#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice, randint
from roller_constant_for import (
    BackdropStyle as bs,
    Bump as fb,
    Caption as pt,
    Fill as fl,
    Frame as fo,
    Fringe as ng,
    Gradient as fg,
    Grid as gr,
    Image as fi,
    Justification as ju,
    Mask as ms,
    Plaque as aq,
    Render as fe,
    Resize as fz,
    Tooltip as ft,
    Shape as sh
)
from roller_constant_key import (
    BackdropStyle as by,
    Effect as ek,
    Option as ok,
    Widget as wk
)
from roller_model_image import Image
from roller_effect import ImageEffect
from roller_one import Base, Comm, Hat, Mode
from roller_one_tip import Tip
from roller_widget_button import (
    ColorButton,
    FileButton,
    FolderButton,
    OptionButton
)
from roller_widget_check_button import CheckButton
from roller_widget_combo import ComboBox
from roller_widget_entry import Entry
from roller_widget_label import Label, GridLabel, MarginLabel, RectangleLabel
from roller_widget_plan import GroupPlan
from roller_widget_per_cell import PerCellGroup
from roller_widget_radio import RadioBox
from roller_widget_slider import Slider
from roller_widget_tree import OptionList, ModelList
from roller_window_brush import RWBrushChoice
from roller_window_bump_choice import RWBumpChoice
from roller_window_choice import RWChoice
from roller_window_image_choice import RWImageChoice
from roller_window_light import RWLight
from roller_window_margin import RWMargin
from roller_window_resize import RWResize
from roller_window_shadow import RWShadow
from roller_window_stripe import RWStripe
import glob
import os
import sys

BLUR = {
    wk.RANDOM: (3., 20.),
    wk.LIMIT: (1., 100.),
    wk.PRECISION: 1,
    wk.WIDGET: Slider
}
CHECK = {wk.WIDGET: CheckButton}
FIXED = {wk.LIMIT: (0, 100000), wk.WIDGET: Slider}
FIXED_POSITION = {wk.LIMIT: (-100000, 100000), wk.WIDGET: Slider}
FIXED_SIZE = {wk.LIMIT: (1, 100000), wk.WIDGET: Slider}
FACTOR_X = {
    wk.LIMIT: (.0, 1.),
    wk.PRECISION: 6,
    wk.TOOLTIP: Tip.FACTOR_X,
    wk.WIDGET: Slider
}
FACTOR_Y = {
    wk.LIMIT: (.0, 1.),
    wk.PRECISION: 6,
    wk.TOOLTIP: Tip.FACTOR_Y,
    wk.WIDGET: Slider
}
GRID_COUNT = {wk.LIMIT: (1, 100), wk.WIDGET: Slider}
KEYS = (
    wk.CHARS,
    wk.CHOICE_WINDOW,
    wk.LABELS,
    wk.LIMIT,
    wk.PRECISION,
    wk.LIST,
    wk.NAME,
    wk.TEXT,
    wk.TIP,
    wk.TIPS,
    wk.TIP_TYPE
)
NET_LINE = {wk.LIMIT: (1, 10000), wk.WIDGET: Slider}
TEXT = {wk.CHARS: 15, wk.WIDGET: Entry}


def get_brush_list():
    """
    Return: list
        of available gradients
    """
    return Hat.cat.brush_list


def get_column_limited(key):
    """
    Generate a random, limited, column value.

    key: string
        option key

    Return: int
        a self-limited randomized column value
    """
    return randint(*Option.row_column_limit[key])


def get_filler_width(key):
    """
    Generate a random filler-space width.

    key: string
        option key
        an effect key

    Return: int
        a random value for a filler width
    """
    a = Option.filler[key]
    return randint(a[0], a[1])


def get_frame_width(key):
    """
    Generate a random value for a frame width.

    key: string
        effect-type

    Return: int
        frame width
    """
    w, h = Option.width[key]
    return randint(w, h)


def get_gradient_list():
    """
    Return: list
        of available gradients
    """
    return Hat.cat.gradient_list


def get_pattern_list():
    """
    Return: list
        of available patterns
    """
    return Hat.cat.pattern_list


def get_image_names():
    """
    Retrieve the image name list that was
    composed during program initialization.

    Return: list
        of GIMP-opened image names
    """
    return Image.image_names


def get_random_backdrop_style():
    """
    Return: string
        a randomly chosen backdrop-style
    """
    return choice(Option.BackdropStyle.names)


def get_random_brush():
    """
    Return: string
        a randomly chosen brush
    """
    return choice(Hat.cat.brush_list)


def get_random_gradient():
    """
    Return: string
        a randomly chosen gradient
    """
    return choice(Hat.cat.gradient_list)


def get_random_image_effect():
    """
    Return: string
        a randomly chosen image-effect
    """
    return choice(Option.Effect.names)


def get_random_pattern():
    """
    Return: string
        a randomly chosen pattern
    """
    return choice(Hat.cat.pattern_list)


def get_row_limited(key):
    """
    Generate a randomized integer for a self-limited row value.

    key: string
        option key

    Return: int
        of row
    """
    return randint(*Option.row_column_limit[key])


class Option:
    """Use to limit a valid range and a random range for option values."""
    # for effect, limit width: (low, high):
    width = {
        ek.BORDER_LINE: (1, 12),
        ek.BRUSH_PUNCH: (1, 12),
        ek.CERAMIC_CHIP: (1, 12),
        ek.CIRCLE_PUNCH: (1, 12),
        ek.CLEAR_FRAME: (1, 65),
        ek.COLOR_PIPE: (1, 65),
        ek.COLOR_BOARD: (1, 65),
        ek.CUTOUT_PLATE: (1, 150),
        ek.GLASS_REVEAL: (1, 100),
        ek.GRADIENT_LEVEL: (1, 100),
        ek.LINE_FASHION: (1, 15),
        ek.MAZE_MIRROR: (1, 15),
        ek.PAINT_RUSH: (1, 100),
        ek.RAD_WAVE: (1, 20),
        ek.RAISED_MAZE: (1, 12),
        ek.SQUARE_PUNCH: (1, 15),
        ek.STAINED_GLASS: (1, 12),
        ek.WIRE_FENCE: (1, 12)
    }

    # for effect, limit filler: (low, high):
    filler = {
        ek.CERAMIC_CHIP: (20, 100),
        ek.CIRCLE_PUNCH: (20, 100),
        ek.LINE_FASHION: (20, 100),
        ek.SQUARE_PUNCH: (20, 100),
        ek.STAINED_GLASS: (20, 100),
        ek.WIRE_FENCE: (20, 100)
    }

    # Is a minimum, maximum value for a limit-random function.
    # If the option in 'keys' is a row or column option, and
    # has a 'GET_WITH_KEY: _get_row_limited key' value-pair,
    # then the option group (either an image-effect or backdrop-style)
    # will need an entry in this dictionary:
    row_column_limit = {
        by.COLOR_GRID: (1, 100),
        by.CORE_DESIGN: (1, 100),
        by.DARK_FORT: (5, 10),
        by.LOST_MAZE: (4, 100),
        by.MAZE_BLEND: (4, 100),
        by.MYSTERY_GRATE: (1, 130),
        by.SPACETIME_FABRIC: (1, 25),
        by.SPIRAL_CHANNEL: (1, 4),
        ek.MAZE_MIRROR: (1, 40),
        ek.RAD_WAVE: (1, 25),
        ek.RAISED_MAZE: (4, 100),
    }
    BACKDROP_BLUR = {
        wk.RANDOM: (0, 500),
        wk.LIMIT: (0, 500),
        wk.WIDGET: Slider
    }

    def __init__(self):
        """
        Option variables use 'keys' to
        define their user-interface widgets.

        The key is an Option or other key.
        The value is a dictionary with
        OptionLimitKey items.

        With each option dictionary define:
        the LIMIT an option widget will allow;
        the RANDOM an option widget will randomize;
        the WIDGET's class-type in the interface.

        If there is no RANDOM, then the
        option does not have randomness.
        """
        self._frame_list = ["None"]
        self._frame_dict = {}
        a = wk
        self.options = {
            ok.AMPLITUDE: {
                a.LIMIT: (2, 30),
                a.RANDOM: (2, 30),
                a.TIP: Tip.JAG_AMPLITUDE,
                a.WIDGET: Slider
            },
            ok.ANGLE_SHIFT: {
                a.LIMIT: (0, 30),
                a.RANDOM: (0, 10),
                a.WIDGET: Slider
            },
            ok.AS_LAYERS: {
                a.TIP: Tip.IMAGE_LAYERS,
                a.WIDGET: CheckButton
            },
            ok.AUTOCROP: {
                a.TIP: Tip.IMAGE_AUTOCROP,
                a.WIDGET: CheckButton
            },
            ok.BACKDROP_BLUR: Option.BACKDROP_BLUR,
            ok.BACKDROP_IMAGE_BLUR: Option.BACKDROP_BLUR,
            ok.BACKDROP_INFLUENCE: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TIP: Tip.BACKDROP_INFLUENCE,
                a.WIDGET: Slider
            },
            ok.BACKGROUND_STRIPE: {
                a.CHOICE_WINDOW: RWStripe,
                a.TIP_TYPE: ft.STRIPE_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.BACKDROP_STYLE: {
                a.GET_RANDOM: get_random_backdrop_style,
                a.LIST: Option.BackdropStyle.names,
                a.WIDGET: OptionList
            },
            ok.BACKDROP_TYPE: {a.LIST: bs.BACKDROP_TYPE, a.WIDGET: ComboBox},
            ok.BEVEL_EDGE_WIDTH: {
                a.LIMIT: (1, 1000),
                a.RANDOM: (8, 24),
                a.WIDGET: Slider
            },
            ok.BLEND: {
                a.LIMIT: (1, 60),
                a.RANDOM: (5, 20),
                a.TIP: Tip.BLEND,
                a.WIDGET: Slider
            },
            ok.BLUR: {
                a.LIMIT: (.0, 500.),
                a.PRECISION: 1,
                a.RANDOM: (.0, 50.),
                a.WIDGET: Slider
            },
            ok.BLUR_BEHIND: {a.LIMIT: (0, 500), a.WIDGET: Slider},
            ok.BLUR_X: BLUR,
            ok.BLUR_Y: BLUR,
            ok.BORDER_BLUR: {
                a.LIMIT: (.0, 500.),
                a.PRECISION: 1,
                a.WIDGET: Slider
            },
            ok.BORDER_WIDTH: {a.LIMIT: (0, 10000), a.WIDGET: Slider},
            ok.BRUSH: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_brush_list,
                a.GET_RANDOM: get_random_brush,
                a.WIDGET: OptionButton
            },
            ok.BRUSH_ANGLE: {
                a.LIMIT: (-180., 180.),
                a.PRECISION: 1,
                a.WIDGET: Slider,
            },
            ok.BRUSH_DICT: {
                a.CHOICE_WINDOW: RWBrushChoice,
                a.COLUMN_TEXT: "Brush",
                a.TIP_TYPE: ft.BRUSH_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.BRUSH_HARDNESS: {
                a.LIMIT: (.001, 1.),
                a.PRECISION: 3,
                a.WIDGET: Slider
            },
            ok.BRUSH_SIZE: {
                a.LIMIT: (10, 10000),
                a.RANDOM: (75, 125),
                a.WIDGET: Slider
            },
            ok.BRUSH_SPACING: {
                a.LIMIT: (10., 5000.),
                a.PRECISION: 1,
                a.RANDOM: (65., 135.),
                a.WIDGET: Slider
            },
            ok.BUMP: {
                a.CHOICE_WINDOW: RWBumpChoice,
                a.TIP_TYPE: ft.BUMP_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.BUMP_DEPTH: {
                a.LIMIT: (1, 100),
                a.RANDOM: (1, 4),
                a.WIDGET: Slider
            },
            ok.BUMP_TYPE: {a.LIST: fb.TYPE, a.WIDGET: ComboBox},
            ok.CAPTION_MARGIN: {
                a.CHOICE_WINDOW: RWMargin,
                a.TIP_TYPE: ft.MARGIN_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.CELL_CAPTION_TYPE: {
                a.LIST: pt.CELL_TYPE_LIST,
                a.WIDGET: ComboBox
            },
            ok.CELL_GAP: {
                a.LIMIT: (2, 100),
                a.RANDOM: (3, 9),
                a.TIP: Tip.CELL_GAP,
                a.WIDGET: Slider
            },
            ok.CELL_NAME: TEXT,
            ok.CELL_PLAN: {a.WIDGET: GroupPlan},
            ok.CELL_SHAPE: {
                a.LIST: sh.SHAPE_LIST,
                a.WIDGET: ComboBox
            },
            ok.CELL_SHAPE_NORMAL: {
                a.LIST: sh.NORMAL_LIST,
                a.WIDGET: ComboBox
            },
            ok.CELL_SHIFT: {a.TIP: Tip.GRID_SHIFT, a.WIDGET: CheckButton},
            ok.CELL_SIZE: {
                a.LIMIT: (1, 1500),
                a.RANDOM: (1, 100),
                a.WIDGET: Slider
            },
            ok.CIRCLE_DIAMETER: {
                a.GET_WITH_KEY: get_filler_width,
                a.LIMIT: (20, 10000),
                a.WIDGET: Slider
            },
            ok.CLIP_TO_CELL: {
                wk.TIP: Tip.CLIP_TO_CELL,
                wk.WIDGET: CheckButton
            },
            ok.CLOSE_FILE: {
                a.COLUMN_TEXT: "Close opened images after first use.",
                a.TOOLTIP: Tip.CLOSE_FILE,
                a.WIDGET: CheckButton
            },
            ok.COLOR: {
                a.GET_RANDOM: Base.rnd_col,
                a.WIDGET: ColorButton
            },
            ok.COLOR_1: {
                a.GET_RANDOM: Base.rnd_col,
                a.WIDGET: ColorButton
            },
            ok.COLOR_2: {
                a.GET_RANDOM: Base.rnd_col,
                a.WIDGET: ColorButton
            },
            ok.COLORIZE: {a.RANDOM: (0, 1), a.WIDGET: CheckButton},
            ok.COLORIZE_OPACITY: {
                a.LIMIT: (1., 100.),
                a.PRECISION: 1,
                a.RANDOM: (1., 100.),
                a.WIDGET: Slider
            },
            ok.COLUMN: {
                a.GET_WITH_KEY: get_column_limited,
                a.LIMIT: (1, 10000),
                a.WIDGET: Slider
            },
            ok.COLUMN_1: {
                a.GET_WITH_KEY: get_column_limited,
                a.LIMIT: (1, 1000),
                a.TIP: Tip.COLUMN_1,
                a.WIDGET: Slider
            },
            ok.COLUMN_2: {
                a.GET_WITH_KEY: get_column_limited,
                a.LIMIT: (1, 1000),
                a.TIP: Tip.COLUMN_2,
                a.WIDGET: Slider
            },
            ok.COLUMN_COUNT: GRID_COUNT,
            ok.COLUMN_MAZE: {
                a.GET_WITH_KEY: get_column_limited,
                a.LIMIT: (4, 10000),
                a.WIDGET: Slider
            },
            ok.COLUMN_SLICE: {
                a.LIMIT: (1, 100000),
                a.WIDGET: Slider
            },
            ok.COLUMN_WIDTH: {a.LIMIT: (1, 100000), a.WIDGET: Slider},
            ok.COMMON_BORDER: CHECK,
            ok.COMPONENT: {a.LIST: bs.COMPONENT, a.WIDGET: ComboBox},
            ok.COMPOSITION_FRAME_WIDTH: {
                a.GET_WITH_KEY: get_frame_width,
                a.LIMIT: (0, 10000),
                a.WIDGET: Slider
            },
            ok.CONTRACT: {
                a.LIMIT: (0, 10000),
                a.TIP: Tip.FRINGE_CONTRACT,
                a.WIDGET: Slider
            },
            ok.CORNER_SHIFT: {
                a.LIMIT: (0, 100),
                a.RANDOM: (0, 18),
                a.WIDGET: Slider
            },
            ok.COVER: {
                a.TEXT:
                    "If necessary, the image is resized so that it can\n"
                    "fill the cell to the greatest degree. The method may\n"
                    "enlarge the image with a locked aspect ratio. In the\n"
                    "process, a portion of the image may be clipped. The\n"
                    "image justification determines the clipped side.",
                a.WIDGET: Label
            },
            ok.CRITERION: {
                a.LIST: fl.CRITERION_LIST,
                a.WIDGET: ComboBox
            },
            ok.CROP_H: FIXED_SIZE,
            ok.CROP_W: FIXED_SIZE,
            ok.CROP_X: {
                a.LIMIT: (0, 100000),
                a.TIP: Tip.RESIZE_CROP_VALUE,
                a.WIDGET: Slider
            },
            ok.CROP_Y: FIXED,
            ok.CURVE: {a.LIST: fo.CURVE, a.WIDGET: ComboBox},
            ok.CUSTOM_CELL_CAPTION_TYPE: {
                a.LIST: pt.CUSTOM_CELL_TYPE_LIST,
                a.WIDGET: ComboBox
            },
            ok.CUSTOM_CELL_SHAPE:  {
                a.LIST: sh.CUSTOM_SHAPE_LIST,
                a.WIDGET: ComboBox
            },
            ok.DECO: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TIP: Tip.DECO,
                a.WIDGET: Slider
            },
            ok.DELETE_PLANS: {
                a.TIP: Tip.DELETE_PLANS,
                a.WIDGET: CheckButton
            },
            ok.DEPTH: {
                a.LIMIT: (1, 100),
                a.RANDOM: (1, 100),
                a.WIDGET: Slider
            },
            ok.DETAIL_LEVEL: {
                a.LIMIT: (1, 15),
                a.RANDOM: (1, 15),
                a.WIDGET: Slider
            },
            ok.DIAGONAL_ROTATION: {
                a.LIMIT: (-359., 359.),
                a.PRECISION: 1,
                a.RANDOM: (-359., 359.),
                a.TIP: Tip.DIAGONAL_ROTATION,
                a.WIDGET: Slider
            },
            ok.EDGE_MODE: {a.LIST: Mode.EDGE_MODE, a.WIDGET: ComboBox},
            ok.EDGE_TYPE: {a.LIST: bs.PaintRush.TYPE, a.WIDGET: ComboBox},
            ok.ELEVATION: {
                a.LIMIT: (.0, 180.),
                a.PRECISION: 1,
                a.RANDOM: (20.0, 40.),
                a.COLUMN_TEXT: "Light Elevation",
                a.TIP: Tip.ELEVATION,
                a.WIDGET: Slider
            },
            ok.EMBOSS: {a.RANDOM: (0, 1), a.WIDGET: CheckButton},
            ok.END_X: {
                a.LIMIT: (.0, 1.),
                a.PRECISION: 6,
                a.RANDOM: (.0, 1.),
                a.TIP: Tip.END_COORDINATE,
                a.WIDGET: Slider
            },
            ok.END_Y: {
                a.LIMIT: (.0, 1.),
                a.PRECISION: 6,
                a.RANDOM: (.0, 1.),
                a.WIDGET: Slider
            },
            ok.FEATHER: {
                a.LIMIT: (0, 10000),
                a.RANDOM: (50, 300),
                a.TIP: Tip.FEATHER,
                a.WIDGET: Slider
            },
            ok.FILE: {a.WIDGET: FileButton},
            ok.FILLED: {
                a.TEXT:
                    "The image is resized so that it fills the cell. Its\n"
                    "aspect ratio will be that of the cell rectangle.",
                a.WIDGET: Label
            },
            ok.FILTER: {a.WIDGET: Entry},
            ok.FIT_IMAGE: CHECK,
            ok.FIXED_BOTTOM: FIXED,
            ok.FIXED_LEFT: FIXED,
            ok.FIXED_IMAGE_SIZE_H: FIXED,
            ok.FIXED_IMAGE_SIZE_W: {
                a.LIMIT: (0, 100000),
                a.TIP: Tip.RESIZE_FIXED_VALUE,
                a.WIDGET: Slider
            },
            ok.FIXED_RIGHT: FIXED,
            ok.FIXED_TOP: FIXED,
            ok.FIXED_POSITION_X: {
                wk.LIMIT: (-100000, 100000),
                wk.TIP: Tip.FIXED_POSITION_X,
                wk.WIDGET: Slider
            },
            ok.FIXED_POSITION_Y: FIXED_POSITION,
            ok.FIXED_WIDTH: FIXED_SIZE,
            ok.FIXED_HEIGHT: FIXED_SIZE,
            ok.FLIP_HORIZONTAL: CHECK,
            ok.FLIP_VERTICAL: CHECK,
            ok.FACTOR_BOTTOM: FACTOR_Y,
            ok.FACTOR_HEIGHT: {
                a.LIMIT: (-1., 1.),
                a.PRECISION: 6,
                a.TIP: Tip.FACTOR_POSITION_H,
                a.WIDGET: Slider
            },
            ok.FACTOR_IMAGE_SIZE_H: {
                a.LIMIT: (.0, 2.),
                a.PRECISION: 6,
                a.WIDGET: Slider,
            },
            ok.FACTOR_IMAGE_SIZE_W: {
                a.LIMIT: (.0, 2.),
                a.PRECISION: 6,
                a.TIP: Tip.RESIZE_FACTOR_VALUE,
                a.WIDGET: Slider,
            },
            ok.FACTOR_LEFT: FACTOR_X,
            ok.FACTOR_POSITION_X: {
                a.LIMIT: (-1., 1.),
                a.PRECISION: 6,
                a.TIP: Tip.FACTOR_POSITION_W,
                a.WIDGET: Slider
            },
            ok.FACTOR_POSITION_Y: {
                a.LIMIT: (-1., 1.),
                a.PRECISION: 6,
                a.TIP: Tip.FACTOR_POSITION_H,
                a.WIDGET: Slider
            },
            ok.FACTOR_RIGHT: FACTOR_X,
            ok.FACTOR_TOP: FACTOR_Y,
            ok.FACTOR_WIDTH: {
                a.LIMIT: (-1., 1.),
                a.PRECISION: 6,
                a.TIP: Tip.FACTOR_POSITION_W,
                a.WIDGET: Slider
            },
            ok.FOLDER: {a.WIDGET: FolderButton},
            ok.FOLDER_ORDER: {
                a.LABELS: fi.FOLDER_ORDER_LIST,
                a.WIDGET: RadioBox
            },
            ok.FONT: {a.CHOICE_WINDOW: RWChoice, a.WIDGET: OptionButton},
            ok.FONT_SIZE: {a.LIMIT: (4, 1000), a.WIDGET: Slider},
            ok.TABLE_NAME: {a.WIDGET: Entry},
            ok.TABLE_PLAN: {a.WIDGET: GroupPlan},
            ok.FRAME: {a.LIST: self._frame_list, a.WIDGET: ComboBox},
            ok.FRAME_STYLE: {a.LIST: fo.FRAME_STYLE, a.WIDGET: ComboBox},
            ok.FRAME_TYPE: {
                a.LABELS:  ("Rounded", "Angular"),
                a.RANDOM: (0, 1),
                a.TIP: Tip.ROUNDED,
                a.WIDGET: RadioBox
            },
            ok.FRAME_WIDTH: {
                a.GET_WITH_KEY: get_frame_width,
                a.LIMIT: (1, 10000),
                a.WIDGET: Slider
            },
            ok.FRINGE_CELL_TYPE: {
                a.LIST: ng.CELL_TYPE,
                a.WIDGET: ComboBox
            },
            ok.FRINGE_LAYER_TYPE: {
                a.LIST: ng.LAYER_TYPE,
                a.WIDGET: ComboBox
            },
            ok.GAP_TYPE: {a.LIST: bs.GAP_TYPE, a.WIDGET: ComboBox},
            ok.GAP_WIDTH: {
                a.LIMIT: (3, 1000),
                a.RANDOM: (12, 100),
                a.WIDGET: Slider
            },
            ok.GRADIENT: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_gradient_list,
                a.GET_RANDOM: get_random_gradient,
                a.WIDGET: OptionButton
            },
            ok.GRADIENT_ANGLE: {a.LIST: fg.GRADIENT_ANGLE, a.WIDGET: ComboBox},
            ok.GRADIENT_DIRECTION: {
                a.LABELS: bs.DIRECTION,
                a.WIDGET: RadioBox
            },
            ok.GRADIENT_MODE: {
                a.LIST: Mode.GRADIENT_MODE_LIST,
                a.WIDGET: ComboBox
            },
            ok.GRADIENT_TYPE: {
                a.LIST: fg.GRADIENT_TYPE_LIST,
                a.WIDGET: ComboBox
            },
            ok.GRID_TYPE: {a.LIST: gr.TYPE_LIST, a.WIDGET: ComboBox},
            ok.HORZ_COUNT: GRID_COUNT,
            ok.HORZ_SCALE: {
                a.LIMIT: (.001, 1.),
                a.PRECISION: 3,
                a.WIDGET: Slider
            },
            ok.IMAGE: {
                a.CHOICE_WINDOW: RWImageChoice,
                a.TIP_TYPE: ft.IMAGE_TIP_TYPE,
                a.WIDGET: OptionButton,
            },
            ok.IMAGE_EFFECT: {
                a.GET_RANDOM: get_random_image_effect,
                a.LIST: Option.Effect.names,
                a.WIDGET: OptionList
            },
            ok.IMAGE_INFLUENCE: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TIP: Tip.IMAGE_INFLUENCE,
                a.WIDGET: Slider
            },
            ok.IMAGE_NAME: {
                a.FUNCTION: get_image_names,
                a.WIDGET: ComboBox
            },
            ok.IMAGE_SOURCE: {
                a.LIST: fi.IMAGE_SOURCE_LIST,
                a.WIDGET: ComboBox
            },
            ok.INFLUENCE: {
                a.CHOICE_WINDOW: RWLight,
                a.TIP_TYPE: ft.INFLUENCE_TYPE,
                a.WIDGET: OptionButton
            },
            ok.INLAY_BLUR: {
                a.LIMIT: (0, 500),
                a.RANDOM: (20, 30),
                a.WIDGET: Slider
            },
            ok.INVERT: {a.RANDOM: (0, 1), a.WIDGET: CheckButton},
            ok.INVERT_NOISE: {a.RANDOM: (0, 1), a.WIDGET: CheckButton},
            ok.INTENSITY: {
                a.LIMIT: (0, 1000),
                a.RANDOM: (80, 200),
                a.WIDGET: Slider
            },
            ok.JUSTIFICATION: {
                a.LIST: ju.TYPE,
                a.WIDGET: ComboBox
            },
            ok.KEEP_GRADIENT: {
                a.TIP: Tip.KEEP_GRADIENT,
                a.WIDGET: CheckButton
            },
            ok.LAYER_CAPTION_TYPE: {
                a.LIST: pt.LAYER_TYPE_LIST,
                a.WIDGET: ComboBox
            },
            ok.LAYER_COUNT: {
                a.LIMIT: (3, 15),
                a.RANDOM: (4, 8),
                a.WIDGET: Slider
            },
            ok.GRID_SIZE: {a.WIDGET: GridLabel},
            ok.LAYER_ORDER: {
                a.LABELS: fi.LAYER_ORDER_LIST,
                a.TIP: Tip.IMAGE_ORDER,
                a.WIDGET: RadioBox
            },
            ok.LEADING_TEXT: {
                a.CHARS: 10,
                a.TIP: Tip.CAPTION_LEADING_TEXT,
                a.WIDGET: Entry,
            },
            ok.LIGHT_ANGLE: {
                a.LIMIT: (.0, 359.),
                a.RANDOM: (.0, 359.),
                a.PRECISION: 1,
                a.TIP: Tip.LIGHT_ANGLE,
                a.WIDGET: Slider
            },
            ok.LINE_WIDTH: {
                a.LIMIT: (3, 10000),
                a.RANDOM: (3, 20),
                a.WIDGET: Slider
            },
            ok.LOCKED: {
                a.TEXT:
                    "The images proportions are locked and a best fit\n"
                    "is applied if necessary. The image is not enlarged.",
                a.WIDGET: Label
            },
            ok.LOOP_INDEX: {
                a.LABELS: fi.LOOP_TYPE,
                a.TIPS: (Tip.LOOP_PLUS, Tip.LOOP_MINUS),
                a.WIDGET: RadioBox
            },
            ok.MAKE_OPAQUE: {
                a.LABELS: (
                    "No, use the original source opacity.",
                    "Yes, use an opaque source."
                ),
                a.TIP: Tip.MAKE_OPAQUE,
                a.WIDGET: RadioBox,
            },
            ok.MARGIN_SIZE: {a.WIDGET: MarginLabel},
            ok.MASK_TYPE: {
                a.LIST: ms.TYPE,
                a.WIDGET: ComboBox
            },
            ok.MAZE_DIRECTION: {a.LABELS: bs.DIRECTION, a.WIDGET: RadioBox},
            ok.MAZE_TYPE: {
                a.LIST: bs.MAZE_TYPE,
                a.WIDGET: ComboBox
            },
            ok.MESH_SIZE: {
                a.LIMIT: (8, 1000),
                a.RANDOM: (25, 60),
                a.WIDGET: Slider
            },
            ok.MESH_TYPE: {a.LIST: bs.MESH_TYPE, a.WIDGET: ComboBox},
            ok.METAL_FRAME: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TIP: Tip.METAL_FRAME,
                a.WIDGET: Slider
            },
            ok.MODE: {
                a.GET_RANDOM: Mode.rand,
                a.LIST: Mode.names,
                a.WIDGET: ComboBox
            },
            ok.MODEL_LIST: {a.WIDGET: ModelList, a.NAME: "Model"},
            ok.NAME: {a.WIDGET: Entry},
            ok.NEATNESS: {
                a.LIMIT: (.0, 1.),
                a.PRECISION: 3,
                a.RANDOM: (.0, 1.),
                a.WIDGET: Slider
            },
            ok.NET_LINE_SPACING: NET_LINE,
            ok.NET_LINE_WIDTH: NET_LINE,
            ok.NEXT_INDEX: {
                a.LABELS: fi.NEXT_TYPE,
                a.TIPS: (
                    Tip.IMAGE_NEXT_LINEAR,
                    Tip.IMAGE_NEXT_CIRCULAR
                ),
                a.WIDGET: RadioBox
            },
            ok.NOISE: {
                a.LIMIT: (.0, 1.),
                a.PRECISION: 3,
                a.RANDOM: (.0, .5),
                a.WIDGET: Slider
            },
            ok.NOISE_MODE: {
                a.LIST: bs.NOISE_MODE_LIST,
                a.WIDGET: ComboBox
            },
            ok.NOISE_OPACITY: {
                a.LIMIT: (.0, 100.),
                a.PRECISION: 1,
                a.RANDOM: (.0, 100.),
                a.WIDGET: Slider
            },
            ok.NUMBER_OF_SLICES: {
                a.LIMIT: (2, 60),
                a.RANDOM: (2, 15),
                a.WIDGET: Slider
            },
            ok.NUMERIC_SEQUENCE: {
                a.LIST: Image.relative_names,
                a.WIDGET: ComboBox
            },
            ok.OBEY_MARGINS: {a.TIP: Tip.GRID_BOUNDS, a.WIDGET: CheckButton},
            ok.OFFSET: {
                a.LIMIT: (0, 10000),
                a.RANDOM: (0, 20),
                a.WIDGET: Slider
            },
            ok.OFFSET_X: {
                a.LIMIT: (-10000, 10000),
                a.RANDOM: (-25, 25),
                a.WIDGET: Slider
            },
            ok.OFFSET_Y: {
                a.LIMIT: (-10000, 10000),
                a.RANDOM: (-25, 25),
                a.WIDGET: Slider
            },
            ok.OPACITY: {
                a.LIMIT: (.0, 100.),
                a.PRECISION: 1,
                a.RANDOM: (25., 100.),
                a.WIDGET: Slider
            },
            ok.OTHER_FRAME: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TIP: Tip.OTHER_FRAME,
                a.WIDGET: Slider
            },
            ok.PANE_HEIGHT: {
                a.LIMIT: (25, 1000),
                a.RANDOM: (100, 200),
                a.WIDGET: Slider
            },
            ok.PANE_WIDTH: {
                a.LIMIT: (25, 1000),
                a.RANDOM: (100, 200),
                a.WIDGET: Slider
            },
            ok.PATTERN: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_pattern_list,
                a.GET_RANDOM: get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PATTERN_1: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_pattern_list,
                a.GET_RANDOM: get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PATTERN_2: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_pattern_list,
                a.GET_RANDOM: get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PATTERN_3: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_pattern_list,
                a.GET_RANDOM: get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PER_CELL: {a.COLUMN_TEXT: "", a.WIDGET: PerCellGroup},
            ok.PIN_CORNER: {a.LIST: gr.PIN_LIST, a.WIDGET: ComboBox},
            ok.PLAQUE_TYPE: {
                a.LIST: aq.TYPE,
                a.WIDGET: ComboBox
            },
            ok.POST_BLUR: {
                a.LIMIT: (0, 500),
                a.RANDOM: (0, 100),
                a.TIP: Tip.POST_BLUR,
                a.WIDGET: Slider
            },
            ok.POWER: {
                a.LIMIT: (0, 180),
                a.RANDOM: (0, 180),
                a.TIP: Tip.NOISE_POWER,
                a.WIDGET: Slider
            },
            ok.PREVIEW_MODE: {
                a.LABELS: ("Show Gradient", "Show Samples."),
                a.WIDGET: RadioBox
            },
            ok.PREVIOUS_INDEX: {
                a.LABELS: fi.PREVIOUS_TYPE,
                a.TIPS: (
                    Tip.IMAGE_PRE_LINEAR,
                    Tip.IMAGE_PRE_CIRCULAR
                ),
                a.WIDGET: RadioBox
            },
            ok.PROFILE: {a.LIST: fo.PROFILE, a.WIDGET: ComboBox},
            ok.RANDOM_SEED: {
                a.LIMIT: (0, 2147483640),
                a.RANDOM: (0, 2147483640),
                a.TIP: Tip.RANDOM_SEED,
                a.WIDGET: Slider
            },
            ok.RECTANGLE_SPECS: {a.WIDGET: RectangleLabel},
            ok.RENDER_HEIGHT: {
                a.LIMIT: (1, fe.MAX_SIZE),
                a.WIDGET: Slider
            },
            ok.RENDER_WIDTH: {
                a.LIMIT: (1, fe.MAX_SIZE),
                a.WIDGET: Slider
            },
            ok.RESIZE_METHOD: {
                a.CHOICE_WINDOW: RWResize,
                a.TIP_TYPE: ft.RESIZE_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.RESIZE_TYPE: {a.LIST: fz.RESIZE_TYPE_LIST, a.WIDGET: ComboBox},
            ok.REVERSE: {
                a.RANDOM: (0, 1),
                a.TIP: Tip.REVERSE,
                a.WIDGET: CheckButton
            },
            ok.ROTATE: {
                a.LIMIT: (-359., 359.),
                a.PRECISION: 1,
                a.RANDOM: (-359., 359.),
                a.WIDGET: Slider
            },
            ok.ROW: {
                a.GET_WITH_KEY: get_row_limited,
                a.LIMIT: (1, 10000),
                a.WIDGET: Slider
            },
            ok.ROW_COUNT: {
                a.LIMIT: (1, 100),
                a.TIP: Tip.GRID_BY_COUNT,
                a.WIDGET: Slider
            },
            ok.ROW_HEIGHT: {
                a.LIMIT: (1, 100000),
                a.TIP: Tip.GRID_FIXED_SIZE,
                a.WIDGET: Slider
            },
            ok.ROW_MAZE: {
                a.LIMIT: (4, 10000),
                a.GET_WITH_KEY: get_row_limited,
                a.WIDGET: Slider
            },
            ok.ROW_SLICE: {
                a.LIMIT: (1, 100000),
                a.WIDGET: Slider
            },
            ok.SAMPLE_POINTS: {
                a.LIMIT: (2, 50),
                a.RANDOM: (2, 25),
                a.TIP: Tip.SAMPLE_POINTS,
                a.WIDGET: Slider
            },
            ok.SAMPLE_RADIUS: {
                a.LIMIT: (1, 100),
                a.RANDOM: (10, 50),
                a.WIDGET: Slider
            },
            ok.SAMPLE_VECTOR: {a.LIST: bs.VECTOR, a.WIDGET: ComboBox},
            ok.SATURATION: {
                a.LIMIT: (.0, 10.),
                a.PRECISION: 2,
                a.RANDOM: (.0, 2.),
                a.TIP: Tip.SATURATION,
                a.WIDGET: Slider
            },
            ok.SCATTER_COUNT: {
                a.LIMIT: (1, 100),
                a.RANDOM: (2, 20),
                a.TIP: Tip.SCATTER_COUNT,
                a.WIDGET: Slider
            },
            ok.SHADOW_BLUR: {
                a.LIMIT: (0, 500),
                a.RANDOM: (15, 40),
                a.WIDGET: Slider
            },
            ok.SHADOW_COLOR: {a.WIDGET: ColorButton},
            ok.SHADOW_TYPE: {a.LABELS: ("None", "Shadow"), a.WIDGET: RadioBox},
            ok.SKETCH_TEXTURE: {
                a.LIST: bs.NEWS_TYPE,
                a.WIDGET: ComboBox
            },
            ok.SLICE: {
                a.TIP: Tip.SLICE,
                a.WIDGET: CheckButton
            },
            ok.SLICE_ORDER: {
                a.LABELS: fi.SLICE_ORDER_LIST,
                a.WIDGET: RadioBox
            },
            ok.SMOOTHNESS: {
                a.LIMIT: (3, 20),
                a.RANDOM: (5, 12),
                a.WIDGET: Slider
            },
            ok.SOFTNESS: {
                a.LIMIT: (0, 1000),
                a.RANDOM: (0, 1000),
                a.WIDGET: Slider
            },
            ok.SPIRAL_DISTANCE: {
                a.LIMIT: (.001, .5),
                a.RANDOM: (.001, .5),
                a.PRECISION: 3,
                a.TIP: Tip.SPIRAL_DISTANCE,
                a.WIDGET: Slider
            },
            ok.SPIRAL_MOD: {
                a.LIST: bs.SPIRAL_MOD_LIST,
                a.WIDGET: ComboBox
            },
            ok.START_X: {
                a.LIMIT: (.0, 1.),
                a.RANDOM: (.0, 1.),
                a.PRECISION: 6,
                a.TIP: Tip.START_X,
                a.WIDGET: Slider
            },
            ok.START_Y: {
                a.LIMIT: (.0, 1.),
                a.RANDOM: (.0, 1.),
                a.PRECISION: 6,
                a.WIDGET: Slider
            },
            ok.STARTING_ANGLE: {
                a.LIMIT: (-360, 360),
                a.RANDOM: (-360, 360),
                a.WIDGET: Slider
            },
            ok.START_NUMBER: {
                a.LIMIT: (-sys.maxint, sys.maxint),
                a.TIP: Tip.CAPTION_START_NUMBER,
                a.WIDGET: Slider
            },
            ok.STEPS: {
                a.LIMIT: (1, 40),
                a.RANDOM: (1, 12),
                a.TIP: Tip.STEPS,
                a.WIDGET: Slider
            },
            ok.STOP_LENGTH: {
                a.LIMIT: (1, 100),
                a.RANDOM: (20, 30),
                a.TIP: Tip.STOP_LENGTH,
                a.WIDGET: Slider
            },
            ok.STRIPE_HEIGHT: {
                a.LIMIT: (.1, 2.),
                a.PRECISION: 1,
                a.TIP: Tip.STRIPE_HEIGHT,
                a.WIDGET: Slider
            },
            ok.STRIPE_TYPE: {
                a.LABELS:  ("None", "Caption Stripe"),
                a.WIDGET: RadioBox
            },
            ok.TAPE_LENGTH: {
                a.LIMIT: (5, 1000),
                a.RANDOM: (80, 140),
                a.WIDGET: Slider
            },
            ok.TAPE_WIDTH: {
                a.LIMIT: (5, 1000),
                a.RANDOM: (30, 60),
                a.WIDGET: Slider
            },
            ok.TEXT: TEXT,
            ok.TEXTURE: {
                a.RANDOM: (0, 1),
                a.WIDGET: CheckButton
            },
            ok.TILE_SIZE: {
                a.LIMIT: (2., 256.),
                a.RANDOM: (7., 30.),
                a.WIDGET: Slider
            },
            ok.THRESHOLD: {
                a.LIMIT: (.0, 1.),
                a.PRECISION: 3,
                a.RANDOM: (.33, 1.),
                a.TIP: Tip.THRESHOLD,
                a.WIDGET: Slider
            },
            ok.TRANSLUCENT_FRAME: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TIP: Tip.TRANSLUCENT_FRAME,
                a.WIDGET: Slider
            },
            ok.TRAILING_TEXT: {
                a.CHARS: 10,
                a.TIP: Tip.CAPTION_TRAILING_TEXT,
                a.WIDGET: Entry,
            },
            ok.TRIM: {
                a.TEXT:
                    "If necessary, the image is resized so that it can fill\n"
                    "the cell to the greatest degree without enlarging or\n"
                    "stretching the image. In the process, a side of the\n"
                    "image may be trimmed. The image justification\n"
                    "determines which part of a side is removed.",
                a.WIDGET: Label
            },
            ok.TRI_SHADOW: {
                a.CHOICE_WINDOW: RWShadow,
                a.TIP_TYPE: ft.SHADOW_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.USE_PLASMA: {
                a.RANDOM: (0, 1),
                a.TIP: Tip.USE_PLASMA,
                a.WIDGET: CheckButton
            },
            ok.VERT_COUNT: {
                a.LIMIT: (1, 100),
                a.TIP: Tip.GRID_NORMALIZED,
                a.WIDGET: Slider
            },
            ok.VERT_SCALE: {
                a.LIMIT: (.001, 1.),
                a.PRECISION: 3,
                a.WIDGET: Slider
            },
            ok.WAVE_AMPLITUDE: {
                a.LIMIT: (0, 100),
                a.RANDOM: (0, 10),
                a.WIDGET: Slider
            },
            ok.WAVE_PER_LAYER: {
                a.LIMIT: (3, 6),
                a.RANDOM: (1, 15),
                a.WIDGET: Slider
            },
            ok.WAVELENGTH: {
                a.LIMIT: (1., 50.),
                a.PRECISION: 1,
                a.RANDOM: (30., 50.),
                a.WIDGET: Slider
            },
            ok.WHIRL: {
                a.LIMIT: (-720, 720),
                a.RANDOM: (-30, 30),
                a.TIP: Tip.WHIRL,
                a.WIDGET: Slider
            },
            ok.WIDTH: {
                a.GET_WITH_KEY: get_filler_width,
                a.LIMIT: (3, 10000),
                a.WIDGET: Slider
            },
            ok.WIRE_THICKNESS: {
                a.LIMIT: (3, 30),
                a.RANDOM: (4, 10),
                a.WIDGET: Slider
            }
        }

    def collect_widget_arg(self, k):
        """
        Gather together the widget keyword arguments.

        k: string
            option key

        on_accept: function
            Use with ChoiceList.
        """
        d = {}
        e = self.options[k]

        for k in KEYS:
            if k in e:
                d[k] = e[k]

        if wk.FUNCTION in e:
            d[wk.LIST] = e[wk.FUNCTION]()
        return d

    def create_frame_list(self):
        """
        Get the frame file names and make a list for the frame list.
        """
        go = False

        try:
            # Ignore sub-directories:
            files = glob.glob(
                Hat.cat.frame_path + os.path.sep + "*.png"
            )
            go = True

        except Exception as ex:
            Comm.show_err(ex)
            Comm.show_err("Roller was unable to load frame images.")
        if go:
            for i in files:
                n = os.path.splitext(os.path.basename(i))[0]
                self._frame_dict[n] = i
                self._frame_list.append(n)

    class Effect:
        """Is a list of image-effects for PortOption."""
        default = ek.KEY_LIST[:]
        names = sorted([k for k in default])

        # Remove options that are not a main effect:
        for k in (
            ek.SHADOW_1,
            ek.SHADOW_2,
            ek.INNER_SHADOW,
            ek.NO_EFFECT
        ):
            names.pop(names.index(k))
        names = [ek.NO_EFFECT] + names

    class BackdropStyle:
        """Is a list of backdrop-styles for PortOption."""
        default = by.KEY_LIST[:]
        names = sorted([k for k in default])


class OptionStat:
    """Has static functions used by PortOption and Render."""

    @staticmethod
    def get_effect_keys(effect):
        """
        Generate a list of sub-effect keys for an effect.

        effect: string
            an image-effect

        Return: list
            of sub-effects
            of strings
        """
        q = ImageEffect.PROPERTY[effect][ImageEffect.EFFECT_STEPS]

        if effect == ek.TRI_SHADOW:
            return q
        return (effect,) + q
