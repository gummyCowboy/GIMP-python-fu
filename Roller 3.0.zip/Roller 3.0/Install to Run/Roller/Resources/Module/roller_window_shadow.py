#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk, Window as wi
from roller_port_shadow import PortShadow
from roller_window import Window


class RWShadow(Window):
    """
    Is a GTK dialog with multiple options for the user to define a shadow.
    """
    def __init__(self, g):
        """
        Create a shadow-choice window.

        g: Button
            Is responsible.
        """
        self.safe = g
        d = {wk.WIN: g.win.win}
        d[wk.WINDOW_TITLE] = "Choose Shadow Type"
        d[wk.WINDOW_KEY] = wi.SHADOW_CHOOSER

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortShadow(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()
