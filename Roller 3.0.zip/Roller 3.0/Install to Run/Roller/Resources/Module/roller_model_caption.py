#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Caption as pt,
    Format as ff,
    Justification as ju,
    Plan as fy
)
from roller_constant_key import Layer as nk, Option as ok
from roller_model_text import Text
from roller_one import Base, Comm, Hat, Rect
from roller_one_fu import Lay, Sel
from roller_one_extract import dispatch, Form, Path, Shape
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

pdb = fu.pdb
NO_SAVE = nk.CUSTOM_CELL_CAPTION, nk.LAYER_CAPTION
YES_ANTIALIAS = 1
X_IS_0 = Y_IS_0 = W_IS_0 = H_IS_0 = 0


def blur_behind(z, d):
    """
    Blur behind material.

    z: layer
        with material

    d: dict
        Has the blur behind option.

    Return: layer
        with material
    """
    z1 = RenderHub.blur_behind(z, d)
    if z1:
        z = z1
    return z


def blur_behind_layer(one, z, d):
    """
    Blur behind a layer caption stripe.

    one: One
        Has model name.

    z: layer
        with stripe

    d: dict
        of background stripe

    return: layer
        with caption
    """
    if d[ok.STRIPE_TYPE] and d[ok.OPACITY] and d[ok.BLUR_BEHIND]:
        z = blur_behind(z, d)
        Hat.cat.register_layer((one.model_name, nk.LAYER_CAPTION), z)
    return z


def get_text(one, r, c, _type):
    """
    Create the text as defined by the grid
    cell data for the caption option group.

    one: One
        Has variables.

    r, c: int
        cell index

    _type: string
        type of caption

    Return: string
        the caption
    """
    d = one.d
    text = ""

    if _type == pt.TEXT:
        text = d[ok.TEXT]

    elif _type == pt.SEQUENCE_NUMBER:
        if one.is_per_cell:
            text = d[ok.TEXT]
        else:
            text = str(one.image_number)
            one.image_number += 1

    elif _type == pt.IMAGE_NAME:
        text = one.cell.image_name if r == fy.CUSTOM_CELL \
            else one.grid.get_image_name(r, c)

    if _type in (pt.IMAGE_NAME, pt.SEQUENCE_NUMBER):
        n = d[ok.LEADING_TEXT]
        n1 = d[ok.TRAILING_TEXT]
        if text:
            if n:
                text = n + text
            if n1:
                text += n1
    return text


def make_caption(z, one, text, layer_key, name):
    """
    Add text. Call once per cell.

    z: layer
        to receive text

    one: One
        Has cell data.

    text: string
        to display

    layer_key: string
        Use to find layer.

    name: string
        layer name
        either a layer or cell-type caption layer
    """
    go = True
    cat = Hat.cat
    j = cat.render.image
    d = one.d
    font = d[ok.FONT]

    if font not in cat.font_list:
        Comm.info_msg(ff.MISSING_ITEM.format("Caption", "font", font))
        go = False

    if go:
        color = (255, 255, 255) if one.is_plan else d[ok.COLOR]
        go, z = Text.make_text_layer(
            j, z,
            YES_ANTIALIAS,
            X_IS_0, Y_IS_0,
            text,
            d[ok.FONT_SIZE],
            font,
            color,
            W_IS_0, H_IS_0
        )
    if go:
        Sel.item(z)

        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        text_width = x1 - x
        text_height = y1 - y
        half_width = text_width // 2
        half_height = text_height // 2
        top, bottom, left, right = Form.combine_margin(
            d[ok.CAPTION_MARGIN],
            one.rect.w, one.rect.h
        )

        # cell width, height:
        w = one.rect.w - left - right
        h = one.rect.h - top - bottom
        n = d[ok.JUSTIFICATION]

        # Correction the w, h dimension:
        w = max(w, 1)
        h = max(h, 1)

        # cell position x, y:
        s = cat.render.size
        x = one.rect.x + left
        y = one.rect.y + top
        x = min(x, s[0] - 1)
        y = min(y, s[1] - 1)

        # Get 'y':
        if n in ju.BOTTOM:
            y += h - text_height

        elif n in ju.CENTER_Y:
            # middle:
            y += (h // 2) - half_height

        # Get 'x':
        if n in ju.RIGHT:
            x += w - text_width

        elif n in ju.CENTER_X:
            # center:
            x += (w // 2) - half_width

        # Correct the x, y position:
        x = Base.seal(x, one.rect.x, s[0] - 1)
        y = Base.seal(y, one.rect.y, s[1] - 1)

        # Move the text layer:
        pdb.gimp_layer_set_offsets(z, x, y)

        if not one.is_plan:
            z.name = name
            z.opacity = d[ok.OPACITY]
            z = Shadow.do_shadows(d[ok.TRI_SHADOW], z)
        make_stripe(d[ok.BACKGROUND_STRIPE], z, one, layer_key)


def make_stripe(d, z, one, layer_key):
    """
    Determine if a caption stripe is required.

    Create the caption background stripe.

    d: dict
        of stripe

    z: layer
        Has caption.

    one: One
        Has variables.

    layer_key: string
        type of stripe
        Use to distinguish a layer from a cell caption.
    """
    def clip(_z):
        """
        Keep the stripe and caption with the bounds a cell plaque.

        _z: layer
            to clip
        """
        if one.is_clip:
            Sel.select_shape(j, one.plaque)
            Sel.invert_clear(_z, keep_sel=True)

    j = z.image

    if d[ok.STRIPE_TYPE] and d[ok.OPACITY]:
        Sel.item(z)

        cat = Hat.cat
        n = z.name
        is_sel, _, y, _, y1 = pdb.gimp_selection_bounds(j)
        if is_sel:
            h = y1 - y
            center_y = y + h // 2
            h1 = int(h * d[ok.STRIPE_HEIGHT])
            y = center_y - h1 // 2
            group = Lay.group(
                j,
                n,
                parent=z.parent,
                offset=pdb.gimp_image_get_item_position(j, z) + 1
            )
            z1 = Lay.add(j, n, parent=group)

            pdb.gimp_image_reorder_item(j, z, group, 0)
            Sel.rect(
                j,
                one.rect.x, y,
                one.rect.w, h1,
                option=fu.CHANNEL_OP_REPLACE
            )
            Sel.fill(
                z1,
                one.color if one.is_plan else d[ok.COLOR]
            )
            clip(z1)

            z1.opacity = d[ok.OPACITY]

            if (
                d[ok.BLUR_BEHIND] and
                not one.is_plan and
                d[ok.OPACITY] < 100. and
                layer_key not in NO_SAVE
            ):
                one.is_stripe = True
                cat.save_caption_stripe_sel(
                    z1,
                    one.model_name,
                    one.r, one.c
                )
            z = Lay.merge_group(group)
    clip(z)


class Caption:
    """Create a text overlay on a cell."""

    @staticmethod
    def blur_behind_custom_cell(one):
        """
        Blur behind a custom cell caption stripe.

        one: One
            Has a path variable.

        Return: layer or None
            with blur behind
        """
        cat = Hat.cat
        z1 = None
        r = fy.CUSTOM_CELL
        d = Path.get_cell_caption_form(one.path, r, r)[ok.BACKGROUND_STRIPE]
        blur = d[ok.BLUR_BEHIND]

        if d[ok.STRIPE_TYPE] and d[ok.OPACITY] and blur:
            j = cat.render.image
            z = cat.get_layer((one.model_name, nk.CELL_CAPTION))
            if z:
                z1 = RenderHub.copy_for_blur(z)
                z2 = Lay.clone_opaque(z, True)
                z1.name = Lay.make_name(z1.parent, nk.CAPTION_BEHIND)

                Sel.item(z2)
                Lay.blur(z1, blur)
                Sel.invert_clear(z1)
                pdb.gimp_image_remove_layer(j, z2)
        return z1

    @staticmethod
    def blur_behind_grid(one):
        """
        Blur behind grid cells.

        one: One
            Has variables.

        Return: layer or None
            with blur behind
        """
        cat = Hat.cat
        j = cat.render.image
        d = Path.get_cell_caption_chunk(one.path)
        grid_d = one.grid.grid_d
        is_merge_cell = one.grid.is_merge_cell
        is_per_cell = d[ok.PER_CELL]

        n = one.model_name
        s = 1
        q = []
        z = cat.get_layer((one.model_name, nk.CELL_CAPTION))
        row, column = one.grid.division

        # for blur material:
        z1 = None

        if z:
            for r in range(row):
                for c in range(column):
                    go = Shape.is_allocated_cell(one.grid, r, c)

                    if go:
                        if is_merge_cell:
                            s = grid_d[ok.PER_CELL][r][c]

                        if s == (-1, -1):
                            go = False

                    if go:
                        e = is_per_cell[r][c] if is_per_cell else d
                        go = blur = e[ok.BACKGROUND_STRIPE][ok.BLUR_BEHIND]

                    if go:
                        go = cat.is_caption_sel(n, r, c)
                    if go:
                        sel = cat.get_caption_stripe_sel(one.model_name, r, c)
                        if sel:
                            q += [sel]
                            if not z1:
                                z1 = RenderHub.copy_for_blur(z)
                                z1.name = Lay.make_name(
                                    z1.parent,
                                    nk.CAPTION_BEHIND
                                )

                            Sel.load(j, sel)
                            Lay.blur(z1, blur)
            if z1:
                pdb.gimp_selection_none(j)

                for i in q:
                    Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
                if q:
                    Sel.invert_clear(z1)
        return z1

    @staticmethod
    def do_custom_cell(one, is_plan):
        """
        Do a caption for a custom cell.

        one: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with caption
        """
        cat = Hat.cat
        j = cat.render.image
        d = one.d
        parent = one.parent
        n = Lay.make_name(parent, nk.CELL_CAPTION)
        r = fy.CUSTOM_CELL
        z = group = None
        a = one.cell.rect
        one.is_clip = d[ok.CLIP_TO_CELL]
        one.is_plan = is_plan
        one.rect = a
        text = get_text(one, r, r, d[ok.CUSTOM_CELL_CAPTION_TYPE])

        if text:
            one.plaque = dispatch[one.cell.shape](a)
            group = Lay.group(j, n, parent=parent)
            z = Lay.add(j, "Caption", parent=group)
            make_caption(z, one, text, nk.CUSTOM_CELL_CAPTION, n)

        if group:
            z = Lay.merge_group(group)
        return z

    @staticmethod
    def do_grid(one, is_plan):
        """
        Do the cell captions.

        one: One
            Has variables.

        is_plan: bool
            Is true if Plan is calling.

        Return: layer or None
            with caption
        """
        cat = Hat.cat
        j = cat.render.image
        parent = one.parent
        is_merge_cell = one.grid.is_merge_cell
        grid_d = one.grid.grid_d
        row, column = one.grid.division
        n = Lay.make_name(parent, nk.CELL_CAPTION)
        one.image_number = one.d[ok.START_NUMBER]
        is_per_cell = one.is_per_cell = one.d[ok.PER_CELL]
        one.is_plan = is_plan
        d = one.d
        z = group = None
        go = True

        if not is_per_cell and d[ok.CELL_CAPTION_TYPE] == "None":
            go = False

        if go:
            for r in range(row):
                for c in range(column):
                    go = True

                    # Don't do dependent cells:
                    if is_merge_cell:
                        if grid_d[ok.PER_CELL][r][c] == (-1, -1):
                            go = False

                    if go:
                        go = Shape.is_allocated_cell(one.grid, r, c)

                    if go:
                        e = one.d = Form.get_form(d, r, c) if is_per_cell \
                            else d

                        n1 = e[ok.CUSTOM_CELL_CAPTION_TYPE] if is_per_cell \
                            else e[ok.CELL_CAPTION_TYPE]

                        text = get_text(one, r, c, n1)
                        if not text:
                            go = False
                    if go:
                        if not group:
                            group = Lay.group(j, n, parent=parent)
                            z = Lay.add(j, "Caption", parent=group)

                        one.rect = one.grid.get_merge_cell_rect(r, c)
                        one.is_clip = e[ok.CLIP_TO_CELL]
                        one.r, one.c = r, c

                        if one.is_clip:
                            one.plaque = one.grid.get_plaque(r, c)
                        make_caption(z, one, text, nk.CELL_CAPTION, n)
        if group:
            z = Lay.merge_group(group)
        return z

    @staticmethod
    def do_layer(one, is_plan):
        """
        Do a layer caption.

        one: One
            Has init variables.

        Return: tuple or None
            with caption layer
        """
        cat = Hat.cat
        parent = one.parent
        d = one.d
        j = cat.render.image
        z = None
        text = d[ok.TEXT]

        if text and d[ok.LAYER_CAPTION_TYPE] != "None":
            is_clip = one.is_clip = d[ok.CLIP_TO_CELL]
            one.c = one.r = fy.LAYER
            one.is_plan = is_plan
            n = Lay.make_name(parent, nk.LAYER_CAPTION)
            group = Lay.group(j, n, parent=parent)
            z = Lay.add(j, "Caption", parent=group)
            size = cat.render.size

            if d[ok.OBEY_MARGINS]:
                y, bottom, x, right = one.layer_margin
                w = size[0] - x - right
                h = size[1] - y - bottom

            else:
                x = y = 0
                w, h = size

            one.rect = Rect((x, y), (w, h))

            if is_clip:
                one.plaque = (
                    x, y,
                    x + w, y,
                    x + w, y + h,
                    x, y + h
                )
            make_caption(z, one, text, nk.LAYER_CAPTION, n)

            z = Lay.merge_group(group)
            if not is_plan:
                e = d[ok.BACKGROUND_STRIPE]
                z = blur_behind_layer(one, z, e)
        return z
