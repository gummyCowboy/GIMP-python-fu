#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat, Mode
from roller_one_fu import Lay, Sel
import gimpfu as fu

ed = Fu.Edge
em = Fu.Emboss
pdb = fu.pdb
DIFF = fu.LAYER_MODE_DIFFERENCE
DIVIDE = fu.LAYER_MODE_DIVIDE
EXTRACT = fu.LAYER_MODE_GRAIN_EXTRACT
FOUR_COORDINATES = 4
LIGHT = fu.LAYER_MODE_LINEAR_LIGHT
MULTIPLY = fu.LAYER_MODE_MULTIPLY
NORMAL = fu.LAYER_MODE_NORMAL
MIXED_EDGE = bs.PaintRush.WHITE_MIXED, bs.PaintRush.GREY_MIXED
SUBTRACT = fu.LAYER_MODE_SUBTRACT


def clear_selection(j, z, image_sel, sel):
    """
    Clear the center selection and the area outside of the image material.

    j: GIMP image
        work-in-progress

    z: layer
        with material to clear

    image_sel: Selection
        of image material

    sel: Selection
        to clear
    """
    Sel.load(j, image_sel)
    Sel.invert_clear(z)
    Sel.load(j, sel)
    Lay.clear_sel(z)


class PaintRush:
    """Create a frame around image material from altered image material."""

    @staticmethod
    def do(one):
        """
        Do the image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Paint Rush
        """
        cat = Hat.cat
        parent = one.parent
        d = one.d
        j = cat.render.image
        image_layer = one.image_layer
        group = Lay.group(
            j,
            one.k,
            parent=parent,
            offset=Lay.offset(image_layer)
        )
        x = bs.PaintRush.TYPE.index(d[ok.EDGE_TYPE])
        group.mode = fu.LAYER_MODE_LIGHTEN_ONLY
        z = Lay.clone(image_layer)
        z.mode = (DIVIDE, DIVIDE, EXTRACT, EXTRACT, EXTRACT, EXTRACT)[x]

        Sel.make_layer_sel(z)
        Sel.invert_clear(z)
        pdb.gimp_image_reorder_item(j, z, group, 0)
        pdb.plug_in_edge(j, z, ed.AMOUNT_2, ed.WRAP, ed.SOBEL)

        z = z1 = Lay.clone(z)
        z.mode = (SUBTRACT, SUBTRACT, EXTRACT, SUBTRACT, SUBTRACT, SUBTRACT)[x]

        pdb.gimp_image_lower_item_to_bottom(j, z)

        z = z2 = Lay.clone(z)
        z.mode = (LIGHT, LIGHT, LIGHT, LIGHT, LIGHT, NORMAL)[x]
        w = d[ok.FRAME_WIDTH]

        while w:
            w1 = min(w, 500)
            w -= w1
            Lay.blur(z, w1)

        if d[ok.EDGE_TYPE] in MIXED_EDGE:
            w = d[ok.FRAME_WIDTH] // 2
            while w:
                w1 = min(w, 500)
                w -= w1
                Lay.blur(z, w1)

        pdb.gimp_image_lower_item_to_bottom(j, z)

        # Protect the center with a grey layer:
        z = Lay.clone(z1)
        z.mode = fu.LAYER_MODE_BURN

        pdb.gimp_image_reorder_item(j, z, group, 2)
        pdb.gimp_curves_spline(
            z,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 127, 255, 127]
        )
        Sel.item(z)
        pdb.gimp_selection_shrink(j, d[ok.FRAME_WIDTH])

        sel = cat.save_short_term_sel()

        Sel.invert_clear(z)
        Sel.make_layer_sel(image_layer)
        image_sel = cat.save_short_term_sel()

        z = Lay.clone(z2)
        z.mode = (MULTIPLY, DIFF, DIFF, MULTIPLY, DIFF, DIFF)[x]

        pdb.gimp_image_lower_item_to_bottom(j, z)

        z = Lay.add(j, one.k, parent=group, offset=len(group.layers))

        Lay.color_fill(z, (127, 127, 127))

        n = d[ok.EDGE_MODE]
        z = z1 = Lay.merge_group(group)
        z.mode = Mode.d[n]

        clear_selection(j, z, image_sel, sel)

        if n == "Burn":
            pdb.gimp_drawable_invert(z, 0)

        else:
            pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        if d[ok.POST_BLUR]:
            Lay.copy_visible(z)
            pdb.gimp_image_remove_layer(j, z)

            z = Lay.paste(image_layer)

            Lay.blur(z, d[ok.POST_BLUR])
            clear_selection(j, z, image_sel, sel)

        if d[ok.EMBOSS]:
            Lay.copy_visible(z)

            z2 = Lay.paste(z)
            z = Lay.clone(z2)
            z.mode = fu.LAYER_MODE_OVERLAY

            pdb.plug_in_emboss(
                j, z,
                cat.light_angle,
                cat.elevation,
                em.DEPTH_3,
                em.EMBOSS
            )
            Sel.load(j, sel)

            for i in (z, z1, z2):
                if pdb.gimp_item_is_valid(i):
                    Lay.clear_sel(i, keep_sel=True)

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            Sel.load(j, image_sel)
            Sel.invert_clear(z)

        if d[ok.COLORIZE]:
            Lay.copy_visible(z)

            z1 = z
            z = Lay.paste(z)
            z = Lay.clone(z)
            z.opacity = d[ok.COLORIZE_OPACITY]

            pdb.plug_in_colorify(j, z, d[ok.COLOR])

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            pdb.gimp_image_remove_layer(j, z1)
            clear_selection(j, z, image_sel, sel)

        z.name = Lay.make_name(parent, one.k)
        one.shadow_layer = [image_layer]
        return z
