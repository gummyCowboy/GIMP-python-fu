#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    BackdropStyle as bs,
    Bump as fb,
    Caption as pt,
    Format as ff,
    Frame as fo,
    Fringe as ng,
    Gradient as fg,
    Grid as gr,
    Group as og,
    Mask as ms,
    Plaque as aq,
    Resize as fz,
    Shape as sh,
    Triangle as ft
)
from roller_constant_key import (
    BackdropStyle as by,
    Button as bk,
    Effect as ek,
    Group as gk,
    Option as ok,
    Widget as wk
)
from roller_one import Hat
from roller_one_draw import Draw
from roller_one_tip import Tip

CAPTION_TYPE = (
    ok.CELL_CAPTION_TYPE,
    ok.CUSTOM_CELL_CAPTION_TYPE,
    ok.LAYER_CAPTION_TYPE,
    ok.CUSTOM_CELL_CAPTION_TYPE
)
COMMON_FORMAT = {bk.PLAN, bk.PREVIEW}
DONE = 1
FOR_CELL_SIZE = {ok.COLUMN_WIDTH, ok.GRID_SIZE, ok.ROW_HEIGHT}
FOR_CROP = {ok.CROP_H, ok.CROP_W, ok.CROP_X, ok.CROP_Y}
FOR_CUBISM_GRADIENT = {ok.GRADIENT_TYPE, ok.GRADIENT}
FOR_FIXED = {ok.FIXED_IMAGE_SIZE_H, ok.FIXED_IMAGE_SIZE_W}
FOR_FACTOR = {ok.FACTOR_IMAGE_SIZE_H, ok.FACTOR_IMAGE_SIZE_W}
FOR_GRADIENT = {ok.GRADIENT, ok.GRADIENT_ANGLE, ok.GRADIENT_TYPE}
FOR_INTENSITY = {
    ok.INLAY_BLUR,
    ok.MAKE_OPAQUE,
    ok.OFFSET_X,
    ok.OFFSET_Y,
    ok.SHADOW_BLUR,
    ok.SHADOW_COLOR
}
FOR_NOISE = {ok.SOFTNESS, ok.DETAIL_LEVEL, ok.RANDOM_SEED}
FOR_PAINT_RUSH = {ok.COLOR, ok.COLORIZE_OPACITY}
FOR_RESIZE_LABEL = ok.COVER, ok.FILLED, ok.LOCKED, ok.TRIM
FOR_SHAPE_COUNT = {
    ok.CELL_SHAPE_NORMAL,
    ok.HORZ_COUNT,
    ok.VERT_COUNT
}
FRINGE_TYPE_TOOLTIP = {
    ng.BACKDROP: Tip.FRINGE_ABOUT_BACKDROP,
    ng.GRADIENT: Tip.FRINGE_ABOUT_GRADIENT,
    ng.IMAGE: Tip.FRINGE_ABOUT_IMAGE,
    ng.MASK: Tip.FRINGE_ABOUT_MASK,
    ng.ONE_COLOR: Tip.FRINGE_ABOUT_ONE_COLOR,
    ng.PATTERN: Tip.FRINGE_ABOUT_PATTERN,
    ng.TWO_COLOR:  Tip.FRINGE_ABOUT_TWO_COLOR
}
FRINGE_TYPE = (
    ok.FRINGE_CELL_TYPE,
    ok.FRINGE_CELL_TYPE,
    ok.FRINGE_LAYER_TYPE,
    ok.FRINGE_CELL_TYPE
)
MASK_TYPE_TOOLTIP = {
    ms.CIRCLE: Tip.MASK_CIRCLE,
    ms.CUT_CORNERS: Tip.MASK_CUT_CORNERS,
    ms.DIAMOND: Tip.MASK_DIAMOND,
    ms.HEXAGON_HORIZONTAL: Tip.MASK_HEXAGON,
    ms.HEXAGON_VERTICAL: Tip.MASK_HEXAGON,
    ms.IMAGE: Tip.MASK_IMAGE,
    ms.OCTAGON: Tip.MASK_OCTAGON,
    ms.OCTAGON_ALIGNED: Tip.MASK_OCTAGON,
    ms.OVAL: Tip.MASK_OVAL,
    "None": "",
    ms.RECTANGLE: Tip.MASK_RECTANGLE,
    ms.RHOMBUS: Tip.MASK_RHOMBUS,
    ms.ROUNDED_CORNERS: Tip.MASK_ROUND_CORNERS,
    ms.SQUARE: Tip.MASK_SQUARE,
    ms.TEXT: Tip.MASK_TEXT,
    ft.TRIANGLE_DOWN: Tip.MASK_TRIANGLE_DOWN,
    ft.TRIANGLE_LEFT: Tip.MASK_TRIANGLE_LEFT,
    ft.TRIANGLE_RIGHT: Tip.MASK_TRIANGLE_RIGHT,
    ft.TRIANGLE_UP: Tip.MASK_TRIANGLE_UP
}
NO_GAP = bs.FILLED, bs.COMPOSITION_FRAME
PLAQUE_COLOR = aq.COLOR, aq.NETTING
WITH_MAZE = bs.FILLED, bs.COMPOSITION_FRAME, bs.SCATTERED_MAZES


def do_backdrop_stripe(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments
    """
    if is_update():
        d = init_group(g, *q)
        g = d[ok.STRIPE_TYPE]
        f = d[ok.OPACITY].get_value()
        q = {i for i in d if i != wk.PRESET}

        if not g.get_value():
            q -= {ok.STRIPE_TYPE}

        elif not f:
            q -= {ok.OPACITY}

        else:
            q = set()
            if f == 100.:
                q = {ok.BLUR_BEHIND}
        return set_visibility(d, q)


def do_border(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments
    """
    if is_update():
        d = init_group(g, *q)
        g = d[ok.OPACITY]
        q = {i for i in d}

        if not is_per_cell(g):
            q -= {wk.PRESET}
            x = ff.PARENT_TYPE.index(g.group.parent_type)

            if not d[ok.BORDER_WIDTH].get_value():
                q -= {ok.BORDER_WIDTH}

            elif not d[ok.OPACITY].get_value():
                q -= {ok.OPACITY}
            else:
                q = set()
                if x != ff.PARENT_CELL_INDEX:
                    q = {ok.COMMON_BORDER}

                if x != ff.PARENT_LAYER_INDEX:
                    q.update({ok.OBEY_MARGINS})

                if not d[ok.EMBOSS].get_value():
                    q.update({ok.BUMP_DEPTH})
        return set_visibility(d, q)


def do_bump(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments
    """
    if is_update():
        d = init_group(g, *q)
        g = d[ok.BUMP_TYPE]
        n = g.get_value()
        q = {i for i in d if i != wk.PRESET}

        if n == "None":
            q -= {ok.BUMP_TYPE}

        else:
            q = set()
            if n != fb.NOISE:
                q.update({ok.NOISE})
            else:
                q.update({ok.BLUR_X, ok.BLUR_Y})
        return set_visibility(d, q)


def do_caption(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments
    """
    if is_update():
        d = init_group(g, *q)
        x = ff.PARENT_TYPE.index(d[ok.TEXT].group.parent_type)
        g = d[CAPTION_TYPE[x]]
        q = {i for i in d}

        if not is_per_cell(g):
            n = g.get_value()
            q -= {wk.PRESET}

            if n == "None":
                q -= {g.key}

            elif not d[ok.OPACITY].get_value():
                q -= {g.key, ok.OPACITY}

            elif n == pt.TEXT and not d[ok.TEXT].get_value():
                q -= {g.key, ok.TEXT}
            else:
                q = set()

                if n != pt.TEXT:
                    q.update({ok.TEXT})

                if n != pt.SEQUENCE_NUMBER:
                    q.update({ok.START_NUMBER})

                if n not in (pt.SEQUENCE_NUMBER, pt.IMAGE_NAME):
                    q.update({ok.LEADING_TEXT, ok.TRAILING_TEXT})

                if x != ff.PARENT_LAYER_INDEX:
                    q.update({ok.OBEY_MARGINS, ok.LAYER_CAPTION_TYPE})

                    if x == ff.PARENT_CELL_INDEX:
                        q.update({ok.CUSTOM_CELL_CAPTION_TYPE})
                    else:
                        q.update({ok.CELL_CAPTION_TYPE})
                else:
                    q.update({
                        ok.CELL_CAPTION_TYPE,
                        ok.CUSTOM_CELL_CAPTION_TYPE
                    })
                    if not d[ok.OBEY_MARGINS].get_value():
                        q.update({ok.CLIP_TO_CELL})
        return set_visibility(d, q)


def do_cubism_cover(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments
    """
    if is_update():
        d = init_group(g, *q)

        if not d[ok.OPACITY].get_value():
            do_opacity(g)
        else:
            q = set()
            n = d[ok.BACKDROP_TYPE].get_value()

            if n != bs.GRADIENT:
                q.update(FOR_CUBISM_GRADIENT)

            if n != bs.PLASMA:
                q.update({ok.RANDOM_SEED})
            return set_visibility(d, q)


def do_floor_sample(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments
    """
    if is_update():
        d = init_group(g, *q)

        if not d[ok.OPACITY].get_value():
            do_opacity(g)
        else:
            q = set()
            if not d[ok.INTENSITY].get_value():
                q = FOR_INTENSITY
            return set_visibility(d, q)


def do_frame_over(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments
    """
    if is_update():
        d = init_group(g, *q)
        q = {i for i in d if i != wk.PRESET}

        g = d[ok.FRAME]
        n = g.get_value()

        if n == "None":
            q -= {ok.FRAME}

        elif not d[ok.OPACITY].get_value():
            q -= {ok.OPACITY}

        else:
            q = set()
            n = d[ok.FRAME_STYLE].get_value()

            if n != fo.PLASMA:
                q.update({ok.RANDOM_SEED})

            if n != fo.COLOR:
                q.update({ok.COLOR})

            if n != fo.IMAGE:
                q.update({ok.IMAGE})
            if n != fo.GRADIENT:
                q.update(FOR_GRADIENT)
        return set_visibility(d, q)


def do_fringe(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments
    """
    if is_update():
        d = init_group(g, *q)
        x = ff.PARENT_TYPE.index(d[ok.BUMP].group.parent_type)
        g = d[FRINGE_TYPE[x]]
        q = {i for i in d}

        if not is_per_cell(g):
            n = g.get_value()
            q -= {wk.PRESET}

            if n == "None":
                q -= {g.key}

            else:
                q = set()

                if x == ff.PARENT_LAYER_INDEX:
                    q.update({ok.FRINGE_CELL_TYPE})
                    if n == ng.MASK:
                        q.update({ok.OBEY_MARGINS})
                    if not d[ok.OBEY_MARGINS].get_value():
                        q.update({ok.CLIP_TO_CELL})

                else:
                    q.update({ok.FRINGE_LAYER_TYPE, ok.OBEY_MARGINS})

                if n == ng.MASK:
                    q.update({ok.TRI_SHADOW, ok.BUMP, ok.CLIP_TO_CELL})

                if n != ng.GRADIENT:
                    q.update(FOR_GRADIENT)

                else:
                    # Shape-burst gradients radiate from the center:
                    if d[ok.GRADIENT_TYPE].get_value() in fg.SHAPE_BURST:
                        q.update({ok.GRADIENT_ANGLE})

                if n != ng.IMAGE:
                    q.update({ok.IMAGE})

                if n != ng.ONE_COLOR:
                    q.update({ok.COLOR})

                if n != ng.TWO_COLOR:
                    q.update({ok.COLOR_1, ok.COLOR_2})
                if n != ng.PATTERN:
                    q.update({ok.PATTERN})

        set_visibility(d, q)

        if g.get_value() != "None":
            g.set_tooltip_text(FRINGE_TYPE_TOOLTIP[g.get_value()])

        else:
            g.set_tooltip_text("")
        return DONE


def do_gradient(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.
    """
    if is_update():
        d = init_group(g, *q)

        if ok.OPACITY in d and not d[ok.OPACITY].get_value():
            do_opacity(g)
        else:
            q = set()

            if d[ok.GRADIENT_TYPE].get_value() in fg.SHAPE_BURST:
                q.update(bs.POINT_KEY)
            return set_visibility(d, q)


def do_grid(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments
    """
    if is_update():
        d = init_group(g, *q)
        g = d[ok.GRID_TYPE]
        q = {i for i in d}

        if not is_per_cell(g):
            n = g.get_value()
            q = set()
            n1 = d[ok.CELL_SHAPE_NORMAL].get_value() if n == gr.SHAPE_COUNT \
                else d[ok.CELL_SHAPE].get_value()

            if n not in (gr.CELL_COUNT, gr.CELL_SIZE):
                q = {ok.CELL_SHAPE}

            if n != gr.CELL_COUNT:
                q.update({ok.COLUMN_COUNT, ok.ROW_COUNT})

            if n != gr.CELL_SIZE:
                q.update(FOR_CELL_SIZE)

            if n != gr.SHAPE_COUNT:
                q.update(FOR_SHAPE_COUNT)

            if n1 not in sh.DOUBLE:
                q.update({ok.CELL_SHIFT})

            if n not in (gr.CELL_SIZE, gr.SHAPE_COUNT):
                q.update({ok.PIN_CORNER})

            if n == gr.CELL_SIZE:
                d[ok.GRID_SIZE].update_size()

            # Is a timing issue with the per cell
            # group coming in behind the form group:
            if hasattr(g.group, 'per_cell'):
                g1 = g.group.per_cell

                if (
                    n != gr.CELL_COUNT or
                    d[ok.CELL_SHAPE].get_value() != sh.RECTANGLE
                ):
                    g1.hide()
                else:
                    g1.show()
        return set_visibility(d, q)


def do_image(g, *q):
    """
    Update the group's visibility.

    Call from the image choice window.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments
    """
    if is_update():
        d = init_group(g, *q)
        g = d[ok.IMAGE_SOURCE]
        n = g.get_value()
        q = {i for i in d if i != ok.IMAGE_SOURCE}

        if n != "None":
            q -= {n, ok.AUTOCROP, ok.AS_LAYERS, ok.SLICE}

            if d[ok.AS_LAYERS].get_value():
                q -= {ok.LAYER_ORDER}

            if n == ok.FOLDER:
                q -= {ok.FILTER, ok.FOLDER_ORDER}
            if d[ok.SLICE].get_value():
                q -= {ok.COLUMN_SLICE, ok.ROW_SLICE, ok.SLICE_ORDER}
        return set_visibility(d, q)


def do_image_gradient(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)

        if not d[ok.OPACITY].get_value():
            do_opacity(g)

        else:
            q = set()
            n = d[ok.SAMPLE_VECTOR].get_value()

            if n != bs.HORIZONTAL:
                q.update({ok.START_Y})

            if n != bs.VERTICAL:
                q.update({ok.START_X})

            if n != bs.DIAGONAL:
                q.update({ok.DIAGONAL_ROTATION})
            return set_visibility(d, q)


def do_margin(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)
        g = d[ok.FIXED_TOP]
        q = {i for i in d} if is_per_cell(g) else set()
        return set_visibility(d, q)


def do_mask(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments
    """
    if is_update():
        d = init_group(g, *q)
        g = d[ok.MASK_TYPE]
        q = {i for i in d}

        if not is_per_cell(g):
            g1 = d[ok.TEXT]
            g2 = d[ok.IMAGE]
            n = g.get_value()
            tip = MASK_TYPE_TOOLTIP[n]
            q -= {ok.MASK_TYPE, wk.PRESET}

            if n == ms.TEXT and not g1.get_value():
                q -= {ok.TEXT}

            elif n == ms.IMAGE and g2.get_value()[ok.IMAGE_SOURCE] == "None":
                q -= {ok.IMAGE}

            elif n == "None":
                pass

            else:
                q = set()

                if n != ms.TEXT:
                    q.update({ok.TEXT, ok.FONT})

                if n != ms.IMAGE:
                    q.update({ok.IMAGE})
                if not d[ok.FEATHER].get_value():
                    q.update({ok.STEPS})
            if n in ms.TYPE:
                g.set_tooltip_text(tip)
        return set_visibility(d, q)


def do_maze_mirror(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)
        q = set()

        if not d[ok.NOISE_OPACITY].get_value():
            q.update(FOR_NOISE)

        maze = d[ok.MAZE_TYPE].get_value()
        gap = d[ok.GAP_TYPE].get_value()

        if maze not in WITH_MAZE:
            q.update({ok.STOP_LENGTH, ok.MAZE_DIRECTION})

        if maze in NO_GAP:
            q.update({ok.CELL_GAP, ok.GAP_TYPE, ok.SCATTER_COUNT})

        if maze not in NO_GAP:
            if gap == bs.RANDOM:
                q.update({ok.CELL_GAP})
        return set_visibility(d, q)


def do_noise(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)
        q = set()

        if not d[ok.NOISE_OPACITY].get_value():
            q.update(FOR_NOISE)
        return set_visibility(d, q)


def do_noise_mode(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)

        if ok.OPACITY in d and not d[ok.OPACITY].get_value():
            do_opacity(g)
        else:
            q = set()

            if d[ok.NOISE_MODE].get_value() == "None":
                q.update({ok.NOISE_OPACITY, ok.RANDOM_SEED})

            else:
                if not d[ok.NOISE_OPACITY].get_value():
                    q.update({ok.RANDOM_SEED})
            return set_visibility(d, q)


def do_opacity(g, *q):
    """
    Update the group's visibility based on the opacity widget.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)
        q = {i for i in d if i not in (ok.OPACITY, wk.PRESET)}

        if ok.OPACITY in d:
            if d[ok.OPACITY].get_value():
                q = set()

        else:
            q = set()
        return set_visibility(d, q)


def do_paint_rush(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)
        q = set()

        if not d[ok.COLORIZE].get_value():
            q.update(FOR_PAINT_RUSH)
        return set_visibility(d, q)


def do_per_cell(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    a: gtk.gdk.Event
        ignore

    q: tuple
        expose event arguments
    """
    if is_update():
        g = g.group.d[ok.PER_CELL]

        init_group(g, *q)

        if g.check_button.get_value():
            g.button.show()

        else:
            g.button.hide()

        # Update the source group:
        path = g.group.path
        source_key = og.SOURCE_GROUP_KEY[path[-1]]
        path = path[:3] + og.PER_CELL_DEPENDENT[path[-1]]
        d = Hat.cat.group_dict[path].d
        g = [d[i] for i in d][0]
        EXPOSE[source_key](g)


def do_place(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)
        q = {i for i in d}

        if not is_per_cell(g):
            q -= {wk.PRESET}
            e = d[ok.IMAGE].get_value()

            # 'e' is None during init:
            if e and e[ok.IMAGE_SOURCE] == "None":
                q -= {ok.IMAGE}
            elif not d[ok.OPACITY].get_value():
                q -= {ok.OPACITY}
            else:
                q = set()
        return set_visibility(d, q)


def do_plaque(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)
        g = d[ok.PLAQUE_TYPE]
        q = {i for i in d}
        if not is_per_cell(g):
            n = g.get_value()
            q -= {wk.PRESET}

            if n == "None":
                q -= {ok.PLAQUE_TYPE}

            elif not d[ok.OPACITY].get_value():
                q -= {ok.OPACITY}

            elif not d[ok.INTENSITY].get_value() and n == aq.SHADOW:
                q -= {ok.PLAQUE_TYPE, ok.INTENSITY}
            else:
                e = d[ok.IMAGE].get_value()

                if n == ok.IMAGE and e and e[ok.IMAGE_SOURCE] == "None":
                    q -= {ok.PLAQUE_TYPE, ok.IMAGE}
                else:
                    _type = d[ok.BUMP].group.parent_type
                    x = ff.PARENT_TYPE.index(_type)
                    q = set()

                    if x != ff.PARENT_LAYER_INDEX:
                        q.update({ok.OBEY_MARGINS})

                    if n != aq.IMAGE:
                        q.update({ok.IMAGE})

                    if n != aq.NETTING:
                        q.update({ok.NET_LINE_WIDTH, ok.NET_LINE_SPACING})

                    if n not in PLAQUE_COLOR:
                        q.update({ok.COLOR})

                    if n != aq.PATTERN:
                        q.update({ok.PATTERN})

                    if not d[ok.FEATHER].get_value():
                        q.update({ok.STEPS})

                    if n != aq.GRADIENT:
                        q.update(FOR_GRADIENT)

                    else:
                        # Shape-burst gradients radiate from the center:
                        if (
                            d[ok.GRADIENT_TYPE].get_value()
                            in fg.SHAPE_BURST
                        ):
                            q.update({ok.GRADIENT_ANGLE})

                    if n != aq.PLASMA:
                        q.update({ok.RANDOM_SEED})

                    if n not in (aq.PATTERN, aq.PLASMA, aq.IMAGE):
                        q.update({ok.BLUR})

                    if n != aq.SHADOW:
                        q.update({ok.INTENSITY})
                        q.update(FOR_INTENSITY)
                    else:
                        if not d[ok.INTENSITY].get_value():
                            q.update(FOR_INTENSITY)
        set_visibility(d, q)


def do_rectangle(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)
        d[ok.RECTANGLE_SPECS].update_specs()


def do_resize(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)
        g = d[ok.RESIZE_TYPE]
        q = {i for i in d if i != ok.RESIZE_TYPE}
        n = g.get_value()

        if n in FOR_RESIZE_LABEL:
            q -= {n}

        elif n == fz.CROP:
            q -= FOR_CROP

        elif n == fz.FIXED:
            q -= FOR_FIXED

        elif n == fz.FACTOR:
            q -= FOR_FACTOR
        return set_visibility(d, q)


def do_shadow_intensity(g, *q):
    """
    Update the group's visibility.

    g: object
        Has a group attribute.

    q: tuple
        expose event arguments

    Return: Done or None
        for GTK
    """
    if is_update():
        d = init_group(g, *q)

        if ok.OPACITY in d and not d[ok.OPACITY].get_value():
            do_opacity(g)
        else:
            q = set()

            if not d[ok.INTENSITY].get_value():
                q.update(FOR_INTENSITY)
            return set_visibility(d, q)


def init_group(g, *q):
    """
    Get the group's widget dictionary.
    Remove the the expose connection.

    g: object
        Sent by expose or change.

    q: tuple
        expose event arguments

    Return: dict
        of group widgets
    """
    # The expose event subscription has an additional parameter, 'q'.
    # The change subscriptions do not have 'q'.
    # The first parameter of 'q' is the expose event.
    # The second parameter is the subscriber of the expose-event:
    if q:
        a = q[1]
        if a.expose_handle is not None:
            a.disconnect(a.expose_handle)
            a.expose_handle = None
    else:
        # Update the preview button's sensitivity:
        a = g.group

        if a.preview_button:
            a.preview_button.set_sensitive(1)
        if a.plan_button:
            a.plan_button.set_sensitive(1)
    return g.group.d


def is_per_cell(g):
    """
    Determine if a per cell group is in per cell mode.

    Return: bool or None
        Is true if the group is in per cell mode.
    """
    a = g.group.vbox
    if hasattr(a, 'per_cell_group'):
        return a.per_cell_group.check_button.get_value()


def is_update():
    return not Draw.load_count or Draw.preset_load_count


def set_visibility(d, q):
    """
    Set widget visibility for an option group.

    d: dict
        of option group

    q: list
        of hidden widget

    Return: int
        Is a done flag for GTK.
    """
    g = None
    q1 = {i for i in d} - q
    q1.update(COMMON_FORMAT)

    for i, g in d.items():
        g.show() if i in q1 else g.hide()
    if g:
        return g.win.resize()


# Use to connect an option group with an expose event handler:
EXPOSE = {
    by.CUBISM_COVER: do_cubism_cover,
    by.FLOOR_SAMPLE: do_floor_sample,
    by.GRADIENT_FILL: do_gradient,
    by.IMAGE_GRADIENT: do_image_gradient,
    ek.BORDER_LINE: do_noise,
    ek.BRUSH_PUNCH: do_noise,
    ek.CERAMIC_CHIP: do_noise,
    ek.CIRCLE_PUNCH: do_noise,
    ek.COLOR_PIPE:  do_noise_mode,
    ek.CORNER_TAPE: do_shadow_intensity,
    ek.CUTOUT_PLATE: do_noise,
    ek.FRAME_OVER: do_frame_over,
    ek.GRADIENT_LEVEL: do_noise_mode,
    ek.INNER_SHADOW: do_shadow_intensity,
    ek.LINE_FASHION: do_noise,
    ek.MAZE_MIRROR: do_maze_mirror,
    ek.PAINT_RUSH: do_paint_rush,
    ek.RAD_WAVE: do_noise,
    ek.RAISED_MAZE: do_noise,
    ek.SHADOW_1: do_shadow_intensity,
    ek.SHADOW_2: do_shadow_intensity,
    ek.SQUARE_PUNCH: do_noise,
    ek.STAINED_GLASS: do_noise,
    ek.WIRE_FENCE: do_noise,
    gk.BACKGROUND_STRIPE: do_backdrop_stripe,
    gk.BUMP: do_bump,
    gk.CELL_BORDER: do_border,
    gk.CELL_CAPTION: do_caption,
    gk.CELL_FRINGE: do_fringe,
    gk.CELL_IMAGE_MASK: do_mask,
    gk.CELL_IMAGE_PLACE: do_place,
    gk.CELL_MARGIN: do_margin,
    gk.CELL_PLAQUE: do_plaque,
    gk.CLEAR_FRAME_BEHIND: init_group,
    gk.COLOR_BOARD_BEHIND: init_group,
    gk.CUSTOM_CELL_BORDER: do_border,
    gk.CUSTOM_CELL_CAPTION: do_caption,
    gk.CUSTOM_CELL_FRINGE: do_fringe,
    gk.CUSTOM_CELL_IMAGE_MASK: do_mask,
    gk.CUSTOM_CELL_IMAGE_PLACE: do_place,
    gk.CUSTOM_CELL_MARGIN: init_group,
    gk.CUSTOM_CELL_PLAQUE: do_plaque,
    gk.GLASS_REVEAL_BEHIND: init_group,
    gk.GRADIENT_LEVEL_BEHIND: init_group,
    gk.GRADIENT_LIGHT: do_gradient,
    gk.GRID: do_grid,
    gk.IMAGE_CHOICE: do_image,
    gk.LAYER_CAPTION: do_caption,
    gk.LAYER_BORDER: do_border,
    gk.LAYER_FRINGE: do_fringe,
    gk.LAYER_MARGIN: init_group,
    gk.LAYER_PLAQUE: do_plaque,
    gk.PER_CELL_BORDER: do_per_cell,
    gk.PER_CELL_FRINGE: do_per_cell,
    gk.PER_CELL_CAPTION: do_per_cell,
    gk.PER_CELL_GRID: do_per_cell,
    gk.PER_CELL_IMAGE_MASK: do_per_cell,
    gk.PER_CELL_IMAGE_PLACE: do_per_cell,
    gk.PER_CELL_MARGIN: do_per_cell,
    gk.PER_CELL_PLAQUE: do_per_cell,
    gk.RECTANGLE: do_rectangle,
    gk.RESIZE_METHOD: do_resize,
    gk.STAINED_GLASS_BEHIND: init_group
}
