#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import (
    Group as gk,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_grid import Grid
from roller_one_extract import Form, Path
from roller_one import Hat, One
from roller_widget import Widget
import gtk


def do_render_size():
    """
    Update the render size.

    Return: tuple
        global dict, width, height of render
    """
    d = Path.get_dict_from_path(sk.GLOBAL)
    w, h = d[ok.RENDER_WIDTH], d[ok.RENDER_HEIGHT]
    Hat.cat.render.set_size(w, h)
    return d, w, h


def update_cell_table(path):
    """
    The cell margins need an up-to-date Grid.

    path: tuple
        of step

    Return: Grid
        Has cell table.
    """
    return Grid(
        One(
            layer_margin=Path.get_layer_margin(path),
            path=path,
            d=Path.get_grid_from_path(path)
        )
    )


class Label(Widget):
    """Is a custom GTK Label."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.Label(d[wk.TEXT])
        d[wk.ALIGN] = d[wk.ALIGN] if wk.ALIGN in d else (0, 0, 0, 0)

        Widget.__init__(self, g, **d)
        self.add(g)

    def destroy(self):
        """Destroy the widget and sub-widgets."""
        self.label.destroy()
        self.destroy()

    def get_value(self):
        """
        Is a Widget preset template function.

        a: undefined
            not used
        """
        return None

    def set_label_value(self, a):
        """
        Change the display value of the label.

        a: string
            the new display value
        """
        if isinstance(a, str):
            self.widget.set_label(a)

    def set_value(self, a):
        """
        Is a Widget preset template function.

        a: undefined
            not used
        """
        return


class GridLabel(Label):
    """Is a Label for displaying row and column counts."""

    TEMPLATE = "Row: {}, Column: {}"

    def __init__(self, **d):
        """
        Initialize the Label widget.

        d: dict
            Has init values for Widget.
        """
        d[wk.TEXT] = GridLabel.TEMPLATE.format(0, 0)
        d[wk.ALIGN] = 0, 0, 1, 1

        Label.__init__(self, **d)

        self._grid = None
        self._path = self.group.path
        self._global_d = {}
        self._layer_margin = {}
        self._grid_d = {}
        self._d = {}
        self.container.connect('expose-event', self._on_expose)

    def _on_expose(self, *_):
        """Respond to an expose event."""
        self.update_size()

    def update_size(self):
        """Update the label after a change."""
        d = self.group.preset.get_value()
        d[ok.PER_CELL] = []
        e = do_render_size()[0]
        d1 = Path.get_layer_margin(self._path)

        if d != self._d or self._global_d != e or self._layer_margin != d1:
            self._grid = update_cell_table(self._path)

        if self._grid:
            r, c = self._grid.division
            self.set_label_value(GridLabel.TEMPLATE.format(r, c))

        self._d = d
        self._layer_margin = d1
        self._global_d = e


class MarginLabel(Label):
    """Is a Label for displaying margin size."""

    TEMPLATE = "Top: {}, Bottom: {}, Left: {}, Right: {}"

    def __init__(self, **d):
        """
        Initialize the Label widget.

        d: dict
            Has init values for Widget.
        """
        d[wk.TEXT] = MarginLabel.TEMPLATE.format(0, 0, 0, 0)
        d[wk.ALIGN] = 0, 0, 1, 1

        Label.__init__(self, **d)

        self._grid = None
        self._path = self.group.path
        k = self.group.group_key
        self.is_layer = k == gk.LAYER_MARGIN
        self.is_cell = k == gk.CELL_MARGIN
        self.is_custom = k == gk.CUSTOM_CELL_MARGIN
        self._global_d = {}
        self._grid_d = {}
        self._d = {}
        self.container.connect('expose-event', self._on_expose)

    def set_caption_type(self, k, path):
        """
        Set the margin caption type.

        k: string
            group key

        path: tuple
            group path of margin caption type
        """
        self.is_layer = k == gk.LAYER_MARGIN
        self.is_cell = k == gk.CELL_MARGIN
        self.is_custom = k == gk.CUSTOM_CELL_MARGIN
        self._path = path

    def _on_expose(self, *_):
        """Respond to an expose event."""
        self.update_size()

    def update_size(self, grid=None, r=0, c=0):
        """
        Update the label after a change.

        grid: Grid
            Is the grid from the per cell editor.

        r, c: int
            cell index
        """
        d = self.group.preset.get_value()
        d[ok.PER_CELL] = []
        e, w, h = do_render_size()

        if grid:
            if d != self._d:
                grid.calc_pockets(d)
            w, h = grid.get_merge_cell_rect(r, c).size

        elif self.is_cell:
            grid_d = Path.get_grid_from_path(self._path)

            if grid_d != self._grid_d:
                self._grid = update_cell_table(self._path)
                self._grid_d = grid_d

            if d != self._d and self._grid:
                self._grid.calc_pockets(d)
            if self._grid:
                w, h = self._grid.get_common_cell_size(d)[1]

        elif self.is_custom:
            d1 = Path.get_rectangle_dict(self._path)
            w, h = Form.get_custom_cell_rect(d1).size

        self.set_label_value(
            MarginLabel.TEMPLATE.format(*Form.combine_margin(d, w, h))
        )

        self._d = d
        self._global_d = e


class RectangleLabel(Label):
    """
    Is a Label for displaying a custom cell rectangle's position and size.
    """

    TEMPLATE = "X: {}, Y: {}, Width: {}, Height: {}"

    def __init__(self, **d):
        """
        Initialize the Label widget.

        d: dict
            Has init values for Widget.
        """
        d[wk.TEXT] = RectangleLabel.TEMPLATE.format(0, 0, 0, 0)
        d[wk.ALIGN] = 0, 0, 1, 1

        Label.__init__(self, **d)

        self._path = self.group.path
        self.container.connect('expose-event', self._on_expose)

    def _on_expose(self, *_):
        """Respond to an expose event."""
        self.update_specs()

    def update_specs(self):
        """Update the label after a change."""
        do_render_size()

        d = self.group.preset.get_value()
        a = Form.get_custom_cell_rect(d)
        self.set_label_value(
            RectangleLabel.TEMPLATE.format(
                a.x, a.y,
                a.w, a.h
            )
        )
