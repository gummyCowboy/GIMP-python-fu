#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy
from roller_constant_key import Model as md, Option as ok
from roller_effect_border_line import BorderLine
from roller_render_hub import RenderHub
from roller_one import Hat
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb

CUSTOM = fy.CUSTOM_CELL


def do_job(one, sel, _):
    """
    Draw the brush frame by making a selection from the brush.

    one: One
        with options

    sel: Selection
        of frame

    _: Selection
        not used

    Return: state of image
        the selection for the frame
    """
    cat = Hat.cat
    j = cat.render.image
    z = Lay.add(j, 'path', parent=one.parent)

    if one.context == md.TABLE:
        process_grid(j, z, one)

    else:
        # custom cell:
        Hat.cat.join_selection(one.model_name, CUSTOM, CUSTOM)
        process_image(j, z, one)

    # Select the usable new material:
    Sel.load(j, sel)
    Sel.item(z, option=fu.CHANNEL_OP_ADD)
    pdb.gimp_image_remove_layer(j, z)


def process_grid(j, z, one):
    """
    Do effect for each image in the cell grid.

    j: GIMP image
        Is render.

    z: layer
        to receive effect

    one: One
        Has options.
    """
    # Do one image at a time:
    d = one.grid.grid_d
    is_merge_cell = one.grid.is_merge_cell
    s = 1
    for r in range(one.r):
        for c in range(one.c):
            if is_merge_cell:
                s = d[ok.PER_CELL][r][c]

            # Is it a dependent cell?
            if s != (-1, -1):
                Hat.cat.join_selection(one.model_name, r, c)
                process_image(j, z, one)


def process_image(j, z, one):
    """
    Do the effect for an image.

    j: GIMP image
        Is render.

    z: layer
        to receive effect

    one: One
        Has options.
    """
    if Sel.is_sel(j):
        d = one.d

        Sel.grow(j, d[ok.FRAME_WIDTH] + 3, d[ok.FRAME_TYPE])
        pdb.plug_in_sel2path(j, z)

        stroke = j.active_vectors.strokes[0]

        pdb.gimp_selection_none(j)
        RenderHub.brush_stroke_on_stroke(
            z,
            d[ok.BRUSH],
            d[ok.BRUSH_SIZE],
            stroke,
            d[ok.BRUSH_SPACING]
        )


class BrushPunch:
    """Create a unique image frames using brush stroke selections."""

    @staticmethod
    def do(one):
        """
        Do the Brush Punch image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Brush Punch
        """
        return BorderLine.do(one, framer=do_job)
