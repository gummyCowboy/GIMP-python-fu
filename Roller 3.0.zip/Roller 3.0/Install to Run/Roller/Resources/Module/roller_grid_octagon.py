#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_one import Rect
from roller_one_extract import Shape


class GridOctagon:
    """
    Calculate the coordinates and the size of cells.

    The cells are octagon shaped.
    """

    def __init__(self, one):
        """
        Calculate cell size and octagon shape.

        one: One
            Has init values.
        """
        self.grid = one.grid
        self.grid_type = one.grid_type
        row, column = self.row, self.column = one.r, one.c
        table = self.grid.table
        s = one.layer_space
        x, y = one.offset

        # intersect points:
        q_x = self.q_x = []
        q_y = self.q_y = []

        if one.grid_type == gr.CELL_SIZE:
            w, h = one.column_width, one.row_height
            s1 = w * column, h * row
            w, h = w / 1., h / 1.
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        elif one.grid_type == gr.SHAPE_COUNT:
            w = s[0] // column
            h = s[1] // row
            w = min(w, h)
            s1 = w * column, w * row
            w, h = w, w
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            w = s[0] / 1. / column
            h = s[1] / 1. / row

        offset = x, y

        if self.grid.cell_shape == sh.OCTAGON:
            is_align = False
            self._calc_octagon_intersect(x, y, w, h)
            q = Shape.calc_octagon_offset(w, h)

        else:
            is_align = True
            self._calc_align_octagon_intersect(x, y, w, h)
            q = Shape.calc_octagon_aligned_offset(w, h)

        self.is_align = is_align

        s1 = s[0] + offset[0], s[1] + offset[1]

        # Compose points:
        for r in range(row):
            for c in range(column):
                x, y = position = int(q_x[c]), int(q_y[r])
                size = int(w), int(h)

                if size[0] > s1[0] or size[1] > s1[1]:
                    position = size = 0, 0

                # 'cell' is the cell rectangle before margins:
                table[r][c].cell = Rect(position, size)
                if size[0]:
                    # If there are no margins, then do shape:
                    if is_align:
                        q1 = Shape.calc_octagon_aligned_shape(
                            x, y, w, h, q
                        )

                    else:
                        q1 = Shape.calc_octagon_shape(x, y, w, h, q)
                    table[r][c].plaque = q1

    def _calc_align_octagon_intersect(self, x, y, w, h):
        """
        Calculate the intersect coordinates for an aligned octagon.

        x, y, w, h: int
            Defines cell rectangle.
        """
        q = self.q_x

        for c in range(self.column):
            q.append(x)
            x += w

        q = self.q_y
        for r in range(self.row):
            q.append(y)
            y += h

    def _calc_octagon_intersect(self, x, y, w, h):
        """
        Calculate the intersect coordinates for an octagon.

        x, y, w, h: int
            Defines cell rectangle.
        """
        q = self.q_x

        for c in range(self.column):
            q.append(x)
            x += w

        q = self.q_y
        for r in range(self.row):
            q.append(y)
            y += h

    def calc_shape_per_cell(self, _):
        """
        Calculate the shape of the diamond from
        the pocket size on a per cell basis.

        Is part of the Grid template.

        _: dict
            of grid
            not used
        """
        self.calc_shape_with_pocket()

    def calc_shape_with_pocket(self):
        """
        Calculate the shape of the octagon from
        the pocket size using intersects.

        Is part of the Grid template.
        """
        is_normal = self.grid_type == gr.SHAPE_COUNT
        for r in range(self.row):
            for c in range(self.column):
                rect = self.grid.table[r][c].pocket
                w, h = rect.w, rect.h
                x, y = rect.x, rect.y,
                if w and h:
                    if is_normal:
                        # Calculate a square for the octagon:
                        w1 = min(w, h)
                        x = x + (w - w1) // 2
                        y = y + (h - w1) // 2
                        w = h = w1

                    if self.is_align:
                        q = Shape.calc_octagon_aligned_shape(
                            x, y,
                            w, h,
                            Shape.calc_octagon_aligned_offset(w, h)
                        )

                    else:
                        q = Shape.calc_octagon_shape(
                            x, y,
                            w, h,
                            Shape.calc_octagon_offset(w, h)
                        )
                    self.grid.table[r][c].shape = q
