#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Bump as fb,
    Format as ff,
    Image as fi,
    Resize as fz
)
from roller_constant_key import (
    BackdropStyle as by,
    Effect as ek,
    Option as ok,
    Step as sk
)


class Tip:
    """Has tooltip text strings."""

    BACKDROP_INFLUENCE = \
        " Is the amount to apply to the backdrop-style or image. "

    BASE_BRUSH = \
        " Brush:\n" \
        "\tBrush:\t\t\t{} \n" \
        "\tSize:\t\t\t{} \n" \
        "\tSpacing:\t\t\t{} \n" \
        "\tOpacity:\t\t\t{} \n" \
        "\tHardness:\t\t{} \n" \
        "\tAngle:\t\t\t{} "

    BASE_BY_COUNT = \
        " Row Count:\t\t{} \n" \
        " Column Count:\t{} \n" \
        " Shape:\t\t\t{} "

    BASE_BY_COUNT_SHIFT = \
        " Row Count:\t\t{} \n" \
        " Column Count:\t{} \n" \
        " Shape:\t\t\t{} \n" \
        " Shift:\t\t\t{} "

    BASE_CLOTH_BUMP = \
        " Bump:\n" \
        "\tBump Type:\t\t{} \n" \
        "\tDepth:\t\t\t{} \n" \
        "\tBlur X:\t\t\t{} \n" \
        "\tBlur Y:\t\t\t{} "

    BASE_FIXED_SIZE = \
        " Row Height:\t\t{} \n" \
        " Column Width:\t{} \n" \
        " Table Position:\t{} \n" \
        " Shape:\t\t\t{} "

    BASE_FIXED_SIZE_SHIFT = \
        " Row Height:\t\t{} \n" \
        " Column Width:\t{} \n" \
        " Table Position:\t{} \n" \
        " Shape:\t\t\t{} \n" \
        " Shift:\t\t\t{} "

    BASE_IMAGE_LAYERS = \
        " {} \n" \
        " As Layers:\t\t{} \n" \
        " Auto-crop:\t\t{} \n" \
        " Layer Order:\t\t{} "

    BASE_MARGIN = \
        " Fixed-Value Margins: \n" \
        "\tTop:\t\t\t{} \n" \
        "\tBottom:\t\t\t{} \n" \
        "\tLeft:\t\t\t{} \n" \
        "\tRight:\t\t\t{} \n" \
        " Factor-Size Margins: \n" \
        "\tTop:\t\t\t{} \n" \
        "\tBottom:\t\t\t{} \n" \
        "\tLeft:\t\t\t{} \n" \
        "\tRight:\t\t\t{} "

    BASE_INNER_SHADOW = \
        " {}: \n" \
        "\tInlay Blur:\t\t{} \n" \
        "\tIntensity:\t\t{} \n" \
        "\tShadow Color:\n" \
        "\t\tRed:\t\t{}\n" \
        "\t\tGreen:\t\t{} \n" \
        "\t\tBlue:\t\t{} "

    BASE_NOISE_BUMP = \
        " Bump:\n" \
        "\tBump Type:\t\t{} \n" \
        "\tBump Depth:\t\t{} \n" \
        "\tNoise:\t\t\t{} "

    BASE_SHADOW = \
        " {}: \n" \
        "\tShadow Blur:\t\t{} \n" \
        "\tIntensity:\t\t{} \n" \
        "\tOffset X:\t\t\t{} \n" \
        "\tOffset Y:\t\t\t{} \n" \
        "\tShadow Color:\n" \
        "\t\tRed:\t\t{}\n" \
        "\t\tGreen:\t\t{} \n" \
        "\t\tBlue:\t\t{}\n" \
        "\tMake Opaque:\t{} "

    BASE_SHAPE_COUNT = \
        " Row Count:\t\t{} \n" \
        " Column Count:\t{} \n" \
        " Table Position:\t{} \n" \
        " Shape:\t\t\t{} "

    BASE_SHAPE_COUNT_SHIFT = \
        " Row Count:\t\t{} \n" \
        " Column Count:\t{} \n" \
        " Table Position:\t{} \n" \
        " Shape:\t\t\t{} \n" \
        " Shift:\t\t\t{} "

    BASE_STRIPE = \
        " Stripe:\n" \
        "\tOpacity:\t\t\t{} \n" \
        "\tHeight:\t\t\t{} \n" \
        "\tBlur Behind:\t\t{} \n" \
        "\tColor:\n" \
        "\t\tRed:\t\t{}\n" \
        "\t\tGreen:\t\t{} \n" \
        "\t\tBlue:\t\t{} "

    BLEND = " Use a higher value to create less textural variation. "
    CAPTION_IMAGE_NAME = \
        " Has Image?\t\t\t{}\n" \
        " Type:\t\t\t\t{} \n" \
        " Justification:\t\t\t{} \n" \
        " Leading Text:\t\t{} \n" \
        " Trailing Text:\t\t\t{} \n" \
        " Font Size:\t\t\t{}\n" \
        " Opacity:\t\t\t{} \n" \
        " Font:\t\t\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t\t{} \n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Clip to Cell:\t\t\t{} "

    CAPTION_LEADING_TEXT = \
        " Is a prefix to a sequenced number or an image name. "

    CAPTION_START_NUMBER = \
        " Is the first number to be displayed in a numeric sequence, \n" \
        " where each successive image increases this number by one. "

    CAPTION = \
        " Has Image?\t\t\t{}\n" \
        " Type:\t\t\t\t{}\n" \
        " Justification:\t\t\t{} \n" \
        " Text:\t\t\t\t{} \n" \
        " Font Size:\t\t\t{}\n" \
        " Opacity:\t\t\t{} \n" \
        " Font:\t\t\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t\t{}\n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{}\n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Clip to Cell:\t\t\t{} "

    CAPTION_TRAILING_TEXT = \
        " Is a suffix to a sequenced number or an image name. "

    CELL_BORDER = \
        " Has Image?\t\t{} \n" \
        " Border Width:\t{} \n" \
        " Opacity:\t\t{} \n" \
        " Border Blur:\t\t{} \n" \
        " Bump Depth:\t{} \n" \
        " Emboss?\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t{}\n" \
        "\tGreen:\t\t{} \n" \
        "\tBlue:\t\t{} "

    CELL_GAP = " Is the number of sequenced-cells between mazes. "
    CLIP_TO_CELL = \
        " When selected, the material is contained within boundaries. \n" \
        " The boundaries are defined by a layer or cell. "

    CLOSE_FILE = \
        " If selected, any open images will be closed \n" \
        " after their first use, freeing up the memory. The \n" \
        " downside is that if the image is referenced by \n" \
        " another cell, the image will be reloaded which will \n" \
        " take a lot longer than using an already open image. "

    COLUMN_1 = \
        " Modifies the number of slats to draw \n" \
        " for the lower layer of the grate. "

    COLUMN_2 = \
        " Modifies the number of slats to draw \n" \
        " for the upper layers of the grate. "

    DECO = \
        " Is amount to apply to decoration \n " \
        " of type plaque, fringe, and border. "

    DELETE_PLANS = \
        " When selected, the plans folder is removed after a render. "

    DIAGONAL_ROTATION = \
        " The direction angle is mirrored \n" \
        " in the opposite direction. The result \n" \
        " is a vector that goes through the center, " \
        " starting and ending at the image bounds. "

    ELEVATION = \
        " Used by emboss functions in a render. It \n" \
        " determines the midtone lightness of an emboss. \n" \
        " A lower elevation is darker than a higher elevation. "

    END_COORDINATE = \
        " The end coordinate is a factor of the layer size \n" \
        " value. The coordinates will scale with the render size. "

    FEATHER = \
        " The initial feather is this number divided \n" \
        " by steps. Subsequent steps add the initial \n" \
        " value to the feather. This value becomes the \n" \
        " feather amount applied on the last step. "

    GRID_BOUNDS = \
        " When selected, the layer boundaries\n" \
        " are contained within the layer margins. "

    FACTOR_POSITION_H = \
        " The value is multiplied by the height of the render. "

    FACTOR_POSITION_W = \
        " The value is multiplied by the width of the render. "

    FACTOR_X = \
        " The value is multiplied by the width of the context. \n" \
        " For layers, the width is the render width. \n " \
        " For cells, the width is the cell width. "

    FACTOR_Y = \
        " The value is multiplied by the height of the context. \n" \
        " For layers, the height is the render height. \n" \
        " For cells, the height is the cell height. "

    FIXED_POSITION_X = \
        " The fixed values are added to the factored values to get \n" \
        " a cell rectangle. For a non-rectangular cell shape, the \n" \
        " cell rectangle defines the shape's bounds."

    FRAME = \
        " Are 'png'-type images found in Roller's Frame folder. \n" \
        " A frame is molded to fit a cell's image rectangle. "

    FRAME_STYLE_AS_IS = " As Is does not modify the frame material. "
    FRAME_STYLE_COLOR = " Color paints the frame material with a color. "
    FRAME_STYLE_GRADIENT = \
        " Gradient paints the frame material with a gradient \n" \
        " that is drawn over the image rectangle. "

    FRAME_STYLE_IMAGE = \
        " Image paints the frame material with an image. \n" \
        " The image paint is molded to fit the cell's image rectangle. "

    FRAME_STYLE_PLASMA = \
        " Plasma paints the frame with a plasma effect. "

    FREE_CELL_POSITION = \
        " The fixed-values and the computed factor of the layer \n" \
        " size values are combined to set the cell location and size. \n" \
        " With the range of settings, It is possible that the cell and \n" \
        " its image will not be visible in the render. \n" \
        " In any event, the enforced minimum image size is 1 x 1 pixels. "

    FRINGE_ABOUT_BACKDROP = \
        " A copy of the backdrop material is painted over the fringe \n" \
        " brush. The copied backdrop material's rectangle is not resized. "

    FRINGE_ABOUT_GRADIENT = \
        " A gradient is applied over the fringe \n" \
        " rectangular bounds. The fringe brush-strokes \n" \
        " are then painted with the overlapping gradient. "

    FRINGE_ABOUT_IMAGE = \
        " An image is sized to the fringe rectangular bounds. The fringe \n" \
        " brush-strokes are then painted with the overlapping image. "

    FRINGE_ABOUT_MASK = \
        " The mask is made from fringe brush-strokes that are \n" \
        " cut into a required plaque. If there is no plaque, then \n" \
        " the fringe-mask will not produce anything. "

    FRINGE_ABOUT_ONE_COLOR = \
        " The fringe brush-strokes are painted with a single color. "

    FRINGE_ABOUT_PATTERN = \
        " The fringe rectangular bounds are filled with \n" \
        " a pattern. The fringe brush-strokes are then \n" \
        " painted with the overlapping pattern. "

    FRINGE_ABOUT_TWO_COLOR = \
        " The fringe brush-strokes are painted with alternating colors. "

    FRINGE_CONTRACT = \
        " At zero, the fringe is drawn on the edge \n" \
        " of a cell. With contract, the edge moves \n" \
        " inward to the center of the cell. To get the \n" \
        " whole brush tip inside the cell, try setting \n" \
        " the contract value to half of the brush size. "

    FRINGE_GRADIENT = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Gradient Type:\t\t{} \n" \
        " Gradient Angle:\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Gradient:\t\t\t{} \n" \
        " Clip to Cell:\t\t\t{} "

    FRINGE_IMAGE = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Image:\t\t\t\t{} \n" \
        " Clip to Cell:\t\t\t{} "

    FRINGE_MASK = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        "{}"

    FRINGE_ONE_COLOR = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Color:\n" \
        "\tRed:\t\t\t{}\n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{}\n" \
        " Clip to Cell:\t\t\t{} "

    FRINGE_PATTERN = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Pattern:\t\t\t\t{} \n" \
        " Clip to Cell:\t\t\t{} "

    FRINGE_TWO_COLOR = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Color #1:\n" \
        "\tRed:\t\t\t{}\n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{}\n" \
        " Color #2:\n" \
        "\tRed:\t\t\t{}\n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{}\n" \
        " Clip to Cell:\t\t\t{} "

    GRID_NORMALIZED = \
        " The layer space is filled with normal-shapes using the \n" \
        " shape counts. Normal-shapes have equal length sides. "

    GRID_FIXED_SIZE = \
        " The layer space is divided by these quantities to \n" \
        " calculate the row and column counts. If either the row \n" \
        " or column span exceeds the layer space size, then \n" \
        " the layer space size is used. \n" \
        " Thus there will always be at least one row and column. "

    GRID_BY_COUNT = \
        " The layer space is divided by these quantities to calculate \n" \
        " the row and column sizes. If the division has a remainder, \n " \
        " then the remainder is distributed evenly through the table. \n" \
        " Thus the entire layer space is utilized. "

    GRID_LABEL = \
        " The layer space is the render size of the \n" \
        " backdrop image less the layer margins. \n "

    GRID_SHIFT = \
        " When shifted, the grid's first \n" \
        " cell is row: 1, column: 2. "

    IMAGE_AUTOCROP = \
        " When checked, empty space around an image is cropped out. "

    IMAGE_FOLDER = \
        " Folder:\t\t\t{} \n" \
        " Folder Order:\t{} "

    IMAGE_FOLDER_FILTERED = \
        " Folder:\t\t\t{} \n" \
        " File Filter:\t\t{} \n" \
        " Folder Order:\t{} "

    IMAGE_INFLUENCE = " Is the amount to apply to image material. "
    IMAGE_LAYERS = \
        " The image's layers are iterated as a tree, \n" \
        " where each layer becomes an image reference. "

    IMAGE_NAME = \
        " The order of image name list is \n" \
        " from GIMP's open image order. "

    IMAGE_NEXT_LINEAR = \
        " Assign images using an index variable.\n" \
        " Assign the first open image,\n" \
        " increment after assigning an image,\n" \
        " and end image assignment with the last open image. \n" \
        " The option shares the index variable with the \n" \
        " circular option. "

    IMAGE_NEXT_CIRCULAR = \
        " Assign images using an index variable.\n" \
        " It will assign the first open image,\n" \
        " increment after assigning an image,\n" \
        " and will rollover to the first open image \n" \
        " after the last open image is used." \
        " The option shares the index variable with the \n " \
        " linear option. "

    IMAGE_NUMERIC = \
        " The order of the numeric list is \n" \
        " from GIMP's open image order. "

    IMAGE_ORDER = \
        " Is the direction of the layer-tree iteration. \n" \
        " With top-down, the first layer will be \n" \
        " the layer at the top of the layer palette. \n" \
        " If top-down is off, then the order is \n" \
        " bottom-up, and the first layer will \n" \
        " be the bottom layer in the palette. "

    IMAGE_PRE_LINEAR = \
        " Assign images using an index variable.\n" \
        " It will assign the last open image,\n" \
        " decrement after assigning an image, and end\n" \
        " image assignment with the first open image. \n" \
        " The option shares the index variable with the \n" \
        " circular option. "

    IMAGE_PRE_CIRCULAR = \
        " Assign images using an index variable. \n" \
        " It will assign the last open image, \n" \
        " decrement after assigning an image,\n" \
        " and rollover to the last open image \n" \
        " after the first open image is used. \n" \
        " The option shares the index variable with the \n " \
        " linear option. "

    IMAGE_MASK_SHAPE = \
        " Has Image?\t\t{}\n" \
        " Type:\t\t\t{} \n" \
        " Horizontal Scale:\t{} \n" \
        " Vertical Scale:\t{} \n" \
        " Feather:\t\t\t{} "

    IMAGE_MASK_TEXT = \
        " Has Image?\t\t{} \n" \
        " Type:\t\t\t{} \n" \
        " Text:\t\t\t{} \n" \
        " Horizontal Scale:\t{} \n" \
        " Vertical Scale:\t{} \n" \
        " Feather:\t\t\t{} \n" \
        " Font:\t\t\t{} "

    IMAGE_MASK_IMAGE = \
        " Has Image?\t\t{} \n" \
        " Type:\t\t\t{} \n" \
        " Image:\t\t\t{} "

    IMAGE_SLICE = \
        "{} \n" \
        " Row Slices:\t\t{} \n" \
        " Column Slices:\t{} \n" \
        " Slice Order:\t\t{} "

    INFLUENCE = \
        " Backdrop Influence\t{} \n" \
        " Decoration\t\t\t{} \n" \
        " Image Influence\t\t{} \n" \
        " Metal Frame\t\t\t{} \n" \
        " Other Frame\t\t\t{} \n" \
        " Translucent Frame\t{} "

    JAG_AMPLITUDE = " Use a higher value to increase the jag projection. "
    KEEP_GRADIENT = \
        " Have GIMP store the sampled gradient \n" \
        " in the user's gradient folder. "

    LAYOUT_FRINGE = " The Cell Fringe mask-type requires a Cell Plaque. "
    LAYOUT_MARGINS = " Cell Margins will typically overlay Cell Fringe. "
    LAYOUT_COORDINATES = \
        " Display the top-left screen coordinate of \n" \
        " an image's bounding rectangle."

    LAYOUT_CORNERS = \
        " Display the location of a cell's bounding \n" \
        " rectangle in screen coordinates."

    LAYOUT_DIMENSIONS = \
        " Dimensions are the size of the image's \n" \
        " bounding rectangle."

    LAYOUT_GRID = " The grid is made with rows and columns. "
    LAYOUT_RATIOS = \
        " A ratio is an image center point divided by the render size. "

    LIGHT_ANGLE = \
        " The light angle is used by \n" \
        " emboss functions in a render. "

    LOOP_MINUS = \
        " Assign images using a circular-type index variable. \n" \
        " It will decrement itself before assigning an image. \n" \
        " Its value will rollover to the last open image\n" \
        " after the first open image. Both Loop-Plus and \n" \
        " Loop-Minus use the same index variable. If the Minus\n" \
        " option is used before the Plus option, the last\n" \
        " open image will be the first open image reference. "

    LOOP_PLUS = \
        " Assign images using a circular-type index variable. This \n" \
        " Loop index will increment before assigning an \n" \
        " image. Its value will rollover to the first open image \n" \
        " after the last open image. Both versions use the same \n" \
        " index variable. If the Plus index is used before the Minus \n" \
        " index, the first open image will be the first open image \n" \
        " reference. "

    MAIN_OPTIONS = \
        " Open a backdrop-style and image-effect options window. "

    MAIN_LAYOUT = \
        " Create a sketch-up image of the render \n" \
        " using the above Layout Options."

    MAKE_OPAQUE = \
        " Make an item opaque to give it a solid or \n" \
        " stronger appearance. A side effect of the \n" \
        " opaque effect is the antialiasing will be gone. "

    MARGIN = \
        " Per margin, the fixed-value margin and the factor \n" \
        " margin are added together to form a single margin. "

    MASK_CIRCLE = \
        " The circle mask's diameter is calculated from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where the width-diameter equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the height-diameter equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."

    MASK_CUT_CORNERS = \
        " The cut corners mask calculates an octagon that defines \n" \
        " the corners. This octagon is calculated from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where the uncut-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the uncut-height equals:\n" \
        "\timage height x vertical scale."

    MASK_DIAMOND = \
        " The diamond mask's diagonals are calculated from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where the width-diagonal equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the height-diagonal equals:\n" \
        "\timage height x vertical scale."

    MASK_HEXAGON = \
        " A hexagon mask's size is calculated from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where the width-diameter equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the height-diameter equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is\n" \
        " multiplied by the hexagon's size ratio."

    MASK_IMAGE = \
        " The image mask uses an image's alpha channel as a mask. \n" \
        " The image mask's scale is transformed by the size of the \n" \
        " image in the cell and the vertical and horizontal scales."

    MASK_OCTAGON = \
        " The octagon mask's sides are calculated from the image size \n" \
        " and the horizontal and vertical scale factors.\n\n" \
        " Where the octagon-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the octagon-height equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."

    MASK_OVAL = \
        " The oval mask's diameters are calculated from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where width-diameter equals: \n" \
        "\timage width x horizontal scale,\n" \
        " and height-diameter equals:\n" \
        "\timage height x vertical scale."

    MASK_RECTANGLE = \
        " The rectangle mask's sides are calculated from the image size \n" \
        " and the horizontal and vertical scale factors.\n\n" \
        " Where the rectangle-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the rectangle-height equals:\n" \
        "\timage height x vertical scale."

    MASK_RHOMBUS = \
        " The rhombus mask's diagonal is calculated from the image size \n" \
        " and the horizontal and vertical scale factors.\n\n" \
        " Where diagonal-value-1 equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and diagonal-value-2 equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."

    MASK_ROUND_CORNERS = \
        " The rounded corners mask calculates a ellipse that defines \n" \
        " the corners. This ellipse is calculated the from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where the ellipse-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the ellipse-height equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " This ellipse is drawn at each corner to form the rounded\n" \
        " corners."

    MASK_SQUARE = \
        " The square mask's side is calculated from the image size \n" \
        " and the horizontal and vertical scale factors.\n\n" \
        " Where the side-value-1 equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the side-value-2 equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."

    MASK_TEXT = \
        " The text mask is made from the text in the\n" \
        " 'Text' entry with the font from the 'Font' button. \n\n" \
        " Where the text-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the text-height equals:\n" \
        "\timage height x vertical scale."

    MASK_TRIANGLE_DOWN = \
        " The triangle is pointing down and is squeezed \n " \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MASK_TRIANGLE_LEFT = \
        " The triangle is pointing left and is squeezed \n " \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MASK_TRIANGLE_RIGHT = \
        " The triangle is pointing right and is squeezed \n " \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MASK_TRIANGLE_UP = \
        " The triangle is pointing up and is squeezed \n " \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MERGE_CELL = " X:\t\t{} \n Y:\t\t{} \n Width:\t{} \n Height:\t{} "

    METAL_FRAME = " Is amount to apply to an image-effect's metal frame. "
    n = " Apply cell data and show cell to the "
    NAVIGATION = (
        n + "north (ctrl + ↑). ",
        n + "south (ctrl + ↓). ",
        n + "west (ctrl + ←). ",
        n + "east (ctrl + →). "
    )

    NO_CAPTION = \
        " Has Image?\t{}\n" \
        " There is no text. "

    NO_CELL_BORDER = \
        " Has Image?\t\t{} \n" \
        " There is no cell border. "

    NO_FRINGE = \
        " Has Image?\t{}\n" \
        " There is no fringe. "

    NO_IMAGE_MASK = \
        " Has Image?\t{} \n" \
        " Type:\t\tNone "

    NO_PLAQUE = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} "

    NOISE_POWER = \
        " Use a higher value to increase \n" \
        " the noise effect on the frame. "

    OPTION_MAIN = {
        by.AVERAGE_COLOR:
            " Overlay the backdrop image with \n"
            " a pixelated backdrop image. ",

        by.BACKDROP_IMAGE:
            "Use the backdrop image settings for the backdrop. ",

        by.COLOR_FILL: "Apply a color fill to the backdrop image. ",
        by.COLOR_GRID:
            "Create a color grid to overlay the backdrop image. ",

        by.CORE_DESIGN: "Create a unique design using a gradient. ",
        by.CRYSTAL_CAVE: "Create a textured grey layer. ",
        by.CUBISM_COVER: " Use Cubism to create a layered backdrop. ",
        by.DARK_FORT: "Use the backdrop image to texture a dark brick wall. ",
        by.DENSITY_GRADIENT: " Mix a stone-like texture with a gradient. ",
        by.ETCH_SKETCH: "Create sketchy lines from the backdrop image. ",
        by.FLOOR_SAMPLE: "Create a radial color-gradient using wedges. ",
        by.GLASS_GAW:
            " Create colorful lines on a smokey glass-like backdrop. ",

        by.GRADIENT_FILL: " Apply a gradient over the backdrop image. ",
        by.CARBON_14: " Create a dark layered mosaic. ",
        by.IMAGE_GRADIENT:
            " Create a gradient from sample points \n"
            " taken from the backdrop image, \n "
            " then overlay the backdrop image. ",

        by.LINE_STONE:
            " Create a neutral bumpy concrete base \n"
            " with added touches of color and line. ",

        by.LOST_MAZE:
            " Create a maze with raised walls and gradient colors. ",

        by.MAZE_BLEND:
            " Pixelize the backdrop image \n"
            " and overlay a shadowy maze. ",

        by.MYSTERY_GRATE:
            " Create two grates that overlay \n"
            " and are painted with a gradient. ",

        by.NOISE_RIFT:
            " Create organic lines to overlay the backdrop image. ",

        by.PATTERN_FILL:
            " Fill the backdrop image with a pattern fill. \n"
            " Use bump to create texture. ",

        by.RAINBOW_VALLEY: " Create colorful droopy sprites. ",
        by.ROCKY_LANDING: " Create a rock-like texture. ",
        by.SPACETIME_FABRIC:
            " Use saturated backdrop image \n"
            " colors and a grid to form lines. ",

        by.SPECIMEN_SPECKLE:
            " Patterns and a gradient overlay \n"
            " to form edges which are then shredded. ",

        by.SPIRAL_CHANNEL:
            " Create a spiral-sourced design. ",

        by.SQUARE_CLOUD:
            " Create layered squares with a common color theme. ",

        by.TRAILING_VINE:
            " Create layered, curvy colored lines. \n"
            " You may wish to blur the backdrop image \n"
            " to harmonize with the illusion of depth. ",

        ek.BALL_JOINT: " Use a dots-brush to create an image border. ",
        ek.BORDER_LINE: " Create a metallic-type border. ",
        ek.BRUSH_PUNCH: " Use a brush to make forms attached to a frame. ",
        ek.CERAMIC_CHIP:
            " Create a metal frame wrapped with \n"
            " another frame of ceramic chips. ",

        ek.CIRCLE_PUNCH: " Create a metal frame that has circular holes. ",
        ek.CLEAR_FRAME: " Create a translucent frame around image material. ",
        ek.COLOR_BOARD:
            " Create an colored frame around image material. \n"
            " There are additional transparency options. ",

        ek.COLOR_PIPE:
            " Create a frame made from a custom \n"
            " gradient, bump, and noise. ",

        ek.CORNER_TAPE:
            " Place tape strips on the corners \n"
            " of an image's rectangle. ",

        ek.CUTOUT_PLATE:
            " Create a pattern-painted rectangular \n"
            " frame around the image material. ",

        ek.FEATHER_STEPS: " Create a feathered image edge. ",
        ek.FRAME_OVER:
            " Overlay an image frame over each image \n"
            " with color and blend options. ",

        ek.GLASS_REVEAL:
            " Create a transparent frame with multiple \n"
            " options for defining its cut or appearance. ",

        ek.GRADIENT_LEVEL:
            " Create a frame from a linear \n"
            " gradient of two colors. ",

        ek.INNER_SHADOW:
            " Add a shadow to the image edges making the \n"
            " image appear to be below the backdrop. ",

        ek.JAGGED_EDGE: " Create a subtle choppy edge to the image material. ",
        ek.LINE_FASHION: " Create a frame with bars. ",
        ek.MAZE_MIRROR:
            " Create an metallic from around the image, \n"
            " the composition, and in a mirrored network. ",

        ek.NO_EFFECT: "Leave the image as is.",
        ek.PAINT_RUSH: " Create an white frame that has edgy paint material. ",
        ek.RAD_WAVE:
            " Create image and composition frames \n"
            " and a network of wavy connectors. ",

        ek.RAISED_MAZE:
            " Create image and composition \n"
            " frames that have a maze of connectors. ",

        ek.SQUARE_PUNCH: " Create a metal frame that has square holes. ",
        ek.STAINED_GLASS:
            " Create a metal frame wrapped with \n"
            " another frame of stained glass. ",
        ek.WIRE_FENCE: " "
            " Create a metal frame wrapped with \n"
            " another frame of fence-like material. "
    }
    OTHER_FRAME = \
        " Is amount to apply to an image-effect's frame \n " \
        " of type that is neither metal or translucent. "

    PER_CELL_BEGIN = \
        " Select to modify options on a per cell basis. "

    PER_CELL_BUTTON = \
        " Open a per cell window in order \n" \
        " to modify settings cell-by-cell. "

    PLACE = \
        " Justification:\t\t{} \n" \
        " Opacity: \t\t{} \n" \
        " Rotate:\t\t\t{} \n" \
        " Blur Behind:\t\t{} \n" \
        " Flip Horizontal:\t{} \n" \
        " Flip Vertical:\t\t{} \n" \
        "{} \n" \
        "{} "

    PLAQUE_AVERAGE_COLOR = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        "{}"

    PLAQUE_COLOR = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t\t{} \n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{} \n" \
        "{}"

    PLAQUE_GRADIENT = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Gradient Type:\t\t{} \n " \
        " Gradient Angle:\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Gradient:\t\t\t{} \n " \
        "{}"

    PLAQUE_IMAGE = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Image:\t\t\t\t{} \n" \
        "{}"

    PLAQUE_NETTING = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Line Width:\t\t\t{} \n" \
        " Spacing:\t\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t\t{} \n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{} \n" \
        "{}"

    PLAQUE_PATTERN = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Pattern:\t\t\t\t{} \n" \
        "{}"

    PLAQUE_PLASMA = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Blur:\t\t\t\t{} \n" \
        "{}"

    PLAQUE_SHADOW = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Intensity:\t\t\t{} \n" \
        " Shadow Blur:\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t\t{} \n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{} \n" \
        "{}"

    POST_BLUR = \
        " Create a blurry frame that sits on top \n" \
        " of image material. The blur is applied \n" \
        " after the frame is defined and embossed. "

    RANDOM_SEED = " Change this value to produce a different result. "
    RESIZE_CROP = \
        " Crop:\n" \
        "\tOffset X:\t\t{} \n" \
        "\tOffset Y:\t\t{} \n" \
        "\tWidth:\t\t{} \n" \
        "\tHeight:\t\t{} "

    RESIZE_CROP_VALUE = \
        " Crop the image from a topleft coordinate \n" \
        " defined by x and y. The size of the crop is \n" \
        " from the width and height options. \n" \
        " If the image doesn't fit in the cell, \n" \
        " a selection is made from the image using \n" \
        " the cell's justification and size. "

    RESIZE_FIXED = \
        " Fixed-Size: \n" \
        "\tWidth:\t\t{} \n" \
        "\tHeight:\t\t{} "

    RESIZE_FIXED_VALUE = \
        " The image is resized to these dimensions. \n" \
        " If the image doesn't fit in the cell, \n" \
        " a selection is made from the image using \n" \
        " the cell's justification and size. "

    RESIZE_FACTOR = \
        " Factor of Image Size: \n" \
        "\tWidth x\t\t{} \n" \
        "\tHeight x\t\t{} "

    RESIZE_FACTOR_VALUE = \
        " The image is resized by multiplying the \n" \
        " factor values by the image size. If \n" \
        " the image doesn't fit in the cell, a \n" \
        " selection is made from the image using \n" \
        " using the cell's justification and size. "

    REVERSE = " Reverse the order of the gradient colors. "
    ROUNDED = " The Rounded process is faster. "
    SAMPLE_POINTS = " Sample points are evenly distributed between the edges. "
    SATURATION = \
        " Values below one lower the saturation. \n" \
        " Saturation multiplies the saturation of the input. "

    SCATTER_COUNT = " Is the number of mazes to draw. "
    SLICE = " Slice an image using row and column quantities. "
    SPIRAL_DISTANCE = " Lower the value to increase the spiral count. "
    START_X = \
        " The start coordinate is a factor of the layer size \n" \
        " value. The coordinate will scale with the render size. "

    STEPS = " The image feather effect repeats by this quantity. "
    STOP_LENGTH = \
        " Is the lowest value of pixels \n" \
        " for drawing a line in a maze. "

    STRIPE_HEIGHT = \
        " The height is calculated as a \n" \
        " factor of the caption height \n" \
        " that is made from text and shadow. "

    THRESHOLD = \
        " A threshold of 1.0 is to match all \n" \
        " and a threshold of 0.0 is to mach none. "

    TRANSLUCENT_FRAME = \
        " Is the amount to apply a translucent image-effect frame. "

    USE_PLASMA = \
        " When checked, a blurred plasma layer \n" \
        " will be used as a background. If \n" \
        " unchecked, the backdrop image settings \n" \
        " are used for the background. If the \n" \
        " backdrop  image is used, try using \n" \
        " the maximum blur for an optimal effect. "
    WHIRL = " As if there were a hole at the center of the image. "

    @staticmethod
    def make_brush_tooltip(d):
        """
        Create a tooltip for a brush option button.

        d: dict
            with brush settings

        Return: string
            tooltip
        """
        return Tip.BASE_BRUSH.format(
            d[ok.BRUSH],
            d[ok.BRUSH_SIZE],
            d[ok.BRUSH_SPACING],
            d[ok.OPACITY],
            round(d[ok.BRUSH_HARDNESS], 3),
            d[ok.BRUSH_ANGLE]
        )

    @staticmethod
    def make_bump_tooltip(d):
        """
        Create a tooltip for a bump option button.

        d: dict
            with bump settings

        Return: string
            tooltip
        """
        if d[ok.BUMP_TYPE] == fb.NOISE:
            return Tip.BASE_NOISE_BUMP.format(
                d[ok.BUMP_TYPE],
                d[ok.BUMP_DEPTH],
                round(d[ok.NOISE], 2)
            )

        elif d[ok.BUMP_TYPE] == fb.CLOTH:
            return Tip.BASE_CLOTH_BUMP.format(
                d[ok.BUMP_TYPE],
                d[ok.BUMP_DEPTH],
                round(d[ok.BLUR_X], 1),
                round(d[ok.BLUR_Y], 1)
            )
        else:
            return " No Bump "

    @staticmethod
    def make_influence_tooltip(d):
        """
        Create a tooltip for an influence option button.

        d: dict
            of image choice

        Return: string
            tooltip
        """
        return Tip.INFLUENCE.format(
            d[ok.BACKDROP_INFLUENCE],
            d[ok.DECO],
            d[ok.IMAGE_INFLUENCE],
            d[ok.METAL_FRAME],
            d[ok.OTHER_FRAME],
            d[ok.TRANSLUCENT_FRAME]
        )

    @staticmethod
    def make_image_tooltip(d):
        """
        Create a tooltip for a image choice option button.

        d: dict
            of image choice

        Return: string
            tooltip
        """
        n = d[ok.IMAGE_SOURCE]

        if n != "None":
            if n in fi.INDICES:
                x = fi.INDICES.index(n)
                a = d[n]
                n = " {} ".format(fi.TOOLTIPS[x][a])

            elif n == ok.FOLDER:
                if d[ok.FILTER]:
                    n = Tip.IMAGE_FOLDER_FILTERED.format(
                        d[ok.FOLDER],
                        d[ok.FILTER],
                        fi.FOLDER_ORDER_LIST[d[ok.FOLDER_ORDER]]
                    )
                else:
                    n = Tip.IMAGE_FOLDER.format(
                        d[ok.FOLDER],
                        fi.FOLDER_ORDER_LIST[d[ok.FOLDER_ORDER]]
                    )

            else:
                n = " {} ".format(d[n])

            if d[ok.AS_LAYERS]:
                n = Tip.BASE_IMAGE_LAYERS.format(
                    n,
                    bool(d[ok.AS_LAYERS]),
                    bool(d[ok.AUTOCROP]),
                    fi.LAYER_ORDER_LIST[d[ok.LAYER_ORDER]]
                )
            if d[ok.SLICE]:
                n = Tip.IMAGE_SLICE.format(
                    n,
                    d[ok.ROW_SLICE],
                    d[ok.COLUMN_SLICE],
                    fi.SLICE_ORDER_LIST[d[ok.SLICE_ORDER]]
                )

        else:
            n = " None "

        n = n.replace("  ", " ")
        return n

    @staticmethod
    def make_margin_tooltip(d):
        """
        Return a tooltip for a margin tuple.

        The tuple is composed of four fixed-value
        and four factor values.

        d: dict
            of margins

        Return: string
            tooltip
        """
        return Tip.BASE_MARGIN.format(
            d[ok.FIXED_TOP],
            d[ok.FIXED_BOTTOM],
            d[ok.FIXED_LEFT],
            d[ok.FIXED_RIGHT],
            d[ok.FACTOR_TOP],
            d[ok.FACTOR_BOTTOM],
            d[ok.FACTOR_LEFT],
            d[ok.FACTOR_RIGHT]
        )

    @staticmethod
    def make_resize_tooltip(d):
        """
        Create a tooltip for a resize method option button.

        d: dict
            of resize method

        Return: string
            tooltip
        """
        n = d[ok.RESIZE_TYPE]
        if n not in fz.TEXT_TYPE:
            if n == fz.CROP:
                n = Tip.RESIZE_CROP.format(
                    d[ok.CROP_X],
                    d[ok.CROP_Y],
                    d[ok.CROP_W],
                    d[ok.CROP_H]
                )

            elif n == fz.FIXED:
                n = Tip.RESIZE_FIXED.format(
                    d[ok.FIXED_IMAGE_SIZE_W],
                    d[ok.FIXED_IMAGE_SIZE_H]
                )
            elif n == fz.FACTOR:
                n = Tip.RESIZE_FACTOR.format(
                    d[ok.FACTOR_IMAGE_SIZE_W],
                    d[ok.FACTOR_IMAGE_SIZE_H]
                )
        return n

    @staticmethod
    def make_shadow_tooltip(d):
        """
        Create a tooltip for a shadow tuple.

        d: dict
            of Tri-Shadow SuperPreset

        Return: string
            tooltip
        """
        def get_shadow_tip(e):
            if i in ff.LOWER_SHADOWS:
                return Tip.BASE_SHADOW.format(
                    i[-1],
                    e[ok.SHADOW_BLUR],
                    e[ok.INTENSITY],
                    e[ok.OFFSET_X],
                    e[ok.OFFSET_Y],
                    e[ok.SHADOW_COLOR][0],
                    e[ok.SHADOW_COLOR][1],
                    e[ok.SHADOW_COLOR][2],
                    bool(e[ok.MAKE_OPAQUE])
                )

            elif i == sk.INNER_SHADOW:
                return Tip.BASE_INNER_SHADOW.format(
                    i[-1],
                    e[ok.INLAY_BLUR],
                    e[ok.INTENSITY],
                    e[ok.SHADOW_COLOR][0],
                    e[ok.SHADOW_COLOR][1],
                    e[ok.SHADOW_COLOR][2]
                )
            return ""

        # Check validity:
        if sk.SHADOW_TYPE not in d:
            tip = " No Shadow "

        else:
            a = d[sk.SHADOW_TYPE][ok.SHADOW_TYPE]
            if not a:
                tip = " No Shadow "
            else:
                tip = ""
                for i in (sk.SHADOW_1, sk.SHADOW_2, sk.INNER_SHADOW):
                    n2 = "" if not tip else "\n"
                    tip += n2 + get_shadow_tip(d[i])
        return tip

    @staticmethod
    def make_stripe_tooltip(d):
        """
        Create a tooltip for a image choice option button.

        d: dict
            of image choice

        Return: string
            tooltip
        """
        if d[ok.STRIPE_TYPE] == 1:
            return Tip.BASE_STRIPE.format(
                d[ok.OPACITY],
                d[ok.STRIPE_HEIGHT],
                d[ok.BLUR_BEHIND],
                d[ok.COLOR][0],
                d[ok.COLOR][1],
                d[ok.COLOR][2]
            )
        else:
            return " No Stripe "
