#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Group as og
from roller_constant_key import (
    Button as bk,
    Group as gk,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_grid import Grid
from roller_option_preset import SuperPreset
from roller_option_view import do_per_cell
from roller_one import One
from roller_one_draw import Draw
from roller_one_extract import Path
from roller_one import Hat
from roller_one_tip import Tip
from roller_widget_button import Button
from roller_widget_box import Box
from roller_widget_check_button import CheckButton
from roller_port_cell import PortCell
import gtk

TRY = "{} Cell Table: Try escape, enter, space-bar to close, save, edit."


class PerCellGroup(Box):
    """
    This is a custom GTK Button.

    It's value is a list containing a cell table.
    """

    def __init__(self, **d):
        """
        Create a GTK Button that is attached to an GTK Alignment.

        Use to open per cell port.

        d: dict
            Has keyword arguments for the Widget.
        """
        Box.__init__(self, box=gtk.HBox, align=(0, 0, 1, 1))

        self._value = []
        self.group = d[wk.GROUP]
        self.on_preview_button = d[wk.ON_PREVIEW_BUTTON]

        # CheckButton:
        self._group_key = d[wk.GROUP_KEY]
        d[wk.KEY] = ok.PER_CELL

        # 'form' is the option group that is attached to the Per Cell:
        path = d[wk.PATH]
        self._form_group_key = og.SOURCE_GROUP_KEY[self._group_key]
        self._form_path_key = d[wk.GROUP_KEY].split(",")[0]
        self._form_path = path[:-1] + (self._form_path_key,)
        self.form_group = Hat.cat.group_dict[self._form_path]

        self._port = d[wk.PORT]
        self.roller_window = d[wk.WIN]
        self._update_window = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self._on_change
        d[wk.TOOLTIP] = Tip.PER_CELL_BEGIN
        self.key = d[wk.TEXT] = ok.PER_CELL
        d[wk.ALIGN] = 0, 0, 0, 1
        d[wk.PADDING] = 0, 0, 0, 5
        self.check_button = CheckButton(**d)

        # Button:
        d[wk.TOOLTIP] = Tip.PER_CELL_BUTTON
        d[wk.KEY] = d[wk.TEXT] = bk.OPEN
        d[wk.ALIGN] = 0, 0, 1, 0
        d[wk.PADDING] = 0, 0, 5, 0
        self.button = Button(**d)

        # Add buttons:
        for i in (self.check_button, self.button):
            self.add(i)

    def _on_change(self, g):
        """
        Respond to a change event for one of the widgets.

        g: Widget
            Is responsible.
        """
        def update():
            """
            Update the per cell table.

            Return: Grid
                for the cell editor
            """
            _d = Path.get_dict_from_path(sk.GLOBAL)

            Hat.cat.render.set_size(_d[ok.RENDER_WIDTH], _d[ok.RENDER_HEIGHT])
            return Grid(
                One(
                    layer_margin=Path.get_layer_margin(path),
                    path=path,
                    d=Path.get_grid_from_path(path)
                )
            )

        if not (Draw.load_count or Draw.preset_load_count):
            a = g.get_value()
            path = self._form_path

            if g == self.check_button:
                # Update its sibling form group of the change:
                self.form_group.changed = self.form_group.unseen = True

                self.group.preset.set_to_undefined()
                self.on_per_cell_change(g)
                do_per_cell(self.check_button)

                if not a:
                    self._value = []
                else:
                    update()

            else:
                grid = update()
                grid.calc_pockets(Path.get_cell_margin(path))
                d = Hat.cat.group_dict
                one = One(
                    grid=grid,
                    path=path,
                    per_cell_group=self,
                    place_chunk={}
                )

                self._port.switch_ports()
                self._original_value = deepcopy(self._value)

                # Is a dependency-timing issue as per cell
                # groups have common cell attributes.
                # Update grid, place and cell margin dict
                # for the per cell table:
                if self._group_key != gk.CELL_IMAGE_PLACE:
                    q = Path.make_cell_place_path(path)
                    d[q].vbox.per_cell_group.get_value()
                    one.place_chunk = Path.get_dict_from_path(q)

                one.per_cell_table = self.get_value()
                one.group_key = self._form_group_key
                one.key = self._form_path_key
                one.on_accept = self.accept_port
                one.on_cancel = self.cancel_port
                one.port = self._port
                one.win = self.roller_window
                one.window_title = TRY.format(self._form_path_key)
                PortCell(one, self)
            self._update_window(g)

    def accept_port(self, cell_table):
        """Return from PortCell."""
        # Update its sibling form group of the change:
        self.form_group.changed = self.form_group.unseen = True

        self._value = cell_table
        self._port.show_port()
        self.on_per_cell_change(self.button)
        self.group.preset.set_to_undefined()

    def cancel_port(self, *_):
        """Return from PortCell."""
        return self._port.show_port()

    def get_value(self):
        """
        Get the Per Cell cell table.

        Return: list
            a cell table
            2D (lists within a list)
        """
        if self._value:
            return deepcopy(self._value)
        return []

    def on_per_cell_change(self, _):
        """
        The source group changes with the per cell group.

        _: Widget
            from the per cell group
            not used
        """
        if not (Draw.load_count or Draw.preset_load_count):
            cat = Hat.cat
            cat.group_dict[self._form_path].preset.set_to_undefined()

            path = self._form_path
            group = cat.group_dict[path]

            # 'group.changed' is set by the PortCell hooks:
            group.unseen = True

            SuperPreset.update_view_buttons(path)
            group.preview_button.set_sensitive(1)
            group.plan_button.set_sensitive(1)

    def set_value(self, q):
        """
        Set the CheckButton checked state.

        Is part of the Widget template.

        q: a 2D list
            lists within a list
            of cell table
        """
        self.check_button.widget.set_active(len(q) > 0)
        self._value = q
