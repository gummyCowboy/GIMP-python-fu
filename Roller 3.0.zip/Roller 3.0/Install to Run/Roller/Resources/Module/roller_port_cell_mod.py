#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color as co, Margin as fm, Widget as fw
from roller_constant_key import (
    Group as gk,
    Option as ok,
    Widget as wk,
    Window as wi
)
from roller_one_tip import Tip
from roller_option_group import OptionGroup
from roller_option_preset import Preset
from roller_option_view import EXPOSE
from roller_port_preview import PortPreview
from roller_widget_box import Box, Eventful, VBow
from roller_widget_button import Button, PreviewButton
from roller_widget_label import Label
from roller_widget_table import Table
from roller_window_save import RWSave
import gtk

# For GTK, let it know that the function handled an signal:
DONE = 1

PAD = 0, 0, fw.MARGIN, fw.MARGIN


def set_button(m, g):
    """
    Set the button sensitivity based on a flag.

    m: flag
        If true, then enable widget.

    g: Widget
        button
    """
    g.enable() if m else g.disable()


class PortCellMod(PortPreview):
    """Draw the cell modification port for a single cell."""

    def __init__(self, d, g, r, c):
        """
        Start it up.

        d: dict
            of PortCell

        g: Button
            an open button from a per cell group
            Has a 'on_preview_button' function.
            Use the function to relay preview commands.

        r, c: int
            cell index
            work-in-progress
        """
        self._row, self._column = r, c
        self.subtitle = d[wk.WINDOW_TITLE]
        self.key = d[wk.KEY]
        self._update_key = self.key + ", Cell"
        self._grid = d[wk.GRID]
        self._path = d[wk.PATH]
        self._set_tool_tip = d[wk.SET_TOOLTIP]
        self._table = d[wk.CELL_TABLE]
        self._rows, self._columns = d[wk.TABLE_SIZE]
        d[wk.WINDOW_KEY] = wi.CELL_MOD
        d[wk.SAVE_WINDOW] = RWSave
        k = d[wk.GROUP_KEY]
        self.d = {
            wk.GROUP_KEY: k,
            wk.GROUP_TYPE: Preset,
            wk.HAS_PRESET: True,
            wk.IS_DEFAULT: False,
            wk.KEYS: Preset.get_keys(k),
            wk.PATH: self._path + (k,),
            wk.PARENT_TYPE: gk.PER_CELL
        }

        PortPreview.__init__(self, d, g)
        self._show_active_cell()

    def _apply_to_all(self, _):
        """
        Apply the widget values to all related cells.

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()

        for r in range(self._rows):
            for c in range(self._columns):
                self._set_changed_box(r, c)
        return self.accept_edit()

    def _apply_to_even(self, _):
        """
        Apply the widget values to the
        current cell and even-sequenced cells.

        _: Button
            Is responsible.
            not used

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()

        for r in range(self._rows):
            for c in range(self._columns):
                if (r + c) % 2:
                    self._set_changed_box(r, c)

        if not (self._row + self._column) % 2:
            self._set_changed_box(self._row, self._column)
        return self.accept_edit()

    def _apply_to_odd(self, _):
        """
        Apply the widget values to the
        current cell and odd-sequenced cells.

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()

        for r in range(self._rows):
            for c in range(self._columns):
                if not (r + c) % 2:
                    self._set_changed_box(r, c)

        if (self._row + self._column) % 2:
            self._set_changed_box(self._row, self._column)
        return self.accept_edit()

    def _apply_to_column(self, _):
        """
        Apply the widget values to the
        current cell table column.

        Return: true
            The key-press is handled.
        """
        c = self._column

        self._show_inactive_cell()

        for r in range(self._rows):
            self._set_changed_box(r, c)
        return self.accept_edit()

    def _apply_to_row(self, _):
        """
        Apply the widget values to the current cell table row.

        _: Button
            not in use

        Return: true
            The key-press is handled.
        """
        r = self._row

        self._show_inactive_cell()

        for c in range(self._columns):
            self._set_changed_box(r, c)
        return self.accept_edit()

    def _do_east_cell(self, *_):
        """Move cell focus eastward."""
        self._save_data()
        self._east_button.set_tooltip_text("")

        for c in range(self._column + 1, self._columns):
            if self._table[self._row][c].has_pic:
                self._column = c
                break
            elif self._table[self._row][c].is_topleft:
                self._column = c
                break
        self._set_widget_values()

    def _do_north_cell(self, *_):
        """Move cell focus upward."""
        self._save_data()
        self._north_button.widget.set_tooltip_text("")

        for r in range(self._row - 1, -1, -1):
            if self._table[r][self._column].has_pic:
                self._row = r
                break
            elif self._table[r][self._column].is_topleft:
                self._row = r
                break
        self._set_widget_values()

    def _do_south_cell(self, *_):
        """Move cell focus downward."""
        self._save_data()
        self._south_button.set_tooltip_text("")

        for r in range(self._row + 1, self._rows):
            if self._table[r][self._column].has_pic:
                self._row = r
                break
            elif self._table[r][self._column].is_topleft:
                self._row = r
                break
        self._set_widget_values()

    def _do_west_cell(self, *_):
        """Change the focus cell to the cell to the west."""
        self._save_data()
        self._west_button.set_tooltip_text("")

        for c in range(self._column - 1, -1, -1):
            if self._table[self._row][c].has_pic:
                self._column = c
                break
            elif self._table[self._row][c].is_topleft:
                self._column = c
                break
        self._set_widget_values()

    def _draw_cell_navigation(self, g):
        """
        Draw four horizontally oriented buttons
        that can navigate the cell table.

        g: container
            container for buttons
        """
        w = fw.MARGIN
        box = Eventful(self.color)
        vbox = Box()
        hbox = Box(box=gtk.HButtonBox, align=(0, 0, 0, 0))

        vbox.pack_start(
            Label(
                padding=(2, 4, 4, 0),
                text="Cell Navigation:"
            )
        )
        vbox.pack_start(hbox, expand=False)
        box.add(vbox)
        g.pack_start(box, expand=False)
        hbox.set_padding(0, 0, w, w)

        self._north_button = Button(
            on_widget_change=self._do_north_cell,
            text="↑"
        )
        self._south_button = Button(
            on_widget_change=self._do_south_cell,
            text="↓"
        )
        self._west_button = Button(
            on_widget_change=self._do_west_cell,
            text="←"
        )
        self._east_button = Button(
            on_widget_change=self._do_east_cell,
            text="→"
        )
        for x, i in enumerate(
            (
                self._north_button,
                self._south_button,
                self._west_button,
                self._east_button
            )
        ):
            hbox.pack_start(i, expand=False)
            i.set_tooltip_text(Tip.NAVIGATION[x])

    def _draw_process(self):
        """
        Draw the process group buttons.

        Return: Eventful
            contains group
        """
        w = fw.MARGIN
        q = []
        box = Eventful(self.color)
        vbox = Box(align=(0, 0, 1, 1))

        box.add(vbox)
        vbox.pack_start(
            Label(padding=(2, 0, 4, 0), text="Apply:"),
            expand=False
        )
        q.append(
            Button(
                on_widget_change=self.cancel,
                padding=PAD,
                text="Cancel"
            )
        )
        q.append(
            PreviewButton(
                group=self.group,
                on_preview_button=self.task_preview,
                on_widget_change=self.on_widget_change,
                padding=PAD
            )
        )
        q.append(
            Button(
                on_widget_change=self._apply_to_row,
                padding=PAD,
                text="Row"
            )
        )
        q.append(
            Button(
                on_widget_change=self._apply_to_column,
                padding=PAD,
                text="Column"
            )
        )
        q.append(
            Button(
                on_widget_change=self._apply_to_all,
                padding=PAD,
                text="All Cells"
            )
        )
        q.append(
            Button(
                on_widget_change=self._apply_to_even,
                padding=PAD,
                text="Cell & Even Cells"
            )
        )
        q.append(
            Button(
                on_widget_change=self._apply_to_odd,
                padding=PAD,
                text="Cell & Odd Cells"
            )
        )
        q.append(
            Button(
                on_widget_change=self.accept_edit,
                padding=PAD,
                text="Cell"
            )
        )
        alignment = gtk.Alignment(0, 0, 0, 0)
        table = gtk.Table(len(q), 1)
        option_count = len(q)
        color = self.color

        self.keep(q)
        table.set_row_spacings(1)
        alignment.set_padding(w, w, w, w)

        for x, i in enumerate(q):
            color = Table.get_darker_color(color, option_count)
            color1 = color, color, co.MAX_COLOR
            box1 = Eventful(color1)

            box1.add(i)
            table.attach(box1, 0, 1, x, x + 1)

        alignment.add(table)
        vbox.add(alignment)
        return box

    def _is_cell(self, r, c):
        """
        Determine if the cell is a valid image cell.

        Return: bool
            Is true if the cell is a valid image holding cell.
        """
        return self._table[r][c].has_pic or self._table[r][c].is_topleft

    def _process_control_arrow(self, n):
        """
        The user pressed control-arrow key.

        Change the widget values to the cell indicated by
        the arrow key. The target cell may not exist.

        n: string
            arrow key-press
        """
        r, c = self._row, self._column

        if n == "Down":
            if r + 1 != self._rows:
                m = False

                for r1 in range(r + 1, self._rows):
                    if self._is_cell(r1, c):
                        m = True
                        break
                if m:
                    self._do_south_cell()

        elif n == "Up":
            if r != 0:
                m = False

                for r1 in range(r - 1, -1, -1):
                    if self._is_cell(r1, c):
                        m = True
                        break
                if m:
                    self._do_north_cell()

        elif n == "Left":
            if c != 0:
                m = False

                for c1 in range(c - 1, -1, -1):
                    if self._is_cell(r, c1):
                        m = True
                        break
                if m:
                    self._do_west_cell()

        elif n == "Right":
            if c + 1 != self._columns:
                m = False

                for c1 in range(c + 1, self._columns):
                    if self._is_cell(r, c1):
                        m = True
                        break
                if m:
                    self._do_east_cell()

    def _save_data(self):
        """Save the current display values with the cell table."""
        self._show_inactive_cell()

        r, c = self._row, self._column
        q = self.safe.get_value()
        d = self.preset.get_value()
        q[r][c] = d

        self.safe.set_value(q)
        self._set_changed_box(r, c)

    def _set_changed_box(self, r, c):
        """
        Update the per cell table, the tooltip, and the label color.

        r, c: int
            cell position
        """
        m = False

        if self._table[r][c].has_pic:
            m = True

        elif self._table[r][c].is_topleft:
            m = True
        if m:
            q = self.safe.get_value()
            d = q[r][c] = self.preset.get_value()
            box = self._table[r][c].box

            self.safe.set_value(q)
            self._set_tool_tip(box, d)
            box.label.modify_fg(gtk.STATE_NORMAL, co.WHITE)

    def _set_widget_values(self, is_update=True):
        """
        Set the values displayed in the widgets.

        Data is from the current cell at self._row and self._column.

        is_update: bool
            When true, the widget visibility is updated.
        """
        d = self.safe.get_value()[self._row][self._column]

        self.preset.set_value(d)
        self.preset.set_to_undefined(has_super=False)
        self._show_active_cell()
        self.verify_nav_button()
        self._cell_label.widget.set_text(
            "Cell Data:\tRow: {}\tColumn: {}".format(
                self._row + 1,
                self._column + 1
            )
        )
        if is_update:
            EXPOSE[self._update_key](self.preset)

    def _show_active_cell(self):
        """
        Change the text of the cell in the PortCell to show an edit-state.
        """
        self._table[self._row][self._column].box.label.set_text("☍")

    def _show_inactive_cell(self):
        """
        Change the text of the cell in the PortCell port back to normal.
        """
        r, c = self._row, self._column
        n = fw.IMAGE_SYMBOL if self._table[r][c].has_pic else fw.NO_IMAGE
        self._table[r][c].box.label.set_text(n)

    def accept_edit(self, *_):
        """
        Apply the widget values to the cell table.

        Return: true
            The key-press is handled.
        """
        self._save_data()
        return self.accept_preview()

    def cancel(self, *_):
        """
        Update the current cell's symbol to
        show that it's back to being inactive.

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()
        return self.cancel_port()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        g: VBox
            container for widgets
        """
        self.d[wk.COLOR] = self.color
        self.d[wk.WIN] = self.roller_window
        self.d[wk.ON_PREVIEW_BUTTON] = self.task_preview
        self.d[wk.ON_WIDGET_CHANGE] = self.on_widget_change
        r, c = self._row, self._column
        self._cell_label = Label(
            padding=(4, 4, 4, 4),
            text="Cell Data:\tRow: {}\tColumn: {}".format(r + 1, c + 1)
        )
        hbox = gtk.HBox()

        # cell data group:
        box = Eventful(self.color)
        vbox = self.d[wk.CONTAINER] = VBow()

        self.reduce_color()
        box.add(vbox)
        vbox.add(self._cell_label)

        d = OptionGroup.draw_group(**self.d)
        self.preset = d[wk.PRESET]
        self.group = self.preset.group

        # navigation group:
        self.reduce_color()
        self._draw_cell_navigation(vbox)
        self.reduce_color()

        box1 = self._draw_process()

        self._set_widget_values(is_update=False)
        hbox.add(box)
        hbox.add(box1)
        g.add(hbox)
        self.roller_window.win.connect(
            'key_press_event',
            self.on_arrow_key_press
        )
        self.preset.refresh(fw.UNDEFINED)

    def get_group_value(self):
        """
        Call before doing a preview.

        Return: list
            a per cell table
        """
        q = self.safe.get_value()
        q[self._row][self._column] = self.preset.get_value()
        return q

    def on_arrow_key_press(self, _, event):
        """
        Check to see if the user pressed control key
        and an arrow key at the same time.

        event: key-press event
            looking for an arrow-key pressed event

        Return: None or true
            Is true if the key-press is handled.
        """
        n = gtk.gdk.keyval_name(event.keyval)
        control_pressed = (event.state & gtk.gdk.CONTROL_MASK)
        if control_pressed and n in ('Left', 'Right', 'Up', 'Down'):
            self._process_control_arrow(n)
            return DONE

    def on_widget_change(self, g):
        """
        Relay a change event from the sub-port widgets.
        Set the sensitivity of the Preview Button.

        g: Widget
            Is responsible for the change event.

        Return: Done or None
            from the super class
            for the GTK event handler
        """
        if g.key in fm.MARGIN_KEY:
            if ok.MARGIN_SIZE in g.group.d:
                g.group.d[ok.MARGIN_SIZE].update_size(
                    grid=self._grid,
                    r=self._row,
                    c=self._column
                )
        return super(PortCellMod, self).on_widget_change(g)

    def verify_nav_button(self):
        """
        Verify the navigation button given the current cell.

        The cell indices, 'self._row' and
        'self._column', define the current cell.

        Scan the cell table for a cell with a picture.
        """
        r, c = self._row, self._column

        if r + 1 == self._rows:
            self._south_button.disable()

        else:
            m = False

            for r1 in range(r + 1, self._rows):
                if self._is_cell(r1, c):
                    m = True
                    break
            set_button(m, self._south_button)

        if r == 0:
            self._north_button.disable()

        else:
            m = False

            for r1 in range(r - 1, -1, -1):
                if self._is_cell(r1, c):
                    m = True
                    break
            set_button(m, self._north_button)

        if c + 1 == self._columns:
            self._east_button.disable()

        else:
            m = False

            for c1 in range(c + 1, self._columns):
                if self._is_cell(r, c1):
                    m = True
                    break
            set_button(m, self._east_button)

        if c == 0:
            self._west_button.disable()
        else:
            m = False

            for c1 in range(c - 1, -1, -1):
                if self._is_cell(r, c1):
                    m = True
                    break
            set_button(m, self._west_button)
