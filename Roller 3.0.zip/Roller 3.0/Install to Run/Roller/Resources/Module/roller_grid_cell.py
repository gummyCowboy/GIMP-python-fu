#!/usr/bin/env python
# -*- coding: utf-8 -*-


class GridCell(object):
    """Use with the grid cell table to hold cell rectangles."""

    def __init__(self, r, c):
        """
        Is a cell attribute object.

        r, c: int
            cell index
        """
        # row and column cell table indices:
        self.r, self.c = r, c

        # Rect
        # Has the topleft coordinate and the size of the cell:
        self.cell = None

        # string
        # Use to assign an Image reference:
        self.image = ""

        # Rect
        # Use to store merged cell size:
        self.merge_cell = None

        # Is a Rect for image place:
        self.mold = None

        # tuple
        # Use with plaque and fringe to get cell shape without margin:
        self.plaque = None

        # Rect
        # Is the cell rectangle with with margins:
        self.pocket = None

        # tuple
        # Use with render to get cell shape with margin:
        self.shape = None
