#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import Widget as fw
from roller_constant_key import Plan as ak, Widget as wk
from roller_one_tip import Tip
from roller_option_preset import NonPreset
from roller_widget_box import Box
from roller_widget_button_pair import ButtonPair
from roller_widget_check_button import CheckButton
import gtk

BUTTON_KEY = "Select All", "Select None"
TOOLTIP = {
    ak.CELL_FRINGE: Tip.LAYOUT_FRINGE,
    ak.CELL_MARGINS: Tip.LAYOUT_MARGINS,
    ak.COORDINATES: Tip.LAYOUT_COORDINATES,
    ak.CORNERS: Tip.LAYOUT_CORNERS,
    ak.DIMENSIONS: Tip.LAYOUT_DIMENSIONS,
    ak.GRID: Tip.LAYOUT_GRID,
    ak.RATIOS: Tip.LAYOUT_RATIOS
}


class GroupPlan(Box):
    """Has a CheckButtons for selecting layout-preview options."""

    def __init__(self, **d):
        """
        Create a group of layout option CheckButtons.

        d: dict
            Has init values.
        """
        w = fw.MARGIN
        w1 = w // 2
        buttons = self._buttons = []
        self.plan_option_dict = {}
        vbox_list = Box(), Box()
        self.key = d[wk.KEY]
        self.group = d[wk.GROUP]

        Box.__init__(self, box=gtk.VBox, padding=(w, w1, 0, 0))

        hbox = gtk.HBox()
        keys = NonPreset.get_keys(d[wk.KEY])

        for k in keys:
            buttons.append(
                CheckButton(padding=(0, 0, w, w), text=k, **d)
            )
            self.plan_option_dict[k] = buttons[-1]
            if k in TOOLTIP:
                buttons[-1].set_tooltip_text(TOOLTIP[k])

        d[wk.TEXT] = BUTTON_KEY
        d[wk.ON_WIDGET_CHANGE] = self._on_button_action
        pair = ButtonPair(**d)

        hbox.add(vbox_list[0])
        hbox.add(vbox_list[1])
        self.add(hbox)
        self.add(pair)

        vbox = vbox_list[0]
        midpoint = len(buttons) // 2 + len(buttons) % 2
        for x, button in enumerate(buttons):
            if x == midpoint:
                vbox = vbox_list[1]
            vbox.add(button)

    def _on_button_action(self, g):
        """
        Respond to a button action.

        g: Button
            Is responsible.
        """
        a = 1 if g.key == BUTTON_KEY[0] else 0
        for i in self._buttons:
            i.set_value(a)

    def get_value(self):
        """
        Return a layout option dictionary so
        the settings can be saved and restored.
        """
        d = OrderedDict()

        for k, g in self.plan_option_dict.items():
            d[k] = g.get_value()
        return d

    def set_value(self, d):
        """
        Set the value of the CheckButton and is part of the Widget template.

        Verify the cell window opener button.

        d: dict
            layout option dict
        """
        [self.plan_option_dict[k].set_value(d[k]) for k in d]
