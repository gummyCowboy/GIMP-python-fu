#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Mage, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
X_IS_1 = Y_IS_1 = 1


def draw_circles(z, d):
    """
    Draw circles on the rotated layer.

    Create a pattern (a black circle).
    Use the clipboard to hold the pattern.
    Fill the target layer with the pattern.

    z: layer
        target layer

    d: dict
        Has options.

    Return: layer
        work-in-progress
        Has material to select.
    """
    diameter = d[ok.CIRCLE_DIAMETER]
    w = int(diameter * 1.5)
    h = int(w * .8660254)
    j1 = pdb.gimp_image_new(w, h, fu.RGB)
    z1 = Lay.add(j1, "pattern")
    x = (w - diameter) // 2
    y = (h - diameter) // 2

    Sel.ellipse(
        j1,
        x, y,
        diameter, diameter,
        option=fu.CHANNEL_OP_REPLACE
    )
    Sel.fill(z1, (0, 0, 0))
    Mage.copy_all(j1)
    pdb.gimp_image_delete(j1)
    RenderHub.set_fill_context(fg.FILL_DICT)
    pdb.gimp_context_set_pattern("Clipboard Image")
    pdb.gimp_drawable_edit_bucket_fill(
        z,
        fu.FILL_PATTERN,
        X_IS_1, Y_IS_1
    )
    return z


def make_sel(one, frame_sel, filler_sel):
    """
    Modify the current selection with selected circles.

    Add the circle selection to the border selection
    within the bounds of the filler selection.

    one: One
        Has options.

    frame_sel:
        Is the frame around the image material.

    filler_sel:
        Is the space for the filler material.

    Return: state of selection
    """
    cat = Hat.cat
    j = cat.render.image
    d = one.d
    z = Lay.add(j, "Circles", parent=one.parent)
    z1 = RenderHub.do_rotated_layer(z, d, draw_circles)

    Sel.item(z1)
    Sel.invert(j)

    if Sel.is_sel(j):
        Sel.load(j, filler_sel, option=fu.CHANNEL_OP_INTERSECT)
        Sel.load(j, frame_sel, option=fu.CHANNEL_OP_ADD)
        Sel.grow(j, 1, 1)
        pdb.gimp_selection_feather(j, 1)

    pdb.gimp_image_remove_layer(j, z1)
    pdb.gimp_displays_flush()


class CirclePunch:
    """Add round holes to a frame that fits around a BorderLine frame."""

    @staticmethod
    def do(one):
        """
        Do the Circle Punch image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Circle Punch
        """
        return BorderLine.do(one, filler=lambda *q, **d: None, framer=make_sel)
