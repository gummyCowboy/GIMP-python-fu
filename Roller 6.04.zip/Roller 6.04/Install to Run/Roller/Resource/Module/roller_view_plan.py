#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_a_contain import Globe, PlanZ, Run
from roller_fu import hide_layer, show_layer, validate_item
from roller_one_extract import get_model_list_group


def do_plan_step(step_q):
    """
    Perform a Plan view run.

    step_q: list
        [Step key, ...]
    """
    def _refresh():
        # Remove selection because the marching ants are slow to draw.
        # Flushing the display will fail if ignored for too long.
        if Run.j:
            pdb.gimp_selection_none(Run.j)
            pdb.gimp_displays_flush()

    is_ice = Globe.hide_layer

    show_plan()
    hide_work()

    # [(navigation step key, AnyGroup)], 'step_q'
    for k, any_group in step_q:
        if is_ice:
            # Freeze GIMP's Layers dock and hide layers.
            if Run.j:
                pdb.gimp_image_freeze_layers(Run.j)
                is_ice = False
                Run.is_frozen = True

        any_group.do()
        _refresh()

    if Run.j:
        if validate_item(PlanZ.plan_group):
            Run.j.active_layer = PlanZ.plan_group
        if Run.is_frozen:
            pdb.gimp_image_thaw_layers(Run.j)
            Run.is_frozen = False
    _refresh()


def hide_work():
    """Hide the Work group."""
    j = Run.j
    if j and j.layers:
        z = j.layers[-1]
        if z and z.name != "Plan":
            hide_layer(z)

            model_group = get_model_list_group()
            q = model_group.work.get_model_folder_list()

            for i in q:
                hide_layer(i)
            pdb.gimp_displays_flush()


def show_plan():
    """Show the Plan group."""
    if validate_item(PlanZ.plan_group):
        show_layer(PlanZ.plan_group)
        pdb.gimp_displays_flush()
