#!/usr/bin/env python
# -*- coding: utf-8 -*-


def calc_factor(f, w):
    """
    Calculate a factored span.

    f: float
        Is factor variable.
        for example, the view image width

    w: numeric
        scale of factor

    Return: float
        factored span
    """
    return round(f * w)


def get_factor(a, w):
    """
    Calculate a factored span.

    a: tuple or numeric
        (fixed value, factor value)
        fixed value

    w: numeric
        span of factor
        for example, the view image height

    Return: float
        factored span
    """
    if isinstance(a, tuple):
        return a[0] + calc_factor(a[1], w)

    # float or int
    return calc_factor(a, w)


def get_factor_h(a):
    """
    Calculate the result for a number pair
    that uses the WIP image height as a factor.

    a: tuple, int, or float
        (fixed value, factor value)
        fixed value, from an earlier version

    Return: numeric
        of the same type as the fixed value
    """
    return get_factor(a, Wip.h)


def get_factor_w(a):
    """
    Calculate the number for a number pair
    that uses the WIP image width as a factor.

    a: tuple, int, or float
        (fixed value, factor value)
        fixed value, from an earlier version

    Return: numeric
        of the same type as the fixed value
    """
    return get_factor(a, Wip.w)


class Wip(object):
    """Define the Work-in-Progress image rectangle. Is a static class."""
    x = y = w = h = .0

    @staticmethod
    def center():
        """
        Calculate the center point of the rectangle.

        Return: tuple
            (x, y)
            center point
        """
        return Wip.x + (Wip.w / 2.), Wip.y + (Wip.h / 2.)

    @staticmethod
    def get_pos():
        """
        Fetch the rectangle's position.

        Return: tuple
            (x, y)
        """
        return Wip.x, Wip.y

    @staticmethod
    def get_rect():
        """
        Arrange its attributes in a rectangle order.

        Return: tuple
            (x, y, w, h)
        """
        return Wip.x, Wip.y, Wip.w, Wip.h

    @staticmethod
    def get_size():
        """
        Fetch the rectangle size.

        Return: tuple
            (w, h)
        """
        return Wip.w, Wip.h
