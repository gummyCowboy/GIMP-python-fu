#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_constant import ForGradient, OptionKey, SessionKey
from roller_backdrop_style import BackdropStyle
from roller_fu import Lay, Sel
from roller_gradient_fill import GradientFill
from roller_grid import Grid
import gimpfu as fu


class CoreDesign(BackdropStyle):
    """Create lines and soft gradients."""
    name = SessionKey.CORE_DESIGN
    row = column = 1

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        BackdropStyle.__init__(self, d, stat)

    def _do_gradient(self, e, n):
        """
        Draws a gradient.

        e: sub-session dict
        n: SessionKey
        """
        GradientFill(
                e,
                self.stat,
                name=n,
                layer_key=n,
                no_save=1
            )

    def _double(self, z, m=0):
        """
        Duplicate a layer and flip it depending on a flag.

        z: layer
        m: flag
            If it's true, the layer is flipped horizontally.
        """
        z1 = Lay.clone(self.stat.render, z)
        Lay.flip(z1, horz=m)
        return z1

    def _free_select(self, q):
        """
        Selects a rectangle.

        q: rectangle points
        """
        pdb.gimp_free_select(
            self.stat.render, len(q), q, fu.CHANNEL_OP_REPLACE, 1, 0, 0)

    def do(self, d):
        """
        Create the core-design.

        Creates the design on the active layer, and
        is part of an RenderHub class template.

        d: sub-session dict
        """
        e = deepcopy(ForGradient.LINEAR_DICT)
        j = self.stat.render
        ok = OptionKey
        w, h = self.stat.width, self.stat.height
        n = SessionKey.CORE_DESIGN

        e.update(d)

        odd = Grid((w, h), e[ok.ROW], e[ok.COLUMN])
        self.group = Lay.group(j, "Temp")

        # Calculate points using a relative points:
        h1 = h / 5

        # The triangle points down:
        q = 0, h1, w, h1, w / 2, h
        e[ok.START_X], e[ok.START_Y] = w / 2, h - 1
        e[ok.END_X], e[ok.END_Y] = w / 2, h1
        z = Lay.add(j, n, z=self.group)

        # Correct alpha inheritance with ‟color_fill”:
        Lay.color_fill(z, (255, 255, 255))
        self._do_gradient(e, n)
        self._free_select(q)

        z = Lay.get_active(j)
        z.mode = fu.LAYER_MODE_DARKEN_ONLY

        Sel.kleer(j, z, keep=1)
        self.shadow(z, op=50.)

        z1 = self._double(z)

        self.shadow(z1, op=50.)
        Sel.none(j)

        # horizontal:
        for r1 in range(0, e[ok.ROW], 2):
            _, y, _, h2 = odd.cell(r1, 0)
            Sel.rect(j, 0, y, w, h2)

        Lay.klear(j, z1)
        self.shadow(z1, op=50.)

        # vertical:
        for c1 in range(0, e[ok.COLUMN], 2):
            x, _, w1, _ = odd.cell(0, c1)
            Sel.rect(j, x, 0, w1, h)

        Lay.klear(j, z)
        self.shadow(z, op=50.)

        # Create background gradient:
        grad = e[ok.GRADIENT] = pdb.gimp_gradient_new(n)
        e[ok.OFFSET] = e[ok.REVERSE] = 0

        pdb.gimp_gradient_segment_set_right_color(
            grad, 0, (255, 255, 255), 100.)

        pdb.gimp_gradient_segment_set_left_color(grad, 0, (0, 0, 0), 100.)

        # left:
        e[ok.START_X], e[ok.START_Y], e[ok.END_X], e[ok.END_Y] = (
                0,
                h / 2,
                w / 2,
                h / 2
            )

        Lay.add(j, n, z=self.group, a=len(self.group.layers))
        self._do_gradient(e, n)

        z = Lay.get_active(j)
        q = 0, 0, 0, h, w / 2 + 1, h / 2

        self._free_select(q)
        Sel.kleer(j, z)

        self._double(z, m=1)

        # top:
        e[ok.START_X], e[ok.START_Y], e[ok.END_X], e[ok.END_Y] = (
            w / 2, 0, w / 2, h / 2)

        Lay.add(
                j,
                n,
                z=self.group,
                a=len(self.group.layers)
            )

        self._do_gradient(e, n)

        z = Lay.get_active(j)
        q = 0, 0, w, 0, w / 2, h / 2 + 1

        self._free_select(q)
        Sel.kleer(j, z)

        self._double(z)
        pdb.gimp_gradient_delete(grad)

        z = Lay.eat(j, self.group)

        Lay.clip(z)
        self.finish_style(z)
