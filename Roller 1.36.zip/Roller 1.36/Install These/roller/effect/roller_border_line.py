#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from random import randint as rnd
from roller_constant import (
        LayerKey,
        OptionKey,
        SessionKey
    )

from roller_drop_shadow import DropShadow
from roller_effect import Effect
from roller_fu import Lay, Sel
from roller_gradient_fill import GradientFill
from roller_shadow import Shadow
import gimpfu as fu


class BorderLine(Effect):
    """Create a metallic-like border."""
    name = SessionKey.BORDER_LINE
    REFLECTION = "Reflection"
    width_low, width_high = 3, 20

    def __init__(
                self,
                d,
                stat,
                name=SessionKey.BORDER_LINE,
                filler=None,
                has_filler_shadow=False,
                reflect=0,
                framer=None
            ):
        """
        d: dict
            sub-session dict

        stat: Stat
            global variables

        name: string
            effect name

        filler: function
            callback used to fill frame

        reflect: flag
            When true, a reflection is made for the filler.

        framer: function
            Use to add extra border material.
        """
        nk, sk = LayerKey, SessionKey
        self.filler = filler
        self.name = name
        self.framer = framer
        j = stat.render

        Effect.__init__(self, d, stat)
        d = self.stat.session[sk.BORDER_LINE]
        if self.has_room:
            if not stat.cancel:
                # Add light and color.
                self._metal_layer.mode = fu.LAYER_MODE_HARDLIGHT

                if Lay.search(j, nk.BACKDROP_LIGHT, is_err=0):
                    Lay.activate(j, self._metal_layer)
                    self._draw_bd_light(sk.BORDER_LINE)

                else:
                    Lay.activate(j, self._metal_layer)
                    GradientFill(
                            self.stat.session[sk.BORDER_GRADIENT],
                            stat,
                            name=sk.BORDER_GRADIENT,
                            layer_key=sk.BORDER_LINE,
                            sel=self.sel,
                            no_transparency=1
                        )

            if not stat.cancel:
                if reflect:
                    self._do_reflection()

            if not stat.cancel:
                z3 = Lay.search(self.active.format, sk.BORDER_LINE)

                # Trim gradient to border:
                Sel.isolate(j, z3, self.sel)
                Lay.order(j, self.edge, self.group, a=0)

                if not Lay.search(j, nk.BACKDROP_LIGHT, is_err=0):
                    # Add backdrop light:
                    Lay.add(
                        j,
                        Lay.get_layer_name(nk.BACKDROP_LIGHT, stat),
                        a=stat.format_count + stat.has_layout)

                    self._draw_bd_light(
                            nk.BACKDROP_LIGHT,
                            no_transparency=0
                        )

                    z = Lay.get_active(j)
                    z.mode = fu.LAYER_MODE_NORMAL
                    z.opacity = 6.
                self._blend_edges(self.edge)

            q = sk.BORDER_LINE, nk.IMAGE
            q1 = q + (self.name,) if has_filler_shadow else q

            if not stat.cancel:
                DropShadow({}, stat, n=sk.KEY_LIGHT_SHADOW, q=q1)

            if not stat.cancel:
                DropShadow({}, stat, n=sk.FILL_LIGHT_SHADOW, q=q1)

            if not stat.cancel:
                Shadow(
                        sk.IMAGE_EDGE_SHADOW,
                        stat,
                        q=(nk.IMAGE,),
                        inlay=1
                    )
            if not stat.cancel and self.name == sk.STAINED_GLASS:
                for k in (sk.KEY_LIGHT_SHADOW, sk.FILL_LIGHT_SHADOW):
                    self.do_behind_shadow(k, q, self.fill_sel)

    def _blend_edges(self, z):
        """
        Blend the color of the background with edge of the frame.

        z: layer with black and white edges
        """
        j = self.stat.render

        Sel.load(j, self.sel)
        Sel.shrink(j, 1)

        a = Sel.save(j)

        Sel.load(j, self.sel)
        Sel.load(j, a, opt=fu.CHANNEL_OP_SUBTRACT)

        edge_sel = Sel.save(j)

        Sel.none(j)
        Lay.kopy(j)

        z1 = Lay.paste(j, z)

        Lay.blur(j, z1, 6)
        Sel.load(j, edge_sel)
        Sel.kleer(j, z1, keep=1)
        z1.name = self.id + " Edge Reflection"

    def _do_reflection(self):
        """
        Create a light reflection for the fill layer.
        """
        j = self.stat.render
        z = Lay.clone(j, self.fill_layer)

        self._draw_bd_light(BorderLine.REFLECTION)

        z = Lay.get_active(j)

        Sel.isolate(j, z, self.fill_sel)
        z.mode, z.opacity = fu.LAYER_MODE_NORMAL, 6.
        z.name = self.id + " Reflection"

    def _draw_bd_light(self, k, no_transparency=1):
        """
        Draw the backdrop light layer.

        Force the gradient to draw on a grey layer in order to keep
        the gradient's transparency from destroying the border pixels.

        Use auto to skip user interaction.

        k: layer name key
        no_transparency: flag
            If it's true, the gradient will draw on a grey layer.
        """
        GradientFill(
                self.stat.session[SessionKey.BORDER_GRADIENT],
                self.stat,
                name=SessionKey.BORDER_GRADIENT,
                layer_key=k,
                no_save=1,
                no_transparency=no_transparency
            )

    def do(self, d):
        """
        Draw the border line effect.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        ok = OptionKey
        j = self.stat.render
        grp = self.group = Lay.group(j, self.id, z=self.active.format)
        z1 = Lay.add(j, self.id + " Frame", z=grp)

        # Create embossed border:
        Lay.color_fill(z1, (255, 255, 255))

        z2 = Lay.selectable(j, Lay.get_active_image(self.stat), d)

        Sel.item(j, z2)

        img_sel = Sel.save(j)

        Sel.grow(j, d[ok.BORDER_WIDTH], d[ok.BORDER_TYPE])

        if self.filler:
            # Create filler and outer selections:
            sel = Sel.save(j)

            Sel.grow(j, d[ok.WIDTH], d[ok.BORDER_TYPE])
            Sel.load(j, sel, opt=fu.CHANNEL_OP_SUBTRACT)
            Sel.grow(j, 1, d[ok.BORDER_TYPE])

            fill_sel = self.fill_sel = Sel.save(j)

            Sel.grow(
                    j,
                    max(int(d[ok.BORDER_WIDTH] / 3.5), 3),
                    d[ok.BORDER_TYPE]
                )

            Sel.load(j, fill_sel, opt=fu.CHANNEL_OP_SUBTRACT)
            Sel.load(j, sel, opt=fu.CHANNEL_OP_ADD)

        if self.framer:
            self.framer(d)

        Sel.load(j, img_sel, opt=fu.CHANNEL_OP_SUBTRACT)

        sel = self.sel = Sel.save(j)

        self.draw_sel(sel, z1)
        self.emboss(j, z1, d[ok.LIGHT_ANGLE], 50)
        Sel.isolate(j, z1, self.sel)
        Lay.anti(j, z1)
        Lay.bury(j, z2)

        # Strengthen edges:
        z2 = self.edge = Lay.clone(j, z1)
        z2.mode = fu.LAYER_MODE_OVERLAY
        z2.name = self.id + " Edge"
        z3 = self._metal_layer = Lay.add(
                j,
                Lay.get_layer_name(
                    SessionKey.BORDER_LINE, self.stat) + " Metal",
                z=grp
            )

        z4 = Lay.clone(j, z3)

        self.noise(z4, d)

        z4.mode = fu.LAYER_MODE_OVERLAY
        z4.name = self.id + " Bump"
        z4.opacity = 4.

        Sel.isolate(j, z4, self.sel)

        z5 = Lay.clone(j, z4)
        z5.mode = fu.LAYER_MODE_MULTIPLY
        z5.opacity = 11.
        z5.name = self.id + " Stain"

        pdb.plug_in_despeckle(j, z5, 3, 0, 50, 205)
        pdb.plug_in_despeckle(j, z5, 7, 0, 100, 155)
        Sel.isolate(j, z5, self.sel)

        if self.filler:
            z = self.fill_layer = self.filler(z5, d)
        if self.name == SessionKey.STAINED_GLASS:
            z.name = Lay.get_layer_name(
                self.name, self.stat) + " Pane"

            e = deepcopy(d)
            e[ok.ROTATE] = rnd(-45, 0)
            z1 = self.filler(z, e)
            z1.mode = fu.LAYER_MODE_DIFFERENCE
            z = self.fill_layer = Lay.merge(j, z1)
            z.opacity = 60.

            Sel.isolate(j, z, fill_sel)
            self.blur_bg(d, z)
