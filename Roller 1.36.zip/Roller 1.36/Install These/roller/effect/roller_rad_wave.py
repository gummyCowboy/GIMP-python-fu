#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import OptionKey, SessionKey
from roller_border_line import BorderLine
from roller_fu import Lay, Sel
from roller_grid import Grid
import gimpfu as fu


class RadWave(BorderLine):
    """Add a wire framework to BorderLine with waves."""
    name = SessionKey.RAD_WAVE
    width_low, width_high = 3, 20
    row = 1
    column = 1

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        BorderLine.__init__(
                self,
                d,
                stat,
                name=SessionKey.RAD_WAVE,
                framer=self.select_wave,
            )

    def select_wave(self, d):
        """
        Draw the wire framework.

        The framework will later mesh with BorderLine.

        Is part of the RenderHub class template.

        d: sub-session dict

        Return state:
            Add the selection to current selection.
        """
        j = self.stat.render
        ok = OptionKey
        border_sel = Sel.save(j)
        z = Lay.add(j, self.name, z=self.group)

        if d[ok.LINE_WIDTH]:
            pdb.gimp_context_set_brush_size(d[ok.LINE_WIDTH])

        Sel.none(j)
        pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
        pdb.gimp_context_set_opacity(100.)
        pdb.gimp_context_set_foreground((0, 0, 0))
        pdb.gimp_context_set_brush_aspect_ratio(0)
        pdb.gimp_context_set_brush_angle(0)
        pdb.gimp_context_set_brush_spacing(0.1)
        pdb.gimp_context_set_dynamics('Dynamics Off')
        pdb.gimp_context_set_brush_default_hardness()
        pdb.gimp_context_set_paint_method("gimp-paintbrush")

        # Set the layer size to the image size with ‟color_fill”:
        Lay.color_fill(z, (0, 0, 0))

        # composition border:
        Sel.all(j)

        if d[ok.COMPOSITION_BORDER_WIDTH]:
            Sel.shrink(j, d[ok.COMPOSITION_BORDER_WIDTH])
            Sel.invert(j)
            sel = Sel.save(j)

        else:
            sel = None

        Sel.all(j)
        Lay.klear(j, z)

        # row and column line:
        if d[ok.LINE_WIDTH]:
            odd = Grid(self.stat.size, d[ok.ROW], d[ok.COLUMN])
            for r in range(1, d[ok.ROW]):
                _, y, _, _ = odd.cell(r, 0)
                q = [0, y, self.stat.width, y]
                pdb.gimp_paintbrush_default(z, len(q), q)

            for c in range(1, d[ok.COLUMN]):
                x, _, _, _ = odd.cell(0, c)
                q = [x, 0, x, self.stat.height]
                pdb.gimp_paintbrush_default(z, len(q), q)

        pdb.plug_in_waves(
                j,
                z,
                d[ok.WAVE_AMPLITUDE],
                1,
                d[ok.WAVELENGTH],
                0,
                1
            )

        pdb.plug_in_whirl_pinch(j, z, d[ok.WHIRL], 0, 2.)

        if sel:
            Sel.load(j, sel)

        Sel.item(j, z)
        Sel.feather(j, 1)
        Sel.load(j, border_sel, opt=fu.CHANNEL_OP_ADD)
        Lay.bury(j, z)
