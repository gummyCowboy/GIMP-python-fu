#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from random import randint as rnd
from roller_constant import (
        ForCell,
        ForPreset,
        OptionKey,
        PickleKey,
        SessionKey
    )

import cPickle
import gimpfu as fu
import gtk
import os


class Base:
    """Has functions used my multiple classes."""

    @staticmethod
    def create_2d_table(r, c, a=0):
        """
        Return a 2D list.

        r, c: size of the table (integers)
        a: initial cell value
        """
        b = [a] * r

        for i in range(r):
            b[i] = [a] * c
        return b

    @staticmethod
    def rnd_col():
        """Return a tuple of integers containing random colors (r, g, b)."""
        return rnd(0, 255), rnd(0, 255), rnd(0, 255)

    @staticmethod
    def seal(a, b, c):
        """
        Limit a value to be between two numbers.

        a: value to limit
        b: minimum value
        c: maximum value
        """
        return max(min(c, a), b)


class OZ:
    """
    Has functions that work with the
    operating system or with files.
    """
    CELL_TABLE_NAME = (
            "Merge Cells",
            "Cell Margin",
            "Image Placement",
            "Image Property"
        )

    CELL_VALUE_W = 2, 4, 4, 5

    @staticmethod
    def ensure_dir(n):
        """
        Ensure a directory exists.

        n: path

        Return two flags.
            error flag
            proceed flag
        """
        go = err = 0

        if not os.path.isdir(os.path.dirname(n)):
            try:
                os.makedirs(os.path.dirname(n))

            except Exception as ex:
                err = 1
                Comm.show_err(ex)
                Comm.show_err("Roller is unable to store files at\n" + n)

        else:
            go = 1
        return err, go

    @staticmethod
    def get_preset_name(n, n1):
        """
        n: preset name
        n1: file specific id
        """
        return n + ForPreset.PRESET_SEPARATOR + n1 + u".pkl"

    @staticmethod
    def get_preset_path(n, n1, dir):
        """
        Return a path to a preset.

        n: preset name or key
        n1: file id
        dir: preset root directory
        """
        n2 = os.path.join(dir, n)
        n3 = os.path.join(n2, OZ.get_preset_name(n, n1))
        return n3

    @staticmethod
    def pass_version(d, e, is_format=0):
        """
        Add missing dictionary items.

        Remove invalid dictionary items.

        Verify cell data length.

        Will call itself recursively.

        d: dict that gets checked
        e: default dict
        is_format: flag: If it's true, the session dict is a format type.
        """
        keys = []

        # Remove old:
        for k in d:
            if k not in e:
                keys.append(k)

        [d.pop(k) for k in keys]

        # Add new:
        for k in e:
            if k not in d:
                d[k] = deepcopy(e[k])

        if is_format:
            # Checks the cell value lengths:
            for x, k in enumerate(ForCell.CELL_KEY_LIST):
                if d[k]:
                    invalid = 0
                    for r in range(len(d[k])):
                        for c in range(len(d[k][r])):
                            q = d[k][r][c]
                            if len(q) != OZ.CELL_VALUE_W[x]:
                                # The cell table is invalid:
                                invalid = 1
                                Comm.info_msg(
                                    "A cell table was invalid:\n"
                                    + d[OptionKey.NAME] + ": "
                                    + OZ.CELL_TABLE_NAME[x] + ",\n"
                                    "and was erased.")
                                break
                        if invalid:
                            break
                    if invalid:
                        d[k] = None

        # Do sub-dictionaries:
        for k in d:
            if k != SessionKey.WINDOW:
                if isinstance(d[k], dict):
                    OZ.pass_version(d[k], e[k])

    @staticmethod
    def pickle_dump(d):
        u"""
        Write a file using ‟cPickle”.

        d: dict

        Return a flag, which is set to true if the operation succeeded.
        """
        m = 0
        n = d[PickleKey.FILE]
        err, _ = OZ.ensure_dir(n)

        if not err:
            try:
                with open(n, "wb") as output_file:
                    cPickle.dump(d[PickleKey.DATA], output_file)
                m = 1

            except Exception as ex:
                Comm.show_err(ex)
                Comm.show_err("Roller is unable to save\n" + n)
        return m

    @staticmethod
    def pickle_load(d):
        u"""
        Read a ‟cPickle” type file.

        d: dict

        Return ‟e” as the data read by
        ‟cPickle” or None if the operation failed.
        """
        e = None
        n = d[PickleKey.FILE]
        err, go = OZ.ensure_dir(n)

        if go and not err:
            try:
                with open(n, "rb") as input_file:
                    e = cPickle.load(input_file)
                    if not isinstance(e, dict):
                        # failure:
                        e = {}

            except Exception as ex:
                if PickleKey.SHOW_ERROR in d:
                    if d[PickleKey.SHOW_ERROR]:
                        Comm.show_err(ex)
                        Comm.show_err("Roller is unable to load\n" + n)
        return e


class Comm:
    """ Has functions that are used to communicate."""

    @staticmethod
    def info_msg(n):
        """
        Use to output messages to the error console.

        n: message string
        """
        a = pdb.gimp_message_get_handler()

        pdb.gimp_message_set_handler(fu.ERROR_CONSOLE)
        fu.gimp.message(n)
        pdb.gimp_message_set_handler(a)

    @staticmethod
    def pop_up(parent, x, n, title):
        """
        Display a message dialog.

        parent: parent window
        x: message type index, (question, info)	 (0..1)
        title: window title
        n: message

        Return true (as 1) if the user responded with yes.
        """
        g = gtk.MessageDialog(
                parent=parent,
                flags=gtk.DIALOG_MODAL,
                type=(gtk.MESSAGE_QUESTION, gtk.MESSAGE_INFO)[x],
                buttons=(gtk.BUTTONS_YES_NO, gtk.BUTTONS_CLOSE)[x],
                message_format=n
            )

        g.set_title(title)

        a = g.run()

        g.destroy()
        return int(a == gtk.RESPONSE_YES)

    @staticmethod
    def show_err(a):
        """
        Post an error message to GIMP's Error Console.

        a: Exception or string
        """
        if not isinstance(a, basestring):
            a = repr(a)
        Comm.info_msg(a)
