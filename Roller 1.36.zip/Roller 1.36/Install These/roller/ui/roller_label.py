#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gtk


class RollerLabel:
    """This is a custom GTK Label."""

    def __init__(self, text, padding=None, align=(0, 0, 0, 0)):
        """
        text: string
            label text

        padding: tuple of int
            (top, bottom, left, right) margin

        align: tuple of float
            (top, bottom, left, right) space reservation (0..1)
        """
        self.label = gtk.Label(text)
        g = self.alignment = gtk.Alignment(*align)

        if padding:
            g.set_padding(*padding)
        g.add(self.label)

    def destroy(self):
        """Destroys the sub-widgets."""
        self.label.destroy()
        self.alignment.destroy()
