#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_base import Base
from roller_constant import ForLayer, LayerKey, OptionKey
from roller_layer_not_found import LayerNotFound
import gimpfu as fu
import math


class Lay:
    """These are functions used to manage image layers."""

    @staticmethod
    def activate(j, z):
        """
        Activate a layer.

        j: GIMP image
        z: layer
        """
        pdb.gimp_image_set_active_layer(j, z)

    @staticmethod
    def add(j, n, z=None, a=0, size=None):
        """
        Add a layer to an image.

        j: GIMP image
        n: layer name
        z: parent layer
        a: offset from top / parent
        size: size of the layer

        Return the new layer.
        """
        z1 = Lay.new(j, n, size=size)

        Lay.place(j, z1, z1=z, a=a)
        return z1

    @staticmethod
    def anti(j, z):
        """
        Perform anti-aliasing on a layer.

        j: GIMP image
        z: layer
        """
        pdb.plug_in_antialias(j, z)

    @staticmethod
    def blur(j, z, a):
        """
        Blur a layer.

        j: GIMP image
        z: layer
        a: blur amount
        """
        pdb.plug_in_gauss_rle2(j, z, a, a)

    @staticmethod
    def bury(j, z):
        """
        Remove a layer.

        j: GIMP image
        z: layer
        """
        pdb.gimp_image_remove_layer(j, z)

    @staticmethod
    def clip(z):
        """
        Clip off the edges of a layer that extend beyond the image size.

        z: layer
        """
        pdb.gimp_layer_resize_to_image_size(z)

    @staticmethod
    def color_fill(z, q):
        """
        Fill a layer with a color.

        z: layer
        q: color
        """
        pdb.gimp_context_set_foreground(q)
        z.fill(fu.FOREGROUND_FILL)

    @staticmethod
    def clone(j, z, has_layout=False):
        """
        Duplicate a layer.

        j: GIMP image
        z: layer

        Return the duplicated layer.
        """
        Sel.all(j)

        z1 = pdb.gimp_layer_copy(z, 0)
        m = len(z.children)

        if m:
            a = 0 + has_layout > 0

            # Activate the bottom layer:
            z2 = j.layers[len(j.layers) - 1]
            Lay.activate(j, z2)

        else:
            a = -1
            Lay.activate(j, z)

        Lay.place(j, z1, None, a=a)

        # Copies the mask, but it's not needed:
        if z1.mask:
            z1.remove_mask(fu.MASK_DISCARD)

        Sel.none(j)
        return z1

    @staticmethod
    def eat(j, z):
        """
        Merge a group of layers.

        z: group layer

        Return the new layer.
        """
        return pdb.gimp_image_merge_layer_group(j, z)

    @staticmethod
    def flip(z, horz=0):
        """
        Flip a layer horizontally or vertically.

        z: layer
        horz: flag: If it's true, the flip is horizontal.

        Return the layer.
        """
        a = fu.ORIENTATION_HORIZONTAL if horz else fu.ORIENTATION_VERTICAL
        return pdb.gimp_item_transform_flip_simple(z, a, True, 0)

    @staticmethod
    def get_active(j):
        """
        Return the active layer.

        j: GIMP image
        """
        return pdb.gimp_image_get_active_drawable(j)

    @staticmethod
    def get_active_format_layer(stat):
        """
        Return the active format layer.

        The active format layer is the top-most layer, except
        when there's a preview group. In that case, the format
        layer is below the preview group.

        stat: Stat
        """
        j, has_layout = stat.render, stat.has_layout
        z = j.layers[0 + has_layout]
        return z if hasattr(j, 'layers') else None

    @staticmethod
    def get_active_image(stat):
        """Returns the active image layer."""
        z = Lay.get_active_format_layer(stat)
        return Lay.search(z, LayerKey.IMAGE)

    @staticmethod
    def get_backdrop_layer(j):
        """
        Return the backdrop layer.

        j: GIMP image

        The backdrop layer is the bottom layer.
        """
        return j.layers[len(j.layers) - 1]

    @staticmethod
    def get_layer_name(n, stat):
        """
        Names a layer given its name key.

        Layers have a naming convention. Some layers have
        Unicode keys and some do not. The one's that don't have a key
        are given an ForLayer.ANY_U symbol.

        n: layer name
        stat: Stat
        """
        if n in ForLayer.LAYER_DICT:
            # keyed layers:
            n1 = Lay.get_active_format_layer(stat).name
            n1 = n1.replace(ForLayer.ANY_U, "")
            n1 = "{}: {}".format(n1, n)
            return ForLayer.LAYER_DICT[n] + " " + n1

        else:
            # non-keyed layers:
            return ForLayer.ANY_U + n

    @staticmethod
    def give_mask(z, masked):
        """
        Transfer a mask from one layer to another.

        z: Receives mask.
        masked: layer with the mask
        """
        if not masked.mask:
            Lay.masked(masked)
        if not z.mask:
            z.add_mask(Lay.mask(masked))

    @staticmethod
    def group(j, n, z=None, a=0):
        """
        Create a group layer.

        j: GIMP image
        n: name of group
        z: parent layer
        a: offset from the top

        Return the group layer.
        """
        z1 = pdb.gimp_layer_group_new(j)
        Lay.place(j, z1, z1=z, a=a)

        z1.name = n
        return z1

    @staticmethod
    def hide(z):
        """
        Make a layer invisible.

        z: layer
        """
        pdb.gimp_item_set_visible(z, 0)

    @staticmethod
    def invert(z):
        """
        Invert the colors on the layer.

        z: layer
        """
        pdb.gimp_drawable_invert(z, 0)

    @staticmethod
    def klear(j, z, no_sel=1):
        """
        Clear a layer's selection.

        j: GIMP image
        z: drawable
        no_sel: flag
            If it's true, then the selection is removed.
        """
        pdb.gimp_edit_clear(z)
        if no_sel:
            Sel.none(j)

    @staticmethod
    def kopy(j):
        """
        Copy a layer from an image.

        Leaves a copy in the buffer.

        j: GIMP image
        """
        pdb.gimp_edit_copy_visible(j)

    @staticmethod
    def mask(z):
        """
        z: layer

        Return a mask of a layer.
        """
        return pdb.gimp_layer_create_mask(z, fu.ADD_MASK_ALPHA)

    @staticmethod
    def masked(z):
        """
        A layer gets an alpha mask.

        z: layer
        """
        z.add_mask(Lay.mask(z))

    @staticmethod
    def merge(j, z):
        """
        Merge layer down. The target must be visible.

        j: GIMP image
        z: layer

        Return the merged layer.
        """
        return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    @staticmethod
    def move(z, x, y):
        """
        Move a layer to a set of coordinates.

        z: layer
        x, y: int, coordinate
        """
        pdb.gimp_layer_set_offsets(z, x, y)

    @staticmethod
    def new(j, n, size=0):
        """
        Create a layer.

        j: GIMP image to receive layer
        n: layer name
        size: size of the layer

        Return the layer.
        """
        if size:
            w, h = size

        else:
            w, h = j.width, j.height
        return pdb.gimp_layer_new(
                j,
                w,
                h,
                fu.RGBA_IMAGE,
                n,
                100,
                fu.LAYER_MODE_NORMAL
            )

    @staticmethod
    def offset(z, z1):
        """
        Return a child layer's offset.

        z: child layer
        z1: parent layer
        """
        for x, z2 in enumerate(z1.layers):
            if z == z2:
                return x
        return None

    @staticmethod
    def order(j, z, z1, a=0):
        """
        Move a layer into a different position.

        z: layer
        z1: parent
        a: offset from the top
        """
        pdb.gimp_image_reorder_item(j, z, z1, a)

    @staticmethod
    def paste(j, z):
        """
        Paste the content of the buffer.

        j: GIMP image
        z: paste to layer
        coordinate: x, y position, an iterable
            When it is, the new layer is moved to the coordinate.
        """
        a = pdb.gimp_edit_paste(z, 0)

        pdb.gimp_floating_sel_to_layer(a)
        return pdb.gimp_image_get_active_layer(j)

    @staticmethod
    def has_pixel(j, z):
        """
        Return the pixel count of a layer.

        Color count will return zero if the layer is completely transparent.

        j: GIMP i   mage
        z: layer
        """
        return pdb.plug_in_ccanalyze(j, z)

    @staticmethod
    def place(j, z, z1=None, a=0):
        """
        Insert a layer into an image.

        j: image
        z: layer to insert
        z1: group
        a: offset from the top
        """
        pdb.gimp_image_insert_layer(j, z, z1, a)

    @staticmethod
    def rotate(j, a):
        """
        Rotate the top layer.

        j: GIMP image
        a: rotation amount in degrees

        Return the transformed layer.
        """
        pdb.gimp_context_set_transform_direction(fu.TRANSFORM_FORWARD)
        pdb.gimp_context_set_transform_resize(fu.TRANSFORM_RESIZE_ADJUST)

        z = pdb.gimp_item_transform_rotate(
            j.layers[0], math.radians(a), 1, 0, 0)

        pdb.gimp_image_resize_to_layers(j)
        return z

    @staticmethod
    def search(z, n, is_err=1):
        """
        Return a layer found by its name.

        z: group layer
        n: layer name key
            Use to discover the layer's Unicode key character.

        is_err: flag
            If it's true, an error message
            will display when the layer is not found.
        """
        if n in ForLayer.LAYER_DICT:
            n1 = ForLayer.LAYER_DICT[n]
            for z1 in z.layers:
                # Decode byte string into unicode for comparison:
                n2 = z1.name.decode('utf-8')[0]

                if n1 == n2:
                    return z1
                if hasattr(z1, 'layers'):
                    z2 = Lay.search(z1, n, is_err=0)
                    if z2:
                        return z2
        if is_err:
            raise LayerNotFound("A layer was not found: " + n)

    @staticmethod
    def selectable(j, z, d):
        """
        Return a duplicate layer with an optional
        transform of no semi-transparent pixels.

        j: GIMP image
        z: layer
        d: dict with an OptionKey.INHERIT_OPACITY key
        """
        z = Lay.clone(j, z)

        if d[OptionKey.INHERIT_OPACITY]:
            pdb.plug_in_threshold_alpha(j, z, 0)
            Lay.anti(j, z)
        return z

    @staticmethod
    def show(z):
        """
        Makes a layer visible.

        z: layer
        """
        pdb.gimp_item_set_visible(z, 1)

    @staticmethod
    def text(j, n):
        """
        Create a new text layer.

        j: GIMP image
        n: text to display

        Return the new layer.
        """
        z = pdb.gimp_text_layer_new(j, n, 'Sans-serif', 11., fu.PIXELS)
        z.name = ForLayer.ANY_U + n
        return z

    @staticmethod
    def tidy(z):
        """
        Try to removes duplicate layer name extrata
        from a group's or image's layer names.

        z: layer or GIMP image
        """
        for z1 in z.layers:
            n = z1.name

            if "#" in n:
                n = z1.name = n[:n.index("#") - 1]

            if " copy" in n:
                z1.name = n.replace(" copy", "")
            if hasattr(z1, 'layers'):
                # recursive:
                Lay.tidy(z1)


class Sel:
    """Organizes selection functions."""

    @staticmethod
    def all(j):
        """
        Selects all of the image.

        j:  GIMP image
        """
        pdb.gimp_selection_all(j)

    @staticmethod
    def color(j, z, q):
        """
        Creates a selection based on color.

        j: GIMP image
        z: layer
        q: color
        """
        pdb.gimp_image_select_color(j, fu.CHANNEL_OP_REPLACE, z, q)

    @staticmethod
    def feather(j, a):
        """
        Feathers a selection.

        j: GIMP image
        a: amount of feather
        """
        pdb.gimp_selection_feather(j, a)

    @staticmethod
    def fill(z, q):
        """
        Fills a selection on a layer.

        z: layer to apply fill
        q: color
        """
        pdb.gimp_context_set_background(q)
        pdb.gimp_edit_bucket_fill(
            z,
            fu.BACKGROUND_FILL,
            fu.LAYER_MODE_NORMAL,
            100,
            0, 0, 0, 0)

    @staticmethod
    def grow(j, w, m):
        """
        Expands a selection.

        j: GIMP image
        w: expansion amount
        m: expansion type flag
        """
        if m:
            for _ in range(w):
                pdb.gimp_selection_grow(j, 1)

        else:
            pdb.gimp_selection_grow(j, w)

    @staticmethod
    def invert(j):
        """
        Invert a selection.

        j: GIMP image
        """
        if Sel.is_sel(j):
            pdb.gimp_selection_invert(j)

    @staticmethod
    def is_sel(j):
        """
        Return true if there is a selection.

        j: GIMP image
        """
        return not pdb.gimp_selection_is_empty(j)

    @staticmethod
    def isolate(j, z, sel):
        """
        Clear out everything but a selection.

        j: GIMP image
        z: layer
        sel: selection
        """
        Sel.load(j, sel)
        Sel.kleer(j, z)

    @staticmethod
    def item(j, z, op=fu.CHANNEL_OP_REPLACE):
        """
        Select an item.

        j: GIMP image
        z: layer
        op: selection operation
            replace, add, subtract
        """
        pdb.gimp_image_select_item(j, op, z)

    @staticmethod
    def kleer(j, z, keep=0):
        """
        Invert and clears a selection.

        z: layer
        j: GIMP image
        keep: flag: If it's true, then the selection is the same at the end.
        """
        if keep:
            sel = Sel.save(j)

        Sel.invert(j)

        if Sel.is_sel(j):
            Lay.klear(j, z)
        if keep:
            Sel.load(j, sel)

    @staticmethod
    def kopy(z):
        """
        Copy a selection.

        z: layer for selection
        """
        pdb.gimp_edit_copy(z)

    @staticmethod
    def load(j, sel, opt=fu.CHANNEL_OP_REPLACE):
        """
        Load a previously saved selection.

        j: GIMP image
        sel: selection
        opt: selection operation
            add, replace, subtract
        """
        pdb.gimp_image_select_item(j, opt, sel)

    @staticmethod
    def none(j):
        """
        Remove the selection.

        j: GIMP image
        """
        pdb.gimp_selection_none(j)

    @staticmethod
    def rect(j, x, y, w, h, mode=fu.CHANNEL_OP_ADD):
        """
        Draw a selection rectangle.

        j: GIMP image
        """
        pdb.gimp_image_select_rectangle(
            j, mode, x, y, Base.seal(w, 0, j.width), Base.seal(h, 0, j.height))

    @staticmethod
    def save(j):
        """
        Save the selection in memory.

        j: GIMP image

        Return the saved selection id.
        """
        return pdb.gimp_selection_save(j)

    @staticmethod
    def shrink(j, a):
        """
        Shrinks as in contracts a selection.

        j: GIMP image
        a: amount to shrink
        """
        pdb.gimp_selection_shrink(j, a)
