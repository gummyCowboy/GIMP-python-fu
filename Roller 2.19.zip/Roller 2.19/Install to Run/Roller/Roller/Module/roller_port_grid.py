#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_cell_table import CellTable
from roller_grid_deck import GridDeck
from roller_one_constant import (
    ForFormat as ff,
    FormatKey as fk,
    ForRender,
    ForWidget as fw,
    SessionKey as sk,
    UIKey
)
from roller_one_preset import Preset
from roller_one_tip import Tip
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_check_button import RollerCheckButton
from roller_widget_combo import RollerComboBox
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_radio import RollerRadioList
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable
import gtk

FIXED = 'fixed'
GRID_LABEL = "Row: {}, Column: {}"
GROUP_PAD = 2, 0, 4, fw.MARGIN
ROX_INDEX, COLUMN_INDEX = 0, 1
SHAPE_LIST_TYPE = ff.Grid.Index.CELL_COUNT, ff.Grid.Index.CELL_SIZE


class PortGrid(Port):
    """Let the user define the cell table properties."""

    def __init__(self, d, g):
        """
        Start it up.

        d: dict
            Has init values.

        g: RollerButton
            Is responsible.
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self._button = g
        self.color = g.color
        self.grid_dict = g.get_value()
        self.form, self._f_x = g.get_format_info()
        self.session = g.get_session_dict()

        # Remember the shape in each grid type:
        self._shape_value_list = ["", "", ""]
        Port.__init__(self, d)

    def _draw_cell_count_group(self, g):
        """
        Draw the cell count group.

        g: GTK container
            to receive group
        """
        d = dict(
            limit=(1, 100),
            precision=0,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change
        )
        q = (
            [
                "Row Count:",
                RollerSlider,
                dict(d, key=fk.Cell.Grid.ROW, tooltip=Tip.GRID_BY_COUNT)
            ],
            [
                "Column Count:",
                RollerSlider,
                dict(d, key=fk.Cell.Grid.COLUMN)
            ]
        )
        d = RollerTable.create(container=g, q=q, color=self.color)
        self.controls += [d[i] for i in d]

    def _draw_cell_shape_group(self, g):
        """
        Draw the cell shape group.

        g: VBox
            container for the widgets
        """
        self.reduce_color()

        shape_box = gtk.VBox()
        box = RollerEventBox(self.color)

        box.add(shape_box)
        g.add(box)
        shape_box.add(
            RollerLabel(
                padding=GROUP_PAD,
                text="Cell Shape Option:"
            )
        )
        d = dict(
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change
        )
        q = (
            [
                "Cell Shape:",
                RollerComboBox,
                dict(
                    d,
                    combo_list=ff.Cell.Shape.SHAPE_LIST,
                    key=fk.Cell.Grid.SHAPE,
                    tooltip=Tip.GRID_SHAPE
                )
            ],
            [
                "Table Start:",
                RollerCheckButton,
                dict(
                    d,
                    key=fk.Cell.Grid.SHIFT,
                    text="Shift",
                    tooltip=Tip.GRID_SHIFT
                )
            ]
        )
        d = RollerTable.create(
            container=shape_box,
            q=q,
            color=self.color
        )
        self._shape_combo = d[fk.Cell.Grid.SHAPE]
        self._shift_button = d[fk.Cell.Grid.SHIFT]
        self.controls += [d[i] for i in d]

    def _draw_cell_size_group(self, g):
        """
        Draw the cell size group.

        g: GTK container
            to receive group
        """
        d = dict(
            limit=(1, ForRender.MAX_SIZE),
            precision=0,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change
        )
        q = (
            [
                "Row Height:",
                RollerSlider,
                dict(
                    d,
                    key=fk.Cell.Grid.ROW_HEIGHT,
                    tooltip=Tip.GRID_FIXED_SIZE
                )
            ],
            [
                "Column Width:",
                RollerSlider,
                dict(d, key=fk.Cell.Grid.COLUMN_WIDTH)
            ]
        )
        d = RollerTable.create(container=g, q=q, color=self.color)
        self._column_width = d[fk.Cell.Grid.COLUMN_WIDTH]
        self._row_height = d[fk.Cell.Grid.ROW_HEIGHT]
        self.controls += [d[i] for i in d]

    def _draw_choices(self, g):
        """
        Draw the choices group.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        label = ff.Grid.TYPE_LIST
        box = RollerBox(
            gtk.VBox,
            align=(1, 1, 1, 1),
            padding=(w // 2, w, 0, 0)
        )

        g.add(box)

        g = self._radio_list = RollerRadioList(
            container=box,
            key=fk.Cell.Grid.TYPE,
            labels=label,
            on_widget_change=self._on_list_change,
            padding=(1, 0, w, w)
        )
        self.controls += [g]

    def _draw_options(self, g):
        """
        Draw the option groups for the radio-list choices.

        g: VBox
            container for widgets
        """
        option_box = gtk.VBox()

        g.add(option_box)

        g1 = self._radio_list
        g1.switch_group_box = option_box
        process = (
            self._draw_cell_count_group,
            self._draw_cell_size_group,
            self._draw_shape_count_group
        )
        label = ff.Grid.TYPE_LIST

        for x, p in enumerate(process):
            vbox = gtk.VBox()

            g1.group_box.append(vbox)

            if label[x]:
                vbox.add(
                    RollerLabel(
                        padding=GROUP_PAD,
                        text=label[x] + " Options:",
                    )
                )
            p(vbox)

        self._draw_table_option_group(g)
        self._draw_cell_shape_group(g)

    def _draw_preset_group(self, g):
        """
        Draw a preset group for the cell grid.

        g: VBox
            container for widgets
        """
        self.preset = Preset(
            container=g,
            key=fk.Cell.Grid.CELL_GRID,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_preset_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_shape_count_group(self, g):
        """
        Draw the shape count group.

        g: GTK container
            to receive group
        """
        d = dict(
            limit=(1, 100),
            precision=0,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change
        )
        q = (
            [
                "Horizontal Shape Count:",
                RollerSlider,
                dict(
                    d,
                    key=fk.Cell.Grid.HORIZONTAL,
                    tooltip=Tip.GRID_NORMALIZED
                )
            ],
            [
                "Vertical Shape Count:",
                RollerSlider,
                dict(d, key=fk.Cell.Grid.VERTICAL)
            ]
        )
        d = RollerTable.create(container=g, q=q, color=self.color)
        self.controls += [d[i] for i in d]

    def _draw_table_option_group(self, g):
        """
        Draw the table option group.

        g: VBox
            container for the widgets
        """
        self.reduce_color()

        shape_box = gtk.VBox()
        box = self._table_box = RollerEventBox(self.color)

        box.add(shape_box)
        g.add(box)
        shape_box.add(
            RollerLabel(
                padding=GROUP_PAD,
                text="Cell Table Option:"
            )
        )

        text = GRID_LABEL.format(1, 1)
        q = (
            [
                "Table Position:",
                RollerComboBox,
                dict(
                    combo_list=ff.Grid.Pin.PIN_LIST,
                    key=fk.Cell.Grid.PIN,
                    on_key_press=self.on_key_press,
                    on_widget_change=self.on_widget_change,
                    tooltip=Tip.GRID_PIN
                )
            ],
            [
                "",
                RollerLabel,
                dict(
                    align=(0, 0, .9, 0),
                    key='label',
                    text=text,
                    tooltip=Tip.GRID_LABEL
                )
            ]
        )
        d = RollerTable.create(
            container=shape_box,
            q=q,
            color=self.color
        )
        self._grid_label = d['label']
        self.controls += [d[fk.Cell.Grid.PIN]]

    def _on_list_change(self, *q):
        """
        Update the row and column label when the user changes grid type.

        q: iterable
            of arguments
        """
        self._update_fixed_grid_label()
        self._update_table_box()
        self._update_shape_list()
        self.on_widget_change(self._radio_list)
        self.on_list_change(*q)

    def _update_fixed_grid_label(self):
        """
        Update the row and column counts in the fixed-cell size group.

        g: Widget
            fixed-size type widget
        """
        d = self.form

        # Update format dict:
        d[fk.Cell.Grid.CELL_GRID] = self.preset.get_value()

        r, c = GridDeck.calc_grid_division(d, self.stat.render.size)

        self._grid_label.widget.set_text(GRID_LABEL.format(r, c))
        self._grid_label.show()

    def _update_shape_list(self, *_):
        """Update the contents of the shape list."""
        Port.load_count += 1
        x = self._radio_list.get_value()

        if x in SHAPE_LIST_TYPE:
            self._shape_combo.populate_list(ff.Cell.Shape.SHAPE_LIST)

        else:
            self._shape_combo.populate_list(ff.Cell.Shape.NORMAL_LIST)

        self._shape_combo.set_value(self._shape_value_list[x])
        Port.load_count -= 1

    def _update_shift_button(self, *_):
        """
        Update the visibility of the Shift CheckButton.
        It is valid if the shape is a double-space type.
        """
        if self._shape_combo.get_value() in ff.Cell.Shape.DOUBLE:
            self._shift_button.show()

        else:
            self._shift_button.hide()
        self.roller_window.resize()

    def _update_table_box(self, *_):
        """Update the visibility of the table option group."""
        if self._radio_list.get_value() == ff.Grid.Index.CELL_COUNT:
            self._table_box.hide()
            self.roller_window.resize()
        else:
            self._table_box.show()

    def do_accept(self, *_):
        """
        Accept the grid settings.

        Return: true
            The key-press is handled.
        """
        return self.do_accept_callback(self.preset.get_value())

    def do_cancel(self, *_):
        """
        Cancel the port.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = (
            self._draw_choices,
            self._draw_options,
            self._draw_preset_group,
            self.draw_process_layout_group
        )
        group_name = "Cell Grid Type", "", "Cell Grid Preset", "Process"

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if group_name[x]:
                vbox.pack_start(
                    RollerLabel(
                        padding=GROUP_PAD,
                        text=group_name[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()

            if x in (0, 2):
                hbox = gtk.HBox()
                g.pack_start(hbox, expand=True)
            hbox.pack_start(box, expand=True)

        self.preset.widget_list = self.controls

        self.preset.load_preset(fw.UNDEFINED, self.grid_dict)

        a = Port.load_count
        Port.load_count = 0

        self._shift_button.connect('expose-event', self._update_shift_button)
        self._table_box.connect('expose-event', self._update_table_box)
        self.on_list_change(self._radio_list)
        self._update_fixed_grid_label()

        Port.load_count = a
        n = self._shape_combo.get_value()
        for x in range(3):
            self._shape_value_list[x] = n

    def on_preset_change(self, g):
        """
        Call when a preset is loaded.

        g: RollerComboBox
            Is responsible.
            not used
        """
        self.on_list_change(self._radio_list)

    def on_widget_change(self, g):
        """
        Call when a widget is changed.

        g: Widget
            Is responsible.
        """
        if not Port.load_count:
            if hasattr(g, 'key'):
                self._update_fixed_grid_label()
                if g.key == fk.Cell.Grid.SHAPE:
                    x = self._radio_list.get_value()
                    self._shape_value_list[x] = self._shape_combo.get_value()

            self._update_shift_button()
            self.preset.preset_is_undefined()

    def show_layout(self, *_):
        """Show a layout sketch-up."""
        self.form[fk.Cell.Grid.CELL_GRID] = self.preset.get_value()
        self.session[sk.FORMAT_LIST][self._f_x] = self.form

        CellTable.adjust_cell_tables(self.form, self.stat)
        self.stat.layout.show(self.session)
