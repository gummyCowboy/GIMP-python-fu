#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_one_constant import (
    ForFormat as ff,
    ForWidget as fw,
    UIKey
)
from roller_one_tip import Tip
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_radio import RollerRadioList
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable as rt
import gtk

OPTION_LABEL = (
    "Locked",
    "Trim",
    "Filled Cell",
    "Cover",
    "Fixed Value",
    "Fraction of Image Size",
    "Crop"
)


class PortResize(Port):
    """
    Offer different methods for resizing an image when placing it in a cell.
    """

    def __init__(self, d, g):
        """
        Draw widgets.

        d: dict
            with init values

        g: RollerButton
            with resize info
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self._button = g
        self.color = g.color
        Port.__init__(self, d)

    @staticmethod
    def _draw_cover_group(g):
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text="If necessary, the image is resized\n"
            "so that it can fill the cell to the\n"
            "greatest degree. The method may\n"
            "enlarge the image with a locked\n"
            "aspect ratio. In the process, a\n"
            "portion of the image may be clipped."
        )
        g.pack_start(g1, expand=True)

    def _draw_crop_value_group(self, g):
        """
        Draw the crop value group.

        g: GTK container
            to receive group
        """
        d = dict(
            color=self.color,
            container=g,
            limit=(0, 1000000),
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            precision=0
        )
        d['q'] = (
            ["X-Offset:", RollerSlider, dict(d, key='x-offset')],
            ["Y-Offset:", RollerSlider, dict(d, key='y-offset')],
            ["Width:", RollerSlider, dict(d, key='width')],
            ["Height:", RollerSlider, dict(d, key='height')]
        )
        e = rt.create(**dict(d))
        self._crop_dict = e
        s = self.stat.render.size

        e['x-offset'].set_value(0.)
        e['y-offset'].set_value(0.)
        e['width'].set_value(s[0])
        e['height'].set_value(s[1])
        e['height'].set_tooltip_text(Tip.RESIZE_CROP_VALUE)
        self.keep([e[i] for i in e])

    @staticmethod
    def _draw_filled_cell_group(g):
        """
        Draw the filled cell options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text="The image is resized so that it\n"
            "fills the cell. Its aspect ratio\n"
            "will be that of the cell rectangle."
        )
        g.pack_start(g1, expand=True)

    def _draw_fixed_value_group(self, g):
        """
        Draw the fixed value group.

        g: GTK container
            to receive group
        """
        d = dict(
            color=self.color,
            container=g,
            limit=(0, 1000000),
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            precision=0
        )

        d['q'] = (
            ["Width:", RollerSlider, dict(d, key='width')],
            ["Height:", RollerSlider, dict(d, key='height')]
        )
        e = rt.create(**dict(d))
        self._fixed_dict = e
        s = self.stat.render.size

        e['width'].set_value(s[0])
        e['height'].set_value(s[1])
        e['height'].set_tooltip_text(Tip.RESIZE_FIXED_VALUE)
        self.keep([e[i] for i in e])

    def _draw_fraction_value_group(self, g):
        """
        Draw the fraction value group.

        g: GTK container
            to receive group
        """
        d = dict(
            color=self.color,
            container=g,
            limit=(.000001, 2.),
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            precision=6
        )
        d['q'] = (
            ["Width:", RollerSlider, dict(d, key='width')],
            ["Height:", RollerSlider, dict(d, key='height')]
        )
        e = self._fraction_dict = rt.create(**dict(d))

        e['height'].set_value(1.)
        e['width'].set_value(1.)
        e['width'].set_tooltip_text(Tip.RESIZE_FRACTION_VALUE)
        self.keep([e[i] for i in e])

    @staticmethod
    def _draw_locked_group(g):
        """
        Draw the locked-proportions options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text="The images proportions are locked\n"
            "and a best fit is applied if necessary.\n"
            "The image is not enlarged."
        )
        g.pack_start(g1, expand=True)

    @staticmethod
    def _draw_trim_group(g):
        """
        Draw the Trim options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text="If necessary, the image is resized so that\n"
            "it can fill the cell to the greatest degree\n"
            "without enlarging or stretching the image. In\n"
            "the process, a side of the image may be trimmed."
        )
        g.pack_start(g1, expand=True)

    def _draw_resize_choices(self, g):
        """
        Draw the resize choices group.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        label = OPTION_LABEL
        box = RollerBox(
            gtk.VBox,
            align=(1, 1, 1, 1),
            padding=(w // 2, w, 0, 0)
        )

        g.add(box)

        g = self._radio_list = RollerRadioList(
            container=box,
            key='not_used',
            labels=label,
            on_widget_change=self.on_list_change,
            padding=(1, 0, w, w)
        )
        self.keep(g.buttons)

    def _draw_options(self, g):
        """
        Draw the option groups for radio-list choices.

        g: VBox
            container for widgets
        """
        g1 = self._radio_list
        g1.switch_group_box = g
        process = (
            PortResize._draw_locked_group,
            PortResize._draw_trim_group,
            PortResize._draw_filled_cell_group,
            PortResize._draw_cover_group,
            self._draw_fixed_value_group,
            self._draw_fraction_value_group,
            self._draw_crop_value_group
        )
        label = OPTION_LABEL
        for x, p in enumerate(process):
            vbox = gtk.VBox()

            g1.group_box.append(vbox)

            if label[x]:
                vbox.add(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=label[x] + " Options:"
                    )
                )
            p(vbox)

    def _get_numeric(self, x):
        """
        Call to get a numeric setting.

        Return:
            string
            the Numeric Name combobox choice.
        """
        if x == ff.Place.FIXED_VALUE_INDEX:
            d = self._fixed_dict
            return \
                Form.FIXED_WIDTH + str(d['width'].get_value()) + \
                ", " + \
                Form.FIXED_HEIGHT + str(d['height'].get_value())

        elif x == ff.Place.FRACTION_VALUE_INDEX:
            d = self._fraction_dict
            return \
                Form.FRACTION_WIDTH + str(d['width'].get_value()) \
                + ", " + \
                Form.FRACTION_HEIGHT + str(d['height'].get_value())
        else:
            d = self._crop_dict
            return \
                Form.X_OFFSET + str(d['x-offset'].get_value()) + ", " + \
                Form.Y_OFFSET + str(d['y-offset'].get_value()) + ", " + \
                Form.CROP_WIDTH + str(d['width'].get_value()) + ", " + \
                Form.CROP_HEIGHT + str(d['height'].get_value())

    def _set_numeric_widget(self):
        """
        Set a numeric-type widgets with the value from the resize button.
        """
        q, type_x = Form.strip_numeric_value(
            self._button.get_value()
        )

        if type_x == ff.Place.FRACTION_VALUE_INDEX:
            d = self._fraction_dict

        elif type_x == ff.Place.FIXED_VALUE_INDEX:
            d = self._fixed_dict

        else:
            d = self._crop_dict

        for x, i in enumerate(d):
            d[i].set_value(q[x])
        return type_x

    def do_accept(self, *_):
        """
        Accept the resize setting.

        Return: true
            The key-press is handled.
        """
        x = self._radio_list.get_value()

        if x in ff.Place.RESIZE_NUMERIC_INDEX:
            n = self._get_numeric(x)

        else:
            n = ff.Place.TYPE[x]
        return self.do_accept_callback(n)

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for widgets
        """
        q = (
            self._draw_resize_choices,
            self._draw_options,
            self.draw_process_group
        )
        n = "Choose a Resize Method", "", ""

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if n[x]:
                vbox.pack_start(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=n[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()

            if x == 0:
                hbox = gtk.HBox()
                g.pack_start(hbox, expand=False)

            if x < 2:
                hbox.pack_start(box, expand=False)
            else:
                g.pack_start(box, expand=False)

        a = Port.load_count
        Port.load_count = 0
        b = self._button.get_value()

        if b in ff.Place.TYPE:
            x = ff.Place.TYPE.index(b)

        else:
            x = self._set_numeric_widget()

        self._radio_list.set_value(x)
        self.on_list_change(self._radio_list)
        Port.load_count = a

    def on_widget_change(self, *_):
        """Call when a widget is changed."""
        return
