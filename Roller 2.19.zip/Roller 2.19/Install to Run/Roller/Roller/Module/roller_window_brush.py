#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import PortKey, UIKey, WindowKey
from roller_port_brush import PortBrushChoice
from roller_window import RollerWindow


class RWBrushChoice(RollerWindow):
    """Is a GTK dialog for defining brush settings."""
    def __init__(self, g):
        """
        Create a window.

        g: OptionButton
            Has values.
        """
        d = {
            UIKey.STAT: g.stat,
            UIKey.WINDOW: g.win.win,
            UIKey.WINDOW_KEY: WindowKey.BRUSH_CHOOSER,
            UIKey.WINDOW_TITLE: "Define Brush Settings"
        }
        self._button = g

        RollerWindow.__init__(self, d)
        d.update(
            {
                UIKey.ON_ACCEPT: self.do_accept,
                UIKey.ON_CANCEL: self.do_cancel,
                UIKey.WINDOW: self,
                UIKey.PORT_KEY: PortKey.NOT_USED
            }
        )

        self.port = PortBrushChoice(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            GTK, it is done.
        """
        return self.close()

    def do_accept(self, value):
        """
        Accept the port's choices.

        value: string
            for image button

        Return: true
            GTK, it is done.
        """
        # the return on investment:
        self._button.set_value(value)
        # Exit:
        return self.close()
