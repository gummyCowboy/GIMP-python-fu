#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import Rect
from roller_one_constant import (
    BorderKey as bo,
    CellKey,
    ForFormat as ff,
    ForLayout,
    FormatKey as fk,
    FreeCellKey as fck,
)
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

em = Fu.Emboss
gf = Fu.GradientFill
pdb = fu.pdb
BORDER = "Cell Border"
ELLIPSE = (
    ff.Cell.Shape.ELLIPSE_HORIZONTAL,
    ff.Cell.Shape.ELLIPSE_VERTICAL,
    ff.Cell.Shape.CIRCLE_HORIZONTAL,
    ff.Cell.Shape.CIRCLE_VERTICAL,
    ff.Cell.Shape.ELLIPSE
)
FREE_CELL_NAME = "Free Range Cell Border"


class Border:
    """Manage Border operation."""

    def __init__(self, session, d, x, stat, parent, is_layout=False):
        """
        Process a format's border needs.

        session: dict
            of session

        d: dict
            of format

        x: int
            format index

        stat: Stat
            globals

        parent: layer
            format group

        is_layout: bool
            Is true when the caller is performing a layout preview.
        """
        self.stat = stat
        self.session = session
        stat = self.stat
        j = stat.render.image
        self.f_x = x
        self.is_layout = is_layout
        is_merge = self.is_merge = Form.is_merge_cells(d)
        self.parent = parent

        if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
            self._do_free_range(j, d)
            self._do_grid(j, d, is_merge)

        else:
            self._do_grid(j, d, is_merge)
            self._do_free_range(j, d)
        self._do_layer(j, d, parent)

    def _add_border_layer(self, j, d, n=BORDER, group=None):
        """
        Add a border layer to the bottom of the format group.

        j: GIMP image
            Is render.

        d: dict
            of border

        Return: layer
            for border material
        """
        if not group:
            group = self.parent

        z = Lay.add(
            j,
            Lay.get_layer_name(n, parent=group),
            parent=group,
            offset=len(group.layers) + 1
        )
        z.opacity = d[bo.OPACITY]
        return z

    def _do_common_ellipse_grid(self, j, d, e):
        """
        Draw border for a square grid
        without merged cells or per cell.

        j: GIMP image
            Is render.

        d: dict
            of format

        e: dict
            of cell grid border
        """
        f_x = self.f_x
        layout = self.stat.layout
        row, column = layout.get_division(f_x)
        w = e[bo.BORDER_WIDTH]
        w1 = w // 2
        double_type = Form.get_double_space_type(d)
        grid_sel = None

        for r in range(row):
            for c in range(column):
                # 'm' is true when there is a valid cell:
                m = True

                if double_type:
                    m = Form.is_double_space_cell(r, c, double_type)
                if m:
                    Form.select_shape(j, layout.get_plaque(f_x, r, c))
                    Sel.grow(j, w1, 1)

                    sel = pdb.gimp_selection_save(j)

                    pdb.gimp_selection_shrink(j, w)

                    if Sel.is_sel(j):
                        sel1 = pdb.gimp_selection_save(j)

                    else:
                        sel1 = None

                    # Make border selection by subtracting
                    # the inner selection from the outer:
                    Sel.load(j, sel)

                    if sel1:
                        Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                    if grid_sel:
                        Sel.load(j, grid_sel, option=fu.CHANNEL_OP_ADD)
                        pdb.gimp_image_remove_channel(j, grid_sel)

                    grid_sel = pdb.gimp_selection_save(j)

                    pdb.gimp_image_remove_channel(j, sel)
                    pdb.gimp_image_remove_channel(j, sel1)
        if grid_sel:
            Sel.load(j, grid_sel)
            self._do_ellipse_sel(j, e)
            pdb.gimp_image_remove_channel(j, grid_sel)

    def _do_common_rect_grid(self, j, d):
        """
        Do a common border for a rectangular cell grid.

        j: GIMP image
            Is render.

        d: dict
            of cell grid border
        """
        f_x = self.f_x
        layout = self.stat.layout
        row, column = layout.get_division(f_x)
        cell = layout.get_merge_cell_rect(f_x, 0, 0)
        left, top = cell.x, cell.y
        cell = layout.get_merge_cell_rect(f_x, row - 1, column - 1)
        right, bottom = cell.x + cell.w, cell.y + cell.h
        x = left
        h1 = d[bo.BORDER_WIDTH]
        h2 = h1 - h1 // 2
        w1 = right - left + h1

        for r in range(row):
            cell = layout.get_merge_cell_rect(f_x, r, 0)
            Sel.rect(j, x - h2, cell.y - h2, w1, h1)

        Sel.rect(j, x - h2, cell.y + cell.h - h2, w1, h1)

        w1, w2 = h1, h2
        h1 = bottom - top + w1
        y = top

        for c in range(column):
            cell = layout.get_merge_cell_rect(f_x, 0, c)
            Sel.rect(j, cell.x - w2, y - w2, w1, h1)

        Sel.rect(j, cell.x + cell.w - w2, y - w2, w1, h1)
        self._process_selection(self._add_border_layer(j, d), d)

    def _do_common_polygon_grid(self, j, d, e):
        """
        Do a common border for a polygon, not rectangular, cell grid.

        j: GIMP image
            Is render.

        d: dict
            of format

        e: dict
            of cell grid border
        """
        # Preserve:
        foreground = pdb.gimp_context_get_foreground()

        f_x = self.f_x
        layout = self.stat.layout
        row, column = layout.get_division(f_x)
        group = self._make_group(j)
        z = self._add_border_layer(j, e, group=group)
        double_type = Form.get_double_space_type(d)
        a = set()
        color = self._get_color(e)
        w = e[bo.BORDER_WIDTH]
        w1 = w // 2
        w2 = w - w1

        RenderHub.set_brush_details()
        pdb.gimp_context_set_brush_size(w)
        pdb.gimp_context_set_foreground(color)
        pdb.gimp_context_set_stroke_method(fu.STROKE_LINE)

        for r in range(row):
            for c in range(column):
                # 'm' is true when there is a valid cell:
                m = True

                if double_type:
                    m = Form.is_double_space_cell(r, c, double_type)
                if m:
                    b = layout.get_plaque(f_x, r, c)
                    for x, i in enumerate(range(len(b) - 1)):
                        if not x % 2:
                            if x < len(b) - 3:
                                if b[x] < b[x + 2]:
                                    a.add((b[x], b[x + 1], b[x + 2], b[x + 3]))
                                else:
                                    a.add((b[x + 2], b[x + 3], b[x], b[x + 1]))
                            else:
                                a.add((b[x], b[x + 1], b[0], b[1]))
        for x, y, x1, y1 in a:
            if x != x1 and y != y1:
                pdb.gimp_paintbrush(
                    z,
                    0.,
                    4,
                    (x, y, x1, y1),
                    fu.PAINT_CONSTANT,
                    .0
                )
            else:
                # Use selection to skip smudgy antialiasing:
                Sel.polygon(
                    j,
                    (
                        x - w1, y - w1,
                        x + w2, y + w2,
                        x1 + w2, y1 + w2,
                        x1 - w1, y1 - w1
                    )
                )
                Sel.fill(z, self._get_color(e))
                pdb.gimp_selection_none(j)

        z = Lay.merge_group(
            group,
            n=Lay.get_layer_name(bo.CELL_BORDER, parent=self.parent)
        )
        z.opacity = e[bo.OPACITY]

        Sel.item(z)
        self._process_selection(z, e, is_fill=0)
        # Restore:
        pdb.gimp_context_set_foreground(foreground)

    def _do_common_square_grid(self, j, d):
        """
        Do a common border for a square cell grid.

        j: GIMP image
            Is render.

        d: dict
            of cell grid border
        """
        f_x = self.f_x
        layout = self.stat.layout
        row, column = layout.get_division(f_x)
        w = d[bo.BORDER_WIDTH]
        cell = layout.get_merge_cell_rect(f_x, 0, 0)
        w1 = cell.w * column + w
        h1 = cell.h * row + w
        w2 = w - w // 2

        for r in range(row):
            cell = layout.get_merge_cell_rect(f_x, r, 0)
            Sel.rect(j, cell.x - w2, cell.y - w2, w1, w)

        Sel.rect(j, cell.x - w2, cell.y + cell.h - w2, w1, w)

        for c in range(column):
            cell = layout.get_merge_cell_rect(f_x, 0, c)
            Sel.rect(j, cell.x - w2, cell.y - w2, w, h1)

        Sel.rect(j, cell.x + cell.w - w2, cell.y - w2, w, h1)
        self._process_selection(self._add_border_layer(j, d), d)

    def _do_free_range(self, j, d):
        """
        Do border for free range cells.

        j: GIMP image
            Is render.

        d: dict
            of format
        """
        self.group = None

        for cell in reversed(d[fk.Layer.CELL_LIST]):
            e = cell[bo.FREE_CELL_BORDER]
            if all((e[bo.BORDER_WIDTH], e[bo.OPACITY])):
                if not self.group:
                    self.group = self._make_group(j)

                n = cell[fck.CELL][CellKey.SHAPE]

                if n == ff.Cell.Shape.RECTANGLE:
                    self._do_rect_free_cell(j, cell)
                else:
                    self._do_shape_free_cell(j, cell, e, n)
        if self.group:
            Lay.merge_group(
                self.group,
                n=Lay.get_layer_name(FREE_CELL_NAME, parent=self.parent)
            )

    def _do_ellipse_sel(self, j, d, group=None):
        """
        Increase the opacity of the ellipse.

        j: GIMP image
            Is render.

        d: dict
            of border

        group: layer
            Is parent for the border material layer.
        """
        group = self._make_group(j, group=group)
        f = d[bo.OPACITY]
        d[bo.OPACITY] = 100.
        z = self._add_border_layer(j, d, group=group)

        Sel.fill(z, self._get_color(d))

        z.opacity = d[bo.OPACITY] = f

        for i in range(3):
            Lay.clone(z)

        z = Lay.merge_group(
            group,
            n=Lay.get_layer_name(bo.CELL_BORDER, parent=self.parent)
        )

        Sel.item(z)
        self._process_selection(z, d, is_fill=0)

    def _do_grid(self, j, d, is_merge):
        """
        Do border for grid cells.

        j: GIMP image
            Is render.

        d: dict
            of format

        is_merge: flag
            Is true, when merge cells is in play.
        """
        e = d[bo.CELL_BORDER]
        n = d[fk.Cell.Grid.CELL_GRID][fk.Cell.Grid.SHAPE]
        go = self.is_per_cell = d[fk.Cell.Border.PER_CELL]
        is_one_border = not any((is_merge, self.is_per_cell))

        if not go:
            go = all((e[bo.BORDER_WIDTH], e[bo.OPACITY]))
        if go:
            pdb.gimp_selection_none(j)
            if n == ff.Cell.Shape.RECTANGLE:
                if is_one_border:
                    if e[bo.COMMON_BORDER]:
                        self._do_common_rect_grid(j, e)
                    else:
                        self._do_rect_grid(j, e)
                else:
                    self._do_rect_per_cell(j, d, e)

            elif n == ff.Cell.Shape.SQUARE:
                if is_one_border:
                    if e[bo.COMMON_BORDER]:
                        self._do_common_square_grid(j, e)
                    else:
                        self._do_square_grid(j, e)
                else:
                    self._do_rect_per_cell(j, d, e)

            elif n in ELLIPSE:
                if is_one_border:
                    if e[bo.COMMON_BORDER]:
                        self._do_common_ellipse_grid(j, d, e)
                    else:
                        self._do_shape_grid(j, d, e, n)
                else:
                    self._do_shape_per_cell(j, d)
            else:
                if is_one_border:
                    if e[bo.COMMON_BORDER]:
                        self._do_common_polygon_grid(j, d, e)
                    else:
                        self._do_shape_grid(j, d, e, n)
                else:
                    self._do_shape_per_cell(j, d)

    def _do_layer(self, j, d, parent):
        """
        Do border for free range cells.

        j: GIMP image
            Is render.

        d: dict
            of format

        parent: layer
            format group
        """
        e = d[bo.LAYER_BORDER]
        w, h = self.session['size']
        w1 = e[bo.BORDER_WIDTH]
        if all((w1, e[bo.OPACITY])):
            w2 = w1 * 2
            w3 = w1 // 2
            w4 = w1 - w3

            if e[bo.OBEY_MARGINS]:
                top, bottom, left, right = Form.get_layer_margin(d, (w, h))
                width, height = w - left - right + w1, h - top - bottom + w1
                Sel.rect(j, left - w3, top - w3, width, height)
                Sel.rect(
                    j,
                    w4 + left,
                    w4 + top,
                    width - w2,
                    height - w2,
                    option=fu.CHANNEL_OP_SUBTRACT
                )

            else:
                Sel.rect(j, 0, 0, w, h)
                Sel.rect(
                    j,
                    w1,
                    w1,
                    w - w2,
                    h - w2,
                    option=fu.CHANNEL_OP_SUBTRACT
                )
            self._process_selection(
                self._add_border_layer(j, e, n="Layer Border", group=parent),
                e
            )

    def _do_rect_free_cell(self, j, d):
        """
        Draw a rectangle free range cell border.

        j: GIMP image
            Is render.

        d: dict
            of free range cell
        """
        x, y, w, h = Form.get_free_cell_rect(d[fck.CELL], self.session['size'])
        e = d[bo.FREE_CELL_BORDER]
        w1 = e[bo.BORDER_WIDTH]
        w2 = w1 + w1
        Sel.rect(j, x, y, w, h)
        Sel.rect(
            j,
            x + w1,
            y + w1,
            max(w - w2, 1),
            max(h - w2, 1),
            option=fu.CHANNEL_OP_SUBTRACT
        )
        self._process_selection(
            self._add_border_layer(j, e, n=FREE_CELL_NAME, group=self.group),
            e
        )

    def _do_rect_grid(self, j, d):
        """
        Draw border for a rectangle grid without merged cells.

        j: GIMP image
            Is render.

        d: dict
            of cell grid border
        """
        f_x = self.f_x
        layout = self.stat.layout
        row, column = layout.get_division(f_x)
        cell = layout.get_merge_cell_rect(f_x, 0, 0)
        left, top = cell.x, cell.y
        cell = layout.get_merge_cell_rect(f_x, row - 1, column - 1)
        right, bottom = cell.x + cell.w, cell.y + cell.h
        w1 = right - left
        x = left
        h1 = d[bo.BORDER_WIDTH]

        for r in range(row):
            cell = layout.get_merge_cell_rect(f_x, r, 0)
            Sel.rect(j, x, cell.y, w1, h1)
            Sel.rect(j, x, max(cell.y + cell.h - h1, cell.y), w1, h1)

        w1 = h1
        h1 = bottom - top
        y = top

        for c in range(column):
            cell = layout.get_merge_cell_rect(f_x, 0, c)
            Sel.rect(j, cell.x, y, w1, h1)
            Sel.rect(j, max(cell.x + cell.w - w1, cell.x), y, w1, h1)
        self._process_selection(self._add_border_layer(j, d), d)

    def _do_rect_per_cell(self, j, d, e):
        """
        Draw border for a rectangle grid with
        merged cells and / or per cell.

        j: GIMP image
            Is render.

        d: dict
            of format

        e: dict
            of cell grid border
        """
        f_x = self.f_x
        layout = self.stat.layout
        row, column = layout.get_division(f_x)
        w = e[bo.BORDER_WIDTH]
        w1 = w + w
        z = None

        for r in range(row):
            for c in range(column):
                if not z or self.is_per_cell:
                    z = self._add_border_layer(j, e)

                go = True

                if self.is_per_cell:
                    e = d[fk.Cell.Border.PER_CELL][r][c]
                    go = all((e[bo.BORDER_WIDTH], e[bo.OPACITY]))
                if go:
                    cell = layout.get_merge_cell_rect(f_x, r, c)
                    Sel.rect(j, cell.x, cell.y, cell.w, cell.h)
                    Sel.rect(
                        j,
                        cell.x + w,
                        cell.y + w,
                        max(cell.w - w1, 1),
                        max(cell.h - w1, 1),
                        option=fu.CHANNEL_OP_SUBTRACT
                    )
                    if self.is_per_cell:
                        self._process_selection(z, e)

        if not self.is_per_cell:
            self._process_selection(z, e)

    def _do_shape_free_cell(self, j, d, e, n):
        """
        Draw a non-rectangle shaped free range cell border.

        j: GIMP image
            Is render.

        d: dict
            of free range cell

        e: dict
            of cell border

        n: string
            cell shape
        """
        x, y, w, h = Form.get_free_cell_rect(d[fck.CELL], self.session['size'])

        Form.select_shape(
            j,
            Form.calc_shape_from_rect(n, Rect((x, y), (w, h)))
        )

        if Sel.is_sel(j):
            sel = pdb.gimp_selection_save(j)

            pdb.gimp_selection_shrink(j, e[bo.BORDER_WIDTH])

            if Sel.is_sel(j):
                sel1 = pdb.gimp_selection_save(j)

            else:
                sel1 = None

            Sel.load(j, sel)
            Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

            if not Sel.is_sel(j):
                Sel.load(j, sel)

            if n in ELLIPSE:
                self._do_ellipse_sel(j, e, group=self.group)
            else:
                self._process_selection(
                    self._add_border_layer(j, e, group=self.group),
                    e
                )

            pdb.gimp_image_remove_channel(j, sel)
            pdb.gimp_image_remove_channel(j, sel1)

    def _do_shape_grid(self, j, d, e, n):
        """
        Draw border for a square grid
        without merged cells or per cell.

        j: GIMP image
            Is render.

        d: dict
            of format

        e: dict
            of cell grid border

        n: string
            shape descriptor
        """
        f_x = self.f_x
        layout = self.stat.layout
        row, column = layout.get_division(f_x)
        w = e[bo.BORDER_WIDTH]
        double_type = Form.get_double_space_type(d)
        grid_sel = None

        for r in range(row):
            for c in range(column):
                # 'm' is true when there is a valid cell:
                m = True

                if double_type:
                    m = Form.is_double_space_cell(r, c, double_type)
                if m:
                    Form.select_shape(j, layout.get_plaque(f_x, r, c))

                    sel = pdb.gimp_selection_save(j)

                    pdb.gimp_selection_shrink(j, w)

                    if Sel.is_sel(j):
                        sel1 = pdb.gimp_selection_save(j)

                    else:
                        sel1 = None

                    # Make border selection by subtracting
                    # the inner selection from the outer:
                    Sel.load(j, sel)
                    Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                    if grid_sel:
                        Sel.load(j, grid_sel, option=fu.CHANNEL_OP_ADD)
                        pdb.gimp_image_remove_channel(j, grid_sel)

                    grid_sel = pdb.gimp_selection_save(j)

                    pdb.gimp_image_remove_channel(j, sel)
                    pdb.gimp_image_remove_channel(j, sel1)
        if grid_sel:
            Sel.load(j, grid_sel)
            pdb.gimp_image_remove_channel(j, grid_sel)

            if n in ELLIPSE:
                self._do_ellipse_sel(j, e)
            else:
                self._process_selection(self._add_border_layer(j, e), e)

    def _do_shape_per_cell(self, j, d):
        """
        Draw border for a square grid
        without merged cells or per cell.

        j: GIMP image
            Is render.

        d: dict
            of format
        """
        group = self._make_group(j)
        f_x = self.f_x
        layout = self.stat.layout
        row, column = layout.get_division(f_x)
        double_type = Form.get_double_space_type(d)
        n = d[fk.Cell.Grid.CELL_GRID][fk.Cell.Grid.SHAPE]

        for r in range(row):
            for c in range(column):
                # 'm' is true when there is a valid cell:
                m = True

                if double_type:
                    m = Form.is_double_space_cell(r, c, double_type)
                if m:
                    e = d[fk.Cell.Border.PER_CELL][r][c]
                    w = e[bo.BORDER_WIDTH]
                    if all((w, e[bo.OPACITY])):
                        Form.select_shape(
                            j,
                            layout.get_plaque(f_x, r, c)
                        )

                        sel = pdb.gimp_selection_save(j)

                        pdb.gimp_selection_shrink(j, w)

                        if Sel.is_sel(j):
                            sel1 = pdb.gimp_selection_save(j)

                        else:
                            sel1 = None

                        # Make border selection by subtracting
                        # the inner selection from the outer:
                        Sel.load(j, sel)
                        Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                        if not Sel.is_sel(j):
                            Sel.load(j, sel)

                        if n in ELLIPSE:
                            self._do_ellipse_sel(j, e, group=group)

                        else:
                            self._process_selection(
                                self._add_border_layer(j, e, group=group),
                                e
                            )

                        pdb.gimp_image_remove_channel(j, sel)
                        pdb.gimp_image_remove_channel(j, sel1)

        Lay.merge_group(
            group,
            n=Lay.get_layer_name(bo.CELL_BORDER, parent=self.parent)
        )

    def _do_square_grid(self, j, d):
        """
        Draw border for a square grid
        without merged cells or per cell.

        j: GIMP image
            Is render.

        d: dict
            of cell grid border
        """
        f_x = self.f_x
        layout = self.stat.layout
        row, column = layout.get_division(f_x)
        w = d[bo.BORDER_WIDTH]
        cell = layout.get_merge_cell_rect(f_x, 0, 0)
        w1 = cell.w * column
        h1 = cell.h * row

        for r in range(row):
            cell = layout.get_merge_cell_rect(f_x, r, 0)
            Sel.rect(j, cell.x, cell.y, w1, w)
            Sel.rect(j, cell.x, max(cell.y + cell.h - w, cell.y), w1, w)

        for c in range(column):
            cell = layout.get_merge_cell_rect(f_x, 0, c)
            Sel.rect(j, cell.x, cell.y, w, h1)
            Sel.rect(j, max(cell.x + cell.w - w, cell.x), cell.y, w, h1)
        self._process_selection(self._add_border_layer(j, d), d)

    def _get_color(self, d):
        """
        Get the color for the border material.

        d: dict
            of border

        Return: tuple
            RGB
        """
        if self.is_layout:
            return ForLayout.BORDER_COLOR
        return d[bo.COLOR]

    def _make_group(self, j, group=None):
        """
        Make a group layer for cell border layers.

        j: GIMP image
            work-in-progress

        group: layer
            Is parent to the border material layer.

        Return: layer
            group type
        """
        z = group if group else self.parent
        return Lay.group(
            j,
            "Borders",
            parent=z,
            offset=len(self.parent.layers) + 1
        )

    def _process_selection(self, z, d, is_fill=1):
        """
        The selection is the border. Fill,
        blur, and emboss complete the process.

        z: layer
            for border material

        d: dict
            of border

        is_fill: flag
            When true, the layer is filled with the border color.
        """
        j = z.image
        if Sel.is_sel(j):
            if is_fill:
                Sel.fill(z, self._get_color(d))

            pdb.gimp_selection_none(j)

            if d[bo.BORDER_BLUR]:
                Lay.blur(z, d[bo.BORDER_BLUR])

            if d[bo.EMBOSS]:
                z = Lay.clone(z)
                z.mode = fu.LAYER_MODE_OVERLAY

                pdb.plug_in_emboss(
                    j,
                    z,
                    self.stat.light_angle,
                    self.stat.elevation,
                    d[bo.BUMP_DEPTH],
                    em.EMBOSS
                )
                pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            pdb.gimp_selection_none(j)
