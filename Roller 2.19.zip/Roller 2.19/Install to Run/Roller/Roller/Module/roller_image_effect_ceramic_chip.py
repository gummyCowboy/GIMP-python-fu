#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import seed
from roller_image_effect_border_line import BorderLine
from roller_image_effect import LayerKey as nk
from roller_one_constant import ForBackdropStyle as fbs, OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
mo = Fu.Mosaic


class CeramicChip(BorderLine):
    """Create a frame with colorful ceramic pieces."""

    def __init__(self, one):
        """
        Do the Ceramic Chip image-effect.

        one: One
            Has variables.
        """
        BorderLine.__init__(self, one, filler=self.do_job)

    def do_job(self, z, d):
        """
        Draw the ceramic chip.

        z: layer
            not used

        d: dict
            with options

        Return: layer
            the ceramic layer
        """
        # A random sequence is reproducible given the same seed:
        seed(d[ok.RANDOM_SEED])

        j = self.stat.render.image
        z = Lay.add(j, self.option_key, parent=self.parent)
        a = min(
            int(d[ok.MESH_SIZE] * 1.2),
            self.session['w'], self.session['h']
        )
        z = RenderHub.draw_color_rectangles(z, a, a)
        z.name = Lay.get_layer_name(nk.FILLER, parent=self.parent)

        pdb.gimp_selection_all(j)
        pdb.plug_in_waves(j, z, 10, 1, 50, 0, 1)
        pdb.plug_in_mosaic(
            j,
            z,
            d[ok.MESH_SIZE],
            mo.TILE_HEIGHT_1,
            mo.TILE_SPACING_MIN,
            mo.TILE_NEATNESS_MIDDLE,
            mo.NO_SPLIT,
            self.stat.light_angle,
            mo.MIN_COLOR_VARIATION,
            mo.YES_ANTIALIAS,
            mo.YES_COLOR_AVERAGING,
            fbs.MESH_TYPE.index(d[ok.MESH_TYPE]),
            mo.SMOOTH_SURFACE,
            mo.BLACK_AND_WHITE_GROUT
        )

        z = Lay.clone(z)
        z.opacity = 50.
        z.mode = fu.LAYER_MODE_LCH_COLOR

        pdb.plug_in_colorify(j, z, d[ok.COLOR])

        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

        Sel.isolate(z, self.fill_sel)
        return z
