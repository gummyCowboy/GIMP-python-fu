#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import RollerImage
from roller_format_text import Text
from roller_one import One
from roller_one_base import Comm
from roller_one_constant import (
    ForFormat as ff,
    ForLayout,
    ForTriangle,
    MaskKey as ma,
    OptionKey as ok
)
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb
MAKE_NEW_LAYER = None
NO_ANTIALIAS = 0
RATIO = ff.Cell.Shape.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = ff.Cell.Shape.TRIANGLE_SCALE_RATIO_UP


class ImageMask:
    """Manage image mask related tasks with a static class."""

    stat = None

    @staticmethod
    def _do_character_mask(j, cell):
        """
        Add a character selection to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        font = cell.data[ma.FONT]

        if font not in cell.stat.font_list:
            Comm.info_msg(ff.MISSING_ITEM.format("Image-Mask", "font", font))
        else:
            # Scale up:
            font_size = min(cell.w, cell.h) * 2

            character = cell.data[ma.CHAR]
            z = Lay.add(j, "text")
            go, z1 = Text.make_text_layer(
                j,
                z,
                NO_ANTIALIAS,
                cell.x,
                cell.y,
                character,
                font_size,
                font,
                (255, 255, 255),
                cell.w,
                cell.h
            )
            if go:
                Sel.item(z1)

                # align center:
                offset_x = cell.x + (cell.image_w - cell.w) // 2
                offset_y = cell.y + (cell.image_h - cell.h) // 2

                pdb.gimp_layer_set_offsets(z1, offset_x, offset_y)

                # Combine selection
                Sel.item(z1)
                for i in (z, z1):
                    pdb.gimp_image_remove_layer(j, i)

    @staticmethod
    def _do_circle_mask(j, cell):
        """
        Add a circle selection to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        # Make into circle.
        # x, y are topleft:
        w = min(cell.w, cell.h)
        Sel.ellipse(j, cell.center_x - w // 2, cell.center_y - w // 2, w, w)

    @staticmethod
    def _do_cut_corners_mask(j, cell):
        """
        Add a cut corners selection to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        # Make into diamond:
        x, y, w, h = cell.x, cell.y, cell.w, cell.h
        w1 = (cell.image_w - w) // 2
        h1 = (cell.image_h - h) // 2

        # eight segments:
        q = (
            x + w1, y,
            x + cell.image_w - w1, y,
            x + cell.image_w, y + h1,
            x + cell.image_w, y + cell.image_h - h1,
            x + cell.image_w - w1, y + cell.image_h,
            x + w1, y + cell.image_h,
            x, y + cell.image_h - h1,
            x, y + h1
        )
        Sel.polygon(j, q)

    @staticmethod
    def _do_diamond_mask(j, cell):
        """
        Add a diamond selection to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w, h = cell.w // 2, cell.h // 2
        x = cell.center_x
        y = cell.center_y

        # four segments:
        q = (
            x, y - h,
            x + w, y,
            x, y + h,
            x - w, y
        )
        Sel.polygon(j, q)

    @staticmethod
    def _do_hexagon_horizontal_mask(j, cell):
        """
        Add a hexagonal horizontally aligned shape to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w, h = cell.w, cell.h

        # There are two possible solutions.
        # first solution:
        w1, h1 = w, w * UP_RATIO

        # Check for overflow:
        if h1 > h:
            # second solution:
            w1, h1 = h * RATIO, h

        q = Form.calc_hexagon_horizontal_offset(w1, h1)
        Sel.polygon(
            j,
            Form.calc_hexagon_horizontal_shape(
                cell.center_x - q[0],
                cell.center_y - q[2],
                w1,
                h1,
                q
            )
        )

    @staticmethod
    def _do_hexagon_vertical_mask(j, cell):
        """
        Add a hexagonal vertically aligned shape to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w, h = cell.w, cell.h

        # There are two possible solutions.
        # first solution:
        w1, h1 = h * UP_RATIO, h

        # Check for overflow:
        if w1 > w:
            # second solution:
            w1, h1 = w, w * RATIO

        q = Form.calc_hexagon_vertical_offset(w1, h1)
        x = cell.center_x - q[1]
        y = cell.center_y - q[3]
        Sel.polygon(j, Form.calc_hexagon_vertical_shape(x, y, w1, h1, q))

    @staticmethod
    def _do_image_mask(j, cell):
        """
        Add an image selection to the selection.

        Image masks transform their shape to a cell rectangle.

        session: dict
            of session

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        j1 = RollerImage.get_image(
            cell.session,
            cell.data[ma.IMAGE]
        )

        if j1:
            pdb.gimp_selection_none(j)
            pdb.gimp_edit_copy_visible(j1.j)

            j2 = pdb.gimp_edit_paste_as_new_image()

            # Shape, copy, and delete image:
            Form.shape(j2, cell.w, cell.h)

            # Paste on the bottom:
            z = Lay.paste(j.active_layer)

            pdb.gimp_layer_set_offsets(z, cell.x, cell.y)
            Sel.item(z)
            pdb.gimp_image_remove_layer(j, z)
            RollerImage.close_image(j1)
        else:
            # Keep entire cell:
            Sel.rect(j, cell.x, cell.y, cell.w, cell.h)

    @staticmethod
    def _do_octagon_mask(j, cell):
        """
        Add an octagon selection to the selection.

        The web address with a helpful formula:
            math.stackexchange.com/
            questions/22064/
            calculating-a-point-that-lies-on-an-ellipse-given-an-angle

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w, h = cell.w, cell.h

        # x, y is topleft:
        x = cell.center_x - w // 2
        y = cell.center_y - h // 2

        q = Form.calc_octagon_offset(w, h)
        Sel.polygon(j, Form.calc_octagon_shape(x, y, w, h, q))

    @staticmethod
    def _do_octagon_aligned_mask(j, cell):
        """
        Add an octagon selection to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w, h = cell.w, cell.h

        # x, y is topleft:
        x = cell.center_x - w // 2
        y = cell.center_y - h // 2

        q = Form.calc_octagon_aligned_offset(w, h)
        Sel.polygon(j, Form.calc_octagon_aligned_shape(x, y, w, h, q))

    @staticmethod
    def _do_oval_mask(j, cell):
        """
        Add a oval selection to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        # x, y are topleft:
        w, h = cell.w, cell.h
        Sel.ellipse(j, cell.center_x - w // 2, cell.center_y - h // 2, w, h)

    @staticmethod
    def _do_rectangle_mask(j, cell):
        """
        Add a rectangle selection to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w, h = cell.w, cell.h
        x = cell.center_x - w // 2
        y = cell.center_y - h // 2
        Sel.rect(j, x, y, w, h)

    @staticmethod
    def _do_rhombus_mask(j, cell):
        """
        Add a rhombus selection to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w = min(cell.w, cell.h) // 2
        x = cell.center_x
        y = cell.center_y
        q = (
            x, y - w,
            x + w, y,
            x, y + w,
            x - w, y
        )
        Sel.polygon(j, q)

    @staticmethod
    def _do_rounded_corners_mask(j, cell):
        """
        Add a square selection to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        x, y, w, h = cell.x, cell.y, cell.w, cell.h
        sel = pdb.gimp_selection_save(j)

        # top-left:
        Sel.ellipse(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)

        # top-right:
        x1 = x + cell.image_w - w

        Sel.ellipse(j, x1, y, w, h)

        # bottom-left:
        y1 = y + cell.image_h - h

        Sel.ellipse(j, x, y1, w, h)

        # bottom-right:
        Sel.ellipse(j, x1, y1, w, h)

        # vertical rectangle:
        x2 = x + w // 2
        w1 = cell.image_w - w

        Sel.rect(j, x2, y, w1, cell.image_h)

        # horizontal rectangle:
        y2 = y + h // 2
        h1 = cell.image_h - h

        Sel.rect(j, x, y2, cell.image_w, h1)
        Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, sel)

    @staticmethod
    def _do_square_mask(j, cell):
        """
        Add a square selection to the selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w = min(cell.w, cell.h)
        x = cell.center_x - w // 2
        y = cell.center_y - w // 2
        Sel.rect(j, x, y, w, w)

    @staticmethod
    def _do_triangle_down_mask(j, cell):
        """
        Add an down-facing-triangle selection
        to the existing selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w = cell.w // 2
        h = cell.h // 2
        x = cell.center_x
        y = cell.center_y
        q = (
            x - w, y - h,
            x + w, y - h,
            x, y + h
        )
        Sel.polygon(j, q)

    @staticmethod
    def _do_triangle_left_mask(j, cell):
        """
        Add an left-facing-triangle selection
        to the existing selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w = cell.w // 2
        h = cell.h // 2
        x = cell.center_x
        y = cell.center_y
        q = (
            x + w, y - h,
            x + w, y + h,
            x - w, y
        )
        Sel.polygon(j, q)

    @staticmethod
    def _do_triangle_right_mask(j, cell):
        """
        Add an right-facing-triangle selection
        to the existing selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w = cell.w // 2
        h = cell.h // 2
        x = cell.center_x
        y = cell.center_y
        q = (
            x - w, y - h,
            x - w, y + h,
            x + w, y
        )
        Sel.polygon(j, q)

    @staticmethod
    def _do_triangle_up_mask(j, cell):
        """
        Add an up-facing-triangle selection
        to the existing selection.

        j: GIMP image
            to receive selection

        cell: One
            Has cell data.
        """
        w = cell.w // 2
        h = cell.h // 2
        x = cell.center_x
        y = cell.center_y
        q = (
            x - w, y + h,
            x + w, y + h,
            x, y - h
        )
        Sel.polygon(j, q)

    @staticmethod
    def make_mask_selection(
        session,
        d,
        stat,
        f_x,
        r,
        c,
        is_merge,
        image=None
    ):
        """
        Add image masks together into one selection.

        session: dict
            Use to get images.

        d: dict
            of format

        stat: Stat
            global variables

        f_x: int
            index
            corresponding with session's format list

        r, c: int
            cell index

        is_merge: bool
            Is true when the cell grid is in a merged cell state.

        image: RollerImage
            Has cell info.

        Return: flag
            Is true, when the cell has a mask selection.

            state of image
                the new masked selection
        """
        ImageMask.stat = stat
        j = stat.render.image
        cell = One(stat=stat, session=session)
        has_mask = True
        layout = stat.layout

        if image:
            j1 = image

        else:
            j1 = layout.get_grid_image(session, d, f_x, r, c, is_merge)

        if not j1:
            has_mask = None

        if has_mask:
            e = cell.data = Form.get_image_mask(d, r, c)
            if e[ma.TYPE] == ok.NONE:
                has_mask = False

        if has_mask:
            # The image selection is modified:
            pdb.gimp_selection_none(j)

            if r != ForLayout.FREE_CELL:
                rect = layout.get_mold_from_cell(f_x, r, c)
                x, y, = cell.x, cell.y = rect.position
                w, h = cell.w, cell.h = rect.size

            else:
                # free range cell:
                x, y = cell.x, cell.y = j1.mold.position
                w, h = cell.w, cell.h = j1.mold.size

            cell.image_w, cell.image_h = w, h
            cell.center_x, cell.center_y = x + w // 2, y + h // 2
            n = e[ma.TYPE]

            # scale:
            if n != ff.Mask.IMAGE:
                cell.w *= e[ma.HORZ_SCALE]
                cell.h *= e[ma.VERT_SCALE]
            # Add mask:
            if n in _mask_function:
                _mask_function[n](j, cell)
        return has_mask


_mask_function = {
    ff.Mask.CHARACTER: ImageMask._do_character_mask,
    ff.Mask.CIRCLE: ImageMask._do_circle_mask,
    ff.Mask.CUT_CORNERS: ImageMask._do_cut_corners_mask,
    ff.Mask.DIAMOND: ImageMask._do_diamond_mask,
    ff.Mask.HEXAGON_HORIZONTAL: ImageMask._do_hexagon_horizontal_mask,
    ff.Mask.HEXAGON_VERTICAL: ImageMask._do_hexagon_vertical_mask,
    ff.Mask.IMAGE: ImageMask._do_image_mask,
    ff.Mask.OCTAGON: ImageMask._do_octagon_mask,
    ff.Mask.OCTAGON_ALIGNED: ImageMask._do_octagon_aligned_mask,
    ff.Mask.OVAL: ImageMask._do_oval_mask,
    ff.Mask.RECTANGLE: ImageMask._do_rectangle_mask,
    ff.Mask.RHOMBUS: ImageMask._do_rhombus_mask,
    ff.Mask.ROUNDED_CORNERS: ImageMask._do_rounded_corners_mask,
    ff.Mask.SQUARE: ImageMask._do_square_mask,
    ForTriangle.TRIANGLE_DOWN: ImageMask._do_triangle_down_mask,
    ForTriangle.TRIANGLE_LEFT: ImageMask._do_triangle_left_mask,
    ForTriangle.TRIANGLE_RIGHT: ImageMask._do_triangle_right_mask,
    ForTriangle.TRIANGLE_UP: ImageMask._do_triangle_up_mask
}
