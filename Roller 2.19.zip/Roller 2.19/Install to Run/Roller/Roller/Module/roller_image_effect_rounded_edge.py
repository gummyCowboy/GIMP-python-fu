#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerKey as nk
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay
import gimpfu as fu
from roller_render_hub import RenderHub

pdb = fu.pdb


class RoundedEdge:
    """Create a curved image effect on an image layer."""

    def __init__(self, one):
        """
        Do Rounded Edge image-effect.

        one: One
            Has variables.
        """
        stat = one.stat
        parent = one.parent
        d, e = one.d, one.e
        if d[ok.ROUNDED_EDGE_BLUR] and d[ok.INTENSITY]:
            color = (255, 255, 255) if d[ok.ROUND_UP] else (0, 0, 0)
            group, layers = RenderHub.create_shadow_unit(
                stat,
                parent,
                e['caster_key']
            )
            z = RenderHub.do_shadow(
                stat,
                group,
                0,
                0,
                d[ok.ROUNDED_EDGE_BLUR],
                color,
                d[ok.INTENSITY],
                layer_name=Lay.get_layer_name(nk.FRAME, parent=parent),
                is_opaque=True,
                is_inlay=True
            )

            pdb.gimp_image_remove_layer(stat.render.image, group)
            pdb.gimp_image_reorder_item(stat.render.image, z, parent, 0)
            Lay.show(layers[0])
