#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_style_gradient_fill import GradientFill
from roller_image_effect import LayerKey as nk
from roller_one import One
from roller_one_constant import ForBump as fb, ForLayer, OptionKey as ok
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb


class FrameGradient:
    """
    Create a gradient for an image-effect frame.

    Give the frame color and light.
    """

    def __init__(self, one):
        """
        Do a Frame Gradient effect.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        j = stat.render.image
        parent = self.parent = one.parent
        z = Lay.search(parent, nk.FRAME)
        d = self.d = deepcopy(one.d)
        d.update(
            {
                ok.BUMP: {ok.BUMP: fb.NONE},
                ok.MODE: "Normal"
            }
        )
        self.option_key = one.k

        Sel.item(z)

        self.sel = stat.save_render_sel()
        z = FrameGradient._add_metal_layer(j, z, parent)

        GradientFill(
            One(d=d, session=one.session, stat=stat, z=z),
            make_opaque=True
        )

        z = metal = j.active_layer

        # backdrop light:
        if not Lay.search(j, nk.BACKDROP_LIGHT, is_err=False):
            z1 = Lay.clone(z)
            z1.opacity = ForLayer.BACKDROP_LIGHT_OPACITY
            z1.name = Lay.get_layer_name(nk.BACKDROP_LIGHT)

            # Place below the last format group:
            for x, i in enumerate(j.layers):
                if pdb.gimp_item_is_group(i):
                    x1 = x
            pdb.gimp_image_reorder_item(j, z1, None, x1 + 1)

        for i in (nk.TRANSPARENCY, nk.FILLER):
            z1 = Lay.search(parent, i, is_err=False)
            if z1:
                z2 = Lay.clone(metal)
                z2.opacity = ForLayer.BACKDROP_LIGHT_OPACITY
                a = Lay.offset(z1)

                pdb.gimp_image_reorder_item(j, z2, parent, a)
                Sel.item(z1)
                Sel.clear_outside_of_selection(z2)
                pdb.gimp_image_merge_down(j, z2, fu.CLIP_TO_IMAGE)

        z.mode = fu.LAYER_MODE_OVERLAY

        Sel.load(j, self.sel)
        Sel.clear_outside_of_selection(z, keep_sel=True)

        z = pdb.gimp_image_merge_down(j, metal, fu.CLIP_TO_IMAGE)

        self._blend_edge(z, parent)

        z = Lay.search(parent, nk.BUMP, is_err=False)
        if z:
            pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    def _blend_edge(self, z, parent):
        """
        Blend the color of the background with edge of the frame.

        z: layer
            to clone from

        parent: layer
            format group
            for layer name
        """
        j = self.stat.render.image
        z = FrameGradient._add_edge_layer(z, parent)

        Sel.load(j, self.sel)
        pdb.gimp_selection_shrink(j, 1)

        sel = self.stat.save_render_sel()

        Sel.load(j, self.sel)
        Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

        edge_sel = self.stat.save_render_sel()

        pdb.gimp_selection_none(j)
        pdb.gimp_edit_copy_visible(j)

        z1 = Lay.paste(z)
        n = z.name

        Lay.blur(z1, 6)
        Sel.load(j, edge_sel)
        Sel.clear_outside_of_selection(z1)
        pdb.gimp_image_remove_layer(j, z)

        z1.mode = fu.LAYER_MODE_NORMAL
        z1.opacity = 51.
        z2 = Lay.clone(z1)
        z2.mode = fu.LAYER_MODE_HARDLIGHT
        z1 = pdb.gimp_image_merge_down(j, z2, fu.CLIP_TO_IMAGE)
        z1.name = n
        pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

    @staticmethod
    def _add_edge_layer(z, parent):
        """
        Add the edge layer.

        z: layer
            to clone from

        parent: layer
            for layer name
            format group
        """
        z = Lay.clone(z)
        z.mode = fu.LAYER_MODE_OVERLAY
        z.name = Lay.get_layer_name(nk.EDGE, parent=parent)
        return z

    @staticmethod
    def _add_metal_layer(j, z, parent):
        """
        Add the metal layer.

        j: GIMP image
            work-in-progress

        z: layer
            to clone from

        parent: layer
            for layer name
            format group
        """
        z = Lay.add(
            j,
            z.name,
            parent=z.parent,
            offset=pdb.gimp_image_get_item_position(j, z)
        )
        z.mode = fu.LAYER_MODE_OVERLAY
        z.name = Lay.get_layer_name(nk.METAL, parent=parent)

        Lay.color_fill(z, (127, 127, 127))
        return z
