#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import RollerImage
from roller_image_effect import ImageEffect, LayerKey
from roller_one import One
from roller_one_base import Comm
from roller_one_constant import (
    BrushKey as br,
    CellKey,
    ForFormat as ff,
    ForGradient as fg,
    FormatKey as fk,
    ForLayout,
    FreeCellKey as fck,
    FringeKey as fr,
    OptionKey as ok,
    PlaceKey as pl,
    PlaqueKey as pq,
    ShadowKey as sh
)
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

ek = ImageEffect.Key
gf = Fu.GradientFill
pdb = fu.pdb
pb = Fu.PaintBrush
ABOVE = fk.Layer.PLACE_FREE_CELL_ABOVE
BOTTOM_LAYERS = LayerKey.LAYER_FRINGE, LayerKey.LAYER_PLAQUE
CELL_FRINGE_LAYERS = LayerKey.CELL_FRINGE, LayerKey.CELL_PLAQUE
CELL_LAYOUT = ff.IS_CELL_FRINGE, ff.IS_BOTH_FRINGE
FC = ForLayout.FRINGE_COLOR
FRINGE_MAT = (
    ff.Fringe.GRADIENT,
    ff.Fringe.IMAGE,
    ff.Fringe.PATTERN,
    ff.Fringe.BACKDROP
)
GRID = fk.Cell.Grid
LAYER_LAYOUT = ff.IS_LAYER_FRINGE, ff.IS_BOTH_FRINGE
MASK = ff.Fringe.MASK
RECTANGLE = ff.Cell.Shape.RECTANGLE
REPLACE = fu.CHANNEL_OP_REPLACE


class Fringe:
    """Manage fringe operation."""

    def __init__(self, session, d, f_x, stat, parent, layout_type):
        """
        Do fringe for one format.

        session: dict
            of session

        d: dict
            Has format.

        f_x: int
            index
            corresponding with the session's format list

        stat: Stat
            globals

        layout_type: enum
            When true, the fringe is drawing for a layout.
        """
        self.session = session
        self._color = self.group = None
        self.f_x = f_x
        self._layout_type = layout_type
        self.form = d
        self.stat = stat
        self.parent = parent
        self.render = stat.render.image

        # Preserve:
        q = pdb.gimp_context_get_foreground()

        pdb.gimp_context_set_antialias(1)

        if not layout_type or layout_type in CELL_LAYOUT:
            if d[fk.Layer.CELL_LIST]:
                if not d[ABOVE]:
                    self._do_free_cell()

        if not layout_type or layout_type in CELL_LAYOUT:
            self._do_cells()

        if not layout_type or layout_type in LAYER_LAYOUT:
            self._do_layer()

        if not layout_type or layout_type in CELL_LAYOUT:
            if d[fk.Layer.CELL_LIST]:
                if d[ABOVE]:
                    self._do_free_cell()
        # Restore:
        pdb.gimp_context_set_foreground(q)

    @staticmethod
    def _brush(z, q):
        """
        Perform a brush stroke.

        z: layer
            to receive brush

        q: tuple
            x, y
            position of stroke
        """
        pdb.gimp_paintbrush(
            z,
            pb.NO_FADE_OUT,
            pb.STROKES_2,
            q,
            fu.PAINT_CONSTANT,
            pb.GRADIENT_LENGTH_0
        )

    def _brush_rectangle(self, z, angle, spacing):
        """
        Do brush for the rectangle shape.

        z: layer
            to receive paint material

        angle: float
            for brush

        spacing: float
            between brush applications
        """
        _, x, y, x1, y1 = pdb.gimp_selection_bounds(self.render)
        x_offset = int((x1 - x) % spacing / 2)
        y_offset = int((y1 - y) % spacing / 2)
        brush_x = x + x_offset

        pdb.gimp_selection_none(self.render)

        # top of cell:
        while brush_x <= x1:
            self._set_foreground_color()
            Fringe._brush(z, (brush_x, y))
            brush_x += spacing

        # right of cell:
        a = angle + 90

        if a > 180:
            a = angle - 90

        pdb.gimp_context_set_brush_angle(a)

        brush_y = y + y_offset

        while brush_y <= y1:
            self._set_foreground_color()
            Fringe._brush(z, (x1, brush_y))
            brush_y += spacing

        # bottom of cell:
        brush_x = x1 - x_offset
        a = angle + 180

        if a > 180:
            a = angle - 180

        pdb.gimp_context_set_brush_angle(a)

        while brush_x >= x:
            self._set_foreground_color()
            Fringe._brush(z, (brush_x, y1))
            brush_x -= spacing

        # left of cell:
        a = angle + 270

        while a > 180:
            a -= 360

        pdb.gimp_context_set_brush_angle(a)

        brush_y = y1 - y_offset
        while brush_y >= y:
            self._set_foreground_color()
            Fringe._brush(z, (x, brush_y))
            brush_y -= spacing

    def _do_backdrop_fringe(self, z, cell):
        """
        Make a image cell fringe.

        z: layer
            Has fringe material.

        cell: One
            Has cell data.

        Return: layer
            Has image.
        """
        j = self.render
        z1 = Lay.clone(j.layers[-1])
        x = Lay.offset(z)

        pdb.gimp_image_reorder_item(j, z1, self.group, x)

        z1 = RenderHub.bump(z1, cell.fringe[fr.BUMP], self.stat, is_merge=True)
        return z1

    def _do_cell(self, cell, fringe_name, plaque_name, item_name):
        """
        Process the fringe for a cell.

        cell: One
            Has cell values.

        fringe_name: string
            fringe layer name

        plaque_name: string
            fringe's plaque layer name

        item_name: string
            either a format or a cell z-list item
        """
        _type = cell.fringe[fr.TYPE]
        is_paint = True if _type != MASK else False

        if is_paint:
            z = Lay.add(self.render, fringe_name, parent=self.group)
            self._do_paint_fringe(z, cell, fringe_name)
        else:
            # fringe mask dependency:
            d = cell.plaque_data
            opacity = d[pq.OPACITY]
            if opacity and _type != ok.NONE:
                self._do_mask_fringe(item_name, cell, plaque_name)

    def _do_cells(self):
        """Do the cell fringe for a format."""
        stat = self.stat
        j = self.render
        d = self.form
        f_x = self.f_x
        parent = self.parent
        cell_name = Lay.get_layer_name(LayerKey.CELL_FRINGE, parent=parent)
        merged = Form.is_merge_cells(d)
        self._fringe_type = LayerKey.CELL_FRINGE
        row, col = stat.layout.get_division(f_x)
        double_type = Form.get_double_space_type(d)

        pdb.gimp_selection_none(j)

        for r in range(row):
            for c in range(col):
                has_fringe = True

                if has_fringe:
                    # Check to see if the cell is a dependent:
                    if merged:
                        if d[fk.Cell.Grid.PER_CELL][r][c] == (-1, -1):
                            # Yup, it was a dependent:
                            has_fringe = False

                if has_fringe:
                    if double_type:
                        has_fringe = Form.is_double_space_cell(
                            r,
                            c,
                            double_type
                        )

                if has_fringe:
                    shape = d[GRID.CELL_GRID][GRID.SHAPE]
                    cell = One(r=r, c=c, shape=shape)
                    rect = cell.cell = stat.layout.get_merge_cell_rect(
                        f_x,
                        r,
                        c
                    )
                    cell.x, cell.y = rect.position
                    cell.w, cell.h = rect.size
                    e = cell.fringe = Form.get_cell_fringe(d, r, c)
                    has_fringe = e[fr.TYPE] != ok.NONE

                if has_fringe:
                    has_fringe = True if e[fr.BRUSH][br.OPACITY] else False

                if has_fringe and double_type:
                    if not Form.is_double_space_cell(r, c, double_type):
                        has_fringe = False
                if has_fringe:
                    cell.plaque = stat.layout.get_plaque(f_x, r, c)
                    cell.plaque_data = Form.get_cell_plaque(d, r, c)
                    if not self.group:
                        z = Lay.search(
                            parent,
                            LayerKey.CELL_PLAQUE,
                            is_err=False
                        )

                        if z:
                            offset = Lay.offset(z)

                        else:
                            offset = len(parent.layers)
                        self.group = Lay.group(
                            j,
                            cell_name,
                            parent,
                            offset
                        )
                    self._do_cell(
                        cell,
                        cell_name,
                        LayerKey.CELL_PLAQUE,
                        d[fk.Layer.NAME]
                    )
        if self.group:
            z = Lay.merge_group(self.group, n=cell_name)
            self.group = None
            if self._layout_type:
                z.opacity = 66.

    def _do_free_cell(self):
        """Do the free-range cell fringe."""
        stat = self.stat
        parent = self.parent
        d = self.form
        r = ForLayout.FREE_CELL
        free_cell_name = Lay.get_layer_name(
            LayerKey.FREE_CELL_FRINGE,
            parent=parent
        )

        j = self.render
        self._fringe_type = LayerKey.FREE_CELL_FRINGE

        for e in reversed(d[fk.Layer.CELL_LIST]):
            opacity = e[fr.CELL_FRINGE][fr.BRUSH][br.OPACITY]
            _type = e[fr.CELL_FRINGE][fr.TYPE]
            if opacity and _type != ok.NONE:
                j1 = RollerImage.get_image(
                    self.session,
                    e[pl.IMAGE_PLACE][pl.IMAGE_DICT]
                )
                if not j1:
                    j1 = RollerImage(None, "")

                Form.prep_free_cell_image(j1, e, stat.render.size)

                cell = One(
                    r=r,
                    c=r,
                    plaque=j1.plaque,
                    shape=e[fck.CELL][CellKey.SHAPE]
                )
                cell.w, cell.h = j1.cell.size
                cell.x, cell.y = j1.cell.position
                cell.fringe = Form.get_cell_fringe(e, r, r)
                cell.plaque_data = Form.get_cell_plaque(e, r, r)

                if not self.group:
                    z = Lay.search(
                        parent,
                        LayerKey.FREE_CELL_PLAQUE,
                        is_err=False
                    )

                    if z:
                        a = Lay.offset(z)

                    else:
                        a = len(parent.layers)
                        for i in BOTTOM_LAYERS:
                            a -= int(
                                Lay.search(
                                    parent,
                                    i,
                                    is_err=False
                                ) is not None
                            )
                        if d[ABOVE]:
                            for i in CELL_FRINGE_LAYERS:
                                a -= int(
                                    Lay.search(
                                        parent,
                                        i,
                                        is_err=False
                                    ) is not None
                                )
                    self.group = Lay.group(
                        j,
                        free_cell_name,
                        parent,
                        a
                    )

                layer_key = LayerKey.CELL_PLAQUE if self._layout_type else \
                    LayerKey.FREE_CELL_PLAQUE

                self._do_cell(
                    cell,
                    free_cell_name,
                    layer_key,
                    e[fck.CELL][CellKey.NAME]
                )
                RollerImage.close_image(j1)
        if self.group:
            z = Lay.merge_group(self.group, free_cell_name)
            self.group = None
            if self._layout_type:
                z.opacity = 66.

    def _do_fringe_context(self, z, cell):
        """
        Paint fringe.

        z: layer
            to receive paint

        cell: One
            Has cell data.

        Return: layer
            with paint
        """
        j = self.render
        d = cell.fringe
        brush = d[fr.BRUSH][br.BRUSH]
        self._colors = None

        if brush not in self.stat.brush_list:
            Comm.info_msg(ff.MISSING_ITEM.format("self", "brush", brush))

        else:
            if self._layout_type:
                self._color = FC

            elif d[fr.TYPE] == ff.Fringe.TWO_COLOR:
                self._colors = d[fr.COLOR_1], d[fr.COLOR_2]
                callback = self._set_foreground_color

            else:
                self._color = d[fr.COLOR]

            if not self._colors:
                pdb.gimp_context_set_foreground(self._color)
                callback = None

            else:
                self._color = self._colors[0]

            brush_size = d[fr.BRUSH][br.SIZE]
            spacing = d[fr.BRUSH][br.SPACING]
            f = spacing / brush_size
            angle = d[fr.BRUSH][br.ANGLE]

            pdb.gimp_selection_shrink(j, d[fr.CONTRACT])
            if Sel.is_sel(j):
                pdb.gimp_context_set_dynamics('Dynamics Off')
                pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
                pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
                pdb.gimp_context_set_brush_aspect_ratio(0.)
                pdb.gimp_context_set_brush_force(1)
                pdb.gimp_context_set_antialias(1)
                pdb.gimp_context_set_brush_angle(angle)
                pdb.gimp_context_set_brush_spacing(f)
                pdb.gimp_context_set_brush_hardness(d[fr.BRUSH][br.HARDNESS])
                pdb.gimp_context_set_brush(brush)
                pdb.gimp_context_set_brush_size(brush_size)
                pdb.gimp_context_set_opacity(d[fr.BRUSH][br.OPACITY])
                pdb.gimp_context_set_foreground(self._color)

                if cell.shape == RECTANGLE:
                    self._brush_rectangle(z, angle, spacing)

                else:
                    pdb.plug_in_sel2path(j, z)

                    stroke = j.active_vectors.strokes[0]

                    pdb.gimp_selection_none(j)
                    RenderHub.brush_stroke_on_stroke(
                        z,
                        brush,
                        brush_size,
                        stroke,
                        spacing,
                        callback=callback
                    )
                if d[fr.TYPE] != MASK:
                    z = RenderHub.bump(z, d[fr.BUMP], self.stat, is_merge=True)
        return z

    def _do_gradient_fringe(self, z, cell, name):
        """
        Make a gradient cell fringe.

        z: layer
            Has material to select.

        cell: One
            Has cell data.

        name: string
            layer name with fringe

        Return: layer
            Has gradient.
        """
        def draw_gradient(_start_x, _end_x, _start_y, _end_y):
            """
            Draw a gradient given a layer, a start-point and an end-point.
            """
            pdb.gimp_drawable_edit_gradient_fill(
                z1,
                fg.GRADIENT_TYPE_LIST.index(gradient_type),
                gf.OFFSET_0,
                gf.YES_SUPERSAMPLE,
                gf.SUPERSAMPLE_MAX_DEPTH_2,
                gf.SUPERSAMPLE_THRESHOLD_0,
                gf.YES_DITHER,
                _start_x,
                _start_y,
                _end_x,
                _end_y
            )

        j = self.render
        z1 = None
        gradient = cell.fringe[fr.GRADIENT]

        if gradient in self.stat.gradient_list:
            Sel.item(z)

            a, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
            w, h = x1 - x, y1 - y
            if a:
                gradient_type = cell.fringe[fr.GRADIENT_TYPE]

                RenderHub.set_fill_context(fg.FILL_DICT)
                pdb.gimp_context_set_gradient(gradient)
                pdb.gimp_context_set_gradient_blend_color_space(
                    fu.GRADIENT_BLEND_RGB_PERCEPTUAL
                )
                pdb.gimp_context_set_gradient_reverse(0)

                if gradient_type in fg.SHAPE_BURST:
                    j1 = pdb.gimp_image_new(w, h, fu.RGB)
                    z1 = Lay.add(j1, 'temp')

                    pdb.gimp_selection_all(j1)
                    Sel.fill(z1, (127, 127, 127))
                    pdb.gimp_selection_none(j1)
                    draw_gradient(0, 0, 0, 0)
                    pdb.gimp_edit_copy_visible(j1)
                    pdb.gimp_image_delete(j1)

                    z1 = Lay.paste(z)
                    z1.name = name

                    pdb.gimp_layer_set_offsets(z1, x, y)
                    z1 = RenderHub.bump(
                        z1,
                        cell.fringe[fr.BUMP],
                        self.stat,
                        is_merge=True
                    )
                else:
                    z1 = Lay.add(j, name, parent=self.group)
                    start_x, end_x, start_y, end_y = \
                        RenderHub.get_gradient_points(
                            cell.fringe[fr.GRADIENT_ANGLE],
                            x,
                            y,
                            w,
                            h
                        )

                    Sel.rect(j, x, y, w, h, option=REPLACE)
                    draw_gradient(start_x, end_x, start_y, end_y)
                    z1 = RenderHub.bump(
                        z1,
                        cell.fringe[fr.BUMP],
                        self.stat,
                        is_merge=True
                    )

        else:
            Comm.info_msg(
                ff.MISSING_ITEM.format("self", "gradient", gradient)
            )
        return z1

    def _do_image_fringe(self, z, cell):
        """
        Make a image cell fringe.

        z: layer
            Has fringe material.

        cell: One
            Has cell data.

        Return: layer
            Has image.
        """
        j = self.render
        z1 = None

        Sel.item(z)

        a, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        w, h = x1 - x, y1 - y

        if a:
            pdb.gimp_selection_none(j)

            image = cell.fringe[fr.IMAGE]
            j1 = RollerImage.get_image(self.session, image)
            if j1:
                j2 = j1.j

                pdb.gimp_selection_none(j2)
                pdb.gimp_edit_copy_visible(j2)

                j2 = pdb.gimp_edit_paste_as_new_image()

                Form.shape(j2, w, h)

                z1 = Lay.paste(z)

                pdb.gimp_layer_set_offsets(z1, x, y)

                z1 = RenderHub.bump(
                    z1,
                    cell.fringe[fr.BUMP],
                    self.stat,
                    is_merge=True
                )
                RollerImage.close_image(j1)
        return z1

    def _do_layer(self):
        """Do fringe for the layer."""
        d = self.form
        if d[fr.LAYER_FRINGE][fr.TYPE] != ok.NONE:
            j = self.render
            parent = self.parent
            cell = One(r=ForLayout.LAYER, c=ForLayout.LAYER, shape=RECTANGLE)
            size = self.session['size']

            if d[fr.LAYER_FRINGE][fr.OBEY_MARGINS]:
                cell.y, bottom, cell.x, right = Form.get_layer_margin(
                    d,
                    size
                )
                cell.w = size[0] - cell.x - right
                cell.h = size[1] - cell.y - bottom

            else:
                cell.x = cell.y = 0
                cell.w, cell.h = size

            w, h = cell.x + cell.w, cell.y + cell.h
            cell.plaque = cell.x, cell.y, w, cell.y, w, h, cell.x, h
            cell.plaque_data = d[pq.LAYER_PLAQUE]
            self._fringe_type = LayerKey.LAYER_FRINGE
            layer_name = Lay.get_layer_name(
                LayerKey.LAYER_FRINGE,
                parent=parent
            )

            # Put the fringe on top of the layer plaque:
            z = Lay.search(parent, LayerKey.LAYER_PLAQUE, is_err=False)
            a = Lay.offset(z) if z else len(parent.layers)
            b = Lay.offset(
                Lay.search(
                    parent,
                    LayerKey.IMAGE,
                    is_err=False
                )
            ) + 1
            a = max(a, b)
            self.group = Lay.group(j, layer_name, parent, a)
            e = cell.fringe = d[fr.LAYER_FRINGE]
            is_paint = True if e[fr.TYPE] != MASK else False

            if is_paint:
                z = Lay.add(j, layer_name, parent=self.group)
                self._do_paint_fringe(z, cell, layer_name)
            else:
                # fringe mask dependency:
                e = d[pq.LAYER_PLAQUE]
                opacity = e[pq.OPACITY]
                _type = e[pq.TYPE]
                if opacity and _type != ok.NONE:
                    self._do_mask_fringe(
                        d[fk.Layer.NAME],
                        cell,
                        LayerKey.LAYER_PLAQUE
                    )

            z = Lay.merge_group(self.group, n=layer_name)
            self.group = None
            if self._layout_type:
                z.opacity = 66.

    def _do_mask_fringe(self, item_name, cell, plaque_name):
        """
        Mask the edge of a cell.

        item_name: string
            id of a format or free cell z-item

        cell: One
            Has cell data.

        plaque_name: string
            to find the fringe layer's plaque layer
        """
        stat = self.stat
        parent = self.parent
        j = self.render
        r, c = cell.r, cell.c
        d = cell.plaque_data
        opacity = d[pq.OPACITY]
        plaque_type = d[pq.TYPE]
        mask_sel = None
        if opacity and plaque_type != ok.NONE:
            z = Lay.search(parent, plaque_name, is_err=False)
            if z:
                # mask layer:
                z1 = Lay.add(j, 'Mask', parent=parent)

                if self._layout_type:
                    x, y, w, h = Fringe._get_position_info(cell)

                    Sel.rect(j, x, y, w, h, option=REPLACE)
                    sel = pdb.gimp_selection_save(j)

                else:
                    sel = stat.get_plaque_sel(item_name, r, c)
                    Sel.load(stat.render.image, sel)

                if Sel.is_sel(j):
                    z1 = self._do_fringe_context(z1, cell)

                    Sel.item(z1)

                    mask_sel = pdb.gimp_selection_save(j)
                    Lay.clear_sel(z)

                else:
                    sel = None

                pdb.gimp_image_remove_layer(j, z1)

                if not self._layout_type and sel:
                    Sel.load(j, sel)
                    Sel.load(j, mask_sel, fu.CHANNEL_OP_SUBTRACT)
                    stat.save_plaque_sel(item_name, r, c)

                if self._layout_type:
                    pdb.gimp_image_remove_channel(j, sel)
                if mask_sel:
                    pdb.gimp_image_remove_channel(j, mask_sel)

    def _do_paint_fringe(self, z, cell, name):
        """
        Paint a fringe texture on the cell fringe layer.

        z: layer
            for fringe material

        cell: One
            Has cell data.

        name: string
            layer name with fringe
        """
        def clip_cell():
            """Remove material outside of the cell."""
            if d[fr.CLIP_TO_CELL]:
                Sel.load(j, sel)
                Sel.invert(j)
                Lay.clear_sel(z)

        j = self.render
        d = cell.fringe

        pdb.gimp_selection_none(j)

        if Form.is_rectangle_shape(self.form):
            x, y, w, h = Fringe._get_position_info(cell)
            Sel.rect(j, x, y, w, h)

        else:
            Form.select_shape(j, cell.plaque)
        if Sel.is_sel(j):
            sel = pdb.gimp_selection_save(j)
            z = self._do_fringe_context(z, cell)

            Sel.item(z)
            if Sel.is_sel(j):
                if self._layout_type:
                    clip_cell()
                else:
                    if d[fr.TYPE] in FRINGE_MAT:
                        # Apply material and clear outside
                        # of fringe-layer-selection:
                        if d[fr.TYPE] == ff.Fringe.GRADIENT:
                            z1 = self._do_gradient_fringe(z, cell, name)

                        elif d[fr.TYPE] == ff.Fringe.IMAGE:
                            z1 = self._do_image_fringe(z, cell)

                        elif d[fr.TYPE] == ff.Fringe.PATTERN:
                            z1 = self._do_pattern_fringe(z, cell, name)

                        else:
                            z1 = self._do_backdrop_fringe(z, cell)
                        if z1:
                            Sel.item(z)
                            Sel.clear_outside_of_selection(z1)
                            pdb.gimp_image_remove_layer(j, z)
                            z = z1

                    clip_cell()

                    if (
                        d[fr.SHADOW][sh.TYPE] != ok.NONE
                        and not self._layout_type
                    ):
                        z.name = name
                        z = Shadow.do_shadows(
                            z,
                            cell.fringe[fr.SHADOW],
                            self.stat,
                            self._fringe_type
                        )
                        clip_cell()
                    z.name = name
            pdb.gimp_image_remove_channel(j, sel)

    def _do_pattern_fringe(self, z, cell, name):
        """
        Make a pattern cell fringe.

        z: layer
            Has fringe material.

        cell: One
            Has cell data.

        name: string
            layer name with fringe

        Return: layer
            Has pattern.
        """
        j = self.render
        z1 = None
        pattern = cell.fringe[fr.PATTERN]

        if pattern in self.stat.pattern_list:
            if pattern in self.stat.pattern_list:
                Sel.item(z)

                a, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
                w, h = x1 - x, y1 - y
                if a:
                    z1 = Lay.add(
                        j,
                        name,
                        parent=self.group,
                        offset=Lay.offset(z)
                    )

                    Sel.rect(j, x, y, w, h, option=REPLACE)
                    RenderHub.set_fill_context(fg.FILL_DICT)
                    pdb.gimp_context_set_pattern(pattern)
                    pdb.gimp_drawable_edit_bucket_fill(
                        z1,
                        fu.FILL_PATTERN,
                        min(self.stat.render.size[0] - 1, x + w // 2),
                        min(self.stat.render.size[1] - 1, y + h // 2)
                    )
                    z1 = RenderHub.bump(
                        z1,
                        cell.fringe[fr.BUMP],
                        self.stat,
                        is_merge=True
                    )

        else:
            Comm.info_msg(ff.MISSING_ITEM.format("self", "pattern", pattern))
        return z1

    @staticmethod
    def _get_position_info(cell):
        """
        Return position info.

        cell: One
            Has cell data.
        """
        return cell.x, cell.y, cell.w, cell.h

    def _set_foreground_color(self):
        """
        Set the foreground color for the brush to use.

        Alternate colors if using two colors.
        """
        if self._colors:
            if len(self._colors) == 2:
                if self._colors[0] == self._color:
                    self._color = self._colors[1]
                else:
                    self._color = self._colors[0]
            pdb.gimp_context_set_foreground(self._color)
