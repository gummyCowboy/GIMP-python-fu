#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay
import gimpfu as fu

de = Fu.Despeckle
em = Fu.Emboss
er = Fu.Erode
hs = Fu.HueSaturation
pdb = fu.pdb
um = Fu.UnsharpMask
ELEVATION_30 = 30.


class CrystalCave:
    """Create a grey backdrop with layered crystal-like properties."""

    def __init__(self, one):
        """
        Create a Crystal Cave backdrop-style.

        one: One
            Has variables.
        """
        self.stat = one.stat
        self.layer = one.z
        self.group_key = one.k
        j = one.stat.render.image
        z = Lay.clone(one.z)
        group = self._make_group(z)

        pdb.plug_in_plasma(
            j,
            z,
            one.d[ok.RANDOM_SEED],
            Fu.Plasma.MEDIUM_TURBULENCE
        )

        z1 = Lay.clone(z)

        pdb.plug_in_emboss(
            j,
            z,
            one.stat.light_angle,
            ELEVATION_30,
            em.DEPTH_1,
            em.EMBOSS
        )

        z2 = Lay.clone(z)

        Lay.clone(z2)
        pdb.plug_in_emboss(
            j,
            z1,
            one.stat.light_angle,
            ELEVATION_30,
            em.MAX_DEPTH,
            em.EMBOSS
        )

        z1.mode = fu.LAYER_MODE_COLOR_ERASE

        pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
        pdb.gimp_image_reorder_item(j, z2, z2.parent, 0)

        z2.mode = fu.LAYER_MODE_LINEAR_LIGHT
        z = Lay.merge_group(group)
        group = self._make_group(z)
        z1 = Lay.clone(z)
        z1.mode = fu.LAYER_MODE_EXCLUSION

        pdb.plug_in_despeckle(
            j,
            z,
            de.RADIUS_16,
            de.RECURSIVE_ADAPTIVE,
            de.WHITE_64,
            de.BLACK_191
        )
        pdb.plug_in_unsharp_mask(
            j,
            z,
            um.RADIUS_12,
            um.AMOUNT_5,
            um.THRESHOLD_42
        )

        for _ in range(3):
            pdb.plug_in_wind(
                j,
                z,
                Fu.Wind.THRESHOLD_10,
                Fu.Wind.FROM_LEFT,
                Fu.Wind.STRENGTH_30,
                Fu.Wind.WIND,
                Fu.Wind.LEADING_EDGE
            )

        z = Lay.merge_group(group)
        group = self._make_group(z)
        z1 = Lay.clone(z)
        z2 = Lay.clone(z1)

        pdb.plug_in_plasma(
            j,
            z1,
            one.d[ok.RANDOM_SEED],
            Fu.Plasma.LOWEST_TURBULENCE
        )

        z1.mode = fu.LAYER_MODE_HSV_VALUE
        z1.opacity = 10.

        pdb.plug_in_erode(
            j,
            z,
            er.PROPAGATE_BLACK,
            er.RGB_CHANNELS,
            er.FULL_RATE,
            er.DIRECTION_MASK_0,
            er.LOW_LIMIT_0,
            er.UPPER_LIMIT_255
        )
        CrystalCave._flip(z2)

        z2.mode = fu.LAYER_MODE_DODGE

        pdb.gimp_edit_copy_visible(j)

        z3 = Lay.paste(z2)
        z3.mode = fu.LAYER_MODE_DIFFERENCE
        z2.mode = fu.LAYER_MODE_HSV_VALUE
        z2.opacity = 50.

        CrystalCave._flip(z2)

        z1.mode = fu.LAYER_MODE_BURN
        z1.opacity = 100.

        pdb.gimp_drawable_hue_saturation(
            z1,
            fu.HUE_RANGE_ALL,
            hs.HUE_OFFSET_0,
            hs.LIGHTNESS_0,
            hs.SATURATION_MINUS_95,
            hs.OVERLAP_0
        )
        pdb.gimp_edit_copy_visible(j)

        z4 = Lay.paste(z3)
        z4.mode = fu.LAYER_MODE_HSV_VALUE

        # Remove 'z1':
        pdb.gimp_image_remove_layer(j, z1)

        z5 = Lay.clone(z4)
        z5.mode = fu.LAYER_MODE_EXCLUSION
        z5.opacity = 50.
        z = Lay.merge_group(group)

        self._make_group(z)

        z1 = Lay.clone(z)

        pdb.gimp_drawable_invert(z1, Fu.DrawableInvert.NO_LINEAR)
        pdb.plug_in_gauss_rle2(
            j,
            z1,
            Fu.GaussRLE2.BLUR_HORZ_3,
            Fu.GaussRLE2.BLUR_VERT_36
        )

        z1.mode = fu.LAYER_MODE_HARDLIGHT
        z1.opacity = 75.
        Lay.clone(z1)

    @staticmethod
    def _flip(z):
        """
        Flip a layer both horizontally and vertically.

        z: layer
            to flip
        """
        Lay.flip(z)
        Lay.flip(z, horizontal=1)

    def _make_group(self, z):
        """
        Make a layer group.

        z: layer
            to move to group

        return:
            group: layer
                new
        """
        j = z.image
        group = Lay.group(j, self.group_key, parent=self.layer.parent)

        pdb.gimp_image_reorder_item(j, z, group, 0)
        return group
