#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_border_line import BorderLine
from roller_image_effect import ImageEffect
from roller_one_constant import ForGradient as fg, OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_one_constant_fu import Fu
from roller_render_hub import RenderHub
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb


class SquarePunch(BorderLine):
    """Add square holes to a frame that fits around a BorderLine frame."""

    def __init__(self, one):
        """
        Do the Square Punch image-effect.

        one: One
            Has variables.
        """
        BorderLine.__init__(
            self,
            one,
            framer=self.make_sel,
            filler=lambda *_: None
        )

    @staticmethod
    def draw_squares(z, d):
        """
        Draw squares on the rotated layer.

        Create a pattern (a black square).
        Use the clipboard to hold the pattern.
        Fill the target layer with the pattern.

        z: layer
            target layer

        d: dict
            Has options.

        Return: layer
            work-in-progress
            Has material to select.
        """
        side = d[ok.GAP_WIDTH]
        w = side + d[ok.LINE_WIDTH]
        j1 = pdb.gimp_image_new(w, w, fu.RGB)
        z1 = Lay.add(j1, "pattern")

        Lay.color_fill(z1, (255, 255, 255))

        x = (w - side) // 2
        y = (w - side) // 2

        Sel.rect(
            j1,
            x,
            y,
            w,
            w,
            option=fu.CHANNEL_OP_REPLACE
        )
        Sel.fill(z1, (0, 0, 0))
        pdb.gimp_selection_none(j1)
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)
        RenderHub.set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_pattern("Clipboard Image")
        pdb.gimp_drawable_edit_bucket_fill(
            z,
            fu.FILL_PATTERN,
            Fu.BucketFill.X_IS_1,
            Fu.BucketFill.Y_IS_1
        )
        pdb.plug_in_colortoalpha(z.image, z, (0, 0, 0))
        return z

    def make_sel(self, d):
        """
        Modify the current selection with the selected grid lines.

        Add the grid selection to the border selection
        within the bounds of the filler selection.

        d: dict
            Has options.

        Return: state of selection
            of render
        """
        stat = self.stat
        j = stat.render.image
        sel = stat.save_render_sel()
        z = Lay.add(j, ek.CIRCLE_PUNCH, parent=self.parent)
        z1 = RenderHub.do_rotated_layer(stat, z, d, SquarePunch.draw_squares)

        Sel.isolate(z1, self.fill_sel)
        Sel.item(z1)
        Sel.grow(j, 1, 1)
        pdb.gimp_selection_feather(j, 1)
        pdb.gimp_image_remove_layer(j, z)
        pdb.gimp_image_remove_layer(j, z1)
        Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
