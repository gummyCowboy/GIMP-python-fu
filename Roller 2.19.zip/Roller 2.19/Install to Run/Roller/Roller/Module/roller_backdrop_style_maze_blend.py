#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
import gimpfu as fu

cs = Fu.ColorSelect
ed = Fu.Edge
em = Fu.Emboss
pdb = fu.pdb
ELEVATION_20 = 20.
STRENGTH_100 = 100
THRESHOLD_POINT_5 = 127


class MazeBlend:
    """
    Use a maze graph to produce softly blended backdrop.
    """

    def __init__(self, one):
        """
        Do the Maze Blend backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        if Lay.has_pixel(one.z):
            d = one.d
            group = Lay.group(j, one.k, parent=one.z.parent)
            z = Lay.add(j, one.k, parent=group)

            # Preserve:
            q = pdb.gimp_context_get_foreground()
            q1 = pdb.gimp_context_get_background()

            Lay.color_fill(z, (127, 127, 127))

            z = Lay.clone(one.z)

            pdb.gimp_image_reorder_item(j, z, group, 0)
            pdb.plug_in_pixelize2(j, z, one.session['w'], one.session['h'])

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            z1 = Lay.clone(z)
            z1.mode = fu.LAYER_MODE_MULTIPLY
            z1.opacity = 25.
            w = one.session['w'] // d[ok.COLUMN_MAZE]
            h = one.session['h'] // d[ok.ROW_MAZE]
            w1 = int((w + h) / 1.5)

            pdb.gimp_selection_none(j)
            pdb.gimp_context_set_background((0, 0, 0))
            pdb.gimp_context_set_foreground((255, 255, 255))
            pdb.plug_in_maze(j, z1, w, h, 1, 0, d[ok.RANDOM_SEED], 0, 0)
            Sel.color(z1, (255, 255, 255))

            sel = one.stat.save_render_sel()
            z2 = Lay.clone(z1)
            z2.mode = fu.LAYER_MODE_OVERLAY

            pdb.plug_in_edge(j, z1, ed.AMOUNT_1, ed.NO_WRAP, ed.SOBEL)

            for _ in range(4):
                Lay.dilate(z1)

            pdb.gimp_drawable_invert(z2, 0)
            Lay.color_fill(z2, (127, 127, 127))
            Sel.load(j, sel)
            Sel.clear_outside_of_selection(z2)
            pdb.plug_in_emboss(
                j,
                z2,
                one.stat.light_angle,
                ELEVATION_20,
                em.DEPTH_3,
                em.EMBOSS
            )
            pdb.gimp_drawable_invert(z1, 0)
            Lay.blur(z1, w1)
            Sel.load(j, sel)
            Sel.invert(j)
            Sel.clear_outside_of_selection(z1)

            # Restore:
            pdb.gimp_context_set_foreground(q)
            pdb.gimp_context_set_background(q1)
