#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_image_effect import ImageEffect
from roller_one_constant import (
    BackdropStyleKey as bsk,
    FormatKey as fk,
    OptionKey as ok,
    SessionKey as sk,
    WidgetKey as wk
)
from roller_one_preset import Preset
from roller_option_limit import OptionStat
from roller_widget_button import RollerButton

ek = ImageEffect.Key
BACKDROP = sk.BACKDROP


class OptButton(RollerButton):
    """Has a label that reflects its data."""

    def __init__(self, **d):
        """
        Create a GTK Button that is attached to an GTK Alignment.

        on_action: function
            callback on action

        d: dict
            Has button variables.

        """
        self.value = {}
        self.stat = d['stat']
        self._get_session_dict = d['get_session_dict']
        self._open_window = d['button_action']
        self._update_window = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self.do_choice
        RollerButton.__init__(self, **d)

    @staticmethod
    def _init_formats(d):
        """
        Give a new format the default settings.

        d: dict
            of session opt
        """
        def _add_default():
            # Add the default:
            d[i] = {
                ek.IMAGE_EFFECT: Preset.get_default(ek.IMAGE_EFFECT)
            }

            # Add 'No Effect':
            _type = d[i][ek.IMAGE_EFFECT][ek.IMAGE_EFFECT]
            d[i][_type] = Preset.get_default(_type)

        # format image-effect:
        for i in d[sk.FORMAT_NAME_LIST]:
            if i in d:
                stage = d[i][ek.IMAGE_EFFECT][ek.IMAGE_EFFECT]
                if not Preset.is_preset(stage):
                    _add_default()
            else:
                _add_default()

    def _pass_bounds(self, d):
        """
        Put steps through a bounds check.

        d: dict
            of session opt
        """
        name = d[sk.FORMAT_NAME_LIST]

        # Pass dictionaries:
        for i in d:
            # frame gradient:
            if i == BACKDROP or i in name:
                # sub-steps:
                for j in d[i]:
                    self.stat.option_limit.pass_bounds(d[i][j], j)
            elif i == ek.FRAME_GRADIENT:
                self.stat.option_limit.pass_bounds(d[i], i)

    @staticmethod
    def _update_format_list(d):
        """
        Update the internal format list names from the session dict.

        d: dict
            of session
        """
        q = d[sk.SESSION_OPT][sk.FORMAT_NAME_LIST] = []
        for i in d[sk.FORMAT_LIST]:
            q.append(i[fk.Layer.NAME])

    def do_choice(self, g):
        """
        Open a choice window.

        Alter a button's value.

        g: RollerButton
            activated
            to receive choice
            not used
        """
        self._open_window(self)
        self._update_window(self)

    def get_render_steps(self, d):
        """
        Generate a list of render steps.

        A step is a tuple.
            option type, option key

        d: dict
            of session
            Is updated.
            Has render options.

        Return: list
            of render steps
        """
        n = BACKDROP
        steps = [(n, bsk.BACKDROP_IMAGE)]
        e = d[sk.SESSION_OPT]
        OptButton._update_format_list(d)
        OptButton._init_formats(e)
        self._pass_bounds(e)

        # Get the three main steps:
        backdrop_style = e[BACKDROP][bsk.BACKDROP_STYLE][ok.BACKDROP_STYLE]

        if backdrop_style != bsk.BACKDROP_IMAGE:
            steps.append((n, backdrop_style))

        # Traverse the list in reverse order:
        for n in e[sk.FORMAT_NAME_LIST][::-1]:
            # the effect steps:
            main_effect = e[n][ek.IMAGE_EFFECT][ok.IMAGE_EFFECT]
            effects = OptionStat.get_effect_keys(main_effect)
            for effect in effects:
                steps.append((n, effect))
                if effect not in e[n]:
                    # Repair:
                    e[n][effect] = Preset.get_default(effect)
        return steps, e

    def get_steps(self, d):
        """
        Collect steps from session.

        Each steps has one or more sub-steps.
        Collect the sub-steps into a 2D table
        that corresponds with the step order.
        Use when populating navigation lists.

        d: dict
            of session

        Return: tuple
            list of steps
            2D list of sub-steps
        """
        e = d[sk.SESSION_OPT]

        OptButton._update_format_list(d)
        OptButton._init_formats(e)
        self._pass_bounds(e)

        # backdrop-style:
        q = [[bsk.BACKDROP_STYLE, bsk.BACKDROP_IMAGE]]
        style = e[BACKDROP][bsk.BACKDROP_STYLE][ok.BACKDROP_STYLE]

        if not Preset.is_preset(style):
            # error correction:
            e[BACKDROP][bsk.BACKDROP_STYLE] = Preset.get_default(
                bsk.BACKDROP_STYLE
            )
            style = bsk.BACKDROP_IMAGE

        if style != bsk.BACKDROP_IMAGE:
            q[0].append(style)

        # Reverse the order of the list:
        name = e[sk.FORMAT_NAME_LIST][::-1]

        # format image-effect:
        for i in name:
            q1 = [ek.IMAGE_EFFECT]
            stage = e[i][ek.IMAGE_EFFECT][ek.IMAGE_EFFECT]

            if not Preset.is_preset(stage):
                # error correction:
                stage = ek.IMAGE_EFFECT

            substeps = OptionStat.get_effect_keys(stage)

            for j in substeps:
                q1.append(j)
            q.append(q1)
        return [BACKDROP] + name, q

    def get_value(self):
        """
        Is part of the Widget template.

        Override the RollerButton method.

        Return: value
            from 'self.value'
        """
        return deepcopy(self.value)
