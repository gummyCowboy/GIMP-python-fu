#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_style_colored_grid import ColoredGrid
from roller_one import One
from roller_one_constant import ForBump as fb, OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb


class SpacetimeFabric:
    """Use wind to shred lines and make a fabric texture."""

    def __init__(self, one):
        """
        Create the Spacetime Fabric backdrop-style.

        one: One
            Has variables.
        """
        stat = one.stat
        j = stat.render.image
        if Lay.has_pixel(one.z):
            z = Lay.clone(one.z)
            d = deepcopy(one.d)
            d[ok.COLOR_1] = 255, 255, 255
            d[ok.COLOR_2] = 0, 0, 0
            d[ok.MODE] = "Normal"
            d[ok.OPACITY] = 100
            d[ok.ROTATE] = 0
            d[ok.THRESHOLD] = 1.
            d[ok.INVERT] = 0
            d[ok.BUMP] = {ok.BUMP: fb.NONE}

            ColoredGrid(One(d=d, k=one.k, stat=stat, z=z))

            z = j.active_layer
            w = one.session['w'] // d[ok.COLUMN]
            h = one.session['h'] // d[ok.ROW]
            w = min(w, h)
            w = max(1, w // 4)

            pdb.plug_in_edge(j, z, 10, 1, 4)

            for _ in range(w):
                Lay.dilate(z)

            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
            Sel.item(z)

            white_sel = stat.save_render_sel()

            pdb.gimp_selection_none(j)
            pdb.gimp_image_remove_layer(j, z)

            # Create three layers, one for each color:
            group = Lay.group(j, one.k, parent=one.z.parent)
            z = red = Lay.clone(one.z)
            z.name = "Red"

            pdb.gimp_image_reorder_item(j, z, group, 0)

            z = green = Lay.clone(z)
            z.name = "Green"
            z = blue = Lay.clone(z)
            z.name = "Blue"
            n = d[ok.COMPONENT]

            pdb.plug_in_colortoalpha(j, red, (0, 255, 255))
            pdb.plug_in_colortoalpha(j, green, (255, 0, 255))
            pdb.plug_in_colortoalpha(j, blue, (255, 255, 0))

            if n == "Red":
                z = red
                q = green, blue

            elif n == "Green":
                z = green
                q = red, blue

            else:
                z = blue
                q = red, green

            Sel.load(j, white_sel)
            Lay.clear_sel(z, keep_sel=True)
            pdb.gimp_selection_none(j)

            w1 = max(2, w // 2)

            # Shred the edges of the top layer:
            for i in range(10):
                for i1 in range(4):
                    z.name = n + str(i) + str(i1)
                    pdb.plug_in_wind(
                        j,
                        z,
                        Fu.Wind.THRESHOLD_0,
                        i1,
                        w1,
                        Fu.Wind.BLAST,
                        Fu.Wind.LEADING_EDGE
                    )
                    Lay.blur(z, 1.)

            pdb.gimp_image_reorder_item(j, z, group, 0)

            # Add texture to the bottom layers:
            for z in q:
                n = z.name
                for i in range(3):
                    for i1 in range(4):
                        pdb.plug_in_wind(j, z, 0, i1, (50, 25, 12)[i], 1, 1)
                        Lay.blur(z, 1.5)
                        z.name = n + str(i) + str(i1)

                z = Lay.clone(z)

                pdb.plug_in_engrave(j, z, i + 2, 1)

                z.mode = fu.LAYER_MODE_BURN
                pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            z = Lay.merge_group(group)
            if d[ok.EMBOSS]:
                z = Lay.clone(z)

                pdb.plug_in_emboss(j, z, stat.light_angle, 30., 1, 1)
                z.mode = fu.LAYER_MODE_OVERLAY
