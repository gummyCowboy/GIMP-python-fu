#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerKey
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

em = Fu.Emboss
pdb = fu.pdb
BRIGHTNESS_ZERO = 0
CONTRAST_50 = 50
ELEVATION_30 = 30.


class BorderLine:
    """Create a metallic-like border around images."""

    def __init__(self, one, filler=None, framer=None):
        """
        Do the Border Line image-effect.

        one: One
            Has variables.

        filler: function
            Call to fill a frame.

        framer: function
            Call to add more frame.
        """
        stat = self.stat = one.stat
        self.option_key = one.k
        parent = self.parent = one.parent
        self.session = one.session
        d = one.d
        j = stat.render.image
        z = Lay.add(
            j,
            Lay.get_layer_name(LayerKey.FRAME, parent=parent),
            parent=parent,
            offset=Lay.offset(Lay.search(parent, LayerKey.IMAGE))
        )
        z1 = Lay.clone_opaque(
            stat.render.get_image_layer(
                Lay.get_format_name_from_group(parent)
            ),
            d[ok.MAKE_OPAQUE]
        )

        Sel.item(z1)

        image_sel = stat.save_render_sel()

        Sel.grow(j, d[ok.FRAME_WIDTH], d[ok.FRAME_TYPE])

        if filler:
            # Create filler and outer selections:
            sel = stat.save_render_sel()

            Sel.grow(j, d[ok.WIDTH], d[ok.FRAME_TYPE])
            Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
            Sel.grow(j, 1, d[ok.FRAME_TYPE])

            self.fill_sel = stat.save_render_sel()

            Sel.grow(
                j,
                max(int(d[ok.FRAME_WIDTH] / 3.5), 3),
                d[ok.FRAME_TYPE]
            )
            Sel.load(j, self.fill_sel, option=fu.CHANNEL_OP_SUBTRACT)
            Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

        if framer:
            framer(d)

        Sel.load(j, image_sel, option=fu.CHANNEL_OP_SUBTRACT)
        Sel.fill(z, (127, 127, 127))
        pdb.gimp_selection_none(stat.render.image)
        pdb.plug_in_emboss(
            j,
            z,
            stat.light_angle,
            ELEVATION_30,
            em.DEPTH_1,
            em.EMBOSS
        )
        pdb.gimp_brightness_contrast(z, BRIGHTNESS_ZERO, CONTRAST_50)
        pdb.plug_in_antialias(j, z)
        pdb.gimp_image_remove_layer(j, z1)

        z1 = BorderLine.add_bump_layer(z, d, parent)
        if filler:
            filler(z1, d)

    @staticmethod
    def add_bump_layer(z, d, parent):
        """
        Add a bump layer.

        z: layer
            to clone from

        parent: layer
            format group

        d: dict
            Has options.
        """
        z1 = Lay.clone(z)

        RenderHub.add_noise(z1, d)

        z1.mode = fu.LAYER_MODE_HARDLIGHT
        z1.name = Lay.get_layer_name(LayerKey.BUMP, parent=parent)
        z1.opacity = d[ok.NOISE_OPACITY]

        Sel.item(z)
        Sel.clear_outside_of_selection(z1)
        return z1
