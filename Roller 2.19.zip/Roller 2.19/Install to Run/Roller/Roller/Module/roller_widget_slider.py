#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import WidgetKey as wk
from roller_widget import Widget
import gtk

# For GTK, let it know that the function handled an event:
DONE = 1


class RollerSlider(Widget):
    """
    Combine a HScale, arrow buttons, and a
    spin button to make a unified slider.
    """
    def __init__(self, **d):
        """
        Create a slider group of widgets.

        d: dict
            Has init values.
        """
        self.precision = 1

        for k in (wk.PRECISION, wk.LIMIT):
            if k in d:
                setattr(self, k, d[k])

        hbox = gtk.HBox()

        if self.precision == 0:
            self._page_increment = 1.

        elif self.precision == 1 and self.limit[1] > 10:
            self._page_increment = 1.

        else:
            self._page_increment = .01

        adjustment = self.alignment = gtk.Adjustment(
            0.,
            self.limit[0] / 1.,
            self.limit[1] / 1.,
            1.,
            self._page_increment,
            0.
        )

        # an horizontal scale
        g = gtk.HScale(adjustment=adjustment)

        d[wk.ALIGN] = 0, 0, 1, 0

        g.set_size_request(150, 1)
        Widget.__init__(self, g, **d)

        if self.precision == 0:
            climb_rate = 2
            step = (1, 2)
            g.set_digits(0)

        else:
            g.set_digits(self.precision)
            climb_rate = .1
            if self.precision == 1:
                step = (1., 2)
            else:
                step = (.01, .1)

        left_button = self.left_button = gtk.Button()
        right_button = self.right_button = gtk.Button()
        left_arrow = gtk.Arrow(gtk.ARROW_LEFT, gtk.SHADOW_NONE)
        right_arrow = gtk.Arrow(gtk.ARROW_RIGHT, gtk.SHADOW_NONE)
        spin_button = self.spin_button = gtk.SpinButton(
            adjustment=adjustment,
            digits=self.precision,
            climb_rate=climb_rate
        )

        spin_button.set_increments(*step)
        left_button.add(left_arrow)
        right_button.add(right_arrow)
        hbox.pack_start(left_button, expand=False)
        hbox.pack_start(g, expand=True)
        hbox.pack_start(right_button, expand=False)
        hbox.pack_start(spin_button, expand=False)
        self.add(hbox)
        g.set_value_pos(gtk.POS_LEFT)

        # Do connections last:
        left_button.connect('clicked', self.on_left_arrow_button)
        right_button.connect('clicked', self.on_right_arrow_button)
        g.connect('value-changed', self.on_value_changed)

        for i in (left_button, right_button):
            i.connect('key_press_event', self.on_key_press)

        spin_button.connect('key_press_event', self.on_key_press)
        self.alignment.emit('value-changed')

    def _on_key_press(self, g, event):
        """
        Process an arrow button key-press.

        g: gtk.Button
            active

        event: gtk.Event
            of key-press

        Return: None or true
            Is true if the key-press is processed.
        """
        n = gtk.gdk.keyval_name(event.keyval)
        if n in ('space', 'Return'):
            if g == self.left_button:
                self.on_left_arrow_button()

            else:
                self.on_right_arrow_button()
            return DONE

    def get_value(self):
        """
        Get the value of the Alignment.

        Is part of the Widget template.

        Return: numeric
            value of slider
        """
        a = self.alignment.get_value()

        if self.precision == 0:
            a = int(a)
        return a

    def set_value(self, value):
        """
        Set the Alignment value.

        Is part of the Widget template.

        value: numeric
            int or float
        """
        self.alignment.set_value(value)

    def on_left_arrow_button(self, *_):
        """Respond to the left arrow button click."""
        a = self.alignment.get_value()
        if a > self.limit[0]:
            a -= self._page_increment
            self.alignment.set_value(a)

    def on_right_arrow_button(self, *_):
        """Respond to the right arrow button click."""
        a = self.alignment.get_value()
        if a < self.limit[1]:
            a += self._page_increment
            self.alignment.set_value(a)

    def on_value_changed(self, *_):
        """
        The alignment value changed.

        Enable or disable the arrow buttons accordingly.
        """
        a = self.alignment.get_value()
        b = 1 if a > self.limit[0] else 0
        c = 1 if a < self.limit[1] else 0

        self.left_button.set_sensitive(b)
        self.right_button.set_sensitive(c)
        self.on_widget_change(self)
