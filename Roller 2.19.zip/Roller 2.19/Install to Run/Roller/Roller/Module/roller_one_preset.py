#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_image_effect import ImageEffect
from roller_one_base import Comm, OZ
from roller_one_constant import (
    BackdropStyleKey as bsk,
    BorderKey as bo,
    BrushKey as br,
    BumpKey as bk,
    CaptionKey as ck,
    CellKey as ce,
    ForBackdropStyle as fbs,
    ForBump as fb,
    ForCell as fc,
    ForFill,
    ForFormat as ff,
    ForFrame as fo,
    ForGradient as fg,
    ForPreset,
    ForWidget as fw,
    FormatKey as fk,
    FreeCellKey as fck,
    FringeKey as fr,
    ImageKey as ik,
    LayoutKey as nk,
    MarginKey as mk,
    MaskKey as ma,
    OptionKey as ok,
    PickleKey,
    PlaceKey as pl,
    PlaqueKey as pq,
    PresetKey as pk,
    PropertyKey as pr,
    SessionKey as sk,
    ShadowKey as sh,
    StripeKey as st,
    UIKey,
    WidgetKey as wk
)
from roller_port import Port
from roller_widget import Widget
from roller_widget_box import RollerBox
from roller_widget_button import RollerButton
from roller_widget_combo import RollerComboBoxEntry
from roller_window_save import RWSave
import glob
import gtk
import os

DEFAULT = u"Default"
ERROR = "Roller was unable to load per cell table."
ek = ImageEffect.Key
screen_width, screen_height = gtk.gdk.screen_width(), gtk.gdk.screen_height()

# dictionaries:
BUMP = OrderedDict([
    (ok.BUMP, fb.NONE),
    (bk.Cloth.BLUR_X, 48),
    (bk.Cloth.BLUR_Y, 6),
    (bk.Noise.NOISE, .12),
    (bk.Emboss.BUMP_DEPTH, 2)
])
BACKDROP_STYLE = {ok.BACKDROP_STYLE: bsk.BACKDROP_IMAGE}
BRUSH = OrderedDict([
    (br.SIZE, 100.),
    (br.SPACING, 100.),
    (br.ANGLE, 0.),
    (br.HARDNESS, 1.),
    (br.OPACITY, 100.),
    (br.BRUSH, "1. Pixel")
])
CELL = {
    ce.FIXED_HEIGHT: 500,
    ce.FIXED_POSITION_X: 0,
    ce.FIXED_POSITION_Y: 0,
    ce.FIXED_WIDTH: 500,
    ce.FRACTION_HEIGHT: 0.,
    ce.FRACTION_POSITION_X: 0.,
    ce.FRACTION_POSITION_Y: 0.,
    ce.FRACTION_WIDTH: 0.,
    ce.NAME: "Cell",
    ce.SHAPE: ff.Cell.Shape.RECTANGLE
}
CELL_BORDER = OrderedDict([
    (bo.BORDER_WIDTH, 0),
    (bo.OPACITY, 100.),
    (bo.BORDER_BLUR, 0),
    (bo.BUMP_DEPTH, 12),
    (bo.EMBOSS, 0),
    (bo.COMMON_BORDER, 1),
    (bo.COLOR, (127, 127, 127))
])
FREE_CELL_BORDER = OrderedDict([
    (bo.BORDER_WIDTH, 0),
    (bo.OPACITY, 100.),
    (bo.BORDER_BLUR, 0),
    (bo.BUMP_DEPTH, 12),
    (bo.EMBOSS, 0),
    (bo.COLOR, (127, 127, 127))
])
DROP_SHADOW = OrderedDict([
    (sh.SHADOW_BLUR, 20),
    (sh.INTENSITY, 100),
    (sh.OFFSET_X, 0),
    (sh.OFFSET_Y, 0),
    (sh.SHADOW_COLOR, (0, 0, 0)),
    (sh.MAKE_OPAQUE, 0)
])
INLAY_SHADOW = OrderedDict([
    (sh.INLAY_BLUR, 20),
    (sh.INTENSITY, 100),
    (sh.SHADOW_COLOR, (0, 0, 0))
])
FILL_LIGHT_SHADOW = OrderedDict([
    (ok.SHADOW_BLUR, 30),
    (ok.INTENSITY, 30),
    (ok.OFFSET_X, 0),
    (ok.OFFSET_Y, 0),
    (ok.SHADOW_COLOR, (0, 0, 0)),
    (ok.MAKE_OPAQUE, 0)
])
KEY_LIGHT_SHADOW = OrderedDict([
    (ok.SHADOW_BLUR, 20),
    (ok.INTENSITY, 100),
    (ok.OFFSET_X, 0),
    (ok.OFFSET_Y, 0),
    (ok.SHADOW_COLOR, (0, 0, 0)),
    (ok.MAKE_OPAQUE, 0)
])
SHADOW_PAIR = OrderedDict([
    (sh.KEY_LIGHT_SHADOW, KEY_LIGHT_SHADOW),
    (sh.FILL_LIGHT_SHADOW, FILL_LIGHT_SHADOW)
])
TRI_SHADOW = OrderedDict([
    (sh.KEY_LIGHT_SHADOW, KEY_LIGHT_SHADOW),
    (sh.FILL_LIGHT_SHADOW, FILL_LIGHT_SHADOW),
    (sh.INLAY_SHADOW, INLAY_SHADOW)
])
SHADOW_DICT = {
    sh.DROP_SHADOW: DROP_SHADOW,
    sh.INLAY_SHADOW: INLAY_SHADOW,
    sh.SHADOW_PAIR: SHADOW_PAIR,
    sh.TRI_SHADOW: TRI_SHADOW,
    sh.TYPE: ok.NONE
}
STRIPE = {
    st.BLUR_BEHIND: 0,
    st.COLOR: (127, 127, 127),
    st.HEIGHT: 1.5,
    st.OPACITY: 100.,
    st.TYPE: 0
}
CELL_CAPTION = {
    ck.CLIP_TO_CELL: 1,
    ck.COLOR: (0, 0, 0),
    ck.FONT: "Tahoma",
    ck.JUSTIFICATION: ff.Caption.TOP_LEFT,
    ck.LEADING_TEXT: "",
    ck.MARGIN: ff.Margin.MARGINS,
    ck.OPACITY: 100.,
    ck.SHADOW: SHADOW_DICT,
    ck.SIZE: 24,
    ck.START_NUMBER: 1,
    ck.STRIPE: STRIPE,
    ck.TEXT: "",
    ck.TRAILING_TEXT: "",
    ck.TYPE: ok.NONE
}
IMAGE_DICT_NONE = {
    ik.AS_LAYERS: 0,
    ik.AUTOCROP: 0,
    ik.FILTER: "",
    ik.FOLDER_ORDER: 0,
    ik.HAS_FORMAT: 0,
    ik.IMAGE_REF: ok.NONE,
    ik.LAYER_ORDER: 0,
    ik.TYPE: ff.Image.Type.NONE
}
CELL_FRINGE = {
    fr.BRUSH: BRUSH,
    fr.BUMP: BUMP,
    fr.CLIP_TO_CELL: 1,
    fr.COLOR: (0, 0, 0),
    fr.COLOR_1: (87, 87, 87),
    fr.COLOR_2: (174, 174, 174),
    fr.CONTRACT: 0,
    fr.GRADIENT: DEFAULT,
    fr.GRADIENT_ANGLE: fg.GRADIENT_ANGLE[0],
    fr.GRADIENT_TYPE: fg.GRADIENT_TYPE_LIST[0],
    fr.IMAGE: IMAGE_DICT_NONE,
    fr.PATTERN: "Pine",
    fr.SHADOW: SHADOW_DICT,
    fr.TYPE: ok.NONE
}
CELL_GRID = {
    fk.Cell.Grid.COLUMN: 1,
    fk.Cell.Grid.COLUMN_WIDTH: 500,
    fk.Cell.Grid.HORIZONTAL: 1,
    fk.Cell.Grid.PIN: ff.Grid.Pin.CENTER,
    fk.Cell.Grid.ROW: 1,
    fk.Cell.Grid.ROW_HEIGHT: 500,
    fk.Cell.Grid.SHAPE: ff.Cell.Shape.RECTANGLE,
    fk.Cell.Grid.SHIFT: 0,
    fk.Cell.Grid.TYPE: 0,
    fk.Cell.Grid.VERTICAL: 1
}
CELL_PLAQUE = {
    pq.BLUR_BEHIND: 0,
    pq.BUMP: BUMP,
    pq.COLOR: (255, 255, 255),
    pq.FEATHER: 0,
    pq.GRADIENT: DEFAULT,
    pq.GRADIENT_ANGLE: fg.GRADIENT_ANGLE[0],
    pq.GRADIENT_TYPE: fg.GRADIENT_TYPE_LIST[0],
    pq.IMAGE: IMAGE_DICT_NONE,
    pq.LINE_WIDTH: 2,
    pq.OPACITY: 100.,
    fr.PATTERN: "Pine",
    pq.SPACING: 6,
    pq.STEPS: 1,
    pq.TYPE: ok.NONE
}
IMAGE_DICT_FIRST = {
    ik.AS_LAYERS: 0,
    ik.AUTOCROP: 1,
    ik.FILTER: "",
    ik.FOLDER_ORDER: 0,
    ik.HAS_FORMAT: 0,
    ik.IMAGE_REF: ff.Image.FIRST_IMAGE,
    ik.LAYER_ORDER: 0,
    ik.TYPE: ff.Image.Type.NUMERIC_SEQUENCE
}
IMAGE_DICT_NEXT = {
    ik.AS_LAYERS: 0,
    ik.AUTOCROP: 1,
    ik.FILTER: "",
    ik.FOLDER_ORDER: 0,
    ik.HAS_FORMAT: 1,
    ik.IMAGE_REF: ff.Image.NEXT_LINEAR,
    ik.LAYER_ORDER: 0,
    ik.TYPE: ff.Image.Type.NEXT
}
BACKDROP_IMAGE = OrderedDict([
    (ok.RENDER_WIDTH, screen_width),
    (ok.RENDER_HEIGHT, screen_height),
    (ok.BACKDROP_IMAGE_BLUR, 0),
    (ok.LIGHT_ANGLE, 45.),
    (ok.ELEVATION, 30.),
    (ok.FIT_IMAGE, 1),
    (ok.INVERT, 0),
    (ok.BACKDROP_IMAGE, IMAGE_DICT_FIRST),
    (ok.BUMP, BUMP)
])
FRAME_GRADIENT = OrderedDict([
    (ok.GRADIENT_TYPE, "Bilinear"),
    (ok.OPACITY, 100.),
    (ok.ROTATE, 0.),
    (ok.OFFSET, 0),
    (ok.START_X, 0.),
    (ok.START_Y, 0.),
    (ok.END_X, 1.),
    (ok.END_Y, 1.),
    (ok.INVERT, 0),
    (ok.REVERSE, 0),
    (ok.GRADIENT, DEFAULT)
])
FREE_CELL_IMAGE_PLACE = {
    pl.HORIZONTAL: ff.Place.CENTER,
    pl.IMAGE_DICT: IMAGE_DICT_NONE,
    pl.RESIZE: ff.Place.LOCKED,
    pl.VERTICAL: ff.Place.MIDDLE,
}
IMAGE_MASK = {
    ma.CHAR: "A",
    ma.FEATHER: 0,
    ma.STEPS: 1,
    ma.FONT: "Tahoma",
    ma.HORZ_SCALE: 1.,
    ma.IMAGE: IMAGE_DICT_NONE,
    ma.TYPE: ok.NONE,
    ma.VERT_SCALE: 1.
}
IMAGE_PLACE = {
    pl.HORIZONTAL: ff.Place.CENTER,
    pl.IMAGE_DICT: IMAGE_DICT_NEXT,
    pl.RESIZE: ff.Place.LOCKED,
    pl.VERTICAL: ff.Place.MIDDLE,
}
IMAGE_PROPERTY = {
    pr.BLUR_BEHIND: 0,
    pr.FLIP_HORIZONTAL: 0,
    pr.FLIP_VERTICAL: 0,
    pr.OPACITY: 100.,
    pr.ROTATE: 0.
}
LAYER_BORDER = OrderedDict([
    (bo.BORDER_WIDTH, 0),
    (bo.OPACITY, 100.),
    (bo.BORDER_BLUR, 0),
    (bo.BUMP_DEPTH, 12),
    (bo.EMBOSS, 0),
    (bo.OBEY_MARGINS, 1),
    (bo.COLOR, (127, 127, 127))
])
LAYER_CAPTION = {
    ck.CLIP_TO_CELL: 1,
    ck.COLOR: (0, 0, 0),
    ck.FONT: "Tahoma",
    ck.JUSTIFICATION: ff.Caption.TOP_LEFT,
    ck.MARGIN: ff.Margin.MARGINS,
    ck.OBEY_MARGINS: 1,
    ck.OPACITY: 100.,
    ck.SHADOW: SHADOW_DICT,
    ck.SIZE: 36,
    ck.STRIPE: STRIPE,
    ck.TEXT: "",
    ck.TYPE: ok.NONE,
}
LAYER_FRINGE = {
    fr.BRUSH: BRUSH,
    fr.BUMP: BUMP,
    fr.CLIP_TO_CELL: 1,
    fr.COLOR: (0, 0, 0),
    fr.COLOR_1: (87, 87, 87),
    fr.COLOR_2: (174, 174, 174),
    fr.CONTRACT: 0,
    fr.GRADIENT: DEFAULT,
    fr.GRADIENT_ANGLE: fg.GRADIENT_ANGLE[0],
    fr.GRADIENT_TYPE: fg.GRADIENT_TYPE_LIST[0],
    fr.IMAGE: IMAGE_DICT_NONE,
    fr.OBEY_MARGINS: 1,
    fr.PATTERN: "Pine",
    fr.SHADOW: SHADOW_DICT,
    fr.TYPE: ok.NONE
}
LAYER_PLAQUE = {
    pq.BLUR_BEHIND: 0,
    pq.BUMP: BUMP,
    pq.COLOR: (0, 0, 0),
    pq.FEATHER: 0,
    pq.GRADIENT: DEFAULT,
    pq.GRADIENT_ANGLE: fg.GRADIENT_ANGLE[0],
    pq.GRADIENT_TYPE: fg.GRADIENT_TYPE_LIST[0],
    pq.IMAGE: IMAGE_DICT_NONE,
    pq.LINE_WIDTH: 2,
    pq.OBEY_MARGINS: 1,
    pq.OPACITY: 100.,
    fr.PATTERN: "Pine",
    pq.SPACING: 6,
    pq.STEPS: 1,
    pq.TYPE: ok.NONE
}
WITH_BUMP = OrderedDict([
    (ok.BUMP, fb.NOISE),
    (bk.Cloth.BLUR_X, 48),
    (bk.Cloth.BLUR_Y, 6),
    (bk.Emboss.BUMP_DEPTH, 2),
    (bk.Noise.NOISE, .055)
])


class Preset(Widget):
    """Use to manage presets."""

    # Read only:
    _default = {
        bo.CELL_BORDER: CELL_BORDER,
        bo.FREE_CELL_BORDER: FREE_CELL_BORDER,
        bo.LAYER_BORDER: LAYER_BORDER,
        bsk.AVERAGE_COLOR: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.INVERT, 0),
            (ok.BUMP, BUMP)
        ]),
        bsk.BACKDROP_IMAGE: BACKDROP_IMAGE,
        bsk.BACKDROP_STYLE: BACKDROP_STYLE,
        bsk.CARBON_14:  OrderedDict([
            (ok.MESH_TYPE, "Hexagon"),
            (ok.MESH_SIZE, 50),
            (ok.NEATNESS, 1.),
            (ok.RANDOM_SEED, 0),
            (ok.BUMP, WITH_BUMP)
        ]),
        bsk.COLOR_FILL: OrderedDict([
            (ok.CRITERION, ForFill.CRITERION_LIST[0]),
            (ok.MODE, "Normal"),
            (ok.THRESHOLD, 1.),
            (ok.OPACITY, 100.),
            (ok.START_X, 0.),
            (ok.START_Y, 0.),
            (ok.INVERT, 0),
            (ok.COLOR, (127, 127, 127)),
            (ok.BUMP, WITH_BUMP)
        ]),
        bsk.COLORED_GRID: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.ROW, 4),
            (ok.COLUMN, 4),
            (ok.OPACITY, 100.),
            (ok.ROTATE, 0.),
            (ok.INVERT, 0),
            (ok.COLOR_1, (64, 64, 64)),
            (ok.COLOR_2, (181, 181, 181)),
            (ok.BUMP, WITH_BUMP)
        ]),
        bsk.CORE_DESIGN: OrderedDict([
            (ok.ROW, 12),
            (ok.COLUMN, 12),
            (ok.OFFSET, 0),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.GRADIENT, "Default"),
            (ok.COLOR, (0, 0, 0))
        ]),
        bsk.CRYSTAL_CAVE: {ok.RANDOM_SEED: 0},
        bsk.CUBISM_COVER: OrderedDict([
            (ok.BACKDROP_TYPE, fbs.BACKDROP_IMAGE),
            (ok.GRADIENT_TYPE, fg.SPIRAL_CLOCKWISE),
            (ok.BACKDROP_BLUR, 250),
            (ok.TILE_SIZE, 20.),
            (ok.SATURATION, 1.),
            (ok.RANDOM_SEED, 0),
            (ok.GRADIENT, "Default")
        ]),
        bsk.DARK_FORT: OrderedDict([
            (ok.ROW, 8),
            (ok.COLUMN, 12),
            (ok.RANDOM_SEED, 0)
        ]),
        bsk.DENSITY_GRADIENT: OrderedDict([
            (ok.GRADIENT_ANGLE, fg.TOP_CENTER_TO_BOTTOM_CENTER),
            (ok.GRADIENT_MODE, "Luma Lighten Only"),
            (ok.RANDOM_SEED, 0),
            (ok.GRADIENT, "Desert Sunset")
        ]),
        bsk.ETCH_SKETCH: OrderedDict([
            (ok.SKETCH_TEXTURE, fbs.NEWS_TYPE),
            (ok.CELL_SIZE, 9),
            (ok.OPACITY, 100.),
            (ok.EMBOSS, 0),
            (ok.INVERT, 0)
        ]),
        bsk.FLOOR_SAMPLE: OrderedDict([
            (ok.NUMBER_OF_SLICES, 6),
            (ok.STARTING_ANGLE, 0),
            (ok.INTENSITY, 200),
            (ok.SHADOW_BLUR, 10),
            (ok.INVERT, 0),
            (ok.COLOR_1, (255, 255, 255)),
            (ok.COLOR_2, (64, 64, 64)),
            (ok.SHADOW_COLOR, (0, 0, 0)),
            (ok.BUMP, BUMP)
        ]),
        bsk.GRID_WORK:  OrderedDict([(ok.ROW, 8), (ok.COLUMN, 12)]),
        bsk.GLASS_GAW: OrderedDict([
            (ok.RANDOM_SEED, 0),
            (ok.BUMP, BUMP)
        ]),
        bsk.GRADIENT_FILL: OrderedDict([
            (ok.GRADIENT_TYPE, "Linear"),
            (ok.MODE, "Normal"),
            (ok.ROTATE, 0.),
            (ok.OPACITY, 100.),
            (ok.OFFSET, 0),
            (ok.START_X, 0.),
            (ok.START_Y, 0.),
            (ok.END_X, 1.),
            (ok.END_Y, 1.),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.GRADIENT, "Default"),
            (ok.BUMP, BUMP)
        ]),
        bsk.IMAGE_GRADIENT: OrderedDict([
            (ok.NAME, "Sampled Gradient"),
            (ok.GRADIENT_TYPE, "Linear"),
            (ok.MODE, "Normal"),
            (ok.SAMPLE_VECTOR, fbs.VERTICAL),
            (ok.SAMPLE_RADIUS, 15),
            (ok.SAMPLE_POINTS, 5),
            (ok.ROTATE, 0.),
            (ok.OPACITY, 100.),
            (ok.START_X, .5),
            (ok.START_Y, .5),
            (ok.DIAGONAL_ROTATION, 45.),
            (ok.KEEP_GRADIENT, 0),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.BUMP, BUMP),
            (ok.PREVIEW_MODE, fbs.SHOW_GRADIENT)
        ]),
        bsk.LIGHT_SHAFT: OrderedDict([(ok.ROTATE, 0.), (ok.SCALE, 7)]),
        bsk.LINE_STONE: {ok.RANDOM_SEED: 0},
        bsk.LOST_MAZE: OrderedDict([
            (ok.GRADIENT_ANGLE, fg.GRADIENT_ANGLE[0]),
            (ok.ROW_MAZE, 10),
            (ok.COLUMN_MAZE, 10),
            (ok.OFFSET, 0),
            (ok.RANDOM_SEED, 0),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.GRADIENT, "Default")
        ]),
        bsk.MAZE_BLEND: OrderedDict([
            (ok.ROW_MAZE, 4),
            (ok.COLUMN_MAZE, 100),
            (ok.RANDOM_SEED, 0)
        ]),
        bsk.MYSTERY_GRATE: OrderedDict([
            (ok.COLUMN_1, 8),
            (ok.COLUMN_2, 80),
            (ok.OFFSET, 0),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.GRADIENT, "Default")
        ]),
        bsk.NOISE_RIFT: OrderedDict([
            (ok.DETAIL_LEVEL, 1),
            (ok.SOFTNESS, 500),
            (ok.RANDOM_SEED, 0),
            (ok.USE_PLASMA, 1),
            (ok.INVERT_NOISE, 0),
            (ok.BUMP, BUMP)
        ]),
        bsk.PATTERN_FILL: OrderedDict([
            (ok.CRITERION, ForFill.CRITERION_LIST[0]),
            (ok.MODE, "Normal"),
            (ok.THRESHOLD, 1.),
            (ok.OPACITY, 100.),
            (ok.START_X, 0.),
            (ok.START_Y, 0.),
            (ok.INVERT, 0),
            (ok.PATTERN, "Paper"),
            (ok.BUMP, WITH_BUMP)
        ]),
        bsk.RAINBOW_VALLEY: OrderedDict([
            (ok.POWER, 30),
            (ok.RANDOM_SEED, 0),
            (ok.TEXTURE, 0),
            (ok.EMBOSS, 0)
        ]),
        bsk.ROCKY_LANDING:  OrderedDict([
            (ok.BLEND, 12),
            (ok.RANDOM_SEED, 0)
        ]),
        bsk.SPACETIME_FABRIC: OrderedDict([
            (ok.COMPONENT, "Green"),
            (ok.ROW, 10),
            (ok.COLUMN, 10),
            (ok.EMBOSS, 0)
        ]),
        bsk.SPECIMEN_SPECKLE: OrderedDict([
            (ok.GRADIENT_TYPE, "Linear"),
            (ok.MODE, "Normal"),
            (ok.ROTATE, 0.),
            (ok.OPACITY, 100.),
            (ok.OFFSET, 0),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.PATTERN_1, "Crack"),
            (ok.PATTERN_2, "Leopard"),
            (ok.PATTERN_3, "Paper"),
            (ok.COLOR, (176, 82, 0)),
            (ok.GRADIENT, "Default")
        ]),
        bsk.SPIRAL_CHANNEL: OrderedDict([
            (ok.SPIRAL_MOD, fbs.HORIZONTAL_FLIP),
            (ok.SPIRAL_DISTANCE, .1),
            (ok.ROW, 1),
            (ok.COLUMN, 1),
            (ok.COLOR, (75, 75, 75)),
            (ok.BUMP, WITH_BUMP),
            (ok.GRADIENT_DIRECTION, fbs.CLOCKWISE)
        ]),
        bsk.SQUARE_CLOUD: OrderedDict([
            (ok.RANDOM_SEED, 0),
            (ok.COLOR, (127, 255, 127))
        ]),
        bsk.TRAILING_VINE: OrderedDict([
            (ok.LAYER_COUNT, 7),
            (ok.WAVE_PER_LAYER, 5),
            (ok.RANDOM_SEED, 0),
            (ok.USE_PLASMA, 1)
        ]),
        ok.BUMP: BUMP,
        ck.CELL_CAPTION: CELL_CAPTION,
        ck.FREE_CELL_CAPTION: CELL_CAPTION,
        ck.LAYER_CAPTION: LAYER_CAPTION,
        ek.BALL_JOINT: OrderedDict([(ok.BRUSH_SIZE, 30)]),
        ek.BORDER_LINE: OrderedDict([
            (ok.FRAME_WIDTH, 10),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.BRUSH_EDGE: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.EXPAND, 0),
            (ok.OPACITY, 25.),
            (ok.ANGLE_FLUX, 30.),
            (ok.OPACITY_FLUX, 3.),
            (ok.RANDOM_SEED, 0),
            (ok.BRUSH_DICT, BRUSH),
            (ok.COLOR, (127, 127, 127))
        ]),
        ek.BRUSH_PUNCH: OrderedDict([
            (ok.BRUSH_SIZE, 100),
            (ok.BRUSH_SPACING, 100.),
            (ok.FRAME_WIDTH, 6),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.BRUSH, "1. Pixel"),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.CERAMIC_CHIP: OrderedDict([
            (ok.MESH_TYPE, "Triangle"),
            (ok.WIDTH, 45),
            (ok.FRAME_WIDTH, 4),
            (ok.MESH_SIZE, 33),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.COLOR, (0, 255, 0)),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.CIRCLE_PUNCH: OrderedDict([
            (ok.CIRCLE_DIAMETER, 50),
            (ok.WIDTH, 45),
            (ok.ROTATE, 45.),
            (ok.FRAME_WIDTH, 4),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.CLEAR_FRAME: OrderedDict([
            (ok.FRAME_WIDTH, 45),
            (ok.COLOR, (255, 255, 255)),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.COLOR_PIPE: OrderedDict([
            (ok.PROFILE, fo.ROUND),
            (ok.NOISE_MODE, ok.NONE),
            (ok.FRAME_WIDTH, 40),
            (ok.NOISE_OPACITY, 100.),
            (ok.RANDOM_SEED, 0),
            (ok.BLUR_BEHIND, 0),
            (ok.COLOR, (0, 127, 0))
        ]),
        ek.COLORED_BOARD: OrderedDict([
            (ok.FRAME_WIDTH, 1),
            (ok.COLOR, (255, 255, 255)),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.CORNER_TAPE: OrderedDict([
            (ok.TAPE_LENGTH, 150),
            (ok.TAPE_WIDTH, 50),
            (ok.OPACITY, 10.),
            (ok.SHADOW_BLUR, 6),
            (ok.INTENSITY, 70),
            (ok.ANGLE_SHIFT, 5),
            (ok.CORNER_SHIFT, 9),
            (ok.RANDOM_SEED, 0),
            (ok.COLOR, (230, 220, 210))
        ]),
        ek.CUTOUT_PLATE: OrderedDict([
            (ok.FRAME_WIDTH, 100),
            (ok.BEVEL_EDGE_WIDTH, 8),
            (ok.NOISE_OPACITY, 25.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.PATTERN, "Paper"),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.DROP_SHADOW: DROP_SHADOW,
        ek.FEATHER_REDUCTION: OrderedDict([
            (ok.FEATHER, 200),
            (ok.STEPS, 6)
        ]),
        ek.FILL_LIGHT_SHADOW: FILL_LIGHT_SHADOW,
        ek.FRAME_GRADIENT: FRAME_GRADIENT,
        ek.GLASS_REVEAL: OrderedDict([
            (ok.PROFILE, fo.ROUND),
            (ok.CURVE, ok.NONE),
            (ok.FRAME_WIDTH, 50),
            (ok.DEPTH, 20),
            (ok.EMBOSS, 0)
        ]),
        ek.GRADIENT_LEVEL: OrderedDict([
            (ok.NOISE_MODE, ok.NONE),
            (ok.FRAME_WIDTH, 60),
            (ok.NOISE_OPACITY, 35.),
            (ok.RANDOM_SEED, 1430641197),
            (ok.COLOR_1, (177, 86, 29)),
            (ok.COLOR_2, (118, 73, 42))
        ]),
        ek.IMAGE_EDGE_SHADOW: OrderedDict([
            (ok.INLAY_BLUR, 20),
            (ok.INTENSITY, 100),
            (ok.SHADOW_COLOR, (0, 0, 0))
        ]),
        ek.IMAGE_EFFECT: {ok.IMAGE_EFFECT: ek.NO_EFFECT},
        ek.IMAGE_SHADOW: OrderedDict([
            (ok.SHADOW_BLUR, 20),
            (ok.INTENSITY, 100),
            (ok.OFFSET_X, 0),
            (ok.OFFSET_Y, 0),
            (ok.SHADOW_COLOR, (0, 0, 0)),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.INLAY_SHADOW: INLAY_SHADOW,
        ek.JAGGED_EDGE: OrderedDict([
            (ok.SHADOW, ek.INLAY_SHADOW),
            (ok.AMPLITUDE, 3),
            (ok.SMOOTHNESS, 4),
            (ok.SHADOW_BLUR, 20),
            (ok.INTENSITY, 200),
            (ok.RANDOM_SEED, 0),
            (ok.SHADOW_COLOR, (0, 0, 0)),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.KEY_LIGHT_SHADOW: KEY_LIGHT_SHADOW,
        ek.LINE_FASHION: OrderedDict([
            (ok.WIDTH, 45),
            (ok.LINE_WIDTH, 12),
            (ok.GAP_WIDTH, 48),
            (ok.FRAME_WIDTH, 4),
            (ok.ROTATE, 45.),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.MAZE_MIRROR: OrderedDict([
            (ok.MAZE_TYPE, fbs.SCATTERED_CONNECTORS),
            (ok.GAP_TYPE, fbs.RANDOM),
            (ok.ROW, 10),
            (ok.COLUMN, 10),
            (ok.CELL_GAP, 3),
            (ok.STOP_LENGTH, 25),
            (ok.SCATTER_COUNT, 4),
            (ok.FRAME_WIDTH, 12),
            (ok.COMPOSITION_FRAME_WIDTH, 12),
            (ok.LINE_WIDTH, 12),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.MAZE_DIRECTION, fbs.CLOCKWISE),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.NO_EFFECT: {},
        ek.PAINT_RUSH: OrderedDict([
            (ok.EDGE_TYPE, fbs.PaintRush.WHITE_SOFT),
            (ok.EDGE_MODE, "Lighten Only"),
            (ok.FRAME_WIDTH, 100),
            (ok.POST_BLUR, 0),
            (ok.COLORIZE_OPACITY, 100.),
            (ok.COLOR, (175, 90, 10)),
            (ok.EMBOSS, 0),
            (ok.COLORIZE, 0)
        ]),
        ek.RAD_WAVE: OrderedDict([
            (ok.FRAME_WIDTH, 10),
            (ok.LINE_WIDTH, 8),
            (ok.COMPOSITION_FRAME_WIDTH, 8),
            (ok.ROW, 2),
            (ok.COLUMN, 2),
            (ok.WAVE_AMPLITUDE, 10),
            (ok.WAVELENGTH, 25.),
            (ok.WHIRL, 0),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.RAISED_MAZE: OrderedDict([
            (ok.FRAME_WIDTH, 8),
            (ok.LINE_WIDTH, 8),
            (ok.COMPOSITION_FRAME_WIDTH, 8),
            (ok.ROW_MAZE, 10),
            (ok.COLUMN_MAZE, 10),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.ROUNDED_EDGE: OrderedDict([
            (ok.ROUNDED_EDGE_BLUR, 15),
            (ok.INTENSITY, 100.),
            (ok.ROUND_UP, 0),
        ]),
        ek.SQUARE_PUNCH: OrderedDict([
            (ok.WIDTH, 50),
            (ok.LINE_WIDTH, 25),
            (ok.GAP_WIDTH, 50),
            (ok.FRAME_WIDTH, 4),
            (ok.ROTATE, 45.),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.STAINED_GLASS: OrderedDict([
            (ok.WIDTH, 45),
            (ok.PANE_WIDTH, 100),
            (ok.PANE_HEIGHT, 100),
            (ok.ROTATE, 45.),
            (ok.FRAME_WIDTH, 5),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.WIRE_FENCE: OrderedDict([
            (ok.MESH_TYPE, "Hexagon"),
            (ok.MESH_SIZE, 30),
            (ok.WIDTH, 35),
            (ok.WIRE_THICKNESS, 3),
            (ok.NEATNESS, 1.),
            (ok.FRAME_WIDTH, 4),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        fck.CELL: CELL,
        fck.FREE_RANGE_CELL: {
            bo.FREE_CELL_BORDER: FREE_CELL_BORDER,
            ck.FREE_CELL_CAPTION: CELL_CAPTION,
            fck.CELL: CELL,
            fck.Cell.MARGIN: ff.Margin.MARGINS,
            fr.CELL_FRINGE: CELL_FRINGE,
            pq.CELL_PLAQUE: CELL_PLAQUE,
            ma.IMAGE_MASK: IMAGE_MASK,
            pk.PRESET: DEFAULT,
            pl.IMAGE_PLACE: FREE_CELL_IMAGE_PLACE,
            pr.IMAGE_PROPERTY: IMAGE_PROPERTY
        },
        fk.Cell.Grid.CELL_GRID: CELL_GRID,
        fk.FORMAT: {
            bo.CELL_BORDER: CELL_BORDER,
            bo.LAYER_BORDER: LAYER_BORDER,
            ck.CELL_CAPTION: CELL_CAPTION,
            ck.LAYER_CAPTION: LAYER_CAPTION,
            fk.Cell.Border.PER_CELL: [],
            fk.Cell.Caption.PER_CELL: [],
            fk.Cell.Fringe.PER_CELL: [],
            fk.Cell.Grid.CELL_GRID: CELL_GRID,
            fk.Cell.Grid.PER_CELL: [],
            fk.Cell.Image.Mask.PER_CELL: [],
            fk.Cell.MARGIN: ff.Margin.MARGINS,
            fk.Cell.Margin.PER_CELL: [],
            fk.Cell.Image.Place.PER_CELL: [],
            fk.Cell.Image.Property.PER_CELL: [],
            fk.Cell.Plaque.PER_CELL: [],
            fk.Layer.CELL_LIST: [],
            fk.Layer.NAME: "Format",
            fk.Layer.PLACE_FREE_CELL_ABOVE: 1,
            fk.Layer.MARGIN: ff.Margin.MARGINS,
            fk.LAYOUT_OPTION: OrderedDict([
                (nk.BORDER, 0),
                (nk.CELL_CAPTION, 0),
                (nk.CELL_FRINGE, 0),
                (nk.CELL_MARGINS, 0),
                (nk.CELL_PLAQUE, 0),
                (nk.COORDINATES, 0),
                (nk.CORNERS, 0),
                (nk.DIMENSIONS, 0),
                (nk.GRID, 0),
                (nk.IMAGE, 1),
                (nk.IMAGE_MASK, 0),
                (nk.LAYER_FRINGE, 0),
                (nk.LAYER_PLAQUE, 0),
                (nk.LAYER_MARGINS, 0),
                (nk.NAME, 0),
                (nk.RATIOS, 0),
            ]),
            fr.CELL_FRINGE: CELL_FRINGE,
            fr.LAYER_FRINGE: LAYER_FRINGE,
            ma.IMAGE_MASK: IMAGE_MASK,
            pk.PRESET: DEFAULT,
            pl.IMAGE_PLACE: IMAGE_PLACE,
            pq.CELL_PLAQUE: CELL_PLAQUE,
            pq.LAYER_PLAQUE: LAYER_PLAQUE,
            pr.IMAGE_PROPERTY: IMAGE_PROPERTY,
        },
        fr.BRUSH: BRUSH,
        fr.CELL_FRINGE: CELL_FRINGE,
        fr.LAYER_FRINGE: LAYER_FRINGE,
        ma.IMAGE_MASK: IMAGE_MASK,
        mk.MARGINS: OrderedDict([
            (mk.FIXED_TOP, 0),
            (mk.FIXED_BOTTOM, 0),
            (mk.FIXED_LEFT, 0),
            (mk.FIXED_RIGHT, 0),
            (mk.FRACTION_TOP, 0.),
            (mk.FRACTION_BOTTOM, 0.),
            (mk.FRACTION_LEFT, 0.),
            (mk.FRACTION_RIGHT, 0.)
        ]),
        pl.IMAGE_PLACE: IMAGE_PLACE,
        pq.CELL_PLAQUE: CELL_PLAQUE,
        pq.LAYER_PLAQUE: LAYER_PLAQUE,
        pr.IMAGE_PROPERTY: IMAGE_PROPERTY,
        sh.SHADOW_DICT: SHADOW_DICT,
        sh.SHADOW_PAIR: SHADOW_PAIR,
        sk.SESSION: {
            sk.CLOSE_FILE: 0,
            sk.FORMAT_LIST: [],
            pk.PRESET: DEFAULT,
            sk.SESSION_OPT: {
                sk.FORMAT_NAME_LIST: [],
                ek.FRAME_GRADIENT: FRAME_GRADIENT,
                sk.BACKDROP: {
                    bsk.BACKDROP_IMAGE: BACKDROP_IMAGE,
                    bsk.BACKDROP_STYLE: BACKDROP_STYLE
                },
            }
        },
        sh.TRI_SHADOW: TRI_SHADOW,
        ck.STRIPE: STRIPE
    }

    def __init__(self, **d):
        """
        Create a format group preset.

        Use the Widget template 'get_value' and 'set_value'
        functions to manage widget option groups.

        d: dict
            Has keyword arguments.
        """
        w = fw.MARGIN
        w1 = w // 2
        self.widget_list = d[wk.WIDGET_LIST] if wk.WIDGET_LIST in d else []
        self.verify = None

        # Backdrop-style and image-effect have a tuple for a key:
        k = d[wk.KEY] if isinstance(d[wk.KEY], str) else d[wk.KEY][1]
        self._default_dict = deepcopy(Preset._default[k])

        # Has preset path.
        # The key is a preset name. The value is a path:
        self._external_preset = {}

        vbox = self._vbox = RollerBox(gtk.VBox, align=(0, 0, 1, 0))
        hbox = RollerBox(gtk.HBox, align=(0, 0, 1, 0))
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        k = wk.ON_WIDGET_CHANGE
        self._update_window = d[k] if k in d else None
        d[wk.ON_WIDGET_CHANGE] = self._on_preset_change
        g = self.menu = RollerComboBoxEntry(**d)

        Widget.__init__(self, g, **d)

        g1 = self._save_button = RollerButton(
            on_widget_change=self.save,
            padding=(w1, 0, 0, w1),
            text="Save Preset"
        )
        g2 = self._delete_button = RollerButton(
            on_widget_change=self._delete,
            padding=(w1, 0, w1, 0),
            text="Delete Preset"
        )

        self.add(vbox)
        vbox.add(g)
        vbox.pack_start(hbox, expand=1)

        for i in (g1, g2):
            hbox.add(i)
            same_size.add_widget(i.widget)
        if 'container' in d:
            d['container'].add(self)

            if 'padding' in d:
                hbox.set_padding(*d['padding'])
                vbox.set_padding(*d['padding'])
            else:
                hbox.set_padding(w1, w, 0, 0)
                vbox.set_padding(w1, 0, w, w)

    def _collect_presets(self):
        """
        Create a list, 'self._option_list', of internal and external presets.

        Return: list
            of options
            to populate combobox
        """
        # menu options:
        q = self._option_list = []
        ext_files = []
        go = False
        self._external_preset = {}

        try:
            search_path = OZ.get_preset_path(
                self.key,
                u"*",
                self.stat.preset_folder
            )

            # Ignore sub-directories:
            ext_files = glob.glob(search_path)
            go = True

        except Exception as ex:
            Comm.show_err(ex)
            Comm.show_err("Roller was unable to load presets.")

        if go:
            # Load internal presets into a list:
            q.append(DEFAULT)
            # Make an external preset file list:
            for n in ext_files:
                file_name = os.path.basename(n)
                split_name = file_name.split(ForPreset.PRESET_SEPARATOR)
                combined_name = u""

                for n1 in range(1, len(split_name)):
                    combined_name = combined_name + split_name[n1]

                types = combined_name.split(u".")
                name = types[0]
                self._external_preset[name] = n
                q.append(name)
        return q

    def _delete(self, *_):
        """Delete a preset file."""
        n = self.menu.get_text()
        is_external = False

        if n in self._external_preset:
            is_external = True
        if is_external:
            path = self._external_preset[n]
            if Comm.pop_up(
                self.win.win,
                0,
                "Do you want to delete:\n{}?".format(path),
                "Delete a File Confirmation"
            ):
                try:
                    os.remove(path)
                    Comm.pop_up(
                        self.win.win,
                        1,
                        "The file:\n" + path + "\nwas removed.",
                        "File Deleted"
                    )

                    if n in self._external_preset:
                        self._external_preset.pop(n)
                    self.refresh(fw.UNDEFINED)

                except Exception as ex:
                    Comm.show_err(ex)
                    Comm.show_err("Roller was unable to delete the file.")

    def _get_preset(self, n):
        """
        Find a preset dictionary from internal or external sources.

        n: string
            name of preset

        Return: dict
            of preset
        """
        if n in self._external_preset:
            d = OZ.pickle_load(
                {
                    PickleKey.FILE: self._external_preset[n],
                    PickleKey.SHOW_ERROR: True
                }
            )

            # The preset name must match the file name:
            d[pk.PRESET] = n

            if self.key == sk.SESSION:
                self._proof_session(d)
            else:
                Preset._pass_version(d, self._default_dict)

        else:
            d = deepcopy(self._default_dict)
            n = DEFAULT
        return d, n

    def _load_preset(self, n, d):
        """
        Load a preset dictionary.

        n: string
            name of preset

        d: dict
            of preset
        """
        Port.load_count += 1

        if n != fw.UNDEFINED:
            d, n = self._get_preset(n)

        self.set_value(d)
        self.menu.set_text(n)
        self.verify_del_button()
        Port.load_count -= 1

    def _on_preset_change(self, g):
        """
        Call after loading a preset.

        g: ComboBox
            Has changed.
            not used
        """
        if not Port.load_count:
            n = self.get_text()

            if n != fw.UNDEFINED:
                self._load_preset(n, self._default_dict)
            if self._update_window:
                self._update_window(self)

    @staticmethod
    def _pass_version(d, e, is_format=False, is_expand=True):
        """
        Add missing dictionary items.

        Remove invalid dictionary items.

        Verify cell data length.

        Is recursive.

        d: dict
            Check content.

        e: dict
            Has default values.

        is_format: flag
            If it's true, the dict is a format type.

        is_expand: flag
            If it's true, the dict in question will receive any
            missing 'key, value' pairs from the default dict.
        """
        # Add new:
        if is_expand:
            Preset.expand(d, e)
        if is_format:
            # Check the cell value lengths:
            for k in fc.CELL_TABLE_DICT:
                invalid = 0

                key = fc.CELL_TABLE_DICT[k]['key']

                if key in Preset._default:
                    default = Preset.get_default(key)

                else:
                    default = None

                if d[k]:
                    for r in range(len(d[k])):
                        for c in range(len(d[k][r])):
                            a = d[k][r][c]
                            if isinstance(a, list):
                                continue
                            if default:
                                is_err = False

                                for i in [i for i in a]:
                                    if i not in default:
                                        is_err = True
                                        break

                                # 'a' is invalid:
                                if is_err:
                                    d[k][r][c] = default
                                    Comm.show_err(ERROR)
                                else:
                                    Preset.expand(a, default)
                        if invalid:
                            break
                if invalid:
                    d[k] = []

    @staticmethod
    def expand(d, e):
        """
        Expand dict from another dict.

        Is recursive.

        d: dict
            expanding dict

        e: dict
            source dict
        """
        # Remove old:
        for k in [i for i in d]:
            if k not in e:
                d.pop(k)
        for i in [i for i in e]:
            if i not in d:
                d[i] = deepcopy(e[i])
            if d[i] and isinstance(d[i], dict):
                if e[i] and isinstance(e[i], dict):
                    Preset.expand(d[i], e[i])
                else:
                    # Change type:
                    d[i] = deepcopy(e[i])

    def _proof_session(self, d):
        """
        Check the contents of the session dict for compatibility.

        d: dict
            of session
        """
        if sk.FORMAT_LIST in d:
            for e in d[sk.FORMAT_LIST]:
                Preset._pass_version(
                    e,
                    Preset._default[fk.FORMAT],
                    is_format=True
                )
                for cell in e[fk.Layer.CELL_LIST]:
                    Preset._pass_version(
                        cell,
                        Preset._default[fck.FREE_RANGE_CELL]
                    )

        else:
            d[sk.FORMAT_LIST] = Preset._default[sk.SESSION][sk.FORMAT_LIST]

        d1 = self._default_dict
        d2 = None

        if sk.SESSION_OPT in d:
            d2 = deepcopy(d[sk.SESSION_OPT])
            d.pop(sk.SESSION_OPT)

        Preset._pass_version(d, d1)

        if d2:
            d[sk.SESSION_OPT] = d2

        for k in d1[sk.SESSION_OPT]:
            if k not in d[sk.SESSION_OPT]:
                d[sk.SESSION_OPT][k] = deepcopy(d1[sk.SESSION_OPT][k])

        q = [i for i in d[sk.SESSION_OPT]]
        for i in q:
            if i == ek.FRAME_GRADIENT:
                Preset._pass_version(d[sk.SESSION_OPT][i], Preset._default[i])
            else:
                q1 = [j for j in d[sk.SESSION_OPT][i]]
                for j in q1:
                    if i != sk.FORMAT_NAME_LIST:
                        if j in Preset._default:
                            Preset._pass_version(
                                d[sk.SESSION_OPT][i][j],
                                Preset._default[j]
                            )
                        else:
                            # an invalid option:
                            d[sk.SESSION_OPT][i].pop(j)

    @staticmethod
    def get_default(key):
        """
        Get a preset dictionary.

        string: key
            of preset

        Return: dict
            default dict
        """
        return deepcopy(Preset._default[key])

    @staticmethod
    def get_keys(key):
        """
        Get the keys belonging to a preset.

        string: key
            of preset

        Return: list
            of preset's keys
            of string
        """
        return [i for i in Preset._default[key]]

    def get_text(self):
        """
        Return the value displayed in the Entry.

        The text may or may not be a row in the drop-menu.

        Return: string
            from the Entry
        """
        g = self.menu.widget.child

        if g:
            return g.get_text()
        return ""

    def get_value(self, has_preset=False):
        """
        Return the preset dictionary.

        Skip widget(s) without keys in the dictionary.
        ZList widgets don't have preset dictionary values.

        has_preset: flag
            If it's true, the dictionary has a preset,
            and its value is stored.
        """
        d = {}

        for i in self.widget_list:
            if i.key in self._default_dict:
                d[i.key] = i.get_value()

        if has_preset:
            d[pk.PRESET] = self.get_text()
        return d

    @staticmethod
    def is_preset(key):
        """
        Determine if a key is a preset key.

        Return: bool
            Is true if the key is a preset key.
        """
        return key in Preset._default

    def load(self, n):
        """
        Load a preset.

        n: string
            name of preset
        """
        Port.load_count += 1

        self.menu.populate_list(self._collect_presets())

        d, n = self._get_preset(n)

        self.set_value(d)
        self.menu.set_text(n)
        self.verify_del_button()
        Port.load_count -= 1

    def load_preset(self, n, d):
        """
        Load a preset dictionary.

        n: string
            to display

        d: dict
            of preset
        """
        Port.load_count += 1

        self.menu.populate_list(self._collect_presets())
        self.set_value(d)
        self.menu.set_text(n)
        self.verify_del_button()
        Port.load_count -= 1

    def preset_is_undefined(self, ignore_load=False):
        """
        Set the preset ComboBox display to undefined.

        ignore_load: flag
            If true, then ignore the 'Port.load_count' state.
        """
        if not Port.load_count or ignore_load:
            if self.get_text() != fw.UNDEFINED:
                self.set_text(fw.UNDEFINED)
                self.verify_del_button()

    def refresh(self, n):
        """
        The state of the preset menu has changed.

        n: string
            the name to display on the menu
        """
        Port.load_count += 1

        self.menu.populate_list(self._collect_presets())

        p = self.menu.set_value if n in self._option_list \
            else self.menu.set_text

        p(n)
        self.verify_del_button()
        Port.load_count -= 1

    def save(self, *_):
        """Save a preset file."""
        d = {
            pk.GET_DATA: self.get_value,
            UIKey.WINDOW: self.win.win,
            UIKey.STAT: self.stat,
            'key': self.key
        }
        if RWSave(d).is_write:
            # Get result from the init dict:
            self.refresh(d[pk.FILE_NAME])

    def set_text(self, n):
        """
        Set the text in the Entry.

        The text does not have to be a row in the drop-menu.

        n: string
            to display in the Entry
        """
        g = self.menu.widget.child
        if g:
            g.set_text(n)

    def set_value(self, d):
        """
        Load the preset on a menu change.

        d: dict
            preset dict or None
        """
        Port.load_count += 1
        k = self.key

        for i in self.widget_list:
            if i.key:
                if i.key in d:
                    if isinstance(i, Preset):
                        if pk.PRESET in d:
                            n = d[pk.PRESET] if i.key == k else fw.UNDEFINED

                        else:
                            n = fw.UNDEFINED
                        i.load_preset(n, d[i.key])
                    else:
                        i.set_value(d[i.key])
                else:
                    i.set_value(self._default_dict[i.key])

        Port.load_count -= 1
        if self.verify:
            self.verify(self)

    def verify_del_button(self):
        """The delete Button is valid for an external preset."""
        n = self.get_text()

        if n != fw.UNDEFINED:
            x = 0 if n == DEFAULT else 1

        else:
            x = 0
        (self._delete_button.disable, self._delete_button.enable)[x]()
