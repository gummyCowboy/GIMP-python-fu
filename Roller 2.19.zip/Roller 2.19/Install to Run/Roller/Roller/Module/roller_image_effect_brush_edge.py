#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import seed
from roller_format_form import Form
from roller_image_effect import LayerKey as nk
from roller_render_hub import RenderHub
from roller_one_constant import (
    BrushKey as bk,
    CellKey as ck,
    ForLayout,
    FormatKey as fk,
    FreeCellKey as fck,
    OptionKey as ok,
    SessionKey as sk
)
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_one_mode import Mode
import gimpfu as fu

pdb = fu.pdb
FREE = ForLayout.FREE_CELL


class BrushEdge:
    """Create a frame with a brush and color."""

    def __init__(self, one):
        """
        Do the image-effect.

        one: One
            Has variables.
        """
        d = one.d
        stat = self.stat = one.stat
        j = stat.render.image
        parent = self.parent = one.parent
        self.format_name = Lay.get_format_name_from_group(parent)
        self.form = None
        image_layer = stat.render.get_image_layer(self.format_name)

        seed(d[ok.RANDOM_SEED])

        # Preserve:
        fg_color = pdb.gimp_context_get_foreground()

        # Check value of option to get a color that has contrast:
        if RenderHub.rgb_to_hsv(d[ok.COLOR])[2] <= .5:
            pdb.gimp_context_set_foreground((255, 255, 255))

        else:
            pdb.gimp_context_set_foreground((0, 0, 0))

        # Get the format dict:
        for x, i in enumerate(one.session[sk.FORMAT_LIST]):
            if i[fk.Layer.NAME] == self.format_name:
                self.form = i
                break

        n = Lay.get_layer_name(nk.TRANSPARENCY, parent=parent)
        z = Lay.add(j, n, parent=parent)
        self.merged = Form.is_merge_cells(self.form)
        self.row, self.col = stat.layout.get_division(x)

        for p in (self._process_grid, self._process_free_range):
            p(j, z, d)

        z.mode = Mode.d[d[ok.MODE]]
        z.opacity = d[ok.BRUSH_DICT][bk.OPACITY]
        z1 = Lay.add(j, one.k, parent=parent, offset=1)

        Sel.item(image_layer)
        Sel.grow(
            j,
            int(d[ok.BRUSH_DICT][bk.SIZE] / 2. + d[ok.EXPAND]),
            1
        )
        Sel.item(image_layer, option=fu.CHANNEL_OP_SUBTRACT)

        sel = stat.save_render_sel()

        Sel.fill(z1, d[ok.COLOR])

        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        z.name = n

        Sel.item(image_layer)
        Lay.clear_sel(z)

        z = Lay.clone(z)
        z.mode = fu.LAYER_MODE_OVERLAY

        Gegl.emboss(z, stat.light_angle, 30, 1)

        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        z.opacity = d[ok.OPACITY]

        Sel.load(j, sel)
        Sel.clear_outside_of_selection(z)
        # Restore:
        pdb.gimp_context_set_foreground(fg_color)

    def _process_free_range(self, j, z, d):
        """
        Do the effect for any free-range cells.

        j: GIMP image
            work-in-progress
            Is render.

        z: layer
            to receive effect

        d: dict
            Has options.
        """
        for e in reversed(self.form[fk.Layer.CELL_LIST]):
            sel = self.stat.get_image_sel(e[fck.CELL][ck.NAME], FREE, FREE)
            self._process_image(j, z, d, sel)

    def _process_grid(self, j, z, d):
        """
        Do effect for each image in the cell grid.

        j: GIMP image
            Is render.

        z: layer
            to receive effect

        d: dict
            Has options.
        """
        # Do one image at a time:
        for r in range(self.row):
            for c in range(self.col):
                if self.merged:
                    s = self.form[fk.Cell.Grid.PER_CELL][r][c]

                else:
                    # not a dependent cell:
                    s = 1
                # Is it a dependent cell?
                if s != (-1, -1):
                    sel = self.stat.get_image_sel(self.format_name, r, c)
                    BrushEdge._process_image(j, z, d, sel)

    @staticmethod
    def _process_image(j, z, d, sel):
        """
        Do the effect for an image.

        j: GIMP image
            Is render.

        z: layer
            to receive effect

        d: dict
            Has options.
        """
        if sel:
            Sel.load(j, sel)

            if d[ok.EXPAND] > 0:
                Sel.grow(j, d[ok.EXPAND], 1)

            elif d[ok.EXPAND] < 0:
                for i in range(abs(d[ok.EXPAND])):
                    pdb.gimp_selection_shrink(j, 1)

            pdb.plug_in_sel2path(j, z)

            stroke = j.active_vectors.strokes[0]
            e = d[ok.BRUSH_DICT]

            pdb.gimp_selection_none(j)
            RenderHub.brush_stroke_on_stroke(
                z,
                e[bk.BRUSH],
                e[bk.SIZE],
                stroke,
                e[bk.SPACING],
                hardness=e[bk.HARDNESS],
                angle=e[bk.ANGLE],
                angle_flux=d[ok.ANGLE_FLUX],
                opacity_flux=d[ok.OPACITY_FLUX]
            )
