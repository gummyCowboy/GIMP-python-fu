#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import ForBackdropStyle as fbs, OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay
import gimpfu as fu

pdb = fu.pdb

em = Fu.Emboss
np = Fu.NewsPrint
FOUR_COORDINATES = 4


class EtchSketch:
    """Use edge and newsprint to create a broken line style."""

    def __init__(self, one):
        """
        Create a Etch Sketch backdrop-style.

        one: One
            Has variables.
        """
        z = Lay.clone(one.z)
        if Lay.has_pixel(z):
            d = one.d
            self.group_key = one.k
            self.angle = one.stat.light_angle
            self.cell_size = d[ok.CELL_SIZE]
            self.emboss = d[ok.EMBOSS]
            self.invert = d[ok.INVERT]
            self.opacity = d[ok.OPACITY]
            self.sketch_type = fbs.NEWS_TYPE.index(d[ok.SKETCH_TEXTURE])
            parent = one.z.parent

            pdb.plug_in_edge(
                z.image,
                z,
                Fu.Edge.AMOUNT_1,
                Fu.Edge.NO_WRAP,
                Fu.Edge.SOBEL
            )

            z = self._do_step_1(z, parent)
            z = self._do_step_2(z, Lay.clone(one.z), parent)
            self._do_step_3(z, parent, one.stat.elevation)

    def _do_step_1(self, z, parent):
        """
        Increase the strength of the line.

        z: layer
            Has line.

        parent: group layer
            contains the style
        """
        j = z.image
        group = Lay.group(j, self.group_key, parent=parent)

        pdb.gimp_image_reorder_item(j, z, group, 0)

        z1 = Lay.clone(z)
        z1.mode = fu.LAYER_MODE_OVERLAY

        pdb.gimp_drawable_invert(z, 0)
        return Lay.merge_group(group)

    def _do_step_2(self, z, z1, parent):
        """
        Apply news print to line.

        z: layer
            Has line.

        z1: layer
            copy of the original layer

        parent: group layer
            contain the style
        """
        while self.angle < 0:
            self.angle += 360

        j = z.image
        group = Lay.group(j, self.group_key, parent=parent)

        pdb.gimp_image_reorder_item(j, z1, group, 0)
        pdb.gimp_image_reorder_item(j, z, group, 0)

        z.mode = fu.LAYER_MODE_DARKEN_ONLY

        pdb.plug_in_newsprint(
            j,
            z,
            self.cell_size,
            np.RGB,
            np.BLACK_100,
            self.angle,
            self.sketch_type,
            self.angle,
            self.sketch_type,
            self.angle,
            self.sketch_type,
            self.angle,
            self.sketch_type,
            np.SAMPLE_2
        )

        q = 0, 0, 0

        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_sample_merged(0)
        pdb.gimp_context_set_sample_criterion(0)
        pdb.gimp_context_set_sample_threshold(.25)
        pdb.gimp_context_set_sample_transparent(1)
        pdb.gimp_image_select_color(j, fu.CHANNEL_OP_REPLACE, z1, q)
        Lay.clear_sel(z)
        Lay.blur(z1, 500)
        pdb.gimp_curves_spline(
            z1,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 100, 255, 155]
        )

        z.opacity = self.opacity
        return Lay.merge_group(group)

    def _do_step_3(self, z, parent, elevation):
        """
        Do invert and / or emboss.

        z: layer
            Has line.

        parent: group layer
            contain the style

        elevation: float
            for emboss
        """
        j = z.image
        group = Lay.group(j, self.group_key, parent=parent)

        pdb.gimp_image_reorder_item(j, z, group, 0)

        if self.invert:
            pdb.gimp_drawable_invert(z, 0)

        if self.emboss:
            z1 = Lay.clone(z)
            z1.mode = fu.LAYER_MODE_HARDLIGHT
            pdb.plug_in_emboss(
                j,
                z1,
                self.angle,
                elevation,
                em.DEPTH_1,
                em.EMBOSS
            )
        return Lay.merge_group(group)
