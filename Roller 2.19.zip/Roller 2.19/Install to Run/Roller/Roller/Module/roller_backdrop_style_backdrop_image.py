#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import RollerImage
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class BackdropImage:
    """Place an image on the backdrop layer."""

    def __init__(self, one):
        """
        Do the Backdrop Image backdrop-style.

        one: One
            Has variables.
        """
        d = one.d
        j, z = one.stat.render.image, one.z
        j1 = None

        if d[ok.BACKDROP_IMAGE] != ok.NONE:
            # Copy the backdrop image to the backdrop layer:
            j1 = RollerImage.get_image(one.session, d[ok.BACKDROP_IMAGE])

        if j1:
            j2 = j1.j

            pdb.gimp_selection_none(j2)
            pdb.gimp_edit_copy_visible(j2)

            if j1.size != one.session['size']:
                if d[ok.FIT_IMAGE]:
                    # Resize the backdrop image to fit the backdrop layer:
                    Form.shape(
                        pdb.gimp_edit_paste_as_new_image(),
                        one.session['w'],
                        one.session['h']
                    )

            z1 = Lay.paste(z)

            if not d[ok.FIT_IMAGE]:
                pdb.gimp_layer_resize_to_image_size(z1)

            z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

            if d[ok.BACKDROP_IMAGE_BLUR]:
                Gegl.blur(z, d[ok.BACKDROP_IMAGE_BLUR])

            if d[ok.INVERT]:
                pdb.gimp_drawable_invert(z, 0)

            RenderHub.bump(Lay.clone(z), d[ok.BUMP], one.stat)
            RollerImage.close_image(j1)
