#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_widget import FormatWidget
from roller_one_constant import (
    BorderKey as bo,
    CaptionKey as ck,
    ForColor,
    FormatKey as fk,
    ForWidget as fw,
    FringeKey as fr,
    MarginKey as mk,
    MaskKey,
    PlaceKey as pl,
    PlaqueKey as pq,
    PortCellKey,
    PropertyKey,
    UIKey,
    WidgetKey,
    WindowKey
)
from roller_one_tip import Tip
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_button import RollerButton
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_table import RollerTable
import gtk

ALIGN = 0, 0, 0, 0

# For GTK, let it know that the function handled an signal:
DONE = 1

PAD = 0, 0, fw.MARGIN, fw.MARGIN

preset_key = {
    fk.Cell.Border.PER_CELL: bo.CELL_BORDER,
    fk.Cell.Caption.PER_CELL: ck.CELL_CAPTION,
    fk.Cell.Fringe.PER_CELL: fr.CELL_FRINGE,
    fk.Cell.Image.Mask.PER_CELL: MaskKey.IMAGE_MASK,
    fk.Cell.Margin.PER_CELL: mk.MARGINS,
    fk.Cell.Plaque.PER_CELL: pq.CELL_PLAQUE,
    fk.Cell.Image.Place.PER_CELL: pl.IMAGE_PLACE,
    fk.Cell.Image.Property.PER_CELL: PropertyKey.IMAGE_PROPERTY
}


class PortCellMod(Port):
    """Draw the cell modification port for a single cell."""

    def __init__(self, d, r, c):
        """
        Start it up.

        d: dict
            of PortCell

        r, c: int
            cell index
            work-in-progress
        """
        self._row, self._column = r, c
        self.subtitle = d[UIKey.WINDOW_TITLE]
        self.key = d[WidgetKey.KEY]
        self._set_tool_tip = d[PortCellKey.SET_TOOLTIP]
        self.form, self._f_x = d[UIKey.FORMAT_DICT], d[UIKey.FORMAT_INDEX]
        self._table = d[PortCellKey.CELL_TABLE]
        self._rows, self._columns = d[PortCellKey.TABLE_SIZE]
        d[UIKey.WINDOW_KEY] = WindowKey.CELL_MOD
        self._cell_draw_dict = {
            fk.Cell.Border.PER_CELL: self._draw_border_cell,
            fk.Cell.Caption.PER_CELL: self._draw_caption_cell,
            fk.Cell.Fringe.PER_CELL: self._draw_fringe_cell,
            fk.Cell.Image.Mask.PER_CELL: self._draw_image_mask_cell,
            fk.Cell.Image.Place.PER_CELL: self._draw_place_cell,
            fk.Cell.Image.Property.PER_CELL: self._draw_property_cell,
            fk.Cell.Margin.PER_CELL: self._draw_margin_cell,
            fk.Cell.Plaque.PER_CELL: self._draw_plaque_cell
        }

        Port.__init__(self, d)
        self._show_active_cell()

    def _apply_to_all(self, _):
        """
        Apply the widget values to all related cells.

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()
        self._get_values()

        for r in range(self._rows):
            for c in range(self._columns):
                self._set_changed_box(r, c)
        return self.do_accept_callback()

    def _apply_to_even(self, g):
        """
        Apply the widget values to the
        current cell and even-sequenced cells.

        g: RollerButton
            Is responsible.
            not used

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()
        self._get_values()

        for r in range(self._rows):
            for c in range(self._columns):
                if (r + c) % 2:
                    self._set_changed_box(r, c)

        if not (self._row + self._column) % 2:
            self._set_changed_box(self._row, self._column)
        return self.do_accept_callback()

    def _apply_to_odd(self, _):
        """
        Apply the widget values to the
        current cell and odd-sequenced cells.

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()
        self._get_values()

        for r in range(self._rows):
            for c in range(self._columns):
                if not (r + c) % 2:
                    self._set_changed_box(r, c)

        if (self._row + self._column) % 2:
            self._set_changed_box(self._row, self._column)
        return self.do_accept_callback()

    def _apply_to_column(self, _):
        """
        Apply the widget values to the
        current cell table column.

        Return: true
            The key-press is handled.
        """
        c = self._column

        self._show_inactive_cell()
        self._get_values()

        for r in range(self._rows):
            self._set_changed_box(r, c)
        return self.do_accept_callback()

    def _apply_to_row(self, g):
        """
        Apply the widget values to the current cell table row.

        g: RollerButton
            not in use

        Return: true
            The key-press is handled.
        """
        r = self._row

        self._show_inactive_cell()
        self._get_values()

        for c in range(self._columns):
            self._set_changed_box(r, c)
        return self.do_accept_callback()

    def _do_east_cell(self, *_):
        """Move cell focus eastward."""
        self._save_data()
        self._east_button.set_tooltip_text("")

        for c in range(self._column + 1, self._columns):
            if self._table[self._row][c].has_pic:
                self._column = c
                break
            elif self._table[self._row][c].is_topleft:
                self._column = c
                break
        self._update_widgets()

    def _do_north_cell(self, *_):
        """Move cell focus upward."""
        self._save_data()
        self._north_button.widget.set_tooltip_text("")

        for r in range(self._row - 1, -1, -1):
            if self._table[r][self._column].has_pic:
                self._row = r
                break
            elif self._table[r][self._column].is_topleft:
                self._row = r
                break
        self._update_widgets()

    def _do_south_cell(self, *_):
        """Move cell focus downward."""
        self._save_data()
        self._south_button.set_tooltip_text("")

        for r in range(self._row + 1, self._rows):
            if self._table[r][self._column].has_pic:
                self._row = r
                break
            elif self._table[r][self._column].is_topleft:
                self._row = r
                break
        self._update_widgets()

    def _do_west_cell(self, *_):
        """Change the focus cell to the cell to the west."""
        self._save_data()
        self._west_button.set_tooltip_text("")

        for c in range(self._column - 1, -1, -1):
            if self._table[self._row][c].has_pic:
                self._column = c
                break
            elif self._table[self._row][c].is_topleft:
                self._column = c
                break
        self._update_widgets()

    def _draw_border_cell(self, g):
        """
        Draw a cell's settings.

        Draw the widgets for the border group.

        g: Widget
            container

        Return: list
            a list of the widgets.
            The list is strict-ordered.
        """
        return FormatWidget.draw_border_group(
            bottom_pad=fw.MARGIN,
            color=self.color,
            container=g,
            is_per_cell=True,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            port=self,
            stat=self.stat,
            sub_type=bo.CELL_BORDER,
            win=self.roller_window
        )

    def _draw_caption_cell(self, g):
        """
        Draw a cell's settings.

        Draw the widgets for the caption group.

        g: Widget
            container

        Return: list
            a list of the widgets.
            The list is strict-ordered.
        """
        return FormatWidget.draw_caption_group(
            bottom_pad=fw.MARGIN,
            sub_type=ck.CELL_CAPTION,
            color=self.color,
            container=g,
            fraction_of="Cell",
            is_per_cell=True,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            get_size=self.get_size,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_cell_navigation_group(self, g):
        """
        Draw four horizontally oriented buttons
        that can navigate the cell table.

        g: container
            container for buttons
        """
        w = fw.MARGIN
        box = RollerEventBox(self.color)
        vbox = RollerBox(gtk.VBox, align=(0, 0, 0, 0))
        hbox = RollerBox(gtk.HButtonBox, align=(0, 0, 0, 0))

        vbox.pack_start(
            RollerLabel(
                padding=(2, 4, 4, 0),
                text="Cell Navigation:"
            )
        )
        vbox.pack_start(hbox, expand=False)
        box.add(vbox)
        g.pack_start(box, expand=False)
        hbox.set_padding(0, 0, w, w)

        self._north_button = RollerButton(
            on_widget_change=self._do_north_cell,
            text="↑"
        )
        self._south_button = RollerButton(
            on_widget_change=self._do_south_cell,
            text="↓"
        )
        self._west_button = RollerButton(
            on_widget_change=self._do_west_cell,
            text="←"
        )
        self._east_button = RollerButton(
            on_widget_change=self._do_east_cell,
            text="→"
        )
        for x, i in enumerate(
            (
                self._north_button,
                self._south_button,
                self._west_button,
                self._east_button
            )
        ):
            hbox.pack_start(i, expand=False)
            i.set_tooltip_text(Tip.NAVIGATION[x])

    def _draw_fringe_cell(self, g):
        """
        Draw a cell's settings.

        Draw the widgets for the fringe group.

        g: Widget
            container

        Return: dict
            of widget
        """
        return FormatWidget.draw_fringe_group(
            bottom_pad=fw.MARGIN,
            sub_type=fr.CELL_FRINGE,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_image_mask_cell(self, g):
        """
        Draw a cell's settings.

        g: Widget
            container

        Return: dict
            of widget
        """
        return FormatWidget.draw_mask_group(
            bottom_pad=fw.MARGIN,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_margin_cell(self, g):
        """
        Draw a cell's settings.

        Draw the ComboBoxes for Image Place.

        g: Widget
            container

        Return: list
            of widget
            index-ordered
        """
        return FormatWidget.draw_margin_group(
            bottom_pad=fw.MARGIN,
            sub_type=fk.Cell,
            color=self.color,
            container=g,
            fraction_of="Cell",
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            get_size=self.get_size,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_place_cell(self, g):
        """
        Draw a cell's settings.

        Draw the ComboBoxes for Image Place.

        g: Widget
            container

        Return: list
            of widget
            index-ordered per the format dict
        """
        return FormatWidget.draw_place_group(
            bottom_pad=fw.MARGIN,
            color=self.color,
            container=g,
            get_format_info=self.get_format_info,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_plaque_cell(self, g):
        """
        Draw a cell's settings.

        g: Widget
            container

        Return: dict
            of widget
        """
        return FormatWidget.draw_plaque_group(
            bottom_pad=fw.MARGIN,
            sub_type=pq.CELL_PLAQUE,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_process_group(self):
        """
        Draw the process group buttons.

        Return: RollerEventBox
            contains group
        """
        w = fw.MARGIN
        q = []
        box = RollerEventBox(self.color)
        vbox = RollerBox(gtk.VBox, align=(0, 0, 1, 1))

        box.add(vbox)
        vbox.pack_start(
            RollerLabel(padding=(2, 0, 4, 0), text="Apply:"),
            expand=False
        )
        q.append(
            RollerButton(
                on_widget_change=self.do_cancel,
                padding=PAD,
                text="Cancel"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self._apply_to_row,
                padding=PAD,
                text="Row"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self._apply_to_column,
                padding=PAD,
                text="Column"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self._apply_to_all,
                padding=PAD,
                text="All Cells"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self._apply_to_even,
                padding=PAD,
                text="Cell & Even Cells"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self._apply_to_odd,
                padding=PAD,
                text="Cell & Odd Cells"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self.do_accept,
                padding=PAD,
                text="Cell"
            )
        )
        alignment = gtk.Alignment(0, 0, 0, 0)
        table = gtk.Table(len(q), 1)
        option_count = len(q)
        color = self.color

        self.keep(q)
        table.set_row_spacings(1)
        alignment.set_padding(w, w, w, w)

        for x, i in enumerate(q):
            color = RollerTable.get_darker_color(color, option_count)
            color1 = color, color, ForColor.MAX_COLOR
            box1 = RollerEventBox(color1)

            box1.add(i)
            table.attach(box1, 0, 1, x, x + 1)

        alignment.add(table)
        vbox.add(alignment)
        return box

    def _draw_property_cell(self, g):
        """
        Draw a cell's settings.

        Draw the widgets for image property.

        g: Widget
            container

        Return: list
            of widgets
            index-ordered per the format dict
        """
        return FormatWidget.draw_property_group(
            bottom_pad=fw.MARGIN,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _get_values(self):
        """Get the values of the widgets for the target cell."""
        if self._preset:
            self._cell_dict = self._preset.get_value()
        else:
            # margins:
            for k in self._widget_dict:
                break
            self._cell_dict = self._widget_dict[k].get_value()

    def _is_cell(self, r, c):
        """
        Determine if the cell is a valid image cell.

        Return: bool
            Is true if the cell is a valid image holding cell.
        """
        return self._table[r][c].has_pic or self._table[r][c].is_topleft

    def _process_control_arrow(self, n):
        """
        The user pressed control-arrow key.

        Change the widget values to the cell indicated by
        the arrow key. The target cell may not exist.

        n: string
            arrow key-press
        """
        r, c = self._row, self._column

        if n == "Down":
            if r + 1 != self._rows:
                m = False

                for r1 in range(r + 1, self._rows):
                    if self._is_cell(r1, c):
                        m = True
                        break
                if m:
                    self._do_south_cell()

        elif n == "Up":
            if r != 0:
                m = False

                for r1 in range(r - 1, -1, -1):
                    if self._is_cell(r1, c):
                        m = True
                        break
                if m:
                    self._do_north_cell()

        elif n == "Left":
            if c != 0:
                m = False

                for c1 in range(c - 1, -1, -1):
                    if self._is_cell(r, c1):
                        m = True
                        break
                if m:
                    self._do_west_cell()

        elif n == "Right":
            if c + 1 != self._columns:
                m = False

                for c1 in range(c + 1, self._columns):
                    if self._is_cell(r, c1):
                        m = True
                        break
                if m:
                    self._do_east_cell()

    def _save_data(self):
        """Save the current display values with the cell table."""
        self._show_inactive_cell()
        self._get_values()
        self._set_changed_box(self._row, self._column)

    @staticmethod
    def _set_button(m, g):
        """
        Set the button sensitivity based on a flag.

        m: flag
            If true, then enable widget.

        g: Widget
            button
        """
        g.enable() if m else g.disable()

    def _set_changed_box(self, r, c):
        """
        Set the format dict, the tooltip and the label color.

        r, c: int
            cell position
        """
        m = False

        if self._table[r][c].has_pic:
            m = True

        elif self._table[r][c].is_topleft:
            m = True
        if m:
            self.form[self.key][r][c] = self._cell_dict
            box = self._table[r][c].box

            self._set_tool_tip(box, self._cell_dict)
            box.label.modify_fg(gtk.STATE_NORMAL, ForColor.WHITE)

    def _set_widget_values(self):
        """
        Set the values displayed in the widgets.

        Data is from the current cell at self._row and self._column.
        """
        d = self.form[self.key][self._row][self._column]

        if self._preset:
            self._preset.set_value(d)

        else:
            # margins:
            for k in self._widget_dict:
                break
            self._widget_dict[k].set_value(d)

        self._show_active_cell()
        self.verify_nav_button()
        self._cell_label.widget.set_text(
            "Cell Data:\tRow: {}\tColumn: {}".format(
                self._row + 1,
                self._column + 1
            )
        )

    def _show_active_cell(self):
        """
        Change the text of the cell in the PortCell to show an edit-state.
        """
        self._table[self._row][self._column].box.label.set_text("☍")

    def _show_inactive_cell(self):
        """
        Change the text of the cell in the PortCell port back to normal.
        """
        r, c = self._row, self._column
        n = fw.IMAGE_SYMBOL if self._table[r][c].has_pic else fw.NO_IMAGE
        self._table[r][c].box.label.set_text(n)

    def _update_widgets(self):
        """Set widget values and verify dependencies."""
        self._set_widget_values()
        for i in self._widget_dict:
            g = self._widget_dict[i]
            if hasattr(g, 'verify'):
                Port.on_widget_change(g)
                break

    def do_accept(self, *_):
        """
        Apply the widget values to the cell table.

        Return: true
            The key-press is handled.
        """
        self._save_data()
        return self.do_accept_callback()

    def do_cancel(self, *_):
        """
        Update the current cell's symbol to
        show that it's back to being inactive.

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        g: VBox
            container for widgets
        """
        self._preset = None
        r, c = self._row, self._column
        self._cell_label = RollerLabel(
            padding=(2, 0, 4, 0),
            text="Cell Data:\tRow: {}\tColumn: {}".format(r + 1, c + 1)
        )
        hbox = gtk.HBox()

        # cell data group:
        box = RollerEventBox(self.color)
        vbox = RollerBox(gtk.VBox, align=(0, 0, 1, 1))

        self.reduce_color()
        box.add(vbox)
        vbox.add(self._cell_label)

        p = self._cell_draw_dict[self.key]
        self._widget_dict = p(vbox)
        k = preset_key[self.key]

        if k in self._widget_dict:
            self._preset = self._widget_dict[k]

        # navigation group:
        self.reduce_color()
        self._draw_cell_navigation_group(vbox)
        self.reduce_color()

        box1 = self._draw_process_group()

        self._set_widget_values()
        hbox.add(box)
        hbox.add(box1)
        g.add(hbox)
        self.roller_window.win.connect(
            'key_press_event',
            self.on_arrow_key_press
        )
        if self._preset:
            self._preset.refresh(fw.UNDEFINED)

    def get_format_info(self):
        """
        Use with place image button.

        Return: tuple
            format dict, format index
        """
        return self.form, self._f_x

    def get_size(self):
        """
        Use to update margin size label in PortMargin.

        Return: tuple
            width, height
            of int
            of cell
        """
        return self.stat.layout.get_cell_block_size(
            self.form,
            self._f_x,
            self._row,
            self._column
        )

    def on_arrow_key_press(self, _, event):
        """
        Check to see if the user pressed control key
        and an arrow key at the same time.

        event: key-press event
            looking for an arrow-key pressed event

        Return: None or true
            Is true if the key-press is handled.
        """
        n = gtk.gdk.keyval_name(event.keyval)
        control_pressed = (event.state & gtk.gdk.CONTROL_MASK)
        if control_pressed and n in ('Left', 'Right', 'Up', 'Down'):
            self._process_control_arrow(n)
            return DONE

    def verify_nav_button(self):
        """
        Verify the navigation button given the current cell.

        The cell indices, 'self._row' and
        'self._column', define the current cell.

        Scan the cell table for a cell with a picture.
        """
        r, c = self._row, self._column

        if r + 1 == self._rows:
            self._south_button.disable()

        else:
            m = False

            for r1 in range(r + 1, self._rows):
                if self._is_cell(r1, c):
                    m = True
                    break
            PortCellMod._set_button(m, self._south_button)

        if r == 0:
            self._north_button.disable()

        else:
            m = False

            for r1 in range(r - 1, -1, -1):
                if self._is_cell(r1, c):
                    m = True
                    break
            PortCellMod._set_button(m, self._north_button)

        if c + 1 == self._columns:
            self._east_button.disable()

        else:
            m = False

            for c1 in range(c + 1, self._columns):
                if self._is_cell(r, c1):
                    m = True
                    break
            PortCellMod._set_button(m, self._east_button)

        if c == 0:
            self._west_button.disable()
        else:
            m = False

            for c1 in range(c - 1, -1, -1):
                if self._is_cell(r, c1):
                    m = True
                    break
            PortCellMod._set_button(m, self._west_button)

    def verify_widgets(self):
        """Call widget verify functions."""
        if self._preset:
            d = self._widget_dict
            for i in d:
                g = d[i]
                if hasattr(g, 'verify'):
                    g.verify(g)
                    break
