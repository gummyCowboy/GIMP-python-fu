#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_style_gradient_fill import GradientFill
from roller_grid import Grid
from roller_one import One
from roller_one_constant import ForGradient, OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class CoreDesign:
    """
    Has lines that resemble a cube projection using
    inverted triangles and gradients.
    """

    def __init__(self, one):
        """
        Do the Core Design backdrop-style.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        n = self.option_key = one.k
        self.session = one.session
        e = deepcopy(ForGradient.LINEAR_DICT)
        j = stat.render.image
        d = one.d
        w, h = one.session['size']
        color = tuple([255 - i for i in d[ok.COLOR]])

        e.update(d)

        grid = Grid((w, h), e[ok.ROW], e[ok.COLUMN]).table
        self.group = Lay.group(j, "Temp", parent=one.z.parent)

        # Calculate points using their relative position:
        h1 = h // 5

        # The triangle is facing down:
        q = 0, h1, w, h1, w // 2, h

        e[ok.START_X], e[ok.START_Y] = .5, 1.
        e[ok.END_X], e[ok.END_Y] = .5, .2
        z = Lay.add(j, n, parent=self.group)

        # Correct alpha inheritance with 'color_fill':
        Lay.color_fill(z, (255, 255, 255))

        self._do_gradient(e)
        self._do_select(q)

        z = j.active_layer
        z.mode = fu.LAYER_MODE_DARKEN_ONLY

        Sel.clear_outside_of_selection(z, keep_sel=True)
        RenderHub.do_stylish_shadow(stat, z, intensity=50.)

        z1 = CoreDesign._double(z)

        RenderHub.do_stylish_shadow(stat, z1, intensity=50.)
        pdb.gimp_selection_none(j)

        # horizontal:
        for r1 in range(0, e[ok.ROW], 2):
            Sel.rect(j, 0, grid[r1][0].y, w, grid[r1][0].h)

        Lay.clear_sel(z1)
        RenderHub.do_stylish_shadow(stat, z1, intensity=50.)

        # vertical:
        for c1 in range(0, e[ok.COLUMN], 2):
            Sel.rect(j, grid[0][c1].x, 0, grid[0][c1].w, h)

        Lay.clear_sel(z)
        RenderHub.do_stylish_shadow(stat, z, intensity=50.)

        # background gradient:
        grad = e[ok.GRADIENT] = pdb.gimp_gradient_new(n)
        e[ok.OFFSET] = e[ok.REVERSE] = 0

        pdb.gimp_gradient_segment_set_right_color(grad, 0, color, 100.)
        pdb.gimp_gradient_segment_set_left_color(grad, 0, d[ok.COLOR], 100.)

        # left:
        e[ok.START_X], e[ok.START_Y], e[ok.END_X], e[ok.END_Y] = \
            (0., .5, .5, .5)

        Lay.add(j, n, parent=self.group, offset=len(self.group.layers))
        self._do_gradient(e)

        z = pdb.gimp_image_get_active_drawable(j)
        q = 0, 0, 0, h, w // 2 + 1, h // 2

        self._do_select(q)
        Sel.clear_outside_of_selection(z)
        CoreDesign._double(z, m=1)

        # top:
        e[ok.START_X], e[ok.START_Y], e[ok.END_X], e[ok.END_Y] = \
            (.5, 0., .5, .5)

        Lay.add(j, n, parent=self.group, offset=len(self.group.layers))
        self._do_gradient(e)

        z = pdb.gimp_image_get_active_drawable(j)
        q = 0, 0, w, 0, w // 2, h // 2 + 1

        self._do_select(q)
        Sel.clear_outside_of_selection(z)
        CoreDesign._double(z)
        pdb.gimp_gradient_delete(grad)
        Lay.merge_group(self.group)

    def _do_gradient(self, d):
        """
        Draw a gradient.

        d: dict
            Has options.
        """
        GradientFill(
            One(
                d=d,
                session=self.session,
                stat=self.stat,
                z=self.stat.render.image.active_layer
            )
        )

    def _do_select(self, q):
        """
        Select an area defined by an array of points.

        q: iterable
            rectangle points
        """
        Sel.polygon(self.stat.render.image, q)

    @staticmethod
    def _double(z, m=0):
        """
        Duplicate a layer and flip it depending on a flag.

        z: layer
            the layer where the gradient goes above it

        m: flag
            If it's true, the layer is flipped horizontally.
        """
        z1 = Lay.clone(z)

        Lay.flip(z1, horizontal=m)
        return z1
