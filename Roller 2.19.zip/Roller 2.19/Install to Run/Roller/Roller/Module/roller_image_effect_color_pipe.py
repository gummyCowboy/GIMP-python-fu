#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import ImageEffect
from roller_one_constant import ForBackdropStyle as fbs, OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub, PROFILE
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb
um = Fu.UnsharpMask


class ColorPipe:
    """Create a frame with a custom profile and color."""

    def __init__(self, one):
        """
        Do the image-effect.

        one: One
            Has variables.
        """
        stat = one.stat
        parent = one.parent
        d = one.d
        j = stat.render.image
        z = Lay.add(
            j,
            Lay.get_layer_name(ek.COLOR_PIPE, parent=parent),
            parent=parent
        )
        z1 = Lay.clone_opaque(
            stat.render.get_image_layer(
                Lay.get_format_name_from_group(parent)
            ),
            True
        )
        color = d[ok.COLOR]
        w = d[ok.FRAME_WIDTH]
        q = PROFILE[d[ok.PROFILE]](w, *(color,))

        Sel.item(z1)
        RenderHub.draw_color_profile(z, w, stat, q, color)
        pdb.gimp_image_remove_layer(j, z1)

        n = d[ok.NOISE_MODE]

        if n != ok.NONE and d[ok.NOISE_OPACITY]:
            z1 = Lay.clone(z)
            z1.opacity = d[ok.NOISE_OPACITY]
            z1.mode = fbs.NOISE_LAYER_MODE[fbs.NOISE_MODE_LIST.index(n)]

            pdb.plug_in_plasma(
                j,
                z1,
                d[ok.RANDOM_SEED],
                Fu.Plasma.LOWEST_TURBULENCE
            )
            Sel.item(z)
            Sel.clear_outside_of_selection(z1)

            if n == fbs.SYRUPY:
                pdb.plug_in_unsharp_mask(
                    j,
                    z1,
                    um.RADIUS_5,
                    um.AMOUNT_1,
                    um.THRESHOLD_0
                )

            elif n == fbs.CARTOONY:
                z = RenderHub.do_cartoony(z, z1, color)
            if n != fbs.CARTOONY:
                z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
        if d[ok.BLUR_BEHIND]:
            z.opacity = 25.
