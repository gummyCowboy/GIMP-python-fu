#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import (
    ForColor,
    ForWidget as fw,
    Signal,
    UIKey
)
from roller_widget_box import RollerBox
from roller_widget_button import ColoredButton, RollerButton, SwitchButton
import gobject
import gtk

# Are widgets that will signal a window's
# accept process upon receiving the Return key:
RETURN_WIDGETS = (
    gtk.CheckButton,
    gtk.ComboBoxEntry,
    gtk.Entry,
    gtk.HScale,
    gtk.RadioButton,
    gtk.ScrolledWindow,
    gtk.SpinButton,
    gtk.ToggleButton,
    ColoredButton,
    SwitchButton
)


class Port(gobject.GObject, object):
    """
    Is a VBox that may be hidden from view.

    Use a Port widget template:
        controls: iterable (tuple or list)
            an iterable of widget(s) with memory

        get_value: function
            Call to get the value of a widget in controls.

        set_value: function
            Call to set the value of widgets in controls.

        update_widgets: function
            Call to update widgets after a 'show_all' is performed.

        draw_port: function
            Call to create widgets for a port.
    """
    __gsignals__ = {
        Signal.VISIBILITY_CHANGE: (
            gobject.SIGNAL_RUN_LAST,
            None,
            (gobject.TYPE_PYOBJECT,)
        )
    }

    # VBoxes for ports:
    port_dict = {}

    # constant:
    COLOR_DEC = 1900

    # Use to indicate that the interface is in a drawing state, and
    # that any event handler can ignore a change or an action event:
    load_count = 0

    def __init__(self, d):
        """
        Create the VBox.

        d: dict
            Has init variables.
        """
        gobject.GObject.__init__(self)

        self.return_widgets = []
        self._pigs = []
        self.option_group_color = None
        self.controls = []
        self.stat = d[UIKey.STAT]
        self.color = ForColor.MAX_COLOR - Port.COLOR_DEC
        self.roller_window = d[UIKey.WINDOW]
        self.title = d[UIKey.WINDOW_TITLE]
        self.pane = gtk.VBox()
        Port.port_dict[d[UIKey.PORT_KEY]] = self
        k1 = UIKey.PARENT_PORT
        self.parent_port = d[k1] if k1 in d else None
        k1 = UIKey.ON_ACCEPT
        self.do_accept_callback = d[k1] if k1 in d else None
        k1 = UIKey.ON_CANCEL
        self.do_cancel_callback = d[k1] if k1 in d else None

        self.roller_window.win.set_title(self.title)
        self.pane.connect('key_press_event', self.on_key_press)

        Port.load_count += 1

        self.draw_port(self.pane)
        self.keep(self.controls)

        Port.load_count -= 1

        if hasattr(self.roller_window, 'switch_box'):
            self.roller_window.switch_box.add(self.pane)
        self.roller_window.resize()

    def draw_process_group(self, g):
        """
        Draw a process group with cancel and accept options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        w1 = w // 2
        hbox = RollerBox(gtk.HBox, align=(0, 0, 1, 1))
        q = (
            RollerButton(
                text="Cancel",
                on_widget_change=self.do_cancel,
                padding=(w, w, w, w1),
                align=(0, 0, 1, 0)
            ),
            RollerButton(
                text="Accept",
                on_widget_change=self.do_accept,
                padding=(w, w, w1, w),
                align=(0, 0, 1, 0)
            )
        )

        for i in q:
            hbox.add(i)

        g.add(hbox)
        self.keep(q)

    def draw_process_layout_group(self, g):
        """
        Draw the Show Layout, Cancel, and Accept buttons.

        g: GTK container
            for group widgets
        """
        w = fw.MARGIN
        w1 = w // 2
        hbox = RollerBox(gtk.HBox, align=(0, 0, 1, 1))
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        q = [
            RollerButton(
                on_widget_change=self.do_cancel,
                padding=(w1, w1, w, w1),
                text="Cancel"
            ),
            RollerButton(
                on_widget_change=self.show_layout,
                padding=(w1, w1, w1, w),
                text="Show Layout",
            ),
            RollerButton(
                on_widget_change=self.do_accept,
                padding=(0, w, w, w),
                text="Accept"
            )
        ]

        for i in q[:-1]:
            hbox.pack_start(i, expand=True)
            same_size.add_widget(i.widget)

        g.pack_start(hbox, expand=True)
        g.pack_start(q[-1], expand=False)
        self.keep(q)

    def keep(self, q):
        """
        Put widget reference into 'self._pigs'.

        Keep the GTK garbage collection from removing widget
        connections from a parent window when a child window is opened.

        q: iterable (tuple or list)
            Widgets
        """
        for g in q:
            self._pigs.append(g)

    def on_key_press(self, _, a):
        """
        Check to see if the user pressed the Esc key.
        If so, then close the window or port.

        a: key-press event

        Return: None or true
            Is true if the key-press is handled.
        """
        if self.pane.get_visible():
            n = gtk.gdk.keyval_name(a.keyval)

            if n == 'Escape':
                return self.do_cancel()
            if n == 'Return':
                # Get the widget in focus:
                g = self.roller_window.win.get_focus()
                if type(g) in RETURN_WIDGETS or g in self.return_widgets:
                    if isinstance(g, gtk.SpinButton):
                        # Force update to get gtk to behave:
                        g.update()
                    return self.do_accept()

    def on_list_change(self, g):
        """
        Respond when the user changes selection in the navigation list.

        Is part of NavigationList template.

        g: NavigationList
            Has attributes.

        """
        if not Port.load_count:
            x = g.get_sel_x()

            # The switch group box is the container for
            # the navigation list's option group boxes:
            if x is not None:
                # 'get_children' is created by GTK when option
                # groups are added to the 'switch_group_box':
                if hasattr(g.switch_group_box, 'get_children'):
                    children = g.switch_group_box.get_children()
                    g1 = g.group_box[x]

                    if g1 not in children:
                        g.switch_group_box.add(g1)

                    g1.show_all()
                    self.emit(Signal.VISIBILITY_CHANGE, (g, x))

                    for child in children:
                        if child != g1:
                            if isinstance(child, gtk.VBox):
                                child.hide()
                    # Resize the window with the group-size change:
                    self.roller_window.resize()

    @staticmethod
    def on_widget_change(g):
        """
        Call widget verify functions.

        g: Widget
            the widget that changed
        """
        # Ignore Port.load_count:
        if hasattr(g, 'verify'):
            g.verify(g)

    def reduce_color(self):
        """'self.color' is used by the red and green color components."""
        self.color -= Port.COLOR_DEC

    def switch_ports(self):
        """Call when switching to a new port."""
        self.roller_window.win.iconify()
        self.pane.hide()
        self.roller_window.switch_box.remove(self.pane)


# Register the custom signal:
gobject.type_register(Port)
