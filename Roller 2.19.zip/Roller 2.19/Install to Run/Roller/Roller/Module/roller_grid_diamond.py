#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import Rect
from roller_grid import Grid
from roller_one_constant import ForFormat as ff, FormatKey as fk


class GridDiamond:
    """
    Calculate the coordinates and the size of cells.

    The cells are diamond shaped.
    """

    def __init__(self, grid):
        """
        Calculate cell size and diamond shape.

        grid: One
            Has init values.
        """
        self.grid = grid
        row, column = grid.r, grid.c
        table = grid.table
        s = grid.layer_space
        x, y = grid.offset
        self.double_type = grid.double_type
        self.is_not_shift = self.double_type == ff.Cell.NOT_SHIFT
        x_intersect = self.x_intersect = []
        y_intersect = self.y_intersect = []

        if grid.grid_type == ff.Grid.Index.CELL_SIZE:
            # cell size:
            w, h = grid.column_width / 1., grid.row_height / 1.

            # table size:
            w1, h1 = w / 2., h / 2.
            s1 = w + (column - 1) * w1, h + (row - 1) * h1
            x, y = Grid.calc_pin_offset(grid.pin, s, s1[0], s1[1], x, y)

        elif grid.grid_type == ff.Grid.Index.SHAPE_COUNT:
            # cell size:
            w = s[0] / (.5 + column * .5)
            h = s[1] / (.5 + row * .5)
            w = min(w, h) / 1.
            w, h = w, w

            # table size:
            h1 = h / 2.
            s1 = column * h1 + h1, row * h1 + h1
            x, y = Grid.calc_pin_offset(grid.pin, s, s1[0], s1[1], x, y)

        else:
            w = s[0] / (.5 + column * .5)
            h = s[1] / (.5 + row * .5)

        offset = x, y

        # intersects:
        w1 = w / 2
        h1 = h / 2
        for c in range(column + 2):
            x_intersect.append(int(round(x)))
            x += w1

        for r in range(row + 2):
            y_intersect.append(int(round(y)))
            y += h1

        # Compose points:
        for r in range(row):
            for c in range(column):
                if Form.is_double_space_cell(r, c, self.double_type):
                    y, y1, y2 = (
                        y_intersect[r],
                        y_intersect[r + 1],
                        y_intersect[r + 2]
                    )
                    x, x1, x2 = (
                        x_intersect[c],
                        x_intersect[c + 1],
                        x_intersect[c + 2]
                    )

                    position = x, y
                    size = x2 - x, y2 - y

                    if (
                        x + size[0] > s[0] + offset[0] or
                        y + size[1] > s[1] + offset[1]
                    ):
                        position = size = 0, 0

                    # 'cell' is the cell rectangle before margins:
                    table[r][c].cell = Rect(position, size)
                    if size[0]:
                        # If there are no margins, then do shape:
                        table[r][c].plaque = x, y1, x1, y, x2, y1, x1, y2
                        if grid.with_shape:
                            table[r][c].shape = table[r][c].plaque

    def _do_per_cell(self, r, c, q):
        """
        Get and calculate the points to make a diamond.

        Vertical triangles face up or down.

        r, c: int
            cell index

        q: tuple
            top, bottom, left, right

        is_inverted: flag
            If it's true, the triangle is inverted.

        Return: tuple
            of lists
            x-intersect list, x-pocket list, and
            y-intersect list, y-pocket list
            Each list has strict synchronized points.
        """
        top, bottom, left, right = q
        x_list = [-1] * 4
        y_list = [-1] * 4
        x_list_1 = [0] * 4
        y_list_1 = [0] * 4

        # Get points from intersects:
        # of y:
        if not top:
            y_list[1] = self.y_intersect[r]

        if not bottom:
            y_list[3] = self.y_intersect[r + 2]

        if not top and not bottom:
            y_list[0] = y_list[2] = self.y_intersect[r + 1]

        # of x:
        if not left:
            x_list[0] = self.x_intersect[c]

        if not right:
            x_list[2] = self.x_intersect[c + 2]

        if not left and not right:
            x_list[1] = x_list[3] = self.x_intersect[c + 1]

        # Calc shape from pocket:
        rect = self.grid.table[r][c].pocket

        # of y:
        y_list_1[1] = rect.y
        y_list_1[3] = rect.y + rect.h
        y_list_1[0] = y_list_1[2] = rect.y + rect.h // 2

        # of x:
        x_list_1[0] = rect.x
        x_list_1[2] = rect.x + rect.w
        x_list_1[1] = x_list_1[3] = rect.x + rect.w // 2

        # Return the intersect and pocket-bound points:
        return x_list, x_list_1, y_list, y_list_1

    def calc_shape_per_cell(self, d):
        """
        Calculate the shape of the diamond from
        the pocket size on a per cell basis.

        Is part of the GridDeck template.

        d: dict
            Has format.
        """
        for r in range(self.grid.r):
            for c in range(self.grid.c):
                if Form.is_double_space_cell(r, c, self.double_type):
                    rect = self.grid.table[r][c].cell
                    if rect.w:
                        q = Form.combine_margin(
                            d[fk.Cell.Margin.PER_CELL][r][c],
                            rect.w,
                            rect.h
                        )

                        x_list, x_list_1, y_list, y_list_1 = \
                            self._do_per_cell(r, c, q)

                        q = zip(x_list, x_list_1)
                        q_x = map(Grid.get_point, q)
                        q = zip(y_list, y_list_1)
                        q_y = map(Grid.get_point, q)
                        q = zip(q_x, q_y)
                        self.grid.table[r][c].shape = [j for i in q for j in i]

    def calc_shape_with_pocket(self):
        """
        Calculate the shape of the diamond from
        the pocket size using intersects.

        Is part of the GridDeck template.
        """
        q = self.grid.table
        x_intersect = self.x_intersect = []
        y_intersect = self.y_intersect = []

        for c in range(self.grid.c):
            if self.grid.r == 1:
                r = 0
                if Form.is_double_space_cell(0, c, self.double_type):
                    rect = q[r][c].pocket
                else:
                    rect = Rect((0, 0), (0, 0))

            else:
                r = c % 2 if self.is_not_shift else not c % 2
                rect = q[r][c].pocket

            x = rect.x

            x_intersect.append(x)
            x_intersect.append(x + rect.w // 2)
            x_intersect.append(x + rect.w)

        for r in range(self.grid.r):
            if self.grid.c == 1:
                c = 0
                if Form.is_double_space_cell(r, 0, self.double_type):
                    rect = q[r][c].pocket
                else:
                    rect = Rect((0, 0), (0, 0))

            else:
                c = r % 2 if self.is_not_shift else not r % 2
                rect = q[r][c].pocket

            y = rect.y

            y_intersect.append(y)
            y_intersect.append(y + rect.h // 2)
            y_intersect.append(y + rect.h)
        for r in range(self.grid.r):
            for c in range(self.grid.c):
                if Form.is_double_space_cell(r, c, self.double_type):
                    if q[r][c].pocket.w:
                        x = x_intersect[c * 3]
                        x1 = x_intersect[c * 3 + 1]
                        x2 = x_intersect[c * 3 + 2]
                        y = y_intersect[r * 3]
                        y1 = y_intersect[r * 3 + 1]
                        y2 = y_intersect[r * 3 + 2]
                        q[r][c].shape = x, y1, x1, y, x2, y1, x1, y2
