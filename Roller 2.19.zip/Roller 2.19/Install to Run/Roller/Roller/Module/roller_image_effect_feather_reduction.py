#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import ImageEffect
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb
FEATHER = ek.FEATHER_REDUCTION


class FeatherReduction:
    """Feather the edges of the combined images on the image layer."""

    def __init__(self, one):
        """
        Do the Feather Reduction effect.

        one: One
            Has variables.
        """
        stat = one.stat
        z = stat.render.get_image_layer(
            Lay.get_format_name_from_group(one.parent)
        )
        z = Lay.clone(z)
        z.name = Lay.get_layer_name(FEATHER, parent=z.parent)

        Lay.show(z)
        FeatherReduction.do(z, one.d)

    @staticmethod
    def do(z, d):
        """
        Feather material with linear growth repeating steps.

        z: layer
            Has material to feather.

        d: dict
            Has feather options.
        """
        if z:
            j = z.image
            a = d[ok.FEATHER]
            f = float(a) / d[ok.STEPS]
            b = f

            Sel.item(z)
            Sel.invert(j)
            RenderHub.expand_image(j)

            while a > b:
                Sel.item(z)
                pdb.gimp_selection_feather(j, b)

                if Sel.is_sel(j):
                    Sel.clear_outside_of_selection(z)

                else:
                    break
                b = min(b + f, a)
            RenderHub.contract_image(j)
