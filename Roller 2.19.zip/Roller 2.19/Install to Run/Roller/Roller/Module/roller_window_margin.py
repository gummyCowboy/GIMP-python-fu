#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import PortKey, UIKey, WindowKey
from roller_port_margin import PortMargin
from roller_window import RollerWindow


class RWMargin(RollerWindow):
    """Is a GTK dialog with margin-setter widgets."""
    def __init__(self, g):
        """
        Create a window.

        g: RollerButton
            Is responsible.
        """
        d = {UIKey.WINDOW: g.win.win, UIKey.STAT: g.stat}
        self._button = g
        d[UIKey.WINDOW_TITLE] = g.key + " Settings"
        d[UIKey.WINDOW_KEY] = WindowKey.MARGIN_CHOOSER

        RollerWindow.__init__(self, d)
        d.update(
            {
                UIKey.ON_ACCEPT: self.do_accept,
                UIKey.ON_CANCEL: self.do_cancel,
                UIKey.WINDOW: self,
                UIKey.PORT_KEY: PortKey.NOT_USED
            }
        )

        self.port = PortMargin(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()

    def do_cancel(self, *_):
        """
        Close the window.

        Return: true
            GTK, it is done.
        """
        return self.close()

    def do_accept(self, d):
        """
        Accept the new margin settings.

        d: dict
            of margin
            for the margin button

        Return: true
            GTK, it is done.
        """
        self._button.set_value(d)
        return self.close()
