#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gtk


class RollerBox(gtk.Alignment):
    """This is a GTK Box widget with an Alignment."""

    def __init__(self, box_type, align=(0, 0, 0, 0), padding=None):
        """
        Create a box container for other widgets.

        box_type: class
            either VBox, HBox, VButtonBox, HButtonBox

        align: tuple
            of float
            top, bottom, left, right
            Alignment
            in .0 to 1.

        padding: tuple of int
            top, bottom, left, right
        """
        super(gtk.Alignment, self).__init__()
        self.set(*align)

        self._box = box_type()

        if padding:
            self.set_padding(*padding)
        super(gtk.Alignment, self).add(self._box)

    def add(self, g):
        """
        Add a widget to the box.

        g: GTK widget
            to add
        """
        self._box.add(g)

    def pack_start(self, g, **d):
        """
        Place a widget in the box.

        g: GTK widget
            Is packed into container.

        d: dict
            keyword options
        """
        self._box.pack_start(g, **d)
