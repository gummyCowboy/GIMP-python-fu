#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_border_line import BorderLine
from roller_image_effect import ImageEffect
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
import gimpfu as fu

cs = Fu.ColorSelect
ed = Fu.Edge
ek = ImageEffect.Key
pdb = fu.pdb


class RaisedMaze(BorderLine):
    """Add a framework to BorderLine."""

    def __init__(self, one):
        """
        Do the Line Fashion image-effect.

        one: One
            Has variables.
        """
        # Preserve:
        q = pdb.gimp_context_get_foreground()
        q1 = pdb.gimp_context_get_background()

        BorderLine.__init__(
            self,
            one,
            framer=self.make_sel
        )

        # Restore:
        pdb.gimp_context_set_foreground(q)
        pdb.gimp_context_set_background(q1)

    def make_sel(self, d):
        """
        Modify the current selection with the selected lines.

        Add the line selection to the border selection
        within the bounds of the filler selection.

        d: dict
            Has options.

        Return: state of selection
        """
        sel = None
        j = self.stat.render.image
        frame_sel = self.stat.save_render_sel()
        z = Lay.add(j, self.option_key, parent=self.parent)
        w = self.session['w'] // d[ok.COLUMN_MAZE]
        h = self.session['h'] // d[ok.ROW_MAZE]

        if d[ok.COMPOSITION_FRAME_WIDTH]:
            pdb.gimp_selection_all(j)
            pdb.gimp_selection_shrink(j, d[ok.COMPOSITION_FRAME_WIDTH])
            Sel.invert(j)
            sel = self.stat.save_render_sel()

        pdb.gimp_selection_none(j)
        pdb.gimp_context_set_foreground((0, 0, 0))
        pdb.gimp_context_set_background((255, 255, 255))
        pdb.plug_in_maze(j, z, w, h, 1, 0, d[ok.RANDOM_SEED], 0, 0)
        pdb.plug_in_edge(j, z, ed.AMOUNT_1, ed.NO_WRAP, ed.SOBEL)

        w = max(d[ok.LINE_WIDTH] // 2 - 1, 1)

        for _ in range(w):
            Lay.dilate(z)

        # Create a selection from the white pixels:
        pdb.gimp_by_color_select(
            z,
            (255, 255, 255),
            cs.THRESHOLD_0,
            fu.CHANNEL_OP_REPLACE,
            cs.YES_ANTIALIAS,
            cs.NO_FEATHER,
            cs.FEATHER_RADIUS_0,
            cs.NO_SAMPLE_MERGED
        )
        Sel.load(j, frame_sel, option=fu.CHANNEL_OP_ADD)
        Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_image_remove_layer(j, z)
