#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import (
    CaptionKey as ck,
    ForWidget as fw,
    StripeKey as st,
    UIKey
)
from roller_one_preset import Preset
from roller_one_tip import Tip
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_button import RollerColorButton
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_radio import RollerRadioList
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable
import gtk

LABEL = "No Stripe", "Caption Stripe"


class PortStripe(Port):
    """Provide widgets for defining a caption background stripe."""

    def __init__(self, d, g):
        """
        Create the port.

        g: OptionButton
            Has values.
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self._d = g.get_value()
        self._button = g
        self.stat = g.stat
        Port.__init__(self, d)

    def _draw_stripe_group(self, g):
        """
        Draw the stripe options.

        g: GTK container
            to receive group
        """
        self.stripe_box = g
        d = dict(
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
        )
        q = (
            [
                "Opacity:",
                RollerSlider,
                dict(
                    d,
                    key=st.OPACITY,
                    limit=(.0, 100.),
                    precision=1
                )
            ],
            [
                "Height:",
                RollerSlider,
                dict(
                    d,
                    key=st.HEIGHT,
                    limit=(1., 2.),
                    precision=2,
                    tooltip=Tip.STRIPE_HEIGHT
                )
            ],
            [
                "Blur Behind:",
                RollerSlider,
                dict(
                    d,
                    key=st.BLUR_BEHIND,
                    limit=(0, 500)
                )
            ],
            [
                "Color:",
                RollerColorButton,
                dict(d, key=st.COLOR)
            ]
        )
        d = RollerTable.create(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        self.controls += [d[i] for i in d]
        self._blur_behind = d[st.BLUR_BEHIND]
        g = self._opacity = d[st.OPACITY]
        g.dependent_widget = [d[i] for i in d if i != st.OPACITY]
        g.attach_dependent(
            [self.on_opacity_change],
            signal='value-changed'
        )

    def _draw_choices(self, g):
        """
        Draw the choices group.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        box = RollerBox(
            gtk.VBox,
            align=(1, 1, 1, 1),
            padding=(w // 2, w, 0, 0)
        )

        g.add(box)

        g = self._radio_list = RollerRadioList(
            container=box,
            key=st.TYPE,
            labels=LABEL,
            on_widget_change=self._on_list_change,
            padding=(1, 0, w, w)
        )
        self.controls += [g]

    def _draw_options(self, g):
        """
        Create option groups that sync with the radio-list.

        g: VBox
            container for the groups
        """
        # for switch group box
        # Is affected by 'self.on_list_change':
        vbox = gtk.VBox()

        g.pack_start(vbox, expand=1)

        g1 = self._radio_list
        g1.switch_group_box = vbox
        group = (
            PortStripe._draw_none_group,
            self._draw_stripe_group
        )
        self.none_index = len(group) - 1
        for x, p in enumerate(group):
            vbox = gtk.VBox()

            g1.group_box.append(vbox)
            vbox.add(
                RollerLabel(
                    padding=(2, 0, 4, fw.MARGIN),
                    text=LABEL[x] + " Options:"
                )
            )
            p(vbox)

    @staticmethod
    def _draw_none_group(g):
        """
        Draw the none options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text="No caption stripe will be\n"
            "applied when this option is used."
        )
        g.pack_start(g1, expand=True)

    def _draw_preset_group(self, g):
        """
        Draw a preset group for the cell grid.

        g: VBox
            container for widgets
        """
        self.preset = Preset(
            container=g,
            key=ck.STRIPE,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_preset_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _on_list_change(self, *q):
        """
        Use to set the preset to undefined.

        q: iterable
            of arguments
        """
        self.on_list_change(*q)
        self.on_opacity_change()
        self.on_widget_change(self._radio_list)

    def do_accept(self, *_):
        """
        Accept the choice.

        Return: true
            The key-press is handled.
        """
        return self.do_accept_callback(self.preset.get_value())

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = (
            self._draw_choices,
            self._draw_options,
            self._draw_preset_group,
            self.draw_process_group
        )
        group_name = "Choose Stripe", "", "Stripe Preset", "Process"

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if group_name[x]:
                vbox.pack_start(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=group_name[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()

            if x in (0, 2):
                hbox = gtk.HBox()
                g.pack_start(hbox, expand=True)
            hbox.pack_start(box, expand=True)

        self.preset.widget_list = self.controls
        self.preset.load_preset(fw.UNDEFINED, self._d)
        self.stripe_box.connect('expose-event', self.on_opacity_change)

        a = Port.load_count
        Port.load_count = 0

        self.on_list_change(self._radio_list)
        Port.load_count = a

    def on_opacity_change(self, *_):
        """
        Call when opacity value changes.
        """
        g = self._opacity
        f = g.get_value()

        if not f:
            [i.hide() for i in g.dependent_widget]

        else:
            for i in g.dependent_widget:
                if i.key != st.BLUR_BEHIND:
                    i.show()
                else:
                    if f == 100.:
                        i.hide()

                    else:
                        i.show()

    def on_preset_change(self, g):
        """
        Call when a preset is loaded.

        g: RollerComboBox
            Is responsible.
            not used
        """
        self.on_list_change(self._radio_list)

    def on_widget_change(self, g):
        """
        Call when a widget is changed.

        g: Widget
            Is responsible.
        """
        if not Port.load_count:
            self.preset.preset_is_undefined()
