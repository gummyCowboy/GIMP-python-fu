#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import (
    PortKey,
    UIKey,
    WindowKey
)
from roller_port_image_choice import PortImageChoice
from roller_window import RollerWindow


class RWImageChoice(RollerWindow):
    """Is a GTK dialog with multiple options for assigning an image."""
    def __init__(self, g):
        """
        Create a window.

        g: OptionButton
            Has values.
        """
        d = {}
        self._button = g
        d[UIKey.STAT] = g.stat
        d[UIKey.WINDOW] = g.win.win
        d[UIKey.WINDOW_TITLE] = "Choose Image Source"
        d[UIKey.WINDOW_KEY] = WindowKey.IMAGE_CHOOSER

        RollerWindow.__init__(self, d)
        d.update(
            {
                UIKey.ON_ACCEPT: self.do_accept,
                UIKey.ON_CANCEL: self.do_cancel,
                UIKey.WINDOW: self,
                UIKey.PORT_KEY: PortKey.NOT_USED
            }
        )

        self.port = PortImageChoice(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()

    def do_cancel(self, *_):
        """
        Cancel the image-choice window.

        Return: true
            GTK, it is done.
        """
        return self.close()

    def do_accept(self, value):
        """
        Accept the image.

        value: string
            for image button

        Return: true
            GTK, it is done.
        """
        # the return on investment:
        self._button.set_value(value)
        # Exit:
        return self.close()
