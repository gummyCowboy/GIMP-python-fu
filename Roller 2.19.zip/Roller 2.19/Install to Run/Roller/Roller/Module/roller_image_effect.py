#!/usr/bin/env python
# -*- coding: utf-8 -*-
CORNER_TAPE = "Corner Tape"
KEY = 'key'
COLOR_PIPE = "Color Pipe"


class LayerKey:
    """Has keys used to identify layers."""
    BACKDROP_LIGHT = "Backdrop Light"
    BLURRED_BACKGROUND = "Blurred Background"
    BUMP = "Bump"
    CELL_BORDER = "Cell Border"
    CELL_CAPTION = "Cell Caption"
    CELL_FRINGE = "Cell Fringe"
    CELL_PLAQUE = "Cell Plaque"
    CELL_PLAQUE_BLUR_BEHIND = "Cell Plaque Blur Behind"
    CORNER_TAPE = CORNER_TAPE
    EDGE = "Edge"
    FILLER = "Filler"
    FORMAT = u"🌲 "
    FRAME = "Frame"
    FREE_CELL_BORDER = "Free-Range Cell Border"
    FREE_CELL_CAPTION = "Free-Range Cell Caption"
    FREE_CELL_FRINGE = "Free-Range Cell Fringe"
    FREE_CELL_PLAQUE = "Free-Range Cell Plaque"
    COLOR_PIPE = COLOR_PIPE
    IMAGE = "Image"
    IMAGE_BLUR_BEHIND = "Image Blur Behind"
    LAYER_BORDER = "Layer Border"
    LAYER_CAPTION = "Layer Caption"
    LAYER_FRINGE = "Layer Fringe"
    LAYER_PLAQUE = "Layer Plaque"
    LAYER_PLAQUE_BLUR_BEHIND = "Layer Plaque Blur Behind"
    METAL = "Metal"
    SHADOW = "Shadow"
    STAIN = "Stain"
    TRANSPARENCY = "Transparency"


class ImageEffect:
    """Has objects used by image-effects."""
    APPLY = "Apply"

    class Key:
        """Has keys that identify an image-effect. Are option types."""
        BALL_JOINT = "Ball Joint"
        BORDER_LINE = "Border Line"
        BRUSH_EDGE = "Brush Edge"
        BRUSH_PUNCH = "Brush Punch"
        CERAMIC_CHIP = "Ceramic Chip"
        CIRCLE_PUNCH = "Circle Punch"
        CLEAR_FRAME = "Clear Frame"
        COLORED_BOARD = "Colored Board"
        CORNER_TAPE = CORNER_TAPE
        CUTOUT_PLATE = "Cutout Plate"
        DROP_SHADOW = "Drop Shadow"
        FEATHER_REDUCTION = "Feather Reduction"
        FILL_LIGHT_SHADOW = "Fill Light Shadow"
        FRAME_GRADIENT = "Frame Gradient"
        GLASS_REVEAL = "Glass Reveal"
        GRADIENT_LEVEL = "Gradient Level"
        COLOR_PIPE = COLOR_PIPE
        IMAGE_EDGE_SHADOW = "Image Edge Shadow"
        IMAGE_EFFECT = "Image Effect"
        IMAGE_SHADOW = "Image Shadow"
        INLAY_SHADOW = "Inlay Shadow"
        JAGGED_EDGE = "Jagged Edge"
        KEY_LIGHT_SHADOW = "Key Light Shadow"
        LINE_FASHION = "Line Fashion"
        MAZE_MIRROR = "Maze Mirror"
        NO_EFFECT = "No Effect"
        PAINT_RUSH = "Paint Rush"
        RAD_WAVE = "Rad Wave"
        RAISED_MAZE = "Raised Maze"
        ROUNDED_EDGE = "Rounded Edge"
        SHADOW = "Shadow"
        SHADOW_PAIR = "Shadow Pair"
        SQUARE_PUNCH = "Square Punch"
        STAINED_GLASS = "Stained Glass"
        TRI_SHADOW = "Tri-Shadow"
        WIRE_FENCE = "Wire Fence"
        KEY_LIST = [
            BALL_JOINT,
            BORDER_LINE,
            BRUSH_EDGE,
            BRUSH_PUNCH,
            CERAMIC_CHIP,
            CIRCLE_PUNCH,
            CLEAR_FRAME,
            COLORED_BOARD,
            CORNER_TAPE,
            CUTOUT_PLATE,
            DROP_SHADOW,
            FEATHER_REDUCTION,
            FILL_LIGHT_SHADOW,
            FRAME_GRADIENT,
            GLASS_REVEAL,
            GRADIENT_LEVEL,
            COLOR_PIPE,
            IMAGE_EDGE_SHADOW,
            IMAGE_EFFECT,
            IMAGE_SHADOW,
            INLAY_SHADOW,
            JAGGED_EDGE,
            KEY_LIGHT_SHADOW,
            LINE_FASHION,
            MAZE_MIRROR,
            NO_EFFECT,
            PAINT_RUSH,
            RAD_WAVE,
            RAISED_MAZE,
            ROUNDED_EDGE,
            SHADOW,
            SHADOW_PAIR,
            SQUARE_PUNCH,
            STAINED_GLASS,
            TRI_SHADOW,
            WIRE_FENCE
        ]

    # Identify effects that need to set the 'caster_key'
    # item in the shadow-effect dictionary when doing a render:
    CASTER_EFFECT = (
        Key.DROP_SHADOW,
        Key.FILL_LIGHT_SHADOW,
        Key.IMAGE_EDGE_SHADOW,
        Key.IMAGE_SHADOW,
        Key.INLAY_SHADOW,
        Key.KEY_LIGHT_SHADOW,
        Key.ROUNDED_EDGE
    )

    # Has layer id/key(s) that shadow-effects
    # need to make a unified-shadow-unit.
    # Each effect's shadow needs an entry:
    CAST = 'cast'

    EFFECT_STEPS = 'effect_steps'

    # Use for effects that make a copy of the image layer:
    IS_HIDE = 'is_hide'

    # Use with preview function to remove previous preview layers.
    # The key is an image effect key. The value is a tuple of
    # layer identifiers. Layers are identified with a layer key
    # and an entry in the LAYER_DICT:
    LAYERS = 'layers'

    nk = LayerKey
    K, K1, K2, K3 = (
        Key.FRAME_GRADIENT,
        Key.KEY_LIGHT_SHADOW,
        Key.FILL_LIGHT_SHADOW,
        Key.IMAGE_EDGE_SHADOW
    )
    FRAME = {
        CAST: (nk.IMAGE, nk.FRAME),
        EFFECT_STEPS: [K1, K2, K3],
        IS_HIDE: 0,
        LAYERS: (nk.FRAME,),
    }
    METAL = {
        CAST: (nk.IMAGE, nk.FRAME),
        EFFECT_STEPS: [K, K1, K2, K3],
        IS_HIDE: 0,
        LAYERS: (nk.FRAME, nk.BUMP),
    }
    NO_EFFECT = {
        CAST: (),
        EFFECT_STEPS: [],
        IS_HIDE: 0,
        LAYERS: (),
    }
    PROPERTY = {
        Key.BALL_JOINT: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS:  (Key.BALL_JOINT, nk.FRAME),
        },
        Key.BORDER_LINE: METAL,
        Key.BRUSH_EDGE: {
            CAST: (nk.IMAGE, nk.TRANSPARENCY),
            EFFECT_STEPS: [K1, K2, K3],
            IS_HIDE: 0,
            LAYERS:  (nk.TRANSPARENCY,),
        },
        Key.BRUSH_PUNCH: METAL,
        Key.CERAMIC_CHIP: {
            CAST: (nk.FILLER, nk.FRAME, nk.IMAGE),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.FRAME, nk.FILLER),
        },
        Key.CIRCLE_PUNCH: METAL,
        Key.CLEAR_FRAME: {
            CAST: (nk.IMAGE, nk.TRANSPARENCY),
            EFFECT_STEPS: [K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.TRANSPARENCY,),
        },
        Key.COLOR_PIPE: {
            CAST: (nk.IMAGE, nk.COLOR_PIPE),
            EFFECT_STEPS: [K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.COLOR_PIPE,),
        },
        Key.COLORED_BOARD: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K1, K2],
            IS_HIDE: 0,
            LAYERS:  (nk.FRAME,),
        },
        Key.CORNER_TAPE: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS:  (Key.CORNER_TAPE, Key.DROP_SHADOW),
        },
        Key.CUTOUT_PLATE: FRAME,
        Key.DROP_SHADOW: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.DROP_SHADOW,),
        },
        Key.FEATHER_REDUCTION: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 1,
            LAYERS: (Key.FEATHER_REDUCTION,),
        },
        Key.FILL_LIGHT_SHADOW: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.FILL_LIGHT_SHADOW,),
        },
        Key.FRAME_GRADIENT: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (nk.BACKDROP_LIGHT,),
        },
        Key.GLASS_REVEAL: {
            CAST: (nk.IMAGE, nk.TRANSPARENCY),
            EFFECT_STEPS: [K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.TRANSPARENCY,),
        },
        Key.GRADIENT_LEVEL: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.FRAME,),
        },
        Key.IMAGE_EDGE_SHADOW: {
            CAST: [],
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.IMAGE_EDGE_SHADOW,),
        },
        Key.IMAGE_EFFECT: NO_EFFECT,
        Key.IMAGE_SHADOW: {
            CAST: (nk.IMAGE,),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.IMAGE_SHADOW,),
        },
        Key.INLAY_SHADOW: {
            CAST: (nk.IMAGE,),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.INLAY_SHADOW,),
        },
        Key.JAGGED_EDGE: {
            CAST: (nk.IMAGE,),
            EFFECT_STEPS: [],
            IS_HIDE: 1,
            LAYERS: (Key.JAGGED_EDGE, nk.SHADOW),
        },
        # Set CAST for main effect of Shadow Pair and Tri-Shadow:
        Key.KEY_LIGHT_SHADOW: {
            CAST: (nk.IMAGE,),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.KEY_LIGHT_SHADOW,),
        },
        Key.LINE_FASHION: METAL,
        Key.MAZE_MIRROR: METAL,
        Key.NO_EFFECT: NO_EFFECT,
        Key.PAINT_RUSH: {
            CAST: (nk.IMAGE,),
            EFFECT_STEPS: [K1, K2],
            IS_HIDE: 0,
            LAYERS: (nk.FRAME,),
        },
        Key.RAD_WAVE: METAL,
        Key.RAISED_MAZE: METAL,
        Key.ROUNDED_EDGE: {
            CAST: (nk.IMAGE,),
            EFFECT_STEPS: [K1, K2],
            IS_HIDE: 0,
            LAYERS: (nk.FRAME,),
        },
        Key.SHADOW: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (),
        },
        Key.SHADOW_PAIR: {
            CAST: (),
            EFFECT_STEPS: [K1, K2],
            IS_HIDE: 0,
            LAYERS: (K1, K2)
        },
        Key.SQUARE_PUNCH: METAL,
        Key.STAINED_GLASS: {
            CAST: (nk.IMAGE, nk.FRAME, nk.TRANSPARENCY),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.TRANSPARENCY, nk.FRAME,),
        },
        Key.TRI_SHADOW: {
            CAST: (),
            EFFECT_STEPS: [K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (K1, K2, K3)
        },
        Key.WIRE_FENCE: METAL
    }

    # effect categories:
    MAIN = (
        Key.BALL_JOINT,
        Key.BORDER_LINE,
        Key.BRUSH_EDGE,
        Key.BRUSH_PUNCH,
        Key.CERAMIC_CHIP,
        Key.CIRCLE_PUNCH,
        Key.CLEAR_FRAME,
        Key.COLOR_PIPE,
        Key.COLORED_BOARD,
        Key.CORNER_TAPE,
        Key.CUTOUT_PLATE,
        Key.FEATHER_REDUCTION,
        Key.GLASS_REVEAL,
        Key.GRADIENT_LEVEL,
        Key.IMAGE_SHADOW,
        Key.INLAY_SHADOW,
        Key.JAGGED_EDGE,
        Key.LINE_FASHION,
        Key.MAZE_MIRROR,
        Key.NO_EFFECT,
        Key.PAINT_RUSH,
        Key.RAD_WAVE,
        Key.RAISED_MAZE,
        Key.ROUNDED_EDGE,
        Key.SHADOW_PAIR,
        Key.SQUARE_PUNCH,
        Key.STAINED_GLASS,
        Key.TRI_SHADOW,
        Key.WIRE_FENCE
    )

    # Use with effect options in PortOption:
    SHADOW_CHOICE = "None", Key.DROP_SHADOW, Key.INLAY_SHADOW

    # These image effects duplicate the image layer as part of their
    # function. The duplicate image layer is to be deleted after a render:
    IMAGE_DUPLICATOR = Key.JAGGED_EDGE, Key.FEATHER_REDUCTION


class LayerId:
    """
    Pair layer-key names with a unicode-key symbol.

    Use for fast layer searches.
    """
    KEY = {
        ImageEffect.Key.COLOR_PIPE: u"+",
        ImageEffect.Key.CORNER_TAPE: u"`",
        ImageEffect.Key.DROP_SHADOW: u"☁",
        ImageEffect.Key.FEATHER_REDUCTION: u"☘",
        ImageEffect.Key.FILL_LIGHT_SHADOW: u"⚫",
        ImageEffect.Key.IMAGE_EDGE_SHADOW: u"☾",
        ImageEffect.Key.IMAGE_SHADOW: u"✪",
        ImageEffect.Key.INLAY_SHADOW: u"★",
        ImageEffect.Key.JAGGED_EDGE: u"❀",
        ImageEffect.Key.KEY_LIGHT_SHADOW: u"⚪",
        LayerKey.BACKDROP_LIGHT: u"☂",
        LayerKey.BUMP: u"¤",
        LayerKey.CELL_BORDER: u".",
        LayerKey.LAYER_BORDER: u"!",
        LayerKey.CELL_CAPTION: u"©",
        LayerKey.CELL_FRINGE: u"◊",
        LayerKey.CELL_PLAQUE: u"☢",
        LayerKey.CELL_PLAQUE_BLUR_BEHIND: u"✺",
        LayerKey.EDGE: u"☠",
        LayerKey.FILLER: u"-",
        LayerKey.FRAME: u"￭",
        LayerKey.FREE_CELL_BORDER: u"=",
        LayerKey.FREE_CELL_CAPTION: u"♔",
        LayerKey.FREE_CELL_FRINGE: u"✸",
        LayerKey.FREE_CELL_PLAQUE: u"º",
        LayerKey.IMAGE: u"❑",
        LayerKey.IMAGE_BLUR_BEHIND: u"□",
        LayerKey.LAYER_CAPTION: u"®",
        LayerKey.LAYER_FRINGE: u"✬",
        LayerKey.LAYER_PLAQUE: u"♦",
        LayerKey.LAYER_PLAQUE_BLUR_BEHIND: u"∞",
        LayerKey.METAL: u"❤",
        LayerKey.SHADOW: u"♠",
        LayerKey.STAIN: u"☀",
        LayerKey.TRANSPARENCY: u"❍"

    }
