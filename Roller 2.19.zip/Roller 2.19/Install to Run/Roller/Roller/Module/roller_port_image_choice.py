#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_image import RollerImage
from roller_one_base import Comm
from roller_one_constant import (
    ForFormat as ff,
    ForWidget as fw,
    ImageKey as ik,
    OptionKey as ok,
    UIKey
)
from roller_one_tip import Tip
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_button import RollerButton
from roller_widget_check_button import RollerCheckButton
from roller_widget_combo import RollerComboBox
from roller_widget_eventbox import RollerEventBox
from roller_widget_entry import RollerEntry
from roller_widget_label import RollerLabel
from roller_widget_radio import RadioBox, RollerRadioList
from roller_widget_table import RollerTable
import gtk
import os

AS_LAYERS = ff.Image.Type.AS_LAYERS_LIST
FILE_ONLY = \
    "The selected item is a folder, " \
    "and the entry is for an image file only."

FOLDER_INDEX = 6
FOLDER_ONLY = \
    "The selected item is a not folder, " \
    "and the entry is for folders only. "

HAS_FORMAT = ff.Image.Type.HAS_FORMAT
HAS_FORMAT_LABEL = (
    "Next Index",
    "Previous Index",
    "Fluctuate Index",
    "Numeric Sequence",
    "Image Name",
    "File",
    "Folder",
    "No Image"
)
NO_FORMAT_LABEL = (
    "Numeric Sequence",
    "Image Name",
    "File",
    "No Image"
)
IMAGE_NAME = 'image_name'
NUMERIC = 'numeric'


class PortImageChoice(Port):
    """Offer different methods for assigning images to cells."""

    def __init__(self, d, g):
        """
        Create the port.

        d: dict
            Has port init values.

        g: OptionButton
            Has values.
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self._file_filter = self._layer_button = None
        self._order = self._autocrop = self._layer_box = None
        self._button = g
        self.d = g.get_value()
        self._has_format = self.d[ik.HAS_FORMAT]
        Port.__init__(self, d)

    def _draw_file_entry(self, g):
        """
        Draw the file entry option.

        g: GTK container
            to receive group
        """
        d = dict(
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change
        )
        q = (
            [
                "File:",
                RollerEntry,
                dict(d, chars=24, key='file')
            ],
            [
                "",
                RollerButton,
                dict(
                    d,
                    on_widget_change=self._get_file_entry_item,
                    text="Select File…"
                )
            ]
        )
        e = RollerTable.create(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        self._file_entry = e['file']
        self.keep([e[i] for i in e])

    def _draw_fluctuate_group(self, g):
        """
        Draw the Fluctuate Index options.

        g: GTK container
            to receive group
        """
        q = (
            [
                "Fluctuate Index Type:",
                RadioBox,
                dict(
                    key='flux',
                    labels=(
                        ff.Image.FLUCTUATE_INCREMENT,
                        ff.Image.FLUCTUATE_DECREMENT
                    ),
                    on_widget_change=self.on_widget_change,
                    stat=self.stat
                )
            ],
        )
        e = RollerTable.create(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        self._fluctuate_radio = e['flux'].radio_group

        e['flux'].buttons[0].set_tooltip_text(Tip.IMAGE_CHOICE_FLUX_INC)
        e['flux'].buttons[1].set_tooltip_text(Tip.IMAGE_CHOICE_FLUX_DEC)
        self.keep([e[i] for i in e])

    def _draw_folder_entry(self, g):
        """
        Draw the folder entry option.

        g: GTK container
            to receive group
        """
        d = dict(on_key_press=self.on_key_press)
        e = dict(d, on_widget_change=self.on_widget_change)
        q = (
            [
                "Folder:",
                RollerEntry,
                dict(e, chars=36, key='folder')
            ],
            [
                "",
                RollerButton,
                dict(
                    on_widget_change=self._get_folder_entry_item,
                    text="Select Folder…"
                )
            ],
            [
                "File Filter:",
                RollerEntry,
                dict(e, chars=36, key='filter')
            ],
            [
                "File Order:",
                RadioBox,
                dict(
                    key='folder_order',
                    labels=ff.Image.FOLDER_ORDER_LIST,
                    on_key_press=self.on_key_press,
                    on_widget_change=self.on_widget_change,
                    stat=self.stat,
                    tooltip=Tip.IMAGE_CHOICE_ORDER
                ),
            ]
        )
        e = RollerTable.create(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        self._folder_entry = e['folder']
        self._file_filter = e['filter']
        self._file_order = e['folder_order']

        self._file_filter.set_value(self.d[ik.FILTER])
        self._file_order.set_value(self.d[ik.FOLDER_ORDER])
        self.keep([e[i] for i in e])

    def _draw_image_choices(self, g):
        """
        Draw the image choices group.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        box = RollerBox(
            gtk.VBox,
            align=(1, 1, 1, 1),
            padding=(w // 2, w, 0, 0)
        )
        label = HAS_FORMAT_LABEL if self._has_format else NO_FORMAT_LABEL

        g.add(box)

        g = self._radio_list = RollerRadioList(
            container=box,
            key='radio list',
            labels=label,
            on_widget_change=self._on_list_change,
            padding=(1, 0, w, w)
        )
        self.keep(g.buttons)

    def _draw_image_name_group(self, g):
        """
        Draw the image name group.

        g: GTK container
            to receive group
        """
        q = (
            [
                "Select Image Name:",
                RollerComboBox,
                dict(
                    combo_list=RollerImage.image_names,
                    key=IMAGE_NAME,
                    on_key_press=self.on_key_press,
                    on_widget_change=self.on_widget_change
                ),
            ],
        )
        d = RollerTable.create(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        self._image_names = d[IMAGE_NAME]

        d[IMAGE_NAME].set_value(RollerImage.image_names[0])
        self.keep([d[i] for i in d])

    def _draw_layer_group(self, g):
        """
        Draw the layer group.

        g: GTK container
            to receive group
        """
        self.reduce_color()

        g1 = gtk.VBox()
        box = self._layer_box = RollerEventBox(self.color)

        box.add(g1)
        g.pack_end(box, expand=False)
        g1.add(
            RollerLabel(
                padding=(2, 0, 4, fw.MARGIN),
                text="Image Layers Options:"
            )
        )

        q = (
            [
                "Decompose Image:",
                RollerCheckButton,
                dict(
                    key='layer',
                    on_key_press=self.on_key_press,
                    on_widget_change=self.on_widget_change,
                    text="As Layers",
                    tooltip=Tip.IMAGE_CHOICE_LAYERS
                ),
            ],
            [
                "Autocrop Layer:",
                RollerCheckButton,
                dict(
                    key='autocrop',
                    on_key_press=self.on_key_press,
                    on_widget_change=self.on_widget_change,
                    text="Autocrop"
                ),
            ],
            [
                "Layer Order:",
                RadioBox,
                dict(
                    key='order',
                    labels=ff.Image.LAYER_ORDER_LIST,
                    on_key_press=self.on_key_press,
                    on_widget_change=self.on_widget_change,
                    stat=self.stat,
                    tooltip=Tip.IMAGE_CHOICE_ORDER
                ),
            ]
        )
        e = RollerTable.create(
            bottom_pad=fw.MARGIN,
            color=self.color,
            container=g1,
            q=q
        )
        self._layer_button = e['layer']
        self._autocrop = e['autocrop']
        self._order = e['order']

        self._layer_button.set_value(self.d[ik.AS_LAYERS])
        self._autocrop.set_value(self.d[ik.AUTOCROP])
        self._order.set_value(self.d[ik.LAYER_ORDER])
        self.keep([e[i] for i in e])

    def _draw_next_group(self, g):
        """
        Draw the Next options.

        g: GTK container
            to receive group
        """
        q = (
            [
                "Next Index Type:",
                RadioBox,
                dict(
                    key='next',
                    labels=(ff.Image.NEXT_LINEAR, ff.Image.NEXT_CIRCULAR),
                    on_key_press=self.on_key_press,
                    on_widget_change=self.on_widget_change,
                    stat=self.stat
                )
            ],
        )
        d = RollerTable.create(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        self._next_radio = d['next'].radio_group

        d['next'].buttons[0].set_tooltip_text(Tip.IMAGE_CHOICE_NEXT_LINEAR)
        d['next'].buttons[1].set_tooltip_text(Tip.IMAGE_CHOICE_NEXT_CIRCULAR)
        self.keep([d[i] for i in d])

    @staticmethod
    def _draw_none_group(g):
        """
        Draw the none options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text="No image will be provided\n"
            "when this option is used."
        )
        g.pack_start(g1, expand=True)

    def _draw_numeric_group(self, g):
        """
        Draw the numeric group.

        g: GTK container
            to receive group
        """
        q = (
            [
                "Select Image Index:",
                RollerComboBox,
                dict(
                    combo_list=RollerImage.relative_names,
                    key=NUMERIC,
                    on_widget_change=self.on_widget_change
                )
            ],
        )
        d = RollerTable.create(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        self._numeric_names = d[NUMERIC]

        d[NUMERIC].set_value(RollerImage.relative_names[0])
        self.keep([d[i] for i in d])

    def _draw_options(self, g):
        """
        Create option groups that sync with the radio-list.

        g : VBox
            container for the groups
        """
        g1 = self._radio_list
        g1.switch_group_box = g
        has_format_group = (
            self._draw_next_group,
            self._draw_previous_group,
            self._draw_fluctuate_group,
            self._draw_numeric_group,
            self._draw_image_name_group,
            self._draw_file_entry,
            self._draw_folder_entry,
            PortImageChoice._draw_none_group
        )
        no_format_group = (
            self._draw_numeric_group,
            self._draw_image_name_group,
            self._draw_file_entry,
            PortImageChoice._draw_none_group
        )
        group = has_format_group if self._has_format else no_format_group
        label = HAS_FORMAT_LABEL if self._has_format else NO_FORMAT_LABEL
        self.none_index = len(group) - 1

        for x, p in enumerate(group):
            vbox = gtk.VBox()

            g1.group_box.append(vbox)

            if label[x]:
                vbox.add(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=label[x] + " Options:"
                    )
                )
            p(vbox)
        if self._has_format:
            self._draw_layer_group(g)

    def _draw_previous_group(self, g):
        """
        Draw the Previous options.

        g: GTK container
            to receive group
        """
        q = (
            [
                "Previous Index Type:",
                RadioBox,
                dict(
                    key='previous',
                    labels=(
                        ff.Image.PREVIOUS_LINEAR,
                        ff.Image.PREVIOUS_CIRCULAR
                    ),
                    on_widget_change=self.on_widget_change,
                    stat=self.stat
                )
            ],
        )
        d = RollerTable.create(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        g = d['previous']
        self._previous_radio = g.radio_group

        g.buttons[0].set_tooltip_text(Tip.IMAGE_CHOICE_PRE_LINEAR)
        g.buttons[1].set_tooltip_text(Tip.IMAGE_CHOICE_PRE_CIRCULAR)
        self.keep([d[i] for i in d])

    def _get_file_entry_item(self, *_):
        """Open a file chooser dialog."""
        dialog = gtk.FileChooserDialog(
            title="Choose Image File",
            parent=self.roller_window.win,
            action=gtk.FILE_CHOOSER_ACTION_OPEN,
            buttons=(
                "Cancel",
                gtk.RESPONSE_CANCEL,
                "Accept",
                gtk.RESPONSE_ACCEPT
            )
        )
        file_filter = gtk.FileFilter()

        file_filter.set_name("Images")

        for i in ff.Image.EXTENSION:
            file_filter.add_pattern("*" + i)

        dialog.add_filter(file_filter)

        response = dialog.run()

        # "-3" is the enum for accept:
        n = dialog.get_filename() if response == -3 else ""

        dialog.destroy()
        if n:
            if not os.path.isfile(n):
                Comm.pop_up(
                    self.roller_window.win,
                    1,
                    FILE_ONLY.format(n),
                    "Wrong Item Type"
                )
                n = ""
            if n:
                self._file_entry.set_value(n)

    def _get_folder_entry_item(self, *_):
        """Open a folder chooser dialog."""
        action = gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER
        dialog = gtk.FileChooserDialog(
            title="Choose Image Folder",
            parent=self.roller_window.win,
            action=action,
            buttons=(
                "Cancel",
                gtk.RESPONSE_CANCEL,
                "Accept",
                gtk.RESPONSE_ACCEPT
            )
        )
        response = dialog.run()

        # "-3" is the enum for accept:
        n = dialog.get_filename() if response == -3 else ""

        dialog.destroy()
        if n:
            if not os.path.isdir(n):
                Comm.pop_up(
                    self.roller_window.win,
                    1,
                    FOLDER_ONLY.format(n),
                    "Wrong Item Type"
                )
                n = ""
            if n:
                self._folder_entry.set_value(n)

    def _init_image_choice(self):
        """Initialize the image choice radio group."""
        d = self.d
        n = d[ik.IMAGE_REF]
        n1 = d[ik.TYPE]

        if n1 == ff.Image.Type.NEXT:
            # Create a change event:
            self.on_list_change(self._radio_list)

        if d[ik.HAS_FORMAT]:
            x = HAS_FORMAT.index(n1)
            p = (
                self._init_options_next,
                self._init_options_previous,
                self._init_options_fluctuate,
                self._init_options_numeric,
                self._init_options_image_names,
                self._init_options_file_entry,
                self._init_options_folder_entry,
                lambda *args, **kwargs: None
            )[x]

        else:
            x = ff.Image.Type.NO_FORMAT.index(n1)
            p = (
                self._init_options_numeric,
                self._init_options_image_names,
                self._init_options_file_entry,
                lambda *args, **kwargs: None
            )[x]

        p(n)
        self._radio_list.set_value(x)

    def _init_options_file_entry(self, n):
        """
        Set the display value for the file entry.

        n: string
            entry value
        """
        self._file_entry.set_value(n)

    def _init_options_fluctuate(self, n):
        """
        Select a Fluctuate-type radio button.

        n: string
            next type
        """
        x = ff.Image.FLUCTUATE_TYPE.index(n)
        self._fluctuate_radio.set_value(x)

    def _init_options_folder_entry(self, n):
        """
        Set the display value for the file entry.

        n: string
            folder path
        """
        self._folder_entry.set_value(n)

    def _init_options_image_names(self, n):
        """
        Select an image name.

        n: string
            combobox item
        """
        self._image_names.set_value(n)

    def _init_options_next(self, n):
        """
        Select a Next-type radio button.

        n: string
            next type
        """
        x = ff.Image.NEXT_TYPE.index(n)
        self._next_radio.set_value(x)

    def _init_options_previous(self, n):
        """
        Select a Previous-type radio button.

        n: string
            previous type
        """
        self._previous_radio.set_value(ff.Image.PREVIOUS_TYPE.index(n))

    def _init_options_numeric(self, n):
        """
        Select an numeric index.

        n: string
            combobox item
        """
        self._numeric_names.set_value(n)

    def _get_file_entry(self):
        """
        Call to get the file entry value.

        Return: string
            from the file entry
        """
        n = self._file_entry.get_value()

        if not n:
            return ok.NONE
        return n

    def _get_fluctuate(self):
        """
        Call to get the Fluctuate setting.

        Return: string
            the Fluctuate radio button choice.
        """
        x = self._fluctuate_radio.get_value()
        return ff.Image.FLUCTUATE_TYPE[x]

    def _get_folder_entry(self):
        """
        Call to get the selected folder entry value.

        Return: string
            folder path
        """
        return self._folder_entry.get_value()

    def _get_image_names(self):
        """
        Call to get the Image Name setting.

        Return: string
            the Image Name combobox choice.
        """
        return self._image_names.get_value()

    def _get_next(self):
        """
        Call to get the Next setting.

        Return: string
            the Next radio button choice.
        """
        x = self._next_radio.get_value()
        return ff.Image.NEXT_TYPE[x]

    @staticmethod
    def _get_none():
        """
        Call to get the None identifier.

        Return: string
            'None' identifier
        """
        return ok.NONE

    def _get_numeric(self):
        """
        Call to get the Numeric Name setting.

        Return: string
            the Numeric Name combobox choice.
        """
        return self._numeric_names.get_value()

    def _get_previous(self):
        """
        Call to get the Previous setting.

        Return: string
            the Previous radio button choice.
        """
        x = self._previous_radio.get_value()
        return ff.Image.PREVIOUS_TYPE[x]

    def _on_list_change(self, *q):
        """
        Use to set the preset to undefined.

        q: iterable
            of arguments
        """
        self.on_list_change(*q)
        self._update_layer_box()
        self.on_widget_change(self._radio_list)

    @staticmethod
    def _set_combo_tooltip(g):
        """
        Set the tooltip for numeric and named image choices.

        g: Widget
            Is responsible.
        """
        n = g.get_value()

        if g.key == NUMERIC:
            if n != ok.NONE:
                g.set_tooltip_text(Tip.IMAGE_CHOICE_NUMERIC)
        elif g.key == IMAGE_NAME:
            if n != ok.NONE:
                g.set_tooltip_text(Tip.IMAGE_CHOICE_NAME)

    def _update_layer_box(self, *_):
        """Update the visibility of the table option group."""
        if self._layer_box:
            if HAS_FORMAT[self._radio_list.get_value()] in AS_LAYERS:
                self._layer_box.show()
                self.roller_window.resize()
            else:
                self._layer_box.hide()

    def _update_layer_dependent(self, *_):
        """Update the visibility of the layer dependents."""
        if self._layer_box:
            if HAS_FORMAT[self._radio_list.get_value()] in AS_LAYERS:
                if self._layer_button.get_value():
                    self._autocrop.show()
                    self._order.show()

                else:
                    self._autocrop.hide()
                    self._order.hide()
                self.roller_window.resize()

    def _update_window_size(self, *_):
        """Update the window size. Call from an signal."""
        self.roller_window.resize()
        self.box.disconnect(self.box_handler)

    def do_accept(self, *_):
        """
        Accept the image.

        Return: true
            The key-press is handled.
        """
        x = self._radio_list.get_value()

        if self._has_format:
            n = (
                self._get_next,
                self._get_previous,
                self._get_fluctuate,
                self._get_numeric,
                self._get_image_names,
                self._get_file_entry,
                self._get_folder_entry,
                PortImageChoice._get_none
            )[x]()
            choice = HAS_FORMAT[x]

        else:
            n = (
                self._get_numeric,
                self._get_image_names,
                self._get_file_entry,
                PortImageChoice._get_none
            )[x]()
            choice = ff.Image.Type.NO_FORMAT[x]

        n1 = self._file_filter.get_value() if self._file_filter else ""

        if self._layer_button:
            a = self._layer_button.get_value()
            b = self._autocrop.get_value()
            c = self._order.get_value()
            a1 = self._file_order.get_value()

        else:
            a = 0
            b = self.d[ik.AUTOCROP]
            c = self.d[ik.LAYER_ORDER]
            a1 = self.d[ik.FOLDER_ORDER]
        return self.do_accept_callback(
            {
                ik.AS_LAYERS: a,
                ik.AUTOCROP: b,
                ik.FILTER: n1,
                ik.FOLDER_ORDER: a1,
                ik.HAS_FORMAT: self.d[ik.HAS_FORMAT],
                ik.IMAGE_REF: n,
                ik.LAYER_ORDER: c,
                ik.TYPE: choice
            }
        )

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = (
            self._draw_image_choices,
            self._draw_options,
            self.draw_process_group
        )
        n = "Choose an Image Source", "", ""

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if n[x]:
                vbox.pack_start(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=n[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()

            if x == 0:
                hbox = gtk.HBox()
                g.pack_start(hbox, expand=False)

            if x == 1:
                self.box = box

            if x < 2:
                hbox.pack_start(box, expand=False)
            else:
                g.pack_start(box, expand=False)

        a = Port.load_count
        Port.load_count = 0

        if self._layer_box:
            self._layer_box.connect('expose-event', self._update_layer_box)
            self._layer_box.connect(
                'expose-event',
                self._update_layer_dependent
            )

        self._init_image_choice()
        self.on_list_change(self._radio_list)

        self.box_handler = self.box.connect(
            'expose_event',
            self._update_window_size
        )

        Port.load_count = a
        if self._has_format:
            self._next_radio.buttons[1].widget.show_all()

    def on_widget_change(self, g):
        """
        Call when a widget is changed.

        g: Widget
            Is responsible.
        """
        if not Port.load_count:
            self._set_combo_tooltip(g)
            if g is self._layer_button:
                self._update_layer_dependent(self, g)
