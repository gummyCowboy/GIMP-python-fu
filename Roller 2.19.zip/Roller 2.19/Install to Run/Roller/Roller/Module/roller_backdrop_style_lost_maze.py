#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_style_gradient_fill import GradientFill
from roller_one import One
from roller_one_constant import ForGradient as fg, OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class LostMaze:
    """Use a maze to create regions, a border, and grid lines."""

    def __init__(self, one):
        """
        Create a Lost Maze backdrop-style.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        self.session = one.session
        d = one.d
        self.option_key = one.k
        j = stat.render.image
        self.group = Lay.group(j, one.k, parent=one.z.parent)
        z = maze_layer = Lay.add(j, one.k, parent=self.group)
        w = one.session['w'] // d[ok.COLUMN_MAZE]
        h = one.session['h'] // d[ok.ROW_MAZE]

        # Preserve:
        foreground = pdb.gimp_context_get_foreground()
        background = pdb.gimp_context_get_background()

        pdb.gimp_context_set_foreground((0, 0, 0))
        pdb.gimp_context_set_background((255, 255, 255))
        pdb.plug_in_maze(j, z, w, h, 1, 0, d[ok.RANDOM_SEED], 0, 0)

        z = Lay.clone(z)

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        alpha_layer = Lay.clone(z)
        alpha_layer.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.gimp_selection_none(j)
        pdb.plug_in_edge(j, maze_layer, 1., 0, 0)

        # Expand the border:
        for _ in range(2):
            Lay.dilate(maze_layer)

        pdb.plug_in_colortoalpha(j, maze_layer, (0, 0, 0))

        # horizontal lines:
        h1 = min(max(6, h // 5), one.session['h'])

        LostMaze._do_grid(
            stat,
            z,
            (h1, h1 + 1, 0, (0, 0, 0), 255),
            is_vertical=False
        )
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        e = self.e = deepcopy(fg.LINEAR_DICT)

        e.update(d)

        e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
            RenderHub.get_gradient_fractions(d[ok.GRADIENT_ANGLE])

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        Sel.item(z)

        sel = self.stat.save_render_sel()

        pdb.gimp_selection_none(j)
        pdb.gimp_image_set_active_layer(j, z)
        self._do_gradient()

        z = pdb.gimp_image_get_active_drawable(j)

        Sel.isolate(z, sel)
        RenderHub.do_stylish_shadow(
            stat,
            z,
            blur=8.,
            intensity=140.,
            offset_x=3,
            offset_y=3
        )
        pdb.gimp_selection_none(j)

        # vertical lines:
        z = Lay.add(
            j,
            one.k,
            parent=self.group,
            offset=len(self.group.layers) + 1
        )

        Lay.color_fill(z, (255, 255, 255))
        pdb.gimp_selection_all(j)

        v1 = min(max(12, w // 12), one.session['w'])

        LostMaze._do_grid(stat, z, (v1, v1 + 1, 0, (0, 0, 0), 255))
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        RenderHub.do_stylish_shadow(
            stat,
            z,
            blur=10,
            intensity=200.,
            is_inlay=True
        )
        RenderHub.do_stylish_shadow(stat, z, blur=10, intensity=200.)

        # background:
        z = Lay.add(
            j,
            one.k,
            parent=self.group,
            offset=len(self.group.layers) + 1
        )
        z.opacity = 50.

        pdb.gimp_image_set_active_layer(j, z)
        self._do_gradient()
        pdb.gimp_image_reorder_item(j, alpha_layer, self.group, 4)
        Gegl.blur(alpha_layer, 500)
        Gegl.blur(one.z, 500)

        # grain effect:
        z = Lay.clone(alpha_layer)

        pdb.gimp_image_reorder_item(j, z, self.group, 6)

        z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
        z.opacity = 100.
        pdb.gimp_drawable_invert(z, 0)

        # Restore:
        pdb.gimp_context_set_foreground(foreground)
        pdb.gimp_context_set_background(background)

    def _do_gradient(self):
        """
        Draw a gradient.

        Use 'self.e' to pass gradient options.
        """
        GradientFill(
            One(
                d=self.e,
                session=self.session,
                stat=self.stat,
                z=self.stat.render.image.active_layer
            )
        )

    @staticmethod
    def _do_grid(stat, z, q, is_vertical=True):
        """
        Draw grid lines.

        The grid lines are either horizontal
        or vertical, but not both.

        stat: Stat
            Has render.

        z: layer
            Draw on layer.

        q: tuple
            arguments for vertical or horizontal lines

        is_vertical: bool
            If it's true, the arguments are for vertical lines.
        """
        args = stat.render.image, z
        q1 = 0, 0, 0, (0, 0, 0), 0

        if is_vertical:
            args += q1 + q + q1

        else:
            args += q + q1 * 2
        pdb.plug_in_grid(*args)
