#!/usr/bin/env python
# -*- coding: utf-8 -*-


class GridCell(object):
    """Use with the grid cell table to hold cell rectangles."""

    def __init__(self, r, c):
        """
        Create a cell storage object.

        r, c: int
            cell index
        """
        # row and column cell table indices:
        self.r, self.c = r, c

        # Has the topleft coordinate and the size of the cell:
        self.cell = None

        # Is the cell rectangle with with margins:
        self.pocket = None

        # Is a Rect for image place:
        self.mold = None

        # tuple
        # Use with plaque and fringe to get cell shape without margin:
        self.plaque = None

        # tuple
        # Use with render to get cell shape with margin:
        self.shape = None

        # string
        # Use to assign an image reference:
        self.image = ""
