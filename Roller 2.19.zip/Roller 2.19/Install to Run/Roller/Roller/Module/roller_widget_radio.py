#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_widget import Widget
from roller_widget_box import RollerBox
import gtk


class RadioGroup:
    """Use to manage a group of RollerRadioButtons."""

    def __init__(self, q, k):
        """
        Receive the RollerRadioButtons.

        The RollerRadioButtons are assumed to part of the same group.

        q: iterable
            group of related RollerRadioButtons

        k: string
            widget group key
        """
        self.buttons = q[:]
        self.key = k

    def get_value(self):
        """
        Find the active RadioButton.

        There's always one RadioButton that is active.

        Is part of the Widget template.

        Return: int
            index into group
            in 0 to n
        """
        for x, g in enumerate(self.buttons):
            if g.get_value():
                return x

    def set_value(self, x):
        """
        Set a RadioButton in the group as active.

        Only one RadioButton in a group can be active.

        Is part of the Widget template.

        x: integer
            index into group
        """
        # Repair:
        x = x if isinstance(x, int) else 0

        self.buttons[x].set_value(1)

    def hide(self):
        """Hide the radio buttons in this group."""
        for i in self.buttons:
            i.hide()

    def show(self):
        """Show the radio buttons in this group."""
        for i in self.buttons:
            i.show()


class RollerRadioList(RadioGroup):
    """
    Create a list of linked radio buttons.

    Use RadioGroup to set and get selected radio button.
    """

    def __init__(self, **d):
        """
        Create a list of radio buttons.

        Each radio button is linked to a group box.
        The group boxes are kept in a switch group box.
        Group boxes are not initially visible.

        d: dict
            Has init values.
        """
        self._on_window_action = d['on_widget_change']
        d['on_widget_change'] = self.relay_on_action
        self.group_box = []
        self.switch_group_box = None
        q = []
        group = None

        for x, text in enumerate(d['labels']):
            g = RollerRadioButton(**dict(d, group=group, label_x=x))

            if not group:
                group = g.widget

            q.append(g)
            d['container'].pack_start(g, expand=False)

        RadioGroup.__init__(self, q, d['key'])
        for i in q:
            i.widget.connect('toggled', self.relay_on_action)

    def get_sel_x(self):
        """
        Get the select radio button index.

        Use with Port's on_list_change function.

        Return: int
            of selection
        """
        return self.get_value()

    def relay_on_action(self, g):
        """
        Call when a radio button is activated.

        Let the owner-window know the button was activated.

        g: RollerRadioButton
            to relay action
            not used
        """
        self._on_window_action(self)


class RollerRadioButton(Widget):
    """Is a GTK RadioButton attached to an Alignment."""

    def __init__(self, **d):
        """
        Create a GTK radio button.

        Radio buttons are grouped together and identify
        their group by referencing their first member.

        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.RadioButton(d['group'], d['labels'][d['label_x']])

        Widget.__init__(self, g, **d)
        self.add(g)

        # Do connections last:
        g.connect('toggled', self.callback)

    def get_value(self):
        """
        Get the value of the RadioButton.

        Is part of the Widget template.

        Return: int
            0 or 1
        """
        return self.widget.get_active()

    def set_value(self, value):
        """
        Set the value of the RadioButton.

        Is part of the Widget template.

        value: int
            0 or 1
        """
        self.widget.set_active(value)


class RadioBox(gtk.Alignment):
    """Create a VBox with RadioButtons."""

    def __init__(self, **d):
        """
        Create the widgets.

        d: dict
            Has Init values.
        """
        super(gtk.Alignment, self).__init__()

        g = RollerBox(gtk.VBox)
        q = self.buttons = []
        self.key = d['key']

        q.append(
            RollerRadioButton(**dict(d, label_x=0, group=None))
        )

        if 'tooltip' in d:
            d.pop('tooltip')

        q.append(
            RollerRadioButton(**dict(d, label_x=1, group=q[0].widget))
        )
        g.add(q[0])
        g.add(q[1])
        self.add(g)
        self.radio_group = RadioGroup(q, self.key)

    def get_value(self):
        """
        Get the value of the RadioGroup.

        Is part of the Widget template.

        Return: int
            index to the active radio button
        """
        return self.radio_group.get_value()

    def hide(self):
        """Hide the buttons and label."""
        # 'self.box' is an eventbox that was added when
        # the RadioBox was inserted into the table:
        if self.box:
            if self.box.get_visible():
                self.box.hide()
                self.label.box.hide()

    def set_value(self, value):
        """
        Set the value in the RadioGroup.

        Is part of the Widget template.

        value: int
            index to a radio button
        """
        self.radio_group.set_value(value)

    def show(self):
        """Hide the buttons and label."""
        if self.box:
            if not self.box.get_visible():
                self.box.show()
                self.label.box.show()
