#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_style_gradient_fill import GradientFill
from roller_one_constant import (
    ForBackdropStyle as fbs,
    ForGradient as fg,
    OptionKey as ok
)
from roller_one_constant_fu import Fu
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_one import One
import gimpfu as fu

pdb = fu.pdb


class CubismCover:
    """Create a pile of tile."""

    def __init__(self, one):
        """
        Do the backdrop-style.

        one: One
            Has variables.
        """
        stat = one.stat
        j = stat.render.image
        z = one.z
        d = one.d
        n = d[ok.BACKDROP_TYPE]

        if n == fbs.PLASMA:
            pdb.plug_in_plasma(
                j,
                z,
                d[ok.RANDOM_SEED],
                Fu.Plasma.LOWEST_TURBULENCE
            )

        elif n == fbs.GRADIENT:
            e = deepcopy(fg.LINEAR_DICT)
            e[ok.GRADIENT_TYPE] = d[ok.GRADIENT_TYPE]
            e[ok.GRADIENT] = d[ok.GRADIENT]

            if d[ok.GRADIENT_TYPE] == "Linear":
                e[ok.END_X] = e[ok.START_X] = .5
                e[ok.START_Y] = .0
                e[ok.END_Y] = 1.

            else:
                e[ok.START_X] = e[ok.START_Y] = .5
                e[ok.END_X] = e[ok.END_Y] = .0

            GradientFill(One(d=e, session=one.session, stat=stat, z=z))
            z = j.active_layer

        if d[ok.BACKDROP_BLUR]:
            Gegl.blur(z, d[ok.BACKDROP_BLUR])

        z = Lay.clone(z)

        Gegl.cubism(z, size=d[ok.TILE_SIZE], amount=5., seed=d[ok.RANDOM_SEED])

        z1 = Lay.clone(z)
        z1.mode = z.mode = fu.LAYER_MODE_SOFTLIGHT

        Gegl.edge(z1)
        pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

        z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
        Gegl.saturation(z, d[ok.SATURATION])
