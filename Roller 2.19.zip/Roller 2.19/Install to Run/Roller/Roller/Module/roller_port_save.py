#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_base import OZ
from roller_one_constant import (
    ForWidget,
    PortKey,
    PresetKey as pk,
    UIKey
)
from roller_port import Port
from roller_widget_button import RollerButton
from roller_widget_entry import RollerEntry
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_splitter import Splitter
import os
import gtk


class PortSave(Port):
    """Save a preset."""

    def __init__(self, d, preset_name, preset_key):
        """
        Start it up.

        d: dict
            Has init values.

        preset_name: string
            Use to make file path.
        """
        self._preset_name = preset_name
        self._preset_key = preset_key
        d[UIKey.PORT_KEY] = PortKey.NOT_USED
        self._file_name_widget = self.save_b = None
        Port.__init__(self, d)

    def _draw_file_info_group(self, g):
        """
        The file info group shows the user the preset file's location.

        g: GTK container
            for this group of widgets
        """
        w = ForWidget.MARGIN
        w1 = w // 2
        self.reduce_color()
        n = os.path.dirname(
            OZ.get_preset_path(self._preset_key, "", self.stat.preset_folder))

        drive, path = os.path.splitdrive(n)
        g1 = Splitter(padding=(w1, w1, w, w), has_inner_padding=True)
        g2 = RollerEventBox(self.color)
        g3 = gtk.VBox()

        self.reduce_color()

        g4 = RollerEventBox(self.color)
        g5 = self._file_name_box = gtk.VBox()
        g6 = self._file_name_widget = RollerLabel(text="")

        g2.add(g3)
        g4.add(g5)
        g1.both(g2, g4)
        g3.add(RollerLabel(text="Drive:"))
        g3.add(RollerLabel(text="Folder:"))
        g3.add(RollerLabel(text="File Name:"))
        g5.add(RollerLabel(text=drive))
        g5.add(RollerLabel(text=path))
        g5.add(g6)
        g1.no_pack()
        g.add(g1.container)
        self._draw_file_name(self._file_name_entry)

    def _draw_file_name(self, g):
        """
        Call whenever the preset name entry changes.

        Update the file location group with the latest file name.

        g: GTK Entry
            file name Entry
        """
        if self._file_name_widget:
            n = OZ.get_preset_name(
                self._preset_key,
                g.get_value()
            )

            self._file_name_widget.widget.set_text(n)
            if self.save_b:
                if g.get_value().lower() in (
                            pk.DEFAULT.lower(),
                        ):
                    self.save_b.disable()
                else:
                    self.save_b.enable()

    def _draw_process_group(self, g):
        """
        Draw the Cancel and Save Buttons for the port.

        g: GTK container
            for the widget group
        """
        w = ForWidget.MARGIN
        w1 = w // 2
        g1 = Splitter(padding=(w1, w1, w, w), has_inner_padding=True)
        g2 = self.save_b = RollerButton(
            on_widget_change=self.do_accept,
            text="Save"
        )
        g3 = self.cancel_b = RollerButton(
            on_widget_change=self.do_cancel,
            text="Cancel"
        )

        g1.both(g3, g2)
        g1.pack()
        g.add(g1.container)

    def _draw_variable_group(self, g):
        """
        Create an entry for naming the preset.

        g: GTK container
            for the widget group
        """
        w = ForWidget.MARGIN
        w1 = w // 2
        g1 = self._file_name_entry = RollerEntry(
            on_key_press=self.on_key_press,
            on_widget_change=self._draw_file_name,
            padding=(0, w1, w, w)
        )

        g.add(RollerLabel(padding=(w1, 0, w, w), text="Preset Name:"))
        g.add(g1)
        g1.set_value(self._preset_name)
        g1.widget.select_region(0, -1)

    def draw_port(self, g):
        """
        Draw the port's controls.

        Is part of the Port template.

        g: VBox
            container for group of widgets
        """
        q = (
            self._draw_variable_group,
            self._draw_file_info_group,
            self._draw_process_group
        )
        q1 = "Variables", "File Location", "Process"

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            g1 = gtk.VBox()

            box.add(g1)
            g.add(box)
            g1.add(RollerLabel(text=q1[x] + ":", padding=(2, 0, 4, 0)))
            p(g1)
            self.reduce_color()

    def do_accept(self, *_):
        """
        Write the preset data.

        Return: true or None
            Is true if the write is successful.
        """
        return self.do_accept_callback(self._file_name_entry.get_value())

    def do_cancel(self, *_):
        """
        Close the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()
