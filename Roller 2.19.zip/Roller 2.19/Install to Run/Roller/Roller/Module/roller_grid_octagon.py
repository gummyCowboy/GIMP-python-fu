#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import Rect
from roller_grid import Grid
from roller_one_constant import ForFormat as ff


class GridOctagon:
    """
    Calculate the coordinates and the size of cells.

    The cells are octagon shaped.
    """

    def __init__(self, grid):
        """
        Calculate cell size and octagon shape.

        grid: One
            Has init values.
        """
        self.grid = grid
        row, column = self.row, self.column = grid.r, grid.c
        table = grid.table
        s = grid.layer_space
        x, y = grid.offset
        q_x = self.x_intersect = []
        q_y = self.y_intersect = []

        if grid.grid_type == ff.Grid.Index.CELL_SIZE:
            w, h = grid.column_width, grid.row_height
            s1 = w * column, h * row
            w, h = w / 1., h / 1.
            x, y = Grid.calc_pin_offset(grid.pin, s, s1[0], s1[1], x, y)

        elif grid.grid_type == ff.Grid.Index.SHAPE_COUNT:
            w = s[0] // column
            h = s[1] // row
            w = min(w, h)
            s1 = w * column, w * row
            w, h = w, w
            x, y = Grid.calc_pin_offset(grid.pin, s, s1[0], s1[1], x, y)

        else:
            w = s[0] / 1. / column
            h = s[1] / 1. / row

        offset = x, y

        if grid.cell_shape == ff.Cell.Shape.OCTAGON:
            is_align = False
            self._calc_octagon_intersect(x, y, w, h)
            q = Form.calc_octagon_offset(w, h)

        else:
            is_align = True
            self._calc_align_octagon_intersect(x, y, w, h)
            q = Form.calc_octagon_aligned_offset(w, h)

        self.is_align = is_align

        s1 = s[0] + offset[0], s[1] + offset[1]

        # Compose points:
        for r in range(row):
            for c in range(column):
                x, y = position = q_x[c], q_y[r]
                size = int(w), int(h)

                if size[0] > s1[0] or size[1] > s1[1]:
                    position = size = 0, 0

                # 'cell' is the cell rectangle before margins:
                table[r][c].cell = Rect(position, size)
                if size[0]:
                    # If there are no margins, then do shape:
                    if is_align:
                        q1 = Form.calc_octagon_aligned_shape(
                            x, y, w, h, q
                        )

                    else:
                        q1 = Form.calc_octagon_shape(x, y, w, h, q)

                    table[r][c].plaque = q1
                    if grid.with_shape:
                        table[r][c].shape = q1

    def _calc_align_octagon_intersect(self, x, y, w, h):
        """
        Calculate the intersect coordinates for an aligned octagon.

        x, y, w, h: int
            Defines cell rectangle.
        """
        q = self.x_intersect

        for c in range(self.column):
            q.append(x)
            x += w

        q = self.y_intersect
        for r in range(self.row):
            q.append(y)
            y += h

    def _calc_octagon_intersect(self, x, y, w, h):
        """
        Calculate the intersect coordinates for an octagon.

        x, y, w, h: int
            Defines cell rectangle.
        """
        q = self.x_intersect

        for c in range(self.column):
            q.append(x)
            x += w

        q = self.y_intersect
        for r in range(self.row):
            q.append(y)
            y += h

    def calc_shape_per_cell(self, d):
        """
        Calculate the shape of the diamond from
        the pocket size on a per cell basis.

        Is part of the GridDeck template.

        d: dict
            Has format.
            not used
        """
        self.calc_shape_with_pocket()

    def calc_shape_with_pocket(self):
        """
        Calculate the shape of the octagon from
        the pocket size using intersects.

        Is part of the GridDeck template.
        """
        for r in range(self.grid.r):
            for c in range(self.grid.c):
                rect = self.grid.table[r][c].pocket
                w, h = rect.w, rect.h
                if w and h:
                    if self.is_align:
                        q = Form.calc_octagon_aligned_shape(
                            rect.x,
                            rect.y,
                            w,
                            h,
                            Form.calc_octagon_aligned_offset(w, h)
                        )

                    else:
                        q = Form.calc_octagon_shape(
                            rect.x,
                            rect.y,
                            w,
                            h,
                            Form.calc_octagon_offset(w, h)
                        )
                    self.grid.table[r][c].shape = q
