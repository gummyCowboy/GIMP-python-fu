#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_grid_deck import GridDeck
from roller_one_base import Base
from roller_one_constant import (
    BorderKey as bo,
    CaptionKey,
    FormatKey as fk,
    FringeKey as fr,
    MaskKey,
    PlaceKey as pl,
    PlaqueKey,
    PropertyKey
)

GRID_KEY = fk.Cell.Grid.PER_CELL
MARGIN_KEY = fk.Cell.Margin.PER_CELL
PROP_KEY = fk.Cell.Image.Property.PER_CELL


class CellTable:
    """Has static methods. Use to adjust cell tables after grid changes."""

    @staticmethod
    def _contract_cell_table(table, row, col):
        """
        Contract Per Cell tables to correspond with the Format dict.

        Checks Merge Cells table for group dimension overflow.

        table: 2D list
            of cell table

        row, col: int
            cell table size
            row, column span
        """
        q = table

        if q:
            r = len(q)

            if r > row:
                # Remove rows:
                for _ in range(r - row):
                    q.pop()
            for r in range(len(q)):
                c = len(q[r])
                if c > col:
                    # Remove columns:
                    for _ in range(c - col):
                        q[r].pop()

    @staticmethod
    def _correct_contracted_cells(table, row, col):
        """
        When cells contract, their dimensions change.
        This makes the cut-off cells independent.

        Use with the merge cell table.

        table: 2D list
            of cell table

        row, col: int
            cell table size
            row, column span
        """
        if table:
            q = table
            r, c = row, col
            r1 = len(q)
            for r2 in range(r1):
                for c1 in range(len(q[r2])):
                    if r2 >= r or c1 >= c:
                        q[r2][c1] = 1, 1

    @staticmethod
    def _correct_merge_overflow(s, row, col, r, c):
        """
        Check if the Merge Cells' table has contracted. If so then
        the top-left cells need their dimensions checked for overflow.

        s: tuple of int (w, h)
            group dimension

        row, col: int
            max location

        r, c: int
            current location
        """
        if s[0] + r > row:
            s = row - r, s[1]

        if s[1] + c > col:
            s = s[0], col - c
        return s

    @staticmethod
    def _expand_cell_table(table, row, col, cell):
        """
        Expand a cell table based on the row and column counts.

        During an expansion, values are inserted into
        a table from the Format window settings.
        These settings are placed in the 'cell' variable.

        Each Per Cell group has its own cell type.

        table: 2D list
            of cell table

        row, col: int
            cell table size
            row, column span

        cell: tuple
            to initialize cell table
        """
        q = table

        if not q:
            q = Base.create_2d_table(row, col, init=cell)

        else:
            # 'r', current row count:
            r = len(q)

            if r < row:
                # e = [cell] * col
                e = []

                for _ in range(col):
                    e.append(cell)
                for r1 in range(row - r):
                    # Add a row with a new list:
                    q.append(deepcopy(e))
            for r1 in range(row):
                c = len(q[r1])
                if c < col:
                    for _ in range(col - c):
                        # Add a column:
                        q[r1].append(cell)
        table = q

    @staticmethod
    def _fix_merge_cells(table, row, col):
        """
        Correct overflow references by reducing
        merged group dimensions in the topleft cells.
        """
        if table:
            q = table
            for r in range(row):
                for c in range(col):
                    if r < len(q):
                        if c < len(q[r]):
                            q[r][c] = \
                                CellTable._correct_merge_overflow(
                                    q[r][c],
                                    row,
                                    col,
                                    r, c
                                )
        CellTable._correct_contracted_cells(table, row, col)

    @staticmethod
    def _get_per_cell_margins(value):
        """
        value: tuple
            of margins

        Return: tuple
            of margins
        """
        return value

    @staticmethod
    def _get_per_cell_merge(_):
        """
        Return: tuple
            of margins
        """
        return 1, 1

    @staticmethod
    def adjust_cell_table(table, r, c, cell):
        """
        Cell tables expand or contract depending on the cell table size.

        table: 2D list
            of cell table

        r, c: int
            row, column span of cell table

        cell: tuple
            to initialize cell table
        """
        CellTable._expand_cell_table(table, r, c, cell)
        CellTable._contract_cell_table(table, r, c)

    @staticmethod
    def adjust_cell_tables(d, stat):
        """
        Adjust all the per cell cell tables.

        d: dict
            of format

        stat: Stat
            globals
        """
        r, c = GridDeck.calc_grid_division(d, stat.render.size)

        for preset, per_cell, p in TABLES:
            cell = p(d[preset])
            CellTable.adjust_cell_table(d[per_cell], r, c, cell)
        CellTable._fix_merge_cells(d[GRID_KEY], r, c)

    @staticmethod
    def init_cell_table(d, key, stat):
        """
        Load an initial value into a cell table.

        d: dict
            of format

        key: string
            of per cell

        stat: Stat
            globals
        """
        r, c = GridDeck.calc_grid_division(d, stat.render.size)

        for preset, per_cell, p in TABLES:
            if per_cell == key:
                break
        return Base.create_2d_table(r, c, init=p(d[preset]), deep=1)


# Return init values for the cell tables:
TABLES = (
    (
        bo.CELL_BORDER,
        fk.Cell.Border.PER_CELL,
        lambda d: d
    ),
    (
        CaptionKey.CELL_CAPTION,
        fk.Cell.Caption.PER_CELL,
        lambda d: d
    ),
    (
        fr.CELL_FRINGE,
        fk.Cell.Fringe.PER_CELL,
        lambda d: d
    ),
    (
        GRID_KEY,
        GRID_KEY,
        CellTable._get_per_cell_merge
    ),
    (
        MaskKey.IMAGE_MASK,
        fk.Cell.Image.Mask.PER_CELL,
        lambda d: d
    ),
    (
        fk.Cell.MARGIN,
        MARGIN_KEY,
        CellTable._get_per_cell_margins
    ),
    (
        pl.IMAGE_PLACE,
        fk.Cell.Image.Place.PER_CELL,
        lambda d: d
    ),
    (
        PlaqueKey.CELL_PLAQUE,
        fk.Cell.Plaque.PER_CELL,
        lambda d: d
    ),
    (
        PropertyKey.IMAGE_PROPERTY,
        PROP_KEY,
        lambda d: d
    )
)
