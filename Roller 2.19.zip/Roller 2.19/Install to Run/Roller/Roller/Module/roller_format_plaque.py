#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import RollerImage
from roller_image_effect_feather_reduction import FeatherReduction as fr
from roller_image_effect import LayerKey as nk
from roller_one import One
from roller_one_base import Base, Comm
from roller_one_constant import (
    CellKey,
    ForFormat as ff,
    ForGradient as fg,
    FormatKey as fk,
    ForLayout as fy,
    FreeCellKey as fck,
    OptionKey as ok,
    PlaceKey as pl,
    PlaqueKey as pq,
    SessionKey as sk
)
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
GRID = fk.Cell.Grid
OPACITY_100 = 255


class Plaque:
    """
    Manage Plaque operation.

    Require a backdrop image for Plaque's average color function.
    """

    def __init__(self, stat):
        """
        Add a cell plaque to the render.

        Not every cell has a plaque.

        stat: Stat
            globals
        """
        self.stat = stat

    def _blur_behind_cell(self, d, x):
        """
        Create a layer with the blur-behind material.

        If the blur-behind layer already exists, add the
        cell's blur-behind material to that layer.

        d: dict
            of format

        x: int
            format index in session's format list
        """
        j = self.render
        stat = self.stat
        blur_layer = None
        self.is_merge = Form.is_merge_cells(d)
        name = d[fk.Layer.NAME]
        parent = stat.render.format_group(x, name)
        plaque_layer = Lay.search(parent, nk.CELL_PLAQUE, is_err=False)
        double_type = Form.get_double_space_type(d)
        blurred = []
        if plaque_layer:
            cell = One(shape=d[GRID.CELL_GRID][GRID.SHAPE])
            row, col = stat.layout.get_division(x)

            Lay.hide_format_stack(stat, x)
            Lay.hide_layers_above(parent, plaque_layer)

            for r in range(row):
                for c in range(col):
                    go = True

                    if double_type:
                        go = Form.is_double_space_cell(r, c, double_type)

                    if go:
                        cell.r, cell.c = r, c
                        e = cell.d = Form.get_cell_plaque(d, r, c)
                        go = Plaque.is_cell_plaque(
                            d,
                            cell,
                            double_type,
                            self.is_merge
                        )

                        if go:
                            go = blur = e[pq.BLUR_BEHIND]

                        if go:
                            if not self.stat.is_plaque_sel(name, r, c):
                                go = False

                        if go:
                            if not blur_layer:
                                pdb.gimp_selection_none(j)
                                pdb.gimp_edit_copy_visible(j)

                                z = blur_layer = Lay.paste(plaque_layer)
                                a = Lay.offset(plaque_layer) + 1
                                pdb.gimp_image_reorder_item(j, z, parent, a)
                        if go:
                            Sel.load(j, stat.get_plaque_sel(name, r, c))
                            if Sel.is_sel(j):
                                Lay.blur(blur_layer, blur)
                                blurred += [(name, r, c)]

            Lay.show_layer_on_top(parent, plaque_layer)
            Lay.show_format_groups(stat)
            pdb.gimp_selection_none(j)

            # Combine the plaque selections so the extra
            # material on the blur-behind layer can be cleared:
            for name, r, c in blurred:
                Sel.load(
                    j,
                    stat.get_plaque_sel(name, r, c),
                    option=fu.CHANNEL_OP_ADD
                )
            Plaque._merge_blur_behind(j, blur_layer, plaque_layer)

    def _blur_behind_free_cell(self, d, x):
        """
        Create a layer with the blur-behind material.

        If the blur-behind layer already exists, add the
        cell's blur=behind material to that layer.

        d: dict
            of format

        x: int
            format index
        """
        stat = self.stat
        j = stat.render.image
        blur_layer = None
        r = fy.FREE_CELL
        blurred = []
        parent = stat.render.format_group(x, d[fk.Layer.NAME])
        plaque_layer = Lay.search(parent, nk.FREE_CELL_PLAQUE, is_err=False)
        if plaque_layer:
            Lay.hide_format_stack(stat, x)
            Lay.hide_layers_above(parent, plaque_layer)

            for e in reversed(d[fk.Layer.CELL_LIST]):
                d1 = Form.get_cell_plaque(e, r, r)
                opacity = e[pq.CELL_PLAQUE][pq.OPACITY]
                _type = e[pq.CELL_PLAQUE][pq.TYPE]
                go = True if opacity and _type != ok.NONE else False

                if go:
                    go = blur = d1[pq.BLUR_BEHIND]

                    if go:
                        name = e[fck.CELL][CellKey.NAME]
                        if not self.stat.is_plaque_sel(name, r, r):
                            go = False
                    if go:
                        if not blur_layer:
                            pdb.gimp_selection_none(j)
                            pdb.gimp_edit_copy_visible(j)

                            z = blur_layer = Lay.paste(plaque_layer)
                            a = Lay.offset(plaque_layer) + 1
                            pdb.gimp_image_reorder_item(j, z, parent, a)

                        Sel.load(
                            j,
                            stat.get_plaque_sel(name, r, r)
                        )
                        if Sel.is_sel(j):
                            Lay.blur(blur_layer, blur)
                            blurred += [(name, r)]

            Lay.show_layer_on_top(parent, plaque_layer)
            Lay.show_format_groups(stat)
            pdb.gimp_selection_none(j)

            # Combine the plaque selections so the extra
            # material on the blur-behind layer can be cleared:
            for name, r in blurred:
                Sel.load(
                    j,
                    stat.get_plaque_sel(name, r, r),
                    option=fu.CHANNEL_OP_ADD
                )
            Plaque._merge_blur_behind(j, blur_layer, plaque_layer)

    def _blur_behind_layer(self, d, x):
        """
        Create a layer with the blurred behind material.

        d: dict
            of format

        x: int
            format index
        """
        stat = self.stat
        j = stat.render.image
        name = d[fk.Layer.NAME]
        parent = stat.render.format_group(x, name)
        plaque_layer = Lay.search(parent, nk.LAYER_PLAQUE, is_err=False)
        e = d[pq.LAYER_PLAQUE]
        blur = e[pq.BLUR_BEHIND]
        if plaque_layer and blur and e[pq.TYPE] != ok.NONE:
            if self.stat.is_plaque_sel(name, fy.LAYER, fy.LAYER):
                Lay.hide_format_stack(stat, x)
                Lay.hide_layers_above(parent, plaque_layer)
                pdb.gimp_selection_none(j)
                pdb.gimp_edit_copy_visible(j)
                Lay.show_layer_on_top(parent, plaque_layer)
                Lay.show_format_groups(stat)

                z = Lay.paste(plaque_layer)
                a = Lay.offset(plaque_layer) + 1

                pdb.gimp_image_reorder_item(j, z, parent, a)
                Sel.load(
                    j,
                    stat.get_plaque_sel(name, fy.LAYER, fy.LAYER)
                )
                if Sel.is_sel(j):
                    Lay.blur(z, blur)
                Plaque._merge_blur_behind(j, z, plaque_layer)

    def _do_average_color_plaque(self, z, cell, opacity):
        """
        Make an average color plaque.

        Exit with a selection to save.

        z: layer
            work-in-progress

        cell: One
            Has cell data.

        opacity: float
            for plaque layer

        Return: state of image
            selection
        """
        j = self.render
        d = cell.d

        if hasattr(cell, 'is_layer'):
            pdb.gimp_selection_none(j)
            RenderHub.copy_for_blur(z, self._parent, self.stat, self.f_x)
            j1 = 1

        else:
            j1 = cell.image

            if j1 and j1.j:
                pdb.gimp_edit_copy_visible(j1.j)
            else:
                j1 = None

        if j1:
            j1 = pdb.gimp_edit_paste_as_new_image()

            pdb.plug_in_pixelize2(
                j1,
                j1.layers[0],
                j1.width,
                j1.height,
            )
            Form.shape(j1, cell.w, cell.h)

        else:
            # There's no image, so use background.
            # Copy selection:
            Sel.rect(
                j,
                cell.x,
                cell.y,
                cell.w,
                cell.h,
                option=fu.CHANNEL_OP_REPLACE
            )
            pdb.gimp_edit_copy_visible(j)

            j1 = pdb.gimp_edit_paste_as_new_image()

            pdb.plug_in_pixelize2(
                j1,
                j1.layers[0],
                j1.width,
                j1.height
            )
            pdb.gimp_edit_copy_visible(j1)
            pdb.gimp_image_delete(j1)

        z = Lay.paste(z)

        pdb.gimp_layer_set_offsets(z, cell.x, cell.y)
        Sel.item(z)
        Form.select_shape(j, cell.plaque)
        Sel.clear_outside_of_selection(z, keep_sel=True)
        Plaque._feather(z, d)

        z = RenderHub.bump(z, d[pq.BUMP], self.stat, is_merge=True)
        z.opacity = opacity
        Sel.item(z)

    def _do_cell(self, cell, r, c, name, _type, opacity):
        """
        The cell has a plaque.

        cell: One
            Has cell data.

        r, c: int
            row, column
            cell table index

        name: string
            a z-item name
            either a format or a free-range cell name

        _type: string
            a plaque descriptor

        opacity: float
            for plaque layer
        """
        j = self.render
        z = Lay.add(j, self._cell_name, parent=self.group)
        if _type in self._plaque_process:
            self._plaque_process[_type](z, cell, opacity)
            self.stat.save_plaque_sel(name, r, c)

    def _do_cells(self):
        """Do the plaque for the grid cells."""
        stat = self.stat
        layout = stat.layout
        d = self.form
        f_x = self.f_x
        j = self.render
        parent = self._parent
        row, col = layout.get_division(f_x)
        double_type = Form.get_double_space_type(d)
        is_merge = Form.is_merge_cells(d)

        for r in range(row):
            for c in range(col):
                go = True

                if double_type:
                    go = Form.is_double_space_cell(r, c, double_type)
                if go:
                    cell = One(
                        r=r,
                        c=c,
                        shape=d[GRID.CELL_GRID][GRID.SHAPE]
                    )
                    rect = cell.cell = layout.get_merge_cell_rect(
                        f_x,
                        r,
                        c
                    )
                    cell.x, cell.y = rect.position
                    cell.w, cell.h = rect.size
                    e = cell.d = Form.get_cell_plaque(d, r, c)
                    go = Plaque.is_cell_plaque(
                        d,
                        cell,
                        double_type,
                        self.is_merge
                    )
                    if go:
                        j1 = layout.get_grid_image(
                            self.session,
                            d,
                            f_x,
                            r,
                            c,
                            is_merge
                        )
                        cell.image = j1
                        cell.plaque = layout.get_plaque(f_x, r, c)
                        opacity = e[pq.OPACITY]
                        _type = e[pq.TYPE]

                        if not self.group:
                            self.group = Lay.group(
                                j,
                                self._cell_name,
                                parent,
                                len(parent.layers)
                            )
                        self._do_cell(
                            cell,
                            r,
                            c,
                            d[fk.Layer.NAME],
                            _type,
                            opacity
                        )
                        RollerImage.close_image(j1)
        if self.group:
            Lay.merge_group(self.group, n=self._cell_name)
            self.group = None

    def _do_color_plaque(self, z, cell, opacity):
        """
        Make a image plaque.

        z: layer
            work-in-progress

        cell: One
            Has cell data.

        opacity: float
            for plaque layer

        Return: state of image
            a selection
        """
        j = self.render

        Form.select_shape(j, cell.plaque)
        Sel.fill(z, cell.d[pq.COLOR])
        Plaque._feather(z, cell.d)

        z = RenderHub.bump(z, cell.d[pq.BUMP], self.stat, is_merge=True)
        z.opacity = opacity
        Sel.item(z)

    def _do_free_cell(self):
        """Do the plaque for the free-range cells in a format."""
        j = self.render
        parent = self._parent
        d = self.form
        stat = self.stat
        r = fy.FREE_CELL

        for e in reversed(d[fk.Layer.CELL_LIST]):
            opacity = e[pq.CELL_PLAQUE][pq.OPACITY]
            _type = e[pq.CELL_PLAQUE][pq.TYPE]
            go = True if opacity and _type != ok.NONE else False
            if go:
                j1 = RollerImage.get_image(
                    self.session,
                    e[pl.IMAGE_PLACE][pl.IMAGE_DICT]
                )

                if not j1:
                    # Create a dummy to hold the 'cell':
                    j1 = RollerImage(None, "")
                if j1:
                    Form.prep_free_cell_image(j1, e, stat.render.size)

                    cell = One(
                        cell=j1.cell,
                        r=r,
                        c=r,
                        image=j1,
                        plaque=j1.plaque,
                        shape=e[fck.CELL][CellKey.SHAPE]
                    )
                    cell.w, cell.h = j1.cell.size
                    cell.x, cell.y = j1.cell.position
                    cell.d = Form.get_cell_plaque(e, r, r)

                    if not self.group:
                        a = len(parent.layers)
                        b = int(
                            Lay.search(
                                parent,
                                nk.LAYER_PLAQUE,
                                is_err=False
                            ) is not None
                        )
                        if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                            b += int(
                                Lay.search(
                                    parent,
                                    nk.CELL_PLAQUE,
                                    is_err=False
                                ) is not None
                            )
                        self.group = Lay.group(
                            j,
                            self._free_cell_name,
                            parent,
                            a - b
                        )

                    self._do_cell(
                        cell,
                        r,
                        r,
                        e[fck.CELL][CellKey.NAME],
                        _type,
                        opacity
                    )
                    RollerImage.close_image(j1)
        if self.group:
            Lay.merge_group(self.group, n=self._free_cell_name)
            self.group = None

    def _do_gradient_plaque(self, z, cell, opacity):
        """
        Make a gradient plaque.

        z: layer
            work-in-progress

        cell: One
            Has cell data.

        opacity: float
            for plaque layer

        Return: state of image
            a selection to save
        """
        def draw_gradient(_start_x, _end_x, _start_y, _end_y):
            pdb.gimp_drawable_edit_gradient_fill(
                z,
                fg.GRADIENT_TYPE_LIST.index(gradient_type),
                gf.OFFSET_0,
                gf.YES_SUPERSAMPLE,
                gf.SUPERSAMPLE_MAX_DEPTH_2,
                gf.SUPERSAMPLE_THRESHOLD_0,
                gf.YES_DITHER,
                _start_x,
                _start_y,
                _end_x,
                _end_y
            )

        j = self.render
        d = cell.d
        z1 = z
        gradient = d[pq.GRADIENT]

        if gradient not in self.stat.gradient_list:
            Comm.info_msg(
                ff.MISSING_ITEM.format("Plaque", "gradient", gradient)
            )
        else:
            x, y, w, h = cell.x, cell.y, cell.w, cell.h
            gradient_type = d[pq.GRADIENT_TYPE]

            RenderHub.set_fill_context(fg.FILL_DICT)
            pdb.gimp_context_set_gradient(gradient)
            pdb.gimp_context_set_gradient_blend_color_space(
                fu.GRADIENT_BLEND_RGB_PERCEPTUAL
            )
            pdb.gimp_context_set_gradient_reverse(0)

            if gradient_type in fg.SHAPE_BURST:
                j1 = pdb.gimp_image_new(w, h, fu.RGB)
                z = Lay.add(j1, 'temp')

                pdb.gimp_selection_all(j1)
                Sel.fill(z, (127, 127, 127))
                pdb.gimp_selection_none(j1)
                draw_gradient(0, 0, 0, 0)
                pdb.gimp_edit_copy_visible(j1)
                pdb.gimp_image_delete(j1)

                z = Lay.paste(z1)
                pdb.gimp_layer_set_offsets(z, x, y)

            else:
                start_x, end_x, start_y, end_y =\
                    RenderHub.get_gradient_points(
                        d[pq.GRADIENT_ANGLE],
                        x,
                        y,
                        w,
                        h
                    )

                Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
                draw_gradient(start_x, end_x, start_y, end_y)

            Form.select_shape(j, cell.plaque)
            Sel.clear_outside_of_selection(z, keep_sel=True)
            Plaque._feather(z, d)

            z = RenderHub.bump(z, d[pq.BUMP], self.stat, is_merge=True)
            z.opacity = opacity
            Sel.item(z)

    def _do_image_plaque(self, z, cell, opacity):
        """
        Make a image plaque.

        z: layer
            work-in-progress

        cell: One
            Has cell image.

        opacity: float
            for plaque layer

        Return: state of image
            a selection to save
        """
        j = self.render
        d = cell.d

        pdb.gimp_selection_none(j)

        image = d[pq.IMAGE]

        j1 = RollerImage.get_image(self.session, image)
        if j1:
            j2 = j1.j

            pdb.gimp_selection_none(j2)
            pdb.gimp_edit_copy_visible(j2)

            j2 = pdb.gimp_edit_paste_as_new_image()

            Form.shape(j2, cell.w, cell.h)

            z = Lay.paste(z)

            pdb.gimp_layer_set_offsets(z, cell.x, cell.y)
            Sel.item(z)

            Form.select_shape(j, cell.plaque)
            Sel.clear_outside_of_selection(z, keep_sel=True)
            Plaque._feather(z, d)

            z = RenderHub.bump(z, d[pq.BUMP], self.stat, is_merge=True)
            z.opacity = opacity
            Sel.item(z)

    def _do_layer(self):
        """
        Add plaque layer.

        Is one per format.
        """
        j = self.render
        parent = self._parent
        stat = self.stat
        d = self.form
        cell = One(is_layer=True)
        size = self.session['size']
        e = cell.d = d[pq.LAYER_PLAQUE]

        if d[pq.LAYER_PLAQUE][pq.OBEY_MARGINS]:
            cell.y, bottom, cell.x, right = Form.get_layer_margin(d, size)
            cell.w = size[0] - cell.x - right
            cell.h = size[1] - cell.y - bottom

        else:
            cell.x = cell.y = 0
            cell.w, cell.h = size

        # Layer and cell plaques have the same order of plaque data:
        opacity = e[pq.OPACITY]
        _type = e[pq.TYPE]
        go = True if opacity and _type != ok.NONE else False
        if go:
            w, h = cell.x + cell.w, cell.y + cell.h
            cell.plaque = cell.x, cell.y, w, cell.y, w, h, cell.x, h
            self.group = Lay.group(
                j,
                self._layer_name,
                parent,
                len(parent.layers)
            )
            if _type in self._plaque_process:
                z = Lay.add(j, self._layer_name, parent=self.group)

                self._plaque_process[_type](z, cell, opacity)
                Lay.merge_group(self.group, n=self._layer_name)

                self.group = None
                stat.save_plaque_sel(
                    d[fk.Layer.NAME],
                    fy.LAYER,
                    fy.LAYER
                )

    def _do_netting_plaque(self, z, cell, opacity):
        """
        Make a netting plaque.

        z: layer
            work-in-progress

        cell: One
            Has cell data.

        opacity: float
            for plaque layer

        Return: state of image
            a selection to save
        """
        j = self.render
        d = cell.d
        w = d[pq.SPACING]
        color = d[pq.COLOR]
        w1 = d[pq.LINE_WIDTH]

        Form.select_shape(self.render, cell.plaque)
        pdb.plug_in_grid(
            j,
            z,
            w1,
            w,
            w,
            color,
            OPACITY_100,
            w1,
            w,
            w,
            color,
            OPACITY_100,
            0,
            0,
            0,
            (0, 0, 0),
            0
        )
        Plaque._feather(z, cell.d)

        z = RenderHub.bump(z, cell.d[pq.BUMP], self.stat, is_merge=True)
        z.opacity = opacity
        Sel.item(z)

    def _do_pattern_plaque(self, z, cell, opacity):
        """
        Make a pattern plaque.

        z: layer
            work-in-progress

        cell: One
            Has cell data.

        opacity: float
            for plaque layer

        Return: state of image
            a selection to save
        """
        d = cell.d
        pattern = d[pq.PATTERN]
        if pattern in self.stat.pattern_list:
            j = self.render

            Form.select_shape(self.render, cell.plaque)
            RenderHub.set_fill_context(fg.FILL_DICT)
            pdb.gimp_context_set_pattern(pattern)
            pdb.gimp_drawable_edit_bucket_fill(
                z,
                fu.FILL_PATTERN,
                Base.seal(cell.x + cell.w // 2, 0, j.width),
                Base.seal(cell.y + cell.h // 2, 0, j.height)
            )
            Plaque._feather(z, d)

            z = RenderHub.bump(z, d[pq.BUMP], self.stat, is_merge=True)
            z.opacity = opacity
            Sel.item(z)
        else:
            Comm.info_msg(ff.MISSING_ITEM.format("Plaque", "pattern", pattern))

    @staticmethod
    def _feather(z, d):
        """
        Feather the plaque selection.

        d: dict
            Has feather option.
        """
        if d[pq.FEATHER]:
            fr.do(z, d)
            Sel.item(z)

    @staticmethod
    def _merge_blur_behind(j, z, z1):
        """
        Finish the blur behind process.

        j: GIMP image
            Is render.

        z: layer
            Is blur behind.

        z1: layer
            Is plaque.
        """
        if z:
            if Sel.is_sel(j):
                Sel.clear_outside_of_selection(z)

                n = z1.name
                z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
                z.name = n
            else:
                pdb.gimp_image_remove_layer(j, z)

    def blur_behind(self, session):
        """
        Blur behind cell and layer plaques.

        session: dict
            of session
        """
        self.session = session
        format_list = session[sk.FORMAT_LIST]
        for x in range(len(format_list) - 1, -1, -1):
            d = format_list[x]
            if not d[fk.Layer.CELL_LIST]:
                if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                    self._blur_behind_free_cell(d, x)

            self._blur_behind_layer(d, x)
            self._blur_behind_cell(d, x)
            if d[fk.Layer.CELL_LIST]:
                if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                    self._blur_behind_free_cell(d, x)

    def do(self, session, d, f_x):
        """
        Do the plaques for a format.

        session: dict
            of session

        d: dict
            of format

        f_x: int
            format index
        """
        self.session = session
        stat = self.stat
        self.f_x = f_x
        self.form = d
        self.render = stat.render.image
        parent = self._parent = stat.render.format_group(
            f_x,
            d[fk.Layer.NAME]
        )
        self._cell_name = Lay.get_layer_name(
            nk.CELL_PLAQUE,
            parent=parent
        )
        self._free_cell_name = Lay.get_layer_name(
            nk.FREE_CELL_PLAQUE,
            parent=parent
        )
        self._layer_name = Lay.get_layer_name(
            nk.LAYER_PLAQUE,
            parent=parent
        )
        self.f_x = f_x
        self.group = None
        self.is_merge = Form.is_merge_cells(d)

        self._plaque_process = {
            ff.Plaque.AVERAGE_COLOR: self._do_average_color_plaque,
            ff.Plaque.COLOR: self._do_color_plaque,
            ff.Plaque.IMAGE: self._do_image_plaque,
            ff.Plaque.GRADIENT: self._do_gradient_plaque,
            ff.Plaque.NETTING: self._do_netting_plaque,
            ff.Plaque.PATTERN: self._do_pattern_plaque
        }

        if d[fk.Layer.CELL_LIST]:
            if not d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                self._do_free_cell()

        self._do_cells()
        self._do_layer()
        if d[fk.Layer.CELL_LIST]:
            if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                self._do_free_cell()

    @staticmethod
    def is_cell_plaque(d, cell, double_type, is_merge):
        """
        Determine if the format's cell has a plaque.

        d: dict
            of format

        cell: One
            Has cell data.

        double_type: flag
            If its true, the cell shape is a hexagon or an ellipse.

        is_merge: flag
            Is true if merge cells is in effect.

        Return: flag
            Is true if the cell has a plaque.
        """
        e = cell.d
        opacity = e[pq.OPACITY]
        _type = e[pq.TYPE]
        go = True if opacity and _type != ok.NONE else False

        if go:
            if is_merge:
                s = d[fk.Cell.Grid.PER_CELL][cell.r][cell.c]

            else:
                s = 1, 1
            go = True if s != (-1, -1) else False

        if go:
            if double_type:
                if not Form.is_double_space_cell(cell.r, cell.c, double_type):
                    go = False
        return go
