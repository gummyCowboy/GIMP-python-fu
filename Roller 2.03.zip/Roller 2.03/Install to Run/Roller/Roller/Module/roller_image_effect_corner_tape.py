#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, seed, uniform
from roller_format_form import Form
from roller_image_effect import ImageEffect, LayerKey
from roller_one_constant import (
    ForFormat as ff,
    FormatKey as fk,
    OptionKey as ok,
    SessionKey as sk
)
from roller_one_fu import Lay, Sel
from roller_one import One
from roller_one_preset import Preset
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu
import math

pdb = fu.pdb
ek = ImageEffect.Key
FOUR_COORDINATES = 4

# oriented with zero at north:
RADIAN_135 = 2.35619
RADIAN_180 = 3.14159
RADIAN_225 = 3.92699
RADIAN_270 = 4.71239
RADIAN_315 = 5.49779
RADIAN_45 = .785398
RADIAN_90 = 1.5708


class CornerTape:
    """Simulate a tape image holder."""

    def __init__(self, one):
        """
        Do a Corner Tape image-effect.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        j = self.render = stat.render.image
        parent = self.parent = one.parent
        d = one.d
        name = Lay.get_format_name_from_group(parent)
        row = col = 0
        self.length = d[ok.TAPE_LENGTH]
        self.width = d[ok.TAPE_WIDTH]
        self.corner_shift = d[ok.CORNER_SHIFT]
        self.angle_shift = d[ok.ANGLE_SHIFT]
        e = Preset.get_default(ek.DROP_SHADOW)

        for i in (ok.SHADOW_BLUR, ok.INTENSITY):
            e[i] = d[i]

        seed(d[ok.RANDOM_SEED])
        Shadow(
            One(
                d=e,
                e={'caster_key': (LayerKey.IMAGE,)},
                k=ek.DROP_SHADOW,
                parent=parent,
                stat=stat
            )
        )

        # Get the format dict:
        for x, i in enumerate(one.session[sk.FORMAT_LIST]):
            if i[fk.Layer.NAME] == name:
                form = i
                row, col = stat.layout.get_division(x)
                break

        n = Lay.get_layer_name(one.k, parent)
        group = Lay.group(j, n, parent=parent)
        z = Lay.add(j, n, group)
        merged = Form.is_merge_cells(form)

        # Do one image at a time:
        for r in range(row):
            for c in range(col):
                if merged:
                    s = form[fk.Cell.Grid.PER_CELL][r][c]

                else:
                    # not a dependent cell:
                    s = 1

                # Is it a dependent cell?
                if s != (-1, -1):
                    sel = stat.get_image_sel(name, r, c)
                    if sel:
                        Sel.load(j, sel)

                        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
                        w = x1 - x
                        h = y1 - y

                        pdb.gimp_selection_none(j)
                        self._do_topleft(
                            x + self._get_corner_shift(),
                            y + self._get_corner_shift()
                        )
                        self._do_top_right(
                            x + w + self._get_corner_shift(),
                            y + self._get_corner_shift()
                        )
                        self._do_bottom_left(
                            x + self._get_corner_shift(),
                            y + h + self._get_corner_shift()
                        )
                        self._do_bottom_right(
                            x + w + self._get_corner_shift(),
                            y + h + self._get_corner_shift()
                        )
                        Sel.fill(z, d[ok.COLOR])

        z1 = Lay.clone(j, z)
        e = Preset.get_default(ok.BUMP)
        e[ok.BUMP] = ff.HAS_BUMP
        e[ok.BUMP_DEPTH] = 1
        e[ok.LIGHT_ANGLE] = 225.

        RenderHub.bump(j, z1, e)
        Lay.blur(j, z1, 2)
        pdb.gimp_drawable_invert(z1, 0)

        z1.mode = fu.LAYER_MODE_DIFFERENCE
        z1.opacity = 66.
        z2 = Lay.clone(j, z1)
        z2.mode = fu.LAYER_MODE_LCH_HUE
        z2.opacity = 24.
        z3 = Lay.clone(j, z2)
        z3.mode = fu.LAYER_MODE_NORMAL
        z3.opacity = 2.
        z4 = Lay.clone(j, z)
        z4.mode = fu.LAYER_MODE_HSL_COLOR

        # Darken the edge:
        Sel.item(j, z4)
        pdb.gimp_selection_shrink(j, 1.)
        Sel.invert(j)
        pdb.gimp_curves_spline(
            z4,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 10, 255, 80]
        )

        # Place on top:
        Lay.order(j, z4, group)

        z5 = Lay.clone(j, z4)
        z5.mode = fu.LAYER_MODE_OVERLAY
        z6 = Lay.clone(j, z)

        pdb.plug_in_shift(j, z6, 2, 0)
        pdb.plug_in_shift(j, z6, 2, 1)
        Lay.blur(j, z6, 2)
        pdb.gimp_curves_spline(
            z6,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 0, 255, 0]
        )

        for i in (z, z1, z2, z3, z4, z5):
            Lay.give_mask(i, z6)

        pdb.gimp_image_remove_layer(j, z6)
        pdb.gimp_drawable_invert(z1, 0)
        z = Lay.merge_group(j, group, n)
        z.opacity = d[ok.OPACITY]

    def _do_bottom_left(self, x, y):
        """
        x, y: int
            center point
        """
        angle = RADIAN_135 + self._get_angle_shift()
        x1, y1 = CornerTape.get_point(x, y, angle, self.length // 2)
        self._select_tape_rect(angle, x1, y1)

    def _do_bottom_right(self, x, y):
        """
        x, y: int
            center point
        """
        angle = RADIAN_45 + self._get_angle_shift()
        x1, y1 = CornerTape.get_point(x, y, angle, self.length // 2)
        self._select_tape_rect(angle, x1, y1)

    def _do_topleft(self, x, y):
        """
        x, y: int
            center point
        """
        angle = RADIAN_225 + self._get_angle_shift()
        x1, y1 = CornerTape.get_point(x, y, angle, self.length // 2)
        self._select_tape_rect(angle, x1, y1)

    def _do_top_right(self, x, y):
        """
        x, y: int
            center point
        """
        angle = RADIAN_315 + self._get_angle_shift()
        x1, y1 = CornerTape.get_point(x, y, angle, self.length // 2)
        self._select_tape_rect(angle, x1, y1)

    def _get_angle_shift(self):
        """
        Make a randomized angle-shift amount.

        Return: int
            angle shift
        """
        return uniform(
            math.radians(-self.angle_shift),
            math.radians(self.angle_shift)
        )

    def _get_corner_shift(self):
        """
        Make a randomized corner-shift amount.

        Return: int
            corner shift
        """
        return randint(-self.corner_shift, self.corner_shift)

    def _select_tape_rect(self, angle, x, y):
        """
        Define and select a tape rectangle.

        x, y: int
            start point
        """
        x1, y1 = CornerTape.get_point(x, y, angle - RADIAN_90, self.width)
        x2, y2 = CornerTape.get_point(x1, y1, angle - RADIAN_180, self.length)
        x3, y3 = CornerTape.get_point(x2, y2, angle - RADIAN_270, self.width)
        Sel.polygon(self.render, (x, y, x1, y1, x2, y2, x3, y3))

    @staticmethod
    def blur_behind_tape(j, parent, stat, format_x):
        """
        Blur behind the tape.

        j: GIMP image
            work-in-progress

        parent: layer
            format group

        stat: Stat
            globals

        format_x: int
            index to format in format list
        """
        z = Lay.search(parent, LayerKey.CORNER_TAPE, is_err=0)
        if z:
            Lay.hide_layers_above(parent, z)
            Lay.hide_format_stack(stat, format_x)
            Lay.hide(z)
            pdb.gimp_edit_copy_visible(j)
            Lay.show(z)
            Lay.show_layer_on_top(parent, z)
            Lay.show_format_groups(stat)

            n = z.name
            image_layer = Lay.search(z.parent, LayerKey.IMAGE)
            blur_layer = Lay.paste(j, image_layer)

            Lay.blur(j, blur_layer, 5)
            pdb.gimp_curves_spline(
                blur_layer,
                fu.HISTOGRAM_VALUE,
                FOUR_COORDINATES,
                [0, 0, 255, 235]
            )
            Sel.item(j, z)
            Sel.clear_outside_of_selection(j, blur_layer)

            z = Lay.merge(j, z)
            z.name = n

    @staticmethod
    def get_point(x, y, angle, radius):
        """
        Returns a point the circle that corresponds to the rotation.

        x, y: int
            center point

        angle : float
            the rotation angle
            of radians

        radius: float
            the radius of the circle

        Returns:
            x : float
            y : float
            the point on the circle
        """
        x = (math.sin(angle) * radius) + x
        y = (math.cos(angle) * -radius) + y
        return round(x), round(y)
