#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_one_constant import ForFormat as ff, OptionKey as ok
from roller_one_fu import Lay
from roller_render_hub import RenderHub


class AverageColor:
    """Use pixelize to create an approximate average color."""

    def __init__(self, one):
        """
        Do the Average Color backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        z = Lay.clone(j, one.z)
        if Lay.has_pixel(j, z):
            d = one.d
            z.mode, z.opacity = RenderHub.get_mode(d)

            pdb.plug_in_pixelize2(j, z, one.session['w'], one.session['h'])

            if one.d[ok.INVERT]:
                pdb.gimp_drawable_invert(z, 0)
            if d[ok.BUMP][ok.BUMP] == ff.HAS_BUMP:
                RenderHub.bump(j, Lay.clone(j, z), d[ok.BUMP])
