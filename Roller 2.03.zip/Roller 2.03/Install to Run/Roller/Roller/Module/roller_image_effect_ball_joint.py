#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerKey
from roller_format_form import Form
from roller_one_base import Comm
from roller_one_constant import (
    FormatKey as fk,
    OptionKey as ok,
    SessionKey as sk
)
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

em = Pdb.Emboss
pdb = fu.pdb


class BallJoint:
    """
    """

    def __init__(self, one):
        """
        Do the Ball Joint image-effect.

        one: One
            Has variables.
        """
        stat = one.stat
        j = stat.render.image
        d = one.d
        form = None
        parent = one.parent
        name = Lay.get_format_name_from_group(parent)
        go = row = col = 0

        try:
            pdb.gimp_context_set_brush('dots')
            go = 1

        except RuntimeError:
            Comm.info_msg("Roller is unable to use the 'dots' brush.")

        if go:
            # Get the format dict:
            for x, i in enumerate(one.session[sk.FORMAT_LIST]):
                if i[fk.Layer.NAME] == name:
                    form = i
                    row, col = stat.layout.get_division(x)
                    break

            frame = Lay.get_layer_name(LayerKey.FRAME, parent)
            z = Lay.add(j, frame, parent)
            merged = Form.is_merge_cells(form)

            # Do one image at a time:
            for r in range(row):
                for c in range(col):
                    if merged:
                        s = form[fk.Cell.Grid.PER_CELL][r][c]

                    else:
                        # not a dependent cell:
                        s = 1

                    # Is it a dependent cell?
                    if s != (-1, -1):
                        image_sel = stat.get_image_sel(name, r, c)
                        if image_sel:
                            Sel.load(j, image_sel)
                            pdb.plug_in_sel2path(j, z)

                            stroke = j.active_vectors.strokes[0]

                            pdb.gimp_selection_none(j)
                            RenderHub.brush_stroke_on_stroke(
                                z,
                                'dots',
                                d[ok.BRUSH_SIZE],
                                stroke,
                                d[ok.BRUSH_SIZE] / 15.
                            )

            pdb.gimp_drawable_hue_saturation(
                z,
                fu.HUE_RANGE_ALL,
                Pdb.HueSaturation.HUE_OFFSET_0,
                Pdb.HueSaturation.LIGHTNESS_0,
                Pdb.HueSaturation.SATURATION_MINUS_100,
                Pdb.HueSaturation.OVERLAP_0
            )

            z1 = Lay.clone(j, z)
            z1.mode = fu.LAYER_MODE_OVERLAY

            pdb.plug_in_emboss(
                j,
                z1,
                d[ok.LIGHT_ANGLE],
                em.ELEVATION_30,
                em.DEPTH_3,
                em.EMBOSS
            )

            z = Lay.merge(j, z1)

            pdb.gimp_selection_none(j)

            # Do one image at a time:
            for r in range(row):
                for c in range(col):
                    if merged:
                        s = form[fk.Cell.Grid.PER_CELL][r][c]

                    else:
                        # not a dependent cell:
                        s = 1

                    # Is it a dependent cell?
                    if s != (-1, -1):
                        image_sel = stat.get_image_sel(name, r, c)
                        if image_sel:
                            Sel.load(j, image_sel, option=fu.CHANNEL_OP_ADD)
            Lay.clear_sel(j, z)
