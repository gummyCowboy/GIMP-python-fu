#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import ImageEffect
from roller_one_constant import ForLayer, OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb


class GradientBevel:
    """Create a colored edge around image material."""

    def __init__(self, one):
        """
        Do the Gradient Bevel image-effect.

        one: One
            Has variables.
        """
        stat = one.stat
        parent = one.parent
        d = one.d
        j = stat.render.image
        n = Lay.get_layer_name(ek.GRADIENT_BEVEL, parent=parent)
        z = Lay.add(j, n, parent=parent)
        z1 = Lay.selectable(
            j,
            stat.render.get_image_layer(
                Lay.get_format_name_from_group(parent)
            ),
            ForLayer.MAKE_OPAQUE_DICT
        )
        color, color1 = d[ok.COLOR_1], d[ok.COLOR_2]
        steps = d[ok.FRAME_WIDTH]

        GradientBevel.do_bevel_effect(j, z, z1, stat, color, color1, steps)
        pdb.gimp_image_remove_layer(j, z1)

    @staticmethod
    def do_bevel_effect(j, z, z1, stat, color, color1, steps):
        """
        Do color blend effect using two colors.

        j: GIMP image
            work-in-progress

        z: layer
            to receive effect

        z1: layer
            has material to select

        stat: Stat
            globals

        color, color1: tuple
            RGB

        steps: int
            the number of steps to grow the
            selection to reach color1
        """
        step = RenderHub.calc_gradient(color, color1, steps)
        start_color = color
        q = list(start_color)

        # The layer borders need to be set to the image size.
        # This is done by using a color fill. The problem
        # is the selection won't grow beyond the layer borders:
        pdb.gimp_selection_all(j)
        Lay.color_fill(z, (127, 127, 127))
        Lay.clear_sel(j, z)
        Sel.item(j, z1)

        for i in range(steps):
            sel = stat.save_selection()

            Sel.grow(j, 1, 0)
            Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
            Sel.fill(z, tuple(q))
            Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
            for x in range(3):
                a = step[x] * (i + 1)
                q[x] = start_color[x] + int(a)

        Sel.item(j, z1)
        Lay.clear_sel(j, z)
