#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_grid import Grid
from roller_one_base import Base
from roller_one_constant import ForFormat as ff, OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class ColoredGrid:
    """Create a colored grid."""

    def __init__(self, one):
        """
        Do the Colored Grid backdrop-style.

        one: One
            Has variables.
        """
        d = one.d
        j = one.stat.render.image

        if d[ok.ROTATE]:
            w = Base.circumradius(one.session['w'], one.session['h']) * 2
            r, c = d[ok.ROW], d[ok.COLUMN]
            d[ok.COLUMN] = int(c * w / 1. / one.session['w']) + 1
            d[ok.ROW] = int(r * w / 1. / one.session['h']) + 1
            j = pdb.gimp_image_new(w, w, fu.RGB)
            z = Lay.add(j, one.k)

        else:
            z = Lay.add(j, one.k, parent=one.z.parent)

        z = self.draw_color_grid(j, z, d)

        if d[ok.ROTATE]:
            d[ok.ROW], d[ok.COLUMN] = r, c
            Lay.rotate(j, d[ok.ROTATE])
            pdb.gimp_edit_copy_visible(j)
            pdb.gimp_image_delete(j)

            j = one.stat.render.image
            z = Lay.paste(j, one.z)
            pdb.gimp_layer_resize_to_image_size(z)

        z.mode, z.opacity = RenderHub.get_mode(d)

        if d[ok.INVERT]:
            pdb.gimp_drawable_invert(z, 0)
        if d[ok.BUMP][ok.BUMP] == ff.HAS_BUMP:
            RenderHub.bump(j, Lay.clone(j, z), d[ok.BUMP])

    @staticmethod
    def draw_color_grid(j, z, d):
        """
        Draw a checkerboard with two colors.

        j: GIMP image
            with layer

        z: layer
            to receive grid

        d: dict
            Has options.

        Return: layer
            Has colored grid.
        """
        s = w, h = j.width, j.height
        r, c = d[ok.ROW], d[ok.COLUMN]
        grid = Grid(s, r, c).table

        # Draw horizontal stripes:
        Lay.color_fill(z, (255, 255, 255))

        for r1 in range(0, r, 2):
            Sel.rect(j, 0, grid[r1][0].y, w, grid[r1][0].height)

        Sel.fill(z, (0, 0, 0))
        pdb.gimp_selection_none(j)

        # Draw vertical stripes:
        z1 = Lay.add(j, "v", parent=z.parent)
        z1.mode = fu.LAYER_MODE_DIFFERENCE

        Lay.color_fill(z1, (255, 255, 255))

        for c1 in range(0, c, 2):
            Sel.rect(j, grid[0][c1].x, 0, grid[0][c1].width, h)

        Sel.fill(z1, (0, 0, 0))

        z = Lay.merge(j, z1)
        z1 = Lay.clone(j, z)

        # Fill the black and white checkerboard:
        Sel.color(j, z1, (255, 255, 255))
        Sel.fill(z1, d[ok.COLOR_1])
        Sel.clear_outside_of_selection(j, z1)
        Lay.color_fill(z, d[ok.COLOR_2])
        pdb.gimp_selection_none(j)
        return Lay.merge(j, z1)
