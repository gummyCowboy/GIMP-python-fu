#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay
import gimpfu as fu
from roller_render_hub import RenderHub

pdb = fu.pdb


class RoundedEdge:
    """Create a curved image effect on an image layer."""

    def __init__(self, one):
        """
        Do Rounded Edge image-effect.

        one: One
            Has variables.
        """
        stat = one.stat
        d, e = one.d, one.e
        d[ok.MAKE_OPAQUE] = True
        color = (255, 255, 255) if d[ok.ROUND_UP] else (0, 0, 0)
        group, layers = RenderHub.create_shadow_unit(
            stat,
            one.parent,
            e['caster_key']
        )
        n = Lay.get_layer_name(one.k)
        z = RenderHub.do_shadow(
            stat,
            group,
            0,
            0,
            d[ok.ROUNDED_EDGE_BLUR],
            color,
            (125., 60.)[int(d[ok.ROUND_UP])],
            layer_name=n,
            d=d,
            is_inlay=1
        )
        z.mode = fu.LAYER_MODE_NORMAL

        pdb.gimp_image_remove_layer(stat.render.image, group)
        Lay.order(stat.render.image, z, one.parent)
        Lay.show(layers[0])
