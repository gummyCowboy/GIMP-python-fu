#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import colorsys
import gimpfu as fu
import math

pdb = fu.pdb
cloth = Pdb.Clothify


class FloorSample:
    """Has wedges colored by a gradient between two colors."""

    def __init__(self, one):
        """
        Draw the samples wedges.

        one: One
            Has variables.
        """
        self.stat = one.stat
        self.session = one.session
        d = one.d
        j = one.stat.render.image
        color, color1 = d[ok.COLOR_1], d[ok.COLOR_2]

        if d[ok.INVERT]:
            color = RenderHub.invert_color(color)
            color1 = RenderHub.invert_color(color1)

        lum = colorsys.rgb_to_hls(*color)[1]
        lum1 = colorsys.rgb_to_hls(*color1)[1]
        angle_of_slice = 360. / d[ok.NUMBER_OF_SLICES]
        steps = d[ok.NUMBER_OF_SLICES]
        w, h = one.session['size']
        cx, cy = w // 2., h // 2.
        a = d[ok.STARTING_ANGLE]
        self.group = Lay.group(j, one.k, parent=one.z.parent)

        if lum > lum1:
            color, color1 = color1, color

        step = RenderHub.calc_gradient(color, color1, steps)
        x, y = self.get_point_on_rectangle(a)
        start_color = color

        for spin in range(steps):
            a += angle_of_slice
            x1, y1 = self.get_point_on_rectangle(a)
            q = cx, cy, x, y

            if x == w and x1 != w:
                q += w, h

            elif y == h and y1 != h:
                q += 0, h

            elif x == 0 and x1 != 0:
                q += 0, 0

            elif y == 0 and y1 != 0:
                q += w, 0

            if y == 0 or y1 == 0:
                if y == h or y1 == h:
                    if a > 270:
                        q += w, h

                    else:
                        q += 0, 0

            if 0 in (x, x1):
                if w in (x, x1):
                    if a > 270:
                        q += w, 0

                    else:
                        q += 0, h

            q += x1, y1

            Sel.polygon(j, q, option=fu.CHANNEL_OP_REPLACE)

            x, y = x1, y1
            z = Lay.add(j, one.k, parent=self.group)

            Sel.fill(z, color)
            pdb.script_fu_clothify(
                j,
                z,
                cloth.BLUR_X_0,
                cloth.BLUR_Y_0,
                cloth.AZIMUTH_90,
                cloth.ELEVATION_70,
                cloth.DEPTH_1
            )

            if d[ok.INTENSITY] and d[ok.SHADOW_BLUR]:
                RenderHub.do_stylish_shadow(
                    one.stat,
                    z,
                    blur=d[ok.SHADOW_BLUR],
                    intensity=d[ok.INTENSITY]
                )

            q1 = [0] * 3

            for i in range(3):
                b = step[i] * (spin + 1)
                q1[i] = start_color[i] + int(b)
            color = tuple(q1)
        Lay.merge_group(j, self.group)

    def get_point_on_rectangle(self, angle):
        """
        Calculate an x, y coordinate for a point intersecting
        a ray, originating from the center of a rectangle,
        and ending at its defining lines.

        angle: float
            radians
            angle from center of the rectangle

        Return: point
            x, y
            of float or int
            the point on the rectangle
        """
        w, h = self.session['size']
        angle = math.radians(angle)
        sine = math.sin(angle)
        cosine = math.cos(angle)

        # distance to the top or the bottom edge (from the center):
        dy = h / 2 if sine > 0 else h / -2

        # distance to the left or the right edge (from the center):
        dx = w / 2 if cosine > 0 else w / -2

        # (distance to the vertical line) < (distance to the horizontal line):
        if abs(dx * sine) < abs(dy * cosine):
            # Calculate distance to the vertical line:
            dy = (dx * sine) / cosine

        # (distance to the top or the bottom edge)
        # < (distance to the left or the right edge):
        else:
            dx = (dy * cosine) / sine
        return max(0., round(dx + w / 2., 0)), max(0., round(dy + h / 2., 0))
