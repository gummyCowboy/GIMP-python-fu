#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import ForFormat as ff, OptionKey as ok
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class ColorFill:
    """Fill the backdrop with a color."""

    def __init__(self, one):
        """
        Do the Color Fill backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        z = one.z
        d = one.d
        q = d[ok.COLOR]
        a = RenderHub.invert_color(q) if d[ok.INVERT] else q
        s = one.session['size']
        x, y = RenderHub.get_layer_points(d, s[0], s[1])[:2]

        RenderHub.set_fill_context(d)
        pdb.gimp_context_set_foreground(a)
        pdb.gimp_drawable_edit_bucket_fill(z, fu.FOREGROUND_FILL, x, y)
        if d[ok.BUMP][ok.BUMP] == ff.HAS_BUMP:
            RenderHub.bump(j, Lay.clone(j, z), d[ok.BUMP])
