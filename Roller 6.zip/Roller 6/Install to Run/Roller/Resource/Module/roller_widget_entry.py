#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk
from roller_widget import Widget
import gtk  # type: ignore


class Entry(Widget):
    """Customize a GTK Entry."""
    change_signal = 'changed'
    has_table_label = True

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        g = gtk.Entry()

        Widget.__init__(self, g, **d)

        if wk.CHARS in d:
            g.set_width_chars(d[wk.CHARS])
        self.add(g)

    def get_a(self):
        """
        Get the value displayed in the Entry.

        Return: string
            from the gtk.Entry
        """
        return self.widget.get_text()

    def set_a(self, n):
        """
        Set the value displayed in the Entry.

        n: string
            give to the GTK Entry
        """
        self.widget.set_text("" if n is None else n)
        self.on_voter_change(self.widget)
