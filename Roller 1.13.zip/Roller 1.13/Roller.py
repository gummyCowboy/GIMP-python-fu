#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Script type: Python-fu
Script Title: Roller
Tested on GIMP version: 2.10.22; Windows 10, 64 bit; GTK 2.28.7

What is Does:
    Create image compositions like wallpaper.

Where The Script Installs:
    See the how-to file.

Get the latest version: github.com/gummycowboy
"""

from collections import OrderedDict
from copy import deepcopy
from os.path import expanduser
from random import choice, uniform
from random import randint as rnd
import cPickle
import gimp
import gimpfu as fu
import glob
import gobject
import gtk
import math
import os
import pango
import platform
import pygtk
import sys
pygtk.require("2.0")

program_title = "Roller 1.13"
DEBUG = 0

if DEBUG:
    # Creates a file and / or appends error messages and piped print statements:
    import time
    sys.stderr = open("D:\\roller_1_error.txt", 'a')
    print >> sys.stderr, "\nRoller 1,", time.ctime()

# constants:
ABLE = gtk.STATE_NORMAL
ACCEPT = 'accept'
ACT = 'activate'
ADD = fu.CHANNEL_OP_ADD

# alignment key:
Align = gtk.Alignment
ALL_X = 0, 0, 1, 0
ALL_Y = 0, 0, 0, 1

# Automate CheckButton key:
AUTO = "Automate"
BD_LIGHT = "Backdrop Light"
BB = "Blur Behind"
BD = "Backdrop"

# Backdrop Image key:
BD_IMG = 'bd_img'

# Backdrop Style key:
BD_STYLE = 'bd_style'
BG = "Border Gradient"
BL = "Border Line"
BLK = 0, 0, 0
BLUR = "Blur"
BORD = 'bord'
BORD_W = "Border Width"
BORD_TYP = "Border Type"
BOT = "Bottom"
BOTH = gtk.SIZE_GROUP_BOTH
C = 'c'

# preview layer margin:
C1 = 200, 200, 206

# preview cell margin:
C2 = 150, 156, 150

# preview image rectangle:
C3 = 106, 100, 100

# preview background:
C4 = 25, 25, 25

# preview cell lines:
C5 = 225, 225, 225
CANCEL = "Cancel"
CB = "Colored Board"
CE = "Center"
CELL_KEY = 'cell_key'
CELL_MARG = 'Cell Margins'
CF = "Color Fill"
CHG = 'changed'
CLF = "Clear Frame"
CLF_BG = CLF + " Background"
CLK = 'clicked'
CM_BOT = 'cm_bot'

# Cell Margin's cell table key:
CM_CELL = 'cm_cell'
CM_LEF = 'cm_lef'

# Cell Margins Per Cell Checkbutton key:
CM_PER = 'cm_per'
CM_RIG = 'cm_rig'
CM_TOP = 'cm_top'
COD = "Colored Diamonds"
COG = "Color Grid"
COL = "Column"
COLOR1 = "Color #1"
COLOR2 = "Color #2"
COLOR3 = "Shadow Color"
COORD = "Coordinates"
CORN = "Corners"
CRIT = "Criteria"
LINEAR = fu.INTERPOLATION_LINEAR

# file folder key:
DIR = 'dir'
DRAW = 'draw'
DEF = "Default"
DETAIL = "\tDetail"
DIM = "Dimensions"
DISPLAY = 'display'
DS = "Drop Shadow"
DUPE = "The file,\n\n{},\n\nalready exists. Do you want to overwrite?"
EFFECT = 'effect'
EFFECTS = 'effects'
EXIT = ": Use Escape or Enter"
PRESET_EXT = 1
FORMAT = "Format"
FORMAT_CNT = 'format_cnt'
FH = "Flip Horizontal"
FIL = "Fill Cell"
FIRST = "1st Image"
FLIP_H = 'flip_h'
FLIP_V = 'flip_v'
FLS = "Fill Light Shadow"
FONT = 'Sans-serif'
FV = "Flip Vertical"
GF = "Gradient Fill"
GRADIENT = "Gradient"
GRID = "Grid"
GRY = (127,) * 3
H = 'h'
HARD = fu.LAYER_MODE_HARDLIGHT
HBox = gtk.HBox

# Resolution Height Entry key:
HG = 'hg'
HOLD = "\tHold"
HORZ = 'horz'
ES = "Edge Shadow"
IMAGE = 'image'
IMG = 'img'
IMG_GRP = 'img_grp'
IMG_PLACE = "Image Placement"
IMG_PROP = "Image Properties"
PRESET_INT = 0
INHERIT = "Opacity\nInheritance"
INHERIT_D = {INHERIT: 1}
INTERNAL = 'internal'
INVERT = 'Invert'
IS = "Inlay Shadow"
KEY = 'key'
KEY_PRESS = 'key_press_event'
KLC = "Key-light Compliment"
KLS = "Key Light Shadow"
LAB_H = 'lab_h'
LAB_I = "w: ", "h: ", "x: ", "y: "
LAB_W = 'lab_w'
LAB_X = 'lab_x'
LAB_Y = 'lab_y'
LAY_MARG = 'Layer Margins'
LM_BOT = 'lay_bot'
LM_LEF = 'lay_lef'
LM_RIG = 'lay_rig'
LM_TOP = 'lay_top'
LAYER = 'layer'
LAYERS = 'layers'
LCK = "Locked"
LFT = "Left"
LIGHT = "Light Angle"
LIST_KEY = 'Return', 'Delete', 'space'
LOAD_ERR = "Roller was unable to load presets."
MARGIN = 18
MAX_COL = 65535

# Merge Cells table key:
ME_CELL = 'me_cell'
MERG_PER = 'merge'
MERGE_CELLS = "Merge Cells"
METHOD = 'Gradient Type'
MID = "Middle"
MIN_CELL = 4
MODE = "Paint Mode"
MULTIPLY = fu.LAYER_MODE_MULTIPLY
NAME = 'Name'
NON = "None"
NORM = "Normal"
NORMAL = fu.LAYER_MODE_NORMAL
NP = "No Picture"
NXT = "Next"
OFFSETX = 'Offset X'
OFFSETY = 'Offset Y'
OFFS = OFFSETX, OFFSETY
OP = 'Opacity'
OPT = 'opt'
OVERLAY = fu.LAYER_MODE_OVERLAY
PAD = 'pad'
PAD5 = [5, 5, 5, 5]
PARENT = 'parent'
PATTERN = 'Pattern'
PC = "Per Cell"
pdb = fu.pdb
PE = "Process"
PF = "Pattern Fill"
PG = "Pixelize Grid"
PIXL8 = "Align cells as pixelize"
PL_CELL = 'pl_cell'
PLACE_PER = 'place_per'
POSE = 'pose'
POWER = "\tPower"

# Properties cell table key:
PR_CELL = 'pr_cell'
PRESET = 'preset'
PRESET_SEP = "﹎"
PREVIEW = "Preview"
PREVIEW_BG = "Preview Background"
PREVIEW_OPT = 'preview_opt'
PROP_PER = 'prop_per'
R = 'r'
RAD = 'rad'
RANGE = 'range'
RAT = "Ratios"
RENDER = "Render"
REPLACE = fu.CHANNEL_OP_REPLACE
RESIZE = 'resize'
RGT = "Right"
ROT = "Rotate"
ROW = "Row"

# Scrollbar width, height:
SCROLL = 22
SEED = "Noise:\n\tSeed"
SELF_BG = 'self_bg'

# Session dict key:
SESS = "Session"
SHADOW = DS, ES, FLS, IS, KLS
SIZE = 'size'
STYLES = 'styles'
SUBTRACT = fu.CHANNEL_OP_SUBTRACT
TEXT = 'text'
THRESH = "Threshold"
TITLE = 'title'
TOP = "Top"
TOPL = MARGIN / 2, 0, MARGIN, MARGIN
TR = "Transparency"
TRM = "Trim"
UND = "〰 undefined 〰"
USE = "Last Used"

# cell table size:
V = 'v'
VALID_SB = ['Up', 'Down', 'Page_Up', 'Page_Down', 'Tab']
VBox = gtk.VBox
VERT = 'vert'
W = 'w'

# Set Wallpaper CheckButton key:
WH = 255, 255, 255

# Resolution Width Entry key:
WI = 'wi'

# Window positions dictionary key:
WIN = 'window'
X = 'x'
Y = 'y'

# left justify alignment:
ZERO = 0, 0, 0, 0

# Related keys:
CELL_K = ME_CELL, PL_CELL, CM_CELL, PR_CELL
CELL_SB_K = CM_TOP, CM_BOT, CM_LEF, CM_RIG
LAB_K = LAB_W, LAB_H, LAB_X, LAB_Y
LAY_SB_K = LM_TOP, LM_BOT, LM_LEF, LM_RIG
PER_CELL_K = PLACE_PER, CM_PER, PROP_PER
PLACE_K = RESIZE, HORZ, VERT, IMAGE
PROP_K = FLIP_H, FLIP_V, ROT, OP, BB
COLOR_K = ROW, COL, COLOR1, COLOR2, PIXL8
MOP_K = MODE, OP
LINE_K = STARTX, STARTY, ENDX, ENDY = "Start X", "Start Y", "End X", "End Y"
FILL_K = THRESH, MODE, CRIT, OP, STARTX, STARTY

# cell tuple indices:
RESIZE_X, IMAGE_X, HORZ_X, VERT_X = range(4)
FLIP_H_X, FLIP_V_X, ROTATE_X, OP_X, BB_X = range(5)
TOP_X, BOT_X, LEF_X, RIG_X = range(4)

# colors:
BG_BUTTON = gtk.gdk.Color(52000, 52000, MAX_COL)
BG_BUTTON_FOCUS = gtk.gdk.Color(50000, 50000, MAX_COL)
BG_CELL = gtk.gdk.Color(56000, 56000, MAX_COL)
BG_HEAD = 44000, 44000, MAX_COL
BG_GROUP = gtk.gdk.Color(54000, 54000, MAX_COL)

# options:
VRT = [TOP, MID, BOT]
HRZ = [LFT, CE, RGT]
RSZ = [FIL, LCK, NON, TRM]

# UICell-type overlay index:
PL_X, PR_X = 1, 3

# label text:
MARGINS = TOP, BOT, LFT, RGT

# The length of cell values and the cell table names correspond with CELL_K:
CELL_VALUE_W = 2, 4, 4, 5
CELL_TABLE_NAME = MERGE_CELLS, CELL_MARG, IMG_PLACE, IMG_PROP

GRAD_TYPE = (
    "Linear",
    "Bilinear",
    "Radial",
    "Square",
    "Conical Symmetric",
    "Conical ASymmetric",
    "Shape-burst-Angular",
    "Shape-burst-Spherical",
    "Shape-burst-Dimpled",
    "Spiral-Clockwise",
    "Spiral-Counter-Clockwise")

CRIT_LIST = (
    "Composite",
    "Red",
    "Green",
    "Blue",
    "Hue",
    "Saturation",
    "Value",
    "Alpha",
    "LCH-Lightness",
    "LCH-Chroma",
    "LCH Hue")

# global dictionary:
D = {CANCEL: 0, WIN: {}}

GRAD_D = {
    ENDX: 1920,
    ENDY: 1080,
    GRADIENT: DEF,
    INVERT: 0,
    METHOD: GRAD_TYPE[0],
    MODE: NORM,
    OP: 100,
    ROT: 0,
    STARTX: 0,
    STARTY: 0}

SHADOW_D = {
    BLUR: 30,
    COLOR3: BLK,
    INHERIT: 0,
    OFFSETX: .05,
    OFFSETY: .05,
    OP: 120}

# Layers Dict:
L = {}

"""
voilà! variables:
    a : part of a sequence, object, int
    b : see ‟a”
    c : see ‟a”, column
    d : dict
    e : dict
    f : float
    g : widget, window
    h : height
    i : iteration
    j : Img, gtk.image, iteration
    k : key
    m : flag
    n : string
    p : process
    q : iterable
    r : row
    s : size
    t : size
    u : point
    v : point
    w : width
    x : coordinate, index
    y : coordinate
    z : layer
"""


def create_2d_table(r, c, a=0):
    """
    Returns a 2D list.

    r, c: size of the table (integers)
    a: initial cell value
    """
    b = [a] * r

    for i in range(r):
        b[i] = [a] * c
    return b


def draw_color_grid(j, z, d):
    """
    Draws a checkerboard with two colors.

    Grid may look ugly if the resulting rectangles are too small.

    j: GIMP image
    z: layer
    d: dict with row, column, and ‟pixl8”

    Returns the merged layer.
    """
    w, h = j.width, j.height
    s = w, h
    r, c = d[ROW], d[COL]
    odd = Grid(s, r, c, pixl8=d[PIXL8])

    # Draw horizontal stripes:
    Lay.color_fill(z, WH)

    D[W] = w
    D[X] = 0

    for r1 in range(0, r, 2):
        _, D[Y], _, D[H] = odd.cell(r1, 0)
        Sel.rect(j)

    Sel.fill(z, BLK)
    Sel.none(j)

    # Draw vertical stripes:
    z1 = Lay.add(j, "V")
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    Lay.color_fill(z1, WH)

    D[H] = h
    D[Y] = 0

    for c1 in range(0, c, 2):
        D[X], _, D[W], _ = odd.cell(0, c1)
        Sel.rect(j)

    Sel.fill(z1, BLK)

    z = Lay.merge(j, z1)
    z1 = Lay.dupl(j, z)

    # Fill the b/w checkerboard:
    Sel.color(j, z1, WH)
    Sel.fill(z1, d[COLOR1])
    Sel.invert(j)
    klear(z1)
    Lay.color_fill(z, d[COLOR2])

    z = Lay.merge(j, z1)

    Sel.none(j)
    return z


def edge_color(q):
    """
    Returns an edge color for a color.

    q: color
    """
    q1 = [0] * 3

    for x, a in enumerate(q):
        q1[x] = 0 if a > 127 else 255
    return tuple(q1)


def ensure_dir(n):
    """
    Ensures a directory exists.

    n: path

    Returns two flags.
        error flag
        proceed flag
    """
    go = err = 0

    if not os.path.isdir(os.path.dirname(n)):
        try:
            os.makedirs(os.path.dirname(n))

        except Exception as ex:
            err = 1
            if d['show']:
                show_err(ex)
                show_err("Roller is unable to store files at\n" + n)

    else:
        go = 1
    return err, go


def float_to_layer(j, z):
    """
    Converts a floating selection to a layer.

    j: GIMP image
    z: floating selection

    Returns the layer.
    """
    pdb.gimp_floating_sel_to_layer(z)
    return pdb.gimp_image_get_active_layer(j)


def info_msg(msg):
    """ Used to output messages to the error console. """
    a = pdb.gimp_message_get_handler()

    pdb.gimp_message_set_handler(fu.ERROR_CONSOLE)
    fu.gimp.message(msg)
    pdb.gimp_message_set_handler(a)


def klear(z):
    """
    Clears a layer or a selection.

    z: drawable
    """
    pdb.gimp_edit_clear(z)


def kopy(j):
    """
    Copies an image.

    j: GIMP image
    """
    pdb.gimp_edit_copy_visible(j)


def merge_dict(d, e):
    """
    d, e: dict

    returns a merged dictionary.
    """
    d1 = deepcopy(d)

    # ‟e” over-writes:
    d1.update(e)
    return d1


def merge_shadow(k):
    """
    Copies the drop shadow and merges it with another layer.

    This is used by translucent layers that blur behind.

    Returns the new layer.
    """
    j = D[RENDER]

    Sel.item(j, L[k])

    _, x, y, _, _ = pdb.gimp_selection_bounds(j)

    Sel.kopy(L[DS])

    z = Lay.paste(j, L[k], xy=(x, y))
    z.mode = MULTIPLY
    return Lay.merge(j, z)


def pass_version(d, e, is_format=0):
    """
    Adds missing dictionary items.

    Removes invalid dictionary items.

    Validates cell data length.

    Calls itself recursively.

    d: session dict
    e: default dict
    is_format: flag: If it's true, the session dict is a format type.
    """
    keys = []

    # Remove old:
    for k in d:
        if k not in e:
            keys.append(k)

    [d.pop(k) for k in keys]

    # Add new:
    for k in e:
        if k not in d:
            d[k] = deepcopy(e[k])

    if is_format:
        # Checks the cell value lengths:
        for x, k in enumerate(CELL_K):
            if d[k]:
                invalid = 0
                for r in range(len(d[k])):
                    for c in range(len(d[k][r])):
                        q = d[k][r][c]
                        if len(q) != CELL_VALUE_W[x]:
                            # The cell table is invalid:
                            invalid = 1
                            info_msg(
                                "A cell table was invalid:\n"
                                + d[NAME] + ": "
                                + CELL_TABLE_NAME[x] + ",\n"
                                "and was erased.")
                            break
                    if invalid:
                        break
                if invalid:
                    d[k] = None

    # Do sub-dictionaries:
    for k in d:
        if k != WIN:
            if isinstance(d[k], dict):
                pass_version(d[k], e[k])


def pickle_dump(d):
    """
    Writes a file using ‟cPickle”.

    d: dict

    Returns a flag, which is set to true if the operation succeeded.
    """
    a = 0
    n = d['file']
    err, go = ensure_dir(n)

    if not err:
        try:
            with open(n, "wb") as output_file:
                cPickle.dump(d['data'], output_file)
            a = 1

        except Exception as ex:
            show_err(ex)
            show_err("Roller is unable to save\n" + n)
    return a


def pickle_load(d):
    """
    Reads a ‟cPickle” type file.

    d: dict

    Returns ‟e” as the data read by
    ‟cPickle” or None if the operation failed.
    """
    e = None
    n = d['file']

    err, go = ensure_dir(n)

    if go and not err:
        try:
            with open(n, "rb") as input_file:
                e = cPickle.load(input_file)
                if not isinstance(e, dict):
                    # failure:
                    e = {}

        except Exception as ex:
            if d['show']:
                show_err(ex)
                show_err("Roller is unable to load\n" + n)
    return e


def pixelize(j, z, w, h):
    pdb.plug_in_pixelize2(j, z, w, h)


def prefix():
    """ Returns the format name in a prefix form. """
    return L[FORMAT].name + ": "


def random_rc():
    """ Returns randomized row and column counts. """
    w, h = D[WI] / MIN_CELL, D[HG] / MIN_CELL
    w1, h1 = min(w, 12), min(h, 12)
    w2, h2 = min(w1, 24), min(h1, 24)
    w3, h3 = min(w2, 36), min(h2, 36)
    return rnd(
        1, rnd(h1, rnd(h2, rnd(h3, h)))), rnd(1, rnd(w1, rnd(w2, rnd(w3, w))))


def rnd_col():
    """ Returns a tuple of integers containing random colors (r, g, b). """
    return rnd(0, 255), rnd(0, 255), rnd(0, 255)


def seal(a, b, c):
    """
    Limits a value to be between two numbers.

    a: value to limit
    b: minimum value
    c: maximum value
    """
    return max(min(c, a), b)


def set_antialias(m=True):
    """
    Sets the anti-aliasing context.

    m: flag: When it's true, anti-aliasing and transparency
        sampling are turned on.
    """
    pdb.gimp_context_set_antialias(m)
    pdb.gimp_context_set_sample_transparent(m)


def shadow(j, item, x, y, blur, color, op, n, d=None, m=0):
    """
    Draws a drop shadow.

    j: GIMP image
    z: layer
    x: float
        offset x

    y: float
        offset y

    blur: float
    color: (R, G, B)
        shadow color

    op: opacity (0..200)
    n: owner's name
        Used to name the shadow layer.

    d: dict with INHERIT key
    m: flag: if true, the selection is inverted

    Returns the new shadow layer.
    """
    item = Lay.dupl(j, item)

    if op:
        grp = Lay.group(j, "Shadow", a=0)

        Lay.order(j, item, grp)

        if m:
            z1 = Lay.add(j, "Inlay", z=grp)

            Lay.color_fill(z1, WH)

            z2 = Lay.selectable(j, item, d)

            Sel.item(j, z2)
            klear(z1)
            Lay.bury(j, item)
            Lay.bury(j, z2)
            item = z1

        Sel.item(j, item)

        while op:
            pdb.script_fu_drop_shadow(
                j,
                item,
                x,
                y,
                blur,
                color,
                op,
                0)     # resize image
            op -= min(op, 100)

        z = Lay.eat(j, grp)
        z.mode = MULTIPLY
        z.name = n

        klear(z)
        Sel.none(j)

    else:
        return None
    return z


def show_err(a):
    """
    Posts an error message to GIMP's Error Console.

    a: Exception or string
    """
    if not isinstance(a, basestring):
        a = repr(a)
    info_msg(a)


class Mode:
    _q = [
        (NORM, NORMAL),
        ("Dissolve", fu.LAYER_MODE_DISSOLVE),
        ("Color Erase", fu.LAYER_MODE_COLOR_ERASE),
        ("Erase", fu.LAYER_MODE_ERASE),
        ("Merge", fu.LAYER_MODE_MERGE),
        ("Split", fu.LAYER_MODE_SPLIT),
        ("★", None),
        ("Lighten Only", fu.LAYER_MODE_LIGHTEN_ONLY),
        ("Luma Lighten Only", fu.LAYER_MODE_LUMA_LIGHTEN_ONLY),
        ("Screen", fu.LAYER_MODE_SCREEN),
        ("Dodge", fu.LAYER_MODE_DODGE),
        ("Addition", fu.LAYER_MODE_ADDITION),
        ("★★", None),
        ("Darken Only", fu.LAYER_MODE_DARKEN_ONLY),
        ("Luma Darken Only", fu.LAYER_MODE_LUMA_DARKEN_ONLY),
        ("Multiply", MULTIPLY),
        ("Burn", fu.LAYER_MODE_BURN),
        ("Linear Burn", fu.LAYER_MODE_LINEAR_BURN),
        ("★ ", None),
        ("Overlay", OVERLAY),
        ("Hard Light", HARD),
        ("Soft Light", fu.LAYER_MODE_SOFTLIGHT),
        ("Vivid Light", fu.LAYER_MODE_VIVID_LIGHT),
        ("Pin Light", fu.LAYER_MODE_PIN_LIGHT),
        ("Linear Light", fu.LAYER_MODE_LINEAR_LIGHT),
        ("Hard Mix", fu.LAYER_MODE_HARD_MIX),
        (" ★", None),
        ("Difference", fu.LAYER_MODE_DIFFERENCE),
        ("Exclusion", fu.LAYER_MODE_EXCLUSION),
        ("Subtract", fu.LAYER_MODE_SUBTRACT),
        ("Divide", fu.LAYER_MODE_DIVIDE),
        ("Grain Extract", fu.LAYER_MODE_GRAIN_EXTRACT),
        ("Grain Merge", fu.LAYER_MODE_GRAIN_MERGE),
        ("★★★", None),
        ("LCH-Lightness", fu.LAYER_MODE_LCH_LIGHTNESS),
        ("LCH-Chroma", fu.LAYER_MODE_LCH_CHROMA),
        ("LCH-Hue", fu.LAYER_MODE_LCH_HUE),
        ("LCH-Color", fu.LAYER_MODE_LCH_COLOR),
        ("Luminance", fu.LAYER_MODE_LUMINANCE),
        ("★★ ", None),
        ("HSV-Hue", fu.LAYER_MODE_HSV_HUE),
        ("HSV-Saturation", fu.LAYER_MODE_HSV_SATURATION),
        ("HSV-Value", fu.LAYER_MODE_HSV_VALUE),
        ("HSL-Color", fu.LAYER_MODE_HSL_COLOR)]

    def __init__(self):
        self.d = OrderedDict(Mode._q)

    def get_x(self, k):
        """
        Returns the integer value of a mode string.

        k: mode
        """
        return self.d[k]

    def names(self):
        """ Returns an ordered list of keys in MODES dict. """
        return [n for n in self.d]

    def rand(self):
        """ Returns a randomly selected mode (int). """
        n = "★"
        q = self.names()

        while "★" in n:
            n = choice(q)
        return n


class Grid:
    """
    Calculates the coordinates and the size of cells.

    Cells are created when a canvas is divided by rows and columns.

    If ‟pixl8” is true, the width and column division remainders are
    applied to the beginning of the grid consecutively. This is technique
    is used by Pixl8 to align cells as pixelize. This method is
    initiated by backdrop styles that use Pixl8.

    If ‟pixl8” is false, the width and column division remainders are applied
    to every other cell starting from the cell at (0, 0).
    """
    pixl8 = 0

    def __init__(self, s, r, c, pixl8=None):
        """
        s: size of the grid
        r, c: row and column scales of the grid
        pixl8: flag: When it is true the cells
            are calculated to with a modified pixelize.
        """
        r, c = min(r, D[HG]), min(c, D[WI])
        self.r, self.c = r, c

        if pixl8 is not None:
            Grid.pixl8 = pixl8

        # Calculate cell size.
        # Converting to float prevents int underflow:
        w = self.w = int(max(s[0] / 1.0 / c, 1))
        h = self.h = int(max(s[1] / 1.0 / r, 1))

        # Calculate remainders:
        rx = rx1 = self.rx = s[0] % c
        ry = ry1 = self.ry = s[1] % r
        q = self.tb = create_2d_table(r, c)
        x = y = 0

        if pixl8:
            for r1 in range(r):
                h1 = 0

                if ry1:
                    h1 = 1
                    ry1 -= 1

                for c1 in range(c):
                    w1 = 0

                    if rx1:
                        w1 = 1
                        rx1 -= 1

                    q[r1][c1] = x, y, w + w1, h + h1
                    x += w + w1

                x = 0
                rx1 = rx
                y += h + h1

        else:
            """
            ‟ax” and ‟ay” are insertion points for the remainders.
            The points range is (0..1).

            Cells are compared with the insertion points by their
            position along both axis. The cells position point
            is the cell's bottom-right point in a row and column position.

            The cell position points range from zero to one (0..1).
            """
            ay = ay1 = 1 / (ry + 1.) if ry else 2
            ax1 = 1 / (rx + 1.) if rx else 2
            f, f1 = r / 1., c / 1.

            for r1 in range(r):
                ax = ax1
                h1 = 0

                if (r1 + 1) / f >= ay:
                    h1 = 1
                    ay = ay + ay1 if ay + ay1 < .9999999 else 2

                for c1 in range(c):
                    w1 = 0
                    if (c1 + 1) / f1 >= ax:
                        w1 = 1
                        ax = ax + ax1 if ax + ax1 < .9999999 else 2

                    q[r1][c1] = x, y, w + w1, h + h1
                    x += w + w1

                x = 0
                y += h + h1

    def block(self, u, v):
        """
        Used when cells are merged, and the merge
        cell's dimension needs to be determined.

        u: top-left cell, (r, c)
        v: bottom-right cell, (r, c)

        Returns the top-left coordinates and the scale of an array of cells.
        """
        r1, c1 = u
        x, y, _, _ = self.cell(r1, c1)

        x1, y1, _, _ = self.cell(r1, c1)
        x2, y2, w3, h3 = self.cell(v[0], v[1])

        w = x2 - x1 + w3
        h = y2 - y1 + h3
        return x, y, w, h

    def cell(self, r, c):
        """ Returns the x, y, w, h of a cell at r, c. """
        return self.tb[r][c]


class Pixl8:
    """ Pixelates an image using row and column variables. """

    @staticmethod
    def do(r, c, z):
        """
        Pixelates using rows and columns.

        r, c: row, column
        z: target layer

        Returns the new target layer.
        """
        j = D[RENDER]
        z2 = z3 = z4 = 0
        s = D[SIZE]
        odd = Grid(s, r, c, pixl8=1)
        _, _, w, h = odd.cell(0, 0)
        x, y = odd.rx, odd.ry

        # Distribute the extra pixels here thanks to ‟odd”:
        z1 = z6 = last = Lay.dupl(j, z)
        z1.name = "1"
        pixelize(j, z1, w, h)

        if x or y:
            D[X], D[Y], D[W], D[H] = odd.block((0, 0), (y - 1, x - 1))
            Pixl8.rect(j, z1)

            _, _, w1, h1 = odd.cell(r - 1, c - 1)

            if x:
                # right-side:
                z2 = last = Lay.dupl(j, z)
                z2.name = "2"

                pixelize(j, z2, w1, h)
                Lay.move(z2, x, 0)

                D[X], D[Y], D[W], D[H] = odd.block((0, x), (y - 1, c - 1))
                Pixl8.rect(j, z2)

            if y:
                # bottom:
                z3 = last = Lay.dupl(j, z)
                z3.name = "3"

                pixelize(j, z3, w, h1)
                Lay.move(z3, 0, y)

                D[X], D[Y], D[W], D[H] = odd.block((y, 0), (r - 1, x - 1))
                Pixl8.rect(j, z3)

            if x and y:
                # bottom-right:
                z4 = last = Lay.dupl(j, z)
                z4.name = "4"

                pixelize(j, z4, w1, h1)
                Lay.move(z4, x, y)

                D[X], D[Y], D[W], D[H] = odd.block((y, x), (r - 1, c - 1))
                Pixl8.rect(j, z4)

        for z5 in (z4, z3, z2, z1):
            if z5:
                if z5 != last:
                    z6 = last = Lay.merge(j, z5)
        return z6

    @staticmethod
    def rect(j, z):
        """
        Clears the layer of everything but the rectangle selection.

        j: GIMP image
        z: layer
        """
        Sel.rect(j)
        Sel.invert(j)
        klear(z)
        Sel.none(j)


class Wig:
    """ This is the base widget for the custom widgets. """

    def __init__(self, p, **d):
        """
        p: callback function
        d: dict
        """
        self.feed = p
        self.wig = d['g']
        self.key = d['k'] if 'k' in d else None
        self.lab = d['lab'] if 'lab' in d else None

    def callback(self, *_):
        """ The widget changed. """
        self.feed(self)

    def enable(self, *_):
        """ Makes the widget operational. """
        self.wig.set_sensitive(1)
        if self.lab:
            self.lab.set_sensitive(1)

    def disable(self, *_):
        """ Makes the widget inoperable. """
        self.wig.set_sensitive(0)
        if self.lab:
            self.lab.set_sensitive(0)


class FormatList(Wig):
    """
    This is widget group with TreeView and TreeView manipulation Buttons.
    """

    def __init__(self, g, p, p1, p2):
        """
        Adds the format list and Buttons to a group.

        g: container
        d: dict
        p: on new function
        p1: on edit function
        p2: on change function
        """
        w = MARGIN
        self.buttons = []
        self.items = []
        self.do_new_format = p
        self.do_edit_format = p1
        g1 = RBox(1)

        # Format Stack TreeView:
        self.store = gtk.ListStore(str)

        g3 = gtk.TreeView(model=self.store)
        g3.set_headers_visible = 0

        Wig.__init__(self, p2, k=FORMAT, g=g3)

        # Create column:
        col = gtk.TreeViewColumn(
            "Format Stack:", gtk.CellRendererText(), text=0)

        col.set_min_width(120)
        col.set_sizing(gtk.TREE_VIEW_COLUMN_AUTOSIZE)

        # Add column to TreeView:
        g3.append_column(col)

        # When a row is selected, it emits a signal:
        g3.get_selection().connect(CHG, self.selected)
        g3.connect(KEY_PRESS, self.on_key_press)
        g1.g.set_padding(w / 2, w, w, w)

        g4 = RBox(2, align=ALL_Y, pad=(0, 0, MARGIN / 2, 0))
        a = zip(
            ("New Format", "Edit Format", "Del Format", "Move Up", "Move Down"),
            (
                self.create_format,
                self.edit_format,
                self.del_format,
                self.move_sel_up,
                self.move_sel_down),
            (0, 1, 1, 2, 2))

        for n, p, b in a:
            g6 = CoOpButton(n, p, b)
            g4.add(g6.g)
            self.buttons.append(g6)

        g7 = gtk.ScrolledWindow()

        g7.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        g7.add_with_viewport(g3)
        g1.add(g7)
        g1.add(g4.g)
        g.add(g1.g)
        self.verify_buttons()

    def create_format(self, *_):
        """ Called when the user activated the New Format Button. """
        q = self.items
        n = FORMAT
        a = len(q) + 1
        go = 1

        while go:
            go = 0
            n1 = n + " " + str(a)
            for i in q:
                if i[0] == n1:
                    a += 1
                    go = 1
                    break

        self.store.append([n1])
        q.append((n1, len(q)))
        self.verify_buttons()
        self.select_item(len(q) - 1)
        self.do_new_format(n1)

    def del_format(self, *_):
        """ Deletes a row in the TreeView. """
        self.items.pop(self.get_sel_x())

        # model, iter:
        a, b = self.wig.get_selection().get_selected()

        a.remove(b)
        self.feed()

    def edit_format(self, *_):
        """ Called because the user clicked the Edit Button. """
        self.do_edit_format()

    def get_sel_x(self):
        """ Returns the row index of the selected item. """
        return self.wig.get_selection().get_selected_rows()[1][0][0]

    def get_sel_text(self):
        """ Returns the selected format name. """
        return self.items[self.get_sel_x()][0]

    def get_val(self):
        """ Returns a list of strings displayed in the list. """
        return self.items

    def load(self, q):
        """
        Populates the TreeView from a list.
        The previous index is replaced.

        q: list of tuples (name, index)
        """
        self.store.clear()
        self.items = []
        for x, b in enumerate(q):
            self.store.append([b[0]])
            self.items.append((b[0], x))

    def move_sel_down(self, *_):
        """
        Called when the user activates the Move Down Button.

        Moves selections down one line in the TreeView.

        If x selection is at the bottom of the list,
        then the item rotates to the top of the list.
        """
        x = x1 = self.get_sel_x()
        a = len(self.items)
        x += 1

        if x == a:
            x = 0
        self.shuffled(x, x1)

    def move_sel_up(self, *_):
        """
        Called when the user activated the Move Up Button.

        Moves selections up one line in the TreeView.

        If ‟x” selection is at the top of the list, then
        the item rotates to the bottom of the list.
        """
        x = x1 = self.get_sel_x()
        a = len(self.items)
        x -= 1

        if x < 0:
            x = a - 1
        self.shuffled(x, x1)

    def on_key_press(self, _, a):
        """
        Used to catch delete and return key.

        a: key-press event
        """
        n = gtk.gdk.keyval_name(a.keyval)
        if len(self.items):
            if n in LIST_KEY:
                x = LIST_KEY.index(n)

                (self.edit_format, self.del_format, self.selected)[x]()
                return 1

    def rename(self, x, n):
        """
        Renames a format.

        x: the current list entry index
        n: name of format
        """
        self.items[x] = n, self.items[x][1]
        self.load(self.items)

    def selected(self, *_):
        """ Called when a selection event occurs. """
        self.verify_buttons()

    def select_item(self, x):
        """
        Selects, sort of, a TreeView item.

        x: row index in the TreeView
        """
        self.wig.set_cursor(x)

    def set_indices(self):
        """
        Updates the ‟self.items” indices.

        This is called after the Session
        dictionary's format list is re-ordered.
        """
        for i in range(len(self.items)):
            self.items[i] = self.items[i][0], i

    def set_val(self, q):
        """
        Loads the format list from a session dictionary's list of formats.

        q: list of formats from the session dict.
        """
        b = []
        for d in q:
            b.append((d[NAME], 0))
        self.load(b)

    def shuffled(self, x, x1):
        """
        Selects a TreeView item by index.

        Re-orders the list.

        x: new position (int)
        x1: old position
        """
        q = self.items[x1]

        self.items.pop(x1)
        self.items.insert(x, q)
        self.feed()
        self.load(self.items)
        self.select_item(x)

    def verify_buttons(self):
        """ Validates Buttons that are dependent on the list quantity. """
        a, b = self.wig.get_selection().get_selected()

        # The move and delete Buttons are dependent
        # on their selection state and the list size:
        for g in self.buttons[1:]:
            if b and len(self.items) >= g.need:
                g.enable()

            else:
                g.disable()


class RBox:
    """ This is a GTK Box widget with an Alignment. """

    def __init__(self, x, align=ZERO, pad=None):
        """
        x: index to box where 0 is a VBox, 1 is a HBox, 2 is a VButtonBox
        align: Alignment tuple (f, f, f, f)
        pad: padding tuple (TBLR)
        """
        g = self.g = Align(*align)
        g1 = self.box = (VBox, HBox, gtk.VButtonBox)[x]()

        if pad:
            g.set_padding(*pad)
        g.add(g1)

    def add(self, g):
        """ g: widget """
        self.box.add(g)


class RButton(Wig):
    """ This is a custom GTK Button. """

    def __init__(self, n, p, padx=0, align=ALL_X):
        """
        n: Button label
        p: callback function
        padx: index to padding
        """
        w = MARGIN
        w1, w2 = w / 2, w / 4
        g = self.g = Align(*align)
        g1 = gtk.Button(n)

        Wig.__init__(self, p, g=g1)
        g1.connect(CLK, self.callback)
        g.add(g1)

        if not isinstance(padx, int):
            g.set_padding(*padx)

        elif padx:
            x = padx - 1
            g.set_padding((
                w1, w2, w2)[x],
                (0, 0, w1)[x],
                w,
                w)


class RCheckButton(Wig):
    """ This is a custom GTK CheckButton. """

    def __init__(self, n, p, k=None, pad=0):
        """
        n: label text
        p: callback function
        k: widget key
        pad: flag: true results in padding
        """
        w = MARGIN
        g = self.g = Align(*ZERO)
        g1 = gtk.CheckButton(label=n)

        Wig.__init__(self, p, k=k, g=g1)

        g.add(g1)
        g1.connect(CLK, self.callback)
        g1.connect(ACT, self.callback)

        if pad:
            g.set_padding(w / 2, w / 2, w, w)
        g1.connect(CLK, self.callback)

    def get_val(self):
        """ Returns the value of the CheckButton. """
        return int(self.wig.get_active())

    def set_val(self, a):
        """
        Sets the CheckButton checked state.

        a: int
        """
        self.wig.set_active(a)


class RColorButton(Wig):
    """ This is a color button that opens a color-chooser dialog. """

    def __init__(self, p, q, k):
        """
        p: unused
        q: color (r, g, b)
        k: widget key
        """
        w = MARGIN
        g = self.g = Align(*ALL_X)
        g1 = gtk.ColorButton(color=RColorButton.convert(q))

        Wig.__init__(self, p, k=k, g=g1)
        g1.connect(CLK, self.callback)
        g.add(g1)
        g.set_padding(w / 2, w / 2, 0, 0)

    @staticmethod
    def convert(q):
        """
        Convert COLOR to GdkColor.

        q: (r, g, b) (0..255)
        """
        q = [i / 255. for i in q]
        return gtk.gdk.Color(*q)

    def get_val(self):
        """ Returns the value of the button as (r, g, b) (0..255). """
        a = self.wig.get_color()
        return tuple([int(i / 256) for i in (a.red, a.green, a.blue)])

    def set_val(self, q):
        """
        Sets the color of the button.

        q: color: (r, g, b): (0..255)
        """
        self.wig.set_color(self.convert(q))


class RCombo(Wig):
    """ Used by RComboBox and RComboBoxE. """

    def __init__(self, p, sub, **d):
        """
        p: callback function
        sub: sub-class
        d: dict
        """
        w = MARGIN
        self.opt = []
        self.length = 0
        g = self.g = Align(*ALL_X)

        self.store = gtk.ListStore(str)
        g1 = d['g'] = sub(self.store)

        Wig.__init__(self, p, **d)

        a = gtk.CellRendererText()
        a.props.ellipsize = pango.ELLIPSIZE_END

        g1.pack_start(a)
        g.add(g1)

        if sub == gtk.ComboBox:
            g1.add_attribute(a, 'text', 0)

        else:
            g1.child.set_editable(0)

        if 'padx' in d:
            if d['padx']:
                # ‟padx” is (1..2):
                x = d['padx'] - 1
                g.set_padding(0, (0, w / 2)[x], w, w)
        if 'opt' in d:
            self.load(d['opt'])

    def get_val(self):
        """ Returns the activated item in the ComboBox. """
        return self.opt[self.wig.get_active()]

    def load(self, q):
        """
        Sets the options the ComboBox.

        q: iter of option strings
        """
        self.store.clear()

        self.opt = q

        for n in q:
            self.store.append([n])
        self.length = len(q)

    def set_val(self, n):
        """
        Sets the ComboBox display.

        n: string to display
        """
        if n in self.opt:
            x = self.opt.index(n)

        else:
            x = 0
        self.wig.set_active(x)


class RComboBox(RCombo):
    """ This ComboBox displays options. """

    def __init__(self, p, **d):
        """
        p: callback function
        d: dict
        """
        RCombo.__init__(self, p, gtk.ComboBox, **d)
        self.wig.connect(CHG, self.callback)
        self.wig.set_row_separator_func(self.set_mode_separator)

    def set_mode_separator(self, model, itr):
        n = model.get_value(itr, 0)
        return "★" in n


class RComboBoxE(RCombo):
    """ This ComboBox displays options and text using an Entry. """

    def __init__(self, p, **d):
        """
        p: callback function
        d: dict
        """
        RCombo.__init__(self, p, gtk.ComboBoxEntry, **d)
        self.wig.child.connect(CHG, self.callback)

    def get_text(self):
        """
        Returns the value displayed in the Entry.

        n: text
        """
        return self.wig.child.get_text()

    def set_text(self, n):
        """
        Sets the text in the Entry.

        n: text
        """
        self.wig.child.set_text(n)


class REntry(Wig):
    """ This is a custom GTK Entry. """

    def __init__(self, p, k, padx=0):
        """
        p: callback function
        k: widget's key
        padx: index to padding
        """
        w = MARGIN
        g = self.g = Align(*ALL_X)
        g1 = gtk.Entry(100)

        Wig.__init__(self, p, k=k, g=g1)
        g.add(g1)
        g1.connect(CHG, self.callback)
        if padx:
            g.set_padding(0, (0, w / 2)[padx - 1], w, w)

    def get_val(self):
        """ Returns the value displayed in the Entry. """
        return self.wig.get_text()

    def set_val(self, n):
        """
        Sets the value displayed in the the Entry.

        n: string to place in the Entry
        """
        self.wig.set_text(n)


class REventBox(gtk.EventBox):
    """ This is a custom GTK EventBox. """

    def __init__(self, a):
        """
        a: gtk color component
            None, int, tuple, or GTK color
        """
        super(gtk.EventBox, self).__init__()
        if a is not None:
            if isinstance(a, int):
                q = gtk.gdk.Color(a, a, MAX_COL)

            elif isinstance(a, tuple):
                q = gtk.gdk.Color(*a)

            else:
                q = a
            self.modify_bg(ABLE, q)


class RLabel:
    """ This is a custom GTK Label. """

    def __init__(self, n, pad=ZERO, align=ZERO):
        """
        n: label text
        a: padding tuple (top, bottom, left, right)
        """
        g = self.lab = gtk.Label(n)
        g1 = self.g = Align(*align)

        g1.set_padding(*pad)
        g1.add(g)

    def destroy(self):
        """ Destroys the internal widgets. """
        self.lab.destroy()
        self.g.destroy()


class RRadio:
    """ Used to manage a group of RadioButtons. """

    def __init__(self, q, k):
        """
        q: group of RRadioButtons
        k: widget group key
        """
        self.q = q
        self.key = k

    def get_val(self):
        """
        Finds the active RadioButton and returns its index.
        """
        for x, g in enumerate(self.q):
            if g.get_val():
                return x

    def set_val(self, x):
        """
        Sets a RadioButton in the group as active.

        x: index into group
        """
        self.q[x].set_val(1)


class RRadioButton(Wig):
    """ This is GTK RadioButton attached to an Alignment. """

    def __init__(self, p, n, k, group):
        """
        p: callback function
        n: label text
        k: widget key
        group: first widget in the button group or None
        x: index in group
        """
        g = self.g = Align(*ALL_X)
        g1 = gtk.RadioButton(group, n)

        Wig.__init__(self, p, k=k, g=g1)

        g1.connect("toggled", self.callback)
        g.add(g1)

    def get_val(self):
        """ Returns the value of the RadioButton. """
        return self.wig.get_active()

    def set_val(self, a):
        """
        Sets the value of the RadioButton.

        a: int (0..1)
        """
        self.wig.set_active(a)


class RSpinButton(Wig):
    """ This is a custom GTK SpinButton. """

    def __init__(self, p, q, k=None, q1=(1, 1), padx=0, lab=None, f=0):
        """
        p: callback function
        q: range tuple
        k: widget key
        q1: increments tuple
        padx: index to padding (0..2)
        lab: label that is attached to the SpinButton
        f: int flag: If it's true, then the SpinButton uses float values.
        """
        w = MARGIN
        w1 = w / 2
        self.float = f
        g = self.g = Align(*ALL_X)
        g1 = gtk.SpinButton(
            adjustment=None,
            climb_rate=(2, .02)[f],
            digits=(0, 3)[f])

        Wig.__init__(self, p, k=k, g=g1, lab=lab)

        # Tell the SpinButton to respond to click events:
        for i in (
                gtk.gdk.BUTTON_RELEASE_MASK,
                gtk.gdk.BUTTON_PRESS_MASK):
            g1.add_events(i)

        g.add(g1)
        g1.set_range(*q)
        g1.set_increments(*q1)
        g1.connect('button_press_event', self.focus_in)
        g1.connect('value_changed', self.callback)
        g1.connect('key_release_event', self.key_handler)
        if padx:
            x = padx - 1
            g.set_padding((0, 0, w1)[x], (0, w1, w1)[x], w, w)

    def focus_in(self, *_):
        """
        Improves focus handling.

        Corrects an invalid numeric.
        """
        self.wig.grab_focus()
        self.set_val(self.get_val())

    def get_val(self):
        """ Returns the value of the SpinButton. """
        n = self.wig.get_text()
        a = n if n.isdigit() else self.wig.get_value()

        if not self.float:
            a = int(a)
        return a

    def key_handler(self, _, a):
        """
        Keeps arrow and page key events from signaling twice.

        a: key release event
        """
        n = gtk.gdk.keyval_name(a.keyval)

        if n in VALID_SB:
            return
        self.callback()

    def set_val(self, a):
        """
        Sets the SpinButton display value.

        a: int or float
        """
        self.wig.set_value(a / 1.)


class CoOpButton(RButton):
    """
    This Button has an extra variable, ‟self.need”.
    ‟self.need” is the number of items in a list
    needed for the Button to be valid.
    """

    def __init__(self, n, p, a):
        """
        n: label
        p: callback function
        a: the number of items needed for this Button to be valid
        """
        self.need = a
        RButton.__init__(self, n, p)


class ColoredButton(gtk.EventBox):
    """ This Button changes color. """

    def __init__(self, n, p):
        """
        n: button text
        p: callback function
        """
        super(ColoredButton, self).__init__()

        self.feed = p

        # Embed widget inside VBox and HBox:
        g = self.label = gtk.Label(n)
        g1 = self.hbox = HBox()

        self.add(g1)
        g1.add(g)

        # events to react to:
        a = gtk.gdk
        p = self.connect

        for i in (
                a.BUTTON_RELEASE_MASK,
                a.BUTTON_PRESS_MASK,
                a.ENTER_NOTIFY_MASK,
                a.LEAVE_NOTIFY_MASK,
                a.FOCUS_CHANGE_MASK,
                a.KEY_PRESS_MASK,
                a.KEY_RELEASE_MASK):
            self.add_events(i)

        self.set_can_focus(1)
        p('button_press_event', self.on_click)
        p(KEY_PRESS, self.on_key_press)
        p('focus_in_event', self.focus_in)
        p('focus_out_event', self.focus_out)

    def focus_in(self, *_):
        """ Called when the EventBox receives focus. """
        self.set_color(BG_BUTTON_FOCUS)

    def focus_out(self, *_):
        """ Called when the EventBox loses focus. """
        self.set_color(BG_BUTTON)

    def on_click(self, g, *_):
        """
        Pass the click event to the button owner.

        g: self
        """
        self.feed(g)
        self.grab_focus()

    def on_key_press(self, g, a):
        """
        Called when because the user pressed a key.

        g: self
        a: key-press event
        """
        if gtk.gdk.keyval_name(a.keyval) == 'space':
            self.feed(g)
            return 1

    def set_color(self, color, state=ABLE):
        """
        Sets the button-face color.

        color: gtk.gdk.Color
        state: normal or disabled
        """
        self.modify_bg(state, color)

    def set_label(self, n):
        """
        Change button's text.

        n: string
        """
        self.label.set_text(n)

    def set_size(self, w=10, h=10):
        """
        Try to set the size of the button.

        w: width of widget, int
        h: height of widget, int
        """
        self.set_size_request(width=w, height=h)

    def set_text_color(self, color, state=ABLE):
        """
        Sets the color of the button's text.

        color: gtk.gdk.Color
        state: normal or disabled
        """
        self.label.modify_fg(state, color)

    def show(self):
        """ Draws the custom button. """
        super(ColoredButton, self).show()
        for g in (self.hbox, self.vbox, self.label):
            g.show()


class SwitchButton(ColoredButton):
    """ Used to process CG cell connection events. """

    def __init__(self, n, p, r, c, g):
        """
        n: text on button
        p: callback functions
        r: row
        c: column
        g: gtk Box-type, widget's container which is padded
        """
        self.r = r / 2
        self.c = c / 2
        self.action = p
        p = self.switch
        self.pad = g
        self.switch = 0
        ColoredButton.__init__(self, n, p)

    def switch(self, _):
        """
        Reverses the switch setting.

        Calls the connection operator.
        """
        x = self.switch = int(not self.switch)

        self.set_label(("+", "-")[x])
        self.action[x](CG.grid[self.r][self.c])


class GPerCell(RCheckButton):
    """ Manages a group of widgets that work cells on a per cell basis. """

    def __init__(self, p, p1, n, k, g, x):
        """
        p: callback function
        p1: open window function
        n: Button label
        k: CheckButton's key
        g: container
        x: ‟win_x” index
        """
        self.key = k
        self.cb_feed = p
        self.x = x
        self.cell_key = CELL_K[x]
        p = self.relay
        g1 = Splitter(padx=3)

        RCheckButton.__init__(self, PC, p, k=k)

        self.button_feed = p1
        p1 = self.relay_button
        g2 = self.g1 = RButton(n, p1)

        g1.left.add(self.g)
        g1.right.add(g2.g)
        g1.pack()
        g.add(g1.g)

    def relay(self, g):
        """
        Intercepts signals from the CheckButton.

        g: CheckButton widget
        """
        self.validate_button()
        self.cb_feed(g)

    def relay_button(self, _):
        """ Intercepts changed signal from the Button. """
        self.button_feed(self.x)

    def set_val(self, a):
        """
        Sets the value of the CheckButton.

        a: int
        """
        RCheckButton.set_val(self, a)
        self.validate_button()

    def validate_button(self):
        """
        The cell window Button is valid only if the CheckButton is checked.
        """
        self.g1.enable() if self.get_val() else self.g1.disable()


class GPreset(RComboBoxE):
    """ Manages a preset group of widgets. """

    def __init__(self, g, p, n, data_p, parent, preset):
        """
        g: container
        p: callback function
        n: name of preset
        data_p: process that retrieves the dict that gets saved
        saver: class type called when saving a preset
        parent: owner window
        """
        self.name = n
        self.get_data = data_p
        self.parent = parent
        self.preset = preset
        self.presets = []
        self.key = PRESET
        self.relay = p
        p = self.on_change

        self.collect_presets()
        RComboBoxE.__init__(self, p, k=PRESET, opt=self.opt, padx=2 if g else 0)

        g2 = self.box = Splitter(padx=3 if g else 0)
        g3 = self.save_b = RButton("Save", self.save)
        g4 = self.del_b = RButton("Delete", self.delete)
        q = TOPL if g else ZERO
        g5 = self.label = RLabel(n + " Preset:", q)
        if g:
            g2.both(g3.g, g4.g)
            g2.pack()
            g.add(g5.g)
            g.add(self.g)
            g.add(g2.g)

    def collect_presets(self):
        """ Creates a list, ‟self.opt”, of internal and external presets. """
        q = self.presets = []

        # menu options:
        self.opt = []
        ext_files = []
        go = 0
        a = self.preset

        try:
            search_path = UI.get_preset_path(a.name, u"*")

            # Ignore sub-directories:
            ext_files = glob.glob(search_path)
            go = 1

        except Exception as ex:
            show_err(ex)
            show_err(LOAD_ERR)

        if go:
            # Loads internal presets into a list:
            [q.append(i) for i in a.internal_presets]

            # Makes an external preset file list:
            for n in ext_files:
                file_name = os.path.basename(n)
                split_name = file_name.split(PRESET_SEP)
                combined_name = u""

                for n1 in range(1, len(split_name)):
                    combined_name = combined_name + split_name[n1]

                types = combined_name.split(u".")
                name = types[0]
                q.append([PRESET_EXT, name, n])
            for i in q:
                self.opt.append(i[Preset.name_x])

    def delete(self, *_):
        """ Called when the user activated the Delete Button. """
        n = self.get_val()

        # Get the file's full file name so that it can be deleted:
        for n1 in self.presets:
            if n1[Preset.name_x].lower() == n.lower():
                n2 = n1[Preset.file_x]
                g = gtk.MessageDialog(
                    parent=self.parent,
                    flags=gtk.DIALOG_MODAL,
                    type=gtk.MESSAGE_QUESTION,
                    buttons=gtk.BUTTONS_YES_NO,
                    message_format="Do you want to delete:\n" + n2 + "?")

                g.set_title("Delete File Confirmation")

                a = g.run()

                g.destroy()
                if int(a == gtk.RESPONSE_YES):
                    try:
                        os.remove(n2)

                        g = gtk.MessageDialog(
                            parent=self.parent,
                            flags=gtk.DIALOG_MODAL,
                            type=gtk.MESSAGE_INFO,
                            buttons=gtk.BUTTONS_CLOSE,
                            message_format="The file:\n" + n2 + "\nwas removed.")

                        g.set_title("File Deleted")
                        g.run()
                        g.destroy()
                        self.refresh(UND)

                    except Exception as ex:
                        show_err(ex)
                        show_err("Roller was unable to delete the file.")
                break

    def on_change(self, g):
        """
        When the ComboBoxE is activated, the delete Button needs to be validated.

        g: ComboBoxE
        """
        if not UI.loading:
            n = self.get_text()

            if n not in (DEF, UND, USE):
                UISave.preset_name = self.get_val()
            if n != UND:
                d = self.preset.get_preset(n, self.presets)

                self.verify_del_button()
                self.relay(g, d)

    def refresh(self, n):
        """
        The state of the preset menu has changed.

        n: the name to display on the menu
        """
        UI.loading += 1

        self.collect_presets()
        self.load(self.opt)

        p = self.set_val if n in self.opt else self.set_text

        p(n)

        if n not in (DEF, UND, USE):
            UISave.preset_name = n
        UI.loading -= 1

    def save(self, *_):
        """ Called when the user activated the Save Button. """
        if UISave({
                'get_data': self.get_data,
                PARENT: self.parent,
                PRESET: self.preset}).reply:
            self.refresh(UISave.preset_name)

    def verify_del_button(self):
        """ The delete Button is valid for an external preset. """
        a = self.del_b
        x = 0 if self.preset.is_internal(self.get_text(), self.presets) else 1
        (a.disable, a.enable)[x]()


class PlusMenu(RComboBoxE):
    """
    This menu remembers menu selection states and shares this
    info with the user by displaying a "+" by the drop-down option.
    """

    def __init__(self, p, key, opt):
        """
        p: callback function
        key: widget's key
        """
        self.plus_feed = p
        self.d = {}
        q = self.origin_opt = sorted(opt)

        for n in q:
            self.d[n] = 0
        RComboBoxE.__init__(self, self.update, k=key, opt=q, padx=2)

    def get_val(self):
        """
        Returns a dictionary with its keys set from menu
        items and values indicating their selection.
        """
        return self.d

    def set_val(self, d):
        """
        Sets the menu options to the keys in ‟d”.

        The menu always shows the same text.

        d: dict
        """
        q = self.origin_opt
        self.temp_opt = q[:]

        if d:
            for x, n in enumerate(q):
                if n in d:
                    if d[n]:
                        self.temp_opt[x] = "+ " + n
                        self.d[n] = 1

        self.load(self.temp_opt)
        self.set_text("Preview Options")

    def update(self, g):
        """
        Updates a menu option by inverting its selection state.

        Updates ‟self.d” for ‟get”.

        g: ComboBox
        """
        x = g.wig.get_active()
        if x > -1:
            n = self.origin_opt[x]
            if n:
                if n[0] == "+":
                    n = n[2:]

                if self.d[n]:
                    self.d[n] = 0

                else:
                    self.d[n] = 1

                self.plus_feed(self)
                self.set_val(self.d)

            # Updates completed:
            return 1


class Splitter:
    """ Creates two equal sized vertical boxes on the x-axis. """

    def __init__(self, padx=0):
        """
        padx: index to padding (1..3)
        """
        w = MARGIN
        w1 = w / 2
        self.g = self.box = HBox()

        if padx:
            g = self.g = Align(*ALL_X)

            g.add(self.box)
            g.set_padding(w1, (0, w1)[int(padx == 3)], w, w)

        g1 = RBox(0, align=ALL_X)
        g2 = RBox(0, align=ALL_X)
        self.left, self.right = g1.box, g2.box
        g3 = self.left_a = g1.g
        g4 = self.right_a = g2.g
        if padx > 1:
            g3.set_padding(0, 0, 0, w1)
            g4.set_padding(0, 0, w1, 0)

    def both(self, g, g1):
        """
        Adds two widgets to the Splitter.

        g: left widget
        g1: right widget
        """
        self.left.add(g)
        self.right.add(g1)

    def no_pack(self):
        """ Adds the two Alignment objects to the box. """
        self.box.add(self.left_a)
        self.box.add(self.right_a)

    def pack(self):
        """
        Makes the the two VBoxes the same size.
        Adds the same-sized VBoxes to the HBox.

        This function is called after all of
        the widgets have been added to the Splitter.
        """
        same_size = gtk.SizeGroup(mode=BOTH)

        # Transform size:
        for g in (self.left_a, self.right_a):
            same_size.add_widget(g)

        g = reversed(same_size.get_widgets())
        [self.box.add(g1) for g1 in g]


class Lay:
    """ These are functions used to manage image layers. """

    @staticmethod
    def activate(j, z):
        """
        Activates a layer.

        j: GIMP image
        z: layer
        """
        pdb.gimp_image_set_active_layer(j, z)

    @staticmethod
    def add(j, n, z=None, a=0, size=None):
        """
        Adds a layer to an image.

        j: image
        n: name of layer
        z: parent layer
        a: offset
        size: size of the layer

        Returns the new layer.
        """
        z1 = Lay.new(j, n, size=size)

        Lay.place(j, z1, z1=z, a=a)
        return z1

    @staticmethod
    def give_mask(z, masked):
        """
        Transfer mask from one layer to another.

        z: Receives mask.
        masked: source layer
        """
        if masked.mask:
            z.add_mask(Lay.mask(masked))

    @staticmethod
    def anti(j, z):
        """
        Performs anti-aliasing on a layer.

        j: GIMP layer
        z: layer
        """
        pdb.plug_in_antialias(j, z)

    @staticmethod
    def blur(j, z, a):
        """
        Blurs a layer.

        j: GIMP image
        z: layer
        a: blur amount
        """
        pdb.plug_in_gauss_rle2(j, z, a, a)

    @staticmethod
    def bury(j, z):
        """
        Removes a layer.

        j: GIMP image
        z: layer
        """
        pdb.gimp_image_remove_layer(j, z)

    @staticmethod
    def color_fill(z, q):
        """
        Fills a layer with a color.

        z: layer
        q: color
        """
        pdb.gimp_context_set_foreground(q)
        z.fill(fu.FOREGROUND_FILL)

    @staticmethod
    def dupl(j, z, mask=0):
        """
        Duplicates a layer. Its mask is optional.

        j: GIMP image
        z: layer
        mask: flag: If it's true, the layer's mask is preserved.

        Returns the duplicated layer.
        """
        Sel.all(j)

        z1 = pdb.gimp_layer_copy(z, 0)
        m = len(z.children)

        if m:
            Lay.activate(D[RENDER], L[BD])
            a = 0 + Preview.has_formats > 0

        else:
            a = -1
            Lay.activate(j, z)

        Lay.place(j, z1, None, a=a)

        if not mask:
            # Copies the mask, but it's not needed:
            if z1.mask:
                z1.remove_mask(fu.MASK_DISCARD)

        Sel.none(j)
        return z1

    @staticmethod
    def eat(j, z):
        """
        Merges a group of layers.

        j: GIMP image
        z: group layer

        Returns the new layer.
        """
        return pdb.gimp_image_merge_layer_group(j, z)

    @staticmethod
    def flip(z, horz=0):
        """
        Flips a layer horizontally or vertically.

        z: layer
        hort: flag: If it's true, the flip is horizontal.

        Returns the layer.
        """
        a = fu.ORIENTATION_HORIZONTAL if horz else fu.ORIENTATION_VERTICAL
        return pdb.gimp_item_transform_flip_simple(z, a, True, 0)

    @staticmethod
    def group(j, n, z=None, a=0):
        """
        Creates a group layer.

        j: image
        n: name of group
        z: parent layer
        a: offset

        Returns the group layer.
        """
        z1 = pdb.gimp_layer_group_new(j)
        Lay.place(j, z1, z1=z, a=a)

        z1.name = n
        return z1

    @staticmethod
    def hide(z):
        """
        Makes a layer invisible.

        z: layer
        """
        pdb.gimp_item_set_visible(z, 0)

    @staticmethod
    def mask(z):
        """
        z: layer

        Returns a mask of a layer.
        """
        return pdb.gimp_layer_create_mask(z, fu.ADD_MASK_ALPHA)

    @staticmethod
    def merge(j, z, clip=fu.CLIP_TO_IMAGE):
        """
        Merges layer down. The target must be visible.

        j: GIMP image
        z: layer

        Returns the merged layer.
        """
        return pdb.gimp_image_merge_down(j, z, clip)

    @staticmethod
    def move(z, x, y):
        """
        Moves a layer to a set of coordinates.

        z: layer
        x: coordinate
        y: coordinate
        """
        pdb.gimp_layer_set_offsets(z, x, y)

    @staticmethod
    def offset(z, z1):
        """
        Returns a child layer's offset.

        z: child layer
        z1: parent layer
        """
        for x, z2 in enumerate(z1.layers):
            if z == z2:
                return x
        return None

    @staticmethod
    def opaque(j, z):
        """
        Makes semi-transparent pixels opaque.

        j: GIMP image
        z: layer
        """
        pdb.plug_in_threshold_alpha(j, z, 0)

    @staticmethod
    def order(j, z, z1, a=0):
        """
        Moves a layer into a different position.

        j: GIMP image
        z: layer
        z1: parent
        a: offset
        """
        pdb.gimp_image_reorder_item(j, z, z1, a)

    @staticmethod
    def paste(j, z, xy=None):
        """
        Pastes the content of the buffer.

        j: GIMP image
        z: paste to layer
        xy: flag: If it's true, the pasted layer is moved to 0, 0.
        """
        a = pdb.gimp_edit_paste(z, False)
        z = float_to_layer(j, a)

        if xy:
            Lay.move(z, xy[0], xy[1])
        return z

    @staticmethod
    def place(j, z, z1=None, a=0):
        """
        Inserts a layer into an image.

        j: image
        z: layer to insert
        z1: group
        a: offset
        """
        pdb.gimp_image_insert_layer(j, z, z1, a)

    @staticmethod
    def new(j, n, size=None):
        """
        Creates a layer.

        j: GIMP image to receive layer
        n: layer name
        size: size of the layer

        Returns the layer.
        """
        if size:
            w, h = size

        else:
            w, h = j.width, j.height
        return pdb.gimp_layer_new(
            j,
            w,
            h,
            fu.RGBA_IMAGE,
            n,
            100,
            NORMAL)

    @staticmethod
    def rotate(j, a):
        """
        Rotates the top layer.

        j: GIMP image
        a: rotation amount in degrees

        Returns the transformed layer.
        """
        pdb.gimp_context_set_transform_direction(fu.TRANSFORM_FORWARD)
        pdb.gimp_context_set_transform_resize(fu.TRANSFORM_RESIZE_ADJUST)

        z = pdb.gimp_item_transform_rotate(
            j.layers[0], math.radians(a), True, 0, 0)

        pdb.gimp_image_resize_to_layers(j)
        return z

    @staticmethod
    def search(z, n):
        """
        Returns a layer found by its name or None.

        z: group layer
        n: name
        """
        for z1 in z.layers:
            if n in z1.name:
                return z1
        return None

    @staticmethod
    def selectable(j, z, d):
        """
        Returns a duplicate layer that has no semi-transparent pixels.

        j: GIMP image
        z: layer
        d: dict with an INHERIT key
        """
        z = Lay.dupl(j, z)

        if d[INHERIT]:
            Lay.opaque(j, z)
            Lay.anti(j, z)
        return z

    @staticmethod
    def show(z):
        """
        Makes a layer visible.

        z: layer
        """
        pdb.gimp_item_set_visible(z, 1)

    @staticmethod
    def tidy(z):
        """
        Removes enumeration from a group's layer names.
        """
        for z1 in z.layers:
            n = z1.name
            if "#" in n:
                n = z1.name = n[:n.index("#") - 1]
            if "copy" in n:
                z1.name = n[:n.index("copy") - 1]


class Layout:
    """ Manages image and preview placement. """
    pix = 0

    @staticmethod
    def blur_behind(blur):
        """
        Creates a blur behind layer if one doesn't exist.

        Uses a opaque selection of an image
        to blur the area on the blur behind layer.

        blur: blur amount
        """
        j1 = D[RENDER]

        if not L[BB]:
            # Create the Blur Behind layer:
            Lay.hide(L[IMG_GRP])
            kopy(j1)
            Lay.show(L[IMG_GRP])

            z = L[BB] = Lay.paste(j1, L[BD])
            z.name = BB + " Background"

        z1 = Lay.selectable(j1, L[IMG], INHERIT_D)

        Sel.item(j1, z1)
        Lay.blur(j1, L[BB], blur)
        Lay.bury(j1, z1)
        Sel.none(j1)

    @staticmethod
    def get_cell_margin(r, c, d):
        """
        Returns the image margins for a cell at r, c.

        d: format dict
        """
        if not d[CM_PER]:
            return d[CM_TOP], d[CM_BOT], d[CM_LEF], d[CM_RIG]

        else:
            return d[CM_CELL][r][c]

    @staticmethod
    def get_blur_behind(j, d):
        """
        Returns the value of an image's blur behind setting.

        j: Img
        d: format dict
        """
        if d[PROP_PER]:
            return d[PR_CELL][j.r][j.c][BB_X]

        else:
            return d[BB]

    @staticmethod
    def get_flip_h(j, d):
        """
        Returns the flip horizontal flag of an image being placed.

        j: Img
        d: format dict
        """
        if d[PROP_PER]:
            return d[PR_CELL][j.r][j.c][FLIP_H_X]

        else:
            return d[FLIP_H]

    @staticmethod
    def get_flip_v(j, d):
        """
        Returns the flip vertical flag of an image being placed.

        j: Img
        d: format dict
        """
        if d[PROP_PER]:
            return d[PR_CELL][j.r][j.c][FLIP_V_X]

        else:
            return d[FLIP_V]

    @staticmethod
    def get_horz_just(r, c, d):
        """
        Returns the horizontal justification for the cell at r, c.

        d: format dict
        """
        if d[PLACE_PER]:
            return d[PL_CELL][r][c][HORZ_X]

        else:
            return d[HORZ]

    @staticmethod
    def get_image(r, c, d):
        """
        Returns an Img object for the cell at r, c.

        d: format dict
        """
        if not d[PLACE_PER]:
            n = d[IMAGE]

        else:
            n = d[PL_CELL][r][c][IMAGE_X]
        return Img.get_image(n)

    @staticmethod
    def sel_img_trim(d, j, j1):
        """
        Used to get the cell-size scaled image pixels
        for a trimmed or non-resized image.

        Creates a selection rectangle for the image transfer.

        Copies the selection.

        d: Format dict
        j: Img
        j1: GIMP image

        Returns the selection size.
        """
        # Need to select from one layer only:
        m = 0

        if len(j1.layers) > 1:
            kopy(j1)
            m = 1
            j1 = Img.paste()

        r, c = j.r, j.c
        n = Layout.get_horz_just(r, c, d)
        s = j.cell_size
        t = j1.width, j1.height

        if n == LFT:
            x = 0
            x1 = s[0]

        elif n == CE:
            x = max(t[0] / 2 - s[0] / 2, 0)
            x1 = min(t[0] / 2 + s[0] / 2 + s[0] % 2, t[0])

        else:
            x = max(t[0] - s[0], 0)
            x1 = t[0]

        n1 = Layout.get_vert_just(r, c, d)

        if n1 == TOP:
            y = 0
            y1 = s[1]

        elif n1 == MID:
            y = max(t[1] / 2 - s[1] / 2, 0)
            y1 = min(t[1] / 2 + s[1] / 2 + s[1] % 2, t[1])

        else:
            y = max(t[1] - s[1], 0)
            y1 = t[1]

        # Correct for underflow:
        if x == x1:
            x1 += 1

        if y == y1:
            y1 += 1

        w = max(x1 - x, 1)
        h = max(y1 - y, 1)

        pdb.gimp_image_select_rectangle(
            j1,
            REPLACE,
            x,
            y,
            w,
            h)

        Sel.kopy(j1.layers[0])
        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j1)

        if m:
            Img.bury(j1)
        return x1 - x, y1 - y

    @staticmethod
    def get_placement(r, c, d):
        """
        Returns the image placement for a cell at r, c.

        d: format dict
        """
        if not d[PLACE_PER]:
            return d[RESIZE], d[IMAGE], d[HORZ], d[VERT]

        else:
            return d[PL_CELL][r][c]

    @staticmethod
    def get_prop_opacity(r, c, d):
        """
        Returns the opacity property of a cell at r, c.

        d: format dict
        """
        if d[PROP_PER]:
            return d[PR_CELL][r][c][OP_X]

        else:
            return d[OP]

    @staticmethod
    def get_resize_type(r, c, d):
        """
        Returns the resize type for the cell at r, c.

        d: format dict
        """
        if d[PLACE_PER]:
            return d[PL_CELL][r][c][0]

        else:
            return d[RESIZE]

    @staticmethod
    def get_rotate(r, c, d):
        """
        Returns the resize type for the cell at r, c.

        d: format dict
        """
        if d[PROP_PER]:
            return d[PR_CELL][r][c][ROTATE_X]

        else:
            return d[ROT]

    @staticmethod
    def get_vert_just(r, c, d):
        """
        Returns the vertical justification for the cell at r, c.

        d: format dict
        """
        if d[PLACE_PER]:
            return d[PL_CELL][r][c][VERT_X]

        else:
            return d[VERT]

    @staticmethod
    def is_draw_one_margin(d):
        """
        Returns true when drawing one margin per row or column.

        d: format dict
        """
        return not any((
            d[PLACE_PER],
            d[CM_PER],
            d[MERG_PER],
            d[PROP_PER]))

    @staticmethod
    def new_render():
        """
        Creates a new image for the Preview and render.

        Returns the new image.
        """
        j = D[RENDER] = Img.new(D[WI], D[HG])

        # Turn off undo functionality:
        pdb.gimp_image_undo_group_start(j)
        return j

    @staticmethod
    def place_img(j, d, cell):
        """
        Copies and pastes images on or above the image layer.

        j: Img
        d: format dict
        cell: Cell
        """
        # The Img will enter the copy and paste buffer:
        Img.mold(j, d, cell)

        j1 = D[RENDER]

        if not Layout.pix:
            a = 1 if Preview.has_formats else 0
            L[IMG_GRP] = Lay.group(j1, d[NAME] + ": Image", a=a)

        z = L[IMG] = Lay.paste(j1, j1.layers[-1])
        z.opacity = Layout.get_prop_opacity(j.r, j.c, d) / 1.

        Lay.order(j1, z, L[IMG_GRP])

        if Layout.get_flip_h(j, d):
            Lay.flip(z, horz=1)

        if Layout.get_flip_v(j, d):
            z = Lay.flip(z)

        Lay.move(z, j.x, j.y)

        blur = Layout.get_blur_behind(j, d)

        if blur:
            Layout.blur_behind(blur)
        Layout.pix += 1


class Sel:
    """ Organizes selection functions. """

    @staticmethod
    def all(j):
        """
        Selects all of the image.

        j:  GIMP image
        """
        pdb.gimp_selection_all(j)

    @staticmethod
    def color(j, z, q):
        """
        Creates a selection based on color.

        j: GIMP image
        z: layer
        q: color
        """
        pdb.gimp_image_select_color(j, REPLACE, z, q)

    @staticmethod
    def fill(z, q):
        """
        Fills a selection on a layer.

        z: layer to apply fill
        q: color
        """
        pdb.gimp_context_set_background(q)
        pdb.gimp_edit_bucket_fill(
            z,
            fu.BACKGROUND_FILL,
            NORMAL,
            100,
            0, False, 0, 0)

    @staticmethod
    def grow(j, w, m):
        """
        Expands a selection.

        j: GIMP image
        w: expansion amount
        m: expansion type flag
        """
        if m:
            for i in range(w):
                pdb.gimp_selection_grow(j, 1)

        else:
            pdb.gimp_selection_grow(j, w)

    @staticmethod
    def invert(j):
        """
        Inverts a selection.

        j: GIMP image
        """
        pdb.gimp_selection_invert(j)

    @staticmethod
    def isolate(z, sel):
        """
        Clears out everything but a selection.

        z: layer
        sel: selection
        """
        Sel.load(sel)
        Sel.invert(D[RENDER])
        klear(z)
        Sel.none(D[RENDER])

    @staticmethod
    def item(j, z):
        """
        Selects an item.

        j: GIMP image
        z: layer
        """
        pdb.gimp_image_select_item(j, REPLACE, z)

    @staticmethod
    def kopy(z):
        """
        Copies a selection.

        z: layer for selection
        """
        pdb.gimp_edit_copy(z)

    @staticmethod
    def load(sel, opt=REPLACE):
        """
        Loads a previously saved selection.

        sel: selection id
        """
        pdb.gimp_image_select_item(D[RENDER], opt, sel)

    @staticmethod
    def none(j):
        """
        Removes the selection.

        j: GIMP image
        """
        pdb.gimp_selection_none(j)

    @staticmethod
    def rect(j):
        """
        Draws a selection rectangle.

        j: GIMP image
        """
        pdb.gimp_image_select_rectangle(
            j,
            ADD,
            D[X],
            D[Y],
            seal(D[W], 1, j.width),
            seal(D[H], 1, j.height))

    @staticmethod
    def save(j):
        """
        Saves the selection in memory with an id.

        j: GIMP image

        Returns the selection id.
        """
        return pdb.gimp_selection_save(j)


class IA:
    """ Used by EF and BS. """

    def __init__(self, layer_k):
        """ layer_k: preview layer key """
        self.layer_k = layer_k
        self.sess_k = self.name
        self.pr = L[FORMAT] if self.is_shadow() else L[layer_k]
        self.previewed = 0
        self.d = None

    def autorun(self, d):
        """
        Called when the user is auto-randomizing the style or effect.

        d: dict with widget values
        """
        D[SESS][self.sess_k] = d
        self.do(d)

    def duplicate(self):
        """
        Duplicates the the active format group.

        Updates the layer dictionary.

        Returns a duplicate of the Format group.
        """
        self.pr = Lay.dupl(D[RENDER], L[self.layer_k], mask=1)
        if self.layer_k == FORMAT:
            self.update_layer(self.pr)
            self.load_img()

    def get_preview_layer(self):
        """ Returns the preview layer that gets replaced. """
        return L[self.layer_k] if self.is_shadow() else self.pr

    def is_shadow(self):
        """ Returns true if the current preview is a shadow. """
        return self.layer_k in SHADOW

    def load_img(self):
        """ Load ‟self.img” with the layers casting a shadow. """
        self.img = []

        for x in self.subject_x:
            self.img.append(self.pr.layers[x])

    def prep(self, d):
        """
        Sets the dictionary needed for processing.

        ‟prep” serves as way to get feedback and then
        wait for the GTK window to finish closing.

        This way there is less a likelihood problems
        with cross-interface event errors between GTK and GIMP.

        d: dict with option results
        """
        j = D[RENDER]
        if not self.previewed:
            self.d = d

        elif self.previewed == 1:
            # Delete original Format group:
            if not self.is_shadow():
                Lay.bury(j, L[self.layer_k])
            if self.layer_k == FORMAT:
                L[FORMAT], L[IMAGE] = self.pr, Lay.search(self.pr, "Image")
                if self.has_shadow:
                    self.previewed = -1
                    self.d = d

                else:
                    self.previewed = 0

                Lay.tidy(L[FORMAT])
                Lay.tidy(j)

        elif self.previewed == 2:
            # Remove the preview:
            z = self.get_preview_layer()

            Lay.bury(j, z)

            if self.is_shadow():
                self.pr = L[FORMAT]

            else:
                z = self.pr = L[self.layer_k]
                Lay.show(L[self.layer_k])

            self.d = d
            if self.layer_k == FORMAT:
                self.load_img()
                self.update_layer(z)

                self.previewed = 0
                Lay.tidy(z)
        D[SESS][self.sess_k] = d

    def preview(self, d):
        """
        Draws a preview.

        d: dict with option results
        """
        if self.previewed:
            z = self.get_preview_layer()
            Lay.bury(D[RENDER], z)

        # Duplicate previous layer:
        self.previewed = 1

        if not self.is_shadow():
            self.duplicate()
            Lay.show(self.pr)
            Lay.hide(L[self.layer_k])
        self.do(d)

    def preview_changed(self):
        """ Invalidates the preview as finalized. """
        self.previewed = 2 if self.previewed else 0

    def randomize(self):
        """ Returns a dictionary with randomized widget values. """
        return self.rand()

    def update_layer(self, z):
        """
        Restores the links in the Layers dictionary.

        z: format layer
        """
        for k in (DS, BB, CLF_BG):
            if k in L:
                if L[k]:
                    L[k] = Lay.search(z, k)


class EF(IA):
    """ Holds factored functions from 3D effect classes. """

    def __init__(self, q=None, m=0, layer_k=FORMAT):
        """
        q: effected layers
        m: flag: It is true when the effect has a border with a shadow.
        """
        IA.__init__(self, layer_k)

        self.img = [L[IMAGE]]

        if q:
            self.img = q
            self.subject_x = []
            for z in q:
                self.subject_x.append(Lay.offset(z, L[FORMAT]))

        else:
            self.subject_x = [Lay.offset(L[IMAGE], L[FORMAT])]
        self.has_shadow = m
        self.id = prefix() + self.name

    def draw_sel(self, sel, z):
        """
        Draws a selection as black on white.

        sel: selection
        z: layer
        """
        Lay.color_fill(z, WH)
        Sel.load(sel)
        Sel.fill(z, BLK)
        Sel.none(D[RENDER])

    def emboss(self, j, z, light, a):
        """
        Embosses a layer.

        j: GIMP image
        z: layer
        light: angle (0..360)
        a: contrast

        The ‟30” produces the middle value for the face.

        The first ‟1” doesn't blend the light and shadow.
        """
        pdb.plug_in_emboss(j, z, light, 30., 1, 1)
        pdb.gimp_brightness_contrast(z, 0, a)

    @staticmethod
    def compliment_key_light():
        """ Returns a complimentary preset of the key-light shadow. """
        d = deepcopy(D[SESS][KLS])
        d[OFFSETX] *= -1
        d[OFFSETY] *= -1
        d[OP] /= 2
        return d

    def noise(self, z, d):
        """
        Adds noise to a layer.

        z: layer
        d: session dict
        x: noise index
        """
        j = D[RENDER]
        pdb.plug_in_solid_noise(
            j, z,
            0, 1, d[SEED], d[DETAIL], 2, 2)
        pdb.plug_in_hsv_noise(
            j,
            z,
            d[HOLD], d[POWER], d[POWER], d[POWER])


class EFShadow(EF):
    """ Used by Drop Shadow and Inlay Shadow. """

    def __init__(self, sess_k, q=None, inlay=0):
        """
        k: effect name
        q: layer tuple to apply shadow
        inlay: flag: invert selection when true
        """
        self.name = sess_k
        self.inlay = inlay

        EF.__init__(self, q=q, layer_k=self.name)

        d = D[SESS][sess_k]

        if D[AUTO] == 1:
            self.do(d)

        elif D[AUTO] == 2:
            self.autorun(self.rand())

        else:
            q = BLUR, COLOR3, OP

            if not inlay:
                q += OFFSETX, OFFSETY

            q += (INHERIT,)

            UIConfig(sess_k, self, q, d)
            if self.d:
                self.do(self.d)

    def do(self, d):
        """
        Creates the effect.

        d: dict with shadow settings
        """
        # Use a selection so the shadow doesn't appear below the image:
        m = self.inlay
        q = self.img
        z = self.pr
        j = D[RENDER]

        # Put layer into a group and merge group:
        grp = Lay.group(j, "Cast", z=z)

        for z1 in q:
            z2 = Lay.dupl(j, z1)
            Lay.order(j, z2, grp)
            Lay.hide(z1)

        grp = Lay.eat(j, grp)

        if m:
            d[OFFSETX] = d[OFFSETY] = .05

        else:
            # drop shadow:
            grp1 = Lay.selectable(j, grp, d)
            Lay.bury(j, grp)
            grp = grp1

        z1 = L[self.name] = shadow(
            j,
            grp,
            d[OFFSETX],
            d[OFFSETY],
            d[BLUR],
            d[COLOR3],
            d[OP],
            n=self.id,
            d=d,
            m=m)

        Lay.bury(j, grp)

        if z1:
            a = len(z.layers) if not m else 0
            Lay.order(j, z1, z, a=a)
            if self.name == KLS:
                z1.mode = NORMAL

        for z1 in q:
            Lay.show(z1)
        Sel.none(j)

    def rand(self):
        """ Returns a dict with randomized widget values. """
        d = deepcopy(D[SESS][self.sess_k])
        d[OP] = (rnd(100, 140), rnd(60, 100))[self.inlay > 0]
        d[BLUR] = (rnd(20, 40), rnd(20, 30))[self.inlay > 0]
        return d


class EFBL(EF):
    """ Creates a metallic-like border. """
    name = BL

    def __init__(self, d):
        """ d: session dict """
        EF.__init__(self, m=1)

        if D[AUTO] == 1:
            self.do(d)

        elif D[AUTO] == 2:
            self.autorun(self.rand())

        else:
            UIConfig(
                self.name, self, (
                    BORD_W, BORD_TYP, LIGHT, INHERIT,
                    SEED, DETAIL, HOLD, POWER), d)
            if self.d:
                self.do(self.d)

    def blend_edges(self, z):
        """
        Blends the color of the background with edge of the frame.

        z: layer with black and white edges
        """
        j = D[RENDER]

        Sel.load(self.sel)
        pdb.gimp_selection_shrink(j, 1)

        a = Sel.save(j)

        Sel.load(self.sel)
        Sel.load(a, opt=SUBTRACT)

        edge_sel = Sel.save(j)

        Sel.none(j)
        kopy(j)

        z1 = Lay.paste(j, z)

        Lay.blur(j, z1, 5)
        Sel.load(edge_sel)
        Sel.invert(j)
        klear(z1)

        z1.opacity = 40.
        z1.name = self.id + " Edge Reflection"

    def do(self, d):
        """
        Creates the border.

        d: sub-session dict
        """
        j = D[RENDER]
        n = self.id

        if self.previewed > -1:
            grp = self.grp = Lay.group(j, n, self.pr)
            z1 = Lay.add(j, n + " Frame", z=grp)

            # Create embossed border:
            Lay.color_fill(z1, WH)

            z2 = Lay.selectable(j, self.img[0], d)

            Sel.item(j, z2)

            sel = Sel.save(j)

            Sel.grow(j, d[BORD_W], d[BORD_TYP])
            Sel.load(sel, opt=SUBTRACT)

            sel = self.sel = Sel.save(j)

            self.draw_sel(sel, z1)

            self.emboss(j, z1, d[LIGHT], 50)
            Sel.isolate(z1, self.sel)
            Lay.anti(j, z1)
            Lay.bury(j, z2)

            # Strengthen edges:
            z2 = self.edge = Lay.dupl(j, z1)
            z2.mode = OVERLAY
            z2.name = n + " Edge"
            z3 = L[BORD] = Lay.add(j, n + " Metal", z=grp)

            z4 = Lay.dupl(j, z3)

            self.noise(z4, d)

            z4.mode = OVERLAY
            z4.name = n + " Bump"
            z4.opacity = 4.

            Sel.isolate(z4, self.sel)

            z5 = Lay.dupl(j, z4)
            z5.mode = MULTIPLY
            z5.opacity = 11.
            z5.name = n + " Stain"
            pdb.plug_in_despeckle(j, z5, 3, 0, 50, 205)
            pdb.plug_in_despeckle(j, z5, 7, 0, 100, 155)
            Sel.isolate(z5, self.sel)

        if self.previewed in (0, -1):
            # Add light and color:
            if BD_LIGHT in L:
                self.draw_bd_light(BORD)

            else:
                BSGF(D[SESS][BG], name=BG, layer_k=BORD, sel=self.sel)

            if not D[CANCEL]:
                z3 = L[BORD]

                # Trim gradient to border:
                Sel.isolate(z3, self.sel)

                # metallic look:
                z3.mode = HARD
                z3.opacity = 80.

                Lay.order(j, self.edge, self.grp, a=0)

                if BD_LIGHT not in L:
                    # Add backdrop light:
                    L[BD_LIGHT] = Lay.add(
                        j,
                        n + " " + BD_LIGHT,
                        a=D[FORMAT_CNT] + Preview.has_formats)

                    self.draw_bd_light(BD_LIGHT)

                    z = L[BD_LIGHT]
                    z.mode = fu.LAYER_MODE_LINEAR_LIGHT
                    z.opacity = 7.
                self.blend_edges(self.edge)
                Lay.tidy(self.grp)
        if self.previewed in (0, -1):
            if not D[CANCEL]:
                EFDS({}, n=KLS, q=(L[BORD], L[IMAGE]))

            if not D[CANCEL]:
                EFDS({}, n=FLS, q=(L[BORD], L[IMAGE]))
            if not D[CANCEL]:
                EFShadow(ES, q=(L[IMAGE],), inlay=1)

    def draw_bd_light(self, k):
        """
        Draws the BD_LIGHT onto a layer.

        z: layer
        k: layer key
        """
        a = D[AUTO]
        D[AUTO] = 1

        BSGF(D[SESS][BG], name=BG, layer_k=k)
        D[AUTO] = a

    def rand(self):
        """ Returns a dict with randomized widget values. """
        if BD_LIGHT in L:
            light = D[SESS][BL][LIGHT]

        else:
            light = rnd(0, 359)

        return {
            BORD_W: rnd(4, 15),
            BORD_TYP: rnd(0, 1),
            DETAIL: rnd(0, 15),
            HOLD: rnd(1, 8),
            INHERIT: 0,
            LIGHT: light,
            POWER: rnd(0, 180),
            SEED: rnd(0, 100000)}


class EFCB(EF):
    """ Creates a an colored edge around an image(s). """
    name = CB

    def __init__(self, d):
        """ d: session dict """
        EF.__init__(self, m=1)

        if D[AUTO] == 1:
            self.do(d)

        elif D[AUTO] == 2:
            self.autorun(self.rand())

        else:
            UIConfig(
                self.name, self, (BORD_W, COLOR1, BORD_TYP, INHERIT), d)
            if self.d:
                self.do(self.d)

    def do(self, d):
        """
        Does the work.

        d: dict with color and border width
        """
        if self.previewed > -1:
            j, z = D[RENDER], self.img[0]
            z1 = Lay.selectable(j, z, d)

            Sel.item(j, z1)
            Sel.grow(j, d[BORD_W], d[BORD_TYP])

            L[CB] = Lay.add(j, self.id, z=z.parent, a=1)

            Sel.fill(L[CB], d[COLOR1])
            Sel.item(j, z1)
            klear(L[CB])
            Sel.none(j)
            Lay.bury(j, z1)
            Lay.anti(j, L[CB])
        if self.previewed in (-1, 0):
            EFDS({}, q=(L[CB], L[IMAGE]))

    def rand(self):
        """ Returns a dict with randomized widget values. """
        return {
            BORD_W: rnd(1, 20),
            COLOR1: rnd_col(),
            BORD_TYP: rnd(0, 1),
            INHERIT: 0}


class EFCF(EF):
    """ This creates a translucent border around an image(s). """
    name = CLF

    def __init__(self, d):
        """ d: session dict """
        EF.__init__(self, m=1)

        if D[AUTO] == 1:
            self.do(d)

        elif D[AUTO] == 2:
            if self.name == FLS:
                self.do(EF.compliment_key_light())

            else:
                self.autorun(self.rand())

        else:
            UIConfig(
                self.name, self, (BORD_W, COLOR1, BORD_TYP, INHERIT), d)
            if self.d:
                self.do(self.d)

    def do(self, d):
        """
        Does the work.

        d: dict with color and border width
        """
        if self.previewed > -1:
            frame = [0, 0]
            n = self.id
            j = D[RENDER]
            q = edge_color(d[COLOR1])
            z = Lay.group(j, n, z=self.pr)
            opaque_img = Lay.selectable(j, self.img[0], d)

            # Creates two layers:
            for x in range(2):
                Sel.item(j, opaque_img)
                Sel.grow(j, (d[BORD_W] + 5, 5)[x], d[BORD_TYP])

                z1 = Lay.add(j, n, z=z)

                Sel.fill(z1, d[COLOR1])
                Sel.item(j, opaque_img)
                klear(z1)
                Sel.none(j)
                frame[x] = self.do_edge(j, z, z1, q)

            Lay.bury(j, opaque_img)

            # Blur the background:
            Sel.all(j)
            Lay.hide(self.pr)
            kopy(j)
            Lay.show(self.pr)

            z1 = L[CLF_BG] = Lay.paste(j, self.img[0], xy=(0, 0))
            z1.name = n + " Background"
            wide = frame[d[BORD_W] < 5]
            sel_frame = Lay.selectable(j, wide, d)

            Lay.blur(j, z1, 16)
            Sel.item(j, sel_frame)
            Sel.invert(j)
            klear(z1)
            Sel.none(j)
            Lay.bury(j, sel_frame)

            # Add shadow and merge:
            z1 = shadow(j, frame[1], .05, .05, 5, BLK, 100, "")

            Lay.order(j, z1, z)

            z1.mode = NORMAL
            frame[0].opacity = 55.
            frame[1].mode = OVERLAY
            L[CLF] = Lay.eat(j, z)
            L[CLF].opacity = 55.

            Sel.none(j)
            Lay.anti(j, L[CLF])
        if self.previewed in (0, -1):
            EFDS({}, q=(L[CLF], L[IMAGE]))
            if not D[CANCEL]:
                EFShadow(ES, q=(L[IMAGE],), inlay=1)

    def do_edge(self, j, z, z1, q):
        """
        Used to create an overlay edge effect
        where the light source is directly above
        the subject.

        j: GIMP image
        z: group
        z1: layer
        q: background color
            The background color needs to differ from the subject.
            It is used to turn transparent pixels into opaque pixels.

        Returns the layer with the edge.
        """
        edge = Lay.dupl(j, z1)
        bg = Lay.new(j, "bg")

        Lay.color_fill(bg, q)
        Lay.place(j, bg, z1=z, a=1)

        edge = Lay.merge(j, edge)

        pdb.plug_in_edge(
            j,
            edge,
            1.,
            0,
            0)

        Sel.item(j, z1)
        Sel.invert(j)
        klear(edge)

        edge.mode = OVERLAY
        return Lay.merge(j, edge)

    def rand(self):
        """ Returns a dict with randomized widget values. """
        return {
            BORD_W: rnd(30, 50),
            COLOR1: rnd_col(),
            BORD_TYP: rnd(0, 1),
            INHERIT: 0}


class EFDS(EFShadow):
    """ This creates a drop shadow effect on an image layer. """
    name = DS

    def __init__(self, _, n=DS, q=None):
        """ q: layer tuple """
        EFShadow.__init__(self, n, q)


class EFIS(EFShadow):
    """ This creates a sunken image effect on an image layer. """
    name = IS

    def __init__(self, _):
        EFShadow.__init__(self, self.name, inlay=1)


class BS(IA):
    """ Used by backdrop styles for option dialog interaction. """

    def __init__(self, layer_k=BD):
        """ layer_k: layer key """
        IA.__init__(self, layer_k)

    def do_gradient(self, z, d, e):
        """
        Draws a gradient.

        z: layer
        d: session dict
        e: vector dict
        """
        pdb.gimp_context_set_gradient(d[GRADIENT])
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            GRAD_TYPE.index(d[METHOD]),
            .0,
            True,
            1,
            0.,
            True,
            e[STARTX],
            e[STARTY],
            e[ENDX],
            e[ENDY])

    def get_mode(self, d):
        """
        Returns the mode and opacity in the session dict.

        d: session dict
        """
        return D[MODE].get_x(d[MODE]), d[OP] / 1.

    def pass_bounds(self, d):
        """
        Styles are using the last used session settings.

        Checks points to make sure they are still inside the image.

        Checks rows and columns to make sure that they aren't greater than
            the image size.

        d: options dict
        """
        if ROW in d:
            d[ROW] = min(d[ROW], D[WI])
            d[COL] = min(d[COL], D[HG])

        for k in (STARTX, ENDX):
            if k in d:
                d[k] = min(d[k], D[WI] - 1)

        for k in (STARTY, ENDY):
            if k in d:
                d[k] = min(d[k], D[HG] - 1)
        self.do(d)

    def rnd_fill(self, d):
        """
        Randomizes values for a fill dictionary.

        d: dict

        Returns the dictionary.
        """
        d[CRIT] = choice(CRIT_LIST)
        d[STARTX] = rnd(0, D[WI] - 1)
        d[STARTY] = rnd(0, D[HG] - 1)
        d[THRESH] = uniform(uniform(uniform(0, .8), .9), 1)
        return self.rnd_mode(d)

    def rnd_grad(self):
        """ Returns a randomly choosen gradient. """
        return choice(pdb.gimp_gradients_get_list(None)[1])

    def rnd_mode(self, d):
        """
        Randomize mode and opacity.

        d: session dict
        """
        d[MODE] = D[MODE].rand()
        d[OP] = rnd(rnd(0, 90), 100)
        return d

    def set_fill_context(self, d):
        """
        Sets the context for current fill-type operation.

        d: options dict
        """
        pdb.gimp_context_set_sample_threshold(d[THRESH])
        pdb.gimp_context_set_opacity(d[OP])
        pdb.gimp_context_set_paint_mode(D[MODE].get_x(d[MODE]))
        pdb.gimp_context_set_sample_criterion(CRIT_LIST.index(d[CRIT]))


class BSAC:
    """ Uses pixelize to create an approximate average color. """
    name = "Average Color"

    def __init__(self, _):
        """ d: unused """
        pixelize(D[RENDER], L[BD], D[WI], D[HG])


class BSBD:
    """ Backdrop image """
    name = BD + " Image"

    def __init__(self, _):
        return


class BSCD(BS):
    """ Creates a diamond grid. """
    name = COD

    def __init__(self, d):
        """ d: session dict """
        BS.__init__(self)

        if D[AUTO] == 1:
            self.pass_bounds(d)

        elif D[AUTO] == 2:
            self.autorun(self.rand())

        else:
            UIConfig(self.name, self, COLOR_K + MOP_K, d)
            if self.d:
                self.do(self.d)
        L[BD] = self.pr

    def do(self, d):
        """
        Processes the diamond colors.

        d: color values dict
        """
        w = D[RAD] * 2
        r, c = d[ROW], d[COL]
        d[COL] = int(d[COL] * w / 1. / D[WI]) + 1
        d[ROW] = int(d[ROW] * w / 1. / D[HG]) + 1
        j = Img.new(w, w)
        z = Lay.add(j, "Diamond")
        draw_color_grid(j, z, d)
        d[ROW], d[COL] = r, c

        Lay.rotate(j, 45)
        kopy(j)
        Img.bury(j)

        j = D[RENDER]
        z = Lay.paste(j, self.pr)

        pdb.gimp_layer_resize_to_image_size(z)

        z.mode, z.opacity = self.get_mode(d)

        Lay.give_mask(z, self.pr)
        self.pr = Lay.merge(j, z)

    def rand(self):
        """ Returns a dict with randomized widget values. """
        r, c = random_rc()
        d = {
            COLOR1: rnd_col(),
            COLOR2: rnd_col(),
            ROW: r,
            COL: c,
            PIXL8: 0}
        return self.rnd_mode(d)


class BSCF(BS):
    """ Fills the backdrop with a color. """
    name = CF

    def __init__(self, d):
        """ d: session dict """
        BS.__init__(self)

        if D[AUTO] == 1:
            self.pass_bounds(d)

        elif D[AUTO] == 2:
            self.autorun(self.rand())

        else:
            UIConfig(self.name, self, FILL_K + (COLOR1,), d)
            if self.d:
                self.do(self.d)
        L[BD] = self.pr

    def do(self, d):
        """
        Processes a chosen color.

        d: color fill options dict
        """
        self.set_fill_context(d)
        pdb.gimp_context_set_foreground(d[COLOR1])
        pdb.gimp_drawable_edit_bucket_fill(
            self.pr,
            fu.FOREGROUND_FILL,
            d[STARTX], d[STARTY])

    def rand(self):
        """ Returns a dictionary with randomized widget values. """
        return self.rnd_fill({COLOR1: rnd_col()})


class BSCG(BS):
    """ Creates a colored grid. """
    name = COG

    def __init__(self, d):
        """ d: session dict """
        BS.__init__(self)

        if D[AUTO] == 1:
            self.pass_bounds(d)

        elif D[AUTO] == 2:
            self.autorun(self.rand())

        else:
            UIConfig(self.name, self, COLOR_K + MOP_K, d)
            if self.d:
                self.do(self.d)
        L[self.layer_k] = self.pr

    def do(self, d):
        """
        Processes the grid colors.

        d: color values dict
        """
        j = D[RENDER]
        z = Lay.add(j, "Grid")
        z = draw_color_grid(j, z, d)
        z.mode, z.opacity = self.get_mode(d)

        Lay.give_mask(z, self.pr)
        self.pr = Lay.merge(j, z)

    def rand(self):
        """ Returns a dict with randomized widget values. """
        r, c = random_rc()
        d = {
            COL: c,
            COLOR1: rnd_col(),
            COLOR2: rnd_col(),
            PIXL8: 0,
            ROW: r}
        return self.rnd_mode(d)


class BSGF(BS):
    """ Fills the backdrop with a gradient. """
    name = GF

    def __init__(self, d, name=GF, layer_k=BD, sel=None):
        """ d: session dict """
        self.name = name
        self.sel = sel

        BS.__init__(self, layer_k=layer_k)

        if D[AUTO] == 1:
            self.pass_bounds(d)

        elif D[AUTO] == 2:
            self.autorun(self.rand())

        else:
            q = (GRADIENT, METHOD, ROT, INVERT) + LINE_K

            if self.name != BG:
                q += MOP_K

            UIConfig(
                self.name,
                self,
                q, d)
            if self.d:
                self.do(self.d)
        L[layer_k] = self.pr

    def do(self, d):
        """
        Processes a chosen pattern.

        d: control values
        """
        j = D[RENDER]
        z = self.pr
        e = d.copy()

        if d[ROT]:
            # Create a new image for the rotation:
            w = D[RAD] * 2
            j1 = Img.new(w, w)
            z = Lay.add(j1, ROT)

            Lay.activate(j1, z)

            for k in (STARTX, ENDX):
                e[k] = int(d[k] * w / 1. / D[WI])

            for k in (STARTY, ENDY):
                e[k] = int(d[k] * w / 1. / D[HG])

        else:
            z = Lay.dupl(j, z)
            z.mode, z.opacity = self.get_grad_mode(d)

        self.do_gradient(z, d, e)

        if d[ROT]:
            Sel.item(j1, z)
            pdb.gimp_item_transform_rotate(
                z, math.radians(d[ROT]), True, 0, 0)

            # Copy / paste the rotated gradient:
            w1 = D[WI] / 2
            h1 = D[HG] / 2
            D[X] = j1.width / 2 - w1
            D[Y] = j1.height / 2 - h1
            D[W] = D[WI]
            D[H] = D[HG]

            Sel.rect(j1)
            kopy(j1)
            Img.bury(j1)

            z = Lay.paste(j, self.pr)

            Lay.give_mask(z, self.pr)

            z.mode, z.opacity = self.get_grad_mode(d)
            self.pr = Lay.merge(j, z)

            if d[INVERT]:
                pdb.gimp_drawable_invert(self.pr, False)
            if self.sel:
                Sel.isolate(self.pr, self.sel)

        else:
            self.pr = Lay.merge(j, z)

    def get_grad_mode(self, d):
        """
        Returns the gradient's mode and opacity.

        d: session dict
        """
        if self.name == BG:
            x = D[MODE].get_x(NORM)
            f = 100.

        else:
            x, f = self.get_mode(d)
        return x, f

    def rand(self):
        """ Returns a dictionary with randomized widget values. """
        d = {
            INVERT: rnd(0, 1),
            ROT: rnd(-359, 359),
            METHOD: choice(GRAD_TYPE),
            GRADIENT: self.rnd_grad()}

        for x, k in enumerate(LINE_K):
            d[k] = rnd(0, D[HG]) if x % 2 else rnd(0, D[WI])

        if self.name != BG:
            return self.rnd_mode(d)

        else:
            return d


class BSPF(BS):
    """ Fills the backdrop with a pattern. """
    name = PF

    def __init__(self, d):
        """ d: session dict """
        BS.__init__(self)

        if D[AUTO] == 1:
            self.pass_bounds(d)

        elif D[AUTO] == 2:
            self.autorun(self.rand())

        else:
            UIConfig(self.name, self, FILL_K + (PATTERN,), d)
            if self.d:
                self.do(self.d)
        L[BD] = self.pr

    def do(self, d):
        """
        Processes a chosen pattern.

        d: control values
        """
        self.set_fill_context(d)
        pdb.gimp_context_set_pattern(d[PATTERN])
        pdb.gimp_drawable_edit_bucket_fill(
            self.pr,
            fu.FILL_PATTERN,
            d[STARTX], d[STARTY])

    def rand(self):
        """ Returns a dictionary with randomized widget values. """
        return self.rnd_fill(
            {PATTERN: choice(pdb.gimp_patterns_get_list(None)[1])})


class BSPG(BS):
    """ Pixelizes the backdrop. """
    name = PG

    def __init__(self, d):
        """ d: session dict """
        BS.__init__(self)

        if D[AUTO] == 1:
            self.pass_bounds(d)

        elif D[AUTO] == 2:
            self.autorun(self.rand())

        else:
            UIConfig(self.name, self, (ROW, COL) + MOP_K, d)
            if self.d:
                self.do(self.d)
        L[BD] = self.pr

    def do(self, d):
        """
        Processes the grid colors.

        d: color values
        """
        z = Pixl8.do(d[ROW], d[COL], self.pr)
        z.mode, z.opacity = self.get_mode(d)

        Lay.give_mask(z, self.pr)
        self.pr = Lay.merge(D[RENDER], z)

    def rand(self):
        """ Returns a dictionary with randomized widget values. """
        r, c = random_rc()
        return self.rnd_mode({ROW: r, COL: c})


class BSTR:
    """ Transparency does nothing. """
    name = TR

    def __init__(self, _):
        return


class EFS:
    """
    Contains the collection of 3D Effects.

    It is used by the 3D Effects menu.
    """
    obj = (EFBL, EFCB, EFCF, EFDS, EFIS)

    def __init__(self):
        """ Creates a list of names from the 3D Effects collection. """
        self.names = [i.name for i in EFS.obj]


class BDS:
    """
    Contains the collection of Backdrop Styles.

    It is used by the Backdrop Styles menu.
    """
    obj = (BSAC, BSBD, BSCD, BSCF, BSCG, BSGF, BSPF, BSPG, BSTR)

    def __init__(self):
        """ Creates a list of names for Backdrop Styles. """
        self.names = [i.name for i in self.obj]


class Preview:
    """ Manages render preview. """

    # flags:
    has_formats = has_background = 0

    # layout type:
    pixl8 = 0

    # Preview canvas size:
    size = 0, 0

    def __init__(self):
        return

    def add_text(self, x, y, z):
        """
        Adds a text layer to the format group.

        Moves the layer to its final position.

        x, y: final position
        z: text layer
        """
        Lay.place(D[RENDER], z, self.format_grp)
        pdb.gimp_text_layer_set_color(z, WH)
        Lay.move(z, x, y)
        z.opacity = 66.

    def draw_cell_margins(self, d):
        """
        Draws cell margins.

        d: format dict
        """
        just_one = Layout.is_draw_one_margin(d)
        row, col = d[ROW], d[COL]
        cell = self.cell
        m = 0
        for r in range(row):
            for c in range(col):
                margin = Layout.get_cell_margin(r, c, d)
                for x in range(4):
                    draw = 1

                    # left, right:
                    if x in (LEF_X, RIG_X):
                        if just_one and r > 0:
                            draw = 0

                    # top, bottom:
                    else:
                        if just_one and c > 0:
                            draw = 0
                    if draw:
                        v = margin[x]
                        if v:
                            # Unavailable cells have zero dimensions:
                            if cell.get_w(r, c):
                                m = 1
                                D[X], D[Y] = cell.get_pos(r, c)
                                D[X] += (
                                    0,
                                    0,
                                    -margin[LEF_X],
                                    cell.get_w(r, c))[x]

                                D[Y] += (
                                    -margin[TOP_X],
                                    cell.get_h(r, c),
                                    0,
                                    0)[x]

                                D[W] = (
                                    cell.get_margin_w(r, c, d),
                                    cell.get_margin_w(r, c, d),
                                    v,
                                    v)[x]

                                D[H] = (
                                    v,
                                    v,
                                    cell.get_margin_h(r, c, d),
                                    cell.get_margin_h(r, c, d))[x]
                                Sel.rect(D[RENDER])
        if m:
            self.fill(C2)

    def draw_coord(self, j):
        """
        Draws image coordinates at the top-left of an image rectangle.

        j: Img
        """
        n = str(j.x) + ", " + str(j.y)
        z = pdb.gimp_text_layer_new(D[RENDER], n, FONT, 11., fu.PIXELS)
        self.add_text(j.x + 3, j.y, z)

    def draw_corners(self, j):
        """
        Draw image corner coordinates.

        j: Img
        """
        # top-right:
        x = j.x + j.new_size[0]
        n = str(x) + ", " + str(j.y)
        z = pdb.gimp_text_layer_new(D[RENDER], n, FONT, 11., fu.PIXELS)

        self.add_text(x - z.width - 3, j.y, z)

        # bottom-left:
        y = j.y + j.new_size[1]
        n = str(j.x) + ", " + str(y)
        z = pdb.gimp_text_layer_new(D[RENDER], n, FONT, 11., fu.PIXELS)
        self.add_text(j.x + 3, y - z.height, z)

    def draw_dim(self, j):
        """
        Draws an image's dimension at the bottom-right of an image rectangle.

        j: image
        """
        w, h = j.new_size[0], j.new_size[1]
        n = str(w) + ", " + str(h)
        z = pdb.gimp_text_layer_new(D[RENDER], n, FONT, 11., fu.PIXELS)
        self.add_text(j.x + w - z.width - 3, j.y + h - z.height, z)

    def draw_format(self, d):
        """
        Draws a format.

        d: format dict
        """
        self.cell = Cell(d)
        e = D[SESS][PREVIEW_OPT]
        q = ((
                CELL_MARG, self.draw_cell_margins), (
                LAY_MARG, self.draw_layer_margins), (
                GRID, self.draw_grid
            ))

        self.draw_image_types(d)
        if e:
            for i in q:
                if e[i[0]]:
                    i[1](d)

    def draw_grid(self, d):
        """
        Draws grid lines.

        d: format dict
        """
        m = 0
        row, col = d[ROW], d[COL]
        w, h = D[WI], D[HG]
        top, left = d[LM_TOP], d[LM_LEF]

        # Grid lines divide the layer space:
        D[W] = w - left - d[LM_RIG]
        D[X] = left
        D[H] = 0

        # Draw rows:
        if row > 1:
            for r in range(1, row):
                D[Y] = self.cell.get_row_y(r)
                D[Y] += top
                if 0 < D[Y] < h:
                    m = 1
                    Sel.rect(D[RENDER])

        D[W], D[H] = 0, h - top - d[LM_BOT]
        D[Y] = top

        # Draw columns:
        if col > 1:
            for c in range(1, col):
                D[X] = self.cell.get_col_x(c)
                D[X] += left
                if 0 < D[X] < w:
                    m = 1
                    Sel.rect(D[RENDER])
        if m:
            self.fill(C5)

    def draw_image_types(self, d):
        """
        Draws a rectangle that represents an image.

        d: format dict
        """
        row, col = d[ROW], d[COL]
        cell = self.cell
        m = 0
        e = D[SESS][PREVIEW_OPT]
        q = ((
                COORD, self.draw_coord), (
                CORN, self.draw_corners), (
                DIM, self.draw_dim), (
                NAME, self.draw_name), (
                RAT, self.draw_ratio
            ))

        for r in range(row):
            for c in range(col):
                if cell.has_image(r, c, d):
                    m = 1
                    j = Layout.get_image(r, c, d)
                    j.r, j.c = r, c
                    j.rot = Layout.get_rotate(r, c, d)

                    if j.rot:
                        if m:
                            Sel.fill(D[LAYER], C3)
                            Sel.none(D[RENDER])
                            m = 0

                    if j.rot:
                        z = Lay.add(D[RENDER], j.n, z=self.format_grp)

                    Img.mold_rect(j, d, cell)

                    if j.rot:
                        self.rotate(j, z, cell, d)
                    if e:
                        for i in q:
                            if e[i[0]]:
                                i[1](j)
        if m:
            self.fill(C3)

    def draw_layer_margins(self, d):
        """
        Draws layer margins.

        d: format dict
        """
        m = 0
        for x, k in enumerate(LAY_SB_K):
            if d[k]:
                m = 1
                if x in (TOP_X, BOT_X):
                    # top, bottom:
                    D[X] = d[LM_LEF]
                    D[W] = D[WI] - d[LM_LEF] - d[LM_RIG]
                    D[H] = d[k]

                    if x == TOP_X:
                        D[Y] = 0

                    else:
                        D[Y] = D[HG] - d[k]

                else:
                    # left, right:
                    D[W] = d[k]
                    D[H] = D[HG] - d[LM_TOP] - d[LM_BOT]
                    D[Y] = d[LM_TOP]

                    if x == LEF_X:
                        D[X] = 0

                    else:
                        D[X] = D[WI] - d[k]
                Sel.rect(D[RENDER])
        if m:
            self.fill(C1)

    def draw_name(self, j):
        """
        Draws a document title at the center of an image rectangle.

        j: Img
        """
        z = pdb.gimp_text_layer_new(D[RENDER], j.n, FONT, 11., fu.PIXELS)
        x = j.new_size[0] / 2 + j.x - z.width / 2
        y = j.new_size[1] / 2 + j.y + z.height / 2
        self.add_text(x, y, z)

    def draw_ratio(self, j):
        """
        Draws an image ratio at the center of an image rectangle.

        A ratio is an image center point divided by the render size.

        j: Img
        """
        x = j.new_size[0] / 2 + j.x
        y = j.new_size[1] / 2 + j.y
        x1 = x / 1. / D[WI]
        y1 = y / 1. / D[HG]
        r_x = format(x1, '.2f')
        r_y = format(y1, '.2f')
        n = r_x[int(x1 < 1):] + ", " + r_y[int(y1 < 1):]
        z = pdb.gimp_text_layer_new(
            D[RENDER], n, FONT, 11., fu.PIXELS)

        x2 = x - z.width / 2
        y2 = y - z.height / 2
        self.add_text(x2, y2, z)

    def fill(self, q):
        """
        Fills the selection with a color on the current format layer.

        q: color (RGB tuple)
        """
        Sel.fill(D[LAYER], q)
        Sel.none(D[RENDER])

    def rotate(self, j, z, cell, d):
        """
        Rotates an image rectangle.

        j: Img
        z: rotation layer
        cell: Cell
        d: format dict
        """
        # Create a new image with the selection:
        j1 = D[RENDER]

        Sel.fill(z, C3)
        Sel.kopy(z)
        klear(z)
        Sel.none(j1)

        s = cell.get_cell_size(j.r, j.c)
        j2 = Img.paste()
        z1 = Lay.rotate(j2, j.rot)

        j.new_size = z1.width, z1.height

        if j.new_size[0] > s[0] or j.new_size[1] > s[1]:
            # The image won't fit into the cell so get the size that will:
            w, h = j.new_size = Img.calc_lock(s, j.new_size)
            z1 = pdb.gimp_item_transform_scale(z1, 0, 0, w, h)

        Sel.kopy(z1)

        Img.bury(j2)

        z3 = pdb.gimp_edit_paste(z, 0)
        z4 = float_to_layer(j1, z3)
        z4.name = "Rotated " + j.n

        Lay.bury(j1, z)
        cell.calc_rect_pos(d, j)
        Lay.move(z4, j.x, j.y)
        z4.opacity = 66.

        # for additional preview options:
        D[X], D[Y] = j.x, j.y

    def show(self):
        """ Draws the preview. """
        a = Preview
        a.pixl8 = Grid.pixl8
        Images.next_x = 0
        s = D[SIZE] = D[WI], D[HG] = D[SESS][WI], D[SESS][HG]

        if a.has_background:
            if a.size != s:
                # Delete old preview:
                pdb.gimp_image_undo_group_end(D[RENDER])
                pdb.gimp_display_delete(D[DISPLAY])
                a.has_background = a.has_formats = 0

        if not a.has_background:
            # Create a new preview:
            j = Layout.new_render()
            z = L[PREVIEW_BG] = Lay.add(j, PREVIEW_BG)
            D[DISPLAY] = pdb.gimp_display_new(j)
            a.has_background = 1
            a.size = D[WI], D[HG]
            Lay.color_fill(z, C4)

        j = D[RENDER]
        q = D[SESS][FORMAT]
        start = len(q) - 1

        if a.has_formats:
            # Delete group:
            Lay.bury(j, L[PREVIEW])

        if start > -1:
            # new group:
            x = 1 if Grid.pixl8 else 0
            z = L[PREVIEW] = Lay.group(
                j, "Preview: " + ("Normal Layout", "Pixelize Layout")[x])

        # Draw format previews:
        for x in range(start, -1, -1):
            a.has_formats = 1
            d = q[x]
            n = d[NAME]
            z1 = self.format_grp = Lay.group(j, "Preview Group: " + n)

            Lay.order(j, z1, z)

            z1 = D[LAYER] = Lay.add(j, "Preview: " + n, z=z1)
            z1.opacity = 66.
            self.draw_format(d)

        Lay.activate(j, z)
        pdb.gimp_displays_flush()


class Cell:
    """ Calculates cell-related dimensions. """

    def __init__(self, d):
        """
        Creates a new cell table, ‟tb”, to store the cell sizes.

        Calculates cell sizes.

        Corrects cell size underflow.

        d : format dict
        """
        r, c = d[ROW], d[COL]
        r, c = d[ROW], d[COL] = min(r, D[HG]), min(c, D[WI])
        self.r, self.c = r, c

        # cell table with cell keys: X, Y, W, H:
        self.tb = create_2d_table(r, c)

        # Calculate layer size:
        w = D[WI] - d[LM_LEF] - d[LM_RIG]
        h = D[HG] - d[LM_TOP] - d[LM_BOT]

        # ‟s” is the size of a cell before image margins are subtracted
        # and after layer margins are subtracted from the layer size:
        s = seal(w, 1, D[WI]), seal(h, 1, D[HG])
        self.odd = Grid(s, self.r, self.c)

        # Cells reduce their size with cell margins:
        for r in range(self.r):
            for c in range(self.c):
                self.calc_cell(r, c, d)

    def calc_block(self, start, end, d):
        """ Recalculates the cell sizes for a block of cells. """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self.calc_cell(r, c, d)

    def calc_cell(self, r, c, d):
        """
        Adds a dict entry to ‟self.tb” for the cell at r, c.

        d: format dict
        """
        # Check if merging cells:
        if d[MERG_PER]:
            s = d[ME_CELL][r][c]

            # Sub-top-left cells are unavailable:
            if s == (-1, -1):
                x = y = w = h = 0

            else:
                k1 = (r + s[0] - 1, c + s[1] - 1)
                x, y, w, h = self.odd.block((r, c), k1)

        else:
            x, y, w, h = self.odd.cell(r, c)

        if w:
            a = Layout.get_cell_margin(r, c, d)
            x += a[LEF_X] + d[LM_LEF]
            y += a[TOP_X] + d[LM_TOP]

            # Correct for margin overflow errors:
            x = seal(x, 0, D[WI] - 1)
            y = seal(y, 0, D[HG] - 1)
            w = w - a[LEF_X] - a[RIG_X]
            h = h - a[TOP_X] - a[BOT_X]

            # Set ‟w”, ‟h” to the minimum value if size under-flowed:
            w, h = max(w, 1), max(h, 1)
        self.tb[r][c] = dict(x=x, y=y, w=w, h=h)

    def calc_rect_pos(self, d, j):
        """
        For an image or rectangle, calculates its (x, y) position in a cell.

        d: format dict
        j: Img
        """
        r, c = j.r, j.c
        x, y = self.get_pos(r, c)
        w, h = j.new_size[0], j.new_size[1]

        n = Layout.get_horz_just(r, c, d)
        n1 = Layout.get_vert_just(r, c, d)

        if n == CE:
            self.get_w(r, c)
            x += (self.get_w(r, c) - w) / 2

        elif n == RGT:
            x += self.get_w(r, c) - w

        if n1 == MID:
            y += (self.get_h(r, c) - h) / 2

        elif n1 == BOT:
            y += self.get_h(r, c) - h
        j.x, j.y = x, y

    def get_cell_info(self, r, c):
        """ Returns a cell's dimension and position for a cell at r, c. """
        return (
            self.tb[r][c][W], self.tb[r][c][H],
            self.tb[r][c][X], self.tb[r][c][Y])

    def get_cell_size(self, r, c):
        """ Returns a cell's width and height for a cell at r, c. """
        return self.tb[r][c][W], self.tb[r][c][H]

    def get_col_x(self, c):
        """ Returns the coordinate x for column, c. """
        x, _, _, _ = self.odd.cell(0, c)
        return x

    def get_row_y(self, r):
        """ Returns the coordinate y for row, r. """
        _, y, _, _ = self.odd.cell(r, 0)
        return y

    def get_h(self, r, c):
        """ Returns the cell height for a cell at r, c. """
        return self.tb[r][c][H]

    def get_margin_h(self, r, c, d):
        """
        Returns the height of an image margin for the cell at r, c.

        d: format dict
        """
        if Layout.is_draw_one_margin(d):
            a = Layout.get_cell_margin(r, c, d)
            return D[HG] - d[LM_TOP] - d[LM_BOT] - a[TOP_X] - a[BOT_X]

        else:
            return self.get_h(r, c)

    def get_margin_w(self, r, c, d):
        """
        Returns the width of an image margin at r, c.

        d: format dict.
        """
        if Layout.is_draw_one_margin(d):
            a = Layout.get_cell_margin(r, c, d)
            return D[WI] - d[LM_LEF] - d[LM_RIG] - a[LEF_X] - a[RIG_X]

        else:
            return self.get_w(r, c)

    def get_pos(self, r, c):
        """ Returns the cell coordinate (x, y) for a cell at r, c. """
        return self.tb[r][c][X], self.tb[r][c][Y]

    def get_w(self, r, c):
        """ Returns the cell width for a cell at r, c. """
        return self.tb[r][c][W]

    def has_image(self, r, c, d):
        """
        Returns true if a cell has an available image at r, c.

        d: format dict
        """
        if self.get_w(r, c):
            a = Layout.get_placement(r, c, d)
            n = a[IMAGE_X]

            if n == NON or not Layout.get_prop_opacity(r, c, d):
                return 0

            if n == NXT:
                if Images.image_count > Images.next_x:
                    return 1

                else:
                    return 0
            if n in Images.format_img_list:
                return 1
        return 0


class CG:
    """ Manages cell grouping and serves UICell. """

    # ‟overlay” is a flag. When it is true,
    # merge cell controls are not displayed:
    overlay = 0

    # ‟collective” is a table of cell dictionaries:
    collective = None

    # ‟sizer” is a Cell.
    # It's used when displaying cell sizes in a Merge Cells window:
    sizer = None

    # ‟format” is a format dict:
    format = None

    @staticmethod
    def calc_bottom_right(d):
        """
        Return the row and column for the
        bottom-right cell of a merged cell group.

        d: top-left cell dict
        """
        return d[R] + d[V][0] - 1, d[C] + d[V][1] - 1

    @staticmethod
    def connect_left(d):
        """
        This routine is called when the user has clicked
        on a horizontal connector in the cell graph.

        d: cell dict
        """
        origin = CG.get_topleft(d=d)
        top = CG.get_topleft(u=(d[R], d[C] - 1))
        CG.merge_groups(top, origin)

    @staticmethod
    def connect_up(d):
        """
        Called when the user has clicked on
        a vertical connector in the cell graph.

        d: cell dict
        """
        origin = CG.get_topleft(d=d)
        top = CG.get_topleft(u=(d[R] - 1, d[C]))
        CG.merge_groups(top, origin)

    @staticmethod
    def draw(d):
        """
        Draws a cell and its connectors.

        d: cell dict
        """
        g = CG.get_topleft(d=d)
        start, end = CG.get_start_end_of_top(g)
        CG.set_cell_looks(d, start, end)

    @staticmethod
    def generate_group(slices):
        """
        Slices organize themselves into one or two groups.

        A slice is a cell group with a piece of itself
        removed by a ‟connect_up” or ‟connect_left” process
        and the resulting merge group.

        slices: a dict of dictionaries where each defines a group of cells
        """
        for k in slices:
            """
            Sort the two possible groups
            into a larger and smaller group (short).
            The larger group will have the greater cell count.
            The smaller group will be the cells not in the larger group.
            If there's only one group,
            the smaller group won't get initialized.

            Starts by finding the longer and shorter row.
            """
            u = slices[k][V]
            long_row_width = long_row_height = 0
            long_col_width = long_col_height = 0
            short_col_width = short_row_height = 0
            short_row_width = short_col_height = 0
            start_long_row = [0, 0]
            start_short_row = [0, 0]
            start_long_col = [0, 0]
            start_short_col = [0, 0]

            for r in range(k[0], k[0] + u[0]):
                row_width = 0
                first_col = -1

                for c in range(k[1], k[1] + u[1]):
                    if CG.is_vector(k, r, c):
                        row_width += 1
                        if first_col < 0:
                            first_col = c

                    elif row_width:
                        break

                if row_width > long_row_width:
                    if long_row_width > 0:
                        # Second group inherits from the first group:
                        short_row_width = long_row_width
                        short_row_height = long_row_height
                        start_short_row = start_long_row

                    # Initialize first group:
                    long_row_width = row_width
                    long_row_height = 1
                    start_long_row = r, first_col

                elif row_width:
                    # The vector is long or short:
                    if row_width == long_row_width:
                        long_row_height += 1

                    else:
                        if short_row_height:
                            # Add another row:
                            short_row_height += 1

                        else:
                            # Initialize second group:
                            short_row_width = row_width
                            start_short_row = r, first_col
                            short_row_height = 1

            # Start finding the long and short column:
            for c in range(k[1], k[1] + u[1]):
                col_height = 0
                first_row = -1

                for r in range(k[0], k[0] + u[0]):
                    if CG.is_vector(k, r, c):
                        col_height += 1
                        if first_row < 0:
                            first_row = r

                    elif col_height:
                        break

                if col_height > long_col_height:
                    if long_col_height > 0:
                        # Second group inherits from the first group:
                        short_col_width = long_col_width
                        short_col_height = long_col_height
                        start_short_col = start_long_col

                    # Initialize first group:
                    long_col_height = col_height
                    long_col_width = 1
                    start_long_col = first_row, c

                elif col_height:
                    # The vector is long or short:
                    if col_height == long_col_height:
                        long_col_width += 1

                    else:
                        if short_col_height:
                            short_col_width += 1

                        else:
                            # Initialize second group:
                            short_col_width = 1
                            short_col_height = col_height
                            start_short_col = first_row, c

            row_cells = long_row_width * long_row_height
            col_cells = long_col_height * long_col_width
            v = 0

            if row_cells >= col_cells:
                u = long_row_height, long_row_width
                d = CG.grid[start_long_row[0]][start_long_row[1]]

                # Process second group if it was initialized:
                if short_row_width > 0:
                    v = short_row_height, short_row_width
                    d1 = CG.grid[
                        start_short_row[0]][start_short_row[1]]

            else:
                u = long_col_height, long_col_width
                d = CG.grid[start_long_col[0]][start_long_col[1]]

                # Process second group if it was initialized:
                if short_col_height > 0:
                    v = short_col_height, short_col_width
                    d1 = CG.grid[
                        start_short_col[0]][start_short_col[1]]

            CG.set_group(d, u)

            # Set the second group if it there was one:
            if v:
                CG.set_group(d1, v)

    @staticmethod
    def get_d(r, c):
        """ Returns the dictionary for the cell at r, c. """
        return CG.grid[r][c]

    @staticmethod
    def get_start_end_of_top(d):
        """
        Return the row and column for the current
        cell and its bottom-right cell.

        d: cell dict
        """
        s = d[R], d[C]
        t = s[0] + d[V][0] - 1, s[1] + d[V][1] - 1
        return s, t

    @staticmethod
    def get_topleft(d=None, u=None):
        """
        Top-left is the cell located at the top-left of a group.

        Sub-top-left cells refer to the top-left
        cell through a ‟topleft” key.

        d: cell dict
        u: (r, c)
        """
        if u:
            d = CG.grid[u[0]][u[1]]

        if d[V][0] < 0:
            v = d['topleft']

        else:
            v = d[R], d[C]
        return CG.grid[v[0]][v[1]]

    @staticmethod
    def is_group(d):
        """
        Returns true if a cell is part of a group.

        d: cell dict
        """
        return CG.is_topleft(d) or d[V] == (-1, -1)

    @staticmethod
    def is_outside(d, r, c, s):
        """
        Returns true if the cell has cells that
        exist outside the bounds of a rectangle.

        d: cell dict
        r, c, s: bounds
        """
        if d[R] < r or d[C] < c or d[R] \
                + d[V][0] > r + s[0] or d[C] \
                + d[V][1] > c + s[1]:
            return 1

    @staticmethod
    def is_topleft(d):
        """
        Returns true if the cell is a top-left cell.

        d: cell dict
        """
        return d[V][0] > 1 or d[V][1] > 1

    @staticmethod
    def is_vector(u, r, c):
        """
        Returns true if the cell (r, c) is still
        referencing a top-left cell at ‟u”.

        u:  (r, c)
        """
        d = CG.grid[r][c]

        # Independent cells are not part of a vector:
        if CG.is_group(d):
            a = CG.get_topleft(d)

            # Cell must refer to its old top:
            if a[R] == u[0] and a[C] == u[1]:
                return 1

    @staticmethod
    def merge_groups(top, origin):
        """
        Merge two groups into a new group.

        top: top-left cell
        origin: top-left cell
        """
        # Get bottom-rights:
        o_b_r = CG.calc_bottom_right(origin)
        t_b_r = CG.calc_bottom_right(top)

        # Merge group settings:
        m_pos = min(top[R], origin[R]), min(top[C], origin[C])
        m_b_r = tuple(max(o, m) for o, m in zip(o_b_r, t_b_r))
        diff = tuple(n - m for n, m in zip(m_b_r, m_pos))
        v = diff[0] + 1, diff[1] + 1

        # Get top-left cell of the merged group:
        m = CG.get_d(m_pos[0], m_pos[1])

        """
        Create a dictionary of potential slices.

        Slices are groups that are part of a merged group rectangle,
        but are exclusive of top and origin groups.

        Slices also have cells outside the bounds of the merged group.
        """
        sliced = {}

        for r in range(m_pos[0], m_pos[0] + v[0]):
            for c in range(m_pos[1], m_pos[1] + v[1]):
                d = CG.grid[r][c]
                if CG.is_group(d):
                    t = CG.get_topleft(d)
                    if t[R] != top[R] or t[C] != top[C]:
                        if t[R] != origin[R] or t[C] != origin[C]:
                            if CG.is_outside(t, m[R], m[C], v):
                                key = t[R], t[C]
                                if KEY not in sliced:
                                    sliced[key] = dict(v=t[V])

        CG.set_group(m, v)
        CG.generate_group(sliced)

    @staticmethod
    def set_block_looks(start, end):
        """
        Sets the appearance of a block of cells.

        start: (r, c) for the top-left cell
        end: (r, c) for the bottom-right cell
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                CG.set_cell_looks(CG.get_d(r, c), start, end)

    @staticmethod
    def set_cell_looks(d, start, end):
        """
        Sets a cell's appearance.

        d: cell dict
        start: (r, c) for the top-left cell
        end: (r, c) for the bottom-right cell
        """
        if d[V] == (1, 1):
            CG.set_single_looks(d)

        else:
            # The cell is a member of a group:
            k = 'left_b'
            k1 = 'top_b'

            # cell neighbor flags:
            top = d[R] > start[0]
            bottom = d[R] < end[0]
            left = d[C] > start[1]
            right = d[C] < end[1]

            # TBLR:
            w = PAD5[:]

            for x, i in enumerate((top, bottom, left, right)):
                if i:
                    w[x] = 0

            d[PAD].set_padding(*w)
            CG.set_group_looks(d)
            if not CG.overlay:
                # button updates:
                if k in d:
                    if left:
                        w = [5, 5, 0, 0]
                        for x, i in enumerate((top, bottom)):
                            if i:
                                w[x] = 0
                        d[k].pad.g.set_padding(*w)
                        d[k].set_label("-")
                        d[k].switch = 1

                    else:
                        d[k].set_label("+")
                        d[k].switch = 0
                        d[k].pad.g.set_padding(5, 5, 0, 0)

                if k1 in d:
                    if top:
                        w = [0, 0, 5, 5]
                        for x, i in enumerate((left, right)):
                            if i:
                                w[x + 2] = 0

                        d[k1].pad.g.set_padding(*w)
                        d[k1].set_label("-")
                        d[k1].switch = 1

                    else:
                        d[k1].set_label("+")
                        d[k1].switch = 0
                        d[k1].pad.g.set_padding(0, 0, 5, 5)
        CG.update_cell_label(d)

    @staticmethod
    def set_group(top, s):
        """
        Sets a group's sub-cell's attributes and the group's appearance.

        top: a new group dict
        s: group's new dimensions
        """
        top[V] = s
        start, end = CG.get_start_end_of_top(top)

        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                if r != top[R] or c != top[C]:
                    CG.set_subtop(top, CG.grid[r][c])
        CG.update_block(start, end)

    @staticmethod
    def set_group_looks(d):
        """
        Changes the appearance of a cell's frame to appear merged.

        d: cell dict
        """
        d['event_box'].modify_bg(ABLE, BG_GROUP)

    @staticmethod
    def set_single_looks(d):
        """
        Changes the appearance of a cell's frame to appear independent.

        d: cell dict
        """
        d[PAD].set_padding(*(5,) * 4)
        d['event_box'].modify_bg(ABLE, BG_CELL)

    @staticmethod
    def set_subtop(d, e):
        """
        Used when a cell is merged into a group.

        Modifies the cell's dictionary to identify the cell as sub-top.

        d: the top-left cell's dict
        e: the sub-top cell's dict
        """
        e['topleft'] = d[R], d[C]
        e[V] = -1, -1

    @staticmethod
    def split_horz(d):
        """
        The user has clicked a horizontal black connector.

        This routine divides the group containing
        this connector of two columns.

        d: cell dict
        """
        c = d[C]
        top = CG.get_topleft(d=d)
        w = c - top[C]
        w1 = top[V][1] - w
        e = CG.get_d(top[R], top[C] + w)
        CG.set_group(e, (top[V][0], w1))
        CG.set_group(top, (top[V][0], w))

    @staticmethod
    def split_vert(d):
        """
        The user has clicked a vertical black connector.

        This routine divides the group
        containing this connector of two rows.

        d: cell dict
        """
        r = d[R]
        top = CG.get_topleft(d=d)
        h = r - top[R]
        h1 = top[V][0] - h
        e = CG.get_d(top[R] + h, top[C])

        # Create a new groups from the split:
        CG.set_group(e, (h1, top[V][1]))
        CG.set_group(top, (h, top[V][1]))

    @staticmethod
    def update_block(start, end):
        """
        Updates format data, cell size table,
        and the cell appearance for a block of cells.

        start: the top-left cell in the block
        end: the bottom-right cell in the block
        """
        CG.update_format(start, end)
        CG.sizer.calc_block(start, end, CG.format_c.format)
        CG.set_block_looks(start, end)

    @staticmethod
    def update_cell_label(d):
        """
        Called whenever a cell is drawn.

        Updates the cell dimension labels.

        d: cell dict
        """
        if not CG.overlay:
            if CG.is_topleft(d) or d[V] == (1, 1):
                b = CG.sizer.get_cell_info(d[R], d[C])

                if LAB_W in d:
                    for x, k in enumerate(LAB_K):
                        d[k].lab.set_text(LAB_I[x] + str(b[x]))

                else:
                    for x, k in enumerate(LAB_K):
                        g = d[k] = RLabel(LAB_I[x] + str(b[x]))

                        d['box'].add(d[k].g)

                        # Need to show both:
                        g.g.show()
                        g.lab.show()

            else:
                if LAB_W in d:
                    # Delete the Labels:
                    for k in LAB_K:
                        b = d[k]

                        d['box'].remove(b.g)
                        d.pop(k)
                        b.destroy()

    @staticmethod
    def update_format(start, end):
        """
        Updates the format data for a block of cells.

        start: the top-left cell in the block
        end: the bottom-right cell in the block.
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                CG.format_c.format[ME_CELL][r][c] = CG.grid[r][c][V]


class Preset:
    """
    Presets are used to store session and format values.

    External presets are created by the user and given a name.
    """
    # indices:
    src_x = 0    # external or internal source index
    name_x = 1   # Name of the Preset index
    file_x = 2   # External data: file name index
    data_x = 2   # Internal preset data index

    def __init__(self, d):
        """ d: dict """
        self.default_preset = deepcopy(d[DEF])
        self.internal_presets = d[INTERNAL]
        self.parent = d[PARENT]
        self.name = d[NAME]

    def get_preset(self, n, presets):
        """
        Returns a preset from internal and external sources.

        n: name of preset
        presets: preset list
        """
        d = deepcopy(self.default_preset)

        for q in presets:
            if n == q[Preset.name_x]:
                if q[Preset.src_x] == PRESET_EXT:
                    e = pickle_load({'file': q[Preset.file_x]})

                    if e:
                        d = e
                    break

                else:
                    # Load internal data:
                    d = q[Preset.data_x]
                break
        return d

    def is_internal(self, n, presets):
        """
        Returns true if the preset is an internal-type.

        n: preset name
        """
        for q in presets:
            if n == q[Preset.name_x]:
                if q[Preset.src_x] == PRESET_INT:
                    return 1


class PRFormat(Preset):
    """
    This is the Preset used in the Format window.

    Stores values from the UIFormat window and from its Per Cell windows.
    """
    def __init__(self, d):
        """ d: dict """
        q = d[DEF] = [PRESET_INT, DEF, deepcopy(Format.default)]
        d[INTERNAL] = [q]
        d[NAME] = FORMAT
        Preset  .__init__(self, d)


class PRSession(Preset):
    """
    This is the Preset used in the Form group.

    Its Preset is the Session data.
    """

    def __init__(self, d):
        """ d: dict """
        e = d[DEF] = deepcopy(Session.default)

        # Don't deepcopy D[WIN]:
        e[WIN] = D[WIN]
        d[INTERNAL] = [[PRESET_INT, DEF, e]]
        d[NAME] = SESS
        Preset.__init__(self, d)


class PRSubSession(Preset):
    """
    This is the Preset used in the Form group.

    Its Preset is the Session data.
    """

    def __init__(self, d):
        """ d: dict """
        e = d[DEF] = deepcopy(Session.default[d[NAME]])
        q = [[DEF, e], [USE, D[SESS][d[NAME]]]]
        k = INTERNAL
        q1 = []

        if k in d:
            for q2 in d[k]:
                q.append(q2)

        for q2 in q:
            q1.append([PRESET_INT] + q2)

        d[k] = q1
        Preset.__init__(self, d)


class Images:
    """ Used to manage the open images. """
    # number of valid images:
    image_count = 0

    # next image index:
    next_x = 0

    # open images:
    images = []

    # valid image names:
    image_names = []
    format_img_list = []
    relative_names = []

    @staticmethod
    def get_img():
        """ Collect related data for images. """
        # post-fix image number tuple:
        q = pdb.gimp_image_list()[1][::-1]

        # gimp.Image list:
        q1 = reversed(gimp.image_list())

        for x, j in enumerate(q1):
            n = j.name + "-" + str(q[x])
            Images.images.append(Img(j, n))

        q = Images.image_names = Images.make_image_name_list()
        Images.image_count = len(q)

        for i in range(len(q)):
            go = 1
            while go:
                go = q.count(q[i]) - 1
                if go:
                    x = q.index(q[i])
                    q[x] = Images.images[x].n = q[x] + " (" + str(go) + ")"

        # Make list for format:
        q = Images.format_img_list = Images.image_names[:]
        b = Images.relative_names

        for i in range(len(q)):
            n = str(i + 1)
            a1 = i + 1

            if i == 0 or (a1 > 20 and a1 % 10 == 1):
                c = n + "st"

            elif i == 1 or (a1 > 20 and a1 % 10 == 2):
                c = n + "nd"

            elif i == 2 or (a1 > 20 and a1 % 10 == 3):
                c = n + "rd"

            else:
                c = n + "th"
            b.append(c + " Image")

        q.append("★")

        q += b

        q.insert(0, NXT)
        q.insert(1, NON)
        q.insert(2, "★")

    @staticmethod
    def get_next():
        """ Returns the next Img or none. """
        j = None
        a = Images

        if a.next_x < a.image_count:
            j = a.images[a.next_x]
            a.next_x += 1
        return j

    @staticmethod
    def make_image_name_list():
        """ Returns a list of valid image names. """
        return [i.n for i in Images.images]


class Img:
    """ Used to manage an open image. """

    def __init__(self, j, n):
        """ j: image """
        Sel.none(j)
        self.j = j
        self.n = n
        self.size = j.width, j.height

    @staticmethod
    def bury(j):
        """
        Deletes an image that doesn't have a display.

        j: GIMP image
        """
        pdb.gimp_image_delete(j)

    @staticmethod
    def calc_lock(s, t):
        """
        Returns the size of an image that will fit into a smaller cell.

        s: cell size
        t: image size
        """
        w_r = float(t[0]) / s[0]
        h_r = float(t[1]) / s[1]

        if w_r > h_r:
            w, h = s[0], int(t[1] * (s[0] / float(t[0])))

        else:
            w, h = int(t[0] * (s[1] / float(t[1]))), s[1]

        # underflow:
        return w + int(int(w) == 0), h + int(int(h) == 0)

    @staticmethod
    def get_image(n):
        """
        Returns an Img object.

        n: name of image
        """
        a = Images

        if n == NXT:
            j = a.get_next()

        elif n in a.image_names:
            x = a.image_names.index(n)
            j = a.images[x]

        else:
            x = a.relative_names.index(n)
            j = a.images[x]
        return j

    @staticmethod
    def get_trim_size(s, t):
        """
        Returns the size of the trim.

        s: image size
        t: cell size
        """
        w_r = t[0] / 1. / s[0]
        h_r = t[1] / 1. / s[1]

        if s[0] < t[0] and s[1] < t[1]:
            # No trim needed:
            w, h = s

        else:
            if w_r < h_r:
                # The image height is closer to the cell size:
                w, h = int(s[0] * h_r), t[1]

            else:
                # The image width is closer to the cell size:
                w, h = t[0], int(s[1] * w_r)

        # underflow:
        return [w + int(int(w) == 0), h + int(int(h) == 0)]

    @staticmethod
    def mold(j, d, cell):
        """
        Molds an image to fit a cell.

        d: format dict
        cell: Cell
        """
        j1 = D[RENDER]

        Sel.none(j1)

        s = j.cell_size = cell.get_cell_size(j.r, j.c)

        # Resize index for fill, locked, none, trim:
        x = RSZ.index(Layout.get_resize_type(j.r, j.c, d))

        (Img.mold_fill, Img.mold_lock, Img.mold_none, Img.mold_trim)[x](j, d)

        if j.rot:
            j2 = Img.paste()
            z = Lay.rotate(j2, j.rot)
            t = w, h = z.width, z.height

            kopy(j2)
            Img.bury(j2)

            if w > s[0] or h > s[1]:
                t = w, h = Img.calc_lock(s, t)
                j3 = Img.paste()
                Img.shape(j3, w, h)
            j.new_size = t
        cell.calc_rect_pos(d, j)

    @staticmethod
    def mold_fill(j, _):
        """
        Resizes a fill image resize-type.

        Returns with the image data in the buffer.
        """
        if j.size != j.cell_size:
            kopy(j.j)
            j1 = Img.paste()
            j.new_size = w, h = j.cell_size
            Img.shape(j1, w, h)

        else:
            j.new_size = j.size
            kopy(j.j)

    @staticmethod
    def mold_lock(j, _):
        """
        Resizes a locked image resize-type.

        Returns with the image data in the buffer.
        """
        kopy(j.j)
        if j.size[0] > j.cell_size[0] or j.size[1] > j.cell_size[1]:
            # down-size:
            w, h = Img.calc_lock(j.cell_size, j.size)
            j1 = Img.paste()
            Img.shape(j1, w, h)

        else:
            w, h = j.size
        j.new_size = w, h

    @staticmethod
    def mold_none(j, d):
        """
        Resizes an None image resize-type.

        Returns with the image data in the buffer.

        d: format dict
        """
        if j.size[0] > j.cell_size[0] or j.size[1] > j.cell_size[1]:
            # Copy a rectangle:
            j.new_size = Layout.sel_img_trim(d, j, j.j)

        else:
            j.new_size = j.size
            kopy(j.j)

    @staticmethod
    def mold_rect(j, d, cell):
        """
        Draws an image rectangle for preview
        that corresponds with the format.

        d: format dict
        cell: Cell
        """
        s = j.size
        t = j.cell_size = cell.get_cell_size(j.r, j.c)

        typ = Layout.get_resize_type(j.r, j.c, d)

        # [FIL, LCK, NON, TRM]
        if typ == FIL:
            s1 = t

        elif typ == LCK:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = Img.calc_lock(t, s)

            else:
                s1 = s

        elif typ == NON:
            s1 = list(s)

            if s[0] > t[0]:
                s1[0] = t[0]
            if s[1] > t[1]:
                s1[1] = t[1]

        else:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = Img.get_trim_size(s, t)
                if s1[1] > t[1]:
                    s1[1] = t[1]

                else:
                    s1[0] = t[0]

            else:
                s1 = s

        D[NAME] = j.n
        D[W], D[H] = j.new_size = s1

        cell.calc_rect_pos(d, j)

        D[X], D[Y] = j.x, j.y
        Sel.rect(D[RENDER])

    @staticmethod
    def mold_trim(j, d):
        """
        Resizes a None image resize-type.

        Returns with the image data in the buffer.

        d: format dict
        """
        s = s1 = j.size
        t = j.cell_size

        kopy(j.j)

        if s[0] > t[0] or s[1] > t[1]:
            w, h = Img.get_trim_size(s, t)
            j1 = Img.paste()
            Img.shape(j1, w, h)

            j1 = Img.paste()
            s1 = Layout.sel_img_trim(d, j, j1)

            # Copy selection:
            kopy(j1)
            Img.bury(j1)
        j.new_size = s1

    @staticmethod
    def new(w, h):
        """
        Creates a new image based on the global scales.

        w, h: size of the new image

        Returns the new image.
        """
        return pdb.gimp_image_new(w, h, fu.RGB)

    @staticmethod
    def paste():
        """
        Pastes the buffer as a new image.

        Returns the new image.
        """
        return pdb.gimp_edit_paste_as_new_image()

    @staticmethod
    def shape(j, w, h):
        """
        Resizes, copies, and kills an image.

        j: GIMP image with one layer
        w: width
        h: height
        """
        z = j.layers[0]

        pdb.gimp_context_set_interpolation(LINEAR)
        pdb.gimp_layer_scale(z, w, h, 1)
        pdb.gimp_image_resize_to_layers(j)
        kopy(j)
        Img.bury(j)


class Format:
    """ Manages UIFormat session data. """

    # Read only:
    default = {
        NAME: "Format",
        EFFECT: NON,
        RESIZE: LCK,
        HORZ: CE,
        VERT: MID,
        IMAGE: NXT,
        ROT: 0,
        OP: 100,
        BB: 0,
        FLIP_H: 0,
        FLIP_V: 0,
        MERG_PER: 0,
        PROP_PER: 0,
        PLACE_PER: 0,
        CM_PER: 0,
        ROW: 1,
        COL: 1,
        LM_TOP: 0,
        LM_LEF: 0,
        LM_RIG: 0,
        LM_BOT: 0,
        CM_TOP: 0,
        CM_LEF: 0,
        CM_RIG: 0,
        CM_BOT: 0,
        PRESET: DEF,
        ME_CELL: None,
        PL_CELL: None,
        CM_CELL: None,
        PR_CELL: None}

    def __init__(self, d):
        self.format = deepcopy(d)


class Session:
    """ Stores session control values. """

    # Read only:
    default = {
        AUTO: 0,
        BD_STYLE: TR,
        BD_IMG: FIRST,
        BG: GRAD_D.copy(),
        BL: {
            BORD_W: 10,
            BORD_TYP: 1,
            INHERIT: 0,
            LIGHT: 45.,
            SEED: 0,
            DETAIL: 7,
            HOLD: 4,
            POWER: 30},

        CB: {
            BORD_W: 1,
            COLOR1: WH,
            BORD_TYP: 1,
            INHERIT: 0},

        CF: {
            COLOR1: GRY,
            CRIT: CRIT_LIST[0],
            MODE: NORM,
            OP: 100,
            STARTX: 0,
            STARTY: 0,
            THRESH: 1.},

        CLF: {
            BORD_TYP: 1,
            BORD_W: 40,
            COLOR1: WH,
            INHERIT: 0},

        COD: {
            COL: 4,
            COLOR1: BLK,
            COLOR2: WH,
            MODE: NORM,
            OP: 100,
            PIXL8: 0,
            ROW: 4},

        COG: {
            COL: 4,
            COLOR1: BLK,
            COLOR2: WH,
            MODE: NORM,
            OP: 100,
            PIXL8: 0,
            ROW: 4},

        DS: SHADOW_D.copy(),
        ES: {
            BLUR: 20,
            COLOR3: BLK,
            INHERIT: 0,
            OP: 120},

        FLS: SHADOW_D.copy(),
        FORMAT: [],
        GF: GRAD_D.copy(),

        HG: 1080,
        IS: {
            BLUR: 30,
            COLOR3: BLK,
            INHERIT: 0,
            OP: 100},

        KLS: SHADOW_D.copy(),
        PF: {
            CRIT: CRIT_LIST[0],
            MODE: NORM,
            OP: 100,
            PATTERN: None,
            STARTX: 0,
            STARTY: 0,
            THRESH: 1.},

        PG: {
            COL: 4,
            MODE: NORM,
            OP: 100,
            ROW: 4},

        PRESET: DEF,
        PREVIEW_OPT: {
            LAY_MARG: 0,
            CELL_MARG: 0,
            COORD: 0,
            DIM: 0,
            CORN: 0,
            GRID: 0,
            NAME: 0,
            RAT: 0},
        WI: 1920}

    @staticmethod
    def load(d):
        """
        Loads a Session file.
        Checks to see if its valid.

        d: dict

        Returns the Session data or (0 or -1) for failure.
        """
        e = pickle_load(d)

        if e:
            d1 = deepcopy(Session.default)
            d1[WIN] = {}
            pass_version(e, d1)
            for d1 in e[FORMAT]:
                pass_version(d1, Format.default, is_format=1)

        else:
            e = 0
        return e


class UI:
    """
    Creates windows.

    Holds common user-interface functions.
    """
    loading = 0

    # This is the reference to the window with a ‟gtk.main” event loop:
    loop = None

    def __init__(self, d):
        """ d: dict """
        self.pigs = []
        self.accept = d[ACCEPT]
        self.color = MAX_COL - 2200

        # ‟self.pose” is the window name key in the WIN dict:
        self.pose = d[POSE]

        if not UI.loop:
            is_dialog = 0
            g = self.win = UI.loop = gtk.Window()
            g.set_title(d[TITLE])
            if not UIMain.is_done:
                w, h = UI.get_screen_res()
                Session.default[WI], Session.default[HG] = w, h
                GRAD_D[ENDX], GRAD_D[ENDY] = w, h
                if SESS in D:
                    if D[SESS][PRESET] == DEF:
                        D[SESS][WI], D[SESS][HG] = w, h

        else:
            self.reply = 0
            is_dialog = 1
            g = self.win = gtk.Dialog(
                d[TITLE],
                UI.loop,
                gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
                None)

        UI.loading += 1

        d[DRAW]()

        UI.loading -= 1

        g.set_position(gtk.WIN_POS_CENTER)
        g.show_all()

        if self.pose in D[WIN]:
            # Make sure the position isn't off screen:
            w, h = UI.get_screen_res()
            w1, h1 = self.win.allocation.width, self.win.allocation.height
            x, y = D[WIN][self.pose]
            x = seal(x, 0, w - w1)
            y = seal(y, 0, h - h1 - SCROLL)
            g.move(x, y)

        else:
            g.set_position(gtk.WIN_POS_CENTER)
            x, y = g.get_position()
            w, h = UI.get_screen_res()
            w1, h1 = self.win.allocation.width, self.win.allocation.height
            g.move(w / 2 - w1 / 2 - x, h / 2 - h1 / 2 - y)

        g.connect('delete_event', self.close)
        g.connect(KEY_PRESS, self.on_key_press)
        if is_dialog:
            self.win.run()
            self.win.destroy()

    def close(self, *_):
        """
        Closes the window.
        Exits the main loop.

        Returns true to let GTK know that the closing operation is handled.
        """
        g = self.win
        D[WIN][self.pose] = g.get_position()

        if g == UI.loop:
            g.destroy()
            gtk.main_quit()
            UI.loop = None

        else:
            g.hide()
            g.response(0)
        return 1

    def do_return(self):
        """ Called by ‟on_key_press” when the user hits the Return key. """
        return self.accept()

    @staticmethod
    def get_preset_name(n, n1):
        """
        n: preset name

        n1: file specific id
        """
        return n + PRESET_SEP + n1 + u".pkl"

    @staticmethod
    def get_preset_path(n, n1):
        """
        Returns a path to a preset.

        n: preset name or key
        n1: file id
        """
        n2 = os.path.join(D[DIR], n)
        n3 = os.path.join(n2, UI.get_preset_name(n, n1))
        return n3

    def get_remaining_dim(self, w, h):
        """
        Used to keep the dynamically sized Per
        Cell windows from drawing off screen.

        Returns the width and height of the screen space
        to the right and bottom of the window.
        """
        w1, h1 = UI.get_screen_res()

        if self.pose in D[WIN]:
            x, y = D[WIN][self.pose]

        else:
            x = w1 / 2
            y = h1 / 2

        x = seal(x, x + SCROLL, w1 - 200)
        y = seal(y, y + SCROLL, h1 - 200)
        return min(w, w1 - x), min(h, h1 - y)

    @staticmethod
    def get_screen_res():
        """ Returns the (width, height) of the screen's dimension. """
        return gtk.gdk.screen_width(), gtk.gdk.screen_height()

    def keep(self, q):
        """
        Puts widget reference into ‟self.pigs”.

        This keeps the GTK garbage
        collection from removing connections.

        q: widgets
        """
        for g in q:
            self.pigs.append(g)

    def load_controls(self, d):
        """
        Loads the controls from a preset.

        d: preset
        """
        return self.update_controls(d)

    def on_key_press(self, _, a):
        """
        Checks to see if the user pressed the Esc key.
        If so, then close the window.

        a: key-press event
        """
        n = gtk.gdk.keyval_name(a.keyval)

        if n == 'Escape':
            return self.close()

        elif n == 'Return':
            g = self.win.get_focus()
            if type(g) in RETURN_WIDGETS:
                return self.do_return()

    def preset_is_undefined(self):
        """ Sets the preset ComboBox display to undefined. """
        if not UI.loading:
            self.preset_m.set_text(UND)

    def subtract_from_color(self):
        """ Subtracts from from the window's red and green color channels. """
        self.color -= 2200

    def update_controls(self, d):
        """
        Loads a window's controls.

        d: dict that stores control values

        Returns the dict.
        """
        UI.loading += 1

        for g in self.controls:
            g.set_val(d[g.key])

        UI.loading -= 1
        return d

    def verify_opacity_depend(self, g, cb=None):
        """
        Validates property group widgets based on the opacity value.

        g: opacity Entry
        cb: Per Cell Checkbutton
        """
        q = g.rot, g.flip_h, g.flip_v

        if not cb:
            do = 1

        else:
            do = not cb.get_val()
        if do:
            if g.get_val():
                for i in q:
                    i.enable()

            else:
                for i in q:
                    i.disable()

    def verify_place_menus(self, g):
        """
        Resize/Fill Cell and Image/None options cause
        some of the other menu options to be invalid.

        g: Placement ComboBox
        """
        if g.resz.get_val() == FIL or g.img.get_val() == NON:
            g.vert.disable()
            g.horz.disable()

        else:
            g.vert.enable()
            g.horz.enable()

        if g.img.get_val() == NON:
            g.resz.disable()

        else:
            g.resz.enable()


class UIConfig(UI):
    """
    This is a bare dialog for style and effect options widget drawing.
    """

    def __init__(self, n, a, q, d):
        """
        n: dialog title and session key
        a: calling class instance
            Used to hook prep, preview, and preview_changed functions.

        q: widget identifiers
        d: dict with widget values
        """
        D[CANCEL] = 1
        self.sess_k = n
        self.caller = a
        self.d = d
        self.wigs = q
        d = {
            ACCEPT: self.do_job,
            DRAW: self.draw,
            POSE: 'uid',
            TITLE: n + " Options"}

        UI.__init__(self, d)
        Sel.none(D[RENDER])
        pdb.gimp_displays_flush()
        gtk.main()

    def add_box(self, g):
        """
        Creates an HBox with colored background.

        g: container

        Returns: RBox.
        """
        box = REventBox(self.color)
        g1 = Splitter(padx=3)

        g.add(box)
        box.add(g1.g)
        return g1

    def cancel(self, *_):
        """ The user canceled the window. """
        self.close()

    def do_job(self, *_):
        """ Called when the user activates the Accept Button. """
        d = self.get_data()

        self.caller.prep(d)
        self.close()
        D[CANCEL] = 0

    def draw(self):
        """ Draws the windows widgets. """
        self.controls = []
        q = []
        internal = None
        g = VBox()
        k = self.sess_k

        if k == FLS:
            n1 = KLC
            self.d = EF.compliment_key_light()
            internal = [[n1, self.d]]

        else:
            n1 = USE if D[SESS][k] != Session.default[k] else DEF

        self.process_wigs(g, q)

        # preview and randomize:
        g1 = self.add_box(g)
        g2 = RButton(PREVIEW, self.preview)
        g3 = RButton("Randomize", self.randomize)

        self.keep((g2, g3))
        q.append(g1)
        g1.both(g2.g, g3.g)
        self.subtract_from_color()

        # default and presets:
        d = {NAME: k, PARENT: self.win}

        if internal:
            d[INTERNAL] = internal

        self.preset = PRSubSession(d)
        g1 = self.add_box(g)
        g2 = self.preset_m = GPreset(
            None,
            self.on_preset_change,
            k,
            self.get_data,
            self.win,
            self.preset)

        q.append(g1)
        g2.box.both(g2.save_b.g, g2.del_b.g)
        g2.box.pack()
        g1.left.add(g2.label.g)
        g1.both(g2.g, g2.box.g)
        self.subtract_from_color()
        g2.set_val(n1)
        g2.verify_del_button()

        # cancel and accept:
        g1 = self.add_box(g)
        g2 = RButton(CANCEL, self.cancel)
        g3 = RButton("Accept", self.accept)

        self.keep((g2, g3))
        q.append(g1)
        g1.both(g2.g, g3.g)
        [g4.pack() for g4 in q]
        self.win.add(g)

    def get_data(self):
        """ Returns a dict of the control values. """
        d = {}

        for g in self.controls:
            d[g.key] = g.get_val()
        return d

    def on_change(self, _):
        """ Called when a widget changes. """
        if not UI.loading:
            self.caller.preview_changed()
            self.preset_is_undefined()

    def on_preset_change(self, _, d):
        """
        Called when the user makes a selection in the preset ComboBox.

        Loads the preset.

        d: preset dict
        """
        g = self.preset_m
        if g.get_text() != UND:
            pass_version(d, Session.default[self.sess_k])
            self.update_controls(d)
            self.caller.preview_changed()

    def preview(self, g):
        """
        Draws a preview.

        g: RButton
        """
        self.win.iconify()
        g.disable()

        d = self.get_data()

        self.caller.preview(d)
        g.enable()
        pdb.gimp_displays_flush()
        self.win.present()

    def process_wigs(self, g, q):
        """
        Creates the widgets.

        g: Vbox
        q: list of widgets
        """
        sb = RSpinButton
        p = self.on_change

        for n in self.wigs:
            g1 = self.add_box(g)
            a = self.d[n]

            if n == PIXL8:
                g2 = RLabel("Choose Layout:")

            elif n == INVERT:
                g2 = RLabel(" ")

            else:
                g2 = RLabel(n + ":\t\t")

            if n == BORD_TYP:
                rb = RRadioButton(p, "Rounded", n, None)
                g3 = RRadioButton(p, "Angular", n, rb.wig)
                rr = RRadio((rb, g3), n)
                g1.right.add(rb.g)

            elif n == BORD_W:
                g3 = sb(p, (0, D[RAD]), k=n)

            elif n == BLUR:
                g3 = sb(p, (0, 1024), k=n)

            elif n in (COLOR1, COLOR2, COLOR3):
                g3 = RColorButton(p, a, n)

            elif n == CRIT:
                g3 = RComboBoxE(p, k=n, opt=CRIT_LIST)

            elif n == DETAIL:
                g3 = sb(p, (0, 15), k=n)

            elif n == HOLD:
                g3 = sb(p, (1, 8), k=n)

            elif n == GRADIENT:
                q2 = pdb.gimp_gradients_get_list(None)[1]
                g3 = RComboBoxE(p, k=n, opt=q2)

            elif n == HOLD:
                g3 = sb(p, (1, 100000), k=n)

            elif n == INHERIT:
                rb = RRadioButton(p, "Same as image", n, None)
                g3 = RRadioButton(p, "Make opaque", n, rb.wig)
                rr = RRadio((rb, g3), n)
                g1.right.add(rb.g)

            elif n == INVERT:
                g3 = RCheckButton(n, p, n)

            elif n == LIGHT:
                g3 = sb(p, (0, 359), k=n)

            elif n in LINE_K:
                b = D[WI] - 1 if n in (STARTX, ENDX) else D[HG] - 1
                g3 = sb(p, (0, b), k=n)

            elif n == METHOD:
                g3 = RComboBoxE(p, k=n, opt=GRAD_TYPE)

            elif n == MODE:
                g3 = RComboBox(p, k=n, opt=D[MODE].names())

            elif n in OFFS:
                b = (D[SIZE][OFFS.index(n)])
                b = min(b, 4096)
                g3 = sb(p, (-b, b), k=n)

            elif n == OP:
                b = 1000 if self.sess_k in SHADOW else 100
                g3 = sb(p, (0, b), k=n)

            elif n == PATTERN:
                q2 = pdb.gimp_patterns_get_list(None)[1]
                g3 = RComboBoxE(p, k=n, opt=q2)

            elif n == PIXL8:
                g3 = RCheckButton(n, p, n)

            elif n == POWER:
                g3 = sb(p, (0, 180), k=n)

            elif n == ROT:
                g3 = sb(p, (-359, 359), k=n)

            elif n in (ROW, COL):
                b = D[HG] / MIN_CELL if n == ROW else D[WI] / MIN_CELL
                g3 = sb(p, (1, b), k=n)

            elif n == SEED:
                g3 = sb(p, (1, 100000), k=n)

            elif n == THRESH:
                g3 = sb(p, (0, 1), k=n, f=1, q1=(.01, .1))

            g1.both(g2.g, g3.g)
            g3.set_val(a)

            if isinstance(g3, RRadioButton):
                g3 = rr

            self.controls.append(g3)
            q.append(g1)
            self.subtract_from_color()

    def randomize(self, _):
        """ Randomizes the variables. """
        d = self.caller.rand()

        self.update_controls(d)
        self.preset_is_undefined()

    def set_default(self, _):
        """ Sets the widgets to their default state. """
        self.update_controls(Session.default[self.sess_k])


class UISwitch(UI):
    """ Switches window focus for dialog interaction. """

    def __init__(self, d):
        g = d['parent']

        g.iconify()
        UI.__init__(self, d)
        g.present()


class UICell(UISwitch):
    """ Draws the Per Cell windows. """

    # GTK will sometimes draw scroll-bars after size changes:
    xtra = 4

    def __init__(self, d):
        """ d: dict """
        x = CG.overlay = self.win_x = d['win_x']
        self.merged = d['merge_pc']
        self.format_c = d['format_c']
        d[ACCEPT] = self.do_job
        d[DRAW] = self.draw_win
        d[POSE] = ('cell_merge',  'cell_place', 'cell_margin', 'cell_prop')[x]
        d[TITLE] = (
            MERGE_CELLS,
            IMG_PLACE,
            CELL_MARG,
            IMG_PROP)[x] + EXIT

        self.init_merge_cells(d)

        # cell window format copy:
        CG.format_c = Format(self.format_c.format)
        CG.sizer = Cell(CG.format_c.format)
        UISwitch.__init__(self, d)

    def do_job(self):
        """ Called because the user pressed the Enter key. """
        self.format_c.format = CG.format_c.format
        return self.close()

    def draw_cell(self, _, d):
        """
        Called by UICell for each cell.

        Initializes the cell's dictionary.

        Draws connectors and cell sizes.

        d: dict
        """
        e = CG.grid[d[R]][d[C]]

        CG.draw(e)
        if self.win_x:
            if e[V] != (-1, -1):
                (
                    self.draw_place_cell,
                    self.draw_margin_cell,
                    self.draw_prop_cell)[self.win_x - 1](d)

    def draw_margin_cell(self, d):
        """
        Called by UICell for each cell.

        Draws margin Labels and SpinButtons.

        d: dict
        """
        # These widgets use an index:
        if self.isnt_no_pic(d):
            e = self.format_c.format[CM_CELL][d[R]][d[C]]
            g = CG.grid[d[R]][d[C]]['box']
            for x, n in enumerate(MARGINS):
                g1 = Splitter()
                w = D[HG] - 1 if x < 2 else D[WI] - 1
                g2 = RSpinButton(
                    self.on_widget_change, (0, w), k=CELL_SB_K[x])

                g2.cell_key = CM_CELL
                g2.r, g2.c = d[R], d[C]
                g2.index = x

                self.keep((g2,))
                g1.both(RLabel(n + ":").g, g2.g)
                g2.set_val(e[x] / 1.)
                g1.pack()
                g.add(g1.g)

    def draw_place_cell(self, d):
        """
        Called by UICell for each cell.

        Draws the ComboBoxes for Image Placement.

        d: dict
        """
        if self.isnt_no_pic(d):
            p = self.on_widget_change
            g = [0] * 4

            for x in range(4):
                a = (RSZ, Images.format_img_list, HRZ, VRT)[x]
                g1 = g[x] = RComboBox(p, opt=a)
                g1.index = x
                g1.cell_key = PL_CELL
                g1.r, g1.c = d[R], d[C]

                CG.grid[d[R]][d[C]]['box'].add(g1.g)
                self.keep((g1,))

            e = self.format_c.format[PL_CELL][d[R]][d[C]]

            for x in range(4):
                g[x].resz, g[x].img, g[x].horz, g[x].vert = g[0], g[1], g[2], g[3]
                g[x].set_val(e[x])
            if g1.resz.get_val() == FIL or g1.img.get_val() == NON:
                self.verify_place_menus(g[0])

    def draw_prop_cell(self, d):
        """
        Called by UICell for each cell.

        Draws the widgets for the Property cell.

        d: dictionary
        """
        if self.isnt_no_pic(d):
            g = CG.grid[d[R]][d[C]]['box']
            p = self.on_widget_change
            q = zip(
                (
                    RCheckButton, RCheckButton, RSpinButton,
                    RSpinButton, RSpinButton),

                (
                    (FH, p), (FV, p), (p, (-359, 359)),
                    (p, (0, 100)), (p, (0, 200))),

                (FLIP_H_X, FLIP_V_X, ROTATE_X, OP_X, BB_X))

            g4 = []
            for x, q1 in enumerate(q):
                g1, c, x1 = q1

                if x < 2:
                    g2 = g1(*c)

                else:
                    lab = RLabel(("Rotate:", "Opacity:", "Blur Behind:")[x - 2]).g
                    g2 = g1(*c, lab=lab)

                g2.index = x1
                g2.r, g2.c = d[R], d[C]
                g2.cell_key = PR_CELL

                if x == 3:
                    # opacity dependents:
                    g2.flip_h, g2.flip_v, g2.rot = g4

                g4.append(g2)
                self.keep((g2,))

                if x < 2:
                    # CheckButton:
                    g.add(g2.g)

                else:
                    g3 = Splitter()
                    g3.both(lab, g2.g)
                    g3.pack()
                    g.add(g3.g)

            e = self.format_c.format[PR_CELL][d[R]][d[C]]

            for x in range(5):
                g4[x].set_val(e[x])
            if not e[OP_X]:
                self.verify_opacity_depend(g4[3])

    def draw_win(self):
        """
        Draws the background framework used by the three Per Cell windows.

        Calls the Per Cell window owner to draw
        its overlay on top of the background.
        """
        # Cell content is the top Frame:
        d = self.format_c.format
        row, col = d[ROW] * 2, d[COL] * 2
        vbox = self.win.vbox
        table = gtk.Table(row, col)
        scroll = gtk.ScrolledWindow()
        is_1st_cell = 1

        scroll.add_with_viewport(table)
        vbox.add(scroll)
        scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        self.buttons = create_2d_table(d[ROW], d[COL])
        for r in range(row):
            for c in range(col):
                r1, c1 = r / 2 + 1, c / 2 + 1
                r2, c2 = r / 2 - 1, c / 2 - 1

                if r == 0:
                    if not self.win_x or (self.win_x and c % 2):
                        # column header:
                        g = REventBox(BG_HEAD)
                        g1 = gtk.Frame()

                        if c % 2:
                            g2 = col_label = RLabel(str(c1), align=ALL_X).g
                            g1.add(g2)

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif c == 0:
                    if not self.win_x or (self.win_x and r % 2):
                        # row header:
                        g = REventBox(BG_HEAD)
                        g1 = gtk.Frame()

                        if r % 2:
                            g2 = row_label = RLabel(
                                str(r1), pad=(0, 0, 4, 4), align=ALL_Y).g
                            g1.add(g2)

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif r % 2 and c % 2:
                    # Create cell:
                    r3, c3 = d[R], d[C] = r / 2, c / 2
                    e = CG.grid[r3][c3]

                    # Add buttons to the cell's dictionary:
                    if r > 1:
                        e['top_b'] = self.buttons[r2][c3]

                    if c > 1:
                        e['left_b'] = self.buttons[r3][c2]

                    g = RBox(0, align=(0, 0, 1, 1))
                    e[PAD] = g.g
                    g1 = e['event_box'] = REventBox(None)
                    g2 = RBox(0, pad=PAD5)
                    g3 = CG.grid[r3][c3]['box'] = g2.box

                    g.add(g1)
                    g1.add(g2.g)
                    table.attach(g.g, c, c + 1, r, r + 1)
                    self.draw_cell(g3, d)

                    if is_1st_cell:
                        """
                        ‟show_all” causes the ‟vbox” allocation to be
                        calculated which will fail ScrolledWindow's dependency.
                        So calculate scroll region-size manually.
                        """
                        self.win.show_all()

                        is_1st_cell = 0
                        w = max(g3.allocation.width, g3.allocation.height)
                        w1, h = w * d[COL], w * d[ROW]
                        w2 = row_label.allocation.width
                        h1 = col_label.allocation.height
                        button_w = 0 if self.win_x else 15 * (d[COL] - 1)
                        button_h = 0 if self.win_x else 15 * (d[ROW] - 1)
                        pad_w = 20 * d[COL]
                        pad_h = 20 * d[ROW]
                        xtra_w, xtra_h = row, col
                        UICell.xtra += 15 if self.win_x == 3 else 0

                        # totaling:
                        w1 += w2 + pad_w + button_w + xtra_w + SCROLL + UICell.xtra
                        h += h1 + pad_h + button_h + xtra_h + SCROLL + UICell.xtra
                        w1, h = self.get_remaining_dim(w1, h)
                        self.win.vbox.set_size_request(w1, h)
                    g3.set_size_request(w, w)

                elif not (not r % 2 and not c % 2):
                    if not self.win_x:
                        # connector button:
                        if r % 2:
                            # left button:
                            p = CG.split_horz, CG.connect_left
                            r3, c3 = r, c + 1
                            r4, c4 = r / 2, c / 2 - 1
                            q = (5, 5, 0, 0)

                        else:
                            # upper button:
                            p = CG.split_vert, CG.connect_up
                            r3, c3 = r + 1, c
                            r4, c4 = r / 2 - 1, c / 2
                            q = (0, 0, 5, 5)

                        g = RBox(1, align=(0, 0, 1, 1), pad=q)
                        g1 = self.buttons[r4][c4] = SwitchButton(
                            "+", p, r3, c3, g)

                        g1.set_size(15, 15)
                        g1.set_color(BG_BUTTON)
                        g.add(g1)
                        table.attach(g.g, c, c + 1, r, r + 1)

                else:
                    if not self.win_x:
                        # nothing reactive:
                        g = REventBox(BG_BUTTON)
                        g1 = HBox()
                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

    def init_merge_cells(self, _):
        """ Sets the first phase of the initial data needed to draw cells. """
        d = self.format_c.format
        row, col = d[ROW], d[COL]
        CG.grid = create_2d_table(row, col)

        # Load cell dimensions:
        for r in range(row):
            for c in range(col):
                if self.merged:
                    s = d[ME_CELL][r][c]

                else:
                    s = 1, 1
                CG.grid[r][c] = dict(v=s, r=r, c=c)

        # Initialize top-left references:
        for r in range(row):
            for c in range(col):
                e = CG.grid[r][c]
                if CG.is_topleft(e):
                    t = e

                    # Initialize sub-topleft cells:
                    for r1 in range(r, r + t[V][0]):
                        for c1 in range(c, c + t[V][1]):
                            if r1 != r or c1 != c:
                                e = CG.grid[r1][c1]
                                e['topleft'] = t[R], t[C]

    def isnt_no_pic(self, d):
        """
        Returns a flag which is true when the image placement is not an image.

        d: dict
        """
        e = CG.format_c.format
        m = 1

        if self.win_x != PL_X:
            if not e[PL_CELL]:
                m = e[IMAGE] != NON

            else:
                m = e[PL_CELL][d[R]][d[C]][IMAGE_X] != NON

        # zero opacity:
        if m:
            if self.win_x != PR_X:
                if not e[PR_CELL]:
                    m = e[OP] != 0

                else:
                    m = e[PR_CELL][d[R]][d[C]][OP_X] != 0

        if not m:
            n = NP + "............" if not d[R] and not d[C] else NP
            CG.grid[d[R]][d[C]]['box'].add(RLabel(n).g)
        return m

    def on_widget_change(self, g):
        """
        Called when a widget changed display value.

        g: widget
        """
        if not self.loading:
            x = g.index
            k = g.cell_key
            q = list(CG.format_c.format[k][g.r][g.c])
            q[x] = g.get_val()
            CG.format_c.format[k][g.r][g.c] = tuple(q)

            if k == PL_CELL:
                if x in (RESIZE_X, IMAGE_X):
                    self.verify_place_menus(g)

            elif k == PR_CELL:
                if x == OP_X:
                    self.verify_opacity_depend(g)


class UISave(UISwitch):
    """ This window gets a preset name then saves the preset. """
    preset_name = "New Preset"

    def __init__(self, d):
        """ d: dict """
        self.get_data = d['get_data']
        a = self.preset = d['preset']
        d[ACCEPT] = self.save
        d[TITLE] = "Name the " + a.name + " Preset"
        d[DRAW] = self.draw_win
        d[POSE] = 'save_' + a.name
        self.filename_label = self.save_b = None
        UISwitch.__init__(self, d)

    def draw_file_info_grp(self, g):
        """
        The file info group shows the user the preset file's location.

        g: container
        """
        self.subtract_from_color()
        n = os.path.dirname(self.get_preset_path(self.preset.name, ""))
        drive, path = os.path.splitdrive(n)

        g1 = Splitter(padx=3)
        g2 = REventBox(self.color)
        g3 = VBox()

        self.subtract_from_color()

        g4 = REventBox(self.color)
        g5 = self.file_name_box = VBox()
        g6 = self.filename_label = RLabel("")

        g2.add(g3)
        g4.add(g5)
        g1.both(g2, g4)
        g3.add(RLabel("Drive:").g)
        g3.add(RLabel("Folder:").g)
        g3.add(RLabel("File Name:").g)
        g5.add(RLabel(drive).g)
        g5.add(RLabel(path).g)
        g5.add(g6.g)
        g1.no_pack()
        g.add(g1.g)
        self.draw_file_name(self.file_name_e)

    def draw_file_name(self, g):
        """
        Called whenever the preset name Entry changes.

        Updates the File Location group with the latest file name.

        g: file name Entry
        """
        if self.filename_label:
            n = UI.get_preset_name(
                self.preset.name,
                g.get_val())
            self.filename_label.lab.set_text(n)
            if self.save_b:
                if g.get_val().lower() in (DEF.lower(), KLC.lower()):
                    self.save_b.disable()

                else:
                    self.save_b.enable()

    def draw_process_grp(self, g):
        """
        Draws the Cancel and Save Buttons for the window.

        g: container
        """
        g1 = Splitter(padx=3)
        g2 = self.save_b = RButton("Save", self.save)
        g3 = self.cancel_b = RButton("Cancel", self.close)

        g1.both(g3.g, g2.g)
        g1.pack()
        g.add(g1.g)

    def draw_var_grp(self, g):
        """
        Creates an Entry for naming the preset.

        g: container
        """
        g1 = self.file_name_e = REntry(self.draw_file_name, None, padx=2)

        g.add(RLabel("Preset Name:", TOPL).g)
        g.add(g1.g)
        g1.set_val(UISave.preset_name)
        g1.wig.select_region(0, -1)

    def draw_win(self):
        """ Draws the window's controls. """
        g = self.win.vbox
        q = (
            self.draw_var_grp,
            self.draw_file_info_grp,
            self.draw_process_grp)

        c = "Variables", "File Location", PE

        for x, p in enumerate(q):
            box = REventBox(self.color)
            g1 = VBox()

            box.add(g1)
            g.add(box)
            g1.add(RLabel(c[x] + ":", (2, 0, 4, 0)).g)
            p(g1)
            self.subtract_from_color()

    def save(self, *_):
        """
        Called because the user activated the Save Button.

        Attempts to write the preset and if successful
        updates the preset menu and closes the window.
        """
        d = deepcopy(self.get_data())
        n = d[PRESET] = self.file_name_e.get_val()
        if self.write(d):
            UISave.preset_name = n
            self.reply = 1
            return self.close()

    def write(self, d):
        """
        Writes the preset, after checking if it already
        exists and asking permission to over-write.

        d: dict that gets saved

        Returns a result flag where true is successful.
        """
        path = UI.get_preset_path(self.preset.name, self.file_name_e.get_val())
        m = 1

        if os.path.isfile(path):
            n = DUPE.format(path)
            g = gtk.MessageDialog(
                parent=self.win,
                flags=gtk.DIALOG_MODAL,
                type=gtk.MESSAGE_QUESTION,
                buttons=gtk.BUTTONS_YES_NO,
                message_format=n)

            g.set_title("Duplicate File")

            a = g.run()

            g.destroy()
            m = int(a == gtk.RESPONSE_YES)

        if m:
            m = pickle_dump(dict(data=d, file=path))
        return m


class UIFormat(UISwitch):
    """
    This is a window with format controls and accesses UICell windows.
    """
    MARG_Y = 30

    def __init__(self, d):
        """ d: dict """
        x = self.format_x = d['format_x']
        self.format = deepcopy(D[SESS][FORMAT][x])
        d[ACCEPT] = self.do_job
        d[TITLE] = "Format"
        d[DRAW] = self.draw_win
        d[POSE] = 'format'
        self.feed = d['feed']
        UISwitch.__init__(self, d)

    def adjust_cell_tables(self):
        """
        Cell tables expand or contract depending on the rows and columns.
        """
        self.expand_cell_tables()
        self.contract_cell_tables()

    def contract_cell_tables(self):
        """
        Contracts Per Cell tables to correspond with the Format window.

        Checks Merge Cells table for group dimension overflow.
        """
        row = self.format[ROW]
        col = self.format[COL]

        for k in CELL_K:
            if self.format[k]:
                r = len(self.format[k])

                if r > row:
                    # Remove rows:
                    for _ in range(r - row):
                        self.format[k].pop()
                for r in range(len(self.format[k])):
                    c = len(self.format[k][r])
                    if c > col:
                        # Remove columns:
                        for _ in range(c - col):
                            self.format[k][r].pop()
        self.fix_merge_cells()

    def correct_merge_overflow(self, s, row, col, r, c):
        """
        Checks if the Merge Cells' table has contracted. If so then
        the top-left cells need their dimensions checked for overflow.

        row, col: max location.
        r, c: current location
        s: group dimension
        """
        if s[0] + r > row:
            s = row - r, s[1]

        if s[1] + c > col:
            s = s[0], col - c
        return s

    def correct_contracted_cells(self):
        """
        When cells contract, their dimensions change.
        This makes the cut-off cells independent.
        """
        if self.format[MERG_PER]:
            r = self.format[ROW]
            r1 = len(self.format[ME_CELL])
            c = self.format[COL]
            for r2 in range(r1):
                for c1 in range(len(self.format[ME_CELL][r2])):
                    if r2 >= r or c1 >= c:
                        self.format[ME_CELL][r2][c1] = 1, 1

    def do_no(self, *_):
        """ Called when the user cancels the Format window. """
        self.feed(None)
        return self.close()

    def do_job(self, *_):
        """ Called when the user accepts the UIFormat window. """
        d = D[SESS]

        for g in self.controls:
            self.format[g.key] = g.get_val()

        self.adjust_cell_tables()

        d[FORMAT][self.format_x] = self.format

        self.feed(self.format_x)
        return self.close()

    def draw_cell_margin_grp(self, g):
        """
        Draws the Cell Margins group.

        g: container
        """
        g1 = self.cell_margin_sb = list(self.draw_marg_grp(g, CELL_SB_K))
        g = self.margin_pc_grp = GPerCell(
            self.on_widget_change,
            self.open_cell_win,
            "Cell Margins...",
            CM_PER,
            g,
            2)

        g.wig.connect(CLK, self.set_margin_depend)
        self.keep((g1,))

    def draw_grid_grp(self, g):
        """
        Draws the grid group.

        g: container
        """
        a = 1, 100
        p = self.on_widget_change
        g1 = Splitter(padx=2)
        g2 = RLabel("Row:").g
        g3 = self.row_sb = RSpinButton(p, a, k=ROW)
        g4 = RLabel("Column:").g
        g5 = self.col_sb = RSpinButton(p, a, k=COL)

        self.keep((g3, g5))
        g1.both(g2, g4)
        g1.both(g3.g, g5.g)
        g1.pack()
        g.add(g1.g)
        self.merge_pc_grp = GPerCell(
            p,
            self.open_cell_win,
            "Merge Cells...",
            MERG_PER,
            g,
            0)

    def draw_layer_grp(self, g):
        """
        Draws a format layer group.

        g: container
        """
        p = self.on_widget_change
        g1 = self.format_name_e = REntry(p, NAME, padx=1)
        g2 = self.effect_m = RComboBox(
            p, k=EFFECT, opt=[NON] + D[EFFECTS].names, padx=2)

        self.keep((g1, g2))
        g.add(RLabel("Format Name:", TOPL).g)
        g.add(g1.g)
        g.add(RLabel("3D Effect:", TOPL).g)
        g.add(g2.g)

    def draw_layer_marg_grp(self, g):
        """
        Draws the layer margins.

        g: container
        """
        self.layer_margin_sb = list(self.draw_marg_grp(g, LAY_SB_K))

    def draw_marg_grp(self, g, k):
        """
        Draws the margin SpinButtons.

        g: container
        k: group key

        Returns the top, bottom, left, right SpinButton widgets.
        """
        a = 0, 100000
        p = self.on_widget_change
        g1 = [0] * 5

        for x in range(5):
            b = 2 if x == 0 else 0
            g1[x] = Splitter(padx=b)

        g2 = RLabel("Top:").g
        g3 = RSpinButton(p, a, k=k[TOP_X], lab=g2)
        g4 = RLabel("Bottom: ").g
        g5 = RSpinButton(p, a, k=k[BOT_X], lab=g4)
        g6 = RLabel("Left:").g
        g7 = RSpinButton(p, a, k=k[LEF_X], lab=g6)
        g8 = RLabel("Right:").g
        g9 = RSpinButton(p, a, k=k[RIG_X], lab=g8)

        for g10 in reversed(g1):
            g10.pack()

        self.keep((g3, g5, g7, g9))
        g1[0].both(g1[1].g, g1[2].g)
        g1[0].both(g1[3].g, g1[4].g)
        g1[1].both(g2, g3.g)
        g1[2].both(g6, g7.g)
        g1[3].both(g4, g5.g)
        g1[4].both(g8, g9.g)
        g.add(g1[0].g)
        return g3, g5, g7, g9

    def draw_place_grp(self, g):
        """
        Draws the Placement ComboBoxes.

        g: container
        """
        q = MARGIN / 4, 0, 0, 0
        p = self.on_widget_change
        g1 = Splitter(padx=2)
        g2 = [0] * 4
        g2[0] = self.resize_m = RComboBox(p, k=RESIZE, opt=RSZ)
        g2[1] = self.image_m = RComboBox(p, k=IMAGE, opt=Images.format_img_list[:])
        g2[2] = self.horz_m = RComboBox(p, k=HORZ, opt=HRZ)
        g2[3] = self.vert_m = RComboBox(p, k=VERT, opt=VRT)

        # Connect dependents:
        for x in range(4):
            g2[x].resz, g2[x].img, g2[x].horz, g2[x].vert = \
                g2[0], g2[1], g2[2], g2[3]

        self.keep(g2)
        g1.both(RLabel("Resize:", q).g, RLabel("Image:", q).g)
        g1.both(g2[0].g, g2[1].g)
        g1.both(RLabel("Horizontal:", q).g, RLabel("Vertical:", q).g)
        g1.both(g2[2].g, g2[3].g)
        g1.pack()
        g.add(g1.g)

        g = self.place_pc_grp = GPerCell(
            p,
            self.open_cell_win,
            "Placement...",
            PLACE_PER,
            g,
            1)
        g.wig.connect(CLK, self.set_place_depend)

    def draw_preset_grp(self, g):
        """
        Draws the Preset ComboBox and Buttons.

        g: container
        """
        self.preset_m = GPreset(
            g,
            self.on_preset_change,
            FORMAT,
            self.return_format,
            self.win,
            self.preset)

    def draw_process_grp(self, g):
        """
        Draws the Show Preview, Cancel, and Accept Buttons.

        g: container
        """
        # Save a self reference to buttons as GTK
        # will remove the event connections otherwise:
        g1 = RButton("Accept", self.do_job, padx=3)
        g2 = RButton("Show Preview", self.show_preview, padx=2)
        g3 = RButton("Cancel", self.do_no, padx=1)

        self.keep((g1, g2, g3))
        g.add(g3.g)
        g.add(g2.g)
        g.add(g1.g)

    def draw_prop_grp(self, g):
        """
        Draws the property group.

        g: container
        """
        w = MARGIN
        p = self.on_widget_change
        g1 = [0] * 3

        for x in range(3):
            a = 2 if x == 0 else 0
            g1[x] = Splitter(padx=a)

        lab = RLabel("Blur Behind:  ").g
        lab1 = RLabel("Rotate:").g
        lab2 = RLabel("Opacity:").g
        g2 = self.flip_h_cb = RCheckButton(FH, p, FLIP_H)
        g3 = self.flip_v_cb = RCheckButton(FV, p, FLIP_V)
        g4 = self.rotate_sb = RSpinButton(p, (-359, 359), k=ROT, lab=lab1)
        g5 = self.opacity_sb = RSpinButton(p, (0, 100), k=OP, lab=lab2)
        g6 = RBox(1, pad=(0, 0, w, w))
        g7 = self.blur_sb = RSpinButton(p, (0, 200), k=BB, lab=lab)
        g5.flip_h, g5.flip_v, g5.rot = g2, g3, g4

        self.keep((g2, g3, g4, g5, g7))
        g1[0].left.add(g2.g)
        g1[0].left.add(g3.g)
        g6.add(lab)
        g6.add(g7.g)
        g1[1].both(lab1, g4.g)
        g1[2].both(lab2, g5.g)

        for g8 in reversed(g1):
            g8.pack()

        g.add(g1[0].g)
        g.add(g6.g)

        for x in range(1, 3):
            g1[0].right.add(g1[x].g)

        g = self.prop_pc_grp = GPerCell(
            p,
            self.open_cell_win,
            "Property...",
            PROP_PER,
            g,
            3)
        g.wig.connect(CLK, self.set_prop_depend)

    def draw_win(self):
        """ Draws the window's widgets. """
        self.preset = PRFormat({PARENT: self.win})
        g = self.win.vbox
        q = (
            self.draw_layer_grp,
            self.draw_grid_grp,
            self.draw_place_grp,
            self.draw_prop_grp,
            self.draw_layer_marg_grp,
            self.draw_cell_margin_grp,
            self.draw_preset_grp,
            self.draw_process_grp)

        c = (
            "Format Layer",
            "Layer Cell Grid",
            IMG_PLACE,
            "Image Property",
            LAY_MARG,
            CELL_MARG,
            "Format Options",
            PE)

        for i, p in enumerate(q):
            if not i % 2:
                same_size = gtk.SizeGroup(mode=BOTH)

            box = REventBox(self.color)
            g1 = VBox()

            g1.add(RLabel(c[i] + ":", (2, 0, 4, 0)).g)
            box.add(g1)
            p(g1)
            same_size.add_widget(box)
            self.subtract_from_color()

            # Keep the widgets in memory:
            wig = same_size.get_widgets()

            if i % 2:
                # Add row of same size widgets:
                g2 = HBox()

                [g2.add(g3) for g3 in reversed(wig)]
                g.add(g2)

        self.pc_group = (
                self.merge_pc_grp,
                self.place_pc_grp,
                self.margin_pc_grp,
                self.prop_pc_grp)

        q = self.controls = [
            self.format_name_e,
            self.effect_m,
            self.resize_m,
            self.horz_m,
            self.vert_m,
            self.image_m,
            self.rotate_sb,
            self.opacity_sb,
            self.flip_h_cb,
            self.flip_v_cb,
            self.blur_sb,
            self.prop_pc_grp,
            self.place_pc_grp,
            self.merge_pc_grp,
            self.margin_pc_grp,
            self.row_sb,
            self.col_sb,
            self.preset_m]

        q += [g for g in self.layer_margin_sb]
        q += [g for g in self.cell_margin_sb]

        self.update_controls(self.format)
        self.verify_opacity_depend(self.opacity_sb, self.prop_pc_grp)
        self.verify_per_cell_buttons()

    def expand_cell_table(self, p):
        """
        Expands a cell table based on the row and column counts.

        During an expansion, values are inserted into
        a table from the Format window settings.
        These settings are placed in a ‟cell” variable.

        Each Per Cell group has its own cell type.

        p: a process that returns a cell value
            and the cell table index for the format
        """
        d = self.format
        cell, x = p()
        row, col = d[ROW], d[COL]

        if not d[x]:
            d[x] = create_2d_table(row, col, a=cell)

        else:
            r = len(d[x])

            if r < row:
                e = []

                for _ in range(col):
                    e.append(cell)
                for r1 in range(row - r):
                    # Add a row with a new list:
                    d[x].append(deepcopy(e))
            for r1 in range(row):
                c = len(d[x][r1])
                if c < col:
                    for _ in range(col - c):
                        # Add a column:
                        d[x][r1].append(cell)

    def expand_cell_tables(self):
        """
        The Per Cell tables need updating because the number
        of rows and/or columns may have increased value.
        """
        for x, p in enumerate([
                self.init_merge_table,
                self.init_place_table,
                self.init_margin_table,
                self.init_prop_table]):
            if self.pc_group[x].get_val():
                self.expand_cell_table(p)

    def fix_merge_cells(self):
        """
        Correct overflow references by reducing
        merged group dimensions in top-left cells.
        """
        d = self.format
        row = d[ROW]
        col = d[COL]

        if d[MERG_PER]:
            for r in range(row):
                for c in range(col):
                    if r < len(d[ME_CELL]):
                        if c < len(d[ME_CELL][r]):
                            d[ME_CELL][r][c] = self.correct_merge_overflow(
                                d[ME_CELL][r][c], row, col, r, c)
        self.correct_contracted_cells()

    def init_margin_table(self):
        """
        This routine is called by ‟expand_cell_table”.

        Returns the image margins cell table init value and the cell table key.
        """
        q = []

        for k in CELL_SB_K:
            q.append(self.format[k])
        return tuple(q), CM_CELL

    def init_merge_table(self):
        """
        This routine is called by ‟expand_cell_table”.

        Returns the merge cell table init value and the cell table key.
        """
        return (1, 1), ME_CELL

    def init_place_table(self):
        """
        This routine is called by ‟expand_cell_table”.

        Returns the image placement cell table
        init value and the cell table key.
        """
        d = self.format
        return (
            d[RESIZE],
            d[IMAGE],
            d[HORZ],
            d[VERT]), PL_CELL

    def init_prop_table(self):
        """
        This routine is called by ‟expand_cell_table”.

        Returns the property table init value and the cell table key.
        """
        q = []

        for k in PROP_K:
            q.append(self.format[k])
        return tuple(q), PR_CELL

    def on_preset_change(self, _, d):
        """
        Called when the user makes a selection in the preset ComboBox.

        Loads the preset.

        d: preset dict
        """
        n = self.preset_m.get_text()
        if n != UND:
            pass_version(d, Format.default, is_format=1)
            self.format = self.load_controls(d)
            self.verify_per_cell_buttons()

    def on_widget_change(self, g):
        """
        A widget changed.

        g: widget
        """
        if not UI.loading:
            self.format[g.key] = g.get_val()

            if g.key in PLACE_K:
                self.verify_place_menus(g)

            elif g.key in PER_CELL_K or g.key == MERG_PER:
                # Reset cell data:
                self.format[g.cell_key] = None
                self.verify_per_cell_buttons()

            elif g.key == OP:
                self.verify_opacity_depend(g)
            self.preset_is_undefined()

    def open_cell_win(self, x):
        """
        Opens a Per Cell window.

        x: window index used by UICell
        """
        # Update layout calculations:
        self.adjust_cell_tables()

        a = Format(self.format)

        UICell(
            dict(
                format_c=a,
                merge_pc=self.merge_pc_grp.get_val(),
                win_x=x,
                parent=self.win)).reply
        if a.format != self.format:
            self.format = deepcopy(a.format)

    def return_format(self):
        """ Used by GPreset when saving presets. """
        return self.format

    def set_margin_depend(self, *_):
        """ Sets margin dependents. """
        m = self.margin_pc_grp.get_val()
        for g in self.cell_margin_sb:
            g.disable() if m else g.enable()

    def set_place_depend(self, *_):
        """ Sets placement dependents. """
        m = self.place_pc_grp.get_val()

        if m:
            for g in (self.resize_m, self.horz_m, self.vert_m, self.image_m):
                g.disable()

        else:
            self.image_m.enable()
            self.verify_place_menus(self.resize_m)

    def set_prop_depend(self, *_):
        """ Sets image dependents. """
        m = self.prop_pc_grp.get_val()

        if m:
            for g in (
                    self.rotate_sb, self.opacity_sb,
                    self.flip_h_cb, self.flip_v_cb, self.blur_sb):
                g.disable()

        else:
            self.blur_sb.enable()
            self.opacity_sb.enable()
            self.verify_opacity_depend(self.opacity_sb)

    def show_preview(self, *_):
        """ Called when the user activated the Show Preview Button. """
        self.adjust_cell_tables()

        # Update D:
        q = D[SESS][FORMAT]
        d = deepcopy(q[self.format_x])
        q[self.format_x] = self.format

        D[PREVIEW].show()

        # Restore D:
        q[self.format_x] = d

    def verify_per_cell_buttons(self):
        """ Validates Per Cell dependency. """
        for p in (
                self.set_place_depend,
                self.set_margin_depend,
                self.set_prop_depend):
            p()


class UIMain(UI):
    """ This is the script's main window. """

    is_done = 0

    def __init__(self):
        """ This is where the main gtk event loop takes place. """
        D[CANCEL] = 1
        if self.verify_ext_dir():
            self.load_last_session()
            Images.get_img()

            D[EFFECTS] = EFS()
            D[PREVIEW] = Preview()
            D[MODE] = Mode()
            d = {
                ACCEPT: self.do_job,
                DRAW: self.draw_win,
                POSE: 'main',
                TITLE: program_title}

            UI.__init__(self, d)
            gtk.main()

    def create_format(self, _):
        """ Creates a new format. """
        d = deepcopy(Format.default)
        d[NAME] = self.format_list.get_sel_text()

        D[SESS][FORMAT].append(d)
        self.edit_format()

    def do_job(self, *_):
        """ Called when the user activates the Render Button. """
        D[CANCEL] = 0
        UIMain.is_done = 1

        self.set_global_scales()

        for g in self.controls:
            if g.key != FORMAT:
                D[SESS][g.key] = g.get_val()

        self.close()
        self.render()

        D[SESS][WIN] = deepcopy(D[WIN])
        if D[SESS] != self.last_session and not D[CANCEL]:
            D[SESS][PRESET] = USE
            pickle_dump(dict(data=D[SESS], file=self.last_used_file))

    def draw_backdrop_grp(self, g):
        """
        Draws the format group.

        g: container
        """
        # Backdrop Style:
        p = self.on_widget_change
        q = self.backdrop_images = Images.format_img_list[:]

        q.pop(q.index(NXT))

        a = D[STYLES] = BDS()
        q1 = self.styles = a.names
        g1 = self.bd_style_m = RComboBox(p, k=BD_STYLE, opt=q1, padx=1)
        g2 = self.bd_image_m = RComboBox(p, k=BD_IMG, opt=q, padx=2)

        g.add(RLabel("Backdrop Style:", TOPL).g)
        g.add(g1.g)
        g.add(RLabel("Backdrop Image", TOPL).g)
        g.add(g2.g)

    def draw_format_grp(self, g):
        """
        Draws the format group.

        g: container
        """
        self.format_list = FormatList(
            g,
            self.create_format,
            self.edit_format,
            self.on_format_list_change)

    def draw_preset_grp(self, g):
        """
        Draws the preset group.

        g: container
        d: dict
        """
        self.preset_m = GPreset(
            g,
            self.on_preset_change,
            SESS,
            self.return_session,
            self.win,
            self.preset)

    def draw_preview_grp(self, g):
        """
        Draws the preview group.

        g: container
        d: dict
        """
        g1 = self.show_b = RButton("Show Preview", self.show_preview, padx=1)
        g2 = self.preview_m = PlusMenu(
            self.on_widget_change,
            PREVIEW_OPT,
            deepcopy(Session.default[PREVIEW_OPT]))

        g.add(g1.g)
        g.add(RLabel("Preview Options:", TOPL).g)
        g.add(g2.g)

    def draw_process_grp(self, g):
        """
        Draws the process group.

        g: container
        d: dict
        """
        p = self.on_widget_change
        g1 = self.cancel_b = RButton(CANCEL, self.close, padx=1)
        g2 = self.render_b = RButton(RENDER, self.accept, padx=2)
        g3 = Splitter(padx=3)
        g4 = RRadioButton(p, "Manual", AUTO, None)
        g5 = RRadioButton(p, "Auto: Last Used", AUTO, g4.wig)
        g6 = RRadioButton(p, "Auto: Randomized", AUTO, g4.wig)
        self.auto_r = RRadio((g4, g5, g6), AUTO)

        g3.both(g4.g, g5.g)
        g3.left.add(g6.g)
        g3.pack()
        g.add(g1.g)
        g.add(g2.g)
        g.add(g3.g)

    def draw_res_grp(self, g):
        """
        Draws the resolution group.

        g: container
        d: dict
        """
        q = MIN_CELL, 100000
        w = MARGIN
        p = self.on_widget_change
        g1 = self.width_sb = RSpinButton(p, q, q1=(10, 100), k=WI, padx=1)
        g2 = self.height_sb = RSpinButton(p, q, q1=(10, 100), k=HG, padx=2)

        g.add(RLabel("Width:", (0, 0, w, 0)).g)
        g.add(g1.g)
        g.add(RLabel("Height:", (w / 2, 0, w, 0)).g)
        g.add(g2.g)

    def draw_win(self):
        """ Draws the window's widgets. """
        self.preset = PRSession(dict(parent=self.win))
        g = VBox()
        q = (
            self.draw_format_grp,
            self.draw_preset_grp,
            self.draw_backdrop_grp,
            self.draw_preview_grp,
            self.draw_res_grp,
            self.draw_process_grp)

        q1 = "Format", "Preset", "Backdrop", "Preview", "Resolution", "Process"

        for i, p in enumerate(q):
            if not i % 2:
                same_size = gtk.SizeGroup(mode=BOTH)

            box = REventBox(self.color)
            g1 = VBox()

            g1.add(RLabel(q1[i] + ":", (2, 0, 4, 0)).g)
            box.add(g1)
            p(g1)
            same_size.add_widget(box)
            self.subtract_from_color()

            # For some reason I have to get widgets in order to keep them:
            wig = same_size.get_widgets()
            if i % 2:
                # Add row of same size widgets:
                g2 = HBox()

                [g2.add(g3) for g3 in reversed(wig)]
                g.add(g2)

        self.win.add(g)
        self.controls = (
            self.format_list,
            self.preview_m,
            self.bd_style_m,
            self.bd_image_m,
            self.preset_m,
            self.width_sb,
            self.height_sb,
            self.auto_r)

        self.update_controls(D[SESS])
        self.verify_bd_img_m()
        Grid.pixl8 = 1 if self.uses_pixl8(
            self.bd_style_m.get_val()) else 0

    def edit_format(self):
        """
        Switches to the format editor window for the selected format.

        a: unused
        """
        self.format_x = self.format_list.items[self.format_list.get_sel_x()][1]

        self.set_global_scales()
        UIFormat(dict(
            feed=self.get_uiformat,
            format_x=self.format_x,
            parent=self.win))

    def get_uiformat(self, x):
        """
        Called when the user accepted the format window.

        x:  format index
        """
        if x is not None:
            n = D[SESS][FORMAT][x][NAME]
            self.format_list.rename(x, n)

        self.format_list.select_item(self.format_x)
        self.preset_is_undefined()

    def img_needed(self, n):
        """
        Some backdrop styles don't require an image.

        n: backdrop style name
        """
        return n != TR

    def load_last_session(self):
        """ Loads the last Session file or the default settings. """
        n = self.last_used_file = UI.get_preset_path(SESS, USE)
        d = Session.load(dict(file=n, show=0))

        if d > 0:
            D[SESS] = deepcopy(d)
            b = self.last_session = deepcopy(d)
            b[PRESET] = D[USE] = D[SESS][PRESET] = USE
            D[WIN] = merge_dict(D[WIN], D[SESS][WIN])

        else:
            self.last_session = None
            D[SESS] = deepcopy(Session.default)
            D[SESS][PREVIEW_OPT] = {}

    def on_format_list_change(self, *_):
        """ Called when the format list changes. """
        if not UI.loading:
            # Re-order the list:
            q = self.format_list.get_val()
            q1 = []

            for q2 in q:
                # new format list order:
                q1.append(D[SESS][FORMAT][q2[1]])

            D[SESS][FORMAT] = q1

            self.format_list.set_indices()
            self.preset_is_undefined()

    def on_preset_change(self, _, d):
        """
        Called because the preset menu changed display value.

        d: preset dict
        """
        if self.preset_m.get_text() != UND:
            e = deepcopy(Session.default)
            e[WIN] = {}
            pass_version(d, e)

            for e in d[FORMAT]:
                pass_version(e, Format.default, is_format=1)

            D[SESS] = self.load_controls(d)
            D[WIN] = merge_dict(D[WIN], D[SESS][WIN])
            self.verify_bd_img_m()

    def on_widget_change(self, g):
        """
        A widget changed.

        g: widget
        """
        if not UI.loading:
            if isinstance(g, RRadioButton):
                g = self.auto_r

            D[SESS][g.key] = g.get_val()

            self.preset_is_undefined()
            if g.key == BD_STYLE:
                self.verify_bd_img_m()
                Grid.pixl8 = 1 if self.uses_pixl8(g.get_val()) else 0

    def render(self):
        """ Renders the form. """
        a = Preview
        m = 0
        s = D[SIZE]
        D[AUTO] = D[SESS][AUTO]
        D[RAD] = int(math.sqrt(s[0]**2 + s[1]**2) / 2)

        if a.has_background:
            j = D[RENDER]

            Lay.bury(j, L[PREVIEW_BG])

            if a.has_formats:
                pdb.gimp_item_set_visible(L[PREVIEW], 0)

            # The preview is invalid if size changed:
            if s != (j.width, j.height):
                m = 1
                pdb.gimp_image_scale_full(
                    j, D[WI], D[HG], LINEAR)

            z = L[BD] = Lay.new(j, BD)
            Lay.place(j, z, a=1)

        else:
            j = Layout.new_render()
            L[BD] = Lay.add(j, BD)
            D[DISPLAY] = pdb.gimp_display_new(j)

        self.render_backdrop()

        if not D[CANCEL]:
            self.render_format()

        if not D[CANCEL]:
            Sel.none(j)
            Lay.activate(j, L[BD])

            # Backdrop styles can change the layout type:
            if Grid.pixl8 != a.pixl8 and a.has_formats:
                m = 1
            if m:
                Lay.bury(j, L[PREVIEW])

    def render_backdrop(self):
        """
        Creates the backdrop layer.

        Returns a style name.
        """
        d = D[SESS]
        j, z = D[RENDER], L[BD]
        style = d[BD_STYLE]
        e = D[SESS][style] if style in D[SESS] else {}

        if self.img_needed(style):
            # Copy the backdrop image to the backdrop layer:
            n = d[BD_IMG]

            if n == NON:
                # Fill with white:
                Lay.color_fill(z, WH)

            else:
                j1 = Img.get_image(n)
                j2 = j1.j

                Sel.none(j2)
                kopy(j2)

                if j1.size != D[SIZE]:
                    # Resize backdrop image to fit backdrop layer:
                    j2 = Img.paste()
                    Img.shape(j2, D[WI], D[HG])

                z1 = Lay.paste(j, z)
                z = L[BD] = Lay.merge(j, z1)

        z.name = style

        z.add_mask(Lay.mask(z))
        D[STYLES].obj[self.styles.index(style)](e)

        if L[BD].mask:
            L[BD].remove_mask(fu.MASK_APPLY)
        if D[CANCEL]:
            L[BD].name = "Canceled " + style

    def render_effect(self, d):
        """
        Creates a 3D effect for the images.

        d: format dict
        """
        D[FORMAT] = d
        D[NAME] = effect = d[EFFECT]

        if effect != NON:
            p = D[EFFECTS].obj[D[EFFECTS].names.index(effect)]
            p(D[SESS][effect])
        if D[CANCEL]:
            L[FORMAT].name = prefix() + "Canceled"

    def render_format(self):
        """ Renders from the bottom of the Format list. """
        j1 = D[RENDER]
        format_list = D[SESS][FORMAT]
        start = len(format_list) - 1
        Images.next_x = D[FORMAT_CNT] = 0

        for x in range(start, -1, -1):
            if not D[CANCEL]:
                D[FORMAT_CNT] += 1
                L[BB] = L[DS] = L[CLF] = None
                Layout.pix = 0
                d = format_list[x]
                row, col = d[ROW], d[COL]
                cell = Cell(d)

                #  Place images:
                for r in range(row):
                    for c in range(col):
                        if cell.has_image(r, c, d):
                            j = Layout.get_image(r, c, d)
                            j.r, j.c = r, c
                            j.rot = Layout.get_rotate(r, c, d)
                            Layout.place_img(j, d, cell)
                if Layout.pix:
                    z = L[IMAGE] = Lay.eat(j1, L[IMG_GRP])
                    a = 1 if Preview.has_formats else 0
                    z1 = L[FORMAT] = Lay.group(j1, d[NAME], a=a)

                    Lay.order(j1, z, z1)
                    if L[BB]:
                        z2 = Lay.selectable(j1, z, INHERIT_D)
                        Sel.item(j1, z2)
                        Sel.invert(j1)
                        klear(L[BB])
                        Sel.none(j1)
                        Lay.bury(j1, z2)
                        Lay.order(j1, L[BB], z1, a=1)

                    self.render_effect(d)
                    if not D[CANCEL]:
                        if L[BB] and L[DS]:
                            L[BB] = merge_shadow(BB)
                        if L[CLF]:
                            L[CLF_BG] = merge_shadow(CLF_BG)

    def return_session(self):
        """ Used to get session data for saving. """
        D[SESS][WIN] = deepcopy(D[WIN])
        return D[SESS]

    def set_global_scales(self):
        """ Sets the global scale variables. """
        D[SIZE] = D[WI], D[HG] = self.width_sb.get_val(), self.height_sb.get_val()

    def show_preview(self, *_):
        """ Called when the user activated the Show Preview Button. """
        D[PREVIEW].show()

    def uses_pixl8(self, n):
        """
        n: style
        Returns true if the chosen backdrop style uses pixl8.
        """
        return n in (PG,)

    def verify_bd_img_m(self):
        """
        The Backdrop Images menu is invalid if the
        Backdrop Style does not need an image.
        """
        a = self.bd_image_m
        if self.img_needed(self.bd_style_m.get_val()):
            a.enable()

            n = self.bd_image_m.get_val()
            if n not in self.backdrop_images or n != D[SESS][BD_IMG]:
                n = FIRST if FIRST in self.backdrop_images else NON
                D[SESS][BD_IMG] = n
                self.bd_image_m.set_val(n)

        else:
            a.disable()

    def verify_ext_dir(self):
        """
        The external directory is where preset and session files are stored.

        The script uses the user's home
        directory to create a storage folder.

        Returns a result flag. It is set to true if the directory is verified.
        """
        go = n1 = 0
        n = platform.system()

        if n == "Linux":
            n1 = u"/home/user/.GIMP/Roller/profiles/"

        elif n == "Darwin":
            n1 = u"/Library/Application Support/GIMP/Roller"

        elif n == "Windows":
            n1 = u"AppData\\Local\\GIMP\\Roller"

        if n1:
            try:
                n = D[DIR] = os.path.join(expanduser("~"), n1)
                err, go = ensure_dir(n)

            except Exception as ex:
                show_err(ex)

        else:
            show_err("The operating system isn't supported by Roller.")
        return go


def start():
    """
    Called by GIMP when the user selects the
    Roller menu item in the render menu.
    """
    # Save the interface context:
    pdb.gimp_context_push()
    set_antialias()
    UIMain()

    # Return undo functionality:
    if RENDER in D:
        pdb.gimp_image_undo_group_end(D[RENDER])

    # Restore the interface context:
    pdb.gimp_context_pop()


fu.register(
    # name
    # becomes dialog title as python-fu + name
    # Space character is not allowed.
    # ‟name” is case-sensitive:
    "Roller",

    # tool-tip and window-tip text:
    "Renders image compositions.",

    # help (describe how-to, exceptions and dependencies).
    # This info will display in the plug-in browser:
    "Creates a new image and does not require an open image.",

    # The author is displayed in the plug-in browser:
    "Charles Bartley",

    # The copyright is displayed in the plug-in browser:
    "Charles Bartley",

    # The date is displayed in the plug-in browser:
    "2020",

    # menu item descriptor with short-cut key ‟_R”:
    "_Roller...",

    # image types
    # An empty string equates to no image:
    "",

    # dialog parameters:
    [],

    # results:
    [],

    # dialog function handler
    # The second item is the menu's location:
    start, menu="<Image>/Filters/Render")


# Widgets that will signal a window's accept
# process upon receiving the return key:
RETURN_WIDGETS = (
    gtk.CheckButton,
    gtk.Entry,
    gtk.RadioButton,
    gtk.ScrolledWindow,
    gtk.SpinButton,
    gtk.ToggleButton,
    SwitchButton)
fu.main()
