#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_image_effect import ImageEffect
from roller_one_constant import ForStep, SessionKey
from roller_one_fu import Lay

BACKDROP = SessionKey.BACKDROP


class View:
    """
    Perform render. Use preview lists to track preview state.

    Create a previous list of steps.

    Is persistent after PortOption closes.

    Invalidate if a format-content or image
    size changes. Delete previous preview.
    """

    def __init__(self, stat):
        """Get ready for render previews."""
        self.stat = stat
        stat.preview = self

    def _delete_previous_preview(self, steps, d):
        """
        Delete invalid previous preview steps. Delete when changed.
        Previous preview steps are invalid when:
            * They are not part of a current preview.
            * Their options have changed.

        steps: list
            Has render steps to perform a preview.

        d: dict
            Use to get an option change-state.
            Has option group.
        """
        stat = self.stat
        j = stat.render.image

        # The backdrop image is not a previous step when the
        # backdrop-style is another type other than backdrop image:
        if len(stat.render.preview_steps) > 1:
            stat.render.preview_steps.pop(0)

        # Items in 'q' are invalid steps:
        q = [i for i in stat.render.preview_steps if i not in steps]

        # 'q1' has valid steps unless they have changed or are dependent:
        q1 = [i for i in stat.render.preview_steps if i in steps]

        # Changed steps are invalid:
        for opt_type, opt_key in q1:
            option_group = d[(opt_type, opt_key)]
            if option_group.changed:
                q.append((opt_type, opt_key))

        # Remove layers:
        for opt_type, opt_key in q:
            if opt_type == BACKDROP:
                stat.render.del_backdrop()

            else:
                layer_keys = ImageEffect.PROPERTY[opt_key][ImageEffect.LAYERS]
                for layer_key in layer_keys:
                    z = Lay.search(j, layer_key, is_err=0)
                    if z:
                        pdb.gimp_image_remove_layer(j, z)
        pdb.gimp_displays_flush()

    @staticmethod
    def _make_main_effect(steps):
        """
        Each format has a main effect. Make a list of these
        main effects and their associated format (opt_type).

        steps: iterable
            (opt_type, opt_key)
            'opt_type' is BACKDROP or format name.
            'opt_key' is a backdrop-style or an image-effect.
        """
        d = {}

        for opt_type, opt_key in steps:
            # Collect effects not style:
            if opt_type != BACKDROP:
                if opt_type not in d:
                    # The first step is the main effect:
                    d[opt_type] = opt_key
        return d

    def do(self, opt_type, opt_key, steps, session, is_preview=False):
        """
        Call to do a render preview.

        opt_type: string
            key to final step

        opt_key: string
            key to final sub-step

        steps: list
            render steps

        session: dict
            of session

        is_preview: flag
            Is true when the caller is doing a preview.
        """
        stat = self.stat
        d = stat.option_group_dict
        preview_steps = []
        changed_preview_steps = []
        main_effect = View._make_main_effect(steps)
        self.is_preview = is_preview

        # preview steps end with previewed option:
        for i in steps:
            preview_steps.append(i)
            if i == (opt_type, opt_key):
                break

        session_steps = preview_steps[:]

        if stat.render.preview_steps:
            self._delete_previous_preview(preview_steps, d)

        # Remove the unchanged from steps:
        for opt_type, opt_key in reversed(preview_steps):
            if not d[(opt_type, opt_key)].changed:
                break

            else:
                changed_preview_steps.insert(0, (opt_type, opt_key))

        # Previous steps are changed:
        for (opt_type, opt_key) in stat.render.preview_steps:
            d[(opt_type, opt_key)].changed = True

        # Current steps are unchanged:
        for opt_type, opt_key in session_steps:
            d[(opt_type, opt_key)].changed = False

        # Backdrop-style changes Backdrop Image:
        if len(session_steps) > 1:
            d[ForStep.BACKDROP_IMAGE_STEP].changed = 1
        stat.render.preview_steps = session_steps

        # Create the image:
        stat.product.do(
            changed_preview_steps,
            main_effect,
            session,
            self.is_preview
        )
