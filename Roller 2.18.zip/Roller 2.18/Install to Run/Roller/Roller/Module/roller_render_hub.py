#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from random import choice, randint, uniform
from roller_image_effect import ImageEffect, LayerKey as nk
from roller_one_base import Base, Comm
from roller_one_constant import (
    BumpKey as bk,
    ForBump as fb,
    ForFill,
    ForLayer,
    FormatKey as fk,
    OptionKey as ok,
    SessionKey as sk
)
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_one_mode import Mode
import colorsys
import gimpfu as fu
import math

ek = ImageEffect.Key
em = Fu.Emboss
pdb = fu.pdb
rn = Fu.RGBNoise
sn = Fu.SolidNoise
um = Fu.UnsharpMask
BLUR_BG_AMOUNT = 16
BOTTOM_LAYER = (
    nk.CELL_PLAQUE_BLUR_BEHIND,
    nk.CELL_FRINGE,
    nk.CELL_PLAQUE,
    nk.LAYER_FRINGE,
    nk.LAYER_PLAQUE,
    nk.LAYER_PLAQUE_BLUR_BEHIND
)
BRIGHTNESS_ZERO = 0
ONE_PIXEL = 1.
SAME_XY = ZERO_ANGLE = 0.
SHADOW_LAYER = ek.DROP_SHADOW, ek.FILL_LIGHT_SHADOW, ek.KEY_LIGHT_SHADOW

# dependent:
HIDE_LAYER = SHADOW_LAYER + (nk.IMAGE,)


class RenderHub:
    """
    Use with image-effect and backdrop-style options.

    Many thanks to Ofnuts for some of the source code which can be found at:
    sourceforge.net/projects/gimp-tools/s
    """

    @staticmethod
    def add_noise(j, z, d):
        """
        Create noise.

        j: GIMP image
            Has layer.

        z: layer
            to receive noise

        d: dict
            Has options.
        """
        go = 1

        if ok.NOISE_OPACITY in d:
            if not d[ok.NOISE_OPACITY]:
                go = 0
        if go:
            # Generate source of lines.
            # The horizontal and vertical sizes are randomized:
            pdb.plug_in_solid_noise(
                j,
                z,
                sn.NO_TILEABLE,
                sn.YES_TURBULENT,
                d[ok.RANDOM_SEED],
                d[ok.DETAIL_LEVEL],
                float(randint(1, 3)),
                float(randint(1, 3)),
            )

            # Harden the noise.
            # The radius is randomized:
            pdb.plug_in_unsharp_mask(
                j,
                z,
                choice((1., 3.)),
                um.AMOUNT_54,
                um.THRESHOLD_0
            )

            # Remove the white noise:
            Sel.item(j, z)
            Sel.clear_outside_of_selection(j, z)
            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))

            # Use feather to soften the noise:
            if d[ok.SOFTNESS]:
                Sel.item(j, z)
                pdb.gimp_selection_feather(j, d[ok.SOFTNESS])
                Sel.invert(j)
                Lay.clear_sel(j, z)
                Lay.blur(j, z, d[ok.SOFTNESS] / 100.)

    @staticmethod
    def adjust_mean_value(z):
        """
        Adjust a layer's material so that it's mean
        intensity is within theoretical bounds.

        z: layer
            work-in-progress
        """
        def histogram():
            """
            Determine mean intensity.

            Return: float
                mean intensity
            """
            return pdb.gimp_drawable_histogram(
                z,
                fu.HISTOGRAM_VALUE,
                .0,
                1.
            )[0]

        def curves():
            """
            Adjust the layer's middle range using the 'ratio'
            of the theoretical mean and the actual mean.
            """
            pdb.gimp_drawable_curves_spline(
                z,
                fu.HISTOGRAM_VALUE,
                8,
                (.0, .0, .3, .3 * ratio, .7, .7 * ratio, 1., 1.)
            )

        mean = histogram()

        # If the layer is only black pixels, the mean will be zero:
        if mean:
            # Consider 3 classes of intensity:
            if mean < 85:
                # theoretical 100:
                theory = (128 + mean) / 2

            elif mean > 170:
                # theoretical 155:
                theory = (127 + mean) / 2

            else:
                # regular:
                theory = 127.5

            mean_min = theory - 16
            mean_max = theory + 16

            # Adjust for minimum mean:
            if mean_min > mean != theory:
                ratio = theory / mean
                for i in range(10):
                    curves()
                    mean = histogram()
                    if mean >= mean_min:
                        break

            # Adjust for maximum mean:
            if mean_max < mean != theory:
                ratio = theory / mean
                for i in range(10):
                    curves()
                    mean = histogram()
                    if mean <= mean_max:
                        break

    @staticmethod
    def blur_behind_frame(parent, stat, format_x):
        """
        Blur behind transparency material.

        parent: layer
            format group

        stat: Stat
            globals

        format_x: int
            format index
        """
        j = stat.render.image
        z = Lay.search(parent, nk.TRANSPARENCY, is_err=False)

        if not z:
            z = Lay.search(parent, nk.FILLER, is_err=False)

        if z:
            Sel.item(j, z)
            if not Sel.is_sel(j):
                z = 0
        if z:
            Lay.hide_layers_above(parent, z)
            Lay.hide_format_stack(stat, format_x)
            pdb.gimp_selection_all(j)

            q = []

            for i in HIDE_LAYER:
                z1 = Lay.search(parent, i, is_err=0)
                if z1:
                    Lay.hide(z1)
                    q.append(z1)

            pdb.gimp_edit_copy_visible(j)

            for i in q:
                Lay.show(i)

            Lay.show_layer_on_top(parent, z)
            Lay.show_format_groups(stat)

            z1 = Lay.search(parent, nk.IMAGE)
            z1 = Lay.paste(j, z1)

            pdb.gimp_layer_set_offsets(z1, 0, 0)

            z1.name = Lay.get_layer_name(
                nk.BLURRED_BACKGROUND,
                parent=parent
            )

            # If there's only transparency, then the blur-behind is pointless:
            if Lay.has_pixel(j, z1):
                z2 = Lay.selectable(j, z, ForLayer.MAKE_OPAQUE_DICT)

                Lay.blur(j, z1, BLUR_BG_AMOUNT)
                Sel.item(j, z2)
                Sel.clear_outside_of_selection(j, z1)
                pdb.gimp_image_remove_layer(j, z2)

                # Move the blur-behind layer to be
                # above the plaque and fringe layers:
                a = 1

                for i in BOTTOM_LAYER:
                    z3 = Lay.search(parent, i, is_err=0)
                    if z3:
                        a += 1
                pdb.gimp_image_reorder_item(
                    j,
                    z1,
                    parent,
                    len(parent.layers) - a
                )

    @staticmethod
    def blur_shadow(session, stat):
        """
        Simulate shadow blur of a transparent frame.

        session: dict
            of session

        stat: Stat
            Has render.
        """
        j = stat.render.image
        for form in session[sk.FORMAT_LIST]:
            parent = stat.render.format_group(None, form[fk.Layer.NAME])
            z = Lay.search(parent, nk.TRANSPARENCY, is_err=False)

            if not z:
                z = Lay.search(parent, nk.FILLER, is_err=False)
            if z:
                for i in SHADOW_LAYER:
                    z1 = Lay.search(parent, i, is_err=0)
                    if z1:
                        z2 = Lay.clone(j, z1)

                        Lay.blur(j, z2, BLUR_BG_AMOUNT)
                        Sel.item(j, z)
                        Sel.clear_outside_of_selection(j, z2, keep_sel=1)
                        Lay.clear_sel(j, z1)
                        pdb.gimp_image_merge_down(j, z2, fu.CLIP_TO_IMAGE)

    @staticmethod
    def brush_stroke(z, q, f, p):
        """
        Make a brush stroke.

        z: layer
            to receive brush stroke

        q: list
            of points

        f: float
            of brush

        p: function or None
            a callback for each stroke
        """
        if p:
            p()

        pdb.gimp_context_set_brush_angle(f)
        pdb.gimp_paintbrush_default(z, 2, q)

    @staticmethod
    def brush_stroke_on_stroke(
        z,
        brush,
        brush_size,
        stroke,
        spacing,
        callback=None,
        hardness=1.,
        angle=0.,
        angle_flux=0.,
        opacity_flux=0.
    ):
        """
        Brush stroke the path.

        z: layer
            to receive brush stroke
            Has a stroke-path.

        brush: string
            GIMP brush

        brush_size: float
            size of brush

        stroke: GIMP path
            to receive brush

        spacing: numeric
            distance between the strokes

        callback: function
            a callback for each brush stroke
        """
        def set_hardness():
            pdb.gimp_context_set_brush_force(
                Base.seal(
                    hardness + uniform(-opacity_flux, opacity_flux) / 100.,
                    .01,
                    1.
                )
            )

        length = stroke.get_length(.1)
        points, closed = stroke.points
        intervals = round((length / spacing))
        if intervals:
            interval_length = length / intervals

            pdb.gimp_context_set_brush_hardness(1.)
            pdb.gimp_context_set_brush(brush)
            pdb.gimp_context_set_brush_size(brush_size)
            pdb.gimp_context_set_brush_aspect_ratio(0.)
            pdb.gimp_context_set_dynamics('Dynamics Off')
            pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
            pdb.gimp_context_set_antialias(1)
            set_hardness()

            # first point:
            RenderHub.brush_stroke(
                z,
                points[2:4],
                RenderHub.calc_stroke_angle(
                    points[2:4],
                    RenderHub.get_origin_tangent(stroke),
                    angle
                ),
                callback
            )

            # special case for first and last:
            for step in range(1, int(intervals)):
                x1, y1 = stroke.get_point_at_dist(
                    step * interval_length,
                    .1
                )[0:2]
                x2, y2 = stroke.get_point_at_dist(
                    .5 + step * interval_length,
                    .1
                )[0:2]

                set_hardness()
                RenderHub.brush_stroke(
                    z,
                    (x1, y1),
                    RenderHub.calc_stroke_angle(
                        (x1, y1),
                        (x2, y2),
                        angle + uniform(-angle_flux, angle_flux)
                    ),
                    callback
                )

            # last point:
            if not closed:
                set_hardness()
                RenderHub.brush_stroke(
                    z,
                    points[-4:-2],
                    RenderHub.calc_stroke_angle(
                        RenderHub.get_end_tangent(stroke),
                        points[-4:-2],
                        angle + uniform(-angle_flux, angle_flux)
                    ),
                    callback
                )

    @staticmethod
    def bump(j, z, d, merge=0, stat=0):
        """
        Add bump to a layer.

        j: GIMP image
            work-in-progress

        z: layer
            work-in-progress

        d: dict
            Has options.

        merge: flag
            When true, the source layer is
            duplicated and the bump layer is merged.

        stat: Stat
            Has save selection function.
            When set, the selection is restored.

        Return: layer or None
            Return merged layer if merge.
        """
        if d[ok.BUMP] in fb.HAS_BUMP:
            if stat:
                sel = stat.save_render_sel()

            if merge:
                z = Lay.clone(j, z)
                z.opacity = 100.

            z.mode = fu.LAYER_MODE_OVERLAY
            f = d[bk.Noise.NOISE]

            if d[ok.BUMP] == fb.NOISE:
                if f:
                    # Set red, green, blue noise with 'f':
                    pdb.plug_in_rgb_noise(
                        j,
                        z,
                        rn.YES_INDEPENDENT,
                        rn.NO_CORRELATED,
                        f,
                        f,
                        f,
                        rn.NOISE_ZERO
                    )

            else:
                pdb.script_fu_clothify(
                    j,
                    z,
                    d[bk.Cloth.BLUR_X],
                    d[bk.Cloth.BLUR_Y],
                    d[ok.LIGHT_ANGLE],
                    max(min(d[bk.Emboss.BUMP_ELEVATION], 90.), 1.),
                    min(d[bk.Emboss.BUMP_DEPTH], 50.)
                )

            pdb.plug_in_emboss(
                j,
                z,
                d[ok.LIGHT_ANGLE],
                d[bk.Emboss.BUMP_ELEVATION],
                d[bk.Emboss.BUMP_DEPTH],
                em.EMBOSS
            )

            if merge:
                z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            if stat:
                Sel.load(j, sel)
        return z

    @staticmethod
    def calc_gradient(color, color1, steps):
        """
        Return the color-steps for a gradient.

        A color-step is a value that is added to one color's
        components in order for the color to become the second color.
        Each color component will have its own color-step.

        color, color1: tuple
            RGB
            of int

        steps: int
            the number of steps
        """
        delta = [0, 0, 0]
        step = [0, 0, 0]

        # Need the color distance to calculate a color step:
        if steps > 1:
            for x in range(3):
                delta[x] = abs(color[x] - color1[x]) / 1. / (steps - 1)

            # The color step can be positive or negative:
            for x in range(3):
                if color[x] > color1[x]:
                    step[x] = -delta[x]

                elif color[x] < color1[x]:
                    step[x] = delta[x]
        return step

    @staticmethod
    def calc_stroke_angle(p1, p2, f):
        """
        Calculate the angle of the brush given the
        base angle and a point with a tangent.

        p1, p2: points
            Form a tangent.

        f: float
            of brush
            base angle
        """
        x, y = p1
        x1, y1 = p2
        return ((f + math.degrees(math.atan2(y - y1, x - x1))) % 360.) - 180.

    @staticmethod
    def contract_image(j):
        """
        Reverse the image expansion provided by 'expand_image'.

        j: GIMP image
            work-in-progress
        """
        pdb.gimp_image_resize(j, j.width - 200, j.height - 200, -100, -100)

    @staticmethod
    def copy_for_blur(j, z, parent, stat, format_x):
        """
        Copy the visible layers that are below a layer.

        j: GIMP image
            work-in-progress

        z: layer
            work-in-progress
            center-piece

        parent: layer
            format group layer

        stat: Stat
            globals

        format_x: int
            format index

        Return: buffer
            copy of image
        """
        Lay.hide_layers_above(parent, z)
        Lay.hide_format_stack(stat, format_x)
        Lay.hide(z)
        pdb.gimp_edit_copy_visible(j)
        Lay.show(z)
        Lay.show_layer_on_top(parent, z)
        Lay.show_format_groups(stat)

    @staticmethod
    def create_shadow_unit(stat, layer, q):
        """
        Create a unified shadow layer.

        stat: Stat
            Has render.

        layer: layer
            group where unified-shadow layer belongs

        q: iterable
            layer keys for layers to merge
            Form a single shadow casting unit.

        Return: tuple
            layer
                unified shadow layer

            list
                Are layers that are contributing to the shadow-unit.
        """
        caster = []

        # Put layer(s) into a group and merge group:
        j, z = stat.render.image, layer
        group = Lay.group(stat.render.image, "Cast", parent=z)

        for k in q:
            z1 = Lay.search(z, k)
            z2 = Lay.clone(j, z1)

            pdb.gimp_image_reorder_item(j, z2, group, 0)
            Lay.hide(z1)
            caster.append(z1)

        z = Lay.merge_group(j, group)
        return z, caster

    @staticmethod
    def do_cartoony(j, z, z1, color):
        """
        Create a cartoony color frame for gradient frames.

        j: GIMP image
            work-in-progress

        z: layer
            Has frame.

        z1: layer
            Has noise.

        color: tuple
            RGB
            to colorize noise
        """
        group = Lay.group(j, z.name, parent=z.parent)

        pdb.gimp_image_reorder_item(j, z, group, 0)
        pdb.gimp_image_reorder_item(j, z1, group, 0)

        opacity = z1.opacity
        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_HSV_VALUE

        pdb.gimp_image_reorder_item(j, z, group, 0)

        z1 = Lay.clone(j, z1)
        z1.mode = fu.LAYER_MODE_LCH_COLOR
        z1.opacity = opacity

        pdb.plug_in_colorify(j, z1, color)
        Lay.merge_group(j, group)

    @staticmethod
    def do_grid(stat, z, q, is_vertical=1):
        """
        Draw grid lines.

        The grid lines are either horizontal
        or vertical, but not both.

        stat: Stat
            Has render.

        z: layer
            Draw on layer.

        q: tuple
            arguments for vertical or horizontal lines

        is_vertical: flag
            If it's true, the arguments are for vertical lines.
        """
        args = stat.render.image, z
        q1 = 0, 0, 0, (0, 0, 0), 0

        if is_vertical:
            args += q1 + q + q1

        else:
            args += q + q1 * 2
        pdb.plug_in_grid(*args)

    @staticmethod
    def do_rotated_layer(stat, z, d, p):
        """
        Create an enlarged layer before rotating.

        Use the callback to process the rotated layer.

        stat: Stat
            globals

        z: layer
            Is the layer that gets rotated and processed.

        d: dict
            Has options.

        p: callback
            Call to act on the rotated layer before it is returned.

        Return: layer
            the rotated layer
        """
        d = deepcopy(d)
        z1 = z
        j = stat.render.image
        w, h = stat.render.size

        if d[ok.ROTATE]:
            # Create a new image for the rotation:
            f = Base.circumradius(w, h) * 2
            j = pdb.gimp_image_new(f, f, fu.RGB)
            z = Lay.add(j, "Rotate")
            pdb.gimp_image_set_active_layer(j, z)

        else:
            z = Lay.clone(stat.render.image, z)

        z = p(j, z, d)

        if d[ok.ROTATE]:
            z = Lay.clone(j, z)

            pdb.gimp_item_transform_rotate(
                z, math.radians(d[ok.ROTATE]), 1, 0, 0)

            Lay.hide(j.layers[1])

            # Copy and paste the rotated gradient:
            Sel.rect(
                j,
                j.width // 2 - w // 2,
                j.height // 2 - h // 2,
                w,
                h,
                option=fu.CHANNEL_OP_REPLACE
            )

            pdb.gimp_edit_copy_visible(j)
            pdb.gimp_image_delete(j)
            z = Lay.paste(stat.render.image, z1)

        pdb.gimp_layer_resize_to_image_size(z)
        return z

    @staticmethod
    def do_shadow(
        stat,
        z,
        x,
        y,
        blur,
        color,
        intensity,
        layer_name="",
        d=None,
        is_inlay=0
    ):
        """
        Draw a drop shadow.

        Create a number of layers, group them, merge them,
        and then cast a shadow from the merged layer.

        If the shadow is an inlay shadow,
        create a layer to cast a shadow over the image.

        stat: Stat
            globals

        z: layer
            layer that casts shadow

        x: float
            offset x

        y: float
            offset y

        blur: float
            shadow blur

        color: tuple
            of int
            (R, G, B)
            shadow color

        intensity: int
            intensity

        layer_name: string
            owner's name
            Use to name the shadow layer.

        d: dict
            Has an 'OptionKey.MAKE_OPAQUE' item.

        is_inlay: flag
            if true, the selection is inverted.

        Return: layer
            the new shadow layer
        """
        j = stat.render.image

        if intensity:
            group = Lay.group(j, "Shadow")

            if d:
                for_opaque = Lay.selectable(j, z, d)

            else:
                for_opaque = Lay.clone(j, z)

            pdb.gimp_image_reorder_item(j, for_opaque, group, 0)

            if is_inlay:
                RenderHub.expand_image(j)

                z1 = Lay.add(j, "Inlay", parent=group)

                Lay.color_fill(z1, (255, 255, 255))
                Sel.item(j, for_opaque)
                Lay.clear_sel(j, z1)
                pdb.gimp_image_remove_layer(j, for_opaque)
                for_opaque = z1

            Sel.item(j, for_opaque)

            if not Sel.is_sel(j):
                intensity = 0

            if intensity:
                layer_count = int(intensity / 100.) + 1
                intensity /= layer_count

                pdb.script_fu_drop_shadow(
                    j,
                    for_opaque,
                    x,
                    y,
                    blur,
                    color,
                    intensity,
                    Fu.DropShadow.NO_RESIZING
                )

                # Increase shadow intensity by
                # stacking duplicate shadow layers:
                z = group.layers[0]
                for i in range(int(layer_count) - 1):
                    z = Lay.clone(j, z)

            if is_inlay:
                Sel.item(j, for_opaque)

            pdb.gimp_image_remove_layer(j, for_opaque)

            z = Lay.merge_group(j, group, n=layer_name)

            if is_inlay:
                Lay.clear_sel(j, z)
                RenderHub.contract_image(j)

            pdb.gimp_layer_resize_to_image_size(z)
            return z

    @staticmethod
    def do_stylish_shadow(
        stat,
        z,
        blur=15.,
        intensity=130.,
        offset_x=0,
        offset_y=0,
        d=None,
        is_inlay=0
    ):
        """
        stat: Stat
            globals

        z: layer
            to cast shadow

        blur: float
            shadow blur

        intensity: float
            shadow opacity

        offset_x: int
            shadow offset on x-axis (-, +)

        offset_y: int
            shadow offset on y-axis (-, +)

        d: inherit dict
            Has an MAKE_OPAQUE item.
            Use with the inlay option.

        is_inlay: flag
            If true, the shadow is an inlay type.

        Return: layer
            the shadow layer
        """
        parent = z.parent
        j = stat.render.image
        x = Lay.offset(j, z)
        z = RenderHub.do_shadow(
            stat,
            z,
            offset_x,
            offset_y,
            blur,
            (0, 0, 0),
            intensity,
            d=d,
            is_inlay=is_inlay
        )
        z.mode = fu.LAYER_MODE_NORMAL

        if is_inlay:
            x -= 1

        pdb.gimp_image_reorder_item(j, z, parent, x + 1)
        return z

    @staticmethod
    def draw_color_rectangles(j, z, w, h):
        """
        Draws two layer of colors stripes in order to create color rectangles.

        j: GIMP image
            work-in-progress

        z: layer
            layer to draw on

        w: int
            width of rectangle

        h: int
            height of rectangle

        Return: layer
            Has color grid.
        """
        # vertical panes:
        x = y = x1 = y1 = 0
        w1, h1 = j.width, j.height
        z.mode, z.opacity = fu.LAYER_MODE_NORMAL, 100.

        while x < w1:
            x1 = min(x1 + w, w1)

            Sel.rect(j, x, 0, x1 - x, h1, option=fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, Base.rnd_col())
            x = x1

        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        # horizontal panes:
        while y < h1:
            y1 = min(y1 + h, h1)

            Sel.rect(j, 0, y, w1, y1 - y, option=fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, Base.rnd_col())
            y = y1
        return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    @staticmethod
    def draw_sel(stat, sel, z):
        """
        Draw a selection as black pixels on white pixels.

        sel: selection
            selection channel
            to fill with black

        z: layer
            to receive fill
        """
        Lay.color_fill(z, (255, 255, 255))
        Sel.load(stat.render.image, sel)
        Sel.fill(z, (0, 0, 0))
        pdb.gimp_selection_none(stat.render.image)

    @staticmethod
    def emboss(j, z, light, contrast):
        """
        Emboss a layer.

        j: GIMP image
            work-in-progress

        z: layer
            to receive emboss

        light: float
            angle
            (0 .. 360)

        contrast: int
            contrast

        Use the elevation of thirty to make grey value for the face.

        The depth of one does not blend the light and shadow.
        """
        pdb.plug_in_emboss(
            j,
            z,
            light,
            em.ELEVATION_30,
            em.DEPTH_1,
            em.EMBOSS
        )
        pdb.gimp_brightness_contrast(z, BRIGHTNESS_ZERO, contrast)

    @staticmethod
    def expand_image(j):
        """
        Enlarge the render by 200 pixels on both x and y vectors.

        Provides extra pixel space for feathering and inlay shadow.

        j: GIMP image
            work-in-progress
        """
        pdb.gimp_image_resize(j, j.width + 200, j.height + 200, 100, 100)

    @staticmethod
    def get_end_tangent(stroke):
        """
        Compute the position of the end-point for a tangent.

        stroke: path
            work-in-progress
        """
        points = stroke.points[0]
        xe, ye = points[-4:-2]
        xt, yt = points[-6:-4]
        if abs(xe - xt) < .0001 and abs(ye - yt) < .0001:
            xt, yt = stroke.get_point_at_dist(
                stroke.get_length(.001) - .5,
                .01
            )[0:2]
        return xt, yt

    @staticmethod
    def get_layer_points(d, w, h):
        """
        Return the layer points for start and end coordinates.

        d: dict
            Has start and end points.
            fraction-of-layer points
            (0 .. 1)

        w, h: int
            size of render or canvas

        return:
            start and end coordinates
            x, y, x1, y1
        """
        x1 = y1 = -1
        x = int(round(d[ok.START_X], 6) * w)
        y = int(round(d[ok.START_Y], 6) * h)

        if ok.END_X in d:
            x1 = min(int(round(d[ok.END_X], 6) * w), w - 1)
            y1 = min(int(round(d[ok.END_Y], 6) * h), h - 1)
        return x, y, x1, y1

    @staticmethod
    def get_mode(d):
        """
        Return the mode and opacity in an option dict.

        d: dict
            Has options.
        """
        return Mode.get_x(d[ok.MODE]), d[ok.OPACITY] / 1.

    @staticmethod
    def get_origin_tangent(stroke):
        """
        Compute the origin-point position of a tangent.

        stroke: path
            work-in-progress

        Return: tuple
            origin point
            x, y
        """
        points = stroke.points[0]
        xo, yo = points[2:4]
        xt, yt = points[4:6]

        if abs(xo - xt) < .001 and abs(yo - yt) < .001:
            xt, yt = stroke.get_point_at_dist(.5, .01)[0:2]
        return xt, yt

    @staticmethod
    def get_point_on_rectangle(s, angle):
        """
        Calculate an x, y coordinate for a point intersecting
        a ray, originating from the center of a rectangle,
        and ending at its defining lines.

        s: tuple or list
            size
            width, height
            of int

        angle: float
            degrees
            angle from center of the rectangle

        Return: point
            x, y
            of float or int
            the point on the rectangle
        """
        w, h = s
        angle = math.radians(angle)
        sine = math.sin(angle)
        cosine = math.cos(angle)

        # distance to the top or the bottom edge (from the center):
        dy = h / 2 if sine > 0 else h / -2

        # distance to the left or the right edge (from the center):
        dx = w / 2 if cosine > 0 else w / -2

        # (distance to the vertical line) < (distance to the horizontal line):
        if abs(dx * sine) < abs(dy * cosine):
            # Calculate distance to the vertical line:
            dy = (dx * sine) / cosine

        # (distance to the top or the bottom edge)
        # < (distance to the left or the right edge):
        else:
            dx = (dy * cosine) / sine
        return max(0., round(dx + w / 2., 0)), max(0., round(dy + h / 2., 0))

    @staticmethod
    def hls_to_rgb(q):
        """
        Calculate the RGB components from an HLS iterable.

        q: tuple or list
            of HLS
            from colorsys

        return: list
            RGB
        """
        return [int(i * 255.) for i in colorsys.hls_to_rgb(*q)]

    @staticmethod
    def hsv_to_rgb(q):
        """
        Calculate the RGB components from an HSV iterable.

        q: tuple or list
            of HSV
            from colorsys

        return: list
            RGB
        """
        return [int(i * 255.) for i in colorsys.hsv_to_rgb(*q)]

    @staticmethod
    def invert_color(q):
        """
        Generate an inverted color.

        q: tuple
            RGB

        Return: tuple
            RGB
            inverted color
        """
        return tuple([255 - i for i in q])

    @staticmethod
    def set_brush_details():
        """Set up the brush for drawing lines."""
        pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
        pdb.gimp_context_set_opacity(100.)

        try:
            pdb.gimp_context_set_brush('perspective')

        except RuntimeError:
            Comm.info_msg("Roller is unable to use the 'perspective' brush.")

        pdb.gimp_context_set_brush_size(ONE_PIXEL)
        pdb.gimp_context_set_brush_aspect_ratio(SAME_XY)
        pdb.gimp_context_set_brush_angle(ZERO_ANGLE)
        pdb.gimp_context_set_dynamics('Dynamics Off')
        pdb.gimp_context_set_brush_force(1.)
        pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_brush_hardness(.95)

    @staticmethod
    def set_fill_context(d):
        """
        Set the context for the current fill-type operation.

        Call before a bucket fill operation.

        d: dict
            Has options.
        """
        pdb.gimp_context_set_sample_threshold(d[ok.THRESHOLD])
        pdb.gimp_context_set_opacity(d[ok.OPACITY])
        pdb.gimp_context_set_paint_mode(Mode.get_x(d[ok.MODE]))
        pdb.gimp_context_set_sample_criterion(
            ForFill.CRITERION_LIST.index(d[ok.CRITERION])
        )
