#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_one_constant import ForWidget
import gimpfu as fu
import random


class Mode:
    _q = [
        ("Normal", fu.LAYER_MODE_NORMAL),
        ("Dissolve", fu.LAYER_MODE_DISSOLVE),
        ("Color Erase", fu.LAYER_MODE_COLOR_ERASE),
        ("Erase", fu.LAYER_MODE_ERASE),
        ("Merge", fu.LAYER_MODE_MERGE),
        ("Split", fu.LAYER_MODE_SPLIT),
        (ForWidget.LIST_SEPARATOR, None),
        ("Lighten Only", fu.LAYER_MODE_LIGHTEN_ONLY),
        ("Luma Lighten Only", fu.LAYER_MODE_LUMA_LIGHTEN_ONLY),
        ("Screen", fu.LAYER_MODE_SCREEN),
        ("Dodge", fu.LAYER_MODE_DODGE),
        ("Addition", fu.LAYER_MODE_ADDITION),
        (ForWidget.LIST_SEPARATOR * 2, None),
        ("Darken Only", fu.LAYER_MODE_DARKEN_ONLY),
        ("Luma Darken Only", fu.LAYER_MODE_LUMA_DARKEN_ONLY),
        ("Multiply", fu.LAYER_MODE_MULTIPLY),
        ("Burn", fu.LAYER_MODE_BURN),
        ("Linear Burn", fu.LAYER_MODE_LINEAR_BURN),
        (ForWidget.LIST_SEPARATOR * 3, None),
        ("Overlay", fu.LAYER_MODE_OVERLAY),
        ("Hard Light", fu.LAYER_MODE_HARDLIGHT),
        ("Soft Light", fu.LAYER_MODE_SOFTLIGHT),
        ("Vivid Light", fu.LAYER_MODE_VIVID_LIGHT),
        ("Pin Light", fu.LAYER_MODE_PIN_LIGHT),
        ("Linear Light", fu.LAYER_MODE_LINEAR_LIGHT),
        ("Hard Mix", fu.LAYER_MODE_HARD_MIX),
        (ForWidget.LIST_SEPARATOR * 4, None),
        ("Difference", fu.LAYER_MODE_DIFFERENCE),
        ("Exclusion", fu.LAYER_MODE_EXCLUSION),
        ("Subtract", fu.LAYER_MODE_SUBTRACT),
        ("Divide", fu.LAYER_MODE_DIVIDE),
        ("Grain Extract", fu.LAYER_MODE_GRAIN_EXTRACT),
        ("Grain Merge", fu.LAYER_MODE_GRAIN_MERGE),
        (ForWidget.LIST_SEPARATOR * 5, None),
        ("LCH Lightness", fu.LAYER_MODE_LCH_LIGHTNESS),
        ("LCH Chroma", fu.LAYER_MODE_LCH_CHROMA),
        ("LCH Hue", fu.LAYER_MODE_LCH_HUE),
        ("LCH Color", fu.LAYER_MODE_LCH_COLOR),
        ("Luminance", fu.LAYER_MODE_LUMINANCE),
        (ForWidget.LIST_SEPARATOR * 6, None),
        ("HSV Hue", fu.LAYER_MODE_HSV_HUE),
        ("HSV Saturation", fu.LAYER_MODE_HSV_SATURATION),
        ("HSV Value", fu.LAYER_MODE_HSV_VALUE),
        ("HSL Color", fu.LAYER_MODE_HSL_COLOR)
    ]

    # Use with DensityGradient:
    GRADIENT_MODE_LIST = (
        "Lighten Only",
        "Luma Lighten Only",
        "Screen",
        "Dodge",
        "Addition",
        "Darken Only",
        "Multiply",
        "Burn",
        "Linear Burn",
        "Overlay",
        "Soft Light",
        "Hard Light",
        "Vivid Light",
        "Linear Light",
        "Difference",
        "Exclusion",
        "Subtract",
        "Grain Extract",
        "Grain Merge",
        "Divide",
        "HSL Color",
        "HSV Value",
        "LCH Color"
    )

    # Use with PaintRush:
    EDGE_MODE = (
        "Normal",
        "Lighten Only",
        "Screen",
        "Overlay",
        "Soft Light",
        "Hard Light",
        "Difference",
        "Subtract",
        "Grain Extract",
        "Grain Merge",
        "Divide",
        "HSV Value",
        "HSV Saturation",
        "HSL Color",
        "LCH Lightness",
        "Luminance"
    )

    d = OrderedDict(_q)
    names = [n for n in d]

    @staticmethod
    def get_x(k):
        """
        Return the integer value of a mode string.

        k: mode
        """
        return Mode.d[k]

    @staticmethod
    def rand():
        """Return a randomly selected mode (int)."""
        n = ForWidget.LIST_SEPARATOR
        q = Mode.names

        while ForWidget.LIST_SEPARATOR in n:
            n = random.choice(q)
        return n
