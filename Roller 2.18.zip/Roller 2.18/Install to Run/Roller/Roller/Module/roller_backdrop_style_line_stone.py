#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import seed
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay
from roller_one_gegl import Gegl
import gimpfu as fu

de = Fu.Despeckle
er = Fu.Erode
pdb = fu.pdb
um = Fu.UnsharpMask
FOUR_COORDINATES = 4


class LineStone:
    """Create a bumpy concrete base that has touches of color and line."""

    def __init__(self, one):
        """
        Do the backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        parent = one.z.parent
        if Lay.has_pixel(j, one.z):
            group = Lay.group(j, one.k, parent=parent)
            z = Lay.clone(j, one.z)

            seed(one.d[ok.RANDOM_SEED])
            pdb.gimp_image_reorder_item(j, z, group, 0)

            z = z1 = LineStone._do_step_one(j, z, group)
            z = LineStone._do_step_two(j, z, group)
            z.mode = fu.LAYER_MODE_GRAIN_EXTRACT

            pdb.gimp_edit_copy_visible(j)

            z.mode = fu.LAYER_MODE_NORMAL
            z = z2 = Lay.paste(j, z)
            z.mode = fu.LAYER_MODE_HARD_MIX

            pdb.gimp_edit_copy_visible(j)

            z = Lay.paste(j, z)
            z.mode = fu.LAYER_MODE_HSV_VALUE

            pdb.gimp_image_remove_layer(j, z1)
            pdb.gimp_image_remove_layer(j, z2)

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            z = LineStone._do_step_three(j, z, group)
            z = LineStone._do_step_four(j, z, group)
            z.mode = fu.LAYER_MODE_LCH_LIGHTNESS

            z = Lay.merge_group(j, group)
            LineStone._do_step_five(j, z, parent, one)

    @staticmethod
    def _do_step_one(j, z, parent):
        """
        Process in multiple phases.

        j: GIMP image
            work-in-progress

        z: layer
            work-in-progress

        parent: layer
            container group

        Return: layer
            work-in-progress
        """
        group = Lay.group(j, "Line 1", parent=parent)
        z = Lay.clone(j, z)

        pdb.gimp_image_reorder_item(j, z, group, 0)

        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_HSV_VALUE

        Gegl.edge(z)
        pdb.gimp_drawable_invert(z, 0)

        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
        z.opacity = 25.

        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_HARD_MIX
        z.opacity = 20.
        return Lay.merge_group(j, group)

    @staticmethod
    def _do_step_two(j, z, parent):
        """
        Process in multiple phases.

        j: GIMP image
            work-in-progress

        z: layer
            work-in-progress

        parent: layer
            container group

        Return: layer
            work-in-progress
        """
        group = Lay.group(j, "Line 2", parent=parent)
        z = Lay.clone(j, z)

        pdb.gimp_image_reorder_item(j, z, group, 0)

        Lay.dilate(j, z)
        pdb.plug_in_erode(
            j,
            z,
            er.PROPAGATE_BLACK,
            er.RGB_CHANNELS,
            er.FULL_RATE,
            er.DIRECTION_MASK_0,
            er.LOW_LIMIT_0,
            er.UPPER_LIMIT_255
        )
        return Lay.merge_group(j, group)

    @staticmethod
    def _do_step_three(j, z, parent):
        """
        Process in multiple phases.

        j: GIMP image
            work-in-progress

        z: layer
            work-in-progress

        parent: layer
            container group

        Return: layer
            work-in-progress
        """
        group = Lay.group(j, "Line 3", parent=parent)
        z = Lay.clone(j, z)

        pdb.gimp_image_reorder_item(j, z, group, 0)

        Gegl.blur(z, 4.)
        pdb.plug_in_despeckle(
            j,
            z,
            4,
            de.RECURSIVE_ADAPTIVE,
            de.WHITE_248,
            de.BLACK_7
        )
        Lay.dilate(j, z)

        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_HSV_VALUE
        Lay.dilate(j, z)
        return Lay.merge_group(j, group)

    @staticmethod
    def _do_step_four(j, z, parent):
        """
        Process in multiple phases.

        j: GIMP image
            work-in-progress

        z: layer
            work-in-progress

        parent: layer
            container group

        Return: layer
            work-in-progress
        """
        group = Lay.group(j, "Line 4", parent=parent)
        z = Lay.clone(j, z)

        pdb.gimp_image_reorder_item(j, z, group, 0)

        pdb.python_fu_foggify(j, z, "Clouds", (127, 127, 127), 3., 100.)
        return Lay.merge_group(j, group)

    @staticmethod
    def _do_step_five(j, z, parent, one):
        """
        Process in multiple phases.

        j: GIMP image
            work-in-progress

        z: layer
            work-in-progress

        parent: layer
            container group

        one: One
            Has original layer.

        Return: layer
            work-in-progress
        """
        group = Lay.group(j, "Line 5", parent=parent)

        pdb.gimp_image_reorder_item(j, z, group, 0)

        z = z1 = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_OVERLAY
        z.opacity = 100.

        pdb.plug_in_hsv_noise(j, z, 1, 5, 5, 5)
        Gegl.emboss(z, 45., 15., 3)

        pdb.gimp_curves_spline(
            z,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 100, 255, 155]
        )

        z = Lay.clone(j, one.z)
        z.mode = fu.LAYER_MODE_OVERLAY
        z.opacity = 100.

        pdb.gimp_image_reorder_item(j, z, group, 1)
        pdb.gimp_curves_spline(
            z,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 255, 255, 127]
        )

        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_DIFFERENCE
        z.opacity = 50.
        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_EXCLUSION
        z.opacity = 25.

        Gegl.do_gegl(z, "c2g")

        z1.opacity = 50.
        z = Lay.merge_group(j, group)
        Gegl.unsharp_mask(z, 5., 1.5, .3)
