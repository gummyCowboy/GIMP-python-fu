#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import ForWidget as fw, UIKey
from roller_port import Port
from roller_widget_tree import ChoiceList
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
import gtk


class PortChoice(Port):
    """Is a port with a Treeview list and process Buttons."""

    def __init__(self, d, g, k):
        """
        Create choice widgets.

        d: dict
            Has initial widget values.

        g: OptionButton
            Has widget value.

        k: string
            name of choice
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self._button = g
        self.color = g.color
        self._key = k
        Port.__init__(self, d)

    def _draw_list_group(self, g):
        """
        Draw the list group.

        g: GTK container
            for list group
        """
        key = self._key

        # without the case-sensitive:
        for i in ('radient', 'rush', 'ont', 'attern'):
            if i in key:
                break

        q = self._list = {
            'rush': self.stat.brush_list,
            'ont': self.stat.font_list,
            'radient': self.stat.gradient_list,
            'attern': self.stat.pattern_list
        }[i]
        choice = self._button.get_value()
        choice_list = ChoiceList(g, q, choice, self.do_accept)
        self.treeview = choice_list.treeview

    def do_accept(self, *_):
        """
        Accept the choice.

        Return: true
            The key-press is handled.
        """
        x = self.treeview.get_selection().get_selected_rows()[1][0][0]
        return self.do_accept_callback(self._list[x])

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = self._draw_list_group, self.draw_process_group
        group_name = "Available {}".format(self._key), ""

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if group_name[x]:
                vbox.pack_start(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=group_name[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()
            g.pack_start(box, expand=(True, False)[x])
        self.roller_window.win.vbox.set_size_request(350, 390)
