#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_base import Base
from roller_one_constant import (
    ForColor,
    ForFormat as ff,
    ImageKey as ik,
    OptionKey as ok,
    OptionLimitKey as olk,
    UIKey,
    WidgetKey as wk
)
from roller_widget import Widget
import gtk

# For GTK, let it know that the function handled an event:
DONE = 1

tip_dict = {
    ff.BRUSH_TIP_TYPE: Base.make_brush_tooltip,
    ff.BUMP_TIP_TYPE: Base.make_bump_tooltip,
    ff.CELL_GRID_TIP_TYPE: Base.make_cell_grid_tooltip,
    ff.IMAGE_TIP_TYPE: Base.make_image_tooltip,
    ff.MARGIN_TIP_TYPE: Base.make_margin_tooltip,
    ff.SHADOW_TIP_TYPE: Base.make_shadow_tooltip,
    ff.STRIPE_TIP_TYPE: Base.make_stripe_tooltip
}
tip_text_dict = {
    ff.BRUSH_TIP_TYPE: "Configure Brush",
    ff.BUMP_TIP_TYPE: "Configure Bump",
    ff.CELL_GRID_TIP_TYPE: "Configure Cell Grid",
    ff.MARGIN_TIP_TYPE: "Configure Margins",
    ff.SHADOW_TIP_TYPE: "Configure Shadow",
    ff.STRIPE_TIP_TYPE: "Configure Stripe"
}


class RollerButton(Widget):
    """This is a custom GTK Button."""

    def __init__(self, **d):
        """
        Create a gtk.Button that is attached to an gtk.Alignment.

        d: dict
            Has keyword arguments for Widget.
        """
        if isinstance(d[wk.TEXT], basestring):
            g = gtk.Button(d[wk.TEXT])

        else:
            # for arrow:
            g = gtk.Button()
            g.add(d[wk.TEXT])

        self.value = None
        self._is_only_one_tooltip = False

        if olk.ONLY_TOOLTIP in d:
            # So the tooltip won't change:
            d[olk.TOOLTIP] = d[olk.ONLY_TOOLTIP]
            self._is_only_one_tooltip = True

        Widget.__init__(self, g, **d)
        self.add(g)

        # Do connections last:
        g.connect('clicked', self.callback)

    def get_value(self):
        """
        Is part of the Widget template.

        Return: value
            from 'self.value'
        """
        return self.value

    def set_value(self, a):
        """
        Set 'self.value'.

        Is part of the Widget template.

        a: value
            Give to 'self.value'.
        """
        self.value = a


class RollerColorButton(Widget):
    """Open a color-chooser dialog on action."""

    def __init__(self, **d):
        """
        Create button.

        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.ColorButton(color=gtk.gdk.Color(0, 0, 0))

        Widget.__init__(self, g, **d)
        self.add(g)

        # Do connections last:
        g.connect('clicked', self.callback)
        g.connect('color_set', self.update_tooltip)

    @staticmethod
    def convert_to_rgb(color):
        """
        Convert gtk.gdk.Color to RGB.
        """
        if isinstance(color.red, int):
            return tuple(
                [i // 257 for i in (color.red, color.green, color.blue)]
            )

    def get_value(self):
        """
        Get the value of the button.

        Is part of the Widget template.

        Return: tuple
            color
            RGB
            (0 .. 255)
        """
        color = self.widget.get_color()
        return RollerColorButton.convert_to_rgb(color)

    def set_value(self, color):
        """
        Set the color of the button.

        Is part of the Widget template.

        color: gtk.gdk.Color
            of button
        """
        if not isinstance(color, gtk.gdk.Color):
            if isinstance(color, tuple):
                color = tuple([i * 257 for i in color])

            # gdk color range: 0 .. 65535
            # 257 in gdk color is 1 RGBA:
            color = gtk.gdk.Color(*color)

        self.widget.set_color(color)

        q = RollerColorButton.convert_to_rgb(color)
        n = ForColor.COLOR_TOOLTIP.format(q[0], q[1], q[2])
        self.set_tooltip_text(n)

    def update_tooltip(self, *_):
        """
        Update the widget after the user closes the color-chooser dialog.
        """
        self.set_value(self.get_value())


class ColoredButton(gtk.EventBox):
    """This Button changes color."""

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        super(ColoredButton, self).__init__()
        self.update_window = d['on_widget_change']
        self.background_color = d['background_color']

        # Embed the widget inside a VBox and an HBox:
        g = self.label = gtk.Label(d['text'])
        g1 = self.hbox = gtk.HBox()

        self.add(g1)
        g1.add(g)

        # events to react to:
        a = gtk.gdk
        p = self.connect

        for i in (
            a.BUTTON_PRESS_MASK,
            a.FOCUS_CHANGE_MASK,
            a.KEY_PRESS_MASK
        ):
            self.add_events(i)

        self.set_can_focus(1)
        self.set_color(self.background_color)

        # Avoid the 'button_press_event' as it fails the widget:
        p('button_release_event', self.on_click)
        p('key_press_event', self.on_key_press)
        p('focus_in_event', self.focus_in)
        p('focus_out_event', self.focus_out)

    def set_color(self, color):
        """
        Set the button-face color.

        color: gtk.gdk.Color
            button color
        """
        self.modify_bg(gtk.STATE_NORMAL, color)

    def on_click(self, *_):
        """Pass the click event to the button owner."""
        self.grab_focus()
        self.update_window(self)

    def on_key_press(self, g, a):
        """
        Process a 'space' key-press.

        g: self
        a: event
            key-press event

        Return: None or true
            Is true when key-press is processed.
        """
        if gtk.gdk.keyval_name(a.keyval) == 'space':
            self.update_window(g)
            return DONE

    def focus_in(self, *_):
        """Change the color of the button to show focus."""
        self.set_color(ForColor.FOCUS_COLOR)

    def focus_out(self, *_):
        """Change the color of the button to normal."""
        self.set_color(self.background_color)

    def set_label(self, n):
        """
        Change button's text.

        n: string
            for label
        """
        self.label.set_text(n)

    def set_size(self, w=10, h=10):
        """
        Try to set the size of the button.

        w: int
            width of widget

        h: int
            height of widget
        """
        self.set_size_request(width=w, height=h)

    def set_text_color(self, color):
        """
        Set the color of the button's text.

        color: gtk.gdk.Color
        state: normal or disabled
        """
        self.label.modify_fg(gtk.STATE_NORMAL, color)

    def show(self):
        """Display the custom button."""
        super(ColoredButton, self).show()
        for g in (self.hbox, self.vbox, self.label):
            g.show()


class OptionButton(RollerButton):
    """Has a label that reflects its data."""

    MAX_SIZE = 48
    WITH_VALUE = "{}…"

    def __init__(self, **d):
        """
        Create a GTK Button that is attached to a GTK Alignment.

        d: dict
            Has button variables.
        """
        # Relay on change:
        self._update_window = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self.do_choice

        self.tip_type = None
        d[wk.TEXT] = "…"

        RollerButton.__init__(self, **d)
        self.widget.set_use_underline(False)
        for k in (
            wk.CHOICE_WINDOW,
            wk.COLOR,
            wk.FRACTION_OF,
            UIKey.GET_FORMAT_INFO,
            UIKey.GET_SESSION_DICT,
            wk.GET_SIZE,
            wk.PREVIEW,
            wk.TIP_TYPE,
        ):
            if k in d:
                setattr(self, k, d[k])

    def _update_tooltip(self, a):
        """
        Set the button's tool-tip to 'value'.

        a: value
            give to 'self.value'
        """
        if not self._is_only_one_tooltip:
            # Python 3 doesn't have basestring:
            if isinstance(a, basestring):
                self.set_tooltip_text(" {} ".format(a))

            else:
                if self.tip_type in tip_dict:
                    p = tip_dict[self.tip_type]

                    if self.tip_type == ff.MARGIN_TIP_TYPE:
                        self.set_tooltip_text(p(a, self.fraction_of))

                    else:
                        self.set_tooltip_text(p(a))

    def connect_dependent(self, dependent):
        """
        Create a connect-event to update dependents

        dependent: list
            dependent widget
        """
        self.dependent += dependent

        self.widget.connect('clicked', self.check_dependent)
        self.check_dependent()

    def check_dependent(self, *_):
        """Update dependent widgets on button state."""
        n = self.get_value()
        for g in self.dependent:
            g.hide() if n == ok.NONE else g.show()

    def do_choice(self, g):
        """
        Open a choice window.

        Alter a button's value.

        g: RollerButton
            activated
            to receive choice
            not used
        """
        self.choice_window(self)
        self._update_window(self)

    def set_value(self, a):
        """
        Override the super class, so that the
        button's label can be modified.

        Is part of the Widget template.

        a: string
            the value to apply to 'self.value'
        """
        self.value = a
        n = ""

        self._update_tooltip(a)

        # There's no basestring in Python 3:
        if isinstance(a, basestring):
            n = a

        else:
            if self.tip_type in tip_text_dict:
                n = tip_text_dict[self.tip_type]

            elif self.tip_type == ff.IMAGE_TIP_TYPE:
                n = a[ik.IMAGE_REF]
                if a[ik.TYPE] == ff.Image.Type.FOLDER:
                    if a[ik.FILTER]:
                        n = "{}, {}, {}".format(
                            n,
                            a[ik.FILTER],
                            ff.Image.FOLDER_ORDER_LIST[a[ik.FOLDER_ORDER]]
                        )

                    else:
                        n = "{}, {}".format(
                            n,
                            ff.Image.FOLDER_ORDER_LIST[a[ik.FOLDER_ORDER]]
                        )

                elif (
                    a[ik.HAS_FORMAT] and
                    a[ik.AS_LAYERS] and
                    a[ik.TYPE] in ff.Image.Type.AS_LAYERS_LIST
                ):
                    n = "{}, As Layers, ".format(n)
                    if a[ik.AUTOCROP]:
                        n += "Autocrop, "
                    n += ff.Image.LAYER_ORDER_LIST[a[ik.LAYER_ORDER]]

        x = min(OptionButton.MAX_SIZE, len(n))
        self.widget.set_label(
            OptionButton.WITH_VALUE.format(n[-x:]))


class SwitchButton(ColoredButton):
    """Use to process cell connection events."""

    def __init__(self, text, on_action, r, c, g, grid, background_color):
        """
        text: string
            text on button

        on_action: function
            Call on action.

        r, c: int
            row, column
            table position

        g: gtk Box-type
            widget's padded container

        grid: dict
            table of cells

        background_color: gdk.gtk color
            color of the button
        """
        self.r = r // 2
        self.c = c // 2
        self.grid = grid
        self.action = on_action
        on_action = self.on_switch_action
        self.pad = g
        self.gate = 0
        ColoredButton.__init__(
            self,
            text=text,
            on_widget_change=on_action,
            background_color=background_color
        )

    def on_switch_action(self, _):
        """
        Reverse the switch setting.

        Call the connection operator.
        """
        x = self.gate = int(not self.gate)

        self.set_label(("+", "-")[x])
        self.action[x](self.grid[self.r][self.c])
