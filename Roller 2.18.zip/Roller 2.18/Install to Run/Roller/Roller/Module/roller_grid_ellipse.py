#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import Rect
from roller_grid_hexagon import GridHexagon
from roller_one_constant import ForFormat as ff


class GridEllipsis(GridHexagon):
    """
    Calculate the position and the size of cells.

    The cells are ellipse shaped.

    Use a double-spaced grid-type.
    """

    def __init__(self, grid):
        """
        Calculate the ellipse cell size rectangle and the ellipse shape.

        grid: One
            Has init values.
        """
        GridHexagon.__init__(self, grid)
        row, column = grid.r, grid.c
        table = grid.table
        is_by_count = 0 if grid.grid_type == ff.Grid.Index.CELL_SIZE else 1
        for r in range(row):
            for c in range(column):
                if Form.is_double_space_cell(r, c, self.is_double):
                    rect = table[r][c].cell
                    if is_by_count:
                        e = table[r][c].plaque = self._get_shape(rect)

                        if grid.with_shape:
                            table[r][c].shape = table[r][c].plaque

                        # The ellipse rect is smaller than the hexagon rect:
                        table[r][c].cell = Rect(
                            (e['x'], e['y']),
                            (e['w'], e['h'])
                        )

                    else:
                        e = {
                            'x': rect.x,
                            'y': rect.y,
                            'w': rect.w,
                            'h': rect.h
                        }
                        table[r][c].plaque = e
                        if grid.with_shape:
                            table[r][c].shape = e

    def _get_shape(self, rect):
        """
        Calculate the shape of an ellipse given
        a rectangle that bounds the ellipse,
        and a hexagonal layout pattern.

        rect: Rect
            Has bounds.

        Return: dict
            shape of ellipse
        """
        if self.is_horizontal:
            d = Form.calc_horizontal_ellipse(rect)

        else:
            d = Form.calc_vertical_ellipse(rect)
        return d

    def calc_shape_per_cell(self, *_):
        """
        Calculate the shape of the ellipse from
        the pocket size on a per cell basis.

        Is part of the GridDeck template.
        """
        # The pocket rectangle has the shape points:
        self.calc_shape_with_pocket()

    def calc_shape_with_pocket(self):
        """
        Calculate the shape of the ellipse from
        the pocket size using intersects.

        Is part of the GridDeck template.
        """
        for r in range(self.grid.r):
            for c in range(self.grid.c):
                if Form.is_double_space_cell(r, c, self.is_double):
                    rect = self.grid.table[r][c].pocket
                    self.grid.table[r][c].shape = {
                        'x': rect.x,
                        'y': rect.y,
                        'w': rect.w,
                        'h': rect.h
                    }
