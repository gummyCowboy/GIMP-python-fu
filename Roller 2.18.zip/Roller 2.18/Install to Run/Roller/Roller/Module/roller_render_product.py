#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_border import Border
from roller_format_caption import Caption
from roller_format_form import Form
from roller_format_fringe import Fringe
from roller_format_image import RollerImage
from roller_format_image_mask import ImageMask
from roller_image_effect import ImageEffect, LayerKey
from roller_image_effect_feather_reduction import FeatherReduction as fr
from roller_one import One
from roller_one_base import Comm
from roller_one_constant import (
    BackdropStyleKey as bsk,
    CellKey,
    ForLayout,
    FormatKey as fk,
    FreeCellKey as fck,
    MaskKey as ma,
    OptionKey as ok,
    PlaceKey as pl,
    PropertyKey as pr,
    SessionKey as sk
)
from roller_one_fu import Lay, Sel
from roller_one_pin import Pin
from roller_option_limit import OptionStat
import gimpfu as fu

ie = ImageEffect
ek = ie.Key
pdb = fu.pdb
IMAGE_EDGE_SHADOWS = ek.INLAY_SHADOW, ek.IMAGE_EDGE_SHADOW


class Product:
    """Create a render."""

    def __init__(self, stat):
        """
        The 'do' function is the entry point for
        rendering the formats, effects, and style.

        stat: Stat
            globals
        """
        self.stat = stat
        stat.product = self
        self._backdrop_sel = None

    def _do_backdrop_style(self):
        """Render a backdrop style."""
        stat = self.stat
        j = stat.render.image
        a = Pin.backdrop[self._opt_key]
        z = j.active_layer = stat.render.backdrop
        group = Lay.group(j, "Backdrop Group", offset=-1)
        z = Lay.clone(j, z)

        # Start off with the backdrop image or a clear slate:
        pdb.gimp_image_reorder_item(j, z, group, 0)

        d = self._wip[self._opt_type][self._opt_key]
        one = One(d=d, k=self._opt_key, session=self.session, stat=stat, z=z)

        a(one)

        z = Lay.merge_group(j, group)

        stat.render.replace_backdrop(z, self._opt_key)
        self._finish_step()

        if self._opt_key == bsk.BACKDROP_IMAGE:
            Sel.item(j, self.stat.render.backdrop)

            if not Sel.is_sel(j):
                pdb.gimp_selection_all(j)
            self._backdrop_sel = self.stat.save_backdrop_sel()

        else:
            # Image Gradient's option group has change:
            if not self.option_group.changed:
                Sel.load(j, self._backdrop_sel)
                Sel.invert(j)
                if Sel.is_sel(j):
                    pdb.gimp_edit_clear(z)
                    pdb.gimp_selection_none(j)

    def _do_effect(self, z):
        """
        Render an image-effect.

        z: layer
            format group
        """
        stat = self.stat

        # A format group with a image layer is required:
        if z:
            if self._effect_has_room(z):
                if self._is_shadow():
                    self._do_shadow(z)

                else:
                    z1 = Lay.search(z, LayerKey.IMAGE)

                    if ie.PROPERTY[self._opt_key][ie.IS_HIDE]:
                        Lay.hide(z1)

                    else:
                        Lay.show(z1)

                    a = Pin.effect[self._opt_key]
                    one = One(
                        d=self._wip[self._opt_type][self._opt_key],
                        k=self._opt_key,
                        parent=z,
                        session=self.session,
                        stat=stat
                    )
                    a(one)
        self._finish_step()

    def _do_free_cell(self, d, parent):
        """
        Add a free-range cell and image to the render.

        d: dict
            of free cell
        """
        stat = self.stat
        j = RollerImage.get_image(
            self.session,
            d[pl.IMAGE_PLACE][pl.IMAGE_DICT]
        )
        if j:
            Form.prep_free_cell_image(j, d, stat.render.size)

            z = stat.layout.place_image(j, d, None, parent)

            if d[ma.IMAGE_MASK][ma.TYPE] != ok.NONE:
                if ImageMask.make_mask_selection(
                    self.session,
                    d,
                    stat,
                    None,
                    ForLayout.FREE_CELL,
                    ForLayout.FREE_CELL,
                    False,
                    image=j
                ):
                    j1 = stat.render.image

                    Sel.clear_outside_of_selection(j1, z)
                    if d[ma.IMAGE_MASK][ma.FEATHER]:
                        fr.do(j1, z, d[ma.IMAGE_MASK])

            stat.save_image_sel(
                z,
                d[fck.CELL][CellKey.NAME],
                ForLayout.FREE_CELL,
                ForLayout.FREE_CELL
            )
            RollerImage.close_image(j)

    def _do_shadow(self, z):
        """
        Render a shadow effect.

        z: layer
            format group
        """
        stat = self.stat

        # Get the caster key:
        if self._opt_key in IMAGE_EDGE_SHADOWS:
            e = dict(is_inlay=True, caster_key=(LayerKey.IMAGE,))

        else:
            e = {
                'caster_key':
                ie.PROPERTY[self._main_effect[self._opt_type]]
                [ie.CAST]
            }

        one = One(
            d=self._wip[self._opt_type][self._opt_key],
            e=e,
            k=self._opt_key,
            parent=z,
            stat=stat
        )
        Pin.effect[self._opt_key](one)
        self._finish_step()

    def _effect_has_room(self, z):
        """
        Determine if an effect has room.

        z: layer
            format layer

        Return: flag
            Is true if the image-effect has working space.
        """
        m = True
        stat = self.stat
        image_layer = Lay.search(z, LayerKey.IMAGE, is_err=0)

        if not image_layer:
            m = False

        elif self._opt_key not in ie.IMAGE_DUPLICATOR:
            Lay.show(image_layer.parent)
            Sel.item(stat.render.image, image_layer)
            Sel.invert(stat.render.image)

            m = Sel.is_sel(stat.render.image)

            if not m and self._opt_key != ek.NO_EFFECT:
                Comm.info_msg(
                    "{} has no room for its image-effect.".format(
                        self._opt_key
                    )
                )
        return m

    def _finish_step(self):
        """
        Perform after completing a step.

        Refresh the display and remove the selection marquee.
        """
        pdb.gimp_selection_none(self.stat.render.image)

    def _is_not_image(self, d):
        """
        Determine if the backdrop image is none.

        d: dict
            with options
            from backdrop image

        Return: flag
            Is true if the backdrop image is none.
        """
        j = RollerImage.get_image(self.session, d[ok.BACKDROP_IMAGE])
        return j is None

    def _is_shadow(self):
        """
        Determine if an effect is a shadow type.

        Return: flag
            Is true if the image-effect is a shadow-effect.
        """
        return self._opt_key in ie.CASTER_EFFECT

    def _render_cell(self, j, d, x, r, c, name, is_merge):
        """
        Render a cell.

        j: RollerImage
            for cell

        d: dict
            of format

        x, r, c: int
            cell index
            format index, row, column

        name: string
            of image selection

        is_merge: flag
            Is true when the cell grid has merged cells.
        """
        j.r, j.c = r, c
        j.rotate = Form.get_image_property(d, r, c)[pr.ROTATE]
        z = self.stat.layout.place_image(j, d, x, self.parent)
        if z:
            e = Form.get_image_mask(d, r, c)
            has_mask = False

            if e[ma.TYPE] != ok.NONE:
                has_mask = True

            if has_mask:
                has_mask = ImageMask.make_mask_selection(
                    self.session,
                    d,
                    self.stat,
                    x,
                    r,
                    c,
                    is_merge
                )

            if has_mask:
                j1 = self.render.image

                Sel.clear_outside_of_selection(j1, z)
                if e[ma.FEATHER]:
                    fr.do(j1, z, e)
            self.stat.save_image_sel(z, name, r, c)

    def _render_format(self):
        """
        Render a format. A format may have groups,
        an image layer, and cell-modification layers.
        """
        stat = self.stat
        render = self.render = stat.render
        layout = stat.layout
        session = self.session
        if not render.has_format:
            format_list = session[sk.FORMAT_LIST]
            start = len(format_list) - 1
            for x in range(start, -1, -1):
                d = format_list[x]
                name = d[fk.Layer.NAME]
                row, column = layout.get_division(x)
                parent = self.parent = render.format_group(x, name)
                is_double = Form.is_double_space(d)
                is_merge = Form.is_merge_cells(d)
                layout.init_format_references()

                if not d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                    # Reverse for image z-order:
                    for i in reversed(d[fk.Layer.CELL_LIST]):
                        self._do_free_cell(i, parent)

                # Place images:
                for r in range(row):
                    for c in range(column):
                        m = 1

                        if is_double:
                            m = Form.is_double_space_cell(r, c, is_double)
                        if m:
                            j = layout.get_grid_image(
                                session,
                                d,
                                x,
                                r,
                                c,
                                is_merge
                            )
                            if j:
                                layout.set_layer_name(j, x, r, c)
                                self._render_cell(
                                    j,
                                    d,
                                    x,
                                    r,
                                    c,
                                    name,
                                    is_merge
                                )
                                RollerImage.close_image(j)

                if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                    # Reverse for image z-order:
                    for i in reversed(d[fk.Layer.CELL_LIST]):
                        self._do_free_cell(i, parent)

                # Merge group for posterity:
                if layout.image_group:
                    render.consume_image_group(
                        name,
                        layout.image_group
                    )

                Caption(session, d, x, stat, parent)
                Border(session, d, x, stat, parent)
                stat.plaque.do(session, d, x)
                Fringe(session, d, x, stat, parent)
                Lay.hide(parent)

    def _show_subformats(self, opt_type):
        """
        Show a format and any formats below it.

        Is necessary because a format without an image
        will skip the previous show format group command.

        opt_type: string
            a format name
            Use to locate the top format group.
        """
        render = self.stat.render
        j = render.image
        parent = render.format_group(None, opt_type)
        if not parent.visible:
            Lay.show(parent)
            for i in reversed(j.layers):
                if pdb.gimp_item_is_group(i):
                    n = Lay.get_format_name_from_group(i)

                    if n == opt_type:
                        break
                    Lay.show(i)

    def do(self, steps, main_effect, session, is_preview=False):
        """
        Perform a preview.

        steps: list
            A step is based on an option group.
            preview or final steps

        main_effect: dict
            Keys are format names.
            Values are main effects keys.
            Use to find caster key for shadows.

        session: dict
            of current session

        is_preview: flag
            Is true when the render is initiated as a preview function.
        """
        self._main_effect = main_effect
        self.session = session
        self.is_preview = is_preview
        self._wip = session[sk.SESSION_OPT]
        stat = self.stat
        z = stat.render.backdrop
        z.name = z.name.split(":")[0] + ": Working"

        stat.init_render()

        # Need for consistency:
        pdb.gimp_context_set_feather(0)

        stat.layout.calc_cell_table(self.session)

        for step in steps:
            self._opt_type, self._opt_key = step
            if OptionStat.step_is_backdrop_style(self._opt_type):
                # Expose the option group for image gradient:
                self.option_group = stat.option_group_dict[step]

                self._do_backdrop_style()

                d = self._wip[self._opt_type][self._opt_key]
                if ok.KEEP_GRADIENT in d:
                    if d[ok.KEEP_GRADIENT]:
                        stat.image_gradient_used = \
                            stat.image_gradients_created[-1]

            else:
                self._render_format()
                self._show_subformats(self._opt_type)
                self._do_effect(stat.render.format_group(None, self._opt_type))

        j = self.stat.render.image

        pdb.gimp_selection_none(j)
        pdb.gimp_displays_flush()
        stat.del_render_sel()
