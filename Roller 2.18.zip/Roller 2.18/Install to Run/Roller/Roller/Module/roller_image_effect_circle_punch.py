#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_border_line import BorderLine
from roller_image_effect import ImageEffect
from roller_one_constant import ForGradient as fg, OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb


class CirclePunch(BorderLine):
    """Add round holes to a frame that fits around a BorderLine frame."""

    def __init__(self, one):
        """
        Do the Circle Punch image-effect.

        one: One
            Has variables.
        """
        BorderLine.__init__(
            self,
            one,
            framer=self.make_sel,
            filler=lambda *args: None
        )

    @staticmethod
    def draw_circles(j, z, d):
        """
        Draw circles on the rotated layer.

        Create a pattern (a black circle).
        Use the clipboard to hold the pattern.
        Fill the target layer with the pattern.

        j: GIMP image
            target image
            not used

        z: layer
            target layer

        d: dict
            Has options.

        Return: layer
            work-in-progress
            Has material to select.
        """
        diameter = d[ok.CIRCLE_DIAMETER]
        w = int(diameter * 1.5)
        h = int(w * .8660254)
        j1 = pdb.gimp_image_new(w, h, fu.RGB)
        z1 = Lay.add(j1, "pattern")
        x = (w - diameter) // 2
        y = (h - diameter) // 2

        Sel.ellipse(
            j1,
            x,
            y,
            diameter,
            diameter,
            option=fu.CHANNEL_OP_REPLACE
        )
        Sel.fill(z1, (0, 0, 0))
        pdb.gimp_selection_none(j1)
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)
        RenderHub.set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_pattern("Clipboard Image")
        pdb.gimp_drawable_edit_bucket_fill(
            z,
            fu.FILL_PATTERN,
            Fu.BucketFill.X_IS_1,
            Fu.BucketFill.Y_IS_1
        )
        return z

    def make_sel(self, d):
        """
        Modify the current selection with selected circles.

        Add the circle selection to the border selection
        within the bounds of the filler selection.

        d: dict
            Has options.

        Return: state of selection
        """
        stat = self.stat
        j = stat.render.image
        frame_sel = stat.save_render_sel()
        z = Lay.add(j, self.option_key, parent=self.parent)
        z1 = RenderHub.do_rotated_layer(stat, z, d, CirclePunch.draw_circles)

        Sel.item(j, z1)

        sel = stat.save_render_sel()
        if sel:
            Sel.load(j, self.fill_sel)
            Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
            Sel.grow(j, 1, 1)
            pdb.gimp_selection_feather(j, 1)

        pdb.gimp_image_remove_layer(j, z)
        pdb.gimp_image_remove_layer(j, z1)
        Sel.load(j, frame_sel, option=fu.CHANNEL_OP_ADD)
