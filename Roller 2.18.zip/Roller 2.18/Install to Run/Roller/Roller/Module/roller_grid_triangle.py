#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import Rect
from roller_grid import Grid
from roller_one_constant import (
    ForFormat as ff,
    FormatKey as fk,
    ForTriangle
)

RATIO = ff.Cell.Shape.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = ff.Cell.Shape.TRIANGLE_SCALE_RATIO_UP
VERTICAL = ForTriangle.VERTICAL_TRIANGLE
X_INTERSECT_COUNT = 2


class GridTriangle:
    """
    Calculate the position and the size of cells for a triangle grid.

    Use intersects to map points shared by multiple triangles.
    Intersects create seamless triangle joints.
    """

    def __init__(self, grid):
        """
        Calculate cell points and cell shapes.

        grid: One
            Has init values.
        """
        self.grid = grid
        self.shape = grid.cell_shape
        row, column = grid.r, grid.c
        table = grid.table
        s = grid.layer_space
        intersect = self.intersect = []
        x_intersect = self.x_intersect = []
        y_intersect = self.y_intersect = []
        x, y = grid.offset
        self.is_vertical = 1 if self.shape in VERTICAL else 0

        if grid.grid_type in (
            ff.Grid.Index.CELL_SIZE,
            ff.Grid.Index.SHAPE_COUNT
        ):
            # cell size:
            if grid.grid_type == ff.Grid.Index.CELL_SIZE:
                w, h = grid.column_width / 1., grid.row_height / 1.

                # table size:
                if self.is_vertical:
                    w1 = w / 2.
                    w2 = w - w1
                    s1 = column * w1 + w2, row * h

                else:
                    h1 = h / 2.
                    h2 = h - h1
                    s1 = column * w, row * h1 + h2

            else:
                # Calculate 's1', the table size.
                # Calculate 'w', 'h', the cell size.
                # shape count:
                if self.is_vertical:
                    w1 = s[0] / (.5 + column * .5)
                    h1 = s[1] / 1. / row

                    # There are two possible solutions.
                    # solution one:
                    _w, _h = h1 * UP_RATIO, h1
                    w2 = _w / 2.
                    w3 = _w - w2
                    s1 = column * w2 + w3, row * _h

                    # solution two:
                    _w1, _h1 = w1, w1 * RATIO
                    w2 = _w1 / 2.
                    w3 = _w1 - w2
                    s2 = column * w2 + w3, row * _h1

                else:
                    # horizontal triangles:
                    w1 = s[0] / 1. / column
                    h1 = s[1] / (.5 + row * .5)

                    # two possible solutions
                    # solution one:
                    _w, _h = h1 * RATIO, h1
                    h2 = _h / 2.
                    h3 = _h - h2
                    s1 = column * _w, row * h2 + h3

                    # solution two:
                    _w1, _h1 = w1, w1 * UP_RATIO
                    h2 = _h1 / 2.
                    h3 = _h1 - h2
                    s2 = column * _w1, row * h2 + h3

                # If solution one fails, use solution two:
                if s1[0] > s[0] or s1[1] > s[1]:
                    s1 = s2
                    w, h = _w1, _h1

                else:
                    w, h = _w, _h
            x, y = Grid.calc_pin_offset(grid.pin, s, s1[0], s1[1], x, y)

        else:
            if self.is_vertical:
                # Calculate cell size for aligned horizontally:
                w = s[0] / (.5 + column * .5)
                h = s[1] / 1. / row

            else:
                w = s[0] / 1. / column
                h = s[1] / (.5 + row * .5)

        offset = x, y

        if self.is_vertical:
            w /= 2.

        else:
            h /= 2.

        # cell rectangle:
        for c in range(column + 2):
            x_intersect.append(int(round(x)))
            x += w

        for r in range(row + 2):
            y_intersect.append(int(round(y)))
            y += h

        # 'intersect' has cell shape mid-points:
        if self.is_vertical:
            x = w + offset[0]
            for c in range(column):
                intersect.append(int(round(x)))
                x += w

        else:
            y = h + offset[1]
            for r in range(row):
                intersect.append(int(round(y)))
                y += h

        # Compose points:
        for r in range(row):
            for c in range(column):
                if self.is_vertical:
                    y, y1 = y_intersect[r], y_intersect[r + 1]
                    x, x1 = x_intersect[c], x_intersect[c + 2]

                else:
                    y, y1 = y_intersect[r], y_intersect[r + 2]
                    x, x1 = x_intersect[c], x_intersect[c + 1]

                position = x, y
                size = x1 - x, y1 - y

                if (
                    x + size[0] > s[0] + offset[0] or
                    y + size[1] > s[1] + offset[1]
                ):
                    position = size = 0, 0

                # 'cell' is the cell rectangle before margins:
                table[r][c].cell = Rect(position, size)
                if size[0]:
                    # If there are no margins, then do shape:
                    table[r][c].plaque = self._get_intersect_shape(r, c)
                    if grid.with_shape:
                        table[r][c].shape = table[r][c].plaque

    def _do_per_cell_horizontal(self, r, c, q, is_inverted):
        """
        Get and calculate the points to draw a horizontal triangle.

        Horizontal triangles face left or right.

        r, c: int
            cell index

        q: tuple
            top, bottom, left, right

        is_inverted: flag
            It's true, the facing is inverted.

        Return: tuple
            of lists
            x-intersect list, x-pocket list, and
            y-intersect list, y-pocket list
            Each list has strict synchronized points.
        """
        top, bottom, left, right = q

        # '-1' are invalid points:
        x_list = [-1, -1, -1]
        y_list = [-1, -1, -1]

        x_list_1 = [0, 0, 0]
        y_list_1 = [0, 0, 0]
        is_left = (
            (not is_inverted and self._is_left) or
            (is_inverted and not self._is_left)
        )

        # Get intersect points.
        # of y:
        if not top:
            y_list[0] = self.y_intersect[r]

        if not bottom:
            y_list[2] = self.y_intersect[r + 2]

        if not top and not bottom:
            y_list[1] = self.intersect[r]

        # of x:
        if not left:
            if is_left:
                x_list[1] = self.x_intersect[c]

            else:
                x_list[0] = x_list[2] = self.x_intersect[c]

        if not right:
            if is_left:
                x_list[0] = x_list[2] = self.x_intersect[c + 1]

            else:
                x_list[1] = self.x_intersect[c + 1]

        # Calculate pocket-bound triangle points:
        rect = self.grid.table[r][c].pocket

        # of x:
        if is_left:
            x_list_1[1] = rect.x
            x_list_1[0] = x_list_1[2] = rect.x + rect.w

        else:
            x_list_1[0] = x_list_1[2] = rect.x
            x_list_1[1] = rect.x + rect.w

        # of y:
        y_list_1[0] = rect.y
        y_list_1[2] = rect.y + rect.h
        y_list_1[1] = (y_list_1[0] + y_list_1[2]) // 2

        # Return the intersect and pocket-bound points:
        return x_list, x_list_1, y_list, y_list_1

    def _do_per_cell_vertical(self, r, c, q, is_inverted):
        """
        Get and calculate the points to make a vertical triangle.

        Vertical triangles face up or down.

        r, c: int
            cell index

        q: tuple
            top, bottom, left, right

        is_inverted: flag
            If it's true, the triangle is inverted.

        Return: tuple
            of lists
            x-intersect list, x-pocket list, and
            y-intersect list, y-pocket list
            Each list has strict synchronized points.
        """
        top, bottom, left, right = q
        x_list = [-1, -1, -1]
        y_list = [-1, -1, -1]
        x_list_1 = [0, 0, 0]
        y_list_1 = [0, 0, 0]

        is_down = (
            (is_inverted and self._is_up) or
            (not is_inverted and not self._is_up)
        )

        # Get points from intersects:
        # of y:
        if not top:
            if is_down:
                y_list[0] = y_list[1] = self.y_intersect[r]

            else:
                y_list[2] = self.y_intersect[r]

        if not bottom:
            if is_down:
                y_list[2] = self.y_intersect[r + 1]

            else:
                y_list[0] = y_list[1] = self.y_intersect[r + 1]

        # of x:
        if not left:
            x_list[0] = self.x_intersect[c]

        if not right:
            x_list[1] = self.x_intersect[c + 2]

        if not left and not right:
            x_list[2] = self.intersect[c]

        # Calc shape from pocket:
        rect = self.grid.table[r][c].pocket

        # of y:
        if is_down:
            y_list_1[0] = y_list_1[1] = rect.y
            y_list_1[2] = rect.y + rect.h

        else:
            y_list_1[0] = y_list_1[1] = rect.y + rect.h
            y_list_1[2] = rect.y

        # of x:
        x_list_1[0] = rect.x
        x_list_1[1] = rect.x + rect.w
        x_list_1[2] = (x_list_1[0] + x_list_1[1]) // 2

        # Return the intersect and pocket-bound points:
        return x_list, x_list_1, y_list, y_list_1

    def calc_shape_per_cell(self, d):
        """
        Calculate the shape of the triangle from
        the pocket size on a per cell basis.

        Is part of the GridDeck template.

        d: dict
            Has format.
        """
        self._is_up = 1 if self.shape == ForTriangle.TRIANGLE_UP else 0
        self._is_left = 1 if self.shape == ForTriangle.TRIANGLE_LEFT else 0
        table = self.grid.table
        for r in range(self.grid.r):
            for c in range(self.grid.c):
                rect = self.grid.table[r][c].cell
                if rect.w:
                    is_inverted = Form.is_triangle_inverted(r, c)
                    q = d[fk.Cell.Margin.PER_CELL][r][c]
                    q = Form.combine_margin(q, rect.w, rect.h)

                    if self.is_vertical:
                        q = self._do_per_cell_vertical(r, c, q, is_inverted)

                    else:
                        q = self._do_per_cell_horizontal(r, c, q, is_inverted)

                    x_list, x_list_1, y_list, y_list_1 = q
                    q = zip(x_list, x_list_1)
                    q_x = map(Grid.get_point, q)
                    q = zip(y_list, y_list_1)
                    q_y = map(Grid.get_point, q)
                    q = zip(q_x, q_y)
                    table[r][c].shape = [j for i in q for j in i]

    def calc_shape_with_pocket(self):
        """
        Calculate the shape of the triangle from
        the pocket size using intersects.

        Is part of the GridDeck template.
        """
        q = self.grid.table
        intersect = self.intersect = []
        x_intersect = self.x_intersect = []
        y_intersect = self.y_intersect = []

        for c in range(self.grid.c):
            rect = q[0][c].pocket
            x_intersect.append(rect.x)
            x_intersect.append(rect.x + rect.w)

        for r in range(self.grid.r):
            rect = q[r][0].pocket
            y_intersect.append(rect.y)
            y_intersect.append(rect.y + rect.h)

        # Calculate mid-point:
        if self.is_vertical:
            for c in range(self.grid.c):
                rect = q[0][c].pocket
                x = (rect.x + rect.x + rect.w) // 2
                intersect.append(x)

        else:
            for r in range(self.grid.r):
                rect = q[r][0].pocket
                y = (rect.y + rect.y + rect.h) // 2
                intersect.append(y)

        # Compose shape:
        for r in range(self.grid.r):
            for c in range(self.grid.c):
                if q[r][c].pocket.w:
                    q[r][c].shape = self._get_intersect_shape(
                        r,
                        c,
                        for_pocket=True
                    )

    def _get_intersect_shape(self, r, c, for_pocket=False):
        """
        Do shape.

        r, c: int
            cell index

        for_pocket: flag
            If it's true, the intersects are
            calculated with pocket dimensions.

        Return: tuple
            shape
        """
        if for_pocket:
            c1, c2, c3, c4 = c, c * 2, c * 2 + 1, c * 2 + 1
            r1, r2, r3, r4 = r, r * 2, r * 2 + 1, r * 2 + 1

        else:
            c1, c2, c3, c4 = c, c, c + 2, c + 1
            r1, r2, r3, r4 = r, r, r + 1, r + 2

        if self.is_vertical:
            x, x1 = self.x_intersect[c2], self.x_intersect[c3]
            y, y1 = self.y_intersect[r2], self.y_intersect[r3]
            x2 = self.intersect[c1]

            # The 'y' value flips when inverted:
            is_inverted = Form.is_triangle_inverted(r, c)

            if self.shape == ForTriangle.TRIANGLE_DOWN:
                is_inverted = not is_inverted

            if is_inverted:
                q = x2, y1, x, y, x1, y

            else:
                q = x2, y, x, y1, x1, y1

        else:
            # horizontal triangle:
            x, x1 = self.x_intersect[c2], self.x_intersect[c4]
            y, y1 = self.y_intersect[r2], self.y_intersect[r4]
            y2 = self.intersect[r1]

            # The 'x' value flips when inverted:
            is_inverted = Form.is_triangle_inverted(r, c)

            if self.shape == ForTriangle.TRIANGLE_LEFT:
                is_inverted = not is_inverted

            if is_inverted:
                q = x1, y, x1, y1, x, y2

            else:
                q = x, y, x, y1, x1, y2
        return q
