#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_INTERSECT  # type: ignore
from roller_a_contain import Deco, Run
from roller_constant_key import Option as ok
from roller_deco import ready_canvas_rect, ready_shape, transform_foam
from roller_fu import (
    add_layer,
    make_layer_group,
    select_rect,
    select_shape,
    verify_layer,
    verify_layer_group
)
from roller_view_hub import color_selection_default
from roller_view_real import get_light


def create_face_per_strip(maya, group):
    """
    Create Face/Caption/Strip.

    maya: Maya
    group: layer
        Is the destination of the Strip layer.

    Return: layer or None
        Strip material
    """
    model = maya.model
    k = maya.k
    group = make_layer_group(Run.j, "Material", group, get_light(maya))
    maya.rect = (.0, .0) + (model.get_facing_rect(k)[2:])
    Deco.shape = model.get_facing_shape(k)
    z = create_strip(maya, group, is_finish=False, is_clip=False)

    if z:
        transform_foam(maya.rect, z, model.get_facing_foam(k))
    return verify_layer_group(group)


def create_facing_per_strip(maya, group):
    """
    Create Facing/Caption/Strip.

    maya: Maya
    group: layer
        Is the destination of Facing/Caption/Strip layer.

    Return: layer or None
        Strip material
    """
    model = maya.model
    k = maya.k
    maya.rect = (.0, .0) + (model.get_facing_rect(k)[2:])
    Deco.shape = model.get_facing_form(k)
    z = create_strip(maya, group, is_finish=False, is_clip=False)
    if z:
        z = transform_foam(maya.rect, z, model.get_facing_foam(k))

        model.clip_facing(z, k)
        return z


def create_strip(maya, group, is_finish=True, is_clip=True):
    """
    Create a background Strip for a Caption.

    maya: Maya
        Strip

    group: layer
        Is the parent group for Strip output.

    is_finish: bool
        When true, the Strip layer is finish checked.

    is_clip: bool
        If True, then the Strip rectangle is clipped to Maya's 'shape' polygon.

    Return: layer or None
        Strip material
    """
    k = maya.k
    d = maya.value_d
    q = maya.model.get_caption_y(k)
    if q:
        y, text_h = q
        j = Run.j

        # A failed Strip layer is None, 'z1'.
        z1 = None

        super_maya = maya.super_maya
        z = super_maya.matter
        if z:
            half_h = text_h // 2.
            center_y = y + half_h
            strip_h = text_h * d[ok.HEIGHT]
            if strip_h:
                y = center_y - strip_h // 2.
                offset = get_light(maya) if group == maya.group else 0

                # A WIP layer fails, so go with a view sized layer.
                z1 = add_layer(j, "Material", group, offset)

                color = d[ok.COLOR_1]

                select_rect(j, maya.rect[0], y, maya.rect[2], strip_h)

                if is_clip:
                    # Clip material outside of the shape.
                    select_shape(
                        j, Deco.shape, option=CHANNEL_OP_INTERSECT
                    )

                color_selection_default(z1, color)
                if is_finish:
                    verify_layer(z1)
        return z1


def do_canvas_strip(maya):
    """
    Make Canvas/Caption/Strip.

    maya: Maya
    Return: layer or None
        Strip material
    """
    a = maya.super_maya

    ready_canvas_rect(a, a.value_d, option=None)

    maya.rect = a.rect
    return verify_layer(create_strip(maya, maya.group))


def do_cell_main_strip(maya):
    """
    Draw Cell/Caption/Strip for main.

    maya: Maya
        Strip

    Return: layer or None
        Strip material
    """
    group = make_layer_group(Run.j, "Material", maya.group, get_light(maya))
    a = maya.super_maya
    p = maya.model.get_plaque

    for k in a.main_q:
        maya.k = k
        maya.rect = fetch_rect(a, a.value_d, k)
        Deco.shape = p(k)
        create_strip(maya, group, is_finish=False)
    return verify_layer_group(group)


def do_cell_per_strip(maya):
    """
    Make a Cell/Per/Caption/Strip.

    maya: Maya
    Return: layer or None
        Strip material
    """
    a = maya.super_maya

    ready_shape(a, a.value_d, option=None)

    maya.rect = a.rect
    maya.k = a.k
    return create_strip(maya, maya.group)


def do_face_main_strip(maya):
    """
    Make a Face/Caption/Strip for main.

    maya: Maya
    Return: layer or None
        Strip material
    """
    return make_facial_main_strip(maya, create_face_per_strip)


def do_face_per_strip(maya):
    """
    Make Face/Per/Caption/Strip.

    maya: Maya
    Return: layer or None
        Strip material
    """
    return make_facial_per_strip(maya, create_face_per_strip)


def do_facing_main_strip(maya):
    """
    Make Facing/Caption/Strip for main.

    maya: Maya
    Return: layer or None
        Strip material
    """
    return make_facial_main_strip(maya, create_facing_per_strip)


def do_facing_per_strip(maya):
    """
    Make Facing/Caption/Per/Strip.

    maya: Maya
    Return: layer or None
        Strip material
    """
    return make_facial_per_strip(maya, create_facing_per_strip)


def fetch_rect(maya, d, k):
    """
    Retrieve a Maya's rectangle (Cell, Face, or Facing) using its Goo key.

    maya: Maya
    d: dict
        Caption Preset

    k: string
        Goo or Map key

    Return: Rect or None
        as requested
    """
    if d[ok.OBEY_MARGIN]:
        # with Margin applied
        return maya.model.get_pocket_rect(k)
    else:
        # with Shift applied
        return maya.model.get_shift_rect(k)


def make_facial_per_strip(maya, p):
    """
    Make Face or Facing Caption/Per/Strip.

    maya: Maya
    p: function
        Make Strip output.

    Return: layer or None
        Strip material
    """
    group = make_layer_group(Run.j, "Material", maya.group, get_light(maya))
    maya.k = maya.super_maya.k

    p(maya, group)
    return verify_layer_group(group)


def make_facial_main_strip(maya, p):
    """
    Make Face or Facing Caption/Strip for main

    maya: Maya
    p: function
        Make Strip output.

    Return: layer or None
        Strip material
    """
    group = make_layer_group(Run.j, "Material", maya.group, get_light(maya))

    for k in maya.super_maya.main_q:
        maya.k = k
        p(maya, group)
    return verify_layer_group(group)
