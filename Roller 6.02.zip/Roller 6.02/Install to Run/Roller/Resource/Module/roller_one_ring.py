#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_a_contain import The
from roller_constant_for import Signal as si
import gobject  # type: ignore


class Ring(gobject.GObject, object):
    """
    Accept Signal from object. Keep signal in an OrderedDict.
    Process signal when the interface is idle.

    The baby paradigm is inspired by a subscriber's dependency on Ring.
    """
    # Reference
    #   github.com/sebp/PyGObject-Tutorial/blob/master/source/objects.txt
    #   library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
    #   zetcode.com/gui/pygtk/signals/
    #   stackoverflow.com/questions/66730/how-do-i-create-a-new-signal-in-pygtk

    # Are signals that can be emitted by this class.
    __gsignals__ = si.RING_D

    # Is a Ring instance for the connect and emit function.
    gob = None

    signal_d = OrderedDict()

    # Has subscriber in idle signal checking ring, '_crib'.
    # {object id: object}
    _crib = {}

    # Is True when there are no Signal in 'signal_d', 'is_gone'.
    # Send a 'si.RING_GONE' Signal when the dict is emptied.
    is_gone = False

    def __init__(self):
        # Enable custom signal.
        gobject.GObject.__init__(self)
        Ring.gob = self

    @staticmethod
    def add(a, n, arg):
        """
        Add a signal to the signal dict.

        a: object
            Is the sender that emits the Signal.

        n: string
            Signal descriptor

        arg: value
            Sent with Signal.
        """
        k = id(a), n

        # Remove old an Signal so that the new Signal is done last.
        if k in Ring.signal_d:
            Ring.signal_d.pop(k)
        Ring.signal_d[k] = a, n, arg

    @staticmethod
    def carry(baby):
        """
        Subscribe an object, (e.g. a Model instance), so that it can
        do its own Signal processing when the interface is idle.
        """
        Ring._crib[id(baby)] = baby

    @staticmethod
    def drop(baby):
        """
        Remove a subscriber.

        baby: Baby
            Is in the crib.
        """
        Ring._crib.pop(id(baby))

    @staticmethod
    def plug(n, arg):
        """
        Add a Ring Signal.

        n: string
            Signal type

        arg: value
        """
        Ring.add(Ring.gob, n, arg)

    @staticmethod
    def pressure():
        """Clear the Signal list and all subscribers do the same."""
        # more Signal-to-process flag, 'm'.
        m = True

        while m:
            m = False

            # There are possible semi-circular usage of Ring by a subscriber.
            Ring.turn()

            # object id, object; '_, a'
            for a in Ring._crib.values():
                if a.signal_d:
                    a.pressure()
                    m = True
            m = m or bool(Ring.signal_d)

    @staticmethod
    def send():
        """
        Send out a Signal. Respond to gobject idle state.

        Return: True
            Tell gobject to continue to call with True.
        """
        Ring.turn()

        if not Ring.signal_d:
            # Is empty flag, 'm'.
            m = True

            # Only call subscriber if a Preset isn't loading.
            if not The.load_count:
                for a in Ring._crib.values():
                    if a.signal_d:
                        m = False
                        a.turn()
            if m:
                Ring.gob.emit(si.RING_EMPTY, None)
        return True

    @staticmethod
    def turn():
        """Send out one Signal if there is one."""
        if Ring.signal_d:
            for i, a in Ring.signal_d.items():
                sender, signal, arg = a

                Ring.signal_d.pop(i)
                sender.emit(signal, arg)

                if not Ring.signal_d:
                    if not Ring.is_gone:
                        Ring.is_gone = True
                break
            if Ring.is_gone:
                Ring.is_gone = False
                Ring.gob.emit(si.RING_CLEARED, None)


if not Ring.gob:
    Ring()

# Register custom Signal.
gobject.type_register(Ring)
