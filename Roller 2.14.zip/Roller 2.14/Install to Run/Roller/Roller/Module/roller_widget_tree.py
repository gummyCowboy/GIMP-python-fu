#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import ForColor, ForWidget as fw
from roller_widget import Widget
from roller_widget_box import RollerBox
import gtk


class TreeViewList(Widget):
    """Is a base for a TreeView list widget."""

    def __init__(self, on_change, background_color, header, min_width, **d):
        """
        Create a TreeView list.

        on_change: function
            Call on select.

        background_color: value
            background color of TreeView cell

        header: string
            navigation-type title

        min_width: int
            minimum width of the column
        """
        self._update_window = on_change
        self._background_color = background_color
        self.list_store = gtk.ListStore(str, str, str)
        tree = self.treeview = gtk.TreeView(model=self.list_store)
        tree.set_headers_visible = 0
        d['on_widget_change'] = self.selected

        Widget.__init__(self, tree, **d)

        # Create a column:
        col = gtk.TreeViewColumn(
            header,
            gtk.CellRendererText(),
            text=0,
            foreground=1,
            background=2
        )

        col.set_min_width(min_width)
        col.set_sizing(gtk.TREE_VIEW_COLUMN_AUTOSIZE)

        # Add the column to the TreeView:
        tree.append_column(col)

        # The treeview cursor-changed signal will send a signal
        # when a row is clicked even if the row is already selected:
        tree.connect('cursor_changed', self.selected)
        if not header:
            # Hide the column header:
            col.set_widget(gtk.Label(""))

    def add_item(self, n):
        """
        Add an item to the list.

        n: string
            item to add
        """
        self.list_store.append([n, '#000000', self._background_color])

    def get_sel_x(self):
        """
        Get the row index of the selected item.

        Return: int or None
            (0 .. n)
        """
        x = None
        q1 = self.treeview.get_selection().get_selected_rows()[1]

        if q1:
            x = q1[0][0]
        return x

    def populate_treeview(self, q):
        """
        Populate the TreeView from a list.
        The previous indexed-list is replaced.

        q: list
            of string
        """
        # Replace "TreeView.ListStore's" iterator.
        self.list_store = gtk.ListStore(str, str, str)
        self.treeview.set_model(self.list_store)

        # Append items to list:
        for n in q:
            self.add_item(n)

    def select_item(self, x):
        """
        Select a TreeView item.

        x: int
            row index in the TreeView
            (0 .. n)
        """
        self.treeview.set_cursor(x)

    def selected(self, *_):
        self._update_window(self, self.get_sel_x())

    def set_value(self, q):
        """
        Load the treeview from a list.

        Initialize group visibility tracking.

        q: iterable
            of items to display in list
        """
        self.populate_treeview(q)


class ChoiceList(TreeViewList):
    """Is a treeview composed of a list."""

    def __init__(self, container, choices, choice, on_accept):
        """
        Create a treeview list.

        container: gtk container
            for list

        choices: list
            for treeview list

        choice: string
            an initial choice

        on_accept: function
            callback on return key
        """
        TreeViewList.__init__(self, self._on_change, '#00FEFF', "", 120)
        self.populate_treeview(choices)

        self._do_accept_callback = on_accept
        g1 = self.scrolled_window = gtk.ScrolledWindow()
        g1.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        g1.add(self.treeview)

        container.pack_start(g1, expand=True)

        # Select the previous choice for the user:
        if choice in choices:
            x = choices.index(choice)

        else:
            x = 0

        self.treeview.set_cursor(x)

        selection = self.treeview.get_selection()
        model, _iter = selection.get_selected()
        path = model.get_path(_iter)
        self.treeview.scroll_to_cell(path)

        # Do connection last now that everything is in place:
        self.treeview.connect('key_press_event', self._on_key_press)

    def _on_change(self, *_):
        return

    def _on_key_press(self, g, a):
        """
        Use to catch the return key.

        g: widget
            not in use

        a: event
            of key-press

        Return: flag
            Is true if the key-press is processed.
        """
        n = gtk.gdk.keyval_name(a.keyval)
        if n == 'Return':
            return self._do_accept_callback()


class NavigationList(TreeViewList):
    """
    Is a GTK TreeView with a ListStore to make a list display.

    Use the NavigationList template to
    hook feedback from the NavigationList:
        on_list_change: function
            Call when the navigation list changes.
    """

    def __init__(self, g, on_change, min_width, on_key_press, item_count=0):
        """
        Create the navigation list.

        g: GTK container
            to receive the TreeView

        on_change: function
            Call on treeview selection change.

        min_width: int
            minimum width of the TreeView column

        item_count: int
            number of items in the list
            Use to add a scrolled window.
        """
        w = fw.MARGIN
        self.group_box = []
        self.switch_group_box = None
        hbox = RollerBox(gtk.HBox)

        TreeViewList.__init__(
            self,
            on_change,
            ForColor.LIST_CELL_COLOR,
            "",
            min_width
        )
        self.add(self.treeview)

        if item_count > 14:
            g1 = gtk.ScrolledWindow()
            g1.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
            g1.add(self)

        else:
            g1 = self

        hbox.add(g1)
        hbox.set_padding(w // 2, w, w, w)
        g.add(hbox)
        self.treeview.connect('key_press_event', on_key_press)

    def insert_item(self, n, x):
        """
        Insert an item into the NavigationList.

        n: string
            item

        x: int
            index
            item's position
            (0..len(list) - 1)
        """
        q = []

        for i in self.list_store:
            q.append(i[0])

        q.insert(x, n)
        self.populate_treeview(q)

    def remove_item(self, index):
        """
        Remove an item from the list.

        index: int
            row number
        """
        q = []

        for i in self.list_store:
            q.append(i[0])

        q.pop(index)
        self.populate_treeview(q)
