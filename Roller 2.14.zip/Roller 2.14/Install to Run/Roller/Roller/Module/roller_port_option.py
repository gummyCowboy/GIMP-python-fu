#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import ImageEffect
from roller_one_base import Base
from roller_one_constant import (
    BackdropStyleKey as bsk,
    BranchKey,
    ForStep,
    ForWidget as fw,
    OptionKey as ok,
    OptionLimitKey as olk,
    SessionKey as sk,
    UIKey
)
from roller_one_fu import Lay
from roller_one_tip import Tip
from roller_option_dependent import OptionDependent
from roller_option_group import OptionGroup
from roller_option_limit import Option, OptionStat
from roller_port import Port
from roller_one_preset import Preset
from roller_widget_branch import Branch
from roller_widget_button import RollerButton
from roller_widget_button_pair import ButtonPair
from roller_widget_check_button import RollerCheckButton
from roller_widget_combo import RollerComboBox
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_radio import RadioBox
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable
import gtk

ek = ImageEffect.Key
CHOICE_TYPE = bsk.BACKDROP_STYLE, ek.IMAGE_EFFECT
NO_LABEL = RollerCheckButton, RollerButton
NO_PREVIEW_TYPE = CHOICE_TYPE + (ek.NO_EFFECT,)


class PortOption(Port):
    """Edit image-effect and backdrop-style options."""
    FRAME_WIDGET = {
        'changed': RollerComboBox,
        'value_changed': RollerSlider,
        'activate': RollerCheckButton,
        'clicked': RollerCheckButton
    }

    def __init__(self, d):
        """
        Draw widgets.

        d: dict
            Has init values.
        """
        stat = self.stat = d[UIKey.STAT]
        self._vbox = {}
        self._frame_gradient_group = []
        self._previous_option_group = None
        self._preview_steps = stat.render.preview_steps
        self._opt = d['opt_button']
        self.session = d[UIKey.GET_SESSION_DICT]()
        self.wip = self.session[sk.SESSION_OPT]
        self._get_updated_session = d[UIKey.GET_SESSION_DICT]

        d.update({UIKey.WINDOW_TITLE: "Render Options"})
        Port.__init__(self, d)
        self._show_port()

    def _draw_branch_group(self, g):
        """
        Create three GTK VBoxes. The first two will have
        a navigation list. The third VBox is for the option groups.

        g: GTK HBox
            for branch groups
        """
        trunk, offshoot = self._opt.get_steps(self.session)
        d = {
            BranchKey.CHANGE_OFFSHOOT_ITEM: self.change_offshoot_item,
            BranchKey.LABEL: ("Steps", "Sub-Steps"),
            BranchKey.MAKE_OPTION_GROUP: self.make_option_group,
            BranchKey.OFFSHOOT_ITEM: offshoot,
            BranchKey.TRUNK_ITEM: trunk,
            UIKey.ON_KEY_PRESS: self.on_key_press,
            UIKey.WINDOW: self,
            UIKey.STAT: self.stat
        }
        self.branch = Branch(d, g)
        e = self.stat.option_group_dict

        # Initialize option group inter-widget dependencies:
        for opt_type, opt_key in e:
            self._dependent_option.init_widget_state(
                self.branch,
                opt_key,
                e[(opt_type, opt_key)]
            )

    def _draw_option_group(self, g, opt_type, opt_key, option_group, color):
        """
        Create the widgets.

        g: GTK Vbox
            container for the widgets

        opt_type: string
            either BACKDROP or a format name

        opt_key: string
            of an option group of widgets

        option_group: OptionGroup
            Has layer info.

        color: int
            for the option group
        """
        # The 'default' dict has ordered keys:
        default = Preset.get_default(opt_key)

        pure = self.stat.option_limit.pure
        q = []
        d1 = dict(
            color=color,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            preview=self.do_preview,
            stat=self.stat,
            win=self.roller_window
        )

        for k in default:
            widget = pure[k][olk.WIDGET]
            e = self.stat.option_limit.collect_widget_arg(k, opt_key, self)
            e['key'] = k
            k1 = pure[k][olk.LABEL] if olk.LABEL in pure[k] else k

            e.update(d1)

            if opt_key in CHOICE_TYPE:
                e['on_widget_change'] = PortOption.on_choice_change

            if widget in NO_LABEL:
                e['text'] = k
                k1 = ""

            q1 = [k1, widget, e]
            q.append(q1)

        has_preset = False

        # preset:
        if opt_key not in NO_PREVIEW_TYPE:
            has_preset = True
            q += (
                [
                    "{} Preset".format(opt_key),
                    Preset,
                    dict(
                        d1,
                        key=opt_key,
                        on_widget_change=self.on_widget_change,
                        stat=self.stat,
                        win=self.roller_window
                    )
                ],
                [
                    "",
                    ButtonPair,
                    dict(
                        d1,
                        button_action=(
                            self.do_preview,
                            self.randomize_widgets
                        ),
                        on_widget_change=lambda *a: None,
                        text=("Preview", "Randomize")
                    )
                ],
            )

        elif opt_key in CHOICE_TYPE:
            # for backdrop-style and image-effect:
            q += (
                [
                    "",
                    RollerButton,
                    dict(
                        d1,
                        on_widget_change=self.randomize_lists,
                        text="Randomize"
                    )
                ],
            )

        else:
            # 'No Effect':
            q += (
                [
                    "",
                    RollerButton,
                    dict(
                        d1,
                        on_widget_change=self.do_preview,
                        text="Preview"
                    )
                ],
            )

        q = RollerTable.enlist(
            container=g,
            q=q,
            color=color,
            bottom_pad=fw.MARGIN
        )

        self.keep(q)

        # widget dict:
        d = option_group.widget_dict = {}
        q1 = q[:-2] if has_preset else q[:-1]

        for i in q1:
            d[i.key] = i

        # Link option group:
        q1 = q[:-1] if has_preset else q

        for i in q1:
            if isinstance(i, RadioBox):
                for j in i.buttons:
                    j.option_group = option_group

            else:
                i.option_group = option_group

        # button-pair:
        if has_preset:
            for i in (q[-1].left_button, q[-1].right_button):
                i.option_group = option_group

        # Load widget values:
        Port.loading += 1

        if opt_key in self.wip[opt_type]:
            d = self.wip[opt_type][opt_key]

        else:
            # Repair a broken link caused by updates:
            d = Preset.default[opt_key]

        if has_preset:
            g = option_group.preset = q[-2]
            g.widget_list = q[:-2]
            g.load_preset(fw.UNDEFINED, d)

        else:
            for i in q[:-1]:
                i.set_value(d[i.key])
            PortOption.on_choice_change(i)
        Port.loading -= 1

    def _get_option(self, opt_type, opt_key):
        """
        Get an option dict.

        opt_type, opt_key: string
            together they form a key

        Return: dict
            of option
        """
        key = opt_type, opt_key
        d = {}

        if opt_key == ek.FRAME_GRADIENT:
            # Use data from any other Frame Gradient option
            # as there is only one Frame Gradient per session:
            for i in self.stat.option_group_dict:
                if i != key:
                    if i[1] == ek.FRAME_GRADIENT:
                        d = self.stat.option_group_dict[i].preset.get_value()

        if not d:
            if key in self.stat.option_group_dict:
                option_group = self.stat.option_group_dict[(opt_type, opt_key)]

                if hasattr(option_group, 'preset'):
                    d = option_group.preset.get_value()

                else:
                    # There's no preset in the 'no preview' options:
                    d = {}
                    for i in option_group.widget_dict:
                        d[i.key] = i.get_value()

            else:
                # Use default:
                d = Preset.get_default(opt_key)
        return d

    def _show_port(self):
        """
        Call when switching to this port.

        Select a navigation list item in order to collapse the port pane.
        """
        self.pane.show_all()

        x = self.branch.trunk.get_sel_x()

        if x is not None:
            self.branch.offshoot[x].treeview.emit('cursor_changed')

        else:
            self.branch.trunk.select_item(0)
            self.branch.offshoot[0].select_item(0)

        self.branch.trunk.treeview.emit('cursor_changed')
        self.roller_window.win.present()

    def _sync_frame_gradients(self, g, option_group):
        """
        A frame gradient widget changed, and the
        other frame gradients need to be kept in sync.

        g: Widget
            Is responsible.

        option_group: OptionGroup
            with changed widget
        """
        a = Port.loading
        Port.loading = 1
        d = self.stat.option_group_dict

        for i in d:
            group = d[i]
            if group.opt_key == ek.FRAME_GRADIENT:
                if group is not option_group:
                    # Transfer settings from the changed frame gradient.
                    # They have the same keys in their groups:
                    group.widget_dict[g.key].set_value(
                        option_group.widget_dict[g.key].get_value()
                    )
                    group.preset.preset_is_undefined(ignore_loading=1)
        Port.loading = a

    def _update_wip(self):
        """
        Update the 'wip' dictionary with the values in the option groups.
        """
        d = self.stat.option_group_dict
        style_key = (sk.BACKDROP, bsk.BACKDROP_STYLE)
        q = [style_key, ForStep.BACKDROP_IMAGE_STEP]
        names = self.wip[sk.FORMAT_NAME_LIST]

        # Get valid steps:
        style = d[style_key].widget_dict[ok.BACKDROP_STYLE].get_value()

        q.append((sk.BACKDROP, style))

        for i in names:
            k = i, ek.IMAGE_EFFECT

            q.append(k)

            d1 = d[k].widget_dict
            effect = d1[ok.IMAGE_EFFECT].get_value()

            q.append((i, effect))

            substeps = OptionStat.get_effect_keys(effect)
            for j in substeps:
                q.append((i, j))

        # Update the valid steps:
        for i in q:
            opt_type, opt_key = i
            if i in d:
                if d[i].preset:
                    self.wip[opt_type][opt_key] = d[i].preset.get_value()

                else:
                    e = self.wip[opt_type][opt_key] = {}
                    d1 = d[i].widget_dict
                    for j in d1:
                        e[j] = d1[j].get_value()

        # Drop the options that aren't used:
        type_list = [sk.BACKDROP] + self.wip[sk.FORMAT_NAME_LIST]
        for i in type_list:
            key_list = [j for j in self.wip[i]]
            for j in key_list:
                if (i, j) not in q:
                    self.wip[i].pop(j)

    def change_offshoot_item(self, g, x, opt_key, opt_type):
        """
        An offshoot item is replaced with another item.

        g: NavigationList
            to be modified

        x: int
            index to item in NavigationList

        opt_key: string
            an effect or backdrop-style option

        opt_type: string
            either Backdrop or a format name
        """
        Port.loading += 1
        g.list_store[x][0] = opt_key
        option_group = None
        has_vbox = True if (opt_type, opt_key) in self._vbox else False

        if not has_vbox:
            if opt_type not in self.wip:
                self.wip[opt_type] = {}

            self.wip[opt_type][opt_key] = self._get_option(opt_type, opt_key)

            vbox = gtk.VBox()
            option_group = self.make_option_group(vbox, g, opt_type, opt_key)

        g.group_box.append(self._vbox[(opt_type, opt_key)])

        if option_group:
            self._dependent_option.init_widget_state(
                self.branch,
                opt_key,
                option_group
            )
        Port.loading -= 1

    def do_accept(self, *_):
        """
        Accept the changes made to opt.

        Return: true
            The key-press is handled.
        """
        d = self.stat.option_group_dict[
            ForStep.BACKDROP_IMAGE_STEP
        ].widget_dict
        self.stat.render.size = (
            d[ok.RENDER_WIDTH].get_value(),
            d[ok.RENDER_HEIGHT].get_value()
        )

        self._update_wip()
        self.switch_ports()
        return self.do_accept_callback(self.wip)

    def do_cancel(self, *_):
        """
        Cancel the option edit.

        Return: true
            The key-press is handled.
        """
        # If the preview changed and the user canceled,
        # then delete any format group(s) in the render
        # because the format(s) are potentially invalid:
        if self._preview_steps != self.stat.render.preview_steps:
            self.stat.render.del_formats()

        self.switch_ports()
        return self.do_cancel_callback()

    def do_choice(self, g):
        """
        Open a choice window.

        g: RollerButton
            Was activated.
            to receive image reference
        """
        if not Port.loading:
            n = g.get_value()
            g.win = self.roller_window
            g.stat = self.stat

            g.choice_window(g)
            if n != g.get_value():
                a = g.option_group
                a.changed = True
                self.on_widget_change(g)

    def do_preview(self, g):
        """
        Draw a preview.

        g: RollerButton
            not in use
            from option group
        """
        self._update_wip()

        stat = self.stat
        a = g.option_group
        self.session = self._get_updated_session(option=self.wip)

        # Invalidate the previous preview.
        # It is about to be replaced:
        self._preview_steps = -1

        steps, self.session[sk.SESSION_OPT] = \
            self._opt.get_render_steps(self.session)

        if stat.render.has_layout_group:
            Lay.hide(stat.render.layout_group)

        stat.viewer.do(
            a.opt_type,
            a.opt_key,
            steps,
            self.session,
            is_preview=1
        )

        z = stat.render.image.layers[-1]
        z.name = z.name.split(":")[0] + ": Ready."

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        self._dependent_option = OptionDependent(
            self.roller_window,
            self.stat
        )
        q = self._draw_branch_group, self.draw_process_group

        for x, p in enumerate(q):
            if not x:
                g1 = gtk.HBox()
                g.add(g1)

            else:
                box = RollerEventBox(self.color)
                g1 = gtk.VBox()

                box.add(g1)
                g.add(box)

            p(g1)

            if not x:
                self._option_group_color = self.color
            self.reduce_color()

        self.return_widgets.append(self.branch.trunk.treeview)
        for i in self.branch.offshoot:
            self.return_widgets.append(i.widget)

    def make_option_group(self, g, nav_list, opt_type, opt_key):
        """
        Create an option group. An option group
        has widgets and is option-type-centric.

        g: GTK VBox
            for option group

        nav_list: NavigationList
            for OptionGroup

        opt_type: string
            one of three types: backdrop, format name, frame gradient
            for group-option identity

        opt_key: string
            either an image-effect or a backdrop-style

        Return: OptionGroup
            newly created
        """
        color = self.option_group_color

        g.add(
            RollerLabel(
                text=opt_key + " Options:",
                padding=(2, 0, 4, fw.MARGIN)
            )
        )

        self._vbox[(opt_type, opt_key)] = g
        option_group = OptionGroup(
            opt_type,
            opt_key,
            self._previous_option_group,
            nav_list
        )
        self.stat.option_group_dict[(opt_type, opt_key)] = option_group

        self._draw_option_group(
            g,
            opt_type,
            opt_key,
            option_group,
            color
        )

        self._previous_option_group = option_group
        return option_group

    @staticmethod
    def on_choice_change(g):
        """
        Set the tool tip for a choice list.

        g: RollerComboBox
            to receive tooltip
        """
        n = g.get_value()
        if n in Tip.OPTION_MAIN:
            g.set_tooltip_text(Tip.OPTION_MAIN[n])

    def on_widget_change(self, g):
        """
        Update the preview state and widget visibility.

        g: Widget
            Has changed.
        """
        if not Port.loading:
            a = g.option_group

            if hasattr(a, 'preset'):
                if a.preset and not isinstance(g, Preset):
                    a.preset.preset_is_undefined()

            if a.opt_key == ek.FRAME_GRADIENT:
                if g.key in a.widget_dict:
                    self._sync_frame_gradients(g, a)

            if g.key != ok.BUMP:
                # The steps following a changed
                # step are invalid, and thus changed:
                self._update_wip()

                self.session = self._get_updated_session(option=self.wip)
                steps = self._opt.get_render_steps(self.session)[0]
                d = self.stat.option_group_dict
                k = a.opt_type, a.opt_key
                if k in steps:
                    x = steps.index(k)
                    changed_steps = steps[x:]

                    for i, j in changed_steps:
                        group = d[(i, j)]
                        group.changed = True

                    # The backdrop-image is changed
                    # if the backdrop-style is changed:
                    option = changed_steps[0][ForStep.OPTION_KEY_INDEX]
                    if option in Option.BackdropStyle.names:
                        if option != bsk.BACKDROP_IMAGE:
                            d[ForStep.BACKDROP_IMAGE_STEP].changed = True

    def randomize_lists(self, g):
        """
        Randomize a list. The list is either of backdrop-style or image-effect.

        g: RollerButton
            Is responsible.
            Has OptionGroup.
        """
        Port.loading += 1
        opt_key = g.option_group.opt_key
        d = g.option_group.widget_dict
        e = {opt_key: ""}

        Base.random_option(e, opt_key, self.stat.option_limit.pure)

        for i in d:
            d[i].set_value(e[i])
        Port.loading -= 1

    def randomize_widgets(self, g):
        """
        Randomize the variables.

        g: RollerButton
            Has OptionGroup.
        """
        Port.loading += 1
        opt_key = g.option_group.opt_key
        d = g.option_group.preset.get_value()
        e = g.option_group.widget_dict

        Base.random_option(d, opt_key, self.stat.option_limit.pure)

        for i in e:
            e[i].set_value(d[i])

        Port.loading -= 1
        g.option_group.preset.preset_is_undefined()

        if g.option_group.opt_key != ek.FRAME_GRADIENT:
            self.on_widget_change(g)

        else:
            for i in e:
                self.on_widget_change(e[i])
