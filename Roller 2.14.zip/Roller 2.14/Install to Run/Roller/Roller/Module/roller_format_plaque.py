#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import RollerImage
from roller_image_effect_feather_reduction import FeatherReduction as fr
from roller_image_effect import LayerKey as nk
from roller_one import One
from roller_one_base import Base, Comm
from roller_one_constant import (
    CellKey,
    ForFormat as ff,
    ForGradient as fg,
    FormatKey as fk,
    ForLayout as fy,
    FreeCellKey as fck,
    OptionKey as ok,
    PlaceKey as pl,
    PlaqueKey as pq,
    SessionKey as sk
)
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
GRID = fk.Cell.Grid


class Plaque:
    """
    Manage Plaque operation.

    Require a backdrop image for Plaque's average color function.
    """

    def __init__(self, stat):
        """
        Add a cell plaque to the render.

        Not every cell has a plaque.

        stat: Stat
            globals
        """
        self.stat = stat

    def _blur_behind_cell(self, d, x):
        """
        Create a layer with the blur-behind material.

        If the blur-behind layer already exists, add the
        cell's blur-behind material to that layer.

        d: dict
            of format

        x: int
            format index in session's format list
        """
        j = self._render
        stat = self.stat
        blur_behind_layer = None
        self._merged = Form.is_merge_cells(d)
        name = d[fk.Layer.NAME]
        parent = stat.render.format_group(x, name)
        plaque_layer = Lay.search(parent, nk.CELL_PLAQUE, is_err=0)
        is_double = Form.is_double_space(d)
        if plaque_layer:
            cell = One(shape=d[GRID.CELL_GRID][GRID.SHAPE])
            row, col = stat.layout.get_division(x)

            Lay.hide_format_stack(stat, x)
            Lay.hide_layers_above(parent, plaque_layer)

            for r in range(row):
                for c in range(col):
                    go = 1

                    if is_double:
                        go = Form.is_double_space_cell(r, c, is_double)

                    if go:
                        cell.r, cell.c = r, c
                        e = cell.d = Form.get_cell_plaque(d, r, c)
                        go = Plaque.is_cell_plaque(
                            d,
                            cell,
                            is_double,
                            self._merged
                        )

                        if go:
                            go = blur = e[pq.BLUR_BEHIND]

                        if go:
                            if not self.stat.is_plaque_sel(name, r, c):
                                go = 0

                        if go:
                            if not blur_behind_layer:
                                pdb.gimp_selection_none(j)
                                pdb.gimp_edit_copy_visible(j)

                                z = blur_behind_layer = Lay.paste(
                                    j,
                                    plaque_layer
                                )
                                z.name = Lay.get_layer_name(
                                    nk.CELL_PLAQUE_BLUR_BEHIND,
                                    parent=parent
                                )
                                a = len(parent.layers) - 1
                                a -= int(
                                    Lay.search(
                                        parent,
                                        nk.LAYER_PLAQUE_BLUR_BEHIND,
                                        is_err=0
                                    ) is not None
                                )
                                pdb.gimp_image_reorder_item(j, z, parent, a)
                        if go:
                            Sel.load(
                                j,
                                stat.get_plaque_sel(name, r, c)
                            )
                            if Sel.is_sel(j):
                                Lay.blur(j, blur_behind_layer, blur)

            Lay.show_layer_on_top(parent, plaque_layer)
            Lay.show_format_groups(stat)
            pdb.gimp_selection_none(j)

            # Combine the plaque selections so the extra
            # material on the blur-behind layer can be cleared:
            for r in range(row):
                for c in range(col):
                    e = Form.get_cell_plaque(d, r, c)
                    cell = One(d=e, r=r, c=c)
                    go = e[pq.BLUR_BEHIND]

                    if go:
                        go = Plaque.is_cell_plaque(
                            d,
                            cell,
                            is_double,
                            self._merged
                        )
                    if go:
                        Sel.load(
                            j,
                            stat.get_plaque_sel(name, r, c),
                            option=fu.CHANNEL_OP_ADD
                        )
            if Sel.is_sel(j):
                Sel.clear_outside_of_selection(j, blur_behind_layer)

    def _blur_behind_free_cell(self, d, x):
        """
        Create a layer with the blur-behind material.

        If the blur-behind layer already exists, add the
        cell's blur=behind material to that layer.

        d: dict
            of format

        x: int
            format index
        """
        stat = self.stat
        j = stat.render.image
        blur_behind_layer = None
        r = fy.FREE_CELL
        parent = stat.render.format_group(x, d[fk.Layer.NAME])
        plaque_layer = Lay.search(parent, nk.FREE_CELL_PLAQUE, is_err=0)
        if plaque_layer:
            Lay.hide_format_stack(stat, x)
            Lay.hide_layers_above(parent, plaque_layer)

            for e in reversed(d[fk.Layer.CELL_LIST]):
                d1 = Form.get_cell_plaque(e, r, r)
                opacity = e[pq.CELL_PLAQUE][pq.OPACITY]
                _type = e[pq.CELL_PLAQUE][pq.TYPE]
                go = 1 if opacity and _type != ok.NONE else 0

                if go:
                    go = blur = d1[pq.BLUR_BEHIND]

                    if go:
                        name = e[fck.CELL][CellKey.NAME]
                        if not self.stat.is_plaque_sel(name, r, r):
                            go = 0

                    if go:
                        if not blur_behind_layer:
                            pdb.gimp_selection_none(j)
                            pdb.gimp_edit_copy_visible(j)

                            z = blur_behind_layer = Lay.paste(j, plaque_layer)
                            z.name = Lay.get_layer_name(
                                nk.FREE_CELL_PLAQUE_BLUR_BEHIND,
                                parent=parent
                            )
                            a = len(parent.layers) - 1
                            a -= int(
                                Lay.search(
                                    parent,
                                    nk.LAYER_PLAQUE_BLUR_BEHIND,
                                    is_err=0
                                ) is not None
                            )

                            if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                                a -= int(
                                    Lay.search(
                                        parent,
                                        nk.CELL_PLAQUE_BLUR_BEHIND,
                                        is_err=0
                                    ) is not None
                                )
                            pdb.gimp_image_reorder_item(j, z, parent, a)

                        Sel.load(
                            j,
                            stat.get_plaque_sel(name, r, r)
                        )
                        if Sel.is_sel(j):
                            Lay.blur(j, blur_behind_layer, blur)

            Lay.show_layer_on_top(parent, plaque_layer)
            Lay.show_format_groups(stat)
            pdb.gimp_selection_none(j)

            # Combine the plaque selections so the extra
            # material on the blur-behind layer can be cleared:
            for e in d[fk.Layer.CELL_LIST]:
                blur = e[pq.CELL_PLAQUE][pq.BLUR_BEHIND]
                if (
                    e[pq.CELL_PLAQUE][pq.OPACITY] and
                    e[pq.CELL_PLAQUE][pq.TYPE] != ok.NONE
                    and blur
                ):
                    Sel.load(
                        j,
                        stat.get_plaque_sel(e[fck.CELL][CellKey.NAME], r, r),
                        option=fu.CHANNEL_OP_ADD
                    )
            if Sel.is_sel(j):
                Sel.clear_outside_of_selection(j, blur_behind_layer)

    def _blur_behind_layer(self, d, x):
        """
        Create a layer with the blurred behind material.

        d: dict
            of format

        x: int
            format index
        """
        stat = self.stat
        j = stat.render.image
        name = d[fk.Layer.NAME]
        parent = stat.render.format_group(x, name)
        plaque_layer = Lay.search(parent, nk.LAYER_PLAQUE, is_err=0)
        e = d[pq.LAYER_PLAQUE]
        blur = e[pq.BLUR_BEHIND]
        if plaque_layer and blur:
            if self.stat.is_plaque_sel(name, fy.LAYER, fy.LAYER):
                Lay.hide_format_stack(stat, x)
                Lay.hide_layers_above(parent, plaque_layer)
                pdb.gimp_selection_none(j)
                pdb.gimp_edit_copy_visible(j)

                z = Lay.paste(j, plaque_layer)
                z.name = Lay.get_layer_name(
                    nk.LAYER_PLAQUE_BLUR_BEHIND,
                    parent=parent
                )

                pdb.gimp_image_reorder_item(
                    j,
                    z,
                    parent,
                    len(parent.layers) - 1
                )
                Sel.load(
                    j,
                    stat.get_plaque_sel(name, fy.LAYER, fy.LAYER)
                )
                if Sel.is_sel(j):
                    Lay.blur(j, z, blur)
                    Lay.show_layer_on_top(parent, plaque_layer)
                    Lay.show_format_groups(stat)
                    Sel.load(
                        j,
                        stat.get_plaque_sel(name, fy.LAYER, fy.LAYER)
                    )
                    if Sel.is_sel(j):
                        Sel.clear_outside_of_selection(j, z)

    def _do_average_color_plaque(self, z, cell, opacity):
        """
        Make an average color plaque.

        Exit with a selection to save.

        z: layer
            work-in-progress

        cell: One
            Has cell data.

        opacity: float
            for plaque layer

        Return: state of image
            selection
        """
        j = self._render

        if hasattr(cell, 'is_layer'):
            pdb.gimp_selection_none(j)
            RenderHub.copy_for_blur(
                j,
                z,
                self._parent,
                self.stat,
                self._format_x
            )
            j1 = 1

        else:
            j1 = cell.image

            if j1 and j1.j:
                pdb.gimp_edit_copy_visible(j1.j)

            else:
                j1 = None

        if j1:
            j1 = pdb.gimp_edit_paste_as_new_image()

            pdb.plug_in_pixelize2(
                j1,
                j1.layers[0],
                j1.width,
                j1.height,
            )
            Form.shape(j1, cell.w, cell.h)

        else:
            # There's no image, so use background.
            # Copy selection:
            Sel.rect(
                j,
                cell.x,
                cell.y,
                cell.w,
                cell.h,
                option=fu.CHANNEL_OP_REPLACE
            )
            pdb.gimp_edit_copy_visible(j)

            j1 = pdb.gimp_edit_paste_as_new_image()

            pdb.plug_in_pixelize2(
                j1,
                j1.layers[0],
                j1.width,
                j1.height
            )
            pdb.gimp_edit_copy_visible(j1)
            pdb.gimp_image_delete(j1)

        z = Lay.paste(j, z)

        pdb.gimp_layer_set_offsets(z, cell.x, cell.y)

        z = RenderHub.bump(j, z, cell.d[pq.BUMP], merge=1)
        z.opacity = opacity

        Sel.item(j, z)
        Form.select_shape(j, cell.plaque)
        Sel.clear_outside_of_selection(j, z, keep_sel=1)
        Plaque._feather(j, z, cell.d)

    def _do_cell(self, cell, r, c, name, _type, opacity):
        """
        The cell has a plaque.

        cell: One
            Has cell data.

        r, c: int
            row, column
            cell table index

        name: string
            a z-item name
            either a format or a free-range cell name

        _type: string
            a plaque descriptor

        opacity: float
            for plaque layer
        """
        j = self._render
        z = Lay.add(j, self._cell_name, parent=self._group)
        if _type in self._plaque_process:
            self._plaque_process[_type](z, cell, opacity)
            self.stat.save_plaque_sel(name, r, c)

    def _do_cells(self):
        """Do the plaque for the grid cells."""
        stat = self.stat
        layout = stat.layout
        d = self._form
        format_x = self._format_x
        j = self._render
        parent = self._parent
        row, col = layout.get_division(format_x)
        is_double = Form.is_double_space(d)
        is_merge = Form.is_merge_cells(d)

        for r in range(row):
            for c in range(col):
                go = 1

                if is_double:
                    go = Form.is_double_space_cell(r, c, is_double)
                if go:
                    cell = One(
                        r=r,
                        c=c,
                        shape=d[GRID.CELL_GRID][GRID.SHAPE]
                    )
                    rect = cell.cell = layout.get_merge_cell_rect(
                        format_x,
                        r,
                        c
                    )
                    cell.x, cell.y = rect.position
                    cell.w, cell.h = rect.size
                    e = cell.d = Form.get_cell_plaque(d, r, c)
                    go = Plaque.is_cell_plaque(
                        d,
                        cell,
                        is_double,
                        self._merged
                    )
                    if go:
                        j1 = layout.get_grid_image(
                            self.session,
                            d,
                            format_x,
                            r,
                            c,
                            is_merge
                        )
                        cell.image = j1
                        cell.plaque = layout.get_plaque(format_x, r, c)
                        opacity = e[pq.OPACITY]
                        _type = e[pq.TYPE]

                        if not self._group:
                            self._group = Lay.group(
                                j,
                                self._cell_name,
                                parent,
                                len(parent.layers)
                            )
                        self._do_cell(
                            cell,
                            r,
                            c,
                            d[fk.Layer.NAME],
                            _type,
                            opacity
                        )
                        RollerImage.close_image(j1)
        if self._group:
            Lay.merge_group(j, self._group, n=self._cell_name)
            self._group = None

    def _do_color_plaque(self, z, cell, opacity):
        """
        Make a image plaque.

        z: layer
            work-in-progress

        cell: One
            Has cell data.

        opacity: float
            for plaque layer

        Return: state of image
            a selection
        """
        j = self._render

        Form.select_shape(j, cell.plaque)
        Sel.fill(z, cell.d[pq.COLOR])
        Plaque._feather(j, z, cell.d)

        z = RenderHub.bump(j, z, cell.d[pq.BUMP], merge=1, stat=self.stat)
        z.opacity = opacity

    def _do_free_cell(self):
        """Do the plaque for the free-range cells in a format."""
        j = self._render
        parent = self._parent
        d = self._form
        stat = self.stat
        r = fy.FREE_CELL

        for e in reversed(d[fk.Layer.CELL_LIST]):
            opacity = e[pq.CELL_PLAQUE][pq.OPACITY]
            _type = e[pq.CELL_PLAQUE][pq.TYPE]
            go = 1 if opacity and _type != ok.NONE else 0
            if go:
                j1 = RollerImage.get_image(
                    self.session,
                    e[pl.IMAGE_PLACE][pl.IMAGE_DICT]
                )

                if not j1:
                    # Create a dummy to hold the 'cell':
                    j1 = RollerImage(None, "")
                if j1:
                    Form.prep_free_cell_image(j1, e, stat.render.size)

                    cell = One(
                        cell=j1.cell,
                        r=r,
                        c=r,
                        image=j1,
                        plaque=j1.plaque,
                        shape=e[fck.CELL][CellKey.SHAPE]
                    )
                    cell.w, cell.h = j1.cell.size
                    cell.x, cell.y = j1.cell.position
                    cell.d = Form.get_cell_plaque(e, r, r)

                    if not self._group:
                        a = len(parent.layers)
                        b = int(
                            Lay.search(
                                parent,
                                nk.LAYER_PLAQUE,
                                is_err=0
                            ) is not None
                        )
                        if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                            b += int(
                                Lay.search(
                                    parent,
                                    nk.CELL_PLAQUE,
                                    is_err=0
                                ) is not None
                            )
                        self._group = Lay.group(
                            j,
                            self._free_cell_name,
                            parent,
                            a - b
                        )

                    self._do_cell(
                        cell,
                        r,
                        r,
                        e[fck.CELL][CellKey.NAME],
                        _type,
                        opacity
                    )
                    RollerImage.close_image(j1)
        if self._group:
            Lay.merge_group(j, self._group, n=self._free_cell_name)
            self._group = None

    def _do_gradient_plaque(self, z, cell, opacity):
        """
        Make a gradient plaque.

        z: layer
            work-in-progress

        cell: One
            Has cell data.

        opacity: float
            for plaque layer

        Return: state of image
            a selection to save
        """
        def draw_gradient(_start_x, _end_x, _start_y, _end_y):
            pdb.gimp_drawable_edit_gradient_fill(
                z,
                fg.GRADIENT_TYPE_LIST.index(gradient_type),
                gf.OFFSET_0,
                gf.YES_SUPERSAMPLE,
                gf.SUPERSAMPLE_MAX_DEPTH_2,
                gf.SUPERSAMPLE_THRESHOLD_0,
                gf.YES_DITHER,
                _start_x,
                _start_y,
                _end_x,
                _end_y
            )

        j = self._render
        d = cell.d
        z1 = z
        gradient = d[pq.GRADIENT]

        if gradient not in self.stat.gradient_list:
            Comm.info_msg(
                ff.MISSING_ITEM.format("Plaque", "gradient", gradient)
            )

        else:
            x, y, w, h = cell.x, cell.y, cell.w, cell.h
            gradient_type = d[pq.GRADIENT_TYPE]
            gradient_angle = d[pq.GRADIENT_ANGLE]

            RenderHub.set_fill_context(fg.FILL_DICT)
            pdb.gimp_context_set_gradient(gradient)
            pdb.gimp_context_set_gradient_blend_color_space(
                fu.GRADIENT_BLEND_RGB_PERCEPTUAL
            )
            pdb.gimp_context_set_gradient_reverse(0)

            if gradient_type in fg.SHAPE_BURST:
                j1 = pdb.gimp_image_new(w, h, fu.RGB)
                z = Lay.add(j1, 'temp')

                pdb.gimp_selection_all(j1)
                Sel.fill(z, (127, 127, 127))
                pdb.gimp_selection_none(j1)
                draw_gradient(0, 0, 0, 0)
                pdb.gimp_edit_copy_visible(j1)
                pdb.gimp_image_delete(j1)

                z = Lay.paste(j, z1)
                pdb.gimp_layer_set_offsets(z, x, y)

            else:
                if gradient_angle in fg.CENTER_X:
                    end_x = start_x = (x + x + w) // 2

                elif gradient_angle in fg.LEFT_X:
                    start_x = x
                    end_x = x + w

                else:
                    start_x = x + w
                    end_x = x

                if gradient_angle in fg.MIDDLE_Y:
                    end_y = start_y = (y + y + h) // 2

                elif gradient_angle in fg.TOP_Y:
                    start_y = y
                    end_y = y + h

                else:
                    start_y = y + h
                    end_y = y

                Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
                draw_gradient(start_x, end_x, start_y, end_y)

            z = RenderHub.bump(j, z, cell.d[pq.BUMP], merge=True)
            z.opacity = opacity

            Form.select_shape(j, cell.plaque)
            Sel.clear_outside_of_selection(j, z, keep_sel=1)
            Plaque._feather(j, z, cell.d)

    def _do_image_plaque(self, z, cell, opacity):
        """
        Make a image plaque.

        z: layer
            work-in-progress

        cell: One
            Has cell image.

        opacity: float
            for plaque layer

        Return: state of image
            a selection to save
        """
        j = self._render

        pdb.gimp_selection_none(j)

        image = cell.d[pq.IMAGE]

        j1 = RollerImage.get_image(self.session, image)
        if j1:
            j2 = j1.j

            pdb.gimp_selection_none(j2)
            pdb.gimp_edit_copy_visible(j2)

            j2 = pdb.gimp_edit_paste_as_new_image()

            Form.shape(j2, cell.w, cell.h)

            z = Lay.paste(j, z)

            pdb.gimp_layer_set_offsets(z, cell.x, cell.y)
            Sel.item(j, z)

            z = RenderHub.bump(j, z, cell.d[pq.BUMP], merge=True)
            z.opacity = opacity

            Form.select_shape(j, cell.plaque)
            Sel.clear_outside_of_selection(j, z, keep_sel=1)
            Plaque._feather(j, z, cell.d)

    def _do_layer(self):
        """
        Add plaque layer.

        Is one per format.
        """
        j = self._render
        parent = self._parent
        stat = self.stat
        d = self._form
        cell = One(is_layer=1)
        size = self.session['size']
        e = cell.d = d[pq.LAYER_PLAQUE]

        if d[pq.LAYER_PLAQUE][pq.OBEY_MARGINS]:
            cell.y, bottom, cell.x, right = Form.get_layer_margin(d, size)
            cell.w = size[0] - cell.x - right
            cell.h = size[1] - cell.y - bottom

        else:
            cell.x = cell.y = 0
            cell.w, cell.h = size

        # Layer and cell plaques have the same order of plaque data:
        opacity = e[pq.OPACITY]
        _type = e[pq.TYPE]
        go = 1 if opacity and _type != ok.NONE else 0
        if go:
            w, h = cell.x + cell.w, cell.y + cell.h
            cell.plaque = cell.x, cell.y, w, cell.y, w, h, cell.x, h
            self._group = Lay.group(
                j,
                self._layer_name,
                parent,
                len(parent.layers)
            )
            if _type in self._plaque_process:
                z = Lay.add(j, self._layer_name, parent=self._group)

                self._plaque_process[_type](z, cell, opacity)

                Lay.merge_group(j, self._group, n=self._layer_name)
                self._group = None
                stat.save_plaque_sel(
                    d[fk.Layer.NAME],
                    fy.LAYER,
                    fy.LAYER
                )

    def _do_pattern_plaque(self, z, cell, opacity):
        """
        Make a pattern plaque.

        z: layer
            work-in-progress

        cell: One
            Has cell data.

        opacity: float
            for plaque layer

        Return: state of image
            a selection to save
        """
        pattern = cell.d[pq.PATTERN]
        if pattern in self.stat.pattern_list:
            j = self._render

            Form.select_shape(self._render, cell.plaque)
            RenderHub.set_fill_context(fg.FILL_DICT)
            pdb.gimp_context_set_pattern(pattern)
            pdb.gimp_drawable_edit_bucket_fill(
                z,
                fu.FILL_PATTERN,
                Base.seal(cell.x + cell.w // 2, 0, j.width),
                Base.seal(cell.y + cell.h // 2, 0, j.height)
            )
            Plaque._feather(j, z, cell.d)

            z = RenderHub.bump(
                j,
                z,
                cell.d[pq.BUMP],
                merge=1,
                stat=self.stat
            )
            z.opacity = opacity

        else:
            Comm.info_msg(ff.MISSING_ITEM.format("Plaque", "pattern", pattern))

    @staticmethod
    def _feather(j, z, d):
        """
        Feather the plaque selection.

        j: GIMP image
            work-in-progress

        d: dict
            Has feather option.
        """
        if d[pq.FEATHER]:
            fr.do(j, z, d)
            Sel.item(j, z)

    def blur_behind(self, session):
        """
        Blur behind cell and layer plaques.

        session: dict
            of session
        """
        self.session = session
        format_list = session[sk.FORMAT_LIST]
        for x in range(len(format_list) - 1, -1, -1):
            d = format_list[x]
            if not d[fk.Layer.CELL_LIST]:
                if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                    self._blur_behind_free_cell(d, x)

            self._blur_behind_layer(d, x)
            self._blur_behind_cell(d, x)
            if d[fk.Layer.CELL_LIST]:
                if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                    self._blur_behind_free_cell(d, x)

    def do(self, session, d, format_x):
        """
        Do the plaques for a format.

        session: dict
            of session

        d: dict
            of format

        format_x: int
            format index
        """
        self.session = session
        stat = self.stat
        self._format_x = format_x
        self._form = d
        self._render = stat.render.image
        parent = self._parent = stat.render.format_group(
            format_x,
            d[fk.Layer.NAME]
        )
        self._cell_name = Lay.get_layer_name(
            nk.CELL_PLAQUE,
            parent=parent
        )
        self._free_cell_name = Lay.get_layer_name(
            nk.FREE_CELL_PLAQUE,
            parent=parent
        )
        self._layer_name = Lay.get_layer_name(
            nk.LAYER_PLAQUE,
            parent=parent
        )
        self._format_x = format_x
        self._group = None
        self._merged = Form.is_merge_cells(d)

        self._plaque_process = {
            ff.Plaque.AVERAGE_COLOR: self._do_average_color_plaque,
            ff.Plaque.COLOR: self._do_color_plaque,
            ff.Plaque.IMAGE: self._do_image_plaque,
            ff.Plaque.GRADIENT: self._do_gradient_plaque,
            ff.Plaque.PATTERN: self._do_pattern_plaque
        }

        if d[fk.Layer.CELL_LIST]:
            if not d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                self._do_free_cell()

        self._do_cells()
        self._do_layer()
        if d[fk.Layer.CELL_LIST]:
            if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                self._do_free_cell()

    @staticmethod
    def is_cell_plaque(d, cell, is_double, merged):
        """
        Determine if the format's cell has a plaque.

        d: dict
            of format

        cell: One
            Has cell data.

        is_double: flag
            If its true, the cell shape is a hexagon or an ellipse.

        merged: flag
            Is true if merged cells is in effect.

        Return: flag
            Is true if the cell has a plaque.
        """
        e = cell.d
        opacity = e[pq.OPACITY]
        _type = e[pq.TYPE]
        go = 1 if opacity and _type != ok.NONE else 0

        if go:
            if merged:
                s = d[fk.Cell.Grid.PER_CELL][cell.r][cell.c]

            else:
                s = 1, 1
            go = 1 if s != (-1, -1) else 0

        if go:
            if is_double:
                if not Form.is_double_space_cell(cell.r, cell.c, is_double):
                    go = 0
        return go
