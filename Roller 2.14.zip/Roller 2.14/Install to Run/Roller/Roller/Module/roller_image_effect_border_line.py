#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerKey
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class BorderLine:
    """Create a metallic-like border around images."""

    def __init__(self, one, filler=None, framer=None):
        """
        Do the Border Line image-effect.

        one: One
            Has variables.

        filler: function
            Call to fill a frame.

        framer: function
            Call to add more frame.
        """
        stat = self.stat = one.stat
        self.option_key = one.k
        parent = self.parent = one.parent
        self.session = one.session
        d = one.d
        j = stat.render.image
        z1 = Lay.add(
            j,
            Lay.get_layer_name(LayerKey.FRAME, parent=parent),
            parent=parent,
            offset=Lay.offset(j, Lay.search(parent, LayerKey.IMAGE))
        )

        # Create embossed border:
        Lay.color_fill(z1, (255, 255, 255))

        z2 = Lay.selectable(
            j,
            stat.render.get_image_layer(
                Lay.get_format_name_from_group(parent)
            ),
            d
        )

        Sel.item(j, z2)

        image_sel = stat.save_render_sel()

        Sel.invert(j)

        if Sel.is_sel(j):
            Sel.invert(j)
            Sel.grow(j, d[ok.FRAME_WIDTH], d[ok.FRAME_TYPE])

            if filler:
                # Create filler and outer selections:
                sel = stat.save_render_sel()

                Sel.grow(j, d[ok.WIDTH], d[ok.FRAME_TYPE])
                Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
                Sel.grow(j, 1, d[ok.FRAME_TYPE])

                self.fill_sel = stat.save_render_sel()

                Sel.grow(
                    j,
                    max(int(d[ok.FRAME_WIDTH] / 3.5), 3),
                    d[ok.FRAME_TYPE]
                )
                Sel.load(j, self.fill_sel, option=fu.CHANNEL_OP_SUBTRACT)
                Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

            if framer:
                framer(d)

            Sel.load(j, image_sel, option=fu.CHANNEL_OP_SUBTRACT)

            sel = stat.save_render_sel()

            RenderHub.draw_sel(stat, sel, z1)
            RenderHub.emboss(j, z1, d[ok.LIGHT_ANGLE], 50)
            Sel.isolate(j, z1, sel)
            pdb.plug_in_antialias(j, z1)
            pdb.gimp_image_remove_layer(j, z2)

            z2 = BorderLine.add_bump_layer(j, z1, d, parent)

            Sel.isolate(j, z2, sel)
            if filler:
                filler(z2, d)

        else:
            # The layers are not appropriate:
            pdb.gimp_image_remove_layer(j, z1)
            pdb.gimp_image_remove_layer(j, z2)

    @staticmethod
    def add_bump_layer(j, z, d, parent):
        """
        Add a bump layer.

        j: GIMP image
            work-in-progress

        z: layer
            to clone from

        parent: layer
            format group

        d: dict
            Has options.
        """
        z = Lay.clone(j, z)

        RenderHub.add_noise(j, z, d)

        z.mode = fu.LAYER_MODE_HARDLIGHT
        z.name = Lay.get_layer_name(LayerKey.BUMP, parent=parent)
        z.opacity = d[ok.NOISE_OPACITY]
        return z
