#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_for import (
    Caption as pt, Issue as vo, Plan as fy, Signal as si
)
from roller_constant_key import (
    Item as ie,
    Material as ma,
    Node as ny,
    Option as ok,
    Plan as ak,
    SubMaya as sm
)
from roller_deco import finish_backed
from roller_deco_caption import (
    do_canvas,
    do_cell_main,
    do_cell_per,
    do_face_main,
    do_face_per,
    do_facing_main,
    do_facing_per
)
from roller_deco_strip import (
    do_canvas_strip,
    do_cell_main_strip,
    do_cell_per_strip,
    do_face_main_strip,
    do_face_per_strip,
    do_facing_main_strip,
    do_facing_per_strip
)
from roller_maya import (
    CanvasRoute,
    CellRoute,
    FaceRoute,
    ImageRoll,
    check_matter,
    check_mix_basic
)
from roller_maya_light import Light
from roller_maya_strip import Strip
from roller_maya_add import Add
from roller_one_helm import Helm
from roller_option_group import DecoGroup
from roller_view_real import make_canvas_group, make_cast_group
from roller_view_step import get_planner, make_model_key


def assign_image(maya, q):
    """
    Find assigned image for the "Image Name" Caption Type.

    maya: Maya
    q: list
        a Model's grid item list
        [(r, c) or (r, c, x), ...]
    """
    d = maya.value_d
    per = d[ok.PER]
    per_d = maya.per_d
    image_maya = get_image_maya(maya)
    image_d = image_maya.per_d if image_maya else None
    if d[ok.SWITCH] or per:
        for k in q:
            if k in per_d:
                # Per
                this_maya = per_d[k]
                e = per[k]

            else:
                # main
                this_maya = maya
                e = d

            if e[ok.TYPE] == pt.IMAGE_NAME:
                if image_maya:
                    maya_j = image_d[k] if k in image_d else image_maya
                    image = maya_j.get_image(k)

                    if image != this_maya.get_image(k):
                        this_maya.is_matter = True
                    this_maya.set_image(k, image)
            else:
                if this_maya.get_image(k):
                    # Switched type.
                    this_maya.is_matter = True
                this_maya.set_image(k, None)


def get_image_maya(maya):
    """
    Get the Image Maya for a Caption Cell.

    maya: Maya
    Return: Maya or None
        an Image type relative
    """
    # Canvas, Cell, Face Node position, '1'
    nav_k = make_model_key(maya.nav_k, (maya.nav_k[1], ie.IMAGE))

    any_group = Helm.get_group(nav_k)
    if any_group:
        return (any_group.plan, any_group.work)[Run.x]


class Caption(DecoGroup):
    """
    Create Widget group. Assign view run processor.
    Connect responsible signal handler.
    """

    def __init__(self, **d):
        DecoGroup.__init__(self, **d)

        node_k = self.nav_k[-2]
        self.plan = {
            ny.CANVAS: PlanCanvas,
            ny.CELL: PlanCell,
            ny.FACE: PlanFace,
            ny.FACING: PlanFacing
        }[node_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas,
            ny.CELL: WorkCell,
            ny.FACE: WorkFace,
            ny.FACING: WorkFacing
        }[node_k](self)
        if node_k in (ny.FACE, ny.FACING):
            self.latch(
                self.item.model.baby, (si.CELL_SHIFT_CALC, self.on_cell_calc)
            )


class Chi(ImageRoll):
    """Factor from Plan and Work."""

    def __init__(self, any_group, view_x, p, q):
        """
        any_group: AnyGroup
            owner

        view_x: int
            0 or 1; Plan or Work index

        p: function
            Make Strip material.

        q: iterable
            of function for producing output
        """
        ImageRoll.__init__(
            self,
            any_group,
            view_x,
            q,
            [
                (),
                (ok.RW1,),                  # Per vote dict's Font/Color
                (ok.RW1, ok.FONT),          # main's vote dict's Font position
                (ok.RW1, ok.MARGIN),
                (ok.LTR,),
                (ok.OCR,),
                (ok.BRW, ok.MOD)
            ]
        )
        self.set_issue()
        self.sub_maya[sm.STRIP] = Strip(
            any_group, self, view_x, p, (ok.BRW, ok.STRIP)
        )


class Plan(Chi):
    """Manage Plan layer output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, p):
        """
        any_group: AnyGroup
            owner

        p: function
            Make Strip material.
        """
        Chi.__init__(self, any_group, 0, p, self.put)

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.CAPTION)
        self.latch(
            planner, (fy.SIGNAL_D[ak.CAPTION], self.on_plan_option_change)
        )

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned

        if self.go:
            self.is_matter |= self.is_switched

        self.realize()
        if self.go:
            if self.matter:
                self.sub_maya[sm.STRIP].do(d, self.is_matter, False)
            else:
                self.die()

    def on_plan_option_change(self, _, arg):
        """Respond to change in PlanOption."""
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage Work layer output."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, p):
        """
        any_group: AnyGroup
            owner

        p: function
            Make Strip material.
        """
        Chi.__init__(self, any_group, 1, p, self.put)

        self.sub_maya[sm.ADD] = Add(any_group, self, (ok.BRW, ok.ADD))
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.CAPTION)

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d
        self.go = d[ok.SWITCH]
        is_back = Run.is_back

        self.realize()
        if self.go:
            if self.matter:
                self.sub_maya[sm.ADD].do(
                    d[ok.BRW][ok.ADD], self.is_matter, self.is_matter, is_back
                )
                finish_backed()
                self.sub_maya[sm.STRIP].do(d, self.is_matter, is_back)
                self.sub_maya[sm.LIGHT].do(self.is_matter)
            else:
                self.die()


class Main:
    """Identify the Maya as main."""
    vote_type = vo.MAIN

    def __init__(self):
        return


# Canvas_______________________________________________________________________
class Cloth:
    """Factor Plan and Work Canvas Maya."""

    def __init__(self):
        self.do_matter = do_canvas

    def prep(self):
        """Assign Image during a view run."""
        if self.value_d[ok.TYPE] == pt.IMAGE_NAME:
            j = get_image_maya(self).get_image(None)

            if j != self.get_image(None):
                self.is_matter = True
            self.set_image(None, j)
        else:
            self.set_image(None, None)


class PlanCanvas(Main, Plan, CanvasRoute, Cloth):
    """Manage Plan's Canvas/Caption layer output."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            owner
        """
        self.do_matter = do_canvas

        Main.__init__(self)
        Plan.__init__(self, any_group, do_canvas_strip)
        CanvasRoute.__init__(self)
        Cloth.__init__(self)


class WorkCanvas(Main, Work, CanvasRoute, Cloth):
    """Manage Work's Canvas/Caption layer output."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            owner
        """
        self.do_matter = do_canvas

        Main.__init__(self)
        Work.__init__(self, any_group, do_canvas_strip)
        CanvasRoute.__init__(self)
        Cloth.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:
    """Factor Plan and Work Cell Maya."""

    def __init__(self):
        self.do_matter = do_cell_main

    def prep(self):
        """Assign Image for a view run."""
        assign_image(self, self.model.cell_q)


class PlanCell(Main, Plan, CellRoute, Cellular):
    """Manage Plan Cell layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        self.do_matter = do_cell_main

        Main.__init__(self)
        Plan.__init__(self, any_group, do_cell_main_strip)
        CellRoute.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(Main, Work, CellRoute, Cellular):
    """Manage Work Cell layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        self.do_matter = do_cell_main

        Main.__init__(self)
        Work.__init__(self, any_group, do_cell_main_strip)
        CellRoute.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per__________________________________________________________________________
class Per:
    """Factor Plan and Work Per Maya."""
    vote_type = vo.PER

    def __init__(self, do_matter, k):
        self.do_matter = do_matter
        self.k = k
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Plan Cell/Per output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
        k: tuple
            (row, column); Goo key
        """
        Plan.__init__(self, any_group, do_cell_per_strip)
        Per.__init__(self, do_cell_per, k)


class WorkCellPer(Work, Per):
    """Manage Work Cell/Per output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
        k: tuple
            (row, column)
        """
        Work.__init__(self, any_group, do_cell_per_strip)
        Per.__init__(self, do_cell_per, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    """Factor Plan and Work Face Maya."""

    def __init__(self):
        self.do_matter = do_face_main

    def prep(self):
        """Assign image for Face/Caption."""
        assign_image(self, self.model.face_q)


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage Plan Face output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, do_face_main_strip)
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, Main, Work, FaceRoute):
    """Manage Work Face layer output for main."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            with Face options
        """
        Face.__init__(self)
        Main.__init__(self)
        Work.__init__(self, any_group, do_face_main_strip)
        FaceRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per Cell________________________________________________________________
class PlanFacePer(Plan, Per):
    """Manage Plan Face/Caption Per layer output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            owner

        k: tuple
            (row, column); cell index
        """
        Plan.__init__(self, any_group, do_face_per_strip)
        Per.__init__(self, do_face_per, k)


class WorkFacePer(Work, Per):
    """Manage Work/Face/Per output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            owner

        k: tuple
            (row, column); cell index
        """
        Work.__init__(self, any_group, do_face_per_strip)
        Per.__init__(self, do_face_per, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing_______________________________________________________________________
class Facing:
    """Factor Plan and Work Facing."""

    def __init__(self):
        self.do_matter = do_facing_main

    def prep(self):
        """Face/Caption needs to check the image assigned by Image Maya."""
        assign_image(self, self.model.face_q)


class PlanFacing(Facing, Main, Plan, FaceRoute):
    """Manage Plan Facing/Caption layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Facing.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, do_facing_main_strip)
        FaceRoute.__init__(self, PlanFacingPer)


class WorkFacing(Facing, Main, Work, FaceRoute):
    """Manage Work Facing/Caption layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Facing.__init__(self)
        Main.__init__(self)
        Work.__init__(self, any_group, do_facing_main_strip)
        FaceRoute.__init__(self, WorkFacingPer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing Per Cell______________________________________________________________
class FacingPer(Per):
    """Factor Plan and Work Facing/Caption Per Maya."""

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacingPer(Plan, FacingPer):
    """Manage Plan Facing/Caption Per."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c); cell index; of int; Goo key
        """
        Plan.__init__(self, any_group, do_facing_per_strip)
        FacingPer.__init__(self, do_facing_per, k)


class WorkFacingPer(Work, FacingPer):
    """Manage Work Facing/Caption/Per."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int; Goo key
        """
        Work.__init__(self, any_group, do_facing_per_strip)
        FacingPer.__init__(self, do_facing_per, k)
