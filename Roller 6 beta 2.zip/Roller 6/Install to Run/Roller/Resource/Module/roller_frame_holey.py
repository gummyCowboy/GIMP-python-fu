#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_constant_key import Material as ma, Option as ok
from roller_frame import do_embossed_frame
from roller_frame_alt import FrameBasic
from roller_fu import (
    add_layer,
    clear_selection,
    copy_all_image,
    create_image,
    select_ellipse
)
from roller_view_hub import (
    clipboard_fill, color_layer, set_fill_context_default
)


def do_matter(maya):
    """
    Make a frame.

    maya: Holey
    Return: layer
        Holey Wrap 'matter'
    """
    return do_embossed_frame(maya, make_pattern)


def make_pattern(z, d):
    """
    Draw circles on a layer. Create a pattern (a black circle). Use the
    clipboard to hold the pattern. Fill the provided layer with the pattern.

    z: layer
        to receive pattern

    d: dict
        Holey Preset
        {Option key: value}

    Return: layer
        work-in-progress
        Has material to select.
    """
    diameter = d[ok.CIRCLE_DIAMETER]
    w = diameter * 1.5
    h = w * .8660254
    j = create_image(int(w), int(h))
    z1 = add_layer(j, 'pattern')

    # A circle at the center of 'z1' will become a hole in the pattern.
    x = (w - diameter) // 2.
    y = (h - diameter) // 2.

    set_fill_context_default()
    color_layer(z1, (255, 255, 255))
    select_ellipse(j, x, y, diameter, diameter)
    pdb.gimp_selection_feather(j, 1.)
    clear_selection(z1)

    # Set the Clipboard Image.
    copy_all_image(j)

    pdb.gimp_image_delete(j)
    pdb.gimp_selection_none(z.image)
    clipboard_fill(z)
    return z


class Holey(FrameBasic):
    filler_k = ok.FILLER_HO
    material = ma.HOLEY
    wrap_k = ok.WRAP_PA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
