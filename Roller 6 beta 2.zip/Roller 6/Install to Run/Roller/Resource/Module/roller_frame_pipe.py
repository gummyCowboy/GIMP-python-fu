#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, CHANNEL_OP_SUBTRACT, pdb  # type: ignore
from roller_a_contain import Run
from roller_constant_for import Frame as ff
from roller_constant_key import Material as ma, Option as ok
from roller_frame import grow_frame
from roller_frame_alt import FrameOverlay
from roller_fu import load_selection, select_item
from roller_fu_mode import get_mode
from roller_view_hub import (
    ROUTE_PROFILE, color_layer, color_selection, set_fill_context_default
)
from roller_view_real import add_wip_layer, get_light


def do_overlay(maya):
    """
    Make a color layer.

    maya: Overlay
    Return: layer
        with color
    """
    pdb.gimp_selection_none(Run.j)

    d = maya.value_d
    z = add_wip_layer("Material", maya.group, offset=get_light(maya))

    color_layer(z, d[ok.COLOR_1])
    return z


def do_matter(maya):
    """
    Make a frame.

    maya: Pipe
    Return: layer or None
        Pipe Wrap 'matter'
    """
    d = maya.value_d
    z = add_wip_layer("Material", maya.group, offset=get_light(maya))
    w = d[ok.WIDTH]
    q = ROUTE_PROFILE[d[ok.PROFILE]](w)

    set_fill_context_default()
    select_item(maya.cast.matter)
    draw_profile(z, w, q)

    z.opacity = d[ok.OPACITY]
    z.mode = get_mode(d, k=ok.MODE)
    return z


def draw_profile(z, w, q):
    """
    Draw a color-type gradient frame using a profile.

    z: layer
        for blur material

    w: float
        width of border

    q: list
        of profile
        in .0 to 1.
    """
    j = z.image

    # selections
    a = b = None

    for i in range(int(w)):
        if a:
            # Do now to save memory for large frames.
            pdb.gimp_image_remove_channel(j, a)

        a = b = pdb.gimp_selection_save(j)
        if b:
            grow_frame(j, 1, ff.ANGULAR)
            load_selection(j, b, option=CHANNEL_OP_SUBTRACT)

            color = int(round(q[i] * 180.))

            color_selection(z, (color, color, color))
            load_selection(j, b, option=CHANNEL_OP_ADD)
    if b:
        pdb.gimp_image_remove_channel(j, b)


class Pipe(FrameOverlay):
    material = ma.PIPE
    overlay_k = ok.OVERLAY_CO
    shade_row = ok.RW1
    wrap_k = ok.WRAP_PI

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        FrameOverlay.__init__(
            self, any_group, super_maya, k_path, do_matter, do_overlay
        )
