#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Issue as vo
from roller_constant_key import Option as ok, SubMaya as sm
from roller_fu import layer_has_pixel
from roller_maya import check_matter, check_mix_basic
from roller_maya_add import AltAdd
from roller_maya_build import Build
from roller_view_real import get_light, insert_copy, make_group


def check_style_group(maya):
    """
    Create a Backdrop Style layer group if needed.

    maya: Maya
    Return: layer group
        the Backdrop Style group
    """
    if not maya.group:
        return make_group(
            "Style", maya.cast.group, offset=get_light(maya.cast)
        )
    return maya.group


def make_background(group):
    """
    Create a background layer for a Backdrop Style's base material.

    group: layer group
        Is the parent of the background layer.

    Return: layer
        base material for a Backdrop Style process
    """
    return insert_copy(group, group)


class Style(Build):
    """Factor Backdrop Style Maya."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (check_style_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )
    vote_type = vo.MAIN

    def __init__(self, any_group, cast_maya, k_path, do_matter):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
        k_path: iterable
            (Option key, ...)

        do_matter: function
            Call to make style layer.
        """
        Build.__init__(self, any_group, cast_maya, k_path, do_matter)

        path = ok.BRW, ok.ADD_ALT
        self.sub_maya[sm.ADD] = AltAdd(
            any_group,
            self,
            k_path + path if isinstance(k_path, tuple) else k_path[0] + path
        )

    def do(self, z, d, is_change):
        """
        Manage layer output for Backdrop Style during a view run.

        z: layer
            Backing layer

        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of Backing matter change.
            Replaces 'Run.is_back'.
        """
        self.value_d = d

        if not self.is_matter and self.is_dependent and is_change:
            self.is_matter = True

        self.go = True if not self.is_dependent else layer_has_pixel(z)

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(
                d[ok.BRW][ok.ADD_ALT],
                self.is_matter,
                self.is_matter,
                is_change
            )
        self.reset_issue()

    def rename_layer(self, z):
        """
        Name the layer output of the Backdrop Style.

        z: layer
            Backdrop Style output

        Return: layer or None
            material
        """
        if z and z.name != self.kind:
            z.name = self.kind
        return z

    def init_background(self, any_group, super_maya, k_path, make_style):
        """
        Call during init when a Backdrop Style has the
        Background option, 'ok.BRW'. Adjust the incoming
        key path so the Background option can count its vote.

        any_group: AnyGroup
        super_maya: Maya
        k_path: tuple
            (Option key, ...)
            Are paths to a sub-dictionary with additional vote.

        make_style: function
            Create a Backdrop Style layer.
        """
        self.is_seeded = self.is_dependent = True
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.RW1,),
                k_path + (ok.RW1, ok.MOD)
            ],
            make_style
        )
