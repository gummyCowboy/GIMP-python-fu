#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_for import Color as co, Signal as si
from roller_constant_key import Widget as wk
from roller_widget import Widget
import gtk  # type: ignore

CHOICE_COLOR = '#A8F8CF'


def get_treeview_item(treeview):
    """
    Return the item selected in a TreeViewList.

    treeview: TreeViewList
        Has list of item.

    Return: string or None
        item
    """
    n = None

    # GTK TreeSelection, 'a'
    a = treeview.get_selection()

    if a:
        model, iter_ = a.get_selected()
        if iter_:
            n = model.get_value(iter_, 0)
    return n


def rename_item(tree, x, n):
    tree.list_store.set_value(tree.list_store[x].iter, 0, n)


class TreeViewList(Widget):
    """
    Is base class for a Roller TreeView list Widget.

    Reference
    'scentric.net/tutorial/'
    """
    change_signal = 'cursor_changed'
    has_table_label = False

    def __init__(self, **d):
        """
        Create a TreeView list.

        d: dict
            Has init values.
        """
        # list of string equal to the visible tree values, 'item_q'
        self.item_q = d[wk.FUNCTION]() if wk.FUNCTION in d else []

        # for the cell
        self.background_color = d[wk.COLOR]

        g = self.treeview = gtk.TreeView()
        g.set_headers_visible = 0
        self.scrolled_window = gtk.ScrolledWindow() if wk.SCROLL in d else None

        if self.scrolled_window:
            self.scrolled_window.set_policy(
                gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC
            )
            self.scrolled_window.add(g)
            g = self.scrolled_window

        if wk.HEADER not in d:
            d[wk.HEADER] = ""

        if wk.MINIMUM_W not in d:
            d[wk.MINIMUM_W] = 1

        Widget.__init__(self, self.treeview, **d)

        self.list_store = gtk.ListStore(str, str, str)

        self.treeview.set_model(self.list_store)
        self.add(g)

        # Create a column.
        col = gtk.TreeViewColumn(
            d[wk.HEADER],
            gtk.CellRendererText(),
            text=0,
            foreground=1,
            background=2
        )

        col.set_min_width(d[wk.MINIMUM_W])

        # Add the column to the TreeView.
        self.treeview.append_column(col)

        if not d[wk.HEADER]:
            # Hide the column header with a dummy Label.
            col.set_widget(gtk.Label(""))

        # Modify the base color or the background color of the Treeview.
        #
        # Reference
        # mail.gnome.org/archives/gtk-app-devel-list/2015-June/msg00026.html
        # kksou.com/php-gtk2/sample-codes/set-the-background-color-of-GtkTreeView.php
        color = d[wk.TREE_COLOR]
        self.treeview.modify_base(
            gtk.STATE_NORMAL, gtk.gdk.Color(color, color, co.MAX_COLOR)
        )

    def append_item(self, n):
        """
        Add an item to the list.

        n: string
            item to add
        """
        self.list_store.append([n, '#000000', self.background_color])
        self.item_q.append(n)

    def get_a(self):
        """
        Get the selected item in the list.

        Return: string
            from the list selection
        """
        return get_treeview_item(self.treeview)

    def get_sel_row(self):
        """
        Determine the row index of the selected item.

        Return: int or None
            in 0 to n, where n is the length of the list minus one
        """
        x = iter_ = None

        # GTK TreeSelection, 'a'
        #
        # Reference
        # 'stackoverflow.com/questions/7938007/how-to-get-
        # value-from-selected-item-in-treeview-in-pygtk'
        a = self.treeview.get_selection()

        if a:
            # GtkTreeIter, 'iter_'
            iter_ = a.get_selected_rows()[1]

        if iter_:
            x = iter_[0][0]
        return x

    def get_item_x(self, n):
        """
        Match a descriptor to an item from the Node's item list.

        n: string
            item to match

        Return: int or None
            row index
        """
        for x, i in enumerate(self.item_q):
            if i == n:
                return x

    def get_branch(self, x):
        """
        Get the Item reference for a list index.

        x: int
            selection index into the Node item list

        Return: Item or None
        """
        if x < len(self.item_q):
            return self.item_q[x]

    def insert_row(self, x, n):
        """
        Insert a row into the TreeView and its item list.

        x: int
            index to row position

        n: string
            Insert this value.
        """
        list_store = self.list_store

        # item descriptor index, '0'
        # Create the row.
        list_store.set_value(list_store.insert(x), 0, n)

        # Set the background color.
        list_store[x] = [n, '#000000', self.background_color]

        # Update the easy access list.
        self.item_q.insert(x, n)

    def is_valid_selection(self, x):
        """
        Determine if a value is a valid selection.

        x: int or None
            a selection index

        Return: bool
            Is True when the selection value is valid.
        """
        if x is not None:
            if len(self.item_q) and len(self.item_q) >= x:
                return True
        return False

    def populate_item_q(self, q):
        """
        Populate the TreeView from a list.
        The previous indexed-list is replaced.

        q: list
            of string
        """
        self.reset()

        # Append items to the list.
        for n in q:
            self.append_item(n)

    def rename_item(self, x, n):
        """
        Change the name of an item in the TreeView and its item list.

        x: int
            index to row

        n: string
            new item name
        """
        rename_item(self, x, n)
        self.item_q[x] = n

    def remove_x(self, x):
        """
        Remove an item from the list using its index in the list.
        Is a get-item-index partner, so None is a valid 'x' value.

        x: int or None
            row number
        """
        if isinstance(x, int):
            r = self.list_store[x]

            self.item_q.pop(x)
            self.list_store.remove(r.iter)

    def reset(self):
        """
        Replace the ListStore with a new one as
        old one's iterator is probably used up.
        """
        # Replace "TreeView.ListStore's" iterator.
        self.item_q = []
        self.list_store = gtk.ListStore(str, str, str)
        self.treeview.set_model(self.list_store)

    def select_item(self, x):
        """
        Select a TreeView item.

        x: int
            row index in the TreeView
            0 to n
        """
        self.treeview.set_cursor(x)

        # GTK TreeSelection, 'selection'
        selection = self.treeview.get_selection()
        if selection:
            model, iter_ = selection.get_selected()
            if iter_:
                path = model.get_path(iter_)
                self.treeview.scroll_to_cell(path)

    def set_a(self, q):
        """
        Load the Treeview from a list.

        q: iterable
            of items to display in list
        """
        self.populate_item_q(q)


class ChoiceList(TreeViewList):
    """Is a Treeview composed of a list."""

    def __init__(self, **d):
        """
        Create a Treeview list. Use for when the value is a string.

        d: dict
            Initialize the Widget.
        """
        d[wk.COLOR] = CHOICE_COLOR
        d[wk.SCROLL] = 1

        TreeViewList.__init__(self, **d)
        self.populate_item_q(self.item_q)

        if wk.ANY_GROUP not in d:
            self.any_group = None

        else:
            self.any_group.connect(si.RANDOMIZE, self.randomize)

        # Select the previous choice for the user.
        x = self.item_q.index(d[wk.CHOICE]) \
            if d[wk.CHOICE] in self.item_q else 0

        self.treeview.set_cursor(x)

        # GTK TreeSelection, 'selection'
        selection = self.treeview.get_selection()
        model, iter_ = selection.get_selected()
        if iter_:
            path = model.get_path(iter_)
            self.treeview.scroll_to_cell(path)

    def randomize(self, *_):
        """Randomize a choice in the list."""
        if len(self.item_q) > 1:
            self.select_item(randint(0, len(self.item_q) - 1))
