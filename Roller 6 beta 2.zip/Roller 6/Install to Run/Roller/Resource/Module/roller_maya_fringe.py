#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_for import Issue as vo, Plan as fy, Signal as si
from roller_constant_key import (
    Material as ma, Node as ny, Option as ok, Plan as ak, SubMaya as sm
)
from roller_deco import finish_backed
from roller_deco_fringe import (
    do_canvas,
    do_cell_main,
    do_cell_per,
    do_face_main,
    do_face_per,
    do_facing_main,
    do_facing_per
)
from roller_maya import (
    Canvas,
    Cell,
    FaceRoute,
    Plasma,
    assign_image,
    check_matter,
    check_mix_basic,
    take_background_vote
)
from roller_maya_light import Light
from roller_maya_add import Add
from roller_option_group import DecoGroup
from roller_view_option_list import Frame
from roller_view_real import make_canvas_group, make_cast_group
from roller_view_step import get_planner


class Fringe(DecoGroup):
    """
    Create a Widget group. Assign a view run processor
    and connect responsible signal handler.
    """

    def __init__(self, **d):
        """
        d: dict
            Initialize the AnyGroup.
        """
        DecoGroup.__init__(self, **d)

        node_k = self.nav_k[-2]
        self.plan = {
            ny.CANVAS: PlanCanvas,
            ny.CELL: PlanCell,
            ny.FACE: PlanFace,
            ny.FACING: PlanFacing
        }[node_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas,
            ny.CELL: WorkCell,
            ny.FACE: WorkFace,
            ny.FACING: WorkFacing
        }[node_k](self)
        if node_k in (ny.FACE, ny.FACING):
            self.latch(
                self.item.model.baby, (si.CELL_SHIFT_CALC, self.on_cell_calc)
            )


class Chi(Plasma):
    """Factor Plan and Work."""

    def __init__(self, any_group, view_x, q):
        """
        view_x: int
            0 or 1; Plan or Work index

        q: iterable
            function for producing view run output
        """
        Plasma.__init__(
            self,
            any_group,
            view_x,
            q,
            [
                (),
                (ok.RW1, ok.MOD),
                (ok.RW1, ok.BRUSH_D),
                (ok.IMAGE_CHOICE,)
            ]
        )
        self.set_issue()


class Plan(Chi):
    """Manage Plan layer output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, self.put)

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.FRINGE)
        self.latch(
            planner, (fy.SIGNAL_D[ak.FRINGE], self.on_plan_option_change)
        )

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned

        if self.go:
            self.is_matter |= self.is_switched
        self.realize()

    def on_plan_option_change(self, _, arg):
        """
        Respond to change in Planner's Fringe option.

        _: Signal
        arg: tuple
            (bool, bool)
            (
                boolean state of the Fringe option,
                boolean state of the Fringe option since the last view run
            )
        """
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage Work layer output."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1, self.put)

        self.sub_maya[sm.ADD] = Add(any_group, self, (ok.BRW, ok.ADD))
        self.sub_maya[sm.FRAME] = Frame(any_group, self, (ok.BRW, ok.FRAME))
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.FRINGE)
        self.latch(any_group, (si.BACK_CHANGE, self.on_back_change))

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d
        self.go = self.value_d[ok.SWITCH]
        is_back = Run.is_back

        if self.go:
            self.is_matter |= take_background_vote(d)

        self.realize()
        if self.go:
            if self.matter:
                self.sub_maya[sm.ADD].do(
                    d[ok.BRW][ok.ADD], self.is_matter, self.is_matter, is_back
                )
                finish_backed()
                self.sub_maya[sm.FRAME].do(d[ok.BRW][ok.FRAME], self.is_matter)
                self.sub_maya[sm.LIGHT].do(self.is_matter)
            else:
                self.die()


class Main:
    """Identify the view step processor as being main."""
    vote_type = vo.MAIN

    def __init__(self):
        return


class WorkMain(Main, Work):
    """Factor Work's the main option settings."""

    def __init__(self, *arg):
        """
        arg: tuple
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *arg)


# Canvas_______________________________________________________________________
class Cloth:
    """Factor Plan and Work Canvas."""
    def __init__(self):
        self.do_matter = do_canvas


class PlanCanvas(Plan, Canvas, Main, Cloth):
    """Manage Plan/Canvas layer output."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Plan.__init__(self, any_group)
        Canvas.__init__(self)
        Main.__init__(self)
        Cloth.__init__(self)


class WorkCanvas(WorkMain, Canvas, Cloth):
    """Manage Work/Canvas layer output."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        WorkMain.__init__(self, any_group)
        Canvas.__init__(self)
        Cloth.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:
    """Manage Cell branch layer output."""
    is_face = False

    def __init__(self):
        self.do_matter = do_cell_main


class PlanCell(Plan, Cell, Main, Cellular):
    """Manage Plan/Cell layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Plan.__init__(self, any_group)
        Main.__init__(self)
        Cell.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, Cell, Cellular):
    """Manage Work/Cell layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            owner
        """
        WorkMain.__init__(self, any_group)
        Cell.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per__________________________________________________________________________
class Per:
    """Manage Per layer output."""
    vote_type = vo.PER

    def __init__(self, do_matter, k):
        self.do_matter = do_matter
        self.k = k
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Cell/Per layer output for Plan and Draft views."""
    is_face = False
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group)
        Per.__init__(self, do_cell_per, k)


class WorkCellPer(Work, Per):
    """Manage Cell/Per layer output for Peek, Preview, and render."""
    is_face = False
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group)
        Per.__init__(self, do_cell_per, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    """Manage Face layer output."""
    is_face = True

    def __init__(self):
        self.do_matter = do_face_main

    def prep(self):
        """With every view run, assign Image."""
        assign_image(self, self.model.face_q)


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage Plan/Face layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group)
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, FaceRoute):
    """Manage Work/Face layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            with Face options
        """
        Face.__init__(self)
        WorkMain.__init__(self, any_group)
        FaceRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per Cell________________________________________________________________
class FacePer(Per):
    """Manage Work/Face/Per layer output."""
    is_face = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacePer(Plan, FacePer):
    """Manage Plan/Face/Per layer output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        k: tuple
            (row, column, face)
        """
        Plan.__init__(self, any_group)
        FacePer.__init__(self, do_face_per, k)


class WorkFacePer(Work, FacePer):
    """Manage Work/Face/Per layer output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (row, column, face)
        """
        Work.__init__(self, any_group)
        FacePer.__init__(self, do_face_per, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing_______________________________________________________________________
class Facing:
    """Factor Plan and Work Facing."""
    is_face = False

    def __init__(self):
        self.do_matter = do_facing_main

    def prep(self):
        """During every view run, assign Image."""
        assign_image(self, self.model.face_q)


class PlanFacing(Facing, Main, Plan, FaceRoute):
    """Manage Plan/Facing layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Facing.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group)
        FaceRoute.__init__(self, PlanFacingPer)


class WorkFacing(Facing, WorkMain, FaceRoute):
    """Manage Work/Facing layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Facing.__init__(self)
        WorkMain.__init__(self, any_group)
        FaceRoute.__init__(self, WorkFacingPer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing Per Cell______________________________________________________________
class FacingPer(Per):
    """Factor Plan and Work Facing/Per."""
    is_face = False

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacingPer(Plan, FacingPer):
    """Manage Plan/Facing/Per output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group)
        FacingPer.__init__(self, do_facing_per, k)


class WorkFacingPer(Work, FacingPer):
    """Manage Work/Facing/Per output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group)
        FacingPer.__init__(self, do_facing_per, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
