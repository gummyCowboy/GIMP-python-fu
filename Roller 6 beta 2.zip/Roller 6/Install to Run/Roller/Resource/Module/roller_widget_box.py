#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color as co
from roller_constant_key import Widget as wk
import gtk  # type: ignore

# {Widget key: value}
DEFAULT_ATTR = {
    wk.ALIGN: (0, 0, 0, 0),
    wk.BOX: gtk.VBox,
    wk.PADDING: (0, 0, 0, 0)
}


class Box(gtk.Alignment):
    """
    This is a GTK Box widget with an GTK Alignment. Import as 'boxer'.
    """

    def __init__(self, **d):
        """
        Create a Box Widget container.

        keys:
            box_type: class
                either VBox, HBox, VButtonBox, HButtonBox

            align: tuple
                of float
                top, bottom, left, right
                Alignment
                in .0 to 1.

            padding: tuple of int
                top, bottom, left, right
        """
        super(gtk.Alignment, self).__init__()

        # Insure Box attribute.
        for k in DEFAULT_ATTR:
            a = d[k] if k in d else DEFAULT_ATTR[k]
            setattr(self, k, a)

        self.box = self.box()

        self.set(*self.align)
        self.set_padding(*self.padding)
        super(gtk.Alignment, self).add(self.box)

    def add(self, g):
        """
        Add a Widget to the Box.

        g: GTK widget
            Add to Box.
        """
        self.box.add(g)

    def get_children(self):
        return self.box.get_children()

    def pack_start(self, g, **d):
        """
        Place a Widget in the Box.

        g: GTK widget
            Is packed into this container.

        d: dict
            keyword options
        """
        self.box.pack_start(g, **d)


class Eventful(gtk.EventBox):
    """Is a GTK EventBox with a color option."""

    def __init__(self, color):
        """
        color: None, int, tuple, or GTK color
            Is the background color for a container.
        """
        super(gtk.EventBox, self).__init__()

        self.color = color
        if color is not None:
            if isinstance(color, int):
                q = gtk.gdk.Color(color, color, co.MAX_COLOR)

            elif isinstance(color, tuple):
                q = gtk.gdk.Color(*color)

            else:
                q = color
            self.modify_bg(gtk.STATE_NORMAL, q)


class ColorHBox(Eventful):
    """Is a GTK HBox with a color background."""

    def __init__(self, color):
        """
        color: GTK color
            Is the background color for the HBox.
        """
        Eventful.__init__(self, color)

        self.hbox = gtk.HBox()
        super(Eventful, self).add(self.hbox)

    def add(self, widget):
        """
        Add an object to the GTK Hbox.

        widget: object
            Add to the HBox.
        """
        self.hbox.add(widget)

    def pack_start(self, g, **kwarg):
        """
        Connect to the HBox function.

        g: object
            Is packed.

        kwarg: dict
            for the VBox function
        """
        self.hbox.pack_start(g, **kwarg)


class ColorVBox(Eventful):
    """Is a GTK VBox with a color background."""

    def __init__(self, color):
        """
        color: GTK color
            Is the background color for the HBox.

        is_node: bool
            Is true when the container is for a Node.
        """
        Eventful.__init__(self, color)

        self.vbox = gtk.VBox()
        super(Eventful, self).add(self.vbox)

    def add(self, widget):
        """
        Add an object to the GTK Hbox.

        widget: object
            Add to the HBox.
        """
        self.vbox.add(widget)

    def pack_end(self, g, **kwarg):
        """
        Connect to the VBox function.

        g: object
            Is packed.

        kwarg: dict
            for the VBox function
        """
        self.vbox.pack_end(g, **kwarg)

    def pack_start(self, g, **kwarg):
        """
        Provide a connection to the VBox function.

        g: object
            Is packed.

        kwarg: dict
            for the VBox function
        """
        self.vbox.pack_start(g, **kwarg)
