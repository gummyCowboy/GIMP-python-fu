#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, LAYER_MODE_HARDLIGHT, pdb  # type: ignore
from roller_a_contain import Globe, Run
from roller_a_gegl import noise_rgb, video_degradation, waterpixels
from roller_constant_for import Frame as ff
from roller_constant_key import Material as ma, Option as ok
from roller_frame import do_embossed_wrap
from roller_frame_alt import FrameOverlay
from roller_fu import adjust_saturation, clone_layer, select_item
from roller_view_hub import color_selection_default
from roller_view_real import add_wip_layer, get_light


def do_overlay(maya):
    """
    Make an overlay layer from waterpixels.

    maya: Overlay
    Return: layer
        overlay
    """
    pdb.gimp_selection_none(Run.j)

    d = maya.value_d
    z = add_wip_layer("Material", maya.group, offset=get_light(maya))
    noise = int(d[ok.SEED] + Globe.seed)

    for i in range(3):
        q = ff.COMPONENT[d[ok.CAMO_TYPE]] + (noise + i,)
        noise_rgb(z, *q)

    waterpixels(z)
    pdb.gimp_brightness_contrast(z, 0, 75)
    adjust_saturation(z, d)
    return z


def do_matter(maya):
    """
    Make a frame.

    maya: Camo
    Return: layer
        Wrap output
    """
    z = do_embossed_wrap(maya)
    z = clone_layer(z)

    select_item(z)
    color_selection_default(z, (127, 127, 127))

    # Curves won't work with a selection.
    pdb.gimp_selection_none(Run.j)

    video_degradation(z, 'dots')
    pdb.gimp_drawable_curves_spline(
        z,
        0,                          # HISTOGRAM_VALUE, '0'
        4,                          # four coordinates
        (.0, .2, 1., .8)
    )

    z.mode = LAYER_MODE_HARDLIGHT
    z.opacity = 65.
    return pdb.gimp_image_merge_down(Run.j, z, CLIP_TO_IMAGE)


class Camo(FrameOverlay):
    add_row = shade_row = ok.RW1
    is_seeded = True
    material = ma.CAMO
    overlay_k = ok.OVERLAY_CA
    wrap_k = ok.WRAP_AB

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Option key,)
            Is the key path to the responsible Frame Button.
        """
        FrameOverlay.__init__(
            self, any_group, super_maya, k_path, do_matter, do_overlay
        )
