#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import Color as co, Signal as si, Widget as fw
from roller_constant_key import (
    Button as bk, Material as ma, Option as ok, Widget as wk
)
from roller_def_access import get_default_value
from roller_def_act import get_mode_name_list
from roller_option_preset import Preset
from roller_port_choice import PortChoice
from roller_port_remove import PortRemove
from roller_widget_box import Eventful
from roller_widget_button import MakeMaterialButton, RemoveButton
from roller_widget_combo import ComboBox
from roller_widget_label import Label
from roller_widget_row import WidgetRow
from roller_widget_slider import RandomSlider
from roller_widget_table import get_darker_color
import gtk      # type: ignore


class HeatTable(gtk.Alignment, object):
    """Modify Heat option. """

    def __init__(self, **d):
        super(gtk.Alignment, self).__init__()
        self.set(0, 0, 1, 1)

        d[wk.ANY_GROUP].widget_d = {}
        self.roller_win = d[wk.ROLLER_WIN]
        self._widget_d = OrderedDict()
        self._hbox_d = {}
        self._size_group_q = []
        self._mode_d = \
            self._make_g = \
            self._remove_g = \
            self._opacity_d = \
            self._row_color = \
            self._scroll_window = \
            self._material_vbox = None
        color = self._make_heat_table(**d)

        self._make_preset_table(color, **d)
        self._validate_remove_button()

    def _add_box_q(self, box_q, k=None):
        """
        Create an Hbox for a HeatRow.

        box_q: list
            [Eventful] x 3

        k: string or None
            Material key
            Own the HBox.
        """
        hbox = gtk.HBox()

        if k:
            self._hbox_d[k] = hbox

        for i in box_q:
            hbox.pack_start(i)
        self._material_vbox.pack_start(hbox)

    def _make_eventful(self):
        return [Eventful(self._row_color) for _ in range(3)]

    def _make_heat_table(self, **d):
        """
        Create an empty GTK Table.

        d: dict
            Initialize the Table.
        """
        w = fw.MARGIN
        color = d[wk.COLOR]
        e = get_default_value(ok.HEAT)
        row = len(e) + 1
        key_q = e.keys()
        self._opacity_d = {
            wk.LIMIT: (.0, 100.), wk.PRECISION: 1, wk.RANDOM_Q: (.0, 100.)
        }
        self._mode_d = {wk.FUNCTION: get_mode_name_list}
        self._material_vbox = gtk.VBox()

        self._opacity_d.update(d)
        self._mode_d.update(d)
        self.set_padding(0, 0, w, w)

        color = get_darker_color(color, row)
        self._row_color = color, color, co.MAX_COLOR

        # column count, '3'
        for i in range(3):
            self._size_group_q.append(gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH))

        for r in range(row):
            box_q = self._make_eventful()

            if r == 0:
                # Table header
                g = gtk.Label("\t\t\tMode\t\t\t")
                g1 = gtk.Label("Opacity")

                box_q[1].add(g)
                box_q[2].add(g1)
                self._size_group_q[1].add_widget(g)
                self._size_group_q[2].add_widget(g1)

            else:
                # Material option
                k = key_q[r - 1]
                self._widget_d[k] = HeatRow(
                    k, box_q, self._mode_d, self._opacity_d, self._size_group_q
                )
            self._add_box_q(box_q)

        self.add(self._material_vbox)

        self._scroll_window = gtk.ScrolledWindow()

        self._scroll_window.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        self._scroll_window.add_with_viewport(self)
        d[wk.ITEM].vbox.add(self._scroll_window)
        return color

    def _make_material(self, k):
        """
        Make a material HBox.

        k: string
            Material key
        """
        box_q = self._make_eventful()
        self._widget_d[k] = HeatRow(
            k, box_q, self._mode_d, self._opacity_d, self._size_group_q
        )

        self._widget_d[k].mode.set_a("Normal")
        self._add_box_q(box_q, k=k)
        self._material_vbox.show_all()
        self._validate_remove_button()

    def _make_preset_table(self, color1, **d):
        """
        Create a GTK Table for Heat Preset Buttons.

        color1: tuple
            GIMP color
            'color' is in 'd'.

        d: dict
            Has init value.
        """
        alignment = gtk.Alignment(0, 0, 1, 1)
        color1 = get_darker_color(color1, 2)

        alignment.set_padding(0, 0, fw.MARGIN, fw.MARGIN)

        # row count, '2'; column count, '2'
        self._table = gtk.Table(2, 2)

        self._table.set_row_spacings(1)

        # Life-cycle Buttons
        # WidgetRow init dict, 'd1'
        d1 = {}

        d1.update(d)
        d1.update(
            {wk.SUB: OrderedDict([
                (bk.MAKE, {
                    wk.DIALOG: PortChoice,
                    wk.GET_A: self.get_make_material_list,
                    wk.WIDGET: MakeMaterialButton
                }),
                (bk.REMOVE, {
                    wk.DIALOG: PortRemove,
                    wk.GET_A: self.get_remove_material_list,
                    wk.WIDGET: RemoveButton
                })
            ])}
        )

        widget_row = WidgetRow(**d1)
        box_q = [Eventful(color1) for _ in range(2)]

        box_q[1].add(widget_row)
        self._table.attach(box_q[0], 0, 1, 0, 1)
        self._table.attach(box_q[1], 1, 2, 0, 1)

        # Preset Buttons
        color1 = get_darker_color(color1, 2)
        box_q = [Eventful(color1) for _ in range(2)]
        e = dict(d, key=ok.PRESET)
        self._preset = d[wk.ANY_GROUP].widget_d[ok.PRESET] = Preset(**e)

        box_q[0].add(gtk.Label("Heat Preset"))
        box_q[1].add(self._preset)
        self._table.attach(box_q[0], 0, 1, 1, 2)
        self._table.attach(box_q[1], 1, 2, 1, 2)
        alignment.add(self._table)
        d[wk.ITEM].vbox.add(alignment)

        self._make_g = widget_row.get_g(bk.MAKE)
        self._remove_g = widget_row.get_g(bk.REMOVE)

        self._make_g.connect(si.MAKE_MATERIAL, self.on_make_material)
        self._remove_g.connect(si.REMOVE_MATERIAL, self.on_remove_material)
        self._remove_g.connect(si.VALIDATE, self._validate_remove_button)

    def _update_scroll_window_size(self):
        """
        Hard coding the size request because I was
        unable to get allocation value from GTK.
        """
        r = min(6, len(self._hbox_d) + 1)
        self._scroll_window.set_size_request(500, r * 30)

    def _validate_remove_button(self, *_):
        """
        The Remove Button is valid if there are two or more materials.
        """
        g = self._remove_g
        if g:
            g.enable() if len(self._hbox_d) else g.disable()

    def get_a(self):
        """
        Fetch the value of the Heat Table.

        Return: dict
            Heat value
        """
        d = OrderedDict()

        # Material key, 'k'; HeatRow, 'a'
        for k, a in self._widget_d.items():
            d[k] = a.get_a()
        return d

    def get_make_material_list(self):
        """
        Fetch a list of possible new Heat Material.

        Return: list
            [Material key, ...]
        """
        return [i for i in ma.KEY_Q if i not in self._widget_d.keys()]

    def get_remove_material_list(self):
        """
        Fetch a list of active Heat Material.
        The Backdrop material is not removable.

        Return: list
            [Material key, ...]
        """
        q = self._widget_d.keys()

        q.pop(q.index(ma.BACKDROP))
        return q

    def on_make_material(self, sender, k):
        """
        Respond to an accept action from a make material dialog.

        sender: MakeMaterialButton
        k: string
            Material key or None
        """
        if k:
            self._make_material(k)
            self._update_scroll_window_size()

    def on_remove_material(self, sender, q):
        """
        Remove material not in a list.

        sender: MakeMaterialButton
        q: list
            [Material key, ...]
            Material that is not deleted.
        """
        q1 = self._widget_d.keys()

        # Don't remove Backdrop.
        q1.pop(q1.index("Backdrop"))

        # Remove items that are not in the 'q' list.
        for k in q1:
            if k not in q:
                hbox = self._hbox_d.get(k)
                if hbox:
                    self._hbox_d.pop(k)
                    hbox.parent.remove(hbox)
                    if k in self._widget_d:
                        self._widget_d.pop(k)
        self.roller_win.resize()

    def set_a(self, d):
        """
        Set the value of the Heat Table.

        d: dict
            Heat Preset value
        """
        e = self._widget_d

        for k, a in d.items():
            if k not in e:
                self._make_material(k)
            e[k].set_a(a)
        self._update_scroll_window_size()


class HeatRow:
    """Make a Row having a Paint Mode and an Opacity Widget."""

    def __init__(self, k, box_q, mode_d, opacity_d, size_group):
        """
        Create a Paint Mode and an Opacity Widget and add them to Eventful.

        k: string
            Material key

        box_q: list
            of Eventful for adding the Mode and Opacity options

        mode_d: dict
            Is the Mode Widget's init dict.

        opacity_d: dict
            Is the Opacity Widget's init dict.

        size_group: list
            [gtk.SizeGroup] x 3
            Make Widget the same size.
        """
        w = fw.MARGIN
        label = Label(text=k.split(",")[0])
        self.mode = ComboBox(**mode_d)
        self.opacity = RandomSlider(**opacity_d)

        box_q[0].add(label)
        box_q[1].add(self.mode)
        box_q[2].add(self.opacity)
        label.set_padding(0, 0, 0, w)
        self.mode.set_padding(0, 0, w, 0)
        for x, g in enumerate((label, self.mode, self.opacity)):
            size_group[x].add_widget(g)

    def get_a(self):
        """
        Return the value of the HeatRow Widget.

        Return: dict
            HeatRow value
        """
        return {
            ok.MODE: self.mode.get_a(),
            ok.OPACITY: self.opacity.get_a()
        }

    def set_a(self, d):
        """
        Set the value of the HeatRow Widget.

        d: dict
            HeatRow value
        """
        if isinstance(d, dict):
            self.mode.set_a(d[ok.MODE])
            self.opacity.set_a(d[ok.OPACITY])
