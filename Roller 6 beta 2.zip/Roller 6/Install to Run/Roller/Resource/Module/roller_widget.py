#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Widget as wk
from roller_widget_voter import Voter
import gtk  # type: ignore

# Are Widget type that accept a Return key for the Accept function.
RETURNABLE = (
    gtk.CheckButton,
    gtk.Entry,
    gtk.HScale,
    gtk.RadioButton,
    gtk.ScrolledWindow,
    gtk.SpinButton,
    gtk.ToggleButton,
    gtk.TreeView
)


def set_widget_attr(g, d):
    """
    Create Widget attribute from filtered keyword.

    g: Widget or object
        Receive attribute.

    d: dict
        Has keyword.
    """
    for i in wk.ATTRIBUTE:
        if i in d:
            setattr(g, i, d[i])


class Widget(gtk.Alignment, Voter, object):
    """
    Is a 'new-style' class with a super class 'gtk.Alignment'.
    Has widget-factored functions and attributes. Sub-Widget classes
    need to init the Widget class before connecting a signal.
    """

    def __init__(self, g, **d):
        """
        g: sub-widget
            of sub-class

        d: dict
            Has init values.
        """
        # Need in Python 2 but not in Python 3.
        # Reference
        #   stackoverflow.com/questions/17509846/
        #   python-super-arguments-why-not-superobj
        super(gtk.Alignment, self).__init__()

        self.align = 0, 0, 1, 1
        self.widget = g
        self.box = self.key = self.label = self.label_box = None

        for i in (wk.ANY_GROUP, wk.ROW_KEY):
            if i not in d:
                d[i] = None

        set_widget_attr(self, d)
        self.relay = d[wk.RELAY][:] if wk.RELAY in d else None
        Voter.__init__(self, **d)
        self.set(*self.align)

        if self.any_group:
            self.latch(self.any_group, (si.DISAPPEAR, self.on_disappear))

        if wk.PADDING in d:
            self.set_padding(*d[wk.PADDING])

        if wk.TOOLTIP in d:
            g.set_tooltip_text(d[wk.TOOLTIP])

        a = self.change_signal
        if a:
            self.latch(g, ('key_press_event', self.on_key_press))
            if isinstance(a, tuple):
                for i in a:
                    self.latch(g, (i, self.on_widget_change))
            else:
                self.latch(g, (a, self.on_widget_change))

    def disable(self, *_):
        """Make the Widget inoperable."""
        self.set_sensitive(0)

    def enable(self, *_):
        """
        Make the Widget operational.

        _: tuple
            not used
        """
        self.set_sensitive(1)

    def get_sensitive(self):
        """
        Get the Widget's sensitivity. Call the Widget's GDK
        function. Override the 'gtk.Alignment' super-class.

        Return: int
            of sensitivity
            0 or 1
        """
        return self.widget.get_sensitive()

    def hide(self):
        """Hide the Widget and its attached Label."""
        if self.box:
            self.box.hide()

        else:
            self.widget.hide()

        if self.label_box:
            self.label_box.hide()
        elif self.label:
            self.label.widget.hide()

    def on_key_press(self, g, a):
        """
        Respond to a keypress event.

        g: Widget
            Is responsible.

        a: gtk.Event
            a keypress

        Return: None or True
            Is True if the keypress is handled.
        """
        if g.get_visible():
            n = gtk.gdk.keyval_name(a.keyval)

            if n == 'Escape':
                self.roller_win.emit(si.CANCEL_WINDOW, self)
                return True

            if n == 'Return':
                if type(g) in RETURNABLE:
                    self.roller_win.emit(si.ACCEPT_WINDOW, self)
                    return True
            if n in ('P', 'p'):
                if a.state & gtk.gdk.CONTROL_MASK:
                    self.roller_win.emit(si.PREVIEW, self)
                    return True

    def on_widget_change(self, *_):
        """
        Call each function in the relay on Widget change.

        Return: True
            Tell GTK that the signal is handled.
        """
        for i in self.relay:
            i(self)
        return True

    def set_sensitive(self, a):
        """
        Set the Widget's sensitivity. Call the Widget's
        GDK function. Override the 'gtk.Alignment' super-class.

        a: int
            sensitivity
            0 or 1
        """
        self.widget.set_sensitive(a)

    def set_tooltip_text(self, tooltip):
        """
        Set the Widget's tooltip.

        tooltip: string
            Apply to the Widget.
        """
        self.widget.set_tooltip_text(tooltip)

    def show(self):
        """Show the Widget, its attached Label, and its background EventBox."""
        # Eventful, 'box'
        if self.box:
            self.box.show()

        else:
            self.widget.show()

        if self.label_box:
            self.label_box.show()
        elif self.label:
            self.label.widget.show()
