#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_a_contain import The
from roller_constant_for import Signal as si, Widget as fw
from roller_constant_key import Button as bk, Option as ok, Widget as wk
from roller_one_ring import Ring
from roller_widget import set_widget_attr
from roller_widget_box import Box as boxer
from roller_widget_button import Button
from roller_widget_row import WidgetRow
from roller_widget_tree import CHOICE_COLOR, TreeViewList
import gtk  # type: ignore

INIT_ROW_ITEM = "Row: {}, Column: 1"
NEW_ROW_ITEM = "Row: {}, Column: {}"
ROW_Q = ["Row: 1, Column: 1"]


class RowList(gtk.Alignment, object):
    """Display a TreeView and TreeView item manipulation Buttons."""
    change_signal = None
    has_table_label = False

    def __init__(self, **d):
        # Use to return focus to a responsible Button.
        self.widget = None

        self.view_value = [None, None]
        self._list_buttons = []
        self.dialog = self._row_count_g = None
        d[wk.SCROLL] = d[wk.CHANGELESS] = True
        w = fw.MARGIN // 2
        self.issue = d[wk.ISSUE]

        super(gtk.Alignment, self).__init__()
        set_widget_attr(self, d)

        relay = d[wk.RELAY][:]
        hbox = gtk.HBox()

        hbox.add(gtk.Label("\n" * 6))

        # WidgetRow keyword arguments, 'e'
        e = {}

        e.update(d)

        # container for the Table Widget, 'vbox'
        vbox = boxer(padding=(0, w, 0, w))

        d.update({wk.COLOR: CHOICE_COLOR, wk.MINIMUM_W: 70})

        self._row_tree = TreeViewList(**d)

        hbox.add(self._row_tree)
        vbox.add(gtk.Label("Column Per Row List:"))
        vbox.add(hbox)

        e[wk.RELAY] = relay

        e.update(
            {wk.SUB: OrderedDict([
                (bk.ADD_COLUMN, {
                    wk.CHANGELESS: True,
                    wk.TEXT: bk.ADD_COLUMN,
                    wk.WIDGET: Button
                }),
                (bk.SUBTRACT_COLUMN, {
                    wk.CHANGELESS: True,
                    wk.TEXT: bk.SUBTRACT_COLUMN,
                    wk.WIDGET: Button
                })
            ])}
        )

        widget_row = WidgetRow(**e)
        self._add_column_g = widget_row.get_g(bk.ADD_COLUMN)
        self._subtract_column_g = widget_row.get_g(bk.SUBTRACT_COLUMN)

        vbox.add(widget_row)
        self.add(vbox)

        # Connect event.
        self._row_tree.treeview.get_selection().connect(
            'changed', self.on_row_tree_list_change
        )
        self._add_column_g.relay.insert(0, self.on_add_column_action)
        self._subtract_column_g.relay.insert(0, self.on_subtract_column_action)
        Ring.gob.connect(si.ROW_COUNT_CHANGE, self.on_row_count_change)
        self._row_tree.set_a(ROW_Q)
        self.on_row_tree_list_change()

    def append_row(self):
        """Add an item to the RowList."""
        self._row_tree.append_item(
            INIT_ROW_ITEM.format(len(self._row_tree.item_q) + 1)
        )

    def get_a(self):
        """
        Get the condensed value of the RowList.

        Return: list
            [column count, ...]
            The column count corresponds with a zero-based row index.
        """
        return [int(i.split(" ")[-1]) for i in self._row_tree.item_q]

    def on_add_column_action(self, _):
        """
        Add an item to the RowList.

        _: Button
            not used
        """
        q = self._row_tree.item_q
        x = self._row_tree.get_sel_row()
        if x is not None:
            n = q[x]
            a = min(100, int(n.split(" ")[-1]) + 1)

            self._row_tree.rename_item(x, NEW_ROW_ITEM.format(x + 1, a))
            self.update_any_group()
            self.on_row_tree_list_change()

    def on_subtract_column_action(self, _):
        """
        Reduce the value of the column count for the selected RowList item.

        _: Button
            not used
        """
        q = self._row_tree.item_q
        x = self._row_tree.get_sel_row()
        if x is not None:
            n = q[x]
            a = max(1, int(n.split(" ")[-1]) - 1)

            self._row_tree.rename_item(x, NEW_ROW_ITEM.format(x + 1, a))
            self.update_any_group()
            self.on_row_tree_list_change()

    def on_row_count_change(self, signal, g):
        """
        Respond to change in the RowCountSlider. Adjust RowList
        value to correspond with the row count widget value. Verify
        that the signal is sent by the RowCountSlider in the
        same AnyGroup (a partner).

        signal: Signal
            row count changed

        g: RowCountSlider
            Is responsible. Is not necessarily a partner.
        """
        if not self._row_count_g:
            self._row_count_g = self.any_group.widget_d.get(ok.ROW_COUNT)
        if not The.load_count and self._row_count_g and g == self._row_count_g:
            q = self._row_tree.item_q

            # current row count, 'a'
            a = len(q) if q else 0

            # requested row count, 'b'
            b = int(g.get_a())

            if a > b:
                q = q[:b]
                self._row_tree.set_a(q)

            elif a < b:
                for i in range(b - a):
                    self.append_row()
            if a != b:
                self.update_any_group()

    def set_a(self, q):
        """
        Translate a list of column count into a RowList value.
        Update the AnyGroup's value dict and have the AnyGroup
        cast the RowList's vote.

        q: list
            [column count]
            The column count corresponds with a zero-based row index.
        """
        if q:
            self._row_tree.reset()
            for x, i in enumerate(q):
                self._row_tree.append_item(NEW_ROW_ITEM.format(x + 1, i))
            self.update_any_group()

    def set_view_value(self, x, _):
        """
        ModelList remembers its parent Node value as its
        state is used to detect background change by Model Maya.

        x: int
            Plan or Work index; 0 or 1

        _: dict
            ModelList value
            not used
        """
        self.view_value[x] = self.get_a()

    def update_any_group(self):
        """Update the AnyGroup's value dict and cast a change vote."""
        # RowList's condensed value, 'a'
        a = self.get_a()

        for x in range(2):
            self.any_group.cast_vote(
                x, self.key, self.issue, a != self.view_value[x]
            )
        self.any_group.update_option_a(self.key, a)

    def on_row_tree_list_change(self, *_):
        """
        Verify the Buttons dependent on a list selection and column count.
        """
        x = self._row_tree.get_sel_row()

        if x is None:
            self._add_column_g.set_sensitive(0)
            self._subtract_column_g.set_sensitive(0)
        else:
            a = int(self._row_tree.get_a().split(" ")[-1])

            self._subtract_column_g.set_sensitive(int(a > 1))
            self._add_column_g.set_sensitive(int(a < 100))
