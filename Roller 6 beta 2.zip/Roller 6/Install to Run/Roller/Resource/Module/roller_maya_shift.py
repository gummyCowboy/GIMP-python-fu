#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_for import Issue as vo, Signal as si
from roller_constant_key import Node as ny, Option as ok
from roller_maya import Runner
from roller_one_ring import Ring
from roller_option_group import ModelGroup
from roller_view_step import find_canvas_margin, find_cell_margin


class Shift(ModelGroup):
    """
    Create a Shift Preset Widget group. Assign view run
    processor for the step and connect signal handler.
    """

    def __init__(self, **d):
        ModelGroup.__init__(self, **d)

        self._is_cell = False
        node_k = self.nav_k[-2]
        self.plan = {ny.CANVAS: PlanCanvas, ny.CELL: PlanCell}[node_k](self)
        self.work = {ny.CANVAS: WorkCanvas, ny.CELL: WorkCell}[node_k](self)

        if node_k == ny.CELL:
            self._is_cell = True
            self._sequence_signal = si.CELL_SHIFT_CHANGE

            self.latch(
                self.item.model.baby, (si.CELL_RECT_CALC, self.on_cell_calc)
            )
            self.latch(
                self.widget_d[ok.PER], (si.PER_CHANGE, self.update_model)
            )

        elif node_k == ny.CANVAS:
            # Canvas hook
            self._sequence_signal = si.CANVAS_SHIFT_CHANGE
            self.latch(Ring.gob, (si.RESIZE, self.on_sequence))

        self.latch(self.booth, (si.VOTE_CHANGE, self.update_model))
        self.latch(self, (si.SEQUENCE, self.on_sequence))

    def do(self):
        """
        Override the AnyGroup function so that Past's view Signal can be sent.
        """
        super(Shift, self).do()

        p = self.item.model.past.emit

        if self._is_cell:
            p(si.CELL_SHIFT_VIEW, Run.x)

            # Adapt to a missing Cell/Margin step.
            if not find_cell_margin(self.nav_k):
                p(si.CELL_MARGIN_VIEW, Run.x)
        else:
            p(si.CANVAS_SHIFT_VIEW, Run.x)

            # Adapt to a missing Canvas/Margin step.
            if not find_canvas_margin(self.nav_k):
                p(si.CANVAS_MARGIN_VIEW, Run.x)

    def on_sequence(self, _, arg):
        """
        Update the Model pronto.

        _: AnyGroup
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
            not used
        """
        self.item.model.baby.feed(self._sequence_signal, (self.value_d, True))

    def update_model(self, *_):
        """Update the Model as time permits."""
        self.item.model.baby.give(self._sequence_signal, (self.value_d, False))


# Chi__________________________________________________________________________
class Chi(Runner):
    """Factor Plan and Work."""
    issue_q = 'matter',

    def __init__(self, any_group, view_x):
        Runner.__init__(self, any_group, view_x, (), ())
        self.set_issue()

    def prep(self):
        """For every view, there is an image, but not for Shift."""
        return

    def dig(self):
        self.reset_issue()


class Plan(Chi):
    """Shift has no layer output. Is part of the AnyGroup template."""

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0)


class Work(Chi):
    """Shift has no layer output. Is part of the AnyGroup template."""

    def __init__(self, any_group):
        """
        Canvas and Cell Work.

        q: iterable
            output function
        """
        Chi.__init__(self, any_group, 1)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Canvas_______________________________________________________________________
class PlanCanvas(Plan):
    """Shift has no layer output. Is part of the AnyGroup template."""
    vote_type = vo.MAIN

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Plan.__init__(self, any_group)


class WorkCanvas(Work):
    """Shift has no layer output. Is part of the AnyGroup template."""
    vote_type = vo.MAIN

    def __init__(self, any_group):
        """
        any_group: AnyGroup
        """
        Work.__init__(self, any_group)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class PlanCell(Plan):
    """Shift has no layer output. Is part of the AnyGroup template."""
    issue_q = 'matter', 'per'
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Plan.__init__(self, any_group)


class WorkCell(Work):
    """Shift has no layer output. Is part of the AnyGroup template."""
    issue_q = 'matter', 'per'
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Work.__init__(self, any_group)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
