#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Globe, Run
from roller_constant_for import Issue as vo, Signal as si
from roller_constant_key import Option as ok
from roller_option_group import ManyGroup
from roller_maya import Maya
from roller_one_ring import Ring
from roller_one_render import Render
from roller_view_real import make_plan_group


def check_view_image(maya):
    """
    Process view image size change.

    maya: Maya
    Return: None
    """
    if maya.is_matter:
        w, h = Globe.view_size
        w1, h1 = (Run.j.width, Run.j.height) if Run.j else (0, 0)
        if w != w1 or h != h1:
            Render.new_image(w, h)
            Ring.pressure()


class Global(ManyGroup):
    """Assign view run processor and connect responsible signal handler."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)
        d = self.widget_d

        # Insert responder into the relay.
        for k, p in (
            (ok.AZIMUTH, self.on_emboss_change),
            (ok.ELEVATION, self.on_emboss_change),
            (ok.HIDE_LAYER, self.on_hide_layer_change),
            (ok.RENDER_W, self.on_view_size_change),
            (ok.RENDER_H, self.on_view_size_change),
            (ok.SEED, self.on_seed_change),
            (ok.WIP, self.on_view_size_change)
        ):
            d[k].relay.insert(0, p)
            p(d[k])

    def on_emboss_change(self, g):
        """
        Respond to change in an emboss type Widget.

        g: Widget
            Is responsible.
            not used
        """
        g, g1 = self.widget_d[ok.ELEVATION], self.widget_d[ok.AZIMUTH]
        a = Globe.elevation = g.get_a()
        b = Globe.azimuth = g1.get_a()
        Ring.plug(
            si.GLOBAL_EMBOSS,
            (
                a != g.view_value[0] or b != g1.view_value[0],
                b != g.view_value[1] or b != g1.view_value[1]
            )
        )

    def on_hide_layer_change(self, g):
        """
        Store the setting for Work and Plan.

        g: CheckButton
            Hide Layer
        """
        Globe.hide_layer = g.get_a()

    def on_seed_change(self, g):
        """
        Respond to change in the Global seed Widget.

        g: Widget
            Roller type
            Is responsible.
            not used
        """
        g = self.widget_d[ok.SEED]
        a = Globe.seed = g.get_a()
        Ring.plug(
            si.GLOBAL_SEED,
            (a != g.view_value[0], a != g.view_value[1]))

    def on_view_size_change(self, g):
        """
        Respond to a view image size option value change.

        g: Widget
            Has changed.
            not used
        """
        g, g1 = self.widget_d[ok.RENDER_W], self.widget_d[ok.RENDER_H]
        g2 = self.widget_d[ok.WIP]
        a = g2.get_a()
        w, h = g.get_a(), g1.get_a()
        Ring.plug(
            si.RESIZE,
            [
                (
                    w != g.view_value[0] or
                    h != g1.view_value[0] or
                    a != g2.view_value[0]
                ),
                (
                    w != g.view_value[1] or
                    h != g1.view_value[1] or
                    a != g2.view_value[1]
                )
            ]
        )


class Chi(Maya):
    """Factor Plan and Work Maya."""
    issue_q = 'matter',
    vote_type = vo.MAIN

    def __init__(self, any_group, view_x, put):
        Maya.__init__(self, any_group, view_x, put, ())
        self.set_issue()

    def do(self):
        """
        Return: None
            for undo
        """
        self.realize_vote()


class Plan(Chi):
    """Manage Draft and Plan response to Global option."""
    put = (check_view_image, 'matter'), (make_plan_group, 'group')

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, Plan.put)


class Work(Chi):
    """Manage Peek, Preview, and render response to Global option."""
    put = (check_view_image, 'matter'),

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1, Work.put)
