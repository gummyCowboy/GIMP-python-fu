#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Mask as ms
from roller_constant_key import Item as ie, Option as ok
from roller_port_preview import PortPreview
from roller_widget_node import Piece


class PortMask(PortPreview):
    """Is a display container for the Mask Preset."""
    window_key = "Mask"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_mask_option(self, box):
        """
        Draw the Mask option group.

        box: VBox
            container for the option group
        """
        group = self.repo.any_group
        self.draw_group(Piece(ok.MASK, box, group.item, has_label=False))
        if group.render_key[-2] in (ie.FACE, ie.FACING):
            # Face and Facing have limited Mask Type.
            g = self.any_group.widget_d[ok.TYPE]
            n = g.get_a()

            g.populate_list(ms.FACE_TYPE)
            g.set_a(n)

    def draw(self):
        """
        Draw Widget.

        g: VBox
            container for Widgets
        """
        self.draw_column((self._draw_mask_option, self.draw_process))

    def get_group_value(self):
        """
        Get the Preset value.

        Return: dict
            Mask Preset
        """
        return self.preset.get_a()
