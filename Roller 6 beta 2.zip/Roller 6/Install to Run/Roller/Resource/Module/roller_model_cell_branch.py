#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Option as ok
from roller_many_rect import Rect
from roller_one_ring import Ring
from roller_one_wip import Wip, get_factor
from roller_model import CellPast, Model, CELL_CHAIN


class CellBranch(Model):
    """The Model has only a Cell-branch."""

    def __init__(self, model_name):
        """
        model_name: string
            Identify the model.
        """
        Model.__init__(self, model_name, CellPast, CELL_CHAIN)

        self.rectangle = .0, .0, .0, .0

        self.latch(self.baby, (si.RECTANGLE_CHANGE, self.on_rectangle_change))
        self.latch(Ring.gob, (si.RESIZE, self.on_resize))
        self.on_resize(None, None)

    def on_rectangle_change(self, _, arg):
        """
        Update the Cell's rectangle.

        _: Model
            Sent the signal.

        arg: tuple
            (Rectangle Preset, is sequence flag)
        """
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        x, y, w, h = Wip.get_rect()
        self.rectangle = (
            # position x, y
            x + get_factor(d[ok.POSITION_X], w),
            y + get_factor(d[ok.POSITION_Y], h),

            # size w, h
            max(1., get_factor(d[ok.CELL_W], w)),
            max(1., get_factor(d[ok.CELL_H], h))
        )
        p(
            si.RECTANGLE_CALC, self.past.did_rectangle(self.rectangle)
        )

    def on_resize(self, _, arg):
        """
        Update the Cell's default Canvas setting on a render resize event.

        _: Ring
            Sent the Signal.

        arg: list
            Plan and Work vote.
            not used
        """
        self.canvas_rect = Wip.get_rect()
        self.canvas_pocket = Rect(*self.canvas_rect)

    def update_type(self, arg):
        """
        Update the Model's Cell/Type dependency.

        arg: tuple
            (Cell Type Preset, is sequence flag)
            {Option key: value}
            A sequence is processed immediately.
        """
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        self.cell_shape = d[ok.CELL_SHAPE]
        vote_d = super(CellBranch, self).update_type(arg)

        self.adapt_missing_cell_step(is_sequence)
        p(si.CELL_RECT_CALC, vote_d)
