#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color as co, Signal as si, Widget as fw
from roller_constant_key import Option as ok, Step as sk, Widget as wk
from roller_view_step import make_panel_key
from roller_one_helm import Helm
from roller_one_ring import Ring
from roller_widget import set_widget_attr
from roller_widget_label import Label
from roller_widget_tree import TreeViewList, rename_item
import gtk      # type: ignore
import gobject  # type: ignore


def add_node_to_list(q):
    """
    Given a navigation step key list, add a Node navigation step key.

    q: list
        [step key]

    Return: list
        [step key] with Node step key
    """
    q1 = [sk.STEPS]
    get_group = Helm.get_group

    # step key, 'i'
    for i in q:
        if len(i) > 1:
            # Remove the last label from the step
            # key to make a Node step key, 'k'.
            k = i[:-1]
            a = get_group(k)
            if a and a.item.group_type == 'node':
                if k not in q1:
                    q1 += [k]
    return q + q1


def get_visibility(g):
    """
    Determine if a Node is in the selected navigation path.

    g: Node
        in question
    """
    def _get_item(_k):
        """
        Get
        """
        # Node, '_g'
        _g = get_group(_k).item.node
        _r = _g.get_sel_row()
        return _g.get_branch(0 if _r is None else _r).item

    if g.nav_k == sk.SHADOW:
        # The Shadow Node is always visible.
        return True

    # Get the selected item in the Steps Node.
    get_group = Helm.get_group
    item = _get_item(sk.STEPS)
    is_visible = True
    nav_k = g.nav_k
    panel_k = make_panel_key(nav_k)

    # Check each Node in the key to see if it is selected.
    for x, n in enumerate(panel_k):
        if n != item:
            # 'item' is selected. 'n' is not.
            is_visible = False
            break
        if x + 1 < len(panel_k):
            item = _get_item(nav_k[:x + 1])
    return is_visible


class Node(gtk.Alignment, gobject.GObject, object):
    """
    Is a list Widget of keyed item descriptor. A selected item
    displays a branch option group. A branch is either
    a Node or a leaf as in a Widget group. An item descriptor is part of
    a step key and is unique, like a key, in the Node list context.
    """
    has_table_label = False

    # Are signals that can be emitted by this class.
    __gsignals__ = si.NODE_D

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        super(gtk.Alignment, self).__init__()

        # Enable custom signal.
        gobject.GObject.__init__(self)

        set_widget_attr(self, d)

        # Is set during a SuperPreset load, 'self._selected_row'.
        self._selected_row = None

        d[wk.COLOR] = co.LIST_CELL_COLOR
        d[wk.PADDING] = 2, 2, fw.MARGIN, fw.MARGIN

        # The HBox is needed for the expose event.
        # The Item VBox's exposure is erratic.
        self.hbox = gtk.HBox()

        self._tree = TreeViewList(**d)
        self.treeview = self._tree.treeview

        self.hbox.add(self._tree)
        self.add(self.hbox)

        # The TreeView cursor-changed signal will send a signal
        # when a row is clicked even if the row is already selected.
        self._tree.treeview.connect('cursor_changed', self.update_on_change)

        self._tree.treeview.get_selection().connect(
            'changed', self.update_on_change
        )
        self.connect(si.SELECT_ITEM, self.on_select_item)
        Ring.gob.connect(si.RING_GONE, self.on_ring_gone)

    def get_a(self):
        """
        Get a dict with the selected row of the Node.

        Return: dict
            {tuple: int}
            {sk.SELECTED_ROW: selected row}
        """
        return {sk.SELECTED_ROW: self.get_sel_row()}

    def get_branch(self, x):
        """
        Get the Item reference for a list index.

        x: int
            selection index into the Node item list

        Return: Item or None
        """
        if x < len(self._tree.item_q):
            return self._tree.item_q[x]

    @staticmethod
    def get_init(*_):
        """
        Provide a dict and a list for group initialization.

        Return: dict
            Use during object init.
        """
        return {ok.NODE: {wk.CHANGELESS: True, wk.WIDGET: Node}}, [ok.NODE]

    def get_item_list(self):
        """
        Get a list of Item in the tree.

        Return: list
            [Item, ...]
        """
        return self._tree.item_q[:]

    def get_label_q(self):
        """
        Get a Item key list.

        Return: list
            [item key, ...]
        """
        return [i.item for i in self._tree.item_q]

    def get_named_item(self, n):
        """
        Get an Item from the Node's item list given its item descriptor.

        n: string
            item key to match
            Is not the Group key, but its split version.

        Return: Item or None
        """
        # Item list, 'q'
        q = self.get_item_list()
        for i in q:
            if i.item == n:
                return i

    def get_sel_row(self):
        """
        Fetch the selection row index for the TreeView.

        Return: int or None
            zero-based row number
        """
        x = self._tree.get_sel_row()

        if x is None:
            x = 0
        return x

    def insert_r(self, x, item):
        """
        Insert a row into the Node and its item list.

        x: int
            index to row

        item: Item
        """
        list_store = self._tree.list_store

        # item descriptor index, '0'
        # Create the row.
        list_store.set_value(list_store.insert(x), 0, item.item)

        # Set the background color.
        list_store[x] = [item.item, '#000000', co.LIST_CELL_COLOR]

        # Update the easy access list.
        self._tree.item_q.insert(x, item)

    def on_ring_gone(self, sender, arg):
        """
        Select a Node item.

        sender: Ring
            Sent the Signal.
        arg: None
        """
        if self._selected_row is not None:
            if self._selected_row < len(self._tree.item_q):
                if get_visibility(self):
                    self.select_row(self._selected_row)
                else:
                    # Turn off 'on_node_change' in the 'relay' so
                    # that it won't get called to display the Node.
                    relay = self._tree.relay
                    self._tree.relay = []

                    self.select_row(self._selected_row)
                    self._tree.relay = relay
            self._selected_row = None

    def on_select_item(self, sender, r):
        """
        Respond to a 'si.SELECT_ITEM'. Make Node
        selection if a Preset isn't loading.

        r: int
            row index
        """
        self._selected_row = r

    def rename_item(self, old_name, new_name):
        """
        Change the name of an item in the Node.

        x: int
            index to row

        n: string
            new item name
        """
        q = self.get_item_list()
        item_q = self._tree.item_q
        for x, i in enumerate(q):
            if i.item == old_name:
                rename_item(self._tree, x, new_name)
                for x1, item in enumerate(item_q):
                    if item.key == old_name:
                        item.key = item.item = new_name

    def remove_named_item(self, n):
        """
        Remove an item from the list.

        x: int
            row number
        """
        q = self.get_item_list()
        for x, i in enumerate(q):
            if i.item == n:
                self._tree.remove_x(x)
                break

    def repopulate(self, q):
        """
        Synchronize the order of a Node's branches with a list of strings.

        q: list
            Are Node branch names in the new order.
        """
        self._tree.reset()
        for x, i in enumerate(q):
            self.insert_r(x, i)

    def select_row(self, r):
        """
        Select an item in the Node based on its descriptor.

        r: int
            row index
        """
        if r < len(self._tree.item_q):
            # Proceed on valid row.
            self._tree.select_item(r)

    def set_view_value(self, x):
        return

    def sort_item_q(self, q):
        """
        Sort the order of a Node's item list.

        q: list
            of item key
        """
        # {Item.key: Item}
        d = {i.key: i for i in self._tree.item_q}
        keys = [i.key for i in self._tree.item_q]

        # Ensure that the two lists synchronized.
        if len(q) == len(keys):
            for x, i in enumerate(keys):
                n = q[x]
                if i != n:
                    self._tree.remove_x(x)
                    self.insert_r(x, d[n])

    def update_on_change(self, *_):
        """Update the option group with the change in selection."""
        self.any_group.update_node_a(self.get_a())


class Snitch:
    """Is a super class for an option group container."""

    def __init__(self, key, model):
        """
        string: key or None
            group key

        model: Model instance
            owner of the AnyGroup
        """
        self.is_per = False
        self.item = \
            self.node = \
            self.text = \
            self.vbox = \
            self.label = \
            self.any_group = \
            self.group_type = None
        self.key = key
        self.model = model


class Pit(Snitch):
    """Is a container for a NoneGroup item."""

    def __init__(self):
        Snitch.__init__(self, None, None)
        self.group_type = 'preset'


class Item(Snitch):
    """Is a container for a Node item."""

    def __init__(self, key, model, group_type, label=None, has_switch=False):
        """
        key: string
            Group or Node key

        model: Model
        group_type: string
            Is 'node', 'preset', or 'super_preset'.
        """
        Snitch.__init__(self, key, model)

        # a member of ('preset', 'node', 'super_preset'), 'group_type'
        self.group_type = group_type

        self.item = "" if isinstance(key, tuple) else key.split(",")[0]
        self.vbox = gtk.VBox()
        if not has_switch:
            # The Switch does not have a Label.
            text = self.item if label is None else label
            self.label = Label(
                text="{}".format(text),
                padding=(4, 4, 4, 4),
                expand=True
            )
            self.vbox.add(self.label)

    def rename(self, n):
        """
        Rename the item's key and item attributes.

        n: string
            key
        """
        self.key = n
        self.item = n.split(",")[0]


class Piece(Snitch):
    """
    Is a container for a Dialog group item. Has the same attributes as Item.
    """

    def __init__(
        self,
        key,
        container,
        item,
        group_type=None,
        has_label=True,
        is_per=False
    ):
        """
        Make a container for a dialog option group. Add
        the group's container to its parent container.
        Inherit recurring attribute from an Item or a Piece.

        key: string
            Group or Node key

        container: GTK container
            Is the container for the option group.

        item: Item
            Inherit pieces.

        group_type: string
            part of group identity

        has_label: bool
            If True, then the GTK VBox will have a label.

        is_per: bool
            ?
        """
        Snitch.__init__(self, key, item.model)

        self.node = item.node
        self.group_type = item.group_type if group_type is None else group_type
        self.item = key.split(",")[0]
        self.vbox = gtk.VBox()
        self.is_per = is_per

        if has_label:
            self.label = Label(
                text="{}".format(self.item),
                padding=(4, 4, 4, 4),
                expand=True
            )
            self.vbox.add(self.label)
        container.add(self.vbox)


class Dust(Snitch):
    """
    Is a container for a Dialog group item. Has
    the same attributes as Item, but has no values.
    """

    def __init__(self, key=None, model=None):
        Snitch.__init__(self, key, model)
        if key is not None:
            self.item = key.split(",")[0]


# Register the custom signals.
gobject.type_register(Node)
