#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_DARKEN_ONLY,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_MULTIPLY,
    pdb
)
from random import randint, uniform
from roller_a_contain import Run
from roller_a_gegl import waves
from roller_backdrop_color_grid import do_color_grid
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def_access import get_default_value
from roller_fu import (
    blur_selection,
    clone_layer,
    make_layer_group,
    merge_layer_group,
    select_color
)
from roller_maya_style import Style
from roller_one import random_rgb
from roller_one_wip import Wip
from roller_view_hub import color_selection, do_mod, prep_replace_color_default
from roller_view_preset import combine_seed
from roller_view_real import add_sub_base_group, insert_copy


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: GlassGaw
    Return: layer or None
        Glass Gaw output
    """
    def _do_grid(_merge):
        """
        Mix random grid overlays with waves.

        _merge: bool
            If it's true, the color grid layer
            is merged with the layer below.
        """
        def do_waves():
            """Do waves on a layer."""
            waves(_z, amplitude=uniform(1., 12.), period=uniform(24., w))

        e[ok.ROW] = randint(2, 6)
        e[ok.COLUMN] = randint(2, 6)
        _z = do_color_grid(e, group)

        select_color(_z, (255, 255, 255))
        color_selection(_z, random_rgb() + (255,))
        select_color(z, (0, 0, 0))
        color_selection(_z, random_rgb() + (255,))
        pdb.gimp_selection_none(j)

        _z.mode = LAYER_MODE_DIFFERENCE

        do_waves()

        if _merge:
            _z = pdb.gimp_image_merge_down(j, _z, CLIP_TO_IMAGE)
            do_waves()
        return _z

    def _make_group(_n):
        return make_layer_group(j, key + _n, parent=parent, z=z)

    j = Run.j
    d = maya.value_d
    e = get_default_value(by.COLOR_GRID)
    key = maya.any_group.item.key
    parent = add_sub_base_group(maya)
    z = insert_copy(parent, parent)
    group = _make_group(" Group 1 WIP")
    w = max(25., min(1000., Wip.w, Wip.h))

    prep_replace_color_default()
    combine_seed(d)

    for i in range(4):
        z1 = _do_grid(i != 0)
        z = clone_layer(z1, n="Grid " + str(i + 1))

    # edge amount, '1.'
    # no wrap, '0'
    # Sobel, '0'
    pdb.plug_in_edge(j, z, 1., 0, 0)

    z2 = clone_layer(z1, n="Difference")

    blur_selection(z2, 20)

    z2.mode = LAYER_MODE_DIFFERENCE
    z3 = clone_layer(z2, n="Difference 2")
    z3.mode = LAYER_MODE_DIFFERENCE
    z4 = clone_layer(z3, n="Grain Extract")
    z4.mode = LAYER_MODE_GRAIN_EXTRACT
    z.mode = LAYER_MODE_DARKEN_ONLY

    # no linear, '0'
    pdb.gimp_drawable_invert(z, 0)

    blur_selection(z, 4)
    pdb.plug_in_unsharp_mask(
        j, z1,
        3.,                     # radius
        .16,                    # amount
        .0                      # threshold
    )

    group1 = _make_group(" Group 2 WIP")

    for i in (z1, z3, z2, z4, z):
        pdb.gimp_image_reorder_item(j, i, group1, 0)

    z5 = clone_layer(z, n="Erode")

    for _ in range(2):
        pdb.plug_in_erode(
            j, z5,
            1,              # propagate black
            7,              # RGB channels
            1.,             # full rate
            7,              # direction mask
            0,              # lower limit
            128             # upper limit
        )

    blur_selection(z5, 90)
    j.remove_layer(group)

    z5.mode = LAYER_MODE_MULTIPLY

    z = merge_layer_group(parent)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class GlassGaw(Style):
    """Create Backdrop Style output."""
    is_dependent = False
    is_seeded = True

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.BRW, ok.MOD)],
            make_style
        )
