#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_a_contain import The
from roller_constant_for import Signal as si
import gobject  # type: ignore


class Ring(gobject.GObject, object):
    """
    Accept signal from object. Keep signal in an OrderedDict.
    Process signal when the interface is idle.

    The baby paradigm is inspired by a subscriber's dependency on Ring.
    """
    # Reference
    #   github.com/sebp/PyGObject-Tutorial/blob/master/source/objects.txt
    #   library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
    #   zetcode.com/gui/pygtk/signals/
    #   stackoverflow.com/questions/66730/how-do-i-create-a-new-signal-in-pygtk

    # Are signals that can be emitted by this class.
    __gsignals__ = si.POWER_D

    # Is a Ring instance for the connect and emit function.
    gob = None

    signal_d = OrderedDict()

    # Has subscriber in idle signal checking ring, '_crib'.
    # {object id: object}
    _crib = {}

    # Is True when there are no Signal in 'signal_d', 'is_gone'.
    # Send a 'si.POWER_GONE' Signal when the dict is emptied.
    is_gone = False

    def __init__(self):
        # Enable custom signal.
        gobject.GObject.__init__(self)
        Ring.gob = self

    @staticmethod
    def add(a, n, arg):
        """
        Add a signal to the signal dict.

        a: object
            Is the sender that emits the signal.

        n: string
            signal descriptor

        arg: value
            Sent with signal.
        """
        k = id(a), n

        # Remove old an signal so that the new signal is done last.
        if k in Ring.signal_d:
            Ring.signal_d.pop(k)
        Ring.signal_d[k] = a, n, arg

    @staticmethod
    def carry(baby):
        """
        Subscribe an entity, (e.g. a Model instance), so that it can
        do its own signal processing when the interface is idle.
        """
        Ring._crib[id(baby)] = baby

    @staticmethod
    def drop(baby):
        """
        Remove a subscriber.

        baby: Baby
            Is in the crib.
        """
        Ring._crib.pop(id(baby))

    @staticmethod
    def plug(n, arg):
        """
        Add a Ring signal.

        n: string
            Signal type

        arg: value
        """
        Ring.add(Ring.gob, n, arg)

    @staticmethod
    def pressure():
        """Clear the signal list and all subscribers do the same."""
        sending = True

        while sending:
            sending = False

            # There are possible semi-circular usage of Ring by a subscriber.
            if Ring.signal_d:
                Ring.turn()
                sending = True

            # object id, object; '_, a'
            for _, a in Ring._crib.items():
                if a.signal_d:
                    a.pressure()
                    sending = True

    @staticmethod
    def send():
        """Send out a signal."""
        if Ring.signal_d:
            Ring.turn()

        else:
            # Only call subscriber if a Preset isn't loading.
            if not The.load_count:
                for _, a in Ring._crib.items():
                    a.turn()
        return True

    @staticmethod
    def turn():
        """Send out one signal if there is one."""
        for i, a in Ring.signal_d.items():
            sender, signal, arg = a

            Ring.signal_d.pop(i)
            sender.emit(signal, arg)

            if not Ring.signal_d:
                if not Ring.is_gone:
                    Ring.is_gone = True
            break
        if Ring.is_gone:
            Ring.is_gone = False
            Ring.gob.emit(si.RING_GONE, None)


if not Ring.gob:
    Ring()

# Register custom signal.
gobject.type_register(Ring)
