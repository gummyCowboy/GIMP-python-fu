#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from copy import deepcopy
from roller_a_contain import Gradient
from roller_constant_for import Issue as vo, Signal as si
from roller_constant_key import Option as ok
from roller_fu import add_layer, create_image
from roller_maya import Maya
from roller_one_ring import Ring
from roller_one_wip import Wip
from roller_option_group import ManyGroup
from roller_view_hub import do_gradient_job, do_mod


def create_gradient(maya):
    """
    Create a Gradient Light image. The image is hidden from
    the user and is removed when Roller closes or by an
    GradientLight change operation. Gradient Light layers are
    created from the image using a copy visible image function.

    maya: Maya
    """
    reset_gradient()

    d = deepcopy(maya.value_d)
    d[ok.GRADIENT] = d[ok.RW1][ok.GRADIENT]
    w, h = Wip.get_size()
    j = Gradient.image = create_image(int(w), int(h))

    do_gradient_job(add_layer(j, "Process"), d)
    do_mod(j.layers[0], d[ok.RW1][ok.MOD])


def make_gradient_light(maya):
    """
    Make Gradient Light and/or remove it.

    maya: Work
    """
    if maya.is_matter:
        reset_gradient()
        create_gradient(maya)


def reset_gradient():
    if Gradient.image:
        pdb.gimp_image_delete(Gradient.image)
        Gradient.image = None


class Light(ManyGroup):
    """Create Widget group and assign view run processor."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)


class Plan(Maya):
    """Doesn't have layer output. Is a template for a Plan run."""
    issue_q = ()
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Maya.__init__(self, any_group, 0, (), vo.NO_VOTE)

    def do(self):
        """
        Plan doesn't have Gradient Light.

        Return: None
            for undo
        """
        return


class Work(Maya):
    """Manage Gradient Light layer output."""
    put = (make_gradient_light, 'matter'),
    issue_q = 'matter',
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Maya.__init__(
            self,
            any_group,
            1,
            Work.put,
            [(), (ok.RW1,), (ok.RW1, ok.MOD)]
        )
        self.set_issue()
        self.latch(any_group.booth, (si.VOTE_CHANGE, Work.on_light_change))

    def do(self):
        """Manage Gradient Light layer output for a Work run."""
        self.go = self.value_d[ok.SWITCH]
        self.realize_vote()

    def die(self):
        """Override the Maya class function."""
        reset_gradient()

    @staticmethod
    def on_light_change(_, arg):
        """
        Respond to change in Gradient Light option.
        Notify gradient light subscriber.

        _: AnyGroup
            Sent the signal.

        arg: dict
            AnyGroup's vote collection
            not used
        """
        Ring.plug(si.LIGHT_CHANGE, None)
