#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import make_2d_table
from roller_many_rect import Rect


class RectTable:
    """
    Create a cell table. Calculate the rectangle of each cell.
    Use a Rect object to store the position and size of a cell.
    """

    def __init__(self, rect, row, column):
        """
        Calculate cell size. Access the cell
        table with this object's 'table' attribute.

        rect: tuple
            (x, y, w, h) of float
            space for the grid

        row, column: int
            row and column scale of the cell table
        """
        x, y, w, h = rect
        w = w / column
        h = h / row
        q_y = []
        q_x = []
        q = self.table = make_2d_table(row, column)

        # remainder total, 'f_x, f_y'
        f_x = f_y = .0

        # Add remainder to coordinate when the remainder is close to one.
        for r in range(row + 1):
            y, f = divmod(y, 1.)
            f_y += f

            if f_y >= .999999:
                y += 1.
                f_y -= 1.

            q_y.append(y)
            y += h

        for c in range(column + 1):
            x, f = divmod(x, 1.)
            f_x += f

            if f_x >= .999999:
                x += 1.
                f_x -= 1.

            q_x.append(x)
            x += w
        for r in range(row):
            for c in range(column):
                y, y1 = q_y[r], q_y[r + 1]
                x, x1 = q_x[c], q_x[c + 1]
                q[r][c] = Rect(x, y, x1 - x, y1 - y)
