#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, seed
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_one_rect_table import RectTable
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_line_graph import LineGraph
import gimpfu as fu

pdb = fu.pdb


def do_border(one, row, column):
    """
    Draw border of mazes around the layer.

    one: One
        Has variables.

    row, column: int
        row and column count for placing a maze
        These counts are approximately half of the
        user-specified row and column count.
    """
    for r in range(row):
        draw_maze(one, r, 0)
    for c in range(column):
        draw_maze(one, 0, c)


def do_fill(one, row, column):
    """
    Draw mazes that fill the frame layer.

    row, column: int
        row and column count for maze place
    """
    for r in range(row):
        for c in range(column):
            draw_maze(one, r, c)


def do_scattered_connectors(one, row, column):
    """
    Draw connectors randomly.

    one: One
        Has options.

    row, column: int
        row and column count for maze place
    """
    d = one.d
    connector = []

    if d[ok.GAP_TYPE] == bs.RANDOM:
        # Try to get the connector to draw
        # so that it's not on the border:
        r1 = min(1, row - 1)
        c1 = min(1, column - 1)
        for _ in range(one.scatter_count):
            r = randint(r1, row - 1)
            c = randint(c1, column - 1)
            q = r, c

            while q in connector:
                r = randint(1, row)
                c = randint(1, column)
                q = r, c
            connector.append(q)

    else:
        r = c = 0
        r1, c1 = row - 1, column - 1
        for _ in range(one.scatter_count):
            c += d[ok.CELL_GAP]
            while c > c1:
                c -= max(1, c1)
                r += 1

            while r > r1:
                r -= max(1, r1)
            connector.append((r, c))
    for q in connector:
        r, c = q[0], q[1]
        if randint(0, 1):
            one.line_graph.add_line(
                (r, c),
                (r + 1, c),
                LineGraph.real
            )
        else:
            one.line_graph.add_line(
                (r, c),
                (r, c + 1),
                LineGraph.real
            )


def do_scattered_mazes(one, row, column):
    """
    Draw mazes randomly.

    one: One
        Has options.

    row, column: int
        row and column count for maze place
    """
    d = one.d
    maze = []

    if d[ok.GAP_TYPE] == bs.RANDOM:
        for _ in range(one.scatter_count):
            r = randint(0, row - 1)
            c = randint(0, column - 1)
            q = r, c

            while q in maze:
                r = randint(0, row - 1)
                c = randint(0, column - 1)
                q = r, c
            maze.append(q)

    else:
        r = c = 0
        for _ in range(one.scatter_count):
            c += d[ok.CELL_GAP]
            while c > column - 1:
                c -= max(1, column - 1)
                r += 1

            while r > row - 1:
                r -= max(1, row - 1)
            maze.append((r, c))
    for q in maze:
        r, c = q[0], q[1]
        draw_maze(one, r, c)

        if d[ok.MAZE_DIRECTION] == bs.COUNTER_CLOCKWISE:
            one.line_graph.add_line(
                (r, c),
                (r + 1, c),
                LineGraph.real
            )
        else:
            one.line_graph.add_line(
                (r, c),
                (r, c + 1),
                LineGraph.real
            )


def draw_corners(one):
    """
    Flip the topleft-quarter selection into the other corners.

    one: One
        Has variables.
    """
    cat = Hat.cat
    j = cat.render.image
    z = Lay.add(j, one.k, parent=one.parent)
    s = cat.render.size
    w = s[0] // 2 + s[0] % 2
    h = s[1] // 2 + s[1] % 2

    Sel.fill(z, (0, 0, 0))
    pdb.gimp_selection_none(j)
    Sel.rect(j, 0, 0, w, h)
    Sel.invert_clear(z)

    z = Lay.clone(z)

    Lay.flip(z, horizontal=True)

    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
    z = Lay.clone(z)

    Lay.flip(z)

    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    Sel.item(z)
    pdb.gimp_image_remove_layer(j, z)


def draw_clockwise_maze(one, r, c):
    """
    Draw a clockwise configured maze.

    one: One
        Has variables.

    r, c: int
        row, column
        maze position
    """
    d = one.d
    line_length = [0, 0]
    line_w = d[ok.LINE_WIDTH]
    x, y = one.grid[r][c].position
    line_length[0], line_length[1] = one.grid[r][c].size
    x1, y1 = x, y
    x2 = 0
    is_right = True
    is_up = is_left = is_down = False
    while line_length[x2] > d[ok.STOP_LENGTH]:
        if is_down:
            x2 = 1
            w = line_w
            h = line_length[x2]

            # next line:
            is_down = False
            is_left = True
            x1 = x
            y1 = y + line_length[x2] - line_w

        elif is_right:
            x2 = 0
            w = line_length[x2]
            h = line_w

            # next line:
            is_right = False
            is_down = True
            x1 = x + line_length[x2]
            y1 = y

        elif is_up:
            x2 = 1
            w = line_w
            h = line_length[x2]
            y = y - line_length[x2]

            # next line:
            is_up = False
            is_right = True
            x1 = x
            y1 = y

        elif is_left:
            x2 = 0
            w = line_length[x2]
            h = line_w
            x -= line_length[x2]

            # next line:
            is_left = False
            is_up = True
            x1 = x
            y1 = y

        # Select line:
        Sel.rect(Hat.cat.render.image, x, y, w, h)

        # next line:
        line_length[x2] = int(line_length[x2] * .75)

        x, y = x1, y1
        x2 = int(not x2)
        line_length[x2] = int(line_length[x2] * .85)


def draw_counter_clockwise_maze(one, r, c):
    """
    Draw a counter-clockwise configured maze.

    one: One
        Has variables.

    r, c: int
        row, column
        maze position
    """
    d = one.d
    line_length = [0, 0]
    line_w = d[ok.LINE_WIDTH]
    x, y = one.grid[r][c].position
    line_length[0], line_length[1] = one.grid[r][c].size
    x1, y1 = x, y
    x2 = 1
    is_down = True
    is_up = is_left = is_right = False
    while line_length[x2] > d[ok.STOP_LENGTH]:
        if is_down:
            x2 = 1
            w = line_w
            h = line_length[x2]

            # next line:
            is_right = True
            is_down = False
            x1 = x
            y1 = y + line_length[x2]

        elif is_right:
            x2 = 0
            w = line_length[x2]
            h = line_w

            # next line:
            is_up = True
            is_right = False
            x1 = x + line_length[x2] - line_w
            y1 = y

        elif is_up:
            x2 = 1
            w = line_w
            h = line_length[x2]
            y = y - line_length[x2]

            # next line:
            is_up = False
            is_left = True
            x1 = x
            y1 = y

        elif is_left:
            x2 = 0
            w = line_length[x2]
            h = line_w
            x -= line_length[x2]

            # next line:
            is_left = False
            is_down = True
            x1 = x
            y1 = y

        # Select line:
        Sel.rect(Hat.cat.render.image, x, y, w, h)

        # next line:
        line_length[x2] = int(line_length[x2] * .75)

        x, y = x1, y1
        x2 = int(not x2)
        line_length[x2] = int(line_length[x2] * .85)


def draw_maze(one, r, c):
    """
    Draw a maze.

    one: One
        Has variables.

    r, c: int
        row, column
        the maze cell position
    """
    if one.d[ok.MAZE_DIRECTION] == bs.COUNTER_CLOCKWISE:
        draw_counter_clockwise_maze(one, r, c)
    else:
        draw_clockwise_maze(one, r, c)


def make_sel(one, frame_sel, _):
    """
    Add the maze selection to the border selection.

    one: One
        Has options.

    frame_sel: Selection
        of frame around image

    _: Selection
        unused

    Return: state of image
        selection state
    """
    cat = Hat.cat
    j = cat.render.image
    d = one.d
    sel1 = None
    a = bs.MAZE_TYPE
    row = d[ok.ROW] // 2 + d[ok.ROW] % 2
    column = d[ok.COLUMN] // 2 + d[ok.COLUMN] % 2
    one.grid = RectTable(cat.render.size, d[ok.ROW], d[ok.COLUMN]).table

    seed(d[ok.RANDOM_SEED])
    pdb.gimp_selection_none(j)

    if d[ok.COMPOSITION_FRAME_WIDTH]:
        pdb.gimp_selection_all(j)
        pdb.gimp_selection_shrink(j, d[ok.COMPOSITION_FRAME_WIDTH])
        Sel.invert(j)
        sel1 = cat.save_short_term_sel()

    one.scatter_count = min(d[ok.SCATTER_COUNT], row * column)

    if d[ok.MAZE_TYPE] in (a[0], a[1]):
        one.line_graph = LineGraph(
            cat.render.size,
            d[ok.ROW],
            d[ok.COLUMN],
            d[ok.LINE_WIDTH]
        )

        if d[ok.MAZE_TYPE] == a[0]:
            do_scattered_connectors(one, row, column)

        elif d[ok.MAZE_TYPE] == a[1]:
            do_scattered_mazes(one, row, column)

        one.line_graph.add_line_to_disconnects()
        one.line_graph.draw_lines()

    elif d[ok.MAZE_TYPE] == a[2]:
        do_border(one, row, column)

    else:
        do_fill(one, row, column)

    draw_corners(one)
    Sel.load(j, frame_sel, option=fu.CHANNEL_OP_ADD)
    if sel1:
        Sel.load(j, sel1, option=fu.CHANNEL_OP_ADD)


class MazeMirror:
    """
    Add spiral mazes and connectors to a frame that fills around images.
    """

    @staticmethod
    def do(one):
        """
        Do the Maze Mirror image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Maze Material
        """
        return BorderLine.do(one, framer=make_sel)
