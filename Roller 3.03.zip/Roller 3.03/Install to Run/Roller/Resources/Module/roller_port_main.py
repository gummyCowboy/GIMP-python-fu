#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Frame as fo,
    Margin as fm,
    Node as fd,
    Widget as fw
)
from roller_constant_key import (
    BackdropStyle as by,
    Button as bk,
    Effect as ek,
    Group as gk,
    Model as md,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_effect import ImageEffect
from roller_one import Hat
from roller_one_draw import Draw
from roller_one_tip import Tip
from roller_option_preset import (
    BEHIND_TYPE,
    NonPreset,
    PerCell,
    Preset,
    SuperPreset
)
from roller_option import OptionStat
from roller_option_group import OptionGroup
from roller_port import Port
from roller_port_node import PortNode
from roller_widget_button import OptionButton
from roller_widget_button_pair import ButtonPair
from roller_widget_box import VBow
from roller_widget_button import Button
from roller_widget_label import Label
from roller_window_save import RWSave

# Are group types that only update SuperPresets on change:
NO_FEEDBACK = Preset, SuperPreset


def get_model_list():
    """
    The ModelList has a fixed path.

    Return: ModelList
        of item names
    """
    return Hat.cat.group_dict[sk.MODEL].d[ok.MODEL_LIST]


def get_parent_node(g):
    """
    Get the connected Node of a ModelList.

    g: ModelList
        with Node

    Return: tuple
        Node
        path of Node
    """
    path = g.group.path[:-1]
    return Hat.cat.group_dict[path].node, path


def insert_node_item(node, group_key, path, x, group_id=None):
    """
    Insert a row into a Node.

    Create a VBox for the item's option group
    or use its existing option group's VBox.

    node: Node
        work-in-progress

    group_key: string
        name of option

    path: string
        to option group
        Use to determine if the option group already exists.

    x: int
        insertion index

    group_id: int
        Use with the table and custom cell model.

    Return: tuple
        gtk.VBox, boolean
        box from new group; Is true, if the vbox is new.
    """
    if group_id is None:
        group_id = group_key

    d = Hat.cat.group_dict
    k = path + (group_id,)

    if k in d:
        vbox = d[k].vbox
        is_new = False

    else:
        vbox = VBow()
        is_new = True

    # Add row:
    node.insert_row(x, group_key)

    if is_new:
        g = vbox.label_ = Label(
            text="{}:".format(group_key),
            padding=(4, 4, 4, 4)
        )

    node.group_box.insert(x, vbox)

    if is_new:
        vbox.pack_start(g, expand=True)
    return vbox, is_new


def make_plan(g):
    """
    Create a plan render.

    g: OptionButton
        of plan
        Is responsible.
        Has path.
    """
    path = g.group.path

    Hat.cat.plan.prep(SuperPreset.get_render_steps(path=path))
    g.set_sensitive(0)
    SuperPreset.update_plan_buttons(path)
    if hasattr(g.group, 'preview_button'):
        if g.group.preview_button:
            g.group.preview_button.set_sensitive(1)


def on_delete_zlist_item(g, group_key):
    """
    Delete a ModelList item. They come from
    the table and cell models.
    """
    node = get_parent_node(g)[0]
    q = node.get_value()
    x = q.index(group_key)

    node.remove_item(x)
    node.group_box.pop(x)


def on_move_zlist_item(g):
    """
    A ModelList has changed the order of its items.

    Respond by rearranging the corresponding items in the Node.

    g: ModelList
        Is responsible.
    """
    node = get_parent_node(g)[0]
    group_box = node.group_box[:]
    q = g.get_value()
    a = node.original_length
    b = len(q)
    q1 = node.get_value()

    # Remove old order:
    for i in range(b):
        node.remove_item(a)

    # Add new order:
    for x, i in enumerate(reversed(q)):
        # Add row:
        n = i[md.NAME_INDEX]

        node.insert_row(a + x, n)

        x1 = q1.index(n)
        node.group_box[a + x] = group_box[x1]


def on_name_change(g):
    """
    Update the three dependencies to a table or a custom cell name.

    g: Entry
        Has new name.
    """
    node, path = get_parent_node(g)

    if g.key == ok.TABLE_NAME:
        # Has label:
        vbox = node.group.vbox

    node = get_parent_node(node)[0]

    if g.key == ok.CELL_NAME:
        vbox = node.group.vbox
        node = get_parent_node(node)[0]

    _id = [i for i in reversed(path) if isinstance(i, int)][0]
    old_name = Hat.cat.group_id.get_name(_id)
    new_name = g.get_value()

    if not new_name:
        new_name = "_"

    # The new name cannot match another
    # in the node item list besides itself:
    q = node.get_value()
    x = q.index(old_name)

    q.pop(x)

    model_list = get_model_list()

    while new_name in q:
        new_name += "_"

    # Rename option group label:
    vbox.label_.set_label_value(new_name + ":")
    Hat.cat.group_id.change_name(_id, new_name)

    # Rename the Node item:
    node.rename_item(x, new_name)

    # Rename ModelList item:
    names = [i[0] for i in model_list.get_value()]
    model_list.rename_item(names.index(old_name), new_name)


def update_margin_label(g):
    """
    Have the margin label update itself.

    g: Slider
        Is responsible.
        of margins
    """
    g.group.d[ok.MARGIN_SIZE].update_size()


class PortMain(Port):
    """Is for the main window."""
    TITLE = "Roller 3.03"

    def __init__(self, d):
        """
        Draw widgets.

        d: dict
            Has init variables.
        """
        d[wk.WINDOW_TITLE] = PortMain.TITLE
        d[wk.SAVE_WINDOW] = RWSave

        # Is passed to widgets during their initialization:
        self.d = {
            wk.CREATE_ZLIST_ITEM: self.on_create_model,
            wk.DELETE_ZLIST_ITEM: on_delete_zlist_item,
            wk.IS_DEFAULT: True,
            wk.MOVE_ZLIST_ITEM: on_move_zlist_item,
            wk.ON_PREVIEW_BUTTON: SuperPreset.make_preview,
            wk.SAVE_WINDOW: d[wk.SAVE_WINDOW]
        }

        # Are functions responding to change:
        self._on_user_change = {
            bk.PLAN: make_plan,
            bk.RANDOM: Port.randomize_widgets
        }
        self._on_any_change = {
            gk.BACKDROP_STYLE: self._on_backdrop_style_change,
            gk.IMAGE_EFFECT: self._on_image_effect_change,
            ok.CELL_NAME: on_name_change,
            ok.TABLE_NAME: on_name_change
        }

        Port.__init__(self, d)
        self._load_steps()

    def _draw_navigation(self, g):
        """
        Draw the options navigation group.

        g: GTK container
            to receive group of widgets
        """
        a = self.color

        self._draw_options(g, gk.STEPS, 0, ())

        self.color = a
        for i in range(len(self.d[wk.NAV_BOX].junctions)):
            self.reduce_color()

    def _draw_process(self, g):
        """
        Draw a process group with cancel and accept options.

        g: GTK container
            to receive group
        """
        def on_action(g_):
            self.cancel(g_) if g_.key == bk.CANCEL else self.accept(g_)

        g1 = ButtonPair(
            on_widget_change=on_action,
            render_pad=(0, 0, fw.MARGIN, fw.MARGIN),
            text=(bk.CANCEL, bk.RENDER),
            win=self.roller_window
        )

        self.keep(g1)
        g.add(g1)

    def _load_steps(self):
        """Load the steps from the previous session."""
        # Get preset for steps:
        g = Hat.cat.group_dict[sk.STEPS_PRESET].d[wk.PRESET]
        self._last_session = g.load(fw.LAST_USED)

    def _on_backdrop_style_change(self, g):
        """
        Process backdrop-style change.

        g: Widget
            Is responsible.
            an OptionList
        """
        def add_row(n_):
            """
            Add an item to the list.

            Is a timing issue with backdrop-style
            not selecting a row.
            """
            node.add_item(n_)

            x = node.get_sel_x()

            if x is not None:
                node.select_item(x)
            else:
                node.select_item(rows - 1)

        Draw.load_count += 1
        d = Hat.cat.group_dict
        group_key = g.get_value()
        node = get_parent_node(g)[0]
        rows = len(node.list_store)

        # Remove old:
        if rows == fd.WITH_BACKDROP_STYLE:
            node.remove_item(2)

        if len(node.group_box) == fd.WITH_BACKDROP_STYLE:
            node.group_box.pop(2)
        # Add new:
        if group_key != by.BACKDROP_IMAGE:
            add_row(group_key)

            k = sk.BACKDROP + (group_key,)

            if k in d:
                node.group_box.append(d[k].vbox)
            else:
                # Are option group initialization variables:
                self.d[wk.IS_DEFAULT] = True
                e = {
                    wk.COLOR: self.column_color[len(k) - 1],
                    wk.CONTAINER: PortNode.add_group_to_node(node, group_key),
                    wk.GROUP_KEY: group_key,
                    wk.GROUP_TYPE: Preset,
                    wk.HAS_PRESET: True,
                    wk.HAS_EFFECT_PAIR: True,
                    wk.KEYS: Preset.get_keys(group_key),
                    wk.PATH: k
                }

                e.update(self.d)
                OptionGroup.draw_group(**e)

        # Set tooltip for selected list item:
        a = d[sk.BACKDROP_STYLE]

        if ok.BACKDROP_STYLE in a.d:
            g = a.d[ok.BACKDROP_STYLE]
            n = g.get_value()
            g.set_tooltip_text(
                Tip.OPTION_MAIN[n] if n in Tip.OPTION_MAIN else ""
            )
        Draw.load_count -= 1

    def _on_image_effect_change(self, g):
        """
        Process image-effect change.

        g: Widget
            Is responsible.
            an OptionList
        """
        Draw.load_count += 1
        group_key = g.get_value()
        node, path = get_parent_node(g)
        x = node.original_length

        # Remove previous effect:
        if group_key in ImageEffect.MAIN:
            sel_x = node.get_sel_x()

            while len(node.group_box) > x:
                # Use '-2' so the Blur Behind remains intact:
                node.group_box.pop(-2)

            while len(node.get_value()) > x:
                node.remove_item(-1)

            # Add new effect:
            keys = OptionStat.get_effect_keys(group_key)
            self.d[wk.IS_DEFAULT] = True

            for x1, key in enumerate(keys):
                vbox, is_new = insert_node_item(node, key, path, x + x1 - 1)
                if is_new:
                    k = path + (key,)

                    # Are option group initialization variables:
                    e = {
                        wk.COLOR: self.column_color[len(k) - 1],
                        wk.CONTAINER: vbox,
                        wk.GROUP_KEY: key,
                        wk.GROUP_TYPE: Preset,
                        wk.KEYS: Preset.get_keys(key),
                        wk.PATH: k
                    }
                    if group_key == ek.NO_EFFECT:
                        e[wk.HAS_PREVIEW] = True

                    else:
                        e[wk.HAS_PRESET] = e[wk.HAS_EFFECT_PAIR] = True

                    e.update(self.d)
                    OptionGroup.draw_group(**e)

            self._update_blur_behind_group(path, group_key)

            if sel_x:
                node.select_item(sel_x)
                g.grab_focus()

            # Set tooltip for selected list item:
            a = Hat.cat.group_dict[path + (gk.IMAGE_EFFECT,)]
            if ok.IMAGE_EFFECT in a.d:
                g = a.d[ok.IMAGE_EFFECT]
                n = g.get_value()
                g.set_tooltip_text(
                    Tip.OPTION_MAIN[n] if n in Tip.OPTION_MAIN else ""
                )
        Draw.load_count -= 1

    def _update_blur_behind_group(self, path, group_key):
        """
        Remove the old and add the new
        blur behind effect to the Blur Behind group.
        """
        path = path + (gk.BLUR_BEHIND,)
        if path in Hat.cat.group_dict:
            node = Hat.cat.group_dict[path].d[gk.BLUR_BEHIND]
            q = node.get_value()

            # Remove old:
            if len(q) > node.original_length:
                node.remove_item(2)
                node.group_box.pop(2)
            # Add new:
            if group_key in fo.BLUR_BEHIND_EFFECT:
                k = path + (group_key,)
                vbox, is_new = insert_node_item(node, group_key, k, 2)
                key = group_key + fd.BLUR_BEHIND
                self.group_def[key] = BEHIND_TYPE
                if is_new:
                    self._draw_options(vbox, key, len(path), path)

    def accept(self, *_):
        """
        Begin a render.

        Return: true
            The key-press is handled.
        """
        self.roller_window.win.iconify()
        return self.accept_port(
            SuperPreset.get_render_steps(),
            self._last_session
        )

    def cancel(self, *_):
        """
        Close the window.

        Return: true
            The key-press is handled.
        """
        # ImageGradient may have produced a gradient:
        Hat.cat.image_gradient_used = None

        return self.cancel_port()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            to receive port
        """
        self.d[wk.WIN] = self.roller_window
        self.draw_simple_dialog_port(
            g,
            (self._draw_navigation, self._draw_process),
            ("Steps", "")
        )

    def on_create_model(self, g, group_key, _type):
        """
        Create a group for a ModelList New action.

        ZLists are used by table and custom cell models.

        g: Widget
            Is responsible.
            Z-List

        group_key: string
            name of new model

        _type: string
            either "Table" or "Cell"
        """
        Draw.load_count += 1
        node, path = get_parent_node(g)
        group_id = Hat.cat.group_id.make_id(group_key)

        # node path, 'q':
        q = path + (group_id,)

        self.d[wk.IS_DEFAULT] = True
        vbox = insert_node_item(
            node,
            group_key,
            path,
            1,
            group_id=group_id
        )[0]
        d = {wk.CONTAINER: vbox, wk.GROUP_KEY: group_key, wk.PATH: q}

        d.update(self.d)

        if _type == md.TABLE:
            NonPreset.update_z_item_name(
                gk.TABLE_PROPERTY,
                ok.TABLE_NAME,
                group_key
            )
            self.group_def[group_id] = self.group_def[gk.TABLE_MODEL]

        else:
            NonPreset.update_z_item_name(
                gk.CUSTOM_CELL_PROPERTY,
                ok.CELL_NAME,
                group_key
            )
            self.group_def[group_id] = self.group_def[gk.CUSTOM_CELL_MODEL]

        self._create_node(d, group_key, len(q) - 1, q, group_id=group_id)
        Draw.load_count -= 1

    def on_widget_change(self, g, *_):
        """
        A widget changed.

        Respond to changes in the interface.

        g: Widget
            Is responsible.
        """
        a = g.group

        if g.key == wk.PRESET:
            if a.group_key in fm.MARGIN_GROUP:
                update_margin_label(g)

        elif g.key in self._on_any_change:
            self._on_any_change[g.key](g)
        else:
            if not (Draw.load_count or Draw.preset_load_count):
                if g.key in fm.MARGIN_KEY:
                    update_margin_label(g)

                elif g.key in self._on_user_change:
                    self._on_user_change[g.key](g)

                # if hasattr(g, 'group'):
                if not Draw.preset_load_count:
                    # SuperPresets are undefined when sub-widgets change.
                    # Use the OptionGroup 'group':
                    if type(g) not in NO_FEEDBACK:
                        _type = a.group_type

                        if _type == Preset and g.key not in fw.NO_CHANGE:
                            a.preset.set_to_undefined()
                        elif _type == NonPreset:
                            Preset.set_super_to_undefined(a.path)
                    else:
                        Preset.set_super_to_undefined(a.path)

        # The change status has to be user-instigated
        # and not a widget load operation:
        if not (Draw.load_count or Draw.preset_load_count):
            if not (isinstance(g, OptionButton) or isinstance(g, Button)):
                a.unseen = a.changed = True
                if a.group_type == PerCell:
                    # Update sibling group:
                    g1 = a.d[ok.PER_CELL]
                    b = g1.form_group
                    b.unseen = b.changed = True
            if g.key not in (bk.PLAN, bk.PREVIEW):
                SuperPreset.update_view_buttons(a.path)
