#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu
pdb = fu.pdb


class NanoSuit:
    """Fill the backdrop-image with a fine gradient texture."""

    @staticmethod
    def do(one):
        """
        Do the backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with Color Fill
        """
        d = one.d
        if d[ok.OPACITY] and Lay.has_pixel(one.z):
            j = Hat.cat.render.image
            group = Lay.group(j, one.k)
            z = Lay.clone(one.z)

            pdb.gimp_image_reorder_item(j, z, group, 0)

            Lay.blur(z, 500)
            Gegl.video_degradation(z, 'dots')

            z = Lay.clone(z)
            z.mode = fu.LAYER_MODE_DIFFERENCE

            Gegl.engrave(z, 3)
            pdb.gimp_curves_spline(
                z,
                fu.HISTOGRAM_VALUE,
                4,
                [0, 127, 255, 255]
            )

            z = Lay.merge_group(group)
            z.opacity = d[ok.OPACITY]

            if d[ok.INVERT]:
                pdb.gimp_drawable_invert(z, 0)
            return RenderHub.bump(z, d[ok.BUMP])
