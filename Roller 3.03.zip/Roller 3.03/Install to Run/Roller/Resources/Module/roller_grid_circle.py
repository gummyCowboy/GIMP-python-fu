#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_one import Rect
from roller_one_extract import FromRect, Shape

RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
RATIO_ALT = 1 - RATIO


class GridCircle:
    """
    Calculate the position and the size of cells.

    The cells are ellipse shaped.

    Use a double-spaced grid-type.
    """

    def __init__(self, one):
        """
        Calculate an ellipse cell-sized rectangle and an ellipse shape.

        one: One
            Has init values.
        """
        grid = self.grid = one.grid
        self.grid_type = one.grid_type
        row, column = self.row, self.column = one.r, one.c
        table = grid.table
        shape = grid.cell_shape
        s = one.layer_space
        x, y = one.offset

        if shape == sh.CIRCLE_HORIZONTAL:
            # cell size:
            w1 = s[0] / (.5 + column * .5)
            h1 = s[1] / (RATIO_ALT + row * RATIO)
            w = min(w1, h1)
            w, h = w, w

            # table size:
            w1 = w / 2.
            h1 = h * RATIO
            h2 = h * RATIO_ALT
            s1 = int(column * w1 + w1), int(row * h1 + h2)
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

            # intersect:
            w1 = w / 2
            h1 = h * RATIO

        else:
            # circle, vertically aligned
            # cell size:
            w1 = s[0] / (RATIO_ALT + column * RATIO)
            h1 = s[1] / (.5 + row * .5)
            w = min(w1, h1)
            w, h = w, w

            # table size:
            w1 = w * RATIO
            w2 = w * RATIO_ALT
            h1 = h / 2.
            s1 = int(column * w1 + w2), int(row * h1 + h1)
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

            # intersect:
            w1 = w * RATIO
            h1 = h / 2

        w, h = int(w), int(h)
        offset = x, y

        # intersect points:
        q_x = self.q_x = []
        q_y = self.q_y = []

        for c in range(column):
            q_x.append(int(round(x)))
            x += w1

        for r in range(row):
            q_y.append(int(round(y)))
            y += h1
        # Compose points:
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(self.grid, r, c):
                    y = q_y[r]
                    x = q_x[c]
                    position = x, y

                    if (
                        x + w > s[0] + offset[0] or
                        y + h > s[1] + offset[1]
                    ):
                        position = size = 0, 0

                    else:
                        size = w, h

                    # 'cell' is the cell before margins:
                    table[r][c].cell = Rect(position, size)
                    if size[0]:
                        table[r][c].plaque = {
                            'x': x, 'y': y,
                            'w': size[0], 'h': size[1]
                        }

    def calc_shape_per_cell(self, *_):
        """
        Calculate the shape of the ellipse from
        the pocket size on a per cell basis.

        Is part of the Grid template.
        """
        # The pocket rectangle has the shape points:
        self.calc_shape_with_pocket()

    def calc_shape_with_pocket(self):
        """
        Calculate the shape of the ellipse from
        the pocket size using intersects.

        Is part of the Grid template.
        """
        q = self.grid.table
        p = FromRect.circle if self.grid_type == gr.SHAPE_COUNT \
            else FromRect.ellipse
        for r in range(self.row):
            for c in range(self.column):
                if Shape.is_allocated_cell(self.grid, r, c):
                    q[r][c].shape = p(q[r][c].pocket)
