#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Format as ff,
    Fringe as ng,
    Gradient as fg,
    Plan as fy,
    Shape as sh
)
from roller_constant_key import Layer as nk, Option as ok
from roller_constant_fu import Fu
from roller_model_image import Image
from roller_one import Comm, Hat
from roller_one_extract import dispatch, Form, Path, Shape
from roller_one_fu import Lay, Mage, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
pb = Fu.PaintBrush
FRINGE_MAT = ng.GRADIENT, ng.IMAGE, ng.PATTERN, ng.PLASMA, ng.BACKDROP
RECTANGLE = sh.RECTANGLE


def apply_brush(z, q):
    """
    Perform a brush stroke.

    z: layer
        to receive brush

    q: tuple
        x, y
        position of stroke
    """
    pdb.gimp_paintbrush(
        z,
        pb.NO_FADE_OUT,
        pb.STROKES_2,
        q,
        fu.PAINT_CONSTANT,
        pb.GRADIENT_LENGTH_0
    )


def brush_rect(j, z, one, angle, spacing):
    """
    Do brush for a rectangular shape.

    j: GIMP image
        Is render.

    z: layer
        to receive paint material

    one: One
        Has WIP variables.

    angle: float
        for brush

    spacing: float
        between brush applications
    """
    _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
    x_offset = int((x1 - x) % spacing / 2)
    y_offset = int((y1 - y) % spacing / 2)
    brush_x = x + x_offset

    pdb.gimp_selection_none(j)

    # top of cell:
    while brush_x <= x1:
        set_foreground_color(one)
        apply_brush(z, (brush_x, y))
        brush_x += spacing

    # right of cell:
    a = angle + 90

    if a > 180:
        a = angle - 90

    pdb.gimp_context_set_brush_angle(a)

    brush_y = y + y_offset

    while brush_y <= y1:
        set_foreground_color(one)
        apply_brush(z, (x1, brush_y))
        brush_y += spacing

    # bottom of cell:
    brush_x = x1 - x_offset
    a = angle + 180

    if a > 180:
        a = angle - 180

    pdb.gimp_context_set_brush_angle(a)

    while brush_x >= x:
        set_foreground_color(one)
        apply_brush(z, (brush_x, y1))
        brush_x -= spacing

    # left of cell:
    a = angle + 270

    while a > 180:
        a -= 360

    pdb.gimp_context_set_brush_angle(a)

    brush_y = y1 - y_offset
    while brush_y >= y:
        set_foreground_color(one)
        apply_brush(z, (x, brush_y))
        brush_y -= spacing


def do_as_is(_, z, one):
    """
    Make cell fringe from the brush's output.

    _: GIMP image
        Is render.

    z: layer
        Has fringe material.

    one: One
        Has cell data.

    Return: layer
        Has image.
    """
    return RenderHub.bump(Lay.clone(z), one.d[ok.BUMP])


def do_backdrop(j, z, one):
    """
    Make cell fringe from the backdrop layers.

    j: GIMP image
        Is render.

    z: layer
        Has fringe material.

    one: One
        Has cell data.

    Return: layer
        Has image.
    """
    Lay.hide(z)
    Mage.copy_all(j)
    Lay.show(z)
    return RenderHub.bump(Lay.paste(z), one.d[ok.BUMP])


def do_brush(j, z, one):
    """
    Paint fringe material.

    j: GIMP image
        Is render.

    z: layer
        to receive paint

    one: One
        Has cell data.

    Return: layer
        with paint
    """
    cat = Hat.cat
    d = one.d
    e = d[ok.BRUSH_DICT]
    brush = e[ok.BRUSH]
    one.colors = None
    callback = None

    if brush not in cat.brush_list:
        Comm.info_msg(ff.MISSING_ITEM.format("self", "brush", brush))

    else:
        if one.is_plan:
            pass

        elif one.type_ == ng.TWO_COLOR:
            one.colors = d[ok.COLOR_1], d[ok.COLOR_2]
            callback = set_foreground_color
            one.color = one.colors[0]

        elif one.type_ == ng.ONE_COLOR:
            one.color = d[ok.COLOR]
            pdb.gimp_context_set_foreground(one.color)

        else:
            if not hasattr(one, 'color'):
                one.color = pdb.gimp_context_get_foreground()

        brush_size = e[ok.BRUSH_SIZE]
        spacing = e[ok.BRUSH_SPACING]
        f = spacing / brush_size
        angle = e[ok.BRUSH_ANGLE]

        pdb.gimp_selection_shrink(j, d[ok.CONTRACT])
        if Sel.is_sel(j):
            pdb.gimp_context_set_dynamics('Dynamics Off')
            pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
            pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
            pdb.gimp_context_set_brush_aspect_ratio(0.)
            pdb.gimp_context_set_brush_force(1)
            pdb.gimp_context_set_antialias(1)
            pdb.gimp_context_set_brush_angle(angle)
            pdb.gimp_context_set_brush_spacing(f)
            pdb.gimp_context_set_brush_hardness(e[ok.BRUSH_HARDNESS])
            pdb.gimp_context_set_brush(brush)
            pdb.gimp_context_set_brush_size(brush_size)
            pdb.gimp_context_set_opacity(e[ok.OPACITY])
            pdb.gimp_context_set_foreground(one.color)

            _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

            if (
                Shape.is_rectangular_shape(one.shape) and
                max(x1 - x, y1 - y) > spacing
            ):
                brush_rect(j, z, one, angle, spacing)

            else:
                pdb.plug_in_sel2path(j, z)

                stroke = j.active_vectors.strokes[0]

                pdb.gimp_selection_none(j)
                RenderHub.brush_stroke_on_stroke(
                    z,
                    brush,
                    brush_size,
                    stroke,
                    spacing,
                    callback=(callback, one)
                )
            if one.type_ != ng.MASK and not one.is_plan:
                z = RenderHub.bump(z, d[ok.BUMP])
    return z


def do_cell(one):
    """
    Process the fringe for a cell.

    one: One
        Has cell values.

    fringe_name: string
        fringe layer name

    plaque_name: string
        fringe's plaque layer name

    Return: layer or None
        with fringe
    """
    cat = Hat.cat
    z = None
    is_paint = one.type_ != ng.MASK
    one.is_paint |= is_paint
    j = cat.render.image

    if is_paint:
        z = Lay.add(j, one.name, parent=one.group)
        z = do_paint(j, z, one)
        if hasattr(one, 'mask_sel'):
            one.mask_sel += [cat.get_plaque_sel(one.model_name, one.r, one.c)]

    else:
        # fringe mask dependency:
        d = one.plaque_dict
        opacity = d[ok.OPACITY]
        if opacity and one.type_ != "None":
            one.make_path = Path.make_cell_plaque_path
            do_mask(one)
    return z


def do_plasma(j, z, one):
    """
    Make a plasma cell fringe.

    j: GIMP image
        Is render.

    z: layer
        Has material to select.

    one: One
        Has cell data.

    Return: layer
        Has gradient.
    """
    z = Lay.add_above(z)

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, one.d[ok.RANDOM_SEED], 3)
    return z


def do_gradient(j, z, one):
    """
    Make a gradient cell fringe.

    j: GIMP image
        Is render.

    z: layer
        Has material to select.

    one: One
        Has cell data.

    Return: layer
        Has gradient.
    """
    def draw_gradient(_start_x, _end_x, _start_y, _end_y):
        """
        Draw a gradient given a layer, a start-point and an end-point.
        """
        pdb.gimp_drawable_edit_gradient_fill(
            z1,
            fg.GRADIENT_TYPE_LIST.index(gradient_type),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            _start_x, _start_y,
            _end_x, _end_y
        )

    cat = Hat.cat
    z1 = None
    gradient = one.d[ok.GRADIENT]

    if gradient in cat.gradient_list:
        Sel.item(z)

        a, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        w, h = x1 - x, y1 - y
        if a:
            gradient_type = one.d[ok.GRADIENT_TYPE]

            RenderHub.set_fill_context(fg.FILL_DICT)
            pdb.gimp_context_set_gradient(gradient)
            pdb.gimp_context_set_gradient_blend_color_space(
                fu.GRADIENT_BLEND_RGB_PERCEPTUAL
            )
            pdb.gimp_context_set_gradient_reverse(0)

            if gradient_type in fg.SHAPE_BURST:
                j1 = pdb.gimp_image_new(w, h, fu.RGB)
                z1 = Lay.add(j1, '')

                pdb.gimp_selection_all(j1)
                Sel.fill(z1, (127, 127, 127))
                pdb.gimp_selection_none(j1)
                draw_gradient(0, 0, 0, 0)
                Mage.copy_all(j1)
                pdb.gimp_image_delete(j1)

                z1 = Lay.paste(z)
                z1.name = one.name

                pdb.gimp_layer_set_offsets(z1, x, y)
                z1 = RenderHub.bump(z1, one.d[ok.BUMP])

            else:
                z1 = Lay.add(j, one.name, parent=one.group)
                start_x, end_x, start_y, end_y = \
                    RenderHub.get_gradient_points(
                        one.d[ok.GRADIENT_ANGLE],
                        x, y,
                        w, h
                    )

                Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
                draw_gradient(start_x, end_x, start_y, end_y)
                z1 = RenderHub.bump(z1, one.d[ok.BUMP])

    else:
        Comm.info_msg(
            ff.MISSING_ITEM.format("self", "gradient", gradient)
        )
    return z1


def do_image(j, z, one):
    """
    Make a image cell fringe.

    j: GIMP image
        Is render.

    z: layer
        Has fringe material.

    one: One
        Has cell data.

    Return: layer
        Has image.
    """
    z1 = None

    Sel.item(z)

    a, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
    w, h = x1 - x, y1 - y

    if a:
        pdb.gimp_selection_none(j)

        image = one.d[ok.IMAGE]
        j1 = Image.get_image(image, one.image_index)
        if j1:
            j2 = j1.j

            Mage.copy_all(j2)

            j2 = pdb.gimp_edit_paste_as_new_image()

            Mage.shape(j2, w, h)

            z1 = Lay.paste(z)

            pdb.gimp_layer_set_offsets(z1, x, y)

            z1 = RenderHub.bump(z1, one.d[ok.BUMP])
            Image.close_image(j1)
    return z1


def do_mask(one):
    """
    Mask the edge of a plaque. The Plaque group is changed.

    one: One
        Has cell data.

    plaque_name: string
        to find the fringe layer's plaque layer
    """
    cat = Hat.cat
    j = cat.render.image
    r, c = one.r, one.c
    d = one.plaque_dict
    opacity = d[ok.OPACITY]
    plaque_type = d[ok.PLAQUE_TYPE]
    if opacity and plaque_type != "None":
        z = one.plaque_layer
        if z:
            # mask layer:
            z1 = Lay.add(j, 'Mask', parent=one.parent)
            sel = cat.get_plaque_sel(one.model_name, r, c)

            Sel.load(j, sel)

            if Sel.is_sel(j):
                z1 = do_brush(j, z1, one)
                one.is_mask = True

                Sel.item(z1)
                Sel.invert(j)
                Sel.load(j, sel, option=fu.CHANNEL_OP_INTERSECT)

                if one.is_grid:
                    one.mask_sel += [cat.save_short_term_sel()]
                else:
                    mask = pdb.gimp_layer_create_mask(
                        z,
                        fu.ADD_MASK_SELECTION
                    )
                    pdb.gimp_layer_add_mask(z, mask)
            pdb.gimp_image_remove_layer(j, z1)


def do_paint(j, z, one):
    """
    Paint a fringe texture on the cell fringe layer.

    j: GIMP image
        Is render.

    z: layer
        for fringe material

    one: One
        Has cell data.

    Return: layer or None
        fringe layer
    """
    def clip_cell():
        """Remove material outside of the cell."""
        if one.is_clip:
            # 'sel' is the cell selection:
            Sel.load(j, sel)
            Sel.invert(j)
            Lay.clear_sel(z)

    d = one.d

    pdb.gimp_selection_none(j)

    if Shape.is_rectangular_shape(one.shape):
        x, y, w, h = get_position_info(one)
        Sel.rect(j, x, y, w, h)

    else:
        Sel.select_shape(j, one.plaque)
    if Sel.is_sel(j):
        # Use with clip:
        sel = pdb.gimp_selection_save(j)

        z = do_brush(j, z, one)

        Sel.item(z)

        if Sel.is_sel(j):
            if one.is_plan:
                clip_cell()
            else:
                if one.type_ in FRINGE_MAT:
                    # Apply material and clear outside
                    # of the fringe-layer-selection:
                    z1 = fringe_job[one.type_](j, z, one)

                    if z1:
                        Sel.item(z)
                        Sel.invert_clear(z1)
                        pdb.gimp_image_remove_layer(j, z)
                        z = z1

                clip_cell()

                z = RenderHub.do_mode(z, d)

                if (
                    Shadow.get_type(d[ok.TRI_SHADOW])
                    and not one.is_plan
                ):
                    z.name = one.name
                    z = Shadow.do_shadows(d[ok.TRI_SHADOW], z)
                    clip_cell()
                z.name = one.name
        pdb.gimp_image_remove_channel(j, sel)
    return z


def do_pattern(j, _, one):
    """
    Make a pattern cell fringe.

    j: GIMP image
        Is render.

    _: layer
        not used

    one: One
        Has cell data.

    Return: layer
        Has pattern.
    """
    cat = Hat.cat
    z1 = None
    pattern = one.d[ok.PATTERN]

    if pattern in cat.pattern_list:
        if pattern in cat.pattern_list:
            pdb.gimp_selection_all(j)

            a, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
            w, h = x1 - x, y1 - y
            if a:
                z1 = Lay.add(j, one.name, parent=one.group)
                s = cat.render.size

                Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
                RenderHub.set_fill_context(fg.FILL_DICT)
                pdb.gimp_context_set_pattern(pattern)
                pdb.gimp_drawable_edit_bucket_fill(
                    z1,
                    fu.FILL_PATTERN,
                    min(s[0] - 1, x + w // 2),
                    min(s[1] - 1, y + h // 2)
                )
                z1 = RenderHub.bump(z1, one.d[ok.BUMP])

    else:
        Comm.info_msg(ff.MISSING_ITEM.format("self", "pattern", pattern))
    return z1


def get_position_info(one):
    """
    Return position info.

    one: One
        Has cell data.
    """
    return one.x, one.y, one.w, one.h


def set_foreground_color(one):
    """
    Set the foreground color for the brush to use.

    Alternate colors if using two colors.
    """
    if hasattr(one, 'colors'):
        if one.colors:
            if one.colors[0] == one.color:
                one.color = one.colors[1]
            else:
                one.color = one.colors[0]
        pdb.gimp_context_set_foreground(one.color)


class Fringe:
    """Manage fringe operation."""

    @staticmethod
    def do_custom_cell(one, is_plan):
        """
        Do a custom cell fringe.

        One: one
            Has variables

        Return: tuple or None
            with fringe layer
        """
        parent = one.parent
        d = one.d
        r = fy.CUSTOM_CELL
        z = None
        opacity = d[ok.BRUSH_DICT][ok.OPACITY]
        one.type_ = d[ok.FRINGE_TYPE]
        one.is_mask = one.is_grid = one.is_paint = False

        if opacity and one.type_ != "None":
            one.name = Lay.make_name(parent, nk.CELL_FRINGE)
            shape = one.cell.shape

            if d[ok.OBEY_MARGINS]:
                a = one.cell.pocket

            else:
                a = one.cell.rect

            one.is_clip = d[ok.CLIP_TO_CELL]
            one.is_plan = is_plan
            one.plaque = dispatch[shape](a)
            one.plaque_dict = Path.get_cell_plaque(one.path)
            one.r = one.c = r
            one.shape = shape
            one.w, one.h = a.size
            one.x, one.y = a.position
            one.group = one.parent
            z = do_cell(one)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.DECO)
        return z

    @staticmethod
    def do_grid(one, is_plan):
        """
        Do the cell fringe for a format.

        one: One
            Has variables.

        Return: tuple
            with fringe layer, is mask flag, is layer fringe flag
        """
        def act():
            """Use to lower indentation."""
            m = True

            if m:
                # Is the cell a sub-topleft cell?
                if is_merge_cell:
                    if grid_d[ok.PER_CELL][r][c] == (-1, -1):
                        m = False

            if m:
                m = Shape.is_allocated_cell(one.grid, r, c)

            if m:
                if d[ok.OBEY_MARGINS]:
                    rect = one.grid.get_pocket(r, c)

                else:
                    rect = one.grid.get_merge_cell_rect(r, c)

                one.x, one.y = rect.position
                one.w, one.h = rect.size
                e = one.d = Form.get_form(d, r, c) if is_per_cell else d
                one.type_ = e[ok.FRINGE_TYPE]
                m = one.type_ != "None"

            if m:
                m = True if e[ok.BRUSH_DICT][ok.OPACITY] else False

            if m:
                one.is_clip = e[ok.CLIP_TO_CELL]
                one.r, one.c = r, c
                one.plaque = one.grid.get_plaque(r, c)
                one.plaque_dict = Form.get_form(
                    Path.get_cell_plaque(one.path),
                    r, c
                )
                if not one.group:
                    one.group = Lay.group(j, one.name, parent)
                do_cell(one)
            else:
                one.mask_sel += [cat.get_plaque_sel(
                    one.model_name, r, c
                )]

        cat = Hat.cat
        j = cat.render.image
        z = None
        d = one.d
        parent = one.parent
        one.name = Lay.make_name(parent, nk.CELL_FRINGE)
        is_merge_cell = one.grid.is_merge_cell
        one.group = None
        one.is_plan = is_plan
        one.shape = one.grid.cell_shape
        row, column = one.grid.division
        grid_d = one.grid.grid_d
        is_per_cell = d[ok.PER_CELL]
        pdb.gimp_selection_none(j)
        go = one.is_grid = True
        one.is_mask = one.is_paint = False
        one.mask_sel = []

        if not is_per_cell and d[ok.FRINGE_TYPE] == "None":
            go = False

        if go:
            for r in range(row):
                for c in range(column):
                    act()

        if one.group:
            if one.is_paint:
                z = Lay.merge_group(one.group)
            else:
                pdb.gimp_image_remove_layer(j, one.group)
                z = None

        if one.is_mask:
            pdb.gimp_selection_none(j)

            for i in one.mask_sel:
                Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
            if Sel.is_sel(j):
                z1 = one.plaque_layer
                mask = pdb.gimp_layer_create_mask(z1, fu.ADD_MASK_SELECTION)
                pdb.gimp_layer_add_mask(z1, mask)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.DECO)
        return z

    @staticmethod
    def do_layer(one, is_plan):
        """
        Do fringe for the layer.

        one: One
            Has init variables.

        is_plan: bool
            Is true when the caller is plan.

        Return: tuple
            with fringe layer, is mask flag, is layer fringe flag
        """
        d = one.d
        z = None
        cat = Hat.cat
        one.type_ = d[ok.FRINGE_TYPE]
        one.is_mask = one.is_grid = one.is_paint = False
        if one.type_ != "None":
            j = cat.render.image

            # Preserve:
            foreground = pdb.gimp_context_get_foreground()

            parent = one.group = one.parent
            one.r = one.c = fy.LAYER
            one.is_plan = is_plan
            one.shape = RECTANGLE
            size = cat.render.size

            if d[ok.OBEY_MARGINS]:
                one.y, bottom, one.x, right = one.layer_margin
                one.w = size[0] - one.x - right
                one.h = size[1] - one.y - bottom

            else:
                one.x = one.y = 0
                one.w, one.h = size

            w, h = one.x + one.w, one.y + one.h
            one.plaque = one.x, one.y, w, one.y, w, h, one.x, h
            e = one.plaque_dict = Path.get_layer_plaque(one.path)
            one.name = Lay.make_name(parent, nk.LAYER_FRINGE)
            is_paint = one.is_paint = one.type_ != ng.MASK

            if is_paint:
                one.is_clip = True if d[ok.OBEY_MARGINS] \
                    and d[ok.CLIP_TO_CELL] else False

                z = Lay.add(j, one.name, parent=parent)
                z = do_paint(j, z, one)

            else:
                # fringe mask dependency:
                if e[ok.OPACITY] and e[ok.PLAQUE_TYPE] != "None":
                    one.parent = parent
                    one.make_path = Path.make_layer_plaque_path
                    do_mask(one)

            # Restore:
            pdb.gimp_context_set_foreground(foreground)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.DECO)
        return z


fringe_job = {
    ng.AS_IS: do_as_is,
    ng.BACKDROP: do_backdrop,
    ng.GRADIENT: do_gradient,
    ng.IMAGE: do_image,
    ng.PATTERN: do_pattern,
    ng.PLASMA: do_plasma
}
