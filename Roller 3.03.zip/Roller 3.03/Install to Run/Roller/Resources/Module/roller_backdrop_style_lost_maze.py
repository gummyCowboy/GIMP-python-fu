#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_style_gradient_fill import GradientFill
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat, One
from roller_one_fu import Lay, Sel
from roller_option_preset import Preset
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


def do_grid(cat, z, q, is_vertical=True):
    """
    Draw grid lines.

    The grid lines are either horizontal
    or vertical, but not both.

    cat: Stat
        Has render.

    z: layer
        Draw on layer.

    q: tuple
        arguments for vertical or horizontal lines

    is_vertical: bool
        If it's true, the arguments are for vertical lines.
    """
    args = cat.render.image, z
    q1 = 0, 0, 0, (0, 0, 0), 0

    if is_vertical:
        args += q1 + q + q1

    else:
        args += q + q1 * 2
    pdb.plug_in_grid(*args)


class LostMaze:
    """Use a maze to create regions, a border, and grid lines."""

    @staticmethod
    def do(one):
        """
        Create a Lost Maze backdrop-style.

        one: One
            Has variables.
        """
        cat = Hat.cat
        s = cat.render.size
        d = one.d
        j = cat.render.image
        group = Lay.group(j, one.k)
        z = maze_layer = Lay.add(j, one.k, parent=group)
        w = s[0] // d[ok.COLUMN_MAZE]
        h = s[1] // d[ok.ROW_MAZE]

        # Preserve:
        foreground = pdb.gimp_context_get_foreground()
        background = pdb.gimp_context_get_background()

        pdb.gimp_context_set_foreground((0, 0, 0))
        pdb.gimp_context_set_background((255, 255, 255))
        pdb.plug_in_maze(j, z, w, h, 1, 0, d[ok.RANDOM_SEED], 0, 0)

        z = Lay.clone(z)

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        alpha_layer = Lay.clone(z)
        alpha_layer.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.gimp_selection_none(j)
        pdb.plug_in_edge(j, maze_layer, 1., 0, 0)

        # Expand the border:
        for _ in range(2):
            Lay.dilate(maze_layer)

        pdb.plug_in_colortoalpha(j, maze_layer, (0, 0, 0))

        # horizontal lines:
        h1 = min(max(6, h // 5), s[1])

        do_grid(
            cat,
            z,
            (h1, h1 + 1, 0, (0, 0, 0), 255),
            is_vertical=False
        )
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        e = Preset.get_default(by.GRADIENT_FILL)

        e.update(d)

        one1 = One(d=e)
        e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
            RenderHub.get_gradient_factors(d[ok.GRADIENT_ANGLE])

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        Sel.item(z)

        sel = Hat.cat.save_short_term_sel()

        pdb.gimp_selection_none(j)
        pdb.gimp_image_set_active_layer(j, z)

        z = GradientFill.do_layer(j, one1)

        if e[ok.START_X] < e[ok.END_X]:
            x = 3

        elif e[ok.START_X] > e[ok.END_X]:
            x = -3

        else:
            x = 0

        if e[ok.START_Y] < e[ok.END_Y]:
            y = 3

        elif e[ok.START_Y] > e[ok.END_Y]:
            y = -3

        else:
            y = 0

        pdb.gimp_image_reorder_item(j, z, group, 0)
        Sel.isolate(z, sel)
        RenderHub.do_stylish_shadow(
            z,
            blur=9.,
            intensity=150.,
            offset_x=x,
            offset_y=y
        )
        pdb.gimp_selection_none(j)

        # vertical lines:
        z = Lay.add(
            j,
            one.k,
            parent=group,
            offset=len(group.layers) + 1
        )

        Lay.color_fill(z, (255, 255, 255))
        pdb.gimp_selection_all(j)

        v1 = min(max(12, w // 12), s[0])

        do_grid(cat, z, (v1, v1 + 1, 0, (0, 0, 0), 255))
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        RenderHub.do_stylish_shadow(
            z,
            blur=10,
            intensity=200.,
            is_inner=True
        )
        RenderHub.do_stylish_shadow(z, blur=10, intensity=200.)

        # background:
        z = GradientFill.do_layer(j, one1)

        pdb.gimp_image_reorder_item(j, z, group, 0)
        pdb.gimp_image_lower_item_to_bottom(j, z)
        pdb.gimp_image_reorder_item(j, alpha_layer, group, 4)
        Lay.blur(alpha_layer, 500)

        # grain effect:
        z = Lay.clone(alpha_layer)

        pdb.gimp_image_reorder_item(j, z, group, 6)

        z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
        z.opacity = 100.

        pdb.gimp_drawable_invert(z, 0)

        z = Lay.merge_group(group)
        z1 = Lay.clone(one.z)

        Lay.blur(z1, 500)

        z = Lay.merge(z)

        # Restore:
        pdb.gimp_context_set_foreground(foreground)
        pdb.gimp_context_set_background(background)

        return z
