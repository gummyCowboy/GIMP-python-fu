#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_style_gradient_fill import GradientFill
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat, One
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import colorsys
import gimpfu as fu

pdb = fu.pdb
is_preview = False


def do_diagonal(d, z, color):
    """
    Sample colors and return a gradient's start and end points.

    d: dict
        Has options.

    z: layer
        of backdrop image

    color: list
        of sampled color

    return: tuple
        start point, end point
    """
    a = d[ok.SAMPLE_POINTS]
    q = get_diagonal_points(d, a)
    s = Hat.cat.render.size

    for i in range(a):
        x, y = q[i]
        color[i] = pick_color(d, z, x, y)

    u = q[0][0] / 1. / s[0], q[0][1] / 1. / s[1]
    v = q[-1][0] / 1. / s[0], q[-1][1] / 1. / s[1]
    return u[0], u[1], v[0], v[1]


def do_horizontal(d, z, color):
    """
    Sample colors and return a gradient's start and end points.

    d: dict
        Has options.

    z: layer
        of backdrop image

    color: list
        of sampled color

    return: tuple
        start point, end point
    """
    a = d[ok.SAMPLE_POINTS]
    q = get_horizontal_points(d, a)

    for i in range(a):
        x, y = q[i]
        color[i] = pick_color(d, z, x, y)
    return .0, .5, 1., .5


def do_vertical(d, z, color):
    """
    Sample colors and return a gradient's start and end points.

    d: dict
        Has options.

    z: layer
        of backdrop image

    color: list
        of sampled color

    return: tuple
        start point, end point
    """
    a = d[ok.SAMPLE_POINTS]
    q = get_vertical_points(d, a)

    for i in range(a):
        x, y = q[i]
        color[i] = pick_color(d, z, x, y)
    return .5, .0, .5, 1.


def get_horizontal_points(d, a):
    """
    Get the sample points for the horizontal vector.

    d: dict
        Has options.

    a: int
        sample point count

    return: list
        of sample point coordinate
    """
    x = 0
    s = Hat.cat.render.size
    y = min(int(s[1] * d[ok.START_Y]), s[1] - 1)
    q = []
    w = s[0] // (a + 1)

    for i in range(a):
        x = min(x + w, s[0] - 1)
        q.append((x, y))
    return q


def get_diagonal_points(d, a):
    """
    Get the sample points for the topleft vector.

    d: dict
        Has options.

    a: int
        sample point count

    return: list
        of sample point coordinate
    """
    s = Hat.cat.render.size
    f = d[ok.DIAGONAL_ROTATION]
    x, y = RenderHub.get_point_on_rectangle(s, f)
    x1, y1 = RenderHub.get_point_on_rectangle(s, f + 180)
    q = []
    b = a + 1

    # run, rise of slope:
    w = (x1 - x) / b
    h = (y1 - y) / b

    for i in range(a):
        x = min(x + w, s[0] - 1)
        y = min(y + h, s[1] - 1)
        q.append((x, y))
    return q


def get_vertical_points(d, a):
    """
    Get the sample points for the vertical vector.

    d: dict
        Has options.

    a: int
        sample point count

    return: list
        of sample point coordinate
    """
    s = Hat.cat.render.size
    x = min(int(s[0] * d[ok.START_X]), s[0] - 1)
    y = 0
    q = []
    h = s[1] // (a + 1)

    for i in range(a):
        y = min(y + h, s[1] - 1)
        q.append((x, y))
    return q


def pick_color(d, z, x, y):
    """
    Pick a color from the canvas.

    d: dict
        Has options.

    z: layer
        the backdrop image

    x, y: int
        coordinate to pick from

    Return: color
        the color
        RGBA
    """
    return pdb.gimp_image_pick_color(
        z.image, z,
        x, y,
        Fu.PickColor.NO_SAMPLE_MERGED,
        Fu.PickColor.YES_SAMPLE_RADIUS,
        d[ok.SAMPLE_RADIUS]
    )


def show_gradient(z, d, e, a, x, color):
    """
    Draw the image gradient.

    z: layer
        with backdrop image

    d: dict
        Has options.

    e: dict
        modified options

    a: int
        sample points

    x: int
        sample vector index
    """
    grad = e[ok.GRADIENT] = pdb.gimp_gradient_new(d[ok.NAME])
    q = do_vertical, do_horizontal, do_diagonal

    if a > 2:
        pdb.gimp_gradient_segment_range_split_uniform(grad, 0, 0, a - 1)

    e[ok.START_X], e[ok.START_Y], e[ok.END_X], e[ok.END_Y] = q[x](e, z, color)

    for x in range(a - 1):
        opacity = color[x].alpha * 100

        pdb.gimp_gradient_segment_set_left_color(
            grad,
            x,
            color[x],
            opacity
        )

        opacity = color[x + 1].alpha * 100
        pdb.gimp_gradient_segment_set_right_color(
            grad,
            x,
            color[x + 1],
            opacity
        )

    z = GradientFill.do_layer(z.image, One(d=e, k="Gradient"))

    if d[ok.KEEP_GRADIENT]:
        # Store image gradients so they can
        # be deleted before the program closes:
        Hat.cat.image_gradients_created.append(grad)

        # This gradient is kept. The gradient is
        # saved to file when GIMP closes:
        Hat.cat.image_gradient_used = grad
    else:
        pdb.gimp_gradient_delete(grad)
    return z


def show_preview(z, d, a, x, option_group, color):
    """
    Show a preview with the sample areas filled with sampled colors.

    z: layer
        of backdrop image

    d: dict
        Has options.

    a: int
        sample point count

    x: int
        vector index

    color: list
        of sampled color

    option_group: dict
        Has change flag.
    """
    j = Hat.cat.render.image
    group = Lay.group(j, "Preview")

    pdb.gimp_selection_none(j)
    pdb.gimp_context_set_foreground((0, 0, 0))

    # Keep RenderProduct from removing preview:
    option_group.changed = True

    q = (
        get_vertical_points,
        get_horizontal_points,
        get_diagonal_points
    )[x](d, a)
    (do_vertical, do_horizontal, do_diagonal)[x](d, z, color)
    w = d[ok.SAMPLE_RADIUS]
    w1 = w + w
    w2 = w + 1
    w3 = w2 * 2

    # Draw line:
    line = q[0][0], q[0][1], q[-1][0], q[-1][1]
    line_layer = Lay.add(j, "Line", parent=group)
    sample_layer = Lay.add(j, "Sample", parent=group)
    color1 = color

    RenderHub.set_brush_details()
    pdb.gimp_paintbrush_default(line_layer, len(line), line)

    for x1, u in enumerate(q):
        x, y = u
        r, g, b, alpha = [(i / 255.) for i in color1[x1]]
        hsv = colorsys.rgb_to_hsv(r, g, b)
        color = (0, 0, 0) if hsv[2] > .5 else (255, 255, 255)

        if alpha < 1.:
            z = Lay.add(j, "Alpha", parent=group)
            z1 = Lay.add(j, "Alpha 2", parent=group)
            z1.opacity = 100. * alpha

        else:
            z = z1 = sample_layer

        Sel.ellipse(j, x - w2, y - w2, w3, w3, fu.CHANNEL_OP_REPLACE)
        Sel.fill(z, color)
        Sel.ellipse(j, x - w, y - w, w1, w1, fu.CHANNEL_OP_REPLACE)

        if z1.opacity:
            Sel.fill(z1, (r, g, b))
        if z1.opacity < 100.:
            # Remove the material as it is visible when semi-opaque:
            Lay.clear_sel(line_layer, keep_sel=True)
            Lay.clear_sel(z)
    return Lay.merge_group(group)


class ImageGradient:
    """Create a gradient from an image."""

    @staticmethod
    def do(one):
        """
        Create an Image Gradient backdrop-style.

        The ImageGradient's Preview button does not disable
        if the preview mode is set to 'Show Samples'.

        one: One
            Has variables.

        Return: layer or None
            with Image Gradient
        """
        global is_preview

        cat = Hat.cat
        d = one.d
        z = one.z
        if Lay.has_pixel(z) and d[ok.OPACITY]:
            a = d[ok.SAMPLE_POINTS]
            e = deepcopy(d)
            e[ok.OFFSET] = 0
            color = [0] * a
            x = bs.VECTOR.index(d[ok.SAMPLE_VECTOR])
            is_preview = cat.product.is_preview

            # Preserve:
            q = pdb.gimp_context_get_foreground()

            pdb.gimp_context_set_sample_transparent(1)

            if d[ok.PREVIEW_MODE] == bs.SHOW_SAMPLE and is_preview:
                z = show_preview(z, d, a, x, cat.group_dict[one.path], color)

            else:
                z = show_gradient(z, d, e, a, x, color)

                Lay.clone(one.z)
                z = Lay.merge(z)

            # Restore:
            pdb.gimp_context_set_foreground(q)

            return z
