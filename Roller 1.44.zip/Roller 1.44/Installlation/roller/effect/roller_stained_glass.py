#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from random import randint, seed
from roller_constant import OptionKey, SessionKey
from roller_border_line import BorderLine
from roller_fu import Lay, Sel
import gimpfu as fu


class StainedGlass(BorderLine):
    """Create a frame with colorful transparent glass."""
    name = SessionKey.STAINED_GLASS
    filler_width_low, filler_width_high = 35, 55

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        BorderLine.__init__(
                self,
                d,
                stat,
                name=SessionKey.STAINED_GLASS,
                filler=self.draw_glass,
                has_filler_shadow=True,
                reflect=1
            )

    def draw_glass(self, z, d):
        z = self.do_rotated_layer(z, d, self.draw_glass_panes)

        z.name = Lay.get_layer_name(
            self.name, self.stat) + " Pane"

        e = deepcopy(d)
        e[OptionKey.ROTATE] = randint(-45, 0)
        z1 = self.do_rotated_layer(z, e, self.draw_glass_panes)
        z1.mode = fu.LAYER_MODE_DIFFERENCE
        z = self.fill_layer = Lay.merge(self.stat.render, z1)
        z.opacity = 60.

        Sel.isolate(self.stat.render, z, self.fill_sel)
        self.blur_bg(d, z)
        return z

    def draw_glass_panes(self, j, z, d):
        """
        Draw the glass panes.

        j: GIMP image
        z: layer
        d: sub-session dict

        Return the glass layer.
        """
        # A random sequence will reproduce itself given the same seed:
        seed(d[OptionKey.RANDOM_SEED])
        return self.draw_color_rectangles(
            j, z, d[OptionKey.PANE_WIDTH], d[OptionKey.PANE_HEIGHT])
