#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from random import randint, seed
from roller_border_line import BorderLine
from roller_constant import ForBackdropStyle, OptionKey, SessionKey
from roller_fu import Lay, Sel
from roller_grid import Grid
from roller_line_graph import LineGraph
import gimpfu as fu


class MazeMirror(BorderLine):
    """Add a round holes to a frame that fits around a BorderLine frame."""
    name = SessionKey.MAZE_MIRROR
    width_low, width_high = 3, 6
    row, column = 2, 2

    def __init__(self, d, stat):
        """
        d: dict
            sub-session dict

        stat: Stat
            global variables
        """
        self.gap_type_widget = self.maze_type_widget = None
        self.stop_length_widget = self.scatter_count_widget = None
        BorderLine.__init__(
                self,
                d,
                stat,
                name=SessionKey.MAZE_MIRROR,
                framer=self.make_line_sel,
            )

    def _do_border(self, d, row, column):
        """
        Draw border of mazes around the layer.

        d: dict
            sub-session dict

        row, column: int
            row and column count for placing a maze
            These counts are approximately half of the
            user-specified row and column count.
        """
        for r in range(row):
            self._draw_maze(r, 0)
        for c in range(column):
            self._draw_maze(0, c)

    def _do_fill(self, d, row, column):
        """
        Draw mazes that fill layer.

        d: dict
            sub-session dict

        row, column: int
            row and column count for maze placement
        """
        for r in range(row):
            for c in range(column):
                self._draw_maze(r, c)

    def _do_scattered_connectors(self, d, row, column):
        """
        Draw mazes randomly.

        d: dict
            sub-session dict

        row, column: int
            row and column count for maze placement
        """
        connector = []
        ok = OptionKey

        if d[ok.GAP_TYPE] == ForBackdropStyle.RANDOM:
            # Try to get the connector to draw
            # so that it's not on the border:
            r1 = min(1, row - 1)
            c1 = min(1, column - 1)
            for _ in range(self.scatter_count):
                r = randint(r1, row - 1)
                c = randint(c1, column - 1)
                q = r, c

                while q in connector:
                    r = randint(1, row)
                    c = randint(1, column)
                    q = r, c
                connector.append(q)

        else:
            r = c = 0
            for _ in range(self.scatter_count):
                c += d[ok.CELL_GAP]
                while c > column - 1:
                    c -= max(1, column - 1)
                    r += 1

                while r > row - 1:
                    r -= max(1, row - 1)
                connector.append((r, c))
        for q in connector:
            r, c = q[0], q[1]
            if self.direction == ForBackdropStyle.COUNTER_CLOCKWISE:
                self.line_graph.add_line(
                        (r, c),
                        (r + 1, c),
                        LineGraph.real
                    )

            else:
                self.line_graph.add_line(
                        (r, c),
                        (r, c + 1),
                        LineGraph.real
                    )

    def _do_scattered_mazes(self, d, row, column):
        """
        Draw mazes randomly.

        d: dict
            sub-session dict

        row, column: int
            row and column count for maze placement
        """
        maze = []
        ok = OptionKey

        if d[ok.GAP_TYPE] == ForBackdropStyle.RANDOM:
            for _ in range(self.scatter_count):
                r = randint(0, row - 1)
                c = randint(0, column - 1)
                q = r, c

                while q in maze:
                    r = randint(0, row - 1)
                    c = randint(0, column - 1)
                    q = r, c
                maze.append(q)

        else:
            r = c = 0
            for _ in range(self.scatter_count):
                c += d[ok.CELL_GAP]
                while c > column - 1:
                    c -= max(1, column - 1)
                    r += 1

                while r > row - 1:
                    r -= max(1, row - 1)
                maze.append((r, c))
        for q in maze:
            r, c = q[0], q[1]
            self._draw_maze(r, c)

            if self.direction == ForBackdropStyle.COUNTER_CLOCKWISE:
                self.line_graph.add_line(
                        (r, c),
                        (r + 1, c),
                        LineGraph.real
                    )

            else:
                self.line_graph.add_line(
                        (r, c),
                        (r, c + 1),
                        LineGraph.real
                    )

    def _draw_corners(self):
        """
        Flip the top-left-quarter selection into the other corners.
        """
        j = self.stat.render
        z = Lay.add(self.stat.render, self.name)
        w = self.stat.width / 2 + self.stat.width % 2
        h = self.stat.height / 2 + self.stat.height % 2

        Sel.fill(z, (0, 0, 0))
        Sel.none(j)
        Sel.rect(self.stat.render, 0, 0, w, h)
        Sel.kleer(j, z)

        z = Lay.clone(j, z)

        Lay.flip(z, horz=True)

        z = Lay.merge(j, z)
        z = Lay.clone(j, z)

        Lay.flip(z)

        z = Lay.merge(j, z)

        Sel.item(j, z)
        Lay.bury(j, z)

    def _draw_clockwise_maze(self, r, c):
        """
        Draw a maze that appears to be rotating clockwise.

        r, c: int
            row, column: the maze position
        """
        line_length = [0, 0]
        x, y, line_length[0], line_length[1] = self.grid.cell(r, c)
        x1, y1 = x, y
        x2 = 0
        is_right = True
        is_up = is_left = is_down = False
        while line_length[x2] > self.stop_gap:
            if is_down:
                x2 = 1
                w = self.line_width
                h = line_length[x2]

                # next line:
                is_down = False
                is_left = True
                x1 = x
                y1 = y + line_length[x2] - self.line_width

            elif is_right:
                x2 = 0
                w = line_length[x2]
                h = self.line_width

                # next line:
                is_right = False
                is_down = True
                x1 = x + line_length[x2]
                y1 = y

            elif is_up:
                x2 = 1
                w = self.line_width
                h = line_length[x2]
                y = y - line_length[x2]

                # next line:
                is_up = False
                is_right = True
                x1 = x
                y1 = y

            elif is_left:
                x2 = 0
                w = line_length[x2]
                h = self.line_width
                x -= line_length[x2]

                # next line:
                is_left = False
                is_up = True
                x1 = x
                y1 = y

            Sel.rect(self.stat.render, x, y, w, h)

            # next line:
            line_length[x2] = int(line_length[x2] * .75)

            x, y = x1, y1
            x2 = int(not x2)
            line_length[x2] = int(line_length[x2] * .85)

    def _draw_counter_clockwise_maze(self, r, c):
        """
        Draw a maze that appears to be rotating counter-clockwise.

        r, c: int
            row, column: the maze position
        """
        line_length = [0, 0]
        x, y, line_length[0], line_length[1] = self.grid.cell(r, c)
        x1, y1 = x, y
        x2 = 1
        is_down = True
        is_up = is_left = is_right = False
        while line_length[x2] > self.stop_gap:
            if is_down:
                x2 = 1
                w = self.line_width
                h = line_length[x2]

                # next line:
                is_right = True
                is_down = False
                x1 = x
                y1 = y + line_length[x2]

            elif is_right:
                x2 = 0
                w = line_length[x2]
                h = self.line_width

                # next line:
                is_up = True
                is_right = False
                x1 = x + line_length[x2] - self.line_width
                y1 = y

            elif is_up:
                x2 = 1
                w = self.line_width
                h = line_length[x2]
                y = y - line_length[x2]

                # next line:
                is_up = False
                is_left = True
                x1 = x
                y1 = y

            elif is_left:
                x2 = 0
                w = line_length[x2]
                h = self.line_width
                x -= line_length[x2]

                # next line:
                is_left = False
                is_down = True
                x1 = x
                y1 = y

            Sel.rect(self.stat.render, x, y, w, h)

            # next line:
            line_length[x2] = int(line_length[x2] * .75)

            x, y = x1, y1
            x2 = int(not x2)
            line_length[x2] = int(line_length[x2] * .85)

    def _draw_maze(self, r, c):
        """
        Draw a maze.

        r, c: int
            row, column: the maze cell position
        """
        if self.direction == ForBackdropStyle.COUNTER_CLOCKWISE:
            self._draw_counter_clockwise_maze(r, c)

        else:
            self._draw_clockwise_maze(r, c)

    def make_line_sel(self, d):
        """
        Modify the current selection with selected circles.

        Add the circle selection to the border selection
        within the bounds of the filler selection.

        d: dict
            sub-session dict
        """
        ok = OptionKey
        j = self.stat.render
        sel = self.stat.save_channel()
        a = ForBackdropStyle.MAZE_TYPE
        row = d[ok.ROW] / 2 + d[ok.ROW] % 2
        column = d[ok.COLUMN] / 2 + d[ok.COLUMN] % 2
        self.grid = Grid(self.stat.size, d[ok.ROW], d[ok.COLUMN])
        self.line_width = d[ok.LINE_WIDTH]

        seed(d[ok.RANDOM_SEED])
        Sel.none(j)

        if d[ok.COMPOSITION_BORDER_WIDTH]:
            Sel.all(j)
            Sel.shrink(j, d[ok.COMPOSITION_BORDER_WIDTH])
            Sel.invert(j)
            sel1 = self.stat.save_channel()

        else:
            sel1 = None

        self.stop_gap = d[ok.STOP_LENGTH]
        self.direction = d[ok.DIRECTION]
        self.scatter_count = min(d[ok.SCATTER_COUNT], row * column)

        if d[ok.MAZE_TYPE] in (a[0], a[1]):
            self.line_graph = LineGraph(
                    d[ok.ROW],
                    d[ok.COLUMN],
                    self.stat,
                    self.line_width
                )

            if d[ok.MAZE_TYPE] == a[0]:
                self._do_scattered_connectors(d, row, column)

            elif d[ok.MAZE_TYPE] == a[1]:
                self._do_scattered_mazes(d, row, column)

            self.line_graph.add_line_to_disconnects()
            self.line_graph.draw_lines()

        elif d[ok.MAZE_TYPE] == a[2]:
            self._do_border(d, row, column)

        else:
            self._do_fill(d, row, column)

        self._draw_corners()

        Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
        if sel1:
            Sel.load(j, sel1, option=fu.CHANNEL_OP_ADD)

    def update_widgets(self, widget, controls):
        """
        Update widget visibility.

        Is part of the UIOption class template.

        widget: Widget or None
        controls: iterable
            list of controls in the options window
        """
        ok = OptionKey

        if not self.gap_type_widget:
            for i in controls:
                if i.key == ok.GAP_TYPE:
                    self.gap_type_widget = i

                elif i.key == ok.MAZE_TYPE:
                    self.maze_type_widget = i

                elif i.key == ok.STOP_LENGTH:
                    self.stop_length_widget = i

                elif i.key == ok.CELL_GAP:
                    self.cell_gap_widget = i

                elif i.key == ok.SCATTER_COUNT:
                    self.scatter_count_widget = i

        if not widget:
            for i in (self.maze_type_widget, self.gap_type_widget):
                self.update_widget(i)

        else:
            self.update_widget(widget)

    def update_widget(self, widget):
        """
        Update widgets based various dependencies of a given widget.

        widget: Widget
        """
        fbs = ForBackdropStyle
        value = widget.get_value()
        key = widget.key

        if key == OptionKey.MAZE_TYPE:
            if value in (fbs.FILLED, fbs.BORDER, fbs.SCATTERED_MAZES):
                # mazes:
                self.show_widget_box(self.stop_length_widget)

            else:
                self.hide_widget_box(self.stop_length_widget)

            if value in (fbs.FILLED, fbs.BORDER):
                self.hide_widget_box(self.cell_gap_widget)
                self.hide_widget_box(self.scatter_count_widget)
                self.hide_widget_box(self.gap_type_widget)

            else:
                self.show_widget_box(self.cell_gap_widget)
                self.show_widget_box(self.scatter_count_widget)
                self.show_widget_box(self.gap_type_widget)

        if key == OptionKey.GAP_TYPE:
            if value == fbs.RANDOM:
                self.hide_widget_box(self.cell_gap_widget)

            else:
                self.show_widget_box(self.cell_gap_widget)
