#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForColor
import gtk


class REventBox(gtk.EventBox):
    """This is a custom GTK EventBox."""

    def __init__(self, color):
        """
        color: gtk color component
            None, int, tuple, or GTK color
        """
        super(gtk.EventBox, self).__init__()
        if color is not None:
            if isinstance(color, int):
                q = gtk.gdk.Color(color, color, ForColor.MAX_COLOR)

            elif isinstance(color, tuple):
                q = gtk.gdk.Color(*color)

            else:
                q = color
            self.modify_bg(gtk.STATE_NORMAL, q)
