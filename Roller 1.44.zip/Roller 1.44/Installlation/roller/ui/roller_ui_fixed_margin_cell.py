#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForFormat
from roller_ui_cell import UICell


class UIFixedMarginCell(UICell):
    """Create the fixed-value margin cell window."""

    def __init__(self, d):
        """
        d: dict
            UICell dict
        """
        UICell.__init__(self, d)

    def draw_cell(self, d):
        """
        Call for each cell.

        Draw margin Labels and SpinButtons.
        Is part of the UICell window template.

        d: dict
            cell dict
        """
        # These widgets use an index:
        w, h = self.stat.width - 1, self.stat.height - 1
        self.draw_margin_cell(
                d,
                ForFormat.CELL_MARGIN_FIXED_SPIN_BUTTON_KEY,
                (h, h, w, w)
            )
