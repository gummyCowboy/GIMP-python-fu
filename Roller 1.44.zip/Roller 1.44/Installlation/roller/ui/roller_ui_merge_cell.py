#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForColor, ForWidget
from roller_box import RollerBox
from roller_ui_cell import UICell
from roller_switch_button import SwitchButton


class UIMergeCell(UICell):
    """Create the merge cell window."""

    def __init__(self, d):
        """
        Begin the merge cell window creation process.

        d: dict
        """
        UICell.__init__(self, d)

    @staticmethod
    def _calc_bottom_right(d):
        """
        Return the row and column for the
        bottom-right cell of a merged cell group.

        d: dict
            top-left cell dict
        """
        return d['row'] + d['size'][0] - 1, d['column'] + d['size'][1] - 1

    def _generate_group(self, slices):
        """
        Slice organize themselves into one or two groups.

        A slice is a cell group with a piece of itself
        removed by a ‟connect_up” or ‟connect_left” process
        and the resulting merge group.

        slices: dict
            a dict of dictionaries where each defines a group of cells
        """
        for k in slices:
            # Sort the two possible groups
            # into a larger and smaller group (short).
            # The larger group will have the greater cell count.
            # The smaller group will be the cells not in the larger group.
            # If there's only one group,
            # the smaller group won't get initialized.
            #
            # Starts by finding the longer and shorter row.
            u = slices[k]['size']
            long_row_width = long_row_height = 0
            long_col_width = long_col_height = 0
            short_col_width = short_row_height = 0
            short_row_width = short_col_height = 0
            start_long_row = [0, 0]
            start_short_row = [0, 0]
            start_long_col = [0, 0]
            start_short_col = [0, 0]

            # The key is the topleft coordinate (r, c):
            for r in range(k[0], k[0] + u[0]):
                row_width = 0
                first_col = -1

                for c in range(k[1], k[1] + u[1]):
                    if self._is_vector(k, r, c):
                        row_width += 1
                        if first_col < 0:
                            first_col = c

                    elif row_width:
                        break

                if row_width > long_row_width:
                    if long_row_width > 0:
                        # Second group inherits from the first group:
                        short_row_width = long_row_width
                        short_row_height = long_row_height
                        start_short_row = start_long_row

                    # Initialize first group:
                    long_row_width = row_width
                    long_row_height = 1
                    start_long_row = r, first_col

                elif row_width:
                    # The vector is long or short:
                    if row_width == long_row_width:
                        long_row_height += 1

                    else:
                        if short_row_height:
                            # Add another row:
                            short_row_height += 1

                        else:
                            # Initialize second group:
                            short_row_width = row_width
                            start_short_row = r, first_col
                            short_row_height = 1

            # Start finding the long and short column:
            for c in range(k[1], k[1] + u[1]):
                col_height = 0
                first_row = -1

                for r in range(k[0], k[0] + u[0]):
                    if self._is_vector(k, r, c):
                        col_height += 1
                        if first_row < 0:
                            first_row = r

                    elif col_height:
                        break

                if col_height > long_col_height:
                    if long_col_height > 0:
                        # Second group inherits from the first group:
                        short_col_width = long_col_width
                        short_col_height = long_col_height
                        start_short_col = start_long_col

                    # Initialize first group:
                    long_col_height = col_height
                    long_col_width = 1
                    start_long_col = first_row, c

                elif col_height:
                    # The vector is long or short:
                    if col_height == long_col_height:
                        long_col_width += 1

                    else:
                        if short_col_height:
                            short_col_width += 1

                        else:
                            # Initialize second group:
                            short_col_width = 1
                            short_col_height = col_height
                            start_short_col = first_row, c

            row_cells = long_row_width * long_row_height
            col_cells = long_col_height * long_col_width
            v = 0

            if row_cells >= col_cells:
                u = long_row_height, long_row_width
                d = self.table[start_long_row[0]][start_long_row[1]]

                # Process second group if it was initialized:
                if short_row_width > 0:
                    v = short_row_height, short_row_width
                    d1 = self.table[
                        start_short_row[0]][start_short_row[1]]

            else:
                u = long_col_height, long_col_width
                d = self.table[start_long_col[0]][start_long_col[1]]

                # Process second group if it was initialized:
                if short_col_height > 0:
                    v = short_col_height, short_col_width
                    d1 = self.table[
                        start_short_col[0]][start_short_col[1]]

            self._set_group(d, u)

            # Set the second group if there was one:
            if v:
                self._set_group(d1, v)

    @staticmethod
    def _is_outside(d, r, c, s):
        """
        Return true if the cell has cells that
        exist outside the bounds of a rectangle.

        d: dict
            cell dict

        r, c: int
            row, column

        s: tuple (w, h)
            bounds
        """
        if d['row'] < r or d['column'] < c or d['row'] \
                + d['size'][0] > r + s[0] or d['column'] \
                + d['size'][1] > c + s[1]:
            return 1

    def _merge_groups(self, top, origin):
        """
        Merge two groups into a new group.

        top: dict
            top-left cell dict

        origin: dict
            top-left cell dict
        """
        # Get bottom-rights:
        o_b_r = UIMergeCell._calc_bottom_right(origin)
        t_b_r = UIMergeCell._calc_bottom_right(top)

        # Merge group settings:
        m_pos = min(
            top['row'], origin['row']), min(top['column'], origin['column'])

        m_b_r = tuple(max(o, m) for o, m in zip(o_b_r, t_b_r))
        diff = tuple(n - m for n, m in zip(m_b_r, m_pos))
        v = diff[0] + 1, diff[1] + 1

        # Get top-left cell's dict of the merged group:
        m = self.table[m_pos[0]][m_pos[1]]

        # Create a dictionary of potential slices.
        #
        # Slices are groups that are part of a merged group rectangle,
        # but are exclusive of top and origin groups.
        #
        # Slices also have cells outside the bounds of the merged group.
        sliced = {}

        for r in range(m_pos[0], m_pos[0] + v[0]):
            for c in range(m_pos[1], m_pos[1] + v[1]):
                d = self.table[r][c]
                if UICell._is_group(d):
                    t = self._get_topleft(d)
                    if t['row'] != top['row'] or t['column'] != top['column']:
                        if (
                                t['row'] != origin['row'] or
                                t['column'] != origin['column']
                                ):
                            if UIMergeCell._is_outside(
                                    t, m['row'], m['column'], v):
                                key = t['row'], t['column']
                                if key not in sliced:
                                    sliced[key] = {'size': t['size']}

        self._set_group(m, v)
        self._generate_group(sliced)

    def _set_group(self, top, s):
        """
        Set a group's sub-cell's attributes and the group's appearance.

        top: dict
            a new group dict

        s: tuple (w, h)
            group's new dimensions
        """
        top['size'] = s
        start, end = UICell._get_start_end_of_top(top)

        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                if r != top['row'] or c != top['column']:
                    UICell._set_subtop(top, self.table[r][c])
        self._update_block(start, end)

    def connect_left(self, d):
        """
        Connect cells horizontally.

        d: dict
            cell dict
        """
        origin = self._get_topleft(d=d)
        top = self._get_topleft(u=(d['row'], d['column'] - 1))
        self._merge_groups(top, origin)

    def connect_up(self, d):
        """
        Connect cells vertically.

        d: dict
            cell dict
        """
        origin = self._get_topleft(d=d)
        top = self._get_topleft(u=(d['row'] - 1, d['column']))
        self._merge_groups(top, origin)

    def draw_cell(self, d):
        return

    def draw_connector(self, r, c):
        """
        Draw connector button.

        r, c: int
            row, column
        """
        # connector button:
        if r % 2:
            # left button:
            p = self.split_horz, self.connect_left
            r3, c3 = r, c + 1
            r4, c4 = r / 2, c / 2 - 1
            q = (5, 5, 0, 0)

        else:
            # upper button:
            p = self.split_vert, self.connect_up
            r3, c3 = r + 1, c
            r4, c4 = r / 2 - 1, c / 2
            q = (0, 0, 5, 5)

        g = RollerBox(ForWidget.HBOX, align=(0, 0, 1, 1), padding=q)
        g1 = self.buttons[r4][c4] = SwitchButton(
            "+", p, r3, c3, g, self.table)

        g1.set_size(15, 15)
        g1.set_color(ForColor.BACKGROUND_BUTTON_COLOR)
        return g, g1

    def split_horz(self, d):
        """
        The user has clicked a horizontal connector in a disconnect state.

        Divide the group containing this connector by two columns.

        d: dict
            cell dict
        """
        self.split_cells = True
        c = d['column']
        top = self._get_topleft(d=d)
        w = c - top['column']
        w1 = top['size'][1] - w
        e = self.table[top['row']][top['column'] + w]

        self._set_group(e, (top['size'][0], w1))
        self._set_group(top, (top['size'][0], w))
        self.split_cells = False

    def split_vert(self, d):
        """
        The user has clicked a vertical connector in a disconnect state.

        Divide the group containing this connector by two rows.

        d: dict
            cell dict
        """
        self.split_cells = True
        r = d['row']
        top = self._get_topleft(d=d)
        h = r - top['row']
        h1 = top['size'][0] - h
        e = self.table[top['row'] + h][top['column']]

        # Create a new groups from the split:
        self._set_group(e, (h1, top['size'][1]))
        self._set_group(top, (h, top['size'][1]))
        self.split_cells = False
