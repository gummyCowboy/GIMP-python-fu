#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import WidgetKey
import gtk


class Widget:
    """This is the base widget for the custom widgets."""

    def __init__(self, callback, **d):
        """
        Has widget factored functions and attributes.

        Sub-widget classes need to init the Widget
        class before connecting events.

        callback: function
            Connect widget with event handler.

        d: dict
            widget dict
        """
        wk = WidgetKey
        self._callback = callback
        self.wig = self.widget = d[wk.WIDGET]
        self.key = d[wk.KEY] if wk.KEY in d else None

        # attached label widget:
        self.label = d[wk.LABEL] if wk.LABEL in d else None

    def callback(self, *_):
        """
        The widget changed or was activated.

        Call the widget's feedback function.
        """
        self._callback(self)

    def enable(self, *_):
        """
        Make the widget operational.

        If the widget has an attached label,
        then it is also enabled.
        """
        self.widget.set_sensitive(1)
        if self.label:
            self.label.set_sensitive(1)

    def disable(self, *_):
        """
        Make the widget inoperable.

        If the widget has an attached label,
        then it is also disabled.
        """
        self.widget.set_sensitive(0)
        if self.label:
            self.label.set_sensitive(0)
