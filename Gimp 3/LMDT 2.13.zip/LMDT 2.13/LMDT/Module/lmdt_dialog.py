#!/usr/bin/env python3
from lmdt_output import (
    ALPHA, DARK, LIGHT, MID_NAME, MIDTONE, Output, _
)
import gi       # type: ignore
import sys

gi.require_version('Gtk', '3.0')

from gi.repository import Gimp, GimpUi, Gtk

VERSION = 2.13

MARGIN = 8

# row offset in the Gtk.Grid for the Selection Channel option
MASK_TYPE_ROW = 3
MASK_GROUP_ROW = MASK_TYPE_ROW + 5
ALPHA_ROW = MASK_GROUP_ROW + 2
GROUP_ROW = ALPHA_ROW + 4

MASK_GROUP = LIGHT, MIDTONE, DARK

# Send Button response.
# {Gtk.ResponseType: responder function}
response_d = {
    Gtk.ResponseType.CANCEL: None,
    Gtk.ResponseType.DELETE_EVENT: None,
    Gtk.ResponseType.OK: None
}


def add_grid(vbox):
    """
    Add a Gtk.Grid to a Gtk.VBox.

    Return: Gtk.Grid
        newly created
    """
    grid = Gtk.Grid()

    grid.set_column_homogeneous(True)
    grid.set_border_width(4)
    grid.set_column_spacing(5)
    grid.set_row_spacing(1)
    vbox.add(grid)
    return grid


def add_grid_header(grid):
    """
    Add mask type label to the top a Gtk.Grid.

    grid: Gtk.Grid
        Receive header label.
    """
    label_q = ()

    for i, n in enumerate((_("Light"), _("Midtone"), _("Dark"))):
        label_q += (create_label(n),)

        # column, 'i'; row, '0'; cell width, '1'; cell height, '1'
        grid.attach(label_q[-1], i, 1, 1, 1)

    # Make the RadioButtons all the same size.
    same_size = Gtk.SizeGroup(mode=Gtk.SizeGroupMode.BOTH)

    for g in label_q:
        same_size.add_widget(g)

    # separator
    sep = Gtk.HSeparator.new()
    sep1 = Gtk.HSeparator.new()

    grid.attach(sep, 0, 0, 3, 1)
    grid.attach(sep1, 0, 2, 3, 1)


def create_checkbutton(label, grid, column, row):
    """
    Create a Gtk.CheckButton and add to a Gtk.Grid.

    label: string
        Give the Gtk.Checkbox a visible descriptor.

    grid: Gtk.Grid
        Contain the CheckButton.

    column: int
        Place CheckButton in a Gtk.Grid cell.
        0 to n

    row: int
        Place CheckButton in a Gtk.Grid cell.
        0 to n

    Return: Gtk.CheckButton
        newly created
    """
    g = Gtk.CheckButton.new_with_label(label)

    # cell width, '1'; cell height, '1'
    grid.attach(g, column, row, 1, 1)

    return g


def create_label(text):
    """
    Create a Gtk.Label

    text: string
        Display value.
    """
    return Gtk.Label(text)


def add_hint_box(vbox):
    """
    Place GIMP's hint box on top of the dialog.

    vbox: Gtk.VBox
        Has vertical packing to receive HintBox.
    """
    vbox.pack_start(
        GimpUi.HintBox.new(_(
            "Check luminosity mask-type to"
            " create mask for selected layer(s).\t\t\t\t"
        )),
        False,                  # expand
        False,                  # fill
        MARGIN                  # padding
    )


def show_no_selected_layer_message():
    """
    Open a Gimp.message with a no selected layer message.
    """
    Gimp.message(
        _(
            "There is no layer selected. Please\n"
            "select a layer and try again."
        )
    )


def get_selected_drawable_layer(q):
    """
    Create a list of selected 'Gimp.Layer'.

    q: list
        [Gimp.Layer, ..., Gimp.GroupLayer, ...]
        Remove GroupLayer from list.

    Return: list
        [Gimp.Layer, ...]
    """
    # Filter out GroupLayer.
    return [
        i for i in q if not Gimp.Item.id_is_group_layer(i.get_id())
    ]


class Dialog:
    """Create a GimpUI.Dialog having Cancel, Preview, and Accept buttons."""

    def __init__(self, add_widget_p, response_p):
        """
        add_widget_p: function
            Add widget to the Dialog's VBox.

        response_p: function
            Handle Cancel, Preview, and Accept button action.
        """
        self.dialog = GimpUi.Dialog(
            use_header_bar=Gtk.Settings.get_default().
            get_property("gtk-dialogs-use-header"),
            title=f"Luminosity Mask Drive-Thru {VERSION}"
        )
        align_vbox = Gtk.Alignment()
        align_vbox.set_padding(0, 0, MARGIN, MARGIN)
        vbox = Gtk.VBox()

        align_vbox.add(vbox)
        self.dialog.get_content_area().add(align_vbox)
        self.dialog.add_button(_("_Cancel"), Gtk.ResponseType.CANCEL)
        self.dialog.add_button(_("_Accept"), Gtk.ResponseType.OK)

        # Add additional widget.
        add_widget_p(vbox)

        # Render dialog.
        align_vbox.show_all()
        self.dialog.show()

        # Map button responses to callback.
        self.dialog.connect('response', response_p)

        # Start event loop.
        Gtk.main()


class PluginDialog:
    """
    Create a GimpUI.Dialog for user interaction and define output settings.
    """

    def __init__(self, j, q):
        """
        Open a dialog. Respond to user interaction.

        j: Gimp.Image
            WIP

        q: list
            [Gimp.Layer, Gimp.GroupLayer, ...]
            selected layer
        """
        self._grid = self._layer_q = None
        self._mask_type_q = ()
        self._alpha_q = ()
        self._image = j

        if q:

            # {widget key: widget}
            # for retrieving widget
            self._widget_d = {}

            # Store mask-type CheckButton by mask-group.
            self._mask_group_q = [[], [], []]

            q = self._layer_q = get_selected_drawable_layer(q)
        if q:
            self.output = Output()

            # Init UI theme.
            GimpUi.init(sys.argv[0])

            response_d[Gtk.ResponseType.CANCEL] = \
                response_d[Gtk.ResponseType.DELETE_EVENT] = self.on_cancel
            response_d[Gtk.ResponseType.OK] = self.on_accept
            Dialog(self.add_dialog_widget, self.on_dialog_button)
        else:
            # Let the user know about the layer situation.
            # Thee must be a Gimp.Layer selected.
            Gimp.message(
                _(
                    "There is no layer selected. Please\n"
                    "select a layer and try again."
                )
            )

    def _add_all_button(self, hbox, q):
        """
        Create an All button and add it to an HBox.

        hbox: Gtk.HBox
            Contain the Gtk.Button.

        q: iterable
            Are CheckButton effected by the All button.
        """
        button = Gtk.Button.new_with_label(_("All"))
        align_left = Gtk.Alignment()

        align_left.set_padding(0, 0, 0, 3)
        button.connect('clicked', self.on_switch_button, (q, 1))
        align_left.add(button)
        hbox.pack_start(align_left, True, True, 0)

    def _add_alpha_row(self):
        """
        Create a Alpha Channel RadioButton row.

        grid: Gtk.Grid
        """
        def _add_line(_r):
            _label = create_label('\n')

            # column, '0'; cell width, '3'; cell height, '1'
            self._grid.attach(_label, 0, _r, 3, 1)

        _add_line(ALPHA_ROW)

        # separator
        sep = Gtk.HSeparator.new()
        sep1 = Gtk.HSeparator.new()

        self._grid.attach(sep, 0, ALPHA_ROW + 1, 3, 1)
        self._grid.attach(sep1, 0, ALPHA_ROW + 5, 3, 1)

        # RadioButton
        hbox = Gtk.HBox(spacing=0)
        align_q = ()
        self._alpha_q = ()
        tip = _(" The {} channel determines the alpha value of the mask. ")
        w = MARGIN + MARGIN

        for i, n in enumerate(ALPHA):
            align = Gtk.Alignment()
            align_q += (align,)
            g = Gtk.CheckButton.new_with_label(n)
            self._alpha_q += (g,)

            align.add(g)
            align.set_padding(0, 0, 0, w)
            g.set_tooltip_text(tip.format(n.lower()))
            g.connect('clicked', self.set_group_visibility)

        # Set 'Gray' as default.
        self._alpha_q[0].set_active(1)

        self._widget_d['alpha'] = self._alpha_q
        label = create_label(_("Alpha Channel"))
        align_label = Gtk.Alignment()

        align_label.set_padding(0, 0, MARGIN, w)
        align_label.add(label)

        # Expand and fill, 'True'; zero padding, '0'.
        for g in ((align_label,) + align_q):
            hbox.pack_start(g, False, False, 0)

        self._add_all_button(hbox, self._alpha_q)
        self._add_none_button(hbox, self._alpha_q)

        # column, '0'; cell width, '3'; cell height, '1'
        self._grid.attach(hbox, 0, ALPHA_ROW + 2, 3, 1)

        # Group CheckButton
        _add_line(ALPHA_ROW + 3)
        g = self._widget_d['group'] = create_checkbutton(
            _("Group"), self._grid, 0, ALPHA_ROW + 4
        )
        g.set_tooltip_text(_("Group layer output by type."))
        g.set_active(1)

        # Cause the widget to hide on dialog start, 'realize'.
        g.connect('realize', self.set_group_visibility)

    def _add_mask_checkbutton(self):
        """Create mask-type Gtk.CheckButton."""
        # Fill three columns with widget, '3'.
        for column in range(3):
            for row in range(5):
                # CheckButton label, 'n'
                n = MASK_GROUP[column][row]

                # Midtone has a None key, so check.
                if n:
                    # Skip the header, '3'.
                    g = self._widget_d[n] = create_checkbutton(
                        n, self._grid, column, row + MASK_TYPE_ROW
                    )
                    self._mask_type_q += (g,)
                    self._mask_group_q[column].append(g)
                    g.connect('clicked', self.set_group_visibility)

    def _add_none_button(self, hbox, q):
        """
        Create a None button and add it to an HBox.

        hbox: Gtk.HBox
            Contain the Gtk.Button.

        q: iterable
            Are CheckButton effected by the None button.
        """
        button = Gtk.Button.new_with_label(_("None"))
        align_right = Gtk.Alignment()

        button.connect('clicked', self.on_switch_button, (q, 0))
        align_right.set_padding(0, 0, 0, 15)
        align_right.add(button)
        hbox.pack_start(align_right, True, True, 0)

    def _add_mask_group_button(self):
        """Create mask-group Gtk.Button for mask-type switching."""
        # mask-group count, '3'
        for column in range(3):
            align_hbox = Gtk.Alignment()
            align_hbox.set_padding(0, 0, 2, MARGIN)
            hbox = Gtk.HBox(homogeneous=False, spacing=0)

            align_hbox.add(hbox)
            self._add_all_button(hbox, self._mask_group_q[column])
            self._add_none_button(hbox, self._mask_group_q[column])

            # column, '1'; cell width, '1'; cell height, '1'
            self._grid.attach(align_hbox, column, MASK_GROUP_ROW, 1, 1)

        # separator
        sep = Gtk.HSeparator.new()

        # last row, '8'; cell width span, '3'; cell height, '1'
        self._grid.attach(sep, 0, MASK_GROUP_ROW + 1, 3, 1)

    def _gather_dialog_setting(self):
        """
        Load a dictionary with dialog widget value.

        Return: (dict, bool, bool)
            dict: {widget key: widget value}
            int: Is True if there was an active alpha channel CheckButton.
            int: Is True if there was an active mask-type CheckButton.
        """
        d = self._widget_d

        # {widget key: widget value}
        e = {}

        g = d['group']

        if g.is_visible():
            is_group = d['group'].get_active()

        else:
            is_group = False

        total_type = total_alpha = total_alpha_group = 0

        # Init mask-group flag.
        for k1 in ('light', 'midtone', 'dark'):
            e[f'{k1}_group'] = False

        for q in ((LIGHT, 'light'), (MID_NAME, 'midtone'), (DARK, 'dark')):
            k = f'{q[1]}_group'
            total_group = 0

            for k1 in q[0]:
                m = e[k1] = d[k1].get_active()
                total_type += m
                total_group += m
                e[k] = is_group and (total_group > 1)
            total_alpha_group += int(bool(total_group))

        for i, k in enumerate(ALPHA):
            k1 = f'{k}_group'
            a = e[k] = self._alpha_q[i].get_active()
            e[k1] = is_group and a and (total_alpha_group > 1)
            total_alpha += a

        e['alpha'] = total_alpha > 1
        return e, total_type, total_alpha

    def _process_fail(self, fail_q):
        """
        Notify the user of failed mask-type.

        fail_q: list
            [(layer name, mask type string)]
        """
        n = _(
            "Some mask-type failed. Were there pixels in the channel?\n"
        )
        n1 = _("\nLayer: {}, \tComponent: {}, \tMask-Type: {} ")

        for q in fail_q:
            name, component, mask_type = q
            n = n + n1.format(name, component, mask_type)
        Gimp.message(n)

    def add_dialog_widget(self, vbox):
        """
        Add widget to the Dialog's VBox.

        vbox: Gtk.VBox
            Has vertical packing.
        """
        add_hint_box(vbox)

        self._grid = add_grid(vbox)

        add_grid_header(self._grid)
        self._add_mask_checkbutton()
        self._add_mask_group_button()
        self._add_alpha_row()

    def on_accept(self):
        """
        Respond to an Accept button action. Create mask-type output.
        """
        d, total_type, total_alpha = self._gather_dialog_setting()

        if total_type and total_alpha:
            # WIP image's selection channel, 'channel'
            channel = None

            # WIP image, 'j'
            j = self._image

            if not Gimp.Selection.is_empty(j):
                # Remember selection.
                selection = j.get_selection()
                channel = selection.save(j)

            Gtk.main_quit()

            masked_q, fail_q = self.output.create(d, self._layer_q)

            if fail_q:
                self._process_fail(fail_q)

            if channel:
                for z in masked_q:
                    # Combine the layer mask with the original
                    # selection's channel. The layer mask is
                    # modified with the intersection.
                    z.get_mask().combine_masks(
                        channel, Gimp.ChannelOps.INTERSECT, .0, .0
                    )

                # Restore the selection.
                j.select_item(Gimp.ChannelOps.REPLACE, channel)
                j.remove_channel(channel)

            else:
                Gimp.Selection.none(j)

            # Restore the selected layers.
            j.set_selected_layers(self._layer_q)

        if not total_alpha:
            Gimp.message(_(
                "Please check a Alpha Channel "
                "before activating the Accept button."
            ))
        elif not total_type:
            Gimp.message(_(
                "Please check a mask type before"
                " activating the Accept button."
            ))

    def on_cancel(self):
        """Close the dialog. The user chose to cancel."""
        Gtk.main_quit()

    def on_dialog_button(self, dialog, response_id):
        """
        Handle a user initiated dialog-process button action.

        dialog: GimpUI.Dialog
            PluginDialog

        response_id: Gtk.ResponseType
            Identify button.
        """
        p = response_d.get(response_id)
        if p is not None:
            p()

    def on_switch_button(self, button, arg):
        """
        Respond to an All or None Button action.

        button: Gtk.Button
            not used

        arg: tuple
            (list, active)
                list:
                    [Gtk.CheckButton, ...]
                    Set their active state.
                active: int
                    0 or 1
                    Set the CheckButton active.
        """
        q, active = arg
        for g in q:
            g.set_active(active)

    def set_group_visibility(self, *arg):
        """
        Set the Group CheckButton visibility depending on
        the number of options selected.

        arg: tuple
            ignore
        """
        g = self._widget_d.get('group')

        # Wait for the Group CheckButton to be created.
        if g:
            alpha = [g.get_active() for g in self._alpha_q].count(1)

            # Is the total number of active mask-type, 'a'.
            a = 0

            for i in self._mask_type_q:
                if i.get_active():
                    a += 1

            a *= alpha

            if a > 1:
                g.show()
            else:
                g.hide()
