#!/usr/bin/env python3
from lmdt_output import DARK, LIGHT, MIDTONE, Output, _
import gi       # type: ignore
import sys

gi.require_version('Gtk', '3.0')

from gi.repository import Gimp, GimpUi, Gtk

# row offset in the Gtk.Grid for the Selection Channel option
SELECT_ROW = 9

# Send Button response.
# {Gtk.ResponseType: responder function}
response_d = {
    Gtk.ResponseType.CANCEL: None,
    Gtk.ResponseType.DELETE_EVENT: None,
    Gtk.ResponseType.OK: None
}


def add_grid(vbox):
    """
    Add a Gtk.Grid to a Gtk.VBox.

    Return: Gtk.Grid
        newly created
    """
    grid = Gtk.Grid()

    grid.set_column_homogeneous(True)
    grid.set_border_width(4)
    grid.set_column_spacing(5)
    grid.set_row_spacing(1)
    vbox.add(grid)
    return grid


def add_grid_header(grid):
    """
    Add mask type label to the top a Gtk.Grid.

    grid: Gtk.Grid
        Receive header label.
    """
    label_q = ()

    for i, n in enumerate((_("Light"), _("Midtone"), _("Dark"))):
        label_q += (create_label(n),)

        # column, 'i'; row, '0'; cell width, '1'; cell height, '1'
        grid.attach(label_q[-1], i, 1, 1, 1)

    # Make the RadioButtons all the same size.
    same_size = Gtk.SizeGroup(mode=Gtk.SizeGroupMode.BOTH)

    for g in label_q:
        same_size.add_widget(g)

    # separator
    sep = Gtk.HSeparator.new()
    sep1 = Gtk.HSeparator.new()

    grid.attach(sep, 0, 0, 3, 1)
    grid.attach(sep1, 0, 2, 3, 1)


def create_checkbutton(label, grid, column, row):
    """
    Create a Gtk.CheckButton and add to a Gtk.Grid.

    label: string
        Give the Gtk.Checkbox a visible descriptor.

    grid: Gtk.Grid
        Contain the CheckButton.

    column: int
        Place CheckButton in a Gtk.Grid cell.
        0 to n

    row: int
        Place CheckButton in a Gtk.Grid cell.
        0 to n

    Return: Gtk.CheckButton
        newly created
    """
    g = Gtk.CheckButton.new_with_label(label)

    # cell width, '1'; cell height, '1'
    grid.attach(g, column, row, 1, 1)

    return g


def create_label(text):
    """
    Create a Gtk.Label

    text: string
        Display value.
    """
    return Gtk.Label(text)


def add_hint_box(vbox):
    """
    Place GIMP's hint box on top of the dialog.

    vbox: Gtk.VBox
        Has vertical packing to receive HintBox.
    """
    vbox.pack_start(
        GimpUi.HintBox.new(_(
            "Check luminosity mask-type to"
            " create mask for selected layer(s).\t\t\t\t"
        )),
        False,                  # expand
        False,                  # fill
        12                      # padding
    )


class Dialog:
    """Create a GimpUI.Dialog having Cancel, Preview, and Accept buttons."""

    def __init__(self, add_widget_p, response_p):
        """
        add_widget_p: function
            Add widget to the Dialog's VBox.

        response_p: function
            Handle Cancel, Preview, and Accept button action.
        """
        self.dialog = GimpUi.Dialog(
            use_header_bar=Gtk.Settings.get_default().
            get_property("gtk-dialogs-use-header"),
            title="Luminosity Mask Drive-Thru 2"
        )
        vbox = Gtk.VBox()

        self.dialog.get_content_area().add(vbox)
        self.dialog.add_button(_("_Cancel"), Gtk.ResponseType.CANCEL)
        self.dialog.add_button(_("_Accept"), Gtk.ResponseType.OK)

        # Add additional widget.
        add_widget_p(vbox)

        # Render dialog.
        vbox.show_all()
        self.dialog.show()

        # Map button responses to callback.
        self.dialog.connect('response', response_p)

        # Start event loop.
        Gtk.main()


class PluginDialog:
    """
    Create a GimpUI.Dialog for user interaction and define output settings.
    """

    def __init__(self, layer_q):
        """
        Open a dialog. Respond to user interaction.

        layer_q: list
            [layer, ...]
            selected layer
        """
        self._grid = None

        # {widget key: widget}
        # for retrieving widget
        self._widget_d = {}

        self._original_q = layer_q
        self._layer_q = [i for i in layer_q if i.is_layer()]

        if self._layer_q:
            self.output = Output()

            # Init UI theme.
            GimpUi.init(sys.argv[0])

            response_d[Gtk.ResponseType.CANCEL] = \
                response_d[Gtk.ResponseType.DELETE_EVENT] = self.on_cancel
            response_d[Gtk.ResponseType.OK] = self.on_accept
            Dialog(self.add_dialog_widget, self.on_dialog_button)
        else:
            # Let the user know about the layer situation.
            # Thee must be a Gimp.Layer selected.
            Gimp.message(
                _(
                    "There is no layer selected. Please\n"
                    "select a layer and try again."
                )
            )

    def _add_mask_checkbutton(self):
        """Create mask-type Gtk.CheckButton."""
        for row in range(5):
            for i, q in enumerate((LIGHT, MIDTONE, DARK)):
                # CheckButton label, 'n'
                n = q[row]

                # Midtone has a None key, so check.
                if n:
                    # Skip the header, '3'.
                    self._widget_d[n] = create_checkbutton(
                        n, self._grid, i, row + 3
                    )

        sep = Gtk.HSeparator.new()

        # last row, '8'; cell width span, '3'; cell height, '1'
        self._grid.attach(sep, 0, 8, 3, 1)

    def _add_selection_row(self):
        """
        Create a Selection Channel RadioButton row.

        grid: Gtk.Grid
        """
        label = create_label('\n')

        # column, '0'; cell width, '3'; cell height, '1'
        self._grid.attach(label, 0, SELECT_ROW, 3, 1)

        # separator
        sep = Gtk.HSeparator.new()
        sep1 = Gtk.HSeparator.new()

        self._grid.attach(sep, 0, SELECT_ROW + 1, 3, 1)
        self._grid.attach(sep1, 0, SELECT_ROW + 3, 3, 1)

        # RadioButton
        # container for RadioButton, 'hbox'
        hbox = Gtk.HBox(spacing=0)

        button_q = ()
        group = None

        for i, n in enumerate((_("Gray"), _("Red"), _("Green"), _("Blue"))):
            button_q += (
                Gtk.RadioButton.new_with_label_from_widget(group, n),
            )
            if not group:
                group = button_q[-1]

        self._widget_d['select_type'] = button_q
        label = create_label(_("Selection Channel"))

        # Expand and fill, 'True'; zero padding, '0'.
        for g in ((label,) + button_q):
            hbox.pack_start(g, True, True, 0)

        # column, '0'; cell width, '3'; cell height, '1'
        self._grid.attach(hbox, 0, SELECT_ROW + 2, 3, 1)

    def _gather_dialog_setting(self):
        """
        Load a dictionary with dialog widget value.

        Return: (dict, bool, int)
            dict: {widget key: widget value}
            bool: Is True if there was an active CheckButton.
            int: Selection Channel option value
        """
        d = self._widget_d
        select_type = 0

        # {widget key: widget value}
        e = {}

        for i, g in enumerate(d['select_type']):
            if g.get_active():
                select_type = i
                break

        # any CheckButton active flag, 'm'
        m = False

        for k in (LIGHT + MIDTONE + DARK):
            if k is None:
                continue

            a = d[k].get_active()
            m += a
            e[k] = a
        return e, m, select_type

    def _process_fail(self, fail_q):
        """
        Notify the user of failed mask-type.

        fail_q: list
            [(layer name, mask type string)]
        """
        n = "Some mask-type failed. Were there pixels?:\n"
        n1 = "\nLayer: {},\tMask-Type: {}"

        for q in fail_q:
            name, type_ = q
            n = n + n1.format(name, type_)
        Gimp.message(n)

    def add_dialog_widget(self, vbox):
        """
        Add widget to the Dialog's VBox.

        vbox: Gtk.VBox
            Has vertical packing.
        """
        add_hint_box(vbox)

        self._grid = add_grid(vbox)

        add_grid_header(self._grid)
        self._add_mask_checkbutton()
        self._add_selection_row()

    def on_accept(self):
        """
        Respond to an Accept button action. Create mask-type output.
        """
        d, m, select_type = self._gather_dialog_setting()

        # CheckButton selected flag, 'm'
        if m:
            # WIP image's selection channel, 'channel'
            channel = None

            # WIP image, 'j'
            j = self._layer_q[0].get_image()

            if not Gimp.Selection.is_empty(j):
                # Remember selection.
                selection = j.get_selection()
                channel = selection.save(j)

            Gtk.main_quit()

            masked_q, fail_q = self.output.create(
                d, select_type, self._layer_q
            )

            if fail_q:
                self._process_fail(fail_q)

            if channel:
                for z in masked_q:
                    # Combine the layer mask with the original
                    # selection's channel. The layer mask is
                    # modified with the intersection.
                    z.get_mask().combine_masks(
                        channel, Gimp.ChannelOps.INTERSECT, .0, .0
                    )

                # Restore the selection.
                j.select_item(Gimp.ChannelOps.REPLACE, channel)
                j.remove_channel(channel)

            else:
                Gimp.Selection.none(j)

            # Restore the selected layers.
            j.set_selected_layers(self._original_q)
        else:
            Gimp.message(
                "Please check a mask type before activating the Accept button."
            )

    def on_cancel(self):
        """Close the dialog. The user chose to cancel."""
        Gtk.main_quit()

    def on_dialog_button(self, dialog, response_id):
        """
        Handle a user initiated dialog-process button action.

        dialog: GimpUI.Dialog
            PluginDialog

        response_id: Gtk.ResponseType
            Identify button.
        """
        p = response_d.get(response_id)
        if p is not None:
            p()
