#!/usr/bin/env python3
from plugout.container.container import Container
from plugout.define.key import HOMOGENEOUS
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa

"""
Define horizontal and vertical Gtk.Box wrapper.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/Box.html'
"""


class HBox(Container):
    """Customize a 'Gtk.HBox' with this wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            HBox definition
                homogeneous: bool
                    Make the HBox divvy up its space evenly.
        """
        g = Gtk.HBox(homogeneous=def_d.get(HOMOGENEOUS, True))
        super().__init__(def_d, g)


class VBox(Container):
    """Customize a 'Gtk.VBox' with this wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            VBox definition
                homogeneous: bool
                    Make the VBox divvy up its space evenly.
        """
        g = Gtk.VBox(homogeneous=def_d.get(HOMOGENEOUS, False))
        super().__init__(def_d, g)
