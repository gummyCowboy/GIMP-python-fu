#!/usr/bin/env python3
from plugout.widget.checkbutton import CheckButton

"""Include customized CheckButton wrapper class."""


class CheckButtonGroup(CheckButton):
    """Customize CheckButton with a custom signal responder."""

    def __init__(self, def_d):
        """
        def_d: dict
            CheckButtonGroup definition
        """
        super().__init__(def_d)
        self._alpha_count = \
            self._dark_count = \
            self._light_count = \
            self._midtone_count = 0

    def on_custom_signal(self, _, arg):
        """
        Respond to a CUSTOM_SIGNAL emission from the AnyGroup host.
        Has been configured with four different Widgets.

        If the combined options are group-able, then show this
        CheckButtonGroup, otherwise, hide the button.

        _: AnyGroup host
        arg: tuple
            (None, ArrayCheckButton, the array's value -> list)
        """
        widget, value = arg[1:]
        count = value.count(True)
        k = widget.key

        if k == 'light_array':
            self._light_count = count

        elif k == 'midtone_array':
            self._midtone_count = count

        elif k == 'dark_array':
            self._dark_count = count

        elif k == 'alpha_array':
            self._alpha_count = count

        total = self._light_count + self._midtone_count + self._dark_count
        total *= self._alpha_count

        if total > 1:
            self.widget.show()
        else:
            self.widget.hide()
            self.widget.set_active(False)
