#!/usr/bin/env python3
import gi                              # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp         # noqa

"""
Include a function to initialize static pdb
run class, and static pdb run class.

The static class' config object is reused. So configuring a
pdb procedure has an additional dynamic in that the previous
call to 'class.do' can be repeated, but without the configuration
settings.
"""


def init_pdb():
    """Implement a get-once strategy for Gimp's pdb interface. """
    for q in (
        (ComponentChannel, 'gimp-channel-new-from-component'),
        (ItemPosition, 'gimp-image-get-item-position')
    ):
        a, n = q
        a.pdb = Gimp.get_pdb().lookup_procedure(n)
        a.config = a.pdb.create_config()


class ComponentChannel:
    pdb = config = None

    def do(q):
        """
        q: tuple
            Configure the procedure.
            (
                ('image', Gimp.Image),
                ('component', Gimp.ChannelType),
                ('name', str)
            )

        Return: Gimp.Channel
            newly created
        """
        for q1 in q:
            ComponentChannel.config.set_property(*q1)

        result = ComponentChannel.pdb.run(ComponentChannel.config)
        return result.index(1)


class ItemPosition:
    pdb = config = None

    def do(q):
        """
        q: tuple
            Configure the procedure.
            (
                ('image', Gimp.Image),
                ('item', Gimp.Item)
            )
        """
        for q1 in q:
            ItemPosition.config.set_property(*q1)
        return ItemPosition.pdb.run(ItemPosition.config).index(1)
