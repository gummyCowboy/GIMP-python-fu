#!/usr/bin/env python3
from plugout.constant import ANY_CHANGE, CONTAINER_CHANGE
import gi                                          # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GLib, GObject      # noqa


def _(n):
    """
    Translate English to local language.

    n: string
        Translate.

    Return: string
        translated
    """
    return GLib.dgettext(None, n)


CHANNEL_TYPE = (
    Gimp.ChannelType.GRAY,
    Gimp.ChannelType.RED,
    Gimp.ChannelType.GREEN,
    Gimp.ChannelType.BLUE
)
NORMAL = Gimp.LayerMode.NORMAL
PROCEDURE_NAME = 'plug-in-luminosity-mask-drive-thru'
TITLE = "Luminosity Mask Drive-Thru 2.22"

# Translate enum for faster look-ups.
# ChannelOps
INTERSECT = Gimp.ChannelOps.INTERSECT
REPLACE = Gimp.ChannelOps.REPLACE
SUBTRACT = Gimp.ChannelOps.SUBTRACT

# MaskApplyMode
APPLY = Gimp.MaskApplyMode.APPLY
DISCARD = Gimp.MaskApplyMode.DISCARD

# AddMaskType
COPY = Gimp.AddMaskType.COPY
SELECTION = Gimp.AddMaskType.SELECTION

# Translate____________________________________________________________________
ALL = _("All")
ALPHA = _("Alpha")
ALPHA_CHANNEL = _("Alpha Channel")
BLACK = _("Black")
BRIGHT = _("Bright")
BRILLIANT = _("Brilliant")
DARK = _("Dark")
DARKER = _("Darker")
DEEP = _("Deep")
EXPANDED = _("Expanded")
FAIL_HEADER = _(
    "Some mask-type failed. Were there pixels in the channel?\n"
)
FAIL_LINE = _("\nLayer: {}, \tComponent: {}, \tMask-Type: {} ")
GREATEST = _("Greatest")
GROUP = _("Group")
GROUP_TIP = _("Group layer output by type.")
HINT_TEXT = _(
    "Check luminosity mask-type and channel alpha-type to"
    " create mask for selected layer."
)
LIGHT = _("Light")
LIGHTER = _("Lighter")
MIDTONE = _("Midtone")
NO_LAYER_SELECTED = _(
    "There is no layer selected. Please\n"
    "select a layer and try again."
)
MINIMAL = _("Minimal")
NONE = _("None")
PLUGIN_BLURB = _(
    "Create luminosity mask on selected"
    " layer with or without an active selection."
)
PLUGIN_TOOLTIP = _("Create luminosity mask.")
SHADOW = _("Shadow")
WHITE = _("White")
WIDE = _("Wide")

# dependent string array
ALPHA_CHANNEL_TYPE = _("Gray"), _("Red"), _("Green"), _("Blue")
DARK_MASK_TYPE = DARK, DARKER, SHADOW, DEEP, BLACK
DARK_MASK_ORDER = list(DARK_MASK_TYPE)
LIGHT_MASK_TYPE = LIGHT, LIGHTER, BRIGHT, BRILLIANT, WHITE
LIGHT_MASK_ORDER = list(LIGHT_MASK_TYPE)
MIDTONE_MASK_TYPE = GREATEST, WIDE, EXPANDED, MINIMAL
MIDTONE_PROCESS_ORDER = list(MIDTONE_MASK_TYPE)

DARK_MASK_ORDER.reverse()
LIGHT_MASK_ORDER.reverse()
MIDTONE_PROCESS_ORDER.reverse()


# custom Signal________________________________________________________________
ALPHA_CHANNEL_CHANGE = 'alpha-channel-change'
MASK_TYPE_CHANGE = 'mask-type-change'
SELECT_ALPHA_ALL = 'select-alpha-all'
SELECT_ALPHA_NONE = 'select-alpha-none'
SELECT_LIGHT_ALL = 'select-light-all'
SELECT_LIGHT_NONE = 'select-light-none'
SELECT_MIDTONE_ALL = 'select-midtone-all'
SELECT_MIDTONE_NONE = 'select-midtone-none'
SELECT_DARK_ALL = 'select-dark-all'
SELECT_DARK_NONE = 'select-dark-none'
SELECT_BUTTON_SIGNAL = (
    (SELECT_LIGHT_ALL, SELECT_LIGHT_NONE),
    (SELECT_MIDTONE_ALL, SELECT_MIDTONE_NONE),
    (SELECT_DARK_ALL, SELECT_DARK_NONE)
)

# run argument
# (emission stage, type of signal, argument type)
SIGNAL_ARG = GObject.SIGNAL_RUN_LAST, None, (GObject.TYPE_PYOBJECT,)

DIALOG_MAIN_SIGNAL = {}

for k in (
    ANY_CHANGE, ALPHA_CHANNEL_CHANGE,
    CONTAINER_CHANGE, MASK_TYPE_CHANGE,
    SELECT_ALPHA_ALL, SELECT_ALPHA_NONE,
    SELECT_LIGHT_ALL, SELECT_LIGHT_NONE,
    SELECT_MIDTONE_ALL, SELECT_MIDTONE_NONE,
    SELECT_DARK_ALL, SELECT_DARK_NONE
):
    DIALOG_MAIN_SIGNAL[k] = SIGNAL_ARG
