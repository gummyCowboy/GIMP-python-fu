#!/usr/bin/env python3
from plugout.define.key import TEXT
from plugout.container.container import Container
from plugout.container.box import VBox
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa

"""
Define a 'Gtk.Notebook' partnership with custom wrapper.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/Notebook.html'
"""


class Notebook(Container):
    """
    Customize a 'Gtk.Notebook' with this wrapper.
    Is the strictly a Container for Page.
    """

    def __init__(self, def_d):
        """
        def_d: dict
            Notebook definition
        """
        g = Gtk.Notebook.new()
        super().__init__(def_d, g)

    def add(self, g):
        """
        Add a Page to the 'Gtk.Notebook'.

        g: Page
            Append page to Gtk.Notebook.
        """
        self.widget.append_page(g.gtk_addable, g.tab_label)


class Page(VBox):
    """
    Is a custom Gtk.VBox with a 'tab_label'
    attribute for the 'Notebook.add' function.
    """

    def __init__(self, def_d):
        """
        def_d: dict
            Page definition
                text: string
                    Describe the tab.
        """
        super().__init__(def_d)
        self.tab_label = Gtk.Label(label=def_d.get(TEXT, ""))
