#!/usr/bin/env python3
from plugout.define.key import TEXT, VALUE
from plugout.widget.value import WidgetValue
from random import choice
import gi                                  # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk              # noqa

"""
Include customized 'Gtk.CheckButton' wrapper class.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/CheckButton.html'
"""


class CheckButton(WidgetValue):
    """
    Customize 'Gtk.CheckButton' with a wrapper.

    lazka.github.io/pgi-docs/Gtk-3.0/classes/CheckButton.html
    """
    change_signal = 'toggled', 'clicked'

    def __init__(self, def_d):
        """
        def_d: dict
            CheckButton definition
                text: string
                    Display a descriptor for the CheckButton.

                value: bool
                    Initialize the Widget value.
                    Is the default value in the Widget's preset.
        """
        g = Gtk.CheckButton.new_with_label(def_d.get(TEXT, ""))

        super().__init__(def_d, g)

        m = self.value_d[self.key] = def_d.get(VALUE, False)
        g.set_active(m)

    def randomize(self, *_):
        """
        Respond to a randomize signal. Randomize
        the value of the 'Gtk.CheckButton'.
        """
        self.set_a(choice(self.limit))

    def get_a(self):
        """
        Retrieve the value of the 'Gtk.CheckButton'.

        Return: bool
        """
        return self.widget.get_active()

    def set_a(self, m):
        """
        Set the value of the 'Gtk.CheckButton'.

        m: bool
            Receive value.
        """
        if not isinstance(m, bool):
            m = bool(m)
        self.widget.set_active(m)
