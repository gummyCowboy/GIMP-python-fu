#!/usr/bin/env python3
from plugout.define.key import GET_LIST, SEPARATOR, VALUE
from plugout.widget.value import WidgetValue
from random import randrange
import gi                                  # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk              # noqa

"""
Include 'Gtk.ComboBoxText' wrapper class.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/ComboBoxText.html'
"""


class ComboBoxText(WidgetValue):
    """
    Customize a 'Gtk.ComboBoxText' with this wrapper.
    The Widget creates a pop-out list when activated.
    """
    change_signal = 'changed'

    def __init__(self, def_d):
        """
        def_d: dict
            ComboBoxText definition
                get_list: function
                Retrieve an initial value iterable.

                separator: value
                In the pop-out list, this value becomes a separator line.

                value: string
                Initialize the value of 'Gtk.ComboBoxText'.
                Is the default value for the Widget's preset.
        """
        self._separator = def_d.get(SEPARATOR, '-')
        g = Gtk.ComboBoxText.new()
        p = self._get_list = def_d.get(GET_LIST, lambda *_: ())
        has_list = False

        super().__init__(def_d, g)

        if p:
            for n in p():
                g.append_text(n)
                has_list = True

        g.set_row_separator_func(self.check_for_separator)
        if has_list:
            a = def_d.get(VALUE, p()[0])

            self.value_d[self.key] = a
            self.set_a(a)

    def check_for_separator(self, list_store, tree_iter):
        """
        Check a ComboBoxText value to see if it's an separator.

        Return: bool
            If True, then the value is a separator.
        """
        # the current item's string, 'n'
        n = list_store.get_value(tree_iter, 0)

        if n:
            return n == self._separator
        return False

    def get_a(self):
        """
        Retrieve the value of the 'Gtk.ComboBoxText'.

        Return: value
        """
        return self.widget.get_active_text()

    def randomize(self, *_):
        """
        Respond to an option groups 'randomize' signal.
        Randomize the 'Gtk.ComboBoxText' value.
        """
        a = 0
        n = self._separator

        while n == self._separator:
            a = randrange(*self.limit)
            n = self.def_d[GET_LIST]()[a]
        self.set_a(a)

    def set_a(self, a):
        """
        Set the active value in the Gtk.ComboBoxText.

        a: int or string
            Is the index to the value that is to become active.
        """
        if isinstance(a, str):
            if a in self._get_list():
                # Convert string to index-int.
                a = self._get_list().index(a)
            else:
                a = 0
        self.widget.set_active(a)
