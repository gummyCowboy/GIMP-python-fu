#!/usr/bin/env python3
from lmdt.constant import PLUGIN_BLURB, PLUGIN_TOOLTIP, PROCEDURE_NAME
from lmdt.dialog_main import DialogMain
from plugout.constant import GIMP_PYTHON
import gi                                         # type: ignore
import sys
gi.require_version('Gimp', '3.0')
gi.require_version('GimpUi', '3.0')
from gi.repository import Gimp, GimpUi, GLib       # noqa


def get_selected_drawable_layer(q):
    """
    Create a list of selected 'Gimp.Layer'.

    q: list
        [Gimp.Layer, ..., Gimp.GroupLayer, ...]
        Remove GroupLayer from list.

    Return: list
        [Gimp.Layer, ...]
    """
    # Filter out GroupLayer and mask drawable.
    return [
        i
        for i in q
        if not Gimp.Item.id_is_group_layer(i.get_id())
        and Gimp.Item.is_layer(i)
    ]


class LMDT(Gimp.PlugIn):
    """Initialize the plug-in with GIMP 3."""

    def do_query_procedures(self):
        return [PROCEDURE_NAME]

    def do_set_i18n(self, name):
        # Support language translation.
        return True, GIMP_PYTHON, None

    def do_create_procedure(self, name):
        """
        Define plug-in so that it can be run.

        name: string
            Is the name of the plug-in and is sourced from PROC_NAME.
        """
        procedure = Gimp.ImageProcedure.new(
            self,
            name,
            Gimp.PDBProcType.PLUGIN,
            self.run,
            None               # run data
        )
        # Require drawable.
        procedure.set_sensitivity_mask(
            Gimp.ProcedureSensitivityMask.DRAWABLE |
            Gimp.ProcedureSensitivityMask.DRAWABLES
        )
        procedure.set_image_types("RGB*, GRAY*")
        procedure.set_menu_label("_Luminosity Mask Drive Thru")
        procedure.add_menu_path('<Image>/Layer/Mask/')
        procedure.set_documentation(PLUGIN_TOOLTIP, PLUGIN_BLURB, name)
        procedure.set_attribution("Charles Bartley", "Charles Bartley", "2024")
        return procedure

    def run(self, procedure, run_mode, image, drawables, *_):
        """
        Produce layer output.

        procedure: Gimp.ImageProcedure
            Manage plug-in.

        run_mode: enum
            Gimp.RunMode

        image: Gimp.Image
            WIP

        drawables: list
            active drawable
            [drawable, ...]

        _: tuple
            args: Gimp.ValueArray
                How is this used?
                Has a length() function that could be useful.

            run_data: value
                Relayed from the 'do_create_procedure'.
        """
        # Check run mode. If interactive create
        # dialog, otherwise use previous settings.
        if run_mode == Gimp.RunMode.INTERACTIVE:
            GimpUi.init(PROCEDURE_NAME)
            Gimp.context_push()
            Gimp.context_set_interpolation(Gimp.InterpolationType.NOHALO)
            DialogMain(image, drawables)
            Gimp.context_pop()
            Gimp.displays_flush()

        else:
            # Use previous settings.
            # This is dependent on the shelf which is a GIMP team WIP.
            pass
        return procedure.new_return_values(
            Gimp.PDBStatusType.SUCCESS, GLib.Error()
        )


Gimp.main(LMDT.__gtype__, sys.argv)
