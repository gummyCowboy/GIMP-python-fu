#!/usr/bin/env python3
from lmdt.constant import (
    ALPHA, ALPHA_CHANNEL_TYPE,
    APPLY, CHANNEL_TYPE,
    DARK, DARK_MASK_ORDER, DARK_MASK_TYPE,
    DISCARD, GROUP, INTERSECT, LIGHT,
    LIGHT_MASK_ORDER, LIGHT_MASK_TYPE,
    MIDTONE, MIDTONE_PROCESS_ORDER,
    REPLACE, SELECTION, SUBTRACT
)
import gi                                # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp           # noqa


def clone_layer(j, z, parent):
    """
    Create a clone of a layer and insert it above its originator.
    If the layer has a mask, apply the mask to the layer's alpha.

    j: Gimp.Image
        Has layer.

    z: Gimp.Layer
        Copy.

    parent: Gimp.GroupLayer or None
        Alternate insert position by parent existence.

    Return: Gimp.Layer
        newly created
    """
    a = len(parent.get_children()) if parent else get_layer_offset(j, z)
    z1 = z.copy()

    j.insert_layer(z1, parent, a)

    if z1.get_mask():
        z1.set_apply_mask(True)
        z1.remove_mask(APPLY)
    return z1


def copy_layer(image, layer):
    """
    Create a copy of a layer and insert it at the top of the image.

    image: Gimp.Image
        Has layer.

    layer: Gimp.Layer
        Copy.

    Return: Gimp.Layer
        newly created
    """
    z = layer.copy()

    image.insert_layer(z, None, 0)

    if z.get_mask():
        z.set_apply_mask(True)
        z.remove_mask(APPLY)
    return z


def delete_empty_group(j, q):
    """
    Delete GroupLayer with no children.

    j: Gimp.Image
        WIP

    q: list
        [GroupLayer, ...]
    """
    for z in reversed(q):
        if not z.get_children():
            j.remove_layer(z)


def relocate_lonely_layer(j, q):
    """
    Relocate layer from a layer group with only layer.
    The lonely layer happens when a mask-type fails,
    and a group layer was created beforehand.

    j: Gimp.Image
        WIP

    q: list
        [GroupLayer, ...]
    """
    for z in reversed(q):
        child_q = z.get_children()
        if len(child_q) == 1:
            child = child_q[0]
            if not Gimp.Item.id_is_group_layer(child.get_id()):
                a = get_layer_offset(j, z)
                j.reorder_item(child, z.get_parent(), a)


def get_layer_offset(image, layer):
    """
    Fetch the layer's offset from the top of it's parent layer.

    image: Gimp.Image
        Has layer.

    layer: Gimp.Layer
        Check its position.

    Return: int
        offset
    """
    procedure = Gimp.get_pdb().lookup_procedure('gimp-image-get-item-position')
    config = procedure.create_config()

    for q in (('image', image), ('item', layer)):
        config.set_property(*q)
    return procedure.run(config).index(1)


def hide_group_layer(z):
    """
    Hide grouped layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    """
    for z1 in z.get_children():
        if Gimp.Item.id_is_group_layer(z1.get_id()):
            # recursive:
            hide_group_layer(z1)
        else:
            if z1.get_visible():
                z1.set_visible(False)


def hide_image_layer(z):
    """
    Hide all layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    """
    for z1 in z.get_layers():
        if Gimp.Item.id_is_group_layer(z1.get_id()):
            # recursive:
            hide_group_layer(z1)
        else:
            if z1.get_visible():
                z1.set_visible(False)


def make_component_channel(image, name, type_):
    """
    Make a component channel from an image.

    image: Gimp.Image
        Has component.

    name: string
        Name the channel.

    type_: Gimp.ChannelType
        Create an alpha channel based on this type.

    Return: Gimp.Channel
        newly created
    """
    procedure = Gimp.get_pdb().lookup_procedure(
        'gimp-channel-new-from-component'
    )
    config = procedure.create_config()

    for q in (
        ('image', image),
        ('component', type_),
        ('name', name)
    ):
        config.set_property(*q)

    result = procedure.run(config)
    return result.index(1)


def restore_group_visibility(z, d):
    """
    Show grouped layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    d: dict
        Has layer visibility.
        {layer id: is visible bool}
    """
    for z1 in z.get_children():
        id_ = z1.get_id()

        if Gimp.Item.id_is_group_layer(id_):
            # recursive:
            restore_group_visibility(z1, d)

        elif id_ in d:
            z1.set_visible(d[id_])
        else:
            # mask layer
            z1.set_visible(True)


def restore_image_visibility(z, d):
    """
    Show all layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    d: dict
        Has layer visibility.
        {layer id: is visible bool}
    """
    for z1 in z.get_layers():
        id_ = z1.get_id()

        if Gimp.Item.id_is_group_layer(id_):
            # recursive:
            restore_group_visibility(z1, d)

        elif id_ in d:
            z1.set_visible(d[id_])
        else:
            # mask layer
            z1.set_visible(True)


def save_group_visibility(z, d):
    """
    Store the visibility state of grouped layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    d: dict
    d: dict
        Store layer visibility.
        {layer id: is visible bool}
    """
    for z1 in z.get_children():
        id_ = z1.get_id()

        if Gimp.Item.id_is_group_layer(id_):
            # recursive
            save_group_visibility(z1, d)
        else:
            d[id_] = z1.get_visible()


def save_image_visibility(z, d):
    """
    Store the visibility state of all layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    d: dict
    d: dict
        Store layer visibility.
        {layer id: is visible bool}
    """
    for z1 in z.get_layers():
        id_ = z1.get_id()

        if Gimp.Item.id_is_group_layer(id_):
            # recursive
            save_group_visibility(z1, d)
        else:
            d[id_] = z1.get_visible()


class Output:
    """Produce mask-type layer output."""

    def __init__(self):
        self._has_midtone = False
        self._last_dark = self._last_light = 0

        # DialogMain
        self._is_group = \
            self._dark_array = \
            self._alpha_array = \
            self._light_array = \
            self._midtone_array = None

        # Output
        self._image = \
            self._parent = \
            self._alpha_type = \
            self._component_name = \
            self._dark_has_group = \
            self._light_has_group = \
            self._midtone_has_group = \
            self._midtone_process_order = \
            self._dark_array_reverse_order = \
            self._light_array_reverse_order = None

        # Is ordered by DialogMain's Alpha Channel option.
        # A True values indicates that the channel has a GroupLayer.
        self._channel_has_group_q = [False] * 4

        # [layer created with mask, ...]
        self._mask_q = []

        # [created group layer, ...]
        self._group_q = []

        # {channel key: channel}
        self._channel_d = {}

    def _check_fail(self, q, z, fail_q):
        """
        Check if mask generation failed at some point.

        q: list
            [failed mask-type, ...]
            [mask type, ...]

        z: Gimp.Layer
            masking

        fail_q: list
            [expanded failed mask type, ...]
            [(layer name, mask type), ...]
        """
        if q:
            n = z.get_name()
            for n1 in q:
                fail_q += [(n, self._component_name, n1)]

    def _create_group(self, image, parent, position, n):
        """
        Create a layer group immediately above a layer.

        image: Gimp.Image
            WIP

        parent: Gimp.GroupLayer or None
            Insert new group here.

        position: int
            Is the offset from the top of the parent.

        n: string
            Give the layer group a name.
        """
        # name source, 'z'
        group = Gimp.GroupLayer.new(image, n)
        self._group_q += [group]

        image.insert_layer(group, parent, position)
        return group

    def _do_alpha_type(self, j, z):
        """
        For each layer, there are one or more Alpha Channel.

        j: Gimp.Image
            WIP

        z: Gimp.Layer
            masking

        Return: list
            failed mask type
            [(layer name, alpha type, mask_type), ...]
        """
        fail_q = []
        group = self._parent

        for i, is_group in enumerate(self._channel_has_group_q):
            is_component = self._alpha_array[i]

            if is_component:
                if is_group:
                    if group:
                        a = len(group.get_children())

                    else:
                        a = get_layer_offset(j, z)
                    self._parent = self._create_group(
                        j,
                        self._parent,
                        a,
                        f'{z.get_name()} {ALPHA_CHANNEL_TYPE[i]}'
                    )

                self._component_name = ALPHA_CHANNEL_TYPE[i]
                self._alpha_type = CHANNEL_TYPE[i]
                fail_q += self._make_all_selection(j, z)
                self._mask_all(j, z)

            self._remove_channels(j)

            # Could be Alpha, Alpha Type, or None.
            self._parent = group
        return fail_q

    def _get_channel(self, k):
        """
        Retrieve a saved selection's channel.

        k: string
            key to channel dict

        Return: Gimp.Channel or None
        """
        return self._channel_d.get(k)

    def _get_group_offset(self, j, z):
        """
        A layer group's offset is dependent on the status of 'self._parent'.

        j: Gimp.Image
            WIP

        z: Gimp.Layer
            Has position.

        Return: int
            Is the insert position for a new layer group.
        """
        if self._parent:
            z = self._parent
        return get_layer_offset(j, z)

    def _make_all_selection(self, j, layer):
        """
        Make Light, Midtone, and Dark selection for a given layer.

        j: Gimp.Image
            WIP

        layer: Gimp.Layer
            Derive selection.

        Return: list
            [(layer name, mask-type string), ...]
            Record selection failure.
        """
        # layer for selection, 'z'
        z = copy_layer(j, layer)

        z.set_visible(True)

        fail_q = []
        q = self._make_polar_selection(
            z, LIGHT_MASK_TYPE, self._light_array, self._last_light
        )

        self._check_fail(q, layer, fail_q)

        if z.get_mask():
            z.remove_mask(DISCARD)

        q = self._make_polar_selection(
            z, DARK_MASK_TYPE, self._dark_array, self._last_dark, is_dark=True
        )

        self._check_fail(q, layer, fail_q)
        j.remove_layer(z)

        q = self._make_midtone_selection(j)

        self._check_fail(q, layer, fail_q)
        return fail_q

    def _make_midtone_selection(self, j):
        """
        Create Midtone mask selection.

        j: Gimp.Image
            WIP

        Return: list
            Is empty if there is no mask failure.
            If there is mask failure, then list contains mask-type string.
            e.g. [Minimum, Expanded, Wide, Greatest]
        """
        fail = []

        if self._has_midtone:
            for i, m in enumerate(self._midtone_process_order):
                # checked Midtone option, 'm'
                if m:
                    # Midtone mask-type, 'n'
                    n = MIDTONE_PROCESS_ORDER[i]

                    # Skip the Light and Dark channels, '1'.
                    light = self._channel_d.get(LIGHT_MASK_TYPE[i + 1])
                    dark = self._channel_d.get(DARK_MASK_TYPE[i + 1])

                    if light and dark:
                        Gimp.Selection.all(j)
                        j.select_item(SUBTRACT, light)
                        j.select_item(SUBTRACT, dark)

                        # The Midtone index is offset
                        # because of the None in MIDTONE, '1'.
                        channel = self._save_selection(n)
                        if not channel:
                            fail.append(n)
                    else:
                        fail.append(n)
        return fail

    def _make_polar_selection(
        self, clone, type_order, array, range_a, is_dark=False
    ):
        """
        Make mask selection.

        clone: Gimp.Layer
            Is mask gen focus.

        type_order: tuple or list
            [string, ...]; mask-type in DialogMain Widget order.

        array: iterable
            Has selected mask-type in DialogMain Widget order.

        range_a: int
            Is the selection iteration value needed by the mask-group-type.

        is_dark: bool
            If True, then the clone layer is inverted.

        Return: list
            Is empty if there is no mask failure.
            If there is mask failure, then list contains the mask-type.
            e.g. [Light, Dark, ...]
        """
        def _failed():
            if array[i]:
                fail.append(type_order[i])

        # Record mask failure.
        fail = []

        if range_a:
            j = self._image

            # initial error index, 'i'
            i = 0

            # Light or Dark string, 'n'
            n = type_order[0]

            if is_dark:
                Gimp.Selection.none(j)
                clone.invert(False)

            # Convert grayscale pixels into a channel where black
            # equates to transparent and white to opaque.
            start_channel = make_component_channel(j, n, self._alpha_type)

            j.insert_channel(start_channel, None, 0)
            j.select_item(REPLACE, start_channel)
            j.select_item(INTERSECT, clone)

            channel = self._save_selection(n)

            if not channel:
                _failed()

            for i in range(1, range_a):
                if channel:
                    Gimp.Selection.invert(j)

                    # a temporary channel key, 'inverted'
                    inverted = self._save_selection('inverted')

                    if inverted:
                        j.select_item(REPLACE, channel)
                        j.select_item(SUBTRACT, inverted)
                        self._remove_channel('inverted')

                        channel = self._save_selection(
                            type_order[i]
                        )
                        if not channel:
                            _failed()
                    else:
                        _failed()
                else:
                    _failed()
            j.remove_channel(start_channel)
        return fail

    def _make_selection(self, k, op):
        """
        Select a saved channel.

        k: string or tuple
            key to channel in the channel dict

        op: Gimp.ChannelOps
            ADD, SUBTRACT, INTERSECT, REMOVE
        """
        channel = self._get_channel(k)

        # A saved channel can be None, so check.
        if channel:
            self._image.select_item(op, channel)

    def _mask_all(self, j, z):
        """
        Create Light, Dark, and Midtone mask-group layer.

        j: Gimp.Image
            WIP

        z: Gimp.Layer
            Copy and make a masked layer.
        """
        parent = self._parent

        self._mask_polar(
            j, z,
            LIGHT_MASK_ORDER,
            self._light_has_group,
            self._light_array_reverse_order,
            LIGHT
        )

        self._parent = parent

        self._mask_midtone(j, z)

        self._parent = parent
        self._mask_polar(
            j, z,
            DARK_MASK_ORDER,
            self._dark_has_group,
            self._dark_array_reverse_order,
            DARK
        )

    def _mask_layer(self, j, layer, k):
        """
        Create a mask layer.

        j: Gimp.Image
            WIP

        layer: Gimp.Layer
            Clone and give mask to its clone.

        k: string
            Define mask-type.
            Find saved channel.
        """
        # Get the selection channel for the mask.
        channel = self._get_channel(k)
        if channel:
            z = clone_layer(j, layer, self._parent)

            self._mask_q.append(z)
            j.select_item(REPLACE, channel)

            # Create the mask from the selection.
            mask = z.create_mask(SELECTION)

            z.add_mask(mask)
            z.set_name(
                f"{layer.get_name()} {self._component_name} {k}"
            )
            z.set_visible(False)

    def _mask_midtone(self, j, z):
        """
        Create Midtone mask-type layer from Light and Dark selection.

        j: Gimp.Image
            WIP

        z: Gimp.Layer
            masking
        """
        if self._midtone_has_group:
            if self._parent:
                name = self._parent.get_name()

                if name.split()[-1] == ALPHA:
                    n = f'{name} {self._component_name} {MIDTONE}'
                else:
                    n = f'{name} {MIDTONE}'
                a = len(self._parent.get_children())
            else:
                n = f'{z.get_name()} {self._component_name} {MIDTONE}'
                a = get_layer_offset(j, z)
            self._parent = self._create_group(j, self._parent, a, n)

        # Midtone name and channel name, 'i'.
        for i, m in enumerate(self._midtone_process_order):
            # Is the widget option checked?
            if m:
                self._mask_layer(j, z, MIDTONE_PROCESS_ORDER[i])

    def _mask_polar(
        self, j, z, mask_name_q, mask_has_group, mask_order, mask_type
    ):
        """
        Create Light and Dark mask-type layer from saved channel.

        j: Gimp.Image
            WIP

        z: Gimp.Layer
            masking

        mask_name_q: iterable
            [mask name, ...]; in DialogMain Widget order.

        mask_has_group: bool
            Is True if the mask-type has a GroupLayer parent.

        array: list
            [bool, ...]; mask-type option; in DialogMain Widget order

        index_: int
            0 or 1
            Light or Dark
        """
        if mask_has_group:
            if self._parent:
                name = self._parent.get_name()

                if name.split()[-1] == ALPHA:
                    n = f'{name} {self._component_name} {mask_type}'

                else:
                    # A component is the parent.
                    n = f'{name} {mask_type} {GROUP}'
                a = len(self._parent.get_children())
            else:
                n = "{} {} {} {}".format(
                    z.get_name(), self._component_name, mask_type, GROUP
                )
                a = get_layer_offset(j, z)
            self._parent = self._create_group(j, self._parent, a, n)

        # Create mask-layer for the Light or Dark.
        for i1, m in enumerate(mask_order):
            # Is the widget option checked?
            if m:
                self._mask_layer(j, z, mask_name_q[i1])

    def _remove_channels(self, j):
        """After a layer is done, remove saved channel."""
        for a in self._channel_d.values():
            if a:
                j.remove_channel(a)
        self._channel_d = {}

    def _remove_channel(self, k):
        """
        Remove a single channel from the image.

        k: value
            Identify the channel.
            channel key for the channel dict
        """
        channel = self._channel_d.get(k)
        if channel:
            self._image.remove_channel(channel)
            self._channel_d.pop(k)

    def _save_selection(self, k):
        """
        Save the current selection. Remember the
        saved channel with the channel dict.

        k: string
            Is the key for the channel dict.
            Identify the channel.

        Return: Gimp.Channel or None
            newly created
        """
        j = self._image

        if Gimp.Selection.is_empty(j):
            channel = self._channel_d[k] = None

        else:
            selection = j.get_selection()
            channel = self._channel_d[k] = selection.save(j)
            if channel:
                channel.set_name(k)
        return channel

    def _set_group_flag(self):
        """
        Set the GroupLayer flags for the multitude of GroupLayer.
        """
        light_count = self._light_array.count(True)
        midtone_count = self._midtone_array.count(True)
        dark_count = self._dark_array.count(True)
        self._light_has_group = self._is_group and light_count > 1
        self._midtone_has_group = self._is_group and midtone_count > 1
        self._dark_has_group = self._is_group and dark_count > 1

        if self._light_has_group:
            light_count = 1

        if self._midtone_has_group:
            midtone_count = 1

        if self._dark_has_group:
            dark_count = 1

        is_multiple = bool(light_count + midtone_count + dark_count)
        for i, m in enumerate(self._alpha_array):
            self._channel_has_group_q[i] = self._is_group and m and is_multiple

    def _set_mask_range(self):
        """
        Determine the last mask selection needed for each
        mask-group and record it as a range for later processing.

        Midtone mask is dependent on Light and Dark selections,
        so a Midtone mask-type also effects the last selection
        needed for both Light and Dark.
        """
        for i, m in enumerate(self._light_array):
            if m:
                # Set for range production with a zero 'i', '1'.
                self._last_light = i + 1

        for i, m in enumerate(self._midtone_process_order):
            if m:
                self._has_midtone = True

                # Light and Dark mask-groups start with
                # there 2nd member to make a Midtone, '2'.
                if i + 2 > self._last_light:
                    self._last_light = i + 2
                if i + 2 > self._last_dark:
                    self._last_dark = i + 2
        for i, m in enumerate(self._dark_array):
            if m:
                if self._last_dark < i + 1:
                    self._last_dark = i + 1

    def create(self, d, layer_q):
        """
        Make mask layer.

        d: dict
            {widget key: widget value}
            Extract value from the plug-in dialog.

        layer_q: list
            [Selected Gimp.Layer, ...]
            Each layer is processed with the mask settings.
        """
        fail_q = []
        visible_d = {}

        for k, v in d.items():
            setattr(self, f'_{k.lower()}', v)

        self._dark_array_reverse_order = self._dark_array[::-1]
        self._light_array_reverse_order = self._light_array[::-1]

        self._set_group_flag()

        alpha_has_group = (
            self._is_group and self._alpha_array.count(True) > 1
        )
        self._midtone_process_order = self._midtone_array[::-1]
        j = self._image = layer_q[0].get_image()

        save_image_visibility(j, visible_d)
        hide_image_layer(j)
        self._set_mask_range()
        j.undo_disable()    # faster undo

        # layer, 'z'
        for z in layer_q:
            if alpha_has_group:
                self._parent = self._create_group(
                    j,
                    z.get_parent(),
                    get_layer_offset(j, z),
                    f'{z.get_name()} {ALPHA}'
                )
            fail_q += self._do_alpha_type(j, z)

        restore_image_visibility(j, visible_d)
        relocate_lonely_layer(j, self._group_q)
        delete_empty_group(j, self._group_q)
        j.undo_enable()
        Gimp.displays_flush()
        return self._mask_q, fail_q
