#!/usr/bin/env python3
from copy import deepcopy
from lmdt.constant import (
    ALL, ALPHA_CHANNEL, ALPHA_CHANNEL_CHANGE, ALPHA_CHANNEL_TYPE,
    DARK, DARK_MASK_TYPE, GROUP, GROUP_TIP,
    HINT_TEXT, LIGHT, LIGHT_MASK_TYPE,
    MASK_TYPE_CHANGE, MIDTONE, MIDTONE_MASK_TYPE,
    NONE, SELECT_ALPHA_ALL, SELECT_ALPHA_NONE,
    SELECT_BUTTON_SIGNAL, SELECT_LIGHT_ALL, SELECT_LIGHT_NONE,
    SELECT_MIDTONE_ALL, SELECT_MIDTONE_NONE,
    SELECT_DARK_ALL, SELECT_DARK_NONE
)
from lmdt.array_checkbutton import ArrayCheckButton
from lmdt.checkbutton_group import CheckButtonGroup
from plugout.constant import MANAGE, SAVE_
from plugout.container.box import HBox, VBox
from plugout.container.grid import Grid, GridCell, GridRow
from plugout.define.key import (
    CHILD, COLUMN, COLUMNS,
    CUSTOM_SIGNAL, EMIT_SIGNAL,
    HALIGN, MARKUP, PADDING,
    PRESET, SUB_TYPE,
    TEXT, TOOLTIP,
    TYPE, VALUE, WIDTH
)
from plugout.widget.button import Button
from plugout.widget.button_preset import ButtonManage, ButtonSave
from plugout.widget.h_sep import HSeparator
from plugout.widget.hint import Hint
from plugout.widget.label import Label, LabelPreset
import gi                                  # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk              # noqa

# Select Button________________________________________________________________
ALL_BUTTON = {PADDING: (0, 0, 0, 6), TEXT: ALL, TYPE: Button}
NONE_BUTTON = {TEXT: NONE, TYPE: Button}
HBOX_SELECT_BUTTON = {CHILD: {1: ALL_BUTTON, 2: NONE_BUTTON}, TYPE: HBox}

# Alpha Type___________________________________________________________________
ALPHA_CHANNEL_LABEL = {
    HALIGN: Gtk.Align.START, TEXT: ALPHA_CHANNEL, TYPE: Label
}
ALPHA_CHANNEL_BUTTON_ARRAY = {
    CUSTOM_SIGNAL: (SELECT_ALPHA_ALL, SELECT_ALPHA_NONE),
    EMIT_SIGNAL: ALPHA_CHANNEL_CHANGE,
    SUB_TYPE: Gtk.HBox,
    TEXT: ALPHA_CHANNEL_TYPE,
    TYPE: ArrayCheckButton,
    VALUE: (True, False, False, False)
}
GRID_CELL_ALPHA_0 = {
    CHILD: {'alpha_channel_label': ALPHA_CHANNEL_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_ALPHA_1 = {
    CHILD: {'alpha_array': ALPHA_CHANNEL_BUTTON_ARRAY},
    COLUMN: 1,
    TYPE: GridCell,
    WIDTH: 2
}
GRID_CELL_ALPHA_2 = {
    CHILD: {1: deepcopy(HBOX_SELECT_BUTTON)},
    COLUMN: 3,
    TYPE: GridCell
}

for i, d in enumerate(
    GRID_CELL_ALPHA_2[CHILD][1][CHILD].values()
):
    d[EMIT_SIGNAL] = (SELECT_ALPHA_ALL, SELECT_ALPHA_NONE)[i]

GRID_ROW_ALPHA_TYPE = {
    CHILD: {1: GRID_CELL_ALPHA_0, 2: GRID_CELL_ALPHA_1, 3: GRID_CELL_ALPHA_2},
    COLUMNS: 4,
    TYPE: GridRow
}

# Group________________________________________________________________________
GROUP_CHECK_BUTTON = {
    CUSTOM_SIGNAL: (ALPHA_CHANNEL_CHANGE, MASK_TYPE_CHANGE),
    TEXT: GROUP,
    TOOLTIP: GROUP_TIP,
    TYPE: CheckButtonGroup,
    VALUE: False
}
GRID_CELL_GROUP_0 = {
    CHILD: {'is_group': GROUP_CHECK_BUTTON},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_ROW_GROUP = {
    CHILD: {1: GRID_CELL_GROUP_0},
    COLUMNS: 1,
    TYPE: GridRow
}
GRID_ALPHA = {
    CHILD: {1: GRID_ROW_ALPHA_TYPE, 2: GRID_ROW_GROUP},
    TYPE: Grid
}

# Header_______________________________________________________________________
LIGHT_LABEL = {MARKUP: ('b', 'big'), TEXT: LIGHT, TYPE: Label}
MIDTONE_LABEL = {MARKUP: ('b', 'big'), TEXT: MIDTONE, TYPE: Label}
DARK_LABEL = {MARKUP: ('b', 'big'), TEXT: DARK, TYPE: Label}
GRID_CELL_LIGHT_0 = {
    CHILD: {'light_label': LIGHT_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_MIDTONE_1 = {
    CHILD: {'midtone_label': MIDTONE_LABEL},
    COLUMN: 1,
    TYPE: GridCell
}
GRID_CELL_DARK_2 = {
    CHILD: {'dark_label': DARK_LABEL},
    COLUMN: 2,
    TYPE: GridCell
}
GRID_ROW_HEADER = {
    CHILD: {
        1: GRID_CELL_LIGHT_0, 2: GRID_CELL_MIDTONE_1, 3: GRID_CELL_DARK_2
    },
    COLUMNS: 3,
    TYPE: GridRow
}

# Light________________________________________________________________________
LIGHT_CHECK_BUTTON_ARRAY = {
    CUSTOM_SIGNAL: (SELECT_LIGHT_ALL, SELECT_LIGHT_NONE),
    EMIT_SIGNAL: MASK_TYPE_CHANGE,
    SUB_TYPE: Gtk.VBox,
    TEXT: LIGHT_MASK_TYPE,
    TYPE: ArrayCheckButton,
    VALUE: (False, False, False, False, False)
}
MIDTONE_CHECK_BUTTON_ARRAY = {
    CUSTOM_SIGNAL: (SELECT_MIDTONE_ALL, SELECT_MIDTONE_NONE),
    EMIT_SIGNAL: MASK_TYPE_CHANGE,
    SUB_TYPE: Gtk.VBox,
    TEXT: MIDTONE_MASK_TYPE,
    TYPE: ArrayCheckButton,
    VALUE: (False, False, False, False)
}
DARK_CHECK_BUTTON_ARRAY = {
    CUSTOM_SIGNAL: (SELECT_DARK_ALL, SELECT_DARK_NONE),
    EMIT_SIGNAL: MASK_TYPE_CHANGE,
    SUB_TYPE: Gtk.VBox,
    TEXT: DARK_MASK_TYPE,
    TYPE: ArrayCheckButton,
    VALUE: (False, False, False, False, False)
}
GRID_CELL_LIGHT_0 = {
    CHILD: {'light_array': LIGHT_CHECK_BUTTON_ARRAY},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_MIDTONE_1 = {
    CHILD: {'midtone_array': MIDTONE_CHECK_BUTTON_ARRAY},
    COLUMN: 1,
    TYPE: GridCell
}
GRID_CELL_DARK_2 = {
    CHILD: {'dark_array': DARK_CHECK_BUTTON_ARRAY},
    COLUMN: 2,
    TYPE: GridCell
}
GRID_ROW_MASK_TYPE = {
    CHILD: {1: GRID_CELL_LIGHT_0, 2: GRID_CELL_MIDTONE_1, 3: GRID_CELL_DARK_2},
    COLUMNS: 3,
    TYPE: GridRow
}

# Preset_______________________________________________________________________
PRESET_LABEL = {HALIGN: Gtk.Align.START, TYPE: LabelPreset}
MANAGE_BUTTON = {TEXT: MANAGE, TYPE: ButtonManage}
SAVE_BUTTON = {PADDING: (0, 0, 0, 4), TEXT: SAVE_, TYPE: ButtonSave}
HBOX_PRESET_BUTTON = {
    CHILD: {
        'save_button': SAVE_BUTTON,
        'manage_button': MANAGE_BUTTON
    },
    TYPE: HBox
}
GRID_CELL_PRESET_0 = {
    CHILD: {'preset_label': PRESET_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_PRESET_1 = {
    CHILD: {1: HBOX_PRESET_BUTTON},
    COLUMN: 1,
    WIDTH: 2,
    TYPE: GridCell
}
GRID_ROW_PRESET = {
    CHILD: {1: GRID_CELL_PRESET_0, 2: GRID_CELL_PRESET_1},
    COLUMNS: 2,
    TYPE: GridRow
}
GRID_PRESET = {CHILD: {1: GRID_ROW_PRESET}, TYPE: Grid}

# Select Mask Type_____________________________________________________________
GRID_CELL_SELECT_BUTTON_0 = {
    CHILD: {1: deepcopy(HBOX_SELECT_BUTTON)}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_SELECT_BUTTON_1 = {
    CHILD: {1: deepcopy(HBOX_SELECT_BUTTON)}, COLUMN: 1, TYPE: GridCell
}
GRID_CELL_SELECT_BUTTON_2 = {
    CHILD: {1: deepcopy(HBOX_SELECT_BUTTON)}, COLUMN: 2, TYPE: GridCell
}
GRID_ROW_SELECT_BUTTON = {
    CHILD: {
        1: GRID_CELL_SELECT_BUTTON_0,
        2: GRID_CELL_SELECT_BUTTON_1,
        3: GRID_CELL_SELECT_BUTTON_2
    },
    COLUMNS: 3,
    TYPE: GridRow
}
d = GRID_ROW_SELECT_BUTTON[CHILD]

for i, k in enumerate(d):
    e = d[k][CHILD]
    for d1 in e.values():
        d2 = d1[CHILD]
        for i1, d3 in enumerate(d2.values()):
            d3[EMIT_SIGNAL] = SELECT_BUTTON_SIGNAL[i][i1]

# Separator____________________________________________________________________
HSEPARATOR = {PADDING: (1, 1, 0, 0), TYPE: HSeparator}
GRID_CELL_HSEPARATOR_0 = {
    CHILD: {'separator': HSEPARATOR}, COLUMN: 0, WIDTH: 2, TYPE: GridCell
}
GRID_ROW_SEPARATOR = {
    CHILD: {1: GRID_CELL_HSEPARATOR_0}, COLUMNS: 3, TYPE: GridRow
}

HINT = {
    PADDING: (0, 0, 0, 10),
    TEXT: HINT_TEXT,
    TYPE: Hint
}

# AnyGroup definition: {key: definition}
DEFINE_MAIN = {
    'main': {
        CHILD: {
            1: HINT,
            2: {
                CHILD: {
                    1: GRID_ROW_SEPARATOR,
                    2: GRID_ROW_HEADER,
                    3: GRID_ROW_SEPARATOR,
                    4: GRID_ROW_MASK_TYPE,
                    5: GRID_ROW_SELECT_BUTTON,
                    6: GRID_ROW_SEPARATOR
                },
                TYPE: Grid
            },
            3: GRID_ALPHA,
            4: GRID_PRESET,
        },

        # Create a preset, but don't give it a key so that
        # preset file will reside in the '.../LMDT/Preset' folder.
        PRESET: None,
        TYPE: VBox
    }
}
