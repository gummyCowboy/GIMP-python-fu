#!/usr/bin/env python3
from plugout.constant import CONTAINER_CHANGE
from plugout.define.key import CUSTOM_SIGNAL, SUB_TYPE, TEXT, VALUE
from plugout.widget.value import ContainerValue
from random import choice
import gi                                  # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk              # noqa


class ArrayCheckButton(ContainerValue):
    """Manage an array of 'Gtk.CheckButton'."""
    change_signal = CONTAINER_CHANGE

    def __init__(self, def_d):
        """
        def_d: dict
            CheckButton definition
                custom_signal: string
                    DialogMain GObject Signal

                sub_type: Gtk.Box
                    Contain the 'Gtk.CheckButton'.

                text: string
                    Display a descriptor for the CheckButton.

                value: bool
                    Initialize the Widget value.
        """
        box = def_d[SUB_TYPE]()
        is_hbox = isinstance(box, Gtk.HBox)
        box.set_homogeneous(is_hbox)
        self._widget_q = []
        self._value_q = []
        value = def_d.get(VALUE)
        self._custom_signal = def_d.get(CUSTOM_SIGNAL)

        for i, n in enumerate(def_d.get(TEXT, ())):
            g = Gtk.CheckButton.new_with_label(n)

            for n1 in ('toggled', 'clicked', 'realize'):
                g.connect(n1, self.on_array_button_click)

            if value is not None:
                self._value_q.append(value[i])

            else:
                self._value_q[i] = 0

            g.set_active(value[i])
            self._widget_q.append(g)

            if is_hbox:
                box.add(g)
            else:
                box.pack_start(g, False, False, 0)

        super().__init__(def_d, box)
        self.value_d[self.key] = value

    def get_a(self):
        """
        Retrieve the value of the 'Gtk.CheckButton'.

        Return: list
            [Gtk.CheckButton active state, ...]
        """
        return self._value_q

    def on_array_button_click(self, g):
        """
        Update the Widget's value when any 'Gtk.CheckButton'
        has its value altered.

        g: Gtk.CheckButton
            Was altered.
        """
        i = None

        for i, g1 in enumerate(self._widget_q):
            if g1 == g:
                break
        if i is not None:
            self._value_q[i] = g.get_active()
            self.on_value_change(self, self.change_signal)

    def on_custom_signal(self, _, arg):
        """
        Select all or none of the 'Gtk.CheckButton' in the array.

        _: DialogMain
            Sent the signal.

        arg: tuple
            (Widget instance, signal)
        """
        custom_signal = arg[-1]

        if custom_signal in self._custom_signal:
            i = self._custom_signal.index(custom_signal)
            m = not i
            for g in self._widget_q:
                g.set_active(m)
        self.on_value_change(self, self.change_signal)

    def randomize(self, *_):
        """
        Respond to a randomize signal. Randomize
        the value of the 'Gtk.CheckButton'.
        """
        for g in self._widget_q:
            g.set_active(choice((False, True)))

    def set_a(self, q):
        """
        Set the value of the 'Gtk.CheckButton' array.

        q: list
            [bool, ...]
            Set 'Gtk.CheckButton' to boolean.
        """
        for i, a in enumerate(q):
            self._value_q[i] = a
            self._widget_q[i].set_active(a)
        self.on_value_change(self, self.change_signal)
