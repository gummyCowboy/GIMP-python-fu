#!/usr/bin/env python3
from plugout.constant import RANDOMIZE
from plugout.define.key import RANDOMER, TEXT
from plugout.widget.emit import WidgetEmitter
import gi                                  # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk              # noqa

"""
Include 'Gtk.Button' wrapper class and derivative class.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/Button.html'
"""


class Button(WidgetEmitter):
    """Customize 'Gtk.Button' with this wrapper."""
    change_signal = 'clicked'

    def __init__(self, def_d):
        """
        def_d: dict
            Button definition
                text: string
                    Display on button face.
        """
        g = Gtk.Button.new_with_label(def_d.get(TEXT, ""))
        super().__init__(def_d, g)

    def get_a(self):
        """
        Widget calls this function when the Gtk.Button is clicked.

        Return: string
            custom signal
            The button doesn't really have a value, but is using the
            change function to emit signal.
        """
        return self.emit_signal


class ButtonRandom(Button):
    """Customize Button with a RANDOMIZE signal emitter."""

    def __init__(self, def_d):
        """
        def_d: dict
            ButtonRandom definition
                randomer: Container
                    Emit RANDOMIZE signal.
        """
        super().__init__(def_d)
        self.widget.connect('clicked', self.on_random_click)
        self._randomer = def_d.get(RANDOMER)

    def on_random_click(self, *_):
        """
        Send the 'randomize' signal to the option group's packaged content.
        """
        if self._randomer:
            self._randomer.emit(RANDOMIZE, None)
