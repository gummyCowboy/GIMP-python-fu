#!/usr/bin/env python3
from lmdt.constant import (
    DIALOG_MAIN_SIGNAL, FAIL_HEADER, FAIL_LINE,
    NO_LAYER_SELECTED, TITLE
)
from lmdt.define_main import DEFINE_MAIN
from lmdt.output import Output
from plugout.any_group import AnyGroup
from plugout.constant import (
    ACCEPT, ANY_CHANGE, CANCEL, CANCEL_TYPE, DELETE_TYPE, OK_TYPE
)
from plugout.container.content_area import ContentArea
from plugout.dialog.dialog import Dialog
import gi                                           # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GObject             # noqa


def get_selected_drawable_layer(q):
    """
    Create a list of selected 'Gimp.Layer'.

    q: list
        [Gimp.Layer, ..., Gimp.GroupLayer, ...]
        Remove GroupLayer from list.

    Return: list
        [Gimp.Layer, ...]
    """
    # Filter out GroupLayer.
    return [
        i for i in q if not Gimp.Item.id_is_group_layer(i.get_id())
    ]


class DialogMain(GObject.GObject, Dialog):
    """Create a Dialog for creating Yin-Yang symbol."""
    __gsignals__ = DIALOG_MAIN_SIGNAL

    def __init__(self, image, drawables):
        """Open a dialog. Respond to user interaction."""
        def _on_accept():
            self.dialog.destroy()
            self.dialog = None
            self.on_accept()

        def _on_cancel():
            self.dialog.destroy()
            self.dialog = None

        GObject.GObject.__init__(self)

        self._preview_d = {}
        self._accept_button = None
        self._image = image
        self._output = Output()
        self._layer_q = get_selected_drawable_layer(drawables)

        self.connect(ANY_CHANGE, self.on_any_change)
        if self._layer_q:
            Dialog.__init__(
                self,
                TITLE,
                ((CANCEL, CANCEL_TYPE), (ACCEPT, OK_TYPE)),
                self.add_widget,
                {
                    CANCEL_TYPE: _on_cancel,
                    DELETE_TYPE: _on_cancel,
                    OK_TYPE: _on_accept
                }
            )
        else:
            # Let the user know about the layer situation.
            # Thee must be a Gimp.Layer selected.
            Gimp.message(NO_LAYER_SELECTED)

    def _process_fail(self, fail_q):
        """
        Notify the user of failed mask-type.

        fail_q: list
            [(layer name, mask type string)]
        """
        n = FAIL_HEADER

        for q in fail_q:
            name, component, mask_type = q
            n = n + FAIL_LINE.format(name, component, mask_type)
        Gimp.message(n)

    def add_widget(self, content_area):
        """
        Add widget to the Dialog's content area.

        content_area: Gtk.Box
            There's room to grow.
        """
        self._accept_button = self.dialog.get_widget_for_response(OK_TYPE)
        container = ContentArea(content_area)
        self._any_group = AnyGroup(
            DEFINE_MAIN,
            container,
            preset_key=None,
            is_any_change=True,
            host=self
        )
        content_area.show_all()

    def on_accept(self):
        """
        Respond to a Preview button action by performing a preview
        but only if things have changed since the last preview.
        """
        d = self._any_group.value_d

        # WIP image's selection channel, 'channel'
        channel = None

        # WIP image, 'j'
        j = self._image

        if not Gimp.Selection.is_empty(j):
            # Remember selection.
            selection = j.get_selection()
            channel = selection.save(j)

        masked_q, fail_q = self._output.create(d, self._layer_q)

        if fail_q:
            self._process_fail(fail_q)

        if channel:
            for z in masked_q:
                # Combine the layer mask with the original
                # selection's channel. The layer mask is
                # modified with the intersection.
                z.get_mask().combine_masks(
                    channel, Gimp.ChannelOps.INTERSECT, .0, .0
                )

            # Restore the selection.
            j.select_item(Gimp.ChannelOps.REPLACE, channel)
            j.remove_channel(channel)

        else:
            Gimp.Selection.none(j)

        # Restore the selected layers.
        j.set_selected_layers(self._layer_q)

    def on_any_change(self, *_):
        """
        Respond to ANY_CHANGE. Set the Accept button's sensitivity.
        The Accept option is not valid if there is no Alpha
        Channel selected, or if there is no mask-type selected.
        """
        d = self._any_group.value_d

        if not d['alpha_array'].count(True):
            self._accept_button.set_sensitive(0)

        elif not (
            d['light_array'].count(True) or
            d['dark_array'].count(True) or
            d['midtone_array'].count(True)
        ):
            self._accept_button.set_sensitive(0)
        else:
            self._accept_button.set_sensitive(1)
