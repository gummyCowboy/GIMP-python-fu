#!/usr/bin/env python3
from yy_constant import COLOR_TIP, SEPARATOR, DefKey as dk
from yy_preset import Preset
from yy_signal import convert_float_color_to_int
from random import choice, randint, randrange, uniform
import colorsys
import gi       # type: ignore
gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Gdk, Gimp, GimpUi, Gtk  # noqa

"""Include a broad range of Widget class."""


def check_for_separator(list_store, tree_iter):
    """
    Check a ComboBox value to see if it's an separator.

    Return: bool
        If True, then the value is a separator.
    """
    n = list_store.get_value(tree_iter, 0)

    if n:
        return n == SEPARATOR
    return False


class Widget:
    """
    Is a base class for custom Gtk.Widget.
    Wrap a Gtk.Widget for customization needs.
    """

    def __init__(self, d, inter_comm, data_d, k, g):
        """
        d: dict
            Define Widget.
            Optional item
            padding: tuple
            tooltip: string

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        k: value
            Identify Widget in an AnyGroup.

        g: Gtk.Widget
            Assign to 'widget'.
        """
        # Identify the Widget in a Preset.
        self.key = k

        # Reference the Gtk widget instance.
        self.widget = g

        # Reference the Gtk widget as an add-able instance.
        self.gtk_g = g

        # read-only widget definition dict, 'd'
        self.def_d = d

        self._limit = d.get(dk.LIMIT)

        self.data_d = data_d
        q = d.get(dk.PADDING)
        self._dialog = inter_comm.main

        if q:
            self.gtk_g = Gtk.Alignment()
            self.gtk_g.add(g)
            self.gtk_g.set_padding(*q)

        tooltip = d.get(dk.TOOLTIP)
        if tooltip:
            g.set_tooltip_text(tooltip)

        signal_q = d.get(dk.SIGNAL)

        if signal_q:
            for q in signal_q:
                g.connect(*q)

        # Check subordinate for function, 'randomize'.
        if hasattr(self, 'randomize'):
            group = inter_comm.group
            if group and self._limit is not None:
                # When 'group' sends the 'randomize' signal,
                # this object will get the signal.
                group.connect('randomize', self.randomize)

    def on_change(self, *_):
        self.data_d[self.key] = self.get_a()
        if self._dialog:
            self._dialog.emit('any-change', None)


class Button(Widget):
    """Is a custom Gtk.Button."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:
            text: string

        inter_comm: InterComm
            Identify option group.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        g = Gtk.Button.new_with_label(d.get(dk.TEXT, ""))
        super().__init__(d, inter_comm, data_d, key, g)


class ButtonRandomColor(Button):
    """Is a custom Gtk.Button."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:
            text: string

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        super().__init__(d, inter_comm, data_d, key)
        self.following = ()

    def on_random_color_button_click(self, _, i):
        """
        Randomize color button value on multiple random-button action.

        _: Gtk.Button
            Is responsible.

        i: index
            the random button's ordered index
        """
        rgb = [uniform(.0, 1.) for _ in range(3)]

        if i:
            i1 = i - 1

            # hue, saturation, lightness, 'q', in float, .0 to 1.
            q = list(colorsys.rgb_to_hls(*rgb))

            # Invert HLS value.
            q[i1] = 1. - q[i1]

            rgb1 = list(colorsys.hls_to_rgb(*q))

        else:
            # Invert color.
            rgb1 = [1. - f for f in rgb]

        # The Rim color is randomly borrowing.
        rgb2 = [(rgb[i], rgb1[i])[randint(0, 1)] for i in range(3)]

        for a in zip(self.following, (rgb, rgb1, rgb2)):
            g, q = a

            g.set_rgba(Gdk.RGBA(*q))

            # Gtk only sends this signal when its dialog is accepted.
            g.emit('color-set')


class ButtonRandom(Button):
    """Is a custom Gtk.Button."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:
            text: string

        inter_comm: InterComm
            Identify option group.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        super().__init__(d, inter_comm, data_d, key)
        self.widget.connect('clicked', self.on_random_click)
        self._group = inter_comm.group

    def on_random_click(self, *_):
        self._group.emit('randomize', None)


class CheckButton(Widget):
    """Is a custom Gtk.CheckButton."""

    def __init__(self, d, e, data_d, key):
        """
        d: dict
            Optional Item:
            text: string

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        g = Gtk.CheckButton.new_with_label(d.get(dk.TEXT, ""))

        super().__init__(d, e, data_d, key, g)

        g.connect('toggled', self.on_change)
        g.connect('clicked', self.on_change)

        m = data_d[key] = d.get(dk.VALUE, False)
        g.set_active(m)

    def randomize(self, *_):
        self.set_a(choice(self._limit))

    def get_a(self):
        """
        Retrieve the value of the Gtk.CheckButton.

        Return: bool
        """
        return self.widget.get_active()

    def set_a(self, m):
        """
        Set the value of the Gtk.CheckButton.

        m: bool
            Receive value.
        """
        self.widget.set_active(m)


class CheckButtonLeader(CheckButton):

    def __init__(self, d, e, data_d, key):
        super().__init__(d, e, data_d, key)
        self.following = ()

    def on_leader_toggle(self, button):
        """
        Respond to a leader CheckButton change. Hide or show following widget.

        button: Gtk.CheckButton
            Is responsible.
        """
        if button.get_active():
            for g in self.following:
                # fool-proof
                if g:
                    g.show()
        else:
            for g in self.following:
                # fool-proof
                if g:
                    g.hide()


class ColorButton(Widget):
    """Is a custom Gtk ColorButton."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:
            value: Gdk.RGBA

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        g = Gtk.ColorButton.new()

        super().__init__(d, inter_comm, data_d, key, g)
        g.connect('color-set', self.on_change)
        g.connect('color-set', self.on_color_set)
        g.connect('realize', self.on_color_set)

        q = data_d[key] = d.get(dk.VALUE, (1., 1., 1., 1.))
        self.set_a(q)

    def get_a(self):
        """
        Retrieve the value of the Gtk.ColorButton.

        Return: tuple
            high precision float
            (.0 to 1.)
        """
        a = self.widget.get_rgba()
        return a.red, a.green, a.blue, a.alpha

    @staticmethod
    def on_color_set(color_button):
        """
        A ColorButton changed value, so its tooltip needs updating.

        color_button: Gtk.ColorButton
            Has a new value.
        """
        rgba = convert_float_color_to_int(color_button.get_rgba())
        color_button.set_tooltip_text(COLOR_TIP.format(*rgba))

    def randomize(self, *_):
        self.set_a([uniform(.0, 1.) for _ in range(3)])

    def set_a(self, q):
        """
        q: tuple or list
            RGBA; (.0 to 1., .0 to 1., .0 to 1., .0 to 1.)
        """
        self.widget.set_rgba(Gdk.RGBA(*q))

        # Gtk only sends this signal when its dialog is accepted.
        self.widget.emit('color-set')


class ComboBoxText(Widget):
    """Is a custom Gtk ComboBoxText."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:
            get_list: function

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        g = Gtk.ComboBoxText.new()
        p = self._get_list = d.get(dk.GET_LIST)

        super().__init__(d, inter_comm, data_d, key, g)

        if p:
            for n in p():
                g.append_text(n)

        g.connect('changed', self.on_change)
        g.set_row_separator_func(check_for_separator)

        i = data_d[key] = d.get(dk.VALUE, 0)
        self.set_a(i)

    def get_a(self):
        """
        Retrieve the value of the Gtk.ComboBoxText.

        Return: value
        """
        return self.widget.get_active_text()

    def randomize(self, *_):
        """Randomize the Gtk.ComboBoxText's value."""
        a = 0
        n = SEPARATOR

        while n == SEPARATOR:
            a = randrange(*self._limit)
            n = self.def_d[dk.GET_LIST]()[a]
        self.set_a(a)

    def set_a(self, a):
        """
        Set the active value in the Gtk.ComboBoxText.

        a: int or string
            Is the index to the value that is to become active.
        """
        if isinstance(a, str):
            if a in self._get_list():
                # Convert string to index-int.
                a = self._get_list().index(a)
            else:
                a = 0
        self.widget.set_active(a)


class Entry(Widget):
    """Is a custom 'Gtk.Entry'."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        g = Gtk.Entry.new()
        data_d[key] = d.get(dk.VALUE, "")

        super().__init__(d, inter_comm, data_d, key, g)
        g.connect('changed', self.on_change)

    def get_a(self):
        """
        Fetch the value of the Gtk.Entry.

        Return: string
        """
        return self.widget.get_text()

    def set_a(self, n):
        """
        Set the value of the Gtk.Entry.

        n: string
            Receive value.
        """
        self.widget.set_text(n)


class EntrySave(Entry):
    """Is a custom 'Gtk.Entry'."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        super().__init__(d, inter_comm, data_d, key)
        self.following = ()

    def on_save_entry_change(self, entry):
        """
        Update the path reflect label on the preset's name Entry change.

        entry: Gtk.Entry
            Has text to append to the preset path.
        """
        # path reflect label index, '0'
        self.following[0].set_label(f'{Preset.path}{entry.get_text()}.json')


class GradientButton(Widget):
    """Is a custom GimpUi.PatternChooser."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        g = GimpUi.GradientChooser.new()

        super().__init__(d, inter_comm, data_d, key, g)
        g.connect('resource-set', self.on_change)

        n = data_d[key] = d.get(dk.VALUE, "Default")
        resource = Gimp.Gradient.get_by_name(n)
        if resource:
            self.set_resource(resource)

    def get_a(self):
        """
        Retrieve the value of the GimpUi.GradientChooser.

        Return: string
            Gradient name
        """
        a = self.widget.get_resource()
        if a:
            return a.get_name()

    def get_resource(self):
        """
        Retrieve the value of the GimpUi.GradientChooser.

        Return: Gimp.Gradient
        """
        return self.widget.get_resource()

    def randomize(self, *_):
        self.set_resource(choice(self._limit()))

    def set_a(self, n):
        """
        Set the value of the GimpUi.GradientChooser.

        n: string
            Find its Gimp.Gradient.
        """
        a = Gimp.Gradient.get_by_name(n)
        if a:
            self.set_resource(a)

    def set_resource(self, a):
        """
        Set the value of the GimpUi.GradientChooser.

        a: Gimp.Gradient
            Receive value.
        """
        self.widget.set_resource(a)
        self.widget.emit('resource-set', a, True)


class Label(Widget):
    """Is a custom Gtk.Label."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:
            text: string
                Is the label's display descriptor.

            x_align: float
                Align the label horizontally in its container.

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        label = Gtk.Label(label=d.get(dk.TEXT, ""))

        super().__init__(d, inter_comm, data_d, key, label)

        if d.get(dk.X_ALIGN):
            label.set_xalign(d[dk.X_ALIGN])

        if d.get(dk.HALIGN):
            label.set_halign(d[dk.HALIGN])
        label.set_yalign(.5)


class PatternButton(Widget):
    """Is a custom GimpUi.PatternChooser."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        g = GimpUi.PatternChooser.new()

        super().__init__(d, inter_comm, data_d, key, g)
        g.connect('resource-set', self.on_change)

        n = data_d[key] = d.get(dk.VALUE, "Big Blue")
        resource = Gimp.Pattern.get_by_name(n)
        if resource:
            self.widget.set_resource(resource)

    def get_a(self):
        """
        Retrieve the value of the GimpUi.PatternChooser.

        Return: string
            Gimp.Pattern name
        """
        a = self.widget.get_resource()
        if a:
            return a.get_name()

    def get_resource(self):
        """
        Retrieve the value of the GimpUi.PatternChooser.

        Return: Gimp.Pattern
        """
        return self.widget.get_resource()

    def randomize(self, *_):
        self.set_resource(choice(self._limit()))

    def set_a(self, n):
        """
        Set the value of the GimpUi.PatternChooser.

        n: string
            Find its Gimp.Gradient.
        """
        a = Gimp.Pattern.get_by_name(n)
        if a:
            self.set_resource(a)

    def set_resource(self, a):
        """
        Set the value of the GimpUi.PatternChooser.

        a: Gimp.Gradient
            Receive value.
        """
        self.widget.set_resource(a)
        self.widget.emit('resource-set', a, True)


class RadioGroup(Widget):
    """Organize Gtk.RadioButton in a group."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:
            text: tuple

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        hbox = Gtk.HBox(homogeneous=d.get(dk.HOMOGENEOUS, True))

        super().__init__(d, inter_comm, data_d, key, hbox)

        self.button_q = []
        group = None

        for n in d.get(dk.TEXT, ()):
            g = Gtk.RadioButton.new_with_label_from_widget(group, n)

            g.connect('toggled', self.on_change)
            self.button_q.append(g)

            if not group:
                group = g
            hbox.add(g)
        if self.button_q:
            a = data_d[key] = d.get(dk.VALUE, 0)
            self.button_q[a].set_active(1)

    def get_a(self):
        """
        Retrieve the index of the Gtk.RadioButton that is active.

        Return: int
        """
        for i, g in enumerate(self.button_q):
            if g.get_active():
                return i

        # nothing active
        return 0

    def randomize(self, *_):
        choice(self.button_q).set_active(1)

    def set_a(self, a):
        """
        Adapt to change in preset by checking type.

        a: int or string
            The older version used string.
        """
        if isinstance(a, int):
            # A Preset may have outdated input.
            if a < len(self.button_q):
                self.button_q[a].set_active(1)
            else:
                self.button_q[0].set_active(1)
        else:
            self.button_q[0].set_active(1)


class RadioGroupType(RadioGroup):

    def __init__(self, d, inter_comm, data_d, key):
        super().__init__(d, inter_comm, data_d, key)
        self.following = {}

    def on_type_change(self, button):
        """
        Respond to Type Gtk.ComboBoxText change signal.

        button: Gtk.RadioButton
            Is responsible.
        """
        if button.get_active():
            k = button.get_label()
            d = self.following

            for k1, v in d.items():
                if k != k1:
                    for g in v:
                        g.hide()
            for g in d[k]:
                g.show()


class SpinButton(Widget):
    """Is a custom Gtk.SpinButton."""

    def __init__(self, d, inter_comm, data_d, key):
        """
        d: dict
            Optional Item:
            adjustment: tuple
            digits: int
            value: float

        inter_comm: InterComm
            Serve communication between Dialog/Window, Container and Widget.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        self._digits = d.get(dk.DIGITS, 0)
        g = Gtk.SpinButton.new(
            Gtk.Adjustment.new(*d[dk.ADJUSTMENT]),
            climb_rate=.02,
            digits=self._digits
        )

        super().__init__(d, inter_comm, data_d, key, g)
        g.connect('value-changed', self.on_change)
        g.set_numeric(True)
        g.set_snap_to_ticks(True)
        g.set_max_length(7)
        g.set_width_chars(7)

        a = data_d[key] = d.get(dk.VALUE, .0)
        g.set_value(a)

    def get_a(self):
        """
        Retrieve the value of the Gtk.SpinButton.

        Return: float or int
        """
        f = self.widget.get_value()

        if not self._digits:
            return int(f)
        return round(f, self._digits)

    def randomize(self, *_):
        """
        Randomize the Gtk.SpinButton's value.
        Integer and float have different random function.
        """
        if self._digits:
            self.set_a(uniform(*self._limit))
        else:
            self.set_a(randint(*self._limit))

    def set_a(self, f):
        """
        Set the value of the Gtk.SpinButton.

        f: float
            Receive value.
        """
        self.widget.set_value(f)


class SpinButtonRim(SpinButton):
    """
    The Rim Width option has a following that changes
    visibility depending on the widget's value.
    """

    def __init__(self, d, e, data_d, key):
        super().__init__(d, e, data_d, key)
        self.following = ()

    def on_rim_width_change(self, button):
        """
        Respond to change in the Rim Width SpinButton
        by hiding or showing Rim Color's VBox.
        """
        a = button.get_value()
        for g in self.following:
            (g.hide, g.show)[a > 0]()
