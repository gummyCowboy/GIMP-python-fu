#!/usr/bin/env python3
import gi       # type: ignore
import os
import sys

gi.require_version('Gimp', '3.0')
gi.require_version('GimpUi', '3.0')

from gi.repository import Gimp, GLib       # type: ignore

"""This is LMDT version 2.01."""

PROC_NAME = 'plug-in-luminosity-mask-drive-thru'

# Append paths to "sys.path" for GIMP's Python
# interpreter. "__file__" is GIMP's plug-in path.
n = os.path.sep
module_path = os.path.dirname(__file__) + n + "Module"

# If a folder path isn't in "sys.path", then add the path.
if module_path not in sys.path:
    sys.path.append(module_path)

from lmdt_dialog import PluginDialog       # type: ignore
from lmdt_output import _                  # type: ignore


class LMDT(Gimp.PlugIn):
    """Initialize the plug-in with GIMP 3."""

    def do_query_procedures(self):
        return [PROC_NAME]

    def do_set_i18n(self, name):
        # Support language translation.
        return True, 'gimp30-python', None

    def do_create_procedure(self, name):
        """
        Define plug-in so that it can be run.

        name: string
            Is the name of the plug-in and is sourced from PROC_NAME.
        """
        procedure = Gimp.ImageProcedure.new(
            self,
            name,
            Gimp.PDBProcType.PLUGIN,
            self.run,
            None               # run data
        )
        # Require drawable.
        procedure.set_sensitivity_mask(
            Gimp.ProcedureSensitivityMask.DRAWABLE |
            Gimp.ProcedureSensitivityMask.DRAWABLES
        )
        procedure.set_image_types("RGB*, GRAY*")
        procedure.set_menu_label("_Luminosity Mask Drive Thru")
        procedure.add_menu_path('<Image>/Layer/Mask/')
        procedure.set_documentation(
            # tooltip
            _("Create luminosity mask."),

            # Plug-in Browser blurb
            _(
                "Create luminosity mask on selected"
                " layer(s) with/without selection."
            ),
            name
        )
        procedure.set_attribution("Charles Bartley", "Charles Bartley", "2024")
        return procedure

    def run(self, procedure, run_mode, n_drawables, drawables, args, run_data):
        """
        Produce layer output.

        procedure: Gimp.ImageProcedure
            Manage plug-in.

        run_mode: enum
            Gimp.RunMode

        n_drawables: int
            Is the number of active drawables in the image.
            not used

        drawables: list
            active drawable
            [drawable, ...]

        args: Gimp.ValueArray
            How is this used?
            Has a length() function that could be useful.
            not used

        run_data: value
            Relayed from the 'do_create_procedure'.
            not used
        """
        # Check run mode. If interactive create
        # dialog, otherwise use previous settings.
        if run_mode == Gimp.RunMode.INTERACTIVE:
            Gimp.context_push()
            Gimp.context_set_interpolation(Gimp.InterpolationType.NOHALO)
            PluginDialog(drawables)
            Gimp.displays_flush()
            Gimp.context_pop()

        else:
            # Use previous settings.
            # This is dependent on the shelf which is a GIMP WIP.
            pass

        return procedure.new_return_values(
            Gimp.PDBStatusType.SUCCESS, GLib.Error()
        )


Gimp.main(LMDT.__gtype__, sys.argv)
