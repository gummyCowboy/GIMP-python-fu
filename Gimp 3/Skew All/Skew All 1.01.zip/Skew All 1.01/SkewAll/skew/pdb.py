#!/usr/bin/env python3
from skew.constant import REPLACE
import gi                              # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp         # noqa

"""
Include a function to initialize static pdb
run class, and static pdb run class.
"""


def init_pdb():
    """Implement a get-once strategy for Gimp's pdb interface. """
    for q in (
        (Autocrop, 'gimp-image-crop'),
        (Copy, 'gimp-edit-copy-visible'),
        (Paste, 'gimp-edit-paste'),
        (Transform, 'gimp-item-transform-perspective')
    ):
        a, n = q
        a.pdb = Gimp.get_pdb().lookup_procedure(n)
        a.config = a.pdb.create_config()


class Autocrop:
    pdb = config = None

    def do(j):
        """
        Autocrop an image removing excess border space.
        This function removes an existing 'Gimp.Selection'.

        j: Gimp.Image
            WIP
        """
        Autocrop.config.set_property('image', j)
        Gimp.Selection.none(j)

        offset_x = offset_y = 99999999.
        max_x = max_y = 0.

        # Get min and max bounds of the image.
        for z in j.get_layers():
            j.select_item(REPLACE, z)
            non_empty, x, y, x1, y1 = Gimp.Selection.bounds(j)[1:]
            if non_empty:
                if x < offset_x:
                    offset_x = x

                if y < offset_y:
                    offset_y = y

                if x1 > max_x:
                    max_x = x1
                if y1 > max_y:
                    max_y = y1
        q = {
            ('new-width', max_x - offset_x),
            ('new-height', max_y - offset_y),
            ('offx', offset_x),
            ('offy', offset_y)
        }

        for q1 in q:
            Autocrop.config.set_property(*q1)

        Autocrop.pdb.run(Autocrop.config)
        Gimp.Selection.none(j)


class Copy:
    pdb = config = None

    def do(q):
        """
        Copy an image's visible projection into the Gimp internal buffer.

        q: tuple
            Configure the procedure.
            (
                ('image', Gimp.Image),
            )

        Return: Gimp paste buffer
        """
        for q1 in q:
            Copy.config.set_property(*q1)
        Copy.pdb.run(Copy.config)


class Paste:
    pdb = config = None

    def do(j):
        """
        Paste a layer onto the top of an image.
        The image is assumed to a have at least one layer.

        j: Gimp.Image
            Receive pasted layer.

        Return: Gimp.Layer
            Is on top of the image.
        """
        z = j.get_layers()[0]

        for q in (('drawable', z), ('paste-into', True)):
            Paste.config.set_property(*q)

        # 'gobject.GBoxed' throws an error in RC1 on
        # print, so the result is useless here.
        Paste.pdb.run(Paste.config)

        z = j.get_layers()[0]

        Gimp.floating_sel_to_layer(z)
        return z


class Transform:
    pdb = config = None

    def do(*arg):
        """
        Shape a layer bounds rectangle into a polygon.

        arg: tuple
            (drawable, x, y, ...)
            Gimp.Drawable
                Is transformed.

            x, y
                x, y; Is a series of x, y; 4 points; 8 coordinates
                topleft, top-right, bottom-left, bottom-right point-order
        """
        for q in zip(
            ('item', 'x0', 'y0', 'x1', 'y1', 'x2', 'y2', 'x3', 'y3'),
            arg
        ):
            Transform.config.set_property(*q)
        Transform.pdb.run(Transform.config)
