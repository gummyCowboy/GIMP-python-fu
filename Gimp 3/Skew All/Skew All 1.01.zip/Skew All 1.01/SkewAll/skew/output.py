#!/usr/bin/env python3
from skew.constant import NORMAL
from skew.pdb import Autocrop, Copy, Paste, Transform
import gi                              # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp         # noqa

"""Include skew output class."""


def add_layer(j, parent=None, position=0, layer_name="Base"):
    """
    Add a layer to an image.

    j: Gimp.Image
        Receive layer.

    parent: Image.GroupLayer or None
        Put layer in a group.

    position: int
        Is the offset from the top of the parent.

    layer_name: string
        Give the layer a name.

    Return: layer
        newly created
    """
    z = Gimp.Layer.new(
        j,
        layer_name,
        j.get_width(),
        j.get_height(),
        Gimp.ImageType.RGBA_IMAGE,
        100,
        Gimp.LayerMode.NORMAL
    )

    j.insert_layer(z, parent, position)
    return z


def get_layer_from_group(z, q):
    """
    Gather layer from a 'Gimp.GroupLayer'.

    z: Gimp.GroupLayer
    q: list
        [Gimp.Layer, ...]
    """
    for z1 in z.get_children():
        if Gimp.Item.id_is_group_layer(z1.get_id()):
            get_layer_from_group(z1, q)
        else:
            q.append(z1)


def get_layer_from_image(j, q):
    """
    Gather layer from a 'Gimp.Image'.

    j: Gimp.Image
    q: list
        [Gimp.Layer, ...]
    """
    for z in j.get_layers():
        if Gimp.Item.id_is_group_layer(z.get_id()):
            get_layer_from_group(z, q)
        else:
            q.append(z)


def hide_group_layer(z, q):
    """
    Hide grouped layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    q: list
        [hidden Gimp.Layer, ...]
    """
    for z1 in z.get_children():
        if Gimp.Item.id_is_group_layer(z1.get_id()):
            # recursive:
            hide_group_layer(z1, q)
        else:
            if z1.get_visible():
                z1.set_visible(False)
                q.append(z1)


def hide_image_layer(j, q):
    """
    Hide all layer in an image.

    j: Gimp.Image
    q: list
        [hidden Gimp.Layer, ...]
    """
    for z in j.get_layers():
        if Gimp.Item.id_is_group_layer(z.get_id()):
            # recursive:
            hide_group_layer(z, q)
        else:
            if z.get_visible():
                z.set_visible(False)
                q.append(z)


def show_image_layer(q):
    """
    Show layer given a list of layer.

    q: list
        [Gimp.Layer, ...]
    """
    for z in q:
        z.set_visible(True)


class Output:
    """
    Create a new image with the same size as the input image. Copy and
    transform the copied layer using two skew points.

    There are four total skew points. DialogMain's Topleft and Bottom-Left
    points have calculated layer-centric symmetrical points.

    The four points define a skew polygon which is passed to a Gimp transform
    function with each copied layer producing output image layer.
    """

    def __init__(self, image):
        """
        image: Gimp.Image
            Each layer in the image is copied, transformed,
            and stacked in an output image.
        """
        self._input_image = image

        # Output
        self._display = \
            self._base_layer = \
            self._top_right_x = \
            self._top_right_y = \
            self._output_image = \
            self._input_layers = \
            self._bottom_right_x = \
            self._bottom_right_y = None

        # DialogMain
        self._is_show = \
            self._topleft_x = \
            self._topleft_y = \
            self._bottom_left_x = \
            self._bottom_left_y = None

    def _calc_symmetrical_point(self):
        """
        A symmetrical point's value is the inverse value of a point
        provided by DialogMain.
        """
        self._bottom_right_x = -self._topleft_x
        self._bottom_right_y = -self._topleft_y
        self._top_right_x = -self._bottom_left_x
        self._top_right_y = -self._bottom_left_y

    def _create_image(self):
        """Create a Skew All output image."""
        if self._output_image:
            # Remove the previous image.
            self._display.delete()
            self._display = self._base_layer = self._output_image = None

        if not self._output_image:
            self._output_image = Gimp.Image.new(
                self._input_image.get_width(),
                self._input_image.get_height(),
                Gimp.ImageBaseType.RGB
            )
            self._base_layer = add_layer(self._output_image)

        # Create a view.
        self._display = Gimp.Display.new(self._output_image)

    def _get_input_layers(self):
        """
        Recursively peruse an image adding each layer found to a list.
        """
        self._input_layers = []
        get_layer_from_image(self._input_image, self._input_layers)
        if self._is_show:
            self._input_layers = self._input_layers[:1]

    def _transform_layer(self):
        for z in reversed(self._input_layers):
            # Only 'z' is visible.
            z.set_visible(True)

            mode = z.get_mode()
            opacity = z.get_opacity()

            z.set_mode(NORMAL)
            z.set_opacity(100.)

            Copy.do((('image', self._input_image),))
            z.set_mode(mode)
            z.set_opacity(opacity)

            z1 = Paste.do(self._output_image)

            w, h = z1.get_width(), z1.get_height()
            offset_x, offset_y = z1.get_offsets()[1:]
            center_x = (w + offset_x) / 2
            center_y = (h + offset_y) / 2

            Transform.do(
                *(
                    z1,
                    round(self._topleft_x * w + center_x),
                    round(self._topleft_y * h + center_y),
                    round(self._top_right_x * w + center_x),
                    round(self._top_right_y * h + center_y),
                    round(self._bottom_left_x * w + center_x),
                    round(self._bottom_left_y * h + center_y),
                    round(self._bottom_right_x * w + center_x),
                    round(self._bottom_right_y * h + center_y)
                )
            )
            z.set_visible(False)
            z1.set_name(z.get_name())
            z1.set_mode(mode)
            z1.set_opacity(opacity)

        self._output_image.remove_layer(self._base_layer)
        Autocrop.do(self._output_image)
        self._base_layer = None

    def create(self, d, is_show):
        """
        Create an output image. Transform input image layer.

        d: dict
            'AnyGroup.value_d'

        is_show: bool
            If it is True, then the output is limited to one layer.
        """
        for k, a in d.items():
            # Widget value, 'a'
            setattr(self, "_" + k, a)

        self._is_show = is_show
        hidden_layers = []

        self._calc_symmetrical_point()
        self._create_image()
        self._get_input_layers()
        hide_image_layer(self._input_image, hidden_layers)
        self._transform_layer()
        show_image_layer(hidden_layers)
        Gimp.displays_flush()
