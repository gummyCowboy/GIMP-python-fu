#!/usr/bin/env python3
from copy import deepcopy
from skew.constant import (
    CTRL_P, DIALOG_MAIN_SIGNAL,
    PREVIEW, PREVIEW_TYPE, REPLACE, TITLE,
    SHOW_SKEW, SHOW_SKEW_TYPE
)
from skew.define_main import DEFINE_MAIN
from skew.output import Output
from plugout.any_group import AnyGroup
from plugout.constant import (
    ACCEPT, ANY_CHANGE, CANCEL,
    CANCEL_TYPE, DELETE_TYPE, OK_TYPE
)
from plugout.container.content_area import ContentArea
from plugout.dialog.dialog import Dialog
import gi                                             # type: ignore
gi.require_version('Gdk', '3.0')
gi.require_version('Gimp', '3.0')
from gi.repository import Gdk, Gimp, GObject          # noqa

"""Define a dialog class and support function for renaming layer."""


class DialogMain(GObject.GObject, Dialog):
    """
    Create a 'GimpUI.Dialog' for user interaction and define output settings.
    """
    __gsignals__ = DIALOG_MAIN_SIGNAL

    def __init__(self, image):
        """
        Open a dialog. Respond to user interaction.

        image: Gimp.Image
            WIP
        """
        def _on_accept():
            self.dialog.destroy()

            self.dialog = None
            self.on_preview(None)

        def _on_cancel():
            self.dialog.destroy()
            self.dialog = None

        def _on_preview():
            self.on_preview(False)

        def _on_show_skew():
            self.on_show_skew()

        GObject.GObject.__init__(self)

        # Is a 'AnyGroup.value_d' copy made on Preview action.
        # {Widget key: Widget value}
        self._preview_d = {}

        self._skew_button = self._preview_button = None
        self._image = image
        self._output = Output(image)
        response_d = {
            CANCEL_TYPE: _on_cancel,
            DELETE_TYPE: _on_cancel,
            OK_TYPE: _on_accept,
            PREVIEW_TYPE: _on_preview,
            SHOW_SKEW_TYPE: _on_show_skew
        }

        self.connect(ANY_CHANGE, self.on_any_change)
        Dialog.__init__(
            self,
            TITLE,
            (
                (CANCEL, CANCEL_TYPE),
                (SHOW_SKEW, SHOW_SKEW_TYPE),
                (PREVIEW, PREVIEW_TYPE),
                (ACCEPT, OK_TYPE)
            ),
            self.add_widget,
            response_d
        )

    def add_widget(self, content_area):
        """
        Add Widget to the Dialog's content area.

        content_area: Gtk.Box
            There's room to grow.
        """
        self._preview_button = self.dialog.get_widget_for_response(
            PREVIEW_TYPE
        )
        self._skew_button = self.dialog.get_widget_for_response(SHOW_SKEW_TYPE)

        self._preview_button.set_tooltip_text(CTRL_P)
        self.dialog.connect('key-press-event', self.on_key_press)

        container = ContentArea(content_area)
        self._any_group = AnyGroup(
            DEFINE_MAIN, container, is_any_change=True, host=self
        )
        content_area.show_all()

    def on_any_change(self, *_):
        """Enable the Preview button on any Widget change."""
        if self._preview_button:
            self._preview_button.set_sensitive(1)
            self._skew_button.set_sensitive(1)

    def on_key_press(self, _, event_key):
        """
        Scan for a Control-P keypress. If found, emit a preview signal.

        _ Gtk.Dialog
            not used

        event_key: Gdk.EventKey
        """
        is_control = (event_key.state & Gdk.ModifierType.CONTROL_MASK)
        if is_control and event_key.keyval == Gdk.KEY_p:
            self._preview_button.emit('clicked')

    def on_preview(self, is_show):
        """
        Respond to a Preview button action by performing a preview
        but only if things have changed since the last preview.

        is_show: bool
            If True, then the user clicked on the Preview button.
        """
        j = self._image
        d = self._any_group.value_d
        g = self._preview_button
        g1 = self._skew_button
        g2 = g1 if is_show else g

        if self.dialog:
            if not g.get_style_context().has_class('pressed'):
                g2.get_style_context().add_class('pressed')

        if d != self._preview_d:
            self._preview_d = deepcopy(d)
            channel = None

            if not Gimp.Selection.is_empty(j):
                selection = j.get_selection()
                channel = selection.save(j)
                Gimp.Selection.none(j)

            self._output.create(d, is_show)
            if channel:
                j.select_item(REPLACE, channel)
                j.remove_channel(channel)

        # If the dialog is dead, then skip.
        if self.dialog:
            g2.get_style_context().remove_class('pressed')

            if not is_show:
                g.set_sensitive(0)
            g1.set_sensitive(0)

    def on_show_skew(self):
        """
        Respond to an Undo button action. Rename layer to the last undo state.
        """
        self.on_preview(True)
        self._preview_d = {}
