#!/usr/bin/env python3
from plugout.constant import ENTRY_SAVE_CHANGE, KEY_PRESS_EVENT
from plugout.define.key import VALUE
from plugout.preset import Preset
from plugout.widget.emit import WidgetValue
import gi                                  # type: ignore
gi.require_version('Gdk', '3.0')
gi.require_version('Gtk', '3.0')
from gi.repository import Gdk, Gtk         # noqa

"""
Include 'Gtk.Entry' wrapper class.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/Entry.html'
"""


class Entry(WidgetValue):
    """Custom 'Gtk.Entry' with a wrapper."""
    change_signal = 'changed'

    def __init__(self, def_d):
        """
        def_d: dict
            Entry definition
                value: string
                Initialize the value of the Widget.
                Define the default value for the Widget in its preset.
        """
        g = Gtk.Entry.new()

        g.connect(KEY_PRESS_EVENT, self.on_key_press)
        super().__init__(def_d, g)
        self.value_d[self.key] = def_d.get(VALUE, "")

    def get_a(self):
        """
        Fetch the value of the 'Gtk.Entry'.

        Return: string
        """
        return self.widget.get_text()

    def set_a(self, n):
        """
        Set the value of the 'Gtk.Entry'.

        n: string
            Receive value.
        """
        if not isinstance(n, str):
            n = str(n)
        self.widget.set_text(n)


class EntrySave(Entry):
    """
    Customize Entry with a 'path_reflect_label' updater.
    The dialog-host is a GObject with custom signal.
    """

    def __init__(self, def_d):
        """
        def_d: dict
            EntrySave definition
        """
        super().__init__(def_d)

        self.widget.connect('changed', self.on_save_entry_change)
        self.widget.connect('realize', self.on_save_entry_change)
        self.widget.connect('key-press-event', self.on_save_entry_key_press)

    def on_save_entry_change(self, entry):
        """
        Update the path reflect label on the preset's name Entry change.

        entry: Gtk.Entry
            Has text to append to the preset path.
        """
        self.host.emit(
            ENTRY_SAVE_CHANGE, f'{Preset.active_path}{self.get_a()}.json'
        )

    def on_save_entry_key_press(self, entry, event_key):
        """
        Save the preset if the user presses the return key.

        entry: Gtk.Entry
            Is responsible for event.

        event_key: Gdk.EventKey
        """
        if Gdk.keyval_name(event_key.keyval) == 'Return':
            if len(entry.get_text()):
                self.host.dialog.emit('response', Gtk.ResponseType.OK)
