#!/usr/bin/env python3
from plugout.any_group import AnyGroup
from plugout.constant import (
    ACCEPT, CANCEL, CANCEL_TYPE,
    CONFIRM_OVERWRITE, DELETE_TYPE, DIALOG_SAVE_SIGNAL,
    EXISTING_FILE, OK_TYPE, PRESET_SAVED,
    SAVE_FAIL, SAVE_PRESET
)
from plugout.container.content_area import ContentArea
from plugout.dialog.dialog import Dialog
from plugout.define.preset_save import DEF_SAVE
from plugout.preset import Preset
import gi                                        # type: ignore
import json
import os
gi.require_version('Gimp', '3.0')
gi.require_version('Gtk', '3.0')
from gi.repository import Gimp, GObject, Gtk     # noqa

"""Include class and function used when loading or deleting a preset."""


def check_duplicate_file(path):
    """
    Check if a file already exists. If it does
    ask the user if it's okay to over-write the file.

    path: string
        file path

    Return: bool
        Is True if the user is okay with writing the file.
    """
    is_success = True

    if os.path.isfile(path):
        dialog = Gtk.MessageDialog(
            type=Gtk.MessageType.QUESTION,
            text=EXISTING_FILE,
            secondary_text=CONFIRM_OVERWRITE.format(path)
        )

        dialog.add_button(CANCEL, CANCEL_TYPE)
        dialog.add_button(ACCEPT, OK_TYPE)

        response = dialog.run()
        is_success = True if response == OK_TYPE else False
        dialog.destroy()
    return is_success


def ensure_preset_dir(n):
    """
    Ensure a directory exists. Use to make
    a "Preset" folder and any sub-folder.

    n: string
        preset path

    Return bool.
        If True, then the Preset directory exists.
    """
    is_success = True

    if n and not os.path.isdir(os.path.dirname(n)):
        try:
            os.makedirs(os.path.dirname(n))
        except Exception:
            is_success = False
            Gimp.message(SAVE_FAIL)
    return is_success


class DialogPresetSave(GObject.GObject, Dialog):
    """Create a Dialog for saving a preset."""
    __gsignals__ = DIALOG_SAVE_SIGNAL

    def __init__(self, save_button, key_path, value_d):
        """
        Open a dialog. Respond to user interaction.

        save_button: ButtonSave
            Set IO name.

        key_path: list
            [preset key, ...]
            Find nested preset.

        value_d: dict
            {Widget key: Widget value}
            preset
        """
        def _on_accept():
            if self.on_accept():
                self.dialog.destroy()
                self.dialog = None

        def _on_cancel():
            self.dialog.destroy()
            self.dialog = None

        GObject.GObject.__init__(self)

        self.key_path = key_path
        self.value_d = value_d
        title = SAVE_PRESET
        self._preset_name = None
        Preset.active_path = Preset.path
        self._save_button = save_button

        # {dialog button response type: response type handler}
        response_d = {
            CANCEL_TYPE: _on_cancel,
            DELETE_TYPE: _on_cancel,
            OK_TYPE: _on_accept
        }

        if key_path:
            self._preset_name = key_path[-1]
            title = f"{title}: {self._preset_name}"
            n = os.path.sep
            Preset.active_path = f'{Preset.path}{self._preset_name}{n}'

        Dialog.__init__(
            self,
            title,
            ((CANCEL, CANCEL_TYPE), (ACCEPT, OK_TYPE)),
            self.add_widget,
            response_d
        )

    def add_widget(self, content_area):
        """
        Add Widget to the Dialog's content area.

        content_area: Gtk.Box
            There's room to grow.
        """
        container = ContentArea(content_area)
        self._any_group = AnyGroup(
            DEF_SAVE, container, preset_key=self._preset_name, host=self
        )
        g = self._any_group.widget_d['name_entry']

        g.set_a(self._save_button.get_io_name())
        content_area.show_all()

    def on_accept(self):
        """Respond to an Accept button action. Save a preset."""
        return self.save_preset_data()

    def save_preset_data(self):
        """
        Try to save the current preset.

        Return: bool
            Is True if the preset is saved to file.
        """
        path = ''
        is_success = ensure_preset_dir(Preset.active_path)

        if is_success:
            n = self._any_group.value_d['name_entry']
            path = f'{Preset.active_path}{n}.json'
            is_success = check_duplicate_file(path)

        if is_success:
            try:
                with open(path, 'w') as a_file:
                    json.dump(self.value_d, a_file)

                Gimp.message(PRESET_SAVED)
                self._save_button.set_io_name(n)
            except Exception:
                Gimp.message(SAVE_FAIL)
                is_success = False
        return is_success
