#!/usr/bin/env python3
import gi                               # type: ignore
gi.require_version('Gdk', '3.0')
gi.require_version('GimpUi', '3.0')
from gi.repository import GimpUi, Gtk   # noqa

"""Define 'GimpUi.Dialog' wrapper class."""


class Dialog:
    """
    Create a 'GimpUI.Dialog' with custom button.
    Is a super-class for custom Dialog having an
    AnyGroup interface.
    """

    def __init__(self, title, button_type, add_widget, response_d):
        """
        title: string
            Give the 'GimpUi.Dialog' a display title.

        button_type: tuple
            (
                (button display name, button response type), ...
            )
            Add button to the Dialog while giving the button a name,
            and a response type.

        add_widget: function
            Add Widget to the Dialog's content area.

        response_d: dict
            {response type: function, ...}
            React to button action. The function has no arguments:
                function()
        """
        self._any_group = None
        self.dialog = GimpUi.Dialog(
            use_header_bar=Gtk.Settings.get_default().get_property(
                "gtk-dialogs-use-header"
            ),
            title=title
        )

        # (button label-string, button type-int), 'q'
        for q in button_type:
            self.dialog.add_button(*q)

        self.dialog.set_modal(True)
        add_widget(self.dialog.get_content_area())
        self.dialog.show()

        # Start event loop.
        while self.dialog:
            response = self.dialog.run()

            try:
                p = response_d.get(response)

                if p is None:
                    self.dialog.destroy()
                    self.dialog = None
                else:
                    p()
            except Exception as ex:
                # Prevent lockup.
                if self.dialog:
                    self.dialog.destroy()
                    self.dialog = None
                raise Exception(ex)
