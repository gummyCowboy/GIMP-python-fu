#!/usr/bin/env python3
from copy import deepcopy
from plugout.constant import MANAGE, SAVE_, RANDOM
from plugout.container.box import HBox
from plugout.container.grid import Grid, GridCell, GridRow
from plugout.define.key import (
    ADJUSTMENT, CHILD, COLUMN, COLUMNS, DIGITS, HALIGN, LIMIT,
    PADDING, PRESET, RANDOMER, TEXT, TOOLTIP, TYPE, VALUE, WIDTH
)
from plugout.widget.button import ButtonRandom
from plugout.widget.button_preset import ButtonManage, ButtonSave
from plugout.widget.h_sep import HSeparator
from plugout.widget.label import Label, LabelPreset
from plugout.widget.spinbutton import SpinButton
from skew.constant import (
    BOTTOM_LEFT_X, BOTTOM_LEFT_Y,
    RELATIVE_POSITION_HEIGHT, RELATIVE_POSITION_WIDTH,
    TOPLEFT_X, TOPLEFT_Y
)
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa

"""Define the DialogMain's content using AnyGroup definition dict."""

SPINBUTTON_DEF_D = {
    ADJUSTMENT: (-.5, -.5, .5, .01, .1, .0),
    DIGITS: 4,
    LIMIT: (-.5, .5),
    TYPE: SpinButton,
    VALUE: -.5,
}

# Bottom-Left X________________________________________________________________
BOTTOM_LEFT_X_LABEL = {
    HALIGN: Gtk.Align.START, TEXT: BOTTOM_LEFT_X, TYPE: Label
}
BOTTOM_LEFT_X_SPINBUTTON = deepcopy(SPINBUTTON_DEF_D)
GRID_CELL_BOTTOM_LEFT_X_0 = {
    CHILD: {'bottom_left_x_label': BOTTOM_LEFT_X_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_BOTTOM_LEFT_X_1 = {
    CHILD: {'bottom_left_x': BOTTOM_LEFT_X_SPINBUTTON},
    COLUMN: 1,
    TYPE: GridCell
}
BOTTOM_LEFT_X_SPINBUTTON.update({TOOLTIP: RELATIVE_POSITION_WIDTH})

# Bottom-Left Y________________________________________________________________
BOTTOM_LEFT_Y_LABEL = {
    HALIGN: Gtk.Align.START, TEXT: BOTTOM_LEFT_Y, TYPE: Label
}
BOTTOM_LEFT_Y_SPINBUTTON = deepcopy(SPINBUTTON_DEF_D)
GRID_CELL_BOTTOM_LEFT_Y_0 = {
    CHILD: {'bottom_left_y_label': BOTTOM_LEFT_Y_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_BOTTOM_LEFT_Y_1 = {
    CHILD: {'bottom_left_y': BOTTOM_LEFT_Y_SPINBUTTON},
    COLUMN: 1,
    TYPE: GridCell
}

BOTTOM_LEFT_Y_SPINBUTTON.update({
    VALUE: .5, TOOLTIP: RELATIVE_POSITION_HEIGHT
})

# Preset_______________________________________________________________________
PRESET_LABEL = {HALIGN: Gtk.Align.START, TYPE: LabelPreset}
MANAGE_BUTTON = {TEXT: MANAGE, TYPE: ButtonManage}
SAVE_BUTTON = {PADDING: (0, 0, 0, 4), TEXT: SAVE_, TYPE: ButtonSave}
HBOX_PRESET_BUTTON = {
    CHILD: {'save_button': SAVE_BUTTON, 'manage_button': MANAGE_BUTTON},
    TYPE: HBox
}
GRID_CELL_PRESET_0 = {
    CHILD: {'preset_label': PRESET_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_PRESET_1 = {
    CHILD: {1: HBOX_PRESET_BUTTON},
    COLUMN: 1,
    WIDTH: 2,
    TYPE: GridCell
}
GRID_ROW_PRESET = {
    CHILD: {1: GRID_CELL_PRESET_0, 2: GRID_CELL_PRESET_1},
    COLUMNS: 2,
    TYPE: GridRow
}

# Random Row___________________________________________________________________
BUTTON_RANDOM = {TEXT: RANDOM, TYPE: ButtonRandom}
GRID_CELL_RANDOM_1 = {
    CHILD: {'random': BUTTON_RANDOM}, COLUMN: 1, TYPE: GridCell
}
GRID_ROW_RANDOM = {
    CHILD: {1: GRID_CELL_RANDOM_1}, COLUMNS: 2, TYPE: GridRow
}

# Separator____________________________________________________________________
HSEPARATOR = {PADDING: (4, 4, 0, 0), TYPE: HSeparator}
GRID_CELL_HSEPARATOR = {
    CHILD: {'separator': HSEPARATOR}, COLUMN: 0, WIDTH: 2, TYPE: GridCell
}
GRID_ROW_SEPARATOR = {
    CHILD: {1: GRID_CELL_HSEPARATOR}, COLUMNS: 2, TYPE: GridRow
}

# Topleft X____________________________________________________________________
TOPLEFT_X_LABEL = {HALIGN: Gtk.Align.START, TEXT: TOPLEFT_X, TYPE: Label}
TOPLEFT_X_SPINBUTTON = deepcopy(SPINBUTTON_DEF_D)
GRID_CELL_TOPLEFT_X_0 = {
    CHILD: {'topleft_x_label': TOPLEFT_X_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_TOPLEFT_X_1 = {
    CHILD: {'topleft_x': TOPLEFT_X_SPINBUTTON},
    COLUMN: 1,
    TYPE: GridCell
}

TOPLEFT_X_SPINBUTTON.update({TOOLTIP: RELATIVE_POSITION_WIDTH, VALUE: -.2})

# Topleft Y____________________________________________________________________
TOPLEFT_Y_LABEL = {HALIGN: Gtk.Align.START, TEXT: TOPLEFT_Y, TYPE: Label}
TOPLEFT_Y_SPINBUTTON = deepcopy(SPINBUTTON_DEF_D)
GRID_CELL_TOPLEFT_Y_0 = {
    CHILD: {'topleft_y_label': TOPLEFT_Y_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_TOPLEFT_Y_1 = {
    CHILD: {'topleft_y': TOPLEFT_Y_SPINBUTTON}, COLUMN: 1, TYPE: GridCell
}
TOPLEFT_Y_SPINBUTTON.update({TOOLTIP: RELATIVE_POSITION_HEIGHT})

# Main_________________________________________________________________________
# AnyGroup definition: {key: definition}
DEFINE_MAIN = {
    1: {
        CHILD: {
            'topleft-x': {
                CHILD: {1: GRID_CELL_TOPLEFT_X_0, 2: GRID_CELL_TOPLEFT_X_1},
                COLUMNS: 2,
                TYPE: GridRow
            },
            'topleft-y': {
                CHILD: {1: GRID_CELL_TOPLEFT_Y_0, 2: GRID_CELL_TOPLEFT_Y_1},
                COLUMNS: 2,
                TYPE: GridRow
            },
            'bottom-left-x': {
                CHILD: {
                    1: GRID_CELL_BOTTOM_LEFT_X_0, 2: GRID_CELL_BOTTOM_LEFT_X_1
                },
                COLUMNS: 2,
                TYPE: GridRow
            },
            'bottom-left-y': {
                CHILD: {
                    1: GRID_CELL_BOTTOM_LEFT_Y_0, 2: GRID_CELL_BOTTOM_LEFT_Y_1
                },
                COLUMNS: 2,
                TYPE: GridRow
            },
            'random': GRID_ROW_RANDOM,
            'sep': GRID_ROW_SEPARATOR,
            'preset': GRID_ROW_PRESET
        },

        # Start a preset, but don't give it a key since there are no
        # sub-preset. If there were sub-preset, then a key would
        # give this preset a Preset sub-folder: '.../Preset/key/'.
        PRESET: None,
        RANDOMER: True,
        TYPE: Grid
    }
}
