#!/usr/bin/env python3
from plugout.constant import ANY_CHANGE
import gi                                          # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GLib, GObject      # noqa


def _(n):
    """
    Translate English to local language.

    n: string
        Translate.

    Return: string
        translated
    """
    return GLib.dgettext(None, n)


PROCEDURE_NAME = 'plug-in-skew-all'
TITLE = "Skew All v1"

# custom button response type
PREVIEW_TYPE = -99
SHOW_SKEW_TYPE = -98

REPLACE = Gimp.ChannelOps.REPLACE

# Translate____________________________________________________________________
BOTTOM_LEFT_X = _("Bottom-Left X")
BOTTOM_LEFT_Y = _("Bottom-Left Y")
CTRL_P = _("Ctrl-P")
PLUGIN_BLURB = _(
    "Create a new image where with skewed layers copied from the active image."
)
PLUGIN_TOOLTIP = _("Create a new image where with skewed layers.")
PREVIEW = _("Preview")
RELATIVE_POSITION_WIDTH = _(
    " Factor the layer's width and add that \n"
    " value to the layer's center X point. "
)
RELATIVE_POSITION_HEIGHT = _(
    " Factor the layer's height and add that \n"
    " value to the layer's center Y point. "
)
TOPLEFT_X = _("Topleft X")
TOPLEFT_Y = _("Topleft Y")
SHOW_SKEW = _("Show Skew")

# custom Signal________________________________________________________________
TOPLEFT_X_CHANGE = 'topleft-x-change'
TOPLEFT_Y_CHANGE = 'topleft-y-change'
BOTTOM_LEFT_X_CHANGE = 'bottom-left-x-change'
BOTTOM_LEFT_Y_CHANGE = 'bottom-left-y-change'

# run first argument
# (emission stage, type of signal, argument type)
SIGNAL_ARG = GObject.SIGNAL_RUN_FIRST, None, (GObject.TYPE_PYOBJECT,)

DIALOG_MAIN_SIGNAL = {}

for k in (
    ANY_CHANGE, BOTTOM_LEFT_X_CHANGE, BOTTOM_LEFT_Y_CHANGE,
    TOPLEFT_X_CHANGE, TOPLEFT_Y_CHANGE
):
    DIALOG_MAIN_SIGNAL[k] = SIGNAL_ARG
