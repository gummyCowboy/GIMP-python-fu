#!/usr/bin/env python3
import gi                              # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp         # noqa

"""Include skew output class."""


def add_layer(j, parent=None, position=0, layer_name="Base"):
    """
    Add a layer to an image.

    j: Gimp.Image
        Receive layer.

    parent: Image.GroupLayer or None
        Put layer in a group.

    position: int
        Is the offset from the top of the parent.

    layer_name: string
        Give the layer a name.

    Return: layer
        newly created
    """
    z = Gimp.Layer.new(
        j,
        layer_name,
        j.get_width(),
        j.get_height(),
        Gimp.ImageType.RGBA_IMAGE,
        100,
        Gimp.LayerMode.NORMAL
    )

    j.insert_layer(z, parent, position)
    return z


def get_layer_from_group(z, q):
    """
    Gather layer from a 'Gimp.GroupLayer'.

    z: Gimp.GroupLayer
    q: list
        [Gimp.Layer, ...]
    """
    for z1 in z.get_children():
        if Gimp.Item.id_is_group_layer(z1.get_id()):
            get_layer_from_group(z1, q)
        else:
            q.append(z1)


def get_layer_from_image(j, q):
    """
    Gather layer from a 'Gimp.Image'.

    j: Gimp.Image
    q: list
        [Gimp.Layer, ...]
    """
    for z in j.get_layers():
        if Gimp.Item.id_is_group_layer(z.get_id()):
            get_layer_from_group(z, q)
        else:
            q.append(z)


def hide_group_layer(z, q):
    """
    Hide grouped layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    q: list
        [hidden Gimp.Layer, ...]
    """
    for z1 in z.get_children():
        if Gimp.Item.id_is_group_layer(z1.get_id()):
            # recursive:
            hide_group_layer(z1, q)
        else:
            if z1.get_visible():
                z1.set_visible(False)
                q.append(z1)


def hide_image_layer(j, q):
    """
    Hide all layer in an image.

    j: Gimp.Image
    q: list
        [hidden Gimp.Layer, ...]
    """
    for z in j.get_layers():
        if Gimp.Item.id_is_group_layer(z.get_id()):
            # recursive:
            hide_group_layer(z, q)
        else:
            if z.get_visible():
                z.set_visible(False)
                q.append(z)


def show_image_layer(q):
    """
    Show layer given a list of layer.

    q: list
        [Gimp.Layer, ...]
    """
    for z in q:
        z.set_visible(True)


class Output:
    """
    Create a new image with the same size as the input image. Copy and
    transform the copied layer using two skew points.

    There are four total skew points. DialogMain's Topleft and Bottom-Left
    points have calculated layer-centric symmetrical points.

    The four points define a skew polygon which is passed to a Gimp transform
    function with each copied layer producing output image layer.
    """

    def __init__(self, image):
        """
        image: Gimp.Image
            Each layer in the image is copied, transformed,
            and stacked in an output image.
        """
        self._input_image = image

        # Output
        self._display = \
            self._base_layer = \
            self._top_right_x = \
            self._top_right_y = \
            self._output_image = \
            self._input_layers = \
            self._bottom_right_x = \
            self._bottom_right_y = None

        # DialogMain
        self._is_show = \
            self._topleft_x = \
            self._topleft_y = \
            self._bottom_left_x = \
            self._bottom_left_y = None

    def _calc_symmetrical_point(self):
        """
        A symmetrical point's value is the inverse value of a point
        provided by DialogMain.
        """
        self._bottom_right_x = -self._topleft_x
        self._bottom_right_y = -self._topleft_y
        self._top_right_x = -self._bottom_left_x
        self._top_right_y = -self._bottom_left_y

    def _create_image(self):
        """Begin creating a new Flower of Life image."""
        if self._output_image:
            # Remove the previous image.
            self._display.delete()
            self._display = self._base_layer = self._output_image = None

        if not self._output_image:
            self._output_image = Gimp.Image.new(
                self._input_image.get_width(),
                self._input_image.get_height(),
                Gimp.ImageBaseType.RGB
            )
            self._base_layer = add_layer(self._output_image)

        # Create a view.
        self._display = Gimp.Display.new(self._output_image)

    def _get_input_layers(self):
        """
        Recursively peruse an image adding each layer found to a list.
        """
        self._input_layers = []
        get_layer_from_image(self._input_image, self._input_layers)
        if self._is_show:
            self._input_layers = self._input_layers[:1]

    def _transform_layer(self):
        procedure = Gimp.get_pdb().lookup_procedure(
            'gimp-item-transform-perspective'
        )
        config = procedure.create_config()
        for i, z in enumerate(reversed(self._input_layers)):
            # Only 'z' is visible.
            z.set_visible(True)

            Copy.do(self._input_image)

            z1 = Paste.do(self._output_image)

            w, h = z1.get_width(), z1.get_height()
            offset_x, offset_y = z1.get_offsets()[1:]
            center_x = (w + offset_x) / 2
            center_y = (h + offset_y) / 2
            x0 = round(self._topleft_x * w + center_x)
            y0 = round(self._topleft_y * h + center_y)
            x1 = round(self._top_right_x * w + center_x)
            y1 = round(self._top_right_y * h + center_y)
            x2 = round(self._bottom_left_x * w + center_x)
            y2 = round(self._bottom_left_y * h + center_y)
            x3 = round(self._bottom_right_x * w + center_x)
            y3 = round(self._bottom_right_y * h + center_y)

            for q in (
                ('item', z1),
                ('x0', x0), ('y0', y0),
                ('x1', x1), ('y1', y1),
                ('x2', x2), ('y2', y2),
                ('x3', x3), ('y3', y3)

            ):
                config.set_property(*q)

            # The result is: (success, layer)
            procedure.run(config)

            z.set_visible(False)
            z1.set_name(z.get_name())

            if i == 0:
                self._output_image.remove_layer(self._base_layer)
                self._base_layer = None

    def create(self, d, is_show):
        """
        Create an output image. Transform input image layer.

        d: dict
            'AnyGroup.value_d'

        is_show: bool
            If it is True, then the output is limited to one layer.
        """
        for k, a in d.items():
            # Widget value, 'a'
            setattr(self, "_" + k, a)

        self._is_show = is_show
        hidden_layers = []

        self._calc_symmetrical_point()
        self._create_image()
        self._get_input_layers()
        hide_image_layer(self._input_image, hidden_layers)
        self._transform_layer()
        show_image_layer(hidden_layers)
        Gimp.displays_flush()


class Copy:
    config = pdb = None

    def do(j):
        """
        Copy an image's visible projection into the Gimp internal buffer.

        j: Gimp.Image
            Copy its visible content.

        Return: Gimp paste buffer
        """
        if Copy.pdb is None:
            Copy.pdb = Gimp.get_pdb().lookup_procedure(
                'gimp-edit-copy-visible'
            )
            Copy.config = Copy.pdb.create_config()

        for q in (('image', j),):
            Copy.config.set_property(*q)
        Copy.pdb.run(Copy.config)


class Paste:
    config = pdb = None

    def do(j):
        """
        Paste a layer onto the top of an image.
        The image is assumed to a have at least one layer.

        j: Gimp.Image
            Receive pasted layer.

        Return: Gimp.Layer
            Is on top of the image.
        """
        z = j.get_layers()[0]

        if Paste.pdb is None:
            Paste.pdb = Gimp.get_pdb().lookup_procedure(
                'gimp-edit-paste'
            )
            Paste.config = Paste.pdb.create_config()

        for q in (('drawable', z), ('paste-into', True)):
            Paste.config.set_property(*q)

        # 'gobject.GBoxed' throws an error in RC1 on
        # print, so the result is useless here.
        Paste.pdb.run(Paste.config)

        z = j.get_layers()[0]

        Gimp.floating_sel_to_layer(z)
        return z
