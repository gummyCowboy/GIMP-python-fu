#!/usr/bin/env python3


"""Define item key for AnyGroup definition dict."""

# tuple; Initialize a SpinButton's Adjustment.
# (init value, lower limit, upper limit, step inc, page inc, page size)
# of float
ADJUSTMENT = 'adjustment'

# int; Set a margin around a Grid.
BORDER_WIDTH = 'border_width'

# Define Container occupant. Create Container-branch and Widget-leaf.
# CHILD: {key: definition dict}
CHILD = 'child'

# int; Assign a Grid column for a GridCell. GridRow
# will peek at this value with an attribute: 'GridRow.column'.
COLUMN = 'column'

# int; Allocate Grid column for a GridRow.
# Columns are part of a 'Gtk.Grid'. Each column
# in a GridRow can be a GridCell or empty.
COLUMNS = 'columns'

# int; Set margin space around Grid column. Is for GridRow.
COLUMN_SPACING = 'column_space'

# string; Have Widget connect with the AnyGroup host
# to have a 'on_custom_signal' function receive this signal.
CUSTOM_SIGNAL = 'custom_signal'

# int; Set the precision of a SpinButton.
# an integer SpinButton: {DIGITS: 0}
# a float SpinButton: {DIGITS: 1+}
DIGITS = 'digits'

# string; Have the host emit this signal on Widget value change.
EMIT_SIGNAL = 'emit_signal'

# function; Retrieve a list for loading ComboBoxText's pop-out.
GET_LIST = 'get_list'

# Set the justification of a 'Gtk.Widget'.
HALIGN = 'halign'

# bool; Make a 'Gtk.Box' divvy space equally.
HOMOGENEOUS = 'homogeneous'

# GObject or None; AnyGroup host signal owner
# Set during AnyGroup init by the host.
HOST = 'host'

# bool; Is True if the host wishes to receive 'any-change' signal.
# Is set by the AnyGroup's host during AnyGroup's init.
IS_ANY_CHANGE = 'is_any_change'

# value; Is a WidgetValue's key. It has a room at the
# value dict and widget dict.
# {Widget key: ...}
# The item is inserted into WidgetValue definition dict
# by AnyGroup during Widget init.
KEY = 'key'

# list; Pass a preset key path to PRESET Widget.
# Write to the Widget's definition dict during init.
KEY_PATH = 'key_path'

# tuple; Limit the range of a randomize response value: {LIMIT: (low, high)}.
# Identify Widget as a randomizer: {LIMIT: True}.
LIMIT = 'limit'

# tuple; Pass markup item to Label.
# Try any: ('i', 'b', 'big', 'small')
MARKUP = 'markup'

# tuple; Give a Widget an alignment. (top, bottom, left, right)
# of int
PADDING = 'padding'

# string; Define a preset within an AnyGroup.
# Insert this item into a Container definition
# to make the Container a preset:
# {PRESET: key}
#
# If the key is None, and the preset files store in the Preset folder.
# Otherwise, preset is stored in 'Preset/key'.
#
# PRESET causes both 'value_d' and 'widget_d' to make a nested preset:
# AnyGroup.value_d[key: {preset branch}]
PRESET = 'preset'

# Container; Generate randomizer signal with this Container.
# {RANDOMER: True}
RANDOMER = 'randomer'

# int; Create a vertical margin around 'Gtk.Grid' row.
ROW_SPACING = 'row_spacing'

# tuple; Create a 'Gtk.ScrolledWindow' container for a Widget.
# The value is (minimum content height, maximum content height).
# If the Widget also defines a 'Gtk.Alignment' with PADDING,
# the ScrolledWindow is added to the Alignment. Otherwise,
# the ScrolledWindow becomes the 'Widget.gtk_addable'.
SCROLLED_WINDOW = 'scrolled_window'

# string; Define a separator for ComboBoxText's pop-out list.
# It should be unique value not found in the list's selectable item.
# Is optional, and the default value is '-'.
SEPARATOR = 'separator'

# class; Pass an additional class during AnyGroup init.
SUB_TYPE = 'sub-type'

# string or tuple; a display value
# Label, CheckButton, and Button define their display value.
# RadioGroup decomposes a tuple into RadioButton descriptor.
TEXT = 'text'

# string; Set a Widget's tooltip.
TOOLTIP = 'tooltip'

# Widget class; Identify the class of a Container or Widget.
TYPE = 'type'

# Set Widget value during its initialization.
# Create a 'AnyGroup.value_d' item, and set the Widget's default value.
VALUE = 'value'

# dict; Is the value dict where WidgetValue own their value.
# May be nested inside another value dict (a sub-preset).
# AnyGroup inserts the item into WidgetValue definition dict
# during AnyGroup's Widget init.
VALUE_D = 'value_d'

# dict; Is the value dict where WidgetValue is part of a preset.
# May be nested inside another Widget dict.
# AnyGroup inserts the item into WidgetValue definition dict
# during AnyGroup's Widget init.
WIDGET_D = 'widget_d'

# int; Allocate Grid column for a GridCell. The default is one.
WIDTH = 'width'
