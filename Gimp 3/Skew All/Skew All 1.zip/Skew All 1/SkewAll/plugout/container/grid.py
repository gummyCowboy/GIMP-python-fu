#!/usr/bin/env python3
from plugout.define.key import (
    BORDER_WIDTH, COLUMN, COLUMN_SPACING,
    COLUMNS, ROW_SPACING, WIDTH
)
from plugout.container.container import Container
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa


class Grid(Container):
    """
    Customize a 'Gtk.Grid' with this wrapper. Is a Container for GridRow.

    Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/Grid.html'
    """

    def __init__(self, def_d):
        """
        def_d: dict
            Grid definition
                border_width: int
                    Create spacing around the 'Gtk.Grid'.

                column_spacing: int
                    Spread columns apart.

                row_spacing: int
                    Spread rows apart.
        """
        g = Gtk.Grid()
        self._row = 0

        super().__init__(def_d, g)
        g.set_border_width(def_d.get(BORDER_WIDTH, 12))
        g.set_column_spacing(def_d.get(COLUMN_SPACING, 12))
        g.set_row_spacing(def_d.get(ROW_SPACING, 2))

    def add(self, grid_attach):
        """
        Add GridCell Widget to a 'Gtk.Grid'. Insert the
        entire GridAttach's set of GridCell/Widget.

        g: GridAttach
            Add GridCell to the table.
        """
        grid_attach.add_to_grid(self.widget, self._row)
        self._row += 1


class GridRow(Container):
    """
    Create a row of GridCell to attach to a Grid.

    GridRow attribute
        columns: int
            Is the number of the GridCell assigned to the GridRow.
            A column can be empty, with no GridCell, but not skipped
            in the columns count.
    """

    def __init__(self, def_d):
        """
        def_d: dict
            GridRow definition
                columns: int
                    Set how many columns the GridRow spans.
                    Allocate column for GridCell occupant.
        """
        self.columns = def_d.get(COLUMNS, 1)
        self._grid_cell_q = [None] * self.columns
        super().__init__(def_d, None)

    def add_to_grid(self, grid, row):
        """
        Attach GridCell to a Grid.

        grid: Gtk.Grid
            Receive GridCell.
        row: int
            Attach at this position in the Grid.
        """
        for grid_cell in self._grid_cell_q:
            if grid_cell and grid_cell.occupant:
                # (child, left, top, width, height)
                grid.attach(
                    grid_cell.occupant,
                    grid_cell.column,
                    row,
                    grid_cell.width,
                    1
                )

    def add(self, g):
        """
        Receive GridCell for the GridRow.

        g: GridCell
        """
        if g.column >= self.columns:
            # Attempt to fix a malformed GridCell.
            g.column = max(0, self.columns - 1)
        self._grid_cell_q[g.column] = g


class GridCell(Container):
    """
    A GridCell Container can contain Widget or any other container besides
    GridRow. A GridCell defines an item to attach to its Gtk.Grid and
    its parent is strictly GridRow.

    GridCell attribute
        column: int
            Is the index to the GridCell in a Grid.

        occupant: Widget
            Resides in the GridCell.

        width: int
            Allocate 'Gtk.Grid' column for the GridCell's Widget.
    """
    def __init__(self, def_d):
        """
        GridCell definition
            d: dict
                width: int
                    Allocate one or more columns for the cell content.

                column: int
                    Is the index of the cell in the GridRow.
        """
        super().__init__(def_d, None)

        self.occupant = None
        self.width = def_d.get(WIDTH, 1)
        self.column = def_d.get(COLUMN, 0)

    def add(self, g):
        """
        Record the assigned Widget for the Grid's cell.

        g: Widget
            Is the cell occupant.
        """
        self.occupant = g.gtk_addable
