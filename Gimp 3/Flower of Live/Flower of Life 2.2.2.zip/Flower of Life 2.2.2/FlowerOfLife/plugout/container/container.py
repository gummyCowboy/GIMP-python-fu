#!/usr/bin/env python3
from plugout.constant import CONTAINER_SIGNAL
from plugout.widget.widget import Widget
from gi.repository import GObject       # noqa

"""
Define a super-class for containing 'Gtk.Widget'.
Each sub-class is a 'Gtk.Container' wrapper.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/Container.html'

AnyGroup creates Container using a definition dict.

____________________
Container Definition
¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
A Container is an object which contains other Widgets or Containers, so its
definition serves itself and its contents. Its nature is to
branch-off from another Container in the AnyGroup tree.

AnyGroup mandates these two items in a Container definition.

{
    # Provide a container key. The key doesn't serve identity but
    # order is can be still be served.
    container_key: {

        # Identify the Container type.
        TYPE: Container,

        # CHILD is unique to a Container definition, and is not found
        # in a Widget-leaf definition.

        # The CHILD dict has ordered content within the Container.
        CHILD: {
            # Define branch or leaf.

            # a branch
            branch_key: Container definition,

            # a leaf
            leaf_key: Widget definition
        }
    }
}
"""


class Container(GObject.GObject, Widget):
    """
    Is a super class for container Widget-type.
    Check group dict for its GROUP insertion. As a GObject,
    it can send RANDOMIZE signal. Generally, its content
    are automatically subscribed to this signal
    by the RANDOMER definition item.
    """
    __gsignals__ = CONTAINER_SIGNAL

    def __init__(self, def_d, g):
        """
        def_d: dict
            Container definition

        g: Gtk.Widget
            Is wrapped by this Container class and is
            referenced by the 'widget' attribute.
        """
        GObject.GObject.__init__(self)
        Widget.__init__(self, def_d, g)

    def add(self, g):
        """
        Add a 'Gtk.Widget' to the 'Gtk.Container'.

        g: Widget
            Reference its attribute 'gtk_addable', a 'Gtk.Widget'.
        """
        g1 = g.gtk_addable

        if g.pack_end:
            # expand, fill, bool option
            self.widget.pack_end(g1, False, False, 0)

        elif g.pack_start:
            self.widget.pack_start(g1, False, False, 0)
        else:
            self.widget.add(g1)
