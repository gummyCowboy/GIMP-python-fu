#!/usr/bin/env python3


def convert_dict_to_str(d):
    """
    This function returns a string representing a given dictionary
    with its relational and hierarchical structure.

    d: dict
    Return: string
        Extracted from the dictionary.
    """
    def _loop(_output, _d, _indent):
        """
        _output: string
        _d: dict
        _indent: int
        """
        for _k, _a in _d.items():
            _s = "\t" * _indent

            if isinstance(_a, dict):
                _output = _output + f'{_s}{_k}:' + '\n'
                _output = _loop(_output, _a, _indent + 1)

            else:
                _output = _output + f'{_s}{_k}: {_a}' + '\n'
        return _output

    s = ""

    if isinstance(d, dict):
        s = _loop(s, d, 0)

    else:
        s = f'The function print_d arg is not dict, but is a {type(d)}'
    return s
