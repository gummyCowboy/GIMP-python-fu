#!/usr/bin/env python3
from math import cos, sin
from life.constant import (
    ADD, CENTER, DEGREE_60, DEGREE_120,
    DEGREE_180, DEGREE_240, DEGREE_300,
    FRAME, REPLACE, RING_1, RING_2,
    RING_3, RING_4, RING_5, RING_6, SUBTRACT
)
from life.pdb import EllipseSelect, GradientFill, GradientNew
import gi                             # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, Gegl  # noqa


def add_layer(j, parent=None, position=0, layer_name="Base"):
    """
    Add a layer to an image.

    j: Gimp.Image
        Receive layer.

    parent: Image.GroupLayer or None
        Put layer in a group.

    position: int
        Is the offset from the top of the parent.

    layer_name: string
        Give the layer a name.

    Return: layer
        newly created
    """
    z = Gimp.Layer.new(
        j,
        layer_name,
        j.get_width(),
        j.get_height(),
        Gimp.ImageType.RGBA_IMAGE,
        100,
        Gimp.LayerMode.NORMAL
    )

    j.insert_layer(z, parent, position)
    return z


def add_group_layer(j, parent=None, position=0, layer_name="Group"):
    """
    Add a group layer to an image.

    j: Gimp.Image
        Receive layer.

    parent: Image.GroupLayer or None
        Specify another layer group to nest this layer group.

    position: int
        Is the offset from the top of the parent.

    layer_name: string
        Give the layer group a name.

    Return: group layer
        newly created
    """
    z = Gimp.GroupLayer.new(j, layer_name)

    j.insert_layer(z, parent, position)
    return z


def fill_selection_with_color(z, color):
    """
    Fills a selection with a color.

    z: Gimp.Drawable
        layer in image with selection
        Receive fill.

    color : Gegl.Color
        color of the circle
    """
    opacity = color.get_rgba().alpha * 100
    if opacity:
        Gimp.context_set_foreground(color)
        Gimp.context_set_opacity(opacity)
        z.edit_fill(Gimp.FillType.FOREGROUND)


def get_point_on_circle(x, y, angle, radius):
    """
    Return a point on the circle that corresponds to a rotation angle.

    x, y: int
        center of the circle

    angle : float
        the rotation angle

    radius : float
        the radius of the circle

    Returns:
        (x, y) of float
        the point on the circle
    """
    return (sin(angle) * radius) + x, (cos(angle) * -radius) + y


class Output:
    """Manage Flower of Life image/layer output."""

    def __init__(self):
        # WindowMain
        self._radius = \
            self._color_type = \
            self._line_width = \
            self._flower_type = \
            self._frame_width = \
            self._color_button_array = None

        # Output
        self._image = \
            self._display = \
            self._image_w = \
            self._is_black = \
            self._image_center = \
            self._circle_radius =  \
            self._is_main_flower = \
            self._expanded_image_w = None

    def _convert_to_gimp_color(self):
        """
        Convert float component in the color array to Gimp.Color.
        """
        # list of ring color in Gegl.Color format, 'q'.
        q = []

        # Convert float color to string suitable for Gegl.Color.
        # Gtk.Color, 'a'
        for i, a in enumerate(self._color_button_array):
            if self._is_black:
                if self._is_outline:
                    color_s = 'black'
                else:
                    color_s = 'white' if i < 7 else 'black'

            else:
                color_s = 'rgba(%f,%f,%f,%f)' % tuple(a)
            q.append(Gegl.Color.new(color_s))
        self._color_button_array = q

    def _create_image(self):
        """Begin creating a new Flower of Life image."""
        if self._image:
            # Remove the previous image.
            self._display.delete()
            self._image = self._display = None

        if not self._image:
            w = self._expanded_image_w
            self._image = Gimp.Image.new(w, w, Gimp.ImageBaseType.RGB)

        # Create a view.
        self._display = Gimp.Display.new(self._image)

    def _draw_1st_ring(self, color):
        """
        Draw the first ring around the image center.

        color: Gegl.Color
            Is the color of the ring output.
        """
        x = self._image_center
        y = self._image_center - self._circle_radius
        angle = .0

        # circle count, '6'
        for i in range(6):
            self._draw_ring_circle(x, y, color, RING_1)
            angle += DEGREE_60
            x, y = get_point_on_circle(
                self._image_center,
                self._image_center,
                angle,
                self._circle_radius
            )

    def _draw_2nd_ring(self, color):
        """
        Draw the 2nd ring of circles.

        color: Gegl.Color
            Is the color of the ring output.
        """
        ring_radius = self._circle_radius * 2
        x = self._image_center
        y = self._image_center - ring_radius
        angle = .0

        # circle count, '6'
        for i in range(6):
            self._draw_ring_circle(x, y, color, RING_2)
            angle += DEGREE_60
            x, y = get_point_on_circle(
                self._image_center,
                self._image_center,
                angle,
                ring_radius
            )

    def _draw_3rd_ring(self, color):
        """
        Draw the 3rd ring of circles.

        color: Gegl.Color
            Is the color of the ring output.

        Return: list
            [3rd ring circle's center, ...]
        """
        angle1 = .0
        angle2 = DEGREE_60
        ring_center = []

        # circle count, '6'
        for i in range(6):
            x, y = get_point_on_circle(
                self._image_center,
                self._image_center,
                angle1,
                self._circle_radius
            )
            x, y = get_point_on_circle(x, y, angle2, self._circle_radius)

            ring_center.append((x, y))
            self._draw_ring_circle(x, y, color, RING_3)

            angle1 += DEGREE_60
            angle2 += DEGREE_60
        return ring_center

    def _draw_4th_ring(self, color, ring_center):
        """
        Draw the 4th ring of circles.

        color: Gegl.Color
            Is the color of the ring output.

        ring_center: list
            [center of 3rd ring circle, ...]
        """
        angle1 = .0
        angle2 = DEGREE_60

        # circle count, '6'
        for i in range(6):
            a, b = ring_center[i]
            x, y = get_point_on_circle(a, b, angle1, self._circle_radius)

            self._draw_ring_circle(x, y, color, RING_4)

            x, y = get_point_on_circle(a, b, angle2, self._circle_radius)

            self._draw_ring_circle(x, y, color, RING_4)

            angle1 += DEGREE_60
            angle2 += DEGREE_60

    def _draw_5th_ring(self, color):
        """
        Draw the 5th ring of circles.

        color: Gegl.Color
            Is the color of the ring output.
        """
        radius = self._circle_radius * 3
        angle = .0

        # circle count, '6'
        for i in range(6):
            x, y = get_point_on_circle(
                self._image_center, self._image_center, angle, radius
            )
            angle += DEGREE_60
            self._draw_ring_circle(x, y, color, RING_5)

    def _draw_6th_ring(self, color, ring_center):
        """
        Draw the 6th and final ring of circles.

        color: Gegl.Color
            Is the color of the ring output.

        ring_center: list
            [center of 3rd ring circle, ...]
        """
        extra_ring = [0] * 12
        angle = -DEGREE_60
        radius = self._circle_radius

        # circle count, '6'
        for i in range(6):
            a, b = ring_center[i]
            extra_ring[i * 2 + 1] = a, b
            extra_ring[i * 2] = get_point_on_circle(a, b, angle, radius)
            angle += DEGREE_60

        angle1 = 0
        angle2 = DEGREE_60

        # the last of the cube, the last edge
        for i in range(2):
            k = (0, 2)[i]
            for j in range(3):
                a, b = extra_ring[j + k]
                c, d = get_point_on_circle(a, b, angle1, radius)
                x, y = get_point_on_circle(c, d, angle2, radius)
                self._draw_ring_circle(x, y, color, RING_6)

            angle1 += DEGREE_60
            angle2 += DEGREE_60

        angle1 = DEGREE_120
        angle2 = DEGREE_180

        for i in range(2):
            k = (4, 6)[i]
            for j in range(3):
                a, b = extra_ring[j + k]
                c, d = get_point_on_circle(a, b, angle1, radius)
                x, y = get_point_on_circle(c, d, angle2, radius)
                self._draw_ring_circle(x, y, color, RING_6)

            angle1 += DEGREE_60
            angle2 += DEGREE_60

        angle1 = DEGREE_240
        angle2 = DEGREE_300

        for i in range(2):
            k = (8, 10)[i]
            for j in range(3):
                if j + k > 11:
                    j = k = 0

                a, b = extra_ring[j + k]
                c, d = get_point_on_circle(a, b, angle1, radius)
                x, y = get_point_on_circle(c, d, angle2, radius)
                self._draw_ring_circle(x, y, color, RING_6)

            angle1 += DEGREE_60
            angle2 += DEGREE_60

    def _draw_center_circle(self):
        """Draw the center at the image center."""
        # center color index, '0'
        self._draw_flower_circle(
            self._image_center,
            self._image_center,
            self._color_button_array[0],
            CENTER
        )

    def _draw_flower(self):
        """Draw the flower."""
        def _merge():
            """Return: Gimp.Layer."""
            return j.merge_visible_layers(Gimp.MergeType.EXPAND_AS_NECESSARY)

        j = self._image
        self._is_main_flower = True

        self._convert_to_gimp_color()
        self._fill_base_layer()
        self._draw_center_circle()

        # Draw rings. ring index, '1' to '6'
        self._draw_1st_ring(self._color_button_array[1])
        _merge()

        self._draw_2nd_ring(self._color_button_array[2])
        _merge()

        ring_center = self._draw_3rd_ring(self._color_button_array[3])
        self._is_main_flower = False

        _merge()
        self._draw_4th_ring(self._color_button_array[4], ring_center)
        _merge()
        self._draw_5th_ring(self._color_button_array[5])
        _merge()
        self._draw_6th_ring(self._color_button_array[6], ring_center)

        z = _merge()

        # Load and combine selection. Cut the
        # non-selection area from the image.
        Gimp.Selection.none(j)

        for i in j.get_channels():
            j.select_item(ADD, i)
            j.remove_channel(i)

        selection = j.get_selection()

        if not z.has_alpha():
            z.add_alpha()

        selection.invert(j)
        z.edit_clear()

        # Add the frame.
        if self._frame_width:
            # frame color index, '7'
            z = self._draw_frame(self._color_button_array[7])

        if not self._is_black:
            self._draw_gradient(z)

        Gimp.Selection.none(j)
        Gimp.context_set_interpolation(Gimp.InterpolationType.NOHALO)
        j.scale(self._image_w, self._image_w)

    def _draw_flower_circle(self, x, y, color, layer_name):
        """
        Draws a flower circle.

        x, y : point
            top-left corner of the circle bounding box

        color: Gegl.Color
            Fill the circle.

        layer_name: string
            Give the circle layer a name.

        Return: Gimp.Layer
            newly created
        """
        x -= self._circle_radius
        y -= self._circle_radius
        z = add_layer(self._image, layer_name=layer_name)

        # circle diameter, 'w'
        w = self._circle_radius + self._circle_radius

        self._select_ellipse(REPLACE, x, y, w, w)
        fill_selection_with_color(z, color)
        return z

    def _draw_ring_circle(self, *arg):
        """
        Draw a circle for a ring processor.

        arg: tuple
            Specify with 'draw_flower_circle'.

        Return: layer
            Has ring of colored circles or rings.
        """
        z = self._draw_flower_circle(*arg)

        if not self._is_outline:
            z.set_mode(Gimp.LayerMode.DIFFERENCE)
        return z

    def _draw_frame(self, color):
        """
        Draws the frame that surrounds the flower.

        color: Gegl.Color
            Is the color of the ring output.
        """
        j = self._image

        # observation, not sure why, '-2'
        flower_dim = self._radius * 2 - 2

        frame_dim = flower_dim + self._frame_width * 2
        y = x = self._image_center - frame_dim / 2.
        z = add_layer(j, layer_name=FRAME)

        self._select_ellipse(
            REPLACE, x, y, frame_dim, frame_dim, is_frame=True
        )

        # Remove the center of the selection to create a ring-frame:
        y = x = self._image_center - flower_dim / 2.

        # observation, not sure why
        flower_dim -= 1

        self._select_ellipse(
            SUBTRACT, x, y, flower_dim, flower_dim, is_frame=True
        )
        fill_selection_with_color(z, color)
        return j.merge_down(z, Gimp.MergeType.CLIP_TO_IMAGE)

    def _draw_gradient(self, base_layer):
        """
        Create a radial gradient to overlay the flower composite.

        base_layer: Gimp.Layer
            The image is flat.
        """
        j = self._image
        z = add_layer(j, layer_name="Gradient")
        center = self._image_center
        result = GradientNew.do("flower")
        gradient = result.index(1)

        # perimeter
        color = Gegl.Color.new('#000000FF')

        gradient.segment_set_right_color(0, color)

        # center:
        color = Gegl.Color.new('#FFFFFFFF')

        gradient.segment_set_left_color(0, color)
        Gimp.context_set_gradient(gradient)
        Gimp.Selection.none(j)
        GradientFill.do(
            (
                ('drawable', z),
                ('gradient-type', Gimp.GradientType.RADIAL),
                ('offset', 0),
                ('supersample', True),
                ('supersample-max-depth', 3),
                ('supersample-threshold', 0),
                ('dither', True),
                ('x1', center),
                ('y1', center),
                ('x2', center),
                ('y2', 2)
            )
        )

        # Remove the resource.
        gradient.delete()

        j.select_item(REPLACE, base_layer)

        selection = j.get_selection()

        selection.invert(j)
        z.edit_clear()
        z.set_mode(Gimp.LayerMode.OVERLAY)

    def _expand(self):
        """Calculate expanded image scale."""
        # The expanded image size is squared in size, '2'.
        self._radius *= 2
        self._frame_width *= 2
        self._line_width *= 2
        self._image_w = self._radius + self._frame_width

        # Expand, '2'.
        self._expanded_image_w = self._image_w * 2

        self._image_center = self._expanded_image_w / 2.
        self._circle_radius = int(self._radius / 3)

    def _fill_base_layer(self):
        Gimp.Selection.none(self._image)
        if not self._is_outline:
            color = Gegl.Color.new(('white', 'black')[self._is_black])
            Gimp.context_set_foreground(color)
            self._base_layer.edit_fill(Gimp.FillType.FOREGROUND)

    def _select_ellipse(self, op, x, y, w, h, is_frame=False):
        """
        Select an ellipse.

        op: Gimp.ChannelOps
            ADD, REPLACE, SUBTRACT or INTERSECT

        x, y: int
            topleft point of the selection

        w, h: int
            size of the selection

        is_frame: bool
            Is True if the selection is a frame.
        """
        def _save():
            """
            Return: Gimp.Channel
            """
            selection = j.get_selection()
            return selection.save(j)

        j = self._image

        EllipseSelect.do((
            ('image', j),
            ('operation', op),
            ('x', x),
            ('y', y),
            ('width', w),
            ('height', h)
        ))

        if self._is_main_flower:
            channel = _save()
            s = channel.get_name()
            channel.set_name(f'main {s}')

        if self._is_outline and not is_frame:
            # Cut-out the center of the circle to form an outline.
            w1 = self._line_width
            EllipseSelect.do((
                ('operation', SUBTRACT),
                ('x', x + w1),
                ('y', y + w1),
                ('width', w - w1 - w1),
                ('height', h - w1 - w1)
            ))

    def create(self, d):
        """
        Create a Flower of Life symbol.

        d: dict
            'AnyGroup.value_d'
            {Widget key: Widget value}
        """
        for k, a in d.items():
            # Widget value, 'a'
            setattr(self, "_" + k, a)

        self._is_outline = bool(self._flower_type)
        self._is_black = bool(self._color_type)

        self._expand()
        self._create_image()
        self._image.undo_group_start()

        self._base_layer = add_layer(self._image)

        self._draw_flower()
        self._image.undo_group_end()
        Gimp.displays_flush()
