#!/usr/bin/env python3
from plugout.constant import RANDOMIZE
from plugout.define.key import RANDOMER
from plugout.widget.button import Button

"""Define random color generating Button."""


class RandomColorArrayButton(Button):
    """
    Is an indirect setter for the color array.
    Generate random color for the color array.
    Send a SET_COLOR_ARRAY signal with randomized value.
    """

    def __init__(self, def_d):
        """
        def_d: dict
            RandomColorArrayButton definition
                randomer: Container
                    Emit RANDOMIZE signal.
        """
        self._randomer = def_d.get(RANDOMER)

        super().__init__(def_d)
        self.widget.connect('clicked', self.on_random_button_action)

    def on_random_button_action(self, _):
        """
        _: Gtk.Button
            Is wrapped by this class.
        """
        if self._randomer:
            # Generate random color type, 'None'.
            self._randomer.emit(RANDOMIZE, None)


class TwoColorButton(Button):
    """
    Is an indirect setter for the color array.
    Generate a random color pair pattern for the color array.
    Send a SET_COLOR_ARRAY signal with randomized value.
    """

    def __init__(self, def_d):
        """
        def_d: dict
            RandomColorArrayButton definition
                randomer: Container
                    Emit RANDOMIZE signal.
        """
        self._randomer = def_d.get(RANDOMER)

        super().__init__(def_d)
        self.widget.connect('clicked', self.on_two_color_button_action)

    def on_two_color_button_action(self, _):
        """
        _: Gtk.Button
            Is wrapped by this class.
        """
        if self._randomer:
            # Generate two-color type, '2'.
            self._randomer.emit(RANDOMIZE, 2)
