#!/usr/bin/env python3
from plugout.constant import COLOR_TIP
from plugout.define.key import TEXT, VALUE
from plugout.gegl_color import (
    convert_float_to_gegl_color, convert_gegl_color_to_int
)
from plugout.widget.emit import WidgetValue
from random import uniform
import gi                                  # type: ignore
gi.require_version('Gtk', '3.0')
gi.require_version('GimpUi', '3.0')
from gi.repository import GimpUi, Gtk         # noqa

"""Define a Widget sub-class for getting and setting color in an array."""


class ColorButtonArray(WidgetValue):

    def __init__(self, def_d):
        """
        def_d: dict
            ColorButtonArray definition
                text: iterable
                    (Color button label, ...)
                    Convert to sub-value key.

                value: iterable
                    ((.0 to 1., (.0 to 1., (.0 to 1., (.0 to 1., ), ...)
                    RGBA
                    Convert to 'Gdk.Color'.
        """
        text = def_d.get(TEXT, ())
        self._widget_q = [None] * len(text)
        self._hbox_alignment = Gtk.Alignment()
        self._hbox_alignment.set_padding(2, 2, 0, 0)
        self._hbox = Gtk.HBox()
        self._hbox_alignment.add(self._hbox)
        value_q = def_d.get(VALUE, ())
        self._value_q = list(value_q)

        super().__init__(def_d, self._hbox_alignment)

        self.value_d[self.key] = self._value_q

        # color index for setting , 'i'
        for i, s in enumerate(text):
            vbox = Gtk.VBox()
            color = convert_float_to_gegl_color(value_q[i])

            # button size, '1'; Is set automatically.
            # transparency VALUE type, '2'
            g = self._widget_q[i] = GimpUi.ColorButton.new(s, 1, 1, color, 2)

            g.connect('color-changed', self.on_widget_change)
            g.connect('color-changed', self.on_color_changed)
            g.connect('realize', self.on_color_changed)
            g.set_update(False)
            vbox.add(Gtk.Label.new(s))
            vbox.add(g)
            self._hbox.add(vbox)

    def _set_tooltip(self, g, a):
        """
        Make a tooltip for a 'Gtk.ColorButton'.

        g: Gtk.ColorButton
        a: Gegl.Color
        """
        rgba = convert_gegl_color_to_int(a)
        g.set_tooltip_text(COLOR_TIP.format(*rgba))

    def get_a(self):
        """
        Retrieve the value of the 'Gtk.ColorButton'.

        Return: tuple
            high precision float
            (.0 to 1.)
        """
        return self._value_q

    def on_color_changed(self, g):
        """
        A ColorButton changed value, so its tooltip needs updating.
        Record its value for the color button array's color retrieval.

        g: GimpUi.ColorButton
            Has a new value.
        """
        # Gegl.Color, 'color'
        color = g.get_color()

        # non-translated linear color, 'rgba'
        rgba = color.get_rgba()

        for i, g1 in enumerate(self._widget_q):
            if g1 == g:
                self._value_q[i] = rgba.red, rgba.green, rgba.blue, rgba.alpha
                break
        self._set_tooltip(g, color)

    def on_custom_signal(self, _, arg):
        """
        Override the Widget function and change visibility.

        _: WindowMain
        arg: tuple
            (signal, Widget instance, Widget value)
        """
        widget, value = arg[1:]
        if widget.key == 'color_type':
            # 'value' is an index. Black is RadioButton, '1'.
            if value == 1:
                self._hbox.hide()
            else:
                self._hbox.show()

    def randomize(self, _, random_type):
        """
        Respond to a randomize signal. Randomize
        the value of the 'GimpUi.ColorButton' array.

        _: Widget
        random_type: int or None
        """
        def _random():
            return [round(uniform(.0, 1.), 4) for _ in range(3)] + [1.]

        # all random type, 'None'
        if random_type is None:
            for g in self._widget_q:
                g.set_color(convert_float_to_gegl_color(_random()))
                g.emit('color-changed')

        # two-color random type, '2'
        elif random_type == 2:
            a = _random()
            b = _random()
            for i, g in enumerate(self._widget_q):
                if i % 2:
                    # odd
                    g.set_color(convert_float_to_gegl_color(a))

                else:
                    # even
                    g.set_color(convert_float_to_gegl_color(b))
                g.emit('color-changed')

    def set_a(self, array):
        """
        Set the color values of the 'Gtk.ColorChooser' array.

        array: tuple
            [(.0 to 1., ...), ...]; a color, four sequenced
            float numbers representing RGBA
            [color, ...] x 8, one for each ColorButton
        """
        for i, q in enumerate(array):
            g = self._widget_q[i]

            g.set_color(convert_float_to_gegl_color(q))

            # Gtk only sends this signal when
            # its ColorChooser dialog is accepted.
            g.emit('color-changed')
