#!/usr/bin/env python3
from copy import deepcopy
from life.constant import (
    CTRL_P, DIALOG_MAIN_SIGNAL, PREVIEW,
    PREVIEW_TYPE, TITLE
)
from life.define_main import DEFINE_MAIN
from life.output import Output
from plugout.any_group import AnyGroup
from plugout.constant import (
    ACCEPT, ANY_CHANGE, CANCEL,
    CANCEL_TYPE, DELETE_TYPE,
    KEY_PRESS_EVENT, OK_TYPE
)
from plugout.container.content_area import ContentArea
from plugout.dialog.dialog import Dialog
import gi                                  # type: ignore
gi.require_version('Gdk', '3.0')
from gi.repository import Gdk, Gtk, GObject     # noqa


class DialogMain(GObject.GObject, Dialog):
    """Create a Dialog for creating Yin-Yang symbol."""
    __gsignals__ = DIALOG_MAIN_SIGNAL

    def __init__(self):
        """Open a dialog. Respond to user interaction."""
        def _on_accept():
            self.dialog.destroy()

            self.dialog = None
            self.on_preview()

        def _on_cancel():
            self.dialog.destroy()
            self.dialog = None

        def _on_preview():
            self.on_preview()

        GObject.GObject.__init__(self)

        self._preview_d = {}
        self._preview_button = None
        self._output = Output()

        # {dialog button response type: response type handler}
        response_d = {
            CANCEL_TYPE: _on_cancel,
            DELETE_TYPE: _on_cancel,
            OK_TYPE: _on_accept,
            PREVIEW_TYPE: _on_preview
        }

        self.connect(ANY_CHANGE, self.on_any_change)
        Dialog.__init__(
            self,
            TITLE,
            (
                (CANCEL, CANCEL_TYPE),
                (PREVIEW, PREVIEW_TYPE),
                (ACCEPT, OK_TYPE)
            ),
            self.add_widget,
            response_d
        )

    def add_widget(self, content_area):
        """
        Add widget to the Dialog's content area.

        content_area: Gtk.Box
            There's room to grow.
        """
        # CSS to animate button appearance on class toggle
        self._preview_button = self.dialog.get_widget_for_response(
            PREVIEW_TYPE
        )
        self._preview_button.set_tooltip_text(CTRL_P)
        self.dialog.connect(KEY_PRESS_EVENT, self.on_key_press)

        container = ContentArea(content_area)
        self._any_group = AnyGroup(
            DEFINE_MAIN,
            container,
            preset_key=None,
            is_any_change=True,
            host=self
        )
        content_area.show_all()

    def on_any_change(self, *_):
        """Enable the Preview button on any Widget change."""
        if self._preview_button:
            self._preview_button.set_sensitive(1)

    def on_key_press(self, _, event_key):
        """
        Save the preset if the user presses the return key.

        _ Gtk.Dialog
            not used

        event_key: Gdk.EventKey
        """
        is_control = (event_key.state & Gdk.ModifierType.CONTROL_MASK)

        if is_control and event_key.keyval == Gdk.KEY_p:
            self._preview_button.emit('clicked')
            return True
        return False

    def on_queue_click(self, *_):
        self._preview_button.emit('clicked')

    def on_preview(self):
        """
        Respond to a Preview button action by performing a preview
        but only if things have changed since the last preview.
        """
        d = self._any_group.value_d
        g = self._preview_button

        if not g.get_style_context().has_class('pressed'):
            g.get_style_context().add_class('pressed')

        if d != self._preview_d:
            self._preview_d = deepcopy(d)
            self._output.create(d)

        g.get_style_context().remove_class('pressed')
        g.set_sensitive(0)
