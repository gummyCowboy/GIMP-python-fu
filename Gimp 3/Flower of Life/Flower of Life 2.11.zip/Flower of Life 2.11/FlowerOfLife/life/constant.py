#!/usr/bin/env python3
from plugout.constant import ANY_CHANGE
import gi                                          # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GLib, GObject      # noqa


def _(n):
    """
    Translate English to local language.

    n: string
        Translate.

    Return: string
        translated
    """
    return GLib.dgettext(None, n)


PROCEDURE_NAME = 'plug-in-flower-of-life'
TITLE = "Flower of Life 2.11"
COLOR_ARRAY_VALUE = (
    (.45, .53, .52, 1.),
    (.04, .77, .32, 1.),
    (.19, .06, .19, 1.),
    (.89, .08, .77, 1.),
    (.09, .87, .86, 1.),
    (1., .10, .03, 1.),
    (.08, .23, .75, 1.),
    (.04, .48, .48, 1.)
)

# preview button type
PREVIEW_TYPE = -99

# angle in radian
DEGREE_60 = 1.0472
DEGREE_120 = 2.0944
DEGREE_180 = 3.14159
DEGREE_240 = 4.18879
DEGREE_300 = 5.23599

# selection ops
SUBTRACT = Gimp.ChannelOps.SUBTRACT
REPLACE = Gimp.ChannelOps.REPLACE
ADD = Gimp.ChannelOps.ADD

# Translate____________________________________________________________________
BLACK = _("Black")
CENTER = _("Center")
COLOR_ARRAY = _("Color Array")
COLOR_ARRAY_TEXT = (
    _("Center"), _("Ring 1"), _("Ring 2"), _("Ring 3"),
    _("Ring 4"), _("Ring 5"), _("Ring 6"), _("Frame")
)
COLOR_TOOLTIP = _(" Red\t{} \n Green\t{} \n Blue\t{} \n Alpha\t{}")
COLOR_TYPE = _("Color Type")
CTRL_P = _("Ctrl-P")
FLOWER = _("Flower")
FLOWER_TYPE = _("Flower Type")
FRAME = _("Frame")
FRAME_WIDTH = _("Frame Width")
LINE_WIDTH = _("Line Width")
PLUGIN_BLURB = _(
    "Create a new image, is non-destructive,"
    " and does not require an open image."
)
PLUGIN_TOOLTIP = _("Create a Flower of Life image.")
PREVIEW = _("Preview")
OUTLINE = _("Outline")
RADIUS = _("Radius")
RANDOM = _("Random")
RING_1 = _("1 Ring")
RING_2 = _("2 Ring")
RING_3 = _("3 Ring")
RING_4 = _("4 Ring")
RING_5 = _("5 Ring")
RING_6 = _("6 Ring")
TWO_COLOR = _("Two Color")

# custom Signal________________________________________________________________
COLOR_TYPE_CHANGE = 'color-type-change'
FLOWER_TYPE_CHANGE = 'flower-type-change'
IMAGE_SIZE_CHANGE = 'image-size-change'

# run first argument
# (emission stage, type of signal, argument type)
SIGNAL_ARG = GObject.SIGNAL_RUN_LAST, None, (GObject.TYPE_PYOBJECT,)

DIALOG_MAIN_SIGNAL = {}
for k in (
    ANY_CHANGE, COLOR_TYPE_CHANGE, FLOWER_TYPE_CHANGE, IMAGE_SIZE_CHANGE
):
    DIALOG_MAIN_SIGNAL[k] = SIGNAL_ARG
