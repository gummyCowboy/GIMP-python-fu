#!/usr/bin/env python3
from math import cos, sin
import gi       # type: ignore

gi.require_version('Gtk', '3.0')

from gi.repository import Gimp, Gegl, GLib   # type: ignore

# angle in radian
DEGREE_30 = .523599
DEGREE_45 = .785398
DEGREE_60 = 1.0472
DEGREE_90 = 1.5708
DEGREE_120 = 2.0944
DEGREE_180 = 3.14159
DEGREE_240 = 4.18879
DEGREE_300 = 5.23599


class Flower:
    """Is a container for the outline flower type."""
    # Remember the size of the image after a Preview.
    # GIMP fails to updates its image properties after a scale op.
    final_image_size = 0

    is_diff = False

    # When True, the circle are converted to the line flower type.
    is_outline = False

    # When True, the circle or line selection is saved.
    is_save = True

    # Is the flower image.
    image = display = None

    # This is the width of line in the line flower type.
    line_w = 0


def _(message):
    """
    Translate English to local language.

    message: string
        to translate

    Return: string
        translated
    """
    return GLib.dgettext(None, message)


def add_layer(image, parent=None, position=0, layer_name="Base"):
    """
    Add a layer to an image.

    image: GIMP image
        Receive layer.

    parent: group layer or None
        Put layer in a group.

    position: int
        Is the offset from the top of the parent.

    layer_name: string
        Give the layer a name.

    Return: layer
        newly created
    """
    layer = Gimp.Layer.new(
        image,
        layer_name,
        image.get_width(),
        image.get_height(),
        Gimp.ImageType.RGBA_IMAGE,
        100,
        Gimp.LayerMode.NORMAL
    )

    image.insert_layer(layer, parent, position)
    return layer


def add_group_layer(image, parent=None, position=0, layer_name="Group"):
    """
    Add a group layer to an image.

    image: GIMP image
        Receive layer.

    parent: layer group or None
        Specify another layer group to nest this layer group.

    position: int
        Is the offset from the top of the parent.

    layer_name: string
        Give the layer group a name.

    Return: group layer
        newly created
    """
    layer = Gimp.GroupLayer.new(image, layer_name)

    image.insert_layer(layer, parent, position)
    return layer


def calc_image_size(symbol_radius, frame_w):
    """
    Calculate the final and WIP image sizes.

    symbol_radius: int
        Is the radius of the flower.

    frame_w: int
        Is the span of the frame.

    Return: tuple
        (final image size, WIP image size)
    """
    # Add extra padding with the ending '2'.
    # Scale the WIP image size, '* 2', for down-scale interpolation.
    final_image_size = int(symbol_radius * 2 + frame_w * 2) + 2
    return final_image_size, int(final_image_size * 2)


def check_alpha(layer):
    """
    If the layer doesn't have alpha, then add the channel.

    layer: Gimp.Layer
        Receive alpha channel.
    """
    if not layer.has_alpha():
        layer.add_alpha()


def create_flower(d):
    """
    Begin creating a new Flower of Life Image.

    d: dict
        {widget key: widget value}
        Determine the image output.
    """
    if not Flower.image:
        image_size = calc_image_size(d['radius'], d['frame_w'])[1]
        Flower.image = create_image(image_size)

    image = Flower.image

    image.undo_group_start()

    base_layer = add_layer(image)

    draw_flower(image, base_layer, d)
    image.undo_group_end()
    Gimp.displays_flush()


def create_image(image_size):
    """
    Create a GIMP image.

    image_size: int
        Define the width and height of the image.

    Return: Gimp.Image
    """
    image = Gimp.Image.new(image_size, image_size, Gimp.ImageBaseType.RGB)

    # Create a view.
    Flower.display = Gimp.Display.new(image)

    return image


def create_preview(d):
    """
    Create a Preview image.

    d: dict
        widget value dict
        {widget key: widget value}
    """
    Flower.is_save = True
    Flower.is_diff = Flower.is_outline = False
    Flower.line_w = 0

    if Flower.image:
        Flower.display.delete()
        Flower.image = Flower.display = None
    create_flower(d)


def draw_1st_ring(image, center, circle_radius, color):
    """
    Draw the first ring around the image center.

    image: Gimp.Image
        Receive ring.

    center: int
        Is the center of the flower image.

    circle_radius: int
        Is the radius of a flower circle.

    color: Gegl.Color
        Is the color of the ring output.
    """
    x = center
    y = center - circle_radius
    angle = .0

    # circle count, '6'
    for i in range(6):
        draw_flower_ring(
            image, x, y, circle_radius, color, _("1 Ring")
        )
        angle += DEGREE_60
        x, y = get_point_on_circle(center, center, angle, circle_radius)


def draw_2nd_ring(image, center, circle_radius, color):
    """
    Draw the 2nd ring of circles.

    image: Gimp.Image
        Receive ring.

    center: int
        Is the center of the flower image.

    circle_radius: int
        Is the radius of a flower circle.

    color: Gegl.Color
        Is the color of the ring output.
    """
    ring_radius = circle_radius * 2
    x = center
    y = center - ring_radius
    angle = .0

    # circle count, '6'
    for i in range(6):
        draw_flower_ring(
            image, x, y, circle_radius, color, _("2 Ring")
        )
        angle += DEGREE_60
        x, y = get_point_on_circle(center, center, angle, ring_radius)


def draw_3rd_ring(image, center, circle_radius, color):
    """
    Draw the 3rd ring of circles.

    image: Gimp.Image
        Receive ring.

    center: int
        Is the center of the flower image.

    circle_radius: int
        Is the radius of a flower circle.

    color: Gegl.Color
        Is the color of the ring output.

    Return: list
        [3rd ring circle's center, ...]
    """
    angle1 = .0
    angle2 = DEGREE_60
    ring_center = []

    # circle count, '6'
    for i in range(6):
        x, y = get_point_on_circle(center, center, angle1, circle_radius)
        x, y = get_point_on_circle(x, y, angle2, circle_radius)

        ring_center.append((x, y))
        draw_flower_ring(
            image, x, y, circle_radius, color, _("3 Ring")
        )

        angle1 += DEGREE_60
        angle2 += DEGREE_60
    return ring_center


def draw_4th_ring(image, circle_radius, color, ring_center):
    """
    Draw the 4th ring of circles.

    image: Gimp.Image
        Receive ring.

    circle_radius: int
        Is the radius of a flower circle.

    color: Gegl.Color
        Is the color of the ring output.

    ring_center: list
        [center of 3rd ring circle, ...]
    """
    angle1 = .0
    angle2 = DEGREE_60

    # circle count, '6'
    for i in range(6):
        a, b = ring_center[i]
        x, y = get_point_on_circle(a, b, angle1, circle_radius)

        draw_flower_ring(
            image, x, y, circle_radius, color, _("4 Ring")
        )

        x, y = get_point_on_circle(a, b, angle2, circle_radius)

        draw_flower_ring(
            image, x, y, circle_radius, color, _("4 Ring")
        )

        angle1 += DEGREE_60
        angle2 += DEGREE_60


def draw_5th_ring(image, center, circle_radius, color):
    """
    Draw the 5th ring of circles.

    image: Gimp.Image
        Receive ring.

    center: int
        Is the center of the flower image.

    circle_radius: int
        Is the radius of a flower circle.

    color: Gegl.Color
        Is the color of the ring output.
    """
    radius = circle_radius * 3
    angle = .0

    # circle count, '6'
    for i in range(6):
        x, y = get_point_on_circle(center, center, angle, radius)
        angle += DEGREE_60
        draw_flower_ring(
            image, x, y, circle_radius, color, _("5 Ring")
        )


def draw_6th_ring(image, circle_radius, color, ring_center):
    """
    Draw the 6th and final ring of circles.

    image: Gimp.Image
        Receive ring.

    circle_radius: int
        Is the radius of a flower circle.

    color: Gegl.Color
        Is the color of the ring output.

    ring_center: list
        [center of 3rd ring circle, ...]
    """
    extra_ring = [0] * 12
    angle = -DEGREE_60

    # circle count, '6'
    for i in range(6):
        a, b = ring_center[i]
        extra_ring[i * 2 + 1] = a, b
        extra_ring[i * 2] = get_point_on_circle(a, b, angle, circle_radius)
        angle += DEGREE_60

    angle1 = 0
    angle2 = DEGREE_60

    # the last of the cube, the last edge
    for i in range(2):
        k = (0, 2)[i]
        for j in range(3):
            a, b = extra_ring[j + k]
            c, d = get_point_on_circle(a, b, angle1, circle_radius)
            x, y = get_point_on_circle(c, d, angle2, circle_radius)
            draw_flower_ring(
                image, x, y, circle_radius, color, _("6 Ring")
            )

        angle1 += DEGREE_60
        angle2 += DEGREE_60

    angle1 = DEGREE_120
    angle2 = DEGREE_180

    for i in range(2):
        k = (4, 6)[i]
        for j in range(3):
            a, b = extra_ring[j + k]
            c, d = get_point_on_circle(a, b, angle1, circle_radius)
            x, y = get_point_on_circle(c, d, angle2, circle_radius)
            draw_flower_ring(
                image, x, y, circle_radius, color, _("6 Ring")
            )

        angle1 += DEGREE_60
        angle2 += DEGREE_60

    angle1 = DEGREE_240
    angle2 = DEGREE_300

    for i in range(2):
        k = (8, 10)[i]
        for j in range(3):
            if j + k > 11:
                j = k = 0

            a, b = extra_ring[j + k]
            c, d = get_point_on_circle(a, b, angle1, circle_radius)
            x, y = get_point_on_circle(c, d, angle2, circle_radius)
            draw_flower_ring(
                image, x, y, circle_radius, color, _("6 Ring")
            )

        angle1 += DEGREE_60
        angle2 += DEGREE_60


def draw_flower(image, base_layer, d):
    """
    Draw the flower.

    image: Gimp.Image
        Receive output.

    base_layer: Gimp.Layer
        Is at the bottom of root layer stack.

    d: dict
        widget value dict
        {widget key: widget value}
    """
    frame_w = d['frame_w']
    symbol_radius = d['radius']
    is_black = not d['color_type']
    Flower.line_w = d['line_w']
    ring_color_q = d['color_d']
    Flower.is_outline = not d['flower_type'] and Flower.line_w

    # Scale by '2' for interpolation on image resize.
    flower_radius = symbol_radius * 2
    circle_radius = int(symbol_radius / 3 * 2)

    Flower.is_diff = not Flower.is_outline
    final_image_size, wip_image_size = calc_image_size(symbol_radius, frame_w)
    Flower.final_image_size = final_image_size
    center = int(wip_image_size / 2)

    # list of ring color in Gegl.Color format, 'q'.
    q = []

    # Convert float color to string suitable for Gegl.Color.
    # Gtk.Color, 'a'
    for i, a in enumerate(ring_color_q):
        # The following line creates a color, but the output looks
        # like it has been converted to perceptual color space.
        # color = Gegl.Color.new('rgb(%f,%f,%f)' % (.5, .5, .5))
        #
        # I also tested Gegl.Color.set_rgba(), but this also
        # creates a color in perceptual space.
        #
        # also perceptual space
        # color = 'rgba({},{},{},{})'.format(*a)
        if is_black:
            if Flower.is_outline:
                color = 'black'
            else:
                color = 'white' if i < 7 else 'black'
        else:
            # Create a color in linear space with a hex string
            # without gamma correction.
            #
            # In testing, this returns perceptual color even
            # with the linear setup above:
            # Gegl.color.get_rgba()
            color = "#{:02x}{:02x}{:02x}".format(
                *map(int, [b * 255 for b in a])
            )
        q.append(Gegl.Color.new(color))

    ring_color_q = q

    image.undo_group_start()
    Gimp.context_set_antialias(False)
    Gimp.context_set_feather(False)
    fill_layer(image, base_layer, ('white', 'black')[is_black])

    if Flower.is_outline:
        Flower.is_save = False

    # center color index, '0'
    draw_flower_circle(
        image, center, center, circle_radius, ring_color_q[0], _("Center")
    )

    if Flower.is_outline:
        Flower.is_save = True

    # Draw rings. ring index, '1' to '6'
    draw_1st_ring(image, center, circle_radius, ring_color_q[1])
    image.flatten()
    draw_2nd_ring(image, center, circle_radius + 1, ring_color_q[2])
    image.flatten()

    ring_center = draw_3rd_ring(image, center, circle_radius, ring_color_q[3])
    Flower.is_save = False
    layer = image.flatten()

    if not Flower.is_outline:
        draw_4th_ring(image, circle_radius + 1, ring_color_q[4], ring_center)
        image.flatten()
        draw_5th_ring(image, center, circle_radius, ring_color_q[5])
        image.flatten()
        draw_6th_ring(image, circle_radius + 1, ring_color_q[6], ring_center)
        layer = image.flatten()

    # Load and combine selection. Cut the non-selection area from the image.
    Gimp.Selection.none(image)

    for i in image.get_channels():
        image.select_item(Gimp.ChannelOps.ADD, i)
        image.remove_channel(i)

    selection = image.get_selection()

    check_alpha(layer)
    selection.invert(image)
    layer.edit_clear()

    # Add the frame.
    if frame_w:
        # frame color index, '7'
        layer = draw_frame(
            image, center, flower_radius, frame_w * 2, ring_color_q[7]
        )

    if not is_black:
        draw_gradient(image, center, layer)

    Gimp.Selection.none(image)
    Gimp.context_set_interpolation(Gimp.InterpolationType.NOHALO)
    image.scale(final_image_size, final_image_size)
    image.undo_group_end()


def draw_flower_circle(image, x, y, circle_radius, color, layer_name):
    """
    Draws a flower circle.

    image: GIMP image
        WIP

    x, y : point
        top-left corner of the circle bounding box

    color: Gegl.Color
        Fill the circle.

    layer_name: string
        Give the circle layer a name.

    Return: Gegl.Layer
        newly created
    """
    x -= circle_radius
    y -= circle_radius
    layer = add_layer(image, layer_name=layer_name)

    # circle diameter, 'w'
    w = circle_radius + circle_radius

    select_ellipse(image, Gimp.ChannelOps.REPLACE, x, y, w, w)
    fill_selection(layer, color)
    return layer


def draw_flower_ring(*arg):
    """
    Draw a circle for a ring processor.

    A layer in a ring circle for the Petal Flower Type
    has a DIFFERENCE layer mode.

    arg: tuple
        Specify with 'draw_flower_circle'.

    Return: layer
        Has ring of colored circles or rings.
    """
    layer = draw_flower_circle(*arg)

    if Flower.is_diff:
        layer.set_mode(Gimp.LayerMode.DIFFERENCE)
    return layer


def draw_frame(image, center, flower_radius, frame_w, color):
    """
    Draws the frame that surrounds the flower.

    image: Gimp.Image
        Receive ring.

    center: int
        Is the center of the flower image.

    flower_radius: int
        Is the radius of the flower made by the combined circles.

    frame_w: int
        Is the span of the frame.

    color: Gegl.Color
        Is the color of the ring output.
    """
    flower_dim = int(flower_radius * 2)
    frame_dim = flower_dim + frame_w * 2
    y = x = center - flower_radius - frame_w
    layer = add_layer(image, layer_name=_("Frame"))

    select_ellipse(
        image, Gimp.ChannelOps.REPLACE, x, y, frame_dim, frame_dim
    )

    # Remove the center of the selection to create a ring-frame:
    y = x = center - flower_radius

    select_ellipse(
        image, Gimp.ChannelOps.SUBTRACT, x, y, flower_dim, flower_dim
    )

    if Flower.is_outline and Flower.line_w < frame_w / 2:
        # There's are two lines for the frame.
        w = Flower.line_w

        # smaller circle #1
        select_ellipse(
            image,
            Gimp.ChannelOps.SUBTRACT,
            x + w, y + w,
            flower_dim - w - w, flower_dim - w - w
        )

        selection = image.get_selection()

        selection.save(image)

        y = x = center - flower_radius

        # larger circle
        select_ellipse(
            image,
            Gimp.ChannelOps.REPLACE,
            x - w, y - w,
            flower_dim + w + w, flower_dim + w + w
        )

        # smaller circle #2
        select_ellipse(
            image,
            Gimp.ChannelOps.SUBTRACT,
            x, y,
            flower_dim, flower_dim
        )

        # Combine line selections.
        for i in image.get_channels():
            image.select_item(Gimp.ChannelOps.ADD, i)
            image.remove_channel(i)

    fill_selection(layer, color)
    return image.merge_down(layer, Gimp.MergeType.CLIP_TO_IMAGE)


def draw_gradient(image, center, base_layer):
    """
    Create a radial gradient to overlay the flower composite.

    image: Gimp.Image
        Receive ring.

    center: int
        Is the center of the flower image.

    base_layer: Gimp.Layer
        Limit the gradient influence.
    """
    layer = add_layer(image, layer_name="Gradient")
    center = float(center)
    procedure = Gimp.get_pdb().lookup_procedure('gimp-gradient-new')
    config = procedure.create_config()
    config.set_property('name', "flower")
    result = procedure.run(config)
    gradient = result.index(1)

    # perimeter
    color = Gegl.Color.new('#000000FF')

    gradient.segment_set_right_color(0, color)

    # center:
    color = Gegl.Color.new('#FFFFFFFF')

    gradient.segment_set_left_color(0, color)
    Gimp.context_set_gradient(gradient)
    Gimp.Selection.none(image)

    # alternate method: Gimp.Drawable.edit_bucket_fill
    procedure = Gimp.get_pdb().lookup_procedure(
        'gimp-drawable-edit-gradient-fill'
    )
    config = procedure.create_config()

    for q in (
        ('drawable', layer),
        ('gradient-type', Gimp.GradientType.RADIAL),
        ('offset', 0),
        ('supersample', True),
        ('supersample-max-depth', 3),
        ('supersample-threshold', 0),
        ('dither', True),
        ('x1', center),
        ('y1', center),
        ('x2', center),
        ('y2', 2)
    ):
        config.set_property(*q)

    result = procedure.run(config)

    # Remove the resource.
    gradient.delete()

    image.select_item(Gimp.ChannelOps.REPLACE, base_layer)

    selection = image.get_selection()

    selection.invert(image)
    layer.edit_clear()
    layer.set_mode(Gimp.LayerMode.OVERLAY)


def fill_layer(image, layer, color):
    """
    Fill a layer with a color.

    image: Gimp.Image
        Has layer.

    layer: Gimp.Layer
        Receive color.

    color: string
        for the fill op
    """
    color = Gegl.Color.new(color)

    Gimp.Selection.none(image)
    Gimp.context_set_foreground(color)
    layer.edit_fill(Gimp.FillType.FOREGROUND)


def fill_selection(layer, color):
    """
    Fills a selection with a color.

    layer : drawable
        layer with selection

    color : Gegl.Color
        color of the circle
    """
    opacity = color.get_rgba().alpha * 100

    Gimp.context_set_foreground(color)
    Gimp.context_set_opacity(opacity)
    layer.edit_fill(Gimp.FillType.FOREGROUND)


def get_point_on_circle(x, y, angle, radius):
    """
    Return a point on the circle that corresponds to a rotation angle.

    x, y: int
        center of the circle

    angle : float
        the rotation angle

    radius : float
        the radius of the circle

    Returns:
        (x, y) of float
        the point on the circle
    """
    return (sin(angle) * radius) + x, (cos(angle) * -radius) + y


def select_ellipse(image, op, x, y, w, h):
    """
    Select an ellipse.

    image: GIMP image
        Receive selection.

    op: Gimp.ChannelOps
        ADD, REPLACE, SUBTRACT or INTERSECT

    x, y: int
        topleft point of the selection

    w, h: int
        size of the selection

    Return: Gimp.PDBStatusType enum
        success state
    """
    procedure = Gimp.get_pdb().lookup_procedure('gimp-image-select-ellipse')
    config = procedure.create_config()

    for q in (
        ('image', image),
        ('operation', op),
        ('x', x),
        ('y', y),
        ('width', w),
        ('height', h)
    ):
        config.set_property(*q)

    result = procedure.run(config)

    if Flower.is_outline:
        # Cut-out the center of the circle to form an outline.
        w1 = Flower.line_w
        for q in (
            ('operation', Gimp.ChannelOps.SUBTRACT),
            ('x', x + w1),
            ('y', y + w1),
            ('width', w - w1 - w1),
            ('height', h - w1 - w1)
        ):
            config.set_property(*q)
        result = procedure.run(config)

    if Flower.is_save:
        selection = image.get_selection()
        selection.save(image)
    return result.index(0)
