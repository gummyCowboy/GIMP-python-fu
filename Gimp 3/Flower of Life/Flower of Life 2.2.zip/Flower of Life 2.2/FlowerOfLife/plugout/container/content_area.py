#!/usr/bin/env python3
from plugout.container.container import Container


class ContentArea(Container):
    """
    Wrap a 'Gtk.Box' which is a 'Gtk.Dialog's content area.
    This object is a typical starting Container, a pot,
    for an AnyGroup definition tree.
    """

    def __init__(self, box):
        """
        box: Gtk.Box
            Place Widget inside.
        """
        # empty definition dict, '{}'
        super().__init__({}, box)
