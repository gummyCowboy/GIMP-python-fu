#!/usr/bin/env python3
from plugout.define.key import TEXT
from plugout.widget.label import Label

"""Include customize Label class for handling custom signal."""


class LabelColorArray(Label):

    def __init__(self, def_d):
        super().__init__(def_d)

    def on_custom_signal(self, _, arg):
        """
        Override the Widget function and change visibility.

        _: WindowMain
        arg: tuple
            (signal, Widget instance, Widget value)
        """
        widget, value = arg[1:]
        if widget.key == 'color_type':
            # 'value' is an index. Black is RadioButton, '1'.
            if value == 1:
                self.widget.hide()
            else:
                self.widget.show()


class LabelImageSize(Label):

    def __init__(self, def_d):
        """
        def_d: dict
            LabelImageSize definition
                text: string
                    Is format-able string with two curly brackets.
        """
        self._text = def_d.get(TEXT, "{} x {}")
        self._radius = self._frame_width = 0.
        super().__init__(def_d)

    def on_custom_signal(self, _, arg):
        """
        Override the Widget function and change visibility.

        _: WindowMain
        arg: tuple
            (signal, Widget instance, Widget value)
        """
        widget, value = arg[1:]

        if widget.key == 'frame_width':
            self._frame_width = value

        elif widget.key == 'radius':
            self._radius = value

        f = int(self._radius * 2 + self._frame_width * 2)
        self.widget.set_text(self._text.format(f, f))


class LabelLineWidth(Label):

    def __init__(self, def_d):
        super().__init__(def_d)

    def on_custom_signal(self, _, arg):
        """
        Override the Widget function and change visibility.

        _: WindowMain
        arg: tuple
            (signal, Widget instance, Widget value)
        """
        widget, value = arg[1:]
        if widget.key == 'flower_type':
            # 'value' is an index. Black is RadioButton, '1'.
            if value == 1:
                self.widget.show()
            else:
                self.widget.hide()
