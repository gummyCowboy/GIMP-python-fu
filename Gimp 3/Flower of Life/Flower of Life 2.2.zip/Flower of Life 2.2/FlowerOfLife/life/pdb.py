#!/usr/bin/env python3
import gi                              # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp         # noqa

"""
Include a function to initialize static pdb
run class, and static pdb run class.

The static class' config object is reused. So configuring a
pdb procedure has an additional dynamic in that the previous
call to 'class.do' can be repeated, but without the configuration
settings.
"""


def init_pdb():
    """Implement a get-once strategy for Gimp's pdb interface. """
    for q in (
        (EllipseSelect, 'gimp-image-select-ellipse'),
        (GradientFill, 'gimp-drawable-edit-gradient-fill'),
        (GradientNew, 'gimp-gradient-new')
    ):
        a, s = q
        a.pdb = Gimp.get_pdb().lookup_procedure(s)
        a.config = a.pdb.create_config()


class GradientFill:
    pdb = config = None

    def do(q):
        """
        q: tuple
            Configure the procedure.
            (
                ('drawable', Gimp.Drawable),
                ('gradient-type', Gimp.GradientType),
                ('offset', float),
                ('supersample', True),
                ('supersample-max-depth', int),
                ('supersample-threshold', float),
                ('dither', True),
                ('x1', float),
                ('y1', float),
                ('x2', float),
                ('y2', float)
            )
        """
        for q1 in q:
            GradientFill.config.set_property(*q1)
        GradientFill.pdb.run(GradientFill.config)


class GradientNew:
    pdb = config = None

    def do(s):
        """
        s: string
            Give the new gradient a name.
        """
        GradientNew.config.set_property('name', s)
        return GradientNew.pdb.run(GradientNew.config)


class EllipseSelect:
    pdb = config = None

    def do(q):
        """
        q: tuple
            Configure the procedure.
            (
                ('image', Gimp.Image),
                ('operation', Gimp.ChannelOps),
                ('x', float),
                ('y', float),
                ('width', float),
                ('height', float)
            )
        """
        for q1 in q:
            EllipseSelect.config.set_property(*q1)
        EllipseSelect.pdb.run(EllipseSelect.config)
