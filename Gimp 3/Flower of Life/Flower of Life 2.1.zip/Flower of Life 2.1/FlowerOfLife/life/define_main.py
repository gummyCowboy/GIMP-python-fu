#!/usr/bin/env python3
from life.constant import (
    BLACK, COLOR_ARRAY,
    COLOR_ARRAY_TEXT, COLOR_ARRAY_VALUE,
    COLOR_TYPE, COLOR_TYPE_CHANGE,
    FLOWER, FLOWER_TYPE, FLOWER_TYPE_CHANGE,
    FRAME_WIDTH, IMAGE_SIZE_CHANGE, LINE_WIDTH,
    OUTLINE, RADIUS, RANDOM, TWO_COLOR
)
from life.container_button_random import HBoxButtonRandom
from life.widget.color_button_array import ColorButtonArray
from life.widget.button_random import RandomColorArrayButton, TwoColorButton
from life.widget.label_custom import (
    LabelColorArray, LabelImageSize, LabelLineWidth
)
from life.widget.spin_button_custom import SpinButtonLineWidth
from plugout.constant import MANAGE, SAVE_
from plugout.container.box import HBox
from plugout.container.grid import Grid, GridCell, GridRow
from plugout.define.key import (
    ADJUSTMENT, CHILD, COLUMN,
    COLUMNS, CUSTOM_SIGNAL, EMIT_SIGNAL,
    HALIGN, LIMIT, PADDING, PRESET,
    RANDOMER, TEXT, TYPE, VALUE, WIDTH
)
from plugout.widget.button_preset import ButtonManage, ButtonSave
from plugout.widget.h_sep import HSeparator
from plugout.widget.label import Label, LabelPreset
from plugout.widget.radio import RadioGroup
from plugout.widget.spinbutton import SpinButton
import gi                            # type: ignore
gi.require_version('Gdk', '3.0')
from gi.repository import Gtk        # noqa

"""Define DialogMain's AnyGroup definition dict."""

# Color Array__________________________________________________________________
COLOR_ARRAY_LABEL = {
    CUSTOM_SIGNAL: (COLOR_TYPE_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: COLOR_ARRAY,
    TYPE: LabelColorArray
}
COLOR_BUTTON_ARRAY = {
    CUSTOM_SIGNAL: (COLOR_TYPE_CHANGE,),
    LIMIT: True,
    TEXT: COLOR_ARRAY_TEXT,
    TYPE: ColorButtonArray,
    VALUE: COLOR_ARRAY_VALUE
}
GRID_CELL_COLOR_ARRAY_0 = {
    CHILD: {'color_array_label': COLOR_ARRAY_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_COLOR_ARRAY_1 = {
    CHILD: {'color_button_array': COLOR_BUTTON_ARRAY},
    COLUMN: 1,
    TYPE: GridCell,
    WIDTH: 3,
}
GRID_ROW_COLOR_ARRAY = {
    CHILD: {1: GRID_CELL_COLOR_ARRAY_0, 2: GRID_CELL_COLOR_ARRAY_1},
    COLUMNS: 2,
    TYPE: GridRow
}

# Color Type___________________________________________________________________
COLOR_TYPE_LABEL = {HALIGN: Gtk.Align.START, TEXT: COLOR_TYPE, TYPE: Label}
COLOR_TYPE_RADIO = {
    EMIT_SIGNAL: COLOR_TYPE_CHANGE,
    TEXT: (COLOR_ARRAY, BLACK),
    TYPE: RadioGroup,
    VALUE: 0
}
GRID_CELL_COLOR_TYPE_0 = {
    CHILD: {'color_type_label': COLOR_TYPE_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_COLOR_TYPE_1 = {
    CHILD: {'color_type': COLOR_TYPE_RADIO},
    COLUMN: 1,
    TYPE: GridCell,
    WIDTH: 2
}
GRID_ROW_COLOR_TYPE = {
    CHILD: {1: GRID_CELL_COLOR_TYPE_0, 2: GRID_CELL_COLOR_TYPE_1},
    COLUMNS: 2,
    TYPE: GridRow
}

# Flower Type__________________________________________________________________
FLOWER_TYPE_LABEL = {HALIGN: Gtk.Align.START, TEXT: FLOWER_TYPE, TYPE: Label}
FLOWER_TYPE_RADIO = {
    EMIT_SIGNAL: FLOWER_TYPE_CHANGE,
    TEXT: (FLOWER, OUTLINE),
    TYPE: RadioGroup,
    VALUE: 0
}
GRID_CELL_FLOWER_TYPE_0 = {
    CHILD: {'flower_type_label': FLOWER_TYPE_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_FLOWER_TYPE_1 = {
    CHILD: {'flower_type': FLOWER_TYPE_RADIO},
    COLUMN: 1,
    TYPE: GridCell,
    WIDTH: 2
}
GRID_ROW_FLOWER_TYPE = {
    CHILD: {1: GRID_CELL_FLOWER_TYPE_0, 2: GRID_CELL_FLOWER_TYPE_1},
    COLUMNS: 3,
    TYPE: GridRow
}

# Frame Width__________________________________________________________________
FRAME_WIDTH_LABEL = {HALIGN: Gtk.Align.START, TEXT: FRAME_WIDTH, TYPE: Label}
FRAME_WIDTH_SPIN_BUTTON = {
    ADJUSTMENT: (0., 0., 9999., 1., 10., 0.),
    EMIT_SIGNAL: IMAGE_SIZE_CHANGE,
    TYPE: SpinButton,
    VALUE: 0.
}
GRID_CELL_FRAME_WIDTH_0 = {
    CHILD: {'frame_width_label': FRAME_WIDTH_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_FRAME_WIDTH_1 = {
    CHILD: {'frame_width': FRAME_WIDTH_SPIN_BUTTON}, COLUMN: 1, TYPE: GridCell
}
GRID_ROW_FRAME_WIDTH = {
    CHILD: {1: GRID_CELL_FRAME_WIDTH_0, 2: GRID_CELL_FRAME_WIDTH_1},
    COLUMNS: 2,
    TYPE: GridRow
}

# Line Width___________________________________________________________________
LINE_WIDTH_SPIN_BUTTON = {
    ADJUSTMENT: (0., 1., 9999., 1., 10., 0.),
    CUSTOM_SIGNAL: (FLOWER_TYPE_CHANGE,),
    TYPE: SpinButtonLineWidth,
    VALUE: 5.
}
LINE_WIDTH_LABEL = {
    CUSTOM_SIGNAL: (FLOWER_TYPE_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: LINE_WIDTH,
    TYPE: LabelLineWidth
}
GRID_CELL_LINE_WIDTH_0 = {
    CHILD: {'line_width_label': LINE_WIDTH_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_LINE_WIDTH_1 = {
    CHILD: {'line_width': LINE_WIDTH_SPIN_BUTTON}, COLUMN: 1, TYPE: GridCell
}
GRID_ROW_LINE_WIDTH = {
    CHILD: {1: GRID_CELL_LINE_WIDTH_0, 2: GRID_CELL_LINE_WIDTH_1},
    COLUMNS: 2,
    TYPE: GridRow
}

# Preset_______________________________________________________________________
PRESET_LABEL = {HALIGN: Gtk.Align.START, TYPE: LabelPreset}
MANAGE_BUTTON = {TEXT: MANAGE, TYPE: ButtonManage}
SAVE_BUTTON = {PADDING: (0, 0, 0, 4), TEXT: SAVE_, TYPE: ButtonSave}
HBOX_PRESET_BUTTON = {
    CHILD: {
        'save_button': SAVE_BUTTON,
        'manage_button': MANAGE_BUTTON
    },
    TYPE: HBox
}
GRID_CELL_PRESET_0 = {
    CHILD: {'preset_label': PRESET_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_PRESET_1 = {
    CHILD: {1: HBOX_PRESET_BUTTON},
    COLUMN: 1,
    WIDTH: 2,
    TYPE: GridCell
}
GRID_ROW_PRESET = {
    CHILD: {1: GRID_CELL_PRESET_0, 2: GRID_CELL_PRESET_1},
    COLUMNS: 2,
    TYPE: GridRow
}

# Radius_______________________________________________________________________
IMAGE_SIZE_LABEL = {
    CUSTOM_SIGNAL: (IMAGE_SIZE_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: "Image Size: {} x {}",
    TYPE: LabelImageSize
}
RADIUS_SPIN_BUTTON = {
    ADJUSTMENT: (0., 12., 9999., 1., 10., 0.),
    EMIT_SIGNAL: IMAGE_SIZE_CHANGE,
    TYPE: SpinButton,
    VALUE: 200.
}
RADIUS_LABEL = {HALIGN: Gtk.Align.START, TEXT: RADIUS, TYPE: Label}
GRID_CELL_RADIUS_0 = {
    CHILD: {'radius_label': RADIUS_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_RADIUS_1 = {
    CHILD: {'radius': RADIUS_SPIN_BUTTON}, COLUMN: 1, TYPE: GridCell
}
GRID_CELL_RADIUS_2 = {
    CHILD: {'image_size_label': IMAGE_SIZE_LABEL}, COLUMN: 2, TYPE: GridCell
}
GRID_ROW_RADIUS = {
    CHILD: {
        1: GRID_CELL_RADIUS_0, 2: GRID_CELL_RADIUS_1, 3: GRID_CELL_RADIUS_2
    },
    COLUMNS: 3,
    TYPE: GridRow
}

# Randomer_____________________________________________________________________
RANDOM_COLOR_ARRAY_BUTTON = {TEXT: RANDOM, TYPE: RandomColorArrayButton}
TWO_COLOR_BUTTON = {
    PADDING: (0, 0, 0, 6), TEXT: TWO_COLOR, TYPE: TwoColorButton
}
RANDOMER_CELL_1_HBOX = {
    CHILD: {1: TWO_COLOR_BUTTON, 2: RANDOM_COLOR_ARRAY_BUTTON},
    CUSTOM_SIGNAL: (COLOR_TYPE_CHANGE,),
    TYPE: HBoxButtonRandom
}
GRID_CELL_RANDOMER_1 = {
    CHILD: {'1': RANDOMER_CELL_1_HBOX}, COLUMN: 1, TYPE: GridCell
}
GRID_ROW_RANDOMER = {
    CHILD: {1: GRID_CELL_RANDOMER_1}, COLUMNS: 2, TYPE: GridRow
}

# Separator____________________________________________________________________
HSEPARATOR = {PADDING: (4, 4, 0, 0), TYPE: HSeparator}
GRID_CELL_HSEPARATOR_0 = {
    CHILD: {'separator': HSEPARATOR}, COLUMN: 0, WIDTH: 2, TYPE: GridCell
}
GRID_ROW_SEPARATOR = {
    CHILD: {1: GRID_CELL_HSEPARATOR_0}, COLUMNS: 2, TYPE: GridRow
}

# AnyGroup definition dict, 'MAIN'_____________________________________________
# AnyGroup definition: {key: definition}
DEFINE_MAIN = {
    'main': {
        CHILD: {
            1: GRID_ROW_RADIUS,
            2: GRID_ROW_FRAME_WIDTH,
            3: GRID_ROW_LINE_WIDTH,
            4: GRID_ROW_FLOWER_TYPE,
            5: GRID_ROW_COLOR_TYPE,
            6: GRID_ROW_COLOR_ARRAY,
            7: GRID_ROW_RANDOMER,
            8: GRID_ROW_SEPARATOR,
            9: GRID_ROW_PRESET
        },

        # This Container is a preset with no key, 'PRESET: None'.
        PRESET: None,

        RANDOMER: True,
        TYPE: Grid
    }
}
