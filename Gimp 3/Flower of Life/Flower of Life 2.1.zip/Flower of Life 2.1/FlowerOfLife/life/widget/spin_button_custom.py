#!/usr/bin/env python3
from plugout.widget.spinbutton import SpinButton

"""Include customize SpinButton class for handling custom signal."""


class SpinButtonLineWidth(SpinButton):

    def __init__(self, def_d):
        super().__init__(def_d)

    def on_custom_signal(self, _, arg):
        """
        Override the Widget function and change visibility.

        _: DialogMain
        arg: tuple
            (signal, Widget instance, Widget value)
        """
        widget, value = arg[1:]
        if widget.key == 'flower_type':
            # 'value' is an index. Black is RadioButton, '1'.
            if value == 1:
                self.widget.show()
            else:
                self.widget.hide()
