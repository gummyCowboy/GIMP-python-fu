#!/usr/bin/env python3
import gi       # type: ignore

gi.require_version('Gdk', '3.0')
gi.require_version('Gtk', '3.0')

from gi.repository import Gdk, GimpUi, Gtk
from flower_output import create_preview, _
from random import uniform
import sys

# ColorButton insight
COLOR_TOOLTIP = _(" Red\t{} \n Green\t{} \n Blue\t{} \n Alpha\t{}")

# Identify ColorButton in the UI.
FIRST_ROW_COLOR = (
    "Center",
    "Ring 1",
    "Ring 2",
    "Ring 3",
    "Ring 4",
    "Ring 5",
    "Ring 6",
    "Frame"
)

# Init dialog or load default value with this read-only dict.
# {widget key: widget init value}
DEFAULT_VALUE_D = {
    'color_d': {
        'Center': Gdk.RGBA(red=1., green=1., blue=1., alpha=1.),
        'Ring 1': Gdk.RGBA(red=.2, green=.7, blue=1., alpha=1.),
        'Ring 2': Gdk.RGBA(red=.5, green=.6, blue=.3, alpha=1.),
        'Ring 3': Gdk.RGBA(red=.4, green=.3, blue=.3, alpha=1.),
        'Ring 4': Gdk.RGBA(red=.2, green=.7, blue=.6, alpha=1.),
        'Ring 5': Gdk.RGBA(red=.8, green=.2, blue=.1, alpha=1.),
        'Ring 6': Gdk.RGBA(red=.1, green=.8, blue=.1, alpha=1.),
        'Frame': Gdk.RGBA(red=.0, green=.0, blue=.0, alpha=1.)
    },
    'color_type': 0,
    'flower_type': 0,
    'frame_w': 0,
    'line_w': 8,
    'radius': 200
}

# Preview button id
RESPONSE_PREVIEW = -99

# Button response in dialog.
response_d = {
    RESPONSE_PREVIEW: None,
    Gtk.ResponseType.CANCEL: None,
    Gtk.ResponseType.DELETE_EVENT: None,
    Gtk.ResponseType.OK: None
}

# Gtk.Grid row index for widget placement
RADIUS_INDEX, FRAME_W_INDEX, LINE_W_INDEX, FLORAL_TYPE_INDEX, \
    COLOR_TYPE_INDEX, COLOR_BUTTON_INDEX, CONFIG_BUTTON_INDEX = range(7)


def add_color_button_array(grid, d):
    """
    Add Gtk.ColorButton options to a Gtk.Grid.

    grid: Gtk.Grid
        Receive ColorButton.

    d: dict
        {widget key: widget}
        Store each widget for value retrieval.
    """
    # Remember the label as it changes visibility.
    d['label'] = add_grid_label(grid, COLOR_BUTTON_INDEX, _("Color Array"))

    # container for ColorButton first row, 'hbox'
    hbox = d['hbox'] = Gtk.Box(spacing=6)

    # Create the row.
    for x in range(8):
        vbox = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            homogeneous=False,
            spacing=1
        )
        k = FIRST_ROW_COLOR[x]
        label = create_label(_(k), x_align=.5)

        vbox.add(label)

        g = d[k] = Gtk.ColorButton.new_with_rgba(
            Gdk.RGBA(red=1., green=1., blue=1., alpha=1.)
        )

        # Add the alpha scale to the chooser dialog.
        Gtk.ColorChooser.set_use_alpha(g, True)

        g.connect('color-set', on_color_set)
        vbox.add(g)
        hbox.add(vbox)

    # column, '1'; cell width, '1'; cell height, '1'
    grid.attach(hbox, 1, COLOR_BUTTON_INDEX, 1, 1)


def add_frame_width_spinner(grid):
    """
    Add a frame Width SpinButton to a Gtk.Grid.

    grid: Gtk.Grid
        Receive SpinButton.

    Return: Gtk.SpinButton
        newly created
    """
    add_grid_label(grid, FRAME_W_INDEX, _("Frame Width"))

    # init value, lower limit, upper limit, step inc, page inc, page size
    return add_grid_spin(grid, FRAME_W_INDEX, (0., 0., 9999., 1., 10., 0.))


def add_grid(vbox):
    """
    Add a Gtk.Grid to a Gtk.VBox.

    Return: Gtk.Grid
        newly created
    """
    grid = Gtk.Grid()

    grid.set_column_homogeneous(False)
    grid.set_border_width(12)
    grid.set_column_spacing(12)
    grid.set_row_spacing(6)
    vbox.add(grid)
    return grid


def add_grid_label(grid, row, text):
    """
    Given a Gtk.Grid, add a Gtk.Label to its first column.

    grid: Gtk.Grid
        Receive Label.

    row: int
        0 to n
        Identify Grid row.

    text: string
        Is the Label's displayed text.

    Return: Gtk.Label
        newly created
    """
    """ Create a label and set it in first column of a grid. """
    label = create_label(text)

    # column, '0'; cell width, '1'; cell height, '1'
    grid.attach(label, 0, row, 1, 1)

    return label


def add_grid_spin(grid, row, adj_arg):
    """
    Add a SpinButton to a Grid. Place the button in the second column.

    grid: Gtk.Grid
        Receive the SpinButton in column 1.

    row: int
        0 to n
        Is the row index in the Grid where the SpinButton is placed.

    adj_arg: tuple
        Is given to a Gtk.Adjustment during its init call.

    Return: Gtk.SpinButton
        newly created
    """
    spin = Gtk.SpinButton.new(
        Gtk.Adjustment.new(*adj_arg), climb_rate=.1, digits=0
    )

    spin.set_numeric(True)
    spin.set_snap_to_ticks(True)
    spin.set_max_length(4)
    spin.set_width_chars(4)

    # column, '1'; cell width, '1'; cell height, '1'
    grid.attach(spin, 1, row, 1, 1)
    return spin


def add_hint_box(vbox):
    """
    Place GIMP's hint box on top of the dialog.

    vbox: Gtk.Box
        Has vertical packing to receive HintBox.
    """
    vbox.pack_start(
        GimpUi.HintBox.new(_("Create a Flower of Life image.")),
        False,                  # expand
        False,                  # fill
        0                       # padding
    )


def add_line_width_spinner(grid):
    """
    Add an Line Width SpinButton to a Gtk.Grid.

    grid: Gtk.Grid
        Receive SpinButton.

    Return: tuple
        (Gtk.Label, Gtk.SpinButton)
        newly created
    """
    label = add_grid_label(grid, LINE_W_INDEX, _("Line Width"))

    # Init value, lower limit, upper limit, step inc, page inc, page size
    return label, add_grid_spin(
        grid, LINE_W_INDEX, (0., 0., 9999., 1., 10., 0.)
    )


def add_radius_spinner(grid):
    """
    Add a Flower Radius SpinButton to a Gtk.Grid.

    grid: Gtk.Grid
        Receive SpinButton.

    Return: Gtk.SpinButton
        newly created
    """
    add_grid_label(grid, RADIUS_INDEX, _("Flower Radius"))

    # Init value, lower limit, upper limit, step inc, page inc, page size
    return add_grid_spin(grid, RADIUS_INDEX, (0., 12., 9999., 1., 10., 0.))


def create_label(text, x_align=.0):
    """
    Make a Gtk.Label.

    text: string
        Assign to the label.

    x_align: float
        .0 to 1.
        Horizontally position the label.
    """
    label = Gtk.Label(label=text)

    label.set_xalign(x_align)
    label.set_yalign(.5)
    return label


def on_color_set(color_button):
    """
    A ColorButton changed value, so its tooltip needs updating.

    color_button: Gtk.ColorButton
        Has a new value.
    """
    color = color_button.get_rgba()
    color_button.set_tooltip_text(
        COLOR_TOOLTIP.format(
            int(color.red * 255),
            int(color.green * 255),
            int(color.blue * 255),
            int(color.alpha * 255)
        )
    )


class Dialog:
    """Create a GimpUI.Dialog having Cancel, Preview, and Accept buttons."""

    def __init__(self, add_widget_p, response_p, d):
        """
        add_widget_p: function
            Call to add widget to the Dialog's VBox.

        response_p: function
            Call to handle Cancel, Preview, and Accept button action.

        d: dict
            {widget key: widget instance}
        """
        self.dialog = GimpUi.Dialog(
            use_header_bar=Gtk.Settings.get_default().
            get_property("gtk-dialogs-use-header"),
            title="Flower of Life 2"
        )
        vbox = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            homogeneous=False,
            spacing=10
        )

        self.dialog.get_content_area().add(vbox)
        self.dialog.add_button(_("_Cancel"), Gtk.ResponseType.CANCEL)
        self.dialog.add_button(_("Preview"), RESPONSE_PREVIEW)
        self.dialog.add_button(_("_Accept"), Gtk.ResponseType.OK)

        # Add additional widget.
        add_widget_p(vbox)

        # Render dialog.
        vbox.show_all()
        self.dialog.show()

        # Hide Line Width widget.
        for g in d['line_w']:
            g.hide()

        # Map button responses to callback.
        self.dialog.connect('response', response_p)

        # Start event loop.
        Gtk.main()


class FlowerDialog:
    """
    Create a GimpUI.Dialog for user interaction and define output settings.
    """

    def __init__(self):
        """Open a dialog. Respond to user interaction."""
        # {option key: widget}
        # Use to store Color Array widget.
        self.color_d = {}

        # {option key: widget}
        # Use to set default and get option value.
        self.widget_d = {'color_d': self.color_d}

        # Capture dialog settings for determining
        # a boolean change state between Preview actions.
        # {widget key: widget value}
        self.preview_d = {}

        # Init UI theme.
        GimpUi.init(sys.argv[0])

        response_d[Gtk.ResponseType.CANCEL] = \
            response_d[Gtk.ResponseType.DELETE_EVENT] = self.on_cancel
        response_d[Gtk.ResponseType.OK] = self.on_accept
        response_d[RESPONSE_PREVIEW] = self.on_preview
        Dialog(self.add_dialog_widget, self.on_dialog_button, self.widget_d)

    def add_color_type(self):
        """
        Add Color Type options to a Gtk.Grid.

        Return: tuple
            (Gtk.RadioButton, Gtk.RadioButton)
            (color option, black and white option)
            newly created
        """
        add_grid_label(self.grid, COLOR_TYPE_INDEX, _("Color Type"))

        # container for RadioButton, 'hbox'
        hbox = Gtk.Box(spacing=1)

        button = Gtk.RadioButton.new_with_label_from_widget(
            None, _("Color Array")
        )
        button1 = Gtk.RadioButton.new_with_label_from_widget(
            button, _("Black")
        )

        # Expand and fill, 'True'; zero padding, '0'.
        hbox.pack_start(button, True, True, 0)
        hbox.pack_start(button1, True, True, 0)

        # column, '1'; cell width, '1'; cell height, '1'
        self.grid.attach(hbox, 1, COLOR_TYPE_INDEX, 1, 1)

        button.connect('toggled', self.on_color_type)
        return button, button1

    def add_config_button(self, grid):
        """
        Add an HBox with three buttons for modifying the Color Array.

        grid: Gtk.Grid
            Receive HBox with buttons.
        """
        hbox = Gtk.Box(spacing=1, homogeneous=True)
        default_button = Gtk.Button.new_with_label("Default")
        align_left = Gtk.Alignment()

        align_left.set_padding(0, 0, 0, 4)
        default_button.connect('clicked', self.load_default)
        align_left.add(default_button)
        hbox.pack_start(align_left, True, True, 0)

        button = Gtk.Button.new_with_label("Two Color")

        button.connect('clicked', self.on_two_color)
        hbox.pack_start(button, True, True, 0)

        random_button = Gtk.Button.new_with_label("Randomize")
        align_right = Gtk.Alignment()

        align_right.set_padding(0, 0, 4, 0)
        random_button.connect('clicked', self.randomize)
        align_right.add(random_button)
        hbox.pack_start(align_right, True, True, 0)

        # column, '1'; cell width, '1'; cell height, '1'
        grid.attach(hbox, 1, CONFIG_BUTTON_INDEX, 1, 1)

    def add_dialog_widget(self, vbox):
        """
        Add Flower of Life widget to the Dialog's VBox.

        vbox: Gtk.Box
            Has vertical packing.
        """
        add_hint_box(vbox)

        self.grid = add_grid(vbox)
        d = self.widget_d

        # Flower Radius SpinButton, 'radius'
        d['radius'] = add_radius_spinner(self.grid)

        d['frame_w'] = add_frame_width_spinner(self.grid)
        d['line_w'] = add_line_width_spinner(self.grid)

        # Flower Type button tuple, (Flower, Petal buttons)
        d['flower_type'] = self.add_flower_type()

        # Color Type button tuple, (Color RadioButton, Black RadioButton)
        d['color_type'] = self.add_color_type()

        # Make the RadioButtons all the same size.
        same_size = Gtk.SizeGroup(mode=Gtk.SizeGroupMode.BOTH)

        for g in d['flower_type'] + d['color_type']:
            same_size.add_widget(g)

        add_color_button_array(self.grid, self.color_d)
        self.add_config_button(self.grid)
        self.load_default()

    def add_flower_type(self):
        """
        Add flower type options to a Gtk.Grid.

        Return: tuple
            (Gtk.RadioButton, Gtk.RadioButton)
            (Petal option, Outline option)
            newly created
        """
        add_grid_label(self.grid, FLORAL_TYPE_INDEX, _("Flower Type"))

        # container for RadioButton, 'hbox'
        hbox = Gtk.Box(spacing=1)

        button = Gtk.RadioButton.new_with_label_from_widget(
            None, _("Petal")
        )
        button1 = Gtk.RadioButton.new_with_label_from_widget(
            button, _("Outline")
        )

        for g in (button, button1):
            g.connect('toggled', self.on_floral_type)

            # Expand or fill; zero padding, '0'
            hbox.pack_start(g, True, True, 0)

        # column, '1'; cell width, '1'; cell height, '1'
        self.grid.attach(hbox, 1, FLORAL_TYPE_INDEX, 1, 1)
        return button, button1

    def on_cancel(self):
        """Close the dialog. The user chose to cancel."""
        Gtk.main_quit()

    def gather_dialog_setting(self):
        """
        Load a dictionary with dialog widget value.

        Return: dict
            {widget key: widget value}
        """
        d = {}
        e = self.widget_d

        # SpinButton
        for k in ('radius', 'frame_w'):
            d[k] = int(e[k].get_value())

        # Line Width has a tuple value, (Label, Spinner).
        d['line_w'] = int(e['line_w'][1].get_value())

        # RadioButton; the first button index, '0'
        for k in ('color_type', 'flower_type'):
            d[k] = e[k][0].get_active()

        # color array
        q = DEFAULT_VALUE_D['color_d'].keys()

        # ordered color array RGBA value in float,
        # [(float, float, float, float), ...], 'q1'
        q1 = d['color_d'] = []

        for k, a in e['color_d'].items():
            # Is it a ColorButton?
            if k in q:
                a = a.get_rgba()
                q1 += [(a.red, a.green, a.blue, a.alpha)]
        return d

    def load_default(self, *_):
        """
        Load default value into dialog widget.

        _: Gtk.Button
            Default
            not used
        """
        d = self.widget_d
        e = DEFAULT_VALUE_D
        d1 = d['color_d']
        d2 = e['color_d']

        d['radius'].set_value(e['radius'])
        d['frame_w'].set_value(e['frame_w'])

        # Label index, 0; SpinButton index, '1'
        d['line_w'][1].set_value(e['line_w'])

        # the first RadioButton index, '0'
        d['color_type'][0].set_active(1)
        d['flower_type'][0].set_active(1)

        # Set Color Array.
        for k in FIRST_ROW_COLOR:
            d1[k].set_rgba(d2[k])
            on_color_set(d1[k])

    def on_color_type(self, _):
        """
        If the Color Type option is Black, then the Color Array is hidden.

        _: Gtk.RadioButton
            Is responsible.
            not used
        """
        # Color Array's RadioButton index, '0'
        if bool(self.widget_d['color_type'][0].get_active()):
            self.show_color_array()
        else:
            # Access Color Array widget.
            d = self.widget_d['color_d']

            d['label'].hide()
            d['hbox'].hide()

    def on_dialog_button(self, dialog, response_id):
        """
        Handle a user initiated button action.

        dialog: GimpUI.Dialog
            Is the Flower of Life dialog.

        response_id: Gtk.ResponseType
            Identify button.
        """
        p = response_d.get(response_id)
        if p is not None:
            p()

    def on_floral_type(self, button):
        """
        Respond to a flower type action. If the flower type is
        'Petal' then hide Line Width widget.

        button: Gtk.RadioButton
            Is responsible.
        """
        q = self.widget_d['line_w']

        if button is self.widget_d['flower_type'][0]:
            for g in q:
                g.hide()
        else:
            for g in q:
                g.show()

    def on_accept(self):
        """
        Respond to an Accept button action. Create a flower-of-life image.
        """
        d = self.gather_dialog_setting()

        if d != self.preview_d:
            create_preview(d)
        Gtk.main_quit()

    def on_preview(self):
        """
        Respond to a Preview button action by performing a preview but
        only if things have changed since the last preview.
        """
        d = self.gather_dialog_setting()

        if self.preview_d != d:
            create_preview(d)
        self.preview_d = d

    def on_two_color(self, _):
        """
        Randomize Color Array ColorButton value.

        _: Gtk.Button
            Black and White
            not used
        """
        self.widget_d['color_type'][0].set_active(1)
        self.show_color_array()

        d = self.widget_d['color_d']

        # color index, 'i'
        i = 0

        colors = (
            [uniform(.0, 1.) for i in range(3)],
            [uniform(.0, 1.) for i in range(3)]
        )

        # Set Color Array.
        for k in FIRST_ROW_COLOR:
            # RGB component count, '3'; color range, '.0, 1.'
            q = colors[i]

            # Flip index.
            i = 0 if i else 1

            # opaque, '1.'
            d[k].set_rgba(
                Gdk.RGBA(red=q[0], green=q[1], blue=q[2], alpha=1.)
            )
            on_color_set(d[k])

    def randomize(self, _):
        """
        Randomize Color Array ColorButton value.

        _: Gtk.Button
            Randomize
            not used
        """
        self.show_color_array()
        self.widget_d['color_type'][0].set_active(1)

        d = self.widget_d['color_d']

        # Set Color Array.
        for k in FIRST_ROW_COLOR:
            # RGB component count, '3'; color range, '.0, 1.'
            q = [uniform(.0, 1.) for i in range(3)]

            # opaque, '1.'
            d[k].set_rgba(
                Gdk.RGBA(red=q[0], green=q[1], blue=q[2], alpha=1.)
            )
            on_color_set(d[k])

    def show_color_array(self):
        """Make the color button array visible."""
        d = self.widget_d['color_d']

        d['label'].show()
        d['hbox'].show()
