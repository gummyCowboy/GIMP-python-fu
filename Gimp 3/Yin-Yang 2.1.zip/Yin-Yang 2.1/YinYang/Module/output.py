#!/usr/bin/env python3
from dataclasses import dataclass
from math import cos, degrees, radians, sin
from gi.repository import Gimp, Gegl, GLib   # type: ignore


# Each yin-yang division has a two flow (positive/negative).
@dataclass
class Flow:
    angle: float = None
    cut_point: list = None
    seg: tuple = None
    motion_center: tuple = None
    motion_square: tuple = None


def _(message):
    """
    Translate English to local language.

    message: string
        Translate.

    Return: string
        translated
    """
    return GLib.dgettext(None, message)


def add_layer(image, parent=None, position=0, layer_name="Base"):
    """
    Add a layer to an image.

    image: GIMP image
        Receive the layer.

    parent: group layer or None
        Put the layer in a group.

    position: int
        Is the offset from the top of the parent.

    layer_name: string
        Give the layer a name.

    Return: layer
        newly created
    """
    layer = Gimp.Layer.new(
        image,
        layer_name,
        image.get_width(),
        image.get_height(),
        Gimp.ImageType.RGBA_IMAGE,
        100,
        Gimp.LayerMode.NORMAL
    )

    image.insert_layer(layer, parent, position)
    return layer


def add_group_layer(image, parent=None, position=0, layer_name="Group"):
    """
    Add a group layer to an image.

    image: GIMP image
        Receive the layer.

    parent: layer group or None
        Specify another layer group to nest this layer group.

    position: int
        Is the offset from the top of the parent.

    layer_name: string
        Give the layer group a name.

    Return: group layer
        newly created
    """
    layer = Gimp.GroupLayer.new(image, layer_name)
    image.insert_layer(layer, parent, position)
    return layer


def color_selection(layer, color):
    """
    Fills a selection with a color.

    layer : Gimp.Drawable
        layer with selection

    color : Gegl.Color
        color of the circle
    """
    opacity = color.get_rgba().alpha * 100

    Gimp.context_set_foreground(color)
    Gimp.context_set_opacity(opacity)
    layer.edit_fill(Gimp.FillType.FOREGROUND)


def create_image(image_size):
    """
    Create a GIMP image.

    image_size: int
        Define the width and height of the image.

    Return: Gimp.Image, Gimp.Display
    """
    image = Gimp.Image.new(image_size, image_size, Gimp.ImageBaseType.RGB)
    return image, Gimp.Display.new(image)


def draw_gradient(layer, start_x, end_x, start_y, end_y):
    """
    Create a linear gradient to overlay the flower composite.

    layer: Gimp.Layer
        Receive Gimp.Gradient.

    start_x, start_y, end_x, end_y: float
        Define the gradient's line.

    return: GimpValueArray
        The result is in index one (e.g array.index(1))
    """
    # alternate method: Gimp.Drawable.edit_bucket_fill
    procedure = Gimp.get_pdb().lookup_procedure(
        'gimp-drawable-edit-gradient-fill'
    )
    config = procedure.create_config()

    for q in (
        ('drawable', layer),
        ('gradient-type', Gimp.GradientType.LINEAR),
        ('offset', 0),
        ('supersample', True),
        ('supersample-max-depth', 3),
        ('supersample-threshold', 0),
        ('dither', True),
        ('x1', start_x),
        ('y1', start_y),
        ('x2', end_x),
        ('y2', end_y)
    ):
        config.set_property(*q)
    return procedure.run(config)


def fill_layer_with_color(image, layer, color):
    """
    Fill a layer with a color.

    image: Gimp.Image
        Has layer.

    layer: Gimp.Layer
        Receive color.

    color: Gegl.Color
        for the fill op
    """
    color = Gegl.Color.new(color)

    Gimp.Selection.none(image)
    Gimp.context_set_foreground(color)
    layer.edit_fill(Gimp.FillType.FOREGROUND)


def fill_selection_with_color(layer, color):
    """
    Fill a selection with a color.

    layer : Gimp.Drawable
        Receive color.

    color : Gegl.Color
        fill color
    """
    Gimp.context_set_foreground(color)
    layer.edit_fill(Gimp.FillType.FOREGROUND)


def fill_selection_with_pattern(layer, pattern):
    """
    Fill a selection with a pattern.

    layer: Gimp.Drawable
        Receive the pattern.

    pattern: Gimp.Pattern
        for the fill op
    """
    Gimp.context_set_pattern(pattern)
    Gimp.context_set_opacity(100.)
    Gimp.context_set_paint_mode(Gimp.LayerMode.NORMAL)
    layer.edit_fill(Gimp.FillType.PATTERN)


def get_linear_gegl(color):
    """
    Create a Gegl.Color in linear color space.

    color: iterable
        RGBA
        [.0 to 1., ...]

    Return: Gegl.Color
    """
    return Gegl.Color.new("#{:02x}{:02x}{:02x}{:02x}".format(
        *map(int, [b * 255 for b in color])
    ))


def get_point_on_circle(x, y, angle, radius):
    """
    Return a point on the circle that corresponds to a rotation angle.

    x, y: int
        center of the circle

    angle : float
        the rotation angle

    radius : float
        the radius of the circle

    Returns:
        (x, y) of float
        the point on the circle
    """
    return (
        round((sin(angle) * radius) + x, 0),
        round((cos(angle) * -radius) + y, 0)
    )


def get_point_on_rect(angle, x, y, w, h):
    """
    Calculate an x, y coordinate for a point intersecting
    a ray, originating from the center of a rectangle,
    and ending at a rectangle boundary.

    angle: float
        radians
        angle from center of the rectangle

    x, y, w, h: numeric
        Define rectangle.

    Return: list
        [x, y] of float
        the point on the rectangle
    """
    sine = sin(angle)
    cosine = cos(angle)
    h1 = h / 2.
    w1 = w / 2.

    # distance to the top or the bottom edge (from the center), 'h2'
    h2 = h1 if sine > .0 else -h1

    # distance to the left or the right edge (from the center), 'w2'
    w2 = w1 if cosine > .0 else -w1

    # (distance to the vertical line) < (distance to the horizontal line)
    if abs(w2 * sine) < abs(h2 * cosine):
        # Calculate distance to the vertical line:
        h2 = (w2 * sine) / cosine

    # (distance to the top or the bottom edge)
    # < (distance to the left or the right edge)
    else:
        w2 = (h2 * cosine) / sine
    return [round(w2 + w1 + x, 0), round(h2 + h1 + y, 0)]


def select_ellipse(image, x, y, w, h, op=Gimp.ChannelOps.REPLACE):
    """
    Select an ellipse.

    image: GIMP image
        Receive selection.

    op: Gimp.ChannelOps
        ADD, REPLACE, SUBTRACT or INTERSECT

    x, y: float
        topleft point of the selection

    w, h: float
        size of the selection

    Return: Gimp.ValueArray
        Has success state at index one.
    """
    procedure = Gimp.get_pdb().lookup_procedure('gimp-image-select-ellipse')
    config = procedure.create_config()

    for q in (
        ('image', image),
        ('operation', op),
        ('x', x),
        ('y', y),
        ('width', w),
        ('height', h)
    ):
        config.set_property(*q)
    return procedure.run(config)


def select_polygon(image, seg, op=Gimp.ChannelOps.REPLACE):
    """
    Select a polygon.

    image: Gimp.Image
        Receive selection.

    seg: tuple
        (x, y, ...); a series of connected segment; float

    op: Gimp.ChannelOps
        ADD, REPLACE, SUBTRACT, INTERSECT
    """
    image.select_polygon(op, seg)


class Output:
    """Create Yin-Yang layer output."""

    def __init__(self):
        self._rim = \
            self._yin = \
            self._mode = \
            self._type = \
            self._yang = \
            self._eye_w = \
            self._image = \
            self._rim_w = \
            self._timer = \
            self._center = \
            self._radius = \
            self._ring_w = \
            self._display = \
            self._is_flip = \
            self._opacity = \
            self._is_anime = \
            self._is_blind = \
            self._division = \
            self._pattern_1 = \
            self._pattern_2 = \
            self._pattern_3 = \
            self._core_radius = \
            self._group_layer = \
            self._is_gradient = \
            self._symbol_rect = \
            self._motion_circle_radius = \
            self._motion_center_radius = None

        # dict; {Gimp.Channel id: Gimp.Channel}
        self._channel_d = None

        # dict; {flow index: flow dataclass}
        self._flow_d = None

    def _animate(self, base_layer):
        """Create animation layer for GIF and WEBP."""
        j = self._image
        timer = ("", " (" + str(self._timer) + "ms)")[self._frame > 1]
        circle = radians(360)
        half_circle = circle / 2
        rotation = angle = circle / self._frame * (1, -1)[self._is_flip]

        for i in range(self._frame - 1):
            dupe = base_layer.copy()

            # Insert layer at top of the root stack.
            j.insert_layer(dupe, None, 0)

            # Keep angle in GIMP rotation bounds.
            if angle > half_circle:
                angle = -circle + angle

            elif angle < -half_circle:
                angle = circle + angle

            dupe.set_name(f"{i + 2} {timer}")
            dupe.transform_rotate(angle, True, 0, 0)

            angle += rotation

            # The flush is critical because
            # the display can get over-extended
            # when a lot layers are created.
            Gimp.displays_flush()
        j.crop(j.get_width(), j.get_height(), 0., 0.)

    def _calc_motion_circle(self):
        """
        Motion is simulated by a flowing head and tail.
        Each flow has an angle that bisects its motion circle.
        """
        # angle offset, 'f'
        f = radians(90)

        a = self._motion_center_radius

        # motion circle width, 'w'
        w = a + a

        for flow in self._flow_d.values():
            # The angle is offset because the rectangle
            # calculation differs from this function.
            x, y = flow.motion_center = get_point_on_circle(
                self._center,
                self._center,
                flow.angle + f,
                a
            )
            flow.motion_square = x - a, y - a, w

    def _calc_polygon(self, w, angle_q):
        """
        Calculate the polygon needed by a Flow. The polygon is used
        to exclude material from a flow.

        Each polygon is made of a series of x, y coordinate pairs connected
        by clockwise-rotated segment. There is a minimum of three
        pairs and a maximum of five.

        w: int
            Image size

        angle_q: list
            [int, ...]
            Each value is a flow angle in degree.
        """
        w = float(w)

        # NE, SE, SW, NW
        degree_ab = 315, 45, 135, 225
        degree_ba = 315, 405, 135, 225

        # Start with NE corner and rotate clockwise.
        corner_q = [[w, 0.], [w, w], [0., w], [0., 0.]]

        # Each polygon starts from the center of the image.
        q = [self._center, self._center]

        for i in range(self._division):
            # The two angles determine corner points that are
            # added to the polygon.
            a = angle_q[i]
            b = angle_q[i + 1]

            # (x, y, ...), 'q1'
            q1 = q + self._flow_d[i].cut_point

            if a > b:
                # There's a rollover in the angles.
                degree_q = degree_ba
                b += 360

            else:
                degree_q = degree_ab

            for corner_i in range(4):
                if a < degree_q[corner_i] < b:
                    q1 += corner_q[corner_i]

            i1 = i + 1

            if i1 == self._division:
                i1 = 0

            q1 += self._flow_d[i + 1].cut_point
            self._flow_d[i1].seg = tuple(q1)

    def _create_channel(self):
        """
        Create selection. Save its channel and
        remember its id in a channel dict.
        """
        # Drop the extra Flow used by the polygon calculator.
        self._flow_d.pop(self._division)

        self._create_ring_channel()
        self._create_motion_channel()
        self._create_eye_channel()
        self._create_eye_patch_channel()
        self._create_flow_channel()

    def _create_eye_channel(self):
        """
        Create eye circle selection. Save it and remember its id.
        """
        if self._eye_w:
            radius = self._eye_w / 2.
            for k, flow in self._flow_d.items():
                x, y = flow.motion_center
                a = radius
                x -= a
                y -= a
                w = a + a

                Gimp.Selection.none(self._image)
                select_ellipse(self._image, x, y, w, w)
                self._save_selection(('eye', k))
        else:
            for k in self._flow_d.keys():
                self._channel_d[('eye', k)] = None

    def _create_eye_patch_channel(self):
        """Create eye patch channel with a series of channel operation."""
        if not self._is_blind:
            Gimp.Selection.none(self._image)

            for k in self._flow_d.keys():
                if k % 2:
                    continue
                self._make_selection(('eye', k), Gimp.ChannelOps.ADD)
            self._save_selection('even_patch')

            Gimp.Selection.none(self._image)

            for k in self._flow_d.keys():
                if not k % 2:
                    continue
                self._make_selection(('eye', k), Gimp.ChannelOps.ADD)
            self._save_selection('odd_patch')

    def _create_motion_channel(self):
        """Create motion circle. Save its selection and remember its id."""
        for k, flow in self._flow_d.items():
            x, y = flow.motion_center
            a = self._motion_circle_radius
            x -= a
            y -= a
            w = a + a

            Gimp.Selection.none(self._image)
            select_ellipse(self._image, x, y, w, w)
            self._save_selection(('motion', k))

    def _create_ring_channel(self):
        """Create a ring selection. Save the channel and remember its id."""
        symbol_offset, symbol_w = self._symbol_rect[0], self._symbol_rect[2]
        select_ellipse(self._image, *self._symbol_rect)

        if self._ring_w == self._radius:
            self._channel_d['ring'] = None

        else:
            # Has a core, so cut its area from the symbol area.
            w = symbol_offset + self._ring_w
            w1 = symbol_w - self._ring_w - self._ring_w
            select_ellipse(
                self._image, w, w, w1, w1, op=Gimp.ChannelOps.SUBTRACT
            )
        self._save_selection('ring')

    def _create_flow_channel(self):
        """Create flow channel with a series of channel operation."""
        for k, flow in self._flow_d.items():
            k1 = k - 1

            if k1 < 0:
                k1 = self._division - 1

            select_polygon(self._image, flow.seg)
            self._make_selection('ring', Gimp.ChannelOps.INTERSECT)
            self._make_selection(('motion', k), Gimp.ChannelOps.ADD)
            self._make_selection(('motion', k1), Gimp.ChannelOps.SUBTRACT)
            self._make_selection(('eye', k), Gimp.ChannelOps.SUBTRACT)
            self._save_selection(('flow', k))

    def _create_image(self, w):
        """
        Create an output image. If the image already exists,
        remove its layers as long it's the same size as the
        latest input requirement.

        w: float
            WIP image size

        return: Gimp.Image
            newly created
        """
        if self._image:
            # Delete image.
            self._display.delete()
            self._image = self._display = None

        self._image, self._display = create_image(w)
        self._center = w / 2
        return self._image

    def _draw_gradient(self):
        """Draw an gradient overlay for each motion."""

        def _get_index(_f):
            """
            f: float
                angle in radians

            Return: int
                0 to 3
                index to quadrant
            """
            return int((degrees(_f) + .01) / 90 % 4)

        def _get_rect_point(_x, _y, _w):
            """
            _x, _y, _w: float
                Define a motion circle's bounding square.
            """
            return _x, _y, _x + _w, _y + _w

        for k, head in self._flow_d.items():
            k1 = k - 1

            if k1 < 0:
                k1 = self._division - 1

            # Compute gradient line that connects head to tail.
            tail = self._flow_d[k1]
            head_x, head_y, head_x1, head_y1 = _get_rect_point(
                *head.motion_square
            )
            tail_x, tail_y, tail_x1, tail_y1 = _get_rect_point(
                *tail.motion_square
            )
            x_i, y_i = ((1, 1), (0, 1), (0, 0), (1, 0))[
                _get_index(head.angle)
            ]
            start_x = (head_x, head_x1)[x_i]
            start_y = (head_y, head_y1)[y_i]

            # The gradient end point is on
            # the opposite corner of the head corner.
            end_x = (tail_x, tail_x1)[not x_i]
            end_y = (tail_y, tail_y1)[not y_i]

            layer = add_layer(
                self._image, parent=self._group_layer, layer_name="Gradient"
            )

            self._make_selection(('flow', k), Gimp.ChannelOps.REPLACE)
            self._make_selection(('eye', k1), Gimp.ChannelOps.ADD)
            Gimp.context_set_gradient_reverse(k % 2)
            draw_gradient(layer, start_x, end_x, start_y, end_y)
            layer.set_mode(self._mode)
            layer.set_opacity(self._opacity)

    def _draw_rim(self):
        """
        Draw a black rim if an option. Do this by expanding the ring selection.
        """
        if self._rim_w:
            layer = add_layer(
                self._image, parent=self._group_layer, layer_name="Rim"
            )

            self._make_selection('ring', Gimp.ChannelOps.REPLACE)
            Gimp.Selection.grow(self._image, self._rim_w)
            self._make_selection('ring', Gimp.ChannelOps.SUBTRACT)

            if self._type:
                fill_selection_with_color(layer, get_linear_gegl(self._rim))

            else:
                fill_selection_with_pattern(layer, self._pattern_3)
            Gimp.Selection.none(self._image)

    def _expand(self):
        """
        Calculate upscale and relative variable.

        Return: float
            WIP image size
        """
        # upscale, '*= 2'
        self._radius *= 2
        self._rim_w *= 2

        # The symbol rectangle is offset from the topleft.
        # padding, '2'
        symbol_offset = self._rim_w + 2
        symbol_w = self._radius * 2

        # The rim is doubled again because its on both sides of the center.
        image_size = symbol_w + (symbol_offset * 2)

        # Define the symbol circle bounds.
        self._symbol_rect = symbol_offset, symbol_offset, symbol_w, symbol_w

        # Factor to get width.
        self._ring_w *= self._radius

        self._core_radius = self._radius - self._ring_w

        # Factor to get width.
        self._eye_w = self._eye_w * self._ring_w

        self._motion_circle_radius = self._ring_w / 2
        self._motion_center_radius = self._core_radius + self._ring_w / 2.
        return image_size

    def _fill_color(self):
        """Combine flow channel and fill them with color."""
        def _fill_p(layer, _index):
            """
            layer: Gimp.Layer
                Receive color.

            _index: int
                0 or 1
                yin or yang
            """
            color_selection(
                layer, get_linear_gegl((self._yang, self._yin)[_index])
            )

        self._fill_symbol(_fill_p)

    def _fill_pattern(self):
        """Combine the flow channels and fill them with pattern."""
        def _fill_p(layer, _index):
            fill_selection_with_pattern(
                layer, (self._pattern_1, self._pattern_2)[_index]
            )

        self._fill_symbol(_fill_p)

    def _fill_symbol(self, fill_p):
        """
        Fill the yin-yang symbol with a color or pattern.

        fill_p: function
            Perform fill.
        """
        layer = add_layer(
            self._image, parent=self._group_layer, layer_name="Flow"
        )

        Gimp.Selection.none(self._image)

        # two selections, yin and yang, '2', 'index_'.
        for index_ in range(2):
            # step, '2'
            for i in range(index_, self._division, 2):
                self._make_selection(('flow', i), op=Gimp.ChannelOps.ADD)

            if not self._is_blind:
                self._make_selection(
                    ('odd_patch', 'even_patch')[index_], Gimp.ChannelOps.ADD
                )
            fill_p(layer, index_)
            Gimp.Selection.none(self._image)

    def _get_channel(self, k):
        """
        Retrieve a saved selection's channel.

        k: string
            key to channel dict
        """
        # channel id, 'a'
        a = self._channel_d.get(k)
        if a is not None:
            return Gimp.Channel.get_by_id(a)

    def _init_flow(self, w):
        """
        Create and init Flow. A flow angle bisects the flow motion circle.
        A cut point is a connecting point for creating flow polygons that
        limit selection fill.

        w: int
            Is the size of the render.
        """
        # The first point is center-top at 270 degrees.
        flow = int(360 / self._division)

        angle_q = []
        rect = 0., 0., w, w

        for i in range(self._division + 1):
            self._flow_d[i] = Flow()
            a = int(flow * i + 270)

            while a >= 360:
                a -= 360
            angle_q += [a]

        for i in range(self._division + 1):
            flow = self._flow_d[i]
            f = flow.angle = radians(angle_q[i])
            flow.cut_point = get_point_on_rect(f, *rect)
        return angle_q

    def _make_selection(self, k, op):
        """
        Perform a selection operation using a saved selection.

        k: string or tuple
            key to channel in the channel dict

        op: Gimp.ChannelOps
            ADD, SUBTRACT, INTERSECT, REMOVE
        """
        channel = self._get_channel(k)

        # A saved channel can be None, so check.
        if channel:
            self._image.select_item(op, channel)

    def _save_selection(self, k):
        """
        Save the current selection. Remember it with a channel dict.

        k: string
            Is the key for the channel dict.
        """
        if Gimp.Selection.is_empty(self._image):
            self._channel_d[k] = None
        else:
            selection = self._image.get_selection()
            channel = selection.save(self._image)
            self._channel_d[k] = channel.get_id()

    def create(self, d):
        """
        Make Yin-Yang output layer.

        d: dict
            {widget key: widget value}
            Extract value from the plug-in dialog.
        """
        for k, v in d.items():
            setattr(self, "_" + k, v)

        self._channel_d = {}
        self._flow_d = {}

        # WIP image size, 'w'
        w = self._expand()

        # final image size, 'w1'
        w1 = w / 2

        j = self._create_image(w)
        j.undo_disable()

        self._group_layer = add_group_layer(j, layer_name="Yin-Yang")
        angle_q = self._init_flow(w)

        self._calc_polygon(w, angle_q)
        self._calc_motion_circle()
        self._create_channel()
        (self._fill_pattern, self._fill_color)[self._type]()

        if self._is_gradient:
            self._draw_gradient()

        self._draw_rim()

        # Remove finished channel to clear memory and ease upkeep.
        for i in j.get_channels():
            j.remove_channel(i)

        layer = self._group_layer.merge()

        Gimp.Selection.none(j)
        j.scale(w1, w1)

        if self._is_flip:
            j.flip(Gimp.OrientationType.HORIZONTAL)

        if self._is_anime:
            self._animate(layer)

        j.undo_enable()
        Gimp.displays_flush()
