#!/usr/bin/env python3
from output import Output, _
from random import randint, uniform
import colorsys
import gi       # type: ignore
import sys

gi.require_version('Gdk', '3.0')
gi.require_version('Gtk', '3.0')

from gi.repository import Gdk, Gimp, GimpUi, Gtk

CHECK_KEY = 'is_anime', 'is_blind', 'is_gradient'
COLOR_KEY = 'yin', 'yang', 'rim'
PATTERN_KEY = 'pattern_1', 'pattern_2', 'pattern_3'
YIN_YANG_LABEL = "Yin", "Yang", "Rim"

# ColorButton insight
COLOR_TOOLTIP = _(" Red\t{} \n Green\t{} \n Blue\t{} \n Alpha\t{}")

EXCLUSION = "Exclusion"

# Init dialog or load default value with this read-only dict.
# {widget key: widget init value}
DEFAULT_VALUE_D = {
    'division': "2",
    'eye_w': .33,
    'frame': 12,
    'is_anime': 0,
    'is_blind': 0,
    'is_flip': 0,
    'is_gradient': 0,
    'mode': EXCLUSION,
    'opacity': 100.,
    'pattern_1': None,
    'pattern_2': None,
    'pattern_3': None,
    'radius': 200,
    'rim': Gdk.RGBA(.0, .0, .0, 1.),
    'rim_w': 1,
    'ring_w': 1.,
    'timer': 100,
    'type': 0,
    'yang': Gdk.RGBA(1., 1., 1., 1.),
    'yin': Gdk.RGBA(.0, .0, .0, 1.)
}

SEPARATOR = '-'

# Preview button id
RESPONSE_PREVIEW = -99

# Button response in dialog.
response_d = {
    RESPONSE_PREVIEW: None,
    Gtk.ResponseType.CANCEL: None,
    Gtk.ResponseType.DELETE_EVENT: None,
    Gtk.ResponseType.OK: None
}

# Gtk.Grid row index for widget placement
DIVISION_INDEX, \
    GRADIENT_MODE_INDEX, \
    OPACITY_INDEX, \
    RADIUS_INDEX, \
    RIM_W_INDEX, \
    RING_WIDTH_INDEX, \
    EYE_W_INDEX, \
    FRAME_INDEX, \
    TIMER_INDEX, \
    TYPE_INDEX, \
    ROTATE_INDEX, \
    CHECK_INDEX, \
    PATTERN_INDEX, \
    COLOR_BUTTON_INDEX, \
    RANDOM_INDEX = range(15)


def add_color_button_row(grid, d):
    """
    Add Gtk.ColorButton options to a Gtk.Grid.

    grid: Gtk.Grid
        Receive ColorButton.

    d: dict
        {widget key: widget}
        Store each widget for value retrieval.
    """
    # Remember the label as it changes visibility.
    d['color_label'] = add_grid_label(grid, COLOR_BUTTON_INDEX, _("Color"))

    hbox = d['color_hbox'] = Gtk.HBox(homogeneous=True, spacing=6)

    # Create the row.
    # three colors, '3'
    for i in range(3):
        g = d[COLOR_KEY[i]] = Gtk.ColorButton.new_with_rgba(
            Gdk.RGBA(red=1., green=1., blue=1., alpha=1.)
        )

        vbox = Gtk.VBox(homogeneous=False, spacing=1)
        k = YIN_YANG_LABEL[i]
        label = create_label(_(k), x_align=.5)

        vbox.add(label)
        vbox.add(g)
        g.connect('color-set', on_color_set)
        hbox.pack_start(
            vbox,
            True,                  # expand
            True,                  # fill
            2                      # padding
        )

    # Need to hide/show on Rim Width option change.
    d['color_vbox'] = vbox

    # column, '1'; cell width, '1'; cell height, '1'
    grid.attach(hbox, 1, COLOR_BUTTON_INDEX, 1, 1)


def add_grid(vbox):
    """
    Add a Gtk.Grid to a Gtk.VBox.

    Return: Gtk.Grid
        newly created
    """
    grid = Gtk.Grid()

    grid.set_column_homogeneous(False)
    grid.set_border_width(12)
    grid.set_column_spacing(12)
    grid.set_row_spacing(2)
    vbox.add(grid)
    return grid


def add_grid_label(grid, row, text):
    """
    Given a Gtk.Grid, add a Gtk.Label to its first column.

    grid: Gtk.Grid
        Receive Label.

    row: int
        0 to n
        Identify Grid row.

    text: string
        Is the Label's displayed text.

    Return: Gtk.Label
        newly created
    """
    """ Create a label and set it in first column of a grid. """
    label = create_label(text)

    # column, '0'; cell width, '1'; cell height, '1'
    grid.attach(label, 0, row, 1, 1)

    return label


def add_grid_spin(grid, row, adj_arg, digits=0):
    """
    Add a SpinButton to a Grid. Place the button in the second column.

    grid: Gtk.Grid
        Receive the SpinButton in column 1.

    row: int
        0 to n
        Is the row index in the Grid where the SpinButton is placed.

    adj_arg: tuple
        Is given to a Gtk.Adjustment during its init call.

    digits: int
        Is the number of decimal places in the widget display.

    Return: Gtk.SpinButton
        newly created
    """
    spin = Gtk.SpinButton.new(
        Gtk.Adjustment.new(*adj_arg), climb_rate=.02, digits=digits
    )

    spin.set_numeric(True)
    spin.set_snap_to_ticks(True)
    spin.set_max_length(5)
    spin.set_width_chars(5)

    # column, '1'; cell width, '1'; cell height, '1'
    grid.attach(spin, 1, row, 1, 1)
    return spin


def add_hint_box(vbox):
    """
    Place GIMP's hint box on top of the dialog.

    vbox: Gtk.Box
        Has vertical packing to receive HintBox.
    """
    vbox.pack_start(
        GimpUi.HintBox.new(_("Create a Yin-Yang image or GIF animation.")),
        False,                  # expand
        False,                  # fill
        0                       # padding
    )


def add_pattern_chooser_row(grid, d):
    """
    Add GimpUi.PatternChooser options to a Gtk.Grid.

    Init:
        GimpUi.PatternChooser.new()

    Getter:
        PatternChooser.get_resource() returns a Gimp.Pattern.

    Changed Signals: 'parent-set' on init, and 'resource-set' on change.

    Setter:
        I tried widget.set_resource(Gimp.Pattern()), where
        widget is a GimpUi.PatternChooser instance,
        but it crashes GIMP 3 RC1.

    grid: Gtk.Grid
        Receive ColorButton.

    d: dict
        {widget key: widget}
        Store each widget for value retrieval.
    """
    # Remember the label as it changes visibility.
    d['pattern_label'] = add_grid_label(grid, PATTERN_INDEX, _("Pattern"))

    hbox = d['pattern_hbox'] = Gtk.Box(spacing=6)

    # Create the row.
    # three patterns, '3'
    for i in range(3):
        g = d[(PATTERN_KEY)[i]] = GimpUi.PatternChooser.new()

        vbox = Gtk.VBox(homogeneous=False, spacing=1)
        k = YIN_YANG_LABEL[i]
        label = create_label(_(k), x_align=.5)

        vbox.add(label)
        vbox.add(g)
        g.connect('resource-set', on_pattern_set)
        hbox.pack_start(
            vbox,
            True,                   # expand
            True,                   # fill
            2                       # padding
        )

    # Need to hide/show on Rim Width option change.
    d['pattern_vbox'] = vbox

    # column, '1'; cell width, '1'; cell height, '1'
    grid.attach(hbox, 1, PATTERN_INDEX, 1, 1)


def check_for_separator(list_store, tree_iter):
    """
    Check a ComboBox value to see if it's an separator.

    Return: bool
        If True, then the value is a separator.
    """
    n = list_store.get_value(tree_iter, 0)

    if n:
        return n == SEPARATOR
    return False


def on_pattern_set(g, pattern, is_valid):
    """
    Respond to 'resource-set' events.

    g: GimpUi.PatternChooser
        Is responsible.

    Gimp.Pattern: Gimp.Pattern
        on display

    is_valid: bool
        Is True if the pattern was qualified by the user.
    """
    if is_valid:
        g.set_tooltip_text(pattern.get_name())


def convert_float_color_to_int(color):
    return [
        int(a * 255)
        for a in (color.red, color.green, color.blue, color.alpha)
    ]


def create_label(text, x_align=.0):
    """
    Make a Gtk.Label.

    text: string
        Assign to the label.

    x_align: float
        .0 to 1.
        Horizontally position the label.
    """
    label = Gtk.Label(label=text)

    label.set_xalign(x_align)
    label.set_yalign(.5)
    return label


def on_color_set(color_button):
    """
    A ColorButton changed value, so its tooltip needs updating.

    color_button: Gtk.ColorButton
        Has a new value.
    """
    rgba = convert_float_color_to_int(color_button.get_rgba())
    color_button.set_tooltip_text(COLOR_TOOLTIP.format(*rgba))


class Dialog:
    """Create a GimpUI.Dialog having Cancel, Preview, and Accept buttons."""

    def __init__(self, add_widget_p, response_p):
        """
        add_widget_p: function
            Add widget to the Dialog's VBox.

        response_p: function
            Handle Cancel, Preview, and Accept button action.
        """
        self.dialog = GimpUi.Dialog(
            use_header_bar=Gtk.Settings.get_default().
            get_property("gtk-dialogs-use-header"),
            title="Yin-Yang 2.1"
        )
        vbox = Gtk.VBox(homogeneous=False)

        self.dialog.get_content_area().add(vbox)
        self.dialog.add_button(_("_Cancel"), Gtk.ResponseType.CANCEL)
        self.dialog.add_button(_("Preview"), RESPONSE_PREVIEW)
        self.dialog.add_button(_("_Accept"), Gtk.ResponseType.OK)

        # Add additional widget.
        add_widget_p(vbox)

        # Render dialog.
        vbox.show_all()
        self.dialog.show()

        # Map button responses to callback.
        self.dialog.connect('response', response_p)

        # Start event loop.
        Gtk.main()


class PluginDialog:
    """
    Create a GimpUI.Dialog for user interaction and define output settings.
    """

    def __init__(self):
        """Open a dialog. Respond to user interaction."""
        # {option key: widget}
        # For setting default value and retrieving widget.
        self._widget_d = {}

        # Capture dialog settings for determining
        # a boolean change state between Preview actions.
        # {widget key: widget value}
        self.preview_d = {}

        # Init UI theme.
        GimpUi.init(sys.argv[0])

        self.output = Output()

        response_d[Gtk.ResponseType.CANCEL] = \
            response_d[Gtk.ResponseType.DELETE_EVENT] = self.on_cancel
        response_d[Gtk.ResponseType.OK] = self.on_accept
        response_d[RESPONSE_PREVIEW] = self.on_preview
        Dialog(self._add_dialog_widget, self.on_dialog_button)

    def _add_checkbutton_row(self):
        """
        Add a Gradient CheckButton to a Gtk.Grid.

        grid: Gtk.Grid
            Receive CheckButton.

        Return: Gtk.CheckButton
            newly created
        """
        hbox = Gtk.HBox(spacing=0)
        g = Gtk.CheckButton.new_with_label("Gradient")
        g1 = Gtk.CheckButton.new_with_label("Animate")
        g2 = Gtk.CheckButton.new_with_label("Transparent Eye")

        for i in (g, g1, g2):
            hbox.pack_start(i, True, True, 0)

        # column, '1'; cell width, '1'; cell height, '1'
        self._grid.attach(hbox, 1, CHECK_INDEX, 1, 1)

        g.set_tooltip_text(" Make a gradient overlay. ")
        g1.set_tooltip_text(" Animate the symbol. ")
        g2.set_tooltip_text(" Make the eye invisible. ")
        g.connect('toggled', self.on_gradient)
        g1.connect('toggled', self.on_anime)

        # Cause the frame widget to hide on start, 'realize'.
        g.connect('realize', self.on_gradient)
        g1.connect('realize', self.on_anime)
        return g, g1, g2

    def _add_dialog_widget(self, vbox):
        """
        Add Yin-Yang widget to the Dialog's VBox.

        vbox: Gtk.Box
            Has vertical packing.
        """
        add_hint_box(vbox)

        g = self._grid = add_grid(vbox)
        d = self._widget_d
        d['division'] = self._add_division_combobox()
        d['mode'] = self._add_gradient_mode_combobox()
        d['opacity'] = self._add_opacity_spinner()
        d['radius'] = self._add_radius_spinner()
        d['rim_w'] = self._add_rim_spinner()
        d['ring_w'] = self._add_ring_width_spinner()
        d['eye_w'] = self._add_eye_spinner()
        d['frame'] = self._add_frame_spinner()
        d['timer'] = self._add_timer_spinner()
        d['is_gradient'], d['is_anime'], d['is_blind'] = \
            self._add_checkbutton_row()
        d['type'] = self._add_type_radiobutton()
        d['is_flip'] = self._add_rotate_radiobutton()

        add_color_button_row(g, d)
        add_pattern_chooser_row(g, d)
        self._add_random_button()
        self._load_default()

        # Make the RadioButtons all the same size.
        same_size = Gtk.SizeGroup(mode=Gtk.SizeGroupMode.BOTH)

        for g in d['is_flip'] + d['type']:
            same_size.add_widget(g)

    def _add_division_combobox(self):
        """
        Add a Division ComboBoxText to a Gtk.Grid.

        Return: Gtk.ComboBoxText
            newly created
        """
        add_grid_label(self._grid, DIVISION_INDEX, _("Division"))

        combobox = Gtk.ComboBoxText.new()

        for n in ("2", "4", "6", "8", "10", "12"):
            combobox.append_text(n)

        # column, '1'; cell width, '1'; cell height, '1'
        self._grid.attach(combobox, 1, DIVISION_INDEX, 1, 1)

        combobox.set_tooltip_text(" Set the number of motion pairs. ")
        combobox.set_active(0)
        return combobox

    def _add_eye_spinner(self):
        """
        Add a Eye Width SpinButton to a Gtk.Grid.

        grid: Gtk.Grid
            Receive SpinButton.

        Return: Gtk.SpinButton
            newly created
        """
        add_grid_label(self._grid, EYE_W_INDEX, _("Eye Width"))

        # (init value, lower limit, upper limit, step inc, page inc, page size)
        spin = add_grid_spin(
            self._grid, EYE_W_INDEX, (0., .0, 1., .01, .1, 0.), digits=2
        )

        spin.set_tooltip_text(" Factor the Ring Width. ")
        return spin

    def _add_frame_spinner(self):
        """
        Add a Frame Count SpinButton to a Gtk.Grid.

        grid: Gtk.Grid
            Receive SpinButton.

        Return: Gtk.SpinButton
            newly created
        """
        self._widget_d['frame_label'] = add_grid_label(
            self._grid, FRAME_INDEX, _("Frame Count")
        )

        # (init value, lower limit, upper limit, step inc, page inc, page size)
        spin = add_grid_spin(
            self._grid, FRAME_INDEX, (0., 1., 999., 1., 2., 0.)
        )

        spin.set_tooltip_text(
            " Create animation layers with more than one frame . "
        )
        return spin

    def _add_gradient_mode_combobox(self):
        """
        Add a Division ComboBoxText to a Gtk.Grid.

        Return: Gtk.ComboBoxText
            newly created
        """
        self._widget_d['mode_label'] = add_grid_label(
            self._grid, GRADIENT_MODE_INDEX, _("Gradient Mode")
        )

        combobox = Gtk.ComboBoxText.new()

        for n in LAYER_MODE_Q:
            combobox.append_text(n)

        # column, '1'; cell width, '1'; cell height, '1'
        self._grid.attach(combobox, 1, GRADIENT_MODE_INDEX, 1, 1)

        combobox.set_row_separator_func(check_for_separator)
        combobox.set_active(LAYER_MODE_Q.index(EXCLUSION))
        return combobox

    def _add_radius_spinner(self):
        """
        Add a Symbol Radius SpinButton to a Gtk.Grid.

        grid: Gtk.Grid
            Receive SpinButton.

        Return: Gtk.SpinButton
            newly created
        """
        add_grid_label(self._grid, RADIUS_INDEX, _("Symbol Radius"))

        # (Init value, lower limit, upper limit, step inc, page inc, page size)
        return add_grid_spin(
            self._grid, RADIUS_INDEX, (0., 12., 9999., 1., 10., 0.)
        )

    def _add_opacity_spinner(self):
        """
        Add an Opacity SpinButton to a Gtk.Grid.

        Return: Gtk.SpinButton
            newly created
        """
        self._widget_d['opacity_label'] = add_grid_label(
            self._grid, OPACITY_INDEX, _("Gradient Opacity")
        )

        # (init value, lower limit, upper limit, step inc, page inc, page size)
        return add_grid_spin(
            self._grid, OPACITY_INDEX, (100., .0, 100., 1., 10., 0.), digits=1
        )

    def _add_random_button(self):
        """
        Add an HBox with three buttons for modifying the Color Array.
        """
        hbox = Gtk.Box(spacing=1, homogeneous=True)
        g = Gtk.Button.new_with_label("Color")
        g1 = Gtk.Button.new_with_label("Hue")
        g2 = Gtk.Button.new_with_label("Saturation")
        g3 = Gtk.Button.new_with_label("Lightness")
        align_left = Gtk.Alignment()
        align_mid = Gtk.Alignment()
        align_right = Gtk.Alignment()

        label = add_grid_label(self._grid, RANDOM_INDEX, _("Random"))

        # first
        align_left.set_padding(0, 0, 0, 4)
        align_left.add(g)
        hbox.pack_start(align_left, True, True, 0)

        # middle
        align_mid.set_padding(0, 0, 0, 4)
        align_mid.add(g1)
        hbox.pack_start(align_mid, True, True, 0)
        hbox.pack_start(g2, True, True, 0)

        # last
        align_right.set_padding(0, 0, 4, 0)
        align_right.add(g3)
        hbox.pack_start(align_right, True, True, 0)

        for i, g_ in enumerate((g, g1, g2, g3)):
            g_.connect('clicked', self.on_random_color, i)

        # column, '1'; cell width, '1'; cell height, '1'
        self._grid.attach(hbox, 1, RANDOM_INDEX, 1, 1)
        self._widget_d['random_widget'] = label, g, g1, g2, g3

    def _add_rim_spinner(self):
        """
        Add a Rim Width SpinButton to a Gtk.Grid.

        Return: Gtk.SpinButton
            newly created
        """
        add_grid_label(self._grid, RIM_W_INDEX, _("Rim Width"))

        # (init value, lower limit, upper limit, step inc, page inc, page size)
        spin = add_grid_spin(
            self._grid, RIM_W_INDEX, (0., 0., 9999., 1., 10., 0.)
        )

        spin.connect('value-changed', self.on_rim_width_change)
        spin.connect('realize', self.on_rim_width_change)
        return spin

    def _add_ring_width_spinner(self):
        """
        Add a Ring Width SpinButton to a Gtk.Grid.

        Return: Gtk.SpinButton
            newly created
        """
        add_grid_label(self._grid, RING_WIDTH_INDEX, _("Ring Width"))

        # init value, lower limit, upper limit, step inc, page inc, page size
        spin = add_grid_spin(
            self._grid, RING_WIDTH_INDEX, (0., .0, 1., .01, .1, 0.), digits=2
        )

        spin.set_tooltip_text(
            " Create a center hole. \n Factor the Symbol Radius. "
        )
        return spin

    def _add_rotate_radiobutton(self):
        """
        Add Rotate options to a Gtk.Grid.

        Return: tuple
            (Gtk.RadioButton, Gtk.RadioButton)
            (Clockwise option, Counter-Clockwise option)
            newly created
        """
        add_grid_label(self._grid, ROTATE_INDEX, _("Rotate"))

        # container for RadioButton, 'hbox'
        hbox = Gtk.Box(spacing=0)

        button = Gtk.RadioButton.new_with_label_from_widget(
            None, _("Clockwise")
        )
        button1 = Gtk.RadioButton.new_with_label_from_widget(
            button, _("Counter-Clockwise")
        )

        # Expand and fill, 'True'; zero padding, '0'.
        hbox.pack_start(button, True, True, 0)
        hbox.pack_start(button1, True, True, 0)

        # column, '1'; cell width, '1'; cell height, '1'
        self._grid.attach(hbox, 1, ROTATE_INDEX, 1, 1)

        return button, button1

    def _add_timer_spinner(self):
        """
        Add a Timer SpinButton to a Gtk.Grid.

        Return: Gtk.SpinButton
            newly created
        """
        self._widget_d['timer_label'] = add_grid_label(
            self._grid, TIMER_INDEX, _("Frame Timer")
        )

        # (init value, lower limit, upper limit, step inc, page inc, page size)
        spin = add_grid_spin(
            self._grid, TIMER_INDEX, (1., 1., 9999., 1., 10., 0.)
        )

        spin.set_tooltip_text(
            " Is the wait time, in millisecond,"
            " that an animation takes between frames. "
        )
        return spin

    def _add_type_radiobutton(self):
        """
        Add Type options to a Gtk.Grid.

        Return: tuple
            (Gtk.RadioButton, Gtk.RadioButton)
            (Clockwise option, Counter-Clockwise option)
            newly created
        """
        add_grid_label(self._grid, TYPE_INDEX, _("Type"))

        # container for RadioButton, 'hbox'
        hbox = Gtk.Box(spacing=0)

        button = Gtk.RadioButton.new_with_label_from_widget(
            None, _("Color")
        )
        button1 = Gtk.RadioButton.new_with_label_from_widget(
            button, _("Pattern")
        )

        # Expand and fill, 'True'; zero padding, '0'.
        hbox.pack_start(button, True, True, 0)
        hbox.pack_start(button1, True, True, 0)

        # column, '1'; cell width, '1'; cell height, '1'
        self._grid.attach(hbox, 1, TYPE_INDEX, 1, 1)

        button.connect('realize', self.on_type)
        button.connect('toggled', self.on_type)
        return button, button1

    def _gather_dialog_setting(self):
        """
        Load a dictionary with dialog widget value.

        Return: dict
            {widget key: widget value}
        """
        d = {}
        e = self._widget_d

        # ComboBoxText
        d['division'] = int(e['division'].get_active_text())
        d['mode'] = LAYER_MODE_D[e['mode'].get_active_text()]

        # int SpinButton
        for k in ('frame', 'opacity', 'radius', 'rim_w', 'timer'):
            d[k] = int(e[k].get_value())

        # float SpinButton
        for k in ('eye_w', 'ring_w'):
            d[k] = e[k].get_value()

        # RadioButton; the first button index, '0'
        for k in ('type',):
            d[k] = e[k][0].get_active()

        d['is_flip'] = e['is_flip'][1].get_active()

        # CheckButton
        for k in CHECK_KEY:
            d[k] = e[k].get_active()

        # ColorButton
        for k in COLOR_KEY:
            a = e[k].get_rgba()
            d[k] = a.red, a.green, a.blue, a.alpha

        # PatternChooser
        for k in PATTERN_KEY:
            d[k] = e[k].get_resource()
        return d

    def _load_default(self, *_):
        """
        Load default value into dialog widget.

        _: Gtk.Button
            Default
            not used
        """
        d = self._widget_d
        e = DEFAULT_VALUE_D

        # Set Color Array.
        for k in COLOR_KEY:
            d[k].set_rgba(e[k])
            on_color_set(d[k])

        for k in ('eye_w', 'frame', 'radius', 'rim_w', 'ring_w', 'timer'):
            d[k].set_value(e[k])

    def on_accept(self):
        """
        Respond to an Accept button action. Create a Yin-Yang image.
        """
        self.on_preview()
        Gtk.main_quit()

    def on_anime(self, *arg):
        """
        Respond to an Animate CheckButton change. Hide or show frame widget.

        arg: tuple or Gtk.CheckButton
        """
        d = self._widget_d
        q = [
            d[k]
            for k in ('frame', 'frame_label', 'timer', 'timer_label')
            if d.get(k)
        ]

        if d['is_anime'].get_active():
            for g in q:
                g.show()
        else:
            for g in q:
                g.hide()

    def on_cancel(self):
        """Close the dialog. The user chose to cancel."""
        Gtk.main_quit()

    def on_dialog_button(self, dialog, response_id):
        """
        Handle a user initiated dialog-process button action.

        dialog: GimpUI.Dialog
            Is the Yin-Yang dialog.

        response_id: Gtk.ResponseType
            Identify button.
        """
        p = response_d.get(response_id)
        if p is not None:
            p()

    def on_gradient(self, *arg):
        """
        Respond to a Gradient CheckButton change.
        Hide or show related gradient widget.

        arg: tuple or Gtk.CheckButton
        """
        d = self._widget_d
        q = [
            d[k]
            for k in ('mode', 'mode_label', 'opacity', 'opacity_label')
            if d.get(k)
        ]

        if d['is_gradient'].get_active():
            for g in q:
                g.show()
        else:
            for g in q:
                g.hide()

    def on_preview(self):
        """
        Respond to a Preview button action by performing a preview
        but only if things have changed since the last preview.
        """
        d = self._gather_dialog_setting()

        if self.preview_d != d:
            self.output.create(d)
        self.preview_d = d

    def on_random_color(self, button, i):
        """
        Randomize color button value on multiple random-button action.

        button: Gtk.Button
            Is responsible.
            not used

        i: index
            random index
        """
        d = self._widget_d
        rgb = [uniform(.0, 1.) for f in range(3)]

        if i:
            i1 = i - 1

            # hue, saturation, lightness, 'q', in float, .0 to 1.
            q = list(colorsys.rgb_to_hls(*rgb))

            # Invert HLS value.
            q[i1] = 1. - q[i1]

            rgb1 = list(colorsys.hls_to_rgb(*q))

        else:
            # Invert color.
            rgb1 = [1. - f for f in rgb]

        # The Rim color is randomly borrowing.
        rgb2 = [(rgb[i], rgb1[i])[randint(0, 1)] for i in range(3)]

        for a in zip(COLOR_KEY, (rgb, rgb1, rgb2)):
            k, q = a

            d[k].set_rgba(Gdk.RGBA(*q))
            on_color_set(d[k])

    def on_rim_width_change(self, button):
        """
        Respond to change in the Rim Width SpinButton
        by hiding or showing Rim Color's VBox.
        """
        k = 'color_vbox' \
            if self._widget_d['type'][0].get_active() else \
            'pattern_vbox'
        g = self._widget_d[k]

        if button.get_value():
            g.show()
        else:
            g.hide()

    def on_type(self, *arg):
        """
        Respond to an Type CheckButton change.
        Hide or show Type-related widget.

        arg: tuple or Gtk.CheckButton
        """
        d = self._widget_d
        q = [d[k] for k in ('pattern_hbox', 'pattern_label')]
        q1 = [d[k] for k in ('color_hbox', 'color_label')]

        if d['type'][0].get_active():
            for g in q:
                g.hide()

            for g in q1:
                g.show()
            for g in d['random_widget']:
                g.show()

        else:
            for g in q:
                g.show()

            for g in q1:
                g.hide()
            for g in d['random_widget']:
                g.hide()
        self.on_rim_width_change(d['rim_w'])


LAYER_MODE_Q = (
    "Normal",
    "Dissolve",
    "Color Erase",
    "Erase",
    "Merge",
    "Split",
    SEPARATOR,
    "Lighten Only",
    "Luma Lighten Only",
    "Screen",
    "Dodge",
    "Addition",
    SEPARATOR,
    "Darken Only",
    "Luma Darken Only",
    "Multiply",
    "Burn",
    "Linear Burn",
    SEPARATOR,
    "Overlay",
    "Soft Light",
    "Hard Light",
    "Vivid Light",
    "Pin Light",
    "Linear Light",
    "Hard Mix",
    SEPARATOR,
    "Difference",
    "Exclusion",
    "Subtract",
    "Grain Extract",
    "Grain Merge",
    "Divide",
    SEPARATOR,
    "HSV Hue",
    "HSV Saturation",
    "HSL Color",
    "HSV Value",
    SEPARATOR,
    "LCH Hue",
    "LCH Chroma",
    "LCH Color",
    "LCH Lightness",
    "Luminance",
)
LAYER_MODE_D = {
    "Normal":  Gimp.LayerMode.NORMAL,
    "Dissolve": Gimp.LayerMode.DISSOLVE,
    "Color Erase": Gimp.LayerMode.COLOR_ERASE,
    "Erase": Gimp.LayerMode.ERASE,
    "Merge": Gimp.LayerMode.MERGE,
    "Split": Gimp.LayerMode.SPLIT,
    "Lighten Only": Gimp.LayerMode.LIGHTEN_ONLY,
    "Luma Lighten Only": Gimp.LayerMode.LUMA_LIGHTEN_ONLY,
    "Screen": Gimp.LayerMode.SCREEN,
    "Dodge": Gimp.LayerMode.DODGE,
    "Addition": Gimp.LayerMode.ADDITION,
    "Darken Only": Gimp.LayerMode.DARKEN_ONLY,
    "Luma Darken Only": Gimp.LayerMode.LUMA_DARKEN_ONLY,
    "Multiply": Gimp.LayerMode.MULTIPLY,
    "Burn": Gimp.LayerMode.BURN,
    "Linear Burn": Gimp.LayerMode.LINEAR_BURN,
    "Overlay": Gimp.LayerMode.OVERLAY,
    "Soft Light": Gimp.LayerMode.SOFTLIGHT,
    "Hard Light": Gimp.LayerMode.HARDLIGHT,
    "Vivid Light": Gimp.LayerMode.VIVID_LIGHT,
    "Pin Light": Gimp.LayerMode.PIN_LIGHT,
    "Linear Light": Gimp.LayerMode.LINEAR_LIGHT,
    "Hard Mix": Gimp.LayerMode.HARD_MIX,
    "Difference": Gimp.LayerMode.DIFFERENCE,
    "Exclusion": Gimp.LayerMode.EXCLUSION,
    "Subtract": Gimp.LayerMode.SUBTRACT,
    "Grain Extract": Gimp.LayerMode.GRAIN_EXTRACT,
    "Grain Merge": Gimp.LayerMode.GRAIN_MERGE,
    "Divide": Gimp.LayerMode.DIVIDE,
    "HSV Hue": Gimp.LayerMode.HSV_HUE,
    "HSV Saturation": Gimp.LayerMode.HSV_SATURATION,
    "HSL Color": Gimp.LayerMode.HSL_COLOR,
    "HSV Value": Gimp.LayerMode.HSV_VALUE,
    "LCH Hue": Gimp.LayerMode.LCH_HUE,
    "LCH Chroma": Gimp.LayerMode.LCH_CHROMA,
    "LCH Color": Gimp.LayerMode.LCH_COLOR,
    "LCH Lightness": Gimp.LayerMode.LCH_LIGHTNESS,
    "Luminance": Gimp.LayerMode.LUMINANCE
}
