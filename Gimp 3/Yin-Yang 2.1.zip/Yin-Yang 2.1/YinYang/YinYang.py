#!/usr/bin/env python3
# Python GTK 3 Internet Reference
# athenajc.gitbooks.io/python-gtk-3-api/
# python-gtk-3-tutorial.readthedocs.io/en/latest/gallery.html
import gi       # type: ignore
import os
import sys

gi.require_version('Gimp', '3.0')
gi.require_version('GimpUi', '3.0')
gi.require_version('Gtk', '3.0')

from gi.repository import Gimp, GLib       # type: ignore

PROC_NAME = 'plug-in-yin-yang'

# Append paths to "sys.path" for GIMP's Python
# interpreter. "__file__" is GIMP's plug-in path.
n = os.path.sep
module_path = os.path.dirname(__file__) + n + "Module"

# If a folder path isn't in "sys.path", then add the path.
if module_path not in sys.path:
    sys.path.append(module_path)

from dialog import PluginDialog       # type: ignore
from output import _


class YinYang(Gimp.PlugIn):
    """Initialize the plug-in with GIMP 3."""

    def do_query_procedures(self):
        return [PROC_NAME]

    def do_set_i18n(self, name):
        # Support language translation.
        return True, 'gimp30-python', None

    def do_create_procedure(self, name):
        """
        Define plug-in so that it can be run.

        name: string
            Is the name of the plug-in and is sourced from PROC_NAME.
        """
        procedure = Gimp.ImageProcedure.new(
            self,
            name,
            Gimp.PDBProcType.PLUGIN,
            self.run,
            None               # run data
        )
        # no image required
        procedure.set_sensitivity_mask(Gimp.ProcedureSensitivityMask.ALWAYS)

        procedure.set_menu_label("_Yin Yang…")
        procedure.add_menu_path('<Image>/Filters/Render/')
        procedure.set_documentation(
            # tooltip
            _("Create a Yin-Yang symbol or animation."),

            # Plug-in Browser blurb
            _(
                "Create a new image, is non-destructive,"
                " and does not require an open image."
            ),
            name
        )
        procedure.set_attribution("Charles Bartley", "Charles Bartley", "2024")
        return procedure

    def run(self, procedure, run_mode, *arg):
        """
        Produce layer output.

        procedure: Gimp.ImageProcedure
            Manage plug-in.

        run_mode: enum
            Gimp.RunMode

        arg: tuple
            n_drawables: int
                Is the number of active drawables in the image.
                not used

            drawables: list
                active drawable
                [drawable, ...]
                not used

            args: Gimp.ValueArray
                How is this used?
                Has a length() function that could be useful.
                not used

            run_data: value
                Relayed from the 'do_create_procedure'.
                not used
        """
        # Check run mode. If interactive create
        # dialog, otherwise use previous settings.
        if run_mode == Gimp.RunMode.INTERACTIVE:
            Gimp.context_push()

            # The image is up-scaled instead.
            Gimp.context_set_antialias(False)
            Gimp.context_set_feather(False)

            Gimp.context_set_interpolation(Gimp.InterpolationType.NOHALO)
            Gimp.context_set_gradient(Gimp.Gradient.get_by_name("Default"))
            Gimp.context_set_gradient_blend_color_space(
                Gimp.GradientBlendColorSpace.RGB_PERCEPTUAL
            )
            PluginDialog()
            Gimp.displays_flush()
            Gimp.context_pop()

        else:
            # Use previous settings.
            # This is dependent on the shelf which is a GIMP WIP.
            pass

        return procedure.new_return_values(
            Gimp.PDBStatusType.SUCCESS, GLib.Error()
        )


Gimp.main(YinYang.__gtype__, sys.argv)
