#!/usr/bin/env python3
from gi.repository import Gimp, GLib   # type: ignore

# Translate enum for faster look-ups.
# ChannelOps
INTERSECT = Gimp.ChannelOps.INTERSECT
REPLACE = Gimp.ChannelOps.REPLACE
SUBTRACT = Gimp.ChannelOps.SUBTRACT

# MaskApplyMode
APPLY = Gimp.MaskApplyMode.APPLY
DISCARD = Gimp.MaskApplyMode.DISCARD

# AddMaskType
COPY = Gimp.AddMaskType.COPY
SELECTION = Gimp.AddMaskType.SELECTION

ALL = Gimp.HueRange.ALL
RGB_PERCEPTUAL = Gimp.LayerColorSpace.RGB_PERCEPTUAL
CHANNEL_TYPE = (
    Gimp.ChannelType.GRAY,
    Gimp.ChannelType.RED,
    Gimp.ChannelType.GREEN,
    Gimp.ChannelType.BLUE
)


def _(message):
    """
    Translate English to local language.

    message: string
        to translate

    Return: string
        translated
    """
    return GLib.dgettext(None, message)


def clone_layer(j, z, parent):
    """
    Create a clone of a layer and insert it above its originator.
    If the layer has a mask, apply the mask to the layer's alpha.

    j: Gimp.Image
        Has layer.

    z: Gimp.Layer
        Copy.

    parent: Gimp.GroupLayer or None
        Alternate insert position by parent existence.

    Return: Gimp.Layer
        newly created
    """
    a = len(parent.get_children()) if parent else get_layer_offset(j, z)
    z1 = z.copy()

    j.insert_layer(z1, parent, a)

    if z1.get_mask():
        z1.set_apply_mask(True)
        z1.remove_mask(APPLY)

    # Make smoother mask.
    z1.set_composite_space(RGB_PERCEPTUAL)
    return z1


def copy_layer(image, layer):
    """
    Create a copy of a layer and insert it at the top of the image.

    image: Gimp.Image
        Has layer.

    layer: Gimp.Layer
        Copy.

    Return: Gimp.Layer
        newly created
    """
    z = layer.copy()

    image.insert_layer(z, None, 0)

    if z.get_mask():
        z.set_apply_mask(True)
        z.remove_mask(APPLY)

    # Make smoother mask.
    z.set_composite_space(RGB_PERCEPTUAL)
    return z


def delete_empty_group(j, q):
    """
    Delete GroupLayer with no children.

    j: Gimp.Image
        WIP

    q: list
        [GroupLayer, ...]
    """
    for z in q:
        if not z.get_children():
            j.remove_layer(z)


def get_layer_offset(image, layer):
    """
    Fetch the layer's offset from the top of it's parent layer.

    image: Gimp.Image
        Has layer.

    layer: Gimp.Layer
        Check its position.

    Return: int
        offset
    """
    procedure = Gimp.get_pdb().lookup_procedure('gimp-image-get-item-position')
    config = procedure.create_config()

    for q in (('image', image), ('item', layer)):
        config.set_property(*q)
    return procedure.run(config).index(1)


def hide_group_layer(z):
    """
    Hide grouped layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    """
    for z1 in z.get_children():
        id_ = z1.get_id()

        if Gimp.Item.id_is_group_layer(id_):
            # recursive:
            hide_group_layer(z1)
        else:
            if z1.get_visible():
                z1.set_visible(False)


def hide_image_layer(z):
    """
    Hide all layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    """
    for z1 in z.get_layers():
        id_ = z1.get_id()

        if Gimp.Item.id_is_group_layer(id_):
            # recursive:
            hide_group_layer(z1)
        else:
            if z1.get_visible():
                z1.set_visible(False)


def make_component_channel(image, name, type_):
    """
    Make a component channel from an image.

    image: Gimp.Image
        Has component.

    name: string
        Name the channel.

    type_: Gimp.ChannelType
        Create an alpha channel based on this type.

    Return: Gimp.Channel
        newly created
    """
    procedure = Gimp.get_pdb().lookup_procedure(
        'gimp-channel-new-from-component'
    )
    config = procedure.create_config()

    for q in (
        ('image', image),
        ('component', type_),
        ('name', name)
    ):
        config.set_property(*q)

    result = procedure.run(config)
    return result.index(1)


def restore_group_visibility(z, d):
    """
    Show grouped layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    d: dict
        Has layer visibility.
        {layer id: is visible bool}
    """
    for z1 in z.get_children():
        id_ = z1.get_id()

        if Gimp.Item.id_is_group_layer(id_):
            # recursive:
            restore_group_visibility(z1, d)

        elif id_ in d:
            z1.set_visible(d[id_])
        else:
            # mask layer
            z1.set_visible(True)


def restore_image_visibility(z, d):
    """
    Show all layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    d: dict
        Has layer visibility.
        {layer id: is visible bool}
    """
    for z1 in z.get_layers():
        id_ = z1.get_id()

        if Gimp.Item.id_is_group_layer(id_):
            # recursive:
            restore_group_visibility(z1, d)

        elif id_ in d:
            z1.set_visible(d[id_])
        else:
            # mask layer
            z1.set_visible(True)


def save_group_visibility(z, d):
    """
    Store the visibility state of grouped layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    d: dict
    d: dict
        Store layer visibility.
        {layer id: is visible bool}
    """
    for z1 in z.get_children():
        id_ = z1.get_id()

        if Gimp.Item.id_is_group_layer(id_):
            # recursive
            save_group_visibility(z1, d)
        else:
            d[id_] = z1.get_visible()


def save_image_visibility(z, d):
    """
    Store the visibility state of all layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    d: dict
    d: dict
        Store layer visibility.
        {layer id: is visible bool}
    """
    for z1 in z.get_layers():
        id_ = z1.get_id()

        if Gimp.Item.id_is_group_layer(id_):
            # recursive
            save_group_visibility(z1, d)
        else:
            d[id_] = z1.get_visible()


class Output:
    """Create mask-type layer output."""

    def __init__(self):
        self._has_midtone = False
        self._last_dark = self._last_light = 0
        self._is_red = \
            self._image = \
            self._sel_dark_q = \
            self._parent = \
            self._is_blue = \
            self._is_dark = \
            self._sel_light_q = \
            self._is_deep = \
            self._is_gray = \
            self._is_wide = \
            self._is_alpha = \
            self._is_black = \
            self._is_green = \
            self._is_group = \
            self._is_light = \
            self._is_white = \
            self._is_darker = \
            self._is_shadow = \
            self._is_bright = \
            self._midtone_q = \
            self._alpha_type = \
            self._is_lighter = \
            self._is_minimal = \
            self._is_greatest = \
            self._is_expanded = \
            self._is_brilliant = \
            self._is_red_group = \
            self._inverse_mid_q = \
            self._is_blue_group = \
            self._is_dark_group = \
            self._is_gray_group = \
            self._component_name = \
            self._is_green_group = \
            self._is_light_group = \
            self._is_midtone_group = None

        self._mask_light_q = None

        # [layer created with mask, ...]
        self._mask_q = []

        # [created group layer, ...]
        self._group_q = []

        # {channel key: channel}
        self._channel_d = {}

    def _check_fail(self, q, z, fail_q):
        """
        Check if mask generation failed at some point.

        q: list
            [failed mask-type, ...]
            [mask type, ...]

        z: Gimp.Layer
            masking

        fail_q: list
            [expanded failed mask type, ...]
            [(layer name, mask type), ...]
        """
        if q:
            n = z.get_name()
            for n1 in q:
                fail_q += [(n, self._component_name, n1)]

    def _create_all_mask(self, j, z):
        """
        Create Light, Dark, and Midtone mask-group layer.

        j: Gimp.Image
            WIP

        z: Gimp.Layer
            Copy and make a masked layer.
        """
        parent = self._parent

        self._create_polar_mask(
            j, z,
            (LIGHT_SEL, self._is_light_group, self._mask_light_q, 'light', 0)
        )

        self._parent = parent

        self._create_midtone_mask(j, z)

        self._parent = parent
        self._create_polar_mask(
            j, z,
            (DARK_SEL, self._is_dark_group, self._mask_dark_q, 'dark', 1)
        )

    def _create_group(self, image, parent, position, n):
        """
        Create a layer group immediately above a layer.

        image: Gimp.Image
            WIP

        parent: Gimp.GroupLayer or None
            Insert new group here.

        position: int
            Is the offset from the top of the parent.

        n: string
            Give the layer group a name.
        """
        # name source, 'z'
        group = Gimp.GroupLayer.new(image, n)
        self._group_q += [group]

        image.insert_layer(group, parent, position)
        return group

    def _create_midtone_mask(self, j, z):
        """
        Create Midtone mask-type layer from Light and Dark selection.

        j: Gimp.Image
            WIP

        z: Gimp.Layer
            masking
        """
        if self._is_midtone_group:
            if self._parent:
                n = f'{self._parent.get_name()} Midtone'
                a = len(self._parent.get_children())
            else:
                n = f'{z.get_name()} {self._component_name} Midtone'
                a = get_layer_offset(j, z)
            self._parent = self._create_group(j, self._parent, a, n)

        # Midtone name and channel index, 'i'.
        for i, m in enumerate(self._midtone_q):
            # Is the widget option checked?
            if m:
                self._mask_layer(j, z, 'midtone', MID_NAME, i)

    def _create_polar_mask(self, j, z, q):
        """
        Create Light and Dark mask-type layer from saved channel.

        j: Gimp.Image
            WIP

        z: Gimp.Layer
            masking

        q: tuple
            (
                mask type name,
                make group flag,
                make mask-type,
                polar key,
                polar index
            )
        """
        k = q[3]
        name_q = q[0]
        check_q = q[2]

        # Is there a new mask-type layer group, '1'?
        if q[1]:
            n = POLAR_GROUP[q[4]]

            if self._parent:
                n = f'{self._parent.get_name()} {n} Group'
                a = len(self._parent.get_children())
            else:
                n = f'{z.get_name()} {self._component_name} {n} Group'
                a = get_layer_offset(j, z)
            self._parent = self._create_group(j, self._parent, a, n)

        # Create mask-layer for the Light or Dark.
        for i1, m in enumerate(check_q):
            # Is the widget option checked?
            if m:
                # The order is reversed due to the desirable stacking, '4'.
                self._mask_layer(j, z, k, name_q, 4 - i1)

    def _do_alpha_type(self, j, z):
        """
        For each layer, there are one or more Alpha Channel.

        j: Gimp.Image
            WIP

        z: Gimp.Layer
            masking

        Return: list
            failed mask type
            [(layer name, alpha type, mask_type), ...]
        """
        fail_q = []
        group = self._parent

        for i, q in enumerate((
            (self._is_gray_group, self._is_gray),
            (self._is_red_group, self._is_red),
            (self._is_green_group, self._is_green),
            (self._is_blue_group, self._is_blue)
        )):
            group_m, component_m = q
            if component_m:
                if group_m:
                    if group:
                        a = len(group.get_children())

                    else:
                        a = get_layer_offset(j, z)
                    self._parent = self._create_group(
                        j,
                        self._parent,
                        a,
                        f'{z.get_name()} {ALPHA[i]}'
                    )

                self._component_name = ALPHA[i]
                self._alpha_type = CHANNEL_TYPE[i]
                fail_q += self._make_all_selection(j, z)
                self._create_all_mask(j, z)

            self._remove_channels(j)

            # Could be Alpha, Alpha Type, or None.
            self._parent = group
        return fail_q

    def _get_channel(self, k):
        """
        Retrieve a saved selection's channel.

        k: string
            key to channel dict

        Return: Gimp.Channel or None
        """
        return self._channel_d.get(k)

    def _get_group_offset(self, j, z):
        """
        A layer group's offset is dependent on the status of 'self._parent'.

        j: Gimp.Image
            WIP

        z: Gimp.Layer
            Has position.

        Return: int
            Is the insert position for a new layer group.
        """
        if self._parent:
            z = self._parent
        return get_layer_offset(j, z)

    def _make_all_selection(self, j, layer):
        """
        Make Light, Midtone, and Dark selection for a given layer.

        j: Gimp.Image
            WIP

        layer: Gimp.Layer
            Derive selection.

        Return: list
            [(layer name, mask-type string), ...]
            Record selection failure.
        """
        # layer for selection, 'z'
        z = copy_layer(j, layer)

        z.set_visible(True)

        fail_q = []
        q = self._make_polar_selection(z, 'light', self._last_light)

        self._check_fail(q, layer, fail_q)

        if z.get_mask():
            z.remove_mask(DISCARD)

        q = self._make_polar_selection(
            z, 'dark', self._last_dark, is_dark=True
        )

        self._check_fail(q, layer, fail_q)
        j.remove_layer(z)

        q = self._make_midtone_selection(j)

        self._check_fail(q, layer, fail_q)
        return fail_q

    def _make_midtone_selection(self, j):
        """
        Create Midtone mask selection.

        j: Gimp.Image
            WIP

        Return: list
            Is empty if there is no mask failure.
            If there is mask failure, then list contains mask-type string.
            e.g. [Minimum, Expanded, Wide, Greatest]
        """
        fail = []

        if self._has_midtone:
            for i, m in enumerate(self._inverse_mid_q):
                i1 = 3 - i

                # checked Midtone option, 'm'
                if m:
                    # Skip the Light and Dark channels, '1'.
                    light = self._channel_d.get(('light', i + 1))
                    dark = self._channel_d.get(('dark', i + 1))

                    if light and dark:
                        Gimp.Selection.all(j)
                        j.select_item(SUBTRACT, light)
                        j.select_item(SUBTRACT, dark)

                        # The Midtone index is offset
                        # because of the None in MIDTONE, '1'.
                        channel = self._save_selection(('midtone', i))
                        if not channel:
                            fail.append(MID_NAME[i])

                    else:
                        fail.append(MID_NAME[i])
        return fail

    def _make_polar_selection(self, clone, k, range_a, is_dark=False):
        """
        Make mask selection.

        clone: Gimp.Layer
            Is mask gen focus.

        k: value
            mask-group-type key

        range_a: int
            Is the selection iteration value needed by the mask-group-type.

        is_dark: bool
            If True, then the clone layer is inverted.

        Return: list
            Is empty if there is no mask failure.
            If there is mask failure, then list contains the mask-type.
            e.g. [Light, Dark, ...]
        """
        # Contain mask failure.
        fail = []

        if range_a:
            j = self._image

            if is_dark:
                Gimp.Selection.none(j)
                clone.invert(False)

            # Convert grayscale pixels into a channel where black
            # equates to transparent and white to opaque.
            start_channel = make_component_channel(
                j, k, self._alpha_type
            )

            j.insert_channel(start_channel, None, 0)
            j.select_item(REPLACE, start_channel)

            channel = self._save_selection((k, 0))

            if not channel:
                if (self._sel_light_q, self._sel_dark_q)[is_dark][0]:
                    fail.append((LIGHT_SEL, DARK_SEL)[is_dark][0])

            for i in range(1, range_a):
                if channel:
                    Gimp.Selection.invert(j)

                    # a temporary channel key, '-1'
                    inverted = self._save_selection(-1)

                    if inverted:
                        j.select_item(REPLACE, channel)
                        j.select_item(SUBTRACT, inverted)

                        # temp key, '-1'
                        self._remove_channel(-1)

                        channel = self._save_selection((k, i))
                        if not channel:
                            if (
                                self._sel_light_q, self._sel_dark_q
                            )[is_dark][i]:
                                fail.append((LIGHT_SEL, DARK_SEL)[is_dark][i])
                    else:
                        if (self._sel_light_q, self._sel_dark_q)[is_dark][i]:
                            fail.append((LIGHT_SEL, DARK_SEL)[is_dark][i])
                else:
                    if (self._sel_light_q, self._sel_dark_q)[is_dark][i]:
                        fail.append((LIGHT_SEL, DARK_SEL)[is_dark][i])
            j.remove_channel(start_channel)
        return fail

    def _make_selection(self, k, op):
        """
        Select a saved channel.

        k: string or tuple
            key to channel in the channel dict

        op: Gimp.ChannelOps
            ADD, SUBTRACT, INTERSECT, REMOVE
        """
        channel = self._get_channel(k)

        # A saved channel can be None, so check.
        if channel:
            self._image.select_item(op, channel)

    def _mask_layer(self, j, layer, k, name_q, i):
        """
        Create a mask layer.

        j: Gimp.Image
            WIP

        layer: Gimp.Layer
            Clone and give mask to its clone.

        k: string
            Define mask-type.
            Find saved channel.

        name_q: tuple
            (mask option, ...)
            Name the clone layer.

        i: int
            Index to mask type.
        """
        # Get the selection channel for the mask.
        channel = self._get_channel((k, i))
        if channel:
            z = clone_layer(j, layer, self._parent)

            self._mask_q.append(z)
            j.select_item(REPLACE, channel)

            # Create the mask from the selection.
            mask = z.create_mask(SELECTION)

            z.add_mask(mask)
            z.set_name(
                f"{layer.get_name()} {self._component_name} {name_q[i]}"
            )
            z.set_visible(False)

    def _remove_channels(self, j):
        """After a layer is done, remove saved channel."""
        for a in self._channel_d.values():
            if a:
                j.remove_channel(a)
        self._channel_d = {}

    def _remove_channel(self, k):
        """
        Remove a single channel from the image.

        k: value
            Identify the channel.
            channel key for the channel dict
        """
        channel = self._channel_d.get(k)
        if channel:
            self._image.remove_channel(channel)
            self._channel_d.pop(k)

    def _save_selection(self, k):
        """
        Save the current selection. Remember the
        saved channel with the channel dict.

        k: string
            Is the key for the channel dict.
            Identify the channel.

        Return: Gimp.Channel or None
            newly created
        """
        j = self._image

        if Gimp.Selection.is_empty(j):
            channel = self._channel_d[k] = None

        else:
            selection = j.get_selection()
            channel = self._channel_d[k] = selection.save(j)
        return channel

    def _set_dark_option(self):
        """
        Record the Dark mask-group settings.

        Return: tuple
            Is sorted by mask-type scope from more to less.
        """
        self._sel_dark_q = (
            self._is_dark,
            self._is_darker,
            self._is_shadow,
            self._is_deep,
            self._is_black
        )
        self._mask_dark_q = self._sel_dark_q[::-1]

    def _set_light_option(self):
        """
        Record the Light mask-group settings.

        Return: tuple
            Is sorted by mask-type scope from more to less.
        """
        self._sel_light_q = (
            self._is_light,
            self._is_lighter,
            self._is_bright,
            self._is_brilliant,
            self._is_white
        )
        self._mask_light_q = self._sel_light_q[::-1]

    def _set_mask_range(self):
        """
        Determine the last mask selection needed for each
        mask-group and record it as a range for later processing.

        Midtone mask is dependent on Light and Dark selections,
        so a Midtone mask-type also effects the last selection
        needed for both Light and Dark.
        """
        self._set_light_option()
        self._set_midtone_option()
        self._set_dark_option()

        for i, m in enumerate(self._sel_light_q):
            if m:
                # Set for range production with a zero 'i', '1'.
                self._last_light = i + 1

        for i, m in enumerate(self._inverse_mid_q):
            if m:
                self._has_midtone = True

                # Light and Dark mask-groups start with
                # there 2nd member to make a Midtone, '2'.
                if i + 2 > self._last_light:
                    # the missing Midtone, '1'
                    self._last_light = i + 2
                if i + 2 > self._last_dark:
                    self._last_dark = i + 2
        for i, m in enumerate(self._sel_dark_q):
            if m:
                if self._last_dark < i + 1:
                    self._last_dark = i + 1

    def _set_midtone_option(self):
        """
        Record the Midtone mask-group settings.

        Return: tuple
            Is sorted by mask-type from less to more.
        """
        self._midtone_q = (
            self._is_minimal,
            self._is_expanded,
            self._is_wide,
            self._is_greatest
        )
        self._inverse_mid_q = self._midtone_q[::-1]

    def create(self, d, layer_q):
        """
        Make mask layer.

        d: dict
            {widget key: widget value}
            Extract value from the plug-in dialog.

        layer_q: list
            [Selected Gimp.Layer, ...]
            Each layer is processed with the mask settings.
        """
        fail_q = []
        visible_d = {}

        for k, v in d.items():
            setattr(self, f'_is_{k.lower()}', v)

        j = self._image = layer_q[0].get_image()

        save_image_visibility(j, visible_d)
        hide_image_layer(j)
        self._set_mask_range()
        j.undo_disable()

        # layer, 'z'
        for z in layer_q:
            if self._is_alpha:
                self._parent = self._create_group(
                    j,
                    z.get_parent(),
                    get_layer_offset(j, z),
                    f'{z.get_name()} {_("Alpha")}'
                )

            fail_q += self._do_alpha_type(j, z)

        restore_image_visibility(j, visible_d)
        delete_empty_group(j, self._group_q)
        j.undo_enable()
        Gimp.displays_flush()
        return self._mask_q, fail_q


# Describe mask. Describe widget. Translate to
# mask index. Init Output attribute.
LIGHT = (
    _("White"),
    _("Brilliant"),
    _("Bright"),
    _("Lighter"),
    _("Light")
)
LIGHT_SEL = LIGHT[::-1]
MID_NAME = (
    _("Minimal"),
    _("Expanded"),
    _("Wide"),
    _("Greatest")
)
MIDTONE = (None,) + MID_NAME
DARK = (
    _("Black"),
    _("Deep"),
    _("Shadow"),
    _("Darker"),
    _("Dark")
)
DARK_SEL = DARK[::-1]
ALPHA = _("Gray"), _("Red"), _("Green"), _("Blue")
POLAR_GROUP = _("Light"), _("Dark")
