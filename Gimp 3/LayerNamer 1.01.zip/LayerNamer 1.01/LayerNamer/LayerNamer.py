#!/usr/bin/env python3
import gi       # type: ignore
import sys

gi.require_version('Gimp', '3.0')
gi.require_version('GimpUi', '3.0')
gi.require_version('Gtk', '3.0')

from gi.repository import Gimp, GimpUi, GLib, GObject      # type: ignore

PROC_NAME = 'plug-in-layer-namer'


def _(message):
    """
    Translate English to local language.

    message: string
        Translate.

    Return: string
        Is the translated message.
    """
    return GLib.dgettext(None, message)


def find_replace_group(z, find, replace):
    """
    Find and replace a character string in layer name
    found in an layer group. Is recursive.

    z: Gimp.GroupLayer
        Is layer and has child layer.

    find: string
        Find a match.

    replace: string
        Replace a match.
    """
    for z1 in z.get_children():
        find_and_replace_layer(z1, find, replace)
        if Gimp.Item.id_is_group_layer(z1.get_id()):
            find_replace_group(z1, find, replace)


def find_replace_image(j, find, replace):
    """
    Find and replace a character string in layer name
    found in an image.

    j: Gimp.Image
        Has layer.

    find: string
        Find a match.

    replace: string
        Replace a match.
    """
    for z in j.get_layers():
        find_and_replace_layer(z, find, replace)
        if Gimp.Item.id_is_group_layer(z.get_id()):
            find_replace_group(z, find, replace)


def find_and_replace_layer(z, find, replace):
    """
    Find a layer name match with a find string. On match, rename
    the layer with the matched string.

    z: Gimp.Layer
        Has name.

    find: string
        Find in layer name.

    replace: string
        Replace matched find string.
    """
    n = z.get_name()
    n1 = n.replace(find, replace)
    if n != n1:
        if n1:
            z.set_name(n1)
        else:
            Gimp.message(_("The replacement would create an empty layer name."))


def layer_namer(procedure, run_mode, image, drawables, config, data):
    if run_mode == Gimp.RunMode.INTERACTIVE:
        GimpUi.init(PROC_NAME)

        dialog = GimpUi.ProcedureDialog(procedure=procedure, config=config)

        dialog.set_title("Layer Namer 1.01")
        dialog.fill(None)

        if not dialog.run():
            dialog.destroy()
            return procedure.new_return_values(
                Gimp.PDBStatusType.CANCEL, GLib.Error()
            )
        else:
            dialog.destroy()

    # Find and replace string values.
    find = config.get_property('find')
    replace = config.get_property('replace')

    image.undo_group_start()

    if find:
        if find != replace:
            find_replace_image(image, find, replace)
        else:
            Gimp.message(_("There was no character string to replace."))

    else:
        Gimp.message(_("There was no character string to find."))

    Gimp.displays_flush()

    image.undo_group_end()
    return procedure.new_return_values(
        Gimp.PDBStatusType.SUCCESS, GLib.Error()
    )


class LayerNamer(Gimp.PlugIn):
    """Initialize the plug-in with GIMP 3."""

    def do_query_procedures(self):
        return [PROC_NAME]

    def do_set_i18n(self, name):
        # Support language translation.
        return True, 'gimp30-python', None

    def do_create_procedure(self, name):
        procedure = Gimp.ImageProcedure.new(
            self,
            name,
            Gimp.PDBProcType.PLUGIN,
            layer_namer,
            None
        )
        procedure.set_image_types("*")
        procedure.set_sensitivity_mask(
            Gimp.ProcedureSensitivityMask.DRAWABLE |
            Gimp.ProcedureSensitivityMask.DRAWABLES
        )
        procedure.set_documentation(
            # tooltip
            _("Find and replace layer character for an entire image."),

            # Plug-in Browser blurb
            _("Find and replace characters in an image's layer collection."),
            name
        )
        procedure.set_menu_label("La_yer Namer…")
        procedure.set_attribution("Charles Bartley", "Charles Bartley", "2024")
        procedure.add_menu_path('<Image>/Layer/')
        procedure.add_string_argument(
            "find",
            _("_Find\t"),
            _("Find"),
            _(".png"),
            GObject.ParamFlags.READWRITE
        )
        procedure.add_string_argument(
            "replace",
            _("R_eplace\t"),
            _("Replace"),
            _(""),
            GObject.ParamFlags.READWRITE
        )
        return procedure


Gimp.main(LayerNamer.__gtype__, sys.argv)
