#!/usr/bin/env python3
import gi                           # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GLib      # noqa


def _(n):
    """
    Translate English to local language.

    n: string
        Translate.

    Return: string
        translated
    """
    return GLib.dgettext(None, n)


# String_______________________________________________________________________
ACCEPT = _("_Accept")
ALL = _("All")
ANIMATE = _("Animate")
AVAILABLE_PRESET = _("Available Preset")
AZIMUTH = _("Azimuth")
BASE = _("Base")
BLUR = _("Blur")
BLUR_TIP = _(" Try equalizing with depth. ")
CANCEL = _("_Cancel")
CLOCKWISE = _("Clockwise")
COLOR = _("Color")
COLOR_TIP = _(" Red\t{} \n Green\t{} \n Blue\t{} \n Alpha\t{}")
CONFIRM_OVERWRITE = _(
    'A file with the name:\n"{}",\nalready exists. Overwrite it?'
)
CONTRAST = _("Contrast")
COUNTER_CLOCKWISE = _("Counter-Clockwise")
DEFAULT = _("Default")
DELETE = _("_Delete")
DELETE_CONFIRM = _('Do you really want to delete:\n"{}"?')
DELETE_FAIL = _("The plugin was unable to delete the file.")
DELETE_FILE = _("Delete a file.")
DEPTH = _("Depth")
DEPTH_TIP = _(" Try equalizing with blur. ")
DIVISION = _("Division")
DIVISION_TIP = _(" Set the number of heads in motion. ")
DOC_BLURB = _(
    "Create a new image, is non-destructive,"
    " and does not require an open image."
)
DOC_TIP = _("Create a Yin-Yang symbol or animation.")
ELEVATION = _("Elevation")
EMBOSS = _("Emboss")
EMPTY_PRESET = _("The loaded preset is empty.")
EXISTING_FILE = _('An existing file was found.')
EYE_WIDTH = _("Eye Width")
EYE_WIDTH_TIP = _(" Factor the Ring Width. ")
FLOW = _("Flow")
FRAME_COUNT = _("Frame Count")
GRADIENT = _("Gradient")
GROUP = _("Group")
HUE = _("Hue")
LEATHER = _("Leather")
LIGHTNESS = _("Lightness")
LOAD = _("_Load")
MANAGE = _("Manage…")
MANAGE_PRESET = _("Manage Preset")
MISSING_PRESET = _("The preset file is missing.")
MODE = _("Mode")
OPACITY = _("Opacity")
OVERLAY = _("Overlay")
PATH = _("Path")
PATTERN = _("Pattern")
PRESET_LOADED = _("The preset was loaded.")
PRESET_SAVE = _("Preset Name")
PRESET_SAVED = _("The preset was saved.")
PREVIEW = _("Preview")
RADIUS = _("Radius")
RANDOM = _("Random")
REMOVED_FILE = _("The file, {},\nwas removed.")
REVERSED = _("Reversed")
REVERSED_TIP = _(" The Yang gradient is the reverse of the Yin. ")
RIM = _("Rim")
RIM_WIDTH = _("Rim Width")
RING_SPIN_TIP = _(" Create a center hole. \n Factor the Symbol Radius. ")
RING_WIDTH = _("Ring Width")
ROTATE = _("Rotate")
SATURATION = _("Saturation")
SAVE_ = _("Save…")
SAVE = _("Save")
SAVE_FAIL = _("The plugin could not save the preset.")
SAVE_PRESET = _("Save Preset")
TIMER = _("Timer")
TIMER_TIP = _(
    " Is the wait time, in millisecond,"
    " that an animation takes between frames. "
)
TRANSPARENT_EYE = _("Transparent Eye")
TYPE_ = _("Type")
LOAD_FAIL = _("The plugin is unable to load the preset.")
YEAR = _("2024")
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

RESOURCE_KEY = 'overlay_gradient', 'pattern_1', 'pattern_2', 'pattern_3'
SEPARATOR = '-'
LAYER_MODE_Q = (
    _("Normal"),
    _("Dissolve"),
    _("Color Erase"),
    _("Erase"),
    _("Merge"),
    _("Split"),
    SEPARATOR,
    _("Lighten Only"),
    _("Luma Lighten Only"),
    _("Screen"),
    _("Dodge"),
    _("Addition"),
    SEPARATOR,
    _("Darken Only"),
    _("Luma Darken Only"),
    _("Multiply"),
    _("Burn"),
    _("Linear Burn"),
    SEPARATOR,
    _("Overlay"),
    _("Soft Light"),
    _("Hard Light"),
    _("Vivid Light"),
    _("Pin Light"),
    _("Linear Light"),
    _("Hard Mix"),
    SEPARATOR,
    _("Difference"),
    _("Exclusion"),
    _("Subtract"),
    _("Grain Extract"),
    _("Grain Merge"),
    _("Divide"),
    SEPARATOR,
    _("HSV Hue"),
    _("HSV Saturation"),
    _("HSL Color"),
    _("HSV Value"),
    SEPARATOR,
    _("LCH Hue"),
    _("LCH Chroma"),
    _("LCH Color"),
    _("LCH Lightness"),
    _("Luminance")
)
LAYER_MODE_D = {
    _("Normal"):  Gimp.LayerMode.NORMAL,
    _("Dissolve"): Gimp.LayerMode.DISSOLVE,
    _("Color Erase"): Gimp.LayerMode.COLOR_ERASE,
    _("Erase"): Gimp.LayerMode.ERASE,
    _("Merge"): Gimp.LayerMode.MERGE,
    _("Split"): Gimp.LayerMode.SPLIT,
    _("Lighten Only"): Gimp.LayerMode.LIGHTEN_ONLY,
    _("Luma Lighten Only"): Gimp.LayerMode.LUMA_LIGHTEN_ONLY,
    _("Screen"): Gimp.LayerMode.SCREEN,
    _("Dodge"): Gimp.LayerMode.DODGE,
    _("Addition"): Gimp.LayerMode.ADDITION,
    _("Darken Only"): Gimp.LayerMode.DARKEN_ONLY,
    _("Luma Darken Only"): Gimp.LayerMode.LUMA_DARKEN_ONLY,
    _("Multiply"): Gimp.LayerMode.MULTIPLY,
    _("Burn"): Gimp.LayerMode.BURN,
    _("Linear Burn"): Gimp.LayerMode.LINEAR_BURN,
    _("Overlay"): Gimp.LayerMode.OVERLAY,
    _("Soft Light"): Gimp.LayerMode.SOFTLIGHT,
    _("Hard Light"): Gimp.LayerMode.HARDLIGHT,
    _("Vivid Light"): Gimp.LayerMode.VIVID_LIGHT,
    _("Pin Light"): Gimp.LayerMode.PIN_LIGHT,
    _("Linear Light"): Gimp.LayerMode.LINEAR_LIGHT,
    _("Hard Mix"): Gimp.LayerMode.HARD_MIX,
    _("Difference"): Gimp.LayerMode.DIFFERENCE,
    _("Exclusion"): Gimp.LayerMode.EXCLUSION,
    _("Subtract"): Gimp.LayerMode.SUBTRACT,
    _("Grain Extract"): Gimp.LayerMode.GRAIN_EXTRACT,
    _("Grain Merge"): Gimp.LayerMode.GRAIN_MERGE,
    _("Divide"): Gimp.LayerMode.DIVIDE,
    _("HSV Hue"): Gimp.LayerMode.HSV_HUE,
    _("HSV Saturation"): Gimp.LayerMode.HSV_SATURATION,
    _("HSL Color"): Gimp.LayerMode.HSL_COLOR,
    _("HSV Value"): Gimp.LayerMode.HSV_VALUE,
    _("LCH Hue"): Gimp.LayerMode.LCH_HUE,
    _("LCH Chroma"): Gimp.LayerMode.LCH_CHROMA,
    _("LCH Color"): Gimp.LayerMode.LCH_COLOR,
    _("LCH Lightness"): Gimp.LayerMode.LCH_LIGHTNESS,
    _("Luminance"): Gimp.LayerMode.LUMINANCE
}


def get_division_list():
    return _("2"), _("4"), _("6"), _("8"), _("10"), _("12")


def get_gradient_list():
    return Gimp.gradients_get_list("")


def get_mode_list():
    return LAYER_MODE_Q


def get_pattern_list():
    return Gimp.patterns_get_list("")


TYPE_FOLLOWING_D = {
    "Color": (
        'color_label', 'color_hbox', 'random_color_label', 'random_hbox'
    ),
    "Pattern": ('pattern_label', 'pattern_hbox')
}


class DefKey:
    """Define item key for AnyGroup definition dict."""

    # tuple; Initialize a SpinButton's Adjustment.
    ADJUSTMENT = 'adjustment'

    # int; Set the margin around a Grid.
    BORDER_WIDTH = 'border_width'

    # Define Container occupant.
    CHILD = 'child'

    # int; Assign a Grid column for a GridCell.
    COLUMN = 'column'

    # int; Allocate Grid column for a GridRow.
    COLUMNS = 'columns'

    # int; Create margin space around Grid column.
    COLUMN_SPACING = 'column_space'

    # int; Set the precision of a SpinButton.
    DIGITS = 'digits'

    # function; Retrieve a list for loading a ComboBoxText.
    GET_LIST = 'get_list'

    # Set the justification of a Gtk.Widget.
    HALIGN = 'halign'

    # bool; Make a Gtk Box divvy space equally.
    HOMOGENEOUS = 'homogeneous'

    # bool; Distinguish a definition as a Widget and not a Container.
    IS_WIDGET = 'is_widget'

    # Identify the Widget as having a following.
    # A leader desires access to its following from a
    # a method identified and connected, by AnyGroup,
    # from an attribute-id string.
    LEADER = 'leader'

    # tuple; Limit the range of a randomize response value.
    # Identify Widget as a randomizer.
    LIMIT = 'limit'

    # tuple; not unlike LEADER, but for RadioGroup.
    MEMBER = 'member'

    # tuple; Give a Widget an alignment. (top, bottom, left, right)
    PADDING = 'padding'

    # int; Create a vertical margin around a Grid row.
    ROW_SPACING = 'row_spacing'

    # tuple; Connect Widget with a handler.
    SIGNAL = 'signal'

    # string; Pass a display descriptor.
    TEXT = 'text'

    # string; Set a Widget's tooltip.
    TOOLTIP = 'tooltip'

    # Widget class; Identify the class of a Container or Widget.
    TYPE = 'type'

    # Set Widget value during its initialization.
    VALUE = 'value'

    # int; Provide a GridCell cell width in a Grid.
    WIDTH = 'width'

    # float; Set the horizontal position of a Widget.
    X_ALIGN = 'x_align'
