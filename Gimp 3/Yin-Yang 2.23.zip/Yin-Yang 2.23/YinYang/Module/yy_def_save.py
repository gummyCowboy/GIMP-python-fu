#!/usr/bin/env python3
from yy_constant import PATH, PRESET_SAVE, DefKey as dk
from yy_container import Grid, GridCell, GridRow
from yy_preset import Preset
from yy_widget import EntrySave, Label
import gi                       # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk   # noqa

CHILD = dk.CHILD
COLUMN = dk.COLUMN
COLUMNS = dk.COLUMNS
IS_WIDGET = dk.IS_WIDGET
SIGNAL = dk.SIGNAL
TEXT = dk.TEXT
TYPE = dk.TYPE
VALUE = dk.VALUE


def init_path_reflect_label(label):
    """
    Initialize the path reflect label with the preset's path.

    label: Gtk.Label
        Display the preset file path.
    """
    label.set_label(Preset.path)


NAME_ENTRY = {
    IS_WIDGET: True,
    dk.LEADER: (
        ('path_reflect_label',),
        (('changed', 'on_save_entry_change'),)
    ),
    TYPE: EntrySave,
    VALUE: ""
}

# Label________________________________________________________________________
NAME_LABEL = {TEXT: PRESET_SAVE}
PATH_LABEL = {TEXT: PATH}
PATH_REFLECT_LABEL = {
    SIGNAL: (('realize', init_path_reflect_label),), TEXT: ""
}
for d in (NAME_LABEL, PATH_LABEL, PATH_REFLECT_LABEL):
    d.update({IS_WIDGET: True, TYPE: Label, dk.HALIGN: Gtk.Align.START})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

NAME_CELL_0 = {
    CHILD: {'name_label': NAME_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
NAME_CELL_1 = {
    CHILD: {'name_entry': NAME_ENTRY},
    COLUMN: 1,
    TYPE: GridCell
}
PATH_CELL_0 = {
    CHILD: {'path_label': PATH_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
PATH_CELL_1 = {
    CHILD: {'path_reflect_label': PATH_REFLECT_LABEL},
    COLUMN: 1,
    TYPE: GridCell
}
GRID_ROW = {
    'name': {
        CHILD: {
            '0': NAME_CELL_0,
            '1': NAME_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'path': {
        CHILD: {
            '0': PATH_CELL_0,
            '1': PATH_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
}
SAVE_DEF = {
    'g': {
        TYPE: Grid,
        CHILD: GRID_ROW
    }
}
