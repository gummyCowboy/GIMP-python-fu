#!/usr/bin/env python3
from yy_constant import DefKey as dk
from yy_container import Grid, GridCell, GridRow, HBox, Notebook, Page
from yy_def_main_cell import (
    ANIMATE_CELL,
    AZIMUTH_CELL_0, AZIMUTH_CELL_1,
    BLUR_CELL_0, BLUR_CELL_1,
    COLOR_CELL_0,
    COLOR_VBOX_1, COLOR_VBOX_2, COLOR_VBOX_3,
    CONTRAST_CELL_0, CONTRAST_CELL_1,
    DEPTH_CELL_0, DEPTH_CELL_1,
    DIALOG_BUTTON_ROW,
    DIVISION_CELL_0, DIVISION_CELL_1,
    ELEVATION_CELL_0, ELEVATION_CELL_1,
    EMBOSS_CELL,
    EMBOSS_MODE_CELL_0, EMBOSS_MODE_CELL_1,
    EMBOSS_OPACITY_CELL_0, EMBOSS_OPACITY_CELL_1,
    EMBOSS_TYPE_CELL_0,
    EYE_W_CELL_0, EYE_W_CELL_1,
    FLIP_CELL_0,
    FRAME_COUNT_CELL_0, FRAME_COUNT_CELL_1,
    GRADIENT_MODE_CELL_0, GRADIENT_MODE_CELL_1,
    GRADIENT_OPACITY_CELL_0, GRADIENT_OPACITY_CELL_1,
    OPACITY_CELL_0,
    OVERLAY_CELL,
    OVERLAY_GRADIENT_CELL_0, OVERLAY_GRADIENT_CELL_1,
    PATTERN_CELL_0,
    PATTERN_VBOX_1, PATTERN_VBOX_2, PATTERN_VBOX_3,
    RADIUS_CELL_0, RADIUS_CELL_1,
    RANDOM_COLOR_CELL_0,
    RANDOM_BUTTON_ROW,
    RANDOM_ROW,
    REVERSED_CELL,
    OPACITY_VBOX_3,
    RIM_W_CELL_0, RIM_W_CELL_1, RING_W_CELL_0,
    RING_W_CELL_1,
    TIMER_CELL_0, TIMER_CELL_1,
    TRANSPARENT_EYE_CELL,
    TYPE_CELL_0, TYPE_CELL_1,
    OPACITY_VBOX_1, OPACITY_VBOX_2
)
from yy_def_main_widget import FLIP_RADIO, EMBOSS_TYPE_RADIO
import gi                           # type: ignore
gi.require_version('Gdk', '3.0')

"""Define container with child container."""

CHILD = dk.CHILD
COLUMN = dk.COLUMN
COLUMNS = dk.COLUMNS
TEXT = dk.TEXT
TYPE = dk.TYPE
WIDTH = dk.WIDTH

COLOR_ROW = {
    CHILD: {
        '1': COLOR_VBOX_1,
        '2': COLOR_VBOX_2,
        '_color_vbox_3': COLOR_VBOX_3
    },
    TYPE: HBox
}
COLOR_CELL_1 = {
    CHILD: {'_color_hbox': COLOR_ROW},
    COLUMN: 1,
    WIDTH: 3,
    TYPE: GridCell
}
DIALOG_CELL_0 = {
    CHILD: {'1': DIALOG_BUTTON_ROW},
    COLUMN: 0,
    WIDTH: 2,
    TYPE: GridCell
}
EMBOSS_TYPE_CELL_1 = {
    CHILD: {'emboss_type': EMBOSS_TYPE_RADIO},
    COLUMN: 1,
    WIDTH: 2,
    TYPE: GridCell
}
FLIP_CELL_1 = {
    CHILD: {'flip': FLIP_RADIO},
    COLUMN: 1,
    WIDTH: 2,
    TYPE: GridCell
}
GRID_RANDOM_ROW = {
    CHILD: {'1': RANDOM_ROW},
    COLUMNS: 2,
    TYPE: GridRow
}
PATTERN_ROW = {
    CHILD: {
        '1': PATTERN_VBOX_1,
        '2': PATTERN_VBOX_2,
        '_pattern_vbox_3': PATTERN_VBOX_3
    },
    TYPE: HBox
}
PATTERN_CELL_1 = {
    CHILD: {'1': PATTERN_ROW},
    COLUMN: 1,
    WIDTH: 3,
    TYPE: GridCell
}
RANDOM_COLOR_CELL_1 = {
    CHILD: {'_random_hbox': RANDOM_BUTTON_ROW},
    COLUMN: 1,
    WIDTH: 4,
    TYPE: GridCell
}
TYPE_OPACITY_ROW = {
    CHILD: {
        '1': OPACITY_VBOX_1,
        '2': OPACITY_VBOX_2,
        '_opacity_vbox_3': OPACITY_VBOX_3
    },
    TYPE: HBox
}
TYPE_OPACITY_CELL_1 = {
    CHILD: {'1': TYPE_OPACITY_ROW},
    COLUMN: 1,
    WIDTH: 3,
    TYPE: GridCell
}
ANIMATION_GRID_ROW = {
    'animate': {
        CHILD: {'1': ANIMATE_CELL},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'frame': {
        CHILD: {
            '0': FRAME_COUNT_CELL_0,
            '1': FRAME_COUNT_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'timer': {
        CHILD: {
            '0': TIMER_CELL_0,
            '1': TIMER_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    }
}
EMBOSS_GRID_ROW = {
    'emboss': {
        CHILD: {'1': EMBOSS_CELL},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'type': {
        CHILD: {
            '0': EMBOSS_TYPE_CELL_0,
            '1': EMBOSS_TYPE_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'mode': {
        CHILD: {
            '0': EMBOSS_MODE_CELL_0,
            '1': EMBOSS_MODE_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'opacity': {
        CHILD: {
            '0': EMBOSS_OPACITY_CELL_0,
            '1': EMBOSS_OPACITY_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'azimuth': {
        CHILD: {
            '0': AZIMUTH_CELL_0,
            '1': AZIMUTH_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'elevation': {
        CHILD: {
            '0': ELEVATION_CELL_0,
            '1': ELEVATION_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'depth': {
        CHILD: {
            '0': DEPTH_CELL_0,
            '1': DEPTH_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'blur': {
        CHILD: {
            '0': BLUR_CELL_0,
            '1': BLUR_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'contrast': {
        CHILD: {
            '0': CONTRAST_CELL_0,
            '1': CONTRAST_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    }
}
OVERLAY_GRID_ROW = {
    'overlay': {
        CHILD: {'1': OVERLAY_CELL},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'mode': {
        CHILD: {
            '0': GRADIENT_MODE_CELL_0,
            '1': GRADIENT_MODE_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'opacity': {
        CHILD: {
            '0': GRADIENT_OPACITY_CELL_0,
            '1': GRADIENT_OPACITY_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'gradient': {
        CHILD: {
            '0': OVERLAY_GRADIENT_CELL_0,
            '1': OVERLAY_GRADIENT_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'reverse': {
        CHILD: {'1': REVERSED_CELL},
        COLUMNS: 2,
        TYPE: GridRow
    }
}
PRESET_GRID_ROW = {
    'dialog': {
        CHILD: {'1': DIALOG_CELL_0},
        COLUMNS: 2,
        TYPE: GridRow
    }
}
SCALE_GRID_ROW = {
    'division': {
        CHILD: {
            '0': DIVISION_CELL_0,
            '1': DIVISION_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'radius': {
        CHILD: {
            '0': RADIUS_CELL_0,
            '1': RADIUS_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'rim': {
        CHILD: {
            'label': RIM_W_CELL_0,
            'g': RIM_W_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'ring': {
        CHILD: {
            '0': RING_W_CELL_0,
            '1': RING_W_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'eye': {
        CHILD: {
            '0': EYE_W_CELL_0,
            '1': EYE_W_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    }
}
TYPE_GRID_ROW = {
    'type': {
        CHILD: {
            '0': TYPE_CELL_0,
            '1': TYPE_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'color': {
        CHILD: {
            '0': COLOR_CELL_0,
            '1': COLOR_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'zing': {
        CHILD: {
            '0': RANDOM_COLOR_CELL_0,
            '1': RANDOM_COLOR_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'pattern': {
        CHILD: {
            '0': PATTERN_CELL_0,
            '_pattern_hbox': PATTERN_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'opacity': {
        CHILD: {
            '0': OPACITY_CELL_0,
            '1': TYPE_OPACITY_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'flip': {
        CHILD: {
            '0': FLIP_CELL_0,
            '1': FLIP_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'eye': {
        CHILD: {'1': TRANSPARENT_EYE_CELL},
        COLUMNS: 2,
        TYPE: GridRow
    }
}

for d in (EMBOSS_GRID_ROW, OVERLAY_GRID_ROW, TYPE_GRID_ROW, SCALE_GRID_ROW):
    d['random'] = GRID_RANDOM_ROW

ANIMATION_GRID = {
    CHILD: ANIMATION_GRID_ROW,
    TYPE: Grid
}
EMBOSS_GRID = {
    CHILD: EMBOSS_GRID_ROW,
    TYPE: Grid
}
OVERLAY_GRID = {
    CHILD: OVERLAY_GRID_ROW,
    TYPE: Grid
}
PRESET_GRID = {
    CHILD: PRESET_GRID_ROW,
    TYPE: Grid
}
SCALE_GRID = {
    CHILD: SCALE_GRID_ROW,
    TYPE: Grid
}
TYPE_GRID = {
    CHILD: TYPE_GRID_ROW,
    TYPE: Grid
}
ANIMATION_PAGE = {
    CHILD: {'0': ANIMATION_GRID},
    TEXT: "Animation",
    TYPE: Page
}
EMBOSS_PAGE = {
    CHILD: {'0': EMBOSS_GRID},
    TEXT: "Emboss",
    TYPE: Page
}
OVERLAY_PAGE = {
    CHILD: {'0': OVERLAY_GRID},
    TEXT: "Overlay",
    TYPE: Page
}
PRESET_PAGE = {
    CHILD: {'0': PRESET_GRID},
    TEXT: "Preset",
    TYPE: Page
}
SCALE_PAGE = {
    CHILD: {'0': SCALE_GRID},
    TEXT: "Scale",
    TYPE: Page
}
TYPE_PAGE = {
    CHILD: {'0': TYPE_GRID},
    TEXT: "Type",
    TYPE: Page
}
MAIN = {
    'g': {
        TYPE: Notebook,
        CHILD: {
            'scale': SCALE_PAGE,
            'type': TYPE_PAGE,
            'overlay': OVERLAY_PAGE,
            'emboss': EMBOSS_PAGE,
            'animation': ANIMATION_PAGE,
            'preset': PRESET_PAGE
        }
    }
}
