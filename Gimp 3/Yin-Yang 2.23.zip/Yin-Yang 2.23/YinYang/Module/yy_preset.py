#!/usr/bin/env python3


class Preset:
    # Is the Save preset dialog/AnyGRoup 'data_d' dict.
    dialog_data_d = None

    # file name; Has a string value after a preset is saved.
    name = ""

    # Locate preset file. Is a relative of the YinYang/Module folder.
    path = None

    # Is the main window widget definition dict.
    main = None

    # Save dict. Is the main window's Widget value.
    # {Widget key: Widget value}
    main_data_d = None

    # Is the main window's Widget.
    # {Widget key: Widget}
    main_widget_d = None
