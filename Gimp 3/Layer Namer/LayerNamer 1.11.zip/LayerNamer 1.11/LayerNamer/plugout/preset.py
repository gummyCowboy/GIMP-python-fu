#!/usr/bin/env python3
import os

# Remove the 'plugout' folder from 'path'.
path = os.path.dirname(__file__)
dir_parts = os.path.split(path)
last_folder = dir_parts[0].split(os.sep)[-1]
path = os.path.dirname(path).replace(last_folder + os.path.sep, "")


class Preset:
    """
    Is a static class for storing the plugin's preset path.
    The DialogPresetSave and DialogPresetLoad both need this variable.
    """
    # Set each time a DialogManagePreset is opened.
    active_path = None

    # Set when the plug-in starts.
    path = "{}{}Preset{}".format(path, os.path.sep, os.path.sep)
