#!/usr/bin/env python3
from namer.constant import EMPTY_LAYER_NAME, NO_FIND_STRING, NO_REPLACE_STRING
import re
import gi                              # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp         # noqa

"""Include function for renaming layer."""


def find_replace_group(z, find, replace, is_regex):
    """
    Find and replace a character string in layer name
    found in an layer group. Is recursive.

    z: Gimp.GroupLayer
        Is layer and has child layer.

    find: string
        Find a match.

    replace: string
        Replace a match.

    is_regex: bool
        If True, Python's 're' module is used
        for regular expression pattern matching.
    """
    for z1 in z.get_children():
        find_and_replace_layer(z1, find, replace, is_regex)
        if Gimp.Item.id_is_group_layer(z1.get_id()):
            find_replace_group(z1, find, replace, is_regex)


def find_replace_image(j, find, replace, is_regex):
    """
    Find and replace a character string in layer name
    found in an image.

    j: Gimp.Image
        Has layer.

    find: string
        Find a match.

    replace: string
        Replace a match.

    is_regex: bool
        If True, Python's 're' module is used
        for regular expression pattern matching.
    """
    for z in j.get_layers():
        find_and_replace_layer(z, find, replace, is_regex)
        if Gimp.Item.id_is_group_layer(z.get_id()):
            find_replace_group(z, find, replace, is_regex)


def find_and_replace_layer(z, find, replace, is_regex):
    """
    Find a layer name match with find and replace string.

    z: Gimp.Layer
        Has name.

    find: string
        Find in layer name.

    replace: string
        Replace matched find string.

    is_regex: bool
        If True, Python's 're' module is used
        for regular expression pattern matching.
    """
    n = z.get_name()

    if is_regex:
        n1 = n

        try:
            n1 = re.sub(find, replace, n)
        except Exception:
            # 're' throws exceptions on some string value.
            pass

    else:
        n1 = n.replace(find, replace)

    # Was there a match?
    if n != n1:
        if n1:
            z.set_name(n1)
        else:
            Gimp.message(EMPTY_LAYER_NAME)


def rename_layer(image, d):
    """
    Find and replace string values in a image/layer collection.

    image: Gimp.Image
        WIP

    d: dict
        'AnyGroup.value_d'
        {Widget key: Widget value}
    """
    find = d['find']
    replace = d['replace']
    is_regex = d['is_regex']

    if find:
        if find != replace:
            find_replace_image(image, find, replace, is_regex)
        else:
            Gimp.message(NO_REPLACE_STRING)

    else:
        Gimp.message(NO_FIND_STRING)
    Gimp.displays_flush()
