#!/usr/bin/env python3
from copy import deepcopy
from namer.constant import (
    CTRL_P, DIALOG_MAIN_SIGNAL,
    PREVIEW, PREVIEW_TYPE, TITLE,
    UNDO, UNDO_TYPE
)
from namer.define_main import DEFINE_MAIN
from namer.output import rename_layer
from plugout.any_group import AnyGroup
from plugout.constant import (
    ACCEPT, ANY_CHANGE, CANCEL,
    CANCEL_TYPE, DELETE_TYPE, OK_TYPE
)
from plugout.container.content_area import ContentArea
from plugout.dialog.dialog import Dialog
import gi                                             # type: ignore
gi.require_version('Gdk', '3.0')
gi.require_version('Gimp', '3.0')
from gi.repository import Gdk, Gimp, GObject          # noqa

"""Define a dialog class and support function for renaming layer."""


def get_name_layer_group(z, d):
    """
    Gather layer from a 'Gimp.GroupLayer'.

    z: Gimp.GroupLayer
    d: dict
        {layer id: layer name}
    """
    for z1 in z.get_children():
        id_ = z1.get_id()
        d[id_] = z1.get_name()
        if Gimp.Item.id_is_group_layer(id_):
            get_name_layer_group(z1, d)


def get_layer_name_image(j, d):
    """
    Gather layer from a 'Gimp.Image'.

    j: Gimp.Image
    d: dict
        {layer id: layer name}
    """
    for z in j.get_layers():
        id_ = z.get_id()
        d[id_] = z.get_name()
        if Gimp.Item.id_is_group_layer(id_):
            get_name_layer_group(z, d)


def restore_undo(j, undo_d):
    """
    Process an undo dict. Create list ordered by non-conflicting
    renaming so as to avoid duplicate rename error.

    j: Gimp.Image
        WIP

    undo_d: dict
        {item id: item name}
        The item can be Gimp.Layer or Gimp.GroupLayer.
    """
    real_d = {}
    order_q = []
    d = undo_d.copy()

    get_layer_name_image(j, real_d)

    # Dwindle 'real_d' in an orderly manner.
    is_working = True

    while is_working:
        name_q = real_d.values()
        is_working = False
        pop_q = []

        for id_, n in d.items():
            if n not in name_q:
                # no problem
                order_q.append((id_, n))
                pop_q.append(id_)
                if id_ in real_d:
                    real_d.pop(id_)
                    is_working = True
        if is_working:
            for k in pop_q:
                d.pop(k)

    if len(order_q) != len(undo_d):
        for k, v in undo_d.items():
            if (k, v) not in order_q:
                order_q.append((k, v))

    # Rename following a no-conflict order.
    for q in order_q:
        id_, n = q
        z = Gimp.Item.get_by_id(id_)
        if n != z.get_name():
            z.set_name(n)


class DialogMain(GObject.GObject, Dialog):
    """
    Create a GimpUI.Dialog for user interaction and define output settings.
    """
    __gsignals__ = DIALOG_MAIN_SIGNAL

    def __init__(self, image):
        """
        Open a dialog. Respond to user interaction.

        image: Gimp.Image
            WIP
        """
        def _on_accept():
            self.dialog.destroy()

            self.dialog = None
            self.on_preview(False)

        def _on_cancel():
            self.dialog.destroy()

            self.dialog = None
            self.on_cancel()

        def _on_preview():
            self.on_preview(True)

        def _on_undo():
            self.on_undo()

        GObject.GObject.__init__(self)

        # Recall original layer name.
        # {layer id: layer name}
        self._original_layer_d = {}

        # Is a 'AnyGroup.value_d' copy made on Preview action.
        # {Widget key: Widget value}
        self._preview_d = {}

        # Before a Preview is run, the image/layer state is recorded.
        # [{layer id: layer name, ...}]
        self._undo_stack = []

        self._undo_button = self._preview_button = None
        self._image = image

        response_d = {
            CANCEL_TYPE: _on_cancel,
            DELETE_TYPE: _on_cancel,
            OK_TYPE: _on_accept,
            PREVIEW_TYPE: _on_preview,
            UNDO_TYPE: _on_undo
        }

        get_layer_name_image(image, self._original_layer_d)
        self.connect(ANY_CHANGE, self.on_any_change)
        Dialog.__init__(
            self,
            TITLE,
            (
                (CANCEL, CANCEL_TYPE),
                (PREVIEW, PREVIEW_TYPE),
                (UNDO, UNDO_TYPE),
                (ACCEPT, OK_TYPE)
            ),
            self.add_widget,
            response_d
        )

    def _restore_layer_state(self, d):
        """
        Rename Gimp.Layer and Gimp.GroupLayer using a state dict.

        d: dict
            Restore image/layer to this state.
            {layer id: layer name, ...}
        """
        restore_undo(self._image, d)
        Gimp.displays_flush()

    def add_widget(self, content_area):
        """
        Add Yin-Yang widget to the Dialog's content area.

        content_area: Gtk.Box
            There's room to grow.
        """
        self._preview_button = self.dialog.get_widget_for_response(
            PREVIEW_TYPE
        )
        self._undo_button = self.dialog.get_widget_for_response(UNDO_TYPE)

        self._undo_button.set_sensitive(0)
        self._preview_button.set_tooltip_text(CTRL_P)
        self.dialog.connect('key-press-event', self.on_key_press)

        container = ContentArea(content_area)
        self._any_group = AnyGroup(
            DEFINE_MAIN,
            container,
            is_any_change=True,
            host=self
        )
        content_area.show_all()

    def on_any_change(self, *_):
        """Enable the Preview button on any Widget change."""
        if self._preview_button:
            self._preview_button.set_sensitive(1)

    def on_cancel(self):
        """
        Close the dialog. The user chose to cancel.

        Return layer name back to their original value.
        Renaming layer can create overlapping layer name, so
        process an error list until that problem is resolved.
        """
        self._restore_layer_state(self._original_layer_d)

    def on_key_press(self, _, event_key):
        """
        Save the preset if the user presses the return key.

        _ Gtk.Dialog
            not used

        event_key: Gdk.EventKey
        """
        is_control = (event_key.state & Gdk.ModifierType.CONTROL_MASK)
        if is_control and event_key.keyval == Gdk.KEY_p:
            self._preview_button.grab_focus()
            self._preview_button.emit('clicked')

    def on_preview(self, is_preview):
        """
        Respond to a Preview button action by performing a preview
        but only if things have changed since the last preview.

        is_preview: bool
            If True, then the user clicked on the Preview button.
        """
        d = self._any_group.value_d
        g = self._preview_button

        if not g.get_style_context().has_class('pressed'):
            g.get_style_context().add_class('pressed')

        if d != self._preview_d:
            self._preview_d = deepcopy(d)

            if is_preview:
                undo_d = {}

                self._undo_stack.append(undo_d)
                get_layer_name_image(self._image, undo_d)
                self._undo_button.set_sensitive(1)
            rename_layer(self._image, d)

        g.get_style_context().remove_class('pressed')
        g.set_sensitive(0)

    def on_undo(self):
        """
        Respond to an Undo button action. Rename layer to the last undo state.
        """
        if self._undo_stack:
            self._preview_d = {}
            undo_d = self._undo_stack.pop()
            self._restore_layer_state(undo_d)

        m = int(bool(len(self._undo_stack)))

        self._undo_button.set_sensitive(m)
        self._preview_button.set_sensitive(1)
        if not m:
            self._preview_button.grab_focus()
