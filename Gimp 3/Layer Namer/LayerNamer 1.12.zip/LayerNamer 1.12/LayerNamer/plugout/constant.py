#!/usr/bin/env python3
import gi                                        # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import GLib, GObject, Gtk     # noqa

"""Define constant value for descriptor, button-type, and signal."""


def _(n):
    """
    Translate English to local language.

    n: string
        Translate.

    Return: string
        translated
    """
    return GLib.dgettext(None, n)


GIMP_PYTHON = 'gimp30-python'

# string_______________________________________________________________________
ACCEPT = _("_Accept")
AVAILABLE_PRESET = _("Available Preset")
CANCEL = _("_Cancel")
COLOR_TIP = _(" Red\t{} \n Green\t{} \n Blue\t{} \n Alpha\t{}")
CONFIRM_OVERWRITE = _(
    'A file with the name:\n"{}",\nalready exists. Overwrite it?'
)
CONTAINER = _("Container")
DEFAULT = _("Default")
DELETE = _("_Delete")
DELETE_CONFIRM = _('Do you really want to delete:\n"{}"?')
DELETE_FAIL = _("The plugin was unable to delete the file.")
DELETE_FILE = _("Delete a file.")
EMPTY_PRESET = _("The loaded preset is empty.")
EXISTING_FILE = _('An existing file was found.')
LOAD = _("Load")
LOAD_FAIL = _("The plugin is unable to load the preset.")
MANAGE = _("Manage…")
MANAGE_PRESET = _("Manage Preset")
MISSING_PRESET = _("The preset file is missing.")
MISSING_TYPE_ERROR = _(
    "AnyGroup requires a 'type' item in a definition.\n"
    "This definition from '{}' has none:\n{}"
)
PATH = _("Path")
PRESET_LOADED = _("The preset was loaded.")
PRESET_NAME = _("Preset Name")
PRESET_SAVED = _("The preset was saved.")
RANDOM = _("Random")
REMOVED_FILE = _('The file, "{}",\nwas removed.')
SAVE_ = _("Save…")
SAVE_FAIL = _("The plugin could not save the preset.")
SAVE_PRESET = _("Save Preset")

# button response id___________________________________________________________
CANCEL_TYPE = Gtk.ResponseType.CANCEL
DELETE_BUTTON_RESPONSE_TYPE = -99
DELETE_TYPE = Gtk.ResponseType.DELETE_EVENT
OK_TYPE = Gtk.ResponseType.OK

# Signal_______________________________________________________________________
ANY_CHANGE = 'any-change'
CONTAINER_CHANGE = 'container-change'
DELETE_PRESET = 'delete-preset'
ENTRY_SAVE_CHANGE = 'entry-save-change'
KEY_PRESS_EVENT = 'key-press-event'
RANDOMIZE = 'randomize'

# run argument
# (emission stage, type of signal, argument type)
SIGNAL_ARG = GObject.SIGNAL_RUN_FIRST, None, (GObject.TYPE_PYOBJECT,)

CONTAINER_SIGNAL = {RANDOMIZE: SIGNAL_ARG}
DIALOG_MANAGE_SIGNAL = {}
DIALOG_SAVE_SIGNAL = {}

for k in (ANY_CHANGE, CONTAINER_CHANGE, ENTRY_SAVE_CHANGE):
    DIALOG_SAVE_SIGNAL[k] = SIGNAL_ARG
for k in (ANY_CHANGE, CONTAINER_CHANGE, DELETE_PRESET):
    DIALOG_MANAGE_SIGNAL[k] = SIGNAL_ARG
