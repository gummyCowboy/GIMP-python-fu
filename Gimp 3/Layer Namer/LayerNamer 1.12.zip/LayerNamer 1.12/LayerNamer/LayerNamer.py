#!/usr/bin/env python3
from namer.constant import PLUGIN_BLURB, PLUGIN_TOOLTIP, PROCEDURE_NAME
from namer.dialog_main import DialogMain
from plugout.constant import GIMP_PYTHON
import gi
import os
import sys
import time
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GimpUi, GLib      # noqa

IS_DEV_PC = os.environ.get('gummy_cowboy', False)


class LayerNamer(Gimp.PlugIn):
    """Initialize the plug-in with GIMP 3."""

    def do_query_procedures(self):
        return [PROCEDURE_NAME]

    def do_set_i18n(self, name):
        # Support language translation.
        return True, GIMP_PYTHON, None

    def do_create_procedure(self, name):
        """
        Define plug-in so that it can do its thing.

        name: string
            Is the name of the plug-in and is sourced from PROC_NAME.
        """
        # run data, 'None'
        procedure = Gimp.ImageProcedure.new(
            self, name, Gimp.PDBProcType.PLUGIN, self.run, None
        )
        procedure.set_image_types("*")
        procedure.set_sensitivity_mask(
            Gimp.ProcedureSensitivityMask.DRAWABLE |
            Gimp.ProcedureSensitivityMask.DRAWABLES
        )
        procedure.set_documentation(PLUGIN_TOOLTIP, PLUGIN_BLURB, name)
        procedure.set_menu_label("La_yer Namer…")
        procedure.set_attribution("Charles Bartley", "Charles Bartley", "2024")
        procedure.add_menu_path('<Image>/Layer/')
        return procedure

    def run(self, procedure, run_mode, image, *_):
        """
        Produce layer output.

        procedure: Gimp.ImageProcedure
            Manage plug-in.

        run_mode: enum
            Gimp.RunMode

        image: Gimp.Image
            the active image

        _: tuple
            drawables: list
                active drawable
                [drawable, ...]
                not used

            args: Gimp.ValueArray
                How is this used?
                Has a length() function that could be useful.
                not used

            run_data: value
                Relayed from the 'do_create_procedure'.
                not used
        """
        # Check run mode. If interactive create
        # dialog, otherwise use previous settings.
        if run_mode == Gimp.RunMode.INTERACTIVE:
            file = None

            # Init UI theme.
            GimpUi.init(PROCEDURE_NAME)

            if IS_DEV_PC:
                # Trace errors by recording them to a file. If
                # the file doesn't exist, create it. Append
                # error messages and piped (">>") print statements.
                file = sys.stderr = sys.stdout = open("D:\\error.txt", 'a')
                _start = f"\nLayer-Namer, {time.ctime()}"
                _end = "_" * (80 - len(_start))
                print(f"{_start}{_end}")

            image.undo_group_start()

            try:
                DialogMain(image)

            except Exception as ex:
                print(ex)

            finally:
                if file:
                    file.close()

                image.undo_group_end()
                Gimp.displays_flush()
        else:
            # Use previous settings.
            # This is dependent on the shelf which is a GIMP team WIP.
            pass

        return procedure.new_return_values(
            Gimp.PDBStatusType.SUCCESS, GLib.Error()
        )


Gimp.main(LayerNamer.__gtype__, sys.argv)
