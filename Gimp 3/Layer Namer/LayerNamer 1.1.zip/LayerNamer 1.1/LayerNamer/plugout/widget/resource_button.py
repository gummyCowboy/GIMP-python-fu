#!/usr/bin/env python3
from plugout.define.key import VALUE
from plugout.widget.value import WidgetValue
from random import choice
import gi                                     # type: ignore
gi.require_version('Gimp', '3.0')
gi.require_version('GimpUi', '3.0')
from gi.repository import Gimp, GimpUi        # noqa

"""Include 'GimpUi.Resource' button and support function."""


def on_resource_realize(g):
    """
    Initialize a pattern button's tooltip after the button is initialized.

    g: Chooser type
    """
    on_resource_set(g, g.get_resource(), True)


def on_resource_set(g, resource, _):
    """
    Respond to a 'resource-set' event.

    g: GimpUi.PatternChooser
        Is responsible.

    resource: Gimp.Resource
        on display

    _: bool
        Is True if the resource was accepted by the user.
    """
    g.set_tooltip_text(resource.get_name())


class ResourceButton(WidgetValue):
    """
    Customize WidgetValue with additional signal handler and factored method.
    """
    change_signal = 'resource-set'

    def __init__(self, def_d, g):
        """
        def_d: dict
            ResourceButton definition
                value: string
                    Use to find the resource inside Gimp.
                    Is the init and default value.

        g: GimpUi button
            Is a Gimp.Resource server.
        """
        super().__init__(def_d, g)
        g.connect('resource-set', on_resource_set)
        g.connect('realize', on_resource_realize)
        self.value_d[self.key] = def_d.get(VALUE)

    def get_a(self):
        """
        Retrieve the value of the 'GimpUi.GradientChooser'.

        Return: string
            Gradient name
        """
        a = self.widget.get_resource()
        if a:
            return a.get_name()

    def get_resource(self):
        """
        Retrieve the value of the 'GimpUi.GradientChooser'.

        Return: Gimp.Gradient
        """
        return self.widget.get_resource()

    def randomize(self, *_):
        """
        Respond to a randomize signal. Randomize
        the value of the 'GimpUi.GradientChooser'.
        """
        self.set_resource(choice(self.limit()))

    def set_resource(self, a):
        """
        Set the value of the 'GimpUi.GradientChooser'.

        a: Gimp.Gradient
            Receive value.
        """
        self.widget.set_resource(a)
        self.widget.emit('resource-set', a, True)


class GradientButton(ResourceButton):
    """Customize 'GimpUi.GradientChooser' with a wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            GradientButton definition
                value: string
                    Initialize the 'GimpUi.GradientChooser'.
        """
        g = GimpUi.GradientChooser.new()

        super().__init__(def_d, g)

        resource = Gimp.Gradient.get_by_name(def_d.get(VALUE))
        if resource:
            self.set_resource(resource)

    def set_a(self, n):
        """
        Set the value of the 'GimpUi.GradientChooser'.

        n: string
            Find its Gimp.Gradient.
        """
        if not isinstance(n, str):
            n = str(n)

        a = Gimp.Gradient.get_by_name(n)
        if a:
            self.set_resource(a)


class PatternButton(ResourceButton):
    """Customize 'GimpUi.PatternChooser' with a wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            PatternButton definition
                value: string
                    Initialize the value of the 'GimpUi.PatternChooser'.
        """
        g = GimpUi.PatternChooser.new()

        super().__init__(def_d, g)

        resource = Gimp.Pattern.get_by_name(def_d.get(VALUE))
        if resource:
            self.set_resource(resource)

    def set_a(self, n):
        """
        Set the value of the 'GimpUi.PatternChooser'.

        n: string
            Find its Gimp.Pattern.
        """
        if not isinstance(n, str):
            n = str(n)

        a = Gimp.Pattern.get_by_name(n)
        if a:
            self.set_resource(a)
