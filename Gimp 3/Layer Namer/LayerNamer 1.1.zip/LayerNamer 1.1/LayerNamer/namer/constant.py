#!/usr/bin/env python3
from plugout.constant import ANY_CHANGE
import gi                                          # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import GLib, GObject            # noqa


def _(n):
    """
    Translate English to local language.

    n: string
        Translate.

    Return: string
        translated
    """
    return GLib.dgettext(None, n)


PROCEDURE_NAME = 'plug-in-layer-namer'
TITLE = "Layer Namer 1.1"

# custom button response type
PREVIEW_TYPE = -99
UNDO_TYPE = -98

# Translate____________________________________________________________________
CTRL_P = _("Ctrl-P")
EMPTY_LAYER_NAME = _("The replacement would create an empty layer name.")
FIND = _("Find")
PLUGIN_BLURB = _("Find and replace characters in an image's layer collection.")
PLUGIN_TOOLTIP = _("Find and replace layer character for an entire image.")
NO_FIND_STRING = _("Insert a character string to find.")
NO_REPLACE_STRING = _("The replace value is the same as the find value.")
PREVIEW = _("Preview")
REGEX = _("Use Regex")
REPLACE = _("Replace")
UNDO = _("Undo")

# custom Signal________________________________________________________________
# run first argument
# (emission stage, type of signal, argument type)
SIGNAL_ARG = GObject.SIGNAL_RUN_FIRST, None, (GObject.TYPE_PYOBJECT,)

DIALOG_MAIN_SIGNAL = {ANY_CHANGE: SIGNAL_ARG}
