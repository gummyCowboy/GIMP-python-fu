#!/usr/bin/env python3
from namer.constant import FIND, REGEX, REPLACE
from plugout.constant import MANAGE, SAVE_
from plugout.container.box import HBox
from plugout.container.grid import Grid, GridCell, GridRow
from plugout.define.key import (
    CHILD, COLUMN, COLUMNS, HALIGN,
    PADDING, PRESET, TEXT, TYPE, VALUE, WIDTH
)
from plugout.widget.button_preset import ButtonManage, ButtonSave
from plugout.widget.checkbutton import CheckButton
from plugout.widget.entry import Entry
from plugout.widget.h_sep import HSeparator
from plugout.widget.label import Label, LabelPreset
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa

"""Define the DialogMain's content using AnyGroup definition dict."""

# Find_________________________________________________________________________
FIND_LABEL = {HALIGN: Gtk.Align.START, TEXT: FIND, TYPE: Label}
FIND_ENTRY = {TYPE: Entry, VALUE: ""}
GRID_CELL_FIND_0 = {
    CHILD: {'find_label': FIND_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_FIND_1 = {
    CHILD: {'find': FIND_ENTRY},
    COLUMN: 1,
    TYPE: GridCell
}

# Preset_______________________________________________________________________
PRESET_LABEL = {HALIGN: Gtk.Align.START, TYPE: LabelPreset}
MANAGE_BUTTON = {TEXT: MANAGE, TYPE: ButtonManage}
SAVE_BUTTON = {PADDING: (0, 0, 0, 4), TEXT: SAVE_, TYPE: ButtonSave}
HBOX_PRESET_BUTTON = {
    CHILD: {
        'save_button': SAVE_BUTTON,
        'manage_button': MANAGE_BUTTON
    },
    TYPE: HBox
}
GRID_CELL_PRESET_0 = {
    CHILD: {'preset_label': PRESET_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_PRESET_1 = {
    CHILD: {1: HBOX_PRESET_BUTTON},
    COLUMN: 1,
    WIDTH: 2,
    TYPE: GridCell
}
GRID_ROW_PRESET = {
    CHILD: {1: GRID_CELL_PRESET_0, 2: GRID_CELL_PRESET_1},
    COLUMNS: 2,
    TYPE: GridRow
}

# Replace______________________________________________________________________
REPLACE_LABEL = {HALIGN: Gtk.Align.START, TEXT: REPLACE, TYPE: Label}
REPLACE_ENTRY = {TYPE: Entry, VALUE: ""}
GRID_CELL_REPLACE_0 = {
    CHILD: {'replace_label': REPLACE_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_REPLACE_1 = {
    CHILD: {'replace': REPLACE_ENTRY},
    COLUMN: 1,
    TYPE: GridCell
}

# Regex________________________________________________________________________
REG_EX_CHECKBUTTON = {
    VALUE: False,
    TEXT: REGEX,
    TYPE: CheckButton
}
GRID_CELL_REG_EX_1 = {
    CHILD: {'is_regex': REG_EX_CHECKBUTTON},
    COLUMN: 1,
    TYPE: GridCell
}

# Separator____________________________________________________________________
HSEPARATOR = {PADDING: (4, 4, 0, 0), TYPE: HSeparator}
GRID_CELL_HSEPARATOR = {
    CHILD: {'separator': HSEPARATOR}, COLUMN: 0, WIDTH: 2, TYPE: GridCell
}
GRID_ROW_SEPARATOR = {
    CHILD: {1: GRID_CELL_HSEPARATOR},
    COLUMNS: 2,
    TYPE: GridRow
}

# Main_________________________________________________________________________
# AnyGroup definition: {key: definition}
DEFINE_MAIN = {
    1: {
        CHILD: {
            'find': {
                CHILD: {1: GRID_CELL_FIND_0, 2: GRID_CELL_FIND_1},
                COLUMNS: 2,
                TYPE: GridRow
            },
            'replace': {
                CHILD: {1: GRID_CELL_REPLACE_0, 2: GRID_CELL_REPLACE_1},
                COLUMNS: 2,
                TYPE: GridRow
            },
            'reg_ex': {
                CHILD: {1: GRID_CELL_REG_EX_1},
                COLUMNS: 2,
                TYPE: GridRow
            },
            'sep': GRID_ROW_SEPARATOR,
            'preset': GRID_ROW_PRESET
        },
        PRESET: None,
        TYPE: Grid
    }
}
