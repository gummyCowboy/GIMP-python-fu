#!/usr/bin/env python3
from yy_widget import Button
from yy_preset_save import show_save_dialog
from yy_preset_manage import show_manage_dialog


class ButtonManage(Button):
    """
    Is a custom Gtk.Button for loading and
    deleting the preset stored in 'data_d'.
    """

    def __init__(self, d, e, data_d, key):
        """
        d: dict
            Optional Item:
            text: string

        e: dict
            Identify option group.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        super().__init__(d, e, data_d, key)
        self.widget.connect('clicked', self.on_manage_click)

    def on_manage_click(self, _):
        """
        _: Gtk.Button
            Is responsible.
        """
        show_manage_dialog(self.data_d)


class ButtonSave(Button):
    """Is a custom Gtk.Button for saving the preset in 'data_d'."""

    def __init__(self, d, e, data_d, key):
        """
        d: dict
            Optional Item:
            text: string

        e: dict
            Identify option group.

        data_d: dict
            Update value on change.

        key: value
            Identify the Widget in an AnyGroup.
        """
        super().__init__(d, e, data_d, key)
        self.widget.connect('clicked', self.on_save_click)

    def on_save_click(self, _):
        """
        Respond to Save button action.

        _: Gtk.Button
            Is responsible.
        """
        show_save_dialog(self.data_d)
