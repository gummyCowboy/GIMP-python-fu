#!/usr/bin/env python3
from yy_constant import (
    ACCEPT,
    AVAILABLE_PRESET,
    CANCEL,
    DEFAULT,
    DELETE,
    DELETE_CONFIRM,
    DELETE_FAIL,
    DELETE_FILE,
    EMPTY_PRESET,
    LOAD,
    LOAD_FAIL,
    MANAGE_PRESET,
    MISSING_PRESET,
    PRESET_LOADED,
    REMOVED_FILE,
    DefKey as dk
)
from yy_preset import Preset
import json
import gi
import glob
import os
gi.require_version('Gimp', '3.0')
gi.require_version('Gtk', '3.0')
from gi.repository import Gimp, Gdk, Gtk  # noqa

DELETE_RESPONSE_TYPE = -99


class Dialog:
    # Enable or disable depending on the Gtk.ListBox selection.
    delete_button = None

    # Is the manage dialog.
    dialog = None

    # Is the manage dialog's Gtk.Listbox.
    list_box = None

    # Is a list of preset name displayed in the manage preset list box.
    preset_q = None


def collect_preset():
    """
    Collect Preset in a list.

    Return: tuple
        (Preset dict, Preset name list)
    """
    # list of Presets, 'q'
    q = [DEFAULT]
    is_success = False

    try:
        n = f"{Preset.path}{'*'}"

        # Ignore sub-directory.
        file_q = glob.glob(n)
        is_success = True

    except Exception:
        Gimp.message(LOAD_FAIL)

    if is_success:
        # Get the file name without the extension.
        for n in file_q:
            q.append(os.path.splitext(os.path.basename(n))[0])
    return is_success, q


def delete_preset(list_box, row_i):
    """
    Delete a preset given its index in the preset list.

    list_box: Gtk.ListBox
        Has a list of preset.

    row_i: int
        index to preset in the preset name list
    """
    path = f'{Preset.path}{Dialog.preset_q[row_i]}.json'
    is_delete = False

    if verify_delete(path):
        try:
            os.remove(path)
            Gimp.message(REMOVED_FILE.format(path))
            is_delete = True
        except Exception:
            Gimp.message(DELETE_FAIL)
    if is_delete:
        row = list_box.get_row_at_index(row_i)

        list_box.remove(row)
        Dialog.preset_q.pop(row_i)


def dispatch_manage_response(dialog, response_type):
    """
    Respond to a Manage preset Gtk.Dialog's button action.

    dialog: Gtk.Dialog
        Save preset.

    response_type: value
        Each dialog button has a response type.
    """
    if response_type == Gtk.ResponseType.OK:
        if load_preset_data():
            dialog.destroy()
    elif response_type == DELETE_RESPONSE_TYPE:
        on_delete_button_click()
    else:
        dialog.destroy()


def get_default():
    """
    Fetch main's default Widget value.

    Return: dict
        {Widget key: Widget value}
    """
    d = {}

    get_widget_init(d, Preset.main)
    return d


def get_widget_init(d, e):
    """
    Get the initial value of main Widget.

    d: dict
        Widget init

    e: dict
        Widget definition
    """
    for k, def_d in e.items():
        if def_d.get(dk.IS_WIDGET):
            a = def_d.get(dk.VALUE)
            if a is not None:
                d[k] = a
        else:
            get_widget_init(d, def_d[dk.CHILD])


def load_preset_data():
    """
    Try to load the Yin-Yang preset from file.

    Return: bool
        Is True if the preset is loaded.
    """
    d = None
    is_success = False
    row = Dialog.list_box.get_selected_row()

    if row:
        i = row.get_index()

        if i:
            n = Dialog.preset_q[i]
            path = f'{Preset.path}{n}.json'

            if os.path.isfile(path):
                try:
                    with open(path, 'r', encoding='utf-8') as a_file:
                        d = json.load(a_file)
                    is_success = True
                except Exception:
                    is_success = False
                    Gimp.message(LOAD_FAIL)
            else:
                Gimp.message(MISSING_PRESET)

        else:
            is_success = True
            d = get_default()
        if is_success:
            if d:
                e = Preset.main_widget_d

                for k in e:
                    if k in d:
                        e[k].set_a(d[k])
                Gimp.message(PRESET_LOADED)
            else:
                is_success = False
                Gimp.message(EMPTY_PRESET)
    return is_success


def on_list_box_key_press(list_box, event_key):
    """
    Delete preset if the user press the delete key.
    Load preset if the  user presses the return key.

    list_box: Gtk.ListBox
        Sent the event.

    event_key: Gdk.EventKey
    """
    n = Gdk.keyval_name(event_key.keyval)

    if n == 'Delete':
        row = list_box.get_selected_row()
        if row.get_index():
            delete_preset(list_box, row.get_index())
    elif n == 'Return':
        dispatch_manage_response(Dialog.dialog, Gtk.ResponseType.OK)


def on_delete_button_click():
    """
    Delete a preset.

    button: Gtk.Button
        Is the Delete button.
    """
    row = Dialog.list_box.get_selected_row()
    if row:
        delete_preset(Dialog.list_box, row.get_index())


def on_row_activated(_, row):
    """
    Enable or disable the Delete button depending
    on the preset selected in the list box.

    _: Gtk.ListBox
        Has a list of available preset.
        not used

    row: Gtk.ListBoxRow
        Is selected. Has an index.
    """
    Dialog.delete_button.set_sensitive(int(bool(row.get_index())))


def show_manage_dialog(d):
    """"""
    Preset.d = d
    dialog = Dialog.dialog = Gtk.Dialog.new()

    dialog.set_title(MANAGE_PRESET)
    dialog.add_button(CANCEL, Gtk.ResponseType.CANCEL)
    Dialog.delete_button = dialog.add_button(DELETE, DELETE_RESPONSE_TYPE)
    dialog.add_button(LOAD, Gtk.ResponseType.OK)
    Dialog.delete_button.set_sensitive(0)

    # Map button responses to callback.
    dialog.connect('response', dispatch_manage_response)

    content_area = dialog.get_content_area()

    content_area.add(Gtk.Label(AVAILABLE_PRESET))
    is_success, Dialog.preset_q = collect_preset()
    if is_success:
        align = Gtk.Alignment()
        align.set_padding(0, 0, 10, 10)

        scrolled_window = Gtk.ScrolledWindow()
        list_box = Dialog.list_box = Gtk.ListBox.new()

        list_box.connect('key-press-event', on_list_box_key_press)
        scrolled_window.set_policy(
            Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC
        )
        scrolled_window.set_min_content_height(360)
        scrolled_window.set_max_content_height(360)

        for n in Dialog.preset_q:
            row = Gtk.ListBoxRow()

            row.add(Gtk.Label(n, xalign=0))
            list_box.add(row)

        list_box.set_selection_mode(Gtk.SelectionMode.SINGLE)
        list_box.connect('row-activated', on_row_activated)
        scrolled_window.add(list_box)
        align.add(scrolled_window)
        content_area.pack_start(align, True, True, 0)
        content_area.show_all()
        dialog.show()


def verify_delete(path):
    """
    Make sure the user wants to delete a file.

    path: string
        file path

    Return: bool
        Is True if the user is okay with deleting the file.
    """
    is_success = False

    if os.path.isfile(path):
        dialog = Gtk.MessageDialog(
            type=Gtk.MessageType.QUESTION,
            text=DELETE_FILE,
            secondary_text=(DELETE_CONFIRM.format(path))
        )

        dialog.add_button(CANCEL, Gtk.ResponseType.CANCEL)
        dialog.add_button(ACCEPT, Gtk.ResponseType.OK)

        response = dialog.run()
        is_success = True if response == Gtk.ResponseType.OK else False
        dialog.destroy()
    return is_success
