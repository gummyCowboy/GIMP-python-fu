#!/usr/bin/env python3
from yy_any_group import AnyGroup
from yy_constant import (
    ACCEPT,
    CANCEL,
    CONFIRM_OVERWRITE,
    EXISTING_FILE,
    PRESET_SAVED,
    SAVE,
    SAVE_FAIL,
    SAVE_PRESET,
    DefKey as dk
)
from yy_container import ContentArea
from yy_def_save import SAVE_DEF
from yy_preset import Preset
import json
import gi                                                   # type: ignore
import os
gi.require_version('Gimp', '3.0')
gi.require_version('Gtk', '3.0')
from gi.repository import Gimp, Gdk, Gtk  # noqa


class Dialog:
    # Is the save dialog.
    dialog = None

    # Enable or disable depending on the Gtk.Entry value.
    save_button = None

    # Has preset name as text value.
    entry = None


def check_duplicate_file(path):
    """
    Check if a file already exists. If it does
    as the user if it's okay to over-write the file.

    path: string
        file path

    Return: bool
        Is True if the user is okay with writing the file.
    """
    is_success = True

    if os.path.isfile(path):
        dialog = Gtk.MessageDialog(
            type=Gtk.MessageType.QUESTION,
            text=EXISTING_FILE,
            secondary_text=CONFIRM_OVERWRITE.format(path)
        )

        dialog.add_button(CANCEL, Gtk.ResponseType.CANCEL)
        dialog.add_button(ACCEPT, Gtk.ResponseType.OK)

        response = dialog.run()
        is_success = True if response == Gtk.ResponseType.OK else False
        dialog.destroy()
    return is_success


def dispatch_save_response(dialog, response_type):
    """
    Respond to a Save Gtk.Dialog's button action.

    dialog: Gtk.Dialog
        Save preset.

    response_type: value
        Each dialog button has a response type.
    """
    if response_type == Gtk.ResponseType.OK:
        if save_preset_data():
            dialog.destroy()
    else:
        dialog.destroy()


def ensure_preset_dir():
    """
    Ensure a directory exists. Use to make a Preset folder.

    Return bool.
        If True, then the Preset directory exists.
    """
    is_success = True
    n = Preset.path

    if n and not os.path.isdir(os.path.dirname(n)):
        try:
            os.makedirs(os.path.dirname(n))
        except Exception:
            is_success = False
            Gimp.message(SAVE_FAIL)
    return is_success


def on_save_entry_key_press(entry, event_key):
    """
    Save the preset if the user presses the return key.

    entry: Gtk.Entry
        Is responsible for event.

    event_key: Gdk.EventKey
    """
    if Gdk.keyval_name(event_key.keyval) == 'Return':
        if len(entry.get_text()):
            dispatch_save_response(Dialog.dialog, Gtk.ResponseType.OK)


def on_save_name_change(entry):
    """
    Enable or disable the Save button depending on the length
    of the entry text.
    """
    Dialog.save_button.set_sensitive(int(bool(entry.get_text())))


def show_save_dialog(d):
    """
    Preset the user with a Save Preset dialog.

    d: dict
        Has the main window's widget value.
        Is a Yin-Yang preset.
        {Widget key: Widget value}
    """
    Preset.main_data_d = d
    dialog = Dialog.dialog = Gtk.Dialog.new()

    dialog.set_title(SAVE_PRESET)
    dialog.add_button(CANCEL, Gtk.ResponseType.CANCEL)
    Dialog.save_button = dialog.add_button(SAVE, Gtk.ResponseType.OK)

    Dialog.save_button.set_sensitive(0)

    # Map button responses to callback.
    dialog.connect('response', dispatch_save_response)

    d = {dk.TYPE: type(None)}
    content_area = dialog.get_content_area()
    container = ContentArea(content_area, d)
    any_group = AnyGroup(SAVE_DEF, d, container)
    Preset.dialog_data_d = any_group.data_d
    g = Dialog.entry = any_group.widget_d['name_entry']

    g.widget.connect('key-press-event', on_save_entry_key_press)
    g.widget.connect('changed', on_save_name_change)
    content_area.show_all()
    dialog.show()


def save_preset_data():
    """
    Try to save the current Yin-Yang preset.

    Return: bool
        Is True if the preset is saved to file.
    """
    path = ''
    is_success = ensure_preset_dir()

    if is_success:
        n = Preset.dialog_data_d['name_entry']
        path = f'{Preset.path}{n}.json'
        is_success = check_duplicate_file(path)

    if is_success:
        try:
            with open(path, 'w') as a_file:
                json.dump(Preset.main_data_d, a_file)
            Gimp.message(PRESET_SAVED)
        except Exception:
            Gimp.message(SAVE_FAIL)
            is_success = False
    return is_success
