#!/usr/bin/env python3
from yy_constant import DefKey as dk

"""
AnyGroup's job is to create a user-interface given a Definition dict.
AnyGroup peruses a Widget definition dict creating Container and Widget alike.
The definition is structured in a tree-form for AnyGroup's required navigation
performed during the object's initialization function.

Definition dict (the root/trunk)
    Container definition
    or
    Widget definition

Container definition (a branch)
    Container definition
    or
    Widget definition

Widget definition (a leaf)

The goal of a Definition dict is to separate data from function, to define
data in recognizable pattern, and to streamline Widget initialization
with an object-oriented approach.

After the Definition dict has been processed and Widget initialized. AnyGroup
connects Widget with a following, if the Widget has certain keys in its Widget
definition dict.

These two keys tell AnyGroup to initialize the Widget 'following' attribute:
    MEMBER and LEADER.

The 'following' is either a tuple of Widget or a dict of Widget.
    tuple: (Gtk.Widget, ...)
    dict: {key: (Gtk.Widget, ...)}

What AnyGroup does is translated 'Widget.key' into 'Widget.instance' by
matching Widget identifier with The AnyGroup's Widget stored in the AnyGroup
widget_d dict.

A Widget by itself keeps AnyGroup's 'data_d' dict up-to-date whenever the
Widget changes value. Thus, the owner of the AnyGroup always has the latest
values of any of Widget in the specified in the definition. Only some Widget
need to update their values in the 'data_d', so they are triggered by a
VALUE key in their Widget definition dict.

Their are several keys found in a Widget definition dict.

ADJUSTMENT: Define a Gtk.SpinButton's initial state.
BORDER_WIDTH: Give a Gtk.Grid some space around its table.
COLUMN: Set the column index of a Gtk.Grid attachment.
COLUMNS: Tell Gtk how many columns a Gtk.Grid row needs.
COLUMN_SPACING: Spread a Gtk.Grid's columns apart.
DIGITS: Increase the precision of a Gtk.SpinButton.
GET_LIST: The ComboBoxText finds its list of values for the pop-out.
HOMOGENEOUS: Make a Widget's sub-content Widget equal in scale.
LIMIT: Limit the random response range of a Widget.
PADDING: Create a Gtk.Alignment for the Gtk.Widget and pad it.
ROW_SPACING: Spread Gtk.Grid row apart.
SIGNAL: Connect a Gtk.Widget with a signal and function argument.
TEXT: Give a Gtk.Widget a descriptor to display.
TOOLTIP: Create a tooltip for a Gtk.Widget.
TYPE: Define a Container or Widget class.
WIDTH: Determine the width in columns of a Gtk.Grid attachment.
X_ALIGN: Position a Gtk.Label in the horizontal space.

AnyGroup has two dictionaries in its possession:
    'data_d' -> {Widget key: Widget value}
    This dict is maintained by VALUE Widget.

    'widget_d' -> {Widget key: Widget instance}
    AnyGroup places VALUE Widgets into this dict.

VALUE Widget when viewed as an AnyGroup form a preset.
Thus AnyGroup has done much the work for preset management
tracking Widget instance and value.
"""


class AnyGroup:
    """Create Widget. Connect Widget with Output."""

    def __init__(self, d, e, container):
        """
        Create Widget.

        d: dict
            Preset definition

        e: dict
            Identify option group type.

        container: Container
            Place Widget.
        """
        self.data_d = {}
        self.widget_d = {}

        self._init_widget_ui(d, e, container, "")
        self._connect_widget()

    def _connect_widget(self):
        """
        Peruse the definition tree. Find
        signal item and connect to Widget.

        container: Container
            Place Widget.
        """
        # Widget, 'g'
        for g in self.widget_d.values():
            member = g.def_d.get(dk.MEMBER)
            leader = g.def_d.get(dk.LEADER)

            if member:
                for g1 in g.button_q:
                    # attribute value, 'a'
                    a = self._get_follower(member)

                    setattr(g, 'following', a)

                    # Signal argument tuple index, '1'
                    q = member[1]
                    for arg in q:
                        # Has no argument, '2'.
                        if len(arg) == 2:
                            g1.connect(arg[0], getattr(g, arg[1]))
                        else:
                            # Has argument.
                            q = arg[0], getattr(g, arg[1]), arg[2]
                            g1.connect(*q)
            if leader:
                g1 = g.widget

                # attribute value, 'a'
                a = self._get_follower(leader)

                setattr(g, 'following', a)

                # Signal argument tuple index, '1'
                q = leader[1]
                for arg in q:
                    # Has no argument, '2'.
                    if len(arg) == 2:
                        g1.connect(arg[0], getattr(g, arg[1]))
                    else:
                        # Has argument.
                        q = arg[0], getattr(g, arg[1]), arg[2]
                        g1.connect(*q)

    def _get_follower(self, partner):
        """
        Get or assemble partner Widget.

        partner: tuple
            (
                widget key ref tuple or dict
                signal tuple
            )

        Return: Widget, tuple, dict
            Gtk.Widget
            (Gtk.Widget, ...)
            {value: (Gtk.Widget, ...)}
        """
        b = None

        # A Widget partner is found in either a tuple or dict.
        pack = partner[0]

        if isinstance(pack, tuple):
            b = []

            for i in pack:
                # Could be Widget or None, 'c'.
                c = self.widget_d.get(i)

                # Don't fail on None.
                if c:
                    # Gtk widget, 'c'
                    c = c.widget
                    b.append(c)

        elif isinstance(pack, dict):
            b = {}
            for k, v in pack.items():
                # [Gtk.Widget, ...]
                q = []

                # tuple of Widget key, 'v'
                for i in v:
                    # Could be Widget or None, 'c'.
                    c = self.widget_d.get(i)

                    # Don't fail on None.
                    if c:
                        # Gtk widget, 'c'
                        c = c.widget
                        q.append(c)
                b[k] = q

        # Return Gtk widget, or (Gtk widget, ...),
        # or {value: (Gtk.Widget, ...)}
        return b

    def _init_widget_ui(self, d, e, container, path):
        """
        Initialize UI with Widget definition dict:

        d: dict
            Widget definition dict

        e: dict
            sub-Widget dict
            Pass {'group': container}.
            Use to manage group of Widget such as connecting to signal.

        container: Container
            Hold Widget in place.

        path: string
            key path for container
        """
        # Container or Widget definition dict, 'def_d'
        for k, def_d in d.items():
            if def_d.get(dk.IS_WIDGET):
                self._load_widget(k, def_d, e, container)
            else:
                self._load_container(k, def_d, e, container, path)

    def _load_container(self, k, d, e, container, path):
        """
        Load a Container with Widget.

        k: string
            Identify the Container in the AnyGroup.

        d: dict
            Container definition

        e: dict
            Identify option group type.

        container: Container
            Receive Widget.
        """
        path = f'{path}.{k}' if path else k

        # A Partner has an abbreviated key for readability.
        k1 = path

        if k:
            # Is it a Widget Partner?
            if k[0] == "_":
                k1 = k[1:]

        a = 1
        k2 = k1

        while k1 in self.widget_d:
            k1 = k2 + str(a)
            a += 1

        g = self.widget_d[k1] = d[dk.TYPE](d, e, self.data_d, k1)

        self._init_widget_ui(d[dk.CHILD], e, g, path)
        container.add(g)

    def _load_widget(self, k, d, e, container):
        """
        Create a Widget.

        k: string
            Identify the Widget in the AnyGroup.

        d: dict
            Widget definition

        e: dict
            Identify group.

        container: Gtk container or Container
            Receive Widget.
        """
        a = 1
        k1 = k

        while k1 in self.widget_d:
            k1 = k + str(a)
            a += 1

        g = self.widget_d[k1] = d[dk.TYPE](d, e, self.data_d, k1)
        container.add(g)
