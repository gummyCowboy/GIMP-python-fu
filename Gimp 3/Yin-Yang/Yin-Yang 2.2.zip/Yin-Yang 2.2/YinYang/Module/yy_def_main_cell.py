#!/usr/bin/env python3
from yy_constant import DefKey as dk
from yy_container import GridCell, HBox, VBox
from yy_def_main_widget import (
    ANIMATE_CHECK,
    AZIMUTH_LABEL, AZIMUTH_SPIN,
    BLUR_LABEL, BLUR_SPIN,
    COLOR_BUTTON_1, COLOR_BUTTON_2, COLOR_BUTTON_3, COLOR_LABEL,
    CONTRAST_LABEL, CONTRAST_SPIN,
    DEPTH_LABEL, DEPTH_SPIN,
    DIVISION_COMBO, DIVISION_LABEL,
    ELEVATION_LABEL, ELEVATION_SPIN,
    EMBOSS_CHECK,
    EMBOSS_MODE_COMBO,
    EYE_SPIN, EYE_W_LABEL,
    FLIP_LABEL,
    FRAME_COUNT_LABEL, FRAME_COUNT_SPIN,
    GRADIENT_BUTTON, GRADIENT_LABEL,
    MANAGE_BUTTON,
    MODE_COMBO, MODE_LABEL,
    OPACITY_LABEL, OPACITY_SPIN,
    OPACITY_SPIN_RIGHT,
    OVERLAY_CHECK,
    PATTERN_BUTTON, PATTERN_BUTTON_RIGHT, PATTERN_LABEL,
    RADIUS_LABEL, RADIUS_SPIN,
    RANDOM_BUTTON,
    RANDOM_COLOR_BUTTON,
    RANDOM_HUE_BUTTON,
    RANDOM_LABEL,
    RANDOM_LIGHTNESS_BUTTON,
    RANDOM_SATURATION_BUTTON,
    RIM_LABEL, RIM_SPIN,
    RIM_W_LABEL,
    RING_SPIN, RING_W_LABEL,
    SAVE_BUTTON,
    TIMER_LABEL, TIMER_SPIN,
    TRANSPARENT_EYE_CHECK,
    TYPE_RADIO, TYPE_LABEL,
    YANG_LABEL, YIN_LABEL
)

"""Define container with Widget occupant."""

CHILD = dk.CHILD
COLUMN = dk.COLUMN
TEXT = dk.TEXT
TYPE = dk.TYPE
WIDTH = dk.WIDTH
COLOR_VBOX_1 = {
    CHILD: {
        'color_label_1': YIN_LABEL,
        'color_1': COLOR_BUTTON_1
    },
    TYPE: VBox
}
COLOR_VBOX_2 = {
    CHILD: {
        'color_label_2': YANG_LABEL,
        'color_2': COLOR_BUTTON_2
    },
    TYPE: VBox
}
COLOR_VBOX_3 = {
    CHILD: {
        'color_label_3': RIM_LABEL,
        'color_3': COLOR_BUTTON_3
    },
    TYPE: VBox
}
PATTERN_VBOX_1 = {
    CHILD: {
        'pattern_label_1': YIN_LABEL,
        'pattern_1': PATTERN_BUTTON
    },
    TYPE: VBox
}
PATTERN_VBOX_2 = {
    CHILD: {
        'pattern_label_2': YANG_LABEL,
        'pattern_2': PATTERN_BUTTON
    },
    TYPE: VBox
}
PATTERN_VBOX_3 = {
    CHILD: {
        'pattern_label_3': RIM_LABEL,
        'pattern_3': PATTERN_BUTTON_RIGHT
    },
    TYPE: VBox
}
RANDOM_BUTTON_ROW = {
    CHILD: {
        'random_color_button': RANDOM_COLOR_BUTTON,
        'random_hue_button': RANDOM_HUE_BUTTON,
        'random_saturation_button': RANDOM_SATURATION_BUTTON,
        'random_lightness_button': RANDOM_LIGHTNESS_BUTTON
    },
    TYPE: HBox
}
DIALOG_BUTTON_ROW = {
    CHILD: {
        'save_button': SAVE_BUTTON,
        'manage_button': MANAGE_BUTTON
    },
    TYPE: HBox
}

OPACITY_VBOX_1 = {
    CHILD: {
        'type_opacity_label_1': YIN_LABEL,
        'yin_opacity': OPACITY_SPIN
    },
    TYPE: VBox
}
OPACITY_VBOX_2 = {
    CHILD: {
        'type_opacity_label_2': YANG_LABEL,
        'yang_opacity': OPACITY_SPIN
    },
    TYPE: VBox
}
OPACITY_VBOX_3 = {
    CHILD: {
        'type_opacity_label_3': RIM_LABEL,
        'rim_opacity': OPACITY_SPIN_RIGHT
    },
    TYPE: VBox
}

# Update definition with factory.
# GridCell / Column 0__________________________________________________________
AZIMUTH_CELL_0 = {CHILD: {'azimuth_label': AZIMUTH_LABEL}}
BLUR_CELL_0 = {CHILD: {'blur_label': BLUR_LABEL}}
COLOR_CELL_0 = {CHILD: {'color_label': COLOR_LABEL}}
CONTRAST_CELL_0 = {CHILD: {'contrast_label': CONTRAST_LABEL}}
DEPTH_CELL_0 = {CHILD: {'depth_label': DEPTH_LABEL}}
DIVISION_CELL_0 = {CHILD: {'division_label': DIVISION_LABEL}}
ELEVATION_CELL_0 = {CHILD: {'elevation_label': ELEVATION_LABEL}}
EMBOSS_MODE_CELL_0 = {CHILD: {'emboss_mode_label': MODE_LABEL}}
EMBOSS_OPACITY_CELL_0 = {
    CHILD: {'emboss_opacity_label': OPACITY_LABEL}
}
EMBOSS_TYPE_CELL_0 = {CHILD: {'emboss_type_label': TYPE_LABEL}}
EYE_W_CELL_0 = {CHILD: {'eye_w_label': EYE_W_LABEL}}
FLIP_CELL_0 = {CHILD: {'flip_label': FLIP_LABEL}}
FRAME_COUNT_CELL_0 = {CHILD: {'frame_label': FRAME_COUNT_LABEL}}
GRADIENT_MODE_CELL_0 = {CHILD: {'gradient_mode_label': MODE_LABEL}}
GRADIENT_OPACITY_CELL_0 = {
    CHILD: {'overlay_opacity_label': OPACITY_LABEL}
}
OPACITY_CELL_0 = {CHILD: {'opacity_label': OPACITY_LABEL}}
OVERLAY_GRADIENT_CELL_0 = {CHILD: {'overlay_gradient_label': GRADIENT_LABEL}}
RANDOM_COLOR_CELL_0 = {CHILD: {'random_color_label': RANDOM_LABEL}}
PATTERN_CELL_0 = {CHILD: {'pattern_label': PATTERN_LABEL}}
RADIUS_CELL_0 = {CHILD: {'radius_label': RADIUS_LABEL}}
RANDOM_ROW = {CHILD: {'random': RANDOM_BUTTON}}
RIM_W_CELL_0 = {CHILD: {'rim_label': RIM_W_LABEL}}
RING_W_CELL_0 = {CHILD: {'ring_label': RING_W_LABEL}}
TIMER_CELL_0 = {CHILD: {'timer_label': TIMER_LABEL}}
TYPE_CELL_0 = {CHILD: {'type_label': TYPE_LABEL}}

for d in (
    AZIMUTH_CELL_0, BLUR_CELL_0, COLOR_CELL_0,
    CONTRAST_CELL_0, DEPTH_CELL_0,
    ELEVATION_CELL_0, DIVISION_CELL_0,
    EMBOSS_MODE_CELL_0, EMBOSS_OPACITY_CELL_0, EMBOSS_TYPE_CELL_0,
    EYE_W_CELL_0, FLIP_CELL_0, FRAME_COUNT_CELL_0,
    GRADIENT_MODE_CELL_0,
    GRADIENT_OPACITY_CELL_0, OPACITY_CELL_0,
    OVERLAY_GRADIENT_CELL_0, RANDOM_COLOR_CELL_0,
    PATTERN_CELL_0, RADIUS_CELL_0,
    RANDOM_ROW, RIM_W_CELL_0,
    TIMER_CELL_0, RING_W_CELL_0, TYPE_CELL_0
):
    d.update({COLUMN: 0, TYPE: GridCell})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# GridCell / Column 1__________________________________________________________
ANIMATE_CELL = {CHILD: {'is_animate': ANIMATE_CHECK}}
AZIMUTH_CELL_1 = {CHILD: {'azimuth': AZIMUTH_SPIN}}
BLUR_CELL_1 = {CHILD: {'blur': BLUR_SPIN}}
CONTRAST_CELL_1 = {CHILD: {'contrast': CONTRAST_SPIN}}
DEPTH_CELL_1 = {CHILD: {'depth': DEPTH_SPIN}}
DIVISION_CELL_1 = {CHILD: {'division': DIVISION_COMBO}}
ELEVATION_CELL_1 = {CHILD: {'elevation': ELEVATION_SPIN}}
EMBOSS_CELL = {CHILD: {'is_emboss': EMBOSS_CHECK}}
EMBOSS_MODE_CELL_1 = {CHILD: {'emboss_mode': EMBOSS_MODE_COMBO}}
EMBOSS_OPACITY_CELL_1 = {CHILD: {'emboss_opacity': OPACITY_SPIN}}
EYE_W_CELL_1 = {CHILD: {'eye_width': EYE_SPIN}}
FRAME_COUNT_CELL_1 = {CHILD: {'frame_count': FRAME_COUNT_SPIN}}
GRADIENT_MODE_CELL_1 = {CHILD: {'gradient_mode': MODE_COMBO}}
GRADIENT_OPACITY_CELL_1 = {CHILD: {'gradient_opacity': OPACITY_SPIN}}
OVERLAY_GRADIENT_CELL_1 = {CHILD: {'overlay_gradient': GRADIENT_BUTTON}}
OVERLAY_CELL = {CHILD: {'is_overlay': OVERLAY_CHECK}}
RADIUS_CELL_1 = {CHILD: {'radius': RADIUS_SPIN}}
RIM_W_CELL_1 = {CHILD: {'rim_width': RIM_SPIN}}
RING_W_CELL_1 = {CHILD: {'ring_width': RING_SPIN}}
TIMER_CELL_1 = {CHILD: {'timer': TIMER_SPIN}}
TRANSPARENT_EYE_CELL = {CHILD: {'is_transparent_eye': TRANSPARENT_EYE_CHECK}}
TYPE_CELL_1 = {CHILD: {'type': TYPE_RADIO}}

for d in (
    ANIMATE_CELL, AZIMUTH_CELL_1,
    BLUR_CELL_1, CONTRAST_CELL_1,
    DEPTH_CELL_1, DIVISION_CELL_1,
    ELEVATION_CELL_1, EMBOSS_CELL, EMBOSS_MODE_CELL_1,
    EMBOSS_OPACITY_CELL_1, EYE_W_CELL_1,
    FRAME_COUNT_CELL_1, GRADIENT_MODE_CELL_1,
    GRADIENT_OPACITY_CELL_1, OVERLAY_GRADIENT_CELL_1,
    OVERLAY_CELL, RADIUS_CELL_1,
    RIM_W_CELL_1, RING_W_CELL_1,
    TIMER_CELL_1, TRANSPARENT_EYE_CELL, TYPE_CELL_1
):
    d.update({COLUMN: 1, TYPE: GridCell})
