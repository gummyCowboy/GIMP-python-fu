#!/usr/bin/env python3
import gi                              # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp         # noqa

"""
Include a function to initialize static pdb
run class, and static pdb run class.

The static class' config object is reused. So configuring a
pdb procedure has an additional dynamic in that the previous
call to 'class.do' can be repeated, but without the configuration
settings.
"""


def init_pdb():
    """Implement a get-once strategy for Gimp's pdb interface. """
    for q in (
        (BrightnessContrast, 'gimp-drawable-brightness-contrast'),
        (GradientFill, 'gimp-drawable-edit-gradient-fill'),
        (ItemPosition, 'gimp-image-get-item-position'),
        (EllipseSelect, 'gimp-image-select-ellipse')
    ):
        a, n = q
        a.pdb = Gimp.get_pdb().lookup_procedure(n)
        a.config = a.pdb.create_config()


class BrightnessContrast:
    pdb = config = None

    def do(q):
        """
        q: tuple
            Configure the procedure.
            (
                ('drawable', Gimp.Drawable),
                ('brightness', float),
                ('contrast', float)
            )
        """
        for q1 in q:
            BrightnessContrast.config.set_property(*q1)
        BrightnessContrast.pdb.run(BrightnessContrast.config)


class Emboss:
    """Reference: gegl.org/operations/gegl-emboss.html"""

    def do(z, q):
        """
        z: Gimp.Layer
            Receive emboss-effect.

        q: tuple
            Configure the filter.
            (
                ('azimuth', float),
                ('elevation', float),
                ('depth', int)
            )
        """
        a = Gimp.DrawableFilter.new(z, "gegl:emboss", "")
        config = a.get_config()

        for q1 in q:
            config.set_property(*q1)

        a.update()
        z.append_filter(a)


class GradientFill:
    pdb = config = None

    def do(q):
        """
        q: tuple
            Configure the procedure.
            (
                ('drawable', Gimp.Drawable),
                ('gradient-type', Gimp.GradientType),
                ('offset', float),
                ('supersample', True),
                ('supersample-max-depth', int),
                ('supersample-threshold', float),
                ('dither', True),
                ('x1', float),
                ('y1', float),
                ('x2', float),
                ('y2', float)
            )
        """
        for q1 in q:
            GradientFill.config.set_property(*q1)
        GradientFill.pdb.run(GradientFill.config)


class ItemPosition:
    pdb = config = None

    def do(q):
        """
        q: tuple
            Configure the procedure.
            (
                ('image', Gimp.Image),
                ('item', Gimp.Item)
            )
        """
        for q1 in q:
            ItemPosition.config.set_property(*q1)
        return ItemPosition.pdb.run(ItemPosition.config).index(1)


class EllipseSelect:
    pdb = config = None

    def do(q):
        """
        q: tuple
            Configure the procedure.
            (
                ('image', Gimp.Image),
                ('operation', Gimp.ChannelOps),
                ('x', float),
                ('y', float),
                ('width', float),
                ('height', float)
            )
        """
        for q1 in q:
            EllipseSelect.config.set_property(*q1)
        EllipseSelect.pdb.run(EllipseSelect.config)
