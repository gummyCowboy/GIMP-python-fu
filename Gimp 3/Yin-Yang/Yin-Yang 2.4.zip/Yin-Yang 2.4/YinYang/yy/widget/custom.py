#!/usr/bin/env python3
from plugout.gegl_color import convert_float_to_gegl_color
from plugout.widget.button import Button
from plugout.widget.label import Label
from plugout.widget.radio import RadioGroup
from yy.constant import (
    IMAGE_SIZE, RADIUS_VALUE_CHANGE, RIM_VALUE_CHANGE, SYMBOL_TYPE_CHANGE
)
from random import randint, uniform
import colorsys


class ButtonRandomColor(Button):
    """Customize Button with a random color button type."""

    def __init__(self, def_d):
        """
        def_d: dict
            ButtonRandomColor definition

            text: string
        """
        super().__init__(def_d)

        self._color_button_q = None
        self._index = (
            'random_color_button',
            'random_hue_button',
            'random_saturation_button',
            'random_lightness_button'
        ).index(self.key)
        self.widget.connect('clicked', self.on_random_color_button_click)

    def on_random_color_button_click(self, _):
        """
        Randomize color button value on multiple random-button action.

        _: Gtk.Button
            Is responsible.
        """
        if self._color_button_q is None:
            self._color_button_q = [
                self.widget_d[k].widget
                for k in ('color_1', 'color_2', 'color_3')
            ]

        rgb = [uniform(.0, 1.) for _ in range(3)]

        if self._index:
            i1 = self._index - 1

            # hue, saturation, lightness, 'q', in float, .0 to 1.
            q = list(colorsys.rgb_to_hls(*rgb))

            # Invert HLS value.
            q[i1] = 1. - q[i1]

            rgb1 = list(colorsys.hls_to_rgb(*q))

        else:
            # Invert color.
            rgb1 = [1. - f for f in rgb]

        # The Rim color is randomly borrowing.
        rgb2 = [(rgb[i], rgb1[i])[randint(0, 1)] for i in range(3)]

        for a in zip(self._color_button_q, (rgb, rgb1, rgb2)):
            g, q = a

            # alpha, '1.'
            q.append(1.)

            g.set_color(convert_float_to_gegl_color(q))

            # Gtk only sends this signal when its dialog is accepted.
            g.emit('color-changed')


class LabelEyeFactor(Label):
    """Customize Label with a signal listener."""

    def __init__(self, def_d):
        """
        def_d: dict
            LabelPathReflect definition
        """
        self._ring_width = self._eye_width = self._radius = .0
        super().__init__(def_d)

    def on_custom_signal(self, _, arg):
        """
        Respond to change in the image size. Both the symbol radius
        and the rim width change the image size.

        _: GObject
            AnyGroup host

        arg: tuple
            (Widget instance, Widget value)
        """
        # Widget key, Widget value
        _, widget, value = arg
        k = widget.key

        if k == 'radius':
            self._radius = value

        elif k == 'eye_width':
            self._eye_width = value

        elif k == 'ring_width':
            self._ring_width = value

        f = (self._radius * self._ring_width) * self._eye_width
        self.widget.set_text(f"{int(round(f))}")


class LabelRingFactor(Label):
    """Customize Label with a signal listener."""

    def __init__(self, def_d):
        """
        def_d: dict
            LabelPathReflect definition
        """
        self._ring_width = self._radius = .0
        super().__init__(def_d)

    def on_custom_signal(self, _, arg):
        """
        Respond to change in the image size. Both the symbol radius
        and the rim width change the image size.

        _: GObject
            AnyGroup host

        arg: tuple
            (Widget instance, Widget value)
        """
        # Widget key, Widget value
        _, widget, value = arg
        k = widget.key

        if k == 'radius':
            self._radius = value

        elif k == 'ring_width':
            self._ring_width = value

        f = self._radius * self._ring_width
        self.widget.set_text(f"{int(round(f))}")


class LabelImageSize(Label):
    """Customize Label with a signal listener."""

    def __init__(self, def_d):
        """
        def_d: dict
            LabelPathReflect definition
        """
        super().__init__(def_d)

        self._radius = self._rim_width = 0.
        self.host.connect(RADIUS_VALUE_CHANGE, self.on_image_size_change)
        self.host.connect(RIM_VALUE_CHANGE, self.on_image_size_change)

    def on_image_size_change(self, *arg):
        """
        Respond to change in the symbol radius.

        arg: tuple
            (host, (SpinButton, value))
        """
        # Widget, Widget value
        _, g, value = arg[-1]

        if g.key == 'radius':
            self._radius = value

        else:
            self._rim_width = value

        # extra image width for antialiasing, '4'
        a = int(round((self._radius * 2) + (self._rim_width * 2) + 4))
        self.widget.set_text(IMAGE_SIZE.format(a, a))


class RadioGroupType(RadioGroup):
    """Customize RadioGroup with a change signal."""

    def __init__(self, *arg):
        super().__init__(*arg)
        for g in self.button_q:
            g.connect('realize', self.on_type_change)
            g.connect('toggled', self.on_type_change)

    def on_type_change(self, button):
        """
        Respond to Type Gtk.ComboBoxText change signal.

        button: Gtk.RadioButton
            Is responsible.
        """
        self.host.emit(SYMBOL_TYPE_CHANGE, self.get_a())
