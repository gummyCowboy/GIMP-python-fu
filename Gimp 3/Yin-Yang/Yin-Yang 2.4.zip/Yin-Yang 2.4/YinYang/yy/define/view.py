#!/usr/bin/env python3
from plugout.constant import ACCEPT, CANCEL, PREVIEW
from plugout.container.box import HBox
from plugout.define.key import CHILD, PACK, PACK_END, PADDING, TEXT, TYPE
from plugout.widget.button import ButtonAccept, ButtonCancel, ButtonPreview


# View_________________________________________________________________________
CANCEL_BUTTON = {
    PACK: PACK_END, PADDING: (0, 0, 0, 1), TEXT: CANCEL, TYPE: ButtonCancel
}
PREVIEW_BUTTON = {
    PACK: PACK_END, PADDING: (0, 0, 0, 1), TEXT: PREVIEW, TYPE: ButtonPreview
}
ACCEPT_BUTTON = {PACK: PACK_END, TEXT: ACCEPT, TYPE: ButtonAccept}
VIEW_HBOX = {
    CHILD: {
        1: ACCEPT_BUTTON, 'preview_button': PREVIEW_BUTTON, 2: CANCEL_BUTTON
    },
    PACK: PACK_END,
    PADDING: (2, 4, 300, 10),
    TYPE: HBox
}

DEFINE_VIEW = {
    'view': {CHILD: {1: VIEW_HBOX}, TYPE: HBox}
}
