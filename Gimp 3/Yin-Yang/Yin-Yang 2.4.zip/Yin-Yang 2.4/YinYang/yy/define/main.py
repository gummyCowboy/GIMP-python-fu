#!/usr/bin/env python3
from plugout.container.notebook import Notebook
from plugout.define.key import PACK, PACK_START
from plugout.define.key import CHILD, TYPE
from yy.define.rotate import PAGE_ROTATE
from yy.define.emboss import PAGE_EMBOSS
from yy.define.overlay import PAGE_OVERLAY
from yy.define.scale import PAGE_SCALE
from yy.define.page_type import PAGE_TYPE
from yy.define.preset import PAGE_PRESET

# AnyGroup definition: {key: definition}
DEFINE_MAIN = {
    1: {
        CHILD: {
            1: PAGE_SCALE,
            2: PAGE_TYPE,
            3: PAGE_OVERLAY,
            4: PAGE_EMBOSS,
            5: PAGE_ROTATE,
            6: PAGE_PRESET
        },
        PACK: PACK_START,
        TYPE: Notebook
    }
}
