#!/usr/bin/env python3
from copy import deepcopy
from plugout.any_group import AnyGroup
from plugout.constant import (
    ANY_CHANGE,
    CTRL_P,
    HOST_ACCEPT_EVENT,
    HOST_CANCEL_EVENT,
    HOST_PREVIEW_EVENT,
    HOST_RESIZE_WINDOW,
    KEY_PRESS_EVENT
)
from plugout.container.box import VBox
from plugout.define.key import CHILD, PACK, PACK_START, TYPE
from yy.constant import MAIN_SIGNAL, RESOURCE_KEY, TITLE, YIN_YANG
from yy.define.main import DEFINE_MAIN
from yy.define.view import DEFINE_VIEW
from yy.output import Output
import gi
gi.require_version('Gdk', '3.0')
gi.require_version('Gimp', '3.0')
gi.require_version('GimpUi', '3.0')
gi.require_version('Gtk', '3.0')
from gi.repository import Gdk, GObject, Gtk             # noqa

VBOX_DEF = {CHILD: {}, PACK: PACK_START, TYPE: VBox}


def get_resource(output_d, widget_d):
    """
    During production, the Gimp.Resource is used, not the resource's name.
    Find the 'Gimp.Resource' in the AnyGroup's Widget dict.
    Match key with RESOURCE_KEY and then get its resource object.

    output_d: dict
        Collect resource.
        {Widget key: Gimp.Resource}

    widget_d: dict
        Find Widget.
        {Widget key: Widget instance}
    """
    for k, a in widget_d.items():
        if k in RESOURCE_KEY:
            # Widget instance, 'a'
            output_d[k] = a.get_resource()
        elif isinstance(a, dict):
            # nested preset dict, 'a'
            # The output dict is not nested.
            get_resource(output_d, a)


class WindowMain(GObject.GObject):
    """Manage plug-in main window life-cycle. Create a main event loop."""
    __gsignals__ = MAIN_SIGNAL

    def __init__(self):
        GObject.GObject.__init__(self)

        self._any_group = self._view_group = self._preview_button = None
        self._preview_d = {}
        self._output = Output()
        self.gtk_window = Gtk.Window.new(Gtk.WindowType.TOPLEVEL)
        vbox = VBox(VBOX_DEF)

        self.gtk_window.add(vbox.widget)
        self.gtk_window.set_title(TITLE)
        self.add_widget(vbox)
        self._init_preview_button()
        self.gtk_window.show_all()
        self.gtk_window.connect('delete_event', self.on_cancel_event)
        self.gtk_window.connect(KEY_PRESS_EVENT, self.on_key_press)
        self.connect(HOST_ACCEPT_EVENT, self.on_accept_event)
        self.connect(HOST_CANCEL_EVENT, self.on_cancel_event)
        self.connect(HOST_PREVIEW_EVENT, self.on_preview_event)
        self.connect(HOST_RESIZE_WINDOW, self.on_resize_window)
        self.connect(ANY_CHANGE, self.on_any_change)

        # Update the window's geometry as its a step behind.
        self.gtk_window.resize(1, 1)

        # Start the main signal processing ring.
        Gtk.main()

    def _init_preview_button(self):
        """
        Find the Gtk Widget for the Preview button. Add tooltip to the button.
        """
        self._preview_button = self._view_group.widget_d.get('preview_button')
        if self._preview_button:
            self._preview_button = self._preview_button.widget
            self._preview_button.set_tooltip_text(CTRL_P)

    def add_widget(self, container):
        """
        Add widget to the Dialog's content area.

        container: plugout.Box
            There's room to grow.
        """
        self._any_group = AnyGroup(
            DEFINE_MAIN,
            container,
            preset_key=YIN_YANG,
            is_any_change=True,
            host=self
        )
        self._view_group = AnyGroup(
            DEFINE_VIEW,
            container,
            preset_key=None,
            is_any_change=True,
            host=self
        )

    def on_any_change(self, *_):
        """Enable the Preview button on any Widget change."""
        if self._preview_button:
            self._preview_button.set_sensitive(1)

    def on_accept_event(self, *_):
        """
        Accept the window content. Exit the plug-in.
        """
        self.gtk_window.hide()
        self.on_preview_event()
        self.on_cancel_event()

    def on_cancel_event(self, *_):
        """
        Exit the plug-in.

        _: tuple
            (GTK window, GTK Event)
            Triggered delete.

        Return: True
            Tell GTK that the closing operation is handled.
        """
        self.gtk_window.destroy()
        Gtk.main_quit()

        # Let GTK know that a key-type event has been handled.
        return True

    def on_key_press(self, _, event_key):
        """
        Scan for a Control-P keypress. If found, emit a preview signal.

        _ Gtk.Dialog
            not used

        event_key: Gdk.EventKey
        Return: bool
            Tell Gtk if the keypress is handled.
        """
        is_control = (event_key.state & Gdk.ModifierType.CONTROL_MASK)
        keypress = event_key.keyval

        if is_control and keypress == Gdk.KEY_p:
            self._preview_button.emit('clicked')
            return True

        elif keypress == Gdk.KEY_Escape:
            return self.on_cancel_event()
        return False

    def on_queue_click(self, *_):
        self._preview_button.emit('clicked')

    def on_preview_event(self, *_):
        """
        Respond to a Preview button action by performing a preview
        but only if things have changed since the last preview.
        """
        d = self._any_group.value_d
        g = self._preview_button

        if g:
            if not g.get_style_context().has_class('pressed'):
                g.get_style_context().add_class('pressed')

        if d != self._preview_d:
            self._preview_d = deepcopy(d)

            # 'value_d' has resource stored as a
            # string representing the resource's name,
            # but the actual resource is needed,
            # hence the call to 'get_resource'.
            e = {}

            get_resource(e, self._any_group.widget_d)
            self._output.create(d, e)
        if g:
            g.get_style_context().remove_class('pressed')
            g.set_sensitive(0)

    def on_resize_window(self, *_):
        """
        Resize the main window. The Emboss Page/Tab causes a
        stretched button to occur when its page is shown,
        and this function fixes that problem.
        """
        self.gtk_window.resize(1, 1)
