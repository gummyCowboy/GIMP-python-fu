#!/usr/bin/env python3
from plugout.constant import ENTRY_SAVE_CHANGE
from plugout.define.key import KEY_PATH, MARKUP, TEXT
from plugout.widget.emit import WidgetValue
import gi                                  # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk              # noqa

"""
Include 'Gtk.Label' wrapper class.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/Label.html'
"""


class Label(WidgetValue):
    """Customize 'Gtk.Label' with a wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            Label definition
                markup: tuple
                    (markup string, ...)
                text: string
                    Is the label's display descriptor.
        """
        g = Gtk.Label.new()
        s = def_d.get(TEXT, "")

        if def_d.get(MARKUP):
            for s1 in def_d[MARKUP]:
                # Wrap with markup.
                s = f"<{s1}>{s}</{s1}>"

        g.set_markup(s)
        super().__init__(def_d, g)
        g.set_yalign(.5)


class LabelPathReflect(Label):
    """
    Customize Label with a signal listener.
    The dialog-host is a GObject with custom signal.
    """

    def __init__(self, def_d):
        """
        def_d: dict
            LabelPathReflect definition
        """
        super().__init__(def_d)
        self.host.connect(ENTRY_SAVE_CHANGE, self.on_entry_save_change)

    def on_entry_save_change(self, *arg):
        # The EntrySave sent this value, '-1'.
        self.widget.set_text(arg[-1])


class LabelPreset(Label):
    """Customize Label as a preset key descriptor."""

    def __init__(self, def_d):
        """
        def_d: dict
            LabelPreset definition
                key_path: list
                [preset key, ...]
                Identify this preset's key-path inside
                'AnyGroup.value_d' and 'AnyGroup.widget_d'.
        """
        if def_d[KEY_PATH]:
            def_d[TEXT] = f'{def_d[KEY_PATH][-1]} Preset'

        else:
            def_d[TEXT] = "Preset"
        super().__init__(def_d)
