#!/usr/bin/env python3
from plugout.constant import KEY_PRESS_EVENT
from plugout.define.key import HOMOGENEOUS, TEXT, VALUE
from plugout.widget.emit import WidgetValue
from random import choice
import gi                               # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk           # noqa

"""Define a class that can manage a group of related 'Gtk.RadioButton."""


class RadioGroup(WidgetValue):
    """Manage multiple 'Gtk.RadioButton' as a group having a common factor."""

    def __init__(self, def_d):
        """
        def_d: dict
            RadioGroup definition
                homogeneous: bool
                    When True, the 'Gtk.RadioButtons' are all the same size.

                text: tuple
                    Initialize the display descriptor

                value: int
                    0 to the number 'Gtk.RadioButton' minus one
                    Initialize a Gtk.RadioButton to active
                    using its index in the group.
        """
        hbox = Gtk.HBox(homogeneous=def_d.get(HOMOGENEOUS, True))

        super().__init__(def_d, hbox)

        self.button_q = []
        group = None

        for s in def_d.get(TEXT, ()):
            g = Gtk.RadioButton.new_with_label_from_widget(group, s)

            g.connect('toggled', self.on_value_change)
            g.connect('realize', self.on_value_change)
            g.connect(KEY_PRESS_EVENT, self.on_key_press)
            self.button_q.append(g)

            if not group:
                group = g
            hbox.add(g)
        if self.button_q:
            a = self.value_d[self.key] = def_d.get(VALUE, 0)
            self.button_q[a].set_active(1)

    def get_a(self):
        """
        Retrieve the index of the 'Gtk.RadioButton' that is active.

        Return: int
        """
        for i, g in enumerate(self.button_q):
            if g.get_active():
                return i

        # nothing active
        return 0

    def randomize(self, *_):
        """
        Respond to a randomize signal. Randomize
        the value of the RadioGroup.
        """
        if self.button_q:
            choice(self.button_q).set_active(1)

    def set_a(self, a):
        """
        Check type in case of version change.

        a: int
            The int is an index to the button in the initial button list.
        """
        if self.button_q:
            if isinstance(a, int):
                # Check for outdated input.
                if a < len(self.button_q):
                    self.button_q[a].set_active(1)
                else:
                    self.button_q[0].set_active(1)
            else:
                self.button_q[0].set_active(1)
