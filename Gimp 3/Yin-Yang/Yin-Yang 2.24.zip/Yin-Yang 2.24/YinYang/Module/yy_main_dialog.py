#!/usr/bin/env python3
from yy_any_group import AnyGroup, InterComm
from yy_constant import ACCEPT, CANCEL, PREVIEW, RESOURCE_KEY
from yy_container import ContentArea
from yy_def_main import MAIN
from yy_output import Output
from yy_preset import Preset
import gi
import sys
gi.require_version('Gimp', '3.0')
gi.require_version('GimpUi', '3.0')
gi.require_version('Gtk', '3.0')
from gi.repository import Gdk, GimpUi, GObject, Gtk   # noqa

VERSION = "Yin-Yang 2.23"

# Preview button id
RESPONSE_PREVIEW = -99

# Button response in dialog.
response_d = {
    RESPONSE_PREVIEW: None,
    Gtk.ResponseType.CANCEL: None,
    Gtk.ResponseType.DELETE_EVENT: None,
    Gtk.ResponseType.OK: None
}


class Dialog:
    """Create a GimpUI.Dialog having Cancel, Preview, and Accept buttons."""

    def __init__(self, load_ui, response_p):
        """
        load_ui: function
            Add widget to the Dialog's content area.

        response_p: function
            Handle Cancel, Preview, and Accept button action.
        """
        self.dialog = GimpUi.Dialog(
            use_header_bar=Gtk.Settings.get_default().
            get_property("gtk-dialogs-use-header"),
            title=VERSION
        )
        self.dialog.add_button(CANCEL, Gtk.ResponseType.CANCEL)

        g = self._preview_button = self.dialog.add_button(
            PREVIEW, RESPONSE_PREVIEW
        )

        g.set_tooltip_text("Ctrl-P")
        self.dialog.add_button(ACCEPT, Gtk.ResponseType.OK)
        self.dialog.connect('key-press-event', self.on_key_press)
        GObject.signal_new(
            'randomize',
            self.dialog,
            GObject.SIGNAL_RUN_LAST,
            GObject.TYPE_PYOBJECT,
            (GObject.TYPE_PYOBJECT,)
        )
        load_ui(self.dialog.get_content_area(), g)
        self.dialog.show()

        # Map button responses to callback.
        self.dialog.connect('response', response_p)

        # Start event loop.
        Gtk.main()

    def on_key_press(self, _, event_key):
        """
        Save the preset if the user presses the return key.

        _ Gtk.Dialog
            not  used

        entry: Gtk.Entry
            Is responsible for event.

        event_key: Gdk.EventKey
        """
        is_control = (event_key.state & Gdk.ModifierType.CONTROL_MASK)
        if is_control and event_key.keyval == Gdk.KEY_p:
            self._preview_button.grab_focus()
            self._preview_button.emit('clicked')


class MainDialog(GObject.GObject):
    """
    Create a GimpUI.Dialog for user interaction and define output settings.
    """
    # {custom signal name: (emission stage, type of signal, define argument)}
    __gsignals__ = {
        'any-change': (
            GObject.SIGNAL_RUN_FIRST, None, (GObject.TYPE_PYOBJECT,)
        )
    }

    def __init__(self):
        """Open a dialog. Respond to user interaction."""
        GObject.GObject.__init__(self)

        # Init UI theme.
        GimpUi.init(sys.argv[0])

        self._preview_d = {}
        self._preview_button = None
        self._output = Output()

        response_d[Gtk.ResponseType.CANCEL] = \
            response_d[Gtk.ResponseType.DELETE_EVENT] = self.on_cancel
        response_d[Gtk.ResponseType.OK] = self.on_accept
        response_d[RESPONSE_PREVIEW] = self.on_preview
        self.connect('any-change', self.on_any_change)
        Dialog(self._add_widget, self.on_dialog_button)

    def _add_widget(self, content_area, preview_button):
        """
        Add Yin-Yang widget to the Dialog's content area.

        container: Gtk.Box
            There's room to grow.

        preview_button: Gtk.Button
        """
        self._preview_button = preview_button
        inter_comm = InterComm(main=self)
        container = ContentArea(content_area, inter_comm)
        self._any_group = AnyGroup(MAIN, inter_comm, container)
        Preset.main_widget_d = self._any_group.widget_d
        Preset.main = MAIN
        content_area.show_all()

    def on_accept(self):
        """
        Respond to an Accept button action. Create a Yin-Yang image.
        """
        self.on_preview()
        Gtk.main_quit()

    def on_any_change(self, *_):
        """Enable the Preview button on any Widget change."""
        if self._preview_button:
            self._preview_button.set_sensitive(1)

    @staticmethod
    def on_cancel():
        """Close the dialog. The user chose to cancel."""
        Gtk.main_quit()

    @staticmethod
    def on_dialog_button(_, response_id):
        """
        Handle a user initiated dialog-process button action.

        _: GimpUI.Dialog
            Is the Yin-Yang dialog.
            not used

        response_id: Gtk.ResponseType
            Identify button.
        """
        p = response_d.get(response_id)
        if p is not None:
            p()

    def on_preview(self):
        """
        Respond to a Preview button action by performing a preview
        but only if things have changed since the last preview.
        """
        d = self._any_group.data_d

        if d != self._preview_d:
            self._preview_d = d.copy()

            # 'data_d' has resource stored as a
            # string, as in the resource's name.
            e = {}

            for k in RESOURCE_KEY:
                e[k] = self._any_group.widget_d[k].get_resource()
            self._output.create(d, e)

        self._preview_button.set_sensitive(0)
        return
