#!/usr/bin/env python3
from yy_constant import (
    ALL,
    ANIMATE,
    AZIMUTH,
    BLUR,
    BLUR_TIP,
    CLOCKWISE,
    COLOR,
    CONTRAST,
    COUNTER_CLOCKWISE,
    DEFAULT,
    DEPTH,
    DEPTH_TIP,
    DIVISION,
    DIVISION_TIP,
    ELEVATION,
    EMBOSS,
    EYE_WIDTH,
    EYE_WIDTH_TIP,
    FRAME_COUNT,
    GRADIENT,
    HUE,
    LAYER_MODE_Q,
    LEATHER,
    LIGHTNESS,
    MANAGE,
    MODE,
    OPACITY,
    OVERLAY,
    PATTERN,
    RADIUS,
    RANDOM,
    REVERSED,
    REVERSED_TIP,
    RIM,
    RIM_WIDTH,
    RING_WIDTH,
    RING_SPIN_TIP,
    ROTATE,
    SATURATION,
    SAVE_,
    TIMER,
    TIMER_TIP,
    TRANSPARENT_EYE,
    TYPE_,
    TYPE_FOLLOWING_D,
    get_division_list,
    get_gradient_list,
    get_mode_list,
    get_pattern_list,
    DefKey as dk
)
from yy_signal import on_resource_realize, on_resource_set
from yy_widget import (
    ButtonRandom,
    ButtonRandomColor,
    CheckButton,
    CheckButtonLeader,
    ColorButton,
    ComboBoxText,
    GradientButton,
    Label,
    PatternButton,
    RadioGroup,
    RadioGroupType,
    SpinButton,
    SpinButtonRim
)
from yy_widget_preset import ButtonManage, ButtonSave
import gi                           # type: ignore
gi.require_version('Gdk', '3.0')
from gi.repository import Gdk, Gtk  # noqa

"""Define usable Widget."""

ADJUSTMENT = dk.ADJUSTMENT
CHILD = dk.CHILD
COLUMN = dk.COLUMN
COLUMNS = dk.COLUMNS
DIGITS = dk.DIGITS
GET_LIST = dk.GET_LIST
IS_WIDGET = dk.IS_WIDGET
LIMIT = dk.LIMIT
PADDING = dk.PADDING
SIGNAL = dk.SIGNAL
TEXT = dk.TEXT
TOOLTIP = dk.TOOLTIP
TYPE = dk.TYPE
VALUE = dk.VALUE
WIDTH = dk.WIDTH
RESOURCE_RESPONSE = (
    ('resource-set', on_resource_set),
    ('realize', on_resource_realize)
)
GRADIENT_BUTTON = {
    IS_WIDGET: True,
    LIMIT: get_gradient_list,
    SIGNAL: RESOURCE_RESPONSE,
    TYPE: GradientButton,
    VALUE: DEFAULT
}
MANAGE_BUTTON = {IS_WIDGET: True, TEXT: MANAGE, TYPE: ButtonManage}
PATTERN_BUTTON_RIGHT = {
    IS_WIDGET: True,
    LIMIT: get_pattern_list,
    SIGNAL: RESOURCE_RESPONSE,
    TYPE: PatternButton,
    VALUE: LEATHER
}
PATTERN_BUTTON = PATTERN_BUTTON_RIGHT.copy()

PATTERN_BUTTON.update({PADDING: (0, 0, 0, 10)})

RANDOM_BUTTON = {IS_WIDGET: True, TEXT: RANDOM, TYPE: ButtonRandom}
SAVE_BUTTON = {
    IS_WIDGET: True, PADDING: (0, 0, 0, 4), TEXT: SAVE_, TYPE: ButtonSave
}

# Update definition with factory.
# Button_______________________________________________________________________
RANDOM_COLOR_BUTTON = {PADDING: (0, 0, 0, 4), TEXT: COLOR}
RANDOM_HUE_BUTTON = {PADDING: (0, 0, 0, 4), TEXT: HUE}
RANDOM_LIGHTNESS_BUTTON = {TEXT: LIGHTNESS}
RANDOM_SATURATION_BUTTON = {PADDING: (0, 0, 0, 4), TEXT: SATURATION}

for i, d in enumerate((
    RANDOM_COLOR_BUTTON, RANDOM_HUE_BUTTON,
    RANDOM_LIGHTNESS_BUTTON, RANDOM_SATURATION_BUTTON
)):
    d.update({
        IS_WIDGET: True,
        dk.LEADER: (
            ('color_1', 'color_2', 'color_3'),
            (('clicked', 'on_random_color_button_click', i),)
        ),
        TYPE: ButtonRandomColor
    })
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# CheckButton__________________________________________________________________
ANIMATE_CHECK = {
    LIMIT: (True, True),
    dk.LEADER: (
        ('frame_count', 'timer', 'frame_label', 'timer_label'),
        (
            ('toggled', 'on_leader_toggle'),
            ('realize', 'on_leader_toggle')
        )
    ),
    TEXT: ANIMATE
}
EMBOSS_CHECK = {
    LIMIT: (True, True),
    dk.LEADER: (
        (
            'emboss_type_label', 'emboss_type',
            'emboss_mode_label', 'emboss_mode',
            'emboss_opacity_label', 'emboss_opacity',
            'azimuth_label', 'azimuth',
            'elevation_label', 'elevation',
            'depth_label', 'depth',
            'contrast_label', 'contrast',
            'blur_label', 'blur'
        ),
        (
            ('toggled', 'on_leader_toggle'),
            ('realize', 'on_leader_toggle')
        )
    ),
    TEXT: EMBOSS
}
OVERLAY_CHECK = {
    LIMIT: (True, True),
    dk.LEADER: (
        # Widget key; Has Gtk.Widget.
        (
            'overlay_gradient',
            'overlay_gradient_label',
            'gradient_mode_label',
            'gradient_mode',
            'overlay_opacity_label',
            'gradient_opacity',
            'is_reversed'
        ),

        # Gtk.Widget.connect arg
        (
            ('toggled', 'on_leader_toggle'),
            ('realize', 'on_leader_toggle')
        )
    ),
    TEXT: OVERLAY
}
REVERSED_CHECK = {
    IS_WIDGET: True,
    LIMIT: (True, False),
    TEXT: REVERSED,
    TOOLTIP: REVERSED_TIP,
    TYPE: CheckButton,
    VALUE: False
}
TRANSPARENT_EYE_CHECK = {
    IS_WIDGET: True,
    LIMIT: (True, False),
    TEXT: TRANSPARENT_EYE,
    TYPE: CheckButton,
    VALUE: False
}

for d in (ANIMATE_CHECK, EMBOSS_CHECK, OVERLAY_CHECK, REVERSED_CHECK):
    d.update({IS_WIDGET: True, TYPE: CheckButtonLeader, VALUE: False})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# ColorButton__________________________________________________________________
COLOR_BUTTON_1 = {
    PADDING: (0, 0, 0, 8),
    VALUE: Gdk.RGBA(red=.0, green=.0, blue=.0, alpha=1.),
}
COLOR_BUTTON_2 = {
    PADDING: (0, 0, 0, 8),
    VALUE: Gdk.RGBA(red=1., green=1., blue=1., alpha=1.)
}
COLOR_BUTTON_3 = {
    VALUE: Gdk.RGBA(red=.5, green=.5, blue=.5, alpha=1.)
}
for d in (COLOR_BUTTON_1, COLOR_BUTTON_2, COLOR_BUTTON_3):
    d.update({
        IS_WIDGET: True,
        LIMIT: True,
        TYPE: ColorButton
    })
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# ComboBoxText_________________________________________________________________
DIVISION_COMBO = {
    GET_LIST: get_division_list,
    LIMIT: (0, len(get_division_list())),
    TOOLTIP: DIVISION_TIP,
    VALUE: 0
}
MODE_COMBO = {
    GET_LIST: get_mode_list,
    LIMIT: (0, len(get_mode_list())),
    VALUE: LAYER_MODE_Q.index("Exclusion")
}
EMBOSS_MODE_COMBO = MODE_COMBO.copy()

EMBOSS_MODE_COMBO.update({VALUE: LAYER_MODE_Q.index("Overlay")})

for d in (DIVISION_COMBO, EMBOSS_MODE_COMBO, MODE_COMBO):
    d.update({IS_WIDGET: True, TYPE: ComboBoxText})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Label________________________________________________________________________
AZIMUTH_LABEL = {TEXT: AZIMUTH}
BLUR_LABEL = {TEXT: BLUR}
COLOR_LABEL = {TEXT: COLOR}
CONTRAST_LABEL = {TEXT: CONTRAST}
DEPTH_LABEL = {TEXT: DEPTH}
DIVISION_LABEL = {TEXT: DIVISION}
ELEVATION_LABEL = {TEXT: ELEVATION}
EYE_W_LABEL = {TEXT: EYE_WIDTH}
FLIP_LABEL = {TEXT: ROTATE}
FRAME_COUNT_LABEL = {TEXT: FRAME_COUNT}
GRADIENT_LABEL = {TEXT: GRADIENT}
MODE_LABEL = {TEXT: MODE}
OPACITY_LABEL = {TEXT: OPACITY}
PATTERN_LABEL = {TEXT: PATTERN}
RADIUS_LABEL = {TEXT: RADIUS}
RANDOM_LABEL = {TEXT: RANDOM}
RIM_LABEL = {PADDING: (8, 0, 0, 0), TEXT: RIM}
RIM_W_LABEL = {TEXT: RIM_WIDTH}
RING_W_LABEL = {TEXT: RING_WIDTH}
TIMER_LABEL = {TEXT: TIMER}
TYPE_LABEL = {TEXT: TYPE_}
YANG_LABEL = {PADDING: (8, 0, 0, 0), TEXT: "Yang", }
YIN_LABEL = {PADDING: (8, 0, 0, 0), TEXT: "Yin"}

for d in (
    AZIMUTH_LABEL, BLUR_LABEL, COLOR_LABEL,
    CONTRAST_LABEL, DEPTH_LABEL,
    ELEVATION_LABEL, DIVISION_LABEL,
    EYE_W_LABEL, FLIP_LABEL, FRAME_COUNT_LABEL,
    GRADIENT_LABEL, MODE_LABEL, OPACITY_LABEL,
    PATTERN_LABEL, RADIUS_LABEL,
    RANDOM_LABEL, RING_W_LABEL, RIM_W_LABEL,
    TIMER_LABEL, TYPE_LABEL
):
    d.update({IS_WIDGET: True, TYPE: Label, dk.HALIGN: Gtk.Align.START})

for d in (RIM_LABEL, YANG_LABEL, YIN_LABEL):
    d.update({IS_WIDGET: True, TYPE: Label})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# RadioGroup___________________________________________________________________
FLIP_RADIO = {TEXT: (CLOCKWISE, COUNTER_CLOCKWISE)}
EMBOSS_TYPE_RADIO = {TEXT: (ALL, RIM)}
TYPE_RADIO = {
    IS_WIDGET: True,
    dk.MEMBER: (
        # Widget key; Has Gtk.Widget.
        TYPE_FOLLOWING_D,

        # Gtk.Widget.connect arg
        (
            ('realize', 'on_type_change'),
            ('toggled', 'on_type_change')
        )
    ),
    LIMIT: True,
    TEXT: ("Color", "Pattern"),
    TYPE: RadioGroupType,
    VALUE: 0
}

for d in (FLIP_RADIO, EMBOSS_TYPE_RADIO):
    d.update({IS_WIDGET: True, LIMIT: True, TYPE: RadioGroup, VALUE: 0})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# SpinButton___________________________________________________________________
AZIMUTH_SPIN = {
    # (init value, lower limit, upper limit, step inc, page inc, page size)
    ADJUSTMENT: (.0, .0, 360., 1., 10., 0.),
    DIGITS: 2,
    LIMIT: (.0, 360.),
    VALUE: 45.
}
BLUR_SPIN = {
    ADJUSTMENT: (.0, .0, 1500., 1., 10., 0.),
    DIGITS: 2,
    LIMIT: (.0, 10.),
    TOOLTIP: BLUR_TIP,
    VALUE: .0
}
CONTRAST_SPIN = {
    ADJUSTMENT: (.0, -1., 1., .01, .1, 0.),
    DIGITS: 3,
    LIMIT: (-1., 1.),
    VALUE: .0
}
DEPTH_SPIN = {
    ADJUSTMENT: (1., 1., 99., 1., 10., 0.),
    LIMIT: (1., 10.),
    TOOLTIP: DEPTH_TIP,
    VALUE: 1.
}
ELEVATION_SPIN = {
    ADJUSTMENT: (.0, .0, 180., 1., 10., 0.),
    DIGITS: 2,
    LIMIT: (10.0, 60.),
    VALUE: 30.
}
EYE_SPIN = {
    ADJUSTMENT: (0., .0, 1., .01, .1, 0.),
    DIGITS: 2,
    LIMIT: (.0, 1.),
    TOOLTIP: EYE_WIDTH_TIP,
    VALUE: .33
}
FRAME_COUNT_SPIN = {
    ADJUSTMENT: (0., 1., 999., 1., 2., 0.),
    VALUE: 12.
}
OPACITY_SPIN_RIGHT = {
    ADJUSTMENT: (100., .0, 100., 1., 10., 0.),
    DIGITS: 1,
    LIMIT: (.0, 100.),
    VALUE: 100.
}
OPACITY_SPIN = OPACITY_SPIN_RIGHT.copy()

OPACITY_SPIN.update({PADDING: (0, 0, 0, 8)})

RADIUS_SPIN = {
    ADJUSTMENT: (0., 12., 9999., 1., 10., 0.),
    VALUE: 200.
}
RING_SPIN = {
    ADJUSTMENT: (0., .0, 1., .01, .1, 0.),
    DIGITS: 2,
    LIMIT: (.0, 1.),
    TOOLTIP: RING_SPIN_TIP,
    VALUE: 1.
}
TIMER_SPIN = {
    ADJUSTMENT: (1., 1., 9999., 1., 10., 0.),
    TOOLTIP: TIMER_TIP,
    VALUE: 100.
}
for d in (
    AZIMUTH_SPIN, BLUR_SPIN, CONTRAST_SPIN,
    DEPTH_SPIN, EYE_SPIN,
    ELEVATION_SPIN, FRAME_COUNT_SPIN,
    OPACITY_SPIN, OPACITY_SPIN_RIGHT, RADIUS_SPIN,
    RING_SPIN, TIMER_SPIN
):
    d.update({IS_WIDGET: True, TYPE: SpinButton})

RIM_SPIN = {
    ADJUSTMENT: (0., 0., 9999., 1., 10., 0.),
    IS_WIDGET: True,
    LIMIT: (0., 12.),
    dk.LEADER: (
        (
            'color_vbox_3', 'pattern_vbox_3',
            'gradient_vbox_3', 'opacity_vbox_3'
        ),
        (
            ('value-changed', 'on_rim_width_change'),
            ('realize', 'on_rim_width_change')
        )
    ),
    TYPE: SpinButtonRim,
    VALUE: .0
}
