#!/usr/bin/env python3


def convert_float_color_to_int(color):
    """
    Convert Gdk.Color into RGBA value.

    color: Gdk.Color
    Return: tuple
        RGBA
        (0 to 255, 0 to 255, 0 to 255, 0 to 255)
    """
    return [
        int(a * 255)
        for a in (color.red, color.green, color.blue, color.alpha)
    ]


def on_resource_realize(g):
    """
    Initialize a pattern button's tooltip after the button is initialized.

    g: Chooser type
    """
    on_resource_set(g, g.get_resource(), True)


def on_resource_set(g, resource, is_valid):
    """
    Respond to 'resource-set' events.

    g: GimpUi.PatternChooser
        Is responsible.

    resource: Gimp.Resource
        on display

    is_valid: bool
        Is True if the pattern was qualified by the user.
    """
    g.set_tooltip_text(resource.get_name())
