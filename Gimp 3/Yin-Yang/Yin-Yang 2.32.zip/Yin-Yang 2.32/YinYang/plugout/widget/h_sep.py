#!/usr/bin/env python3
from plugout.widget.emit import Widget
import gi                             # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk         # noqa

"""
Include 'Gtk.HSeparator' wrapper class.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/HSeparator.html'
"""


class HSeparator(Widget):
    """Customize 'Gtk.HSeparator' with a wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            HSeparator definition
        """
        g = Gtk.HSeparator.new()
        super().__init__(def_d, g)
