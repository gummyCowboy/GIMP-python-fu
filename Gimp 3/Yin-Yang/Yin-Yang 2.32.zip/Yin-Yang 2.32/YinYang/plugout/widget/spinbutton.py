#!/usr/bin/env python3
from plugout.constant import KEY_PRESS_EVENT
from plugout.define.key import ADJUSTMENT, DIGITS, VALUE
from plugout.widget.emit import WidgetValue
from random import randint, uniform
import gi                               # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk           # noqa

"""
Include 'Gtk.SpinButton' wrapper class.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/SpinButton.html'
"""


class SpinButton(WidgetValue):
    """Customize 'Gtk.SpinButton' with this wrapper."""
    change_signal = 'value-changed'

    def __init__(self, def_d):
        """
        def_d: dict
            SpinButton definition
                adjustment: tuple
                    (
                        value,
                        lower,
                        upper,
                        step increment,
                        page increment,
                        page size
                    )
                digits: int
                    Set the precision of the Gtk.SpinButton.

                value: float
                    init and default value
        """
        self._digits = def_d.get(DIGITS, 0)
        g = Gtk.SpinButton.new(
            Gtk.Adjustment.new(*def_d[ADJUSTMENT]),
            climb_rate=.02,
            digits=self._digits
        )

        # Is the maximum number of characters, 'max_a'.
        # one for a period, one for a minus, and one for an edit, '3'
        max_a = len(str(def_d[ADJUSTMENT][2])) + self._digits + 3

        g.set_numeric(True)
        g.set_snap_to_ticks(False)
        g.set_max_length(max_a)
        g.set_width_chars(max_a)
        g.connect(KEY_PRESS_EVENT, self.on_key_press)
        super().__init__(def_d, g)

        value = self.value_d[self.key] = def_d.get(VALUE, .0)
        g.set_value(value)

    def get_a(self):
        """
        Retrieve the value of the 'Gtk.SpinButton'.

        Return: float or int
        """
        f = self.widget.get_value()

        if not self._digits:
            return int(f)
        return round(f, self._digits)

    def randomize(self, *_):
        """
        Randomize the 'Gtk.SpinButton' value.
        Integer and float have different random function.
        """
        if self._digits:
            self.set_a(uniform(*self.limit))
        else:
            self.set_a(randint(*self.limit))

    def set_a(self, f):
        """
        Set the value of the 'Gtk.SpinButton'.

        f: float
            Receive value.
        """
        if not isinstance(f, float):
            if isinstance(f, int):
                f = float(f)
            else:
                # fail-safe
                f = .0
        self.widget.set_value(f)
