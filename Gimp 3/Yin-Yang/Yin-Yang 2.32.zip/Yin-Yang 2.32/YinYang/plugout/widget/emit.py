#!/usr/bin/env python3
from plugout.constant import ANY_CHANGE, OK_TYPE, RANDOMIZE
from plugout.define.key import (
    EMIT_SIGNAL, KEY, IS_ANY_CHANGE,
    LIMIT, RANDOMER, VALUE_D, WIDGET_D
)
from plugout.widget.widget import Widget
import gi                                  # type: ignore
gi.require_version('Gdk', '3.0')
from gi.repository import Gdk              # noqa

"""
Define a super class for Widget-leaf having a value.
Include function used by sub-class.
"""


def convert_float_color_to_int(color):
    """
    Convert Gdk.Color into RGBA value.

    color: Gdk.Color
    Return: tuple
        RGBA
        (0 to 255, 0 to 255, 0 to 255, 0 to 255)
    """
    return [
        int(a * 255)
        for a in (color.red, color.green, color.blue, color.alpha)
    ]


class WidgetEmit(Widget):
    change_signal = None

    """
    Connect the custom 'randomize' signal to a RANDOMER.
    When the Widget changes value:
        Update the 'AnyGroup.value_d'.
        Emit a custom signal.
        Emit an ANY_CHANGE signal.

    WidgetValue attribute:
        change_signal: string or tuple
            Is a static class attribute. Sub-WidgetValue
            override this class' None value in order
            to connect with 'WidgetValue.on_widget_change'.

        emit_signal: string; GObject signal
            Is an optional custom signal that the host can emit
            when its 'WidgetValue.widget' changes value.

        is_any_change: bool
            The Widget's host sends ANY_CHANGE signal when the
            Widget changes value.

        key: value
            Identify the Widget in its preset scope. Is inserted
            into 'def_d' by AnyGroup.

        limit: value
            Is an option flag or tuple that indicates and guides
            randomize ability.

        value: value
            Is optional. Is the default value of the Widget.
            Indicates that it is part of the preset contract with
            'Widget.get_a' and 'Widget.set_a' functions.

        value_d: dict
            Is inserted into WidgetValue definition dict by AnyGroup.
            Has preset scope items:
            {Widget key: Widget value}

        widget_d: dict
            Is inserted into the WidgetValue definition dict by AnyGroup.
            Has a preset's Container scope Widget items:
            {Widget key: Widget instance}
    """

    def __init__(self, def_d, g):
        """
        def_d: dict
            WidgetValue definition
                emit_signal: string
                    GObject signal
                    Emit when widget changes.

                key: string
                    Widget key found in 'AnyGroup.value_d'
                    and 'AnyGroup.widget_d'.

                limit: value
                    Specify randomization limit/range or trigger activation.

                value: value
                    Initialize the Widget. Indicate that
                    the Widget is part of a preset.

                value_d: dict
                    'AnyGroup.value_d' but limited to the Widget's preset.

        g: Gtk.Widget
            Is wrapped by this Widget class and is
            referenced by the 'widget' attribute.
        """
        self.is_any_change = def_d.get(IS_ANY_CHANGE)
        self.emit_signal = def_d.get(EMIT_SIGNAL)
        self.key = def_d.get(KEY)
        self.limit = def_d.get(LIMIT)
        self.value_d = def_d.get(VALUE_D, {})
        self.widget_d = def_d.get(WIDGET_D, {})

        super().__init__(def_d, g)

        # Check subordinate for function, 'randomize'.
        # Connect the option group's randomize signal to the
        # Widget if all the pieces are in place.
        if hasattr(self, 'randomize'):
            group = def_d.get(RANDOMER)
            if group and self.limit is not None:
                # When 'group' sends the 'randomize' signal,
                # this object will get the signal.
                group.connect(RANDOMIZE, self.randomize)

    def on_key_press(self, _, event_key):
        """
        _: Gtk.ListBox
            Sent the event.

        event_key: Gdk.EventKey
        """
        if Gdk.keyval_name(event_key.keyval) == 'Return':
            self.host.dialog.emit('response', OK_TYPE)
            return True
        return False

    def on_widget_change(self, *arg):
        """
        Respond to Widget change or action.
        Let the AnyGroup host know that there was 'any-change'.

        arg: tuple
            (sender, signal argument)
        """
        a = self.value_d.get(self.key)
        q = arg[-1], self, a

        if self.is_any_change and self.host:
            self.host.emit(ANY_CHANGE, q)
        if self.emit_signal:
            self.host.emit(self.emit_signal, q)

    def on_value_change(self, *arg):
        """
        Respond to Widget change. Store the latest Widget value in 'value_d'.

        arg: tuple
            (sender, signal argument)
        """
        self.value_d[self.key] = self.get_a()
        self.on_widget_change(*arg)


class WidgetValue(WidgetEmit):
    """Connect a Gtk.Widget's change signal."""

    def __init__(self, def_d, g):
        """
        def_d: dict
            WidgetValue definition

        g: Gtk.Widget
            Is wrapped by this Widget class and is
            referenced by the 'widget' attribute.
        """
        super().__init__(def_d, g)
        if self.change_signal:
            if isinstance(self.change_signal, tuple):
                for i in self.change_signal:
                    g.connect(i, self.on_value_change, i)
                    g.connect(i, self.on_value_change, i)

            else:
                g.connect(
                    self.change_signal,
                    self.on_value_change,
                    self.change_signal
                )
            g.connect('realize', self.on_value_change, 'realize')


class WidgetEmitter(WidgetEmit):
    """Connect a Gtk.Widget's change signal."""

    def __init__(self, def_d, g):
        """
        def_d: dict
            WidgetValue definition

        g: Gtk.Widget
            Is wrapped by this Widget class and is
            referenced by the 'widget' attribute.
        """
        super().__init__(def_d, g)
        if self.change_signal:
            if isinstance(self.change_signal, tuple):
                for i in self.change_signal:
                    g.connect(i, self.on_emitter_action, i)
                    g.connect(i, self.on_emitter_action, i)

            else:
                g.connect(
                    self.change_signal,
                    self.on_emitter_action,
                    self.change_signal
                )

    def on_emitter_action(self, _, signal):
        """
        Respond to Widget change. Store the latest Widget value in 'value_d'.
        Let the AnyGroup host know that there was 'any-change'.

        _: Gtk.Widget
        signal: string
            Identify the signal.
        """
        q = signal, self, self.emit_signal

        if self.is_any_change and self.host:
            self.host.emit(ANY_CHANGE, q)
        if self.emit_signal:
            self.host.emit(self.emit_signal, q)


class ContainerValue(WidgetEmit):
    """Connect a Container's custom change signal."""

    def __init__(self, def_d, g):
        """
        def_d: dict
            ContainerValue definition

        g: Gtk.Widget
            Is wrapped by this Widget class and is
            referenced by the 'widget' attribute.
        """
        super().__init__(def_d, g)
        if self.change_signal:
            # custom Container signal
            if isinstance(self.change_signal, tuple):
                for i in self.change_signal:
                    self.host.connect(i, self.on_value_change, i)
            else:
                self.host.connect(
                    self.change_signal,
                    self.on_value_change,
                    self.change_signal
                )
