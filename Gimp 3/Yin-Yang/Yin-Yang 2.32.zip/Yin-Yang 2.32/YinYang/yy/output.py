#!/usr/bin/env python3
from yy.constant import (
    ADD, BASE, FLOW, GRADIENT, GROUP,
    INTERSECT, LAYER_MODE_D,
    RADIAN_180, RADIAN_360,
    REPLACE, RIM, SUBTRACT
)
from yy.pdb import (
    BrightnessContrast, EllipseSelect, Emboss, GradientFill, ItemPosition
)
from dataclasses import dataclass
from math import cos, degrees, radians, sin
import gi                                            # type: ignore
gi.require_version('Gimp', '3.0')
gi.require_version('Gegl', '0.4')
from gi.repository import Gimp, Gegl   # noqa


# Each yin-yang division has two flow (positive/negative).
@dataclass
class Flow:
    angle: float = None
    cut_point: list = None
    seg: tuple = None
    motion_center: tuple = None
    motion_square: tuple = None


def add_layer(image, parent=None, position=0, layer_name=BASE):
    """
    Add a layer to an image.

    image: GIMP image
        Receive the layer.

    parent: group layer or None
        Put the layer in a group.

    position: int
        Is the offset from the top of the parent.

    layer_name: string
        Give the layer a name.

    Return: layer
        newly created
    """
    layer = Gimp.Layer.new(
        image,
        layer_name,
        image.get_width(),
        image.get_height(),
        Gimp.ImageType.RGBA_IMAGE,
        100,
        Gimp.LayerMode.NORMAL
    )

    image.insert_layer(layer, parent, position)
    return layer


def add_group_layer(image, parent=None, position=0, layer_name=GROUP):
    """
    Add a group layer to an image.

    image: GIMP image
        Receive the layer.

    parent: layer group or None
        Specify another layer group to nest this layer group.

    position: int
        Is the offset from the top of the parent.

    layer_name: string
        Give the layer group a name.

    Return: group layer
        newly created
    """
    layer = Gimp.GroupLayer.new(image, layer_name)

    image.insert_layer(layer, parent, position)
    return layer


def do_gegl_op(z, gegl_op, arg):
    """
    Do a Gegl operation.

    Thank you Ofnuts for this logic.

    z: Gimp.Drawable
        Receive Gegl process.

    buffer_in: Gegl.Buffer
    buffer_out: Gegl.Buffer
    gegl_op: string
        Gegl coded process instruction

    arg: tuple
        Give argument to the Gegl process.
        (('key-word', value), ...)
    """
    buffer_in = z.get_buffer()
    buffer_out = z.get_shadow_buffer()
    graph = Gegl.Node()
    source = graph.create_child('gegl:buffer-source')

    source.set_property('buffer', buffer_in)

    sink = graph.create_child('gegl:write-buffer')

    sink.set_property('buffer', buffer_out)

    operation = graph.create_child(gegl_op)

    for q in arg:
        operation.set_property(*q)

    source.link(operation)
    operation.link(sink)
    sink.process()
    buffer_out.flush()
    z.merge_shadow(True)

    # Pass x, y, w, h (a rectangle) to update the layer.
    z.update(*z.mask_intersect()[1:])


def clone_layer(j, layer):
    """
    Create a copy of a layer and insert it above the original.

    j: Gimp.Image
        Has layer.

    layer: Gimp.Layer
        Copy.

    Return: Gimp.Layer
        newly created
    """
    z = layer.copy()

    j.insert_layer(z, layer.get_parent(), get_layer_offset(j, layer))

    if z.get_mask():
        z.set_apply_mask(True)
        z.remove_mask(Gimp.MaskApplyMode.APPLY)

    # Make smoother mask.
    z.set_composite_space(Gimp.LayerColorSpace.RGB_PERCEPTUAL)
    return z


def fill_selection_with_color(layer, color, opacity):
    """
    Fills a selection with a color.

    layer : Gimp.Drawable
        layer with selection

    color : Gegl.Color
        color of the circle

    opacity: float
        .0 to 100.
        Set the opacity of the fill material.
    """
    if opacity:
        Gimp.context_set_foreground(color)
        Gimp.context_set_opacity(opacity)
        layer.edit_fill(Gimp.FillType.FOREGROUND)


def create_image(image_size):
    """
    Create a GIMP image.

    image_size: int
        Define the width and height of the image.

    Return: Gimp.Image, Gimp.Display
    """
    image = Gimp.Image.new(image_size, image_size, Gimp.ImageBaseType.RGB)
    return image, Gimp.Display.new(image)


def do_contrast(z, contrast):
    """
    Alter the contrast of a drawable.

    z: Gimp.Drawable
        Receive contrast process.

    contrast: float
        -1. to 1.
        Change the layer's contrast.

    Return: Gimp.PDBStatusType
        Result of the PDB processing. Hopefully, it's GIMP_PDB_SUCCESS.
    """
    # no change, '.0'
    BrightnessContrast.do((
        ('drawable', z), ('brightness', .0), ('contrast', contrast)
    ))


def do_emboss(j, z, azimuth, elevation, depth):
    """
    Emboss or bump-map the given drawable, specifying
    the angle and elevation for the light source.

    The bump-map has color, the emboss doesn't.

    j: Gimp.Image
        WIP

    z: Gimp.Drawable
        Receive effect.

    azimuth: float
        .0 to 360.

    elevation: float
        .0 to 180.

    depth: int
        1 to 99
    """
    Emboss.do((
        ('run-mode', Gimp.RunMode.NONINTERACTIVE),
        ('image', j),
        ('drawable', z),
        ('azimuth', azimuth),
        ('elevation', elevation),
        ('depth', depth),
        ('emboss', True)
    ))


def draw_gradient(layer, gradient, start_x, start_y, end_x, end_y):
    """
    Create a linear gradient to overlay the flower composite.

    layer: Gimp.Layer
        Receive Gimp.Gradient.

    gradient: Gimp.Gradient
        Draw this gradient.

    start_x, start_y, end_x, end_y: float
        Define the gradient's line.

    return: GimpValueArray
        The result is in index one (e.g array.index(1))
    """
    Gimp.context_set_gradient(gradient)
    GradientFill.do(
        (
            ('drawable', layer),
            ('gradient-type', Gimp.GradientType.LINEAR),
            ('offset', 0.),
            ('supersample', True),
            ('supersample-max-depth', 3),
            ('supersample-threshold', 0.),
            ('dither', True),
            ('x1', start_x),
            ('y1', start_y),
            ('x2', end_x),
            ('y2', end_y)
        )
    )


def fill_selection_with_pattern(layer, pattern, opacity):
    """
    Fill a selection with a pattern.

    layer: Gimp.Drawable
        Receive the pattern.

    pattern: Gimp.Pattern
        for the fill op
    """
    if opacity:
        Gimp.context_set_pattern(pattern)
        Gimp.context_set_opacity(opacity)
        Gimp.context_set_paint_mode(Gimp.LayerMode.NORMAL)
        layer.edit_fill(Gimp.FillType.PATTERN)


def get_layer_offset(image, layer):
    """
    Fetch the layer's offset from the top of it's parent layer.

    image: Gimp.Image
        Has layer.

    layer: Gimp.Layer
        Check its position.

    Return: int
        offset
    """
    return ItemPosition.do((('image', image), ('item', layer)))


def get_linear_gegl(color):
    """
    Create a Gegl.Color in linear color space.

    color: iterable
        RGBA
        [.0 to 1., ...]

    Return: Gegl.Color
        linear
    """
    return Gegl.Color.new("#{:02x}{:02x}{:02x}{:02x}".format(
        *map(int, [b * 255 for b in color])
    ))


def get_point_on_circle(x, y, angle, radius):
    """
    Return a point on the circle that corresponds to a rotation angle.

    x, y: int
        center of the circle

    angle : float
        the rotation angle

    radius : float
        the radius of the circle

    Returns:
        (x, y) of float
        the point on the circle
    """
    return (
        round((sin(angle) * radius) + x, 0),
        round((cos(angle) * -radius) + y, 0)
    )


def get_point_on_rect(angle, x, y, w, h):
    """
    Calculate an x, y coordinate for a point intersecting
    a ray, originating from the center of a rectangle,
    and ending at a rectangle boundary.

    angle: float
        radians
        angle from center of the rectangle

    x, y, w, h: numeric
        Define rectangle.

    Return: list
        [x, y] of float
        the point on the rectangle
    """
    sine = sin(angle)
    cosine = cos(angle)
    h1 = h / 2.
    w1 = w / 2.

    # distance to the top or the bottom edge (from the center), 'h2'
    h2 = h1 if sine > .0 else -h1

    # distance to the left or the right edge (from the center), 'w2'
    w2 = w1 if cosine > .0 else -w1

    # (distance to the vertical line) < (distance to the horizontal line)
    if abs(w2 * sine) < abs(h2 * cosine):
        # Calculate distance to the vertical line:
        h2 = (w2 * sine) / cosine

    # (distance to the top or the bottom edge)
    # < (distance to the left or the right edge)
    else:
        w2 = (h2 * cosine) / sine
    return [round(w2 + w1 + x, 0), round(h2 + h1 + y, 0)]


def select_ellipse(j, x, y, w, h, op=REPLACE):
    """
    Select an ellipse.

    j: GIMP image
        Receive selection.

    op: Gimp.ChannelOps
        ADD, REPLACE, SUBTRACT or INTERSECT

    x, y: float
        topleft point of the selection

    w, h: float
        size of the selection
    """
    EllipseSelect.do(
        (
            ('image', j),
            ('operation', op),
            ('x', x),
            ('y', y),
            ('width', w),
            ('height', h)
        )
    )


def select_polygon(image, seg, op=REPLACE):
    """
    Select a polygon.

    image: Gimp.Image
        Receive selection.

    seg: tuple
        (x, y, ...); a series of connected segment; float

    op: Gimp.ChannelOps
        ADD, REPLACE, SUBTRACT, INTERSECT
    """
    image.select_polygon(op, seg)


class Output:
    """Create Yin-Yang layer output."""

    def __init__(self):
        # dialog
        self._blur = \
            self._type = \
            self._depth = \
            self._timer = \
            self._radius = \
            self._azimuth = \
            self._color_1 = \
            self._color_2 = \
            self._color_3 = \
            self._contrast = \
            self._division = \
            self._direction = \
            self._elevation = \
            self._eye_width = \
            self._is_emboss = \
            self._is_rotate = \
            self._pattern_1 = \
            self._pattern_2 = \
            self._pattern_3 = \
            self._rim_width = \
            self._is_overlay = \
            self._is_reversed = \
            self._ring_width = \
            self._emboss_mode = \
            self._emboss_type = \
            self._frame_count = \
            self._rim_opacity = \
            self._yin_opacity = \
            self._yang_opacity = \
            self._gradient_mode = \
            self._emboss_opacity = \
            self._gradient_opacity = \
            self._overlay_gradient = \
            self._is_transparent_eye = None

        # output
        self._image = \
            self._center = \
            self._display = \
            self._core_radius = \
            self._group_layer = \
            self._symbol_rect = \
            self._motion_circle_radius = \
            self._motion_center_radius = None

        # dict; {Gimp.Channel id: Gimp.Channel}
        self._channel_d = None

        # dict; {flow index: flow dataclass}
        self._flow_d = None

    def _calc_motion_circle(self):
        """
        Motion is simulated by a flowing head and tail.
        Each flow has an angle that bisects its motion circle.
        """
        # angle offset, 'f'
        f = radians(90)

        a = self._motion_center_radius

        # motion circle width, 'w'
        w = a + a

        for flow in self._flow_d.values():
            # The angle is offset because the rectangle
            # calculation differs from this function.
            x, y = flow.motion_center = get_point_on_circle(
                self._center,
                self._center,
                flow.angle + f,
                a
            )
            flow.motion_square = x - a, y - a, w

    def _calc_polygon(self, w, angle_q):
        """
        Calculate the polygon needed by a Flow. The polygon is used
        to exclude material from a flow.

        Each polygon is made of a series of x, y coordinate pairs connected
        by clockwise-rotated segment. There is a minimum of three
        pairs and a maximum of five.

        w: int
            Image size

        angle_q: list
            [int, ...]
            Each value is a flow angle in degree.
        """
        w = float(w)

        # NE, SE, SW, NW
        degree_ab = 315, 45, 135, 225
        degree_ba = 315, 405, 135, 225

        # Start with NE corner and rotate clockwise.
        corner_q = [[w, 0.], [w, w], [0., w], [0., 0.]]

        # Each polygon starts from the center of the image.
        q = [self._center, self._center]

        for i in range(self._division):
            # The two angles determine corner points that are
            # added to the polygon.
            a = angle_q[i]
            b = angle_q[i + 1]

            # (x, y, ...), 'q1'
            q1 = q + self._flow_d[i].cut_point

            if a > b:
                # There's a rollover in the angles.
                degree_q = degree_ba
                b += 360

            else:
                degree_q = degree_ab

            for corner_i in range(4):
                if a < degree_q[corner_i] < b:
                    q1 += corner_q[corner_i]

            i1 = i + 1

            if i1 == self._division:
                i1 = 0

            q1 += self._flow_d[i + 1].cut_point
            self._flow_d[i1].seg = tuple(q1)

    def _create_channel(self):
        """
        Create selection. Save its channel and
        remember its id in a channel dict.
        """
        # Drop the extra Flow used by the polygon calculator.
        self._flow_d.pop(self._division)

        self._create_ring_channel()
        self._create_motion_channel()
        self._create_eye_channel()
        self._create_eye_patch_channel()
        self._create_flow_channel()

    def _create_eye_channel(self):
        """
        Create eye circle selection. Save it and remember its id.
        """
        if self._eye_width:
            radius = self._eye_width / 2.
            for k, flow in self._flow_d.items():
                x, y = flow.motion_center
                a = radius
                x -= a
                y -= a
                w = a + a

                Gimp.Selection.none(self._image)
                select_ellipse(self._image, x, y, w, w)
                self._save_selection(('eye', k))
        else:
            for k in self._flow_d.keys():
                self._channel_d[('eye', k)] = None

    def _create_eye_patch_channel(self):
        """Create eye patch channel with a series of channel operation."""
        if not self._is_transparent_eye:
            Gimp.Selection.none(self._image)

            for k in self._flow_d.keys():
                if k % 2:
                    continue
                self._make_selection(('eye', k), ADD)
            self._save_selection('even_patch')

            Gimp.Selection.none(self._image)

            for k in self._flow_d.keys():
                if not k % 2:
                    continue
                self._make_selection(('eye', k), ADD)
            self._save_selection('odd_patch')

    def _create_motion_channel(self):
        """Create motion circle. Save its selection and remember its id."""
        for k, flow in self._flow_d.items():
            x, y = flow.motion_center
            a = self._motion_circle_radius
            x -= a
            y -= a
            w = a + a

            Gimp.Selection.none(self._image)
            select_ellipse(self._image, x, y, w, w)
            self._save_selection(('motion', k))

    def _create_ring_channel(self):
        """Create a ring selection. Save the channel and remember its id."""
        symbol_offset, symbol_w = self._symbol_rect[0], self._symbol_rect[2]
        select_ellipse(self._image, *self._symbol_rect)

        if self._ring_width == self._radius:
            self._channel_d['ring'] = None

        else:
            # Has a core, so cut its area from the symbol area.
            w = symbol_offset + self._ring_width
            w1 = symbol_w - self._ring_width - self._ring_width
            select_ellipse(
                self._image, w, w, w1, w1, op=SUBTRACT
            )
        self._save_selection('ring')

    def _create_flow_channel(self):
        """Create flow channel with a series of channel operation."""
        for k, flow in self._flow_d.items():
            k1 = k - 1

            if k1 < 0:
                k1 = self._division - 1

            select_polygon(self._image, flow.seg)
            self._make_selection('ring', INTERSECT)
            self._make_selection(('motion', k), ADD)
            self._make_selection(('motion', k1), SUBTRACT)
            self._make_selection(('eye', k), SUBTRACT)
            self._save_selection(('flow', k))

    def _create_image(self, w):
        """
        Create an output image. If the image already exists,
        remove its layers as long it's the same size as the
        latest input requirement.

        w: float
            WIP image size

        return: Gimp.Image
            newly created
        """
        if self._image:
            # Delete old image.
            self._display.delete()
            self._image = self._display = None

        self._image, self._display = create_image(w)
        self._center = w / 2
        return self._image

    def _do_emboss(self):
        """
        Emboss a layer.

        z: Gimp.Layer
            Emboss.
        """
        q = self._group_layer.get_children()

        # rim only, '1'
        if self._emboss_type == 1:
            if self._rim_width:
                q = self._group_layer.get_children()[0],
            else:
                # no rim
                q = ()
        for z in q:
            j = self._image
            z = clone_layer(j, z)
            f = self._blur

            Gimp.Selection.none(j)

            if f:
                is_selected = j.select_item(REPLACE, z)

                if is_selected:
                    selection = j.get_selection()
                    channel = selection.save(j)

                    Gimp.Selection.none(j)
                    do_gegl_op(
                        z,
                        'gegl:gaussian-blur',
                        (('std-dev-x', f), ('std-dev-y', f))
                    )
                    is_selected = j.select_item(
                        REPLACE, channel
                    )
                if is_selected:
                    # Clip the blur material outside
                    # of the original layer's material.
                    selection = j.get_selection()

                    selection.invert(j)
                    z.edit_clear()
                    j.remove_channel(channel)
                    Gimp.Selection.none(j)

            do_emboss(j, z, self._azimuth, self._elevation, self._depth)

            if self._contrast:
                do_contrast(z, self._contrast)

            z.set_opacity(self._emboss_opacity)
            z.set_mode(LAYER_MODE_D[self._emboss_mode])
            j.merge_down(z, Gimp.MergeType.CLIP_TO_IMAGE)

    def _draw_overlay_gradient(self):
        """Draw an gradient overlay for each motion."""

        def _get_index(_f):
            """
            f: float
                angle in radians

            Return: int
                0 to 3
                index to quadrant
            """
            return int((degrees(_f) + .01) / 90 % 4)

        def _get_rect_point(_x, _y, _w):
            """
            _x, _y, _w: float
                Define a motion circle's bounding square.
            """
            return _x, _y, _x + _w, _y + _w

        for k, head in self._flow_d.items():
            k1 = k - 1

            if k1 < 0:
                k1 = self._division - 1

            # Compute gradient line that connects head to tail.
            tail = self._flow_d[k1]
            head_x, head_y, head_x1, head_y1 = _get_rect_point(
                *head.motion_square
            )
            tail_x, tail_y, tail_x1, tail_y1 = _get_rect_point(
                *tail.motion_square
            )
            x_i, y_i = ((1, 1), (0, 1), (0, 0), (1, 0))[
                _get_index(head.angle)
            ]
            start_x = (head_x, head_x1)[x_i]
            start_y = (head_y, head_y1)[y_i]

            # The gradient end point is on
            # the opposite corner of the head corner.
            end_x = (tail_x, tail_x1)[not x_i]
            end_y = (tail_y, tail_y1)[not y_i]

            z = add_layer(
                self._image, parent=self._group_layer, layer_name=GRADIENT
            )

            self._make_selection(('flow', k), REPLACE)

            if not self._is_transparent_eye:
                self._make_selection(('eye', k1), ADD)

            if self._is_reversed:
                Gimp.context_set_gradient_reverse(bool(k % 2))

            draw_gradient(
                z, self._overlay_gradient, start_x, start_y, end_x, end_y
            )
            z.set_mode(self._gradient_mode)
            z.set_opacity(self._gradient_opacity)

    def _draw_rim(self):
        """
        Draw a black rim if an option. Do this by expanding the ring selection.
        """
        if self._rim_width:
            j = self._image
            z = add_layer(j, parent=self._group_layer, layer_name=RIM)

            self._make_selection('ring', REPLACE)
            Gimp.Selection.grow(j, self._rim_width)
            self._make_selection('ring', SUBTRACT)

            # color type, '0'
            if self._type == 0:
                fill_selection_with_color(
                    z, get_linear_gegl(self._color_3), self._rim_opacity
                )

            # Pattern type, '1'
            elif self._type == 1:
                fill_selection_with_pattern(
                    z, self._pattern_3, self._rim_opacity
                )
            Gimp.Selection.none(j)

    def _expand(self, is_scale):
        """
        Calculate upscale and relative variable.

        is_scale: bool
            If True, the WIP image is scaled up by a factor of two.

        Return: float
            WIP image size
        """
        if is_scale:
            # upscale, '*= 2'
            self._radius *= 2
            self._rim_width *= 2
            padding = 4

        else:
            padding = 2

        # The symbol rectangle is offset from the topleft.
        # padding, '2'
        symbol_offset = self._rim_width + padding
        symbol_w = self._radius * 2

        # The rim is doubled again because its on both sides of the center.
        image_size = symbol_w + (symbol_offset * 2)

        # Define the symbol circle bounds.
        self._symbol_rect = symbol_offset, symbol_offset, symbol_w, symbol_w

        # Factor to get width.
        self._ring_width *= self._radius

        self._core_radius = self._radius - self._ring_width

        # Factor to get width.
        self._eye_width = self._eye_width * self._ring_width

        self._motion_circle_radius = self._ring_width / 2
        self._motion_center_radius = self._core_radius + self._ring_width / 2.
        return image_size

    def _fill_color(self):
        """Combine flow channel and fill them with color."""

        def _fill_p(_z, _i):
            """
            _z: Gimp.Layer
                Receive color.

            _index: int
                0 or 1
                yin or yang
            """
            fill_selection_with_color(
                _z,
                get_linear_gegl((self._color_2, self._color_1)[_i]),
                (self._yang_opacity, self._yin_opacity)[_i]
            )

        self._fill_symbol(_fill_p)

    def _fill_pattern(self):
        """Combine the flow channels and fill them with pattern."""

        def _fill_p(_z, _i):
            fill_selection_with_pattern(
                _z,
                (self._pattern_2, self._pattern_1)[_i],
                (self._yang_opacity, self._yin_opacity)[_i]
            )

        self._fill_symbol(_fill_p)

    def _fill_symbol(self, fill_p):
        """
        Fill the yin-yang symbol with a color or pattern.

        fill_p: function
            Perform fill.
        """
        Gimp.Selection.none(self._image)

        # two selections, yin and yang, '2', 'index_'.
        for index_ in range(2):
            layer = add_layer(
                self._image, parent=self._group_layer, layer_name=FLOW
            )

            for i in range(index_, self._division, 2):
                self._make_selection(('flow', i), op=ADD)

            if not self._is_transparent_eye:
                self._make_selection(
                    ('odd_patch', 'even_patch')[index_], ADD
                )

            fill_p(layer, index_)
            Gimp.Selection.none(self._image)

    def _get_channel(self, k):
        """
        Retrieve a saved selection's channel.

        k: string
            key to channel dict
        """
        # channel id, 'a'
        a = self._channel_d.get(k)
        if a is not None:
            return Gimp.Channel.get_by_id(a)

    def _init_flow(self, w):
        """
        Create and init Flow. A flow angle bisects the flow motion circle.
        A cut point is a connecting point for creating flow polygons that
        limit selection fill.

        w: int
            Is the size of the render.
        """
        # The first point is center-top at 270 degrees.
        flow = int(360 / self._division)

        angle_q = []
        rect = 0., 0., w, w

        for i in range(self._division + 1):
            self._flow_d[i] = Flow()
            a = int(flow * i + 270)

            while a >= 360:
                a -= 360
            angle_q += [a]

        for i in range(self._division + 1):
            flow = self._flow_d[i]
            f = flow.angle = radians(angle_q[i])
            flow.cut_point = get_point_on_rect(f, *rect)
        return angle_q

    def _load_value_attr(self, d):
        """
        Recursively set Output attribute given
        a value dict having nested preset.

        d: dict
            {Widget key: Widget value}
            Has nested preset dict.
        """
        for k, a in d.items():
            if isinstance(a, dict):
                # nested preset dict, 'a'
                self._load_value_attr(a)
            else:
                # Widget value, 'a'
                setattr(self, "_" + k, a)

    def _make_selection(self, k, op):
        """
        Perform a selection operation using a saved selection.

        k: string or tuple
            key to channel in the channel dict

        op: Gimp.ChannelOps
            ADD, SUBTRACT, INTERSECT, REMOVE
        """
        channel = self._get_channel(k)

        # A saved channel can be None, so check.
        if channel:
            self._image.select_item(op, channel)

    def _rotate(self, base_layer):
        """Create animation layer for GIF and WEBP."""
        j = self._image
        timer = f"{self._timer}ms"
        angle = progress = \
            RADIAN_360 / self._frame_count * (1, -1)[self._direction]

        base_layer.set_name(f"1 {timer}")

        for i in range(self._frame_count - 1):
            dupe = base_layer.copy()

            # Insert layer at top of the root stack.
            j.insert_layer(dupe, None, 0)

            # Keep angle in GIMP rotation bounds.
            if progress > RADIAN_180:
                progress = -RADIAN_360 + progress

            elif progress < -RADIAN_180:
                progress = RADIAN_360 + progress

            dupe.set_name(f"{i + 2} {timer}")
            dupe.transform_rotate(progress, True, 0, 0)

            progress += angle

            # The flush is critical because
            # the display can get over-extended
            # when a lot layers are created.
            Gimp.displays_flush()
        j.crop(j.get_width(), j.get_height(), 0., 0.)

    def _save_selection(self, k):
        """
        Save the current selection. Remember it with a channel dict.

        k: string
            Is the key for the channel dict.
            Identify a saved selection.
        """
        if Gimp.Selection.is_empty(self._image):
            self._channel_d[k] = None
        else:
            selection = self._image.get_selection()
            channel = selection.save(self._image)
            self._channel_d[k] = channel.get_id()

    def create(self, d, e):
        """
        Make Yin-Yang output layer.

        d: dict
            {widget key: widget value}
            Extract value from the plug-in dialog.
            Has nested preset.

        e: dict
            {Widget key: Gimp.Resource}
        """
        self._load_value_attr(d)

        for k, v in e.items():
            setattr(self, "_" + k, v)

        self._channel_d = {}
        self._flow_d = {}
        is_scale = self._type == 0

        # ComboBox translation
        self._division = int(self._division)
        self._gradient_mode = LAYER_MODE_D[self._gradient_mode]

        # WIP image size, 'image_w'
        image_w = self._expand(is_scale)

        j = self._create_image(image_w)

        j.undo_disable()

        self._group_layer = add_group_layer(j, layer_name="Yin-Yang")
        angle_q = self._init_flow(image_w)

        self._calc_polygon(image_w, angle_q)
        self._calc_motion_circle()
        self._create_channel()
        (self._fill_color, self._fill_pattern)[self._type]()
        self._draw_rim()

        if self._is_emboss:
            self._do_emboss()

        if self._is_overlay:
            self._draw_overlay_gradient()

        # Remove finished channel to clear memory and ease upkeep.
        for i in j.get_channels():
            j.remove_channel(i)

        layer = self._group_layer.merge()

        Gimp.Selection.none(j)

        if is_scale:
            # final image size, 'w1'
            w = image_w / 2
            j.scale(w, w)

        if self._direction:
            j.flip(Gimp.OrientationType.HORIZONTAL)

        if self._is_rotate:
            self._rotate(layer)

        j.undo_enable()
        Gimp.displays_flush()
