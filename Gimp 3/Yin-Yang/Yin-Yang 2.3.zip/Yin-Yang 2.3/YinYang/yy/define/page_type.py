#!/usr/bin/env python3
from plugout.define.key import (
    CHILD, COLUMN,
    COLUMNS, CUSTOM_SIGNAL,
    HALIGN, LIMIT, PADDING,
    PRESET, RANDOMER, TEXT,
    TYPE, VALUE, WIDTH
)
from plugout.container.box import HBox, VBox
from plugout.container.grid import Grid, GridCell, GridRow
from plugout.container.notebook import Page
from plugout.widget.checkbutton import CheckButton
from plugout.widget.colorbutton import ColorButton
from plugout.widget.label import Label
from plugout.widget.radio import RadioGroup
from plugout.widget.resource_button import PatternButton
from yy.constant import (
    get_pattern_list,
    CLOCKWISE, COLOR,
    COUNTER_CLOCKWISE,
    HUE, LIGHTNESS,
    OPACITY, PATTERN, LEATHER,
    RANDOM, RIM_VALUE_CHANGE, ROTATE,
    SATURATION, TRANSPARENT_EYE, TYPE_
)
from yy.define.shared import (
    GRID_ROW_RANDOM, GRID_ROW_SEPARATOR,
    GRID_ROW_PRESET, RIM_LABEL,
    SPIN_BUTTON_OPACITY, YANG_LABEL, YIN_LABEL
)
from yy.widget.custom import ButtonRandomColor, RadioGroupType
from yy.widget.lead_visual import VBoxFollow
from yy.widget.pattern_visual import (
    HBoxColor, HBoxPattern, LabelColor, LabelPattern
)
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa


# Color________________________________________________________________________
LABEL_COLOR = {HALIGN: Gtk.Align.START, TEXT: COLOR, TYPE: LabelColor}
COLOR_BUTTON_1 = {
    LIMIT: True,
    PADDING: (0, 0, 0, 8),
    TYPE: ColorButton,
    VALUE: (0, .0, .0, 1.),
}
COLOR_BUTTON_2 = {
    LIMIT: True,
    PADDING: (0, 0, 0, 8),
    TYPE: ColorButton,
    VALUE: (1., 1., 1., 1.)
}
COLOR_BUTTON_3 = {
    LIMIT: True,
    TYPE: ColorButton,
    VALUE: (.5, .5, .5, 1.)
}
VBOX_COLOR_1 = {
    CHILD: {
        'yin_label': YIN_LABEL,
        'color_1': COLOR_BUTTON_1
    },
    TYPE: VBox
}
VBOX_COLOR_2 = {
    CHILD: {
        'color_label_2': YANG_LABEL,
        'color_2': COLOR_BUTTON_2
    },
    TYPE: VBox
}
VBOX_COLOR_3 = {
    CHILD: {
        'color_label_3': RIM_LABEL,
        'color_3': COLOR_BUTTON_3
    },
    CUSTOM_SIGNAL: (RIM_VALUE_CHANGE,),
    TYPE: VBoxFollow
}
HBOX_COLOR = {
    CHILD: {1: VBOX_COLOR_1, 2: VBOX_COLOR_2, 3: VBOX_COLOR_3},
    TYPE: HBoxColor
}
GRID_CELL_COLOR_0 = {
    CHILD: {'color_label': LABEL_COLOR}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_COLOR_1 = {
    CHILD: {1: HBOX_COLOR},
    COLUMN: 1,
    WIDTH: 3,
    TYPE: GridCell
}

# Opacity______________________________________________________________________
OPACITY_LABEL = {HALIGN: Gtk.Align.START, TEXT: OPACITY, TYPE: Label}
SPIN_BUTTON_OPACITY_LEFT = SPIN_BUTTON_OPACITY.copy()
SPIN_BUTTON_OPACITY_RIGHT = SPIN_BUTTON_OPACITY.copy()
VBOX_OPACITY_1 = {
    CHILD: {
        'type_opacity_label_1': YIN_LABEL,
        'yin_opacity': SPIN_BUTTON_OPACITY_LEFT
    },
    TYPE: VBox
}
VBOX_OPACITY_2 = {
    CHILD: {
        'type_opacity_label_2': YANG_LABEL,
        'yang_opacity': SPIN_BUTTON_OPACITY_LEFT
    },
    TYPE: VBox
}
VBOX_OPACITY_3 = {
    CHILD: {
        'type_opacity_label_3': RIM_LABEL,
        'rim_opacity': SPIN_BUTTON_OPACITY_RIGHT
    },
    CUSTOM_SIGNAL: (RIM_VALUE_CHANGE,),
    TYPE: VBoxFollow
}
HBOX_OPACITY = {
    CHILD: {1: VBOX_OPACITY_1, 2: VBOX_OPACITY_2, 3: VBOX_OPACITY_3},
    TYPE: HBox
}
GRID_CELL_OPACITY_0 = {
    CHILD: {'opacity_label': OPACITY_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_OPACITY_1 = {
    CHILD: {1: HBOX_OPACITY},
    COLUMN: 1,
    WIDTH: 3,
    TYPE: GridCell
}

SPIN_BUTTON_OPACITY_LEFT.update({PADDING: (0, 0, 0, 8)})

# Pattern______________________________________________________________________
PATTERN_LABEL = {HALIGN: Gtk.Align.START, TEXT: PATTERN, TYPE: LabelPattern}
PATTERN_BUTTON_RIGHT = {
    LIMIT: get_pattern_list,
    TYPE: PatternButton,
    VALUE: LEATHER
}
PATTERN_BUTTON = {
    LIMIT: get_pattern_list,
    PADDING: (0, 0, 0, 10),
    TYPE: PatternButton,
    VALUE: LEATHER
}
VBOX_PATTERN_1 = {
    CHILD: {
        'pattern_label_1': YIN_LABEL,
        'pattern_1': PATTERN_BUTTON
    },
    TYPE: VBox
}
VBOX_PATTERN_2 = {
    CHILD: {
        'pattern_label_2': YANG_LABEL,
        'pattern_2': PATTERN_BUTTON
    },
    TYPE: VBox
}
VBOX_PATTERN_3 = {
    CHILD: {
        'pattern_label_3': RIM_LABEL,
        'pattern_3': PATTERN_BUTTON_RIGHT
    },
    CUSTOM_SIGNAL: (RIM_VALUE_CHANGE,),
    TYPE: VBoxFollow
}
HBOX_PATTERN = {
    CHILD: {1: VBOX_PATTERN_1, 2: VBOX_PATTERN_2, 3: VBOX_PATTERN_3},
    TYPE: HBoxPattern
}
GRID_CELL_PATTERN_0 = {
    CHILD: {'pattern_label': PATTERN_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_PATTERN_1 = {
    CHILD: {1: HBOX_PATTERN},
    COLUMN: 1,
    WIDTH: 3,
    TYPE: GridCell
}

# Random Color_________________________________________________________________
RANDOM_LABEL = {HALIGN: Gtk.Align.START, TEXT: RANDOM, TYPE: LabelColor}
RANDOM_COLOR_BUTTON = {
    PADDING: (0, 0, 0, 4), TEXT: COLOR, TYPE: ButtonRandomColor
}
RANDOM_HUE_BUTTON = {
    PADDING: (0, 0, 0, 4), TEXT: HUE, TYPE: ButtonRandomColor
}
RANDOM_LIGHTNESS_BUTTON = {TEXT: LIGHTNESS, TYPE: ButtonRandomColor}
RANDOM_SATURATION_BUTTON = {
    PADDING: (0, 0, 0, 4), TEXT: SATURATION, TYPE: ButtonRandomColor
}
HBOX_RANDOM_BUTTON = {
    CHILD: {
        'random_color_button': RANDOM_COLOR_BUTTON,
        'random_hue_button': RANDOM_HUE_BUTTON,
        'random_saturation_button': RANDOM_SATURATION_BUTTON,
        'random_lightness_button': RANDOM_LIGHTNESS_BUTTON
    },
    TYPE: HBoxColor
}

GRID_CELL_RANDOM_COLOR_0 = {
    CHILD: {'random_color_label': RANDOM_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_RANDOM_COLOR__1 = {
    CHILD: {1: HBOX_RANDOM_BUTTON},
    COLUMN: 1,
    WIDTH: 4,
    TYPE: GridCell
}

# Rotate_______________________________________________________________________
FLIP_LABEL = {HALIGN: Gtk.Align.START, TEXT: ROTATE, TYPE: Label}
RADIO_GROUP_FLIP = {
    LIMIT: True,
    TEXT: (CLOCKWISE, COUNTER_CLOCKWISE),
    TYPE: RadioGroup,
    VALUE: 0
}
GRID_CELL_FLIP_0 = {
    CHILD: {'flip_label': FLIP_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_FLIP_1 = {
    CHILD: {'flip': RADIO_GROUP_FLIP}, WIDTH: 2, COLUMN: 1, TYPE: GridCell
}

# Transparent Eye______________________________________________________________
CHECKBUTTON_TRANSPARENT_EYE = {
    LIMIT: (True, False),
    TEXT: TRANSPARENT_EYE,
    TYPE: CheckButton,
    VALUE: False
}
GRID_CELL_TRANSPARENT_EYE_1 = {
    CHILD: {'is_transparent_eye': CHECKBUTTON_TRANSPARENT_EYE},
    COLUMN: 1,
    TYPE: GridCell
}

# Type_________________________________________________________________________
LABEL_TYPE = {HALIGN: Gtk.Align.START, TEXT: TYPE_, TYPE: Label}
TYPE_RADIO = {
    LIMIT: True,
    TEXT: (COLOR, PATTERN),
    TYPE: RadioGroupType,
    VALUE: 0
}
GRID_CELL_TYPE_0 = {
    CHILD: {'type_label': LABEL_TYPE}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_TYPE_1 = {CHILD: {'type': TYPE_RADIO}, COLUMN: 1, TYPE: GridCell}

# Page/Type____________________________________________________________________
GRID_ROW_TYPE = {
    'type': {
        CHILD: {1: GRID_CELL_TYPE_0, 2: GRID_CELL_TYPE_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'color': {
        CHILD: {1: GRID_CELL_COLOR_0, 2: GRID_CELL_COLOR_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'coloring': {
        CHILD: {1: GRID_CELL_RANDOM_COLOR_0, 2: GRID_CELL_RANDOM_COLOR__1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'pattern': {
        CHILD: {1: GRID_CELL_PATTERN_0, 2: GRID_CELL_PATTERN_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'opacity': {
        CHILD: {1: GRID_CELL_OPACITY_0, 2: GRID_CELL_OPACITY_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'flip': {
        CHILD: {1: GRID_CELL_FLIP_0, 2: GRID_CELL_FLIP_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'eye': {
        CHILD: {1: GRID_CELL_TRANSPARENT_EYE_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'random': GRID_ROW_RANDOM,
    'sep': GRID_ROW_SEPARATOR,
    'preset': GRID_ROW_PRESET
}
GRID_TYPE = {
    CHILD: GRID_ROW_TYPE,
    RANDOMER: True,
    TYPE: Grid
}
PAGE_TYPE = {
    CHILD: {1: GRID_TYPE},
    PRESET: "Type",
    TEXT: "Type",
    TYPE: Page
}
