#!/usr/bin/env python3
from plugout.define.key import (
    CHILD, COLUMN,
    COLUMNS, CUSTOM_SIGNAL, EMIT_SIGNAL,
    HALIGN, LIMIT,
    PRESET, RANDOMER, TEXT,
    TOOLTIP, TYPE, VALUE
)
from plugout.constant import DEFAULT
from plugout.container.grid import Grid, GridCell, GridRow
from plugout.container.notebook import Page
from plugout.widget.checkbutton import CheckButton
from yy.constant import (
    get_gradient_list,
    GRADIENT, LAYER_MODES,
    MODE, OPACITY,
    OVERLAY, OVERLAY_CHANGE,
    REVERSED, REVERSED_TIP
)
from yy.define.shared import (
    COMBO_MODE, GRID_ROW_RANDOM,
    GRID_ROW_SEPARATOR, GRID_ROW_PRESET,
    SPIN_BUTTON_OPACITY
)
from yy.widget.lead_visual import (
    CheckButtonFollow, GradientButtonFollow, LabelFollow, SpinButtonFollow
)
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa

# Gradient_____________________________________________________________________
OVERLAY_GRADIENT_LABEL = {
    CUSTOM_SIGNAL: (OVERLAY_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: GRADIENT,
    TYPE: LabelFollow
}
OVERLAY_GRADIENT_BUTTON = {
    CUSTOM_SIGNAL: (OVERLAY_CHANGE,),
    LIMIT: get_gradient_list,
    TYPE: GradientButtonFollow,
    VALUE: DEFAULT
}
GRID_CELL_OVERLAY_GRADIENT_0 = {
    CHILD: {'overlay_gradient_label': OVERLAY_GRADIENT_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_OVERLAY_GRADIENT_1 = {
    CHILD: {'overlay_gradient': OVERLAY_GRADIENT_BUTTON},
    COLUMN: 1,
    TYPE: GridCell
}

# Mode_________________________________________________________________________
OVERLAY_MODE_LABEL = {
    CUSTOM_SIGNAL: (OVERLAY_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: MODE,
    TYPE: LabelFollow
}
OVERLAY_MODE_COMBO = COMBO_MODE.copy()
GRID_CELL_OVERLAY_MODE_0 = {
    CHILD: {'gradient_mode_label': OVERLAY_MODE_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_OVERLAY_MODE_1 = {
    CHILD: {'gradient_mode': OVERLAY_MODE_COMBO}, COLUMN: 1, TYPE: GridCell
}

OVERLAY_MODE_COMBO.update({
    CUSTOM_SIGNAL: (OVERLAY_CHANGE,),
    VALUE: LAYER_MODES.index("Exclusion")
})

# Opacity______________________________________________________________________
OVERLAY_OPACITY_LABEL = {
    CUSTOM_SIGNAL: (OVERLAY_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: OPACITY,
    TYPE: LabelFollow
}
OVERLAY_OPACITY_SPIN = SPIN_BUTTON_OPACITY.copy()
GRID_CELL_OVERLAY_OPACITY_0 = {
    CHILD: {'overlay_opacity_label': OVERLAY_OPACITY_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_OVERLAY_OPACITY_1 = {
    CHILD: {'gradient_opacity': OVERLAY_OPACITY_SPIN},
    COLUMN: 1,
    TYPE: GridCell
}

OVERLAY_OPACITY_SPIN.update({
    CUSTOM_SIGNAL: (OVERLAY_CHANGE,), TYPE: SpinButtonFollow,
})

# Overlay______________________________________________________________________
CHECK_BUTTON_OVERLAY = {
    EMIT_SIGNAL: OVERLAY_CHANGE,
    LIMIT: (True, True),
    TEXT: OVERLAY,
    TYPE: CheckButton,
    VALUE: False
}
GRID_CELL_OVERLAY_1 = {
    CHILD: {'is_overlay': CHECK_BUTTON_OVERLAY}, COLUMN: 1, TYPE: GridCell
}

# Reversed_____________________________________________________________________
CHECK_BUTTON_REVERSED = {
    CUSTOM_SIGNAL: (OVERLAY_CHANGE,),
    LIMIT: (True, False),
    TEXT: REVERSED,
    TOOLTIP: REVERSED_TIP,
    TYPE: CheckButtonFollow,
    VALUE: False
}
GRID_CELL_REVERSED_1 = {
    CHILD: {'is_reversed': CHECK_BUTTON_REVERSED}, COLUMN: 1, TYPE: GridCell
}

# Page Overlay_________________________________________________________________
GRID_ROW_OVERLAY = {
    'overlay': {
        CHILD: {1: GRID_CELL_OVERLAY_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'mode': {
        CHILD: {1: GRID_CELL_OVERLAY_MODE_0, 2: GRID_CELL_OVERLAY_MODE_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'opacity': {
        CHILD: {
            1: GRID_CELL_OVERLAY_OPACITY_0,
            2: GRID_CELL_OVERLAY_OPACITY_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'gradient': {
        CHILD: {
            1: GRID_CELL_OVERLAY_GRADIENT_0,
            2: GRID_CELL_OVERLAY_GRADIENT_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'reverse': {
        CHILD: {1: GRID_CELL_REVERSED_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'random': GRID_ROW_RANDOM,
    'sep': GRID_ROW_SEPARATOR,
    'preset': GRID_ROW_PRESET
}
GRID_OVERLAY = {
    CHILD: GRID_ROW_OVERLAY,
    RANDOMER: True,
    TYPE: Grid
}
PAGE_OVERLAY = {
    CHILD: {1: GRID_OVERLAY},
    PRESET: "Overlay",
    TEXT: "Overlay",
    TYPE: Page
}
