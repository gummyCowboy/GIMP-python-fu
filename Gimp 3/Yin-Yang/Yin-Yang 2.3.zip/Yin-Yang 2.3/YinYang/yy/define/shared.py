#!/usr/bin/env python3
from plugout.constant import MANAGE, SAVE_
from plugout.container.box import HBox
from plugout.container.grid import GridCell, GridRow
from plugout.define.key import (
    ADJUSTMENT, CHILD, COLUMN, COLUMNS,
    DIGITS, GET_LIST, HALIGN, LIMIT, PADDING,
    TEXT, TYPE, VALUE, WIDTH
)
from plugout.widget.button import ButtonRandom
from plugout.widget.h_sep import HSeparator
import gi                                      # type: ignore
from plugout.widget.label import Label, LabelPreset
from plugout.widget.button_preset import ButtonManage, ButtonSave
from plugout.widget.spinbutton import SpinButton
from yy.constant import get_mode_list, RANDOM, RIM
from yy.widget.lead_visual import ComboBoxTextFollow
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk                  # noqa

COMBO_MODE = {
    GET_LIST: get_mode_list,
    LIMIT: (0, len(get_mode_list())),
    TYPE: ComboBoxTextFollow
}
RIM_LABEL = {PADDING: (8, 0, 0, 0), TEXT: RIM, TYPE: Label}
SPIN_BUTTON_OPACITY = {
    ADJUSTMENT: (100., .0, 100., 1., 10., 0.),
    DIGITS: 1,
    LIMIT: (.0, 100.),
    TYPE: SpinButton,
    VALUE: 100.
}
YANG_LABEL = {PADDING: (8, 0, 0, 0), TEXT: "Yang", TYPE: Label}
YIN_LABEL = {PADDING: (8, 0, 0, 0), TEXT: "Yin", TYPE: Label}

# preset row___________________________________________________________________
LABEL_PRESET = {HALIGN: Gtk.Align.START, TYPE: LabelPreset}
MANAGE_BUTTON = {TEXT: MANAGE, TYPE: ButtonManage}
SAVE_BUTTON = {PADDING: (0, 0, 0, 4), TEXT: SAVE_, TYPE: ButtonSave}
HBOX_BUTTON_PRESET = {
    CHILD: {
        'save_button': SAVE_BUTTON,
        'manage_button': MANAGE_BUTTON
    },
    TYPE: HBox
}
GRID_CELL_PRESET_0 = {
    CHILD: {'preset_label': LABEL_PRESET}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_PRESET_1 = {
    CHILD: {1: HBOX_BUTTON_PRESET},
    COLUMN: 1,
    WIDTH: 2,
    TYPE: GridCell
}
GRID_ROW_PRESET = {
    CHILD: {1: GRID_CELL_PRESET_0, 2: GRID_CELL_PRESET_1},
    COLUMNS: 2,
    TYPE: GridRow
}

# Random Row___________________________________________________________________
BUTTON_RANDOM = {TEXT: RANDOM, TYPE: ButtonRandom}
GRID_CELL_RANDOM_1 = {
    CHILD: {'random': BUTTON_RANDOM}, COLUMN: 1, TYPE: GridCell
}
GRID_ROW_RANDOM = {
    CHILD: {1: GRID_CELL_RANDOM_1},
    COLUMNS: 2,
    TYPE: GridRow
}

# Separator Row________________________________________________________________
HSEPARATOR = {PADDING: (4, 4, 0, 0), TYPE: HSeparator}
GRID_CELL_HSEPARATOR_0 = {
    CHILD: {'separator': HSEPARATOR}, COLUMN: 0, TYPE: GridCell
}
GRID_ROW_SEPARATOR = {
    CHILD: {1: GRID_CELL_HSEPARATOR_0},
    COLUMNS: 2,
    TYPE: GridRow
}
