#!/usr/bin/env python3
from plugout.constant import PATH, PRESET_NAME
from plugout.container.grid import Grid, GridCell, GridRow
from plugout.define.key import (
    CHILD, COLUMN, COLUMNS, HALIGN, TEXT, TYPE, VALUE
)
from plugout.widget.label import Label, LabelPathReflect
from plugout.widget.entry import EntrySave
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa

"""Define an AnyGroup definition dict for DialogPresetSave."""

NAME_ENTRY = {TYPE: EntrySave, VALUE: ""}

# Label________________________________________________________________________
NAME_LABEL = {TEXT: PRESET_NAME}
PATH_LABEL = {TEXT: PATH}
PATH_REFLECT_LABEL = {
    HALIGN: Gtk.Align.START, TEXT: "", TYPE: LabelPathReflect
}
for d in (NAME_LABEL, PATH_LABEL):
    d.update({HALIGN: Gtk.Align.START, TYPE: Label})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

NAME_CELL_0 = {
    CHILD: {'name_label': NAME_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
NAME_CELL_1 = {
    CHILD: {'name_entry': NAME_ENTRY},
    COLUMN: 1,
    TYPE: GridCell
}
PATH_CELL_0 = {
    CHILD: {'path_label': PATH_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
PATH_CELL_1 = {
    CHILD: {'path_reflect_label': PATH_REFLECT_LABEL},
    COLUMN: 1,
    TYPE: GridCell
}
GRID_ROW = {
    'name': {
        CHILD: {
            '0': NAME_CELL_0,
            '1': NAME_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
    'path': {
        CHILD: {
            '0': PATH_CELL_0,
            '1': PATH_CELL_1
        },
        COLUMNS: 2,
        TYPE: GridRow
    },
}

# AnyGroup definition dict, 'DEF_SAVE'
DEF_SAVE = {
    'g': {
        TYPE: Grid,
        CHILD: GRID_ROW
    }
}
