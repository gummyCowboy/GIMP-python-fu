#!/usr/bin/env python3
from plugout.define.key import (
    CUSTOM_SIGNAL, HALIGN, HOST, PADDING, SCROLLED_WINDOW, TOOLTIP
)
import types
import gi                                 # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk             # noqa

"""
Define base Widget class for wrapping 'Gtk.Widget'.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/Widget.html'

Both Container and Widget-leaf are Widget sub-class.

For each wrapped 'Gtk.Widget', a Widget instance is created
using a Widget definition dict.

_________________
Widget Definition
¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
A Widget is either a Container-branch or a Widget-leaf in an AnyGroup
definition tree. All of its items are optional.

{
    # The definition key serves identity if the sub-class is a Widget-leaf.
    # AnyGroup stores Widget-leaf in its 'widget_d' and 'value_d' dict.
    definition_key: {
        # Connect the AnyGroup host to a custom signal.
        CUSTOM_SIGNAL: string; GObject Signal

        # Position the Widget horizontally in its Container.
        HALIGN: Gtk.Align,

        # Create a 'Gtk.Alignment' and pad the Widget with space.
        # of int
        PADDING: (top, bottom, left, right),

        # Create a 'Gtk.ScrolledWindow' and place the 'Gtk.Widget' inside.
        # of int
        SCROLLED_WINDOW: (minimum vertical space, maximum vertical space),

        # Create a tooltip pop-up when the mouse is over the 'Gtk.Widget'.
        TOOLTIP: string,
    }
}
"""


class Widget:
    """
    Is a base class for customizing 'Gtk.Widget'.
    Customize a 'Gtk.Widget' with an expanded scope.

    Widget attribute
        def_d: dict
            Is the Widget's definition.

        gtk_addable: Gtk.Widget
            This is the 'Gtk.Widget' that is added to a 'Gtk.Container'.

        host: GObject or None
            Send/receive custom signal.

        scrolled_window: Gtk.ScrolledWindow or None
            Contain the wrapped 'Gtk.Widget'.

        widget: Gtk.Widget
            The wrapper serves this object.
    """

    def __init__(self, def_d, g):
        """
        def_d: dict
            Widget definition
                custom_signal: (string, ...)
                    (GObject signal, ...)
                    Connect 'Widget.on_custom_signal' to the host signal
                     emitter. Sub-Widget needs to override
                    'Widget.on_custom_signal' in their class in order to
                    receive the custom signal.

                halign: Gtk.Align
                    Justify the Widget in its horizontal assigned space.

                host: GObject
                    If not None, the GObject sends and receives ANY_CHANGE
                    signal. AnyGroup's host also sends CUSTOM_SIGNAL
                    to subscribed Widget.

                padding: tuple
                    Create an alignment for the Widget.
                    (top, bottom, left, right) of int

                signal: tuple
                    ((signal type, function, optional arg), ...)
                    Has one or more signal connections.
                    Connect the 'Gtk.Widget' to a signal/function.

                tooltip: string
                    Give the Widget a tooltip.

                g: Gtk.Widget
                    Is wrapped by this Widget class and is
                    referenced by the 'widget' attribute.
        """
        self.scrolled_window = None

        # Reference the Gtk widget instance.
        self.widget = g

        # There are three possible 'gtk_addable' results.
        # Reference the addable 'Gtk.Widget' when adding to a Container.
        # the first addable result
        self.gtk_addable = g

        self.host = def_d.get(HOST)
        self.def_d = def_d

        # 'Gtk.Alignment'
        q = def_d.get(PADDING)
        q1 = def_d.get(SCROLLED_WINDOW)

        if q:
            # The 'Gtk.Alignment' is the new top-dog.
            # the second addable result
            self.gtk_addable = Gtk.Alignment()
            self.gtk_addable.set_padding(*q)
            if not q1:
                self.gtk_addable.add(g)

        # ScrolledWindow scale, 'q1'
        if q1:
            g1 = self.scrolled_window = Gtk.ScrolledWindow()
            g1.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            g1.set_min_content_height(q1[0])
            g1.set_max_content_height(q1[1])
            g1.add(self.widget)

            if q:
                self.gtk_addable.add(g1)
            else:
                # the third addable result
                self.gtk_addable = g1

        tooltip = def_d.get(TOOLTIP)

        if tooltip:
            g.set_tooltip_text(tooltip)

        if def_d.get(HALIGN):
            g.set_halign(def_d[HALIGN])

        # AnyGroup host, 'host'
        if self.host:
            q = def_d.get(CUSTOM_SIGNAL, ())
            if isinstance(q, (tuple, list, types.GeneratorType)):
                for i in q:
                    self.host.connect(i, self.on_custom_signal)
            else:
                raise AttributeError(
                    "During Widget init, {}, has tried to pass, {}, "
                    "as a 'custom_signal', but a 'custom_signal' "
                    "must be a type of tuple, list, or generator.".format(
                        self, q
                    )
                )

    def hide(self):
        """
        Hide the parent 'Gtk.Widget'.
        Can be a 'self.widget' or a 'Gtk.Alignment'.
        """
        self.gtk_addable.hide()

    def on_custom_signal(self, *_):
        """Override this CUSTOM_SIGNAL handler in the sub-class."""
        return

    def show(self):
        """Show the parent 'Gtk.Widget'."""
        self.gtk_addable.show()
