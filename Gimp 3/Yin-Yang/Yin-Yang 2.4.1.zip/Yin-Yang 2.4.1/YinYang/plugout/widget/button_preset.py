#!/usr/bin/env python3
from plugout.define.key import KEY_PATH, VALUE, WIDGET_D
from plugout.dialog.preset_manage import DialogPresetManage
from plugout.dialog.preset_save import DialogPresetSave
from plugout.widget.button import Button

"""Include class and function for preset life-cycle management."""


def get_default(default_d, widget_d):
    """
    Get the default value dict for a preset recursively.

    default_d: dict
        Gather default item.
        {Widget key: Widget value}

    widget_d: dict
        Has default item.
        {Widget key: Widget instance}
    """
    for k, a in widget_d.items():
        if isinstance(a, dict):
            # Is a nested preset, 'a'.
            default_d[k] = {}
            get_default(default_d[k], a)
        else:
            # Is a Widget instance, 'a'.
            if VALUE in a.def_d:
                default_d[k] = a.def_d[VALUE]


class ButtonPreset(Button):
    """
    Factor ButtonSave and ButtonManage.

    ButtonPreset attribute
        key_path: list
            [preset key, ...]
            The last preset key is this preset's type.

            The list represents nested preset. Each preset
            has a dict value inside:
            'AnyGroup.value_d' and 'AnyGroup.widget_d'

            A particular preset value dict is found by:

            # When there is one preset key.
            AnyGroup.value_d[preset_key]

            # When there is more than one preset key.
            AnyGroup.value_d[preset_key][...]

            # When there is no preset key.
            AnyGroup.value_d

            A preset dict structure is both
            relational and hierarchical. The structure is
            the same in both AnyGroup dict.

            # relational
            {Widget key: Widget value, ...}

            # hierarchical
            {preset key: {Widget key: Widget value, ...}}

    """
    io_name = "New Preset"

    def __init__(self, def_d):
        super().__init__(def_d)
        self.key_path = def_d.get(KEY_PATH, [])

    def get_io_name(self):
        """
        Fetch the IO preset name from workflow memory.

        Return: string
            Is the name of last preset.
        """
        return ButtonPreset.io_name

    def set_io_name(self, s):
        """
        Update the IO preset name for workflow memory.

        s: string
            Is the name of latest preset.
        """
        ButtonPreset.io_name = s


class ButtonManage(ButtonPreset):
    """
    Is a custom 'Gtk.Button' for loading and deleting preset. The Widget's
    'value_d' receives input-value when loading a preset. Also, the 'widget_d'
    is used to create a default value dict for the preset which is made
    available to DialogPresetManage.
    """

    def __init__(self, def_d):
        """
        arg: tuple
            def_d: dict
                ButtonManage definition
                    widget_d: dict
                        {Widget key: Widget instance}
        """
        super().__init__(def_d)

        self._default_d = None
        self.widget_d = def_d.get(WIDGET_D)
        self.widget.connect('clicked', self.on_button_manage_click)

    def get_default(self):
        """
        Create a default dict for its preset.

        Return: dict
            default
            {Widget key: Widget init value}
        """
        if self._default_d is None:
            self._default_d = {}
            get_default(self._default_d, self.widget_d)
        return self._default_d

    def on_button_manage_click(self, _):
        """
        _: Gtk.Button
            Is responsible.
        """
        DialogPresetManage(self, self.key_path, self.widget_d)


class ButtonSave(ButtonPreset):
    """Is a custom 'Gtk.Button' for saving its preset."""

    def __init__(self, *arg):
        """
        arg: tuple
            def_d: dict
                ButtonSave definition
        """
        super().__init__(*arg)
        self.widget.connect('clicked', self.on_button_save_click)

    def on_button_save_click(self, _):
        """
        Respond to Save button action.

        _: Gtk.Button
            Is responsible.
        """
        DialogPresetSave(self, self.key_path, self.value_d)
