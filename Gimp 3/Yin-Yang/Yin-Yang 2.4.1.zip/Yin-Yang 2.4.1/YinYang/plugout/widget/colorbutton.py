#!/usr/bin/env python3
from plugout.constant import COLOR_TIP
from plugout.define.key import TEXT, VALUE
from plugout.gegl_color import (
    convert_float_to_gegl_color,
    convert_gegl_color_to_float,
    convert_gegl_color_to_int
)
from plugout.widget.emit import WidgetValue
from random import uniform
import gi                                 # type: ignore
gi.require_version('Gdk', '3.0')
gi.require_version('GimpUi', '3.0')
gi.require_version('Gtk', '3.0')
from gi.repository import GimpUi          # noqa

"""
Include 'Gtk.Colorbutton wrapper class.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/ColorButton.html'
"""


class ColorButton(WidgetValue):
    """
    Customize a 'Gtk ColorButton' with a wrapper.
    Require COLOR_TIP constant which can be empty.

    When activated the button opens a dialog which
    returns a RGB linear color-space value.
    """
    change_signal = 'color-changed'

    def __init__(self, def_d):
        """
        def_d: dict
            ColorButton definition
                value: Gdk.RGBA
                Initialize the button.
                Is the default value for a preset.
        """
        value = def_d.get(VALUE, (1., 1., 1., 1.))
        color = convert_float_to_gegl_color(value)

        # button size, '1'; Size is set automatically.
        # transparency VALUE type, '2'
        g = GimpUi.ColorButton.new(def_d.get(TEXT, ""), 1, 1, color, 2)

        super().__init__(def_d, g)
        g.connect('color-changed', self.on_color_changed)
        g.connect('realize', self.on_color_changed)

        q = self.value_d[self.key] = value
        self.set_a(q)

    def get_a(self):
        """
        Retrieve the value of the 'Gtk.ColorButton'.

        Return: tuple
            high precision float
            (.0 to 1.)
        """
        return convert_gegl_color_to_float(self.widget.get_color())

    @staticmethod
    def on_color_changed(color_button):
        """
        A 'Gtk.ColorButton' changed value, so its tooltip needs updating.

        color_button: GimpUi.ColorButton
            Has a new value.
        """
        color = color_button.get_color()
        rgba = convert_gegl_color_to_int(color)
        color_button.set_tooltip_text(COLOR_TIP.format(*rgba))

    def randomize(self, *_):
        """
        Respond to a randomize signal. Randomize
        the value of the 'Gtk.ColorButton'.
        """
        q = [round(uniform(.0, 1.), 4) for _ in range(3)]

        # alpha, '1.'
        q.append(1.)

        self.set_a(q)

    def set_a(self, q):
        """
        q: tuple or list
            RGBA sequenced float values;
            (.0 to 1., .0 to 1., .0 to 1., .0 to 1.)
        """
        self.widget.set_color(convert_float_to_gegl_color(q))

        # Gtk only sends this signal when its ColorChooser dialog is accepted.
        self.widget.emit('color-changed')
