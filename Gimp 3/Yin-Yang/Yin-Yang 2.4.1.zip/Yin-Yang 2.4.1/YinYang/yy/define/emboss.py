#!/usr/bin/env python3
from plugout.define.key import (
    ADJUSTMENT, CHILD, COLUMN,
    COLUMNS, CUSTOM_SIGNAL, DIGITS,
    EMIT_SIGNAL, HALIGN, LIMIT,
    PRESET, RANDOMER, TEXT,
    TOOLTIP, TYPE, VALUE, WIDTH
)
from plugout.container.grid import Grid, GridCell, GridRow
from plugout.container.notebook import Page
from plugout.widget.checkbutton import CheckButton
from yy.constant import (
    ALL, AZIMUTH, POST_BLUR, POST_BLUR_TIP,
    PRE_BLUR, PRE_BLUR_TIP,
    CONTRAST, DEPTH, DEPTH_TIP,
    ELEVATION, EMBOSS, EMBOSS_CHANGE,
    LAYER_MODES, MODE, OPACITY, RIM, TYPE_
)
from yy.define.shared import (
    COMBO_MODE, GRID_ROW_PRESET, GRID_ROW_RANDOM,
    GRID_ROW_SEPARATOR, SPIN_BUTTON_OPACITY
)
from yy.widget.lead_visual import (
    LabelFollow, RadioGroupFollow, SpinButtonFollow
)
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa

# Azimuth______________________________________________________________________
AZIMUTH_LABEL = {
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: AZIMUTH,
    TYPE: LabelFollow
}
AZIMUTH_SPIN_BUTTON = {
    # (init value, lower limit, upper limit, step inc, page inc, page size)
    ADJUSTMENT: (.0, .0, 360., 1., 10., 0.),
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    DIGITS: 2,
    LIMIT: (.0, 360.),
    TYPE: SpinButtonFollow,
    VALUE: 45.
}
GRID_CELL_AZIMUTH_0 = {
    CHILD: {'azimuth_label': AZIMUTH_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_AZIMUTH_1 = {
    CHILD: {'azimuth': AZIMUTH_SPIN_BUTTON}, COLUMN: 1, TYPE: GridCell
}

# Post-Blur_____________________________________________________________________
POST_BLUR_LABEL = {
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: POST_BLUR,
    TYPE: LabelFollow
}
POST_BLUR_SPIN = {
    ADJUSTMENT: (.0, .0, 1500., 1., 10., 0.),
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    DIGITS: 2,
    LIMIT: (.0, 4.),
    TOOLTIP: POST_BLUR_TIP,
    TYPE: SpinButtonFollow,
    VALUE: .0
}
GRID_CELL_POST_BLUR_0 = {
    CHILD: {'post_blur_label': POST_BLUR_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_POST_BLUR_1 = {
    CHILD: {'post_blur': POST_BLUR_SPIN}, COLUMN: 1, TYPE: GridCell
}

# Pre-Blur_____________________________________________________________________
PRE_BLUR_LABEL = {
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: PRE_BLUR,
    TYPE: LabelFollow
}
PRE_BLUR_SPIN = {
    ADJUSTMENT: (.0, .0, 1500., 1., 10., 0.),
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    DIGITS: 2,
    LIMIT: (.0, 10.),
    TOOLTIP: PRE_BLUR_TIP,
    TYPE: SpinButtonFollow,
    VALUE: .0
}
GRID_CELL_PRE_BLUR_0 = {
    CHILD: {'pre_blur_label': PRE_BLUR_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_PRE_BLUR_1 = {
    CHILD: {'pre_blur': PRE_BLUR_SPIN}, COLUMN: 1, TYPE: GridCell
}

# Contrast_____________________________________________________________________
CONTRAST_LABEL = {
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: CONTRAST,
    TYPE: LabelFollow
}
CONTRAST_SPIN = {
    ADJUSTMENT: (.0, -1., 1., .01, .1, 0.),
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    DIGITS: 3,
    LIMIT: (-1., 1.),
    TYPE: SpinButtonFollow,
    VALUE: .0
}
GRID_CELL_CONTRAST_0 = {
    CHILD: {'contrast_label': CONTRAST_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_CONTRAST_1 = {
    CHILD: {'contrast': CONTRAST_SPIN}, COLUMN: 1, TYPE: GridCell
}

# Elevation____________________________________________________________________
ELEVATION_LABEL = {
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: ELEVATION,
    TYPE: LabelFollow
}
ELEVATION_SPIN_BUTTON = {
    ADJUSTMENT: (.0, .0, 180., 1., 10., 0.),
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    DIGITS: 2,
    LIMIT: (10.0, 60.),
    TYPE: SpinButtonFollow,
    VALUE: 30.
}
GRID_CELL_ELEVATION_0 = {
    CHILD: {'elevation_label': ELEVATION_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_ELEVATION_1 = {
    CHILD: {'elevation': ELEVATION_SPIN_BUTTON}, COLUMN: 1, TYPE: GridCell
}

# Depth________________________________________________________________________
DEPTH_LABEL = {
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    TEXT: DEPTH,
    HALIGN: Gtk.Align.START,
    TYPE: LabelFollow
}
DEPTH_SPIN_BUTTON = {
    ADJUSTMENT: (1., 1., 99., 1., 10., 0.),
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    LIMIT: (1., 10.),
    TOOLTIP: DEPTH_TIP,
    TYPE: SpinButtonFollow,
    VALUE: 1.
}
GRID_CELL_DEPTH_0 = {
    CHILD: {'depth_label': DEPTH_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_DEPTH_1 = {
    CHILD: {'depth': DEPTH_SPIN_BUTTON}, COLUMN: 1, TYPE: GridCell
}

# Emboss_______________________________________________________________________
CHECK_BUTTON_EMBOSS = {
    EMIT_SIGNAL: EMBOSS_CHANGE,
    LIMIT: (True, True),
    TEXT: EMBOSS,
    TYPE: CheckButton,
    VALUE: False
}
GRID_CELL_EMBOSS_1 = {
    CHILD: {'is_emboss': CHECK_BUTTON_EMBOSS}, COLUMN: 1, TYPE: GridCell
}

# Mode_________________________________________________________________________
EMBOSS_MODE_LABEL = {
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: MODE,
    TYPE: LabelFollow
}
EMBOSS_MODE_COMBO = COMBO_MODE.copy()
GRID_CELL_EMBOSS_MODE_0 = {
    CHILD: {'emboss_mode_label': EMBOSS_MODE_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_EMBOSS_MODE_1 = {
    CHILD: {'emboss_mode': EMBOSS_MODE_COMBO},
    COLUMN: 1,
    TYPE: GridCell
}

EMBOSS_MODE_COMBO.update({
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    VALUE: LAYER_MODES.index("Overlay")
})

# Opacity______________________________________________________________________
EMBOSS_OPACITY_LABEL = {
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    TEXT: OPACITY,
    HALIGN: Gtk.Align.START,
    TYPE: LabelFollow
}
EMBOSS_OPACITY_SPIN = SPIN_BUTTON_OPACITY.copy()
GRID_CELL_EMBOSS_OPACITY_0 = {
    CHILD: {'emboss_opacity_label': EMBOSS_OPACITY_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_EMBOSS_OPACITY_1 = {
    CHILD: {'emboss_opacity': EMBOSS_OPACITY_SPIN},
    COLUMN: 1,
    TYPE: GridCell
}

EMBOSS_OPACITY_SPIN.update({
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,), TYPE: SpinButtonFollow
})

# Type_________________________________________________________________________
EMBOSS_TYPE_LABEL = {
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: TYPE_,
    TYPE: LabelFollow
}
EMBOSS_TYPE_RADIO = {
    CUSTOM_SIGNAL: (EMBOSS_CHANGE,),
    LIMIT: True,
    TEXT: (ALL, RIM),
    TYPE: RadioGroupFollow,
    VALUE: 0
}
GRID_CELL_EMBOSS_TYPE_0 = {
    CHILD: {'emboss_type_label': EMBOSS_TYPE_LABEL},
    COLUMN: 0,
    TYPE: GridCell
}
GRID_CELL_EMBOSS_TYPE_1 = {
    CHILD: {'emboss_type': EMBOSS_TYPE_RADIO},
    WIDTH: 2,
    COLUMN: 1,
    TYPE: GridCell
}

# Page Emboss__________________________________________________________________
GRID_ROW_EMBOSS = {
    'emboss': {
        CHILD: {1: GRID_CELL_EMBOSS_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'type': {
        CHILD: {1: GRID_CELL_EMBOSS_TYPE_0, 2: GRID_CELL_EMBOSS_TYPE_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'mode': {
        CHILD: {1: GRID_CELL_EMBOSS_MODE_0, 2: GRID_CELL_EMBOSS_MODE_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'opacity': {
        CHILD: {1: GRID_CELL_EMBOSS_OPACITY_0, 2: GRID_CELL_EMBOSS_OPACITY_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'azimuth': {
        CHILD: {1: GRID_CELL_AZIMUTH_0, 2: GRID_CELL_AZIMUTH_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'elevation': {
        CHILD: {1: GRID_CELL_ELEVATION_0, 2: GRID_CELL_ELEVATION_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'depth': {
        CHILD: {1: GRID_CELL_DEPTH_0, 2: GRID_CELL_DEPTH_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'pre_blur': {
        CHILD: {1: GRID_CELL_PRE_BLUR_0, 2: GRID_CELL_PRE_BLUR_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'post_blur': {
        CHILD: {1: GRID_CELL_POST_BLUR_0, 2: GRID_CELL_POST_BLUR_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'contrast': {
        CHILD: {
            1: GRID_CELL_CONTRAST_0, 2: GRID_CELL_CONTRAST_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'random': GRID_ROW_RANDOM,
    'sep': GRID_ROW_SEPARATOR,
    'preset': GRID_ROW_PRESET
}
GRID_EMBOSS = {
    CHILD: GRID_ROW_EMBOSS,
    RANDOMER: True,
    TYPE: Grid
}
PAGE_EMBOSS = {
    CHILD: {1: GRID_EMBOSS},
    PRESET: "Emboss",
    TEXT: "Emboss",
    TYPE: Page
}
