#!/usr/bin/env python3
from plugout.define.key import (
    ADJUSTMENT, CHILD, COLUMN,
    COLUMNS, CUSTOM_SIGNAL, EMIT_SIGNAL,
    HALIGN, LIMIT,
    PRESET, TEXT, TOOLTIP,
    TYPE, VALUE
)
from plugout.container.grid import Grid, GridCell, GridRow
from plugout.container.notebook import Page
from plugout.widget.checkbutton import CheckButton
from yy.constant import (
    ROTATE, ROTATE_CHANGE, FRAME_COUNT, TIMER, TIMER_TIP
)
from yy.define.shared import GRID_ROW_PRESET, GRID_ROW_SEPARATOR
from yy.widget.lead_visual import LabelFollow, SpinButtonFollow
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa

# Rotate_______________________________________________________________________
CHECK_BUTTON_ROTATE = {
    EMIT_SIGNAL: ROTATE_CHANGE,
    LIMIT: (True, True),
    TEXT: ROTATE,
    TYPE: CheckButton,
    VALUE: False
}
GRID_CELL_ROTATE_1 = {
    CHILD: {'is_rotate': CHECK_BUTTON_ROTATE}, COLUMN: 1, TYPE: GridCell
}

# Frame Count__________________________________________________________________
FRAME_COUNT_LABEL = {
    CUSTOM_SIGNAL: (ROTATE_CHANGE,),
    HALIGN: Gtk.Align.START,
    TEXT: FRAME_COUNT,
    TYPE: LabelFollow
}
FRAME_COUNT_SPIN = {
    ADJUSTMENT: (0., 1., 999., 1., 2., 0.),
    CUSTOM_SIGNAL: (ROTATE_CHANGE,),
    TYPE: SpinButtonFollow,
    VALUE: 12.
}
GRID_CELL_FRAME_COUNT_0 = {
    CHILD: {'frame_label': FRAME_COUNT_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_FRAME_COUNT_1 = {
    CHILD: {'frame_count': FRAME_COUNT_SPIN}, COLUMN: 1, TYPE: GridCell
}

# Timer________________________________________________________________________
TIMER_LABEL = {
    CUSTOM_SIGNAL: (ROTATE_CHANGE,),
    TEXT: TIMER,
    HALIGN: Gtk.Align.START,
    TYPE: LabelFollow
}
TIMER_SPIN = {
    ADJUSTMENT: (1., 1., 9999., 1., 10., 0.),
    CUSTOM_SIGNAL: (ROTATE_CHANGE,),
    TOOLTIP: TIMER_TIP,
    TYPE: SpinButtonFollow,
    VALUE: 100.
}
GRID_CELL_TIMER_0 = {
    CHILD: {'timer_label': TIMER_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_TIMER_1 = {CHILD: {'timer': TIMER_SPIN}, COLUMN: 1, TYPE: GridCell}

# Page Rotate__________________________________________________________________
GRID_ROW_ROTATE = {
    'rotate': {
        CHILD: {1: GRID_CELL_ROTATE_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'frame': {
        CHILD: {1: GRID_CELL_FRAME_COUNT_0, 2: GRID_CELL_FRAME_COUNT_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'timer': {
        CHILD: {1: GRID_CELL_TIMER_0, 2: GRID_CELL_TIMER_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'sep': GRID_ROW_SEPARATOR,
    'preset': GRID_ROW_PRESET
}
GRID_ROTATE = {
    CHILD: GRID_ROW_ROTATE,
    TYPE: Grid
}
PAGE_ROTATE = {
    CHILD: {1: GRID_ROTATE},
    PRESET: "Rotate",
    TEXT: "Rotate",
    TYPE: Page
}
