#!/usr/bin/env python3
from plugout.any_group import AnyGroup
from plugout.constant import (
    DELETE, DELETE_CONFIRM,
    DELETE_FAIL, DELETE_FILE,
    DELETE_BUTTON_RESPONSE_TYPE, EMPTY_PRESET,
    DELETE_PRESET, DIALOG_MANAGE_SIGNAL,
    LOAD, LOAD_FAIL, MISSING_PRESET,
    PRESET_LOADED, REMOVED_FILE
)
from plugout.container.content_area import ContentArea
from plugout.define.preset_manage import DEF_MANAGE
from plugout.dialog.dialog import Dialog
from plugout.constant import (
    ACCEPT, CANCEL, CANCEL_TYPE,
    DELETE_TYPE, MANAGE_PRESET, OK_TYPE
)
from plugout.preset import Preset
import json
import os
import gi                                       # type: ignore
gi.require_version('Gimp', '3.0')
gi.require_version('Gtk', '3.0')
from gi.repository import Gimp, GObject, Gtk    # noqa

"""Include class and function used when saving a preset."""


def load_preset(input_d, widget_d):
    """
    Load a preset dict into interface Widget recursively.

    input_d: dict
        preset
        {Widget key: Widget value}

    widget_d: dict
        {Widget key: Widget instance}
    """
    for k, a in input_d.items():
        # Check for missing key, 'k'.
        if k in widget_d:
            if isinstance(a, dict):
                # nested preset, 'a'
                load_preset(a, widget_d[k])
            else:
                # Widget value, 'a'
                widget_d[k].set_a(a)


def verify_delete(path):
    """
    Make sure the user wants to delete a file.

    path: string
        file path

    Return: bool
        Is True if the user is okay with deleting the file.
    """
    is_success = False

    if os.path.isfile(path):
        dialog = Gtk.MessageDialog(
            type=Gtk.MessageType.QUESTION,
            text=DELETE_FILE,
            secondary_text=(DELETE_CONFIRM.format(path))
        )

        dialog.add_button(CANCEL, Gtk.ResponseType.CANCEL)
        dialog.add_button(ACCEPT, Gtk.ResponseType.OK)

        response = dialog.run()
        is_success = True if response == Gtk.ResponseType.OK else False
        dialog.destroy()

    else:
        Gimp.message(MISSING_PRESET)
    return is_success


class DialogPresetManage(GObject.GObject, Dialog):
    """Create a Dialog for managing preset."""
    __gsignals__ = DIALOG_MANAGE_SIGNAL

    def __init__(self, manage_button, key_path, widget_d):
        """
        Open a dialog. Respond to user interaction.

        manage_button: ButtonManage
            Set IO name.

        key_path: list
            [preset key, ...]
            Find nested preset.
            Identify this preset.

        widget_d: dict
            {Widget key: Widget}
            preset
        """
        def _on_accept():
            if self._load_preset():
                self.dialog.destroy()
                self.dialog = None

        def _on_cancel():
            self.dialog.destroy()
            self.dialog = None

        def _on_delete_button():
            self.on_delete_preset_action()

        GObject.GObject.__init__(self)

        self._list_box = self._preset_name = None
        self.key_path = key_path
        self.widget_d = widget_d
        title = MANAGE_PRESET
        Preset.active_path = Preset.path
        self._manage_button = manage_button

        # {dialog button response type: response type handler}
        response_d = {
            CANCEL_TYPE: _on_cancel,
            DELETE_BUTTON_RESPONSE_TYPE: _on_delete_button,
            DELETE_TYPE: _on_cancel,
            OK_TYPE: _on_accept
        }

        if key_path:
            self._preset_name = key_path[-1]
            title = f"{title}: {self._preset_name}"
            Preset.active_path = '{}{}{}'.format(
                Preset.path, self._preset_name, os.path.sep
            )

        self.connect(DELETE_PRESET, self.on_delete_preset_action)
        Dialog.__init__(
            self,
            title,
            (
                (CANCEL, CANCEL_TYPE),
                (DELETE, DELETE_BUTTON_RESPONSE_TYPE),
                (LOAD, OK_TYPE)
            ),
            self.add_widget,
            response_d
        )

    def _load_preset(self):
        """
        Try to load a preset from file.

        Return: bool
            Is True if the preset is loaded.
        """
        d = None
        is_success = False
        row = self._list_box.get_selected_row()

        if row:
            row_i = row.get_index()

            if row_i:
                n = self._list_box.get_selected_name()
                path = f'{Preset.active_path}{n}.json'

                if os.path.isfile(path):
                    try:
                        with open(path, 'r', encoding='utf-8') as a_file:
                            d = json.load(a_file)
                        is_success = True
                    except Exception:
                        is_success = False
                        Gimp.message(LOAD_FAIL)
                else:
                    Gimp.message(MISSING_PRESET)

            else:
                is_success = True
                d = self._manage_button.get_default()
            if is_success:
                if d:
                    load_preset(d, self.widget_d)
                    Gimp.message(PRESET_LOADED)
                else:
                    is_success = False
                    Gimp.message(EMPTY_PRESET)
        return is_success

    def add_widget(self, content_area):
        """
        Add Widget to the Dialog's content area.

        content_area: Gtk.Box
            There's room to grow.
        """
        container = ContentArea(content_area)
        self._any_group = AnyGroup(
            DEF_MANAGE,
            container,
            preset_key=self._preset_name,
            host=self
        )
        self._list_box = self._any_group.widget_d['preset list']
        content_area.show_all()

    def delete_preset(self, preset_name):
        """
        Delete a preset file given its index in the preset list.

        _: Gtk.ListBox
            Has a list of preset.

        preset_name: string
            Is the name of the preset to delete.
        """
        path = f'{Preset.active_path}{preset_name}.json'
        is_delete = False

        if verify_delete(path):
            try:
                os.remove(path)
                Gimp.message(REMOVED_FILE.format(path))
                is_delete = True
            except Exception:
                Gimp.message(DELETE_FAIL)
        if is_delete:
            self._list_box.remove_name(preset_name)

    def on_delete_preset_action(self, *_):
        """
        Delete a preset.

        button: Gtk.Button
            Is the Delete button.
        """
        row = self._list_box.get_selected_row()
        if row:
            self.delete_preset(self._list_box.get_selected_name())
