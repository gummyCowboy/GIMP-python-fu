#!/usr/bin/env python3
from plugout.container.box import VBox
from plugout.widget.checkbutton import CheckButton
from plugout.widget.combo import ComboBoxText
from plugout.widget.label import Label
from plugout.widget.radio import RadioGroup
from plugout.widget.resource_button import GradientButton
from plugout.widget.spinbutton import SpinButton


class Follow:
    """
    Initialize after Widget. Change visibility
    depending on the value of a lead Widget.
    """

    def __init__(self, def_d):
        return

    def on_custom_signal(self, _, arg):
        """
        Show or hide itself depending on the leader value.

        _: object
            Sent the signal.

        arg: tuple
            (follower, symbol-type-value)
        """
        if arg[-1]:
            self.widget.show()
        else:
            self.widget.hide()


class CheckButtonFollow(Follow, CheckButton):
    """Is a customized CheckButton."""

    def __init__(self, def_d):
        """
        def_d: dict
            CheckButtonFollow definition
        """
        Follow.__init__(self, def_d)
        CheckButton.__init__(self, def_d)


class ComboBoxTextFollow(Follow, ComboBoxText):
    """Customize a ComboBoxText with this wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            ComboBoxTextFollow definition
        """
        Follow.__init__(self, def_d)
        ComboBoxText.__init__(self, def_d)


class GradientButtonFollow(Follow, GradientButton):
    """Customize GradientButton with a wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            GradientButtonFollow definition
        """
        Follow.__init__(self, def_d)
        GradientButton.__init__(self, def_d)


class LabelFollow(Follow, Label):
    """Customize Label with a wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            LabelFollow definition
        """
        Follow.__init__(self, def_d)
        Label.__init__(self, def_d)


class RadioGroupFollow(Follow, RadioGroup):
    """Customize RadioGroup with a wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            RadioGroupFollow definition
        """
        Follow.__init__(self, def_d)
        RadioGroup.__init__(self, def_d)


class SpinButtonFollow(Follow, SpinButton):
    """Customize SpinButton with a wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            SpinButtonFollow definition
        """
        Follow.__init__(self, def_d)
        SpinButton.__init__(self, def_d)


class VBoxFollow(Follow, VBox):
    """Customize a VBox with this wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            VBoxFollow definition
        """
        Follow.__init__(self, def_d)
        VBox.__init__(self, def_d)
