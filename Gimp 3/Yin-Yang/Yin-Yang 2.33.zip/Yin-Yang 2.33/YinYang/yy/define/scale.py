#!/usr/bin/env python3
from plugout.define.key import (
    ADJUSTMENT, CHILD, COLUMN,
    COLUMNS, CUSTOM_SIGNAL, DIGITS, EMIT_SIGNAL,
    GET_LIST, HALIGN, LIMIT,
    PRESET, RANDOMER, TEXT, TOOLTIP, TYPE, VALUE
)
from plugout.container.grid import Grid, GridCell, GridRow
from plugout.container.notebook import Page
from plugout.widget.combo import ComboBoxText
from plugout.widget.label import Label
from plugout.widget.spinbutton import SpinButton
from yy.constant import (
    DIVISION, DIVISION_TIP, EYE_VALUE_CHANGE,
    EYE_WIDTH, EYE_WIDTH_TIP, IMAGE_SIZE,
    RADIUS, RADIUS_VALUE_CHANGE,
    RIM_VALUE_CHANGE, RIM_WIDTH,
    RING_SPIN_TIP, RING_VALUE_CHANGE, RING_WIDTH,
    get_division_list
)
from yy.widget.custom import (
    LabelEyeFactor,
    LabelRingFactor,
    LabelImageSize
)
from yy.define.shared import (
    GRID_ROW_RANDOM, GRID_ROW_SEPARATOR, GRID_ROW_PRESET
)
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa

# Division_____________________________________________________________________
LABEL_DIVISION = {HALIGN: Gtk.Align.START, TEXT: DIVISION, TYPE: Label}
COMBO_DIVISION = {
    GET_LIST: get_division_list,
    LIMIT: (0, len(get_division_list())),
    TOOLTIP: DIVISION_TIP,
    TYPE: ComboBoxText,
    VALUE: 0
}
GRID_CELL_DIVISION_0 = {
    CHILD: {'division_label': LABEL_DIVISION}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_DIVISION_1 = {
    CHILD: {'division': COMBO_DIVISION}, COLUMN: 1, TYPE: GridCell
}

# Eye Width____________________________________________________________________
LABEL_EYE_WIDTH = {HALIGN: Gtk.Align.START, TEXT: EYE_WIDTH, TYPE: Label}
LABEL_EYE_WIDTH_FACTOR = {
    CUSTOM_SIGNAL: (EYE_VALUE_CHANGE, RADIUS_VALUE_CHANGE, RING_VALUE_CHANGE),
    HALIGN: Gtk.Align.START,
    TEXT: "0",
    TYPE: LabelEyeFactor
}
SPIN_BUTTON_EYE_WIDTH = {
    ADJUSTMENT: (0., .0, 1., .01, .1, 0.),
    DIGITS: 4,
    EMIT_SIGNAL: EYE_VALUE_CHANGE,
    LIMIT: (.0, 1.),
    TOOLTIP: EYE_WIDTH_TIP,
    TYPE: SpinButton,
    VALUE: .33
}
GRID_CELL_EYE_WIDTH_0 = {
    CHILD: {'eye_width_label': LABEL_EYE_WIDTH}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_EYE_WIDTH_1 = {
    CHILD: {'eye_width': SPIN_BUTTON_EYE_WIDTH}, COLUMN: 1, TYPE: GridCell
}
GRID_CELL_EYE_WIDTH_2 = {
    CHILD: {'eye_factor_label': LABEL_EYE_WIDTH_FACTOR},
    COLUMN: 2,
    TYPE: GridCell
}

# Radius_______________________________________________________________________
LABEL_RADIUS = {HALIGN: Gtk.Align.START, TEXT: RADIUS, TYPE: Label}
SPIN_BUTTON_RADIUS = {
    ADJUSTMENT: (0., 12., 9999., 1., 10., 0.),
    EMIT_SIGNAL: RADIUS_VALUE_CHANGE,
    TYPE: SpinButton,
    VALUE: 200.
}
LABEL_IMAGE_SIZE_REFLECT = {
    HALIGN: Gtk.Align.START, TEXT: IMAGE_SIZE, TYPE: LabelImageSize
}

GRID_CELL_RADIUS_0 = {
    CHILD: {'radius_label': LABEL_RADIUS}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_RADIUS_1 = {
    CHILD: {'radius': SPIN_BUTTON_RADIUS}, COLUMN: 1, TYPE: GridCell
}
GRID_CELL_RADIUS_2 = {
    CHILD: {'image_size_label': LABEL_IMAGE_SIZE_REFLECT},
    COLUMN: 2,
    TYPE: GridCell
}

# Rim Width____________________________________________________________________
LABEL_RIM_WIDTH = {HALIGN: Gtk.Align.START, TEXT: RIM_WIDTH, TYPE: Label}
SPIN_BUTTON_RIM_WIDTH = {
    ADJUSTMENT: (0., 0., 9999., 1., 10., 0.),
    EMIT_SIGNAL: RIM_VALUE_CHANGE,
    LIMIT: (0., 12.),
    TYPE: SpinButton,
    VALUE: .0
}
GRID_CELL_RIM_WIDTH_0 = {
    CHILD: {'rim_width_label': LABEL_RIM_WIDTH}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_RIM_WIDTH_1 = {
    CHILD: {'rim_width': SPIN_BUTTON_RIM_WIDTH}, COLUMN: 1, TYPE: GridCell
}

# Ring Width___________________________________________________________________
LABEL_RING_WIDTH = {HALIGN: Gtk.Align.START, TEXT: RING_WIDTH, TYPE: Label}
RING_SPIN = {
    ADJUSTMENT: (0., .0, 1., .01, .1, 0.),
    DIGITS: 4,
    EMIT_SIGNAL: RING_VALUE_CHANGE,
    LIMIT: (.0, 1.),
    TOOLTIP: RING_SPIN_TIP,
    TYPE: SpinButton,
    VALUE: 1.
}
LABEL_RING_FACTOR = {
    CUSTOM_SIGNAL: (RADIUS_VALUE_CHANGE, RING_VALUE_CHANGE),
    HALIGN: Gtk.Align.START,
    TEXT: "0",
    TYPE: LabelRingFactor
}
GRID_CELL_RING_WIDTH_0 = {
    CHILD: {'ring_width_label': LABEL_RING_WIDTH}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_RING_WIDTH_1 = {
    CHILD: {'ring_width': RING_SPIN}, COLUMN: 1, TYPE: GridCell
}
GRID_CELL_RING_WIDTH_2 = {
    CHILD: {'ring_factor_label': LABEL_RING_FACTOR}, COLUMN: 2, TYPE: GridCell
}

# Scale________________________________________________________________________
GRID_ROW_SCALE = {
    'division': {
        CHILD: {1: GRID_CELL_DIVISION_0, 2: GRID_CELL_DIVISION_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'radius': {
        CHILD: {
            1: GRID_CELL_RADIUS_0, 2: GRID_CELL_RADIUS_1, 3: GRID_CELL_RADIUS_2
        },
        COLUMNS: 3,
        TYPE: GridRow
    },
    'ring': {
        CHILD: {
            1: GRID_CELL_RING_WIDTH_0,
            2: GRID_CELL_RING_WIDTH_1,
            3: GRID_CELL_RING_WIDTH_2
        },
        COLUMNS: 3,
        TYPE: GridRow
    },
    'eye': {
        CHILD: {
            1: GRID_CELL_EYE_WIDTH_0,
            2: GRID_CELL_EYE_WIDTH_1,
            3: GRID_CELL_EYE_WIDTH_2
        },
        COLUMNS: 3,
        TYPE: GridRow
    },
    'rim': {
        CHILD: {1: GRID_CELL_RIM_WIDTH_0, 2: GRID_CELL_RIM_WIDTH_1},
        COLUMNS: 2,
        TYPE: GridRow
    },
    'random': GRID_ROW_RANDOM,
    'sep': GRID_ROW_SEPARATOR,
    'preset': GRID_ROW_PRESET
}
GRID_SCALE = {
    CHILD: GRID_ROW_SCALE,
    RANDOMER: True,
    TYPE: Grid
}
PAGE_SCALE = {
    CHILD: {1: GRID_SCALE},
    PRESET: "Scale",
    TEXT: "Scale",
    TYPE: Page
}
