#!/usr/bin/env python3
from yy.constant import PLUGIN_BLURB, PLUGIN_TOOLTIP, PROCEDURE_NAME, YEAR
from yy.dialog_main import DialogMain
from yy.pdb import init_pdb
from plugout.constant import GIMP_PYTHON
import gi                                          # type: ignore
import os
import sys
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GimpUi, GLib       # noqa

IS_DEV_PC = os.environ.get('gummy_cowboy', True)


class YinYang(Gimp.PlugIn):
    """Initialize the plug-in with GIMP 3."""

    def do_query_procedures(self):
        return [PROCEDURE_NAME]

    def do_set_i18n(self, name):
        # Support language translation.
        return True, GIMP_PYTHON, None

    def do_create_procedure(self, name):
        """
        Define plug-in so that it can be run.

        name: string
            Is the name of the plug-in and is sourced from PROC_NAME.
        """
        procedure = Gimp.ImageProcedure.new(
            self,
            name,
            Gimp.PDBProcType.PLUGIN,
            self.run,
            None               # run data
        )
        # no image required
        procedure.set_sensitivity_mask(Gimp.ProcedureSensitivityMask.ALWAYS)

        procedure.set_menu_label("_Yin Yang…")
        procedure.add_menu_path('<Image>/Filters/Render/')
        procedure.set_documentation(PLUGIN_TOOLTIP, PLUGIN_BLURB, name)
        procedure.set_attribution("Charles Bartley", "Charles Bartley", YEAR)
        return procedure

    def run(self, procedure, run_mode, *_):
        """
        Produce layer output.

        procedure: Gimp.ImageProcedure
            Manage plug-in.

        run_mode: enum
            Gimp.RunMode

        _: tuple
            image: Gimp.Image
                the active image

            drawables: list
                active drawable
                [drawable, ...]

            args: Gimp.ValueArray
                How is this used?
                Has a length() function that could be useful.

            run_data: value
                Relayed from the 'do_create_procedure'.
        """
        # Check run mode. If interactive create
        # dialog, otherwise use previous settings.
        if run_mode == Gimp.RunMode.INTERACTIVE:
            file = None

            GimpUi.init(PROCEDURE_NAME)
            Gimp.context_push()

            if IS_DEV_PC:
                # Trace errors by recording them to a file. If
                # the file doesn't exist, create it. Append
                # error messages and piped (">>") print statements.
                file = sys.stderr = sys.stdout = open("D:\\error.txt", 'a')
                print("Yin-Yang started.")

            # Improve output detail.
            Gimp.context_set_antialias(True)

            # The image is up-scaled instead.
            Gimp.context_set_feather(False)

            Gimp.context_set_interpolation(Gimp.InterpolationType.NOHALO)
            Gimp.context_set_gradient_blend_color_space(
                Gimp.GradientBlendColorSpace.RGB_PERCEPTUAL
            )
            init_pdb()

            try:
                DialogMain()

            except Exception:
                Gimp.context_pop()
                Gimp.displays_flush()
            finally:
                if IS_DEV_PC:
                    file.close()

        else:
            # Use previous settings.
            # This is dependent on the shelf which is a GIMP WIP.
            pass

        return procedure.new_return_values(
            Gimp.PDBStatusType.SUCCESS, GLib.Error()
        )


Gimp.main(YinYang.__gtype__, sys.argv)
