#!/usr/bin/env python3
from plugout.container.box import HBox
from plugout.widget.label import Label
from yy.constant import SYMBOL_TYPE_CHANGE


class SymbolVisual:
    """Initialize after Widget."""

    def __init__(self, show_value):
        self.show_value = show_value
        self.host.connect(SYMBOL_TYPE_CHANGE, self.on_symbol_type_change)

    def on_symbol_type_change(self, _, *arg):
        """
        Show or hide itself depending on the 'show_value'.

        _: object
            Sent the signal.

        arg: tuple
            (host, symbol-type-value)
        """
        if arg[-1] == self.show_value:
            self.widget.show()
        else:
            self.widget.hide()


class HBoxColor(HBox, SymbolVisual):
    """Customize a Gtk.HBox with this wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            HBoxColor definition
        """
        HBox.__init__(self, def_d)

        # Pattern is at index zero in the symbol-type RadioGroup.
        SymbolVisual.__init__(self, 0)


class HBoxPattern(HBox, SymbolVisual):
    """Customize a Gtk.HBox with this wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            HBoxPattern definition
        """
        HBox.__init__(self, def_d)

        # Pattern is at index one in the symbol-type RadioGroup.
        SymbolVisual.__init__(self, 1)


class LabelColor(Label, SymbolVisual):
    """Customize a Gtk.HBox with this wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            LabelColor definition
        """
        Label.__init__(self, def_d)

        # Color is at index zero in the symbol-type RadioGroup.
        SymbolVisual.__init__(self, 0)


class LabelPattern(Label, SymbolVisual):
    """Customize a Gtk.HBox with this wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            LabelPattern definition
        """
        Label.__init__(self, def_d)

        # Pattern is at index one in the symbol-type RadioGroup.
        SymbolVisual.__init__(self, 1)
