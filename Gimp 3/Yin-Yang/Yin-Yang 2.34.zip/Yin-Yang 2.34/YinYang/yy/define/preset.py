#!/usr/bin/env python3
from plugout.define.key import CHILD, TEXT, TYPE
from plugout.container.notebook import Page
from plugout.container.grid import Grid
from yy.define.shared import GRID_ROW_PRESET

GRID_PRESET = {CHILD: {'preset': GRID_ROW_PRESET}, TYPE: Grid}
PAGE_PRESET = {
    CHILD: {1: GRID_PRESET}, TEXT: "Preset", TYPE: Page
}
