#!/usr/bin/env python3
from copy import deepcopy
from plugout.any_group import AnyGroup
from plugout.constant import (
    ACCEPT, ANY_CHANGE, CANCEL,
    CANCEL_TYPE, DELETE_TYPE, OK_TYPE
)
from plugout.container.content_area import ContentArea
from plugout.dialog.dialog import Dialog
from yy.constant import (
    CTRL_P, DIALOG_MAIN_SIGNAL, PREVIEW,
    PREVIEW_TYPE, RESOURCE_KEY, TITLE, YIN_YANG
)
from yy.define.main import DEFINE_MAIN
from yy.output import Output
import gi                                  # type: ignore
gi.require_version('Gdk', '3.0')
from gi.repository import Gdk, GObject     # noqa


def get_resource(output_d, widget_d):
    """
    During production, the Gimp.Resource is used, not the resource's name.
    Find the 'Gimp.Resource' in the AnyGroup's Widget dict.
    Match key with RESOURCE_KEY and then get its resource object.

    output_d: dict
        Collect resource.
        {Widget key: Gimp.Resource}

    widget_d: dict
        {Widget key: Widget instance}
    """
    for k, a in widget_d.items():
        if k in RESOURCE_KEY:
            # Widget instance, 'a'
            output_d[k] = a.get_resource()
        elif isinstance(a, dict):
            # nested preset dict, 'a'
            # The output dict is not nested.
            get_resource(output_d, a)


class DialogMain(GObject.GObject, Dialog):
    """Create a Dialog for creating Yin-Yang symbol."""
    __gsignals__ = DIALOG_MAIN_SIGNAL

    def __init__(self):
        """Open a dialog. Respond to user interaction."""
        def _on_accept():
            self.dialog.destroy()
            self.dialog = None
            self.on_preview()

        def _on_cancel():
            self.dialog.destroy()
            self.dialog = None

        def _on_preview():
            self.on_preview()

        GObject.GObject.__init__(self)

        self._preview_d = {}
        self._preview_button = None
        self._output = Output()

        # {dialog button response type: response type handler}
        response_d = {
            CANCEL_TYPE: _on_cancel,
            DELETE_TYPE: _on_cancel,
            OK_TYPE: _on_accept,
            PREVIEW_TYPE: _on_preview
        }

        self.connect(ANY_CHANGE, self.on_any_change)
        Dialog.__init__(
            self,
            TITLE,
            (
                (CANCEL, CANCEL_TYPE),
                (PREVIEW, PREVIEW_TYPE),
                (ACCEPT, OK_TYPE)
            ),
            self.add_widget,
            response_d
        )

    def add_widget(self, content_area):
        """
        Add Widget to the Dialog's content area.

        content_area: Gtk.Box
            There's room to grow.
        """
        self._preview_button = self.dialog.get_widget_for_response(
            PREVIEW_TYPE
        )

        self._preview_button.set_tooltip_text(CTRL_P)
        self.dialog.connect('key-press-event', self.on_key_press)

        container = ContentArea(content_area)
        self._any_group = AnyGroup(
            DEFINE_MAIN,
            container,
            preset_key=YIN_YANG,
            is_any_change=True,
            host=self
        )
        content_area.show_all()

    def on_any_change(self, *_):
        """Enable the Preview button on any Widget change."""
        if self._preview_button:
            self._preview_button.set_sensitive(1)

    def on_key_press(self, _, event_key):
        """
        Scan keypress for Control-P. If found, emit a preview signal.

        _ Gtk.Dialog
            not used

        event_key: Gdk.EventKey
        """
        is_control = (event_key.state & Gdk.ModifierType.CONTROL_MASK)
        if is_control and event_key.keyval == Gdk.KEY_p:
            self._preview_button.grab_focus()
            self._preview_button.emit('clicked')

    def on_preview(self):
        """
        Respond to a Preview button action by performing a preview
        but only if things have changed since the last preview.
        """
        g = self._preview_button
        d = self._any_group.value_d

        if self.dialog:
            if not g.get_style_context().has_class('pressed'):
                g.get_style_context().add_class('pressed')

        if d != self._preview_d:
            self._preview_d = deepcopy(d)

            # 'value_d' has resource stored as a
            # string representing the resource's name.
            e = {}

            get_resource(e, self._any_group.widget_d)
            self._output.create(d, e)

        if self.dialog:
            g.get_style_context().remove_class('pressed')
            g.set_sensitive(0)
        return
