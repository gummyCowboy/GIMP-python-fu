#!/usr/bin/env python3
from plugout.constant import COLOR_TIP
from plugout.define.key import VALUE
from plugout.widget.emit import WidgetValue, convert_float_color_to_int
from random import uniform
import gi                                 # type: ignore
gi.require_version('Gdk', '3.0')
gi.require_version('Gtk', '3.0')
from gi.repository import Gdk, Gtk        # noqa

"""
Include 'Gtk.Colorbutton wrapper class.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/ColorButton.html'
"""


class ColorButton(WidgetValue):
    """
    Customize a 'Gtk ColorButton' with a wrapper.
    Require COLOR_TIP constant which can be empty.

    When activated the button opens a dialog which
    returns a RGB linear color-space value.
    """
    change_signal = 'color-set'

    def __init__(self, def_d):
        """
        def_d: dict
            ColorButton definition
                value: Gdk.RGBA
                Initialize the button.
                Is the default value for a preset.
        """
        g = Gtk.ColorButton.new()

        super().__init__(def_d, g)
        g.connect('color-set', self.on_color_set)
        g.connect('realize', self.on_color_set)

        q = self.value_d[self.key] = def_d.get(VALUE, (1., 1., 1., 1.))
        self.set_a(q)

    def get_a(self):
        """
        Retrieve the value of the 'Gtk.ColorButton'.

        Return: tuple
            high precision float
            (.0 to 1.)
        """
        a = self.widget.get_rgba()
        return a.red, a.green, a.blue, a.alpha

    @staticmethod
    def on_color_set(color_button):
        """
        A 'Gtk.ColorButton' changed value, so its tooltip needs updating.

        color_button: Gtk.ColorButton
            Has a new value.
        """
        rgba = convert_float_color_to_int(color_button.get_rgba())
        color_button.set_tooltip_text(COLOR_TIP.format(*rgba))

    def randomize(self, *_):
        """
        Respond to a randomize signal. Randomize
        the value of the 'Gtk.ColorButton'.
        """
        self.set_a([round(uniform(.0, 1.), 4) for _ in range(3)])

    def set_a(self, q):
        """
        q: tuple or list
            RGBA; (.0 to 1., .0 to 1., .0 to 1., .0 to 1.)
        """
        self.widget.set_rgba(Gdk.RGBA(*q))

        # Gtk only sends this signal when its ColorChooser dialog is accepted.
        self.widget.emit('color-set')
