#!/usr/bin/env python3
from plugout.define.key import TEXT
from plugout.widget.emit import Widget
import gi                                     # type: ignore
gi.require_version('GimpUi', '3.0')
from gi.repository import GimpUi              # noqa

"""Include a 'GimpUi.HintBox' Widget."""


class Hint(Widget):
    """Customize 'Gtk.HSeparator' with a wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            Hint definition
                text: string
                    Display with an hint icon.
        """
        g = GimpUi.HintBox.new(def_d.get(TEXT, ""))
        super().__init__(def_d, g)
