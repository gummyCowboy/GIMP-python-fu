#!/usr/bin/env python3
from plugout.constant import (
    DELETE_PRESET, DELETE_BUTTON_RESPONSE_TYPE, OK_TYPE
)
from plugout.define.key import GET_LIST
from plugout.widget.emit import WidgetValue
import gi                                  # type: ignore
gi.require_version('Gdk', '3.0')
gi.require_version('Gtk', '3.0')
from gi.repository import Gdk, Gtk         # noqa

"""
Include 'Gtk.ListBox' wrapper class.

Reference: 'lazka.github.io/pgi-docs/Gtk-3.0/classes/ListBox.html'
"""


class ListBox(WidgetValue):
    """Customize 'Gtk.ListBox' with a wrapper."""

    def __init__(self, def_d):
        """
        def_d: dict
            ListBox definition
                get_list: function
                    Init 'Gtk.ListBox's pop-out list.
        """
        g = Gtk.ListBox.new()

        super().__init__(def_d, g)

        get_list = def_d.get(GET_LIST, lambda *_: [])
        self._list_q = get_list()
        for n in self._list_q:
            row = Gtk.ListBoxRow()

            row.add(Gtk.Label(n, halign=Gtk.Align.START))
            g.add(row)

    def get_selected(self):
        row = self.get_selected_row()
        if row:
            return row.get_index()

    def get_selected_name(self):
        row = self.get_selected_row()
        if row:
            return self._list_q[row.get_index()]

    def get_selected_row(self):
        return self.widget.get_selected_row()

    def remove_name(self, name):
        """
        Remove an list item given its name.

        name: string
            Remove this item.
        """
        q = self._list_q
        if name in q:
            row_i = q.index(name)
            row = self.widget.get_row_at_index(row_i)

            self.widget.remove(row)
            q.pop(row_i)
            self.select_row_at_index(max(0, row_i - 1))

    def select_row_at_index(self, i):
        """
        Select a Gtk.ListBox row given its index in the list.

        i: int
            index of item in the list
        """
        row = self.widget.get_row_at_index(i)
        if row:
            self.widget.select_row(row)


class ListBoxPreset(ListBox):
    """Customize ListBox for DialogPresetManage with a wrapper.
    The dialog-host is a GObject with custom signal.
    """

    def __init__(self, def_d):
        """
        def_d: dict
            ListBoxPreset definition
        """
        super().__init__(def_d)

        self._delete_button = self.host.dialog.get_widget_for_response(
            DELETE_BUTTON_RESPONSE_TYPE
        )
        self.widget.connect('key-press-event', self.on_list_box_key_press)
        self.widget.connect('row-selected', self.on_row_selected)
        self._delete_button.set_sensitive(0)

    def on_list_box_key_press(self, _, event_key):
        """
        Delete preset if the user press the delete key.
        Load preset if the user presses the return key.

        _: Gtk.ListBox
            Sent the event.

        event_key: Gdk.EventKey
        """
        n = Gdk.keyval_name(event_key.keyval)

        if n == 'Delete':
            row_i = self.get_selected()

            # The zero position is the default preset.
            if row_i:
                # list of preset name,'q'
                q = self._list_q
                if row_i < len(q):
                    self.host.emit(DELETE_PRESET, q[row_i])
        elif n == 'Return':
            self.host.dialog.emit('response', OK_TYPE)

    def on_row_selected(self, _, row):
        """
        Enable or disable the Delete button depending
        on the preset selected in the list box.

        _: Gtk.ListBox
            Has a list of available preset.
            not used

        row: Gtk.ListBoxRow
            Is selected. Has an index.
        """
        if row:
            self._delete_button.set_sensitive(row.get_index())
