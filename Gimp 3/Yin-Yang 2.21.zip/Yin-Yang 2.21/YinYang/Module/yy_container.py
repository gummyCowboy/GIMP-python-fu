#!/usr/bin/env python3
from yy_constant import DefKey as dk
from yy_widget import Widget
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import GObject, Gtk       # noqa

"""
Include a broad range of Widget class which are Gtk container wrappers.
"""


class Container(GObject.GObject, Widget):
    """
    Super class for container Widget-type.
    Check group dict for its 'group' insertion.
    """
    # {custom signal name: (emission stage, type of signal, define argument)}
    __gsignals__ = {
        'randomize': (GObject.SIGNAL_RUN_FIRST, None, (GObject.TYPE_PYOBJECT,))
    }

    def __init__(self, d, e, data_d, key, g):
        """
        d: dict; Has optional item.
            border_width: int
            column_spacing: int
            row_spacing: int

        e: dict
            Identify option group. For each Widget in option group,
            receive option group scoped signal, e.g. 'randomize'.

        data_d: dict
            Update value on change.

        key: value
            Identify the container in an AnyGroup.

        g: Gtk.Widget
            Is the container-wrapper's candy.
        """
        GObject.GObject.__init__(self)
        Widget.__init__(self, d, e, data_d, key, g)

        # Prep the group dict's 'type' to identify an option group.
        if isinstance(self, e[dk.TYPE]):
            e['group'] = self


class ContentArea(Container):
    """Is a Gtk.Dialog's content area."""

    def __init__(self, box, d):
        """
        box: Gtk.Container
            Receive Widget.

        d: dict
            Identify option group type.
        """
        super().__init__({}, d, {}, 'content', box)

    def add(self, g):
        """
        Add something to the Gtk.VBox.
        """
        self.widget.add(g.widget)


class Grid(Container):
    """Is a custom Gtk.Grid."""

    def __init__(self, d, e, data_d, key):
        """
        d: dict; Has optional item.
            border_width: int
            column_spacing: int
            row_spacing: int

        e: dict
            Identify option group.

        data_d: dict
            Update value on change.

        key: value
            Identify the container in an AnyGroup.
        """
        self._row = 0
        g = Gtk.Grid()

        super().__init__(d, e, data_d, key, g)
        g.set_border_width(d.get(dk.BORDER_WIDTH, 12))
        g.set_column_spacing(d.get(dk.COLUMN_SPACING, 12))
        g.set_row_spacing(d.get(dk.ROW_SPACING, 2))
        e['group'] = self

    def add(self, g):
        """
        Add something to a Gtk Box.

        g: GridRow
            Add a row to table.
        """
        for i in range(g.columns):
            q = g.row_get_widget(i)
            # The column/cell/widget can be empty.
            if q:
                width, cell_g = q
                if cell_g:
                    # cell height, '1'
                    self.widget.attach(
                        cell_g.gtk_g, i, self._row, width, 1
                    )
        self._row += 1


class GridCell(Container):
    """Add a row to Grid."""

    def __init__(self, d, e, data_d, key):
        """
        d: dict; Has optional item.
            width: int
            column: int

        e: dict
            Identify option group.

        data_d: dict
            Update value on change.

        key: value
            Identify the container in an AnyGroup.
        """
        super().__init__(d, e, data_d, key, None)

        self.width = d.get(dk.WIDTH, 1)
        self.column = d.get(dk.COLUMN, 0)

    def add(self, g):
        """
        Record the assigned Widget for the Grid cell.

        g: Widget
            Is the cell occupant.
        """
        self.widget = g

    def cell_get_widget(self):
        """Fetch the Widget assigned to the cell."""
        return self.widget


class GridRow(Container):
    """Add a row to Grid."""

    def __init__(self, d, e, data_d, key):
        """
        d: dict; Has optional item.
            columns: int
            row: int
            text: string

        e: dict
            Identify option group.

        data_d: dict
            Update value on change.

        key: value
            Identify the container in an AnyGroup.
        """
        super().__init__(d, e, data_d, key, None)

        self.label = Gtk.Label(label=d.get(dk.TEXT, ""))
        self.columns = d.get(dk.COLUMNS, 1)
        self.cell_q = [None] * self.columns

    def add(self, g):
        """
        Receive GridCell for the Grid row.

        g: GridCell
        """
        self.cell_q[g.column] = g

    def row_get_widget(self, column):
        """
        Retrieve the Cell widget for given column if it exists.

        column: int
            Is a zero-based index in the row.

        Return: tuple
            (Grid cell width, Grid cell Widget)
        """
        # GridCell, 'g'
        g = self.cell_q[column]
        if g:
            return g.width, g.cell_get_widget()


class HBox(Container):
    """Is a custom Gtk.HBox."""

    def __init__(self, d, e, data_d, key):
        """
        d: dict; Has optional item.
            homogeneous: bool
                Make the VBox divvy up the space evenly.

        e: dict
            Identify option group.

        data_d: dict
            Update value on change.

        key: value
            Identify the container in an AnyGroup.
        """
        g = Gtk.HBox(homogeneous=d.get(dk.HOMOGENEOUS, True))
        super().__init__(d, e, data_d, key, g)

    def add(self, g):
        """
        Add something to the Gtk.Box.
        """
        self.widget.add(g.gtk_g)

    def hide(self):
        self.gtk_g.hide()

    def show(self):
        self.gtk_g.show()


class Notebook(Container):
    """Is a custom Gtk.Notebook."""

    def __init__(self, d, e, data_d, key):
        """
        d: dict; Has optional item.

        e: dict
            Identify option group.

        data_d: dict
            Update value on change.

        key: value
            Identify the container in an AnyGroup.
        """
        g = Gtk.Notebook.new()
        super().__init__(d, e, data_d, key, g)

    def add(self, g):
        """
        Add something to the Gtk.VBox.

        g: Page
            Append page to Gtk.Notebook.
        """
        self.widget.append_page(g.widget, g.tab_label)


class VBox(Container):
    """Is a custom Gtk.VBox."""

    def __init__(self, d, e, data_d, key):
        """
        d: dict; Has optional item.
            homogeneous: bool
                Make the VBox divvy up the space evenly.

        e: dict
            Identify option group.

        data_d: dict
            Update value on change.

        key: value
            Identify the container in an AnyGroup.
        """
        g = Gtk.VBox(homogeneous=d.get(dk.HOMOGENEOUS, False))
        super().__init__(d, e, data_d, key, g)

    def add(self, g):
        """
        Add something to the Gtk.Box.
        """
        self.widget.add(g.gtk_g)


class Page(VBox):
    """Is a custom Gtk.VBox."""

    def __init__(self, d, e, data_d, key):
        """
        d: dict; Has optional item.
            homogeneous: bool
                Make the VBox divvy up the space evenly.

            text: string
                Is for the tab label.

        e: dict
            Identify group.

        data_d: dict
            Update value on change.

        key: value
            Identify the widget in an AnyGroup.
        """
        super().__init__(d, e, data_d, key)
        self.tab_label = Gtk.Label(label=d.get(dk.TEXT, ""))
