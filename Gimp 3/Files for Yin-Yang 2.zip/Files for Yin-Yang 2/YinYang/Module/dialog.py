#!/usr/bin/env python3
from output import Output, _
from random import uniform
import colorsys
import gi       # type: ignore
import sys

gi.require_version('Gdk', '3.0')
gi.require_version('Gtk', '3.0')

from gi.repository import Gdk, GimpUi, Gtk

# ColorButton insight
COLOR_TOOLTIP = _(" Red\t{} \n Green\t{} \n Blue\t{} \n Alpha\t{}")

# Init dialog or load default value with this read-only dict.
# {widget key: widget init value}
DEFAULT_VALUE_D = {
    'is_anime': 0,
    'color_1': Gdk.RGBA(1., 1., 1., 1.),
    'color_2': Gdk.RGBA(.0, .0, .0, 1.),
    'division': "4",
    'eye_w': .33,
    'frame': 12,
    'is_gradient': 0,
    'pattern_1': None,
    'pattern_2': None,
    'radius': 200,
    'rim_w': 0,
    'ring_w': 1.,
    'is_flip': 0,
    'timer': 100,
    'type': 0,
}

# Preview button id
RESPONSE_PREVIEW = -99

# Button response in dialog.
response_d = {
    RESPONSE_PREVIEW: None,
    Gtk.ResponseType.CANCEL: None,
    Gtk.ResponseType.DELETE_EVENT: None,
    Gtk.ResponseType.OK: None
}

# Gtk.Grid row index for widget placement
DIVISION_INDEX, \
    RADIUS_INDEX, \
    RIM_W_INDEX, \
    RING_WIDTH_INDEX, \
    EYE_W_INDEX, \
    FRAME_INDEX, \
    TIMER_INDEX, \
    TYPE_INDEX, \
    ROTATE_INDEX, \
    CHECK_INDEX, \
    PATTERN_INDEX, \
    COLOR_BUTTON_INDEX, \
    RANDOM_INDEX = range(13)


def add_color_button_row(grid, d):
    """
    Add Gtk.ColorButton options to a Gtk.Grid.

    grid: Gtk.Grid
        Receive ColorButton.

    d: dict
        {widget key: widget}
        Store each widget for value retrieval.
    """
    # Remember the label as it changes visibility.
    d['color_label'] = add_grid_label(grid, COLOR_BUTTON_INDEX, _("Color"))

    # container for ColorButton first row, 'hbox'
    hbox = d['hbox'] = Gtk.Box(spacing=6)

    # Create the row.
    for i in range(2):
        g = d[('color_1', 'color_2')[i]] = Gtk.ColorButton.new_with_rgba(
            Gdk.RGBA(red=1., green=1., blue=1., alpha=1.)
        )

        # Add the alpha scale to the chooser dialog.
        # Gtk.ColorChooser.set_use_alpha(g, True)

        g.connect('color-set', on_color_set)
        hbox.pack_start(
            g,
            True,                   # expand
            True,                   # fill
            2                       # padding
        )

    # column, '1'; cell width, '1'; cell height, '1'
    grid.attach(hbox, 1, COLOR_BUTTON_INDEX, 1, 1)


def add_division_combobox(grid):
    """
    Add a Division ComboBoxText to a Gtk.Grid.

    grid: Gtk.Grid
        Receive ComboBoxText.

    Return: Gtk.ComboBoxText
        newly created
    """
    add_grid_label(grid, DIVISION_INDEX, _("Division"))

    combobox = Gtk.ComboBoxText.new()

    for n in ("2", "4", "6", "8", "10", "12"):
        combobox.append_text(n)

    # column, '1'; cell width, '1'; cell height, '1'
    grid.attach(combobox, 1, DIVISION_INDEX, 1, 1)

    combobox.set_tooltip_text(" Set the number of motion pairs. ")
    return combobox


def add_eye_spinner(grid):
    """
    Add a Eye Width SpinButton to a Gtk.Grid.

    grid: Gtk.Grid
        Receive SpinButton.

    Return: Gtk.SpinButton
        newly created
    """
    add_grid_label(grid, EYE_W_INDEX, _("Eye Width"))

    # init value, lower limit, upper limit, step inc, page inc, page size
    spin = add_grid_spin(
        grid, EYE_W_INDEX, (0., .0, 1., .01, .1, 0.), digits=2
    )

    spin.set_tooltip_text(" Factor the Ring Width. ")
    return spin


def add_frame_spinner(grid):
    """
    Add a Frame Count SpinButton to a Gtk.Grid.

    grid: Gtk.Grid
        Receive SpinButton.

    Return: Gtk.SpinButton
        newly created
    """
    label = add_grid_label(grid, FRAME_INDEX, _("Frame Count"))

    # init value, lower limit, upper limit, step inc, page inc, page size
    spin = add_grid_spin(
        grid, FRAME_INDEX, (0., 1., 999., 1., 2., 0.)
    )

    spin.set_tooltip_text(
        " Create animation layers with more than one frame . "
    )
    return label, spin


def add_grid(vbox):
    """
    Add a Gtk.Grid to a Gtk.VBox.

    Return: Gtk.Grid
        newly created
    """
    grid = Gtk.Grid()

    grid.set_column_homogeneous(False)
    grid.set_border_width(1)
    grid.set_column_spacing(12)
    grid.set_row_spacing(1)
    vbox.add(grid)
    return grid


def add_grid_label(grid, row, text):
    """
    Given a Gtk.Grid, add a Gtk.Label to its first column.

    grid: Gtk.Grid
        Receive Label.

    row: int
        0 to n
        Identify Grid row.

    text: string
        Is the Label's displayed text.

    Return: Gtk.Label
        newly created
    """
    """ Create a label and set it in first column of a grid. """
    label = create_label(text)

    # column, '0'; cell width, '1'; cell height, '1'
    grid.attach(label, 0, row, 1, 1)

    return label


def add_grid_spin(grid, row, adj_arg, digits=0):
    """
    Add a SpinButton to a Grid. Place the button in the second column.

    grid: Gtk.Grid
        Receive the SpinButton in column 1.

    row: int
        0 to n
        Is the row index in the Grid where the SpinButton is placed.

    adj_arg: tuple
        Is given to a Gtk.Adjustment during its init call.

    digits: int
        Is the number of decimal places in the widget display.

    Return: Gtk.SpinButton
        newly created
    """
    spin = Gtk.SpinButton.new(
        Gtk.Adjustment.new(*adj_arg), climb_rate=.02, digits=digits
    )

    spin.set_numeric(True)
    spin.set_snap_to_ticks(True)
    spin.set_max_length(4)
    spin.set_width_chars(4)

    # column, '1'; cell width, '1'; cell height, '1'
    grid.attach(spin, 1, row, 1, 1)
    return spin


def add_hint_box(vbox):
    """
    Place GIMP's hint box on top of the dialog.

    vbox: Gtk.Box
        Has vertical packing to receive HintBox.
    """
    vbox.pack_start(
        GimpUi.HintBox.new(_("Create a Yin-Yang image or GIF animation.")),
        False,                  # expand
        False,                  # fill
        0                       # padding
    )


def add_pattern_chooser_row(grid, d):
    """
    Add GimpUi.PatternChooser options to a Gtk.Grid.

    Init:
        GimpUi.PatternChooser.new()

    Getter:
        PatternChooser.get_resource() returns a Gimp.Pattern.

    Changed Signals: 'parent-set' on init, and 'resource-set' on change.

    Setter:
        I tried widget.set_resource(Gimp.Pattern()), where
        widget is a GimpUi.PatternChooser instance,
        but it crashes GIMP 3 RC1.

    grid: Gtk.Grid
        Receive ColorButton.

    d: dict
        {widget key: widget}
        Store each widget for value retrieval.
    """
    # Remember the label as it changes visibility.
    d['pattern_label'] = add_grid_label(grid, PATTERN_INDEX, _("Pattern"))

    # container for ColorButton first row, 'hbox'
    hbox = d['hbox'] = Gtk.Box(spacing=6)

    # Create the row.
    for i in range(2):
        g = d[('pattern_1', 'pattern_2')[i]] = GimpUi.PatternChooser.new()

        g.connect('resource-set', on_pattern_set)
        hbox.pack_start(
            g,
            True,                   # expand
            True,                   # fill
            2                       # padding
        )

    # column, '1'; cell width, '1'; cell height, '1'
    grid.attach(hbox, 1, PATTERN_INDEX, 1, 1)


def on_pattern_set(g, pattern, is_valid):
    """
    Respond to 'resource-set' events.

    g: GimpUi.PatternChooser
        Is responsible.

    Gimp.Pattern: Gimp.Pattern
        on display

    is_valid: bool
        Is True if the pattern was qualified by the user.
    """
    if is_valid:
        g.set_tooltip_text(pattern.get_name())


def add_radius_spinner(grid):
    """
    Add a Symbol Radius SpinButton to a Gtk.Grid.

    grid: Gtk.Grid
        Receive SpinButton.

    Return: Gtk.SpinButton
        newly created
    """
    add_grid_label(grid, RADIUS_INDEX, _("Symbol Radius"))

    # Init value, lower limit, upper limit, step inc, page inc, page size
    return add_grid_spin(grid, RADIUS_INDEX, (0., 12., 9999., 1., 10., 0.))


def add_rim_spinner(grid):
    """
    Add a Rim Width SpinButton to a Gtk.Grid.

    grid: Gtk.Grid
        Receive SpinButton.

    Return: Gtk.SpinButton
        newly created
    """
    add_grid_label(grid, RIM_W_INDEX, _("Rim Width"))

    # init value, lower limit, upper limit, step inc, page inc, page size
    return add_grid_spin(grid, RIM_W_INDEX, (0., 0., 9999., 1., 10., 0.))


def add_rotate_radiobutton(grid):
    """
    Add Rotate options to a Gtk.Grid.

    grid: Gtk.Grid
        Receive Rotate RadioButton.

    Return: tuple
        (Gtk.RadioButton, Gtk.RadioButton)
        (Clockwise option, Counter-Clockwise option)
        newly created
    """
    add_grid_label(grid, ROTATE_INDEX, _("Rotate"))

    # container for RadioButton, 'hbox'
    hbox = Gtk.Box(spacing=0)

    button = Gtk.RadioButton.new_with_label_from_widget(
        None, _("Clockwise")
    )
    button1 = Gtk.RadioButton.new_with_label_from_widget(
        button, _("Counter-Clockwise")
    )

    # Expand and fill, 'True'; zero padding, '0'.
    hbox.pack_start(button, True, True, 0)
    hbox.pack_start(button1, True, True, 0)

    # column, '1'; cell width, '1'; cell height, '1'
    grid.attach(hbox, 1, ROTATE_INDEX, 1, 1)

    return button, button1


def add_timer_spinner(grid):
    """
    Add a Timer SpinButton to a Gtk.Grid.

    grid: Gtk.Grid
        Receive SpinButton.

    Return: Gtk.SpinButton
        newly created
    """
    label = add_grid_label(grid, TIMER_INDEX, _("Frame Timer in Millisecond"))

    # init value, lower limit, upper limit, step inc, page inc, page size
    spin = add_grid_spin(
        grid, TIMER_INDEX, (1., 1., 9999., 1., 10., 0.)
    )

    spin.set_tooltip_text(
        " Is the wait time that an animation takes between frames. "
    )
    return label, spin


def add_ring_width_spinner(grid):
    """
    Add a Ring Width SpinButton to a Gtk.Grid.

    grid: Gtk.Grid
        Receive SpinButton.

    Return: Gtk.SpinButton
        newly created
    """
    add_grid_label(grid, RING_WIDTH_INDEX, _("Ring Width"))

    # init value, lower limit, upper limit, step inc, page inc, page size
    spin = add_grid_spin(
        grid, RING_WIDTH_INDEX, (0., .0, 1., .01, .1, 0.), digits=2
    )

    spin.set_tooltip_text(
        " Create a center hole. \n Factor the Symbol Radius. "
    )
    return spin


def convert_float_color_to_int(color):
    return [
        int(a * 255)
        for a in (color.red, color.green, color.blue, color.alpha)
    ]


def create_label(text, x_align=.0):
    """
    Make a Gtk.Label.

    text: string
        Assign to the label.

    x_align: float
        .0 to 1.
        Horizontally position the label.
    """
    label = Gtk.Label(label=text)

    label.set_xalign(x_align)
    label.set_yalign(.5)
    return label


def on_color_set(color_button):
    """
    A ColorButton changed value, so its tooltip needs updating.

    color_button: Gtk.ColorButton
        Has a new value.
    """
    rgba = convert_float_color_to_int(color_button.get_rgba())
    color_button.set_tooltip_text(COLOR_TOOLTIP.format(*rgba))


class Dialog:
    """Create a GimpUI.Dialog having Cancel, Preview, and Accept buttons."""

    def __init__(self, add_widget_p, response_p):
        """
        add_widget_p: function
            Add widget to the Dialog's VBox.

        response_p: function
            Handle Cancel, Preview, and Accept button action.
        """
        self.dialog = GimpUi.Dialog(
            use_header_bar=Gtk.Settings.get_default().
            get_property("gtk-dialogs-use-header"),
            title="Yin-Yang 2"
        )
        vbox = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            homogeneous=False,
            spacing=0
        )

        self.dialog.get_content_area().add(vbox)
        self.dialog.add_button(_("_Cancel"), Gtk.ResponseType.CANCEL)
        self.dialog.add_button(_("Preview"), RESPONSE_PREVIEW)
        self.dialog.add_button(_("_Accept"), Gtk.ResponseType.OK)

        # Add additional widget.
        add_widget_p(vbox)

        # Render dialog.
        vbox.show_all()
        self.dialog.show()

        # Map button responses to callback.
        self.dialog.connect('response', response_p)

        # Start event loop.
        Gtk.main()


class PluginDialog:
    """
    Create a GimpUI.Dialog for user interaction and define output settings.
    """

    def __init__(self):
        """Open a dialog. Respond to user interaction."""
        # {option key: widget}
        # For setting default value and retrieving widget.
        self.widget_d = {}

        # Capture dialog settings for determining
        # a boolean change state between Preview actions.
        # {widget key: widget value}
        self.preview_d = {}

        # Init UI theme.
        GimpUi.init(sys.argv[0])

        self.output = Output()

        response_d[Gtk.ResponseType.CANCEL] = \
            response_d[Gtk.ResponseType.DELETE_EVENT] = self.on_cancel
        response_d[Gtk.ResponseType.OK] = self.on_accept
        response_d[RESPONSE_PREVIEW] = self.on_preview
        Dialog(self.add_dialog_widget, self.on_dialog_button)

    def add_checkbutton_row(self):
        """
        Add a Gradient CheckButton to a Gtk.Grid.

        grid: Gtk.Grid
            Receive CheckButton.

        Return: Gtk.CheckButton
            newly created
        """
        hbox = Gtk.HBox(spacing=0)
        g = Gtk.CheckButton.new_with_label("Gradient")
        g1 = Gtk.CheckButton.new_with_label("Animate")

        for i in (g, g1):
            hbox.pack_start(i, True, True, 0)

        # column, '1'; cell width, '1'; cell height, '1'
        self.grid.attach(hbox, 1, CHECK_INDEX, 1, 1)

        g.set_tooltip_text(" Make a gradient overlay. ")
        g1.set_tooltip_text(" Animate the symbol. ")
        g1.connect('toggled', self.on_anime)

        # Cause the frame widget to hide on start, 'realize'.
        g1.connect('realize', self.on_anime)
        return g, g1

    def add_dialog_widget(self, vbox):
        """
        Add Yin-Yang widget to the Dialog's VBox.

        vbox: Gtk.Box
            Has vertical packing.
        """
        add_hint_box(vbox)

        g = self.grid = add_grid(vbox)
        d = self.widget_d
        d['division'] = add_division_combobox(g)
        d['radius'] = add_radius_spinner(g)
        d['rim_w'] = add_rim_spinner(g)
        d['ring_w'] = add_ring_width_spinner(g)
        d['eye_w'] = add_eye_spinner(g)
        d['frame'] = add_frame_spinner(g)
        d['timer'] = add_timer_spinner(g)
        d['is_gradient'], d['is_anime'] = self.add_checkbutton_row()
        d['type'] = self.add_type_radiobutton()
        d['is_flip'] = add_rotate_radiobutton(g)

        add_color_button_row(g, d)
        add_pattern_chooser_row(g, d)
        self.add_random_button()
        self.load_default()

        # Make the RadioButtons all the same size.
        same_size = Gtk.SizeGroup(mode=Gtk.SizeGroupMode.BOTH)

        for g in d['is_flip'] + d['type']:
            same_size.add_widget(g)

    def add_random_button(self):
        """
        Add an HBox with three buttons for modifying the Color Array.
        """
        hbox = Gtk.Box(spacing=1, homogeneous=True)
        g = Gtk.Button.new_with_label("Color")
        g1 = Gtk.Button.new_with_label("Hue")
        g2 = Gtk.Button.new_with_label("Saturation")
        g3 = Gtk.Button.new_with_label("Lightness")
        align_left = Gtk.Alignment()
        align_mid = Gtk.Alignment()
        align_right = Gtk.Alignment()

        label = add_grid_label(self.grid, RANDOM_INDEX, _("Random"))

        # first
        align_left.set_padding(0, 0, 0, 4)
        align_left.add(g)
        hbox.pack_start(align_left, True, True, 0)

        # middle
        align_mid.set_padding(0, 0, 0, 4)
        align_mid.add(g1)
        hbox.pack_start(align_mid, True, True, 0)
        hbox.pack_start(g2, True, True, 0)

        # last
        align_right.set_padding(0, 0, 4, 0)
        align_right.add(g3)
        hbox.pack_start(align_right, True, True, 0)

        for i, g_ in enumerate((g, g1, g2, g3)):
            g_.connect('clicked', self.randomize, i)

        # column, '1'; cell width, '1'; cell height, '1'
        self.grid.attach(hbox, 1, RANDOM_INDEX, 1, 1)
        self.widget_d['random_widget'] = label, g, g1, g2, g3

    def add_type_radiobutton(self):
        """
        Add Type options to a Gtk.Grid.

        grid: Gtk.Grid
            Receive Type RadioButton.

        Return: tuple
            (Gtk.RadioButton, Gtk.RadioButton)
            (Clockwise option, Counter-Clockwise option)
            newly created
        """
        add_grid_label(self.grid, TYPE_INDEX, _("Type"))

        # container for RadioButton, 'hbox'
        hbox = Gtk.Box(spacing=0)

        button = Gtk.RadioButton.new_with_label_from_widget(
            None, _("Color")
        )
        button1 = Gtk.RadioButton.new_with_label_from_widget(
            button, _("Pattern")
        )

        # Expand and fill, 'True'; zero padding, '0'.
        hbox.pack_start(button, True, True, 0)
        hbox.pack_start(button1, True, True, 0)

        # column, '1'; cell width, '1'; cell height, '1'
        self.grid.attach(hbox, 1, TYPE_INDEX, 1, 1)

        button.connect('realize', self.on_type)
        button.connect('toggled', self.on_type)
        return button, button1

    def on_cancel(self):
        """Close the dialog. The user chose to cancel."""
        Gtk.main_quit()

    def gather_dialog_setting(self):
        """
        Load a dictionary with dialog widget value.

        Return: dict
            {widget key: widget value}
        """
        d = {}
        e = self.widget_d

        # ComboBoxText
        d['division'] = int(e['division'].get_active_text())

        # label and SpinButton, 0, '1'
        for k in ('frame', 'timer'):
            d[k] = e[k][1].get_value()

        # int SpinButton
        for k in ('radius', 'rim_w'):
            d[k] = int(e[k].get_value())

        # float SpinButton
        for k in ('eye_w', 'ring_w'):
            d[k] = e[k].get_value()

        # RadioButton; the first button index, '0'
        for k in ('type',):
            d[k] = e[k][0].get_active()

        d['is_flip'] = e['is_flip'][1].get_active()

        # CheckButton
        for k in ('is_anime', 'is_gradient'):
            d[k] = e[k].get_active()

        # ColorButton
        for k in ('color_1', 'color_2'):
            a = e[k].get_rgba()
            d[k] = a.red, a.green, a.blue, a.alpha

        # PatternChooser
        for k in ('pattern_1', 'pattern_2'):
            d[k] = e[k].get_resource()
        return d

    def load_default(self, *_):
        """
        Load default value into dialog widget.

        _: Gtk.Button
            Default
            not used
        """
        d = self.widget_d
        e = DEFAULT_VALUE_D

        # ComboBoxText
        d['division'].set_active(0)

        # RadioButton
        for k in ('is_flip', 'type'):
            d[k][0].set_active(0)

        # Set Color Array.
        for k in ('color_1', 'color_2'):
            d[k].set_rgba(e[k])
            on_color_set(d[k])

        for k in ('is_anime', 'is_gradient', 'division'):
            d[k].set_active(0)

        for k in ('eye_w', 'radius', 'rim_w', 'ring_w'):
            d[k].set_value(e[k])

        # label and spinner, 0, '1'
        for k in ('frame', 'timer'):
            d[k][1].set_value(e[k])

    def on_dialog_button(self, dialog, response_id):
        """
        Handle a user initiated dialog-process button action.

        dialog: GimpUI.Dialog
            Is the Yin-Yang dialog.

        response_id: Gtk.ResponseType
            Identify button.
        """
        p = response_d.get(response_id)
        if p is not None:
            p()

    def on_accept(self):
        """
        Respond to an Accept button action. Create a Yin-Yang image.
        """
        self.on_preview()
        Gtk.main_quit()

    def on_anime(self, *arg):
        """
        Respond to an Animate CheckButton change. Hide or show frame widget.

        arg: tuple or Gtk.CheckButton
        """
        d = self.widget_d
        q = [g for k in ('frame', 'timer') for g in d[k]]

        if d['is_anime'].get_active():
            for g in q:
                g.show()
        else:
            for g in q:
                g.hide()

    def on_preview(self):
        """
        Respond to a Preview button action by performing a preview
        but only if things have changed since the last preview.
        """
        d = self.gather_dialog_setting()

        if self.preview_d != d:
            self.output.create(d)
        self.preview_d = d

    def on_type(self, *arg):
        """
        Respond to an Type CheckButton change.
        Hide or show Type-related widget.

        arg: tuple or Gtk.CheckButton
        """
        d = self.widget_d
        q = [d[k] for k in ('pattern_1', 'pattern_2', 'pattern_label')]
        q1 = [d[k] for k in ('color_1', 'color_2', 'color_label')]

        if d['type'][0].get_active():
            for g in q:
                g.hide()

            for g in q1:
                g.show()
            for g in d['random_widget']:
                g.show()
        else:
            for g in q:
                g.show()

            for g in q1:
                g.hide()
            for g in d['random_widget']:
                g.hide()

    def randomize(self, button, i):
        """
        Randomize color button value on multiple random-button action.

        button: Gtk.Button
            Is responsible.
            not used

        i: index
            random index
        """
        d = self.widget_d
        rgb = [uniform(.0, 1.) for f in range(3)]

        if i:
            i1 = i - 1

            # hue, saturation, lightness, 'q', in float, .0 to 1.
            q = list(colorsys.rgb_to_hls(*rgb))

            # Invert HLS value.
            q[i1] = 1. - q[i1]

            rgb1 = list(colorsys.hls_to_rgb(*q))

        else:
            # Invert color.
            rgb1 = [1. - f for f in rgb]

        # alpha, '1'.
        rgb1 += [1.]

        for a in zip(('color_1', 'color_2'), (rgb, rgb1)):
            k, q = a
            d[k].set_rgba(Gdk.RGBA(*q))
            on_color_set(d[k])
