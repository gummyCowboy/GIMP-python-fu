#!/usr/bin/env python3
from copy import deepcopy
from rotor.constant import (
    CTRL_P, DIALOG_MAIN_SIGNAL,
    PREVIEW, PREVIEW_TYPE, REPLACE, TITLE
)
from rotor.define_main import DEFINE_MAIN
from rotor.output import Output
from plugout.any_group import AnyGroup
from plugout.constant import (
    ACCEPT, ANY_CHANGE, CANCEL,
    CANCEL_TYPE, DELETE_TYPE,
    NO_SELECTED_LAYER, OK_TYPE
)
from plugout.container.content_area import ContentArea
from plugout.dialog.dialog import Dialog
import gi                                             # type: ignore
gi.require_version('Gdk', '3.0')
gi.require_version('Gimp', '3.0')
from gi.repository import Gdk, Gimp, GObject          # noqa

"""Define a dialog class and support function for renaming layer."""


def get_selected_layer(q):
    """
    Create a list of selected 'Gimp.Layer'.

    q: list
        [Gimp.Layer, ..., Gimp.GroupLayer, ...]
        Remove GroupLayer from list.

    Return: list
        [Gimp.Layer, ...]
    """
    # Filter out 'Gimp.GroupLayer' and 'Gimp.LayerMask'.
    q1 = []

    for i in q:
        id_ = i.get_id()
        if (
            not Gimp.Item.id_is_group_layer(id_) and
            not Gimp.Item.id_is_layer_mask(id_) and
            not Gimp.Item.id_is_channel(id_)
        ):
            q1.append(i)
    return q1


class DialogMain(GObject.GObject, Dialog):
    """
    Create a 'GimpUI.Dialog' for user interaction and define output settings.
    """
    __gsignals__ = DIALOG_MAIN_SIGNAL

    def __init__(self, image, drawables):
        """
        Open a dialog. Respond to user interaction.

        image: Gimp.Image
            WIP

        drawables: list
            [Gimp.Drawable, ...]
        """
        def _on_accept():
            self.dialog.destroy()

            self.dialog = None
            self.on_preview()

        def _on_cancel():
            self.dialog.destroy()
            self.dialog = None

        def _on_preview():
            self.on_preview()

        GObject.GObject.__init__(self)

        # Is a 'AnyGroup.value_d' copy made on Preview action.
        # {Widget key: Widget value}
        self._preview_d = {}

        self._preview_button = None
        self._image = image
        drawables = get_selected_layer(drawables)

        if drawables:
            self._output = Output(image, drawables)
            response_d = {
                CANCEL_TYPE: _on_cancel,
                DELETE_TYPE: _on_cancel,
                OK_TYPE: _on_accept,
                PREVIEW_TYPE: _on_preview
            }

            self.connect(ANY_CHANGE, self.on_any_change)
            Dialog.__init__(
                self,
                TITLE,
                (
                    (CANCEL, CANCEL_TYPE),
                    (PREVIEW, PREVIEW_TYPE),
                    (ACCEPT, OK_TYPE)
                ),
                self.add_widget,
                response_d
            )
        else:
            Gimp.message(NO_SELECTED_LAYER)

    def add_widget(self, content_area):
        """
        Add Widget to the Dialog's content area.

        content_area: Gtk.Box
            There's room to grow.
        """
        self._preview_button = self.dialog.get_widget_for_response(
            PREVIEW_TYPE
        )

        self._preview_button.set_tooltip_text(CTRL_P)
        self.dialog.connect('key-press-event', self.on_key_press)

        container = ContentArea(content_area)
        self._any_group = AnyGroup(
            DEFINE_MAIN, container, is_any_change=True, host=self
        )
        content_area.show_all()

    def on_any_change(self, *_):
        """Enable the Preview button on any Widget change."""
        if self._preview_button:
            self._preview_button.set_sensitive(1)

    def on_key_press(self, _, event_key):
        """
        Scan for a Control-P keypress. If found, emit a preview signal.

        _ Gtk.Dialog
            not used

        event_key: Gdk.EventKey
        """
        is_control = (event_key.state & Gdk.ModifierType.CONTROL_MASK)
        if is_control and event_key.keyval == Gdk.KEY_p:
            self._preview_button.emit('clicked')

    def on_preview(self):
        """
        Respond to a Preview button action by performing a preview
        but only if things have changed since the last preview.
        """
        j = self._image
        d = self._any_group.value_d
        g = self._preview_button

        if self.dialog:
            if not g.get_style_context().has_class('pressed'):
                g.get_style_context().add_class('pressed')

        if d != self._preview_d:
            self._preview_d = deepcopy(d)
            channel = None

            if not Gimp.Selection.is_empty(j):
                selection = j.get_selection()
                channel = selection.save(j)
                Gimp.Selection.none(j)

            self._output.create(d)
            if channel:
                j.select_item(REPLACE, channel)
                j.remove_channel(channel)

        # If the dialog is dead, then skip.
        if self.dialog:
            g.get_style_context().remove_class('pressed')
            g.set_sensitive(0)
