#!/usr/bin/env python3
from plugout.constant import ANY_CHANGE
import gi                                          # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GLib, GObject      # noqa


def _(n):
    """
    Translate English to local language.

    n: string
        Translate.

    Return: string
        translated
    """
    return GLib.dgettext(None, n)


NORMAL = Gimp.LayerMode.NORMAL
PROCEDURE_NAME = 'plug-in-rotor'
RADIAN_180 = 3.141592653
RADIAN_360 = 6.283185307
TITLE = "Rotor 1"

# custom button response type
PREVIEW_TYPE = -99

REPLACE = Gimp.ChannelOps.REPLACE

# Translate____________________________________________________________________
CLOCKWISE = _("Clockwise")
COUNTER_CLOCKWISE = _("Counter-Clockwise")
CTRL_P = _("Ctrl-P")
DIRECTION = _("Direction")
FRAME_COUNT = _("Frame Count")
HINT_TEXT = _(
    "Transform each selected layer into a new\n"
    "image composed of stacked and rotated layer."
)
PLUGIN_BLURB = _(
    "Create a new image from a single layer which is then rotated repeatedly."
)
PLUGIN_TOOLTIP = _("Create a new image of a rotated layer.")
PREVIEW = _("Preview")
TIMER = _("Timer")
TIMER_TIP = _(
    " Is the wait time, in millisecond,"
    " that an animation takes between frames. "
)

# custom Signal________________________________________________________________

# run first argument
# (emission stage, type of signal, argument type)
SIGNAL_ARG = GObject.SIGNAL_RUN_FIRST, None, (GObject.TYPE_PYOBJECT,)

DIALOG_MAIN_SIGNAL = {}

for k in (
    ANY_CHANGE,
):
    DIALOG_MAIN_SIGNAL[k] = SIGNAL_ARG
