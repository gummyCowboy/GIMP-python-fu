#!/usr/bin/env python3
from plugout.constant import CONTAINER, MISSING_TYPE_ERROR
from plugout.define.key import (
    CHILD, HOST, IS_ANY_CHANGE, KEY, KEY_PATH, PRESET,
    RANDOMER, TYPE, VALUE_D, WIDGET_D
)

"""
________
AnyGroup
¯¯¯¯¯¯¯¯
AnyGroup's job is to create a user-interface given a definition dict.
AnyGroup peruses a definition dict creating Container and Widget alike.
The definition is structured in a tree-form where a starting root Container
receives all of the AnyGroup's packaged content.

_______________________
AnyGroup Initialization
¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
AnyGroup has no public methods. It is the initialization that creates the UI.

# Initialize.
AnyGroup(
    # AnyGroup definition; Define the UI as a static tree, like a seed it is
    # planted to reproduce a user-interface.
    def_d: dict

    # Receive Widget. This is the AnyGroup host's container, the pot
    # where the AnyGroup definition tree can grow. It is typically a
    # ContentArea Container.
    container: Container

    # Create a preset folder for the entire AnyGroup. It is useful if there
    # are nested preset in the AnyGroup.
    preset_key: string or None

    # If the host is a GObject configured to send/receive 'any-change' signal,
    # then set this value to True.
    is_any_change: bool

    # If the host is a GObject configured to send/receive custom signal, then
    # set this value to the GObject instance.
    host: GObject or None
)

_____________________
Definition Dictionary
¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
A definition dictionary is how an AnyGroup Widget tree is defined. Definition
starts at the greatest scope definition, the AnyGroup definition, the UI seed.
The AnyGroup definition is a Container definition, so it can have
Container-branch and Widget-leaf sub-definition dict.

The goal of a definition dict is to separate data from function, to define
data in recognizable pattern, and to streamline Widget initialization
with an object-oriented approach.

__________________________
Basic Definition Structure
¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
AnyGroup definition dict (the seed)
    Container definition
    or
    Widget definition

Container definition (a branch)
    Container definition
    or
    Widget definition

Widget definition (a leaf)

___________________
AnyGroup Definition
¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
This definition is the same as a Container definition, but is distinguished
because it is the first definition, the seed, in the UI definition tree.
It's structure differs slightly from a Container definition in that
the AnyGroup definition has definition item only.

{key: definition dict, ...}

Both 'plugout.Container' and 'plugout.Widget' have further documentation.
"""


class AnyGroup:
    """
    Connect AnyGroup host with created Container and Widget while growing
    a user-interface from a AnyGroup definition dict, a seed.

    AnyGroup attribute
        An AnyGroup has two public dictionaries it creates during init.
        There is a Widget dict and a value dict:
        'AnyGroup.widget_d' and 'AnyGroup.value_d'

        The Widget dict is composed of Widget-leaf objects created during
        the AnyGroup definition tree break-out:

        {Widget key: Widget instance}

        The value dict stores Widget value in real-time. When a Widget is
        initialized or changes, the value dict is updated. Only Widget with a
        VALUE key in their Widget definition update the value dict.
        It's the Widget's responsibility to update the value dict when
        the Widget changes value.

        {Widget key: Widget value}
    """

    def __init__(
        self, def_d, container, preset_key=None, is_any_change=False, host=None
    ):
        """
        Create a user-interface inside a host-container.

        def_d: dict
            AnyGroup definition; Define the UI as a tree. From this
            seed, an interface tree grows. The dict is modified by
            AnyGroup.

        container: Container
            Place Widget inside. Is the AnyGroup's host container, the root
            of the definition tree. The Container holds the entire AnyGroup
            packaged content.

        preset_key: string or None
            Is the preset key for the AnyGroup. The AnyGroup definition can
            still have a preset configuration even if this value is None.

        is_any_change: bool
            Set to True to have the host receive
            'any-change' signal from WidgetValue.

        host: GObject or None
            AnyGroup host
            Receive 'any-change' signal from Widget. The host is the sender
            and receiver of the signal.
        """
        self.value_d = {}
        self.widget_d = {}
        self._host = host
        self._is_any_change = is_any_change
        key_path = [preset_key] if preset_key else []
        self._load_any(
            def_d, container, key_path, None, self.value_d, self.widget_d
        )

    def _load_any(self, d, container, key_path, randomer, value_d, widget_d):
        """
        Initialize the UI with either Container or Widget definition dict.

        d: dict
            definition dict

        container: Container
            Package Widget inside.

        key_path: list
            [preset key, ...]
            key path for container
            Find nested preset option group.

        randomer: Container or None
            Send RANDOMIZE signal.

        value_d: dict
            preset value
            {Widget key: Widget value}

        widget_d: dict
            preset Widget
            {Widget key: Widget instance}
        """
        # Container or Widget definition dict, 'def_d'
        for k, def_d in d.items():
            if def_d.get(CHILD):
                self._load_container(
                    def_d,
                    container,
                    key_path,
                    randomer,
                    value_d,
                    widget_d
                )
            else:
                self._load_widget(
                    k,
                    def_d,
                    container,
                    key_path,
                    randomer,
                    value_d,
                    widget_d
                )

    def _load_container(
        self, def_d, container, key_path, randomer, value_d, widget_d
    ):
        """
        Load a Container with Widget.

        def_d: dict
            Container definition

        container: Container
            Receive Widget.

        key_path: list
            [preset key, ...]
            Maintain preset-path-key for the definition tree.
            Find nested preset option group.

        randomer: Container or None
            Send RANDOMIZE signal.

        value_d: dict
            preset value
            {Widget key: Widget value}

        widget_d: dict
            preset Widget
            {Widget key: Widget instance}
        """
        k = def_d.get(PRESET)

        if k is not None:
            # Create a new list for this branch.
            key_path = key_path + [k]

            # Create a nested preset dict.
            value_d[k] = {}
            value_d = value_d[k]
            widget_d[k] = {}
            widget_d = widget_d[k]

        def_d[HOST] = self._host
        a = def_d.get(TYPE)

        if a is None:
            missing_type_item = MISSING_TYPE_ERROR.format(CONTAINER, def_d)
            raise AttributeError(missing_type_item)

        g = a(def_d)

        if def_d.get(RANDOMER):
            # the branch's randomize signal sender, 'g'
            randomer = g

        self._load_any(
            def_d[CHILD], g, key_path, randomer, value_d, widget_d
        )
        container.add(g)

    def _load_widget(
        self, k, def_d, container, key_path, randomer, value_d, widget_d
    ):
        """
        Create a Widget-leaf.

        k: string
            Identify the Widget in the preset.

        def_d: dict
            Widget definition

        container: Container
            Receive Widget.

        key_path: list
            [preset key, ...]
            Maintain preset-path-key for the definition tree.
            Find nested preset option group.

        randomer: Container or None
            Send RANDOMIZE signal.

        value_d: dict
            preset value
            {Widget key: Widget value}

        widget_d: dict
            preset Widget
            {Widget key: Widget instance}
        """
        def_d[HOST] = self._host
        def_d[KEY] = k
        def_d[KEY_PATH] = key_path
        def_d[RANDOMER] = randomer
        def_d[VALUE_D] = value_d
        def_d[WIDGET_D] = widget_d
        def_d[IS_ANY_CHANGE] = self._is_any_change
        a = def_d.get(TYPE)

        if a is None:
            missing_type_item = MISSING_TYPE_ERROR.format(k, def_d)
            raise AttributeError(missing_type_item)

        g = widget_d[k] = a(def_d)
        container.add(g)
