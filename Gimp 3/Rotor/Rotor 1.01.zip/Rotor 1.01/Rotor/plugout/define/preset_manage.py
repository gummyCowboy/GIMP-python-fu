#!/usr/bin/env python3
from plugout.constant import AVAILABLE_PRESET, DEFAULT, LOAD_FAIL
from plugout.container.box import VBox
from plugout.define.key import (
    CHILD, GET_LIST, MARKUP, PADDING, SCROLLED_WINDOW, TEXT, TYPE
)
from plugout.preset import Preset
from plugout.widget.label import Label
from plugout.widget.listbox import ListBoxPreset
import glob
import os
import gi                            # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp       # noqa

"""Define an AnyGroup definition dict for DialogPresetManage."""


def collect_preset():
    """
    Collect Preset in a list.

    Return: list
        Preset name list
    """
    # list of preset, 'q'
    q = [DEFAULT]
    is_success = False

    try:
        n = f"{Preset.active_path}*.json"

        # Ignore sub-directory.
        file_q = glob.glob(n)
        is_success = True

    except Exception:
        Gimp.message(LOAD_FAIL)

    if is_success:
        # Get the file name without the extension.
        for n in file_q:
            q.append(os.path.splitext(os.path.basename(n))[0])
    return q


AVAILABLE_LABEL = {
    MARKUP: ('b', 'big'),
    PADDING: (8, 0, 0, 0),
    TEXT: AVAILABLE_PRESET,
    TYPE: Label
}
PRESET_LIST = {
    GET_LIST: collect_preset,
    PADDING: (0, 0, 10, 10),
    SCROLLED_WINDOW: (360, 360),
    TYPE: ListBoxPreset
}

# AnyGroup definition dict, 'DEF_MANAGE'
DEF_MANAGE = {
    'g': {
        CHILD: {
            '0': AVAILABLE_LABEL,
            'preset list': PRESET_LIST
        },
        TYPE: VBox
    }
}
