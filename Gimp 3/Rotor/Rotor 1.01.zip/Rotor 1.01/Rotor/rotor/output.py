#!/usr/bin/env python3
from math import ceil, sqrt
from rotor.constant import NORMAL, RADIAN_180, RADIAN_360
from rotor.pdb import Autocrop, Copy, Paste
import gi                              # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp         # noqa

"""Include rotor output class."""


def calc_diagonal(w, h):
    """
    Calculate the diagonal of a rectangle.

    Return: float
        Is the length of the rectangle's diagonal and is
        rounded up to the nearest integer.
    """
    return ceil(sqrt(w**2. + h**2.))


def copy_layer(j, z):
    """
    Copy a Gimp.Layer.

    j: Gimp.Image
        Has a visible projection.

    z: Gimp.Item
        Could be a Gimp.Layer, Gimp.GroupLayer, or a Gimp.LayerMask.

    Return: Gimp internal edit-buffer state
    """
    mode = z.get_mode()
    opacity = z.get_opacity()

    z.set_visible(True)
    z.set_mode(NORMAL)
    z.set_opacity(100.)
    Copy.do((('image', j),))
    z.set_visible(False)
    z.set_mode(mode)
    z.set_opacity(opacity)


def add_layer(j, parent=None, position=0, layer_name="Base"):
    """
    Add a layer to an image.

    j: Gimp.Image
        Receive layer.

    parent: Image.GroupLayer or None
        Put layer in a group.

    position: int
        Is the offset from the top of the parent.

    layer_name: string
        Give the layer a name.

    Return: layer
        newly created
    """
    z = Gimp.Layer.new(
        j,
        layer_name,
        j.get_width(),
        j.get_height(),
        Gimp.ImageType.RGBA_IMAGE,
        100,
        Gimp.LayerMode.NORMAL
    )

    j.insert_layer(z, parent, position)
    return z


def get_layer_from_group(z, q):
    """
    Gather layer from a 'Gimp.GroupLayer'.

    z: Gimp.GroupLayer
    q: list
        [Gimp.Layer, ...]
    """
    for z1 in z.get_children():
        if Gimp.Item.id_is_group_layer(z1.get_id()):
            get_layer_from_group(z1, q)
        else:
            q.append(z1)


def get_layer_from_image(j, q):
    """
    Gather layer from a 'Gimp.Image'.

    j: Gimp.Image
    q: list
        [Gimp.Layer, ...]
    """
    for z in j.get_layers():
        if Gimp.Item.id_is_group_layer(z.get_id()):
            get_layer_from_group(z, q)
        else:
            q.append(z)


def hide_group_layer(z, q):
    """
    Hide grouped layer in an image.

    z: Gimp.Image or Gimp.LayerGroup
    q: list
        [hidden Gimp.Layer, ...]
    """
    for z1 in z.get_children():
        if Gimp.Item.id_is_group_layer(z1.get_id()):
            # recursive:
            hide_group_layer(z1, q)
        else:
            if z1.get_visible():
                z1.set_visible(False)
                q.append(z1)


def hide_image_layer(j, q):
    """
    Hide all layer in an image.

    j: Gimp.Image
    q: list
        [hidden Gimp.Layer, ...]
    """
    for z in j.get_layers():
        if Gimp.Item.id_is_group_layer(z.get_id()):
            # recursive:
            hide_group_layer(z, q)
        else:
            if z.get_visible():
                z.set_visible(False)
                q.append(z)


def show_image_layer(q):
    """
    Show layer given a list of layer.

    q: list
        [Gimp.Layer, ...]
    """
    for z in q:
        z.set_visible(True)


class Output:
    """
    Create a new image with the same size as the input image. Copy and
    transform the copied layer using two skew points.

    There are four total skew points. DialogMain's Topleft and Bottom-Left
    points have calculated layer-centric symmetrical points.

    The four points define a skew polygon which is passed to a Gimp transform
    function with each copied layer producing output image layer.
    """

    def __init__(self, image, drawables):
        """
        image: Gimp.Image
            Each layer in the image is copied, transformed,
            and stacked in an output image.
        """
        self._input_image = image
        self._input_layers = drawables
        self._output_images = []
        w, h = self._input_image.get_width(), self._input_image.get_height()

        if w == h:
            self._is_autocrop = False
            self._output_w = w

        else:
            self._is_autocrop = True
            self._output_w = calc_diagonal(w, h)

        # DialogMain
        self._timer = self._direction = self._frame_count = None

    def _clear_output_image(self):
        for q in self._output_images:
            j, display = q
            display.delete()
        self._output_images = []

    def _create_image(self):
        """
        Create a square-sized image for layer rotating and stacking.

        Return: Gimp.Image
            newly created
        """
        # If the layer is a group  layer, then the it needs to be made
        # visible and then copied.
        j = Gimp.Image.new(
            self._output_w, self._output_w, Gimp.ImageBaseType.RGB
        )
        display = Gimp.Display.new(j)

        self._output_images.append((j, display))
        add_layer(j)
        return j

    def _give_name(self, z, i):
        """
        Give a rotor layer a GIF style layer name.

        z: Gimp.Layer
            Rename.

        i: int
            Is the frame number.
        """
        z.set_name(f"{i} {self._timer}ms")

    def _rotate_layer(self):
        """
        For each selected input layer, make a visible copy,
        create a new image, and produce a rotated layer stack.
        """
        for z in reversed(self._input_layers):
            j = self._create_image()

            copy_layer(self._input_image, z)
            base_layer = Paste.do(j)

            # Remove the old base layer.
            j.remove_layer(j.get_layers()[-1])

            self._give_name(base_layer, 1)

            angle = progress = RADIAN_360 / self._frame_count * (1, -1)[
                self._direction
            ]

            for i in range(self._frame_count - 1):
                dupe = base_layer.copy()

                # Insert layer at top of the image.
                j.insert_layer(dupe, None, 0)

                # Keep angle in GIMP rotation bounds.
                if progress > RADIAN_180:
                    progress = -RADIAN_360 + progress

                elif progress < -RADIAN_180:
                    progress = RADIAN_360 + progress

                self._give_name(dupe, i + 2)
                dupe.transform_rotate(progress, True, 0, 0)

                progress += angle

                # The flush is critical because
                # the display can get over-extended
                # when a lot layers are created.
                Gimp.displays_flush()
            if self._is_autocrop:
                Autocrop.do(j)

    def create(self, d):
        """
        Create output image. Transform input image layer into output image.

        d: dict
            'AnyGroup.value_d'
        """
        for k, a in d.items():
            # Widget value, 'a'
            setattr(self, "_" + k, a)

        hidden_layers = []

        hide_image_layer(self._input_image, hidden_layers)
        self._clear_output_image()
        self._rotate_layer()
        show_image_layer(hidden_layers)
        Gimp.displays_flush()
