#!/usr/bin/env python3
from plugout.constant import MANAGE, SAVE_
from plugout.container.box import HBox
from plugout.container.grid import Grid, GridCell, GridRow
from plugout.define.key import (
    ADJUSTMENT, CHILD, COLUMN, COLUMNS,
    HALIGN, PADDING, PRESET, TEXT,
    TOOLTIP, TYPE, VALUE, WIDTH
)
from plugout.widget.button_preset import ButtonManage, ButtonSave
from plugout.widget.h_sep import HSeparator
from plugout.widget.hint import Hint
from plugout.widget.label import Label, LabelPreset
from plugout.widget.radio import RadioGroup
from plugout.widget.spinbutton import SpinButton
from rotor.constant import (
    CLOCKWISE, COUNTER_CLOCKWISE,
    DIRECTION, FRAME_COUNT,
    HINT_TEXT, TIMER, TIMER_TIP
)
import gi                           # type: ignore
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk       # noqa

"""Define the DialogMain's content using AnyGroup definition dict."""


# Direction____________________________________________________________________
DIRECTION_LABEL = {HALIGN: Gtk.Align.START, TEXT: DIRECTION, TYPE: Label}
RADIO_GROUP_DIRECTION = {
    TEXT: (CLOCKWISE, COUNTER_CLOCKWISE),
    TYPE: RadioGroup,
    VALUE: 0
}
GRID_CELL_DIRECTION_0 = {
    CHILD: {'flip_label': DIRECTION_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_DIRECTION_1 = {
    CHILD: {'direction': RADIO_GROUP_DIRECTION},
    WIDTH: 2,
    COLUMN: 1,
    TYPE: GridCell
}

# Frame Count__________________________________________________________________
FRAME_COUNT_LABEL = {
    HALIGN: Gtk.Align.START,
    TEXT: FRAME_COUNT,
    TYPE: Label
}
FRAME_COUNT_SPIN = {
    ADJUSTMENT: (0., 1., 999., 1., 2., 0.),
    TYPE: SpinButton,
    VALUE: 12.
}
GRID_CELL_FRAME_COUNT_0 = {
    CHILD: {'frame_label': FRAME_COUNT_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_FRAME_COUNT_1 = {
    CHILD: {'frame_count': FRAME_COUNT_SPIN}, COLUMN: 1, TYPE: GridCell
}

# Hint_________________________________________________________________________
ROTOR_HINT = {TEXT: HINT_TEXT, TYPE: Hint}
GRID_CELL_HINT_0 = {
    CHILD: {'hint': ROTOR_HINT}, COLUMN: 0, WIDTH: 2, TYPE: GridCell
}

# Timer________________________________________________________________________
TIMER_LABEL = {TEXT: TIMER, HALIGN: Gtk.Align.START, TYPE: Label}
TIMER_SPIN = {
    ADJUSTMENT: (1., 1., 9999., 1., 10., 0.),
    TOOLTIP: TIMER_TIP,
    TYPE: SpinButton,
    VALUE: 100.
}
GRID_CELL_TIMER_0 = {
    CHILD: {'timer_label': TIMER_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_TIMER_1 = {CHILD: {'timer': TIMER_SPIN}, COLUMN: 1, TYPE: GridCell}

# Preset_______________________________________________________________________
PRESET_LABEL = {HALIGN: Gtk.Align.START, TYPE: LabelPreset}
MANAGE_BUTTON = {TEXT: MANAGE, TYPE: ButtonManage}
SAVE_BUTTON = {PADDING: (0, 0, 0, 4), TEXT: SAVE_, TYPE: ButtonSave}
HBOX_PRESET_BUTTON = {
    CHILD: {'save_button': SAVE_BUTTON, 'manage_button': MANAGE_BUTTON},
    TYPE: HBox
}
GRID_CELL_PRESET_0 = {
    CHILD: {'preset_label': PRESET_LABEL}, COLUMN: 0, TYPE: GridCell
}
GRID_CELL_PRESET_1 = {
    CHILD: {1: HBOX_PRESET_BUTTON},
    COLUMN: 1,
    WIDTH: 2,
    TYPE: GridCell
}
GRID_ROW_PRESET = {
    CHILD: {1: GRID_CELL_PRESET_0, 2: GRID_CELL_PRESET_1},
    COLUMNS: 2,
    TYPE: GridRow
}

# Separator____________________________________________________________________
HSEPARATOR = {PADDING: (4, 4, 0, 0), TYPE: HSeparator}
GRID_CELL_HSEPARATOR = {
    CHILD: {'separator': HSEPARATOR}, COLUMN: 0, WIDTH: 2, TYPE: GridCell
}
GRID_ROW_SEPARATOR = {
    CHILD: {1: GRID_CELL_HSEPARATOR}, COLUMNS: 2, TYPE: GridRow
}

# Main_________________________________________________________________________
# AnyGroup definition: {key: definition}
DEFINE_MAIN = {
    1: {
        CHILD: {
            'hint': {CHILD: {1: GRID_CELL_HINT_0}, COLUMNS: 2, TYPE: GridRow},
            'frame_count': {
                CHILD: {
                    1: GRID_CELL_FRAME_COUNT_0, 2: GRID_CELL_FRAME_COUNT_1
                },
                COLUMNS: 2,
                TYPE: GridRow
            },
            'timer': {
                CHILD: {1: GRID_CELL_TIMER_0, 2: GRID_CELL_TIMER_1},
                COLUMNS: 2,
                TYPE: GridRow
            },
            'direction': {
                CHILD: {1: GRID_CELL_DIRECTION_0, 2: GRID_CELL_DIRECTION_1},
                COLUMNS: 2,
                TYPE: GridRow
            },
            'sep': GRID_ROW_SEPARATOR,
            'preset': GRID_ROW_PRESET
        },

        # Start a preset, but don't give it a key since there are no
        # sub-preset. If there were sub-preset, then a key would
        # give this preset a Preset sub-folder: '.../Preset/key/'.
        PRESET: None,

        TYPE: Grid
    }
}
