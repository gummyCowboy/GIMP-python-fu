#!/usr/bin/env python3
from rotor.constant import REPLACE
import gi                              # type: ignore
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp         # noqa

"""
Include a function to initialize static pdb
run class, and static pdb run class.

The static class' config object is reused. So configuring a
pdb procedure has an additional dynamic in that the previous
call to 'class.do' can be repeated, but without the configuration
settings.
"""


def init_pdb():
    """Implement a get-once strategy for Gimp's pdb interface. """
    for q in (
        (Autocrop, 'gimp-image-crop'),
        (Copy, 'gimp-edit-copy-visible'),
        (Paste, 'gimp-edit-paste')
    ):
        a, n = q
        a.pdb = Gimp.get_pdb().lookup_procedure(n)
        a.config = a.pdb.create_config()


class Autocrop:
    pdb = config = None

    def do(j):
        """
        Autocrop an image removing excess border space.
        This function removes an existing 'Gimp.Selection'.

        j: Gimp.Image
            WIP
        """
        Autocrop.config.set_property('image', j)
        Gimp.Selection.none(j)

        offset_x = offset_y = 99999999.
        max_x = max_y = 0.

        # Get min and max bounds of the image.
        for z in j.get_layers():
            j.select_item(REPLACE, z)
            non_empty, x, y, x1, y1 = Gimp.Selection.bounds(j)[1:]
            if non_empty:
                if x < offset_x:
                    offset_x = x

                if y < offset_y:
                    offset_y = y

                if x1 > max_x:
                    max_x = x1
                if y1 > max_y:
                    max_y = y1
        q = {
            ('new-width', max_x - offset_x),
            ('new-height', max_y - offset_y),
            ('offx', offset_x),
            ('offy', offset_y)
        }

        for q1 in q:
            Autocrop.config.set_property(*q1)

        Autocrop.pdb.run(Autocrop.config)
        Gimp.Selection.none(j)


class Copy:
    pdb = config = None

    def do(q):
        """
        Copy an image's visible projection into the Gimp internal buffer.

        q: tuple
            Configure the procedure.
            (
                ('image', Gimp.Image),
            )

        Return: Gimp edit buffer
        """
        for q1 in q:
            Copy.config.set_property(*q1)
        Copy.pdb.run(Copy.config)


class Paste:
    pdb = config = None

    def do(j):
        """
        Paste a layer onto the top of an image.
        The image is assumed to a have at least one layer.

        j: Gimp.Image
            Receive pasted layer.

        Return: Gimp.Layer
            Is on top of the image.
        """
        z = j.get_layers()[0]

        for q in (('drawable', z), ('paste-into', True)):
            Paste.config.set_property(*q)

        # 'gobject.GBoxed' throws an error in RC1 on
        # print, so the result is useless here.
        Paste.pdb.run(Paste.config)

        z = j.get_layers()[0]

        Gimp.floating_sel_to_layer(z)
        return z
