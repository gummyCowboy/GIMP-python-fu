#!/usr/bin/env python3
from gi.repository import Gegl

"""Contain Gegl.Color auxiliary operations."""


def convert_gegl_color_to_int(color):
    """
    Convert Gdk.Color into RGBA value.

    color: Gdk.Color
    Return: list
        RGBA
        [0..255, 0..255, 0..255, 0..255]
    """
    return [int(a * 255) for a in color.get_rgba()]


def convert_float_to_gegl_color(rgba_f):
    """
    Convert an iterable of floating point value representing an
    RGBA value into a Gegl.Color.

    rgba_f: iterable
        [float, float, float, float] in a RGBA sequence

    Return: Gegl.Color
        Represent the given color.
    """
    return Gegl.Color.new('rgba(%f,%f,%f,%f)' % tuple(rgba_f))
