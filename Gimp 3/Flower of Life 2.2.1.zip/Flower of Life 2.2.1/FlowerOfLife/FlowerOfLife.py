#!/usr/bin/env python3
from life.constant import PLUGIN_BLURB, PLUGIN_TOOLTIP, PROCEDURE_NAME
from life.window_main import WindowMain
from life.pdb import init_pdb
from plugout.constant import GIMP_PYTHON
import gi                                   # type: ignore
import os
import sys
import time
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GimpUi, GLib       # noqa

error_file = None

if os.environ.get('gummy_cowboy', False):
    error_file = sys.stdout = sys.stderr = open("D:\\error.txt", 'a')
    _start = f"\nFlower of Life, {time.ctime()}"
    _end = "_" * (80 - len(_start))
    print(f"{_start}{_end}")


class FlowerOfLife(Gimp.PlugIn):
    """Initialize the plug-in with GIMP 3."""

    def do_query_procedures(self):
        return [PROCEDURE_NAME]

    def do_set_i18n(self, name):
        # Support language translation.
        return True, GIMP_PYTHON, None

    def do_create_procedure(self, name):
        """
        Define plug-in so that it can be run.

        name: string
            Is the name of the plug-in and is sourced from PROC_NAME.
        """
        # run data, 'None
        procedure = Gimp.ImageProcedure.new(
            self, name, Gimp.PDBProcType.PLUGIN, self.run, None
        )
        # no image required
        procedure.set_sensitivity_mask(Gimp.ProcedureSensitivityMask.ALWAYS)

        procedure.set_menu_label("Flo_wer of Life…")
        procedure.add_menu_path('<Image>/Filters/Render/')
        procedure.set_documentation(PLUGIN_TOOLTIP, PLUGIN_BLURB, name)
        procedure.set_attribution("Charles Bartley", "Charles Bartley", "2025")
        return procedure

    def run(self, procedure, run_mode, *_):
        """
        Produce layer output.

        procedure: Gimp.ImageProcedure
            Manage plug-in.

        _: tuple
            run_mode: enum
                Gimp.RunMode

            image: GIMP image
                the active image

            drawables: list
                active drawable
                [drawable, ...]

            args: Gimp.ValueArray
                How is this used?
                Has a length() function that could be useful.

            run_data: value
                Relayed from the 'do_create_procedure'.
        """
        # Check run mode. If interactive create
        # dialog, otherwise use previous settings.
        if run_mode == Gimp.RunMode.INTERACTIVE:
            GimpUi.init(PROCEDURE_NAME)
            Gimp.context_push()
            Gimp.context_set_antialias(True)
            Gimp.context_set_feather(False)
            init_pdb()
            WindowMain()
            Gimp.context_pop()

        else:
            # Use previous settings.
            # This is dependent on the shelf which is a GIMP team WIP.
            pass

        if error_file:
            error_file.close()
        return procedure.new_return_values(
            Gimp.PDBStatusType.SUCCESS, GLib.Error()
        )


Gimp.main(FlowerOfLife.__gtype__, sys.argv)
