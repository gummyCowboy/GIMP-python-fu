#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import ImageEffect
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb
FEATHER = ek.FEATHER_REDUCTION


class FeatherReduction:
    """Feather the edges of the combined images on the image layer."""

    def __init__(self, one):
        """
        Do the Feather Reduction effect.

        one: One
            Has variables.
        """
        stat = one.stat
        j = stat.render.image
        z = stat.render.get_image_layer(
            Lay.get_format_name_from_group(one.parent)
        )
        z = Lay.clone(j, z)
        z.name = Lay.get_layer_name(FEATHER, parent=z.parent)

        Lay.show(z)
        FeatherReduction.do(j, z, one.d)

    @staticmethod
    def do(j, z, d):
        """
        Feather material with linear growth repeating steps.

        j: GIMP image
            work-in-progress

        z: layer
            Has material to feather.

        d: dict
            Has feather options.
        """
        if z:
            a = d[ok.FEATHER]
            f = float(a) / d[ok.STEPS]
            b = f

            Sel.item(j, z)
            Sel.invert(j)
            RenderHub.expand_image(j)

            while a > b:
                Sel.item(j, z)
                pdb.gimp_selection_feather(j, b)

                if Sel.is_sel(j):
                    Sel.clear_outside_of_selection(j, z)

                else:
                    break
                b = min(b + f, a)
            RenderHub.contract_image(j)
