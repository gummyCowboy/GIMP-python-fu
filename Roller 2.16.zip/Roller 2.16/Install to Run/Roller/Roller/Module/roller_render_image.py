#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerKey
from roller_one_base import Comm
from roller_one_constant import ForLayout, ForStep, SessionKey as sk
from roller_one_fu import Lay
import gimpfu as fu

pdb = fu.pdb


class RenderImage(object):
    """
    Use to create and change the render image.

    Use to manage layout and format groups.

    Use to manage backdrop layer.
    """
    _size = 50, 50

    def __init__(self, stat):
        """
        Init for a new render image.

        stat: Stat
            globals
        """
        self.stat = stat
        self._init()

    def _del_layout(self):
        """Delete any layout format groups."""
        z = self._layout_group
        if z:
            self._layout_group = self._layout_background = None
            self.has_layout_group = False

            pdb.gimp_image_remove_layer(self._image, z)
            pdb.gimp_displays_flush()

    def _init(self):
        """
        Call when an image is defined or its size has changed.
        """
        self._image = self._layout_group = self._layout_background = None
        self.has_image = self.has_layout_group = False
        self._backdrop = None

        # Use with render View to remember preview steps:
        self.preview_steps = []

        self._init_format()

    def _init_format(self):
        """
        Call to initialize format settings.

        Call when deleting formats.
        """
        self._format_group_dict = {}
        self._image_dict = {}
        self.has_format = False

        # Use with render View:
        if self.preview_steps:
            q = []
            d = self.stat.option_group_dict

            # Save the backdrop-style:
            for i in self.preview_steps:
                if i[ForStep.OPTION_TYPE_INDEX] == sk.BACKDROP:
                    q.append(i)

                else:
                    # Are option groups not previewed by render View:
                    d[i].changed = True
            self.preview_steps = q

    @property
    def backdrop(self, n=""):
        """
        Return the backdrop layer. If there isn't one, then create it.

        n: string
            from backdrop style
            Is the layer name.
            Use when creating the backdrop layer.
        """
        if self._backdrop:
            return self._backdrop

        image = self.image
        n = Lay.get_layer_name(n)
        self._backdrop = Lay.add(image, n, offset=len(image.layers))
        return self._backdrop

    @backdrop.setter
    def backdrop(self, *_):
        """The backdrop layer property is read-only."""
        raise RenderImage.WriteError('backdrop')

    def consume_image_group(self, k, group):
        """
        With an image layer group, merge,
        and remember the resulting image layer.

        k: string
            format group name

        group: layer
            Has image layers.
        """
        self._image_dict[k] = Lay.merge_group(
            self._image,
            group,
            n=Lay.get_layer_name(LayerKey.IMAGE, parent=group.parent)
        )

    def del_backdrop(self):
        """Delete the backdrop layer and reset its reference."""
        if self._backdrop:
            pdb.gimp_image_remove_layer(self._image, self._backdrop)
            pdb.gimp_displays_flush()

        d = self.stat.option_group_dict

        for i in self.preview_steps:
            d[i].changed = True

        self.preview_steps = []
        self._backdrop = None

    def del_formats(self, del_bg=True):
        """
        Delete any format groups and the backdrop-light layer.

        del_bg: flag
            If it's true, then delete the backdrop layer.
        """
        if self._image:
            d = self._format_group_dict

            for i in d:
                pdb.gimp_image_remove_layer(self._image, d[i][0])

            if del_bg:
                self.del_backdrop()

            self._init_format()
            self._del_layout()

            z = Lay.search(self._image, LayerKey.BACKDROP_LIGHT, is_err=0)

            if z:
                pdb.gimp_image_remove_layer(self._image, z)
            pdb.gimp_displays_flush()
            self.stat.del_format_sel()

    def del_image_layer(self, k):
        """
        Delete a format's image layer.

        k: string
            format name
        """
        z = self.get_image_layer(k)
        if z:
            pdb.gimp_image_remove_layer(self._image, z)
            self._image_dict.pop(k)

    def del_layout_background(self):
        """Delete the layout background layer."""
        z = self._layout_background
        if z:
            pdb.gimp_image_remove_layer(self._image, z)
            pdb.gimp_displays_flush()
            self._layout_background = None

    def format_group(self, x, n):
        """
        Return a format group. If it doesn't exist, then create one.

        x: int
            index to a format group in 'self._format_list'
            If 'x' is set to None, then the format is assumed
            to have been already created.

        Return: layer or None
            format group
        """
        d = self._format_group_dict

        if n in d:
            group, x = d[n]
            return group

        # The group was not found:
        if x is None:
            return None

        # The format group name is a key:
        n1 = LayerKey.FORMAT + n
        a = int(self.has_layout_group)
        image = self.image
        z = Lay.group(image, n1, offset=a)
        d[n] = z, x
        self.has_format = True
        return z

    def is_format_group(self, n):
        """
        Determine if a name is a format name.

        n: string
            layer name

        Return: flag
            Is true if the name is a format group name.
        """
        return True if n in self._format_group_dict else False

    @property
    def layout_background(self):
        """
        Get the layout background. If it doesn't exist, then create one first.

        Return: layer
            layout background
        """
        if self._layout_background:
            return self._layout_background

        else:
            image = self.image
            z = self._layout_background = Lay.add(
                image,
                "Layout Background"
            )

            Lay.color_fill(z, ForLayout.BACKGROUND_COLOR)
            return z

    @layout_background.setter
    def layout_background(self, *_):
        """The layout background is self-managed."""
        raise RenderImage.WriteError('image')

    @property
    def layout_group(self):
        """
        Get the layout group. If it doesn't exist, then create one first.

        Return: layer
            layout group
        """
        if self._layout_group:
            return self._layout_group

        else:
            z = self.layout_background
            image = self.image
            n = Lay.get_layer_name("Layout")
            z1 = self._layout_group = Lay.group(image, n)
            self.has_layout_group = True

            pdb.gimp_image_reorder_item(image, z, z1, 0)
            return z1

    @layout_group.setter
    def layout_group(self, *_):
        """The layout background is read-only."""
        raise RenderImage.WriteError('image')

    @property
    def image(self):
        """
        Get the render image. If it doesn't exist, then create one first.

        Return: GIMP image
            for render
        """
        if self._image:
            return self._image

        else:
            j = self._image = pdb.gimp_image_new(
                RenderImage._size[0],
                RenderImage._size[1],
                fu.RGB
            )

            # Show in GIMP:
            self._display = pdb.gimp_display_new(j)

            # Turn on undo functionality:
            pdb.gimp_image_undo_group_start(j)

            self.has_image = True
            return j

    @image.setter
    def image(self, *_):
        """The image property is read-only."""
        raise RenderImage.WriteError('image')

    def get_image_layer(self, k):
        """
        Get the image layer of a given format.

        k: string
            key in 'self._image_dict'
            name of format

        Return: layer or None
            image layer
        """
        return self._image_dict[k] if k in self._image_dict else None

    def on_new_layout(self):
        """
        The layout group has been replaced with a new group.
        So, remove the old one.
        """
        z = self._layout_group
        if z:
            self._del_layout()

    def replace_backdrop(self, z, n):
        """
        Replace the backdrop layer with another layer.

        z: layer
            to replace backdrop layer with

        n: string
            name to give to backdrop layer
        """
        pdb.gimp_image_remove_layer(self.image, self._backdrop)

        self._backdrop = z
        z.name = Lay.get_layer_name(n) + ": Working."

    @property
    def size(self):
        """Return the size of the render."""
        return RenderImage._size

    @size.setter
    def size(self, size):
        """
        Call to set the render image size.

        If the image size has changed, the image is deleted.

        size: tuple
            of int
            width, height
        """
        if size != RenderImage._size:
            RenderImage._size = size
            image = self._image

            self._init()
            if image:
                pdb.gimp_display_delete(self._display)
                self._display = None

    class WriteError(Exception):
        """
        Use when a function attempts to write to a read-only property.
        """
        def __init__(self, n):
            """
            There was an write error.

            Spit out the variable name.

            n: string
                function name
            """
            self.value = "StatWriteError: Attempted to write to a read-only " \
                "property: RenderImage.{}.".format(n)
            Comm.info_msg(self.value)

        def __str__(self):
            """
            Return the string value of the error message.

            This an Exception template function.
            """
            return repr(self.value)
