#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerKey
from roller_one_constant import ForLayer, OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_one_constant_fu import Fu
from roller_render_hub import RenderHub
import gimpfu as fu

ed = Fu.Edge
pdb = fu.pdb


class ClearFrame:
    """Create a translucent border around an image(s)."""

    def __init__(self, one):
        """
        Do the Clear Frame image-effect.

        one: One
            Has variables.
        """
        stat = one.stat
        j = stat.render.image
        frame = [0, 0]
        n = one.k
        d = one.d
        parent = one.parent
        q = ClearFrame._edge_color(d[ok.COLOR])
        group = Lay.group(j, n, parent=parent)
        select_layer = Lay.selectable(
            j,
            stat.render.get_image_layer(
                Lay.get_format_name_from_group(parent)
            ),
            ForLayer.MAKE_OPAQUE_DICT
        )

        # Creates two layers:
        for x in range(2):
            Sel.item(j, select_layer)
            Sel.grow(
                j,
                (d[ok.FRAME_WIDTH] + 5, 5)[x],
                d[ok.FRAME_TYPE]
            )

            z = Lay.add(j, n, parent=group)

            Sel.fill(z, d[ok.COLOR])
            Sel.item(j, select_layer)
            Lay.clear_sel(j, z)
            frame[x] = ClearFrame._do_edge(j, z, q)

        pdb.gimp_image_remove_layer(j, select_layer)

        # Create frame selection to remove shadow bleed:
        Sel.item(j, frame[0])
        Sel.item(j, frame[1], option=fu.CHANNEL_OP_ADD)

        sel = stat.save_render_sel()

        # Add shadow and merge:
        z = RenderHub.do_shadow(stat, frame[1], 0, 0, 5, (0, 0, 0), 100)

        pdb.gimp_image_reorder_item(j, z, group, 1)

        z.mode = fu.LAYER_MODE_NORMAL
        frame[0].opacity = 55.
        frame[1].mode = fu.LAYER_MODE_OVERLAY
        z = Lay.merge_group(
            j,
            group,
            n=Lay.get_layer_name(LayerKey.TRANSPARENCY, parent=parent)
        )
        z.opacity = 33.

        Sel.load(j, sel)
        Sel.clear_outside_of_selection(j, z)

    @staticmethod
    def _do_edge(j, z, q):
        """
        Use to create an overlay edge effect
        where the light source is directly above
        the subject.

        j: GIMP image
            work-in-progress

        z: layer
            The layer that is on top.

        q: tuple
            background color (RGB)
            The background color needs to differ from the subject.
            It is used to turn transparent pixels into opaque pixels.

        Return: layer
            the layer with the edge
        """
        z1 = Lay.clone(j, z)
        z2 = Lay.add(
            j,
            z.name,
            parent=z.parent,
            offset=pdb.gimp_image_get_item_position(j, z)
        )

        Lay.color_fill(z2, q)

        z1 = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

        pdb.plug_in_edge(j, z1, ed.AMOUNT_1, ed.NO_WRAP, ed.SOBEL)
        Sel.item(j, z)
        Sel.clear_outside_of_selection(j, z1)

        z1.mode = fu.LAYER_MODE_LIGHTEN_ONLY
        return pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

    @staticmethod
    def _edge_color(q):
        """
        Return an edge color for a color.

        q: tuple
            (red, green, blue)
            of int
            color
        """
        q1 = [0, 0, 0]

        for x, a in enumerate(q):
            q1[x] = 0 if a > 127 else 255
        return tuple(q1)
