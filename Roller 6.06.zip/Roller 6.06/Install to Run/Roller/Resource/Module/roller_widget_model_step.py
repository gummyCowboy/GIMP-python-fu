#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color as co, Signal as si, Widget as fw
from roller_constant_key import Group as gk, Widget as wk
from roller_one_shelf import Shelf
from roller_one_tip import Tip
from roller_widget import set_widget_attr
from roller_widget_button import Button
from roller_widget_label import Label
from roller_widget_tree import get_treeview_item, TreeViewList
import gtk  # type: ignore

MODEL_GROUP = (
    gk.BORDER,
    gk.CAPTION,
    gk.FRINGE,
    gk.IMAGE,
    gk.LINE,
    gk.MARGIN,
    gk.PLAQUE,
    gk.RECTANGLE,
    gk.SHIFT,
    gk.TYPE
)
NO_SHOW = (
    "/Cell/Rectangle", "/Cell/Type", "/Property", "/Preset", "/Canvas/Shift"
)


def convert_to_string(q):
    """
    Convert a list of step key to TreeView compatible string.

    q: list
        of step key
        tuple
        ('item', ...)

    Return: list
        [string, ...]
    """
    path_q = set()

    for i in q:
        n = ""

        # Developer: The branch may have a path with None?
        if i:
            if i[0] is not None:
                for x, i1 in enumerate(i):
                    if x + 1 < len(i):
                        n += i1 + "/"
                    else:
                        n += i1
                path_q.update({n})
    return path_q


class ModelStep(gtk.Alignment, object):
    """
    Compose the user interface with a Model step filter. A Model step can
    be shelved, hidden from the interface, or included in navigation tree.
    """

    def __init__(self, model_list, branch_q, **d):
        """
        model_list: ModelList
            Has Model.

        branch_q: list
            [Model branch, ...]

        d: dict
            Has option.
        """
        super(gtk.Alignment, self).__init__()
        set_widget_attr(self, d)

        self.relay = d[wk.RELAY]
        self._model_list = model_list
        self._branch_q = branch_q
        hbox = gtk.HBox()

        hbox.add(gtk.Label("\n" * 22))

        w = fw.MARGIN
        d[wk.SCROLL] = 1
        d[wk.PADDING] = w, w, w, w
        d[wk.TREE_COLOR] = d[wk.COLOR]
        d[wk.COLOR] = co.LIST_CELL_COLOR
        d[wk.MINIMUM_W] = 100

        self._draw_shelf_tree(hbox, **d)
        self._draw_move_button(hbox, **d)
        self._draw_nav_tree(hbox, **d)
        self.add(hbox)
        self._init_list()

        # Trigger a change signal.
        self._shelf_tree.select_item(0)

        self._verify_buttons()

    def _draw_move_button(self, hbox, **d):
        """
        Draw a list for selected Model item.

        hbox: GTK HBox
            Contain the list.

        d: dict
            Initialize the list.
        """
        vbox = gtk.VBox()
        d[wk.TEXT] = gtk.Arrow(gtk.ARROW_LEFT, gtk.SHADOW_NONE)
        d[wk.TOOLTIP] = Tip.MOVE_LEFT
        d[wk.RELAY] = self.relay[:] + [self.on_move_left_action]
        self.move_left = Button(**d)
        d[wk.TEXT] = gtk.Arrow(gtk.ARROW_RIGHT, gtk.SHADOW_NONE)
        d[wk.TOOLTIP] = Tip.MOVE_RIGHT
        d[wk.RELAY] = self.relay[:] + [self.on_move_right_action]
        self.move_right = Button(**d)

        vbox.pack_start(Label(**{wk.TEXT: " "}), expand=False)
        vbox.add(self.move_right)
        vbox.add(self.move_left)
        hbox.add(vbox)

    def _draw_nav_tree(self, hbox, **d):
        """
        Draw a Use list for Model item. Items in an accepted
        Use list are integrated into the navigation tree.

        hbox: GTK HBox
            Is the container for the list.

        d: dict
            Initialize the navigation list.
        """
        vbox = gtk.VBox()
        d[wk.RELAY] = self.relay[:]

        d[wk.RELAY].insert(0, self.on_step_list_change)

        # Has step for the interface navigation tree, '_nav_tree'.
        self._nav_tree = TreeViewList(**d)

        vbox.pack_start(Label(**{wk.TEXT: "Use Step"}), expand=False)
        vbox.pack_start(self._nav_tree, expand=True)
        hbox.pack_start(vbox, expand=True)

    def _draw_shelf_tree(self, hbox, **d):
        """
        Draw a list of shelved Model item.

        hbox: GTK HBox
            Contain the list.

        d: dict
            Initialize the shelf list.
        """
        vbox = gtk.VBox()
        d[wk.RELAY] = self.relay[:]

        d[wk.RELAY].insert(0, self.on_model_list_change)

        # Has step for the offline dict, '_offline_tree'.
        self._shelf_tree = TreeViewList(**d)

        vbox.pack_start(Label(**{wk.TEXT: "Model Shelf"}), expand=False)
        vbox.pack_start(self._shelf_tree, expand=True)
        hbox.pack_start(vbox, expand=True)

    def _init_list(self):
        """
        A Model has a step key that is visible in the navigation tree
        or is available to add to that tree. Create two lists, one for
        the visible and the other for the available. Load each
        TreeViewList per its assignment.
        """
        def _remove_no_show(_q):
            _q1 = set()

            for _i in _q:
                for _i1 in NO_SHOW:
                    if _i1 in _i:
                        _q1.update((_i,))

            for _i in _q1:
                _q -= {_i}
            return _q

        total_model_q = set()
        model_step_q = set()
        shelf_key_q = Shelf.get_step_q()

        for model_name, model_type in self._model_list.get_model_def():
            # Create a list of panel step key (branch) matching the model.
            for i in shelf_key_q:
                if i[0] == model_name:
                    if i[-1] in MODEL_GROUP:
                        # Add steps are for user workflow
                        # that are not saved with the Shelf.
                        # branch step
                        model_step_q.add(i[:-1])

                        # model step
                        model_step_q.add((i[0],))
                    model_step_q.add(i)

            # Load the TreeView.
            q = convert_to_string(model_step_q)

            q = _remove_no_show(q)
            total_model_q.update(q)

        q = convert_to_string(self._branch_q)
        q = _remove_no_show(q)

        self._shelf_tree.populate_item_q(sorted(list(total_model_q)))
        self._nav_tree.populate_item_q(sorted(list(q)))

    def _move_item(self, from_tree, to_tree):
        """
        Move an item from one TreeView to the other.

        from_tree: TreeViewList
        to_tree: TreeViewList
        """
        n = get_treeview_item(from_tree.treeview)

        if n is not None:
            from_tree.remove_x(from_tree.get_sel_row())

            if n not in to_tree.item_q:
                to_tree.insert_row(len(to_tree.item_q), n)

            x = len(n)

            # Transfer a Node branch.
            for i in from_tree.item_q[:]:
                if n in i[:x] and i[:x + 1][-1] == '/':
                    from_tree.remove_x(from_tree.get_item_x(i))
                    if i not in to_tree.item_q:
                        to_tree.insert_row(len(to_tree.item_q), i)

        self._verify_buttons()
        self.roller_win.emit(si.ACCEPT_FOCUS, None)

    def _verify_buttons(self):
        self._verify_left_button()
        self._verify_right_button()

    def _verify_left_button(self):
        """
        The left Button is dependent on a selection in the 'Use' TreeView.
        """
        self.move_left.set_sensitive(self._nav_tree.get_sel_row() is not None)

    def _verify_right_button(self):
        """
        The right Button is dependent on a selection in the 'Shelf' TreeView.
        """
        self.move_right.set_sensitive(
            self._shelf_tree.get_sel_row() is not None
        )

    def get_a(self, is_all=False):
        """
        Retrieve the value of the TreeView.

        is_all: bool
            If its True, then the combined Shelf
            and Navigation lists to the caller.

        Return: tuple
            (list of Model TreeView item, list of Tree TreeView item)
        """
        q = self._shelf_tree.item_q + self._nav_tree.item_q \
            if is_all else self._nav_tree.item_q

        # Insert hidden step back into the list with Model reference.
        for model_name, model_type in self._model_list.get_model_def():
            model_follower = [model_name + i for i in NO_SHOW]
            if any([i for i in q if model_name == i.split("/")[0]]):
                q += model_follower
                if model_name not in q:
                    q.append(model_name)

        # Convert the item string value into step key tuple.
        return [tuple(i.split("/")) for i in q]

    def on_model_list_change(self, *_):
        """Respond to a change in the Model list."""
        self._verify_right_button()

    def on_move_left_action(self, *_):
        """
        Move the selected item from the 'Use' TreeView to the 'Shelf' TreeView.
        """
        self._move_item(self._nav_tree, self._shelf_tree)

    def on_move_right_action(self, *_):
        """
        Move the selected item from the 'Shelf' TreeView to the 'Use' TreeView.
        """
        self._move_item(self._shelf_tree, self._nav_tree)

    def on_step_list_change(self, *_):
        """Respond to a change in the 'Use' list."""
        self._verify_left_button()
