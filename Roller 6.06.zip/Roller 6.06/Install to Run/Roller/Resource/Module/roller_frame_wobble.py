#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (  # type: ignore
    CHANNEL_OP_REPLACE, CHANNEL_OP_SUBTRACT, gimp, pdb
)
from math import cos, radians, sin
from random import random
from roller_a_contain import Run
from roller_constant_for import Frame as ff
from roller_constant_key import Material as ma, Option as ok, SubMaya as sm
from roller_frame import do_emboss_sel, sort_shadow_layer
from roller_frame_alt import AltAdd, Wrap
from roller_fu import (
    add_layer,
    get_select_bounds,
    load_selection,
    remove_z,
    select_item,
    select_rect,
    shrink_selection
)
from roller_maya_build import Build
from roller_maya_shadow import Shadow
from roller_view_preset import combine_seed
from roller_view_real import get_light

# pi x 2, FULL_CIRCLE
FULL_CIRCLE = 6.283185307179586

# A lower increment value increases the wavelength.
INCREMENT = 1.5
HALF_INC = .5 * INCREMENT
QUART_INC = .25 * INCREMENT

gimp_stroke = gimp.VectorsBezierStroke

# fast look-up list
cos_q = []
sin_q = []

# Is the number of indices created by the INCREMENT value, '5'.
for a_ in range(int(INCREMENT + 1)):
    cos_q.append(cos(radians(a_)))
    sin_q.append(sin(radians(a_)))


def create_wobble_path(j, wobble_factor, active_vectors):
    """
    Adapt Tin Tran's 'wobble3d.py' GIMP plug-in.
    Create a wobble path from the active path.

    j: GIMP image
        WIP

    wobble_factor: float
        .0 to 1.
        Create greater wobble with a higher value.

    active_vectors: gimp.vectors
    """
    point_x = 50
    point_y = point_z = 0
    new_vectors = pdb.gimp_vectors_new(j, "3D wobble hand-scribble")
    temp_vectors = pdb.gimp_vectors_new(j, "Temp vectors for speed")
    remove_stroke = temp_vectors.remove_stroke
    pitch = random() * FULL_CIRCLE
    roll = random() * FULL_CIRCLE
    yaw = random() * FULL_CIRCLE
    stroke_x = stroke_y = current_stroke_count = 0
    is_valid = False

    for source_stroke in active_vectors.strokes:
        current_stroke_count += 1

        # precision, '.1'
        stroke_length = source_stroke.get_length(.1)

        source_point_q, is_closed = source_stroke.points
        distance = 0
        old_x = old_y = last_distance = -1

        # Count coordinate.
        start_x = 0

        # Store single distance.
        distance_q = []

        end_total_distance = []
        distance_up_to_now = 0
        stroke_point_count = len(source_point_q) / 6

        # Get the first short Stroke.
        fast_stroke = gimp_stroke(
            temp_vectors, source_point_q[start_x:start_x + 12], 0
        )
        start_x += 6

        # precision, '.1'
        this_distance = temp_vectors.strokes[0].get_length(.1)

        distance_q.append(this_distance)
        distance_up_to_now += this_distance
        end_total_distance.append(distance_up_to_now)
        current_index = 1
        current_stroke_index = 0
        current_short_stroke = fast_stroke
        get_point_at_dist = current_short_stroke.get_point_at_dist
        this_stroke_distance = 0
        stroke_point_q = []

        while distance < stroke_length:
            pitch += random() * HALF_INC-QUART_INC

            if pitch < -INCREMENT:
                pitch = -INCREMENT

            elif pitch > INCREMENT:
                pitch = INCREMENT

            roll += random() * HALF_INC - QUART_INC

            if roll < -INCREMENT:
                roll = -INCREMENT

            elif roll > INCREMENT:
                roll = INCREMENT

            yaw += random() * HALF_INC - QUART_INC

            if yaw < -INCREMENT:
                yaw = -INCREMENT

            elif yaw > INCREMENT:
                yaw = INCREMENT

            int_yaw = int(yaw)
            cosine1 = cos_q[int_yaw]
            sine1 = sin_q[int_yaw]
            int_pitch = int(pitch)
            cosine2 = cos_q[int_pitch]
            sine2 = sin_q[int_pitch]
            int_roll = int(roll)
            cosine3 = cos_q[int_roll]
            sine3 = sin_q[int_roll]
            x = point_x
            y = point_y
            z = point_z
            point_x = \
                cosine1 * cosine2 * x + \
                (cosine1 * sine2 * sine3 - sine1 * cosine3) * y + \
                (cosine1 * sine2 * cosine3 + sine1 * sine3) * z
            point_y = \
                sine1 * cosine2 * x + \
                (sine1 * sine2 * sine3 + cosine1 * cosine3) * y + \
                (sine1 * sine2 * cosine3 - cosine1 * sine3) * z
            point_z = \
                -sine2 * x + \
                cosine2 * sine3 * y + \
                cosine2 * cosine3 * z

            # Don't need to get points if it's within 1 pixel,
            # just let it use the previous point.
            if distance - last_distance > .999999:
                while distance > end_total_distance[current_stroke_index]:
                    if current_index < stroke_point_count - 1:
                        remove_stroke(fast_stroke)
                        fast_stroke = gimp_stroke(
                            temp_vectors,
                            source_point_q[start_x:start_x + 12],
                            0
                        )
                        start_x += 6

                        # precision, '.1'
                        this_distance = fast_stroke.get_length(.1)

                        distance_q.append(this_distance)
                        distance_up_to_now += this_distance
                        end_total_distance.append(distance_up_to_now)
                        current_index += 1

                    elif (
                        current_index == stroke_point_count - 1 and is_closed
                    ):
                        remove_stroke(fast_stroke)
                        fast_stroke = gimp_stroke(
                            temp_vectors,
                            source_point_q[start_x:start_x + 6] +
                            source_point_q[0:6],
                            0
                        )
                        start_x += 6

                        # precision, '.1'
                        this_distance = fast_stroke.get_length(.1)

                        distance_q.append(this_distance)
                        distance_up_to_now += this_distance
                        end_total_distance.append(distance_up_to_now)
                        current_index += 1

                    # Move to the next stroke.
                    current_stroke_index += 1
                    current_short_stroke = fast_stroke
                    get_point_at_dist = current_short_stroke.get_point_at_dist
                    this_stroke_distance = distance_q[current_stroke_index] - (
                        end_total_distance[current_stroke_index] - distance
                    )

                # slope, '_'; precision, '.1'
                stroke_x, stroke_y, _, is_valid = get_point_at_dist(
                    this_stroke_distance, .1
                )
                last_distance = distance

            x1 = stroke_x + point_x * wobble_factor
            y1 = stroke_y + point_y * wobble_factor

            # new distance-delta reach, '.99'
            if (abs(x1 - old_x) > .99 or abs(y1 - old_y) > .99) and is_valid:
                old_x = x1
                old_y = y1
                stroke_point_q.extend([x1, y1] * 3)

            distance_inc = random()
            distance += distance_inc
            this_stroke_distance += distance_inc

        if temp_vectors.strokes:
            remove_stroke(fast_stroke)

        # Add the points to the 'new_vectors' path.
        gimp_stroke(new_vectors, stroke_point_q, is_closed)
    pdb.gimp_image_insert_vectors(j, new_vectors, None, 0)


def do_matter(maya):
    """
    Make a frame around cast layer pixel.

    maya: Maya
    Return: layer or None
        Wrap frame
    """
    j = Run.j
    d = maya.value_d
    group = maya.group
    cast = maya.cast.matter

    # layer for the emboss, 'z'
    z = add_layer(j, "Material", group, get_light(maya))

    combine_seed(d)
    select_wobble_frame(j, cast, d[ok.WIDTH], d[ok.TYPE])

    if not pdb.gimp_selection_is_empty(j):
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_feather(.75)
        pdb.plug_in_sel2path(j, z)

        active_vectors = pdb.gimp_image_get_active_vectors(j)
        if active_vectors:
            create_wobble_path(j, d[ok.WOBBLE_FACTOR], active_vectors)

            path = pdb.gimp_image_get_active_vectors(j)

            pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, path)

            while j.active_vectors:
                pdb.gimp_image_remove_vectors(j, j.active_vectors)
            return do_emboss_sel(z, d)
    remove_z(z)


def select_wobble_frame(j, z, w, n):
    """
    Make a frame selection. The frame width is divided into
    an expansion and contraction amount. The resulting
    selection overlaps the frame by the contraction amount.

    j: GIMP image
        Receive selection.

    z: layer
        Is the material that the frame surrounds.

    w: float
        expansion amount

    n: string
        Wrap Type
    """
    def _angular():
        pdb.gimp_context_set_antialias(0)
        for _ in range(int(expand_w)):
            pdb.gimp_selection_grow(j, 1)

    def _rectangle():
        _is_sel, _x, _y, _x1, _y1 = get_select_bounds(j)
        if _is_sel:
            _x -= expand_w
            _y -= expand_w
            _w = _x1 + expand_w - _x
            _h = _y1 + expand_w - _y
            select_rect(j, _x, _y, _w, _h)

    def _rounded():
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_selection_grow(j, int(expand_w))

    f = z.opacity
    z.opacity = 100.
    w1, odd = divmod(w, 2.)
    expand_w = w1 + odd

    select_item(z)
    {ff.ANGULAR: _angular, ff.RECTANGLE: _rectangle, ff.ROUNDED: _rounded}[n]()

    sel = pdb.gimp_selection_save(j)

    shrink_selection(j, w)

    sel1 = pdb.gimp_selection_save(j)

    load_selection(j, sel)

    if not pdb.gimp_selection_is_empty(j):
        load_selection(j, sel1, option=CHANNEL_OP_SUBTRACT)

    for a in (sel, sel1):
        pdb.gimp_image_remove_channel(j, a)
    z.opacity = f


class Wobble(Build):
    is_embossed = True
    put = issue_q = ()
    kind = material = ma.WOBBLE
    shade_row = ok.BRW
    wrap_k = ok.WRAP_WO

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        Build.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.BRW, ok.WRAP,)],
            do_matter
        )

        rap = self.sub_maya[sm.WRAP] = Wrap(
            any_group,
            self,
            [k_path, k_path + (ok.BRW, ok.WRAP_WO)],
            do_matter
        )
        self.sub_maya[sm.ADD] = AltAdd(
            any_group,
            self.sub_maya[sm.WRAP],
            k_path + (ok.BRW, ok.ADD_ALT,)
        )
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group,
            rap,
            (self.cast, rap),
            k_path + (ok.BRW, ok.SHADOW),
            is_overlay=True
        )

    def do(self, d, is_change):
        """
        Manage layer output.

        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.value_d = d
        is_back = Run.is_back

        self.realize()

        wrap = self.sub_maya[sm.WRAP]
        m = wrap.do(d[ok.BRW][ok.WRAP_WO], is_change)

        if wrap.matter:
            m1 = self.sub_maya[sm.SHADOW].do(
                d[self.shade_row][ok.SHADOW], is_change, m, wrap.group
            )

            m1 |= self.sub_maya[sm.ADD].do(
                d[ok.BRW][ok.ADD_ALT], m, m, is_back
            )
            sort_shadow_layer(self, m1, get_light(wrap), wrap.matter)

        else:
            self.die()
        self.reset_issue()
