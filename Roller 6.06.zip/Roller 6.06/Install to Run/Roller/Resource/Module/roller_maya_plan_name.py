#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_key import Model as md
from roller_deco import ready_canvas_rect
from roller_polygon import get_bounds
from roller_fu import make_layer_group, verify_layer_group
from roller_image_grind import ref_get_image_name
from roller_view_hub import add_text_layer, make_plan_text_layer


def create_facial_main_name(maya, p):
    """
    Draw an image name for Plan Face or Facing for main.

    maya: Maya
    Return: layer or None
        text material
    """
    super_ = maya.super_maya
    parent = super_.group
    group = make_layer_group(Run.j, "Name", parent, 0)

    for k in super_.main_q:
        p(maya, group, k)
    return verify_layer_group(group)


def create_facial_per_name(maya, p):
    """
    Draw an image name for Plan Facing or Face Per.

    maya: Maya
    p: function
        Create Face/Facing name.

    Return: layer or None
        text material
    """
    super_ = maya.super_maya
    parent = super_.group
    group = make_layer_group(Run.j, "Name", parent, 0)

    p(maya, group, super_.k)
    return verify_layer_group(group)


def draw_canvas_name(maya):
    """
    Draw image name for Canvas/Image.

    maya: Maya
    Return: layer or None
        text
    """
    ready_canvas_rect(maya, maya.value_d, option=None)

    super_ = maya.super_maya
    j = Run.j
    n = ref_get_image_name(maya.any_group, None, 0)
    if n:
        z = make_plan_text_layer(j, n, maya.font_size)
        x, y, w, h = maya.model.canvas_pocket.rect
        x = w / 2. + x - z.width / 2.
        y = h / 2. + y + z.height / 2.
        z.name = super_.group.name + " Name"

        add_text_layer(super_.group, z, x, y)
        return z


def draw_cell_main_name(maya):
    """
    Draw an image name for Cell/Image main.

    maya: Maya
    Return: layer or None
        text material
    """
    model = maya.model
    j = Run.j
    super_ = maya.super_maya
    group = make_layer_group(j, "Name", super_.group, 0)
    font_size = maya.font_size

    for k in super_.main_q:
        x, y, w, h = model.get_pocket_rect(k)
        n = ref_get_image_name(maya.any_group, k, 0)
        if n:
            z = make_plan_text_layer(j, n, font_size)
            x1 = w / 2. + x - z.width / 2.
            y1 = h / 2. + y + z.height / 2.

            if model.model_type == md.STACK:
                y1 = y1 + k[0] * z.height
            add_text_layer(group, z, x1, y1)
    return verify_layer_group(group)


def draw_cell_per_name(maya):
    """
    Draw an image name for Cell/Image/Per.

    maya: Maya
    Return: layer or None
        text
    """
    model = maya.model
    j = Run.j
    super_ = maya.super_maya
    k = super_.k
    x, y, w, h = model.get_pocket_rect(k)
    n = ref_get_image_name(maya.any_group, k, 0)
    if n:
        z = make_plan_text_layer(j, n, maya.font_size)
        x1 = w / 2. + x - z.width / 2.
        y1 = h / 2. + y + z.height / 2.

        if model.model_type == md.STACK:
            y1 = y1 + maya.k[0] * z.height

        add_text_layer(super_.group, z, x1, y1)
        return z


def draw_face_per_name(maya):
    """
    Draw an image name for Plan Face/Image/Per.

    maya: Maya
    Return: layer or None
        text
    """
    return create_facial_per_name(maya, draw_face_name)


def draw_face_main_name(maya):
    """
    Draw Plan Face/Image name for main.

    maya: Maya
    Return: layer or None
        text material
    """
    super_ = maya.super_maya
    parent = super_.group
    group = make_layer_group(Run.j, "Name", parent, 0)

    for k in super_.main_q:
        draw_face_name(maya, group, k)
    return verify_layer_group(group)


def draw_face_name(maya, group, k):
    """
    Draw Face/Image name.

    maya: Maya
    group: layer group
        Is where to place text layer.

    k: tuple
        (row, column, face)
        cell index
    """
    model = maya.model
    font_size = maya.font_size

    x, y, w, h = get_bounds(model.get_facing_foam(k))
    n = maya.super_maya.get_facing_name(k)
    if n:
        z = make_plan_text_layer(group.image, n, font_size)
        x1 = w / 2. + x - z.width / 2.
        y1 = h / 2. + y + z.height / 2.

        if model.model_type == md.STACK:
            y1 = y1 + k[0] * z.height
        add_text_layer(group, z, x1, y1)


def draw_facing_per_name(maya):
    """
    Draw an image name for Plan Facing/Per.

    maya: Maya
    Return: layer or None
        text
    """
    return create_facial_per_name(maya, draw_facing_name)


def draw_facing_main_name(maya):
    """
    Draw Plan Face/Image main.

    maya: Maya
    Return: layer or None
        text material
    """
    return create_facial_main_name(maya, draw_facing_name)


def draw_facing_name(maya, group, k):
    """
    Draw Facing/Image name.

    maya: Maya
    group: layer group
        Is where to place text layer.

    k: tuple
        (row, column, None)
        Map key derived from grid index
    """
    model = maya.model
    font_size = maya.font_size
    x, y, w, h = get_bounds(model.get_facing_foam(k))
    n = maya.super_maya.get_facing_name(k)
    if n:
        z = make_plan_text_layer(group.image, n, font_size)
        x1 = w / 2. + x - z.width / 2.
        y1 = h / 2. + y + z.height / 2.

        if model.model_type == md.STACK:
            y1 = y1 + k[0] * z.height
        add_text_layer(group, z, x1, y1)
