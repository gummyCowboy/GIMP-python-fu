#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    ADD_MASK_BLACK,
    ADD_MASK_SELECTION,
    CHANNEL_OP_ADD,
    LAYER_MODE_NORMAL,
    RGBA_IMAGE,
    pdb
)
from collections import OrderedDict
from roller_a_contain import PlanZ, Run
from roller_constant_key import Group as gk, Item as ie, SubMaya as sm
from roller_fu import (
    add_layer,
    clear_inverse_selection,
    discard_mask,
    get_background,
    get_layer_position,
    make_layer_group,
    remove_layers,
    select_item,
    select_rect
)
from roller_one_wip import Wip
from roller_view_step import get_model_branch_key
import math

# {group key: sortable position ordinal}
LEAF_D = OrderedDict([
    (gk.CAPTION, 0),
    (gk.LINE, 1),
    (gk.IMAGE, 2),
    (gk.BORDER, 3),
    (gk.FRINGE, 4),
    (gk.PLAQUE, 5),
    (gk.MARGIN, 6),
    (gk.TYPE, 7)
])

# {Node/branch item key: sortable position ordinal}
BRANCH_D = OrderedDict([
    (ie.FACING, 0),
    (ie.FACE, 1),
    (ie.CELL, 2),
    (ie.CANVAS, 3),
])


def add_sub_base_group(maya):
    """
    Add a group layer to the bottom of a Maya layer group.

    maya: Maya
    Return: layer group
        newly added
    """
    return make_layer_group(
        Run.j,
        maya.any_group.item.key + " WIP",
        maya.group,
        len(maya.group.layers)
    )


def add_top_layer(maya, n):
    """
    Add a layer at the top of a Maya group, but below a Gradient Light layer.

    maya: Maya
    n: string
        layer name appendix

    Return: layer
        newly added
    """
    return add_layer(Run.j, n, maya.group, get_light(maya))


def add_wip_above(z, n=""):
    """
    Insert a new empty WIP layer above an existing layer.

    z: layer
        Has position of insertion.

    n: string
        Name the layer.

    Return: layer
        newly added
    """
    return add_wip_layer(n, z.parent, offset=get_layer_position(z))


def add_wip_base(n, group):
    """
    Insert a new empty WIP layer at the bottom of a layer group.

    n: string
        layer name suffix

    Return: layer
        newly added
    """
    return add_wip_layer(n, group, offset=len(group.layers))


def add_wip_below(z, n=""):
    """
    Insert a new empty WIP layer below an existing layer.

    z: layer
        Has position of insertion.

    n: string
        Name the layer.

    Return: layer
        newly added
    """
    return add_wip_layer(n, z.parent, offset=get_layer_position(z) + 1)


def add_wip_layer(n, group, offset=0):
    """
    Make a WIP layer. Is not for the Layers
    trunk, but is for a layer group branch.

    n: string
        layer name suffix

    group: layer group or None
        Is the parent of the new layer.

    offset: int
        Position the layer from the top of the layer group.

    Return: layer
        as requested
    """
    n = group.name + " " + n if group else n
    x, y, w, h = map(int, Wip.get_rect())
    z = pdb.gimp_layer_new(
        Run.j,
        w, h,
        RGBA_IMAGE,
        n,
        100.,                       # opacity
        LAYER_MODE_NORMAL
    )

    pdb.gimp_layer_set_offsets(z, x, y)
    pdb.gimp_image_insert_layer(Run.j, z, group, offset)
    return z


def clip_to_view(z):
    """
    Transform a layer to the view size which is also the render image size.
    Layer content is clipped to the image bounds.

    z: layer
        Resize to the view size.
    """
    j = z.image
    pdb.gimp_layer_resize(z, j.width, j.height, *z.offsets)


def clip_to_wip(z):
    """
    Transform a layer to a WIP sized layer.
    Crop the content to the WIP layer bounds.

    z: layer or None
        Crop its content to the Wip size.
    """
    if z:
        isolate_wip_rect(z)

        x, y = z.offsets
        q = map(int, (Wip.w, Wip.h, x - Wip.x, y - Wip.y))
        pdb.gimp_layer_resize(z, *q)


def clone_background(z, n="BG Copy", is_hide=True, on_top=False):
    """
    Make a copy of the visible background material
    below a layer. Insert the copy below the layer
    unless flagged otherwise.

    z: layer
        Copy its background.

    n: string
        Name the clone layer.

    is_hide: bool
        If true, the top layer, 'z', is not part of the copy.

    on_top: bool
        If True, the copy layer is inserted above layer 'z'.

    Return: layer
        Is the copy of the background.
    """
    j = z.image
    z1 = get_background(z, n, is_hide=is_hide)
    x = 0 if on_top else 1

    pdb.gimp_image_insert_layer(j, z1, z.parent, get_layer_position(z) + x)
    clip_to_wip(z1)
    return z1


def create_branch(maya):
    """
    Create a layer group for a Model branch.

    maya: Maya
        Needs a layer group in the correct position.

    Return: layer group
        newly created
    """
    def _insert(_d):
        """Insert branch and leaf into a Model layer tree."""
        # [item key, ...]
        _q = []

        for _z in parent.layers:
            _n = _z.name
            _q.append(_n.split(" ")[-1])

        # [position ordinal, ...]
        _q1 = []

        for k in _q:
            _q1.append(_d.get(k))

        _ordinal = _d.get(item_k)
        _q1.append(_ordinal)
        _q1 = sorted(_q1)

        # Is the offset from the top of parent, '_x'.
        _x = _q1.index(_ordinal)

        pdb.gimp_image_reorder_item(j, group, parent, _x)

    def _sort(_):
        """Sort Main and Per branches."""
        _n = group.name
        _x = 0

        for _x, _i in enumerate(parent.layers):
            if _n > _i.name:
                break
        pdb.gimp_image_reorder_item(j, group, parent, _x)

    j = Run.j
    step_k = get_model_branch_key(maya.node_path)

    # Model layer group for Plan or Work, 'parent'
    parent = maya.model.group_q[Run.x]

    # If there isn't a Model group, then the caller is out-of-sync.
    if parent:
        # index to item in step key, 'x'
        for x, item_k in enumerate(step_k):
            # Find the sub-step's layer group.
            group = None
            n = item_k

            for i in parent.layers:
                if i.name.split(" ")[-1] == n:
                    group = i
                    break

            if not group:
                group = make_layer_group(j, item_k, None, 0)
                group.name = parent.name + " " + item_k

                # Create a layer group. 'x' is in the range of 0 to 2.
                (_insert, _insert, _sort)[x]((BRANCH_D, LEAF_D, None)[x])
            parent = group
    return parent


def get_light(maya):
    """
    Determine the offset for a layer group
    which may have a Gradient Light layer.

    maya: Maya
    Return: int
        0 or 1
        Is the integer conversion of the boolean result
        of the layer in question's existence.
    """
    a = maya.sub_maya.get(sm.LIGHT)

    if a:
        return int(bool(a.matter))

    # Plan output doesn't have Gradient Light.
    return 0


def insert_copy(group, z, is_hide=False):
    """
    Insert a background copy layer into a layer group.

    group: layer
        Is the destination.

    z: layer
        Copy from its position.

    is_hide: bool
        If True, then the positional layer is
        hidden before making the background copy.

    Return: layer
        that was inserted
    """
    j = z.image
    z1 = get_background(z, "Background Copy", is_hide=is_hide)

    pdb.gimp_image_insert_layer(j, z1, group, 0)
    clip_to_wip(z1)
    return z1


def get_point_on_edge(angle):
    """
    Calculate an x, y coordinate for a point intersecting
    a ray, originating from the center of a rectangle,
    and ending at a rectangle boundary.

    angle: float
        radians
        angle from center of the rectangle

    Return: point
        x, y of float
        the point on the rectangle
    """
    x, y, w, h = Wip.get_rect()
    sine = math.sin(angle)
    cosine = math.cos(angle)
    h1 = h / 2.
    w1 = w / 2.

    # distance to the top or the bottom edge (from the center), 'h2'
    h2 = h1 if sine > .0 else -h1

    # distance to the left or the right edge (from the center), 'w2'
    w2 = w1 if cosine > .0 else -w1

    # (distance to the vertical line) < (distance to the horizontal line)
    if abs(w2 * sine) < abs(h2 * cosine):
        # Calculate distance to the vertical line:
        h2 = (w2 * sine) / cosine

    # (distance to the top or the bottom edge)
    # < (distance to the left or the right edge)
    else:
        w2 = (h2 * cosine) / sine
    return round(w2 + w1 + x), round(h2 + h1 + y)


def insert_copy_above(z, z1):
    """
    Insert a background copy layer above another layer.

    z: layer
        Insert the copy above this layer.

    z1: layer
        Copy from its position.

    Return: layer
        that was inserted
    """
    j = z.image
    z2 = get_background(z1, "Background Copy", is_hide=False)

    pdb.gimp_image_insert_layer(j, z2, z.parent, get_layer_position(z))
    clip_to_wip(z2)
    return z2


def isolate_wip_rect(z, is_keep=False):
    """
    Clear out material not in the WIP rectangle.

    z: layer
        Clear.

    is_keep: bool
        If it's True, then the selection remains.
    """
    if Wip.x:
        select_rect(Run.j, *Wip.get_rect())
        clear_inverse_selection(z, is_keep=is_keep)


def make_cast_group(maya):
    """
    Make a group layer for a Cell/leaf.

    maya: Maya
    """
    if not maya.group:
        group = create_branch(maya)
        maya.group = make_layer_group(Run.j, "Cast", group, get_light(maya))
    return maya.group


def make_canvas_group(maya):
    """
    Make a group layer for a Canvas/leaf step.

    maya: Maya
    """
    if not maya.group:
        maya.group = create_branch(maya)
    return maya.group


def make_matter_group(maya):
    """
    Add a material layer group to a layer group.

    maya: Maya
        Must have a Light sub-Maya and a layer 'group'.

    Return: layer
        newly added
    """
    return make_layer_group(Run.j, "Material", maya.group,  get_light(maya))


def make_plan_group(_):
    """
    Make a Plan layer group if there isn't one.

    _: maya
        not used

    Return: layer group
        for Plan
    """
    if not PlanZ.plan_group:
        PlanZ.plan_group = make_layer_group(Run.j, "Plan", None, 0)
    return PlanZ.plan_group


def mask_from_maya(alpha, sub_z, p=select_item):
    """
    Mask a layer from multiple Maya 'matter' layer alpha.

    alpha: Maya
        Its 'Maya.matter' layer's alpha creates the mask.

    sub_z: layer or None
        Is the layer to receive the mask.

    p: function
        Select source layer.

    Return: layer
        mask
    """
    if sub_z:
        pdb.gimp_selection_none(Run.j)

        z = alpha.matter

        if z:
            p(z, option=CHANNEL_OP_ADD)
        mask_sel(sub_z)


def mask_sel(z):
    """
    Make a mask for a layer from a selection.
    Call with a selection already in place.

    z: layer
        to receive mask
    """
    if z:
        discard_mask(z)
        if not pdb.gimp_selection_is_empty(z.image):
            z.add_mask(pdb.gimp_layer_create_mask(z, ADD_MASK_SELECTION))
        else:
            # There is no source for the mask, so mask everything.
            z.add_mask(pdb.gimp_layer_create_mask(z, ADD_MASK_BLACK))


def mask_sub_maya(source_z, sub_z):
    """
    Make a mask for a sub-Maya matter layer from a source layer's alpha.

    source_z: layer
        Derive a mask from the layer's alpha material.

    sub_z: layer or None
        Receive the mask.

    Return: layer
        mask
    """
    if sub_z and source_z:
        select_item(source_z)
        mask_sel(sub_z)


def remove_maya_z(maya, n):
    """
    Remove a layer given its attribute descriptor. Set its reference to None.

    maya: Maya
        Has the attribute that references a layer(s).

    n: string
        layer attribute descriptor
    """
    remove_layers(getattr(maya, n))
    setattr(maya, n, None)
