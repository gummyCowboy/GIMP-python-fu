#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD,
    CHANNEL_OP_INTERSECT,
    CHANNEL_OP_SUBTRACT,
    CLIP_TO_IMAGE,
    HISTOGRAM_VALUE,
    LAYER_MODE_HARDLIGHT,
    pdb
)
from roller_a_contain import Globe, Run
from roller_a_gegl import emboss
from roller_constant_for import Frame as ff
from roller_constant_key import Material as ma, Option as ok, SubMaya as sm
from roller_frame import (
    grow_wrap, do_emboss_sel, remove_sel, sort_shadow_layer
)
from roller_frame_alt import AltFiller
from roller_fu import (
    add_layer,
    apply_mask,
    clone_layer,
    clone_opaque_layer,
    load_selection,
    make_layer_group,
    merge_layer_group,
    remove_z,
    select_item
)
from roller_maya_add import AltAdd
from roller_maya_build import Build, SubBuild
from roller_maya_layer import check_matter, check_mix_basic, make_group_wrap
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_view_hub import do_mod
from roller_view_real import get_light


def do_matter(maya):
    """
    Make a frame.

    maya: StretchWrap
    Return: layer
        raw Stretch Wrap 'matter'
    """
    j = Run.j

    for n in ('filler_sel', 'wrap_sel'):
        remove_sel(maya, n)

    maya.filler_sel = make_1st_frame_sel(maya)
    maya.wrap_sel = pdb.gimp_selection_save(j) \
        if not pdb.gimp_selection_is_empty(j) else None
    return add_layer(j, "Material", maya.group, get_light(maya))


def do_filler(maya):
    """
    Draw Filler material.

    maya: AltFiller
    Return: layer
        Stretch Filler 'matter'
    """
    j = Run.j
    d = maya.value_d

    # source layer, 'z'
    z = clone_opaque_layer(maya.cast.matter, n="Left")

    group = make_layer_group(
        j, "Material", maya.group, get_light(maya), z=z,
    )

    apply_mask(z)
    pdb.gimp_selection_none(j)

    for x, z in enumerate((
        z,
        clone_layer(z, n="Right"),
        clone_layer(z, n="Top"),
        clone_layer(z, n="Bottom")
    )):
        pdb.plug_in_wind(
            j, z,
            .0,                 # Threshold All
            x,                  # direction
            100,                # maximum strength
            0,                  # wind algorithm
            1,                  # leading edge
        )

        # threshold all pixel, '.0'
        pdb.plug_in_threshold_alpha(j, z, .0)

    # Make the wind output opaque.
    z = merge_layer_group(group)
    z1 = clone_opaque_layer(z)

    remove_z(z)
    pdb.gimp_drawable_curves_spline(
        z1,
        HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .25, 1., .75)
    )

    z2 = clone_layer(z1, n="Hard Light")
    z2.mode = LAYER_MODE_HARDLIGHT
    z2.opacity = 80.

    pdb.gimp_drawable_curves_spline(
        z2,
        HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .45, 1., .54)
    )

    # depth, '3'
    emboss(z2, Globe.azimuth, Globe.elevation, 3)

    z = pdb.gimp_image_merge_down(j, z2, CLIP_TO_IMAGE)
    z.name = z.parent.name + " Material"

    do_mod(z, d[ok.BRW][ok.MOD])
    return z


def make_1st_frame_sel(maya):
    """
    Make Wrap selection.

    maya: Stretch
    Return: GIMP selection channel and GIMP's state of selection
        Limit the Filler area.
    """
    j = Run.j
    d = maya.value_d
    cast = maya.cast.matter

    # Grow the selection for each frame part.
    select_item(cast)
    grow_wrap(j, d[ok.WIDTH], d[ok.TYPE])

    # inner frame selection, 'sel'
    sel = pdb.gimp_selection_save(j)

    grow_wrap(j, d[ok.FILLER_W], d[ok.TYPE])

    # inner and filler frame selection, 'sel1'
    sel1 = pdb.gimp_selection_save(j)

    grow_wrap(j, d[ok.WIDTH], d[ok.TYPE])

    # inner, filler, and outer selection, 'sel2'
    sel2 = pdb.gimp_selection_save(j)

    load_selection(j, sel1, option=CHANNEL_OP_SUBTRACT)

    # outer frame selection, 'sel3'
    sel3 = pdb.gimp_selection_save(j)

    load_selection(j, sel1)
    load_selection(j, sel, option=CHANNEL_OP_SUBTRACT)

    filler_sel = pdb.gimp_selection_save(j)

    # Make an inner frame selection.
    load_selection(j, sel)
    select_item(cast, option=CHANNEL_OP_SUBTRACT)
    load_selection(j, sel3, option=CHANNEL_OP_ADD)

    for i in (sel, sel1, sel2, sel3):
        pdb.gimp_image_remove_channel(j, i)
    return filler_sel


def make_2nd_frame_sel(d, z, cast_z, wrap_sel, filler_sel):
    """
    Make a Filler area selection.

    d: dict
        Wrap, Fill Preset

    z: layer
        Filler output

    wrap_sel: GIMP selection channel
        Define initial wrap.

    filler_sel: GIMP selection channel
        Limit filler area.

    Return: GIMP state of selection
    """
    j = Run.j

    load_selection(j, filler_sel)
    select_item(z, option=CHANNEL_OP_INTERSECT)
    grow_wrap(
        j,
        d[ok.WIDTH],
        ff.ANGULAR if d[ok.TYPE] == ff.RECTANGLE else d[ok.TYPE]
    )
    select_item(z, option=CHANNEL_OP_SUBTRACT)
    select_item(cast_z, option=CHANNEL_OP_SUBTRACT)
    load_selection(j, wrap_sel, option=CHANNEL_OP_ADD)


class StretchWrap(SubBuild):
    filler_k = ok.FILLER_S2
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )
    wrap_k = ok.WRAP_FI

    def __init__(self, any_group, super_maya, k_path):
        """
        super_maya: Maya
            Frame type

        k_path: tuple
            (Option key, ...)
            Are path key to its vote dict.
        """
        k_path = k_path + (ok.BRW, ok.WRAP_FI)

        SubBuild.__init__(self, any_group, super_maya, k_path, do_matter)

        self.filler_sel = self.wrap_sel = None
        self.sub_maya[sm.ADD] = AltAdd(any_group, self, k_path + (ok.ADD_ALT,))
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.STRETCH)

    def do(self, d, is_change, is_back):
        """
        Produce layer output.

        d: dict
            Wrap Preset

        is_change: bool
            Is True if the cast Maya has change.

        is_back: bool
            Is True if the background changed.

        Return: bool
            Is True if the wrap layer changed.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(d[ok.ADD_ALT], m, m, is_back)
            self.sub_maya[sm.LIGHT].do(m)

        else:
            self.die()

        self.reset_issue()
        return m

    def reset(self):
        """Call when the view image is removed."""
        for i in (self.filler_sel, self.wrap_sel):
            if i:
                pdb.gimp_image_remove_channel(Run.j, i)

        self.filler_sel = self.wrap_sel = None
        super(StretchWrap, self).reset()


class Stretch(Build):
    filler_k = ok.FILLER_S2
    put = issue_q = ()
    kind = material = ma.STRETCH
    shade_row = ok.BRW
    wrap_k = ok.WRAP_FI

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Is the Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        Build.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.WRAP] = StretchWrap(any_group, self, k_path)
        self.sub_maya[sm.FILLER] = AltFiller(
            any_group, self, k_path, do_filler
        )
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group,
            self,
            (self.cast, self.sub_maya[sm.WRAP], self.sub_maya[sm.FILLER]),
            k_path + (ok.BRW, ok.SHADOW)
        )

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        m = is_change
        shadow = self.sub_maya[sm.SHADOW]
        wrap = self.sub_maya[sm.WRAP]
        wrap_d = d[ok.BRW][ok.WRAP_FI]

        self.realize()

        m |= wrap.do(wrap_d, is_change, is_back)

        if wrap.wrap_sel:
            self.sub_maya[sm.FILLER].do(
                d[ok.BRW][self.filler_k],
                is_change,
                m,
                is_back,
                wrap.filler_sel
            )
            make_2nd_frame_sel(
                wrap_d,
                self.sub_maya[sm.FILLER].matter,
                self.cast.matter,
                wrap.wrap_sel,
                wrap.filler_sel
            )

            if pdb.gimp_selection_is_empty(Run.j):
                remove_z(wrap.matter)
                wrap.matter = None

            else:
                wrap.matter = do_emboss_sel(wrap.matter, wrap_d)

            m1 = shadow.do(d[ok.BRW][ok.SHADOW], is_change, m, wrap.group)
            sort_shadow_layer(self, m or m1, get_light(wrap), wrap.matter)

        else:
            self.die()
        self.reset_issue()
