#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Shape as sh, Triangle as ft
from roller_model_goo import Goo
from roller_polygon import calc_pin_xy, make_coord_list

SCALE_ALT = 1 - ft.SCALE_DOWN


class GridCircle:
    """Calculate a double-spaced grid of ellipse shaped cell."""

    @staticmethod
    def calc(model, o):
        """
        Calculate cell rectangle and form polygon for a Model's cell.

        model: Model
        o: One
            Translate Cell/Type option to attribute for readability.

        Return: dict
            {value: [bool, bool]}
            {cell key: [Plan vote change, Work vote change]}
        """
        vote_d = {}
        did_cell = model.past.did_cell
        row, column = model.grid
        goo_d = model.goo_d
        shape = model.cell_shape
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect

        if shape == sh.CIRCLE_HORIZONTAL:
            # cell size
            w1 = canvas_w / (.5 + column * .5)
            h1 = canvas_h / (SCALE_ALT + row * ft.SCALE_DOWN)
            w = min(w1, h1)
            w, h = w, w

            # grid size
            w1 = w / 2.
            h1 = h * ft.SCALE_DOWN
            h2 = h * SCALE_ALT
            s = column * w1 + w1, row * h1 + h2
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

            # intersect
            w1 = w / 2.
            h1 = h * ft.SCALE_DOWN

        else:
            # circle, vertically aligned
            # cell size
            w1 = canvas_w / (SCALE_ALT + column * ft.SCALE_DOWN)
            h1 = canvas_h / (.5 + row * .5)
            w = min(w1, h1)
            w, h = w, w

            # grid size
            w1 = w * ft.SCALE_DOWN
            w2 = w * SCALE_ALT
            h1 = h / 2.
            s = column * w1 + w2, row * h1 + h1
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

            # intersect
            w1 = w * ft.SCALE_DOWN
            h1 = h / 2.

        # [intersect point]
        q_x = make_coord_list(canvas_w, column, x, span=w1)
        q_y = make_coord_list(canvas_h, row, y, span=h1)

        # Prevent round to zero with max 1.
        w = max(1., w)

        for r_c in model.cell_q:
            r, c = r_c
            y = q_y[r]
            x = q_x[c]
            a = goo_d[r_c] = Goo(r_c)
            a.cell.rect = a.merged.rect = x, y, w, w
            vote_d[r_c] = did_cell(r_c)
            a.form = x, y, w, w
        return vote_d
