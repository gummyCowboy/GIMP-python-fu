#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color as co, Widget as fw
from roller_constant_key import Widget as wk
from roller_widget_box import Eventful
from roller_widget_label import Label
import gtk  # type: ignore

LABEL_X, WIDGET_X, KEY_ARG_X = range(3)


def create_table(container, **d):
    """
    Create a GTK Table with added Widget given a list of Widget argument.

    container: GTK container
        Is for the Table.

    d: dict
        Has keyword arguments.
        Must have:
        wk.COLOR, start color row 1
        'q', list of Widget arguments

    Return: dict
        {Option key: Widget}
        A Widget must have a key if it is to be returned.
    """
    w = fw.MARGIN
    w1 = w // 2
    top_pad = bottom_pad = w
    color = d[wk.COLOR]

    # Widget argument list, 'q'
    q = d['q']

    e = {}
    alignment = gtk.Alignment(.5, .5, 1, 0)
    table = gtk.Table(len(q), 2)
    option_count = len(q)

    alignment.set_padding(top_pad, bottom_pad, w1, w1)
    table.set_row_spacings(1)

    for r, i in enumerate(q):
        if not r:
            # Expand the right-column with an invisible label Widget.
            table.attach(gtk.Label("\t" * 6), 1, 2, r, r + 1)

        # right-side Widget, 'g'
        g = i[WIDGET_X](**i[KEY_ARG_X])

        color = get_darker_color(color, option_count)
        color1 = color, color, co.MAX_COLOR
        g.label_box = Eventful(color1)
        text = i[LABEL_X]

        if text:
            label = Label(text=text)
            g.label = label

            g.label_box.add(label)
            label.set_padding(0, 0, w, w1)

        if g.key is not None:
            e[g.key] = g

        g.box = Eventful(color1)

        g.set_padding(0, 0, w1, w)
        g.box.add(g)
        table.attach(g.label_box, 0, 1, r, r + 1)
        table.attach(g.box, 1, 2, r, r + 1, yoptions=gtk.FILL)

    alignment.add(table)
    container.add(alignment)
    return e


def get_darker_color(color, step_count):
    """
    Calculate a darker blue color using a step count.

    color: int
        Decrease its value to obtain result.
        Is the red and green component.

    step_count: int
        Use to compute amount to reduce.

    Return: int
        for a darker color
    """
    return color - 14000 // (step_count + 1)
