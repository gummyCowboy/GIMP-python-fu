#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_key import (
    Group as gk,
    Item as ie,
    Model as md,
    Node as ny,
    Step as sk,
    Widget as wk
)

# AnyGroup with a Preset
preset = {wk.HAS_PRESET: 1, wk.WIDGET: 'preset'}
preset_switch = {wk.HAS_PRESET: 1, wk.HAS_SWITCH: True, wk.WIDGET: 'preset'}
preset_random = {wk.HAS_PRESET: 1, wk.HAS_RANDOM: 1, wk.WIDGET: 'preset'}

# AnyGroup without a savable Preset
simple = {wk.WIDGET: 'preset'}

# AnyGroup with only a SuperPreset
super_ = {wk.WIDGET: 'super_preset', wk.HAS_PRESET: True}

BORDER = gk.BORDER, preset_switch
CAPTION = gk.CAPTION, preset_switch
FRINGE = gk.FRINGE, preset_switch
IMAGE = gk.IMAGE, preset_switch
LINE = gk.LINE, preset_switch,
MARGIN = gk.MARGIN, preset
PLAQUE = gk.PLAQUE, preset_switch
RECTANGLE = gk.RECTANGLE, preset
SHIFT = gk.SHIFT, preset_switch
DECO = OrderedDict([
    SHIFT, MARGIN, PLAQUE, FRINGE, BORDER, IMAGE, LINE, CAPTION
])
FACE = OrderedDict([PLAQUE, FRINGE, BORDER, IMAGE, LINE, CAPTION])
FACING = deepcopy(FACE)
CANVAS = ny.CANVAS, {wk.ITEM: DECO, wk.WIDGET: 'node'}
CELL_NODE = [(ny.CELL,)]
MULTI_CELL = [
    (ie.PROPERTY,), (ny.CANVAS, ie.SHIFT), (ny.CELL, ie.TYPE), (ie.PRESET,)
]
MULTI_CELL_BRANCH = MULTI_CELL + CELL_NODE
ONE_CELL = [
    (ie.PROPERTY,), (ny.CELL, ie.TYPE), (ny.CELL, ie.RECTANGLE), (ie.PRESET,)
]
ONE_CELL_BRANCH = ONE_CELL + CELL_NODE
DEFAULT_MODEL = {
    md.BOX: MULTI_CELL,
    md.CELL: ONE_CELL,
    md.PYRAMID: MULTI_CELL,
    md.SIDEWALK: MULTI_CELL,
    md.STACK: ONE_CELL,
    md.TABLE: MULTI_CELL
}
DEFAULT_MODEL_BRANCH = {
    md.BOX: MULTI_CELL_BRANCH,
    md.CELL: ONE_CELL_BRANCH,
    md.PYRAMID: MULTI_CELL_BRANCH,
    md.SIDEWALK: MULTI_CELL_BRANCH,
    md.STACK: ONE_CELL_BRANCH,
    md.TABLE: MULTI_CELL_BRANCH
}
SPLIT_KEY = ie.PRESET, ie.TYPE
MAIN_TREE = {
    sk.STEPS: {
        wk.ITEM: OrderedDict([
            (gk.GLOBAL, preset_random),
            (gk.GRADIENT_LIGHT, preset_switch),
            (gk.BACKDROP, preset),
            (gk.MODEL, preset),
            (gk.PRESET_STEPS, super_)
        ]),
        wk.WIDGET: 'node'
    }
}
MAIN_TREE_STEP = [
    sk.STEPS,
    sk.GLOBAL,
    sk.GRADIENT_LIGHT,
    sk.BACKDROP,
    sk.MODEL,
    sk.PRESET_STEPS
]
SHADOW_TREE = {
    ny.SHADOW: {
        wk.ITEM: OrderedDict([
            (gk.SWITCH, simple),
            (gk.SHADOW_1, preset_random),
            (gk.SHADOW_2, preset_random),
            (gk.INNER_SHADOW, preset_random),
            (gk.PRESET_SHADOW, super_)
        ]),
        wk.WIDGET: 'node'
    }
}
INSERT_MODEL_D = {
    sk.STEPS: {
        wk.ITEM: {},
        wk.WIDGET: 'node'
    }
}
INSERT_STEPS_D = deepcopy(INSERT_MODEL_D)

INSERT_STEPS_D.update(MAIN_TREE)

BOX_CELL = OrderedDict([(gk.TYPE_BOX, preset)])
CELL_CELL = OrderedDict([RECTANGLE, (gk.TYPE_CELL, simple)])
PYRAMID_CELL = OrderedDict([(gk.TYPE_PYRAMID, preset)])
SIDEWALK_CELL = OrderedDict([(gk.TYPE_SIDEWALK, preset)])
STACK_CELL = OrderedDict([RECTANGLE, (gk.TYPE_STACK, preset)])
TABLE_CELL = OrderedDict([(gk.TYPE_TABLE, preset)])

for i_ in (
    BOX_CELL,
    CELL_CELL,
    PYRAMID_CELL,
    SIDEWALK_CELL,
    STACK_CELL,
    TABLE_CELL
):
    i_.update(DECO)

MODEL_TREE = {
    md.BOX: {
        wk.ITEM: OrderedDict([
            (gk.PROPERTY, preset),
            CANVAS,
            (ny.CELL, {wk.ITEM: BOX_CELL, wk.WIDGET: 'node'}),
            (ny.FACE, {wk.ITEM: FACE, wk.WIDGET: 'node'}),
            (gk.PRESET_BOX, super_)
        ]),
        wk.WIDGET: 'node'
    },
    md.CELL: {
        wk.ITEM: OrderedDict([
            (gk.PROPERTY, preset),
            (ny.CELL, {wk.ITEM: CELL_CELL, wk.WIDGET: 'node'}),
            (gk.PRESET_CELL, super_)
        ]),
        wk.WIDGET: 'node'
    },
    md.PYRAMID: {
        wk.ITEM: OrderedDict([
            (gk.PROPERTY, preset),
            CANVAS,
            (ny.CELL, {wk.ITEM: PYRAMID_CELL, wk.WIDGET: 'node'}),
            (gk.PRESET_PYRAMID, super_)
        ]),
        wk.WIDGET: 'node'
    },
    md.SIDEWALK: {
        wk.ITEM: OrderedDict([
            (gk.PROPERTY, preset),
            CANVAS,
            (ny.CELL, {wk.ITEM: SIDEWALK_CELL, wk.WIDGET: 'node'}),
            (ny.FACING, {wk.ITEM: FACING, wk.WIDGET: 'node'}),
            (gk.PRESET_SIDEWALK, super_)
        ]),
        wk.WIDGET: 'node'
    },
    md.STACK:  {
        wk.ITEM: OrderedDict([
            (gk.PROPERTY, preset),
            (ny.CELL, {wk.ITEM: STACK_CELL, wk.WIDGET: 'node'}),
            (gk.PRESET_STACK, super_)
        ]),
        wk.WIDGET: 'node'
    },
    md.TABLE: {
        wk.ITEM: OrderedDict([
            (gk.PROPERTY, preset),
            CANVAS,
            (ny.CELL, {wk.ITEM: TABLE_CELL, wk.WIDGET: 'node'}),
            (gk.PRESET_TABLE, super_)
        ]),
        wk.WIDGET: 'node'
    }
}


def create_model_insert_d(q, model_def):
    """
    Create a dictionary for inserting a
    hierarchical structured sequenced step key.

    q: list
        of step key that is to be added to the navigation tree

    model_def: list
        of tuple
        (Model name, Model type)

    Return: dict
        hierarchically structured and relationally sequenced
    """
    step_d = OrderedDict()
    add_d = OrderedDict()
    insert_d = {}

    for i in q:
        d = step_d
        for i1 in i:
            if i1 not in d:
                d[i1] = OrderedDict()
            d = d[i1]

    for model_name, model_type in model_def:
        add_d[model_name] = deepcopy(MODEL_TREE[model_type])

    # Restructure Model dictionary.
    remove_unused_step(add_d, step_d)

    insert_d.update(add_d)
    return insert_d


def create_steps_insert_d(q, model_def):
    """
    Create a dictionary for inserting a hierarchical
    structured and relational sequenced step key.

    q: list
        of step key that is to be added to the navigation tree

    model_name: string
        Identify Model instance.
        Is a Node item key.

    model_type: string
        Identify Model class.

    Return: dict
        hierarchically structured and relationally sequenced
    """
    step_d = {sk.STEPS: OrderedDict()}
    add_d = OrderedDict()
    insert_d = deepcopy(INSERT_STEPS_D)
    model_path_d = insert_d[sk.STEPS][wk.ITEM]

    for i in q:
        d = step_d[sk.STEPS]
        for i1 in i:
            if i1 not in d:
                d[i1] = OrderedDict()
            d = d[i1]

    model_path_d.update(add_d)

    for model_name, model_type in model_def:
        model_path_d[model_name] = deepcopy(MODEL_TREE[model_type])

    # Restructure Model dictionary.
    remove_unused_step(insert_d, step_d)
    return insert_d


def remove_unused_step(add_d, step_d):
    """
    Recursively remove item from a NodePanel structure dict
    according to the hierarchically arranged insert dict keys.

    add_d: dict
        structure dict
        Has a default structure and order.

    step_d: dict
        insert type
        Has the desired structure, but not order.
    """
    for i in add_d.keys():
        # Transform group key to an item key.
        item = i.split(",")[0] if isinstance(i, basestring) else i

        if item not in step_d.keys():
            add_d.pop(i)

        # Node has ITEM.
        elif wk.ITEM in add_d[i]:
            remove_unused_step(add_d[i][wk.ITEM], step_d[item])
