#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Widget as fw
from roller_constant_key import Widget as wk
from roller_port_process import PortProcess
from roller_widget_box import Box as boxer
from roller_widget_button import AcceptButton, Button, CancelButton
from roller_widget_tree import ChoiceList
import gtk  # type: ignore


class PortRemove(PortProcess):
    """Remove a Heat material."""
    window_key = "Remove Material"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: Button
            responsible
        """
        self._del_button = \
            self._choice_list = \
            self._accept_button = \
            self._cancel_button = None
        self._item_k = g.any_group.item.key
        self._get_list = g.get_list
        PortProcess.__init__(self, d, g)

    def _draw_list_group(self, g):
        """
        Draw a ChoiceList containing a Preset list.

        g: GTK container
            for list group
        """
        self._choice_list = ChoiceList(
            **{
                wk.CHOICE: self._get_list()[0],
                wk.FUNCTION: self._get_list,
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win,
                wk.TREE_COLOR: self.color
            }
        )

        g.pack_start(self._choice_list, expand=True)

        # Connect event.
        self._choice_list.treeview.connect(
            'key_press_event', self._on_choice_list_keypress
        )

    def _get_selection(self):
        """
        Get the selection in the ChoiceList.

        Return: int or None
            0 to n
        """
        if self._choice_list:
            return self._choice_list.get_sel_row()

    def delete_item(self, *_):
        """
        Delete the selected item from the list.

        _: Delete Button
            not used
        """
        x = self._get_selection()

        if x is not None:
            self._choice_list.remove_x(x)
        self.on_port_change()

    def draw_process_group(self, g):
        """
        Draw a Widget group having process Buttons.

        g: GTK container
            Receive Widget group.
        """
        w = fw.MARGIN
        w1 = w // 2
        hbox = boxer(box=gtk.HBox, align=(0, 0, 1, 1))
        self._cancel_button = CancelButton(
            align=(0, 0, 1, 0),
            padding=(w, w, w, w1),
            relay=[],
            roller_win=self.roller_win,
        )
        self._del_button = Button(
            align=(0, 0, 1, 0),
            padding=(w, w, w1, w1),
            relay=[self.delete_item],
            roller_win=self.roller_win,
            text="Delete"
        )
        self._accept_button = AcceptButton(
            align=(0, 0, 1, 0),
            padding=(w, w, w1, w),
            relay=[],
            roller_win=self.roller_win,
        )

        for i in (self._cancel_button, self._del_button, self._accept_button):
            hbox.add(i)

        g.pack_end(hbox, expand=False)
        self.on_port_change()

    def draw(self):
        """Draw Widget."""
        self.draw_list(
            (self._draw_list_group, self.draw_process_group),
            ("Remove Material ", "")
        )
        self.roller_win.gtk_win.vbox.set_size_request(350, 350)

    def get_group_value(self):
        """
        Provide the value of the ChoiceList.

        Return: list
            [string, ...] -> [material, ...]
        """
        return self._choice_list.item_q

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return lambda: None, self.on_accept_material

    def _on_choice_list_keypress(self, _, event):
        """
        Respond to ChoiceList Treeview keypress. Determine
        if the keypress is a Delete key, call the
        confirmation dialog.

        _: Treeview
        event: GTK Event
        """
        if gtk.gdk.keyval_name(event.keyval) == 'Delete':
            self.delete_item()
            return True

    def on_accept_material(self, *_):
        return self.get_group_value()

    def on_port_change(self, *_):
        """
        Respond to a choice list change.

        _: tuple
            not used
        """
        g = self._del_button
        if g:
            g.enable() if self._get_selection() is not None else g.disable()
