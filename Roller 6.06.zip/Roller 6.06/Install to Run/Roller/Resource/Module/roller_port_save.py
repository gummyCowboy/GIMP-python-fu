#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_a_oz import make_preset_path, make_preset_name, pickle_dump
from roller_constant_for import Preset as fp, Widget as fw
from roller_constant_key import Button as bk, Preset as pk, Widget as wk
from roller_fu_comm import pop_up
from roller_port import Port
from roller_widget_box import Eventful
from roller_widget_button import AcceptButton, CancelButton
from roller_widget_entry import Entry
from roller_widget_label import Label
from roller_widget_row import WidgetRow
from roller_widget_splitter import Splitter
import gtk  # type: ignore
import os
import platform

DUPLICATE_FILE = \
    "The file,\n\n{},\n\nalready exists. " \
    "Do you want to overwrite the existing file?"

# Reference
# en.wikipedia.org/wiki/Filename#Reserved_characters_and_words
INVALID_CHAR = "/?%*:|<>" + '"' + "'" + "\\"


def save_file(gtk_win, d, key, n, is_overwrite=False):
    """
    Save a Preset to a file after checking if it already
    exists and possibly asking for permission to overwrite.

    gtk_win: GTK Window
        Is responsible.

    d: dict
        Preset or SuperPreset

    key: string
        Preset key

    n: string
        second part of the file path
        file name

    is_overwrite: bool
        If it's False, a pop-up will confirm a file over-write.

    Return: bool
        Is True if the file was written without error.
    """
    # When in Windows OS, remove invalid file name characters.
    if platform.system() == "Windows":
        for i in INVALID_CHAR:
            n = n.replace(i, "")

    # Replace the PRESET_SEPARATOR for the Preset file-path.
    n = n.replace(fp.PRESET_SEPARATOR, "-")
    path = make_preset_path(key, n)
    go = True

    if not is_overwrite:
        if path:
            if os.path.isfile(path):
                n = DUPLICATE_FILE.format(path)
                go = pop_up(gtk_win, 0, n, "Duplicate File")

    if go:
        go = pickle_dump(d, path)
    return go


class PortSave(Port):
    """Interactively save a Preset."""
    preset_name = "New Preset"
    window_key = "Save Preset"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: Button
            Is responsible.
        """
        self._file_name_label = \
            self._file_name_entry = \
            self._save_button = None
        self.group_key = g.any_group.item.key
        Port.__init__(self, d, g)

    def _draw_file_info_group(self, g):
        """
        Display the Preset file's location.

        g: GTK container
            Contain and display Widget.
        """
        w = fw.MARGIN
        w1 = w // 2

        self.reduce_color()

        n = os.path.dirname(make_preset_path(self.group_key, ""))
        drive, path = os.path.splitdrive(n)
        g1 = Splitter(padding=(w1, w1, w, w), has_inner_padding=True)
        g2 = Eventful(self.color)
        g3 = gtk.VBox()

        self.reduce_color()

        g4 = Eventful(self.color)
        g5 = gtk.VBox()
        g6 = self._file_name_label = Label(text="")

        g2.add(g3)
        g4.add(g5)
        g1.both(g2, g4)
        g3.add(Label(text="Drive:"))
        g3.add(Label(text="Folder:"))
        g3.add(Label(text="File Name:"))
        g5.add(Label(text=drive))
        g5.add(Label(text=path))
        g5.add(g6)
        g1.no_pack()
        g.add(g1.container)
        self._draw_file_name(self._file_name_entry)

    def _draw_file_name(self, g):
        """
        Call whenever the Preset name entry changes. Update
        the file location group with the latest file name.

        g: GTK Entry
            file name Entry
        """
        if self._file_name_label:
            n = make_preset_name(self.group_key, g.get_a())

            self._file_name_label.widget.set_text(n)
            if self._save_button:
                if g.get_a().lower() in (pk.DEFAULT.lower(),):
                    self._save_button.disable()
                else:
                    self._save_button.enable()

    def _draw_process_group(self, vbox):
        """
        Draw the Cancel and Save Buttons for the Port.

        vbox: VBox
            Contain and display Widget.
        """
        button_row = WidgetRow(
            **{
                wk.PADDING: (0, 0, fw.MARGIN, fw.MARGIN),
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win,
                wk.SUB: OrderedDict([
                    (bk.CANCEL, {wk.WIDGET: CancelButton}),
                    (bk.ACCEPT, {wk.WIDGET: AcceptButton})
                ])
            }
        )

        # AcceptButton index, '1'
        self._save_button = button_row.widget_q[1]

        vbox.add(button_row)
        self.keep(button_row)

    def _draw_variable_group(self, vbox):
        """
        Create an Entry for naming the Preset.

        vbox: VBox
            Contain and display Widget.
        """
        w = fw.MARGIN
        w1 = w // 2
        g = self._file_name_entry = Entry(
            padding=(0, w1, w, w),
            relay=[self._draw_file_name],
            roller_win=self.roller_win
        )

        vbox.add(Label(padding=(w1, 0, w, w), text="Preset Name:"))
        vbox.add(g)
        g.set_a(PortSave.preset_name)
        g.widget.select_region(0, -1)

    def draw(self):
        """Draw Port Widget."""
        # function to draw an option group, 'process_q'
        process_q = (
            self._draw_variable_group,
            self._draw_file_info_group,
            self._draw_process_group
        )

        label_q = (
            "Type: {}\n".format(self.group_key), "\nFile Location:", ""
        )

        for x, p in enumerate(process_q):
            box = Eventful(self.color)
            vbox = gtk.VBox()

            box.add(vbox)
            self.add(box)

            if label_q[x]:
                vbox.add(Label(text=label_q[x], padding=(2, 0, 4, 0)))

            p(vbox)
            self.reduce_color()

    def accept_save_window(self, *_):
        """Save the Preset to a file."""
        d = self.repo.any_group.get_preset_g().get_a()
        n = self._file_name_entry.get_a()
        if save_file(self.roller_win.gtk_win, d, self.group_key, n):
            PortSave.preset_name = n

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return lambda: None, self.accept_save_window
