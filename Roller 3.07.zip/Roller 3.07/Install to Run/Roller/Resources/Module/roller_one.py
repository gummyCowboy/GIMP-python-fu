#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from math import sqrt
from random import randint
from roller_constant_for import Preset as fp, Widget as fw
from roller_constant_key import Option as ok, Pickle as pc

# 'cpickle' is not available in Python 3:
import cPickle

import gimpfu as fu
import gtk
import os
import random
import sys

pdb = fu.pdb


class Base:
    """Has functions used my multiple classes."""

    @staticmethod
    def circumradius(w, h):
        """
        Calculate the half-diagonal of a rectangle.

        Return: int
        """
        return int(sqrt(w**2 + h**2) // 2)

    @staticmethod
    def copy_sel_dict(d):
        """
        deepcopy can't copy a GIMP selection, so this is a work-around.

        d: dict
            with GIMP selection values

        Return: dict
            the copy
        """
        return {a: k for a, k in d.items()}

    @staticmethod
    def create_2d_table(r, c, init=0, deep=0):
        """
        Return a 2D list.

        r, c: int
            size of the table

        init: value
            to init table with

        deep: flag
            When it is true, the init value is deep-copied.
        """
        b = [init] * r

        for i in range(r):
            if deep:
                b[i] = [0] * c
                for j in range(c):
                    b[i][j] = deepcopy(init)
            else:
                b[i] = [init] * c
        return b

    @staticmethod
    def enumerate_name(n, q):
        """
        Enumerate a name given a list of names.

        Ensure the name is unique as in a key.

        n: string
            name

        q: list
            list of names
            of string

        Return: string
            the enumerated name
        """
        while n[-1].isdigit():
            n = n[:-1]

        n = n.strip()
        a = 1
        go = True

        while go:
            go = False
            n1 = n + " " + str(a)
            if n1 in q:
                a += 1
                go = True
        return n1

    @staticmethod
    def rnd_col():
        """Return a tuple of integers containing random colors (r, g, b)."""
        return randint(0, 255), randint(0, 255), randint(0, 255)

    @staticmethod
    def seal(a, b, c):
        """
        Limit a numeric value to be between two numbers.

        a: value
            to limit

        b: value
            minimum amount

        c: value
            maximum amount

        Return: value
            within seal
        """
        return max(min(c, a), b)


class OZ:
    """
    Has functions that work with the
    operating system or with files.
    """

    @staticmethod
    def ensure_dir(n):
        """
        Ensure a directory exists.

        n: string
            path

        Return two flags.
            err: bool
                error flag

            go: bool
                If it is true, then the operation was successful.
        """
        go = err = False

        if n and not os.path.isdir(os.path.dirname(n)):
            try:
                os.makedirs(os.path.dirname(n))
            except Exception as ex:
                err = True
                Comm.show_err(ex)
                Comm.show_err("Roller is unable to store files at\n" + n)

        else:
            go = True
        return err, go

    @staticmethod
    def get_preset_name(n, n1):
        """
        Construct a preset file name.

        n: string
            preset name

        n1: string
            file specific id

        Return: string
            preset name
        """
        return n + fp.PRESET_SEPARATOR + n1 + ".pkl"

    @staticmethod
    def get_preset_path(n, n1, _dir):
        """
        Construct a path to a preset.

        n: string
            preset name or key

        n1: string
            file id

        _dir: string
            preset root directory

        Return: string
            preset path
        """
        n2 = os.path.join(_dir, n)
        n3 = os.path.join(n2, OZ.get_preset_name(n, n1))
        return n3

    @staticmethod
    def pickle_dump(d):
        """
        Write a file using 'cPickle'.

        d: dict
            of Pickle

        Return: flag
            Is set to true if the operation succeeded.
        """
        go = False
        n = d[pc.FILE]
        err, _ = OZ.ensure_dir(n)

        if not err:
            try:
                with open(n, "wb") as output_file:
                    cPickle.dump(d[pc.DATA], output_file)
                go = True
            except Exception as ex:
                Comm.show_err(ex)
                Comm.show_err("Roller is unable to save\n" + n)
        return go

    @staticmethod
    def pickle_load(d):
        """
        Read a 'cPickle' type file.

        d: dict
            of Pickle

        Return: dict or None
            the data read in
        """
        e = None
        n = d[pc.FILE]
        err, go = OZ.ensure_dir(n)

        if go and not err:
            try:
                with open(n, "rb") as input_file:
                    e = cPickle.load(input_file)
                    if not isinstance(e, dict):
                        # failure:
                        e = {}
            except Exception as ex:
                if pc.SHOW_ERROR in d:
                    if d[pc.SHOW_ERROR]:
                        Comm.show_err(ex)
                        Comm.show_err("Roller is unable to load\n" + n)
        return e


class Comm:
    """Has functions that are used to communicate."""

    @staticmethod
    def info_msg(n):
        """
        Use to output messages to the error console.

        n: message
        """
        a = pdb.gimp_message_get_handler()
        n = n if isinstance(n, str) else str(n)

        pdb.gimp_message_set_handler(fu.ERROR_CONSOLE)
        fu.gimp.message(n)
        pdb.gimp_message_set_handler(a)

    @staticmethod
    def pop_up(window, x, n, title):
        """
        Display a message dialog.

        window: window
            GTK window
            parent

        x: int
            message type index
            (question, info)
            0, 1

        n: string
            message

        title: string
            window title

        Return: flag
            It is true if the user responded with yes.
        """
        g = gtk.MessageDialog(
            parent=window,
            flags=gtk.DIALOG_MODAL,
            type=(gtk.MESSAGE_QUESTION, gtk.MESSAGE_INFO)[x],
            buttons=(gtk.BUTTONS_YES_NO, gtk.BUTTONS_CLOSE)[x],
            message_format=n
        )

        g.set_title(title)

        a = g.run()

        g.destroy()
        return int(a == gtk.RESPONSE_YES)

    @staticmethod
    def show_err(a):
        """
        Post an error message to GIMP's error console.

        a: Exception or string
            to show
        """
        # Python 3 does not have basestring:
        if not isinstance(a, basestring):
            a = repr(a)
        Comm.info_msg(a)


class GroupId:
    """Is part of grid and custom cell name id management system."""

    def __init__(self):
        """Initialize the database."""
        self._db = {}

    def change_name(self, _id, n):
        """
        Call when the user renames an item.

        _id: int
            item id

        n: string
            new item name
        """
        self._db[_id] = n

    def delete_id(self, n):
        """Remove an id using the group key."""
        q = [i for i in self._db]
        for i in q:
            if self._db[i] == n:
                self._db.pop(i)
                break

    def get_id(self, n):
        """
        Get the id from an item name.

        n: string
            item name

        Return: int
            id for item
            Is None if the item is not found.
        """
        for i, a in self._db.items():
            if a == n:
                return i

    def get_name(self, _id):
        """
        Get the name from an item id.

        _id: int
            item id

        Return: string
            name for item
            Is None if the id is not found.
        """
        if _id in self._db:
            return self._db[_id]

    def make_id(self, n):
        """
        Assign an id to an item name.

        n: string
            item name

        Return: int
            item id
        """
        self.delete_id(n)

        _id = 0

        while _id not in self._db:
            _id = randint(-sys.maxint, sys.maxint)
            if _id not in self._db:
                self._db[_id] = n
        return _id


class Hat:
    """Is the cat in the hat."""
    # Cat won't import directly due to circular references.
    # This reference is initialized early and
    # is an indirect method to access Cat:
    cat = None


class Mode:
    _q = [
        ("Normal", fu.LAYER_MODE_NORMAL),
        ("Dissolve", fu.LAYER_MODE_DISSOLVE),
        ("Color Erase", fu.LAYER_MODE_COLOR_ERASE),
        ("Erase", fu.LAYER_MODE_ERASE),
        ("Merge", fu.LAYER_MODE_MERGE),
        ("Split", fu.LAYER_MODE_SPLIT),
        (fw.LIST_SEPARATOR, None),
        ("Lighten Only", fu.LAYER_MODE_LIGHTEN_ONLY),
        ("Luma Lighten Only", fu.LAYER_MODE_LUMA_LIGHTEN_ONLY),
        ("Screen", fu.LAYER_MODE_SCREEN),
        ("Dodge", fu.LAYER_MODE_DODGE),
        ("Addition", fu.LAYER_MODE_ADDITION),
        (fw.LIST_SEPARATOR * 2, None),
        ("Darken Only", fu.LAYER_MODE_DARKEN_ONLY),
        ("Luma Darken Only", fu.LAYER_MODE_LUMA_DARKEN_ONLY),
        ("Multiply", fu.LAYER_MODE_MULTIPLY),
        ("Burn", fu.LAYER_MODE_BURN),
        ("Linear Burn", fu.LAYER_MODE_LINEAR_BURN),
        (fw.LIST_SEPARATOR * 3, None),
        ("Overlay", fu.LAYER_MODE_OVERLAY),
        ("Hard Light", fu.LAYER_MODE_HARDLIGHT),
        ("Soft Light", fu.LAYER_MODE_SOFTLIGHT),
        ("Vivid Light", fu.LAYER_MODE_VIVID_LIGHT),
        ("Pin Light", fu.LAYER_MODE_PIN_LIGHT),
        ("Linear Light", fu.LAYER_MODE_LINEAR_LIGHT),
        ("Hard Mix", fu.LAYER_MODE_HARD_MIX),
        (fw.LIST_SEPARATOR * 4, None),
        ("Difference", fu.LAYER_MODE_DIFFERENCE),
        ("Exclusion", fu.LAYER_MODE_EXCLUSION),
        ("Subtract", fu.LAYER_MODE_SUBTRACT),
        ("Divide", fu.LAYER_MODE_DIVIDE),
        ("Grain Extract", fu.LAYER_MODE_GRAIN_EXTRACT),
        ("Grain Merge", fu.LAYER_MODE_GRAIN_MERGE),
        (fw.LIST_SEPARATOR * 5, None),
        ("LCH Lightness", fu.LAYER_MODE_LCH_LIGHTNESS),
        ("LCH Chroma", fu.LAYER_MODE_LCH_CHROMA),
        ("LCH Hue", fu.LAYER_MODE_LCH_HUE),
        ("LCH Color", fu.LAYER_MODE_LCH_COLOR),
        ("Luminance", fu.LAYER_MODE_LUMINANCE),
        (fw.LIST_SEPARATOR * 6, None),
        ("HSV Hue", fu.LAYER_MODE_HSV_HUE),
        ("HSV Saturation", fu.LAYER_MODE_HSV_SATURATION),
        ("HSV Value", fu.LAYER_MODE_HSV_VALUE),
        ("HSL Color", fu.LAYER_MODE_HSL_COLOR)
    ]

    # Use with DensityGradient:
    GRADIENT_MODE_LIST = (
        "Lighten Only",
        "Luma Lighten Only",
        "Screen",
        "Dodge",
        "Addition",
        "Darken Only",
        "Multiply",
        "Burn",
        "Linear Burn",
        "Overlay",
        "Soft Light",
        "Hard Light",
        "Vivid Light",
        "Linear Light",
        "Difference",
        "Exclusion",
        "Subtract",
        "Grain Extract",
        "Grain Merge",
        "Divide",
        "HSL Color",
        "HSV Value",
        "LCH Color"
    )

    # Use with PaintRush:
    EDGE_MODE = (
        "Normal",
        "Lighten Only",
        "Screen",
        "Overlay",
        "Soft Light",
        "Hard Light",
        "Difference",
        "Subtract",
        "Grain Extract",
        "Grain Merge",
        "Divide",
        "HSV Value",
        "HSV Saturation",
        "HSL Color",
        "LCH Lightness",
        "Luminance"
    )

    _d = OrderedDict(_q)
    names = _d.keys()

    @staticmethod
    def get_(d):
        """
        Get the enum mode from a English translation.

        d: dict
            Has a MODE option.

        Return: enum
            of layer mode
        """
        return Mode._d[d[ok.MODE]]

    @staticmethod
    def rand():
        """Return a randomly selected mode (int)."""
        n = fw.LIST_SEPARATOR
        q = Mode.names

        while fw.LIST_SEPARATOR in n:
            n = random.choice(q)
        return n


class One(object):
    """Use to pass around data."""

    def __init__(self, **d):
        """
        Is an object. All is one.
        Add attributes to the object.

        d: dict
            Has 'keyword, value' pairs that form attributes.
        """
        for k, a in d.items():
            setattr(self, k, a)


class Rect(object):
    """Define a rectangle."""

    def __init__(self, position, size):
        """
        Create useful fields that define a rectangle.

        position: tuple
            x, y
            of rectangle

        size: tuple
            width, height
            of rectangle
        """
        self.x, self.y = position
        self.w, self.h = size

    @property
    def clone(self):
        """Make a copy of the rectangle and return the copy."""
        return Rect((self.x, self.y), (self.w, self.h))

    @property
    def position(self):
        """Return the rectangle position."""
        return self.x, self.y

    @position.setter
    def position(self, value):
        """Set the rectangle position."""
        self.x, self.y = value

    @property
    def size(self):
        """Return the rectangle size."""
        return self.w, self.h

    @size.setter
    def size(self, value):
        """Set the rectangle size."""
        self.w, self.h = value
