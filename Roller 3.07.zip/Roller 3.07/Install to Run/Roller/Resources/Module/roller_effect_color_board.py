#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
import gimpfu as fu

pdb = fu.pdb


def process_layer(j, image_layer, one):
    """
    Add a frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    one: One
        Has variables.

    Return: layer or None
        with frame material
    """
    cat = Hat.cat
    d = one.d
    if d[ok.OPACITY]:
        parent = image_layer.parent
        Sel.make_layer_sel(image_layer)

        sel = cat.save_short_term_sel()

        Sel.grow(j, d[ok.FRAME_WIDTH], d[ok.FRAME_TYPE])
        Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

        z = Lay.add(j, Lay.name(parent, one.k), parent=parent)

        Sel.fill(z, d[ok.COLOR])
        pdb.plug_in_antialias(j, z)

        z = GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)
        z.opacity = d[ok.OPACITY]
        return z


class ColorBoard:
    """Create a an color edge around an image(s)."""

    @staticmethod
    def do(one):
        """
        Do the Colored Board image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer, list, or None
            with frame
        """
        z = one.image_layer
        j = z.image

        if one.is_image_group:
            undo_z = []
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], one)]
            one.shadow_layer = [z]

        else:
            undo_z = process_layer(j, z, one)
            one.shadow_layer = [undo_z, z]
        return undo_z
