#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg, Plan as fy
from roller_constant_fu import Fu
from roller_constant_key import Model as md, Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
CUSTOM = fy.CUSTOM_CELL


def do_grid(j, z, group, one):
    """
    Do the effect for each image in the cell grid.

    j: GIMP image
        Is render.

    z: layer
        to receive effect

    group: layer
        Has parent with name which has an appended z-height.

    one: One
        Has options.
    """
    def do():
        Hat.cat.join_selection(one.model_name, r, c)
        process_image(j, z, one)

    # Do one image at a time:
    cat = Hat.cat
    d = one.grid.grid_d
    is_merge_cell = one.grid.is_merge_cell
    n = group.parent.name.split(" ")[-1]
    s = 1
    for r in range(one.r):
        for c in range(one.c):
            if is_merge_cell:
                s = d[ok.PER_CELL][r][c]

            # Is it a dependent cell?
            if s != (-1, -1):
                if one.is_image_group:
                    if cat.get_z_height((one.model_name, r, c)) == n:
                        do()
                else:
                    do()


def process_image(j, z, one):
    """
    Do the effect for an image.

    j: GIMP image
        Is render.

    z: layer
        to receive effect

    one: One
        Has options.
    """
    if Sel.is_sel(j):
        d = one.d

        Sel.grow(j, d[ok.FRAME_WIDTH], 1)

        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(d[ok.SHAPE_BURST]),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            (x1 + x) / 2, (y1 + y) / 2,
            x, y
        )


def process_layer(j, image_layer, one):
    """
    Add a frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    one: One
        Has variables.

    Return: layer or None
        with frame material
    """
    d = one.d
    parent = image_layer.parent
    group = Lay.group(j, Lay.name(parent, one.k), parent=parent)
    z = Lay.add(j, one.k, parent=group)

    RenderHub.set_fill_context(fg.FILL_DICT)
    pdb.gimp_context_set_gradient(d[ok.GRADIENT])
    pdb.gimp_context_set_gradient_blend_color_space(
        fu.GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(d[ok.REVERSE])

    if one.context == md.TABLE:
        do_grid(j, z, group, one)

    else:
        # custom cell:
        r = CUSTOM
        Hat.cat.join_selection(one.model_name, r, r)
        process_image(j, z, one)

    z = Lay.merge_group(group)

    pdb.gimp_selection_none(j)

    if d[ok.INVERT]:
        pdb.gimp_drawable_invert(z, 0)

    if d[ok.UNSHARP_AMOUNT] and d[ok.UNSHARP_RADIUS]:
        Gegl.unsharp_mask(z, d[ok.UNSHARP_RADIUS], d[ok.UNSHARP_AMOUNT], .0)
        Gegl.blur(z, .5)

    Lay.clear_image_sel(image_layer, z)
    return GradientLight.apply_light(z, ok.OTHER_FRAME)


class ShapeBurst:
    """Create a border from a shape-burst type of gradient."""

    @staticmethod
    def do(one):
        """
        Do the image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer or None
            with frame
        """
        j = Hat.cat.render.image
        z = one.image_layer

        if not one.is_image_group:
            undo_z = process_layer(j, z, one)
            one.shadow_layer = [undo_z, z]
        else:
            # 'undo_z' is a list of layers for the preview's undo function:
            undo_z = []
            one.shadow_layer = [z]
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], one)]
        return undo_z
