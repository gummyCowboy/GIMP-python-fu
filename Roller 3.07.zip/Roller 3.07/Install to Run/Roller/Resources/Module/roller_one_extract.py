#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Grid as gr,
    Group as og,
    Plan as fy,
    Margin as fm,
    Shape as sh,
    Triangle as ft
)
from roller_constant_key import (
    Option as ok,
    Path as pa,
    Step as sk,
    Widget as wk
)
from roller_one import Base, Hat, Rect
import math


class Path:
    """Organize path functions. These are step-key paths."""

    @staticmethod
    def get_cell_caption_chunk(path):
        """
        Get a cell caption dict of the chunk type.
        The chunk includes the per cell table.

        path: tuple
            of model

        Return: dict
            of cell caption chunk
        """
        return Path.get_dict_from_path(path[:3] + (pa.IMAGE, pa.CAPTION))

    @staticmethod
    def get_cell_caption_form(path, r, c):
        """
        Get a cell caption dict of the form type.

        path: tuple
            of model

        r, c: int
            cell index

        Return: dict
            of cell caption form
        """
        path = path[:3] + (pa.IMAGE, pa.CAPTION)
        d = Path.get_dict_from_path(path)

        if r == fy.CUSTOM_CELL:
            return d

        q = d[ok.PER_CELL]
        return q[r][c] if q else d

    @staticmethod
    def get_cell_margin(path):
        """
        Get a cell margin chunk.
        A chunk has the source group and a per cell table.

        path: tuple
            of model

        Return: dict
            of cell margin chunk
        """
        return Path.get_dict_from_path(path[:3] + (pa.CELL, pa.MARGIN))

    @staticmethod
    def get_cell_place_chunk(path):
        """
        Get a cell place form.
        A form is the source dict or a dict from its per cell table.

        path: tuple
            of model

        Return: dict
            of cell place form
        """
        return Path.get_dict_from_path(path[:3] + (pa.IMAGE, pa.PLACE))

    @staticmethod
    def get_cell_place_form(path, r, c):
        """
        Get a cell place form.
        A form is the source dict or a dict from its per cell table.

        path: tuple
            of model

        Return: dict
            of cell place form
        """
        path = path[:3] + (pa.IMAGE, pa.PLACE)
        d = Path.get_dict_from_path(path)

        if r == fy.CUSTOM_CELL:
            return d

        q = d[ok.PER_CELL]
        return q[r][c] if q else d

    @staticmethod
    def get_cell_plaque(path):
        """
        Get a cell plaque chunk.
        A chunk has the source group and a per cell table.

        path: tuple
            of model

        Return: dict
            of cell plaque chunk
        """
        return Path.get_dict_from_path(path[:3] + (pa.CELL, pa.PLAQUE))

    @staticmethod
    def get_dict_from_path(path, add_per_cell=True):
        """
        Get a widget-key-based dict from a group of widgets.

        Return: dict
            of widget key, widget value pairs
        """
        d = {}
        e = Hat.cat.group_dict

        # OptionGroup 'a' and 'b':
        a = e[path]
        d1 = a.d

        for i, g in d1.items():
            # The Preset widget is not part of the group:
            if i != wk.PRESET:
                d[i] = g.get_value()

        if add_per_cell:
            # Include per cell:
            if hasattr(a.vbox, og.PER_CELL_GROUP):
                d[ok.PER_CELL] = a.vbox.per_cell_group.get_value()

        return d

    @staticmethod
    def get_layer_plaque(path):
        """
        Get a layer plaque dictionary.

        path: tuple
            Has grid.
        """
        return Path.get_dict_from_path(Path.make_layer_plaque_path(path))

    @staticmethod
    def get_model_name_list():
        """
        Get a list of model names corresponding with the models.
        """
        return Hat.cat.group_dict[sk.MODEL].d[ok.MODEL_LIST].get_value()

    @staticmethod
    def get_model_path_list():
        """
        Get a list of model paths corresponding with the models.
        """
        q = Hat.cat.group_dict[sk.MODEL].d[ok.MODEL_LIST].get_value()
        q1 = []

        for i in q:
            q1 += [sk.EFFECT + (Hat.cat.group_id.get_id(i),)]
        return q1

    @staticmethod
    def get_grid_from_path(path, add_per_cell=True):
        """
        Get a widget-key-based grid dict.

        path: tuple
            of model
            Has to include grid id.

        Return: dict
            of widget key, widget value pairs
            of grid
        """
        path = path[:3] + (pa.CELL, pa.GRID)
        d = {}
        e = Hat.cat.group_dict

        # OptionGroup 'a' and 'b':
        a = e[path]
        d1 = a.d

        for i, g in d1.items():
            # The Preset widget is not part of the group:
            if i != wk.PRESET:
                d[i] = g.get_value()

        if add_per_cell:
            # Include per cell.
            path = Path.make_per_cell_path(path)
            if path in e:
                d[ok.PER_CELL] = e[path].d[ok.PER_CELL].get_value()
        return d

    @staticmethod
    def get_layer_margin(path):
        """
        Get a grid's layer margins.

        path: tuple
            of sub-steps

        Return: tuple
            top, bottom, left, right
            of int
        """
        return Form.combine_margin(
            Path.get_dict_from_path(
                path[:3] + (pa.LAYER, pa.MARGIN),
                add_per_cell=False
            ),
            *Hat.cat.render.size
        )

    @staticmethod
    def get_rectangle_dict(path):
        """
        Get a custom cell rectangle dictionary.

        path: tuple
            Has custom cell model.
        """
        return Path.get_dict_from_path(
            path[:3] + (pa.CELL, pa.RECTANGLE),
            add_per_cell=False
        )

    @staticmethod
    def has_margin(d):
        """
        Determine if a cell has a cell margin.

        d: dict
            of margins, form

        r, c: int
            cell index

        Return: bool
            Is true if the margin dict has a value other than zero.
        """
        for a in d.values():
            if a:
                return True
        return False

    @staticmethod
    def make_cell_margin_path(path):
        """
        Make a path to a cell margin group.

        path: tuple
            of model

        Return: tuple
            path-key
        """
        return path[:3] + (pa.CELL, pa.MARGIN)

    @staticmethod
    def make_cell_place_path(path):
        """
        Make a path to an image place group.

        path: tuple
            of model

        Return: tuple
            path-key
        """
        return path[:3] + (pa.IMAGE, pa.PLACE)

    @staticmethod
    def make_cell_plaque_path(path):
        """
        Make a path to an cell plaque group.

        path: tuple
            of model

        Return: tuple
            path-key
        """
        return path[:3] + (pa.CELL, pa.PLAQUE)

    @staticmethod
    def make_grid_path(path):
        """
        Make a path to a grid group.

        path: tuple
            of sub-steps

        Return: tuple
            path-key
        """
        return path[:3] + (pa.CELL, pa.GRID)

    @staticmethod
    def make_layer_plaque_path(path):
        """
        Make a path to a layer plaque group.

        path: tuple
            of sub-steps

        Return: tuple
            path-key
        """
        return path[:3] + (pa.LAYER, pa.PLAQUE)

    @staticmethod
    def make_per_cell_path(path):
        """
        Create a path from a option group to its Per Cell group.

        Return: tuple
            the path to the option's attached Per Cell group
        """
        return path[:-1] + (path[-1] + ", Per Cell",)


class Form:
    """Organize functions that work with an option group dictionaries."""

    @staticmethod
    def combine_margin(d, w, h):
        """
        Return the margins after adding the fixed-value
        and the factor margins together.

        d: dict
            of margin

        w: int
            width bounds
            from layer or cell

        h: int
            height bounds
            from layer or cell

        Return: list
            top, bottom, left, right
            of int
        """
        margin = [0] * 4

        # Combine fixed and factor:
        for x, q in enumerate(fm.MARGIN_KEY_V):
            margin[x] = int(d[q[0]] + d[q[1]] * h)

        for x, q in enumerate(fm.MARGIN_KEY_H):
            margin[x + 2] = int(d[q[0]] + d[q[1]] * w)

        # Compensate for margin overflow
        # by reserving one pixel for the image:
        if margin[fm.TOP] + margin[fm.BOTTOM] >= h:
            margin[fm.TOP] = h // 2
            margin[fm.BOTTOM] = h - margin[fm.TOP] - 1

        if margin[fm.LEFT] + margin[fm.RIGHT] >= w:
            margin[fm.LEFT] = w // 2
            margin[fm.RIGHT] = w - margin[fm.LEFT] - 1
        return margin

    @staticmethod
    def get_custom_cell_rect(d):
        """
        Calculate a custom cell rectangle.

        d: dict
            of custom cell's rectangle
        """
        s = Hat.cat.render.size
        return Rect(
            (
                d[ok.FIXED_POSITION_X] + int(d[ok.FACTOR_POSITION_X] * s[0]),
                d[ok.FIXED_POSITION_Y] + int(d[ok.FACTOR_POSITION_Y] * s[1])
            ),
            (
                max(1, d[ok.FIXED_WIDTH] + int(d[ok.FACTOR_WIDTH] * s[0])),
                max(1, d[ok.FIXED_HEIGHT] + int(d[ok.FACTOR_HEIGHT] * s[1]))
            )
        )

    @staticmethod
    def get_form(d, r, c):
        """
        Get the form dictionary, source or per cell.

        d: dict
            form dict

        r, c: int
            cell index in the cell table
            Is valid if there is a cell table.
        """
        if ok.PER_CELL in d:
            return d[ok.PER_CELL][r][c] if d[ok.PER_CELL] else d
        return d

    @staticmethod
    def get_image_rotate(d, r, c):
        """
        Get the rotation value from image place chunk.

        d: dict
            image place chunk

        r, c: int
            row, column of image in cell table

        Return: float
            of image rotation
        """
        return Form.get_form(d, r, c)[ok.ROTATE]


class Shape:
    """Organize functions related to cell and mask shape."""

    @staticmethod
    def calc_hexagon_horizontal_offset(w, h):
        """
        Calculate offsets of a horizontal hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            offsets
        """
        return w / 2, h / 4, h / 2, h / 4 * 3

    @staticmethod
    def calc_hexagon_horizontal_shape(x, y, w, h, q):
        """
        Calculate offsets of a vertical hexagon.

        w, h: numeric
            rectangle

        q: tuple
            of offsets

        Return: tuple
            of shape
            for the select polygon function
        """
        w1, h1, _, h2 = q
        # The first point is the topleft.
        # The points connect clockwise:
        return (
            x, y + h1,
            x + w1, y,
            x + w, y + h1,
            x + w, y + h2,
            x + w1, y + h,
            x, y + h2
        )

    @staticmethod
    def calc_hexagon_vertical_offset(w, h):
        """
        Calculate offsets of a vertical hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            offsets
        """
        return w / 4, w / 2, w / 4 * 3, h / 2

    @staticmethod
    def calc_hexagon_vertical_shape(x, y, w, h, q):
        """
        Calculate shape of a vertical hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            of x, y pairs
            for the select polygon function
        """
        w1, w2, w3, h1 = q
        # The first point is the topleft.
        # The points connect clockwise:
        return (
            x, y + h1,
            x + w1, y,
            x + w3, y,
            x + w, y + h1,
            x + w3, y + h,
            x + w1, y + h,
        )

    @staticmethod
    def calc_horizontal_ellipse(rect):
        """
        Calculate the rectangle shape for a horizontal ellipse.

        rect: Rect
            bounding rectangle for an ellipse

        Return: dict
            with shape
        """
        h = int(round(rect.h * sh.ELLIPSE_RATIO))
        return {'x': rect.x, 'y': rect.y, 'w': rect.w, 'h': rect.h - h}

    @staticmethod
    def calc_lock(s, t):
        """
        Return the size of an image that will fit into a smaller cell.

        s: tuple
            of int
            cell size
            (w, h)
            Conform image size to this size.

        t: tuple
            of int
            image size
            (w, h)
        """
        w_r = float(t[0]) / s[0]
        h_r = float(t[1]) / s[1]

        if w_r > h_r:
            w, h = s[0], int(t[1] * (s[0] / float(t[0])))

        else:
            w, h = int(t[0] * (s[1] / float(t[1]))), s[1]
        return max(w, 1), max(h, 1)

    @staticmethod
    def calc_octagon_aligned_offset(w, h):
        """
        Calculate the offsets of an align octagon using a ratio.

        w, h: numeric
            size of cell

        Return: tuple
            of offsets
        """
        # Use ratio:
        w1 = int(w * sh.OCTAGON_RATIO)
        w2 = w - w1
        h1 = int(h * sh.OCTAGON_RATIO)
        h2 = h - h1
        return w1, w2, h1, h2

    @staticmethod
    def calc_octagon_aligned_shape(x, y, w, h, q):
        """
        Calculate the shape of an align octagon using a ratio.

        x, y, w, h: float
            Defines rectangle.

        q: tuple
            of offsets for points

        Return: tuple
            of x, y pairs
            for select polygon function
        """
        w1, w2, h1, h2 = q

        # The first point is topleft.
        # The direction is clockwise:
        return (
            x + w1, y,
            x + w2, y,
            x + w, y + h1,
            x + w, y + h2,
            x + w2, y + h,
            x + w1, y + h,
            x, y + h2,
            x, y + h1
        )

    @staticmethod
    def calc_octagon_offset(w, h):
        """
        Calculate the offsets of a non-align octagon.

        w, h: numeric
            size of cell

        Return: tuple
            of offsets
        """
        # of cell rectangle:
        radius = Base.circumradius(w, h)

        w1 = w / 2.
        h1 = h / 2.
        angle = math.asin(h1 / radius)

        # The process for w2 is deliberately
        # not factored as it is a complex formula:
        _w = w1 * h1
        w2 = math.tan(angle)**2
        w2 = w2 * w1**2
        w2 = h1**2 + w2
        w2 = math.sqrt(w2)
        w2 = _w / w2
        h2 = w2 * math.tan(angle)
        w3 = w1 + w2
        w4 = w1 - w2
        h3 = h1 + h2
        h4 = h1 - h2
        return w4, w1, w3, h4, h1, h3

    @staticmethod
    def calc_octagon_shape(x, y, w, h, q):
        """
        Calculate the shape of an octagon using a ratio.

        x, y, w, h: float
            Defines rectangle.

        q: tuple
            of offsets for points

        Return: tuple
            of x, y pairs
            for select polygon function
        """
        w1, w2, w3, h1, h2, h3 = q

        # The first point is top-center.
        # The direction is clockwise:
        return (
            x + w2, y,
            x + w3, y + h1,
            x + w, y + h2,
            x + w3, y + h3,
            x + w2, y + h,
            x + w1, y + h3,
            x, y + h2,
            x + w1, y + h1
        )

    @staticmethod
    def calc_pin_offset(pin, s, w, h, x, y):
        """
        Calculate pin offset given the layer space.

        Fixed-sized cells have a pin corner. Their cell
        grid is pinned or connected to its pin corner.

        pin: string
            pin type

        s: tuple
            size
            w, h
            layer space

        w, h: int
            size of table

        x, y: int
            offset
        """
        if pin in gr.PINS_WITH_X_OFFSET:
            x1 = s[0] - w

            if pin == gr.CENTER:
                x1 //= 2
            x += x1

        if pin in gr.PINS_WITH_Y_OFFSET:
            y1 = s[1] - h

            if pin == gr.CENTER:
                y1 //= 2
            y += y1
        return x, y

    @staticmethod
    def calc_vertical_ellipse(rect):
        """
        Calculate the rectangle shape for a vertical ellipse.

        rect: Rect
            the bounding rectangle of the ellipse

        Return: dict
            with shape
        """
        w = int(round(rect.w * .135))
        return {'x': rect.x, 'y': rect.y, 'w': rect.w - w, 'h': rect.h}

    @staticmethod
    def get_point(q):
        """
        Returns a valid coordinate from a pair of coordinates.

        If the intersect coordinate is -1, then it is invalid.

        q: tuple
            intersect, pocket
            coordinates
        """
        return q[1] if q[0] == -1 else q[0]

    @staticmethod
    def is_allocated_cell(grid, r, c):
        """
        Determine if a cell is a valid cell in a table.
        Consider double-space shapes allocate every other cell.

        If the grid is not shifted, then only cells
        where the row and column have the same
        remainder when divided by two are valid.

        If the grid is shifted, then only cells
        where the row and column have different
        remainders when divided by two are valid.

        grid: Grid
            of cell table

        r, c: int
            row, column
            cell index

        double_type: enum
            a polarized and typed value

        Return: bool
            Is true if the cell is valid.
        """
        d = grid.grid_d
        if d:
            if grid.cell_shape in sh.DOUBLE:
                if d[ok.CELL_SHIFT]:
                    a = sh.SHIFT
                else:
                    a = sh.NOT_SHIFT
            else:
                a = sh.NOT_DOUBLE_SPACE

        else:
            a = grid.double_type

        if a == sh.NOT_DOUBLE_SPACE:
            return True

        elif a == sh.SHIFT:
            return (r % 2 and not c % 2) or (not r % 2 and c % 2)
        else:
            return (r % 2 and c % 2) or (not r % 2 and not c % 2)

    @staticmethod
    def is_rectangular_shape(shape):
        """
        Determine if a cell shape is rectangular.

        shape: string
            shape descriptor

        Return: bool
            Is true if the cell shape is rectangular shaped.
        """
        return shape in (sh.RECTANGLE, sh.SQUARE)

    @staticmethod
    def is_inverse_triangle(r, c):
        """
        Determine if a triangle is inverted,
        either vertically or horizontally.

        r, c: int
            row, column
            cell index

        Return: bool
            Is true when the triangle is inverted.
        """
        return (not r % 2 and c % 2) or (r % 2 and not c % 2)


class FromRect:
    """Has functions for calculating a cell shape."""

    @staticmethod
    def circle(rect):
        """
        Get a dictionary for a circle.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: dict
            Defines a rectangle bounds of an ellipse.
        """
        x, y = rect.position
        w, h = rect.size
        center_x, center_y = x + w // 2, y + h // 2
        w1 = min(w, h)
        x1 = center_x - w1 // 2
        y1 = center_y - w1 // 2
        return {'x': x1, 'y': y1, 'w': w1, 'h': w1}

    @staticmethod
    def diamond(rect):
        """
        Get the 4 points for a diamond.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a diamond polygon
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = (y + y1) / 2
        x2 = (x + x1) / 2
        return x, y2, x2, y, x1, y2, x2, y1

    @staticmethod
    def ellipse(rect):
        """
        Translate a rectangle into a dictionary for an ellipse.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: dict
            with key, value pairs that define a rectangle
        """
        return {'x': rect.x, 'y': rect.y, 'w': rect.w, 'h': rect.h}

    @staticmethod
    def hexagon_horz(rect):
        """
        Get 6 points of a horizontally aligned hexagon.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a horizontally aligned hexagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_hexagon_horizontal_shape(
            x, y,
            w, h,
            Shape.calc_hexagon_horizontal_offset(w, h)
        )

    @staticmethod
    def hexagon_vert(rect):
        """
        Get 6 points of a vertically aligned hexagon.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a vertically aligned hexagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_hexagon_vertical_shape(
            x, y,
            w, h,
            Shape.calc_hexagon_vertical_offset(w, h)
        )

    @staticmethod
    def octagon(rect):
        """
        Get 8 points of an octagon.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing an octagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_octagon_shape(
            x, y,
            w, h,
            Shape.calc_octagon_offset(w, h)
        )

    @staticmethod
    def octagon_align(rect):
        """
        Get a 8 points of an aligned octagon.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing an aligned octagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_octagon_aligned_shape(
            x, y,
            w, h,
            Shape.calc_octagon_aligned_offset(w, h)
        )

    @staticmethod
    def rectangle(rect):
        """
        Translate a rectangle into tuple of x, y
        coordinates for drawing a rectangle polygon.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a rectangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        return x, y, x1, y, x1, y1, x, y1

    @staticmethod
    def square(rect):
        """
        Get 4 points for a square from the
        topleft corner with consecutive clock-wise order.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a square
        """
        x, y = rect.position
        w, h = rect.size
        center_x, center_y = x + w // 2, y + h // 2
        w1 = min(w, h)
        x1 = center_x - w1 // 2
        y1 = center_y - w1 // 2
        x2, y2 = x1 + w1, y1 + w1
        return x1, y1, x2, y1, x2, y2, x1, y2

    @staticmethod
    def triangle_down(rect):
        """
        Get 3 points for a triangle facing down.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a facing down triangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        x2 = (x + x1) / 2
        return x, y, x2, y1, x1, y

    @staticmethod
    def triangle_left(rect):
        """
        Get 3 points for a triangle facing left.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a facing left triangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = (y + y1) / 2
        return x1, y, x1, y1, x, y2

    @staticmethod
    def triangle_right(rect):
        """
        Get 3 points for a triangle facing right.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a facing right triangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = (y + y1) / 2
        return x, y, x, y1, x1, y2

    @staticmethod
    def triangle_up(rect):
        """
        Get 3 points for a triangle facing up.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a facing up triangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        x2 = (x + x1) / 2
        return x, y1, x2, y, x1, y1


dispatch = {
    ft.TRIANGLE_DOWN: FromRect.triangle_down,
    ft.TRIANGLE_LEFT: FromRect.triangle_left,
    ft.TRIANGLE_RIGHT: FromRect.triangle_right,
    ft.TRIANGLE_UP: FromRect.triangle_up,
    sh.CIRCLE: FromRect.ellipse,
    sh.CIRCLE_HORIZONTAL: FromRect.ellipse,
    sh.CIRCLE_VERTICAL: FromRect.ellipse,
    sh.DIAMOND: FromRect.diamond,
    sh.ELLIPSE: FromRect.ellipse,
    sh.ELLIPSE_HORIZONTAL: FromRect.ellipse,
    sh.ELLIPSE_VERTICAL: FromRect.ellipse,
    sh.HEXAGON_HORIZONTAL: FromRect.hexagon_horz,
    sh.HEXAGON_VERTICAL: FromRect.hexagon_vert,
    sh.OCTAGON: FromRect.octagon,
    sh.OCTAGON_ALIGNED: FromRect.octagon_align,
    sh.OCTAGON_DOUBLE: FromRect.octagon_align,
    sh.RHOMBUS: FromRect.diamond,
    sh.SQUARE: FromRect.square,
    sh.RECTANGLE: FromRect.rectangle
}
