#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Group as gk
from roller_one import Hat

# Are option groups that change and influence follower groups.
# However, they are not needed in the render step-through:
CHANGE_STEP = gk.BACKDROP_STYLE


def update_change_flag(steps):
    """
    The change flag is used to indicate an option group's
    render status. If it's changed, then the step needs
    to be done.

    The change flag also has a chain-inheritance. If a step
    is changed, the following steps are also changed.

    steps: list
        of paths (tuples)
        Paths are keys to option group widgets held in 'group_dict'.

    Return: list
        of changed steps
    """
    e = Hat.cat.group_dict
    q = []
    is_change = False

    # Every step after the first changed
    # group is part of a preview.
    # Change the change status as it is
    # assumed that the render will succeed.
    # Remove the CHANGE_STEP group as
    # it has served its purpose:
    for i in steps:
        a = e[i]
        if not is_change and a.changed:
            is_change = True
        if is_change:
            a.changed = False
            if a.group_key != CHANGE_STEP:
                q += [i]
    return q


class View:
    """
    Perform render.

    Create a previous list of steps.
    """

    def __init__(self):
        """Get ready for render previews."""
        self._previous_steps = []

    def _update_previous_steps(self, steps):
        """
        Update previous steps for another render.
        The previous steps are screened.
        These steps go up to the undo stage.

        steps: list
            for the next render
        """
        # Set the change status:
        e = Hat.cat.group_dict
        q = []
        is_change = False

        for i in self._previous_steps[::-1]:
            a = e[i]
            if not is_change and a.changed:
                is_change = True
            if is_change:
                if a.group_key != CHANGE_STEP:
                    q += [i]
            else:
                if i not in steps:
                    if a.group_key != CHANGE_STEP:
                        q += [i]
        self._previous_steps = q[::-1]

    def do(self, q, is_preview=False):
        """
        Call to do a render preview.

        q: list
            render steps

        is_preview: bool
            Is true when the caller is performing a preview.
        """
        self._update_previous_steps(q)

        q1 = q[:]

        # Update before the render:
        q = update_change_flag(q)

        q2 = self._previous_steps[:]

        # Reverse the order of the list.
        # Undo is the reverse of the render:
        self._previous_steps = q1[::-1]

        # Create the image:
        Hat.cat.product.do(q, q2, is_preview)
