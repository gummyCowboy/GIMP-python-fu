#!/usr/bin/env python
# -*- coding: utf-8 -*-
from datetime import datetime
from random import choice, randint, seed, uniform
from roller_constant_for import Color as co
from roller_constant_key import Button as bk, Widget as wk
from roller_one import Hat
from roller_one_draw import Draw
from roller_port_node import PortNode
from roller_widget_box import Eventful, VBow
from roller_widget_button import SwitchButton
from roller_widget_button_pair import ButtonPair
from roller_widget_label import Label
import gtk

# Let GTK know that an event has been handled:
DONE = 1

# Are widgets that will signal a window's
# accept process upon receiving the Return key:
RETURN_WIDGETS = (
    gtk.CheckButton,
    gtk.ComboBoxEntry,
    gtk.Entry,
    gtk.HScale,
    gtk.RadioButton,
    gtk.ScrolledWindow,
    gtk.SpinButton,
    gtk.ToggleButton,
    gtk.TreeView,
    SwitchButton
)


class Port(PortNode):
    """
    Is a VBox that may be hidden from view.

    Are part of the Port template:s
        draw_port: function
            Call to create widgets for a port.

        accept: function
            Call when accepting the Port.

        cancel: function
            Call when canceling the Port.
    """
    # constant:
    COLOR_DEC = 1900

    def __init__(self, d):
        """
        Create the VBox.

        d: dict
            Has init variables.
        """
        self._pigs = []
        self.color = co.MAX_COLOR - Port.COLOR_DEC
        self.roller_window = d[wk.WIN]
        self.title = d[wk.WINDOW_TITLE]
        self.pane = gtk.VBox()
        self.accept_port = d[wk.ON_ACCEPT]
        self.cancel_port = d[wk.ON_CANCEL]

        self.roller_window.win.set_title(self.title)
        self.pane.connect('key_press_event', self.on_key_press)

        PortNode.__init__(self, d)

        Draw.load_count += 1

        self.draw_port(self.pane)

        Draw.load_count -= 1

        if hasattr(self.roller_window, 'switch_box'):
            self.roller_window.switch_box.add(self.pane)
        self.roller_window.resize()

    def accept(self, *_):
        """
        Accept the choice.

        Use with satellite windows.

        Return: true
            The key-press is handled.
        """
        return self.accept_port(self.get_group_value())

    def cancel(self, *_):
        """
        Cancel the port.

        Use with satellite windows.

        Return: true
            The key-press is handled.
        """
        return self.cancel_port()

    def draw_simple_dialog_port(self, g, q, q1):
        """
        Draw a port with two stacked HBoxes.

        g: VBox
            container for the widgets

        q: tuple
            of process to call that draw widgets

        q1: tuple
            Has strings for group VBox labels.
        """
        for x, p in enumerate(q):
            box = Eventful(self.color)
            hbox = gtk.HBox()
            vbox = VBow()

            if x == 0 and hasattr(self, 'd'):
                self.d[wk.NAV_BOX] = hbox
                hbox.junctions = [vbox]

            hbox.add(box)
            box.add(vbox)
            g.add(hbox)

            if q1[x]:
                vbox.add(Label(padding=(4, 4, 4, 4), text=q1[x] + ":"))

            p(vbox)
            self.reduce_color()

    def draw_process(self, g):
        """
        Draw a process group with cancel and accept options.

        g: GTK container
            to receive group
        """
        def on_action(g_):
            self.cancel(g_) if g_.key == bk.CANCEL else self.accept(g_)

        g1 = ButtonPair(
            on_widget_change=on_action,
            text=(bk.CANCEL, bk.ACCEPT),
            win=self.roller_window
        )

        self.keep((g1,))
        g.add(g1)

    def keep(self, q):
        """
        Put widget reference into 'self._pigs'.

        Keep the GTK garbage collection from removing widget
        connections from a parent window when a child window is opened.

        q: iterable (tuple or list)
            Widgets
        """
        [self._pigs.append(g) for g in q]

    def on_key_press(self, g, a):
        """
        Check to see if the user pressed the Esc key.
        If so, then close the window or port.

        g: Widget
            Is responsible.

        a: gtk.Event
            a key-press

        Return: None or true
            Is true if the key-press is handled.
        """
        if self.pane.get_visible():
            n = gtk.gdk.keyval_name(a.keyval)

            if n == 'Escape':
                return self.cancel()
            if n == 'Return':
                # Get the widget in focus:
                if type(g) in RETURN_WIDGETS:
                    if isinstance(g, gtk.SpinButton):
                        # Remove focus from the Entry
                        # so that it updates internally:
                        g.get_parent().grab_focus()
                    return self.accept()

    def on_list_change(self, g):
        """
        Respond when the user changes selection in the navigation list.

        Is part of NavigationList template.

        g: NavigationList
            Has attributes.

        """
        def hide_box():
            """
            Hide option groups two columns or more into
            the navigation box from the current column.
            """
            a = g.level + 2
            if a < len(g.junctions):
                for i in range(a, len(g.junctions)):
                    for j in g.junctions[i].get_children():
                        if isinstance(j, gtk.VBox):
                            if j.get_visible():
                                j.hide()
        if not Draw.load_count:
            x = g.get_sel_x()

            # The junction is the container for
            # the navigation list's option group boxes:
            if x is not None:
                # 'get_children' is created by GTK when option
                # groups are added to the 'junction':
                if len(g.junctions) > g.level + 1:
                    junction = g.junctions[g.level + 1]
                    children = junction.get_children()

                    if len(g.group_box) and len(g.group_box) >= x:
                        g1 = g.group_box[x]

                        if not hasattr(g1, 'node_'):
                            hide_box()

                        else:
                            if g1.node_.get_sel_x() is None:
                                hide_box()

                        for child in children:
                            if child != g1:
                                if child.get_visible():
                                    child.hide()

                        if g1 not in children:
                            junction.add(g1)
                            g1.show_all()

                        else:
                            g1.show()

                        # Resize the window with the group-size change:
                        self.roller_window.resize()

    def on_widget_change(self, g):
        """
        Call when a widget is changed.

        Use with satellite ports.

        g: Widget
            Is responsible.
        """
        if not Draw.load_count:
            if g.key != wk.PRESET:
                if hasattr(self, 'preset'):
                    self.preset.set_to_undefined()

    @staticmethod
    def randomize_widgets(g):
        """
        Randomize the variables.

        g: Button
            Has an OptionGroup.
        """
        seed(datetime.now())
        d = g.group.d
        e = Hat.cat.option.options
        for k, g1 in d.items():
            if k in e:
                if wk.RANDOM in e[k]:
                    a = e[k][wk.RANDOM]

                    if wk.PRECISION in e[k]:
                        g1.set_value(uniform(a[0], a[1]))
                    else:
                        g1.set_value(randint(a[0], a[1]))

                elif wk.GET_WITH_KEY in e[k]:
                    g1.set_value(e[k][wk.GET_WITH_KEY](g.group.group_key))

                elif wk.GET_RANDOM in e[k]:
                    g1.set_value(e[k][wk.GET_RANDOM]())
                elif wk.LIST in e[k]:
                    g1.set_value(choice(e[k][wk.LIST]))

    def reduce_color(self):
        """'self.color' is used by the red and green color components."""
        self.color -= Port.COLOR_DEC

    def show_port(self):
        """
        Call when switching to this port.

        Select a navigation list items in
        order to collapse the option groups.
        """
        self.roller_window.switch_box.add(self.pane)
        self.roller_window.win.set_title(self.title)
        self.roller_window.resize()
        return DONE

    def switch_ports(self):
        """Call when switching to a new port."""
        self.roller_window.switch_box.remove(self.pane)
