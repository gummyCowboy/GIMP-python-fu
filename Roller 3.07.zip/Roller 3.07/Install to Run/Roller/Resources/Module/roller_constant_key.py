#!/usr/bin/env python
# -*- coding: utf-8 -*-
BACKDROP_IMAGE = "Backdrop Image"
BRUSH = "Brush"
BUMP = "Bump"
CAPTION_MARGIN = "Margin, Caption"
COLOR_PIPE = "Color Pipe"
CORNER_TAPE = "Corner Tape"
INNER_SHADOW = "Inner Shadow"
JAGGED_EDGE = "Jagged Edge"
LIST_SEPARATOR = "★"
PLAQUE_MASK = "Plaque Mask"
RESIZE_METHOD = "Resize Method"
SHADOW_1 = "Shadow #1"
SHADOW_2 = "Shadow #2"
SHADOW_TYPE = "Shadow Type"
TRI_SHADOW = "Tri-Shadow"


class BackdropStyle:
    """Has keys that identify a backdrop-style."""
    AVERAGE_COLOR = "Average Color"
    BACKDROP_IMAGE = BACKDROP_IMAGE
    CARBON_14 = "Carbon 14"
    CLAY_CHEMISTRY = "Clay Chemistry"
    COLOR_FILL = "Color Fill"
    COLOR_GRID = "Color Grid"
    CRYSTAL_CAVE = "Crystal Cave"
    CORE_DESIGN = "Core Design"
    CUBISM_COVER = "Cubism Cover"
    DARK_FORT = "Dark Fort"
    DENSITY_GRADIENT = "Density Gradient"
    ETCH_SKETCH = "Etch Sketch"
    FLOOR_SAMPLE = "Floor Sample"
    GALACTIC_FIELD = "Galactic Field"
    GLASS_GAW = "Glass Gaw"
    GRADIENT_FILL = "Gradient Fill"
    HISTORIC_TRIP = "Historic Trip"
    IMAGE_GRADIENT = "Image Gradient"
    LINE_STONE = "Line Stone"
    LOST_MAZE = "Lost Maze"
    MAZE_BLEND = "Maze Blend"
    MYSTERY_GRATE = "Mystery Grate"
    NANO_SUIT = "Nano Suit"
    NOISE_RIFT = "Noise Rift"
    PATTERN_FILL = "Pattern Fill"
    RAINBOW_VALLEY = "Rainbow Valley"
    ROCKY_LANDING = "Rocky Landing"
    SPACETIME_FABRIC = "Spacetime Fabric"
    SPECIMEN_SPECKLE = "Specimen Speckle"
    SPIRAL_CHANNEL = "Spiral Channel"
    SQUARE_CLOUD = "Square Cloud"
    TRAILING_VINE = "Trailing Vine"
    WATERY_PAGE = "Watery Page"
    KEY_LIST = (
        AVERAGE_COLOR,
        BACKDROP_IMAGE,
        CARBON_14,
        CLAY_CHEMISTRY,
        COLOR_FILL,
        COLOR_GRID,
        CRYSTAL_CAVE,
        CORE_DESIGN,
        CUBISM_COVER,
        DARK_FORT,
        DENSITY_GRADIENT,
        ETCH_SKETCH,
        FLOOR_SAMPLE,
        GALACTIC_FIELD,
        GLASS_GAW,
        GRADIENT_FILL,
        HISTORIC_TRIP,
        IMAGE_GRADIENT,
        LINE_STONE,
        LOST_MAZE,
        MAZE_BLEND,
        MYSTERY_GRATE,
        NANO_SUIT,
        NOISE_RIFT,
        PATTERN_FILL,
        RAINBOW_VALLEY,
        ROCKY_LANDING,
        SPACETIME_FABRIC,
        SPECIMEN_SPECKLE,
        SPIRAL_CHANNEL,
        SQUARE_CLOUD,
        TRAILING_VINE,
        WATERY_PAGE
    )


by = BackdropStyle


class Button:
    """Has keys used by buttons."""
    ACCEPT = "Accept"
    CANCEL = "Cancel"
    OPEN = "Open…"
    PER_CELL = 'per_cell_button,'
    PLAN = "Plan"
    PREVIEW = "Preview"
    RANDOM = "Randomize"
    RENDER = "Render"


class Effect:
    """Has keys that identify an image-effect. Are option types."""
    BALL_JOINT = "Ball Joint"
    BORDER_LINE = "Border Line"
    BRUSH_PUNCH = "Brush Punch"
    CAMO_PLANET = "Camo Planet"
    CERAMIC_CHIP = "Ceramic Chip"
    CIRCLE_PUNCH = "Circle Punch"
    CLEAR_FRAME = "Clear Frame"
    COLOR_BOARD = "Color Board"
    COLOR_PIPE = COLOR_PIPE
    CORNER_TAPE = CORNER_TAPE
    CUTOUT_PLATE = "Cutout Plate"
    FEATHER_STEPS = "Feather Steps"
    FRAME_OVER = "Frame Over"
    GLASS_REVEAL = "Glass Reveal"
    GRADIENT_LEVEL = "Gradient Level"
    HOT_GLUE = "Hot Glue"
    IMAGE_EFFECT = "Image Effect"
    INNER_SHADOW = INNER_SHADOW
    JAGGED_EDGE = JAGGED_EDGE
    LINE_FASHION = "Line Fashion"
    MAZE_MIRROR = "Maze Mirror"
    METALLIC_PROFILE = "Metallic Profile"
    NO_EFFECT = "No Effect"
    PAINT_RUSH = "Paint Rush"
    RAD_WAVE = "Rad Wave"
    RAISED_MAZE = "Raised Maze"
    SHADOW_1 = SHADOW_1
    SHADOW_2 = SHADOW_2
    SHAPE_BURST = "Shape Burst"
    SQUARE_CUT = "Square Cut"
    SQUARE_PUNCH = "Square Punch"
    STAINED_GLASS = "Stained Glass"
    STRETCH_TRAY = "Stretch Tray"
    TRI_SHADOW = TRI_SHADOW
    WIRE_FENCE = "Wire Fence"
    KEY_LIST = (
        BALL_JOINT,
        BORDER_LINE,
        BRUSH_PUNCH,
        CAMO_PLANET,
        CERAMIC_CHIP,
        CIRCLE_PUNCH,
        CLEAR_FRAME,
        COLOR_BOARD,
        COLOR_PIPE,
        CORNER_TAPE,
        CUTOUT_PLATE,
        FEATHER_STEPS,
        FRAME_OVER,
        GLASS_REVEAL,
        GRADIENT_LEVEL,
        HOT_GLUE,
        INNER_SHADOW,
        JAGGED_EDGE,
        LINE_FASHION,
        MAZE_MIRROR,
        METALLIC_PROFILE,
        NO_EFFECT,
        PAINT_RUSH,
        RAD_WAVE,
        RAISED_MAZE,
        SHADOW_1,
        SHADOW_2,
        SHAPE_BURST,
        SQUARE_CUT,
        SQUARE_PUNCH,
        STAINED_GLASS,
        STRETCH_TRAY,
        TRI_SHADOW,
        WIRE_FENCE
    )


class Group:
    """
    Has keys used for presets of option groups.

    The comas are used to split the string. The first
    part is the label, and the whole part is the key.
    """
    BACKDROP = "Backdrop"
    BACKDROP_STYLE = "Backdrop Style"
    BACKGROUND_STRIPE = "Background Stripe"
    BLUR_BEHIND = "Blur Behind"
    BRUSH = BRUSH
    BUMP = BUMP
    CAPTION_MARGIN = CAPTION_MARGIN
    EFFECT = "Effect"
    GLOBAL = "Global"
    GRADIENT_LIGHT = "Gradient Light"
    GRID = "Grid"
    IMAGE_CHOICE = "Image Choice"
    IMAGE_EFFECT = "Image Effect"
    INFLUENCE = "Influence"
    INNER_SHADOW = INNER_SHADOW
    MODEL = "Model"
    PLAQUE_MASK = PLAQUE_MASK
    RECTANGLE = "Rectangle"
    RESIZE_METHOD = RESIZE_METHOD
    SHADOW_1 = SHADOW_1
    SHADOW_2 = SHADOW_2
    SHADOW_TYPE = SHADOW_TYPE
    SHIFT = "Shift"
    STEPS = "Steps"
    TRI_SHADOW = TRI_SHADOW

    # grid:
    GRID_BORDER = "Border, Grid"
    GRID_CELL = "Cell, Grid"
    GRID_LAYER = "Layer, Grid"
    GRID_IMAGE = "Image, Grid"
    TABLE_MODEL = "Table Model"
    TABLE_PROPERTY = "Property, Table"

    # layer:
    LAYER_BORDER = "Border, Layer"
    LAYER_CAPTION = "Caption, Layer"
    LAYER_FRINGE = "Fringe, Layer"
    LAYER_MARGIN = "Margin, Layer"
    LAYER_PLAQUE = "Plaque, Layer"

    # cell:
    CELL_BORDER = "Border, Cell"
    CELL_CAPTION = "Caption, Cell"
    CELL_FRINGE = "Fringe, Cell"
    CELL_IMAGE_MASK = "Mask, Cell"
    CELL_IMAGE_PLACE = "Place, Cell"
    CELL_MARGIN = "Margin, Cell"
    CELL_PLAQUE = "Plaque, Cell"

    # custom cell:
    CUSTOM_CELL_BORDER = "Border, Custom Cell"
    CUSTOM_CELL_CAPTION = "Caption, Custom Cell"
    CUSTOM_CELL_CELL = "Cell, Custom Cell"
    CUSTOM_CELL_FRINGE = "Fringe, Custom Cell"
    CUSTOM_CELL_IMAGE = "Image, Custom Cell"
    CUSTOM_CELL_IMAGE_MASK = "Mask, Custom Cell"
    CUSTOM_CELL_IMAGE_PLACE = "Place, Custom Cell"
    CUSTOM_CELL_MARGIN = "Margin, Custom Cell"
    CUSTOM_CELL_MODEL = "Custom Cell Model"
    CUSTOM_CELL_PLAQUE = "Plaque, Custom Cell"
    CUSTOM_CELL_PROPERTY = "Property, Custom Cell"

    # per cell:
    PER_CELL_BORDER = "Border, Per Cell"
    PER_CELL_CAPTION = "Caption, Per Cell"
    PER_CELL_FRINGE = "Fringe, Per Cell"
    PER_CELL_GRID = "Grid, Per Cell"
    PER_CELL_IMAGE_PLACE = "Place, Per Cell"
    PER_CELL_IMAGE_MASK = "Mask, Per Cell"
    PER_CELL_MARGIN = "Margin, Per Cell"
    PER_CELL_PLAQUE = "Plaque, Per Cell"

    # Use to set parent type of a per cell generated option group:
    PER_CELL = 'per_cell'

    # SuperPreset:
    PRESET_STEPS = "Preset, Steps"
    PRESET_TABLE = "Preset, Table"
    PRESET_CUSTOM_CELL = "Preset, Custom Cell"
    PRESET_TRI_SHADOW = "Preset, Tri-Shadow"
    PRESET = "Preset"

    # blur behind:
    CAPTION_BEHIND = "Cell Caption, Blur Behind"
    CLEAR_FRAME_BEHIND = "Clear Frame, Blur Behind"
    COLOR_BOARD_BEHIND = "Color Board, Blur Behind"
    GLASS_REVEAL_BEHIND = "Glass Reveal, Blur Behind"
    GRADIENT_LEVEL_BEHIND = "Gradient Level, Blur Behind"
    IMAGE_BEHIND = "Image, Blur Behind"
    STAINED_GLASS_BEHIND = "Stained Glass, Blur Behind"


gk = Group


class Image:
    """Are keys used by the Image class."""
    LOOP = 'loop'
    LOOP_DICT = 'loop_dict'
    NEXT = 'next'
    NEXT_DICT = 'next_dict'
    PREVIOUS = 'previous'
    PREVIOUS_DICT = 'previous_dict'
    SLICE = 'slice'


class Layer:
    """
    Has keys used to id a layer. The key is paired
    with a context identifier in the Cat 'layers' dict.
    """
    CAPTION_BEHIND = "Caption Blur Behind"
    CELL_BORDER = "Cell Border"
    CELL_CAPTION = "Cell Caption"
    CELL_FRINGE = "Cell Fringe"
    CELL_PLAQUE = "Cell Plaque"
    CUSTOM_CELL_CAPTION = "Custom Cell Caption"
    FRAME = "Frame"
    IMAGE = "Image"
    IMAGE_BEHIND = "Image Blur Behind"
    LAYER_CAPTION = "Layer Caption"
    LAYER_BORDER = "Layer Border"
    LAYER_FRINGE = "Layer Fringe"
    LAYER_PLAQUE = "Layer Plaque"
    GRADIENT_LIGHT = "Gradient Light"
    IMAGE_MASK = "Image Mask"
    GROUP_TO_LAYER = {
        gk.CAPTION_BEHIND: CAPTION_BEHIND,
        gk.CELL_BORDER: CELL_BORDER,
        gk.CELL_CAPTION: CELL_CAPTION,
        gk.CELL_FRINGE: CELL_FRINGE,
        gk.CELL_IMAGE_MASK: IMAGE_MASK,
        gk.CELL_IMAGE_PLACE: IMAGE,
        gk.CELL_PLAQUE: CELL_PLAQUE,
        gk.CUSTOM_CELL_BORDER: CELL_BORDER,
        gk.CUSTOM_CELL_CAPTION: CELL_CAPTION,
        gk.CUSTOM_CELL_FRINGE: CELL_FRINGE,
        gk.CUSTOM_CELL_IMAGE_MASK: IMAGE_MASK,
        gk.CUSTOM_CELL_IMAGE_PLACE: IMAGE,
        gk.CUSTOM_CELL_PLAQUE: CELL_PLAQUE,
        gk.IMAGE_BEHIND: IMAGE_BEHIND,
        gk.LAYER_BORDER: LAYER_BORDER,
        gk.LAYER_CAPTION: LAYER_CAPTION,
        gk.LAYER_FRINGE: LAYER_FRINGE,
        gk.LAYER_PLAQUE: LAYER_PLAQUE
    }
    METAL_FRAME = "Metal Frame"


class Model:
    """Has keys used by the ModelList."""
    CELL = "Cell"
    TABLE = "Table"

    # indices for ModelList's 'self.items':
    NAME_INDEX, TYPE_INDEX = 0, 1


class Option:
    """
    Has keys displayed in PortOption.

    A descriptor that follows a comma serves to make the key
    categorically unique and is not displayed in the UI.
    """
    AMPLITUDE = "Amplitude"
    ANGLE_JITTER = "Angle Jitter"
    ANGLE_SHIFT = "Angle Shift"
    AS_LAYERS = "Decompose Image As Layers"
    AUTOCROP = "Auto-Crop"
    BACKDROP_BLUR = "Backdrop Blur"
    BACKDROP_IMAGE_BLUR = "Backdrop Image Blur"
    BACKDROP_IMAGE = BACKDROP_IMAGE
    BACKDROP_INFLUENCE = "Backdrop Influence"
    BACKGROUND_STRIPE = "Background Stripe"
    BACKDROP_STYLE = "Backdrop Style"
    BACKDROP_TYPE = "Backdrop Type"
    BEVEL_EDGE_WIDTH = "Bevel Edge Width"
    BLEND = "Blend"
    BLUR = "Blur"
    BLUR_BEHIND = "Blur Behind"
    BLUR_RADIUS = "Blur Radius"
    BLUR_X = "Blur X"
    BLUR_Y = "Blur Y"
    BORDER_BLUR = "Border Blur"
    BORDER_INFLUENCE = "Border, Influence"
    BORDER_WIDTH = "Border Width"
    BRUSH = BRUSH
    BRUSH_ANGLE = "Brush Angle"
    BRUSH_DICT = 'brush_dict'
    BRUSH_HARDNESS = "Brush Hardness"
    BRUSH_SIZE = "Brush Size"
    BRUSH_SPACING = "Brush Spacing"
    BUMP = BUMP
    BUMP_DEPTH = "Bump Depth"
    BUMP_TYPE = "Bump Type"
    CAMO_TYPE = "Camo Type"
    CAPTION_MARGIN = CAPTION_MARGIN
    CELL_CAPTION_TYPE = "Cell Caption Type"
    CELL_GAP = "Cell Gap"
    CELL_MARGINS = "Cell Margins"
    CELL_NAME = "Cell Name"
    CELL_PLAN = "Cell Plan"
    CELL_SHAPE = "Cell Shape"
    CELL_SHAPE_NORMAL = "Cell Shape (Normal)"
    CELL_SHIFT = "Cell Shift"
    CELL_SIZE = "Cell Size"
    CIRCLE_DIAMETER = "Circle Diameter"
    CLIP_TO_CELL = "Clip to Cell"
    CLOSE_FILE = 'close_file'
    COLOR = "Color"
    COLOR_1 = "Color #1"
    COLOR_2 = "Color #2"
    COLOR_3 = "Color #3"
    COLOR_4 = "Color #4"
    COLORIZE = "Colorize"
    COLORIZE_OPACITY = "Colorize Opacity"
    COLUMN = "Column"
    COLUMN_1 = "Column #1"
    COLUMN_2 = "Column #2"
    COLUMN_COUNT = "Column Count"
    COLUMN_MAZE = "Column for Maze"
    COLUMN_SLICE = "Column Slice Count"
    COLUMN_WIDTH = "Column Width"
    COMMON_BORDER = "Common Border"
    COMPONENT = "Color Component"
    COMPOSITION_FRAME_WIDTH = "Composition Frame Width"
    CONTRACT = "Contract"
    CORNER_SHIFT = "Corner Shift"
    COVER = "Cover"
    CRITERION = "Criterion"
    CROP_H = "Crop Height"
    CROP_W = "Crop Width"
    CROP_X = "Crop Offset X"
    CROP_Y = "Crop Offset Y"
    CURVE = "Curve"
    CUSTOM_CELL_CAPTION_TYPE = "Custom Cell Caption Type"
    CUSTOM_CELL_SHAPE = "Custom Cell Shape"
    DELETE_PLANS = "Delete plans on exit."
    DEPTH = "Depth"
    DETAIL_LEVEL = "Noise Amount"
    DIAGONAL_ROTATION = "Diagonal Rotation"
    EDGE_MODE = "Edge Mode"
    EDGE_TYPE = "Edge Type"
    ELEVATION = "Elevation"
    EMBOSS = "Emboss"
    END_X = "End X"
    END_Y = "End Y"
    FACTOR_BOTTOM = "Bottom, Factor"
    FACTOR_HEIGHT = "Height, Factor"
    FACTOR_IMAGE_SIZE_H = "Factor of Image Size Height"
    FACTOR_IMAGE_SIZE_W = "Factor of Image Size Width"
    FACTOR_LEFT = "Left, Factor"
    FACTOR_POSITION_X = "Position: X, Factor"
    FACTOR_POSITION_Y = "Position: Y, Factor"
    FACTOR_RIGHT = "Right, Factor"
    FACTOR_TOP = "Top, Factor"
    FACTOR_WIDTH = "Width, Factor"
    FEATHER = "Feather"
    FILE = "File"
    FILLED = "Filled Cell"
    FILTER = "Filter"
    FIT_IMAGE = "Fit image to render"
    FIXED_BOTTOM = "Bottom, Fixed"
    FIXED_HEIGHT = "Height, Fixed"
    FIXED_IMAGE_SIZE_H = "Fixed Size Height"
    FIXED_IMAGE_SIZE_W = "Fixed Size Width"
    FIXED_LEFT = "Left, Fixed"
    FIXED_POSITION_X = "Position: X, Fixed"
    FIXED_POSITION_Y = "Position: Y, Fixed"
    FIXED_RIGHT = "Right, Fixed"
    FIXED_TOP = "Top, Fixed"
    FIXED_WIDTH = "Width, Fixed"
    FLIP_HORIZONTAL = "Flip Horizontal"
    FLIP_VERTICAL = "Flip Vertical"
    FOLDER = "Folder"
    FOLDER_ORDER = "Folder Order"
    FONT = "Font"
    FONT_SIZE = "Font Size"
    FRINGE_INFLUENCE = "Fringe, Influence"
    TABLE_NAME = "Table Name"
    FRAME = "Frame"
    FRAME_STYLE = "Frame Style"
    FRAME_TYPE = "Frame Type"
    FRAME_WIDTH = "Frame Width"
    FRINGE_TYPE = "Fringe Type"
    GAP_TYPE = "Gap Type"
    GAP_WIDTH = "Gap Width"
    GRADIENT = "Gradient"
    GRADIENT_ANGLE = "Gradient Angle"
    GRADIENT_DIRECTION = "Gradient Direction"
    GRADIENT_MODE = "Gradient Mode"
    GRADIENT_POSITION = "Gradient Position"
    GRADIENT_TYPE = "Gradient Type"
    TABLE_PLAN = "Table Plan"
    GRID_SIZE = "Grid Size"
    GRID_TYPE = "Grid Type"
    HEIGHT_MOD = "Height Mod"
    HORZ_COUNT = "Horizontal Count"
    HORZ_SCALE = "Horizontal Scale"
    IMAGE = "Image"
    IMAGE_EFFECT = "Image Effect"
    IMAGE_INFLUENCE = "Image Influence"
    IMAGE_NAME = "Image Name"
    IMAGE_SOURCE = "Image Source"
    INFLUENCE = "Influence"
    INLAY_BLUR = "Inlay Shadow Blur"
    INNER_FRAME_WIDTH = "Inner Frame Width"
    INTENSITY = "Shadow Intensity"
    INVERT = "Invert"
    INVERT_NOISE = "Invert Noise"
    ITERATIONS = "Iterations"
    JUSTIFICATION = "Justification"
    KEEP_GRADIENT = "Keep the Gradient"
    LAYER_CAPTION_TYPE = "Layer Caption Type"
    LAYER_COUNT = "Layer Count"
    LAYER_ORDER = "Layer Order"
    LEADING_TEXT = "Leading Text"
    LENGTH_SHIFT = "Length Shift"
    AZIMUTH = "Azimuth"
    LINE_WIDTH = "Line Width"
    LOCKED = "Locked Aspect Ratio"
    LOOP_INDEX = "Loop Index"
    MAKE_OPAQUE = "Make Opaque?"
    MARGIN_SIZE = "Margin Size"
    MASK_TYPE = "Mask Type"
    MAZE_DIRECTION = "Maze Rotation Direction"
    MAZE_TYPE = "Maze Type"
    MESH_SIZE = "Mesh Size"
    MESH_TYPE = "Mesh Type"
    METAL_FRAME = "Metal Frame"
    MODE = "Paint Mode"
    MODEL_LIST = "Model List"
    NAME = "Name"
    NEATNESS = "Neatness"
    NET_LINE_SPACING = "Net Line Spacing"
    NET_LINE_WIDTH = "Net Line Width"
    NEXT_INDEX = "Next Index"
    NOISE = "Noise"
    NOISE_MODE = "Noise Mode"
    NOISE_OPACITY = "Noise Opacity"
    NUMBER_OF_SLICES = "Number of Slices"
    NUMERIC_SEQUENCE = "Numeric Sequence"
    OBEY_MARGINS = "Obey Margins"
    OFFSET = "Offset"
    OFFSET_X = "Offset X"
    OFFSET_Y = "Offset Y"
    OFFSET_Z = "Offset Z"
    OPACITY = "Opacity"
    OTHER_FRAME = "Other Frame"
    PANE_HEIGHT = "Pane Height"
    PANE_WIDTH = "Pane Width"
    PATTERN = "Pattern"
    PATTERN_1 = "Pattern #1"
    PATTERN_2 = "Pattern #2"
    PATTERN_3 = "Pattern #3"
    PER_CELL = "Per Cell"
    PLAQUE_MASK = PLAQUE_MASK
    PLAQUE_TYPE = "Plaque Type"
    PIN_CORNER = "Pin Corner"
    PLAQUE_INFLUENCE = "Plaque, Influence"
    POST_BLUR = "Post Blur"
    POWER = "Noise Power"
    PREVIEW_MODE = "Preview Mode"
    PREVIOUS_INDEX = "Previous Index"
    PROFILE = "Profile"
    RANDOM_SEED = "Random Seed"
    RECTANGLE_SPECS = "Rectangle Specs"
    RENDER_HEIGHT = "Render Height"
    RENDER_WIDTH = "Render Width"
    RESIZE_METHOD = RESIZE_METHOD
    RESIZE_TYPE = "Resize Method Type"
    REVERSE = "Reverse"
    ROTATE = "Rotate"
    ROW = "Row"
    ROW_COUNT = "Row Count"
    ROW_HEIGHT = "Row Height"
    ROW_MAZE = "Row for Maze"
    ROW_SLICE = "Row Slice Count"
    SAMPLE_POINTS = "Sample Points"
    SAMPLE_RADIUS = "Sample Radius"
    SAMPLE_VECTOR = "Sample Vector"
    SATURATION = "Saturation"
    SCATTER_COUNT = "Scatter Count"
    SEED_GLOBAL = "Random Seed, Global"
    SHADOW_BLUR = "Shadow Blur"
    SHADOW_COLOR = "Shadow Color"
    SHADOW_DICT = "Shadow, Dict"
    SHADOW_TYPE = SHADOW_TYPE
    SHAPE_BURST = "Shape Burst"
    SHIFT = "Shift"
    SHIFT_HEIGHT = "Shift Height"
    SHIFT_WIDTH = "Shift Width"
    SHIFT_X = "Shift X"
    SHIFT_Y = "Shift Y"
    SHIFT_Z = "Shift Z"
    SKETCH_TEXTURE = "Sketch Texture"
    SLICE = "Slice"
    SLICE_ORDER = "Slice Order"
    SMOOTHNESS = "Smoothness"
    SOFTNESS = "Noise Softness"
    SPIRAL_DISTANCE = "Spiral Distance"
    SPIRAL_MOD = "Spiral Mod"
    SPREAD = "Spread"
    SQUARE_DIMENSION = "Square Dimension"
    START_X = "Start X"
    START_Y = "Start Y"
    STARTING_ANGLE = "Starting Angle"
    START_NUMBER = "Start Number"
    STEPS = "Steps"
    STOP_LENGTH = "Stop Length"
    STRIPE_HEIGHT = "Height, Stripe"
    STRIPE_TYPE = "Stripe Type"
    SUPERPIXEL_SIZE = "Superpixel Size"
    TAPE_LENGTH = "Tape Length"
    TAPE_WIDTH = "Tape Width"
    TEXT = "Text"
    TEXTURE = "Texture"
    TILE_SIZE = "Tile Size"
    THRESHOLD = "Threshold"
    TRAILING_TEXT = "Trailing Text"
    TRANSLUCENT_FRAME = "Translucent Frame"
    TRI_SHADOW = TRI_SHADOW
    TRIM = "Trimmed Side"
    UNSHARP_AMOUNT = "Unsharp Amount"
    UNSHARP_RADIUS = "Unsharp Radius"
    UNSHARP_THRESHOLD = "Unsharp Threshold"
    USE_PLASMA = "Use Plasma"
    VERT_COUNT = "Vertical Count"
    VERT_SCALE = "Vertical Scale"
    WAVE_AMPLITUDE = "Wave Amplitude"
    WAVE_PER_LAYER = "Waves Per Layer"
    WAVE_PHASE = "Wave Phase"
    WAVELENGTH = "Wavelength"
    WHIRL = "Whirl"
    WIDTH = "Width"
    WIDTH_MOD = "Width Mod"
    WIRE_THICKNESS = "Wire Thickness"


class Path:
    """Are values used to make step keys."""
    BORDER = "Border"
    CAPTION = "Caption"
    CELL = "Cell"
    FRINGE = "Fringe"
    GRID = "Grid"
    IMAGE = "Image"
    LAYER = "Layer"
    MARGIN = "Margin"
    MASK = "Mask"
    PLACE = "Place"
    PLAQUE = "Plaque"
    PROPERTY = "Property"
    RECTANGLE = "Rectangle"


pa = Path


class Pickle:
    """Has keys used with Pickle."""
    DATA = 'data'
    FILE = 'file'
    SHOW_ERROR = 'show_error'


class Plan:
    """Has keys used by the plan option."""
    BORDER = "Border"
    CAPTION = "Caption"
    CELL_FRINGE = "Cell Fringe"
    CELL_PLAQUE = "Cell Plaque"
    CELL_MARGINS = "Cell Margins"
    COORDINATES = "Coordinates"
    CORNERS = "Corners"
    DIMENSIONS = "Dimensions"
    LAYER_FRINGE = "Layer Fringe"
    LAYER_PLAQUE = "Layer Plaque"
    LAYER_MARGINS = "Layer Margins"
    GRID = "Grid"
    IMAGE = "Image"
    IMAGE_MASK = "Image Mask"
    NAME = "Name"
    RATIOS = "Ratios"
    RECTANGLE = "Rectangle"


class PortCell:
    """Has keys used to initialize PortCell."""
    CELL_TABLE = 'cell_table'
    PER_CELL_BUTTON = 'per_cell_button'
    SET_TOOLTIP = 'set_tooltip'
    TABLE_SIZE = 'table_size'


class Preset:
    """Has keys used to initialize a Preset."""
    DEFAULT = "Default"
    DELETE = "Delete"
    FILE_NAME = 'file_name'
    GET_DATA = 'get_data'
    SAVE = "Save"
    WIN = 'win'


class Step:
    """Has keys used by option groups."""
    SELECTED_ROW = 'selected_row'
    STEP_LIST = 'step_list'
    SESSION = 'session'
    STEPS = gk.STEPS,

    # fixed paths:
    BACKDROP = gk.STEPS, gk.BACKDROP
    BACKDROP_IMAGE = BACKDROP + (by.BACKDROP_IMAGE,)
    BACKDROP_STYLE = BACKDROP + (gk.BACKDROP_STYLE,)
    EFFECT = gk.STEPS, gk.EFFECT
    GLOBAL = gk.STEPS, gk.GLOBAL
    GRADIENT_LIGHT = gk.STEPS, gk.GRADIENT_LIGHT
    MODEL = EFFECT + (gk.MODEL,)
    STEPS_PRESET = gk.STEPS, gk.PRESET

    # Tri-Shadow:
    SHADOW_TYPE = gk.TRI_SHADOW, gk.SHADOW_TYPE
    TRI_SHADOW = gk.TRI_SHADOW,
    TRI_SHADOW_PRESET = gk.TRI_SHADOW, gk.PRESET
    SHADOW_1 = gk.TRI_SHADOW, gk.SHADOW_1
    SHADOW_2 = gk.TRI_SHADOW, gk.SHADOW_2
    INNER_SHADOW = gk.TRI_SHADOW, gk.INNER_SHADOW
    SHADOWS = SHADOW_1, SHADOW_2, INNER_SHADOW


class Widget:
    """Has keys used to initialize widgets."""
    # tuple of float
    # in .0 to 1.
    # a factor of the space to assign
    # for top, bottom, left, right:
    ALIGN = 'align'

    # int
    # padding for the bottom of a table:
    BOTTOM_PAD = 'bottom_pad'

    # of gtk.Box classes:
    BOX = 'box'

    # list, 2D, a list of lists, a cell table
    CELL_TABLE = 'cell_table'

    # Use with Entry's string length allocation:
    CHARS = 'chars'

    # string
    # Use with choice window:
    CHOICE = 'choice'

    # class
    # type of choice window:
    CHOICE_WINDOW = 'choice_window'

    # Widget
    # container for group:
    CONTAINER = 'container'

    # int
    # for event boxes:
    COLOR = 'color'

    # string
    # for a widget table
    # Is a label string for the left-side of a table:
    COLUMN_TEXT = 'column_text'

    # function
    # Call when a z-list item is created:
    CREATE_ZLIST_ITEM = 'create_zlist_item'

    # function
    # Call when a z-list item is deleted:
    DELETE_ZLIST_ITEM = 'delete_zlist_item'

    # Call to get a value for range:
    FUNCTION = 'function'

    # Get random function:
    GET_RANDOM = 'get_random'

    # Use with margins to return size of margin space:
    GET_SIZE = 'get_size'

    # Get random function with key arg:
    GET_WITH_KEY = 'get_with_key'

    # OptionGroup
    # Use to connect widgets with other widget in their group.
    # Use to access an option's OptionGroup:
    GROUP = 'group'

    # identifier
    # Is a preset key at times. Identifies a group of widgets:
    GROUP_KEY = 'group_key'

    # object type
    # Use to differentiate the different group types:
    # Preset, NonPreset, and PerCell:
    GROUP_TYPE = 'group_type'

    # boolean
    # When true, an option group has an effect pair of buttons:
    HAS_EFFECT_PAIR = 'has_effect_pair'

    # boolean
    # When true, an option group has a grid pair of buttons:
    HAS_GRID_PAIR = 'has_grid_pair'

    # boolean
    # When true, an option group has a Preview button:
    HAS_PREVIEW = 'has_preview'

    # boolean
    # When true, an option group has a Randomize button:
    HAS_RANDOM = 'has_random'

    # boolean
    # When true, an option group has a Preset button:
    HAS_PRESET = 'has_preset'

    # string
    # Is an optional header for a TreeViewList:
    HEADER = 'header'

    # Grid
    # Has the cell table.
    GRID = 'grid'

    # bool
    # When true, the OptionGroup will load a newly
    # drawn preset or non-preset from its default dictionary:
    IS_DEFAULT = 'is_default'

    # int
    # Use with TreeViewList:
    ITEM_COUNT = 'item_count'

    # string
    # option group:
    KEY = 'key'

    # list
    # Use to pass keys for an option when drawing an option group:
    KEYS = 'keys'

    # Label
    # sensitivity synchronized with another widget:
    LABEL = 'label'

    # int
    # Use when creating a RadioButton:
    LABEL_X = 'label_x'

    # Use with RadioBox:
    LABELS = 'labels'

    # navigation depth
    # Use with Node:
    LEVEL = 'level'

    # tuple
    # low, high
    # limit self value range of slider
    LIMIT = 'limit'

    # list
    # of strings for combobox:
    LIST = '_list'

    # int
    # Set the minimum width of a TreeViewList column:
    MINIMUM_WIDTH = 'minimum_width'

    # function
    # Call when a z-list item is moved:
    MOVE_ZLIST_ITEM = 'move_zlist_item'

    # string
    # Use to pass the z-list item name:
    NAME = 'name'

    # the navigation box
    # Use with Node:
    NAV_BOX = 'nav_box'

    # function
    # callback for accept button:
    ON_ACCEPT = 'on_accept'

    # function
    # callback for cancel button:
    ON_CANCEL = 'on_cancel'

    # function
    # callback on a key press:
    ON_KEY_PRESS = 'on_key_press'

    # function
    # callback on a preview button action:
    ON_PREVIEW_BUTTON = 'on_preview_button'

    # function
    # callback on change:
    ON_WIDGET_CHANGE = 'on_widget_change'

    # function
    # Is a callback for a button-click action.
    # Use with the OSButton:
    OS_BUTTON_CLICK = 'os_button_click'

    # tuple
    # Alignment padding:
    PADDING = 'padding'

    # string
    # Use to distinguish factored-preset option groups:
    PARENT_TYPE = 'parent_type'

    # tuple
    # Use to track parents of an option group:
    PATH = 'path'

    # PerCellGroup
    # Use to set value of the widget when doing
    # a preview function in the per cell table:
    PER_CELL_GROUP = 'per_cell_group'

    # 2D list
    # Is a group's per cell table:
    PER_CELL_TABLE = 'per_cell_table'

    # Port
    # Use to connect signals to port:
    PORT = 'port'

    # int
    # number of digits after the decimal point
    # Is zero for an integer:
    PRECISION = 'precision'

    # string
    # Use as widget key for Presets:
    PRESET = "Preset"

    # function
    # Is a callback to show preview for a chooser window:
    PREVIEW = 'preview'

    # tuple
    # HBox padding
    # Use with Cancel and Render button pair:
    RENDER_PAD = 'render_pad'

    # RadioButton
    # Is used to define the lead
    # RadioButton of a group RadioButtons:
    RADIO_GROUP = 'radio_group'

    # Is a tuple that defines a random-function limitation:
    RANDOM = 'random'

    # Widget
    # Use with RadioPreset:
    RESPONSIBLE = 'responsible'

    # RWSave
    # Use to remove circular import reference to a Port:
    SAVE_WINDOW = 'save_window'

    # function
    # Use to set cell tooltips in the cell editor:
    SET_TOOLTIP = 'set_tooltip'

    # tuple
    # row, column counts of a cell table:
    TABLE_SIZE = 'table_size'

    # string
    # for checkbutton, label:
    TEXT = 'text'

    TIP = 'tooltip'

    # tuple
    # Use to pass multiple tooltips for RadioBox buttons:
    TIPS = 'tips'

    # for OptionButton:
    TIP_TYPE = 'tip_type'

    # string
    # for tooltip:
    TOOLTIP = 'tooltip'

    # int
    # padding for the top of a widget table:
    TOP_PAD = 'top_pad'

    # Set a widget class:
    WIDGET = 'widget'

    # GTK window or Window:
    WIN = 'win'

    # string
    # Use to pass a window's key for storage in the window dict.
    WINDOW_KEY = 'window_key'

    # string
    # Use when creating a window:
    WINDOW_TITLE = 'window_title'


class Window:
    """
    Has keys used in the window position dictionary.

    Use key with a window type.
    """
    BUMP_CHOOSER = 'bump_chooser'
    BRUSH_CHOOSER = 'brush_chooser'
    CELL_MOD = 'cell_mod'
    CHOOSER = 'chooser'
    INFLUENCER = 'influencer'
    IMAGE_CHOOSER = 'image_chooser'
    MAIN = 'main'
    MARGIN_CHOOSER = 'margin_chooser'
    RESIZE_CHOOSER = 'resize_chooser'
    SAVE = 'save'
    SHADOW_CHOOSER = 'shadow_chooser'
    SHIFT_CHOOSER = 'shift_chooser'
    STRIPE = 'stripe'
