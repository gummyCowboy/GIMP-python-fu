#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Mage
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class WateryPage:
    """Create a surreal watercolor-like backdrop."""

    @staticmethod
    def do(one):
        """
        Do the backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            Is the backdrop-style.
        """
        cat = Hat.cat
        j = cat.render.image
        z = None

        if Lay.has_pixel(one.z):
            z = Lay.clone(one.z)
            group = Lay.group(j, one.k, layer=z)
            z1 = Lay.clone(z)
            z2 = Lay.clone(z1)
            n = z.name = "Furry"
            z.mode = z2.mode = fu.LAYER_MODE_SUBTRACT
            z1.mode = fu.LAYER_MODE_DIFFERENCE

            Lay.blur(z, 60)
            Lay.blur(z1, 30)
            pdb.plug_in_gimpressionist(j, z2, n)
            Mage.copy_all(j)

            z = Lay.paste(z2)
            z.mode = fu.LAYER_MODE_LCH_LIGHTNESS

            Gegl.waterpixels(z)

            z = Lay.clone(z)

            Gegl.edge(z)
            Mage.copy_all(j)

            z = Lay.paste(z)

            Gegl.waterpixels(z)

            z.mode = fu.LAYER_MODE_LCH_LIGHTNESS

            Mage.copy_all(j)

            z = Lay.paste(z)

            pdb.gimp_drawable_invert(z, 0)
            Lay.dilate(z)
            Lay.dilate(z)

            z = Lay.clone(one.z)
            z.mode = fu.LAYER_MODE_EXCLUSION

            Gegl.blur(z, 500)
            pdb.gimp_image_reorder_item(j, z, group, 0)
            z = Lay.merge_group(group)
            z = RenderHub.bump(z, one.d[ok.BUMP])
        return z
