#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_one import Rect
from roller_one_extract import FromRect, Shape


class GridRect:
    """
    Calculate the position and the size of cells.

    The cells are rectangular shaped.
    """

    def __init__(self, one):
        """
        Calculate cell size and rectangle shape.

        one: One
            Has init values.
        """
        self.row, self.column = one.r, one.c
        self.grid = one.grid
        self.grid_type = one.grid_type
        row, column, table = one.r, one.c, self.grid.table
        x, y = one.offset
        s = one.layer_space

        # Determine if the 'cell size' is the grid type.
        # If so then calculate grid size:
        if one.grid_type == gr.CELL_SIZE:
            w, h = one.column_width, one.row_height
            s1 = w * column, h * row
            w, h = w / 1., h / 1.
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        elif one.grid_type == gr.SHAPE_COUNT:
            w = s[0] // column
            h = s[1] // row
            w = min(w, h)
            s1 = w * column, w * row
            w, h = w, w
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            w = s[0] / 1. / column
            h = s[1] / 1. / row

        # intersect points:
        q_y = []
        q_x = []

        for r in range(row + 1):
            q_y.append(int(round(y)))
            y += h

        for c in range(column + 1):
            q_x.append(int(round(x)))
            x += w
        for r in range(row):
            for c in range(column):
                y, y1 = q_y[r], q_y[r + 1]
                x, x1 = q_x[c], q_x[c + 1]
                position = x, y
                size = x1 - x, y1 - y

                # 'cell' is the cell before margins:
                table[r][c].cell = Rect(position, size)
                x1, y1 = x + size[0], y + size[1]
                q = x, y, x1, y, x1, y1, x, y1
                table[r][c].plaque = q

    def calc_shape_per_cell(self, *_):
        """
        Record the shape from the pocket size
        on a per cell basis.

        Is part of the Grid template.
        """
        # The pocket rectangle has the shape points:
        self.calc_shape_with_pocket()

    def calc_shape_with_pocket(self):
        """
        Record the shape from the pocket size.

        Is part of the Grid template.
        """
        q = self.grid.table
        p = FromRect.square if self.grid_type == gr.SHAPE_COUNT \
            else FromRect.rectangle
        for r in range(self.row):
            for c in range(self.column):
                q[r][c].shape = p(q[r][c].pocket)
