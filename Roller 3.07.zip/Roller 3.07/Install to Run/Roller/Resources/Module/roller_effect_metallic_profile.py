#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub, PROFILE
import gimpfu as fu

pdb = fu.pdb
em = Fu.Emboss


def process_layer(j, image_layer, one):
    """
    Add a frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    one: One
        Has variables.

    Return: layer or None
        with frame material
    """
    cat = Hat.cat

    # Metallic Profile's 'preset', d:
    d = one.d

    parent = image_layer.parent
    group = Lay.group(j, Lay.name(parent, one.k), parent=parent)
    z = Lay.add(j, one.k, parent=group)
    z1 = Lay.clone_opaque(image_layer)
    color = 255, 255, 255
    w = d[ok.FRAME_WIDTH]
    q = PROFILE[d[ok.PROFILE]](w, *(color,))

    Sel.make_layer_sel(z1)
    RenderHub.draw_color_profile(z, w, q, color)
    pdb.gimp_image_remove_layer(j, z1)
    pdb.plug_in_emboss(
        j, z,
        cat.azimuth,
        cat.elevation,
        em.DEPTH_2,
        em.BUMP
    )

    z = Lay.merge_group(group)
    z = GradientLight.apply_light(z, ok.METAL_FRAME)
    z = RenderHub.make_polar_mask(j, z, is_dark=True)
    z.mode = fu.LAYER_MODE_VIVID_LIGHT
    z.opacity = 50.
    return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)


class MetallicProfile:
    """Create a metallic frame from a profile."""

    @staticmethod
    def do(one):
        """
        Do the image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer, list, or None
            with frame
        """
        z = one.image_layer
        j = z.image

        if one.is_image_group:
            undo_z = []
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], one)]
            one.shadow_layer = [z]

        else:
            undo_z = process_layer(j, z, one)
            one.shadow_layer = [undo_z, z]
        return undo_z
