#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Model as mo
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_render_gradient_light import GradientLight
import gimpfu as fu

em = Fu.Emboss
pdb = fu.pdb
COMPONENT = {
    mo.BLUE: (.0, 1., .0, .25),
    mo.AQUA: (.0, 1., 1., 1.),
    mo.PURPLE: (1., 1., .0, .25),
    mo.COMPOSITE: (1., 1., 1., 1.),
    mo.GREEN: (.0, .0, 1., 1.),
    mo.YELLOW: (1., .0, 1., .5),
    mo.RED: (1., .0, .0, .5)
}


def process_image(j, image_layer, one):
    """
    Do effect for the image material on a layer.

    j: GIMP image
        Is render.

    z: layer
        with image material

    one: One
        Has options.
    """
    cat = Hat.cat
    d = one.d
    parent = image_layer.parent
    group = Lay.group(j, Lay.name(parent, one.k), parent=parent)

    Sel.make_layer_sel(image_layer)
    Sel.invert(j)

    # 'z' is for the paint:
    z = Lay.add(j, one.k, parent=group)

    for i in range(3):
        q = COMPONENT[d[ok.CAMO_TYPE]] + (d[ok.RANDOM_SEED] + i,)
        Gegl.noise_rgb(z, *q)

    Gegl.waterpixels(z)
    Gegl.saturation(z, d[ok.SATURATION])
    Sel.make_layer_sel(image_layer)

    Sel.grow(j, d[ok.FRAME_WIDTH], d[ok.FRAME_TYPE])
    Sel.invert_clear(z)

    z.mode = fu.LAYER_MODE_HARDLIGHT

    # 'z' is for the emboss:
    z1 = Lay.add(j, "Emboss", parent=group, offset=1)

    Lay.color_fill(z1, (255, 255, 255))
    Sel.item(z)
    Sel.invert_clear(z1)
    Lay.blur(z1, 1.)
    pdb.plug_in_emboss(
        j, z1,
        cat.azimuth,
        cat.elevation,
        em.DEPTH_2,
        em.BUMP
    )
    Gegl.video_degradation(z1, 'dots')

    z = Lay.merge_group(group)
    z = GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)
    return z


def process_layers(j, one):
    """
    j: GIMP
        Is render.

    one: One
        Has variables.

    Return: list
        with frames
    """
    undo_z = []

    for i in one.image_layer.layers:
        undo_z += [process_image(j, i.layers[0], one)]
    return undo_z


class CamoPlanet:
    """Create a frame with different camouflage colors."""

    @staticmethod
    def do(one):
        """
        Do the image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer, list or None
            with frame
        """
        j = Hat.cat.render.image
        z = one.image_layer

        if one.is_image_group:
            undo_z = process_layers(j, one)
            one.shadow_layer = [z]

        else:
            undo_z = process_image(j, z, one)
            one.shadow_layer = [z, undo_z]
        return undo_z
