#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Widget as fw
from roller_constant_key import Group as gk, Widget as wk
from roller_option_group import OptionGroup
from roller_option_preset import Preset
from roller_port_preview import PortPreview
from roller_window_save import RWSave


class PortShift(PortPreview):
    """Provide widgets for defining a caption background stripe."""

    def __init__(self, d, g):
        """
        Create the port.

        g: OptionButton
            Has values.
        """
        self._parent_type = g.group.parent_type
        PortPreview.__init__(self, d, g)

    def _draw_shift_options(self, g):
        """
        Draw the options using the default dictionary keys.

        g: VBox
            container for the groups
        """
        k = gk.SHIFT
        d = OptionGroup.draw_group(
            **{
                wk.COLOR: self.color,
                wk.CONTAINER: g,
                wk.GROUP_KEY: k,
                wk.GROUP_TYPE: Preset,
                wk.HAS_PRESET: True,
                wk.IS_DEFAULT: False,
                wk.KEYS: Preset.get_keys(k),
                wk.ON_KEY_PRESS: self.on_key_press,
                wk.ON_PREVIEW_BUTTON: self.task_preview,
                wk.ON_WIDGET_CHANGE: self.on_widget_change,
                wk.PARENT_TYPE: self._parent_type,
                wk.PATH: (k,),
                wk.PORT: self,
                wk.SAVE_WINDOW: RWSave,
                wk.WIN: self.roller_window
            }
        )
        g = self.preset = d[wk.PRESET]
        self.group = g.group
        g.load_preset(self.safe.get_value(), fw.UNDEFINED)

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        self.draw_simple_dialog_port(
            g,
            (self._draw_shift_options, self.draw_preview_process),
            ("Shift Options", "")
        )

    def get_group_value(self):
        """
        Use to get the preset value.
        Call from PortPreview.

        Return: dict
            of caption stripe
        """
        return self.preset.get_value()
