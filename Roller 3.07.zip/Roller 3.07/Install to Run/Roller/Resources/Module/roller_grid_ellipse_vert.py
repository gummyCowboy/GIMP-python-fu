#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_grid_hexagon_vert import HexagonVert
from roller_one import Rect
from roller_one_extract import Shape

CELL_SIZE = gr.CELL_SIZE


class EllipsisVert(HexagonVert):
    """
    Calculate the position and the size of cells.

    The cells are ellipse shaped.

    Use a double-spaced grid-type.
    """

    def __init__(self, one):
        """
        Calculate the ellipse cell size rectangle and the ellipse shape.

        one: One
            Has init values.
        """
        HexagonVert.__init__(self, one)
        row, column = one.r, one.c
        table = self.grid.table
        is_by_count = False if one.grid_type == CELL_SIZE else True
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(self.grid, r, c):
                    # Get the cell rectangle, 'a':
                    a = table[r][c].cell
                    if is_by_count:
                        e = table[r][c].plaque = Shape.calc_vertical_ellipse(
                            a
                        )

                        # The ellipse rect is smaller than the hexagon rect:
                        table[r][c].cell = Rect(
                            (e['x'], e['y']),
                            (e['w'], e['h'])
                        )
                    else:
                        e = {
                            'x': a.x, 'y': a.y,
                            'w': a.w, 'h': a.h
                        }
                        table[r][c].plaque = e

    def calc_shape_per_cell(self, *_):
        """
        Calculate the shape of the ellipse from
        the pocket size on a per cell basis.

        Is part of the Grid template.
        """
        # The pocket rectangle has the shape points:
        self.calc_shape_with_pocket()

    def calc_shape_with_pocket(self):
        """
        Calculate the shape of the ellipse from
        the pocket size using intersects.

        Is part of the Grid template.
        """
        for r in range(self.row):
            for c in range(self.column):
                if Shape.is_allocated_cell(self.grid, r, c):
                    a = self.grid.table[r][c].pocket
                    self.grid.table[r][c].shape = {
                        'x': a.x, 'y': a.y,
                        'w': a.w, 'h': a.h
                    }
