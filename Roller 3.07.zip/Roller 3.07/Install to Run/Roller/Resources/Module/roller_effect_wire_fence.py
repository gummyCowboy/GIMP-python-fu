#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Sel
import gimpfu as fu

mo = Fu.Mosaic
pdb = fu.pdb


def make_sel(one, effect_layer, frame_sel, filler_sel):
    """
    Receive task from BorderLine.
    Draw the wire framework.

    The framework will later mesh with BorderLine.

    one: One
        Has options.

    effect_layer: layer
        Provides parent.

    frame_sel: Selection
        of image frame

    filler_sel: Selection
        space for wire fence

    Add the selection to the current selection.

    Return: selection state
        of render
    """
    j = Hat.cat.render.image
    d = one.d
    z = Lay.add(j, one.k, parent=effect_layer.parent)

    pdb.gimp_selection_all(j)
    pdb.plug_in_mosaic(
        j,
        z,
        d[ok.MESH_SIZE],
        mo.TILE_HEIGHT_1,
        d[ok.WIRE_THICKNESS],
        d[ok.NEATNESS],
        mo.NO_SPLIT,
        Hat.cat.azimuth,
        mo.MIN_COLOR_VARIATION,
        mo.YES_ANTIALIAS,
        mo.YES_COLOR_AVERAGING,
        bs.MESH_TYPE.index(d[ok.MESH_TYPE]),
        mo.SMOOTH_SURFACE,
        mo.BLACK_AND_WHITE_GROUT
    )
    Sel.isolate(z, filler_sel)

    # Erase white pixels:
    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))

    Sel.item(z)
    pdb.gimp_selection_feather(j, 1)
    Sel.load(j, frame_sel, option=fu.CHANNEL_OP_ADD)
    pdb.gimp_image_remove_layer(j, z)


class WireFence:
    """Add a wire framework to the BorderLine effect."""

    @staticmethod
    def do(one):
        """
        Do the Wire Fence image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Wire Fence
        """
        return BorderLine.do(one, framer=make_sel, filler=lambda *_: None)
