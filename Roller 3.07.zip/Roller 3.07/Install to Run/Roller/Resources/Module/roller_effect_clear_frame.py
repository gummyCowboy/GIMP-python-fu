#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

ed = Fu.Edge
pdb = fu.pdb


def do_edge(j, z, q):
    """
    Use to create an overlay edge effect
    where the light source is directly above
    the subject.

    j: GIMP image
        Is render.

    z: layer
        The layer that is on top.

    q: tuple
        background color (RGB)
        The background color needs to differ from the subject.
        It is used to turn transparent pixels into opaque pixels.

    Return: layer
        the layer with the edge
    """
    z1 = Lay.clone(z)
    z2 = Lay.add(
        j,
        z.name,
        parent=z.parent,
        offset=pdb.gimp_image_get_item_position(j, z)
    )

    Lay.color_fill(z2, q)

    z1 = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

    pdb.plug_in_edge(j, z1, ed.AMOUNT_1, ed.NO_WRAP, ed.SOBEL)
    Sel.item(z)
    Sel.invert_clear(z1)

    z1.mode = fu.LAYER_MODE_LIGHTEN_ONLY
    return pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)


def edge_color(q):
    """
    Return an edge color for a color.

    q: tuple
        (red, green, blue)
        of int
        color
    """
    q1 = [0, 0, 0]

    for x, a in enumerate(q):
        q1[x] = 0 if a > 127 else 255
    return tuple(q1)


def process_layer(j, image_layer, one):
    """
    Add frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    one: One
        Has variables.

    Return: layer or None
        with frame material
    """
    cat = Hat.cat
    d = one.d
    if d[ok.OPACITY]:
        frame = [0, 0]
        parent = image_layer.parent
        w = d[ok.INNER_FRAME_WIDTH]
        q = edge_color(d[ok.COLOR])
        group = Lay.group(j, Lay.name(parent, one.k), parent=parent)

        Sel.make_layer_sel(image_layer)

        sel = cat.save_short_term_sel()

        # Creates two layers:
        for x in range(2):
            Sel.load(j, sel)
            Sel.grow(
                j,
                (d[ok.FRAME_WIDTH] + w, w)[x],
                d[ok.FRAME_TYPE]
            )

            z = Lay.add(j, one.k, parent=group)

            Sel.fill(z, d[ok.COLOR])
            Sel.load(j, sel)
            Lay.clear_sel(z)
            frame[x] = do_edge(j, z, q)

        # Create frame selection to remove shadow bleed:
        Sel.item(frame[0])
        Sel.item(frame[1], option=fu.CHANNEL_OP_ADD)

        sel = cat.save_short_term_sel()

        # Add shadow and merge:
        z = RenderHub.do_shadow(frame[1], 0, 0, 5, (0, 0, 0), 100)

        pdb.gimp_image_reorder_item(j, z, group, 1)

        z.mode = fu.LAYER_MODE_NORMAL
        frame[1].mode = fu.LAYER_MODE_OVERLAY
        z = Lay.merge_group(group)

        Sel.load(j, sel)
        Sel.invert_clear(z)

        z.opacity = d[ok.OPACITY]
        z = GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)
        return z


class ClearFrame:
    """Create a translucent border around an image(s)."""

    @staticmethod
    def do(one):
        """
        Do the Clear Frame image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer, list, or None
            with Clear Frame
        """
        z = one.image_layer
        j = z.image

        if one.is_image_group:
            undo_z = []
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], one)]
            one.shadow_layer = [z]

        else:
            undo_z = process_layer(j, z, one)
            one.shadow_layer = [undo_z, z]
        return undo_z
