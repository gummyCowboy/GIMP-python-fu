#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub, PROFILE
import gimpfu as fu

pdb = fu.pdb
um = Fu.UnsharpMask


def process_layer(j, image_layer, one):
    """
    Add frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    one: One
        Has variables.

    Return: layer or None
        with frame material
    """
    d = one.d
    parent = image_layer.parent
    z = Lay.add(j, Lay.name(parent, one.k), parent=parent)
    z1 = Lay.clone(image_layer)
    color = d[ok.COLOR]
    w = d[ok.FRAME_WIDTH]
    q = PROFILE[d[ok.PROFILE]](w, *(color,))

    Sel.make_layer_sel(z1)
    RenderHub.draw_color_profile(z, w, q, color)
    pdb.gimp_image_remove_layer(j, z1)

    n = d[ok.NOISE_MODE]

    if n != "None" and d[ok.NOISE_OPACITY]:
        z1 = Lay.clone(z)
        z1.opacity = d[ok.NOISE_OPACITY]
        z1.mode = bs.NOISE_LAYER_MODE[bs.NOISE_MODE_LIST.index(n)]

        pdb.plug_in_plasma(
            j, z1,
            d[ok.RANDOM_SEED],
            Fu.Plasma.LOWEST_TURBULENCE
        )
        Sel.item(z)
        Sel.invert_clear(z1)

        if n == bs.SYRUPY:
            pdb.plug_in_unsharp_mask(
                j, z1,
                um.RADIUS_5,
                um.AMOUNT_1,
                um.THRESHOLD_0
            )

        elif n == bs.CARTOONY:
            z = RenderHub.do_cartoony(z, z1, color)
        if n != bs.CARTOONY:
            z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

    z = Lay.adjust_opacity(z)
    z = GradientLight.apply_light(z, ok.OTHER_FRAME)
    return z


class ColorPipe:
    """Create a frame with a custom profile and color."""

    @staticmethod
    def do(one):
        """
        Do the image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Color Pipe
        """
        z = one.image_layer
        j = z.image

        if one.is_image_group:
            undo_z = []
            one.shadow_layer = [z]
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], one)]

        else:
            undo_z = process_layer(j, z, one)
            one.shadow_layer = [undo_z, z]
        return undo_z
