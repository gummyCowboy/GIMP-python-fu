#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Frame as fo, Plan as fy
from roller_constant_key import (
    BackdropStyle as by,
    Effect as ek,
    Group as gk,
    Layer as nk,
    Model as md,
    Option as ok
)
from roller_grid import Grid
from roller_model_caption import Caption
from roller_model_image import Image
from roller_model_place import Place
from roller_one import Comm, Hat, One
from roller_one_extract import Form, Path
from roller_one_pin import Pin
from roller_one_fu import Lay, Mage, Sel
from roller_render import Render
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
READY = ": Ready"
WORK = ": Working"


def calc_pockets(one):
    """
    Have a model's Grid update the cell pockets.

    one: One
        Has the margin dict chunk.
    """
    one.grid.calc_pockets(one.d)


def effect_has_room(z, k):
    """
    Determine if an effect has room. Is for effects that need at
    least one pixel of alpha-transparency to produce a result.

    z: layer
        image layer

    k: string
        effect / group key

    Return: bool
        Is true if the image-effect has working space.
    """
    j = Hat.cat.render.image

    Sel.make_layer_sel(z)
    Sel.invert(j)

    m = Sel.is_sel(j)

    if not m and k != ek.NO_EFFECT:
        Comm.info_msg("{} has no canvas space for its image-effect.".format(k))
    return m


def make_backdrop_alpha(z):
    """
    Set a layer's alpha-transparency to that of the backdrop image layer.

    z: layer
        to adjust
    """
    j = Hat.cat.render.image

    Sel.item(j.layers[-1])
    Sel.invert(j)
    if Sel.is_sel(j):
        pdb.gimp_edit_clear(z)


def remove_layers(a):
    """
    Remove zero or more layers.

    a: layer or tuple of layers
        to remove
    """
    if a:
        if type(a) in (tuple, list):
            for i in a:
                Lay.remove(i)
        else:
            Lay.remove(a)


def undo_gradient_light(z):
    """
    Undo a model list group's change.

    z: layer or None
        Is sitting above backdrop image / backdrop style.
    """
    Lay.remove(z)
    if GradientLight.image:
        pdb.gimp_image_delete(GradientLight.image)
        GradientLight.image = None


class Product(Render):
    """Create a render."""

    def __init__(self):
        """
        The 'do' function is the entry point for
        rendering the models, effects, and style.
        """
        self.shadow_layer = []

        Render.__init__(self, 'product')
        self.layer_d.update(
            {
                gk.GRID: self._init_grid,
                gk.LAYER_MARGIN: self._set_layer_margin
            }
        )
        self.non_layer_d.update(
            {
                gk.CAPTION_BEHIND: self._blur_behind_caption,
                gk.CELL_MARGIN: calc_pockets,
                gk.GRADIENT_LIGHT: self._init_gradient_light,
                gk.IMAGE_BEHIND: self._blur_behind_image,
                gk.IMAGE_EFFECT: self._init_image_effect,

                # blur behind frames:
                gk.CLEAR_FRAME_BEHIND: self._blur_behind_frame,
                gk.COLOR_BOARD_BEHIND: self._blur_behind_frame,
                gk.GLASS_REVEAL_BEHIND: self._blur_behind_frame,
                gk.GRADIENT_LEVEL_BEHIND: self._blur_behind_frame,
                gk.STAINED_GLASS_BEHIND: self._blur_behind_frame
            }
        )

        self._main_effect = None
        self.backdrop_count = 0

    def _blur_behind_caption(self, one):
        """
        Blur behind a grid or a custom cell's caption stripe.

        one: One
            Has variables.
        """
        if self.context == md.TABLE:
            z = Caption.blur_behind_grid(one)

        else:
            z = Caption.blur_behind_custom_cell(one)
        self.undo[one.path] = z, Lay.remove

    def _blur_behind_frame(self, one):
        """
        Blur behind a translucent frame.

        one: One
            Has variables.
        """
        z = Hat.cat.get_layer((self.model_name, nk.FRAME))

        if z:
            blur = one.d[ok.BLUR_BEHIND]

            if isinstance(z, list):
                undo_z = []

                for i in z:
                    z1 = RenderHub.blur_behind_frame(i, blur)
                    if z1:
                        undo_z += [z1]
                        z1.name = Lay.name(i.parent, one.k.replace(",", ""))
                if undo_z:
                    self.undo[one.path] = undo_z, remove_layers
            else:
                z = RenderHub.blur_behind_frame(z, blur)
                if z:
                    z.name = Lay.name(z.parent, one.k.replace(",", ""))
                    self.undo[one.path] = z, Lay.remove

    def _blur_behind_image(self, one):
        """
        Blur behind an image.

        one: One
            Has variables.

        Return: tuple
            image blur behind layer,
        """
        z = None

        if self.context == md.TABLE:
            z = Image.blur_behind_grid(one)

        else:
            d = Path.get_cell_place_chunk(one.path)
            if one.image_layer and d[ok.BLUR_BEHIND]:
                z = RenderHub.blur_behind(one.image_layer, d, is_merge=False)
                if z:
                    z.name = Lay.name(z.parent, nk.IMAGE_BEHIND)
        if z:
            self.undo[one.path] = z, Lay.remove

    def _do_backdrop(self, one, step, k, is_preview):
        """
        Do a backdrop image or backdrop style.

        one: One
            Has variables.

        step: tuple
            path of option

        k: string
            group key

        is_preview: bool
            Is true when the caller is performing a preview and not a render.
        """
        cat = Hat.cat
        one.z = self.backdrop_layer
        d = deepcopy(self.image_index)

        cat.del_long_term_sel()

        z = Pin.backdrop[k].do(one)

        if k == by.BACKDROP_IMAGE:
            self.backdrop_layer = z
            self.undo[step] = (z, d), self._undo_backdrop
            z.name = k + WORK
            self.backdrop_count = 1
        else:
            if z:
                z.name = k
                self.undo[step] = (z, d), self._undo_backdrop_style
                self.backdrop_count = 2
                offset = cat.plan.get_offset()

                if offset:
                    pdb.gimp_image_reorder_item(
                        z.image, z,
                        None,
                        offset
                    )

                # Transfer backdrop alpha-state to the backdrop-style.
                # Image gradient in sample mode is an exception:
                if not (is_preview and k == by.IMAGE_GRADIENT):
                    make_backdrop_alpha(z)

    def _do_effect(self, one, step, k):
        """
        Do an image effect.

        one: One
            Has variables.

        step: tuple
            path of option

        k: string
            group key
        """
        cat = Hat.cat
        q = self.shadow_layer[:]
        go = False
        z = one.image_layer
        one.is_image_group = pdb.gimp_item_is_group(z) if z else False

        # image-effect:
        if self.context == md.CELL:
            one.r = one.c = fy.CUSTOM_CELL

        else:
            one.r, one.c = one.grid.division

        if one.is_image_group:
            go = True

        elif Lay.has_pixel(z):
            if effect_has_room(z, k):
                go = True

        if go:
            one.effect_layer = None
            d1 = deepcopy(self.image_index)
            one.context = self.context
            one.shadow_layer = self.shadow_layer
            z1 = Pin.effect[k].do(one)
            self.shadow_layer = one.shadow_layer

            if k == ek.FEATHER_STEPS:
                self.undo[step] = (
                    (z1, z, q),
                    self._undo_feather_steps
                )

            elif k == ek.JAGGED_EDGE:
                self.undo[step] = (z1, z, q), self._undo_jagged_edge
            else:
                self.undo[step] = (z1, k, q, d1), self._undo_effect
                if k in fo.BLUR_BEHIND_EFFECT:
                    cat.register_layer((self.model_name, nk.FRAME), z1)

    def _init_gradient_light(self, one):
        """
        Create a gradient light image.
        Make a backdrop gradient light layer.

        one: One
            Has variables.
        """
        cat = Hat.cat
        j = cat.render.image
        cat.gradient_light_d = one.d
        f = one.d[ok.INFLUENCE][ok.BACKDROP_INFLUENCE]
        z = None

        if f:
            GradientLight.create_gradient_light(one.d)
            Mage.copy_all(GradientLight.image)

            z = Lay.paste(self.backdrop_layer)

            z.opacity = f
            z.name = nk.GRADIENT_LIGHT

            pdb.gimp_image_reorder_item(
                j, z,
                None,
                len(j.layers) - self.backdrop_count - 1
            )
            make_backdrop_alpha(z)

        else:
            cat.gradient_light_position = self.backdrop_count
        self.undo[one.path] = z, undo_gradient_light

    def _init_grid(self, one):
        """
        Make a cell table for the grid.

        one: One
            Has variables for Grid.

        Return: tuple
            of grid-specific variables
        """
        a = self.grid
        d = deepcopy(self.image_index)
        self.grid = Grid(one)
        self.undo[one.path] = (a, d), self._undo_grid

    def _init_image_effect(self, one):
        """
        Set the shadow layer for the Tri-Shadow image-effect.

        one: One
            Has variables.
        """
        if one.d[ok.IMAGE_EFFECT] == ek.TRI_SHADOW:
            q = self.shadow_layer[:]
            self.shadow_layer = [one.image_layer]
            self.undo[one.path] = q, self._undo_image_effect

    def _set_layer_margin(self, one):
        """
        Set the layer margin dict in Stat.

        one: One
            Has options dict.

        Return: tuple
            of layer margin,
        """
        cat = Hat.cat
        q = self.layer_margin[:]
        self.layer_margin = Form.combine_margin(one.d, *cat.render.size)
        self.undo[one.path] = q, self._undo_layer_margin

    def _undo_backdrop(self, q):
        """
        Undo a backdrop image process.

        q: tuple
            Has a layer and a dict.
        """
        self.backdrop_layer = None
        z, self.image_index = q
        Lay.remove(z)

    def _undo_backdrop_style(self, q):
        """
        Undo a backdrop image process.

        q: tuple
            Has a layer and a dict.
        """
        self.image_gradient_used = None
        z, self.image_index = q
        Lay.remove(z)

    def _undo_effect(self, q):
        """
        Undo an image-effect.

        q: tuple
            (the effect layer, an image index dict)
        """
        cat = Hat.cat
        z, k, self.shadow_layer, cat.image_index = q

        if k in fo.BLUR_BEHIND_EFFECT:
            cat.unregister_layer(None, key=(self.model_name, nk.FRAME))
        remove_layers(z)

    def _undo_feather_steps(self, q):
        """
        Undo a Feather Steps image-effect.

        q: tuple
            model layer name, layer to remove
        """
        z, z1, self.shadow_layer = q

        remove_layers(z)

        if z1 and pdb.gimp_item_is_group(z1):
            # Has shift:
            for i in z1.layers:
                Lay.show(i.layers[0])
        else:
            Lay.show(z1)

    def _undo_grid(self, q):
        """
        Undo a grid step.

        q: tuple
            cat undo variables
        """
        self.grid, self.image_index = q

    def _undo_image_effect(self, q):
        """
        Undo an image effect step.

        q: tuple
            of shadow layers
        """
        self.shadow_layer = q

    def _undo_jagged_edge(self, q):
        """
        Undo a Jagged Edge effect.

        q: tuple
            layer with Jagged Edge and image layer
        """
        z, z1, self.shadow_layer = q
        k = self.render_type, self.model_name, nk.IMAGE

        remove_layers(z)

        if z1 and pdb.gimp_item_is_group(z1):
            # Has shift:
            Hat.cat.register_layer(k, z1)
            for i in z1.layers:
                Lay.show(i.layers[0])
        else:
            Lay.show(z1)
            Hat.cat.register_layer(k, z1)

    def _undo_layer_margin(self, q):
        """
        Undo a layer margin change.

        q: list
            of combined layer margins
        """
        self.layer_margin = q

    def do(self, steps, undo, is_preview):
        """
        Perform a preview.

        steps: list
            A step is based on an option group.
            preview or final steps

        undo: list
            of steps to undo

        is_preview: bool
            ImageGradient needs this setting.
        """
        Product.is_preview = is_preview
        cat = Hat.cat
        d = cat.group_dict
        e = self.non_layer_d
        e1 = self.layer_d
        is_start = True

        cat.plan.hide()
        self.undo_steps(undo, steps)

        for step in steps:
            j = cat.render.image
            k = d[step].group_key
            one = One(
                cell=self.cell,
                d=Path.get_dict_from_path(step),
                grid=self.grid,
                image_index=self.image_index,
                image_layer=cat.get_layer(
                    (
                        self.render_type,
                        self.model_name,
                        nk.IMAGE
                    )
                ),
                k=k,
                model_name=self.model_name,
                parent=self.model_group,
                path=step,
                render_type=self.render_type
            )

            pdb.gimp_selection_none(j)

            if is_start and cat.render.has_image:
                z = self.backdrop_layer
                if z:
                    z.name = z.name.split(":")[0] + WORK
                    is_start = False

            if k in e:
                e[k](one)

            elif k in e1:
                one.layer_margin = self.layer_margin
                e1[k](one)

            elif k in by.KEY_LIST:
                self._do_backdrop(one, step, k, is_preview)
            elif k in ek.KEY_LIST:
                self._do_effect(one, step, k)

        z = self.backdrop_layer
        j = cat.render.image

        if z:
            z.name = z.name.split(":")[0] + READY

        pdb.gimp_selection_none(j)
        pdb.gimp_displays_flush()
        cat.del_short_term_sel()

    def reset(self):
        """Reset any variables belonging to the render."""
        self.model_group = self.model_name = None
        self.cell = self.grid = self.backdrop_layer = None
        self.layer_margin = []
        self.image_index = deepcopy(Place.IMAGE_INDEX)
        self.context = ""
        self.undo = {}
