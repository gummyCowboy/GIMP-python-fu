#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy
from roller_constant_fu import Fu
from roller_constant_key import Model as md, Option as ok
from roller_one import Comm, Hat
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
from roller_render_gradient_light import GradientLight
import gimpfu as fu

em = Fu.Emboss
hs = Fu.HueSaturation
pdb = fu.pdb
CUSTOM = fy.CUSTOM_CELL
ELEVATION_30 = 30
SIX_COORDINATES = 6
EIGHT_COORDINATES = 8


def do_grid(j, image_layer, effect_layer, one):
    """
    Do effect for each image in the cell grid.

    j: GIMP image
        Is render.

    image_layer: layer
        with layer position

    effect_layer: layer
        for frame

    one: One
        Has variables.
    """
    cat = Hat.cat
    d = one.grid.grid_d
    is_merge_cell = one.grid.is_merge_cell
    n = image_layer.parent.name.split(" ")[-1]

    if not is_merge_cell:
        s = 1
    for r in range(one.r):
        for c in range(one.c):
            if is_merge_cell:
                s = d[ok.PER_CELL][r][c]

            # '(-1, -1)' is a dependent cell in a merge cell table:
            if s != (-1, -1):
                cat.join_selection(one.model_name, r, c)
                if Sel.is_sel(j):
                    if one.is_image_group:
                        if cat.get_z_height((one.model_name, r, c)) == n:
                            process_image(one, effect_layer)
                    else:
                        process_image(one, effect_layer)


def embellish(j, z):
    """
    Add color and depth to the frame.

    j: GIMP image
        Is render.

    z: layer
        Has frame.

    Return: layer
        with new features
    """
    n = z.name
    group = Lay.group(j, n, parent=z.parent, layer=z)
    z1 = Lay.clone(z)
    z1.mode = fu.LAYER_MODE_OVERLAY
    z1.opacity = 25.
    z1 = Lay.clone(z1)
    z1.mode = fu.LAYER_MODE_BURN
    z1.opacity = 50.

    pdb.plug_in_emboss(
        j, z,
        Hat.cat.azimuth,
        ELEVATION_30,
        em.DEPTH_3,
        em.EMBOSS
    )
    pdb.gimp_selection_none(j)

    z = Lay.merge_group(group)
    z.name = n

    pdb.gimp_drawable_hue_saturation(
        z,
        fu.HUE_RANGE_ALL,
        hs.HUE_OFFSET_0,
        hs.LIGHTNESS_0,
        hs.SATURATION_MINUS_50,
        hs.OVERLAP_0
    )
    pdb.gimp_curves_spline(
        z,
        fu.HISTOGRAM_RED,
        SIX_COORDINATES,
        [0, 0, 149, 193, 255, 255]
    )
    pdb.gimp_curves_spline(
        z,
        fu.HISTOGRAM_GREEN,
        SIX_COORDINATES,
        [0, 0, 132, 102, 255, 255]
    )
    pdb.gimp_curves_spline(
        z,
        fu.HISTOGRAM_BLUE,
        EIGHT_COORDINATES,
        [0, 0, 54, 15, 170, 125, 255, 255]
    )
    return z


def process_image(one, z):
    """
    Do the effect for an image.

    one: One
        Has variables.

    z: layer
        to receive effect
    """
    j = Hat.cat.render.image
    d = one.d

    pdb.plug_in_sel2path(j, z)

    stroke = j.active_vectors.strokes[0]

    pdb.gimp_selection_none(j)
    RenderHub.brush_stroke_on_stroke(
        z,
        'dots',
        d[ok.BRUSH_SIZE],
        stroke,
        d[ok.BRUSH_SIZE] / 15.,
        .0
    )


def process_layer(j, image_layer, one):
    """
    Add frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    one: One
        Has variables.

    Return: layer or None
        with frame material
    """
    if one.context == md.TABLE:
        effect_layer = Lay.add_above(image_layer, n=one.k)
        do_grid(j, image_layer, effect_layer, one)

    else:
        # custom cell:
        r = one.r = one.c = CUSTOM
        effect_layer = None
        Hat.cat.join_selection(one.model_name, r, r)
        if Sel.is_sel(j):
            effect_layer = Lay.add_above(image_layer, n=one.k)
            process_image(one, effect_layer)
    if effect_layer:
        Lay.clear_image_sel(image_layer, effect_layer)
        return GradientLight.apply_light(
            embellish(j, effect_layer),
            ok.METAL_FRAME
        )


class BallJoint:
    """
    Create a metallic image frame_name from a brush with overlapping circles.
    """

    @staticmethod
    def do(one):
        """
        Do the Ball Joint image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer, list or None
            with frame(s)
        """
        try:
            pdb.gimp_context_set_brush('dots')

        except RuntimeError:
            # Exit with an error message:
            Comm.info_msg(
                "Roller requires the 'dots' brush for the Ball Joint effect. "
                "Please check Roller's included files for the file."
            )
            return

        cat = Hat.cat
        j = cat.render.image
        z = one.image_layer

        if not one.is_image_group:
            undo_z = process_layer(j, z, one)
            one.shadow_layer = [undo_z, z]

        else:
            # 'undo_z' is a list of layers for the preview's undo function:
            undo_z = []
            one.shadow_layer = [z]
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], one)]
        return undo_z
