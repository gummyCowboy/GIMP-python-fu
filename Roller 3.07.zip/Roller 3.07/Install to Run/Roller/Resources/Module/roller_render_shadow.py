#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Layer as nk, Option as ok, Step as sk
from roller_one import Hat, One
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


def do_numbered_shadow(one):
    """
    Create a drop shadow.

    one: One
        Has variables.

    Return: layer or None
        with shadow
    """
    if one.is_image_group:
        # 'undo_z' is a list of layers for the preview undo function:
        undo_z = []
        cat = Hat.cat

        for i in one.image_layer.layers:
            z = cat.get_image_layer(i.name)

            if z:
                x = Lay.offset(z)
                if x:
                    q = i.layers[0:x + 1] if x else i.layers
                else:
                    q = i.layers[0],

            undo_z += [
                Shadow.do(
                    One(
                        cast=q,
                        d=one.d,
                        model_name=one.model_name,
                        parent=i,
                        name=Lay.name(i, one.k)
                    )
                )
            ]
        return undo_z
    return Shadow.do(
        One(
            cast=one.shadow_layer,
            d=one.d,
            model_name=one.model_name,
            parent=one.parent,
            name=Lay.name(one.parent, one.k)
        )
    )


def make_shadow_unit(z, q):
    """
    Create a unified shadow layer.

    z: layer
        group where unified-shadow layer belongs

    q: iterable
        layers to copy and merge
        Form a single shadow casting unit.

    Return: layer
        a unified shadow layer
    """
    # Put layer(s) into a group and merge group:
    j = Hat.cat.render.image
    group = Lay.group(j, "Unit", parent=z)

    for z1 in q:
        z2 = Lay.clone(z1)
        z2.mode = fu.LAYER_MODE_NORMAL

        pdb.gimp_image_reorder_item(j, z2, group, 0)
        Lay.hide(z1)
    return Lay.merge_group(group)


class Shadow:
    """
    Create a shadow layer.

    Use with shadow effects.
    """

    @staticmethod
    def do(one):
        """
        Make a shadow.

        one: One
            Has variables.

        Return: layer
            with shadow
        """
        # Use a selection so the shadow doesn't appear below the image:
        cat = Hat.cat
        d = one.d
        parent = one.parent
        model_name = one.model_name
        j = cat.render.image
        cast = one.cast

        if cast and d[ok.INTENSITY]:
            is_inner = one.is_inner if hasattr(one, 'is_inner') else False
            unit = make_shadow_unit(parent, cast)

            if is_inner:
                # inlay-type shadow:
                x = y = 0
                blur = d[ok.INLAY_BLUR]

            else:
                blur = d[ok.SHADOW_BLUR]
                x, y = d[ok.OFFSET_X], d[ok.OFFSET_Y]

            is_opaque = True if ok.MAKE_OPAQUE not in d else d[ok.MAKE_OPAQUE]
            z = RenderHub.do_shadow(
                unit,
                x, y,
                blur,
                d[ok.SHADOW_COLOR],
                d[ok.INTENSITY],
                is_opaque=is_opaque,
                is_inner=is_inner
            )

            pdb.gimp_image_remove_layer(j, unit)

            if z:
                a = 0
                if is_inner:
                    # Caption is on top:
                    cap = cat.get_layer((model_name, nk.CELL_CAPTION))
                    if cap:
                        a = Lay.offset(cap) + 1

                else:
                    # Put the shadow layer below the lowest shadow caster:
                    for i in cast:
                        b = Lay.offset(i) + 1
                        if b > a:
                            a = b
                pdb.gimp_image_reorder_item(j, z, parent, a)

            [Lay.show(i) for i in cast]
            pdb.gimp_selection_none(j)

            if hasattr(one, 'name'):
                z.name = one.name
            return z

    @staticmethod
    def do_shadows(d, z):
        """
        Draw shadows for a material
        given a shadow dict.

        d: dict
            of shadow choice

        z: layer
            with material

        Return: tuple
            layer:
                the shadow layer or None

            flag:
                Is true if the shadow is an inlay.
        """
        def cast_shadow():
            """
            Create the shadow effect and merge
            it with the material layer.
            """
            one.d = e
            is_inner = one.is_inner = k == sk.INNER_SHADOW
            z1 = Shadow.do(one)
            if z1:
                a = 0 if is_inner else Lay.offset(z) + 1
                pdb.gimp_image_reorder_item(j, z1, z1.parent, a)

        if Shadow.get_type(d):
            j = z.image
            group = Lay.group(j, "Shadow", parent=z.parent, layer=z)
            one = One(cast=(z,), model_name="", parent=group)

            for k in sk.SHADOWS:
                e = d[k]
                cast_shadow()
            return Lay.merge_group(group)
        return z

    @staticmethod
    def get_type(d):
        """
        Get the shadow type from a tri-shadow dictionary.

        d: dict
            of tri-shadow

        Return:
            int
            True is a shadow.
        """
        if sk.SHADOW_TYPE in d:
            return d[sk.SHADOW_TYPE][ok.SHADOW_TYPE]
        return 0


class InnerShadow:
    """Create a cut-out, inlay, or inner shadow for the image layer."""

    @staticmethod
    def do(one):
        """
        Create a drop shadow.

        one: One
            Has variables.

        Return: layer or None
            with shadow
        """
        if one.is_image_group:
            cat = Hat.cat
            # 'undo_z' is a list of layers for the preview undo function:
            undo_z = []

            for i in one.image_layer.layers:
                z = cat.get_image_layer(i.name)
                if z:
                    undo_z += [
                        Shadow.do(
                            One(
                                cast=(z,),
                                d=one.d,
                                is_inner=True,
                                model_name=one.model_name,
                                parent=i,
                                name=Lay.name(i, one.k)
                            )
                        )
                    ]
            return undo_z
        return Shadow.do(
            One(
                cast=(one.image_layer,),
                d=one.d,
                is_inner=True,
                model_name=one.model_name,
                parent=one.parent,
                name=Lay.name(one.parent, one.k)
            )
        )


class Shadow1:
    """Is the same as Shadow except that it uses Cat to get its shadow cast."""

    @staticmethod
    def do(one):
        """
        Create a drop shadow.

        one: One
            Has variables.

        Return: layer or None
            with shadow
        """
        return do_numbered_shadow(one)


class Shadow2:
    """Is the same as Shadow except that it uses Cat to get its shadow cast."""

    @staticmethod
    def do(one):
        """
        Create a drop shadow.

        one: One
            Has variables.

        Return: layer or None
            with shadow
        """
        return do_numbered_shadow(one)
