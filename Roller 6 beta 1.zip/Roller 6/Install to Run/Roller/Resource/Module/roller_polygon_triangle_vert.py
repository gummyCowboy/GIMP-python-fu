#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Triangle as ft
from roller_model_goo import Goo
from roller_polygon import (
    calc_pin_xy, make_coord_list, what_is_inverse_triangle
)


class TriangleVert:
    """Vertical triangles face up or down."""

    @staticmethod
    def calc(model, o):
        """
        For Model cell, calculate cell and merge
        rectangle and their inscribed form polygon.

        model: Model
        o: One
            with Cell Type reference

        Return: list
            [Plan vote, Work vote]
        """
        def _get_shape():
            """
            Do shape.

            Return: tuple
                shape
            """
            _x, _x1, _x2 = q_x[c], q_x[c + 1], q_x[c + 2]
            _y, _y1 = q_y[r], q_y[r + 1]

            # The '_y' value flips when inverted.
            _is_inverse = what_is_inverse_triangle(r, c)

            # Both up and down use this function,
            # but down is the inverse of up.
            if is_down:
                _is_inverse = not _is_inverse

            return (_x, _y, _x1, _y1, _x2, _y) if _is_inverse \
                else (_x, y1, _x1, _y, _x2, y1)

        vote_d = {}
        did_cell = model.past.did_cell
        row, column = model.division
        is_down = model.cell_shape in ft.DOWN_TYPE
        goo_d = model.goo_d
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect

        if o.grid_type in (gr.CELL_SIZE, gr.SHAPE_COUNT):
            # cell size
            if o.grid_type == gr.CELL_SIZE:
                # Correct cell size overflow.
                w = min(canvas_w, o.column_width)
                h = min(canvas_h, o.row_height)

                # grid size
                w1 = w / 2.
                w2 = w - w1
                s = column * w1 + w2, row * h

            else:
                # Calculate the grid size, 's'.
                # Calculate the cell size, 'w, h'.
                # shape count
                w1 = canvas_w / (.5 + column * .5)
                h1 = canvas_h / row

                # There are two possible solutions.
                # solution one
                _w, _h = h1 * ft.SCALE_UP, h1
                w2 = _w / 2.
                w3 = _w - w2
                s = column * w2 + w3, row * _h

                # solution two
                _w1, _h1 = w1, w1 * ft.SCALE_DOWN
                w2 = _w1 / 2.
                w3 = _w1 - w2
                s1 = column * w2 + w3, row * _h1

                # If the first solution fails, use solution two.
                if s[0] > canvas_w or s[1] > canvas_h:
                    s = s1
                    w, h = _w1, _h1
                else:
                    w, h = _w, _h
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

        else:
            # Calculate the cell size for cell count.
            w = canvas_w / (.5 + column * .5)
            h = canvas_h / row

        w /= 2.
        q_x = make_coord_list(canvas_w, column + 2, x, span=w)
        q_y = make_coord_list(canvas_h, row + 2, y, span=h)

        for r_c in model.cell_q:
            r, c = r_c
            y, y1 = q_y[r], q_y[r + 1]
            x, x1 = q_x[c], q_x[c + 2]
            a = goo_d[r_c] = Goo(r_c)

            # Prevent round to zero with max 1.
            a.cell.rect = a.merged.rect = \
                x, y, max(1., x1 - x), max(1., y1 - y)

            a.form = _get_shape()
            vote_d[r_c] = did_cell(r_c)
        return vote_d
