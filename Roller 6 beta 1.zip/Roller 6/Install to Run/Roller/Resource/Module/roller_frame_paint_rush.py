#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_for import Frame as ff
from roller_constant_key import Frame as ek, Material as ma, Option as ok
from roller_fu import (
    blur_selection,
    clear_selection,
    clear_inverse_selection,
    clone_layer,
    clone_opaque_layer,
    load_selection,
    merge_layer_group,
    select_item,
    set_layer_mode
)
from roller_fu_mode import get_mode
from roller_frame_alt import FrameBasic
from roller_view_hub import color_layer_default, do_curves
from roller_view_real import add_wip_base, clone_background, make_matter_group
import gimpfu as fu  # type: ignore

MIXED_EDGE = ff.WHITE_MIXED, ff.GREY_MIXED
MODE_1 = (
    fu.LAYER_MODE_DIVIDE,
    fu.LAYER_MODE_DIVIDE,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT
)
MODE_2 = (
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_SUBTRACT
)
MODE_3 = (
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_NORMAL
)
MODE_4 = (
    fu.LAYER_MODE_MULTIPLY,
    fu.LAYER_MODE_DIFFERENCE,
    fu.LAYER_MODE_DIFFERENCE,
    fu.LAYER_MODE_MULTIPLY,
    fu.LAYER_MODE_DIFFERENCE,
    fu.LAYER_MODE_DIFFERENCE
)
pdb = fu.pdb


def do_matter(maya):
    """
    Make a frame.

    maya: PaintRush
    Return: layer
        with color
    """
    def _clear_selection():
        """
        Clear the center selection and the area outside of the image material.
        """
        load_selection(j, sel1)
        clear_inverse_selection(z)
        load_selection(j, sel)
        clear_selection(z)

    j = Run.j
    cast = maya.cast.matter
    d = maya.value_d
    group = make_matter_group(maya)
    x = ff.PAINT_RUSH_TYPE.index(d[ok.EDGE_TYPE])
    group.mode = fu.LAYER_MODE_LIGHTEN_ONLY
    z = first_z = clone_opaque_layer(cast)
    z.mode = MODE_1[x]

    select_item(z)
    clear_inverse_selection(z)
    pdb.gimp_image_reorder_item(j, z, group, 0)

    # amount, '2.'; wrap, '1'; Sobel, '0'
    pdb.plug_in_edge(j, z, 2., 1, 0)

    z = dark_z = clone_layer(z, n="Dark")
    z.mode = MODE_2[x]

    pdb.gimp_image_lower_item_to_bottom(j, z)

    z = light_z = clone_layer(z, n="Light")
    z.mode = MODE_3[x]
    w = d[ok.WIDTH]

    while w:
        w1 = min(w, 500.)
        w -= w1
        blur_selection(z, w1)

    if d[ok.EDGE_TYPE] in MIXED_EDGE:
        w = d[ok.WIDTH] // 2.
        while w:
            w1 = min(w, 500.)
            w -= w1
            blur_selection(z, w1)

    pdb.gimp_image_lower_item_to_bottom(j, z)

    # Protect the center with a grey layer.
    z = clone_layer(dark_z, n="Burn")
    z.mode = fu.LAYER_MODE_BURN

    pdb.gimp_image_reorder_item(j, z, group, 2)
    do_curves(z, (.0, .5, 1., .5))
    select_item(z)
    pdb.gimp_selection_shrink(j, int(d[ok.WIDTH]))

    sel = pdb.gimp_selection_save(j)

    clear_inverse_selection(z)
    select_item(first_z)

    sel1 = pdb.gimp_selection_save(j)
    z = clone_layer(light_z, n="Accent")
    z.mode = MODE_4[x]

    pdb.gimp_image_lower_item_to_bottom(j, z)

    z = add_wip_base("Grey", group)

    color_layer_default(z, (127, 127, 127))

    n = d[ok.EDGE_MODE]
    z = merge_layer_group(group)

    set_layer_mode(z, get_mode({ok.MODE: n}))
    _clear_selection()

    if n == "Burn":
        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)

    else:
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

    if d[ok.POST_BLUR]:
        blur_z = clone_background(z, n="Post Blur", is_hide=False)

        pdb.gimp_image_remove_layer(j, z)

        z = blur_z

        blur_selection(z, d[ok.POST_BLUR])
        _clear_selection()

    if d[ok.COLORIZE]:
        z = clone_background(
            z, n="Colorify", is_hide=False, on_top=True
        )
        z.opacity = d[ok.COLORIZE_OPACITY]

        pdb.plug_in_colorify(j, z, d[ok.COLOR_1])

        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        _clear_selection()

    pdb.gimp_image_remove_channel(j, sel)
    pdb.gimp_image_remove_channel(j, sel1)
    return z


class PaintRush(FrameBasic):
    """Create a frame over the subject material by altering it."""
    add_row = shade_row = ok.BRW
    kind = ek.PAINT_RUSH
    material = ma.PAINT_RUSH
    wrap_k = ok.WRAP_PR

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
