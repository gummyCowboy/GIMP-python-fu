#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Deco, Run
from roller_constant_for import Issue as vo, Signal as si
from roller_constant_key import Option as ok
from roller_fu import (
    clone_layer, select_item, select_opaque, select_rect
)
from roller_maya import check_mix_basic, check_matter, on_global
from roller_maya_build import SubBuild
from roller_one_wip import Wip
from roller_view_hub import do_mod
from roller_view_real import clip_to_wip, clone_background, mask_from_maya
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def blur_below_matter(maya):
    """
    Blur Below the super's matter layer.

    maya: BlurBelow
    Return: layer or None
        with Blur Below Material
    """
    j = Run.j
    group = maya.super_maya.group
    d = maya.value_d

    # When there is no Blur Below layer, 'z'.
    z = None

    if group:
        # Blur Below layer, 'z'
        if Deco.bg_z:
            z = clone_layer(Deco.bg_z)

        else:
            z = clone_background(group)

        z.name = group.name + " Blur Below"

        select_rect(j, *Wip.get_rect())
        do_mod(z, d[ok.MOD])
        clip_to_wip(z)
    return z


class BlurBelow(SubBuild):
    """
    Manage Blur Below option's layer output. Blur Below
    is done after Frame and Shadow Maya during a View run.
    """
    issue_q = 'matter', 'mode', 'opacity'
    put = (check_matter, 'matter'), (check_mix_basic, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            The Maya's 'matter' layer alpha becomes the output mask.
        """
        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.MOD,)],
            blur_below_matter
        )
        self.latch(any_group, (si.BACK_CHANGE, self.on_back_change))

    def do(self, d, is_back, is_mask):
        """
        Manage layer output during a View run.

        d: dict or None
            Blur Below Preset

        is_back: bool or None
            Is True when the background has change.

        is_mask: bool
            If True, then the Blur Below is masked from its over-layer.

        Return: bool
            Is True if BlurBelow changed.
        """
        self.value_d = d
        self.go = d[ok.SWITCH] and bool(self.super_maya.matter)

        if self.go:
            self.is_matter |= is_back
            m = self.is_matter or is_mask

        else:
            m = False

        self.realize()

        if self.matter and m:
            mask_from_maya(
                self.super_maya,
                self.matter,
                select_opaque if d[ok.OPAQUE] else select_item
            )

        self.reset_issue()
        return m

    def on_back_change(self, _, x):
        """
        The background changed for the group.

        _: AnyGroup
            Sent the Signal.

        x: int
            Plan or Work index
        """
        if x == self.view_x:
            arg = [None, None]
            arg[x] = True
            on_global(self, arg, ok.IS_BACK, issue=vo.MATTER)
