#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import radians
from roller_a_contain import Run
from roller_constant_for import Issue as vo
from roller_constant_key import Option as ok, Step as sk, SubMaya as sm
from roller_fu import merge_layer_group, select_polygon
from roller_maya import check_matter, check_mix_basic
from roller_maya_build import Build
from roller_maya_bump import Bump
from roller_maya_shadow import Shadow
from roller_maya_style import check_style_group
from roller_one_wip import Wip
from roller_view_hub import (
    calc_gradient, color_selection, do_mod, set_fill_context_default
)
from roller_view_real import (
    add_sub_base_group,
    add_wip_layer,
    clip_to_wip,
    finish_style,
    get_point_on_edge
)
from roller_view_shadow import make_shadow, make_shadow_inner

LEFT, TOP, RIGHT, BOTTOM = range(4)


def do_shadow_preset(d, outer_cast_q, inner_cast_z, parent):
    """
    Make up to three shadow layers.

    d: dict
        Shadow SuperPreset

    outer_cast_q: tuple
        of layers to pass to Shadow #1 and Shadow #2

    inner_cast_z: layer
        cast an inner shadow

    parent: layer group
        Where the shadow layer is placed.
    """
    make_shadow(
        d[sk.SHADOW_1],
        parent,
        outer_cast_q,
        name=parent.name + " Shadow 1"
    )
    make_shadow(
        d[sk.SHADOW_2],
        parent,
        outer_cast_q,
        name=parent.name + " Shadow 2"
    )
    make_shadow_inner(
        d[sk.INNER_SHADOW],
        parent,
        inner_cast_z,
        name=parent.name + " Inner Shadow"
    )


def make_style(maya):
    """
    Draw a fan of wedges colored by one color transiting to another.

    maya: Style
    Return: layer or None
        with Floor Sample material
    """
    def _get_side(_x, _y):
        """
        Determine the side that a vector intersects.

        _x, _y: float
            point on the rectangle bounds

        Return: int
            index to the side the vector intersects
        """
        if _x >= right_x and _y < bottom_y:
            return RIGHT

        if _y >= bottom_y and _x > left_x:
            return BOTTOM

        if _x <= left_x and _y > top_y:
            return LEFT
        return TOP

    j = Run.j
    d = maya.value_d
    shadow_d = d[ok.RW1][ok.SHADOW]
    has_shadow = shadow_d[sk.SHADOW_SWITCH][ok.SWITCH]
    color, color1 = d[ok.COLOR_2A]

    set_fill_context_default()

    angle = radians(360. / d[ok.SLICE_COUNT])
    slice_cnt = int(d[ok.SLICE_COUNT])
    left_x, top_y, w, h = Wip.get_rect()
    right_x = w + left_x
    bottom_y = h + top_y
    center_x, center_y = Wip.center()
    start_angle = radians(d[ok.ANGLE])
    group = add_sub_base_group(maya)
    step = calc_gradient(color, color1, slice_cnt)
    start_color = color

    # Indexed by side. The order is TOP, RIGHT, BOTTOM, LEFT.
    corner_q = (
        (left_x, top_y),
        (right_x, top_y),
        (right_x, bottom_y),
        (left_x, bottom_y)
    )

    # Collect vector rectangle intersect.
    # intersect
    q_x = []
    q_y = []

    for _ in range(slice_cnt):
        x, y = get_point_on_edge(start_angle)
        q_x += [x]
        q_y += [y]
        start_angle += angle

    # Add repeating start vector to simplify the final polygon arrangement.
    q_x += [q_x[0]]
    q_y += [q_y[0]]

    # Assemble and draw color filled polygon.
    for ray_x in range(slice_cnt):
        # The variables 'side 1' and 'side 2'
        # are the sides of the image-rectangle
        # that the arc begins and ends.
        # line 1
        x, y = q_x[ray_x], q_y[ray_x]
        q = center_x, center_y, x, y
        side_1 = _get_side(x, y)

        # line 2
        x1, y1 = q_x[ray_x + 1], q_y[ray_x + 1]
        side_2 = _get_side(x1, y1)

        if side_1 != side_2:
            # Add corner points to the polygon.
            side_x = side_1
            for _ in range(4):
                # Add a corner point.
                q += corner_q[side_x]

                if side_x == side_2:
                    break

                side_x += 1
                if side_x > BOTTOM:
                    side_x = 0

        q += x1, y1

        select_polygon(j, q)

        z = add_wip_layer("Edge", group)

        color_selection(z, color)

        if has_shadow:
            do_shadow_preset(shadow_d, (z,), z, group)

        # Calculate the next polygon color.
        color = ()
        for i in range(4):
            b = step[i] * (ray_x + 1)
            color += (start_color[i] + int(b),)

    z = merge_layer_group(group)

    clip_to_wip(z)
    do_mod(z, d[ok.RW1][ok.MOD])
    return finish_style(z, "Floor Sample")


class FloorSample(Build):
    """Create Backdrop Style output."""
    is_dependent = False
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (check_style_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None),
    )
    vote_type = vo.MAIN

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Has the Backdrop Style Button.

        super_maya: Backdrop Maya
        k_path: tuple
            Is the key path to the Backdrop Style
            Button in the AnyGroup's vote dict.
        """
        Build.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.RW1, ok.SHADOW),
                k_path + (ok.RW1, ok.MOD)
            ],
            make_style
        )

        self.sub_maya[sm.BUMP] = Bump(
            any_group, self, k_path + (ok.BRW, ok.BUMP)
        )
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group, self, (self,), k_path + (ok.RW1, ok.SHADOW)
        )

    def do(self, z, d, is_change):
        """
        Produce or modify layer output.

        z: layer
            Backing output
            not used

        d: dict
            Backdrop Style Preset

        is_change: bool
            not used
            Is the state of the super Maya's matter and/or mask.
            Floor Sample is independent of the Backing layer.
        """
        self.value_d = d
        self.is_matter |= self.sub_maya[sm.SHADOW].get_any_vote()

        self.realize()
        self.sub_maya[sm.BUMP].do(
            self.value_d[ok.BRW][ok.BUMP], self.is_matter, False
        )
        self.sub_maya[sm.SHADOW].reset_all_issue()
        self.reset_issue()
