#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_INTERSECT, CLIP_TO_IMAGE, pdb  # type: ignore
from roller_a_contain import Cat, Deco, Run
from roller_constant_for import Caption as pt, Justification as ju, Model as mo
from roller_constant_key import Option as ok
from roller_deco import (
    get_obey_margins, ready_canvas_rect, ready_shape, transform_foam
)
from roller_fu import (
    clear_inverse_selection,
    get_select_coord,
    make_text_layer,
    remove_z,
    select_item,
    select_rect,
    select_shape,
    verify_layer,
    verify_layer_group
)
from roller_fu_comm import info_msg
from roller_view_hub import color_selection_default, do_mod
from roller_view_preset import calc_margin
from roller_view_real import add_wip_below, add_wip_layer, make_group


def do(maya, make):
    """
    Create Caption output. Plan overrides and restores its required option.

    maya: Maya
    make: function
        Call to make the Caption material.
    """
    d = maya.value_d

    if not Run.x:
        # Preserve.
        mode = d[ok.MODE]
        color = d[ok.RW1][ok.COLOR_1]

        # Override.
        d[ok.MODE] = "Normal"
        d[ok.RW1][ok.COLOR_1] = 255, 255, 255

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.x:
        # Restore.
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
    return z


def do_canvas(maya):
    """
    Draw a Canvas branch Caption.

    maya: Maya
    Return: layer or None
    """
    return do(maya, make_canvas)


def do_cell(maya):
    """
    Draw a Cell/Per Caption.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_per_cell)


def do_face(maya):
    """
    Draw a Face/Per Caption.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell_face)


def do_facing(maya):
    """
    Draw a Facing/Per Caption.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell_facing)


def do_main_cell(maya):
    """
    Draw cell material for the main option settings.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main)


def do_main_face(maya):
    """
    Draw Face.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main_face)


def do_main_facing(maya):
    """
    Draw Facing.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main_facing)


def fetch_rect(maya, d, k):
    """
    Retrieve a Maya's rectangle (Cell, Face, or Facing) using its Goo key.

    maya: Maya
    d: dict
        Caption Preset

    k: string
        Goo key

    Return: Rect or None
        as requested
    """
    if get_obey_margins(d):
        # with Margin applied
        return maya.model.get_pocket_rect(k)
    else:
        # with Shift applied
        return maya.model.get_shift_rect(k)


def make_canvas(maya, d):
    """
    Make Caption for the Canvas branch.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        with material
    """
    ready_canvas_rect(maya, d, option=None)
    return verify_layer(make_caption_text(maya, d, maya.group, None))


def make_canvas_strip(maya):
    """
    Make a background Strip for the Canvas Caption.

    maya: Maya
    Return: layer or None
        with Caption material
    """
    a = maya.super_maya

    ready_canvas_rect(a, a.value_d, option=None)

    maya.rect = a.rect
    return verify_layer(make_strip(maya, maya.group))


def make_caption_text(maya, d, group, arg, seq_n=""):
    """
    Create text. Call once per Caption instance.

    maya: Maya
    d: dict
        Caption Preset

    group: layer
        Is the parent of the text layer.

    arg: tuple or None
        key for storing text position and height

    seq_n: string
        Append to the sequence value.
        Is used by sub-Face.
        Is only applied if the Caption/Type is Sequence.

    is_facing: bool
        Is True if the Caption is Facing-branch output.

    Return: layer or None
        with Caption material
    """
    def _get_text():
        """
        Assemble the text as defined by the options.

        Return: string
            the Caption text
        """
        _text = ""
        type_ = d[ok.TYPE]

        if type_ == pt.TEXT:
            _text = d[ok.TEXT]

        elif type_ == pt.SEQUENCE:
            _text = str(
                maya.model.cell_q.index(maya.k[:2]) +
                int(d[ok.START_NUMBER])
            ) + seq_n

        elif type_ == pt.IMAGE_NAME:
            _text = maya.get_image_name(maya.k)

        if type_ in (pt.IMAGE_NAME, pt.SEQUENCE) and _text:
            _n = d[ok.LTR][ok.LEAD]
            _n1 = d[ok.LTR][ok.TRAIL]
            _text = _n + _text + _n1
        return _text

    j = Run.j

    # Caption failsafe layer, 'z'
    z = None

    go = True
    font = d[ok.RW1][ok.FONT]
    text = _get_text()
    color = d[ok.RW1][ok.COLOR_1]

    if font not in Cat.font_list:
        info_msg(mo.MISSING_ITEM.format("Caption", "font", font))
        go = False

    if go:
        if text:
            go, z = make_text_layer(
                j,
                add_wip_layer("Material", group),
                1,                          # yes, antialias
                text,
                d[ok.FONT_SIZE],
                font,
                color,
                .0, .0,                     # x, y
                .0, .0                      # w, h
            )
        else:
            go = False

    if go:
        # Select the layer for autocrop.
        select_item(z)

        pdb.plug_in_autocrop_layer(j, z)

        rect_x, rect_y, rect_w, rect_h = maya.rect
        x, y, x1, y1 = get_select_coord(j)
        text_w = x1 - x
        text_h = y1 - y
        half_w = text_w / 2.
        half_h = text_h / 2.
        top, bottom, left, right = calc_margin(d[ok.RW1][ok.MARGIN])

        # cell width, height
        w = max(1., rect_w - left - right)
        h = max(1., rect_h - top - bottom)
        n = d[ok.JUSTIFICATION]

        # cell position x, y
        x = rect_x + left
        y = rect_y + top

        # Get 'y'.
        if n in ju.BOTTOM:
            y += h - text_h

        elif n in ju.CENTER_Y:
            y += (h / 2.) - half_h

        # Get 'x'.
        if n in ju.RIGHT:
            x += w - text_w

        elif n in ju.CENTER_X:
            x += (w / 2.) - half_w

        # Move the text layer.
        pdb.gimp_layer_set_offsets(z, int(x), int(y))

        # Save the Cell's text selection for Strip.
        maya.model.set_caption_y(arg, (y, z.height))

        if d[ok.OCR][ok.CLIP]:
            select_shape(j, Deco.shape)
            clear_inverse_selection(z)

    else:
        remove_z(z)
        z = None
    return z


def make_cell_face(maya, d):
    """
    Make Caption for Face/Per.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        with material
    """
    return produce_cell_facing(maya, d, make_face)


def make_cell_facing(maya, d):
    """
    Make Caption for Facing/Per.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        with material
    """
    return produce_cell_facing(maya, d, make_facing)


def make_cell_face_strip(maya):
    """
    Make Strip for Face/Per.

    maya: Maya
        Per Cell

    Return: layer or None
        with Strip material
    """
    return produce_cell_facing_strip(maya, make_face_strip)


def make_cell_facing_strip(maya):
    """
    Make Strip for Facing/Per.

    maya: Maya
        Per Cell

    Return: layer or None
        with Strip material
    """
    return produce_cell_facing_strip(maya, make_facing_strip)


def make_cell(maya, d, group, is_main=False):
    """
    Make Caption for Cell/Per.

    maya: Maya
    d: dict
        Caption Preset

    group: layer
        Is the destination parent layer group of cell output.

    is_main: bool
        If True, then the output layer can skip the finish check.

    Return: layer or None
        with material
    """
    ready_shape(maya, d, option=None)

    z = make_caption_text(maya, d, group, maya.k)

    if is_main:
        return z
    return verify_layer(z)


def make_cell_strip(maya):
    """
    Make a Cell/Per Strip.

    maya: Maya
    Return: layer or None
        with material
    """
    a = maya.super_maya

    ready_shape(a, a.value_d, option=None)

    maya.rect = a.rect
    maya.k = a.k
    return make_strip(maya, maya.group)


def make_face(maya, d, group):
    """
    Apply Face material.

    maya: Maya
    d: dict
        Caption Preset

    group: layer
        Is the parent of Face output.
    """
    k = maya.k
    model = maya.model
    Deco.shape = model.get_facing_shape(k)

    # Transform is less likely to be clipped
    # from the topleft corner of the layer, '(.0, .0)'.
    maya.rect = (.0, .0) + model.get_facing_rect(k)[2:]

    # Face index position, '-1;
    z = make_caption_text(maya, d, group, k, seq_n="abc"[k[-1]])
    if z:
        # Set the layer size for the transform by
        # merging the text layer with a new layer.
        add_wip_below(z, "Resize")

        z = pdb.gimp_image_merge_down(Run.j, z, CLIP_TO_IMAGE)
        transform_foam(maya.rect, z, model.get_facing_foam(k))


def make_facing(maya, d, group):
    """
    Apply Face material.

    maya: Maya
    d: dict
        Caption Preset

    group: layer
        Is the parent of Face output.
    """
    k = maya.k
    model = maya.model
    Deco.shape = model.get_facing_form(k)

    # Transform is less likely to be clipped
    # from the topleft corner of the layer, '(.0, .0)'.
    maya.rect = (.0, .0) + model.get_facing_rect(k)[2:]

    z = make_caption_text(maya, d, group, k)
    if z:
        # Set the layer size for the transform by
        # merging the text layer with a new layer.
        add_wip_below(z, "Resize")

        z = pdb.gimp_image_merge_down(Run.j, z, CLIP_TO_IMAGE)
        z = transform_foam(maya.rect, z, model.get_facing_foam(k))
        model.clip_facing(z, k)


def make_face_strip(maya, group):
    """
    Create Face Strip.

    maya: Maya
    group: layer
        Is the destination of Face Strip layer.

    Return: layer or None
        with Face Strip
    """
    model = maya.model
    k = maya.k
    group = make_group("Material", group)
    maya.rect = (.0, .0) + (model.get_facing_rect(k)[2:])
    Deco.shape = model.get_facing_shape(k)
    z = make_strip(maya, group, is_finish=False)

    if z:
        transform_foam(maya.rect, z, model.get_facing_foam(k))
    return verify_layer_group(group)


def make_facing_strip(maya, group):
    """
    Create Facing Strip.

    maya: Maya
    group: layer
        Is the destination of Facing Strip layer.

    Return: layer or None
        with Facing Strip
    """
    model = maya.model
    k = maya.k
    maya.rect = (.0, .0) + (model.get_facing_rect(k)[2:])
    Deco.shape = model.get_facing_form(k)
    z = make_strip(maya, group, is_finish=False)
    if z:
        z = transform_foam(maya.rect, z, model.get_facing_foam(k))

        model.clip_facing(z, k)
        return z


def make_main(maya, d):
    """
    Draw Caption for the main option settings.
    Main combines Caption output into one layer.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        with material
    """
    parent = maya.group
    group = make_group("Material", parent, offset=len(parent.layers))

    for k in maya.main_q:
        maya.k = k
        make_cell(maya, d, group, is_main=True)
    return verify_layer_group(group)


def make_main_face(maya, d):
    """
    Make Caption for Face main option settings.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        with material
    """
    return produce_main_facing(maya, d, make_face)


def make_main_facing(maya, d):
    """
    Make Caption for Face main option settings.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        with material
    """
    return produce_main_facing(maya, d, make_facing)


def make_main_face_strip(maya):
    """
    Make a Strip for Face main option settings.

    maya: Maya
    Return: layer or None
        with Strip material
    """
    return produce_main_facing_strip(maya, make_face_strip)


def make_main_facing_strip(maya):
    """
    Make a Strip for Facing main option settings.

    maya: Maya
    Return: layer or None
        with Strip material
    """
    return produce_main_facing_strip(maya, make_facing_strip)


def make_main_strip(maya):
    """
    Draw Strip for the main option settings.
    Main combines Strip output into one layer.

    maya: Maya
        Strip

    Return: layer or None
        with material
    """
    group = make_group("Material", maya.group)
    a = maya.super_maya
    p = maya.model.get_plaque

    for k in a.main_q:
        maya.k = k
        maya.rect = fetch_rect(a, a.value_d, k)
        Deco.shape = p(k)
        make_strip(maya, group, is_finish=False)
    return verify_layer_group(group)


def make_per_cell(maya, d):
    """
    Is needed for its signature.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        with Caption text
    """
    return make_cell(maya, d, maya.group)


def make_strip(maya, group, is_finish=True):
    """
    Create a background Strip for a Caption.

    maya: Maya
        Strip

    group: layer
        Is the parent group for Strip output.

    is_finish: bool
        When true, the Strip layer is finish checked.

    Return: layer or None
        with material
    """
    k = maya.k
    d = maya.value_d
    q = maya.model.get_caption_y(k)
    if q:
        y, text_h = q
        j = Run.j

        # A failed Strip layer is None, 'z1'.
        z1 = None

        super_maya = maya.super_maya
        z = super_maya.matter
        if z:
            half_h = text_h // 2.
            center_y = y + half_h
            strip_h = text_h * d[ok.HEIGHT]
            if strip_h:
                y = center_y - strip_h // 2.

                # A WIP layer fails, so go with a View sized layer.
                z1 = add_wip_layer("Material", group)

                color = d[ok.COLOR_1]

                select_rect(j, maya.rect[0], y, maya.rect[2], strip_h)

                if super_maya.value_d[ok.OCR][ok.CLIP]:
                    select_shape(
                        j, Deco.shape, option=CHANNEL_OP_INTERSECT
                    )

                color_selection_default(z1, color)
                if is_finish:
                    verify_layer(z1)
        return z1


def produce_cell_facing(maya, d, p):
    """
    Make Caption for Facing/Per.

    maya: Maya
    d: dict
        Caption Preset

    p: function
        Call to create cell Face/Facing.

    Return: layer or None
        with material
    """
    group = make_group("Material", maya.group)

    p(maya, d, group)
    return verify_layer_group(group)


def produce_cell_facing_strip(maya, p):
    """
    Make Strip for a Per Cell Face/Facing.

    maya: Maya
        Per Cell

    p: function
        Call to produce Strip output.

    Return: layer or None
        with Strip material
    """
    group = make_group("Material", maya.group)
    maya.k = maya.super_maya.k

    p(maya, group)
    return verify_layer_group(group)


def produce_main_facing(maya, d, p):
    """
    Make Caption for Face main option settings.

    maya: Maya
    d: dict
        Caption Preset

    p: function
        Call to make Facing.

    Return: layer or None
        with material
    """
    group = make_group("Material", maya.group)

    for k in maya.main_q:
        maya.k = k
        p(maya, d, group)
    return verify_layer_group(group)


def produce_main_facing_strip(maya, p):
    """
    Make a Strip for Face main option settings.

    maya: Maya
    p: function
        Call to make Face/Facing Strip.

    Return: layer or None
        with Strip material
    """
    group = make_group("Material", maya.group)

    for k in maya.super_maya.main_q:
        maya.k = k
        p(maya, group)
    return verify_layer_group(group)
