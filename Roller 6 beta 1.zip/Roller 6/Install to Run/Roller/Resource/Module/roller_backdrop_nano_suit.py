#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_a_gegl import engrave, video_degradation
from roller_constant_key import Option as ok
from roller_fu import clone_layer, make_layer_group, merge_layer_group
from roller_maya_style import Style, make_background
from roller_view_hub import do_mod
from roller_view_real import add_sub_base_group, finish_style
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: NanoSuit
    Return: layer
        with style material
    """
    # Is dependent.
    if maya.go:
        j = Run.j
        d = maya.value_d
        parent = add_sub_base_group(maya)
        z = make_background(parent)
        group = make_layer_group(j, "WIP", parent=parent, z=z)

        # Curves won't work with a selection.
        pdb.gimp_selection_none(j)

        video_degradation(z, 'dots')

        z = clone_layer(z, n="Difference")
        z.mode = fu.LAYER_MODE_DIFFERENCE

        engrave(z, 3)
        pdb.gimp_drawable_curves_spline(
            z, fu.HISTOGRAM_VALUE, 4, (.0, .5, 1., 1.)
        )
        merge_layer_group(group)

        z = merge_layer_group(parent)

        do_mod(z, d[ok.BRW][ok.MOD])
        return finish_style(z, "Nano Suit")


class NanoSuit(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
