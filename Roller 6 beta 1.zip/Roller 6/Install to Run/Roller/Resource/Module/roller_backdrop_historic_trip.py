#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_DISSOLVE,
    LAYER_MODE_GRAIN_MERGE,
    LAYER_MODE_HSV_VALUE,
    pdb
)
from roller_a_contain import Globe, Run
from roller_a_gegl import emboss, spread, waterpixels
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection, clone_layer, make_layer_group, merge_layer_group
)
from roller_maya_style import Style, make_background
from roller_view_hub import color_layer_default, do_mod, get_mean_color
from roller_view_real import (
    add_sub_base_group, finish_style, insert_copy_above
)


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: HistoricTrip
    Return: layer or None
        with style material
    """
    def _merge(_z, _n):
        """
        Merge a group and set its layer mode.

        _z: layer group
            to merge

        _n: string
            version number

        return: layer
            Is the result of the merge.
        """
        _z = merge_layer_group(_z)
        _z.mode = LAYER_MODE_GRAIN_MERGE
        _z.name = "Grain Merge " + _n
        pdb.plug_in_colortoalpha(j, _z, (0, 0, 0))
        return _z

    # Is dependent.
    if maya.go:
        j = Run.j
        d = maya.value_d
        parent = add_sub_base_group(maya)
        z = make_background(parent)
        key = maya.any_group.item.key
        bg_1 = clone_layer(z, n="Original #1")
        bg_2 = clone_layer(z, n="Original #3")
        group = make_layer_group(j, "WIP", parent=parent, z=z)
        group1 = make_layer_group(j, key + " WIP #2", parent=group, z=bg_1)
        z2 = clone_layer(bg_1, n="Difference #1")
        z2.mode = LAYER_MODE_DIFFERENCE
        color = get_mean_color(z)
        loop_cnt = int(d[ok.ITERATIONS])
        spread_a = int(d[ok.SPREAD])

        for _ in range(loop_cnt):
            spread(z2, 0, amount_x=spread_a, amount_y=min(6, spread_a))

        group2 = make_layer_group(j, "Sub-Group", parent=group, z=bg_2)
        z2 = clone_layer(bg_2, n="Difference #2")
        z2.mode = LAYER_MODE_DIFFERENCE

        for _ in range(loop_cnt):
            spread(z2, 0, amount_x=min(6, spread_a), amount_y=spread_a)

        color_layer_default(z, color)

        z1 = _merge(group1, "#1")
        z2 = _merge(group2, "#2")
        z = insert_copy_above(z2, parent.layers[0])
        dissolve_z = clone_layer(z, n="Dissolve")
        z.mode = LAYER_MODE_HSV_VALUE

        emboss(z1, Globe.azimuth, 12, 1)
        emboss(z2, Globe.azimuth, 12, 1)
        waterpixels(z, size=int(d[ok.SUPERPIXEL_SIZE]))
        dissolve_z.mode = LAYER_MODE_DISSOLVE
        dissolve_z.opacity = 50.
        blur_selection(dissolve_z, 1)
        insert_copy_above(dissolve_z, parent.layers[0])
        merge_layer_group(group)

        z = merge_layer_group(parent, n="Despeckle")

        pdb.plug_in_despeckle(
            j, z,
            1,                  # radius
            0,
            -1,                 # black cut-off
            256                 # white cut-off
        )

        do_mod(z, d[ok.BRW][ok.MOD])
        return finish_style(z, "Historic Trip")


class HistoricTrip(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
