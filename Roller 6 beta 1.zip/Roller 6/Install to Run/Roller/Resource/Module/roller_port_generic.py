#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_port_preview import PortPreview
from roller_widget_node import Piece


# PortGeneric__________________________________________________________________
class PortGeneric(PortPreview):
    """Is a display container for a Preset."""

    def __init__(self, d, g, k, is_random=True):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Is responsible.

        k: string
            Preset Option key
        """
        self._is_random = is_random
        self._preset_k = k
        PortPreview.__init__(self, d, g)

    def _draw(self, box):
        """
        Draw the Preset option group.

        box: GTK container
            to receive group
        """
        self.draw_group(Piece(
            self._preset_k, box, self.repo.any_group.item, has_label=False
        ))

    def draw(self):
        """Draw Widget."""
        p = self.draw_random_process_group if self._is_random \
            else self.draw_process
        self.draw_column((self._draw, p))

    def get_group_value(self):
        """
        Get the Preset value dict.

        Return: dict
            Preset
        """
        return self.preset.get_a()


class PortAdd(PortGeneric):
    window_key = "Add"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.ADD, is_random=False)


class PortAddAbove(PortGeneric):
    window_key = "Add"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.ADD_ABOVE, is_random=False)


class PortAddAlt(PortGeneric):
    window_key = "Add"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.ADD_ALT, is_random=False)


class PortBacking(PortGeneric):
    window_key = "Backing"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.BACKING)


class PortBelow(PortGeneric):
    window_key = "Below"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.BELOW)


class PortBrush(PortGeneric):
    window_key = "Brush"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.BRUSH_D)


class PortBrushPD(PortGeneric):
    window_key = "Brush"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.BRUSH_D1)


class PortBump(PortGeneric):
    window_key = "Bump"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.BUMP)


class PortMargin(PortGeneric):
    window_key = "Margin"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.MARGIN)


class PortMod(PortGeneric):
    window_key = "Mod"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.MOD)


class PortNoise(PortGeneric):
    window_key = "Noise"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.NOISE_D)


class PortResize(PortGeneric):
    window_key = "Resize"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.RESIZE, is_random=False)


class PortShadowBasic(PortGeneric):
    window_key = "Shadow Basic"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.SHADOW_BASIC)


class PortStencil(PortGeneric):
    window_key = "Stencil"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.STENCIL)


class PortStrip(PortGeneric):
    window_key = "Strip"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.STRIP)


class PortTape(PortGeneric):
    window_key = "Tape"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.WRAP_TA)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# PortFiller___________________________________________________________________
class PortFiller(PortGeneric):
    window_key = "Filler"

    def __init__(self, d, g, k):
        PortGeneric.__init__(self, d, g, k)


class PortFillerCeramic(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_CE)


class PortFillerChecker(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_CH)


class PortFillerCircuit(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_CI)


class PortFillerFence(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_FE)


class PortFillerHoley(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_HO)


class PortFillerMecha(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_ME)


class PortFillerMirror(PortFiller):

    def __init__(self, d, g):
        """d, g: PortGeneric spec"""
        PortFiller.__init__(self, d, g, ok.FILLER_MI)


class PortFillerRad(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_RA)


class PortFillerStained(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_S1)


class PortFillerStretch(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_S2)


class PortFillerStripe(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_S3)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# PortOverlay__________________________________________________________________
class PortOverlay(PortGeneric):
    window_key = "Overlay"

    def __init__(self, d, g, k):
        PortGeneric.__init__(self, d, g, k)


class PortOverlayBevel(PortOverlay):

    def __init__(self, d, g):
        PortOverlay.__init__(self, d, g, ok.OVERLAY_BE)


class PortOverlayCamo(PortOverlay):

    def __init__(self, d, g):
        PortOverlay.__init__(self, d, g, ok.OVERLAY_CA)


class PortOverlayColor(PortOverlay):

    def __init__(self, d, g):
        PortOverlay.__init__(self, d, g, ok.OVERLAY_CO)


class PortOverlayOver(PortOverlay):

    def __init__(self, d, g):
        PortOverlay.__init__(self, d, g, ok.OVERLAY_OV)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# PortWrap_____________________________________________________________________
class PortWrap(PortGeneric):
    window_key = "Wrap"

    def __init__(self, d, g, k=ok.WRAP):
        PortGeneric.__init__(self, d, g, k)


class PortWrapAddAbove(PortGeneric):
    window_key = "Add"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.WRAP_AB)


class PortWrapAlt(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_AL)


class PortWrapBevel(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_BE)


class PortWrapBurst(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_BU)


class PortWrapClear(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_CL)


class PortWrapCrumble(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_CR)


class PortWrapDecay(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_DE)


class PortWrapFill(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_FI)


class PortWrapGlue(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_GL)


class PortWrapGradual(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_GR)


class PortWrapJoint(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_JO)


class PortWrapPattern(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_PA)


class PorWraptPipe(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_PI)


class PortWrapWobble(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_WO)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
