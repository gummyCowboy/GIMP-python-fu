#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore


class Cat(object):
    """"""
    # Are the color palette settings at startup. Use with FG and BG gradient.
    # RGBA; (float, float, float, float); .0 to 1.
    # gimpcolor
    background = foreground = None

    # GIMP brush
    brush_list = []

    # GIMP font
    font_list = []

    # GIMP gradient
    gradient_list = []

    # GIMP pattern
    pattern_list = []

    @staticmethod
    def load():
        # GIMP brush
        Cat.brush_list = sorted(pdb.gimp_brushes_get_list(None)[1])

        # GIMP font
        Cat.font_list = sorted(pdb.gimp_fonts_get_list(None)[1])

        # GIMP gradient
        Cat.gradient_list = sorted(pdb.gimp_gradients_get_list(None)[1])

        # GIMP pattern
        Cat.pattern_list = sorted(pdb.gimp_patterns_get_list(None)[1])

        # Remember for gradient type using the FG and BG.
        Cat.background = pdb.gimp_context_get_background()
        Cat.foreground = pdb.gimp_context_get_foreground()


class Deco:
    """Is container for Maya and deco output."""
    # Fringe/Type/Multi-color color index
    color_x = 0

    # for deco Type/Below and Cast's Blur Below
    bg_z = None

    # a tuple of x, y canvas coordinate used to draw a polygon
    # Use with margins.
    shape = None


class Dog:
    """
    Initialize a class during program start as
    part of a circular import reference solution.
    """
    many_group = none_group = loner_group = None

    # For Maya AnyGroup, translate key to class.
    class_group = None

    @staticmethod
    def load(class_group, loner_group, many_group, none_group):
        """Initialize global access variables."""
        Dog.class_group = class_group
        Dog.loner_group = loner_group
        Dog.many_group = many_group
        Dog.none_group = none_group


class Globe:
    """Store Global Preset value for a View run."""
    seed = 0
    azimuth = elevation = .0

    # Is the actual image size on display and
    # is calculated from the Global render size and the WIP factor.
    view_size = 0, 0


class Gradient:
    """Has Gradient Light variable."""
    image = None


class One(object):
    """Is a generic-based container."""

    def __init__(self, **d):
        """
        Is an object. All is one. Add attribute to the object.

        d: dict
            Each {key: value} pair becomes a self attribute where key
            is the attribute id, and the value is the attribute's.
        """
        for k, a in d.items():
            setattr(self, k, a)


class PlanZ:
    plan_group = None


class Pot:
    """Store Image scope variable during a View run."""

    # Is a tuple of x, y coordinate used to transform
    # an image rectangle into a polygon.
    # Each x, y pair is a polygon vertex and ordered
    # from the left-most top in a clockwise rotation.
    foam = None

    # Use to skip a transform step where the source
    # rectangle is sized down. Is true when the source
    # rectangle is smaller than the pocket rectangle.
    is_small = False

    # Is a temp GIMP image that is deleted at the end image place.
    temp_image = None


class Run:
    """Is a container for View run output."""

    # Is the background change state during a View response.
    is_back = False

    # Is True if GIMP's Layers dock is frozen.
    is_frozen = False

    # Is True when Work is doing a Preview.
    is_preview = False

    # The GIMP image created and rendered by Roller.
    j = None

    # image dict
    # Recall image assignment.
    j_d = None

    # dict
    # {navigation step key: snapshot of image dict after a step execution}
    pre_j_d = {}

    # Is an index for the split in View processing.
    # Plan and Work, where 0 is for Plan and 1 is for Work.
    x = None


class The:
    """
    Has class and variable that won't import directly
    due to a circular reference. Variables are
    initialized during Roller start-up.
    """
    # Is the frame file path used by Over.
    frame_path = ""

    # Use with ImageGradient to delete unused gradients.
    image_gradient_used = None

    # Use with ImageGradient to delete unused gradients.
    image_gradient_created = []

    # Use to remember the image file path for an OSButton.
    image_path = ""

    # Set when loading a Preset or SuperPreset. Suppress UI update.
    load_count = 0

    # NumberPair class
    number_pair = None

    # Preset class
    preset = None

    # Is the root folder for Preset storage.
    preset_path = ""

    # "Roller/Resource" folder
    resource_path = ""

    # SuperPreset class
    super_preset = None

    # Window position dict
    window_pose = {}


class ViewSize:
    """
    Is the actual image size on display and is calculated
    from the Global render size and the WIP factor.
    """
    w = h = .0


class Mold:
    """Contain the final Image rectangle during a run."""
    x = y = w = h = .0

    @staticmethod
    def center():
        """
        Calculate the center point for the rectangle.

        Return: tuple
            (x, y)
            center point
        """
        return Mold.x + (Mold.w / 2.), Mold.y + (Mold.h / 2.)

    @staticmethod
    def foam():
        """
        Assemble a polygon of coordinates for the rectangle.
        The points are arranged clockwise from the topleft corner.

        Return: tuple
            of x, y series
        """
        w, h = Mold.x + Mold.w, Mold.y + Mold.h

        # four vertices
        return [Mold.x, Mold.y, w, Mold.y, Mold.x, h, w, h]

    @staticmethod
    def get_rect():
        """
        Arrange its attributes in a rectangle order.

        Return: tuple
            (x, y, w, h)
        """
        return Mold.x, Mold.y, Mold.w, Mold.h

    @staticmethod
    def get_size():
        return Mold.w, Mold.h

    @staticmethod
    def set_pos(*q):
        """
        q: tuple
            x, y
        """
        Mold.x, Mold.y = map(float, q)

    @staticmethod
    def set_rect(*q):
        """
        Set the rectangle attributes.

        q: tuple
            (x, y, w, h)
            of numeric
        """
        Mold.x, Mold.y, Mold.w, Mold.h = map(float, q)


class Pocket:
    """Contain the final Image pocket rectangle during a run."""
    x = y = w = h = .0

    @staticmethod
    def center():
        """
        Calculate the center point for the rectangle.

        Return: tuple
            (x, y)
            center point
        """
        return Pocket.x + (Pocket.w / 2.), Pocket.y + (Pocket.h / 2.)

    @staticmethod
    def get_rect():
        """
        Arrange its attributes in a rectangle order.

        Return: tuple
            (x, y, w, h)
        """
        return Pocket.x, Pocket.y, Pocket.w, Pocket.h

    @staticmethod
    def set_rect(*q):
        """
        Set the rectangle attributes.

        q: tuple
            (x, y, w, h)
            of numeric
        """
        Pocket.x, Pocket.y, Pocket.w, Pocket.h = map(float, q)


class Source:
    """Contain the Image source rectangle during a run."""
    x = y = w = h = .0

    @staticmethod
    def get_rect():
        """
        Arrange its attributes in a rectangle order.

        Return: tuple
            (x, y, w, h)
        """
        return Source.x, Source.y, Source.w, Source.h

    @staticmethod
    def set_rect(*q):
        """
        Set the rectangle attributes.

        q: tuple
            (x, y, w, h)
            of numeric
        """
        Source.x, Source.y, Source.w, Source.h = map(float, q)
