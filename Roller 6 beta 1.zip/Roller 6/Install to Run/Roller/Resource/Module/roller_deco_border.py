#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD, CHANNEL_OP_SUBTRACT, pdb
)
from roller_a_contain import Deco, Run
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    add_group_type,
    make_deco_material,
    prep_below_type,
    produce_main_facing,
    produce_per_facing,
    ready_canvas_rect,
    ready_shape,
    test_image,
    transform_foam
)
from roller_fu import (
    clear_inverse_selection,
    load_selection,
    select_polygon,
    select_rect,
    shrink_selection,
    verify_layer_group
)
from roller_view_hub import do_mod


def do(maya, make):
    """
    Process the Border matter. If Plan is active,
    temporarily override Preset option with Plan setting.

    maya: Maya
    make: function
        Call to make Border material.

    Return: layer or None
        with Border material
    """
    d = maya.value_d

    if not Run.x:
        # Preserve.
        type_ = d[ok.TYPE]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = {
            ny.CELL: fy.CELL_BORDER_COLOR,
            ny.CANVAS: fy.CANVAS_BORDER_COLOR,
            ny.FACE: fy.FACE_BORDER_COLOR,
            ny.FACING: fy.FACE_BORDER_COLOR
        }[maya.any_group.render_key[-2]]

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.x:
        # Restore.
        d[ok.TYPE] = type_
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Make Canvas Border.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_canvas)


def do_cell(maya):
    """
    Draw cell material.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell)


def do_face(maya):
    """
    Draw Face Border material for a cell.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell_face)


def do_facing(maya):
    """
    Draw Facing Border material for a cell.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell_facing)


def do_main_cell(maya):
    """
    Draw cell material for the main option settings.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main)


def do_main_face(maya):
    """
    Draw Face material for its main option settings.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main_face)


def do_main_facing(maya):
    """
    Draw Facing material for its main option settings.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main_facing)


def make_canvas(maya, d):
    """
    Draw Canvas Border material.

    maya: Maya
    d: dict
        Border Preset

    Return: layer or None
        with Border material
    """
    if test_image(maya, d):
        prep_below_type(d, maya.group)
        ready_canvas_rect(maya, d, option=None)

        j = Run.j
        x, y, w, h = maya.rect
        border_w = d[ok.BORDER_W]
        w1 = border_w * 2.

        select_rect(j, *maya.rect)

        # Cut out an interior rectangle.
        select_rect(
            j,
            x + border_w, y + border_w,
            max(1., w - w1), max(1., h - w1),
            option=CHANNEL_OP_SUBTRACT
        )
        return make_deco_material(maya, d, maya.group)


def make_cell_face(maya, d):
    """
    Make Face Border material for one cell.

    maya: Maya
    d: dict
        Border Preset

    Return: layer or None
        with material
    """
    return produce_per_facing(maya, d, make_face)


def make_cell_facing(maya, d):
    """
    Make Facing Border material for one cell.

    maya: Maya
    d: dict
        Border Preset

    Return: layer or None
        with material
    """
    return produce_per_facing(maya, d, make_facing)


def make_cell(maya, d):
    """
    Make Border material for a cell.

    maya: Maya
    d: dict
        Border Preset

    Return: layer or None
        with material
    """
    if test_image(maya, d):
        prep_below_type(d, maya.group)
        ready_shape(maya, d)
        select_border(d)
        return make_deco_material(maya, d, maya.group)


def make_face(maya, d, group):
    """
    Process Face Border for a cell.

    maya: Maya
    d: dict
        Border Preset

    group: layer
        Is the parent of Face output.
    """
    j = Run.j
    model = maya.model
    k = maya.k
    go = test_image(maya, d)
    if go:
        maya.rect = model.get_facing_rect(k)
        Deco.shape = model.get_facing_form(k)

        select_rect(j, *maya.rect)
        select_border(d)

        z = make_deco_material(maya, d, group)
        if z:
            transform_foam(maya.rect, z, model.get_facing_foam(k))


def make_facing(maya, d, group):
    """
    Process Facing Border for a cell.

    maya: Maya
    d: dict
        Border Preset

    group: layer
        Is the parent of Face output.
    """
    j = Run.j
    model = maya.model
    k = maya.k
    is_color = False
    go = test_image(maya, d)
    if go:
        if d[ok.TYPE] in (dc.MEAN_COLOR, dc.COLOR):
            is_color = True

        maya.rect = model.get_facing_rect(k)
        shape = model.get_facing_shape(k)

        if is_color:
            Deco.shape = shape
            select_polygon(j, Deco.shape)
            select_border(d)

        else:
            Deco.shape = model.get_facing_form(k)
            select_rect(j, *maya.rect)

        z = make_deco_material(maya, d, group)
        if z and not is_color:
            z = transform_foam(maya.rect, z, model.get_facing_foam(k))

            model.clip_facing(z, k)
            select_polygon(j, shape)
            select_border(d)
            clear_inverse_selection(z)


def make_main(maya, d):
    """
    Make Border material for the main option settings.
    Multiple Cell Border is combined into one layer.

    maya: Maya
    d: dict
        Border Preset

    Return: layer or None
        with material
    """
    def _do_many_material():
        """
        The cells have the same Border type, but
        the material is applied cell-by-cell.
        """
        _group = add_group_type(maya, d)

        for _k in maya.main_q:
            maya.k = _k
            if test_image(maya, d):
                ready_shape(maya, d)
                select_border(d)
                make_deco_material(maya, d, _group)
        return verify_layer_group(_group)

    def _do_one_material():
        """
        The cells have the same Border material,
        so there selection is combined.
        """
        _sel = None

        prep_below_type(d, maya.group)
        pdb.gimp_selection_none(j)

        for _k in maya.main_q:
            maya.k = _k

            ready_shape(maya, d)
            select_border(d)

            if _sel:
                load_selection(j, _sel, option=CHANNEL_OP_ADD)
                pdb.gimp_image_remove_channel(j, _sel)
            _sel = pdb.gimp_selection_save(j)

        if _sel:
            pdb.gimp_image_remove_channel(j, _sel)
        return make_deco_material(maya, d, maya.group)

    j = Run.j
    n = d[ok.TYPE]

    if n not in dc.PER_TYPE:
        # All the Border is the same
        # material and is applied one time.
        return _do_one_material()
    else:
        # All the Border is the same material
        # and is applied cell-by-cell.
        return _do_many_material()


def make_main_face(maya, d):
    """
    Each Face in the grid uses the main option settings.
    The output is a single layer.

    maya: Maya
    d: dict
        Border Preset

    Return: layer or None
        with material
    """
    return produce_main_facing(maya, d, make_face)


def make_main_facing(maya, d):
    """
    Each Face in the grid uses the main option settings.
    The output is a single layer.

    maya: Maya
    d: dict
        Border Preset

    Return: layer or None
        with material
    """
    return produce_main_facing(maya, d, make_facing)


def select_border(d):
    """
    Make a Border selection for a cell. Requires a selection at start.

    d: dict
        Border Preset

    Return: state of selection
    """
    j = Run.j
    sel = pdb.gimp_selection_save(j)

    shrink_selection(j, d[ok.BORDER_W])
    if not pdb.gimp_selection_is_empty(j):
        # inner polygon cut-out selection, 'inner_cut'
        inner_cut = pdb.gimp_selection_save(j)

        load_selection(j, sel)
        load_selection(j, inner_cut, option=CHANNEL_OP_SUBTRACT)
        pdb.gimp_image_remove_channel(j, sel)
        pdb.gimp_image_remove_channel(j, inner_cut)
