#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import atan2, cos, sin
from roller_a_contain import Mold
from roller_constant_for import Shape as sh, Signal as si
from roller_constant_key import Model as md, Option as ok
from roller_fu import clear_inverse_selection, select_rect
from roller_model_facing import Facing
from roller_model_goo import Goo, Map
from roller_model_grid import Grid
from roller_one_wip import Wip
from roller_polygon import (
    calc_length, calc_rotated_point, make_coord_list, shift_center
)

# Arrange form points into foam order.
V_FORM_Q = (6, 0, 4, 2), (2, 4, 0, 6)
H_FORM_Q = (0, 2, 6, 4), (4, 6, 2, 0)


def calc_fill_rect(rect, is_right=False, is_bottom=False):
    """
    Calculate the scale of a cell rectangle that is to be rotated as a cover.
    The rotated rectangle is later clipped creating a fill for the Facing.
    Center the over-sized rectangle with Shift rectangle.

    rect: tuple
        (x, y, w, h)
        Is the Shift rectangle that is rotated.

    is_right, is_bottom: bool
        If True, then try to keep the fill rectangle within the Wip.

    Return: tuple
        ((polygon array), (rectangle definition,))
        The radius is the minimum span of the scaled cell rectangle.
    """
    x, y, w, h = rect
    diagonal = calc_length(x, y, x + w, y + h)

    # grow factor, 'f'
    f = diagonal / min(w, h)
    w1, h1 = w * f, h * f

    x1 = x + w1
    y1 = y + h1

    if is_right:
        # Try to keep the fill rectangle 'x' within the bounds of Wip.
        x2 = Wip.w + Wip.x
        if x1 > x2:
            w2 = x1 - x2
            x -= w2
            x1 -= w2

    if is_bottom:
        # Try to keep the fill rectangle 'y' within the bounds of Wip.
        y2 = Wip.h + Wip.y
        if y1 > y2:
            h2 = y1 - y2
            y -= h2
            y1 -= h2
    return map(round, (x, y, x1, y, x1, y1, x, y1)), map(round, (x, y, w1, h1))


def calc_sidewalk_cell(model):
    """
    Calc cell rectangle and form.

    model: Sidewalk

    Return: dict
        {(row, column0): [Plan vote, Work vote]}
    """
    vote_d = {}
    did_cell = model.past.did_cell
    row, column = model.division
    goo_d = model.goo_d
    x, y, canvas_w, canvas_h = model.canvas_pocket.rect

    # [intersect coordinate, ...]
    q_x = make_coord_list(canvas_w, column, x)
    q_y = make_coord_list(canvas_h, row, y)

    for r_c in model.cell_q:
        r, c = r_c
        x, x1 = q_x[c], q_x[c + 1]
        y, y1 = q_y[r], q_y[r + 1]
        a = goo_d[r_c] = Goo(r_c)

        # Prevent round to zero with max 1.
        a.cell.rect = a.merged.rect = x, y, max(1., x1 - x), max(1., y1 - y)

        a.form = x, y, x1, y, x1, y1, x, y1
        vote_d[r_c] = did_cell(r_c)
    return vote_d


class Sidewalk(Grid, Facing):
    """
    Has a Canvas, Cell, and a Facing branch. Has two or
    more row and column arranged in a rectangular ring.
    """
    model_type = md.SIDEWALK

    def __init__(self, model_name):
        """
        model_name: string
            A key to identify the Model instance amongst other Models.
        """
        Grid.__init__(self, model_name)
        Facing.__init__(self)

        self.face_q = None
        self.cell_shape = sh.RECTANGLE
        self.baby.connect(si.CELL_MARGIN_CALC, self.update_sidewalk_facing)

    def calc_division(self, d):
        """
        Determine the row and column count of the cell grid.
        Call after Canvas pocket has been calculated.

        d: dict
            Cell Type Preset
            {Option key: value}
        """
        self.division = int(d[ok.ROW_COUNT]), int(d[ok.COLUMN_COUNT])
        self.baby.emit(si.DIVISION_CHANGE, self.division)

    def clip_facing(self, z, k):
        # Convert to (r, c, x) to (r, c).
        k = k[:2]

        select_rect(z.image, *self.goo_d[k].shift.rect)
        clear_inverse_selection(z)

    def init_cell_q(self, d):
        """
        Create a sorted list of valid cell index,
        'cell_q' -> [(row, column), ...].

        d: dict
            Cell Type Preset
            not used
        """
        row, column = self.division
        last_r = row - 1
        last_c = column - 1
        self.cell_q = []
        self.face_q = []
        for r in range(row):
            for c in range(column):
                if r == 0 or c == 0 or r == last_r or c == last_c:
                    self.cell_q += [(r, c)]
                    self.face_q += [(r, c, 0)]

    def init_model_cell(self, d):
        """
        Calculate cell, merged, and form value.

        d: dict
            Cell Type Preset
            {Option key: value}

        Return: list
            [Plan vote, Work vote]
            Each vote is a vote for change.
        """
        e = self.map_d = {}
        last_r, last_c = self.division[0] - 1, self.division[1] - 1
        e[(0, 0, 0)] = Topleft(d)
        e[(0, last_c, 0)] = TopRight(d)
        e[(last_r, 0, 0)] = BottomLeft(d)
        e[(last_r, last_c, 0)] = BottomRight(d)

        for i in range(1, last_r):
            e[(i, 0, 0)] = Left(d)
            e[(i, last_c, 0)] = Right(d)

        for i in range(1, last_c):
            e[(0, i, 0)] = Top(d)
            e[(last_r, i, 0)] = Bottom(d)

        self.goo_d = {}
        return calc_sidewalk_cell(self)

    def update_sidewalk_facing(self, *_):
        """Update Facing variables with Cell/Shift change."""
        for r_c in self.cell_q:
            # Map, 'a'
            a = self.map_d[r_c + (0,)]

            # Goo, 'b'
            b = self.goo_d[r_c]
            a.center_x, a.center_y = b.shift.center()
            a.update_facing(b)

    def update_type(self, arg):
        """
        Update Cell Type dependency.

        arg: tuple
            (Cell Type Preset, is sequence flag)
            {Option key: value}
            If the flag is True, then a chained-sequence
            of update processing is done immediately.
        """
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        vote_d = super(Sidewalk, self).update_type(arg)

        self.adapt_missing_cell_step(is_sequence)
        p(si.CELL_RECT_CALC, vote_d)


class Corner:

    def __init__(self):
        self.angle = .0

    def _rotate(self, q, radius):
        """
        Calculate rotated rectangle point.

        q: list
            [x, y, ...]
            Define a rectangle polygon.
            four points -> topleft, top-right, bottom-right, bottom-left

        radius: float
            Is the rectangle's half-diagonal.

        Return: list
            [x, y, ...]
            four points of float corresponding with the rectangle.
        """
        f = self.angle
        if f:
            # rotated point polygon, 'q1'
            q1 = []

            x, y = self.center_x, self.center_y

            for i in range(0, 8, 2):
                q1 += calc_rotated_point(
                    x, y, atan2(q[i + 1], q[i]) + f, radius
                )
            return q1
        return q

    def do_transform(self, maya):
        """
        Calculate the foam needed for a Mold rectangle to transform into foam.

        maya: Maya
            not used

        Return: list
            [x, y, ...]
            Are four x, y coordinates arranged in flag-order for
            the 'pdb.gimp_item_transform_perspective' function.
            Flag-order is topleft, top-right, bottom-left, bottom-right.
        """
        x, y, w, h = Mold.get_rect()
        x1, y1 = x + w, y + h
        radius = calc_length(x, y, x1, y1) / 2.
        foam_mold = shift_center(
            (x, y, x1, y, x1, y1, x, y1), *Mold.center()
        )

        # Calculate polygon point that is ready for selection.
        return self.pour_foam(self._rotate(foam_mold, radius))

    def pour_foam(self, q):
        """
        q: iterable
            form polygon

        Return: list
            [x, y, ...] in flag-order
            foam
        """
        # foam, 'q2'
        # [x, y, ...]
        q2 = []

        m = self.is_inward

        if self.is_reverse:
            m = not m

        q1 = (6, 4, 0, 2) if m else (2, 0, 4, 6)

        for x in q1:
            q2 += [q[x], q[x + 1]]
        return q2


class Side:
    """Factored from Left, Right, Top and Bottom."""

    def __init__(self, angle):
        self.angle = angle

    def _rotate(self, q, radius):
        """
        Calculate rotated rectangle point.

        q: list
            [x, y, ...]
            Define a rectangle polygon.
            four points -> topleft, top-right, bottom-right, bottom-left

        radius: float
            Is the rectangle's half-diagonal.

        Return: list
            [x, y, ...]
            four points of float corresponding with the rectangle.
        """
        # return q
        f = self.angle
        if f:
            # Shift rect center point, 'x, y'
            x, y = self.center_x, self.center_y

            # atan2 needs a zero center and cartesian coordinate.
            q = shift_center(q, *Mold.center())

            # rotated point polygon, 'q1'
            q1 = []

            # Calculate rotated NW and SE corner
            # points and reconstruct rectangle.
            for i in range(0, 8, 4):
                # the rotated angle in radians, 'f1'
                # atan2(y, x)
                x1 = q[i]
                y1 = q[i + 1]
                f1 = atan2(y1, x1)

                while f1 < .0:
                    # Add pi * 2 to make the angle
                    # positive so sin and cos work.
                    f1 += 6.283185

                f2 = f1 + f
                x2 = (cos(f2) * radius)
                y2 = (sin(f2) * radius)

                # Invert the 'y' coordinate back to screen mapping, '-'.
                q1 += [x2 + x, -y2 + y]

            # NE and SW points, 'x, y', 'x1, y1'
            x, y, x1, y1 = q1
            return [x, y, x, y1, x1, y1, x1, y]
        return q

    def do_transform(self, maya):
        """
        Calculate the foam needed for a Mold rectangle to transform into foam.

        maya: Maya
            not used

        Return: list
            [x, y, ...]
            Are four x, y coordinates arranged in flag-order for
            the 'pdb.gimp_item_transform_perspective' function.
            Flag-order is topleft, top-right, bottom-left, bottom-right.
        """
        x, y, w, h = Mold.get_rect()
        x1, y1 = x + w, y + h
        radius = calc_length(x, y, x1, y1) / 2.
        foam_mold = (x, y, x1, y, x1, y1, x, y1)

        # Calculate polygon point that is ready for selection.
        return self.pour_foam(
            self._rotate(foam_mold, radius), ((0, 2, 6, 4), (4, 6, 2, 0))
        )

    def pour_foam(self, q, q1):
        """
        q: iterable
            form polygon

        q1: tuple
            (point order, point order)
            The point order is reflects how the 'q' points are arranged.

        Return: list
            [x, y, ...] in flag-order
            foam
        """
        # foam, 'q2'
        # [x, y, ...]
        foam = []

        m = self.is_inward

        if self.is_reverse:
            # Right is reversed.
            m = not m

        q2 = q1[0] if m else q1[1]

        for x in q2:
            foam += [q[x], q[x + 1]]
        return foam


class Form(Map):

    def __init__(self, d):
        """
        d: dict
            Cell Type Preset
        """
        Map.__init__(self, d, self.do_transform)
        self.center_x = self.center_y = .0
        self.foam_form = None


class Bottom(Side, Form):
    """
    Define property for a bottom row cell that
    is not a corner in the Sidewalk grid.
    """
    is_reverse = True

    def __init__(self, d):
        """
        d: dict
            Cell Type Preset
        """
        Side.__init__(self, .0)
        Form.__init__(self, d)

    def update_facing(self, goo):
        self.merged.rect = goo.shift.rect
        self.form = self.shape = goo.plaque
        self.foam = self.pour_foam(self.form, H_FORM_Q)


class BottomLeft(Corner, Form):
    """Define property for the bottom-left corner cell in the Sidewalk grid."""
    is_reverse = True

    def __init__(self, d):
        """
        d: dict
            Cell Type Preset
        """
        Corner.__init__(self)
        Form.__init__(self, d)

    def update_facing(self, goo):
        """
        A Facing is dependent on the Shift
        rectangle, so respond to change in it.

        goo: Goo
        """
        self.form, self.merged.rect = calc_fill_rect(
            goo.shift.rect, is_bottom=True
        )
        self.shape = goo.plaque

        # 180 degrees, '3.14'
        self.angle = -atan2(goo.shift.h, goo.shift.w) + 3.141592653

        # Make point usable for atan2.
        self.foam_form = shift_center(self.form, *self.merged.center())

        x, y, w, h = self.merged.rect
        radius = calc_length(x, y, x + w, y + h) / 2.

        # Calculate polygon point that is ready for selection.
        self.foam = self.pour_foam(self._rotate(self.foam_form, radius))


class BottomRight(Corner, Form):
    """
    Define property for the bottom-right corner cell in the Sidewalk grid.
    """
    is_reverse = False

    def __init__(self, d):
        """
        d: dict
            Cell Type Preset
        """
        Corner.__init__(self)
        Form.__init__(self, d)

    def update_facing(self, goo):
        """
        A Facing is dependent on the Shift
        rectangle, so respond to change in it.

        goo: Goo
        """
        self.form, self.merged.rect = calc_fill_rect(
            goo.shift.rect, is_bottom=True, is_right=True
        )
        self.shape = goo.plaque

        # 180 degrees, '3.14'
        self.angle = atan2(goo.shift.h, goo.shift.w) + 3.141592653

        # Make point usable for atan2.
        self.foam_form = shift_center(self.form, *self.merged.center())

        x, y, w, h = self.merged.rect
        radius = calc_length(x, y, x + w, y + h) / 2.

        # Calculate polygon point that is ready for selection.
        self.foam = self.pour_foam(self._rotate(self.foam_form, radius))


class Left(Side, Form):
    """
    Define property for a left column cell that
    is not a corner in the Sidewalk grid.
    """
    is_reverse = False

    def __init__(self, d):
        """
        d: dict
            Cell Type Preset
        """
        # 90 degrees, '1.57'
        Side.__init__(self, 1.570796326)

        Form.__init__(self, d)

    def update_facing(self, goo):
        """
        A Facing is dependent on the Shift
        rectangle, so respond to change in it.

        goo: Goo
        """
        x, y, w, h = goo.shift.rect

        # The width and height exchange places as the cell is on its side.
        self.merged.rect = x, y, h, w

        self.form = self.shape = goo.plaque
        self.foam = self.pour_foam(self.form, V_FORM_Q)


class Right(Side, Form):
    """
    Define property for a right column cell that
    is not a corner in the Sidewalk grid.
    """
    is_reverse = True

    def __init__(self, d):
        """
        d: dict
            Cell Type Preset
        """
        # 90 degrees, '1.57' radian
        Side.__init__(self, 1.570796326)

        Form.__init__(self, d)

    def update_facing(self, goo):
        """
        A Facing is dependent on the Shift
        rectangle, so respond to change in it.

        goo: Goo
        """
        # The width and height exchange places as the cell is on its side.
        x, y, w, h = goo.shift.rect

        self.merged.rect = x, y, h, w
        self.form = self.shape = goo.plaque
        self.foam = self.pour_foam(self.form, V_FORM_Q)


class Top(Side, Form):
    """
    Define property for a top row cell that
    is not a corner in the Sidewalk grid.
    """
    is_reverse = False

    def __init__(self, d):
        """
        d: dict
            Cell Type Preset
        """
        Side.__init__(self, .0)
        Form.__init__(self, d)

    def update_facing(self, goo):
        """
        A Facing is dependent on the Shift
        rectangle, so respond to change in it.

        goo: Goo
        """
        self.merged.rect = goo.shift.rect
        self.form = self.shape = goo.plaque
        self.foam = self.pour_foam(self.form, H_FORM_Q)


class Topleft(Corner, Form):
    """Define property for the topleft corner cell in the Sidewalk grid."""
    is_reverse = False

    def __init__(self, d):
        """
        d: dict
            Cell Type Preset
        """
        Corner.__init__(self)
        Form.__init__(self, d)

    def update_facing(self, goo):
        """
        A Facing is dependent on the Shift
        rectangle, so respond to change in it.

        goo: Goo
        """
        self.form, self.merged.rect = calc_fill_rect(goo.shift.rect)
        self.shape = goo.plaque
        self.angle = atan2(goo.shift.h, goo.shift.w)

        # Make point usable for atan2.
        self.foam_form = shift_center(self.form, *self.merged.center())

        x, y, w, h = self.merged.rect
        radius = calc_length(x, y, x + w, y + h) / 2.

        # Calculate polygon point that is ready for selection.
        self.foam = self.pour_foam(self._rotate(self.foam_form, radius))


class TopRight(Corner, Form):
    """Define property for the top-right corner cell in the Sidewalk grid."""
    is_reverse = True

    def __init__(self, d):
        """
        d: dict
            Cell Type Preset
        """
        Corner.__init__(self)
        Form.__init__(self, d)

    def update_facing(self, goo):
        """
        A Facing is dependent on the Shift
        rectangle, so respond to change in it.

        goo: Goo
        """
        self.form, self.merged.rect = calc_fill_rect(
            goo.shift.rect, is_right=True
        )
        self.shape = goo.plaque
        self.angle = -atan2(goo.shift.h, goo.shift.w)

        # Make point usable for atan2.
        self.foam_form = shift_center(self.form, *self.merged.center())

        x, y, w, h = self.merged.rect
        radius = calc_length(x, y, x + w, y + h) / 2.

        # Calculate polygon point that is ready for selection.
        self.foam = self.pour_foam(self._rotate(self.foam_form, radius))
