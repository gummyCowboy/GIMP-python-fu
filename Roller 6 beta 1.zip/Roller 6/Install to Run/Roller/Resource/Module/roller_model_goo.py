#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_many_rect import Rect


class Goo(object):
    """Is a container for Cell property."""

    def __init__(self, k):
        """
        k: tuple
            cell index
        """
        # row and column cell index and key
        self.k = k

        # Rect
        # Is the original cell rectangle, before a merge cell.
        self.cell = Rect()

        # Is the plaque polygon before Cell Shift
        # and is inscribed inside the merged rectangle.
        self.form = None

        # Rect
        # Is the cell rectangle, except with the Table Model,
        # where it is the cell size a block of cell.
        self.merged = Rect()

        # tuple
        # Is the Cell polygon shape without margin
        # and is derived the Shift rectangle.
        self.plaque = None

        # Rect
        # Is the cell rectangle within margin.
        self.pocket = Rect()

        # tuple
        # Is the cell polygon shape that derived from
        # the Shift rectangle and Cell margin.
        self.shape = None

        # Rect
        # Is the merged rectangle after it has shifted.
        self.shift = Rect()


class Map:
    """Use with Facing to remember its cell-scope state."""

    def __init__(self, d, p):
        """
        Input is a deco type's source/target
        layer. Output is a Facing target layer.

        d: dict
            Cell Type Preset

        p: function
            Call to transform a rectangle into output suitable foam.
        """
        # function
        # Call to clip a rotated material.
        self.clip_p = None

        # tuple
        self.foam = None

        # function
        # Call to transform a rectangle into foam.
        self.foam_p = None

        # tuple
        # input polygon selection
        self.form = None

        # Rect
        # input rectangle selection
        self.merged = Rect()

        # tuple
        # output for a color fill
        self.shape = None

        # function
        # Call to shape a rectangle into output foam.
        self.transform = p

        self.is_inward = d.get(ok.INWARD)


class Mesh(Goo):
    """Use with the Box Model for Face attribute."""

    def __init__(self, k):
        Goo.__init__(self, k)

        # Define the face transform output with four points
        # (topleft, top-right, bottom-left, bottom-right).
        self.foam = ()

        # function
        # Call to transform a Face's mold rectangle into foam.
        self.transform = None
