#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_fu import remove_z, select_rect
from roller_maya_style import Style
from roller_one_wip import Wip
from roller_view_hub import color_selection_default, do_mod, get_mean_color
from roller_view_real import add_wip_base, clone_background, finish_style


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: MeanColor
    Return: layer or None
        style layer
    """
    # Is dependent.
    if maya.go:
        d = maya.value_d
        z = add_wip_base("Mean Color", maya.group)
        e = get_default_value(by.COLOR_FILL)

        e.update(d)

        z1 = clone_background(z)

        select_rect(Run.j, *Wip.get_rect())

        # RGB, 'q'
        q = get_mean_color(z1)

        remove_z(z1)
        color_selection_default(z, q)
        do_mod(z, d[ok.BRW][ok.MOD])
        return finish_style(z, "Mean Color")


class MeanColor(Style):
    """Create Backdrop Style output."""
    is_dependent = True

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.BRW, ok.MOD)],
            make_style
        )
