#!/usr/bin/env python
# -*- coding: utf-8 -
from gimpfu import CLIP_TO_IMAGE, LAYER_MODE_SOFTLIGHT, pdb      # type: ignore
from roller_a_contain import Globe, Run
from roller_a_gegl import cubism, edge
from roller_constant_key import Option as ok
from roller_fu import clone_layer, merge_layer_group
from roller_maya_style import Style, make_background
from roller_view_hub import do_mod
from roller_view_real import add_sub_base_group, finish_style


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: Style
    Return: layer or None
        with Cubism Cover
    """
    # Is dependent.
    if maya.go:
        j = Run.j
        d = maya.value_d
        parent = add_sub_base_group(maya)
        z = make_background(parent)

        cubism(
            z,
            size=d[ok.TILE_SIZE],
            amount=5.,
            seed=int(Globe.seed)
        )

        z1 = clone_layer(z, n="Soft light")
        z1.mode = z.mode = LAYER_MODE_SOFTLIGHT

        edge(z1)
        pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
        pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

        z = merge_layer_group(parent)

        do_mod(z, d[ok.BRW][ok.MOD])
        return finish_style(z, "Cubism Cover")


class CubismCover(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
