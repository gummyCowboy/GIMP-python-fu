#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_for import Issue as vo, Signal as si
from roller_constant_key import (
    Node as ny, Option as ok, Plan as ak, SubMaya as sm
)
from roller_deco_margin import (
    make_main, make_cell, make_canvas
)
from roller_maya import CanvasRoute, CellRoute, Runner
from roller_maya_plan_detail import (
    Detail,
    PlanMargin,
    PlanShape,
    draw_main_corner,
    draw_main_dimension,
    draw_main_position,
    draw_main_ratio,
    draw_main_shape,
    draw_per_position,
    draw_per_corner,
    draw_per_dimension,
    draw_per_ratio,
    draw_per_shape
)
from roller_option_group import ModelGroup
from roller_view_real import make_canvas_group, make_cast_group
from roller_view_step import find_canvas_shift, find_cell_shift


class Margin(ModelGroup):
    """
    Create Widget group. Assign a View processor
    and connect responsible signal handler.
    """

    def __init__(self, **d):
        ModelGroup.__init__(self, **d)

        node_k = self.nav_k[-2]
        self.plan = {ny.CANVAS: PlanCanvas, ny.CELL: PlanCell}[node_k](self)
        self.work = {ny.CANVAS: WorkCanvas, ny.CELL: WorkCell}[node_k](self)
        baby = self.item.model.baby
        self._is_cell = False

        if node_k == ny.CELL:
            self._is_cell = True
            self._sequence_signal = si.CELL_MARGIN_CHANGE
            self.latch(baby, (si.CELL_SHIFT_CALC, self.on_cell_calc))
            self.latch(
                self.widget_d[ok.PER], (si.PER_CHANGE, self.update_model)
            )

        elif node_k == ny.CANVAS:
            # Respond to Model's Canvas change.
            self.latch(baby, (si.CANVAS_RECT_CALC, self.on_sequence_change))
            self._sequence_signal = si.CANVAS_MARGIN_CHANGE

        self.latch(self.booth, (si.VOTE_CHANGE, self.update_model))
        self.latch(self, (si.SEQUENCE, self.on_sequence))

    def do(self):
        """
        Override the AnyGroup function so that Past's View Signal can be sent.
        """
        super(Margin, self).do()

        p = self.item.model.past.emit

        if self._is_cell:
            p(si.CELL_MARGIN_VIEW, Run.x)

            # Adapt to a missing Shift step.
            if not find_cell_shift(self.nav_k):
                p(si.CELL_SHIFT_VIEW, Run.x)
        else:
            p(si.CANVAS_MARGIN_VIEW, Run.x)

            # Adapt to a missing Shift step.
            if not find_canvas_shift(self.nav_k):
                p(si.CANVAS_SHIFT_VIEW, Run.x)

    def on_sequence(self, _, arg):
        """
        Update the Model pronto.

        _: AnyGroup
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
            not  used
        """
        self.item.model.baby.feed(self._sequence_signal, (self.value_d, True))

    def update_model(self, *_):
        """Respond to change in the Margin AnyGroup."""
        self.item.model.baby.give(self._sequence_signal, (self.value_d, False))


class Chi(Runner):
    """Factor Plan and Work."""
    issue_q = 'matter',

    def __init__(self, any_group, view_x, put):
        Runner.__init__(self, any_group, view_x, put, ())
        self.set_issue()

    def prep(self):
        """
        For every View, there is an Image, but not for Margin.
        """
        return


class Plan(Chi):
    """Manage Margin Plan layer output."""
    put = (make_cast_group, 'group'),

    def __init__(self, any_group):
        """Canvas and Cell Plan."""
        Chi.__init__(self, any_group, 0, self.put)


class Work(Chi):
    """Doesn't have layer output. Is a template for View/Work."""

    def __init__(self, any_group):
        """
        Canvas and Cell Work.

        q: iterable
            output function
        """
        Chi.__init__(self, any_group, 1, ())

    def dig(self):
        return


# Canvas_______________________________________________________________________
class PlanCanvas(Plan, CanvasRoute):
    """Manage Canvas/Margin Plan layer output."""
    put = (make_canvas_group, 'group'),
    vote_type = vo.MAIN

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        self.do_matter = make_canvas

        Plan.__init__(self, any_group)
        CanvasRoute.__init__(self)
        self.sub_maya[sm.MARGIN] = PlanMargin(
            any_group, self, make_canvas
        )

    def bore(self):
        """Manage layer output during a View run."""
        self.realize()
        self.sub_maya[sm.MARGIN].do()


class WorkCanvas(Work):
    """Doesn't have layer output. Is a template for the View/Work step."""
    vote_type = vo.MAIN

    def __init__(self, any_group):
        """
        Determine change of Canvas Margin.

        _: AnyGroup
        """
        Work.__init__(self, any_group)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class PlanSub(Plan):
    """Factor from PlanCell and PlanPerCell."""

    def __init__(self, any_group, do_matter, sub_d):
        # Force the Per Cell 'do' call in CellRoute.
        self.is_per = True

        Plan.__init__(self, any_group)

        self.sub_maya[sm.MARGIN] = PlanMargin(any_group, self, do_matter)
        self.sub_maya[sm.POSITION] = Detail(
            any_group, self, sub_d[ak.POSITION], ak.POSITION
        )
        self.sub_maya[sm.CORNER] = Detail(
            any_group, self, sub_d[ak.CORNER], ak.CORNER
        )
        self.sub_maya[sm.DIMENSION] = Detail(
            any_group, self, sub_d[ak.DIMENSION], ak.DIMENSION
        )
        self.sub_maya[sm.RATIO] = Detail(
            any_group, self, sub_d[ak.RATIO], ak.RATIO
        )
        self.sub_maya[sm.CELL_SHAPE] = PlanShape(
            any_group, self, sub_d[ak.CELL_SHAPE]
        )

    def bore(self):
        """Manage layer output during a View run."""
        self.realize()
        self.sub_maya[sm.MARGIN].do()
        self.sub_maya[sm.POSITION].do()
        self.sub_maya[sm.CORNER].do()
        self.sub_maya[sm.DIMENSION].do()
        self.sub_maya[sm.RATIO].do()
        self.sub_maya[sm.CELL_SHAPE].do()


class PlanCell(PlanSub, CellRoute):
    """Manage Cell/Margin Plan layer output."""
    vote_type = vo.MAIN

    def __init__(self, any_group):
        PlanSub.__init__(
            self,
            any_group,
            make_main,
            {
                ak.CORNER: draw_main_corner,
                ak.DIMENSION: draw_main_dimension,
                ak.POSITION: draw_main_position,
                ak.RATIO: draw_main_ratio,
                ak.CELL_SHAPE: draw_main_shape
            }
        )
        CellRoute.__init__(self, PlanCellPer)


class WorkCell(Work):
    """Doesn't have layer output. Is a template for the View/Work step."""
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Work.__init__(self, any_group)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell/Per_____________________________________________________________________
class PlanCellPer(PlanSub):
    """Manage Cell/Margin/Per Cell Plan layer output."""
    vote_type = vo.PER

    def __init__(self, any_group, k):
        """
        Create a Maya for Per Cell.

        k: tuple
            (r, c); cell index; of int
        """
        PlanSub.__init__(
            self,
            any_group,
            make_cell,
            {
                ak.POSITION: draw_per_position,
                ak.CORNER: draw_per_corner,
                ak.DIMENSION: draw_per_dimension,
                ak.RATIO: draw_per_ratio,
                ak.CELL_SHAPE: draw_per_shape
            }
        )
        self.k = k
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
