#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_a_contain import Run
from roller_constant_for import Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import ready_canvas_rect, ready_shape
from roller_fu import select_shape, verify_layer
from roller_fu_comm import show_err
from roller_view_hub import do_mod, set_gimp_brush
from roller_view_real import add_wip_layer, get_light


def add_line_layer(maya):
    """
    Add a layer named after "Material" to the base of the Maya's group.

    maya: Maya
    Return: layer
        newly added
    """
    return add_wip_layer("Material", maya.group, offset=get_light(maya))


def do(maya, make):
    """
    Create Line for a navigation branch.

    maya: Maya
    Return: layer or None
        with material
    """
    # Line Preset, 'd'
    d = maya.value_d

    if not Run.x:
        # Preserve.
        mode = d[ok.MODE]
        color = d[ok.RW1][ok.COLOR_1]

        # Plan override.
        d[ok.MODE] = "Normal"
        d[ok.RW1][ok.COLOR_1] = {
            ny.CANVAS: fy.CANVAS_LINE_COLOR,
            ny.CELL: fy.CELL_LINE_COLOR,
            ny.FACE: fy.FACE_LINE_COLOR,
            ny.FACING: fy.FACE_LINE_COLOR
        }[maya.any_group.render_key[-2]]

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.x:
        # Restore.
        d[ok.MODE] = mode
        d[ok.RW1][ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_face(maya):
    """
    Draw Face/Per Line.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell_face)


def do_canvas(maya):
    """
    Draw Canvas branch Line.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_canvas)


def do_cell(maya):
    """
    Draw Line for Cell/Per.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell)


def do_main_cell(maya):
    """
    Draw Cell/Per Line.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main)


def do_main_face(maya):
    """
    Draw Face/Per Line.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main_face)


def make_canvas(maya, d):
    """
    Draw Canvas Line material.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        with Line material
    """
    j = Run.j
    z = add_line_layer(maya)

    ready_canvas_rect(maya, d)

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)
    return verify_layer(z)


def make_cell(maya, d):
    """
    Make Line for a Per cell.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        with material
    """
    j = Run.j
    z = add_line_layer(maya)

    ready_shape(maya, d)

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)
    return verify_layer(z)


def make_cell_face(maya, d):
    """
    Make Line for Face/Per.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        with material
    """
    j = Run.j
    z = add_line_layer(maya)

    select_shape(j, maya.model.get_facing_shape(maya.k))

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)
    return verify_layer(z)


def make_main(maya, d):
    """
    Create Line for the Cell branch main option settings.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        Line output
    """
    j = Run.j
    z = add_line_layer(maya)

    prep_line(d)

    # cell key, 'k'
    for k in maya.main_q:
        maya.k = k
        ready_shape(maya, d)
        if not pdb.gimp_selection_is_empty(j):
            pdb.gimp_drawable_edit_stroke_selection(z)
    return verify_layer(z)


def make_main_face(maya, d):
    """
    Make Line for Face/Per.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        with material
    """
    j = Run.j
    z = add_line_layer(maya)

    prep_line(d)

    for k in maya.main_q:
        select_shape(j, maya.model.get_facing_shape(k))
        if not pdb.gimp_selection_is_empty(j):
            # Can throw an error if the image size is too small.
            try:
                pdb.gimp_drawable_edit_stroke_selection(z)
            except Exception as ex:
                show_err(ex)
    return verify_layer(z)


def prep_line(d):
    """
    Prepare to draw line.

    d: dict
        Line Preset
    """
    set_gimp_brush(d[ok.RW1][ok.BRUSH])
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_context_set_brush_angle(.0)
    pdb.gimp_context_set_brush_hardness(d[ok.HARDNESS])
    pdb.gimp_context_set_brush_size(d[ok.LINE_W])
    pdb.gimp_context_set_foreground(d[ok.RW1][ok.COLOR_1])
    pdb.gimp_context_set_opacity(100.)
