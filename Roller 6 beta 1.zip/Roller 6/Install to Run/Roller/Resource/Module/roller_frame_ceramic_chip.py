#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import uniform, randint, seed
from roller_a_contain import Globe, Run
from roller_a_gegl import waterpixels
from roller_constant_for import Frame as ff
from roller_constant_key import Frame as ek, Material as ma, Option as ok
from roller_frame_alt import AltWrapFiller
from roller_frame import do_alt_frame
from roller_fu import blur_selection
from roller_view_real import add_wip_layer, get_light
import gimpfu as fu  # type: ignore

COLOR_BALANCE = (
    (-100., 100., 100.),
    (-100., -100., 100.),
    (-100., 100., -100.),
    (100., -100., -100.),
    (100., -100., 100.),
    (100., 100., -100.)
)
pdb = fu.pdb


def do_matter(maya):
    """
    Make a frame.

    maya: CeramicChip
    Return: layer
        with the frame
    """
    return do_alt_frame(maya)


def do_filler(maya):
    """
    Draw filler material.

    maya: AltFiller
    Return: layer
        Has ceramic chip.
    """
    j = Run.j
    d = maya.value_d
    seed_ = int(Globe.seed + d[ok.SEED])
    z = add_wip_layer("Ceramic Chip", maya.group, offset=get_light(maya))

    pdb.gimp_selection_none(j)
    seed(seed_)

    # random turbulence
    pdb.plug_in_plasma(j, z, seed_, uniform(1., 7.))

    # mid-tones, '1'; yes, preserve luminosity,  '1'
    pdb.gimp_color_balance(z, 1, 1, *COLOR_BALANCE[randint(0, 5)])

    waterpixels(z, size=min(256, int(d[ok.MESH_SIZE])))
    pdb.gimp_selection_all(j)
    pdb.plug_in_mosaic(
        j, z,
        d[ok.MESH_SIZE],
        1.,                                     # tile height
        .1,                                     # minimum spacing
        .5,                                     # medium neatness
        0,                                      # no split
        Globe.azimuth,
        .0,                                     # minimum color variation
        1,                                      # yes, antialias
        1,                                      # yes, average color
        ff.MESH_TYPE.index(d[ok.MESH_TYPE]),
        0,                                      # smooth surface
        0                                       # black and white grout
    )
    blur_selection(z, 1.5)
    return z


class CeramicChip(AltWrapFiller):
    """Create a frame with ceramic-like pieces."""
    filler_k = ok.FILLER_CC
    kind = ek.CERAMIC_CHIP
    material = ma.CERAMIC_CHIP
    shade_row = ok.BRW
    wrap_k = ok.WRAP_ALT

    def __init__(self, any_group, super_maya, k_path):
        AltWrapFiller.__init__(
            self, any_group, super_maya, k_path, do_matter, do_filler
        )
