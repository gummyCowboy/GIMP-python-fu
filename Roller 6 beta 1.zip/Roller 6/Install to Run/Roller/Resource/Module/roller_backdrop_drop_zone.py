#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb      # type: ignore
from roller_a_contain import Cat, Run, The
from roller_a_gegl import median_blur
from roller_constant_for import Shape as sh, Triangle as ft
from roller_constant_key import Option as ok
from roller_fu import clear_selection, select_shape, select_rect
from roller_many_rect import Rect
from roller_maya_style import Style
from roller_one import enumerate_name
from roller_one_wip import Wip
from roller_polygon import (
    calc_circumradius,
    calc_hexagon,
    calc_hexagon_truncated,
    calc_octagon,
    calc_octagon_on_its_side,
    calc_square_mitered,
    calc_triangle_down_regular,
    calc_triangle_left_regular,
    calc_triangle_right_regular,
    calc_triangle_up_regular
)
from roller_view_hub import (
    calc_gradient, color_selection, do_mod, set_fill_context_default
)
from roller_view_real import add_wip_base, finish_style


def make_style(maya):
    """
    Draw shrinking polygons.

    maya: Style
    Return: layer or None
        with Drop Zone material
    """
    j = Run.j
    d = maya.value_d

    # Is a gradient that is created by the user, 'grad'.
    grad = None

    set_fill_context_default()

    x, y, w, h = Wip.get_rect()
    steps = d[ok.STEPS]
    color, color1 = d[ok.COLOR_2A]
    mod_w = w / steps / 2.
    mod_h = h / steps / 2.

    # RGBA of int, 'stair'
    # Is added to the start color once per iteration.
    stair = calc_gradient(color, color1, steps)

    is_keep = d[ok.KEEP]

    if is_keep:
        # Make a unique gradient name.
        gradients = Cat.gradient_list

        # gradient name, 'n'
        n = d[ok.NAME]

        if not n:
            n = "Drop Zone"

        if n in gradients:
            n = enumerate_name(n, gradients)

        # Create a gradient with evenly spaced
        # segments, one for each color.
        grad = pdb.gimp_gradient_new(n)

        # start segment, '0'; end segment, '0'
        pdb.gimp_gradient_segment_range_split_uniform(grad, 0, 0, int(steps))

    start_color = color[:]
    z = add_wip_base("Drop Zone WIP", maya.group)
    shape = d[ok.SHAPE]

    for step in range(int(steps)):
        # Set the 'color_selection' function's input to
        # the correct format (a tuple).
        # tuple of RGBA ordered integer, 'q'
        q = tuple([int(i) for i in color])

        if is_keep:
            # arg, (gradient, segment index, color, opacity)
            # The opacity value has to be rounded
            # as it will overflow with float-sum (e.g. 100.00000007).
            arg = grad, step, q[:3], round(q[3] / 255. * 100., 1)

            # The start and end color is the same for a segment.
            pdb.gimp_gradient_segment_set_left_color(*arg)
            pdb.gimp_gradient_segment_set_right_color(*arg)

        if w >= 1. and h >= 1.:
            pdb.gimp_selection_none(j)
            ROUTE_SELECT[shape](j, x, y, w, h)
            clear_selection(z, keep_sel=True)
            color_selection(z, q)

        # Define the next rectangle.
        x += mod_w
        y += mod_h
        w -= (mod_w * 2.)
        h -= (mod_h * 2.)

        color = ()
        for i in range(4):
            b = stair[i] * (step + 1)
            color += (start_color[i] + int(b),)

    # Create a gradient if the user desires.
    if grad and is_keep:
        # Store image gradients so they can
        # be deleted before the program closes.
        The.image_gradient_created.append(grad)

        # This gradient is kept and is
        # saved to a file when GIMP closes.
        The.image_gradient_used = grad

    pdb.gimp_selection_none(j)
    median_blur(z, 2., 50.)
    do_mod(z, d[ok.BRW][ok.MOD])
    return finish_style(z, "Drop Zone")


def select_circle(j, x, y, w, h):
    """
    Select a circle given an inscribed rectangle.

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: state of selection
    """
    radius = calc_circumradius(w, h)
    w1 = radius * 2.
    x1 = x - (w1 - w) / 2.
    y1 = y - (w1 - h) / 2.
    select_shape(j, (x1, y1, w1, w1))


def select_ellipse(j, x, y, w, h):
    """
    Select an ellipse given an inscribed rectangle.

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: state of selection
    """
    # square-root of 2, '1.41'
    w1, h1 = w * 1.41421356, h * 1.41421356

    x1 = x - (w1 - w) / 2.
    y1 = y - (h1 - h) / 2.
    select_shape(j, (x1, y1, w1, h1))


def select_hexagon(j, x, y, w, h):
    """
    Select a hexagon that is circumscribing a rectangle.

    Reference
    calcresource.com/geom-hexagon.html

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: state of selection
    """
    inscribe_radius = calc_circumradius(w, h)
    circum_radius = inscribe_radius * ft.SCALE_UP
    w1 = inscribe_radius * 2.
    h1 = circum_radius * 2.
    x1 = x - (w1 - w) / 2.
    y1 = y - (h1 - h) / 2.

    # Make selection.
    select_shape(j, calc_hexagon(Rect(x1, y1, w1, h1)))


def select_hexagon_truncated(j, x, y, w, h):
    """
    Select a truncated hexagon that is circumscribing a rectangle.

    Reference
    calcresource.com/geom-hexagon.html

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: state of selection
    """
    inscribe_radius = calc_circumradius(w, h)
    circum_radius = inscribe_radius * ft.SCALE_UP
    w1 = circum_radius * 2.
    h1 = inscribe_radius * 2.
    x1 = x - (w1 - w) / 2.
    y1 = y - (h1 - h) / 2.

    # Make selection.
    select_shape(j, calc_hexagon_truncated(Rect(x1, y1, w1, h1)))


def select_octagon(j, x, y, w, h):
    """
    Select an octagon that is circumscribing a rectangle.

    Reference
    calcresource.com/geom-octagon.html

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: state of selection
    """
    w2 = (calc_circumradius(w, h) / sh.OCTAGON_CIRCUMRADIUS_RATIO) * 2.
    x -= (w2 - w) / 2.
    y -= (w2 - h) / 2.
    select_shape(j, calc_octagon(Rect(x, y, w2, w2)))


def select_octagon_on_its_side(j, x, y, w, h):
    """
    Select an octagon on its side that is circumscribing a rectangle.

    Reference
    calcresource.com/geom-octagon.html

    q: tuple
        x, y: float
        rectangle position

        w, h: float
        rectangle size

    Return: state of selection
    """
    w2 = (calc_circumradius(w, h) / sh.OCTAGON_CIRCUMRADIUS_RATIO) * 2.
    x -= (w2 - w) / 2.
    y -= (w2 - h) / 2.
    select_shape(j, calc_octagon_on_its_side(Rect(x, y, w2, w2)))


def select_square(j, x, y, w, h):
    """
    Select a square that is circumscribing a rectangle.

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: state of selection
    """
    w1 = max(w, h)
    x -= (w1 - w) / 2.
    y -= (w1 - h) / 2.
    select_rect(j, x, y, w1, w1)


def select_square_mitered(j, x, y, w, h):
    """
    Select a square that has been rotated 45 degrees.

    Reference
    varsitytutors.com/hotmath/hotmath_help/topics/circles-inscribed-in-squares

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: state of selection
    """
    side = calc_circumradius(w, h) * 2.

    # square-root of 2, '1.41'
    diagonal = side * 1.41421356

    x -= (diagonal - w) / 2.
    y -= (diagonal - h) / 2.
    select_shape(j, calc_square_mitered(Rect(x, y, diagonal, diagonal)))


def select_triangle_down_equal(j, x, y, w, h):
    """
    Select an regular triangle that is facing down.
    The triangle is centered and inscribes the rectangle.

    Reference
    brilliant.org/wiki/properties-of-equilateral-triangles/

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: state of selection
    """
    h1 = h / 2.
    radius = calc_circumradius(w, h)

    # height of triangle, 'h2'
    # width of rectangle, 'w1'
    h2 = radius * 3.
    w1 = ft.SCALE_UP * h2
    x1 = x - (w1 - w) / 2.
    y1 = y - radius + h1
    q = calc_triangle_down_regular(Rect(x1, y1, w1, h2))

    # Make selection.
    select_shape(j, q)


def select_triangle_left_equal(j, x, y, w, h):
    """
    Select an regular triangle that is facing left.
    The triangle is centered and inscribes the rectangle.

    Reference
    brilliant.org/wiki/properties-of-equilateral-triangles/

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: state of selection
    """
    w1 = w / 2.
    radius = calc_circumradius(w, h)

    # width of triangle, 'w2'
    # height of rectangle, 'h1'
    w2 = radius * 3.
    h1 = ft.SCALE_UP * w2
    x1 = x - (radius * 2.) + w1
    y1 = y - (h1 - h) / 2.
    q = calc_triangle_left_regular(Rect(x1, y1, w2, h1))

    # Make selection.
    select_shape(j, q)


def select_triangle_right_equal(j, x, y, w, h):
    """
    Select an regular triangle that is facing right.
    The triangle is centered and inscribes the rectangle.

    Reference
    brilliant.org/wiki/properties-of-equilateral-triangles/

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: state of selection
    """
    w1 = w / 2.
    radius = calc_circumradius(w, h)

    # width of triangle, 'w2'
    # height of rectangle, 'h1'
    w2 = radius * 3.
    h1 = ft.SCALE_UP * w2
    x1 = x - radius + w1
    y1 = y - (h1 - h) / 2.
    q = calc_triangle_right_regular(Rect(x1, y1, w2, h1))

    # Make selection.
    select_shape(j, q)


def select_triangle_up_equal(j, x, y, w, h):
    """
    Select an regular triangle that is facing up.
    The triangle is centered and inscribes the rectangle.

    Reference
    brilliant.org/wiki/properties-of-equilateral-triangles/

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: state of selection
    """
    h1 = h / 2.
    radius = calc_circumradius(w, h)

    # height of triangle, 'h2'
    # width of rectangle, 'w1'
    h2 = radius * 3.
    w1 = ft.SCALE_UP * h2
    x1 = x - (w1 - w) / 2.
    y1 = y - (radius * 2.) + h1
    q = calc_triangle_up_regular(Rect(x1, y1, w1, h2))

    # Make selection.
    select_shape(j, q)


class DropZone(Style):
    """Create Backdrop Style output."""
    is_dependent = False

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.BRW, ok.MOD)],
            make_style
        )


ROUTE_SELECT = {
    sh.CIRCLE: select_circle,
    sh.ELLIPSE: select_ellipse,
    sh.HEXAGON: select_hexagon,
    sh.HEXAGON_TRUNCATED: select_hexagon_truncated,
    sh.OCTAGON: select_octagon,
    sh.OCTAGON_ON_ITS_SIDE: select_octagon_on_its_side,
    sh.SQUARE: select_square,
    sh.SQUARE_MITERED: select_square_mitered,
    ft.TRIANGLE_DOWN_REGULAR: select_triangle_down_equal,
    ft.TRIANGLE_LEFT_REGULAR: select_triangle_left_equal,
    ft.TRIANGLE_RIGHT_REGULAR: select_triangle_right_equal,
    ft.TRIANGLE_UP_REGULAR: select_triangle_up_equal,
    sh.RECTANGLE: select_rect
}
