#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE, LAYER_MODE_DIFFERENCE, LAYER_MODE_GRAIN_EXTRACT, pdb
)
from roller_a_contain import Globe, Run
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_fu import (
    blur_selection,
    clone_layer,
    dilate,
    isolate_selection,
    merge_layer_group,
    select_item
)
from roller_maya_style import Style
from roller_one_wip import Wip
from roller_view_real import (
    add_sub_base_group,
    add_wip_layer,
    clip_to_wip,
    do_gradient_for_layer,
    finish_style
)
from roller_view_hub import color_layer_default, do_mod, get_gradient_factors
from roller_view_shadow import do_stylish_shadow


def do_grid(z, q, is_vertical=True):
    """
    Draw grid lines. The grid lines are either
    horizontal or vertical, but not both.

    z: layer
        work-in-progress

    q: tuple
        argument for vertical or horizontal line

    is_vertical: bool
        If it's True, the argument is for a vertical line.
    """
    args = z.image, z
    q1 = 0, 0, 0, (0, 0, 0), 0

    if is_vertical:
        args += q1 + q + q1

    else:
        args += q + q1 * 2
    pdb.plug_in_grid(*args)


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: LostMaze
    Return: layer
        with the style material
    """
    # Is dependent.
    if maya.go:
        j = Run.j
        d = maya.value_d
        group = add_sub_base_group(maya)
        z = maze_layer = add_wip_layer("Base", group)
        w = max(1, int(Wip.w // d[ok.COLUMN]))
        h = max(1, int(Wip.h // d[ok.ROW]))
        seed_ = int(d[ok.SEED] + Globe.seed)

        pdb.gimp_context_set_foreground((0, 0, 0))
        pdb.gimp_context_set_background((255, 255, 255))
        select_item(z)
        pdb.plug_in_maze(
            j, z,
            w, h,               # passage scale
            1,                  # yes, tileable
            0,                  # depth first algorithm
            seed_,
            0,                  # multiple, not clearly defined
            0                   # offset, not clearly defined
        )

        z = clone_layer(z, n="Alpha")

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        alpha_layer = clone_layer(z, n="Difference")
        alpha_layer.mode = LAYER_MODE_DIFFERENCE

        pdb.gimp_selection_none(j)

        # no wrap, '0'; SOBEL, '0'
        pdb.plug_in_edge(j, maze_layer, 1., 0, 0)

        # Expand the border.
        for _ in range(2):
            dilate(maze_layer)

        pdb.plug_in_colortoalpha(j, maze_layer, (0, 0, 0))

        # horizontal line
        h1 = min(max(6, h // 5), int(Wip.h))

        do_grid(
            z,
            (h1, h1 + 1, 0, (0, 0, 0), 255),
            is_vertical=False
        )
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
        e = get_default_value(by.GRADIENT_FILL)

        e.update(d)

        e[ok.GRADIENT] = d[ok.RW1][ok.GRADIENT]
        e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
            get_gradient_factors(d)

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        select_item(z)

        sel = pdb.gimp_selection_save(j)

        pdb.gimp_selection_none(j)
        pdb.gimp_image_set_active_layer(j, z)

        z = do_gradient_for_layer(e, group, 0)

        if e[ok.START_X] < e[ok.END_X]:
            x = 3.

        elif e[ok.START_X] > e[ok.END_X]:
            x = -3.

        else:
            x = 0.

        if e[ok.START_Y] < e[ok.END_Y]:
            y = 3.

        elif e[ok.START_Y] > e[ok.END_Y]:
            y = -3.

        else:
            y = .0

        isolate_selection(z, sel)
        do_stylish_shadow(
            z, blur=9., intensity=150., offset_x=x, offset_y=y
        )
        pdb.gimp_selection_none(j)

        # vertical line
        z = add_wip_layer(
            "Vertical Line", group, offset=len(group.layers) + 1
        )

        color_layer_default(z, (255, 255, 255))
        pdb.gimp_selection_all(j)

        v1 = min(max(12, w // 12), int(Wip.h))

        do_grid(z, (v1, v1 + 1, 0, (0, 0, 0), 255))
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        do_stylish_shadow(z, blur=10, intensity=200., is_inner=True)
        do_stylish_shadow(z, blur=10, intensity=200.)

        # background
        z = do_gradient_for_layer(e, group, 0)

        pdb.gimp_image_lower_item_to_bottom(j, z)
        pdb.gimp_image_reorder_item(j, alpha_layer, group, 4)
        blur_selection(alpha_layer, 500)

        # grain
        z = clone_layer(alpha_layer, n="Grain Extract")

        pdb.gimp_image_reorder_item(j, z, group, 6)

        z.mode = LAYER_MODE_GRAIN_EXTRACT
        z.opacity = 100.

        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)

        z = merge_layer_group(group)

        pdb.gimp_image_remove_channel(j, sel)
        clip_to_wip(z)
        do_mod(z, d[ok.RW1][ok.MOD])
        return finish_style(z, "Lost Maze")


class LostMaze(Style):
    """Create Backdrop Style output."""
    is_dependent = False

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.RW1,),
                k_path + (ok.RW1, ok.MOD)
            ],
            make_style
        )
