#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Dog
from roller_constant_for import Signal as si, Widget as fw
from roller_constant_key import (
    Group as gk, Option as ok, Step as sk, Widget as wk
)
from roller_one_helm import Helm
from roller_one_ring import Ring
from roller_port_preview import PortPreview
from roller_widget_label import Label
from roller_widget_node import Piece


class PortRename(PortPreview):
    """Is a display container for a renaming a Model."""
    window_key = "Rename Model"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        self._entry = self._old_name = None
        PortPreview.__init__(self, d, g)

    def draw_entry(self, box):
        """
        Draw a rename group.

        box: GTK container
            to receive group
        """
        self.is_dirt = True
        w = fw.MARGIN
        padding = w, w, w, w
        n = self._old_name = Helm.get_group(sk.MODEL).widget_d[
            ok.MODEL_LIST].get_selected_name()
        piece = Piece(
            gk.MODEL_NAME, box, self.repo.any_group.item, group_type='preset'
        )

        piece.vbox.add(
            Label(
                **{
                    wk.PADDING: padding,
                    wk.TEXT: "\nPrevious Name:\n\t{}\n\nNew Name:".format(n)
                }
            )
        )

        a = Dog.loner_group(
            **{
                wk.COLOR: self.color,
                wk.IS_DEFAULT: False,
                wk.ITEM: piece,
                wk.PADDING: padding,
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win
            }
        )
        self._entry = a.widget_d[ok.RENAME_MODEL]
        self._entry.set_a(n)

    def draw(self):
        """Draw Widget."""
        self.draw_row((self.draw_entry, self.draw_basic_process))

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return lambda: None, self.on_accept_rename_model

    def on_accept_rename_model(self, *_):
        Ring.plug(si.RENAME, (self._old_name, self._entry.get_a()))
