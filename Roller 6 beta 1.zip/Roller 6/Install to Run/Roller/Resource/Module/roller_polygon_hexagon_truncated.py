#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Triangle as ft
from roller_model_goo import Goo
from roller_polygon import calc_pin_xy, make_coord_list


class HexagonTruncated:
    """
    Calculate the position and the size of cell for a hexagon cell shape.
    The pointy ends are vertically aligned. Is a double-spaced cell model-type.
    """

    @staticmethod
    def calc(model, o, ellipse_space=.0):
        """
        For Model cell, calculate cell and merge
        rectangle and their inscribed form polygon.

        model: Model
        o: One
            Cell Type option key has become an attribute in the One container.

        Return: list
            [Plan vote, Work vote]
        """
        def _arrange():
            """
            Arrange a hexagon shape of x, y coordinate
            where each x, y pair is a polygon vertex.

            Return: tuple
                Define a truncated hexagon.
            """
            _c = c * 2
            _x = q_x[_c + 1]
            _x1 = q_x[_c + 2]
            _y = q_y[r]
            _y1 = q_y[r + 1]
            _y2 = q_y[r + 2]
            return (
                q_x[_c], _y1,
                _x, _y,
                _x1, _y,
                q_x[_c + 3], _y1,
                _x1, _y2,
                _x, _y2
            )

        vote_d = {}
        did_cell = model.past.did_cell
        row, column = model.division
        goo_d = model.goo_d
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w = min(canvas_w, o.column_width)
            h = min(canvas_h, o.row_height)

            # grid size
            w1 = w * .75
            w2 = w - w1
            h1 = h / 2.
            s = column * w1 + w2, row * h1 + h1
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

        elif o.grid_type == gr.SHAPE_COUNT:
            # Calculate 's', 'w', 'h'.
            # vertical, cell size
            w, h = canvas_w / (.25 + column * .75), canvas_h / (.5 + row * .5)

            # two possible solutions
            # solution one
            # hexagon size, 'hex_w, hex_h'
            hex_w, hex_h = h * ft.SCALE_UP, h

            w1 = hex_w * .75
            w2 = hex_w - w1
            h1 = hex_h / 2.
            s = column * w1 + w2, row * h1 + h1

            # solution two
            # hexagon size, 'hex_w1, hex_h1'
            hex_w1, hex_h1 = w, w * ft.SCALE_DOWN

            w1 = hex_w1 * .75
            w2 = hex_w1 - w1
            h1 = hex_h1 / 2.
            s1 = column * w1 + w2, row * h1 + h1
            s = s[0], s[1]
            s1 = s1[0], s1[1]

            if s[0] > canvas_w or s[1] > canvas_h:
                s = s1
                w, h = hex_w1, hex_h1

            else:
                w, h = hex_w, hex_h
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

        else:
            # cell count
            w = canvas_w / (.25 + column * .75 - ellipse_space)
            h = canvas_h / (.5 + row * .5)

        h = h / 2.
        w1 = w * .25
        w2 = w * .75

        # [intersect point]
        q_x = []
        q_y = make_coord_list(canvas_h, row + 2, y, span=h)

        # remainder total, 'f_x'
        f_x = .0

        # Add remainder to coordinate when close to one.
        for _ in range(column + 1):
            x, f = divmod(x, 1.)
            f_x += f

            if f_x >= .999999:
                x += 1.
                f_x -= 1.

            q_x += [x, round(x + w1)]
            x += w2

        for r_c in model.cell_q:
            r, c = r_c
            c1 = c * 2
            x, x1 = q_x[c1], q_x[c1 + 3]
            y, y1 = q_y[r], q_y[r + 2]
            a = goo_d[r_c] = Goo(r_c)

            # Prevent round to zero with max 1.
            a.cell.rect = a.merged.rect = \
                x, y, max(1., x1 - x), max(1., y1 - y)
            a.form = _arrange()
            vote_d[r_c] = did_cell(r_c)
        return vote_d
