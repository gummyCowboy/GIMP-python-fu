#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Frame as ek, Material as ma, Option as ok
from roller_frame import do_embossed_wrap
from roller_frame_alt import FrameBasic


class Basic(FrameBasic):
    add_row = shade_row = ok.BRW
    is_embossed = True
    kind = ek.BASIC
    material = ma.BASIC
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        FrameBasic.__init__(
            self, any_group, super_maya, k_path, do_embossed_wrap
        )
