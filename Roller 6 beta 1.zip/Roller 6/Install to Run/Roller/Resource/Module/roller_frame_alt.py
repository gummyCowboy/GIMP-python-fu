#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_key import Material as ma, Option as ok, SubMaya as sm
from roller_maya import (
    check_matter,
    check_mix_basic,
    make_group_filler,
    make_group_overlay,
    make_group_shadow,
    make_group_wrap
)
from roller_maya_add import AddAbove, AltAdd
from roller_maya_build import Build, SubBuild
from roller_frame import mask_filler_layer, remove_sel, sort_shadow_layer
from roller_maya_below import Below
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_view_real import get_light, mask_sub_maya


class Wrap(SubBuild):
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        super_maya: Maya
            Frame type

        k_path: tuple
            (Option key, ...)
            Are path key to its vote dict.

        do_matter: function
            Make a wrap layer.
        """
        self.wrap_k = super_maya.wrap_k
        self.kind = super_maya.kind

        SubBuild.__init__(self, any_group, super_maya, k_path, do_matter)
        self.sub_maya[sm.LIGHT] = Light(any_group, self, super_maya.material)

    def do(self, d, is_change):
        """
        Produce GIMP layer output. Has a filler
        layer and a Gradient Light layer.

        d: dict
            frame Preset

        is_change: bool
            Is True if the cast Maya has change.

        Return: bool
            Is True if the wrap layer changed.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change

        self.realize()

        if self.matter:
            self.sub_maya[sm.LIGHT].do(m)

        self.reset_issue()
        return m


class AltFiller(SubBuild):
    """Process change for a filler output."""
    is_seeded = is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_filler, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path, do_filler):
        """
        Require the inheritor class to have a 'filler_k' attribute,
        a sub-row Option key to a filler dict.

        super_maya: Maya
            Frame type

        k_path: tuple
            (Option key, ...)
            Are path key to its vote dict.

        do_filler: function
            Call to make a filler layer.

        k: string
            Filler Option key
        """
        self.filler_k = super_maya.filler_k
        k_path += (ok.BRW, self.filler_k)
        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.BRW, ok.MOD)],
            do_filler
        )

        self.sub_maya[sm.ADD] = AltAdd(
            any_group, self, k_path + (ok.BRW, ok.ADD_ALT,)
        )
        self.sub_maya[sm.LIGHT] = Light(
            any_group, self, super_maya.material + ma.FILLER
        )

    def do(self, d, is_change, is_mask, is_back, filler_sel):
        """
        Produce GIMP layer output. Has a filler
        layer and a Gradient Light layer.

        d: dict
            frame Preset

        is_change: bool
            Is True if the cast Maya has change.

        is_mask: bool
            Is True if the mask has change.

        is_back: bool
            Is True if the background changed.

        filler_sel: GIMP selection channel
            Mask the 'matter' layer.

        Return: bool
            Is True if there is Filler change.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize()

        if self.matter:
            if self.is_matter or is_mask:
                mask_filler_layer(Run.j, self, filler_sel)

            self.sub_maya[sm.ADD].do(
                d[ok.BRW][ok.ADD_ALT], self.is_matter, is_mask, is_back
            )
            self.sub_maya[sm.LIGHT].do(is_change)

        else:
            self.die()
        self.reset_issue()


class AddAboveWrap(SubBuild):
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path, do_matter, material):
        """
        super_maya: Maya
            Frame t0ype

        k_path: tuple
            (Option key, ...)
            Are path key to its vote dict.

        do_matter: function
            Make a wrap layer.

        material: string
            Material key
        """
        self.wrap_k = super_maya.wrap_k
        k_path = k_path + (ok.BRW, self.wrap_k)

        SubBuild.__init__(self, any_group, super_maya, k_path, do_matter)

        self.sub_maya[sm.ADD] = AddAbove(
            any_group, self, k_path + (ok.ADD_ABOVE,)
        )
        self.sub_maya[sm.LIGHT] = Light(any_group, self, material)

    def do(self, d, is_change, is_back):
        """
        Produce GIMP layer output. Has a filler
        layer and a Gradient Light layer.

        d: dict
            frame Preset

        is_change: bool
            Is True if the cast Maya has change.

        is_back: bool
            Is True if the background changed.

        Return: bool
            Is True if the wrap layer changed.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(d[ok.ADD_ABOVE], m, m, is_back)
            self.sub_maya[sm.LIGHT].do(self.is_matter)

        else:
            self.die()

        self.reset_issue()
        return m


class AltWrapSel(SubBuild):
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )
    wrap_k = ok.WRAP_AL

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        super_maya: Maya
            Frame type

        k_path: tuple
            (Option key, ...)
            Are path key to its vote dict.

        do_matter: function
            Make a wrap layer.

        material: string
            Material key
        """
        self.filler_sel = None
        self.wrap_k = super_maya.wrap_k
        self.filler_k = super_maya.filler_k
        k_path = k_path + (ok.BRW, self.wrap_k)

        SubBuild.__init__(self, any_group, super_maya, k_path, do_matter)

        self.sub_maya[sm.ADD] = AltAdd(any_group, self, k_path + (ok.ADD_ALT,))
        self.sub_maya[sm.LIGHT] = Light(any_group, self, super_maya.material)

    def do(self, d, is_change, is_back):
        """
        Produce GIMP layer output. Has a filler
        layer and a Gradient Light layer.

        d: dict
            frame Preset

        is_change: bool
            Is True if the cast Maya has change.

        is_back: bool
            Is True if the background changed.

        Return: bool
            Is True if the wrap layer changed.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(d[ok.ADD_ALT], m, m, is_back)
            self.sub_maya[sm.LIGHT].do(self.is_matter)

        else:
            self.die()

        self.reset_issue()
        return m

    def reset(self):
        """Call when the View image is removed."""
        remove_sel(self, 'filler_sel')
        super(AltWrapSel, self).reset()


class AltWrapFiller(Build):
    is_embossed = True
    issue_q = ()
    put = (make_group_shadow, 'group'),

    def __init__(self, any_group, super_maya, k_path, do_matter, do_filler):
        """
        Require the inheritor class to have a attributes 'wrap_k' and
        'filler_k'. Both are sub-row Option key to a wrap or filler dict.

        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Is the Key path of the Frame Button in its vote dict.

        do_matter: function
            Make a matter layer.

        do_filler: function
            Make a filler layer.
        """
        Build.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.WRAP] = AltWrapSel(
            any_group, self, k_path, do_matter
        )
        self.sub_maya[sm.FILLER] = AltFiller(
            any_group, self, k_path, do_filler
        )
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group,
            self,
            (self.cast, self.sub_maya[sm.WRAP], self.sub_maya[sm.FILLER]),
            k_path + (ok.BRW, ok.SHADOW)
        )

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        m = is_change
        e = self.sub_maya
        wrap = e[sm.WRAP]

        self.realize()

        m |= wrap.do(
            d[ok.BRW][self.wrap_k], is_change, is_back
        )

        if wrap.matter:
            e[sm.FILLER].do(
                d[ok.BRW][self.filler_k],
                is_change,
                m,
                is_back,
                wrap.filler_sel
            )

            m = e[sm.SHADOW].do(d[ok.BRW][ok.SHADOW], is_change, m)
            sort_shadow_layer(self, m, get_light(wrap))

        else:
            self.die()
        self.reset_issue()


class FrameBasic(Build):
    issue_q = ()
    put = (make_group_shadow, 'group'),

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.

        do_matter: function
            Call to make the frame layer.
        """
        Build.__init__(self, any_group, super_maya, k_path, do_matter)
        self.sub_maya[sm.WRAP] = Wrap(
            any_group,
            self,
            [
                k_path,
                k_path + (ok.BRW, self.wrap_k),
                k_path + (ok.BRW, self.wrap_k, ok.RW1)      # ShapeBurst
            ],
            do_matter
        )
        self.sub_maya[sm.ADD] = AltAdd(
            any_group,
            self.sub_maya[sm.WRAP],
            k_path + (self.add_row, ok.ADD_ALT,)
        )
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group,
            self,
            (self.cast, self.sub_maya[sm.WRAP]),
            k_path + (self.shade_row, ok.SHADOW)
        )

    def add_filler_k_path(self, k_path):
        """
        Add the filler k-path to the Wrap k-path.

        k_path: tuple
            (Option key, ...)
        """
        self.sub_maya[sm.WRAP].k_path += [k_path + (ok.BRW, self.filler_k)]

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        m = is_change
        wrap = self.sub_maya[sm.WRAP]

        self.realize()

        m |= wrap.do(d[ok.BRW][self.wrap_k], is_change)

        if wrap.matter:
            m1 = self.sub_maya[sm.SHADOW].do(
                d[self.shade_row][ok.SHADOW], is_change, m
            )
            m1 |= self.sub_maya[sm.ADD].do(
                d[self.add_row][ok.ADD_ALT], m, m, is_back or m1
            )
            sort_shadow_layer(self, m1, get_light(wrap))

        else:
            self.die()
        self.reset_issue()


class Overlay(SubBuild):
    """
    Process change for an overlay layer.
    Change its blend with its super Maya mask.
    """
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_overlay, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path, do_overlay, material):
        """
        super_maya: Maya
            Is the enclosing Maya.

        k_path: tuple
            (Option key, ...)
            Are path key to its vote dict.

        do_overlay: function
            Make an overlay layer.

        material: string
            Material key
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, do_overlay)

        self.sub_maya[sm.ADD] = AddAbove(
            any_group, self, k_path + (ok.ADD_ABOVE,)
        )
        self.sub_maya[sm.LIGHT] = Light(any_group, self, material + ma.OVERLAY)

    def do(self, d, is_change, is_mask, is_back):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        is_change: bool
            If it is True, then a mask is drawn on the Color layer.

        is_mask: bool
            Is True if the frame Maya has change.

        is_back: bool
            Is True if the background changed.
        """
        self.value_d = d
        self.is_matter += is_change

        self.realize()

        if self.matter:
            if self.is_matter or is_mask:
                mask_sub_maya(
                    self.super_maya.sub_maya[sm.WRAP].matter, self.matter
                )

            self.sub_maya[sm.ADD].do(
                d[ok.ADD_ABOVE], self.is_matter, self.is_matter, is_back
            )
            self.sub_maya[sm.LIGHT].do(is_change)

        else:
            self.die()
        self.reset_issue()


class FrameOverlay(Build):
    issue_q = ()
    put = (make_group_shadow, 'group'),

    def __init__(self, any_group, super_maya, k_path, do_matter, do_overlay):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in the Preset's vote dict.
            (Option key, ...)

        do_matter: function
            Produce Wrap output.

        do_overlay: function
            Produce Overlay output.
        """
        Build.__init__(self, any_group, super_maya, k_path, do_matter)

        rap = self.sub_maya[sm.WRAP] = AddAboveWrap(
            any_group, self, k_path, do_matter, self.material
        )
        self.sub_maya[sm.OVERLAY] = Overlay(
            any_group,
            self,
            k_path + (ok.BRW, self.overlay_k),
            do_overlay,
            self.material
        )
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group,
            self,
            (self.cast, rap),
            k_path + (self.shade_row, ok.SHADOW)
        )
        self.sub_maya[sm.BELOW] = Below(
            any_group, rap, k_path + (self.shade_row, ok.BELOW)
        )

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            Bevel Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        m = is_change
        wrap = self.sub_maya[sm.WRAP]

        self.realize()

        m |= wrap.do(
            d[ok.BRW][self.wrap_k], is_change, is_back
        )

        if wrap.matter:
            self.sub_maya[sm.OVERLAY].do(
                d[ok.BRW][self.overlay_k], is_change, m, is_back
            )

            m1 = self.sub_maya[sm.SHADOW].do(
                d[self.shade_row][ok.SHADOW], is_change, m
            )

            sort_shadow_layer(self, m1, get_light(wrap))
            self.sub_maya[sm.BELOW].do(d[
                self.shade_row][ok.BELOW], is_back or m1, m
            )

        else:
            self.die()
        self.reset_issue()
