#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_INTERSECT, CHANNEL_OP_REPLACE, LAYER_MODE_SOFTLIGHT, pdb
)
from roller_a_contain import Globe, Run
from roller_a_gegl import emboss
from roller_constant_key import (
    Frame as ek, Material as ma, Option as ok, SubMaya as sm
)
from roller_frame_alt import FrameBasic
from roller_fu import (
    add_layer,
    blur_selection,
    clear_inverse_selection,
    discard_mask,
    isolate_selection,
    make_layer_group,
    merge_layer_group,
    select_item
)
from roller_view_hub import (
    color_layer, color_selection, set_fill_context_default
)
from roller_view_real import clip_to_wip, clone_background, get_light


def select_bump_color(z):
    """
    Create a bump selection.

    z: layer
        Is sampled.

    Return: state of selection
    """
    pdb.gimp_context_set_feather(1)
    pdb.gimp_context_set_feather_radius(3., 3.)

    # composite, '0'
    pdb.gimp_context_set_sample_criterion(0)

    pdb.gimp_context_set_sample_threshold(.33)
    pdb.gimp_image_select_color(
        z.image, CHANNEL_OP_REPLACE, z, (255, 255, 255)
    )


def select_bg_white(z):
    """
    Create a selection from white color. Inherit
    GIMP context settings from 'select_bump_color'.

    z: layer
        Is sampled.

    Return: state of selection
    """
    pdb.gimp_context_set_feather_radius(4., 4.5)
    pdb.gimp_context_set_sample_threshold(.13)
    pdb.gimp_image_select_color(
        z.image, CHANNEL_OP_REPLACE, z, (255, 255, 255)
    )


def do_matter(maya):
    """
    Make a frame.

    maya: Glue
    Return: layer
        with the frame
    """
    j = Run.j
    d = maya.value_d
    w, h = j.width, j.height
    cast = maya.cast.matter

    set_fill_context_default()

    # A mask interferes with 'clone_background'.
    discard_mask(maya.group)

    # Resize material layer so that the waves plug-in will perform
    # its function off-center which has less symmetry and stretch.
    pdb.gimp_image_resize(j, w + w, h + h, 0, 0)

    group = make_layer_group(
        j,
        maya.group.name + " Material",
        parent=maya.group,
        offset=get_light(maya)
    )
    bump_z = add_layer(j, "Bump", parent=group)
    w1 = d[ok.WIDTH]
    w1 = int(w1 // 2. + w1 % 2)

    color_layer(bump_z, (48, 48, 48))
    select_item(cast)

    # Make a border overlapping the cast.
    pdb.gimp_selection_border(j, int(w1))

    color_selection(bump_z, (255, 255, 255))

    bg_z = clone_background(bump_z, n="Base")

    pdb.gimp_selection_none(j)
    pdb.plug_in_waves(
        j, bump_z,
        d[ok.WAVE_AMPLITUDE],
        d[ok.WAVE_PHASE],
        d[ok.WAVELENGTH],
        0,                      # smeared
        0                       # not reflective
    )
    pdb.gimp_image_resize(j, w, h, 0, 0)
    blur_selection(bump_z, d[ok.SOFTEN] * 2.)
    select_bump_color(bump_z)

    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    emboss(bump_z, Globe.azimuth, 45., int(d[ok.SOFTEN]))
    isolate_selection(bump_z, sel)
    pdb.gimp_image_remove_channel(j, sel)

    bg_z.mode = LAYER_MODE_SOFTLIGHT

    blur_selection(bg_z, d[ok.SOFTEN] * 2)
    select_bg_white(bg_z)
    select_item(bump_z, CHANNEL_OP_INTERSECT)
    clear_inverse_selection(bg_z)
    pdb.gimp_image_reorder_item(j, bg_z, group, 0)

    z = merge_layer_group(group)

    clip_to_wip(z)
    return z


class Glue(FrameBasic):
    """Create a translucent type of frame that has a gluey tube appearance."""
    add_row = shade_row = ok.BRW
    is_embossed = True
    kind = ek.GLUE
    material = ma.GLUE
    wrap_k = ok.WRAP_GL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)

    def do(self, d, is_change):
        """
        Glue is background change sensitive.

        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.sub_maya[sm.WRAP].is_matter |= Run.is_back
        super(Glue, self).do(d, is_change)
