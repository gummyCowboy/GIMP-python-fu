#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_a_contain import Dog
from roller_constant_for import Widget as fw
from roller_constant_key import Button as bk, Option as ok, Widget as wk
from roller_port_preview import PortPreview
from roller_widget_button import (
    AcceptButton,
    CancelButton,
    PlanButton,
    PreviewButton,
    RandomButton
)
from roller_widget_node import Piece
from roller_widget_heat import HeatTable
from roller_widget_row import WidgetRow


class PortHeat(PortPreview):
    """Edit the Heat Preset."""
    window_key = "Heat"

    def __init__(self, d, g):
        """
        d: dict
            Initialize Port.

        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def draw_heat(self, box):
        """
        Draw the Heat option group.

        box: VBox
            container for the Widgets
        """
        d = {
            wk.COLOR: self.color,
            wk.ITEM: Piece(ok.HEAT, box, self.repo.any_group.item),
            wk.RELAY: [self.on_port_change],
            wk.ROLLER_WIN: self.roller_win
        }
        self.any_group = d[wk.ANY_GROUP] = Dog.none_group(**d)
        self._heat_table = HeatTable(**d)
        self._heat_table.set_a(self.repo.get_a())

    def draw(self):
        """
        Draw Widget.

        vbox: VBox
            container for the Widgets
        """
        self.draw_column((self.draw_heat, self.draw_heat_process))

    def draw_heat_process(self, vbox):
        """
        Draw a group with process Buttons.

        vbox: GTK container
            to receive group
        """
        g = WidgetRow(
            **{
                wk.ANY_GROUP: self.any_group,
                wk.PADDING: (0, 0, fw.MARGIN, fw.MARGIN),
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win,
                wk.SUB: OrderedDict([
                    (bk.CANCEL, {wk.WIDGET: CancelButton}),
                    (bk.RANDOM, {wk.WIDGET: RandomButton}),
                    (bk.PLAN, {wk.WIDGET: PlanButton}),
                    (bk.PREVIEW, {wk.WIDGET: PreviewButton}),
                    (bk.ACCEPT, {wk.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        vbox.add(g)

    def get_group_value(self):
        """
        Fetch the Heat Table value.

        Return: dict
            Heat Preset
        """
        return self._heat_table.get_a()
