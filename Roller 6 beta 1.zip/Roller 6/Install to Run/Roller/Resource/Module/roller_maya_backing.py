#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, FILL_PATTERN, pdb   # type: ignore
from roller_a_contain import Globe, Run
from roller_constant_for import Backdrop as bs, Issue as vo
from roller_constant_key import (
    BackdropStyle as by, Material as ma, Option as ok, SubMaya as sm
)
from roller_def import get_default_value
from roller_fu import (
    create_image,
    get_layer_position,
    layer_has_pixel,
    make_clouds,
    select_rect,
    verify_layer
)
from roller_many_image import get_image_ref
from roller_maya import ImageRoll, check_matter
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_one_wip import Wip
from roller_view_hub import (
    color_selection_default,
    do_mod,
    get_gradient_factors,
    set_fill_context_default,
    set_gimp_pattern
)
from roller_view_real import (
    add_wip_layer, do_gradient_for_layer, isolate_wip_rect, make_group
)


def add_image(maya):
    """
    Make a Backing image layer.

    maya: Maya
    Return: layer or None
        Backing
    """
    d = maya.value_d
    j = Run.j
    w, h = map(int, Wip.get_size())
    z = make_backing_layer(maya)
    j1 = maya.get_image(None)

    if j1:
        # GIMP image, 'j2'
        j2 = j1.j

        if j1.size != (w, h) and d[ok.FILLED]:
            j3 = create_image(w, h)
            z1 = pdb.gimp_layer_new_from_visible(j2, j3, "")

            j3.add_layer(z1, 0)

            # Use image origin, '1'.
            pdb.gimp_layer_scale(z1, w, h, 1)

            pdb.gimp_image_resize_to_layers(j3)

            z1 = pdb.gimp_layer_new_from_visible(j3, j, "")
            pdb.gimp_image_delete(j3)

        else:
            z1 = pdb.gimp_layer_new_from_visible(j2, j, "")

        pdb.gimp_image_insert_layer(j, z1, z.parent, get_layer_position(z))

        if z1.width != j.width or z1.height != j.height:
            pdb.gimp_layer_set_offsets(
                z1,
                (j.width - z1.width) // 2, (j.height - z1.height) // 2
            )

        z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
        z.name = "Backdrop Backing Image"
        if layer_has_pixel(z) and not d[ok.FILLED]:
            isolate_wip_rect(z)
    return z


def check_work_group(maya):
    """
    Create a Backdrop layer group.

    maya: Work
    Return: layer group
        for Work
    """
    if not maya.group:
        return make_work_group()
    return maya.group


def do_matter(maya):
    """
    Create a Backing layer.

    maya: Work
    Return: layer
        Backing
    """
    def _do_color():
        """
        Create a layer filled with one color.

        Return: layer
            Backing
        """
        _z = add_wip_layer(n1, group, offset=offset)

        select_rect(j, *Wip.get_rect())
        color_selection_default(_z, d[ok.COLOR_1])
        return _z

    def _do_clouds():
        """
        Create a layer with simulated clouds.

        Return: layer
            Backing
        """
        _z, _seed = _do_random()
        make_clouds(_z, _seed)
        return _z

    def _do_gradient():
        """
        Create a gradient layer.

        Return: layer
            Backing
        """
        add_wip_layer("Backing Gradient", group, offset=offset)

        _d = get_default_value(by.GRADIENT_FILL)
        _d[ok.GRADIENT] = d[ok.GRADIENT]
        _d[ok.GRADIENT_TYPE] = d[ok.GRADIENT_TYPE]
        _d[ok.START_X], _d[ok.END_X], _d[ok.START_Y], _d[ok.END_Y] = \
            get_gradient_factors(d)
        _z = do_gradient_for_layer(_d, group, offset)
        _z = verify_layer(_z)

        if _z:
            _z = pdb.gimp_image_merge_down(j, _z, CLIP_TO_IMAGE)
        return _z

    def _do_image():
        """
        Create a layer from an image.

        Return: layer
            Backing
        """
        return add_image(maya)

    def _do_pattern():
        """
        Create a layer filled with a GIMP pattern.

        Return: layer
            Backing
        """
        _z = add_wip_layer(n1, group, offset=offset)

        set_fill_context_default()
        set_gimp_pattern(d[ok.PATTERN])
        pdb.gimp_drawable_edit_bucket_fill(
            _z, FILL_PATTERN, *Wip.center()
        )
        return _z

    def _do_plasma():
        """
        Create a layer made with the GIMP's plasma plugin.

        Return: layer
            Backing
        """
        _z, _seed = _do_random()
        pdb.plug_in_plasma(j, _z, _seed, 1.5)
        return _z

    def _do_random():
        """Create a layer and calculate a random seed.

        Return: tuple
            (layer, int)
            (Backing layer, random seed)
        """
        _z = add_wip_layer(n1, group, offset=offset)
        _seed = int(d[ok.SEED] + Globe.seed)
        return _z, _seed

    j = Run.j
    d = maya.value_d
    n = d[ok.TYPE]
    n1 = "Backing " + n
    group = maya.group
    offset = len(group.layers)

    pdb.gimp_selection_none(j)

    if d[ok.SWITCH]:
        z = {
            bs.CLOUDS: _do_clouds,
            bs.COLOR: _do_color,
            bs.GRADIENT: _do_gradient,
            bs.IMAGE: _do_image,
            bs.PATTERN: _do_pattern,
            bs.PLASMA: _do_plasma,
        }[n]()
        if z:
            if layer_has_pixel(z):
                do_mod(z, d[ok.RW1][ok.MOD])

    else:
        z = add_wip_layer("Base", group, offset=offset)
    return z


def make_backing_layer(maya):
    """
    Create a Backing image layer.

    maya: Maya
    Return: layer
        Is new.
    """
    return add_wip_layer(
        "Backing Image Empty", maya.group, offset=len(maya.group.layers)
    )


def make_work_group():
    """
    Make a Backdrop layer group for Work.

    Return: layer group
        Is for Backdrop output.
    """
    return make_group("Backdrop", None, offset=len(Run.j.layers))


class Backing(ImageRoll):
    """Factor Plan and Work."""
    issue_q = 'matter',
    vote_type = vo.MAIN
    put = (check_work_group, 'group'), (check_matter, 'matter'),

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            A Preset is displayed as a Widget group in a navigation
            tree having a step key, a value dict, and change vote.

            Is the Backdrop option group.
        """
        # View's Work index, '1'
        ImageRoll.__init__(
            self,
            any_group,
            1,
            Backing.put,
            [(ok.BACKING,), (ok.BACKING, ok.RW1, ok.MOD)]
        )
        self.set_issue()

        self.do_matter = do_matter
        self.sub_maya[sm.BUMP] = Bump(
            any_group, self, (ok.BACKING, ok.RW1, ok.BUMP,)
        )
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.BACKDROP)

    def prep(self, d):
        """
        Assign the Backing Image. Is called by Backing and not from Run.
        """
        n = d[ok.TYPE]

        if n == bs.IMAGE:
            e = d[ok.IMAGE_CHOICE]
            image = get_image_ref(e, Run.j_d) if e[ok.SWITCH] else None

        else:
            image = None

        if image != self.get_image(None):
            self.is_matter = True
        self.set_image(None, image)

    def do(self, d):
        """
        Manage the Backing layer for a View run.
        Override the 'Run.do' function.

        Return: bool
            Is True if Backing matter has change.
        """
        self.value_d = d

        self.prep(d)
        self.realize()

        # A boolean that is True if Backing is changing the background, 'm'.
        m = self.sub_maya[sm.BUMP].do(
            d[ok.RW1][ok.BUMP], self.is_matter, self.is_matter
        )
        m += self.is_matter

        self.sub_maya[sm.LIGHT].do(m)
        self.reset_issue()
        return m
