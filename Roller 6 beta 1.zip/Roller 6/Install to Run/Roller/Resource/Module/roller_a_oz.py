#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Preset as fp
from roller_fu_comm import show_err

# 'cpickle' is not available in Python 3.
import cPickle

import os


def ensure_dir(n):
    """
    Ensure a directory exists. Use to make a Preset folder.

    n: string
        file path

    Return two flags.
        err: bool
            error flag

        go: bool
            If it is true, then the operation was successful.
    """
    go = err = False

    if n and not os.path.isdir(os.path.dirname(n)):
        try:
            os.makedirs(os.path.dirname(n))
        except Exception as ex:
            err = True
            show_err(ex)
            show_err("Roller is unable to store files at\n" + n)

    else:
        go = True
    return err, go


def get_preset_path(n, n1, dir_):
    """
    Construct a file path to a Preset file.

    n: string
        Preset key

    n1: string
        file id

    dir_: string
        Preset root directory

    Return: string
        Preset file path
    """
    n2 = os.path.join(dir_, n)
    n3 = os.path.join(n2, make_preset_name(n, n1))
    return n3


def make_preset_name(n, n1):
    """
    Format a Preset file name.

    n: string
        preset name

    n1: string
        file specific id

    Return: string
        preset name
    """
    return n + fp.PRESET_SEPARATOR + n1 + ".pkl"


def pickle_dump(d, n):
    """
    Write a file using 'cPickle'.

    d: dict
        Is Pickle output.

    n: string
        file path

    Return: bool
        Is True if the operation succeeded.
    """
    go = False
    err, _ = ensure_dir(n)

    if not err:
        try:
            with open(n, "wb") as output_file:
                cPickle.dump(d, output_file)
            go = True
        except Exception as ex:
            show_err(ex)
            show_err("Roller is unable to save:\n" + n)
    return go


def pickle_load(n, is_shown=True):
    """
    Read a 'cPickle' type file.

    n: string
        file path

    show_err: bool
        If it is False, then a load error is not displayed.

    Return: dict or None
        the data read in
    """
    e = None
    err, go = ensure_dir(n)

    if go and not err:
        try:
            with open(n, "rb") as input_file:
                e = cPickle.load(input_file)
                if not isinstance(e, dict):
                    # failure
                    e = {}
        except Exception as ex:
            if is_shown:
                show_err(ex)
                show_err("Roller is unable to load\n" + n)
    return e
