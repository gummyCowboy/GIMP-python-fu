#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_DARKEN_ONLY,
    LAYER_MODE_HSV_SATURATION,
    LAYER_MODE_OVERLAY,
    pdb
)
from roller_a_contain import Globe, Run
from roller_constant_key import Option as ok
from roller_fu import clone_layer, dilate, merge_layer_group
from roller_maya_style import Style
from roller_view_hub import color_layer_default, do_mod
from roller_view_real import add_sub_base_group, add_wip_layer, finish_style


def make_style(maya):
    """
    Make a style layer.

    maya: SquareCloud
    Return: layer or None
        with the style material
    """
    # Is dependent.
    if maya.go:
        j = Run.j
        d = maya.value_d
        group = add_sub_base_group(maya)
        base = add_wip_layer("Base", group)
        z = clone_layer(base, n="Plasma")

        pdb.gimp_selection_none(j)

        # medium turbulence, '3.5'
        pdb.plug_in_plasma(j, z, int(d[ok.SEED] + Globe.seed), 3.5)

        z1 = clone_layer(z, n="Erode")

        for i in range(10):
            dilate(z1)
            pdb.plug_in_erode(
                j, z,
                6,                      # propagate opaque
                7,                      # RGB channels
                1.,                     # full rate
                7,                      # RGB channels
                0,                      # low limit
                255                     # upper limit
            )

        pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
        pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
        color_layer_default(base, (127, 127, 127))

        z2 = clone_layer(base, n="HSV Saturation")
        z2.mode = LAYER_MODE_HSV_SATURATION

        pdb.gimp_image_reorder_item(j, z2, group, 0)

        z3 = clone_layer(z, n="Overlay")
        z3.mode = LAYER_MODE_OVERLAY
        z3.opacity = 75.

        pdb.gimp_image_reorder_item(j, z3, group, 0)

        z4 = clone_layer(z3, n="Darken Only")
        z4.mode = LAYER_MODE_DARKEN_ONLY
        z4.opacity = 30.
        z = merge_layer_group(group)
        z = clone_layer(z, n="Colorify")
        z.opacity = 50.

        pdb.plug_in_colorify(j, z, d[ok.COLOR_1])

        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

        do_mod(z, d[ok.BRW][ok.MOD])
        return finish_style(z, "Square Cloud")


class SquareCloud(Style):
    """Create Backdrop Style output."""
    is_seeded = is_dependent = True

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.BRW, ok.MOD)],
            make_style
        )
