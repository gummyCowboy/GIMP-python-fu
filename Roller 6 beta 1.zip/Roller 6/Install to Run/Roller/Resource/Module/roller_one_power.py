#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import Signal as si
import gobject


class Power(gobject.GObject, object):
    """
    Accept signal from object. Keep signal in an OrderedDict.
    Process the signal list when the interface is idle.

    The baby paradigm is inspired by a subscriber's dependency on Power.
    """
    # Reference
    #   github.com/sebp/PyGObject-Tutorial/blob/master/source/objects.txt
    #   library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
    #   zetcode.com/gui/pygtk/signals/
    #   stackoverflow.com/questions/66730/how-do-i-create-a-new-signal-in-pygtk

    # Are signals that can be emitted by this class.
    __gsignals__ = si.POWER_D

    def __init__(self, the):
        """
        the: The
        """
        # for custom signal(s)
        gobject.GObject.__init__(self)
        self.signal_d = OrderedDict()

        # Has subscriber to idle signal checking, 'self._crib'.
        # {object id: object}
        self._crib = {}

        # It's faster to the 'self' space than using the global.
        self.the = the

        # Is True when there are no Signal in 'signal_d', 'self.is_gone'.
        # Send a 'si.POWER_GONE' Signal when the dict is emptied.
        self.is_gone = False

    def add(self, a, n, arg):
        """
        Add a signal to the signal dict.

        a: object
            The object to emit the signal.

        n: string
            signal id

        arg: value
            Sent with signal.
        """
        k = id(a), n

        # Remove old an signal so that the new signal is done last.
        if k in self.signal_d:
            self.signal_d.pop(k)
        self.signal_d[k] = a, n, arg

    def carry(self, baby):
        """
        Subscribe an entity, (e.g. a Model instance), so that it can
        do its own signal processing when the interface is idle.
        """
        self._crib[id(baby)] = baby

    def drop(self, baby):
        """
        Remove a subscriber.

        baby: Baby
            Is in the crib.
        """
        self._crib.pop(id(baby))

    def plug(self, n, arg):
        """
        Add a Power signal.

        n: string
            Signal type

        arg: value
        """
        self.add(self, n, arg)

    def pressure(self):
        """Clear the signal list and all subscribers do the same."""
        sending = True

        while sending:
            sending = False

            # There are possible semi-circular usage of Power by a subscriber.
            if self.signal_d:
                self.turn()
                sending = True

            # object id, object; '_, a'
            for _, a in self._crib.items():
                if a.signal_d:
                    a.pressure()
                    sending = True

    def send(self):
        """Send out a signal."""
        if self.signal_d:
            self.turn()

        else:
            # Only call subscriber if a Preset isn't loading.
            if not self.the.load_count:
                for _, a in self._crib.items():
                    a.turn()
        return True

    def turn(self):
        """Send out one signal if there is one."""
        for i, a in self.signal_d.items():
            sender, signal, arg = a

            self.signal_d.pop(i)
            sender.emit(signal, arg)

            if not self.signal_d:
                if not self.is_gone:
                    self.is_gone = True
            break
        if self.is_gone:
            self.is_gone = False
            self.emit(si.POWER_GONE, None)


# Register the custom signals.
gobject.type_register(Power)
