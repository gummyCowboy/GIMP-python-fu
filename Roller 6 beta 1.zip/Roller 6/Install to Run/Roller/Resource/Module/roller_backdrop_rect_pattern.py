#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from random import randint
from roller_constant_key import Option as ok
from roller_fu import (
    add_layer, create_image, copy_all_image, select_rect
)
from roller_maya_style import Style
from roller_polygon import make_coord_list
from roller_view_hub import (
    clipboard_fill_arg, color_selection, do_mod, set_fill_context_default
)
from roller_view_preset import combine_seed
from roller_view_real import do_rotated_layer, finish_style


def make_pattern(d):
    """
    Make a rectangle pattern. The pattern is made-to-order and
    is then transferred to the canvas via the clipboard.

    d: dict
        Rectangle Pattern Preset
        {Option key: value}

    Return: image in the clipboard
        Is the pattern.
    """
    q_x1 = []

    set_fill_context_default()

    # pattern size
    width, height = d[ok.WIDTH], d[ok.HEIGHT]

    # Make a hidden image to draw the pattern on, 'j'.
    j = create_image(int(width), int(height))
    z = add_layer(j, "Pattern")

    row = column = int(d[ok.COLOR_COUNT])

    # Calculate the size of the rectangle, 'w, h'.
    # Use the rectangle to make selections for color fill.
    w, h = width / row, height / row

    is_brick = d[ok.COLOR_GRID_TYPE]
    is_random = d[ok.RANDOM_ORDER]

    # x-intersect list, 'q_x'
    # for both checkerboard and brick
    q_x = []
    x = y = 0
    column1 = column + 4

    # remainder total, 'f_x'
    f_x = .0

    for i in range(1, column1):
        x, f = divmod(x, 1.)
        f_x += f

        if f_x >= .999999:
            x += 1.
            f_x -= 1.

        q_x += [round(x)]
        x += w

    if is_brick:
        # x-intersect array for brick odd rows, 'q_x1'
        q_x1 = [.0]
        x = w / 2.
        for i in range(1, column1):
            q_x1 += [round(x)]
            x += w

    # y-intersect array, 'q_y'
    q_y = make_coord_list(height, row + 1, y, span=h)

    for r in range(row):
        if is_brick and r % 2:
            # Need an extra column for the half-cut bricks.
            brick = column + 1

        else:
            brick = column

        for c in range(brick):
            if is_random:
                # Get a random color from the color options.
                color = d[ok.COLOR_6A][randint(0, row - 1)]

            else:
                # Get the next color in the wrap-around color scheme.
                index = r * row + r + c

                while index >= row:
                    index -= row
                color = d[ok.COLOR_6A][index]

            if is_brick and r % 2:
                x = q_x1[c]
                w = q_x1[c + 1] - x

            else:
                x = q_x[c]
                w = q_x[c + 1] - x

            y = q_y[r]
            h = q_y[r + 1] - q_y[r]

            # Select and fill the calculated rectangle.
            select_rect(j, x, y, w, h)
            color_selection(z, color)

    # Set the Clipboard Image for the pattern fill op.
    copy_all_image(j)

    # Close the tile image as the pattern is done.
    pdb.gimp_image_delete(j)


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: RectanglePattern
    Return: layer
        with the style material
    """
    d = maya.value_d

    set_fill_context_default()
    combine_seed(d)
    make_pattern(d)

    z = do_rotated_layer(d, clipboard_fill_arg, maya.group, 0)

    do_mod(z, d[ok.BRW][ok.MOD])
    return finish_style(z, "Rectangle Pattern")


class RectPattern(Style):
    """Create Backdrop Style output."""
    is_dependent = False

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.BRW, ok.MOD)],
            make_style
        )
