#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, LAYER_MODE_DODGE, pdb   # type: ignore
from roller_a_contain import Run
from roller_constant_key import Frame as ek, Material as ma, Option as ok
from roller_frame import select_frame
from roller_frame_alt import FrameOverlay
from roller_fu import (
    add_layer,
    add_layer_above,
    clear_selection,
    clear_inverse_selection,
    clone_layer,
    make_layer_group,
    merge_layer_group,
    select_item
)
from roller_view_hub import (
    color_layer, color_selection, set_fill_context_default
)
from roller_view_real import add_wip_layer, get_light
from roller_view_shadow import do_stylish_shadow


def do_matter(maya):
    """
    Make a frame.

    maya: Clear
    Return: layer
        Clear Wrap 'matter'
    """
    j = Run.j
    d = maya.value_d
    cast = maya.cast.matter
    frame_q = []
    w = d[ok.INNER_FRAME_W]
    group = make_layer_group(
        j,
        maya.group.name + " Material",
        parent=maya.group,
        offset=get_light(maya)
    )

    set_fill_context_default()
    select_item(cast)

    if not pdb.gimp_selection_is_empty(j):
        # Create two layers.
        for x in range(2):
            # Add layer to the bottom of the group layer.
            z = add_layer(
                j,
                ("1", "2")[x],
                parent=group,
                offset=len(group.layers)
            )

            select_frame(
                j, cast, (w, d[ok.WIDTH] + w)[x], d[ok.TYPE]
            )
            color_selection(z, (127, 127, 127))

            z = give_edge(j, z)
            frame_q += [z]

        z = do_stylish_shadow(frame_q[0], blur=5., intensity=130.)
        if z:
            select_item(cast)
            clear_selection(z)
    return merge_layer_group(group)


def do_overlay(maya):
    """
    Make a color layer.

    maya: Overlay
    Return: layer
        with color
    """
    pdb.gimp_selection_none(Run.j)

    d = maya.value_d
    z = add_wip_layer("Material", maya.group, offset=get_light(maya))

    color_layer(z, d[ok.COLOR_1])
    return z


def give_edge(j, z):
    """
    Give the frame an edge.

    j: GIMP image
        WIP

    z: layer
        to give edge

    Return: layer
        with edge
    """
    z1 = clone_layer(z, "Material")
    z2 = add_layer_above(z, n="Back")

    color_layer(z2, (100, 100, 100))

    z1 = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

    # amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(z.image, z1, 1., .0, .0)

    z1.mode = LAYER_MODE_DODGE

    select_item(z)
    clear_inverse_selection(z1)
    return pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)


class Clear(FrameOverlay):
    """Is a crisp translucent frame with an inner ridge."""
    kind = ek.CLEAR
    material = ma.CLEAR
    overlay_k = ok.OVERLAY_CO
    shade_row = ok.RW1
    wrap_k = ok.WRAP_CL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            option owner

        super_maya: Maya
            deco type

        k_path: tuple
            Is the path to the Frame Button.
        """
        FrameOverlay.__init__(
            self, any_group, super_maya, k_path, do_matter, do_overlay
        )
