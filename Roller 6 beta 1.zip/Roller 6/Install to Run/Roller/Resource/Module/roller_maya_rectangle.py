#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_for import Issue as vo, Signal as si
from roller_maya import Maya
from roller_one_ring import Ring
from roller_option_group import ManyGroup


class Rectangle(ManyGroup):
    """
    Create Widget group, assign a View processor,
    and connect responsible signal handler.
    """

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)
        self.work = Chi(self, 1)
        self.plan = Chi(self, 0)

        self.latch(self.booth, (si.VOTE_CHANGE, self.update_model))
        self.latch(self, (si.SEQUENCE, self.on_sequence))
        self.latch(Ring.gob, (si.RESIZE, self.on_sequence))

    def do(self):
        """
        Override the AnyGroup function so that Past's View Signal can be sent.
        """
        super(Rectangle, self).do()
        self.item.model.past.emit(si.RECTANGLE_VIEW, Run.x)

    def on_sequence(self, _, arg):
        """
        Update the Model immediately.

        _: AnyGroup
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
            not used
        """
        self.item.model.baby.feed(si.RECTANGLE_CHANGE, (self.value_d, True))

    def update_model(self, *_):
        """Update the Model as time permits."""
        self.item.model.baby.give(si.RECTANGLE_CHANGE, (self.value_d, False))


class Chi(Maya):
    """
    Rectangle has no layer output. Is a template for View Step processing.
    """
    issue_q = 'matter',
    vote_type = vo.MAIN

    def __init__(self, any_group, view_x):
        Maya.__init__(self, any_group, view_x, (), ())
        self.set_issue()

    def do(self):
        self.reset_issue()
