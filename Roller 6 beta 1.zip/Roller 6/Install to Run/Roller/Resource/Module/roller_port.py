#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color as co, Signal as si
from roller_constant_key import Widget as wk
from roller_one import reduce_color
from roller_one_ring import Ring
from roller_view import do_draft, do_peek, do_plan, do_preview
import gtk  # type: ignore


class Port(gtk.VBox, object):
    """Is a display container for Widget."""

    def __init__(self, d, g):
        """
        d: dict
            Has init variable.

        g: Widget or None
            Is responsible.
        """
        self.is_dirt = False
        self._pig = []
        self.roller_win = d[wk.ROLLER_WIN]
        self.repo = g

        super(gtk.VBox, self).__init__()
        self.color = co.INIT_COLOR

    def keep(self, q):
        """
        Put Widget reference into 'self._pig'. Keep the GTK
        garbage collection from removing Widget connection
        from the parent Window when a GTK Dialog is opened.

        q: iterable (tuple or list)
            Widgets
        """
        [self._pig.append(g) for g in q]

    def on_port_change(self, g):
        """
        A Widget changed. Respond to changes in the interface.

        g: Widget
            Is responsible.

        Return: True
            Let GTK know that the Signal is handled.
        """
        if g.any_group:
            # Update squishy interface.
            Ring.add(g.any_group, si.GROUP_CHANGE, None)

        Ring.plug(si.UI_CHANGE, g)
        return True

    def reduce_color(self):
        """Lower the red and green components of 'self.color'."""
        self.color = reduce_color(self.color)

    def task_view(self, g, view_x):
        """
        Create a View. Set the repo's value
        after fetching the Port's group value.

        Ports stack:
            main
                parent dialog
                    child dialog

        When a dialog is open, its value dict is passed to its
        parent Port. Eventually, the value dict arrives at
        the main AnyGroup and the View run is performed.

        g: Widget
            Is a View run-type Button.

        view_x: int
            Identify the View type.

        Return: True
            Let GTK know that the signal was handled.
        """
        repo = self.repo

        if repo:
            # There's an underlying Window/Port.
            value = self.get_group_value()
            x = view_x if view_x < 2 else view_x - 2

            repo.set_a(value, x=x)
            repo.roller_win.port.task_view(g, view_x)

        else:
            # The chain of Port is up-to-date.
            Ring.pressure()
            (
                do_plan,
                do_preview,
                do_draft,
                do_peek
            )[view_x]()
        return True
