#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_constant_key import Frame as ek, Material as ma, Option as ok
from roller_frame import do_embossed_frame
from roller_frame_alt import FrameBasic
from roller_fu import (
    add_layer, copy_all_image, create_image, select_rect
)
from roller_view_hub import (
    clipboard_fill, color_layer, color_selection, set_fill_context_default
)


def do_matter(maya):
    """
    Make a border around material.

    maya: Mecha
    Return: layer
        Mecha Wrap 'matter'
    """
    set_fill_context_default()
    return do_embossed_frame(maya, make_pattern)


def make_pattern(z, d):
    """
    Draw a rectangle on a rotated layer. Create a pattern
    (a black square). Use the clipboard to hold the
    pattern. Fill the provided layer with the pattern.

    z: layer
        to receive pattern

    d: dict
        Mecha Preset
        {Option key: value}

    Return: layer
        with the pattern
    """
    gap_w = d[ok.GAP_W]
    w = gap_w + d[ok.LINE_W]
    j1 = create_image(int(w), int(w))
    z1 = add_layer(j1, "Pattern")

    color_layer(z1, (255, 255, 255))

    # A rectangle at the center of 'z1' will become a hole in the pattern.
    x = y = d[ok.LINE_W] / 2.

    select_rect(j1, x, y, gap_w, gap_w)
    color_selection(z1, (0, 0, 0))

    # Set the Clipboard Image.
    copy_all_image(j1)

    pdb.gimp_image_delete(j1)
    clipboard_fill(z)
    pdb.plug_in_colortoalpha(z.image, z, (0, 0, 0))
    return z


class Mecha(FrameBasic):
    add_row = shade_row = ok.RW1
    filler_k = ok.FILLER_ME
    kind = ek.MECHA
    material = ma.MECHA
    wrap_k = ok.WRAP_PA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
