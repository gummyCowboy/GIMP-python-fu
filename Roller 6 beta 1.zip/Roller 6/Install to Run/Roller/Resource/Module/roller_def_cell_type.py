#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Issue as vo, Shape as sh
from roller_constant_key import Option as ok, Widget as wk
from roller_def_act import make_bool_tip
from roller_def_option import (
    BOX_TYPE,
    CELL_SHAPE_CELL,
    CELL_SIZE,
    FCI,
    GRID_COUNT,
    GRID_SIZE,
    GRID_TYPE,
    INWARD,
    MASK_SCALE,
    MAX_POLAR_X,
    MAX_POLAR_Y,
    PER,
    PIN
)
from roller_one_tip import Tip
from roller_widget_combo import ComboBox
from roller_widget_radio import SwitchRadio
from roller_widget_row_list import RowList
from roller_widget_slider import RowCountSlider


def get_equilateral_list():
    return sh.EQUILATERAL_LIST


def get_shape_list():
    return sh.SHAPE_LIST


# Type Box_____________________________________________________________________
TYPE_BOX = OrderedDict([
    (ok.BOX_TYPE, deepcopy(BOX_TYPE)),
    (ok.GRID_TYPE, deepcopy(GRID_TYPE)),
    (ok.PIN, deepcopy(PIN)),
    (ok.ROW_COUNT, deepcopy(GRID_COUNT)),
    (ok.COLUMN_COUNT, deepcopy(GRID_COUNT)),
    (ok.ROW_H, deepcopy(CELL_SIZE)),
    (ok.COLUMN_W, deepcopy(CELL_SIZE)),
    (ok.VERT_COUNT, deepcopy(GRID_COUNT)),
    (ok.HORZ_COUNT, deepcopy(GRID_COUNT)),
    (ok.FCI, deepcopy(FCI)),
    (ok.GRID_SIZE, deepcopy(GRID_SIZE))
])

# Type Cell____________________________________________________________________
TYPE_CELL = OrderedDict([
    (ok.CELL_SHAPE, deepcopy(CELL_SHAPE_CELL)),
    (ok.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE))
])
TYPE_CELL[ok.PARALLELOGRAM_SCALE][wk.VAL] = .7
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Type Pyramid_________________________________________________________________
TYPE_PYRAMID = OrderedDict([
    (ok.DIRECTION, {
        wk.COLUMN_TEXT: ok.DIRECTION,
        wk.ISSUE: vo.MATTER,
        wk.TEXT: ("Up", "Down"),
        wk.VAL: 0,
        wk.WIDGET: SwitchRadio
    }),
    (ok.ROW_COUNT, {
        wk.ISSUE: vo.MATTER,
        wk.LIMIT: (1, 100),
        wk.PAGE_INCR: 2,
        wk.VAL: 1.,
        wk.WIDGET: RowCountSlider
    }),
    (ok.COLUMN_COUNT_Q, deepcopy({
        wk.ISSUE: vo.MATTER,
        wk.VAL: [1],
        wk.WIDGET: RowList
    })),
])

# Type Sidewalk________________________________________________________________
TYPE_SIDEWALK = OrderedDict([
    (ok.ROW_COUNT, deepcopy(GRID_COUNT)),
    (ok.COLUMN_COUNT, deepcopy(GRID_COUNT)),
    (ok.INWARD, deepcopy(INWARD))
])

for i in (ok.ROW_COUNT, ok.COLUMN_COUNT):
    TYPE_SIDEWALK[i][wk.LIMIT] = 2, 100
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Type Stack___________________________________________________________________
TYPE_STACK = OrderedDict([
    (ok.CELL_SHAPE, deepcopy(CELL_SHAPE_CELL)),
    (ok.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE)),
    (ok.CELL_COUNT, deepcopy(GRID_COUNT)),
    (ok.ADD_OFFSET_X, deepcopy(MAX_POLAR_X)),
    (ok.ADD_OFFSET_Y, deepcopy(MAX_POLAR_Y))
])

for x, i in enumerate((ok.ADD_OFFSET_X, ok.ADD_OFFSET_Y)):
    TYPE_STACK[i].update({
        wk.AXIS: ('x', 'y')[x],
        wk.TOOLTIP: Tip.ADD_SHIFT_XY
    })
TYPE_STACK[ok.PARALLELOGRAM_SCALE][wk.VAL] = .7
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Type Table___________________________________________________________________
TYPE_TABLE = OrderedDict([
    (ok.GRID_TYPE, GRID_TYPE),
    (ok.CELL_SHAPE, {
        wk.FUNCTION: get_shape_list,
        wk.ISSUE: vo.MATTER,
        wk.VAL: sh.RECTANGLE,
        wk.WIDGET: ComboBox
    }),
    (ok.ECS, {
        wk.FUNCTION: get_equilateral_list,
        wk.ISSUE: vo.MATTER,
        wk.VAL: sh.SQUARE,
        wk.WIDGET: ComboBox
    }),
    (ok.PIN, deepcopy(PIN)),
    (ok.ROW_COUNT, deepcopy(GRID_COUNT)),
    (ok.COLUMN_COUNT, deepcopy(GRID_COUNT)),
    (ok.ROW_H, deepcopy(CELL_SIZE)),
    (ok.COLUMN_W, deepcopy(CELL_SIZE)),
    (ok.VERT_COUNT, deepcopy(GRID_COUNT)),
    (ok.HORZ_COUNT, deepcopy(GRID_COUNT)),
    (ok.FCI, deepcopy(FCI)),
    (ok.GRID_SIZE, deepcopy(GRID_SIZE)),
    (ok.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE)),
    (ok.PER, deepcopy(PER))
])
TYPE_TABLE[ok.PARALLELOGRAM_SCALE][wk.VAL] = .7
