#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import GRADIENT_BLEND_RGB_PERCEPTUAL, pdb   # type: ignore
from roller_a_contain import Run
from roller_a_gegl import unsharp_mask
from roller_constant_for import Frame as ff, Gradient as fg
from roller_constant_key import Frame as ek, Material as ma, Option as ok
from roller_frame import do_selection_material, grow_frame
from roller_frame_alt import FrameBasic
from roller_fu import blur_selection, get_select_coord
from roller_view_hub import set_fill_context_default, set_gimp_gradient


def do_matter(maya):
    """
    Make a frame.

    maya: Burst
    Return: layer
        with the frame
    """
    # Burst Preset dict, 'd'
    d = maya.value_d

    set_fill_context_default()
    set_gimp_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(d[ok.RW1][ok.REVERSE])
    return do_selection_material(maya, do_sel, embellish, "Material")


def do_sel(maya, z):
    """
    Do the Frame for a selection.

    maya: Maya

    z: layer
        to receive frame

    Return: layer
        with frame material
    """
    # Burst Preset dict, 'd'
    d = maya.value_d

    grow_frame(Run.j, d[ok.WIDTH], ff.RECTANGLE)

    x, y, x1, y1 = get_select_coord(Run.j)

    pdb.gimp_drawable_edit_gradient_fill(
        z,
        fg.GRADIENT_TYPE_LIST.index(d[ok.SHAPED_TYPE]),
        0,                                         # offset
        1,                                         # yes, super-sample
        3,                                         # maximum super-sample depth
        .0,                                        # super-sample threshold
        1,                                         # yes, dither
        (x1 + x) / 2., (y1 + y) / 2.,              # start point
        x, y                                       # end point
    )
    return z


def embellish(maya, z):
    """
    Modify the frame material.

    maya: Burst
    z: layer
        Has the frame.

    Return: layer
        with the frame
    """
    # Burst Preset dict, 'd'
    d = maya.value_d

    pdb.gimp_selection_none(Run.j)

    if d[ok.UNSHARP_AMOUNT] and d[ok.UNSHARP_RADIUS]:
        unsharp_mask(z, d[ok.UNSHARP_RADIUS], d[ok.UNSHARP_AMOUNT], .0)
        blur_selection(z, 1)

    if d[ok.RW1][ok.INVERT]:
        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)
    return z


class Burst(FrameBasic):
    add_row = shade_row = ok.BRW
    kind = ek.BURST
    material = ma.BURST
    wrap_k = ok.WRAP_BU

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
