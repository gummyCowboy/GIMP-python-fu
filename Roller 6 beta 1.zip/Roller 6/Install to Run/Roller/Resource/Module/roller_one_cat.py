#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_one_the import The
import gimpfu as fu
import gobject

pdb = fu.pdb


class Cat(object):
    """Hold the center. Has program scope variable."""
    # Are the color palette settings at startup. Use with FG and BG gradient.
    # RGBA; (float, float, float, float); .0 to 1.
    # gimpcolor
    is_frozen = background = foreground = None

    # RenderImage
    _view_image = None

    # GIMP brush
    brush_list = []

    # GIMP font
    font_list = []

    # GIMP gradient
    gradient_list = []

    # GIMP pattern
    pattern_list = []

    def __init__(self):
        """Initialize variables."""

        # GIMP brush
        Cat.brush_list = sorted(pdb.gimp_brushes_get_list(None)[1])

        # GIMP font
        Cat.font_list = sorted(pdb.gimp_fonts_get_list(None)[1])

        # GIMP gradient
        Cat.gradient_list = sorted(pdb.gimp_gradients_get_list(None)[1])

        # GIMP pattern
        Cat.pattern_list = sorted(pdb.gimp_patterns_get_list(None)[1])

    @property
    def render(self):
        """
        Get the ViewImage or create one.

        Return: ViewImage
            Has the View image.
        """
        if not Cat._view_image:
            Cat._view_image = ViewImage()
        return Cat._view_image

    @render.setter
    def render(self, *_):
        """Is an invalid access."""
        raise AttributeError("Unable to write to variable 'render'.")


class ViewImage(gobject.GObject, object):
    """Use to create and change the render image."""
    __gsignals__ = si.IMAGE_D

    def __init__(self):
        """Init for a new View image."""
        self._image = self.has_image = self._display = None
        gobject.GObject.__init__(self)

    def get_image(self):
        """
        Fetch the View's GIMP image.

        Return: GIMP image or None
        """
        return self._image

    def image(self):
        """
        Get the View's image. If it doesn't exist, then create it.

        Return: GIMP image
            Is from a View op or a new image made due to size change.
        """
        if self._image:
            return self._image
        return self.new_image(*The.view.view_size)

    def new_image(self, w, h):
        """
        Get the View's image. If it doesn't exist, then create one first.

        w, h: numeric
            new image size

        Return: GIMP image
            Is from a View op or a new image made due to size change.
        """
        # Is manipulated by Work's and Plan's 'do' function, 'is_frozen'.
        is_frozen = Cat.is_frozen

        if self._image:
            # The View image is the wrong size.
            self.emit(si.CLOSE_VIEW_IMAGE, self._image)

            if is_frozen:
                # the image needs to be thawed in order to keep the balance.
                pdb.gimp_image_thaw_layers(self._image)
            pdb.gimp_display_delete(self._display)

        j = self._image = pdb.gimp_image_new(int(w), int(h), fu.RGB)

        # Show in GIMP:
        self._display = pdb.gimp_display_new(j)

        if is_frozen:
            # Reproduce the frozen state of the previous image.
            pdb.gimp_image_freeze_layers(j)

        # Turn off undo functionality to save
        # memory and to improve performance.
        pdb.gimp_image_undo_disable(j)

        self.has_image = True
        return j


# Register the custom signals.
gobject.type_register(ViewImage)
