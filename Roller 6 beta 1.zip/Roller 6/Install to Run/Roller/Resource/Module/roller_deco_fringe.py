#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from roller_a_contain import Deco, Run
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    add_group_type,
    make_deco_material,
    paint,
    prep_below_type,
    produce_per_facing,
    produce_main_facing,
    ready_canvas_rect,
    ready_shape,
    test_image,
    transform_foam
)
from roller_fu import (
    add_layer,
    clear_inverse_selection,
    remove_z,
    select_item,
    select_polygon,
    select_rect,
    select_shape,
    verify_layer,
    verify_layer_group
)
from roller_view_hub import do_mod
from roller_view_real import get_light


def add_fringe_layer(maya, j, group, n):
    """
    Fringe's select polygon requires view-sized layer.

    Return: layer
        newly added
    """
    return add_layer(j, group.name + " " + n, group, offset=get_light(maya))


def do(maya, make):
    """
    Make Fringe material. If Plan is active, it
    makes temporary adjustment to the option settings.

    maya: Maya
    make: function
        Call to create Fringe layer.

    Return: layer or None
        matter
    """
    d = maya.value_d

    if not Run.x:
        # Preserve.
        type_ = d[ok.TYPE]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = {
            ny.CELL: fy.CELL_FRINGE_COLOR,
            ny.CANVAS: fy.CANVAS_FRINGE_COLOR,
            ny.FACE: fy.FACE_FRINGE_COLOR,
            ny.FACING: fy.FACE_FRINGE_COLOR
        }[maya.any_group.render_key[-2]]

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.RW1][ok.MOD])

    if not Run.x:
        # Restore.
        d[ok.TYPE] = type_
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Make Fringe for the Canvas branch.

    maya: Maya
    Return: layer or None
        with Canvas Fringe material
    """
    return do(maya, make_canvas)


def do_cell(maya):
    """
    Make Fringe for Cell/Per.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell)


def do_face(maya):
    """
    Draw Face/Per Fringe.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell_face)


def do_facing(maya):
    """
    Draw Facing/Per Fringe.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell_facing)


def do_main_cell(maya):
    """
    Make Cell branch Fringe for main option settings.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main)


def do_main_face(maya):
    """
    Draw Fringe Face for the main option settings.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main_face)


def do_main_facing(maya):
    """
    Draw Fringe Face for the main option settings.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main_facing)


def make_canvas(maya, d):
    """
    Draw Canvas Fringe material.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        with Fringe material
    """
    if test_image(maya, d):
        prep_below_type(d, maya.group)
        ready_canvas_rect(maya, d)
        return verify_layer(paint_fringe(maya, d, maya.group))


def make_cell(maya, d):
    """
    Make Fringe for Cell/Per.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        with material
    """
    if test_image(maya, d):
        prep_below_type(d, maya.group)
        ready_shape(maya, d)
        return verify_layer(paint_fringe(maya, d, maya.group))


def make_cell_face(maya, d):
    """
    Make Fringe for Face/Per.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        with material
    """
    return produce_per_facing(maya, d, make_face)


def make_cell_facing(maya, d):
    """
    Make Fringe for Facing/Per.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        with material
    """
    return produce_per_facing(maya, d, make_facing)


def make_face(maya, d, group):
    """
    Create Face material.

    maya: Maya
    d: dict
        Fringe Preset

    group: layer
        Is the destination parent layer of Face output.
    """
    k = maya.k
    model = maya.model
    go = test_image(maya, d)
    if go:
        maya.rect = model.get_facing_rect(k)
        Deco.shape = model.get_facing_form(k)
        z = paint_fringe(maya, d, group)
        if z:
            transform_foam(maya.rect, z, model.get_facing_foam(k))


def make_facing(maya, d, group):
    """
    Create cell Facing material.

    maya: Maya
    d: dict
        Fringe Preset

    group: layer or None
        Is the destination parent layer of Facing output.
    """
    j = Run.j
    k = maya.k
    model = maya.model
    go = test_image(maya, d)
    if go:
        maya.rect = model.get_facing_rect(k)
        n = d[ok.TYPE]

        if n in (dc.MEAN_COLOR, dc.COLOR):
            is_color = True
            Deco.shape = model.get_facing_shape(k)
            select_polygon(j, Deco.shape)

        else:
            Deco.shape = model.get_facing_form(k)
            is_color = False
            select_rect(Run.j, *maya.rect)

        # The As Is Fringe Type doesn't create a layer.
        z = make_deco_material(maya, d, group)

        if z and not is_color:
            z = transform_foam(maya.rect, z, model.get_facing_foam(k))

        z1 = add_fringe_layer(maya, j, group, n)

        select_shape(j, model.get_facing_shape(k))

        paint(z1, d)
        model.clip_facing(z1, k)
        select_item(z1)

        if n in (dc.AS_IS, dc.MULTI_COLOR):
            remove_z(z)
        else:
            if z:
                clear_inverse_selection(z)
            remove_z(z1)


def make_main(maya, d):
    """
    Create Cell branch Fringe for the main option settings.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        with material
    """
    def _do_many_material():
        """
        The cells have the same Fringe material, but
        the material has to be applied cell-by-cell.
        """
        for _k in maya.main_q:
            maya.k = _k
            if test_image(maya, d):
                ready_shape(maya, d)
                paint_fringe(maya, d, group)
        return verify_layer_group(group)

    def _do_one_material():
        """
        The cells have the same Fringe material,
        so the output is combined on one layer.
        """
        for _k in maya.main_q:
            _z = add_fringe_layer(maya, j, group, "Material")
            maya.k = _k

            ready_shape(maya, d)
            paint(_z, d)

        _z = verify_layer_group(group)
        prep_below_type(d, parent)
        if _z:
            select_item(_z)
            return verify_layer(paint_fringe(maya, d, parent, z=_z))

    j = Run.j
    parent = maya.group
    group = add_group_type(maya, d)
    n = d[ok.TYPE]

    if n not in dc.PER_TYPE:
        # All the Fringe is the same
        # material and is applied one time.
        return _do_one_material()
    else:
        return _do_many_material()


def make_main_face(maya, d):
    """
    Create Fringe material for the main option settings.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        with material
    """
    return produce_main_facing(maya, d, make_face)


def make_main_facing(maya, d):
    """
    Create Fringe material for the main Facing option settings.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        with material
    """
    return produce_main_facing(maya, d, make_facing)


def paint_fringe(maya, d, group, z=None):
    """
    Paint Fringe and apply material.

    maya: Maya
    d: dict
        Fringe Preset

    group: layer
        Is the destination parent of Fringe output.

    z: layer
        The layer has Fringe material.

    Return: layer or None
        with Fringe material
    """
    j = Run.j
    type_ = d[ok.TYPE]

    if not z:
        z = add_fringe_layer(maya, j, group, type_)

        select_shape(j, Deco.shape)
        paint(z, d)

    if type_ not in (dc.AS_IS, dc.MULTI_COLOR):
        n = z.name

        select_item(z)
        pdb.gimp_image_remove_layer(j, z)

        z = make_deco_material(maya, d, group)
        if z:
            z.name = n
    return z
