#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_key import Option as ok
from roller_fu import merge_layer_group
from roller_maya_style import Style
from roller_view_hub import do_mod
from roller_view_real import (
    add_sub_base_group, do_gradient_for_layer, finish_style
)


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: GradientFill
    Return: layer or None
        with Gradient Fill material
    """
    d = maya.value_d
    e = deepcopy(d)
    e[ok.GRADIENT] = d[ok.RW1][ok.GRADIENT]
    parent = add_sub_base_group(maya)

    do_gradient_for_layer(e, parent, 0)

    z = merge_layer_group(parent)

    do_mod(z, d[ok.RW1][ok.MOD])
    return finish_style(z, "Gradient Fill")


class GradientFill(Style):
    """Create Backdrop Style output."""
    is_dependent = False

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.RW1,),
                k_path + (ok.RW1, ok.MOD)
            ],
            make_style
        )
