#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_BURN,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_LIGHTEN_ONLY,
    pdb
)
from roller_a_contain import Globe, Run
from roller_constant_key import Option as ok
from roller_fu import clone_layer, merge_layer_group
from roller_maya_style import Style, make_background
from roller_view_hub import do_mod
from roller_view_real import add_sub_base_group, finish_style

LAYER_NUM = "{} of {}"


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: Rainbow Valley
    Return: layer
        with the style material
    """
    def _noise():
        """Adds noise to a layer."""
        if power:
            pdb.plug_in_solid_noise(
                j, z,
                0,                      # no tile-able
                1,                      # yes, turbulent
                seed_,
                7,                      # medium detail
                2.,                     # horizontal size
                2.                      # vertical size
            )

            # medium holdness, '4'
            pdb.plug_in_hsv_noise(j, z, 4, power, power, power)

    # Is dependent.
    if maya.go:
        j = Run.j
        d = maya.value_d
        parent = add_sub_base_group(maya)
        z = make_background(parent)
        seed_ = int(d[ok.SEED] + Globe.seed)
        is_texture = d[ok.TEXTURE]
        power = int(d[ok.POWER])

        # layer counter, 'x'
        x = 1

        # total layers to make, 'a'
        a = 15

        a += 8 if is_texture else 7

        for i in range(10):
            z = clone_layer(z, n=LAYER_NUM.format(x, a))
            z.mode = LAYER_MODE_DIFFERENCE

            pdb.plug_in_despeckle(j, z, i, 0, 0, 255)

            if i % 2:
                x += 1
                z = clone_layer(z, n=LAYER_NUM.format(x, a))
                z.mode = LAYER_MODE_LIGHTEN_ONLY

                _noise()

                seed_ += 1

                pdb.plug_in_despeckle(j, z, i, 0, 0, 255)
                z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

            is_engrave = False

            if is_texture:
                if i < 7 or i == 9:
                    is_engrave = True

            elif i < 7:
                is_engrave = True

            if is_engrave:
                x += 1
                z = clone_layer(z, n=LAYER_NUM.format(x, a))

                pdb.plug_in_engrave(j, z, max(i, 2), 1)

                z.mode = LAYER_MODE_BURN
                z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
                pdb.plug_in_wind(
                    j, z,
                    0,              # threshold
                    2,              # from top
                    50,             # strength
                    1,              # blast
                    1               # leading edge
                )
            x += 1

        z = merge_layer_group(parent)

        do_mod(z, d[ok.BRW][ok.MOD])
        return finish_style(z, "Rainbow Valley")


class RainbowValley(Style):
    """Create Backdrop Style output."""
    is_seeded = is_dependent = True

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.BRW, ok.MOD)],
            make_style
        )
