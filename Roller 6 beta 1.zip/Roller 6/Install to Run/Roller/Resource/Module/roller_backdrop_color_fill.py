#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import FOREGROUND_FILL, pdb  # type: ignore
from roller_constant_key import Option as ok
from roller_fu import merge_layer_group
from roller_maya_style import Style, make_background
from roller_view_hub import do_mod, get_canvas_points, set_fill_context
from roller_view_real import add_sub_base_group, finish_style


def make_style(maya):
    """
    Make a style layer.

    maya: Style
    Return: layer or None
        style layer
    """
    # Is dependent.
    if maya.go:
        d = maya.value_d
        parent = add_sub_base_group(maya)
        z = make_background(parent)

        # RGBA, 'q'
        q = d[ok.COLOR_1A]

        # Use to set the opacity context for bucket fill.
        d[ok.FILL_OPACITY] = q[3] / 255. * 100.

        # fill point, 'x, y'
        x, y = get_canvas_points(d)[:2]

        set_fill_context(d)
        pdb.gimp_context_set_foreground(q)
        pdb.gimp_drawable_edit_bucket_fill(z, FOREGROUND_FILL, x, y)

        z = merge_layer_group(parent)

        do_mod(z, d[ok.BRW][ok.MOD])
        return finish_style(z, "Color Fill")


class ColorFill(Style):
    """Create Backdrop Style output."""
    is_dependent = True

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
