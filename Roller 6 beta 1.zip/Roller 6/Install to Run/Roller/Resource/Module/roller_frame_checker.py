#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_backdrop_color_grid import draw_color_grid
from roller_constant_key import (
    BackdropStyle as by, Frame as ek, Material as ma, Option as ok
)
from roller_frame import do_embossed_frame
from roller_frame_alt import FrameBasic
from roller_def import get_default_value
from roller_one_render import Render


def do_matter(maya):
    """
    Make a frame.

    maya: Checker
    Return: layer
        with the frame
    """
    return do_embossed_frame(maya, make_pattern)


def make_pattern(z, d):
    """
    Make a black and white rectangle pattern.

    z: layer
        to receive pattern

    d: dict
        Checker Preset
        {Option key: value}

    Return: layer
        Checker pattern for selecting
    """
    j = Render.provide()

    pdb.gimp_selection_none(j)

    e = get_default_value(by.COLOR_FILL)

    e.update(d)

    z = draw_color_grid(z, e)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    return z


class Checker(FrameBasic):
    add_row = shade_row = ok.RW1
    filler_k = ok.FILLER_CH
    kind = ek.CHECKER
    material = ma.CHECKER
    wrap_k = ok.WRAP_PA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
