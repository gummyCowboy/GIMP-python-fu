#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from random import randint, seed
from roller_image_effect_border_line import BorderLine
from roller_image_effect import ImageEffect, LayerKey
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

ek = ImageEffect.Key
hs = Fu.HueSaturation
pdb = fu.pdb


class StainedGlass(BorderLine):
    """Create a frame with colorful transparent glass."""

    def __init__(self, one):
        """
        Do the Stained Glass image-effect.

        one: One
            Has variables.
        """
        seed(one.d[ok.RANDOM_SEED])
        BorderLine.__init__(self, one, filler=self.do_job)

    def do_job(self, z, d):
        """
        Receive task from BorderLine to draw glass.

        z: layer
            no use

        d: dict
            Has options.
        """
        stat = self.stat
        j = stat.render.image
        z = RenderHub.do_rotated_layer(stat, z, d, StainedGlass.draw_glass_panes)
        z.name = Lay.get_layer_name(LayerKey.FILLER, parent=self.parent)
        e = deepcopy(d)
        e[ok.ROTATE] = randint(-45, 0)
        z1 = RenderHub.do_rotated_layer(stat, z, e, StainedGlass.draw_glass_panes)
        z1.mode = fu.LAYER_MODE_DIFFERENCE
        z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
        z.opacity = 66.
        pdb.gimp_drawable_hue_saturation(
            z,
            fu.HUE_RANGE_ALL,
            hs.HUE_OFFSET_0,
            hs.LIGHTNESS_0,
            hs.SATURATION_MINUS_35,
            hs.OVERLAP_0
        )

        Sel.isolate(j, z, self.fill_sel)
        return z

    @staticmethod
    def draw_glass_panes(j, z, d):
        """
        Draw the glass panes.

        j: GIMP image
            work-in-progress

        z: layer
            to receive glass panes

        d: dict
            Has options.

        Return: layer
            the glass layer
        """
        return RenderHub.draw_color_rectangles(
            j,
            z,
            d[ok.PANE_WIDTH],
            d[ok.PANE_HEIGHT]
        )
