#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_cell import Cell
from roller_format_form import Form
from roller_one_base import Base
from roller_one_constant import (
    CaptionKey as ck,
    ForCell,
    ForColor,
    ForFormat as ff,
    FormatKey as fk,
    ForWidget as fw,
    FringeKey as fr,
    ImageKey as ik,
    MaskKey as ma,
    OptionKey as ok,
    PlaceKey as pl,
    PlaqueKey as pq,
    PortCellKey,
    PortKey,
    PropertyKey as pr,
    UIKey,
    WidgetKey,
)
from roller_one_tip import Tip
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_button import ColoredButton, SwitchButton
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_window_cell_mod import RollerWindowCellMod
import gtk

HEADER_COLOR = ForColor.HEADER_COLOR
MERGE_KEY = fk.Cell.Grid.PER_CELL
TRY = ". Try escape, enter, space bar to close, save, edit."

# cell padding:
PAD = 1
PADDING = [PAD, PAD, PAD, PAD]
H_PAD = [0, 0, PAD, PAD]
V_PAD = [PAD, PAD, 0, 0]


class PortCell(Port):
    """Has a table of cell(s) corresponding with a format cell grid."""

    PAD = PAD

    def __init__(self, d):
        """
        Create a cell port.

        d: dict
            with init values
        """
        k = self.key = d[WidgetKey.KEY]
        self._per_cell_check_button = d[PortCellKey.PER_CELL_BUTTON]
        self.get_format_info = d[UIKey.GET_FORMAT_INFO]
        self.roller_window = d[UIKey.WINDOW]
        self.split_cells = False
        d[UIKey.WINDOW_TITLE] = ForCell.CELL_TABLE_DICT[k]['name'] + TRY
        d[UIKey.PORT_KEY] = PortKey.CELL
        self.form, self._format_x = self.get_format_info()
        self.is_merge = 1 if k == fk.Cell.Grid.PER_CELL else 0
        self.is_not_merge = not self.is_merge
        self.merged = Form.is_merge_cells(self.form)
        self.place_widget = []
        self.stat = d[UIKey.STAT]
        n = self.form[fk.Cell.Grid.CELL_GRID][fk.Cell.Grid.SHAPE]
        self.is_double = Form.is_double_space(self.form)
        self.is_rectangle = n == ff.Cell.Shape.RECTANGLE
        session = d[UIKey.GET_SESSION_DICT]()
        self._cell_tooltip_dict = {
            fk.Cell.Caption.PER_CELL: self._set_caption_tooltip,
            fk.Cell.Fringe.PER_CELL: self._set_fringe_tooltip,
            fk.Cell.Image.Mask.PER_CELL: self._set_image_mask_tooltip,
            fk.Cell.Image.Place.PER_CELL: PortCell._set_place_tooltip,
            fk.Cell.Image.Property.PER_CELL: PortCell._set_property_tooltip,
            fk.Cell.Margin.PER_CELL: PortCell._set_margin_tooltip,
            fk.Cell.Plaque.PER_CELL: self._set_plaque_tooltip
        }
        self._set_sub_fringe_tooltip = {
            ff.Fringe.GRADIENT:  PortCell._set_fringe_gradient_tooltip,
            ff.Fringe.IMAGE: PortCell._set_fringe_image_tooltip,
            ff.Fringe.MASK: PortCell._set_fringe_mask_tooltip,
            ok.NONE: PortCell._set_no_fringe_tooltip,
            ff.Fringe.ONE_COLOR: PortCell._set_fringe_one_color_tooltip,
            ff.Fringe.PATTERN: PortCell._set_fringe_pattern_tooltip,
            ff.Fringe.TWO_COLOR: PortCell._set_fringe_two_color_tooltip
        }

        self.stat.layout.calc_cell_table(session)

        # Plaque and fringe don't require an image:
        r, c = self.rows, self.columns = self.stat.layout.get_division(
            self._format_x
        )

        self._init_table()

        w = max(r, c)
        self._more = max(5, w)

        if w < 10:
            size = 500 // w

        elif w < 15:
            size = 50

        else:
            size = 25

        self.cell_height = size
        Port.__init__(self, d)
        self._show_port()

    @staticmethod
    def _calc_bottom_right(cell):
        """
        Return the row and column for the
        bottom-right cell of a merged cell group.

        cell: Cell
            from a topleft cell
        """
        return cell.r + cell.s[0] - 1, cell.c + cell.s[1] - 1

    def _draw_cell(self, r, c):
        """
        Call for each cell.

        Is part of the PortCell template.

        r, c: int (0..n)
            row, column
            cell position
        """
        cell = self.table[r][c]
        start, end = self._get_topleft(cell=cell).start_end_of_top
        self._set_cell_looks(cell, start, end)
        if not self.is_merge:
            m = 0

            if cell.has_pic:
                m = 1

            elif cell.is_topleft:
                m = 1
            if m:
                self.set_tooltip(cell.box, self.form[self.key][cell.r][cell.c])

    def _draw_cell_mod_window(self, g):
        """
        Draw a cell modification window.

        g: ColorButton
            Has row and column info.
        """
        self.row, self.column = g.r, g.c
        RollerWindowCellMod(
            {
                PortCellKey.CELL_TABLE: self.table,
                PortCellKey.SET_TOOLTIP: self.set_tooltip,
                PortCellKey.TABLE_SIZE: (self.rows, self.columns),
                WidgetKey.KEY: self.key,
                UIKey.FORMAT_INDEX: self._format_x,
                UIKey.FORMAT_DICT: self.form,
                UIKey.WINDOW: self.roller_window.win,
                UIKey.STAT: self.stat,
                UIKey.WINDOW_TITLE: ForCell.CELL_TABLE_DICT[self.key]['name'] +
                " Cell Editor"
            },
            g.r, g.c
        )

    def _draw_column_header(self, c, c1):
        """
        Draw a column header.

        c: int
            table column

        c1: int
            actual column
        """
        # column header:
        g = RollerEventBox(HEADER_COLOR)
        g1 = gtk.Frame()

        if c % 2:
            g2 = self.col_label = RollerLabel(align=(0, 0, 1, 1), text=str(c1))
            g1.add(g2)

        g.add(g1)
        return g

    def _draw_connector(self, r, c):
        """
        Draw connector button.

        r, c: int
            row, column
        """
        # connector button:
        if r % 2:
            # left button:
            p = self.split_horz, self.connect_left
            r3, c3 = r, c + 1
            r4, c4 = r // 2, c // 2 - 1
            q = (PortCell.PAD, PortCell.PAD, 0, 0)

        else:
            # upper button:
            p = self.split_vert, self.connect_up
            r3, c3 = r + 1, c
            r4, c4 = r // 2 - 1, c // 2
            q = (0, 0, PortCell.PAD, PortCell.PAD)

        g = RollerBox(gtk.HBox, align=(0, 0, 1, 1), padding=q)
        g1 = self.buttons[r4][c4] = SwitchButton(
            "+", p, r3, c3, g, self.table, ForColor.CONNECTOR_COLOR)

        g1.set_size(8, 8)
        return g, g1

    def _draw_first_cell(self, g, vbox):
        """
        Draw the first cell in the cell table.

        The size of the first cell will be the
        size of every cell in the table.

        'self.win.show_all' causes the 'vbox' allocation to be
        calculated which will fail ScrolledWindow's dependency.
        So calculate the scroll region-size manually.

        g: cell widget
            event box or colored button

        vbox: VBox
            container for widgets

        Return:
            the width of the cell in pixels
            of int
        """
        rows, columns = self.rows, self.columns

        self.roller_window.win.show_all()

        # scale:
        w = max(g.allocation.width, g.allocation.height, self.cell_height)
        w1, h = w * columns, w * rows
        w2 = self.row_label.allocation.width
        h1 = self.col_label.allocation.height
        button_w = 0 if self.is_not_merge else 15 * (columns - 1)
        button_h = 0 if self.is_not_merge else 15 * (rows - 1)
        pad_w = 4 * columns
        pad_h = 4 * rows
        extra_w, extra_h = self.table_row, self.table_column
        extra = self._more
        extra += 15 if self.is_not_merge == 3 else 0

        # sum:
        w1 += w2 + pad_w + button_w + extra_w + fw.SCROLL_SPAN + extra
        h += h1 + pad_h + button_h + extra_h + fw.SCROLL_SPAN + extra
        w1, h = self.roller_window.get_remaining_dim(w1, h)

        vbox.set_size_request(w1, h)
        return w

    def _draw_row_header(self, r, r1):
        """
        Draw row header.

        r: int
            table row

        r1: int
            row number
        """
        # row header:
        g = RollerEventBox(HEADER_COLOR)
        g1 = gtk.Frame()

        if r % 2:
            g2 = self.row_label = RollerLabel(align=(0, 0, 1, 1), text=str(r1))
            g1.add(g2)

        g.add(g1)
        return g

    def _generate_group(self, slices):
        """
        Slices organize themselves into one or more groups.

        A slice is a cell group with a piece of itself
        removed by a 'connect_up' or 'connect_left' process
        and the consuming merge group.

        slices: dict
            of dictionaries where each defines a group of cells
        """
        for k in slices:
            # Sort the two possible groups into a
            # larger and a smaller group (short).
            # The larger group will have the greater cell count.
            # The smaller group will be the cells not in the larger group.
            # If there's only one group,
            # the smaller group is not initialized.
            #
            # Starts by finding the longer and shorter row.
            u = slices[k]['size']
            long_row_width = long_row_height = 0
            long_col_width = long_col_height = 0
            short_col_width = short_row_height = 0
            short_row_width = short_col_height = 0
            start_long_row = [0, 0]
            start_short_row = [0, 0]
            start_long_col = [0, 0]
            start_short_col = [0, 0]

            # The key is the topleft coordinate (r, c):
            for r in range(k[0], k[0] + u[0]):
                row_width = 0
                first_col = -1

                for c in range(k[1], k[1] + u[1]):
                    if self._is_vector(k, r, c):
                        row_width += 1
                        if first_col < 0:
                            first_col = c

                    elif row_width:
                        break

                if row_width > long_row_width:
                    if long_row_width > 0:
                        # Second group inherits from the first group:
                        short_row_width = long_row_width
                        short_row_height = long_row_height
                        start_short_row = start_long_row

                    # Initialize first group:
                    long_row_width = row_width
                    long_row_height = 1
                    start_long_row = r, first_col

                elif row_width:
                    # The vector is long or short:
                    if row_width == long_row_width:
                        long_row_height += 1

                    else:
                        if short_row_height:
                            # Add another row:
                            short_row_height += 1

                        else:
                            # Initialize second group:
                            short_row_width = row_width
                            start_short_row = r, first_col
                            short_row_height = 1

            # Start finding the long and short column:
            for c in range(k[1], k[1] + u[1]):
                col_height = 0
                first_row = -1

                for r in range(k[0], k[0] + u[0]):
                    if self._is_vector(k, r, c):
                        col_height += 1
                        if first_row < 0:
                            first_row = r

                    elif col_height:
                        break

                if col_height > long_col_height:
                    if long_col_height > 0:
                        # Second group inherits from the first group:
                        short_col_width = long_col_width
                        short_col_height = long_col_height
                        start_short_col = start_long_col

                    # Initialize first group:
                    long_col_height = col_height
                    long_col_width = 1
                    start_long_col = first_row, c

                elif col_height:
                    # The vector is long or short:
                    if col_height == long_col_height:
                        long_col_width += 1

                    else:
                        if short_col_height:
                            short_col_width += 1

                        else:
                            # Initialize second group:
                            short_col_width = 1
                            short_col_height = col_height
                            start_short_col = first_row, c

            row_cells = long_row_width * long_row_height
            col_cells = long_col_height * long_col_width
            v = 0

            if row_cells >= col_cells:
                u = long_row_height, long_row_width
                cell = self.table[start_long_row[0]][start_long_row[1]]

                # Process second group if it was initialized:
                if short_row_width > 0:
                    v = short_row_height, short_row_width
                    cell1 = self.table[
                        start_short_row[0]][start_short_row[1]]

            else:
                u = long_col_height, long_col_width
                cell = self.table[start_long_col[0]][start_long_col[1]]

                # Process second group if it was initialized:
                if short_col_height > 0:
                    v = short_col_height, short_col_width
                    cell1 = self.table[
                        start_short_col[0]][start_short_col[1]]

            self._set_group(cell, u)

            # Set the second group if there was one:
            if v:
                self._set_group(cell1, v)

    def _get_topleft(self, cell=None, u=None):
        """
        Topleft is the cell located at the topleft of a cell group.

        Sub-topleft cells refer to the topleft
        cell through a topleft attribute.

        cell: Cell
            Has cell data.

        u: tuple
            row, column

        Return: Cell
            a topleft cell
        """
        if u:
            cell = self.table[u[0]][u[1]]

        if cell.s[0] < 0:
            cell1 = cell.topleft
            v = cell1.r, cell1.c

        else:
            v = cell.r, cell.c
        return self.table[v[0]][v[1]]

    def _has_pic(self, r, c):
        """
        Determine if a cell has a picture.

        r, c: int
            cell coordinate
            row, column

        Return: flag
            It's true when there is an image assigned to the cell.
        """
        m = 1

        # Is there an image?
        if self.key != fk.Cell.Image.Place.PER_CELL:
            m = Form.get_place(
                self.form,
                r,
                c
            )[pl.IMAGE_DICT][ik.IMAGE_REF] != ok.NONE

        # zero opacity:
        if m:
            if self.key != fk.Cell.Image.Property.PER_CELL:
                m = Form.get_image_property(self.form, r, c)[pr.OPACITY] != 0

        # Hexagonal shaped cells have missing cells:
        if m:
            m = self.table[r][c].is_cell
        return m

    def _init_table(self):
        """Set the initial data needed to draw cells."""
        d = self.form
        row, col = self.rows, self.columns
        self.table = Base.create_2d_table(row, col)

        # Load cell dimensions:
        for r in range(row):
            for c in range(col):
                if self.merged:
                    s = d[MERGE_KEY][r][c]

                else:
                    s = 1, 1

                is_cell = 1

                if self.is_double:
                    is_cell = Form.is_double_space_cell(
                        r,
                        c,
                        self.is_double
                    )
                self.table[r][c] = Cell(s, r, c, is_cell)

        # Initialize topleft references:
        for r in range(row):
            for c in range(col):
                cell = self.table[r][c]
                if cell.is_topleft:
                    # Initialize sub-topleft cells:
                    for r1 in range(r, r + cell.s[0]):
                        for c1 in range(c, c + cell.s[1]):
                            if r1 != r or c1 != c:
                                a = self.table[r1][c1]
                                a.topleft = cell

    @staticmethod
    def _is_outside(cell, r, c, s):
        """
        Determine if a cell has cells that
        exist outside the bounds of a rectangle.

        cell: Cell
            Has cell data.

        r, c: int
            row, column

        s: tuple (w, h)
            bounds

        Return: flag
            Is true if the cell or its group has
            cells outside of the rectangle.
        """
        if cell.r < r or \
                cell.c < c or \
                cell.r + cell.s[0] > r + s[0] or \
                cell.c + cell.s[1] > c + s[1]:
            return 1

    def _is_vector(self, u, r, c):
        """
        Determine if a cell (r, c) is still
        referencing a topleft cell at 'u'.

        u: tuple
            (row, column)

        Return: flag
            Is true if the topleft cell is still referenced.
        """
        # Get cell dict:
        cell = self.table[r][c]

        # Independent cells are not part of a vector:
        if cell.is_group:
            a = self._get_topleft(cell)

            # Cell must refer to its old top:
            if a.r == u[0] and a.c == u[1]:
                return 1

    def _make_cell_button(self, r, c):
        """
        Make a ColoredButton and add its cell coordinates to the button.

        r, c: int
            row, column
            cell position

        Return: ColoredButton
            newly created
        """
        n = fw.IMAGE_SYMBOL if self.table[r][c].has_pic else fw.NO_IMAGE
        g = ColoredButton(
            background_color=ForColor.CELL_COLOR,
            on_widget_change=self._draw_cell_mod_window,
            text=n
        )
        g.r, g.c = r, c
        return g

    def _merge_groups(self, top, origin):
        """
        Merge two groups into a new group.

        top: Cell
            from topleft of group

        origin: Cell
            topleft cell of group
        """
        # Get bottom-rights:
        o_b_r = PortCell._calc_bottom_right(origin)
        t_b_r = PortCell._calc_bottom_right(top)

        # Merge group settings:
        m_pos = min(top.r, origin.r), min(top.c, origin.c)
        m_b_r = tuple(max(o, m) for o, m in zip(o_b_r, t_b_r))
        diff = tuple(n - m for n, m in zip(m_b_r, m_pos))
        v = diff[0] + 1, diff[1] + 1

        # Get top-left cell's dict of the merged group:
        m = self.table[m_pos[0]][m_pos[1]]

        # Create a dictionary of potential slices.
        #
        # Slices are groups that are part of a merged group
        # rectangle, but are exclusive of top and origin groups.
        #
        # Also, slices have cells outside the bounds of the merged group.
        sliced = {}

        for r in range(m_pos[0], m_pos[0] + v[0]):
            for c in range(m_pos[1], m_pos[1] + v[1]):
                cell = self.table[r][c]
                if cell.is_group:
                    t = self._get_topleft(cell)
                    if t.r != top.r or t.c != top.c:
                        if t.r != origin.r or t.c != origin.c:
                            if PortCell._is_outside(
                                t,
                                m.r,
                                m.c,
                                v
                            ):
                                key = t.r, t.c
                                if key not in sliced:
                                    sliced[key] = {'size': t.s}

        self._set_group(m, v)
        self._generate_group(sliced)

    def _set_block_looks(self, start, end):
        """
        Set the appearance of a block of cells.

        start: tuple
            (r, c) for the topleft cell

        end: tuple
            (r, c) for the bottom-right cell
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self._set_cell_looks(self.table[r][c], start, end)

    def _set_caption_tooltip(self, g, d):
        """
        Set the tooltip for a cell widget.

        g: ColorButton
            Has tooltip.

        d: dict
            cell data
        """
        r, c = g.r, g.c
        has_image = "Yes" if self.table[r][c].has_pic else "No"
        n = d[ck.TYPE]
        margin = Base.make_margin_tooltip(d[ck.MARGIN], "Cell")
        shadow = Base.make_shadow_tooltip(d[ck.SHADOW])
        stripe = Base.make_stripe_tooltip(d[ck.STRIPE])

        # There is no sequence number in per cell caption:
        if n in (ok.NONE, ff.Caption.SEQUENCE_NUMBER):
            tip = Tip.NO_CAPTION.format(has_image)

        elif n == ff.Caption.IMAGE_NAME:
            tip = Tip.CAPTION_IMAGE_NAME.format(
                has_image,
                d[ck.TYPE],
                d[ck.JUSTIFICATION],
                d[ck.LEADING_TEXT],
                d[ck.TRAILING_TEXT],
                d[ck.SIZE],
                d[ck.OPACITY],
                d[ck.FONT],
                d[ck.COLOR][0],
                d[ck.COLOR][1],
                d[ck.COLOR][2],
                margin,
                shadow,
                stripe,
                bool(d[ck.CLIP_TO_CELL])
            )

        else:
            # text:
            tip = Tip.CAPTION.format(
                has_image,
                d[ck.TYPE],
                d[ck.JUSTIFICATION],
                d[ck.TEXT],
                d[ck.SIZE],
                d[ck.OPACITY],
                d[ck.FONT],
                d[ck.COLOR][0],
                d[ck.COLOR][1],
                d[ck.COLOR][2],
                margin,
                shadow,
                stripe,
                bool(d[ck.CLIP_TO_CELL])
            )
        g.set_tooltip_text(tip)

    def _set_cell_looks(self, cell, start, end):
        """
        Set a cell's appearance.

        cell: Cell
            Has cell data.

        start: tuple
            (r, c) for the topleft cell

        end: tuple
            (r, c) for the bottom-right cell
        """
        if cell.s == (1, 1):
            self._set_single_looks(cell)

        else:
            # The cell is a member of a group.
            #
            # cell neighbor flags:
            top = cell.r > start[0]
            bottom = cell.r < end[0]
            left = cell.c > start[1]
            right = cell.c < end[1]

            # top, bottom, left, right:
            w = [PAD, PAD, PAD, PAD]

            for x, i in enumerate((top, bottom, left, right)):
                if i:
                    w[x] = 0

            cell.pad_box.set_padding(*w)

            if self.is_merge:
                # button updates:
                if cell.left_button:
                    g = cell.left_button

                    if left:
                        w = V_PAD[:]
                        for x, i in enumerate((top, bottom)):
                            if i:
                                w[x] = 0

                        g.pad.set_padding(*w)
                        g.set_label(" - ")
                        g.gate = 1

                    else:
                        g.set_label(" + ")
                        g.gate = 0
                        g.pad.set_padding(*V_PAD)

                if cell.top_button:
                    g = cell.top_button

                    if top:
                        w = H_PAD[:]

                        for x, i in enumerate((left, right)):
                            if i:
                                w[x + 2] = 0

                        g.pad.set_padding(*w)
                        g.set_label(" - ")
                        g.gate = 1

                    else:
                        g.set_label(" + ")
                        g.gate = 0
                        g.pad.set_padding(*H_PAD)
        if self.is_merge:
            self._update_cell_tooltip(cell)

    def _set_fringe_tooltip(self, g, d):
        """
        Set the tooltip for a cell widget.

        g: ColorButton
            Has tooltip.

        d: dict
            cell data
        """
        r, c = g.r, g.c
        has_image = "Yes" if self.table[r][c].has_pic else "No"
        f_type = d[fr.TYPE]
        shadow = Base.make_shadow_tooltip(d[fr.SHADOW])
        bump = Base.make_bump_tooltip(d[fr.BUMP])
        tip = self._set_sub_fringe_tooltip[f_type](
            d,
            has_image,
            shadow,
            bump
        )
        g.set_tooltip_text(tip)

    @staticmethod
    def _set_fringe_gradient_tooltip(d, has_image, shadow, bump):
        """
        Return the tooltip text for the gradient-type fringe.

        d: dict
            fringe data from cell

        has_image: flag
            Indicate the presence of an image in the cell.

        shadow: string
            shadow settings

        bump: string
            bump settings

        return: string
            the tooltip
        """
        return Tip.FRINGE_GRADIENT.format(
            has_image,
            d[fr.TYPE],
            d[fr.GRADIENT_TYPE],
            d[fr.GRADIENT_ANGLE],
            d[fr.CONTRACT],
            Base.make_brush_tooltip(d[fr.BRUSH]),
            shadow,
            bump,
            d[fr.GRADIENT],
            bool(d[fr.CLIP_TO_CELL])
        )

    @staticmethod
    def _set_fringe_image_tooltip(d, has_image, shadow, bump):
        """
        Return the tooltip text for the image fringe.

        d: dict
            fringe data from cell

        has_image: flag
            Indicate the presence of an image in the cell.

        shadow: string
            shadow settings

        bump: string
            bump settings

        return: string
            the tooltip
        """
        return Tip.FRINGE_IMAGE.format(
            has_image,
            d[fr.TYPE],
            d[fr.CONTRACT],
            Base.make_brush_tooltip(d[fr.BRUSH]),
            bump,
            shadow,
            Base.make_image_tooltip(d[fr.IMAGE]),
            bool(d[fr.CLIP_TO_CELL])
        )

    @staticmethod
    def _set_fringe_mask_tooltip(d, has_image, shadow, bump):
        """
        Return the tooltip text for the mask fringe.

        d: dict
            fringe data from cell

        has_image: flag
            Indicate the presence of an image in the cell.

        shadow: string
            shadow settings
            no use

        bump: string
            bump settings
            no use

        return: string
            the tooltip
        """
        return Tip.FRINGE_MASK.format(
            has_image,
            d[fr.TYPE],
            d[fr.CONTRACT],
            Base.make_brush_tooltip(d[fr.BRUSH])
        )

    @staticmethod
    def _set_fringe_one_color_tooltip(d, has_image, shadow, bump):
        """
        Return the tooltip text for the one-color fringe.

        d: dict
            fringe data from cell

        has_image: flag
            Indicate the presence of an image in the cell.

        shadow: string
            shadow settings

        bump: string
            bump settings

        return: string
            the tooltip
        """
        return Tip.FRINGE_ONE_COLOR.format(
            has_image,
            d[fr.TYPE],
            d[fr.CONTRACT],
            Base.make_brush_tooltip(d[fr.BRUSH]),
            bump,
            shadow,
            d[fr.COLOR][0],
            d[fr.COLOR][1],
            d[fr.COLOR][2],
            bool(d[fr.CLIP_TO_CELL])
        )

    @staticmethod
    def _set_fringe_pattern_tooltip(d, has_image, shadow, bump):
        """
        Return the tooltip text for the pattern fringe.

        d: dict
            fringe data from cell

        has_image: flag
            Indicate the presence of an image in the cell.

        shadow: string
            shadow settings

        bump: string
            bump settings

        return: string
            the tooltip
        """
        return Tip.FRINGE_PATTERN.format(
            has_image,
            d[fr.TYPE],
            d[fr.CONTRACT],
            Base.make_brush_tooltip(d[fr.BRUSH]),
            bump,
            shadow,
            d[fr.PATTERN],
            bool(d[fr.CLIP_TO_CELL])
        )

    @staticmethod
    def _set_fringe_two_color_tooltip(d, has_image, shadow, bump):
        """
        Return the tooltip text for the two-color fringe.

        d: dict
            fringe data from cell

        has_image: flag
            Indicate the presence of an image in the cell.

        shadow: string
            shadow settings

        bump: string
            bump settings

        return: string
            the tooltip
        """
        return Tip.FRINGE_TWO_COLOR.format(
            has_image,
            d[fr.TYPE],
            d[fr.CONTRACT],
            Base.make_brush_tooltip(d[fr.BRUSH]),
            bump,
            shadow,
            d[fr.COLOR_1][0],
            d[fr.COLOR_1][1],
            d[fr.COLOR_1][2],
            d[fr.COLOR_2][0],
            d[fr.COLOR_2][1],
            d[fr.COLOR_2][2],
            bool(d[fr.CLIP_TO_CELL])
        )

    def _set_group(self, top, s):
        """
        Set a group's sub-cell's attributes and the group's appearance.

        top: Cell
            for a new group

        s: tuple (w, h)
            group's new dimensions
        """
        top.s = s
        start, end = top.start_end_of_top

        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                if r != top.r or c != top.c:
                    PortCell._set_sub_top(top, self.table[r][c])
        self._update_block(start, end)

    def _set_image_mask_tooltip(self, g, d):
        """
        Set the tooltip for a cell.

        Is part of the PortCell template.

        g: ColorButton
            Has tooltip.

        d: dict
            of image mask
        """
        r, c = g.r, g.c
        has_image = "Yes" if self.table[r][c].has_pic else "No"
        n = d[ma.TYPE]

        if n == ok.NONE:
            tip = Tip.NO_IMAGE_MASK.format(has_image)

        elif n == ff.Mask.CHARACTER:
            tip = Tip.IMAGE_MASK_CHARACTER.format(
                has_image,
                n,
                d[ma.CHAR],
                d[ma.HORZ_SCALE],
                d[ma.VERT_SCALE],
                d[ma.FEATHER],
                d[ma.FONT]
            )

        elif n == ff.Mask.IMAGE:
            tip = Tip.IMAGE_MASK_IMAGE.format(
                has_image,
                n,
                Base.make_image_tooltip(d[ma.IMAGE])
            )

        else:
            tip = Tip.IMAGE_MASK_SHAPE.format(
                has_image,
                n,
                d[ma.HORZ_SCALE],
                d[ma.VERT_SCALE],
                d[ma.FEATHER]
            )
        g.set_tooltip_text(tip)

    @staticmethod
    def _set_margin_tooltip(g, q):
        """
        Set the tooltip for the current cell.

        g: ColorButton
            Has tooltip.

        q: tuple
            cell data
        """
        tip = Base.make_margin_tooltip(q, "Cell")
        g.set_tooltip_text(tip)

    @staticmethod
    def _set_no_fringe_tooltip(d, has_image, shadow, bump):
        """
        Return the tooltip text for the cell with no fringe.

        d: dict
            fringe data from cell
            not used

        has_image: flag
            Indicate the presence of an image in the cell.

        shadow: string
            shadow settings
            no use

        bump: string
            bump settings
            no use

        return: string
            the tooltip
        """
        return Tip.NO_FRINGE.format(has_image)

    @staticmethod
    def _set_place_tooltip(g, d):
        """
        Set the tooltip for a cell.

        g: ColorButton
            Has tooltip.

        q: tuple
            cell data
        """
        n = Base.make_image_tooltip(d[pl.IMAGE_DICT])

        if d[pl.IMAGE_DICT][ik.TYPE] != ff.Image.Type.FOLDER:
            n = " Image:\t\t\t" + n

        g.set_tooltip_text(
            Tip.PLACE.format(
                d[pl.HORIZONTAL],
                d[pl.VERTICAL],
                n,
                d[pl.RESIZE]
            )
        )

    def _set_plaque_tooltip(self, g, d):
        """
        Set the tooltip for a cell widget.

        g: ColorButton
            Has tooltip.

        d: dict
            cell data
        """
        r, c = g.r, g.c
        has_image = "Yes" if self.table[r][c].has_pic else "No"
        n = d[pq.TYPE]
        bump = Base.make_bump_tooltip(d[pq.BUMP])

        if n == ff.Plaque.AVERAGE_COLOR:
            tip = Tip.PLAQUE_AVERAGE_COLOR.format(
                has_image,
                n,
                d[pq.OPACITY],
                d[pq.BLUR_BEHIND],
                d[pq.FEATHER],
                bump
            )

        elif n == ff.Plaque.COLOR:
            tip = Tip.PLAQUE_COLOR.format(
                has_image,
                n,
                d[pq.OPACITY],
                d[pq.BLUR_BEHIND],
                d[pq.FEATHER],
                d[pq.COLOR][0],
                d[pq.COLOR][1],
                d[pq.COLOR][2],
                bump
            )

        elif n == ff.Plaque.GRADIENT:
            tip = Tip.PLAQUE_GRADIENT.format(
                has_image,
                n,
                d[pq.GRADIENT_TYPE],
                d[pq.GRADIENT_ANGLE],
                d[pq.OPACITY],
                d[pq.BLUR_BEHIND],
                d[pq.FEATHER],
                d[pq.GRADIENT],
                bump
            )

        elif n == ff.Plaque.IMAGE:
            tip = Tip.PLAQUE_IMAGE.format(
                has_image,
                n,
                d[pq.OPACITY],
                d[pq.BLUR_BEHIND],
                d[pq.FEATHER],
                Base.make_image_tooltip(d[pq.IMAGE]),
                bump
            )

        elif n == ff.Plaque.PATTERN:
            tip = Tip.PLAQUE_PATTERN.format(
                has_image,
                n,
                d[pq.OPACITY],
                d[pq.BLUR_BEHIND],
                d[pq.FEATHER],
                d[pq.PATTERN],
                bump
            )

        else:
            tip = Tip.NO_PLAQUE.format(has_image, n)
        g.set_tooltip_text(tip)

    @staticmethod
    def _set_property_tooltip(g, d):
        """
        Set the tooltip for a cell widget.

        Is part of the PortCell template.

        g: ColorButton
            Give tooltip.

        d: dict
            cell data
        """
        tip = Tip.IMAGE_PROPERTY.format(
            d[pr.ROTATE],
            d[pr.OPACITY],
            d[pr.BLUR_BEHIND],
            bool(d[pr.FLIP_HORIZONTAL]),
            bool(d[pr.FLIP_VERTICAL])
        )
        g.set_tooltip_text(tip)

    def _set_single_looks(self, cell):
        """
        Change the appearance of a cell's frame to appear independent.

        If the cell is changing because of a split cells
        operation, then update the cell's switch buttons.

        cell: Cell
            Has cell values.
        """
        cell.pad_box.set_padding(*PADDING)
        if self.split_cells:
            for g in (cell.left_button, cell.top_button):
                if g:
                    g.set_label(" + ")

                    g.gate = 0

                    if g == cell.left_button:
                        g.pad.set_padding(*V_PAD)

                    else:
                        g.pad.set_padding(*H_PAD)

    @staticmethod
    def _set_sub_top(cell, cell1):
        """
        Modify a cell's Cell to identify the cell as being sub-topleft.

        cell: Cell
            the topleft cell

        cell1: Cell
            the sub-top cell
        """
        cell1.topleft = cell
        cell1.s = -1, -1

    def _show_port(self):
        """Call when opening a per cell port."""
        self.pane.show_all()
        self.roller_window.win.present()

    def _update_block(self, start, end):
        """
        Update format data, cell size table,
        and the cell appearance for a block of cells.

        start: Cell
            the top-left cell in the block

        end: Cell
            the bottom-right cell in the block
        """
        self._update_format(start, end)
        self.stat.layout.calc_block(self.form, self._format_x, start, end)
        self._set_block_looks(start, end)

    def _update_cell_tooltip(self, cell):
        """
        Call whenever a cell is drawn.

        Update the cell dimension labels.

        cell: Cell
            Has cell data.
        """
        g, s = cell.box, cell.s
        if cell.is_topleft:
            rect = self.stat.layout.get_pocket_rect(
                self._format_x,
                cell.r,
                cell.c
            )
            tip = Tip.MERGE_CELL.format(
                rect.x,
                rect.y,
                rect.width,
                rect.height
            )

            g.set_tooltip_text(tip)
            if s != (1, 1):
                start, end = cell.start_end_of_top
                for r in range(start[0], end[0] + 1):
                    for c in range(start[1], end[1] + 1):
                        if self.table[r][c].box:
                            g1 = self.table[r][c].box
                            if g != g1:
                                g1.set_tooltip_text("")

    def _update_format(self, start, end):
        """
        Update the format data for a block of cells.

        start: tuple of int
            the topleft cell in the block
            (r, c)

        end: tuple of int
            the bottom-right cell in the block
            (r, c)
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self.form[fk.Cell.Grid.PER_CELL][r][c] = self.table[r][c].s

    def connect_left(self, cell):
        """
        Connect cells horizontally.

        cell: Cell
            Has cell data.
        """
        origin = self._get_topleft(cell=cell)
        top = self._get_topleft(u=(cell.r, cell.c - 1))
        self._merge_groups(top, origin)

    def connect_up(self, cell):
        """
        Connect cells vertically.

        cell: Cell
            Has cell data.
        """
        origin = self._get_topleft(cell=cell)
        top = self._get_topleft(u=(cell.r - 1, cell.c))
        self._merge_groups(top, origin)

    def do_accept(self):
        """
        Accept the format dict.

        Return: true
            The key-press is handled.
        """
        self._per_cell_check_button.set_value(self.form[self.key])
        self.switch_ports()
        return self.do_accept_callback()

    def do_cancel(self, *_):
        """
        Cancel the port.

        Return: true
            The key-press is handled.
        """
        self.switch_ports()
        return self.do_cancel_callback()

    def draw_port(self, vbox):
        """
        Draw a cell table used by the per-cell ports.

        Is part of the Port template.

        vbox: VBox
            container for the widgets
        """
        is_merge = self.is_merge
        is_not_merge = self.is_not_merge
        r, c = self.rows, self.columns
        row, col = self.table_row, self.table_column = r * 2, c * 2
        table = gtk.Table(row, col)
        scroll = gtk.ScrolledWindow()
        is_1st_cell = 1
        black_box = RollerEventBox((0, 0, 0))
        black_box.add(table)
        scroll.add_with_viewport(black_box)
        vbox.add(scroll)
        scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        self.buttons = Base.create_2d_table(r, c)

        for r in range(row):
            for c in range(col):
                r1, c1 = r // 2 + 1, c // 2 + 1
                r2, c2 = r // 2 - 1, c // 2 - 1

                if r == 0:
                    if is_merge or (is_not_merge and c % 2):
                        g = self._draw_column_header(c, c1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif c == 0:
                    if is_merge or (is_not_merge and r % 2):
                        g = self._draw_row_header(r, r1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif r % 2 and c % 2:
                    # Create cell:
                    r3, c3 = r // 2, c // 2
                    cell = self.table[r3][c3]

                    # Add buttons to the cell's dictionary:
                    if r > 1:
                        cell.top_button = self.buttons[r2][c3]

                    if c > 1:
                        cell.left_button = self.buttons[r3][c2]

                    g = cell.pad_box = RollerBox(gtk.VBox, align=(0, 0, 1, 1))

                    if self.is_rectangle and cell.is_dependent:
                        cell.has_pic = 0

                    else:
                        cell.has_pic = self._has_pic(r3, c3)

                    if cell.is_topleft and is_not_merge:
                        g1 = self._make_cell_button(r3, c3)

                    elif is_merge or cell.is_not_pic_cell:
                        g1 = RollerEventBox(ForColor.CELL_COLOR)

                        if is_not_merge and not cell.is_dependent:
                            g1.set_tooltip_text(" No Image ")

                        elif not cell.is_cell:
                            g1.set_tooltip_text(" No Cell ")

                    else:
                        g1 = self._make_cell_button(r3, c3)

                    g2 = self.table[r3][c3].box = g1

                    g.add(g1)
                    table.attach(g, c, c + 1, r, r + 1)
                    self._draw_cell(r3, c3)

                    if is_1st_cell:
                        w = self._draw_first_cell(g2, vbox)
                        is_1st_cell = 0
                    g2.set_size_request(w, w)

                elif not (not r % 2 and not c % 2):
                    if is_merge:
                        g, g1 = self._draw_connector(r, c)

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

                else:
                    if is_merge:
                        # This is the square that lies at the four
                        # corners of a cell group and is not active:
                        g = RollerEventBox(ForColor.CONNECTOR_COLOR)
                        g1 = gtk.HBox()

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

    def set_tooltip(self, box, d):
        """
        Set the tooltip for a cell.

        box: ColoredButton
            Has tooltip.

        d: dict
            from per cell table
        """
        self._cell_tooltip_dict[self.key](box, d)

    def split_horz(self, cell):
        """
        The user has clicked a horizontal connector in a disconnect state.

        Divide the group containing this connector by two columns.

        cell: Cell
            Has cell data.
        """
        self.split_cells = True
        c = cell.c
        top = self._get_topleft(cell=cell)
        w = c - top.c
        w1 = top.s[1] - w
        cell1 = self.table[top.r][top.c + w]

        self._set_group(cell1, (top.s[0], w1))
        self._set_group(top, (top.s[0], w))
        self.split_cells = False

    def split_vert(self, cell):
        """
        The user has clicked a vertical connector in a disconnect state.

        Divide the group containing this connector by two rows.

        cell: Cell
            Has cell data.
        """
        self.split_cells = True
        r = cell.r
        top = self._get_topleft(cell=cell)
        h = r - top.r
        h1 = top.s[0] - h
        cell1 = self.table[top.r + h][top.c]

        # Create a new groups from the split:
        self._set_group(cell1, (h1, top.s[1]))
        self._set_group(top, (h, top.s[1]))
        self.split_cells = False
