#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import ForStep, PortKey, UIKey, WindowKey
from roller_port_choice import PortChoice
from roller_window import RollerWindow


class RWChoice(RollerWindow):
    """Is a GTK dialog with a list for the user to select an item."""

    def __init__(self, g):
        """
        Create a choice window.

        g: OptionButton
            Has values.
            Is responsible.
        """
        d = {}
        self._button = g
        k = g.key

        if isinstance(k, tuple):
            # image-effect key:
            k = k[ForStep.OPTION_KEY_INDEX]

        d[UIKey.STAT] = g.stat
        d[UIKey.WINDOW] = g.win.win
        d[UIKey.WINDOW_TITLE] = "Choose a {}".format(k)
        d[UIKey.WINDOW_KEY] = WindowKey.CHOOSER

        RollerWindow.__init__(self, d)
        d.update(
            {
                UIKey.ON_ACCEPT: self.do_accept,
                UIKey.ON_CANCEL: self.do_cancel,
                UIKey.WINDOW: self,
                UIKey.PORT_KEY: PortKey.NOT_USED
            }
        )

        self.port = PortChoice(d, g, k)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()

    def do_accept(self, value):
        """
        Accept the choice.

        value: string
            for image button

        Return: true
            The key-press is handled.
        """
        self._button.set_value(value)
        return self.close()

    def do_cancel(self, *_):
        """
        Cancel the choice window.

        Return: true
            The key-press is handled.
        """
        return self.close()
