#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay
import gimpfu as fu

pdb = fu.pdb


class RockyLanding:
    """Create a rock-like backdrop-style."""

    def __init__(self, one):
        """
        Create a Rocky Landing backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        z = Lay.clone(j, one.z)
        group = Lay.group(j, one.k, parent=one.z.parent)

        pdb.gimp_image_reorder_item(j, z, group, 0)
        pdb.plug_in_plasma(j, z, one.d[ok.RANDOM_SEED], 3)

        z1 = Lay.clone(j, z)

        Lay.color_fill(z, (0, 0, 0))

        z = Lay.clone(j, z1)
        z = RockyLanding._do_edge(j, z, fu.LAYER_MODE_SUBTRACT)
        z = RockyLanding._do_edge(j, z, fu.LAYER_MODE_LCH_HUE)

        for _ in range(one.d[ok.BLEND]):
            z = RockyLanding._do_edge(j, z, fu.LAYER_MODE_COLOR_ERASE)
            z = RockyLanding._do_edge(j, z, fu.LAYER_MODE_LCH_CHROMA)

        z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
        z1 = Lay.clone(j, z)

        pdb.plug_in_emboss(j, z1, 45, 30., 1, 1)

        z1.mode = fu.LAYER_MODE_OVERLAY

        pdb.gimp_drawable_invert(z1, 0)

        z = Lay.clone(j, z1)

        pdb.plug_in_despeckle(j, z1, 1, 1, 200, 255)
        pdb.gimp_layer_set_offsets(z, 0, 2)
        pdb.plug_in_sobel(j, z, 1, 0, 0)

        z.opacity = 83.
        z1.mode = fu.LAYER_MODE_NORMAL
        z1.opacity = 33.

        pdb.gimp_image_reorder_item(j, z1, group, 3)
        Lay.merge_group(j, group)

    @staticmethod
    def _do_edge(j, z, mode):
        """
        Shred the layer with the edge function and a layer mode.

        j: GIMP image
            with layer

        z: layer
            work-in-progress
            Is modified.

        mode: enum
            layer mode

        Return: layer
            with modifications
        """
        pdb.plug_in_edge(j, z, 1., 0, 0)

        z.mode = mode
        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        return Lay.clone(j, z)
