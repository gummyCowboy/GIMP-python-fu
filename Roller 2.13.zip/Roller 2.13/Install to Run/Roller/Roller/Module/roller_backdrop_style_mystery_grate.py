#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_backdrop_style_colored_grid import ColoredGrid
from roller_backdrop_style_gradient_fill import GradientFill
from roller_one import One
from roller_one_constant import (
    BackdropStyleKey as bsk,
    ForGradient,
    OptionKey as ok,
)
from roller_one_fu import Lay
from roller_one_preset import Preset
from roller_render_hub import RenderHub
import gimpfu as fu


class MysteryGrate:
    """Has grate-like layers."""

    def __init__(self, one):
        """
        Create a Mystery Grate backdrop-style.

        one: One
            Has variables.
        """
        self.stat = one.stat
        self.session = one.session
        j = one.stat.render.image
        self.option_key = one.k
        e = self.e = deepcopy(ForGradient.LINEAR_DICT)

        e.update(one.d)

        self.d1 = one.d
        self.d2 = Preset.get_default(bsk.COLORED_GRID)
        self.d2[ok.ROTATE] = 45.
        wip = Lay.add(j, one.k, parent=one.z.parent)
        self.group = Lay.group(j, one.k, parent=one.z.parent)

        Lay.color_fill(wip, (127, 127, 127))
        self._do_1st_layer()

        z1 = self._do_2nd_layer()

        self._do_3rd_layer(z1)

        e[ok.START_X] = e[ok.END_Y] = 1.
        e[ok.END_X] = e[ok.START_Y] = 0.

        Lay.merge_group(j, self.group)
        self._do_gradient(wip)

    def _do_1st_layer(self):
        """Create a diamond-slat layer and a shadow."""
        stat = self.stat
        j = stat.render.image
        z = Lay.add(j, self.option_key, parent=self.group)
        d, e = self.d2, self.e
        d[ok.ROW] = 1
        d[ok.COLUMN] = self.d1[ok.COLUMN_1]
        d[ok.COLOR_1] = (255, 255, 255)
        d[ok.COLOR_2] = (0, 0, 0)
        d[ok.MODE] = "Normal"
        d[ok.OPACITY] = 100
        d[ok.ROTATE] = 45

        ColoredGrid(
            One(
                d=d,
                k=self.option_key,
                session=self.session,
                stat=self.stat,
                z=z
            )
        )

        z = pdb.gimp_image_get_active_drawable(j)

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        RenderHub.do_stylish_shadow(stat, z)
        Lay.create_mask(z)

        e[ok.START_X] = e[ok.START_Y] = 0.
        e[ok.END_X] = e[ok.END_Y] = 1.
        self._do_gradient(z)

    def _do_2nd_layer(self):
        """Process the second layer."""
        stat = self.stat
        j = self.stat.render.image
        d, e = self.d2, self.e
        z = Lay.add(j, self.option_key, parent=self.group)

        d[ok.COLOR_1] = 0, 0, 0
        d[ok.COLOR_2] = 255, 255, 255
        d[ok.COLUMN] = self.d1[ok.COLUMN_2]

        ColoredGrid(
            One(
                d=d,
                k=self.option_key,
                session=self.session,
                stat=stat,
                z=z
            )
        )

        z = pdb.gimp_image_get_active_drawable(j)

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        RenderHub.do_stylish_shadow(stat, z)
        Lay.create_mask(z)

        e[ok.END_X] = e[ok.END_Y] = 0.
        e[ok.START_X] = e[ok.START_Y] = 1.
        return self._do_gradient(z)

    def _do_3rd_layer(self, z):
        """
        Process the third layer.

        z: layer
            work-in-progress
        """
        z = Lay.clone(self.stat.render.image, z)

        Lay.flip(z, horizontal=1)
        RenderHub.do_stylish_shadow(self.stat, z)
        Lay.create_mask(z)

    def _do_gradient(self, z):
        """
        Draw a gradient.

        z: layer
            to receive the gradient
        """
        j = self.stat.render.image
        clone = Lay.clone(self.stat.render.image, z)

        GradientFill(
            One(
                d=self.e,
                k=self.option_key,
                session=self.session,
                stat=self.stat,
                z=clone
            )
        )

        z1 = pdb.gimp_image_get_active_drawable(self.stat.render.image)

        Lay.transfer_mask(z1, z)
        return pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
