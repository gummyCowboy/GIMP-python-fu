#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, seed, uniform
from roller_backdrop_style_colored_grid import ColoredGrid
from roller_one import One
from roller_one_constant import (
    BackdropStyleKey as bsk,
    ForBump as fb,
    OptionKey as ok
)
from roller_one_constant_fu import Fu
from roller_one_fu import Lay
from roller_one_base import Base
from roller_one_preset import Preset
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
ed = Fu.Edge
er = Fu.Erode
um = Fu.UnsharpMask
wa = Fu.Waves


class GlassGaw:
    """
    Create a glassy grid with channels of liquid color.
    """

    def __init__(self, one):
        """
        Draw the squiggly lines of translucent color.

        one: One
            Has variables.
        """
        self.stat = one.stat
        self.option_key = one.k
        j = one.stat.render.image
        e = Preset.get_default(bsk.COLORED_GRID)
        z = Lay.clone(j, one.z)
        e.update(
            {
                ok.BUMP: {ok.BUMP: fb.NONE},
                ok.INVERT: 0,
                ok.MODE: "Normal",
                ok.OPACITY: 100,
                ok.ROTATE: 0,
                ok.THRESHOLD: 1.
            }
        )

        # Plant the seed that makes the style reproducible:
        seed(one.d[ok.RANDOM_SEED])

        for i in range(4):
            self.do_grid(e, merge=i != 0)
            z1 = j.active_layer
            z = Lay.clone(j, z1)

        pdb.plug_in_edge(j, z, ed.AMOUNT_1, ed.NO_WRAP, ed.SOBEL)

        z2 = Lay.clone(j, z1)

        Lay.blur(j, z2, 20)
        z2.mode = fu.LAYER_MODE_DIFFERENCE
        z3 = Lay.clone(j, z2)
        z4 = Lay.clone(j, z3)
        z4.mode = fu.LAYER_MODE_GRAIN_EXTRACT
        z.mode = fu.LAYER_MODE_DARKEN_ONLY

        pdb.gimp_drawable_invert(z, 0)
        Lay.blur(j, z, 4)
        pdb.plug_in_unsharp_mask(
            j,
            z1,
            um.RADIUS_3,
            um.AMOUNT_POINT_16,
            um.THRESHOLD_0
        )

        group = Lay.group(j, one.k, one.z.parent)

        for i in (z1, z3, z2, z4, z):
            pdb.gimp_image_reorder_item(j, i, group, 0)

        z5 = Lay.clone(j, z)

        for _ in range(2):
            pdb.plug_in_erode(
                j,
                z5,
                er.PROPAGATE_BLACK,
                er.RGB_CHANNELS,
                er.FULL_RATE,
                er.DIRECTION_MASK_7,
                er.LOW_LIMIT_0,
                er.UPPER_LIMIT_128
            )

        Lay.blur(j, z5, 90)

        z5.mode = fu.LAYER_MODE_MULTIPLY

        if one.d[ok.BUMP][ok.BUMP] in fb.HAS_BUMP:
            pdb.gimp_edit_copy_visible(j)

            z = Lay.paste(j, one.z.parent.layers[-1])

            RenderHub.bump(j, z, one.d[ok.BUMP])
            pdb.gimp_image_reorder_item(j, z, one.z.parent, 0)
        Lay.merge_group(j, group)

    def do_waves(self, z):
        """
        Do waves on layer.

        z: layer
            to receive wave
        """
        pdb.plug_in_waves(
            self.stat.render.image,
            z,
            randint(1, 12),
            wa.PHASE_1,
            uniform(24., 50.),
            wa.SMEARED,
            wa.USE_REFLECTION
        )

    def do_grid(self, d, merge=1):
        """
        Mix random grid overlays with waves.

        d: dict
            Has options.

        merge: flag
            If it's true, the color grid layer
            is merged to the layer below.
        """
        j = self.stat.render.image
        d[ok.ROW] = randint(2, 6)
        d[ok.COLUMN] = randint(2, 6)
        d[ok.COLOR_1] = Base.rnd_col()
        d[ok.COLOR_2] = Base.rnd_col()

        ColoredGrid(
            One(
                d=d,
                k=self.option_key,
                stat=self.stat,
                z=j.active_layer
            )
        )

        z = j.active_layer
        z.mode = fu.LAYER_MODE_DIFFERENCE

        self.do_waves(z)

        if merge:
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            self.do_waves(z)
        return z
