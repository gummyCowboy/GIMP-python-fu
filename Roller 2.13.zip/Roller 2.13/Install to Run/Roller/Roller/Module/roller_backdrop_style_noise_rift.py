#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import seed
from roller_one_constant import (
    OptionKey as ok
)
from roller_one_constant_fu import Fu
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
sn = Fu.SolidNoise


class NoiseRift:
    """Create soft lines."""

    def __init__(self, one):
        """
        Do the backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        parent = one.z.parent
        z = one.z
        d = one.d
        group = Lay.group(j, one.k, parent=parent)

        seed(d[ok.RANDOM_SEED])

        if d[ok.USE_PLASMA]:
            z = Lay.add(j, one.k, parent=group)

            pdb.plug_in_plasma(
                j,
                z,
                d[ok.RANDOM_SEED],
                Fu.Plasma.LOWEST_TURBULENCE
            )
            Gegl.blur(z, 500)
            z = Lay.clone(j, z)

        else:
            z = Lay.clone(j, z)

            pdb.gimp_image_reorder_item(j, z, group, 0)
            RenderHub.adjust_mean_value(z)

        RenderHub.add_noise(j, z, d)

        if d[ok.INVERT_NOISE]:
            pdb.gimp_drawable_invert(z, 0)

        z = Lay.merge_group(j, group)
        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        RenderHub.bump(j, z, d[ok.BUMP], merge=1)
