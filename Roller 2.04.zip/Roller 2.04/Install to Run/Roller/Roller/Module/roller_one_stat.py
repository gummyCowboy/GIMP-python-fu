#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_format_layout import Layout
from roller_format_plaque import Plaque
from roller_one_base import Comm
from roller_one_constant import ForStep
from roller_one_fu import Sel
from roller_option_limit import OptionLimit
from roller_render_image import RenderImage
from roller_render_product import Product
from roller_render_view import View


class Stat(object):
    """
    Use as a common ground for essential program variables.

    Has minimal dependencies so it won't create a circular import problem.
    """
    BACKDROP_STYLE_KEY = ForStep.BACKDROP_IMAGE_STEP

    def __init__(self):
        # alpha channels:
        self._selection = []

        # ImageRender image:
        self._render_image = None

        # Just do once:
        self.brush_list = sorted(pdb.gimp_brushes_get_list(None)[1])

        # Just do once:
        self.font_list = sorted(pdb.gimp_fonts_get_list(None)[1])

        # Just do once:
        self.gradient_list = sorted(pdb.gimp_gradients_get_list(None)[1])

        # Use with ImageGradient to delete unused gradients:
        self.image_gradients_created = []

        # Use with ImageGradient to delete unused gradients:
        self.image_gradient_used = None

        # blur behind image selection
        # key format: format name, row, column:
        self._image_sel = {}

        # Layout:
        self.layout = Layout(self)

        # Only one OptionLimit object is
        # needed through-out the program:
        self.option_limit = OptionLimit(self)

        # option groups from PortOption
        self.option_group_dict = {}

        # Just do once:
        self.pattern_list = sorted(pdb.gimp_patterns_get_list(None)[1])

        # Render plaque:
        self.plaque = Plaque(self)

        # blur-behind plaque selection
        # key: format name, row, column:
        self._plaque_sel = {}

        # the root folder for preset storage:
        self.preset_folder = None

        # Use this class instance to render:
        self.product = Product(self)

        # of render image:
        self._radius = 0

        # 'roller_path' is where are Roller
        # modules and presets are stored:
        self.roller_path = ""

        # Use to manage render preview:
        self.viewer = View(self)

        # window position dict:
        self.window_pose = {}

    @property
    def channel(self):
        """Return the list of alpha channels belonging to the render."""
        return self._selection

    def get_image_sel(self, item_name, r, c):
        """
        Get the image selection for a format cell.

        item_name: string
            part of the selection id
            a z-list item name

        r, c: int
            row, column
            cell index

        Return: GIMP selection
            for cell-oriented image
        """
        k = "{},{},{}".format(item_name, r, c)
        if k in self._image_sel:
            return self._image_sel[k]

    def get_plaque_sel(self, item_name, r, c):
        """
        Get the plaque selection for a format cell.

        item_name: string
            part of the selection id
            a z-list item name

        r, c: int
            row, column
            cell index

        Return: GIMP selection
            for cell-oriented plaque
        """
        k = "{},{},{}".format(item_name, r, c)
        return self._plaque_sel[k]

    @property
    def render(self):
        """Get the image where the render is applied."""
        if self._render_image:
            return self._render_image

        else:
            self._render_image = RenderImage(self)
            return self._render_image

    @render.setter
    def render(self, *_):
        """Is an invalid access."""
        raise Stat.StatWriteError('render')

    def save_image_sel(self, z, item_name, r, c):
        """
        Add an image selection to the image selection dict.

        z: layer
            Has plaque.

        item_name: string
            part of the selection id
            a z-list item name

        r, c: int
            row, column
            cell index
        """
        k = "{},{},{}".format(item_name, r, c)
        Sel.item(self.render.image, z)
        self._image_sel[k] = self.save_selection()

    def save_plaque_sel(self, item_name, r, c):
        """
        Add a plaque selection to the plaque selection dict.

        item_name: string
            part of the selection id
            a z-list item name

        r, c: int
            row, column
            cell index

        is_no_sel: flag
            If it is true, the selection is made.
        """
        k = "{},{},{}".format(item_name, r, c)
        self._plaque_sel[k] = self.save_selection()

    def save_selection(self):
        """
        Save a copy of the selection to the alpha channel.

        Return the selection.
        """
        self._selection.append(pdb.gimp_selection_save(self.render.image))
        return self._selection[-1]

    class StatWriteError(Exception):
        """
        Use when a function attempts to write to a read-only property.
        """
        def __init__(self, n):
            """
            There was a write error.

            Spit out the variable name.

            n: string
                function name
            """
            self.value = "StatWriteError: Attempted to write to a read-only " \
                "property: Stat.{}.".format(n)
            Comm.info_msg(self.value)

        def __str__(self):
            """
            Return the string value of the error message.

            This an Exception template function.
            """
            return repr(self.value)
