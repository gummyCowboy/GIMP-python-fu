#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_border_line import BorderLine
from roller_image_effect import ImageEffect
from roller_format_form import Form
from roller_render_hub import RenderHub
from roller_one_constant import (
    CellKey as ck,
    ForLayout,
    FormatKey as fk,
    FreeCellKey as fck,
    OptionKey as ok,
    SessionKey as sk
)
from roller_one_fu import Lay, Sel
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb

FREE = ForLayout.FREE_CELL


class BrushPunch(BorderLine):
    """Create a unique image frames using brush stroke selections."""

    def __init__(self, one):
        """
        Do the Brush Punch image-effect.

        one: One
            Has variables.
        """
        self.d = one.d
        BorderLine.__init__(self, one, framer=self.do_job)

    def do_job(self, d):
        """
        Draw the brush frame by making a selection from the brush.

        session: dict
            with format list

        d: dict
            with options

        Return: state of image
            the selection for the frame
        """
        stat = self.stat
        j = stat.render.image
        self.format_name = Lay.get_format_name_from_group(self.parent)
        self.form = None
        start_sel = stat.save_selection()
        self.frame_width = d[ok.FRAME_WIDTH] + 3

        # Get the format dict:
        for x, i in enumerate(self.session[sk.FORMAT_LIST]):
            if i[fk.Layer.NAME] == self.format_name:
                self.form = i
                break

        z = Lay.add(j, 'path', self.parent)
        self.merged = Form.is_merge_cells(self.form)
        self.row, self.col = stat.layout.get_division(x)

        self._process_grid(j, z, d)
        self._process_free_range(j, z, d)

        # Select the usable new material:
        Sel.load(j, start_sel, option=fu.CHANNEL_OP_SUBTRACT)

        for r in range(self.row):
            for c in range(self.col):
                sel = stat.get_image_sel(self.format_name, r, c)
                if sel:
                    Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

        Sel.load(j, start_sel, option=fu.CHANNEL_OP_ADD)
        Sel.item(j, z, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_image_remove_layer(j, z)

    def _process_free_range(self, j, z, d):
        """
        Do the effect for any free-range cells.

        j: GIMP image
            work-in-progress
            Is render.

        z: layer
            to receive effect

        d: dict
            Has options.
        """
        for e in reversed(self.form[fk.Layer.CELL_LIST]):
            sel = self.stat.get_image_sel(e[fck.CELL][ck.NAME], FREE, FREE)
            self._process_image(j, z, d, sel)

    def _process_grid(self, j, z, d):
        """
        Do effect for each image in the cell grid.

        j: GIMP image
            Is render.

        z: layer
            to receive effect

        d: dict
            Has options.
        """
        # Do one image at a time:
        for r in range(self.row):
            for c in range(self.col):
                if self.merged:
                    s = self.form[fk.Cell.Grid.PER_CELL][r][c]

                else:
                    # not a dependent cell:
                    s = 1

                # Is it a dependent cell?
                if s != (-1, -1):
                    sel = self.stat.get_image_sel(self.format_name, r, c)
                    self._process_image(j, z, d, sel)

    def _process_image(self, j, z, d, sel):
        """
        Do the effect for an image.

        j: GIMP image
            Is render.

        z: layer
            to receive effect

        d: dict
            Has options.
        """
        if sel:
            Sel.load(j, sel)
            Sel.grow(j, self.frame_width, d[ok.FRAME_TYPE])
            pdb.plug_in_sel2path(j, z)

            stroke = j.active_vectors.strokes[0]

            pdb.gimp_selection_none(j)
            RenderHub.brush_stroke_on_stroke(
                z,
                d[ok.BRUSH],
                d[ok.BRUSH_SIZE],
                stroke,
                d[ok.BRUSH_SPACING]
            )
