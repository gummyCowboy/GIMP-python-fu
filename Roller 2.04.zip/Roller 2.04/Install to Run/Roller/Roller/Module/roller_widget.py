#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import WidgetKey as wk
import gtk

ATTRIBUTE = (
    wk.ALIGN,
    wk.CONTAINER,
    wk.LABEL,
    wk.EVENT,
    wk.KEY,
    wk.ON_KEY_PRESS,
    wk.ON_WIDGET_CHANGE,
    wk.STAT,
    wk.WIN
)


class Widget(gtk.Alignment, object):
    """
    Is the base widget for custom widgets.

    Is a 'new-style' class with super method call.
    """

    def __init__(self, widget, **d):
        """
        Has widget-factored functions and attributes.

        Sub-widget classes need to init the Widget
        class before connecting events.

        widget: widget
            of sub-class

        d: dict
            Has init values.
        """
        super(gtk.Alignment, self).__init__()

        self.align = 0, 0, 1, 0
        self.widget = widget
        self.box = self.key = self.label = self.event = None

        for i in ATTRIBUTE:
            if i in d:
                setattr(self, i, d[i])

        self.set(*self.align)

        if wk.PADDING in d:
            self.set_padding(*d[wk.PADDING])

        if wk.ON_KEY_PRESS in d:
            self.widget.connect('key_press_event', d[wk.ON_KEY_PRESS])

        if wk.TOOLTIP in d:
            self.widget.set_tooltip_text(d[wk.TOOLTIP])

        # list of functions to call on change
        self.dependent = []

        if self.event:
            self.connect_event(self.event)

    def attach_dependent(self, dependent):
        """
        Create connections for widget inter-dependency.

        dependent: list
            of function
            for call on change
        """
        self.dependent = dependent
        self.widget.connect('changed', self.call_dependent)

    def callback(self, *_):
        """
        The widget changed or was activated.

        Call the widget's feedback function.
        """
        self.on_widget_change(self)

    def call_dependent(self, *_):
        """
        Call functions in the dependent list
        because the widget has changed.
        """
        for i in self.dependent:
            i(self)

    def connect_event(self, event):
        """
        Connect a signal to the sender for dependent widget to receive.

        sender: object
            to emit signal

        signal: string
            identifier
        """
        sender, signal = event
        sender.connect(signal, self.call_dependent, self)

    def disable(self, *_):
        """
        Make the widget inoperable.

        If the widget has an attached label, then it is also disabled.
        """
        self.widget.set_sensitive(0)
        if self.label:
            if not isinstance(
                        self.label, gtk.Label
                    ) and not isinstance(
                        self.label, gtk.Alignment
                    ):
                self.label.label.set_sensitive(0)

            else:
                self.label.set_sensitive(0)

    def enable(self, *_):
        """
        Make the widget operational.

        If the widget has an attached label, then it is also enabled.
        """
        self.widget.set_sensitive(1)
        if self.label:
            if not isinstance(
                        self.label, gtk.Label
                    ) and not isinstance(
                        self.label, gtk.Alignment
                    ):
                self.label.label.set_sensitive(1)

            else:
                self.label.set_sensitive(1)

    def hide(self):
        """Hide the widget and its attached label."""
        if self.box:
            if self.box.get_visible():
                self.box.hide()
                self.label.box.hide()

        elif self.label:
            if self.label.widget.get_visible():
                self.label.widget.hide()
        if not self.box:
            if self.widget.get_visible():
                self.widget.hide()

    def set_tooltip_text(self, tooltip):
        """
        Set the tooltip for the widget.

        tooltip: string
            for the widget
        """
        self.widget.set_tooltip_text(tooltip)

    def show(self):
        """Show the widget, its attached label, and container event box."""
        # 'box' is an EventBox:
        if self.box:
            if not self.box.get_visible():
                self.box.show()
                self.label.box.show()

        elif self.label:
            if not self.label.widget.get_visible():
                self.label.widget.show()
        if not self.box:
            if not self.widget.get_visible():
                self.widget.show()
