#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_style_colored_grid import ColoredGrid
from roller_one import One
from roller_one_constant import ForOption as fo, OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb


class SpacetimeFabric:
    """Use wind to shred lines and make a fabric texture."""

    def __init__(self, one):
        """
        Create the Spacetime Fabric backdrop-style.

        one: One
            Has variables.
        """
        stat = one.stat
        j = stat.render.image
        if Lay.has_pixel(j, one.z):
            z = Lay.clone(j, one.z)
            d = deepcopy(one.d)
            d[ok.COLOR_1] = 255, 255, 255
            d[ok.COLOR_2] = 0, 0, 0
            d[ok.MODE] = "Normal"
            d[ok.OPACITY] = 100
            d[ok.ROTATE] = 0
            d[ok.THRESHOLD] = 1.
            d[ok.INVERT] = 0
            d[ok.BUMP] = {ok.BUMP: fo.HAS_NO_BUMP}
            ColoredGrid(One(d=d, k=one.k, stat=stat, z=z))

            z = j.active_layer

            pdb.plug_in_edge(j, z, 10, 1, 4)

            w = one.session['w'] // d[ok.COLUMN]
            h = one.session['h'] // d[ok.ROW]
            w = min(w, h)
            w = max(1, w // 4)

            for _ in range(w):
                Lay.dilate(j, z)

            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
            Sel.item(j, z)

            white_sel = stat.save_selection()

            pdb.gimp_selection_none(j)
            pdb.gimp_image_remove_layer(j, z)

            # Create three layers, one for each color:
            group = Lay.group(j, one.k, parent=one.z.parent)
            z = red = Lay.clone(j, one.z)
            z.name = "Red"

            Lay.order(j, z, group)

            z = green = Lay.clone(j, z)
            z.name = "Green"
            z = blue = Lay.clone(j, z)
            z.name = "Blue"
            n = d[ok.COMPONENT]

            pdb.plug_in_colortoalpha(j, red, (0, 255, 255))
            pdb.plug_in_colortoalpha(j, green, (255, 0, 255))
            pdb.plug_in_colortoalpha(j, blue, (255, 255, 0))

            if n == "Red":
                z = red
                q = green, blue

            elif n == "Green":
                z = green
                q = red, blue

            else:
                z = blue
                q = red, green

            Sel.load(j, white_sel)
            Lay.clear_sel(j, z, no_sel=0)
            pdb.gimp_selection_none(j)

            w1 = max(2, w // 2)

            # Shred the edges of the top layer:
            for i in range(10):
                for i1 in range(4):
                    z.name = n + str(i) + str(i1)
                    pdb.plug_in_wind(
                        j,
                        z,
                        Pdb.Wind.THRESHOLD_0,
                        i1,
                        w1,
                        Pdb.Wind.BLAST,
                        Pdb.Wind.LEADING_EDGE
                    )
                    Lay.blur(j, z, 1.)

            Lay.order(j, z, group, offset=0)

            # Add texture to the bottom layers:
            for z in q:
                n = z.name
                for i in range(3):
                    for i1 in range(4):
                        pdb.plug_in_wind(j, z, 0, i1, (50, 25, 12)[i], 1, 1)
                        Lay.blur(j, z, 1.5)
                        z.name = n + str(i) + str(i1)

                z = Lay.clone(j, z)

                pdb.plug_in_engrave(j, z, i + 2, 1)

                z.mode = fu.LAYER_MODE_BURN
                Lay.merge(j, z)

            z = Lay.merge_group(j, group)
            if d[ok.EMBOSS]:
                z = Lay.clone(j, z)
                pdb.plug_in_emboss(j, z, 45, 30., 1, 1)
                z.mode = fu.LAYER_MODE_OVERLAY
