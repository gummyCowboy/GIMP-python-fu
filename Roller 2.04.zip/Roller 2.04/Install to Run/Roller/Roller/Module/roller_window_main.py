#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_format_image import RollerImage
from roller_image_effect import ImageEffect, LayerKey
from roller_image_effect_corner_tape import CornerTape
from roller_one_constant import (
    BackdropStyleKey as bsk,
    ForLayer,
    ForWidget as fw,
    FormatKey as fk,
    OptionKey as ok,
    PickleKey as pk,
    PresetKey,
    SessionKey as sk,
    UIKey,
    WindowKey
)
from roller_one_base import Comm, OZ
from roller_one_fu import Lay, Sel
from roller_option_group import OptionGroup
from roller_port_main import PortMain
from roller_render_hub import RenderHub
from roller_window import RollerWindow
from roller_window_save import RWSave
import gtk
import os

BI = bsk.BACKDROP_IMAGE
DONE = 1
IE = ok.IMAGE_EFFECT
LIGHT_LAYER = LayerKey.CELL_PLAQUE, LayerKey.CELL_FRINGE, LayerKey.LAYER_FRINGE


class WindowMain(RollerWindow):
    """Is the plug-in's main window."""

    def __init__(self, stat):
        """
        Has the GTK event loop.

        stat: Stat
            globals
        """
        self.stat = stat
        if self._verify_preset_folder():
            self._load_window_pose()
            RollerImage.make_image_list()

            d = {UIKey.STAT: stat, UIKey.WINDOW_KEY: WindowKey.MAIN}

            RollerWindow.__init__(self, d)

            d = {
                UIKey.ON_ACCEPT: self.do_accept,
                UIKey.ON_CANCEL: self.do_cancel,
                UIKey.WINDOW: self,
                UIKey.STAT: stat
            }
            self.port = PortMain(d)

            self._load_last_session()
            self.win.show_all()
            gtk.main()

            # Close any opened images:
            for k in RollerImage.opened_images:
                pdb.gimp_image_delete(RollerImage.opened_images[k].j)
            self.remove_unused_image_gradients()

    def _do_render(self, d, steps):
        """
        Render the form.

        d: dict
            of session

        steps: list
            of render steps
            [(opt_type, opt_key)]
        """
        stat = self.stat
        backdrop_light_layer = None

        stat.render.del_layout_background()
        self._refill_option_group(steps)
        stat.viewer.do(steps[-1][0], steps[-1][1], steps, d)

        if stat.render.has_image:
            j = stat.render.image
            backdrop_light_layer = Lay.search(
                j,
                LayerKey.BACKDROP_LIGHT,
                is_err=0
            )

        if stat.render.has_image:
            j = stat.render.image

            for e in d[sk.FORMAT_LIST]:
                parent = stat.render.format_group(None, e[fk.Layer.NAME])
                Lay.show(parent)
                if backdrop_light_layer:
                    # Apply the backdrop light to fringe and plaque layers:
                    for i in LIGHT_LAYER:
                        z = Lay.search(j, i, is_err=0)
                        if z:
                            Sel.item(j, z)
                            pdb.gimp_edit_copy(backdrop_light_layer)

                            z = Lay.paste(j, z)
                            z.opacity = ForLayer.BACKDROP_LIGHT_OPACITY
                            Lay.merge(j, z)

            stat.plaque.do_blur_behind(d)
            RenderHub.blur_shadow(d, stat)
            RollerImage.do_blur_behind(d, stat)

            # for the Clear Frame and Stained Glass image-effects:
            for x, e in enumerate(d[sk.FORMAT_LIST]):
                parent = stat.render.format_group(None, e[fk.Layer.NAME])

                RenderHub.blur_behind_frame(parent, stat, x)
                CornerTape.blur_behind_tape(j, parent, stat, x)

            self._del_unused_image_layer(d)

            z = j.layers[-1]
            z.name = z.name.split(":")[0] + ": Completed."

            Lay.tidy(j)

            j.active_layer = z
            pdb.gimp_selection_none(j)

    def _load_last_session(self):
        """Load the last-used session file or the default settings."""
        self.port.preset.load(fw.LAST_USED)
        self._last_session = self.port.get_session_dict()

    def _load_window_pose(self):
        """Load the window position dictionary if it exists."""
        stat = self.stat
        n = self._window_pose_file = OZ.get_preset_path(
            u"Window Position",
            "",
            stat.preset_folder
        )
        d = OZ.pickle_load({pk.FILE: n, pk.SHOW_ERROR: False})

        if d:
            stat.window_pose = deepcopy(d)
            self._last_window_pose = deepcopy(d)

        else:
            self._last_window_pose = {}

    def _refill_option_group(self, steps):
        """
        Create option groups for steps.

        In the case where the user has not viewed an option group
        in PortOption, then the option group will not already exist.

        steps: list
            [(opt_type, opt_key),]
        """
        d = self.stat.option_group_dict
        for step in steps:
            if step not in d:
                d[step] = OptionGroup(step[0], step[1], None, None)

    def _del_unused_image_layer(self, d):
        """
        The image layer is not needed in some effects.

        d: dict
            of session
        """
        stat = self.stat
        for i in d[sk.FORMAT_LIST]:
            opt_type = i[fk.Layer.NAME]
            effect = d[sk.SESSION_OPT][opt_type][IE]
            if effect:
                if effect[IE] in ImageEffect.IMAGE_DUPLICATOR:
                    stat.render.del_image_layer(opt_type)

    def _verify_preset_folder(self):
        """
        The external directory is where preset and session files are stored.

        Return: flag
            It is true if the directory is verified.
        """
        go = 0

        try:
            n = self.stat.preset_folder = os.path.join(
                self.stat.roller_path,
                u"Preset"
            )
            go = OZ.ensure_dir(n)[-1]

        except Exception as ex:
            Comm.show_err(ex)
            Comm.show_err(
                "The operating system isn't compatible with Roller."
            )
        return go

    def _write_option(self, d, opt_key):
        """
        Write a last-used file for a preset.

        d: dict
            Has last-used options.

        opt_key: string
            option key/name
            Use to name file and its folder
        """
        RWSave.write(
            self.win,
            d,
            opt_key,
            fw.LAST_USED,
            self.stat,
            do_not_overwrite=False
        )

    def do_accept(self, d, steps):
        """
        Begin a render.

        d: dict
            of session

        steps: list
            render steps

        Return: true
            The key-press was processed.
        """
        stat = self.stat

        self.close()

        if stat.render.has_layout_group:
            Lay.hide(stat.render.layout_group)

        self._do_render(d, steps)

        if d != self._last_session:
            d[PresetKey.PRESET] = fw.LAST_USED
            self._write_option(d, sk.SESSION)

        # Write last-used preset for each option
        # that was used in the render:
        for opt_type, opt_key in steps:
            if opt_key != ImageEffect.Key.NO_EFFECT:
                self._write_option(
                    d[sk.SESSION_OPT][opt_type][opt_key],
                    opt_key
                )

        if stat.window_pose != self._last_window_pose:
            OZ.pickle_dump({
                pk.DATA: stat.window_pose,
                pk.FILE: self._window_pose_file
            })

        for channel in stat.channel:
            # Channels may become invalid if the render size changes:
            if pdb.gimp_item_is_valid(channel):
                pdb.gimp_image_remove_channel(stat.render.image, channel)
        return DONE

    def do_cancel(self):
        """Close the window."""
        return self.close()

    def remove_unused_image_gradients(self):
        """
        Delete any image gradients that were
        created but not saved with the render:
        """
        for grad in self.stat.image_gradients_created:
            if grad != self.stat.image_gradient_used:
                pdb.gimp_gradient_delete(grad)
