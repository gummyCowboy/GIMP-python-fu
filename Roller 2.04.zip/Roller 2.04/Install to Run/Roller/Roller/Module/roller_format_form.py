#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_one_constant import (
    CaptionKey,
    CellKey,
    ForFormat as ff,
    ForLayout,
    FormatKey as fk,
    FreeCellKey as fck,
    FringeKey,
    ForTriangle as ft,
    MaskKey,
    OptionKey as ok,
    PlaceKey,
    PlaqueKey,
    PropertyKey
)
from roller_one_constant_fu import Pdb
from roller_one_fu import Sel
import gimpfu as fu

pdb = fu.pdb
CAPTION_KEY = fk.Cell.Caption.PER_CELL
FRINGE_KEY = fk.Cell.Fringe.PER_CELL
GRID = fk.Cell.Grid
IMAGE_PROP = PropertyKey.IMAGE_PROPERTY
LOHALO = fu.INTERPOLATION_LOHALO
MARGIN = ff.Margin.Index
MASK_KEY = fk.Cell.Image.Mask.PER_CELL
NOHALO = fu.INTERPOLATION_NOHALO
PLACE_KEY = fk.Cell.Image.Place.PER_CELL
PLAQUE_KEY = fk.Cell.Plaque.PER_CELL
PROPERTY_KEY = fk.Cell.Image.Property.PER_CELL
REPLACE = fu.CHANNEL_OP_REPLACE
SHAPE = ff.Cell.Shape


class Form:
    """Is a static class with layout functions."""

    FRACTION_WIDTH = "Width x "
    FRACTION_HEIGHT = "Height x "
    FIXED_WIDTH = "Width: "
    FIXED_HEIGHT = "Height: "
    X_OFFSET = "X: "
    Y_OFFSET = "Y: "
    CROP_WIDTH = "W: "
    CROP_HEIGHT = "H: "
    NUMERIC_STRIP = (
        FIXED_WIDTH,
        FIXED_HEIGHT,
        FRACTION_WIDTH,
        FRACTION_HEIGHT,
        X_OFFSET,
        Y_OFFSET,
        CROP_WIDTH,
        CROP_HEIGHT
    )

    @staticmethod
    def apply_shape_mask(render, j, z):
        """
        Create a cell-based shape selection and clear outside of it.

        render: GIMP image
            Has render.

        j: RollerImage
            Has cell data.

        z: layer
            with image
        """
        Form.select_shape(render, j.shape)
        Sel.clear_outside_of_selection(render, z)

    @staticmethod
    def calc_free_cell_shape(d, j):
        """
        Calculate the shape of a free-range cell.

        d: dict
            of free cell

        j: RollerImage
            Has pocket.
            to receive shape
        """
        n = d[fck.CELL][CellKey.SHAPE]
        j.shape = Form.calc_shape_from_rect(n, j.pocket)
        j.plaque = Form.calc_shape_from_rect(n, j.cell)

    @staticmethod
    def calc_shape_from_rect(n, rect):
        """
        Use with free-range cell. Calculate the shape
        given a rectangle that bounds the shape.

        n: string
            shape descriptor

        rect: Rect
            bounds of shape

        Return: object
            tuple or dict
            tuple of points
            dict defining a rectangle
            Has shape data.
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = (y + y1) // 2
        y3 = y + int(round(h * .25))
        y4 = y + int(round(h * .75))
        x2 = (x + x1) // 2
        x3 = x + int(round(w * .25))
        x4 = x + int(round(w * .75))

        if n == SHAPE.RECTANGLE:
            b = x, y, x1, y, x1, y1, x, y1

        elif n == SHAPE.HEXAGON_HORIZONTAL:
            b = x, y3, x2, y, x1, y3, x1, y4, x2, y1, x, y4

        elif n == SHAPE.HEXAGON_VERTICAL:
            b = x, y2, x3, y, x4, y, x1, y2, x4, y1, x3, y1

        elif n == SHAPE.ELLIPSE_HORIZONTAL:
            b = Form.calc_horizontal_ellipse(rect)

        elif n == SHAPE.ELLIPSE_VERTICAL:
            b = Form.calc_vertical_ellipse(rect)

        elif n == ft.TRIANGLE_LEFT:
            b = x1, y, x1, y1, x, y2

        elif n == ft.TRIANGLE_RIGHT:
            b = x, y, x, y1, x1, y2

        elif n == ft.TRIANGLE_UP:
            b = x, y1, x2, y, x1, y1

        elif n == ft.TRIANGLE_DOWN:
            b = x, y, x2, y1, x1, y

        elif n == SHAPE.ELLIPSE:
            # ellipse:
            b = {'x': rect.x, 'y': rect.y, 'w': rect.width, 'h': rect.height}

        elif n == SHAPE.DIAMOND:
            b = x, y2, x2, y, x1, y2, x2, y1
        return b

    @staticmethod
    def calc_horizontal_ellipse(rect):
        """
        Calculate the rectangle shape for a horizontal ellipse.

        rect: Rect
            bounding rectangle for an ellipse

        Return: dict
            with shape
        """
        h = int(round(rect.height * .135))
        return {
            'x': rect.x,
            'y': rect.y,
            'w': rect.width,
            'h': rect.height - h
        }

    @staticmethod
    def calc_lock(s, t):
        """
        Return the size of an image that will fit into a smaller cell.

        s: tuple
            of int
            cell size
            (w, h)

        t: tuple
            of int
            image size
            (w, h)
        """
        w_r = float(t[0]) / s[0]
        h_r = float(t[1]) / s[1]

        if w_r > h_r:
            w, h = s[0], int(t[1] * (s[0] / float(t[0])))

        else:
            w, h = int(t[0] * (s[1] / float(t[1]))), s[1]
        return max(w, 1), max(h, 1)

    @staticmethod
    def calc_vertical_ellipse(rect):
        """
        Calculate the rectangle shape for a vertical ellipse.

        rect: Rect
            the bounding rectangle of the ellipse

        Return: dict
            with shape
        """
        w = int(round(rect.width * .135))
        return {
            'x': rect.x,
            'y': rect.y,
            'w': rect.width - w,
            'h': rect.height
        }

    @staticmethod
    def combine_margin(q, w, h):
        """
        Return the margins after adding the fixed-value
        and the fraction-calculated margins together.

        q: tuple
            4 * fixed-value
            of int

            4 * fraction-of margin
            of float

        w: int
            width bounds
            from layer or cell

        h: int
            height bounds
            from layer or cell

        Return: tuple
            top, bottom, left, right
            of int
        """
        margin = [0] * 4

        # 'q1' is fraction-of margins:
        q1 = q[4:]

        q2 = [int(round(i, 6) * h) for i in q1[:2]]
        q3 = [int(round(i, 6) * w) for i in q1[2:]]
        q1 = q2 + q3

        # Combine fixed and fraction-of:
        for x in range(4):
            margin[x] = q1[x] + q[x]

        # Compensate for margin overflow
        # by reserving one pixel for the image:
        if margin[MARGIN.TOP] + margin[MARGIN.BOTTOM] >= h:
            margin[MARGIN.TOP] = h // 2
            margin[MARGIN.BOTTOM] = margin[MARGIN.TOP] + 1 if h % 2 else -1

        if margin[MARGIN.LEFT] + margin[MARGIN.RIGHT] >= w:
            margin[MARGIN.LEFT] = w // 2
            margin[MARGIN.RIGHT] = margin[MARGIN.LEFT] + 1 if w % 2 else -1
        return margin

    @staticmethod
    def get_blur_behind(d, r, c):
        """
        Return the value of an image's blur-behind setting.

        d: dict
            of format

        r, c: int
            cell index
        """
        if d[PROPERTY_KEY]:
            return d[PROPERTY_KEY][r][c][
                ff.Property.Index.BLUR_BEHIND]

        # by key:
        return d[IMAGE_PROP][PropertyKey.BLUR_BEHIND]

    @staticmethod
    def get_caption_by_key(d, k):
        """
        Put the caption data into a tuple using an ordered key-list.

        d: dict
            of caption

        k: string
            caption key
            either layer, cell, or free-cell

        Return: tuple
            index-ordered data
        """
        b = CaptionKey

        if k == CaptionKey.CELL_CAPTION:
            return (
                d[b.TYPE],
                d[b.TEXT],
                d[b.START_NUMBER],
                d[b.LEADING_TEXT],
                d[b.TRAILING_TEXT],
                d[b.FONT],
                d[b.SIZE],
                d[b.COLOR],
                d[b.MARGIN],
                d[b.JUSTIFICATION],
                d[b.OPACITY],
                d[b.CLIP_TO_CELL],
                d[b.SHADOW]
            )

        elif k == CaptionKey.FREE_CELL_CAPTION:
            return (
                d[b.TYPE],
                d[b.TEXT],
                d[b.LEADING_TEXT],
                d[b.TRAILING_TEXT],
                d[b.FONT],
                d[b.SIZE],
                d[b.COLOR],
                d[b.MARGIN],
                d[b.JUSTIFICATION],
                d[b.OPACITY],
                d[b.CLIP_TO_CELL],
                d[b.SHADOW]
            )

        else:
            # layer caption:
            return (
                d[b.TYPE],
                d[b.TEXT],
                d[b.FONT],
                d[b.SIZE],
                d[b.COLOR],
                d[b.MARGIN],
                d[b.JUSTIFICATION],
                d[b.OPACITY],
                d[b.CLIP_TO_CELL],
                d[b.SHADOW]
            )

    @staticmethod
    def get_cell_caption(d, r, c):
        """
        Collect the caption data.

        d: dict
            of format or free cell

        r, c: int
            row, column
            cell index
            (0..n)

        Return: tuple
            of caption
        """
        if r != ForLayout.FREE_CELL:
            if d[CAPTION_KEY]:
                return d[CAPTION_KEY][r][c]

            # by key:
            return Form.get_caption_by_key(
                d[CaptionKey.CELL_CAPTION],
                CaptionKey.CELL_CAPTION
            )

        # free-range cell:
        return Form.get_caption_by_key(
            d[CaptionKey.FREE_CELL_CAPTION],
            CaptionKey.FREE_CELL_CAPTION
        )

    @staticmethod
    def get_cell_fringe(d, r, c):
        """
        Return the index-ordered fringe data tuple.

        d: dict
            of format or free cell

        r, c: int
            row, column
            cell index

        Return: tuple
            of fringe
        """
        if r != ForLayout.FREE_CELL:
            if d[FRINGE_KEY]:
                return d[FRINGE_KEY][r][c]

        # by key:
        return Form.get_fringe_by_key(d[FringeKey.CELL_FRINGE])

    @staticmethod
    def get_cell_plaque(d, r, c):
        """
        Return the plaque tuple for a cell.

        d: dict
            of format or free cell

        r, c: int:
            row, column
            cell index
            (0..n)

        Return: tuple
            of plaque
        """
        if r != ForLayout.FREE_CELL:
            if d[PLAQUE_KEY]:
                return d[PLAQUE_KEY][r][c]

        # by key:
        return Form.get_plaque_by_key(d[PlaqueKey.CELL_PLAQUE])

    @staticmethod
    def get_flip_h(j, d):
        """
        Get the flip horizontal flag from a format.

        j: RollerImage
            Has cell indices.

        d: dict
            of format or free cell

        Return: int
            horizontal flip setting
        """
        if j.r != ForLayout.FREE_CELL:
            if d[PROPERTY_KEY]:
                return d[PROPERTY_KEY][j.r][j.c][
                    ff.Property.Index.FLIP_HORIZONTAL]

        # by key:
        return d[IMAGE_PROP][PropertyKey.FLIP_HORIZONTAL]

    @staticmethod
    def get_flip_v(j, d):
        """
        Get the flip vertical flag for a format.

        j: RollerImage
            Has cell indices.

        d: dict
            of format or free cell

        Return: int
            vertical flip setting
        """
        if j.r != ForLayout.FREE_CELL:
            if d[PROPERTY_KEY]:
                return d[PROPERTY_KEY][j.r][j.c][
                    ff.Property.Index.FLIP_VERTICAL]

        # by key:
        return d[IMAGE_PROP][PropertyKey.FLIP_VERTICAL]

    @staticmethod
    def get_free_cell_rect(d, size):
        """
        Calculate the position and size of a free-cell rectangle.

        d: dict
            of free cell

        size: tuple
            of int
            width, height of layer

        Return: tuple
            x, y, w, h
            position and size of free-range cell
        """
        # 'cell' in the cell info without the margins:
        x = int(
            d[CellKey.FIXED_POSITION_X] +
            round(d[CellKey.FRACTION_POSITION_X], 6) * size[0]
        )
        y = int(
            d[CellKey.FIXED_POSITION_Y] +
            round(d[CellKey.FRACTION_POSITION_Y], 6) * size[1]
        )
        w = max(
            int(
                d[CellKey.FIXED_WIDTH] +
                round(d[CellKey.FRACTION_WIDTH], 6) * size[0]
            ),
            1
        )
        h = max(
            int(
                d[CellKey.FIXED_HEIGHT] +
                round(d[CellKey.FRACTION_HEIGHT], 6) * size[1]
            ),
            1
        )
        return x, y, w, h

    @staticmethod
    def get_fringe_by_key(d):
        """
        Get the fringe data into a tuple using an ordered-key list.

        d: dict
            of fringe

        Return: tuple
            index-ordered data
        """
        a = FringeKey
        return (
            d[a.TYPE],
            d[a.BRUSH],
            d[a.BRUSH_SIZE],
            d[a.SPACING],
            d[a.OPACITY],
            d[a.BRUSH_ANGLE],
            d[a.HARDNESS],
            d[a.CONTRACT],
            d[a.BUMP],
            d[a.CLIP_TO_CELL],
            d[a.COLOR],
            d[a.COLOR_1],
            d[a.COLOR_2],
            d[a.GRADIENT],
            d[a.GRADIENT_TYPE],
            d[a.GRADIENT_ANGLE],
            d[a.IMAGE],
            d[a.PATTERN],
            d[a.SHADOW]
        )

    @staticmethod
    def get_horz_just(d, r, c):
        """
        Get the horizontal justification for a cell.

        d: dict
            of format or free cell

        r, c: int
            row, column
            cell index

        return: string
            horizontal justification
        """
        if r != ForLayout.FREE_CELL:
            if d[PLACE_KEY]:
                return d[PLACE_KEY][r][c][
                    ff.Place.Index.HORIZONTAL]

        # by key:
        return d[PlaceKey.IMAGE_PLACE][PlaceKey.HORIZONTAL]

    @staticmethod
    def get_image_mask(d, r, c):
        """
        Get the image mask data from a format.

        d: dict
            of format

        r, c: int
            cell index

        Return: tuple
            of image mask
        """
        if r != ForLayout.FREE_CELL:
            if d[MASK_KEY]:
                return d[MASK_KEY][r][c]

        # by key:
        return Form.get_image_mask_by_key(d[MaskKey.IMAGE_MASK])

    @staticmethod
    def get_image_mask_by_key(d):
        """
        Get the image mask data into a tuple using an ordered-key list.

        d: dict
            of image mask

        Return: tuple
            index-ordered data
        """
        a = MaskKey
        return (
            d[a.TYPE],
            d[a.CHAR],
            d[a.FONT],
            d[a.IMAGE],
            d[a.HORZ_SCALE],
            d[a.VERT_SCALE]
        )

    @staticmethod
    def get_layer_margin(d, size):
        """
        Get a layer margin tuple for a format layer.

        d: dict
            Has format.

        size: tuple
            w, h
            of render

        Return: tuple
            (top, bottom, left, right)
            of int
            layer margins
        """
        return Form.combine_margin(d[fk.Layer.MARGIN], size[0], size[1])

    @staticmethod
    def get_numeric_size(j, n):
        """
        Return the size of the resulting rectangle
        of an image that is numerically resized.

        j: RollerImage
            Has cell and image data.

        n: string
            from numeric-resize
            Has embedded values.

        Return: tuple
            size of rectangle
            If it is None, there was no image material.
        """
        q, x = Form.strip_numeric_value(n)

        if x == ff.Place.FIXED_VALUE_INDEX:
            size = min(q[0], j.pocket.width), min(q[1], j.pocket.height)

        elif x == ff.Place.FRACTION_VALUE_INDEX:
            w = int(round(q[0], 6) * j.j.width)
            h = int(round(q[1], 6) * j.j.height)
            size = min(w, j.pocket.width), min(h, j.pocket.height)

        else:
            if q[2] > j.j.width or q[3] > j.j.height:
                # out of image bounds, so use image size:
                size = j.j.width, j.j.height

            else:
                bounds = (
                    min(q[0] + q[2], j.j.width),
                    min(q[1] + q[3], j.j.height)
                )
                size = max(0, bounds[0] - q[0]), max(0, bounds[1] - q[1])
        return size

    @staticmethod
    def get_place(d, r, c):
        """
        Get the image place for a cell.

        d: dict
            of format

        r, c: int
            cell index

        Return: tuple
            of image place
        """
        if d[PLACE_KEY]:
            return d[PLACE_KEY][r][c]

        # by key:
        return Form.get_place_by_key(d[PlaceKey.IMAGE_PLACE])

    @staticmethod
    def get_place_by_key(d):
        """
        Get the image place data into a tuple using an ordered-key list.

        d: dict
            of image place

        Return: tuple
            index-ordered data
        """
        return (
            d[PlaceKey.IMAGE],
            d[PlaceKey.RESIZE],
            d[PlaceKey.HORIZONTAL],
            d[PlaceKey.VERTICAL]
        )

    @staticmethod
    def get_plaque_by_key(d):
        """
        Get the cell plaque data into a tuple using an ordered-key list.

        d: dict
            of plaque

        Return: tuple
            index-ordered data
        """
        a = PlaqueKey
        return (
            d[a.TYPE],
            d[a.COLOR],
            d[a.IMAGE],
            d[a.PATTERN],
            d[a.GRADIENT],
            d[a.GRADIENT_TYPE],
            d[a.GRADIENT_ANGLE],
            d[a.OPACITY],
            d[a.BLUR_BEHIND],
            d[a.BUMP]
        )

    @staticmethod
    def get_property_by_key(d):
        """
        Collect the image property data from a format dict.

        d: dict
            of image property

        Return: tuple
            of per cell image property
            index-ordered
        """
        a = PropertyKey
        return (
            d[a.FLIP_HORIZONTAL],
            d[a.FLIP_VERTICAL],
            d[a.ROTATE],
            d[a.OPACITY],
            d[a.BLUR_BEHIND]
        )

    @staticmethod
    def get_prop_opacity(d, r, c):
        """
        Get the opacity property of a cell.

        d: dict
            format dict

        r, c: int:
            row, column
            cell index
            (0..n)

        Return: float
            opacity for image
        """
        if r != ForLayout.FREE_CELL:
            if d[PROPERTY_KEY]:
                return d[PROPERTY_KEY][r][c][
                    ff.Property.Index.OPACITY]

        # by key:
        return d[IMAGE_PROP][PropertyKey.OPACITY]

    @staticmethod
    def get_resize_type(d, r, c):
        """
        Get the resize type for a cell.

        d: dict
            either of format or free cell

        r, c: int:
            row, column
            cell index
            (0..n)

        Return: object
            string or tuple
            of resize image
        """
        if r != ForLayout.FREE_CELL:
            if d[PLACE_KEY]:
                return d[PLACE_KEY][r][c][
                    ff.Place.Index.RESIZE]

        # by key:
        return d[PlaceKey.IMAGE_PLACE][PlaceKey.RESIZE]

    @staticmethod
    def get_resize_type_index(d, r, c):
        """
        Get the resize type index for a cell.

        d: dict
            format dict

        r, c: int:
            row, column
            cell index
            (0..n)

        Return: int
            resize index
        """
        a = Form.get_resize_type(d, r, c)
        if a in ff.Place.TYPE:
            return ff.Place.TYPE.index(a)

        else:
            return ff.Place.NUMERIC_INDEX

    @staticmethod
    def get_rotate(d, r, c):
        """
        Get the image rotation for a cell.

        d: dict
            format dict

        r, c: int:
            row, column
            cell index
            (0..n)

        Return: float
            rotation
        """
        if r != ForLayout.FREE_CELL:
            if d[PROPERTY_KEY]:
                return d[PROPERTY_KEY][r][c][
                    ff.Property.Index.ROTATE]

        # by key:
        return d[IMAGE_PROP][PropertyKey.ROTATE]

    @staticmethod
    def get_shadow_dict(q):
        """
        Get a shadow dict from a shadows tuple.

        q: tuple
            ForFormat.Shadow.SHADOWS tuple

        Return: dict
            of shadow
            from the shadow choice option
        """
        choice = q[ff.Shadow.Index.CHOICE]
        if choice == ok.NONE:
            d = {}

        elif choice == ff.Shadow.DROP_SHADOW:
            d = deepcopy(ff.Shadow.DROP_SHADOW_DICT)
            x = ff.Shadow.Index.SHADOW_BLUR
            for x1, i in enumerate(ff.Shadow.DROP_SHADOW_KEY):
                d[i] = q[x + x1]

        else:
            d = deepcopy(ff.Shadow.INLAY_SHADOW_DICT)
            x = ff.Shadow.Index.INLAY_BLUR
            for x1, i in enumerate(ff.Shadow.INLAY_SHADOW_KEY):
                d[i] = q[x + x1]
        return d

    @staticmethod
    def get_trim_size(s, t):
        """
        Calculate the size of a trim.

        s: tuple
            (w, h)
            of int
            image size

        t: tuple
            (w, h)
            of int
            cell size

        Return: list
            size with trim
        """
        w_r = t[0] / 1. / s[0]
        h_r = t[1] / 1. / s[1]

        if s[0] < t[0] and s[1] < t[1]:
            # No trim needed:
            w, h = s

        else:
            if w_r < h_r:
                # The image height is closer to the cell size:
                f = h_r

            else:
                # The image width is closer to the cell size:
                f = w_r

            w, h = int(s[0] * f), int(s[1] * f)
            w = min(w, s[0])
            h = min(h, s[1])

        # underflow:
        return [max(w, 1), max(h, 1)]

    @staticmethod
    def get_vert_just(d, r, c):
        """
        Get the vertical justification for a cell.

        d: dict
            of format or free cell

        r, c: int:
            row, column
            cell index
            (0..n)

        Return: string
            vertical justification
        """
        if r != ForLayout.FREE_CELL:
            if d[PLACE_KEY]:
                return d[PLACE_KEY][r][c][
                    ff.Place.Index.VERTICAL]

        # by key:
        return d[PlaceKey.IMAGE_PLACE][PlaceKey.VERTICAL]

    @staticmethod
    def is_draw_one_margin(d):
        """
        Determine if drawing one margin per row or column.

        d: dict
            of format

        Return: flag
            If it's true, there is only one margin.
        """
        return not any((
            d[PLACE_KEY],
            d[fk.Cell.Margin.PER_CELL],
            Form.is_merge_cells(d),
            d[PROPERTY_KEY]
        ))

    @staticmethod
    def is_double_space_cell(r, c, double_space):
        """
        Determine if a cell is a valid cell in a double-spaced table.

        If the grid is not shifted, then only cells
        where the row and column have the same
        remainder when divided by two are valid.

        If the grid is shifted, then only cells
        where the row and column have different
        remainders when divided by two are valid.

        r, c: int
            row, column
            cell index

        double_space: enum-flag
            type of a doubled-spaced grid

        Return: flag
            Is true if the cell is valid.
        """
        if double_space == ff.Cell.SHIFT:
            return (r % 2 and not c % 2) or (not r % 2 and c % 2)

        else:
            return (r % 2 and c % 2) or (not r % 2 and not c % 2)

    @staticmethod
    def is_double_space(d):
        """
        Determine if the cell table is double-spaced.

        A double-spaced cell table has empty cells in every other cell.

        d: dict
            of format

        Return: enum-flag
            If it's true, the cell table is double-spaced.
            type of a double-spaced grid
        """
        if d[GRID.CELL_GRID][GRID.SHAPE] in ff.Cell.Shape.DOUBLE:
            if d[GRID.CELL_GRID][GRID.SHIFT]:
                return ff.Cell.SHIFT

            else:
                return ff.Cell.NOT_SHIFT

    @staticmethod
    def is_merge_cells(d):
        """
        Determine if merge cells is in effect.

        Return: bool
            Is true if merge cells is in effect.
        """
        if Form.is_rectangle_shape(d):
            return d[GRID.PER_CELL]

    @staticmethod
    def is_rectangle_shape(d):
        """
        Determine if the current cell shape is a rectangle.

        Return: bool
            Is true if the cell shape is a rectangle.
        """
        if GRID.CELL_GRID in d:
            return d[GRID.CELL_GRID][GRID.SHAPE] == ff.Cell.Shape.RECTANGLE

        # free-range cell:
        return d[fck.CELL][CellKey.SHAPE] == ff.Cell.Shape.RECTANGLE

    @staticmethod
    def is_triangle_inverted(r, c):
        """
        Determine if a triangle is inverted,
        either vertically or horizontally.

        r, c: int
            row, column
            cell index

        Return: bool
            Is true when the triangle is inverted.
        """
        return (not r % 2 and c % 2) or (r % 2 and not c % 2)

    @staticmethod
    def mold_fill(j, _):
        """
        Resize a fill-image resize-type.

        j: RollerImage
            Has cell info.

        Return: buffer data
            of the image
        """
        if j.size != j.pocket.size:
            pdb.gimp_edit_copy_visible(j.j)

            j1 = pdb.gimp_edit_paste_as_new_image()
            w, h = j.mold.size = j.pocket.size
            Form.shape(j1, w, h)

        else:
            j.mold.size = j.size
            pdb.gimp_edit_copy_visible(j.j)

    @staticmethod
    def mold_lock(j, _):
        """
        Resize a locked image resize-type.

        j: RollerImage
            Has cell info.

        Return: buffer data
            of the image
        """
        pdb.gimp_edit_copy_visible(j.j)

        if j.width > j.pocket.width or j.height > j.pocket.height:
            # down-size:
            w, h = Form.calc_lock(j.pocket.size, j.size)
            j1 = pdb.gimp_edit_paste_as_new_image()
            Form.shape(j1, w, h)

        else:
            w, h = j.size
        j.mold.size = w, h

    @staticmethod
    def mold_numerically(j, d, n):
        """
        Resize an image with numerical values.

        j: RollerImage
            Has cell info.
            Has material.
            work-in-progress

        d: dict
            format dict

        n: string
            Has resize numeric values embedded.

        return: flag
            Is true if there is material in the buffer.

            buffer data
                of the image
        """
        q, x = Form.strip_numeric_value(n)
        j1 = None
        is_copy = True

        if x == ff.Place.FIXED_VALUE_INDEX:
            pdb.gimp_edit_copy_visible(j.j)

            j1 = pdb.gimp_edit_paste_as_new_image()

            pdb.gimp_layer_scale(
                j1.layers[0],
                q[0],
                q[1],
                Pdb.LayerScale.IMAGE_ORIGIN
            )
            pdb.gimp_image_resize_to_layers(j1)

        elif x == ff.Place.FRACTION_VALUE_INDEX:
            pdb.gimp_edit_copy_visible(j.j)

            j1 = pdb.gimp_edit_paste_as_new_image()
            w = int(j1.width * round(q[0], 6))
            h = int(j1.height * round(q[1], 6))

            pdb.gimp_layer_scale(
                j1.layers[0],
                w,
                h,
                Pdb.LayerScale.IMAGE_ORIGIN
            )
            pdb.gimp_image_resize_to_layers(j1)

        else:
            # crop method:
            pdb.gimp_selection_none(j.j)
            Sel.rect(j.j, q[0], q[1], q[2], q[3], option=fu.CHANNEL_OP_REPLACE)

            if Sel.is_sel(j.j):
                pdb.gimp_edit_copy_visible(j.j)
                j1 = pdb.gimp_edit_paste_as_new_image()

            else:
                is_copy = False

        if j1:
            if j1.width > j.pocket.width or j1.height > j.pocket.height:
                # Copy a rectangle:
                j.mold.size = Form.select_image_trim(d, j, j1)

            else:
                j.mold.size = j1.width, j1.height
                pdb.gimp_edit_copy_visible(j1)
            pdb.gimp_image_delete(j1)
        return is_copy

    @staticmethod
    def mold_trim(j, d):
        """
        Resize a trim image resize-type.

        Return with the image data in the buffer.

        j: RollerImage
            Has cell info.

        d: dict
            format dict

        return: buffer data
            of the image
        """
        s = s1 = j.size
        t = j.pocket.size

        pdb.gimp_edit_copy_visible(j.j)

        if s[0] > t[0] or s[1] > t[1]:
            w, h = Form.get_trim_size(s, t)
            j1 = pdb.gimp_edit_paste_as_new_image()

            Form.shape(j1, w, h)

            j1 = pdb.gimp_edit_paste_as_new_image()
            s1 = Form.select_image_trim(d, j, j1)

            # Copy visible selection:
            pdb.gimp_edit_copy_visible(j1)
            pdb.gimp_image_delete(j1)
        j.mold.size = s1

    @staticmethod
    def prep_free_cell_image(j, d, size):
        """
        Prepare a RollerImage for render.

        j: RollerImage
            for prep
            Is part of a render.

        d: dict
            of free cell

        size: tuple
            w, h
            of render
        """
        j.rotate = d[IMAGE_PROP][PropertyKey.ROTATE]
        j.d = d
        e = d[fck.CELL]

        # Invalid as a row and column index, the
        # negative one is a flag for a free-range image:
        j.r = j.c = ForLayout.FREE_CELL

        x, y, w, h = Form.get_free_cell_rect(e, size)

        j.cell.position = x, y
        j.cell.size = w, h

        # 'pocket' is the cell rectangle with the margins included:
        top, bottom, left, right = Form.combine_margin(
            d[fck.Cell.MARGIN],
            w,
            h
        )
        x1 = x + left
        y1 = y + top
        w = w - left - right
        h = h - top - bottom
        j.pocket.position = x1, y1
        j.pocket.size = w, h

        # 'mold' is the image rectangle for the image place.
        # Its value is computed by layout 'mold' functions:
        j.mold.position = j.mold.size = 0, 0
        Form.calc_free_cell_shape(d, j)

    @staticmethod
    def select_image_trim(d, j, j1):
        """
        Use to get the cell-size scaled image pixels
        for a trimmed or non-resized image.

        Create a selection rectangle for image data transfer.

        Copy the selection.

        d: dict
            of format

        j: RollerImage
            Has cell info.

        j1: GIMP image
            with trim

        Return: tuple
            the selection size
        """
        # Need to select from one layer only:
        m = 0

        if len(j1.layers) > 1:
            pdb.gimp_edit_copy_visible(j1)
            m = 1
            j1 = pdb.gimp_edit_paste_as_new_image()

        r, c = j.r, j.c
        n = Form.get_horz_just(d, r, c)
        s = j.pocket.size
        t = j1.width, j1.height

        if n == ff.Place.LEFT:
            x = 0
            x1 = s[0]

        elif n == ff.Place.CENTER:
            x = max(t[0] // 2 - s[0] // 2, 0)
            x1 = min(t[0] // 2 + s[0] // 2 + s[0] % 2, t[0])

        else:
            x = max(t[0] - s[0], 0)
            x1 = t[0]

        n1 = Form.get_vert_just(d, r, c)

        if n1 == ff.Place.TOP:
            y = 0
            y1 = s[1]

        elif n1 == ff.Place.MIDDLE:
            y = max(t[1] // 2 - s[1] // 2, 0)
            y1 = min(t[1] // 2 + s[1] // 2 + s[1] % 2, t[1])

        else:
            y = max(t[1] - s[1], 0)
            y1 = t[1]

        # Correct for underflow:
        if x == x1:
            x1 += 1

        if y == y1:
            y1 += 1

        w = max(x1 - x, 1)
        h = max(y1 - y, 1)

        Sel.rect(j1, x, y, w, h, option=REPLACE)
        pdb.gimp_edit_copy(j1.layers[0])

        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j1)

        if m:
            pdb.gimp_image_delete(j1)
        return x1 - x, y1 - y

    @staticmethod
    def select_shape(render, shape):
        """
        Make a selection based on a layer's cell
        shape, and an image's cell rectangle.

        render: GIMP image
            Has render.

        shape: tuple or dict
            If it is a dict, then the shape is a ellipse.
            Otherwise, it is an polygon.
        """
        if isinstance(shape, dict):
            Sel.ellipse(
                render,
                shape['x'],
                shape['y'],
                shape['w'],
                shape['h'],
                option=REPLACE
            )

        else:
            Sel.polygon(render, shape, option=REPLACE)

    @staticmethod
    def shape(j, w, h):
        """
        Resize, copy, and close an image.

        j: GIMP image
            with one layer

        w: int
            width to shape

        h: int
            height to shape

        Return: buffered data
            with image
        """
        z = j.layers[0]

        # as recommended by Davies Media Design:
        a = LOHALO if w * h <= j.width * j.height else NOHALO

        pdb.gimp_context_set_interpolation(a)
        pdb.gimp_layer_scale(z, w, h, Pdb.LayerScale.IMAGE_ORIGIN)
        pdb.gimp_image_resize_to_layers(j)
        pdb.gimp_edit_copy_visible(j)
        pdb.gimp_image_delete(j)

    @staticmethod
    def strip_numeric_value(n):
        """
        Return a tuple for the numeric value of a resize button.

        n: string
            value to split and strip

        Return:
            q1: list
                numeric values
                [for width, for height]

            x: int
                Use as type-identity.
        """
        if Form.FRACTION_HEIGHT in n:
            x = ff.Place.FRACTION_VALUE_INDEX

        elif Form.FIXED_HEIGHT in n:
            x = ff.Place.FIXED_VALUE_INDEX

        else:
            x = ff.Place.CROP_VALUE_INDEX

        q = n.split(",")
        q1 = []
        for i in q:
            for j in Form.NUMERIC_STRIP:
                i = i.strip(j)

            i = float(i) if '.' in i else int(i)
            q1.append(i)
        return q1, x
