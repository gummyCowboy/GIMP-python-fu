#!/usr/bin/env python
# -*- coding: utf-8 -*-


class NoEffect:
    """
    Don't do anything. Use so a preview
    without an effect can show images.
    """

    def __init__(self, one):
        """
        Do the Ceramic Chip image-effect.

        one: One
            Has variables.
            not used
        """
        return
