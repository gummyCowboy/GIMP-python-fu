#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class PatternFill:
    """Fill the backdrop with a pattern."""

    def __init__(self, one):
        """
        Create a Pattern Fill backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        d = one.d
        z = Lay.clone(j, one.z)
        s = one.session['size']
        x, y = RenderHub.get_layer_points(d, s[0], s[1])[:2]

        RenderHub.set_fill_context(d)
        pdb.gimp_context_set_pattern(d[ok.PATTERN])
        pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, x, y)

        if d[ok.INVERT]:
            pdb.gimp_drawable_invert(z, Pdb.DrawableInvert.NO_LINEAR)
        RenderHub.bump(j, Lay.clone(j, z), d[ok.BUMP])
