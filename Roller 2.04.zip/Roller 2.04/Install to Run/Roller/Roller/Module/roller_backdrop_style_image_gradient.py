#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_backdrop_style_gradient_fill import GradientFill
from roller_one import One
from roller_one_constant import ForBackdropStyle as fbs, OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import colorsys
import gimpfu as fu


class ImageGradient:
    """Create a gradient from an image."""

    def __init__(self, one):
        """
        Create an Image Gradient backdrop-style.

        one: One
            Has variables.
        """
        self.one = one
        stat = self.stat = one.stat
        self.layer = one.z
        self.session = one.session
        d = one.d
        j = stat.render.image
        if Lay.has_pixel(j, one.z):
            a = d[ok.SAMPLE_POINTS]
            self.d = deepcopy(d)
            self.d[ok.OFFSET] = 0
            self.color = [0] * a
            x = fbs.VECTOR.index(d[ok.SAMPLE_VECTOR])
            is_preview = stat.product.is_preview

            # Preserve:
            q = pdb.gimp_context_get_foreground()

            pdb.gimp_context_set_sample_transparent(1)

            if d[ok.PREVIEW_MODE] == fbs.SHOW_SAMPLE and is_preview:
                self._show_preview(j, d, a, x, stat.product.option_group)

                # Restore:
                pdb.gimp_context_set_foreground(q)

            else:
                self._show_gradient(j, d, a, x)

    def _do_diagonal(self, d):
        """
        Sample colors and return a gradient's start and end points.

        d: dict
            Has options.

        return: tuple
            start point, end point
        """
        a = d[ok.SAMPLE_POINTS]
        q = self._get_diagonal_points(d, a)
        s = self.session['size']

        for i in range(a):
            x, y = q[i]
            self.color[i] = self._pick_color(d, x, y)

        u = q[0][0] / 1. / s[0], q[0][1] / 1. / s[1]
        v = q[-1][0] / 1. / s[0], q[-1][1] / 1. / s[1]
        return u[0], u[1], v[0], v[1]

    def _do_horizontal(self, d):
        """
        Sample colors and return a gradient's start and end points.

        d: dict
            Has options.

        return: tuple
            start point, end point
        """
        a = d[ok.SAMPLE_POINTS]
        q = self._get_horizontal_points(d, a)

        for i in range(a):
            x, y = q[i]
            self.color[i] = self._pick_color(d, x, y)
        return 0., .5, 1., .5

    def _do_vertical(self, d):
        """
        Sample colors and return a gradient's start and end points.

        d: dict
            Has options.

        return: tuple
            start point, end point
        """
        a = d[ok.SAMPLE_POINTS]
        q = self._get_vertical_points(d, a)

        for i in range(a):
            x, y = q[i]
            self.color[i] = self._pick_color(d, x, y)
        return .5, 0., .5, 1.

    def _get_horizontal_points(self, d, a):
        """
        Get the sample points for the horizontal vector.

        d: dict
            Has options.

        a: int
            sample point count

        return: list
            of sample point coordinate
        """
        x = 0
        y = min(int(self.session['h'] * d[ok.START_Y]), self.session['h'] - 1)
        q = []
        w = self.session['w'] // (a + 1)

        for i in range(a):
            x = min(x + w, self.session['w'] - 1)
            q.append((x, y))
        return q

    def _get_diagonal_points(self, d, a):
        """
        Get the sample points for the topleft vector.

        d: dict
            Has options.

        a: int
            sample point count

        return: list
            of sample point coordinate
        """
        s = self.session['size']
        f = d[ok.DIAGONAL_ROTATION]
        x, y = RenderHub.get_point_on_rectangle(s, f)
        x1, y1 = RenderHub.get_point_on_rectangle(s, f + 180)
        q = []
        b = a + 1

        # run, rise of slope:
        w = (x1 - x) / b
        h = (y1 - y) / b

        for i in range(a):
            x = min(x + w, self.session['w'] - 1)
            y = min(y + h, self.session['h'] - 1)
            q.append((x, y))
        return q

    def _get_vertical_points(self, d, a):
        """
        Get the sample points for the vertical vector.

        d: dict
            Has options.

        a: int
            sample point count

        return: list
            of sample point coordinate
        """
        x = min(int(self.session['w'] * d[ok.START_X]), self.session['w'] - 1)
        y = 0
        q = []
        h = self.session['h'] // (a + 1)

        for i in range(a):
            y = min(y + h, self.session['h'] - 1)
            q.append((x, y))
        return q

    def _pick_color(self, d, x, y):
        """
        Pick a color from the canvas.

        d: dict
            Has options.

        x, y: int
            coordinate to pick from

        Return: color
            the color
            RGBA
        """
        return pdb.gimp_image_pick_color(
            self.stat.render.image,
            self.layer,
            x,
            y,
            Pdb.PickColor.NO_SAMPLE_MERGED,
            Pdb.PickColor.YES_SAMPLE_RADIUS,
            d[ok.SAMPLE_RADIUS]
        )

    def _show_gradient(self, j, d, a, x):
        """
        Draw the image gradient.

        j: GIMP image
            work-in-progress

        d: dict
            Has options.

        a: int
            sample points

        x: int
            sample vector index
        """
        e = self.d
        one = self.one
        grad = e[ok.GRADIENT] = pdb.gimp_gradient_new(d[ok.NAME])
        q = self._do_vertical, self._do_horizontal, self._do_diagonal

        if a > 2:
            pdb.gimp_gradient_segment_range_split_uniform(grad, 0, 0, a - 1)

        e[ok.START_X], e[ok.START_Y], e[ok.END_X], e[ok.END_Y] = q[x](e)

        for x in range(a - 1):
            opacity = self.color[x].alpha * 100

            pdb.gimp_gradient_segment_set_left_color(
                grad,
                x,
                self.color[x],
                opacity
            )

            opacity = self.color[x + 1].alpha * 100
            pdb.gimp_gradient_segment_set_right_color(
                grad,
                x,
                self.color[x + 1],
                opacity
            )

        z = Lay.clone(j, one.z)

        GradientFill(
            One(
                d=e,
                k=one.k,
                session=one.session,
                stat=self.stat,
                z=z
            )
        )
        z = pdb.gimp_image_get_active_drawable(j)

        RenderHub.bump(j, Lay.clone(j, z), d[ok.BUMP])

        if not d[ok.KEEP_GRADIENT]:
            pdb.gimp_gradient_delete(grad)

        else:
            # Track image gradients so they can
            # be deleted before the program closes:
            self.stat.image_gradients_created.append(grad)

    def _show_preview(self, j, d, a, x, option_group):
        """
        Show a preview with the sample areas filled with sampled colors.

        j: GIMP image
            work-in-progress

        d: dict
            Has options.

        a: int
            sample point count

        x: int
            vector index

        option_group: dict
            Has change flag.
        """
        pdb.gimp_selection_none(j)
        pdb.gimp_context_set_foreground((0, 0, 0))

        parent = self.layer.parent

        # Keep RenderProduct from removing preview:
        option_group.changed = True

        q = (
            self._get_vertical_points,
            self._get_horizontal_points,
            self._get_diagonal_points
        )[x](d, a)
        (self._do_vertical, self._do_horizontal, self._do_diagonal)[x](d)

        w = d[ok.SAMPLE_RADIUS]
        w1 = w + w
        w2 = w + 1
        w3 = w2 * 2

        # Draw line:
        line = q[0][0], q[0][1], q[-1][0], q[-1][1]
        line_layer = Lay.add(j, "Line", parent=parent)
        sample_layer = Lay.add(j, "Sample", parent=parent)

        RenderHub.set_brush_details()

        pdb.gimp_paintbrush_default(line_layer, len(line), line)

        for x1, u in enumerate(q):
            x, y = u
            r, g, b, alpha = [i / 255. for i in self.color[x1]]
            hsv = colorsys.rgb_to_hsv(r, g, b)
            color = (0, 0, 0) if hsv[2] > .5 else (255, 255, 255)

            if alpha < 1.:
                z = Lay.add(j, "Alpha", parent=parent, offset=0)
                z1 = Lay.add(j, "Alpha 2", parent=parent, offset=0)
                z1.opacity = 100. * alpha

            else:
                z = z1 = sample_layer

            Sel.ellipse(j, x - w2, y - w2, w3, w3, fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, color)
            Sel.ellipse(j, x - w, y - w, w1, w1, fu.CHANNEL_OP_REPLACE)

            if z1.opacity:
                Sel.fill(z1, (r, g, b))
            if z1.opacity < 100.:
                # Remove the material as it is visible when semi-opaque:
                Lay.clear_sel(j, line_layer, no_sel=0)
                Lay.clear_sel(j, z)
