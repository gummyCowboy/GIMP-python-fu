#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, seed, uniform
from roller_one_base import Base
from roller_one import One
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu
import math

pdb = fu.pdb

ONE_PIXEL = 1.
PI = 6.28318

# vine shadow dict:
DROP_SHADOW = {
    ok.SHADOW_BLUR: 20,
    ok.INTENSITY: 100,
    ok.OFFSET_X: -6,
    ok.OFFSET_Y: 0,
    ok.SHADOW_COLOR: (0, 0, 0),
    ok.MAKE_OPAQUE: 0
}


class TrailingVine:
    """
    Create layers of lines that blur as they fade in the distance.
    """

    def __init__(self, one):
        """
        Do the Trailing Vine backdrop-style.

        one: One
            Has variables.
        """
        d = one.d
        j = one.stat.render.image
        z = one.z
        self.session = one.session
        z1 = z.parent
        n = one.k
        n1 = Lay.get_layer_name(n, parent=z1)
        e = DROP_SHADOW
        d1 = {'caster_key': (n,)}
        w, h = one.session['size']
        span = min(w, h)
        stack = d[ok.LAYER_COUNT]
        shadow_blur_dec = 90 // stack

        # Preserve:
        foreground = pdb.gimp_context_get_foreground()

        seed(d[ok.RANDOM_SEED])
        RenderHub.set_brush_details()
        for i in range(stack):
            amplitude = max(20, w // max(w, randint(span // 33, span // 11)))
            amp_inc = max(10, w // randint(50, 100))
            offset = h * uniform(-.5, .5)
            wave_length = h + offset
            z = Lay.add(j, n1, parent=z1)
            z.mode = fu.LAYER_MODE_DIFFERENCE
            e[ok.SHADOW_BLUR] = max(30, (90 - i * 10 - shadow_blur_dec))

            pdb.gimp_context_set_brush_size(ONE_PIXEL + i // 2)
            pdb.gimp_context_set_foreground(Base.rnd_col())

            for _ in range(d[ok.WAVE_PER_LAYER]):
                x = randint(0, w)
                q = self.plot_wave(x, amplitude, wave_length)

                pdb.gimp_paintbrush_default(z, len(q), q)
                amplitude += amp_inc

            Shadow(
                One(
                    d=e,
                    e=d1,
                    k='shadow',
                    stat=one.stat,
                    parent=z1
                )
            )

            z2 = j.active_layer

            Lay.order(j, z2, z1, offset=1)
            Lay.blur(j, z, (stack - i) * 3)

        # Restore:
        pdb.gimp_context_set_foreground(foreground)

    def plot_wave(self, start_x, amplitude, wave_length):
        """
        Calculate the points for a wave that starts
        at the top of image and ends at the bottom.

        start_x: int
            x-coordinate to start wave

        amplitude: numeric
            in pixels
            of wave

        wave_length: numeric
            in pixels
        """
        q = []
        y = 0
        angle = 0.
        h = self.session['h']
        f = PI / wave_length

        while y < h:
            x = math.sin(angle) * amplitude + start_x
            q += [x, y]
            y += 1
            angle += f
        return q
