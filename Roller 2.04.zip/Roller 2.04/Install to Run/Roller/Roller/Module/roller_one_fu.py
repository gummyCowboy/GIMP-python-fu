#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerId, LayerKey
from roller_one_base import Comm
from roller_one_constant import ForLayer, OptionKey as ok
from roller_one_constant_fu import Pdb
import gimpfu as fu
import math

pdb = fu.pdb
NO_LAYER_FOUND = "The layer offset of, {}, was not found"
OPACITY_100 = 100.
SAMPLE_MERGED_NO = 0
THRESHOLD_ALL = 0.
X_IS_0 = Y_IS_0 = 0.


class Lay:
    """These are functions used to manage image layers."""

    @staticmethod
    def add(j, n, parent=None, offset=0, size=None):
        """
        Add a layer to an image.

        j: GIMP image
            to receive layer

        n: string
            new layer name

        parent: layer
            parent
            group layer

        offset: int
            offset from top
            from parent

        size: tuple
            size of the new layer

        Return: layer
            the new layer
        """
        z = Lay.new(j, n, size=size)

        Lay.place(j, z, parent=parent, offset=offset)
        return z

    @staticmethod
    def blur(j, z, a):
        """
        Blur a layer.

        j: GIMP image
            with layer

        z: layer
            to receive blur

        a: float or int
            blur amount
        """
        a = min(a, 500)
        pdb.plug_in_gauss_rle2(j, z, a, a)

    @staticmethod
    def clear_sel(j, z, no_sel=1):
        """
        Clear a layer's selection.

        If there's no selection, do nothing.
        GIMP will clear the layer otherwise.

        j: GIMP image
            with selection

        z: layer
            to clear material

        no_sel: flag
            If it's true, then the selection is removed.
        """
        if Sel.is_sel(j):
            pdb.gimp_edit_clear(z)
        if no_sel:
            pdb.gimp_selection_none(j)

    @staticmethod
    def clone(j, z):
        """
        Duplicate a layer.

        j: GIMP image
            with layer to duplicate

        z: layer
            to duplicate

        Return: layer
            the duplicate
        """
        pdb.gimp_selection_all(j)

        z1 = pdb.gimp_layer_copy(z, 0)
        a = Lay.offset(z)

        Lay.place(j, z1, parent=z.parent, offset=a)

        # Copies the mask, but it's not needed:
        if z1.mask:
            z1.remove_mask(fu.MASK_DISCARD)

        pdb.gimp_selection_none(j)
        return z1

    @staticmethod
    def color_fill(z, q):
        """
        Fill a layer with a color.

        z: layer
            to fill

        q: tuple
            RGB color
        """
        # Preserve:
        q1 = pdb.gimp_context_get_background()

        pdb.gimp_context_set_background(q)
        z.fill(fu.BACKGROUND_FILL)

        # Restore:
        pdb.gimp_context_set_background(q1)

    @staticmethod
    def dilate(j, z):
        """
        Dilate the material on a layer.

        j: GIMP image
            with layer

        z: layer
            to receive dilation
        """
        pdb.plug_in_dilate(
            j,
            z,
            Pdb.Dilate.OPAQUE,
            Pdb.Dilate.CHANNEL_0,
            Pdb.Dilate.FULL_RATE,
            Pdb.Dilate.DIRECTION_MASK_0,
            Pdb.Dilate.LOW_LIMIT_0,
            Pdb.Dilate.UPPER_LIMIT_255
        )

    @staticmethod
    def flip(z, horizontal=0):
        """
        Flip a layer horizontally or vertically.

        z: layer
            to flip

        horizontal: flag
            If it's true, flip layer horizontally.

        Return: layer
            the modified layer
        """
        a = fu.ORIENTATION_HORIZONTAL if horizontal \
            else fu.ORIENTATION_VERTICAL
        return pdb.gimp_item_transform_flip_simple(z, a, True, 0)

    @staticmethod
    def get_format_name_from_group(z):
        """
        Get the format name as referenced by a format group.

        z: layer
            format group

        Return: string
            format name
        """
        return z.name.decode('utf-8')[3:]

    @staticmethod
    def get_layer_name(n, parent=None):
        """
        Name a layer given its name-key.

        Layers have a naming convention. Some layers have
        Unicode keys and some do not. The one's that don't
        have a key are given an ForLayer.LAYER_BULLET symbol.

        n: string
            layer name

        stat: Stat
            global variables

        parent: layer
            group layer

        Return: string
            layer name
        """
        # Remove the unicode character:
        if not parent:
            n1 = ""

        else:
            q = parent.name.decode('utf-8').split(" ")
            n1 = ""

            for i in q[1:]:
                n1 += i + " "
            n1 = n1.strip()

        if n in LayerId.KEY:
            # keyed layers:
            n1 = "{}: {}".format(n1, n)
            return LayerId.KEY[n] + " " + n1

        else:
            if parent:
                # non-keyed layers:
                return "{}{}: {}".format(ForLayer.LAYER_BULLET, n1, n)

            else:
                return ForLayer.LAYER_BULLET + n

    @staticmethod
    def give_mask(z, masked, option=fu.ADD_MASK_ALPHA):
        """
        Transfer a mask from one layer to another.

        z: layer
            to receive mask

        masked: layer
            with the mask

        option: gimpfu enum
            mask-type
        """
        if not masked.mask:
            Lay.masked(masked, option=option)
        if not z.mask:
            z.add_mask(Lay.mask(masked, option=option))

    @staticmethod
    def group(j, n, parent=None, offset=0):
        """
        Create a group layer.

        j: GIMP image
            to receive group

        n: string
            name of group

        parent: layer
            parent layer of group

        offset: int
            offset from the top

        Return: layer
            the group
        """
        z = pdb.gimp_layer_group_new(j)

        Lay.place(j, z, parent=parent, offset=offset)

        z.name = n
        z.mode = fu.LAYER_MODE_PASS_THROUGH
        return z

    @staticmethod
    def hide(z):
        """
        Make a layer invisible.

        z: layer
            to hide
        """
        if z.visible:
            pdb.gimp_item_set_visible(z, 0)

    @staticmethod
    def hide_format_stack(stat, x):
        """
        Hide format groups that are stacked above a format group.

        stat: Stat
            globals

        x: int
            format group index in format group stack
            The top-most group has a zero-index.
        """
        x1 = 0
        if x:
            for z in stat.render.image.layers:
                if z.name.decode('utf-8')[0] == LayerKey.FORMAT[0]:
                    if x1 < x:
                        Lay.hide(z)
                        x1 += 1

    @staticmethod
    def has_pixel(j, z):
        """
        Return the pixel count of a layer.

        Color count will return zero if the layer is completely transparent.

        j: GIMP image
            with layer check

        z: layer
            to check
        """
        return pdb.plug_in_ccanalyze(j, z)

    @staticmethod
    def hide_layers_above(parent, z):
        """
        Hide a layer and any layers above in a layer stack.

        parent: layer
            group

        z: layer
            first layer to hide
            child of parent
        """
        for z1 in parent.layers:
            Lay.hide(z1)
            if z1 == z:
                break

    @staticmethod
    def mask(z, option=fu.ADD_MASK_ALPHA):
        """
        z: layer
            to mask

        option: gimpfu enum
            mask type

        Return: GIMP mask
            of a layer
        """
        return pdb.gimp_layer_create_mask(z, option)

    @staticmethod
    def masked(z, option=fu.ADD_MASK_ALPHA):
        """
        A layer gets an alpha mask.

        z: layer
            to mask

        option: gimpfu enum
            mask type
        """
        z.add_mask(Lay.mask(z, option=option))

    @staticmethod
    def merge(j, z):
        """
        Merge layer down. The target must be visible.

        j: GIMP image
            with layer

        z: layer
            to merge down

        Return: layer
            merged
        """
        return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    @staticmethod
    def merge_group(j, z, n=None):
        """
        Merge layer group. Resize merge group to image size.

        j: GIMP image
            work-in-progress

        z: layer
            group

        n: string
            layer name after merge

        Return: layer
            the merged group
        """
        z = pdb.gimp_image_merge_layer_group(j, z)

        pdb.gimp_layer_resize_to_image_size(z)
        if n:
            z.name = n
        return z

    @staticmethod
    def new(j, n, size=0):
        """
        Create a layer.

        j: GIMP image
            to receive layer

        n: string
            layer name

        size: tuple
            size of the layer

        Return: layer
            newly created
        """
        if size:
            w, h = size

        else:
            w, h = j.width, j.height
        return pdb.gimp_layer_new(
            j,
            w,
            h,
            fu.RGBA_IMAGE,
            n,
            OPACITY_100,
            fu.LAYER_MODE_NORMAL
        )

    @staticmethod
    def offset(z):
        """
        Get a layer's offset from its parent.

        z: layer
            with an unknown offset

        Return: int
            offset
        """
        if z:
            z1 = z.parent

            # If layer is sub-grouped:
            if z1 and hasattr(z1, 'layers'):
                for x, z2 in enumerate(z1.layers):
                    if z == z2:
                        return x

            # Layer is in on the root stack:
            else:
                for x, z1 in enumerate(z.image.layers):
                    if z == z1:
                        return x

            Comm.info_msg(NO_LAYER_FOUND.format(repr(z)))
            return -1
        return -1

    @staticmethod
    def order(j, z, group, offset=0):
        """
        Move a layer into a different position.

        z: layer
            to move in layer stack

        group: layer
            parent group or None
            a potential parent after the move

        offset: int
            offset from the top of a layer stack
            belonging to the parent
        """
        pdb.gimp_image_reorder_item(j, z, group, offset)

    @staticmethod
    def paste(j, z):
        """
        Paste the content of the buffer.

        j: GIMP image
            to receive the new layer

        z: layer
            paste above this layer

        Return: layer
            newly created
        """
        a = pdb.gimp_edit_paste(z, 0)

        pdb.gimp_floating_sel_to_layer(a)
        return j.active_layer

    @staticmethod
    def place(j, z, parent=None, offset=0):
        """
        Insert a layer into an image.

        j: image
            to receive layer

        z: layer
            to insert

        parent: layer
            parent group

        offset: int
            offset from the top of a layer stack of parent
        """
        pdb.gimp_image_insert_layer(j, z, parent, offset)

    @staticmethod
    def rotate(j, a):
        """
        Rotate the top layer.

        j: GIMP image
            to rotate

        a: float or int
            rotation amount in degrees

        Return: layer
            the transformed layer
        """
        pdb.gimp_context_set_transform_direction(fu.TRANSFORM_FORWARD)
        pdb.gimp_context_set_transform_resize(fu.TRANSFORM_RESIZE_ADJUST)

        z = pdb.gimp_item_transform_rotate(
            j.layers[0],
            math.radians(a),
            Pdb.Rotate.AUTO_CENTER_YES,
            Pdb.Rotate.CENTER_X_0,
            Pdb.Rotate.CENTER_Y_0
        )

        pdb.gimp_image_resize_to_layers(j)
        return z

    @staticmethod
    def search(z, n, is_err=1):
        """
        Find a layer by its name.

        z: layer
            group to search

        n: string
            layer name key
            Use to discover the layer's Unicode key character.

        is_err: flag
            If it's true, an error message
            will display when the layer is not found.

        Return: layer or None
            as found
        """
        if n in LayerId.KEY:
            n1 = LayerId.KEY[n]
            for z1 in z.layers:
                # Decode byte string into unicode for comparison:
                n2 = z1.name.decode('utf-8')[0]

                if n1 == n2:
                    return z1
                if hasattr(z1, 'layers'):
                    z2 = Lay.search(z1, n, is_err=0)
                    if z2:
                        return z2
        if is_err:
            raise LayerNotFound("A layer was not found: " + n)

    @staticmethod
    def selectable(j, z, d):
        """
        Return a duplicate layer with an optional
        transform of no semi-transparent pixels.

        j: GIMP image
            with selection

        z: layer
            with material

        d: dict
            with an OptionKey.MAKE_OPAQUE key
        """
        z = Lay.clone(j, z)

        # no semi-transparency:
        if d[ok.MAKE_OPAQUE]:
            pdb.plug_in_threshold_alpha(j, z, THRESHOLD_ALL)
            pdb.plug_in_antialias(j, z)
        return z

    @staticmethod
    def show(z):
        """
        Makes a layer visible.

        z: layer
            to show
        """
        if not z.visible:
            pdb.gimp_item_set_visible(z, 1)

    @staticmethod
    def show_format_groups(stat):
        """
        Show each format group.

        stat: Stat
            global variables
        """
        for z in stat.render.image.layers:
            if z.name.decode('utf-8')[0] == LayerKey.FORMAT[0]:
                Lay.show(z)

    @staticmethod
    def show_layer_on_top(parent, z):
        """
        Show layers in a group from the top layer
        and stop after the given layer.

        parent: group
            with layers to show

        z: layer
            last layer to show
        """
        for z1 in parent.layers:
            Lay.show(z1)
            if z1 == z:
                break

    @staticmethod
    def tidy(z):
        """
        Remove duplicate layer name fu from layer names.

        Is recursive.

        z: layer or GIMP image
            Has sub-layers.
        """
        for z1 in z.layers:
            n = z1.name

            if "#" in n:
                n = n.replace(" #", "#")
                x = n.index("#")
                prefix = n[:x]
                postfix = n[x:]

                for n2 in "#0123456789":
                    postfix = postfix.replace(n2, "")
                z1.name = prefix + postfix

            if "  " in n:
                n = z1.name = n.replace("  ", "")

            if " copy" in n:
                z1.name = n.replace(" copy", "")
            if hasattr(z1, 'layers'):
                # recursive:
                Lay.tidy(z1)


class Sel:
    """Organize selection functions."""

    @staticmethod
    def clear_outside_of_selection(j, z, keep_sel=0):
        """
        Invert and clear a selection.

        z: layer
            Is cleared.

        j: GIMP image
            Has layer.

        keep_sel: flag
            If it's true, then the selection is the same on exit.
        """
        if keep_sel:
            sel = pdb.gimp_selection_save(j)

        Sel.invert(j)
        Lay.clear_sel(j, z)
        if keep_sel:
            Sel.load(j, sel)
            pdb.gimp_image_remove_channel(j, sel)

    @staticmethod
    def color(j, z, q):
        """
        Create a selection based on color.

        j: GIMP image
            Has layer to color.

        z: layer
            to color

        q: tuple
            RGB color
        """
        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_sample_merged(0)

        # composite:
        pdb.gimp_context_set_sample_criterion(0)
        pdb.gimp_context_set_sample_threshold(.059)
        pdb.gimp_context_set_sample_transparent(1)
        pdb.gimp_image_select_color(j, fu.CHANNEL_OP_REPLACE, z, q)

    @staticmethod
    def ellipse(j, x, y, w, h, option=fu.CHANNEL_OP_ADD):
        """
        Make an ellipse selection.

        j: GIMP image
            to receive selection

        x, y: int
            top-left point of ellipse

        w: int
            radius width

        h: int
            radius height

        option: GIMP enum
            add, replace, subtract, or intersect
        """
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_feather(1)
        pdb.gimp_context_set_feather_radius(2., 2.)
        pdb.gimp_image_select_ellipse(
            j,
            option,
            x,
            y,
            w,
            h,
        )

    @staticmethod
    def fill(z, q):
        """
        Fill a selection on a layer.

        z: layer
            to apply fill

        q: tuple
            RGB color
        """
        # Preserve:
        q1 = pdb.gimp_context_get_background()

        pdb.gimp_context_set_background(q)
        pdb.gimp_edit_bucket_fill(
            z,
            fu.BACKGROUND_FILL,
            fu.LAYER_MODE_NORMAL,
            OPACITY_100,
            THRESHOLD_ALL,
            SAMPLE_MERGED_NO,
            X_IS_0,
            Y_IS_0
        )

        # Restore:
        pdb.gimp_context_set_background(q1)

    @staticmethod
    def grow(j, w, m, feather=0):
        """
        Expand a selection.

        When a selection is grown incrementally,
        the selection appears to be angular.

        j: GIMP image
            with selection

        w: int
            expansion amount

        m: flag
            expansion type
            '0' is rounded.
            '1' is angular.

        feather: bool
            (0..1)
            If true the selection is softened with a feather.
        """
        pdb.gimp_context_set_feather(feather)
        pdb.gimp_context_set_antialias(0)
        if m:
            for _ in range(w):
                pdb.gimp_selection_grow(j, 1)

        else:
            pdb.gimp_selection_grow(j, w)

    @staticmethod
    def invert(j):
        """
        Invert a selection.

        j: GIMP image
            with selection
        """
        if Sel.is_sel(j):
            pdb.gimp_selection_invert(j)

    @staticmethod
    def is_sel(j):
        """
        Determine if there is a selection.

        j: GIMP image
            with selection

        Return: flag
            If it's true, then there is a selection.
        """
        return not pdb.gimp_selection_is_empty(j)

    @staticmethod
    def isolate(j, z, sel, keep_sel=0):
        """
        Clear out material not in a selection.

        j: GIMP image
            with selection

        z: layer
            with material to clear

        sel: selection
            The selection part is preserved.
            The other part is removed.

        keep_sel: flag
            If true, the selection remains.
        """
        Sel.load(j, sel)
        Sel.clear_outside_of_selection(j, z, keep_sel=keep_sel)

    @staticmethod
    def item(j, z, option=fu.CHANNEL_OP_REPLACE):
        """
        Select an item.

        j: GIMP image
            with layer

        z: layer
            to select

        option: GIMP enum
            selection operation
            replace, add, subtract
        """
        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_image_select_item(j, option, z)

    @staticmethod
    def load(j, sel, option=fu.CHANNEL_OP_REPLACE):
        """
        Load a previously saved selection.

        j: GIMP image
            to receive selection

        sel: selection
            a selection channel of image

        option: selection operation
            add, replace, subtract
        """
        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_antialias(0)
        pdb.gimp_image_select_item(j, option, sel)

    @staticmethod
    def polygon(j, q, option=fu.CHANNEL_OP_ADD):
        """
        Add a polygon selection to the current selection.

        j: GIMP image
            to receive selection

        q: list
            of points

        option: GIMP enum
            add, subtract, or replace the selection mode
        """
        if q:
            pdb.gimp_context_set_antialias(1)
            pdb.gimp_context_set_feather(0)
            pdb.gimp_image_select_polygon(j, option, len(q), q)

        else:
            Comm.info_msg("Sorry. Roller failed to draw a polygon.")

    @staticmethod
    def rect(j, x, y, w, h, option=fu.CHANNEL_OP_ADD):
        """
        Draw a selection rectangle.

        j: GIMP image
            to receive selection
        """
        if (x + w > 0 and x < j.width) and (y + h > 0 and y < j.height):
            pdb.gimp_context_set_feather(0)
            pdb.gimp_context_set_antialias(0)
            pdb.gimp_image_select_rectangle(j, option, x, y, w, h)


class LayerNotFound(Exception):
    """
    An exception for when a layer isn't found by 'Lay.search'.

    The program is unstable or in a buggy state.
    """
    def __init__(self, n):
        """
        There was an error.

        Spit out the layer name for tracing purposes.

        n: string
            layer name
        """
        self.value = "A layer was not found: " + n

    def __str__(self):
        """
        Return the string value of the error message.

        This an Exception template function.
        """
        return repr(self.value)
