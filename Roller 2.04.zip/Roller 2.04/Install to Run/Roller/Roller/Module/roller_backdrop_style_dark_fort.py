#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_style_colored_grid import ColoredGrid
from roller_one_constant import ForOption as fo, OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay
import gimpfu as fu

cs = Pdb.ColorSelect
des = Pdb.Despeckle
edge = Pdb.Edge
em = Pdb.Emboss
pdb = fu.pdb
rn = Pdb.RGBNoise


class DarkFort:
    """Create a dark texture that resembles a brick wall."""

    def __init__(self, one):
        """
        Do the Dark Fort backdrop style.

        one: One
            Has variables.
        """
        d = one.d
        j = one.stat.render.image
        z = Lay.add(j, one.k, parent=one.z.parent)
        d[ok.COLOR_1] = 0, 0, 0
        d[ok.COLOR_2] = 255, 255, 255
        d[ok.BUMP] = {ok.BUMP: fo.HAS_NO_BUMP}
        z = ColoredGrid.draw_color_grid(j, z, d)

        # Create a selection from black pixels:
        pdb.gimp_by_color_select(
            z,
            (0, 0, 0),
            cs.THRESHOLD_0,
            fu.CHANNEL_OP_REPLACE,
            cs.YES_ANTIALIAS,
            cs.NO_FEATHER,
            cs.FEATHER_RADIUS_0,
            cs.NO_SAMPLE_MERGED
        )

        # Clear the black grid:
        Lay.clear_sel(j, z)

        pdb.plug_in_rgb_noise(
            j,
            z,
            rn.YES_INDEPENDENT,
            rn.NO_CORRELATED,
            rn.NOISE_TENTH,
            rn.NOISE_TENTH,
            rn.NOISE_TENTH,
            rn.NOISE_ZERO
        )
        pdb.plug_in_emboss(
            j,
            z,
            em.AZIMUTH_30,
            em.ELEVATION_20,
            em.DEPTH_3,
            em.BUMP
        )
        pdb.plug_in_despeckle(
            j,
            z,
            des.RADIUS_4,
            des.ADAPTIVE,
            des.BLACK_7,
            des.WHITE_248
        )
        pdb.plug_in_despeckle(
            j,
            z,
            des.RADIUS_30,
            des.ADAPTIVE,
            des.BLACK_7,
            des.WHITE_248
        )

        z1 = Lay.clone(j, z)
        z1.mode = fu.LAYER_MODE_HSV_VALUE

        Lay.flip(z1, horizontal=1)

        Lay.merge(j, z)
        z = Lay.merge(j, z1)
        z1 = Lay.clone(j, z)
        z1.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.plug_in_plasma(
            j,
            z,
            d[ok.RANDOM_SEED],
            Pdb.Plasma.LOWEST_TURBULENCE
        )
        pdb.gimp_drawable_desaturate(z, fu.DESATURATE_LUMINANCE)
        pdb.plug_in_emboss(
            j,
            z,
            em.AZIMUTH_30,
            em.ELEVATION_20,
            em.DEPTH_3,
            em.BUMP
        )

        z = Lay.clone(j, z)

        pdb.gimp_drawable_invert(z, 0)

        z.mode = fu.LAYER_MODE_LUMINANCE
        z2 = Lay.clone(j, z1)
        z2.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.plug_in_edge(j, z2, edge.AMOUNT_2, edge.WRAP, edge.SOBEL)
        pdb.gimp_edit_copy_visible(j)

        z3 = Lay.paste(j, z2)

        pdb.gimp_image_remove_layer(j, z2)
        pdb.plug_in_despeckle(
            j,
            z,
            des.RADIUS_1,
            des.ADAPTIVE,
            des.BLACK_58,
            des.WHITE_154
        )

        z4 = Lay.clone(j, z3)
        z5 = Lay.clone(j, z4)

        Lay.blur(j, z5, 2)

        z3.mode = fu.LAYER_MODE_GRAIN_EXTRACT
        z4.mode = fu.LAYER_MODE_DIFFERENCE
        z4.opacity = 20.
        z5.mode = fu.LAYER_MODE_DIFFERENCE
        pdb.gimp_drawable_invert(z3, 0)
