#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay
import gimpfu as fu

pdb = fu.pdb
COLOR = (0, 255, 255), (255, 255, 0), (255, 0, 255)


class SquareCloud:
    """Make a cloud of bright squares."""

    def __init__(self, one):
        """
        Create a Square Cloud backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        d = one.d
        parent = one.z.parent
        group = Lay.group(j, one.k, parent=parent)
        base = Lay.clone(j, one.z)

        Lay.order(j, base, group)

        z = Lay.clone(j, base)

        pdb.plug_in_plasma(
            j,
            z,
            d[ok.RANDOM_SEED],
            Pdb.Plasma.MEDIUM_TURBULENCE
        )

        z1 = Lay.clone(j, z)

        for i in range(10):
            Lay.dilate(j, z1)
            pdb.plug_in_erode(
                j,
                z,
                Pdb.Erode.PROPAGATE_OPAQUE,
                Pdb.Erode.RGB_CHANNELS,
                Pdb.Erode.FULL_RATE,
                Pdb.Erode.RGB_CHANNELS,
                Pdb.Erode.LOW_LIMIT_0,
                Pdb.Erode.UPPER_LIMIT_255
            )

        pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
        pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
        Lay.color_fill(base, (127, 127, 127))

        z2 = Lay.clone(j, base)
        z2.mode = fu.LAYER_MODE_HSV_SATURATION

        Lay.order(j, z2, group)

        z3 = Lay.clone(j, z)
        z3.mode = fu.LAYER_MODE_OVERLAY
        z3.opacity = 75.

        Lay.order(j, z3, group)

        z4 = Lay.clone(j, z3)
        z4.mode = fu.LAYER_MODE_DARKEN_ONLY
        z4.opacity = 30.
        z = Lay.merge_group(j, group)
        z1 = Lay.clone(j, z)
        z1.opacity = 50.
        pdb.plug_in_colorify(j, z1, d[ok.COLOR])
