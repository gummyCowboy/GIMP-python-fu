#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Pdb:
    """
    Has values used by pdb functions.

    Replace numbers with more useful information.
    """
    class BucketFill:
        """Is for gimp_drawable_edit_bucket_fill."""
        X_IS_1 = 1
        Y_IS_1 = 1

    class Clothify:
        """Is for the script-fu, clothify."""
        AZIMUTH_90 = 90.
        AZIMUTH_135 = 135.
        BLUR_X_0 = BLUR_Y_0 = 0.
        BLUR_X_3 = BLUR_Y_3 = 3.
        DEPTH_1 = 1.
        DEPTH_2 = 2.
        ELEVATION_45 = 45.
        ELEVATION_70 = 70.

    class ColorSelect:
        """Is for gimp_by_color_select."""
        THRESHOLD_0 = 0
        YES_ANTIALIAS = 1
        NO_FEATHER = 0
        FEATHER_RADIUS_0 = 0.
        NO_SAMPLE_MERGED = 0

    class Despeckle:
        """Is for the plug-in, despeckle."""
        ADAPTIVE = 1
        BLACK_7 = 7
        BLACK_58 = 58
        BLACK_154 = 154
        BLACK_191 = 191
        RADIUS_1 = 1
        RADIUS_4 = 4
        RADIUS_16 = 16
        RADIUS_30 = 30
        RECURSIVE_ADAPTIVE = 3
        WHITE_58 = 58
        WHITE_64 = 64
        WHITE_154 = 154
        WHITE_248 = 248

    class Dilate:
        """Is for plug_in_dilate."""
        CHANNEL_0 = 0
        DIRECTION_MASK_0 = 0
        FULL_RATE = 1.
        LOW_LIMIT_0 = 0
        OPAQUE = 6
        UPPER_LIMIT_255 = 255

    class DrawableInvert:
        """Is for the GIMP function, drawable invert."""
        NO_LINEAR = 0

    class DropShadow:
        """Is for script_fu_drop_shadow."""
        NO_RESIZING = 0

    class Edge:
        """Is for plug_in_edge."""
        AMOUNT_1 = 1.
        AMOUNT_2 = 2.
        NO_WRAP = 0
        SOBEL = 0
        WRAP = 1

    class Emboss:
        """Is for the plug-in, emboss."""
        AZIMUTH_210 = 210.
        AZIMUTH_30 = 30.
        AZIMUTH_45 = 45.
        DEPTH_1 = 1
        DEPTH_100 = 100
        DEPTH_2 = 2
        DEPTH_3 = 3
        DEPTH_4 = 4
        BUMP = 0
        ELEVATION_19 = 19.
        ELEVATION_20 = 20.
        ELEVATION_30 = 30.
        ELEVATION_50 = 50.
        EMBOSS = 1
        LIGHT_ANGLE_45 = 45.
        MAX_DEPTH = 100

    class Erode:
        """Is for the plug-in, erode."""
        DIRECTION_MASK_0 = 0
        DIRECTION_MASK_7 = 7
        FULL_RATE = 1.
        LOW_LIMIT_0 = 0
        PROPAGATE_BLACK = 1
        PROPAGATE_OPAQUE = 6
        RGB_CHANNELS = 7
        UPPER_LIMIT_128 = 128
        UPPER_LIMIT_255 = 255

    class GaussRLE2:
        """Is for the plug-in, gauss RLE2."""
        BLUR_HORZ_3 = 3
        BLUR_VERT_36 = 36

    class GradientFill:
        """Is for gimp_drawable_edit_gradient_fill."""
        OFFSET_0 = 0
        SUPERSAMPLE_MAX_DEPTH_2 = 2
        YES_DITHER = 1
        YES_SUPERSAMPLE = 1
        SUPERSAMPLE_THRESHOLD_0 = 0.

    class HSVNoise:
        """Is for plug_in_hsv_noise."""
        MEDIUM_HOLDNESS = 4

    class HueSaturation:
        """Is for hue_saturation."""
        HUE_OFFSET_0 = 0
        LIGHTNESS_0 = 0
        OVERLAP_0 = 0
        SATURATION_MINUS_100 = -100
        SATURATION_MINUS_35 = -35
        SATURATION_MINUS_95 = -95

    class LayerScale:
        """Is for gimp_layer_scale."""
        IMAGE_ORIGIN = 1

    class Mosaic:
        """If for the plug-in, mosaic."""
        BLACK_AND_WHITE_GROUT = 0
        LIGHT_ANGLE_0 = 0.
        LIGHT_ANGLE_45 = 45.
        MIN_COLOR_VARIATION = 0.
        NO_SPLIT = 0
        SMOOTH_SURFACE = 0
        TILE_HEIGHT_1 = 1.
        TILE_HEIGHT_4 = 4.
        TILE_NEATNESS_MIDDLE = .5
        TILE_SPACING_1 = 1.
        TILE_SPACING_MIN = .1
        TRIANGLE_TYPE = 3
        YES_ANTIALIAS = 1
        YES_COLOR_AVERAGING = 1

    class NewsPrint:
        """Is for plug_in_newsprint."""
        BLACK_100 = 100
        CELL_WIDTH_12 = 12
        RGB = 1
        SAMPLE_2 = 2

    class Oilify:
        """Is for plug_in_oilify."""
        RGB_MODE = 0

    class PaintBrush:
        """Is for gimp_paintbrush."""
        GRADIENT_LENGTH_0 = 0
        NO_FADE_OUT = 0
        STROKES_2 = 2

    class PickColor:
        """Is for gimp_image_pick_color."""
        NO_SAMPLE_MERGED = 0
        YES_SAMPLE_RADIUS = 1

    class Plasma:
        """Is for the plug-in, plasma."""
        LOWEST_TURBULENCE = 1.
        MEDIUM_TURBULENCE = 3.5

    class RGBNoise:
        """Is for the plug-in, plug_in_rgb_noise."""
        YES_INDEPENDENT = 1
        NO_CORRELATED = 0
        NOISE_TENTH = .1
        NOISE_ZERO = 0.

    class Rotate:
        """Is for gimp_item_transform_rotate."""
        AUTO_CENTER_YES = 1
        CENTER_X_0 = CENTER_Y_0 = 0.

    class SolidNoise:
        """Is for the plug-in, plug_in_solid_noise."""
        HORIZONTAL_SIZE_2 = 2
        MEDIUM_DETAIL = 7
        NO_TILEABLE = 0
        VERTICAL_SIZE_2 = 2
        YES_TURBULENT = 1

    class UnsharpMask:
        """Is for the plug-in, unsharp mask."""
        AMOUNT_1 = 1.
        AMOUNT_2 = 2.
        AMOUNT_5 = 5.
        AMOUNT_POINT_16 = .16
        RADIUS_3 = 3.
        RADIUS_5 = 5.
        RADIUS_12 = 12.
        THRESHOLD_0 = 0.
        THRESHOLD_42 = .42

    class TextFontName:
        """Is for the GIMP function, gimp_text_fontname."""
        BORDER_0 = 0

    class Waves:
        """Is for plug_in_waves."""
        PHASE_1 = 1.
        SMEARED = 1
        USE_REFLECTION = 1

    class Wind:
        """Is for the plug-in, wind."""
        BLAST = 1
        FROM_BOTTOM = 3
        FROM_LEFT = 0
        FROM_RIGHT = 1
        FROM_TOP = 2
        LEADING_EDGE = 1
        STRENGTH_25 = 25
        STRENGTH_30 = 30
        STRENGTH_50 = 50
        THRESHOLD_0 = 0
        THRESHOLD_10 = 10
        TRAILING_EDGE = 0
        WIND = 0
