#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import ImageEffect
from roller_one_constant import (
    BackdropStyleKey as bsk,
    ForBackdropStyle as fbs,
    ForGradient,
    OptionKey as ok
)

ek = ImageEffect.Key
BACKDROP_IMAGE_DEPENDENT = ok.BACKDROP_BLUR, ok.FIT_IMAGE, ok.INVERT
MAZES = fbs.FILLED, fbs.COMPOSITION_FRAME, fbs.SCATTERED_MAZES
VECTOR_DEPENDENT = ok.START_X, ok.START_Y, ok.DIAGONAL_ROTATION


class OptionDependent:
    """
    Manage dependent image-effect and backdrop-style option widgets.
    """

    def __init__(self, win, stat):
        """
        Initialize variables.

        win: RollerWindow
            responsible owner

        stat: Stat
            globals
        """
        self.win = win
        self.stat = stat

    @staticmethod
    def _init_backdrop_image(option_group):
        """
        Add connections for widget dependencies.

        option_group: OptionGroup
            Has widget list.
        """
        dependent = []

        d = option_group.widget_dict
        button = d[ok.BACKDROP_IMAGE]

        for i in BACKDROP_IMAGE_DEPENDENT:
            g = d[i]
            dependent.append(g)
        button.attach_dependent(dependent)

    def _init_frame_gradient(self, option_group):
        """
        Add connections for widget dependencies.

        option_group: OptionGroup
            Has widget list.
        """
        dependent_widget = []
        d = option_group.widget_dict
        combobox = d[ok.GRADIENT_TYPE]
        combobox.dependent_widget = dependent_widget

        for k in fbs.POINT_KEY:
            if k in d:
                dependent_widget.append(d[k])
        combobox.attach_dependent([self.on_gradient_type_change])

    def _init_gradient_pipe(self, option_group):
        """
        Use to set-up widget dependencies.

        option_group: OptionGroup
            Has widget group info.
        """
        d = option_group.widget_dict
        d[ok.NOISE_MODE].widgets = d[ok.NOISE_OPACITY], d[ok.RANDOM_SEED]
        d[ok.NOISE_MODE].attach_dependent([self.on_gradient_pipe_change])

    def _init_image_gradient(self, option_group):
        """
        Use to set-up widget dependencies.

        option_group: OptionGroup
            Has widget group info.
        """
        d = option_group.widget_dict
        d[ok.SAMPLE_VECTOR].widgets = []

        for i in VECTOR_DEPENDENT:
            d[ok.SAMPLE_VECTOR].widgets.append(d[i])
        d[ok.SAMPLE_VECTOR].attach_dependent([self.on_image_gradient_change])

    def _init_jagged_edge(self, option_group):
        """
        Update sub-navigation list for the latest Jagged Edge shadow.

        option_group: OptionGroup
            Has widget list.
        """
        d = option_group.widget_dict
        shadow = d[ok.SHADOW]
        make_opaque = d[ok.MAKE_OPAQUE]
        shadow_blur = d[ok.SHADOW_BLUR]
        intensity = d[ok.INTENSITY]
        shadow_color = d[ok.SHADOW_COLOR]
        shadow.dependent_widget = [
            make_opaque,
            shadow_blur,
            intensity,
            shadow_color
        ]
        shadow.attach_dependent([self.on_shadow_changed])

    def _init_maze_mirror(self, option_group):
        """
        Use to set-up widget dependencies.

        option_group: OptionGroup
            Has widget group info.
        """
        d = option_group.widget_dict
        cell_gap = d[ok.CELL_GAP]
        gap_type = d[ok.GAP_TYPE]
        stop_length = d[ok.STOP_LENGTH]
        scatter_count = d[ok.SCATTER_COUNT]
        maze_type = d[ok.MAZE_TYPE]
        _dir = d[ok.MAZE_DIRECTION]

        for i in d:
            d[i].widgets = stop_length, cell_gap, scatter_count, gap_type, _dir
        for i in (maze_type, gap_type):
            i.attach_dependent([self.on_maze_widget_change])

    def init_widget_state(self, branch, opt_key, option_group):
        """
        Use to set-up widget dependencies.

        branch: Branch
            Has navigation lists.

        opt_key: string
            either effect or style
        """
        self._branch = branch
        d = {
            bsk.BACKDROP_IMAGE: self._init_backdrop_image,
            bsk.BACKDROP_STYLE: self._branch.init_option_list,
            bsk.GRADIENT_FILL: self._init_frame_gradient,
            bsk.IMAGE_GRADIENT: self._init_image_gradient,
            bsk.SPECIMEN_SPECKLE: self._init_frame_gradient,
            ek.FRAME_GRADIENT: self._init_frame_gradient,
            ek.GRADIENT_LEVEL: self._init_gradient_pipe,
            ek.GRADIENT_PIPE: self._init_gradient_pipe,
            ek.IMAGE_EFFECT: self._branch.init_option_list,
            ek.JAGGED_EDGE: self._init_jagged_edge,
            ek.MAZE_MIRROR: self._init_maze_mirror
        }
        if opt_key in d:
            d[opt_key](option_group)

    def on_gradient_pipe_change(self, g):
        """
        Update sub-gradient pipe noise widget visibility.

        g: RollerComboBox
            Has changed.
            Is noise mode.
        """
        if g.get_value() == ok.NONE:
            for i in g.widgets:
                i.hide()

        else:
            for i in g.widgets:
                i.show()
        self.win.resize()

    def on_gradient_type_change(self, g):
        """
        Update sub-gradient widget visibility.

        g: RollerComboBox
            Has changed.
        """
        if g.get_value() in ForGradient.SHAPE_BURST:
            for i in g.dependent_widget:
                i.hide()

        else:
            for i in g.dependent_widget:
                i.show()
        self.win.resize()

    def on_image_gradient_change(self, g):
        """
        Update image-gradient widget visibility.

        g: RollerComboBox
            Has changed.
        """
        n = g.get_value()
        start_x, start_y, _dir = g.widgets

        if n == fbs.HORIZONTAL:
            start_x.hide()
            start_y.show()
            _dir.hide()

        elif n == fbs.VERTICAL:
            start_x.show()
            start_y.hide()
            _dir.hide()

        else:
            start_x.hide()
            start_y.hide()
            _dir.show()
        self.win.resize()

    def on_maze_widget_change(self, g):
        """
        Update widgets based their dependency to a given widget.

        widget: Widget
            of Maze Mirror
        """
        value = g.get_value()
        k = g.key
        stop_length, cell_gap, scatter_count, gap_type, _dir = g.widgets

        if k == ok.MAZE_TYPE:
            if value in MAZES:
                stop_length.show()
                _dir.show()

            else:
                stop_length.hide()
                _dir.hide()

            if value in (fbs.FILLED, fbs.COMPOSITION_FRAME):
                for i in (cell_gap, scatter_count, gap_type):
                    i.hide()

            else:
                for i in (cell_gap, scatter_count, gap_type):
                    i.show()

        if gap_type.get_value() == fbs.RANDOM:
            cell_gap.hide()

        else:
            cell_gap.show()
        self.win.resize()

    def on_shadow_changed(self, g):
        """
        Update sub-navigation list with the latest
        selection from the Jagged Edge shadow widget.

        g: Widget
            Jagged Edge ComboBox with shadow options
        """
        option = g.get_value()
        make_opaque, shadow_blur, intensity, shadow_color = g.dependent_widget
        q = shadow_blur, intensity, shadow_color

        if option in (ek.INLAY_SHADOW, ok.NONE):
            make_opaque.hide()

        elif option == ek.DROP_SHADOW:
            make_opaque.show()

        if option in (ek.INLAY_SHADOW, ek.DROP_SHADOW):
            for i in q:
                i.show()

        else:
            # no shadow:
            for i in q:
                i.hide()
        self.win.resize()
