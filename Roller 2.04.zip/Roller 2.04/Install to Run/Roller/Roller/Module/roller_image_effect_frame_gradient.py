#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_style_gradient_fill import GradientFill
from roller_image_effect import LayerKey
from roller_one import One
from roller_one_constant import (
    ForOption as fo,
    ForLayer,
    OptionKey as ok
)
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb


class FrameGradient:
    """
    Create a gradient for an image-effect frame.

    Give the frame color and light.
    """

    def __init__(self, one):
        """
        Do a Frame Gradient effect.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        j = stat.render.image
        parent = self.parent = one.parent
        z = frame_layer = Lay.search(parent, LayerKey.FRAME)
        d = self.d = deepcopy(one.d)
        d.update(
            {
                ok.BUMP: {ok.BUMP: fo.HAS_NO_BUMP},
                ok.MODE: "Normal"
            }
        )
        self.option_key = one.k

        Sel.item(j, z)

        self.sel = stat.save_selection()
        z = FrameGradient.add_metal_layer(j, z, parent)

        GradientFill(
            One(
                d=d,
                k=one.k,
                session=one.session,
                stat=stat,
                z=z
            ),
            make_opaque=True
        )

        z = j.active_layer

        # backdrop light:
        if not Lay.search(j, LayerKey.BACKDROP_LIGHT, is_err=0):
            z1 = Lay.clone(j, z)
            z1.opacity = ForLayer.BACKDROP_LIGHT_OPACITY
            z1.name = Lay.get_layer_name(LayerKey.BACKDROP_LIGHT)

            # Place below the last format group:
            for x, i in enumerate(j.layers):
                if pdb.gimp_item_is_group(i):
                    x1 = x
            Lay.order(j, z1, None, offset=x1 + 1)

        if Lay.search(parent, LayerKey.REFLECTION, is_err=0):
            z1 = Lay.clone(j, z)
            z1.opacity = ForLayer.BACKDROP_LIGHT_OPACITY
            z1.name = Lay.get_layer_name(
                LayerKey.REFLECTION,
                parent=parent
            )
            z2 = Lay.search(parent, LayerKey.FILLER)

            Lay.order(j, z1, parent, offset=0)
            Sel.item(j, z2)
            Sel.clear_outside_of_selection(j, z1)

        z.mode = fu.LAYER_MODE_OVERLAY

        Sel.load(j, self.sel)
        Sel.clear_outside_of_selection(stat.render.image, z, keep_sel=1)
        self._blend_edge(frame_layer, parent)

    def _blend_edge(self, z, parent):
        """
        Blend the color of the background with edge of the frame.

        z: layer
            to clone from

        parent: layer
            format group
            for layer name
        """
        j = self.stat.render.image
        z = FrameGradient.add_edge_layer(j, z, parent)

        Sel.load(j, self.sel)
        pdb.gimp_selection_shrink(j, 1)

        a = self.stat.save_selection()

        Sel.load(j, self.sel)
        Sel.load(j, a, option=fu.CHANNEL_OP_SUBTRACT)

        edge_sel = self.stat.save_selection()

        pdb.gimp_selection_none(j)
        pdb.gimp_edit_copy_visible(j)

        z1 = Lay.paste(j, z)
        n = z.name

        Lay.blur(j, z1, 6)
        Sel.load(j, edge_sel)
        Sel.clear_outside_of_selection(j, z1)

        pdb.gimp_image_remove_layer(j, z)
        z1.mode = fu.LAYER_MODE_NORMAL
        z1.opacity = 51.
        z2 = Lay.clone(j, z1)
        z2.mode = fu.LAYER_MODE_HARDLIGHT
        z1 = Lay.merge(j, z2)
        z1.name = n

    @staticmethod
    def add_edge_layer(j, z, parent):
        """
        Add the edge layer.

        j: GIMP image
            work-in-progress

        z: layer
            to clone from

        parent: layer
            for layer name
            format group
        """
        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_OVERLAY
        z.name = Lay.get_layer_name(LayerKey.EDGE, parent=parent)
        return z

    @staticmethod
    def add_metal_layer(j, z, parent):
        """
        Add the metal layer.

        j: GIMP image
            work-in-progress

        z: layer
            to clone from

        parent: layer
            for layer name
            format group
        """
        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_OVERLAY
        z.name = Lay.get_layer_name(LayerKey.METAL, parent=parent)

        Lay.color_fill(z, (127, 127, 127))
        return z
