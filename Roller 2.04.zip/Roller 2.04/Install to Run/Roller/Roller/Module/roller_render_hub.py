#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_image_effect import ImageEffect, LayerKey
from roller_one_base import Base, Comm
from roller_one_constant import (
    ForFill,
    ForLayer,
    ForOption as fo,
    FormatKey as fk,
    OptionKey as ok,
    SessionKey as sk
)
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay, Sel
from roller_one_mode import Mode
import gimpfu as fu
import math

ek = ImageEffect.Key
em = Pdb.Emboss
pdb = fu.pdb
rn = Pdb.RGBNoise
BLUR_BG_AMOUNT = 16
BOTTOM_LAYER = (
    LayerKey.CELL_PLAQUE_BLUR_BEHIND,
    LayerKey.CELL_FRINGE,
    LayerKey.CELL_PLAQUE,
    LayerKey.LAYER_FRINGE,
    LayerKey.LAYER_PLAQUE,
    LayerKey.LAYER_PLAQUE_BLUR_BEHIND
)
BRIGHTNESS_ZERO = 0
ONE_PIXEL = 1.
SAME_XY = 0.
SHADOW_LAYER = (
    ek.DROP_SHADOW,
    ek.FILL_LIGHT_SHADOW,
    ek.KEY_LIGHT_SHADOW
)
ZERO_ANGLE = 0.

# dependent:
HIDE_LAYER = SHADOW_LAYER + (LayerKey.IMAGE,)
sn = Pdb.SolidNoise


class RenderHub:
    """
    Use with image-effect and backdrop-style options.

    Many thanks to Ofnuts for some of the source code which can be found at:
    sourceforge.net/projects/gimp-tools/s
    """

    @staticmethod
    def blur_behind_frame(parent, stat, format_x):
        """
        Blur behind transparency material.

        parent: layer
            format group

        stat: Stat
            globals

        format_x: int
            format index
        """
        j = stat.render.image
        z = Lay.search(parent, LayerKey.TRANSPARENCY, is_err=False)

        if not z:
            z = Lay.search(parent, LayerKey.FILLER, is_err=False)

        if z:
            Lay.hide_layers_above(parent, z)
            Lay.hide_format_stack(stat, format_x)
            pdb.gimp_selection_all(j)

            q = []

            for i in HIDE_LAYER:
                z1 = Lay.search(parent, i, is_err=0)
                if z1:
                    Lay.hide(z1)
                    q.append(z1)

            pdb.gimp_edit_copy_visible(j)

            for i in q:
                Lay.show(i)

            Lay.show_layer_on_top(parent, z)
            Lay.show_format_groups(stat)

            z1 = Lay.search(parent, LayerKey.IMAGE)
            z1 = Lay.paste(j, z1)

            pdb.gimp_layer_set_offsets(z1, 0, 0)

            # If there's only transparency, then the blur-behind is pointless:
            z1.name = Lay.get_layer_name(
                LayerKey.BLURRED_BACKGROUND,
                parent=parent
            )
            if Lay.has_pixel(j, z1):
                z2 = Lay.selectable(j, z, ForLayer.MAKE_OPAQUE_DICT)

                Lay.blur(j, z1, BLUR_BG_AMOUNT)
                Sel.item(j, z2)
                Sel.clear_outside_of_selection(j, z1)
                pdb.gimp_image_remove_layer(j, z2)

                # Move the blur-behind layer to be
                # above the plaque and fringe layers:
                a = 1

                for i in BOTTOM_LAYER:
                    z3 = Lay.search(parent, i, is_err=0)
                    if z3:
                        a += 1
                Lay.order(j, z1, parent, offset=len(parent.layers) - a)

    @staticmethod
    def blur_shadow(session, stat):
        """
        Simulate shadow blur of a transparent frame.

        session: dict
            of session

        stat: Stat
            Has render.
        """
        j = stat.render.image
        for form in session[sk.FORMAT_LIST]:
            parent = stat.render.format_group(None, form[fk.Layer.NAME])
            z = Lay.search(parent, LayerKey.TRANSPARENCY, is_err=False)

            if not z:
                z = Lay.search(parent, LayerKey.FILLER, is_err=False)

            if z:
                for i in SHADOW_LAYER:
                    z1 = Lay.search(parent, i, is_err=0)
                    if z1:
                        z2 = Lay.clone(j, z1)

                        Lay.blur(j, z2, BLUR_BG_AMOUNT)
                        Sel.item(j, z)
                        Sel.clear_outside_of_selection(j, z2, keep_sel=1)
                        Lay.clear_sel(j, z1)
                        Lay.merge(j, z2)

    @staticmethod
    def brush_stroke(z, pos, angle, callback):
        """
        Make a brush stroke.

        z: layer
            to receive brush stroke

        pos: list
            of points

        angle: float
            of brush

        callback: function
            call for each stroke
        """
        if callback:
            callback()

        pdb.gimp_context_set_brush_angle(angle)
        pdb.gimp_paintbrush_default(z, 2, pos)

    @staticmethod
    def brush_stroke_on_stroke(
        z,
        brush,
        brush_size,
        stroke,
        spacing,
        callback=None
    ):
        """
        Brush stroke the path.

        z: layer
            to receive brush stroke
            Has a stroke-path.

        brush: string
            GIMP brush

        brush_size: float
            size of brush

        stroke: GIMP path
            to receive brush

        spacing: numeric
            distance between the strokes

        callback: function
            a callback for each brush stroke
        """
        base_angle = 0.
        length = stroke.get_length(.01)
        points, closed = stroke.points
        intervals = round((length / spacing))
        interval_length = length / intervals

        pdb.gimp_context_set_brush(brush)
        pdb.gimp_context_set_brush_size(brush_size)
        pdb.gimp_context_set_brush_aspect_ratio(0.)
        pdb.gimp_context_set_dynamics('Dynamics Off')
        pdb.gimp_context_set_brush_spacing(.5)
        pdb.gimp_context_set_brush_force(.6)
        pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_brush_hardness(1.)

        # first point:
        RenderHub.brush_stroke(
            z,
            points[2:4],
            RenderHub.calc_stroke_angle(
                points[2:4],
                RenderHub.get_origin_tangent(stroke),
                base_angle
            ),
            callback
        )

        # special case for first and last:
        for step in range(1, int(intervals)):
            x1, y1 = stroke.get_point_at_dist(
                step * interval_length,
                .01
            )[0:2]
            x2, y2 = stroke.get_point_at_dist(
                .5 + step * interval_length,
                .01
            )[0:2]
            RenderHub.brush_stroke(
                z,
                (x1, y1),
                RenderHub.calc_stroke_angle(
                    (x1, y1),
                    (x2, y2),
                    base_angle
                ),
                callback
            )

        # last point:
        if not closed:
            RenderHub.brush_stroke(
                z,
                points[-4:-2],
                RenderHub.calc_stroke_angle(
                    RenderHub.get_end_tangent(stroke),
                    points[-4:-2],
                    base_angle
                ),
                callback
            )

    @staticmethod
    def bump(j, z, d, merge=0, stat=0):
        """
        Add bump to a layer.

        j: GIMP image
            work-in-progress

        z: layer
            work-in-progress

        d: dict
            Has options.

        merge: flag
            When true, the bump layer is merged down.

        stat: Stat
            Has save selection function.
            When set, the selection is restored.

        Return: layer or None
            Return merged layer if merge.
        """
        if d[ok.BUMP] == fo.HAS_BUMP:
            if stat:
                sel = stat.save_selection()

            if merge:
                z = Lay.clone(j, z)
                z.opacity = 100.

            z.mode = fu.LAYER_MODE_OVERLAY
            f = d[ok.NOISE]

            if f:
                pdb.plug_in_rgb_noise(
                    j,
                    z,
                    rn.YES_INDEPENDENT,
                    rn.NO_CORRELATED,
                    f,
                    f,
                    f,
                    rn.NOISE_ZERO
                )

            pdb.plug_in_emboss(
                j,
                z,
                d[ok.LIGHT_ANGLE],
                d[ok.BUMP_ELEVATION],
                d[ok.BUMP_DEPTH],
                em.EMBOSS
            )

            if merge:
                z = Lay.merge(j, z)

            if stat:
                Sel.load(j, sel)
        return z

    @staticmethod
    def calc_gradient(color, color1, steps):
        """
        Return the color-steps for a gradient.

        A color-step is a value that is added to one color's
        components in order for the color to become the second color.
        Each color component will have its own color-step.

        color, color1: tuple
            RGB
            of int

        steps: int
            the number of steps
        """
        delta = [0, 0, 0]
        step = [0, 0, 0]

        # Need the color distance to calculate a color step:
        if steps > 1:
            for x in range(3):
                delta[x] = abs(color[x] - color1[x]) / 1. / (steps - 1)

            # The color step can be positive or negative:
            for x in range(3):
                if color[x] > color1[x]:
                    step[x] = -delta[x]

                elif color[x] < color1[x]:
                    step[x] = delta[x]
        return step

    @staticmethod
    def calc_stroke_angle(p1, p2, base_angle):
        """
        Calculate the angle of the brush given the
        base angle and a point with a tangent.

        p1, p2: points
            Form a tangent.

        base_angle: float
            of brush
        """
        x1, y1 = p1
        x2, y2 = p2
        alpha = math.degrees(math.atan2(y1 - y2, x1 - x2))
        return ((base_angle + alpha) % 360.) - 180.

    @staticmethod
    def create_shadow_unit(stat, layer, caster_key):
        """
        Create a unified shadow layer.

        stat: Stat
            Has render.

        layer: layer
            group where unified-shadow layer belongs

        caster_key: iterable
            layer keys for layers to merge
            Form a single shadow casting unit.

        Return:
            z: layer
                unified shadow layer

            caster_layer: list
                Are layers that are contributing to the shadow-unit.
        """
        caster_layer = []

        # Put layer(s) into a group and merge group:
        j, z = stat.render.image, layer
        group = Lay.group(stat.render.image, "Cast", parent=z)

        for k in caster_key:
            z1 = Lay.search(z, k)
            z2 = Lay.clone(j, z1)

            Lay.order(j, z2, group)
            Lay.hide(z1)
            caster_layer.append(z1)

        z = Lay.merge_group(j, group)
        return z, caster_layer

    @staticmethod
    def do_cartoony(j, z, z1, color):
        """
        Create a cartoony color frame for gradient frames.

        j: GIMP image
            work-in-progress

        z: layer
            Has frame.

        z1: layer
            Has noise.

        color: tuple
            RGB
            to colorize noise
        """
        group = Lay.group(j, z.name, parent=z.parent)

        Lay.order(j, z, group)
        Lay.order(j, z1, group)

        opacity = z1.opacity
        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_HSV_VALUE

        Lay.order(j, z, group, offset=0)

        z1 = Lay.clone(j, z1)
        z1.mode = fu.LAYER_MODE_LCH_COLOR
        z1.opacity = opacity

        pdb.plug_in_colorify(j, z1, color)
        Lay.merge_group(j, group)

    @staticmethod
    def do_grid(stat, z, q, is_vertical=1):
        """
        Draw grid lines.

        The grid lines are either horizontal
        or vertical, but not both.

        stat: Stat
            Has render.

        z: layer
            Draw on layer.

        q: tuple
            arguments for vertical or horizontal lines

        is_vertical: flag
            If it's true, the arguments are for vertical lines.
        """
        args = stat.render.image, z
        q1 = 0, 0, 0, (0, 0, 0), 0

        if is_vertical:
            args += q1 + q + q1

        else:
            args += q + q1 * 2
        pdb.plug_in_grid(*args)

    @staticmethod
    def do_rotated_layer(stat, z, d, p):
        """
        Create an enlarged layer before rotating.

        Use the callback to process the rotated layer.

        stat: Stat
            globals

        z: layer
            Is the layer that gets rotated and processed.

        d: dict
            Has options.

        p: callback
            Call to act on the rotated layer before it is returned.

        Return: layer
            the rotated layer
        """
        d = deepcopy(d)
        z1 = z
        j = stat.render.image
        w, h = stat.render.size

        if d[ok.ROTATE]:
            # Create a new image for the rotation:
            f = Base.circumradius(w, h) * 2
            j = pdb.gimp_image_new(f, f, fu.RGB)
            z = Lay.add(j, "Rotate")
            pdb.gimp_image_set_active_layer(j, z)

        else:
            z = Lay.clone(stat.render.image, z)

        z = p(j, z, d)

        if d[ok.ROTATE]:
            z = Lay.clone(j, z)

            pdb.gimp_item_transform_rotate(
                z, math.radians(d[ok.ROTATE]), 1, 0, 0)

            Lay.hide(j.layers[1])

            # Copy and paste the rotated gradient:
            Sel.rect(
                j,
                j.width // 2 - w // 2,
                j.height // 2 - h // 2,
                w,
                h,
                option=fu.CHANNEL_OP_REPLACE
            )

            pdb.gimp_edit_copy_visible(j)
            pdb.gimp_image_delete(j)
            z = Lay.paste(stat.render.image, z1)

        pdb.gimp_layer_resize_to_image_size(z)
        return z

    @staticmethod
    def do_shadow(
        stat,
        item,
        x,
        y,
        blur,
        color,
        intensity,
        layer_name="",
        d=None,
        is_inlay=0
    ):
        """
        Draw a drop shadow.

        Create a number of layers, group them, merge them,
        and then cast a shadow from the merged layer.

        If the shadow is an inlay shadow,
        create a layer to cast a shadow over the image.

        stat: Stat
            globals

        item: layer
            layer that casts shadow

        x: float
            offset x

        y: float
            offset y

        blur: float
            shadow blur

        color: tuple
            of int
            (R, G, B)
            shadow color

        intensity: int
            intensity

        layer_name: string
            owner's name
            Use to name the shadow layer.

        d: dict
            Has an 'OptionKey.MAKE_OPAQUE' item.

        is_inlay: flag
            if true, the selection is inverted.

        Return: layer
            the new shadow layer
        """
        j = stat.render.image
        item = Lay.clone(j, item)
        z = None

        if intensity:
            group = Lay.group(j, "Shadow")

            Lay.order(j, item, group)

            if is_inlay:
                z1 = Lay.add(j, "Inlay", parent=group)

                Lay.color_fill(z1, (255, 255, 255))

                z2 = Lay.selectable(j, item, d)

                Sel.item(j, z2)
                Lay.clear_sel(j, z1)
                pdb.gimp_image_remove_layer(j, item)
                pdb.gimp_image_remove_layer(j, z2)
                item = z1

            Sel.item(j, item)

            if not Sel.is_sel(j):
                intensity = 0

            # Increase shadow intensity by stacking duplicate shadow layers:
            while intensity:
                pdb.script_fu_drop_shadow(
                    j,
                    item,
                    x,
                    y,
                    blur,
                    color,
                    min(100., intensity),
                    Pdb.DropShadow.NO_RESIZING
                )

                intensity -= min(intensity, 100.)
                z = group.layers[0]
                while intensity >= 100:
                    z = Lay.clone(j, z)
                    intensity -= min(intensity, 100.)

            if not is_inlay:
                pdb.gimp_image_remove_layer(j, item)

            if is_inlay:
                Sel.item(j, z1)
                pdb.gimp_image_remove_layer(j, z1)

            z = Lay.merge_group(j, group, n=layer_name)

            if is_inlay:
                Lay.clear_sel(j, z)
            pdb.gimp_layer_resize_to_image_size(z)
        return z

    @staticmethod
    def do_stylish_shadow(
        stat,
        z,
        blur=15.,
        intensity=130.,
        offset_x=0,
        offset_y=0,
        d=None,
        is_inlay=0
    ):
        """
        stat: Stat
            globals

        z: layer
            to cast shadow

        blur: float
            shadow blur

        intensity: float
            shadow opacity

        offset_x: int
            shadow offset on x-axis (-, +)

        offset_y: int
            shadow offset on y-axis (-, +)

        d: inherit dict
            Has an MAKE_OPAQUE item.
            Use with the inlay option.

        is_inlay: flag
            If true, the shadow is an inlay type.

        Return: layer
            the shadow layer
        """
        parent = z.parent
        x = Lay.offset(z)
        z = RenderHub.do_shadow(
            stat,
            z,
            offset_x,
            offset_y,
            blur,
            (0, 0, 0),
            intensity,
            d=d,
            is_inlay=is_inlay
        )
        z.mode = fu.LAYER_MODE_NORMAL

        if is_inlay:
            x -= 1

        Lay.order(stat.render.image, z, parent, offset=x + 1)
        return z

    @staticmethod
    def draw_color_rectangles(j, z, w, h):
        """
        Draws two layer of colors stripes in order to create color rectangles.

        j: GIMP image
            work-in-progress

        z: layer
            layer to draw on

        w: int
            width of rectangle

        h: int
            height of rectangle

        Return: layer
            Has color grid.
        """
        # vertical panes:
        x = y = x1 = y1 = 0
        w1, h1 = j.width, j.height
        z.mode, z.opacity = fu.LAYER_MODE_NORMAL, 100.

        while x < w1:
            x1 = min(x1 + w, w1)

            Sel.rect(j, x, 0, x1 - x, h1, option=fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, Base.rnd_col())
            x = x1

        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        # horizontal panes:
        while y < h1:
            y1 = min(y1 + h, h1)

            Sel.rect(j, 0, y, w1, y1 - y, option=fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, Base.rnd_col())
            y = y1
        return Lay.merge(j, z)

    @staticmethod
    def draw_sel(stat, sel, z):
        """
        Draw a selection as black pixels on white pixels.

        sel: selection
            selection channel
            to fill with black

        z: layer
            to receive fill
        """
        Lay.color_fill(z, (255, 255, 255))
        Sel.load(stat.render.image, sel)
        Sel.fill(z, (0, 0, 0))
        pdb.gimp_selection_none(stat.render.image)

    @staticmethod
    def emboss(j, z, light, contrast):
        """
        Emboss a layer.

        j: GIMP image
            work-in-progress

        z: layer
            to receive emboss

        light: float
            angle
            (0 .. 360)

        contrast: int
            contrast

        Use the elevation of thirty to make grey value for the face.

        The depth of one does not blend the light and shadow.
        """
        pdb.plug_in_emboss(
            j,
            z,
            light,
            Pdb.Emboss.ELEVATION_30,
            Pdb.Emboss.DEPTH_1,
            Pdb.Emboss.EMBOSS
        )
        pdb.gimp_brightness_contrast(z, BRIGHTNESS_ZERO, contrast)

    @staticmethod
    def get_end_tangent(stroke):
        """
        Compute the position of the end-point for a tangent.

        stroke: path
            work-in-progress
        """
        points = stroke.points[0]
        xe, ye = points[-4:-2]
        xt, yt = points[-6:-4]
        if abs(xe - xt) < .0001 and abs(ye - yt) < .0001:
            xt, yt = stroke.get_point_at_dist(
                stroke.get_length(.001) - .5,
                .01
            )[0:2]
        return xt, yt

    @staticmethod
    def get_layer_points(d, w, h):
        """
        Return the layer points for start and end coordinates.

        d: dict
            Has start and end points.
            fraction-of-layer points
            (0 .. 1)

        w, h: int
            size of render or canvas

        return:
            start and end coordinates
            x, y, x1, y1
        """
        x1 = y1 = -1
        x = int(round(d[ok.START_X], 6) * w)
        y = int(round(d[ok.START_Y], 6) * h)

        if ok.END_X in d:
            x1 = min(int(round(d[ok.END_X], 6) * w), w - 1)
            y1 = min(int(round(d[ok.END_Y], 6) * h), h - 1)
        return x, y, x1, y1

    @staticmethod
    def get_mode(d):
        """
        Return the mode and opacity in an option dict.

        d: dict
            Has options.
        """
        return Mode.get_x(d[ok.MODE]), d[ok.OPACITY] / 1.

    @staticmethod
    def get_origin_tangent(stroke):
        """
        Compute the origin-point position of a tangent.

        stroke: path
            work-in-progress

        Return: tuple
            origin point
            x, y
        """
        points = stroke.points[0]
        xo, yo = points[2:4]
        xt, yt = points[4:6]

        if abs(xo - xt) < .001 and abs(yo - yt) < .001:
            xt, yt = stroke.get_point_at_dist(.5, .01)[0:2]
        return xt, yt

    @staticmethod
    def get_point_on_rectangle(s, angle):
        """
        Calculate an x, y coordinate for a point intersecting
        a ray, originating from the center of a rectangle,
        and ending at its defining lines.

        s: tuple or list
            size
            width, height
            of int

        angle: float
            degrees
            angle from center of the rectangle

        Return: point
            x, y
            of float or int
            the point on the rectangle
        """
        w, h = s
        angle = math.radians(angle)
        sine = math.sin(angle)
        cosine = math.cos(angle)

        # distance to the top or the bottom edge (from the center):
        dy = h / 2 if sine > 0 else h / -2

        # distance to the left or the right edge (from the center):
        dx = w / 2 if cosine > 0 else w / -2

        # (distance to the vertical line) < (distance to the horizontal line):
        if abs(dx * sine) < abs(dy * cosine):
            # Calculate distance to the vertical line:
            dy = (dx * sine) / cosine

        # (distance to the top or the bottom edge)
        # < (distance to the left or the right edge):
        else:
            dx = (dy * cosine) / sine
        return max(0., round(dx + w / 2., 0)), max(0., round(dy + h / 2., 0))

    @staticmethod
    def invert_color(q):
        """
        Generate an inverted color.

        q: tuple
            RGB

        Return: tuple
            RGB
            inverted color
        """
        return tuple([255 - i for i in q])

    @staticmethod
    def noise(stat, z, d):
        """
        Adds noise to a layer.

        stat: Stat
            globals

        z: layer
            layer that receives noise

        d: dict
            Has options.
        """
        if d[ok.POWER]:
            pdb.plug_in_solid_noise(
                stat.render.image,
                z,
                sn.NO_TILEABLE,
                sn.YES_TURBULENT,
                d[ok.RANDOM_SEED],
                sn.MEDIUM_DETAIL,
                sn.HORIZONTAL_SIZE_2,
                sn.VERTICAL_SIZE_2
            )
            pdb.plug_in_hsv_noise(
                stat.render.image,
                z,
                Pdb.HSVNoise.MEDIUM_HOLDNESS,
                d[ok.POWER],
                d[ok.POWER],
                d[ok.POWER]
            )

    @staticmethod
    def set_brush_details():
        """Set up the brush for drawing lines."""
        pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
        pdb.gimp_context_set_opacity(100.)

        try:
            pdb.gimp_context_set_brush('perspective')

        except RuntimeError:
            Comm.info_msg("Roller is unable to use the 'perspective' brush.")

        pdb.gimp_context_set_brush_size(ONE_PIXEL)
        pdb.gimp_context_set_brush_aspect_ratio(SAME_XY)
        pdb.gimp_context_set_brush_angle(ZERO_ANGLE)
        pdb.gimp_context_set_dynamics('Dynamics Off')
        pdb.gimp_context_set_brush_spacing(.5)
        pdb.gimp_context_set_brush_force(.6)
        pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_brush_hardness(.9)

    @staticmethod
    def set_fill_context(d):
        """
        Set the context for the current fill-type operation.

        Call before a bucket fill operation.

        d: dict
            Has options.
        """
        pdb.gimp_context_set_sample_threshold(d[ok.THRESHOLD])
        pdb.gimp_context_set_opacity(d[ok.OPACITY])
        pdb.gimp_context_set_paint_mode(Mode.get_x(d[ok.MODE]))
        pdb.gimp_context_set_sample_criterion(
            ForFill.CRITERION_LIST.index(d[ok.CRITERION])
        )
