#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerKey
from roller_format_form import Form
from roller_one_base import Comm
from roller_one_constant import (
    CellKey as ck,
    ForLayout,
    FormatKey as fk,
    FreeCellKey as fck,
    OptionKey as ok,
    SessionKey as sk
)
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

em = Pdb.Emboss
pdb = fu.pdb

FREE = ForLayout.FREE_CELL


class BallJoint:
    """
    Create a metallic image frame from a brush with overlapping circles.
    """

    def __init__(self, one):
        """
        Do the Ball Joint image-effect.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        j = stat.render.image
        d = one.d
        self.session = one.session
        self.form = None
        parent = one.parent
        self.format_name = Lay.get_format_name_from_group(parent)
        go = self.row = self.col = 0

        try:
            pdb.gimp_context_set_brush('dots')
            go = 1

        except RuntimeError:
            Comm.info_msg("Roller is unable to use the 'dots' brush.")

        if go:
            # Get the format dict:
            for x, i in enumerate(one.session[sk.FORMAT_LIST]):
                if i[fk.Layer.NAME] == self.format_name:
                    self.form = i
                    self.row, self.col = stat.layout.get_division(x)
                    break

            frame = Lay.get_layer_name(LayerKey.FRAME, parent)
            z = Lay.add(j, frame, parent)
            self.merged = Form.is_merge_cells(self.form)

            self._process_grid(j, z, d)
            self._process_free_range(j, z, d)

            pdb.gimp_drawable_hue_saturation(
                z,
                fu.HUE_RANGE_ALL,
                Pdb.HueSaturation.HUE_OFFSET_0,
                Pdb.HueSaturation.LIGHTNESS_0,
                Pdb.HueSaturation.SATURATION_MINUS_100,
                Pdb.HueSaturation.OVERLAP_0
            )

            z1 = Lay.clone(j, z)
            z1.mode = fu.LAYER_MODE_OVERLAY

            pdb.plug_in_emboss(
                j,
                z1,
                d[ok.LIGHT_ANGLE],
                em.ELEVATION_30,
                em.DEPTH_3,
                em.EMBOSS
            )

            z = Lay.merge(j, z1)

            pdb.gimp_selection_none(j)

            # Do one image at a time:
            for r in range(self.row):
                for c in range(self.col):
                    if self.merged:
                        s = self.form[fk.Cell.Grid.PER_CELL][r][c]

                    else:
                        # not a dependent cell:
                        s = 1

                    # Is it a dependent cell?
                    if s != (-1, -1):
                        sel = stat.get_image_sel(self.format_name, r, c)
                        if sel:
                            Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

            for e in reversed(self.form[fk.Layer.CELL_LIST]):
                sel = self.stat.get_image_sel(e[fck.CELL][ck.NAME], FREE, FREE)
                if sel:
                    Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
            Lay.clear_sel(j, z)

    def _process_grid(self, j, z, d):
        """
        Do effect for each image in the cell grid.

        j: GIMP image
            Is render.

        z: layer
            to receive effect

        d: dict
            Has options.
        """
        # Do one image at a time:
        for r in range(self.row):
            for c in range(self.col):
                if self.merged:
                    s = self.form[fk.Cell.Grid.PER_CELL][r][c]

                else:
                    # not a dependent cell:
                    s = 1

                # Is it a dependent cell?
                if s != (-1, -1):
                    sel = self.stat.get_image_sel(self.format_name, r, c)
                    self._process_image(j, z, d, sel)

    def _process_free_range(self, j, z, d):
        """
        Do the effect for any free-range cells.

        j: GIMP image
            work-in-progress
            Is render.

        z: layer
            to receive effect

        d: dict
            Has options.
        """
        for e in reversed(self.form[fk.Layer.CELL_LIST]):
            sel = self.stat.get_image_sel(e[fck.CELL][ck.NAME], FREE, FREE)
            self._process_image(j, z, d, sel)

    def _process_image(self, j, z, d, sel):
        """
        Do the effect for an image.

        j: GIMP image
            Is render.

        z: layer
            to receive effect

        d: dict
            Has options.
        """
        if sel:
            Sel.load(j, sel)
            pdb.plug_in_sel2path(j, z)

            stroke = j.active_vectors.strokes[0]

            pdb.gimp_selection_none(j)
            RenderHub.brush_stroke_on_stroke(
                z,
                'dots',
                d[ok.BRUSH_SIZE],
                stroke,
                d[ok.BRUSH_SIZE] / 15.
            )
