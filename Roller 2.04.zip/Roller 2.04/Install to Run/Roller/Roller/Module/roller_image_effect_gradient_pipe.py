#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import sqrt
from roller_image_effect import ImageEffect
from roller_one_constant import (
    ForBackdropStyle as fbs,
    ForLayer,
    OptionKey as ok
)
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import colorsys
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb


class GradientPipe:
    """Create a pipe with a gradient."""

    def __init__(self, one):
        """
        Do the Gradient Pipe image-effect.

        one: One
            Has variables.
        """
        stat = one.stat
        parent = one.parent
        d = one.d
        j = stat.render.image
        n = Lay.get_layer_name(ek.GRADIENT_PIPE, parent=parent)
        z = Lay.add(j, n, parent=parent)
        z1 = Lay.selectable(
            j,
            stat.render.get_image_layer(
                Lay.get_format_name_from_group(parent)
            ),
            ForLayer.MAKE_OPAQUE_DICT
        )
        color = d[ok.COLOR]
        steps = d[ok.FRAME_WIDTH]

        if d[ok.PIPE_TYPE]:
            GradientPipe.do_round_effect(j, z, z1, stat, color, steps)

        else:
            GradientPipe.do_bevel_effect(j, z, z1, stat, color, steps)

        pdb.gimp_image_remove_layer(j, z1)

        n = d[ok.NOISE_MODE]
        if n != ok.NONE:
            z1 = Lay.clone(j, z)
            z1.opacity = d[ok.NOISE_OPACITY]
            z1.mode = fbs.NOISE_LAYER_MODE[fbs.NOISE_MODE_LIST.index(n)]

            pdb.plug_in_plasma(
                j,
                z1,
                d[ok.RANDOM_SEED],
                Pdb.Plasma.LOWEST_TURBULENCE
            )

            Sel.item(j, z)
            Sel.clear_outside_of_selection(j, z1)

            if n == fbs.SYRUPY:
                pdb.plug_in_unsharp_mask(
                    j,
                    z1,
                    Pdb.UnsharpMask.RADIUS_5,
                    Pdb.UnsharpMask.AMOUNT_1,
                    Pdb.UnsharpMask.THRESHOLD_0
                )

            elif n == fbs.CARTOONY:
                RenderHub.do_cartoony(j, z, z1, color)
            if n != fbs.CARTOONY:
                Lay.merge(j, z1)

    @staticmethod
    def do_bevel_effect(j, z, z1, stat, color, steps):
        """
        Do color blend effect using a color and its luminosity.

        j: GIMP image
            work-in-progress

        z: layer
            to receive effect

        z1: layer
            has material to select

        stat: Stat
            globals

        color: tuple
            RGB

        steps: int
            the number of gradient steps
        """
        r, g, b = [i / 255. for i in color]
        hls = colorsys.rgb_to_hls(r, g, b)
        lum = hls[1]
        lum1 = .94 if lum < .5 else .06
        hls = hls[0], lum1, hls[2]
        color1 = GradientPipe.hls_to_rgb(hls)
        half = steps // 2

        if lum >= .5:
            q = color
            color = color1
            color1 = q

        step = RenderHub.calc_gradient(color, color1, half + steps % 2)
        start_color = color
        q = list(start_color)

        # The layer borders need to be set to the image size.
        # This is done by using a color fill. The problem
        # is the selection won't grow beyond the layer borders:
        pdb.gimp_selection_all(j)
        Lay.color_fill(z, (127, 127, 127))
        Lay.clear_sel(j, z)
        Sel.item(j, z1)

        for i in range(steps):
            sel = stat.save_selection()

            Sel.grow(j, 1, 0)
            Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
            Sel.fill(z, tuple(q))
            Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

            if i < half - 1:
                for x in range(3):
                    a = step[x] * (i + 1)
                    q[x] = start_color[x] + int(a)

            else:
                for x in range(3):
                    a = step[x] * (i - (half - 1))
                    q[x] = color1[x] - int(a)

        Sel.item(j, z1)
        Lay.clear_sel(j, z)

    @staticmethod
    def do_round_effect(j, z, z1, stat, color, steps):
        """
        Do color blend effect using a color and its luminosity.

        The round effect is calculated using the unit circle formula.
        So 'x' is the luminosity step, and 'y' is the luminosity result.

            x**2 + y**2 = 1

        j: GIMP image
            work-in-progress

        z: layer
            to receive effect

        z1: layer
            has material to select

        stat: Stat
            globals

        color: tuple
            RGB

        steps: int
            the number of gradient steps
        """
        r, g, b = [i / 255. for i in color]
        hsv = colorsys.rgb_to_hsv(r, g, b)
        value = hsv[2]
        value1 = .9 if value < .5 else .1
        base = min(value, value1)
        amplitude = abs(value - value1)
        half = steps / 2.

        # Are luminosity steps for the x-vector:
        step_x = 1. / half
        step_x2 = step_x / 2

        # 'a' is the x-value, 'offset' is the y-value:
        a = 1 - step_x2
        offset = amplitude * sqrt(1 - a * a) + base
        hsv = hsv[0], hsv[1], offset
        q = GradientPipe.hsv_to_rgb(hsv)

        # The layer borders need to be set to the image size.
        # This is done by using a color fill. The problem
        # is the selection won't grow beyond the layer borders:
        pdb.gimp_selection_all(j)
        Lay.color_fill(z, (127, 127, 127))
        Lay.clear_sel(j, z)
        Sel.item(j, z1)

        for i in range(steps):
            sel = stat.save_selection()

            Sel.grow(j, 1, 0)
            Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
            Sel.fill(z, tuple(q))
            Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

            if i < steps - 1:
                # 'luminosity' is on the  y-vector of the unit circle:
                a = 1 - step_x * (i + 1) - step_x2
                hsv = hsv[0], hsv[1], amplitude * sqrt(1 - a * a) + base
                q = GradientPipe.hsv_to_rgb(hsv)

        Sel.item(j, z1)
        Lay.clear_sel(j, z)

    @staticmethod
    def hls_to_rgb(q):
        """
        Calculate the RGB components from an HLS iterable.

        q: tuple or list
            of HLS

        return: list
            RGB
        """
        return [int(i * 255.) for i in colorsys.hls_to_rgb(*q)]

    @staticmethod
    def hsv_to_rgb(q):
        """
        Calculate the RGB components from an HSV iterable.

        q: tuple or list
            of HSV

        return: list
            RGB
        """
        return [int(i * 255.) for i in colorsys.hsv_to_rgb(*q)]
