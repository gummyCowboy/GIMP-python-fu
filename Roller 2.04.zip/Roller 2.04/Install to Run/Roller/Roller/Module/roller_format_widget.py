#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import (
    CaptionKey as ck,
    ForFormat as ff,
    ForGradient as fg,
    ForTriangle,
    ForWidget as fw,
    FringeKey,
    MaskKey,
    OptionKey as ok,
    PlaceKey,
    PlaqueKey,
    PropertyKey,
    WidgetKey as wk
)
from roller_one_preset import Preset
from roller_one_tip import Tip
from roller_widget_button import OptionButton, RollerColorButton
from roller_widget_check_button import RollerCheckButton
from roller_widget_combo import RollerComboBox
from roller_widget_entry import RollerEntry
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable
from roller_window_bump_choice import RWBumpChoice
from roller_window_choice import RWChoice
from roller_window_image_choice import RWImageChoice
from roller_window_margin import RWMargin
from roller_window_resize import RWResize
from roller_window_shadow import RWShadow
import gtk
import sys

FRINGE_TYPE_TOOLTIP = {
    ff.Fringe.GRADIENT: Tip.FRINGE_ABOUT_GRADIENT,
    ff.Fringe.IMAGE: Tip.FRINGE_ABOUT_IMAGE,
    ff.Fringe.MASK: Tip.FRINGE_ABOUT_MASK,
    ff.Fringe.ONE_COLOR: Tip.FRINGE_ABOUT_ONE_COLOR,
    ff.Fringe.PATTERN: Tip.FRINGE_ABOUT_PATTERN,
    ff.Fringe.TWO_COLOR:  Tip.FRINGE_ABOUT_TWO_COLOR
}
LABEL_INDEX, WIDGET_INDEX, ARGS_INDEX, KEY_ARGS_INDEX = range(4)
MASK_TYPE_TOOLTIP = {
    ff.Mask.CHARACTER: Tip.MASK_CHARACTER,
    ff.Mask.CIRCLE: Tip.MASK_CIRCLE,
    ff.Mask.CUT_CORNERS: Tip.MASK_CUT_CORNERS,
    ff.Mask.DIAMOND: Tip.MASK_DIAMOND,
    ff.Mask.IMAGE: Tip.MASK_IMAGE,
    ff.Mask.OVAL: Tip.MASK_OVAL,
    ok.NONE: "",
    ff.Mask.RECTANGLE: Tip.MASK_RECTANGLE,
    ff.Mask.RHOMBUS: Tip.MASK_RHOMBUS,
    ff.Mask.ROUNDED_CORNERS: Tip.MASK_ROUND_CORNERS,
    ff.Mask.SQUARE: Tip.MASK_SQUARE,
    ForTriangle.TRIANGLE_DOWN: Tip.MASK_TRIANGLE_DOWN,
    ForTriangle.TRIANGLE_LEFT: Tip.MASK_TRIANGLE_LEFT,
    ForTriangle.TRIANGLE_RIGHT: Tip.MASK_TRIANGLE_RIGHT,
    ForTriangle.TRIANGLE_UP: Tip.MASK_TRIANGLE_UP
}

PAD = fw.MARGIN

SAME_SIZE_FRINGE = (
    ff.Fringe.Index.ANGLE,
    ff.Fringe.Index.BRUSH_SIZE,
    ff.Fringe.Index.CONTRACT,
    ff.Fringe.Index.HARDNESS,
    ff.Fringe.Index.OPACITY,
    ff.Fringe.Index.SPACING
)
SAME_SIZE_PROPERTY = (
    ff.Property.Index.BLUR_BEHIND,
    ff.Property.Index.OPACITY,
    ff.Property.Index.ROTATE
)

VERIFY_CAPTION = (
    ck.CELL_CAPTION,
    ck.FREE_CELL_CAPTION,
    ck.LAYER_CAPTION,
    ck.OPACITY,
    ck.TEXT,
    ck.TYPE
)
VERIFY_FRINGE = (
    FringeKey.CELL_FRINGE,
    FringeKey.GRADIENT,
    FringeKey.GRADIENT_TYPE,
    FringeKey.IMAGE,
    FringeKey.LAYER_FRINGE,
    FringeKey.OPACITY,
    FringeKey.TYPE
)
VERIFY_MASK = MaskKey.TYPE, MaskKey.IMAGE, MaskKey.IMAGE_MASK
VERIFY_PLACE = PlaceKey.IMAGE, PlaceKey.RESIZE, PlaceKey.IMAGE_PLACE
VERIFY_PLAQUE = (
    PlaqueKey.CELL_PLAQUE,
    PlaqueKey.GRADIENT,
    PlaqueKey.GRADIENT_TYPE,
    PlaqueKey.IMAGE,
    PlaqueKey.LAYER_PLAQUE,
    PlaqueKey.OPACITY,
    PlaqueKey.TYPE
)


class FormatWidget:
    """Has common functions used by PortFormat and PortCell."""

    @staticmethod
    def _set_mask_type_tooltip(g):
        """
        Set the tooltip for a mask-type widget from the image mask group.

        g: Widget
            Has changed.
        """
        # If it the mask type widget:
        if g == g.preset.widget_list[ff.Mask.Index.TYPE]:
            n = g.get_value()
            if n in ff.Mask.TYPE:
                tooltip = MASK_TYPE_TOOLTIP[n]
                g.set_tooltip_text(tooltip)

    @staticmethod
    def _set_fringe_type_tooltip(g):
        """
        Set the tooltip for a fringe-type widget from the fringe group.

        g: Widget
            Has changed.
        """
        # If it the mask type widget:
        if g == g.preset.widget_list[ff.Fringe.Index.TYPE]:
            n = g.get_value()
            if n in ff.Fringe.TYPE and n != ok.NONE:
                tooltip = FRINGE_TYPE_TOOLTIP[n]
                g.set_tooltip_text(tooltip)

    @staticmethod
    def draw_caption_group(**d):
        """
        Draw the widgets for cell caption.

        d: dict
            Has init values.

        Return: list
            of widget
        """
        key = d['sub_type']
        is_per_cell = 0 if 'is_per_cell' not in d else 1

        if is_per_cell:
            type_list = ff.Caption.NO_SEQUENCE_LIST
            index_type = ff.Caption.Cell.Index
            clip = "Cell"

        elif key == ck.CELL_CAPTION:
            type_list = ff.Caption.CELL_TYPE_LIST
            index_type = ff.Caption.Cell.Index
            clip = "Cell"

        elif key == ck.FREE_CELL_CAPTION:
            type_list = ff.Caption.FREE_CELL_TYPE_LIST
            index_type = ff.Caption.FreeCell.Index
            clip = "Cell"

        elif key == ck.LAYER_CAPTION:
            type_list = ff.Caption.LAYER_TYPE_LIST
            index_type = ff.Caption.Layer.Index
            clip = "Layer"

        q = (
            [
                "Type:",
                RollerComboBox,
                dict(
                    d,
                    key=ck.TYPE,
                    combo_list=type_list
                )
            ],
            [
                "Text:",
                RollerEntry,
                dict(
                    d,
                    key=ck.TEXT,
                    chars=10
                )
            ]
        )

        if key == ck.CELL_CAPTION:
            q += (
                [
                    "Start Number:",
                    RollerSlider,
                    dict(
                        d,
                        key=ck.START_NUMBER,
                        limit=(-sys.maxint, sys.maxint),
                        precision=0,
                        tooltip=Tip.CAPTION_START_NUMBER,
                    )
                ],
            )

        if key in (ck.CELL_CAPTION, ck.FREE_CELL_CAPTION):
            q += (
                [
                    "Leading Text:",
                    RollerEntry,
                    dict(
                        d,
                        key=ck.LEADING_TEXT,
                        chars=10,
                        tooltip=Tip.CAPTION_LEADING_TEXT
                    )
                ],
                [
                    "Trailing Text:",
                    RollerEntry,
                    dict(
                        d,
                        key=ck.TRAILING_TEXT,
                        chars=10,
                        tooltip=Tip.CAPTION_TRAILING_TEXT
                    )
                ]
            )

        q += (
            [
                "Font:",
                OptionButton,
                dict(d, choice_window=RWChoice, key=ck.FONT)
            ],
            [
                "Font Size:",
                RollerSlider,
                dict(d, key=ck.SIZE, limit=(4, 1000), precision=0)
            ],
            [
                "Color:",
                RollerColorButton,
                dict(d, key=ck.COLOR)
            ],
            [
                "Margins",
                OptionButton,
                dict(
                    d,
                    choice_window=RWMargin,
                    key=ck.MARGIN,
                    tip_type=ff.MARGIN_TIP_TYPE
                ),
            ],
            [
                "Justification:",
                RollerComboBox,
                dict(
                    d,
                    key=ck.JUSTIFICATION,
                    combo_list=ff.Caption.JUSTIFICATION_LIST
                )
            ],
            [
                "Opacity:",
                RollerSlider,
                dict(d, limit=(0, 100), key=ck.OPACITY)
            ],
            [
                "Limit Spread:",
                RollerCheckButton,
                dict(
                    d,
                    key=ck.CLIP_TO_CELL,
                    text="Clip to {}".format(clip),
                    tooltip=Tip.CAPTION_LIMIT_SPREAD.format(clip.lower())
                )
            ],
            [
                "Shadow:",
                OptionButton,
                dict(
                    d,
                    choice_window=RWShadow,
                    key=ck.SHADOW,
                    tip_type=ff.SHADOW_TIP_TYPE
                ),
            ]
        )
        if key == ck.LAYER_CAPTION:
            q += (
                [
                    "Bounds:",
                    RollerCheckButton,
                    dict(
                        d,
                        key=ck.OBEY_MARGINS,
                        text="Obey Margins",
                        tooltip=Tip.FORMAT_BOUNDS
                    )
                ],
            )
        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        q += (
            [
                "{} Preset:".format(key),
                Preset,
                dict(d, key=key)
            ],
        )
        q = RollerTable.populate_table(**dict(d, container=container, q=q))
        q[-1].widget_list = q[:-1]
        obey_margin = q[-2] if key == ck.LAYER_CAPTION else None

        for i in q:
            i.preset = q[-1]

            # for verify widgets:
            if i.key in VERIFY_CAPTION:
                i.verify = FormatWidget.verify_caption_widget
                i.is_per_cell = is_per_cell
                i.obey_margin = obey_margin
                i.index_type = index_type
        return q

    @staticmethod
    def draw_fringe_group(**d):
        """
        Draw the cell fringe group.

        Cell fringe can effect a cell plaque or a cell border.

        d: dict
            Has init values.

        Return: list
            of widget
        """
        key = d['sub_type']
        clip = "Cell" if key == FringeKey.CELL_FRINGE else "Layer"
        q = (
            [
                "Type:",
                RollerComboBox,
                dict(
                    d,
                    key=FringeKey.TYPE,
                    combo_list=ff.Fringe.TYPE
                )
            ],
            [
                "Brush:",
                OptionButton,
                dict(d, choice_window=RWChoice, key=FringeKey.BRUSH)
            ],
            [
                "Brush Size:",
                RollerSlider,
                dict(
                    d,
                    key=FringeKey.BRUSH_SIZE,
                    limit=(10, 10000),
                )
            ],
            [
                "Brush Spacing:",
                RollerSlider,
                dict(
                    d,
                    key=FringeKey.SPACING,
                    limit=(10, 10000)
                )
            ],
            [
                "Brush Opacity:",
                RollerSlider,
                dict(
                    d,
                    key=FringeKey.OPACITY,
                    limit=(0, 100)
                )
            ],
            [
                "Brush Angle:",
                RollerSlider,
                dict(
                    d,
                    key=FringeKey.BRUSH_ANGLE,
                    limit=(-180, 180)
                )
            ],
            [
                "Brush Hardness:  ",
                RollerSlider,
                dict(
                    d,
                    key=FringeKey.HARDNESS,
                    limit=(.001, 1),
                    precision=3
                )
            ],
            [
                "Contract:",
                RollerSlider,
                dict(
                    d,
                    key=FringeKey.CONTRACT,
                    limit=(0, 10000),
                    precision=0,
                    tooltip=Tip.FRINGE_CONTRACT
                )
            ],
            [
                "Bump",
                OptionButton,
                dict(
                    d,
                    choice_window=RWBumpChoice,
                    key=PlaqueKey.BUMP,
                    preview=False,
                    tip_type=ff.BUMP_TIP_TYPE
                ),
            ],
            [
                "Limit Painting:",
                RollerCheckButton,
                dict(
                    d,
                    key=FringeKey.CLIP_TO_CELL,
                    text="Clip to {}".format(clip),
                    tooltip=Tip.FORMAT_CLIP.format(clip.lower())
                )
            ],
            [
                "Color:",
                RollerColorButton,
                dict(d, key=FringeKey.COLOR)
            ],
            [
                "Color #1:",
                RollerColorButton,
                dict(d, key=FringeKey.COLOR_1)
            ],
            [
                "Color #2:",
                RollerColorButton,
                dict(d, key=FringeKey.COLOR_2)
            ],
            [
                "Gradient",
                OptionButton,
                dict(d, choice_window=RWChoice, key=FringeKey.GRADIENT)
            ],
            [
                "Gradient Type",
                RollerComboBox,
                dict(
                    d,
                    key=FringeKey.GRADIENT_TYPE,
                    combo_list=fg.GRADIENT_TYPE_LIST
                )
            ],
            [
                "Gradient Angle",
                RollerComboBox,
                dict(
                    d,
                    key=FringeKey.GRADIENT_ANGLE,
                    combo_list=fg.GRADIENT_ANGLE
                )
            ],
            [
                "Image:",
                OptionButton,
                dict(d, choice_window=RWImageChoice, key=FringeKey.IMAGE)
            ],
            [
                "Pattern:",
                OptionButton,
                dict(d, choice_window=RWChoice, key=FringeKey.PATTERN)
            ],
            [
                "Shadow:",
                OptionButton,
                dict(
                    d,
                    choice_window=RWShadow,
                    key=FringeKey.SHADOW,
                    tip_type=ff.SHADOW_TIP_TYPE
                )
            ]
        )
        if key == FringeKey.LAYER_FRINGE:
            q += (
                [
                    "Bounds:",
                    RollerCheckButton,
                    dict(
                        d,
                        key=FringeKey.OBEY_MARGINS,
                        text="Obey Margins",
                        tooltip=Tip.FORMAT_BOUNDS
                    )
                ],
            )
        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        q += (
            [
                "{} Preset:".format(key),
                Preset,
                dict(d, key=key)
            ],
        )
        q = RollerTable.populate_table(**dict(d, container=container, q=q))
        q[-1].widget_list = q[:-1]
        obey_margin = q[-2] if key == FringeKey.LAYER_FRINGE else None
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

        # for verify widgets:
        for i in q:
            i.preset = q[-1]
            if i.key in VERIFY_FRINGE:
                i.verify = FormatWidget.verify_fringe_widget
                i.obey_margin = obey_margin

        for i in SAME_SIZE_FRINGE:
            same_size.add_widget(q[i].spin_button)
        return q

    @staticmethod
    def draw_margin_group(**d):
        """
        Draw a margin button.

        d: dict
            Has init values.

        Return: list
            of widgets
        """
        q = (
            [
                "Margins:",
                OptionButton,
                dict(
                    d,
                    key=d['sub_type'].MARGIN,
                    choice_window=RWMargin,
                    tip_type=ff.MARGIN_TIP_TYPE
                )
            ],
        )
        q = RollerTable.populate_table(**dict(d, q=q))
        return q

    @staticmethod
    def draw_mask_group(**d):
        """
        Draw the image mask widget group.

        d: dict
            Has init options.

        Return: list
            of widgets
        """
        q = (
            [
                "Type:",
                RollerComboBox,
                dict(
                    d,
                    combo_list=ff.Mask.TYPE[:],
                    key=MaskKey.TYPE
                )
            ],
            [
                "Character:",
                RollerEntry,
                dict(d, key=MaskKey.CHAR, chars=1)
            ],
            [
                "Font:",
                OptionButton,
                dict(d, choice_window=RWChoice, key=MaskKey.FONT),
            ],
            [
                "Mask Image:",
                OptionButton,
                dict(d, choice_window=RWImageChoice, key=MaskKey.IMAGE),
            ],
            [
                "Horizontal Scale:",
                RollerSlider,
                dict(d, key=MaskKey.HORZ_SCALE, limit=(.001, 1.), precision=3)
            ],
            [
                "Vertical Scale:",
                RollerSlider,
                dict(d, key=MaskKey.VERT_SCALE, limit=(.001, 1.), precision=3)
            ],
        )
        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        q += (
            [
                "Image Mask Preset:",
                Preset,
                dict(d, key=MaskKey.IMAGE_MASK)
            ],
        )

        q = RollerTable.populate_table(**dict(d, container=container, q=q))
        q[-1].widget_list = q[:-1]

        for i in q:
            i.preset = q[-1]

            # for verify widgets:
            if i.key in VERIFY_MASK:
                i.verify = FormatWidget.verify_mask_widget
        return q

    @staticmethod
    def draw_place_group(**d):
        """
        Draw image place widgets.

        d: dict
            Has init values.

        Return: list
            of widget
        """
        key = PlaceKey
        q = (
            [
                "Image:",
                OptionButton,
                dict(
                    d,
                    choice_window=RWImageChoice,
                    key=key.IMAGE,
                    tip_type=ff.FOLDER_TIP_TYPE
                )
            ],
            [
                "Resize:",
                OptionButton,
                dict(d, choice_window=RWResize, key=key.RESIZE)
            ],
            [
                "Horizontal:",
                RollerComboBox,
                dict(
                    d,
                    key=key.HORIZONTAL,
                    combo_list=ff.Place.HORIZONTAL_OPTION
                )
            ],
            [
                "Vertical:",
                RollerComboBox,
                dict(
                    d,
                    key=key.VERTICAL,
                    combo_list=ff.Place.VERTICAL_OPTION_LIST
                )
            ]
        )
        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        q += (
            [
                "Image Place Preset:",
                Preset,
                dict(d, key=PlaceKey.IMAGE_PLACE)
            ],
        )
        q = RollerTable.populate_table(**dict(d, container=container, q=q))
        q[-1].widget_list = q[:-1]

        # for verify widgets and choice-window:
        for i in q:
            i.preset = q[-1]
            if i.key in VERIFY_PLACE:
                i.verify = FormatWidget.verify_place
        return q

    @staticmethod
    def draw_plaque_group(**d):
        """
        Draw the plaque widgets.

        d: dict
            Has widget values.

        Return: list
            of widget
        """
        key = d['sub_type']
        q = (
            [
                "Type:",
                RollerComboBox,
                dict(
                    d,
                    key=PlaqueKey.TYPE,
                    combo_list=ff.Plaque.TYPE[:]
                )
            ],
            [
                "Color:",
                RollerColorButton,
                dict(d, key=PlaqueKey.COLOR)
            ],
            [
                "Plaque Image:",
                OptionButton,
                dict(d, choice_window=RWImageChoice, key=PlaqueKey.IMAGE)
            ],
            [
                "Pattern:",
                OptionButton,
                dict(d, choice_window=RWChoice, key=PlaqueKey.PATTERN)
            ],
            [
                "Gradient",
                OptionButton,
                dict(d, choice_window=RWChoice, key=PlaqueKey.GRADIENT)
            ],
            [
                "Gradient Type",
                RollerComboBox,
                dict(
                    d,
                    key=PlaqueKey.GRADIENT_TYPE,
                    combo_list=fg.GRADIENT_TYPE_LIST
                )
            ],
            [
                "Gradient Angle",
                RollerComboBox,
                dict(
                    d,
                    key=PlaqueKey.GRADIENT_ANGLE,
                    combo_list=fg.GRADIENT_ANGLE
                )
            ],
            [
                "Opacity:",
                RollerSlider,
                dict(d, key=PlaqueKey.OPACITY, limit=(0., 100.))
            ],
            [
                "Blur Behind:",
                RollerSlider,
                dict(
                    d,
                    key=PlaqueKey.BLUR_BEHIND,
                    limit=(0, 500),
                    precision=0
                ),
            ],
            [
                "Bump",
                OptionButton,
                dict(
                    d,
                    choice_window=RWBumpChoice,
                    key=PlaqueKey.BUMP,
                    preview=None,
                    tip_type=ff.BUMP_TIP_TYPE
                ),
            ]
        )

        if key == PlaqueKey.LAYER_PLAQUE:
            q += (
                [
                    "Bounds:",
                    RollerCheckButton,
                    dict(
                        d,
                        key=PlaqueKey.OBEY_MARGINS,
                        text="Obey Margins",
                        tooltip=Tip.FORMAT_BOUNDS
                    )
                ],
            )

        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        q += (
            [
                "{} Preset:".format(key),
                Preset,
                dict(d, key=key)
            ],
        )
        q = RollerTable.populate_table(**dict(d, container=container, q=q))
        q[-1].widget_list = q[:-1]
        obey_margin = q[-2] if key == PlaqueKey.LAYER_PLAQUE else None

        for i in q:
            i.preset = q[-1]

            # for verify widgets:
            if i.key in VERIFY_PLAQUE:
                i.verify = FormatWidget.verify_plaque_widget
                i.obey_margin = obey_margin
        return q

    @staticmethod
    def draw_property_group(**d):
        """
        Draw the property group.

        d: dict
            Has init values.

        Return: list
            of widget
        """
        key = PropertyKey
        q = (
            [
                "Transform:",
                RollerCheckButton,
                dict(d, key=key.FLIP_HORIZONTAL, text="Flip Horizontal")
            ],
            [
                "",
                RollerCheckButton,
                dict(d, key=key.FLIP_VERTICAL, text="Flip Vertical")
            ],
            [
                "Rotate:",
                RollerSlider,
                dict(d, key=key.ROTATE, limit=(-359, 359))
            ],
            [
                "Opacity:",
                RollerSlider,
                dict(d, key=key.OPACITY, limit=(0., 100.))
            ],
            [
                "Blur Behind:",
                RollerSlider,
                dict(d, key=key.BLUR_BEHIND, limit=(0, 500), precision=0)
            ]
        )
        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        q += (
            [
                "Image Property Preset:",
                Preset,
                dict(d, key=PropertyKey.IMAGE_PROPERTY)
            ],
        )
        q = RollerTable.populate_table(**dict(d, container=container, q=q))
        q[-1].widget_list = q[:-1]
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

        for i in SAME_SIZE_PROPERTY:
            same_size.add_widget(q[i].spin_button)

        # for verify widgets:
        for i in (ff.Property.Index.OPACITY, -1):
            q[i].verify = FormatWidget.verify_property_widget

        for i in q:
            i.preset = q[-1]
        return q

    @staticmethod
    def verify_caption_widget(g):
        """
        Verify caption widgets.

        g: Widget
            text widget
        """
        a = g.index_type
        q = g.preset.widget_list
        show_list = [
            i for i in q if i.key not in (
                ck.START_NUMBER,
                ck.TEXT,
                ck.LEADING_TEXT,
                ck.TRAILING_TEXT
            )
        ]
        g, g1, g2 = q[a.TYPE], q[a.TEXT], q[a.OPACITY]

        caption_type = g.get_value()
        obey = g.obey_margin

        if caption_type == ok.NONE:
            show_list = [g]

        elif not g2.get_value():
            show_list = [g, g2]

        elif caption_type == ff.Caption.TEXT:
            if not g1.get_value():
                show_list = [g, g1]

            else:
                show_list.append(g1)
                if obey:
                    show_list.append(obey)

        elif caption_type == ff.Caption.SEQUENCE_NUMBER:
            show_list += [q[a.START_NUMBER]]

        if caption_type in (
            ff.Caption.SEQUENCE_NUMBER,
            ff.Caption.IMAGE_NAME
        ):
            show_list += [q[a.LEADING_TEXT], q[a.TRAILING_TEXT]]

        for i in q:
            if i in show_list:
                i.show()

            else:
                i.hide()

        if obey:
            obey.show() if obey in show_list else obey.hide()
        g.win.resize()

    @staticmethod
    def verify_fringe_widget(g):
        """
        Verify fringe widgets.

        g: Widget
            fringe group widget
        """
        q = brush_type, \
            brush, \
            brush_size, \
            spacing, \
            opacity, \
            angle, \
            hardness, \
            contract, \
            bump, \
            clip, \
            color, \
            color_1, \
            color_2, \
            gradient, \
            gradient_type, \
            gradient_angle, \
            image, \
            pattern, \
            shadow = g.preset.widget_list[:ff.Fringe.Index.TOTAL_OPTION]

        obey = g.obey_margin

        if not opacity.get_value():
            show_list = opacity,

        elif brush_type.get_value() == ok.NONE:
            show_list = brush_type,

        else:
            show_list = (
                brush_type,
                brush,
                brush_size,
                spacing,
                opacity,
                angle,
                hardness,
                contract
            )

            if obey:
                show_list += obey,

            value = brush_type.get_value()

            if value != ff.Fringe.MASK:
                show_list += clip, shadow, bump

                if value == ff.Fringe.GRADIENT:
                    show_list += gradient, gradient_type

                    # Shape-burst gradients radiate from the center:
                    if gradient_type.get_value() not in fg.SHAPE_BURST:
                        show_list += gradient_angle,

                elif value == ff.Fringe.IMAGE:
                    if image.get_value() == ok.NONE:
                        show_list = brush_type, image

                    else:
                        show_list += image,

                elif value == ff.Fringe.ONE_COLOR:
                    show_list += color,

                elif value == ff.Fringe.TWO_COLOR:
                    show_list += color_1, color_2

                elif value == ff.Fringe.PATTERN:
                    show_list += pattern,

        for i in q:
            if i in show_list:
                i.show()

            else:
                i.hide()

        if obey:
            obey.show() if obey in show_list else obey.hide()

        FormatWidget._set_fringe_type_tooltip(g)
        g.win.resize()

    @staticmethod
    def verify_mask_widget(g):
        """
        Verify mask widgets.

        g: Widget
            mask group widget
        """
        q = mask_type, _char, font, image, h_scale, v_scale = \
            g.preset.widget_list

        n = mask_type.get_value()
        show_list = mask_type, g.preset

        if n != ok.NONE:
            show_list += h_scale, v_scale

            if n == ff.Mask.CHARACTER:
                show_list += font, _char

            elif n == ff.Mask.IMAGE:
                show_list = mask_type, image

        for i in q:
            if i in show_list:
                i.show()

            else:
                i.hide()

        FormatWidget._set_mask_type_tooltip(g)
        g.win.resize()

    @staticmethod
    def verify_place(g):
        """
        Verify image place widgets.

        g: ComboBox
            of image place
        """
        q = image, resize, horizontal, vertical = g.preset.widget_list
        show_list = image,
        n = image.get_value()

        if n != ok.NONE:
            show_list += resize,
            if resize.get_value() != ff.Place.FILL_CELL:
                show_list += horizontal, vertical

        for i in q:
            if i in show_list:
                i.show()

            else:
                i.hide()
        g.win.resize()

    @staticmethod
    def verify_plaque_widget(g):
        """
        Verify plaque widgets.

        g: Widget
            plaque widget
        """
        q = plaque_type, \
            color, \
            image, \
            pattern, \
            gradient, \
            gradient_type, \
            gradient_angle, \
            opacity, \
            blur_behind, \
            bump = g.preset.widget_list[:ff.Plaque.Index.TOTAL_OPTION]

        obey = g.obey_margin

        show_list = plaque_type,
        n = plaque_type.get_value()

        if n != ok.NONE:
            if not opacity.get_value():
                show_list = opacity,

            else:
                show_list += opacity, blur_behind, bump

                if obey:
                    show_list += obey,

                if n == ff.Plaque.COLOR:
                    show_list += color,

                elif n == ff.Plaque.IMAGE:
                    if image.get_value() == ok.NONE:
                        show_list = plaque_type, image

                    else:
                        show_list += image,

                elif n == ff.Plaque.PATTERN:
                    show_list += pattern,

                elif n == ff.Plaque.GRADIENT:
                    show_list += gradient, gradient_type

                    # Shape-burst gradients radiate from the center:
                    if gradient_type.get_value() not in fg.SHAPE_BURST:
                        show_list += gradient_angle,

        for i in q:
            if i in show_list:
                i.show()

            else:
                i.hide()

        if obey:
            obey.show() if obey in show_list else obey.hide()
        g.win.resize()

    @staticmethod
    def verify_property_widget(g):
        """
        Verify image property group widgets.

        g: Widget
            property widget
        """
        q = g.preset.widget_list
        g = q[ff.Property.Index.OPACITY]
        show_list = [g]

        if g.get_value():
            show_list = q

        for i in q:
            if i in show_list:
                i.show()

            else:
                i.hide()
        g.win.resize()
