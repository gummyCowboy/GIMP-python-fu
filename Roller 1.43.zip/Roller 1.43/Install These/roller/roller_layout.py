#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_base import Base
from roller_constant import (
    ForFormat,
    ForLayer,
    LayoutKey,
    FormatKey,
    ForWidget,
    LayerKey,
    SessionKey)

from roller_fu import Lay, Sel
from roller_grid import Grid
import gimp
import gimpfu as fu


class Layout:
    """Manage image placement."""
    LAYER_MARGIN_COLOR = 200, 200, 206
    CELL_MARGIN_COLOR = 150, 156, 150
    IMAGE_COLOR = 106, 100, 100
    BACKGROUND_COLOR = 25, 25, 25
    GRID_COLOR = 225, 225, 225

    def __init__(self, stat):
        """stat: Stat"""
        self.stat = stat
        self._init_layout_references()

    def _calc_cell(self, r, c, d):
        """
        Adds a dict entry to "self.cell_table" for the cell at r, c.

        dict entries:
            x, y: coordinate
            w, h: cell size with margin

        r, c: int
            row, column

        d: dict
            format dict
        """
        ff = ForFormat

        # If merging cells:
        if d[FormatKey.MERGE_PER_CELL]:
            s = d[FormatKey.CELL_TABLE_MERGE][r][c]

            # Sub-top-left cells are unavailable:
            if s == (-1, -1):
                x = y = w = h = 0

            else:
                k1 = (r + s[0] - 1, c + s[1] - 1)
                x, y, w, h = self.grid.block((r, c), k1)

        else:
            x, y, w, h = self.grid.cell(r, c)

        if w:
            q = self.get_cell_margin(r, c, d)
            q1 = self.get_layer_margin(d)
            x += q[ff.LEFT_INDEX] + q1[ff.LEFT_INDEX]
            y += q[ff.TOP_INDEX] + q1[ff.TOP_INDEX]

            # Correct for margin overflow errors:
            x = Base.seal(x, 0, self.stat.width - 1)
            y = Base.seal(y, 0, self.stat.height - 1)
            w = w - q[ff.LEFT_INDEX] - q[ff.RIGHT_INDEX]
            h = h - q[ff.TOP_INDEX] - q[ff.BOTTOM_INDEX]

            # Set "w", "h" to the minimum value if size underflowed:
            w, h = max(w, 1), max(h, 1)
        self.cell_table[r][c].update({
                'x': x,
                'y': y,
                'w': w,
                'h': h
            })

    def _calc_cell_alloc(self, r, c, d):
        """
        Calculate cell allocation for percentage-of-cell cell margins.

        dict entry:
            alloc: cell size before margin

        r, c: int
            row, column

        d: dict
            format dict
        """
        # If merging cells:
        if d[FormatKey.MERGE_PER_CELL]:
            s = d[FormatKey.CELL_TABLE_MERGE][r][c]

            # Sub-top-left cells are unavailable:
            if s == (-1, -1):
                alloc = 0, 0

            else:
                k1 = (r + s[0] - 1, c + s[1] - 1)
                _, _, w, h = self.grid.block((r, c), k1)
                alloc = w, h

        else:
            _, _, w, h = self.grid.cell(r, c)
            alloc = w, h
        self.cell_table[r][c] = {'alloc': alloc}

    def _combine_margin(self, q, q1, w, h):
        """
        Return the margin after adding the
        fixed and the percentage margin together.

        q: tuple of int
            fixed-value margin

        q1: list of float
            percentage-of margin

        w: int
            width bounds

        h: int
            height bounds
        """
        q2 = [int(i * h) for i in q1[:2]]
        q3 = [int(i * w) for i in q1[2:]]
        q1 = q2 + q3

        for x in range(4):
            q1[x] = q1[x] + q[x]

        # Compensate for margin overflow
        # by reserving one pixel for the image:
        if q1[0] + q1[1] >= h:
            q1[0] = h / 2
            a = 1 if h % 2 else -1
            q1[1] = q1[0] + a

        if q1[2] + q1[3] >= w:
            q1[2] = w / 2
            a = 1 if w % 2 else -1
            q1[3] = q1[2] + a
        return q1

    def _draw_cell_margins(self, d):
        """
        Draw the cell margins.

        Call during a layout demo.

        d: dict
            format dict
        """
        just_one = Layout.is_draw_one_margin(d)
        row, col = self.row, self.column

        m = 0
        for r in range(row):
            for c in range(col):
                margin = self.get_cell_margin(r, c, d)
                for x in range(4):
                    draw = 1

                    # left, right:
                    if x in (ForFormat.LEFT_INDEX, ForFormat.RIGHT_INDEX):
                        if just_one and r > 0:
                            draw = 0

                    # top, bottom:
                    else:
                        if just_one and c > 0:
                            draw = 0
                    if draw:
                        v = margin[x]
                        if v:
                            # Unavailable cells have zero dimensions:
                            if self.get_cell_width(r, c):
                                m = 1
                                x1, y = self.get_cell_position(r, c)
                                x1 += (
                                        0,
                                        0,
                                        -margin[ForFormat.LEFT_INDEX],
                                        self.get_cell_width(r, c)
                                    )[x]

                                y += (
                                        -margin[ForFormat.TOP_INDEX],
                                        self.get_cell_height(r, c),
                                        0,
                                        0
                                    )[x]

                                w = (
                                        self.get_margin_w(r, c, d),
                                        self.get_margin_w(r, c, d),
                                        v,
                                        v
                                    )[x]

                                h = (
                                        v,
                                        v,
                                        self.get_margin_h(r, c, d),
                                        self.get_margin_h(r, c, d)
                                    )[x]
                                Sel.rect(self.stat.render, x1, y, w, h)
        if m:
            self._color_fill(Layout.CELL_MARGIN_COLOR)

    def _draw_coord(self, j):
        """
        Draw image coordinates at the top-left of an image rectangle.

        j: RollerImage
        """
        z = Lay.text(self.stat.render, str(j.x) + ", " + str(j.y))
        self._draw_text(j.x + 3, j.y, z)

    def _draw_corners(self, j):
        """
        Draw image corner coordinates.

        j: RollerImage
        """
        # top-right:
        x = j.x + j.new_size[0]
        n = str(x) + ", " + str(j.y)
        z = Lay.text(self.stat.render, n)

        self._draw_text(x - z.width - 3, j.y, z)

        # bottom-left:
        y = j.y + j.new_size[1]
        n = str(j.x) + ", " + str(y)
        z = Lay.text(self.stat.render, n)
        self._draw_text(j.x + 3, y - z.height, z)

    def _draw_dim(self, j):
        """
        Draw an image's dimension at the bottom-right of an image rectangle.

        j: RollerImage
        """
        w, h = j.new_size[0], j.new_size[1]
        n = str(w) + ", " + str(h)
        z = Lay.text(self.stat.render, n)
        self._draw_text(j.x + w - z.width - 3, j.y + h - z.height, z)

    def _draw_format(self, d):
        """
        Draw a format.

        d: dict
            format dict
        """
        self.calc_cell_table(d)
        e = self.stat.session[SessionKey.LAYOUT_OPTION]
        q = ((
                LayoutKey.CELL_MARGINS, self._draw_cell_margins), (
                LayoutKey.LAYER_MARGINS, self._draw_layer_margins), (
                LayoutKey.GRID, self._draw_grid
            ))

        self._draw_image_types(d)
        if e:
            for i in q:
                if e[i[0]]:
                    i[1](d)

    def _draw_grid(self, d):
        """
        Draw grid lines.

        d: dict
            format dict
        """
        m = 0
        row, col = self.row, self.column
        w, h = self.stat.width, self.stat.height
        top, bottom, left, right = self.get_layer_margin(d)

        # Grid lines divide the layer space:
        w1 = w - left - right
        x = left
        h1 = 1

        # Draw rows:
        if row > 1:
            for r in range(1, row):
                y = self.get_row_y(r) + top
                if 0 < y < h:
                    m = 1
                    Sel.rect(self.stat.render, x, y, w1, h1)

        w1, h1 = 1, h - top - bottom
        y = top

        # Draw columns:
        if col > 1:
            for c in range(1, col):
                x = self.get_col_x(c) + left
                if 0 < x < w:
                    m = 1
                    Sel.rect(self.stat.render, x, y, w1, h1)
        if m:
            self._color_fill(Layout.GRID_COLOR)

    def _draw_image_types(self, d):
        """
        Draw a rectangle that represents an image.

        d: dict
            format dict
        """
        a = LayoutKey
        row, col = self.row, self.column
        m = 0
        e = self.stat.session[SessionKey.LAYOUT_OPTION]
        q = ((
                a.COORDINATES, self._draw_coord), (
                a.CORNERS, self._draw_corners), (
                a.DIMENSIONS, self._draw_dim), (
                a.NAME, self._draw_name), (
                a.RATIOS, self._draw_ratio
            ))

        for r in range(row):
            for c in range(col):
                if self.cell_has_image(r, c, d):
                    m = 1
                    j = Layout.get_image_reference(r, c, d)
                    j.r, j.c = r, c
                    j.rot = Layout.get_rotate(r, c, d)

                    if j.rot:
                        if m:
                            Sel.fill(self._active_layer, Layout.IMAGE_COLOR)
                            Sel.none(self.stat.render)
                            m = 0

                    if j.rot:
                        z = Lay.add(
                            self.stat.render, j.n, z=self.format_group)

                    self.mold_rect(j, d)

                    if j.rot:
                        self._rotate(j, z, d)
                    if e:
                        for i in q:
                            if e[i[0]]:
                                i[1](j)
        if m:
            self._color_fill(Layout.IMAGE_COLOR)

    def _draw_layer_margins(self, d):
        """
        Draw the layer margins.

        d: dict
            format dict
        """
        m = 0
        ff = ForFormat
        top, bottom, left, right = self.get_layer_margin(d)

        for x in range(4):
            m = 1

            if x in (ff.TOP_INDEX, ff.BOTTOM_INDEX):
                # top, bottom:
                x1 = left
                w = self.stat.width - left - right

                if x == ff.TOP_INDEX:
                    y = 0
                    h = top

                else:
                    h = bottom
                    y = self.stat.height - h

            else:
                # left, right:
                h = self.stat.height - top - bottom
                y = top

                if x == ff.LEFT_INDEX:
                    x1 = 0
                    w = left

                else:
                    w = right
                    x1 = self.stat.width - w
            Sel.rect(self.stat.render, x1, y, w, h)
        if m:
            self._color_fill(Layout.LAYER_MARGIN_COLOR)

    def _draw_name(self, j):
        """
        Draw a document title at the center of an image rectangle.

        j: RollerImage
        """
        z = Lay.text(self.stat.render, j.n)
        x = j.new_size[0] / 2 + j.x - z.width / 2
        y = j.new_size[1] / 2 + j.y + z.height / 2
        self._draw_text(x, y, z)

    def _draw_ratio(self, j):
        """
        Draw an image ratio at the center of an image rectangle.

        A ratio is an image center point divided by the render size.

        j: RollerImage
        """
        x = j.new_size[0] / 2 + j.x
        y = j.new_size[1] / 2 + j.y
        x1 = x / 1. / self.stat.width
        y1 = y / 1. / self.stat.height
        r_x = format(x1, '.2f')
        r_y = format(y1, '.2f')
        n = r_x[int(x1 < 1):] + ", " + r_y[int(y1 < 1):]
        z = Lay.text(self.stat.render, n)
        x2 = x - z.width / 2
        y2 = y - z.height / 2
        self._draw_text(x2, y2, z)

    def _draw_text(self, x, y, z):
        """
        Adds a text layer to the format group.

        x, y: int
            final position

        z: layer
            text layer
        """
        Lay.place(self.stat.render, z, self.format_group)
        pdb.gimp_text_layer_set_color(z, (255,) * 3)
        Lay.move(z, x, y)
        z.opacity = 66.

    def _color_fill(self, q):
        """
        Fill the selection with a color on the current format layer.

        q: tuple
            color (RGB)
        """
        Sel.fill(self._active_layer, q)
        Sel.none(self.stat.render)

    def _init_layout_references(self):
        """Initialize layout variables."""
        self.format_group = self._active_layer = None
        self.layout_size = self.layout_background = None
        self.cell_table = self.grid = None

    def _rotate(self, j, z, d):
        """
        Rotate an image rectangle.

        j: RollerImage
        z: layer
            rotation layer

        d: dict
            format dict
        """
        # Create a new image with the selection:
        Sel.fill(z, Layout.IMAGE_COLOR)
        Sel.kopy(z)
        Lay.klear(self.stat.render, z)

        s = self.get_cell_size(j.r, j.c)
        j2 = RollerImage.paste()
        z1 = Lay.rotate(j2, j.rot)

        j.new_size = z1.width, z1.height

        if j.new_size[0] > s[0] or j.new_size[1] > s[1]:
            # The image won't fit into the cell so get the size that will:
            w, h = j.new_size = RollerImage.calc_lock(s, j.new_size)
            z1 = pdb.gimp_item_transform_scale(z1, 0, 0, w, h)

        Sel.kopy(z1)
        RollerImage.bury(j2)

        z4 = Lay.paste(self.stat.render, z)
        z4.name = Lay.get_layer_name("Rotated " + j.n, self.stat)

        Lay.bury(self.stat.render, z)
        self.calc_rect_pos(d, j)
        Lay.move(z4, j.x, j.y)
        z4.opacity = 66.

    def calc_block(self, start, end, d):
        """
        Recalculate the cell sizes for a block of cells.

        start, end: tuple of int
            size, (w, h)
            
        d: dict
            format dict
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self._calc_cell(r, c, d)

    def calc_cell_table(self, d):
        """
        Create a new cell table, "tb", to store the cell sizes.

        Calculate cell sizes.

        Correct cell size underflow.

        d : dict
            format dict
        """
        fk = FormatKey
        r, c = d[fk.ROW], d[fk.COLUMN] = (
                    min(d[fk.ROW], self.stat.height),
                    min(d[fk.COLUMN], self.stat.width)
                )

        # cell table with cell keys: 'x', 'y', 'w', 'h':
        self.cell_table = Base.create_2d_table(r, c)
        top, bottom, left, right = self.get_layer_margin(d)

        # Calculate layer size:
        w = self.stat.width - left - right
        h = self.stat.height - top - bottom

        # "s" is the size of a cell before image margins are subtracted
        # and after layer margins are subtracted from the layer size:
        s = (
                Base.seal(w, 1, self.stat.width),
                Base.seal(h, 1, self.stat.height)
            )

        self.grid = Grid(s, r, c)

        # The row and column counts can change if there
        # is an underflow of space for the rows and columns.
        r, c = self.row, self.column = self.grid.r, self.grid.c

        # Calculate cell allocation for cell margin:
        for i in range(r):
            for j in range(c):
                self._calc_cell_alloc(i, j, d)

        # Cells reduce their size with cell margins:
        for i in range(r):
            for j in range(c):
                self._calc_cell(i, j, d)

    def calc_rect_pos(self, d, j):
        """
        For an image or rectangle, calculate its (x, y) position in a cell.

        d: dict
            format dict

        j: RollerImage
        """
        r, c = j.r, j.c
        x, y = self.get_cell_position(r, c)
        w, h = j.new_size[0], j.new_size[1]

        n = Layout.get_horz_just(r, c, d)
        n1 = Layout.get_vert_just(r, c, d)

        if n == ForFormat.CENTER:
            self.get_cell_width(r, c)
            x += (self.get_cell_width(r, c) - w) / 2

        elif n == ForFormat.RIGHT:
            x += self.get_cell_width(r, c) - w

        if n1 == ForFormat.MIDDLE:
            y += (self.get_cell_height(r, c) - h) / 2

        elif n1 == ForFormat.BOTTOM:
            y += self.get_cell_height(r, c) - h
        j.x, j.y = x, y

    def cell_has_image(self, r, c, d):
        """
        Return true if a cell has an available image at r, c.

        d: dict
            format dict
        """
        # Check for underflow conditions:
        if r > self.row - 1:
            return 0

        if c > self.column - 1:
            return 0

        if self.get_cell_width(r, c):
            a = Layout.get_placement(r, c, d)
            n = a[ForFormat.IMAGE_INDEX]

            if n == ForFormat.NONE or not Layout.get_prop_opacity(r, c, d):
                return 0

            if n == ForFormat.NEXT:
                if RollerImage.image_count > RollerImage.next_x:
                    return 1

                else:
                    return 0
            if n in RollerImage.image_list:
                return 1

    def do_blur_behind(self, image_layer, blur):
        """
        Create a blur behind layer if one doesn't exist.

        Use an opaque selection of an image
        to blur the area on the blur behind layer.

        image_layer: layer
        blur: int
            blur amount
        """
        j = self.stat.render
        z = self.blur_behind_layer

        if not z:
            # Create the Blur Behind layer:
            Lay.hide(self.image_group)
            Lay.kopy(j)
            Lay.show(self.image_group)

            z = self.blur_behind_layer = Lay.paste(
                j, Lay.get_backdrop_layer(j))
            z.name = Lay.get_layer_name(LayerKey.BLUR_BEHIND, self.stat)

        z1 = Lay.selectable(j, image_layer, ForLayer.INHERIT_DICT)

        Sel.item(j, z1)
        Lay.blur(j, z, blur)
        Lay.bury(j, z1)
        Sel.none(j)

    @staticmethod
    def get_blur_behind(j, d):
        """
        Return the value of an image's blur behind setting.

        j: RollerImage
        d: dict
            format dict
        """
        if d[FormatKey.PROPERTY_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PROPERTY][j.r][j.c][
                ForFormat.BLUR_BEHIND_INDEX]

        else:
            return d[FormatKey.BLUR_BEHIND]

    def get_cell_height(self, r, c):
        """
        Return the cell height for a cell at r, c.

        r, c: int
            row, column
        """
        return self.cell_table[r][c]['h']

    def get_cell_info(self, r, c):
        """Return a cell's dimension and position for a cell at r, c."""
        return (
            self.cell_table[r][c]['w'], self.cell_table[r][c]['h'],
            self.cell_table[r][c]['x'], self.cell_table[r][c]['y'])

    def get_cell_margin(self, r, c, d):
        """
        Return the image margins for a cell at r, c as
        (top, bottom, left, right) of int.

        d: dict
            format dict
        """
        fk = FormatKey
        w, h = self.cell_table[r][c]['alloc']

        if not d[fk.FIXED_MARGIN_PER_CELL]:
            q = d[fk.CELL_MARGIN_TOP_FIXED], \
                d[fk.CELL_MARGIN_BOTTOM_FIXED], \
                d[fk.CELL_MARGIN_LEFT_FIXED], \
                d[fk.CELL_MARGIN_RIGHT_FIXED]

        else:
            q = d[fk.CELL_TABLE_FIXED_MARGIN][r][c]

        if not d[fk.PERCENT_MARGIN_PER_CELL]:
            q1 = d[fk.CELL_MARGIN_TOP_PERCENT], \
                d[fk.CELL_MARGIN_BOTTOM_PERCENT], \
                d[fk.CELL_MARGIN_LEFT_PERCENT], \
                d[fk.CELL_MARGIN_RIGHT_PERCENT]
        else:
            q1 = d[fk.CELL_TABLE_PERCENT_MARGIN][r][c]
        return self._combine_margin(q, q1, w, h)

    def get_cell_position(self, r, c):
        """
        Return the cell coordinate (x, y) for a cell at r, c.

        r, c: int
            row, column
        """
        return self.cell_table[r][c]['x'], self.cell_table[r][c]['y']

    def get_cell_size(self, r, c):
        """Return a cell's width and height for a cell at r, c."""
        return self.cell_table[r][c]['w'], self.cell_table[r][c]['h']

    def get_cell_width(self, r, c):
        """Return the cell width for a cell at r, c."""
        return self.cell_table[r][c]['w']

    def get_col_x(self, c):
        """Return the coordinate x for column, c."""
        x, _, _, _ = self.grid.cell(0, c)
        return x

    def get_row_y(self, r):
        """Return the coordinate y for row, r."""
        _, y, _, _ = self.grid.cell(r, 0)
        return y

    @staticmethod
    def get_flip_h(j, d):
        """
        Return the flip horizontal flag of an image being placed.

        j: RollerImage
        d: dict
            format dict
        """
        if d[FormatKey.PROPERTY_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PROPERTY][j.r][j.c][
                ForFormat.FLIP_HORIZONTAL_INDEX]

        else:
            return d[FormatKey.FLIP_HORIZONTAL]

    @staticmethod
    def get_flip_v(j, d):
        """
        Return the flip vertical flag of an image being placed.

        j: RollerImage
        d: dict
            format dict
        """
        if d[FormatKey.PROPERTY_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PROPERTY][j.r][j.c][
                ForFormat.FLIP_VERTICAL_INDEX]

        else:
            return d[FormatKey.FLIP_VERTICAL]

    @staticmethod
    def get_horz_just(r, c, d):
        """
        Return the horizontal justification for the cell at r, c.

        d: dict
            format dict
        """
        if d[FormatKey.PLACEMENT_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PLACEMENT][r][c][
                ForFormat.HORIZONTAL_INDEX]

        else:
            return d[FormatKey.HORIZONTAL]

    @staticmethod
    def get_image_reference(r, c, d):
        """
        Return an RollerImage object for the cell at r, c.

        d: dict
            format dict
        """
        if not d[FormatKey.PLACEMENT_PER_CELL]:
            n = d[FormatKey.IMAGE]

        else:
            n = d[FormatKey.CELL_TABLE_PLACEMENT][r][c][
                ForFormat.IMAGE_INDEX]
        return RollerImage.get_image(n)

    def get_layer_margin(self, d):
        """
        Return a layer margin tuple for the format layer.
        (top, bottom, left, right) of int

        r, c: int
            row, column

        d: dict
            format dict
        """
        fk = FormatKey
        w, h = self.stat.width, self.stat.height
        q = d[fk.LAYER_MARGIN_TOP_FIXED], \
            d[fk.LAYER_MARGIN_BOTTOM_FIXED], \
            d[fk.LAYER_MARGIN_LEFT_FIXED], \
            d[fk.LAYER_MARGIN_RIGHT_FIXED]

        q1 = d[fk.LAYER_MARGIN_TOP_PERCENT], \
            d[fk.LAYER_MARGIN_BOTTOM_PERCENT], \
            d[fk.LAYER_MARGIN_LEFT_PERCENT], \
            d[fk.LAYER_MARGIN_RIGHT_PERCENT]
        return self._combine_margin(q, q1, w, h)

    def get_margin_h(self, r, c, d):
        """
        Return the height of an image margin for the cell at r, c.

        r, c: int
            row, column

        d: dict
            format dict
        """
        if Layout.is_draw_one_margin(d):
            top, bottom, _, _ = self.get_cell_margin(r, c, d)
            top1, bottom1, _, _ = self.get_layer_margin(d)
            return self.stat.height - top - bottom - top1 - bottom1

        else:
            return self.get_cell_height(r, c)

    def get_margin_w(self, r, c, d):
        """
        Return the width of an image margin at r, c.

        r, c: int
            row, column

        d: dict
            format dict
        """
        if Layout.is_draw_one_margin(d):
            _, _, left, right = self.get_cell_margin(r, c, d)
            _, _, left1, right1 = self.get_layer_margin(d)
            return self.stat.width - left - right - left1 - right1

        else:
            return self.get_cell_width(r, c)

    @staticmethod
    def get_placement(r, c, d):
        """
        Return the image placement for a cell at r, c.

        d: dict
            format dict
        """
        fk = FormatKey

        if not d[fk.PLACEMENT_PER_CELL]:
            return \
                d[fk.RESIZE], \
                d[fk.IMAGE], \
                d[fk.HORIZONTAL], \
                d[fk.VERTICAL]

        else:
            return d[fk.CELL_TABLE_PLACEMENT][r][c]

    @staticmethod
    def get_prop_opacity(r, c, d):
        """
        Return the opacity property of a cell at r, c.

        d: dict
            format dict
        """
        fk = FormatKey

        if d[fk.PROPERTY_PER_CELL]:
            return d[fk.CELL_TABLE_PROPERTY][r][c][ForFormat.OPACITY_INDEX]

        else:
            return d[fk.OPACITY]

    @staticmethod
    def get_resize_type(r, c, d):
        """
        Return the resize type for the cell at r, c.

        d: dict
            format dict
        """
        if d[FormatKey.PLACEMENT_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PLACEMENT][r][c][0]

        else:
            return d[FormatKey.RESIZE]

    @staticmethod
    def get_rotate(r, c, d):
        """
        Return the resize type for the cell at r, c.

        d: dict
            format dict
        """
        if d[FormatKey.PROPERTY_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PROPERTY][r][c][
                ForFormat.ROTATE_INDEX]

        else:
            return d[FormatKey.ROTATE]

    @staticmethod
    def get_vert_just(r, c, d):
        """
        Return the vertical justification for the cell at r, c.

        d: dict
            format dict
        """
        if d[FormatKey.PLACEMENT_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PLACEMENT][r][c][
                ForFormat.VERTICAL_INDEX]

        else:
            return d[FormatKey.VERTICAL]

    def init_format_references(self):
        """
        Initializes variables used when rendering a format.

        Format variables need to be reset per format.
        """
        self.blur_behind_layer = None
        self.pix = 0

    @staticmethod
    def is_draw_one_margin(d):
        """
        Return true when drawing one margin per row or column.

        d: dict
            format dict
        """
        return not any((
                d[FormatKey.PLACEMENT_PER_CELL],
                d[FormatKey.FIXED_MARGIN_PER_CELL],
                d[FormatKey.PERCENT_MARGIN_PER_CELL],
                d[FormatKey.MERGE_PER_CELL],
                d[FormatKey.PROPERTY_PER_CELL]
            ))

    def do_new_render(self):
        """Creates a new image for the layout and render."""
        j = self.stat.render = RollerImage.new(
            self.stat.width, self.stat.height)

        # Turn on undo functionality:
        pdb.gimp_image_undo_group_start(j)

    def mold(self, j, d):
        """
        Mold an image to fit a cell.

        j: RollerImage
        d: dict
            format dict
        """
        Sel.none(self.stat.render)

        s = j.cell_size = self.get_cell_size(j.r, j.c)

        # Resize index for fill, locked, none, trim:
        x = ForFormat.RESIZE_OPTION.index(
            Layout.get_resize_type(j.r, j.c, d))

        (
            RollerImage.mold_fill,
            RollerImage.mold_lock,
            RollerImage.mold_none,
            RollerImage.mold_trim
        )[x](j, d)

        if j.rot:
            j2 = RollerImage.paste()
            z = Lay.rotate(j2, j.rot)
            t = w, h = z.width, z.height

            Lay.kopy(j2)
            RollerImage.bury(j2)

            if w > s[0] or h > s[1]:
                t = w, h = RollerImage.calc_lock(s, t)
                j3 = RollerImage.paste()
                RollerImage.shape(j3, w, h)
            j.new_size = t
        self.calc_rect_pos(d, j)

    def mold_rect(self, j, d):
        """
        Draw an image rectangle for a layout
        that corresponds with the format.

        j: RollerImage
        d: dict
            format dict
        """
        s = j.size
        t = j.cell_size = self.get_cell_size(j.r, j.c)

        typ = Layout.get_resize_type(j.r, j.c, d)

        if typ == ForFormat.FILL_CELL:
            s1 = t

        elif typ == ForFormat.LOCKED:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = RollerImage.calc_lock(t, s)

            else:
                s1 = s

        elif typ == ForFormat.NONE:
            s1 = list(s)

            if s[0] > t[0]:
                s1[0] = t[0]
            if s[1] > t[1]:
                s1[1] = t[1]

        else:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = RollerImage.get_trim_size(s, t)
                if s1[1] > t[1]:
                    s1[1] = t[1]

                else:
                    s1[0] = t[0]

            else:
                s1 = s

        j.new_size = s1

        self.calc_rect_pos(d, j)
        Sel.rect(self.stat.render, j.x, j.y, *s1)

    def place_image(self, j, d):
        """
        Copies and pastes images on or above the image layer.

        j: RollerImage
        d: dict
            format dict
        """
        # The RollerImage's image will enter the copy and paste buffer:
        self.mold(j, d)

        if not self.pix:
            a = 1 if self.stat.has_layout else 0
            self.image_group = Lay.group(
                    self.stat.render,
                    Lay.get_layer_name(d[FormatKey.NAME], self.stat),
                    a=a
                )

        z = Lay.paste(self.stat.render, self.stat.render.layers[-1])
        z.opacity = Layout.get_prop_opacity(j.r, j.c, d) / 1.

        Lay.order(self.stat.render, z, self.image_group)

        if Layout.get_flip_h(j, d):
            Lay.flip(z, horz=1)

        if Layout.get_flip_v(j, d):
            z = Lay.flip(z)

        Lay.move(z, j.x, j.y)

        blur = Layout.get_blur_behind(j, d)

        if blur:
            self.do_blur_behind(z, blur)
        self.pix += 1

    def remove_background(self):
        """
        Deletes the Layout's background layer.

        Updates layout references.
        """
        Lay.bury(self.stat.render, self.layout_background)
        self.layout_background = None

    def remove_layout_group(self):
        """
        Deletes the Layout's background layer.

        Updates layout references.
        """
        Lay.bury(self.stat.render, self.layout_group)
        self._init_layout_references()

    @staticmethod
    def select_image_trim(d, j, j1):
        """
        Use to get the cell-size scaled image pixels
        for a trimmed or non-resized image.

        Create a selection rectangle for the image transfer.

        Copy the selection.

        d: dict
            Format dict

        j: RollerImage
        j1: GIMP image

        Return the selection size.
        """
        # Need to select from one layer only:
        ff = ForFormat
        m = 0

        if len(j1.layers) > 1:
            Lay.kopy(j1)
            m = 1
            j1 = RollerImage.paste()

        r, c = j.r, j.c
        n = Layout.get_horz_just(r, c, d)
        s = j.cell_size
        t = j1.width, j1.height

        if n == ff.LEFT:
            x = 0
            x1 = s[0]

        elif n == ff.CENTER:
            x = max(t[0] / 2 - s[0] / 2, 0)
            x1 = min(t[0] / 2 + s[0] / 2 + s[0] % 2, t[0])

        else:
            x = max(t[0] - s[0], 0)
            x1 = t[0]

        n1 = Layout.get_vert_just(r, c, d)

        if n1 == ff.TOP:
            y = 0
            y1 = s[1]

        elif n1 == ff.MIDDLE:
            y = max(t[1] / 2 - s[1] / 2, 0)
            y1 = min(t[1] / 2 + s[1] / 2 + s[1] % 2, t[1])

        else:
            y = max(t[1] - s[1], 0)
            y1 = t[1]

        # Correct for underflow:
        if x == x1:
            x1 += 1

        if y == y1:
            y1 += 1

        w = max(x1 - x, 1)
        h = max(y1 - y, 1)

        Sel.rect(j1, x, y, w, h, mode=fu.CHANNEL_OP_REPLACE)

        Sel.kopy(j1.layers[0])
        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j1)

        if m:
            RollerImage.bury(j1)
        return x1 - x, y1 - y

    def show(self):
        """Draw the layout."""
        stat = self.stat
        RollerImage.next_x = 0
        s = stat.size

        if self.layout_background:
            if self.layout_size != s:
                # Delete old layout:
                pdb.gimp_image_undo_group_end(stat.render)
                pdb.gimp_display_delete(self.display)
                self.layout_background = stat.has_layout = None

        if not self.layout_background:
            # Create a new layout:
            self.do_new_render()
            z = self.layout_background = Lay.add(
                    stat.render,
                    "Layout Background"
                )

            self.display = pdb.gimp_display_new(stat.render)
            self.layout_size = stat.width, stat.height
            Lay.color_fill(z, Layout.BACKGROUND_COLOR)

        q = self.stat.session[SessionKey.FORMAT_LIST]
        start = len(q) - 1

        if self.stat.has_layout:
            # Delete group:
            Lay.bury(stat.render, self.layout_group)

        if start > -1:
            # new group:
            z = self.layout_group = Lay.group(
                    stat.render,
                    Lay.get_layer_name("Layout", self.stat)
                )

        # Draw format layouts:
        for x in range(start, -1, -1):
            d = q[x]
            if d[FormatKey.SHOW_IN_LAYOUT]:
                stat.has_layout = 1
                n = d[FormatKey.NAME]
                z1 = self.format_group = Lay.group(
                        stat.render,
                        Lay.get_layer_name("Layout Group: " + n, self.stat)
                    )

                Lay.order(stat.render, z1, z)
                z1 = self._active_layer = Lay.add(
                        stat.render,
                        Lay.get_layer_name("Layout: " + n, self.stat),
                        z=z1
                    )

                z1.opacity = 66.
                self._draw_format(d)

        Lay.activate(stat.render, z)
        pdb.gimp_displays_flush()


class RollerImage:
    """Use to manage an open image."""

    # number of valid images:
    image_count = 0

    # next image index:
    next_x = 0

    # open images:
    images = []

    # valid image names:
    image_names = []
    image_list = []
    relative_names = []

    def __init__(self, j, n):
        """
        j: GIMP image
        n: string
            image name
        """
        Sel.none(j)
        self.j = j
        self.n = n
        self.size = j.width, j.height

    @staticmethod
    def bury(j):
        """
        Delete an image that doesn't have a display.

        j: GIMP image
        """
        pdb.gimp_image_delete(j)

    @staticmethod
    def calc_lock(s, t):
        """
        Return the size of an image that will fit into a smaller cell.

        s: cell size
        t: tuple of int
            image size (w, h)
        """
        w_r = float(t[0]) / s[0]
        h_r = float(t[1]) / s[1]

        if w_r > h_r:
            w, h = s[0], int(t[1] * (s[0] / float(t[0])))

        else:
            w, h = int(t[0] * (s[1] / float(t[1]))), s[1]

        # underflow:
        return w + int(int(w) == 0), h + int(int(h) == 0)

    @staticmethod
    def collect_images():
        """Collect related data for images."""
        # post-fix image number tuple:
        q = pdb.gimp_image_list()[1][::-1]

        # gimp.Image list:
        q1 = reversed(gimp.image_list())

        for x, j in enumerate(q1):
            n = j.name + "-" + str(q[x])
            RollerImage.images.append(RollerImage(j, n))

        q = RollerImage.image_names = RollerImage.make_image_name_list()
        RollerImage.image_count = len(q)

        for i in range(len(q)):
            go = 1
            while go:
                go = q.count(q[i]) - 1
                if go:
                    x = q.index(q[i])
                    q[x] = RollerImage.images[
                        x].n = q[x] + " (" + str(go) + ")"

        # Make list for format:
        q = RollerImage.image_list = RollerImage.image_names[:]
        b = RollerImage.relative_names

        for i in range(len(q)):
            n = str(i + 1)
            a1 = i + 1

            if i == 0 or (a1 > 20 and a1 % 10 == 1):
                c = n + "st"

            elif i == 1 or (a1 > 20 and a1 % 10 == 2):
                c = n + "nd"

            elif i == 2 or (a1 > 20 and a1 % 10 == 3):
                c = n + "rd"

            else:
                c = n + "th"
            b.append(c + " Image")

        q.append("★")

        q += b

        q.insert(0, ForFormat.NEXT)
        q.insert(1, ForFormat.NONE)
        q.insert(2, ForWidget.LIST_SEPARATOR)

    @staticmethod
    def get_image(n):
        """
        Return an RollerImage object.

        n: string
            name of image
        """
        a = RollerImage

        if n == ForFormat.NEXT:
            j = a.get_next_image()

        elif n in a.image_names:
            x = a.image_names.index(n)
            j = a.images[x]

        else:
            x = a.relative_names.index(n)
            j = a.images[x]
        return j

    @staticmethod
    def get_next_image():
        """Return the next RollerImage or none."""
        j = None
        a = RollerImage

        if a.next_x < a.image_count:
            j = a.images[a.next_x]
            a.next_x += 1
        return j

    @staticmethod
    def get_trim_size(s, t):
        """
        Return the size of the trim.

        s: tuple (w, h) int
            image size

        t: tuple (w, h) int
            cell size
        """
        w_r = t[0] / 1. / s[0]
        h_r = t[1] / 1. / s[1]

        if s[0] < t[0] and s[1] < t[1]:
            # No trim needed:
            w, h = s

        else:
            if w_r < h_r:
                # The image height is closer to the cell size:
                w, h = int(s[0] * h_r), t[1]
                h = min(h, s[1])

            else:
                # The image width is closer to the cell size:
                w, h = int(s[0] * w_r), int(s[1] * w_r)
                w = min(w, s[0])

        # underflow:
        return [w + int(int(w) == 0), h + int(int(h) == 0)]

    @staticmethod
    def make_image_name_list():
        """Return a list of valid image names."""
        return [i.n for i in RollerImage.images]

    @staticmethod
    def mold_fill(j, _):
        """
        Resize a fill-image resize-type.

        Return with the image data in the buffer.
        """
        if j.size != j.cell_size:
            Lay.kopy(j.j)
            j1 = RollerImage.paste()
            j.new_size = w, h = j.cell_size
            RollerImage.shape(j1, w, h)

        else:
            j.new_size = j.size
            Lay.kopy(j.j)

    @staticmethod
    def mold_lock(j, _):
        """
        Resize a locked image resize-type.

        Return with the image data in the buffer.
        """
        Lay.kopy(j.j)
        if j.size[0] > j.cell_size[0] or j.size[1] > j.cell_size[1]:
            # down-size:
            w, h = RollerImage.calc_lock(j.cell_size, j.size)
            j1 = RollerImage.paste()
            RollerImage.shape(j1, w, h)

        else:
            w, h = j.size
        j.new_size = w, h

    @staticmethod
    def mold_none(j, d):
        """
        Resize a None-image resize-type.

        Return with the image data in the buffer.

        d: dict
            format dict
        """
        if j.size[0] > j.cell_size[0] or j.size[1] > j.cell_size[1]:
            # Copy a rectangle:
            j.new_size = Layout.select_image_trim(d, j, j.j)

        else:
            j.new_size = j.size
            Lay.kopy(j.j)

    @staticmethod
    def mold_trim(j, d):
        """
        Resize a None-image resize-type.

        Return with the image data in the buffer.

        j: RollerImage
        d: dict
            format dict
        """
        s = s1 = j.size
        t = j.cell_size

        Lay.kopy(j.j)

        if s[0] > t[0] or s[1] > t[1]:
            w, h = RollerImage.get_trim_size(s, t)
            j1 = RollerImage.paste()
            RollerImage.shape(j1, w, h)

            j1 = RollerImage.paste()
            s1 = Layout.select_image_trim(d, j, j1)

            # Copy selection:
            Lay.kopy(j1)
            RollerImage.bury(j1)
        j.new_size = s1

    @staticmethod
    def new(w, h):
        """
        Create a new image based on the global scales.

        w, h: int
            size of the new image

        Return the new image.
        """
        return pdb.gimp_image_new(w, h, fu.RGB)

    @staticmethod
    def paste():
        """
        Paste the buffer as a new image.

        Return the new image.
        """
        return pdb.gimp_edit_paste_as_new_image()

    @staticmethod
    def shape(j, w, h):
        """
        Resize, copy, and close an image.

        j: GIMP image with one layer
        w: int
            width

        h: int
            height
        """
        z = j.layers[0]

        pdb.gimp_layer_scale(z, w, h, 1)
        pdb.gimp_image_resize_to_layers(j)
        Lay.kopy(j)
        RollerImage.bury(j)
