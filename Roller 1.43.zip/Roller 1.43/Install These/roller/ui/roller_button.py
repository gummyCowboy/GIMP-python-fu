#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_widget import Widget
import gtk


class RollerButton(Widget):
    """This is a custom GTK Button."""

    def __init__(
                self,
                text,
                on_action,
                padding=None,
                align=(0, 0, 1, 0)
            ):
        """
        Create a gtk.Button that is attached to an gtk.Alignment.

        Use the Widget class callback.

        text: string
            Button label

        on_action: function
            callback on action

        padding: tuple
            Alignment padding
        """
        g = self.alignment = gtk.Alignment(*align)
        g1 = gtk.Button(text)

        Widget.__init__(self, on_action, widget=g1)
        g1.connect('clicked', self.callback)
        g.add(g1)
        if padding:
            g.set_padding(*padding)
