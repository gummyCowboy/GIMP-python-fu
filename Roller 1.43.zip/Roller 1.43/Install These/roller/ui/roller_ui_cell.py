#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_base import Base
from roller_constant import (
        ForCell,
        ForColor,
        ForFormat,
        FormatKey,
        ForWidget,
        UICellKey,
        UIKey,
    )

from roller_box import RollerBox
from roller_eventbox import REventBox
from roller_label import RollerLabel
from roller_spin_button import RollerSpinButton
from roller_splitter import Splitter
from roller_ui_switch import UISwitch
import gtk


class UICell(UISwitch):
    """Draw the Per Cell windows."""

    # GTK will sometimes draw scroll-bars after the window's size changes:
    EXTRA = 5
    NP = "No Picture"
    HEADER_COLOR = 44000, 44000, ForColor.MAX_COLOR
    LAB_WIDTH = 'label_width'
    LAB_KEY_LIST = LAB_WIDTH, 'label_height', 'label_x', 'label_y'
    LABEL_ID = "w: ", "h: ", "x: ", "y: "

    def __init__(self, d):
        """d: dict"""
        k = self.cell_table_key = d[UICellKey.CELL_TABLE_KEY]
        e = ForCell.CELL_TABLE_DICT[k]
        x = e['index']
        self.is_merge = not x
        self.split_cells = False
        d[UIKey.WINDOW_TITLE] = e['name'] + ": Use Escape or Enter"
        self.merged = d[UICellKey.MERGE_PER_CELL]
        self.start_format = d[UIKey.FORMAT_DICT]
        self._layout = d[UIKey.LAYOUT]
        self.placement_widget = []
        self.stat = d[UIKey.STAT]
        d[UIKey.ON_RETURN] = self.do_job
        d[UIKey.WINDOW_KEY] = e['window_key']

        # cell window format copy:
        self.format = deepcopy(self.start_format)
        self._init_cells(d)
        self._layout.calc_cell_table(self.format)
        UISwitch.__init__(self, d)

    def _draw_column_header(self, c, c1):
        """
        Draw a column header.

        c: int
            table column

        c1: int
            actual column
        """
        # column header:
        g = REventBox(UICell.HEADER_COLOR)
        g1 = gtk.Frame()

        if c % 2:
            g2 = self.col_label = RollerLabel(
                str(c1), align=(0, 0, 1, 0)).alignment
            g1.add(g2)

        g.add(g1)
        return g

    def _draw_row_header(self, r, r1):
        """
        Draw row header.

        r: int
            table row

        r1: int
            row number
        """
        # row header:
        g = REventBox(UICell.HEADER_COLOR)
        g1 = gtk.Frame()

        if r % 2:
            g2 = self.row_label = RollerLabel(
                    str(r1),
                    padding=(0, 0, 4, 4),
                    align=(0, 0, 0, 1)
                ).alignment
            g1.add(g2)

        g.add(g1)
        return g

    def _init_cells(self, _):
        """Set the initial data needed to draw cells."""
        d = self.format
        row, col = d[FormatKey.ROW], d[FormatKey.COLUMN]
        self.table = Base.create_2d_table(row, col)

        # Load cell dimensions:
        for r in range(row):
            for c in range(col):
                if self.merged:
                    s = d[FormatKey.CELL_TABLE_MERGE][r][c]

                else:
                    s = 1, 1
                self.table[r][c] = {
                        'size': s,
                        'row': r,
                        'column': c
                    }

        # Initialize top-left references:
        for r in range(row):
            for c in range(col):
                e = self.table[r][c]
                if UICell._is_topleft(e):
                    t = e

                    # Initialize sub-topleft cells:
                    for r1 in range(r, r + t['size'][0]):
                        for c1 in range(c, c + t['size'][1]):
                            if r1 != r or c1 != c:
                                e = self.table[r1][c1]
                                e['topleft'] = t['row'], t['column']

    def _is_picture(self, d):
        """
        Return a true if there is an image assigned to the current cell.

        d: cell dict
        """
        e = self.format
        m = 1
        fk, ff = FormatKey, ForFormat

        # "None" image:
        if self.cell_table_key != FormatKey.CELL_TABLE_PLACEMENT:
            if not e[fk.CELL_TABLE_PLACEMENT]:
                m = e[fk.IMAGE] != ff.NONE

            else:
                m = e[fk.CELL_TABLE_PLACEMENT][d['row']][d[
                    'column']][ff.IMAGE_INDEX] != ff.NONE

        # zero opacity:
        if m:
            if self.cell_table_key != FormatKey.CELL_TABLE_PROPERTY:
                if not e[fk.CELL_TABLE_PROPERTY]:
                    m = e[fk.OPACITY] != 0

                else:
                    m = e[
                        fk.CELL_TABLE_PROPERTY][d['row']][d['column']][
                            ff.OPACITY_INDEX] != 0

        if not m:
            # Widen the cell:
            n = UICell.NP + "." * 25 if not d['row'] \
                and not d['column'] else UICell.NP
            self.table[d['row']][d['column']]['box'].add(
                RollerLabel(n).alignment)
        return m

    def _on_widget_change(self, g):
        """
        Update the format dict and widget visibility.

        g: Widget
        """
        x = g.index
        k = g.cell_table_key
        if not self.loading:
            q = list(self.format[k][g.r][g.c])
            q[x] = g.get_value()
            self.format[k][g.r][g.c] = tuple(q)

            if k == FormatKey.CELL_TABLE_PLACEMENT:
                if x in (ForFormat.RESIZE_INDEX, ForFormat.IMAGE_INDEX):
                    self.verify_place_menus(g)

            elif k == FormatKey.CELL_TABLE_PROPERTY:
                if x == ForFormat.OPACITY_INDEX:
                    self.verify_opacity_depend(g)
        if k == FormatKey.CELL_TABLE_PLACEMENT:
            if x == ForFormat.IMAGE_INDEX:
                n = g.get_value()
                n = n if len(n) > 10 else ""
                g.alignment.set_tooltip_text(n)

    def do_job(self):
        """Accept the format dict."""
        if self.placement_widget:
            for g in self.placement_widget:
                self._on_widget_change(g)

        self.start_format.update(self.format)
        return self.close()

    def _draw_cell(self, _, d):
        """
        Call for each cell.

        Initialize the cell's dictionary.

        Draw connectors and cell sizes.

        d: cell dict
        """
        e = self.table[d['row']][d['column']]

        g = self._get_topleft(d=e)
        start, end = UICell._get_start_end_of_top(g)
        self._set_cell_looks(e, start, end)
        if not self.is_merge:
            if e['size'] != (-1, -1):
                self.draw_cell(d)

    @staticmethod
    def _get_start_end_of_top(d):
        """
        Return the row and column for the current
        cell and its bottom-right cell.

        d: dict
            cell dict
        """
        s = d['row'], d['column']
        t = s[0] + d['size'][0] - 1, s[1] + d['size'][1] - 1
        return s, t

    def _get_topleft(self, d=None, u=None):
        """
        Top-left is the cell located at the top-left of a group.

        Sub-top-left cells refer to the top-left
        cell through a ‟topleft” key.

        d: dict
            cell dict

        u: tuple
            (row, column)
        """
        if u:
            d = self.table[u[0]][u[1]]

        if d['size'][0] < 0:
            v = d['topleft']

        else:
            v = d['row'], d['column']
        return self.table[v[0]][v[1]]

    @staticmethod
    def _is_group(d):
        """
        Return true if a cell is part of a group.

        d: dict
            cell dict
        """
        return UICell._is_topleft(d) or d['size'] == (-1, -1)

    @staticmethod
    def _is_topleft(d):
        """
        Return true if the cell is a top-left cell.

        d: dict
            cell dict
        """
        return d['size'][0] > 1 or d['size'][1] > 1

    def _is_vector(self, u, r, c):
        """
        Return true if the cell (r, c) is still
        referencing a top-left cell at ‟u”.

        u: tuple
            (row, column)
        """
        d = self.table[r][c]

        # Independent cells are not part of a vector:
        if UICell._is_group(d):
            a = self._get_topleft(d)

            # Cell must refer to its old top:
            if a['row'] == u[0] and a['column'] == u[1]:
                return 1

    def _set_block_looks(self, start, end):
        """
        Set the appearance of a block of cells.

        start: tuple
            (r, c) for the top-left cell

        end: tuple
            (r, c) for the bottom-right cell
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self._set_cell_looks(self.table[r][c], start, end)

    def _set_cell_looks(self, d, start, end):
        """
        Set a cell's appearance.

        d: dict
            cell dict

        start: tuple
            (r, c) for the top-left cell

        end: tuple
            (r, c) for the bottom-right cell
        """
        if d['size'] == (1, 1):
            self._set_single_looks(d)

        else:
            # The cell is a member of a group:
            k = 'left_b'
            k1 = 'top_b'

            # cell neighbor flags:
            top = d['row'] > start[0]
            bottom = d['row'] < end[0]
            left = d['column'] > start[1]
            right = d['column'] < end[1]

            # top, bottom, left, right:
            w = [5, 5, 5, 5]

            for x, i in enumerate((top, bottom, left, right)):
                if i:
                    w[x] = 0

            d['pad'].set_padding(*w)
            UICell._set_group_looks(d)
            if self.is_merge:
                # button updates:
                if k in d:
                    if left:
                        w = [5, 5, 0, 0]
                        for x, i in enumerate((top, bottom)):
                            if i:
                                w[x] = 0
                        d[k].pad.alignment.set_padding(*w)
                        d[k].set_label("-")
                        d[k].gate = 1

                    else:
                        d[k].set_label("+")
                        d[k].gate = 0
                        d[k].pad.alignment.set_padding(5, 5, 0, 0)

                if k1 in d:
                    if top:
                        w = [0, 0, 5, 5]
                        for x, i in enumerate((left, right)):
                            if i:
                                w[x + 2] = 0

                        d[k1].pad.alignment.set_padding(*w)
                        d[k1].set_label("-")
                        d[k1].gate = 1

                    else:
                        d[k1].set_label("+")
                        d[k1].gate = 0
                        d[k1].pad.alignment.set_padding(0, 0, 5, 5)
        self._update_cell_label(d)

    @staticmethod
    def _set_group_looks(d):
        """
        Change the appearance of a cell's frame to appear merged.

        d: dict
            cell dict
        """
        d['event_box'].modify_bg(
            gtk.STATE_NORMAL, ForColor.NORMAL_BUTTON_COLOR)

    def _set_single_looks(self, d):
        """
        Change the appearance of a cell's frame to appear independent.

        If the cell is changing because of a split cells operation,
        then update the cell's switch buttons.

        d: dict
            cell dict
        """
        d['pad'].set_padding(5, 5, 5, 5)
        d['event_box'].modify_bg(gtk.STATE_NORMAL, ForColor.SINGLE_CELL_COLOR)
        if self.split_cells:
            for k in ('left_b', 'top_b'):
                if k in d:
                    d[k].set_label("+")
                    d[k].gate = 0

                    if k == 'left_b':
                        d[k].pad.alignment.set_padding(5, 5, 0, 0)
                    if k == 'top_b':
                        d[k].pad.alignment.set_padding(0, 0, 5, 5)

    @staticmethod
    def _set_subtop(d, e):
        """
        Modify the cell's dictionary to identify the cell as a sub-topleft.

        d: dict
            the top-left cell's dict

        e: dict
            the sub-top cell's dict
        """
        e['topleft'] = d['row'], d['column']
        e['size'] = -1, -1

    def _update_block(self, start, end):
        """
        Update format data, cell size table,
        and the cell appearance for a block of cells.

        start: the top-left cell in the block
        end: the bottom-right cell in the block
        """
        self._update_format(start, end)
        self._layout.calc_block(start, end, self.format)
        self._set_block_looks(start, end)

    def _update_cell_label(self, d):
        """
        Call whenever a cell is drawn.

        Update the cell dimension labels.

        d: dict
            cell dict
        """
        if self.is_merge:
            if UICell._is_topleft(d) or d['size'] == (1, 1):
                b = self._layout.get_cell_info(d['row'], d['column'])

                if UICell.LAB_WIDTH in d:
                    for x, k in enumerate(UICell.LAB_KEY_LIST):
                        d[k].label.set_text(UICell.LABEL_ID[x] + str(b[x]))

                else:
                    for x, k in enumerate(UICell.LAB_KEY_LIST):
                        g = d[k] = RollerLabel(UICell.LABEL_ID[x] + str(b[x]))

                        d['box'].add(d[k].alignment)

                        # Need to show both:
                        g.alignment.show()
                        g.label.show()

            else:
                if UICell.LAB_WIDTH in d:
                    # Delete the Labels:
                    for k in UICell.LAB_KEY_LIST:
                        b = d[k]

                        d['box'].remove(b.alignment)
                        d.pop(k)
                        b.destroy()

    def _update_format(self, start, end):
        """
        Update the format data for a block of cells.

        start: the top-left cell in the block
        end: the bottom-right cell in the block.
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self.format[FormatKey.CELL_TABLE_MERGE][r][c] = \
                    self.table[r][c]['size']

    def draw_margin_cell(
                self,
                d,
                spin_key,
                max_spin_value,
                step=(1, 1),
                type_index=ForWidget.INT_INDEX
            ):
        """
        Call for each cell.

        Draw margin Labels and SpinButtons.

        d: dict
            cell dict

        spin_key: list of string
            SpinButton widget key list

        max_spin_value: tuple
            Maximum value for each SpinButton

        step: tuple
            Use with float SpinButton

        type_index: int
            Determine int or float SpinButton-type.
        """
        # These widgets use an index:
        if self._is_picture(d):
            e = self.format[
                self.cell_table_key][d['row']][d['column']]

            g = self.table[d['row']][d['column']]['box']
            for x, n in enumerate(
                    (
                        ForFormat.TOP,
                        ForFormat.BOTTOM,
                        ForFormat.LEFT,
                        ForFormat.RIGHT
                    )):
                g1 = Splitter()
                g2 = RollerSpinButton(
                        self._on_widget_change,
                        (0, max_spin_value[x]),
                        key=spin_key[x],
                        step=step,
                        type_index=type_index,
                        precision=6
                    )

                g2.cell_table_key = self.cell_table_key
                g2.r, g2.c = d['row'], d['column']
                g2.index = x

                self.keep((g2,))
                g1.both(RollerLabel(n + ":").alignment, g2.alignment)
                g2.set_value(e[x])
                g1.pack()
                g.add(g1.container)

    def draw_window(self):
        """
        Draw the background framework used by the three Per Cell windows.

        Is part of the UI window template.
        """
        is_merge = self.is_merge
        is_not_merge = not is_merge
        fk, span = FormatKey, ForWidget.SCROLL_SPAN
        d = self.format
        row, col = d[fk.ROW] * 2, d[fk.COLUMN] * 2
        vbox = self.win.vbox
        table = gtk.Table(row, col)
        scroll = gtk.ScrolledWindow()
        is_1st_cell = 1

        scroll.add_with_viewport(table)
        vbox.add(scroll)
        scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        self.buttons = Base.create_2d_table(
            d[fk.ROW], d[fk.COLUMN])
        for r in range(row):
            for c in range(col):
                r1, c1 = r / 2 + 1, c / 2 + 1
                r2, c2 = r / 2 - 1, c / 2 - 1

                if r == 0:
                    if is_merge or (is_not_merge and c % 2):
                        g = self._draw_column_header(c, c1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif c == 0:
                    if is_merge or (is_not_merge and r % 2):
                        g = self._draw_row_header(r, r1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif r % 2 and c % 2:
                    # Create cell:
                    r3, c3 = d['row'], d['column'] = r / 2, c / 2
                    e = self.table[r3][c3]

                    # Add buttons to the cell's dictionary:
                    if r > 1:
                        e['top_b'] = self.buttons[r2][c3]

                    if c > 1:
                        e['left_b'] = self.buttons[r3][c2]

                    g = RollerBox(ForWidget.VBOX, align=(0, 0, 1, 1))
                    e['pad'] = g.alignment
                    g1 = e['event_box'] = REventBox(None)
                    g2 = RollerBox(ForWidget.VBOX, padding=(5, 5, 5, 5))
                    g3 = self.table[r3][c3]['box'] = g2.box

                    g.add(g1)
                    g1.add(g2.alignment)
                    table.attach(g.alignment, c, c + 1, r, r + 1)
                    self._draw_cell(g3, d)

                    if is_1st_cell:
                        """
                        "show_all" causes the "vbox" allocation to be
                        calculated which will fail ScrolledWindow's dependency.
                        So it's calculate the scroll region-size manually.
                        """
                        self.win.show_all()

                        # scaling:
                        is_1st_cell = 0
                        w = max(g3.allocation.width, g3.allocation.height)
                        w1, h = w * d[fk.COLUMN], w * d[fk.ROW]
                        w2 = self.row_label.allocation.width
                        h1 = self.col_label.allocation.height
                        button_w = 0 if is_not_merge else \
                            15 * (d[fk.COLUMN] - 1)

                        button_h = 0 if is_not_merge else \
                            15 * (d[fk.ROW] - 1)

                        pad_w = 20 * d[fk.COLUMN]
                        pad_h = 20 * d[fk.ROW]
                        extra_width, extra_height = row, col
                        extra = UICell.EXTRA
                        extra += 15 if is_not_merge == 3 else 0

                        # totaling:
                        w1 += w2 + pad_w + button_w + extra_width + \
                            span + extra

                        h += h1 + pad_h + button_h + extra_height + \
                            span + extra

                        w1, h = self.get_remaining_dim(w1, h)
                        self.win.vbox.set_size_request(w1, h)
                    g3.set_size_request(w, w)

                elif not (not r % 2 and not c % 2):
                    if is_merge:
                        g, g1 = self.draw_connector(r, c)
                        g.add(g1)
                        table.attach(g.alignment, c, c + 1, r, r + 1)

                else:
                    if is_merge:
                        # nothing reactive:
                        g = REventBox(ForColor.BACKGROUND_BUTTON_COLOR)
                        g1 = gtk.HBox()
                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)
