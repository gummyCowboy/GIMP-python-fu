#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import uniform
from roller_constant_for import (
    Fringe as ng,
    Gradient as fg,
    Model as mo,
    Plan as fy,
    Shape as sh,
    Triangle as ft
)
from roller_constant_key import Layer as nk, Option as ok
from roller_constant_fu import Fu
from roller_model_image import Image
from roller_one import Base, Comm, Hat
from roller_one_extract import dispatch, Form, Path, Shape
from roller_one_fu import Lay, Mage, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
pb = Fu.PaintBrush
FRINGE_MAT = (
    ng.AS_IS,
    ng.BACKDROP,
    ng.GRADIENT,
    ng.IMAGE,
    ng.ONE_COLOR,
    ng.PATTERN,
    ng.PLASMA,
    ng.TWO_COLOR
)
RECTANGLE = sh.RECTANGLE


def apply_brush(z, q):
    """
    Perform a brush stroke.

    z: layer
        to receive brush

    q: tuple
        x, y
        position of stroke
    """
    pdb.gimp_paintbrush(
        z,
        pb.NO_FADE_OUT,
        pb.STROKES_2,
        q,
        fu.PAINT_CONSTANT,
        pb.GRADIENT_LENGTH_0
    )


def brush_rect(j, z, o, angle, spacing, jitter):
    """
    Do brush for a rectangular shape.

    j: GIMP image
        Is render.

    z: layer
        to receive paint material

    o: One
        Has WIP variables.

    angle: float
        for brush

    spacing: float
        between brush applications

    jitter: float
        random angle modification
    """
    def calc_angle():
        return Base.seal(a + uniform(-jitter, jitter), -180., 180.)

    a = angle
    _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
    x_offset = int((x1 - x) % spacing / 2)
    y_offset = int((y1 - y) % spacing / 2)
    brush_x = x + x_offset

    pdb.gimp_selection_none(j)

    # top of cell:
    while brush_x <= x1:
        pdb.gimp_context_set_brush_angle(calc_angle())
        set_foreground_color(o)
        apply_brush(z, (brush_x, y))
        brush_x += spacing

    # right of cell:
    a = angle + 90

    if a > 180:
        a = angle - 90

    brush_y = y + y_offset

    while brush_y <= y1:
        pdb.gimp_context_set_brush_angle(calc_angle())
        set_foreground_color(o)
        apply_brush(z, (x1, brush_y))
        brush_y += spacing

    # bottom of cell:
    brush_x = x1 - x_offset
    a = angle + 180

    if a > 180:
        a = angle - 180

    while brush_x >= x:
        pdb.gimp_context_set_brush_angle(calc_angle())
        set_foreground_color(o)
        apply_brush(z, (brush_x, y1))
        brush_x -= spacing

    # left of cell:
    a = angle + 270

    while a > 180:
        a -= 360

    brush_y = y1 - y_offset
    while brush_y >= y:
        pdb.gimp_context_set_brush_angle(calc_angle())
        set_foreground_color(o)
        apply_brush(z, (x, brush_y))
        brush_y -= spacing


def complete(z, d):
    """
    Complete the fringe paint with bump and mode.

    z: layer
        with fringe

    d: dict
        of fringe, form

    Return: layer
        with fringe material
    """
    z = RenderHub.do_mode(z, d)
    return RenderHub.bump(z, d[ok.BUMP])


def do_as_is(_, z, o):
    """
    Make cell fringe from the brush's output.

    _: GIMP image
        Is render.

    z: layer
        Has fringe material.

    o: One
        Has cell data.

    Return: layer
        Has image.
    """
    return complete(z, o.e)


def do_backdrop(_, z, o):
    """
    Make cell fringe from the backdrop layers.

    _: GIMP image
        Is render.
        not used

    z: layer
        Has fringe material.

    o: One
        Has cell data.

    Return: layer
        Has image.
    """
    z1 = Lay.clone_background(z)

    transfer_sel(z, z1)
    return complete(z1, o.e)


def do_brush(j, z, o):
    """
    Paint fringe material.

    j: GIMP image
        Is render.

    z: layer
        to receive paint

    o: One
        Has cell data.

    Return: layer
        with paint
    """
    cat = Hat.cat
    d = o.e
    e = d[ok.BRUSH_DICT]
    brush = e[ok.BRUSH]
    o.colors = None
    callback = None

    if brush not in cat.brush_list:
        Comm.info_msg(mo.MISSING_ITEM.format("self", "brush", brush))

    else:
        if o.is_plan:
            pass

        elif o.type_ == ng.TWO_COLOR:
            o.colors = d[ok.COLOR_1], d[ok.COLOR_2]
            callback = set_foreground_color
            o.color = o.colors[0]

        elif o.type_ == ng.ONE_COLOR:
            o.color = d[ok.COLOR]
            pdb.gimp_context_set_foreground(o.color)

        else:
            if not hasattr(o, 'color'):
                o.color = pdb.gimp_context_get_foreground()

        brush_size = e[ok.BRUSH_SIZE]
        spacing = e[ok.BRUSH_SPACING]
        f = spacing / brush_size
        angle = e[ok.BRUSH_ANGLE]

        pdb.gimp_selection_shrink(j, d[ok.CONTRACT])
        if Sel.is_sel(j):
            pdb.gimp_context_set_dynamics('Dynamics Off')
            pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
            pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
            pdb.gimp_context_set_brush_aspect_ratio(0.)
            pdb.gimp_context_set_brush_force(1)
            pdb.gimp_context_set_antialias(1)
            pdb.gimp_context_set_brush_spacing(f)
            pdb.gimp_context_set_brush_hardness(e[ok.BRUSH_HARDNESS])
            pdb.gimp_context_set_brush(brush)
            pdb.gimp_context_set_brush_size(brush_size)
            pdb.gimp_context_set_opacity(e[ok.OPACITY])
            pdb.gimp_context_set_foreground(o.color)

            _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

            if (
                Shape.is_rectangular_shape(o.shape) and
                max(x1 - x, y1 - y) > spacing
            ):
                brush_rect(j, z, o, angle, spacing, e[ok.ANGLE_JITTER])

            else:
                pdb.plug_in_sel2path(j, z)

                stroke = j.active_vectors.strokes[0]

                pdb.gimp_selection_none(j)
                RenderHub.brush_stroke_on_stroke(
                    z,
                    brush,
                    brush_size,
                    stroke,
                    spacing,
                    e[ok.ANGLE_JITTER],
                    callback=(callback, o)
                )
    return z


def do_cell(o):
    """
    Process the fringe for a cell.

    o: One
        Has cell values.

    Return: layer or None
        with fringe
    """
    cat = Hat.cat
    z = None
    is_paint = o.type_ != ng.MASK
    o.is_paint |= is_paint
    j = cat.render.image

    if is_paint:
        z = Lay.add(j, o.name, parent=o.group)
        z = do_paint(j, z, o)
        if hasattr(o, 'mask_sel'):
            o.mask_sel += [cat.get_plaque_sel(o.model_name, o.r, o.c)]

    else:
        # fringe mask dependency:
        d = o.plaque_dict
        opacity = d[ok.OPACITY]
        if opacity and o.type_ != "None":
            o.make_path = Path.make_cell_plaque_path
            do_mask(o)
    return z


def do_gradient(j, z, o):
    """
    Make a gradient cell fringe.

    j: GIMP image
        Is render.

    z: layer
        Has material to select.

    o: One
        Has cell data.

    Return: layer
        Has gradient.
    """
    def draw_gradient(_start_x, _end_x, _start_y, _end_y):
        """
        Draw a gradient given a layer, a start-point and an end-point.
        """
        pdb.gimp_drawable_edit_gradient_fill(
            z1,
            fg.GRADIENT_TYPE_LIST.index(gradient_type),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            _start_x, _start_y,
            _end_x, _end_y
        )

    def finish_gradient():
        transfer_sel(z, z1)
        return complete(z1, o.e)

    cat = Hat.cat
    z1 = None
    gradient = o.e[ok.GRADIENT]

    if gradient in cat.gradient_list:
        Sel.item(z)

        a, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        w, h = x1 - x, y1 - y
        if a:
            gradient_type = o.e[ok.GRADIENT_TYPE]

            RenderHub.set_fill_context(fg.FILL_DICT)
            pdb.gimp_context_set_gradient(gradient)
            pdb.gimp_context_set_gradient_blend_color_space(
                fu.GRADIENT_BLEND_RGB_PERCEPTUAL
            )
            pdb.gimp_context_set_gradient_reverse(0)

            if gradient_type in fg.SHAPE_BURST:
                j1 = pdb.gimp_image_new(w, h, fu.RGB)
                z1 = Lay.add(j1, '')

                pdb.gimp_selection_all(j1)
                Sel.fill(z1, (127, 127, 127))
                pdb.gimp_selection_none(j1)
                draw_gradient(0, 0, 0, 0)
                Mage.copy_all(j1)
                pdb.gimp_image_delete(j1)

                z1 = Lay.paste(z)
                z1.name = o.name

                pdb.gimp_layer_set_offsets(z1, x, y)
                z1 = finish_gradient()

            else:
                z1 = Lay.add(j, o.name, parent=o.group)
                start_x, end_x, start_y, end_y = \
                    RenderHub.get_gradient_points(
                        o.e[ok.GRADIENT_ANGLE],
                        x, y,
                        w, h
                    )

                Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
                draw_gradient(start_x, end_x, start_y, end_y)
                z1 = finish_gradient()

    else:
        Comm.info_msg(
            mo.MISSING_ITEM.format("self", "gradient", gradient)
        )
    return z1 if z1 else z


def do_image(j, z, o):
    """
    Make a image cell fringe.

    j: GIMP image
        Is render.

    z: layer
        Has fringe material.

    o: One
        Has cell data.

    Return: layer or None
        Has fringe.
    """
    z1 = None

    Sel.item(z)

    a, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
    w, h = x1 - x, y1 - y

    if a:
        pdb.gimp_selection_none(j)

        image = o.e[ok.IMAGE]
        j1 = Image.get_image(image, o.image_index)
        if j1:
            j2 = j1.j

            Mage.copy_all(j2)

            j2 = pdb.gimp_edit_paste_as_new_image()

            Mage.shape(j2, w, h)

            z1 = Lay.paste(z)

            pdb.gimp_layer_set_offsets(z1, x, y)
            Image.close_image(j1)
            transfer_sel(z, z1)
            z1 = complete(z1, o.e)
    return z1 if z1 else z


def do_mask(o):
    """
    Mask the edge of a plaque.

    o: One
        Has cell data.

    plaque_name: string
        to find the fringe layer's plaque layer
    """
    cat = Hat.cat
    j = cat.render.image
    d = o.plaque_dict
    opacity = d[ok.OPACITY]
    plaque_type = d[ok.PLAQUE_TYPE]
    if opacity and plaque_type != "None":
        z = o.plaque_layer
        if z:
            # mask layer:
            z1 = Lay.add(j, 'Mask', parent=o.parent)
            sel = cat.get_plaque_sel(o.model_name, o.r, o.c)

            Sel.load(j, sel)

            if Sel.is_sel(j):
                z1 = do_brush(j, z1, o)
                o.is_mask = True

                Sel.item(z1)
                Sel.invert(j)
                Sel.load(j, sel, option=fu.CHANNEL_OP_INTERSECT)

                if o.is_grid:
                    o.mask_sel += [cat.save_short_term_sel()]
                else:
                    mask = pdb.gimp_layer_create_mask(
                        z,
                        fu.ADD_MASK_SELECTION
                    )
                    pdb.gimp_layer_add_mask(z, mask)
            pdb.gimp_image_remove_layer(j, z1)


def call_complete(_, z, o):
    """
    Complete the one color fringe.

    _: GIMP image
        Is render.
        not used

    z: layer
        Has fringe material.

    o: One
        Has cell data.

    Return: layer
        Has fringe.
    """
    return complete(z, o.d)


def do_paint(j, z, o):
    """
    Paint a fringe texture on the cell fringe layer.

    j: GIMP image
        Is render.

    z: layer
        for fringe material

    o: One
        Has cell data.

    Return: layer or None
        fringe layer
    """
    def clip_cell():
        """Remove material outside of the cell."""
        if o.is_clip:
            # 'sel' is the cell selection:
            Sel.load(j, sel)
            Sel.invert(j)
            Lay.clear_sel(z)

    # 'o.e' is the fringe preset dict as
    # the form-only without the per-cell chunk:
    d = o.e

    pdb.gimp_selection_none(j)

    if Shape.is_rectangular_shape(o.shape):
        x, y, w, h = get_position_info(o)
        Sel.rect(j, x, y, w, h)

    else:
        Sel.select_shape(j, o.polygon)
    if Sel.is_sel(j):
        # Use with clip:
        sel = pdb.gimp_selection_save(j)

        z = do_brush(j, z, o)

        Sel.item(z)

        if Sel.is_sel(j):
            if o.is_plan:
                clip_cell()
            else:
                if o.type_ in FRINGE_MAT:
                    # Apply material and clear outside
                    # of the fringe-layer-selection:
                    z = fringe_job[o.type_](j, z, o)

                    clip_cell()

                    if all(
                        (
                            Shadow.get_type(d[ok.TRI_SHADOW]),
                            not o.is_plan,
                            z
                        )
                    ):
                        z = Shadow.do_shadows(d[ok.TRI_SHADOW], z)
                        if z:
                            clip_cell()
                    if z:
                        z.name = o.name
        pdb.gimp_image_remove_channel(j, sel)
    return z


def do_pattern(j, z, o):
    """
    Make a pattern cell fringe.

    j: GIMP image
        Is render.

    z: layer
        Has paint.

    o: One
        Has cell data.

    Return: layer or None
        Has pattern.
    """
    cat = Hat.cat
    z1 = None
    pattern = o.e[ok.PATTERN]

    if pattern in cat.pattern_list:
        pdb.gimp_selection_all(j)

        a, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        w, h = x1 - x, y1 - y
        if a:
            z1 = Lay.add(j, o.name, parent=o.group)
            s = cat.render.size

            Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
            RenderHub.set_fill_context(fg.FILL_DICT)
            pdb.gimp_context_set_pattern(pattern)
            pdb.gimp_drawable_edit_bucket_fill(
                z1,
                fu.FILL_PATTERN,
                min(s[0] - 1, x + w // 2),
                min(s[1] - 1, y + h // 2)
            )
            transfer_sel(z, z1)
            z1 = complete(z1, o.e)

    else:
        Comm.info_msg(mo.MISSING_ITEM.format("self", "pattern", pattern))
    return z1 if z1 else z


def do_plasma(j, z, o):
    """
    Make a plasma cell fringe.

    j: GIMP image
        Is render.

    z: layer
        Has material to select.

    o: One
        Has cell data.

    Return: layer
        Has gradient.
    """
    z1 = Lay.add_above(z)

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z1, o.e[ok.RANDOM_SEED], 3)
    transfer_sel(z, z1)
    return complete(z1, o.e)


def get_position_info(o):
    """
    Return position info.

    o: One
        Has cell data.
    """
    return o.x, o.y, o.w, o.h


def set_foreground_color(o):
    """
    Set the foreground color for the brush to use.

    Alternate colors if using two colors.
    """
    if hasattr(o, 'colors'):
        if o.colors:
            if o.colors[0] == o.color:
                o.color = o.colors[1]
            else:
                o.color = o.colors[0]
        pdb.gimp_context_set_foreground(o.color)


def transfer_sel(z, z1):
    """
    Transfer the alpha selection from the painted
    fringe layer to the material fringe layer.

    z: layer
        with painted fringe

    z1: layer
        with fringe material
    """
    if z:
        Sel.item(z)
        Sel.invert_clear(z1)
        pdb.gimp_image_remove_layer(z.image, z)


class Fringe:
    """Manage fringe operation."""

    @staticmethod
    def do_custom_cell(o, is_plan):
        """
        Do a custom cell fringe.

        One: o
            Has variables

        Return: tuple or None
            with fringe layer
        """
        parent = o.parent
        d = o.e = o.d
        z = None
        opacity = d[ok.BRUSH_DICT][ok.OPACITY]
        o.type_ = d[ok.FRINGE_TYPE]
        o.is_mask = o.is_grid = o.is_paint = False

        if opacity and o.type_ != "None":
            o.name = Lay.name(parent, nk.CELL_FRINGE)
            shape = o.cell.shape

            if d[ok.OBEY_MARGINS]:
                a = o.cell.pocket

            else:
                a = o.cell.rect

            o.is_clip = d[ok.CLIP_TO_CELL]
            o.is_plan = is_plan
            o.polygon = dispatch[shape](a)
            o.plaque_dict = Path.get_cell_plaque(o.path)
            o.shape = shape
            o.w, o.h = a.size
            o.x, o.y = a.position
            o.r = o.c = fy.CUSTOM_CELL
            o.group = o.parent
            z = do_cell(o)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.FRINGE_INFLUENCE)
        return z

    @staticmethod
    def do_grid(o, is_plan):
        """
        Do the cell fringe for a format.

        o: One
            Has variables.

        Return: tuple
            with fringe layer, is mask flag, is layer fringe flag
        """
        def act():
            """Use to lower indentation."""
            m = True

            if m:
                # Is the cell a sub-topleft cell?
                if is_merge_cell:
                    if o.grid_d[ok.PER_CELL][r][c] == (-1, -1):
                        m = False

            if m:
                m = Shape.is_allocated_cell(o.grid, r, c)

            if m:
                o.r, o.c = r, c
                e = o.e = Form.get_form(d, r, c) if is_per_cell else d

                if (
                    e[ok.OBEY_MARGINS] and
                    Path.has_margin(Form.get_form(margin, r, c))
                ):
                    # Update plaque size:
                    rect = o.grid.get_pocket(r, c)
                    n = o.grid.cell_shape

                    if n in ft.TRIANGLE:
                        if Shape.is_inverse_triangle(r, c):
                            n = ft.INVERTED[n]
                    o.polygon = dispatch[n](rect)

                else:
                    rect = o.grid.get_merge_cell_rect(r, c)
                    o.polygon = o.grid.get_shape(r, c)

                o.x, o.y = rect.position
                o.w, o.h = rect.size
                o.type_ = e[ok.FRINGE_TYPE]
                m = o.type_ != "None"

            if m:
                m = True if e[ok.BRUSH_DICT][ok.OPACITY] else False

            if m:
                o.is_clip = e[ok.CLIP_TO_CELL]
                o.plaque_dict = Form.get_form(
                    Path.get_cell_plaque(o.path),
                    r, c
                )
                if not o.group:
                    o.group = Lay.group(j, o.name, parent)
                do_cell(o)
            else:
                o.mask_sel += [cat.get_plaque_sel(o.model_name, r, c)]

        cat = Hat.cat
        j = cat.render.image
        z = None
        d = o.d
        parent = o.parent
        o.name = Lay.name(parent, nk.CELL_FRINGE)
        is_merge_cell = o.grid.is_merge_cell
        o.group = None
        o.is_plan = is_plan
        o.shape = o.grid.cell_shape
        row, column = o.grid.division
        is_per_cell = d[ok.PER_CELL]
        go = o.is_grid = True
        o.is_mask = o.is_paint = False
        o.mask_sel = []
        margin = Path.get_cell_margin(o.path)

        pdb.gimp_selection_none(j)

        if not is_per_cell and d[ok.FRINGE_TYPE] == "None":
            go = False

        if go:
            for r in range(row):
                for c in range(column):
                    act()

        if o.group:
            if o.is_paint:
                z = Lay.merge_group(o.group)
            else:
                pdb.gimp_image_remove_layer(j, o.group)
                z = None

        if o.is_mask:
            pdb.gimp_selection_none(j)

            for i in o.mask_sel:
                Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
            if Sel.is_sel(j):
                z1 = o.plaque_layer
                mask = pdb.gimp_layer_create_mask(z1, fu.ADD_MASK_SELECTION)
                pdb.gimp_layer_add_mask(z1, mask)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.FRINGE_INFLUENCE)
        return z

    @staticmethod
    def do_layer(o, is_plan):
        """
        Do fringe for the layer.

        o: One
            Has init variables.

        is_plan: bool
            Is true when the caller is plan.

        Return: tuple
            with fringe layer, is mask flag, is layer fringe flag
        """
        d = o.e = o.d
        z = None
        cat = Hat.cat
        o.type_ = d[ok.FRINGE_TYPE]
        o.is_mask = o.is_grid = o.is_paint = False
        if o.type_ != "None":
            j = cat.render.image

            # Preserve:
            foreground = pdb.gimp_context_get_foreground()

            parent = o.group = o.parent
            o.is_plan = is_plan
            o.shape = RECTANGLE
            size = cat.render.size

            if d[ok.OBEY_MARGINS]:
                o.y, bottom, o.x, right = o.layer_margin
                o.w = size[0] - o.x - right
                o.h = size[1] - o.y - bottom

            else:
                o.x = o.y = 0
                o.w, o.h = size

            w, h = o.x + o.w, o.y + o.h
            o.polygon = o.x, o.y, w, o.y, w, h, o.x, h
            e = o.plaque_dict = Path.get_layer_plaque(o.path)
            o.name = Lay.name(parent, nk.LAYER_FRINGE)
            is_paint = o.is_paint = o.type_ != ng.MASK
            o.r = o.c = fy.LAYER

            if is_paint:
                o.is_clip = True if d[ok.OBEY_MARGINS] \
                    and d[ok.CLIP_TO_CELL] else False

                z = Lay.add(j, o.name, parent=parent)
                z = do_paint(j, z, o)

            else:
                # fringe mask dependency:
                if e[ok.OPACITY] and e[ok.PLAQUE_TYPE] != "None":
                    o.parent = parent
                    o.make_path = Path.make_layer_plaque_path
                    do_mask(o)

            # Restore:
            pdb.gimp_context_set_foreground(foreground)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.FRINGE_INFLUENCE)
        return z


fringe_job = {
    ng.AS_IS: do_as_is,
    ng.BACKDROP: do_backdrop,
    ng.GRADIENT: do_gradient,
    ng.IMAGE: do_image,
    ng.ONE_COLOR: call_complete,
    ng.PATTERN: do_pattern,
    ng.PLASMA: do_plasma,
    ng.TWO_COLOR: call_complete
}
