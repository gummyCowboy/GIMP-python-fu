#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, uniform
from roller_constant_for import (
    Justification as ju,
    Plan as fy,
    Resize as fz,
    Shape as sh
)
from roller_constant_fu import Fu
from roller_constant_key import Image as ik, Layer as nk, Option as ok
from roller_model_image import Image
from roller_one import Hat
from roller_one_extract import dispatch, Form, Shape
from roller_one_fu import Lay, Mage, Sel
from roller_render_hub import RenderHub
from roller_render_gradient_light import GradientLight
import gimpfu as fu

pdb = fu.pdb


def apply_shape_mask(j, z):
    """
    Create a cell-based shape selection and clear outside of it.

    j: Image
        Has cell data.

    z: layer
        with image
    """
    Sel.select_shape(z.image, j.shape)
    Sel.select_shape(z.image, j.plaque, option=fu.CHANNEL_OP_INTERSECT)
    Sel.invert_clear(z)


def calc_mold_position(grid, d, j):
    """
    Calculate an image's (x, y) position in a cell given
    the cell's pocket rectangle and the image's mold size.

    grid: Grid
        Has cell table.

    d: dict
        image place, form

    j: Image
        Has x and y position.
    """
    r, c = j.r, j.c
    pocket = get_pocket(grid, r, c, j=j)
    x, y = pocket.position
    w, h = j.mold.size
    n = d[ok.JUSTIFICATION]

    if n in ju.RIGHT:
        x += pocket.w - w

    if n in ju.CENTER_X:
        x += (pocket.w - w) // 2

    if n in ju.CENTER_Y:
        y += (pocket.h - h) // 2

    elif n in ju.BOTTOM:
        y += pocket.h - h

    x, y = shift_position(d, x, y)
    j.mold.position = x, y
    if r != fy.CUSTOM_CELL:
        grid.set_mold(r, c, (x, y), (w, h))


def get_trim_size(s, t):
    """
    Calculate the size of a trim.

    s: tuple
        (w, h)
        of int
        image size

    t: tuple
        (w, h)
        of int
        cell size

    Return: list
        size with trim
    """
    # ratios:
    w_r = t[0] / 1. / s[0]
    h_r = t[1] / 1. / s[1]

    if s[0] < t[0] and s[1] < t[1]:
        # No trim needed:
        w, h = s

    else:
        if w_r < h_r:
            # The image height is closer to the cell size:
            f = h_r

        else:
            # The image width is closer to the cell size:
            f = w_r

        w, h = int(s[0] * f), int(s[1] * f)
        w = min(w, s[0])
        h = min(h, s[1])

    # underflow:
    return [max(w, 1), max(h, 1)]


def get_pocket(grid, r, c, j=None):
    """
    Get the pocket topleft coordinate (x, y) for a cell.

    grid: Grid
        with pocket

    r, c: int
        row, column
        cell index

    j: Image
        Has 'd', its free cell dict.

    Return: tuple
        position
        x, y
    """
    if r != fy.CUSTOM_CELL:
        return grid.get_pocket(r, c)
    return j.pocket


def mold_cover(j, d):
    """
    Resize an image using the cover resize-type.

    Return with the image data in the buffer.

    j: Image
        Has cell info.

    d: dict
        of image place, form

    Return: buffer data
        of the image
    """
    s = j.size
    t = j.pocket.size

    if s[0] > t[0] and s[1] > t[1]:
        mold_trim(j, d)

    # width and height ratios:
    w_r = t[0] / 1. / s[0]
    h_r = t[1] / 1. / s[1]

    if w_r < h_r:
        # The image height is closer to the cell size:
        f = h_r

    else:
        # The image width is closer to the cell size:
        f = w_r

    Mage.copy_all(j.j)

    j1 = pdb.gimp_edit_paste_as_new_image()

    Mage.shape(j1, int(s[0] * f), int(s[1] * f))

    j1 = pdb.gimp_edit_paste_as_new_image()
    s1 = select_image_trim(d, j, j1)

    # Copy visible selection:
    pdb.gimp_edit_copy_visible(j1)

    pdb.gimp_image_delete(j1)

    j.mold.size = s1
    return True


def mold_crop(j, d):
    """
    Get image material through a crop.

    j: Image
        Has cell info.
        Has material.
        work-in-progress

    d: dict
        of image place, form

    Return: bool
        Is true if there is material in the buffer.
        buffer data
            of the image
    """
    j1 = None
    is_copy = True
    e = d[ok.RESIZE_METHOD]

    Sel.rect(
        j.j,
        e[ok.CROP_X], e[ok.CROP_Y],
        e[ok.CROP_W], e[ok.CROP_H],
        option=fu.CHANNEL_OP_REPLACE
    )

    if Sel.is_sel(j.j):
        # Copy selection:
        pdb.gimp_edit_copy_visible(j.j)
        pdb.gimp_selection_none(j.j)
        j1 = pdb.gimp_edit_paste_as_new_image()

    else:
        is_copy = False

    if j1:
        if j1.width > j.pocket.w or j1.height > j.pocket.h:
            # Copy a rectangle:
            j.mold.size = select_image_trim(d, j, j1)

        else:
            j.mold.size = j1.width, j1.height
            pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)
    return is_copy


def mold_fill(j, _):
    """
    Resize using a fill-image resize-type.

    j: Image
        Has cell info.

    _: dict
        of image place, form
        ignore

    Return: buffer data
        of the image
    """
    if j.size != j.pocket.size:
        Mage.copy_all(j.j)

        j1 = pdb.gimp_edit_paste_as_new_image()
        w, h = j.mold.size = j.pocket.size
        Mage.shape(j1, w, h)

    else:
        j.mold.size = j.size
        Mage.copy_all(j.j)
    return True


def mold_fixed(j, d):
    """
    Resize an image with fixed-size values.

    j: Image
        Has cell info.
        Has material.
        work-in-progress

    d: dict
        of image place, form

    Return: flag
        Is true if there is material in the buffer.

        buffer data
            of the image
    """
    is_copy = True

    Mage.copy_all(j.j)

    j1 = pdb.gimp_edit_paste_as_new_image()
    e = d[ok.RESIZE_METHOD]

    pdb.gimp_layer_scale(
        j1.layers[0],
        e[ok.FIXED_IMAGE_SIZE_W],
        e[ok.FIXED_IMAGE_SIZE_H],
        Fu.LayerScale.IMAGE_ORIGIN
    )
    pdb.gimp_image_resize_to_layers(j1)

    if j1:
        if j1.width > j.pocket.w or j1.height > j.pocket.h:
            # Copy a rectangle:
            j.mold.size = select_image_trim(d, j, j1)

        else:
            j.mold.size = j1.width, j1.height
            pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

    else:
        is_copy = False
    return is_copy


def mold_factor(j, d):
    """
    Resize an image by multiplying its size by a factor.

    j: Image
        Has cell info.
        Has material.
        work-in-progress

    d: dict
        of image place, form

    Return: flag
        Is true if there is material in the buffer.
        buffer data
            of the image
    """
    is_copy = True

    Mage.copy_all(j.j)

    j1 = pdb.gimp_edit_paste_as_new_image()
    e = d[ok.RESIZE_METHOD]

    pdb.gimp_layer_scale(
        j1.layers[0],
        int(j1.width * round(e[ok.FACTOR_IMAGE_SIZE_W], 6)),
        int(j1.height * round(e[ok.FACTOR_IMAGE_SIZE_H], 6)),
        Fu.LayerScale.IMAGE_ORIGIN
    )
    pdb.gimp_image_resize_to_layers(j1)

    if j1:
        if j1.width > j.pocket.w or j1.height > j.pocket.h:
            # Copy a rectangle:
            j.mold.size = select_image_trim(d, j, j1)

        else:
            j.mold.size = j1.width, j1.height
            pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

    else:
        is_copy = False
    return is_copy


def mold_image(j, d, grid, one):
    """
    Mold an image to fit a cell.

    j: Image
        to fit into cell

    d: dict
        of image place, form

    grid: Grid
        Has cell table.

    Return: bool
        Is true if there is material in the buffer.
    """
    pdb.gimp_selection_none(Hat.cat.render.image)

    if j.r != fy.CUSTOM_CELL:
        r, c = j.r, j.c
        j.pocket = grid.get_pocket(r, c)
        j.cell = grid.get_merge_cell_rect(r, c)
        j.mold.size = j.mold.position = 0, 0
        j.shape = grid.get_shape(r, c)
        j.plaque = grid.get_plaque(r, c)

    s = j.pocket.size = shift_size(d, j.pocket.size)
    n = d[ok.RESIZE_METHOD][ok.RESIZE_TYPE]
    is_copy = MOLD[n](j, d)
    f = .0
    e = d[ok.SHIFT]
    w = e[ok.ANGLE_JITTER]

    if w:
        f = uniform(-w, w)

    Hat.cat.save_jitter((one.model_name, j.r, j.c), f)

    if (j.rotate or f) and is_copy:
        j1 = pdb.gimp_edit_paste_as_new_image()
        z = Lay.rotate(j1, f + j.rotate)
        t = w, h = z.width, z.height

        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

        if not f and (w > s[0] or h > s[1]):
            t = w, h = Shape.calc_lock(s, t)
            j2 = pdb.gimp_edit_paste_as_new_image()
            Mage.shape(j2, w, h)
        j.mold.size = t

    if is_copy:
        calc_mold_position(grid, d, j)
    return is_copy


def mold_lock(j, _):
    """
    Resize using a locked resize-type.

    j: Image
        Has cell info.

    _: dict
        of image place, form
        ignore

    Return: buffer data
        of the image
    """
    Mage.copy_all(j.j)

    if j.width > j.pocket.w or j.height > j.pocket.h:
        # down-size:
        w, h = Shape.calc_lock(j.pocket.size, j.size)
        j1 = pdb.gimp_edit_paste_as_new_image()
        Mage.shape(j1, w, h)

    else:
        w, h = j.size

    j.mold.size = w, h
    return True


def mold_trim(j, d):
    """
    Resize an image using the trim resize-type.

    Finish with the image data in the buffer.

    j: Image
        Has cell info.

    d: dict
        of image place, form

    Return: buffer data
        of the image
    """
    s = s1 = j.size
    t = j.pocket.size

    Mage.copy_all(j.j)

    if s[0] > t[0] or s[1] > t[1]:
        w, h = get_trim_size(s, t)
        j1 = pdb.gimp_edit_paste_as_new_image()

        Mage.shape(j1, w, h)

        j1 = pdb.gimp_edit_paste_as_new_image()
        s1 = select_image_trim(d, j, j1)

        # Copy visible selection:
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

    j.mold.size = s1
    return True


def place_image(j, d, grid, group, one):
    """
    Copy and paste images into a image layer group.

    grid: Grid
        Has cell table.

    j: Image
        with GIMP image reference
        Has a row and column position.
        Has a rotate attribute.

    d: dict
        of image place, form

    grid: Grid
        Has cell table.

    group: layer
        group for image layer group

    one: One
        Has model name.

    return: the selected layer or None
        with image
        Is None and no selection when there is no image.
    """
    cat = Hat.cat
    pdb.gimp_selection_none(cat.render.image)

    # The Image's image will enter the copy and paste buffer:
    if mold_image(j, d, grid, one):
        z = Lay.paste(group.layers[0])
        z.opacity = d[ok.OPACITY]

        if d[ok.FLIP_HORIZONTAL]:
            Lay.flip(z, horizontal=1)

        if d[ok.FLIP_VERTICAL]:
            z = Lay.flip(z)

        # The 'mold' attribute is from 'mold_image':
        pdb.gimp_layer_set_offsets(z, j.mold.x, j.mold.y)

        if j.cell_shape not in (sh.RECTANGLE, sh.SQUARE):
            apply_shape_mask(j, z)
        return z


def select_image_trim(d, j, j1):
    """
    Use to get the cell-size scaled image pixels
    for a trimmed or non-resized image.

    Create a selection rectangle for image data transfer.

    Copy the selection.

    d: dict
        of image place, form

    j: Image
        Has cell info.

    j1: GIMP image
        with trim

    Return: tuple
        the selection size
    """
    # Need to select from one layer only:
    m = False

    if len(j1.layers) > 1:
        Mage.copy_all(j1)

        m = True
        j1 = pdb.gimp_edit_paste_as_new_image()

    n = d[ok.JUSTIFICATION]
    s = j.pocket.size
    t = j1.width, j1.height

    if n in ju.LEFT:
        x = 0
        x1 = s[0]

    elif n in ju.RIGHT:
        x = max(t[0] - s[0], 0)
        x1 = t[0]

    else:
        # horizontal center:
        x = max(t[0] // 2 - s[0] // 2, 0)
        x1 = min(t[0] // 2 + s[0] // 2 + s[0] % 2, t[0])

    if n in ju.TOP:
        y = 0
        y1 = s[1]

    elif n in ju.BOTTOM:
        y = max(t[1] - s[1], 0)
        y1 = t[1]

    else:
        # vertical center:
        y = max(t[1] // 2 - s[1] // 2, 0)
        y1 = min(t[1] // 2 + s[1] // 2 + s[1] % 2, t[1])

    # Correct for underflow:
    if x == x1:
        x1 += 1

    if y == y1:
        y1 += 1

    w = max(x1 - x, 1)
    h = max(y1 - y, 1)

    Sel.rect(j1, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
    pdb.gimp_edit_copy(j1.layers[0])

    _, x, y, x1, y1 = pdb.gimp_selection_bounds(j1)

    if m:
        pdb.gimp_image_delete(j1)
    return x1 - x, y1 - y


def shift_position(d, x, y):
    """
    Modifies an image's position per the shift settings.

    d: dict
        image place, form

    x, y: int
        The topleft corner of image position after molding

    Return: tuple
        x, y
        of int
        shifted topleft corner
    """
    e = d[ok.SHIFT]
    x += e[ok.OFFSET_X]
    y += e[ok.OFFSET_Y]
    w = e[ok.SHIFT_X]

    if w:
        x += randint(-w, w)

    w = e[ok.SHIFT_Y]

    if w:
        y += randint(-w, w)
    return x, y


def shift_size(d, s):
    """
    Modify the size of a mold per the shift settings.

    d: dict
        image place, form

    s: tuple
        width, height
        of int
        size of image mold

    return tuple
        width, height
        modified mold size
    """
    w, h = s
    e = d[ok.SHIFT]
    w += e[ok.WIDTH_MOD]
    h += e[ok.HEIGHT_MOD]
    w1 = e[ok.SHIFT_WIDTH]

    if w1:
        w += randint(-w1, w1)

    w1 = e[ok.SHIFT_HEIGHT]

    if w1:
        h += randint(-w1, w1)
    return max(1, w), max(1, h)


class Place:
    """Organize functions related to image placement."""

    # Use with the Image class:
    IMAGE_INDEX = {
        # '-2' is a condition that will cause an init function to perform:
        ik.LOOP_DICT: {ik.LOOP: -2, ik.SLICE: {}},
        ik.NEXT_DICT: {ik.NEXT: 0, ik.SLICE: {}},
        ik.PREVIOUS_DICT: {ik.PREVIOUS: -2, ik.SLICE: {}},
        ik.SLICE: {}
    }

    @staticmethod
    def do_custom_cell(one, is_plan):
        """
        Place a custom cell image onto the render.

        one: One
            Has place variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with image
        """
        cat = Hat.cat
        j = cat.render.image
        z = group = None
        d = one.d
        r = fy.CUSTOM_CELL
        parent = one.parent
        name = one.model_name
        one.cell.image_name = None
        j1 = one.cell.image = Image.get_image(d[ok.IMAGE], one.image_index)

        if j1:
            cat.seed(d[ok.SHIFT])

            group = Lay.group(
                j, Lay.name(parent, nk.IMAGE),
                parent=parent
            )
            Lay.add(j, "Image", parent=group)
            shape = one.cell.shape
            a = one.cell.rect
            j1.pocket = one.cell.pocket
            j1.r, j1.c = r, r
            j1.rotate = d[ok.ROTATE]
            j1.cell_shape = shape
            j1.shape = dispatch[shape](j1.pocket)
            j1.plaque = dispatch[shape](a)
            z = place_image(j1, d, one.grid, group, one)

            if z:
                z = RenderHub.do_mode(z, d)
                cat.save_z_height((one.model_name, r, r), "0")

                one.cell.mold = j1.mold
                one.cell.image_name = j1.layer_name if j1.layer_name \
                    else j1.image_name
                cat.save_image_sel(z, name, r, r)
            Image.close_image(j1)

        if group:
            z = Lay.merge_group(group)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.IMAGE_INFLUENCE)
        return z

    @staticmethod
    def do_grid(one, is_plan):
        """
        Place grid images onto the render.

        one: One
            Has place variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with image
        """
        def do_gradient():
            if not is_plan:
                return GradientLight.apply_light(z, ok.IMAGE_INFLUENCE)
            return z

        cat = Hat.cat
        j = cat.render.image
        z = group = None
        d = one.d
        e = one.grid.grid_d
        row, column = one.grid.division
        parent = one.parent
        is_merge_cell = one.grid.is_merge_cell
        name = one.model_name
        shape = one.grid.cell_shape
        is_per_cell = d[ok.PER_CELL]
        loft = []

        if not is_per_cell:
            cat.seed(d[ok.SHIFT])

        # Place images:
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(one.grid, r, c):
                    j1 = Image.get_image_for_cell(
                        d,
                        e,
                        one.image_index,
                        r, c,
                        is_merge_cell
                    )
                    if j1:
                        n = j1.layer_name if j1.layer_name else j1.image_name

                        one.grid.set_image_name(r, c, n)
                        one.grid.set_image(r, c, j1)

                        if not group:
                            group = Lay.group(
                                j, Lay.name(parent, nk.IMAGE),
                                parent=parent
                            )

                        j1.r, j1.c = r, c
                        j1.rotate = Form.get_image_rotate(d, r, c)
                        j1.cell_shape = shape
                        d1 = Form.get_form(d, r, c)
                        d2 = d1[ok.SHIFT]
                        z_height = d2[ok.OFFSET_Z]
                        w = d2[ok.SHIFT_Z]

                        if w:
                            z_height += randint(0, w)

                        n1 = str(z_height)
                        n2 = Lay.name(group, n1)

                        if z_height in loft:
                            x = loft.index(z_height)
                            group1 = group.layers[x]

                        else:
                            loft += [z_height]
                            loft = list(reversed(sorted(loft)))
                            x = loft.index(z_height) + 1
                            z = Lay.add(j, n1, parent=group)
                            group1 = Lay.group(
                                j,
                                n2,
                                parent=group,
                                offset=x,
                                layer=z
                            )

                        if is_per_cell:
                            cat.seed(d2)

                        z = place_image(
                            j1,
                            d1,
                            one.grid,
                            group1,
                            one
                        )

                        if z:
                            z = RenderHub.do_mode(z, d1)

                            Sel.item(z)
                            cat.save_image_sel(z, name, r, c)
                            cat.save_z_height((one.model_name, r, c), n1)
                        Image.close_image(j1)

        if group:
            if len(group.layers) == 1:
                z = Lay.merge_group(group)
                z = do_gradient()

            else:
                q = group.layers

                for x, z in enumerate(q):
                    z = Lay.merge_group(z)
                    z = do_gradient()

                    z1 = Lay.group(
                        j,
                        Lay.name(z.parent, "Group " + z.name.split(" ")[-1]),
                        parent=group,
                        offset=x,
                        layer=z
                    )
                    cat.save_image_layer(z, z1.name)
                z = group
        return z


MOLD = {
    ok.COVER: mold_cover,
    fz.CROP: mold_crop,
    ok.FILLED: mold_fill,
    fz.FIXED: mold_fixed,
    fz.FACTOR: mold_factor,
    ok.LOCKED: mold_lock,
    ok.TRIM: mold_trim
}
