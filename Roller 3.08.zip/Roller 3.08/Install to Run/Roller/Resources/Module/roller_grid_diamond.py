#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_one import Rect
from roller_one_extract import Shape


class GridDiamond:
    """
    Calculate the coordinates and the size of cells.

    The cells are diamond shaped.
    """

    def __init__(self, one):
        """
        Calculate cell size and diamond shape.

        one: One
            Has init values.
        """
        grid = self.grid = one.grid
        row, column = self.row, self.column = one.r, one.c
        table = grid.table
        s = one.layer_space
        x, y = one.offset
        self.is_not_shift = grid.double_type == sh.NOT_SHIFT

        # intersect points:
        q_x = self.q_x = []
        q_y = self.q_y = []

        if one.grid_type == gr.CELL_SIZE:
            # cell size:
            w, h = one.column_width / 1., one.row_height / 1.

            # table size:
            w1, h1 = w / 2., h / 2.
            s1 = w + (column - 1) * w1, h + (row - 1) * h1
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        elif one.grid_type == gr.SHAPE_COUNT:
            # cell size:
            w = s[0] / (.5 + column * .5)
            h = s[1] / (.5 + row * .5)
            w = min(w, h) / 1.
            w, h = w, w

            # table size:
            h1 = h / 2.
            s1 = column * h1 + h1, row * h1 + h1
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            w = s[0] / (.5 + column * .5)
            h = s[1] / (.5 + row * .5)

        offset = x, y

        # intersects:
        w1 = w / 2
        h1 = h / 2
        for c in range(column + 2):
            q_x.append(int(round(x)))
            x += w1

        for r in range(row + 2):
            q_y.append(int(round(y)))
            y += h1

        # Compose points:
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(self.grid, r, c):
                    y, y1, y2 = q_y[r], q_y[r + 1], q_y[r + 2]
                    x, x1, x2 = q_x[c], q_x[c + 1], q_x[c + 2]
                    position = x, y
                    size = x2 - x, y2 - y

                    if (
                        x + size[0] > s[0] + offset[0] or
                        y + size[1] > s[1] + offset[1]
                    ):
                        position = size = 0, 0

                    # 'cell' is the cell rectangle before margins:
                    a = table[r][c]
                    a.cell = Rect(position, size)
                    if size[0]:
                        a.shape = a.plaque = x, y1, x1, y, x2, y1, x1, y2
