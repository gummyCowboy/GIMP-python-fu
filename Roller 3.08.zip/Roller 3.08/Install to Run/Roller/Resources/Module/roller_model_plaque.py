#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import (
    Gradient as fg,
    Model as mo,
    Plan as fy,
    Plaque as aq,
    Triangle as ft
)
from roller_constant_key import Layer as nk, Option as ok
from roller_constant_fu import Fu
from roller_effect_feather_steps import FeatherSteps
from roller_model_image import Image
from roller_model_image_mask import MASK_FUNCTION
from roller_one import Base, Comm, Hat, One
from roller_one_extract import dispatch, Form, Path, Shape
from roller_one_fu import Lay, Mage, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
OPACITY_100 = 255
PER_CELL_TYPE = aq.AVERAGE_COLOR, aq.GRADIENT, aq.IMAGE, aq.SHADOW


def blur_behind(z, d, _type):
    """
    Blur behind plaque material.

    z: layer
        with material

    d: dict
        Has the blur behind option.

    one: One
        Has variables.

    _type: string
        type of plaque

    Return: layer
        with material
    """
    z1 = z
    z = RenderHub.blur_behind(z, d, has_mode=True)

    if not z:
        z = z1
    return z


def cast_shadow(z, d):
    """
    Merge a shadow layer with the plaque if needed.

    z: layer
        with material

    d: dict
        of options

    Return: layer
        with plaque material
    """
    if Shadow.get_type(d[ok.TRI_SHADOW]):
        n = z.name
        z = Shadow.do_shadows(d[ok.TRI_SHADOW], z)
        z.name = n
    return z


def complete(j, z, d, one):
    """
    Perform the steps that complete a plaque type.

    j: GIMP image
        Is render.

    z: layer
        Has plaque.

    d: dict
        of plaque, form

    one: One
        Has variables.

    Return: layer
        with plaque
    """
    _type = d[ok.PLAQUE_TYPE]
    is_netting = _type == aq.NETTING

    do_mask(j, z, d, one)

    if d[ok.FEATHER]:
        if is_netting:
            Sel.select_shape(j, one.plaque, option=fu.CHANNEL_OP_INTERSECT)
            FeatherSteps.feather_sel(j, d)
            Sel.invert_clear(z, keep_sel=True)
            Sel.invert_clear(z)
        else:
            feather(z, d)

    z = RenderHub.bump(z, d[ok.BUMP])
    z = RenderHub.do_mode(z, d)

    if has_blur_behind(d):
        z = blur_behind(z, d, _type)

    if z and _type != aq.SHADOW:
        z = cast_shadow(z, d)
    return z


def do_average_color(j, z, one):
    """
    Make an average color plaque. Is not a candidate for is-one-selection.

    Exit with a selection to save.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress
        A new layer is inserted above 'z'.

    one: One
        Has cell data.

    opacity: float
        for plaque layer

    Return: state of image, layer
        selection, with material
    """
    j1 = None

    # Make a new image, 'j1', with the material to average:
    if not one.is_layer:
        # Disconnect the dict so it doesn't change:
        one.image_index = deepcopy(one.image_index)

        grid_d = one.grid.grid_d if one.grid else None

        # Use the image assigned to a cell to get the average color:
        j1 = Image.get_image_for_cell(
            Path.get_cell_place_chunk(one.path),
            grid_d,
            one.image_index,
            one.r, one.c,
            one.is_merge_cell
        )

        if j1 and j1.j:
            Mage.copy_all(j1.j)
            Image.close_image(j1)
        else:
            # There was no image found for the cell, so
            # the cell's background will be used:
            j1 = None

    if j1:
        j1 = pdb.gimp_edit_paste_as_new_image()

    else:
        # There's no image, so use the cell's background
        # as the source of the average color.
        # Copy the selection:
        Sel.rect(
            j,
            one.x, one.y,
            one.w, one.h,
            option=fu.CHANNEL_OP_REPLACE
        )
        pdb.gimp_edit_copy_visible(j)
        j1 = pdb.gimp_edit_paste_as_new_image()

    z = Lay.add_above(z)

    Lay.color_fill(z, RenderHub.get_average_color(j1.layers[0]))
    pdb.gimp_image_delete(j1)
    Sel.item(z)
    Sel.select_shape(j, one.plaque)
    Sel.invert_clear(z, keep_sel=True)
    return z


def do_backdrop(j, z, one):
    """
    Make cell fringe from the backdrop layers.
    If called from a is-one-selection state,
    then the selection is already set.

    j: GIMP image
        Is render.

    z: layer
        Has fringe material.

    one: One
        Has cell data.

    Return: layer
        Has image.
    """
    d = one.d
    z = Lay.clone_background(z)

    if d[ok.BLUR]:
        Lay.blur(z, d[ok.BLUR])

    if not one.is_one_sel:
        Sel.select_shape(j, one.plaque)

    Sel.invert_clear(z, keep_sel=True)
    return z


def do_cell(one):
    """
    The cell has a plaque.

    one: One
        Has cell data.
    """
    cat = Hat.cat
    j = cat.render.image
    d = one.d
    _type = d[ok.PLAQUE_TYPE]

    if _type in plaque_process:
        if not one.group:
            one.group = Lay.group(
                j,
                Lay.name(one.parent, nk.CELL_PLAQUE),
                one.parent
            )
            z = Lay.add(j, "Plaque", parent=one.group)

        else:
            z = one.group.layers[0]

        if one.is_one_sel:
            Sel.select_shape(j, one.plaque)
            cat.save_plaque_sel(one.model_name, one.r, one.c)

        else:
            if one.is_plan:
                z = do_color(j, z, one)
            else:
                z = plaque_process[_type](j, z, one)
                if z:
                    z.opacity = d[ok.OPACITY]

        if not one.is_one_sel and not one.is_plan:
            z = complete(j, z, d, one)

            Sel.item(z)
            cat.save_plaque_sel(one.model_name, one.r, one.c)


def do_color(j, z, one):
    """
    Make a image plaque. If called from a is-one-selection
    state, then the selection is already set.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has options.

    Return: state of image, layer
        selection, with material
    """
    if not one.is_one_sel:
        Sel.select_shape(j, one.plaque)

    z = Lay.add_above(z)

    Sel.fill(z, get_color(one))
    return z


def do_gradient(j, z, one):
    """
    Make a gradient plaque. Is not a candidate for is-one-selection.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    def draw_gradient():
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(gradient_type),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            start_x, start_y,
            end_x, end_y
        )

    d = one.d
    gradient = d[ok.GRADIENT]

    if gradient not in Hat.cat.gradient_list:
        Comm.info_msg(
            mo.MISSING_ITEM.format("Plaque", "gradient", gradient)
        )
    else:
        z = Lay.add_above(z)
        x, y, w, h = one.x, one.y, one.w, one.h
        gradient_type = d[ok.GRADIENT_TYPE]

        RenderHub.set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_gradient(gradient)
        pdb.gimp_context_set_gradient_blend_color_space(
            fu.GRADIENT_BLEND_RGB_PERCEPTUAL
        )
        pdb.gimp_context_set_gradient_reverse(0)

        start_x, end_x, start_y, end_y =\
            RenderHub.get_gradient_points(
                d[ok.GRADIENT_ANGLE],
                x, y,
                w, h
            )

        Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
        draw_gradient()
        Sel.select_shape(j, one.plaque)
        Sel.invert_clear(z, keep_sel=True)
        return z


def do_image(j, z, one):
    """
    Make a image plaque. Is not a candidate for is-one-selection.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell image.

    opacity: float
        for plaque layer

    Return: state of image, layer or None
        selection, with material
    """
    d = one.d
    j1 = Image.get_image(d[ok.IMAGE], one.image_index)

    if j1:
        j2 = j1.j

        pdb.gimp_selection_none(j)
        Mage.copy_all(j2)
        Image.close_image(j1)

        j2 = pdb.gimp_edit_paste_as_new_image()

        Mage.shape(j2, one.w, one.h)

        z = Lay.paste(z)

        pdb.gimp_layer_set_offsets(z, one.x, one.y)
        Sel.item(z)

        if d[ok.BLUR]:
            Lay.blur(z, d[ok.BLUR])

        Sel.select_shape(j, one.plaque)
        Sel.invert_clear(z, keep_sel=True)
        return z
    else:
        # There is no plaque:
        pdb.gimp_selection_none(j)


def do_mask(j, z, d, one):
    """
    Apply a mask to a plaque. Is not a candidate for is-one-selection.

    j: GIMP image
        Is render.
    """
    e = d[ok.PLAQUE_MASK]
    _type = e[ok.MASK_TYPE]

    if _type in MASK_FUNCTION:
        Sel.item(z)

        is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

        if is_sel:
            w, h = x1 - x, y1 - y
            one = One(
                center_x=(x + x1) // 2, center_y=(y + y1) // 2,
                d=e,
                e=e,
                image_w=w, image_h=h,
                image_index=one.image_index,
                one=one,
                w=w * e[ok.HORZ_SCALE], h=h * e[ok.VERT_SCALE],
                x=x, y=y
            )
            MASK_FUNCTION[_type](j, one)
        if Sel.is_sel(j):
            Sel.invert_clear(z, keep_sel=True)
    else:
        pdb.gimp_selection_all(j)


def do_netting(j, z, one):
    """
    Make a netting plaque. If called from a is-one-selection
    state, then the selection is already set.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    d = one.d
    w = d[ok.NET_LINE_SPACING]
    color = d[ok.COLOR]
    w1 = d[ok.NET_LINE_WIDTH]
    z = Lay.add_above(z)

    if not one.is_one_sel:
        Sel.select_shape(j, one.plaque)

    pdb.plug_in_grid(
        j, z,
        w1,
        w,
        w,
        color,
        OPACITY_100,
        w1,
        w,
        w,
        color,
        OPACITY_100,
        0,
        0,
        0,
        (0, 0, 0),
        0
    )
    return z


def do_pattern(j, z, one):
    """
    Make a pattern plaque. If called from a is-one-selection
    state, then the selection is already set.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    d = one.d
    pattern = d[ok.PATTERN]

    if pattern in Hat.cat.pattern_list:
        if not one.is_one_sel:
            Sel.select_shape(j, one.plaque)

        RenderHub.set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_pattern(pattern)

        # Try and fill the selection by keeping the
        # fill point within the visible canvas:
        x = Base.seal(one.x, 0, j.width - 1)
        y = Base.seal(one.y, 0, j.height - 1)

        z = Lay.add_above(z)

        pdb.gimp_drawable_edit_bucket_fill(
            z,
            fu.FILL_PATTERN,
            Base.seal(x, 0, j.width),
            Base.seal(y, 0, j.height)
        )
        if d[ok.BLUR]:
            Lay.blur(z, d[ok.BLUR])

    else:
        Comm.info_msg(mo.MISSING_ITEM.format("Plaque", "pattern", pattern))
    return z


def do_plasma(j, z, one):
    """
    Make a plasma plaque. If called from a is-one-selection
    state, then the selection is already set.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    d = one.d
    z = Lay.add_above(z)

    if one.is_one_sel:
        # Is a work-around for a plasma bug not filling a selection correctly:
        sel = Hat.cat.save_short_term_sel()

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, d[ok.RANDOM_SEED], 3)

    if d[ok.BLUR]:
        Lay.blur(z, d[ok.BLUR])

    if one.is_one_sel:
        Sel.load(j, sel)

    else:
        Sel.select_shape(j, one.plaque)

    Sel.invert_clear(z)
    return z


def do_shadow(j, z, one):
    """
    Make a shadow plaque. Is not a candidate for is-one-selection.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    d = one.d
    z = Lay.add_above(z)

    Sel.select_shape(j, one.plaque)
    Sel.fill(z, (0, 0, 0))

    z1 = Shadow.do(
        One(
            cast=(z,),
            d=d,
            is_inner=True,
            model_name=one.model_name,
            parent=one.group
        )
    )

    pdb.gimp_image_remove_layer(j, z)
    return z1


def feather(z, d):
    """
    Feather the plaque selection.

    z: layer
        Has material.

    d: dict
        Has feather option.
    """
    if d[ok.FEATHER]:
        FeatherSteps.feather(z, d)
        Sel.item(z)


def get_color(one):
    """
    Get the color for the border material.

    d: dict
        of border

    Return: tuple
        RGB
    """
    if one.is_plan:
        return one.color
    return one.d[ok.COLOR]


def has_blur_behind(d):
    """
    Determine if blur behind is in effect.

    d: dict
        of plaque, form

    Return: bool
        Is true when the blur behind is to be done.
    """
    return d[ok.BLUR_BEHIND] and d[ok.OPACITY]


class Plaque:
    """
    Manage Plaque operation.

    Require a backdrop image for Plaque's average color function.
    """
    @staticmethod
    def do_custom_cell(one, is_plan):
        """
        Do the plaque for a custom cell.

        one: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with plaque
        """
        d = one.d
        r = fy.CUSTOM_CELL
        z = one.group = None
        opacity = d[ok.OPACITY]
        _type = d[ok.PLAQUE_TYPE]

        if opacity and _type != "None":
            if d[ok.OBEY_MARGINS]:
                a = one.cell.pocket
            else:
                a = one.cell.rect

            one.is_one_sel = one.is_layer = False
            one.r = one.c = r
            one.is_merge_cell = one.is_per_cell = False
            one.plaque = dispatch[one.cell.shape](a)
            one.is_plan = is_plan
            one.x, one.y = a.position
            one.w, one.h = a.size
            do_cell(one)

        if one.group:
            z = Lay.merge_group(one.group)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.PLAQUE_INFLUENCE)
        return z

    @staticmethod
    def do_grid(one, is_plan):
        """
        Do the plaque for the grid cells.

        one: One
            Has init values.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with plaque material
        """
        cat = Hat.cat
        j = cat.render.image
        z = one.group = None
        row, column = one.grid.division
        is_merge_cell = one.is_merge_cell = one.grid.is_merge_cell
        d = one.d
        grid_d = one.grid.grid_d
        is_per_cell = one.is_per_cell = d[ok.PER_CELL]
        margin = Path.get_cell_margin(one.path)

        # Render as a single selection, 'is_one_sel' flag:
        one.is_one_sel = one.is_layer = False

        one.is_plan = is_plan
        go = True
        f, n = d[ok.OPACITY], d[ok.PLAQUE_TYPE]

        # Update the plaque size with the
        # obey margins option and cell margins.
        for r in range(row):
            for c in range(column):
                e = Form.get_form(d, r, c) if is_per_cell else d
                if e[ok.OBEY_MARGINS]:
                    # Update plaque size:
                    rect = one.grid.get_pocket(r, c)
                    if Path.has_margin(Form.get_form(margin, r, c)):
                        n = one.grid.cell_shape

                        if n in ft.TRIANGLE:
                            if Shape.is_inverse_triangle(r, c):
                                n = ft.INVERTED[n]
                        one.grid.set_plaque(r, c, dispatch[n](rect))

        if not is_per_cell:
            go = f and n != "None"

        if go:
            if (
                not is_per_cell and
                n not in PER_CELL_TYPE and
                not Shadow.get_type(d[ok.TRI_SHADOW]) and
                d[ok.PLAQUE_MASK][ok.MASK_TYPE] == "None"
            ):
                one.is_one_sel = True

            # Process a plaque for each cell in the grid:
            for r in range(row):
                for c in range(column):
                    one.r, one.c = r, c
                    e = one.d = Form.get_form(d, r, c) if is_per_cell else d
                    m = e[ok.OPACITY] and e[ok.PLAQUE_TYPE] != "None"

                    if m:
                        m = Shape.is_allocated_cell(one.grid, r, c)

                    if m:
                        if e[ok.OBEY_MARGINS]:
                            rect = one.grid.get_pocket(r, c)

                        else:
                            rect = one.grid.get_merge_cell_rect(r, c)

                    if m:
                        if is_merge_cell:
                            if grid_d[ok.PER_CELL][r][c] == (-1, -1):
                                m = False
                    if m:
                        one.x, one.y = rect.position
                        one.w, one.h = rect.size
                        one.plaque = one.grid.get_plaque(r, c)
                        do_cell(one)

        if one.group and one.is_one_sel:
            pdb.gimp_selection_none(j)

            q = [
                cat.get_plaque_sel(one.model_name, r, c)
                for r in range(row) for c in range(column)
            ]

            [Sel.load(j, i, option=fu.CHANNEL_OP_ADD) for i in q if i]
            if Sel.is_sel(j) and one.group:
                z = one.group.layers[0]

                if is_plan:
                    z = do_color(j, z, one)
                else:
                    z = plaque_process[n](j, z, one)
                    if not is_plan:
                        z = complete(j, z, d, one)
                        if z:
                            z.opacity = d[ok.OPACITY]

        if one.group:
            z = Lay.merge_group(one.group)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.PLAQUE_INFLUENCE)
        return z

    @staticmethod
    def do_layer(one, is_plan):
        """
        Add a plaque layer. Is one per model.

        one: One
            Has init variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: list
            with plaque layer
        """
        d = one.d
        z = None
        opacity = d[ok.OPACITY]
        _type = d[ok.PLAQUE_TYPE]
        go = opacity and _type != "None"

        if go:
            cat = Hat.cat
            parent = one.parent
            j = cat.render.image
            one.is_layer = True
            one.is_plan = is_plan
            one.is_one_sel = False
            size = cat.render.size

            if d[ok.OBEY_MARGINS]:
                one.y, bottom, one.x, right = one.layer_margin
                one.w = size[0] - one.x - right
                one.h = size[1] - one.y - bottom

            else:
                one.x = one.y = 0
                one.w, one.h = size

            w, h = one.x + one.w, one.y + one.h
            one.plaque = one.x, one.y, w, one.y, w, h, one.x, h
            one.group = Lay.group(
                j,
                Lay.name(parent, nk.LAYER_PLAQUE),
                parent,
                len(parent.layers)
            )
            if _type in plaque_process:
                z = Lay.add(j, "Layer Plaque", parent=one.group)
                z = plaque_process[_type](j, z, one)

                if z:
                    z.opacity = d[ok.OPACITY]

                z = Lay.merge_group(one.group)

                if not is_plan:
                    z = complete(j, z, d, one)

                Sel.item(z)
                cat.save_plaque_sel(one.model_name, fy.LAYER, fy.LAYER)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.PLAQUE_INFLUENCE)
        return z


plaque_process = {
    aq.AVERAGE_COLOR: do_average_color,
    aq.BACKDROP: do_backdrop,
    aq.COLOR: do_color,
    aq.IMAGE: do_image,
    aq.GRADIENT: do_gradient,
    aq.NETTING: do_netting,
    aq.PATTERN: do_pattern,
    aq.PLASMA: do_plasma,
    aq.SHADOW: do_shadow
}
