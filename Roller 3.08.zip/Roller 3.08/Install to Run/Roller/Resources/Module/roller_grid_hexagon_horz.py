#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_one import Rect
from roller_one_extract import Shape

HORIZONTAL = sh.HORIZONTAL_ALIGNED
RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP

# Is a dummy image size for calculating a pocket rectangle with 'calc_lock':
HEXAGON_MAX = 10000000, 11547005


class HexagonHorz:
    """
    Calculate the position and the size of cells
    for a horizontally aligned hexagon grid.

    Use a double-spaced grid-type.
    """

    def __init__(self, one):
        """
        Calculate a hexagon cell-size rectangle and hexagon shape.

        When possible, calculate cell shape with intersects.
        Intersects are points on the grid that two or more hexagons share.
        These points may define a cell, a pocket, or the shape.

        one: One
            Has init values.
        """
        grid = self.grid = one.grid
        self.grid_type = one.grid_type
        row, column = self.row, self.column = one.r, one.c
        table = grid.table
        self.is_not_shift = grid.double_type == sh.NOT_SHIFT
        s = one.layer_space

        # intersect points:
        q_x = self.q_x = []
        q_y = self.q_y = []

        x, y = one.offset
        ellipse_space = 0 if grid.cell_shape in sh.HEXAGON \
            else sh.ELLIPSE_RATIO

        if one.grid_type == gr.CELL_SIZE:
            # cell size:
            w, h = one.column_width / 1., one.row_height / 1.

            # table size:
            w1 = w / 2
            h1 = h * .75
            h2 = h - h1
            s1 = column * w1 + w1, row * h1 + h2

            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        elif one.grid_type == gr.SHAPE_COUNT:
            # Calculate 's1', 'w', 'h':
            # cell size:
            w, h = s[0] / (.5 + column * .5), s[1] / (.25 + row * .75)

            # two possible solutions:
            # solution one:
            _w, _h = h * RATIO, h
            w1 = _w / 2
            h1 = _h * .75
            h2 = _h - h1
            s1 = column * w1 + w1, row * h1 + h2

            # solution two:
            _w1, _h1 = w, w * UP_RATIO
            w1 = _w1 / 2
            h1 = _h1 * .75
            h2 = _h1 - h1
            s2 = column * w1 + w1, row * h1 + h2

            # 'round' will infrequently cause an overflow:
            s1 = int(s1[0]), int(s1[1])
            s2 = int(s2[0]), int(s2[1])

            if s1[0] > s[0] or s1[1] > s[1]:
                s1 = s2
                w, h = _w1, _h1

            else:
                w, h = _w, _h
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            # cell count:
            # Calculate cell size for aligned horizontally:
            w = s[0] / (.5 + column * .5)
            h = s[1] / (.25 + row * .75 - ellipse_space)

        w = w / 2
        h1 = h * .25
        h2 = h * .75

        # cell rectangle:
        for _ in range(column + 4):
            q_x += [round(x)]
            x += w

        for _ in range(row + 4):
            q_y += [round(y)]
            q_y += [round(y + h1)]
            y += h2

        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(grid, r, c):
                    r1 = r * 2
                    x, x1 = q_x[c], q_x[c + 2]
                    y, y1 = q_y[r1], q_y[r1 + 3]
                    size = int(x1 - x), int(y1 - y)

                    # 'cell' is the cell rectangle before margins:
                    a = table[r][c]
                    a.cell = Rect((int(x), int(y)), size)
                    if size[0]:
                        a.shape = a.plaque = self._do_shape(r, c)

    def _do_shape(self, r, c, is_pocket=False):
        """
        Assemble a hexagon shape.

        r, c: int
            cell index

        is_pocket: flag
            If it's true, the row and column indices are adjusted
            to get values from pocket-oriented intersects.

        Return: tuple
            shape
        """
        q_x, q_y = self.q_x, self.q_y

        if is_pocket:
            c *= 3
            r *= 4

        else:
            r *= 2

        x = q_x[c]
        x1 = q_x[c + 1]
        x2 = q_x[c + 2]
        y = q_y[r + 1]
        y1 = q_y[r + 2]
        return x, y, x1, q_y[r], x2, y, x2, y1, x1, q_y[r + 3], x, y1
