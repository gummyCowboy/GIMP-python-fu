#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Triangle as ft, Shape as sh
from roller_one import Rect
from roller_one_extract import Shape

RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP
TRIANGLE_MAX = 10000000, 11547005


class TriangleHorz:
    """
    Calculate the position and the size of cells for a triangle grid.

    Use intersects to map points shared by multiple triangles.
    Intersects create seamless triangle joints.
    """

    def __init__(self, one):
        """
        Calculate cell points and cell shapes.

        one: One
            Has init values.
            r, c: row, column span
        """
        row, column = self.row, self.column = one.r, one.c
        grid = self.grid = one.grid
        self.grid_type = one.grid_type
        table = grid.table
        s = one.layer_space
        self.is_right = grid.cell_shape == ft.TRIANGLE_RIGHT

        # intersect points:
        q_x = self.q_x = []
        q_y = self.q_y = []

        x, y = one.offset

        if one.grid_type in (gr.CELL_SIZE, gr.SHAPE_COUNT):
            # cell size:
            if one.grid_type == gr.CELL_SIZE:
                w, h = one.column_width / 1., one.row_height / 1.

                # table size:
                h1 = h / 2.
                h2 = h - h1
                s1 = column * w, row * h1 + h2

            else:
                # horizontal triangles:
                w1 = s[0] / 1. / column
                h1 = s[1] / (.5 + row * .5)

                # two possible solutions
                # solution one:
                _w, _h = h1 * RATIO, h1
                h2 = _h / 2.
                h3 = _h - h2
                s1 = column * _w, row * h2 + h3

                # solution two:
                _w1, _h1 = w1, w1 * UP_RATIO
                h2 = _h1 / 2.
                h3 = _h1 - h2
                s2 = column * _w1, row * h2 + h3

                # If solution one fails, use solution two:
                if s1[0] > s[0] or s1[1] > s[1]:
                    s1 = s2
                    w, h = _w1, _h1
                else:
                    w, h = _w, _h
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            w = s[0] / 1. / column
            h = s[1] / (.5 + row * .5)

        offset = x, y
        h /= 2.

        # cell rectangle:
        for c in range(column + 2):
            q_x += [int(x)]
            x += w

        for r in range(row + 2):
            q_y += [int(y)]
            y += h

        # Compose intersect coordinates:
        for r in range(row):
            for c in range(column):
                y, y1 = q_y[r], q_y[r + 2]
                x, x1 = q_x[c], q_x[c + 1]
                position = x, y
                size = x1 - x, y1 - y

                if (
                    x + size[0] > s[0] + offset[0] or
                    y + size[1] > s[1] + offset[1]
                ):
                    position = size = 0, 0

                a = table[r][c]
                a.cell = Rect(position, size)
                if size[0]:
                    a.shape = a.plaque = self._get_shape(r, c)

    def _get_shape(self, r, c, is_pocket=False):
        """
        Do shape.

        r, c: int
            cell index

        is_pocket: flag
            If it's true, the intersects are
            calculated with pocket dimensions.

        Return: tuple
            shape
        """
        r1, c1 = r, c

        if is_pocket:
            c *= 2
            r *= 3

        x, x1 = self.q_x[c], self.q_x[c + 1]
        y, y1, y2 = self.q_y[r], self.q_y[r + 1], self.q_y[r + 2]

        # The 'x' value flips when inverted:
        is_inverse = Shape.is_inverse_triangle(r1, c1)

        if self.is_right:
            is_inverse = not is_inverse
        return (x, y, x1, y1, x, y2) if is_inverse else (x1, y, x, y1, x1, y2)
