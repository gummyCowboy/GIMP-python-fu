#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk, Window as wi
from roller_port_plaque_mask import PortPlaqueMask
from roller_window import Window


class RWPlaqueMask(Window):
    """
    Is a GTK dialog with options for defining a plaque mask.
    """
    def __init__(self, g):
        """
        Create a window.

        g: Button
            Is responsible.
        """
        self.safe = g
        d = {
            wk.WIN: g.win.win,
            wk.WINDOW_TITLE: "Choose a Plaque Mask",
            wk.WINDOW_KEY: wi.RESIZE_CHOOSER
        }

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortPlaqueMask(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()
