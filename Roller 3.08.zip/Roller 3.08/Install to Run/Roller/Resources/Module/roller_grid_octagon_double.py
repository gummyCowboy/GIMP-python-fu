#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_one import Rect
from roller_one_extract import Shape

# The odd row and column intersects are offset in their intersect list:
ODD_INTERSECT_OFFSET = 2
OCTAGON_REMAIN = 1. - sh.OCTAGON_RATIO


class GridOctagonDouble:
    """
    Calculate the coordinates and the size of cells.

    The cells are octagon shaped and are placed in a double-spaced grid.
    """

    def __init__(self, one):
        """
        Calculate cell size and octagon shape.

        one: One
            Has init values.
        """
        grid = self.grid = one.grid
        grid_type = self.grid_type = one.grid_type
        self.is_not_shift = grid.double_type == sh.NOT_SHIFT
        row, column = self.row, self.column = one.r, one.c
        table = grid.table
        s = one.layer_space
        x, y = one.offset

        # intersect points:
        self.q_x = []
        self.q_y = []

        if grid_type == gr.CELL_SIZE:
            w, h = one.column_width / 1., one.row_height / 1.

        elif grid_type == gr.SHAPE_COUNT:
            w = s[0] / (sh.OCTAGON_RATIO + column * OCTAGON_REMAIN)
            h = s[1] / (sh.OCTAGON_RATIO + row * OCTAGON_REMAIN)
            w = min(w, h)
            w, h = w, w

        else:
            w = s[0] / (sh.OCTAGON_RATIO + column * OCTAGON_REMAIN)
            h = s[1] / (sh.OCTAGON_RATIO + row * OCTAGON_REMAIN)

        s1 = self._calc_intersects(one, x, y, w, h)

        # Compose points:
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(grid, r, c):
                    q, q1 = self._get_intersects(r, c)
                    position = q[0], q1[0]
                    size = q[3] - q[0], q1[3] - q1[0]

                    if size[0] > s1[0] or size[1] > s1[1]:
                        size = position = 0, 0

                    # 'cell' is the cell rectangle before margins:
                    a = table[r][c]
                    a.cell = Rect(position, size)
                    if size[0]:
                        a.shape = a.plaque = (
                            q[1], q1[0],
                            q[2], q1[0],
                            q[3], q1[1],
                            q[3], q1[2],
                            q[2], q1[3],
                            q[1], q1[3],
                            q[0], q1[2],
                            q[0], q1[1]
                        )

    def _calc_intersects(self, one, x, y, w, h):
        """
        Calculate vertical and horizontal intersect points.

        one: One
            Has 'layer_space'.

        x, y: int
            topleft coordinate

        w, h: float
            cell size

        Return: tuple
            table size
        """
        w1 = w * sh.OCTAGON_RATIO
        h1 = h * sh.OCTAGON_RATIO
        w2 = w - w1
        h2 = h - h1
        w3 = w - w1 - w1
        h3 = h - h1 - h1
        s1 = (self.column - 1) * w2 + w, (self.row - 1) * h2 + h
        s = one.layer_space
        x, y = Shape.calc_pin_offset(
            one.pin_corner,
            s,
            s1[0], s1[1],
            x, y
        )
        offset = x, y
        s1 = s[0] + offset[0], s[1] + offset[1]

        for r in range(self.row):
            self.q_y += [y, y + h1, y + h2, y + h]
            y += h + h3

        for _ in range(self.column):
            self.q_x += [x, x + w1, x + w2, x + w]
            x += w + w3
        return s1

    def _get_intersects(self, r, c):
        """
        Get the points for an aligned octagon, double-spaced.

        r, c: int
            cell index

        Return: tuple
            of octagon offsets
        """
        c1 = c // 2 * 4
        r1 = r // 2 * 4

        if c % 2:
            index_x = (c - 1) * 4 + 2 - c1

        else:
            index_x = c * 4 - c1

        if r % 2:
            index_y = (r - 1) * 4 + 2 - r1
        else:
            index_y = r * 4 - r1
        return self.q_x[index_x:index_x+4], self.q_y[index_y:index_y+4]
