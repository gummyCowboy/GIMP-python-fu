#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Bump as fb,
    Image as fi,
    Mask as ms,
    Model as mo,
    Resize as fz
)
from roller_constant_key import (
    BackdropStyle as by,
    Effect as ek,
    Option as ok,
    Step as sk
)
BRUSH_KEY = (
    ok.ANGLE_JITTER,
    ok.BRUSH,
    ok.BRUSH_ANGLE,
    ok.BRUSH_HARDNESS,
    ok.BRUSH_SIZE,
    ok.BRUSH_SPACING,
    ok.OPACITY
)
BUMP_KEY = (
    ok.BLUR_X,
    ok.BLUR_Y,
    ok.BUMP_TYPE,
    ok.BUMP_TYPE,
    ok.BUMP_DEPTH,
    ok.NOISE
)
IMAGE_KEY = (
    ok.AS_LAYERS,
    ok.AUTOCROP,
    ok.COLUMN_SLICE,
    ok.FILTER,
    ok.FOLDER,
    ok.FOLDER_ORDER,
    ok.IMAGE_SOURCE,
    ok.ROW_SLICE,
    ok.SLICE,
    ok.SLICE_ORDER
)
INFLUENCE_KEY = (
    ok.BACKDROP_INFLUENCE,
    ok.BORDER_INFLUENCE,
    ok.FRINGE_INFLUENCE,
    ok.IMAGE_INFLUENCE,
    ok.METAL_FRAME,
    ok.OTHER_FRAME,
    ok.PLAQUE_INFLUENCE,
    ok.TRANSLUCENT_FRAME
)
PLAQUE_KEY = (
    ok.FEATHER,
    ok.FONT,
    ok.HORZ_SCALE,
    ok.IMAGE,
    ok.MASK_TYPE,
    ok.TEXT,
    ok.VERT_SCALE
)
RESIZE_KEY = (
    ok.RESIZE_TYPE,
    ok.CROP_X,
    ok.CROP_Y,
    ok.CROP_W,
    ok.CROP_H,
    ok.FIXED_IMAGE_SIZE_W,
    ok.FIXED_IMAGE_SIZE_H,
    ok.FACTOR_IMAGE_SIZE_W,
    ok.FACTOR_IMAGE_SIZE_H
)
STRIPE_KEY = (
    ok.BLUR_BEHIND,
    ok.COLOR,
    ok.OPACITY,
    ok.STRIPE_HEIGHT,
    ok.STRIPE_TYPE
)


class Tip:
    """Has tooltip text strings."""

    AS_LAYERS = \
        " {} \n" \
        "\tAs Layers:\t\t{} \n" \
        "\tLayer Order:\t\t{} "

    BACKDROP_INFLUENCE = \
        " Is the amount to apply to the backdrop-style or image. "

    BLEND = " Use a higher value to create less textural variation. "
    BRUSH = \
        " Brush:\n" \
        "\tBrush:\t\t\t{} \n" \
        "\tSize:\t\t\t{} \n" \
        "\tSpacing:\t\t\t{} \n" \
        "\tOpacity:\t\t\t{} \n" \
        "\tHardness:\t\t{} \n" \
        "\tAngle:\t\t\t{} \n" \
        "\tJitter:\t\t\t{} " \

    CAPTION_IMAGE_NAME = \
        " Has Image?\t\t\t{}\n" \
        " Type:\t\t\t\t{} \n" \
        " Justification:\t\t\t{} \n" \
        " Leading Text:\t\t{} \n" \
        " Trailing Text:\t\t\t{} \n" \
        " Font Size:\t\t\t{}\n" \
        " Opacity:\t\t\t{} \n" \
        " Font:\t\t\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t\t{} \n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Clip to Cell:\t\t\t{} "

    CAPTION_LEADING_TEXT = \
        " Is a prefix to a sequenced number or an image name. "

    CAPTION_START_NUMBER = \
        " Is the first number to be displayed in a numeric sequence, \n" \
        " where each successive image increases this number by one. "

    CAPTION = \
        " Has Image?\t\t\t{}\n" \
        " Type:\t\t\t\t{}\n" \
        " Justification:\t\t\t{} \n" \
        " Text:\t\t\t\t{} \n" \
        " Font Size:\t\t\t{}\n" \
        " Opacity:\t\t\t{} \n" \
        " Font:\t\t\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t\t{}\n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{}\n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Clip to Cell:\t\t\t{} "

    CAPTION_TRAILING_TEXT = \
        " Is a suffix to a sequenced number or an image name. "

    CELL_BORDER = \
        " Has Image?\t\t{} \n" \
        " Border Width:\t{} \n" \
        " Opacity:\t\t{} \n" \
        " Border Blur:\t\t{} \n" \
        " Bump Depth:\t{} \n" \
        " Emboss?\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t{}\n" \
        "\tGreen:\t\t{} \n" \
        "\tBlue:\t\t{} \n" \
        "{}\n"

    CELL_GAP = " Is the number of sequenced-cells between mazes. "
    CLIP_TO_CELL = \
        " When selected, the material is contained within boundaries. \n" \
        " The boundaries are defined by a layer or cell. "

    CLOSE_FILE = \
        " If selected, any open images is closed \n" \
        " after it's first use, freeing up the memory. The \n" \
        " downside is that if the image is referenced by \n" \
        " another cell, the image is reloaded which takes \n" \
        " more time than using an already open image. "

    CLOTH_BUMP = \
        " Bump:\n" \
        "\tBump Type:\t\t{} \n" \
        "\tDepth:\t\t\t{} \n" \
        "\tBlur X:\t\t\t{} \n" \
        "\tBlur Y:\t\t\t{} \n" \
        "\tInvert:\t\t\t{} "

    COLUMN_1 = \
        " Modifies the number of slats to draw \n" \
        " for the lower layer of the grate. "

    COLUMN_2 = \
        " Modifies the number of slats to draw \n" \
        " for the upper layers of the grate. "

    CROSSHATCH_BUMP = \
        " Bump:\n" \
        "\tBump Type:\t\t{} \n" \
        "\tDepth:\t\t\t{} \n" \
        "\tInvert:\t\t\t{} "

    DELETE_PLANS = \
        " When selected, the plans layer group is removed after a render. "

    DIAGONAL_ROTATION = \
        " The direction angle is mirrored \n" \
        " in the opposite direction. The result \n" \
        " is a vector that goes through the center, " \
        " starting and ending at the image bounds. "

    ELEVATION = \
        " Used by emboss functions in a render. It \n" \
        " determines the midtone lightness of an emboss. "

    END_COORDINATE = \
        " The end coordinate is a factor of the layer size \n" \
        " value. The coordinates scales with the render size. "

    FEATHER = \
        " The initial feather is this number divided \n" \
        " by steps. Subsequent steps add the initial \n" \
        " value to the feather. This value becomes the \n" \
        " feather amount applied on the last step. "

    FACTOR_POSITION_H = \
        " The value is multiplied by the height of the render. "

    FACTOR_POSITION_W = \
        " The value is multiplied by the width of the render. "

    FACTOR_X = \
        " The value is multiplied by the width of the context. \n" \
        " For layers, the width is the render width. \n" \
        " For cells, the width is the cell width. "

    FACTOR_Y = \
        " The value is multiplied by the height of the context. \n" \
        " For layers, the height is the render height. \n" \
        " For cells, the height is the cell height. "

    FIXED_POSITION_X = \
        " The fixed values are added to the factored values to get \n" \
        " a cell rectangle. For a non-rectangular cell shape, the \n" \
        " cell rectangle defines the shape's bounds."

    FRAME = \
        " Are 'png'-type images found in Roller's Frame folder. \n" \
        " A frame is molded to fit a cell's image rectangle. "

    FRAME_STYLE_AS_IS = " As Is does not modify the frame material. "
    FRAME_STYLE_COLOR = " Color paints the frame material with a color. "
    FRAME_STYLE_GRADIENT = \
        " Gradient paints the frame material with a gradient \n" \
        " that is drawn over the image rectangle. "

    FRAME_STYLE_IMAGE = \
        " Image paints the frame material with an image. \n" \
        " The image paint is molded to fit the cell's image rectangle. "

    FRAME_STYLE_PLASMA = \
        " Plasma paints the frame with a plasma effect. "

    FRINGE_ABOUT_AS_IS = \
        " The brush material is used to make the fringe without changes. "

    FRINGE_ABOUT_BACKDROP = \
        " A copy of the backdrop material is painted over the fringe \n" \
        " brush. The copied backdrop material's rectangle is not resized. "

    FRINGE_ABOUT_GRADIENT = \
        " A gradient is applied over the fringe \n" \
        " rectangular bounds. The fringe brush-strokes \n" \
        " are then painted with the overlapping gradient. "

    FRINGE_ABOUT_IMAGE = \
        " An image is sized to the fringe rectangular bounds. The fringe \n" \
        " brush-strokes are then painted with the overlapping image. "

    FRINGE_ABOUT_MASK = \
        " The mask is made from fringe brush-strokes that are \n" \
        " cut into a required plaque. If there is no plaque, then \n" \
        " the fringe-mask does not produce anything. "

    FRINGE_ABOUT_ONE_COLOR = \
        " The fringe brush-strokes are painted with a single color. "

    FRINGE_ABOUT_PATTERN = \
        " The fringe rectangular bounds are filled with \n" \
        " a pattern. The fringe brush-strokes are then \n" \
        " painted with the overlapping pattern. "

    FRINGE_ABOUT_PLASMA = " The fringe brush strokes are painted with plasma. "
    FRINGE_ABOUT_TWO_COLOR = \
        " The fringe brush-strokes are painted with alternating colors. "

    FRINGE_GENERAL = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        " Clip to Cell:\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}"

    FRINGE_CONTRACT = \
        " At zero, the fringe is drawn on the edge \n" \
        " of a cell. With contract, the edge moves \n" \
        " inward to the center of the cell. To get the \n" \
        " whole brush tip inside the cell, try setting \n" \
        " the contract value to half of the brush size. "

    FRINGE_GRADIENT = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Gradient Type:\t\t{} \n" \
        " Gradient Angle:\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        " Clip to Cell:\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Gradient:\t\t\t{} "

    FRINGE_IMAGE = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        " Clip to Cell:\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        "{} "

    FRINGE_MASK = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        "{}"

    FRINGE_ONE_COLOR = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        " Clip to Cell:\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Color:\n" \
        "\tRed:\t\t\t{}\n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{} "

    FRINGE_PATTERN = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        " Clip to Cell:\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Pattern:\t\t\t\t{} "

    FRINGE_PLASMA = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        " Random Seed:\t\t{} \n" \
        " Clip to Cell:\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}"

    FRINGE_TWO_COLOR = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Contract:\t\t\t{} \n" \
        " Clip to Cell:\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}\n" \
        " Color #1:\n" \
        "\tRed:\t\t\t{}\n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{}\n" \
        " Color #2:\n" \
        "\tRed:\t\t\t{}\n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{} "

    GRID_NORMALIZED = \
        " The layer space is filled with normal-shapes using the \n" \
        " shape counts. Normal-shapes have equal length sides. "

    GRID_FIXED_SIZE = \
        " The layer space is divided by these quantities to \n" \
        " calculate the row and column counts. If either the row \n" \
        " or column span exceeds the layer space size, then \n" \
        " the layer space size is used. \n" \
        " Thus there is always at least one row and column. "

    GRID_BY_COUNT = \
        " The layer space is divided by these quantities to calculate \n" \
        " the row and column sizes. If the division has a remainder, \n" \
        " then the remainder is distributed evenly through the table. \n" \
        " Thus the entire layer space is utilized. "

    GRID_LABEL = \
        " The layer space is the render size of the \n" \
        " backdrop image less the layer margins. \n"

    GRID_SHIFT = \
        " When shifted, the grid's first \n" \
        " cell is row: 1, column: 2. "

    HAS_IMAGE = " Has Image?\t\t{}\n"
    HEIGHT_MOD = \
        " An image's height is modified by this amount. "

    IMAGE_AUTOCROP = \
        " When checked, empty space around an image is cropped out. "

    IMAGE_FOLDER = \
        " Image: \n" \
        "\tFolder:\t\t\t{} \n" \
        "\tFolder Order:\t\t{} "

    IMAGE_FOLDER_FILTERED = \
        " Image:\n" \
        "\tFolder:\t\t\t{} \n" \
        "\tFile Filter:\t\t{} \n" \
        "\tFolder Order:\t\t{} "

    IMAGE_INFLUENCE = " Is the amount to apply to image material. "

    IMAGE_LAYERS = \
        " The image's layers are iterated as a tree, \n" \
        " where each layer becomes an image reference. "

    IMAGE_NAME = \
        " The order of image name list is \n" \
        " from GIMP's open image order. "

    IMAGE_NEXT_LINEAR = \
        " Assign images using an index variable.\n" \
        " Assign the first open image,\n" \
        " increment after assigning an image,\n" \
        " and end image assignment with the last open image. \n" \
        " The option shares the index variable with the \n" \
        " circular option."

    IMAGE_NEXT_CIRCULAR = \
        " Assign images using an index variable.\n" \
        " It assigns the first open image,\n" \
        " increments after assigning an image,\n" \
        " and rolls=over to the first open image \n" \
        " after the last open image is used." \
        " The option shares the index variable with the \n" \
        " linear option."

    IMAGE_NUMERIC = \
        " The order of the numeric list is \n" \
        " from GIMP's open image order. "

    IMAGE_ORDER = \
        " Is the direction of the layer-tree iteration. \n" \
        " With top-down, the first layer is the \n" \
        " layer at the top of the layer palette. \n" \
        " If top-down is off, then the order is \n" \
        " bottom-up, and the first layer is \n" \
        " the bottom layer in the palette. "

    IMAGE_PRE_LINEAR = \
        " Assign images using an index variable.\n" \
        " It assigns the last open image,\n" \
        " decrements after assigning an image, and ends \n" \
        " image assignment with the first open image. \n" \
        " The option shares the index variable with \n" \
        " the circular option."

    IMAGE_PRE_CIRCULAR = \
        " Assign images using an index variable. \n" \
        " It assigns the last open image, \n" \
        " decrements after assigning an image,\n" \
        " and rolls-over to the last open image \n" \
        " after the first open image is used. \n" \
        " The option shares the index variable \n" \
        " with the linear option."

    IMAGE_MASK_SHAPE = \
        " Mask\n" \
        "\tType:\t\t\t{} \n" \
        "\tHorizontal Scale:\t{} \n" \
        "\tVertical Scale:\t{} \n" \
        "\tFeather:\t\t\t{} "

    IMAGE_MASK_TEXT = \
        " Mask\n" \
        "\tType:\t\t\t{} \n" \
        "\tText:\t\t\t{} \n" \
        "\tHorizontal Scale:\t{} \n" \
        "\tVertical Scale:\t{} \n" \
        "\tFeather:\t\t\t{} \n" \
        "\tFont:\t\t\t{} "

    IMAGE_MASK_IMAGE = \
        " Mask\n" \
        "\tType:\t\t{} \n" \
        "{} "

    IMAGE_SLICE = \
        "{} \n" \
        "\tSlice:\t\t\tTrue \n" \
        "\tRow Slices:\t\t{} \n" \
        "\tColumn Slices:\t{} \n" \
        "\tSlice Order:\t\t{} "

    INFLUENCE = \
        " Gradient Light Influence: \n" \
        " Backdrop\t\t\t{} \n" \
        " Border\t\t\t\t{} \n" \
        " Plaque\t\t\t\t{} \n" \
        " Fringe\t\t\t\t{} \n" \
        " Image\t\t\t\t{} \n" \
        " Metal Frame\t\t\t{} \n" \
        " Other Frame\t\t\t{} \n" \
        " Translucent Frame\t{} "

    INNER_SHADOW = \
        " {}: \n" \
        "\tInlay Blur:\t\t{} \n" \
        "\tIntensity:\t\t{} \n" \
        "\tShadow Color:\n" \
        "\t\tRed:\t\t{}\n" \
        "\t\tGreen:\t\t{} \n" \
        "\t\tBlue:\t\t{} "

    JAG_AMPLITUDE = " Use a higher value to increase the jag projection. "
    KEEP_GRADIENT = \
        " Have GIMP store the sampled gradient \n" \
        " in the user's default gradient folder. "

    LENGTH_SHIFT = \
        " Modifies the length of the tape per strip, plus or minus, \n" \
        " by a random amount limited by this scale. "

    AZIMUTH = \
        " The light angle is used by \n" \
        " emboss functions in a render. "

    LOOP_MINUS = \
        " Assign images using a circular-type index variable. \n" \
        " It decrements itself before assigning an image. \n" \
        " It rolls-over to the last open image after \n" \
        " the first open image. Both Loop-Plus and \n" \
        " Loop-Minus use the same index variable. If the Minus\n" \
        " option is used before the Plus option, the last \n" \
        " open image is the first open image reference. "

    LOOP_PLUS = \
        " Assign images using a circular-type index variable. This \n" \
        " Loop index increments before assigning an \n" \
        " image. Its rolls-over to the first open image after \n" \
        " the last open image. Both versions use the same index \n" \
        " variable. If the Plus index is used before the Minus \n" \
        " index, the first open image is the first open image \n" \
        " reference. "

    MAIN_OPTIONS = \
        " Open a backdrop-style and image-effect options window. "

    MAIN_LAYOUT = \
        " Create a sketch-up image of the render \n" \
        " using the above Layout Options."

    MAKE_OPAQUE = \
        " Make an item opaque to give it a solid or stronger \n" \
        " appearance, but has no antialiasing. "

    MARGIN = \
        " Per margin, the fixed-value margin and the factor \n" \
        " margin are added together to form a single margin. "

    MARGIN_DETAIL = \
        " Fixed-Value Margins: \n" \
        "\tTop:\t\t\t{} \n" \
        "\tBottom:\t\t\t{} \n" \
        "\tLeft:\t\t\t{} \n" \
        "\tRight:\t\t\t{} \n" \
        " Factor-Size Margins: \n" \
        "\tTop:\t\t\t{} \n" \
        "\tBottom:\t\t\t{} \n" \
        "\tLeft:\t\t\t{} \n" \
        "\tRight:\t\t\t{} "

    MASK_CIRCLE = \
        " The circle mask's diameter is calculated from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where the width-diameter equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the height-diameter equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."

    MASK_CUT_CORNERS = \
        " The cut corners mask calculates an octagon that defines \n" \
        " the corners. This octagon is calculated from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where the uncut-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the uncut-height equals:\n" \
        "\timage height x vertical scale."

    MASK_DIAMOND = \
        " The diamond mask's diagonals are calculated from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where the width-diagonal equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the height-diagonal equals:\n" \
        "\timage height x vertical scale."

    MASK_HEXAGON = \
        " A hexagon mask's size is calculated from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where the width-diameter equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the height-diameter equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is\n" \
        " multiplied by the hexagon's size ratio."

    MASK_IMAGE = \
        " The image mask uses an image's alpha channel as a mask. \n" \
        " The image mask's scale is transformed by the size of the \n" \
        " image in the cell and the vertical and horizontal scales. "

    MASK_OCTAGON = \
        " The octagon mask's sides are calculated from the image size \n" \
        " and the horizontal and vertical scale factors.\n\n" \
        " Where the octagon-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the octagon-height equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."

    MASK_OVAL = \
        " The oval mask's diameters are calculated from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where width-diameter equals: \n" \
        "\timage width x horizontal scale,\n" \
        " and height-diameter equals:\n" \
        "\timage height x vertical scale."

    MASK_RECTANGLE = \
        " The rectangle mask's sides are calculated from the image size \n" \
        " and the horizontal and vertical scale factors.\n\n" \
        " Where the rectangle-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the rectangle-height equals:\n" \
        "\timage height x vertical scale."

    MASK_RHOMBUS = \
        " The rhombus mask's diagonal is calculated from the image size \n" \
        " and the horizontal and vertical scale factors.\n\n" \
        " Where diagonal-value-1 equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and diagonal-value-2 equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."

    MASK_ROUND_CORNERS = \
        " The rounded corners mask calculates a ellipse that defines \n" \
        " the corners. This ellipse is calculated the from the image \n" \
        " size and the horizontal and vertical scale factors.\n\n" \
        " Where the ellipse-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the ellipse-height equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " This ellipse is drawn at each corner to form the rounded\n" \
        " corners."

    MASK_SQUARE = \
        " The square mask's side is calculated from the image size \n" \
        " and the horizontal and vertical scale factors.\n\n" \
        " Where the side-value-1 equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the side-value-2 equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."

    MASK_TEXT = \
        " The text mask is made from the text in the\n" \
        " 'Text' entry with the font from the 'Font' button. \n\n" \
        " Where the text-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the text-height equals:\n" \
        "\timage height x vertical scale."

    MASK_TRIANGLE_DOWN = \
        " The triangle is pointing down and is squeezed \n" \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MASK_TRIANGLE_LEFT = \
        " The triangle is pointing left and is squeezed \n" \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MASK_TRIANGLE_RIGHT = \
        " The triangle is pointing right and is squeezed \n" \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MASK_TRIANGLE_UP = \
        " The triangle is pointing up and is squeezed \n" \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MERGE_CELL = " X:\t\t{} \n Y:\t\t{} \n Width:\t{} \n Height:\t{} "

    METAL_FRAME = " Is amount to apply to an image-effect's metal frame. "
    n = " Apply cell data and show cell to the "
    NAVIGATION = (
        n + "north (ctrl + ↑). ",
        n + "south (ctrl + ↓). ",
        n + "west (ctrl + ←). ",
        n + "east (ctrl + →). "
    )

    NO_CAPTION = \
        " Has Image?\t{}\n" \
        " There is no text. "

    NO_CELL_BORDER = \
        " Has Image?\t\t{} \n" \
        " There is no cell border. "

    NO_FRINGE = \
        " Has Image?\t{}\n" \
        " There is no fringe. "

    NO_FRINGE_IMAGE = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} \n" \
        " There is no image for the fringe. "

    NO_IMAGE_MASK = \
        "\tType:\t\tNone "

    NO_PLAQUE = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} "

    NO_SHADOW = \
        " {}: \n" \
        " Intensity:\t\t\t{} "

    NOISE_BUMP = \
        " Bump:\n" \
        "\tBump Type:\t\t{} \n" \
        "\tBump Depth:\t{} \n" \
        "\tNoise:\t\t\t{} "

    NOISE_POWER = \
        " Use a higher value to increase \n" \
        " the noise effect on the frame. "

    OBEY_MARGINS = \
        " When selected, the plaque boundaries are \n" \
        " contained within the layer or cell margins. "

    OFFSET_Z = \
        " Set altitude of an image. Higher values are above lower values. "

    OPTION_MAIN = {
        by.AVERAGE_COLOR:
            " Overlay the backdrop image with \n"
            " a pixelated backdrop image. ",

        by.BACKDROP_IMAGE:
            " Use the backdrop image settings for the backdrop. ",

        by.CLAY_CHEMISTRY:
            " Create a dark texture, colorful smokey \n"
            " lines mixed with a gradient's color. ",

        by.COLOR_FILL: " Apply a color fill to the backdrop image. ",
        by.COLOR_GRID:
            " Create a color grid to overlay the backdrop image. ",

        by.CORE_DESIGN: " Create a unique design using a gradient. ",
        by.CRYSTAL_CAVE: " Create a textured grey layer. ",
        by.CUBISM_COVER: " Use Cubism to create a layered backdrop. ",
        by.DARK_FORT: " Use the backdrop image to texture a dark brick wall. ",
        by.DENSITY_GRADIENT: " Mix a stone-like texture with a gradient. ",
        by.ETCH_SKETCH: " Create sketchy lines from the backdrop image. ",
        by.FLOOR_SAMPLE: " Create a radial color-gradient using wedges. ",
        by.GALACTIC_FIELD:
            " Using the background-image, apply a Dotify impression \n"
            " and mix that result with a gradient to make an organic style. ",

        by.GLASS_GAW:
            " Create colorful lines on a smokey glass-like backdrop. ",

        by.GRADIENT_FILL: " Apply a gradient over the backdrop image. ",
        by.CARBON_14: " Create a dark layered mosaic. ",
        by.IMAGE_GRADIENT:
            " Create a gradient from sample points \n"
            " taken from the backdrop image, \n"
            " then overlay the backdrop image. ",

        by.LINE_STONE:
            " Create a neutral bumpy concrete base \n"
            " with added touches of color and line. ",

        by.LOST_MAZE:
            " Create a maze with raised walls and gradient colors. ",

        by.MAZE_BLEND:
            " Use the backdrop image \n"
            " and overlay a shadowy maze. ",

        by.MYSTERY_GRATE:
            " Create two grates that overlay \n"
            " and are painted with a gradient. ",

        by.NANO_SUIT:
            " Create a fine textured gradient from the backdrop-image. ",

        by.NOISE_RIFT:
            " Create organic lines to overlay the backdrop image. ",

        by.PATTERN_FILL:
            " Fill the backdrop image with a pattern fill. \n"
            " Use bump to create texture. ",

        by.RAINBOW_VALLEY: " Create colorful droopy sprites. ",
        by.ROCKY_LANDING: " Create a rock-like texture. ",
        by.SPACETIME_FABRIC:
            " Use saturated backdrop image \n"
            " colors and a grid to form lines. ",

        by.SPECIMEN_SPECKLE:
            " Patterns and a gradient overlay \n"
            " to form edges which are then shredded. ",

        by.SPIRAL_CHANNEL:
            " Create a spiral-sourced design. ",

        by.SQUARE_CLOUD:
            " Create layered squares with a common color theme. ",

        by.TRAILING_VINE:
            " Create layered, curvy colored lines. \n"
            " You may wish to blur the backdrop image \n"
            " to harmonize with the illusion of depth. ",

        by.WATERY_PAGE:
            " Create a surreal watercolor from the backdrop-image material. ",

        ek.BALL_JOINT:
            " Use a dots-brush to create an image border. \n"
            " Frame Type: Metal ",

        ek.BORDER_LINE:
            " Create a metallic-type border. \n"
            " Frame Type: Metal ",

        ek.BRUSH_PUNCH:
            " Use a brush to make forms attached to a frame. \n"
            " Frame Type: Metal ",

        ek.CAMO_PLANET:
            " Create a hard frame and apply a \n"
            " camouflage paint and a course texture. \n"
            " Frame Type: Other ",

        ek.CERAMIC_CHIP:
            " Create a metal frame wrapped with \n"
            " another frame of ceramic chips. \n"
            " Frame Type: Metal and Other ",

        ek.CIRCLE_PUNCH:
            " Create a metal frame that has circular holes. \n"
            " Frame Type: Metal ",

        ek.CLEAR_FRAME:
            " Create a translucent frame around image material. \n"
            " Frame Type: Translucent ",

        ek.COLOR_BOARD:
            " Create an colored frame around image material. \n"
            " There are additional transparency options. \n"
            " Frame Type: Translucent ",

        ek.COLOR_PIPE:
            " Create a frame made from a custom \n"
            " gradient, bump, and noise. \n"
            " Frame Type: Other ",

        ek.CORNER_TAPE:
            " Place tape strips on the corners of an image's rectangle. \n"
            " If the image is rotated, Corner Tape will fail when \n"
            " the resize method is not Locked Aspect Ratio. \n"
            " Frame Type: Other ",

        ek.CUTOUT_PLATE:
            " Create a pattern-painted rectangular \n"
            " frame around the image material. \n"
            " Frame Type: Other ",

        ek.FEATHER_STEPS: " Create a feathered image edge. ",
        ek.FRAME_OVER:
            " Overlay an image frame over each image \n"
            " with color and blend options. Note, the frame \n"
            " does not rotate with an image rotation or jitter. \n"
            " Frame Type: Other ",

        ek.GLASS_REVEAL:
            " Create a transparent frame with multiple \n"
            " options for defining its cut or appearance. \n"
            " Frame Type: Translucent ",

        ek.GRADIENT_LEVEL:
            " Create a frame from a linear \n"
            " gradient of two colors. \n"
            " Frame Type: Translucent ",

        ek.HOT_GLUE:
            " Create translucent, tube-shaped, gluey image frame. ",

        ek.INNER_SHADOW:
            " Add a shadow to the image edges making the \n"
            " image appear to be below the backdrop. ",

        ek.JAGGED_EDGE: " Create a subtle choppy edge to the image material. ",
        ek.LINE_FASHION:
            " Create a frame with bars. \n"
            " Frame Type: Metal ",

        ek.MAZE_MIRROR:
            " Create an metallic frame around the image, \n"
            " the composition, and in a mirrored network. \n"
            " Frame Type: Metal ",

        ek.METALLIC_PROFILE:
            " Create an metallic frame with characteristics from a profile. \n"
            " Frame Type: Metal ",

        ek.NO_EFFECT: " Leave the image as is. ",
        ek.PAINT_RUSH:
            " Create an white frame that has edgy paint material. \n"
            " Frame Type: None ",

        ek.RAD_WAVE:
            " Create image and composition frames \n"
            " and a network of wavy connectors. \n"
            " Frame Type: Metal ",

        ek.RAISED_MAZE:
            " Create image and composition \n"
            " frames that have a maze of connectors. \n"
            " Frame Type: Metal ",

        ek.SHAPE_BURST:
            " Create a frame from a shape gradient. \n"
            " Frame Type: Other ",

        ek.SQUARE_CUT:
            " Create a metallic-like frame from a grid with rectangles. \n"
            " Frame Type: Metal ",

        ek.SQUARE_PUNCH:
            " Create a metal frame that has square holes. \n"
            " Frame Type: Metal ",

        ek.STAINED_GLASS:
            " Create a metal frame wrapped with \n"
            " another frame of stained glass. \n"
            " Frame Type: Metal and Translucent ",

        ek.STRETCH_TRAY:
            " Stretches the edges of an image to make a frame. \n"
            " Frame Type: Metal and Other ",

        ek.WIRE_FENCE: " "
            " Create a metal frame wrapped with \n"
            " another frame of fence-like material. \n"
            " Frame Type: Metal "
    }
    OTHER_FRAME = \
        " Is amount to apply to an image-effect's frame \n" \
        " of type that is neither metal or translucent. "

    PER_CELL_BEGIN = \
        " Select to modify options on a per cell basis. "

    PER_CELL_BUTTON = \
        " Open a per cell window in order \n" \
        " to modify settings cell-by-cell. "

    PLACE = \
        " Mode:\t\t\t\t{} \n" \
        " Justification:\t\t\t{} \n" \
        " Opacity: \t\t\t{} \n" \
        " Rotate:\t\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Flip Horizontal:\t\t{} \n" \
        " Flip Vertical:\t\t\t{} \n" \
        "{} \n" \
        "{} \n" \
        "{} "

    PLAN_COORDINATES = \
        " Display the top-left screen coordinate of \n" \
        " an image's bounding rectangle."

    PLAN_CORNERS = \
        " Display the location of a cell's bounding \n" \
        " rectangle in screen coordinates."

    PLAN_DIMENSIONS = \
        " Dimensions are the size of the image's \n" \
        " bounding rectangle."

    PLAN_FRINGE = " The Cell Fringe mask-type requires a Cell Plaque. "
    PLAN_GRID = " The grid is made with rows and columns. "
    PLAN_RATIOS = \
        " A ratio is an image center point divided by the render size. "

    PLAQUE_AVERAGE_COLOR = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}"

    PLAQUE_COLOR = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t\t{} \n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}"

    PLAQUE_GRADIENT = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Gradient Type:\t\t{} \n" \
        " Gradient Angle:\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        " Gradient:\t\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}"

    PLAQUE_IMAGE = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}"

    PLAQUE_NETTING = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Line Width:\t\t\t{} \n" \
        " Spacing:\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t\t{} \n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}"

    PLAQUE_PATTERN = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        " Pattern:\t\t\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}"

    PLAQUE_PLASMA = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Blur:\t\t\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        "{}\n" \
        "{}\n" \
        "{}"

    PLAQUE_SHADOW = \
        " Has Image?\t\t\t{} \n" \
        " Type:\t\t\t\t{} \n" \
        " Mode:\t\t\t\t{} \n" \
        " Opacity:\t\t\t{} \n" \
        " Blur Behind:\t\t\t{} \n" \
        " Feather:\t\t\t\t{} \n" \
        " Intensity:\t\t\t{} \n" \
        " Shadow Blur:\t\t{} \n" \
        " Obey Margins:\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t\t\t{} \n" \
        "\tGreen:\t\t\t{} \n" \
        "\tBlue:\t\t\t{} \n" \
        "{}\n" \
        "{}"

    POST_BLUR = \
        " Create a blurry frame that sits on top \n" \
        " of image material. The blur is applied \n" \
        " after the frame is defined and embossed. "

    RANDOM_SEED = " Change this value to produce a different result. "
    RESIZE_CROP = \
        " Crop:\n" \
        "\tOffset X:\t\t{} \n" \
        "\tOffset Y:\t\t{} \n" \
        "\tWidth:\t\t{} \n" \
        "\tHeight:\t\t{} "

    RESIZE_CROP_VALUE = \
        " Crop the image from a topleft coordinate \n" \
        " defined by x and y. The size of the crop is \n" \
        " from the width and height options. \n" \
        " If the image doesn't fit in the cell, \n" \
        " a selection is made from the image using \n" \
        " the cell's justification and size. "

    RESIZE_FIXED = \
        " Fixed-Size: \n" \
        "\tWidth:\t\t{} \n" \
        "\tHeight:\t\t{} "

    RESIZE_FIXED_VALUE = \
        " The image is resized to these dimensions. \n" \
        " If the image doesn't fit in the cell, \n" \
        " a selection is made from the image using \n" \
        " the cell's justification and size. "

    RESIZE_FACTOR = \
        " Factor of Image Size: \n" \
        "\tWidth x\t\t{} \n" \
        "\tHeight x\t\t{} "

    RESIZE_FACTOR_VALUE = \
        " The image is resized by multiplying the \n" \
        " factor values by the image size. If \n" \
        " the image doesn't fit in the cell, a \n" \
        " selection is made from the image using \n" \
        " using the cell's justification and size. "

    REVERSE = " Reverse the order of the gradient colors. "
    ROUNDED = " The Rounded process is faster. "
    SAMPLE_POINTS = " Sample points are evenly distributed between the edges. "
    SATURATION = \
        " Values below one lower the saturation. \n" \
        " Saturation multiplies the saturation of the input. "

    SCATTER_COUNT = " Is the number of mazes to draw. "
    SEED_GLOBAL = " Modifies all the random seeds in use. "
    SHADOW = \
        " {}: \n" \
        "\tShadow Blur:\t\t{} \n" \
        "\tIntensity:\t\t{} \n" \
        "\tOffset X:\t\t\t{} \n" \
        "\tOffset Y:\t\t\t{} \n" \
        "\tShadow Color:\n" \
        "\t\tRed:\t\t{}\n" \
        "\t\tGreen:\t\t{} \n" \
        "\t\tBlue:\t\t{}\n" \
        "\tMake Opaque:\t{} "

    SHIFT = \
        " Shift:\n" \
        "\tOffset X:\t\t\t{} \n" \
        "\tOffset Y:\t\t\t{} \n" \
        "\tOffset Z:\t\t\t{} \n" \
        "\tShift X:\t\t\t{} \n" \
        "\tShift Y:\t\t\t{} \n" \
        "\tShift Z:\t\t\t{} \n" \
        "\tShift Width:\t\t{} \n" \
        "\tShift Height:\t\t{} \n" \
        "\tJitter:\t\t\t{} \n" \
        "\tWidth Mod:\t\t{} \n" \
        "\tHeight Mod:\t\t{} \n" \
        "\tRandom Seed:\t{} "

    SHIFT_HEIGHT = \
        " An image height is randomly modified by an amount within \n" \
        " a range. The range value is a span, extending from zero \n" \
        " in the positive and negative directions. "

    SHIFT_WIDTH = \
        " An image width is randomly modified by an amount within \n" \
        " a range. The range value is a span, extending from zero \n" \
        " in the positive and negative directions. "

    SHIFT_X = \
        " An image's position X is randomly modified by an amount \n" \
        " within a range. The range value is a span, extending \n" \
        " from zero in the positive and negative directions. "

    SHIFT_Y = \
        " An image's position Y is randomly modified by an amount \n" \
        " within a range. The range value is a span, extending \n" \
        " from zero in the positive and negative directions. "

    SHIFT_Z = \
        " An image's position Z is randomly modified by an\n" \
        " amount  within a range. The range value is a span, \n" \
        " extending from zero to the value provided here. "

    SLICE = " Slice an image using row and column quantities. "
    SPIRAL_DISTANCE = " Lower the value to increase the spiral count. "
    START_X = \
        " The start coordinate is a factor of the layer size \n" \
        " value. The coordinate scales with the render size. "

    STEPS = " The image feather effect repeats by this quantity. "
    STOP_LENGTH = \
        " Is the lowest value of pixels \n" \
        " for drawing a line in a maze. "

    STRIPE = \
        " Stripe:\n" \
        "\tOpacity:\t\t\t{} \n" \
        "\tHeight:\t\t\t{} \n" \
        "\tBlur Behind:\t\t{} \n" \
        "\tColor:\n" \
        "\t\tRed:\t\t{}\n" \
        "\t\tGreen:\t\t{} \n" \
        "\t\tBlue:\t\t{} "

    STRIPE_HEIGHT = \
        " The height is calculated as a \n" \
        " factor of the caption height \n" \
        " that is made from text and shadow. "

    THRESHOLD = \
        " A threshold of 1.0 is to match all \n" \
        " and a threshold of 0.0 is to mach none. "

    TRANSLUCENT_FRAME = \
        " Is the amount to apply a translucent image-effect frame. "

    USE_PLASMA = \
        " When checked, a blurred plasma layer \n" \
        " is used as a background. If unchecked, \n" \
        " the backdrop image settings are used \n" \
        " for the background. If the backdrop \n" \
        " image is used, try using the maximum \n" \
        " blur for an optimal effect. "

    WIDTH_MOD = \
        " An image's width is modified by this amount. "
    WHIRL = " As if there were a hole at the center of the image. "

    @staticmethod
    def make_brush_tooltip(d):
        """
        Create a tooltip for a brush option button.

        d: dict
            with brush settings

        Return: string
            tooltip
        """
        for i in BRUSH_KEY:
            if i not in d:
                return ""
        return Tip.BRUSH.format(
            d[ok.BRUSH],
            d[ok.BRUSH_SIZE],
            d[ok.BRUSH_SPACING],
            d[ok.OPACITY],
            round(d[ok.BRUSH_HARDNESS], 3),
            d[ok.BRUSH_ANGLE],
            d[ok.ANGLE_JITTER]
        )

    @staticmethod
    def make_bump_tooltip(d):
        """
        Create a tooltip for a bump option button.

        d: dict
            with bump settings

        Return: string
            tooltip
        """
        for i in BUMP_KEY:
            if i not in d:
                return ""
        n = d[ok.BUMP_TYPE]
        if n == fb.NOISE:
            return Tip.NOISE_BUMP.format(
                n,
                d[ok.BUMP_DEPTH],
                round(d[ok.NOISE], 2)
            )

        elif n == fb.CLOTH:
            return Tip.CLOTH_BUMP.format(
                n,
                d[ok.BUMP_DEPTH],
                round(d[ok.BLUR_X], 1),
                round(d[ok.BLUR_Y], 1),
                bool(d[ok.INVERT])
            )

        elif n == fb.CROSSHATCH:
            return Tip.CROSSHATCH_BUMP.format(
                n,
                d[ok.BUMP_DEPTH],
                bool(d[ok.INVERT])
            )
        else:
            return " No Bump "

    @staticmethod
    def make_influence_tooltip(d):
        """
        Create a tooltip for an influence option button.

        d: dict
            of image choice

        Return: string
            tooltip
        """
        for i in INFLUENCE_KEY:
            if i not in d:
                return ""
        return Tip.INFLUENCE.format(
            d[ok.BACKDROP_INFLUENCE],
            d[ok.BORDER_INFLUENCE],
            d[ok.PLAQUE_INFLUENCE],
            d[ok.FRINGE_INFLUENCE],
            d[ok.IMAGE_INFLUENCE],
            d[ok.METAL_FRAME],
            d[ok.OTHER_FRAME],
            d[ok.TRANSLUCENT_FRAME]
        )

    @staticmethod
    def make_image_tooltip(d):
        """
        Create a tooltip for a image choice option button.

        d: dict
            of image choice

        Return: string
            tooltip
        """
        for i in IMAGE_KEY:
            if i not in d:
                return ""

        n = d[ok.IMAGE_SOURCE]

        if n != "None":
            if n in fi.INDICES:
                x = fi.INDICES.index(n)
                a = d[n]
                n = " Image:\n\t{} ".format(fi.TOOLTIPS[x][a])

            elif n == ok.FOLDER:
                if d[ok.FILTER]:
                    n = Tip.IMAGE_FOLDER_FILTERED.format(
                        d[ok.FOLDER],
                        d[ok.FILTER],
                        fi.FOLDER_ORDER_LIST[d[ok.FOLDER_ORDER]]
                    )
                else:
                    n = Tip.IMAGE_FOLDER.format(
                        d[ok.FOLDER],
                        fi.FOLDER_ORDER_LIST[d[ok.FOLDER_ORDER]]
                    )

            else:
                n = " Image: \n\t{} ".format(d[n])

            if d[ok.AUTOCROP]:
                n = "{}\n\tAutocrop:\t\tTrue ".format(n)

            if d[ok.AS_LAYERS]:
                n = Tip.AS_LAYERS.format(
                    n,
                    bool(d[ok.AS_LAYERS]),
                    fi.LAYER_ORDER_LIST[d[ok.LAYER_ORDER]]
                )
            if d[ok.SLICE]:
                n = Tip.IMAGE_SLICE.format(
                    n,
                    d[ok.ROW_SLICE],
                    d[ok.COLUMN_SLICE],
                    fi.SLICE_ORDER_LIST[d[ok.SLICE_ORDER]]
                )

        else:
            n = " Image: None "

        n = n.replace("  ", " ")
        return n

    @staticmethod
    def make_margin_tooltip(d):
        """
        Return a tooltip for a margin tuple.

        The tuple is composed of four fixed-value
        and four factor values.

        d: dict
            of margins

        Return: string
            tooltip
        """
        return Tip.MARGIN_DETAIL.format(
            d[ok.FIXED_TOP],
            d[ok.FIXED_BOTTOM],
            d[ok.FIXED_LEFT],
            d[ok.FIXED_RIGHT],
            d[ok.FACTOR_TOP],
            d[ok.FACTOR_BOTTOM],
            d[ok.FACTOR_LEFT],
            d[ok.FACTOR_RIGHT]
        )

    @staticmethod
    def mask_plaque_tooltip(d):
        """
        Return a tooltip for a mask button.

        d: dict
            of mask, plaque or image

        Return: string
            tooltip
        """
        for i in PLAQUE_KEY:
            if i not in d:
                return ""

        n = d[ok.MASK_TYPE]

        if n == "None":
            tip = Tip.NO_IMAGE_MASK

        elif n == ms.TEXT:
            tip = Tip.IMAGE_MASK_TEXT.format(
                n,
                d[ok.TEXT],
                d[ok.HORZ_SCALE],
                d[ok.VERT_SCALE],
                d[ok.FEATHER],
                d[ok.FONT]
            )

        elif n == ms.IMAGE:
            tip = Tip.IMAGE_MASK_IMAGE.format(
                n,
                Tip.make_image_tooltip(d[ok.IMAGE])
            )

        else:
            tip = Tip.IMAGE_MASK_SHAPE.format(
                n,
                d[ok.HORZ_SCALE],
                d[ok.VERT_SCALE],
                d[ok.FEATHER]
            )
        return tip

    @staticmethod
    def make_resize_tooltip(d):
        """
        Create a tooltip for a resize method option button.

        d: dict
            of resize method

        Return: string
            tooltip
        """
        for i in RESIZE_KEY:
            if i not in d:
                return ""

        n = d[ok.RESIZE_TYPE]

        if n not in fz.TEXT_TYPE:
            if n == fz.CROP:
                n = Tip.RESIZE_CROP.format(
                    d[ok.CROP_X],
                    d[ok.CROP_Y],
                    d[ok.CROP_W],
                    d[ok.CROP_H]
                )

            elif n == fz.FIXED:
                n = Tip.RESIZE_FIXED.format(
                    d[ok.FIXED_IMAGE_SIZE_W],
                    d[ok.FIXED_IMAGE_SIZE_H]
                )
            elif n == fz.FACTOR:
                n = Tip.RESIZE_FACTOR.format(
                    d[ok.FACTOR_IMAGE_SIZE_W],
                    d[ok.FACTOR_IMAGE_SIZE_H]
                )
        return n

    @staticmethod
    def make_shadow_tooltip(d):
        """
        Create a tooltip for a shadow tuple.

        d: dict
            of Tri-Shadow SuperPreset

        Return: string
            tooltip
        """
        def get_shadow_tip(e):
            if i in mo.LOWER_SHADOWS:
                if e[ok.INTENSITY]:
                    return Tip.SHADOW.format(
                        i[-1],
                        e[ok.SHADOW_BLUR],
                        e[ok.INTENSITY],
                        e[ok.OFFSET_X],
                        e[ok.OFFSET_Y],
                        e[ok.SHADOW_COLOR][0],
                        e[ok.SHADOW_COLOR][1],
                        e[ok.SHADOW_COLOR][2],
                        bool(e[ok.MAKE_OPAQUE])
                    )
                else:
                    return Tip.NO_SHADOW.format(i[-1], e[ok.INTENSITY])

            elif i == sk.INNER_SHADOW:
                if e[ok.INTENSITY]:
                    return Tip.INNER_SHADOW.format(
                        i[-1],
                        e[ok.INLAY_BLUR],
                        e[ok.INTENSITY],
                        e[ok.SHADOW_COLOR][0],
                        e[ok.SHADOW_COLOR][1],
                        e[ok.SHADOW_COLOR][2]
                    )
                else:
                    return Tip.NO_SHADOW.format(i[-1], e[ok.INTENSITY])
            return ""

        # Check validity:
        if sk.SHADOW_TYPE not in d:
            tip = " No Shadow "

        else:
            a = d[sk.SHADOW_TYPE][ok.SHADOW_TYPE]
            if not a:
                tip = " No Shadow "
            else:
                tip = ""
                for i in (sk.SHADOW_1, sk.SHADOW_2, sk.INNER_SHADOW):
                    n2 = "" if not tip else "\n"
                    tip += n2 + get_shadow_tip(d[i])
        return tip

    @staticmethod
    def make_shift_tooltip(d):
        """
        Create a tooltip for the shift group.

        d: dict
            of Shift

        Return: string
            tooltip
        """
        return Tip.SHIFT.format(
            d[ok.OFFSET_X],
            d[ok.OFFSET_Y],
            d[ok.OFFSET_Z],
            d[ok.SHIFT_X],
            d[ok.SHIFT_Y],
            d[ok.SHIFT_Z],
            d[ok.SHIFT_WIDTH],
            d[ok.SHIFT_HEIGHT],
            d[ok.ANGLE_JITTER],
            d[ok.WIDTH_MOD],
            d[ok.HEIGHT_MOD],
            d[ok.RANDOM_SEED]
        )

    @staticmethod
    def make_stripe_tooltip(d):
        """
        Create a tooltip for a image choice option button.

        d: dict
            of image choice

        Return: string
            tooltip
        """
        for i in STRIPE_KEY:
            if i not in d:
                return ""

        if d[ok.STRIPE_TYPE] == 1:
            return Tip.STRIPE.format(
                d[ok.OPACITY],
                d[ok.STRIPE_HEIGHT],
                d[ok.BLUR_BEHIND],
                d[ok.COLOR][0],
                d[ok.COLOR][1],
                d[ok.COLOR][2]
            )
        else:
            return " No Stripe "
