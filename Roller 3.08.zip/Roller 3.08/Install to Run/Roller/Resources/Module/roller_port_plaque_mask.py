#!/usr/bin/env python
# -*- coding: utf-8 -*-

from roller_constant_for import Widget as fw
from roller_constant_key import Group as gk, Widget as wk
from roller_option_group import OptionGroup
from roller_option_preset import Preset
from roller_port_preview import PortPreview
from roller_window_save import RWSave


class PortPlaqueMask(PortPreview):
    """Configure a plaque mask."""

    def __init__(self, d, g):
        """
        Draw widgets.

        d: dict
            with init values

        g: Button
            with resize info
        """
        PortPreview.__init__(self, d, g)

    def _draw_mask_plaque_option(self, g):
        """
        Draw the options using the default dictionary keys.

        g: VBox
            container for the groups
        """
        k = gk.PLAQUE_MASK
        d = OptionGroup.draw_group(
            **{
                wk.COLOR: self.color,
                wk.CONTAINER: g,
                wk.GROUP_KEY: k,
                wk.GROUP_TYPE: Preset,
                wk.HAS_PRESET: True,
                wk.IS_DEFAULT: False,
                wk.KEYS: Preset.get_keys(k),
                wk.ON_KEY_PRESS: self.on_key_press,
                wk.ON_PREVIEW_BUTTON: self.task_preview,
                wk.ON_WIDGET_CHANGE: self.on_widget_change,
                wk.PATH: (k,),
                wk.PORT: self,
                wk.SAVE_WINDOW: RWSave,
                wk.WIN: self.roller_window
            }
        )
        g = self.preset = d[wk.PRESET]
        self.group = g.group
        g.load_preset(self.safe.get_value(), fw.UNDEFINED)

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for widgets
        """
        self.draw_simple_dialog_port(
            g,
            (self._draw_mask_plaque_option, self.draw_preview_process),
            ("Choose a Plaque Mask", "")
        )

    def get_group_value(self):
        """
        Use to get the preset value.
        Call from PortPreview.

        Return: dict
            of resize method
        """
        return self.preset.get_value()
