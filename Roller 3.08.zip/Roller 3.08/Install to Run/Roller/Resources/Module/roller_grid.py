#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import (
    Grid as gr,
    Group as og,
    Plan as fy,
    Shape as sh,
    Triangle as ft
)
from roller_constant_key import Group as gk, Option as ok
from roller_one import Hat, Rect
from roller_one_extract import dispatch, Form, Path, Shape
from roller_grid_cell import GridCell
from roller_grid_circle import GridCircle
from roller_grid_diamond import GridDiamond
from roller_grid_ellipse_horz import EllipsisHorz
from roller_grid_ellipse_vert import EllipsisVert
from roller_grid_hexagon_horz import HexagonHorz
from roller_grid_hexagon_vert import HexagonVert
from roller_grid_octagon import GridOctagon
from roller_grid_octagon_double import GridOctagonDouble
from roller_grid_rect import GridRect
from roller_grid_triangle_horz import TriangleHorz
from roller_grid_triangle_vert import TriangleVert
from roller_one import One, Base

SHAPES = {
    sh.CIRCLE_HORIZONTAL: GridCircle,
    sh.CIRCLE_VERTICAL: GridCircle,
    sh.DIAMOND: GridDiamond,
    sh.ELLIPSE_HORIZONTAL: EllipsisHorz,
    sh.ELLIPSE_VERTICAL: EllipsisVert,
    sh.HEXAGON_HORIZONTAL: HexagonHorz,
    sh.HEXAGON_VERTICAL: HexagonVert,
    sh.OCTAGON: GridOctagon,
    sh.OCTAGON_ALIGNED: GridOctagon,
    sh.OCTAGON_DOUBLE: GridOctagonDouble,
    sh.RECTANGLE: GridRect,
    sh.RHOMBUS: GridDiamond,
    sh.SQUARE: GridRect,
    ft.TRIANGLE_DOWN: TriangleVert,
    ft.TRIANGLE_UP: TriangleVert,
    ft.TRIANGLE_LEFT: TriangleHorz,
    ft.TRIANGLE_RIGHT: TriangleHorz
}


def contract_cell_table(q, row, col):
    """
    Contract Per Cell tables to correspond with the grid dict.

    Checks Merge Cells table for group dimension overflow.

    q: 2D list
        of cell table

    row, col: int
        cell table size
        row, column span
    """
    if q:
        r = len(q)

        if r > row:
            # Remove rows:
            for _ in range(r - row):
                q.pop()
        for r in range(len(q)):
            c = len(q[r])
            if c > col:
                # Remove columns:
                for _ in range(c - col):
                    q[r].pop()


def correct_contracted_cells(q, row, col):
    """
    When cells contract, their dimensions change.
    This makes the cut-off cells independent.

    Use with the merge cell table.

    q: 2D list
        of cell table

    row, col: int
        cell table size
        row, column span
    """
    if q:
        r, c = row, col
        r1 = len(q)
        for r2 in range(r1):
            for c1 in range(len(q[r2])):
                if r2 >= r or c1 >= c:
                    q[r2][c1] = 1, 1
    return q


def correct_merge_overflow(s, row, col, r, c):
    """
    Check if the Merge Cells' table has contracted. If so then
    the top-left cells need their dimensions checked for overflow.

    s: tuple of int (w, h)
        group dimension

    row, col: int
        max location

    r, c: int
        current location
    """
    if s[0] + r > row:
        s = row - r, s[1]

    if s[1] + c > col:
        s = s[0], col - c
    return s


def expand_cell_table(q, row, col, a):
    """
    Expand a cell table based on the row and column counts.

    During an expansion, values are inserted into
    a table from the grid settings.
    These settings are placed in the 'cell' variable.

    Each Per Cell group has its own cell type.

    q: 2D list
        of cell table

    row, col: int
        cell table size
        row, column span

    a: value
        to initialize cell table

    Return: list
        of cell table
    """
    if not q:
        q = Base.create_2d_table(row, col, init=a)
    else:
        # 'r', current row count:
        r = len(q)

        if r < row:
            # e = [cell] * col
            e = []

            for _ in range(col):
                e.append(a)
            for r1 in range(row - r):
                # Add a row with a new list:
                q.append(deepcopy(e))
        for r1 in range(row):
            c = len(q[r1])
            if c < col:
                for _ in range(col - c):
                    # Add a column:
                    q[r1].append(a)
    return q


def fix_cell_table_size(q, r, c, a):
    """
    An existing cell table expands or contracts
    depending on the cell table size.

    q: 2D list
        a cell table
        of option values

    r, c: int
        row, column span of cell table

    a: value
        to initialize cell table

    Return: list
        of cells
        2D
        lists within a list
    """
    q = expand_cell_table(q, r, c, a)

    contract_cell_table(q, r, c)
    return q


def fix_merge_cells(q, row, col):
    """
    Correct overflow references by reducing
    merged group dimensions in the topleft cells.

    q: list
        a cell table

    row, col: int
        cell table span
    """
    if q:
        for r in range(row):
            for c in range(col):
                if r < len(q):
                    if c < len(q[r]):
                        q[r][c] = correct_merge_overflow(
                            q[r][c],
                            row, col,
                            r, c
                        )
    q = correct_contracted_cells(q, row, col)
    return q


def get_cell_shape(d):
    """
    Get the cell shape according the cell type.

    d: dict
        of grid form

    Return: string
        cell shape descriptor
    """
    if d[ok.GRID_TYPE] == gr.SHAPE_COUNT:
        return d[ok.CELL_SHAPE_NORMAL]
    return d[ok.CELL_SHAPE]


def is_merge_cell(d):
    """
    Determine if the grid is in merge cell mode.

    d: dict
        of grid chunk

    Return: bool
        Is true if the grid dict is in merge cell mode.
    """
    if is_rectangle_shape(d):
        return True if ok.PER_CELL in d and d[ok.PER_CELL] else False
    return False


def is_rectangle_shape(d):
    """
    Determine if the current cell shape is a rectangle.

    d: dict
        of grid form or chunk

    Return: bool
        Is true if the cell shape is a rectangle.
    """
    return get_cell_shape(d) == sh.RECTANGLE


class Grid:
    """
    Calculate the coordinates and the size of cells for the current grid.

    A grid cell table is at the core of Grid and is referred by
    'self.table'. Each cell in the table corresponds with a
    cell defined by the Grid option group.

    A cell has attributes:
        image: Image assigned
        image_name: string, name of image assigned
        merge_cell: rectangle of merged cells
        mold: rectangle of image that was placed
        plaque: cell shape with margins
        pocket: rectangle of cell with margins
        rect: rectangle of cell
        shape: cell shape without margins
    """

    def __init__(self, one):
        """
        Initialize a cell table for a cell grid group.

        table[row][column]

        one: One
            Has init variables.
            d: grid chunk
            path: tuple with model

        Return: object
            of cell shape
        """
        d = self.grid_d = one.d
        path = one.path
        self.layer_margin = one.layer_margin
        self.cell_shape = get_cell_shape(d)
        self.is_merge_cell = is_merge_cell(d)
        self.is_rectangle_shape = is_rectangle_shape(d)
        self.double_type = self._get_double_type()
        r, c = self.division = self._calc_grid_division()
        table = self.table = Base.create_2d_table(r, c)

        Grid.fix_tables(path, r, c)

        # The per cell table was changed by 'fix_tables':
        self.grid_d[ok.PER_CELL] = Path.get_grid_from_path(path)[ok.PER_CELL]

        for i in range(r):
            for j in range(c):
                if Shape.is_allocated_cell(self, i, j):
                    table[i][j] = GridCell(i, j)

        self.shaper = self._calc_cell()

        # merge cell rectangle:
        for i in range(r):
            for j in range(c):
                # cell, 'a':
                a = table[i][j]

                # If merging cells:
                if self.is_merge_cell:
                    # 's' size of the cell in cells:
                    s = self.grid_d[ok.PER_CELL][i][j]

                    # Sub-topleft cells are unavailable:
                    if s == (-1, -1):
                        x = y = w = h = 0
                    else:
                        s1 = i + s[0] - 1, j + s[1] - 1
                        x, y, w, h = self.get_cell_block((i, j), s1)

                else:
                    if Shape.is_allocated_cell(self, i, j):
                        rect = a.cell
                        x, y = rect.position
                        w, h = rect.size
                    else:
                        # 'x' is set to flag an unallocated cell:
                        x = -1
                if x > -1:
                    # If the cell has a width of zero,
                    # then the cell is not an image cell:
                    a.merge_cell = Rect((x, y), (w, h))
                    if self.is_merge_cell and (s[0] > 1 or s[1] > 1):
                        n = self.cell_shape

                        if n in ft.TRIANGLE:
                            if Shape.is_inverse_triangle(r, c):
                                n = ft.INVERTED[n]
                        a.shape = a.plaque = dispatch[n](a.merge_cell)

    def _calc_cell(self):
        """
        Calculate the cell sizes for the cell table.
        """
        e = self.grid_d
        size = Hat.cat.render.size
        shape = self.cell_shape
        top, bottom, left, right = self.layer_margin
        one = One(offset=(left, top), grid=self)
        one.r, one.c = self.division
        one.layer_space = (
            Base.seal(size[0] - left - right, 1, size[0]),
            Base.seal(size[1] - top - bottom, 1, size[1])
        )

        # Transfer the grid dict to one:
        for k, a in e.items():
            k1 = k.lower().replace(" ", "_")
            setattr(one, k1, a)
        return SHAPES[shape](one)

    def _calc_grid_division(self):
        """
        Determine the row and column count for the grid.

        Return: tuple
            of int
            row, column
            cell index
        """
        cat = Hat.cat
        d = self.grid_d
        n = d[ok.GRID_TYPE]
        size = cat.render.size
        if n == gr.CELL_COUNT:
            r, c = (
                min(d[ok.ROW_COUNT], size[1]),
                min(d[ok.COLUMN_COUNT], size[0])
            )

        elif n == gr.SHAPE_COUNT:
            r, c = (
                min(d[ok.VERT_COUNT], size[1]),
                min(d[ok.HORZ_COUNT], size[0])
            )

        else:
            # cell size:
            top, bottom, left, right = self.layer_margin
            w = size[0] - left - right
            h = size[1] - top - bottom
            width, height = d[ok.COLUMN_WIDTH], d[ok.ROW_HEIGHT]

            # rectangle and octagon:
            r, c = max(h // height, 1), max(w // width, 1)

            # hexagon, ellipse, diamond, octagon-double, and triangle:
            n = self.cell_shape

            if not Shape.is_rectangular_shape(n) and n not in sh.OCTAGONS:
                if n in sh.HORIZONTAL_ALIGNED:
                    w1, h1 = width * .5, height * .75
                    w2, h2 = w - w1, h - height * .25
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)

                elif n in sh.VERTICAL_ALIGNED:
                    w1, h1 = width * .75, height * .5
                    w2, h2 = w - width * .25, h - h1
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)

                elif n in ft.VERTICAL_TRIANGLE:
                    w1 = width * .5
                    w2 = w - w1
                    r, c = max(int(h / height), 1), max(int(w2 / w1), 1)

                elif n in ft.HORIZONTAL_TRIANGLE:
                    h1 = height * .5
                    h2 = h - h1
                    r, c = max(int(h2 / h1), 1), max(int(w / width), 1)

                elif n == sh.DIAMOND:
                    w1, h1 = width * .5, height * .5
                    w2, h2 = w - w1, h - h1
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)
                elif n == sh.OCTAGON_DOUBLE:
                    w1 = width * sh.OCTAGON_RATIO
                    h1 = height * sh.OCTAGON_RATIO
                    w2, h2 = width - w1, height - h1
                    w3, h3 = w - w1, h - h1
                    r, c = max(int(h3 / h2), 1), max(int(w3 / w2), 1)
        return r, c

    def _get_double_type(self):
        """
        Get the double type of the grid's cell table.

        Return: enum
            of double-type
        """
        if self.cell_shape in sh.DOUBLE:
            if self.grid_d[ok.CELL_SHIFT]:
                return sh.SHIFT
            else:
                return sh.NOT_SHIFT
        return sh.NOT_DOUBLE_SPACE

    def calc_pockets(self, d):
        """
        Calculate cell rectangle, pocket, plaque, and shape.

        table: list
            of cells

        d: dict
            of cell margin, chunk
        """
        is_per_cell = False
        row, column = self.division

        if d[ok.PER_CELL]:
            is_per_cell = True

        else:
            q = top, bottom, left, right = self.get_common_cell_size(d)[0]

        s = Hat.cat.render.size
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(self, r, c):
                    rect = self.get_merge_cell_rect(r, c)
                    x, y = rect.position
                    w, h = rect.size
                    if w:
                        if is_per_cell:
                            q = top, bottom, left, right = Form.combine_margin(
                                Form.get_form(d, r, c), w, h
                            )
                        if any(q):
                            x += left
                            y += top
                            x = Base.seal(x, 0, s[0] - 1)
                            y = Base.seal(y, 0, s[1] - 1)
                            w = max(w - left - right, 1)
                            h = max(h - top - bottom, 1)
                    self.table[r][c].pocket = Rect((x, y), (w, h))

    @staticmethod
    def fix_tables(path, r, c):
        """
        Fix the scale of the per cell tables.
        A per cell widget has a its own per cell table.

        path: tuple
            with model

        r, c: int
            cell index
        """
        # Update the per cell tables:
        d = og.PER_CELL_DEPENDENT
        e = Hat.cat.group_dict
        q = path[:3]
        for i in og.PER_CELL_DEPENDENT:
            path = q + d[i]
            g = e[path].vbox.per_cell_group
            if g.check_button.get_value():
                d1 = Path.get_dict_from_path(path)
                table = d1[ok.PER_CELL]

                if i == gk.PER_CELL_GRID:
                    table = fix_cell_table_size(table, r, c, (1, 1))
                    table = fix_merge_cells(table, r, c)

                else:
                    d1.pop(ok.PER_CELL)
                    table = fix_cell_table_size(table, r, c, d1)
                g.set_value(table)

    def get_cell_block(self, u, v):
        """
        Use when cells are merged, and the merge
        cell's dimension needs to be determined.

        u: tuple
            (r, c) of int
            topleft cell

        v: tuple
            (r, c) of int
            bottom-right cell

        Return the topleft coordinates and the scale of an array of cells.
        """
        r1, c1 = u
        x, y = self.get_cell_rect(r1, c1).position
        rect = self.get_cell_rect(v[0], v[1])
        x1, y1 = rect.position
        w, h = rect.size
        w = x1 - x + w
        h = y1 - y + h
        return x, y, w, h

    def get_cell_position(self, r, c):
        """
        Get a cell's position.

        r, c: int
            cell index

        Return: tuple
            position of cell
            x, y
        """
        return self.table[r][c].cell.position

    def get_cell_rect(self, r, c):
        """
        Get a cell's rectangle.

        table: list
            of cells

        r, c: int
            cell index

        Return: Rect
            of cell
        """
        return self.table[r][c].cell.clone

    def get_common_cell_size(self, d):
        """
        Get the cell size for margin calculations.

        d: dict
            of cell margin, chunk

        Return: tuple
            (cell margins, cell size)
        """
        r = c = 0

        if self.cell_shape in sh.DOUBLE:
            if self.grid_d[ok.CELL_SHIFT]:
                c = 1
                if self.division[1] == 1:
                    if self.division[0] == 1:
                        # There is only one cell, and it isn't allocated:
                        c = -1
                    else:
                        r, c = 1, 0

        if c > -1:
            rect = self.get_merge_cell_rect(r, c)
            w, h = rect.size
            q = Form.combine_margin(d, w, h)

        else:
            # Invalid margins:
            q = -1, -1, -1, -1
            w = h = 0
        return q, (w, h)

    def get_image(self, r, c):
        """
        Get the image assigned to a cell.

        r, c: int
            cell index

        Return: Image or None
            as assigned
        """
        a = self.table[r][c].cell
        if hasattr(a, 'image'):
            return a.image

    def get_image_name(self, r, c):
        """
        Get the image name assigned to a cell.

        r, c: int
            cell index

        Return: string or None
            an image name
        """
        a = self.table[r][c].cell
        if hasattr(a, 'image_name'):
            return a.image_name

    def get_merge_cell_rect(self, r, c):
        """
        Get a cell's size in the context of possible merged cells.

        r, c: int
            cell index

        Return: tuple
            of cell
            x, y, w, h
        """
        return self.table[r][c].merge_cell.clone

    def get_mold(self, r, c):
        """
        Mold is a rectangle sized for image place.

        r, c: int
            cell index

        Return: Rect
            of mold
            the rectangle of the image place
        """
        return self.table[r][c].mold.clone

    def get_plaque(self, r, c, j=None):
        """
        Get a 'plaque' value.

        d: dict
            of grid

        r, c: int
            cell index
            Has 'plaque' item.
        """
        if r != fy.CUSTOM_CELL:
            return self.table[r][c].plaque
        return j.plaque

    def get_pocket(self, r, c):
        """
        Get the cell pocket.

        r, c: int
            cell index

        Return: Rect
            of mold
            the rectangle of the cell with margins
        """
        return self.table[r][c].pocket.clone

    def get_shape(self, r, c):
        """
        Get the shape tuple or dict.

        Ellipse shapes are in a dictionary. The
        other shapes are in a list or a tuple.

        r, c: int
            cell index

        Return: object
            of shape
        """
        return self.table[r][c].shape

    def set_image(self, r, c, j):
        """
        Store the image assigned to a cell.

        r, c: int
            cell index

        j: Image
            as assigned
        """
        self.table[r][c].cell.image = j

    def set_image_name(self, r, c, n):
        """
        Store the image name assigned to a cell.

        r, c: int
            cell index

        n: string
            image name
        """
        self.table[r][c].cell.image_name = n

    def set_mold(self, r, c, position, size):
        """
        Set the mold position. The 'mold' is the
        rectangle for an image place.

        r, c: int
            cell index

        position: tuple
            x, y
            screen coordinate
        """
        self.table[r][c].mold = Rect(position, size)

    def set_plaque(self, r, c, a):
        """
        Update a cell plaque.

        r, c: int
            cell index

        a: value
            plaque
        """
        self.table[r][c].plaque = a

    def update_cell_block(self, u, v):
        """
        Update the merge cell size for a cell block.

        u: tuple
            cell index of the topleft cell of the block

        v: tuple
            cell index of the bottom-right cell of the block
        """
        x, y, w, h = self.get_cell_block(u, v)
        self.table[u[0]][u[1]].merge_cell = Rect((x, y), (w, h))
