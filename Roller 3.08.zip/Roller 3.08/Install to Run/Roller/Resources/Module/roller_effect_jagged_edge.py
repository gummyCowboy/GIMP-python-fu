#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_key import Layer as nk, Option as ok
from roller_constant_fu import Fu
from roller_one import Hat
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb
ta = Fu.ThresholdAlpha


def process_layer(j, image_layer, one):
    """
    Add a frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    one: One
        Has variables.

    Return: layer or None
        with frame material
    """
    d = one.d
    z = Lay.clone(image_layer)

    Lay.apply_mask(z)

    z1 = Lay.clone(z)

    Hat.cat.seed(d)
    Sel.item(z)
    pdb.gimp_selection_shrink(j, max(d[ok.AMPLITUDE] + 1, 6))
    Sel.invert_clear(z)
    Lay.hide(image_layer)

    for x in range(4):
        a = randint(0, 1)
        pdb.plug_in_shift(j, z, randint(1, d[ok.AMPLITUDE]), a)
        pdb.plug_in_shift(j, z, randint(1, d[ok.AMPLITUDE]), int(not a))

    pdb.plug_in_oilify(j, z, d[ok.SMOOTHNESS], Fu.Oilify.RGB_MODE)
    pdb.plug_in_threshold_alpha(j, z, ta.THRESHOLD_ALL)

    # Transfer the alpha to make a Jagged Edge:
    Sel.item(z)

    Sel.invert_clear(z1)
    pdb.gimp_image_remove_layer(j, z)

    z1.name = Lay.name(z1.parent, one.k)
    return z1


class JaggedEdge:
    """Create a jagged edge around image material."""

    @staticmethod
    def do(one):
        """
        Do the Jagged Edge image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer, list, or None
            Is jagged edge.
        """
        z = one.image_layer
        j = z.image

        if one.is_image_group:
            undo_z = []
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], one)]

                # The 'jagged edge' layer is now the image layer:
                Hat.cat.save_image_layer(undo_z[-1], i.name)
            one.shadow_layer = [z]

        else:
            undo_z = process_layer(j, z, one)
            one.shadow_layer = [undo_z]
            Hat.cat.register_layer(
                (one.render_type, one.model_name, nk.IMAGE),
                undo_z
            )
        return undo_z
