#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat, Mode
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
mo = Fu.Mosaic


class Carbon14:
    """Create a backdrop-style with layers of mosaic tiles."""

    @staticmethod
    def do(one):
        """
        Make the backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with Carbon 14
        """
        def mosaic():
            pdb.plug_in_mosaic(
                j, z,
                size,
                mo.TILE_HEIGHT_4,
                mo.TILE_SPACING_1,
                d[ok.NEATNESS],
                mo.NO_SPLIT,
                cat.azimuth,
                mo.MIN_COLOR_VARIATION,
                mo.YES_ANTIALIAS,
                mo.YES_COLOR_AVERAGING,
                bs.MESH_TYPE.index(d[ok.MESH_TYPE]),
                mo.SMOOTH_SURFACE,
                mo.BLACK_AND_WHITE_GROUT
            )

        cat = Hat.cat
        j = cat.render.image
        d = one.d
        if d[ok.OPACITY]:
            size = d[ok.MESH_SIZE]
            group = Lay.group(j, one.k)
            group1 = Lay.group(j, one.k, parent=group)
            z = plasma_layer = Lay.clone(one.z)

            pdb.gimp_image_reorder_item(j, z, group, 1)
            pdb.plug_in_plasma(j, z, d[ok.RANDOM_SEED], 3)

            # Create alternate textures for light and dark:
            z = lights = RenderHub.make_polar_mask(j, z)
            z = dark = RenderHub.make_polar_mask(j, z, is_dark=True)

            Gegl.saturation(z, .1)

            z = Lay.clone(lights)
            z.mode = fu.LAYER_MODE_LUMA_DARKEN_ONLY

            pdb.plug_in_emboss(j, z, cat.azimuth, 30, 1, 1)

            z = Lay.clone(dark)
            z.mode = fu.LAYER_MODE_HSV_VALUE

            Lay.blur(z, size * 2)
            pdb.gimp_edit_copy_visible(j)

            z = Lay.paste(z)
            z.mode = fu.LAYER_MODE_LUMA_LIGHTEN_ONLY
            z = z1 = Lay.merge_group(group1)

            pdb.plug_in_colortoalpha(j, z1, (255, 255, 255))
            pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

            z = z2 = Lay.clone(plasma_layer)

            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
            pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
            pdb.plug_in_colortoalpha(j, z, (0, 0, 255))
            pdb.plug_in_colortoalpha(j, z, (0, 255, 0))
            pdb.plug_in_colortoalpha(j, z, (255, 0, 0))

            mosaic()

            z.mode = fu.LAYER_MODE_COLOR_ERASE
            z = plasma_layer

            Gegl.saturation(z, .0)
            Lay.blur(z, size)
            Gegl.emboss(z, cat.azimuth, cat.elevation, 1)
            Lay.hide(z1)
            pdb.gimp_edit_copy_visible(j)
            Lay.show(z1)

            z = Lay.paste(z2)
            z.mode = fu.LAYER_MODE_HSL_COLOR

            pdb.gimp_drawable_invert(z, 0)
            pdb.gimp_image_remove_layer(j, z2)

            z = Lay.merge_group(group)
            z1 = RenderHub.make_polar_mask(j, z)

            Gegl.saturation(z1, .3)
            Gegl.saturation(z, .3)

            z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
            z = Lay.clone(z)

            Gegl.edge(z)

            z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
            z.opacity = 80.
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            z = RenderHub.bump(z, d[ok.BUMP])
            z.opacity = d[ok.OPACITY]

            Lay.clone(one.z)

            z.mode = Mode.get_(d)
            return Lay.merge(z)
