#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_fu import Fu
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_option_preset import Preset
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
um = Fu.UnsharpMask


class DensityGradient:
    """Create a rocky texture and overlay a gradient."""

    @staticmethod
    def do(one):
        """
        Do the backdrop-style.

        one: One
            Has variables.

        Return: layer
            with Density Gradient
        """
        cat = Hat.cat
        j = cat.render.image
        d = one.d
        group = Lay.group(j, one.k)

        cat.seed(d)

        z = Lay.add(j, one.k, parent=group)

        pdb.plug_in_plasma(
            j, z,
            d[ok.RANDOM_SEED] + cat.seed_global,
            Fu.Plasma.LOWEST_TURBULENCE
        )

        z = Lay.add(j, one.k, parent=group)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.plug_in_plasma(
            j, z,
            randint(0, 100000),
            Fu.Plasma.MEDIUM_TURBULENCE
        )

        z = z1 = Lay.add(j, one.k, parent=group)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.plug_in_plasma(
            j, z,
            randint(0, 100000),
            Fu.Plasma.HIGHEST_TURBULENCE
        )
        pdb.gimp_edit_copy_visible(j)

        z = Lay.paste(z)
        z.mode = fu.LAYER_MODE_GRAIN_EXTRACT

        for i in ((255, 0, 0), (0, 255, 0), (255, 0, 255)):
            pdb.plug_in_colortoalpha(j, z, i)

        pdb.plug_in_unsharp_mask(
            j, z1,
            um.RADIUS_3,
            100.,   # um.AMOUNT_100,
            um.THRESHOLD_0
        )

        Lay.clone(z1)
        Gegl.blur(z1, 1.5)

        z1.mode = fu.LAYER_MODE_NORMAL
        z = Lay.clone(z1)
        z.mode = fu.LAYER_MODE_HSV_SATURATION

        pdb.gimp_image_reorder_item(j, z, group, 0)

        z = Lay.clone(z)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.gimp_edit_copy_visible(j)

        z = Lay.paste(z)
        z.mode = fu.LAYER_MODE_EXCLUSION

        Gegl.emboss(z, cat.azimuth, 30, 2)
        Lay.clone(z)

        e = Preset.get_default(by.GRADIENT_FILL)

        e.update(one.d)

        one.z = Lay.merge_group(group)
        e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
            RenderHub.get_gradient_factors(d[ok.GRADIENT_ANGLE])

        e[ok.MODE] = d[ok.GRADIENT_MODE]
        one.d = e
        z = GradientFill.do_layer(j, one)
        return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
