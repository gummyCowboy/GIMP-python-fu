#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
um = Fu.UnsharpMask


def do_gradient(j, z, z1, color, color1, steps):
    """
    Do a color blend effect using two colors.

    j: GIMP image
        work-in-progress

    z: layer
        to receive effect

    z1: layer
        with image

    color, color1: tuple
        RGB

    steps: int
        the number of steps to grow the
        selection to reach color1
    """
    step = RenderHub.calc_gradient(color, color1, steps)
    start_color = color
    q = list(start_color)
    a = None

    Sel.make_layer_sel(z1)

    for i in range(steps):
        if Sel.is_sel(j):
            a = pdb.gimp_selection_save(j)

            Sel.grow(j, 1, 0)
            Sel.load(j, a, option=fu.CHANNEL_OP_SUBTRACT)
            Sel.fill(z, tuple(q))
            Sel.load(j, a, option=fu.CHANNEL_OP_ADD)
            for x in range(3):
                q[x] = start_color[x] + int(step[x] * (i + 1))
        pdb.gimp_image_remove_channel(j, a)

    Sel.make_layer_sel(z1)
    Lay.clear_sel(z)


def process_layer(j, image_layer, one):
    """
    Add frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    one: One
        Has variables.

    Return: layer or None
        with frame material
    """
    d = one.d
    if d[ok.OPACITY]:
        parent = image_layer.parent
        group = Lay.group(j, Lay.name(parent, one.k), parent=parent)
        z = Lay.add(j, one.k, parent=group)
        color, color1 = d[ok.COLOR_1], d[ok.COLOR_2]
        steps = d[ok.FRAME_WIDTH]
        n = d[ok.NOISE_MODE]

        do_gradient(j, z, image_layer, color, color1, steps)

        if n != "None" and d[ok.NOISE_OPACITY]:
            z1 = Lay.clone(z)
            z1.opacity = d[ok.NOISE_OPACITY]
            z1.mode = bs.NOISE_LAYER_MODE[bs.NOISE_MODE_LIST.index(n)]

            pdb.plug_in_plasma(
                j, z1,
                d[ok.RANDOM_SEED],
                Fu.Plasma.LOWEST_TURBULENCE
            )
            Sel.item(z)
            Sel.invert_clear(z1)

            if n == bs.SYRUPY:
                pdb.plug_in_unsharp_mask(
                    j, z1,
                    um.RADIUS_5,
                    um.AMOUNT_1,
                    um.THRESHOLD_0
                )
                pdb.gimp_drawable_desaturate(z1, fu.DESATURATE_LUMINANCE)
            elif n == bs.CARTOONY:
                avg = tuple(
                    [(color[i] + color1[i]) // 2 for i in range(3)]
                )
                RenderHub.do_cartoony(z, z1, avg)

        z = Lay.merge_group(group)
        z.opacity = d[ok.OPACITY]
        return GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)


class GradientLevel:
    """Create a colorful gradient around image material."""

    @staticmethod
    def do(one):
        """
        Do the image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer, list, or None
            with Glass Reveal
        """
        z = one.image_layer
        j = z.image

        if one.is_image_group:
            undo_z = []
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], one)]
            one.shadow_layer = [z]

        else:
            undo_z = process_layer(j, z, one)
            one.shadow_layer = [undo_z, z]
        return undo_z
