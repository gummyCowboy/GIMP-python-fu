#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat, One
from roller_one_fu import Lay, Mage, Sel
from roller_option_preset import Preset
import gimpfu as fu

pdb = fu.pdb


class GradientLight:
    """
    Has functions used to make the GradientLight layer and influence.
    """
    image = None

    @staticmethod
    def apply_light(z, k):
        """
        Add gradient light influence to a layer.

        z: layer
            to receive effect

        k: string
            option key
            of Influence

        Return: layer
            the original or its alter
        """
        def apply_it():
            """
            Apply the gradient light to the layer.

            Return: layer
                with the gradient light
            """
            Mage.copy_all(GradientLight.image)

            j = cat.render.image
            z1 = Lay.paste(z)
            z1.opacity = 100.

            if k == ok.METAL_FRAME:
                z1.mode = fu.LAYER_MODE_HARDLIGHT

            Sel.item(z)
            Sel.invert_clear(z1)

            opacity = z.opacity
            z1.opacity = f
            z1 = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
            z1.opacity = opacity
            return z1

        if z:
            cat = Hat.cat
            d = cat.gradient_light_d
            f = d[ok.INFLUENCE][k]
            if f:
                if GradientLight.image:
                    z = apply_it()
                else:
                    GradientLight.create_gradient_light(d)
                    z = apply_it()
        return z

    @staticmethod
    def create_gradient_light(d):
        """
        Create a gradient light image.
        The image is hidden from the user
        and removed during program closing,
        and a GradientLight undo operation.

        Layers are created from the image
        using copy visible.

        d: dict
            of gradient light
        """
        w, h = Hat.cat.render.size
        j = GradientLight.image = pdb.gimp_image_new(w, h, fu.RGB)
        e = Preset.get_default(by.GRADIENT_FILL)

        e.update(d)
        GradientFill.do_layer(j, One(d=e))
