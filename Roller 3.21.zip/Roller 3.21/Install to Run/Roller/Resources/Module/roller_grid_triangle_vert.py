#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Triangle as ft, Shape as sh
from roller_one import Rect
from roller_one_extract import Shape

RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP
TRIANGLE_MAX = 11547005, 10000000


class TriangleVert:
    """
    Calculate the position and the size of cells for a triangle grid.

    Use intersects to map points shared by multiple triangles.
    Intersects create seamless triangle joints.
    """

    def __init__(self, o):
        """
        Calculate cell points and cell shapes.

        o: One
            Has init values.
            r, c: row, column span
        """
        row, column = self.row, self.column = o.r, o.c
        grid = self.grid = o.grid
        self.grid_type = o.grid_type
        self.is_down_type = grid.cell_shape in ft.DOWN_TYPE
        table = grid.table
        s = o.layer_space

        # intersect points
        q_x = self.q_x = []
        q_y = self.q_y = []

        x, y = o.offset

        if o.grid_type in (gr.CELL_SIZE, gr.SHAPE_COUNT):
            # cell size
            if o.grid_type == gr.CELL_SIZE:
                w, h = o.column_width / 1., o.row_height / 1.

                # table size
                w1 = w / 2.
                w2 = w - w1
                s1 = column * w1 + w2, row * h

            else:
                # Calculate 's1', the table size.
                # Calculate 'w', 'h', the cell size.
                # shape count
                w1 = s[0] / (.5 + column * .5)
                h1 = s[1] / 1. / row

                # There are two possible solutions.
                # solution one
                _w, _h = h1 * UP_RATIO, h1
                w2 = _w / 2.
                w3 = _w - w2
                s1 = column * w2 + w3, row * _h

                # solution two
                _w1, _h1 = w1, w1 * RATIO
                w2 = _w1 / 2.
                w3 = _w1 - w2
                s2 = column * w2 + w3, row * _h1

                # If the first solution fails, use solution two.
                if s1[0] > s[0] or s1[1] > s[1]:
                    s1 = s2
                    w, h = _w1, _h1
                else:
                    w, h = _w, _h
            x, y = Shape.calc_pin_offset(
                o.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            # Calculate cell size for aligned horizontally.
            w = s[0] / (.5 + column * .5)
            h = s[1] / 1. / row

        offset = x, y
        w /= 2.

        # cell rectangle
        for c in range(column + 2):
            q_x += [int(x)]
            x += w

        for r in range(row + 2):
            q_y += [int(y)]
            y += h

        # Compose the points.
        for r in range(row):
            for c in range(column):
                y, y1 = q_y[r], q_y[r + 1]
                x, x1 = q_x[c], q_x[c + 2]
                position = x, y
                size = x1 - x, y1 - y

                if (
                    x + size[0] > s[0] + offset[0] or
                    y + size[1] > s[1] + offset[1]
                ):
                    position = size = 0, 0

                # 'cell' is the cell rectangle before margins.
                a = table[r][c]
                a.cell = Rect(position, size)
                if size[0]:
                    # If there are no margins, then do shape.
                    a.shape = a.plaque = self._get_shape(r, c)

    def _get_shape(self, r, c, is_pocket=False):
        """
        Do shape.

        r, c: int
            cell index

        is_pocket: flag
            If it's true, the intersects are
            calculated with pocket dimensions.

        Return: tuple
            shape
        """
        r1, c1 = r, c

        if is_pocket:
            c *= 3
            r *= 2

        x, x1, x2 = self.q_x[c], self.q_x[c + 1], self.q_x[c + 2]
        y, y1 = self.q_y[r], self.q_y[r + 1]

        # The 'y' value flips when inverted.
        is_inverse = Shape.is_inverse_triangle(r1, c1)

        # Both up and down use this function,
        # but down is the inverse of up.
        if self.is_down_type:
            is_inverse = not is_inverse

        return (x, y, x1, y1, x2, y) if is_inverse else (x, y1, x1, y, x2, y1)
