#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Base, Hat
from roller_one_extract import Render
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import colorsys
import gimpfu as fu

pdb = fu.pdb


class DropZone:
    """Has rotating rectangles colored by a gradient between two colors."""

    @staticmethod
    def do(o):
        """
        Draw the rotating rectangles.

        o: One
            Has variables.

        Return: layer or None
            with Drop Zone material
        """
        cat = Hat.cat

        # the id of the layer to return, 'z'
        z = None

        # Is a gradient that is created by a user option.
        grad = None

        # Drop Zone preset dict, 'd'
        d = o.d

        j = cat.render.image

        if d[ok.OPACITY]:
            # the selection rectangle's dimension, 'w' and 'h'
            w, h = Render.size()

            steps = d[ok.STEPS_DROP_ZONE]
            color, color1 = d[ok.COLOR_1], d[ok.COLOR_2]
            mod_w = w / steps / 2.
            mod_h = h / steps / 2.

            if d[ok.INVERT]:
                color = RenderHub.invert_color(color)
                color1 = RenderHub.invert_color(color1)

            # Sort the colors based on their luminosity.
            lum = colorsys.rgb_to_hls(*color)[1]
            lum1 = colorsys.rgb_to_hls(*color1)[1]

            if lum < lum1:
                color, color1 = color1, color

            if d[ok.REVERSE]:
                color, color1 = color1, color

            # RGB of int, 'step'
            # Is added to the start color once per iteration.
            step = RenderHub.calc_gradient(color, color1, steps)

            # backdrop image layer, 'z'
            z = Lay.clone(o.z)

            # Is the previous layer with fill material.
            z1 = None

            # group key, 'o.k'
            group = Lay.group(j, o.k, layer=z)

            # the selection rectangle's topleft coordinate, 'x' and 'y'
            x = y = 0

            # RGB, of int, 'q'
            q = color

            keep = d[ok.KEEP_GRADIENT]

            # There's no need to clip the previous
            # fill if the opacity is always 100%.
            is_clip = d[ok.START_OPACITY] != 100. or d[ok.END_OPACITY] != 100.

            if keep:
                # Make a unique gradient name.
                gradients = Hat.cat.gradient_list

                # gradient name, 'n'
                n = d[ok.NAME]

                if n in gradients:
                    n = Base.enumerate_name(n, gradients)

                # Create a gradient with evenly spaced
                # segments, one for each color.
                grad = pdb.gimp_gradient_new(n)
                pdb.gimp_gradient_segment_range_split_uniform(
                    grad,
                    0,
                    0,
                    steps
                )

            opacity = d[ok.START_OPACITY]
            opacity_step = (d[ok.END_OPACITY] - opacity) / (steps - 1)

            for i in range(steps):
                # Set the 'Sel.fill' function's input to the correct format.
                # tuple of integers, RGB
                q1 = tuple([int(i1) for i1 in q])

                if keep:
                    # gradient, segment index, color, opacity
                    # The opacity value has to be rounded
                    # as it will overflow with float-sum (i.e. 100.00000007).
                    arg = grad, i, q1, round(opacity, 1)

                    # The start and end color is the same for a segment.
                    pdb.gimp_gradient_segment_set_left_color(*arg)
                    pdb.gimp_gradient_segment_set_right_color(*arg)

                if w >= 1 and h >= 1:
                    Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
                    Sel.fill(z, q1)

                    if z1 and is_clip:
                        Sel.item(z)
                        Lay.clear_sel(z1)

                    z.opacity = round(opacity, 1)
                    z1 = z

                # Define the next rectangle.
                x += mod_w
                y += mod_h
                w -= (mod_w * 2)
                h -= (mod_h * 2)

                # Add the step color's RGB components to the color.
                q = [i1 + step[x1] for x1, i1 in enumerate(q)]

                # Add a new layer for the opacity changes.
                z = Lay.add_above(z, o.k + " " + str(i + 1))

                # The opacity value steps not unlike the color values.
                opacity += opacity_step

            z = Lay.merge_group(group)
            z.mode, z.opacity = RenderHub.get_mode(d)

            Lay.clone(o.z)

            z = Lay.merge(z)
            z = RenderHub.bump(z, d[ok.BUMP])

        # Create a gradient if the user desires.
        if grad and d[ok.KEEP_GRADIENT]:
            # Store image gradients so they can
            # be deleted before the program closes.
            Hat.cat.image_gradients_created.append(grad)

            # This gradient is kept. The gradient is
            # saved to a file when GIMP closes.
            Hat.cat.image_gradient_used = grad

        # Return the Drop Zone backdrop-style layer for the undo function.
        return z
