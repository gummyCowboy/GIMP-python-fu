#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub, PROFILE
import gimpfu as fu

pdb = fu.pdb
um = Fu.UnsharpMask


def adjust_opacity(z):
    """
    For a given layer, adjust its material-only, alpha channel
    mean intensity value, to be above a threshold (225).

    z: layer
        with material to adjust

    Return: layer, Selection state
        with material
    """
    j = z.image

    # the mean intensity value, 'f'
    f = 0

    while f < 225.:
        # Create a selection-mask.
        Sel.item(z)

        if Sel.is_sel(j):
            # Get the mean intensity value of the material's alpha, 'f'.
            f = pdb.gimp_drawable_histogram(
                z, fu.HISTOGRAM_ALPHA, .0, 1.
            )[0]
            if f < 225.:
                # double-down
                z = Lay.clone(z)
                z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        else:
            break
    return z


def process_layer(j, image_layer, o):
    """
    Add frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    d = o.d
    parent = image_layer.parent
    z = Lay.add(j, Lay.name(parent, o.k), parent=parent)
    z1 = Lay.clone(image_layer)
    color = d[ok.COLOR]
    w = d[ok.FRAME_WIDTH]
    q = PROFILE[d[ok.PROFILE]](w, *(color,))

    Sel.make_layer_sel(z1)
    RenderHub.draw_color_profile(z, w, q, color)
    j.remove_layer(z1)

    n = d[ok.NOISE_MODE]

    if n != "None" and d[ok.NOISE_OPACITY]:
        z1 = Lay.clone(z)
        z1.opacity = d[ok.NOISE_OPACITY]
        z1.mode = bs.NOISE_LAYER_MODE[bs.NOISE_MODE_LIST.index(n)]

        pdb.plug_in_plasma(
            j, z1,
            d[ok.RANDOM_SEED],
            Fu.Plasma.LOWEST_TURBULENCE
        )
        Sel.item(z)
        Sel.invert_clear(z1)

        if n == bs.SYRUPY:
            pdb.plug_in_unsharp_mask(
                j, z1,
                um.RADIUS_5,
                um.AMOUNT_1,
                um.THRESHOLD_0
            )

        elif n == bs.CARTOONY:
            z = RenderHub.do_cartoony(z, z1, color)
        if n != bs.CARTOONY:
            z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

    z = adjust_opacity(z)
    z = GradientLight.apply_light(z, ok.OTHER_FRAME)
    return z


class ColorPipe:
    """Create a frame with a custom profile and color."""

    @staticmethod
    def do(o):
        """
        Do the image-effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer
            with Color Pipe
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # 'undo_z' is a list of layers for the preview's undo function.
        undo_z = []
        o.shadow_layer = [z]

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], o)]

        else:
            undo_z = process_layer(j, z, o)
            if undo_z:
                o.shadow_layer = [undo_z, z]
        return undo_z
