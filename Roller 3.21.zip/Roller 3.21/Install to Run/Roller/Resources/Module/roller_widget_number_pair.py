#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import sqrt
from random import uniform
from roller_constant_for import Widget as fw, MAX_SIZE
from roller_constant_key import Widget as wk
from roller_one import Base, Hat
from roller_one_extract import Factor, Render
from roller_one_tip import Tip
from roller_widget_label import Label
from roller_widget_slider import Slider
import gtk
import gobject


class NumberPair(gtk.Alignment, gobject.GObject):
    """
    Is an GTK HBox with two Sliders.

    The widget value is a tuple for storage.
    Use 'get_net_value' to get the value represented by the pair.
    """
    # for OptionGroup's change subscription
    change_signal = fw.UI_CHANGE

    # a custom signal for change notification
    __gsignals__ = {
        fw.UI_CHANGE: (
            gobject.SIGNAL_RUN_LAST,
            None,
            (gobject.TYPE_PYOBJECT,)
        )
    }

    def __init__(self, **d):
        """
        Create an HBox with some buttons.

        d: dict
            Has init values.
            Has a key, Widget.KEY, which is a pair of label descriptor values.
        """
        # for custom signal(s)
        gobject.GObject.__init__(self)

        # Init for a on-change-response timing issue.
        self._factor_slider = None
        self._limit = 0, 0

        # widget attributes
        self.label = None
        self.win = d[wk.WIN]
        self.path = d[wk.PATH]
        self.group = d[wk.GROUP]
        self.key = d[wk.KEY]

        # unique to this widget
        self.is_x_axis = d[wk.AXIS] == 'x'

        # Use to return the correct type for the net value.
        self._is_int = False
        self._precision = 0

        super(gtk.Alignment, self).__init__()

        # The type can be either an int or a float with a variable precision.
        if wk.PRECISION not in d:
            self._is_int = True

        else:
            self._precision = d[wk.PRECISION]

        # Create a relay.
        self._callback = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self.on_change

        hbox = gtk.HBox()
        d[wk.ALIGN] = 0, 0, 1, 0

        # fixed-value Slider
        # Can be an integer or a float.
        d[wk.KEY] = wk.FIXED
        d[wk.TIP] = d[wk.TIPS][0] if wk.TIPS in d else ""
        g = self._fixed_slider = Slider(**d)

        # The factor Slider value is a fraction of a
        # context size, for instance, the render size.
        d[wk.KEY] = wk.FACTOR
        d[wk.PRECISION] = 6
        d[wk.LIMIT] = self._random_range = (.0, 1.) if self._limit[0] >= 0 \
            else (-1., 1.)

        d[wk.TIP] = d[wk.TIPS][1] if wk.TIPS in d else ""
        g1 = self._factor_slider = Slider(**d)

        # value Label
        # Display the net value.
        d[wk.KEY] = wk.LABEL
        d[wk.TEXT] = " 0"
        d[wk.TIP] = " Is the net value. "
        g2 = self._value_label = Label(**d)

        for i in (g, g1, g2):
            hbox.pack_start(i, expand=0)

        self.add(hbox)

        if len(self.group.path) >= 3:
            self._model_number = self.group.path[:3][-1]

        else:
            # not a sub-model widget
            self._model_number = None
        self._parent_type = self.group.parent_type

    def _get_net_label(self):
        """
        Make a string for the net value label.
        Match the string descriptor with the type of the fixed value.
        """
        return " " + str(self.get_net_value())

    def on_change(self, g):
        """
        Respond to change in one of the sliders.

        g: Slider
            Could be either one.
            no use
        """
        if self._factor_slider:
            self._value_label.set_label_value(self._get_net_label())
            self._callback(self)
            self.emit(fw.UI_CHANGE, self.group)

    def hide(self):
        """Hide the Buttons and its attached Label."""
        super(gtk.Alignment, self).hide()
        if self.label:
            if self.label.widget.get_visible():
                self.label.widget.hide()

    def get_net_value(self):
        """
        Calculate the net value of the two sliders.

        Return: numeric
            same type as the fixed value
        """
        q = self.get_value()
        a = q[0] + Factor.calc_factor(q[1], self._limit[1])
        a = Base.seal(self._limit[0], a, self._limit[1])

        if self._is_int:
            a = int(a)
        return a

    def get_value(self):
        """
        Get the values of the two sliders.

        Return: tuple
            (fixed value, factor value)
        """
        # Is called during the init.
        if self._factor_slider:
            return (
                self._fixed_slider.get_value(),
                self._factor_slider.get_value()
            )
        return 0, 0

    def set_value(self, a):
        """
        Set the value of the Sliders. A retro numeric value is acceptable.

        a: numeric or tuple
            the value to apply to the Sliders
            If the value is numeric, then the fixed value slider
            is set to 'a', and the factored value slider is set to zero.
        """
        if isinstance(a, tuple):
            self._fixed_slider.set_value(a[0])
            self._factor_slider.set_value(a[1])

        else:
            # for previous Roller version
            if isinstance(a, int):
                self._fixed_slider.set_value(a)
                self._factor_slider.set_value(.0)
            else:
                # float
                self._fixed_slider.set_value(0)
                self._factor_slider.set_value(a)
        self._value_label.set_label_value(self._get_net_label())

    def show(self):
        """Show the Buttons and its attached Label."""
        super(gtk.Alignment, self).show()
        if self.label:
            if not self.label.widget.get_visible():
                self.label.widget.show()

    def subscribe(self):
        """
        Create connections for the widget.

        p: function
            to call on change
        """
        self.connect(
            self.change_signal,
            Hat.dog.signal_filter.add_group,
            self.group
        )

    def update_net_label(self):
        """
        Update the net value label on a dependency change.
        """
        self._value_label.set_label_value(self._get_net_label())


class CanvasPair(NumberPair):
    """
    Use with canvas space dependent options.
    Update the net value label on render size change.
    """

    def __init__(self, **d):
        """
        Manifest the enable scale widget.

        d: dict
            Has keyword, value pairs.
        """
        d[wk.LIMIT] = 0, MAX_SIZE

        if d[wk.AXIS] == 'x':
            d[wk.TIPS] = d[wk.TIPS][0], Tip.FACTOR_CANVAS_W

        else:
            # 'y'
            d[wk.TIPS] = d[wk.TIPS][0], Tip.FACTOR_CANVAS_H

        NumberPair.__init__(self, **d)
        Hat.dog.signal_filter.connect(
            fw.RENDER_SIZE_CHANGE,
            self._on_render_size_change
        )

        # Force the update to the net label.
        self._on_render_size_change()

    def _on_render_size_change(self, *_):
        """
        Update the widget on a render size change.
        The net value label's limit is effected.
        """
        w, h = Render.size()
        self._limit = (0, w - 1) if self.is_x_axis else (0, h - 1)
        self.update_net_label()

    def randomize(self):
        """Get a random value for the NumberPair."""
        self.set_value((
            0,
            uniform(self._random_range[0], self._random_range[1])
        ))


class RectPair(NumberPair):
    """
    Use with cell rectangle size options.
    Update the net value label on render size change.
    """

    def __init__(self, **d):
        """
        Manifest the enable scale widget.

        d: dict
            Has keyword, value pairs.
        """
        if d[wk.AXIS] == 'x':
            d[wk.TIPS] = d[wk.TIPS][0], Tip.FACTOR_W

        else:
            # 'y'
            d[wk.TIPS] = d[wk.TIPS][0], Tip.FACTOR_H

        NumberPair.__init__(self, **d)
        Hat.dog.signal_filter.connect(
            fw.RENDER_SIZE_CHANGE,
            self._on_render_size_change
        )

        # Force the update to the net label.
        self._on_render_size_change()

    def _on_render_size_change(self, *_):
        """
        Update the net value label on render size change.
        """
        w, h = Render.size()
        self._limit = (1, w) if self.is_x_axis else (1, h)
        self.update_net_label()


class RenderPair(NumberPair):
    """
    Use with render size dependent options.
    Update the net value label on render size change.
    """

    def __init__(self, **d):
        """
        Manifest the enable scale widget.

        d: dict
            Has keyword, value pairs.
        """
        a = d[wk.TIPS][0] if wk.TIPS in d else ""

        if d[wk.AXIS] == 'x':
            d[wk.TIPS] = a, Tip.FACTOR_W

        elif d[wk.AXIS] == 'y':
            # 'y'
            d[wk.TIPS] = a, Tip.FACTOR_H

        else:
            # 'xy'
            d[wk.TIPS] = a, Tip.FACTOR_SIZE

        self.is_y_axis = d[wk.AXIS] == 'y'

        NumberPair.__init__(self, **d)
        Hat.dog.signal_filter.connect(
            fw.RENDER_SIZE_CHANGE,
            self._on_render_size_change
        )

        # Force the update to the net label.
        self._on_render_size_change()

    def _on_render_size_change(self, *_):
        """
        Update the net value label on render size change.
        """
        w, h = Render.size()

        if self._limit[0] == 0:
            if self.is_x_axis:
                self._limit = (0, w)

            elif self.is_y_axis:
                self._limit = (0, h)
            else:
                self._limit = (0, sqrt(w * h))

        else:
            self._limit = (-w, w) if self.is_x_axis else (-w, h)
        self.update_net_label()


# Register the custom signal.
gobject.type_register(NumberPair)
