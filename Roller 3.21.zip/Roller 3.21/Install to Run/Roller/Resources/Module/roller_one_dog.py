#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import GroupId
from roller_option import Option
from roller_render_plan import Plan
from roller_render_product import Product
from roller_render_view import View


class Dog(object):
    """
    Use to initialize classes during program start and
    reduce circular import reference errors.
    Reference class instance variables from 'Hat.dog'.
    """

    def __init__(self):
        """Initialize global access variables."""

        # GroupId is encodes grid and custom cell names.
        self.group_id = GroupId()

        # Only one Option object is
        # needed through-out the program.
        self.option = Option()

        # Use when drawing plans.
        self.plan = Plan()

        # Use this class instance to render.
        self.product = Product()

        # Use to stockpile signals, and the reduce them.
        self.signal_filter = None

        # Use to manage render preview.
        self.viewer = View()
