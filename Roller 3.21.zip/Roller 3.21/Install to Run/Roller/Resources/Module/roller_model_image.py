#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Image as fi
from roller_constant_key import Image as ik, Option as ok
from roller_one import Comm, Hat, One, Rect
from roller_one_extract import Form
from roller_one_fu import Lay, Mage, Sel
from roller_one_rect_table import RectTable
import gimp
import gimpfu as fu
import os

pdb = fu.pdb
sk = fk = CellKey = fck = ok

CROP = " (Crop)"
LOAD_ERR = \
    "Roller tried to load an image file:\n'{}'\n and an error occurred."

NONE_ERR = "Roller will use a 'None' image reference for the file."
READ_ERR = "Roller tried to read from a folder:\n'{}'\n and an error occurred."


def add_image(j, q, k, layer_name=None):
    """
    Add a GIMP image to the Image collection.

    j: GIMP image
        to be given a Image

    q: list
        of layers
        Use with 'As Layers'.

    k: string or tuple
        a file path string or
        (image name, layer name)

    layer_name: string
        Use to describe image.

    Return: Image
        the corresponding Image
    """
    j1 = Image.opened_images[k] = Image(
        j,
        k,
        layer_name=layer_name
    ), q
    j1[fi.IMAGE_INDEX].path = k
    return j1[fi.IMAGE_INDEX]


def copy_layer(z):
    """
    Copy a layer from an image.

    z: layer
        to copy

    Return: GIMP buffer state
        copy of layer
    """
    j = z.image
    q = hide_all_but_one(j, z, [])
    q1 = ensure_visible(z, [])

    if not z.visible:
        pdb.gimp_item_set_visible(z, 1)
        q1.append(z)

    Mage.copy_all(j)

    # Restore visibility state.
    for i in q:
        Lay.show(i)
    for i in q1:
        Lay.hide(i)


def ensure_visible(z, q):
    """
    Ensure a layer to visible. If it part
    of a tree, then the branches need to
    be visible.

    Is recursive.

    z: layer
        to be made visible

    q: list
        Layers made visible.

    Return: list
        Layers made visible.
    """
    if hasattr(z, 'parent'):
        if z.parent and not z.parent.visible:
            Lay.show(z.parent)
            q.append(z.parent)
            q = ensure_visible(z.parent, q)
    return q


def get_circulated_image(j, d, e, n):
    """
    If needed, get an image's decomposed and/or slice image.
    Otherwise, the image is an already created Image.

    If the image is decomposed or sliced, then
    poll the 'get_layer_image' function until it
    retrieves a sub-image. The polling process will
    rollover or circulate the sub-images.

    j: Image
        Is the source of layers and slices.

    d: dict
        of image choice

    e: dict
        of image index

    n: string
        an image name

    Return: Image or None
        None is a code failure.
    """
    if d[ok.AS_LAYERS] or d[ok.SLICE]:
        x = 0
        x1 = Image.image_count + len(Image.opened_images)
        j1 = None

        while j1 is None:
            j1 = get_layer_image(j, d, e, n)
            x += 1

            # fail-safe
            if x == x1:
                break
        j = j1

    else:
        j = get_layer_image(j, d, e, n)
    return j


def get_file(d, e):
    """
    Validate a file path.

    d: dict
        of image choice

    e: dict
        image index

    n: string
        file path

    Return: Image or None
        an opened image
    """
    n = d[ok.FILE]
    n = n if n and os.path.isfile(n) else None
    if n:
        j = get_file_from_path(d, n)
        return get_circulated_image(j, d, e, n)


def get_file_from_path(_, n):
    """
    Get an Image for a file path.

    Will open a file.

    _: dict
        of image choice

    n: string
        file path

    Return: Image or None
        corresponding with an opened image
    """
    j = None

    # If the image is already opened, then don't re-open.
    if image_is_open(n):
        j = Image.opened_images[n][fi.IMAGE_INDEX]

    else:
        try:
            j1 = pdb.gimp_file_load(n, n)
            j = add_image(j1, [], n)
        except Exception as ex:
            Comm.info_msg(LOAD_ERR).format(n)
            Comm.info_msg("The error was:\n" + repr(ex))
            Comm.info_msg(NONE_ERR)
    return j


def get_folder_file_ref(d, image_index):
    """
    Return a file path string from an indexed-file of a folder path.

    d: dict
        of image choice

    Return: Image or None
        from a folder
    """
    def calc_next():
        """
        Update the folder file indices.

        Return: int
            the next index
        """
        # top, bottom
        x_, x1_ = image_index[k]

        if d[ok.FOLDER_ORDER]:
            # descending
            x1_ -= 1
            x2_ = x1_

        else:
            # ascending
            x_ += 1
            x2_ = x_

        image_index[k] = x_, x1_
        return x2_

    # Begin.
    e = Image.folder_pile
    n = d[ok.FOLDER]
    n1 = d[ok.FILTER]
    j = None
    k = n, n1
    file_list = []

    if n and os.path.isdir(n):
        if k in e:
            file_list = e[k]
        if k not in e:
            try:
                for _file in os.listdir(n):
                    ext = os.path.splitext(_file)[1]
                    if ext.lower() in fi.EXTENSION:
                        if n1:
                            if n1 not in _file:
                                continue
                        file_list.append(os.path.join(n, _file))
                e[k] = file_list = sorted(file_list)
            except Exception as ex:
                Comm.info_msg(READ_ERR.format(n))
                Comm.info_msg("The error was:\n" + repr(ex))
                Comm.info_msg(NONE_ERR)

    # Initialize.
    if k not in image_index:
        # ascending and descending indices
        image_index[k] = 0, len(file_list) - 1

    top_x, bottom_x = image_index[k]
    x = bottom_x if d[ok.FOLDER_ORDER] else top_x

    # Is the index valid?
    if len(file_list) > x > -1:
        d1 = Image.opened_images
        n = file_list[x]
        j = get_file_from_path(d, n)

        if d[ok.AS_LAYERS] or d[ok.SLICE]:
            j = get_layer_image(d1[n][fi.IMAGE_INDEX], d, image_index, n)
            while j is None:
                x = calc_next()
                n = file_list[x] if len(file_list) > x > -1 else None
                if n:
                    # Ensure that the file is loaded.
                    if get_file_from_path(d, n):
                        j = get_layer_image(
                            d1[n][fi.IMAGE_INDEX],
                            d,
                            image_index,
                            n,
                            is_start=True
                        )
                    else:
                        break
                else:
                    break
        else:
            calc_next()
    return j


def get_image_by_name(d, e):
    """
    Validate an image reference from opened images.

    d: dict
        of image choice

    e: dict
        image index
        unused

    Return: string or None
        image reference
    """
    n = d[ok.IMAGE_NAME]
    n1 = None
    q = Image.image_names

    if n != "None" and n in q:
        x = q.index(n)
        n1 = Image.image_names[x]
    if n1:
        j = Image.roller_image[n1]
        return get_circulated_image(j, d, e, n1)


def get_last_layer(d, d1, k):
    """
    Get the last-used layer.

    d: dict
        image choice

    d1: dict
        of image index

    k: string or tuple
        image key

    Return: tuple
        (layer or None, list of layers)
    """
    e = Image.opened_images
    j = None
    q = []
    n = k

    if image_is_open(k):
        q = e[k][fi.LAYER_LIST_INDEX]
        if k in d1:
            top_x, bottom_x = d1[k]
            x = top_x if d[ok.LAYER_ORDER] else bottom_x
            if len(q) > x > -1:
                z = e[k][fi.LAYER_LIST_INDEX][x]
                n = k, z.name
                if n in e:
                    j = e[n][fi.IMAGE_INDEX]
    return j, q, n


def get_layer_image(j, d, d1, n, is_start=False):
    """
    Get a layer image if it is still available.
    There are four conditional outcomes controlled by:
        +/- decompose (as layers)
        +/- slice

    j: Image or None
        work-in-progress

    d: dict
        of image choice

    d1: dict
        of image index

    n: string or tuple
        image name or (image name, filter)
        key for the opened image dict

    is_start: bool
        If it is true, the layer index is set
        to the beginning of a layer retrieval.

    Return: Image or None
        from layer or unchanged
    """
    if j and d[ok.AS_LAYERS]:
        if d[ok.SLICE]:
            e = Image.opened_images
            j1 = j
            k = n
            j, q, n = get_last_layer(d, d1, k)
            j = slice_it(j, d, d1, n)
            x = 0
            while j is None:
                j, n, is_start = get_next_layer(j1, d, d1, k, is_start)

                if not j:
                    break

                else:
                    if k in e and not q:
                        q = e[k][fi.LAYER_LIST_INDEX]

                    j = slice_it(j, d, d1, n)
                    x += 1
                    if x >= len(q):
                        break
        else:
            j, n, is_start = get_next_layer(j, d, d1, n, is_start)

    elif j and d[ok.SLICE]:
        j = slice_it(j, d, d1, n)
    return j


def get_layers(z):
    """
    Collect a list of layers belonging to an image.
    Group layers are excluded.

    Is recursive.

    z: GIMP image or layer
        Has layers.

    q: list
        of layers

    Return: list
        of layers
    """
    q = []

    for z1 in z.layers:
        if pdb.gimp_item_is_group(z1):
            # recursive
            q = get_layers(z1)
        else:
            q.append(z1)
    return q


def get_loop_image(d, e):
    """
    Get an open image reference with the loop index.

    d: dict
        of image choice

    e: dict
        of image index
        for image allocation

    Return: Image or None
        an open image
    """
    def calc_loop():
        """Calculate the next loop index."""
        # Initialize.
        if d[ok.LOOP_INDEX] == 0:
            e[ik.LOOP] += 1

            # positive rollover
            if e[ik.LOOP] >= a.image_count:
                e[ik.LOOP] = 0
        else:
            e[ik.LOOP] -= 1

            # negative rollover
            if e[ik.LOOP] < 0:
                e[ik.LOOP] = a.image_count - 1

    a = Image
    b = a.image_names
    e = e[ik.LOOP_DICT]
    j = None

    if a.image_count:
        d1 = a.roller_image

        # Initialize.
        if e[ik.LOOP] < 0:
            e[ik.LOOP] = 0 if d[ok.LOOP_INDEX] == 0 else a.image_count - 1

        if d[ok.AS_LAYERS] or d[ok.SLICE]:
            n = b[e[ik.LOOP]]
            j = get_layer_image(d1[n], d, e, n)
            x = 0
            while j is None:
                calc_loop()
                n = b[e[ik.LOOP]]
                j = get_layer_image(d1[n], d, e, n, is_start=True)
                x += 1
                if x > a.image_count:
                    break
        else:
            n = b[e[ik.LOOP]]

            if n in d1:
                j = d1[n]
            calc_loop()
    return j


def get_next_image(d, e):
    """
    Get the next image with the 'next' index.

    d: dict
        of image choice

    e: dict
        of image index

    Return: Image or None
        the next open image
    """
    def calc_next():
        """
        Calculate the next next-type index.

        Return: string or None
            image name
        """
        e[ik.NEXT] += 1
        if d[ok.NEXT_INDEX] == 1:
            if e[ik.NEXT] >= a.image_count:
                e[ik.NEXT] = 0

    a = Image
    b = a.image_names
    j = None

    if a.image_count:
        e = e[ik.NEXT_DICT]
        d1 = a.roller_image
        n = b[e[ik.NEXT]] if e[ik.NEXT] < a.image_count else None

        if d[ok.AS_LAYERS] or d[ok.SLICE]:
            if n:
                j = get_layer_image(d1[n], d, e, n)
            while j is None:
                calc_next()

                n = b[e[ik.NEXT]] if e[ik.NEXT] < a.image_count else None

                if n:
                    j = get_layer_image(d1[n], d, e, n, is_start=True)
                else:
                    break
        else:
            if n:
                j = d1[n]
            calc_next()
    return j


def get_next_layer(j, d, d1, n, is_start):
    """
    Get a layer image if it is still available.
    There are four conditional outcomes controlled by:
        +/- decompose (as layers)
        +/- slice

    j: Image or None
        work-in-progress
        Has layer(s).

    d: dict
        of image choice

    d1: dict
        of image index

    n: string or tuple
        image name or (image name, filter)
        key for the opened image dict

    is_start: bool
        If it is true, the layer index is set
        to the beginning of a layer retrieval.

    Return: tuple
        (Image or None, string)
            from layer or unchanged, image key
    """
    def get_layer():
        """Get the next layer per the layer order."""
        k = n

        # Update the value of the opened image.
        e[n] = j, q

        top_x, bottom_x = d1[n]

        if d[ok.LAYER_ORDER]:
            # top-down
            if is_start:
                x = top_x = 0

            else:
                x = top_x = top_x + 1
            more = len(q) > x

        else:
            # bottom-up
            if is_start:
                x = bottom_x = len(q) - 1

            else:
                x = bottom_x = bottom_x - 1
            more = x > -1

        if more:
            # Get the layer.
            z = e[n][fi.LAYER_LIST_INDEX][x]
            k = n, z.name

            if image_is_open(k):
                j1 = e[k][fi.IMAGE_INDEX]

            else:
                copy_layer(z)

                j1 = pdb.gimp_edit_paste_as_new_image()
                j1 = add_image(j1, q, k, layer_name=z.name)
            d1[n] = top_x, bottom_x

        else:
            # Roll it over.
            d1[n] = -1, len(q)
            j1 = None
        return j1, k

    def init_image_index():
        """
        Initialize the image index for the image.

        d1: dict
            of image index

        Return: True
            for 'is_start'
        """
        d1[n] = -1, len(q)
        return True

    e = Image.opened_images

    if image_is_open(n):
        q = e[n][fi.LAYER_LIST_INDEX]

        if not q:
            # Re-initialize a file image.
            q = get_layers(j.j)
            is_start = init_image_index()

        else:
            if n not in d1:
                # from an undo
                init_image_index()
        j, n = get_layer()

    else:
        # Add an item to the layer pile.
        q = get_layers(j.j)

        init_image_index()

        j = add_image(j.j, q, n)
        j, n = get_layer()
    return j, n, is_start


def get_previous_image(d, e):
    """
    Get the previous opened image with the 'previous' index.

    d: dict
        of image choice

    e: dict
        of image index

    Return: Image or None
        the open previous image
    """
    def calc_previous():
        """Calculate the next previous-type index."""
        e[ik.PREVIOUS] = max(-1, e[ik.PREVIOUS] - 1)
        if d[ok.PREVIOUS_INDEX] == 1:
            # Previous-Circular
            if e[ik.PREVIOUS] < 0:
                e[ik.PREVIOUS] = Image.image_count - 1

    j = None
    b = Image.image_names
    e = e[ik.PREVIOUS_DICT]

    if Image.image_count:
        d1 = Image.roller_image

        # Initialize.
        if e[ik.PREVIOUS] == -2:
            e[ik.PREVIOUS] = len(Image.image_names) - 1

        n = b[e[ik.PREVIOUS]] if e[ik.PREVIOUS] >= 0 else None

        if d[ok.AS_LAYERS] or d[ok.SLICE]:
            if n:
                j = get_layer_image(d1[n], d, e, n)
            if j is None:
                calc_previous()

                n = b[e[ik.PREVIOUS]] if e[ik.PREVIOUS] >= 0 else None
                if n:
                    j = get_layer_image(d1[n], d, e, n, is_start=True)
        else:
            if n:
                j = d1[n]
            calc_previous()
    return j


def get_relative_name_ref(d, e):
    """
    Get an open image reference corresponding with a numeric index.

    d: dict
        of image choice

    e: dict
        of image index
        unused

    Return: Image or None
        an open image
    """
    n = d[ok.NUMERIC_SEQUENCE]
    n1 = None
    q = Image.relative_names

    if n != "None" and n in q:
        x = q.index(n)
        n1 = Image.image_names[x]
    if n1:
        j = Image.roller_image[n1]
        return get_circulated_image(j, d, e, n1)


def get_sliced_image(j, k, r, c):
    """
    Get a sliced image. The image may already exist.
    If it doesn't exist, create it from a rectangle
    selection defined from a slice table.

    j: Image
        with image material

    k: tuple
        an opened image key for a sliced image

    r, c: int
        slice index in slice table

    q: list
        of layers

    Return: Image
        the sliced image
    """
    # Drop the slice order attribute from the image key.
    if image_is_open(k[:-1]):
        # The image has already been created.
        j = Image.opened_images[k[:-1]][fi.IMAGE_INDEX]

    else:
        Mage.copy_all(j.j)

        temp_image = pdb.gimp_edit_paste_as_new_image()

        # Use the slice table made for the image to get
        # the rectangle, 'a', the size of the slice.
        # The table span is in the minus two position.
        k1 = j.size, k[-2][0], k[-2][1]
        a = get_slice_table(k1)[r][c]

        Sel.rect(temp_image, a.x, a.y, a.w, a.h, option=fu.CHANNEL_OP_REPLACE)
        pdb.gimp_edit_copy(temp_image.layers[0])

        j1 = pdb.gimp_edit_paste_as_new_image()

        pdb.gimp_image_delete(temp_image)

        # The layer name is for Caption.
        n = "{}, {}".format(r + 1, c + 1)

        if isinstance(k[0], tuple):
            # Add the layer name.
            n = "{}, ({})".format(k[0][1], n)
        j = add_image(j1, [], k[:-1], layer_name=n)
    return j


def get_slice_index(d, e, k):
    """
    Get the index to the next slice. Adjust the slice index.

    d: dict
        of image

    e: dict
        of image index

    k: tuple
        key to slice index

    Return: tuple
        cell index of int
        by row, column
    """
    d1 = e[ik.SLICE]

    if k in d1:
        r, c = d1[k]
        if d[ok.SLICE_ORDER]:
            c -= 1
            if c < 0:
                c = d[ok.COLUMN_SLICE] - 1
                r -= 1
                if r < 0:
                    # no more left
                    c = r
        else:
            c += 1

            if c == d[ok.COLUMN_SLICE]:
                c = 0
                r += 1
                if r == d[ok.ROW_SLICE]:
                    # no more left
                    r = c = -1

        if r == -1:
            # Remove the expired slice.
            d1.pop(k)
        else:
            d1[k] = r, c
    else:
        r, c = (d[ok.ROW_SLICE] - 1, d[ok.COLUMN_SLICE] - 1) \
            if d[ok.SLICE_ORDER] else (0, 0)
        d1[k] = r, c
    return r, c


def get_slice_table(k):
    """
    Get a slice table from the slice table pile dict.

    If the table isn't in the pile dict, then
    create a table and add it to the dict.

    k: tuple
        key to slice_table_pile
        (image size, row count, column count)

    Return: list
        a 2D slice table
    """
    d = Image.slice_table_pile

    if k not in d:
        d[k] = RectTable(*k).table
    return d[k]


def hide_all_but_one(z, z1, q):
    """
    Hide all the layers in the image.

    Is recursive.

    z: layer or GIMP image
        Is a branch.

    z1: layer
        layer not to hide

    q: list
        Layers that are hidden.

    return: list
        Layers that are hidden.
    """
    for z2 in z.layers:
        if not hasattr(z2, 'layers'):
            if z2.visible and z2.name != z1.name:
                pdb.gimp_item_set_visible(z2, 0)
                q.append(z2)
        else:
            # recursive
            q = hide_all_but_one(z2, z1, q)
    return q


def image_is_open(n):
    """
    Determine if a previously opened image is still open.

    n: string or tuple
        image key

    Return: bool
        Is true if the image is still open.
    """
    d = Image.opened_images

    if n in d:
        return pdb.gimp_image_is_valid(d[n][fi.IMAGE_INDEX].j)
    return False


def slice_it(j, d, d1, n):
    """
    Slice an image.

    j: Image
        to slice

    d: dict
        of image choice

    d1: dict
        of image index

    n: string
        image name

    Return: Image or None
        a slice
    """
    span = d[ok.ROW_SLICE], d[ok.COLUMN_SLICE]
    order = d[ok.SLICE_ORDER]
    k = n, span[0], span[1], order

    # Determine if more slices are available.
    r, c = get_slice_index(d, d1, k)

    if r == -1:
        j = None
    if j:
        k = n, r, c, span, order
        j = get_sliced_image(j, k, r, c)
    return j


class Image:
    """Use to manage an open image."""

    # the number of valid images
    image_count = 0

    # An open image already inside GIMP is assigned an Image.
    # The key is an image name from image names.
    # The value is an Image.
    roller_image = {}

    # valid image names
    image_names = []

    # numeric ordered
    relative_names = []

    # Has images opened from a file reference.
    # The key is a string for images before they are decomposed or sliced.
    # In this case, the file path is the key.
    #
    # For images that are decomposed but not sliced the key is a tuple:
    # (image_name str, layer_name str).
    #
    # For images that are sliced but not decomposed, the key is
    # (image_name, row_index, column_index).
    #
    # For images that are decomposed and sliced, the key is
    # (image_name, layer_name, row_index, column_index).
    #
    # The value is a tuple: (an Image, a layer list).
    opened_images = {}

    # Each folder that is in process has an item in "folder_pile".
    # The key is a string of folder path.
    # The value is a file list.
    # The file list is a list of file.
    # A file is a path strings found in the folder.
    folder_pile = {}

    # The key is a tuple:
    # (opened image name key, row slice count, column slice count).
    # The value is a RectTable.
    slice_table_pile = {}

    def __init__(self, j, n, layer_name=None):
        """
        Create a Image object from
        a corresponding open image.

        j: GIMP image or None
            Use None for dummy-usage.

        n: string
            image name
            Could be empty for dummy-usage.

        layer_name: string
            Use instead of image name to describe image source.
        """
        self.j = j
        self.image_name = n
        self.layer_name = layer_name
        self.path = None

        s = (j.width, j.height) if j else (0, 0)
        self.size = self.width, self.height = s

        # 'cell' is the cell rectangle without the margins.
        self.cell = Rect((0, 0), (0, 0))

        # 'pocket' is the cell rectangle with the margins included.
        self.pocket = Rect((0, 0), (0, 0))

        # 'mold' is the image rectangle for the image place.
        # Its value is computed by layout 'mold' functions.
        self.mold = Rect((0, 0), (0, 0))

    @staticmethod
    def close_image(j):
        """
        Close an opened file.

        j: Image
            opened but soon to be closed
        """
        if j and Hat.cat.is_close_file and j.path in Image.opened_images:
            pdb.gimp_image_delete(j.j)

    @staticmethod
    def get_image(d, image_index):
        """
        Get a Image object.

        d: dict
            of image choice

        image_index: dict
            for image-stream allocation

        Return: Image or None
            corresponding with an opened image
        """
        n = d[ok.IMAGE_SOURCE]
        image = IMAGE_RESOLVE[n](d, image_index)

        if image:
            if d[ok.AUTOCROP]:
                e = Image.opened_images
                j = image.j
                j1 = j2 = None
                n = image.image_name

                # The cropped image has its own key, 'k'.
                if isinstance(n, str):
                    k = image_name = n + CROP

                else:
                    k = image_name = n + ("Crop",)

                layer_name = image.layer_name + CROP if image.layer_name \
                    else None

                if d[ok.AS_LAYERS]:
                    k = image_name = (k, image.layer_name)

                # Check to see if the image has already been created.
                if image_is_open(k):
                    image = e[k][fi.IMAGE_INDEX]
                else:
                    pdb.gimp_selection_all(j)

                    if len(j.layers) > 1:
                        pdb.gimp_edit_copy_visible(j)
                        j = j1 = pdb.gimp_edit_paste_as_new_image()

                    # Begin copying the base layer.
                    z = j.layers[0]

                    Sel.item(z)

                    is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

                    if is_sel:
                        # Copy visible material.
                        Sel.rect(
                            j,
                            x, y,
                            x1 - x, y1 - y,
                            option=fu.CHANNEL_OP_REPLACE
                        )
                        pdb.gimp_edit_copy(z)
                        j2 = pdb.gimp_edit_paste_as_new_image()

                    # 'j1' or 'j2' are both candidates for an Image. 'image'
                    # is closed because it is replaced by the cropped image.
                    if j1 and j2:
                        pdb.gimp_image_delete(j1)
                        Image.close_image(image)
                        image = add_image(j2, [], image_name, layer_name)

                    elif j1:
                        Image.close_image(image)
                        image = add_image(j1, [], image_name, layer_name)
                    elif j2:
                        Image.close_image(image)
                        image = add_image(j2, [], image_name, layer_name)
        return image

    @staticmethod
    def get_image_for_cell(d, e, image_index, r, c, is_merge_cell):
        """
        Get the image for a grid cell.

        d: dict
            of image place, chunk

        e: dict
            of grid, chunk

        image_index: dict
            for image-stream allocation

        r, c: int
            cell index

        is_merge_cell: flag
            Is true when the cell grid's merge cells option is in play.

        Return: Image
            or None
        """
        go = True

        if is_merge_cell:
            if e[ok.PER_CELL][r][c] == (-1, -1):
                go = False
        if go:
            e = Form.get_form(One(d=d, r=r, c=c))[ok.IMAGE]
            return Image.get_image(e, image_index)

    @staticmethod
    def image_undo_end():
        """
        The changes are bundled.

        Call after placing images with a render or plan.
        """
        for _, j in Image.roller_image.items():
            if pdb.gimp_image_is_valid(j.j):
                pdb.gimp_image_undo_group_end(j.j)

    @staticmethod
    def image_undo_start():
        """
        Roll image changes into a ball.

        Call before placing images with a render or plan.
        """
        for _, j in Image.roller_image.items():
            pdb.gimp_image_undo_group_start(j.j)

    @staticmethod
    def make_image_list():
        """Collect related data for images."""
        # post-fix image number tuple
        q = pdb.gimp_image_list()[1][::-1]

        # GIMP has an image list.
        q1 = reversed(gimp.image_list())

        d = Image.roller_image
        q2 = Image.image_names = []

        for x, j in enumerate(q1):
            n = j.name + "-" + str(q[x])
            d[n] = Image(j, n)
            q2.append(n)

        # Use 'q2' to map the image numeric sequence to a name.
        Image.image_count = len(q2)

        for i in range(len(q2)):
            count = 1
            while count:
                count = q2.count(q2[i]) - 1
                if count:
                    x = q2.index(q2[i])
                    q2[x] += " (" + str(count) + ")"

        if not q2:
            q2.append("None")

        # numeric sequenced
        if Image.image_count:
            for i in range(len(q)):
                n = str(i + 1)
                a1 = i + 1

                if i == 0 or (a1 > 20 and a1 % 10 == 1):
                    c = n + "st"

                elif i == 1 or (a1 > 20 and a1 % 10 == 2):
                    c = n + "nd"

                elif i == 2 or (a1 > 20 and a1 % 10 == 3):
                    c = n + "rd"

                else:
                    c = n + "th"
                Image.relative_names.append(c + " Image")

        else:
            Image.relative_names.append("None")
        Image.image_undo_start()


IMAGE_RESOLVE = {
    ok.LOOP_INDEX: get_loop_image,
    ok.FILE: get_file,
    ok.FOLDER: get_folder_file_ref,
    ok.IMAGE_NAME: get_image_by_name,
    ok.NUMERIC_SEQUENCE: get_relative_name_ref,
    ok.NEXT_INDEX: get_next_image,
    "None": lambda *q, **d: None,
    ok.PREVIOUS_INDEX: get_previous_image,
}
