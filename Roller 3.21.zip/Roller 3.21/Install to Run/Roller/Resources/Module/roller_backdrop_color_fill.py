#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class ColorFill:
    """Fill the backdrop-image with a color."""

    @staticmethod
    def do(o):
        """
        Do the Color Fill backdrop-style.

        o: One
            Has variables.

        Return: layer or None
            with Color Fill
        """
        # Color Fill preset dict, 'd'
        d = o.d
        if d[ok.OPACITY]:
            # backdrop image, 'z'
            z = Lay.clone(o.z)

            # RGB, 'q'
            q = d[ok.COLOR]

            if d[ok.INVERT]:
                q = RenderHub.invert_color(q)

            x, y = RenderHub.get_render_points(d)[:2]

            # Preserve.
            foreground = pdb.gimp_context_get_foreground()

            RenderHub.set_fill_context(d)
            pdb.gimp_context_set_foreground(q)
            pdb.gimp_drawable_edit_bucket_fill(z, fu.FOREGROUND_FILL, x, y)

            # Restore.
            pdb.gimp_context_set_foreground(foreground)

            # Return the undo layer.
            return RenderHub.bump(z, d[ok.BUMP])
