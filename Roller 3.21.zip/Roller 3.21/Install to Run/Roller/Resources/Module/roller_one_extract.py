#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import sqrt
from roller_constant_for import (
    Grid as gr,
    Group as og,
    Shape as sh,
    Triangle as ft
)
from roller_constant_key import (
    Model as md,
    Option as ok,
    Path as pa,
    Step as sk,
    Widget as wk
)
from roller_one import Base, Hat, Rect
import math
import sys

RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP


def get_option_values(path):
    """
    Get the option values from the interface.

    path: tuple
        option group key

    Return: dict
        widget-key based dict with values loaded
    """
    d = {}

    # OptionGroup, 'a'
    a = Hat.cat.group_dict[path]

    # OptionGroup widget dict, 'e'
    e = a.d

    # option key, 'i' and its widget, 'g'
    for i, g in e.items():
        # The Preset widget is not part of the group.
        if i != wk.PRESET:
            d[i] = g.get_value()
    return d


class Path:
    """Organize path functions. These are step-key paths."""

    @staticmethod
    def get_cell_caption_chunk(path):
        """
        Get a cell caption dict of the chunk type.
        The chunk includes the per cell table.

        path: tuple
            of model

        Return: dict
            of cell caption chunk
        """
        return Path.get_dict_from_path(path[:3] + (pa.IMAGE, pa.CAPTION))

    @staticmethod
    def get_cell_caption_form(o):
        """
        Get a cell caption dict of the form type.

        o: One
            Has path (tuple), model (string), r, c (int).

        Return: dict
            of cell caption form
        """
        path = o.path
        path = path[:3] + (pa.IMAGE, pa.CAPTION)
        d = Path.get_dict_from_path(path)

        if o.model in md.ONE_CELL:
            return d

        q = d[ok.PER_CELL]
        return q[o.r][o.c] if q else d

    @staticmethod
    def get_cell_plaque(path):
        """
        Get a cell plaque chunk.
        A chunk has the source group and a per cell table.

        path: tuple
            of model

        Return: dict
            of cell plaque chunk
        """
        return Path.get_dict_from_path(path[:3] + (pa.CELL, pa.PLAQUE))

    @staticmethod
    def get_cell_margin(path):
        """
        Get a cell margin and its per cell table.

        path: tuple
            of model

        Return: dict
            of cell margin, with per cell table
        """
        return Path.get_dict_from_path(path[:3] + (pa.CELL, pa.MARGIN))

    @staticmethod
    def get_dict_from_path(path, add_per_cell=True):
        """
        Get a widget-key-based dict from a group of widgets.

        path: tuple
            of steps

        add_per_cell: bool
            When true, include the per cell table in the return dict.

        Return: dict
            of widget key, widget value pairs
        """
        d = get_option_values(path)

        # container for the option group, 'vbox'
        vbox = Hat.cat.group_dict[path].vbox

        if add_per_cell:
            # Include the per cell table.
            if hasattr(vbox, og.PER_CELL_GROUP):
                d[ok.PER_CELL] = vbox.per_cell_group.get_value()
        return d

    @staticmethod
    def get_global_d():
        """
        Get the global values in a dict.

        Return: dict
            of globals
        """
        return get_option_values(sk.GLOBAL)

    @staticmethod
    def get_layer_plaque(path):
        """
        Get a layer plaque dictionary.

        path: tuple
            Has grid.
        """
        return Path.get_dict_from_path(Path.make_layer_plaque_path(path))

    @staticmethod
    def get_grid_from_path(path, add_per_cell=True):
        """
        Get a widget-key-based grid dict.

        path: tuple
            of model
            Has to include grid id.

        add_per_cell: bool
            If it is true, the per cell table is added to the
            dictionary making the return dictionary a chunk-type.

        Return: dict
            of widget key, widget value pairs
            of grid
        """
        path = path[:3] + (pa.CELL, pa.GRID)
        e = Hat.cat.group_dict

        # OptionGroup, 'a'
        d = get_option_values(path)

        if add_per_cell:
            # Include the per cell table.
            path = Path.make_per_cell_path(path)
            if path in e:
                d[ok.PER_CELL] = e[path].d[ok.PER_CELL].get_value()
        return d

    @staticmethod
    def get_layer_margin(path):
        """
        Get a grid's layer margins.

        path: tuple
            of sub-steps

        Return: tuple
            top, bottom, left, right
            of int
        """
        return Form.calc_margin(
            Path.get_dict_from_path(
                path[:3] + (pa.LAYER, pa.MARGIN),
                add_per_cell=False
            ),
            *Render.size()
        )

    @staticmethod
    def get_model_name_list():
        """
        Get a list of model names corresponding with the models.
        """
        return Hat.cat.group_dict[sk.MODEL].d[ok.MODEL_LIST].get_value()

    @staticmethod
    def get_model_path_list():
        """
        Get a list of model paths corresponding with the models.

        Return: list
            of model paths
        """
        q = Hat.cat.group_dict[sk.MODEL].d[ok.MODEL_LIST].get_value()
        q1 = []

        for i in q:
            q1 += [sk.EFFECT + (Hat.dog.group_id.get_id(i),)]
        return q1

    @staticmethod
    def get_pile_from_path(path):
        """
        Get a widget-key-based Pile dict.

        path: tuple
            of model
            Has to include model id.

        Return: dict
            of widget key, widget value pairs
            of pile
        """
        return get_option_values(path[:3] + (pa.CELL, pa.PILE))

    @staticmethod
    def get_place_chunk(path):
        """
        Get an image place preset dict and its per cell table.

        path: tuple
            of model

        Return: dict
            of cell place form
        """
        return Path.get_dict_from_path(path[:3] + (pa.IMAGE, pa.PLACE))

    @staticmethod
    def get_place_form(o):
        """
        Get a cell place form.
        A form is the source dict or a dict from its per cell table.

        o: One
            Has path (tuple), model (string), r, c (int).

        Return: dict
            of cell place form
        """
        path = o.path[:3] + (pa.IMAGE, pa.PLACE)
        d = Path.get_dict_from_path(path)

        if o.model in md.ONE_CELL:
            return d

        q = d[ok.PER_CELL]
        return q[o.r][o.c] if q else d

    @staticmethod
    def get_property_dict(path):
        """
        Get the a property dict for a model. The Property
        option group is a standard to every model.

        Return: dict or None
            property dict
        """
        return Path.get_dict_from_path(
            path[:3] + (pa.PROPERTY,),
            add_per_cell=False
        )

    @staticmethod
    def get_rectangle_dict(path):
        """
        Get a custom cell rectangle dictionary.

        path: tuple
            Has custom cell model.
        """
        return Path.get_dict_from_path(
            path[:3] + (pa.CELL, pa.RECTANGLE),
            add_per_cell=False
        )

    @staticmethod
    def has_margin(d):
        """
        Determine if a cell has a cell margin.

        d: dict
            of margins, form

        r, c: int
            cell index

        Return: bool
            Is true if the margin dict has a value other than zero.
        """
        for a in d.values():
            if a:
                return True
        return False

    @staticmethod
    def make_place_path(path):
        """
        Make a path to an image place group.

        path: tuple
            of model

        Return: tuple
            path-key
        """
        return path[:3] + (pa.IMAGE, pa.PLACE)

    @staticmethod
    def make_cell_plaque_path(path):
        """
        Make a path to an cell plaque group.

        path: tuple
            of model

        Return: tuple
            path-key
        """
        return path[:3] + (pa.CELL, pa.PLAQUE)

    @staticmethod
    def make_grid_path(path):
        """
        Make a path to a grid group.

        path: tuple
            of sub-steps

        Return: tuple
            path-key
        """
        return path[:3] + (pa.CELL, pa.GRID)

    @staticmethod
    def make_layer_plaque_path(path):
        """
        Make a path to a layer plaque group.

        path: tuple
            of sub-steps

        Return: tuple
            path-key
        """
        return path[:3] + (pa.LAYER, pa.PLAQUE)

    @staticmethod
    def make_per_cell_path(path):
        """
        Create a path from a option group to its Per Cell group.

        Return: tuple
            the path to the option's attached Per Cell group
        """
        return path[:-1] + (path[-1] + ", Per Cell",)


class Form:
    """Organize functions that work with an option group dictionaries."""

    @staticmethod
    def calc_margin(d, w, h):
        """
        Return the margins after adding the fixed-value
        and the factor margins together.

        d: dict
            of margin

        w, h: int
            cell size or render size

        Return: list
            top, bottom, left, right
            of int
        """
        top = bottom = left = right = 0

        if d:
            top = Render.get_factor_h(d[ok.MARGIN_TOP])
            bottom = Render.get_factor_h(d[ok.MARGIN_BOTTOM])
            left = Render.get_factor_w(d[ok.MARGIN_LEFT])
            right = Render.get_factor_w(d[ok.MARGIN_RIGHT])

            # Compensate for margin overflow
            # by reserving one pixel for the image.
            if top + bottom >= h:
                top = h // 2
                bottom = h - top - 1
            if left + right >= w:
                left = w // 2
                right = w - left - 1
        return top, bottom, left, right

    @staticmethod
    def get_cell_rect(d):
        """
        Calculate a custom cell rectangle.

        d: dict
            of custom cell's rectangle
        """
        w, h = Render.size()
        return Rect(
            # position
            (
                d[ok.POSITION_X][0] + int(d[ok.POSITION_X][1] * w),
                d[ok.POSITION_Y][0] + int(d[ok.POSITION_Y][1] * h)
            ),
            # size
            (
                max(1, d[ok.CELL_WIDTH][0] + int(d[ok.CELL_WIDTH][1] * w)),
                max(1, d[ok.CELL_HEIGHT][0] + int(d[ok.CELL_HEIGHT][1] * h))
            )
        )

    @staticmethod
    def get_form(o):
        """
        Get the form dictionary, source or per cell.

        o: One
            Has d, a preset dict, chunk or form.
            Has r, c, int, cell index.

        Return: dict
            the preset for the cell, form-type
        """
        d = o.d
        if ok.PER_CELL in d and d[ok.PER_CELL]:
            return d[ok.PER_CELL][o.r][o.c]
        return d

    @staticmethod
    def get_image_rotate(o):
        """
        Get the rotation value from image place chunk.

        o: One
            Has d, a preset dict, chunk or form.
            Has r, c, int, cell index.

        Return: float
            the image rotation for the cell
        """
        return Form.get_form(o)[ok.ROTATE]


class Shape:
    """Organize functions related to cell and mask shape."""

    @staticmethod
    def bounds(a):
        """
        Return the bounds of a shape.

        a: iterable or dict
            The iterable has x, y numeric pairs.
            The dict of an ellipse has x, y, w, h.

        Return: tuple
            x, y, w, h
            the bounds of the shape
        """
        if isinstance(a, dict):
            return a['x'], a['y'], a['w'], a['h']
        else:
            min_x = min_y = sys.maxint
            max_x = max_y = -sys.maxint

            for x, i in enumerate(a):
                if not x % 2:
                    min_x = min(i, min_x)
                    max_x = max(i, max_x)
                else:
                    min_y = min(i, min_y)
                    max_y = max(i, max_y)
            return min_x, min_y, max_x - min_x, max_y - min_y

    @staticmethod
    def calc_hexagon_regular_offset(w, h):
        """
        Calculate offsets of a regular hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            offsets
        """
        return w / 2, h / 4, h / 2, h / 4 * 3

    @staticmethod
    def calc_hexagon_regular_shape(x, y, w, h, q):
        """
        Calculate offsets of a vertical hexagon.

        w, h: numeric
            rectangle

        q: tuple
            of offsets

        Return: tuple
            of shape
            for the select polygon function
        """
        w1, h1, _, h2 = q
        # The first point is the topleft.
        # The points connect in a clockwise placement.
        return (
            x, y + h1,
            x + w1, y,
            x + w, y + h1,
            x + w, y + h2,
            x + w1, y + h,
            x, y + h2
        )

    @staticmethod
    def calc_hexagon_truncated_offset(w, h):
        """
        Calculate offsets of a truncated hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            offsets
        """
        return w / 4, w / 2, w / 4 * 3, h / 2

    @staticmethod
    def calc_hexagon_truncated_shape(x, y, w, h, q):
        """
        Calculate shape of a truncated hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            of x, y pairs
            for the select polygon function
        """
        # 'w2' is not used.
        w1, w2, w3, h1 = q

        # The first point is the topleft.
        # The points connect clockwise.
        return (
            x, y + h1,
            x + w1, y,
            x + w3, y,
            x + w, y + h1,
            x + w3, y + h,
            x + w1, y + h,
        )

    @staticmethod
    def calc_horizontal_ellipse(rect):
        """
        Calculate the rectangle shape for a horizontal ellipse.

        rect: Rect
            bounding rectangle for an ellipse

        Return: dict
            with shape
        """
        h = int(round(rect.h * sh.ELLIPSE_RATIO))
        return {'x': rect.x, 'y': rect.y, 'w': rect.w, 'h': rect.h - h}

    @staticmethod
    def calc_lock(s, t):
        """
        Return the size of an image that will fit into a smaller cell.

        s: tuple
            of int
            cell size
            (w, h)
            Conform image size to this size.

        t: tuple
            of int
            image size
            (w, h)
        """
        w_r = float(t[0]) / s[0]
        h_r = float(t[1]) / s[1]

        if w_r > h_r:
            w, h = s[0], int(t[1] * (s[0] / float(t[0])))

        else:
            w, h = int(t[0] * (s[1] / float(t[1]))), s[1]
        return max(w, 1), max(h, 1)

    @staticmethod
    def calc_octagon_side_to_side_offset(w, h):
        """
        Calculate the offsets of a side-to-side octagon using a ratio.

        w, h: numeric
            size of cell

        Return: tuple
            of offsets
        """
        # Use ratio.
        w1 = int(w * sh.OCTAGON_RATIO)
        w2 = w - w1
        h1 = int(h * sh.OCTAGON_RATIO)
        h2 = h - h1
        return w1, w2, h1, h2

    @staticmethod
    def calc_octagon_side_to_side_shape(x, y, w, h, q):
        """
        Calculate the shape of an align octagon using a ratio.

        x, y, w, h: float
            Defines rectangle.

        q: tuple
            of offsets for points

        Return: tuple
            of x, y pairs
            for select polygon function
        """
        w1, w2, h1, h2 = q

        # The first point is topleft.
        # The direction is clockwise.
        return (
            x + w1, y,
            x + w2, y,
            x + w, y + h1,
            x + w, y + h2,
            x + w2, y + h,
            x + w1, y + h,
            x, y + h2,
            x, y + h1
        )

    @staticmethod
    def calc_octagon_offset(w, h):
        """
        Calculate the offsets of a non-align octagon.

        w, h: numeric
            size of cell

        Return: tuple
            of offsets
        """
        # of cell rectangle
        radius = Base.circumradius(w, h)

        w1 = w / 2.
        h1 = h / 2.
        angle = math.asin(h1 / radius)

        # The process for 'w2' is deliberately
        # not factored as it is a complex formula.
        _w = w1 * h1
        w2 = math.tan(angle)**2
        w2 = w2 * w1**2
        w2 = h1**2 + w2
        w2 = math.sqrt(w2)
        w2 = _w / w2
        h2 = w2 * math.tan(angle)
        w3 = w1 + w2
        w4 = w1 - w2
        h3 = h1 + h2
        h4 = h1 - h2
        return w4, w1, w3, h4, h1, h3

    @staticmethod
    def calc_octagon_shape(x, y, w, h, q):
        """
        Calculate the shape of an octagon using a ratio.

        x, y, w, h: float
            Defines rectangle.

        q: tuple
            of offsets for points

        Return: tuple
            of x, y pairs
            for select polygon function
        """
        w1, w2, w3, h1, h2, h3 = q

        # The first point is top-center.
        # The direction is clockwise.
        return (
            x + w2, y,
            x + w3, y + h1,
            x + w, y + h2,
            x + w3, y + h3,
            x + w2, y + h,
            x + w1, y + h3,
            x, y + h2,
            x + w1, y + h1
        )

    @staticmethod
    def calc_pin_offset(pin, s, w, h, x, y):
        """
        Calculate pin offset given the layer space.

        Fixed-sized cells have a pin corner. Their cell
        grid is pinned or connected to its pin corner.

        pin: string
            pin type

        s: tuple
            size
            w, h
            layer space

        w, h: int
            size of table

        x, y: int
            offset
        """
        if pin in gr.PINS_WITH_X_OFFSET:
            x1 = s[0] - w

            if pin == gr.CENTER:
                x1 //= 2
            x += x1

        if pin in gr.PINS_WITH_Y_OFFSET:
            y1 = s[1] - h

            if pin == gr.CENTER:
                y1 //= 2
            y += y1
        return x, y

    @staticmethod
    def calc_vertical_ellipse(rect):
        """
        Calculate the rectangle shape for a vertical ellipse.

        rect: Rect
            the bounding rectangle of the ellipse

        Return: dict
            with shape
        """
        w = int(round(rect.w * .135))
        return {'x': rect.x, 'y': rect.y, 'w': rect.w - w, 'h': rect.h}

    @staticmethod
    def is_allocated_cell(grid, r, c):
        """
        Determine if a cell is a valid cell in a table.
        Consider double-space shapes allocate every other cell.

        If the grid is not shifted, then only cells
        where the row and column have the same
        remainder when divided by two are valid.

        If the grid is shifted, then only cells
        where the row and column have different
        remainders when divided by two are valid.

        grid: Grid
            of cell table

        r, c: int
            row, column
            cell index

        double_type: enum
            a polarized and typed value

        Return: bool
            Is true if the cell is valid.
        """
        d = grid.d
        if d:
            if grid.cell_shape in sh.DOUBLE:
                if ok.CELL_SHIFT in d and d[ok.CELL_SHIFT]:
                    a = sh.SHIFT
                else:
                    a = sh.NOT_SHIFT
            else:
                a = sh.NOT_DOUBLE_SPACE

        else:
            a = grid.double_type

        if a == sh.NOT_DOUBLE_SPACE:
            return True

        elif a == sh.SHIFT:
            return (r % 2 and not c % 2) or (not r % 2 and c % 2)
        else:
            return (r % 2 and c % 2) or (not r % 2 and not c % 2)

    @staticmethod
    def is_rectangular_shape(shape):
        """
        Determine if a cell shape is rectangular.

        shape: string
            shape descriptor

        Return: bool
            Is true if the cell shape is rectangular shaped.
        """
        return shape in (sh.RECTANGLE, sh.SQUARE)

    @staticmethod
    def is_inverse_triangle(r, c):
        """
        Determine if a triangle is inverted,
        either vertically or horizontally.

        r, c: int
            row, column
            cell index

        Return: bool
            Is true when the triangle is inverted.
        """
        return (not r % 2 and c % 2) or (r % 2 and not c % 2)


class FromRect:
    """
    Has functions for calculating a cell shape.
    The functions receive a Rect and return a tuple or dictionary.

    Tuples are x, y points for drawing polygons.
    Dictionaries contain x, y, w, h, a rectangle,
    and are used to draw ellipses.
    """

    @staticmethod
    def circle(rect):
        """
        Get a dictionary for a circle.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: dict
            Defines a rectangle bounds of an ellipse.
        """
        x, y = rect.position
        w, h = rect.size
        center_x, center_y = x + w // 2, y + h // 2
        w = min(w, h)
        x1 = center_x - w // 2
        y1 = center_y - w // 2
        return {'x': x1, 'y': y1, 'w': w, 'h': w}

    @staticmethod
    def rhombus_shear(rect):
        """
        Get the 4 points for a sheared rhombus.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a sheared rhombus polygon
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = (y + y1) / 2
        x2 = (x + x1) / 2
        return x, y2, x2, y, x1, y2, x2, y1

    @staticmethod
    def rhombus_regular(rect):
        """
        Get the 4 points for a regular rhombus.
        Maintain the rhombus shape proportions.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a regular rhombus polygon
        """
        x, y = rect.position
        w, h = rect.size
        w2 = min(w, h) // 2
        center_x, center_y = x + w // 2, y + h // 2
        return (
            center_x - w2, center_y,
            center_x, center_y - w2,
            center_x + w2, center_y,
            center_x, center_y + w2
        )

    @staticmethod
    def ellipse(rect):
        """
        Translate a rectangle into a dictionary for an ellipse.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: dict
            with key, value pairs that define a rectangle
        """
        return {'x': rect.x, 'y': rect.y, 'w': rect.w, 'h': rect.h}

    @staticmethod
    def hexagon_regular_shear(rect):
        """
        Get 6 points of a sheared regular hexagon.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a horizontally aligned hexagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_hexagon_regular_shape(
            x, y,
            w, h,
            Shape.calc_hexagon_regular_offset(w, h)
        )

    @staticmethod
    def hexagon_regular(rect):
        """
        Get 6 points of a regular hexagon.
        Maintain the hexagon shape proportions.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a hexagon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * RATIO, h

        if w1 > w:
            # Solution one doesn't fit the rectangle, so it's solution two.
            w1, h1 = w, w * UP_RATIO

        center_x, center_y = (w - w1) // 2, (h - h1) // 2
        x += center_x
        y += center_y
        return Shape.calc_hexagon_regular_shape(
            x, y,
            w1, h1,
            Shape.calc_hexagon_regular_offset(w1, h1)
        )

    @staticmethod
    def hexagon_truncated_shear(rect):
        """
        Get 6 points of a sheared and truncated hexagon.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a vertically aligned hexagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_hexagon_truncated_shape(
            x, y,
            w, h,
            Shape.calc_hexagon_truncated_offset(w, h)
        )

    @staticmethod
    def hexagon_truncated(rect):
        """
        Get 6 points of a truncated hexagon.
        Maintain the hexagon shape proportions.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a hexagon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = w, w * RATIO

        if h1 > h:
            # Solution one doesn't fit the rectangle, so it's solution two.
            w1, h1 = h * UP_RATIO, h

        center_x, center_y = (w - w1) // 2, (h - h1) // 2
        x += center_x
        y += center_y
        return Shape.calc_hexagon_truncated_shape(
            x, y,
            w1, h1,
            Shape.calc_hexagon_truncated_offset(w1, h1)
        )

    @staticmethod
    def octagon_shear(rect):
        """
        Get 8 points of an octagon.
        Process sheared or regular octagons.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing an octagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_octagon_shape(
            x, y,
            w, h,
            Shape.calc_octagon_offset(w, h)
        )

    @staticmethod
    def octagon_side_to_side_shear(rect):
        """
        Get a 8 points of an octagon, side to side.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing an octagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_octagon_side_to_side_shape(
            x, y,
            w, h,
            Shape.calc_octagon_side_to_side_offset(w, h)
        )

    @staticmethod
    def octagon_side_to_side(rect):
        """
        Get a 8 points of a side to side octagon.
        Maintain the octagon side to side shape proportions.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing an octagon
        """
        x, y = rect.position
        w, h = rect.size
        w1 = min(w, h)

        # Center the polygon in the rectangle.
        offset_x, offset_y = (w - w1) // 2, (h - w1) // 2
        x += offset_x
        y += offset_y
        return Shape.calc_octagon_side_to_side_shape(
            x, y,
            w1, w1,
            Shape.calc_octagon_side_to_side_offset(w1, w1)
        )

    @staticmethod
    def octagon_regular(rect):
        """
        Get 8 points of an octagon.
        Maintain a regular octagon proportions.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing an octagon
        """
        x, y = rect.position
        w, h = rect.size
        w1 = min(w, h)

        offset_x, offset_y = (w - w1) // 2, (h - w1) // 2
        x += offset_x
        y += offset_y
        return Shape.calc_octagon_shape(
            x, y,
            w1, w1,
            Shape.calc_octagon_offset(w1, w1)
        )

    @staticmethod
    def rectangle(rect):
        """
        Translate a rectangle into tuple of x, y
        coordinates for drawing a rectangle polygon.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a rectangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        return x, y, x1, y, x1, y1, x, y1

    @staticmethod
    def square(rect):
        """
        Get 4 points for a square from the
        topleft corner with consecutive clock-wise order.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a square
        """
        x, y = rect.position
        w, h = rect.size
        center_x, center_y = x + w // 2, y + h // 2
        w = min(w, h)
        x1 = center_x - w // 2
        y1 = center_y - w // 2
        x2, y2 = x1 + w, y1 + w
        return x1, y1, x2, y1, x2, y2, x1, y2

    @staticmethod
    def triangle_down_shear(rect):
        """
        Get 3 points for a triangle facing down.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a facing down triangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        x2 = (x + x1) / 2
        return x, y, x2, y1, x1, y

    @staticmethod
    def triangle_down_isosceles(rect):
        """
        Get 3 points for a triangle facing down.
        Maintain an equilateral triangle shape.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a facing down triangle
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * UP_RATIO, h

        if w1 > w:
            # Solution one overflows the rectangle.
            w1, h1 = w, w * RATIO

        x1, y1 = x + w1, y + h1
        x2 = (x + x1) / 2

        # Center the triangle.
        offset_x = (w - w1) // 2
        offset_y = (h - h1) // 2
        x += offset_x
        x1 += offset_x
        x2 += offset_x
        y += offset_y
        y1 += offset_y
        return x, y, x2, y1, x1, y

    @staticmethod
    def triangle_left_shear(rect):
        """
        Get 3 points for a triangle facing left.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a facing left triangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = (y + y1) / 2
        return x1, y, x1, y1, x, y2

    @staticmethod
    def triangle_left_isosceles(rect):
        """
        Get 3 points for a triangle facing left.
        Maintain an equilateral triangle shape.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a triangle
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * RATIO, h

        if w1 > w:
            # Solution one overflows the given rectangle.
            # solution two
            w1, h1 = w, w * UP_RATIO

        x1, y1 = x + w1, y + h1
        y2 = (y + y1) / 2

        # Center the triangle.
        offset_x = (w - w1) // 2
        offset_y = (h - h1) // 2
        x += offset_x
        x1 += offset_x
        y += offset_y
        y1 += offset_y
        y2 += offset_y
        return x1, y, x1, y1, x, y2

    @staticmethod
    def triangle_right_shear(rect):
        """
        Get 3 points for a triangle facing right.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a facing right triangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = (y + y1) / 2
        return x, y, x, y1, x1, y2

    @staticmethod
    def triangle_right_isosceles(rect):
        """
        Get 3 points for a triangle facing right.
        Maintain an equilateral triangle shape.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a facing right triangle
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * RATIO, h

        if w1 > w:
            # Solution one overflows the given rectangle.
            # solution two
            w1, h1 = w, w * UP_RATIO

        x1, y1 = x + w1, y + h1
        y2 = (y + y1) / 2

        # Center the triangle.
        offset_x = (w - w1) // 2
        offset_y = (h - h1) // 2
        x += offset_x
        x1 += offset_x
        y += offset_y
        y1 += offset_y
        y2 += offset_y
        return x, y, x, y1, x1, y2

    @staticmethod
    def triangle_up_shear(rect):
        """
        Get 3 points for a triangle facing up.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing a facing up triangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        x2 = (x + x1) / 2
        return x, y1, x2, y, x1, y1

    @staticmethod
    def triangle_up_isosceles(rect):
        """
        Get 3 points for a triangle facing down.
        Maintain an equilateral triangle shape.

        rect: Rect
            Defines a rectangle.
            a cell or pocket

        Return: tuple
            x, y pairs
            for drawing the triangle
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * UP_RATIO, h

        if w1 > w:
            # Solution one overflows the rectangle.
            w1, h1 = w, w * RATIO

        x1, y1 = x + w1, y + h1
        x2 = (x + x1) / 2

        # Center the triangle.
        offset_x = (w - w1) // 2
        offset_y = (h - h1) // 2
        x += offset_x
        x1 += offset_x
        x2 += offset_x
        y += offset_y
        y1 += offset_y
        return x, y1, x2, y, x1, y1


class Render:
    """Use the render size."""

    @staticmethod
    def calc_factor_h(f):
        return f * Render.height()

    @staticmethod
    def calc_factor_w(f):
        return f * Render.width()

    @staticmethod
    def get_factor_h(a):
        """
        Calculate the number for a number pair
        that uses the render height as a factor.

        a: tuple, int, or float
            (fixed value, factor value)
            fixed value, from an earlier version

        Return: numeric
            of the same type as the fixed value
        """
        return Factor.get_factor(a, Render.height())

    @staticmethod
    def get_factor_w(a):
        """
        Calculate the number for a number pair
        that uses the render width as a factor.

        a: tuple, int, or float
            (fixed value, factor value)
            fixed value, from an earlier version

        Return: numeric
            of the same type as the fixed value
        """
        return Factor.get_factor(a, Render.width())

    @staticmethod
    def get_factor_s(q):
        """
        Calculate the number for a number pair
        that uses the render size as a factor.

        q: tuple
            (fixed value, factor value)

        Return: int
            of the same type as the fixed value
        """
        w, h = Render.size()
        return q[0] + int(q[1] * sqrt(w * h))

    @staticmethod
    def height():
        """
        Get the render width from the interface.

        Return: int
            width of render
        """
        return Hat.cat.group_dict[sk.GLOBAL].d[ok.RENDER_HEIGHT].get_value()

    @staticmethod
    def size():
        """
        Get the render size from the interface.

        Return: tuple
            of int
            render size
            width, height
        """
        d = Hat.cat.group_dict[sk.GLOBAL].d
        return d[ok.RENDER_WIDTH].get_value(), d[ok.RENDER_HEIGHT].get_value()

    @staticmethod
    def width():
        """
        Get the render width from the interface.

        Return: int
            width of render
        """
        return Hat.cat.group_dict[sk.GLOBAL].d[ok.RENDER_WIDTH].get_value()


class Factor:
    """Produce factored results from NumberPairs."""

    @staticmethod
    def calc_factor(f, w):
        """
        Calculate the factored render height.

        f: float
            Is factor variable.
            for example, the render width

        w: numeric
            scale of factor

        Return: int
            the factor of the render height
        """
        return f * w

    @staticmethod
    def get_factor(a, w):
        """
        Calculate the number for a number pair
        that uses the render width as a factor.

        a: tuple or int
            (fixed value, factor value)
            fixed value

        w: numeric
            scale of factor
            for example, the render height

        Return: numeric
            of the same type as the fixed value
        """
        # result, 'b'
        b = a

        if isinstance(a, tuple):
            b = a[0] + Factor.calc_factor(a[1], w)
            if isinstance(a[0], int):
                b = int(b)

        elif isinstance(a, float):
            b = Factor.calc_factor(a, w)
        return b


class Canvas:
    """Use the canvas size."""

    @staticmethod
    def calc_factor_h(f):
        return f * (Render.height() - 1)

    @staticmethod
    def calc_factor_w(f):
        return f * (Render.width() - 1)

    @staticmethod
    def get_factor_h(a):
        """
        Calculate the number for a number pair
        that uses the render height as a factor.

        a: tuple, int, or float
            (fixed value, factor value)
            fixed value, from an earlier version

        Return: numeric
            of the same type as the fixed value
        """
        return Factor.get_factor(a, Render.height() - 1)

    @staticmethod
    def get_factor_w(a):
        """
        Calculate the number for a number pair
        that uses the render width as a factor.

        a: tuple, int, or float
            (fixed value, factor value)
            fixed value, from an earlier version

        Return: numeric
            of the same type as the fixed value
        """
        return Factor.get_factor(a, Render.width() - 1)


dispatch = {
    ft.TRIANGLE_DOWN_SHEAR: FromRect.triangle_down_shear,
    ft.TRIANGLE_DOWN_ISOSCELES: FromRect.triangle_down_isosceles,
    ft.TRIANGLE_LEFT_SHEAR: FromRect.triangle_left_shear,
    ft.TRIANGLE_LEFT_ISOSCELES: FromRect.triangle_left_isosceles,
    ft.TRIANGLE_RIGHT_SHEAR: FromRect.triangle_right_shear,
    ft.TRIANGLE_RIGHT_ISOSCELES: FromRect.triangle_right_isosceles,
    ft.TRIANGLE_UP_SHEAR: FromRect.triangle_up_shear,
    ft.TRIANGLE_UP_ISOSCELES: FromRect.triangle_up_isosceles,
    sh.CIRCLE: FromRect.circle,
    sh.CIRCLE_HORIZONTAL: FromRect.circle,
    sh.CIRCLE_VERTICAL: FromRect.circle,
    sh.ELLIPSE: FromRect.ellipse,
    sh.ELLIPSE_HORIZONTAL: FromRect.ellipse,
    sh.ELLIPSE_VERTICAL: FromRect.ellipse,
    sh.HEXAGON_REGULAR: FromRect.hexagon_regular,
    sh.HEXAGON_REGULAR_SHEAR: FromRect.hexagon_regular_shear,
    sh.HEXAGON_TRUNCATED: FromRect.hexagon_truncated,
    sh.HEXAGON_TRUNCATED_SHEAR: FromRect.hexagon_truncated_shear,
    sh.OCTAGON_DOUBLE_REGULAR: FromRect.octagon_side_to_side,
    sh.OCTAGON_DOUBLE_SHEAR: FromRect.octagon_side_to_side_shear,
    sh.OCTAGON_REGULAR: FromRect.octagon_regular,
    sh.OCTAGON_SHEAR: FromRect.octagon_shear,
    sh.OCTAGON_SIDE_TO_SIDE_SHEAR: FromRect.octagon_side_to_side_shear,
    sh.OCTAGON_SIDE_TO_SIDE_REGULAR: FromRect.octagon_side_to_side,
    sh.RECTANGLE: FromRect.rectangle,
    sh.RHOMBUS: FromRect.rhombus_regular,
    sh.RHOMBUS_SHEAR: FromRect.rhombus_shear,
    sh.SQUARE: FromRect.square
}
