#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_average_color import AverageColor
from roller_backdrop_backdrop_image import BackdropImage
from roller_backdrop_carbon_14 import Carbon14
from roller_backdrop_clay_chemistry import ClayChemistry
from roller_backdrop_color_fill import ColorFill
from roller_backdrop_color_grid import ColorGrid
from roller_backdrop_core_design import CoreDesign
from roller_backdrop_crystal_cave import CrystalCave
from roller_backdrop_cubism_cover import CubismCover
from roller_backdrop_dark_fort import DarkFort
from roller_backdrop_density_gradient import DensityGradient
from roller_backdrop_drop_zone import DropZone
from roller_backdrop_etch_sketch import EtchSketch
from roller_backdrop_floor_sample import FloorSample
from roller_backdrop_galactic_field import GalacticField
from roller_backdrop_glass_gaw import GlassGaw
from roller_backdrop_gradient_fill import GradientFill
from roller_backdrop_historic_trip import HistoricTrip
from roller_backdrop_image_gradient import ImageGradient
from roller_backdrop_line_stone import LineStone
from roller_backdrop_lost_maze import LostMaze
from roller_backdrop_maze_blend import MazeBlend
from roller_backdrop_nano_suit import NanoSuit
from roller_backdrop_mystery_grate import MysteryGrate
from roller_backdrop_noise_rift import NoiseRift
from roller_backdrop_pattern_fill import PatternFill
from roller_backdrop_rainbow_valley import RainbowValley
from roller_backdrop_rocky_landing import RockyLanding
from roller_backdrop_spacetime_fabric import SpacetimeFabric
from roller_backdrop_specimen_speckle import SpecimenSpeckle
from roller_backdrop_spiral_channel import SpiralChannel
from roller_backdrop_square_cloud import SquareCloud
from roller_backdrop_trailing_vine import TrailingVine
from roller_backdrop_watery_page import WateryPage
from roller_constant_key import BackdropStyle as by, Effect as ek
from roller_effect_ball_joint import BallJoint
from roller_effect_border_line import BorderLine
from roller_effect_brush_punch import BrushPunch
from roller_effect_camo_planet import CamoPlanet
from roller_effect_ceramic_chip import CeramicChip
from roller_effect_circle_punch import CirclePunch
from roller_effect_clear_frame import ClearFrame
from roller_effect_color_board import ColorBoard
from roller_effect_color_pipe import ColorPipe
from roller_effect_corner_tape import CornerTape
from roller_effect_crumble_shell import CrumbleShell
from roller_effect_cutout_plate import CutoutPlate
from roller_effect_feather_steps import FeatherSteps
from roller_effect_frame_over import FrameOver
from roller_effect_glass_reveal import GlassReveal
from roller_effect_gradient_level import GradientLevel
from roller_effect_hot_glue import HotGlue
from roller_effect_jagged_edge import JaggedEdge
from roller_effect_line_fashion import LineFashion
from roller_effect_maze_mirror import MazeMirror
from roller_effect_metallic_profile import MetallicProfile
from roller_effect_no_effect import NoEffect
from roller_effect_paint_rush import PaintRush
from roller_effect_rad_wave import RadWave
from roller_effect_raised_maze import RaisedMaze
from roller_effect_shape_burst import ShapeBurst
from roller_effect_square_cut import SquareCut
from roller_effect_square_punch import SquarePunch
from roller_effect_stained_glass import StainedGlass
from roller_effect_stretch_tray import StretchTray
from roller_effect_wire_fence import WireFence
from roller_render_shadow import InnerShadow, Shadow1, Shadow2


class Pin:
    """
    Connect image-effect and backdrop-style classes with their key.
    Use with render or its preview.
    """
    # backdrop-style
    backdrop = {
        by.AVERAGE_COLOR: AverageColor,
        by.BACKDROP_IMAGE: BackdropImage,
        by.CARBON_14: Carbon14,
        by.CLAY_CHEMISTRY: ClayChemistry,
        by.COLOR_FILL: ColorFill,
        by.COLOR_GRID: ColorGrid,
        by.CORE_DESIGN: CoreDesign,
        by.CRYSTAL_CAVE: CrystalCave,
        by.CUBISM_COVER: CubismCover,
        by.DARK_FORT: DarkFort,
        by.DROP_ZONE: DropZone,
        by.DENSITY_GRADIENT: DensityGradient,
        by.ETCH_SKETCH: EtchSketch,
        by.FLOOR_SAMPLE: FloorSample,
        by.GALACTIC_FIELD: GalacticField,
        by.GLASS_GAW: GlassGaw,
        by.GRADIENT_FILL: GradientFill,
        by.HISTORIC_TRIP: HistoricTrip,
        by.IMAGE_GRADIENT: ImageGradient,
        by.LINE_STONE: LineStone,
        by.LOST_MAZE: LostMaze,
        by.MAZE_BLEND: MazeBlend,
        by.MYSTERY_GRATE: MysteryGrate,
        by.NANO_SUIT: NanoSuit,
        by.NOISE_RIFT: NoiseRift,
        by.PATTERN_FILL: PatternFill,
        by.RAINBOW_VALLEY: RainbowValley,
        by.ROCKY_LANDING: RockyLanding,
        by.SPACETIME_FABRIC: SpacetimeFabric,
        by.SPECIMEN_SPECKLE: SpecimenSpeckle,
        by.SPIRAL_CHANNEL: SpiralChannel,
        by.SQUARE_CLOUD: SquareCloud,
        by.TRAILING_VINE: TrailingVine,
        by.WATERY_PAGE: WateryPage
    }

    # image-effect
    effect = {
        ek.BALL_JOINT: BallJoint,
        ek.BORDER_LINE: BorderLine,
        ek.BRUSH_PUNCH: BrushPunch,
        ek.CAMO_PLANET: CamoPlanet,
        ek.CERAMIC_CHIP: CeramicChip,
        ek.CIRCLE_PUNCH: CirclePunch,
        ek.CLEAR_FRAME: ClearFrame,
        ek.COLOR_BOARD: ColorBoard,
        ek.COLOR_PIPE: ColorPipe,
        ek.CORNER_TAPE: CornerTape,
        ek.CRUMBLE_SHELL: CrumbleShell,
        ek.CUTOUT_PLATE: CutoutPlate,
        ek.FEATHER_STEPS: FeatherSteps,
        ek.FRAME_OVER: FrameOver,
        ek.GLASS_REVEAL: GlassReveal,
        ek.GRADIENT_LEVEL: GradientLevel,
        ek.HOT_GLUE: HotGlue,
        ek.INNER_SHADOW: InnerShadow,
        ek.JAGGED_EDGE: JaggedEdge,
        ek.LINE_FASHION: LineFashion,
        ek.MAZE_MIRROR: MazeMirror,
        ek.METALLIC_PROFILE: MetallicProfile,
        ek.NO_EFFECT: NoEffect,
        ek.RAD_WAVE: RadWave,
        ek.RAISED_MAZE: RaisedMaze,
        ek.PAINT_RUSH: PaintRush,
        ek.SHADOW_1: Shadow1,
        ek.SHADOW_2: Shadow2,
        ek.SHAPE_BURST: ShapeBurst,
        ek.SQUARE_CUT: SquareCut,
        ek.SQUARE_PUNCH: SquarePunch,
        ek.STAINED_GLASS: StainedGlass,
        ek.STRETCH_TRAY: StretchTray,
        ek.WIRE_FENCE: WireFence
    }
