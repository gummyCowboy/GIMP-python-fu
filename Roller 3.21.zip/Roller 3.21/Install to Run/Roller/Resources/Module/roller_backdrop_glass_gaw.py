#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, uniform
from roller_backdrop_color_grid import ColorGrid
from roller_constant_fu import Fu
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Base, Hat, One
from roller_one_fu import Lay
from roller_option_preset_dict import PresetDict
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
ed = Fu.Edge
er = Fu.Erode
um = Fu.UnsharpMask
wa = Fu.Waves


def do_waves(z):
    """
    Do waves on layer.

    z: layer
        to receive wave
    """
    pdb.plug_in_waves(
        z.image, z,
        randint(1, 12),
        wa.PHASE_1,
        uniform(24., 50.),
        wa.SMEARED,
        wa.USE_REFLECTION
    )


def do_grid(d, merge=1):
    """
    Mix random grid overlays with waves.

    d: dict
        Has options.

    merge: flag
        If it's true, the color grid layer
        is merged to the layer below.
    """
    j = Hat.cat.render.image
    d[ok.ROW] = randint(2, 6)
    d[ok.COLUMN] = randint(2, 6)
    d[ok.COLOR_1] = Base.rnd_col()
    d[ok.COLOR_2] = Base.rnd_col()
    z = ColorGrid.do(
        One(d=d, k="Glass", z=j.active_layer)
    )
    z.mode = fu.LAYER_MODE_DIFFERENCE

    do_waves(z)

    if merge:
        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        do_waves(z)
    return z


class GlassGaw:
    """
    Create a glassy grid with channels of liquid color.
    """

    @staticmethod
    def do(o):
        """
        Draw the squiggly lines of translucent color.

        o: One
            Has variables.

        Return: layer or None
            with Glass Gaw
        """
        cat = Hat.cat
        j = cat.render.image

        # Glass Gaw preset dict, 'd'
        d = o.d

        if d[ok.OPACITY]:
            e = PresetDict.get_default(by.COLOR_GRID)

            # backdrop image layer, 'z'
            z = Lay.clone(o.z)

            group = Lay.group(j, o.k, layer=z)

            e.update(
                {
                    ok.BUMP: {ok.BUMP_TYPE: "None"},
                    ok.INVERT: 0,
                    ok.MODE: "Normal",
                    ok.OPACITY: 100,
                    ok.ROTATE: 0,
                    ok.THRESHOLD: 1.
                }
            )

            # Plant the seed that makes the style reproducible.
            cat.seed(d)

            j.active_layer = z

            for i in range(4):
                z1 = do_grid(e, merge=i != 0)
                z = Lay.clone(z1)

            pdb.plug_in_edge(j, z, ed.AMOUNT_1, ed.NO_WRAP, ed.SOBEL)

            z2 = Lay.clone(z1)

            Lay.blur(z2, 20)

            z2.mode = fu.LAYER_MODE_DIFFERENCE
            z3 = Lay.clone(z2)
            z4 = Lay.clone(z3)
            z4.mode = fu.LAYER_MODE_GRAIN_EXTRACT
            z.mode = fu.LAYER_MODE_DARKEN_ONLY

            pdb.gimp_drawable_invert(z, 0)
            Lay.blur(z, 4)
            pdb.plug_in_unsharp_mask(
                j, z1,
                um.RADIUS_3,
                um.AMOUNT_POINT_16,
                um.THRESHOLD_0
            )

            group1 = Lay.group(j, o.k)

            for i in (z1, z3, z2, z4, z):
                pdb.gimp_image_reorder_item(j, i, group1, 0)

            z5 = Lay.clone(z)

            for _ in range(2):
                pdb.plug_in_erode(
                    j, z5,
                    er.PROPAGATE_BLACK,
                    er.RGB_CHANNELS,
                    er.FULL_RATE,
                    er.DIRECTION_MASK_7,
                    er.LOW_LIMIT_0,
                    er.UPPER_LIMIT_128
                )

            Lay.blur(z5, 90)

            z5.mode = fu.LAYER_MODE_MULTIPLY

            j.remove_layer(group)

            z = Lay.merge_group(group1)
            z.mode, z.opacity = RenderHub.get_mode(d)

            Lay.clone(o.z)

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            return RenderHub.bump(z, d[ok.BUMP])
