#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Caption as pt, Justification as ju, Model as mo
from roller_constant_key import Layer as nk, Model as md, Option as ok
from roller_model_text import Text
from roller_one import Base, Comm, Hat, Rect
from roller_one_fu import Lay, Sel
from roller_one_extract import dispatch, Form, Path, Render, Shape
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

pdb = fu.pdb
NO_SAVE = nk.CUSTOM_CELL_CAPTION, nk.LAYER_CAPTION
X_IS_0 = Y_IS_0 = W_IS_0 = H_IS_0 = 0
YES_ANTIALIAS = 1


def blur_behind(z, d):
    """
    Blur behind material.

    z: layer
        with material

    d: dict
        Has the blur behind option.

    Return: layer
        with material
    """
    z1 = RenderHub.blur_behind(z, d)

    if z1:
        z = z1
    return z


def blur_behind_layer(o, z, d):
    """
    Blur behind a layer caption stripe.

    o: One
        Has model name.

    z: layer
        with stripe

    d: dict
        of background stripe

    return: layer
        with caption
    """
    if d[ok.STRIPE_TYPE] and d[ok.OPACITY] and d[ok.BLUR_BEHIND]:
        z = blur_behind(z, d)
        Hat.cat.register_layer((o.model_name, nk.LAYER_CAPTION), z)
    return z


def get_text(o, _type):
    """
    Assemble the text as defined by the grid
    cell data for the caption option group.
    Updates 'o.image_number' for the sequence type in grid.

    o: One
        Has variables.
        r, c: int
            row, column for multi-image
        e: dict
            of caption, form

    _type: string
        caption type

    Return: string
        the caption
    """
    d = o.e
    text = ""

    if _type == pt.TEXT:
        text = d[ok.TEXT]

    elif _type == pt.SEQUENCE_NUMBER:
        if o.is_per_cell:
            text = d[ok.TEXT]
        else:
            text = str(o.image_number)
            o.image_number += 1

    elif _type == pt.IMAGE_NAME:
        text = o.grid.get_image_name(o.r, o.c) if o.model in \
            md.MULTI_IMAGE else o.grid.get_image_name(o.r, o.c)
    if _type in (pt.IMAGE_NAME, pt.SEQUENCE_NUMBER):
        n = d[ok.LEADING_TEXT]
        n1 = d[ok.TRAILING_TEXT]
        if text:
            if n:
                text = n + text
            if n1:
                text += n1
    return text


def make_caption(z, o, text, layer_key, name):
    """
    Add text. Call once per cell.

    z: layer
        to receive text

    o: One
        Has cell data.

    text: string
        to display

    layer_key: string
        Use to find layer.

    name: string
        layer name
        either a layer or cell-type caption layer
    """
    go = True
    cat = Hat.cat
    j = cat.render.image
    d = o.e
    font = d[ok.FONT]

    if font not in cat.font_list:
        Comm.info_msg(mo.MISSING_ITEM.format("Caption", "font", font))
        go = False

    if go:
        color = (255, 255, 255) if o.is_plan else d[ok.COLOR]
        go, z = Text.make_text_layer(
            j, z,
            YES_ANTIALIAS,
            X_IS_0, Y_IS_0,
            text,
            d[ok.FONT_SIZE],
            font,
            color,
            W_IS_0, H_IS_0
        )
    if go:
        Sel.item(z)

        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        text_width = x1 - x
        text_height = y1 - y
        half_width = text_width // 2
        half_height = text_height // 2
        top, bottom, left, right = Form.calc_margin(
            d[ok.CAPTION_MARGIN],
            o.rect.w, o.rect.h
        )

        # cell width, height
        w = o.rect.w - left - right
        h = o.rect.h - top - bottom
        n = d[ok.JUSTIFICATION]

        # correction for the w, h dimension
        w = max(w, 1)
        h = max(h, 1)

        # cell position x, y
        s = Render.size()
        x = o.rect.x + left
        y = o.rect.y + top
        x = min(x, s[0] - 1)
        y = min(y, s[1] - 1)

        # Get 'y'.
        if n in ju.BOTTOM:
            y += h - text_height

        elif n in ju.CENTER_Y:
            # middle
            y += (h // 2) - half_height

        # Get 'x'.
        if n in ju.RIGHT:
            x += w - text_width

        elif n in ju.CENTER_X:
            # center
            x += (w // 2) - half_width

        # Correct the x, y position.
        x = Base.seal(x, o.rect.x, s[0] - 1)
        y = Base.seal(y, o.rect.y, s[1] - 1)

        # Move the text layer.
        pdb.gimp_layer_set_offsets(z, x, y)

        if not o.is_plan:
            z.name = name
            z.opacity = d[ok.OPACITY]
            z = Shadow.do_shadows(d[ok.TRI_SHADOW], z)
        make_stripe(d[ok.BACKGROUND_STRIPE], z, o, layer_key)


def make_stripe(d, z, o, layer_key):
    """
    Determine if a caption stripe is required.

    Create the caption background stripe.

    d: dict
        of stripe

    z: layer
        Has caption.

    o: One
        Has variables.
        color: tuple
            RGB

    layer_key: string
        type of stripe
        Use to distinguish a layer from a cell caption.
    """
    def clip(_z):
        """
        Keep the stripe and caption with the bounds a cell plaque.

        _z: layer
            to clip
        """
        if o.is_clip:
            Sel.shape(j, o.shape)
            Sel.invert_clear(_z, keep_sel=True)

    j = z.image

    if d[ok.STRIPE_TYPE] and d[ok.OPACITY]:
        Sel.item(z)

        cat = Hat.cat
        n = z.name
        is_sel, _, y, _, y1 = pdb.gimp_selection_bounds(j)
        if is_sel:
            h = y1 - y
            center_y = y + h // 2
            h1 = int(h * d[ok.STRIPE_HEIGHT])
            y = center_y - h1 // 2
            group = Lay.group(
                j,
                n,
                parent=z.parent,
                offset=pdb.gimp_image_get_item_position(j, z) + 1
            )
            z1 = Lay.add(j, n, parent=group)

            pdb.gimp_image_reorder_item(j, z, group, 0)
            Sel.rect(
                j,
                o.rect.x, y,
                o.rect.w, h1,
                option=fu.CHANNEL_OP_REPLACE
            )
            Sel.fill(
                z1,
                o.color if o.is_plan else d[ok.COLOR]
            )
            clip(z1)

            z1.opacity = d[ok.OPACITY]

            if (
                d[ok.BLUR_BEHIND] and
                not o.is_plan and
                d[ok.OPACITY] < 100. and
                layer_key not in NO_SAVE
            ):
                o.is_stripe = True
                n1 = o.model_name
                cat.save_caption_stripe_sel(
                    z1,
                    n1 if n1 in md.ONE_CELL else (n1, o.r, o.c)
                )
            z = Lay.merge_group(group)
    clip(z)


class Caption:
    """Create a text overlay on a cell."""

    @staticmethod
    def blur_behind_custom_cell(o):
        """
        Blur behind a custom cell caption stripe.

        o: One
            Has a path variable.

        Return: layer or None
            with blur behind
        """
        cat = Hat.cat
        z1 = None
        d = Path.get_cell_caption_form(o)[ok.BACKGROUND_STRIPE]
        blur = d[ok.BLUR_BEHIND]

        if d[ok.STRIPE_TYPE] and d[ok.OPACITY] and blur:
            j = cat.render.image
            z = cat.get_layer((o.model_name, nk.CELL_CAPTION))
            if z:
                z1 = Lay.clone_background(z)
                z2 = Lay.clone_opaque(z)
                z1.name = Lay.name(z1.parent, nk.CAPTION_BEHIND)

                Sel.item(z2)
                Lay.blur(z1, blur)
                Sel.invert_clear(z1)
                j.remove_layer(z2)
        return z1

    @staticmethod
    def blur_behind_grid(o):
        """
        Blur behind grid cells.

        o: One
            Has variables.

        Return: layer or None
            with blur behind
        """
        cat = Hat.cat
        j = cat.render.image
        d = Path.get_cell_caption_chunk(o.path)
        is_merge_cell = o.grid.is_merge_cell
        is_per_cell = d[ok.PER_CELL]
        n = o.model_name

        # size of merged cell, 's'
        # indicates a topleft cell, '1'
        s = 1

        # a list of caption stripe selections, 'q'
        q = []

        z = cat.get_layer((n, nk.CELL_CAPTION))
        row, column = o.grid.division

        # for the blur material
        z1 = None

        if z:
            for r in range(row):
                for c in range(column):
                    k = n, r, c
                    go = Shape.is_allocated_cell(o.grid, r, c)

                    if go:
                        if is_merge_cell:
                            s = o.grid.d[ok.PER_CELL][r][c]

                        if s == (-1, -1):
                            go = False

                    if go:
                        e = is_per_cell[r][c] if is_per_cell else d
                        go = blur = e[ok.BACKGROUND_STRIPE][ok.BLUR_BEHIND]

                    if go:
                        go = cat.is_caption_sel(k)
                    if go:
                        sel = cat.get_caption_stripe_sel(k)
                        if sel:
                            q += [sel]
                            if not z1:
                                z1 = Lay.clone_background(z)
                                z1.name = Lay.name(
                                    z1.parent,
                                    nk.CAPTION_BEHIND
                                )

                            Sel.load(j, sel)
                            Lay.blur(z1, blur)
            if z1:
                pdb.gimp_selection_none(j)

                for i in q:
                    Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
                if q:
                    Sel.invert_clear(z1)
        return z1

    @staticmethod
    def do_custom_cell(o, is_plan):
        """
        Do a caption for a custom cell.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with caption
        """
        # 'get_text' needs 'o.e'.
        o.e = o.d
        o.r = o.c = 0
        return Caption.do_singular_cell_type(
            o,
            is_plan,
            get_text(o, o.d[ok.CUSTOM_CELL_CAPTION_TYPE]),
            o.d[ok.CUSTOM_CELL_CAPTION_TYPE]
        )

    @staticmethod
    def do_grid(o, is_plan):
        """
        Do the cell captions.

        o: One
            Has variables.

        is_plan: bool
            Is true if Plan is calling.

        Return: layer or None
            with caption
        """
        cat = Hat.cat
        j = cat.render.image
        is_merge_cell = o.grid.is_merge_cell
        row, column = o.grid.division
        n = Lay.name(o.parent, nk.CELL_CAPTION)
        o.image_number = o.d[ok.START_NUMBER]
        is_per_cell = o.is_per_cell = o.d[ok.PER_CELL]
        o.is_plan = is_plan
        d = o.d
        z = group = None
        go = True

        if not is_per_cell and d[ok.CELL_CAPTION_TYPE] == "None":
            go = False

        if go:
            for r in range(row):
                for c in range(column):
                    go = True
                    o.r, o.c = r, c

                    # Don't do dependent cells.
                    if is_merge_cell:
                        if o.grid.d[ok.PER_CELL][r][c] == (-1, -1):
                            go = False

                    if go:
                        go = Shape.is_allocated_cell(o.grid, r, c)

                    if go:
                        e = o.e = Form.get_form(o) if is_per_cell else d
                        n1 = e[ok.CUSTOM_CELL_CAPTION_TYPE] if is_per_cell \
                            else e[ok.CELL_CAPTION_TYPE]

                        text = get_text(o, n1)
                        if not text:
                            go = False
                    if go:
                        if not group:
                            group = Lay.group(j, n, parent=o.parent)
                            z = Lay.add(j, "Caption", parent=group)

                        o.rect = o.grid.get_merge_cell_rect(r, c)
                        o.is_clip = e[ok.CLIP_TO_CELL]

                        if o.is_clip:
                            o.shape = o.grid.get_shape(r, c)
                        make_caption(z, o, text, nk.CELL_CAPTION, n)
        if group:
            z = Lay.merge_group(group)
        return z

    @staticmethod
    def do_layer(o, is_plan):
        """
        Do a layer caption.

        o: One
            Has init variables.

        Return: tuple or None
            with caption layer
        """
        cat = Hat.cat
        parent = o.parent
        d = o.e = o.d
        j = cat.render.image
        z = None
        text = d[ok.TEXT]

        if text and d[ok.LAYER_CAPTION_TYPE] != "None":
            is_clip = o.is_clip = d[ok.CLIP_TO_CELL]
            o.is_plan = is_plan
            n = Lay.name(parent, nk.LAYER_CAPTION)
            group = Lay.group(j, n, parent=parent)
            z = Lay.add(j, "Caption", parent=group)
            size = Render.size()

            if d[ok.OBEY_MARGINS]:
                y, bottom, x, right = o.grid.layer_margin
                w = size[0] - x - right
                h = size[1] - y - bottom

            else:
                x = y = 0
                w, h = size

            o.rect = Rect((x, y), (w, h))

            if is_clip:
                o.shape = (
                    x, y,
                    x + w, y,
                    x + w, y + h,
                    x, y + h
                )

            make_caption(z, o, text, nk.LAYER_CAPTION, n)

            z = Lay.merge_group(group)
            if not is_plan:
                e = d[ok.BACKGROUND_STRIPE]
                z = blur_behind_layer(o, z, e)
        return z

    @staticmethod
    def do_singular_cell_type(o, is_plan, text, _type):
        """
        o: One
            Has init variables.

        is_plan: bool
            Is true when Plan is calling.

        text: string
            caption

        _type: string
            caption type

        Return: tuple or None
            with caption layer
        """
        z = group = None

        if text and _type != "None":
            cat = Hat.cat
            j = cat.render.image
            n = Lay.name(o.parent, nk.CELL_CAPTION)
            a = o.rect = o.grid.rect
            o.is_clip = o.d[ok.CLIP_TO_CELL]
            o.is_plan = is_plan
            o.shape = dispatch[o.grid.cell_shape](a)
            group = Lay.group(j, n, parent=o.parent)
            z = Lay.add(j, "Caption", parent=group)
            make_caption(z, o, text, nk.CUSTOM_CELL_CAPTION, n)

        if group:
            z = Lay.merge_group(group)
        return z

    @staticmethod
    def do_stack(o, is_plan):
        """
        Do a stack caption.

        o: One
            Has init variables.

        is_plan: bool
            Is true when Plan is calling.

        Return: tuple or None
            with caption layer
        """
        # The layer caption type is used by the stack model.
        o.e = o.d
        o.r = o.c = 0
        return Caption.do_singular_cell_type(
            o,
            is_plan,
            get_text(o, o.d[ok.LAYER_CAPTION_TYPE]),
            o.d[ok.LAYER_CAPTION_TYPE]
        )
