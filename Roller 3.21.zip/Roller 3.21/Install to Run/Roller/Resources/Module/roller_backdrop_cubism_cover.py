#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_one import One
from roller_option_preset_dict import PresetDict
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class CubismCover:
    """Create a pile of tile."""

    @staticmethod
    def do(o):
        """
        Do the backdrop-style.

        o: One
            Has variables.

        Return: layer or None
            with Cubism Cover
        """
        cat = Hat.cat
        j = cat.render.image

        # Cubism Cover preset dict, 'd'
        d = o.d

        if d[ok.OPACITY]:
            # backdrop image layer, 'z'
            z = Lay.clone(o.z)

            n = d[ok.BACKDROP_TYPE]

            if n == bs.PLASMA:
                pdb.plug_in_plasma(
                    j, z,
                    d[ok.RANDOM_SEED] + cat.seed_global,
                    Fu.Plasma.LOWEST_TURBULENCE
                )

            elif n == bs.GRADIENT:
                e = PresetDict.get_default(by.GRADIENT_FILL)
                e[ok.GRADIENT_TYPE] = d[ok.GRADIENT_TYPE]
                e[ok.GRADIENT] = d[ok.GRADIENT]

                if d[ok.GRADIENT_TYPE] == "Linear":
                    e[ok.END_X] = e[ok.START_X] = .5
                    e[ok.START_Y] = .0
                    e[ok.END_Y] = 1.

                else:
                    e[ok.START_X] = e[ok.START_Y] = .5
                    e[ok.END_X] = e[ok.END_Y] = .0

                z = GradientFill.do_layer(j, One(d=e, z=z))
                z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            if d[ok.BACKDROP_BLUR]:
                Lay.blur(z, d[ok.BACKDROP_BLUR])

            Gegl.cubism(
                z,
                size=d[ok.TILE_SIZE],
                amount=5.,
                seed=d[ok.RANDOM_SEED] + cat.seed_global
            )

            z1 = Lay.clone(z)
            z1.mode = z.mode = fu.LAYER_MODE_SOFTLIGHT

            Gegl.edge(z1)
            pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

            z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

            Gegl.saturation(z, d[ok.SATURATION])

            z.mode, z.opacity = RenderHub.get_mode(d)

            Lay.clone(o.z)

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            return RenderHub.bump(z, d[ok.BUMP])
