#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_extract import Render
from roller_one_fu import Lay, Sel
from roller_one_rect_table import RectTable
import gimpfu as fu

pdb = fu.pdb


def make_sel(o, effect_layer, frame_sel, _):
    """
    Draw the wire framework.

    The framework will later mesh with BorderLine.

    o: One
        Has options.

    effect_layer: layer
        Has frame from BorderLine.

    frame_sel: Selection
        of frame around image

    _: Selection
        not used

    Return: state of selection
    """
    cat = Hat.cat
    j = cat.render.image
    z = Lay.add(j, o.k, parent=effect_layer.parent)
    d = o.d
    w, h = Render.size()
    w1 = d[ok.LINE_WIDTH]
    w2 = d[ok.COMPOSITION_FRAME_WIDTH]
    w3 = w2 + w2

    if w2:
        pdb.gimp_selection_all(j)
        Sel.rect(j, w2, w2, w - w3, h - w3, option=fu.CHANNEL_OP_SUBTRACT)

    Sel.load(j, frame_sel, option=fu.CHANNEL_OP_ADD)

    sel = cat.save_short_term_sel()

    pdb.gimp_selection_none(j)

    if d[ok.LINE_WIDTH]:
        grid = RectTable((w, h), d[ok.ROW], d[ok.COLUMN]).table

        for r in range(1, d[ok.ROW]):
            Sel.rect(j, 0, grid[r][0].y, w, w1, option=fu.CHANNEL_OP_ADD)
        for c in range(1, d[ok.COLUMN]):
            Sel.rect(j, grid[0][c].x, 0, w1, h, option=fu.CHANNEL_OP_ADD)

    Sel.fill(z, (0, 0, 0))
    pdb.gimp_selection_none(j)
    pdb.plug_in_waves(
        j, z,
        d[ok.WAVE_AMPLITUDE],
        1,
        d[ok.WAVELENGTH],
        0,
        1
    )
    pdb.gimp_selection_none(j)
    pdb.plug_in_whirl_pinch(j, z, d[ok.WHIRL], 0, 2.)
    Sel.item(z)
    Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
    j.remove_layer(z)


class RadWave:
    """Add a wire framework to BorderLine using waves."""

    @staticmethod
    def do(o):
        """
        Do the Rad Wave image-effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer
            with Rad Wave
        """
        # Preserve.
        q = pdb.gimp_context_get_foreground()

        z = BorderLine.do(o, framer=make_sel)

        # Restore.
        pdb.gimp_context_set_foreground(q)

        return z
