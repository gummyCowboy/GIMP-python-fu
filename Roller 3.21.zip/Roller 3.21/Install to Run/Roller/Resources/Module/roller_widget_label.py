#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok, Widget as wk
from roller_model_table import Grid
from roller_one_extract import Path
from roller_one import One
from roller_one_extract import Render
from roller_widget import Widget
import gtk


def update_cell_table(path):
    """
    The cell margins need an up-to-date Grid.

    path: tuple
        of step

    Return: Grid
        Has cell table.
    """
    grid = Grid(One(path=path))
    grid.layer_margin = Path.get_layer_margin(path)
    grid.update_grid(One(d=Path.get_grid_from_path(path)))
    grid.calc_pocket(One(d=Path.get_cell_margin(path)))
    return grid


class Label(Widget):
    """Is a custom GTK Label."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.Label(d[wk.TEXT])
        d[wk.ALIGN] = d[wk.ALIGN] if wk.ALIGN in d else (0, 0, 0, 0)

        Widget.__init__(self, g, **d)
        self.add(g)

    def destroy(self):
        """Destroy the widget and sub-widgets."""
        self.label.destroy()
        self.destroy()

    @staticmethod
    def get_value():
        """
        Is a Widget preset template function.

        a: undefined
            not used
        """
        return None

    def set_label_value(self, a):
        """
        Change the display value of the label.

        a: string
            the new display value
        """
        if isinstance(a, str):
            self.widget.set_label(a)

    def set_value(self, a):
        """
        Is a Widget preset template function.

        a: undefined
            not used
        """
        return


class GridLabel(Label):
    """Is a Label for displaying row and column counts."""

    TEMPLATE = "Row: {}, Column: {}"

    def __init__(self, **d):
        """
        Initialize the Label widget.

        d: dict
            Has init values for Widget.
        """
        d[wk.TEXT] = GridLabel.TEMPLATE.format(0, 0)
        d[wk.ALIGN] = 0, 0, 1, 1

        Label.__init__(self, **d)

        self._grid = None
        self._path = self.group.path
        self._render_size = 0, 0
        self._layer_margin = {}
        self._grid_d = {}
        self._d = {}
        self.container.connect('expose-event', self._on_expose)

    def _on_expose(self, *_):
        """Respond to an expose event."""
        self.update_size()

    def update_size(self):
        """Update the label after a change."""
        d = self.group.preset.get_value()
        d[ok.PER_CELL] = []
        size = Render.size()
        d1 = Path.get_layer_margin(self._path)

        if (
            d != self._d or
            self._render_size != size or
            self._layer_margin != d1
        ):
            self._grid = update_cell_table(self._path)

        if self._grid:
            r, c = self._grid.division
            self.set_label_value(GridLabel.TEMPLATE.format(r, c))

        self._d = d
        self._layer_margin = d1
        self._render_size = size
