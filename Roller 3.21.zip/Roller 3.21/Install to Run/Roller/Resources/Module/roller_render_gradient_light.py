#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat, One
from roller_one_extract import Render
from roller_one_fu import Lay, Mage, Sel
from roller_option_preset_dict import PresetDict
import gimpfu as fu

pdb = fu.pdb


class GradientLight:
    """
    Has functions used to make the GradientLight layer and its influence.
    """
    image = None

    @staticmethod
    def apply_light(z, k):
        """
        Add gradient light influence to a layer.

        z: layer
            to receive effect

        k: string
            option key
            of Influence preset

        Return: layer
            the original or its alter
        """
        def apply_it():
            """
            Apply the gradient light to the layer.

            Return: layer
                with the gradient light
            """
            Mage.copy_all(GradientLight.image)

            j = cat.render.image
            z1 = Lay.paste(z)
            z1.opacity = 100.
            z2 = z

            if k == ok.METAL_FRAME:
                # Create a slight reflection for the metal frame edge.
                Sel.item(z2)
                pdb.gimp_selection_shrink(j, 1)

                if Sel.is_sel(j):
                    sel = pdb.gimp_selection_save(j)

                    Sel.item(z2)
                    Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

                    sel1 = pdb.gimp_selection_save(j)

                    Lay.hide(z1)
                    Lay.hide(z2)
                    Mage.copy_all(j)

                    z3 = Lay.paste(z2)
                    z3.opacity = 9.

                    # Mix in the image material.
                    Lay.blur(z3, 12)

                    Sel.load(j, sel1)
                    Sel.invert_clear(z3)
                    Lay.show(z1)
                    Lay.show(z2)

                    z2 = pdb.gimp_image_merge_down(j, z3, fu.CLIP_TO_IMAGE)

                    pdb.gimp_image_remove_channel(j, sel)
                    pdb.gimp_image_remove_channel(j, sel1)

                # Create a metallic appearance.
                z1.mode = fu.LAYER_MODE_HARDLIGHT

            Sel.item(z2)
            Sel.invert_clear(z1)

            opacity = z2.opacity
            z1.opacity = f
            z1 = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
            z1.opacity = opacity
            return z1

        def process_layer():
            """
            Add gradient light to a layer.

            Return: layer
                with gradient light added
            """
            if GradientLight.image:
                return apply_it()
            else:
                GradientLight.create_gradient_light(d)
                return apply_it()

        if z:
            cat = Hat.cat
            d = cat.gradient_light_d
            f = d[ok.INFLUENCE][k]
            if f:
                if pdb.gimp_item_is_group(z):
                    for z in z.layers:
                        process_layer()
                else:
                    z = process_layer()
        return z

    @staticmethod
    def create_gradient_light(d):
        """
        Create a gradient light image.
        The image is hidden from the user
        and is removed during program closing
        or by a GradientLight undo operation.

        Layers are created from the image
        using copy visible.

        d: dict
            of gradient light
        """
        w, h = Render.size()
        j = GradientLight.image = pdb.gimp_image_new(w, h, fu.RGB)
        e = PresetDict.get_default(by.GRADIENT_FILL)

        e.update(d)
        GradientFill.do_layer(j, One(d=e))
