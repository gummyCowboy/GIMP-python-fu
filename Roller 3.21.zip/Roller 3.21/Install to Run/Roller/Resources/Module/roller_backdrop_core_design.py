#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Base, Hat, One
from roller_one_extract import Render
from roller_one_fu import Lay, Sel
from roller_one_rect_table import RectTable
from roller_option_preset_dict import PresetDict
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


def do_gradient(d, group, offset):
    """
    Draw a gradient.

    d: dict
        Has options.

    group: group layer
        to place gradient layer

    offset: int
        where to put the new layer

    Return: layer
        with gradient
    """
    j = Hat.cat.render.image
    z = GradientFill.do_layer(j, One(d=d))
    pdb.gimp_image_reorder_item(j, z, group, offset)
    return z


def do_select(q):
    """
    Select an area defined by an array of points.

    q: iterable
        rectangle points
    """
    Sel.polygon(Hat.cat.render.image, q, option=fu.CHANNEL_OP_ADD)


def double(z, m=0):
    """
    Duplicate a layer and flip it depending on a flag.

    z: layer
        the layer where the gradient goes above it

    m: flag
        If it's true, the layer is flipped horizontally.
    """
    z1 = Lay.clone(z)

    Lay.flip(z1, horizontal=m)
    return z1


class CoreDesign:
    """
    Has lines that resemble a cube projection using
    inverted triangles and gradients.
    """

    @staticmethod
    def do(o):
        """
        Do the Core Design backdrop-style.

        o: One
            Has variables.

        Return: layer or None
            with Core Design
        """
        cat = Hat.cat
        j = cat.render.image
        d = o.d
        if d[ok.OPACITY]:
            n = o.k
            gradients = cat.gradient_list
            e = PresetDict.get_default(by.GRADIENT_FILL)
            w, h = Render.size()
            color = tuple([255 - i for i in d[ok.COLOR]])
            opacity = d[ok.OPACITY]
            d[ok.OPACITY] = 100.

            e.update(d)

            grid = RectTable((w, h), e[ok.ROW], e[ok.COLUMN]).table
            group = Lay.group(j, o.k)

            # Calculate the points using their relative position.
            h1 = h // 5

            # The triangle is facing down.
            q = 0, h1, w, h1, w // 2, h

            e[ok.START_X], e[ok.START_Y] = (0, .5), (0, 1.)
            e[ok.END_X], e[ok.END_Y] = (0, .5), (0, .2)
            z = do_gradient(e, group, 0)
            z.mode = fu.LAYER_MODE_DARKEN_ONLY

            do_select(q)
            Sel.invert_clear(z, keep_sel=True)
            RenderHub.do_stylish_shadow(z, intensity=50.)

            z1 = double(z)

            RenderHub.do_stylish_shadow(z1, intensity=50.)
            pdb.gimp_selection_none(j)

            # horizontal
            for r1 in range(0, e[ok.ROW], 2):
                Sel.rect(j, 0, grid[r1][0].y, w, grid[r1][0].h)

            Lay.clear_sel(z1)
            RenderHub.do_stylish_shadow(z1, intensity=50.)

            # vertical
            for c1 in range(0, e[ok.COLUMN], 2):
                Sel.rect(j, grid[0][c1].x, 0, grid[0][c1].w, h)

            Lay.clear_sel(z)
            RenderHub.do_stylish_shadow(z, intensity=50.)

            # background gradient
            if n in gradients:
                n = Base.enumerate_name(n, gradients)

            # The option name is needed in the gradient list so that
            # 'RenderHub.set_gradient' will pass the gradient-exists test.
            gradients += [n]

            grad = e[ok.GRADIENT] = pdb.gimp_gradient_new(n)
            e[ok.OFFSET] = e[ok.REVERSE] = 0

            pdb.gimp_gradient_segment_set_right_color(grad, 0, color, 100.)
            pdb.gimp_gradient_segment_set_left_color(
                grad,
                0,
                d[ok.COLOR],
                100.
            )

            # left
            e[ok.START_X] = 0, .0
            e[ok.START_Y] = e[ok.END_X] = e[ok.END_Y] = 0, .5

            pdb.gimp_selection_none(j)

            z = do_gradient(e, group, len(group.layers))
            q = 0, 0, 0, h, w // 2 + 1, h // 2

            do_select(q)
            Sel.invert_clear(z)

            double(z, m=1)

            # top
            e[ok.START_Y] = 0, .0
            e[ok.START_X] = e[ok.END_X] = e[ok.END_Y] = 0, .5
            z = do_gradient(e, group, len(group.layers))
            q = 0, 0, w, 0, w // 2, h // 2 + 1

            do_select(q)
            Sel.invert_clear(z)
            double(z)
            pdb.gimp_gradient_delete(grad)
            gradients.pop(-1)
            Lay.clone(o.z)

            z = Lay.merge_group(group)
            z.opacity = opacity
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            return RenderHub.bump(z, d[ok.BUMP])
