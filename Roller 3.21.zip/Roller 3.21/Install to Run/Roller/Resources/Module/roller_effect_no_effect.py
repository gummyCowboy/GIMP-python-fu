#!/usr/bin/env python
# -*- coding: utf-8 -*-


class NoEffect:
    """
    Don't do anything. Use so a preview
    without an effect can show images.
    """

    @staticmethod
    def do(o):
        """
        Is an image-effect template function.

        o: One
            Has variables.
            not used
        """
        return
