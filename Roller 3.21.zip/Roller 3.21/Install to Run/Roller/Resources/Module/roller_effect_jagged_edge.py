#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_key import Layer as nk, Option as ok
from roller_constant_fu import Fu
from roller_one import Hat
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb
ta = Fu.ThresholdAlpha


def process_layer(j, image_layer, o):
    """
    Add a frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    cat = Hat.cat
    d = o.d
    z = Lay.clone(image_layer)

    Lay.apply_mask(z)

    # the image layer with the Jagged Edge effect, 'z1'
    z1 = Lay.clone(z)

    cat.seed(d)
    Sel.item(z)
    pdb.gimp_selection_shrink(j, max(d[ok.AMPLITUDE] + 1, 6))
    Sel.invert_clear(z)
    Lay.hide(image_layer)

    for x in range(4):
        a = randint(0, 1)
        pdb.plug_in_shift(j, z, randint(1, d[ok.AMPLITUDE]), a)
        pdb.plug_in_shift(j, z, randint(1, d[ok.AMPLITUDE]), int(not a))

    pdb.plug_in_oilify(j, z, d[ok.SMOOTHNESS], Fu.Oilify.RGB_MODE)
    pdb.plug_in_threshold_alpha(j, z, ta.THRESHOLD_ALL)

    # Transfer the alpha to make a Jagged Edge.
    Sel.item(z)
    Sel.invert_clear(z1)

    j.remove_layer(z)
    z1.name = Lay.name(z1.parent, o.k)

    cat.del_image_layer(image_layer.name)
    cat.save_image_layer(z1, z1.name)
    return z1


class JaggedEdge:
    """Create a jagged edge around image material."""

    @staticmethod
    def do(o):
        """
        Do the Jagged Edge image-effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer, list, or None
            Is jagged edge.
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # 'undo_z' is a list of layers for the preview's undo function.
        undo_z = []
        o.shadow_layer = [z]

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], o)]

        else:
            if pdb.gimp_item_is_group(z):
                z1 = Lay.clone(z)
                z1 = Lay.merge_group(z1)
                z2 = process_layer(j, z1, o)

                Lay.remove(z1)
                Sel.item(z2)
                Lay.remove(z2)

                mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)

                pdb.gimp_layer_add_mask(z, mask)

                # The undo process needs layer
                # 'z' as a the mask removal reference.
                undo_z = [mask, z]
            else:
                undo_z = process_layer(j, z, o)
                o.shadow_layer = [undo_z]
                Hat.cat.register_layer(
                    (o.render_type, o.model_name, nk.IMAGE),
                    undo_z
                )
        return undo_z
