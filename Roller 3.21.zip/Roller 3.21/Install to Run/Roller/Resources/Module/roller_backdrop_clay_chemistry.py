#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_fu import Fu
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat, One
from roller_one_fu import Lay, Mage
from roller_one_gegl import Gegl
from roller_option_preset_dict import PresetDict
from roller_render_hub import RenderHub
import gimpfu as fu

er = Fu.Erode
hs = Fu.HueSaturation
pdb = fu.pdb


class ClayChemistry:
    """
    Has a dark texture, colorful smokey lines,
    and is mixed with gradient's color.
    """

    @staticmethod
    def do(o):
        """
        Do the backdrop-style.

        o: One
            Has variables.

        Return: layer or None
            Is the backdrop-style.
        """
        cat = Hat.cat
        j = cat.render.image
        z = None

        if Lay.has_pixel(o.z):
            # Clay Chemistry preset dict, 'd'
            d = o.d

            # backdrop image layer, 'z'
            z = Lay.clone(o.z)

            group = Lay.group(j, o.k, layer=z)
            z1 = Lay.clone(z)

            Gegl.blur(z, 250)

            n = z1.name = "Painted_Rock"
            z1.mode = fu.LAYER_MODE_HSV_HUE

            pdb.plug_in_gimpressionist(j, z1, n)
            Mage.copy_all(j)

            z = Lay.paste(z1)
            z.mode = fu.LAYER_MODE_DIFFERENCE

            Gegl.edge(z)
            Mage.copy_all(j)

            z = Lay.paste(z)
            z.mode = fu.LAYER_MODE_EXCLUSION

            Lay.dilate(z)
            Gegl.waterpixels(z)
            Gegl.unsharp_mask(z, 3., 30., .0)
            Mage.copy_all(j)

            z = Lay.paste(z)
            z = Lay.clone(z)
            z.mode = fu.LAYER_MODE_LINEAR_LIGHT

            Gegl.blur(z, 6)
            Mage.copy_all(j)

            z = Lay.paste(z)

            Lay.dilate(z)
            Lay.dilate(z)

            z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
            z1 = Lay.merge_group(group)
            group = Lay.group(j, o.k, layer=z1)

            z2 = Lay.clone(z1)

            Gegl.waterpixels(z2)

            z2.mode = fu.LAYER_MODE_LUMA_LIGHTEN_ONLY
            z2 = Lay.merge(z2)
            z3 = Lay.clone(z2)

            Gegl.median_blur(z3, 32, 50.)

            z4 = Lay.clone(z3)
            z4.mode = fu.LAYER_MODE_PIN_LIGHT

            Gegl.edge(z4)
            pdb.plug_in_erode(
                j, z4,
                er.PROPAGATE_BLACK,
                er.RGB_CHANNELS,
                er.FULL_RATE,
                er.DIRECTION_MASK_7,
                er.LOW_LIMIT_0,
                er.UPPER_LIMIT_255
            )
            Mage.copy_all(j)

            z = Lay.paste(z4)
            z2.mode = fu.LAYER_MODE_OVERLAY

            pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
            Gegl.emboss(z2, cat.azimuth, 12., 1.)
            Lay.hide(z3)
            Lay.hide(z4)

            e = PresetDict.get_default(by.GRADIENT_FILL)
            e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
                RenderHub.get_gradient_factors(d[ok.GRADIENT_ANGLE])

            e.update(d)

            z1 = GradientFill.do_layer(z.image, One(d=e, k="Gradient"))
            z1.mode, z1.opacity = RenderHub.get_mode(d)

            pdb.gimp_image_reorder_item(j, z1, group, len(group.layers))

            z = Lay.add(j, "Back", parent=group, offset=len(group.layers) + 1)
            z.opacity = z1.opacity

            Lay.color_fill(z, (64, 64, 64))

            z = Lay.clone(o.z)

            Lay.blur(z, 500)
            pdb.gimp_image_reorder_item(j, z, group, len(group.layers) + 1)

            z = Lay.merge_group(group)
            z = RenderHub.bump(z, d[ok.BUMP])
        return z
