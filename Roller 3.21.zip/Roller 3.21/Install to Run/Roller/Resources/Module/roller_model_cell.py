#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Cell(object):
    """Use with cell table to hold cell values."""

    def __init__(self, s, r, c, is_cell):
        """
        Create a cell storage object.

        s: tuple
            cell size
            in cells

        r, c: int
            cell index

        is_cell: flag
            Use with hexagonal.
        """
        # size in cells
        self.s = s

        # row and column cell table indices
        self.r, self.c = r, c

        # Cell: If the cell is not a topleft cell,
        # then this is its topleft cell.
        self.topleft = None

        # ColorButtons on the side of the cell in the cell window
        self.top_button = self.left_button = None

        # flag: Is true if the cell is not
        # a hexagonal cell with invalid offsets.
        self.is_cell = is_cell

        # flag: Is true when the cell has an image assigned.
        self.has_pic = False

        # VBox with padding
        self.pad_box = None

        # Is an event box or a colored button.
        self.box = None

    @property
    def is_dependent(self):
        """
        Dependent cells are not a topleft cell,
        but part of a group of merged cells.
        """
        return self.s == (-1, -1)

    @property
    def is_group(self):
        """Group cells are merged cells."""
        return self.is_topleft or self.s == (-1, -1)

    @property
    def is_not_pic_cell(self):
        """
        Determine if the cell has a picture.

        Return: flag
            Is true if the cell does not have a picture.
        """
        return not self.has_pic or not self.is_cell

    @property
    def is_topleft(self):
        """
        Determine if a cell is a topleft cell.

        Return: flag
            Is true if the cell is a topleft cell.
        """
        return (self.s[0] >= 1 or self.s[1] >= 1) and self.is_cell

    @property
    def corners(self):
        """
        Return the row and column for the
        cell and its bottom-right cell.
        """
        s = self.r, self.c
        t = s[0] + self.s[0] - 1, s[1] + self.s[1] - 1
        return s, t
