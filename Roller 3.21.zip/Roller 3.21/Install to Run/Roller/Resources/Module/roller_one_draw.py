#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Draw:
    """Has globals that need to be alone."""
    # Use to indicate that the interface is in a drawing state, and
    # that any event handler can ignore a change or an action event.
    load_count = 0

    # Set when loading a SuperPreset.
    preset_load_count = 0
