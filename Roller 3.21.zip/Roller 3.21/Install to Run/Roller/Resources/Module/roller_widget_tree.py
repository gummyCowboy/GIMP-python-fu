#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color as co, Widget as fw
from roller_one import Base
from roller_constant_key import Model as md, Widget as wk
from roller_widget import Widget
from roller_widget_box import Box, Eventful, VBow
from roller_widget_button import Button
from roller_widget_label import Label
import gtk

# Let GTK know a signal is processed.
DONE = True


def create_box(g, color):
    """
    Create a box for the navigation list.
    Keep the list from destroying the container's label.

    g: container
        container for box

    color: int
        for the Eventful background
    """
    box = Eventful(color)
    vbox = VBow()

    box.add(vbox)
    g.add(box)
    return vbox


class TreeViewList(Widget):
    """Is a base for a TreeView list widget."""

    def __init__(self, **d):
        """
        Create a TreeView list.

        d: dict
            Has init values.
        """
        self._update_window = d[wk.ON_WIDGET_CHANGE]
        self.background_color = d[wk.COLOR]
        self.list_store = None
        tree = self.treeview = gtk.TreeView()
        tree.set_headers_visible = 0

        if wk.HEADER not in d:
            d[wk.HEADER] = ""

        if wk.MINIMUM_WIDTH not in d:
            d[wk.MINIMUM_WIDTH] = 1

        Widget.__init__(self, tree, **d)
        self.reset_list_store()

        # Create a column.
        col = gtk.TreeViewColumn(
            d[wk.HEADER],
            gtk.CellRendererText(),
            text=0,
            foreground=1,
            background=2
        )

        col.set_min_width(d[wk.MINIMUM_WIDTH])

        # Add the column to the TreeView.
        tree.append_column(col)

        if not d[wk.HEADER]:
            # Hide the column header.
            col.set_widget(gtk.Label(""))

        # The treeview cursor-changed signal will send a signal
        # when a row is clicked even if the row is already selected.
        tree.connect('cursor_changed', self.on_change)

    def append_item(self, n):
        """
        Add an item to the list.

        n: string
            item to add
        """
        self.list_store.append([n, '#000000', self.background_color])

    def get_sel_x(self):
        """
        Get the row index of the selected item.

        Return: int or None
            in 0 to n
        """
        x = q1 = None
        q = self.treeview.get_selection()

        if q:
            # GtkTreeIter, 'q1'
            q1 = q.get_selected_rows()[1]

        if q1:
            x = q1[0][0]
        return x

    def get_value(self):
        """
        Get the selected item in the list.

        Return: string
            from the list selection
        """
        n = None
        q = self.treeview.get_selection()

        if q:
            model, _iter = q.get_selected()
            if _iter:
                n = model.get_value(_iter, 0)
        return n

    def on_change(self, *_):
        """Use to insert self into the change argument."""
        self._update_window(self)

    def populate_treeview(self, q):
        """
        Populate the TreeView from a list.
        The previous indexed-list is replaced.

        q: list
            of string
        """
        self.reset_list_store()

        # Append items to list.
        for n in q:
            self.append_item(n)

    def rename_item(self, x, n):
        """
        Change the name of an item in the TreeView.

        x: int
            index to row

        n: string
            new item name
        """
        for x1, r in enumerate(self.list_store):
            if x == x1:
                self.list_store.set_value(r.iter, 0, n)

    def reset_list_store(self):
        """
        Replace the ListStore with a new one as
        old one's iterator is probably used up.
        """
        # Replace "TreeView.ListStore's" iterator.
        self.list_store = gtk.ListStore(str, str, str)
        self.treeview.set_model(self.list_store)

    def select_item(self, x):
        """
        Select a TreeView item.

        x: int
            row index in the TreeView
            in 0 to n
        """
        self.treeview.set_cursor(x)

        selection = self.treeview.get_selection()
        if selection:
            model, _iter = selection.get_selected()
            if _iter:
                path = model.get_path(_iter)
                self.treeview.scroll_to_cell(path)

    def set_value(self, q):
        """
        Load the treeview from a list.

        Initialize group visibility tracking.

        q: iterable
            of items to display in list
        """
        self.populate_treeview(q)


class ChoiceList(TreeViewList):
    """Is a treeview composed of a list."""

    def __init__(self, **d):
        """
        Create a treeview list.

        Use for when the value is a string.
        """
        d[wk.COLOR] = '#00FEFF'
        g1 = self.scrolled_window = gtk.ScrolledWindow()

        TreeViewList.__init__(self, **d)
        self.populate_treeview(d[wk.LIST])
        g1.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        g1.add(self.treeview)
        d[wk.CONTAINER].pack_start(g1, expand=True)

        # Select the previous choice for the user.
        x = d[wk.LIST].index(d[wk.CHOICE]) \
            if d[wk.CHOICE] in d[wk.LIST] else 0

        self.treeview.set_cursor(x)

        selection = self.treeview.get_selection()
        model, _iter = selection.get_selected()
        if _iter:
            path = model.get_path(_iter)
            self.treeview.scroll_to_cell(path)


class OptionList(TreeViewList):
    """Is a treeview composed of a list."""

    def __init__(self, **d):
        """
        Create a treeview list.

        d: dict
            Has options.

            list: list
                for treeview list

            choice: string
                an initial choice

            on_accept: function
                callback on return key
        """
        self.choices = d[wk.LIST]
        g = gtk.ScrolledWindow()
        d[wk.COLOR] = '#D7D7FF'
        d[wk.MINIMUM_WIDTH] = 1

        TreeViewList.__init__(self, **d)
        self.populate_treeview(self.choices)

        # Initialize the iterator.
        self.select_item(0)

        vbox = gtk.VBox()
        hbox = gtk.HBox()
        label = gtk.Label("\n" * 12)

        hbox.pack_start(label, expand=1)
        hbox.pack_start(g, expand=1)
        vbox.pack_start(hbox, expand=True)
        g.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        g.add(self.treeview)
        self.add(vbox)

    @property
    def option_group(self):
        """
        Set the option group for the tree view list.

        The tree view list sends signals where
        the listener requires the option group.
        """
        return self.treeview.option_group

    @option_group.setter
    def option_group(self, a):
        """
        Return: OptionGroup
            of the tree view list
        """
        self.treeview.option_group = a

    def set_value(self, n):
        """
        Select an item in the list.

        n: string
            item to select
        """
        self.treeview.set_cursor(
            self.choices.index(n) if n in self.choices else 0
        )

        selection = self.treeview.get_selection()
        if selection:
            model, _iter = selection.get_selected()
            if _iter:
                path = model.get_path(_iter)
                self.treeview.scroll_to_cell(path)


class NavigationList(TreeViewList):
    """Is a GTK TreeView with a ListStore to make a list display."""

    def __init__(self, **d):
        """
        Create the navigation list.

        g: GTK container
            to receive the TreeView
        """
        w = fw.MARGIN

        # Node branches connect to VBoxes found in 'self._groupie'.
        self._groupie = []

        hbox = Box(box=gtk.HBox)
        d[wk.COLOR] = co.LIST_CELL_COLOR

        TreeViewList.__init__(self, **d)
        self.add(self.treeview)

        if d[wk.ITEM_COUNT] > 14:
            g1 = gtk.ScrolledWindow()
            g1.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
            g1.add(self)

        else:
            g1 = self

        hbox.add(g1)
        hbox.set_padding(2, 2, w, w)
        d[wk.CONTAINER].add(hbox)

    def remove_item(self, x):
        """
        Remove an item from the list.

        x: int
            row number
        """
        if x < 0:
            x = len(self._groupie) + x
        for x1, r in enumerate(self.list_store):
            if x == x1:
                self._groupie.pop(x)
                self.list_store.remove(r.iter)
                break


class Node(NavigationList):
    """
    Is a navigation item list where an item descriptor
    is part of a path to an option group.
    """

    def __init__(self, **d):
        """
        Draw navigation groups.

        d: dict
            Has init values.
        """
        # 'q', a list of strings that correspond
        # with the Node's list of item descriptors.
        q = [i.split(",")[0] for i in d[wk.LABELS]]

        self.original_length = len(q)
        g = d[wk.CONTAINER]
        g.node_ = self
        self.level = d[wk.LEVEL]
        self.junctions = d[wk.NAV_BOX].junctions
        g1 = self._box = d[wk.CONTAINER] = create_box(g, d[wk.COLOR])
        d[wk.ON_WIDGET_CHANGE] = d[wk.PORT].on_list_change

        NavigationList.__init__(self, item_count=len(q), **d)

        for i in q:
            self.append_group(i, None)

        self.key = d[wk.GROUP_KEY]

        # Use to update widget visibility.
        g1.connect('expose-event', self._on_expose)

    def _on_expose(self, *_):
        """
        Call when the node is exposed or becomes visible.

        _: VBow, GTK Event
            container for this Node,
            not used
        """
        x = self.get_sel_x()
        x = x if x is not None else 0

        self.select_item(x)
        return True

    def append_group(self, label, vbox):
        """
        Add a group to the end of a node's item list.

        label: string
            name of the option for the group label

        vbox: VBow or None
            group container

        Return: VBow
            group container
            a gtk.VBox
        """
        self.append_item(label)

        if not vbox:
            vbox = VBow()

        label = label.split(",")[0]
        g = vbox.label_ = Label(
            text="{}:".format(label),
            padding=(4, 4, 4, 4),
            expand=True
        )

        self._groupie.append(vbox)
        vbox.pack_start(g, expand=True)
        return vbox

    def get_groupie(self, x):
        """
        Get the VBox reference from the Node list's selection index.

        x: int
            selection index into the Node item list

        return: VBox or None
            the VBox connected to the Node branch
        """
        return self._groupie[x]

    def get_groupie_with_label(self, n):
        """
        Get the VBox reference from the Node's label list.

        n: string
            label to match

        return: VBox or None
            the VBox, used by an option group, that branches from a node label
        """
        n = n.split(",")[0]
        q = self.get_value()
        if n in q:
            return self._groupie[q.index(n)]

    def get_item_value(self):
        """
        Get the selected item in the list.

        Return: string
            from the list selection
        """
        n = None
        q = self.treeview.get_selection()

        if q:
            model, _iter = q.get_selected()
            if _iter:
                n = model.get_value(_iter, 0)
        return n

    def get_value(self):
        """
        Get the items in the list.

        Return: list
            of node items from rows
        """
        q = []
        item = self.list_store.get_iter_first()

        while item is not None:
            q.append(self.list_store.get_value(item, 0))
            item = self.list_store.iter_next(item)
        return q

    def insert_row(self, x, n, vbox):
        """
        Insert a row into the Node list.

        x: int
            index to row

        n: string
            to insert as item
            Is group key.
        """
        self.list_store.set_value(
            self.list_store.insert(x),
            0,
            n.split(",")[0]
        )

        # Set the row's background color.
        for x1, i in enumerate(self.list_store):
            if x == x1:
                self.list_store[i.iter][2] = self.background_color
        self._groupie.insert(x, vbox)

    def is_valid_selection(self, x):
        """
        Determine if a value is valid selection.

        x: int or None
            a selection index

        Return: bool
            Is true when the selection value is valid.
        """
        if x is not None:
            if len(self._groupie) and len(self._groupie) >= x:
                return True
        return False

    def refresh_list(self, q):
        """
        Synchronize the order of a Node's branches with a list of strings.

        q: list
            of Node branch names
        """
        previous = self.get_value()
        groupie = self._groupie[:]
        for x, i in enumerate(q):
            if i != previous[x]:
                self.remove_item(x)
                self.insert_row(x, i, groupie[previous.index(i)])


class ModelList(TreeViewList):
    """
    Is a widget group with a TreeView and TreeView manipulation Buttons.
    """

    def __init__(self, **d):
        """
        Add an item list and associated buttons to a group.

        d: dict
            Has init values.
        """
        w = fw.MARGIN // 2
        self._buttons = []
        self.items = []
        hbox = Box(box=gtk.HBox, padding=(w, w, w, w))
        vbox = Box(padding=(0, 0, 0, w))
        self.key = d[wk.KEY]
        self._name = d[wk.NAME]
        self._on_create_model_list_item = d[wk.CREATE_ZLIST_ITEM]
        self._on_delete_zlist_item = d[wk.DELETE_ZLIST_ITEM]
        self._on_move_zlist_item = d[wk.MOVE_ZLIST_ITEM]
        self._on_model_list_change = d[wk.ON_WIDGET_CHANGE]

        d.update(
            {
                wk.ON_WIDGET_CHANGE: self._verify_buttons,
                wk.COLOR: '#00FEFF',
                wk.MINIMUM_WIDTH: 70
            }
        )
        TreeViewList.__init__(self, **d)
        self.treeview.set_tooltip_text(" Is the layer palette order. ")

        q = (
            ("New Custom Cell", self._create_cell_item, 0),
            ("New Stack", self._create_stack_item, 0),
            ("New Table", self._create_table_item, 0),
            ("Delete", self._del_item, 1)
        )

        for n, p, a in q:
            g = CoOpButton(n, p, a)
            self._buttons.append(g)

        q1 = self._buttons[:]
        scrolled_window = gtk.ScrolledWindow()
        up_arrow = gtk.Arrow(gtk.ARROW_UP, gtk.SHADOW_NONE)
        down_arrow = gtk.Arrow(gtk.ARROW_DOWN, gtk.SHADOW_NONE)
        up_move = self._move_up_button = CoOpButton(
            up_arrow,
            self._move_sel_up,
            2
        )
        down_move = self._move_down_button = CoOpButton(
            down_arrow,
            self._move_sel_down,
            2
        )

        pair = gtk.HBox()
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

        for i in (up_move, down_move):
            pair.pack_start(i, expand=1)
            same_size.add_widget(i.widget)

        q1.append(pair)

        for i in q1:
            vbox.add(i)

        self._dependent_buttons = self._buttons[-1], up_move, down_move
        scrolled_window.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        scrolled_window.add(self.treeview)
        hbox.add(vbox)
        hbox.add(scrolled_window)
        self.add(hbox)
        self._verify_buttons()

        # Connect events.
        self.treeview.connect('key_press_event', self._on_key_press)
        self.treeview.get_selection().connect('changed', self._verify_buttons)

    def _create_cell_item(self, _):
        """
        Create a new item.
        Enumerate the item name until
        a unique identifier is created.

        _: Widget
            not used
        """
        self._create_item(None, md.CELL)

    def _create_item(self, name, _type):
        """
        Create a new item.
        Enumerate the item name until
        a unique identifier is created.

        name: string
            identify the model instance

        _type: string
            identify the model type
        """
        q = [i[md.NAME_INDEX] for i in self.items]
        n = name if name is not None else Base.enumerate_name(_type, q)

        self.list_store.append([n, '#000000', self.background_color])
        self.items.append((n, _type))
        self._verify_buttons()
        self.select_item(len(self.items) - 1)
        self._on_create_model_list_item(self, n, _type)
        self._on_model_list_change(self)

    def _create_table_item(self, _):
        """
        Create a new item.
        Enumerate the item name until
        a unique identifier is created.

        _: Widget
            not used
        """
        self._create_item(None, md.TABLE)

    def _create_stack_item(self, _):
        """
        Create a new Stack-type item in the list.
        Enumerate the item name until
        a unique identifier is created.

        _: Widget
            not used
        """
        self._create_item(None, md.STACK)

    def _del_item(self, *_):
        """Delete a row in the TreeView."""
        x = self.get_sel_x()
        if x is not None:
            n = self.items[x][md.NAME_INDEX]

            self.items.pop(x)

            sel = self.widget.get_selection()
            if sel:
                # 'a, b', model, iter
                a, b = sel.get_selected()
                if b:
                    a.remove(b)
                    self._populate_list(self.items)
                    self._verify_buttons()
                    self._on_delete_zlist_item(self, n)
                    self._on_model_list_change(self)

    def _move_sel_down(self, *_):
        """
        Move a selection down one line in the TreeView.
        If 'x' selection is at the bottom of the list,
        then the item rotates to the top of the list.
        """
        x = x1 = self.get_sel_x()
        a = len(self.items)
        x += 1

        if x == a:
            x = 0

        self._update_treeview(x, x1)
        self._move_down_button.widget.grab_focus()
        self._on_move_zlist_item(self)
        self._on_model_list_change(self)

    def _move_sel_up(self, *_):
        u"""
        Move a selection up one line in the TreeView.
        If 'x' selection is at the top of the list, then
        the item rotates to the bottom of the list.
        """
        x = x1 = self.get_sel_x()
        a = len(self.items)
        x -= 1

        if x < 0:
            x = a - 1

        self._update_treeview(x, x1)
        self._move_up_button.widget.grab_focus()
        self._on_model_list_change(self)
        self._on_move_zlist_item(self)

    def _on_key_press(self, _, a):
        """
        Use to catch the delete and return keys.

        a: GTK Event
            of key-press
        """
        n = gtk.gdk.keyval_name(a.keyval)
        if len(self.items):
            if n == 'Delete':
                self._del_item()
                return DONE

    def _populate_list(self, q):
        """
        Populate the TreeView from a list.
        The previous indexed-list is replaced.

        q: list
            of (name, type)
        """
        self.reset_list_store()

        self.items = []
        for x, i in enumerate(q):
            self.list_store.append([i[md.NAME_INDEX], '#000000', '#00FEFF'])
            self.items.append(i)

    def _update_treeview(self, x, x1):
        """
        Update the list after a change.

        x: int
            new position

        x1: int
            old position
        """
        q = self.items[x1]

        self.items.pop(x1)
        self.items.insert(x, q)
        self._populate_list(self.items)
        self.select_item(x)

    def _verify_buttons(self, *_):
        """Verify the buttons dependent on the list quantity."""

        def disable_buttons():
            """
            Disable the dependent Buttons as there
            is no item selected in the ModelList.
            """
            for g_ in self._dependent_buttons:
                g_.disable()

        sel = self.treeview.get_selection()

        if sel:
            # GtkTreeIter, '_iter'
            _iter = sel.get_selected()[1]

            if _iter:
                # The move and delete Buttons are dependent
                # on their selection state and the list size.
                x = self.get_sel_x()
                for g in self._dependent_buttons:
                    if _iter and len(self.items) >= g.need and x is not None:
                        g.enable()
                    else:
                        g.disable()
            else:
                disable_buttons()
        else:
            disable_buttons()

    def get_value(self):
        """
        Get a list of strings displayed in the list.
        Is part of the Widget template.

        Return: list
            of z-list items
        """
        return self.items

    def rename_item(self, x, n):
        """
        Rename an item.

        x: the current list entry index
        n: name of item
        """
        super(ModelList, self).rename_item(x, n)
        self.items[x] = n, self.items[x][md.TYPE_INDEX]

    def set_value(self, q, is_preset=False):
        """
        Load the item list from the owner's list.

        Is part of the Widget template.
        """
        if is_preset:
            while self.items:
                self.select_item(0)
                self._del_item()

        else:
            self.items = q
            self._populate_list(q)
        if is_preset:
            for i in q:
                self._create_item(*i)


class CoOpButton(Button):
    """
    Has a variable, 'self.need'.
    'self.need' is the number of items in a list
    needed for the Button to be valid.
    """

    def __init__(self, text, callback, need, **d):
        """
        text: string
            Button Label
            or gtk.Arrow

        callback: function
            Call on action.

        need: int
            the number of items needed for this Button to be valid
        """
        self.need = need
        Button.__init__(self, text=text, on_widget_change=callback, **d)
