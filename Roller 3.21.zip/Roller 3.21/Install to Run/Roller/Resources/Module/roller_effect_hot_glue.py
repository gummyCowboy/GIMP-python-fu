#!/usr/bin/env python
# -*- coding: utf-8 -*-
# from roller_constant_fu import Fu
from roller_constant_key import Effect as ek, Option as ok
from roller_one import Hat, One
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_option_preset_dict import PresetDict
from roller_render_gradient_light import GradientLight
from roller_render_shadow import Shadow
import gimpfu as fu

pdb = fu.pdb
YES_REFLECTIVE = COMPENSATE_FOR_DARK = True
ELEVATION_45 = 45
SMEARED = NO_INVERT = LINEAR_TYPE = ZERO_OFFSET_X = ZERO_OFFSET_Y = 0
ZERO_WATER_LEVEL = ZERO_AMBIENT_LIGHT = .0


def process_layer(j, image_layer, o):
    """
    Add a frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    if Sel.is_sel(j):
        cat = Hat.cat
        d = o.d

        if pdb.gimp_item_is_group(image_layer):
            z1 = Lay.clone(image_layer)
            z1 = Lay.merge_group(z1)
            z = image_layer = Lay.clone_opaque(z1)
            Lay.remove(z1)

        else:
            z = image_layer = Lay.clone_opaque(image_layer)

        group = Lay.group(j, o.k, parent=image_layer.parent, layer=z)
        e = PresetDict.get_default(ek.SHADOW_1)

        e.update(d)
        Lay.apply_mask(z)

        # the bump map layer, 'z1'
        z1 = Lay.add(j, "Frame", parent=group)

        Lay.color_fill(z1, (0, 0, 0))
        Sel.item(z)

        sel = Hat.cat.save_short_term_sel()

        Sel.grow(j, 1, 0)
        Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

        if d[ok.FRAME_WIDTH] > 1:
            Sel.grow(j, d[ok.FRAME_WIDTH] - 1, 0)

        Sel.fill(z1, (255, 255, 255))

        # the frame layer, 'z'
        z = Lay.clone_background(z1)
        depth = max(1, d[ok.BORDER_BLUR] // 2)

        pdb.gimp_selection_none(j)
        Lay.blur(z1, d[ok.BORDER_BLUR])
        Lay.blur(z, d[ok.BACKDROP_BLUR])
        pdb.plug_in_waves(
            j, z1,
            d[ok.WAVE_AMPLITUDE],
            d[ok.WAVE_PHASE],
            d[ok.WAVELENGTH],
            SMEARED,
            YES_REFLECTIVE
        )
        pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
        pdb.plug_in_bump_map(
            j, z, z1,
            cat.azimuth, ELEVATION_45, depth,
            ZERO_OFFSET_X, ZERO_OFFSET_Y,
            ZERO_WATER_LEVEL,
            ZERO_AMBIENT_LIGHT,
            COMPENSATE_FOR_DARK,
            NO_INVERT,
            LINEAR_TYPE
        )

        if e[ok.INTENSITY] and e[ok.SHADOW_BLUR]:
            shadow_layer = Shadow.do(
                One(
                    cast=(image_layer,),
                    d=e,
                    model_name=o.model_name,
                    parent=group,
                    name=Lay.name(o.parent, "Image Shadow")
                )
            )
            if shadow_layer:
                Sel.item(z1)
                Lay.clear_sel(shadow_layer)

        Sel.item(z1)
        Sel.invert_clear(z)
        pdb.gimp_image_reorder_item(j, z, group, 0)
        pdb.gimp_drawable_invert(z1, 0)
        j.remove_layer(image_layer)

        z.mode = fu.LAYER_MODE_DIFFERENCE
        z = Lay.merge_group(group)
        z = Lay.clone(z)
        z = Lay.merge(z)
        z = Lay.clone(z)
        q = [0, 0, 103, 0, 188, 215, 255, 255]

        pdb.gimp_curves_spline(z, fu.HISTOGRAM_VALUE, len(q), q)
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        Sel.item(z)
        pdb.gimp_context_set_feather(1)
        pdb.gimp_context_set_feather_radius(4., 4.)
        Sel.invert_clear(z)

        z.mode = fu.LAYER_MODE_ADDITION
        z = Lay.merge(z)
        z.name = Lay.name(o.parent, o.k)

        Gegl.unsharp_mask(z, 5., min(2., d[ok.BORDER_BLUR]), .0)
        return GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)


class HotGlue:
    """Create a translucent type of frame that has gluey tube appearance."""

    @staticmethod
    def do(o):
        """
        Do the image-effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer, list, or None
            Is border.
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # 'undo_z' is a list of layers for the preview's undo function.
        undo_z = []
        o.shadow_layer = [z]

        if o.is_nested_group:
            for i in z.layers:
                Sel.item(i)
                undo_z += [process_layer(j, i.layers[0], o)]

        else:
            Sel.item(z)
            undo_z = process_layer(j, z, o)
            if undo_z:
                o.shadow_layer = [undo_z, z]
        return undo_z
