#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Image as fi, Widget as fw
from roller_constant_key import (
    Group as gk,
    Option as ok,
    Pickle as pc,
    Step as sk,
    Widget as wk,
    Window as wi
)
from roller_model_image import Image
from roller_one import Comm, Hat, OZ
from roller_one_fu import Lay, Sel
from roller_option_preset import Preset
from roller_option_preset_core import Core
from roller_port_main import PortMain
from roller_render_gradient_light import GradientLight
from roller_window import Window
from roller_window_save import RWSave
import gimpfu as fu
import gobject
import gtk
import os

pdb = fu.pdb
CRITICAL = "Roller closed itself due to a critical error: "
DONE = 1
IE = ok.IMAGE_EFFECT


def verify_preset_folder():
    """
    The external directory is where preset files are stored.

    Return: flag
        It is true if the directory is verified.
    """
    go = False

    try:
        n = Hat.cat.preset_folder = os.path.join(
            Hat.cat.roller_path,
            u"Preset"
        )
        go = OZ.ensure_dir(n)[-1]

    except Exception as ex:
        Comm.show_err(ex)
        Comm.show_err(
            "The operating system isn't compatible with Roller."
        )
    return go


class WindowMain(Window):
    """Is the plug-in's main window."""

    is_iconify = True

    def __init__(self):
        """Has the GTK event loop."""
        if verify_preset_folder():
            self._load_window_pose()
            Image.make_image_list()

            self.canceled = True
            cat = Hat.cat
            dog = Hat.dog

            dog.option.create_frame_list()

            # Preserve the selection and active layer of open images.
            selections = []
            active_layer = []

            for _, j in Image.roller_image.items():
                active_layer.append((j.j, j.j.active_layer))
                if Sel.is_sel(j.j):
                    sel = pdb.gimp_selection_save(j.j)

                    selections.append((j.j, sel))
                    pdb.gimp_selection_none(j.j)

            # Prepare the Port.
            d = {wk.WINDOW_KEY: wi.MAIN}

            Window.__init__(self, d)

            d = {
                wk.ON_CANCEL: self.cancel,
                wk.ON_ACCEPT: self.accept_main,
                wk.WIN: self
            }
            self.port = PortMain(d)

            # Display the main window now that's been
            # initialized with widgets and values by PortMain.
            self.win.show_all()

            try:
                # Insert a signal processing function
                # into the main signal processing ring.
                # reference
                #   library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
                gobject.idle_add(dog.signal_filter.send)

                # Start the main signal processing ring.
                gtk.main()

            except Exception as ex:
                if self.win is not None:
                    self.close()
                    Comm.show_err(CRITICAL + repr(ex))
                raise

            # Close any opened images.
            for k, q in Image.opened_images.items():
                if k not in Image.image_names:
                    j = q[fi.IMAGE_INDEX].j

                    # The image may already been closed
                    # due to the global settings.
                    if pdb.gimp_image_is_valid(j):
                        pdb.gimp_image_delete(j)

            # Close the GradientLight image.
            if GradientLight.image:
                pdb.gimp_image_delete(GradientLight.image)

            # Restore the selection for open images.
            for i in selections:
                j, sel = i[0], i[1]

                Sel.load(j, sel)
                if pdb.gimp_item_is_valid(sel) and pdb.gimp_image_is_valid(j):
                    pdb.gimp_image_remove_channel(j, sel)

            # Restore the active layer for open images.
            for j, z in active_layer:
                if (
                    z and
                    pdb.gimp_item_is_valid(z) and
                    pdb.gimp_image_is_valid(j)

                ):
                    j.active_layer = z

            if cat.render.has_image:
                j = cat.render.image
                a = WindowMain

                if not self.canceled:
                    a.remove_unused_group(j)
                    a.remove_unused_layer(j)
                    a.merge_single(j)
                a.remove_unused_image_gradients()

            if not self.canceled and cat.render.has_image:
                # Select the bottom layer.
                j = cat.render.image
                if len(j.layers):
                    j.active_layer = j.layers[-1]
            Image.image_undo_end()

    def _load_window_pose(self):
        """Load the window position dictionary if it exists."""
        cat = Hat.cat
        n = self._window_pose_file = OZ.get_preset_path(
            u"Window Position",
            "",
            cat.preset_folder
        )
        d = OZ.pickle_load({pc.FILE: n, pc.SHOW_ERROR: False})

        if d:
            cat.window_pose = deepcopy(d)
            self._last_window_pose = deepcopy(d)
        else:
            self._last_window_pose = {}

    @staticmethod
    def _render(steps):
        """
        Render the form.

        steps: list
            of render steps
            k, v: path, dict of option group value
        """
        cat = Hat.cat

        Hat.dog.viewer.do(steps)
        if cat.render.has_image:
            j = cat.render.image
            z = j.layers[-1]
            z.name = z.name.split(":")[0] + " Finish"
            z1 = Hat.dog.plan.plan_group

            if z1:
                z1.name = z1.name.split(":")[0]

            j.active_layer = z
            pdb.gimp_selection_none(j)

    def _write_last_used(self, d, steps, last_session):
        """
        Write the last used dictionaries in the session.

        d: dict
            of preset
        """
        cat = Hat.cat
        go = True
        e = Core.translate_to_name(d)

        if e != last_session:
            go = self._write_option(e, gk.PRESET_STEPS)

        d1 = cat.group_dict
        q = set()

        # Before saving the step presets,
        # create a set of keys because
        # many preset-types are repeated.
        for step in steps:
            # Presets are identified by their group key.
            if step in d1:
                group = d1[step]
                if group.group_type == Preset and group.preset:
                    q.add(group.group_key)

        # Write a last-used preset for the collected set
        # of presets that was used in the render.
        # Reverse the order so that the last-used is correct.
        for step in reversed(steps):
            if go:
                # Presets are distinguished by their group key.
                if step in d1:
                    k = d1[step].group_key
                    if k in q:
                        q.remove(k)
                        go = self._write_option(d[step], k)

        # Save the window positions.
        if go:
            if cat.window_pose != self._last_window_pose:
                OZ.pickle_dump({
                    pc.DATA: cat.window_pose,
                    pc.FILE: self._window_pose_file
                })

    def _write_option(self, d, group_key):
        """
        Write a last-used file for a preset.

        d: dict
            Has last-used options.

        group_key: string
            option key/name
            Use to name file and its folder

        Return: bool
            Is true if the file was saved.
        """
        return RWSave.write(
            self.win,
            d,
            group_key,
            fw.LAST_USED,
            overwrite=True
        )

    def accept_main(self, steps, last_session):
        """
        Begin a render.

        steps: list
            of steps for the render

        last_session: dict
            of session

        Return: true
            The key-press was processed.
        """
        self.canceled = False
        cat = Hat.cat

        if cat.group_dict[sk.GLOBAL].d[ok.DELETE_PLANS].get_value():
            Hat.dog.plan.delete()

        else:
            Hat.dog.plan.delete_backdrop()

        # Render and save the options.
        WindowMain._render(steps)
        self._write_last_used(
            Core.get_steps(sk.STEPS,  with_list=False)[0],
            steps,
            last_session
        )

        self.close()

        # Clean-up.
        cat.del_long_term_sel()

        # for GTK
        return DONE

    @staticmethod
    def merge_single(j):
        """
        Remove any group layers without any children.
        Is recursive.

        j: GIMP image or layer group
            Is render.
        """
        if len(j.layers):
            for i in j.layers:
                if pdb.gimp_item_is_group(i):
                    WindowMain.merge_single(i)
                else:
                    if i.parent and len(i.parent.layers) == 1:
                        Lay.merge_single(i.parent)
                        break

    @staticmethod
    def remove_unused_layer(z):
        """
        Remove any layers without effect.
        Is recursive.

        z: layer or GIMP image
            Has sub-layers.
        """
        for i in z.layers:
            if not i.visible and not pdb.gimp_item_is_group(i):
                i.image.remove_layer(i)

            elif not i.opacity:
                i.image.remove_layer(i)
            elif pdb.gimp_item_is_group(i):
                # recursive
                WindowMain.remove_unused_layer(i)

    @staticmethod
    def remove_unused_group(a):
        """
        Remove any group layers without any children.

        a: GIMP image or layer group
            Is render.
        """
        if len(a.layers):
            for i in a.layers:
                if pdb.gimp_item_is_group(i):
                    if not len(i.layers):
                        i.image.remove_layer(i)

                    elif not i.visible and i.parent:
                        i.image.remove_layer(i)
                    else:
                        WindowMain.remove_unused_group(i)

    @staticmethod
    def remove_unused_image_gradients():
        """
        Delete any image gradients that were
        created but not saved with the render:
        """
        for grad in Hat.cat.image_gradients_created:
            if grad != Hat.cat.image_gradient_used:
                pdb.gimp_gradient_delete(grad)
