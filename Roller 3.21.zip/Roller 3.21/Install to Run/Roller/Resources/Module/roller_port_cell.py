#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Border as bo,
    Caption as pt,
    Color as co,
    Fringe as ng,
    Plaque as aq,
    Widget as fw
)
from roller_constant_key import (
    Group as gk,
    Option as ok,
    Path as pa,
    Widget as wk
)
from roller_model_cell import Cell
from roller_one import Base, One
from roller_one_extract import Form, Render, Shape
from roller_one_tip import Tip
from roller_option_group import OptionGroup
from roller_option_preset import NonPreset
from roller_port_preview import PortPreview
from roller_widget_box import Box, Eventful
from roller_widget_button import ColorfulButton, SwitchButton
from roller_widget_label import Label
from roller_window_cell_mod import WindowCellMod
import gtk

HEADER_COLOR = co.HEADER_COLOR

# cell padding
PAD = 1
PADDING = [PAD, PAD, PAD, PAD]
H_PAD = [0, 0, PAD, PAD]
V_PAD = [PAD, PAD, 0, 0]


def calc_bottom_right(cell):
    """
    Return the row and column for the
    bottom-right cell of a merged cell group.

    cell: Cell
        from a topleft cell
    """
    return cell.r + cell.s[0] - 1, cell.c + cell.s[1] - 1


def get_fringe_general_tooltip(d, with_image, _type, shadow, bump):
    """
    Return the tooltip text for the gradient-type fringe.

    d: dict
        fringe data from cell

    with_image: string
        Indicate the presence of an image in the cell.

    _type: string
        fringe type

    shadow: string
        shadow settings

    bump: string
        bump settings

    return: string
        the tooltip
    """
    return Tip.FRINGE_GENERAL.format(
        with_image,
        _type,
        d[ok.MODE],
        d[ok.CONTRACT],
        bool(d[ok.OBEY_MARGINS]),
        bool(d[ok.CLIP_TO_CELL]),
        Tip.make_brush_tooltip(d[ok.BRUSH_DICT]),
        bump,
        shadow
    )


def get_fringe_gradient_tooltip(d, with_image, _type, shadow, bump):
    """
    Return the tooltip text for the gradient-type fringe.

    d: dict
        fringe data from cell

    with_image: string
        Indicate the presence of an image in the cell.

    _type: string
        fringe type

    shadow: string
        shadow settings

    bump: string
        bump settings

    return: string
        the tooltip
    """
    return Tip.FRINGE_GRADIENT.format(
        with_image,
        _type,
        d[ok.MODE],
        d[ok.GRADIENT_TYPE],
        d[ok.GRADIENT_ANGLE],
        d[ok.CONTRACT],
        bool(d[ok.OBEY_MARGINS]),
        bool(d[ok.CLIP_TO_CELL]),
        d[ok.GRADIENT],
        Tip.make_brush_tooltip(d[ok.BRUSH_DICT]),
        bump,
        shadow
    )


def get_fringe_image_tooltip(d, with_image, _type, shadow, bump):
    """
    Return the tooltip text for the image fringe.

    d: dict
        fringe data from cell

    with_image: string
        Indicate the presence of an image in the cell.

    _type: string
        fringe type

    shadow: string
        shadow settings

    bump: string
        bump settings

    return: string
        the tooltip
    """
    if d[ok.IMAGE][ok.IMAGE_SOURCE] == "None":
        return Tip.NO_FRINGE_IMAGE.format(with_image, _type)
    return Tip.FRINGE_IMAGE.format(
        with_image,
        _type,
        d[ok.MODE],
        d[ok.CONTRACT],
        bool(d[ok.OBEY_MARGINS]),
        bool(d[ok.CLIP_TO_CELL]),
        Tip.make_image_tooltip(d[ok.IMAGE]),
        Tip.make_brush_tooltip(d[ok.BRUSH_DICT]),
        bump,
        shadow
    )


def get_fringe_mask_tooltip(d, with_image, _type, *_):
    """
    Return the tooltip text for the mask fringe.

    d: dict
        fringe data from cell

    with_image: string
        Indicate the presence of an image in the cell.

    _type: string
        fringe type

    _: string
        shadow settings
        no use

    _: string
        bump settings
        not used

    return: string
        the tooltip
    """
    return Tip.FRINGE_MASK.format(
        with_image,
        _type,
        d[ok.CONTRACT],
        Tip.make_brush_tooltip(d[ok.BRUSH_DICT])
    )


def get_fringe_pattern_tooltip(d, with_image, _type, shadow, bump):
    """
    Return the tooltip text for the pattern fringe.

    d: dict
        fringe data from cell

    with_image: string
        Indicate the presence of an image in the cell.

    _type: string
        fringe type

    shadow: string
        shadow settings

    bump: string
        bump settings

    return: string
        the tooltip
    """
    return Tip.FRINGE_PATTERN.format(
        with_image,
        _type,
        d[ok.MODE],
        d[ok.CONTRACT],
        bool(d[ok.OBEY_MARGINS]),
        bool(d[ok.CLIP_TO_CELL]),
        d[ok.PATTERN],
        Tip.make_brush_tooltip(d[ok.BRUSH_DICT]),
        bump,
        shadow
    )


def get_fringe_one_color_tooltip(d, with_image, _type, shadow, bump):
    """
    Return the tooltip text for the one-color fringe.

    d: dict
        fringe data from cell

    with_image: string
        Indicate the presence of an image in the cell.

    _type: string
        fringe type

    shadow: string
        shadow settings

    bump: string
        bump settings

    return: string
        the tooltip
    """
    return Tip.FRINGE_ONE_COLOR.format(
        with_image,
        _type,
        d[ok.MODE],
        d[ok.CONTRACT],
        bool(d[ok.OBEY_MARGINS]),
        bool(d[ok.CLIP_TO_CELL]),
        d[ok.COLOR][0],
        d[ok.COLOR][1],
        d[ok.COLOR][2],
        Tip.make_brush_tooltip(d[ok.BRUSH_DICT]),
        bump,
        shadow
    )


def get_fringe_plasma_tooltip(d, with_image, _type, shadow, bump):
    """
    Make the tooltip text for the two-color fringe.

    d: dict
        fringe data from cell

    with_image: string
        Indicate the presence of an image in the cell.

    _type: string
        fringe type

    shadow: string
        shadow settings

    bump: string
        bump settings

    return: string
        the tooltip
    """
    return Tip.FRINGE_PLASMA.format(
        with_image,
        _type,
        d[ok.MODE],
        d[ok.CONTRACT],
        d[ok.RANDOM_SEED],
        bool(d[ok.OBEY_MARGINS]),
        bool(d[ok.CLIP_TO_CELL]),
        Tip.make_brush_tooltip(d[ok.BRUSH_DICT]),
        bump,
        shadow
    )


def get_fringe_two_color_tooltip(d, with_image, _type, shadow, bump):
    """
    Return the tooltip text for the two-color fringe.

    d: dict
        fringe data from cell

    with_image: string
        Indicate the presence of an image in the cell.

    _type: string
        fringe type

    shadow: string
        shadow settings

    bump: string
        bump settings

    return: string
        the tooltip
    """
    return Tip.FRINGE_TWO_COLOR.format(
        with_image,
        _type,
        d[ok.MODE],
        d[ok.CONTRACT],
        bool(d[ok.OBEY_MARGINS]),
        bool(d[ok.CLIP_TO_CELL]),
        d[ok.COLOR_1][0],
        d[ok.COLOR_1][1],
        d[ok.COLOR_1][2],
        d[ok.COLOR_2][0],
        d[ok.COLOR_2][1],
        d[ok.COLOR_2][2],
        Tip.make_brush_tooltip(d[ok.BRUSH_DICT]),
        bump,
        shadow
    )


def get_no_fringe_tooltip(_, with_image, __, *q):
    """
    Return the tooltip text for the cell with no fringe.

    _: dict
        fringe data from cell
        not used

    with_image: string
        Indicate the presence of an image in the cell.

    __: string
        fringe type

    q:
    _: string
        shadow settings
        no use

    _: string
        bump settings
        no use

    return: string
        the tooltip
    """
    return Tip.NO_FRINGE.format(with_image)


def get_plaque_average_color_tip(with_image, n, d, bump, tri):
    """
    Make a tooltip for the average color plaque.

    with_image: string
        Yes or No

    n: string
        type of plaque

    d: dict
        of cell plaque, per cell form

    bump: string
        bump tooltip

    tri: string
        Tri-shadow tooltip

    Return: string
        tooltip
    """
    return Tip.PLAQUE_AVERAGE_COLOR.format(
        with_image,
        n,
        d[ok.MODE],
        d[ok.OPACITY],
        d[ok.BLUR_BEHIND],
        d[ok.FEATHER],
        d[ok.STEPS],
        bool(d[ok.OBEY_MARGINS]),
        Tip.mask_plaque_tooltip(d[ok.PLAQUE_MASK]),
        bump,
        tri
    )


def get_plaque_backdrop_tip(with_image, n, d, bump, tri):
    """
    Make a tooltip for the average color plaque.

    with_image: string
        Yes or No

    n: string
        type of plaque

    d: dict
        of cell plaque, per cell form

    bump: string
        bump tooltip

    tri: string
        Tri-shadow tooltip

    Return: string
        tooltip
    """
    return Tip.PLAQUE_BACKDROP.format(
        with_image,
        n,
        d[ok.MODE],
        d[ok.OPACITY],
        d[ok.BLUR_BEHIND],
        d[ok.FEATHER],
        d[ok.STEPS],
        d[ok.BLUR],
        bool(d[ok.OBEY_MARGINS]),
        Tip.mask_plaque_tooltip(d[ok.PLAQUE_MASK]),
        bump,
        tri
    )


def get_plaque_color_tip(with_image, n, d, bump, tri):
    """
    Make a tooltip for the color plaque.

    with_image: string
        Yes or No

    n: string
        type of plaque

    d: dict
        of cell plaque, per cell form

    bump: string
        bump tooltip

    tri: string
        Tri-shadow tooltip

    Return: string
        tooltip
    """
    return Tip.PLAQUE_COLOR.format(
        with_image,
        n,
        d[ok.MODE],
        d[ok.OPACITY],
        d[ok.BLUR_BEHIND],
        d[ok.FEATHER],
        d[ok.STEPS],
        bool(d[ok.OBEY_MARGINS]),
        d[ok.COLOR][0],
        d[ok.COLOR][1],
        d[ok.COLOR][2],
        Tip.mask_plaque_tooltip(d[ok.PLAQUE_MASK]),
        bump,
        tri
    )


def get_plaque_gradient_tip(with_image, n, d, bump, tri):
    """
    Make a tooltip for the gradient plaque.

    with_image: string
        Yes or No

    n: string
        type of plaque

    d: dict
        of cell plaque, per cell form

    bump: string
        bump tooltip

    tri: string
        Tri-shadow tooltip

    Return: string
        tooltip
    """
    return Tip.PLAQUE_GRADIENT.format(
        with_image,
        n,
        d[ok.GRADIENT_TYPE],
        d[ok.GRADIENT_ANGLE],
        d[ok.MODE],
        d[ok.OPACITY],
        d[ok.BLUR_BEHIND],
        d[ok.FEATHER],
        d[ok.STEPS],
        bool(d[ok.OBEY_MARGINS]),
        d[ok.GRADIENT],
        Tip.mask_plaque_tooltip(d[ok.PLAQUE_MASK]),
        bump,
        tri
    )


def get_plaque_image_tip(with_image, n, d, bump, tri):
    """
    Make a tooltip for the image plaque.

    with_image: string
        Yes or No

    n: string
        type of plaque

    d: dict
        of cell plaque, per cell form

    bump: string
        bump tooltip

    tri: string
        Tri-shadow tooltip

    Return: string
        tooltip
    """
    return Tip.PLAQUE_IMAGE.format(
        with_image,
        n,
        d[ok.MODE],
        d[ok.OPACITY],
        d[ok.BLUR_BEHIND],
        d[ok.FEATHER],
        d[ok.STEPS],
        bool(d[ok.OBEY_MARGINS]),
        Tip.make_image_tooltip(d[ok.IMAGE]),
        Tip.mask_plaque_tooltip(d[ok.PLAQUE_MASK]),
        bump,
        tri
    )


def get_plaque_netting_tip(with_image, n, d, bump, tri):
    """
    Make a tooltip for the netting plaque.

    with_image: string
        Yes or No

    n: string
        type of plaque

    d: dict
        of cell plaque, per cell form

    bump: string
        bump tooltip

    tri: string
        Tri-shadow tooltip

    Return: string
        tooltip
    """
    return Tip.PLAQUE_NETTING.format(
        with_image,
        n,
        d[ok.MODE],
        d[ok.OPACITY],
        d[ok.BLUR_BEHIND],
        d[ok.FEATHER],
        d[ok.STEPS],
        d[ok.NET_LINE_WIDTH],
        d[ok.NET_LINE_SPACING],
        bool(d[ok.OBEY_MARGINS]),
        d[ok.COLOR][0],
        d[ok.COLOR][1],
        d[ok.COLOR][2],
        Tip.mask_plaque_tooltip(d[ok.PLAQUE_MASK]),
        bump,
        tri
    )


def get_plaque_pattern_tip(with_image, n, d, bump, tri):
    """
    Make a tooltip for the pattern plaque.

    with_image: string
        Yes or No

    n: string
        type of plaque

    d: dict
        of cell plaque, per cell form

    bump: string
        bump tooltip

    tri: string
        Tri-shadow tooltip

    Return: string
        tooltip
    """
    return Tip.PLAQUE_PATTERN.format(
        with_image,
        n,
        d[ok.MODE],
        d[ok.OPACITY],
        d[ok.BLUR_BEHIND],
        d[ok.FEATHER],
        d[ok.STEPS],
        bool(d[ok.OBEY_MARGINS]),
        d[ok.PATTERN],
        Tip.mask_plaque_tooltip(d[ok.PLAQUE_MASK]),
        bump,
        tri
    )


def get_plaque_plasma_tip(with_image, n, d, bump, tri):
    """
    Make a tooltip for the plasma plaque.

    with_image: string
        Yes or No

    n: string
        type of plaque

    d: dict
        of cell plaque, per cell form

    bump: string
        bump tooltip

    tri: string
        Tri-shadow tooltip

    Return: string
        tooltip
    """
    return Tip.PLAQUE_PLASMA.format(
        with_image,
        n,
        d[ok.MODE],
        d[ok.OPACITY],
        d[ok.BLUR_BEHIND],
        d[ok.FEATHER],
        d[ok.STEPS],
        d[ok.BLUR],
        d[ok.RANDOM_SEED],
        bool(d[ok.OBEY_MARGINS]),
        Tip.mask_plaque_tooltip(d[ok.PLAQUE_MASK]),
        bump,
        tri
    )


def get_plaque_shadow_tip(with_image, n, d, bump, _):
    """
    Make a tooltip for the plasma plaque.

    with_image: string
        Yes or No

    n: string
        type of plaque

    d: dict
        of cell plaque, per cell form

    bump: string
        bump tooltip

    _: string
        Tri-shadow tooltip
        no use

    Return: string
        tooltip
    """
    return Tip.PLAQUE_SHADOW.format(
        with_image,
        n,
        d[ok.MODE],
        d[ok.OPACITY],
        d[ok.BLUR_BEHIND],
        d[ok.FEATHER],
        d[ok.STEPS],
        d[ok.INTENSITY],
        d[ok.INLAY_BLUR],
        bool(d[ok.OBEY_MARGINS]),
        d[ok.SHADOW_COLOR][0],
        d[ok.SHADOW_COLOR][1],
        d[ok.SHADOW_COLOR][2],
        Tip.mask_plaque_tooltip(d[ok.PLAQUE_MASK]),
        bump
    )


def is_outside(cell, r, c, s):
    """
    Determine if a cell has cells that
    exist outside the bounds of a rectangle.

    cell: Cell
        Has cell data.

    r, c: int
        row, column

    s: tuple (w, h)
        bounds

    Return: flag
        Is true if the cell or its group has
        cells outside of the rectangle.
    """
    if cell.r < r or \
            cell.c < c or \
            cell.r + cell.s[0] > r + s[0] or \
            cell.c + cell.s[1] > c + s[1]:
        return 1


def set_margin_tooltip(g, q):
    """
    Set the tooltip for the current cell.

    g: ColorButton
        Has tooltip.

    q: tuple
        cell data
    """
    tip = Tip.make_margin_tooltip(q, g)
    g.set_tooltip_text(tip)


def set_place_tooltip(g, d):
    """
    Set the tooltip for a cell.

    g: ColorButton
        Has tooltip.

    q: tuple
        cell data
    """
    opacity = d[ok.OPACITY]

    if not opacity:
        n = " Image: The image is invisible. "
        has_pic = False

    else:
        has_pic, n = Tip.has_pic(d[ok.IMAGE])

    if has_pic:
        n = Tip.make_image_tooltip(d[ok.IMAGE])
        n1 = Tip.make_resize_tooltip(d[ok.RESIZE_METHOD])
        n = Tip.PLACE.format(
            d[ok.JUSTIFICATION],
            opacity,
            d[ok.ROTATE],
            d[ok.BLUR_BEHIND],
            bool(d[ok.FLIP_HORIZONTAL]),
            bool(d[ok.FLIP_VERTICAL]),
            n,
            n1,
            Tip.make_shift_tooltip(d[ok.SHIFT], g)
        )
    g.set_tooltip_text(n)


def set_sub_top(a, b):
    """
    Modify a cell's Cell to identify the cell as being sub-topleft.

    a: Cell
        the topleft cell

    b: Cell
        the sub-top cell
    """
    b.topleft = a
    b.s = -1, -1


class PortCell(PortPreview):
    """Draw a table of cell(s) corresponding with a cell grid."""

    def __init__(self, o, g):
        """
        Create a cell port.

        d: dict
            with init values

        g: PerCellGroup
            Has widget values.
        """
        self._key = o.key
        self._path = o.path
        self._group_key = o.group_key
        self._is_grid = True if self._key == gk.GRID else False
        self._model_d = o.model.d
        self._model = o.model
        self._is_all_cells = o.is_all_cells
        self._render_size = Render.size()
        self._is_merge_cell = o.model.is_merge_cell
        self._split_cells = False
        self._is_rectangle = o.model.is_rectangle
        self._place_chunk = o.place_chunk
        self._cell_tooltip_dict = {
            pa.BORDER: self._set_border_tooltip,
            pa.CAPTION: self._set_caption_tooltip,
            pa.FRINGE: self._set_fringe_tooltip,
            pa.MARGIN: set_margin_tooltip,
            pa.MASK: self._set_image_mask_tooltip,
            pa.PLACE: set_place_tooltip,
            pa.PLAQUE: self._set_plaque_tooltip
        }
        self._set_sub_fringe_tooltip = {
            ng.AS_IS: get_fringe_general_tooltip,
            ng.BACKDROP: get_fringe_general_tooltip,
            ng.GRADIENT:  get_fringe_gradient_tooltip,
            ng.IMAGE: get_fringe_image_tooltip,
            ng.MASK: get_fringe_mask_tooltip,
            "None": get_no_fringe_tooltip,
            ng.ONE_COLOR: get_fringe_one_color_tooltip,
            ng.PATTERN: get_fringe_pattern_tooltip,
            ng.PLASMA: get_fringe_plasma_tooltip,
            ng.TWO_COLOR: get_fringe_two_color_tooltip
        }

        self._table_button = None
        self._per_cell_table = o.per_cell_table
        r, c = self.rows, self.columns = o.model.division
        self.table_row, self.table_column = r * 2, c * 2
        self.buttons = Base.make_2d_table(r, c)

        self._init_table()

        w = max(r, c)
        self._more = max(5, w)

        if w < 10:
            size = 500 // w

        elif w < 15:
            size = 50

        else:
            size = 25

        self.cell_height = size
        self.group = OptionGroup(
            **{
                wk.CONTAINER: None,
                wk.GROUP_KEY: self._group_key,
                wk.GROUP_TYPE: NonPreset,
                wk.PATH: self._key
            }
        )

        PortPreview.__init__(
            self,
            {
                wk.ON_ACCEPT: o.on_accept,
                wk.ON_CANCEL: o.on_cancel,
                wk.WIN: o.win,
                wk.WINDOW_TITLE: o.window_title
            },
            g
        )
        self._show_port()

    def _draw_cell(self, r, c):
        """
        Call for each cell.

        Is part of the PortCell template.

        r, c: int
            row, column
            cell position
            in 0 to n
        """
        cell = self.table[r][c]
        start, end = self._get_topleft(cell=cell).corners

        self._set_cell_face(cell, start, end)
        if not self._is_grid:
            m = False

            if cell.has_pic:
                m = True

            elif cell.is_topleft:
                m = True
            if m:
                q = self._table_button.get_value()
                self.set_tooltip(
                    cell.box,
                    q[cell.r][cell.c]
                )

    def _draw_cell_mod_window(self, g):
        """
        Draw a cell modification window.

        g: ColorButton
            Has row and column info.
        """
        self.row, self.column = g.r, g.c
        WindowCellMod(
            {
                wk.CELL_TABLE: self.table,
                wk.GRID: self._model,
                wk.GROUP_KEY: self._group_key,
                wk.KEY: self._key,
                wk.ON_ACCEPT: self.accept_window,
                wk.PATH: self._path,
                wk.SET_TOOLTIP: self.set_tooltip,
                wk.TABLE_SIZE: (self.rows, self.columns),
                wk.WINDOW_TITLE: self._key + "'s Cell Editor",
                wk.WIN: self.roller_window.win
            },
            self._table_button,
            g.r, g.c
        )

    def _draw_column_header(self, c, c1):
        """
        Draw a column header.

        c: int
            table column

        c1: int
            actual column
        """
        # column header
        g = Eventful(HEADER_COLOR)
        g1 = gtk.Frame()

        if c % 2:
            g2 = self.col_label = Label(align=(0, 0, 1, 1), text=str(c1))
            g1.add(g2)

        g.add(g1)
        return g

    def _draw_connector(self, r, c):
        """
        Draw connector button.

        r, c: int
            row, column
        """
        # connector button
        if r % 2:
            # left button
            p = self.split_horz, self.connect_left
            r3, c3 = r, c + 1
            r4, c4 = r // 2, c // 2 - 1
            q = (PAD, PAD, 0, 0)

        else:
            # upper button
            p = self.split_vert, self.connect_up
            r3, c3 = r + 1, c
            r4, c4 = r // 2 - 1, c // 2
            q = (0, 0, PAD, PAD)

        g = Box(box=gtk.HBox, align=(0, 0, 1, 1), padding=q)
        g1 = self.buttons[r4][c4] = SwitchButton(
            r3, c3,
            cell_table=self.table,
            color=co.CONNECTOR_COLOR,
            container=g,
            on_widget_change=p,
            on_accept=self.accept,
            text="+"
        )

        g1.set_size(8, 8)
        return g, g1

    def _draw_first_cell(self, g, vbox):
        """
        Draw the first cell in the cell table.

        The size of the first cell will be the
        size of every cell in the table.

        'self.win.show_all' causes the 'vbox' allocation to be
        calculated which will fail ScrolledWindow's dependency.
        So calculate the scroll region-size manually.

        g: cell widget
            event box or colored button

        vbox: VBox
            container for widgets

        Return:
            the width of the cell in pixels
            of int
        """
        rows, columns = self.rows, self.columns

        self.roller_window.win.show_all()

        # scale
        w = max(g.allocation.width, g.allocation.height, self.cell_height)
        w1, h = w * columns, w * rows
        w2 = self.row_label.allocation.width
        h1 = self.col_label.allocation.height
        button_w = 0 if not self._is_grid else 15 * (columns - 1)
        button_h = 0 if not self._is_grid else 15 * (rows - 1)
        pad_w = 4 * columns
        pad_h = 4 * rows
        extra_w, extra_h = self.table_row, self.table_column
        extra = self._more
        extra += 15 if not self._is_grid == 3 else 0

        # sum
        w1 += w2 + pad_w + button_w + extra_w + fw.SCROLL_SPAN + extra
        h += h1 + pad_h + button_h + extra_h + fw.SCROLL_SPAN + extra
        w1, h = self.roller_window.get_remaining_dim(w1, h)

        vbox.set_size_request(w1, h)
        return w

    def _draw_row_header(self, r, r1):
        """
        Draw row header.

        r: int
            table row

        r1: int
            row number
        """
        # row header
        g = Eventful(HEADER_COLOR)
        g1 = gtk.Frame()

        if r % 2:
            g2 = self.row_label = Label(align=(0, 0, 1, 1), text=str(r1))
            g1.add(g2)

        g.add(g1)
        return g

    def _generate_group(self, slices):
        """
        Slices organize themselves into one or more groups.

        A slice is a cell group with a piece of itself
        removed by a 'connect_up' or 'connect_left' process
        and the consuming merge group.

        slices: dict
            of dictionaries where each defines a group of cells
        """
        for k in slices:
            # Sort the two possible groups into a
            # larger and a smaller group (short).
            # The larger group will have the greater cell count.
            # The smaller group will be the cells not in the larger group.
            # If there's only one group,
            # the smaller group is not initialized.
            #
            # Starts by finding the longer and shorter row.
            u = slices[k]['size']
            long_row_width = long_row_height = 0
            long_col_width = long_col_height = 0
            short_col_width = short_row_height = 0
            short_row_width = short_col_height = 0
            start_long_row = [0, 0]
            start_short_row = [0, 0]
            start_long_col = [0, 0]
            start_short_col = [0, 0]

            # The key is the topleft coordinate (r, c).
            for r in range(k[0], k[0] + u[0]):
                row_width = 0
                first_col = -1

                for c in range(k[1], k[1] + u[1]):
                    if self._is_vector(k, r, c):
                        row_width += 1
                        if first_col < 0:
                            first_col = c
                    elif row_width:
                        break

                if row_width > long_row_width:
                    if long_row_width > 0:
                        # The second group inherits from the first group.
                        short_row_width = long_row_width
                        short_row_height = long_row_height
                        start_short_row = start_long_row

                    # Initialize the first group.
                    long_row_width = row_width
                    long_row_height = 1
                    start_long_row = r, first_col
                elif row_width:
                    # The vector is long or short.
                    if row_width == long_row_width:
                        long_row_height += 1
                    else:
                        if short_row_height:
                            # Add another row.
                            short_row_height += 1
                        else:
                            # Initialize the second group.
                            short_row_width = row_width
                            start_short_row = r, first_col
                            short_row_height = 1

            # Start finding the long and short column.
            for c in range(k[1], k[1] + u[1]):
                col_height = 0
                first_row = -1

                for r in range(k[0], k[0] + u[0]):
                    if self._is_vector(k, r, c):
                        col_height += 1
                        if first_row < 0:
                            first_row = r
                    elif col_height:
                        break

                if col_height > long_col_height:
                    if long_col_height > 0:
                        # Second group inherits from the first group.
                        short_col_width = long_col_width
                        short_col_height = long_col_height
                        start_short_col = start_long_col

                    # Initialize first group.
                    long_col_height = col_height
                    long_col_width = 1
                    start_long_col = first_row, c
                elif col_height:
                    # The vector is long or short.
                    if col_height == long_col_height:
                        long_col_width += 1
                    else:
                        if short_col_height:
                            short_col_width += 1
                        else:
                            # Initialize the second group.
                            short_col_width = 1
                            short_col_height = col_height
                            start_short_col = first_row, c

            row_cells = long_row_width * long_row_height
            col_cells = long_col_height * long_col_width

            # second group's dimensions, 'v'
            v = 0

            if row_cells >= col_cells:
                u = long_row_height, long_row_width
                cell = self.table[start_long_row[0]][start_long_row[1]]

                # Process the second group if it was initialized.
                if short_row_width > 0:
                    v = short_row_height, short_row_width
                    cell1 = self.table[
                        start_short_row[0]][start_short_row[1]]

            else:
                u = long_col_height, long_col_width
                cell = self.table[start_long_col[0]][start_long_col[1]]

                # Process the second group if it was initialized.
                if short_col_height > 0:
                    v = short_col_height, short_col_width
                    cell1 = self.table[
                        start_short_col[0]][start_short_col[1]]

            self._set_group(cell, u)

            # Set the second group if there was one.
            if v:
                self._set_group(cell1, v)

    def _get_topleft(self, cell=None, u=None):
        """
        Topleft is the cell located at the topleft of a cell group.

        Sub-topleft cells refer to the topleft
        cell through a topleft attribute.

        cell: Cell
            Has cell data.

        u: tuple
            row, column

        Return: Cell
            a topleft cell
        """
        if u:
            cell = self.table[u[0]][u[1]]

        if cell.s[0] < 0:
            cell1 = cell.topleft
            v = cell1.r, cell1.c

        else:
            v = cell.r, cell.c
        return self.table[v[0]][v[1]]

    def _has_pic(self, r, c):
        """
        Determine if a cell has a picture.

        r, c: int
            cell coordinate
            row, column

        Return: flag
            It's true when there is an image assigned to the cell.
        """
        d = Form.get_form(One(d=self._place_chunk, r=r, c=c))

        # Is there an image?
        m = Tip.has_pic(d[ok.IMAGE])[0]

        # zero opacity
        if m:
            m = d[ok.OPACITY]

        # Hexagonal shaped cells have missing cells.
        if m:
            m = self.table[r][c].is_cell
        return m

    def _init_table(self):
        """Set the initial data needed to draw cells."""
        row, col = self.rows, self.columns
        self.table = Base.make_2d_table(row, col)

        if self._is_merge_cell:
            merge_grid = self._model_d[ok.PER_CELL]

        # Load the cell dimensions.
        for r in range(row):
            for c in range(col):
                if self._is_merge_cell:
                    s = merge_grid[r][c]

                else:
                    s = 1, 1

                if self._is_all_cells:
                    is_cell = True

                else:
                    is_cell = Shape.is_allocated_cell(self._model, r, c)
                self.table[r][c] = Cell(s, r, c, is_cell)

        # Initialize the topleft references.
        for r in range(row):
            for c in range(col):
                cell = self.table[r][c]
                if cell.is_topleft:
                    # Initialize the sub-topleft cells.
                    for r1 in range(r, r + cell.s[0]):
                        for c1 in range(c, c + cell.s[1]):
                            if r1 != r or c1 != c:
                                a = self.table[r1][c1]
                                a.topleft = cell

    def _is_vector(self, u, r, c):
        """
        Determine if a cell (r, c) is still
        referencing a topleft cell at 'u'.

        u: tuple
            (row, column)

        Return: flag
            Is true if the topleft cell is still referenced.
        """
        # Get the cell dict.
        cell = self.table[r][c]

        # Independent cells are not part of a vector.
        if cell.is_group:
            a = self._get_topleft(cell)
            # Cell must refer to its old top.
            if a.r == u[0] and a.c == u[1]:
                return 1

    def _make_cell_button(self, r, c):
        """
        Make a ColorfulButton and add its cell coordinates to the button.

        r, c: int
            row, column
            cell position

        Return: ColorfulButton
            newly created
        """
        n = fw.IMAGE_SYMBOL if self.table[r][c].has_pic else fw.NO_IMAGE
        g = ColorfulButton(
            on_accept=self.accept,
            color=co.CELL_COLOR,
            group=self.group,
            on_preview_button=self.task_preview,
            on_widget_change=self._draw_cell_mod_window,
            text=n
        )
        g.r, g.c = r, c
        return g

    def _merge_groups(self, top, origin):
        """
        Merge two groups into a new group.

        top: Cell
            from topleft of group

        origin: Cell
            topleft cell of group
        """
        # Get the bottom-rights.
        o_b_r = calc_bottom_right(origin)
        t_b_r = calc_bottom_right(top)

        # Merge the group settings.
        m_pos = min(top.r, origin.r), min(top.c, origin.c)
        m_b_r = tuple(max(o, m) for o, m in zip(o_b_r, t_b_r))
        diff = tuple(n - m for n, m in zip(m_b_r, m_pos))
        v = diff[0] + 1, diff[1] + 1

        # Get the top-left cell's dict of the merged group.
        m = self.table[m_pos[0]][m_pos[1]]

        # Create a dictionary of potential slices.
        #
        # Slices are groups that are part of a merged group
        # rectangle, but are exclusive of top and origin groups.
        #
        # Also, slices have cells outside the bounds of the merged group.
        sliced = {}

        for r in range(m_pos[0], m_pos[0] + v[0]):
            for c in range(m_pos[1], m_pos[1] + v[1]):
                cell = self.table[r][c]
                if cell.is_group:
                    t = self._get_topleft(cell)
                    if t.r != top.r or t.c != top.c:
                        if t.r != origin.r or t.c != origin.c:
                            if is_outside(
                                t,
                                m.r, m.c,
                                v
                            ):
                                key = t.r, t.c
                                if key not in sliced:
                                    sliced[key] = {'size': t.s}

        self._set_group(m, v)
        self._generate_group(sliced)

    def _set_block_face(self, start, end):
        """
        Set the appearance of a block of cells.

        start: tuple
            (r, c) for the topleft cell

        end: tuple
            (r, c) for the bottom-right cell
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self._set_cell_face(self.table[r][c], start, end)

    def _set_border_tooltip(self, g, d):
        """
        Set the tooltip for a cell widget.

        g: ColorButton
            Has tooltip.
            Has r, c, the cell index.

        d: dict
            cell data
        """
        n = "Yes" if self.table[g.r][g.c].has_pic else "No"
        bump = Tip.make_bump_tooltip(d[ok.BUMP])
        n1 = d[ok.BORDER_TYPE]
        shadow = Tip.make_shadow_tooltip(d[ok.TRI_SHADOW])

        if (
            n == "No" or
            n1 == "None" or
            not d[ok.BORDER_WIDTH] and
            not d[ok.OPACITY]
        ):
            n = Tip.NO_CELL_BORDER.format(n)

        elif n1 in (bo.AVERAGE_COLOR, bo.BACKDROP):
            n = Tip.CELL_BORDER_AVERAGE_COLOR.format(
                n,
                n1,
                d[ok.MODE],
                d[ok.BORDER_WIDTH],
                d[ok.OPACITY],
                d[ok.BORDER_BLUR],
                d[ok.BLUR_BEHIND],
                bump,
                shadow
            )

        elif n1 == bo.GRADIENT:
            n = Tip.CELL_BORDER_GRADIENT.format(
                n,
                n1,
                d[ok.MODE],
                d[ok.GRADIENT_TYPE],
                d[ok.GRADIENT_ANGLE],
                d[ok.BORDER_WIDTH],
                d[ok.OPACITY],
                d[ok.BORDER_BLUR],
                d[ok.BLUR_BEHIND],
                d[ok.GRADIENT],
                bump,
                shadow
            )

        elif n1 == bo.COLOR:
            n = Tip.CELL_BORDER_COLOR.format(
                n,
                n1,
                d[ok.MODE],
                d[ok.BORDER_WIDTH],
                d[ok.OPACITY],
                d[ok.BORDER_BLUR],
                d[ok.BLUR_BEHIND],
                d[ok.COLOR][0],
                d[ok.COLOR][1],
                d[ok.COLOR][2],
                bump,
                shadow
            )

        elif n1 == bo.IMAGE:
            n = Tip.CELL_BORDER_IMAGE.format(
                n,
                n1,
                d[ok.MODE],
                d[ok.BORDER_WIDTH],
                d[ok.OPACITY],
                d[ok.BORDER_BLUR],
                d[ok.BLUR_BEHIND],
                Tip.make_image_tooltip(d[ok.IMAGE]),
                bump,
                shadow
            )

        elif n1 == bo.PATTERN:
            n = Tip.CELL_BORDER_PATTERN.format(
                n,
                n1,
                d[ok.MODE],
                d[ok.BORDER_WIDTH],
                d[ok.OPACITY],
                d[ok.BORDER_BLUR],
                d[ok.BLUR_BEHIND],
                d[ok.PATTERN],
                bump,
                shadow
            )

        elif n1 == bo.PLASMA:
            n = Tip.CELL_BORDER_PLASMA.format(
                n,
                n1,
                d[ok.MODE],
                d[ok.BORDER_WIDTH],
                d[ok.OPACITY],
                d[ok.BORDER_BLUR],
                d[ok.BLUR_BEHIND],
                d[ok.RANDOM_SEED],
                bump,
                shadow
            )

        else:
            n = ""
        g.set_tooltip_text(n)

    def _set_caption_tooltip(self, g, d):
        """
        Set the tooltip for a cell widget.

        g: ColorButton
            Has tooltip.

        d: dict
            of cell from table
        """
        r, c = g.r, g.c
        with_image = "Yes" if self.table[r][c].has_pic else "No"
        n = d[ok.CUSTOM_CELL_CAPTION_TYPE]

        # A sequence number is nonsense in this context.
        if n == pt.SEQUENCE_NUMBER:
            n = d[ok.CELL_CAPTION_TYPE] = pt.TEXT

        margin = Tip.make_margin_tooltip(d[ok.CAPTION_MARGIN], g)
        shadow = Tip.make_shadow_tooltip(d[ok.TRI_SHADOW])
        stripe = Tip.make_stripe_tooltip(d[ok.BACKGROUND_STRIPE])

        # There is no sequence number in per cell caption.
        if n == "None":
            tip = Tip.NO_CAPTION.format(with_image)

        elif n == pt.IMAGE_NAME:
            tip = Tip.CAPTION_IMAGE_NAME.format(
                with_image,
                n,
                d[ok.JUSTIFICATION],
                d[ok.LEADING_TEXT],
                d[ok.TRAILING_TEXT],
                d[ok.OPACITY],
                d[ok.FONT_SIZE],
                bool(d[ok.CLIP_TO_CELL]),
                d[ok.COLOR][0],
                d[ok.COLOR][1],
                d[ok.COLOR][2],
                d[ok.FONT],
                margin,
                shadow,
                stripe
            )

        else:
            # text
            tip = Tip.CAPTION.format(
                with_image,
                n,
                d[ok.JUSTIFICATION],
                d[ok.TEXT],
                d[ok.OPACITY],
                d[ok.FONT_SIZE],
                bool(d[ok.CLIP_TO_CELL]),
                d[ok.COLOR][0],
                d[ok.COLOR][1],
                d[ok.COLOR][2],
                d[ok.FONT],
                margin,
                shadow,
                stripe
            )
        g.set_tooltip_text(tip)

    def _set_cell_face(self, cell, start, end):
        """
        Set a cell's appearance.

        cell: Cell
            Has cell data.

        start: tuple
            (r, c) for the topleft cell

        end: tuple
            (r, c) for the bottom-right cell
        """
        if cell.s == (1, 1):
            self._set_single_looks(cell)

        else:
            # The cell is a member of a group.
            #
            # cell neighbor flags
            top = cell.r > start[0]
            bottom = cell.r < end[0]
            left = cell.c > start[1]
            right = cell.c < end[1]

            # top, bottom, left, right
            w = [PAD, PAD, PAD, PAD]

            for x, i in enumerate((top, bottom, left, right)):
                if i:
                    w[x] = 0

            cell.pad_box.set_padding(*w)
            if self._is_grid:
                # button updates
                if cell.left_button:
                    g = cell.left_button

                    if left:
                        w = V_PAD[:]
                        for x, i in enumerate((top, bottom)):
                            if i:
                                w[x] = 0

                        g.pad.set_padding(*w)
                        g.set_label(" - ")
                        g.gate = 1
                    else:
                        g.set_label(" + ")
                        g.gate = 0
                        g.pad.set_padding(*V_PAD)
                if cell.top_button:
                    g = cell.top_button

                    if top:
                        w = H_PAD[:]

                        for x, i in enumerate((left, right)):
                            if i:
                                w[x + 2] = 0

                        g.pad.set_padding(*w)
                        g.set_label(" - ")
                        g.gate = 1
                    else:
                        g.set_label(" + ")
                        g.gate = 0
                        g.pad.set_padding(*H_PAD)
        if self._is_grid:
            self._update_cell_tooltip(cell)

    def _set_fringe_tooltip(self, g, d):
        """
        Set the tooltip for a cell widget.

        g: ColorButton
            Has tooltip.

        d: dict
            cell data
        """
        r, c = g.r, g.c
        _type = d[ok.FRINGE_TYPE]
        shadow = Tip.make_shadow_tooltip(d[ok.TRI_SHADOW])
        bump = Tip.make_bump_tooltip(d[ok.BUMP])
        tip = self._set_sub_fringe_tooltip[_type](
            d,
            "Yes" if self.table[r][c].has_pic else "No",
            _type,
            shadow,
            bump,
        )
        g.set_tooltip_text(tip)

    def _set_group(self, top, s):
        """
        Set a group's sub-cell's attributes and the group's appearance.

        top: Cell
            for a new group

        s: tuple (w, h)
            group's new dimensions
        """
        top.s = s
        start, end = top.corners

        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                if r != top.r or c != top.c:
                    set_sub_top(top, self.table[r][c])
        self._update_block(start, end)

    def _set_image_mask_tooltip(self, g, d):
        """
        Set the tooltip for a cell.

        Is part of the PortCell template.

        g: ColorButton
            Has tooltip.

        d: dict
            of image mask
        """
        r, c = g.r, g.c
        with_image = "Yes" if self.table[r][c].has_pic else "No"
        has_image = Tip.HAS_IMAGE_TIP.format(with_image)
        tip = has_image + Tip.mask_plaque_tooltip(d)
        g.set_tooltip_text(tip)

    def _set_plaque_tooltip(self, g, d):
        """
        Set the tooltip for a cell widget.

        g: ColorButton
            Has tooltip.

        d: dict
            cell data
        """
        r, c = g.r, g.c
        with_image = "Yes" if self.table[r][c].has_pic else "No"
        n = d[ok.PLAQUE_TYPE]
        bump = Tip.make_bump_tooltip(d[ok.BUMP])
        tri = Tip.make_shadow_tooltip(d[ok.TRI_SHADOW])
        g.set_tooltip_text(
            plaque_tip[n](with_image, n, d, bump, tri) if n in plaque_tip
            else Tip.NO_PLAQUE.format(with_image, n)
        )

    def _set_single_looks(self, cell):
        """
        Change the appearance of a cell's frame to appear independent.

        If the cell is changing because of a split cells
        operation, then update the cell's switch buttons.

        cell: Cell
            Has cell values.
        """
        cell.pad_box.set_padding(*PADDING)
        if self._split_cells:
            for g in (cell.left_button, cell.top_button):
                if g:
                    g.set_label(" + ")

                    g.gate = 0

                    if g == cell.left_button:
                        g.pad.set_padding(*V_PAD)
                    else:
                        g.pad.set_padding(*H_PAD)

    def _show_port(self):
        """Call when opening a per cell port."""
        self.pane.show_all()
        self.roller_window.win.present()

    def _update_block(self, start, end):
        """
        Update the Grid, cell size table,
        and the cell appearance for a block of cells.

        start: Cell
            the top-left cell in the block

        end: Cell
            the bottom-right cell in the block
        """
        self._update_grid(start, end)
        self._model.update_cell_block(start, end)
        self._set_block_face(start, end)

    def _update_cell_tooltip(self, cell):
        """
        Call whenever a cell is drawn.

        Update the cell dimension labels.

        cell: Cell
            Has cell data.
        """
        g, s = cell.box, cell.s
        if cell.is_topleft:
            rect = self._model.get_merge_cell_rect(cell.r, cell.c)
            tip = Tip.MERGE_CELL.format(rect.x, rect.y, rect.w, rect.h)
            g.set_tooltip_text(tip)
            if s != (1, 1):
                start, end = cell.corners
                for r in range(start[0], end[0] + 1):
                    for c in range(start[1], end[1] + 1):
                        if self.table[r][c].box:
                            g1 = self.table[r][c].box
                            if g != g1:
                                g1.set_tooltip_text("")

    def _update_grid(self, start, end):
        """
        Update the size attribute for a block of cells.

        start: tuple of int
            the topleft cell in the block
            (r, c)

        end: tuple of int
            the bottom-right cell in the block
            (r, c)
        """
        q = self._table_button.get_value()
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                q[r][c] = self.table[r][c].s

    def accept(self):
        """
        Accept the changes to the per cell table.

        Return: true
            The key-press is handled.
        """
        self.switch_ports()
        return self.accept_port(self._table_button.get_value())

    def accept_window(self, q):
        """
        Is called from PortCellMod.

        q: list
            per cell table
        """
        self.safe.set_value(q)

    def connect_left(self, cell):
        """
        Connect cells horizontally.

        cell: Cell
            Has cell data.
        """
        origin = self._get_topleft(cell=cell)
        top = self._get_topleft(u=(cell.r, cell.c - 1))
        self._merge_groups(top, origin)

    def connect_up(self, cell):
        """
        Connect cells vertically.

        cell: Cell
            Has cell data.
        """
        origin = self._get_topleft(cell=cell)
        top = self._get_topleft(u=(cell.r - 1, cell.c))
        self._merge_groups(top, origin)

    def cancel(self, *_):
        """
        Cancel the port.

        Return: true
            The key-press is handled.
        """
        self.switch_ports()
        return self.cancel_port()

    def draw_port(self, vbox):
        """
        Draw a cell table used by the per-cell ports.

        Is part of the Port template.

        vbox: VBox
            container for the widgets
        """
        w = 1
        is_grid = self._is_grid
        is_not_merge = not self._is_grid
        row, col = self.table_row, self.table_column
        table = gtk.Table(row, col)
        scroll = gtk.ScrolledWindow()
        is_1st_cell = True
        black_box = Eventful((0, 0, 0))
        black_box.add(table)
        scroll.add_with_viewport(black_box)
        vbox.add(scroll)
        scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        for r in range(row):
            for c in range(col):
                r1, c1 = r // 2 + 1, c // 2 + 1
                r2, c2 = r // 2 - 1, c // 2 - 1

                if r == 0:
                    if is_grid or (is_not_merge and c % 2):
                        g = self._draw_column_header(c, c1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif c == 0:
                    if is_grid or (is_not_merge and r % 2):
                        g = self._draw_row_header(r, r1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif r % 2 and c % 2:
                    # Create the cell.
                    r3, c3 = r // 2, c // 2
                    cell = self.table[r3][c3]

                    # Add buttons to the cell's dictionary.
                    if r > 1:
                        cell.top_button = self.buttons[r2][c3]

                    if c > 1:
                        cell.left_button = self.buttons[r3][c2]

                    g = cell.pad_box = Box(align=(0, 0, 1, 1))

                    if self._is_rectangle and cell.is_dependent:
                        cell.has_pic = False

                    else:
                        cell.has_pic = self._has_pic(r3, c3)

                    if cell.is_topleft and is_not_merge:
                        g1 = self._make_cell_button(r3, c3)

                    elif is_grid or cell.is_not_pic_cell:
                        g1 = Eventful(co.CELL_COLOR)

                        if is_not_merge and not cell.is_dependent:
                            g1.set_tooltip_text(" No Image ")
                        elif not cell.is_cell:
                            g1.set_tooltip_text(" No Cell ")

                    else:
                        g1 = self._make_cell_button(r3, c3)

                    g2 = self.table[r3][c3].box = g1

                    if not self._table_button:
                        self._table_button = g1
                        g1.set_value(self._per_cell_table)

                    g.add(g1)
                    table.attach(g, c, c + 1, r, r + 1)
                    self._draw_cell(r3, c3)

                    if is_1st_cell:
                        w = self._draw_first_cell(g2, vbox)
                        is_1st_cell = False
                    g2.set_size_request(w, w)

                elif not (not r % 2 and not c % 2):
                    if is_grid:
                        g, g1 = self._draw_connector(r, c)

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)
                else:
                    if is_grid:
                        # This is the square that lies at the four
                        # corners of a cell group and is not active.
                        g = Eventful(co.CONNECTOR_COLOR)
                        g1 = gtk.HBox()

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

    def get_group_value(self):
        """
        Call before doing a preview.

        Return: list
            a per cell table
        """
        return self._table_button.get_value()

    def set_tooltip(self, g, d):
        """
        Set the tooltip for a cell.

        g: ColorfulButton
            Has tooltip.

        d: dict
            from per cell table
        """
        self._cell_tooltip_dict[self._key](g, d)

    def split_horz(self, cell):
        """
        The user has clicked a horizontal connector in a disconnect state.

        Divide the group containing this connector by two columns.

        cell: Cell
            Has cell data.
        """
        self._split_cells = True
        c = cell.c
        top = self._get_topleft(cell=cell)
        w = c - top.c
        w1 = top.s[1] - w
        cell1 = self.table[top.r][top.c + w]

        self._set_group(cell1, (top.s[0], w1))
        self._set_group(top, (top.s[0], w))
        self._split_cells = False

    def split_vert(self, cell):
        """
        The user has clicked a vertical connector in a disconnect state.

        Divide the group containing this connector by two rows.

        cell: Cell
            Has cell data.
        """
        self._split_cells = True
        r = cell.r
        top = self._get_topleft(cell=cell)
        h = r - top.r
        h1 = top.s[0] - h
        cell1 = self.table[top.r + h][top.c]

        # Create new groups from the split.
        self._set_group(cell1, (h1, top.s[1]))
        self._set_group(top, (h, top.s[1]))
        self._split_cells = False


plaque_tip = {
    aq.AVERAGE_COLOR: get_plaque_average_color_tip,
    aq.BACKDROP: get_plaque_backdrop_tip,
    aq.COLOR: get_plaque_color_tip,
    aq.GRADIENT: get_plaque_gradient_tip,
    aq.IMAGE: get_plaque_image_tip,
    aq.NETTING: get_plaque_netting_tip,
    aq.PATTERN: get_plaque_pattern_tip,
    aq.PLASMA: get_plaque_plasma_tip,
    aq.SHADOW: get_plaque_shadow_tip
}
