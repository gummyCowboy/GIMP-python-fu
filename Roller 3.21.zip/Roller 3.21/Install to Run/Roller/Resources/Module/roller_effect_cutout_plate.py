#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import sqrt
from roller_constant_for import Gradient as fg, Stack as st
from roller_constant_key import Model as md, Option as ok
from roller_constant_fu import Fu
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import colorsys
import gimpfu as fu

em = Fu.Emboss
pdb = fu.pdb
sn = Fu.SolidNoise
um = Fu.UnsharpMask
X_IS_1 = Y_IS_1 = 1


def do_grid(j, image_layer, o, edge, span, half):
    """
    Create a list of selections for images in the grid.

    o: One
        Has variables.

    image_layer: layer
        with image material

    edge: int
        width of edge

    span: int
        width of frame less edge

    half: int
        half of the frame width

    return: list
        of selection rectangle
    """
    cat = Hat.cat
    row, column = o.grid.division
    is_merge_cell = o.grid.is_merge_cell
    e = o.grid.d
    rect_list = []
    n = image_layer.parent.name.split(" ")[-1]
    s = 1

    # Load the image selections. Calculate the frame bounds.
    # Collect the frame bounds for plate clearing.
    # Do one image at a time.
    for r in range(row):
        for c in range(column):
            if is_merge_cell:
                s = e[ok.PER_CELL][r][c]

            # Is it a topleft cell?
            if s != (-1, -1):
                k = o.model_name, r, c
                Hat.cat.join_selection(k)
                if o.is_nested_group:
                    if cat.get_z_height(k) == n:
                        a = process_image(j, edge, span, half)
                        if a:
                            rect_list.append(a)
                else:
                    a = process_image(j, edge, span, half)
                    if a:
                        rect_list.append(a)
    return rect_list


def do_rounded_edge(j, z, edge):
    """
    Do color blend effect using a color and its luminosity.

    The round effect is calculated using the unit circle formula.
    So 'x' is the luminosity step, and 'y' is the luminosity result.

        x**2 + y**2 = 1

    j: GIMP image
        work-in-progress

    z: layer
        to receive effect

    edge: int
        the number of gradient edge steps
    """
    # the x-vector steps
    f = 1. / (edge - 1)

    # '255.' is the high-end of the range for the luminosity.
    q = colorsys.hsv_to_rgb(0., 0., 255. * sqrt(1. - f**2))

    Sel.item(z)
    for i in range(edge):
        if Sel.is_sel(j):
            a = pdb.gimp_selection_save(j)
            q = tuple([int(b) for b in q])

            Sel.grow(j, 1, 0)
            Sel.load(j, a, option=fu.CHANNEL_OP_SUBTRACT)
            Sel.fill(z, q)
            Sel.load(j, a, option=fu.CHANNEL_OP_ADD)

            # 'luminosity' is on the  y-vector of the unit circle.
            y = f * (i + 1)

            if y < 1:
                q = colorsys.hsv_to_rgb(0., 0., 255. * sqrt(1 - y**2))
            pdb.gimp_image_remove_channel(j, a)


def process_image(j, edge, span, half):
    """
    Calculate a selection rectangle for an image.

    k: string or tuple
        key to image selection

    edge: int
        width of edge

    span: int
        width of frame less edge

    half: int
        half of the frame width

    return: tuple or None
        a rectangle
        x, y, w, h
    """
    if Sel.is_sel(j):
        # Calculate the frame bounds.
        Sel.grow(j, edge, 1)
        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        w = x1 - x + span
        h = y1 - y + span
        x -= half
        y -= half
        return x, y, w, h


def process_layer(j, image_layer, o):
    """
    Add frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    parent = image_layer.parent

    # the Cutout Plate preset dict, 'd'
    d = o.d

    group = Lay.group(j, Lay.name(parent, o.k), parent=parent)
    w = d[ok.FRAME_WIDTH]
    half = w // 2
    edge = max(min(d[ok.BEVEL_EDGE_WIDTH], half), 1)
    half = max(half - edge, 1)
    span = max(w - edge * 2, 2)
    frame_layer = Lay.add(j, o.k, parent=group)
    rect_list = []

    Lay.color_fill(frame_layer, (255, 255, 255))

    # Cut out the image.
    # Use 'z' to set the alpha of the selection.
    Sel.make_layer_sel(image_layer)
    Sel.grow(j, edge, 1)
    Lay.clear_sel(frame_layer)

    if o.model == md.TABLE:
        rect_list = do_grid(j, image_layer, o, edge, span, half)

    elif o.model == md.STACK:
        if o.grid.image_group_type == st.EACH_HAS_GROUP:
            rect_list = do_grid(j, image_layer, o, edge, span, half)
        else:
            Sel.item(o.image_layer)

            # a selection rectangle, 'a'
            a = process_image(j, edge, span, half)
            if a:
                rect_list = [a]
    else:
        Sel.make_layer_sel(o.image_layer)

        # a selection rectangle, 'a'
        a = process_image(j, edge, span, half)
        if a:
            rect_list = [a]

    pdb.gimp_selection_none(j)

    # Load the expanded rectangle selections as additions.
    for i in rect_list:
        Sel.rect(j, *i)

    # Clear the material outside of the rectangle selections.
    Sel.invert_clear(frame_layer)

    do_rounded_edge(j, frame_layer, edge)

    # Begin the frame decoration.
    # pattern, 'z'
    z = pattern_layer = Lay.add(
        j,
        o.k,
        parent=group,
        offset=Lay.offset(frame_layer)
    )
    frame_layer.mode = fu.LAYER_MODE_MULTIPLY

    Sel.item(z)
    RenderHub.set_fill_context(fg.FILL_DICT)
    RenderHub.set_pattern(d)
    pdb.gimp_drawable_edit_bucket_fill(
        z,
        fu.FILL_PATTERN,
        X_IS_1, Y_IS_1
    )
    Sel.item(frame_layer)
    Sel.invert_clear(z)
    RenderHub.adjust_mean_value(z)

    if d[ok.NOISE_OPACITY]:
        # noise
        z = Lay.add(j, o.k, parent=group)
        z.opacity = d[ok.NOISE_OPACITY]

        pdb.plug_in_solid_noise(
            j, z,
            sn.NO_TILEABLE,
            sn.YES_TURBULENT,
            d[ok.RANDOM_SEED],
            d[ok.DETAIL_LEVEL],
            sn.HORIZONTAL_SIZE_2,
            sn.VERTICAL_SIZE_2
        )
        pdb.plug_in_unsharp_mask(
            j, z,
            um.RADIUS_3,
            um.AMOUNT_54,
            um.THRESHOLD_0
        )

        # in case of transparency in the pattern
        Sel.item(pattern_layer)

        sel = Hat.cat.save_short_term_sel()
        if sel:
            Sel.item(frame_layer)
            Sel.invert_clear(z)
            pdb.plug_in_colortoalpha(j, z, (127, 127, 127))
            Sel.item(z)
            pdb.gimp_selection_feather(j, d[ok.SOFTNESS])
            Sel.invert(j)
            Lay.clear_sel(z)
            Sel.load(j, sel)
            Sel.invert_clear(z)

    z = Lay.clone(frame_layer)
    z.mode = fu.LAYER_MODE_NORMAL
    frame_layer.opacity = 94.

    pdb.gimp_image_raise_layer_to_top(j, frame_layer)

    z = Lay.merge_group(group)
    return GradientLight.apply_light(z, ok.OTHER_FRAME)


class CutoutPlate:
    """Create a rectangular frame with cutout space for image material."""

    @staticmethod
    def do(o):
        """
        Is an image-effect template function.

        o: One
            Has variables.

        o: One
            Has variables.

        Return: layer
            Has Cutout Plate
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # 'undo_z' is a list of layers for the preview's undo function.
        undo_z = []
        o.shadow_layer = [z]

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], o)]

        else:
            undo_z = process_layer(j, z, o)
            if undo_z:
                o.shadow_layer = [undo_z, z]
        return undo_z
