#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Widget as fw
from roller_constant_key import Button as bk, Widget as wk
from roller_widget_button import Button, PreviewButton
import gtk


class ButtonPair(gtk.Alignment):
    """
    Is an GTK HBox with two Buttons.

    Button access is through the 'left_button'
    and 'right_button' attributes.
    """

    def __init__(self, **d):
        """
        Create an HBox with some buttons.

        d: dict
            Has init values.
            Has a key, Widget.KEY, which is a pair of label descriptor values.
        """
        super(gtk.Alignment, self).__init__()

        if wk.RENDER_PAD in d:
            self.set_padding(*d[wk.RENDER_PAD])

        w = fw.MARGIN // 2
        self.label = None
        self.key = d[wk.KEY] if wk.KEY in d else None
        self.win = d[wk.WIN] if wk.WIN in d else None
        self.group = d[wk.GROUP] if wk.GROUP in d else None
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        hbox = gtk.HBox()
        q = d[wk.TEXT]
        d[wk.KEY] = d[wk.TEXT] = q[0]
        d[wk.PADDING] = w, w, 0, w
        d[wk.ALIGN] = 0, 0, 1, 0
        g = self.left_button = Button(**d)
        n = d[wk.KEY] = d[wk.TEXT] = q[1]
        d[wk.PADDING] = w, w, w, 0
        g1 = self.right_button = PreviewButton(**d) \
            if n == bk.PREVIEW else Button(**d)

        for i in (g, g1):
            hbox.pack_start(i, expand=1)
            same_size.add_widget(i.widget)
        self.add(hbox)

    def hide(self):
        """Hide the Buttons and its attached Label."""
        super(gtk.Alignment, self).hide()
        if self.label:
            if self.label.widget.get_visible():
                self.label.widget.hide()

    def show(self):
        """Show the Buttons and its attached Label."""
        super(gtk.Alignment, self).show()
        if self.label:
            if not self.label.widget.get_visible():
                self.label.widget.show()
