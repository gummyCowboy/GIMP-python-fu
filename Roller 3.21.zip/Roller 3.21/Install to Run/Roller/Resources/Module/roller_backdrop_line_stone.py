#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu

de = Fu.Despeckle
er = Fu.Erode
pdb = fu.pdb
um = Fu.UnsharpMask
FOUR_COORDINATES = 4


def do_step_one(z, parent):
    """
    Process in multiple phases.

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    j = z.image
    z = Lay.clone(z)
    group = Lay.group(j, "Line 1", parent=parent, layer=z)
    z = Lay.clone(z)
    z.mode = fu.LAYER_MODE_HSV_VALUE

    Gegl.edge(z)
    pdb.gimp_drawable_invert(z, 0)

    z = Lay.clone(z)
    z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
    z.opacity = 25.

    z = Lay.clone(z)
    z.mode = fu.LAYER_MODE_HARD_MIX
    z.opacity = 20.
    return Lay.merge_group(group)


def do_step_two(z, parent):
    """
    Process in multiple phases.

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    j = z.image
    z = Lay.clone(z)
    group = Lay.group(j, "Line 2", parent=parent, layer=z)

    Lay.dilate(z)
    pdb.plug_in_erode(
        j, z,
        er.PROPAGATE_BLACK,
        er.RGB_CHANNELS,
        er.FULL_RATE,
        er.DIRECTION_MASK_0,
        er.LOW_LIMIT_0,
        er.UPPER_LIMIT_255
    )
    return Lay.merge_group(group)


def do_step_three(z, parent):
    """
    Process in multiple phases.

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    j = z.image
    z = Lay.clone(z)
    group = Lay.group(j, "Line 3", parent=parent, layer=z)

    Gegl.blur(z, 4.)
    pdb.plug_in_despeckle(
        j, z,
        4,
        de.RECURSIVE_ADAPTIVE,
        de.WHITE_248,
        de.BLACK_7
    )
    Lay.dilate(z)

    z = Lay.clone(z)
    z.mode = fu.LAYER_MODE_HSV_VALUE
    Lay.dilate(z)
    return Lay.merge_group(group)


def do_step_four(z, parent):
    """
    Process in multiple phases.

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    j = z.image
    z = Lay.clone(z)
    group = Lay.group(j, "Line 4", parent=parent, layer=z)

    pdb.python_fu_foggify(j, z, "Clouds", (127, 127, 127), 3., 100.)
    return Lay.merge_group(group)


def do_step_five(z, o):
    """
    Process in multiple phases.

    z: layer
        work-in-progress

    o: One
        Has original layer.

    Return: layer
        work-in-progress
    """
    j = z.image
    group = Lay.group(j, "Line 5", layer=z)
    z = z1 = Lay.clone(z)
    z.mode = fu.LAYER_MODE_OVERLAY
    z.opacity = 100.

    pdb.plug_in_hsv_noise(j, z, 1, 5, 5, 5)
    Gegl.emboss(z, 45., 15., 3)

    pdb.gimp_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        FOUR_COORDINATES,
        [0, 100, 255, 155]
    )

    z = Lay.clone(o.z)
    z.mode = fu.LAYER_MODE_OVERLAY
    z.opacity = 100.

    pdb.gimp_image_reorder_item(j, z, group, 1)
    pdb.gimp_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        FOUR_COORDINATES,
        [0, 255, 255, 127]
    )

    z = Lay.clone(z)
    z.mode = fu.LAYER_MODE_DIFFERENCE
    z.opacity = 50.
    z = Lay.clone(z)
    z.mode = fu.LAYER_MODE_EXCLUSION
    z.opacity = 25.

    Gegl.color_to_grey(z)

    z1.opacity = 50.
    z = Lay.merge_group(group)
    Gegl.unsharp_mask(z, 5., 1.5, .3)
    return z


class LineStone:
    """Create a bumpy concrete base that has touches of color and line."""

    @staticmethod
    def do(o):
        """
        Do the backdrop-style.

        o: One
            Has variables.

        Return: layer or None
            of Line Stone
        """
        cat = Hat.cat
        j = cat.render.image

        # Line Stone preset dict, 'd'
        d = o.d

        if Lay.has_pixel(o.z) and d[ok.OPACITY]:
            cat.seed(d)

            # backdrop image layer, 'z'
            z = Lay.clone(o.z)

            group = Lay.group(j, o.k, layer=z)
            z = z1 = do_step_one(z, group)
            z = do_step_two(z, group)
            z.mode = fu.LAYER_MODE_GRAIN_EXTRACT

            pdb.gimp_edit_copy_visible(j)

            z.mode = fu.LAYER_MODE_NORMAL
            z = z2 = Lay.paste(z)
            z.mode = fu.LAYER_MODE_HARD_MIX

            pdb.gimp_edit_copy_visible(j)

            z = Lay.paste(z)
            z.mode = fu.LAYER_MODE_HSV_VALUE

            j.remove_layer(z1)
            j.remove_layer(z2)

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            z = do_step_three(z, group)
            z = do_step_four(z, group)
            z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
            z = Lay.merge_group(group)
            z = do_step_five(z, o)
            z.mode, z.opacity = RenderHub.get_mode(d)

            Lay.clone(o.z)

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            return RenderHub.bump(z, d[ok.BUMP])
