#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Step as fs
from roller_constant_key import (
    Group as gk,
    Model as md,
    Option as ok,
    Pickle as pc,
    Preset as pk,
    Step as sk,
    Widget as wk
)
from roller_one import Comm, Hat, OZ
from roller_one_draw import Draw
from roller_option_preset_core import Core
from roller_option_preset_dict import NonPresetDict, PresetDict
from roller_widget_button_pair import ButtonPair
from roller_widget_tree import Node, OptionList, ModelList
from roller_window_preset import RWPreset
from roller_window_save import RWSave

LOAD_ERR = "Roller is unable to load a preset in its original state."
PRESET_LABEL = "Manage Preset…", "Save Preset…"
PRESET_STEPS = {
    sk.GLOBAL: PresetDict.GLOBAL,
    sk.BACKDROP_STYLE: PresetDict.BACKDROP_STYLE,
    sk.BACKDROP_IMAGE: PresetDict.BACKDROP_IMAGE,
    sk.GRADIENT_LIGHT: PresetDict.GRADIENT_LIGHT,
    sk.MODEL: PresetDict.MODEL
}


def get_group(path):
    """
    Get the OptionGroup and Node of a path.

    path: tuple
        of steps

    Return: tuple
        OptionGroup, Node
    """
    group = Hat.cat.group_dict[path]
    return group, group.node


class Preset(ButtonPair):
    """Use to manage presets."""

    def __init__(self, **d):
        """
        Create a grid group preset.

        Use the Widget template 'get_value' and 'set_value'
        functions to manage widget option groups.

        d: dict
            Has keyword arguments.
        """
        def on_action(g_):
            if g_.key == PRESET_LABEL[0]:
                RWPreset(g_)
            else:
                RWSave(
                    {
                        pk.GET_DATA: self.get_value,
                        wk.KEY: self.group_key,
                        wk.WIN: self.win.win
                    }
                )

        # Backdrop-style and image-effect have a tuple for a key.
        self.group_key = d[wk.GROUP_KEY]

        self.group = d[wk.GROUP]
        ButtonPair.__init__(
            self,
            key=d[wk.KEY],
            group=d[wk.GROUP],
            on_widget_change=on_action,
            text=PRESET_LABEL,
            win=d[wk.WIN]
        )

    @staticmethod
    def _expand_preset(d, e):
        """
        Expand dict from another dict.

        Is recursive.

        d: dict
            expanding dict

        e: dict
            source dict
        """
        # Remove old.
        for k in d.keys():
            if k not in e:
                d.pop(k)
        for i in e.keys():
            if i not in d:
                d[i] = deepcopy(e[i])
            if d[i] and isinstance(d[i], dict):
                if e[i] and isinstance(e[i], dict):
                    Preset._expand_preset(d[i], e[i])
                else:
                    # Change type.
                    d[i] = deepcopy(e[i])

    @staticmethod
    def get_default(k):
        """
        Get a preset dictionary.

        Is part of a Preset template.

        k: string
            of preset

        Return: dict
            default dict
        """
        return PresetDict.get_default(k)

    @staticmethod
    def get_keys(k):
        """
        Get the keys belonging to a preset.

        Is part of a Preset template.

        k: string
            of preset

        Return: list
            of preset keys
            of string
        """
        return PresetDict.get_keys(k)

    def get_value(self):
        """
        Return the preset dictionary.

        Skip widget(s) without keys in the dictionary.
        ModelList widgets don't have preset dictionary values.
        """
        d = {}
        e = self.group.d

        for i in PresetDict.get_keys(self.group_key):
            d[i] = e[i].get_value()
        return d

    def load(self, n, external_preset):
        """
        Load a preset.

        n: string
            name of preset

        external_preset: dict
            The key is the preset name.
            The value is the file path.

        Return: dict
            the loaded preset
        """
        Draw.load_count += 1

        if external_preset and n in external_preset:
            d = OZ.pickle_load(
                {
                    pc.FILE: external_preset[n],
                    pc.SHOW_ERROR: True
                }
            )

        else:
            d = PresetDict.get_default(self.group_key)

        self.set_value(d)

        Draw.load_count -= 1
        return d

    def load_preset(self, d):
        """
        Load a preset dictionary into its widgets.

        d: dict
            of preset
        """
        Draw.load_count += 1

        self.set_value(d)
        Draw.load_count -= 1

    def set_value(self, d):
        """
        Load the preset on a menu change.

        d: dict
            Preset dict or None
        """
        Draw.load_count += 1
        e = self.group.d

        if self.group.group_type == PerCell:
            for i, a in d.items():
                # Find the Per Cell key.
                if i in e:
                    Core.check_per_cell(self.group.d[ok.PER_CELL], a)

        else:
            # Synchronize preset with the default keys.
            Core.synchronize_preset(d, self.get_default(self.group_key))

        [e[i].set_value(d[i]) for i in e if i in d]
        Draw.load_count -= 1


class SuperPreset(Preset):
    """Has sub-presets."""

    def __init__(self, **d):
        """
        Initialize the Preset.

        d: dict
            Has keyword init values.
        """
        # Port is PortMain.
        # Remember values needed to load the tree.
        Preset.__init__(self, **d)

    def _expand_tree(self, d, a, g, k, z_list=None):
        """
        Use recursion to walk through the option groups
        setting the list values. Make the grid
        and custom cell branches form.

        d: dict
            of SuperPreset
            Has the values to load into widgets.

        a: OptionGroup
            Has the needed info.

        g: Node
            Has branches.

        k: tuple
            path
            Is the key for the group dict.

        z_list: ModelList or None

        Return: tuple
            OptionGroup, Node, path key, ModelList
            for recursion
        """
        if g:
            for i in g.get_value():
                # path, a step, key, 'k1'
                k1 = k + (i,)

                if k1 in Hat.cat.group_dict:
                    # OptionGroup, 'a'
                    a = Hat.cat.group_dict[k1]

                    if a.node:
                        g = a.node
                        a, g, k1, z_list = self._expand_tree(
                            d,
                            a,
                            g,
                            k1,
                            z_list=z_list
                        )
                    else:
                        # widget dict, 'e'
                        e = a.d

                        # SuperPresets are not in the save dict.
                        if k1 in d:
                            # loaded option dict, 'd1'
                            d1 = d[k1]

                            # Option key, 'j', and widget, 'g'
                            for j, g in e.items():
                                if j in d1:
                                    if isinstance(g, ModelList):
                                        g.set_value(
                                            d1[j],
                                            is_preset=True
                                        )
                                        z_list = g
                                    elif isinstance(g, OptionList):
                                        g.set_value(d1[j])
        return a, g, k, z_list

    def _load_steps(self, d):
        """
        There are two phases to loading a Steps SuperPreset:

        (1) Create the option groups.
        (2) Load the option group values.

        d: dict
            Is a relational-type database.
            key: path, value: group dict
        """
        # Walk-through the Nodes to get additional steps.
        path = sk.STEPS
        group, node = get_group(path)
        model_list = self._expand_tree(d, group, node, path)[3]

        # Translate the SuperPreset names into an id number.
        if model_list:
            for i in model_list.get_value():
                n = i[md.NAME_INDEX]
                _id = Hat.dog.group_id.get_id(n)
                d = Core.translate_to_id(d, n, _id)
                path = sk.EFFECT + (_id,)
                group, node = get_group(path)
                d = Core.translate_model_to_id(
                    d,
                    self._expand_tree(d, group, node, path)[3]
                )
        SuperPreset._load_widgets(d)

    def _load_sub_steps(self, d, q):
        """
        Load widgets of a sub-SuperPreset.

        d: dict
            of Effect

        q: tuple
            of indices in path where the group id is inserted
        """
        path = self.group.path[:-1]
        group, node = get_group(path)

        # Get ids in the path.
        q1 = []

        for i in q:
            q1 += [path[i]]

        # Translate the name into its id.
        e = {}

        for i, a in d.items():
            # If 'i' is not a tuple, then the dict is the wrong version.
            if isinstance(i, tuple):
                q3 = list(i)

                for j in range(len(q)):
                    q3[q[j]] = q1[j]
                e[tuple(q3)] = a

        d = Core.translate_model_to_id(
            e,
            self._expand_tree(e, group, node, path)[3]
        )
        SuperPreset._load_widgets(d)

    @staticmethod
    def _load_widgets(d):
        """
        Load the widgets from a translated SuperPreset dictionary.

        d: dict
            of SuperPreset
        """
        is_err = False
        e = Hat.cat.group_dict

        # Set the values of the options.
        for i, d1 in d.items():
            for j, a in d1.items():
                # option value, 'a'
                if j != sk.SELECTED_ROW:
                    if i in e and j in e[i].d:
                        # Don't set it twice.
                        if type(e[i].d[j]) not in (ModelList, OptionList):
                            g = e[i].d[j]
                            g.group.changed = g.group.unseen = True
                            a = Core.update_version(g, a)
                            g.set_value(a)
                    else:
                        if not is_err:
                            # Report an error one time.
                            Comm.info_msg(LOAD_ERR)
                        is_err = True
                else:
                    if a is not None:
                        if i in e:
                            k = [k for k in e[i].d][0]
                            # Select Node item.
                            e[i].d[k].select_item(a)

    @staticmethod
    def _translate_step(q):
        """
        Replace a numeric id with its corresponding name.

        q: tuple
            a step key

        Return: tuple
            the translated step
        """
        q1 = []
        group_id = Hat.dog.group_id

        if len(q) > fs.MODEL_INDEX:
            if isinstance(q[fs.MODEL_INDEX], int):
                q1 += [fs.MODEL_INDEX]

        if q1:
            q2 = list(q)

            for x1 in q1:
                q2[x1] = group_id.get_name(q[x1])
            q = tuple(q2)
        return q

    def get_value(self):
        """
        Collect a SuperPreset dictionary.

        Use when saving a SuperPreset.

        Return: dict
            of SuperPreset
            key: step; value: option group dict
        """
        k = sk.STEPS if self.group_key == gk.PRESET_STEPS else \
            self.group.path[:-1]

        d = Core.get_steps(k, with_list=False)[0]
        return Core.translate_to_name(d)

    def set_value(self, d):
        """
        Override the 'set_value' function in the Preset class.

        d: dict
            of super preset
        """
        if not d:
            # 'q', steps in the SuperPreset where
            # each step is a key to an option group.
            q = []

            # Use default dict.
            if self.group_key == gk.PRESET_STEPS:
                d = PRESET_STEPS
            else:
                if not Draw.preset_load_count:
                    # Create a default dict.
                    path = self.group.path[:-1]
                    q = Core.get_steps(path, with_dict=False)[1]

                # Set the name of the default SuperCell.
                if self.group_key == gk.PRESET_TABLE:
                    NonPresetDict.update_model_item_name(
                        gk.TABLE_PROPERTY,
                        ok.TABLE_NAME,
                        "Table 1"
                    )

                else:
                    NonPresetDict.update_model_item_name(
                        gk.CUSTOM_CELL_PROPERTY,
                        ok.CELL_NAME,
                        "Cell 1"
                    )

                # Remove useless paths.
                for x, i in enumerate([j for j in q]):
                    # Get OptionGroup, 'a'.
                    a = Hat.cat.group_dict[i]
                    if a.group_type not in (Node, SuperPreset):
                        d[i] = a.group_type.get_default(a.group_key)
        if d:
            Draw.preset_load_count += 1

            if self.group_key == gk.PRESET_STEPS:
                self._load_steps(d)

            else:
                # sub-SuperPreset
                x = (
                    gk.PRESET_TABLE,
                    gk.PRESET_CUSTOM_CELL,
                    gk.PRESET_TRI_SHADOW
                ).index(self.group_key)
                q = ((fs.MODEL_INDEX,), (fs.MODEL_INDEX,), ())[x]
                self._load_sub_steps(d, q)
            Draw.preset_load_count -= 1


class NonPreset:
    """
    Are dictionaries that do not have a preset,
    but still have options. Use when drawing groups.
    """

    @staticmethod
    def get_default(k):
        """
        Get a preset dictionary.

        Is part of a Preset template.

        k: string
            of preset

        Return: dict
            default dict
        """
        return NonPresetDict.get_default(k)

    @staticmethod
    def get_keys(k):
        """
        Get the keys belonging to a preset.

        Is part of a Preset template.

        k: string
            of preset

        Return: list
            of preset keys
            of string
        """
        return NonPresetDict.get_keys(k)

    @staticmethod
    def load(d, k):
        """
        Load the default settings for a Non-Preset group.

        d: dict
            of widgets

        k: string
            group key
        """
        Draw.load_count += 1
        e = NonPreset.get_default(k)

        [d[i].set_value(e[i]) for i in e if i in d]
        Draw.load_count -= 1


class PerCell(Preset):
    """
    Inherit the functionality of a Preset.

    Use an option group that have a PerCellGroup.
    """
    def __init__(self, **d):
        Preset.__init__(self, **d)


BEHIND_TYPE = {wk.HAS_PREVIEW: True, wk.WIDGET: NonPreset}
