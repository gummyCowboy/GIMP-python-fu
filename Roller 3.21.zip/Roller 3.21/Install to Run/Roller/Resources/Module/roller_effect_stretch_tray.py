#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_render_gradient_light import GradientLight
import gimpfu as fu

pdb = fu.pdb
em = Fu.Emboss
ta = Fu.ThresholdAlpha
FOUR_COORDINATES = 4


def do_job(effect_layer, image_layer, o, sel):
    """
    Receive task from BorderLine.
    Draw the stretched tray.

    effect_layer: layer
        Provides parent.

    image_layer: layer
        with image material

    o: One
        with options

    sel: Selection
        for filler material

    Return: layer
        with filler material
    """
    def wind(z_, dir_):
        pdb.plug_in_wind(
            j, z_,
            Fu.Wind.THRESHOLD_0,
            dir_,
            Fu.Wind.STRENGTH_30,
            Fu.Wind.WIND,
            Fu.Wind.LEADING_EDGE,
        )
        pdb.plug_in_threshold_alpha(j, z_, ta.THRESHOLD_ALL)

    cat = Hat.cat
    j = cat.render.image
    parent = effect_layer.parent

    # Duplicate the image layer.
    z = Lay.clone(image_layer)

    group = Lay.group(j, o.k, parent=parent, layer=z)

    # The Stack model has a group of images
    # that act as one layer for the effect.
    if pdb.gimp_item_is_group(z):
        z = Lay.merge_group(z)

    z1 = Lay.clone_opaque(z)

    Lay.apply_mask(z1)

    z2 = Lay.clone(z1)
    z3 = Lay.clone(z1)
    z4 = Lay.clone(z1)

    for q in (
        (z1, Fu.Wind.FROM_TOP),
        (z2, Fu.Wind.FROM_BOTTOM),
        (z3, Fu.Wind.FROM_LEFT),
        (z4, Fu.Wind.FROM_RIGHT)
    ):
        wind(*q)

    z = Lay.merge_group(group)

    Sel.load(j, sel)
    Sel.isolate(z, sel)
    pdb.gimp_curves_spline(z, fu.HISTOGRAM_VALUE, 4, [0, 64, 255, 187])
    Gegl.saturation(z, 10.)

    z1 = Lay.clone(z)
    z1.mode = fu.LAYER_MODE_HARDLIGHT
    z1.opacity = 80.

    pdb.gimp_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        FOUR_COORDINATES,
        [0, 117, 255, 137]
    )
    pdb.plug_in_emboss(
        j, z,
        cat.azimuth,
        cat.elevation,
        em.DEPTH_3,
        em.EMBOSS
    )

    z = Lay.merge(z1)
    z = GradientLight.apply_light(z, ok.OTHER_FRAME)

    pdb.gimp_image_reorder_item(j, z, parent, 0)
    return z


class StretchTray:
    """Stretch the image in horizontal and vertical directions."""

    @staticmethod
    def do(o):
        """
        Do the image-effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer or None
            Is border.
        """
        return BorderLine.do(o, filler=do_job)
