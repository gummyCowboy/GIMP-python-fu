#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Widget as fw
from roller_constant_key import (
    Button as bk,
    Group as gk,
    Step as sk,
    Widget as wk,
    Window as wi
)
from roller_one import Hat
from roller_one_draw import Draw
from roller_option_preset_core import Core
from roller_port import Port
from roller_port_main_dict import MainDict
from roller_port_node import PortNode
from roller_port_preview import PortPreview
from roller_widget_box import VBow
from roller_widget_label import Label
from roller_window import Window
from roller_window_save import RWSave
import gtk


class RWShadow(Window):
    """
    Is a GTK dialog with multiple options for the user to define a shadow.
    """
    def __init__(self, g):
        """
        Create a shadow-choice window.

        g: Button
            Is responsible.
        """
        self.safe = g
        d = {
            wk.WIN: g.win.win,
            wk.WINDOW_TITLE: "Choose Shadow Type",
            wk.WINDOW_KEY: wi.SHADOW_CHOOSER
        }

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortShadow(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()


class PortShadow(PortPreview):
    """Offer options for defining a shadow."""

    def __init__(self, d, g):
        """
        Create a shadow-choice port.

        d: dict
            Has init values.

        g: OptionButton
            Has option values.
        """
        d.update({
            wk.IS_DEFAULT: False,
            wk.ON_KEY_PRESS: self.on_key_press,
            wk.ON_PREVIEW_BUTTON: Core.make_preview,
            wk.ON_WIDGET_CHANGE: self.on_widget_change,
            wk.PORT: self,
            wk.SAVE_WINDOW: RWSave
        })
        self.d = d
        self._port_node = PortNode(self.d, MainDict())

        d.update(self.d)
        PortPreview.__init__(self, d, g)

    def _draw_navigation(self, g):
        """
        Draw the shadow choices group.

        g: GTK container
            to receive group
        """
        self.d.update({wk.COLOR: self.color})

        hbox = self.d[wk.NAV_BOX] = gtk.HBox()
        vbox = VBow()

        vbox.add(
            Label(
                padding=(4, 4, 4, fw.MARGIN),
                text="Shadows:"
            )
        )

        hbox.junctions = [vbox]
        a = self.color

        hbox.add(vbox)
        g.add(hbox)
        self._port_node.draw_options(vbox, gk.TRI_SHADOW, 0, ())

        self.color = a
        g = Hat.cat.group_dict[sk.TRI_SHADOW_PRESET].d[wk.PRESET]
        self.group = g.group

        g.load_preset(self.safe.get_value())
        for i in range(len(self.d[wk.NAV_BOX].junctions)):
            self.reduce_color()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        self.draw_simple_dialog_port(
            g,
            (self._draw_navigation, self.draw_preview_process),
            ("Shadow Options", "")
        )

    @staticmethod
    def get_group_value():
        """
        Use to get the preset value.
        Call from PortPreview.

        Return: dict
            of tri-shadow, the super-preset
        """
        return Core.get_steps(sk.TRI_SHADOW, with_list=False)[0]

    def on_widget_change(self, g):
        """
        Call when a widget value changes.

        g: Widget
            Is responsible.
        """
        if not Draw.load_count:
            if g.key == bk.RANDOM:
                Port.randomize_widgets(g)
        return super(PortShadow, self).on_widget_change(g)
