#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_grid_hexagon_truncated import HexagonTruncated
from roller_one import Rect
from roller_one_extract import Shape

CELL_SIZE = gr.CELL_SIZE


class EllipsisVert(HexagonTruncated):
    """
    Calculate the position and the size of cells.

    The cells are ellipse shaped.

    Use a double-spaced grid-type.
    """

    def __init__(self, o):
        """
        Calculate the ellipse cell size rectangle and the ellipse shape.

        o: One
            Has init values.
        """
        HexagonTruncated.__init__(self, o)
        row, column = o.r, o.c
        table = self.grid.table
        is_by_count = False if o.grid_type == CELL_SIZE else True
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(self.grid, r, c):
                    a = table[r][c]

                    # cell rectangle, 'b'
                    b = a.cell

                    if is_by_count:
                        e = a.shape = a.plaque = Shape.calc_vertical_ellipse(b)

                        # The ellipse rect is smaller than the hexagon rect.
                        a.cell = Rect(
                            (e['x'], e['y']),
                            (e['w'], e['h'])
                        )
                    else:
                        a.shape = a.plaque = {'x': b.x, 'y': b.y, 'w': b.w, 'h': b.h}
