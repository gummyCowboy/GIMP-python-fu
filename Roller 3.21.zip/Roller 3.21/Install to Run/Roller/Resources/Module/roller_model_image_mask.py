#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Mask as ms,
    Model as mo,
    Shape as sh,
    Stack as st,
    Triangle as ft
)
from roller_constant_key import Layer as nk, Model as md, Option as ok
from roller_effect_feather_steps import FeatherSteps
from roller_model_image import Image
from roller_model_text import Text
from roller_one import Comm, Hat, Rect
from roller_one_fu import Lay, Mage, Sel
from roller_one_extract import dispatch, Form, Shape
import gimpfu as fu
import math

pdb = fu.pdb
NO_ANTIALIAS = 0
RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP
X_IS_0 = Y_IS_0 = 0
YES_AUTO_CENTER = True


def do_circle(j, o):
    """
    Add a circle selection to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    # Make into a circle.
    # topleft, x, y
    w = min(o.w, o.h)
    Sel.ellipse(
        j,
        o.center_x - w // 2, o.center_y - w // 2,
        w, w,
        option=fu.CHANNEL_OP_REPLACE
    )


def do_cut_corners_mask(j, o):
    """
    Add a cut corners selection to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    x, y, w, h = o.x, o.y, o.w, o.h
    w1 = (o.image_w - w) // 2
    h1 = (o.image_h - h) // 2

    # eight segments
    q = (
        x + w1, y,
        x + o.image_w - w1, y,
        x + o.image_w, y + h1,
        x + o.image_w, y + o.image_h - h1,
        x + o.image_w - w1, y + o.image_h,
        x + w1, y + o.image_h,
        x, y + o.image_h - h1,
        x, y + h1
    )
    Sel.polygon(j, q)


def do_rhombus_shear(j, o):
    """
    Add a sheared rhombus selection to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w, h = o.w // 2, o.h // 2
    x = o.center_x
    y = o.center_y

    # four segments
    q = (
        x, y - h,
        x + w, y,
        x, y + h,
        x - w, y
    )
    Sel.polygon(j, q)


def do_eye(j, o):
    """
    Add an eye selection to the selection.

    The circle radius formula was on the internet.
        rechneronline.de/pi/circular-segment.php
        radius = (w² / 4 + h²) / 2 / h

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w, h = o.w, o.h / 2
    x = o.center_x - (w // 2)
    y = o.center_y - h
    radius = (w * w / 4 + h * h) / 2 / h
    diameter = radius * 2
    x = x - (diameter - w) // 2

    Sel.ellipse(j, x, y, diameter, diameter, option=fu.CHANNEL_OP_REPLACE)
    Sel.ellipse(
        j,
        x, y - diameter + o.h,
        diameter, diameter,
        option=fu.CHANNEL_OP_INTERSECT
    )


def do_hexagon_regular(j, o):
    """
    Add a sheared regular hexagon shape to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w, h = o.w, o.h

    # There are two possible solutions.
    # first solution
    w1, h1 = w, w * UP_RATIO

    # Check for overflow.
    if h1 > h:
        # second solution
        w1, h1 = h * RATIO, h

    q = Shape.calc_hexagon_regular_offset(w1, h1)
    Sel.polygon(
        j,
        Shape.calc_hexagon_regular_shape(
            o.center_x - q[0], o.center_y - q[2],
            w1, h1,
            q
        )
    )


def do_hexagon_regular_shear(j, o):
    """
    Add a sheared regular hexagon shape to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w, h = o.w // 2, o.h // 2
    Sel.polygon(
        j,
        Shape.calc_hexagon_regular_shape(
            o.center_x - w, o.center_y - h,
            o.w, o.h,
            Shape.calc_hexagon_regular_offset(o.w, o.h)
        )
    )


def do_hexagon_truncated(j, o):
    """
    Add a sheared and truncated hexagon shape to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w, h = o.w, o.h

    # There are two possible solutions.
    # first solution
    w1, h1 = h * UP_RATIO, h

    # Check for overflow.
    if w1 > w:
        # second solution
        w1, h1 = w, w * RATIO

    q = Shape.calc_hexagon_truncated_offset(w1, h1)
    x = o.center_x - q[1]
    y = o.center_y - q[3]
    Sel.polygon(
        j,
        Shape.calc_hexagon_truncated_shape(x, y, w1, h1, q)
    )


def do_hexagon_truncated_shear(j, o):
    """
    Add a sheared and truncated hexagon shape to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w, h = o.w // 2, o.h // 2
    Sel.polygon(
        j,
        Shape.calc_hexagon_truncated_shape(
            o.center_x - w, o.center_y - h,
            o.w, o.h,
            Shape.calc_hexagon_truncated_offset(o.w, o.h)
        )
    )


def do_image(j, o):
    """
    Add an image selection to the selection.

    Image masks transform their shape to a cell rectangle.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    j1 = Image.get_image(o.e[ok.IMAGE], o.image_index)
    if j1:
        Mage.copy_all(j1.j)

        j2 = pdb.gimp_edit_paste_as_new_image()

        # Shape, copy, and delete the image.
        Mage.shape(j2, o.w, o.h)

        z = Lay.paste(j.layers[-1])

        # the topleft corner, x, y
        x = o.center_x - o.w // 2
        y = o.center_y - o.h // 2

        pdb.gimp_layer_set_offsets(z, x, y)
        Sel.item(z)
        j.remove_layer(z)
        Image.close_image(j1)


def do_octagon_regular(j, o):
    """
    Add a regular octagon selection to the selection.

    The web address with a helpful formula:
        math.stackexchange.com/
        questions/22064/
        calculating-a-point-that-lies-on-an-ellipse-given-an-angle

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w = min(o.w, o.h)

    # topleft, x, y
    x = o.center_x - w // 2
    y = o.center_y - w // 2

    q = Shape.calc_octagon_offset(w, w)
    Sel.polygon(
        j,
        Shape.calc_octagon_shape(x, y, w, w, q)
    )


def do_octagon_shear(j, o):
    """
    Add an octagon selection to the selection.

    The web address with a helpful formula:
        math.stackexchange.com/
        questions/22064/
        calculating-a-point-that-lies-on-an-ellipse-given-an-angle

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w, h = o.w // 2, o.h // 2
    Sel.polygon(
        j,
        Shape.calc_octagon_shape(
            o.center_x - w, o.center_y - h,
            o.w, o.h,
            Shape.calc_octagon_offset(o.w, o.h)
        )
    )


def do_octagon_side_to_side_regular(j, o):
    """
    Add a sheared side-to-side octagon to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w = min(o.w, o.h)

    # topleft x, y
    x = o.center_x - w // 2
    y = o.center_y - w // 2

    q = Shape.calc_octagon_side_to_side_offset(w, w)
    Sel.polygon(
        j,
        Shape.calc_octagon_side_to_side_shape(x, y, w, w, q)
    )


def do_octagon_side_to_side_shear(j, o):
    """
    Add a sheared side-to-side octagon to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w, h = o.w // 2, o.h // 2
    Sel.polygon(
        j,
        Shape.calc_octagon_side_to_side_shape(
            o.center_x - w, o.center_y - h,
            o.w, o.h,
            Shape.calc_octagon_side_to_side_offset(o.w, o.h)
        )
    )


def do_oval(j, o):
    """
    Add a oval selection to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    # x, y are topleft.
    w, h = o.w, o.h
    Sel.ellipse(
        j,
        o.center_x - w // 2,
        o.center_y - h // 2,
        w, h,
        option=fu.CHANNEL_OP_REPLACE
    )


def do_rectangle(j, o):
    """
    Add a rectangle selection to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w, h = o.w, o.h
    x = o.center_x - w // 2
    y = o.center_y - h // 2
    Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)


def do_rhombus(j, o):
    """
    Add a rhombus selection to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w = min(o.w, o.h) // 2
    x = o.center_x
    y = o.center_y
    q = (
        x, y - w,
        x + w, y,
        x, y + w,
        x - w, y
    )
    Sel.polygon(j, q)


def do_rounded_corners(j, o):
    """
    Add a square selection to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    x, y, w, h = o.x, o.y, o.w, o.h

    # top-left
    Sel.ellipse(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)

    # top-right
    x1 = x + o.image_w - w

    Sel.ellipse(j, x1, y, w, h)

    # bottom-left
    y1 = y + o.image_h - h

    Sel.ellipse(j, x, y1, w, h)

    # bottom-right
    Sel.ellipse(j, x1, y1, w, h)

    # vertical rectangle
    x2 = x + w // 2
    w1 = o.image_w - w

    Sel.rect(j, x2, y, w1, o.image_h)

    # horizontal rectangle
    y2 = y + h // 2
    h1 = o.image_h - h

    Sel.rect(j, x, y2, o.image_w, h1)


def do_square(j, o):
    """
    Add a square selection to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    w = min(o.w, o.h)
    x = o.center_x - w // 2
    y = o.center_y - w // 2
    Sel.rect(j, x, y, w, w, option=fu.CHANNEL_OP_REPLACE)


def do_text(j, o):
    """
    Add a character selection to the selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    cat = Hat.cat
    font = o.e[ok.FONT]

    if font not in cat.font_list:
        Comm.info_msg(mo.MISSING_ITEM.format("Image-Mask", "font", font))
    else:
        font_size = max(o.w, o.h)
        character = o.e[ok.TEXT]
        if character:
            z = Lay.add(j, "text")
            go, z1 = Text.make_text_layer(
                j, z,
                NO_ANTIALIAS,
                o.x, o.y,
                character,
                font_size,
                font,
                (255, 255, 255),
                o.w, o.h
            )
            if go:
                Sel.item(z1)

                is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

                if is_sel:
                    x = o.center_x - ((x1 - x) // 2)
                    y = o.center_y - ((y1 - y) // 2)

                    pdb.gimp_layer_set_offsets(z1, x, y)
                    Sel.item(z1)
                for i in (z, z1):
                    j.remove_layer(i)


def do_triangle_down_isosceles(j, o):
    """
    Add an down-facing isosceles triangle
    selection to the existing selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    Sel.polygon(j, dispatch[ft.TRIANGLE_DOWN_ISOSCELES](
        Rect((o.center_x - o.w // 2, o.center_y - o.h // 2), (o.w, o.h)))
    )


def do_triangle_down_shear(j, o):
    """
    Add an down-facing-triangle selection
    to the existing selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    Sel.polygon(j, dispatch[ft.TRIANGLE_DOWN_SHEAR](
        Rect((o.center_x - o.w // 2, o.center_y - o.h // 2), (o.w, o.h)))
    )


def do_triangle_left_isosceles(j, o):
    """
    Add an left-facing isosceles triangle
    selection to the existing selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    Sel.polygon(j, dispatch[ft.TRIANGLE_LEFT_ISOSCELES](
        Rect((o.center_x - o.w // 2, o.center_y - o.h // 2), (o.w, o.h)))
    )


def do_triangle_left_shear(j, o):
    """
    Add an left-facing-triangle selection
    to the existing selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    Sel.polygon(j, dispatch[ft.TRIANGLE_LEFT_SHEAR](
        Rect((o.center_x - o.w // 2, o.center_y - o.h // 2), (o.w, o.h)))
    )


def do_triangle_right_isosceles(j, o):
    """
    Add an right-facing isosceles triangle
    selection to the existing selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    Sel.polygon(j, dispatch[ft.TRIANGLE_RIGHT_ISOSCELES](
        Rect((o.center_x - o.w // 2, o.center_y - o.h // 2), (o.w, o.h)))
    )


def do_triangle_right_shear(j, o):
    """
    Add an right-facing-triangle selection
    to the existing selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    Sel.polygon(j, dispatch[ft.TRIANGLE_RIGHT_SHEAR](
        Rect((o.center_x - o.w // 2, o.center_y - o.h // 2), (o.w, o.h)))
    )


def do_triangle_up_isosceles(j, o):
    """
    Add an up-facing isosceles triangle
    selection to the existing selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    Sel.polygon(j, dispatch[ft.TRIANGLE_UP_ISOSCELES](
        Rect((o.center_x - o.w // 2, o.center_y - o.h // 2), (o.w, o.h)))
    )


def do_triangle_up_shear(j, o):
    """
    Add an up-facing-triangle selection
    to the existing selection.

    j: GIMP image
        to receive selection

    o: One
        Has cell data.
    """
    Sel.polygon(j, dispatch[ft.TRIANGLE_UP_SHEAR](
        Rect((o.center_x - o.w // 2, o.center_y - o.h // 2), (o.w, o.h)))
    )


MASK_FUNCTION = {
    sh.CIRCLE: do_circle,
    ms.CUT_CORNERS: do_cut_corners_mask,
    ms.EYE: do_eye,
    sh.HEXAGON_REGULAR: do_hexagon_regular,
    sh.HEXAGON_REGULAR_SHEAR: do_hexagon_regular_shear,
    sh.HEXAGON_TRUNCATED: do_hexagon_truncated,
    sh.HEXAGON_TRUNCATED_SHEAR: do_hexagon_truncated_shear,
    ms.IMAGE: do_image,
    sh.OCTAGON_REGULAR: do_octagon_regular,
    sh.OCTAGON_SHEAR: do_octagon_shear,
    sh.OCTAGON_SIDE_TO_SIDE_REGULAR: do_octagon_side_to_side_regular,
    sh.OCTAGON_SIDE_TO_SIDE_SHEAR: do_octagon_side_to_side_shear,
    ms.OVAL: do_oval,
    sh.RECTANGLE: do_rectangle,
    sh.RHOMBUS: do_rhombus,
    sh.RHOMBUS_SHEAR: do_rhombus_shear,
    ms.ROUNDED_CORNERS: do_rounded_corners,
    sh.SQUARE: do_square,
    ms.TEXT: do_text,
    ft.TRIANGLE_DOWN_ISOSCELES: do_triangle_down_isosceles,
    ft.TRIANGLE_DOWN_SHEAR: do_triangle_down_shear,
    ft.TRIANGLE_LEFT_ISOSCELES: do_triangle_left_isosceles,
    ft.TRIANGLE_LEFT_SHEAR: do_triangle_left_shear,
    ft.TRIANGLE_RIGHT_ISOSCELES: do_triangle_right_isosceles,
    ft.TRIANGLE_RIGHT_SHEAR: do_triangle_right_shear,
    ft.TRIANGLE_UP_ISOSCELES: do_triangle_up_isosceles,
    ft.TRIANGLE_UP_SHEAR: do_triangle_up_shear
}


class ImageMask:
    """Manage image mask related tasks with a static class."""

    @staticmethod
    def _do_grid(j, z, o, is_one_stack_group=False):
        """
        Make a mask layer for the image layer.
        The masks are defined by the user in
        the image / mask option.

        j: GIMP image
            Is render.

        z: layer
            with images

        o: One
            Has variables.

        Return: layer or None
            Has a layer with an image if it received a mask.
        """
        cat = Hat.cat
        row, column = o.grid.division
        d = o.d
        grid_d = o.grid.d
        is_merge_cell = o.grid.is_merge_cell
        name = o.model_name
        has_mask = False
        go = True
        is_group = o.is_image_group or is_one_stack_group
        is_table = o.model == md.TABLE

        if is_group:
            # image layer's z-height, 'n'
            n = z.name.split(" ")[-1]

        if not d[ok.PER_CELL] and d[ok.MASK_TYPE] == "None":
            go = False

        if go:
            for r in range(row):
                for c in range(column):
                    go = True
                    o.r, o.c = r, c
                    e = o.e = Form.get_form(o)
                    n1 = e[ok.MASK_TYPE]
                    k = name, r, c

                    if n1 == "None":
                        go = False

                    if go and is_table:
                        go = Shape.is_allocated_cell(o.grid, r, c)

                    if go:
                        go = cat.is_image_sel(k)

                    if go:
                        if (
                            is_merge_cell and
                            grid_d[ok.PER_CELL][r][c] == (-1, -1)
                        ):
                            go = False

                    if go:
                        if is_group:
                            if cat.get_z_height(k) != n:
                                go = False

                    if go:
                        rect = o.grid.get_mold(r, c)
                        x, y, = o.x, o.y = rect.position
                        w, h = o.w, o.h = o.image_w, o.image_h = rect.size

                        # x, y, w, h, '\t', r, c
                        o.center_x, o.center_y = x + w // 2, y + h // 2

                        # scale
                        o.w *= e[ok.HORZ_SCALE]
                        o.h *= e[ok.VERT_SCALE]

                        # Add a mask.
                        if n1 in MASK_FUNCTION:
                            MASK_FUNCTION[n1](j, o)

                            if Sel.is_sel(j):
                                FeatherSteps.feather_sel(j, e)
                            ImageMask.rotate_mask(j, e)
                        if Sel.is_sel(j):
                            cat.save_mask_sel(k)
                            has_mask = True

        # Preserve an image view by adding its selection to the mask layer.
        q = []

        if has_mask:
            for r in range(row):
                for c in range(column):
                    k = name, r, c

                    if is_group:
                        if cat.get_z_height(k) != n:
                            continue

                    sel = cat.get_image_sel(k)
                    sel1 = cat.get_mask_sel(k)
                    if sel and not sel1:
                        q += [sel]

        pdb.gimp_selection_none(j)

        # Combine the image mask selections.
        if has_mask:
            for r in range(row):
                for c in range(column):
                    k = name, r, c

                    if is_group:
                        if cat.get_z_height(k) != n:
                            continue

                    sel = cat.get_mask_sel(k)
                    Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

        # Were there any masks?
        # If so, then create a layer mask for the image layer.
        if Sel.is_sel(j):
            for i in q:
                Sel.load(j, i, option=fu.CHANNEL_OP_ADD)

            mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)

            pdb.gimp_layer_add_mask(z, mask)
            return z

    @staticmethod
    def do_custom_cell(o):
        """
        Make a mask layer for the image layer.
        The masks are defined by the user in
        the image / mask option.

        o: One
            Has variables.

        Return: layer or None
            Has a layer with an image if it received a mask.
        """
        cat = Hat.cat
        j = cat.render.image
        d = o.e = o.d
        name = o.model_name
        has_mask = False
        sel = cat.get_image_sel(name)
        _type = d[ok.MASK_TYPE]

        # the custom cell's cell reference
        o.r = o.c = 0

        if _type != "None" and sel:
            a = o.grid.get_mold(o.r, o.c)
            x, y = a.position
            w, h = o.image_w, o.image_h = a.size
            o.x, o.y = x, y
            o.center_x, o.center_y = x + w // 2, y + h // 2

            # scale
            o.w = w * d[ok.HORZ_SCALE]
            o.h = h * d[ok.VERT_SCALE]

            # Add a mask.
            if _type in MASK_FUNCTION:
                MASK_FUNCTION[_type](j, o)
                has_mask = True
        if has_mask and Sel.is_sel(j):
            FeatherSteps.feather_sel(j, d)
        if has_mask and Sel.is_sel(j):
            ImageMask.rotate_mask(j, d)
            cat.save_mask_sel(name)

            # image layer, 'z'
            z = cat.get_layer((o.render_type, o.model_name, nk.IMAGE))
            if z:
                mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)
                pdb.gimp_layer_add_mask(z, mask)
            return z

    @staticmethod
    def do_layers(o):
        """
        Make a mask layer for the image layer(s).
        The masks are defined by the user in
        the image / mask option.

        The Table model has two image-location
        configurations in the layer palette.

        o: One
            Has 'image_layer', the location of image layer(s).

        Return: layer, list, or None
            Has a layer with an image if it received a mask.
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # 'undo_z' is a list of layers for the preview's undo function.
        undo_z = []

        if z:
            o.is_image_group = pdb.gimp_item_is_group(z) if z else False

            if o.is_image_group:
                for i in z.layers:
                    undo_z += [ImageMask._do_grid(j, i.layers[0], o)]
                undo_z = tuple(undo_z)
            else:
                undo_z = ImageMask._do_grid(j, z, o)
        return undo_z

    @staticmethod
    def do_stack(o):
        """
        Make a mask layer for the image layer(s).
        The masks are defined by the user in
        the image / mask option.

        The Stack model has three image-location
        configurations in the layer palette.

        o: One
            Has 'image_layer', the location of image layer(s).
        """
        j = Hat.cat.render.image

        # 'undo_z' is a list of layers for the preview's undo function.
        undo_z = []

        # the Stack's cell reference
        o.r = o.c = 0

        group = o.image_layer

        if group:
            is_layer = not pdb.gimp_item_is_group(group)
            if group:
                if is_layer:
                    o.is_image_group = False
                    undo_z += [ImageMask._do_grid(j, group, o)]

                elif o.grid.image_group_type == st.ONE_GROUP:
                    z = group.layers[0]
                    o.is_image_group = pdb.gimp_item_is_group(z) if z \
                        else False

                    if o.is_image_group:
                        for i in z.layers:
                            undo_z += [ImageMask._do_grid(j, i, o)]
                    else:
                        for i in group.layers:
                            undo_z += [
                                ImageMask._do_grid(
                                    j, i,
                                    o,
                                    is_one_stack_group=True
                                )
                            ]
                else:
                    o.is_image_group = True
                    for group1 in group.layers:
                        undo_z += [ImageMask._do_grid(j, group1.layers[0], o)]
        return tuple(undo_z)

    @staticmethod
    def rotate_mask(j, d):
        """
        Rotate the mask selection.

        j: GIMP image
            Is render.

        d: dict
            of image mask preset

        Return: state of selection
        """
        if Sel.is_sel(j) and d[ok.ROTATE]:
            z = Lay.add(j, "Rotate")

            Sel.fill(z, (0, 0, 0))

            z1 = pdb.gimp_item_transform_rotate(
                z,
                math.radians(d[ok.ROTATE]),
                YES_AUTO_CENTER,
                X_IS_0,
                Y_IS_0
            )

            Sel.item(z1)
            Lay.remove_layers((z, z1))
