#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_border_line import BorderLine
from roller_constant import OptionKey, SessionKey
from roller_fu import Lay, Sel
import gimpfu as fu


class SquarePunch(BorderLine):
    """Add a square holes to a frame that fits around a BorderLine frame."""
    name = SessionKey.SQUARE_PUNCH
    width_low, width_high = 3, 15
    filler_width_low, filler_width_high = 20, 60

    def __init__(self, d, stat):
        """
        d: dict
            sub-session dict

        stat: Stat
            global variables
        """
        BorderLine.__init__(
                self,
                d,
                stat,
                name=SessionKey.SQUARE_PUNCH,
                framer=self.make_line_sel,
                filler=lambda *args: None
            )

    def draw_lines(self, j, z, d):
        """
        Draw vertical and horizontal lines.

        j: GIMP image
            target image

        z: layer
            target layer

        d: dict
            sub-session dict
        """
        ok = OptionKey
        x = y = 0
        w, h = j.width, j.height
        z.mode, z.opacity = fu.LAYER_MODE_NORMAL, 100.
        w1, w2 = d[ok.LINE_WIDTH], d[ok.GAP_WIDTH]

        while x < w:
            Sel.rect(j, x, 0, w1, h, mode=fu.CHANNEL_OP_ADD)
            x += w1 + w2
            x = min(x, w)

        while y < h:
            Sel.rect(j, 0, y, w, w1, mode=fu.CHANNEL_OP_ADD)
            y += w1 + w2
            y = min(y, h)

        Sel.fill(z, (0, 0, 0))
        return z

    def make_line_sel(self, d):
        """
        Modify the current selection with the selected grid lines.

        Add the grid selection to the border selection
        within the bounds of the filler selection.

        d: dict
            sub-session dict
        """
        j = self.stat.render
        border_sel = self.stat.save_channel()
        z = z1 = Lay.add(j, self.id, self.group)
        z = self.do_rotated_layer(z, d, self.draw_lines)

        Sel.isolate(j, z, self.fill_sel)
        Sel.item(j, z)
        Sel.grow(j, 1, 1)
        Sel.feather(j, 1)
        Lay.bury(j, z)
        Lay.bury(j, z1)
        Sel.load(j, border_sel, option=fu.CHANNEL_OP_ADD)
