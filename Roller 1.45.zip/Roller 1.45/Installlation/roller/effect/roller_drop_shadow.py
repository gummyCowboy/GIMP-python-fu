#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import SessionKey
from roller_shadow import Shadow


class DropShadow(Shadow):
    """Create a drop shadow effect on an image layer."""
    name = SessionKey.DROP_SHADOW

    def __init__(self, _, stat, n=SessionKey.DROP_SHADOW, q=None):
        """
        stat: Stat
        n: effect name
        q: layer tuple
            layer(s) that cast shadow together
        """
        self.name = n
        Shadow.__init__(self, n, stat, q=q)
