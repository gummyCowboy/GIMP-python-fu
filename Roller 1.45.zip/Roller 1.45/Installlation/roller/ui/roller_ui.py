#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_base import Base
from roller_constant import ForColor, ForFormat, ForWidget, UIKey
from roller_switch_button import SwitchButton
import gtk

# Widgets that will signal a window's accept
# process upon receiving the return key:
RETURN_WIDGETS = (
        gtk.CheckButton,
        gtk.Entry,
        gtk.RadioButton,
        gtk.ScrolledWindow,
        gtk.SpinButton,
        gtk.ToggleButton,
        gtk.TreeView,
        SwitchButton
    )


class UI:
    """
    Create windows.

    Has common user-interface functions.

    If the widget has memory of its state, use an UI widget template
    for 'get' and 'set' operations:
        controls: iterable
            an iterable of widget(s) with memory

        get_value: function
            Call to get the value of a widget in controls.

        load_controls: function
            Call to set the values of the window's widgets.

        set_value: function
            Call to set the value of widgets in controls.

    UI windows follow a UI window template:
        draw_window: function
            Call to let the window create widgets.

    Has a UI preset template property:
        self.preset_menu: combobox
            Use to set the menu to undefined.
    """
    # Signal that the widget is in a loading state, and that the
    # event handler can ignore the change or action event:
    loading = 0

    # This is the reference to the window with a ‟gtk.main” event loop:
    loop = None

    # constant:
    COLOR_DEC = 2200

    def __init__(self, d):
        """
        Create a window.

        The new window can be a normal window with it's own event
        handler, or be a dialog. There can only be one open window
        with an event handler at a time.

        d: UI dict
        """
        self.pigs = []
        self.accept = d[UIKey.ON_RETURN]
        self.stat = d[UIKey.STAT]
        self.color = ForColor.MAX_COLOR - UI.COLOR_DEC

        # ‟self.pose_key” is the window's key in the window dict:
        self.pose_key = d[UIKey.WINDOW_KEY]

        if not UI.loop:
            is_dialog = 0
            g = self.win = UI.loop = gtk.Window()
            g.set_title(d[UIKey.WINDOW_TITLE])

        else:
            self.reply = 0
            is_dialog = 1
            g = self.win = gtk.Dialog(
                    d[UIKey.WINDOW_TITLE],
                    UI.loop,
                    gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
                    None
                )

        UI.loading += 1

        self.draw_window()

        UI.loading -= 1

        g.set_position(gtk.WIN_POS_CENTER)
        g.show_all()

        if self.pose_key in self.stat.window_pose:
            # Make sure the position isn't off screen:
            w, h = UI.get_screen_res()
            w1, h1 = self.win.allocation.width, self.win.allocation.height
            x, y = self.stat.window_pose[self.pose_key]
            x = Base.seal(x, 0, w - w1)
            y = Base.seal(y, 0, h - h1 - ForWidget.SCROLL_SPAN)
            g.move(x, y)

        else:
            w, h = UI.get_screen_res()
            w1, h1 = self.win.allocation.width, self.win.allocation.height
            g.move(w / 2 - w1 / 2, h / 2 - h1 / 2)

        g.connect('delete_event', self.close)
        g.connect('key_press_event', self.on_key_press)

        if is_dialog:
            self.win.run()
            self.win.destroy()

    def close(self, *_):
        """
        Close the window.
        Exit the main loop.

        Return true to let GTK know that the closing operation is handled.
        """
        g = self.win
        self.stat.window_pose[self.pose_key] = g.get_position()

        if g == UI.loop:
            g.destroy()
            gtk.main_quit()
            UI.loop = None

        else:
            g.hide()
            g.response(0)
        return 1

    def do_return(self):
        """Accept the window's contents on a return key event."""
        return self.accept()

    def get_remaining_dim(self, w, h):
        """
        Use to keep the dynamically sized Per
        Cell windows from drawing off screen.

        Return the width and height of the screen space
        to the right and bottom of the window.
        """
        w1, h1 = UI.get_screen_res()

        if self.pose_key in self.stat.window_pose:
            x, y = self.stat.window_pose[self.pose_key]

        else:
            x = w1 / 2
            y = h1 / 2

        x = Base.seal(x, x + ForWidget.SCROLL_SPAN, w1 - 200)
        y = Base.seal(y, y + ForWidget.SCROLL_SPAN, h1 - 200)
        return min(w, w1 - x), min(h, h1 - y)

    @staticmethod
    def get_screen_res():
        """Return the (width, height) of the screen's dimension."""
        return gtk.gdk.screen_width(), gtk.gdk.screen_height()

    def keep(self, q):
        """
        Put widget reference into ‟self.pigs”.

        This keeps the GTK garbage
        collection from removing connections
        when a secondary window is opened.

        q: widgets
        """
        for g in q:
            self.pigs.append(g)

    def load_controls(self, d):
        """
        Load the controls from a preset.

        Is part of a UI widget template.

        d: preset
        """
        return self.update_controls(d)

    def on_key_press(self, _, a):
        """
        Check to see if the user pressed the Esc key.
        If so, then close the window.

        a: key-press event
        """
        n = gtk.gdk.keyval_name(a.keyval)
        if n == 'Escape':
            return self.close()

        elif n == 'Return':
            g = self.win.get_focus()
            q = RETURN_WIDGETS

            if type(g) in q:
                return self.do_return()

    def on_list_change(self, index):
        """
        Respond when user changes selection in the navigation list.

        Is part of NavigationList class template.

        index: int
            selected row index in navigation list
        """
        if not self.group_visibility[index]:
            self.switch_group_box.add(self.group_box[index])
            self.group_visibility[index] = 1

        self.win.show_all()

        for x, _ in enumerate(self.group_box):
            if self.group_visibility[x]:
                if x != index:
                    self.group_box[x].hide()

        # Resize the window with the group-size change:
        self.win.resize(1, 1)

    def preset_is_undefined(self):
        """Set the preset ComboBox display to undefined."""
        if not UI.loading:
            self.preset_menu.set_text(ForWidget.UNDEFINED)
            self.preset_menu.verify_del_button()

    def reduce_color(self):
        """‟self.color” is used by the red and green color channels."""
        self.color -= UI.COLOR_DEC

    def update_controls(self, d):
        """
        Load a window's controls.

        d: dict that stores control values

        Is part of a UI widget template.

        Return the dict.
        """
        UI.loading += 1

        for g in self.controls:
            g.set_value(d[g.key])

        UI.loading -= 1
        return d

    def verify_opacity_depend(self, g, cb=None):
        """
        Verify property group widgets based on the opacity value.

        g: opacity SpinButton
        cb: Per Cell Checkbutton
        """
        q = g.rot, g.flip_h, g.flip_v, g.blur

        if not cb:
            do = 1

        else:
            do = not cb.get_value()
        if do:
            if g.get_value():
                for i in q:
                    i.enable()

            else:
                for i in q:
                    i.disable()

    def verify_place_menus(self, g):
        """
        Resize/Fill Cell and Image/None options causes
        some of the other menu options to be invalid.

        g: Placement ComboBox
        """
        ff = ForFormat
        if (
                g.resize_combobox.get_value() == ff.FILL_CELL or
                g.image_combobox.get_value() == ff.NONE
                ):
            g.vertical_combobox.disable()
            g.horizontal_combobox.disable()

        else:
            g.vertical_combobox.enable()
            g.horizontal_combobox.enable()

        if g.image_combobox.get_value() == ff.NONE:
            g.resize_combobox.disable()

        else:
            g.resize_combobox.enable()
