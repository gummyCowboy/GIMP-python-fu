#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_widget import Widget
import gtk


class RollerSpinButton(Widget):
    """This is a custom GTK SpinButton."""

    def __init__(
                self,
                on_change,
                limit,
                key=None,
                step=(1, 1),
                label=None,
                padding=None,
                type_index=0,
                precision=3
            ):
        """
        on_change: function
            Call on change.

        limit: tuple (low, high)
            Limit of the SpinButton value.

        key: string
            widget key

        step: tuple
            (increment, speed value) of the GTK.SpinButton

        label: RollerLabel
            label that is attached to the SpinButton

        padding: tuple of int
            Alignment padding (top, bottom, left, right)

        type_index: int
            Determine integer or float SpinButton-type.

        precision: int
            number of digits in the float precision
        """
        self.type_index = type_index
        g = self.alignment = gtk.Alignment(0, 0, 1, 0)
        g1 = gtk.SpinButton(
                adjustment=None,
                climb_rate=(2, .02)[type_index],
                digits=(0, precision)[type_index]
            )

        Widget.__init__(self, on_change, key=key, label=label, widget=g1)

        # Tell the SpinButton to respond to click events:
        for i in (
                    gtk.gdk.BUTTON_RELEASE_MASK,
                    gtk.gdk.BUTTON_PRESS_MASK
                ):
            g1.add_events(i)

        g.add(g1)
        g1.set_range(*limit)
        g1.set_increments(*step)
        g1.connect('button_press_event', self.focus_in)
        g1.connect('value_changed', self.callback)
        g1.connect('key_release_event', self.on_key_release)
        if padding:
            g.set_padding(*padding)

    def focus_in(self, *_):
        """
        Improve focus handling.

        Correct an invalid numeric.
        """
        self.wig.grab_focus()
        self.set_value(self.get_value())

    def get_value(self):
        """
        Return the value of the SpinButton.

        Is part of the UI widget template.
        """
        n = self.wig.get_text()
        a = n if n.isdigit() else self.wig.get_value()

        if self.type_index == ForWidget.INT_INDEX:
            a = int(a)
        return a

    def on_key_release(self, _, event):
        """
        Keep arrow and page key events from signaling twice.

        event: key release event
        """
        n = gtk.gdk.keyval_name(event.keyval)

        if n in ('Up', 'Down', 'Page_Up', 'Page_Down', 'Tab'):
            return
        self.callback()

    def set_value(self, value):
        """
        Set the SpinButton display value.

        Is part of the UI widget template.

        value: int or float
        """
        self.wig.set_value(value / 1.)
