#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_constant import (
        ForPreset,
        ForWidget,
        OptionKey,
        PresetKey,
        SessionKey,
        UIKey,
        WindowKey
    )

from roller_base import OZ
from roller_ui import UI
from roller_group_preset import GroupPreset
from roller_session import Session
from roller_preset_sub_session import PresetSubSession
from roller_button import RollerButton
from roller_check_button import RollerCheckButton
from roller_color_button import RollerColorButton
from roller_combobox import RollerComboBox
from roller_eventbox import REventBox
from roller_entry import RollerEntry
from roller_fu import Sel
from roller_label import RollerLabel
from roller_navigation_list import NavigationList
from roller_option_limit import OptionLimitKey
from roller_radio import RRadio
from roller_radio_button import RollerRadioButton
from roller_spin_button import RollerSpinButton
from roller_splitter import Splitter
import gtk


class UIOption(UI):
    """
    Is a dynamic-widget dialog for style and effect options.

    Use an UIOption class template to communicate with the creator class.
    The UIOption template has the following properties:
        prep: function
            Call when the user accepted the options.

        preview: function
            Call when the user wants a preview of the options.

        preview_changed: function
            Call so the creator class can keep or delete a
            previous preview.

        rand: function
            Call so the creator can return a dictionary with
            randomized widget values.

        update_widget: function
            Call to update widget visibility when
            there is inter-widget dependency.
    """

    def __init__(self, a, d, stat):
        """
        Begin options dialog creation.

        a: calling class instance
            part of the UIOption class template

        d: dict
            sub-session dict

        stat: Stat
            global variables
        """
        stat.cancel = 1
        self._session_key = a.name
        self._creator = a
        self.d = d
        self.wigs = [k for k in Session.default[a.name]]
        d = {
                UIKey.ON_RETURN: self.do_job,
                UIKey.WINDOW_KEY: WindowKey.OPTION,
                UIKey.WINDOW_TITLE: a.name + " Options",
                UIKey.STAT: stat
            }

        UI.__init__(self, d)
        Sel.none(stat.render)
        pdb.gimp_displays_flush()
        self._update_widget_visibility()
        gtk.main()

    def _add_box(self, g):
        """
        Create a box that is vertically split and has a colored background.

        g: GTK container
            container for box

        Returns:
            Splitter, REventBox
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        box = REventBox(self.color)
        g1 = Splitter(padding=(w1, w1, w, w), has_inner_padding=True)

        g.add(box)
        box.add(g1.container)
        return g1, box

    def _compliment_key_light(self):
        """Return a complimentary preset dict of the key-light shadow."""
        d = deepcopy(self.stat.session[SessionKey.KEY_LIGHT_SHADOW])
        d[OptionKey.OFFSET_X] *= -1
        d[OptionKey.OFFSET_Y] *= -1
        d[OptionKey.INTENSITY] /= 3
        return d

    def _get_data(self):
        """Return a dict of the current widget values."""
        d = {}

        for g in self.controls:
            d[g.key] = g.get_value()
        return d

    def _draw_categories(self, g):
        """
        Create the widgets.

        g: GTK Vbox
            container for the widgets
        """
        olk = OptionLimitKey
        d = self.stat.option_limit.delimiter
        splitter, _ = self._add_box(g)
        category_list = []
        self.group_box = []

        for n in self.wigs:
            if olk.CATEGORY in d[n]:
                category = d[n][olk.CATEGORY]
                if category not in category_list:
                    category_list.append(category)

        self.group_visibility = [0] * (len(category_list) + 1)
        self.switch_group_box = splitter.right
        vbox_color = self.color

        for n in category_list:
            self.color = vbox_color
            g = gtk.VBox()

            self.group_box.append(g)
            g.add(RollerLabel(
                n + ":",
                padding=(2, 0, 4, 0)).alignment)
            for name in self.wigs:
                if d[name][olk.CATEGORY] == n:
                    splitter1, box1 = self._add_box(g)
                    g1, g2, radio = self._draw_widget(name, splitter1, box1)

                    splitter1.both(g1.alignment, g2.alignment)
                    g2.set_value(self.d[name])

                    if isinstance(g2, RollerRadioButton):
                        g2 = radio

                    self.controls.append(g2)
                    self.keep((g2,))
                    splitter1.pack()
                    self.reduce_color()

        # navigation:
        splitter.left.add(
            RollerLabel("Navigation:", padding=(2, 0, 4, 0)).alignment)

        navigation_list = NavigationList(splitter.left, self)
        navigation_list.set_value(category_list)
        splitter.pack()

    def _draw_preview(self, g):
        """
        Draw a preview.

        Call the creator class to perform the preview operation.

        g: RollerButton
            Disable button while drawing preview.
        """
        self.win.iconify()
        g.disable()

        d = self._get_data()

        self._creator.preview(d)
        g.enable()
        self.win.present()
        pdb.gimp_displays_flush()

    def _draw_widget(self, n, splitter, box):
        """
        Create a widget.

        n: string
            widget label and key

        splitter: Splitter
            container

        box: EventBox
            container

        Return Label, Widget, RRadio.
        """
        ok = OptionKey
        olk = OptionLimitKey
        p = self.on_widget_change
        d = self.stat.option_limit.delimiter
        wig = d[n][olk.WIDGET]
        radio = None

        if wig == RollerCheckButton:
            g2 = RollerLabel("")
            g3 = wig(n, p, key=n)

        else:
            if n == ok.WIDTH:
                g2 = RollerLabel(self._session_key + " Width:")

            else:
                g2 = RollerLabel(n + ":\t\t")

            if wig == RollerColorButton:
                g3 = wig(p, (0, 0, 0), n)

            elif wig == RollerEntry:
                g3 = RollerEntry(p, n)

            elif wig == RollerComboBox:
                if olk.LIST in d[n]:
                    q1 = d[n][olk.LIST]

                else:
                    for k in (
                                olk.FUNCTION,
                                olk.RANGE_FUNCTION
                            ):
                        if k in d[n]:
                            q1 = d[n][k]()
                            break
                g3 = wig(p, key=n, opt=q1)

            elif wig == RollerRadioButton:
                g_ = wig(p, d[n][olk.LABEL][0], n, None)
                g3 = wig(p, d[n][olk.LABEL][1], n, g_.wig)
                radio = RRadio((g_, g3), n)
                splitter.right.add(g_.alignment)

            elif wig == RollerSpinButton:
                if olk.RANGE in d[n]:
                    q1 = d[n][olk.RANGE]

                elif olk.RANGE_SELF in d[n]:
                    q1 = d[n][olk.RANGE_SELF](self._creator)

                elif olk.RANGE_FUNCTION in d[n]:
                    q1 = d[n][olk.RANGE_FUNCTION]()

                if olk.STEP in d[n]:
                    type_index = ForWidget.FLOAT_INDEX
                    step = d[n][olk.STEP]

                else:
                    type_index = ForWidget.INT_INDEX
                    step = 1, 1
                g3 = wig(p, q1, key=n, type_index=type_index, step=step)
        return g2, g3, radio

    def _draw_widgets(self, g, q):
        """
        Create the widgets.

        g: GTK Vbox
            container for the widgets

        q: list
            widget instances for later packing
        """
        for n in self.wigs:
            g1, box = self._add_box(g)
            g2, g3, radio = self._draw_widget(n, g1, box)

            g1.both(g2.alignment, g3.alignment)
            g3.set_value(self.d[n])

            if isinstance(g3, RollerRadioButton):
                g3 = radio

            self.controls.append(g3)
            q.append(g1)
            self.reduce_color()

    def _randomize_widgets(self, _):
        """Randomize the variables."""
        d = self._creator.rand(self._get_data())

        self._creator.preview_changed()
        self.update_controls(d)
        self.preset_is_undefined()
        self._update_widget_visibility()

    def _update_widget_visibility(self, widget=None):
        """
        The end points are not necessary for a shape-burst gradient type.

        Call the template function "update_widgets" if it exists.

        widget: Widget
            If not none, then is the widget that changed.
        """
        if hasattr(self._creator, 'update_widgets'):
            self._creator.update_widgets(widget, self.controls)
            self.win.resize(1, 1)

    def cancel(self, *_):
        """The user canceled the window."""
        self.close()

    def do_job(self, *_):
        """The user accepted the window content."""
        d = self._get_data()

        self._creator.prep(d)
        self.close()
        self.stat.cancel = 0

    def draw_window(self):
        """
        Draw the windows widgets.

        Is part of the UI window template.
        """
        pk = PresetKey
        self.controls = []
        q = []
        internal = None
        g = gtk.VBox()
        k = self._session_key

        if k == SessionKey.FILL_LIGHT_SHADOW:
            n1 = ForPreset.KEY_LIGHT_COMPLIMENT
            self.d = self._compliment_key_light()
            internal = [[n1, self.d]]

        else:
            n1 = ForWidget.LAST_USED if self.stat.session[k] != \
                Session.default[k] else pk.DEFAULT

        if k == SessionKey.COLORED_GRID:
            d = deepcopy(self.d)
            d[OptionKey.ROTATE] = 45
            internal = [[ForPreset.COLORED_DIAMONDS, d]]

        if len(self.wigs) < 15:
            self._draw_widgets(g, q)

        else:
            self._draw_categories(g)

        # preview and randomize:
        g1, _ = self._add_box(g)
        g2 = RollerButton("Preview", self._draw_preview)
        g3 = RollerButton("Randomize", self._randomize_widgets)

        self.keep((g2, g3))
        q.append(g1)
        g1.both(g2.alignment, g3.alignment)
        self.reduce_color()

        # default and presets:
        d = {
                pk.FOLDER: self.stat.preset_folder,
                pk.NAME: k,
                pk.PARENT: self.win
            }

        if internal:
            d[pk.INTERNAL] = internal

        self.preset = PresetSubSession(d, self.stat)
        g1, _ = self._add_box(g)
        g2 = self.preset_menu = GroupPreset(
                None,
                self.on_preset_change,
                k,
                self._get_data,
                self.win,
                self.preset,
                self.stat,
                has_label=True
            )

        q.append(g1)
        g2.box.both(g2.save_b.alignment, g2.del_b.alignment)
        g2.box.pack()
        g1.left.add(g2.label.alignment)
        g1.both(g2.alignment, g2.box.container)
        self.reduce_color()
        g2.set_value(n1)
        g2.verify_del_button()

        # cancel and accept:
        g1, _ = self._add_box(g)
        g2 = RollerButton("Cancel", self.cancel)
        g3 = RollerButton("Accept", self.accept)

        self.keep((g2, g3))
        q.append(g1)
        g1.both(g2.alignment, g3.alignment)
        [g4.pack() for g4 in q]
        self.win.add(g)

    def on_preset_change(self, _, d):
        """
        Loads the preset in the menu.

        d: dict
            sub-session dict
        """
        g = self.preset_menu
        if g.get_text() != ForWidget.UNDEFINED:
            OZ.pass_version(d, Session.default[self._session_key])
            self.update_controls(d)
            self._creator.preview_changed()
            self._update_widget_visibility()

    def on_widget_change(self, g):
        """
        Update the preview state and widget visibility.

        g: Widget
            widget that changed
        """
        if not UI.loading:
            self._creator.preview_changed()
            self.preset_is_undefined()
            self._update_widget_visibility(widget=g)
