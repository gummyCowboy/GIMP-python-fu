#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant import (
        ForWidget,
        SessionKey
    )

from roller_box import RollerBox
from roller_check_button import RollerCheckButton


class GroupLayoutOption:
    """
    Has a UICell window opener Button and a per-cell CheckButton.
    """

    def __init__(
                self,
                on_checkbutton_action,
                session_key,
                container,
                stat
            ):
        """
        on_checkbutton_action: function
            Call on a CheckButton action.

        session_key: string
            sub-session key

        container: object
            Widget or GTK container

        stat: Stat
            global variables, session dict needed
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        self.key = session_key
        self.update_window_for_checkbutton = on_checkbutton_action
        self._container = RollerBox(ForWidget.HBOX, padding=(w, w1, 0, 0))
        vbox_list = RollerBox(ForWidget.VBOX), RollerBox(ForWidget.VBOX)
        items = []
        self.layout_option_dict = {}

        for k in stat.session[SessionKey.LAYOUT_OPTION]:
            items.append(RollerCheckButton(
                    k,
                    on_checkbutton_action,
                    key=k,
                    padding=(0, w1, w, w)
                ))
            self.layout_option_dict[k] = items[-1]

        x = 0

        for i in vbox_list:
            for _ in range(4):
                i.add(items[x].alignment)
                x += 1
            self._container.add(i.alignment)
        container.add(self._container.alignment)

    def get_value(self):
        """
        Return a Session.LAYOUT_OPTION dictionary so
        the settings can saved and restored.
        """
        d = OrderedDict()

        for k in self.layout_option_dict:
            d[k] = self.layout_option_dict[k].get_value()
        return d

    def set_value(self, d):
        """
        Set the value of the CheckButton and is part of a UI widget template.

        Verify the cell window opener button.

        d: dict
            sub-session dict
        """
        [self.layout_option_dict[k].set_value(d[k]) for k in d]
