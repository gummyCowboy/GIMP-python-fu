#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import UIKey
from roller_ui import UI


class UISwitch(UI):
    """
    Switch window focus for dialog interaction.

    The calling window will be hidden
    until the new dialog window closes.
    """

    def __init__(self, d):
        g = d[UIKey.PARENT]

        g.iconify()
        UI.__init__(self, d)
        g.present()
