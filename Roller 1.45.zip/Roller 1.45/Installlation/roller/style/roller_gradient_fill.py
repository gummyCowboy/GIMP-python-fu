#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import (
        ForBackdropStyle,
        ForGradient,
        ForLayer,
        ForRender,
        OptionKey,
        SessionKey
    )

from roller_fu import Lay, Sel
from roller_backdrop_style import BackdropStyle
import gimpfu as fu


class GradientFill(BackdropStyle):
    """
    Fill the backdrop with a gradient.

    A gradient may have semi-transparent pixels.
    """
    name = SessionKey.GRADIENT_FILL

    def __init__(
                self,
                d,
                stat,
                name=SessionKey.GRADIENT_FILL,
                layer_key=ForLayer.BACKDROP,
                sel=None,
                no_save=0,
                no_transparency=0
            ):
        """
        d: dict
            sub-session dict

        stat: Stat
            global variables

        name: string
            effect name

        layer_key: string
            layer that is processed

        sel: selection
            GIMP selection

        no_save: flag
            If it's true, the gradient is drawn as is.

        no_transparency: flag
            If it's true, the gradient is drawn on a grey layer.
        """
        self.point_widget = []
        self.gradient_type_widget = None

        if no_save:
            a = stat.auto
            stat.auto = ForRender.AUTO_NO_SAVE

        self.name = name
        self.sel = sel
        self.no_transparency = no_transparency
        active = None if name == SessionKey.GRADIENT_FILL else \
            Lay.get_active(stat.render)

        BackdropStyle.__init__(
            self, d, stat, layer_key=layer_key, active=active)
        if no_save:
            stat.auto = a

    def do(self, d):
        """
        Fill the active layer with a gradient.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        z = self.do_rotated_layer(self.active.layer, d, self.do_job)

        if self.name == SessionKey.GRADIENT_FILL:
            self.give_render_mask(z)

        z.mode, z.opacity = self.get_grad_mode(d)
        z.name = Lay.get_layer_name(self.name, self.stat)
        self.active.layer = Lay.merge(self.stat.render, z)
        if self.sel:
            Sel.isolate(self.stat.render, self.active.layer, self.sel)

    def do_job(self, j, z, d):
        """
        Draw a gradient.

        j: GIMP image
        z: layer
        d: sub-session dict

        Return the layer.
        """
        ok = OptionKey

        # Shape-burst methods require an opaque layer to work properly:
        if (
                    d[ok.GRADIENT_TYPE] in ForGradient.SHAPE_BURST
                    or self.no_transparency
                ):
            Sel.all(j)
            Sel.fill(z, (127, 127, 127))
            Sel.none(j)

        pdb.gimp_context_set_gradient_blend_color_space(
            fu.GRADIENT_BLEND_RGB_PERCEPTUAL)

        pdb.gimp_context_set_gradient(d[ok.GRADIENT])
        pdb.gimp_context_set_gradient_reverse(d[ok.REVERSE])
        pdb.gimp_drawable_edit_gradient_fill(
                z,
                ForGradient.GRADIENT_TYPE.index(d[ok.GRADIENT_TYPE]),
                d[ok.OFFSET],
                1,
                2,
                0.,
                1,
                d[ok.START_X],
                d[ok.START_Y],
                d[ok.END_X],
                d[ok.END_Y]
            )

        if d[ok.INVERT]:
            Lay.invert(z)
        return z

    def update_widgets(self, widget, controls):
        """
        Update widget visibility.

        Is part of the UIOption class template.

        widget: Widget or None
        controls: iterable
            list of controls in the options window
        """
        ok = OptionKey

        if not self.point_widget:
            for i in controls:
                if i.key in ForBackdropStyle.POINT_KEY:
                    self.point_widget.append(i)

                elif i.key == ok.GRADIENT_TYPE:
                    self.gradient_type_widget = i

        if not widget:
            for i in (self.gradient_type_widget,):
                self.update_widget(i)

        else:
            self.update_widget(widget)

    def update_widget(self, widget):
        """
        Update widgets based various dependencies of a given widget.

        widget: Widget
        """
        if widget.key == OptionKey.GRADIENT_TYPE:
            # Shape-burst gradient types are always centered:
            if widget.get_value() in ForGradient.SHAPE_BURST:
                for i in self.point_widget:
                    self.hide_widget_box(i)

            else:
                for i in self.point_widget:
                    self.show_widget_box(i)
