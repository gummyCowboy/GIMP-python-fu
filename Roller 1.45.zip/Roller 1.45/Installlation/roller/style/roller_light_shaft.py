#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_backdrop_style import BackdropStyle
from roller_constant import OptionKey, SessionKey
from roller_fu import Lay, Sel
from roller_gradient_fill import GradientFill
import gimpfu as fu


class LightShaft(BackdropStyle):
    """Create a dark stoney texture that highlights bump with a gradient."""
    name = SessionKey.LIGHT_SHAFT

    def __init__(self, d, stat):
        """d: sub-session dict"""
        BackdropStyle.__init__(self, d, stat)

    def _do_gradient(self, z, e):
        """
        Draw a gradient on a layer.

        Preserve the alpha.

        z: layer
            The layer that receives the gradient.

        e: dict
            GRADIENT sub-session
        """
        Lay.clone(self.stat.render, z)
        GradientFill(
                e,
                self.stat,
                name=self.name,
                layer_key=self.name,
                no_save=1
            )

        z1 = Lay.get_active(self.stat.render)

        Lay.give_mask(z1, z)
        return Lay.merge(self.stat.render, z1)

    def do(self, d):
        """
        Create the backdrop style.

        Is part of a RenderHub class template.
        Make organic texture and color.
        Use a gradient to mimic light entering a tunnel or shaft.

        d: dict
            sub-session dict
        """
        ok = OptionKey
        j = self.stat.render
        group = Lay.group(j, self.name)
        z = Lay.clone(j, self.active.layer)

        Lay.order(j, z, group)
        Sel.all(j)

        for i in range(10):
            pdb.plug_in_mosaic(
                    j,
                    z,
                    (i + 1) * d[ok.SCALE],
                    1,
                    .1,
                    .5,
                    0,
                    0,
                    .0,
                    1,
                    1,
                    0,
                    0,
                    0
                )

            z = Lay.clone(j, z)
            z.mode = fu.LAYER_MODE_DIFFERENCE

        z = Lay.eat(j, group)
        group = Lay.group(j, self.name)
        z1 = Lay.clone(j, z)
        z1.mode = fu.LAYER_MODE_EXCLUSION

        Lay.order(j, z1, group)

        pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
        pdb.plug_in_emboss(j, z1, 135, 30., 1, 1)

        z1 = Lay.clone(j, z1)
        z1.mode = fu.LAYER_MODE_GRAIN_MERGE
        z1 = Lay.clone(j, z1)
        z1.mode = fu.LAYER_MODE_GRAIN_EXTRACT
        e = deepcopy(self.stat.session[SessionKey.GRADIENT_FILL])
        e[ok.GRADIENT] = "Default"
        e[ok.GRADIENT_TYPE] = "Bilinear"
        e[ok.MODE] = "Normal"
        e[ok.OPACITY] = 50.
        e[ok.INVERT] = 1
        e[ok.REVERSE] = 1
        e[ok.START_X] = int(self.stat.width / 2)
        e[ok.START_Y] = int(self.stat.height / 2)
        e[ok.OFFSET] = e[ok.END_X] = e[ok.END_Y] = 0
        e[ok.ROTATE] = d[ok.ROTATE]

        self._do_gradient(z, e)

        z = Lay.get_active(j)

        Lay.order(j, z, group, a=len(group.layers))

        z2 = Lay.clone(j, z)

        Lay.order(j, z2, group, a=0)
        Lay.invert(z2)

        z2.mode = fu.LAYER_MODE_LINEAR_BURN
        z = Lay.eat(j, group)
        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_COLOR_ERASE
        z.opacity = 50.

        pdb.plug_in_erode(j, z, 1, 7, 1, 0, 0, 255)
        Lay.invert(z)

        z = Lay.merge(j, z)
        self.finish_style(z)
