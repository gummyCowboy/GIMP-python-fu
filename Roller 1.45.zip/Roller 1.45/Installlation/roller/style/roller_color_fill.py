#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import OptionKey, SessionKey
from roller_backdrop_style import BackdropStyle
import gimpfu as fu


class ColorFill(BackdropStyle):
    """Fill the backdrop with a color."""
    name = SessionKey.COLOR_FILL

    def __init__(self, d, stat):
        """d: sub-session dict"""
        BackdropStyle.__init__(self, d, stat)

    def do(self, d):
        """
        Fill the active layer with a color.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        ok = OptionKey
        q = d[ok.COLOR_1]
        a = BackdropStyle.invert_color(q) if d[ok.INVERT] else q
        z = self.active.layer

        self.set_fill_context(d)
        pdb.gimp_context_set_foreground(a)

        pdb.gimp_drawable_edit_bucket_fill(
                z,
                fu.FOREGROUND_FILL,
                d[ok.START_X], d[ok.START_Y]
            )
        self.give_render_mask(z)
