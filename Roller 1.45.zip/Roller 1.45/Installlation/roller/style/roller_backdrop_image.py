#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForFormat, ForWidget, OptionKey, SessionKey
from roller_fu import Lay, Sel
from roller_layout import RollerImage
from roller_backdrop_style import BackdropStyle
import gimpfu as fu


class BackdropImage(BackdropStyle):
    """Backdrop image"""
    name = SessionKey.BACKDROP_IMAGE

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        q = RollerImage.image_list[:]
        sk = SessionKey
        self.blur_widget = self.fit_image_widget = None
        self.backdrop_image_widget = None

        if d[sk.BACKDROP_IMAGE] not in q:
            n = ForWidget.FIRST
            d[sk.BACKDROP_IMAGE] = n if n in q else ForFormat.NONE
        BackdropStyle.__init__(self, d, stat)

    def do(self, d):
        """
        Places an existing image as a backdrop.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        ok = OptionKey
        j, z = self.stat.render, self.active.layer

        if d[SessionKey.BACKDROP_IMAGE] == ForFormat.NONE:
            # Fill with white:
            Lay.color_fill(z, (255,) * 3)

        else:
            # Copy the backdrop image to the backdrop layer:
            j1 = RollerImage.get_image(d[SessionKey.BACKDROP_IMAGE])
            j2 = j1.j

            Sel.none(j2)
            Lay.kopy(j2)

            if j1.size != self.stat.size:
                if d[ok.FIT_IMAGE]:
                    # Resize backdrop image to fit backdrop layer:
                    j1 = RollerImage.paste()
                    RollerImage.shape(j1, self.stat.width, self.stat.height)

            z1 = self.active.layer = Lay.paste(j, z)

            if not d[ok.FIT_IMAGE]:
                Lay.clip(z1)

            z = self.active.layer = Lay.merge(j, z1)
            if d[ok.BACKDROP_BLUR]:
                Lay.blur(j, z, d[ok.BACKDROP_BLUR])

        if d[ok.INVERT]:
            Lay.invert(z)

        if z.mask:
            z.remove_mask(fu.MASK_DISCARD)
        Lay.masked(z)

    def update_widgets(self, widget, controls):
        """
        Update widget visibility.

        Is part of the UIOption class template.

        widget: Widget or None
        controls: iterable
            list of controls in the options window
        """
        ok = OptionKey

        if not self.blur_widget:
            for i in controls:
                if i.key == ok.BACKDROP_BLUR:
                    self.blur_widget = i

                elif i.key == ok.FIT_IMAGE:
                    self.fit_image_widget = i

                elif i.key == ok.BACKDROP_IMAGE:
                    self.backdrop_image_widget = i

        if not widget:
            for i in (self.backdrop_image_widget,):
                self.update_widget(i)

        else:
            self.update_widget(widget)

    def update_widget(self, widget):
        """
        Update widgets based various dependencies of a given widget.

        widget: Widget
        """
        if widget.key == OptionKey.BACKDROP_IMAGE:
            if widget.get_value() == ForFormat.NONE:
                self.hide_widget_box(self.blur_widget)
                self.hide_widget_box(self.fit_image_widget)

            else:
                self.show_widget_box(self.blur_widget)
                self.show_widget_box(self.fit_image_widget)
