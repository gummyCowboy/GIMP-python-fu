#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
import gtk


class ForColor:
    """Has values used by color processing."""
    MAX_COLOR = 65535
    BACKGROUND_BUTTON_COLOR = gtk.gdk.Color(52000, 52000, MAX_COLOR)
    NORMAL_BUTTON_COLOR = gtk.gdk.Color(54000, 54000, MAX_COLOR)
    SINGLE_CELL_COLOR = gtk.gdk.Color(56000, 56000, MAX_COLOR)


class ForFill:
    """
    Has values used by a fill process.

    Color Fill and Pattern Fill use criteria.
    """
    CRITERIA_LIST = (
            "Composite",
            "Red",
            "Green",
            "Blue",
            "Hue",
            "Saturation",
            "Value",
            "Alpha",
            "LCH-Lightness",
            "LCH-Chroma",
            "LCH Hue"
        )


class ForPreset:
    """Has values used by a preset."""
    COLORED_DIAMONDS = "Colored Diamonds"
    KEY_LIGHT_COMPLIMENT = "Key-light Compliment"
    PRESET_SEPARATOR = "﹎"

    # indices:
    # external or internal source index:
    SOURCE_INDEX = 0

    # name of the preset index:
    NAME_INDEX = 1

    # external data: file name index:
    FILE_INDEX = 2

    # internal preset data index:
    DATA_INDEX = 2

    # internal or external type id:
    INTERNAL_TYPE = 0
    EXTERNAL_TYPE = 1


class ForWidget:
    """Has values used by widgets."""
    FIRST = "1st Image"
    LAST_USED = "Last Used"
    LIST_SEPARATOR = "★"
    MARGIN = 13
    SCROLL_SPAN = 22
    UNDEFINED = "〰 undefined 〰"
    VBOX, HBOX, VBUTTON_BOX = 0, 1, 2
    INT_INDEX, FLOAT_INDEX = 0, 1


class LayerKey:
    """Has keys used to identify layers."""
    BLUR_BEHIND = "Blur Behind"
    BLURRED_BACKGROUND = "Blurred Background"
    BACKDROP_LIGHT = "Backdrop Light"
    CORE_DESIGN = "Core Design"
    FORMAT = "Format"
    IMAGE = "Image"


class OptionKey:
    """Has keys that are displayed in UIOption."""
    AMPLITUDE = "Amplitude"
    ANGLE = "Angle"
    BACKDROP_BLUR = "Backdrop Image Blur"
    BACKDROP_IMAGE = "Backdrop Image"
    BLEND = "Blend"
    BLUR = "Blur"
    BORDER_WIDTH = "Border Width"
    BORDER_TYPE = "Border Type"
    CELL_GAP = "Cell Gap"
    CIRCLE_DIAMETER = "Circle Diameter"
    COLOR_1 = "Color #1"
    COLOR_2 = "Color #2"
    COLUMN = "Column"
    COLUMN_1 = "Column #1"
    COLUMN_2 = "Column #2"
    COMPONENT = "Color Component"
    COMPOSITION_BORDER_WIDTH = "Composition Border Width"
    CRITERIA = "Criteria"
    DIRECTION = "Rotation Direction"
    EMBOSS = "Emboss"
    END_X = "End X"
    END_Y = "End Y"
    FIT_IMAGE = "Fit image to render"
    GAP_TYPE = "Gap Type"
    GAP_WIDTH = "Gap Width"
    GRADIENT = "Gradient"
    GRADIENT_TYPE = "Gradient Type"
    INHERIT_OPACITY = "Inherit Opacity"
    INLAY_BLUR = "Inlay Shadow Blur"
    INTENSITY = "Intensity"
    INVERT = "Invert"
    KEEP_GRADIENT = "Keep the Gradient"
    LIGHT_ANGLE = "Light Angle"
    LINE_WIDTH = "Line Width"
    MAZE_TYPE = "Maze Type"
    MESH_SIZE = "Mesh Size"
    MESH_TYPE = "Mesh Type"
    MODE = "Paint Mode"
    NAME = "Name"
    NEATNESS = "Neatness"
    OFFSET = "Offset"
    OFFSET_X = "Offset X"
    OFFSET_Y = "Offset Y"
    PANE_HEIGHT = "Pane Height"
    PANE_WIDTH = "Pane Width"
    PATTERN = "Pattern"
    RANDOM_SEED = "Random Seed"
    OPACITY = "Opacity"
    POWER = "Noise Power"
    REVERSE = "Reverse"
    ROTATE = "Rotate"
    ROUND_UP = "Round Up"
    ROUNDED_EDGE_BLUR = "Rounded Edge Blur"
    ROW = "Row"
    SAMPLE_POINTS = "Sample Points"
    SAMPLE_RADIUS = "Sample Radius"
    SAMPLE_VECTOR = "Sample Vector"
    SCALE = "Scale"
    SCATTER_COUNT = "Scatter Count"
    SHADOW = "Shadow"
    SHADOW_BLUR = "Shadow Blur"
    SHADOW_COLOR = "Shadow Color"
    SMOOTHNESS = "Smoothness"
    START_X = "Start X"
    START_Y = "Start Y"
    STOP_LENGTH = "Stop Length"
    TEXTURE = "Texture"
    THRESHOLD = "Threshold"
    WAVE_AMPLITUDE = "Wave Amplitude"
    WAVELENGTH = "Wavelength"
    WHIRL = "Whirl"
    WIDTH = "Width"
    WIRE_THICKNESS = "Wire Thickness"


class PresetKey:
    """Has keys used to initialize a Preset."""
    DEFAULT = "Default"
    FOLDER = 'folder'
    GET_DATA = 'get_data'
    INTERNAL = 'internal'
    NAME = "Name"
    PARENT = 'parent'
    PRESET = 'preset'


class FormatKey:
    """Has keys used by the Format dictionary."""
    BLUR_BEHIND = "Blur Behind"
    CELL_MARGIN_BOTTOM_FIXED = 'cell_margin_bottom_fixed'
    CELL_MARGIN_LEFT_FIXED = 'cell_margin_left_fixed'
    CELL_MARGIN_RIGHT_FIXED = 'cell_margin_right_fixed'
    CELL_MARGIN_TOP_FIXED = 'cell_margin_top_fixed'
    CELL_MARGIN_BOTTOM_PERCENT = 'cell_margin_bottom_percent'
    CELL_MARGIN_LEFT_PERCENT = 'cell_margin_left_percent'
    CELL_MARGIN_RIGHT_PERCENT = 'cell_margin_right_percent'
    CELL_MARGIN_TOP_PERCENT = 'cell_margin_top_percent'
    CELL_TABLE_FIXED_MARGIN = 'cell_table_fixed_margin'
    CELL_TABLE_PERCENT_MARGIN = 'cell_table_percent_margin'
    CELL_TABLE_MERGE = 'cell_table_merge'
    CELL_TABLE_PLACEMENT = 'cell_table_placement'
    CELL_TABLE_PROPERTY = 'cell_table_property'
    COLUMN = "Column"
    EFFECT = 'effect'
    FLIP_HORIZONTAL = 'flip_horizontal'
    FLIP_VERTICAL = 'flip_vertical'
    HORIZONTAL = 'horizontal'
    IMAGE = 'image'
    LAYER_MARGIN_BOTTOM_FIXED = 'layer_margin_bottom_fixed'
    LAYER_MARGIN_LEFT_FIXED = 'layer_margin_left_fixed'
    LAYER_MARGIN_RIGHT_FIXED = 'layer_margin_right_fixed'
    LAYER_MARGIN_TOP_FIXED = 'layer_margin_top_fixed'
    LAYER_MARGIN_BOTTOM_PERCENT = 'layer_margin_bottom_percent'
    LAYER_MARGIN_LEFT_PERCENT = 'layer_margin_left_percent'
    LAYER_MARGIN_RIGHT_PERCENT = 'layer_margin_right_percent'
    LAYER_MARGIN_TOP_PERCENT = 'layer_margin_top_percent'
    MERGE_PER_CELL = 'merge_per_cell'
    FIXED_MARGIN_PER_CELL = 'margin_per_cell'
    PERCENT_MARGIN_PER_CELL = 'percent_margin_per_cell'
    NAME = "Name"
    OPACITY = "Opacity"
    PLACEMENT_PER_CELL = 'placement_per_cell'
    PRESET = PresetKey.PRESET
    PROPERTY_PER_CELL = 'property_per_cell'
    RESIZE = 'resize'
    ROTATE = "Rotate"
    ROW = "Row"
    SHOW_IN_LAYOUT = "Show in the Layout Preview"
    VERTICAL = 'vertical'


class PickleKey:
    """Has keys that Pickle operations use."""
    DATA = 'data'
    FILE = 'file'
    SHOW_ERROR = 'show_error'


class SessionKey:
    """
    Has keys used by the Session dictionary.

    Most are formatted to as a user-presentable self-descriptor.
    """
    AUTOMATE = "Automate"
    AVERAGE_COLOR = "Average Color"
    BACKDROP_IMAGE = "Backdrop Image"
    BACKDROP_STYLE = 'backdrop_style'
    BORDER_GRADIENT = "Border Gradient"
    BORDER_LINE = "Border Line"
    CERAMIC_CHIP = "Ceramic Chip"
    CIRCLE_PUNCH = "Circle Punch"
    CLEAR_FRAME = "Clear Frame"
    COLOR_FILL = "Color Fill"
    COLORED_BOARD = "Colored Board"
    COLORED_GRID = "Colored Grid"
    COLUMN = "Column"
    CORE_DESIGN = "Core Design"
    DROP_SHADOW = "Drop Shadow"
    LIGHT_SHAFT = "Light Shaft"
    FILL_LIGHT_SHADOW = "Fill Light Shadow"
    FLOOR_SAMPLE = "Floor Sample"
    FORMAT_LIST = "format_list"
    GLASS_GAW = "Glass Gaw"
    GRADIENT_BEVEL = "Gradient Bevel"
    GRADIENT_FILL = "Gradient Fill"
    HEIGHT = 'height'
    HONEY_BEE = "Honey Bee"
    IMAGE_EDGE_SHADOW = "Image Edge Shadow"
    IMAGE_GRADIENT = "Image Gradient"
    INLAY_SHADOW = "Inlay Shadow"
    JAGGED_EDGE = "Jagged Edge"
    KEY_LIGHT_SHADOW = "Key Light Shadow"
    LAYOUT_OPTION = "layout_option"
    LINE_FASHION = "Line Fashion"
    LOST_MAZE = "Lost Maze"
    MAZE_MIRROR = "Maze Mirror"
    MYSTERY_GRATE = "Mystery Grate"
    OPACITY = "Opacity"
    PATTERN_FILL = "Pattern Fill"
    RAD_WAVE = "Rad Wave"
    RAINBOW_VALLEY = "Rainbow Valley"
    PRESET = PresetKey.PRESET
    ROCKY_LANDING = "Rocky Landing"
    ROTATE = "Rotate"
    ROUNDED_EDGE = "Rounded Edge"
    ROW = "Row"
    SPACETIME_FABRIC = "Spacetime Fabric"
    SQUARE_PUNCH = "Square Punch"
    STAINED_GLASS = "Stained Glass"
    WIDTH = 'width'
    WIRE_FENCE = "Wire Fence"


class UICellKey:
    """Has keys used to initialize UICell."""
    CELL_TABLE_KEY = 'cell_table_key'
    MERGE_PER_CELL = 'merge_per_cell'


class UIFormatKey:
    """Has keys used to initialize UIFormat."""
    FORMAT_INDEX = 'format_index'


class UIKey:
    """Has keys used to initialize a window."""
    ON_RETURN = 'on_return'
    FORMAT_DICT = 'format_dict'
    FORMAT_INDEX = 'format_index'
    LAYOUT = 'layout'
    PARENT = 'parent'
    STAT = 'stat'
    WINDOW_KEY = 'window_key'
    WINDOW_TITLE = 'window_title'


class WidgetKey:
    """Has keys used to initialize widgets."""
    KEY = 'key'
    LABEL = 'label'
    NAME = "Name"
    OPT = 'opt'
    PADDING = 'padding'
    WIDGET = 'widget'


class WindowKey:
    """
    Has keys used in the window position dictionary.

    Each key refers to a window type.
    """
    FORMAT = 'format'
    MAIN = 'main'
    OPTION = 'uid'
    SAVE = 'save'


class ForBackdropStyle:
    """Has values used by backdrop styles."""
    CLOCKWISE = "Clockwise"
    COUNTER_CLOCKWISE = "Counter-Clockwise"
    RANDOM = "Random"
    COMPONENT = "Red", "Green", "Blue"
    DIRECTION = CLOCKWISE, COUNTER_CLOCKWISE
    GAP_TYPE = RANDOM, "Evenly Distributed"
    BORDER = "Border"
    FILLED = "Filled"
    SCATTERED_CONNECTORS = "Scattered Connectors"
    SCATTERED_MAZES = "Scattered Mazes"
    MAZE_TYPE = (
            SCATTERED_CONNECTORS,
            SCATTERED_MAZES,
            BORDER,
            FILLED
        )

    MESH_TYPE = "Square", "Hexagon", "Octagon", "Triangle"
    POINT_KEY = (
            OptionKey.START_X,
            OptionKey.START_Y,
            OptionKey.END_X,
            OptionKey.END_Y
        )
    TRANSPARENCY = "Transparency"


class ForLayer:
    """Has values used by GIMP layers."""

    # UNICODE_KEY corresponds with LAYER_NAME_KEY on a 1:1 basis:
    UNICODE_KEY = (
            "★", "☉", "❀", "❑", "✙", "❖", "✦",
            "⚪", "⚫", "￭", "✪", "¤", "☺", "☻",
            "☀"
        )

    ANY_U = "• "
    BACKDROP = "Backdrop"
    FORMAT = "Format"

    # Opaque is on:
    INHERIT_DICT = {OptionKey.INHERIT_OPACITY: 1}

    # SessionKeys are dual-purposed by serving
    # the session dict and layer name-keys.
    # Where there is no session key, then a layer key is used.
    LAYER_NAME_KEY = (
            LayerKey.IMAGE,
            SessionKey.COLORED_BOARD,
            SessionKey.CLEAR_FRAME,
            SessionKey.DROP_SHADOW,
            SessionKey.IMAGE_EDGE_SHADOW,
            LayerKey.BLURRED_BACKGROUND,
            SessionKey.BORDER_LINE,
            SessionKey.KEY_LIGHT_SHADOW,
            SessionKey.FILL_LIGHT_SHADOW,
            SessionKey.STAINED_GLASS,
            SessionKey.INLAY_SHADOW,
            LayerKey.BLUR_BEHIND,
            LayerKey.BACKDROP_LIGHT,
            SessionKey.GRADIENT_BEVEL,
            SessionKey.CERAMIC_CHIP
        )
    LAYER_DICT = dict(zip(LAYER_NAME_KEY, UNICODE_KEY))


class ForCell:
    """Has values used by cells."""
    CELL_TABLE_DICT = {
            FormatKey.CELL_TABLE_MERGE: {
                    'name': "Merge Cells",
                    'index': 0,
                    'length': 2,
                    'window_key': 'cell_merge'
                },

            FormatKey.CELL_TABLE_PLACEMENT: {
                    'name': "Image Placement",
                    'index': 1,
                    'length': 4,
                    'window_key': 'cell_place'
                },

            FormatKey.CELL_TABLE_FIXED_MARGIN: {
                    'name': "Fixed-Value Cell Margin",
                    'index': 2,
                    'length': 4,
                    'window_key': 'cell_margin'
                },

            FormatKey.CELL_TABLE_PERCENT_MARGIN: {
                    'name': "Percentage-of-Cell Cell Margin",
                    'index': 3,
                    'length': 4,
                    'window_key': 'percent_cell_margin'
                },

            FormatKey.CELL_TABLE_PROPERTY: {
                    'name': "Image Property",
                    'index': 4,
                    'length': 5,
                    'window_key': 'cell_prop'
                },
        }
    MIN_CELL_SPAN = 4


class ForEffect:
    """Has values used by a 3D effect."""
    SHADOW_EFFECT = (
            SessionKey.DROP_SHADOW,
            SessionKey.IMAGE_EDGE_SHADOW,
            SessionKey.FILL_LIGHT_SHADOW,
            SessionKey.INLAY_SHADOW,
            SessionKey.KEY_LIGHT_SHADOW
        )
    SHADOW_CHOICE = (
            SessionKey.DROP_SHADOW,
            SessionKey.INLAY_SHADOW,
            SessionKey.KEY_LIGHT_SHADOW
        )


class ForFormat:
    """Has values used by format."""
    BOTTOM = "Bottom"
    CENTER = "Center"
    FILL_CELL = "Fill Cell"
    LEFT = "Left"
    LOCKED = "Locked"
    MIDDLE = "Middle"
    NEXT = "Next"
    NONE = "None"
    RIGHT = "Right"
    TOP = "Top"
    TRIM = "Trim"
    HORIZONTAL_OPTION = [LEFT, CENTER, RIGHT]
    RESIZE_OPTION = [FILL_CELL, LOCKED, NONE, TRIM]
    VERTICAL_OPTION_LIST = [TOP, MIDDLE, BOTTOM]
    CELL_MARGIN_FIXED_SPIN_BUTTON_KEY = (
            FormatKey.CELL_MARGIN_TOP_FIXED,
            FormatKey.CELL_MARGIN_BOTTOM_FIXED,
            FormatKey.CELL_MARGIN_LEFT_FIXED,
            FormatKey.CELL_MARGIN_RIGHT_FIXED
        )

    CELL_MARGIN_PERCENT_SPIN_BUTTON_KEY = (
            FormatKey.CELL_MARGIN_TOP_PERCENT,
            FormatKey.CELL_MARGIN_BOTTOM_PERCENT,
            FormatKey.CELL_MARGIN_LEFT_PERCENT,
            FormatKey.CELL_MARGIN_RIGHT_PERCENT
        )

    LAYER_MARGIN_FIXED_SPIN_BUTTON_KEY = (
            FormatKey.LAYER_MARGIN_TOP_FIXED,
            FormatKey.LAYER_MARGIN_BOTTOM_FIXED,
            FormatKey.LAYER_MARGIN_LEFT_FIXED,
            FormatKey.LAYER_MARGIN_RIGHT_FIXED
        )

    LAYER_MARGIN_PERCENT_SPIN_BUTTON_KEY = (
            FormatKey.LAYER_MARGIN_TOP_PERCENT,
            FormatKey.LAYER_MARGIN_BOTTOM_PERCENT,
            FormatKey.LAYER_MARGIN_LEFT_PERCENT,
            FormatKey.LAYER_MARGIN_RIGHT_PERCENT
        )

    TOP_INDEX, BOTTOM_INDEX, LEFT_INDEX, RIGHT_INDEX = range(4)
    RESIZE_INDEX, IMAGE_INDEX, HORIZONTAL_INDEX, VERTICAL_INDEX = range(4)
    FLIP_HORIZONTAL_INDEX, FLIP_VERTICAL_INDEX, ROTATE_INDEX, OPACITY_INDEX, \
        BLUR_BEHIND_INDEX = range(5)


class ForGradient:
    """Has values used by gradients."""
    GRADIENT_TYPE = (
            "Linear",
            "Bilinear",
            "Radial",
            "Square",
            "Conical Symmetric",
            "Conical ASymmetric",
            "Shape-burst-Angular",
            "Shape-burst-Spherical",
            "Shape-burst-Dimpled",
            "Spiral-Clockwise",
            "Spiral-Counter-Clockwise"
        )

    LINEAR_DICT = OrderedDict([
            (OptionKey.GRADIENT_TYPE, "Linear"),
            (OptionKey.INVERT, 0),
            (OptionKey.MODE, "Normal"),
            (OptionKey.OFFSET, 0),
            (OptionKey.OPACITY, 100),
            (OptionKey.REVERSE, 0),
            (OptionKey.ROTATE, 0)
        ])

    SHAPE_BURST = (
            "Shape-burst-Angular",
            "Shape-burst-Spherical",
            "Shape-burst-Dimpled"
        )
    VECTOR = (
            "Mid-Vertical",
            "Mid-Horizontal",
            "Top-Left to Bottom-Right",
            "Bottom-Left to Top-Right"
        )


class ForRender:
    """Has values used by the rendering process."""
    MANUAL = 0
    AUTO_LAST_USED = 1
    AUTO_RANDOM = 2
    AUTO_NO_SAVE = 3
    AUTO = AUTO_LAST_USED, AUTO_RANDOM, AUTO_NO_SAVE


class LayoutKey:
    """Has keys used by 'session.LAYOUT_OPTION'."""
    CELL_MARGINS = "Cell Margins"
    COORDINATES = "Coordinates"
    CORNERS = "Corners"
    DIMENSIONS = "Dimensions"
    LAYER_MARGINS = "Layer Margins"
    GRID = "Grid"
    NAME = "Name"
    RATIOS = "Ratios"
