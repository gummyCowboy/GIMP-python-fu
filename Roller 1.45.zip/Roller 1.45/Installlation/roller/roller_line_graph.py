#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_fu import Sel
from roller_grid import Grid


class LineGraph:
    """ Creates randomized connections for Maze Mirror. """
    # Connection vector types:
    disconnected = 0
    real = 1
    virtual = 2     # Graph boundaries are 'virtual' connections.

    # (x, y) ordered vector directions:
    directions = [(-1, 0), (0, -1), (1, 0), (0, 1)]

    # direction indices:
    left, down, up, right = range(4)

    # opposing vector connections:
    connector = [right, up, down, left]

    def __init__(self, row, col, stat, line_width, m=0):
        """
        row: row count
        col: column count
        stat: Stat
            global variables

        line_width: int
            width of the line to draw

        m: flag
            When it is true, rows and columns are unchanged.
        """
        self.stat = stat
        self.line_width = line_width

        if m:
            # Adds one to the row and columns
            # because the far edges are connectors too:
            self.row, self.col = row + 1, col + 1

        else:
            self.row = ((row + 1) / 2) + 1
            self.col = ((col + 1) / 2) + 1

        r, c = self.row, self.col
        self.grid = Grid(stat.size, row, col)

        if self.row > 1 and self.col > 1:
            # Initialize point matrix to disconnected:
            self.graph = [0] * r

            for i in range(r):
                self.graph[i] = [0] * c
                for j in range(c):
                    self.graph[i][j] = [0] * 4

        # "a" is connection type for edges.
        # "b" is the connection type for out of bounds:
        if m:
            a = self.real

        else:
            a = self.virtual

        b = self.virtual
        a1 = self.graph

        # Set initial vectors for graph boundaries:
        for i in range(r):
            for j in range(c):
                # Set the top and bottom edges:
                if i == 0 or i == r - 1:
                    a1[i][j][self.right] = a
                    a1[i][j][self.left] = a

                # Set the left and right edges:
                if j == 0 or j == c - 1:
                    a1[i][j][self.down] = a
                    a1[i][j][self.up] = a

        # The graph boundaries are connected by virtual connections:
        for i in range(r):
            for j in range(c):
                # Set the out-of-bounds:
                if i == 0:
                    a1[i][j][self.up] = b

                elif i == r - 1:
                    a1[i][j][self.down] = b

                if j == 0:
                    a1[i][j][self.left] = b

                elif j == c - 1:
                    a1[i][j][self.right] = b

    def _get_direction(self, u, v):
        """
        Returns direction vectors from points "u" and "v".

        u: (row, column)
        v: (row, column)
        """
        if u[0] > v[0]:
            return self.up, self.down

        elif u[0] < v[0]:
            return self.down, self.up

        elif u[1] > v[1]:
            return self.left, self.right
        return self.right, self.left

    def add_line(self, u, v, a):
        """
        Depicts a line in the graph to connect "u" to "v".

        Points are a top-left cell point.

        u: tuple (row, column)
        v: tuple (row, column)
        a: line type
        """
        b = self.graph
        a1, a2 = self._get_direction(u, v)
        b[u[0]][u[1]][a1] = b[v[0]][v[1]][a2] = a
        return a1

    def add_line_to_disconnects(self):
        """
        Repeatedly scans through the "self.graph"
        table for disconnected points.

        When all disconnected points are connected, the scan stops.

        Connections end at the graph boundaries or with self-contained loops.

        A line segment has end points. Each point has up to four directions
        that lines can connect. There are two connection vector types.
        Once a line segment has two of connections that are
        real and/or virtual, then the point is connected.
        """
        graph = self.graph
        dis = self.disconnected
        m = 1
        while m:
            m1 = 1
            for i in range(self.row):
                for j in range(self.col):
                    connect_cnt = is_real = 0
                    for k in range(4):
                        a = graph[i][j][k]
                        if a in (self.real, self.virtual):
                            connect_cnt += 1
                            if a == self.real:
                                is_real = 1

                    # If the connect count is less than 2, and
                    # one vector is real, the point is disconnected:
                    if connect_cnt < 2 and is_real:
                        u = i, j

                        # Randomly select a disconnect vector:
                        while 1:
                            typ = randint(0, 3)
                            if graph[i][j][typ] == dis:
                                break

                        # Adds a line from this point:
                        b = self.connector[typ]

                        if typ == self.left:
                            v = i, j - 1

                        elif typ == self.right:
                            v = i, j + 1

                        elif typ == self.up:
                            v = i - 1, j

                        else:
                            v = i + 1, j

                        graph[u[0]][u[1]][typ] = \
                            graph[v[0]][v[1]][b] = self.real
                        m1 = 0
            m = not m1

    def do_line(self, u, v, a):
        """
        Adds a line to the graph.

        Draws a line on the screen.

        u: (row, column)
        v: (row, column)
        a: line type
        """
        b = self.add_line(u, v, a)
        if a == self.real:
            x, y, w, h = self.grid.cell(u[0], u[1])
            w *= (1, 0, 0, 1)[b]
            h *= (0, 1, 1, 0)[b]
            Sel.rect(self.stat.render, x, y, w, h)

    def draw_lines(self):
        """ Draws lines depicted as "self.real" in the "self.graph". """
        r, c = self.row, self.col
        a = self.graph
        for i in range(r):
            for j in range(c):
                # Draw only right and down vectors:
                if a[i][j][self.right] == self.real:
                    x, y, w, _ = self.grid.cell(i, j)
                    h = self.line_width
                    w += self.line_width
                    Sel.rect(self.stat.render, x, y, w, h)
                if a[i][j][self.down] == self.real:
                    x, y, _, h = self.grid.cell(i, j)
                    w = self.line_width
                    Sel.rect(self.stat.render, x, y, w, h)

    def get_connected_points(self, u):
        """
        Returns a list of points connected to point "u".

        u: (row, column)
        """
        a = []

        for x in range(4):
            if self.graph[u[0]][u[1]][x] == self.real:
                # left, down, up, right
                a += [(u[0] + (0, 1, -1, 0)[x], u[1] + (-1, 0, 0, 1)[x])]
        return a

    def get_line(self, u, v):
        """
        Returns the line state between points "u" and "v".

        u: (row, column)
        v: (row, column)
        """
        a, _ = self._get_direction(u, v)
        return self.graph[u[0]][u[1]][a]
