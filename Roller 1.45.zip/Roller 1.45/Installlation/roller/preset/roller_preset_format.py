#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant import ForPreset, PresetKey
from roller_preset import Preset
from roller_session import Format


class PresetFormat(Preset):
    """
    This is the Preset used in the Format window.

    Store values from the UIFormat window and from its Per Cell windows.
    """

    def __init__(self, d):
        """
        d: preset dict

        Customize the preset dictionary.

        Call Preset to complete.
        """
        q = d[PresetKey.DEFAULT] = [
                ForPreset.INTERNAL_TYPE,
                PresetKey.DEFAULT,
                deepcopy(Format.default)
            ]

        d[PresetKey.INTERNAL] = [q]
        d[PresetKey.NAME] = "Format"
        Preset.__init__(self, d)
