#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_image_effect import ImageEffect, LayerKey
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb
BOTTOM_LAYER = (
    LayerKey.BLURRED_BACKGROUND,
    LayerKey.CELL_FRINGE,
    LayerKey.CELL_PLAQUE,
    LayerKey.LAYER_FRINGE,
    LayerKey.LAYER_PLAQUE
)
CAPTION_LAYER = LayerKey.CELL_CAPTION, LayerKey.LAYER_CAPTION


class Shadow:
    """
    Creates a shadow layer.

    Use with shadow effects.
    """

    def __init__(self, one):
        """
        Make a shadow.

        one: One
            Has variables.

            e: keyword args
                caster_key: iterable
                    layer key(s) of layers that cast a shadow

                is_inlay: flag
                    Set to true to make the shadow an inlay-type.
        """
        # Use a selection so the shadow doesn't appear below the image:
        stat = one.stat
        e = one.e
        d = deepcopy(one.d)
        parent = one.parent
        j = stat.render.image
        caster_key = e['caster_key'] if 'caster_key' in e else []
        if caster_key:
            is_inlay = e['is_inlay'] if 'is_inlay' in e else False
            group, caster_layer = RenderHub.create_shadow_unit(
                stat,
                parent,
                caster_key
            )
            name = Lay.get_layer_name(one.k, parent=parent)

            if is_inlay:
                # inlay-type shadow:
                d[ok.OFFSET_X] = d[ok.OFFSET_Y] = 0
                blur = d[ok.INLAY_BLUR]

            else:
                blur = d[ok.SHADOW_BLUR]
                group1 = Lay.selectable(j, group, d)
                pdb.gimp_image_remove_layer(j, group)
                group = group1

            if ok.MAKE_OPAQUE not in d:
                d[ok.MAKE_OPAQUE] = 1

            z = RenderHub.do_shadow(
                stat,
                group,
                d[ok.OFFSET_X],
                d[ok.OFFSET_Y],
                blur,
                d[ok.SHADOW_COLOR],
                d[ok.INTENSITY],
                layer_name=name,
                d=d,
                is_inlay=is_inlay
            )

            pdb.gimp_image_remove_layer(j, group)

            if z:
                if is_inlay:
                    # Caption is to be on top:
                    a = 0
                    for i in CAPTION_LAYER:
                        a += int(
                            Lay.search(
                                parent,
                                i,
                                is_err=0
                            ) is not None
                        )
                    b = 0

                else:
                    a = len(parent.layers)
                    b = 0
                    for i in BOTTOM_LAYER:
                        reserved = Lay.search(parent, i, is_err=0)
                        b = b - 1 if reserved else b

                Lay.order(j, z, parent, offset=a + b)
                if one.k == ek.KEY_LIGHT_SHADOW:
                    z.mode = fu.LAYER_MODE_NORMAL

            [Lay.show(i) for i in caster_layer]
            pdb.gimp_selection_none(j)
