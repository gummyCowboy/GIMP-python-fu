#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_one_constant import (
    ForFormat as ff,
    ForWidget as fw,
    UIKey
)
from roller_one_tip import Tip
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_radio import RollerRadioList
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable as rt
import gtk

OPTION_LABEL = (
    "Locked",
    "Trim",
    "Filled Cell",
    "Fixed Value",
    "Fraction of Image Size",
    "Crop"
)


class PortResize(Port):
    """
    Offer different methods for resizing an image when placing it in a cell.
    """

    def __init__(self, d, g):
        """
        Draw widgets.

        d: dict
            with init values

        g: RollerButton
            with resize info
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self._button = g
        self.color = g.color
        Port.__init__(self, d)

    def _draw_crop_value_group(self, g):
        """
        Draw the crop value group.

        g: GTK container
            to receive group
        """
        d = dict(
            color=self.color,
            container=g,
            limit=(0, 1000000),
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            precision=0
        )
        d['q'] = (
            ["X-Offset:", RollerSlider, dict(d)],
            ["Y-Offset:", RollerSlider, dict(d)],
            ["Width:", RollerSlider, dict(d)],
            ["Height:", RollerSlider, dict(d)]
        )
        q = self._crop_value = rt.populate_table(**dict(d))
        s = self.stat.render.size

        q[-4].set_value(0.)
        q[-3].set_value(0.)
        q[-2].set_value(s[0])
        q[-1].set_value(s[1])
        q[-1].set_tooltip_text(Tip.RESIZE_CROP_VALUE)
        self.keep(q)

    def _draw_filled_cell_group(self, g):
        """
        Draw the filled cell options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text="The image is resized so \n"
            "that it fills the cell. "
        )
        g.pack_start(g1, expand=True)

    def _draw_fixed_value_group(self, g):
        """
        Draw the fixed value group.

        g: GTK container
            to receive group
        """
        d = dict(
            color=self.color,
            container=g,
            limit=(0, 1000000),
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            precision=0
        )

        d['q'] = (
            ["Width:", RollerSlider, dict(d)],
            ["Height:", RollerSlider, dict(d)]
        )
        q = self._fixed_value = rt.populate_table(**dict(d))
        s = self.stat.render.size

        q[-2].set_value(s[0])
        q[-1].set_value(s[1])
        q[-1].set_tooltip_text(Tip.RESIZE_FIXED_VALUE)
        self.keep(q)

    def _draw_fraction_value_group(self, g):
        """
        Draw the fraction value group.

        g: GTK container
            to receive group
        """
        d = dict(
            color=self.color,
            container=g,
            limit=(.000001, 2.),
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            precision=6
        )
        d['q'] = (
            ["Width:", RollerSlider, dict(d)],
            ["Height:", RollerSlider, dict(d)]
        )
        q = self._fraction_value = rt.populate_table(**dict(d))

        q[-2].set_value(1.)
        q[-1].set_value(1.)
        q[-1].set_tooltip_text(Tip.RESIZE_FRACTION_VALUE)
        self.keep(q)

    def _draw_locked_group(self, g):
        """
        Draw the locked-proportions options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text="The images proportions are locked\n"
            "and a best fit is applied if necessary.\n"
            "The image is not enlarged."
        )
        g.pack_start(g1, expand=True)

    def _draw_trim_group(self, g):
        """
        Draw the Trim options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text="If necessary, the image is resized so that\n"
            "it can fill the cell to the greatest degree\n"
            "without enlarging or stretching the image. In\n"
            "the process, a side of the image may be trimmed."
        )
        g.pack_start(g1, expand=True)

    def _draw_resize_choices(self, g):
        """
        Draw the resize choices group.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        label = OPTION_LABEL
        box = RollerBox(
            gtk.VBox,
            align=(1, 1, 1, 1),
            padding=(w // 2, w, 0, 0)
        )

        g.add(box)

        g = self._radio_list = RollerRadioList(
            container=box,
            key='not_used',
            labels=label,
            on_widget_change=self.on_list_change,
            padding=(1, 0, w, w)
        )
        self.keep(g.buttons)

    def _draw_resize_options(self, g):
        """
        Draw the option groups for radio-list choices.

        g: VBox
            container for widgets
        """
        g1 = self._radio_list
        g1.switch_group_box = g
        process = (
            self._draw_locked_group,
            self._draw_trim_group,
            self._draw_filled_cell_group,
            self._draw_fixed_value_group,
            self._draw_fraction_value_group,
            self._draw_crop_value_group
        )
        label = OPTION_LABEL

        for x, p in enumerate(process):
            vbox = gtk.VBox()

            g1.group_box.append(vbox)

            if label[x]:
                vbox.add(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=label[x] + " Options:"
                    )
                )
            p(vbox)

    def _get_numeric(self, x):
        """
        Call to get a numeric setting.

        Return:
            string
            the Numeric Name combobox choice.
        """
        if x == ff.Place.FIXED_VALUE_INDEX:
            return \
                Form.FIXED_WIDTH + str(self._fixed_value[0].get_value()) + \
                ", " + \
                Form.FIXED_HEIGHT + str(self._fixed_value[1].get_value())

        elif x == ff.Place.FRACTION_VALUE_INDEX:
            return \
                Form.FRACTION_WIDTH + str(
                    self._fraction_value[0].get_value()
                ) \
                + ", " + \
                Form.FRACTION_HEIGHT + str(self._fraction_value[1].get_value())

        else:
            a = self._crop_value
            return \
                Form.X_OFFSET + str(a[0].get_value()) + ", " + \
                Form.Y_OFFSET + str(a[1].get_value()) + ", " + \
                Form.CROP_WIDTH + str(a[2].get_value()) + ", " + \
                Form.CROP_HEIGHT + str(a[3].get_value())

    def _set_numeric_widget(self):
        """
        Set a numeric-type widgets with the value from the resize button.
        """
        q, type_x = Form.strip_numeric_value(
            self._button.get_value()
        )

        if type_x == ff.Place.FRACTION_VALUE_INDEX:
            g = self._fraction_value

        elif type_x == ff.Place.FIXED_VALUE_INDEX:
            g = self._fixed_value

        else:
            g = self._crop_value

        for x, i in enumerate(q):
            g[x].set_value(i)
        return type_x

    def do_accept(self, *_):
        """
        Accept the resize setting.

        Return: true
            The key-press is handled.
        """
        x = self._radio_list.get_value()

        if x in ff.Place.RESIZE_NUMERIC_INDEX:
            a = self._get_numeric(x)

        else:
            a = ff.Place.TYPE[x]
        return self.do_accept_callback(a)

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for widgets
        """
        q = (
            self._draw_resize_choices,
            self._draw_resize_options,
            self.draw_process_group
        )
        group_name = "Resize Choices", "", ""

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if group_name[x]:
                vbox.pack_start(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=group_name[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()

            if x == 0:
                hbox = gtk.HBox()
                g.pack_start(hbox, expand=False)

            if x < 2:
                hbox.pack_start(box, expand=False)

            else:
                g.pack_start(box, expand=False)

        a = Port.loading
        Port.loading = 0
        b = self._button.get_value()

        if b in ff.Place.TYPE:
            x = ff.Place.TYPE.index(b)

        else:
            x = self._set_numeric_widget()

        self._radio_list.set_value(x)
        self.on_list_change(self._radio_list, x)
        Port.loading = a

    def on_widget_change(self, *_):
        """Call when a widget is changed."""
        return
