#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerKey
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
BRIGHTNESS_0 = 0
CONTRAST_30 = 30


class CosmeticPipe:
    """Create a raised painted-pipe appearance for a border."""

    def __init__(self, one):
        """
        Do frame.

        one: One
            Has variables.
        """
        stat = one.stat
        d = one.d
        j = stat.render.image
        z = Lay.search(one.parent, LayerKey.IMAGE)
        w = d[ok.FRAME_WIDTH]
        group = Lay.group(j, one.k, parent=one.parent)
        z1 = Lay.selectable(j, z, d)

        Lay.order(j, z1, group)

        z2 = Lay.clone(j, z1)

        Lay.color_fill(z2, (255, 255, 255))

        # Make two white layers:
        z3 = Lay.clone(j, z2)

        # one white, one black:
        pdb.gimp_drawable_invert(z3, 0)

        Sel.item(j, z1)
        Sel.grow(j, w, d[ok.FRAME_TYPE])
        Sel.item(j, z1, option=fu.CHANNEL_OP_SUBTRACT)

        # frame selection:
        sel = stat.save_selection()

        pdb.gimp_image_remove_layer(j, z1)
        Sel.clear_outside_of_selection(j, z3)

        z1 = Lay.merge(j, z3)

        pdb.gimp_selection_none(j)
        Lay.blur(j, z1, w * 2)

        pdb.plug_in_emboss(
            j,
            z1,
            d[ok.LIGHT_ANGLE],
            Pdb.Emboss.ELEVATION_50,
            Pdb.Emboss.DEPTH_100,
            Pdb.Emboss.BUMP
        )
        Lay.blur(j, z1, w * 2)

        pdb.gimp_brightness_contrast(z1, BRIGHTNESS_0, 25)

        z2 = Lay.clone(j, z1)
        z2.mode = fu.LAYER_MODE_HARDLIGHT

        RenderHub.set_fill_context(
            {
                ok.THRESHOLD: 1.,
                ok.OPACITY: 100.,
                ok.MODE: "Normal",
                ok.CRITERION: "Composite"
            }
        )
        pdb.gimp_context_set_pattern(d[ok.PATTERN])
        pdb.gimp_drawable_edit_bucket_fill(
            z1,
            fu.FILL_PATTERN,
            Pdb.BucketFill.X_IS_1,
            Pdb.BucketFill.Y_IS_1
        )
        pdb.gimp_brightness_contrast(z1, BRIGHTNESS_0, 33)

        z1 = Lay.merge_group(j, group)
        z1.name = Lay.get_layer_name(LayerKey.FRAME, parent=one.parent)
        Sel.isolate(j, z1, sel)
