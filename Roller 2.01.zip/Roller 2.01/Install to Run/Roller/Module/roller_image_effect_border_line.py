#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerKey
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class BorderLine:
    """Create a metallic-like border around images."""

    def __init__(self, one, filler=None, framer=None):
        """
        Do the Border Line image-effect.

        one: One
            Has variables.

        filler: function
            Call to fill a frame.

        framer: function
            Call to add more frame.
        """
        stat = self.stat = one.stat
        self.option_key = one.k
        parent = self.parent = one.parent
        self.session = one.session
        d = one.d
        j = stat.render.image
        x = Lay.offset(Lay.search(parent, LayerKey.IMAGE))
        z1 = Lay.add(
            j,
            Lay.get_layer_name(LayerKey.FRAME, parent=parent),
            parent=parent,
            offset=x
        )

        # Create embossed border:
        Lay.color_fill(z1, (255, 255, 255))

        z2 = Lay.selectable(
            j,
            stat.render.get_image_layer(
                Lay.get_format_name_from_group(parent)
            ),
            d
        )

        Sel.item(j, z2)

        img_sel = stat.save_selection()

        Sel.invert(j)

        if Sel.is_sel(j):
            Sel.invert(j)
            Sel.grow(j, d[ok.FRAME_WIDTH], d[ok.FRAME_TYPE])

            if filler:
                # Create filler and outer selections:
                sel = stat.save_selection()

                Sel.grow(j, d[ok.WIDTH], d[ok.FRAME_TYPE])
                Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
                Sel.grow(j, 1, d[ok.FRAME_TYPE])

                self.fill_sel = stat.save_selection()

                Sel.grow(
                    j,
                    max(int(d[ok.FRAME_WIDTH] / 3.5), 3),
                    d[ok.FRAME_TYPE]
                )
                Sel.load(j, self.fill_sel, option=fu.CHANNEL_OP_SUBTRACT)
                Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

            if framer:
                framer(d)

            Sel.load(j, img_sel, option=fu.CHANNEL_OP_SUBTRACT)

            sel = stat.save_selection()

            RenderHub.draw_sel(stat, sel, z1)
            RenderHub.emboss(j, z1, d[ok.LIGHT_ANGLE], 50)
            Sel.isolate(j, z1, sel)
            pdb.plug_in_antialias(j, z1)
            pdb.gimp_image_remove_layer(j, z2)

            z2 = BorderLine.add_bump_layer(j, z1, parent, stat, d)
            z3 = BorderLine.add_stain_layer(j, z2, parent)

            for i in (z2, z3):
                Sel.isolate(j, i, sel)
            if filler:
                filler(z3, d)

        else:
            # The layers are not appropriate:
            pdb.gimp_image_remove_layer(j, z1)
            pdb.gimp_image_remove_layer(j, z2)

    @staticmethod
    def add_bump_layer(j, z, parent, stat, d):
        """
        Add a bump layer.

        j: GIMP image
            work-in-progress

        z: layer
            to clone from

        parent: layer
            format group

        stat: Stat
            globals

        d: dict
            Has options.
        """
        z = Lay.clone(j, z)

        RenderHub.noise(stat, z, d)

        z.mode = fu.LAYER_MODE_OVERLAY
        z.name = Lay.get_layer_name(LayerKey.BUMP, parent=parent)
        z.opacity = 8.
        return z

    @staticmethod
    def add_stain_layer(j, z, parent):
        """
        Add a stain layer.

        j: GIMP image
            work-in-progress

        z: layer
            to clone from

        parent: layer
            format group
        """
        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_VIVID_LIGHT
        z.opacity = 18.
        z.name = Lay.get_layer_name(LayerKey.STAIN, parent=parent)

        Lay.blur(j, z, 20)
        return z
