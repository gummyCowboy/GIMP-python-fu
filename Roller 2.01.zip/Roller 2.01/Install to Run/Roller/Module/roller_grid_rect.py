#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_image import Rect
from roller_grid import Grid
from roller_one_constant import ForFormat as ff, FormatKey as fk

GRID = fk.Cell.Grid


class GridRect:
    """
    Calculate the position and the size of cells.

    The cells are rectangular shaped.
    """

    def __init__(self, grid):
        """
        Calculate cell size and rectangle shape.

        grid: One
            Has init values.
        """
        self.grid = grid
        row, column, table = grid.r, grid.c, grid.table
        x, y = grid.offset
        s = grid.layer_space
        with_shape = grid.with_shape

        # Determine if the 'cell size' is the grid type.
        # If so then calculate grid size:
        if grid.grid_type == ff.Grid.Index.CELL_SIZE:
            w, h = grid.column_width, grid.row_height
            s1 = w * column, h * row
            w, h = w / 1., h / 1.
            x, y = Grid.calc_pin_offset(grid.pin, s, s1[0], s1[1], x, y)

        elif grid.grid_type == ff.Grid.Index.SHAPE_COUNT:
            w = s[0] // column
            h = s[1] // row
            w = min(w, h)
            s1 = w * column, w * row
            w, h = w, w
            x, y = Grid.calc_pin_offset(grid.pin, s, s1[0], s1[1], x, y)

        else:
            w = s[0] / 1. / column
            h = s[1] / 1. / row

        y_intersect = []
        x_intersect = []

        for r in range(row + 1):
            y_intersect.append(int(round(y)))
            y += h

        for c in range(column + 1):
            x_intersect.append(int(round(x)))
            x += w
        for r in range(row):
            for c in range(column):
                y, y1 = y_intersect[r], y_intersect[r + 1]
                x, x1 = x_intersect[c], x_intersect[c + 1]
                position = x, y
                size = x1 - x, y1 - y

                # 'cell' is the cell before margins:
                table[r][c].cell = Rect(position, size)
                x1, y1 = x + size[0], y + size[1]
                q = x, y, x1, y, x1, y1, x, y1
                table[r][c].plaque = q
                if with_shape:
                    table[r][c].shape = q

    def calc_shape_per_cell(self, *_):
        """
        Record the shape from the pocket size
        on a per cell basis.

        Is part of the GridDeck template.
        """
        # The pocket rectangle has the shape points:
        self.calc_shape_with_pocket()

    def calc_shape_with_pocket(self):
        """
        Record the shape from the pocket size.

        Is part of the GridDeck template.
        """
        q = self.grid.table
        for r in range(self.grid.r):
            for c in range(self.grid.c):
                rect = q[r][c].pocket
                x, y = rect.position
                w, h = rect.size
                x1, y1 = x + w, y + h
                q[r][c].shape = x, y, x1, y, x1, y1, x, y1
