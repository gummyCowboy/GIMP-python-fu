#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_caption import Caption
from roller_format_fringe import Fringe
from roller_format_form import Form
from roller_format_image import RollerImage
from roller_format_image_mask import ImageMask
from roller_format_plaque import Plaque
from roller_grid_deck import GridDeck
from roller_image_effect import LayerKey
from roller_one_base import Comm
from roller_one_constant import (
    ForFormat as ff,
    ForLayer,
    ForLayout,
    FormatKey as fk,
    FreeCellKey as fck,
    LayoutKey,
    OptionKey as ok,
    PlaceKey,
    SessionKey as sk
)
from roller_one import One
from roller_one_fu import Lay, Sel
import gimpfu as fu
import os

pdb = fu.pdb
MARGIN = ff.Margin.Index
SHIFT = ff.Cell.SHIFT


class Layout:
    """Manage image place."""

    def __init__(self, stat):
        """
        Init layout variables.

        stat: Stat
            globals
        """
        self.stat = stat
        self._deck = self._active_layer = self.image_group = None
        self._next_index = self._previous_index = self._fluctuate_index = 0
        self.image_group = self.format_group = self.blur_behind_layer = None
        self._init_layout_references()

    def _calc_rect_position(self, d, j, format_x):
        """
        For an image or rectangle, calculate its (x, y) position in a cell.

        d: dict
            format dict

        j: RollerImage
            Has x and y position.

        format_x: int
            index
            corresponding with session's format list
        """
        r, c = j.r, j.c
        x, y = self._get_pocket_position(format_x, r, c, j=j)
        w, h = j.mold.size
        n = Form.get_horz_just(d, r, c)
        n1 = Form.get_vert_just(d, r, c)

        if n == ff.Place.CENTER:
            x += (self._get_pocket_width(format_x, r, c, j=j) - w) // 2

        elif n == ff.Place.RIGHT:
            x += self._get_pocket_width(format_x, r, c, j=j) - w

        if n1 == ff.Place.MIDDLE:
            y += (self._get_pocket_height(format_x, r, c, j=j) - h) // 2

        elif n1 == ff.Place.BOTTOM:
            y += self._get_pocket_height(format_x, r, c, j=j) - h

        j.mold.position = x, y
        if r != ForLayout.FREE_CELL:
            self._deck.set_mold(format_x, r, c, (x, y), (w, h))

    def _color_fill(self, q):
        """
        Fill the selection with a color on the current format layer.

        q: tuple
            color (RGB)
        """
        Sel.fill(self._active_layer, q)
        pdb.gimp_displays_flush()

    def _draw_caption(self, session, d, format_x, parent):
        """
        Draw cell caption for layout.

        d: dict
            format dict

        format_x: int
            index

        parent: layer
            layout format group
        """
        if session[sk.LAYOUT_OPTION][LayoutKey.CELL_CAPTION]:
            Caption(
                session,
                d,
                format_x,
                self.stat,
                parent=parent,
                is_layout=True
            )

    def _draw_cell_margins(self, session, d, format_x):
        """
        Draw the cell margins.

        Call during a layout demo.

        session: dict
            of session

        d: dict
            of format

        format_x: int
            index in format list
        """
        def select_margins(m):
            """
            Select a margin for a cell.

            m: flag
                If it's true, the margins were selected.

            return:
                m: flag
                same as input 'm'
            """
            a = margin[x]
            p = self._get_margin_rect_width
            p1 = self._get_margin_rect_height
            if a:
                # Unavailable cells have zero dimensions:
                if self._get_pocket_width(format_x, r, c, j=j):
                    m = 1
                    x1, y = self._get_pocket_position(format_x, r, c, j=j)
                    x1 += (
                        0,
                        0,
                        -margin[MARGIN.LEFT],
                        self._get_pocket_width(format_x, r, c, j=j)
                    )[x]
                    y += (
                        -margin[MARGIN.TOP],
                        self._get_pocket_height(format_x, r, c, j=j),
                        0,
                        0
                    )[x]
                    w = (
                        p(session, format_x, r, c, d, j=j),
                        p(session, format_x, r, c, d, j=j),
                        a,
                        a
                    )[x]
                    h = (
                        a,
                        a,
                        p1(session, format_x, r, c, d, j=j),
                        p1(session, format_x, r, c, d, j=j)
                    )[x]
                    Sel.rect(self.stat.render.image, x1, y, w, h)
            return m

        row, col = self._deck.get_division(format_x)
        m = 0
        j = None
        double_space = Form.is_double_space(d)
        just_one = Form.is_draw_one_margin(d) if not double_space else 0

        for r in range(row):
            for c in range(col):
                is_cell = 1

                if double_space:
                    is_cell = Form.is_double_space_cell(r, c, double_space)
                if is_cell:
                    margin = self.get_cell_margin(format_x, r, c, d)
                    for x in range(4):
                        draw = 1

                        # left, right:
                        if x in (MARGIN.LEFT, MARGIN.RIGHT):
                            if just_one and r > 0:
                                draw = 0

                        # top, bottom:
                        else:
                            if just_one and c > 0:
                                draw = 0
                        if draw:
                            m += select_margins(m)

        for cell in d[fk.Layer.CELL_LIST]:
            r = c = ForLayout.FREE_CELL
            j = self.get_roller_image(session, format_x, r, c)
            if not j:
                # Create a dummy image for the missing image:
                j = RollerImage(None, "")

                Form.prep_free_cell_image(j, cell, session['size'])
                margin = Form.combine_margin(
                    cell[fck.Cell.MARGIN],
                    j.cell.width,
                    j.cell.height
                )
            for x in range(4):
                m += select_margins(m)
        if m:
            self._color_fill(ForLayout.CELL_MARGIN_COLOR)

    def _draw_coord(self, session, format_x, j):
        """
        Draw image coordinates at the top-left of an image rectangle.

        session: dict
            of session

        format_x: int
            index to format dict

        j: RollerImage
            work-in-progress
        """
        z = self._make_text(str(j.mold.x) + ", " + str(j.mold.y))
        cell = self._deck.get_merge_cell_rect(format_x, j.r, j.c)
        self._draw_text(cell.x + 3, cell.y, z)

    def _draw_corners(self, session, format_x, j):
        """
        Draw image corner coordinates.

        session: dict
            of session

        format_x: int
            index to format dict

        j: RollerImage
            work-in-progress
        """
        # top-right:
        x = j.mold.x + j.mold.width
        n = str(x) + ", " + str(j.mold.y)
        z = self._make_text(n)
        cell = self._deck.get_merge_cell_rect(format_x, j.r, j.c)

        self._draw_text(cell.x + 3, cell.y, z)

        # bottom-left:
        y = j.mold.y + j.mold.height
        n = str(j.mold.x) + ", " + str(y)
        z = self._make_text(n)
        self._draw_text(
            cell.x + cell.width - z.width - 3,
            cell.y + cell.height - z.height,
            z
        )

    def _draw_dimension(self, session, format_x, j):
        """
        Draw an image's dimension at the bottom-right of an image rectangle.

        session: dict
            of session

        format_x: int
            index to format

        j: RollerImage
            work-in-progress
        """
        w, h = j.mold.size
        n = str(w) + ", " + str(h)
        z = self._make_text(n)
        cell = self._deck.get_merge_cell_rect(format_x, j.r, j.c)
        self._draw_text(
            cell.x + cell.width - z.width - 3,
            cell.y + cell.height - z.height,
            z
        )

    def _draw_format(self, session, d, format_x, parent):
        """
        Draw a format.

        session: dict
            of session

        d: dict
            of format

        format_x: int
            index in format list

        parent: layer
            layout format group
        """
        self.calc_cell_table(session)

        e = session[sk.LAYOUT_OPTION]
        is_rectangle = Form.is_rectangle_shape(d)
        double_space = Form.is_double_space(d)
        q = (
            (LayoutKey.CELL_MARGINS, self._draw_cell_margins),
            (LayoutKey.LAYER_MARGINS, self._draw_layer_margins),
        )

        self._draw_plaque_types(session, d, format_x, double_space)

        if e:
            for i in q:
                if e[i[0]]:
                    i[1](session, d, format_x)

        self._draw_image(session, d, format_x, is_rectangle, double_space)

        if e[LayoutKey.GRID]:
            self._draw_grid(session, d, format_x, double_space)
        self._draw_caption(session, d, format_x, parent)

    def _draw_grid(self, session, d, format_x, double_space):
        """
        Draw grid lines.

        session: dict
            of session

        d: dict
            of format

        format_x: int
            index in format list

        double_space: flag
            Is true if the cell table is doubled-spaced.
        """
        m = 0
        row, col = self._deck.get_division(format_x)
        w, h = session['size']
        top, bottom, left, right = Form.get_layer_margin(d, (w, h))

        # Grid lines divide the layer space:
        w1 = w - left - right
        x = left
        h1 = 1

        pdb.gimp_selection_none(self.stat.render.image)

        # Draw rows:
        if row > 1:
            for r in range(1, row):
                c = 0
                is_draw = 1

                if double_space:
                    c = not r % 2 if double_space == SHIFT else r % 2
                    is_draw = Form.is_double_space_cell(r, c, double_space)
                if is_draw:
                    y = self._deck.get_cell_position(format_x, r, c)[1]
                    if 0 < y < h:
                        m = 1
                        Sel.rect(self.stat.render.image, x, y, w1, h1)

        w1, h1 = 1, h - top - bottom
        y = top

        # Draw columns:
        if col > 1:
            for c in range(1, col):
                is_draw = 1
                r = 0

                if double_space:
                    r = not c % 2 if double_space == SHIFT else c % 2
                    is_draw = Form.is_double_space_cell(r, c, double_space)
                if is_draw:
                    x = self._deck.get_cell_position(format_x, r, c)[0]
                    if 0 < x < w:
                        m = 1
                        Sel.rect(self.stat.render.image, x, y, w1, h1)
        if m:
            self._color_fill(ForLayout.GRID_COLOR)

    def _draw_image(self, session, d, format_x, is_rectangle, double_space):
        """
        Draw a rectangle that represents an image.
        Draw image-related text.
        Conditionally apply an image mask.
        Work on the active layer.

        session: dict
            of session

        d: dict
            of format

        format_x: int
            index in format list

        is_rectangle: flag
            Is true if the cell shape is a rectangle.

        double_space: flag
            Is true if the cell table is double-spaced.
        """
        def process_image():
            j.r, j.c = r, c
            j.rotate = Form.get_rotate(d, r, c)

            pdb.gimp_selection_none(render)
            self._mold_rect(j, d, format_x)

            if j.rotate:
                self._rotate_image_rect(j, d, format_x)

            if e[a.IMAGE_MASK]:
                sel = stat.save_selection()
                render.active_layer = self._active_layer
                if ImageMask.make_mask_selection(
                    session,
                    d,
                    stat,
                    format_x,
                    r,
                    c,
                    image=j
                ):
                    Sel.load(render, sel, option=fu.CHANNEL_OP_INTERSECT)

            if not is_rectangle:
                sel = stat.save_selection()
                Form.select_shape(render, j.shape)

            self._color_fill(ForLayout.IMAGE_COLOR)
            if e:
                for i in q:
                    if e[i[0]]:
                        i[1](session, format_x, j)

        a = LayoutKey
        stat = self.stat
        render = stat.render.image
        row, col = self._deck.get_division(format_x)
        e = session[sk.LAYOUT_OPTION]
        q = (
            (a.COORDINATES, self._draw_coord),
            (a.CORNERS, self._draw_corners),
            (a.DIMENSIONS, self._draw_dimension),
            (a.NAME, self._draw_name),
            (a.RATIOS, self._draw_ratio)
        )
        parent = self._active_layer.parent
        self._active_layer = render.active_layer = parent.layers[0]

        pdb.gimp_selection_none(render)

        for r in range(row):
            for c in range(col):
                m = 1

                if double_space:
                    m = Form.is_double_space_cell(r, c, double_space)
                if m:
                    j = self.get_roller_image(session, format_x, r, c)
                    if j:
                        j.pocket = self._deck.get_pocket(format_x, r, c)
                        j.shape = self._deck.get_shape(format_x, r, c)
                        process_image()
        for d in d[fk.Layer.CELL_LIST]:
            j = RollerImage.get_image(
                session,
                d[PlaceKey.IMAGE_PLACE][PlaceKey.IMAGE]
            )
            if j:
                r = c = ForLayout.FREE_CELL

                Form.prep_free_cell_image(j, d, session['size'])
                process_image()
                if j.free:
                    RollerImage.close_image(j)

    def _draw_layer_margins(self, session, d, format_x):
        """
        Draw the layer margins.

        session: dict
            of session

        d: dict
            Has format.

        format_x: int
            index
            corresponding with session's format list
        """
        m = 0
        size = session['size']
        top, bottom, left, right = Form.get_layer_margin(d, size)
        if any((top, bottom, left, right)):
            for x in range(4):
                m = 1

                if x in (MARGIN.TOP, MARGIN.BOTTOM):
                    # top, bottom:
                    x1 = left
                    w = size[0] - left - right

                    if x == MARGIN.TOP:
                        y = 0
                        h = top

                    else:
                        h = bottom
                        y = size[1] - h

                else:
                    # left, right:
                    h = size[1] - top - bottom
                    y = top

                    if x == MARGIN.LEFT:
                        x1 = 0
                        w = left

                    else:
                        w = right
                        x1 = size[0] - w
                Sel.rect(self.stat.render.image, x1, y, w, h)

            if m:
                self._color_fill(ForLayout.LAYER_MARGIN_COLOR)

    def _draw_name(self, session, format_x, j):
        """
        Draw a document title at the center of an image rectangle.

        session: dict
            of session

        format_x: int
            index to format dict

        j: RollerImage
            work-in-progress
        """
        z = self._make_text(j.image_name)
        x = j.mold.width // 2 + j.mold.x - z.width // 2
        y = j.mold.height // 2 + j.mold.y + z.height // 2
        self._draw_text(x, y, z)

    def _draw_plaque_types(self, session, d, format_x, double_space):
        """
        Draw cell plaque and cell fringe mock-ups.

        d: dict
            of format

        format_x: int
            index in format list

        double_space: flag
            Is true if the cell table is double-spaced.
        """
        def select_plaque(plaque_dict):
            """
            Select a rectangle that represents a cell plaque.

            plaque_dict: dict
                Has plaque.
            """
            one.data = Form.get_cell_plaque(plaque_dict, r, c)
            one.r, one.c = r, c

            if Plaque.is_cell_plaque(d, one, double_space, merged):
                plaque = self.get_plaque(format_x, r, c, j=j1)

                Form.select_shape(j, plaque)
                Sel.fill(
                    self._active_layer,
                    ForLayout.PLAQUE_COLOR
                )
                pdb.gimp_selection_none(j)

        e = session[sk.LAYOUT_OPTION]
        stat = self.stat
        j = stat.render.image
        j1 = None
        row, col = self._deck.get_division(format_x)
        merged = Form.is_merge_cells(d)
        one = One()

        if e[LayoutKey.CELL_PLAQUE]:
            for r in range(row):
                for c in range(col):
                    m = 1

                    if double_space:
                        m = Form.is_double_space_cell(r, c, double_space)

                    if m:
                        select_plaque(d)

            # for cell list:
            merged = double_space = 0

            for cell in d[fk.Layer.CELL_LIST]:
                r = c = ForLayout.FREE_CELL
                j1 = RollerImage(None, "")

                # Set the 'cell' Rect for 'select_plaque':
                Form.prep_free_cell_image(j1, cell, session['size'])
                select_plaque(cell)
        if e[LayoutKey.CELL_FRINGE]:
            # Rename layer for fringe to find plaque:
            z = self._active_layer
            n = Lay.get_layer_name(LayerKey.CELL_PLAQUE, parent=z.parent)
            z.name = n

            Fringe(session, d, format_x, stat, True, z.parent)
            self._active_layer = j.active_layer

    def _draw_ratio(self, session, format_x, j):
        """
        Draw an image ratio at the center of an image rectangle.

        A ratio is an image center point divided by the render size.

        session: dict
            of session

        format_x: int
            index to format

        j: RollerImage
            work-in-progress
        """
        cell = self._deck.get_merge_cell_rect(format_x, j.r, j.c)
        x = j.mold.width // 2 + j.mold.x
        y = j.mold.height // 2 + j.mold.y
        x1 = x / 1. / session['w']
        y1 = y / 1. / session['h']
        r_x = format(x1, '.2f')
        r_y = format(y1, '.2f')
        n = r_x[int(x1 < 1):] + ", " + r_y[int(y1 < 1):]
        z = self._make_text(n)
        x2 = cell.x + cell.width // 2 - z.width // 2
        y2 = cell.y + cell.height // 2 - z.height // 2
        self._draw_text(x2, y2, z)

    def _draw_text(self, x, y, z):
        """
        Add a text layer to the format group.

        x, y: int
            final position
            screen coordinate

        z: layer
            to receive text
        """
        Lay.place(self.stat.render.image, z, self.format_group)
        pdb.gimp_text_layer_set_color(z, (255, 255, 255))
        pdb.gimp_layer_set_offsets(z, x, y)
        z.opacity = 66.

    def _get_folder_file_reference(self, q, d, format_x):
        """
        Return a file path string from an indexed-file of a folder path.

        q: tuple
            of string
            folder path, filter

        d: dict
            of format

        format_x: int
            index in format list

        Return: string or None
            Return file path.
        """
        path = None
        e = RollerImage.folder_pile
        k = n, n1 = q

        if k in e:
            path = self._get_next_folder_file(k, format_x)

        else:
            try:
                file_list = []

                for _file in os.listdir(n):
                    ext = os.path.splitext(_file)[1]
                    if ext.lower() in ff.Image.EXTENSION:
                        if n1:
                            if n1 not in _file:
                                continue
                        file_list.append(os.path.join(n, _file))

                file_list = sorted(file_list)
                e[k] = file_list, 0
                path = self._get_next_folder_file(k, format_x)

            except Exception as ex:
                Comm.info_msg(
                    "Roller tried to read from a folder:\n'{}'\n"
                    "and an error occurred.".format(n)
                )
                Comm.info_msg("The error was:\n" + repr(ex))
                Comm.info_msg(
                    "Roller will use a 'None' image reference for the folder."
                )
        return path

    def _get_fluctuate_image(self, n, *_, **d):
        """
        Get an opened image reference with the fluctuate index.

        n: string
            fluctuate descriptor

        Return: string or None
            an opened image
        """
        n1 = None

        if RollerImage.image_count:
            if n == ff.Image.FLUCTUATE_INCREMENT:
                # Increment rollover:
                if self._fluctuate_index + 1 >= RollerImage.image_count:
                    self._fluctuate_index = -1

                self._fluctuate_index += 1
                n1 = RollerImage.image_names[self._fluctuate_index]

            else:
                # Decrement rollover:
                if self._fluctuate_index - 1 < 0:
                    self._fluctuate_index = RollerImage.image_count

                self._fluctuate_index -= 1
                n1 = RollerImage.image_names[self._fluctuate_index]
        return n1

    def _get_image_reference(self, format_x, r, c, d):
        """
        Get an image reference for a cell.

        format_x: int
            index to format in session's format list

        r, c: int
            row, column
            cell index

        d: dict
            format dict

        Return: string or None
            image reference
        """
        if d[fk.Cell.Image.Place.PER_CELL]:
            n = d[fk.Cell.Image.Place.PER_CELL][r][c][
                ff.Place.Index.IMAGE
            ]

        else:
            n = d[PlaceKey.IMAGE_PLACE][PlaceKey.IMAGE]
        return self.get_image(n, d, format_x)

    def _get_margin_rect_height(self, session, format_x, r, c, d, j=None):
        """
        Return the height of a cell margin drawing rectangle.

        session: dict
            Has render height.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        d: dict
            format dict

        j: RollerImage
            Has pocket.

        Return: int
            the height of the drawing rectangle
        """
        if r != ForLayout.FREE_CELL:
            if Form.is_draw_one_margin(d):
                top, bottom, _, _ = self.get_cell_margin(format_x, r, c, d)
                top1, bottom1, _, _ = Form.get_layer_margin(d, session['size'])
                return session['h'] - top - bottom - top1 - bottom1

            else:
                return self._get_pocket_height(format_x, r, c)

        # free-range cell:
        return j.pocket.height

    def _get_margin_rect_width(self, session, format_x, r, c, d, j=None):
        """
        Return the width of a cell margin drawing rectangle.

        session: dict
            of session

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        d: dict
            of format

        j: RollerImage
            Has pocket.

        Return: int
            width of rectangle for drawing margin
        """
        if r != ForLayout.FREE_CELL:
            if Form.is_draw_one_margin(d):
                _, _, left, right = self.get_cell_margin(format_x, r, c, d)
                _, _, left1, right1 = Form.get_layer_margin(d, session['size'])
                return session['w'] - left - right - left1 - right1

            else:
                return self._get_pocket_width(format_x, r, c)

        # free-range cell:
        return j.pocket.width

    def _get_next_folder_file(self, key, format_x):
        """
        Get a file reference from a folder's file list.

        key: tuple
            path, filter
            key for RollerImage.folder_pile

        format_x: int
            index

        Return: string or None
            file path
        """
        path = None
        file_list, index = RollerImage.folder_pile[key]

        if index < len(file_list):
            path = file_list[index]
            index += 1
            RollerImage.folder_pile[key] = file_list, index
        return path

    def _get_next_image(self, n, *_, **d):
        """
        Get next image with the 'next' index.

        n: string
            Next descriptor

        Return:
            string or None
        """
        n1 = None

        if RollerImage.image_count:
            if n == ff.Image.NEXT_LINEAR:
                if self._next_index < RollerImage.image_count:
                    n1 = RollerImage.image_names[self._next_index]
                    self._next_index += 1

            else:
                # Next-Circular:
                if self._next_index >= RollerImage.image_count:
                    self._next_index = 0

                n1 = RollerImage.image_names[self._next_index]
                self._next_index += 1
        return n1

    def _get_pocket_height(self, format_x, r, c, j=None):
        """
        Get the pocket height for a cell.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        j: RollerImage
            Has 'd', its free cell dict.

        Return: int
            pocket height
        """
        if r != ForLayout.FREE_CELL:
            return self._deck.get_pocket(format_x, r, c).height
        return j.pocket.height

    def _get_pocket_position(self, format_x, r, c, j=None):
        """
        Get the pocket topleft coordinate (x, y) for a cell.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        j: RollerImage
            Has 'd', its free cell dict.

        Return: tuple
            position
            x, y
        """
        if r != ForLayout.FREE_CELL:
            return self._deck.get_pocket(format_x, r, c).position

        else:
            return j.pocket.position

    def _get_pocket_width(self, format_x, r, c, j=None):
        """
        Get a pocket's width.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            cell index

        j: RollerImage
            Has 'pocket'.

        Return: int
            pocket width
        """
        if r != ForLayout.FREE_CELL:
            return self._deck.get_pocket(format_x, r, c).width

        # free-range cell:
        return j.pocket.width

    def _get_previous_image(self, n, *_, **d):
        """
        Get previous opened image with the 'previous' index.

        n: string
            Previous descriptor

        d: unused

        Return: string
            open image title
        """
        n1 = None

        if RollerImage.image_count:
            if n == ff.Image.PREVIOUS_LINEAR:
                if self._previous_index > -1:
                    n1 = RollerImage.image_names[self._previous_index]
                    self._previous_index -= 1

            else:
                # Previous-Circular:
                if self._previous_index < 0:
                    self._previous_index = RollerImage.image_count - 1

                n1 = RollerImage.image_names[self._previous_index]
                self._previous_index -= 1
        return n1

    def _get_relative_name_reference(self, n, *_, **d):
        """
        Get an open image reference corresponding with a numeric index.

        n: string
            numeric reference

        Return: string
            opened image name or None
        """
        n1 = None
        q = RollerImage.relative_names

        if n != ok.NONE and n in q:
            x = q.index(n)
            n1 = RollerImage.image_names[x]
        return n1

    def _init_layout_references(self):
        """Initialize layout variables."""
        self._grid_deck = self._active_layer = None

    def _make_text(self, n):
        """
        Create a new text layer.

        n: string
            text to display

        Return the new layer.
        """
        z = pdb.gimp_text_layer_new(
            self.stat.render.image,
            n,
            'Sans-serif',
            11.,
            fu.PIXELS
        )
        z.name = ForLayer.LAYER_BULLET + n
        return z

    def _mold_image(self, j, d, format_x):
        """
        Mold an image to fit a cell.

        j: RollerImage
            to fit into cell

        d: dict
            of format

        format_x: int
            index
            corresponding with session's format list

        Return: bool
            Is true if there is material in the buffer.
        """
        pdb.gimp_selection_none(self.stat.render.image)

        is_copy = True

        if j.r != ForLayout.FREE_CELL:
            j.pocket = self._deck.get_pocket(format_x, j.r, j.c)
            j.cell = self._deck.get_merge_cell_rect(format_x, j.r, j.c)
            j.mold.size = j.mold.position = 0, 0
            j.shape = self._deck.get_shape(format_x, j.r, j.c)

        s = j.pocket.size

        # Get resize index for fill, locked, numeric, trim:
        x = Form.get_resize_type_index(d, j.r, j.c)

        if x < ff.Place.NUMERIC_INDEX:
            (
                Form.mold_lock,
                Form.mold_trim,
                Form.mold_fill
            )[x](j, d)

        else:
            is_copy = Form.mold_numerically(
                j,
                d,
                Form.get_resize_type(d, j.r, j.c)
            )

        if j.rotate and is_copy:
            j2 = pdb.gimp_edit_paste_as_new_image()
            z = Lay.rotate(j2, j.rotate)
            t = w, h = z.width, z.height

            pdb.gimp_edit_copy_visible(j2)
            pdb.gimp_image_delete(j2)

            if w > s[0] or h > s[1]:
                t = w, h = Form.calc_lock(s, t)
                j3 = pdb.gimp_edit_paste_as_new_image()
                Form.shape(j3, w, h)
            j.mold.size = t

        if is_copy:
            self._calc_rect_position(d, j, format_x)
        return is_copy

    def _mold_rect(self, j, d, format_x):
        """
        Draw an image rectangle for a layout
        that corresponds with the format.

        j: RollerImage
            with image place information

        d: dict
            with format

        format_x: int
            index
            corresponding with session's format list
        """
        s = j.size
        t = j.pocket.size
        n = Form.get_resize_type(d, j.r, j.c)

        if n == ff.Place.FILL_CELL:
            s1 = t

        elif n == ff.Place.LOCKED:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = Form.calc_lock(t, s)

            else:
                s1 = s

        elif n == ff.Place.TRIM:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = Form.get_trim_size(s, t)
                if s1[1] > t[1]:
                    s1[1] = t[1]

                else:
                    s1[0] = t[0]

            else:
                s1 = s

        else:
            # numerically resized:
            s1 = Form.get_numeric_size(j, n)

        j.mold.size = s1

        # The size is invalid if it is None or has a zero for w, h:
        if s1 and s1[0] and s[1]:
            self._calc_rect_position(d, j, format_x)
            Sel.rect(self.stat.render.image, j.mold.x, j.mold.y, *s1)

    def _rotate_image_rect(self, j, d, format_x):
        """
        Rotate an image rectangle.

        j: RollerImage
            with cell info

        d: dict
            of format

        format_x: int
            index
            corresponding with session's format list

        Return: state of image
            selection of rotated layer
        """
        render = self.stat.render.image

        # Create a new image with the selection:
        z = Lay.add(
            render,
            j.image_name,
            parent=self.format_group
        )

        Sel.fill(z, ForLayout.IMAGE_COLOR)
        pdb.gimp_edit_copy(z)
        Lay.clear_sel(render, z)

        s = j.pocket.size
        j2 = pdb.gimp_edit_paste_as_new_image()
        z1 = Lay.rotate(j2, j.rotate)

        j.mold.size = z1.width, z1.height

        if j.mold.width > s[0] or j.mold.height > s[1]:
            # The image won't fit into the cell so get the size that will:
            w, h = j.mold.size = Form.calc_lock(s, j.mold.size)
            z1 = pdb.gimp_item_transform_scale(z1, 0, 0, w, h)

        pdb.gimp_edit_copy(z1)
        pdb.gimp_image_delete(j2)

        z4 = Lay.paste(render, z)
        z4.name = Lay.get_layer_name("Rotated " + j.image_name)

        pdb.gimp_image_remove_layer(render, z)
        self._calc_rect_position(d, j, format_x)
        pdb.gimp_layer_set_offsets(z4, j.mold.x, j.mold.y)
        Sel.item(render, z4)
        pdb.gimp_image_remove_layer(render, z4)

    def _validate_file_reference(self, n, *_, **d):
        """
        Validate a file path.

        n: string
            file path

        Return: string or None
            file path
        """
        return n if n and os.path.isfile(n) else None

    def _validate_image_name(self, n, *_, **d):
        """
        Validate an image reference from opened Roller images.

        n: string
            image name

        Return: string or None
            image reference
        """
        d = RollerImage.roller_image
        return n if n in d else None

    def calc_block(self, d, format_x, start, end):
        """
        Recalculate the pocket sizes for a block of cells.

        d: dict
            of format

        format_x: int
            index
            corresponding with session's format list

        start, end: tuple
            of int
            size
            w, h
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self._deck.calc_pocket(format_x, r, c, d)

    def calc_cell_table(self, session):
        """
        Calculate cell sizes.

        Correct cell size underflow and overflow.

        session: dict
            of session
        """
        format_list = session[sk.FORMAT_LIST]
        self._next_index = 0
        self._fluctuate_index = -1
        self._previous_index = RollerImage.image_count - 1
        self._deck = GridDeck(self.stat, session)

        # Initialize image references:
        for format_x, d in enumerate(format_list):
            RollerImage.init_file_list()
            double_space = Form.is_double_space(d)
            r, c = self._deck.get_division(format_x)
            for i in range(r):
                for j in range(c):
                    m = 1

                    if double_space:
                        m = Form.is_double_space_cell(i, j, double_space)
                    if m:
                        # Topleft cells have images:
                        is_topleft = True

                        if Form.is_merge_cells(d):
                            # 's' size of cell in cell-count:
                            s = d[fk.Cell.Grid.PER_CELL][i][j]
                            if s == (-1, -1):
                                is_topleft = False
                                n = None

                        if is_topleft:
                            n = self._get_image_reference(
                                format_x,
                                i,
                                j,
                                d
                            )
                        self._deck.set_image(format_x, i, j, n)

    def get_cell_block_size(self, d, format_x, r, c):
        """
        Calculate the cell block size.

        d: dict
            of format

        format_x: int
            index to format in format list

        r, c: int
            row, column
            cell indices
        """
        s = 1, 1

        if d[fk.Cell.Grid.PER_CELL]:
            # 's' size of the cell in cells:
            s = d[fk.Cell.Grid.PER_CELL][r][c]

        # Sub-topleft cells are unavailable:
        if s == (-1, -1):
            w = h = 0

        else:
            s = r + s[0] - 1, c + s[1] - 1
            _, _, w, h = self._deck.calc_cell_block(format_x, (r, c), s)
        return w, h

    def get_cell_margin(self, format_x, r, c, d, size=None):
        """
        Return the image margins for a cell at r, c as
        (top, bottom, left, right) of int.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        d: dict
            format dict

        size: tuple
            w, h
            of cell

        Return: tuple
            top, bottom, left, right
            of int
        """
        if not size:
            size = self._deck.get_merge_cell_size(format_x, r, c)

        if not d[fk.Cell.Margin.PER_CELL]:
            q = d[fk.Cell.MARGIN]

        else:
            q = d[fk.Cell.Margin.PER_CELL][r][c]
        return Form.combine_margin(q, *size)

    def get_division(self, format_x):
        """
        Get the row and column span of a cell grid.

        format_x: int
            index for format list

        Return: tuple
            row, column
            of int
            size of cell grid
        """
        return self._deck.get_division(format_x)

    def get_image(self, n, d, format_x):
        """
        Get an opened image reference.

        n: string
            name of image

        d: dict
            format dict

        Return: string
            opened image or None
        """
        _file = folder = -1

        if isinstance(n, tuple):
            # Match the folder path and filter:
            folder = n

        elif n and os.path.isfile(n):
            # Match the file path:
            _file = n

        for x, q in enumerate(
            (
                ff.Image.NEXT_TYPE,
                ff.Image.PREVIOUS_TYPE,
                ff.Image.FLUCTUATE_TYPE,
                RollerImage.relative_names,
                RollerImage.image_names,
                [_file],
                [folder],
            )
        ):
            if q and n in q:
                break

        else:
            x += 1

        return (
            self._get_next_image,
            self._get_previous_image,
            self._get_fluctuate_image,
            self._get_relative_name_reference,
            self._validate_image_name,
            self._validate_file_reference,
            self._get_folder_file_reference,
            lambda *args, **kwargs: None
        )[x](n, d, format_x)

    def get_image_name_from_cell(self, format_x, r, c, j=None):
        """
        Get the image name from a cell or a RollerImage.

        format_x: int
            format index in session's format list

        r, c: int
            cell table index

        Return: string or None
            image reference
        """
        if r != ForLayout.FREE_CELL:
            return self._deck.get_image_name(format_x, r, c)

        # free-range cell:
        if j:
            return j.image_name

    def get_merge_cell_rect(self, format_x, r, c):
        """
        Return a 'cell' Rect object.

        format_x: int
            index in session's format list

        r, c: int
            cell index
            Has a 'cell' rectangle.

        Return: Rect
            merged-cell before margins
        """
        return self._deck.get_merge_cell_rect(format_x, r, c)

    def get_mold_from_cell(self, format_x, r, c):
        """
        Get the 'mold' Rect object f    or a cell.

        format_x: int
            index in session's format list

        r, c: int
            cell index

        Return: Rect
            of mold
            Is an image place rectangle.
        """
        return self._deck.get_mold(format_x, r, c)

    def get_roller_image(self, session, format_x, r, c, j=None):
        """
        Get the image name from a cell, then get the image.

        session: dict
            of session

        format_x: int
            index to format in session's format list

        r, c: int
            cell index

        j: RollerImage
            Has cell data.

        Return: RollerImage
            or None
        """
        return RollerImage.get_image(
            session,
            self.get_image_name_from_cell(format_x, r, c, j=j)
        )

    def get_plaque(self, format_x, r, c, j=None):
        """
        Get a 'plaque' value.

        d: dict
            of format

        format_x: int
            index in session's format list

        r, c: int
            cell index
            Has 'plaque' item.
        """
        if r != ForLayout.FREE_CELL:
            return self._deck.get_plaque(format_x, r, c)

        # free-range cell:
        return j.plaque

    def get_pocket_rect(self, format_x, r, c):
        """
        Get a cell's pocket rectangle for a cell.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        Return: Rect
            of pocket
        """
        return self._deck.get_pocket(format_x, r, c)

    def init_format_references(self):
        """
        Initialize variables when rendering a format.

        Format variables need to be reset per format.
        """
        self.image_group = self.blur_behind_layer = None

    def place_image(self, j, d, format_x, parent):
        """
        Copy and paste images on or above the image layer.

        j: RollerImage
            with GIMP image reference
            Has row and column position.

        d: dict
            of format or free cell

        format_x: int
            index
            corresponding with session's format list

        parent: layer
            group for image layer group

        return: layer
            with image
            Is None when there is no image.
        """
        # The RollerImage's image will enter the copy and paste buffer:
        is_copy = self._mold_image(j, d, format_x)
        if is_copy:
            render = self.stat.render.image
            if not self.image_group:
                self.image_group = Lay.group(
                    render,
                    LayerKey.IMAGE,
                    parent=parent
                )
                Lay.add(render, "Paste Target", self.image_group)

            z = Lay.paste(render, self.image_group.layers[-1])
            z.opacity = Form.get_prop_opacity(d, j.r, j.c)

            Lay.order(render, z, self.image_group)

            if Form.get_flip_h(j, d):
                Lay.flip(z, horizontal=1)

            if Form.get_flip_v(j, d):
                z = Lay.flip(z)

            pdb.gimp_layer_set_offsets(z, j.mold.x, j.mold.y)

            if not Form.is_rectangle_shape(d):
                Form.apply_shape_mask(render, j, z)

            if j.free:
                RollerImage.close_image(j)
            return z

    def show(self, session):
        """
        Draw the layout.

        session: dict
            of session
        """
        self.stat.render.on_new_layout()

        stat = self.stat
        q = session[sk.FORMAT_LIST]
        start = len(q) - 1
        z = stat.render.layout_group

        if start > -1:
            # Draw format layouts:
            for x in range(start, -1, -1):
                d = q[x]
                if d[fk.Layer.SHOW_IN_LAYOUT]:
                    n = d[fk.Layer.NAME]
                    z1 = self.format_group = Lay.group(
                        stat.render.image,
                        Lay.get_layer_name("Layout Group: " + n)
                    )

                    Lay.order(stat.render.image, z1, z)

                    z2 = self._active_layer = Lay.add(
                        stat.render.image,
                        Lay.get_layer_name("Layout: " + n),
                        parent=z1
                    )
                    z2.opacity = 66.
                    self._draw_format(session, d, x, z1)

        pdb.gimp_image_set_active_layer(stat.render.image, z)
        pdb.gimp_selection_none(self.stat.render.image)
        pdb.gimp_displays_flush()
