#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import Rect
from roller_grid_cell import GridCell
from roller_grid_circle import GridCircle
from roller_grid_diamond import GridDiamond
from roller_grid_ellipse import GridEllipsis
from roller_grid_hexagon import GridHexagon
from roller_grid_rect import GridRect
from roller_grid_triangle import GridTriangle
from roller_one import One
from roller_one_base import Base
from roller_one_constant import (
    ForFormat as ff,
    FormatKey as fk,
    ForTriangle as ft,
    SessionKey as sk
)

GRID = fk.Cell.Grid
MARGIN = ff.Margin.Index
a = SHAPE = ff.Cell.Shape
SHAPES = {
    a.CIRCLE_HORIZONTAL: GridCircle,
    a.CIRCLE_VERTICAL: GridCircle,
    a.DIAMOND: GridDiamond,
    a.ELLIPSE_HORIZONTAL: GridEllipsis,
    a.ELLIPSE_VERTICAL: GridEllipsis,
    a.HEXAGON_HORIZONTAL: GridHexagon,
    a.HEXAGON_VERTICAL: GridHexagon,
    a.RECTANGLE: GridRect,
    a.RHOMBUS: GridDiamond,
    a.SQUARE: GridRect,
    ft.TRIANGLE_DOWN: GridTriangle,
    ft.TRIANGLE_UP: GridTriangle,
    ft.TRIANGLE_LEFT: GridTriangle,
    ft.TRIANGLE_RIGHT: GridTriangle
}


class GridDeck:
    """
    Calculate the coordinates and the size
    of cells for the current format list.
    """

    def __init__(self, stat, session):
        """
        Create the a 3D table for the cells:
        [format][row][column]

        stat: Stat
            globals

        session: dict
            of session
        """
        self.stat = stat
        self._table = []
        size = session['size']
        self._division = []

        for format_x, d in enumerate(session[sk.FORMAT_LIST]):
            grid = One(with_shape=True)

            is_per_cell = False
            r, c = grid.r, grid.c = GridDeck.calc_grid_division(d, size)
            table = grid.table = Base.create_2d_table(r, c)
            shape = d[GRID.CELL_GRID][GRID.SHAPE]

            self._table.append(table)
            self._division.append(One(r=r, c=c))

            # Calculate layer size:
            top, bottom, left, right = Form.combine_margin(
                d[fk.Layer.MARGIN],
                size[0],
                size[1]
            )
            grid.layer_space = (
                Base.seal(size[0] - left - right, 1, size[0]),
                Base.seal(size[1] - top - bottom, 1, size[1])
            )
            grid.offset = left, top

            # Transfer the cell grid dict to grid:
            for k in d[GRID.CELL_GRID]:
                setattr(grid, k, d[GRID.CELL_GRID][k])

            if d[fk.Cell.Margin.PER_CELL]:
                grid.with_shape = False
                is_per_cell = True

            elif any(d[fk.Cell.MARGIN]):
                grid.with_shape = False

            double_space = grid.double_space = Form.is_double_space(d)

            for i in range(r):
                for j in range(c):
                    m = 1

                    if double_space:
                        m = Form.is_double_space_cell(i, j, double_space)
                    if m:
                        table[i][j] = GridCell(i, j)

            shaper = SHAPES[shape](grid)

            for i in range(r):
                for j in range(c):
                    m = 1

                    if double_space:
                        m = Form.is_double_space_cell(i, j, double_space)
                    if m:
                        self.calc_pocket(format_x, i, j, d)
            if not grid.with_shape:
                if is_per_cell:
                    shaper.calc_shape_per_cell(d)

                else:
                    shaper.calc_shape_with_pocket()

    def _get_cell_rect(self, format_x, r, c):
        """
        Get a cell's rectangle.

        format_x: int
            index to the format in the session's format list

        r, c: int
            cell index

        Return: Rect
            of cell
        """
        return self._table[format_x][r][c].cell.clone

    def calc_cell_block(self, format_x, u, v):
        """
        Use when cells are merged, and the merge
        cell's dimension needs to be determined.

        format_x: int
            index to format list in session's format list

        u: (r, c) of int
            topleft cell

        v: (r, c) of int
            bottom-right cell

        Return the topleft coordinates and the scale of an array of cells.
        """
        r1, c1 = u
        x, y = self._get_cell_rect(format_x, r1, c1).position
        rect = self._get_cell_rect(format_x, v[0], v[1])
        x1, y1 = rect.position
        w, h = rect.size
        w = x1 - x + w
        h = y1 - y + h
        return x, y, w, h

    @staticmethod
    def calc_grid_division(d, size):
        """
        Determine the row and column count for the format.

        d: dict
            of format

        size: tuple
            render size
            w, h

        Return: tuple
            of int
            row, column
            cell index
        """
        e = d[GRID.CELL_GRID]

        if e[GRID.TYPE] == ff.Grid.Index.CELL_COUNT:
            r, c = (
                min(e[GRID.ROW], size[1]),
                min(e[GRID.COLUMN], size[0])
            )

        elif e[GRID.TYPE] == ff.Grid.Index.SHAPE_COUNT:
            r, c = (
                min(e[GRID.VERTICAL], size[1]),
                min(e[GRID.HORIZONTAL], size[0])
            )

        else:
            # cell size:
            top, bottom, left, right = Form.combine_margin(
                d[fk.Layer.MARGIN],
                size[0],
                size[1]
            )
            w = size[0] - left - right
            h = size[1] - top - bottom
            width, height = e[GRID.COLUMN_WIDTH], e[GRID.ROW_HEIGHT]

            # rectangle:
            r, c = max(h // height, 1), max(w // width, 1)

            # hexagon, ellipse, diamond, and triangle:
            if not Form.is_rectangle_shape(d):
                n = e[GRID.SHAPE]

                if n in SHAPE.HORIZONTAL_ALIGNED:
                    w1, h1 = width * .5, height * .75
                    w2, h2 = w - width * .5, h - height * .25
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)

                elif n in SHAPE.VERTICAL_ALIGNED:
                    w1, h1 = width * .75, height * .5
                    w2, h2 = w - width * .25, h - height * .5
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)

                elif n in ft.VERTICAL_TRIANGLE:
                    w1 = width * .5
                    w2 = w - w1
                    r, c = max(int(h / height), 1), max(int(w2 / w1), 1)

                elif n in ft.HORIZONTAL_TRIANGLE:
                    h1 = height * .5
                    h2 = h - h1
                    r, c = max(int(h2 / h1), 1), max(int(w / width), 1)

                elif n == SHAPE.DIAMOND:
                    w1, h1 = width * .5, height * .5
                    w2, h2 = w - width * .5, h - height * .5
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)
        return r, c

    def calc_pocket(self, format_x, r, c, d):
        """
        Calculate the pocket rectangle for a cell.

        Calculate the merge cell rectangle for a cell.

        A pocket is a cell rectangle with margins reducing its size.

        format_x: int
            index
            corresponding to format list index in session

        r, c: int
            row, column
            cell index

        d: dict
            Has format.
        """
        # If merging cells:
        if Form.is_merge_cells(d):
            # 's' size of the cell in cells:
            s = d[fk.Cell.Grid.PER_CELL][r][c]

            # Sub-topleft cells are unavailable:
            if s == (-1, -1):
                x = y = w = h = 0

            else:
                s = r + s[0] - 1, c + s[1] - 1
                x, y, w, h = self.calc_cell_block(format_x, (r, c), s)
                x1 = x + w
                y1 = y + h
                self._table[format_x][r][c].plaque = x, y, x1, y, x1, y1, x, y1

        else:
            rect = self._table[format_x][r][c].cell
            x, y = rect.position
            w, h = rect.size

        self._table[format_x][r][c].merge_cell = Rect((x, y), (w, h))

        if w:
            q = self.stat.layout.get_cell_margin(
                format_x,
                r,
                c,
                d,
                size=(w, h)
            )
            if any(q):
                size = self.stat.render.size
                x += q[MARGIN.LEFT]
                y += q[MARGIN.TOP]
                x = Base.seal(x, 0, size[0] - 1)
                y = Base.seal(y, 0, size[1] - 1)
                w = max(w - q[MARGIN.LEFT] - q[MARGIN.RIGHT], 1)
                h = max(h - q[MARGIN.TOP] - q[MARGIN.BOTTOM], 1)
        self._table[format_x][r][c].pocket = Rect((x, y), (w, h))

    def get_cell_position(self, format_x, r, c):
        """
        Get a cell's position.

        format_x: int
            index to the format in the session's format list

        r, c: int
            cell index

        Return: tuple
            position of cell
            x, y
        """
        return self._table[format_x][r][c].cell.position

    def get_cell_size(self, format_x, r, c):
        """
        Get a cell's size.

        format_x: int
            index to the format in the session's format list

        r, c: int
            cell index

        Return: tuple
            size of cell
            width, height
        """
        return self._table[format_x][r][c].cell.size

    def get_division(self, format_x):
        """
        Get the row and column scale of a format's cell table.

        format_x: int
            index to the format in the session's format list

        Return: tuple
            row total, column total
            span of table in row and column count
        """
        return self._division[format_x].r, self._division[format_x].c

    def get_image_name(self, format_x, r, c):
        """
        Return: string
            GIMP image reference

        format_x: int
            index to the format in the session's format list

        r, c: int
            cell index
        """
        return self._table[format_x][r][c].image

    def get_merge_cell_rect(self, format_x, r, c):
        """
        Get a cell's size in the context of possible merged cells.

        format_x: int
            index to the format in the session's format list

        r, c: int
            cell index

        Return: tuple
            of cell
            x, y, w, h
        """
        return self._table[format_x][r][c].merge_cell.clone

    def get_merge_cell_size(self, format_x, r, c):
        """
        format_x: int
            index to the format in the session's format list

        r, c: int
            cell index

        Return: tuple
            size of merged cell
            w, h
        """
        return self._table[format_x][r][c].merge_cell.size

    def get_mold(self, format_x, r, c):
        """
        Return: Rect
            of mold
            the rectangle of the image place

        format_x: int
            index to the format in the session's format list

        r, c: int
            cell index
        """
        return self._table[format_x][r][c].mold.clone

    def get_plaque(self, format_x, r, c):
        """
        Get the cell plaque.

        format_x: int
            index to the format in the session's format list

        r, c: int
            cell index

        Return: object
            of plaque
            Is the cell shape before margins.
        """
        return self._table[format_x][r][c].plaque

    def get_pocket(self, format_x, r, c):
        """
        Get the cell pocket.

        format_x: int
            index to the format in the session's format list

        r, c: int
            cell index

        Return: Rect
            of mold
            the rectangle of the cell with margins
        """
        return self._table[format_x][r][c].pocket.clone

    def get_shape(self, format_x, r, c):
        """
        Get the shape tuple or dict.

        Ellipse shapes are in a dictionary. The
        other shapes are in a list or a tuple.

        format_x: int
            index to the format in session's format list

        r, c: int
            cell index

        Return: object
            of shape
        """
        return self._table[format_x][r][c].shape

    def set_image(self, format_x, r, c, name):
        """
        Set the GIMP image reference.

        format_x: int
            index to the format in session's format list

        r, c: int
            cell index

        name: string
            an image reference
        """
        self._table[format_x][r][c].image = name

    def set_mold(self, format_x, r, c, position, size):
        """
        Set the mold position. The 'mold' is the
        rectangle for an image place.

        format_x: int
            index to the format in session's format list

        r, c: int
            cell index

        position: tuple
            x, y
            screen coordinate
        """
        self._table[format_x][r][c].mold = Rect(position, size)
