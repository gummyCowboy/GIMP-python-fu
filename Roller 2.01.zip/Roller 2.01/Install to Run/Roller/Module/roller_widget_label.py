#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gtk
from roller_widget import Widget


class RollerLabel(Widget):
    """Is a custom GTK Label."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.Label(d['text'])
        d['align'] = d['align'] if 'align' in d else (0, 0, 0, 0)

        Widget.__init__(self, g, **d)
        self.add(g)

    def destroy(self):
        """Destroy the widget and sub-widgets."""
        self.label.destroy()
        self.destroy()

    def do_nothing(self, *_):
        return
