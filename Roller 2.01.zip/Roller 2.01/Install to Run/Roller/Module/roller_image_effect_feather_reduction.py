#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import ImageEffect
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay, Sel
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb
FEATHER = ek.FEATHER_REDUCTION


class FeatherReduction:
    """Feather the edges of the combined images on the image layer."""

    def __init__(self, one):
        """
        Do the Feather Reduction effect.

        one: One
            Has variables.
        """
        stat = one.stat
        j = stat.render.image
        z = stat.render.get_image_layer(
            Lay.get_format_name_from_group(one.parent)
        )
        z1 = Lay.clone(j, z)
        z1.name = Lay.get_layer_name(FEATHER, parent=one.parent)

        Lay.show(z1)
        if z1:
            b = one.d[ok.FEATHER]
            f = float(b) / one.d[ok.STEPS]
            a = int(f) - 1

            Sel.item(j, z1)
            Sel.invert(j)

            # work-around for a GIMP limitation
            # The image layer must have some transparency to work with feather:
            if not Sel.is_sel(j):
                Sel.item(j, z1)
                pdb.gimp_selection_shrink(j, 1)
                Sel.clear_outside_of_selection(j, z1)

            while a < b:
                Sel.item(j, z1)
                pdb.gimp_selection_feather(j, a)

                if Sel.is_sel(j):
                    Sel.clear_outside_of_selection(j, z1)

                else:
                    break
                a = min(int(a + f), b)
