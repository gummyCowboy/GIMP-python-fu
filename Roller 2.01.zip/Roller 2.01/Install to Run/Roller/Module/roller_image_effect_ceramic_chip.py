#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import seed
from roller_image_effect_border_line import BorderLine
from roller_image_effect import ImageEffect, LayerKey
from roller_one_constant import ForBackdropStyle, OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb
mosaic = Pdb.Mosaic


class CeramicChip(BorderLine):
    """Create a frame with colorful ceramic pieces."""

    def __init__(self, one):
        """
        Do the Ceramic Chip image-effect.

        one: One
            Has variables.
        """
        BorderLine.__init__(self, one, filler=self.do_job)

    def do_job(self, z, d):
        """
        Draw the ceramic chip.

        z: layer
            no use

        d: dict
            with options

        Return: layer
            the ceramic layer
        """
        # A random sequence is reproducible given the same seed:
        seed(d[ok.RANDOM_SEED])

        j = self.stat.render.image
        z = Lay.add(j, self.option_key, parent=self.parent)
        a = min(
            int(d[ok.MESH_SIZE] * 1.2), self.session['w'], self.session['h']
        )
        z = RenderHub.draw_color_rectangles(j, z, a, a)
        z.name = Lay.get_layer_name(LayerKey.FILLER, parent=self.parent)

        pdb.gimp_selection_all(j)
        pdb.plug_in_waves(j, z, 10, 1, 50, 0, 1)
        pdb.plug_in_mosaic(
            j,
            z,
            d[ok.MESH_SIZE],
            mosaic.TILE_HEIGHT_1,
            mosaic.TILE_SPACING_MIN,
            mosaic.TILE_NEATNESS_MIDDLE,
            mosaic.NO_SPLIT,
            d[ok.LIGHT_ANGLE],
            mosaic.MIN_COLOR_VARIATION,
            mosaic.YES_ANTIALIAS,
            mosaic.YES_COLOR_AVERAGING,
            ForBackdropStyle.MESH_TYPE.index(d[ok.MESH_TYPE]),
            mosaic.SMOOTH_SURFACE,
            mosaic.BLACK_AND_WHITE_GROUT
        )

        z = Lay.clone(j, z)
        z.opacity = 50.
        z.mode = fu.LAYER_MODE_LCH_COLOR

        pdb.plug_in_colorify(j, z, d[ok.COLOR])

        z = Lay.merge(j, z)

        Sel.isolate(j, z, self.fill_sel)
        return z
