#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, seed
from roller_grid import Grid
from roller_image_effect_border_line import BorderLine
from roller_image_effect import ImageEffect
from roller_one_constant import ForBackdropStyle as fbs, OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_line_graph import LineGraph
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb


class MazeMirror(BorderLine):
    """
    Add spiral mazes and connectors to a frame that fills around images.
    """

    def __init__(self, one):
        """
        Do the Maze Mirror image-effect.

        one: One
            Has variables.
        """
        BorderLine.__init__(self, one, framer=self.make_line_sel)

    def _do_border(self, row, column):
        """
        Draw border of mazes around the layer.

        row, column: int
            row and column count for placing a maze
            These counts are approximately half of the
            user-specified row and column count.
        """
        for r in range(row):
            self._draw_maze(r, 0)
        for c in range(column):
            self._draw_maze(0, c)

    def _do_fill(self, row, column):
        """
        Draw mazes that fill the frame layer.

        row, column: int
            row and column count for maze place
        """
        for r in range(row):
            for c in range(column):
                self._draw_maze(r, c)

    def _do_scattered_connectors(self, d, row, column):
        """
        Draw connectors randomly.

        d: dict
            Has options.

        row, column: int
            row and column count for maze place
        """
        connector = []

        if d[ok.GAP_TYPE] == fbs.RANDOM:
            # Try to get the connector to draw
            # so that it's not on the border:
            r1 = min(1, row - 1)
            c1 = min(1, column - 1)
            for _ in range(self.scatter_count):
                r = randint(r1, row - 1)
                c = randint(c1, column - 1)
                q = r, c

                while q in connector:
                    r = randint(1, row)
                    c = randint(1, column)
                    q = r, c
                connector.append(q)

        else:
            r = c = 0
            for _ in range(self.scatter_count):
                c += d[ok.CELL_GAP]
                while c > column - 1:
                    c -= max(1, column - 1)
                    r += 1

                while r > row - 1:
                    r -= max(1, row - 1)
                connector.append((r, c))
        for q in connector:
            r, c = q[0], q[1]
            if self.direction == fbs.COUNTER_CLOCKWISE:
                if r + 1 < row:
                    self.line_graph.add_line(
                        (r, c),
                        (r + 1, c),
                        LineGraph.real
                    )

            else:
                if c + 1 < column:
                    self.line_graph.add_line(
                        (r, c),
                        (r, c + 1),
                        LineGraph.real
                    )

    def _do_scattered_mazes(self, d, row, column):
        """
        Draw mazes randomly.

        d: dict
            Has options.

        row, column: int
            row and column count for maze place
        """
        maze = []

        if d[ok.GAP_TYPE] == fbs.RANDOM:
            for _ in range(self.scatter_count):
                r = randint(0, row - 1)
                c = randint(0, column - 1)
                q = r, c

                while q in maze:
                    r = randint(0, row - 1)
                    c = randint(0, column - 1)
                    q = r, c
                maze.append(q)

        else:
            r = c = 0
            for _ in range(self.scatter_count):
                c += d[ok.CELL_GAP]
                while c > column - 1:
                    c -= max(1, column - 1)
                    r += 1

                while r > row - 1:
                    r -= max(1, row - 1)
                maze.append((r, c))
        for q in maze:
            r, c = q[0], q[1]
            self._draw_maze(r, c)

            if self.direction == fbs.COUNTER_CLOCKWISE:
                self.line_graph.add_line(
                    (r, c),
                    (r + 1, c),
                    LineGraph.real
                )

            else:
                self.line_graph.add_line(
                    (r, c),
                    (r, c + 1),
                    LineGraph.real
                )

    def _draw_corners(self):
        """
        Flip the topleft-quarter selection into the other corners.
        """
        j = self.stat.render.image
        z = Lay.add(
            self.stat.render.image,
            self.option_key,
            parent=self.parent
        )
        w = self.session['w'] // 2 + self.session['w'] % 2
        h = self.session['h'] // 2 + self.session['h'] % 2

        Sel.fill(z, (0, 0, 0))
        pdb.gimp_selection_none(j)
        Sel.rect(self.stat.render.image, 0, 0, w, h)
        Sel.clear_outside_of_selection(j, z)

        z = Lay.clone(j, z)

        Lay.flip(z, horizontal=True)

        z = Lay.merge(j, z)
        z = Lay.clone(j, z)

        Lay.flip(z)

        z = Lay.merge(j, z)

        Sel.item(j, z)
        pdb.gimp_image_remove_layer(j, z)

    def _draw_clockwise_maze(self, r, c):
        """
        Draw a clockwise configured maze.

        r, c: int
            row, column
            maze position
        """
        line_length = [0, 0]
        x, y = self.grid[r][c].position
        line_length[0], line_length[1] = self.grid[r][c].size
        x1, y1 = x, y
        x2 = 0
        is_right = True
        is_up = is_left = is_down = False
        while line_length[x2] > self.stop_gap:
            if is_down:
                x2 = 1
                w = self.line_width
                h = line_length[x2]

                # next line:
                is_down = False
                is_left = True
                x1 = x
                y1 = y + line_length[x2] - self.line_width

            elif is_right:
                x2 = 0
                w = line_length[x2]
                h = self.line_width

                # next line:
                is_right = False
                is_down = True
                x1 = x + line_length[x2]
                y1 = y

            elif is_up:
                x2 = 1
                w = self.line_width
                h = line_length[x2]
                y = y - line_length[x2]

                # next line:
                is_up = False
                is_right = True
                x1 = x
                y1 = y

            elif is_left:
                x2 = 0
                w = line_length[x2]
                h = self.line_width
                x -= line_length[x2]

                # next line:
                is_left = False
                is_up = True
                x1 = x
                y1 = y

            Sel.rect(self.stat.render.image, x, y, w, h)

            # next line:
            line_length[x2] = int(line_length[x2] * .75)

            x, y = x1, y1
            x2 = int(not x2)
            line_length[x2] = int(line_length[x2] * .85)

    def _draw_counter_clockwise_maze(self, r, c):
        """
        Draw a counter-clockwise configured maze.

        r, c: int
            row, column
            maze position
        """
        line_length = [0, 0]
        x, y = self.grid[r][c].position
        line_length[0], line_length[1] = self.grid[r][c].size
        x1, y1 = x, y
        x2 = 1
        is_down = True
        is_up = is_left = is_right = False
        while line_length[x2] > self.stop_gap:
            if is_down:
                x2 = 1
                w = self.line_width
                h = line_length[x2]

                # next line:
                is_right = True
                is_down = False
                x1 = x
                y1 = y + line_length[x2]

            elif is_right:
                x2 = 0
                w = line_length[x2]
                h = self.line_width

                # next line:
                is_up = True
                is_right = False
                x1 = x + line_length[x2] - self.line_width
                y1 = y

            elif is_up:
                x2 = 1
                w = self.line_width
                h = line_length[x2]
                y = y - line_length[x2]

                # next line:
                is_up = False
                is_left = True
                x1 = x
                y1 = y

            elif is_left:
                x2 = 0
                w = line_length[x2]
                h = self.line_width
                x -= line_length[x2]

                # next line:
                is_left = False
                is_down = True
                x1 = x
                y1 = y

            Sel.rect(self.stat.render.image, x, y, w, h)

            # next line:
            line_length[x2] = int(line_length[x2] * .75)

            x, y = x1, y1
            x2 = int(not x2)
            line_length[x2] = int(line_length[x2] * .85)

    def _draw_maze(self, r, c):
        """
        Draw a maze.

        r, c: int
            row, column
            the maze cell position
        """
        if self.direction == fbs.COUNTER_CLOCKWISE:
            self._draw_counter_clockwise_maze(r, c)

        else:
            self._draw_clockwise_maze(r, c)

    def make_line_sel(self, d):
        """
        Add the maze selection to the border selection.

        d: dict
            Has options.

        Return: state of image
            selection state
        """
        j = self.stat.render.image
        sel = self.stat.save_selection()
        a = fbs.MAZE_TYPE
        row = d[ok.ROW] // 2 + d[ok.ROW] % 2
        column = d[ok.COLUMN] // 2 + d[ok.COLUMN] % 2
        self.grid = Grid(self.session['size'], d[ok.ROW], d[ok.COLUMN]).table
        self.line_width = d[ok.LINE_WIDTH]

        seed(d[ok.RANDOM_SEED])
        pdb.gimp_selection_none(j)

        if d[ok.COMPOSITION_FRAME_WIDTH]:
            pdb.gimp_selection_all(j)
            pdb.gimp_selection_shrink(j, d[ok.COMPOSITION_FRAME_WIDTH])
            Sel.invert(j)
            sel1 = self.stat.save_selection()

        else:
            sel1 = None

        self.stop_gap = d[ok.STOP_LENGTH]
        self.direction = d[ok.DIRECTION]
        self.scatter_count = min(d[ok.SCATTER_COUNT], row * column)

        if d[ok.MAZE_TYPE] in (a[0], a[1]):
            self.line_graph = LineGraph(
                self.stat.render.size,
                d[ok.ROW],
                d[ok.COLUMN],
                self.stat,
                self.line_width
            )

            if d[ok.MAZE_TYPE] == a[0]:
                self._do_scattered_connectors(d, row, column)

            elif d[ok.MAZE_TYPE] == a[1]:
                self._do_scattered_mazes(d, row, column)

            self.line_graph.add_line_to_disconnects()
            self.line_graph.draw_lines()

        elif d[ok.MAZE_TYPE] == a[2]:
            self._do_border(row, column)

        else:
            self._do_fill(row, column)

        self._draw_corners()
        Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
        if sel1:
            Sel.load(j, sel1, option=fu.CHANNEL_OP_ADD)
