#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import RollerImage
from roller_image_effect import ImageEffect, LayerKey
from roller_one import One
from roller_one_base import Comm
from roller_one_constant import (
    CellKey,
    ForFormat as ff,
    ForGradient as fg,
    FormatKey as fk,
    ForLayout,
    FreeCellKey as fck,
    FringeKey as frk,
    OptionKey as ok,
    PlaceKey,
    PlaqueKey,
    PropertyKey
)
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

ek = ImageEffect.Key
gf = Pdb.GradientFill
pdb = fu.pdb
pb = Pdb.PaintBrush
BOTTOM_LAYERS = LayerKey.LAYER_FRINGE, LayerKey.LAYER_PLAQUE
ABOVE = fk.Layer.PLACE_FREE_CELL_ABOVE
CELL_FRINGE_LAYERS = LayerKey.CELL_FRINGE, LayerKey.CELL_PLAQUE
FC = ForLayout.FRINGE_COLOR
FRINGE_MAT = ff.Fringe.GRADIENT, ff.Fringe.IMAGE, ff.Fringe.PATTERN
GRID = fk.Cell.Grid
HARDNESS = ff.Fringe.Index.HARDNESS
MASK = ff.Fringe.MASK
RECTANGLE = ff.Cell.Shape.RECTANGLE
REPLACE = fu.CHANNEL_OP_REPLACE
TYPE = ff.Fringe.Index.TYPE


class Fringe:
    """Manage fringe operation."""

    def __init__(self, session, d, format_x, stat, is_layout, parent):
        """
        Do fringe for one format.

        session: dict
            of session

        d: dict
            Has format.

        format_x: int
            index
            corresponding with the session's format list

        stat: Stat
            globals

        is_layout: flag
            If it is true, the fringe is drawing for a layout.
        """
        self.session = session
        self._color = self._group = None
        self._format_x = format_x
        self._is_layout = is_layout
        self._form = d
        self.stat = stat
        self._parent = parent
        self._render = stat.render.image

        pdb.gimp_context_set_antialias(1)

        if d[fk.Layer.CELL_LIST]:
            if not d[ABOVE]:
                self._do_free_cell()

        self._do_cells()

        if not is_layout:
            self._do_layer()
        if d[fk.Layer.CELL_LIST]:
            if d[ABOVE]:
                self._do_free_cell()

    @staticmethod
    def _brush(z, q):
        """
        Perform a brush stroke.

        z: layer
            to receive brush

        q: tuple
            x, y
            position of stroke
        """
        pdb.gimp_paintbrush(
            z,
            pb.NO_FADE_OUT,
            pb.STROKES_2,
            q,
            fu.PAINT_CONSTANT,
            pb.GRADIENT_LENGTH_0
        )

    def _brush_rectangle(self, z, angle, spacing):
        """
        Do brush for the rectangle shape.

        z: layer
            to receive paint material

        angle: float
            for brush

        spacing: float
            between brush applications
        """
        _, x, y, x1, y1 = pdb.gimp_selection_bounds(self._render)
        x_offset = int((x1 - x) % spacing / 2)
        y_offset = int((y1 - y) % spacing / 2)
        brush_x = x + x_offset

        pdb.gimp_selection_none(self._render)

        # top of cell:
        while brush_x <= x1:
            self._set_foreground_color()
            Fringe._brush(z, (brush_x, y))
            brush_x += spacing

        # right of cell:
        a = angle + 90

        if a > 180:
            a = angle - 90

        pdb.gimp_context_set_brush_angle(a)

        brush_y = y + y_offset

        while brush_y <= y1:
            self._set_foreground_color()
            Fringe._brush(z, (x1, brush_y))
            brush_y += spacing

        # bottom of cell:
        brush_x = x1 - x_offset
        a = angle + 180

        if a > 180:
            a = angle - 180

        pdb.gimp_context_set_brush_angle(a)

        while brush_x >= x:
            self._set_foreground_color()
            Fringe._brush(z, (brush_x, y1))
            brush_x -= spacing

        # left of cell:
        a = angle + 270

        while a > 180:
            a -= 360

        pdb.gimp_context_set_brush_angle(a)

        brush_y = y1 - y_offset
        while brush_y >= y:
            self._set_foreground_color()
            Fringe._brush(z, (x, brush_y))
            brush_y -= spacing

    def _do_cell(self, cell, fringe_name, plaque_name, item_name):
        """
        Process the fringe for a cell.

        cell: One
            Has cell values.

        fringe_name: string
            fringe layer name

        plaque_name: string
            fringe's plaque layer name

        item_name: string
            either a format or a cell z-list item
        """
        _type = cell.fringe[TYPE]
        is_paint = 1 if _type != MASK else 0

        if is_paint:
            z = Lay.add(
                self._render,
                fringe_name,
                parent=self._group
            )
            self._do_paint_fringe(z, cell, fringe_name)

        else:
            # fringe mask dependency:
            q1 = cell.plaque_data
            opacity = q1[ff.Plaque.Index.OPACITY]
            if opacity and _type != ok.NONE:
                self._do_mask_fringe(item_name, cell, plaque_name)

    def _do_cells(self):
        """Do the cell fringe for a format."""
        stat = self.stat
        d = self._form
        _x = self._format_x
        parent = self._parent
        cell_name = Lay.get_layer_name(LayerKey.CELL_FRINGE, parent=parent)
        merged = Form.is_merge_cells(d)
        self._fringe_type = LayerKey.CELL_FRINGE
        row, col = stat.layout.get_division(_x)
        double_space = Form.is_double_space(d)

        pdb.gimp_selection_none(self._render)

        for r in range(row):
            for c in range(col):
                has_fringe = 1

                if has_fringe:
                    # Check to see if the cell is a dependent:
                    if merged:
                        if d[fk.Cell.Grid.PER_CELL][r][c] == (-1, -1):
                            # Yup, it was a dependent:
                            has_fringe = 0

                if has_fringe:
                    if double_space:
                        has_fringe = Form.is_double_space_cell(
                            r,
                            c,
                            double_space
                        )

                if has_fringe:
                    shape = d[GRID.CELL_GRID][GRID.SHAPE]
                    cell = One(r=r, c=c, shape=shape)
                    rect = cell.cell = stat.layout.get_merge_cell_rect(
                        _x,
                        r,
                        c
                    )
                    cell.x, cell.y = rect.position
                    cell.w, cell.h = rect.size
                    q = cell.fringe = Form.get_cell_fringe(d, r, c)
                    has_fringe = q[TYPE] != ok.NONE

                if has_fringe:
                    has_fringe = 1 if q[ff.Fringe.Index.OPACITY] else 0

                if has_fringe and double_space:
                    if not Form.is_double_space_cell(r, c, double_space):
                        has_fringe = 0

                if has_fringe:
                    cell.plaque = stat.layout.get_plaque(_x, r, c)
                    cell.plaque_data = Form.get_cell_plaque(d, r, c)
                    if not self._group:
                        z = Lay.search(
                            parent,
                            LayerKey.CELL_PLAQUE,
                            is_err=0
                        )

                        if z:
                            offset = Lay.offset(z)

                        else:
                            offset = len(parent.layers)

                        self._group = Lay.group(
                            self._render,
                            cell_name,
                            parent,
                            offset
                        )
                    self._do_cell(
                        cell,
                        cell_name,
                        LayerKey.CELL_PLAQUE,
                        d[fk.Layer.NAME]
                    )
        if self._group:
            z = Lay.merge_group(self._render, self._group, n=cell_name)
            self._group = None
            if self._is_layout:
                z.opacity = 66.

    def _do_free_cell(self):
        """Do the free-range cell fringe."""
        stat = self.stat
        parent = self._parent
        d = self._form
        r = ForLayout.FREE_CELL
        free_cell_name = Lay.get_layer_name(
            LayerKey.FREE_CELL_FRINGE,
            parent=parent
        )

        j = self._render
        self._fringe_type = LayerKey.FREE_CELL_FRINGE

        for e in reversed(d[fk.Layer.CELL_LIST]):
            opacity = e[PropertyKey.IMAGE_PROPERTY][frk.OPACITY]
            _type = e[frk.CELL_FRINGE][frk.TYPE]
            if opacity and _type != ok.NONE:
                j1 = RollerImage.get_image(
                    self.session,
                    e[PlaceKey.IMAGE_PLACE][PlaceKey.IMAGE]
                )
                if not j1:
                    j1 = RollerImage(None, "")

                if j1:
                    Form.prep_free_cell_image(j1, e, stat.render.size)

                    cell = One(
                        r=r,
                        c=r,
                        plaque=j1.plaque,
                        shape=e[fck.CELL][CellKey.SHAPE]
                    )

                    cell.w, cell.h = j1.cell.size
                    cell.x, cell.y = j1.cell.position
                    cell.fringe = Form.get_cell_fringe(e, r, r)
                    cell.plaque_data = Form.get_cell_plaque(e, r, r)

                    if not self._group:
                        z = Lay.search(
                            parent,
                            LayerKey.FREE_CELL_PLAQUE,
                            is_err=0
                        )

                        if z:
                            a = Lay.offset(z)

                        else:
                            a = len(parent.layers)
                            for i in BOTTOM_LAYERS:
                                a -= int(
                                    Lay.search(
                                        parent,
                                        i,
                                        is_err=0
                                    ) is not None
                                )
                            if d[ABOVE]:
                                for i in CELL_FRINGE_LAYERS:
                                    a -= int(
                                        Lay.search(
                                            parent,
                                            i,
                                            is_err=0
                                        ) is not None
                                    )
                        self._group = Lay.group(
                            j,
                            free_cell_name,
                            parent,
                            a
                        )

                    layer_key = LayerKey.CELL_PLAQUE if self._is_layout else \
                        LayerKey.FREE_CELL_PLAQUE

                    self._do_cell(
                        cell,
                        free_cell_name,
                        layer_key,
                        e[fck.CELL][CellKey.NAME]
                    )
                    if j1.free:
                        RollerImage.close_image(j1)

        if self._group:
            z = Lay.merge_group(j, self._group, free_cell_name)
            self._group = None
            if self._is_layout:
                z.opacity = 66.

    def _do_fringe_context(self, z, cell):
        """
        Paint fringe.

        z: layer
            to receive paint

        cell: One
            Has cell data.
        """
        j = self._render
        q = cell.fringe
        sel = self.stat.save_selection()
        brush = q[ff.Fringe.Index.BRUSH]
        self._colors = None

        if brush not in self.stat.brush_list:
            Comm.info_msg(ff.MISSING_ITEM.format("self", "brush", brush))

        else:
            if self._is_layout:
                self._color = FC

            elif q[ff.Fringe.Index.TYPE] == ff.Fringe.TWO_COLOR:
                self._colors = (
                    q[ff.Fringe.Index.COLOR_1],
                    q[ff.Fringe.Index.COLOR_2]
                )
                callback = self._set_foreground_color

            else:
                self._color = q[ff.Fringe.Index.COLOR]

            if not self._colors:
                pdb.gimp_context_set_foreground(self._color)
                callback = None

            else:
                self._color = self._colors[0]

            brush_size = q[ff.Fringe.Index.BRUSH_SIZE]
            spacing = q[ff.Fringe.Index.SPACING]
            f = spacing / brush_size
            angle = q[ff.Fringe.Index.ANGLE]

            pdb.gimp_selection_shrink(j, q[ff.Fringe.Index.CONTRACT])
            if Sel.is_sel(j):
                pdb.gimp_context_set_dynamics('Dynamics Off')
                pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
                pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
                pdb.gimp_context_set_brush_aspect_ratio(0.)
                pdb.gimp_context_set_brush_force(1)
                pdb.gimp_context_set_antialias(1)
                pdb.gimp_context_set_brush_angle(angle)
                pdb.gimp_context_set_brush_spacing(f)
                pdb.gimp_context_set_brush_hardness(q[HARDNESS])
                pdb.gimp_context_set_brush(brush)
                pdb.gimp_context_set_brush_size(brush_size)
                pdb.gimp_context_set_opacity(q[ff.Fringe.Index.OPACITY])
                pdb.gimp_context_set_foreground(self._color)

                if cell.shape == RECTANGLE:
                    self._brush_rectangle(z, angle, spacing)

                else:
                    pdb.plug_in_sel2path(j, z)

                    stroke = j.active_vectors.strokes[0]

                    pdb.gimp_selection_none(j)
                    RenderHub.brush_stroke_on_stroke(
                        z,
                        brush,
                        brush_size,
                        stroke,
                        spacing,
                        callback=callback
                    )
                if q[ff.Fringe.Index.CLIP_TO_CELL]:
                    Sel.load(j, sel)
                    Sel.invert(j)
                    Lay.clear_sel(j, z)

    def _do_gradient_fringe(self, z, cell, name):
        """
        Make a gradient cell fringe.

        z: layer
            Has material to select.

        cell: One
            Has cell data.

        name: string
            layer name with fringe

        Return: layer
            Has gradient.
        """
        def draw_gradient(_start_x, _end_x, _start_y, _end_y):
            """
            Draw a gradient given a layer, a start-point and an end-point.
            """
            pdb.gimp_drawable_edit_gradient_fill(
                z1,
                fg.GRADIENT_TYPE_LIST.index(gradient_type),
                gf.OFFSET_0,
                gf.YES_SUPERSAMPLE,
                gf.SUPERSAMPLE_MAX_DEPTH_2,
                gf.SUPERSAMPLE_THRESHOLD_0,
                gf.YES_DITHER,
                _start_x,
                _start_y,
                _end_x,
                _end_y
            )

        j = self._render
        z1 = None
        gradient = cell.fringe[ff.Fringe.Index.GRADIENT]

        if gradient in self.stat.gradient_list:
            Sel.item(j, z)

            a, x, y, w, h = pdb.gimp_selection_bounds(j)
            if a:
                gradient_type = cell.fringe[ff.Fringe.Index.GRADIENT_TYPE]
                gradient_angle = cell.fringe[ff.Fringe.Index.GRADIENT_ANGLE]

                RenderHub.set_fill_context(fg.FILL_DICT)
                pdb.gimp_context_set_gradient(gradient)
                pdb.gimp_context_set_gradient_blend_color_space(
                    fu.GRADIENT_BLEND_RGB_PERCEPTUAL
                )
                pdb.gimp_context_set_gradient_reverse(0)

                if gradient_type in fg.SHAPE_BURST:
                    j1 = pdb.gimp_image_new(w, h, fu.RGB)
                    z1 = Lay.add(j1, 'temp')

                    pdb.gimp_selection_all(j1)
                    Sel.fill(z1, (127, 127, 127))
                    pdb.gimp_selection_none(j1)
                    draw_gradient(0, 0, 0, 0)
                    pdb.gimp_edit_copy_visible(j1)
                    pdb.gimp_image_delete(j1)

                    z1 = Lay.paste(j, z)
                    z1.name = name
                    pdb.gimp_layer_set_offsets(z1, x, y)

                else:
                    z1 = Lay.add(j, name, parent=self._group)

                    if gradient_angle in fg.CENTER_X:
                        end_x = start_x = (x + x + w) // 2

                    elif gradient_angle in fg.LEFT_X:
                        start_x = x
                        end_x = x + w

                    else:
                        start_x = x + w
                        end_x = x

                    if gradient_angle in fg.MIDDLE_Y:
                        end_y = start_y = (y + y + h) // 2

                    elif gradient_angle in fg.TOP_Y:
                        start_y = y
                        end_y = y + h

                    else:
                        start_y = y + h
                        end_y = y

                    Sel.rect(j, x, y, w, h, option=REPLACE)
                    draw_gradient(start_x, end_x, start_y, end_y)

        else:
            Comm.info_msg(
                ff.MISSING_ITEM.format("self", "gradient", gradient)
            )

        return z1

    def _do_image_fringe(self, z, cell):
        """
        Make a image cell fringe.

        z: layer
            Has fringe material.

        cell: One
            Has cell data.

        Return: layer
            Has image.
        """
        j = self._render
        z1 = None

        Sel.item(j, z)

        a, x, y, w, h = pdb.gimp_selection_bounds(j)

        if a:
            pdb.gimp_selection_none(j)

            image = cell.fringe[ff.Fringe.Index.IMAGE]
            j1 = RollerImage.get_image(self.session, image)

            if j1:
                j2 = j1.j

                pdb.gimp_selection_none(j2)
                pdb.gimp_edit_copy_visible(j2)

                j2 = pdb.gimp_edit_paste_as_new_image()

                Form.shape(j2, w, h)

                z1 = Lay.paste(j, z)

                pdb.gimp_layer_set_offsets(z1, x, y)
                if j1.free:
                    RollerImage.close_image(j1)
        return z1

    def _do_layer(self):
        """Do fringe for the layer."""
        d = self._form
        if d[frk.LAYER_FRINGE][frk.TYPE] != ok.NONE:
            j = self._render
            parent = self._parent
            cell = One(r=ForLayout.LAYER, c=ForLayout.LAYER, shape=RECTANGLE)
            size = self.session['size']

            if d[frk.LAYER_FRINGE][frk.OBEY_MARGINS]:
                cell.y, bottom, cell.x, right = Form.get_layer_margin(
                    d,
                    size
                )
                cell.w = size[0] - cell.x - right
                cell.h = size[1] - cell.y - bottom

            else:
                cell.x = cell.y = 0
                cell.w, cell.h = size

            w, h = cell.x + cell.w, cell.y + cell.h
            cell.plaque = cell.x, cell.y, w, cell.y, w, h, cell.x, h
            cell.plaque_data = Form.get_plaque_by_key(
                d[PlaqueKey.LAYER_PLAQUE]
            )
            self._fringe_type = LayerKey.LAYER_FRINGE
            layer_name = Lay.get_layer_name(
                LayerKey.LAYER_FRINGE,
                parent=parent
            )

            # Put the fringe on top of the layer plaque:
            z = Lay.search(j, LayerKey.LAYER_PLAQUE, is_err=0)
            a = Lay.offset(z) if z else len(parent.layers)
            b = Lay.offset(Lay.search(parent, LayerKey.IMAGE, is_err=0)) + 1
            a = max(a, b)
            self._group = Lay.group(j, layer_name, parent, a)
            q = cell.fringe = Form.get_fringe_by_key(d[frk.LAYER_FRINGE])
            is_paint = 1 if q[TYPE] != MASK else 0

            if is_paint:
                z = Lay.add(j, layer_name, parent=self._group)
                self._do_paint_fringe(z, cell, layer_name)

            else:
                # fringe mask dependency:
                q1 = Form.get_plaque_by_key(d[PlaqueKey.LAYER_PLAQUE])
                opacity = q1[ff.Plaque.Index.OPACITY]
                _type = q1[ff.Plaque.Index.TYPE]
                if opacity and _type != ok.NONE:
                    self._do_mask_fringe(
                        d[fk.Layer.NAME],
                        cell,
                        LayerKey.LAYER_PLAQUE
                    )

            z = Lay.merge_group(j, self._group, n=layer_name)
            self._group = None
            if self._is_layout:
                z.opacity = 66.

    def _do_mask_fringe(self, item_name, cell, plaque_name):
        """
        Mask the edge of a cell.

        item_name: string
            id of a format or free cell z-item

        cell: One
            Has cell data.

        plaque_name: string
            to find the fringe layer's plaque layer
        """
        stat = self.stat
        parent = self._parent
        j = self._render
        r, c = cell.r, cell.c
        plaque_data = cell.plaque_data
        opacity = plaque_data[ff.Plaque.Index.OPACITY]
        plaque_type = plaque_data[ff.Plaque.Index.TYPE]
        if opacity and plaque_type != ok.NONE:
            z = Lay.search(parent, plaque_name, is_err=0)
            if z:
                mask_layer = Lay.add(j, 'Mask', parent=parent)

                if self._is_layout:
                    x, y, w, h = Fringe._get_position_info(cell)

                    Sel.rect(
                        j,
                        x, y, w, h,
                        option=REPLACE
                    )
                    sel = stat.save_selection()

                else:
                    sel = stat.get_plaque_sel(item_name, r, c)
                    Sel.load(stat.render.image, sel)

                if Sel.is_sel(j):
                    self._do_fringe_context(mask_layer, cell)
                    Sel.item(j, mask_layer)

                    mask_sel = stat.save_selection()
                    Lay.clear_sel(j, z)

                else:
                    sel = None

                pdb.gimp_image_remove_layer(j, mask_layer)
                if not self._is_layout and sel:
                    Sel.load(j, sel)
                    Sel.load(j, mask_sel, fu.CHANNEL_OP_SUBTRACT)
                    stat.save_plaque_sel(item_name, r, c)

    def _do_paint_fringe(self, z, cell, name):
        """
        Paint a fringe texture on the cell fringe layer.

        z: layer
            for fringe material

        cell: One
            Has cell data.

        name: string
            layer name with fringe
        """
        j = self._render
        q = cell.fringe

        pdb.gimp_selection_none(j)

        if Form.is_rectangle_shape(self._form):
            x, y, w, h = Fringe._get_position_info(cell)
            Sel.rect(j, x, y, w, h)

        else:
            Form.select_shape(j, cell.plaque)

        if Sel.is_sel(j):
            self._do_fringe_context(z, cell)
            Sel.item(j, z)
            if Sel.is_sel(j):
                if q[TYPE] in FRINGE_MAT:
                    # Apply material and clear outside
                    # of fringe-layer-selection:
                    if q[TYPE] == ff.Fringe.GRADIENT:
                        z1 = self._do_gradient_fringe(z, cell, name)

                    elif q[TYPE] == ff.Fringe.IMAGE:
                        z1 = self._do_image_fringe(z, cell)

                    else:
                        z1 = self._do_pattern_fringe(z, cell, name)
                    if z1:
                        Sel.item(j, z)
                        Sel.clear_outside_of_selection(j, z1)
                        pdb.gimp_image_remove_layer(j, z)
                        z = z1
                if q[ff.Fringe.Index.SHADOW] != ok.NONE:
                    z.name = name
                    self._do_shadow(z, cell)
                z.name = name

    def _do_pattern_fringe(self, z, cell, name):
        """
        Make a pattern cell fringe.

        z: layer
            Has fringe material.

        cell: One
            Has cell data.

        name: string
            layer name with fringe

        Return: layer
            Has pattern.
        """
        j = self._render
        z1 = None
        pattern = cell.fringe[ff.Fringe.Index.PATTERN]

        if pattern in self.stat.pattern_list:
            if pattern in self.stat.pattern_list:
                Sel.item(j, z)

                a, x, y, w, h = pdb.gimp_selection_bounds(j)
                if a:
                    offset = Lay.offset(z)
                    z1 = Lay.add(
                        j,
                        name,
                        parent=self._group,
                        offset=offset
                    )

                    Sel.rect(j, x, y, w, h, option=REPLACE)
                    RenderHub.set_fill_context(fg.FILL_DICT)
                    pdb.gimp_context_set_pattern(pattern)
                    pdb.gimp_drawable_edit_bucket_fill(
                        z1,
                        fu.FILL_PATTERN,
                        min(self.stat.render.size[0] - 1, x + w // 2),
                        min(self.stat.render.size[1] - 1, y + h // 2)
                    )

        else:
            Comm.info_msg(ff.MISSING_ITEM.format("self", "pattern", pattern))
        return z1

    def _do_shadow(self, z, cell):
        """
        Draw shadow for material.

        z: layer
            with material

        cell: One
            Has cell data.
        """
        a = ff.Fringe.Index
        shadow = cell.fringe[a.SHADOW][ff.Shadow.Index.CHOICE]
        if shadow != ok.NONE and not self._is_layout:
            e = {'caster_key': (self._fringe_type,)}
            d = Form.get_shadow_dict(cell.fringe[a.SHADOW])

            if shadow == ff.Shadow.DROP_SHADOW:
                is_not_inlay = 1

            elif shadow == ff.Shadow.INLAY_SHADOW:
                e['is_inlay'] = True
                is_not_inlay = 0

            if d:
                Shadow(
                    One(
                        d=d,
                        e=e,
                        k='shadow',
                        stat=self.stat,
                        parent=z.parent
                    )
                )

                z1 = self._render.active_layer
                offset = Lay.offset(z)
                Lay.order(
                    self._render,
                    z1,
                    z.parent,
                    offset=offset + is_not_inlay
                )

    @staticmethod
    def _get_position_info(cell):
        """
        Return position info.

        cell: One
            Has cell data.
        """
        return cell.x, cell.y, cell.w, cell.h

    def _set_foreground_color(self):
        """
        Set the foreground color for the brush to use.

        Alternate colors if using two colors.
        """
        if self._colors:
            if len(self._colors) == 2:
                if self._colors[0] == self._color:
                    self._color = self._colors[1]

                else:
                    self._color = self._colors[0]
            pdb.gimp_context_set_foreground(self._color)
