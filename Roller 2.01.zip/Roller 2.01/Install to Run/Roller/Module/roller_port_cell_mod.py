#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_widget import FormatWidget
from roller_one_constant import (
    CaptionKey,
    ForColor,
    FormatKey as fk,
    ForWidget as fw,
    FringeKey,
    PlaqueKey,
    PortCellKey,
    UIKey,
    WidgetKey,
    WindowKey
)
from roller_one_tip import Tip
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_button import RollerButton
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_table import RollerTable
import gtk

ALIGN = 0, 0, 0, 0

# For GTK, let it know that the function handled an event:
DONE = 1

PAD = 0, 0, fw.MARGIN, fw.MARGIN


class PortCellMod(Port):
    """Draw the cell modification port for a single cell."""

    def __init__(self, d, r, c):
        """
        Start it up.

        d: dict
            of PortCell

        r, c: int
            cell index
            work-in-progress
        """
        self.row, self.column = r, c
        self.subtitle = d[UIKey.WINDOW_TITLE]
        self.key = d[WidgetKey.KEY]
        self._set_tool_tip = d[PortCellKey.SET_TOOLTIP]
        self.form, self._format_x = d[UIKey.FORMAT_DICT], d[UIKey.FORMAT_INDEX]
        self.table = d[PortCellKey.CELL_TABLE]
        self._rows, self._columns = d[PortCellKey.TABLE_SIZE]
        d[UIKey.WINDOW_KEY] = WindowKey.CELL_MOD

        self._cell_draw_dict = {
            fk.Cell.Caption.PER_CELL: self._draw_caption_cell,
            fk.Cell.Fringe.PER_CELL: self._draw_fringe_cell,
            fk.Cell.Image.Mask.PER_CELL: self._draw_image_mask_cell,
            fk.Cell.Image.Place.PER_CELL: self._draw_place_cell,
            fk.Cell.Image.Property.PER_CELL: self._draw_property_cell,
            fk.Cell.Margin.PER_CELL: self._draw_margin_cell,
            fk.Cell.Plaque.PER_CELL: self._draw_plaque_cell
        }

        Port.__init__(self, d)
        self._show_active_cell()

    def _apply_to_all(self, _):
        """
        Apply the widget values to all related cells.

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()
        self._get_values()

        for r in range(self._rows):
            for c in range(self._columns):
                self._set_changed_box(r, c)
        return self.do_accept_callback()

    def _apply_to_even(self, g):
        """
        Apply the widget values to the
        current cell and even-sequenced cells.

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()
        self._get_values()

        for r in range(self._rows):
            for c in range(self._columns):
                if (r + c) % 2:
                    self._set_changed_box(r, c)

        if not (self.row + self.column) % 2:
            self._set_changed_box(self.row, self.column)
        return self.do_accept_callback()

    def _apply_to_odd(self, _):
        """
        Apply the widget values to the
        current cell and odd-sequenced cells.

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()
        self._get_values()

        for r in range(self._rows):
            for c in range(self._columns):
                if not (r + c) % 2:
                    self._set_changed_box(r, c)

        if (self.row + self.column) % 2:
            self._set_changed_box(self.row, self.column)
        return self.do_accept_callback()

    def _apply_to_column(self, _):
        """
        Apply the widget values to the
        current cell table column.

        Return: true
            The key-press is handled.
        """
        c = self.column

        self._show_inactive_cell()
        self._get_values()

        for r in range(self._rows):
            self._set_changed_box(r, c)
        return self.do_accept_callback()

    def _apply_to_row(self, g):
        """
        Apply the widget values to the current cell table row.

        g: RollerButton
            not in use

        Return: true
            The key-press is handled.
        """
        r = self.row

        self._show_inactive_cell()
        self._get_values()

        for c in range(self._columns):
            self._set_changed_box(r, c)
        return self.do_accept_callback()

    def _do_east_cell(self, *_):
        """Move cell focus eastward."""
        self._save_data()
        self.east_button.set_tooltip_text("")

        for c in range(self.column + 1, self._columns):
            if self.table[self.row][c].has_pic:
                self.column = c
                break

            elif self.table[self.row][c].is_topleft:
                self.column = c
                break
        self._update_widgets()

    def _do_north_cell(self, *_):
        """Move cell focus upward."""
        self._save_data()
        self.north_button.widget.set_tooltip_text("")

        for r in range(self.row - 1, -1, -1):
            if self.table[r][self.column].has_pic:
                self.row = r
                break

            elif self.table[r][self.column].is_topleft:
                self.row = r
                break
        self._update_widgets()

    def _do_south_cell(self, *_):
        """Move cell focus downward."""
        self._save_data()
        self.south_button.set_tooltip_text("")

        for r in range(self.row + 1, self._rows):
            if self.table[r][self.column].has_pic:
                self.row = r
                break

            elif self.table[r][self.column].is_topleft:
                self.row = r
                break
        self._update_widgets()

    def _do_west_cell(self, *_):
        """Change the focus cell to the cell to the west."""
        self._save_data()
        self.west_button.set_tooltip_text("")

        for c in range(self.column - 1, -1, -1):
            if self.table[self.row][c].has_pic:
                self.column = c
                break

            elif self.table[self.row][c].is_topleft:
                self.column = c
                break
        self._update_widgets()

    def _draw_caption_cell(self, g):
        """
        Draw a cell's settings.

        Draw the widgets for the caption group.
        Is part of the PortCell template.

        g: Widget
            container

        Return: list
            a list of the widgets.
            The list is strict-ordered.
        """
        return FormatWidget.draw_caption_group(
            bottom_pad=fw.MARGIN,
            sub_type=CaptionKey.CELL_CAPTION,
            color=self.color,
            container=g,
            fraction_of="Cell",
            is_per_cell=True,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            get_size=self.get_size,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_cell_navigation_group(self, g):
        """
        Draw four horizontally oriented buttons
        that can navigate the cell table.

        g: container
            container for buttons
        """
        w = fw.MARGIN
        box = RollerEventBox(self.color)
        vbox = RollerBox(gtk.VBox, align=(0, 0, 0, 0))
        hbox = RollerBox(gtk.HButtonBox, align=(0, 0, 0, 0))

        vbox.pack_start(
            RollerLabel(
                padding=(2, 4, 4, 0),
                text="Cell Navigation:"
            )
        )
        vbox.pack_start(hbox, expand=False)
        box.add(vbox)
        g.pack_start(box, expand=False)
        hbox.set_padding(0, 0, w, w)

        self.north_button = RollerButton(
            on_widget_change=self._do_north_cell,
            text="↑"
        )
        self.south_button = RollerButton(
            on_widget_change=self._do_south_cell,
            text="↓"
        )
        self.west_button = RollerButton(
            on_widget_change=self._do_west_cell,
            text="←"
        )
        self.east_button = RollerButton(
            on_widget_change=self._do_east_cell,
            text="→"
        )
        for x, i in enumerate(
            (
                self.north_button,
                self.south_button,
                self.west_button,
                self.east_button
            )
        ):
            hbox.pack_start(i, expand=False)
            i.set_tooltip_text(Tip.NAVIGATION[x])

    def _draw_fringe_cell(self, g):
        """
        Draw a cell's settings.

        Draw the widgets for the fringe group.
        Is part of the PortCell template.

        g: Widget
            container

        Return: list
            of widget
            The list is strict-ordered.
            index-ordered
        """
        return FormatWidget.draw_fringe_group(
            bottom_pad=fw.MARGIN,
            sub_type=FringeKey.CELL_FRINGE,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_image_mask_cell(self, g):
        """
        Draw a cell's settings.

        Is part of the PortCell template.

        g: Widget
            container

        Return: list
            of widget
            index-ordered per the format dict
        """
        return FormatWidget.draw_mask_group(
            bottom_pad=fw.MARGIN,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_margin_cell(self, g):
        """
        Draw a cell's settings.

        Draw the ComboBoxes for Image Place.
        Is part of the PortCell template.

        g: Widget
            container

        Return: list
            of widget
            index-ordered
        """
        return FormatWidget.draw_margin_group(
            bottom_pad=fw.MARGIN,
            sub_type=fk.Cell,
            color=self.color,
            container=g,
            fraction_of="Cell",
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            get_size=self.get_size,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_place_cell(self, g):
        """
        Draw a cell's settings.

        Draw the ComboBoxes for Image Place.
        Is part of the PortCell template.

        g: Widget
            container

        Return: list
            of widget
            index-ordered per the format dict
        """
        return FormatWidget.draw_place_group(
            bottom_pad=fw.MARGIN,
            color=self.color,
            container=g,
            get_format_info=self.get_format_info,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_plaque_cell(self, g):
        """
        Draw a cell's settings.

        Is part of the PortCell template.

        g: Widget
            container

        Return: list
            of widget
            index-ordered per the format dict
        """
        return FormatWidget.draw_plaque_group(
            bottom_pad=fw.MARGIN,
            sub_type=PlaqueKey.CELL_PLAQUE,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_process_group(self):
        """
        Draw the process group buttons.

        Return: RollerEventBox
            contains group
        """
        w = fw.MARGIN
        q = []
        box = RollerEventBox(self.color)
        vbox = RollerBox(gtk.VBox, align=(0, 0, 1, 1))

        box.add(vbox)
        vbox.pack_start(
            RollerLabel(padding=(2, 0, 4, 0), text="Apply:"),
            expand=False
        )
        q.append(
            RollerButton(
                on_widget_change=self.do_cancel,
                padding=PAD,
                text="Cancel"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self._apply_to_row,
                padding=PAD,
                text="Row"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self._apply_to_column,
                padding=PAD,
                text="Column"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self._apply_to_all,
                padding=PAD,
                text="All Cells"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self._apply_to_even,
                padding=PAD,
                text="Cell & Even Cells"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self._apply_to_odd,
                padding=PAD,
                text="Cell & Odd Cells"
            )
        )
        q.append(
            RollerButton(
                on_widget_change=self.do_accept,
                padding=PAD,
                text="Cell"
            )
        )
        alignment = gtk.Alignment(0, 0, 0, 0)
        table = gtk.Table(len(q), 1)
        option_count = len(q)
        color = self.color

        self.keep(q)
        table.set_row_spacings(1)
        alignment.set_padding(w, w, w, w)

        for x, i in enumerate(q):
            color = RollerTable.get_darker_color(color, option_count)
            color1 = color, color, ForColor.MAX_COLOR
            box1 = RollerEventBox(color1)

            box1.add(i)
            table.attach(box1, 0, 1, x, x + 1)

        alignment.add(table)
        vbox.add(alignment)
        return box

    def _draw_property_cell(self, g):
        """
        Draw a cell's settings.

        Draw the widgets for image property.

        g: Widget
            container

        Return: list
            of widgets
            index-ordered per the format dict
        """
        return FormatWidget.draw_property_group(
            bottom_pad=fw.MARGIN,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=Port.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _get_values(self):
        """Get the values of the widgets for the target cell."""
        q = []
        q1 = self.widget_list[:-1] if self.preset else self.widget_list

        # The widget list order is corresponding with the cell table:
        for i in q1:
            q.append(i.get_value())

        if self.preset:
            self.values = tuple(q)

        else:
            # margins:
            self.values = q[0]

    def _process_control_arrow(self, n):
        """
        The user pressed control-arrow key.

        Change the widget values to the cell indicated by
        the arrow key. The target cell may not exist.

        n: string
            arrow key-press
        """
        r, c = self.row, self.column

        if n == "Down":
            if r + 1 != self._rows:
                m = 0

                for r1 in range(r + 1, self._rows):
                    if self.table[r1][c].has_pic:
                        m = 1
                        break

                    elif self.table[r1][c].is_topleft:
                        m = 1
                        break
                if m:
                    self._do_south_cell()

        elif n == "Up":
            if r != 0:
                m = 0

                for r1 in range(r - 1, -1, -1):
                    if self.table[r1][c].has_pic:
                        m = 1
                        break

                    elif self.table[r1][c].is_topleft:
                        m = 1
                        break
                if m:
                    self._do_north_cell()

        elif n == "Left":
            if c != 0:
                m = 0

                for c1 in range(c - 1, -1, -1):
                    if self.table[r][c1].has_pic:
                        m = 1
                        break

                    elif self.table[r][c1].is_topleft:
                        m = 1
                        break
                if m:
                    self._do_west_cell()

        elif n == "Right":
            if c + 1 != self._columns:
                m = 0

                for c1 in range(c + 1, self._columns):
                    if self.table[r][c1].has_pic:
                        m = 1
                        break

                    elif self.table[r][c1].is_topleft:
                        m = 1
                        break
                if m:
                    self._do_east_cell()

    def _save_data(self):
        """Save the current display values with the cell table."""
        self._show_inactive_cell()
        self._get_values()
        self._set_changed_box(self.row, self.column)

    def _set_button(self, m, g):
        """
        Set the button sensitivity based on a flag.

        m: flag
            If true, then enable widget.

        g: Widget
            button
        """
        if m:
            g.enable()

        else:
            g.disable()

    def _set_changed_box(self, r, c):
        """
        Set the format dict, the tooltip and the label color.

        r, c: int
            cell position
        """
        m = 0
        if self.table[r][c].has_pic:
            m = 1

        elif self.table[r][c].is_topleft:
            m = 1

        if m:
            self.form[self.key][r][c] = self.values
            box = self.table[r][c].box

            self._set_tool_tip(box, self.values)
            box.label.modify_fg(gtk.STATE_NORMAL, ForColor.WHITE)

    def _set_widget_values(self):
        """
        Set the values displayed in the widgets.

        Data is from the current cell at self.row and self.column.
        """
        q = self.form[self.key][self.row][self.column]

        if self.preset:
            for x, i in enumerate(q):
                self.widget_list[x].set_value(i)

        else:
            # margins:
            self.widget_list[0].set_value(q)

        self._show_active_cell()
        self.verify_nav_button()
        self.cell_label.widget.set_text(
            "Cell Data:\tRow: {}\tColumn: {}".format(
                self.row + 1,
                self.column + 1
            )
        )

    def _show_active_cell(self):
        """
        Change the text of the cell in the PortCell to show an edit-state.
        """
        self.table[self.row][self.column].box.label.set_text("☍")

    def _show_inactive_cell(self):
        """
        Change the text of the cell in the PortCell port back to normal.
        """
        r, c = self.row, self.column
        n = fw.IMAGE_SYMBOL if self.table[r][c].has_pic else fw.NO_IMAGE
        self.table[r][c].box.label.set_text(n)

    def _update_widgets(self):
        """Set widget values and verify dependencies."""
        self._set_widget_values()
        for i in self.widget_list:
            if hasattr(i, 'verify'):
                Port.on_widget_change(i)
                break

    def do_accept(self, *_):
        """
        Apply the widget values to the cell table.

        Return: true
            The key-press is handled.
        """
        self._save_data()
        return self.do_accept_callback()

    def do_cancel(self, *_):
        """
        Update the current cell's symbol to
        show that it's back to being inactive.

        Return: true
            The key-press is handled.
        """
        self._show_inactive_cell()
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        g: VBox
            container for widgets
        """
        self.preset = None
        r, c = self.row, self.column
        self.cell_label = RollerLabel(
            padding=(2, 0, 4, 0),
            text="Cell Data:\tRow: {}\tColumn: {}".format(r + 1, c + 1)
        )
        hbox = gtk.HBox()

        # cell data group:
        box = RollerEventBox(self.color)
        vbox = RollerBox(gtk.VBox, align=(0, 0, 1, 1))

        self.reduce_color()
        box.add(vbox)
        vbox.add(self.cell_label)

        p = self._cell_draw_dict[self.key]
        self.widget_list = p(vbox)

        if len(self.widget_list) > 1:
            self.preset = self.widget_list[-1]

        # navigation group:
        self.reduce_color()
        self._draw_cell_navigation_group(vbox)
        self.reduce_color()

        box1 = self._draw_process_group()

        self._set_widget_values()
        hbox.add(box)
        hbox.add(box1)
        g.add(hbox)
        self.roller_window.win.connect(
            'key_press_event',
            self.on_arrow_key_press
        )
        if self.preset:
            self.preset.refresh(fw.UNDEFINED)

    def get_format_info(self):
        """
        Use with place image button.

        Return: tuple
            format dict, format index
        """
        return self.form, self._format_x

    def get_size(self):
        """
        Use to update margin size label in PortMargin.

        Return: tuple
            width, height
            of int
            of cell
        """
        return self.stat.layout.get_cell_block_size(
            self.form,
            self._format_x,
            self.row,
            self.column
        )

    def on_arrow_key_press(self, _, event):
        """
        Check to see if the user pressed control key
        and an arrow key at the same time.

        event: key-press event
            looking for an arrow-key pressed event

        Return: None or true
            Is true if the key-press is handled.
        """
        n = gtk.gdk.keyval_name(event.keyval)
        control_pressed = (event.state & gtk.gdk.CONTROL_MASK)
        if control_pressed and n in ('Left', 'Right', 'Up', 'Down'):
            self._process_control_arrow(n)
            return DONE

    def verify_nav_button(self):
        """
        Verify the navigation button given the current cell.

        The cell indices, 'self.row' and
        'self.column', define the current cell.

        Scan the cell table for a cell with a picture.
        """
        r, c = self.row, self.column

        if r + 1 == self._rows:
            self.south_button.disable()

        else:
            m = 0

            for r1 in range(r + 1, self._rows):
                if self.table[r1][c].has_pic:
                    m = 1
                    break

                elif self.table[r1][c].is_topleft:
                    m = 1
                    break
            self._set_button(m, self.south_button)

        if r == 0:
            self.north_button.disable()

        else:
            m = 0

            for r1 in range(r - 1, -1, -1):
                if self.table[r1][c].has_pic:
                    m = 1
                    break

                elif self.table[r1][c].is_topleft:
                    m = 1
                    break
            self._set_button(m, self.north_button)

        if c + 1 == self._columns:
            self.east_button.disable()

        else:
            m = 0

            for c1 in range(c + 1, self._columns):
                if self.table[r][c1].has_pic:
                    m = 1
                    break

                elif self.table[r][c1].is_topleft:
                    m = 1
                    break
            self._set_button(m, self.east_button)

        if c == 0:
            self.west_button.disable()

        else:
            m = 0

            for c1 in range(c - 1, -1, -1):
                if self.table[r][c1].has_pic:
                    m = 1
                    break

                elif self.table[r][c1].is_topleft:
                    m = 1
                    break
            self._set_button(m, self.west_button)

    def verify_widgets(self):
        """Call widget verify functions."""
        q = self.widget_list[:-1] if self.preset else self.widget_list
        for i in q:
            if hasattr(i, 'verify'):
                i.verify(i)
                break
