#!/usr/bin/env python
# -*- coding: utf-8 -*-


class OptionGroup:
    """Has values used to manage a PortOption group."""

    def __init__(
        self,
        opt_type,
        opt_key,
        previous_option_group,
        navigation_list
    ):
        """
        Create an option group.

        Option group has option-related variables.

        previous_option_group: OptionGroup
            Use with render and by fill light shadow.

        navigation_list: NavigationList
            parent of option group's VBox
        """
        self.opt_key = opt_key
        self.opt_type = opt_type

        # If disabled, the widget group is ignored during a render:
        self.disabled = False

        # If changed, the group's preview is not
        # a valid representative of the render:
        self.changed = True

        # Has widgets that populate an option group.
        # The key is an option key. The value is a Widget:
        self.widget_dict = {}

        # Is preset widget for group:
        self.preset = None

        # Is the option group that preceded this one:
        self.previous_group = previous_option_group

        # The option group has a parent navigation list:
        self.navigation_list = navigation_list
