#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_one_constant import (
    ForColor,
    ForWidget as fw,
    MarginKey,
    UIKey
)
from roller_one_preset import Preset
from roller_one_tip import Tip
from roller_port import Port
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable
import gtk

COLUMN_0, COLUMN_1, COLUMN_2, COLUMN_3 = 0, 1, 2, 3
LIMIT = (0, 100000), (0., 1.)
MARGIN_LABEL = "Top: {}, Bottom: {}, Left: {}, Right: {}"
MARGIN_NAME = "Top", "Bottom", "Left", "Right"
PAD = 0, 0, fw.MARGIN, fw.MARGIN
PRECISION = 0, 6
TOTAL_ROW = 10
TYPES = "Fixed-Value {} Margins", "Fraction-of-{} Margins"


class PortMargin(Port):
    """Is a port with fixed and fraction-of margin widgets."""

    def __init__(self, d, g):
        """
        Start it up.

        d: dict
            Has init values.

        g: OptionButton
            Has option values.
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self.color = g.color
        self._option_data = g.get_value()
        self._button = g
        self._get_size = g.get_size if hasattr(g, 'get_size') else None
        self.margin_label = None
        Port.__init__(self, d)

    def _do_table_row(self, color, table, i, j):
        """
        Add eventboxes to a row in a table.

        The color is darkened prior to adding the boxes.

        color: int
            for red and green

        table: gtk.Table
            to receive eventboxes

        i, j: int
            row begin, row end

        Return: tuple
            three eventboxes and the new color (int)
        """
        color = RollerTable.get_darker_color(color, TOTAL_ROW)
        color1 = color, color, ForColor.MAX_COLOR
        box = RollerEventBox(color1)
        box1 = RollerEventBox(color1)
        box2 = RollerEventBox(color1)

        table.attach(box, COLUMN_0, COLUMN_1, i, j)
        table.attach(box1, COLUMN_1, COLUMN_2, i, j)
        table.attach(box2, COLUMN_2, COLUMN_3, i, j)
        return box, box1, box2, color

    def _draw_margins(self, g):
        """
        Draw widgets in a table.

        g: VBox
            container for widgets

        q: iterable
            of strings
            keys to widgets
        """
        w = fw.MARGIN
        p = self.on_widget_change
        alignment = gtk.Alignment(0, 0, 0, 0)
        table = gtk.Table(TOTAL_ROW, COLUMN_3)
        color = self.color
        margin_name = MARGIN_NAME * 2
        table.set_row_spacings(1)

        for i in range(TOTAL_ROW - 2):
            j = i + 1
            x = 0 if i < 4 else 1
            box, box1, box2, color = self._do_table_row(color, table, i, j)
            g1 = RollerLabel(text=margin_name[i] + ":", padding=PAD)
            g2 = RollerSlider(
                key=MarginKey.ORDER_LIST[i],
                limit=LIMIT[x],
                on_key_press=self.on_key_press,
                on_widget_change=p,
                precision=PRECISION[x]
            )

            if i == 0:
                table.attach(gtk.Label("\t" * 8), COLUMN_2, COLUMN_3, i, j)

            if i % 4 == 0:
                n = TYPES[x].format(self._button.fraction_of)
                box.add(RollerLabel(text=n, padding=PAD))

            self.controls.append(g2)
            box1.add(g1)
            box2.add(g2)

        if self._get_size:
            self.margin_label = RollerLabel(
                text=MARGIN_LABEL.format(0, 0, 0, 0),
                padding=PAD,
                align=(0, 0, .9, 0)
            )
            _, _, box2, color = self._do_table_row(color, table, i + 1, i + 2)
            box2.add(self.margin_label)

        box, box1, box2, _ = self._do_table_row(color, table, i + 2, i + 3)
        self.preset = Preset(
            container=box2,
            key=MarginKey.MARGINS,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            widget_list=self.controls,
            win=self.roller_window
        )
        box.add(RollerLabel(text="Margins Preset:", padding=PAD))

        # Make a dummy preset dictionary:
        d = {}

        for x, i in enumerate(self._option_data):
            d[MarginKey.ORDER_LIST[x]] = i

        self.preset.load_preset(fw.UNDEFINED, d)
        self.controls[0].set_tooltip_text(Tip.MARGIN)
        alignment.set_padding(w, w, w, w)
        alignment.add(table)
        g.add(alignment)
        self._update_margin_label()

    def _update_margin_label(self):
        """Update the margin label with the latest settings."""
        if self._get_size:
            q = []

            for i in self.controls:
                q.append(i.get_value())

            top, bottom, left, right = Form.combine_margin(
                q,
                *self._get_size()
            )

            self.margin_label.widget.set_text(
                MARGIN_LABEL.format(top, bottom, left, right)
            )
            self.margin_label.show()

    def do_accept(self, *_):
        """
        Accept the margins.

        Return: true
            The key-press is handled.
        """
        q = []

        for i in self.controls:
            q.append(i.get_value())
        return self.do_accept_callback(tuple(q))

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for widgets
        """
        q = self._draw_margins, self.draw_process_group
        group_name = "Set {}s".format(self._button.key), "Process"

        self.reduce_color()
        self.reduce_color()
        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if group_name[x]:
                vbox.pack_start(
                    RollerLabel(
                        text=group_name[x] + ":",
                        padding=(2, 0, 4, fw.MARGIN)
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()
            g.pack_start(box, expand=False)

    def on_widget_change(self, g):
        """
        Call when a widget is changed.

        g: Widget
            Has changed.
        """
        if not Port.loading:
            self._update_margin_label()
            if g.key != MarginKey.MARGINS:
                self.preset.preset_is_undefined()
