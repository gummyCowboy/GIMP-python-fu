#!/usr/bin/env python
# -*- coding: utf-8 -*-


class LayerNotFound(Exception):
    """
    An exception for when a layer isn't found by a Lay.search.

    The program is unstable or in a buggy state.
    """
    def __init__(self, n):
        """
        There was an error.

        Spit out the layer name for tracing purposes.

        n: layer name
        """
        self.value = "A layer was not found: " + n

    def __str__(self):
        """
        Return the string value of the error message.

        This an Exception template function.
        """
        return repr(self.value)
