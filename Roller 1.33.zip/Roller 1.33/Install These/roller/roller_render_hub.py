#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import (
        ForCell,
        ForEffect,
        LayerKey,
        OptionKey,
        SessionKey
    )

from copy import deepcopy
from random import randint as rnd
from random import choice, uniform
from roller_active import Active
from roller_fu import Lay, Sel
from roller_mode import Mode
from roller_layout import Img
from roller_option_limit import OptionLimitKey
from roller_ui_option import UIOption
import gimpfu as fu
import math


class RenderHub:
    """
    Use with Effect and BackdropStyle.

    Use a RenderHub class template to enable sub-class functionality:
        do: function
            Call when the sub-class is required to perform its function.

        width_low, width_high: integers
            Use when calculating a random-sized border width.
    """

    def __init__(self, d, stat, layer_key, active=None):
        """
        d: session dict
        stat: Stat
        layer_key: preview layer key
        active: layer
            the active layer
        """
        self.stat = stat
        self.layer_key = layer_key
        self.active = self.active_start = Active(stat, layer_key, clone=active)
        self.previewed = 0
        self.d = None

        # ‟self.with_offset” when true will move a
        # cloned format group below a layout group:
        self.has_offset = 0

        if layer_key == LayerKey.FORMAT and stat.has_layout:
            self.has_offset = 1

        if self.stat.auto == 1:
            self.pass_bounds(d)

        elif self.stat.auto == 2:
            self.stat.session[self.name] = self.rand(d)
            self.do(d)

        elif self.stat.auto == 3:
            self.do(d)

        else:
            UIOption(self, d, self.stat)
            if self.d:
                self.do(self.d)

    def calculate_gradient(self, color, color1, steps):
        """
        Returns the color-steps for a gradient.

        Each color component will have its own color-step.
        Color-steps are multiplied by a factor to get the final color.

        color, color1: RGB tuple
        steps: int
            the number of steps
        """
        delta = [0] * 3
        step = [0] * 3

        # Need color distance to calculate color step:
        if steps > 1:
            for x in range(3):
                delta[x] = abs(color[x] - color1[x]) / 1. / (steps - 1)

            # The color step can be positive or negative:
            for x in range(3):
                if color[x] > color1[x]:
                    step[x] = -delta[x]

                elif color[x] < color1[x]:
                    step[x] = delta[x]
        return step

    def do_rotated_layer(self, z, d, p):
        """
        Rotated layer creates an enlarged layer before processing.

        Use the callback to process the rotated layer.

        z: process layer
        d: sub-session dict
        p: callback

        Return the rotated layer.
        """
        ok = OptionKey
        d = deepcopy(d)
        z1 = z
        j = self.stat.render
        w, h = self.stat.width, self.stat.height

        if d[ok.ROTATE]:
            # Create a new image for the rotation:
            f = self.stat.radius * 2
            j = Img.new(f, f)
            z = Lay.add(j, "Rotate")

            Lay.activate(j, z)

            # Scale the points relative to the image's new scale:
            for k in (ok.START_X, ok.END_X):
                if k in d:
                    d[k] = int(d[k] * f / 1. / w)

            for k in (ok.START_Y, ok.END_Y):
                if k in d:
                    d[k] = int(d[k] * f / 1. / h)

        else:
            z = Lay.clone(self.stat.render, z)

        z = p(j, z, d)

        if d[ok.ROTATE]:
            z = Lay.clone(j, z)

            pdb.gimp_item_transform_rotate(
                z, math.radians(d[ok.ROTATE]), 1, 0, 0)

            Lay.hide(j.layers[1])

            # Copy / paste the rotated gradient:
            Sel.rect(
                j,
                j.width / 2 - w / 2,
                j.height / 2 - h / 2,
                w,
                h,
                mode=fu.CHANNEL_OP_REPLACE
            )

            Lay.kopy(j)
            Img.bury(j)
            z = Lay.paste(self.stat.render, z1)
        return z

    def do_shadow(self, item, x, y, blur, color, op, n, d=None, inlay=0):
        """
        Draw a drop shadow.

        Create a number of layers, group them, merge them, and then
        cast a shadow from the merged layer.

        If the shadow is an inlay shadow,
        create a layer to cast a shadow over the image.

        item: layer
        x: float
            offset x

        y: float
            offset y

        blur: float
        color: (R, G, B)
            shadow color

        op: opacity
        n: owner's name
            Use to name the shadow layer.

        d: dict with an OptionKey.INHERIT_OPACITY item
        inlay: flag
            if true, the selection is inverted.

        Return the new shadow layer.
        """
        j = self.stat.render
        item = Lay.clone(j, item)

        if op:
            grp = Lay.group(j, "Shadow")

            Lay.order(j, item, grp)

            if inlay:
                z1 = Lay.add(j, "Inlay", z=grp)

                Lay.color_fill(z1, (255, 255, 255))

                z2 = Lay.selectable(j, item, d)

                Sel.item(j, z2)
                Lay.klear(j, z1)
                Lay.bury(j, item)
                Lay.bury(j, z2)
                item = z1

            Sel.item(j, item)

            # Increase shadow intensity by stacking multiple layers:
            while op:
                pdb.script_fu_drop_shadow(j, item, x, y, blur, color, op, 0)
                op -= min(op, 100)

            if not inlay:
                Lay.bury(j, item)

            z = Lay.eat(j, grp)
            z.name = n

            Lay.clip(z)
            if inlay:
                Lay.klear(j, z)

        else:
            return None
        return z

    def get_grad_mode(self, d):
        """
        Return the gradient's mode and opacity.

        d: sub-session dict
        """
        if self.name == SessionKey.BORDER_GRADIENT:
            mode = Mode.get_x("Normal")
            opacity = d[OptionKey.OPACITY]

        else:
            mode, opacity = self.get_mode(d)
        return mode, opacity / 1.

    def get_mode(self, d):
        """
        Return the mode and opacity in the session dict.

        d: sub-session dict
        """
        return Mode.get_x(d[OptionKey.MODE]), d[OptionKey.OPACITY] / 1.

    def give_render_mask(self, z):
        """
        The backdrop layer's mask is transferred to a layer.

        Before merging or removing the backdrop layer, it's mask
        needs to be passed along.

        z: layer
        """
        Lay.give_mask(z, Lay.get_backdrop_layer(self.stat.render))

    @staticmethod
    def is_shadow(n):
        """
        Return true if an effect name is a shadow type.

        n: effect name
        """
        return n in ForEffect.SHADOW_EFFECT

    def noise(self, z, d):
        """
        Adds noise to a layer.

        z: layer
        d: sub-session dict
        """
        pdb.plug_in_solid_noise(
            self.stat.render, z,
            0, 1, d[OptionKey.RANDOM_SEED], 7, 2, 2)
        pdb.plug_in_hsv_noise(
                self.stat.render,
                z,
                4,
                d[OptionKey.POWER],
                d[OptionKey.POWER],
                d[OptionKey.POWER]
            )

    def pass_bounds(self, d):
        """
        Styles are using the last used session settings.

        Check for under and over flows.

        Check gradient and  pattern to see if they exist.

        d: sub-session dict
        """
        ok = OptionKey

        if ok.ROW in d:
            d[ok.ROW] = min(d[ok.ROW], self.stat.width)
            d[ok.ROW] = max(d[ok.ROW], self.row)
            d[ok.COLUMN] = min(d[ok.COLUMN], self.stat.height)
            d[ok.COLUMN] = max(d[ok.COLUMN], self.column)

        if ok.BORDER_WIDTH in d:
            d[ok.BORDER_WIDTH] = min(d[ok.BORDER_WIDTH], self.stat.radius)

        if ok.GRADIENT in d:
            q = pdb.gimp_gradients_get_list(None)[1]
            if d[ok.GRADIENT] not in q:
                d[ok.GRADIENT] = q[0]

        if ok.PATTERN in d:
            q = pdb.gimp_patterns_get_list(None)[1]
            if d[ok.PATTERN] not in q:
                d[ok.GRADIENT] = q[0]

        if ok.PANE_WIDTH in d:
            d[ok.PANE_WIDTH] = min(d[ok.PANE_WIDTH], self.stat.width)

        if ok.WIDTH in d:
            d[ok.WIDTH] = min(
                    d[ok.WIDTH],
                    max(self.stat.width, self.stat.height)
                )

        if ok.PANE_HEIGHT in d:
            d[ok.PANE_HEIGHT] = min(d[ok.PANE_HEIGHT], self.stat.height)

        for k in (ok.START_X, ok.END_X):
            if k in d:
                d[k] = min(d[k], self.stat.width - 1)

        for k in (ok.START_Y, ok.END_Y):
            if k in d:
                d[k] = min(d[k], self.stat.height - 1)
        self.do(d)

    def prep(self, d):
        """
        Set the dictionary needed for processing.

        ‟prep” serves as way to get feedback and then
        wait for the GTK window to finish closing.

        This way there is less a likelihood of problems
        with cross-interface event errors between GTK and GIMP.

        Is part of the UIOption class template.

        d: a sub-session dict with option results
        """
        if not self.previewed:
            self.d = d

        elif self.previewed == 1:
            # Delete original:
            if not RenderHub.is_shadow(self.name):
                Lay.bury(self.stat.render, self.active_start.wip)

        elif self.previewed == 2:
            # Remove the previous preview:
            Lay.bury(self.stat.render, self.active.wip)

            self.active = self.active_start
            self.d = d
            if not RenderHub.is_shadow(self.name):
                self.active.show()

        self.previewed = 0
        self.stat.session[self.name] = d

    def preview(self, d):
        """
        Draw a preview.

        Is part of the UIOption class template.

        d: dict with option results
        """
        # If previous preview:
        z = self.active.wip
        self.previewed += 1

        if z:
            # Shadows create their own duplicate:
            if not RenderHub.is_shadow(self.layer_key):
                self.active_start.hide()

                z1 = Lay.clone(
                        self.stat.render,
                        self.active_start.wip,
                        has_layout=self.has_offset
                    )

                self.active = Active(self.stat, self.layer_key, clone=z1)
                self.active.show()

            if self.previewed > 1:
                Lay.bury(self.stat.render, z)

        self.previewed = 1
        self.do(d)

    def preview_changed(self):
        """
        Invalidate the preview as being finalized.

        Is part of the UIOption class template.
        """
        self.previewed = 2 if self.previewed else 0

    def rand(self, d):
        """
        Randomize option values.

        Is part of the UIOption class template.

        d: dict with current displayed values with OptionKeys
        """
        olk = OptionLimitKey
        e = self.stat.option_limit.delimiter

        for k in d:
            if k in e:
                if olk.LIMIT in e[k]:
                    a = e[k][olk.LIMIT]
                    if olk.STEP in e[k]:
                        d[k] = uniform(a[0], a[1])

                    else:
                        d[k] = rnd(a[0], a[1])

                elif olk.FUNCTION in e[k]:
                    d[k] = choice(e[k][olk.FUNCTION]())

                elif olk.LIMIT_SELF in e[k]:
                    d[k] = e[k][olk.LIMIT_SELF](self)

                elif olk.LIST in e[k]:
                    d[k] = choice(e[k][olk.LIST])

                elif olk.LIMIT_FUNCTION in e[k]:
                    d[k] = e[k][olk.LIMIT_FUNCTION]()
        return d

    def random_rc(self):
        """Return randomized row and column counts."""
        w, h = (
                self.stat.width / ForCell.MIN_CELL_SPAN,
                self.stat.height / ForCell.MIN_CELL_SPAN
            )

        w1, h1 = min(w, 12), min(h, 12)
        w2, h2 = min(w1, 24), min(h1, 24)
        w3, h3 = min(w2, 36), min(h2, 36)
        return rnd(1, rnd(h1, rnd(h2, rnd(h3, h)))), rnd(
            1, rnd(w1, rnd(w2, rnd(w3, w))))
