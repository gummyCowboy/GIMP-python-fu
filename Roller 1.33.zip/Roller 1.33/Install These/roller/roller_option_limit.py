#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from random import choice, randint
from roller_base import Base
from roller_constant import (
        ForBackdropStyle,
        ForCell,
        ForEffect,
        ForFill,
        ForGradient,
        OptionKey
    )

from roller_mode import Mode
from roller_check_button import RCheckButton
from roller_color_button import RColorButton
from roller_combobox import RComboBox
from roller_entry import REntry
from roller_layout import Images
from roller_radio_button import RRadioButton
from roller_spin_button import RSpinButton


class OptionLimit:
    """Use to define a limited range and a random range for option values."""

    def __init__(self, stat):
        """
        stat: Stat
        """
        self.stat = stat
        a = OptionLimitKey
        ok = OptionKey
        self.delimiter = {
            ok.AMPLITUDE: {
                    a.RANGE: (2, 10),
                    a.LIMIT: (2, 10),
                    a.WIDGET: RSpinButton
                },

            ok.ANGLE: {
                    a.RANGE: (6, 90),
                    a.LIMIT: (30, 90),
                    a.WIDGET: RSpinButton
                },

            ok.BACKDROP_BLUR: {
                    a.RANGE: (0, 1000),
                    a.LIMIT: (0, 200),
                    a.WIDGET: RSpinButton
                },

            ok.BACKDROP_IMAGE: {
                    a.RANGE_FUNCTION: self.get_image_list,
                    a.WIDGET: RComboBox
                },

            ok.BORDER_TYPE: {
                    a.LIMIT: (0, 1),
                    a.LABEL:  ("Rounded", "Angular"),
                    a.WIDGET: RRadioButton
                },

            ok.BORDER_WIDTH: {
                    a.RANGE_FUNCTION: self.get_max_span,
                    a.LIMIT_SELF: self.get_border_width,
                    a.WIDGET: RSpinButton
                },

            ok.CHIP_TYPE: {
                    a.LIST: ForBackdropStyle.CHIP_TYPE,
                    a.WIDGET: RComboBox
                },

            ok.COLOR_1: {
                    a.LIMIT_FUNCTION: Base.rnd_col,
                    a.WIDGET: RColorButton
                },

            ok.COLOR_2: {
                    a.LIMIT_FUNCTION: Base.rnd_col,
                    a.WIDGET: RColorButton
                },

            ok.COLUMN: {
                    a.RANGE_SELF: self.get_column_range,
                    a.LIMIT_SELF: self.get_column_limited,
                    a.WIDGET: RSpinButton
                },

            ok.COLUMN_1: {
                    a.RANGE_SELF: self.get_column_range,
                    a.LIMIT_SELF: self.get_column,
                    a.WIDGET: RSpinButton
                },

            ok.COLUMN_2: {
                    a.RANGE_SELF: self.get_column_range,
                    a.LIMIT_SELF: self.get_column,
                    a.WIDGET: RSpinButton
                },

            ok.COMPOSITION_BORDER_WIDTH: {
                    a.LIMIT_SELF: self.get_border_width,
                    a.WIDGET: RSpinButton
                },

            ok.CRITERIA: {
                    a.LIST: ForFill.CRITERIA_LIST,
                    a.WIDGET: RComboBox
                },

            ok.EMBOSS: {
                    a.LIMIT: (0, 1),
                    a.WIDGET: RCheckButton
                },

            ok.END_X: {
                    a.RANGE_FUNCTION: self.get_coordinate_x_range,
                    a.LIMIT_FUNCTION: self.get_coordinate_x,
                    a.WIDGET: RSpinButton
                },

            ok.END_Y: {
                    a.RANGE_FUNCTION: self.get_coordinate_y_range,
                    a.LIMIT_FUNCTION: self.get_coordinate_y,
                    a.WIDGET: RSpinButton
                },

            ok.FIT_IMAGE: {a.WIDGET: RCheckButton},
            ok.GRADIENT: {
                    a.FUNCTION: self.get_gradient_list,
                    a.WIDGET: RComboBox
                },

            ok.GRADIENT_TYPE: {
                    a.LIST: ForGradient.GRADIENT_TYPE,
                    a.WIDGET: RComboBox
                },

            ok.INHERIT_OPACITY: {
                    a.LABEL: ("Same as image", "Make opaque"),
                    a.WIDGET: RRadioButton
                },

            ok.INLAY_BLUR: {
                    a.RANGE: (0, 1000),
                    a.LIMIT: (20, 30),
                    a.WIDGET: RSpinButton
                },

            ok.INVERT: {
                    a.LIMIT: (0, 1),
                    a.WIDGET: RCheckButton
                },

            ok.KEEP_GRADIENT: {a.WIDGET: RCheckButton},
            ok.LIGHT_ANGLE: {
                    a.RANGE: (0, 359),
                    a.LIMIT: (0, 359),
                    a.WIDGET: RSpinButton
                },

            ok.LINE_WIDTH: {
                    a.RANGE_FUNCTION: self.get_max_span,
                    a.LIMIT_SELF: self.get_border_width,
                    a.WIDGET: RSpinButton
                },

            ok.INTENSITY: {
                    a.RANGE: (0, 1000),
                    a.LIMIT: (80, 130),
                    a.WIDGET: RSpinButton
                },

            ok.MODE: {
                    a.RANGE_FUNCTION: Mode.names,
                    a.LIMIT_FUNCTION: Mode.rand,
                    a.WIDGET: RComboBox
                },

            ok.NAME: {a.WIDGET: REntry},
            ok.OFFSET: {
                    a.RANGE_FUNCTION: self.get_max_span,
                    a.LIMIT_FUNCTION: self.get_gradient_offset_limited,
                    a.WIDGET: RSpinButton
                },

            ok.OFFSET_X: {
                    a.RANGE_FUNCTION: self.get_max_shadow_span,
                    a.LIMIT_FUNCTION: self.get_shadow_offset_limited,
                    a.WIDGET: RSpinButton
                },

            ok.OFFSET_Y: {
                    a.RANGE_FUNCTION: self.get_max_shadow_span,
                    a.LIMIT_FUNCTION: self.get_shadow_offset_limited,
                    a.WIDGET: RSpinButton
                },

            ok.OPACITY: {
                    a.RANGE: (0, 100),
                    a.LIMIT: (50, 100),
                    a.WIDGET: RSpinButton
                },

            ok.PANE_HEIGHT: {
                    a.RANGE_FUNCTION: self.get_pane_range,
                    a.LIMIT_FUNCTION: self.get_pane_limit,
                    a.WIDGET: RSpinButton
                },

            ok.PANE_WIDTH: {
                    a.RANGE_FUNCTION: self.get_pane_range,
                    a.LIMIT_FUNCTION: self.get_pane_limit,
                    a.WIDGET: RSpinButton
                },

            ok.PATTERN: {
                    a.FUNCTION: self.get_pattern_list,
                    a.WIDGET: RComboBox
                },

            ok.POWER: {
                    a.RANGE: (0, 180),
                    a.LIMIT: (0, 180),
                    a.WIDGET: RSpinButton
                },

            ok.RANDOM_SEED: {
                    a.RANGE: (0, 100000),
                    a.LIMIT: (0, 100000),
                    a.WIDGET: RSpinButton
                },

            ok.REVERSE: {
                    a.LIMIT: (0, 1),
                    a.WIDGET: RCheckButton
                },

            ok.ROTATE: {
                    a.RANGE: (-359, 359),
                    a.LIMIT: (-359, 359),
                    a.WIDGET: RSpinButton
                },

            ok.ROUND_UP: {
                    a.LIMIT: (0, 1),
                    a.WIDGET: RCheckButton
                },

            ok.ROUNDED_EDGE_BLUR: {
                    a.RANGE: (0, 1000),
                    a.LIMIT: (15, 30),
                    a.WIDGET: RSpinButton
                },

            ok.ROW: {
                    a.RANGE_SELF: self.get_row_range,
                    a.LIMIT_SELF: self.get_row_limited,
                    a.WIDGET: RSpinButton
                },

            ok.SAMPLE_POINTS: {
                    a.RANGE: (2, 50),
                    a.LIMIT: (2, 25),
                    a.WIDGET: RSpinButton
                },

            ok.SAMPLE_RADIUS: {
                    a.RANGE: (1, 50),
                    a.LIMIT: (1, 15),
                    a.WIDGET: RSpinButton
                },

            ok.SAMPLE_VECTOR: {
                    a.LIST: ForGradient.VECTOR,
                    a.WIDGET: RComboBox
                },

            ok.SHADOW: {
                    a.LIST: ForEffect.SHADOW_CHOICE,
                    a.WIDGET: RComboBox
                },

            ok.SHADOW_BLUR: {
                    a.RANGE: (0, 1000),
                    a.LIMIT: (20, 40),
                    a.WIDGET: RSpinButton
                },

            ok.SHADOW_COLOR: {a.WIDGET: RColorButton},
            ok.SMOOTHNESS: {
                    a.RANGE: (3, 20),
                    a.LIMIT: (5, 12),
                    a.WIDGET: RSpinButton
                },

            ok.START_X: {
                    a.RANGE_FUNCTION: self.get_coordinate_x_range,
                    a.LIMIT_FUNCTION: self.get_coordinate_x,
                    a.WIDGET: RSpinButton
                },

            ok.START_Y: {
                    a.RANGE_FUNCTION: self.get_coordinate_y_range,
                    a.LIMIT_FUNCTION: self.get_coordinate_y,
                    a.WIDGET: RSpinButton
                },

            ok.TEXTURE: {
                    a.LIMIT: (0, 1),
                    a.WIDGET: RCheckButton
                },

            ok.THRESHOLD: {
                    a.RANGE: (.0, 1.),
                    a.LIMIT: (.5, 1.),
                    a.STEP: (.01, .1),
                    a.WIDGET: RSpinButton
                },

            ok.WAVE_AMPLITUDE: {
                    a.RANGE: (0, 100),
                    a.LIMIT: (0, 10),
                    a.WIDGET: RSpinButton
                },

            ok.WAVELENGTH: {
                    a.RANGE: (.01, 50.),
                    a.LIMIT: (30., 50.),
                    a.STEP: (1., 1.),
                    a.WIDGET: RSpinButton
                },

            ok.WHIRL: {
                    a.RANGE: (-720, 720),
                    a.LIMIT: (-30, 30),
                    a.WIDGET: RSpinButton
                },
            ok.WIDTH: {
                    a.RANGE_FUNCTION: self.get_max_span,
                    a.LIMIT_SELF: self.get_filler_width,
                    a.WIDGET: RSpinButton
                },
        }

    def get_border_width(self, caller):
        """
        Return a random value for a border width.

        Use a border width template.
            width_low: int
                low value of random range

            width_high: int
                high value of random range
        """
        return randint(caller.width_low, caller.width_high)

    def get_filler_width(self, caller):
        """
        Return a random value for a filler width.

        Use a border width template.
            filler_width_low: int
                low value of random range

            filler_width_high: int
                high value of random range
        """
        return randint(caller.filler_width_low, caller.filler_width_high)

    def get_column(self, caller):
        """
        Return a randomized column value.

        Use a RenderHub class template.
            random_rc: function
                Call to return a randomized column value.

        caller: RenderHub class instance
        """
        _, c = caller.random_rc()
        return c

    def get_column_limited(self, caller):
        """
        Return a self-limited randomized column value.

        Use a RenderHub class template.
            random_rc: function
                Call to return a randomized column value.

        caller: RenderHub class instance
        """
        _, c = caller.random_rc()
        return max(c, caller.column)

    def get_column_range(self, caller):
        """
        Return a column range.

        Use a RenderHub class template.
            random_rc: function
                Call to return a randomized column value.

            column: int
                Use to set the minimum column value.

        caller: RenderHub class instance
        """
        c = self.stat.height / ForCell.MIN_CELL_SPAN
        return (caller.column, max(caller.column, c))

    def get_coordinate_x(self):
        """Return a Start or End X value."""
        return randint(0, self.stat.width - 1)

    def get_coordinate_x_range(self):
        """Return a Start or End X value."""
        return 0, self.stat.width - 1

    def get_coordinate_y(self):
        """Return a Start or End Y value."""
        return randint(0, self.stat.height - 1)

    def get_coordinate_y_range(self):
        """Return a Start or End Y value."""
        return 0, self.stat.height - 1

    def get_gradient_list(self):
        """Return a list of available gradients."""
        return pdb.gimp_gradients_get_list(None)[1]

    def get_gradient_offset_limited(self):
        """Return a tuple for a shadow offset."""
        return randint(0, min(self.stat.width, self.stat.height, 100))

    def get_image_list(self):
        """Return a backdrop image list."""
        return Images.format_img_list[1:]

    def get_max_shadow_span(self):
        """Return a maximum value for a shadow offset."""
        a = max(self.stat.width, self.stat.height)
        return -a, a

    def get_max_span(self):
        """Return a maximum value for a shadow offset."""
        return (0, max(self.stat.width, self.stat.height))

    def get_shadow_offset_limited(self):
        """Return a tuple for a shadow offset."""
        return randint(0, min(self.stat.radius, 10)) * choice((-1, 1))

    def get_pane_range(self):
        """Return a tuple for a glass pane range."""
        a = min(self.stat.width, self.stat.height)
        return min(25, a), a

    def get_pane_limit(self):
        """Return an integer for a randomized glass pane width."""
        a = min(self.stat.width, self.stat.height)
        return randint(min(25, a), min(300, a))

    def get_pattern_list(self):
        """Return a list of available patterns."""
        return pdb.gimp_patterns_get_list(None)[1]

    def get_row_range(self, caller):
        """Return a tuple for the range of available rows."""
        r = self.stat.width / ForCell.MIN_CELL_SPAN
        return (caller.row, max(r, caller.row))

    def get_row_limited(self, caller):
        """Return a randomized integer for a self-limited row value."""
        r, _ = caller.random_rc()
        return max(r, caller.row)


class OptionLimitKey:
    """Has keys used to access the OptionLimit delimiter dictionary."""
    FUNCTION = 'function'
    FUNCTION_RANGE = 'function_range'
    LIMIT_SELF = 'limit_self'
    LABEL = 'label'
    LIMIT = 'limit'
    LIMIT_FUNCTION = 'limit_function'
    LIST = 'list'
    RANGE = 'range'
    RANGE_FUNCTION = 'range_function'
    RANGE_SELF = 'range_self'
    STEP = 'step'
    WIDGET = 'widget'
