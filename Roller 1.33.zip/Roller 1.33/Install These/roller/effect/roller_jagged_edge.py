#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from random import randint, seed
from roller_constant import ForLayer, LayerKey, OptionKey, SessionKey
from roller_drop_shadow import DropShadow
from roller_effect import Effect
from roller_fu import Lay, Sel
from roller_shadow import Shadow
import gimpfu as fu


class JaggedEdge(Effect):
    """Create a a jagged edge around an image(s)."""
    name = SessionKey.JAGGED_EDGE

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        Effect.__init__(self, d, stat)
        if not stat.cancel:
            ok, sk = OptionKey, SessionKey
            d = self.stat.session[sk.JAGGED_EDGE]

            if d[ok.SHADOW] == sk.DROP_SHADOW:
                if self.has_room:
                    DropShadow({}, stat, q=(LayerKey.IMAGE,))

            elif d[ok.SHADOW] == sk.INLAY_SHADOW:
                Shadow(
                        sk.INLAY_SHADOW,
                        stat,
                        q=(LayerKey.IMAGE,),
                        inlay=1
                    )

            else:
                if self.has_room:
                    Shadow(
                            sk.KEY_LIGHT_SHADOW,
                            stat,
                            q=(LayerKey.IMAGE,),
                        )
                    if not stat.cancel:
                        Shadow(
                                sk.FILL_LIGHT_SHADOW,
                                stat,
                                q=(LayerKey.IMAGE,),
                            )

    def do(self, d):
        """
        Draws the jagged edge.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        ok = OptionKey
        j = self.stat.render
        image_layer = Lay.get_active_image(self.stat)
        z = Lay.selectable(
                j,
                image_layer,
                ForLayer.INHERIT_DICT
            )

        seed(d[OptionKey.RANDOM_SEED])
        Sel.item(j, z)
        Sel.shrink(j, max(d[ok.AMPLITUDE] + 1, 6))
        Sel.kleer(j, z)

        for _ in range(3):
            for i in (fu.ORIENTATION_VERTICAL, fu.ORIENTATION_HORIZONTAL):
                pdb.plug_in_shift(j, z, randint(1, d[ok.AMPLITUDE]), i)

        pdb.plug_in_oilify(j, z, d[OptionKey.SMOOTHNESS], 0)
        Sel.item(j, z)
        Lay.bury(j, z)
        Sel.kleer(j, image_layer)
