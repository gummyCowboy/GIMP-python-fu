#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import (
        ForLayer,
        LayerKey,
        OptionKey
    )

from roller_base import Base
from roller_base import Comm
from roller_render_hub import RenderHub
from roller_fu import Lay, Sel
import gimpfu as fu


class Effect(RenderHub):
    """Has factored functions from 3D effect classes."""
    BLUR_BACKGROUND_AMOUNT = 16

    def __init__(
                self,
                d,
                stat,
                q=None,
                layer_key=LayerKey.FORMAT, need_room=True
            ):
        """
        d: sub-session dict
        stat: Stat
        q: effect layers
        layer_key: layer key
        need_room: boolean
            Is true if the effect needs to expand the image selection.
        """
        # ‟self.caster” is a list of Active layer keys.
        # These layers cast a shadow as a single selection.
        self.caster = q if q else (LayerKey.IMAGE,)
        z = Lay.get_active_format_layer(stat)
        self.id = "{}: {}".format(z.name, self.name)
        z = Lay.search(z, LayerKey.IMAGE)

        Sel.item(stat.render, z)
        Sel.invert(stat.render)

        self.has_room = Sel.is_sel(stat.render) if need_room else True

        Sel.none(stat.render)
        if self.has_room:
            RenderHub.__init__(self, d, stat, layer_key)

        else:
            Comm.info_msg(
                "{} has no room for its 3D effect.".format(self.id))

    def blur_bg(self, d, z):
        """
        Blur the background of a transparent border.

        d: sub-session dict
        z: transparent border layer
        """
        j = self.stat.render
        Lay.hide(self.active.format)
        Sel.all(j)
        Lay.kopy(j)
        Lay.show(self.active.format)

        z1 = Lay.search(self.active.format, LayerKey.IMAGE)
        z1 = Lay.paste(j, z1)

        Lay.move(z1, 0, 0)

        # If there's only transparency then the blur behind is pointless:
        z1.name = Lay.get_layer_name(LayerKey.BLURRED_BACKGROUND, self.stat)

        if Lay.has_pixel(j, z1):
            z2 = Lay.selectable(j, z, ForLayer.INHERIT_DICT)

            Lay.blur(j, z1, Effect.BLUR_BACKGROUND_AMOUNT)
            pdb.gimp_brightness_contrast(z1, -20, 0)
            Sel.item(j, z2)
            Sel.kleer(j, z1)
            Lay.bury(j, z2)

    def create_shadow_unit(self, q, q1):
        """
        Create a unified shadow layer.

        q: layers to merge
        q1: list to append source layers
        """
        # Put layer(s) into a group and merge group:
        j, z = self.stat.render, self.active.format
        group = Lay.group(self.stat.render, "Cast", z=z)

        for k in q:
            z1 = Lay.search(z, k)
            z2 = Lay.clone(j, z1)

            Lay.order(j, z2, group)
            Lay.hide(z1)
            q1.append(z1)
        return Lay.eat(j, group)

    def do_behind_shadow(self, k, q, sel):
        """
        Use with borders that have transparency in the their frame.

        Create an additional shadow cast by the
        opaque frame beneath the transparent frame.

        k: sub-session key
        q: opaque layer keys
        sel: selection that gets blurred
        """
        ok = OptionKey
        j = self.stat.render
        d = self.stat.session[k]
        q1 = []
        group = self.create_shadow_unit(q, q1)
        group1 = Lay.selectable(j, group, ForLayer.INHERIT_DICT)
        Lay.bury(j, group)

        z = self.do_shadow(
                group1,
                d[ok.OFFSET_X],
                d[ok.OFFSET_Y],
                d[ok.SHADOW_BLUR],
                d[ok.SHADOW_COLOR],
                d[ok.INTENSITY],
                n=LayerKey.BLURRED_BACKGROUND,
                d=d
            )

        Lay.bury(j, group1)

        z = j.layers[0]
        z1 = Lay.search(self.active.format, LayerKey.BLURRED_BACKGROUND)
        x = Lay.offset(z1, self.active.format)

        Lay.order(j, z, self.active.format, a=x)
        Lay.blur(j, z, Effect.BLUR_BACKGROUND_AMOUNT / 2)

        z = Lay.merge(j, z)

        Sel.load(j, sel)
        Sel.kleer(j, z)
        [Lay.show(i) for i in q1]

    def draw_color_rectangles(self, j, z, w, h):
        """
        Draws two layers of colors stripes in order to create color rectangles.

        j: GIMP image
        z: layer to draw on
        w: width of rectangle
        h: height of rectangle
        """
        # vertical panes:
        x = y = x1 = y1 = 0
        w1, h1 = j.width, j.height
        z.mode, z.opacity = fu.LAYER_MODE_NORMAL, 100.

        while x < w1:
            x1 = min(x1 + w, w1)

            Sel.rect(j, x, 0, x1 - x, h1, mode=fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, Base.rnd_col())
            x = x1

        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        # horizontal panes:
        while y < h1:
            y1 = min(y1 + h, h1)

            Sel.rect(j, 0, y, w1, y1 - y, mode=fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, Base.rnd_col())
            y = y1
        return Lay.merge(j, z)

    def draw_sel(self, sel, z):
        """
        Draw a selection as black on white.

        sel: selection
        z: layer
        """
        Lay.color_fill(z, (255, 255, 255))
        Sel.load(self.stat.render, sel)
        Sel.fill(z, (0, 0, 0))
        Sel.none(self.stat.render)

    def emboss(self, j, z, light, a):
        """
        Emboss a layer.

        j: GIMP image
        z: layer
        light: angle (0..360)
        a: contrast

        The ‟30” produces the middle value for the face.

        The first ‟1” doesn't blend the light and shadow.
        """
        pdb.plug_in_emboss(j, z, light, 30., 1, 1)
        pdb.gimp_brightness_contrast(z, 0, a)
