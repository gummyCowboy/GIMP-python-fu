#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import OptionKey, SessionKey
from roller_effect import Effect
from roller_fu import Lay, Sel
import gimpfu as fu


class Shadow(Effect):
    """
    Creates a shadow layer.

    Use with shadow effects.
    """

    def __init__(self, k, stat, q=None, inlay=0):
        """
        k: effect name
        stat: Stat
        q: layer tuple
            layers that cast shadow as a unit
        inlay: flag: invert selection when true
        """
        self.name = k
        self.inlay = inlay
        d = stat.session[k]
        Effect.__init__(self, d, stat, q=q, layer_key=k)

    def do(self, d):
        """
        Draws a shadow.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        # Use a selection so the shadow doesn't appear below the image:
        ok = OptionKey
        j = self.stat.render
        m = self.inlay
        q1 = []
        group = self.create_shadow_unit(self.caster, q1)
        name = Lay.get_layer_name(self.name, self.stat)

        if m:
            # inlay-type shadow:
            d[ok.OFFSET_X] = d[ok.OFFSET_Y] = 0
            blur = d[ok.INLAY_BLUR]

        else:
            blur = d[ok.SHADOW_BLUR]
            group1 = Lay.selectable(j, group, d)
            Lay.bury(j, group)
            group = group1

        if ok.INHERIT_OPACITY not in d:
            d[ok.INHERIT_OPACITY] = 1

        z = self.active.layer = self.do_shadow(
            group,
            d[ok.OFFSET_X],
            d[ok.OFFSET_Y],
            blur,
            d[ok.SHADOW_COLOR],
            d[ok.INTENSITY],
            n=name,
            d=d,
            inlay=m)

        Lay.bury(j, group)

        if z:
            a = len(self.active.format.layers) if not m else 0
            Lay.order(j, z, self.active.format, a=a)
            if self.name == SessionKey.KEY_LIGHT_SHADOW:
                z.mode = fu.LAYER_MODE_NORMAL

        [Lay.show(i) for i in q1]
        Sel.none(j)
