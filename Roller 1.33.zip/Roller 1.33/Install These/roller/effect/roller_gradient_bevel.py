#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForLayer, LayerKey, OptionKey, SessionKey
from roller_drop_shadow import DropShadow
from roller_effect import Effect
from roller_fu import Lay, Sel
from roller_shadow import Shadow
import gimpfu as fu


class GradientBevel(Effect):
    """Create a an colored edge around an image(s)."""
    name = SessionKey.GRADIENT_BEVEL
    width_low, width_high = 12, 40

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        sk = SessionKey

        Effect.__init__(self, d, stat)
        if self.has_room:
            if not stat.cancel:
                DropShadow(
                        {},
                        stat,
                        q=(LayerKey.IMAGE, sk.GRADIENT_BEVEL)
                    )
            if not stat.cancel:
                Shadow(
                        sk.IMAGE_EDGE_SHADOW,
                        stat,
                        q=(LayerKey.IMAGE,),
                        inlay=1
                    )

    def do(self, d):
        """
        Draws the jagged edge.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        ok = OptionKey
        j = self.stat.render
        n = Lay.get_layer_name(SessionKey.GRADIENT_BEVEL, self.stat)
        z = Lay.add(j, n, z=self.active.format)
        z1 = Lay.selectable(
                j,
                Lay.get_active_image(self.stat),
                ForLayer.INHERIT_DICT
            )

        color, color1 = d[ok.COLOR_1], d[ok.COLOR_2]
        steps = d[ok.BORDER_WIDTH]
        step = self.calculate_gradient(color, color1, steps)
        start_color = color
        q = list(start_color)

        # The layer borders need to be set to the image size.
        # This is done by using a color fill. The problem
        # is the selection won't grow beyond the layer borders:
        Sel.all(j)
        Lay.color_fill(z, (127, 127, 127))
        Lay.klear(j, z)
        Sel.item(j, z1)

        for i in range(steps):
            sel = Sel.save(j)
            Sel.grow(j, 1, 0)
            Sel.load(j, sel, opt=fu.CHANNEL_OP_SUBTRACT)
            Sel.fill(z, tuple(q))
            Sel.load(j, sel, opt=fu.CHANNEL_OP_ADD)
            for x in range(3):
                a = step[x] * (i + 1)
                q[x] = start_color[x] + int(a)

        Sel.item(j, z1)
        Lay.klear(j, z)
        Lay.bury(j, z1)
