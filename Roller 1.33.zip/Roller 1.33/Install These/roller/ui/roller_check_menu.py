#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_combobox_entry import RComboBoxEntry


class CheckMenu(RComboBoxEntry):
    u"""
    Remembers drop-menu selections.

    This menu remembers menu selection states and shares this
    info with the user by displaying a ‟✓” by the drop-down option.
    """

    def __init__(self, p, n, key, opt):
        """
        ‟self.d” is used to remember checkmarks.

        p: callback function
        n: string
            always displayed on combobox

        key: widget's key
        opt: iterable of strings
            for populating the list
        """
        self.update_window = p
        self.displayed_text = n
        self.d = {}
        q = self.origin_opt = sorted(opt)

        for n in q:
            self.d[n] = 0
        RComboBoxEntry.__init__(
            self, self.on_check_menu_change, key=key, opt=q, pad_x=3)

    def get_value(self):
        """
        Return a dictionary with its keys set from menu
        items and values indicating their selection.

        Is part of a UI widget template.
        """
        return self.d

    def set_value(self, d):
        u"""
        Set the menu options to the keys in ‟d”.

        The menu always shows the same text.

        Is part of a UI widget template.

        d: dict
        """
        q = self.origin_opt
        self.temp_opt = q[:]

        if d:
            for x, n in enumerate(q):
                if n in d:
                    if d[n]:
                        self.temp_opt[x] = "✓ " + n
                        self.d[n] = 1

        self.populate_list(self.temp_opt)
        self.set_text(self.displayed_text)

    def on_check_menu_change(self, g):
        u"""
        Update a menu option by inverting its selection state.

        Update ‟self.d” for ‟get”.

        g: ComboBox
        """
        x = g.wig.get_active()
        if x > -1:
            n = self.origin_opt[x]
            if n:
                if n[0] == "✓":
                    n = n[2:]

                if self.d[n]:
                    self.d[n] = 0

                else:
                    self.d[n] = 1

                self.update_window(self)
                self.set_value(self.d)

            # Tell GTK updates are completed:
            return 1
