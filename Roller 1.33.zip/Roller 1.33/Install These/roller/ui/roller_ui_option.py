#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_constant import (
        ForGradient,
        ForPreset,
        ForWidget,
        OptionKey,
        PresetKey,
        SessionKey,
        UIKey,
        WindowKey
    )

from roller_base import OZ
from roller_ui import UI
from roller_group_preset import GroupPreset
from roller_session import Session
from roller_preset_sub_session import PresetSubSession
from roller_button import RButton
from roller_check_button import RCheckButton
from roller_color_button import RColorButton
from roller_combobox import RComboBox
from roller_eventbox import REventBox
from roller_entry import REntry
from roller_fu import Sel
from roller_label import RLabel
from roller_option_limit import OptionLimitKey
from roller_radio import RRadio
from roller_radio_button import RRadioButton
from roller_spin_button import RSpinButton
from roller_splitter import Splitter
import gtk


class UIOption(UI):
    """
    This is a dynamic-widget dialog for style and effect options.

    Use an UIOption class template to communicate with the creator class.
    The UIOption template has the following properties:
        prep: function
            Call when the user accepted the options.

        preview: function
            Call when the user wants a preview of the options.

        preview_changed: function
            Call so the creator class can keep or delete a
            previous preview.

        rand: function
            Call so the creator can return a dictionary with
            randomized widget values.
    """

    def __init__(self, a, d, stat):
        """
        a: calling class instance
            part of the UIOption class template

        d: sub-session dict
        stat: Stat
        """
        self.stat = stat
        self.stat.cancel = 1
        self._session_key = a.name
        self._creator = a
        self.d = d
        self.wigs = [k for k in Session.default[a.name]]
        self.bd_image_m = None
        d = {
                UIKey.ON_RETURN: self.do_job,
                UIKey.WINDOW_POSITION: WindowKey.OPTION,
                UIKey.WINDOW_TITLE: a.name + " Options"
            }

        UI.__init__(self, d)
        Sel.none(stat.render)
        pdb.gimp_displays_flush()

        if self._gradient_type_widget:
            self._update_widget_visibility(self._gradient_type_widget)
        gtk.main()

    def _add_box(self, g):
        """
        Create a box that is split and has a colored background.

        g: container

        Returns:
            Splitter, REventBox
        """
        box = REventBox(self.color)
        g1 = Splitter(pad_x=3)

        g.add(box)
        box.add(g1.g)
        return g1, box

    def _compliment_key_light(self):
        """Return a complimentary preset of the key-light shadow."""
        d = deepcopy(self.stat.session[SessionKey.KEY_LIGHT_SHADOW])
        d[OptionKey.OFFSET_X] *= -1
        d[OptionKey.OFFSET_Y] *= -1
        d[OptionKey.INTENSITY] /= 2
        return d

    def _get_data(self):
        """Return a dict of the control values."""
        d = {}

        for g in self.controls:
            d[g.key] = g.get_value()
        return d

    def _draw_preview(self, g):
        """
        Draw a preview.

        Calls the creator class to perform the preview operation.

        g: RButton
        """
        self.win.iconify()
        g.disable()

        d = self._get_data()

        self._creator.preview(d)
        g.enable()
        self.win.present()
        pdb.gimp_displays_flush()

    def _draw_widgets(self, g, q):
        """
        Create the widgets.

        g: Vbox
        q: list of widgets
        """
        ok = OptionKey
        olk = OptionLimitKey
        p = self.on_widget_change
        self._point_box = []
        self._gradient_type_widget = None
        d = self.stat.option_limit.delimiter

        for n in self.wigs:
            g1, _ = self._add_box(g)
            wig = d[n][olk.WIDGET]

            if wig == RCheckButton:
                g2 = RLabel("")
                g3 = RCheckButton(n, p, n)

            else:
                if n == ok.WIDTH:
                    g2 = RLabel(self._session_key + " Width:")

                else:
                    g2 = RLabel(n + ":\t\t")

                if wig == RColorButton:
                    g3 = wig(p, (0, 0, 0), n)

                elif wig == REntry:
                    g3 = REntry(p, n)

                elif wig == RComboBox:
                    if olk.LIST in d[n]:
                        q1 = d[n][olk.LIST]

                    else:
                        for k in (
                                    olk.FUNCTION,
                                    olk.RANGE_FUNCTION
                                ):
                            if k in d[n]:
                                q1 = d[n][k]()
                                break
                    g3 = wig(p, key=n, opt=q1)

                elif wig == RRadioButton:
                    g_ = wig(p, d[n][olk.LABEL][0], n, None)
                    g3 = wig(p, d[n][olk.LABEL][1], n, g_.wig)
                    rr = RRadio((g_, g3), n)
                    g1.right.add(g_.g)

                elif wig == RSpinButton:
                    if olk.RANGE in d[n]:
                        q1 = d[n][olk.RANGE]

                    elif olk.RANGE_SELF in d[n]:
                        q1 = d[n][olk.RANGE_SELF](self._creator)

                    elif olk.RANGE_FUNCTION in d[n]:
                        q1 = d[n][olk.RANGE_FUNCTION]()

                    is_float = 1 if olk.STEP in d[n] else 0
                    q2 = d[n][olk.STEP] if is_float else (1, 1)
                    g3 = wig(p, q1, key=n, is_float=is_float, q1=q2)

            g1.both(g2.g, g3.g)
            g3.set_value(self.d[n])

            if isinstance(g3, RRadioButton):
                g3 = rr

            self.controls.append(g3)
            q.append(g1)
            self.reduce_color()

    def _randomize_widgets(self, _):
        """Randomize the variables."""
        d = self._creator.rand(self._get_data())

        self._creator.preview_changed()
        self.update_controls(d)
        self.preset_is_undefined()
        self._update_widget_visibility(self._gradient_type_widget)

    def _update_widget_visibility(self, g):
        """
        The end points are not necessary for a shape-burst gradient type.

        g: widget
        """
        if g:
            if g.key == OptionKey.GRADIENT_TYPE:
                if g.get_value() in ForGradient.SHAPE_BURST:
                    [i.hide() for i in self._point_box]

                else:
                    [i.show() for i in self._point_box]

    def cancel(self, *_):
        """The user canceled the window."""
        self.close()

    def do_job(self, *_):
        """The user accepted the window content."""
        d = self._get_data()

        self._creator.prep(d)
        self.close()
        self.stat.cancel = 0

    def draw_window(self):
        """
        Draw the windows widgets.

        Is part of the UI window template.
        """
        self.controls = []
        q = []
        internal = None
        g = gtk.VBox()
        k = self._session_key

        if k == SessionKey.FILL_LIGHT_SHADOW:
            n1 = ForPreset.KEY_LIGHT_COMPLIMENT
            self.d = self._compliment_key_light()
            internal = [[n1, self.d]]

        else:
            n1 = ForWidget.LAST_USED if self.stat.session[k] != \
                Session.default[k] else PresetKey.DEFAULT

        if k == SessionKey.COLORED_GRID:
            d = deepcopy(self.d)
            d[OptionKey.ROTATE] = 45
            internal = [[ForPreset.COLORED_DIAMONDS, d]]

        self._draw_widgets(g, q)

        # preview and randomize:
        g1, _ = self._add_box(g)
        g2 = RButton("Preview", self._draw_preview)
        g3 = RButton("Randomize", self._randomize_widgets)

        self.keep((g2, g3))
        q.append(g1)
        g1.both(g2.g, g3.g)
        self.reduce_color()

        # default and presets:
        d = {
                PresetKey.FOLDER: self.stat.preset_folder,
                PresetKey.NAME: k,
                PresetKey.PARENT: self.win
            }

        if internal:
            d[PresetKey.INTERNAL] = internal

        self.preset = PresetSubSession(d, self.stat)
        g1, _ = self._add_box(g)
        g2 = self.preset_menu = GroupPreset(
            None,
            self.on_preset_change,
            k,
            self._get_data,
            self.win,
            self.preset)

        q.append(g1)
        g2.box.both(g2.save_b.g, g2.del_b.g)
        g2.box.pack()
        g1.left.add(g2.label.g)
        g1.both(g2.g, g2.box.g)
        self.reduce_color()
        g2.set_value(n1)
        g2.verify_del_button()

        # cancel and accept:
        g1, _ = self._add_box(g)
        g2 = RButton("Cancel", self.cancel)
        g3 = RButton("Accept", self.accept)

        self.keep((g2, g3))
        q.append(g1)
        g1.both(g2.g, g3.g)
        [g4.pack() for g4 in q]
        self.win.add(g)

    def on_preset_change(self, _, d):
        """
        Loads the preset in the menu.

        d: preset dict
        """
        g = self.preset_menu
        if g.get_text() != ForWidget.UNDEFINED:
            OZ.pass_version(d, Session.default[self._session_key])
            self.update_controls(d)
            self._creator.preview_changed()
            self._update_widget_visibility(self._gradient_type_widget)

    def on_widget_change(self, g):
        """
        Update the preview state and widget visibility.

        g: widget
        """
        if not UI.loading:
            self._creator.preview_changed()
            self.preset_is_undefined()
            self._update_widget_visibility(g)
