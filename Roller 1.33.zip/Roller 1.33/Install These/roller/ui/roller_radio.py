#!/usr/bin/env python
# -*- coding: utf-8 -*-


class RRadio:
    """
    Use to manage a group of RadioButtons.

    By using an index into the group, the group's
    state can be restored between sessions.
    """

    def __init__(self, q, k):
        """
        Receive the RRadioButtons.

        The RRadioButtons are assumed to part of the same group.

        q: iterable
            group of interrelated RRadioButtons

        k: string
            widget group key
        """
        self.q = q
        self.key = k

    def get_value(self):
        """
        Find the active RadioButton and returns its index.

        There's always one RadioButton that is active.

        Is part of a UI widget template.
        """
        for x, g in enumerate(self.q):
            if g.get_value():
                return x

    def set_value(self, x):
        """
        Set a RadioButton in the group as active.

        Only one RadioButton in a group can be active.

        Is part of a UI widget template.

        x: integer
            index into group
        """
        self.q[x].set_value(1)
