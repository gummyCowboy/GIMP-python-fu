#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_wig import Wig
import gtk


class RColorButton(Wig):
    """This is a color button that opens a color-chooser dialog."""

    def __init__(self, p, q, k):
        """
        p: callback function
        q: color (r, g, b)
        k: widget key
        """
        w = ForWidget.MARGIN
        g = self.g = gtk.Alignment(0, 0, 1, 0)
        g1 = gtk.ColorButton(color=RColorButton._convert_color(q))

        Wig.__init__(self, p, key=k, widget=g1)
        g1.connect('clicked', self.callback)
        g.add(g1)
        g.set_padding(w / 2, w / 2, 0, 0)

    @staticmethod
    def _convert_color(q):
        """
        Convert COLOR to GdkColor.

        q: (r, g, b) (0..255)
        """
        q = [i / 255. for i in q]
        return gtk.gdk.Color(*q)

    def get_value(self):
        """
        Return the value of the button as (r, g, b) (0..255).

        Is part of a UI widget template.
        """
        a = self.wig.get_color()
        return tuple([int(i / 256) for i in (a.red, a.green, a.blue)])

    def set_value(self, q):
        """
        Set the color of the button.

        Is part of a UI widget template.

        q: color: (r, g, b): (0..255)
        """
        self.wig.set_color(RColorButton._convert_color(q))
