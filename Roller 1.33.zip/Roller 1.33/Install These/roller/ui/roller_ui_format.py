#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_base import Base, OZ
from roller_constant import (
        ForCell,
        ForFormat,
        FormatKey,
        ForWidget,
        PresetKey,
        SessionKey,
        UICellKey,
        UIFormatKey,
        UIKey,
        WindowKey
    )

from roller_button import RButton
from roller_check_button import RCheckButton
from roller_combobox import RComboBox
from roller_effect_nexus import EffectNexus
from roller_entry import REntry
from roller_eventbox import REventBox
from roller_group_per_cell import GroupPerCell
from roller_group_preset import GroupPreset
from roller_label import RLabel
from roller_layout import Images
from roller_preset_format import PresetFormat
from roller_rbox import RBox
from roller_session import Format
from roller_spin_button import RSpinButton
from roller_splitter import Splitter
from roller_ui import UI
from roller_ui_cell import UICell
from roller_ui_switch import UISwitch
import gtk


class UIFormat(UISwitch):
    """
    This is a window with format controls and accesses UICell windows.
    """
    MARG_Y = 30

    def __init__(self, d):
        """d: dict"""
        self.stat = d[UIKey.STAT]
        x = self._format_index = d[UIFormatKey.FORMAT_INDEX]
        self._format = deepcopy(self.stat.session[SessionKey.FORMAT_LIST][x])
        self._feedback = d[UIKey.FEEDBACK]
        self._layout = d[UIKey.LAYOUT]
        d[UIKey.ON_RETURN] = self.do_job
        d[UIKey.WINDOW_TITLE] = "Format"
        d[UIKey.WINDOW_POSITION] = WindowKey.FORMAT
        UISwitch.__init__(self, d)

    def _adjust_cell_tables(self):
        """
        Cell tables expand or contract depending on the rows and columns.
        """
        self._expand_cell_tables()
        self._contract_cell_tables()

    def _contract_cell_tables(self):
        """
        Contract Per Cell tables to correspond with the Format dict.

        Checks Merge Cells table for group dimension overflow.
        """
        row = self._format[FormatKey.ROW]
        col = self._format[FormatKey.COLUMN]

        for k in ForCell.CELL_KEY_LIST:
            if self._format[k]:
                r = len(self._format[k])

                if r > row:
                    # Remove rows:
                    for _ in range(r - row):
                        self._format[k].pop()
                for r in range(len(self._format[k])):
                    c = len(self._format[k][r])
                    if c > col:
                        # Remove columns:
                        for _ in range(c - col):
                            self._format[k][r].pop()
        self._fix_merge_cells()

    def _correct_contracted_cells(self):
        """
        When cells contract, their dimensions change.
        This makes the cut-off cells independent.
        """
        if self._format[FormatKey.MERGE_PER_CELL]:
            r = self._format[FormatKey.ROW]
            r1 = len(self._format[FormatKey.CELL_TABLE_MERGE])
            c = self._format[FormatKey.COLUMN]
            for r2 in range(r1):
                for c1 in range(
                        len(self._format[FormatKey.CELL_TABLE_MERGE][r2])):
                    if r2 >= r or c1 >= c:
                        self._format[FormatKey.CELL_TABLE_MERGE][r2][c1] = 1, 1

    def _correct_merge_overflow(self, s, row, col, r, c):
        """
        Check if the Merge Cells' table has contracted. If so then
        the top-left cells need their dimensions checked for overflow.

        row, col: max location.
        r, c: current location
        s: group dimension
        """
        if s[0] + r > row:
            s = row - r, s[1]

        if s[1] + c > col:
            s = s[0], col - c
        return s

    def _draw_cell_margin_group(self, g):
        """
        Draw the Cell Margins group.

        g: container
        """
        g1 = self.cell_margin_sb = list(
            self.draw_margin_group(g, ForFormat.CELL_MARGIN_SPIN_BUTTON_KEY))

        g = self.margin_pc_group = GroupPerCell(
                self.on_widget_change,
                self._open_cell_window,
                "Cell Margins...",
                FormatKey.MARGIN_PER_CELL,
                g,
                2
            )

        g.wig.connect('clicked', self._set_margin_dependent)
        self.keep((g1,))

    def _draw_grid_group(self, g):
        """
        Draw the grid group.

        g: container
        """
        a = 1, 100
        p = self.on_widget_change
        g1 = Splitter(pad_x=2)
        g2 = RLabel("Row:").g
        g3 = self.row_sb = RSpinButton(p, a, key=FormatKey.ROW)
        g4 = RLabel("Column:").g
        g5 = self.col_sb = RSpinButton(p, a, key=FormatKey.COLUMN)

        self.keep((g3, g5))
        g1.both(g2, g4)
        g1.both(g3.g, g5.g)
        g1.pack()
        g.add(g1.g)
        self.merge_pc_group = GroupPerCell(
                p,
                self._open_cell_window,
                "Merge Cells...",
                FormatKey.MERGE_PER_CELL,
                g,
                0
            )

    def _draw_layer_group(self, g):
        """
        Draw a format layer group.

        g: container
        """
        p = self.on_widget_change
        g1 = self.format_name_e = REntry(p, FormatKey.NAME, pad_x=1)
        g2 = self.effect_m = RComboBox(
                p,
                key=FormatKey.EFFECT,
                opt=[ForFormat.NONE] + EffectNexus.names,
                pad_x=3
            )

        self.keep((g1, g2))
        g.add(RLabel("Format Name:", ForWidget.TOPLEFT).g)
        g.add(g1.g)
        g.add(RLabel("3D Effect:", ForWidget.TOPLEFT).g)
        g.add(g2.g)

    def _draw_layer_margin_group(self, g):
        """
        Draw the layer margins.

        g: container
        """
        self.layer_margin_sb = list(
            self.draw_margin_group(g, ForFormat.LAYER_MARGIN_SPIN_BUTTON_KEY))

    def draw_margin_group(self, g, k):
        """
        Draw the margin SpinButtons.

        g: container
        k: group key

        Return the top, bottom, left, right SpinButton widgets.
        """
        a = 0, 100000
        p = self.on_widget_change
        g1 = [None] * 5
        sb = RSpinButton

        for x in range(5):
            b = 2 if x == 0 else 0
            g1[x] = Splitter(pad_x=b)

        g2 = RLabel("Top:").g
        g3 = sb(p, a, key=k[ForFormat.TOP_INDEX], label=g2)
        g4 = RLabel("Bottom: ").g
        g5 = sb(p, a, key=k[ForFormat.BOTTOM_INDEX], label=g4)
        g6 = RLabel("Left:").g
        g7 = sb(p, a, key=k[ForFormat.LEFT_INDEX], label=g6)
        g8 = RLabel("Right:").g
        g9 = sb(p, a, key=k[ForFormat.RIGHT_INDEX], label=g8)

        for g10 in reversed(g1):
            g10.pack()

        self.keep((g3, g5, g7, g9))
        g1[0].both(g1[1].g, g1[2].g)
        g1[0].both(g1[3].g, g1[4].g)
        g1[1].both(g2, g3.g)
        g1[2].both(g6, g7.g)
        g1[3].both(g4, g5.g)
        g1[4].both(g8, g9.g)
        g.add(g1[0].g)
        return g3, g5, g7, g9

    def _draw_placement_group(self, g):
        """
        Draw the Placement ComboBoxes.

        g: container
        """
        q = ForWidget.MARGIN / 4, 0, 0, 0
        p = self.on_widget_change
        g1 = Splitter(pad_x=2)
        g2 = [None] * 4
        g2[0] = self.resize_m = RComboBox(
            p, key=FormatKey.RESIZE, opt=ForFormat.RESIZE_OPTION)

        g2[1] = self.image_menu = RComboBox(
            p, key=FormatKey.IMAGE, opt=Images.format_img_list[:])

        g2[2] = self.horz_m = RComboBox(
            p, key=FormatKey.HORIZONTAL, opt=ForFormat.HORIZONTAL_OPTION)

        g2[3] = self.vert_m = RComboBox(
            p, key=FormatKey.VERTICAL, opt=ForFormat.VERTICAL_OPTION_LIST)

        # Connect dependents:
        for x in range(4):
            g2[x].resz, g2[x].img, g2[x].horz, g2[x].vert = \
                g2[0], g2[1], g2[2], g2[3]

        self.keep(g2)
        g1.both(RLabel("Resize:", q).g, RLabel("Image:", q).g)
        g1.both(g2[0].g, g2[1].g)
        g1.both(RLabel("Horizontal:", q).g, RLabel("Vertical:", q).g)
        g1.both(g2[2].g, g2[3].g)
        g1.pack()
        g.add(g1.g)

        g = self.placement_pc_group = GroupPerCell(
            p,
            self._open_cell_window,
            "Placement...",
            FormatKey.PLACEMENT_PER_CELL,
            g,
            1)
        g.wig.connect('clicked', self._set_placement_dependent)

    def _draw_preset_group(self, g):
        """
        Draw the Preset ComboBox and Buttons.

        g: container
        """
        self.preset_menu = GroupPreset(
            g,
            self.on_preset_change,
            SessionKey.FORMAT_LIST,
            self.return_format,
            self.win,
            self.preset)

    def _draw_process_group(self, g):
        """
        Draw the Show Layout, Cancel, and Accept Buttons.

        g: container
        """
        g1 = RButton("Accept", self.do_job, pad_x=3)
        g2 = RButton("Show Layout", self._show_layout, pad_x=2)
        g3 = RButton("Cancel", self.do_no, pad_x=1)

        self.keep((g1, g2, g3))
        g.add(g3.g)
        g.add(g2.g)
        g.add(g1.g)

    def _draw_property_group(self, g):
        """
        Draw the property group.

        g: container
        """
        w = ForWidget.MARGIN
        p = self.on_widget_change
        g1 = [None] * 3

        for x in range(3):
            a = 2 if x == 0 else 0
            g1[x] = Splitter(pad_x=a)

        lab = RLabel("Blur Behind:  ").g
        lab1 = RLabel("Rotate:").g
        lab2 = RLabel("Opacity:").g
        g2 = self.flip_h_cb = RCheckButton(
            "Flip Horizontal", p, FormatKey.FLIP_HORIZONTAL)

        g3 = self.flip_v_cb = RCheckButton(
            "Flip Vertical", p, FormatKey.FLIP_VERTICAL)

        g4 = self.rotate_sb = RSpinButton(
            p, (-359, 359), key=FormatKey.ROTATE, label=lab1)

        g5 = self.opacity_sb = RSpinButton(
            p, (0, 100), key=FormatKey.OPACITY, label=lab2)

        g6 = RBox(1, pad=(0, 0, w, w))
        g7 = self.blur_sb = RSpinButton(
            p, (0, 200), key=FormatKey.BLUR_BEHIND, label=lab)

        g5.flip_h, g5.flip_v, g5.rot, g5.blur = g2, g3, g4, g7

        self.keep((g2, g3, g4, g5, g7))
        g1[0].left.add(g2.g)
        g1[0].left.add(g3.g)
        g6.add(lab)
        g6.add(g7.g)
        g1[1].both(lab1, g4.g)
        g1[2].both(lab2, g5.g)

        for g8 in reversed(g1):
            g8.pack()

        g.add(g1[0].g)
        g.add(g6.g)

        for x in range(1, 3):
            g1[0].right.add(g1[x].g)

        g = self.property_pc_group = GroupPerCell(
            p,
            self._open_cell_window,
            "Property...",
            FormatKey.PROPERTY_PER_CELL,
            g,
            3)
        g.wig.connect('clicked', self._set_property_dependent)

    def _expand_cell_table(self, p):
        """
        Expand a cell table based on the row and column counts.

        During an expansion, values are inserted into
        a table from the Format window settings.
        These settings are placed in the ‟cell” variable.

        Each Per Cell group has its own cell type.

        p: a process that returns a cell value
            and the cell table index for the format
        """
        d = self._format
        cell, x = p()
        row, col = d[FormatKey.ROW], d[FormatKey.COLUMN]

        if not d[x]:
            d[x] = Base.create_2d_table(row, col, a=cell)

        else:
            r = len(d[x])

            if r < row:
                e = []

                for _ in range(col):
                    e.append(cell)
                for r1 in range(row - r):
                    # Add a row with a new list:
                    d[x].append(e[:])
            for r1 in range(row):
                c = len(d[x][r1])
                if c < col:
                    for _ in range(col - c):
                        # Add a column:
                        d[x][r1].append(cell)

    def _expand_cell_tables(self):
        """
        The Per Cell tables need updating because the number
        of rows and/or columns may have increased value.
        """
        for x, p in enumerate([
                self._init_merge_table,
                self._init_placement_table,
                self._init_margin_table,
                self._init_property_table]):
            if self.pc_group[x].get_value():
                self._expand_cell_table(p)

    def _fix_merge_cells(self):
        """
        Correct overflow references by reducing
        merged group dimensions in the top-left cells.
        """
        d = self._format
        row, col = d[FormatKey.ROW], d[FormatKey.COLUMN]

        if d[FormatKey.MERGE_PER_CELL]:
            for r in range(row):
                for c in range(col):
                    if r < len(d[FormatKey.CELL_TABLE_MERGE]):
                        if c < len(d[FormatKey.CELL_TABLE_MERGE][r]):
                            d[FormatKey.CELL_TABLE_MERGE][r][c] = \
                                self._correct_merge_overflow(
                                        d[FormatKey.CELL_TABLE_MERGE][r][c],
                                        row,
                                        col,
                                        r, c
                                    )
        self._correct_contracted_cells()

    def _init_margin_table(self):
        """
        This routine is called by ‟_expand_cell_table”.

        Return the image margins cell table init value and the cell table key.
        """
        q = []

        for k in ForFormat.CELL_MARGIN_SPIN_BUTTON_KEY:
            q.append(self._format[k])
        return tuple(q), FormatKey.CELL_TABLE_MARGIN

    def _init_merge_table(self):
        """
        This routine is called by ‟_expand_cell_table”.

        Return the merge cell table init value and the cell table key.
        """
        return (1, 1), FormatKey.CELL_TABLE_MERGE

    def _init_placement_table(self):
        """
        This routine is called by ‟_expand_cell_table”.

        Return the image placement cell table
        init value and the cell table key.
        """
        d = self._format
        return (
            d[FormatKey.RESIZE],
            d[FormatKey.IMAGE],
            d[FormatKey.HORIZONTAL],
            d[FormatKey.VERTICAL]), FormatKey.CELL_TABLE_PLACEMENT

    def _init_property_table(self):
        """
        This routine is called by ‟_expand_cell_table”.

        Return the property table init value and the cell table key.
        """
        q = []

        for k in (
                    FormatKey.FLIP_HORIZONTAL,
                    FormatKey.FLIP_VERTICAL,
                    FormatKey.ROTATE,
                    FormatKey.OPACITY,
                    FormatKey.BLUR_BEHIND
                ):
            q.append(self._format[k])
        return tuple(q), FormatKey.CELL_TABLE_PROPERTY

    def _open_cell_window(self, x):
        """
        Open a Per Cell window.

        x: window index used by UICell
        """
        self._adjust_cell_tables()

        a = Format(self._format)

        UICell({
                UICellKey.FORMAT_OBJ: a,
                UICellKey.MERGE_PER_CELL: self.merge_pc_group.get_value(),
                UICellKey.WINDOW_INDEX: x,
                UIKey.PARENT: self.win,
                UIKey.STAT: self.stat
            }).reply
        if a.format != self._format:
            self._format = deepcopy(a.format)

    def _set_margin_dependent(self, *_):
        """Set margin dependents."""
        m = self.margin_pc_group.get_value()
        for g in self.cell_margin_sb:
            g.disable() if m else g.enable()

    def _set_placement_dependent(self, *_):
        """Set placement dependents."""
        m = self.placement_pc_group.get_value()

        if m:
            for g in (
                    self.resize_m, self.horz_m, self.vert_m, self.image_menu):
                g.disable()

        else:
            self.image_menu.enable()
            self.verify_place_menus(self.resize_m)

    def _set_property_dependent(self, *_):
        """Set image dependents."""
        m = self.property_pc_group.get_value()

        if m:
            for g in (
                    self.rotate_sb, self.opacity_sb,
                    self.flip_h_cb, self.flip_v_cb, self.blur_sb):
                g.disable()

        else:
            self.opacity_sb.enable()
            self.verify_opacity_depend(self.opacity_sb)

    def _show_layout(self, *_):
        """Show a layout sketch-up."""
        self._adjust_cell_tables()

        # Update:
        q = self.stat.session[SessionKey.FORMAT_LIST]
        d = deepcopy(q[self._format_index])
        q[self._format_index] = self._format

        self._layout.show()

        # Restore:
        q[self._format_index] = d

    def _verify_per_cell_buttons(self):
        """Verify Per Cell dependency."""
        for p in (
                    self._set_placement_dependent,
                    self._set_margin_dependent,
                    self._set_property_dependent
                ):
            p()

    def do_no(self, *_):
        """Cancel the Format window."""
        self._feedback(None)
        return self.close()

    def do_job(self, *_):
        """Accept the UIFormat window."""
        for g in self.controls:
            self._format[g.key] = g.get_value()

        self._adjust_cell_tables()

        self.stat.session[SessionKey.FORMAT_LIST][self._format_index] = \
            self._format

        self._feedback(self._format_index)
        return self.close()

    def draw_window(self):
        """
        Draw the window's widgets.

        Is part of the UI window template.
        """
        self.preset = PresetFormat({
                PresetKey.FOLDER: self.stat.preset_folder,
                PresetKey.PARENT: self.win
            })

        g = self.win.vbox
        q = (
                self._draw_layer_group,
                self._draw_grid_group,
                self._draw_placement_group,
                self._draw_property_group,
                self._draw_layer_margin_group,
                self._draw_cell_margin_group,
                self._draw_preset_group,
                self._draw_process_group
            )

        c = (
                "Format Layer",
                "Layer Cell Grid",
                "Image Placement",
                "Image Property",
                "Layer Margins",
                "Cell Margins",
                "Format Options",
                "Process"
            )

        for i, p in enumerate(q):
            if not i % 2:
                same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

            box = REventBox(self.color)
            g1 = gtk.VBox()

            g1.add(RLabel(c[i] + ":", (2, 0, 4, 0)).g)
            box.add(g1)
            p(g1)
            same_size.add_widget(box)
            self.reduce_color()

            # Keep the widgets in memory:
            wig = same_size.get_widgets()

            if i % 2:
                # Add row of same size widgets:
                g2 = gtk.HBox()

                [g2.add(g3) for g3 in reversed(wig)]
                g.add(g2)

        self.pc_group = (
                self.merge_pc_group,
                self.placement_pc_group,
                self.margin_pc_group,
                self.property_pc_group
            )

        q = self.controls = [
                self.format_name_e,
                self.effect_m,
                self.resize_m,
                self.horz_m,
                self.vert_m,
                self.image_menu,
                self.rotate_sb,
                self.opacity_sb,
                self.flip_h_cb,
                self.flip_v_cb,
                self.blur_sb,
                self.property_pc_group,
                self.placement_pc_group,
                self.merge_pc_group,
                self.margin_pc_group,
                self.row_sb,
                self.col_sb,
                self.preset_menu
            ]

        q += [i for i in self.layer_margin_sb]
        q += [i for i in self.cell_margin_sb]

        self.update_controls(self._format)
        self.verify_opacity_depend(self.opacity_sb, self.property_pc_group)
        self._verify_per_cell_buttons()

    def on_preset_change(self, _, d):
        """
        Load the preset on menu change.

        d: preset dict
        """
        n = self.preset_menu.get_text()
        if n != ForWidget.UNDEFINED:
            OZ.pass_version(d, Format.default, is_format=1)
            self._format = self.load_controls(d)
            self._verify_per_cell_buttons()

    def on_widget_change(self, g):
        """
        A widget changed.

        g: widget
        """
        if not UI.loading:
            self._format[g.key] = g.get_value()

            if g.key in (
                    FormatKey.RESIZE,
                    FormatKey.HORIZONTAL,
                    FormatKey.VERTICAL,
                    FormatKey.IMAGE
                    ):
                self.verify_place_menus(g)

            elif g.key in (
                    FormatKey.PLACEMENT_PER_CELL,
                    FormatKey.MARGIN_PER_CELL,
                    FormatKey.PROPERTY_PER_CELL) \
                    or g.key == FormatKey.MERGE_PER_CELL:

                # Reset cell data:
                self._format[g.cell_key] = None
                self._verify_per_cell_buttons()

            elif g.key == FormatKey.OPACITY:
                self.verify_opacity_depend(g)
            self.preset_is_undefined()
        if g.key == FormatKey.IMAGE:
            n = g.get_value()
            n = n if len(n) > 10 else ""
            g.g.set_tooltip_text(n)

    def return_format(self):
        """Use with GroupPreset to save presets."""
        return self._format
