#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gtk


class RBox:
    """This is a GTK Box widget with an Alignment."""

    def __init__(self, x, align=(0, 0, 0, 0), pad=None):
        """
        x: index to box where 0 is a VBox, 1 is a HBox, 2 is a VButtonBox
        align: Alignment tuple (f, f, f, f)
        pad: padding tuple (top, bottom, left, right)
        """
        g = self.g = gtk.Alignment(*align)
        g1 = self.box = (gtk.VBox, gtk.HBox, gtk.VButtonBox)[x]()

        if pad:
            g.set_padding(*pad)
        g.add(g1)

    def add(self, g):
        """g: GTK widget"""
        self.box.add(g)
