#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_wig import Wig
import gtk


class RSpinButton(Wig):
    """This is a custom GTK SpinButton."""

    def __init__(
                self,
                p,
                q,
                key=None,
                q1=(1, 1),
                label=None,
                pad_x=0,
                is_float=0,
                range=None
            ):
        """
        p: callback function
        q: range tuple
        key: widget key
        q1: increments tuple
        pad_x: index to padding (0..2)
        label: label that is attached to the SpinButton
        is_float: int-flag
            If it's true, then the SpinButton uses float values.

        range: tuple
            (low, high) range for the ‟get_random” function
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        self.float = is_float
        self.range = range
        g = self.g = gtk.Alignment(0, 0, 1, 0)
        g1 = gtk.SpinButton(
                adjustment=None,
                climb_rate=(2, .02)[is_float],
                digits=(0, 3)[is_float]
            )

        Wig.__init__(self, p, key=key, label=label, widget=g1)

        # Tell the SpinButton to respond to click events:
        for i in (
                    gtk.gdk.BUTTON_RELEASE_MASK,
                    gtk.gdk.BUTTON_PRESS_MASK
                ):
            g1.add_events(i)

        g.add(g1)
        g1.set_range(*q)
        g1.set_increments(*q1)
        g1.connect('button_press_event', self.focus_in)
        g1.connect('value_changed', self.callback)
        g1.connect('key_release_event', self.on_key_release)
        if pad_x:
            x = pad_x - 1
            g.set_padding((0, 0, w1)[x], (0, w1, w1)[x], w, w)

    def focus_in(self, *_):
        """
        Improve focus handling.

        Correct an invalid numeric.
        """
        self.wig.grab_focus()
        self.set_value(self.get_value())

    def get_value(self):
        """
        Return the value of the SpinButton.

        Is part of the UI widget template.
        """
        n = self.wig.get_text()
        a = n if n.isdigit() else self.wig.get_value()

        if not self.float:
            a = int(a)
        return a

    def on_key_release(self, _, a):
        """
        Keep arrow and page key events from signaling twice.

        a: key release event
        """
        n = gtk.gdk.keyval_name(a.keyval)

        if n in ('Up', 'Down', 'Page_Up', 'Page_Down', 'Tab'):
            return
        self.callback()

    def set_value(self, a):
        """
        Set the SpinButton display value.

        Is part of the UI widget template.

        a: int or float
        """
        self.wig.set_value(a / 1.)
