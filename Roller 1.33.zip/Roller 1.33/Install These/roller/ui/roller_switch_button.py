#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_cg import CG
from roller_colored_button import ColoredButton


class SwitchButton(ColoredButton):
    """Use to process CG cell connection events."""

    def __init__(self, n, p, r, c, g):
        """
        n: text on button
        p: callback functions
        r: row
        c: column
        g: gtk Box-type, widget's container which is padded
        """
        self.r = r / 2
        self.c = c / 2
        self.action = p
        p = self.on_switch_action
        self.pad = g
        self.gate = 0
        ColoredButton.__init__(self, n, p)

    def on_switch_action(self, _):
        """
        Reverse the switch setting.

        Call the connection operator.
        """
        x = self.gate = int(not self.gate)

        self.set_label(("+", "-")[x])
        self.action[x](CG.grid[self.r][self.c])
