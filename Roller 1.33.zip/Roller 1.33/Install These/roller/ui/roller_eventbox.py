#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForColor
import gtk


class REventBox(gtk.EventBox):
    """This is a custom GTK EventBox."""

    def __init__(self, a):
        """
        a: gtk color component
            None, int, tuple, or GTK color
        """
        super(gtk.EventBox, self).__init__()
        if a is not None:
            if isinstance(a, int):
                q = gtk.gdk.Color(a, a, ForColor.MAX_COLOR)

            elif isinstance(a, tuple):
                q = gtk.gdk.Color(*a)

            else:
                q = a
            self.modify_bg(gtk.STATE_NORMAL, q)
