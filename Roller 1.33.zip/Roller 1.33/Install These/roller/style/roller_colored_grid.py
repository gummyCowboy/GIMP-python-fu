#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForLayer, OptionKey, SessionKey
from roller_fu import Lay, Sel
from roller_layout import Img
from roller_grid import Grid
from roller_backdrop_style import BackdropStyle
import gimpfu as fu


class ColoredGrid(BackdropStyle):
    """Create a colored grid."""
    name = SessionKey.COLORED_GRID
    row = column = 1

    def __init__(
                self,
                d,
                stat,
                name=SessionKey.COLORED_GRID,
                layer_key=ForLayer.BACKDROP
            ):
        """
        Start the Colored Grid backdrop style.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        self.name = name
        active = None if name == SessionKey.COLORED_GRID else \
            Lay.get_active(stat.render)
        BackdropStyle.__init__(
            self, d, stat, layer_key=layer_key, active=active)

    def do(self, d):
        """
        Draw a colored grid over the backdrop image.

        Is part of an RenderHub class template.

        d: sub-session dict
        """
        j = self.stat.render

        if d[OptionKey.ROTATE]:
            w = self.stat.radius * 2
            r, c = d[OptionKey.ROW], d[OptionKey.COLUMN]
            d[OptionKey.COLUMN] = int(c * w / 1. / self.stat.width) + 1
            d[OptionKey.ROW] = int(r * w / 1. / self.stat.height) + 1
            j = Img.new(w, w)
            z = Lay.add(j, self.name)

        else:
            z = Lay.add(j, self.name)

        z = self.draw_color_grid(j, z, d)

        if d[OptionKey.ROTATE]:
            d[OptionKey.ROW], d[OptionKey.COLUMN] = r, c
            Lay.rotate(j, d[OptionKey.ROTATE])
            Lay.kopy(j)
            Img.bury(j)

            z = Lay.paste(self.stat.render, self.active.layer)
            Lay.clip(z)

        z.mode, z.opacity = self.get_mode(d)

        Lay.invert(z, d[OptionKey.INVERT])

        if self.name == SessionKey.COLORED_GRID:
            self.give_render_mask(z)
        z = self.active.layer = Lay.merge(self.stat.render, z)

    @staticmethod
    def draw_color_grid(j, z, d):
        """
        Draw a checkerboard with two colors.

        j: GIMP image
        z: layer
        d: sub-session dict

        Return the merged layer.
        """
        s = w, h = j.width, j.height
        r, c = d[OptionKey.ROW], d[OptionKey.COLUMN]
        odd = Grid(s, r, c)

        # Draw horizontal stripes:
        Lay.color_fill(z, (255, 255, 255))

        for r1 in range(0, r, 2):
            _, y, _, h1 = odd.cell(r1, 0)
            Sel.rect(j, 0, y, w, h1)

        Sel.fill(z, (0, 0, 0))
        Sel.none(j)

        # Draw vertical stripes:
        z1 = Lay.add(j, "v")
        z1.mode = fu.LAYER_MODE_DIFFERENCE

        Lay.color_fill(z1, (255, 255, 255))

        for c1 in range(0, c, 2):
            x, _, w, _ = odd.cell(0, c1)
            Sel.rect(j, x, 0, w, h)

        Sel.fill(z1, (0, 0, 0))

        z = Lay.merge(j, z1)
        z1 = Lay.clone(j, z)

        # Fill the b/w checkerboard:
        Sel.color(j, z1, (255, 255, 255))
        Sel.fill(z1, d[OptionKey.COLOR_1])
        Sel.kleer(j, z1)
        Lay.color_fill(z, d[OptionKey.COLOR_2])
        Sel.none(j)
        return Lay.merge(j, z1)
