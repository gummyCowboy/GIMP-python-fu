#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import PortKey, UIKey, WindowKey
from roller_port_grid import PortGrid
from roller_window import RollerWindow


class RWGrid(RollerWindow):
    """Is a GTK dialog for defining a format's cell table properties."""
    def __init__(self, g):
        """
        Create a window.

        g: RollerButton
            in action
        """
        d = {UIKey.WINDOW: g.win.win, UIKey.STAT: g.stat}
        self._button = g
        d[UIKey.WINDOW_TITLE] = "Define Cell Grid"
        d[UIKey.WINDOW_KEY] = WindowKey.RESIZE_CHOOSER

        RollerWindow.__init__(self, d)
        d.update(
            {
                UIKey.ON_ACCEPT: self.do_accept,
                UIKey.ON_CANCEL: self.do_cancel,
                UIKey.WINDOW: self,
                UIKey.PORT_KEY: PortKey.NOT_USED
            }
        )

        self.port = PortGrid(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()

    def do_accept(self, value):
        """
        Accept the image.

        value: string
            for image button

        Return: true
            The key-press is handled.
        """
        self._button.set_value(value)
        return self.close()

    def do_cancel(self, *_):
        """
        Close the window.

        Return: true
            The key-press is handled.
        """
        return self.close()
