#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_format_cell_table import CellTable
from roller_one_constant import Signal
from roller_port import Port
from roller_widget_check_button import RollerCheckButton


class PerCellCheckButton(RollerCheckButton):
    """
    Is a custom GTK CheckButton.

    Is attached to its own Alignment.
    """
    ATTRIBUTE = 'checkbutton_action', 'port', 'widgets'

    def __init__(self, **d):
        """
        Create a CheckButton and an Alignment.

        d: dict
            Has keyword arguments for Widget.
        """
        self.expose_handler = None

        for i in PerCellCheckButton.ATTRIBUTE:
            setattr(self, i, d[i])

        self._get_format_info = d['get_format_info']
        d['text'] = "Per Cell"
        self._button = d['button']
        d['on_widget_change'] = self.on_check_button_change
        self._verify_widget = None
        self.value = []

        RollerCheckButton.__init__(self, **d)

        for g in self.widgets:
            if hasattr(g, 'verify') and g.verify:
                self._verify_widget = g
                break

        self.dependent = [self.verify_widgets]

        # Act when its sub-navigation list-item is selected:
        self.connect_event((self.port, Signal.VISIBILITY_CHANGE))

        self.connect_expose()

    def get_value(self):
        """
        Return: 2D list
            of cell table
        """
        return deepcopy(self.value)

    def on_check_button_change(self, g):
        """
        Intercept signals from the CheckButton.

        g: CheckButton widget
            active in user-interface
        """
        if not self.widget.get_active():
            self.value = []

        else:
            if not Port.loading:
                self.value = CellTable.init_cell_table(
                    self._get_format_info()[0],
                    self.key,
                    self.stat
                )

        self.verify_widgets(g)
        self.checkbutton_action(g)

    def set_value(self, q):
        """
        Set the CheckButton checked state.

        Is part of the Widget template.

        q: 2D lists
            of cell table
        """
        b = len(q) > 0
        self.widget.set_active(b)
        self.value = q

    def connect_expose(self):
        """
        Use the expose event to update the group
        when switching formats from the main port.
        """
        # Update when there's no visibility change:
        if not self.expose_handler:
            self.expose_handler = self.widget.connect(
                'expose-event', self.expose_widgets
            )

    def expose_widgets(self, *_):
        """
        The expose is useful when the format port
        first draws, or is loading a new format.
        """
        self.verify_widgets()
        if self.expose_handler:
            self.widget.disconnect(self.expose_handler)
            self.expose_handler = None

    def verify_widgets(self, *_):
        """
        Verify the widgets dependent on the per cell CheckButton.

        at times, g: RollerCheckButton
            on call
        """
        if not Port.loading:
            value = self.widget.get_active()
            self._button.enable() if value else self._button.disable()

            for g1 in self.widgets:
                if value:
                    g1.hide()

                else:
                    g1.show()

            if not value:
                if self._verify_widget:
                    self._verify_widget.verify(self._verify_widget)
            self.win.resize()
