#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import (
    BrushKey as br,
    ForWidget as fw,
    FringeKey as fr,
    UIKey
)
from roller_one_preset import Preset
from roller_port import Port
from roller_widget_slider import RollerSlider
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_button import OptionButton
from roller_widget_table import RollerTable
from roller_window_choice import RWChoice
import gtk

SAME_SIZE_BRUSH = (
    br.ANGLE,
    br.SIZE,
    br.HARDNESS,
    br.OPACITY,
    br.SPACING
)


class PortBrushChoice(Port):
    """Provide widgets for defining a brush settings."""

    def __init__(self, d, g):
        """
        Create the port by drawing widgets.

        g: OptionButton
            Has values.
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self._dict = g.get_value()
        self._button = g
        self.stat = g.stat
        Port.__init__(self, d)

    def _draw_brush_group(self, g):
        """
        Draw the noise bump options.

        g: GTK container
            to receive group
        """
        d = dict(
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
        )
        q = [
            [
                "Brush Size:",
                RollerSlider,
                dict(
                    d,
                    key=br.SIZE,
                    limit=(10, 10000),
                )
            ],
            [
                "Brush Spacing:",
                RollerSlider,
                dict(
                    d,
                    key=br.SPACING,
                    limit=(10, 10000)
                )
            ],
            [
                "Brush Opacity:",
                RollerSlider,
                dict(
                    d,
                    key=br.OPACITY,
                    limit=(0, 100)
                )
            ],
            [
                "Brush Angle:",
                RollerSlider,
                dict(
                    d,
                    key=br.ANGLE,
                    limit=(-180, 180)
                )
            ],
            [
                "Brush Hardness:  ",
                RollerSlider,
                dict(
                    d,
                    key=br.HARDNESS,
                    limit=(.001, 1),
                    precision=3
                )
            ],
            [
                "Brush",
                OptionButton,
                dict(
                    d,
                    choice_window=RWChoice,
                    color=self.color,
                    key=br.BRUSH,
                    stat=self.stat,
                    win=self.roller_window
                ),
            ]
        ]
        e = RollerTable.create(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        self.controls = [e[i] for i in e]
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        for i in SAME_SIZE_BRUSH:
            same_size.add_widget(e[i].spin_button)

    def _draw_preset_group(self, g):
        """
        Draw a preset group for the cell grid.

        g: VBox
            container for widgets
        """
        self.preset = Preset(
            container=g,
            key=fr.BRUSH,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

    def do_accept(self, *_):
        """
        Accept the choice.

        Return: true
            The key-press is handled.
        """
        return self.do_accept_callback(self.preset.get_value())

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = (
            self._draw_brush_group,
            self._draw_preset_group,
            self.draw_process_group
        )
        group_name = "Brush Settings", "Brush Preset", "Process"

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)
            vbox.pack_start(
                RollerLabel(
                    padding=(2, 0, 4, fw.MARGIN),
                    text=group_name[x] + ":"
                ),
                expand=False
            )
            p(vbox)
            self.reduce_color()

            if x in (0, 1):
                hbox = gtk.HBox()
                g.pack_start(hbox, expand=True)
            hbox.pack_start(box, expand=True)

        self.preset.widget_list = self.controls
        self.preset.load_preset(fw.UNDEFINED, self._dict)

    def on_widget_change(self, g):
        """
        Call when a widget is changed.

        g: Widget
            Is responsible.
        """
        if not Port.loading:
            self.preset.preset_is_undefined()
