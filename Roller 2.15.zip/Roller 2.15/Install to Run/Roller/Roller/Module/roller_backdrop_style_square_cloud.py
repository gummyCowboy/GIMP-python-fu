#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay
import gimpfu as fu

er = Fu.Erode
pdb = fu.pdb
COLOR = (0, 255, 255), (255, 255, 0), (255, 0, 255)


class SquareCloud:
    """Make a cloud of bright squares."""

    def __init__(self, one):
        """
        Create a Square Cloud backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        d = one.d
        parent = one.z.parent
        group = Lay.group(j, one.k, parent=parent)
        base = Lay.add(
            j,
            one.z.name,
            parent=parent,
            offset=pdb.gimp_image_get_item_position(j, one.z)
        )

        pdb.gimp_image_reorder_item(j, base, group, 0)

        z = Lay.clone(j, base)

        pdb.plug_in_plasma(
            j,
            z,
            d[ok.RANDOM_SEED],
            Fu.Plasma.MEDIUM_TURBULENCE
        )

        z1 = Lay.clone(j, z)

        for i in range(10):
            Lay.dilate(j, z1)
            pdb.plug_in_erode(
                j,
                z,
                er.PROPAGATE_OPAQUE,
                er.RGB_CHANNELS,
                er.FULL_RATE,
                er.RGB_CHANNELS,
                er.LOW_LIMIT_0,
                er.UPPER_LIMIT_255
            )

        pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
        pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
        Lay.color_fill(base, (127, 127, 127))

        z2 = Lay.clone(j, base)
        z2.mode = fu.LAYER_MODE_HSV_SATURATION

        pdb.gimp_image_reorder_item(j, z2, group, 0)

        z3 = Lay.clone(j, z)
        z3.mode = fu.LAYER_MODE_OVERLAY
        z3.opacity = 75.

        pdb.gimp_image_reorder_item(j, z3, group, 0)

        z4 = Lay.clone(j, z3)
        z4.mode = fu.LAYER_MODE_DARKEN_ONLY
        z4.opacity = 30.
        z = Lay.merge_group(j, group)
        z1 = Lay.clone(j, z)
        z1.opacity = 50.
        pdb.plug_in_colorify(j, z1, d[ok.COLOR])
