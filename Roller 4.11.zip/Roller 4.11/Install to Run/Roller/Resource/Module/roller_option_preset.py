#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Signal as si
from roller_constant_key import (
    BackdropStyle as by,
    Button as bk,
    Frame as ff,
    Group as gk,
    Item as ie,
    Option as ok,
    Pickle as pc,
    Step as sk,
    Widget as wk
)
from roller_def import get_default_value, get_init, get_group_keys, get_vote_d
from roller_one_oz import get_preset_path, pickle_load
from roller_one_extract import get_option_list_key, get_node_row
from roller_one_the import The
from roller_port_tree import DEFAULT_MODEL_BRANCH, SPLIT_KEY
from roller_view_step import (
    get_branch_value_d,
    make_panel_key,
    make_step_key,
    translate_to_id,
    translate_to_name
)
from roller_widget_button import ManagePresetButton, SaveButton
from roller_widget_node import add_node_to_list
from roller_widget_row import WidgetRow
from roller_port_preset import PortPreset
from roller_port_save import PortSave
import os


def add_to_d(d, e):
    """
    Recursively add missing dict items to a loaded
    dict using a default dictionary as a source.

    d: dict
        receiver

    e: dict
        default
    """
    for i, value in e.items():
        if i == ok.PRESET:
            pass
        elif i not in d:
            d[i] = value
        else:
            if e and i in e:
                a, b = isinstance(d[i], dict), isinstance(value, dict)

                if a and b:
                    add_to_d(d[i], value)
                elif a or b:
                    d[i] = value


def fix_preset(d, e, any_group):
    """
    Recursively synchronize a loading
    Preset with its default Preset values.

    d: dict
        loading Preset

    e: dict
        default Preset

    any_group: AnyGroup
        owner of the option
    """
    if not (any_group.item.item == ie.TYPE and ok.PER_CELL in d):
        # Has a Preset dict for Per Cell cell value.
        sync_per_cell(d, e)
        sync_option_list(d, e)
    sync_preset(d, e)


def get_model_default_value(any_group):
    """
    Create a SuperPreset with a Model's default value.

    group_key: string
        Identify Model SuperPreset.

    Return: dict
        Model specific SuperPreset
    """
    d = {}
    group_key = any_group.item.key
    model_type = group_key.split(",")[1].strip()
    name = The.model_id.get_name(any_group.item.model.model_id)

    # the default Model branch list, 'q'
    q = DEFAULT_MODEL_BRANCH[model_type]

    for i in q:
        if i[-1] not in SPLIT_KEY:
            e = get_default_value(i[-1])
        else:
            e = get_default_value(make_split_key(model_type, i[-1]))
        d[sk.EXTRA + (name,) + i] = e

    d[sk.EXTRA + (name,)] = None
    return d


def get_option_default_value(any_group):
    """
    Get the default value for an option.

    any_group: AnyGroup
    """
    return get_default_value(any_group.item.key)


def get_steps_default(any_group):
    """
    Make a Steps Preset having default value.

    any_group: AnyGroup
        not used
    """
    return {
        sk.GROUP_2_STEP_D[i]: get_default_value(i)
        for i in sk.GROUP_2_STEP_D
    }


def load_model_step(d):
    """
    Load Widget value for a Model SuperPreset.

    d: dict
        SuperPreset
    """
    q = get_node_row(d)

    load_super(d)

    # Some groups don't load until after another group does.
    if d.keys():
        load_super(d)

    # Select row after the navigation tree is loaded. The
    # UI appears as it was when the SuperPreset was saved.
    for node, row in q:
        node.select_row(row)


def load_option_preset(d):
    """
    Load the Preset option and select Node row.

    d: dict
        SuperPreset
    """
    q = get_node_row(d)

    load_super(d)

    # Select row after the navigation tree is loaded. The
    # UI appears as it was when the SuperPreset was saved.
    for node, row in q:
        node.select_row(row)


def load_steps_preset(d):
    """
    There are two phases to loading a Steps SuperPreset:

    (1) Create the option groups.
    (2) Load the option group values.

    d: dict
        {key: step, value: group dict}
    """
    # list of loading step, 'q'
    q = d.keys() + [sk.PRESET_STEPS]

    # list of loading step key with Node step key, 'q'
    add_node_to_list(q)

    d = translate_to_id(d)
    q = get_node_row(d)

    load_super(d)

    # Select row after the navigation tree is loaded. The
    # UI appears as it was when the SuperPreset was saved.
    for node, row in q:
        node.select_row(row)


def load_super(d):
    """
    Load Widget from a SuperPreset dictionary.

    d: dict
        SuperPreset
        {navigation step key: AnyGroup value dict}
    """
    # Set the values of the options.
    # an AnyGroup value dict, 'e'
    helm = The.helm

    # navigation step key, 'k'
    for k in d.keys():
        any_group = helm.get_group(k)
        if any_group:
            e = d[k]
            if any_group.item.group_type == 'preset':
                fix_preset(e, get_default_value(any_group.item.key), any_group)
                d.pop(k)
                for k1, a in e.items():
                    any_group.widget_d[k1].set_a(a)


def make_split_key(model_type, item_key):
    """
    When Preset diverge on a common item key,
    the Model key is used to create the key.
    For example, the Table Property Preset
    has a group key, "Property, Table".

    model_type: string
        Identify Model.

    item_key: string
        Is used by Node.

    return: string
        group key formatted as a split key
    """
    return "{}, {}".format(item_key, model_type)


def remove_from_d(d, e):
    """
    Recursively remove invalid dict item from a loaded
    dict using a default dictionary for comparison.

    d: dict
        to check

    e: dict
        of default
    """
    # In some cases, 'e' is empty for the Shadow SuperPreset.
    if e:
        q = [i for i in d if i != ok.PRESET]
        for i in q:
            # The Shadow SuperPreset loads keys with tuples.
            if not isinstance(i, tuple):
                if i not in e:
                    d.pop(i)
                else:
                    a = isinstance(d[i], dict)
                    b = isinstance(e[i], dict)

                    if a and b:
                        remove_from_d(d[i], e[i])
                    elif a or b:
                        d[i] = e[i]
            else:
                # Leave the tuple key. It could be a Node selection.
                if i in e:
                    a = isinstance(d[i], dict)
                    b = isinstance(e[i], dict)

                    if a and b:
                        remove_from_d(d[i], e[i])
                    elif a or b:
                        d[i] = e[i]


def sync_preset(d, e):
    """
    Recursively synchronize a Preset with its default Preset value.

    d: dict
        loading Preset

    e: dict
        default Preset
    """
    remove_from_d(d, e)
    add_to_d(d, e)


def sync_option_list(d, e):
    """
    Recursively synchronize a Preset with its default
    Preset, but only for the OptionList option.

    d: dict
        loading Preset

    e: dict
        default Preset
    """
    for i in d:
        k = None

        if i in (ok.BACKDROP_STYLE, ok.FRAME):
            if i == ok.FRAME:
                k = get_option_list_key(d[i])
                if k not in ff.KEY_LIST:
                    # Replace a missing Frame option.
                    k = ff.KEY_LIST[0]

            elif i == ok.BACKDROP_STYLE:
                k = get_option_list_key(d[i])
                if k not in by.KEY_LIST:
                    # Replace a missing Backdrop Style option.
                    k = by.KEY_LIST[0]
            e[i] = {k: get_default_value(k), ok.SWITCH: 0}
        else:
            if i in e:
                if isinstance(d[i], dict) and isinstance(e[i], dict):
                    sync_option_list(d[i], e[i])


def sync_per_cell(d, e):
    """
    Synchronize a loading Preset with its default Preset values for Per Cell.

    d: dict
        loading Preset

    e: dict
        default Preset

    any_group: AnyGroup
        owner of the option
    """
    if ok.PER_CELL in d:
        for r_c, d1 in d[ok.PER_CELL].items():
            sync_option_list(d1, e)
            sync_preset(d1, e)


def update_model_tree(any_group, d):
    """
    When loading a Model Preset, the navigation
    tree is transformed by the incoming step list.
    """
    # list of Model that are referenced in the load dict, 'model_def'
    model_def = []

    get_group = The.helm.get_group
    get_branch_step_q = The.helm.get_branch_step_q

    # list of panel step key, 'step_q'
    step_q = d.keys()

    node = get_group(sk.EXTRA).item.node
    name = The.model_id.get_name(any_group.item.model.model_id)

    # list of online Model name, 'name_q'
    name_q = node.get_label_q()[1:]

    # ModelList definition with all Models,
    # offline and online Model definition list, 'all_def'
    all_def = get_group(sk.MODEL).widget_d[ok.MODEL_LIST].get_model_def()

    for model_name, model_type in all_def:
        if model_name in name_q:
            model_def += [(model_name, model_type)]

    for i in name_q:
        if i != name:
            q = get_branch_step_q(sk.EXTRA + (The.model_id.get_id(i),))
            for i1 in q:
                step_q += [make_panel_key(i1)]
        else:
            i1 = sk.EXTRA + (name,) + (ie.PRESET,)
            if i1 not in step_q:
                step_q += [i1]

    # Update the navigation tree.
    node.emit(si.UPDATE_TREE, (step_q + sk.DEFAULT_STEP, model_def))


class Preset(WidgetRow):
    """Use to manage option group Presets."""

    def __init__(self, **d):
        """
        Create an option group Preset.

        d: dict
            Has keyword arguments.
        """
        self.group_key = d[wk.ITEM].key

        # A SuperPreset does not have a default value.
        self._default_value = get_default_value(self.group_key)

        d.update(
            {wk.SUB: OrderedDict([
                (bk.MANAGE_PRESET, {
                    wk.DIALOG: PortPreset,
                    wk.WIDGET: ManagePresetButton
                }),
                (bk.SAVE_PRESET, {
                    wk.DIALOG: PortSave,
                    wk.WIDGET: SaveButton
                })
            ])}
        )
        WidgetRow.__init__(self, **d)

    def get_a(self):
        """Return the Preset dictionary."""
        d = OrderedDict()
        e = self.any_group.widget_d

        for i in get_group_keys(self.group_key):
            d[i] = e[i].get_a()
        return d

    @staticmethod
    def get_default_value(k):
        """
        Is here as a routing mechanism for a circular conversation.

        k: string
            option group key

        Return: dict or None
            with default value
        """
        return get_default_value(k)

    @staticmethod
    def get_init_d(k):
        """
        Is here as a routing mechanism for a circular conversation.

        k: string
            option group key

        Return: dict
            with group init variable
        """
        # group init dict index, '0'
        return get_init(k)[0]

    @staticmethod
    def get_vote_d(k):
        """
        Is here as a routing mechanism for a circular conversation.

        k: string
            option group key

        Return: dict
            with group vote dict
        """
        return get_vote_d(k)

    @staticmethod
    def load_default(d, k):
        """
        Load the default settings for a group.

        d: dict
            of Widgets

        k: string
            group key
        """
        e = get_default_value(k)
        for i in e:
            if i in d:
                d[i].set_a(e[i])

    def load_file(self, n, group_key):
        """
        Load a Preset dict.

        n: string
            name of Preset; a key

        group_key: string
            integral to path

        Return: dict
            the loaded Preset
        """
        file_path = get_preset_path(group_key, n, The.preset_folder)

        if os.path.isfile(file_path):
            # Preset dict, 'd'
            d = pickle_load({pc.FILE: file_path, pc.SHOW_ERROR: True})

        else:
            # If the Preset is a SuperPreset, then it's an empty list, 'd'.
            d = get_default_value(group_key)

        self.set_a(d)
        return d

    @staticmethod
    def load_super(d):
        """
        Is here as a routing mechanism for a circular import problem.

        d: dict
            SuperPreset
        """
        load_super(d)

    def set_a(self, d):
        """
        Load a Preset from a dictionary.

        d: dict
            incoming Preset
        """
        e = self.any_group.widget_d
        q = e.keys()

        fix_preset(d, self._default_value, self.any_group)

        q1 = d.keys()
        [e[i].set_a(d[i]) for i in q if i in q1]

    def set_per_cell_less(self, d):
        """
        Load a Preset from a dictionary. The Per Cell option is ignored.

        d: dict
            incoming Preset
        """
        e = self.any_group.widget_d
        q = e.keys()

        fix_preset(d, self._default_value, self.any_group)

        q1 = d.keys()
        [e[i].set_a(d[i]) for i in q if i in q1 and i != ok.PER_CELL]


class SuperPreset(Preset):
    """Is made from combined Presets."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword init values.
        """
        self._default_super_d = {
            gk.PRESET_STEPS: get_steps_default,
            gk.PRESET_BOX: get_model_default_value,
            gk.PRESET_CELL: get_model_default_value,
            gk.PRESET_STACK: get_model_default_value,
            gk.PRESET_TABLE: get_model_default_value,
            gk.SHADOW_PRESET: get_option_default_value
        }
        Preset.__init__(self, **d)

    def get_a(self):
        """
        Assemble a SuperPreset dictionary. Use when saving a SuperPreset.

        Return: dict
            of SuperPreset
            key: step; value: option group dict
        """
        k = () if self.group_key == gk.PRESET_STEPS \
            else self.any_group.step_key[:-1]
        d = get_branch_value_d(k)
        return translate_to_name(d)

    @staticmethod
    def get_init(*_):
        """A SuperPreset group init is empty having no Widget."""
        return {}, []

    def set_a(self, d):
        """
        Override the 'set_a' function in the Preset class.

        d: dict
            SuperPreset
        """
        The.load_count += 1

        if not d:
            # Use default dict.
            d = deepcopy(self._default_super_d[self.group_key](self.any_group))

        elif self.group_key in gk.SUPER_MODEL:
            # SuperPreset key is in panel step key format.
            # Replace old Model name with this Model name.
            e = {}
            n = The.model_id.get_name(self.any_group.item.model.model_id)

            for i in d.keys():
                e[make_panel_key(i, model_name=n)] = d[i]
            d = e

        if self.group_key in gk.SUPER_MODEL:
            update_model_tree(self.any_group, d)

            # Convert to navigation step key for loading Preset.
            for i in d.keys():
                d[make_step_key(i)] = d[i]
                d.pop(i)

        ROUTE[self.group_key](d)
        The.load_count -= 1


ROUTE = {
    gk.PRESET_STEPS: load_steps_preset,
    gk.PRESET_BOX: load_model_step,
    gk.PRESET_CELL: load_model_step,
    gk.PRESET_PYRAMID: load_model_step,
    gk.PRESET_STACK: load_model_step,
    gk.PRESET_TABLE: load_model_step,
    gk.SHADOW_PRESET: load_option_preset
}
