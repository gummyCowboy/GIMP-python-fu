#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from datetime import datetime
from random import randint, seed
from roller_constant_for import Color as co
import colorsys
import gimpfu as fu

pdb = fu.pdb


def convert_to_rgb(color):
    """
    Convert gtk.gdk.Color to RGB.

    color: gtk.gdk.Color
        to convert

    Return: RGB
        color
    """
    if isinstance(color.red, int):
        return tuple(
            [i // 257 for i in (color.red, color.green, color.blue)]
        )


def enumerate_name(n, q):
    """
    Enumerate a name given a list of names.
    Ensure the name is unique to the list.

    n: string
        name to check

    q: list
        list of name
        of string

    Return: string
        the enumerated name
    """
    while n[-1].isdigit():
        n = n[:-1]

    n = n.strip()
    a = 1

    while 1:
        n1 = n + " " + str(a)

        if n1 in q:
            a += 1
        else:
            break
    return n1


def hsv_to_rgb(q):
    """
    Convert HSV to RGB.

    q: iterable
        HSV
        in .0 to 1.

    return: tuple
        RGB
        in 0. to 255.
    """
    return tuple([int(round(i1 * 255)) for i1 in colorsys.hsv_to_rgb(*q)])


def make_2d_table(r, c, init=0):
    """
    Return a 2D list.

    r, c: int
        size of the 2D table

    init: value
        to init table with

    deep: bool
        When it is True, the init value is deep-copied.
    """
    table = init

    for a in (c, r):
        table = [deepcopy(table) for _ in range(a)]
    return table


def random_rgb():
    """Return a tuple of integer containing random colors (r, g, b)."""
    return randint(0, 255), randint(0, 255), randint(0, 255)


def random_rgba():
    """
    Return a tuple of integer containing
    random color components (r, g, b, a).
    """
    return random_rgb() + (randint(0, 255),)


def reduce_color(color):
    """
    'color' is used by the red and green color
    components. Use when drawing a gtk.EventBox.

    color: tuple
        RGB
    """
    return color - co.COLOR_DEC


def rgb_to_hsv(q):
    """
    Convert RGB to HSV.

    q: iterable
        of int
        RGB

    Return: tuple
        HSV
            float in .0 to 1.
            float in .0 to 1.
            float in 0. to 255.
    """
    return colorsys.rgb_to_hsv(*[(i / 255.) for i in q])


def seal(a, b, c):
    """
    Limit a numeric value to be between two numbers.

    a: value
        to limit

    b: value
        minimum amount

    c: value
        maximum amount

    Return: value
        within seal
    """
    return max(min(c, a), b)


def seed_random():
    """Use a float to randomize Python random number generator."""
    seed(float(datetime.now().microsecond))
