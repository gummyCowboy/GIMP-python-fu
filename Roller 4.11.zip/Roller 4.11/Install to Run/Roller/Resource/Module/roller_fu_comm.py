#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gimpfu as fu
import gtk

pdb = fu.pdb


def info_msg(n, handler=fu.ERROR_CONSOLE):
    """
    Use to output a message to the user.

    n: value
        message

    handler: GIMP enum
        0 - fu.MESSAGE_BOX
        1 - fu.CONSOLE
        2 - fu.ERROR_CONSOLE
    """
    a = pdb.gimp_message_get_handler()
    n = n if isinstance(n, str) else repr(n)

    pdb.gimp_message_set_handler(handler)
    fu.gimp.message(n)
    pdb.gimp_message_set_handler(a)


def pop_up(window, x, n, title):
    """
    Display a message dialog.

    window: window
        GTK window
        parent

    x: int
        message type index
        (question, info)
        0, 1

    n: string
        message

    title: string
        window title

    Return: flag
        Is true if the user responded with yes.
    """
    g = gtk.MessageDialog(
        parent=window,
        flags=gtk.DIALOG_MODAL,
        type=(gtk.MESSAGE_QUESTION, gtk.MESSAGE_INFO)[x],
        buttons=(gtk.BUTTONS_YES_NO, gtk.BUTTONS_CLOSE)[x],
        message_format=n
    )

    g.set_title(title)

    a = g.run()

    g.destroy()
    return int(a == gtk.RESPONSE_YES)


def show_err(a):
    """
    Post an error message to GIMP's error console.

    a: Exception or string
        to show
    """
    # Python 3 does not have basestring.
    if not isinstance(a, basestring):
        a = repr(a)
    info_msg(a)
