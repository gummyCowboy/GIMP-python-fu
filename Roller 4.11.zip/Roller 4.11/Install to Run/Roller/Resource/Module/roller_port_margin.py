#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_port_preview import PortPreview
from roller_widget_node import Piece


class PortMargin(PortPreview):
    """Is a display container for the Margin Preset."""
    window_key = "Margin"

    def __init__(self, d, g):
        """
        d: dict
            Has init values.

        g: OptionButton
            Has option values.
        """
        PortPreview.__init__(self, d, g)

    def _draw_margin(self, box):
        """
        Draw the Margin option group.

        box: VBox
            container for Widgets
        """
        self.draw_group(Piece(ok.MARGIN, box, self.safe.any_group.item))

    def draw(self):
        """Draw Widget."""
        self.draw_column((self._draw_margin, self.draw_process))

    def get_group_value(self):
        """
        Get the Preset value.

        Return: dict
            Margin Preset
        """
        return self.preset.get_a()
