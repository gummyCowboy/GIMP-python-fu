#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Frame as ek, Option as ok
from roller_frame import Filler, Noise, do_filler_frame, make_frame_group
from roller_frame_build import Build
from roller_fu import (
    blur_selection, clone_layer, color_fill_selection, merge_layer, select_rect
)
from roller_maya_blur_behind import BlurBehind
from roller_maya import check_metal_frame_cake, check_matter
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_one import random_rgb
from roller_one_gegl import saturation
from roller_view_preset import combine_seed
from roller_view_real import FILLER, LIGHT, do_rotated_layer, get_light
import gimpfu as fu

pdb = fu.pdb


def do_filler(v, maya):
    """
    Make Stained Glass material.

    v: View
    maya: StainedGlass
    Return: layer
        with filler material
    """
    j = v.j
    d = maya.value_d
    group = maya.group

    combine_seed(v, d)

    z = do_rotated_layer(v, d, draw_color, group, get_light(maya))
    z = clone_layer(z)

    # amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(j, z, 1., 0, 0)

    # Remove the color.
    saturation(z, .0)

    # Convert to white line on black. Curves work
    # better than threshold as curves provides smoothing.
    # four coordinates, '4'
    pdb.gimp_drawable_curves_spline(
        z, fu.HISTOGRAM_VALUE, 4, (.0, .0, .05, 1.)
    )

    # Convert the layer to be a black edge on white material.
    pdb.gimp_drawable_invert(z, 0)

    # Soften the line.
    blur_selection(z, 2.)

    z.mode = fu.LAYER_MODE_DARKEN_ONLY
    z = merge_layer(z)

    saturation(z, .85)

    z.name = z.parent.name + " Stained Glass"
    return z


def draw_color(z, d):
    """
    Draw two layers of color stripes in order to create color rectangles.

    z: layer
        layer to draw on

    d: dict
        Stained Glass Preset
        {Option key: value}

    Return: layer
        Has color grid.
    """
    # vertical panes
    j = z.image
    x = y = x1 = y1 = 0
    w1, h1 = j.width, j.height
    z.mode, z.opacity = fu.LAYER_MODE_NORMAL, 100.
    w = d[ok.GLASS_PANE_W]

    while x < w1:
        x1 = min(x1 + w, w1)

        select_rect(j, x, 0, x1 - x, h1)
        color_fill_selection(z, random_rgb())
        x = x1

    z = clone_layer(z, n="Difference")
    z.mode = fu.LAYER_MODE_DIFFERENCE

    # horizontal panes
    while y < h1:
        y1 = min(y1 + w, h1)

        select_rect(j, 0, y, w1, y1 - y)
        color_fill_selection(z, random_rgb())
        y = y1
    return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)


class StainedGlass(Build):
    """Is a frame with colorful transparent glass."""
    FRAME_K = ek.STAINED_GLASS
    is_seeded = is_embossed = True
    issue_q = 'cake', 'matter', 'shade',
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_metal_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)

        """
        self.filler_sel = None
        self.do_matter = do_filler_frame

        Build.__init__(
            self,
            any_group,
            super_maya,
            k_path=[k_path, k_path + (ok.FNR, ok.FRAME_METAL)]
        )

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.FNR, ok.NOISE_D)
        )
        self.sub_maya[FILLER] = Filler(
            any_group, self, do_filler, k_path, is_lucid=True
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group,
            self,
            (self.cause, self, self.sub_maya[FILLER]),
            k_path + (ok.SRR, ok.SHADOW)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(
            any_group, self.sub_maya[FILLER], k_path
        )

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        filler = self.sub_maya[FILLER]
        self.is_matter |= is_change

        self.realize(v)
        filler.do(v, d, self.is_matter)
        self.sub_maya[ok.NOISE_D].do(v, d[ok.FNR][ok.NOISE_D], self.is_matter)

        m = self.sub_maya[ok.SHADOW].do(
            v,
            d[ok.SRR][ok.SHADOW],
            self.is_matter + self.is_cake,
            is_change + self.cause.is_cake
        )

        self.sub_maya[ok.BLUR_BEHIND].do(
            v, d, m or is_back, self.is_matter
        )
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m

    def reset(self):
        """Call when the View image is removed."""
        self.filler_sel = None
        super(StainedGlass, self).reset()
