#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import (
    BackdropStyle as bs, Gradient as fg, Issue as vo
)
from roller_constant_key import Option as ok, Widget as wk
from roller_def_share import (
    BBR,
    BLOCK_H,
    BLOCK_W,
    BLUR,
    BRR,
    BSR,
    CLIP,
    COLOR_1,
    COLOR_2A,
    CRITERION,
    ANGLE,
    END_X,
    END_Y,
    FILL_MODE,
    FLIP,
    GRADIENT_ANGLE,
    GBR,
    GRADIENT,
    GRADIENT_MODE,
    GRADIENT_TYPE,
    IFR,
    IFRW,
    IKR,
    INVERT,
    IRK,
    IRR,
    MESH_SIZE,
    MESH_TYPE,
    MODE,
    NEATNESS,
    NOISE_AMOUNT,
    OFFSET,
    OPACITY,
    PATTERN,
    P3R,
    R_C,
    SATURATION,
    SEED,
    START_X,
    START_Y,
    SUPERPIXEL_SIZE,
    THRESHOLD,
    make_radio_tip,
    make_rainbow_count_tip,
    make_rainbow_tip,
    make_text_tip,
    set_issue
)
from roller_one_tip import Tip
from roller_widget_button import RandomColorButton
from roller_widget_check_button import CheckButtonRandom
from roller_widget_combo import ComboBox
from roller_widget_entry import Entry
from roller_widget_slider import RandomSlider
from roller_widget_radio import RadioRow
from roller_widget_row import Rainbow


def get_component_list():
    return bs.COMPONENT


def get_news_type_list():
    return bs.NEWS_TYPE


def get_spiral_mod_list():
    return bs.SPIRAL_MOD_LIST


def get_vector_list():
    return bs.VECTOR


MAZE = {
    wk.LIMIT: (4, 999),
    wk.PAGE_INCR: 2,
    wk.RANDOM: (4, 50),
    wk.TIPPER: make_text_tip,
    wk.VAL: 10,
    wk.WIDGET: RandomSlider
}

# Acrylic Sky_______________________________________
ACRYLIC_SKY = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SHIFT_GEGL, {
        wk.LIMIT: (0, 200),
        wk.RANDOM: (0, 200),
        wk.TIPPER: make_text_tip,
        wk.VAL: 200,
        wk.WIDGET: RandomSlider
    }),
    (ok.SUPERPIXEL_SIZE, deepcopy(SUPERPIXEL_SIZE)),
    (ok.SEED, deepcopy(SEED)),
    (ok.SHIFT_DIRECTION, {
        wk.TEXT: bs.SHIFT_DIRECTION,
        wk.RANDOM: (0, 1),
        wk.TIPPER: make_radio_tip,
        wk.VAL: 1,
        wk.WIDGET: RadioRow
    }),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Carbon 14_____________________________
CARBON_14 = OrderedDict([
    (ok.MESH_TYPE, deepcopy(MESH_TYPE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.MESH_SIZE, deepcopy(MESH_SIZE)),
    (ok.NEATNESS, deepcopy(NEATNESS)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Clay Chemistry__________________________________
CLAY_CHEMISTRY = OrderedDict([
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (ok.GRADIENT, deepcopy(GRADIENT)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Color Fill____________________________
COLOR_FILL = OrderedDict([
    (ok.CRITERION, deepcopy(CRITERION)),
    (ok.FILL_MODE, deepcopy(FILL_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.THRESHOLD, deepcopy(THRESHOLD)),
    (ok.START_X, deepcopy(START_X)),
    (ok.START_Y, deepcopy(START_Y)),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.COLOR_1A, {
        wk.HAS_ALPHA: True,
        wk.TIPPER: make_text_tip,
        wk.VAL: (127, 127, 127, 255),
        wk.WIDGET: RandomColorButton
    }),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Color Grid__________________________
COLOR_GRID = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BRR, deepcopy(BRR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Core Design_______________________
CORE_DESIGN = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.IRR, deepcopy(IRR)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.GBR, deepcopy(GBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Crystal Cave______________________
CRYSTAL_CAVE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRR, deepcopy(BRR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Cube Pattern_______________________
CUBE_PATTERN = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.HEIGHT_CLIP, deepcopy(CLIP)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.IFRW, deepcopy(IFRW)),
    (ok.COLOR_3A, {
        wk.BUTTON_COUNT: 3,
        wk.HAS_ALPHA: True,
        wk.TIPPER: make_rainbow_tip,
        wk.VAL: (
            (24, 104, 174, 255),
            (217, 165, 179, 255),
            (198, 215, 235, 255)
        ),
        wk.WIDGET: Rainbow
    }),
    (ok.BRR, deepcopy(BRR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Cubism Cover__________________________________
CUBISM_COVER = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.TILE_SIZE, {
        wk.LIMIT: (2., 256.),
        wk.RANDOM: (7., 45.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 20.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SATURATION, deepcopy(SATURATION)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Dark Fort_________________________
DARK_FORT = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRR, deepcopy(BRR))
])

for i in (ok.ROW, ok.COLUMN):
    DARK_FORT[i][wk.RANDOM] = 4, 16
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Density Gradient__________________________________________________________
DENSITY_GRADIENT = OrderedDict([
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.GRADIENT_MODE, deepcopy(GRADIENT_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.GBR, deepcopy(GBR))
])
DENSITY_GRADIENT[ok.GRADIENT_ANGLE][wk.VAL] = fg.TOP_CENTER_TO_BOTTOM_CENTER
DENSITY_GRADIENT[ok.GRADIENT_MODE][wk.VAL] = "Luma Lighten Only"
DENSITY_GRADIENT[ok.GBR][wk.SUB][ok.GRADIENT][wk.VAL] = \
    "Desert Sunset"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Drop Zone_____________________________________________________________
DROP_ZONE = OrderedDict([
    (ok.NAME, {
        wk.TIPPER: make_text_tip,
        wk.VAL: "Drop Zone",
        wk.WIDGET: Entry
    }),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.STEPS_DROP_ZONE, {
        wk.LIMIT: (2, 100),
        wk.RANDOM: (2, 12),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.STEPS_DROP_ZONE,
        wk.VAL: 12,
        wk.WIDGET: RandomSlider
    }),
    (ok.IKR, deepcopy(IKR)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BRR, deepcopy(BRR))
])
DROP_ZONE[ok.COLOR_2A][wk.VAL] = (187, 187, 187, 255), (64, 64, 64, 255)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Etch Sketch____________________________________________________________
ETCH_SKETCH = OrderedDict([
    (ok.SKETCH_TEXTURE, {
        wk.FUNCTION: get_news_type_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: bs.DOT,
        wk.WIDGET: ComboBox
    }),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.CELL_SIZE, {
        wk.LIMIT: (1, 1500),
        wk.PAGE_INCR: 10,
        wk.RANDOM: (1, 100),
        wk.TIPPER: make_text_tip,
        wk.VAL: 9,
        wk.WIDGET: RandomSlider
    }),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Floor Sample________________________
FLOOR_SAMPLE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SLICE_COUNT, {
        wk.LIMIT: (2, 60),
        wk.RANDOM: (2, 15),
        wk.TIPPER: make_text_tip,
        wk.VAL: 6,
        wk.WIDGET: RandomSlider
    }),
    (ok.START_ANGLE, {
        wk.LIMIT: (-360, 360),
        wk.RANDOM: (-360, 360),
        wk.TIPPER: make_text_tip,
        wk.VAL: 0,
        wk.WIDGET: RandomSlider
    }),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BSR, deepcopy(BSR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Galactic Field__________________________________________________________
GALACTIC_FIELD = OrderedDict([
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.GRADIENT_MODE, deepcopy(GRADIENT_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (ok.GRADIENT, deepcopy(GRADIENT)),
    (ok.BBR, deepcopy(BBR))
])
GALACTIC_FIELD[ok.GRADIENT_ANGLE][wk.VAL] = fg.TOP_CENTER_TO_BOTTOM_CENTER
GALACTIC_FIELD[ok.GRADIENT_MODE][wk.VAL] = "Subtract"
GALACTIC_FIELD[ok.GRADIENT][wk.VAL] = "Galactic Field"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Glass Gaw_________________________
GLASS_GAW = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRR, deepcopy(BRR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Gradient Fill_________________________________
GRADIENT_FILL = OrderedDict([
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.START_X, deepcopy(START_X)),
    (ok.START_Y, deepcopy(START_Y)),
    (ok.END_X, deepcopy(END_X)),
    (ok.END_Y, deepcopy(END_Y)),
    (ok.IRR, deepcopy(IRR)),
    (ok.GBR, deepcopy(GBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Historic Trip__________________________________________________________
HISTORIC_TRIP = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ITERATIONS, {
        wk.LIMIT: (0, 100),
        wk.PAGE_INCR: 2,
        wk.RANDOM: (0, 20),
        wk.TIPPER: make_text_tip,
        wk.VAL: 12,
        wk.WIDGET: RandomSlider
    }),
    (ok.SPREAD, {
        wk.LIMIT: (0, 512),
        wk.RANDOM: (0, 512),
        wk.TIPPER: make_text_tip,
        wk.VAL: 512,
        wk.WIDGET: RandomSlider
    }),
    (ok.SUPERPIXEL_SIZE, deepcopy(SUPERPIXEL_SIZE)),
    (ok.SATURATION, deepcopy(SATURATION)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Image Gradient_______________________________________________________________
IMAGE_GRADIENT = OrderedDict([
    (ok.NAME, {
        wk.TIPPER: make_text_tip,
        wk.VAL: "Sampled Gradient",
        wk.WIDGET: Entry
    }),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.SAMPLE_VECTOR, {
        wk.FUNCTION: get_vector_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: bs.VERTICAL,
        wk.WIDGET: ComboBox
    }),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SAMPLE_RADIUS, {
        wk.LIMIT: (1., 100.),
        wk.PRECISION: 1,
        wk.RANDOM: (10., 50.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 15.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SAMPLE_POINTS, {
        wk.LIMIT: (2, 50),
        wk.RANDOM: (2, 12),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.SAMPLE_POINTS,
        wk.VAL: 5,
        wk.WIDGET: RandomSlider
    }),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.DIAGONAL_ROTATION, {
        wk.LIMIT: (-359., 359.),
        wk.PRECISION: 1,
        wk.RANDOM: (-359., 359.),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.DIAGONAL_ROTATION,
        wk.VAL: 45.,
        wk.WIDGET: RandomSlider
    }),
    (ok.START_X, deepcopy(START_X)),
    (ok.START_Y, deepcopy(START_Y)),
    (ok.IRK, IRK),
    (ok.PREVIEW_MODE, {
        wk.TEXT: ("Show Gradient", "Show Samples."),
        wk.TIPPER: make_radio_tip,
        wk.VAL: bs.SHOW_GRADIENT,
        wk.WIDGET: RadioRow
    }),
    (ok.BRR, deepcopy(BRR))
])
IMAGE_GRADIENT[ok.START_X][wk.VAL] = IMAGE_GRADIENT[ok.START_Y][wk.VAL] = 0, .5
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Line Stone_____________________________________________________________
LINE_STONE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Lost Maze_____________________________
LOST_MAZE = OrderedDict([
    (ok.GRADIENT_ANGLE, GRADIENT_ANGLE),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(MAZE)),
    (ok.COLUMN, deepcopy(MAZE)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.SEED, deepcopy(SEED)),
    (ok.IRR, deepcopy(IRR)),
    (ok.GBR, deepcopy(GBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Maze Blend____________________________
MAZE_BLEND = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(MAZE)),
    (ok.COLUMN, deepcopy(MAZE)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRR, deepcopy(BRR))
])
MAZE_BLEND[ok.ROW][wk.VAL] = 4
MAZE_BLEND[ok.COLUMN][wk.VAL] = 100
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Mystery Grate_________________________
MYSTERY_GRATE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.COLUMN_1, deepcopy(R_C)),
    (ok.COLUMN_2, deepcopy(R_C)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.IRR, deepcopy(IRR)),
    (ok.GBR, deepcopy(GBR))
])
MYSTERY_GRATE[ok.COLUMN_1][wk.VAL] = 16
MYSTERY_GRATE[ok.COLUMN_2][wk.VAL] = 160
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Nano Suit_________________________
NANO_SUIT = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Noise Rift__________________________________
NOISE_RIFT = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.NOISE_AMOUNT, deepcopy(NOISE_AMOUNT)),
    (ok.BLUR, deepcopy(BLUR)),
    (ok.SEED, deepcopy(SEED)),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.BBR, deepcopy(BBR))
])
NOISE_RIFT[ok.NOISE_AMOUNT][wk.VAL] = 1
NOISE_RIFT[ok.BLUR][wk.VAL] = 20.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Paper Waste_______________________
PAPER_WASTE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BLOCK_W, deepcopy(BLOCK_W)),
    (ok.BLOCK_H, deepcopy(BLOCK_H)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Pattern Fill___________________________________
PATTERN_FILL = OrderedDict([
    (ok.CRITERION, deepcopy(CRITERION)),
    (ok.FILL_MODE, deepcopy(FILL_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.FILL_OPACITY, deepcopy(OPACITY)),
    (ok.THRESHOLD, deepcopy(THRESHOLD)),
    (ok.START_X, deepcopy(START_X)),
    (ok.START_Y, deepcopy(START_Y)),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.PATTERN, deepcopy(PATTERN)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Rainbow Valley________________________________
RAINBOW_VALLEY = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.POWER, {
        wk.LIMIT: (0, 180),
        wk.RANDOM: (0, 180),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.POWER,
        wk.VAL: 30,
        wk.WIDGET: RandomSlider
    }),
    (ok.SEED, deepcopy(SEED)),
    (ok.TEXTURE, {
        wk.TIPPER: make_text_tip,
        wk.VAL: 0,
        wk.WIDGET: CheckButtonRandom
    }),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Rectangle Pattern_______________________
RECT_PATTERN = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.WIDTH_CLIP, deepcopy(CLIP)),
    (ok.HEIGHT_CLIP, deepcopy(CLIP)),
    (ok.COLOR_COUNT, {
        wk.LIMIT: (2, 6),
        wk.PAGE_INCR: 1,
        wk.RANDOM: (2, 6),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.COLOR_COUNT,
        wk.VAL: 2,
        wk.WIDGET: RandomSlider
    }),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.SEED, deepcopy(SEED)),
    (ok.IFR, deepcopy(IFR)),
    (ok.COLOR_GRID_TYPE, {
        wk.TEXT: bs.COLOR_GRID_TYPE,
        wk.RANDOM: (0, 1),
        wk.TIPPER: make_radio_tip,
        wk.VAL: 0,
        wk.WIDGET: RadioRow
    }),
    (ok.COLOR_6A, {
        wk.BUTTON_COUNT: 6,
        wk.HAS_ALPHA: True,
        wk.TIPPER: make_rainbow_count_tip,
        wk.VAL: (
            (51, 51, 51, 255),
            (204, 204, 204, 255),
            (0, 0, 0, 255),
            (255, 255, 255, 255),
            (102, 102, 102, 255),
            (153, 153, 153, 255)
        ),
        wk.WIDGET: Rainbow
    }),
    (ok.BRR, deepcopy(BRR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Rocky Landing_____________________
ROCKY_LANDING = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BLEND, {
        wk.LIMIT: (1, 60),
        wk.PAGE_INCR: 2,
        wk.RANDOM: (5, 20),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.BLEND,
        wk.VAL: 12,
        wk.WIDGET: RandomSlider
    }),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRR, deepcopy(BRR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Soft Touch_____________________________________________________________
SOFT_TOUCH = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Specimen Speckle_______________________________
SPECIMEN_SPECKLE = OrderedDict([
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.IRR, deepcopy(IRR)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.GRADIENT, deepcopy(GRADIENT)),
    (ok.P3R, deepcopy(P3R)),
    (ok.GBR, deepcopy(GBR))
])
SPECIMEN_SPECKLE[ok.COLOR_1][wk.VAL] = 176, 82, 0
a = SPECIMEN_SPECKLE[ok.P3R][wk.SUB]
a[ok.PATTERN_1][wk.VAL] = "Crack"
a[ok.PATTERN_2][wk.VAL] = "Leopard"
a[ok.PATTERN_3][wk.VAL] = "Paper"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Spiral Channel_____________________________________________
SPIRAL_CHANNEL = OrderedDict([
    (ok.SPIRAL_MOD, {
        wk.FUNCTION: get_spiral_mod_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: "None",
        wk.WIDGET: ComboBox
    }),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SPIRAL_DISTANCE, {
        wk.LIMIT: (.001, .5),
        wk.RANDOM: (.001, .5),
        wk.PRECISION: 3,
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.SPIRAL_DISTANCE,
        wk.VAL: .1,
        wk.WIDGET: RandomSlider
    }),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.GRADIENT_DIRECTION, {
        wk.TEXT: bs.DIRECTION,
        wk.TIPPER: make_text_tip,
        wk.VAL: bs.CLOCKWISE,
        wk.WIDGET: RadioRow
    }),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.BRR, deepcopy(BRR))
])
SPIRAL_CHANNEL[ok.COLOR_1][wk.VAL] = 75, 75, 75
SPIRAL_CHANNEL[ok.ROW][wk.VAL] = 1
SPIRAL_CHANNEL[ok.COLUMN][wk.VAL] = 1
SPIRAL_CHANNEL[ok.SPIRAL_MOD][wk.VAL] = bs.HORIZONTAL_FLIP

d = {wk.RANDOM: (1, 10), wk.PAGE_INCR: 2, wk.LIMIT: (1, 100)}

SPIRAL_CHANNEL[ok.ROW].update(d)
SPIRAL_CHANNEL[ok.COLUMN].update(d)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Square Cloud______________________
SQUARE_CLOUD = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.BRR, deepcopy(BRR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stone age______________________________________
STONE_AGE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.PATTERN_SIZE, {
        # Is limited by GIMP's clipboard to
        # pattern function where the maximum side
        # dimension for the clipboard is 1024.
        wk.LIMIT: (24, 256),
        wk.RANDOM: (120, 256),
        wk.TIPPER: make_text_tip,
        wk.VAL: 120,
        wk.WIDGET: RandomSlider
    }),
    (ok.FLIP_V, deepcopy(FLIP)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Trailing Vine___________________________
TRAILING_VINE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.LAYER_COUNT, {
        wk.LIMIT: (3, 20),
        wk.RANDOM: (4, 8),
        wk.TIPPER: make_text_tip,
        wk.VAL: 7,
        wk.WIDGET: RandomSlider
    }),
    (ok.WAVE_PER_LAYER, {
        wk.LIMIT: (1, 18),
        wk.RANDOM: (1, 18),
        wk.TIPPER: make_text_tip,
        wk.VAL: 5,
        wk.WIDGET: RandomSlider
    }),
    (ok.SEED, deepcopy(SEED)),
    (ok.BBR, deepcopy(BBR))
])
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

for i in (
    ACRYLIC_SKY,
    CARBON_14,
    CLAY_CHEMISTRY,
    COLOR_FILL,
    COLOR_GRID,
    CORE_DESIGN,
    CRYSTAL_CAVE,
    CUBE_PATTERN,
    CUBISM_COVER,
    DARK_FORT,
    DENSITY_GRADIENT,
    DROP_ZONE,
    ETCH_SKETCH,
    FLOOR_SAMPLE,
    GALACTIC_FIELD,
    GLASS_GAW,
    GRADIENT_FILL,
    HISTORIC_TRIP,
    IMAGE_GRADIENT,
    LINE_STONE,
    LOST_MAZE,
    MAZE_BLEND,
    MYSTERY_GRATE,
    NANO_SUIT,
    NOISE_RIFT,
    PAPER_WASTE,
    PATTERN_FILL,
    RAINBOW_VALLEY,
    RECT_PATTERN,
    ROCKY_LANDING,
    SOFT_TOUCH,
    SPECIMEN_SPECKLE,
    SPIRAL_CHANNEL,
    SQUARE_CLOUD,
    STONE_AGE,
    TRAILING_VINE
):
    set_issue(
        i, None, vo.BAKE, (ok.OPACITY, ok.MODE, ok.BUMP, ok.SHADOW)
    )
