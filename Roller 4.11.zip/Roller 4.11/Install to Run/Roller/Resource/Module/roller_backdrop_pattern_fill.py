#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_maya_style import Style, make_background
from roller_view_real import finish_style
from roller_view_hub import (
    get_canvas_points, set_fill_context, set_gimp_pattern
)
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make the Backdrop Style.

    v: View
    maya: PatternFill
    Return: layer
        with the style material
    """
    d = maya.value_d
    z = make_background(v, maya, d)

    # fill point, 'x, y'
    x, y = get_canvas_points(d)[:2]

    set_fill_context(d)
    set_gimp_pattern(d[ok.PATTERN])
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, x, y)

    if d[ok.INVERT]:
        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)
    return finish_style(z, "Pattern Fill")


class PatternFill(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BBR

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        self.init_background(make_style, *q, **d)

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BBR][ok.BACKGROUND][ok.BACKDROP_TYPE] == bs.BACKDROP_IMAGE
        super(PatternFill, self).do(v, d, is_change)
