#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Option as ok
from roller_option_group import ManyGroup
from roller_maya import MAIN, Maya
from roller_fu import make_layer_group
from roller_one_the import The


def check_view_image(v, maya):
    """
    Process View image size change.

    v: View
    maya: Maya
    Return: None
    """
    if maya.is_matter:
        w, h = v.view_size
        w1, h1 = (v.j.width, v.j.height) if v.j else (0, 0)
        if w != w1 or h != h1:
            v.j = The.cat.render.new_image(w, h)
            The.power.press()


def make_plan_group(v, maya):
    """
    Make a Plan layer group if there isn't one.

    v: View
    maya: Global Plan
    Return: layer group
        for Plan
    """
    if not v.plan.plan_group:
        v.plan.plan_group = make_layer_group(v.j, "Plan")
    return v.plan.plan_group


class Global(ManyGroup):
    """Assign a View processor and connect responsible signal handler."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)
        d = self.widget_d

        # Insert a responder into the relay, but the Signal has already flown.
        for k, p in (
            (ok.RENDER_W, self.on_view_size_change),
            (ok.RENDER_H, self.on_view_size_change),
            (ok.WIP, self.on_view_size_change),
            (ok.ELEVATION, self.on_emboss_change),
            (ok.AZIMUTH, self.on_emboss_change),
            (ok.SEED, self.on_seed_change)
        ):
            d[k].relay.insert(0, p)
            p(d[k])

    def on_emboss_change(self, g):
        """
        Respond to change in a emboss type Widget.

        g: Widget
            Roller type
            Is responsible.
        """
        g, g1 = self.widget_d[ok.ELEVATION], self.widget_d[ok.AZIMUTH]
        a = The.view.glow_ball.elevation = g.get_a()
        b = The.view.glow_ball.azimuth = g1.get_a()
        The.power.plug(
            si.GLOBAL_EMBOSS,
            (
                a != g.view_value[0] or b != g1.view_value[0],
                b != g.view_value[1] or b != g1.view_value[1]
            )
        )

    def on_seed_change(self, g):
        """
        Respond to change in the Global seed Widget.

        g: Widget
            Roller type
            Is responsible.
        """
        g = self.widget_d[ok.SEED]
        a = The.view.glow_ball.seed = g.get_a()
        The.power.plug(
            si.GLOBAL_SEED,
            (a != g.view_value[0], a != g.view_value[1]))

    def on_view_size_change(self, g):
        """
        Respond to a View image size option value change.

        g: Widget
            Has changed.
        """
        g, g1 = self.widget_d[ok.RENDER_W], self.widget_d[ok.RENDER_H]
        g2 = self.widget_d[ok.WIP]
        a = g2.get_a()
        w, h = g.get_a(), g1.get_a()
        The.power.plug(
            si.RESIZE,
            [
                (
                    w != g.view_value[0] or
                    h != g1.view_value[0] or
                    a != g2.view_value[0]
                ),
                (
                    w != g.view_value[1] or
                    h != g1.view_value[1] or
                    a != g2.view_value[1]
                )
            ]
        )


class Chi(Maya):
    """Put energy to use."""
    issue_q = 'matter',
    vote_type = MAIN

    def __init__(self, *arg):
        Maya.__init__(self, *arg)
        self.set_issue()

    def do(self, v):
        """
        v: View
        Return: None
            for undo
        """
        self.realize_vote(v)


class Plan(Chi):
    """Manage Draft and Plan response to Global option."""
    put = (check_view_image, 'matter'), (make_plan_group, 'group')

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, Plan.put)


class Work(Chi):
    """Manage Peek, Preview, and render response to Global option."""
    put = (check_view_image, 'matter'),

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1, Work.put)
