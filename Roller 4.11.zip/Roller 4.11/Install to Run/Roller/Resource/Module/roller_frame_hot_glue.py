#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Group as gk, Option as ok
from roller_frame_build import Build
from roller_def import get_default_value
from roller_maya import check_matter, make_frame_group
from roller_fu import (
    add_layer,
    blur_selection,
    clear_inverse_selection,
    clone_layer,
    color_fill_selection,
    color_fill_layer,
    discard_mask,
    make_layer_group,
    merge_layer,
    merge_layer_group,
    select_item
)
from roller_maya_light import Light
from roller_one_gegl import unsharp_mask
from roller_view_real import (
    LIGHT, clip_to_wip, clone_background, get_light
)
from roller_view_shadow import make_shadow
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: Hot Glue Maya
    Return: layer
        with the frame
    """
    j = v.j
    d = maya.value_d
    w, h = j.width, j.height
    cause = maya.cause.matter

    # A mask interferes with 'clone_background'.
    discard_mask(maya.group)

    # Resize material layer so that the waves plug-in will perform
    # its function off-center which has less symmetry and stretch.
    pdb.gimp_image_resize(j, w + w, h + h, 0, 0)

    group = make_layer_group(
        j, "Hot Glue WIP", parent=maya.group, offset=get_light(maya)
    )
    bump_z = add_layer(j, "Bump", parent=group)
    w1 = d[ok.FRAME_W]
    w1 = w1 // 2 + w1 % 2

    color_fill_layer(bump_z, (0, 0, 0))
    select_item(cause)

    # Make a border overlapping the cause material.
    pdb.gimp_selection_border(j, w1)

    color_fill_selection(bump_z, (255, 255, 255))

    base_z = clone_background(v, bump_z, n="Base")
    depth = max(1, d[ok.BORDER_BLUR] // 2)

    pdb.gimp_selection_none(j)
    blur_selection(bump_z, d[ok.BORDER_BLUR])
    blur_selection(base_z, d[ok.BLUR_BEHIND])

    if d[ok.INTENSITY] and d[ok.SHADOW_BLUR]:
        e = get_default_value(gk.SHADOW_1)

        e.update(d)

        shadow_z = make_shadow(j, e, maya.group, (cause,))
        if shadow_z:
            # second position, '1'
            pdb.gimp_image_reorder_item(j, shadow_z, group, 1)

    pdb.plug_in_waves(
        j, bump_z,
        d[ok.WAVE_AMPLITUDE],
        d[ok.WAVE_PHASE],
        d[ok.WAVELENGTH],
        0,                      # smeared
        0                       # not reflective
    )
    pdb.gimp_image_resize(j, w, h, 0, 0)
    pdb.plug_in_colortoalpha(j, bump_z, (0, 0, 0))
    pdb.plug_in_bump_map(
        j, base_z, bump_z,
        v.glow_ball.azimuth,
        45.,                    # elevation
        depth,
        0, 0,                   # x, y offset
        .0,                     # water level
        .0,                     # ambient light
        1,                      # compensate for dark
        0,                      # no invert
        0                       # linear map
    )
    select_item(bump_z)
    clear_inverse_selection(base_z)
    pdb.gimp_image_reorder_item(j, base_z, group, 0)
    pdb.gimp_drawable_invert(bump_z, 0)

    base_z.mode = fu.LAYER_MODE_DIFFERENCE
    z = merge_layer_group(group)
    z = clone_layer(z)
    z = merge_layer(z)
    z = clone_layer(z)
    q = .0, .0, .403, .0, .737, .843, 1., 1.

    pdb.gimp_drawable_curves_spline(z, fu.HISTOGRAM_VALUE, len(q), q)
    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    select_item(z)
    pdb.gimp_context_set_feather(1)
    pdb.gimp_context_set_feather_radius(4., 4.)
    clear_inverse_selection(z)

    z.mode = fu.LAYER_MODE_ADDITION
    z = merge_layer(z)
    z.name = maya.group.name + " Hot Glue"

    clip_to_wip(v, z)
    unsharp_mask(z, 5., min(2., d[ok.BORDER_BLUR]), .0)

    # antialias softening
    blur_selection(z, 2)

    return z


class HotGlue(Build):
    """Create a translucent type of frame that has a gluey tube appearance."""
    is_embossed = True
    issue_q = 'matter',
    put = (make_frame_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its Preset vote dict.
            (Option key, ...)
        """
        self.do_matter = do_matter

        Build.__init__(self, any_group, super_maya, k_path)
        self.sub_maya[LIGHT] = Light(any_group, self, ok.TRANSLUCENT)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Hot Glue Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: False
            Shadow did not change the background.
        """
        self.value_d = d
        self.is_matter |= is_change or v.is_back

        self.realize(v)
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return False
