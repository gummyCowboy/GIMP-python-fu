#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame import draw_color_profile
from roller_frame_build import Build
from roller_fu import add_layer, clone_layer, merge_layer, select_opaque
from roller_maya import check_frame_cake, check_matter, make_frame_group
from roller_maya_blur_behind import BlurBehind
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_view_hub import PROFILE
from roller_view_real import LIGHT, get_light
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: GlassReveal
    Return: layer or None
        with the frame
    """
    j = v.j

    # Glass Reveal Preset dict, 'd'
    d = maya.value_d

    group = maya.group
    n = group.name + " Glass Reveal"
    z = add_layer(v.j, n, parent=group, offset=get_light(maya))
    color = 255, 255, 255
    w = d[ok.FRAME_W]
    q = PROFILE[d[ok.PROFILE]](w, *(color,))

    select_opaque(maya.cause.matter)
    draw_color_profile(z, w, q, color)

    if d[ok.CURVE] != "None":
        q = ff.CURVE_DICT[d[ok.CURVE]]
        pdb.gimp_drawable_curves_spline(z, fu.HISTOGRAM_VALUE, len(q), q)

    if d[ok.EMBOSS]:
        z = clone_layer(z)

        pdb.plug_in_emboss(
            j, z,
            v.glow_ball.azimuth,
            v.glow_ball.elevation,
            max(1, w // 3),
            0                   # bump
        )

        z.opacity = 50. if w < 60. else 100.
        z.mode = fu.LAYER_MODE_MULTIPLY
        z = clone_layer(z)
        z.mode = fu.LAYER_MODE_SCREEN
        z = merge_layer(z)
        z = merge_layer(z)
        z.name = n
    return z


class GlassReveal(Build):
    """Create a glass-like border."""
    is_embossed = True
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

         k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        self.do_matter = do_matter

        Build.__init__(self, any_group, super_maya, k_path)

        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (self.cause, self), k_path + (ok.SRR, ok.SHADOW)
        )
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(any_group, self, k_path)
        self.sub_maya[LIGHT] = Light(any_group, self, ok.TRANSLUCENT)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Glass Pipe Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)

        m = self.sub_maya[ok.SHADOW].do(
            v,
            d[ok.SRR][ok.SHADOW],
            self.is_matter + self.is_cake,
            is_change + self.cause.is_cake
        )

        self.sub_maya[ok.BLUR_BEHIND].do(v, d, m or is_back, self.is_matter)
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m
