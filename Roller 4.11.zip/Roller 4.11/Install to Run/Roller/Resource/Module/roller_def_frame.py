#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Frame as ff, Gradient as fg, Issue as vo
from roller_constant_key import Option as ok, Widget as wk
from roller_def_share import (
    ANGLE_JITTER,
    BLUR,
    BLUR_BEHIND,
    BRUSH,
    BRUSH_SIZE,
    BRUSH_SPACING,
    CER,
    CFW,
    CIR,
    COLOR_1,
    COLOR_2A,
    ANGLE,
    FEATHER,
    FNR,
    FRAME_TYPE,
    FRAME_W,
    GAP_W,
    GBRW,
    GRADIENT,
    GRADIENT_ANGLE,
    IPB,
    IRR,
    GRADIENT_TYPE,
    INTENSITY,
    LINE_W,
    MESH_SIZE,
    MESH_TYPE,
    MODE,
    NEATNESS,
    NSR,
    OPACITY,
    OVERLAY_MODE,
    PNR,
    PROFILE,
    R_C,
    SATURATION,
    SEED,
    SHADOW,
    SHADOW_BLUR,
    SHADOW_COLOR,
    SRR,
    STEPS,
    WAVE_AMPLITUDE,
    WAVELENGTH,
    WIDTH,
    make_bool_tip,
    make_text_tip,
    set_issue
)
from roller_fu_comm import show_err
from roller_fu_mode import Mode
from roller_one_the import The
from roller_one_tip import Tip
from roller_widget_check_button import CheckButtonRandom
from roller_widget_combo import ComboBox
from roller_widget_slider import RandomSlider
import glob
import os

NO_MATTER = (
    ok.BLUR_BEHIND,
    ok.BUMP,
    ok.FRAME_MODE,
    ok.FRAME_OPACITY,
    ok.FRAME_STYLE,
    ok.FSM,
    ok.FSO,
    ok.NOISE_D,
    ok.SHADOW,
    ok.SHADOW_BLUR,
    ok.SHADOW_COLOR
)


def get_nail_polish_list():
    return ff.NAIL_POLISH


def get_camo_type_list():
    return ff.CAMO_TYPE


def get_curve_list():
    return ff.CURVE


def get_edge_mode_list():
    return Mode.EDGE_MODE


def get_frame_over_image_source():
    return [ok.FILE]


def get_frame_list():
    """
    Make a list of frame file for Frame Over.

    Return: list
        of GIMP-opened image name
    """
    files = []
    frame_list = ["None"]
    go = False

    try:
        # Ignore sub-directories.
        files = glob.glob(The.frame_path + os.path.sep + "*.png")
        go = True

    except Exception as ex:
        show_err(ex)
        show_err("Roller was unable to load frame images.")
    if go:
        for i in files:
            frame_list += [os.path.splitext(os.path.basename(i))[0]]
    return frame_list


def get_frame_style_list():
    return ff.FRAME_STYLE


def get_paint_rush_type_list():
    return ff.PAINT_RUSH_TYPE


def get_shape_burst_list():
    return fg.SHAPE_BURST


brush_size = deepcopy(BRUSH_SIZE)

# Ball Joint___________________________________
BALL_JOINT = OrderedDict([
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.BRUSH_SIZE, brush_size),
    (ok.SRR, deepcopy(SRR))
])

set_issue(BALL_JOINT, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Brush Punch___________________________________
BRUSH_PUNCH = OrderedDict([
    (ok.BRUSH_SIZE, brush_size),
    (ok.BRUSH_SPACING, deepcopy(BRUSH_SPACING)),
    (ok.ANGLE_JITTER, deepcopy(ANGLE_JITTER)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRUSH, deepcopy(BRUSH)),
    (ok.FNR, deepcopy(FNR)),
    (ok.SRR, deepcopy(SRR))
])

set_issue(BRUSH_PUNCH, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Camo Planet_______________________________________________________________
CAMO_PLANET = OrderedDict([
    (ok.FRAME_TYPE, deepcopy(FRAME_TYPE)),
    (ok.CAMO_TYPE, {
        wk.FUNCTION: get_camo_type_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: ff.COMPOSITE,
        wk.WIDGET: ComboBox
    }),
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FSM, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FSO, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.SATURATION, deepcopy(SATURATION)),
    (ok.SEED, deepcopy(SEED)),
    (ok.SRR, deepcopy(SRR))
])
CAMO_PLANET[ok.FSM][wk.VAL] = "Hard Light"
CAMO_PLANET[ok.FRAME_W][wk.VAL] = 30
CAMO_PLANET[ok.SATURATION][wk.VAL] = 2.

set_issue(CAMO_PLANET, (), vo.BAKE, NO_MATTER + (ok.SATURATION, ok.SEED))
set_issue(CAMO_PLANET, (ok.CAMO_TYPE, ok.SATURATION, ok.SEED), vo.COLOR, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Ceramic Chip______________________________________________
CERAMIC_CHIP = OrderedDict([
    (ok.MESH_TYPE, deepcopy(MESH_TYPE)),
    (ok.FSM, deepcopy(MODE)),
    (ok.FSO, deepcopy(OPACITY)),
    (ok.WIDTH, deepcopy(WIDTH)),
    (ok.MESH_SIZE, deepcopy(MESH_SIZE)),
    (ok.SEED, deepcopy(SEED)),
    (ok.GREY_SCALE, {
        wk.TIPPER: make_bool_tip,
        wk.VAL: 0,
        wk.WIDGET: CheckButtonRandom
    }),
    (ok.FNR, deepcopy(FNR)),
    (ok.SRR, deepcopy(SRR))
])

set_issue(CERAMIC_CHIP, (), vo.BAKE, NO_MATTER + (ok.SEED,))
set_issue(
    CERAMIC_CHIP,
    (ok.GREY_SCALE, ok.MESH_SIZE, ok.MESH_TYPE, ok.SEED),
    vo.FILLER,
    (ok.NOISE_D,)
)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Circle Punch____________________________________
CIRCLE_PUNCH = OrderedDict([
    (ok.CIRCLE_DIAMETER, {
        # Is limited by GIMP's clipboard to
        # pattern function where the maximum side
        # span for the clipboard is 1024.
        wk.LIMIT: (12, 680),
        wk.RANDOM: (12, 100),
        wk.TIPPER: make_text_tip,
        wk.VAL: 30,
        wk.WIDGET: RandomSlider
    }),
    (ok.WIDTH, deepcopy(WIDTH)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.FNR, deepcopy(FNR)),
    (ok.SRR, deepcopy(SRR))
])

set_issue(CIRCLE_PUNCH, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Clear Frame______________________________________
CLEAR_FRAME = OrderedDict([
    (ok.FRAME_TYPE, deepcopy(FRAME_TYPE)),
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FSM, deepcopy(OVERLAY_MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FSO, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.INNER_FRAME_W, {
        wk.LIMIT: (4, 14),
        wk.RANDOM: (4, 12),
        wk.TIPPER: make_text_tip,
        wk.VAL: 5,
        wk.WIDGET: RandomSlider
    }),
    (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.SRR, deepcopy(SRR))
])
CLEAR_FRAME[ok.COLOR_1][wk.VAL] = 231, 231, 194
CLEAR_FRAME[ok.FRAME_W][wk.VAL] = 30
CLEAR_FRAME[ok.FRAME_OPACITY][wk.VAL] = 33.

set_issue(CLEAR_FRAME, (), vo.BAKE, NO_MATTER)
set_issue(CLEAR_FRAME, (ok.COLOR_1,), vo.COLOR, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Color Board______________________________________
COLOR_BOARD = OrderedDict([
    (ok.FRAME_TYPE, deepcopy(FRAME_TYPE)),
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FSM, deepcopy(OVERLAY_MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FSO, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.SRR, deepcopy(SRR))
])
COLOR_BOARD[ok.COLOR_1][wk.VAL] = 255, 255, 255
COLOR_BOARD[ok.FRAME_W][wk.VAL] = 30

set_issue(COLOR_BOARD, (), vo.BAKE, NO_MATTER)
set_issue(COLOR_BOARD, (ok.COLOR_1,), vo.COLOR, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Color Pipe_________________________________
COLOR_PIPE = OrderedDict([
    (ok.PROFILE, deepcopy(PROFILE)),
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.NSR, deepcopy(NSR))
])
COLOR_PIPE[ok.COLOR_1][wk.VAL] = 0, 127, 0
COLOR_PIPE[ok.FRAME_W][wk.VAL] = 30

set_issue(COLOR_PIPE, (), vo.BAKE, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Corner Tape_________________________________________________________
CORNER_TAPE = OrderedDict([
    (ok.FSM, deepcopy(MODE)),
    (ok.FSO, deepcopy(OPACITY)),
    (ok.TAPE_LENGTH, {
        wk.LIMIT: (5, 1000),
        wk.PAGE_INCR: 10,
        wk.RANDOM: (80, 150),
        wk.TIPPER: make_text_tip,
        wk.VAL: 150,
        wk.WIDGET: RandomSlider
    }),
    (ok.TAPE_W, {
        wk.LIMIT: (5, 999),
        wk.PAGE_INCR: 10,
        wk.RANDOM: (30, 60),
        wk.TIPPER: make_text_tip,
        wk.VAL: 50,
        wk.WIDGET: RandomSlider
    }),
    (ok.INTENSITY, deepcopy(INTENSITY)),
    (ok.SHADOW_BLUR, deepcopy(SHADOW_BLUR)),
    (ok.ANGLE_SHIFT, {
        wk.LIMIT: (.0, 180.),
        wk.PRECISION: 1,
        wk.RANDOM: (.0, 11.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 5.,
        wk.WIDGET: RandomSlider
    }),
    (ok.CORNER_SHIFT, {
        wk.LIMIT: (0, 100),
        wk.PAGE_INCR: 5,
        wk.RANDOM: (0, 18),
        wk.TIPPER: make_text_tip,
        wk.VAL: 9,
        wk.WIDGET: RandomSlider
    }),
    (ok.LENGTH_SHIFT, {
        wk.LIMIT: (0, 999),
        wk.PAGE_INCR: 10,
        wk.RANDOM: (10, 40),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.LENGTH_SHIFT,
        wk.VAL: 10,
        wk.WIDGET: RandomSlider
    }),
    (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
    (ok.SEED, deepcopy(SEED)),
    (ok.COLOR_1, deepcopy(COLOR_1))
])
CORNER_TAPE[ok.FSO][wk.VAL] = 15.
CORNER_TAPE[ok.INTENSITY][wk.VAL] = 75
CORNER_TAPE[ok.SHADOW_BLUR][wk.VAL] = 7.
CORNER_TAPE[ok.SHADOW_BLUR][wk.RANDOM] = 2., 10.

CORNER_TAPE[ok.BLUR_BEHIND].update({wk.VAL: 3., wk.RANDOM: (1., 6.)})
CORNER_TAPE[ok.COLOR_1][wk.VAL] = 220, 210, 180

set_issue(CORNER_TAPE, (), vo.BAKE, NO_MATTER)
set_issue(CORNER_TAPE, (ok.COLOR_1,), vo.COLOR, ())
set_issue(CORNER_TAPE, (ok.INTENSITY, ok.SHADOW_BLUR), vo.SHADOW, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Crumble Shell_____________________________________
CRUMBLE_SHELL = OrderedDict([
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.SPREAD_DISTRESS, {
        wk.LIMIT: (1., 100.),
        wk.PAGE_INCR: 5.,
        wk.PRECISION: 1,
        wk.RANDOM: (8., 16.),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.SPREAD_DISTRESS,
        wk.VAL: 12.,
        wk.WIDGET: RandomSlider
    }),
    (ok.DISTRESS_THRESHOLD, {
        wk.LIMIT: (1., 254.),
        wk.PRECISION: 1,
        wk.RANDOM: (1., 254.),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.DISTRESS_THRESHOLD,
        wk.VAL: 127.,
        wk.WIDGET: RandomSlider
    }),
    (ok.INTENSITY, deepcopy(INTENSITY)),
    (ok.SHADOW_BLUR, deepcopy(SHADOW_BLUR)),
    (ok.SEED, deepcopy(SEED)),
    (ok.SHADOW_COLOR, deepcopy(SHADOW_COLOR))
])
CRUMBLE_SHELL[ok.FRAME_W][wk.VAL] = 15
CRUMBLE_SHELL[ok.FRAME_W][wk.RANDOM] = 15, 35
CRUMBLE_SHELL[ok.SHADOW_BLUR][wk.VAL] = 12.

set_issue(CRUMBLE_SHELL, (), vo.BAKE, NO_MATTER)
set_issue(
    CRUMBLE_SHELL,
    (ok.INTENSITY, ok.SHADOW_BLUR, ok.SHADOW_COLOR),
    vo.SHADOW,
    ()
)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Cutout Plate______________________________________
CUTOUT_PLATE = OrderedDict([
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FSM, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FSO, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.BEVEL_EDGE_W, {
        wk.LIMIT: (0, 999),
        wk.PAGE_INCR: 2,
        wk.RANDOM: (4, 8),
        wk.TIPPER: make_text_tip,
        wk.VAL: 2,
        wk.WIDGET: RandomSlider
    }),
    (ok.PNR, deepcopy(PNR)),
    (ok.SRR, deepcopy(SRR))
])
CUTOUT_PLATE[ok.FRAME_W][wk.VAL] = 30
CUTOUT_PLATE[ok.FRAME_W][wk.RANDOM] = 12, 24
CUTOUT_PLATE[ok.FSO][wk.VAL] = 90.

set_issue(CUTOUT_PLATE, (), vo.BAKE, NO_MATTER)
set_issue(CUTOUT_PLATE, (ok.PATTERN,), vo.COLOR, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Frame Over______________________________
FEATHER_STEP = OrderedDict([
    (ok.FEATHER, deepcopy(FEATHER)),
    (ok.STEPS, deepcopy(STEPS))
])

set_issue(FEATHER_STEP, (), vo.MATTER, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Frame Over_________________________________________________________
FRAME_OVER = OrderedDict([
    (ok.FRAME_OVER, {
        wk.FUNCTION: get_frame_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: "",
        wk.WIDGET: ComboBox
    }),
    (ok.FRAME_STYLE, {
        wk.FUNCTION: get_frame_style_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: ff.AS_IS,
        wk.WIDGET: ComboBox
    }),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FSM, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FSO, deepcopy(OPACITY)),
    (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
    (ok.BLUR, deepcopy(BLUR)),
    (ok.SEED, deepcopy(SEED)),
    (ok.CIR, deepcopy(CIR)),
    (ok.GBRW, deepcopy(GBRW)),
    (ok.SRR, deepcopy(SRR))
])
FRAME_OVER[ok.FSM][wk.VAL] = "Linear Burn"
FRAME_OVER[ok.BLUR][wk.VAL] = 20.
a = FRAME_OVER[ok.CIR][wk.SUB][ok.IMAGE_CHOICE]
a[wk.SUB][ok.IMAGE_SOURCE][wk.FUNCTION] = get_frame_over_image_source

set_issue(FRAME_OVER, (), vo.BAKE, NO_MATTER)
set_issue(
    FRAME_OVER,
    (
        ok.BLUR,
        ok.COLOR_1,
        ok.FRAME_STYLE,
        ok.GRADIENT,
        ok.GRADIENT_ANGLE,
        ok.GRADIENT_TYPE,
        ok.SEED
    ),
    vo.COLOR,
    ()
)
set_issue(a, (), vo.COLOR, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Glass Reveal_________________________________
GLASS_REVEAL = OrderedDict([
    (ok.PROFILE, deepcopy(PROFILE)),
    (ok.CURVE, {
        wk.FUNCTION: get_curve_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: "None",
        wk.WIDGET: ComboBox
    }),
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
    (ok.EMBOSS, {
        wk.TIPPER: make_bool_tip,
        wk.VAL: 0,
        wk.WIDGET: CheckButtonRandom
    }),
    (ok.SRR, deepcopy(SRR))
])
GLASS_REVEAL[ok.FRAME_OPACITY][wk.VAL] = 24.
GLASS_REVEAL[ok.FRAME_W][wk.VAL] = 30
GLASS_REVEAL[ok.PROFILE][wk.VAL] = ff.ROUND

set_issue(GLASS_REVEAL, (), vo.BAKE, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Gradient Level_____________________________________________________________
GRADIENT_LEVEL = OrderedDict([
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.NSR, deepcopy(NSR))
])
GRADIENT_LEVEL[ok.COLOR_2A][wk.VAL] = (160, 105, 28, 255), (116, 77, 43, 255)
GRADIENT_LEVEL[ok.FRAME_W][wk.VAL] = 30

set_issue(GRADIENT_LEVEL, (), vo.BAKE, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Hot Glue________________________________________
HOT_GLUE = OrderedDict([
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.BORDER_BLUR, deepcopy(BLUR)),
    (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
    (ok.WAVE_AMPLITUDE, deepcopy(WAVE_AMPLITUDE)),
    (ok.WAVELENGTH, deepcopy(WAVELENGTH)),
    (ok.WAVE_PHASE, {
        wk.LIMIT: (-360., 360.),
        wk.PRECISION: 1,
        wk.RANDOM: (-360., 360.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 1.,
        wk.WIDGET: RandomSlider
    }),
    (ok.INTENSITY, deepcopy(INTENSITY)),
    (ok.SHADOW_BLUR, deepcopy(SHADOW_BLUR))
])
HOT_GLUE[ok.BLUR_BEHIND][wk.VAL] = 10.
HOT_GLUE[ok.FRAME_W][wk.VAL] = 5
HOT_GLUE[ok.BORDER_BLUR].update(
    {wk.RANDOM: (1., 3.), wk.VAL: 2.}
)
HOT_GLUE[ok.INTENSITY][wk.VAL] = 80
HOT_GLUE[ok.SHADOW_BLUR][wk.VAL] = 4
HOT_GLUE[ok.SHADOW_BLUR][wk.RANDOM] = 1., 6.

set_issue(HOT_GLUE, (), vo.BAKE, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Jagged Edge___________________________________
JAGGED_EDGE = OrderedDict([
    (ok.AMPLITUDE, {
        wk.LIMIT: (2, 30),
        wk.RANDOM: (2, 30),
        wk.TOOLTIP: Tip.AMPLITUDE,
        wk.TIPPER: make_text_tip,
        wk.VAL: 3,
        wk.WIDGET: RandomSlider
    }),
    (ok.SMOOTHNESS, {
        wk.LIMIT: (3, 20),
        wk.RANDOM: (5, 12),
        wk.TIPPER: make_text_tip,
        wk.VAL: 4,
        wk.WIDGET: RandomSlider
    }),
    (ok.SEED, deepcopy(SEED)),
    (ok.SRR, deepcopy(SRR))
])

set_issue(JAGGED_EDGE, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Line Fashion___________________________________
LINE_FASHION = OrderedDict([
    (ok.WIDTH, deepcopy(WIDTH)),
    (ok.LINE_W, deepcopy(LINE_W)),
    (ok.GAP_W, deepcopy(GAP_W)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.FNR, deepcopy(FNR)),
    (ok.SRR, deepcopy(SRR))
])

LINE_FASHION[ok.ANGLE].update({wk.VAL: 45.})
set_issue(LINE_FASHION, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Metallic Frame_____________________________________
METALLIC_PROFILE = OrderedDict([
    (ok.PROFILE, deepcopy(PROFILE)),
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.SRR, deepcopy(SRR))
])
METALLIC_PROFILE[ok.FRAME_W][wk.VAL] = 30

set_issue(METALLIC_PROFILE, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Nail Polish____________________________________________________
NAIL_POLISH = OrderedDict([
    (ok.FRAME_TYPE, {
        wk.FUNCTION: get_nail_polish_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: ff.BACKDROP,
        wk.WIDGET: ComboBox
    }),
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FSM, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FSO, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.IPB, deepcopy(IPB)),
    (ok.SRR, deepcopy(SRR))
])
NAIL_POLISH[ok.FSO][wk.VAL] = 50.
NAIL_POLISH[ok.COLOR_1][wk.VAL] = 0, 127, 0
NAIL_POLISH[ok.FRAME_MODE][wk.VAL] = "Subtract"

NAIL_POLISH[ok.FRAME_W].update({wk.RANDOM: (1, 100), wk.VAL: 50})
set_issue(NAIL_POLISH, (), vo.MATTER, NO_MATTER)
set_issue(NAIL_POLISH, (ok.FSM, ok.FSO), vo.MATTER, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Paint Rush________________________________________
PAINT_RUSH = OrderedDict([
    (ok.EDGE_TYPE, {
        wk.FUNCTION: get_paint_rush_type_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: ff.WHITE_SOFT,
        wk.WIDGET: ComboBox
    }),
    (ok.EDGE_MODE, {
        wk.FUNCTION: get_edge_mode_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: "Lighten Only",
        wk.WIDGET: ComboBox
    }),
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.POST_BLUR, deepcopy(BLUR)),
    (ok.COLORIZE_OPACITY, deepcopy(OPACITY)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.CER, deepcopy(CER)),
    (ok.SRR, deepcopy(SRR))
])
PAINT_RUSH[ok.FRAME_W][wk.VAL] = 80
PAINT_RUSH[ok.COLOR_1][wk.VAL] = 175, 90, 10
PAINT_RUSH[ok.COLORIZE_OPACITY][wk.VAL] = 70.
PAINT_RUSH[ok.POST_BLUR][wk.TOOLTIP] = Tip.POST_BLUR

set_issue(PAINT_RUSH, (), vo.BAKE, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Rad Wave________________________________________
RAD_WAVE = OrderedDict([
    (ok.LINE_W, deepcopy(LINE_W)),
    (ok.CFW, deepcopy(CFW)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.WAVE_AMPLITUDE, deepcopy(WAVE_AMPLITUDE)),
    (ok.WAVELENGTH, deepcopy(WAVELENGTH)),
    (ok.WHIRL, {
        wk.LIMIT: (-720, 720),
        wk.PAGE_INCR: 10,
        wk.RANDOM: (-30, 30),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.WHIRL,
        wk.VAL: 45,
        wk.WIDGET: RandomSlider
    }),
    (ok.FNR, deepcopy(FNR)),
    (ok.SRR, deepcopy(SRR))
])
RAD_WAVE[ok.CFW][wk.LIMIT] = 0, 999

set_issue(RAD_WAVE, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Raised Maze___________________________________
RAISED_MAZE = OrderedDict([
    (ok.LINE_W, deepcopy(LINE_W)),
    (ok.CFW, deepcopy(CFW)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.SEED, deepcopy(SEED)),
    (ok.FNR, deepcopy(FNR)),
    (ok.SRR, deepcopy(SRR))
])
RAISED_MAZE[ok.CFW][wk.LIMIT] = 0, 999

for i in (ok.ROW, ok.COLUMN):
    RAISED_MAZE[i][wk.LIMIT] = 4, 999

set_issue(RAISED_MAZE, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Shape Burst_________________________________
SHAPE_BURST = OrderedDict([
    (ok.SHAPE_BURST, {
        wk.FUNCTION: get_shape_burst_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: fg.SHAPE_BURST_SPHERICAL,
        wk.WIDGET: ComboBox
    }),
    (ok.FRAME_MODE, deepcopy(MODE)),
    (ok.FRAME_OPACITY, deepcopy(OPACITY)),
    (ok.FRAME_W, deepcopy(FRAME_W)),
    (ok.UNSHARP_AMOUNT, {
        wk.LIMIT: (.0, 300.),
        wk.PAGE_INCR: 10.,
        wk.PRECISION: 1,
        wk.RANDOM: (.0, 50.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 10.,
        wk.WIDGET: RandomSlider
    }),
    (ok.UNSHARP_RADIUS, {
        wk.LIMIT: (.0, 1500.),
        wk.PAGE_INCR: 10.,
        wk.PRECISION: 1,
        wk.RANDOM: (.0, 50.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 11.,
        wk.WIDGET: RandomSlider
    }),
    (ok.UNSHARP_THRESHOLD, {
        wk.LIMIT: (.0, .1),
        wk.PRECISION: 2,
        wk.RANDOM: (.0, .1),
        wk.TIPPER: make_text_tip,
        wk.VAL: .03,
        wk.WIDGET: RandomSlider
    }),
    (ok.IRR, deepcopy(IRR)),
    (ok.GRADIENT, deepcopy(GRADIENT)),
    (ok.SRR, deepcopy(SRR))
])
a = SHAPE_BURST[ok.GRADIENT]
a[wk.VAL] = "Brushed Aluminium"
SHAPE_BURST[ok.FRAME_W][wk.VAL] = 45

set_issue(SHAPE_BURST, (), vo.BAKE, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Square Cut___________________________________
SQUARE_CUT = OrderedDict([
    (ok.WIDTH, deepcopy(WIDTH)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.FNR, deepcopy(FNR)),
    (ok.SRR, deepcopy(SRR))
])

SQUARE_CUT[ok.ANGLE].update({wk.VAL: 45.})
set_issue(SQUARE_CUT, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Square Punch___________________________________
SQUARE_PUNCH = OrderedDict([
    (ok.WIDTH, deepcopy(WIDTH)),
    (ok.LINE_W, deepcopy(LINE_W)),
    (ok.GAP_W, deepcopy(GAP_W)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.FNR, deepcopy(FNR)),
    (ok.SRR, deepcopy(SRR))
])

SQUARE_PUNCH[ok.ANGLE].update({wk.VAL: 45.})
set_issue(SQUARE_PUNCH, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stained Glass__________________________________________________
a = STAINED_GLASS = OrderedDict([
    (ok.FSM, deepcopy(MODE)),
    (ok.FSO, deepcopy(OPACITY)),
    (ok.WIDTH, deepcopy(WIDTH)),
    (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
    (ok.GLASS_PANE_W, deepcopy(WIDTH)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.SEED, deepcopy(SEED)),
    (ok.FNR, deepcopy(FNR)),
    (ok.SRR, deepcopy(SRR))
])
a[ok.FSO][wk.VAL] = 40.
a[ok.WIDTH][wk.VAL] = a[ok.GLASS_PANE_W][wk.VAL] = 55
a[ok.GLASS_PANE_W][wk.RANDOM] = 25, 100

a[ok.ANGLE].update({wk.VAL: 45.})
set_issue(a, (), vo.BAKE, NO_MATTER + (ok.ANGLE, ok.SEED))
set_issue(a, (ok.GLASS_PANE_W, ok.ANGLE, ok.SEED), vo.FILLER, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stretch Tray_________________________________
STRETCH_TRAY = OrderedDict([
    (ok.FSM, deepcopy(MODE)),
    (ok.FSO, deepcopy(OPACITY)),
    (ok.WIDTH, deepcopy(WIDTH)),
    (ok.FNR, deepcopy(FNR)),
    (ok.SRR, deepcopy(SRR))
])

set_issue(STRETCH_TRAY, (), vo.BAKE, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

SHADOWY = {ok.SHADOW: SHADOW}

# Wire Fence___________________________________
WIRE_FENCE = OrderedDict([
    (ok.MESH_TYPE, deepcopy(MESH_TYPE)),
    (ok.MESH_SIZE, deepcopy(MESH_SIZE)),
    (ok.WIDTH, deepcopy(WIDTH)),
    (ok.WIRE_THICKNESS, {
        wk.LIMIT: (3, 30),
        wk.RANDOM: (4, 10),
        wk.TIPPER: make_text_tip,
        wk.VAL: 3,
        wk.WIDGET: RandomSlider
    }),
    (ok.NEATNESS, deepcopy(NEATNESS)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.FNR, deepcopy(FNR)),
    (ok.SRR, deepcopy(SRR))
])
WIRE_FENCE[ok.ANGLE].update({wk.VAL: 45.})

set_issue(WIRE_FENCE, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
