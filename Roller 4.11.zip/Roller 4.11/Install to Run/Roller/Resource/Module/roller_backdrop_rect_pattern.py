#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_key import Option as ok
from roller_fu import (
    add_layer, color_fill_selection, copy_all_image, flip_layer, select_rect
)
from roller_maya_style import Style
from roller_view_hub import fill_with_clipboard
from roller_view_preset import combine_seed
from roller_view_real import do_rotated_layer, finish_style
import gimpfu as fu

pdb = fu.pdb


def make_pattern(d):
    """
    Make a rectangle pattern. The pattern is
    made-to-order and is then transferred
    to the canvas via the clipboard.

    d: dict
        Rectangle Pattern Preset
        {Option key: value}

    Return: image in the clipboard
        Is the pattern.
    """
    q_x1 = []

    # pattern size
    width, height = d[ok.WIDTH_CLIP], d[ok.HEIGHT_CLIP]

    # Make a hidden image to draw the pattern on, 'j'.
    j = pdb.gimp_image_new(width, height, fu.RGB)

    z = add_layer(j, "Pattern")
    count = d[ok.COLOR_COUNT]

    # Calculate the size of the rectangle, 'w, h'.
    # Use the rectangle to make selections for color fill.
    w, h = float(width) / count, float(height) / count

    is_brick = d[ok.COLOR_GRID_TYPE]
    is_random = d[ok.IFR][ok.RANDOM_ORDER]

    # x-intersect list, 'q_x'
    # for both checkerboard and brick
    q_x = [0] * (count + 1)
    q_x[-1] = width
    x = w

    for i in range(1, count):
        q_x[i] = int(x)
        x += w

    if is_brick:
        # x-intersect array for brick odd rows, 'q_x1'
        q_x1 = [0] * (count + 2)
        q_x1[-1] = width
        x = w / 2

        for i in range(1, count + 1):
            q_x1[i] = int(x)
            x += w

    # y-intersect array, 'q_y'
    q_y = [0] * (count + 1)
    q_y[-1] = height
    y = h

    for i in range(1, count):
        q_y[i] = int(y)
        y += h

    for row in range(count):
        columns = count

        if is_brick and row % 2:
            # Need an extra column for the half-cut bricks.
            columns += 1

        for column in range(columns):
            if is_random:
                # Get a random color from the color options.
                color = d[ok.COLOR_6A][randint(0, count - 1)]

            else:
                # Get the next color in the wrap-around color scheme.
                index = row * count + row + column

                while index >= count:
                    index -= count
                color = d[ok.COLOR_6A][index]

            if is_brick and row % 2:
                x = q_x1[column]
                w = q_x1[column + 1] - q_x1[column]

            else:
                x = q_x[column]
                w = q_x[column + 1] - q_x[column]

            y = q_y[row]
            h = q_y[row + 1] - q_y[row]

            # Select and fill the calculated rectangle.
            select_rect(j, x, y, w, h)
            color_fill_selection(z, color)

    if d[ok.IFR][ok.FLIP_V]:
        pdb.gimp_selection_none(j)
        flip_layer(z)

    # Set the Clipboard Image for the pattern fill op.
    copy_all_image(j)

    # Close the tile image as the pattern is done.
    pdb.gimp_image_delete(j)


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: RectanglePattern
    Return: layer
        with the style material
    """
    d = maya.value_d

    combine_seed(v, d)
    make_pattern(d)

    z = do_rotated_layer(v, d, fill_with_clipboard, maya.group, 0)

    if d[ok.IFR][ok.INVERT]:
        pdb.gimp_drawable_invert(z, 0)
    return finish_style(z, "Rectangle Pattern")


class RectPattern(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = False

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        k_path = d['k_path']
        d['k_path'] = [k_path, k_path + (ok.IFR,)]
        Style.__init__(self, *q + (make_style,), **d)
