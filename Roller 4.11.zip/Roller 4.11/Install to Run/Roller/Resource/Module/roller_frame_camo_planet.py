#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame import Color, select_border
from roller_frame_build import Build
from roller_fu import (
    add_layer, blur_selection, color_fill_selection
)
from roller_maya import check_frame_cake, check_matter, make_frame_group
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_one_gegl import (
    noise_rgb, saturation, video_degradation, waterpixels
)
from roller_view_real import COLOR, LIGHT, add_wip_layer, get_light
import gimpfu as fu

pdb = fu.pdb


def do_color(v, maya):
    """
    Make a color layer.

    v: View
    maya: Maya
    Return: layer
        with color
    """
    pdb.gimp_selection_none(v.j)

    d = maya.value_d
    a = maya.cause
    z = add_wip_layer(
        v, maya, "Color", maya.super_maya.group, offset=get_light(a)
    )
    noise = d[ok.SEED] + v.glow_ball.seed

    for i in range(3):
        q = ff.COMPONENT[d[ok.CAMO_TYPE]] + (noise + i,)
        noise_rgb(z, *q)

    waterpixels(z)
    pdb.gimp_brightness_contrast(z, 0, 75)
    saturation(z, d[ok.SATURATION])
    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: Frame
    Return: layer
        with the frame material
    """
    j = v.j
    cause = maya.cause.matter
    group = maya.group
    d = maya.value_d

    select_border(j, cause, d[ok.FRAME_W], d[ok.FRAME_TYPE])

    # layer for the emboss, 'z'
    z = add_layer(
        j,
        group.name + " Camo Planet",
        parent=group,
        offset=len(group.layers)
    )

    color_fill_selection(z, (255, 255, 255))
    blur_selection(z, 1.)
    pdb.plug_in_emboss(
        j, z,
        v.glow_ball.azimuth,
        v.glow_ball.elevation,
        1,                          # depth
        0                           # bump
    )
    video_degradation(z, 'dots')
    pdb.gimp_drawable_curves_spline(
        z,
        0,                          # HISTOGRAM_VALUE, '0'
        4,                          # four coordinates
        (.0, .2, 1., .8)
    )
    return z


class CamoPlanet(Build):
    """Is a metallic like frame."""
    is_seeded = is_embossed = True
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Option key,)
            Is the key path to the responsible Frame Button.
        """
        self.do_matter = do_matter

        Build.__init__(self, any_group, super_maya, k_path)

        self.sub_maya[COLOR] = Color(any_group, self, do_color, k_path)
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (self.cause, self), k_path + (ok.SRR, ok.SHADOW)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Camo Planet Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[COLOR].do(v, d, self.is_matter)

        is_back = self.sub_maya[ok.SHADOW].do(
            v,
            d[ok.SRR][ok.SHADOW],
            self.is_matter + self.is_cake,
            is_change + self.cause.is_cake
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return is_back
