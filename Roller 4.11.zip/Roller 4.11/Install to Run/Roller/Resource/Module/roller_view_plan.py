#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Signal as si
from roller_constant_key import Group as gk
from roller_fu import (
    hide_layer, remove_z, rename_layer, show_layer, validate_layer
)
from roller_one_the import The
from roller_view_output import Output
import gimpfu as fu

READY = "Plan Ready"
WORKING = "Plan Working"
pdb = fu.pdb


class Plan(Output):
    """Organize Plan methods."""

    def __init__(self):
        """
        Init once and reuse. Make sketchy output for View. Has a sibling, Work.
        """
        Output.__init__(self)
        The.cat.render.connect(si.CLOSE_VIEW_IMAGE, self.on_close_view_image)

    def delete(self):
        """Delete the Plan folder."""
        remove_z(self.plan_group)
        self.plan_group = None

    def delete_backdrop(self):
        """
        Delete the faux Backdrop Image layer.
        Is a Roller closing procedure.
        """
        remove_z(self.backdrop_layer)

    def do(self, v, step_q):
        """
        Perform a Plan View.

        v: View
        step_q: list
            of Step
        """
        def _refresh():
            # Remove selection because the marching ants are slow to draw.
            # Flush the display will fail if ignored for too long.
            pdb.gimp_selection_none(v.j)
            pdb.gimp_displays_flush()

        is_start = True

        self.show_view()
        v.work.hide_view()

        # Step, 'a'
        for any_group in step_q:
            k = any_group.step_key

            if is_start:
                # Rename the Plan layer to show activity.
                z = self.plan_group
                if rename_layer(z, WORKING):
                    is_start = False

            any_group.do(v)
            _refresh()

            if any_group.item.key in gk.IMAGE_SOURCE_USER:
                v.source_d[k] = deepcopy(v.image_source)

        z = self.plan_group

        if validate_layer(z):
            z.name = READY
            v.j.active_layer = z
        _refresh()

    def hide_view(self):
        """Hide the Plan group."""
        if validate_layer(self.plan_group):
            hide_layer(self.plan_group)
            pdb.gimp_displays_flush()

    def get_offset(self):
        """
        Get the offset needed for Product groups.

        Return: int
            0 or 1
        """
        return 1 if validate_layer(self.plan_group) else 0

    def on_close_view_image(self, sender, signal):
        """
        Reset the Plan group reference as it was deleted.

        sender: ViewImage
        signal: not used
        """
        self.plan_group = None

    def show_view(self):
        """Show the Plan group."""
        if validate_layer(self.plan_group):
            show_layer(self.plan_group)
            pdb.gimp_displays_flush()
