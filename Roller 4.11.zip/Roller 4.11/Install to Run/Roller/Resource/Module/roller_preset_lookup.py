#!/usr/bin/env python
# -*- coding: utf-8 -*-
import roller_backdrop_paper_waste as paper_waste
import roller_backdrop_acrylic_sky as acrylic_sky
import roller_backdrop_average_color as average_color
import roller_backdrop_carbon_14 as carbon_14
import roller_backdrop_clay_chemistry as clay_chemistry
import roller_backdrop_color_fill as color_fill
import roller_backdrop_color_grid as color_grid
import roller_backdrop_core_design as core_design
import roller_backdrop_crystal_cave as crystal_cave
import roller_backdrop_cube_pattern as cube_pattern
import roller_backdrop_cubism_cover as cubism_cover
import roller_backdrop_dark_fort as dark_fort
import roller_backdrop_density_gradient as density_gradient
import roller_backdrop_drop_zone as drop_zone
import roller_backdrop_etch_sketch as etch_sketch
import roller_backdrop_floor_sample as floor_sample
import roller_backdrop_galactic_field as galactic_field
import roller_backdrop_glass_gaw as glass_gaw
import roller_backdrop_gradient_fill as gradient_fill
import roller_backdrop_historic_trip as historic_trip
import roller_backdrop_image_gradient as image_gradient
import roller_backdrop_line_stone as line_stone
import roller_backdrop_lost_maze as lost_maze
import roller_backdrop_maze_blend as maze_blend
import roller_backdrop_mystery_grate as mystery_grate
import roller_backdrop_nano_suit as nano_suit
import roller_backdrop_noise_rift as noise_rift
import roller_backdrop_pattern_fill as pattern_fill
import roller_backdrop_rainbow_valley as rainbow_valley
import roller_backdrop_rect_pattern as rect_pattern
import roller_backdrop_rocky_landing as rocky_landing
import roller_backdrop_soft_touch as soft_touch
import roller_backdrop_specimen_speckle as specimen_speckle
import roller_backdrop_spiral_channel as spiral_channel
import roller_backdrop_square_cloud as square_cloud
import roller_backdrop_stone_age as stone_age
import roller_backdrop_trailing_vine as trailing_vine
import roller_frame_nail_polish as nail_polish
import roller_frame_ball_joint as ball_joint
import roller_frame_border_line as border_line
import roller_frame_brush_punch as brush_punch
import roller_frame_camo_planet as camo_planet
import roller_frame_ceramic_chip as ceramic_chip
import roller_frame_circle_punch as circle_punch
import roller_frame_clear_frame as clear_frame
import roller_frame_color_board as color_board
import roller_frame_color_pipe as color_pipe
import roller_frame_corner_tape as corner_tape
import roller_frame_crumble_shell as crumble_shell
import roller_frame_cutout_plate as cutout_plate
import roller_frame_feather_step as feather_step
import roller_frame_frame_over as frame_over
import roller_frame_glass_reveal as glass_reveal
import roller_frame_gradient_level as gradient_level
import roller_frame_hot_glue as hot_glue
import roller_frame_jagged_edge as jagged_edge
import roller_frame_line_fashion as line_fashion
import roller_frame_metallic_profile as metallic_profile
import roller_frame_paint_rush as paint_rush
import roller_frame_rad_wave as rad_wave
import roller_frame_raised_maze as raised_maze
import roller_frame_shadow as shadow
import roller_frame_shape_burst as shape_burst
import roller_frame_square_cut as square_cut
import roller_frame_square_punch as square_punch
import roller_frame_stained_glass as stained_glass
import roller_frame_stretch_tray as stretch_tray
import roller_frame_wire_fence as wire_fence
from roller_constant_key import BackdropStyle as by, Frame as ek


# key, value -> [Frame key: Frame Maya]
FRAME_D = {
    ek.BALL_JOINT: ball_joint.BallJoint,
    ek.BORDER_LINE: border_line.BorderLine,
    ek.BRUSH_PUNCH: brush_punch.BrushPunch,
    ek.CAMO_PLANET: camo_planet.CamoPlanet,
    ek.CERAMIC_CHIP: ceramic_chip.CeramicChip,
    ek.CIRCLE_PUNCH: circle_punch.CirclePunch,
    ek.CLEAR_FRAME: clear_frame.ClearFrame,
    ek.COLOR_BOARD: color_board.ColorBoard,
    ek.COLOR_PIPE: color_pipe.ColorPipe,
    ek.CORNER_TAPE: corner_tape.CornerTape,
    ek.CRUMBLE_SHELL: crumble_shell.CrumbleShell,
    ek.CUTOUT_PLATE: cutout_plate.CutoutPlate,
    ek.FEATHER_STEP: feather_step.FeatherStep,
    ek.FRAME_OVER: frame_over.FrameOver,
    ek.GLASS_REVEAL: glass_reveal.GlassReveal,
    ek.GRADIENT_LEVEL: gradient_level.GradientLevel,
    ek.HOT_GLUE: hot_glue.HotGlue,
    ek.JAGGED_EDGE: jagged_edge.JaggedEdge,
    ek.LINE_FASHION: line_fashion.LineFashion,
    ek.METALLIC_PROFILE: metallic_profile.MetallicProfile,
    ek.NAIL_POLISH: nail_polish.NailPolish,
    ek.PAINT_RUSH: paint_rush.PaintRush,
    ek.RAD_WAVE: rad_wave.RadWave,
    ek.RAISED_MAZE: raised_maze.RaisedMaze,
    ek.SHAPE_BURST: shape_burst.ShapeBurst,
    ek.SQUARE_CUT: square_cut.SquareCut,
    ek.SQUARE_PUNCH: square_punch.SquarePunch,
    ek.STAINED_GLASS: stained_glass.StainedGlass,
    ek.STRETCH_TRAY: stretch_tray.StretchTray,
    ek.SHADOWY: shadow.Shadowy,
    ek.WIRE_FENCE: wire_fence.WireFence
}
FRAME_MOD_D = {
    ek.BALL_JOINT: ball_joint,
    ek.BORDER_LINE: border_line,
    ek.BRUSH_PUNCH: brush_punch,
    ek.CAMO_PLANET: camo_planet,
    ek.CERAMIC_CHIP: ceramic_chip,
    ek.CIRCLE_PUNCH: circle_punch,
    ek.CLEAR_FRAME: clear_frame,
    ek.COLOR_BOARD: color_board,
    ek.COLOR_PIPE: color_pipe,
    ek.CORNER_TAPE: corner_tape,
    ek.CRUMBLE_SHELL: crumble_shell,
    ek.CUTOUT_PLATE: cutout_plate,
    ek.FEATHER_STEP: feather_step,
    ek.FRAME_OVER: frame_over,
    ek.GLASS_REVEAL: glass_reveal,
    ek.GRADIENT_LEVEL: gradient_level,
    ek.HOT_GLUE: hot_glue,
    ek.JAGGED_EDGE: jagged_edge,
    ek.LINE_FASHION: line_fashion,
    ek.METALLIC_PROFILE: metallic_profile,
    ek.NAIL_POLISH: nail_polish,
    ek.PAINT_RUSH: paint_rush,
    ek.RAD_WAVE: rad_wave,
    ek.RAISED_MAZE: raised_maze,
    ek.SHAPE_BURST: shape_burst,
    ek.SQUARE_CUT: square_cut,
    ek.SQUARE_PUNCH: square_punch,
    ek.STAINED_GLASS: stained_glass,
    ek.STRETCH_TRAY: stretch_tray,
    ek.SHADOWY: shadow,
    ek.WIRE_FENCE: wire_fence
}
STYLE_D = {
    by.ACRYLIC_SKY: acrylic_sky.AcrylicSky,
    by.AVERAGE_COLOR: average_color.AverageColor,
    by.CARBON_14: carbon_14.Carbon14,
    by.CLAY_CHEMISTRY: clay_chemistry.ClayChemistry,
    by.COLOR_FILL: color_fill.ColorFill,
    by.COLOR_GRID: color_grid.ColorGrid,
    by.CORE_DESIGN: core_design.CoreDesign,
    by.CRYSTAL_CAVE: crystal_cave.CrystalCave,
    by.CUBE_PATTERN: cube_pattern.CubePattern,
    by.CUBISM_COVER: cubism_cover.CubismCover,
    by.DARK_FORT: dark_fort.DarkFort,
    by.DENSITY_GRADIENT: density_gradient.DensityGradient,
    by.DROP_ZONE: drop_zone.DropZone,
    by.ETCH_SKETCH: etch_sketch.EtchSketch,
    by.FLOOR_SAMPLE: floor_sample.FloorSample,
    by.GALACTIC_FIELD: galactic_field.GalacticField,
    by.GLASS_GAW: glass_gaw.GlassGaw,
    by.GRADIENT_FILL: gradient_fill.GradientFill,
    by.HISTORIC_TRIP: historic_trip.HistoricTrip,
    by.IMAGE_GRADIENT: image_gradient.ImageGradient,
    by.LINE_STONE: line_stone.LineStone,
    by.LOST_MAZE: lost_maze.LostMaze,
    by.MAZE_BLEND: maze_blend.MazeBlend,
    by.MYSTERY_GRATE: mystery_grate.MysteryGrate,
    by.NANO_SUIT: nano_suit.NanoSuit,
    by.NOISE_RIFT: noise_rift.NoiseRift,
    by.PAPER_WASTE: paper_waste.PaperWaste,
    by.PATTERN_FILL: pattern_fill.PatternFill,
    by.RAINBOW_VALLEY: rainbow_valley.RainbowValley,
    by.RECT_PATTERN: rect_pattern.RectPattern,
    by.ROCKY_LANDING: rocky_landing.RockyLanding,
    by.SOFT_TOUCH: soft_touch.SoftTouch,
    by.SPECIMEN_SPECKLE: specimen_speckle.SpecimenSpeckle,
    by.SPIRAL_CHANNEL: spiral_channel.SpiralChannel,
    by.SQUARE_CLOUD: square_cloud.SquareCloud,
    by.STONE_AGE: stone_age.StoneAge,
    by.TRAILING_VINE: trailing_vine.TrailingVine
}

# module, 'MOD'
STYLE_MOD_D = {
    by.PAPER_WASTE: paper_waste,
    by.ACRYLIC_SKY: acrylic_sky,
    by.AVERAGE_COLOR: average_color,
    by.CARBON_14: carbon_14,
    by.CLAY_CHEMISTRY: clay_chemistry,
    by.COLOR_FILL: color_fill,
    by.COLOR_GRID: color_grid,
    by.CORE_DESIGN: core_design,
    by.CRYSTAL_CAVE: crystal_cave,
    by.CUBE_PATTERN: cube_pattern,
    by.CUBISM_COVER: cubism_cover,
    by.DARK_FORT: dark_fort,
    by.DENSITY_GRADIENT: density_gradient,
    by.DROP_ZONE: drop_zone,
    by.ETCH_SKETCH: etch_sketch,
    by.FLOOR_SAMPLE: floor_sample,
    by.GALACTIC_FIELD: galactic_field,
    by.GLASS_GAW: glass_gaw,
    by.GRADIENT_FILL: gradient_fill,
    by.HISTORIC_TRIP: historic_trip,
    by.IMAGE_GRADIENT: image_gradient,
    by.LINE_STONE: line_stone,
    by.LOST_MAZE: lost_maze,
    by.MAZE_BLEND: maze_blend,
    by.MYSTERY_GRATE: mystery_grate,
    by.NANO_SUIT: nano_suit,
    by.NOISE_RIFT: noise_rift,
    by.PATTERN_FILL: pattern_fill,
    by.RAINBOW_VALLEY: rainbow_valley,
    by.RECT_PATTERN: rect_pattern,
    by.ROCKY_LANDING: rocky_landing,
    by.SOFT_TOUCH: soft_touch,
    by.SPECIMEN_SPECKLE: specimen_speckle,
    by.SPIRAL_CHANNEL: spiral_channel,
    by.SQUARE_CLOUD: square_cloud,
    by.STONE_AGE: stone_age,
    by.TRAILING_VINE: trailing_vine
}
OPTION_D = {}

OPTION_D.update(FRAME_MOD_D)
OPTION_D.update(STYLE_MOD_D)
