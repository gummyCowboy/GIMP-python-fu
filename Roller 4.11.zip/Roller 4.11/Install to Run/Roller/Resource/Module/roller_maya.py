#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Deco as dc, Issue as vo, Model as mo, Signal as si
)
from roller_constant_key import Option as ok
from roller_fu_mode import translate_mode
from roller_fu import make_layer_group, remove_z, set_layer_attr
from roller_one_image import Image as ig
from roller_one_the import The
from roller_view_contain import Deco
from roller_view_real import remove_maya_z
import gimpfu as fu
import os

MAIN = 'main'
NO_VOTE = 'NO VOTE'
PER = 'per'
pdb = fu.pdb


def assign_deco_image(v, d):
    """
    For every View, there is an image. Fetch an image for a Plaque Preset.

    v: View
    d: dict
        Preset

    Return: Image or None
    """
    if d[ok.SWITCH] and d[ok.TYPE_DECO] == dc.IMAGE:
        e = d[ok.IMAGE_CHOICE]
        if e[ok.SWITCH]:
            return ig.get_image(e, v.image_source)


def assign_deco_face_image(v, maya):
    """
    Assign images for deco Face.

    v: View
    maya: Maya
    """
    d = maya.value_d
    per_cell = d[ok.PER_CELL]
    cell_d = maya.cell_d
    for r_c in maya.model.cell_q:
        if r_c in per_cell:
            e = per_cell[r_c]
            face_maya = cell_d[r_c]

        else:
            e = d
            face_maya = maya

        # Face count, '3'
        image = [assign_deco_image(v, e) for _ in range(3)]

        pre_image = face_maya.get_image(r_c)

        if image != pre_image:
            face_maya.is_matter = True
        face_maya.set_image(r_c, image)


def assign_mask_image(v, d):
    """
    Assign an image for a Mask Preset.

    v: View
    d: dict
        Mask Preset

    Return: Image or None
    """
    if d[ok.SWITCH] and d[ok.MASK_TYPE] == dc.IMAGE:
        e = d[ok.IBR][ok.IMAGE_CHOICE]
        if e[ok.SWITCH]:
            return ig.get_image(e, v.image_source)


def bag_vote(maya, d, k_path):
    """
    Extract vote from a vote dict for Maya. Convert issue key
    found in a collected vote dict to Maya vote attribute.

    maya: Maya
        to receive vote

    d: dict
        Has relational vote.

    k_path: tuple
        (Option key, ...)
        Is a path to a relational structured vote dict.
    """
    for k in k_path:
        if k in d:
            d = d[k]
        else:
            d = {}
            break

    for i, a in d.items():
        if i in maya.issue_q and isinstance(a, dict):
            n = 'is_' + i
            vote = None

            for i1, b in a.items():
                if isinstance(b, bool):
                    if vote is None:
                        vote = b

                    else:
                        vote |= b
                    if vote:
                        break
            if vote is not None:
                setattr(maya, n, vote)
    take_great_vote(maya)


def check_cake(v, maya):
    """
    Determine the matter layer's mode or opacity change.
    It's Layer Cake like the movie.

    v: View
    maya: Maya
    """
    if maya.is_cake or maya.is_matter:
        d = maya.value_d

        set_layer_attr(maya.matter, translate_mode(d[ok.MODE]), d[ok.OPACITY])
        v.is_back = True


def check_color(v, maya):
    """
    Determine if material has changed. Make material if so.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    if maya.is_color:
        return check_layer(v, maya, 'matter', maya.do_matter)
    return maya.matter


def check_color_style(v, maya):
    """
    Determine a layer's mode or opacity change
    for Color Maya's Frame Style option.

    v: View
    maya: Maya
    """
    if maya.is_cake or maya.is_color:
        d = maya.value_d

        set_layer_attr(maya.matter, translate_mode(d[ok.FSM]), d[ok.FSO])
        v.is_back = True


def check_filler(v, maya):
    """
    Determine if material has changed. Make material if so.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    if maya.is_filler:
        return check_layer(v, maya, 'matter', maya.do_matter)
    return maya.matter


def check_filler_cake(v, maya):
    """
    Determine a layer's mode or opacity change
    for Filler Maya's Frame Style option.

    v: View
    maya: Maya
    """
    if maya.is_cake or maya.is_filler:
        d = maya.value_d

        set_layer_attr(maya.matter, translate_mode(d[ok.FSM]), d[ok.FSO])
        v.is_back = True


def check_frame_cake(v, maya):
    """
    Determine a Frame's matter layer's mode or opacity change.

    v: View
    maya: Maya
    """
    if maya.is_cake or maya.is_matter:
        d = maya.value_d

        set_layer_attr(
            maya.matter, translate_mode(d[ok.FRAME_MODE]), d[ok.FRAME_OPACITY]
        )
        v.is_back = True


def check_frame_mask_group(v, maya):
    """
    Make a group for the feather mask.

    v: View
    maya: Maya
        Frame type

    Return: layer
        group
    """
    maya.group = make_frame_group(v, maya)

    if maya.group:
        z = maya.super_maya.group
        if z.parent != maya.group:
            pdb.gimp_image_reorder_item(v.j, z, maya.group, 0)
    return maya.group


def check_layer(v, maya, n, p):
    """
    Make or remove a layer. The layer is assumed to need an update.

    v: View
    maya: Maya

    n: string
        layer attribute descriptor

    p: function
        Call to make View output.

    Return: layer or None
        with material
    """
    z = getattr(maya, n)

    if z:
        remove_maya_z(maya, n)

    z = p(v, maya)
    v.is_back = True
    return z


def check_matter(v, maya):
    """
    Determine if material has changed. Make material if so.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    if maya.is_matter:
        return check_layer(v, maya, 'matter', maya.do_matter)
    return maya.matter


def check_metal_frame_cake(v, maya):
    """
    Determine a Metal Frame's matter layer's mode or opacity change.

    v: View
    maya: Maya
    """
    if maya.is_cake or maya.is_matter:
        d = maya.value_d[ok.FNR][ok.FRAME_METAL]

        set_layer_attr(
            maya.matter, translate_mode(d[ok.FRAME_MODE]), d[ok.FRAME_OPACITY]
        )
        v.is_back = True


def check_shadow(v, maya):
    """
    Determine if shadow has changed. Make a shadow layer if so.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    if maya.is_shadow:
        return check_layer(v, maya, 'shadow', maya.do_shadow)
    return maya.shadow


def format_image_name(j):
    """
    Get the name of an image, without its file extension, assigned to a cell

    j: Image
        Has an image and layer name.

    Return: string
        an image name without file type suffix
    """
    if j.layer_name:
        return j.layer_name

    n = j.image_name

    if os.path.isfile(n):
        return os.path.basename(os.path.splitext(n)[0])
    return n


def get_sub_maya_vote(d, row_k, k):
    """
    From a hierarchical vote dict, find a sub-maya vote dict.

    d: dict
        Has vote.

    row_k: string
        Is a Row key where the option is found.

    k: string
        Is an Option key with accumulated vote.

    Return: dict
        Is the sub-Maya vote dict.
    """
    if row_k:
        a = d.get(row_k)
        if a:
            b = a.get(k)
            if b:
                return b

    a = d.get(k)

    if a:
        return a
    return {}


def init_per_cell(maya):
    """
    Before performing layer output, init the cell.

    maya: Maya
        Per Cell variety
    """
    maya.value_d = maya.per_cell_group.get_cell_value(maya.r_c)
    maya.step_key = maya.any_group.step_key + (
        "{}.{}".format(maya.r_c[0] + 1, maya.r_c[1] + 1),
    )


def make_frame_group(v, maya):
    """
    Make a Frame layer group. Is a sub-group of the super maya's layer group.

    v: View
    maya: Maya
    Return: layer group
        for frame
    """
    return make_sub_group(v, maya, " Frame")


def make_filler_group(v, maya):
    """
    Make a Frame layer group. Is a sub-group of the super Maya's layer group.

    v: View
    maya: Maya
    Return: layer group
        for frame
    """
    return make_sub_group(v, maya, " Filler")


def make_sub_group(v, maya, n):
    """
    Make a Frame layer group. Is a sub-group of the super Maya's layer group.

    v: View
    maya: Maya
    n: string
        group name appendix

    Return: layer group
        for frame
    """
    parent = maya.cause.group.parent
    group = maya.group

    if not group:
        return make_layer_group(v.j, parent.name + n, parent=parent)
    return group


def make_source_key(d):
    """
    The source key is a signal key for notifying an image source sequence.

    d: dict
        Image Choice Preset

    Return: string
        signal key
    """
    k = d[ok.IMAGE_SOURCE]
    is_folder = k == ok.FOLDER
    key = (k,)

    if is_folder:
        if is_folder:
            key += (d[ok.FILTER],)
            if d[ok.RANDOM_ORDER]:
                key += (d[ok.SEED],)
    return key


def on_global(maya, arg, option_k, issue=vo.MATTER):
    """
    Respond to a Global option change.

    maya: Maya
    arg: list
        [Plan vote, Work vote]

    option_k: string
        Option key
        Is responsible for the vote.

    issue: string
        Is altered by the vote.
    """
    d = maya.great_vote_d

    # Find the Cell Maya and set its 'per_cell' vote to True.
    # The 'per_cell' issue is voted on when a Per Cell Maya
    # has change, or in this case, when there is Global change.
    chain = maya

    while chain:
        if 'per_cell' in chain.issue_q:
            # Found the Cell Maya, 'chain'.
            if not chain.is_per_cell:
                a = chain.any_group

                a.accept_vote(1, option_k, vo.PER_CELL, True)
                chain.take_vote(a.vote_q[1])
                break
        chain = chain.super_maya if hasattr(chain, 'super_maya') else None

    if issue not in d:
        d[issue] = {}

    d[issue][option_k] = arg[maya.view_x]

    take_great_vote(maya)
    maya.any_group.changed(maya.view_x)


def prep_main_step(v, maya):
    """
    Undo a Per Cell type step. Init View's Deco.

    v: View
    maya: Maya
    """
    v.deco = Deco()

    pdb.gimp_selection_none(v.j)
    if not maya.main_cell_q:
        maya.die(v)


def retire_sub_maya(sub_maya):
    """
    Remove Maya layer output and its sub-Maya output.

    sub_maya: dict
        of sub-Maya
    """
    for k, a in sub_maya.items():
        a.set_issue()
        retire_sub_maya(a.sub_maya)
        for i in a.order:
            if i:
                remove_maya_z(a, i)


def take_type_vote(v, d):
    """
    Border, Fringe, and Plaque have background
    sensitive types. If the background has changed
    with these types, then vote for change
    on that background-changed cause.

    v: View
    d: dict
        deco type Preset
        {Option key: value}

    Return: bool
        If true, then the matter layer has change.
    """
    if v.is_back and d[ok.TYPE_DECO] in (dc.AVERAGE_COLOR, dc.BACKDROP):
        return True
    return False


def take_great_vote(maya):
    """
    Set Maya issue from the great vote dict.

    maya: Maya
    """
    for i, a in maya.great_vote_d.items():
        if i in maya.issue_q and isinstance(a, dict):
            n = 'is_' + i
            vote = None

            for i1, b in a.items():
                if isinstance(b, bool):
                    if vote is None:
                        vote = b

                    else:
                        vote |= b
                    if vote:
                        break
            if vote is not None:
                vote |= getattr(maya, n)
                if vote:
                    setattr(maya, n, vote)


class Maya(object):
    """Is a super class. Is an object for Python 2.7."""

    def __init__(self, any_group, view_x, q, k_path=()):
        """
        any_group: AnyGroup
        q: list or None
            [(function, function output name)]

            Are function called in sequence. It's return value is
            assigned to an attribute defined by function output name.

        k_path: tuple or list
            (Option key, ...)
            [(Option key, ...), ...]

            A tuple key is a path to a sub-vote dict.
            The key is needed to find an options vote in a
            vote dict where some options are nested.

            A list of tuple have multiple key path where
            each path is to another vote dict collection
            perused when taking vote.
        """
        self.go = True
        self.handle_d = {}
        self.great_vote_d = {}
        self.k_path = k_path
        self.rect = None
        self.any_group = any_group
        self.view_x = view_x
        self.model = any_group.item.model
        self.value_d = any_group.value_d
        self.per_cell_group = any_group.widget_d[ok.PER_CELL] \
            if ok.PER_CELL in any_group.widget_d \
            else None

        # Call on View run function list, '_make'.
        self._make = [i[0] for i in q]

        # Name function output layer attribute list, 'order'.
        self.order = [i[1] for i in q]

        # Have layer output to remove. Layer output
        # is removed on Maya death and sometimes on change.
        self.sub_maya = {}

        # Are layer output reference.
        for p, n in q:
            if n:
                setattr(self, n, None)

        self.take_vote = self._mash_vote if isinstance(k_path, list) \
            else self._grab_vote
        self.handle_d[The.cat.render.connect(
            si.CLOSE_VIEW_IMAGE, self.on_close_view_image
        )] = The.cat.render
        self.handle_d[The.power.connect(si.RESIZE, self.on_resize)] = The.power
        self.handle_d[
            The.power.connect(si.PANEL_CHANGE, self.on_panel_change)
        ] = The.power
        self.handle_d[
            self.any_group.connect(si.DISAPPEAR, self.on_disappear_group)
        ] = self.any_group
        if k_path != NO_VOTE:
            if hasattr(self, 'is_seeded'):
                self.handle_d[
                    The.power.connect(
                        si.GLOBAL_SEED, self.on_global_seed
                    )
                ] = The.power

            if hasattr(self, 'is_embossed'):
                self.handle_d[
                    The.power.connect(
                        si.GLOBAL_EMBOSS, self.on_global_emboss
                    )
                ] = The.power

            if self.vote_type == MAIN:
                self.handle_d[
                    any_group.booth.connect(
                        si.VOTE_CHANGE, self.on_vote_change
                    )
                ] = any_group.booth
                self.handle_d[
                    self.any_group.connect(si.SEQUENCE, self.on_sequence)
                ] = self.any_group
            elif hasattr(self, 'r_c'):
                # Per Cell Maya
                self.handle_d[
                    self.per_cell_group.connect(
                        si.PER_CELL_CHANGE, self.on_per_cell_change
                    )
                ] = self.per_cell_group

    def _grab_vote(self, d):
        """
        Vote on issue given a vote dict.

        d: dict
            Has relational vote.
        """
        bag_vote(self, d, self.k_path)

    def _mash_vote(self, d):
        """
        Vote on issue given a vote dict with multiple vote sources.

        d: dict
            Has relational and nested vote.
        """
        for k_q in self.k_path:
            bag_vote(self, d, k_q)

    def die(self, v):
        """
        Remove its layer output.

        v: View
        """
        for i in self.order:
            if i:
                z = getattr(self, i)
                if z:
                    remove_z(z)
                    setattr(self, i, None)
                    v.is_back = True

        retire_sub_maya({None: self})
        self.set_issue()

    def on_close_view_image(self, _, arg):
        """
        Reset the Plan group reference as it was deleted.

        _: ViewImage
            Sent the signal.

        arg: not used
        """
        for i in self.order:
            if i:
                setattr(self, i, None)
        self.reset()

    def on_disappear(self, _, r_c_q):
        """
        The Maya is no longer used, so disconnect its subscription.

        r_c_q: tuple
            set of (row, column)
            Identify Maya with the view and cell index.
        """
        def _unplug(_maya):
            _maya.die(The.view)

            for _i, _a in _maya.handle_d.items():
                _a.disconnect(_i)
            _maya.handle_d = {}

        def _poof(_maya):
            for _, _maya in _maya.sub_maya.items():
                _unplug(_maya)
                _poof(_maya)
            _maya.sub_maya = {}

        for r_c in r_c_q:
            if r_c in self.cell_d:
                maya = self.cell_d[r_c]

                _unplug(maya)
                self.cell_d.pop(r_c)

                # Remove the Maya's ability to take sub-vote.
                _poof(maya)
        pdb.gimp_displays_flush()

    def on_disappear_group(self, _, arg):
        """
        The Maya is no longer used, so disconnect its subscription.

        _: AnyGroup
            Sent the Signal.
        arg: None
        """
        self.die(The.view)

        for i, a in self.handle_d.items():
            a.disconnect(i)

        # Remove the Maya's ability to take sub-vote.
        self.cell_d = self.sub_maya = self.handle_d = {}

        pdb.gimp_displays_flush()

    def on_global_emboss(self, _, arg):
        """
        Respond to a Global emboss option change.

        _: Power
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
        """
        on_global(self, arg, ok.IS_EMBOSS)

    def on_global_seed(self, _, arg):
        """
        Respond to a Global Seed option change.

        _: Power
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
        """
        on_global(self, arg, ok.IS_SEED)

    def on_panel_change(self, _, arg):
        """
        Check to see if the Maya is still online. If the Maya
        is offline or has been deleted, then kill the Maya.

        _: Power
            Sent the Signal.

        arg: None
        """
        k = self.any_group.step_key
        if not The.helm.finds(k):
            self.die(The.view)

            for i, a in self.handle_d.items():
                a.disconnect(i)
            pdb.gimp_displays_flush()

    def on_per_cell_change(self, _, arg):
        """
        Respond to change from its PerCellGroup.
        Create Per Cell Maya to mirror PerCellGroup cell addition.

        _: PerCellGroup
            Sent the Signal.

        arg: tuple
            ((row, column), vote dict, view index)
            The row and column work together as a cell index.
            The vote dict has vote for cell referenced by the cell index.
        """
        def _trickle(_d):
            """
            Recursively trickle down the vote through the sub-maya pyramid.

            _d: dict
                sub-Maya
                {sub-Maya key: Maya}
            """
            for _, _b in _d.items():
                _b.take_vote(d)
                _trickle(_b.sub_maya)

        r_c, d, x = arg
        if x == self.view_x and r_c == self.r_c:
            self.take_vote(d)
            _trickle(self.sub_maya)

    def on_resize(self, _, arg):
        """
        Cast a View image size change vote for both Plan and Work.

        _: Power
            Sent the signal.

        arg: list
            [Plan vote, Work vote]
        """
        on_global(self, [True, True], ok.IS_NEW)

    def on_sequence(self, _, arg):
        """
        Respond to change taking place in a Model sequence calculation.
        The 'matter' vote has already been added to the AnyGroup's vote
        dict, but now it needs to be counted so to speak.

        _: AnyGroup
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
        """
        # Plan and Work, '2'
        for x in range(2):
            self.take_vote(self.any_group.vote_q[x])

    def on_vote_change(self, _, x):
        """
        Respond to VOTE_CHANGE Signal from its AnyGroup.
        Convert sub vote dict to Maya vote.

        x: int
            Plan or Work
            0 or 1
        """
        if x == self.view_x:
            self.take_vote(self.any_group.vote_q[x])

    def realize(self, v):
        """
        Create, modify, and delete layer output.

        v: View
        """
        if not self.go:
            self.die(v)
        else:
            for x, i in enumerate(self.order):
                a = self._make[x](v, self)
                if i:
                    setattr(self, i, a)

    def realize_vote(self, v):
        """
        Call to manage layer output and then reset the vote.

        v: View
        """
        self.realize(v)
        self.reset_issue()

    def reset(self):
        """Is called when the View image closes."""
        for i in self.issue_q:
            self.any_group.cast_vote(self.view_x, ok.IS_NEW, i, True)

    def reset_issue(self):
        """Indicate no change."""
        self.great_vote_d = {}
        for i in self.issue_q:
            setattr(self, 'is_' + i, False)

    def set_issue(self):
        """Set issue for self and sub-Maya to True."""
        for i in self.issue_q:
            setattr(self, 'is_' + i, True)
        for i, a in self.sub_maya.items():
            a.set_issue()


class Roll(Maya):
    """Has a prep call for Per Cell. Is for Per Cell Maya."""

    def __init__(self, *arg, **kwarg):
        """
        arg: tuple
            Maya spec

        kwarg: dict
            Maya spec
        """
        self.main_cell_q = ()
        Maya.__init__(self, *arg, **kwarg)

    def do(self, v):
        """
        Is an entry point for AnyGroup processing a View.

        v: View
        """
        self.main_cell_q = self.model.get_main_list(self.value_d)

        self.prep(v)
        self.dig(v)


class ImageRoll(Roll):
    """Manage assigned image."""

    def __init__(self, *arg, **kwarg):
        """
        arg: tuple
            Maya spec

        kwarg: dict
            Maya spec
        """
        # The three dict have the same structure.
        # Canvas has a None key.
        # {(r, c) or None: Image or None}
        self._image_d = {}
        self._frame_image = {}
        self._mask_image = {}
        Roll.__init__(self, *arg, **kwarg)

    @staticmethod
    def _get_image(r_c, d):
        """
        Find the Image reference made for a Cell-branch.
        Use the Cell index variable as a key.

        r_c: tuple or None
            (row, column) of int
            cell index; Goo key
            Is None for Canvas.

        d: dict
            Has (row, column) or None key.

        Return: Image or None
            Is None when no image was assigned.
        """
        if r_c in d:
            return d[r_c]

    def get_face_name(self, r, c, face_x):
        """
        Get mask image reference.

        r, c: int
            cell index

        face_x: int
            Face index

        Return: string or None
            layer or image name
        """
        j = self.get_image((r, c))[face_x]
        if j:
            return format_image_name(j)

    def get_frame_image(self, r_c):
        """
        Get mask image reference.

        r_c: tuple
            (row, column); cell index; of int

        Return: Image or None
            Assigned to the Frame Maya.
        """
        return ImageRoll._get_image(r_c, self._frame_image)

    def get_image(self, r_c):
        """
        Fetch an Image reference made for a Cell-branch.

        r_c: tuple or None
            (row, column) of int
            cell index; Goo key
            Is None for Canvas.

        Return: Image or None
        """
        if hasattr(self, 'cell_d'):
            if r_c in self.cell_d:
                return self.cell_d[r_c].get_image(r_c)
        if r_c in self._image_d:
            return self._image_d[r_c]

    def get_image_name(self, r_c):
        """
        Get an image name from an Image reference.

        r_c: (r, c) or None
            cell index

        Return: string or None
            layer or image name
        """
        j = self.get_image(r_c)
        if j:
            return format_image_name(j)

    def get_mask_image(self, r_c):
        """
        Get a mask image reference.

        r_c: tuple
            (row, column); cell index; Goo key; of int

        Return: the 'mask_image' attribute
        """
        return ImageRoll._get_image(r_c, self._mask_image)

    def set_frame_image(self, r_c, j):
        """
        The Frame option has an Image reference.

        r_c: tuple
            (row, column)
            zero-based cell index

        j: Image
            to remember
        """
        self._frame_image[r_c] = j

    def set_image(self, r_c, j):
        """
        The Maya's Preset has an Image reference.
        Remember the Image for later access.

        r_c: tuple
            (row, column)
            zero-based cell index

        j: Image
            to remember
        """
        self._image_d[r_c] = j

    def set_mask_image(self, r_c, j):
        """
        The Maya's Preset has a mask reference.

        r_c: tuple
            (row, column)
            zero-based cell index

        j: Image
            to remember
        """
        self._mask_image[r_c] = j


class CellRoute:
    """Manage Cell-branch output."""
    cell_type = mo.MAIN

    def __init__(self, per_cell_type):
        """
        per_cell_type: Class
            Per Cell Maya
        """
        # Has Cell Maya for each Per Cell.
        # key, value -> {(r, c): Cell-branch Maya}
        self.cell_d = {}

        self.r_c = None
        self.per_cell_type = per_cell_type

        # main step key
        self.step_key = self.any_group.step_key + (".",)

        self.handle_d[
            self.per_cell_group.connect(si.DISAPPEAR, self.on_disappear)
        ] = self.per_cell_group
        self.handle_d[
            self.per_cell_group.connect(
                si.PER_CELL_CHANGE, self.on_cell_d_change
            )
        ] = self.per_cell_group

    def dig(self, v):
        """
        Check change and produce layer output for main Cell and Per Cell.

        v: View
        """
        d = self.cell_d

        prep_main_step(v, self)
        self.bore(v)

        if self.is_per_cell or v.is_back:
            for r_c in self.model.cell_q:
                if r_c in d:
                    maya = d[r_c]

                    init_per_cell(maya)
                    maya.bore(v)
                    maya.reset_issue()
        self.reset_issue()

    def on_cell_d_change(self, _, arg):
        """
        Respond to change from the AnyGroup's PerCellGroup.
        Create Per Cell Maya to mirror PerCellGroup cell addition.

        _: PerCellGroup
            Sent the Signal.

        arg: tuple
            ((row, column), vote dict, view index)
            The row and column work together as a cell index and Goo key.
            The vote dict has vote for cell referenced by the cell index.
        """
        r_c, vote_d, x = arg
        if x == self.view_x:
            if r_c not in self.cell_d:
                self.cell_d[r_c] = self.per_cell_type(self.any_group, r_c)


class Cell(CellRoute):
    """Use with deco step that secede Cell Margin."""

    def __init__(self, *arg, **kwarg):
        CellRoute.__init__(self, *arg, **kwarg)

    def prep(self, v):
        """
        Assign image. There is no Mask or Frame image.

        v: View
        """
        d = self.value_d
        cell_d = self.cell_d
        per_cell = d[ok.PER_CELL]
        for r_c in self.model.cell_q:
            if r_c in per_cell:
                cell_maya = cell_d[r_c]
                e = per_cell[r_c]
                if r_c in d:
                    self.remove_ref(r_c)

            else:
                cell_maya = self
                e = d

            image = assign_deco_image(v, e)
            pre_image = cell_maya.get_image(r_c)

            if image != pre_image:
                cell_maya.is_matter = True
            cell_maya.set_image(r_c, image)


class CanvasRoute:
    """Has common Canvas-branch function."""
    is_face = False
    cell_type = mo.CANVAS

    def __init__(self):
        self.r_c = None
        self.step_key = self.any_group.step_key + ("Main",)

    def dig(self, v):
        """
        Produce layer output.

        v: View
        """
        self.bore(v)
        self.reset_issue()


class Canvas(CanvasRoute):
    """Has common Canvas function for Preset with Image assignment."""

    def __init__(self):
        CanvasRoute.__init__(self)

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        image = assign_deco_image(v, self.value_d)

        if image != self.get_image(None):
            self.is_matter = True
        self.set_image(None, image)


class Plasma(ImageRoll):
    """Use with Border, Fringe and Plaque."""
    is_seeded = True

    def __init__(self, *q, **d):
        ImageRoll.__init__(self, *q, **d)

    def on_global_seed(self, _, arg):
        """
        The Global Random Seed option has changed.
        Check to see if the layer output is seed dependent.

        _: Power
            Sent the signal.

        arg: tuple
            (Plan vote, Work vote)
        """
        d = self.any_group.value_d if self.vote_type == MAIN else \
            self.per_cell_group.get_cell_value(self.r_c)

        if d[ok.TYPE_DECO] != dc.PLASMA:
            # no change
            arg = [False, False]
        super(Plasma, self).on_global_seed(_, arg)

    def on_back_change(self, _, x):
        """
        The background changed for the group.

        _: AnyGroup
            Sent the Signal.

        x: int
            Plan or Work index
        """
        if x == self.view_x:
            d = self.any_group.value_d if self.vote_type == MAIN else \
                self.per_cell_group.get_cell_value(self.r_c)
            if d[ok.TYPE_DECO] in dc.BACKED:
                arg = [None, None]
                arg[x] = True
                on_global(self, arg, ok.IS_BACK)
