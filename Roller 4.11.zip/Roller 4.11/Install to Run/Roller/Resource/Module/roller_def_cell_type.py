#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Shape as sh, Issue as vo
from roller_constant_key import Option as ok, Widget as wk
from roller_def_share import (
    CELL_SHAPE_CELL,
    CELL_SIZE,
    FCI,
    GRID_COUNT,
    GRID_SIZE,
    GRID_TYPE,
    MASK_SCALE,
    MAX_POLAR,
    PER_CELL,
    PIN_CORNER,
    set_issue
)
from roller_one_tip import Tip
from roller_widget_combo import ComboBox
from roller_widget_radio import SwitchRadio
from roller_widget_row_list import RowList
from roller_widget_slider import RowCountSlider


def get_box_type_list():
    return sh.BOX_TYPE


def get_equilateral_list():
    return sh.EQUILATERAL_LIST


def get_shape_list():
    return sh.SHAPE_LIST


# Type Box__________________________________
TYPE_BOX = OrderedDict([
    (ok.BOX_TYPE, {
        wk.FUNCTION: get_box_type_list,
        wk.VAL: sh.TOP,
        wk.WIDGET: ComboBox
    }),
    (ok.GRID_TYPE, deepcopy(GRID_TYPE)),
    (ok.PIN_CORNER, deepcopy(PIN_CORNER)),
    (ok.ROW_COUNT, deepcopy(GRID_COUNT)),
    (ok.COLUMN_COUNT, deepcopy(GRID_COUNT)),
    (ok.ROW_H, deepcopy(CELL_SIZE)),
    (ok.COLUMN_W, deepcopy(CELL_SIZE)),
    (ok.VERT_COUNT, deepcopy(GRID_COUNT)),
    (ok.HORZ_COUNT, deepcopy(GRID_COUNT)),
    (ok.FCI, deepcopy(FCI)),
    (ok.GRID_SIZE, deepcopy(GRID_SIZE))
])

set_issue(TYPE_BOX, (), vo.MATTER, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Type Cell___________________________________________
TYPE_CELL = OrderedDict([
    (ok.CELL_SHAPE, deepcopy(CELL_SHAPE_CELL)),
    (ok.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE))
])

TYPE_CELL[ok.PARALLELOGRAM_SCALE][wk.VAL] = .7
set_issue(TYPE_CELL, (), vo.MATTER, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Type Pyramid________________________________________
TYPE_PYRAMID = OrderedDict([
    (ok.DIRECTION, {
        wk.COLUMN_TEXT: ok.DIRECTION,
        wk.TEXT: ("Up", "Down"),
        wk.VAL: 0,
        wk.WIDGET: SwitchRadio
    }),
    (ok.ROW_COUNT, {
        wk.LIMIT: (1, 100),
        wk.PAGE_INCR: 2,
        wk.VAL: 1,
        wk.WIDGET: RowCountSlider
    }),
    (ok.COLUMN_COUNT, deepcopy({
        wk.VAL: [1],
        wk.WIDGET: RowList
    })),
])

set_issue(TYPE_PYRAMID, (), vo.MATTER, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Type Stack______________________________________________
TYPE_STACK = OrderedDict([
    (ok.CELL_SHAPE, deepcopy(CELL_SHAPE_CELL)),
    (ok.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE)),
    (ok.CELL_COUNT, deepcopy(GRID_COUNT)),
    (ok.ADD_OFFSET_X, deepcopy(MAX_POLAR)),
    (ok.ADD_OFFSET_Y, deepcopy(MAX_POLAR))
])

for x, i in enumerate((ok.ADD_OFFSET_X, ok.ADD_OFFSET_Y)):
    TYPE_STACK[i].update({
        wk.AXIS: ('x', 'y')[x],
        wk.TOOLTIP: Tip.ADD_SHIFT_XY
    })
TYPE_STACK[ok.PARALLELOGRAM_SCALE][wk.VAL] = .7

set_issue(TYPE_STACK, (), vo.MATTER, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Type Table________________________________________
TYPE_TABLE = OrderedDict([
    (ok.GRID_TYPE, GRID_TYPE),
    (ok.CELL_SHAPE, {
        wk.FUNCTION: get_shape_list,
        wk.VAL: sh.RECTANGLE,
        wk.WIDGET: ComboBox
    }),
    (ok.ECS, {
        wk.FUNCTION: get_equilateral_list,
        wk.VAL: sh.SQUARE,
        wk.WIDGET: ComboBox
    }),
    (ok.PIN_CORNER, deepcopy(PIN_CORNER)),
    (ok.ROW_COUNT, deepcopy(GRID_COUNT)),
    (ok.COLUMN_COUNT, deepcopy(GRID_COUNT)),
    (ok.ROW_H, deepcopy(CELL_SIZE)),
    (ok.COLUMN_W, deepcopy(CELL_SIZE)),
    (ok.VERT_COUNT, deepcopy(GRID_COUNT)),
    (ok.HORZ_COUNT, deepcopy(GRID_COUNT)),
    (ok.FCI, deepcopy(FCI)),
    (ok.GRID_SIZE, deepcopy(GRID_SIZE)),
    (ok.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE)),
    (ok.PER_CELL, deepcopy(PER_CELL))
])

TYPE_TABLE[ok.PARALLELOGRAM_SCALE][wk.VAL] = .7
set_issue(TYPE_TABLE, (), vo.MATTER, (ok.PER_CELL,))
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
