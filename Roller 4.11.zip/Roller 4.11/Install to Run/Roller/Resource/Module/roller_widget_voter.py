#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Issue as vo
from roller_constant_key import Widget as wk


def accept_vote(d, key, issue, vote):
    """
    Update a relational vote dict with issue votes. Is
    recursive when the 'issue' value is a tuple of Issue.

    d: dict
        to hold vote; for Plan or Work

    key: string
        Option

    issue: string or tuple
        string: type of change
        tuple: multiple Issue

    vote: bool
        Is True if the Widget has changed value from its View value.
    """
    if issue and issue != vo.NULL:
        if isinstance(issue, tuple):
            for i in issue:
                accept_vote(d, key, i, vote)
        else:
            if issue not in d:
                d[issue] = {}
            d[issue][key] = vote


class Voter:
    """Subscribe to signal. Receive signal. Cast vote."""

    def __init__(self, **d):
        """
        d: dict
            Init.
        """
        self.handle_d = {}
        self.view_value = [None, None]
        self.issue = d[wk.ISSUE] if wk.ISSUE in d else None

        if self.key and self.change_signal:
            if self.issue and wk.CHANGELESS not in d:
                self.relay += [self.on_voter_change]
            elif wk.CHANGELESS not in d:
                # The option does not vote but effects change.
                self.relay += [self.on_simple_change]

    def on_disappear(self, _, arg):
        """
        The AnyGroup is no longer in service, so disconnect its subscription.
        """
        for i, a in self.handle_d.items():
            a.disconnect(i)
        self.handle_d = {}

    def on_simple_change(self, _):
        """
        Flag the option group as changed.

        _: GTK Widget
            the signal sender
            Is responsible for change.
        """
        self.any_group.changed()

    def on_voter_change(self, _):
        """
        Cast change vote.

        _: GTK Widget
            the signal sender
            Is responsible for change.
        """
        if self.any_group:
            a = self.get_a()

            for x in range(2):
                self.any_group.cast_vote(
                    x, self.key, self.issue, a != self.view_value[x]
                )

            if self.row_key:
                self.any_group.set_sub_widget_a(self.key, self.row_key, a)
            else:
                self.any_group.update_option_a(self.key, a)

    def set_view_value(self, x, a):
        self.view_value[x] = deepcopy(a)
