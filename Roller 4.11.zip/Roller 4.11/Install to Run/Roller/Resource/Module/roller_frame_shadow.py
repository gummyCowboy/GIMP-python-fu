#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_maya import NO_VOTE
from roller_frame_build import Build
from roller_maya_shadow import Shadow
import gimpfu as fu

pdb = fu.pdb


class Shadowy(Build):
    """Has three shadows."""
    put = issue_q = ()

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        Build.__init__(self, any_group, super_maya, NO_VOTE)
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (self.cause,), k_path + (ok.SHADOW,)
        )

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_change += self.cause.is_cake

        self.realize(v)
        return self.sub_maya[ok.SHADOW].do(
            v, d[ok.SHADOW], is_change, is_change
        )
