#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy
from roller_constant_key import Option as ok, Node as ny
from roller_maya import Maya, check_cake, check_matter
from roller_maya_blur_behind import BlurBehind
from roller_fu import get_layer_offset
from roller_view_real import make_group
import gimpfu as fu

PLAN_COLOR_D = {
    ny.CELL: fy.CELL_STRIPE_COLOR,
    ny.CANVAS: fy.CANVAS_STRIPE_COLOR,
    ny.FACE: fy.FACE_STRIPE_COLOR
}
pdb = fu.pdb


def check_stripe_matter(v, maya):
    """
    Plan uses this function to change the color
    of the Stripe before drawing the Stripe.

    Return: layer or None
        Has Stripe.
    """
    def _do(_v, _maya):
        _e = maya.value_d
        _color = _e[ok.COLOR_1]

        # Override.
        _e[ok.COLOR_1] = PLAN_COLOR_D[maya.any_group.render_key[-2]]

        _z = _do_matter(v, maya)

        _e[ok.COLOR_1] = _color

        if _z:
            _z.opacity = 66.
        return _z

    _do_matter = maya.do_matter
    maya.do_matter = _do
    return check_matter(v, maya)


def make_stripe_group(v, maya):
    """
    Make a group layer for the Stripe layer and its Blur Behind layer.

    v: View
    maya: Maya
    Return: layer group
    """
    if not maya.group:
        parent = maya.super_maya.group
        return make_group(v, "Stripe", parent, offset=len(parent.layers))
    return maya.group


class Stripe(Maya):
    """Manage Stripe layer output."""
    issue_q = 'cake', 'matter'

    def __init__(self, any_group, super_maya, view_x, do_stripe, k_path):
        """
        super_maya: Maya
            from the enclosing Preset

        view_x: int
        do_stripe: function
            Call to make Stripe material.

        k_path: tuple
            (Option key, ...)
            path to the Stripe vote dict in the AnyGroup vote dict
        """
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        q = (make_stripe_group, (check_stripe_matter, check_matter)[view_x],)
        q1 = 'group', 'matter',
        self.do_matter = do_stripe

        if view_x:
            q += (check_cake,)
            q1 += (None,)

        Maya.__init__(self, any_group, view_x, zip(q, q1), k_path=k_path)

        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(any_group, self, k_path)
        self.set_issue()

    def do(self, v, d):
        """
        Manage layer output during a View run.

        v: View
        d: dict
            Is the Caption Preset which has the Stripe option.
            {Option key: value}
        """
        d = self.value_d = d[ok.MSS][ok.STRIPE]
        self.go = d[ok.SWITCH]
        is_back = v.is_back

        if self.go:
            self.is_matter |= self.super_maya.is_matter
            z = self.super_maya.matter
            if self.group and z:
                pdb.gimp_image_reorder_item(
                    v.j,
                    self.group,
                    self.super_maya.group,
                    get_layer_offset(z) + 1
                )

        self.realize(v)

        if self.go:
            self.sub_maya[ok.BLUR_BEHIND].do(v, d, is_back, self.is_matter)
        self.reset_issue()
