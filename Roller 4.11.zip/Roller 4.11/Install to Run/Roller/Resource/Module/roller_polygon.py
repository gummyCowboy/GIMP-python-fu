#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh, Triangle as ft
from math import asin, sqrt, tan


RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP


def arrange_hexagon(q, x, y, w, h):
    """
    Calculate a hexagon polygon's x, y series.

    q: tuple
        of offsets

    x, y: numeric
        topleft point

    w, h: numeric
        rectangle

    Return: tuple
        of x, y vertex pairs
        for the select polygon function
    """
    w1, h1, _, h2 = q
    x1 = x + w1
    x2 = x + w
    y1 = y + h1
    y2 = y + h2

    # The first point is the topleft. The
    # vertices connect in a clockwise rotation.
    return (
        x, y1,
        x1, y,
        x2, y1,
        x2, y2,
        x1, y + h,
        x, y2
    )


def arrange_hexagon_truncated(q, x, y, w, h):
    """
    Calculate the polygon vertices of a truncated hexagon.

    w, h: numeric
        rectangle

    Return: tuple
        of x, y vertex pairs
        for the select polygon function
    """
    # 'w2' is not used.
    w1, w2, w3, h1 = q
    x1 = x + w1
    x2 = x + w3
    y1 = y + h1
    y2 = y + h

    # The first point is the topleft.
    # The vertices connect clockwise.
    return (
        x, y1,
        x1, y,
        x2, y,
        x + w, y1,
        x2, y2,
        x1, y2,
    )


def arrange_octagon(q, x, y, w, h):
    """
    Calculate the polygon vertices of an octagon with offsets.

    q: tuple
        of offsets for the vertices

    x, y, w, h: float
        the bounds rectangle of the octagon

    Return: tuple
        of x, y vertex pairs
        for select polygon function
    """
    w1, w2, w3, h1, h2, h3 = q
    x0 = x + w1
    x1 = x + w2
    x3 = x + w3
    y1 = y + h1
    y2 = y + h2
    y3 = y + h3

    # The first point is top-center.
    # The direction is clockwise.
    return (
        x1, y,
        x3, y1,
        x + w, y2,
        x3, y3,
        x1, y + h,
        x0, y3,
        x, y2,
        x0, y1
    )


def arrange_octagon_side_to_side(q, x, y, w, h):
    """
    Calculate the polygon vertices of a side-to-side octagon using a ratio.

    x, y, w, h: float
        the bounds rectangle of the octagon

    q: tuple
        Are offsets for the vertices.

    Return: tuple
        of x, y vertex pairs
        for select polygon function
    """
    w1, w2, h1, h2 = q
    x1 = x + w1
    x2 = x + w2
    x3 = x + w
    y1 = y + h1
    y2 = y + h2
    y3 = y + h

    # The first point is topleft.
    # The vertices connect clockwise.
    return (
        x1, y,
        x2, y,
        x3, y1,
        x3, y2,
        x2, y3,
        x1, y3,
        x, y2,
        x, y1
    )


def arrange_rectangle(rect):
    """
    Translate a rectangle into a tuple of x, y
    coordinates for drawing a Rectangle polygon.

    rect: Rect
        the bounds rectangle for the Rectangle

    Return: tuple
        of x, y vertex pairs
        for drawing a Rectangle
    """
    x, y = rect.position
    w, h = rect.size
    x1, y1 = x + w, y + h
    return x, y, x1, y, x1, y1, x, y1


def calc_circle(rect):
    """
    Calculate a bounds rectangle for drawing a circle.

    rect: Rect
        the bounds rectangle of a cell-like rectangle

    Return: tuple
        (x, y, w, h)
        Define the rectangle bounds of the circle.
    """
    x, y = rect.position
    w, h = rect.size
    center_x, center_y = x + w / 2., y + h / 2.
    w = min(w, h)
    x1 = center_x - w / 2.
    y1 = center_y - w / 2.
    return x1, y1, w, w


def calc_circumradius(w, h):
    """
    Calculate the half-diagonal of a rectangle.

    Return: float
        half the length of the rectangle's diagonal
    """
    return sqrt(w**2 + h**2) / 2.


def calc_hexagon(rect):
    """
    Calculate six vertices of a Hexagon.
    Maintain the Hexagon shape proportions.

    rect: Rect
        Is the bounds rectangle for the hexagon.

    Return: tuple
        x, y pairs
        for drawing a hexagon
    """
    x, y = rect.position
    w, h = rect.size

    # There are two possible solutions.
    # solution one
    w1, h1 = h * RATIO, h

    if w1 > w:
        # Solution one doesn't fit the rectangle, so it's solution two.
        w1, h1 = w, w * UP_RATIO

    return arrange_hexagon(
        calc_hexagon_offset(w1, h1),
        x + (w - w1) / 2.,
        y + (h - h1) / 2.,
        w1, h1
    )


def calc_hexagon_offset(w, h):
    """
    Calculate hexagon offsets.

    w, h: numeric
        rectangle

    Return: tuple
        offsets
    """
    return w / 2., h / 4., h / 2., h * .75


def calc_hexagon_shear(rect):
    """
    Get the six vertices of a Sheared Hexagon.

    rect: Rect
        the bounds rectangle for the Sheared Hexagon

    Return: tuple
        x, y pairs
        for drawing a Sheared Hexagon
    """
    return arrange_hexagon(calc_hexagon_offset(*rect.size), *rect.rect)


def calc_hexagon_truncated(rect):
    """
    Get the vertices of a Truncated Hexagon.
    Maintain the hexagon shape proportions.

    rect: Rect
        the bounds rectangle for the Truncated Hexagon

    Return: tuple
        x, y pairs
        for drawing a Truncated Hexagon
        a tuple of six coordinates of the hexagon connected clockwise
        The first point is the topleft point.
    """
    x, y = rect.position
    w, h = rect.size

    # There are two possible solutions.
    # solution one
    w1, h1 = float(w), w * RATIO

    if h1 > h:
        # Solution one doesn't fit the rectangle, so it's solution two.
        w1, h1 = h * UP_RATIO, float(h)

    center_x, center_y = (w - w1) / 2., (h - h1) / 2.
    x += center_x
    y += center_y
    return arrange_hexagon_truncated(
        calc_hexagon_truncated_offset(w1, h1), x, y, w1, h1
    )


def calc_hexagon_truncated_offset(w, h):
    """
    Calculate offsets of a Truncated Hexagon.

    w, h: numeric
        rectangle

    Return: tuple
        offsets
    """
    return w / 4., w / 2., w * .75, h / 2.


def calc_hexagon_truncated_shear(rect):
    """
    Get the six vertices of a Sheared Truncated Hexagon.

    rect: Rect
        the bounds rectangle for the Sheared Truncated Hexagon

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    w, h = rect.size
    return arrange_hexagon_truncated(
        calc_hexagon_truncated_offset(w, h), rect.x, rect.y, w, h
    )


def calc_length(x, y, x1, y1):
    """
    Calculate the distance between two points.

    x, y, x1, y1: numeric
        end points of a line (x, y), (x1, y1)

    Return: float
        the distance between the points
    """
    return sqrt((x - x1)**2 + (y - y1)**2)


def calc_octagon(rect):
    """
    Get the eight vertices of a octagon.
    Maintain the octagon proportions.

    rect: Rect
        the bounds rectangle for the octagon

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y = rect.position
    w, h = rect.size
    w1 = min(w, h)
    offset_x, offset_y = (w - w1) / 2., (h - w1) / 2.
    x += offset_x
    y += offset_y
    return arrange_octagon(calc_octagon_offset(w1, w1), x, y, w1, w1)


def calc_octagon_offset(w, h):
    """
    Calculate the offsets of an octagon.

    w, h: numeric
        the bounds of the octagon

    Return: tuple
        of offsets
    """
    # of cell rectangle
    radius = calc_circumradius(w, h)

    w1 = w / 2.
    h1 = h / 2.
    angle = asin(h1 / radius)

    # The process for 'w2' is deliberately
    # not factored as this is a complex formula.
    area = w1 * h1
    w2 = tan(angle)**2
    w2 = w2 * w1**2
    w2 = h1**2 + w2
    w2 = sqrt(w2)
    w2 = area / w2
    h2 = w2 * tan(angle)
    w3 = w1 + w2
    w4 = w1 - w2
    h3 = h1 + h2
    h4 = h1 - h2
    return w4, w1, w3, h4, h1, h3


def calc_octagon_shear(rect):
    """
    Get the eight vertices of a Sheared Octagon.

    rect: Rect
        the bounds rectangle for the Sheared Octagon

    Return: tuple
        x, y pairs
        for drawing an octagon
    """
    x, y = rect.position
    w, h = rect.size
    return arrange_octagon(calc_octagon_offset(w, h), x, y, w, h)


def calc_octagon_side_to_side(rect):
    """
    Get the eight vertices of a Side-to-Side Octagon.
    Maintain the Octagon shape proportions.

    rect: Rect
        the bounds rectangle for the Side-to-Side Octagon

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y = rect.position
    w, h = rect.size
    w1 = min(w, h)

    # Center the polygon in the rectangle.
    offset_x, offset_y = (w - w1) / 2., (h - w1) / 2.
    x += offset_x
    y += offset_y
    return arrange_octagon_side_to_side(
        calc_octagon_side_to_side_offset(w1, w1), x, y, w1, w1
    )


def calc_octagon_side_to_side_offset(w, h):
    """
    Calculate the offsets of a side-to-side octagon using a ratio.

    w, h: numeric
        limiting size

    Return: tuple
        of offsets
    """
    # Use ratio.
    w1 = w * sh.OCTAGON_RATIO
    w2 = w - w1
    h1 = h * sh.OCTAGON_RATIO
    h2 = h - h1
    return w1, w2, h1, h2


def calc_octagon_side_to_side_shear(rect):
    """
    Get the eight vertices of a Sheared Side-to-Side Octagon.

    rect: Rect
        the bounds rectangle for the Sheared Side-to-Side Octagon

    Return: tuple
        x, y pairs
        for drawing an Octagon
    """
    w, h = rect.size
    return arrange_octagon_side_to_side(
        calc_octagon_side_to_side_offset(w, h), rect.x, rect.y, w, h
    )


def calc_parallelogram_left(rect, scale):
    """
    Calculate a left parallelogram.

    rect: Rect
        the parallelogram's rectangular container

    scale: float
        .001 to 1.
        the scale of the parallelogram top and bottom side
        Is multiplied by the parallelogram's container width.

    Return: tuple
        the parallelogram's polygon
    """
    w, h = rect.size
    center_x, center_y = rect.center()
    x = center_x - w / 2.
    y = center_y - h / 2.
    y1 = y + h
    w1 = w * scale
    x1 = x + w1
    x2 = x + w
    x3 = x2 - w1
    return x, y, x1, y, x2, y1, x3, y1


def calc_parallelogram_right(rect, scale):
    """
    Calculate a right parallelogram.

    rect: Rect
        the parallelogram's rectangular container

    scale: float
        .001 to 1.
        the scale of the parallelogram top and bottom side
        Is multiplied by the parallelogram's container width.

    Return: tuple
        the parallelogram's polygon
    """
    w, h = rect.size
    center_x, center_y = rect.center()
    x = center_x - w / 2.
    y = center_y - h / 2.
    y1 = y + h
    w1 = w * scale
    x1 = x + w - w1
    x2 = x + w
    x3 = x + w1
    return x1, y, x2, y, x3, y1, x, y1


def calc_pin_xy(pin, x, y, w, h, w1, h1):
    """
    Calculate a pin offset given the canvas space and cell
    grid size. Fixed-sized cells have a pin corner. Their
    cell grid is justified to its pin corner.

    pin: string
        pin type

    x, y: int
        topleft point of the canvas

    w, h: int
        canvas size

    w1, h1: numeric
        cell grid size

    Return: tuple
        the topleft point for the grid
    """
    if pin in gr.PINS_WITH_X_OFFSET:
        x1 = w - w1

        if pin == gr.CENTER:
            x1 /= 2.
        x += x1

    if pin in gr.PINS_WITH_Y_OFFSET:
        y1 = h - h1

        if pin == gr.CENTER:
            y1 /= 2.
        y += y1
    return x, y


def calc_rhombus(rect):
    """
    Get the four vertices of a Rhombus.
    Maintain the Rhombus shape proportions.

    rect: Rect
        the bounds rectangle for a rhombus

    Return: tuple
        x, y pairs
        for drawing a rhombus
    """
    x, y = rect.position
    w, h = rect.size
    w2 = min(w, h) / 2.
    center_x, center_y = x + w / 2., y + h / 2.
    return (
        center_x - w2, center_y,
        center_x, center_y - w2,
        center_x + w2, center_y,
        center_x, center_y + w2
    )


def calc_rhombus_shear(rect):
    """
    Get the four vertices of a Sheared Rhombus.

    rect: Rect
        the bounds rectangle for the Sheared Rhombus

    Return: tuple
        x, y pairs
        for drawing a Sheared Rhombus
    """
    x, y = rect.position
    w, h = rect.size
    x1, y1 = x + w, y + h
    y2 = (y + y1) / 2.
    x2 = (x + x1) / 2.
    return x, y2, x2, y, x1, y2, x2, y1


def calc_square(rect):
    """
    Get the four vertices of a Square.

    rect: Rect
        the bounds rectangle for the Square

    Return: tuple
        x, y pairs
        for drawing a Square
    """
    x, y = rect.position
    w, h = rect.size
    center_x, center_y = x + w / 2., y + h / 2.
    w = min(w, h)
    x1 = center_x - w / 2.
    y1 = center_y - w / 2.
    x2, y2 = x1 + w, y1 + w
    return x1, y1, x2, y1, x2, y2, x1, y2


def calc_triangle_down_isosceles(rect):
    """
    Get the three vertices of a Down Triangle.
    Maintain an isosceles triangle shape.

    rect: Rect
        the bounds rectangle for the polygon

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y = rect.position
    w, h = rect.size

    # There are two possible solutions.
    # solution one
    w1, h1 = h * UP_RATIO, h

    if w1 > w:
        # Solution one would overflow the bounds rectangle.
        w1, h1 = w, w * RATIO

    x1, y1 = x + w1, y + h1
    x2 = (x + x1) / 2.

    # Center the triangle.
    offset_x = (w - w1) / 2.
    offset_y = (h - h1) / 2.
    x += offset_x
    x1 += offset_x
    x2 += offset_x
    y += offset_y
    y1 += offset_y
    return x, y, x2, y1, x1, y


def calc_triangle_down_shear(rect):
    """
    Get the three vertices of a Sheared Down Triangle.

    rect: Rect
        the bounds rectangle for the polygon

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y = rect.position
    w, h = rect.size
    x1, y1 = x + w, y + h
    x2 = (x + x1) / 2.
    return x, y, x2, y1, x1, y


def calc_triangle_left_isosceles(rect):
    """
    Get the three vertices of a Left Isosceles Triangle.

    rect: Rect
        the bounds rectangle for the polygon

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y = rect.position
    w, h = rect.size

    # There are two possible solutions.
    # solution one
    w1, h1 = h * RATIO, h

    if w1 > w:
        # Solution one would overflow the bounds rectangle.
        # solution two
        w1, h1 = w, w * UP_RATIO

    x1, y1 = x + w1, y + h1
    y2 = (y + y1) / 2.

    # Center the triangle.
    offset_x = (w - w1) / 2.
    offset_y = (h - h1) / 2.
    x += offset_x
    x1 += offset_x
    y += offset_y
    y1 += offset_y
    y2 += offset_y
    return x1, y, x1, y1, x, y2


def calc_triangle_left_shear(rect):
    """
    Get the three vertices of a Sheared Left Triangle.

    rect: Rect
        the bounds rectangle for the polygon

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y = rect.position
    w, h = rect.size
    x1, y1 = x + w, y + h
    y2 = (y + y1) / 2.
    return x1, y, x1, y1, x, y2


def calc_triangle_right_isosceles(rect):
    """
    Get the three vertices of a Right Isosceles Triangle.

    rect: Rect
        the bounds rectangle for the polygon

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y = rect.position
    w, h = rect.size

    # There are two possible solutions.
    # solution one
    w1, h1 = h * RATIO, h

    if w1 > w:
        # Solution one would overflow the bounds rectangle.
        # solution two
        w1, h1 = w, w * UP_RATIO

    x1, y1 = x + w1, y + h1
    y2 = (y + y1) / 2.

    # Center the triangle.
    offset_x = (w - w1) / 2.
    offset_y = (h - h1) / 2.
    x += offset_x
    x1 += offset_x
    y += offset_y
    y1 += offset_y
    y2 += offset_y
    return x, y, x, y1, x1, y2


def calc_triangle_right_shear(rect):
    """
    Get the three vertices of a Right Sheared Triangle.

    rect: Rect
        the bounds rectangle for the polygon

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y = rect.position
    w, h = rect.size
    x1, y1 = x + w, y + h
    y2 = (y + y1) / 2.
    return x, y, x, y1, x1, y2


def calc_triangle_up_isosceles(rect):
    """
    Get the three vertices of a Down Isosceles Triangle.

    rect: Rect
        the bounds rectangle for the polygon

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y = rect.position
    w, h = rect.size

    # There are two possible solutions.
    # solution one
    w1, h1 = h * UP_RATIO, h

    if w1 > w:
        # Solution one would overflow the bounds rectangle.
        w1, h1 = w, w * RATIO

    x1, y1 = x + w1, y + h1
    x2 = (x + x1) / 2.

    # Center the triangle.
    offset_x = (w - w1) / 2.
    offset_y = (h - h1) / 2.
    x += offset_x
    x1 += offset_x
    x2 += offset_x
    y += offset_y
    y1 += offset_y
    return x, y1, x2, y, x1, y1


def calc_triangle_up_shear(rect):
    """
    Get the three vertices of a Sheared Up Triangle.

    rect: Rect
        the bounds rectangle for the polygon

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y = rect.position
    w, h = rect.size
    x1, y1 = x + w, y + h
    x2 = (x + x1) / 2.
    return x, y1, x2, y, x1, y1


def get_bounds(a):
    """
    Return the bounds of a shape.

    a: iterable or dict
        The iterable has x, y numeric pairs.
        The dict of an ellipse has x, y, w, h.

    Return: tuple
        x, y, w, h
        the bounds of the shape
    """
    def _extent(_a):
        return min(_a), max(_a)

    if len(a) == 4:
        return a
    else:
        b = len(a)
        min_x, max_x = _extent([a[i] for i in range(0, b, 2)])
        min_y, max_y = _extent([a[i] for i in range(1, b, 2)])
        return min_x, min_y, max_x - min_x, max_y - min_y


def get_ellipse(rect):
    """
    Translate a rectangle into a dictionary for an ellipse.

    rect: Rect
        the bounds rectangle for the ellipse

    Return: tuple
        (x, y, w, h)
        Define the rectangle bounds of the ellipse.
    """
    return rect.rect


def get_extreme(a):
    """
    Return the extreme x and y coordinates of a shape.

    a: iterable
        The iterable has x, y numeric pairs.

    Return: tuple
        x, y, x1, y1
        left, top, right, bottom
    """
    b = len(a)
    q_x = [a[i] for i in range(0, b, 2)]
    q_y = [a[i] for i in range(1, b, 2)]
    return min(q_x), min(q_y), max(q_x), max(q_y)


def get_intersection(p, p1, p2, p3):
    """
    Given two lines that are known to intersect,
    find their intersecting point.

    Reference
    'stackoverflow.com/questions/563198/how-do-you
    -detect-where-two-line-segments-intersect'

    p, p1: tuple
        (x, y) of float
        line

    p2, p3: tuple
        (x, y) of float
        line

    Return: list
        [float x, float y]
        intersect point
    """
    s_x = p1[0] - p[0]
    s_y = p1[1] - p[1]
    s1_x = p3[0] - p2[0]
    s1_y = p3[1] - p2[1]
    s2_x = p[0] - p2[0]
    s2_y = p[1] - p2[1]

    # scalar, 't'
    t = (s1_x * s2_y - s1_y * s2_x) / (s_x * s1_y - s1_x * s_y)
    return [p[0] + (t * s_x), p[1] + (t * s_y)]


def get_h_ellipse_rect(rect):
    """
    Calculate the rectangle bounds of a horizontal ellipse.

    rect: Rect
        bounding rectangle for an ellipse

    Return: tuple
        (x, y, w, h)
    """
    return rect.x, rect.y, rect.w, rect.h - rect.h * sh.ELLIPSE_RATIO


def get_v_ellipse_rect(rect):
    """
    Calculate the rectangle bounds of a vertical ellipse.

    rect: Rect
        the bounds rectangle of the ellipse

    Return: tuple
        (x, y, w, h)
    """
    return rect.x, rect.y, rect.w - rect.w * sh.ELLIPSE_RATIO, rect.h


def what_is_inverse_triangle(r, c):
    """
    Determine if a vertical or horizontal triangle is inverted.

    r, c: int
        row, column
        cell index; Goo key

    Return: bool
        Is true when the triangle is inverted.
    """
    return (not r % 2 and c % 2) or (r % 2 and not c % 2)


CELL_SHAPE_D = {
    ft.TRIANGLE_DOWN_SHEAR: calc_triangle_down_shear,
    ft.TRIANGLE_DOWN_ISOSCELES: calc_triangle_down_isosceles,
    ft.TRIANGLE_LEFT_SHEAR: calc_triangle_left_shear,
    ft.TRIANGLE_LEFT_ISOSCELES: calc_triangle_left_isosceles,
    ft.TRIANGLE_RIGHT_SHEAR: calc_triangle_right_shear,
    ft.TRIANGLE_RIGHT_ISOSCELES: calc_triangle_right_isosceles,
    ft.TRIANGLE_UP_SHEAR: calc_triangle_up_shear,
    ft.TRIANGLE_UP_ISOSCELES: calc_triangle_up_isosceles,
    sh.BOX_HORZ_SHEAR: calc_hexagon_truncated_shear,
    sh.BOX_HORZ: calc_hexagon_truncated,
    sh.BOX_VERT_SHEAR: calc_hexagon_shear,
    sh.BOX_VERT: calc_hexagon,
    sh.CIRCLE: calc_circle,
    sh.CIRCLE_HORIZONTAL: calc_circle,
    sh.CIRCLE_VERTICAL: calc_circle,
    sh.ELLIPSE: get_ellipse,
    sh.ELLIPSE_HORIZONTAL: get_ellipse,
    sh.ELLIPSE_VERTICAL: get_ellipse,
    sh.HEXAGON: calc_hexagon,
    sh.HEXAGON_SHEAR: calc_hexagon_shear,
    sh.HEXAGON_TRUNCATED: calc_hexagon_truncated,
    sh.HEXAGON_TRUNCATED_SHEAR: calc_hexagon_truncated_shear,
    sh.OCTAGON_DOUBLE: calc_octagon_side_to_side,
    sh.OCTAGON_DOUBLE_SHEAR: calc_octagon_side_to_side_shear,
    sh.OCTAGON: calc_octagon,
    sh.OCTAGON_SHEAR: calc_octagon_shear,
    sh.OCTAGON_SIDE_TO_SIDE_SHEAR: calc_octagon_side_to_side_shear,
    sh.OCTAGON_SIDE_TO_SIDE: calc_octagon_side_to_side,
    sh.RECTANGLE: arrange_rectangle,
    sh.RHOMBUS: calc_rhombus,
    sh.RHOMBUS_SHEAR: calc_rhombus_shear,
    sh.SQUARE: calc_square
}
SHEAR_D = {
    sh.PARALLELOGRAM_ALT_LEFT: calc_parallelogram_left,
    sh.PARALLELOGRAM_ALT_RIGHT: calc_parallelogram_right,
    sh.PARALLELOGRAM_LEFT: calc_parallelogram_left,
    sh.PARALLELOGRAM_RIGHT: calc_parallelogram_right,
}
