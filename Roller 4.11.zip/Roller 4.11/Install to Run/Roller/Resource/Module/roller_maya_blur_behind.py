#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Issue as vo, Signal as si
from roller_constant_key import Option as ok
from roller_frame_build import SubBuild
from roller_maya import check_layer, on_global
from roller_fu import blur_selection, select_rect
from roller_view_real import clone_background, mask_sub_maya
import gimpfu as fu

pdb = fu.pdb


def blur_behind_matter(v, maya):
    """
    Blur Behind the super's matter layer.

    v: View
    maya: BlurBehind
    Return: layer or None
        with Blur Behind Material
    """
    z = maya.super_maya.matter
    blur = maya.value_d[ok.BLUR_BEHIND]

    # no Blur Behind layer, 'z1'
    z1 = None

    if z and blur:
        # Blur Behind layer, 'z1'
        z1 = clone_background(v, z)
        z1.name = z1.parent.name + " Blur Behind"

        select_rect(v.j, *v.wip.rect)
        blur_selection(z1, blur)
        pdb.gimp_drawable_curves_spline(
            z1,
            fu.HISTOGRAM_VALUE,
            4,                              # four coordinate
            (.0, .0, 1., .93)
        )
    return z1


def check_blur_behind(v, maya):
    """
    Determine if the blur behind has changed. Make material if so.

    v: View
    maya: BlurBehind
    Return: layer or None
        with material
    """
    if maya.is_blur_behind:
        return check_layer(v, maya, 'blur_behind', blur_behind_matter)
    return maya.blur_behind


class BlurBehind(SubBuild):
    """
    Manage Blur Behind option's layer output. Blur Behind
    is done after Frame and Shadow Maya in a View run.
    """
    issue_q = 'blur_behind',
    put = (check_blur_behind, 'blur_behind'),

    def __init__(self, any_group, super_maya, k_path):
        """
        super_maya: Maya
            Is the enclosing Preset's Maya.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path)
        self.handle_d[
            self.any_group.connect(si.BACK_CHANGE, self.on_back_change)
        ] = self.any_group

    def do(self, v, d, is_back, is_mask):
        """
        Manage layer output during a View run.

        v: View
        d: dict or None
            Blur Behind's enclosing Preset value

        is_back: bool or None
            Is True when the background has change.

        is_mask: bool
            If True, then the Blur Behind is masked from its over-layer.
        """
        self.value_d = d
        self.go = bool(self.super_maya.matter)

        if self.go:
            self.is_blur_behind |= is_back
            if self.blur_behind and not self.is_blur_behind:
                pdb.gimp_image_reorder_item(
                    v.j,
                    self.blur_behind,
                    self.blur_behind.parent,
                    len(self.blur_behind.parent.layers)
                )

        self.realize(v)

        if self.go and (self.is_blur_behind or is_mask):
            mask_sub_maya(self.super_maya.matter, self.blur_behind)
        self.reset_issue()

    def on_back_change(self, _, x):
        """
        The background changed for the group.

        _: AnyGroup
            Sent the Signal.

        x: int
            Plan or Work index
        """
        if x == self.view_x:
            arg = [None, None]
            arg[x] = True
            on_global(self, arg, ok.IS_BACK, issue=vo.BLUR_BEHIND)
