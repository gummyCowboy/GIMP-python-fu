#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Group as gk, Option as ok
from roller_def import get_default_value
from roller_frame import Shadow1
from roller_frame_build import Build
from roller_fu import (
    clear_inverse_selection,
    clone_layer,
    clone_opaque_layer,
    dilate,
    load_selection,
    merge_layer,
    remove_z,
    select_opaque
)
from roller_maya import check_frame_cake, check_matter, make_frame_group
from roller_maya_light import Light
from roller_one_gegl import noise_rgb, saturation
from roller_view_real import LIGHT, SHADOW, add_top_layer
from roller_view_shadow import make_shadow
import gimpfu as fu

SAWTOOTH = (
    .0, .0,
    .166, .166,
    .167, .1,
    .333, .333,
    .334, .166,
    .5, .5,
    .501, .25,
    .666, .666,
    .667, .444,
    1., 1.
)
pdb = fu.pdb


def do_matter(v, maya):
    """
    Make a Crumble Shell frame.

    v: View
    maya: Crumble Shell Maya
    Return: layer or None
        with the frame
    """
    j = v.j
    d = maya.value_d
    group = maya.group
    go = False

    # failed frame layer, 'z'
    z = wip_z = None

    select_opaque(maya.cause.matter)

    if not pdb.gimp_selection_is_empty(j):
        z = wip_z = add_top_layer(v, maya, "WIP")

        # Make a border overlapping the matter.
        pdb.gimp_selection_border(j, d[ok.FRAME_W])

        # Create crumble selection from the frame selection.
        pdb.script_fu_distress_selection(
            j, z,
            d[ok.DISTRESS_THRESHOLD],
            d[ok.SPREAD_DISTRESS],
            4., 2.,
            1, 1                            # smooth horizontal and vertical
        )

    if not pdb.gimp_selection_is_empty(j):
        a = pdb.gimp_selection_save(j)

        # Add noise to the selection.
        # GEGL's Simplex-Noise failed me, so I use this.
        for i in range(12):
            noise_rgb(
                z,
                1., 1., 1., 1.,
                d[ok.SEED] + v.glow_ball.seed + i
            )

            if i % 2:
                pdb.plug_in_erode(
                    j, z,
                    1,                      # propagate black
                    7,                      # RGB channels
                    1.,                     # full rate
                    7,                      # direction mask
                    0,                      # lower limit
                    255                     # upper limit
                )
            else:
                dilate(z)

        pdb.plug_in_despeckle(
            j, z,
            3,                  # radius
            3,                  # recursive adaptive
            0,                  # black start point
            255                 # white end point
        )

        z = clone_layer(z, n="Difference")
        z.mode = fu.LAYER_MODE_DIFFERENCE
        go = True

        load_selection(j, a)
        clear_inverse_selection(z)
        pdb.gimp_image_remove_channel(j, a)

    if go:
        pdb.plug_in_colortoalpha(j, z, (1., 1., 1.))
        saturation(z, .1)

        z = clone_layer(z, n="Burn")

        dilate(z)

        z.mode = fu.LAYER_MODE_OVERLAY
        z = merge_layer(z)
        z = clone_opaque_layer(z, n="Burn")
        z = merge_layer(z)
        z.name = group.name + " Crumble Shell"

        # coordinate count, '20'
        pdb.gimp_drawable_curves_spline(
            z, fu.HISTOGRAM_VALUE, 20, SAWTOOTH
        )

        # Cast shadow around grain.
        e = get_default_value(gk.SHADOW_1)
        e[ok.SHADOW_BLUR] = 2.
        e[ok.INTENSITY] = 100.

        make_shadow(v.j, e, maya.group, (z,), None, name="Shadow")

        z = merge_layer(z)
        remove_z(wip_z)
    return z


class CrumbleShell(Build):
    """Is a sprinkle of noise around the bounds of the cause material."""
    is_seeded = True
    issue_q = 'cake', 'matter'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        self.do_matter = do_matter

        Build.__init__(self, any_group, super_maya, k_path)

        self.sub_maya[SHADOW] = Shadow1(any_group, self, k_path)
        self.sub_maya[LIGHT] = Light(any_group, self, ok.OTHER)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Crumble Shell Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: False
            Shadow did not change the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[SHADOW].do(v, d, self.is_matter + self.is_cake)
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return False
