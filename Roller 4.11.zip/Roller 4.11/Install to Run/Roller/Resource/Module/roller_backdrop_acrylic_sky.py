#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection, clone_layer, dilate, make_layer_group, merge_layer_group
)
from roller_maya_style import Style, make_background
from roller_one_gegl import edge, shift, waterpixels
from roller_view_real import add_sub_base_group, finish_style, insert_copy
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a style layer.

    v: View
        Has scope variable.

    maya: Style
    Return: layer or None
        style layer
    """
    def copier(_n):
        """
        Copy the output.

        _n: string
            layer name of copy

        Return: layer
            the copy
        """
        return insert_copy(v, group, parent)

    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya)
    z = make_background(v, maya, d)
    group = make_layer_group(j, "WIP", parent=parent, z=z)
    bg_z = clone_layer(z, n="Exclusion")
    z1 = clone_layer(z, n="Difference")
    z2 = clone_layer(z1, n="Subtract")
    z.mode = z2.mode = fu.LAYER_MODE_SUBTRACT
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    blur_selection(z, 60)
    blur_selection(z1, 30)
    pdb.plug_in_gimpressionist(j, z2, "Furry")

    z = copier("LCH Lightness")
    z.mode = fu.LAYER_MODE_LCH_LIGHTNESS

    waterpixels(z, size=d[ok.SUPERPIXEL_SIZE])

    z = clone_layer(z, n="Edge")

    edge(z)

    z = copier("Waterpixels")

    waterpixels(z)

    z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
    z = copier("Dilate")

    pdb.gimp_drawable_invert(z, 0)
    dilate(z)
    dilate(z)

    bg_z.mode = fu.LAYER_MODE_EXCLUSION

    blur_selection(bg_z, 500)
    pdb.gimp_image_reorder_item(j, bg_z, group, 0)

    z = merge_layer_group(group)

    # Create a paint brush texture.
    shift(
        z,
        bs.SHIFT_DIRECTION[d[ok.SHIFT_DIRECTION]].lower(),
        d[ok.SHIFT_GEGL],
        d[ok.SEED] + v.glow_ball.seed
    )
    blur_selection(z, 1)
    return finish_style(merge_layer_group(parent), "Acrylic Style")


class AcrylicSky(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BBR

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        self.init_background(make_style, *q, **d)

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BBR][ok.BACKGROUND][ok.BACKDROP_TYPE] == bs.BACKDROP_IMAGE
        super(AcrylicSky, self).do(v, d, is_change)
