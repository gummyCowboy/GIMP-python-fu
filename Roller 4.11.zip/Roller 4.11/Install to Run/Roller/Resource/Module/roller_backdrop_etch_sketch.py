#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clear_selection,
    clone_layer,
    make_layer_group,
    merge_layer_group
)
from roller_maya_style import Style, make_background
from roller_view_real import add_sub_base_group, clone_background, finish_style
import gimpfu as fu

ETCH_WIP = "Etch Sketch WIP"
pdb = fu.pdb


def make_style(v, maya):
    """
    Create a Etch Sketch Backdrop Style layer.

    v: View
    maya: Style
    Return: layer or None
        with Etch Sketch
    """
    def _do_step_1():
        """
        Increase the strength of the line.

        Return: layer
            with modification
        """
        _group = make_layer_group(j, ETCH_WIP, parent=parent, z=z)
        _z1 = clone_layer(z, n="Overlay")
        _z1.mode = fu.LAYER_MODE_OVERLAY

        pdb.gimp_drawable_invert(z, 0)
        return merge_layer_group(_group, n="Step 1")

    def _do_step_2():
        """
        Apply newsprint to lines.

        Return: layer
            with modification
        """
        _z = clone_background(v, z)
        _f = v.glow_ball.azimuth

        while _f < 0:
            _f += 360

        _group = make_layer_group(j, ETCH_WIP, parent=parent, z=_z)

        pdb.gimp_image_reorder_item(j, z, _group, 0)

        z.mode = fu.LAYER_MODE_DARKEN_ONLY
        _type = bs.NEWS_TYPE.index(d[ok.SKETCH_TEXTURE])

        pdb.plug_in_newsprint(
            j, z,
            d[ok.CELL_SIZE],
            1,                  # RGB
            100,                # black
            _f,
            _type,
            _f,
            _type,
            _f,
            _type,
            _f,
            _type,
            2                   # sample
        )

        _q = 0, 0, 0

        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_sample_merged(0)
        pdb.gimp_context_set_sample_criterion(0)
        pdb.gimp_context_set_sample_threshold(.25)
        pdb.gimp_context_set_sample_transparent(1)
        pdb.gimp_image_select_color(j, fu.CHANNEL_OP_REPLACE, _z, _q)
        clear_selection(z)
        blur_selection(_z, 500)

        # four coordinates, '4'
        pdb.gimp_drawable_curves_spline(
            _z,
            fu.HISTOGRAM_VALUE,
            4,
            (.0, .3921, 1., .6078)
        )
        return merge_layer_group(_group, n="Step 2")

    def _do_step_3():
        """Do invert."""
        if d[ok.INVERT]:
            pdb.gimp_drawable_invert(z, 0)

    j = v.j
    d = maya.value_d
    z = make_background(v, maya, d)
    parent = add_sub_base_group(v, maya, z=z)

    pdb.plug_in_edge(
        z.image, z,
        1.,             # edge amount
        0,              # no wrap
        0               # Sobel
    )

    z = _do_step_1()
    z = _do_step_2()

    _do_step_3()
    return finish_style(merge_layer_group(parent), "Etch Sketch")


class EtchSketch(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BBR

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        self.init_background(make_style, *q, **d)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BBR][ok.BACKGROUND][ok.BACKDROP_TYPE] == bs.BACKDROP_IMAGE
        super(EtchSketch, self).do(v, d, is_change)
