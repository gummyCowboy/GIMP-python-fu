#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy, Signal as si
from roller_constant_key import Node as ny, Option as ok, Plan as ak
from roller_deco import make_deco_mask
from roller_deco_plaque import (
    do_canvas,
    do_main_cell,
    do_main_face,
    do_cell,
    do_face,
    i_make_main_face_mask,
    i_make_cell_face_mask,
    mask_main_cell
)
from roller_maya import (
    MAIN,
    PER,
    CanvasRoute,
    CellRoute,
    Plasma,
    assign_deco_image,
    assign_mask_image,
    check_cake,
    check_matter,
    take_type_vote
)
from roller_maya_blur_behind import BlurBehind
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_maya_mask import Mask
from roller_option_group import DecoGroup
from roller_view_option_list import Frame
from roller_view_real import LIGHT, make_canvas_group, make_cast_group
from roller_view_step import get_planner


def assign_canvas_image(v, maya):
    """
    Assign image and mask image for the Canvas-branch.

    v: View
    d: dict
        Plaque Preset
        {Option key: value}
    """
    d = maya.value_d
    image = assign_deco_image(v, d)
    mask = assign_mask_image(v, d[ok.MBF][ok.MASK])

    if mask != maya.get_mask_image(None) or image != maya.get_image(None):
        maya.is_matter = True

    maya.set_image(None, image)
    maya.set_mask_image(None, mask)


def assign_image(v, maya, p):
    """
    Assign image and mask image for Cell-branch Maya.

    v: View
    maya: Maya
    p: function
        Call to assign image.
    """
    d = maya.value_d
    d_q = d, d[ok.MBF][ok.MASK]
    per_cell = d[ok.PER_CELL]
    cell_d = maya.cell_d
    for r_c in maya.model.cell_q:
        if r_c in per_cell:
            e = per_cell[r_c]
            e1 = e[ok.MBF][ok.MASK]
            cell_maya = cell_d[r_c]

        else:
            e, e1 = d_q
            cell_maya = maya

        image, mask = p(v, e, e1)

        # Determine if an image reference changed.
        if image != cell_maya.get_image(r_c):
            cell_maya.is_matter = True

        if mask != cell_maya.get_mask_image(r_c):
            cell_maya.sub_maya[ok.MASK].is_matter = True

        # Store image reference.
        cell_maya.set_image(r_c, image)
        cell_maya.set_mask_image(r_c, mask)


def assign_cell_image(v, maya):
    """
    Assign image for a Cell-branch.

    v: View
    maya: Maya
    """
    def _assign(_v, _d, _e):
        """
        _v: View
        _d: dict
            Plaque Preset
            {Option key: value}

        _e: dict
            Mask Preset
            {Option key: value}

        Return: tuple
            (Image, Mask Image)
            either could be None
        """
        return (
            assign_deco_image(_v, _d),
            assign_mask_image(_v, _e) if _d[ok.SWITCH] else None
        )
    assign_image(v, maya, _assign)


def assign_face_image(v, maya):
    """
    Assign image for Face Maya. Has three images per cell.

    v: View
    maya: Maya
    """
    def _assign(_v, _d, _e):
        """
        _v: View
        _d: dict
            Plaque Preset
            {Option key: value}

        _e: dict
            Mask Preset
            {Option key: value}

        Return: tuple
            (Image, Mask Image)
            either could be None
        """
        return (
            [assign_deco_image(_v, _d) for _ in range(3)],
            [
                assign_mask_image(_v, _e) if _d[ok.SWITCH] else None
                for _ in range(3)
            ]
        )
    assign_image(v, maya, _assign)


class Plaque(DecoGroup):
    """Assign a View processor and connect responsible signal handler."""

    def __init__(self, **d):
        DecoGroup.__init__(self, **d)

        node_k = self.step_key[-2]
        self.plan = {
            ny.CANVAS: PlanCanvas, ny.CELL: PlanCell, ny.FACE: PlanFace
        }[node_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas, ny.CELL: WorkCell, ny.FACE: WorkFace
        }[node_k](self)
        baby = self.item.model.baby
        if node_k == ny.FACE:
            self.handle_d[
                baby.connect(si.CELL_SHIFT_CALC, self.on_cell_calc)
            ] = baby


class Chi(Plasma):
    """Is factored from Plan and Work."""
    # for deco
    MASK_ROW_K = ok.MBF

    def __init__(self, any_group, view_x, q, make_mask, get_mask_d):
        """
        view_x: int
            0 or 1; Plan or Work

        mask_mask: function
            Call to make mask.

        q: iterable
            of function for producing View output

        get_mask_d: function
            Call to retrieve the Mask Preset.
        """
        Plasma.__init__(
            self, any_group, view_x, q, k_path=[(), (ok.IMAGE_CHOICE,)]
        )

        self.sub_maya[ok.MASK] = Mask(
            any_group, self, view_x, make_mask, get_mask_d, (ok.MBF, ok.MASK)
        )
        self.set_issue()


class Plan(Chi):
    """Manage Plan Plaque output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, make_mask, get_mask_d):
        """
        any_group: AnyGroup
        make_mask: function
            Call to make a Mask for the matter layer.

        get_mask_d: function
            Call to retrieve the Mask Preset.
        """
        Chi.__init__(self, any_group, 0, self.put, make_mask, get_mask_d)

        planner = get_planner(any_group.step_key)
        self.is_planned = planner.get_option_a(ak.PLAQUE)
        self.handle_d[
            planner.connect(fy.SIGNAL_D[ak.PLAQUE], self.on_plan_option_change)
        ] = planner

    def bore(self, v):
        """
        Manage layer output for a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned
        self.is_matter |= self.is_switched

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)
            self.sub_maya[ok.MASK].do(v, d[ok.MBF][ok.MASK])

    def on_plan_option_change(self, _, arg):
        """
        Respond to change from Planner's Plaque option.

        arg: tuple
            (bool, bool)
            (
                Is True if the Plaque option is checked in Planner.,
                Is True if the Plaque option in Planner changed.
            )
        """
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage Plaque for Peek, Preview and render output."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_cake, None)
    )

    def __init__(self, any_group, make_mask, get_mask_d):
        """
        any_group: AnyGroup
            owner

        make_mask: function
            Call to make a Mask output.

        get_mask_d: function
            Call to retrieve the Mask Preset.
        """
        Chi.__init__(self, any_group, 1, self.put, make_mask, get_mask_d)

        self.sub_maya[ok.FRAME] = Frame(any_group, self, (ok.MBF, ok.FRAME))
        self.sub_maya[ok.BUMP] = Bump(any_group, self, (ok.MBF, ok.BUMP))
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(any_group, self, ())
        self.sub_maya[LIGHT] = Light(any_group, self, ok.PLAQUE)
        self.handle_d[
            self.any_group.connect(si.BACK_CHANGE, self.on_back_change)
        ] = self.any_group

    def bore(self, v):
        """
        Manage layer output for a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH]
        is_back = v.is_back

        if self.go:
            self.is_matter |= take_type_vote(v, d)

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)
            is_change = self.is_matter or self.sub_maya[ok.MASK].is_matter

            self.sub_maya[ok.MASK].do(v, d[ok.MBF][ok.MASK])
            self.sub_maya[ok.BUMP].do(v, d[ok.MBF][ok.BUMP], is_change)

            if not self.is_face:
                is_back |= self.sub_maya[ok.FRAME].do(
                    v, d[ok.MBF][ok.FRAME], is_change
                )

            self.sub_maya[ok.BLUR_BEHIND].do(v, d, is_back, is_change)
            self.sub_maya[LIGHT].do(v, is_change)


class Main:
    """Is for main option settings found in the MainWindow."""
    vote_type = MAIN

    def __init__(self):
        self.r_c = None

    def get_mask_d(self):
        return self.any_group.value_d[ok.MBF][ok.MASK]


class WorkMain(Main, Work):
    """Is factored from Main and Work."""

    def __init__(self, *arg):
        """
        arg: tuple
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *arg + (self.get_mask_d,))


# Canvas_______________________________________________________________________
class Cloth:
    """Is factored from Plan and Work Canvas."""

    def __init__(self):
        self.do_matter = do_canvas

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_canvas_image(v, self)


class PlanCanvas(Cloth, Main, Plan, CanvasRoute):
    """Manage Plan Plaque output for the Canvas-branch."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Cloth.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, make_deco_mask, self.get_mask_d)
        CanvasRoute.__init__(self)


class WorkCanvas(Cloth, WorkMain, CanvasRoute):
    """Manage Work Plaque output for the Canvas-branch."""
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_cake, None)
    )

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's option group
        """
        Cloth.__init__(self)
        WorkMain.__init__(self, any_group, make_deco_mask)
        CanvasRoute.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:
    """Is factored from Plan and Work Cell."""
    is_face = False

    def __init__(self):
        self.r_c = None
        self.do_matter = do_main_cell

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_cell_image(v, self)


class PlanCell(Main, Plan, CellRoute, Cellular):
    """Manage Plan Plaque output for the Cell-branch."""
    issue_q = 'matter', 'per_cell', 'switched'

    def __init__(self, any_group):
        Main.__init__(self)
        Plan.__init__(self, any_group, mask_main_cell, self.get_mask_d)
        CellRoute.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, CellRoute, Cellular):
    """Manage Work Plaque output for the Cell-branch."""
    issue_q = 'cake', 'matter', 'per_cell', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        WorkMain.__init__(self, any_group, mask_main_cell)
        CellRoute.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per Cell_____________________________________________________________________
class PerCell:
    """Is factored from Plan and Work Per Cell."""
    vote_type = PER

    def __init__(self, do_matter, r_c):
        self.do_matter = do_matter
        self.r_c = r_c

    def get_mask_d(self):
        d = self.per_cell_group.get_cell_value(self.r_c)
        if d:
            return d[ok.MBF][ok.MASK]


class PlanCellPer(PerCell, Plan):
    """Manage Plan Plaque output for a Per Cell Preset."""
    is_face = False
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, r_c):
        """
        r_c: tuple
            (r, c); cell index; of int
        """
        PerCell.__init__(self, do_cell, r_c)
        Plan.__init__(self, any_group, make_deco_mask, self.get_mask_d)


class WorkCellPer(PerCell, Work):
    """Manage Work Plaque output for a Per Cell Preset."""
    is_face = False
    issue_q = 'cake', 'matter', 'shade'

    def __init__(self, any_group, r_c):
        """
        Create a Maya for Per Cell.

        r_c: tuple
            (r, c); cell index; of int
        """
        PerCell.__init__(self, do_cell, r_c)
        Work.__init__(self, any_group, make_deco_mask, self.get_mask_d)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    """Is factored from Plan and Work Face."""
    is_face = True

    def __init__(self):
        self.r_c = self.r_c_x = None
        self.do_matter = do_main_face

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_face_image(v, self)


class PlanFace(Face, Main, Plan, CellRoute):
    """Manage Plan Plaque output for the Face-branch."""
    issue_q = 'matter', 'per_cell', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, i_make_main_face_mask, self.get_mask_d)
        CellRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, CellRoute):
    """Manage Work Plaque output for the Face-branch."""
    issue_q = 'cake', 'matter', 'per_cell', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Face.__init__(self)
        WorkMain.__init__(self, any_group, i_make_main_face_mask)
        CellRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per Cell________________________________________________________________
class FacePer(PerCell):
    """Is factored from Plan and Work Per Cell Face."""
    is_face = True

    def __init__(self, *q):
        PerCell.__init__(self, *q)


class PlanFacePer(FacePer, Plan):
    """Manage Plan Plaque output for a Face Per Cell Preset."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, r_c):
        """
        any_group: AnyGroup
            the enclosing Preset's

        r_c: tuple
            (r, c); cell index; of int; Goo key
        """
        FacePer.__init__(self, do_face, r_c)
        Plan.__init__(self, any_group, i_make_cell_face_mask, self.get_mask_d)


class WorkFacePer(FacePer, Work):
    """Manage Work Plaque output for a Face Per Cell Preset."""
    issue_q = 'cake', 'matter', 'shade'

    def __init__(self, any_group, r_c):
        """
        Create a Maya for Per Cell.

        r_c: tuple
            (r, c); cell index; of int; Goo key
        """
        FacePer.__init__(self, do_face, r_c)
        Work.__init__(self, any_group, i_make_cell_face_mask, self.get_mask_d)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
