#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Lucid, select_border
from roller_fu import (
    add_layer,
    add_layer_above,
    clear_selection,
    clear_inverse_selection,
    clone_layer,
    color_fill_selection,
    color_fill_layer,
    get_layer_offset,
    make_layer_group,
    merge_layer,
    merge_layer_group,
    select_item
)
from roller_view_hub import do_shade
from roller_view_real import add_wip_layer, get_color, get_light
import gimpfu as fu

pdb = fu.pdb


def do_color(v, maya):
    """
    Make a color layer.

    v: View
    maya: Maya
    Return: layer
        with color
    """
    pdb.gimp_selection_none(v.j)

    d = maya.value_d
    a = maya.super_maya
    z = add_wip_layer(v, maya, "Color", group=a.group, offset=get_light(a))

    color_fill_layer(z, d[ok.COLOR_1])
    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: Maya
    Return: layer
        with frame material
    """
    j = v.j
    d = maya.value_d
    cause = maya.cause.matter
    frame_q = []
    w = d[ok.INNER_FRAME_W]
    group = make_layer_group(
        j,
        maya.group.name + " Clear Frame",
        parent=maya.group,
        offset=get_color(maya) + get_light(maya)
    )

    select_item(cause)

    if not pdb.gimp_selection_is_empty(j):
        # Create two layers.
        for x in range(2):
            # Add layer to the bottom of the group layer.
            z = add_layer(
                j,
                ("1", "2")[x],
                parent=group,
                offset=len(group.layers)
            )

            select_border(
                j, cause, (w, d[ok.FRAME_W] + w)[x], d[ok.FRAME_TYPE]
            )
            color_fill_selection(z, (127, 127, 127))

            z = give_edge(z)
            frame_q += [z]

        z = do_shade(frame_q[0], 0, 0, 5, (0, 0, 0), 100.)

        if z:
            select_item(cause)
            clear_selection(z)

            # The shadow layer is on top of the layer
            # stack, so move it to where it belongs.
            pdb.gimp_image_reorder_item(
                j, z, group, get_layer_offset(frame_q[1])
            )
    return merge_layer_group(group)


def give_edge(z):
    """
    Give the frame an edge.

    z: layer
        to give edge

    Return: layer
        with edge
    """
    z1 = clone_layer(z, "Material")
    z2 = add_layer_above(z, n="Back")

    color_fill_layer(z2, (100, 100, 100))

    z1 = merge_layer(z1)

    # amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(z.image, z1, 1., 0, 0)

    z1.mode = fu.LAYER_MODE_DODGE

    select_item(z)
    clear_inverse_selection(z1)
    return merge_layer(z1)


class ClearFrame(Lucid):
    """Is a crisp translucent frame with an inner ridge."""

    def __init__(self, *q, **d):
        """
        q: tuple
            Lucid spec

        d: dict
            Lucid spec
        """
        Lucid.__init__(self, *q + (do_matter, do_color), **d)
