#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_model_goo import Goo
from roller_one_rect import Rect
from roller_polygon import calc_pin_xy

RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP


class Hexagon:
    """
    Calculate the position and the size of cells for a
    regular hexagon. Is a double-spaced model-type.
    """

    @staticmethod
    def calc(model, o, ellipse_space=.0):
        """
        Calculate cell rectangle for a Model's cell.

        model: Model
        o: One
            with Cell Type reference

        Return: list
            [Plan vote, Work vote]
        """
        def _arrange():
            """
            Arrange a hexagon shape of x, y coordinate
            where each x, y pair is a polygon vertex.

            Return: tuple
                shape
            """
            _r = r * 2
            _x = q_x[c]
            _x1 = q_x[c + 1]
            _x2 = q_x[c + 2]
            _y = q_y[_r + 1]
            _y1 = q_y[_r + 2]
            return (
                _x, _y,
                _x1, q_y[_r],
                _x2, _y,
                _x2, _y1,
                _x1, q_y[_r + 3],
                _x, _y1
            )

        vote_d = {}
        did_cell = model.past.did_cell
        row, column = model.division
        goo_d = model.goo_d
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect

        # intersect points
        q_x = []
        q_y = []

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w, h = min(canvas_w, o.column_width), min(canvas_h, o.row_height)

            # grid size
            w1 = w / 2.
            h1 = h * .75
            h2 = h - h1
            s = column * w1 + w1, row * h1 + h2

            # topleft corner, 'x, y'
            x, y = calc_pin_xy(o.pin_corner, x, y, canvas_w, canvas_h, *s)

        elif o.grid_type == gr.SHAPE_COUNT:
            # Calculate 's', 'w', 'h'.
            # cell size
            w, h = canvas_w / (.5 + column * .5), canvas_h / (.25 + row * .75)

            # two possible solutions
            # solution one
            # hexagon size, 'hex_w, hex_h'
            hex_w, hex_h = h * RATIO, h

            w1 = hex_w / 2.
            h1 = hex_h * .75
            h2 = hex_h - h1
            s = column * w1 + w1, row * h1 + h2

            # solution two
            # hexagon size, 'hex_w1, hex_h1'
            hex_w1, hex_h1 = w, w * UP_RATIO

            w1 = hex_w1 / 2.
            h1 = hex_h1 * .75
            h2 = hex_h1 - h1
            s1 = column * w1 + w1, row * h1 + h2
            s = s[0], s[1]
            s1 = s1[0], s1[1]

            if s[0] > canvas_w or s[1] > canvas_h:
                s = s1
                w, h = hex_w1, hex_h1

            else:
                w, h = hex_w, hex_h
            x, y = calc_pin_xy(o.pin_corner, x, y, canvas_w, canvas_h, *s)

        else:
            # cell count
            # Calculate the cell size for aligned horizontally.
            w = canvas_w / (.5 + column * .5)
            h = canvas_h / (.25 + row * .75 - ellipse_space)

        w = w / 2.
        h1 = h * .25
        h2 = h * .75

        # remainder total, 'f_x, f_y'
        f_x = f_y = .0

        # Add remainder to coordinate when the remainder is close to one.
        for _ in range(column + 2):
            x, f = divmod(x, 1.)
            f_x += f

            if f_x >= .999:
                x += 1.
                f_x -= 1.

            q_x += [x]
            x += w

        for _ in range(row + 1):
            y, f = divmod(y, 1.)
            f_y += f

            if f_y >= .999:
                y += 1.
                f_y -= 1.

            q_y += [y, round(y + h1)]
            y += h2

        for r_c in model.cell_q:
            r, c = r_c
            r1 = r * 2
            x, x1 = q_x[c], q_x[c + 2]
            y, y1 = q_y[r1], q_y[r1 + 3]
            a = goo_d[r_c] = Goo(r_c)

            # Prevent round to zero with max 1.
            a.cell = a.merged = Rect(x, y, max(1., x1 - x), max(1., y1 - y))

            vote_d[r_c] = did_cell(r_c)
            a.form = _arrange()
        return vote_d
