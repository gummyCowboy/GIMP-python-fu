#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import atan2, cos, radians, sin
from roller_constant_for import Justification as ju, Resize as fz
from roller_constant_key import Option as ok
from roller_deco import (
    make_main_face_mask,
    make_cell_face_mask,
    make_sel_mask,
    ready_canvas_rect,
    ready_shape
)
from roller_fu import (
    clear_inverse_selection,
    copy_all_image,
    flip_layer,
    load_selection,
    merge_layer,
    paste_layer,
    remove_z,
    select_item,
    select_rect,
    select_shape,
    verify_layer,
    verify_layer_group
)
from roller_one import seal
from roller_one_rect import Rect
from roller_polygon import calc_circumradius, get_extreme, get_bounds
from roller_view_contain import Pot
from roller_view_real import (
    add_base_layer, add_matter_group, add_matter_layer, clip_to_view
)
import gimpfu as fu

pdb = fu.pdb


def apply_shape_mask(z, shape):
    """
    Select a shape and clear pixel outside of it.

    z: layer
        target of the clear op

    shape: tuple
        Is a polygon shape's x, y series.
    """
    select_shape(z.image, shape)
    clear_inverse_selection(z)


def calc_lock(w, h, w1, h1):
    """
    Return the size of an image that will fit into a cell.

    w, h: numeric
        image size
        (width, height)

    w1, h1: numeric
        cell size
        (width, height)
        Conform the image size to this size.
    """
    w, h = float(w), float(h)
    w_r = w / w1
    h_r = h / h1

    if w_r > h_r:
        w, h = w1, h * (w1 / w)

    else:
        w, h = w * (h1 / h), h1
    return max(w, 1.), max(h, 1.)


def calc_mold_rotation(v, maya):
    """
    If an image is rotated, calculate the rotated rectangle's
    corner points. The image is first rotated, and then the
    rotated image rectangle is fitted to the pocket rectangle.

    v: View
    maya: Maya
    """
    f = maya.value_d[ok.ROTATION]
    if f:
        a = v.pot
        q = zero_center(a.mold.foam(), *a.mold.center())
        q = rotate_points(q, a.pocket, calc_circumradius(*a.source.size), f)
        a.foam = fit_coord_in_rect(q, a.pocket)
        a.mold.rect = get_bounds(a.foam)


def calc_rotated_point(x, y, angle, radius):
    """
    Return a point on a circle that corresponds to an angle.

    angle : float
        rotation angle in radian

    radius: float
        the radius of the circle in pixel

    x, y: float
        center point

    Return: list
        x, y of float
        the point on the circle
    """
    return [(sin(angle) * radius) + x, (cos(angle) * -radius) + y]


def do(v, maya, make, is_face=False):
    """
    Prepare to place image.

    v: View
    maya: Maya
    make: function
        Call to make an image layer.

    is_face: bool
        Is True when Face Maya is in control.

    Return: layer or None
        with image
    """
    if not v.x:
        d = maya.value_d

        # Preserve.
        mode = d[ok.MODE]

        # Plan override.
        d[ok.MODE] = "Normal"

    v.pot = Pot(is_face)
    z = make(v, maya)

    if not v.x:
        # Restore.
        d[ok.MODE] = mode
        if z:
            z.opacity = 66.
    return z


def do_canvas(v, maya):
    """
    Place image for the Canvas-branch option.

    v: View
    maya: Maya
    Return: layer or None
        image matter
    """
    return do(v, maya, make_canvas_material)


def do_main_cell(v, maya):
    """
    Place image for the Cell-branch main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_material)


def do_main_face(v, maya):
    """
    Place image for the Face-branch main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with image material
    """
    return do(v, maya, make_main_face_material, is_face=True)


def do_cell(v, maya):
    """
    Place image for Per Cell.

    v: View
    maya: Maya
    Return: layer or None
        with image
    """
    return do(v, maya, make_per_cell_material)


def do_face(v, maya):
    """
    Place image for Per Cell Face.

    v: View
    maya: Maya
    make: function
        Call to produce the layer output.

    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_face_material, is_face=True)


def fit_coord_in_rect(q, rect):
    """
    Given a rectangle polygon of points, calculate
    their position inside another rectangle.

    q: list
        x, y series
        8 total
        rectangle points

    rect: Rect
        Is the bounds for the coordinates.

    Return: list
        with coordinates
    """
    q1 = []
    left, top, right, bottom = get_extreme(q)
    input_w = right - left
    input_h = bottom - top
    is_fit = rect.w >= input_w and rect.h >= input_h

    if not is_fit:
        center_x, center_y = rect.center()
        lock_w, lock_h = calc_lock(input_w, input_h, *rect.size)
        lock_x = center_x - lock_w / 2.
        lock_y = center_y - lock_h / 2.

        for i in range(0, 8, 2):
            # Transform size, one coordinate per side.
            x, y = q[i], q[i + 1]

            ratio_x = (x - left) / input_w
            ratio_y = (y - top) / input_h
            x = lock_w * ratio_x + lock_x
            y = lock_h * ratio_y + lock_y

            # point inside pocket rectangle, 'q1'
            q1 += [x, y]
        return q1
    return q


def i_make_main_face_mask(v, maya):
    """
    Apply mask option to main Face image.

    v: View
    maya: Maya
    Return: mask layer or None
    """
    return make_main_face_mask(
        v, maya, maya.value_d[ok.MRR][ok.MASK]
    )


def i_make_cell_face_mask(v, maya):
    """
    Apply a mask to a Per Cell image.

    v: View
    maya: Image Per Cell Maya
    Return: mask layer or None
    """
    return make_cell_face_mask(
        v, maya, maya.value_d[ok.MRR][ok.MASK]
    )


def justify_mold(v, n):
    """
    Adjust the mold position per the image justification.

    v: View
    n: string
        justification type
    """
    mold = v.pot.mold
    x, y = mold.position
    pocket = v.pot.pocket
    w, h = mold.size

    if w != pocket.w:
        # x-vector position
        if n in ju.CENTER_X:
            x1 = pocket.w / 2. - w / 2. + pocket.x

        elif n in ju.LEFT:
            x1 = pocket.x
        else:
            # right
            x1 = pocket.x + pocket.w - w

    else:
        x1 = pocket.x

    if h != pocket.h:
        # y-vector position
        if n in ju.CENTER_Y:
            y1 = pocket.h / 2. - h / 2. + pocket.y

        elif n in ju.TOP:
            y1 = pocket.y
        else:
            # bottom
            y1 = pocket.y + pocket.h - h

    else:
        y1 = pocket.y

    mold.position = x1, y1
    if v.pot.foam and (x != x1 or y != y1):
        # Adjust foam to justification.
        w1 = x1 - x
        h1 = y1 - y
        q = v.pot.foam

        # adjusted foam, 'q1'
        q1 = []

        for i in range(0, len(q), 2):
            x, y = q[i], q[i + 1]
            q1 += [x + w1, y + h1]
        v.pot.foam = q1


def make_main_face_material(v, maya):
    """
    Place image for Face main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    group = add_matter_group(v, maya, maya.group)

    for r, c in maya.main_cell_q:
        maya.r_c = r, c
        make_face_material(v, maya, group, is_main=True)
    return verify_layer_group(group)


def make_main_material(v, maya):
    """
    Place image for Cell-branch main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with image material
    """
    group = add_matter_group(v, maya, maya.group)

    for r, c in maya.main_cell_q:
        maya.r_c = r, c
        make_cell_material(v, maya, group, is_main=True)
    return verify_layer_group(group)


def make_canvas_material(v, maya):
    """
    Place a Canvas Image.

    v: View
    maya: Maya
    Return: layer or None
        with image material
    """
    image = maya.get_image(None)
    if image:
        ready_canvas_rect(v, maya, option=None)

        v.pot.pocket.rect = maya.rect
        base = add_matter_layer(v, maya, maya.group)
        z = place_image(v, maya, image.j, base, False)

        if z:
            # Consume 'base'. Set the layer size to the image size.
            z = merge_layer(z)

        else:
            remove_z(base)
        return z


def make_cell_face_material(v, maya):
    """
    Place image for Per Cell Face.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    group = add_matter_group(v, maya, maya.group)

    make_face_material(v, maya, group)
    return verify_layer_group(group)


def make_cell_material(v, maya, group, is_main=False):
    """
    Place an Image in a cell.

    v: View
    maya: Maya
    group: layer
        Is the parent layer for image output.

    is_main: bool
        Is True when the caller is the main cell Maya version.

    Return: layer or None
        with image material
    """
    # failed image layer, 'z'
    z = None

    # Image instance, 'image'
    image = maya.get_image(maya.r_c)

    if image:
        ready_shape(v, maya, option=None)

        v.pot.pocket = maya.model.get_pocket(maya.r_c)

        if group.layers:
            # Use the top layer instead of making a base layer.
            # This happens when the main version of Maya is calling.
            base = group.layers[0]
            is_remove = False

        else:
            base = add_matter_layer(v, maya, group)
            is_remove = True

        z = place_image(v, maya, image.j, base, is_main)
        z = verify_layer(z)
        if is_remove:
            remove_z(base)
    return z


def make_face_material(v, maya, group, is_main=False):
    """
    Make Face Fringe material.

    v: View
    maya: Maya
    group: layer
        Is the destination of Face output.

    is_main: bool
        Main Maya Cell image output is placed on the same layer.
    """
    base = add_base_layer(v, group)
    r, c = maya.r_c
    model = maya.model
    face_image_q = maya.get_image((r, c))

    # three faces, '3'
    for face_x in range(3):
        arg = maya.r_c_x = r, c, face_x
        v.pot.pocket = model.get_face_merged(*arg)
        maya.rect = model.get_face_rect(*arg)
        v.deco.shape = model.get_face_form(*arg)
        image = face_image_q[face_x]
        if image:
            place_image(v, maya, image.j, base, is_main)


def make_per_cell_material(v, maya):
    """
    Is needed for its argument signature.

    v: View
    maya: Maya
    Return: layer or None
        with image material
    """
    return make_cell_material(v, maya, maya.group)


def mask_main_cell(v, maya):
    """
    Apply mask to image on a main option layer.

    v: View
    maya: Maya
    Return: mask layer or None
    """
    j = v.j
    z = maya.matter
    d = maya.value_d
    sel = mask = None
    mask_d = d[ok.MRR][ok.MASK]
    model = maya.model

    pdb.gimp_selection_none(j)

    for r_c in maya.main_cell_q:
        maya.r_c = r_c
        image_sel = model.get_image_sel(r_c)
        if image_sel:
            load_selection(j, image_sel)

            if not pdb.gimp_selection_is_empty(j):
                make_sel_mask(v, maya, mask_d)

            if sel:
                load_selection(j, sel, option=fu.CHANNEL_OP_ADD)
                pdb.gimp_image_remove_channel(j, sel)
            if not pdb.gimp_selection_is_empty(j):
                sel = pdb.gimp_selection_save(j)
    if sel:
        load_selection(j, sel)
        pdb.gimp_image_remove_channel(j, sel)
    if not pdb.gimp_selection_is_empty(j):
        mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)
        pdb.gimp_layer_add_mask(z, mask)
    return mask


def mold_cover(v, maya, j):
    """
    Resize an image using the Cover Resize Method.

    v: View
    maya: Maya
    j: GIMP image
        WIP

    Return: GIMP image
        WIP
    """
    a = v.pot
    b = a.pocket
    d = maya.value_d
    w, h = b.w, b.h
    w1, h1 = j.width, j.height

    # Is small and not a Face image, 'is_small'.
    is_small = w1 <= w and h1 <= h and not v.pot.is_face

    trim(v, d, b, w1, h1, is_trim=not is_small)

    if is_small:
        x1 = b.x + b.w
        y1 = b.y + b.h

        # Transform uses foam.
        a.foam = (
            b.x, b.y,
            x1, b.y,
            b.x, y1,
            x1, y1
        )

        # Rotation uses rectangle.
        v.pot.mold.rect = b.rect
    return j


def mold_crop(v, maya, j):
    """
    Set the mold and source rectangle for a Crop Resize Method.
    Determine if the source rectangle is smaller than the pocket rectangle.

    v: view
    maya: Maya
    j: GIMP image
        WIP

    Return: GIMP image
        WIP
    """
    a = v.pot
    b = a.pocket
    source = a.source
    w, h = j.width, j.height
    d = maya.value_d
    e = d[ok.IRRW][ok.RESIZE]

    # Limit the crop rectangle size to the image source size.
    x = seal(e[ok.CROP_X], 1, j.width - 1)
    y = seal(e[ok.CROP_Y], 1, j.height - 1)
    source.rect = (
        x, y,
        seal(e[ok.CROP_W], 1, w - x),
        seal(e[ok.CROP_H], 1, h - y)
    )

    source.rect = trim_oversize(d[ok.JUSTIFICATION], b, source)
    a.mold.rect = 0, 0, source.w, source.h

    # Source pixel is copied without resizing.
    a.is_small = True

    return j


def mold_factor(v, maya, j):
    """
    Resize an image by multiplying its size by a factor.

    v: View
    j: GIMP image
        WIP

    Return: GIMP image
        WIP
    """
    a = v.pot
    b = v.pot.pocket
    source = a.source
    d = maya.value_d
    e = d[ok.IRRW][ok.RESIZE]
    w, h = e[ok.FIW], e[ok.FIH]

    # Check to see if the source image is resized.
    if w != 1. or h != 1.:
        # Create a resized source image to replace the original.
        copy_all_image(j)

        j1 = pdb.gimp_edit_paste_as_new_image()
        if j1:
            j = v.pot.temp_image = j1
            w = float(j.width * w)
            h = float(j.height * h)

            pdb.gimp_item_transform_perspective(
                j.layers[0], 0, 0, w, 0, 0, h, w, h
            )
            pdb.gimp_image_resize_to_layers(j)

    source.rect = 0, 0, j.width, j.height
    source.rect = trim_oversize(d[ok.JUSTIFICATION], b, source)
    a.mold.rect = 0, 0, source.w, source.h

    # Source pixel is copied without resizing.
    a.is_small = True

    return j


def mold_fill(v, maya, j):
    """
    Set the mold and source rectangle for a Fill Resize Method.
    Determine if the source rectangle is smaller than the pocket rectangle.

    v: View
    j: GIMP image
        WIP

    Return: GIMP image
        to be placed
    """
    a = v.pot
    b = a.pocket
    a.source.rect = 0, 0, j.width, j.height
    a.is_small = a.source.w == b.w and a.source.h == b.h
    v.pot.mold.rect = v.pot.pocket.rect
    return j


def mold_fixed(v, maya, j):
    """
    Resize an image with Fixed Resize Method.

    v: View
    j: GIMP image
        WIP

    Return: GIMP image
        to be placed
    """
    a = v.pot
    b = v.pot.pocket
    source = a.source
    d = maya.value_d
    e = d[ok.IRRW][ok.RESIZE]
    w, h = e[ok.FIXED_SIZE_W], e[ok.FIXED_SIZE_H]

    # Check to see if a new image is needed.
    if w != j.width or h != j.height:
        # Create a resized source image to replace the original.
        copy_all_image(j)

        j1 = pdb.gimp_edit_paste_as_new_image()
        if j1:
            j = v.pot.temp_image = j1
            w, h = int(w), int(h)

            pdb.gimp_item_transform_perspective(
                j.layers[0], 0, 0, w, 0, 0, h, w, h
            )
            pdb.gimp_image_resize_to_layers(j)

    source.rect = 0, 0, j.width, j.height
    source.rect = trim_oversize(d[ok.JUSTIFICATION], b, source)
    a.mold.rect = 0, 0, source.w, source.h

    # Source pixel is copied without resizing.
    a.is_small = True

    return j


def mold_lock(v, maya, j):
    """
    Determine the size of a mold rectangle given a pocket rectangle,
    and a Locked Aspect Ratio Resize Method. Set the source
    rectangle to the image size. Determine if the source image
    is smaller than the pocket rectangle.

    v: View
    maya: Maya
    j: GIMP image
        source pixel

    Return: GIMP image
        to be placed
    """
    a = v.pot
    b = a.pocket
    a.source.rect = 0, 0, j.width, j.height
    a.is_small = a.source.w <= b.w and a.source.h <= b.h

    if a.is_small:
        w, h = j.width, j.height

    else:
        # down-size
        w, h = calc_lock(j.width, j.height, *b.size)

    a.mold.rect = 0, 0, w, h
    return j


def mold_trim(v, maya, j):
    """
    Resize an image using the Trimmed Side Resize Method.

    v: View
    j: GIMP image
        source pixel

    Return: GIMP image
        to be placed
    """
    a = v.pot
    b = a.pocket
    d = maya.value_d
    w1, h1 = j.width, j.height
    a.is_small = w1 <= b.w and h1 <= b.h

    if not a.is_small:
        trim(v, d, b, w1, h1)

    else:
        a.mold.rect = b.x, b.y, w1, h1
        a.source.rect = 0, 0, w1, h1
    return j


def place_image(v, maya, j, base, is_main):
    """
    Copy and paste an image after molding it to a cell.
    Molding takes an image source and produces a
    transformed image that fits inside a pocket rectangle.

    v: View
    v: Maya
    group: layer
        Is the destination of layer output.

    j: GIMP image
        WIP to place

    base: layer
        Is the target for the image copy/paste.

    is_main: bool
        Is true when the Maya is the main version.

    Return: image layer or None
        with image
    """
    def _flip(_z):
        if d[ok.FLIP_R][ok.FLIP_H]:
            _z = flip_layer(_z, horizontal=1)

        if d[ok.FLIP_R][ok.FLIP_V]:
            # vertical flip
            _z = flip_layer(_z)
        return _z

    d = maya.value_d
    a = v.pot
    a.foam = []
    model = maya.model
    resize_type = d[ok.IRRW][ok.RESIZE][ok.RESIZE_TYPE]
    j = MOLD[resize_type](v, maya, j)

    calc_mold_rotation(v, maya)

    if resize_type not in (ok.COVER, ok.FILLED):
        justify_mold(v, d[ok.JUSTIFICATION])

    if a.is_face:
        if resize_type in (ok.COVER, ok.FILLED):
            a.foam = model.get_face_foam(*maya.r_c_x)
        else:
            a.foam = model.get_face_transform(*maya.r_c_x)(v, maya)

    source_rect = a.source.rect

    select_rect(j, *source_rect)
    pdb.gimp_edit_copy_visible(j)

    z = paste_layer(base, base.parent.name + " Image")
    z = _flip(z)
    z = transform_source(v, z)

    clip_to_view(z)

    if a.temp_image:
        pdb.gimp_image_delete(a.temp_image)
        a.temp_image = None

    if z and not a.is_face:
        if not model.is_rectangle:
            apply_shape_mask(z, v.deco.shape)
        if is_main:
            select_item(z)
            model.set_image_sel(v.j, maya.r_c)
    return z


def rotate_points(point_q, rect, radius, f):
    """
    Rotate rectangle corner point around its center point.

    point_q: iter
        of numeric points

    rect: Rect
        Has center point.

    radius: float
        half-diagonal of the output rectangle

    f: float
        rotation amount in degree

    Return: list
        of rotated points
    """
    q = []
    f = radians(f)
    center_x, center_y = rect.center()

    for i in range(0, 8, 2):
        x, y = point_q[i], point_q[i + 1]
        q += calc_rotated_point(center_x, center_y, atan2(x, y) + f, radius)
    return q


def transform_source(v, z):
    """
    Transform an image source into its destination mold rectangle.

    v: View
    z: layer
        with material to transform

    Return: layer
        with transformed material
    """
    q = v.pot.foam

    pdb.gimp_selection_none(v.j)

    if q:
        # Coordinate is a float.
        # point order: topleft, top-right, bottom-left, bottom-right
        z = pdb.gimp_item_transform_perspective(z, *map(round, q))

    elif v.pot.is_small:
        x, y = v.pot.mold.position
        x = int(round(x))
        y = int(round(y))
        pdb.gimp_layer_set_offsets(z, x, y)

    else:
        # Transform Rectangle, 'a'.
        a = v.pot.mold

        # I tried 'pdb.gimp_item_transform_perspective', but it fails
        # as it interpolates outside the layer boundary producing a soft
        # edged image for a rectangular image.
        pdb.gimp_context_set_antialias(0)

        # local origin, 'True'
        # Rectangle is integer.
        pdb.gimp_layer_scale(
            z, max(1, int(round(a.w))), max(1, int(round(a.h))), True
        )
        pdb.gimp_layer_set_offsets(z, int(round(a.x)), int(round(a.y)))
    return z


def trim(v, d, b, w1, h1, is_trim=True):
    """
    Trim a side of an over-sized image.

    v: View
    d: dict
        Image Preset

    b: Rect
        pocket

    w1, h1: numeric
        width, height of image

    is_trim: bool
        If True, then calculate the mold rectangle.
    """
    source = v.pot.source
    ratio_w = float(b.w / w1)
    ratio_h = float(b.h / h1)

    # the mold scale factor, 'f'.
    # the pocket scale factor, 'f1'
    if ratio_w < ratio_h:
        # The image height is closer to the pocket height.
        f = ratio_h
        f1 = float(h1 / b.h)

    else:
        # The image width is closer to the pocket width.
        f = ratio_w
        f1 = float(w1 / b.w)

    # Oversize the pocket to get a source rectangle, 'rect'.
    rect = Rect(b.x, b.y, b.w * f1, b.h * f1)
    source.rect = 0, 0, w1, h1
    source.rect = trim_oversize(d[ok.JUSTIFICATION], rect, source)

    if is_trim:
        # The mold rectangle is derived from the image source rectangle.
        v.pot.mold.rect = b.x, b.y, source.w * f, source.h * f


def trim_oversize(n, pocket, source):
    """
    Use to get the pocket scale for an over-sized rectangle. The
    justification determines the side where clipping is applied.

    n: string
        image justification

    w, h: numeric
        size of Trim

    Return: tuple
        x, y, w, h
        the rectangle trimmed selection of the source image
    """
    w, h = pocket.size
    x1, y1, w1, h1 = source.rect

    # x-vector
    # Check for over-sized vector.
    if w < w1:
        # over-sized
        w2 = w

        if n in ju.CENTER_X:
            x2 = (w1 / 2. + x1) - w / 2.

        elif n in ju.LEFT:
            x2 = x1

        else:
            # right
            x2 = x1 + w1 - w

    else:
        # no change
        x2 = x1
        w2 = w1

    # y-vector
    if h < h1:
        # over-sized
        h2 = h

        if n in ju.CENTER_Y:
            y2 = (h1 / 2. + y1) - h / 2.

        elif n in ju.TOP:
            y2 = y1
        else:
            # bottom
            y2 = y1 + h1 - h

    else:
        # no change
        y2 = y1
        h2 = h1
    return x2, y2, w2, h2


def zero_center(q, center_x, center_y):
    """
    Offset the points in a rectangle polygon by their center
    x and y position. Invert the y value in order to convert
    the canvas coordinate into a Cartesian coordinate.

    q: iter
        x, y series, eight coordinates
        a rectangle polygon

    center_x, center_y: numeric
        the center of the rectangle
    """
    # a rectangle polygon's x, y series with a zero center, 'q1'
    q1 = []

    for i in range(0, 8, 2):
        q1 += [q[i] - center_x, -(q[i + 1] - center_y)]
    return q1


MOLD = {
    ok.COVER: mold_cover,
    fz.CROP: mold_crop,
    ok.FILLED: mold_fill,
    fz.FIXED: mold_fixed,
    fz.FACTOR: mold_factor,
    ok.LOCKED: mold_lock,
    ok.TRIM: mold_trim
}
