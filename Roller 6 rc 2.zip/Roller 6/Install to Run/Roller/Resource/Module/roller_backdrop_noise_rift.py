#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from random import choice, randint
from roller_a_contain import Globe, Run
from roller_constant_key import Option as ok
from roller_fu import clear_inverse_selection, merge_layer_group, select_item
from roller_maya_style import Style
from roller_view_hub import do_mod
from roller_view_preset import combine_seed
from roller_view_real import add_sub_base_group, add_wip_layer


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: NoiseRift
    Return: layer
        Backdrop Style material
    """
    def _add_noise():
        _m = True

        if ok.NOISE_OPACITY in d:
            if not d[ok.NOISE_OPACITY]:
                _m = False
        if _m:
            # Generate noise line.
            # The horizontal and vertical sizes are randomized.
            pdb.plug_in_solid_noise(
                j, z,
                0,                      # no tile-able
                1,                      # yes, turbulent
                int(d[ok.SEED] + Globe.seed),
                int(d[ok.NOISE_AMOUNT]),
                float(randint(1, 3)),
                float(randint(1, 3)),
            )

            # Aggregate the noise.
            # The radius is randomized.
            pdb.plug_in_unsharp_mask(
                j, z,
                choice((1., 3.)),
                54.,                    # amount
                .0                      # threshold
            )

            # Remove the white noise.
            select_item(z)
            clear_inverse_selection(z)
            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))

    j = Run.j
    d = maya.value_d
    parent = add_sub_base_group(maya)
    z = add_wip_layer("Noise", parent)

    combine_seed(d)
    _add_noise()
    pdb.gimp_selection_none(j)

    z = merge_layer_group(parent)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class NoiseRift(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
