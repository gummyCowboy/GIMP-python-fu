#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, seed
from roller_a_contain import Globe
from roller_constant_key import Option as ok
from roller_one_wip import Wip, get_factor


def calc_margin(d):
    """
    Return margin values after adding their fixed and factor value together.

    d: dict or None
        Margin Preset

    Return: list
        top, bottom, left, right
        of numeric
    """
    top = bottom = left = right = 0
    w, h = Wip.get_size()

    if d and d[ok.SWITCH]:
        top = get_factor(d[ok.TOP], h)
        bottom = get_factor(d[ok.BOTTOM], h)
        left = get_factor(d[ok.LEFT], w)
        right = get_factor(d[ok.RIGHT], w)

        # Compensate for margin overflow
        # by reserving one pixel for the image.
        if top + bottom >= h:
            top = h / 2.
            bottom = h - top - 1
        if left + right >= w:
            left = w / 2.
            right = w - left - 1
    return top, bottom, left, right


def calc_shift_rect(d):
    """
    Calculate a rectangle from another rectangle given a Shift Preset.

    d: dict
        Shift Preset

    Return: tuple
        x, y, w, h
        the transformed rectangle
    """
    if d and d[ok.SWITCH]:
        combine_seed(d)

        w, h = Wip.get_size()

        # size
        w1 = get_factor(d[ok.WIDTH_MOD], w)
        h1 = get_factor(d[ok.HEIGHT_MOD], h)
        shift_w = get_factor(d[ok.JITTER_W], w)
        shift_h = get_factor(d[ok.JITTER_H], h)
        w1 += randint(-shift_w, shift_w)
        h1 += randint(-shift_h, shift_h)

        # position
        x = get_factor(d[ok.OFFSET_X], w)
        y = get_factor(d[ok.OFFSET_Y], h)
        shift_x = get_factor(d[ok.JITTER_X], w)
        shift_y = get_factor(d[ok.JITTER_Y], h)
        x += randint(-shift_x, shift_x)
        y += randint(-shift_y, shift_y)
        x, y, w, h = map(round, (map(int, (x, y, w, h))))
        return x, y, max(1., w1), max(1., h1)

    # no change
    return .0, .0, .0, .0


def combine_seed(d):
    """
    Seed Python's random output with combined global and local seed values.

    d: dict
        Has a SEED option.
    """
    seed(int(Globe.seed + d[ok.SEED]))
