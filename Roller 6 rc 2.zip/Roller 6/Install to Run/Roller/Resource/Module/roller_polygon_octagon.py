#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_model_goo import Goo
from roller_polygon import (
    arrange_octagon,
    arrange_octagon_on_its_side,
    calc_octagon_offset,
    calc_octagon_on_its_side_offset,
    calc_pin_xy,
    make_coord_list
)


class GridOctagon:
    """A cell is octagon shaped."""

    @staticmethod
    def calc(model, o):
        """
        For Model cell, calculate 'cell' and 'merge'
        rectangle and their inscribed 'form' polygon.

        model: Model
        o: One
            Has Cell/Type reference.

        Return: dict
            {value: [bool, bool]}
            {cell key: [Plan vote change, Work vote change]}
        """
        vote_d = {}
        did_cell = model.past.did_cell
        row, column = model.grid
        goo_d = model.goo_d
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect
        is_align = False if model.cell_shape in \
            (sh.OCTAGON_SHEAR, sh.OCTAGON) else True

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w = min(canvas_w, o.column_width)
            h = min(canvas_h, o.row_height)

            s = w * column, h * row
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

        elif o.grid_type == gr.SHAPE_COUNT:
            w = canvas_w / column
            h = canvas_h / row
            w = min(w, h)
            s = w * column, w * row
            w, h = w, w
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

        else:
            w = canvas_w / column
            h = canvas_h / row

        # [intersect, ...]
        q_x = make_coord_list(canvas_w, column + 1, x, span=w)
        q_y = make_coord_list(canvas_h, row + 1, y, span=h)

        offset_q = calc_octagon_on_its_side_offset(w, h) if is_align \
            else calc_octagon_offset(w, h)

        for r_c in model.cell_q:
            r, c = r_c
            x, x1 = q_x[c], q_x[c + 1]
            y, y1 = q_y[r], q_y[r + 1]
            a = goo_d[r_c] = Goo(r_c)

            # Prevent round to zero with max 1.
            w, h = max(1., x1 - x), max(1., y1 - y)
            a.cell.rect = a.merged.rect = x, y, w, h
            a.form = arrange_octagon_on_its_side(offset_q, x, y, w, h) \
                if is_align else arrange_octagon(offset_q, x, y, w, h)
            vote_d[r_c] = did_cell(r_c)
        return vote_d
