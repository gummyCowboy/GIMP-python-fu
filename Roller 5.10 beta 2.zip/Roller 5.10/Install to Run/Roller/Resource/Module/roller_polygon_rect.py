#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_model_goo import Goo
from roller_one_rect import Rect
from roller_polygon import calc_pin_xy, make_coord_list


class GridRect:
    """
    Calculate the position and the size of
    cell. Each cell is rectangular shaped.
    """

    @staticmethod
    def calc(model, o):
        """
        Calculate a Model's cell rectangle, merge rectangle, and form polygon.

        model: Model
        o: One
            with Cell Type reference

        Return: dict
            {(row, column0): [Plan vote, Work vote]}
        """
        vote_d = {}
        did_cell = model.past.did_cell
        row, column = model.division
        goo_d = model.goo_d
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w = min(canvas_w, o.column_width)
            h = min(canvas_h, o.row_height)
            s = w * column, h * row
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

        elif o.grid_type == gr.SHAPE_COUNT:
            w = canvas_w / column
            h = canvas_h / row
            w = min(w, h)
            s = w * column, w * row
            w, h = w, w
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

        else:
            w = canvas_w / column
            h = canvas_h / row

        # [intersect coordinate, ...]
        q_x = make_coord_list(canvas_w, column + 1, x, span=w)
        q_y = make_coord_list(canvas_h, row + 1, y, span=h)

        for r in range(row):
            for c in range(column):
                r_c = r, c
                y, y1 = q_y[r], q_y[r + 1]
                x, x1 = q_x[c], q_x[c + 1]
                a = goo_d[r_c] = Goo(r_c)

                # Prevent round to zero with max 1.
                b = a.cell = Rect(x, y, max(1., x1 - x), max(1., y1 - y))

                a.merged = b.clone()
                a.form = x, y, x1, y, x1, y1, x, y1
                vote_d[r_c] = did_cell(r_c)
        return vote_d
