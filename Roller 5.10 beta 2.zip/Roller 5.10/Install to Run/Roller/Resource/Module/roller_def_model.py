#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import (
    Border as bo, Fringe as ng, Plaque as aq, Issue as vo
)
from roller_constant_key import Option as ok, Widget as wk
from roller_def_share import (
    make_rainbow_count_tip,
    make_text_tip,
    set_issue,
    ANGLE,
    BBR1,
    BBF,
    BFR1,
    BLUR,
    CAPTION_TYPE,
    CBR,
    COLOR_1,
    CONTRACT,
    DECO_TYPE,
    FCR,
    FLIP_R,
    FONT_SIZE,
    GRADIENT,
    GRADIENT_ANGLE,
    GRADIENT_TYPE,
    HARDNESS,
    IDR,
    IMAGE_CHOICE,
    IRRW,
    JUSTIFICATION,
    LTR,
    MAX_POLAR_X,
    MAX_POLAR_Y,
    MAX_POSITIVE_X,
    MAX_POSITIVE_Y,
    MBR,
    MODE,
    MBF,
    MSS,
    NET_LINE,
    OBEY_MARGINS,
    OCR,
    OPACITY,
    PATTERN,
    PER,
    SEED,
    SWITCH,
    TEXT
)
from roller_one_tip import Tip
from roller_widget_row import Rainbow
from roller_widget_slider import Slider
import sys


def get_border_type_list():
    return bo.TYPE


def get_fringe_type_list():
    return ng.TYPE


def get_plaque_type_list():
    return aq.TYPE


NO_MATTER = (
    ok.BLUR_BELOW,
    ok.BRUSH_D,
    ok.BUMP,
    ok.FRAME,
    ok.IMAGE_CHOICE,
    ok.MASK,
    ok.MODE,
    ok.OPACITY,
    ok.PER,
    ok.SHADOW,
    ok.STRIPE
)
net_line_w = deepcopy(NET_LINE)
net_line_w[wk.VAL] = 2.

# Border_______________________________________________________________________
BORDER = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.TYPE, deepcopy(DECO_TYPE)),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BORDER_W, {
        wk.LIMIT: (1, 9999),
        wk.PAGE_INCR: 10,
        wk.TIPPER: make_text_tip,
        wk.VAL: 4.,
        wk.WIDGET: Slider
    }),
    (ok.SOFTEN, deepcopy(BLUR)),
    (ok.BLUR, deepcopy(BLUR)),
    (ok.NLS, deepcopy(NET_LINE)),
    (ok.NET_LINE_W, net_line_w),
    (ok.SEED, deepcopy(SEED)),
    (ok.OBEY_MARGINS, deepcopy(OBEY_MARGINS)),
    (ok.IDR, deepcopy(IDR)),
    (ok.GRADIENT, deepcopy(GRADIENT)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
    (ok.PATTERN, deepcopy(PATTERN)),
    (ok.BRW, deepcopy(BBF)),
    (ok.PER, deepcopy(PER))
])
BORDER[ok.SOFTEN][wk.RANDOM_Q] = 1., 3.,
BORDER[ok.COLOR_1][wk.VAL] = 127, 127, 127
BORDER[ok.TYPE][wk.FUNCTION] = get_border_type_list
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Caption______________________________________________________________________
CAPTION = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.TYPE, deepcopy(CAPTION_TYPE)),
    (ok.JUSTIFICATION, deepcopy(JUSTIFICATION)),
    (ok.TEXT, deepcopy(TEXT)),
    (ok.LTR, deepcopy(LTR)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.FONT_SIZE, deepcopy(FONT_SIZE)),
    (ok.START_NUMBER, {
        wk.LIMIT: (-sys.maxint, sys.maxint),
        wk.PAGE_INCR: 100,
        wk.TOOLTIP: Tip.START_NUMBER,
        wk.TIPPER: make_text_tip,
        wk.VAL: 1.,
        wk.WIDGET: Slider
    }),
    (ok.OCR, deepcopy(OCR)),
    (ok.FCR, deepcopy(FCR)),
    (ok.MSS, deepcopy(MSS)),
    (ok.PER, deepcopy(PER))
])

CAPTION[ok.FCR][wk.SUB][ok.COLOR_1][wk.TOOLTIP] = "Text Color"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Fringe_______________________________________________________________________
FRINGE = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.TYPE, deepcopy(DECO_TYPE)),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.CONTRACT, deepcopy(CONTRACT)),
    (ok.COLOR_COUNT, {
        wk.LIMIT: (1, 6),
        wk.PAGE_INCR: 1,
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.COLOR_COUNT,
        wk.VAL: 1.,
        wk.WIDGET: Slider
    }),
    (ok.BLUR, deepcopy(BLUR)),
    (ok.NLS, deepcopy(NET_LINE)),
    (ok.NET_LINE_W, net_line_w),
    (ok.SEED, deepcopy(SEED)),
    (ok.OCR, deepcopy(OCR)),
    (ok.IDR, deepcopy(IDR)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.COLOR_6, {
        wk.BUTTON_COUNT: 6,
        wk.TIPPER: make_rainbow_count_tip,
        wk.VAL: (
            (0, 0, 0),
            (51, 51, 51),
            (102, 102, 102),
            (153, 153, 153),
            (204, 204, 204),
            (255, 255, 255)
        ),
        wk.WIDGET: Rainbow
    }),
    (ok.GRADIENT, deepcopy(GRADIENT)),
    (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
    (ok.PATTERN, deepcopy(PATTERN)),
    (ok.BRW, deepcopy(BBR1)),
    (ok.FRW, deepcopy(BFR1)),
    (ok.PER, deepcopy(PER))
])
FRINGE[ok.TYPE][wk.FUNCTION] = get_fringe_type_list
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Image__________________________________________________________
IMAGE = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.JUSTIFICATION, deepcopy(JUSTIFICATION)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.FLIP_R, deepcopy(FLIP_R)),
    (ok.IRRW, deepcopy(IRRW)),
    (ok.MRW, deepcopy(MBF)),
    (ok.PER, deepcopy(PER))
])
IMAGE[ok.IRRW][wk.SUB][ok.IMAGE_CHOICE][wk.SUB][ok.TYPE][
    wk.VAL] = ok.LOOP_X
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Line_________________________________________________________________________
LINE = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.LINE_W, {
        wk.LIMIT: (1, 9999),
        wk.PAGE_INCR: 2,
        wk.TIPPER: make_text_tip,
        wk.VAL: 2.,
        wk.WIDGET: Slider
    }),
    (ok.HARDNESS, deepcopy(HARDNESS)),
    (ok.BLUR, deepcopy(BLUR)),
    (ok.OBEY_MARGINS, deepcopy(OBEY_MARGINS)),
    (ok.CBR, deepcopy(CBR)),
    (ok.BRW, deepcopy(BBF)),
    (ok.PER, deepcopy(PER))
])

# Plaque_______________________________________________________________________
PLAQUE = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.TYPE, deepcopy(DECO_TYPE)),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BLUR, deepcopy(BLUR)),
    (ok.NLS, deepcopy(NET_LINE)),
    (ok.NET_LINE_W, net_line_w),
    (ok.SEED, deepcopy(SEED)),
    (ok.OBEY_MARGINS, deepcopy(OBEY_MARGINS)),
    (ok.IDR, deepcopy(IDR)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.GRADIENT, deepcopy(GRADIENT)),
    (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
    (ok.PATTERN, deepcopy(PATTERN)),
    (ok.MRW, deepcopy(MBR)),
    (ok.FRW, deepcopy(BFR1)),
    (ok.PER, deepcopy(PER))
])
PLAQUE[ok.TYPE][wk.FUNCTION] = get_plaque_type_list
PLAQUE[ok.COLOR_1][wk.VAL] = 255, 255, 255
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Shift________________________________________________________________________
SHIFT = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.OFFSET_X, deepcopy(MAX_POLAR_X)),
    (ok.OFFSET_Y, deepcopy(MAX_POLAR_Y)),
    (ok.WIDTH_MOD, deepcopy(MAX_POLAR_X)),
    (ok.HEIGHT_MOD, deepcopy(MAX_POLAR_Y)),
    (ok.JITTER_X, deepcopy(MAX_POSITIVE_X)),
    (ok.JITTER_Y, deepcopy(MAX_POSITIVE_Y)),
    (ok.JITTER_W, deepcopy(MAX_POSITIVE_X)),
    (ok.JITTER_H, deepcopy(MAX_POSITIVE_Y)),
    (ok.SEED, deepcopy(SEED)),
    (ok.PER, deepcopy(PER))
])

for i in (ok.JITTER_X, ok.JITTER_W, ok.OFFSET_X, ok.WIDTH_MOD):
    SHIFT[i].update({wk.AXIS: 'x'})

for i in (ok.HEIGHT_MOD, ok.JITTER_H, ok.JITTER_Y, ok.OFFSET_Y):
    SHIFT[i].update({wk.AXIS: 'y'})

set_issue(SHIFT, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

for i in (BORDER, CAPTION, FRINGE, IMAGE, LINE, PLAQUE):
    set_issue(i, (), vo.MATTER, NO_MATTER)
