#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import Signal as si, Widget as fw
from roller_constant_key import (
    Button as bk,
    Group as gk,
    Item as ie,
    Model as md,
    ModelList as ml,
    Step as sk,
    Widget as wk
)
from roller_model_nexus import CLASS_MODEL
from roller_one import enumerate_name
from roller_one_extract import get_model_branch
from roller_one_the import The
from roller_one_tip import Tip
from roller_port_define_model import PortNewModel, PortReviseModel
from roller_port_rename import PortRename
from roller_port_step import PortModelStep
from roller_port_tree import (
    DEFAULT_MODEL, MAIN_TREE_STEP, create_model_insert_d
)
from roller_view_step import get_parent_node, make_panel_key, translate_to_id
from roller_widget import set_widget_attr
from roller_widget_box import Box as boxer
from roller_widget_button import (
    Button,
    MoveDownButton,
    MoveUpButton,
    NewModelButton,
    RenameButton,
    ReviseButton
)
from roller_widget_combo import ComboBox
from roller_widget_row import WidgetRow
from roller_widget_table import create_table
from roller_widget_tree import CHOICE_COLOR, TreeViewList, rename_item
import gtk

MANAGE = 'manage'
MODEL_STEP = "Model Step…"
MODEL_TYPE = "Model Type"
MODIFY = 'modify'
NEED_COUNT = 2, 2, 1, 1, 1, 1
SORT = 'sort'
SORT_KEY = SORT_UP, SORT_DOWN = "Up", "Down"
MANAGE_KEY = NEW, DELETE = "New…", "Delete"
BUTTON_CHANGE = DELETE, NEW, SORT_DOWN, SORT_UP


def collect_active_model(d):
    """
    Find Model name in the active dict.

    d: dict
        active dict
        {panel step key: group dict}

    Return: set
        {model name, ...}
    """
    # Model panel key, without a branch, length , '1'
    # Model name position in panel key, '0'
    return {i[0] for i in d if len(i) == 1}


def get_model_list():
    """
    Fetch a list of available Model type.

    Return: list
        of Model type
    """
    return md.MODEL_TYPE_LIST


class ModelList(gtk.Alignment, object):
    """Is a Widget group for managing Model and Model step."""
    change_signal = None
    has_table_label = False

    def __init__(self, **d):
        super(gtk.Alignment, self).__init__()
        set_widget_attr(self, d)

        # Use to return focus to a responsible Button.
        self.widget = None

        # [(model name, Model type)]
        # Each item in the list is for a named Model. A
        # Model is either in the Shelf or is active.
        self._model_def = []

        self.view_value = [None, None]
        self._list_buttons = []
        self._branch_step_d = {}
        self._value = {ml.MODEL_DEF: [], ml.SHELVED: {}, ml.ACTIVE: {}}

        self.dialog = None
        d[wk.SCROLL] = d[wk.CHANGELESS] = True
        w = fw.MARGIN // 2
        hbox = gtk.HBox()
        relay = d[wk.RELAY][:]
        self._parent_node = get_parent_node(self.nav_k)
        self._parent_node.connect(si.UPDATE_TREE, self.on_update_tree)

        # Table Widget keyword arguments, 'e'
        e = {}

        e.update(d)

        # container for the Table Widget, 'vbox'
        vbox = boxer(padding=(0, 0, 0, w))

        d[wk.RELAY].insert(0, self.on_active_tree_change)
        d.update({wk.COLOR: CHOICE_COLOR, wk.MINIMUM_W: 70})

        d[wk.HEADER] = "Active:"
        self._active_tree = TreeViewList(**d)
        model_type_relay = d[wk.RELAY] = relay[:]

        model_type_relay.insert(0, self.on_model_type_change)
        self._active_tree.treeview.set_tooltip_text(Tip.MODEL_LIST_TREE)

        # Build a Model Table.
        e['q'] = (
            (
                MODEL_TYPE,
                ComboBox,
                dict(
                    e,
                    key=MODEL_TYPE,
                    function=get_model_list,
                    relay=model_type_relay
                )
            ),
            (
                "",
                WidgetRow,
                dict(
                    e,
                    key=MANAGE,
                    relay=relay + [self._verify_button],
                    sub=OrderedDict([
                        (bk.NEW_MODEL, {
                            wk.DIALOG: PortNewModel,
                            wk.TOOLTIP: Tip.MODEL_LIST_NEW,
                            wk.WIDGET: NewModelButton
                        }),
                        (bk.DEL_MODEL, {
                            wk.TEXT: DELETE,
                            wk.TOOLTIP: Tip.DELETE_MODEL,
                            wk.WIDGET: Button
                        })
                    ])
                )
            ),
            (
                "",
                WidgetRow,
                dict(
                    e,
                    key=MODIFY,
                    relay=relay + [self._verify_button],
                    sub=OrderedDict([
                        (bk.RENAME, {
                            wk.DIALOG: PortRename,
                            wk.TOOLTIP: Tip.RENAME_MODEL,
                            wk.WIDGET: RenameButton
                        }),
                        (bk.REVISE, {
                            wk.DIALOG: PortReviseModel,
                            wk.TOOLTIP: Tip.REVISE_MODEL,
                            wk.WIDGET: ReviseButton
                        })
                    ])
                )
            ),
            (
                "",
                WidgetRow,
                dict(
                    e,
                    key=SORT,
                    relay=relay + [self._verify_button],
                    sub=OrderedDict([
                        (bk.MOVE_UP, {
                            wk.TOOLTIP: Tip.MOVE_UP,
                            wk.WIDGET: MoveUpButton
                        }),
                        (bk.MOVE_DOWN, {
                            wk.TOOLTIP: Tip.MOVE_DOWN,
                            wk.WIDGET: MoveDownButton
                        })
                    ])
                )
            ),
            (
                "",
                Button,
                dict(
                    e,
                    key=MODEL_STEP,
                    text=MODEL_STEP,
                    tooltip=Tip.MODEL_STEP,
                    relay=relay + [self.on_model_step_action]
                )
            )
        )

        # dict of Widgets, 'd'
        d = create_table(vbox, **e)

        self._model_type_g = d[MODEL_TYPE]

        # the Delete Button index, '1'
        self._list_buttons = d[SORT].widget_q + \
            d[MANAGE].widget_q[1:] + d[MODIFY].widget_q

        d[MANAGE].get_g(bk.DEL_MODEL).relay.insert(0, self.on_delete_item)
        d[SORT].get_g(bk.MOVE_DOWN).relay.insert(0, self.move_sel_down)
        d[SORT].get_g(bk.MOVE_UP).relay.insert(0, self.move_sel_up)

        for x, i in enumerate(self._list_buttons):
            i.need_count = NEED_COUNT[x]

        # Assign self variable to prevent garbage collection.
        # New Button index, '0'
        self._new_button = d[MANAGE].widget_q[0]

        self._model_step_button = d[MODEL_STEP]

        hbox.add(vbox)
        hbox.pack_start(self._active_tree, expand=True)
        self.add(hbox)
        self._verify_button()

        # Connect event.
        self._active_tree.treeview.connect(
            'key_press_event', self.on_model_list_keypress
        )
        self._active_tree.treeview.get_selection().connect(
            'changed', self._verify_button
        )
        The.power.connect(si.PANEL_CHANGE, self.on_panel_change)
        The.power.connect(si.PANEL_CHANGE, self.on_active_tree_change)
        The.power.connect(si.RENAME, self.on_rename_action)
        The.power.connect(si.MODEL_NEW, self.make_new_model)
        The.power.connect(si.MODEL_REVISE, self.revise_model)

        # Do last.
        d[MODEL_TYPE].set_a(md.TABLE)

    def _add_model_to_active_tree(self, model_name):
        """
        Create an item for the active Model list from a Model's name.

        model_name: string or None
            a Model key
            Is the identity of the Model found in the 'self._model_def' list.
        """
        self._active_tree.append_item(model_name)
        self._verify_button()
        self._active_tree.select_item(len(self._active_tree.item_q))
        The.power.plug(si.MODEL_MOVE, None)

    def _delete_model_def_item(self, dead_name):
        """
        Remove an item from the Model definition list.

        dead_name: string
            Is the name of the Model that is to be removed.
        """
        for x, i in enumerate([i[0] for i in self._model_def]):
            if i == dead_name:
                self._model_def.pop(x)
                break

    def _fix_model_name(self, model_name, model_type):
        """
        A Model name is not allowed to contain a comma or a slash.

        model_name: string
        Return: string
            fixed Model name
        """
        n = model_type if model_name is None else model_name

        # Remove reserved step key path character.
        for i in (",", "/", "\\"):
            n = n.replace(i, "")

        # Any default Steps Node item are reserved
        # word as a Node item is also a key.
        # list of default item matched with the model name, 'q'
        if any([i for i in gk.STEPS_DEFAULT if i == n]):
            # Change the name to a different key.
            n += "_"

        # list of Model names, 'q'
        q = [i[ml.NAME_INDEX] for i in self._model_def]
        q += [gk.MODEL]

        if any([i for i in q if i == n]):
            n = enumerate_name(n, q)
        return n

    def _make_model_branch(self, model_name, model_type):
        """
        Add a Model to the main NodePanel.

        model: Model
            to add to the navigation tree

        model_name: string
            Is an item key for the Steps Node.
        """
        step_q = []

        # Create a Model definition list, 'model_def', for the insertion dict.
        # Record active (visible) Model with model definition list.
        # (model name, model type) -> (string, string)
        model_def = []

        node_item_q = self._parent_node.get_item_list()[4:-1]
        model_def_name_q = [i[ml.NAME_INDEX] for i in self._model_def]

        for i in node_item_q:
            for name in self._active_tree.item_q:
                if name == i:
                    type_ = self._model_def[model_def_name_q.index(i)]
                    model_def += [(i, type_)]

        model_def += [(model_name, model_type)]

        for n, type_ in model_def:
            q = DEFAULT_MODEL[type_]
            step_q += [(n,) + i for i in q]

        d = create_model_insert_d(step_q, model_def)

        CLASS_MODEL[model_type](model_name)
        self._parent_node.emit(si.ADD_ITEM, (d, model_name))
        self._update_step_node(self.get_active_model_name_q())

        # The Model group changed.
        self.any_group.changed()

    def _rename_model_def_item(self, old_name, new_name):
        """
        Change the name of a Model stored in the Model definition list.

        old_name: string
        new_name: string
        """
        for x, q in enumerate(self._model_def):
            model_name, model_type = q
            if model_name == old_name:
                self._model_def[x] = new_name, model_type
                break

    def _update_branch_d(self, name_q):
        """
        Update the ModelList value.

        name_q: list
            [model name, ...]
        """
        # Maintain the branch dict for the getter.
        # Link directly with value dict for speed as this is an expensive op.
        self._branch_step_d.clear()

        for i in self.get_model_branch_q(name_q):
            # AnyGroup, 'a'
            a = The.helm.get_group(i)
            if a:
                if a.item.group_type in ('node', 'preset'):
                    self._branch_step_d[make_panel_key(i)] = a.value_d

        self.any_group.update_option_a(self.key, self.get_a())
        return name_q

    def _update_item_q(self, old_name, new_name):
        """
        Update the active tree's item list.

        old_name: string
            Remove from the item list.

        new_name: string
            Insert into the item list.
        """
        q = self._active_tree.item_q
        for x, name in enumerate(q):
            if name == old_name:
                q.pop(x)
                q.insert(x, new_name)

    def _update_model_def(self, name_q):
        """
        Update the model definition list.

        name_q: list
            [model name, ...]
        """
        # Sort the model definition list.
        top_def = [
            q for n in name_q for q in self._model_def if n == q[ml.NAME_INDEX]
        ]
        off_def = [
            q for q in self._model_def if q[ml.NAME_INDEX] not in name_q
        ]

        # Empty the model definition list (Python 2.7).
        # Reference
        # stackoverflow.com/questions/1400608/how-to-empty-a-list
        # Python 3: list.clear()
        del self._model_def[:]

        for q in top_def + off_def:
            self._model_def += [q]

    def _update_active_tree(self, x, x1):
        """
        Update the active Model list after changing the order of a Model.

        x: int
            new position

        x1: int
            old position
        """
        n = self._active_tree.item_q[x1]

        self._active_tree.remove_x(x1)
        self._active_tree.insert_row(x, n)
        self._active_tree.select_item(x)
        The.power.plug(si.MODEL_MOVE, None)

    def _update_step_node(self, name_q):
        """
        Sort Model item in the Steps Node. Fix the Steps
        Node being out of sync with the active Model TreeViewList.

        name_q: list
            [model name, ...]
            of active Model
        """
        self._parent_node.sort_item_q(
            gk.STEPS_DEFAULT[:-1] + name_q + gk.STEPS_DEFAULT[-1:]
        )

    def _verify_button(self, *_):
        """Verify Button depending on the active TreeView state."""

        def disable_buttons():
            """
            Disable the dependent Buttons when there
            is no item selected in the ModelList.
            """
            for _g in self._list_buttons:
                _g.disable()
                _g.set_tooltip_text("")

        sel = self._active_tree.treeview.get_selection()

        if sel:
            # GtkTreeIter, 'iter_'
            iter_ = sel.get_selected()[1]

            if iter_:
                # The move and delete Buttons are dependent
                # on their selection state and the active TreeViewList size.
                x = self._active_tree.get_sel_row()
                for g in self._list_buttons:
                    if (
                        len(self._active_tree.item_q) >= g.need_count and
                        x is not None
                    ):
                        g.enable()
                        g.set_tooltip_text(g.tooltip_text)
                    else:
                        g.disable()
                        g.set_tooltip_text("")
            else:
                disable_buttons()
        else:
            disable_buttons()

    def get_a(self):
        """
        Get the value for data storage.

        Return: dict
            ModelList value
        """
        self._value[ml.MODEL_DEF] = self._model_def
        self._value[ml.ACTIVE] = self._branch_step_d
        self._value[ml.SHELVED] = The.shelf.get_shelf_d()
        return self._value

    def get_model_branch_q(self, name_q):
        """
        Collect an active Model navigation step key list.

        name_q: list
            of Model name found in the navigation tree

        Return: list
            [step key]
        """
        q = []

        for model_name in name_q:
            q += get_model_branch(model_name)
        return q

    def get_model_def(self):
        """
        Fetch the Model definition list.

        Return: list
            as requested
        """
        return self._model_def[:]

    def get_active_model_name_q(self):
        """
        Make a list of active Model name.

        Return: list
            [model name, ...]
        """
        return self._active_tree.item_q[:]

    def get_model_type_item(self):
        """
        Fetch the Model type active in its ComboBox.

        Return: list
            as requested
        """
        return self._model_type_g.get_a()

    def get_selected_name(self):
        """
        From the active Model listing, return the name with the selection.

        Return: string or None
            the selected Model's name
        """
        x = self._active_tree.get_sel_row()
        if x is not None:
            return self._active_tree.item_q[x]

    def make_new_model(self, sender, d):
        """
        Respond to user accept action for the New Model dialog.

        sender: Power
        d: dict
            {branch key, boolean selection value}
        """
        model_type = self._model_type_g.get_a()
        model_name = self._fix_model_name(None, model_type)

        self._add_model_to_active_tree(model_name)
        self._model_def.append((model_name, model_type))
        self._make_model_branch(model_name, model_type)

        # panel step key, root only, 'root
        root = model_name,

        # Convert the selected step option to panel step key, branch only.
        for i, a in d.items():
            if a:
                q = tuple(reversed(i.split(",")))
                panel_k = root + q
                The.shelf.set_step(
                    panel_k, The.preset.get_default_value(panel_k[-1])
                )

        self.on_model_step_action(self._model_step_button)

    def move_sel_down(self, g):
        """
        Move a selection down one line in the active TreeViewList.
        If the selection row 'x' is at the bottom of the list,
        then the item rotates to the top of the list.

        g: Button
            Is responsible.
        """
        x = x1 = self._active_tree.get_sel_row()
        a = len(self._active_tree.item_q)
        x += 1

        if x == a:
            x = 0

        self._update_active_tree(x, x1)
        g.widget.grab_focus()
        self._update_step_node(self.get_active_model_name_q())
        The.power.plug(si.PANEL_CHANGE, None)

    def move_sel_up(self, g):
        """
        Move a selection up one line in the TreeView.
        If selection row 'x' is at the top of the list,
        then the item rotates to the bottom of the list.

        g: Button
            Is responsible
        """
        x = x1 = self._active_tree.get_sel_row()
        x -= 1

        if x < 0:
            x = len(self._active_tree.item_q) - 1

        self._update_active_tree(x, x1)
        g.widget.grab_focus()
        self._update_step_node(self.get_active_model_name_q())
        The.power.plug(si.PANEL_CHANGE, None)

    def on_delete_item(self, *_):
        """Delete a row in the active TreeViewList."""
        x = self._active_tree.get_sel_row()
        if x is not None:
            n = self._active_tree.item_q[x]
            sel = self._active_tree.treeview.get_selection()
            if sel:
                self._active_tree.remove_x(x)
                self._verify_button()
                self._new_button.widget.grab_focus()

                model_id = The.model_id.get_id(n)
                model = The.model_id.get_model(model_id)

                self._parent_node.remove_named_item(n)
                self._delete_model_def_item(n)
                The.shelf.remove_model(n)
                The.helm.remove_model(model_id)
                model.die()
                The.power.plug(si.PANEL_CHANGE, None)

    def on_model_list_keypress(self, _, a):
        """
        Use to catch a Delete keypress.

        a: GTK Event
            of keypress
        """
        n = gtk.gdk.keyval_name(a.keyval)
        if len(self._active_tree.item_q):
            if n == 'Delete':
                return self.on_delete_item()

    def on_active_tree_change(self, *_):
        """Update the sensitivity of the Model Step Button."""
        self._model_step_button.set_sensitive(bool(self._model_def))

    @staticmethod
    def on_model_type_change(g):
        """
        Respond to a Model Type change event.

        g: ComboBox
            Is responsible.
        """
        k = g.get_a()
        if k in Tip.MODEL_LIST_TYPE:
            g.set_tooltip_text(Tip.MODEL_LIST_TYPE[k])

    def on_model_step_action(self, g):
        """
        Respond to a Model Step Button click by opening a Model Step Window.

        g: Button
            Is Model Step.
        """
        self.widget = g
        self.dialog = PortModelStep
        self.roller_win.bring_dialog(self)

    def on_panel_change(self, _, arg):
        """
        The branch dict has active Model. The dict
        is dependent on AnyGroup initialization.

        _: Power
            Sent the Signal.

        arg: None
        """
        # active Model name list, 'name_q'
        name_q = self.get_active_model_name_q()

        self._update_branch_d(name_q)
        self._update_model_def(name_q)
        self._update_step_node(name_q)

    def on_rename_action(self, _, name_q):
        """
        Respond to a Rename Button action.

        _: Power
        new_name: string
            Is the new name for the selected Model.
        """
        old_name, new_name = name_q

        if old_name != new_name:
            x = [i[ml.NAME_INDEX] for i in self._model_def].index(old_name)
            model_type = self._model_def[x][ml.TYPE_INDEX]
            new_name = self._fix_model_name(new_name, model_type)

            # Rename the Model in the ModelList.
            rename_item(self._active_tree, x, new_name)
            self._update_item_q(old_name, new_name)
            self._rename_model_def_item(old_name, new_name)

            # Rename the Model in the parent Node.
            item = self._parent_node.get_named_item(old_name)

            self._parent_node.rename_item(old_name, new_name)
            item.rename(new_name)

            # Rename the item in the Model's Node branch.
            item.label.set_label_value(new_name)

            # Update the Model Id dict.
            The.model_id.rename(old_name, new_name)

            # Update the active branch dict.
            The.power.plug(si.PANEL_CHANGE, None)

            # Rename layer.
            The.power.emit(si.MODEL_RENAME, (old_name, new_name))

    def on_update_tree(self, sender, arg):
        """
        Respond to a navigation tree structure update signal.
        Remove item and Node from the tree that is no longer used.
        Add new item and Node to the tree from a new step key list.

        sender: Node
        arg: tuple
            ([new step key], [(model name, model type)])
        """
        self._active_tree.reset()
        for model_name, model_type in arg[1]:
            self._add_model_to_active_tree(model_name)

    def revise_model(self, sender, arg):
        """
        Alter the steps available for a Model. Respond to user
        accept action from the Revise Model dialog.

        sender: Power
        arg: tuple
            (
                {branch key: boolean selection value},
                [previous branch key, ...],
                model name
            )

        Return: True
            Let GTK know that the signal was processed.
        """
        def _remove(_node, _nav_k, _item_k):
            """
            Remove an item from a Node and its layer output.

            _node: Node
                Has item to remove.

            _nav_k: tuple
                Is the navigation step key of the item to remove.

            _item_k: string
                Is the item's display value.
            """
            if any_group:
                # Remove layer output.
                any_group.emit(si.DISAPPEAR, None)

            _node.remove_named_item(_item_k)
            The.helm.remove_step(_nav_k)

        d, q, model_name = arg

        # Create a list of navigation step key for the selection option.
        model_id = The.model_id.get_id(model_name)

        # root of step key
        nav_root = model_id,
        panel_root = model_name,

        for i, a in d.items():
            if a or i in q:
                branch = i.split(",")
                branch = (branch[1],) + (branch[0],)
                nav_k = nav_root + branch
                panel_k = panel_root + branch

                if not a:
                    # Remove the step from the Model.
                    if The.shelf.finds(panel_k):
                        # The step is shelved.
                        The.shelf.remove_step(panel_k)
                    else:
                        # The step is visible.
                        any_group = The.helm.get_group(nav_k)
                        node = get_parent_node(nav_k)

                        _remove(node, nav_k, any_group.item.key)

                        # Remove Node to Node item when the branch is empty.
                        if not node.get_label_q():
                            parent_node = get_parent_node(node.nav_k)
                            _remove(
                                parent_node,
                                node.nav_k,
                                node.any_group.item.key
                            )
                elif i not in q:
                    # Make the step available. Add the step to the Shelf.
                    The.shelf.set_step(
                        panel_k, The.preset.get_default_value(panel_k[-1])
                    )
        self._update_branch_d(self._parent_node.get_label_q()[4:-1])

    def set_a(self, d):
        """
        Load the active Model list and the Shelf from a dictionary.

        d: dict
            ModelList value
            {
                ml.MODEL_DEF: model def list,
                ml.ACTIVE: SuperPreset,
                ml.SHELVED: SuperPreset
            }

            SuperPreset
            {panel key: Preset value dict}

            A panel step key has the Model name at index zero.
            (model name, label, ...)

            Preset value dict
            {Option key: value}
        """
        # Before loading a ModelList Preset, clear the previous Model(s).
        while self._active_tree.item_q:
            self._active_tree.select_item(0)
            self.on_delete_item()

        # Clear list.
        del self._model_def[:]

        # Check Model compatibility.
        for model_name, model_type in d[ml.MODEL_DEF]:
            if model_type in get_model_list():
                # Is a valid Model type.
                self._model_def += [(model_name, model_type)]

        load_d = d[ml.ACTIVE]

        The.shelf.set_d(d[ml.SHELVED], self._model_def)

        if load_d:
            load_step_q = load_d.keys() + MAIN_TREE_STEP
            active_model = collect_active_model(load_d)

            # list of Model that are referenced in the active dict, 'model_def'
            model_def = []

            for model_name, model_type in self._model_def:
                if model_name in active_model:
                    self._add_model_to_active_tree(model_name)

                    # Add a Model Preset step key.
                    load_step_q += [(model_name,) + (ie.PRESET,)]
                    model_def += [(model_name, model_type)]

            if model_def:
                # Update the navigation tree.
                get_parent_node(sk.STEPS).emit(
                    si.UPDATE_TREE, (load_step_q, model_def)
                )

                load_d = translate_to_id(load_d)
                The.preset.load_super(load_d)
        The.power.plug(si.PANEL_CHANGE, None)

    def set_view_value(self, x, a):
        """
        ModelList remembers its parent Node value as this state
        is used to detect background change by Model Maya.

        x: int
            Plan or Work index

        a: dict
            ModelList value
            not used
        """
        # Ignore the Node Item at the top of the list, '1'.
        self.view_value[x] = self._parent_node.get_item_list()[4:-1]
