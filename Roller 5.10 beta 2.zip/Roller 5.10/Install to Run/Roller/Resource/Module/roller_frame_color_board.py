#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Lucid, select_frame
from roller_view_hub import color_layer_default, color_selection_default
from roller_view_real import add_wip_layer, get_overlay, get_light
import gimpfu as fu

pdb = fu.pdb


def do_color(v, maya):
    """
    Make a color layer.

    v: View
    maya: Maya
    Return: layer
        with color
    """
    pdb.gimp_selection_none(v.j)

    d = maya.value_d
    a = maya.super_maya
    z = add_wip_layer(v, "Overlay", a.group, offset=get_light(a))

    color_layer_default(z, d[ok.COLOR_1])
    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: ColorBoard
    Return: layer
        with the frame
    """
    j = v.j
    d = maya.value_d[ok.WRW][ok.WRAP_CB]
    z = add_wip_layer(
        v,
        "Wrap",
        maya.group,
        offset=get_light(maya) + get_overlay(maya)
    )

    select_frame(j, maya.cast.matter, d[ok.WIDTH], d[ok.TYPE])
    color_selection_default(z, (180, 180, 180))
    return z


class ColorBoard(Lucid):
    """Create a color border with optional transparency around material."""
    wrap_k = ok.WRAP_CB

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            option owner

        super_maya: Maya
            deco type

        k_path: tuple
            Is the path to the Frame Button.
        """
        Lucid.__init__(
            self,
            any_group,
            super_maya,
            k_path,
            do_matter,
            do_color,
            ok.OVERLAY_CF
        )
