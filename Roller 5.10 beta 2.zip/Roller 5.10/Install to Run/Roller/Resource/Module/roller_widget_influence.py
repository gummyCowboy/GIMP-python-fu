#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color as co, GradientLight as gl, Widget as fw
from roller_constant_key import Option as ok, Widget as wk
from roller_fu_mode import get_influence_mode
from roller_one_the import The
from roller_widget_box import Eventful
from roller_widget_combo import ComboBox
from roller_widget_label import Label
from roller_widget_slider import RandomSlider
from roller_widget_table import get_darker_color
import gtk


class InfluenceTable(gtk.Alignment, object):
    """Access Influence option. """

    def __init__(self, **d):
        super(gtk.Alignment, self).__init__()
        self.set(0, 0, 1, 1)

        d[wk.ANY_GROUP].widget_d = {}
        self._widget_d = {}

        # header, '1', and one row for each Influence type
        colored_row = len(gl.INFLUENCE_KEY) + 2

        self._make_preset_table(
            self._make_influence_table(colored_row, **d),
            colored_row,
            **d
        )
        d[wk.ANY_GROUP].widget_d.update(self._widget_d)

    def _make_influence_table(self, colored_row, **d):
        """
        Create a GTK Table having a Influence type
        option at the top of Port's VBox.

        colored_row: int
            the number of rows in both tables

        d: dict
            Has init value.
        """
        w = fw.MARGIN

        # header, '1', and one row for each Influence type
        row = len(gl.INFLUENCE_KEY) + 1

        color = d[wk.COLOR]
        opacity_d = {
            wk.LIMIT: (.0, 100.), wk.PRECISION: 1, wk.RANDOM_Q: (.0, 100.)
        }
        mode_d = {wk.FUNCTION: get_influence_mode}

        opacity_d.update(d)
        mode_d.update(d)

        # column count, '3'
        table = gtk.Table(row, 3)

        table.set_row_spacings(1)
        self.set_padding(0, 0, w, w)

        for r in range(row):
            color = get_darker_color(color, colored_row)
            color1 = color, color, co.MAX_COLOR
            box_q = [Eventful(color1) for _ in range(3)]

            if r == 0:
                # Table header
                box_q[1].add(gtk.Label("\t\t\tMode\t\t\t"))
                box_q[2].add(gtk.Label("Opacity"))

            else:
                # Influence option
                k = gl.INFLUENCE_KEY[r - 1]
                self._widget_d[k] = InfluenceRow(
                    k, box_q, mode_d, opacity_d
                )

            table.attach(box_q[0], 0, 1, r, r + 1)
            table.attach(box_q[1], 1, 2, r, r + 1)
            table.attach(box_q[2], 2, 3, r, r + 1)

        self.add(table)
        d[wk.ITEM].vbox.add(self)
        return color

    def _make_preset_table(self, a, colored_row, **d):
        """
        Create a GTK Table having an Influence Preset
        option at the bottom of Port's VBox.

        a: tuple
            GIMP color

        colored_row: int
            the number of rows in both tables

        d: dict
            Has init value.
        """
        alignment = gtk.Alignment(0, 0, 1, 1)

        alignment.set_padding(0, 0, fw.MARGIN, fw.MARGIN)

        color = get_darker_color(a, colored_row)
        color1 = color, color, co.MAX_COLOR
        e = dict(d, key=ok.PRESET)

        # row count, '1'; column count, '2'
        table = gtk.Table(1, 2)

        table.set_row_spacings(1)

        box_q = [Eventful(color1) for _ in range(2)]

        box_q[0].add(gtk.Label("Influence Preset"))

        self._preset = d[wk.ANY_GROUP].widget_d[ok.PRESET] = The.preset(**e)

        box_q[1].add(self._preset)
        table.attach(box_q[0], 0, 1, 0, 1)
        table.attach(box_q[1], 1, 2, 0, 1)
        alignment.add(table)
        d[wk.ITEM].vbox.add(alignment)

    def get_a(self):
        """
        Fetch the value of the Influence Table.

        Return: dict
            Influence value
        """
        return {k: a.get_a() for k, a in self._widget_d.items()}

    def set_a(self, d):
        """
        Set the value of the Influence Table.

        d: dict
            Influence value
        """
        e = self._widget_d
        for k, a in d.items():
            if k in e:
                e[k].set_a(a)


class InfluenceRow:
    """Is a Row having a Paint Mode and Opacity Widget."""

    def __init__(self, k, box_q, mode_d, opacity_d):
        """
        Create a Paint Mode Widget and an Opacity
        Widget for a Table's row Eventful.

        k: string
            Influence option key

        box_q: list
            of Eventful for adding the Mode and Opacity options

        mode_d: dict
            Is the Mode Widget's init dict.

        opacity_d: dict
            Is the Opacity Widget's init dict.
        """
        w = fw.MARGIN
        label = Label(text=k.split(",")[0])
        self.mode = ComboBox(**mode_d)
        self.opacity = RandomSlider(**opacity_d)

        box_q[0].add(label)
        box_q[1].add(self.mode)
        box_q[2].add(self.opacity)
        label.set_padding(0, 0, 0, w)
        self.mode.set_padding(0, 0, w, 0)

    def get_a(self):
        """
        Return the value of the Row Widget.

        Return: dict
            Influence Row value
        """
        return {
            ok.MODE: self.mode.get_a(),
            ok.OPACITY: self.opacity.get_a()
        }

    def set_a(self, d):
        """
        Set the value of the Row Widget.

        d: dict
            Influence Row value
        """
        if isinstance(d, dict):
            self.mode.set_a(d[ok.MODE])
            self.opacity.set_a(d[ok.OPACITY])
