#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import (
    MetalCanvas, make_canvas_frame_sel, do_metal_sel
)
from roller_fu import (
    add_layer,
    load_selection,
    select_item,
    select_opaque,
    select_rect
)
from roller_one_rect_table import RectTable
from roller_view_hub import color_selection_default
import gimpfu as fu

pdb = fu.pdb


def do_filler(v, maya):

    """
    Make the frame.

    v: View
    maya: RadWave
    Return: layer
        with the frame
    """
    def _add():
        """Add a layer to the bottom of the Maya group."""
        return add_layer(
            j,
            group.name + " Filler",
            parent=group,
            offset=len(group.layers)
        )

    j = v.j
    d = maya.value_d[ok.WRW][ok.FILLER_RW]
    super_ = maya.super_maya
    group = super_.group

    # layer for the wire, 'z'
    z = _add()

    sel = make_canvas_frame_sel(v, d)

    pdb.gimp_selection_none(j)

    width, height = map(float, v.view_size)
    w1 = d[ok.LINE_W]
    row, column = int(d[ok.ROW]), int(d[ok.COLUMN])

    if w1:
        grid = RectTable(v.wip.rect, row, column).table

        for r in range(1, row):
            select_rect(
                j, .0, grid[r][0].y, width, w1, option=fu.CHANNEL_OP_ADD
            )
        for c in range(1, column):
            select_rect(
                j, grid[0][c].x, .0, w1, height, option=fu.CHANNEL_OP_ADD
            )

    color_selection_default(z, (0, 0, 0))
    pdb.gimp_selection_none(j)

    # phase, '1.'; smeared wave type, '0'; no reflective, '0'
    pdb.plug_in_waves(j, z, d[ok.WAVE_AMPLITUDE], 1., d[ok.WAVELENGTH], 0, 0)

    pdb.gimp_selection_none(j)

    # mid-pinch, '.0'; radius, '2.'
    pdb.plug_in_whirl_pinch(j, z, d[ok.WHIRL], .0, 2.)

    select_item(z)
    pdb.gimp_image_remove_layer(j, z)

    # layer for the combined frame, 'z'
    z = _add()

    if sel:
        load_selection(j, sel, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, sel)

    select_opaque(super_.cast.matter, option=fu.CHANNEL_OP_SUBTRACT)
    select_rect(v.j, *v.wip.rect, option=fu.CHANNEL_OP_INTERSECT)
    return do_metal_sel(v, z, maya.value_d[ok.WRW][ok.WRAP])


class RadWave(MetalCanvas):
    """Is a metallic frame with wavy wire filling the canvas."""

    def __init__(self, any_group, super_maya, k_path):
        """
        q: tuple
            Metal spec

        d: dict
            Metal spec
        """
        MetalCanvas.__init__(
            self,
            any_group,
            super_maya,
            k_path,
            do_filler,
            (ok.WRW, ok.FILLER_RW)
        )
