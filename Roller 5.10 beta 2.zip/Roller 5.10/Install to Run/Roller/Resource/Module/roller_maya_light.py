#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Signal as si
from roller_constant_key import Option as ok, Step as sk
from roller_fu_mode import translate_mode
from roller_maya import NO_VOTE, check_matter
from roller_maya_build import SubBuild
from roller_fu import set_layer_attr
from roller_one_the import The
from roller_view_gradient_light import insert_gradient
from roller_view_real import mask_from_many_layer, mask_sub_maya


def do_matter(v, maya):
    """
    Make a Gradient Light layer at the top of a super Maya group.

    v: View
        not used

    maya: Light
    Return: layer
        with Gradient Light
    """
    return insert_gradient(maya.super_maya.group)


class Star(SubBuild):
    """
    Manage Gradient Light layer output. Is a super class for mask deployment.
    """
    issue_q = 'matter', 'mode', 'opacity'
    put = (check_matter, 'matter'),

    def __init__(self, any_group, super_maya, influence):
        """
        any_group: AnyGroup
            with a Gradient Light Influence

        super_maya: Maya
            Has control over the Light output.

        influence: string
            Influence type
        """
        self.influence = influence
        self._view_mode = self.view_value = self._view_opacity = None

        SubBuild.__init__(self, any_group, super_maya, NO_VOTE, do_matter)
        self.handle_d[
            The.power.connect(si.LIGHT_CHANGE, self.on_light_change)
        ] = The.power
        self.value_d = The.helm.get_group(sk.GRADIENT_LIGHT).value_d

    def do(self, v, is_change):
        """
        Manage layer output during a View run.

        v: View
        is_change: bool
            Is True when the super Maya has either matter or mask change.
        """
        d = self.value_d
        self.go = self.super_maya.go and d[ok.SWITCH]
        e = d[ok.IGR][ok.INFLUENCE][self.influence]
        mode, opacity = e[ok.MODE], e[ok.OPACITY]

        if self.go:
            if not self.matter:
                if opacity == .0:
                    self.is_mode = self.is_opacity = self.is_matter = False
                else:
                    # Matter is valid because the layer had been suppressed.
                    self.is_matter = True

            self.realize(v)
            if self.matter:
                if self.is_mode or self.is_opacity or self.is_matter:
                    m = set_layer_attr(
                        self.matter, translate_mode(mode), opacity
                    )
                    v.is_back += m
                if self.is_matter or is_change:
                    self.mask_light_layer()

        else:
            self.die(v)

        self.reset_issue()

        self.view_value = deepcopy(self.value_d)
        self._view_mode = mode
        self._view_opacity = opacity

    def on_light_change(self, *_):
        """Respond to Gradient Light change."""
        mode = opacity = None
        d = self.value_d

        if ok.IGR in d and ok.INFLUENCE in d[ok.IGR]:
            e = d[ok.IGR][ok.INFLUENCE][self.influence]
            mode, opacity = e[ok.MODE], e[ok.OPACITY]

        e = self.view_value

        if e:
            self.is_mode = self.is_opacity = self.is_matter = False

            for k in d:
                if k != ok.IGR:
                    if d[k] != e[k]:
                        self.is_matter = True
                        break
                else:
                    if (
                        ok.GRADIENT in d[k] and
                        d[k][ok.GRADIENT] != e[k][ok.GRADIENT]
                    ):
                        self.is_matter = True
                        break

            if opacity != self._view_opacity:
                self.is_opacity = True
            if mode != self._view_mode:
                self.is_mode = True
        else:
            self.is_mode = self.is_opacity = self.is_matter = True

    def reset(self):
        """
        Is called when the View image closes as during an image resize event.
        """
        self.view_value = None
        self.is_mode = self.is_opacity = self.is_matter = True


class Light(Star):
    """Manage Gradient Light layer output."""

    def __init__(self, *q):
        """
        q: tuple
            Star spec
        """
        Star.__init__(self, *q)

    def mask_light_layer(self):
        """
        Mask the Gradient Light layer from a super
        Maya 'matter' layer's alpha selection.
        """
        mask_sub_maya(self.super_maya.matter, self.matter)


class Lamp(Star):
    """
    Manage Gradient Light layer output for Maya having many mask source layer.
    """

    def __init__(self, any_group, super_maya, influence, mask_maya):
        """
        q: tuple
            Star spec
        """
        self.mask_maya = (super_maya,) + mask_maya
        Star.__init__(self, any_group, super_maya, influence)

    def mask_light_layer(self):
        """
        Mask the Gradient Light layer from alpha
        selection of the super Maya's 'matter' layer.
        """
        mask_from_many_layer([i.matter for i in self.mask_maya], self.matter)
