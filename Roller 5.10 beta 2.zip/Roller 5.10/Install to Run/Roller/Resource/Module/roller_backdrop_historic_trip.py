#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clone_layer,
    invert_and_desaturate,
    make_layer_group,
    merge_layer_group,
    set_saturation
)
from roller_maya_style import Style, make_background
from roller_one_gegl import emboss, spread, waterpixels
from roller_view_real import (
    add_sub_base_group, finish_style, insert_copy_above
)
from roller_view_hub import color_layer_default, get_mean_color
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: HistoricTrip
    Return: layer or None
        with style material
    """
    def _merge(_z, _n):
        """
        Merge a group and set its layer mode.

        _z: layer group
            to merge

        _n: string
            version number

        return: layer
            Is the result of the merge.
        """
        _z = merge_layer_group(_z)
        _z.mode = fu.LAYER_MODE_GRAIN_MERGE
        _z.name = "Grain Merge " + _n
        pdb.plug_in_colortoalpha(j, _z, (0, 0, 0))
        return _z

    # Is dependent.
    if maya.go:
        j = v.j
        d = maya.value_d
        parent = add_sub_base_group(v, maya)
        z = make_background(v, parent)
        key = maya.any_group.item.key
        bg_1 = clone_layer(z, n="Original #1")
        bg_2 = clone_layer(z, n="Original #3")
        group = make_layer_group(v.j, "WIP", parent=parent, z=z)
        group1 = make_layer_group(j, key + " WIP #2", parent=group, z=bg_1)
        z2 = clone_layer(bg_1, n="Difference #1")
        z2.mode = fu.LAYER_MODE_DIFFERENCE
        color = get_mean_color(z)
        loop_cnt = int(d[ok.ITERATIONS])
        spread_a = int(d[ok.SPREAD])

        for _ in range(loop_cnt):
            spread(z2, 0, amount_x=spread_a, amount_y=min(6, spread_a))

        group2 = make_layer_group(j, "Sub-Group", parent=group, z=bg_2)
        z2 = clone_layer(bg_2, n="Difference #2")
        z2.mode = fu.LAYER_MODE_DIFFERENCE

        for _ in range(loop_cnt):
            spread(z2, 0, amount_x=min(6, spread_a), amount_y=spread_a)

        color_layer_default(z, color)

        z1 = _merge(group1, "#1")
        z2 = _merge(group2, "#2")
        z = insert_copy_above(v, z2, parent.layers[0])

        dissolve_z = clone_layer(z, n="Dissolve")
        z.mode = fu.LAYER_MODE_HSV_VALUE

        emboss(z1, v.glow_ball.azimuth, 12, 1)
        emboss(z2, v.glow_ball.azimuth, 12, 1)
        waterpixels(z, size=int(d[ok.SUPERPIXEL_SIZE]))
        dissolve_z.mode = fu.LAYER_MODE_DISSOLVE
        dissolve_z.opacity = 50.
        blur_selection(dissolve_z, 1)

        z = insert_copy_above(v, dissolve_z, parent.layers[0])

        set_saturation(z, d[ok.SATURATION])
        merge_layer_group(group)

        z = merge_layer_group(parent, n="Despeckle")

        pdb.plug_in_despeckle(
            j, z,
            1,                  # radius
            0,
            -1,                 # black cut-off
            256                 # white cut-off
        )

        invert_and_desaturate(d[ok.IDR], z)
        return finish_style(z, "Historic Trip")


class HistoricTrip(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
