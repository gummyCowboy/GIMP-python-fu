#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Group as gk, Option as ok
from roller_def import get_default_value
from roller_fu import (
    add_layer_below,
    blur_selection,
    clear_selection,
    get_select_bounds,
    isolate_selection,
    load_selection,
    merge_layer,
    remove_z,
    select_item,
    select_rect,
    verify_layer
)
from roller_maya import (
    check_filler,
    check_filler_metal,
    check_matter,
    check_mix_basic,
    check_mix_overlay,
    check_mix_wrap,
    check_overlay,
    check_shadow,
    make_group_filler,
    make_group_kind,
    make_group_wrap
)
from roller_maya_blur_below import BlurBelow
from roller_maya_build import Build, SubBuild
from roller_maya_light import Lamp, Light
from roller_maya_noise import Noise, Noisy
from roller_maya_shadow import Shadow
from roller_one_gegl import emboss
from roller_one_the import The
from roller_view_hub import (
    color_layer, color_selection, set_fill_context_default
)
from roller_view_real import (
    OVERLAY,
    FILLER,
    LIGHT,
    add_base_layer,
    add_layer,
    add_wip_layer,
    clip_to_wip,
    do_rotated_layer,
    get_light,
    get_noise,
    mask_sel,
    mask_sub_maya
)
from roller_view_shadow import make_shadow
import gimpfu as fu

MAIN = 'main'
pdb = fu.pdb


def do_filler_wrap(v, maya):
    """
    Make an inner and outer metallic wrap.

    v: View
    maya: Frame
    Return: layer
        with the frame
    """
    d = maya.value_d[ok.WRW][maya.filler_k]
    e = maya.value_d[ok.WRW][ok.WRAP]
    j = v.j
    group = maya.group
    cast = maya.cast.matter

    # layer for the emboss, 'z'
    z = add_wip_layer(
        v, maya.kind, group, offset=get_light(maya) + get_noise(maya)
    )

    # Grow the selection for each frame part.
    select_item(cast)
    grow_frame(j, e[ok.WIDTH], e[ok.TYPE])

    # inner frame selection, 'sel'
    sel = pdb.gimp_selection_save(j)

    grow_frame(j, d[ok.WIDTH], e[ok.TYPE])

    # inner and filler frame selection, 'sel1'
    sel1 = pdb.gimp_selection_save(j)

    grow_frame(j, e[ok.WIDTH], e[ok.TYPE])

    # inner, filler, and outer selection, 'sel2'
    sel2 = pdb.gimp_selection_save(j)

    load_selection(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

    # outer frame selection, 'sel3'
    sel3 = pdb.gimp_selection_save(j)

    load_selection(j, sel1)
    load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

    # Cover-up the emboss on the inner and outer frame.
    grow_frame(j, 1., ff.ANGULAR)

    # filler selection
    if maya.filler_sel:
        pdb.gimp_image_remove_channel(v.j, maya.filler_sel)

    maya.filler_sel = pdb.gimp_selection_save(j)

    # Make an inner frame selection.
    load_selection(j, sel)
    select_item(cast, option=fu.CHANNEL_OP_SUBTRACT)
    load_selection(j, sel3, option=fu.CHANNEL_OP_ADD)

    z = do_metal_sel(v, z, e)

    for i in (sel, sel1, sel2, sel3):
        pdb.gimp_image_remove_channel(j, i)
    return z


def do_metal_wrap(v, maya):
    """
    Make a frame around material.

    v: View
    maya: Maya
    Return: layer
        with the frame
    """
    j = v.j
    d = maya.value_d[ok.WRW][ok.WRAP]
    group = maya.group

    # layer for the emboss, 'z'
    z = add_layer(
        j,
        group.name + " Wrap",
        parent=group,
        offset=get_light(maya) + get_noise(maya)
    )

    select_frame(j, maya.cast.matter, d[ok.WIDTH], d[ok.TYPE])
    return do_metal_sel(v, z, d)


def do_selection_material(v, maya, do_sel, embellish, n, is_clear=True):
    """
    Process the material for a frame.

    v: View
    maya: Maya
    do_sel: function
        Call to process selection.

    embellish: function
        Call to process the material layer.

    n: string
        layer name appendix
        Frame kind
        Prefix with a space character.

    is_clear: bool
        If True, then the cast's alpha selection
        is removed from the output layer.

    Return: layer or None
        with material
    """
    j = v.j
    model = maya.model
    super_ = maya.cast
    cast = super_.matter
    z = add_base_layer(v, maya.group, n=n)

    if super_.vote_type == MAIN:
        for k in super_.main_q:
            maya.k = k
            sel = model.get_image_sel(k)

            load_selection(j, sel)

            if cast.mask:
                pdb.gimp_image_select_item(
                    j, fu.CHANNEL_OP_INTERSECT, cast.mask
                )
            if not pdb.gimp_selection_is_empty(j):
                z = do_sel(v, maya, z)

    else:
        maya.k = super_.k

        select_item(cast)
        if not pdb.gimp_selection_is_empty(j):
            z = do_sel(v, maya, z)

    if is_clear:
        select_item(cast)
        clear_selection(z)

    z = verify_layer(z)

    if z:
        z = embellish(v, maya, z)
        z.name = z.parent.name + " " + n
    return z


def do_cast_shadow(v, maya):
    """
    Do the shadow process for the cast.

    v: View
    maya: Maya
        Frame type

    Return: layer or None
        with shadow
    """
    d = get_default_value(gk.SHADOW_1)
    frame = maya.super_maya
    cast = frame.cast
    group = cast.group.parent

    d.update(maya.value_d)
    return make_shadow(
        v,
        d,
        group,
        (cast.matter,),
        name=group.name + " Shadow",
        is_wrap=True
    )


def do_metal_frame(v, maya, make_pattern, k):
    """
    Make an embossed frame.

    v: View
    maya: Frame
    n: string
        group key
        Name output layer.

    k: string
        Filler Option key in the 'ok.WRW' row.

    Return: layer or None
        with the Frame
    """
    def _draw(_z):
        """
        Return a layer with pattern.

        _z: layer
            Maya matter layer
        """
        return do_rotated_layer(
            v,
            d[ok.WRW][k],
            make_pattern,
            maya.group,
            len(maya.group.layers) - 1
        )

    d = maya.value_d
    j = v.j
    cast = maya.cast.matter

    # Add a pattern layer to the bottom of the Maya's group layer, 'z'.
    z = add_wip_layer(v, "Frame", maya.group, offset=len(maya.group.layers))
    make_pattern_frame(j, cast, d, _draw, k)
    return do_metal_sel(v, z, d[ok.WRW][ok.WRAP])


def grow_frame(j, w, n):
    """
    Expand a frame selection depending on the Frame Type.

    j: GIMP image
        with selection

    w: float
        expansion amount

    n: string
        Frame Type
    """
    def _angular():
        pdb.gimp_context_set_antialias(0)
        for _ in range(int(w)):
            pdb.gimp_selection_grow(j, 1)

    def _rectangle():
        _is_sel, _x, _y, _x1, _y1 = get_select_bounds(j)
        if _is_sel:
            _x -= w
            _y -= w
            _w = _x1 + w - _x
            _h = _y1 + w - _y
            select_rect(j, _x, _y, _w, _h)

    def _rounded():
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_selection_grow(j, int(w))

    {ff.ANGULAR: _angular, ff.RECTANGLE: _rectangle, ff.ROUNDED: _rounded}[n]()


def make_canvas_frame_sel(v, d):
    """
    Make a selection border around the Canvas.

    v: View
    d: dict
        a Frame-subtype Preset

    Return: GIMP selection or None, state of selection
        Canvas border
    """
    w = d[ok.CFW]
    if w:
        j = v.j
        a = v.wip

        select_rect(j, *a.rect)
        select_rect(
            j,
            a.x + w, a.y + w,
            a.w - w - w, a.h - w - w,
            option=fu.CHANNEL_OP_SUBTRACT
        )
        return pdb.gimp_selection_save(j)


def make_pattern_frame(j, z, d, p, k):
    """
    Make a selection for frame material.

    j: GIMP image
        from View

    z: layer
        Maya matter

    d: dict
        Frame Preset

    p: function
        Call to make pattern.

    k: string
        Filler Option key in the 'ok.WRW' row.

    Return: state of selection
    """
    e = d[ok.WRW][ok.WRAP]
    d = d[ok.WRW][k]

    select_item(z)
    grow_frame(j, e[ok.WIDTH], e[ok.TYPE])

    sel = pdb.gimp_selection_save(j)

    grow_frame(j, d[ok.WIDTH], e[ok.TYPE])

    sel1 = pdb.gimp_selection_save(j)

    grow_frame(j, e[ok.WIDTH], e[ok.TYPE])

    sel2 = pdb.gimp_selection_save(j)

    load_selection(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

    # outer selection, 'sel3'
    sel3 = pdb.gimp_selection_save(j)

    z1 = p(z)

    load_selection(j, sel1)
    load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
    select_item(z1, option=fu.CHANNEL_OP_INTERSECT)
    remove_z(z1)

    # filler selection, 'sel4'
    sel4 = pdb.gimp_selection_save(j)

    # Make an inner frame selection.
    load_selection(j, sel)
    select_item(z, option=fu.CHANNEL_OP_SUBTRACT)

    # Combine selections.
    load_selection(j, sel3, option=fu.CHANNEL_OP_ADD)
    load_selection(j, sel4, option=fu.CHANNEL_OP_ADD)
    for i in (sel, sel1, sel2, sel3, sel4):
        pdb.gimp_image_remove_channel(j, i)


def mask_filler_layer(j, filler, sel):
    """
    Mask a filler group from a selection created by a frame.

    j: GIMP image
        View output

    filler: Filler
        Has filler and group layer.

    sel: GIMP selection
        to apply to layer
    """
    if sel:
        load_selection(j, sel)
        mask_sel(filler.matter)


def select_frame(j, z, w, n, is_cut=True):
    """
    Make a frame selection around a layer's alpha.

    j: GIMP image
        with selection

    z: layer
        Is the material that the frame surrounds.

    w: float
        expansion amount

    n: string
        Frame Type

    is_cut: bool
        If True, then the cast layer's selection
        is removed from the frame selection.
    """
    f = z.opacity
    z.opacity = 100.

    select_item(z)
    grow_frame(j, w, n)

    if is_cut:
        select_item(z, option=fu.CHANNEL_OP_SUBTRACT)
    z.opacity = f


def do_metal_sel(v, z, d):
    """
    Fill a selection with grey color and emboss it.

    v: View
    z: layer
        to fill
        WIP

    d: dict
        Metal Frame Preset

    Return: layer
        with material
    """
    j = v.j

    set_fill_context_default()

    if d[ok.EMBOSS]:
        n = z.name
        sel = pdb.gimp_selection_save(j)

        color_selection(z, (190, 190, 190))
        pdb.gimp_selection_none(j)

        z1 = add_layer_below(z)

        color_layer(z1, (65, 65, 65))

        z = merge_layer(z)
        z.name = n

        blur_selection(z, d[ok.DEPTH])
        emboss(z, v.glow_ball.azimuth, v.glow_ball.elevation, int(d[ok.DEPTH]))

        # brightness, '0'
        if d[ok.CONTRAST]:
            pdb.gimp_brightness_contrast(z, 0, int(d[ok.CONTRAST]))

        blur_selection(z, d[ok.SOFTEN])
        isolate_selection(z, sel)
        pdb.gimp_image_remove_channel(j, sel)
        clip_to_wip(v, z)

    else:
        color_selection(z, d[ok.COLOR_1])
    return z


class Overlay(SubBuild):
    """
    Process change for an overlay layer.
    Change its blend with its super Maya mask.
    """
    issue_q = 'overlay', 'mode', 'opacity'
    put = (check_overlay, 'matter'), (check_mix_overlay, None)

    def __init__(self, *q):
        """
        v: View
        super_maya: Maya
            Is the enclosing Maya.

        do_color: function
            Call to make a color layer.
        """
        self.bg_z = None
        SubBuild.__init__(self, *q)

    def do(self, v, d, is_change, is_mask):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            If it is True, then a mask is drawn on the Color layer.

        is_mask: bool
            Is True if the frame Maya has change.
        """
        self.value_d = d
        self.go = bool(self.super_maya.matter)
        self.is_overlay += is_change

        self.realize(v)

        if self.go and (self.is_overlay or is_mask):
            mask_sub_maya(self.super_maya.matter, self.matter)
        self.reset_issue()


class Filler(SubBuild):
    """Process change for a filler output."""
    issue_q = 'filler', 'mode', 'opacity'
    put = (
        (make_group_filler, 'group'),
        (check_filler, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(
        self, any_group, super_maya, k_path, do_filler, is_lucid=False
    ):
        """
        super_maya: Maya
            Frame type

        do_filler: function
            Call to make a filler layer.

        k_path: tuple
            (Option key, ...)
            Are path key to its vote dict.

        is_lucid: bool
            If True, then Blur Below is incorporated.
        """
        # Isn't an issue, 'matter', but is referenced by Shadow.
        self.is_matter = False

        SubBuild.__init__(self, any_group, super_maya, k_path, do_filler)
        self.sub_maya[LIGHT] = Light(
            any_group, self, [ok.OTHER, ok.TRANSLUCENT][is_lucid]
        )

    def do(self, v, d, is_change, is_mask):
        """
        Produce GIMP layer output. Has a filler
        layer and a Gradient Light layer.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is True if the cast Maya has change.

        is_mask: bool
            Is True if the super Maya has change.

        Return: bool
            Is True if there is Filler change.
        """
        self.value_d = d
        self.is_filler |= is_change

        # an external access adaptation, 'self.is_matter'
        # Filler's boolean change state, 'm'
        m = self.is_matter = self.is_filler

        self.realize(v)

        if m or is_mask:
            mask_filler_layer(v.j, self, self.super_maya.filler_sel)

        self.sub_maya[LIGHT].do(v, m)
        self.reset_issue()
        return m


class MetalFillerCanvas(SubBuild):
    """Process change for canvas filler output."""
    # There's no 'is_emboss' flag. because the super-Maya, the Wrap Maya,
    # processes the 'emboss' vote and passes it along to the 'do' function.
    is_seeded = True
    issue_q = 'filler', 'matter', 'mode', 'opacity'
    put = (
        (check_filler_metal, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path, do_filler, filler_path):
        """
        super_maya: Maya
            Frame type

        k_path: tuple
            (Option key, ...)
            path to this sub-Frame option

        do_filler: function
            Call to make a filler layer.

        filler_path: tuple
            (Option key, ...)
            Append to 'k_path' to create path to Filler option.
        """
        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + filler_path,
                k_path + (ok.WRW, ok.WRAP)
            ],
            do_filler
        )

    def do(self, v, d, is_change):
        """
        Produce GIMP layer output. Has a filler
        layer and a Gradient Light layer.

        v: View
        d: dict
            sub-Frame Preset

        Return: bool
            Is True when there is layer change.
        """
        self.value_d = d
        self.is_filler |= is_change

        # for shadow output
        # 'is_matter' is set by global seed and emboss vote.
        # MetalFillerCanvas's boolean change state, 'm'
        m = self.is_matter = self.is_filler = self.is_filler or self.is_matter

        self.realize(v)
        self.reset_issue()
        return m


class Lucid(Build):
    """
    Is a translucent frame. Require 'wrap_k' attribute in the
    sub-class which is the Option key of the Wrap Button.
    """
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_kind, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )

    def __init__(self, any_group, super_maya, k_path, do_matter, do_color, k):
        """
        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_matter: function
            Call to make the matter layer.

        do_color: function
            Call to make the color layer.

        k: string
            Is the row's Overlay Button key.
        """
        self.overlay_k = k

        Build.__init__(
            self,
            any_group,
            super_maya,
            k_path + (ok.WRW, self.wrap_k),
            do_matter
        )

        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cast, self)
        )
        self.sub_maya[OVERLAY] = Overlay(
            any_group, self, k_path + (ok.WRW, k), do_color
        )
        self.sub_maya[ok.BLUR_BELOW] = BlurBelow(
            any_group, self, k_path, ok.SRW
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.TRANSLUCENT)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame-type Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], is_change, self.is_matter
        )

        self.sub_maya[OVERLAY].do(
            v, d[ok.WRW][self.overlay_k], is_change, self.is_matter
        )
        self.sub_maya[ok.BLUR_BELOW].do(
            v, d[ok.SRW][ok.BLUR_BELOW], m or is_back, self.is_matter
        )
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m


class MaskGroup(Build):
    """Create a group having a mask and parenting the cast layer."""
    issue_q = 'matter',
    put = (check_matter, 'matter'),

    def __init__(self, *q):
        Build.__init__(self, *q)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame type Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: False
            The background did not change.
        """
        self.value_d = d
        self.is_matter |= is_change
        self.realize_vote(v)
        return False


class Metal(Build):
    """Is a metallic-like frame."""
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_kind, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path, do_matter, k):
        """
        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Is the Key path of the Frame Button in its vote dict.

        do_matter: function
            Call to make the matter layer.

        k: string
            Filler Option key
        """
        q1 = [k_path + (ok.WRW, ok.WRAP), k_path + (ok.WRW, k)]

        Build.__init__(self, any_group, super_maya, q1, do_matter)

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.SRW, ok.NOISE_D)
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cast, self)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[ok.NOISE_D].do(
            v, d[ok.SRW][ok.NOISE_D], is_change, self.is_matter
        )

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], is_change, self.is_matter
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m


class MetalCanvas(Build):
    """Create a metal frame with a filler insert."""
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_kind, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP

    def __init__(
        self, any_group, super_maya, k_path, do_filler, filler_path
    ):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_filler: function
            Call to make filler material

        k: string
            Wrap row key
        """
        self.filler_sel = None

        Build.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.WRW, ok.WRAP)],
            do_metal_wrap
        )

        self.sub_maya[FILLER] = MetalFillerCanvas(
            any_group, self, k_path, do_filler, filler_path
        )
        self.sub_maya[ok.NOISE_D] = Noisy(
            any_group,
            self,
            k_path + (ok.SRW, ok.NOISE_D),
            (self, self.sub_maya[FILLER])
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group,
            self,
            k_path + (ok.SRW, ok.SHADOW),
            (self.cast, self, self.sub_maya[FILLER]),
        )
        self.sub_maya[LIGHT] = Lamp(
            any_group, self, ok.METAL, (self.sub_maya[FILLER],)
        )

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)

        is_filler = self.sub_maya[FILLER].do(v, d, is_change)
        is_mask = self.is_matter or is_filler
        self.sub_maya[ok.NOISE_D].do(
            v,
            d[ok.SRW][ok.NOISE_D],
            is_change,
            is_mask
        )
        is_shadow = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], is_change, is_mask
        )

        self.sub_maya[LIGHT].do(v, is_mask)
        self.reset_issue()
        return is_shadow


class MetalAltFiller(Build):
    """Create a metal frame with a filler insert."""
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path, do_filler, k):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Is the key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_filler: function
            Call to make filler material

        k: string
            Is the Option key to the Filler dict found in the 'ok.WRW' row.
        """
        self.filler_sel = None
        self.filler_k = k

        Build.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.WRW, ok.WRAP), k_path + (ok.WRW, k)],
            do_filler_wrap
        )

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.SRW, ok.NOISE_D)
        )
        self.sub_maya[FILLER] = Filler(
            any_group, self, k_path + (ok.WRW, k), do_filler
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group,
            self,
            k_path + (ok.SRW, ok.SHADOW),
            (self.cast, self, self.sub_maya[FILLER])
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)

        is_filler = self.sub_maya[FILLER].do(
            v, d[ok.WRW][self.filler_k], is_change, self.is_matter
        )

        self.sub_maya[ok.NOISE_D].do(
            v, d[ok.SRW][ok.NOISE_D], is_change, self.is_matter
        )

        # background changed flag, 'm'
        is_shadow = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], is_change, self.is_matter or is_filler
        )

        # Filler doesn't receive light. The
        # 'self.matter' layer does receive light.
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return is_shadow

    def reset(self):
        """Call when the View image is removed."""
        if self.filler_sel:
            pdb.gimp_image_remove_channel(The.view.j, self.filler_sel)
            self.filler_sel = None
        super(MetalAltFiller, self).reset()


class ShadowBasic(SubBuild):
    """Process change for a shadow layer."""
    issue_q = 'shadow',
    put = (check_shadow, 'shadow'),

    def __init__(self, any_group, super_maya, k_path):
        """
        v: View
        super_maya: Maya
            Is the enclosing Maya.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, do_cast_shadow)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame-type Preset

        Return: bool
            Is True when the Shadow has change.
        """
        is_back = v.is_back
        self.value_d = d
        self.is_shadow |= is_change

        self.realize_vote(v)
        return is_back != v.is_back
