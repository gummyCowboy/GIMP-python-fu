#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Signal as si
from roller_constant_key import ModelList as ml, Step as sk
from roller_model_id import ModelId
from roller_one_power import Power


def get_step_q(d, k):
    """
    Make a list of navigation step key sorted
    by the navigation tree's process order.

    d: dict
        Has navigation step key of visible option group.
        {navigation step key: AnyGroup}

    k: tuple
        navigation step key
        (Node label, ...); Use Model id for Model reference.
        Is the key to the first Node in the tree.

    Return: tuple
        (SuperPreset step key list, Preset step key list)
    """
    def _walk(_group):
        """
        Use recursion to walk through the AnyGroup dict.
        Collect navigation step key by its group type.

        _group: AnyGroup
            Is either a Node, SuperPreset, or Preset type.
        """
        for _item in _group.item.node.get_item_list():
            _step_k = _item.any_group.nav_k

            if _item.group_type == 'preset':
                step_q.append(_step_k)
                preset_step_q.append(_step_k)

            elif _item.group_type == 'super_preset':
                preset_step_q.append(_step_k)

            _group1 = d[_step_k]
            if _group1.item.node:
                _walk(_group1)

    # Is a list of Preset-filtered step key that make up a view, 'step_q'.
    # [Preset navigation step key, ...]
    step_q = []

    # [SuperPreset navigation step key, ...]
    preset_step_q = []

    _walk(d[k])
    return preset_step_q, step_q


class The:
    """
    Has class and variable that won't import directly
    due to a circular reference. Variables are
    initialized during Roller start-up.
    """
    # Cat and Dog are paradigm abstractions with a short and unique descriptor.
    # Cat class
    cat = None

    # Dog class
    dog = None

    # Is the frame file path used by FrameOver.
    frame_path = ""

    helm = None

    # Use with ImageGradient to delete unused gradients.
    image_gradient_used = None

    # Use with ImageGradient to delete unused gradients.
    image_gradient_created = []

    # Use to remember the image file path for an OSButton.
    image_path = ""

    # Set when loading a Preset or SuperPreset. Suppress UI update.
    load_count = 0

    model_id = ModelId()

    # Power instance
    power = None

    # Preset class
    preset = None

    # Is the root folder for Preset storage.
    preset_folder = ""

    # Shelf instance
    shelf = None

    # SuperPreset class
    super_preset = None

    # NumberPair class
    number_pair = None

    # Is the View instance.
    view = None

    # Window position dict
    window_pose = {}


# Could this be more circular? Yet, power is a circular motion.
The.power = Power(The)


class Helm:
    """
    Has a dictionary of navigation step key with AnyGroup
    value that are visible in the user interface.
    """

    def __init__(self):
        # {navigation step key: AnyGroup}
        self._helm_d = {}

        # [sequenced navigation step key of Preset type]
        self._step_q = []

        # [sequenced navigation step key of Preset, Node, and SuperPreset type]
        self._all_step_q = []

        # [sequenced navigation step key of Preset and SuperPreset type]
        self._preset_step_q = []

        The.power.connect(si.PANEL_CHANGE, self.on_panel_change)
        return

    def add_step(self, k, a):
        """
        Add an AnyGroup to the Helm dict.

        k: tuple
            navigation step key

        a: AnyGroup
            Correspond with step key.
        """
        self._helm_d[k] = a

    def finds(self, k):
        """
        Determine if a navigation step key is the Helm dict.

        k: tuple
            navigation step key

        Return: bool
            Is True if the key is in the Helm dict.
        """
        return bool(k in self._helm_d)

    def get_all_step_q(self):
        """
        Provide a list of the steps in the navigation tree.

        Return: list
            [navigation step key]; [(node label, model id, node label, ...)]
        """
        return self._helm_d.keys()

    def get_branch_step_q(self, k):
        """
        Make a list of navigation step key that have a sub-step key.

        k: tuple
            Is the navigation step key at the start of a branch.

        Return: list
            containing branch step key
        """
        x = len(k)
        return [i for i in self._helm_d.keys() if k == tuple(i[0:x])]

    def get_group(self, k):
        """
        Fetch an AnyGroup from the Helm dict.

        k: tuple
            navigation step key

        Return: AnyGroup or None
        """
        if k in self._helm_d:
            return self._helm_d[k]

    def get_key_q(self):
        """Return a list of active navigation step key."""
        return self._helm_d.keys()

    def get_preset_step_q(self):
        """
        Compile a list of navigation step key ordered by process order
        excluding Node step key.

        Return: list
            [navigation step key, ...]
            navigation step key -> (Node label,), (Model id, Node label, ...)
        """
        return self._preset_step_q[:]

    def get_step_q(self):
        """Return a copy of the navigation step key list."""
        return self._step_q[:]

    def on_panel_change(self, *_):
        """
        When there's NodePanel change, the step lists needs to be updated.
        """
        self._preset_step_q, self._step_q = get_step_q(self._helm_d, sk.STEPS)

    def remove_step(self, k):
        """
        Remove a navigation step key from the Helm dict.

        k: tuple
            navigation step key
        """
        if k in self._helm_d:
            self._helm_d.pop(k)

    def remove_model(self, a):
        """
        Remove step having a given Model id reference from the Helm dict.

        a: int
            model id
        """
        d = self._helm_d
        for i in d.keys():
            if a in i:
                d.pop(i)


class Shelf:
    """Use to manage the offline dictionary that ModelList loads."""

    def __init__(self):
        # {panel step key: value dict}
        # panel step key -> (Model name, Node label, ...)
        self._shelf_d = {}

    def clear_shelf(self):
        self._shelf_d.clear()

    def finds(self, k):
        """
        Determine if a panel step key is shelved.

        k: tuple
            panel step key

        Return: bool
            Is True if the key is shelved.
        """
        return bool(k in self._shelf_d)

    def get_model_step_q(self, n):
        """
        Create a list of panel step key of a model.

        n: string
            model name
            Only step with this model name will be returned.

        Return: list
            [panel step key,]
        """
        # Model name index in a panel step key, '0'
        return [i for i in self._shelf_d.keys() if n == i[0]]

    def get_shelf_d(self):
        """
        Make a copy of the shelf dict.

        Return: dict
            shelf dict copy
        """
        return deepcopy(self._shelf_d)

    def get_step_d(self, k):
        """
        Fetch the shelved Preset for a panel step key.

        k: tuple
            panel step key

        Return: dict or None
            Is a Preset value dict.
        """
        if k in self._shelf_d:
            return self._shelf_d[k]

    def get_step_q(self):
        """
        Fetch a list of shelved panel key.

        Return: list
            [panel key,]
        """
        return self._shelf_d.keys()

    def remove_model(self, n):
        """
        Remove step having a model name reference from the shelf dict.

        n: string
            model name key
        """
        d = self._shelf_d
        for i in d.keys():
            # index of a model name in a panel step key, '0'
            if n == i[0]:
                d.pop(i)

    def remove_step(self, k):
        """
        Remove a panel step key from the shelf dict.

        k: tuple
            panel step key
        """
        if k in self._shelf_d:
            self._shelf_d.pop(k)

    def set_d(self, d, model_def):
        """
        Set the Shelf dict from a new dict.

        d: dict
            {panel step key: Preset dict}

        model_def: list
            [(Model name, Model type), ...]
        """
        name_q = [i[ml.NAME_INDEX] for i in model_def]

        # Sync the Shelf dict with a Model definition list.
        for i in d.keys():
            # Model name index, '0'
            if i[0] not in name_q:
                # Repair.
                d.pop(i)
        self._shelf_d = d

    def set_step(self, k, a):
        """
        Set the value of a panel step key in the shelf dict.

        k: tuple
            panel step key

        a: value
            Is the value of the step's Preset.
        """
        self._shelf_d[k] = a


The.helm = Helm()
The.shelf = Shelf()


def calc_factor(f, w):
    """
    Calculate a factored height.

    f: float
        Is factor variable.
        for example, the View image width

    w: numeric
        scale of factor

    Return: float
        the factor of the height
    """
    return round(f * w)


def get_factor(a, w):
    """
    Calculate a factored scale.

    a: tuple or int
        (fixed value, factor value)
        fixed value

    w: numeric
        scale of factor
        for example, the View image height

    Return: numeric
        of the same type as the fixed value
    """
    if isinstance(a, tuple):
        return a[0] + calc_factor(a[1], w)

    # float or int
    return calc_factor(a, w)


def get_factor_h(a):
    """
    Calculate the result for a number pair
    that uses the WIP image height as a factor.

    a: tuple, int, or float
        (fixed value, factor value)
        fixed value, from an earlier version

    Return: numeric
        of the same type as the fixed value
    """
    return get_factor(a, The.view.wip.h)


def get_factor_w(a):
    """
    Calculate the number for a number pair
    that uses the WIP image width as a factor.

    a: tuple, int, or float
        (fixed value, factor value)
        fixed value, from an earlier version

    Return: numeric
        of the same type as the fixed value
    """
    return get_factor(a, The.view.wip.w)
