#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Image as fi
from roller_constant_key import Widget as wk
from roller_fu_comm import show_err
from roller_fu import (
    collect_group, load_selection, merge_layer_group, remove_z, validate_layer
)
from roller_one_image import (
    Image as ig, image_undo_end, image_undo_start, make_image_list
)
from roller_one_oz import ensure_dir, get_preset_path, pickle_dump, pickle_load
from roller_one_the import The
from roller_port_main import PortMain
from roller_view_gradient_light import GradientLight
from roller_window import Window
import gimpfu as fu
import gobject
import gtk
import os

CRITICAL = "Roller closed itself due to a critical error: "
TITLE = "Roller 5.10"
pdb = fu.pdb


def collapse_loner(j):
    """
    Collapse layer group with only one child.

    j: GIMP image
        Has layer group.
    """
    # list of group layers from the top-down, 'group_q'
    group_q = []

    collect_group(j, group_q)

    # Remove invisible layer.
    for group in reversed(group_q):
        if len(group.layers) == 1:
            z = group.layers[0]
            if not pdb.gimp_item_is_group(z):
                mode = z.mode
                z = merge_layer_group(group, n=z.name)
                z.mode = mode


def pass_by_parent(j):
    """
    If a group has one layer and it is a group, move the child
    to the parent's level and remove the former parent.

    j: GIMP image
        Has layer group.
    """
    # list of group layers from the top-down, 'group_q'
    group_q = []

    collect_group(j, group_q)

    # Remove invisible layer.
    for group in reversed(group_q):
        if len(group.layers) == 1:
            z = group.layers[0]
            if pdb.gimp_item_is_group(z):
                pdb.gimp_image_reorder_item(j, z, group.parent, 1)
                remove_z(group)


def remove_unused_layer(j):
    """
    Remove any layers without pixel. Is recursive.

    j: GIMP image
        Has sub-layers.
    """
    # list of group layers from the top-down, 'group_q'
    group_q = []

    collect_group(j, group_q)

    # Remove invisible layer.
    for group in group_q:
        for z in group.layers:
            if not z.visible and not pdb.gimp_item_is_group(z):
                pdb.gimp_image_remove_layer(z.image, z)
            elif not z.opacity:
                pdb.gimp_image_remove_layer(z.image, z)


def remove_unused_group(j):
    """
    Remove any group layers without any children.

    j: GIMP image
        Is render.
    """
    # list of group layers from the top-down, 'group_q'
    group_q = []

    collect_group(j, group_q)

    # Remove empty groups from the bottom-up.
    [remove_z(z) for z in reversed(group_q) if not z.layers]


def resize_layers(z):
    """
    Resize the layers to the image size.

    z: GIMP image or layer
        Has sub-layers.
    """
    # list of group layers from the top-down, 'group_q'
    # Remove invisible layer.
    for i in z.layers:
        pdb.gimp_layer_resize_to_image_size(i)
        if pdb.gimp_item_is_group(i):
            resize_layers(i)


def verify_preset_folder():
    """
    Roller requires a Preset folder to store Preset.

    Return: bool
        It is True if the directory is verified.
    """
    go = False

    try:
        n = The.preset_folder = os.path.join(
            The.cat.roller_path,
            u"Preset"
        )
        go = ensure_dir(n)[-1]

    except Exception as ex:
        show_err(ex)
        show_err(
            "The operating system isn't compatible with Roller."
        )
    return go


class WindowMain(Window):
    """Is Roller's main window."""

    def __init__(self):
        """Has the GTK event loop."""
        if verify_preset_folder():
            self._last_window_pose = {}
            cat = The.cat

            # Preserve the selection and active layer of open images.
            sel_q = []
            active_layer_q = []

            self._load_window_pose()
            make_image_list()
            image_undo_start()

            for _, j in ig.roller_image.items():
                active_layer_q.append((j.j, j.j.active_layer))
                sel_q.append((
                    j.j,
                    pdb.gimp_selection_save(j.j)
                    if not pdb.gimp_selection_is_empty(j.j) else None
                ))
                pdb.gimp_selection_none(j.j)

            Window.__init__(self, {wk.WINDOW_KEY: TITLE}, is_dialog=False)

            self.port = PortMain({wk.ROLLER_WIN: self})

            self.set_hook(self.port.get_hook())
            self.add(self.port)

            # Display the main window now that it
            # has been initialized by PortMain.
            self.gtk_win.show_all()

            try:
                # Insert a signal processing function
                # into the main signal processing ring.
                #
                # Reference
                # library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
                gobject.idle_add(The.power.send)

                # Start the main signal processing ring.
                gtk.main()

            except Exception as ex:
                if self.gtk_win is not None:
                    self.close()
                    show_err(CRITICAL + repr(ex))
                raise

            view_j = cat.render.get_image()

            # Close any opened images.
            for k, q in ig.opened_image_d.items():
                if k not in ig.image_name_list:
                    j = q[fi.IMAGE_INDEX].j
                    if pdb.gimp_image_is_valid(j):
                        pdb.gimp_image_delete(j)

            # Close the GradientLight image.
            if GradientLight.image:
                pdb.gimp_image_delete(GradientLight.image)

            # Restore the selection for open images.
            for i in sel_q:
                j, sel = i[0], i[1]

                if sel is not None:
                    if (
                        pdb.gimp_item_is_valid(sel) and
                        pdb.gimp_image_is_valid(j)
                    ):
                        load_selection(j, sel)
                        pdb.gimp_image_remove_channel(j, sel)
                else:
                    # Remove a Roller generated selection.
                    pdb.gimp_selection_none(j)

            # Restore the active layer for open images.
            for j, z in active_layer_q:
                if pdb.gimp_image_is_valid(j) and validate_layer(z):
                    j.active_layer = z

            if view_j:
                a = WindowMain

                if not self.canceled:
                    v = The.view

                    remove_unused_group(view_j)
                    remove_unused_layer(view_j)
                    collapse_loner(view_j)
                    pass_by_parent(view_j)
                    pdb.gimp_image_resize(
                        view_j, *map(int, (v.wip.size + (-v.wip.x, -v.wip.y)))
                    )
                    resize_layers(view_j)
                a.remove_unused_image_gradient()

            if not self.canceled and view_j:
                # Set the bottom layer as the active layer.
                if len(view_j.layers):
                    view_j.active_layer = view_j.layers[-1]

                # Remove channels.
                [view_j.remove_channel(i) for i in view_j.channels]

            # Save Window position.
            if The.window_pose != self._last_window_pose:
                pickle_dump(The.window_pose, self._window_pose_file)
            image_undo_end()

    def _load_window_pose(self):
        """Load the Window position dictionary if it exists."""
        n = self._window_pose_file = get_preset_path(
            u"Window Position", "", The.preset_folder
        )
        d = pickle_load(n, is_shown=False)

        if d:
            The.window_pose = deepcopy(d)
            self._last_window_pose = deepcopy(d)

    @staticmethod
    def remove_unused_image_gradient():
        """
        Delete image gradient that was created
        but is not saved with the render.
        """
        for grad in The.image_gradient_created:
            if grad != The.image_gradient_used:
                pdb.gimp_gradient_delete(grad)
