#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_maya import Maya


class SubMaya(Maya):
    """Factor Build and SubBuild. Is for Work layer output."""

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        Require 'put' attribute in calling sub-class.

        any_group: AnyGroup
            option owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_matter: function
            Call to make primary layer.
        """
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter

        Maya.__init__(self, any_group, 1, self.put, k_path)
        self.set_issue()


class Build(SubMaya):
    """
    Is for sub-Maya in particular option-list sourced.

    Has a 'cast' variable for referencing the super maya's super maya.
    """

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        any_group: AnyGroup
            option owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_matter: function
            Call to make primary layer.
        """
        self.cast = super_maya.super_maya
        SubMaya.__init__(self, any_group, super_maya, k_path, do_matter)


class SubBuild(SubMaya):
    """
    Is for sub-Maya in particular option-list sourced.

    Has an inherited 'cast' variable.
    """
    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        any_group: AnyGroup
            option owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_matter: function
            Call to make primary layer.
        """
        self.cast = super_maya.cast if hasattr(super_maya, 'cast') else None
        SubMaya.__init__(self, any_group, super_maya, k_path, do_matter)
