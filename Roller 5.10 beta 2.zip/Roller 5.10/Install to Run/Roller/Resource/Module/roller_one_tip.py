#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import BackdropStyle as by, Frame as ek, Model as md

DEPENDENT_STYLE = " Uses the Backing layer. "
FRAME_TYPE_METAL = " Frame Type: Metal "
FRAME_TYPE_METAL_OTHER = " Frame Type: Metal and Other "
FRAME_TYPE_OTHER = " Frame Type: Other "
FRAME_TYPE_TRANSLUCENT = " Frame Type: Translucent "
INDEPENDENT_STYLE = " Doesn't use the Backing layer. "


class Tip:
    """Has tooltip text string."""
    ADD_SHIFT_XY = \
        " After the first cell, each cell's position \n" \
        " is offset by this amount from the prior \n" \
        " cell in the cell sequence. "
    AMPLITUDE = " Use a higher value to increase the roughness. "
    AUTOCROP = " When checked, empty space around an image is cropped. "
    AZIMUTH = " The light angle is used by an emboss function. "
    BLEND = " Use a higher value to create less textural variation. "
    CELL_GAP = " Is the number of sequenced cells between two mazes. "
    CLIP_TO_CELL = \
        " If selected, the output is contained \n" \
        " within the contextual bounds. "
    COLOR = " Red\t{} \n Green\t{} \n Blue\t{} "
    COLOR_COUNT = " Is the number of potential colors. "
    COLOR_INTENT = " \tRed \t{} \n \tGreen\t{} \n \tBlue\t{} "
    COLOR_RGBA = COLOR + "\n Alpha\t{}"
    COLOR_RGBA_INDENT = COLOR_INTENT + "\t\n Alpha\t{}"
    CONTRACT = \
        " At zero, the brush is applied on the edge of \n" \
        " a cell or source material. With contract, the \n" \
        " edge moves inward toward the center of the subject. "
    CROP_X = \
        " Crop the image from a topleft coordinate \n" \
        " defined by x and y. The size of the \n" \
        " crop is the width and height values. "
    CUT_OUT = \
        " Invert the mask making it cut-out instead of cut-around. "
    DELETE_MODEL = " Delete the selected model. "
    DELETE_PLAN = " If selected, the Plan layer group is removed on exit. "
    DIAGONAL_ROTATION = \
        " The direction angle is mirrored in the \n" \
        " opposite direction. The result is a vector \n" \
        " that goes through the layer's center, \n" \
        " starting and ending at the layer bounds. "
    DISTRESS_THRESHOLD = " Stress the frame more with a higher value. "
    DRAFT_BUTTON = " Plan steps up to the visible option group. "
    ELEVATION = \
        " Used by an emboss function. It \n" \
        " determines the lightness of an emboss, \n" \
        " where a higher value has greater light. "
    END_X = " Add to the x-axis end coordinate. "
    END_Y = " Add to the y-axis end coordinate. "
    EXPAND_FRAME = \
        " The frame image rectangle is expanded on \n" \
        " both axes by twice this amount. The frame \n " \
        " center remains the center of the image rectangle. "
    FACTOR_H = " Multiply by the render height and add to the result. "
    FIW = \
        " Resize the image by multiplying its scale with factor values. "
    FACTOR_W = " Multiply by the render width and add to the result. "
    FCI = \
        " Select to make the grid's first cell position be row 1, column 2. "
    FEATHER = \
        " The initial feather is this number divided \n" \
        " by steps. Subsequent steps add the initial \n" \
        " value to the feather. This value becomes the \n" \
        " feather amount applied on the last step. "
    FILL_MODE = "Is the paint mode used by the bucket fill. "
    FIXED_SIZE_W = " Resize the image to these dimensions. "
    FONT_SIZE = " Is for Draft/Plan text output. "
    FRINGE_MASK = \
        " Brush strokes painted on the edge of the material form a mask. "
    GRID_FIXED_SIZE = \
        " The canvas space is divided by the dimension \n" \
        " to derive the row and column count. "
    HEIGHT_MOD = " Modify the image height by this amount. "
    HIDE_LAYER = " Hide Layers in the dock for faster processing. "
    IMAGE_LAYERS = \
        " The image's layers are iterated as a tree, \n" \
        " where each layer becomes an image reference. "
    IMAGE_NAME = \
        " The order of image name list is \n" \
        " from GIMP's open image order. "
    IMAGE_NUMERIC = \
        " The order of the numeric list is \n" \
        " from GIMP's open image order. "
    IMAGE_ORDER = \
        " Is the direction of the layer-tree iteration. \n" \
        " With top-down, the first layer is the \n" \
        " layer at the top of the layer stack. \n" \
        " If top-down is off, then the order is \n" \
        " bottom-up, and the first layer is \n" \
        " the bottom layer in the stack. "
    INTENSITY = " Is the shadow opacity but is layered for greater capacity. "
    INWARD = \
        " When selected, Facing output faces towards the center of the model. "
    KEEP_GRADIENT = \
        " Have GIMP save the new gradient in \n" \
        " the user's default gradient folder. "
    LEAD = " Is a caption prefix. "
    LENGTH_SHIFT = \
        " Modify the length of a tape strip, plus or \n" \
        " minus, by a random amount limited by this scale. "
    LOOP_MINUS = \
        " Assign images using a circular-type index variable. \n" \
        " Loop Minus decrements after assigning an image. \n" \
        " It's index rolls-over to the last open image after \n" \
        " the first open image. Both Loop Plus and Loop \n" \
        " Minus use the same index variable. If the Minus \n" \
        " option is used before the Plus option, then the \n" \
        " last open image is the first image reference. "
    LOOP_PLUS = \
        " Assign an image using a circular-type index variable. \n" \
        " Loop Plus increments after assigning an image. \n" \
        " The index rolls-over to the first open image after \n" \
        " the last open image. Both Loop versions use the same \n" \
        " index variable. If the Plus index is used before the \n" \
        " Minus index, then the first open image is the first \n" \
        " image reference. "
    MERGE_CELL = " X:\t\t{} \n Y:\t\t{} \n Width:\t{} \n Height:\t{} "
    MODEL_LIST_NEW = " Make a new model from the type specified. "
    MODEL_LIST_TREE = " active model in inverted layer stack order "
    MODEL_LIST_TYPE = {
        md.BOX:
            " Arrange double-spaced box-shaped \n"
            " cell by row and column. ",
        md.CELL: " Define a cell. ",
        md.PYRAMID: " Define rows of cell in a triangular-shaped stack. ",
        md.STACK: " Layer cell in a stack. ",
        md.TABLE: " Arrange cell by row and column. "
    }
    MODEL_STEP = " Add and remove available step from the navigation tree. "
    MOVE_DOWN = " Move the selected model down in the z-order. "
    MOVE_LEFT = " Remove the selected item from the interface. "
    MOVE_RIGHT = " Move the selected item to the interface. "
    MOVE_UP = " Move the selected model up in the z-order. "
    n = " Apply cell data and show cell to the "
    NAVIGATION = (
        n + "north (ctrl ↑) ",
        n + "south (ctrl ↓) ",
        n + "west (ctrl ←) ",
        n + "east (ctrl →) "
    )

    OBEY_MARGINS = \
        " If selected, the output is applied within the branch margins. "
    OFFSET_X_SHIFT = " Move the image on the X-axis. "
    OFFSET_Y_SHIFT = " Move image on the Y-axis. "
    OPAQUE = " When selected, the blur's mask source is made opaque. "
    OPTION_LIST = {
        # Backdrop Style
        by.ACRYLIC_SKY: DEPENDENT_STYLE,
        by.BACK_GAME: DEPENDENT_STYLE,
        by.CLAY_CHEMISTRY: DEPENDENT_STYLE,
        by.COLOR_FILL: DEPENDENT_STYLE,
        by.COLOR_GRID: DEPENDENT_STYLE,
        by.CORE_DESIGN: INDEPENDENT_STYLE,
        by.CUBE_PATTERN: INDEPENDENT_STYLE,
        by.CUBISM_COVER: DEPENDENT_STYLE,
        by.CRYSTAL_CAVE: INDEPENDENT_STYLE,
        by.DARK_FORT: INDEPENDENT_STYLE,
        by.FADING_MAZE: INDEPENDENT_STYLE,
        by.DENSITY_GRADIENT: INDEPENDENT_STYLE,
        by.DROP_ZONE: INDEPENDENT_STYLE,
        by.ETCH_SKETCH: DEPENDENT_STYLE,
        by.FLOOR_SAMPLE: INDEPENDENT_STYLE,
        by.GALACTIC_FIELD: DEPENDENT_STYLE,
        by.GLASS_GAW: INDEPENDENT_STYLE,
        by.GRADIENT_FILL: INDEPENDENT_STYLE,
        by.HISTORIC_TRIP: DEPENDENT_STYLE,
        by.IMAGE_GRADIENT: DEPENDENT_STYLE,
        by.LINE_STONE: DEPENDENT_STYLE,
        by.LOST_MAZE: INDEPENDENT_STYLE,
        by.MAZE_BLEND: DEPENDENT_STYLE,
        by.MEAN_COLOR: DEPENDENT_STYLE,
        by.MYSTERY_GRATE: INDEPENDENT_STYLE,
        by.NANO_SUIT: DEPENDENT_STYLE,
        by.NOISE_RIFT: INDEPENDENT_STYLE,
        by.PAPER_WASTE: DEPENDENT_STYLE,
        by.PATTERN_FILL: DEPENDENT_STYLE,
        by.RAINBOW_VALLEY: DEPENDENT_STYLE,
        by.RECT_PATTERN: INDEPENDENT_STYLE,
        by.ROCKY_LANDING: INDEPENDENT_STYLE,
        by.ROOF_TOP: INDEPENDENT_STYLE,
        by.SOFT_TOUCH: DEPENDENT_STYLE,
        by.SPECIMEN_SPECKLE: DEPENDENT_STYLE,
        by.SPIRAL_CHANNEL: INDEPENDENT_STYLE,
        by.SQUARE_CLOUD: DEPENDENT_STYLE,
        by.STONE_AGE: DEPENDENT_STYLE,
        by.TRAILING_VINE: INDEPENDENT_STYLE,

        # Frame
        ek.BALL_JOINT: FRAME_TYPE_METAL,
        ek.BORDER_LINE: FRAME_TYPE_METAL,
        ek.BOXY_BEVEL: FRAME_TYPE_OTHER,
        ek.BRUSH_PUNCH: FRAME_TYPE_METAL,
        ek.CAMO_PLANET: FRAME_TYPE_METAL,
        ek.CERAMIC_CHIP: FRAME_TYPE_METAL_OTHER,
        ek.CIRCLE_PUNCH: FRAME_TYPE_METAL,
        ek.CLEAR_FRAME: FRAME_TYPE_TRANSLUCENT,
        ek.COLOR_BOARD: FRAME_TYPE_TRANSLUCENT,
        ek.COLOR_PIPE: FRAME_TYPE_TRANSLUCENT,
        ek.CORNER_TAPE: FRAME_TYPE_TRANSLUCENT,
        ek.CRUMBLE_SHELL: FRAME_TYPE_OTHER,
        ek.FRAME_OVER: FRAME_TYPE_OTHER,
        ek.GRADIENT_LEVEL: FRAME_TYPE_TRANSLUCENT,
        ek.HOT_GLUE: FRAME_TYPE_TRANSLUCENT,
        ek.LINK_MIRROR: FRAME_TYPE_METAL,
        ek.LINE_FASHION: FRAME_TYPE_METAL,
        ek.NAIL_POLISH: FRAME_TYPE_OTHER,
        ek.RAD_WAVE: FRAME_TYPE_METAL,
        ek.RAISED_MAZE: FRAME_TYPE_METAL,
        ek.SHAPE_BURST: FRAME_TYPE_OTHER,
        ek.SQUARE_CUT: FRAME_TYPE_METAL,
        ek.SQUARE_PUNCH: FRAME_TYPE_METAL,
        ek.STAINED_GLASS: " Frame Type: Metal and Translucent ",
        ek.STICKY_WOBBLE: FRAME_TYPE_METAL,
        ek.STRETCH_TRAY: FRAME_TYPE_METAL_OTHER,
        ek.WIRE_FENCE: FRAME_TYPE_METAL
    }
    PER_CHECK_BUTTON = " Define option as either main or per. "
    PER_BUTTON = " Open a per option table for per editor access. "
    PEEK_BUTTON = " Preview steps up to the visible option group. "
    PLAN_BORDER = " Show Border material in Draft/Plan output. "
    PLAN_BUTTON = " Per the Planner option, draw a plan graph. "
    PLAN_CELL_SHAPE = " Draw the cell shape outline. \n" \
        " Requires the Cell/Margin step. "
    PLAN_POSITION = \
        " Display the topleft canvas coordinate of a \n" \
        " cell's position. Requires the Cell/Margin step. "
    PLAN_CORNER = \
        " Display the bottom-left and top-right canvas \n" \
        " coordinate of a cell's position. Requires the \n" \
        " Cell/Margin step. "
    PLAN_DIMENSION = \
        " Display the size of a cell. Requires the Cell/Margin step. "
    PLAN_GRID = " Draw a grid defined by the model's grid. "
    PLAN_IMAGE_NAME = " Show the name of the image assigned to a cell. "
    PLAN_RATIO = \
        " Display the cell's position ratio. Requires the Cell/Margin step. "
    POST_BLUR = \
        " Create a blurry frame that sits on top \n" \
        " of the source material. The blur is \n" \
        " applied at the end of the processing. "
    POWER = " A higher value increases cloud material. "
    PREVIEW_BUTTON = " Make a render using the navigation tree (ctrl-p). "
    SEED = " Randomized output uses this an init value. "
    SEEDING = " Try dynamic to randomize Per Cell output. "
    RENAME_MODEL = " Rename the selected model. "
    REVISE_MODEL = " Revise the available steps for the selected model. "
    REVERSE = " Reverse the order of the gradient colors. "
    SAMPLE_COUNT = " Sample points are evenly distributed between the edges. "
    SCATTER_COUNT = " Is the number of mazes to draw. "
    SEED_GLOBAL = " Modify all the random seed in use. "
    SHELVE = " Move the selected model from the navigation tree to the shelf. "
    SHIFT_H = " Randomize the image's height (+/-). "
    SHIFT_W = " Randomize the image's width (+/-). "
    SHIFT_X = " Randomize the image's x position (+/-). "
    SHIFT_Y = " Randomize the image's y position (+/-). "
    SLICE = " Slice an image using row and column values. "
    SLIDER_INT_PART = " Add to the result with the factored calculation. "
    SPIRAL_DISTANCE = " Lower the value to increase the spiral count. "
    SPREAD_DISTRESS = \
        " The material scatters increasingly with a higher value. "
    START_NUMBER = " Is the first number displayed in an integer sequence. "
    STEPS = " Repeat feather. "
    STEPS_DROP_ZONE = " Is the number of colors in the resulting gradient. "
    STRIPE_H = " Is a factor of the caption's text height. "
    THRESHOLD = \
        " A threshold of 1.0 is a match all \n" \
        " and a threshold of 0.0 is to match none. "
    TRAIL = " Is a caption suffix. "
    WIDTH_MOD = " Modify the image width by this amount. "
    WHIRL = " Spin the material around the center of the image. "
    WIP = " Scale the image size. Use to improve render edge-case output. "
