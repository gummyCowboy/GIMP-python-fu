#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame import do_selection_material
from roller_fu import (
    clear_inverse_selection,
    clone_layer,
    copy_all_image,
    get_layer_position,
    get_select_bounds,
    hide_layer,
    merge_layer,
    paste_layer,
    remove_z,
    select_item,
    select_rect,
    shape_clipboard,
    show_layer
)
from roller_maya import (
    check_matter,
    check_mix_overlay,
    check_mix_wrap,
    check_overlay,
    make_group_kind
)
from roller_maya_blur_below import BlurBelow
from roller_maya_build import Build, SubBuild
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_one_gegl import edge
from roller_view_hub import (
    color_selection_default, set_gimp_pattern, set_fill_context_default
)
from roller_view_real import LIGHT, OVERLAY, clone_background, mask_sub_maya
import gimpfu as fu

pdb = fu.pdb


def apply_backdrop(v, maya, z):
    """
    Copy the background. Clip material around the existing selection.

    v: View
    maya: Maya
        NailPolish/Overlay

    z:
    Return: layer
        with backdrop
    """
    j = v.j
    z1 = clone_layer(maya.bg_z)

    select_item(z)
    clear_inverse_selection(z1)
    j.remove_layer(z)
    return z1


def apply_image(v, maya, z):
    """
    Apply an image to the frame.

    v: View
    maya: Maya
    z: layer
        Has the frame.

    Return: layer
        with the frame
    """
    j = v.j
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    j1 = maya.cast.get_frame_image(maya.k)

    if j1:
        copy_all_image(j1.j)
        shape_clipboard(x1 - x, y1 - y)

        z = paste_layer(z)

        pdb.gimp_layer_set_offsets(z, x, y)
        return merge_layer(z)
    return z


def apply_pattern(v, maya, z):
    """
    Fill an existing selection with a pattern.

    v: View
        not used

    maya: Maya
    Return: layer
        with pattern
    """
    d = maya.value_d

    set_fill_context_default()
    set_gimp_pattern(d[ok.PATTERN])
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, .0, .0)
    return z


def prep_overlay(v, maya):
    """
    Create a color overlay layer.

    v: View
    maya: Maya
        NailPolish/Overlay
    """
    go = True
    z = z1 = None
    super_ = maya.super_maya

    if maya.value_d[ok.TYPE] == ff.BELOW:
        z = super_.matter

        if z:
            z1 = maya.super_maya.sub_maya[ok.BLUR_BELOW].matter

            if z1:
                hide_layer(z1)
            maya.bg_z = clone_background(v, z)
        else:
            go = False

    if go:
        maya.group = super_.group
        z = do_selection_material(
            v, maya, do_overlay, embellish, "Overlay"
        )
        if maya.bg_z:
            remove_z(maya.bg_z)

    if z:
        pdb.gimp_image_reorder_item(
            v.j, z, maya.group, get_layer_position(maya.super_maya.matter)
        )

    if z1:
        show_layer(z1)
    return z


def do_color_fill(v, maya, z):
    d = maya.value_d[ok.WRW][ok.WRAP_NP]
    z.name = z.parent.name + " Wrap"

    grow_sel(v, d[ok.WIDTH])
    color_selection_default(z, d[ok.COLOR_1])
    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: FrameOver
    Return: layer or None
        with the frame
    """
    return do_selection_material(v, maya, do_color_fill, embellish, "Wrap")


def do_overlay(v, maya, z):
    """
    Create a layer that overlay's the base frame layer.

    v: View
    maya: Maya
        NailPolish/Overlay

    z: layer
    Return: layer
        with overlay
    """
    j = v.j
    super_ = maya.super_maya
    z1 = super_.matter

    if z1:
        grow_sel(v, super_.value_d[ok.WRW][ok.WRAP_NP][ok.WIDTH])

        z = ROUTE_OVERLAY[maya.value_d[ok.TYPE]](v, maya, z)

        pdb.gimp_selection_none(j)
        edge(z)
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

    z.name = z.parent.name + " Overlay"
    return z


def grow_sel(v, a):
    """
    Make a frame from a selection.

    v: View
    maya: Maya
    a: float
        amount to expand selection
    """
    j = v.j
    is_sel, x, y, x1, y1 = get_select_bounds(j)

    if is_sel:
        x -= a
        y -= a
        w = x1 + a - x
        h = y1 + a - y
        select_rect(j, x, y, w, h)


def embellish(v, maya, z):
    """
    Is a callback from 'do_selection_material'.

    v: View
        not used

    maya: NailPolish
        not used

    z: layer
        to embellish

    Return: layer
        with embellishment
    """
    return z


class Overlay(SubBuild):
    """
    Process change for an overlay layer.
    Change its blend with its super Maya mask.
    """
    issue_q = 'overlay', 'mode', 'opacity'
    put = (check_overlay, 'matter'), (check_mix_overlay, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        v: View
        any_group: AnyGroup
            Is the responsible owner.

        super_maya: Maya
            Is the enclosing Maya, NailPolish.

        k_path: tuple
            (Option key, ...)
            Find the Overlay Preset structured sub-vote
            dict inside NailPolish's vote dict.
        """
        self.bg_z = None
        k_path1 = k_path + (ok.WRW, ok.OVERLAY_NP)

        SubBuild.__init__(self, any_group, super_maya, k_path1, prep_overlay)
        self.sub_maya[ok.BUMP] = Bump(any_group, self, k_path1 + (ok.BUMP,))

    def do(self, v, d, is_change, is_mask):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            If it is True, then a mask is drawn on the 'matter' layer.

        is_mask: bool
            Is True if the frame Maya has change.
        """
        self.value_d = d
        self.go = bool(self.super_maya.matter)
        self.is_overlay += is_change

        if d[ok.TYPE] == ff.BELOW:
            self.is_overlay += v.is_back

        self.realize(v)
        self.sub_maya[ok.BUMP].do(v, d[ok.BUMP], self.is_overlay)

        if self.go and (self.is_overlay or is_mask):
            mask_sub_maya(self.super_maya.matter, self.matter)
            mask_sub_maya(self.matter, self.sub_maya[ok.BUMP].matter)
        self.reset_issue()


class NailPolish(Build):
    """Make an overlay for material."""
    is_seeded = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_kind, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP_NP

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        Build.__init__(
            self,
            any_group,
            super_maya,
            k_path + (ok.WRW, ok.WRAP_NP),
            do_matter
        )

        self.sub_maya[OVERLAY] = Overlay(any_group, self, k_path)
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cast, self)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.OTHER)
        self.sub_maya[ok.BLUR_BELOW] = BlurBelow(
            any_group, self, k_path, ok.SRW
        )

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame Over Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[OVERLAY].do(
            v, d[ok.WRW][ok.OVERLAY_NP], self.is_matter, self.is_matter
        )

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], is_change, self.is_matter
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.sub_maya[ok.BLUR_BELOW].do(
            v, d[ok.SRW][ok.BLUR_BELOW], m or is_back, self.is_matter
        )
        self.reset_issue()
        return m


# {Overlay type: its make function}
ROUTE_OVERLAY = {
    ff.BELOW: apply_backdrop,
    ff.IMAGE: apply_image,
    ff.PATTERN: apply_pattern
}
