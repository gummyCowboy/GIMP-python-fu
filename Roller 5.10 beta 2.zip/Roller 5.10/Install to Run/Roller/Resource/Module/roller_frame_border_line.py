#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Metal, do_metal_wrap
from roller_maya_build import Build
from roller_maya_light import Light
from roller_maya_noise import Noise
from roller_maya_shadow import Shadow
from roller_view_real import LIGHT


class BorderLine(Metal):
    """Create a metallic-like frame."""

    def __init__(self, any_group, super_maya, k_path):
        """
        q: tuple
            Metal spec

        d: dict
            Metal spec
        """
        if isinstance(k_path, tuple):
            q = k_path
            q1 = [k_path, q + (ok.WRW, ok.WRAP,)]

        else:
            q = k_path[0]
            q1 = k_path + [q + (ok.WRW, ok.WRAP,)]

        Build.__init__(self, any_group, super_maya, q1, do_metal_wrap)

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, q + (ok.WRW, ok.NOISE_D)
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, q + (ok.WRW, ok.SHADOW), (self.cast, self)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[ok.NOISE_D].do(
            v, d[ok.WRW][ok.NOISE_D], is_change, self.is_matter
        )

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.WRW][ok.SHADOW], is_change, self.is_matter
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m
