#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_fu import desaturate, remove_z, select_rect
from roller_maya_style import Style
from roller_view_hub import (
    color_selection_default, get_average_color, invert_color
)
from roller_view_real import add_wip_base, clone_background, finish_style


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: AverageColor
    Return: layer or None
        style layer
    """
    # Is dependent.
    if maya.go:
        d = maya.value_d
        z = add_wip_base(v, "Average Color", maya.group)
        e = get_default_value(by.COLOR_FILL)

        e.update(d)

        z1 = clone_background(v, z)

        select_rect(v.j, *v.wip.rect)

        # RGB, 'q'
        q = get_average_color(z1)

        remove_z(z1)

        if d[ok.IDR][ok.INVERT]:
            q = invert_color(q)

        color_selection_default(z, q)

        if d[ok.IDR][ok.DESATURATE]:
            desaturate(z)
        return finish_style(z, "Average Color")


class AverageColor(Style):
    """Create Backdrop Style output."""
    is_dependent = True

    def __init__(self, any_group, super_maya, k_path):
        k_path = [k_path, k_path + (ok.IDR,)]
        Style.__init__(self, any_group, super_maya, k_path, make_style)
