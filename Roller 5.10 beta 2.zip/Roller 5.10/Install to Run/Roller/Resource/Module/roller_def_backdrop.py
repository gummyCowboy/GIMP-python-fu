#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Issue as vo
from roller_constant_key import BackdropStyle as by, Option as ok, Widget as wk
from roller_def_share import (
    MEAN_COLOR, BACKING, SWITCH, set_issue
)
from roller_one_extract import scour
from roller_widget_option_button import OptionListButton
from roller_port_option_list import PortStyle

BACKDROP = OrderedDict([
    (ok.BACKING, deepcopy(BACKING)),
    (ok.BACKDROP_STYLE, {
        wk.CHANGELESS: True,
        wk.DIALOG: PortStyle,
        wk.VAL: {
            ok.SWITCH: SWITCH[wk.VAL],
            by.MEAN_COLOR: scour({}, MEAN_COLOR, wk.VAL)
        },
        wk.WIDGET: OptionListButton
    })
])
set_issue(BACKDROP, (ok.BACKING,), vo.MATTER, ())
