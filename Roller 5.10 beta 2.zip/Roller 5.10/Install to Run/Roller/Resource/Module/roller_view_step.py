#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_key import (
    Item as ie, Option as ok, Step as sk, Widget as wk
)
from roller_one_the import The


def collect_step(d, render_key, step_q):
    """
    Recursively add navigation step key found in
    a hierarchical step dict to a list.

    d: dict
        with step key structure

    render_key: tuple
        (item, ...)

    step_q: list
        step key collection
    """
    k = render_key[-1]
    step_q += [render_key]
    if wk.ITEM in d[k]:
        for k1 in d[k][wk.ITEM]:
            collect_step(
                d[k][wk.ITEM],
                render_key + (k1,),
                step_q
            )


def extract_value_d(nav_k, d):
    """
    Get the Widget value dict for an AnyGroup.

    nav_k: tuple
        (sequenced navigation Node, ...)

    d: dict
        {navigation step key: AnyGroup}

    Return: dict
        {Option key: Widget value}
    """
    any_group = d[nav_k] if nav_k in d else None
    if any_group:
        return any_group.get_value_d()


def find_canvas_margin(nav_k):
    """
    For a Model, determine if a Canvas Margin step is active.

    nav_k: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(nav_k, (ie.CANVAS, ie.MARGIN)))


def find_canvas_shift(nav_k):
    """
    For a Model, determine if a Canvas Shift step is active.

    nav_k: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(nav_k, (ie.CANVAS, ie.SHIFT)))


def find_cell_margin(nav_k):
    """
    For a Model, determine if a Cell Margin step is active.

    nav_k: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(nav_k, sk.CELL_MARGIN))


def find_cell_shift(nav_k):
    """
    For a Model, determine if a Cell Shift step is active.

    nav_k: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(nav_k, sk.CELL_SHIFT))


def get_branch_value_d(nav_k):
    """
    Get a SuperPreset value dict.

    nav_k: tuple
        SuperPreset key in step dict

    Return: dict
        {step key: value}
    """
    d = {}
    helm = The.helm
    get_group = helm.get_group
    q = helm.get_branch_step_q(nav_k)

    for i in q:
        a = get_group(i)
        if a and a.item.group_type in ('node', 'preset'):
            d[i] = a.get_value_d()
    return d


def get_cell_shift(nav_k):
    """
    Get a Cell Shift Preset value dict.

    nav_k: tuple
        Has a Model reference.

    Return: dict
        Shift Preset
    """
    any_group = The.helm.get_group(make_model_key(nav_k, sk.CELL_SHIFT))
    if any_group:
        return any_group.get_value_d()


def get_planner(nav_k):
    """
    Get a Model's Cell / Rectangle Preset value dictionary.

    nav_k: tuple
        Is a navigation step key with a Model id reference.
    """
    return get_property_group(nav_k).widget_d[ok.PLANNER]


def get_model(nav_k):
    """
    Return the Model instance for a step key. If the step key
    is not part of a Model branch, then return None.

    nav_k: tuple
        step key
        Has a Model id in position one.

    Return: Model instance or None
    """
    if len(nav_k) >= 1:
        return The.model_id.get_model(nav_k[0])


def get_model_branch(nav_k):
    """
    Clip the branch from a step key.

    nav_k: tuple
        navigation step key

    Return: tuple
        any -> (Node key,), (Group key,), (Node key, Group key)
    """
    # By-pass the model reference index, '1'.
    return nav_k[1:]


def get_parent_node(nav_k):
    """
    Get the Node of a branched AnyGroup.
    The Node may not be in the interface step dict.

    nav_k: tuple
        of the branch group

    Return: Node or None
        for the branch group
    """
    k = nav_k[:-1]
    any_group = The.helm.get_group(k)

    if any_group:
        return any_group.item.node
    if len(k) == 1:
        return The.helm.get_group(sk.STEPS).item.node


def get_property_group(nav_k):
    return The.helm.get_group(make_model_key(nav_k, (ie.PROPERTY,)))


def get_step_d(step_q):
    """
    Get the navigation step key dict of a navigation step key list.

    step_q: list
        [navigation step key, ...]

    Return: dict
        {navigation step key: value dict}
    """
    # steps in the View, {step key: option value dict}, 'step_d'
    step_d = OrderedDict()

    get_group = The.helm.get_group

    for i in step_q:
        # AnyGroup, 'a'
        a = get_group(i)

        # Is a terminal point of this branch.
        if a and a.item.group_type in ('node', 'preset'):
            step_d[i] = a.get_value_d()
    return step_d


def make_model_key(k, q):
    """
    Given a Model branch key, append a key to it.

    k: tuple
        Is a Model branch.

    q: tuple
        any -> (Node key,), (Group key,), (Node key, Group key)
    """
    # A Model branch starts after the Model reference, '1'.
    return k[:1] + q


def make_panel_key(nav_k, model_name=None):
    """
    Make a panel-usable key from a step key.
    Swap the Model id with a Model name.

    nav_k: tuple
        navigation step key to an AnyGroup

    model_id: string or None
        Use to prefetch the Model name.

    Return: tuple
        NodePanel usable key
    """
    a = len(nav_k)

    if a < 1:
        # no Model
        return nav_k

    if model_name is None:
        model_name = The.model_id.get_name(nav_k[0])

    if model_name:
        return (model_name,) + nav_k[1:]

    # no model
    return nav_k


def make_render_key(nav_k, model_type):
    """
    Make a render step key from a step key. This is done
    by swapping the Model id for a Model type.

    nav_key: tuple
        for AnyGroup

    model_type: string
        Model type key
    """
    a = len(nav_k)

    if a < 1:
        # no Model
        return nav_k
    return (model_type,) + nav_k[1:]


def make_nav_key(nav_k):
    """
    Make a navigation step key from a render key. This
    is done by swapping the Model type with a Model id.

    nav_k: tuple
        for AnyGroup
        panel key

    Return: tuple
        nav_k
    """
    a = len(nav_k)

    if a < 1:
        # no Model
        return nav_k

    model_id = The.model_id.get_id(nav_k[0])

    if model_id:
        return (model_id,) + nav_k[1:]

    # no model
    return nav_k


def translate_to_id(d):
    """
    For a SuperPreset, translate a Model name to a Model id.

    d: dict
        of SuperPreset

    n: string
        Model name

    identity: int
        Is unique to a Model.

    Return: dict
        with step having translated name to identity
    """
    e = {}

    for k in d:
        e[make_nav_key(k)] = d[k]
    return e


def translate_to_name(d):
    """
    For a SuperPreset, replace numeric Model id
    with its corresponding Model name.

    d: dict
        of steps

    Return: dict
        with translation
    """
    e = {}

    for i, a in d.items():
        e[make_panel_key(i)] = a
    return e
