#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Issue as vo, Plan as fy, Shape as sh, Signal as si
)
from roller_constant_key import Model as md, Option as ok, Plan as ak
from roller_maya import MAIN, Maya, check_matter
from roller_fu import select_rect
from roller_one_the import The
from roller_option_group import ModelGroup
from roller_view_hub import color_selection_default
from roller_view_real import add_wip_layer, make_cast_group
from roller_view_step import find_cell_margin, find_cell_shift, get_planner
import gimpfu as fu

pdb = fu.pdb


def draw_grid(v, maya):
    """
    Draw line corresponding with a Model's row and column grid.

    v: View
    maya: Maya
    Return: layer or None
        with Grid
    """
    model = maya.model
    j = v.j
    row, column = model.division
    left, top, w, h = model.canvas_pocket.rect
    is_double = model.cell_shape in sh.DOUBLE
    is_indent = maya.value_d[ok.FCI] if ok.FCI in maya.value_d else False
    a = None

    pdb.gimp_selection_none(j)

    # Draw row line.
    for r in range(0, row):
        c = 0

        if is_double and r != row:
            c = not r % 2 if is_indent else r % 2
            c = min(column - 1, c)

        a = model.goo_d.get((r, c))
        if a:
            a = a.cell
            select_rect(j, left, a.y, w, 1., option=fu.CHANNEL_OP_ADD)

    if a:
        # Is the last row line, the enclosing row line.
        select_rect(j, left, a.y + a.h, w, 1., option=fu.CHANNEL_OP_ADD)

    a = None

    # Draw column line.
    for c in range(0, column):
        r = 0

        if is_double and c != column:
            r = not c % 2 if is_indent else c % 2
            r = min(row - 1, r)

        a = model.goo_d.get((r, c))
        if a:
            a = a.cell
            select_rect(j, a.x, top, 1., h, option=fu.CHANNEL_OP_ADD)

    if a:
        # Is the last line, the enclosing column line.
        select_rect(j, a.x + a.w, top, 1., h, option=fu.CHANNEL_OP_ADD)
    if not pdb.gimp_selection_is_empty(j):
        z = add_wip_layer(v, "Grid", maya.group)
        z.opacity = 66.

        color_selection_default(z, fy.GRID_COLOR)
        return z


class Type(ModelGroup):
    """
    Assign Plan and Work delegates for View run processing.
    Keep the Model up-to-date with Cell Type change.
    """

    def __init__(self, **d):
        ModelGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)
        baby = self.item.model.baby

        if self.item.model.model_type in md.ONE_CELL:
            self.handle_d[baby.connect(
                si.RECTANGLE_CALC, self.on_sequence_change
            )] = baby
            self.handle_d[
                The.power.connect(si.RESIZE, self.on_sequence)
            ] = The.power

        else:
            # Respond to Model's Canvas change.
            self.handle_d[baby.connect(
                si.CANVAS_MARGIN_CALC, self.on_sequence_change
            )] = baby
            if ok.PER in self.widget_d:
                self.handle_d[
                    self.widget_d[ok.PER].connect(
                        si.PER_CHANGE, self.update_model
                    )
                ] = self.widget_d[ok.PER]

        self.handle_d[
            self.booth.connect(si.VOTE_CHANGE, self.update_model)
        ] = self.booth
        self.handle_d[self.connect(si.SEQUENCE, self.on_sequence)] = self

    def do(self, v):
        """
        Override the AnyGroup function so that Past's View Signal can be sent.

        v: View
        """
        p = self.item.model.past.emit

        super(Type, self).do(v)
        p(si.CELL_RECT_VIEW, v.x)
        if (
            not find_cell_margin(self.nav_k) and
            not find_cell_shift(self.nav_k)
        ):
            p(si.CELL_SHIFT_VIEW, v.x)
            p(si.CELL_MARGIN_VIEW, v.x)

    def update_model(self, *_):
        """Respond to change in the Cell Type Preset."""
        self.item.model.baby.give(si.CELL_RECT_CHANGE, (self.value_d, False))

    def on_sequence(self, _, arg):
        """
        Update the Model.

        _: AnyGroup
            Sent the Signal

        arg: list
            [Plan vote, Work vote]
            not used
        """
        self.item.model.baby.feed(si.CELL_RECT_CHANGE, (self.value_d, True))


class Chi(Maya):
    """Factor Plan and Work layer output."""
    issue_q = 'matter', 'per'
    vote_type = MAIN

    def __init__(self, any_group, view_x, q):
        Maya.__init__(self, any_group, view_x, q)
        self.reset_issue()


class Plan(Chi):
    """Manage Draft and Plan layer output for the Cell/Type step."""

    def __init__(self, any_group):
        # Plan index, '0'
        Chi.__init__(
            self,
            any_group,
            0,
            ((make_cast_group, 'group'), (check_matter, 'matter'))
        )

        self.do_matter = draw_grid
        self.nav_k = any_group.nav_k
        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.GRID)

        self.set_issue()
        self.handle_d[
            planner.connect(fy.SIGNAL_D[ak.GRID], self.on_grid_plan_change)
        ] = planner

    def do(self, v):
        """Manage layer output during a View run."""
        self.go = self.is_planned
        self.realize_vote(v)

    def on_grid_plan_change(self, _, arg):
        """
        Receive a Signal when the Planner Grid option
        is activated. Update the 'go' dependency.

        _: PlanOption
            Sent the signal.

        arg: tuple
            (the value of the Margin CheckButton, its change state)
        """
        self.is_planned, m = arg

        self.any_group.accept_vote(0, ok.IS_PLANNED, vo.MATTER, m)
        self.take_vote(self.any_group.vote_q[0])


class Work(Chi):
    """
    Manage Peek, Preview, and final render layer output for the Cell/Type step.
    """
    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1, ())

    def do(self, v):
        """
        Update a Model's Type dependent state if there's change.

        v: VIew
            not used
        """
        self.reset_issue()
