#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame import Metal, do_metal_frame
from roller_one_gegl import antialias
from roller_one_the import The
import gimpfu as fu

pdb = fu.pdb


def make_pattern(z, d):
    """
    Make a pattern from a black and white mosaic.

    z: layer
        to receive pattern

    d: dict
        Wire Fence Preset
        {Option key: value}

    Return: layer
        with material
    """
    j = z.image

    pdb.plug_in_mosaic(
        j,
        z,
        d[ok.MESH_SIZE],
        1.,                                     # tile height
        d[ok.WIRE_THICKNESS],
        d[ok.NEATNESS],
        0,                                      # no split
        The.view.glow_ball.azimuth,
        .0,                                     # minimum color variation
        1,                                      # yes, antialias
        1,                                      # yes, average color
        ff.MESH_TYPE.index(d[ok.MESH_TYPE]),
        0,                                      # smooth surface
        0                                       # black and white grout
    )

    # Erase white pixel.
    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))

    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
        Has scope variables.

    maya: WireFence
    Return: layer
        with the frame
    """
    z = do_metal_frame(v, maya, make_pattern, ok.FILLER_WF)

    antialias(z)
    return z


class WireFence(Metal):
    """Create a metallic frame with wire filler."""

    def __init__(self, any_group, super_maya, k_path):
        Metal.__init__(
            self, any_group, super_maya, k_path, do_matter, ok.FILLER_WF
        )
