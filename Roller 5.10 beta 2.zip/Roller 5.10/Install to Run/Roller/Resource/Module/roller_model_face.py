#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_polygon import get_intersection


def make_h_face(v, maya):
    """
    Calculate the foam needed for a finished mold.
    The intersection of two lines make a foam vertex.
    First create four lines, then intersect them.

    v: View
    Return: tuple
        foam
        x, y float series in flag-shape order
        Each x, y pair is a polygon vertex.
    """
    q = maya.model.get_facing_foam(maya.k)
    foam_w = q[2] - q[0]
    foam_h = q[5] - q[1]
    merged = maya.model.get_facing_merged(maya.k)
    mold = v.pot.mold

    # rectangle offset percentage
    x_f = (mold.x - merged.x) / merged.w
    x1_f = x_f + mold.w / merged.w
    y_f = (mold.y - merged.y) / merged.h
    y1_f = y_f + mold.h / merged.h

    # six coordinates of four lines
    x = x_f * foam_w + q[0]
    x1 = x1_f * foam_w + q[0]
    y = y_f * foam_h + q[1]
    y1 = y1_f * foam_h + q[1]
    y2 = y_f * foam_h + q[3]
    y3 = y1_f * foam_h + q[3]

    # four lines that intersect
    line = (x, q[1]), (x, q[5])
    line_1 = (x1, q[1]), (x1, q[5])
    line_2 = (q[0], y), (q[2], y2)
    line_3 = (q[0], y1), (q[2], y3)

    # foam for mold, 'q1'
    q1 = []
    q1 += get_intersection(*line + line_2)
    q1 += get_intersection(*line_1 + line_2)
    q1 += get_intersection(*line + line_3)
    q1 += get_intersection(*line_1 + line_3)
    return q1


def make_v_face(v, maya):
    """
    Calculate the foam needed for a finished mold.
    The intersection of two lines make a foam vertex.
    First create four lines, then intersect them.

    v: View
    maya: Maya
    Return: tuple
        foam
        x, y float series in flag-shape order
        Each x, y pair is a polygon vertex.
    """
    q = maya.model.get_facing_foam(maya.k)
    foam_w = q[2] - q[0]
    foam_h = q[5] - q[1]
    merged = maya.model.get_facing_merged(maya.k)
    mold = v.pot.mold

    # rectangle height offset percentage, '*_f'
    y_f = (mold.y - merged.y) / merged.h
    y1_f = y_f + mold.h / merged.h

    # y-factor
    y = y_f * foam_h + q[1]
    y1 = y1_f * foam_h + q[1]
    y2 = y_f * foam_h + q[3]
    y3 = y1_f * foam_h + q[3]

    # x-slope
    slope = (q[1] - q[5]) / (q[0] - q[4])

    x = (y - q[1]) / slope + q[0]
    x1 = (y1 - q[1]) / slope + q[0]
    x2 = (y2 - q[1]) / slope + q[2] + foam_w
    x3 = (y3 - q[1]) / slope + q[2] + foam_w

    # line from NW to SE
    line = (x, y), (x2, y2)
    line_1 = (x1, y1), (x3, y3)

    # rectangle width offset percentage, '*_f'
    x_f = (mold.x - merged.x) / merged.w
    x1_f = x_f + mold.w / merged.w

    # x-factor
    x4 = x_f * foam_w + q[0]
    x5 = x1_f * foam_w + q[0]
    x6 = x_f * foam_w + q[4]
    x7 = x1_f * foam_w + q[4]

    # y-slope
    slope = (q[1] - q[3]) / (q[0] - q[2])
    y4 = slope * (x4 - q[0]) + q[1]
    y5 = slope * (x5 - q[0]) + q[1]
    y6 = slope * (x6 - q[4]) + q[5]
    y7 = slope * (x7 - q[4]) + q[5]

    # line from NE to SW
    line_2 = (x4, y4), (x6, y6)
    line_3 = (x5, y5), (x7, y7)

    # foam derived from the mold rectangle, 'q1'
    q1 = []
    q1 += get_intersection(*line + line_2)
    q1 += get_intersection(*line + line_3)
    q1 += get_intersection(*line_1 + line_2)
    q1 += get_intersection(*line_1 + line_3)
    return q1
