#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Are supplemental class module with a two letter import variable
# that are unique in the context of the program.
# As a consistency rule, two letter variables are either
# import classes, enumerated single letter typed variable names,
# or single letter typed variable names with an underscore.
from collections import OrderedDict
from roller_constant_key import Option as ok, Plan as ak
import gobject
import gtk

_AS_IS = "As Is"
_BELOW = "Below"
_CIRCLE = "Circle"
_CLOCKWISE, _COUNTER_CLOCKWISE = 0, 1
_CLOUDS = "Clouds"
_COLOR = "Color"
_COMPOSITE = "Composite"
_DIAMOND = "Diamond"
_ELLIPSE = "Ellipse"
_GRADIENT = "Gradient"
_HEXAGON = "Hexagon"
_HEXAGON_SHEAR = "Hexagon, Sheared"
_HEXAGON_TRUNCATED = "Hexagon, Truncated"
_HEXAGON_TRUNCATED_SHEAR = "Hexagon, Truncated, Sheared"
_IMAGE = "Image"
_LIST_SEPARATOR = "★"
_MEAN_COLOR = "Mean Color"
_MESH_TYPE = "Square", "Hexagon", "Octagon", "Triangle"
_MULTI_COLOR = "Multi-Color"
_NETTING = "Netting"
_OCTAGON = "Octagon"
_OCTAGON_SHEAR = "Octagon, Sheared"
_OCTAGON_ON_ITS_SIDE = "Octagon, On Its Side"
_OCTAGON_ON_ITS_SIDE_SHEAR = "Octagon, On Its Side, Sheared"
_PARALLELOGRAM_LEFT = "Parallelogram, Left"
_PARALLELOGRAM_RIGHT = "Parallelogram, Right"
_PATTERN = "Pattern"
_PLASMA = "Plasma"
_RECTANGLE = "Rectangle"
_SQUARE = "Square"
_SQUARE_MITERED = "Square, Mitered"
_TRIANGLE_DOWN_SHEAR = "Triangle, Down, Sheared"
_TRIANGLE_DOWN_REGULAR = "Triangle, Down, Regular"
_TRIANGLE_LEFT_SHEAR = "Triangle, Left, Sheared"
_TRIANGLE_LEFT_REGULAR = "Triangle, Left, Regular"
_TRIANGLE_RIGHT_SHEAR = "Triangle, Right, Sheared"
_TRIANGLE_RIGHT_REGULAR = "Triangle, Right, Regular"
_TRIANGLE_UP_SHEAR = "Triangle, Up, Sheared"
_TRIANGLE_UP_REGULAR = "Triangle, Up, Regular"
MAX_SIZE = 524288
MAX_SIZE_F = 524288.


class Backdrop:
    """Has values used by Backdrop Styles. Import as 'bs'."""
    CLOCKWISE, COUNTER_CLOCKWISE = _CLOCKWISE, _COUNTER_CLOCKWISE
    COLOR_GRID_TYPE = "Checkerboard", "Brick"
    RED = "Red"
    CLOUDS = _CLOUDS
    COLOR = _COLOR
    COMPONENT = RED, "Green", "Blue"
    DIAGONAL = "Diagonal"
    DIRECTION = "Clockwise", "Counter-Clockwise"
    DOT = "Dot"
    FLIP_BOTH = "Flip Both Axis"
    GRADIENT = _GRADIENT
    HORIZONTAL = "Horizontal"
    HORIZONTAL_FLIP = "Horizontal Flip"
    IMAGE = _IMAGE
    MESH_TYPE = _MESH_TYPE
    NEWS_TYPE = DOT, "Line", "Diamond", "Euclidean Dot", "PS-Diamond"
    PATTERN = _PATTERN
    PLASMA = _PLASMA
    POINT_KEY = {"Start X", "Start Y", "End X", "End Y"}
    SHIFT_DIRECTION = "Vertical", "Horizontal"
    SHOW_GRADIENT, SHOW_SAMPLE = 0, 1
    SQUARE = _SQUARE
    VERTICAL = "Vertical"
    VERTICAL_FLIP = "Vertical Flip"

    # dependent________________________________________________________
    BACKDROP_TYPE = CLOUDS, COLOR, GRADIENT, IMAGE, PATTERN, PLASMA
    SPIRAL_MOD_LIST = "None", HORIZONTAL_FLIP, VERTICAL_FLIP, FLIP_BOTH
    VECTOR = VERTICAL, HORIZONTAL, DIAGONAL
    # ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


class Border:
    """Has values used by the Fringe option group. Import as 'bo'."""
    PLASMA = _PLASMA
    TYPE = (
        _BELOW,
        _CLOUDS,
        _COLOR,
        _GRADIENT,
        _IMAGE,
        _MEAN_COLOR,
        _NETTING,
        _PATTERN,
        PLASMA
    )


class Bump:
    """Has values used by the Bump option group. Import as 'fb'."""
    CLOTH = "Cloth"
    CROSSHATCH = "Crosshatch"
    NANO = "Nano"
    NOISE = "Noise"
    HAS_BUMP = CLOTH, CROSSHATCH, NANO, NOISE
    HAS_NOISE = NANO, NOISE
    TYPE = CLOTH, CROSSHATCH, NANO, NOISE


class Caption:
    """Has values used by the Caption option group. Import as 'pt'."""
    IMAGE_NAME = "Image Name"
    SEQUENCE = "Sequence"
    TEXT = "Text"
    ALL_OPTION = IMAGE_NAME, SEQUENCE, TEXT
    NO_SEQUENCE_OPTION = IMAGE_NAME, TEXT
    TEXT_OPTION = TEXT,


class Color:
    """Has values used by color processing. Import as 'co'."""
    MAX_COLOR = 65535

    # colored button
    ACTIVE_COLOR = gtk.gdk.Color(55000, 55000, 0)
    CELL_COLOR = gtk.gdk.Color(55000, 55000, MAX_COLOR)
    CONNECTOR_COLOR = gtk.gdk.Color(52000, 52000, MAX_COLOR)
    CONNECTED_COLOR = gtk.gdk.Color(MAX_COLOR, 0, 0)
    FOCUS_COLOR = gtk.gdk.Color(50000, 44000, MAX_COLOR)

    HEADER_COLOR = 44000, 44000, MAX_COLOR
    LIST_CELL_COLOR = gtk.gdk.Color(51000, 61000, 50000)
    WHITE = gtk.gdk.Color(MAX_COLOR, MAX_COLOR, MAX_COLOR)
    MISSING_FILE = gtk.gdk.Color(MAX_COLOR, MAX_COLOR, MAX_COLOR // 2)

    # GTK Box
    COLOR_DEC = 1900
    INIT_COLOR = MAX_COLOR - COLOR_DEC


class Deco:
    """Has values used by Plaque, Fringe and Border. Import as 'dc'."""
    AS_IS = _AS_IS
    MEAN_COLOR = _MEAN_COLOR
    BELOW = _BELOW
    COLOR = _COLOR
    CLOUDS = _CLOUDS
    GRADIENT = _GRADIENT
    IMAGE = _IMAGE
    MULTI_COLOR = _MULTI_COLOR
    NETTING = _NETTING
    PATTERN = _PATTERN
    PLASMA = _PLASMA

    # branch type enum
    CANVAS, CELL, FACE = 0, 1, 2

    # Are Deco type that apply their material on one Preset at a time,
    PER_TYPE = {AS_IS, GRADIENT, IMAGE, MULTI_COLOR}

    ONE_IMAGE_TYPE = ok.NUMERIC_SEQUENCE, ok.FILE
    BACKED = {MEAN_COLOR, BELOW}


class Frame:
    """Are variable used by sub-Frame class. Import as 'ff'."""
    AQUA = "Aqua"
    BLUE = "Blue"
    PURPLE = "Purple"
    COMPOSITE = _COMPOSITE
    GREEN = "Green"
    YELLOW = "Yellow"
    RED = "Red"
    COMPONENT = {
        BLUE: (.0, 1., .0, .25),
        AQUA: (.0, 1., 1., 1.),
        PURPLE: (1., 1., .0, .25),
        COMPOSITE: (1., 1., 1., 1.),
        GREEN: (.0, .0, 1., 1.),
        YELLOW: (1., .0, 1., .5),
        RED: (1., .0, .0, .5)
    }
    CLOCKWISE, COUNTER_CLOCKWISE = _CLOCKWISE, _COUNTER_CLOCKWISE
    CLOUDS = _CLOUDS
    DARK = "Dark"
    INK = "Ink"
    MESH_TYPE = _MESH_TYPE
    PATTERN = _PATTERN
    PRISMATIC = "Prismatic"
    RANDOM_TYPE = 0
    SYRUPY = "Syrupy"

    # Paint Rush
    WHITE_HARD = "Hard Edge on White"
    WHITE_MIXED = "Mixed Edge on White"
    WHITE_SOFT = "Soft Edge on White"
    GREY_HARD = "Hard Edge on Grey"
    GREY_MIXED = "Mixed Edge on Grey"
    GREY_SOFT = "Soft Edge on Grey"
    PAINT_RUSH_TYPE = (
        WHITE_SOFT,
        WHITE_MIXED,
        WHITE_HARD,
        GREY_SOFT,
        GREY_MIXED,
        GREY_HARD
    )

    # Frame Type
    ANGULAR = "Angular"
    RECTANGLE = "Rectangle"
    ROUNDED = "Rounded"
    WRAP_TYPE_Q = ANGULAR, RECTANGLE, ROUNDED

    # dependent
    CAMO_TYPE = COMPOSITE, GREEN, RED, BLUE, AQUA, PURPLE, YELLOW
    RIFT = "Rift"
    SPECK = "Speck"
    WATER = "Water"
    NOISE_TYPE = INK, RIFT, SPECK, WATER

    # Button Row with Frame
    FRAME_ROW = ok.FRW, ok.MRW, ok.BRW

    BELOW = _BELOW
    BAND = "Band"
    BEVEL = "Bevel"
    COLOR = _COLOR
    EDGE = "Edge"
    FLAT_TOP = "Flat Top"
    GRADIENT = _GRADIENT
    IMAGE = _IMAGE
    M_SHAPE = "M-Shape"
    PLASMA = _PLASMA
    RAISE = "Raise"
    RING = "Ring"
    ROUND = "Round"
    RIPPLE = "Ripple"
    SINK = "Sink"
    U_SHAPE = "U-Shape"
    NAIL_POLISH = BELOW, IMAGE, PATTERN
    PROFILE = BAND, BEVEL, RAISE, ROUND, SINK
    CURVE = "None", EDGE, FLAT_TOP, M_SHAPE, RING, RIPPLE, U_SHAPE
    OVERLAY_TYPE = CLOUDS, COLOR, GRADIENT, IMAGE, PATTERN, PLASMA
    CURVE_DICT = {
        EDGE: (.0, .0, .5, .0, .5098, .0, .5215, .5215, 1., 1.),
        FLAT_TOP: (.0, .0, .7843, 1., 1., 1.),
        M_SHAPE: (.0, .0, .3294, .3294, .5, .0, .6588, .6588, 1., 1.),
        RING: (.0, .0, .4941, .4941, .9411, 1., .945, .2352, 1., .1176),
        RIPPLE: (.0, .0, .196, 1., .3921, .0, .5882, 1., .7843, .0, 1., 1.),
        U_SHAPE: (.0, 1., .5, .0, 1., 1.)
    }


class Fill:
    """
    Has values used by a fill process. Color Fill and
    Pattern Fill use criteria. Import as 'fl'.
    """
    COMPOSITE = _COMPOSITE
    CRITERION_LIST = (
        COMPOSITE,
        "Red",
        "Green",
        "Blue",
        "Hue",
        "Saturation",
        "Value",
        "Alpha",
        "LCH-Lightness",
        "LCH-Chroma",
        "LCH Hue"
    )


class Fringe:
    """Has values used by a Fringe option group. Import as 'ng'."""
    PLASMA = _PLASMA
    TYPE = (
        _AS_IS,
        _BELOW,
        _CLOUDS,
        _COLOR,
        _GRADIENT,
        _IMAGE,
        _MEAN_COLOR,
        _MULTI_COLOR,
        _NETTING,
        _PATTERN,
        PLASMA
    )


class Gradient:
    """Has values used by gradients. Import as 'fg'."""
    BOTTOM_CENTER_TO_TOP_CENTER = "Bottom-center to Top-center"
    BOTTOM_LEFT_TO_TOP_RIGHT = "Bottom-left to Top-right"
    BOTTOM_RIGHT_TO_TOP_LEFT = "Bottom-right to Top-left"
    CENTER_BOTTOM = "Center to Bottom-center"
    CENTER_LEFT = "Center to Center-left"
    CENTER_RIGHT = "Center to Center-right"
    CENTER_TOP = "Center to Top-center"
    CENTER_LEFT_TO_CENTER_RIGHT = "Center-left to Center-right"
    CENTER_RIGHT_TO_CENTER_LEFT = "Center-right to Center-left"
    LINEAR = "Linear"
    RADIAL = "Radial"
    SHAPED_ANGULAR = "Shaped (angular)"
    SHAPED_DIMPLED = "Shaped (dimpled)"
    SHAPED_SPHERICAL = "Shaped (spherical)"
    SPIRAL_CLOCKWISE = "Spiral-Clockwise"
    SPIRAL_COUNTER_CW = "Spiral-Counter-Clockwise"
    SQUARE = _SQUARE
    TOP_CENTER_TO_BOTTOM_CENTER = "Top-center to Bottom-center"
    TOP_LEFT_TO_BOTTOM_RIGHT = "Top-left to Bottom-right"
    TOP_RIGHT_TO_BOTTOM_LEFT = "Top-right to Bottom-left"
    GRADIENT_ANGLE = (
        CENTER_BOTTOM,
        CENTER_LEFT,
        CENTER_RIGHT,
        CENTER_TOP,
        TOP_LEFT_TO_BOTTOM_RIGHT,
        TOP_CENTER_TO_BOTTOM_CENTER,
        TOP_RIGHT_TO_BOTTOM_LEFT,
        BOTTOM_LEFT_TO_TOP_RIGHT,
        BOTTOM_CENTER_TO_TOP_CENTER,
        BOTTOM_RIGHT_TO_TOP_LEFT,
        CENTER_LEFT_TO_CENTER_RIGHT,
        CENTER_RIGHT_TO_CENTER_LEFT
    )

    # Translate a gradient angle into x, y factor pairs.
    # The key is a gradient angle.
    # The value is a tuple: (start x, end x, start y, end y) of factor values.
    GRADIENT_XY = {
        CENTER_BOTTOM: (.5, .5, .5, 1.),
        CENTER_LEFT: (.5, .0, .5, .5),
        CENTER_RIGHT: (.5, 1., .5, .5),
        CENTER_TOP: (.5, .5, .5, .0),
        TOP_LEFT_TO_BOTTOM_RIGHT: (.0, 1., .0, 1.),
        TOP_CENTER_TO_BOTTOM_CENTER: (.5, .5, .0, 1.),
        TOP_RIGHT_TO_BOTTOM_LEFT: (1., .0, .0, 1.),
        BOTTOM_LEFT_TO_TOP_RIGHT: (.0, 1., 1., .0),
        BOTTOM_CENTER_TO_TOP_CENTER: (.5, .5, 1., .0),
        BOTTOM_RIGHT_TO_TOP_LEFT: (1., .0, 1., .0),
        CENTER_LEFT_TO_CENTER_RIGHT: (.0, 1., .5, .5),
        CENTER_RIGHT_TO_CENTER_LEFT: (1., .0, .5, .5)
    }

    GRADIENT_TYPE_LIST = (
        LINEAR,
        "Bilinear",
        RADIAL,
        SQUARE,
        "Conical Symmetric",
        "Conical ASymmetric",
        SHAPED_ANGULAR,
        SHAPED_DIMPLED,
        SHAPED_SPHERICAL,
        SPIRAL_CLOCKWISE,
        SPIRAL_COUNTER_CW
    )
    SHAPED_TYPE = SHAPED_ANGULAR, SHAPED_DIMPLED, SHAPED_SPHERICAL


class GradientLight:
    """Has values used by GradientLight. Import as gl."""
    INFLUENCE_D = OrderedDict([
        (ok.BACKDROP, {ok.MODE: "Normal", ok.OPACITY: .0}),
        (ok.BORDER, {ok.MODE: "Hard Light", ok.OPACITY: .0}),
        (ok.FRINGE, {ok.MODE: "Linear Light", ok.OPACITY: .0}),
        (ok.IMAGE, {ok.MODE: "Normal", ok.OPACITY: .0}),
        (ok.LINE, {ok.MODE: "Normal", ok.OPACITY: .0}),
        (ok.METAL, {ok.MODE: "Hard Light", ok.OPACITY: .0}),
        (ok.OTHER, {ok.MODE: "Normal", ok.OPACITY: .0}),
        (ok.PLAQUE, {ok.MODE: "Overlay", ok.OPACITY: .0}),
        (ok.TRANSLUCENT, {ok.MODE: "Pin Light", ok.OPACITY: .0})
    ])
    INFLUENCE_KEY = INFLUENCE_D.keys()


class Grid:
    """Has values used by a Cell Type option group. Import as 'gr'."""
    CELL_COUNT = "Cell Count"
    CELL_SIZE = "Cell Size"
    SHAPE_COUNT = "Shape Count"
    TYPE_LIST = CELL_COUNT, CELL_SIZE, SHAPE_COUNT

    # pin
    TOP_LEFT = "Top-Left"
    TOP_RIGHT = "Top-Right"
    BOTTOM_LEFT = "Bottom-Left"
    BOTTOM_RIGHT = "Bottom-Right"
    CENTER = "Center"
    PIN_LIST = CENTER, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT

    # A fixed-sized table has a pin-point.
    PINS_WITH_X_OFFSET = CENTER, TOP_RIGHT, BOTTOM_RIGHT
    PINS_WITH_Y_OFFSET = CENTER, BOTTOM_LEFT, BOTTOM_RIGHT


class Justification:
    """Has values used by justification options. Import as 'ju'."""
    TOP_LEFT = "Top-Left"
    TOP_CENTER = "Top-Center"
    TOP_RIGHT = "Top-Right"
    LEFT_CENTER = "Left-Center"
    CENTER = "Center"
    RIGHT_CENTER = "Right-Center"
    BOTTOM_LEFT = "Bottom-Left"
    BOTTOM_CENTER = "Bottom-Center"
    BOTTOM_RIGHT = "Bottom-Right"
    TYPE = (
        CENTER,
        TOP_LEFT,
        TOP_CENTER,
        TOP_RIGHT,
        LEFT_CENTER,
        RIGHT_CENTER,
        BOTTOM_LEFT,
        BOTTOM_CENTER,
        BOTTOM_RIGHT
    )
    BOTTOM = BOTTOM_CENTER, BOTTOM_LEFT, BOTTOM_RIGHT
    CENTER_X = BOTTOM_CENTER, CENTER, TOP_CENTER
    CENTER_Y = CENTER, LEFT_CENTER, RIGHT_CENTER
    LEFT = BOTTOM_LEFT, LEFT_CENTER, TOP_LEFT
    RIGHT = BOTTOM_RIGHT, RIGHT_CENTER, TOP_RIGHT
    TOP = TOP_CENTER, TOP_LEFT, TOP_RIGHT


class Image:
    """Has values used by the Image option group. Import as 'fi'."""
    # Use with the file selector as a filter.
    EXTENSION = (
        ".xcf",
        ".jpg", ".jpeg", ".jpe", ".jif", ".jfif", ".jfi",
        ".png",
        ".gif", ".webp",
        ".tiff", ".tif",
        ".psd",
        ".raw", ".arw", ".cr2", ".nrw", ".k25",
        ".bmp", ".dib",
        ".jp2", ".j2k", ".jpx", ".jpm", ".mj2",
        ".ico",
        ".svg",
        ".pdf"
    )
    FIRST_IMAGE = "1st Image"
    IMAGE_TYPE_LIST = (
        ok.FILE,
        ok.FOLDER,
        ok.IMAGE_NAME,
        ok.LOOP_X,
        ok.NEXT_X,
        ok.NUMERIC_SEQUENCE,
        ok.PREVIOUS_X
    )
    LOOP_MINUS = "Loop-Minus"
    LOOP_PLUS = "Loop-Plus"
    FOLDER_ORDER_LIST = "Ascending (A to Z)", "Descending (Z to A)"
    LAYER_ORDER_LIST = "Bottom-Up", "Top-Down"
    NEXT = "Next"
    PREVIOUS = "Previous"
    SLICE_ORDER_LIST = "Top-Left to Bottom-Right", "Bottom-Right to Top-Left"

    # 'opened_image_d' value indices
    IMAGE_INDEX, LAYER_LIST_INDEX = 0, 1

    # file list indices for folder pile
    FILE_INDEX, FILTER_INDEX = 0, 1

    # index-ordered
    LOOP_TYPE = LOOP_PLUS, LOOP_MINUS


fi = Image


class Issue:
    """Identify output change-type. Double as a key. Import as 'vo'."""
    BLUR_BELOW = 'blur_below'
    OVERLAY = 'overlay'
    FILLER = 'filler'
    EMBOSS = 'emboss'
    INNER_SHADOW = 'inner_shadow'
    MATTER = 'matter'
    MODE = 'mode'
    OPACITY = 'opacity'
    NOISE = 'noise'
    NULL = 'null'
    PER = 'per'
    SEED = 'seed'
    SHADOW = 'shadow'
    SHADOW_1 = 'shadow_1'
    SHADOW_2 = 'shadow_2'
    MATTER_EMBOSS = MATTER, EMBOSS


class Mask:
    """Has values used by Mask options. Import as 'ms'."""
    CIRCLE = _CIRCLE
    CORNER = "Corner"
    CUT_CORNER = "Cut Corner"
    DARKS = "Darks"
    ELLIPSE = _ELLIPSE
    ELLIPSE_NOTCH = "Ellipse Notch"
    EYE = "Eye"
    EYE_OPENING = "Eye Opening"
    FRINGE = "Fringe"
    GRADIENT = _GRADIENT
    IMAGE = _IMAGE
    LIGHTS = "Lights"
    PARALLELOGRAM_LEFT = _PARALLELOGRAM_LEFT
    PARALLELOGRAM_RIGHT = _PARALLELOGRAM_RIGHT
    RECTANGLE_NOTCH = "Rectangle Notch"
    ROUNDED_CORNER = "Rounded Corner"
    TEXT = "Text"
    TRIANGLE = "Triangle"
    TRIANGLE_BOTTOM_LEFT = "Triangle, Bottom-Left"
    TRIANGLE_BOTTOM_RIGHT = "Triangle, Bottom-Right"
    TRIANGLE_TOPLEFT = "Triangle, Topleft"
    TRIANGLE_TOP_RIGHT = "Triangle, Top-Right"
    TRIANGLE_UP_REGULAR = _TRIANGLE_UP_REGULAR
    CORNER_TYPE_Q = (
        CUT_CORNER, ELLIPSE_NOTCH, RECTANGLE_NOTCH, ROUNDED_CORNER
    )
    HEXAGON_TYPE_Q = (
        _HEXAGON,
        _HEXAGON_SHEAR,
        _HEXAGON_TRUNCATED,
        _HEXAGON_TRUNCATED_SHEAR
    )
    OCTAGON_TYPE_Q = (
        _OCTAGON,
        _OCTAGON_SHEAR,
        _OCTAGON_ON_ITS_SIDE,
        _OCTAGON_ON_ITS_SIDE_SHEAR
    )
    RECTANGLE_TYPE_Q = (
        _RECTANGLE,
        _SQUARE,
        _SQUARE_MITERED
    )
    TRIANGLE_TYPE_Q = (
        TRIANGLE_BOTTOM_LEFT,
        TRIANGLE_BOTTOM_RIGHT,
        _TRIANGLE_DOWN_REGULAR,
        _TRIANGLE_DOWN_SHEAR,
        _TRIANGLE_LEFT_REGULAR,
        _TRIANGLE_LEFT_SHEAR,
        _TRIANGLE_RIGHT_REGULAR,
        _TRIANGLE_RIGHT_SHEAR,
        TRIANGLE_TOPLEFT,
        TRIANGLE_TOP_RIGHT,
        TRIANGLE_UP_REGULAR,
        _TRIANGLE_UP_SHEAR
    )
    TYPE = [
        CIRCLE,
        CORNER,
        DARKS,
        _DIAMOND,
        ELLIPSE,
        EYE,
        EYE_OPENING,
        FRINGE,
        GRADIENT,
        _HEXAGON,
        IMAGE,
        LIGHTS,
        _OCTAGON,
        PARALLELOGRAM_LEFT,
        PARALLELOGRAM_RIGHT,
        _RECTANGLE,
        TEXT,
        TRIANGLE
    ]
    FACE_TYPE = TYPE[:]
    for i in (DARKS, LIGHTS):
        FACE_TYPE.pop(FACE_TYPE.index(i))


class Model:
    """Has values used by one of the Model-types. Import as 'mo'."""
    MISSING_ITEM = "Roller {} can't find a {}, {}."

    # cell type
    CANVAS = 'canvas'


mo = Model


# Plan_________________________________________________________________________
class Plan:
    """Has values used by Plan. Import as 'fy'."""
    BACKGROUND_COLOR = 0, 0, 0

    # Items are:
    #   RGB
    #   Plan output color
    #   in layer z-order, bottom to top
    attr_q_ = (
        'CANVAS_LINE_COLOR',
        'CANVAS_MARGIN_COLOR',
        'CANVAS_PLAQUE_COLOR',
        'CANVAS_FRINGE_COLOR',
        'CANVAS_BORDER_COLOR',
        'CANVAS_LINE_COLOR',
        'CANVAS_STRIPE_COLOR',
        'GRID_COLOR',
        'SHAPE_COLOR',
        'CELL_MARGIN_COLOR',
        'CELL_PLAQUE_COLOR',
        'CELL_FRINGE_COLOR',
        'CELL_BORDER_COLOR',
        'CELL_LINE_COLOR',
        'CELL_STRIPE_COLOR',
        'FACE_PLAQUE_COLOR',
        'FACE_FRINGE_COLOR',
        'FACE_BORDER_COLOR',
        'FACE_LINE_COLOR',
        'FACE_STRIPE_COLOR'
    )

    # {PlanOption Widget key: its GObject signal}
    SIGNAL_D = {
        i: i.replace(" ", "_").lower() + '_plan_change' for i in ak.KEY
    }


# Set class attribute and its value from
# string as its less redundant (less code).
# R, G, B component, 'a'
a = 24

for n in Plan.attr_q_:
    setattr(Plan, n, (a, a, a))
    a += 4
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


class Plaque:
    """Has values used by the Plaque option group. Import as 'aq'."""
    PLASMA = _PLASMA
    TYPE = (
        _BELOW,
        _CLOUDS,
        _COLOR,
        _GRADIENT,
        _IMAGE,
        _MEAN_COLOR,
        _NETTING,
        _PATTERN,
        PLASMA
    )


class Preset:
    """Has values used by a Preset. Import as 'fp'."""
    DEFAULT = u"Default"
    PRESET_SEPARATOR = "★"


class Resize:
    """Has values used by the Resize Method. Import as 'fz'."""
    CROP = "Crop"
    FIXED = "Fixed Size"
    FACTOR = "Factor of Image Size"
    TEXT_TYPE = ok.COVER, ok.FILLED, ok.LOCKED, ok.TRIM
    RESIZE_TYPE_LIST = (
        ok.COVER,
        CROP,
        FACTOR,
        ok.FILLED,
        FIXED,
        ok.LOCKED,
        ok.TRIM
    )


class Triangle:
    """Has values used to describe triangles. Import as 'ft'."""
    # width/height ratios of an equilateral triangle
    SCALE_UP = 1.1547005

    # Is also the sine of 60 degrees.
    SCALE_DOWN = .8660254

    TRIANGLE_DOWN_SHEAR = _TRIANGLE_DOWN_SHEAR
    TRIANGLE_DOWN_REGULAR = _TRIANGLE_DOWN_REGULAR
    TRIANGLE_LEFT_SHEAR = _TRIANGLE_LEFT_SHEAR
    TRIANGLE_LEFT_REGULAR = _TRIANGLE_LEFT_REGULAR
    TRIANGLE_RIGHT_SHEAR = _TRIANGLE_RIGHT_SHEAR
    TRIANGLE_RIGHT_REGULAR = _TRIANGLE_RIGHT_REGULAR
    TRIANGLE_UP_SHEAR = _TRIANGLE_UP_SHEAR
    TRIANGLE_UP_REGULAR = _TRIANGLE_UP_REGULAR
    DOWN_TYPE = TRIANGLE_DOWN_SHEAR, TRIANGLE_DOWN_REGULAR
    RIGHT_TYPE = TRIANGLE_RIGHT_SHEAR, TRIANGLE_RIGHT_REGULAR
    TRIANGLE = (
        TRIANGLE_DOWN_SHEAR,
        TRIANGLE_DOWN_REGULAR,
        TRIANGLE_LEFT_SHEAR,
        TRIANGLE_LEFT_REGULAR,
        TRIANGLE_RIGHT_SHEAR,
        TRIANGLE_RIGHT_REGULAR,
        TRIANGLE_UP_SHEAR,
        TRIANGLE_UP_REGULAR
    )
    HORIZONTAL_TRIANGLE = (
        TRIANGLE_LEFT_SHEAR,
        TRIANGLE_LEFT_REGULAR,
        TRIANGLE_RIGHT_SHEAR,
        TRIANGLE_RIGHT_REGULAR
    )
    VERTICAL_TRIANGLE = (
        TRIANGLE_DOWN_SHEAR,
        TRIANGLE_DOWN_REGULAR,
        TRIANGLE_UP_SHEAR,
        TRIANGLE_UP_REGULAR
    )
    INVERTED = {
        TRIANGLE_DOWN_SHEAR: TRIANGLE_UP_SHEAR,
        TRIANGLE_DOWN_REGULAR: TRIANGLE_UP_REGULAR,
        TRIANGLE_LEFT_SHEAR: TRIANGLE_RIGHT_SHEAR,
        TRIANGLE_LEFT_REGULAR: TRIANGLE_RIGHT_REGULAR,
        TRIANGLE_RIGHT_SHEAR: TRIANGLE_LEFT_SHEAR,
        TRIANGLE_RIGHT_REGULAR: TRIANGLE_LEFT_REGULAR,
        TRIANGLE_UP_SHEAR: TRIANGLE_DOWN_SHEAR,
        TRIANGLE_UP_REGULAR: TRIANGLE_DOWN_REGULAR
    }


class Shape:
    """Has values used for shape processing. Import as 'sh'."""
    BOTTOM = "Bottom"
    BOX_HORZ = 'box horz'
    BOX_HORZ_SHEAR = 'box horz shear'
    BOX_VERT = 'box vert'
    BOX_VERT_SHEAR = 'box vert shear'
    CIRCLE = _CIRCLE
    CIRCLE_HORIZONTAL = "Circle, Horizontally Aligned"
    CIRCLE_VERTICAL = "Circle, Vertically Aligned"
    DIAMOND = _DIAMOND
    ELLIPSE = _ELLIPSE
    ELLIPSE_HORIZONTAL = "Ellipse, Horizontally Aligned"
    ELLIPSE_RATIO = .13466
    ELLIPSE_VERTICAL = "Ellipse, Vertically Aligned"
    ELLIPSE_LIST = ELLIPSE_HORIZONTAL, ELLIPSE_VERTICAL
    HEXAGON_SHEAR = _HEXAGON_SHEAR
    HEXAGON = _HEXAGON
    HEXAGON_TRUNCATED = _HEXAGON_TRUNCATED
    HEXAGON_TRUNCATED_SHEAR = _HEXAGON_TRUNCATED_SHEAR
    LEFT = "Left"
    OCTAGON = _OCTAGON
    OCTAGON_SHEAR = _OCTAGON_SHEAR
    OCTAGON_ON_ITS_SIDE_SHEAR = _OCTAGON_ON_ITS_SIDE_SHEAR
    OCTAGON_DOUBLE_SHEAR = "Octagon, Double-spaced, Sheared"
    OCTAGON_ON_ITS_SIDE = _OCTAGON_ON_ITS_SIDE
    OCTAGON_DOUBLE = "Octagon, Double-spaced"
    OCTAGON_RATIO = .2928932188

    # circumscribe radius = inscribe radius / OCTAGON_CIRCUMRADIUS_RATIO
    OCTAGON_CIRCUMRADIUS_RATIO = .93

    PARALLELOGRAM_ALT_LEFT = "Parallelogram, Alt-Left"
    PARALLELOGRAM_ALT_RIGHT = "Parallelogram, Alt-Right"
    PARALLELOGRAM_LEFT = _PARALLELOGRAM_LEFT
    PARALLELOGRAM_RIGHT = _PARALLELOGRAM_RIGHT
    PYRAMID = 'pyramid'
    RECTANGLE = _RECTANGLE
    REGULAR = (
        OCTAGON_SHEAR,
        OCTAGON_ON_ITS_SIDE_SHEAR,
        OCTAGON_ON_ITS_SIDE,
        OCTAGON_DOUBLE,
        RECTANGLE,
        _SQUARE
    )
    RIGHT = "Right"
    SQUARE = _SQUARE
    SQUARE_MITERED = _SQUARE_MITERED
    TOP = "Top"
    EQUILATERAL_BOX = HEXAGON, HEXAGON_TRUNCATED
    BOX_SHAPE_LIST = HEXAGON_SHEAR, HEXAGON_TRUNCATED_SHEAR
    BOX_TYPE = TOP, BOTTOM, LEFT, RIGHT
    CURVED = ELLIPSE_LIST + (
        CIRCLE, CIRCLE_HORIZONTAL, CIRCLE_VERTICAL, ELLIPSE
    )
    DOUBLE = (
        ELLIPSE_LIST +
        (
            DIAMOND,
            BOX_HORZ,
            BOX_HORZ_SHEAR,
            BOX_VERT,
            BOX_VERT_SHEAR,
            CIRCLE_VERTICAL,
            CIRCLE_HORIZONTAL,
            HEXAGON,
            HEXAGON_SHEAR,
            HEXAGON_TRUNCATED,
            HEXAGON_TRUNCATED_SHEAR,
            OCTAGON_DOUBLE_SHEAR,
            OCTAGON_DOUBLE,
            SQUARE_MITERED
        )
    )
    CELL_SHAPE_LIST = (
        RECTANGLE,
        CIRCLE,
        DIAMOND,
        ELLIPSE,
        HEXAGON_SHEAR,
        HEXAGON,
        HEXAGON_TRUNCATED_SHEAR,
        HEXAGON_TRUNCATED,
        OCTAGON_SHEAR,
        OCTAGON,
        OCTAGON_ON_ITS_SIDE_SHEAR,
        OCTAGON_ON_ITS_SIDE,
        _PARALLELOGRAM_LEFT,
        _PARALLELOGRAM_RIGHT,
        SQUARE_MITERED,
        SQUARE,
        _TRIANGLE_DOWN_SHEAR,
        _TRIANGLE_DOWN_REGULAR,
        _TRIANGLE_LEFT_SHEAR,
        _TRIANGLE_LEFT_REGULAR,
        _TRIANGLE_RIGHT_SHEAR,
        _TRIANGLE_RIGHT_REGULAR,
        _TRIANGLE_UP_SHEAR,
        _TRIANGLE_UP_REGULAR
    )
    EQUILATERAL_LIST = (
        CIRCLE_HORIZONTAL,
        CIRCLE_VERTICAL,
        HEXAGON,
        HEXAGON_TRUNCATED,
        OCTAGON,
        OCTAGON_ON_ITS_SIDE,
        OCTAGON_DOUBLE,
        SQUARE,
        SQUARE_MITERED,
        _TRIANGLE_DOWN_REGULAR,
        _TRIANGLE_LEFT_REGULAR,
        _TRIANGLE_RIGHT_REGULAR,
        _TRIANGLE_UP_REGULAR
    )
    SHAPE_LIST = (
        RECTANGLE,
        DIAMOND,
        ELLIPSE_HORIZONTAL,
        ELLIPSE_VERTICAL,
        HEXAGON_SHEAR,
        HEXAGON_TRUNCATED_SHEAR,
        OCTAGON_SHEAR,
        OCTAGON_ON_ITS_SIDE_SHEAR,
        OCTAGON_DOUBLE_SHEAR,
        PARALLELOGRAM_ALT_LEFT,
        PARALLELOGRAM_ALT_RIGHT,
        _PARALLELOGRAM_LEFT,
        _PARALLELOGRAM_RIGHT,
        _TRIANGLE_DOWN_SHEAR,
        _TRIANGLE_LEFT_SHEAR,
        _TRIANGLE_RIGHT_SHEAR,
        _TRIANGLE_UP_SHEAR
    )

    EQUILATERAL_TYPE = (
        CIRCLE,
        CIRCLE_HORIZONTAL,
        CIRCLE_VERTICAL,
        HEXAGON,
        HEXAGON_TRUNCATED,
        OCTAGON_ON_ITS_SIDE,
        OCTAGON_DOUBLE,
        OCTAGON,
        SQUARE,
        SQUARE_MITERED,
        _TRIANGLE_DOWN_REGULAR,
        _TRIANGLE_LEFT_REGULAR,
        _TRIANGLE_RIGHT_REGULAR,
        _TRIANGLE_UP_REGULAR
    )

    # Has an alternate ego.
    ALT_PARALLELOGRAM = {
        PARALLELOGRAM_ALT_LEFT: PARALLELOGRAM_ALT_RIGHT,
        PARALLELOGRAM_ALT_RIGHT: PARALLELOGRAM_ALT_LEFT
    }


class Signal:
    """Are custom signal. Import as 'si'."""
    ACCEPT_FOCUS = 'accept_focus'
    ACCEPT_WINDOW = 'accept_window'
    ADD_ITEM = 'add_item'
    BACK_CHANGE = 'back_change'
    CANCEL_WINDOW = 'cancel_window'
    CANVAS_MARGIN_CALC = 'canvas_margin_calc'
    CANVAS_MARGIN_CHANGE = 'canvas_margin_change'
    CANVAS_MARGIN_VIEW = 'canvas_margin_view'
    CANVAS_RECT_CALC = 'canvas_rect_calc'
    CANVAS_SHIFT_CHANGE = 'canvas_shift_change'
    CANVAS_SHIFT_CALC = 'canvas_shift_calc'
    CANVAS_SHIFT_VIEW = 'canvas_shift_view'
    CELL_MARGIN_CALC = 'cell_margin_calc'
    CELL_MARGIN_CHANGE = 'cell_margin_change'
    CELL_MARGIN_VIEW = 'cell_margin_view'
    CELL_RECT_CALC = 'cell_rect_calc'
    CELL_RECT_CHANGE = 'cell_rect_change'
    CELL_RECT_VIEW = 'cell_rect_view'
    CELL_SHIFT_CALC = 'cell_shift_calc'
    CELL_SHIFT_CHANGE = 'cell_shift_change'
    CELL_SHIFT_VIEW = 'cell_shift_view'
    CLOSE_VIEW_IMAGE = 'close_view_image'
    COLOR_CHANGE = 'color_change'
    DIALOG_CLOSE = 'dialog_close'
    DIALOG_DRAWN = 'dialog_drawn'
    DIALOG_OPEN = 'dialog_open'
    DISAPPEAR = 'disappear'
    DIVISION_CHANGE = 'division_change'
    EMBOSS_CHANGE = 'emboss_change'
    FONT_SIZE_CHANGE = 'font_size_change'
    GLOBAL_EMBOSS = 'global_emboss'
    GLOBAL_SEED = 'global_seed'
    GROUP_CHANGE = 'group_change'
    GROUP_VIEW = 'group_view'
    LIGHT_CHANGE = 'light_change'
    MODEL_CREATED = 'model_created'
    MODEL_MOVE = 'model_move'
    MODEL_NEW = 'model_new'
    MODEL_RENAME = 'model_rename'
    MODEL_REVISE = 'model_revise'
    PANEL_CHANGE = 'panel_change'
    PER_CHANGE = 'per_change'
    POWER_GONE = 'power_gone'
    PREVIEW = 'preview'
    RANDOMIZE = 'randomize'
    RECTANGLE_CALC = 'rectangle_calc'
    RECTANGLE_CHANGE = 'rectangle_change'
    RECTANGLE_VIEW = 'rectangle_view'
    RENAME = 'rename'
    RESIZE = 'resize'
    ROW_COUNT_CHANGE = 'row_count_change'
    SEED_CHANGE = 'seed_change'
    SELECT_ITEM = 'select_item'
    SEQUENCE = 'sequence'
    UPDATE_TREE = 'update_tree'
    UI_CHANGE = 'ui_change'
    VIEW_SIZE_CHANGE = 'view_size_change'
    VOTE_CHANGE = 'vote_change'
    WINDOW_SIZE_CHANGE = 'window_size_change'
    WINDOW_XY_CHANGE = 'window_xy_change'
    run_first = gobject.SIGNAL_RUN_FIRST, None, (gobject.TYPE_PYOBJECT,)
    run_last = gobject.SIGNAL_RUN_LAST, None, (gobject.TYPE_PYOBJECT,)
    BOOTH_D = {VOTE_CHANGE: run_first}
    FONT_SIZE_D = {FONT_SIZE_CHANGE: run_first}
    GROUP_D = {
        BACK_CHANGE: run_first,
        DISAPPEAR: run_first,
        GROUP_CHANGE: run_first,
        GROUP_VIEW: run_first,
        RANDOMIZE: run_first,
        SEQUENCE: run_first
    }
    IMAGE_D = {CLOSE_VIEW_IMAGE: run_first}
    MODEL_D = {
        CANVAS_MARGIN_CALC: run_first,
        CANVAS_MARGIN_CHANGE: run_first,
        CANVAS_RECT_CALC: run_first,
        CANVAS_SHIFT_CALC: run_first,
        CANVAS_SHIFT_CHANGE: run_first,
        CELL_MARGIN_CALC: run_first,
        CELL_MARGIN_CHANGE: run_first,
        CELL_RECT_CALC: run_first,
        CELL_RECT_CHANGE: run_first,
        CELL_SHIFT_CALC: run_first,
        CELL_SHIFT_CHANGE: run_first,
        DIVISION_CHANGE: run_first,
        RECTANGLE_CALC: run_first,
        RECTANGLE_CHANGE: run_first
    }
    NODE_D = {
        ADD_ITEM: run_first,
        SELECT_ITEM: run_first,
        UPDATE_TREE: run_first
    }
    PAST_D = {
        CANVAS_MARGIN_VIEW: run_first,
        CANVAS_SHIFT_VIEW: run_first,
        CELL_MARGIN_VIEW: run_first,
        CELL_RECT_VIEW: run_first,
        CELL_SHIFT_VIEW: run_first,
        RECTANGLE_VIEW: run_first
    }
    PER_D = {
        DISAPPEAR: run_first,
        PER_CHANGE: run_first
    }
    POWER_D = {
        GLOBAL_EMBOSS: run_first,
        GLOBAL_SEED: run_first,
        LIGHT_CHANGE: run_first,
        MODEL_CREATED: run_first,
        MODEL_MOVE: run_first,
        MODEL_NEW: run_first,
        MODEL_RENAME: run_first,
        MODEL_REVISE: run_first,
        PANEL_CHANGE: run_first,
        POWER_GONE: run_first,
        RENAME: run_first,
        RESIZE: run_first,
        ROW_COUNT_CHANGE: run_first,
        UI_CHANGE: run_first,
        VIEW_SIZE_CHANGE: run_first,
        WINDOW_SIZE_CHANGE: run_first,
        WINDOW_XY_CHANGE: run_first
    }
    PLANNER_D = {}
    RAINBOW_D = {COLOR_CHANGE: run_first}
    WINDOW_D = {
        ACCEPT_FOCUS: run_last,
        ACCEPT_WINDOW: run_last,
        CANCEL_WINDOW: run_last,
        DIALOG_CLOSE: run_last,
        DIALOG_DRAWN: run_last,
        DIALOG_OPEN: run_last,
        PREVIEW: run_last
    }
    for i, a in Plan.SIGNAL_D.items():
        PLANNER_D[a] = run_first


class Widget:
    """Has values used with Widget. Import as 'fw'."""
    LAST_USED = "Last Used"
    LIST_SEPARATOR = _LIST_SEPARATOR
    MARGIN = 4
    SCROLL_SPAN = 22
