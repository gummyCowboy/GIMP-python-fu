#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy, Signal as si
from roller_constant_key import Node as ny, Option as ok, Plan as ak
from roller_deco import make_deco_mask
from roller_deco_image import (
    do_main_cell,
    do_main_face,
    do_main_facing,
    do_canvas,
    do_cell,
    do_face,
    do_facing,
    i_make_main_face_mask,
    i_make_main_facing_mask,
    i_make_cell_face_mask,
    i_make_cell_facing_mask,
    mask_main_cell
)
from roller_maya import (
    MAIN,
    PER,
    CanvasRoute,
    CellRoute,
    FaceRoute,
    ImageRoll,
    assign_frame_image,
    assign_mask_image,
    check_matter,
    check_mix_basic
)
from roller_maya_blur_below import BlurBelow
from roller_maya_light import Light
from roller_maya_mask import Mask
from roller_maya_plan_detail import Detail
from roller_maya_plan_name import (
    draw_main_name,
    draw_canvas_name,
    draw_cell_name,
    draw_face_main_name,
    draw_face_per_name,
    draw_facing_main_name,
    draw_facing_per_name
)
from roller_one_image import get_image_ref
from roller_option_group import DecoGroup
from roller_view_option_list import Frame
from roller_view_real import (
    LIGHT, make_canvas_group, make_cast_group, remove_maya_z
)
from roller_view_step import get_planner


def assign_image(v, maya, p, q):
    """
    Assign image for the Cell branch. Has three images for each cell.

    v: View
    maya: Maya
    p: function
        Assign an Image, a Mask Image, and a Frame Image.

    q: list
        [(r, c) or (r, c, x), ...]
        [grid item reference]
    """
    d = maya.value_d
    per = d[ok.PER]

    # Main Maya's cell dict has sub-cell Maya reference, 'per_d'.
    per_d = maya.per_d

    for k in q:
        if k in per:
            e = per[k]
            this_maya = per_d[k]

        else:
            e = d
            this_maya = maya

        j, j1, j2 = p(v, e)

        # Determine if an image reference changed.
        if j != this_maya.get_image(k):
            this_maya.is_matter = True

        if j1 != this_maya.get_mask_image(k):
            this_maya.sub_maya[ok.MASK].is_matter = True

        if j2 != this_maya.get_frame_image(k):
            this_maya.sub_maya[ok.FRAME].is_matter = True

        # Store image reference.
        this_maya.set_image(k, j)
        this_maya.set_mask_image(k, j1)
        this_maya.set_frame_image(k, j2)


def assign_cell_image(v, maya):
    """
    Assign image for a cell.

    v: View
    maya: Maya
    """
    def _assign(_v, _d):
        """
        _v: View
        _d: dict
            Image Preset
            {Option key: value}

        Return: tuple
            (Image, Mask Image, Frame Image)
            any could be None
        """
        return assign_preset_source(_v, _d)
    assign_image(v, maya, _assign, maya.model.cell_q)


def assign_face_image(v, maya, is_face):
    """
    Assign Cell/Face image.

    v: View
    maya: Maya
    is_face: bool
        Is True if the Maya is the Face type.
    """
    def _assign(_v, _d):
        """
        _v: View
        _d: dict
            Image Preset
            {Option key: value}

        Return: tuple
            (Image, Mask Image, Frame Image)
            any could be None
        """
        return assign_preset_source(_v, _d, is_face=is_face)
    assign_image(v, maya, _assign, maya.model.face_q)


def assign_preset_source(v, d, is_face=False):
    """
    Assign an image, mask image, and frame image for an Image Preset.

    v: View
    d: dict
        Image Preset

    is_face: bool
        Is True when a Face Maya is calling.

    Return: tuple
        (Image or None, Image or None, Image or None)
        (the image, the mask image, the frame image)
    """
    e = d[ok.IRRW][ok.IMAGE_CHOICE]
    go = d[ok.SWITCH] and e[ok.SWITCH]
    a = get_image_ref(e, v.j_d) if go else None

    # If the primary image is None, then the
    # mask and frame are None, 'b, c'.
    b = c = None

    if a:
        b = assign_mask_image(v, d[ok.MRW][ok.MASK]) if go else None
        c = assign_frame_image(v, d[ok.MRW][ok.FRAME], is_face)
    return a, b, c


def assign_canvas_image(v, maya, d):
    """
    Assign image for the Canvas branch.

    v: View
    maya: Maya
    d: dict
        Image Preset
    """
    j, j1, j2 = assign_preset_source(v, d)

    if (
        j != maya.get_mask_image(None) or
        j1 != maya.get_image(None) or
        j2 != maya.get_frame_image(None)
    ):
        maya.is_matter = True

    maya.set_image(None, j)
    maya.set_mask_image(None, j1)
    maya.set_frame_image(None, j2)


class Image(DecoGroup):
    """
    Manage Image Preset layer output. Create Widget
    group and assign Plan and Work delegates. Connect
    Face/Facing to the Cell/Shift calculation Signal
    to update their change state.
    """

    def __init__(self, **d):
        DecoGroup.__init__(self, **d)

        node_k = self.nav_k[-2]
        self.plan = {
            ny.CANVAS: PlanCanvas,
            ny.CELL: PlanCell,
            ny.FACE: PlanFace,
            ny.FACING: PlanFacing
        }[node_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas,
            ny.CELL: WorkCell,
            ny.FACE: WorkFace,
            ny.FACING: WorkFacing
        }[node_k](self)
        baby = self.item.model.baby
        if node_k in (ny.FACE, ny.FACING):
            self.handle_d[
                baby.connect(si.CELL_SHIFT_CALC, self.on_cell_calc)
            ] = baby


class Chi(ImageRoll):
    """Factor from Plan and Work."""

    def __init__(
        self, any_group, view_x, make_mask, get_mask_d, q
    ):
        """
        view_x: int
            0 or 1
            Plan or Work index

        make_mask: function
            Call to manage Mask output for the matter layer.

        q: iterable
            Direct output.
        """
        ImageRoll.__init__(
            self,
            any_group,
            view_x,
            q,
            k_path=[
                (),
                (ok.IRRW, ok.IMAGE_CHOICE),
                (ok.IRRW, ok.RESIZE),
                (ok.FLIP_R,)
            ]
        )
        self.set_issue()
        self.sub_maya[ok.FRAME] = Frame(any_group, self, (ok.MRW, ok.FRAME))
        self.sub_maya[ok.MASK] = Mask(
            any_group, self, view_x, make_mask, get_mask_d, (ok.MRW, ok.MASK)
        )


class Plan(Chi):
    """Manage layer output for Draft and Plan views."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, make_mask, get_mask_d, draw_name):
        """
        any_group: AnyGroup
        make_mask: function
            Call to make a mask for the matter layer.

        get_mask_d: function
            Call to retrieve the Mask Preset from the Image Preset.

        draw_name: function or None
            Call to produce an image name text layer.
        """
        Chi.__init__(self, any_group, 0, make_mask, get_mask_d, self.put)

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.IMAGE)

        self.handle_d[
            planner.connect(fy.SIGNAL_D[ak.IMAGE], self.on_plan_option_change)
        ] = planner
        if draw_name:
            self.sub_maya[ak.NAME] = Detail(
                any_group, self, draw_name, ak.NAME
            )

    def bore(self, v):
        """
        Manage layer output during a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH]

        if self.go:
            if self.is_planned:
                self.is_matter |= self.is_switched
            else:
                # Produce a layer group and nothing else.
                # Plan Detail/name requires the layer group.
                remove_maya_z(self, 'matter')
                self.is_matter = False

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)

            self.sub_maya[ok.MASK].do(v, d[ok.MRW][ok.MASK])
            if ak.NAME in self.sub_maya:
                self.sub_maya[ak.NAME].do(v)

    def on_plan_option_change(self, _, arg):
        """Respond to change in the Planner's Image checkbox."""
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage Peek, Preview, and render view layer output."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, make_mask, get_mask_d):
        """
        v: View
        make_mask: function
            Call to make a mask layer.

        get_mask_d: function
            Is a callback to fetch a Mask Preset from the Image Preset.
        """
        Chi.__init__(self, any_group, 1, make_mask, get_mask_d, self.put)

        self.sub_maya[ok.BLUR_BELOW] = BlurBelow(any_group, self, (), ok.MRW)
        self.sub_maya[LIGHT] = Light(any_group, self, ok.IMAGE)

    def bore(self, v):
        """
        Manage layer output during a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH]
        is_back = v.is_back

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)
            is_change = self.is_matter or self.sub_maya[ok.MASK].is_matter

            if is_change:
                self.sub_maya[ok.MASK].do(v, d[ok.MRW][ok.MASK])

            is_back |= self.sub_maya[ok.FRAME].do(
                v, d[ok.MRW][ok.FRAME], is_change
            )

            self.sub_maya[ok.BLUR_BELOW].do(
                v, d[ok.MRW][ok.BLUR_BELOW], is_back, is_change
            )
            self.sub_maya[LIGHT].do(v, is_change)
            v.is_back |= is_back


class Main:
    """Is factored from Plan and Work for the Main window option settings."""
    vote_type = MAIN

    def __init__(self):
        return

    def get_mask_d(self):
        return self.any_group.value_d[ok.MRW][ok.MASK]


class WorkMain(Main, Work):
    """Manage layer output for the View/Work main option settings."""

    def __init__(self, *q, **d):
        """
        arg: tuple
            Work spec

        kwarg: dict
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *q + (self.get_mask_d,), **d)


# Canvas_______________________________________________________________________
class Cloth:
    """Is factored from Plan and Work Canvas Maya."""

    def __init__(self):
        self.do_matter = do_canvas

    def prep(self, v):
        """
        For every View, there is an Image. Assign image for a Canvas branch.

        v: View
        """
        assign_canvas_image(v, self, self.value_d)


class PlanCanvas(Main, Plan, CanvasRoute, Cloth):
    """Manage Plan/Canvas simulated layer output."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Main.__init__(self)
        Plan.__init__(
            self,
            any_group,
            make_deco_mask,
            self.get_mask_d,
            draw_canvas_name
        )
        CanvasRoute.__init__(self)
        Cloth.__init__(self)


class WorkCanvas(WorkMain, CanvasRoute, Cloth):
    """Manage Work/Canvas layer output."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        self.do_matter = do_canvas

        # for error test
        WorkMain.__init__(self, any_group, make_deco_mask)
        CanvasRoute.__init__(self)
        Cloth.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:
    """Factor Plan and Work Model/Cell Maya."""
    is_face = False

    def __init__(self):
        self.do_matter = do_main_cell

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_cell_image(v, self)


class PlanCell(Main, Plan, CellRoute, Cellular):
    """Manage Plan Cell output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Main.__init__(self)
        Plan.__init__(
            self, any_group, mask_main_cell, self.get_mask_d, draw_main_name
        )
        CellRoute.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, CellRoute, Cellular):
    """Manage Work Cell output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        WorkMain.__init__(self, any_group, mask_main_cell)
        CellRoute.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per__________________________________________________________________________
class Per:
    """Factor Cell, Face, and Facing Per Maya."""
    vote_type = PER

    def __init__(self, do_matter, k):
        self.do_matter = do_matter
        self.k = k

    def get_mask_d(self):
        d = self.per_group.get_cell_value(self.k)
        if d:
            return d[ok.MRW][ok.MASK]
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Plan Per Cell output."""
    is_face = False
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        Plan.__init__(
            self, any_group, make_deco_mask, self.get_mask_d, draw_cell_name
        )
        Per.__init__(self, do_cell, k)


class WorkCellPer(Work, Per):
    """Manage Work Per Cell output."""
    is_face = False
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            Has the Per Cell option.

        k: tuple
            (row, column)
            cell index and Goo key
        """
        Work.__init__(self, any_group, make_deco_mask, self.get_mask_d)
        Per.__init__(self, do_cell, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    """Factor from Plan and Work Face Maya."""
    is_face = True

    def __init__(self):
        self.do_matter = do_main_face

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_face_image(v, self, True)


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage Plan Face output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        self.do_matter = do_main_face

        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(
            self,
            any_group,
            i_make_main_face_mask,
            self.get_mask_d,
            draw_face_main_name
        )
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, FaceRoute):
    """Manage Work Face output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        self.do_matter = do_main_face

        Face.__init__(self)
        WorkMain.__init__(self, any_group, i_make_main_face_mask)
        FaceRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per Cell________________________________________________________________
class FacePer(Per):
    """Factor Plan and Work Face/Per Maya."""
    is_face = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacePer(Plan, FacePer):
    """Manage Plan Face/Per output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        k: tuple
            (row, column, face)
        """
        Plan.__init__(
            self,
            any_group,
            i_make_cell_face_mask,
            self.get_mask_d,
            draw_face_per_name
        )
        FacePer.__init__(self, do_face, k)


class WorkFacePer(Work, FacePer):
    """Manage Work Face/Per output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (row, column, face)
        """
        Work.__init__(self, any_group, i_make_cell_face_mask, self.get_mask_d)
        FacePer.__init__(self, do_face, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing_______________________________________________________________________
class Facing:
    """Factor Plan and Work Facing."""
    is_face = True

    def __init__(self):
        self.do_matter = do_main_facing

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_face_image(v, self, False)


class PlanFacing(Facing, Main, Plan, FaceRoute):
    """Manage Plan Facing layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Facing.__init__(self)
        Main.__init__(self)
        Plan.__init__(
            self, any_group,
            i_make_main_facing_mask,
            self.get_mask_d,
            draw_facing_main_name
        )
        FaceRoute.__init__(self, PlanFacingPer)


class WorkFacing(Facing, WorkMain, FaceRoute):
    """Manage Work Facing layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Facing.__init__(self)
        WorkMain.__init__(self, any_group, i_make_main_facing_mask)
        FaceRoute.__init__(self, WorkFacingPer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing Per Cell______________________________________________________________
class FacingPer(Per):
    """Factor Plan and Work Facing/Per Maya."""
    is_face = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacingPer(Plan, FacingPer):
    """Manage Plan Facing/Per layer output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(
            self,
            any_group,
            i_make_cell_facing_mask,
            self.get_mask_d,
            draw_facing_per_name
        )
        FacingPer.__init__(self, do_facing, k)


class WorkFacingPer(Work, FacingPer):
    """Manage Work Facing/Per layer output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        Create a Maya for Per Cell.

        k: tuple
            (r, c, 0); cell index; of int
        """
        Work.__init__(
            self, any_group, i_make_cell_facing_mask, self.get_mask_d
        )
        FacingPer.__init__(self, do_facing, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
