#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Caption as pt, Justification as ju, Model as mo
from roller_constant_key import Option as ok
from roller_deco import (
    get_obey_margins, ready_canvas_rect, ready_shape, transform_foam
)
from roller_fu import (
    add_layer,
    add_layer_below,
    clear_inverse_selection,
    get_select_coord,
    make_text_layer,
    merge_layer,
    remove_z,
    select_item,
    select_rect,
    select_shape,
    verify_layer_group
)
from roller_fu_comm import info_msg
from roller_one_the import The
from roller_view_contain import Pot
from roller_view_hub import color_selection_default
from roller_view_preset import calc_margin
from roller_view_real import add_wip_layer, make_group
import gimpfu as fu

pdb = fu.pdb


def do(v, maya, make):
    """
    Create Caption output. Plan overrides and restores its required option.

    v: View
    maya: Maya
    make: function
        Call to make the Caption material.
    """
    if not v.x:
        # Preserve.
        d = maya.value_d
        mode = d[ok.MODE]
        color = d[ok.FCR][ok.COLOR_1]

        # Override.
        d[ok.MODE] = "Normal"
        d[ok.FCR][ok.COLOR_1] = 255, 255, 255

    v.pot = Pot()
    z = make(v, maya)

    if not v.x:
        # Restore.
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
    return z


def do_canvas(v, maya):
    """
    Draw a Canvas branch Caption.

    v: View
    maya: Maya
    Return: layer or None
    """
    if maya.value_d[ok.TYPE] == pt.IMAGE_NAME:
        v.caption.image_name = maya.get_image_name(None)
    return do(v, maya, make_canvas)


def do_cell(v, maya):
    """
    Draw a Cell/Per Caption.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_per_cell)


def do_face(v, maya):
    """
    Draw a Face/Per Caption.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_face)


def do_facing(v, maya):
    """
    Draw a Facing/Per Caption.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_facing)


def do_main_cell(v, maya):
    """
    Draw cell material for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main)


def do_main_face(v, maya):
    """
    Draw Face.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_face)


def do_main_facing(v, maya):
    """
    Draw Facing.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_facing)


def fetch_rect(maya, k):
    """
    Retrieve a Maya's rectangle (Cell, Face, or Facing) using its Goo key.

    maya: Maya
    k: string
        Goo key

    Return: Rect or None
        as requested
    """
    if get_obey_margins(maya.value_d):
        # with Margin applied
        return maya.model.get_pocket(k).rect
    else:
        # with Shift applied
        return maya.model.get_shift_rect(k)


def finish_caption(z):
    """
    Ensure that a Caption layer size does not overflow an image size.

    z: layer or None
        (layer, dict)
        layer with material

    return: layer or None
        with material
    """
    if z:
        # Caption material overflow image bounds.
        pdb.gimp_layer_resize_to_image_size(z)
        return z


def make_canvas(v, maya):
    """
    Make Caption for the Canvas branch.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    # Set super Maya rect.
    ready_canvas_rect(v, maya, option=None)
    return finish_caption(
        make_caption_text(v, maya, maya.group, None)
    )


def make_canvas_stripe(v, maya):
    """
    Make a background Stripe for the Canvas Caption.

    v: View
    maya: Maya
    Return: layer or None
        with Caption material
    """
    ready_canvas_rect(v, maya.super_maya, option=None)

    maya.rect = maya.super_maya.rect
    return make_stripe(v, maya, maya.group)


def make_caption_text(v, maya, group, arg, seq_n=""):
    """
    Create text. Call once per Caption instance.

    v: View
    maya: Maya
    group: layer
        Is the parent of the text layer.

    arg: tuple or None
        key for storing text position and height

    seq_n: string
        Append to the sequence value.
        Is used by sub-Face.
        Is only applied if the Caption/Type is Sequence.

    Return: layer or None
        with Caption material
    """
    def _get_text():
        """
        Assemble the text as defined by the options.

        Return: string
            the Caption text
        """
        _text = ""
        type_ = d[ok.TYPE]

        if type_ == pt.TEXT:
            _text = d[ok.TEXT]

        elif type_ == pt.SEQUENCE:
            _text = str(
                maya.model.cell_q.index(maya.k[:2]) +
                int(maya.value_d[ok.START_NUMBER])
            ) + seq_n

        elif type_ == pt.IMAGE_NAME:
            _text = v.caption.image_name

        if type_ in (pt.IMAGE_NAME, pt.SEQUENCE) and _text:
            _n = d[ok.LTR][ok.LEAD]
            _n1 = d[ok.LTR][ok.TRAIL]
            _text = _n + _text + _n1
        return _text

    j = v.j

    # Caption failsafe layer, 'z'
    z = None

    d = maya.value_d
    go = True
    font = d[ok.FCR][ok.FONT]
    text = _get_text()
    color = d[ok.FCR][ok.COLOR_1]

    if font not in The.cat.font_list:
        info_msg(mo.MISSING_ITEM.format("Caption", "font", font))
        go = False

    if go:
        if text:
            go, z = make_text_layer(
                j,
                add_wip_layer(v, "Material", group),
                1,                          # yes, antialias
                text,
                d[ok.FONT_SIZE],
                font,
                color,
                .0, .0,                     # x, y
                .0, .0                      # w, h
            )
        else:
            go = False

    if go:
        select_item(z)
        pdb.plug_in_autocrop_layer(j, z)

        rect_x, rect_y, rect_w, rect_h = maya.rect
        x, y, x1, y1 = get_select_coord(j)
        text_w = x1 - x
        text_h = y1 - y
        half_w = text_w / 2.
        half_h = text_h / 2.
        top, bottom, left, right = calc_margin(v, d[ok.MSS][ok.MARGIN])

        # cell width, height
        w = max(1., rect_w - left - right)
        h = max(1., rect_h - top - bottom)
        n = d[ok.JUSTIFICATION]

        # cell position x, y
        x = rect_x + left
        y = rect_y + top

        # Get 'y'.
        if n in ju.BOTTOM:
            y += h - text_h

        elif n in ju.CENTER_Y:
            y += (h / 2.) - half_h

        # Get 'x'.
        if n in ju.RIGHT:
            x += w - text_w

        elif n in ju.CENTER_X:
            x += (w / 2.) - half_w

        # Move the text layer.
        pdb.gimp_layer_set_offsets(z, int(x), int(y))

        # Save the Cell's text selection for Stripe.
        maya.model.set_caption_y(arg, (y, z.height))

        if d[ok.OCR][ok.CLIP_TO_CELL]:
            select_shape(j, v.deco.shape)
            clear_inverse_selection(z)

    else:
        remove_z(z)
        z = None
    return z


def make_cell_face(v, maya):
    """
    Make Caption for Face/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_cell_facing(v, maya, make_face)


def make_cell_facing(v, maya):
    """
    Make Caption for Facing/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_cell_facing(v, maya, make_facing)


def make_cell_face_stripe(v, maya):
    """
    Make Stripe for Face/Per.

    v: View
    maya: Maya
        Per Cell

    Return: layer or None
        with Stripe material
    """
    return produce_cell_facing_stripe(v, maya, make_face_stripe)


def make_cell_facing_stripe(v, maya):
    """
    Make Stripe for Facing/Per.

    v: View
    maya: Maya
        Per Cell

    Return: layer or None
        with Stripe material
    """
    return produce_cell_facing_stripe(v, maya, make_facing_stripe)


def make_cell(v, maya, group, is_main=False):
    """
    Make Caption for Cell/Per.

    v: View
    maya: Maya
    group: layer
        Is the destination parent layer group of cell output.

    is_main: bool
        If True, then the output layer can skip the finish check.

    Return: layer or None
        with material
    """
    d = maya.value_d

    ready_shape(v, maya, option=None)

    if d[ok.TYPE] == pt.IMAGE_NAME:
        v.caption.image_name = maya.get_image_name(maya.k)

    z = make_caption_text(v, maya, group, maya.k)

    if is_main:
        return z
    return finish_caption(z)


def make_cell_stripe(v, maya):
    """
    Make a Cell/Per Stripe.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    a = maya.super_maya

    ready_shape(v,  a, option=None)

    maya.rect = a.rect
    maya.k = a.k
    return make_stripe(v, maya, maya.group)


def make_face(v, maya, group):
    """
    Apply Face material.

    v: View
    maya: Maya
    group: layer
        Is the parent of Face output.
    """
    k = maya.k
    model = maya.model
    d = maya.value_d
    maya.rect = model.get_facing_rect(k)
    v.deco.shape = model.get_facing_shape(k)

    if d[ok.TYPE] == pt.IMAGE_NAME:
        v.caption.image_name = maya.get_image_name(maya.k)

    # Face index position, '-1;
    z = make_caption_text(v, maya, group, k, seq_n="abc"[k[-1]])
    if z:
        # Set the layer size for the transform by
        # merging the text layer with a new layer.
        add_layer_below(z)

        z = merge_layer(z)
        transform_foam(v, maya.rect, z, model.get_facing_foam(k))


def make_facing(v, maya, group):
    """
    Apply Face material.

    v: View
    maya: Maya
    group: layer
        Is the parent of Face output.
    """
    k = maya.k
    model = maya.model
    maya.rect = model.get_facing_rect(k)
    v.deco.shape = model.get_facing_form(k)

    if maya.value_d[ok.TYPE] == pt.IMAGE_NAME:
        v.caption.image_name = maya.get_image_name(maya.k)

    z = make_caption_text(v, maya, group, k)
    if z:
        # Set the layer size for the transform by
        # merging the text layer with a new layer.
        add_layer_below(z)

        z = merge_layer(z)
        z = transform_foam(v, maya.rect, z, model.get_facing_foam(k))
        model.clip_facing(z, k)


def make_face_stripe(v, maya, group):
    """
    Create Face Stripe.

    v: View
    maya: Maya
    group: layer
        Is the destination of Face Stripe layer.

    Return: layer or None
        with Face Stripe
    """
    model = maya.model
    k = maya.k
    group = make_group(v, "Material", group)
    maya.rect = model.get_facing_rect(k)
    v.deco.shape = model.get_facing_shape(k)
    z = make_stripe(v, maya, group, is_finish=False)

    if z:
        transform_foam(v, maya.rect, z, model.get_facing_foam(k))
    return verify_layer_group(group)


def make_facing_stripe(v, maya, group):
    """
    Create Facing Stripe.

    v: View
    maya: Maya
    group: layer
        Is the destination of Facing Stripe layer.

    Return: layer or None
        with Facing Stripe
    """
    model = maya.model
    k = maya.k
    maya.rect = model.get_facing_rect(k)
    v.deco.shape = model.get_facing_form(k)
    z = make_stripe(v, maya, group, is_finish=False)
    if z:
        z = transform_foam(v, maya.rect, z, model.get_facing_foam(k))
        model.clip_facing(z, k)
        return z


def make_main(v, maya):
    """
    Draw Caption for the main option settings.
    Main combines Caption output into one layer.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    parent = maya.group
    group = make_group(v, "Material", parent, offset=len(parent.layers))

    for k in maya.main_q:
        maya.k = k
        make_cell(v, maya, group, is_main=True)
    return finish_caption(verify_layer_group(group))


def make_main_face(v, maya):
    """
    Make Caption for Face main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_main_facing(v, maya, make_face)


def make_main_facing(v, maya):
    """
    Make Caption for Face main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_main_facing(v, maya, make_facing)


def make_main_face_stripe(v, maya):
    """
    Make a Stripe for Face main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with Stripe material
    """
    return produce_main_facing_stripe(v, maya, make_face_stripe)


def make_main_facing_stripe(v, maya):
    """
    Make a Stripe for Facing main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with Stripe material
    """
    return produce_main_facing_stripe(v, maya, make_facing_stripe)


def make_main_stripe(v, maya):
    """
    Draw Stripe for the main option settings.
    Main combines Stripe output into one layer.

    v: View
    maya: Maya
        Stripe

    Return: layer or None
        with material
    """
    group = make_group(v, "Material", maya.group)
    a = maya.super_maya

    for k in a.main_q:
        maya.k = k
        maya.rect = fetch_rect(a, k)

        make_stripe(v, maya, group, is_finish=False)
    return finish_caption(verify_layer_group(group))


def make_per_cell(v, maya):
    """
    Is needed for its signature.

    v: View
    maya: Maya
    Return: layer or None
        with Caption text
    """
    return make_cell(v, maya, maya.group)


def make_stripe(v, maya, group, is_finish=True):
    """
    Create a background Stripe for a Caption.

    v: View
    maya: Maya
    group: layer
        Is the parent group for Stripe output.

    is_finish: bool
        When true, the Stripe layer is finish checked.

    Return: layer or None
        with material
    """
    k = maya.k
    d = maya.value_d
    q = maya.model.get_caption_y(k)
    if q:
        y, text_h = q
        j = v.j

        # A failed Stripe layer is None, 'z1'.
        z1 = None

        super_maya = maya.super_maya
        z = super_maya.matter
        if z:
            half_h = text_h // 2.
            center_y = y + half_h
            stripe_h = text_h * d[ok.HEIGHT]
            if stripe_h:
                y = center_y - stripe_h // 2.

                # A WIP layer fails, so go with a View sized layer.
                z1 = add_layer(j, group.name + " Material", parent=group)

                color = d[ok.COLOR_1]

                select_rect(j, maya.rect[0], y, maya.rect[2], stripe_h)

                if super_maya.value_d[ok.OCR][ok.CLIP_TO_CELL]:
                    select_shape(
                        j, v.deco.shape, option=fu.CHANNEL_OP_INTERSECT
                    )

                color_selection_default(z1, color)
                if is_finish:
                    finish_caption(z1)
        return z1


def produce_cell_facing(v, maya, p):
    """
    Make Caption for Facing/Per.

    v: View
    maya: Maya
    p: function
        Call to create cell Face/Facing.

    Return: layer or None
        with material
    """
    group = make_group(v, "Material", maya.group)

    p(v, maya, group)
    return finish_caption(verify_layer_group(group))


def produce_cell_facing_stripe(v, maya, p):
    """
    Make Stripe for a Per Cell Face/Facing.

    v: View
    maya: Maya
        Per Cell

    p: function
        Call to produce Stripe output.

    Return: layer or None
        with Stripe material
    """
    group = make_group(v, "Material", maya.group)
    maya.k = maya.super_maya.k

    p(v, maya, group)
    return verify_layer_group(group)


def produce_main_facing(v, maya, p):
    """
    Make Caption for Face main option settings.

    v: View
    maya: Maya
    p: function
        Call to make Facing.

    Return: layer or None
        with material
    """
    group = make_group(v, "Material", maya.group)

    for k in maya.main_q:
        maya.k = k
        p(v, maya, group)
    return finish_caption(verify_layer_group(group))


def produce_main_facing_stripe(v, maya, p):
    """
    Make a Stripe for Face main option settings.

    v: View
    maya: Maya
    p: function
        Call to make Face/Facing Stripe.

    Return: layer or None
        with Stripe material
    """
    group = make_group(v, "Material", maya.group)

    for k in maya.super_maya.main_q:
        maya.k = k
        p(v, maya, group)
    return finish_caption(verify_layer_group(group))
