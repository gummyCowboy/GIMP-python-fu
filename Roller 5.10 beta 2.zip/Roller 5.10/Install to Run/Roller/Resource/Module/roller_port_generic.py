#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_port_preview import PortPreview
from roller_widget_node import Piece


class PortGeneric(PortPreview):
    """Is a display container for a Preset."""

    def __init__(self, d, g, k):
        """
        g: OptionButton
            Is responsible.
        """
        self._preset_k = k
        PortPreview.__init__(self, d, g)

    def _draw(self, box):
        """
        Draw the Preset option group.

        box: GTK container
            to receive group
        """
        self.draw_group(Piece(
            self._preset_k, box, self.safe.any_group.item, has_label=False
        ))

    def draw(self):
        """Draw Widget."""
        self.draw_column((self._draw, self.draw_random_process_group))

    def get_group_value(self):
        """
        Get the Preset value dict.

        Return: dict
            Preset
        """
        return self.preset.get_a()


class PortBacking(PortGeneric):
    """Is a display container for a Background Preset."""
    window_key = "Backing"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, ok.BACKING)


class PortBlurBelow(PortGeneric):
    """Is a display container for a Blur Below Preset."""
    window_key = "Blur Below"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, ok.BLUR_BELOW)


class PortBrush(PortGeneric):
    """Is a display container for a Brush Group Preset."""
    window_key = "Brush"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, ok.BRUSH_D)


class PortBump(PortGeneric):
    """Is a display container for a Bump Preset."""
    window_key = "Bump"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, ok.BUMP)


class PortFiller(PortGeneric):
    """Is a display container for a Filler Preset."""
    window_key = "Filler"

    def __init__(self, d, g, k):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, k)


class PortMargin(PortGeneric):
    """Is a display container for a Margin Preset."""
    window_key = "Margin"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, ok.MARGIN)


class PortOverlay(PortGeneric):
    """Is a display container an Overlay Preset."""
    window_key = "Overlay"

    def __init__(self, d, g, k):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, k)


class PortCeramicChipFiller(PortFiller):
    """Is a display container for a Ceramic Chip Filler Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortFiller.__init__(self, d, g, ok.FILLER_CC)


class PortCirclePunchFiller(PortFiller):
    """Is a display container for a Circle Punch Filler Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortFiller.__init__(self, d, g, ok.FILLER_CP)


class PortLineFashionFiller(PortFiller):
    """Is a display container for a Line Fashion Filler Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortFiller.__init__(self, d, g, ok.FILLER_LF)


class PortLinkMirrorFiller(PortFiller):
    """Is a display container for a Link Mirror Filler Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortFiller.__init__(self, d, g, ok.FILLER_LM)


class PortCamoPlanetOverlay(PortOverlay):
    """Is a display container for a Camo Planet Overlay Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortOverlay.__init__(self, d, g, ok.OVERLAY_CP)


class PortColorOverlay(PortOverlay):
    """Is a display container for a Color Overlay Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortOverlay.__init__(self, d, g, ok.OVERLAY_CF)


class PortBoxyBevelOverlay(PortOverlay):
    """Is a display container for a Boxy Bevel Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortOverlay.__init__(self, d, g, ok.OVERLAY_CU)


class PortFrameOverOverlay(PortOverlay):
    """Is a display container for a Frame Over Overlay Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortOverlay.__init__(self, d, g, ok.OVERLAY_FO)


class PortNailPolishOverlay(PortOverlay):
    """Is a display container for a Nail Polish Overlay Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortOverlay.__init__(self, d, g, ok.OVERLAY_NP)


class PortResize(PortGeneric):
    """Is a display container for a Resize Preset."""
    window_key = "Resize"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, ok.RESIZE)


class PortWrap(PortGeneric):
    """Is a display container for a Wrap Preset."""
    window_key = "Wrap"

    def __init__(self, d, g, k=ok.WRAP):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, k)


class PortClearFrameWrap(PortWrap):
    """Is a display container for a Clear Frame Wrap Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortWrap.__init__(self, d, g, k=ok.WRAP_CF)


class PortColorBoardWrap(PortWrap):
    """Is a display container for a Color Board Wrap Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortWrap.__init__(self, d, g, k=ok.WRAP_CB)


class PortColorPipeWrap(PortWrap):
    """Is a display container for a Color Pipe Wrap Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortWrap.__init__(self, d, g, k=ok.WRAP_CP)


class PortCrumbleShellWrap(PortWrap):
    """Is a display container for a Crumble Shell Wrap Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortWrap.__init__(self, d, g, k=ok.WRAP_CS)


class PortBoxyBevelWrap(PortWrap):
    """Is a display container for a Boxy Bevel Wrap Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortWrap.__init__(self, d, g, k=ok.WRAP_CU)


class PortNailPolishWrap(PortWrap):
    """Is a display container for a Nail Polish Wrap Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortWrap.__init__(self, d, g, k=ok.WRAP_NP)


class PortNoise(PortGeneric):
    """Is a display container for a Noise Preset."""
    window_key = "Noise"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, ok.NOISE_D)


class PortRaisedMazeFiller(PortFiller):
    """Is a display container for a Raised Maze Filler Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortFiller.__init__(self, d, g, ok.FILLER_RM)


class PortRadWaveFiller(PortFiller):
    """Is a display container for a Rad Wave Filler Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortFiller.__init__(self, d, g, ok.FILLER_RW)


class PortShadowBasic(PortGeneric):
    """Is a display container for a Shadow Basic Preset."""
    window_key = "Shadow Basic"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, ok.SHADOW_BASIC)


class PortSquareCutFiller(PortFiller):
    """Is a display container for a Square Cut Filler Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortFiller.__init__(self, d, g, ok.FILLER_SC)


class PortSquarePunchFiller(PortFiller):
    """Is a display container for a Square Punch Filler Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortFiller.__init__(self, d, g, ok.FILLER_SP)


class PortStainedGlassFiller(PortFiller):
    """Is a display container for a Stained Glass Filler Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortFiller.__init__(self, d, g, ok.FILLER_SG)


class PortStencil(PortGeneric):
    """Is a display container for a Stencil Preset."""
    window_key = "Stencil"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, ok.STENCIL)


class PortStretchTrayFiller(PortFiller):
    """Is a display container for a Stretch Tray Filler Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortFiller.__init__(self, d, g, ok.FILLER_ST)


class PortStripe(PortGeneric):
    """Is a display container for a Stripe Preset."""
    window_key = "Stripe"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, ok.STRIPE)


class PortTape(PortGeneric):
    """Is a display container for a Tape Preset."""
    window_key = "Tape"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortGeneric.__init__(self, d, g, ok.TAPE)


class PortWireFrameFiller(PortFiller):
    """Is a display container for a Wire Frame Filler Preset."""

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortFiller.__init__(self, d, g, ok.FILLER_WF)
