#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy, Signal as si
from roller_constant_key import Node as ny, Option as ok, Plan as ak
from roller_deco_border import (
    do_facing,
    do_main_cell,
    do_main_face,
    do_main_facing,
    do_canvas,
    do_cell,
    do_face
)
from roller_maya import (
    MAIN,
    PER,
    Canvas,
    FaceRoute,
    Cell,
    Plasma,
    assign_image,
    check_matter,
    check_mix_basic,
    take_type_vote
)
from roller_maya_blur_below import BlurBelow
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_option_group import DecoGroup
from roller_view_option_list import Frame
from roller_view_real import LIGHT, make_canvas_group, make_cast_group
from roller_view_step import get_planner


class Border(DecoGroup):
    """
    Create Widget group, assign a View processor,
    and connect responsible signal handler.
    """

    def __init__(self, **d):
        DecoGroup.__init__(self, **d)

        node_k = self.nav_k[-2]
        self.plan = {
            ny.CANVAS: PlanCanvas,
            ny.CELL: PlanCell,
            ny.FACE: PlanFace,
            ny.FACING: PlanFacing
        }[node_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas,
            ny.CELL: WorkCell,
            ny.FACE: WorkFace,
            ny.FACING: WorkFacing
        }[node_k](self)
        baby = self.item.model.baby
        if node_k in (ny.FACE, ny.FACING):
            self.handle_d[
                baby.connect(si.CELL_SHIFT_CALC, self.on_cell_calc)
            ] = baby


class Chi(Plasma):
    """Factor Plan and Work."""

    def __init__(self, any_group, view_x, q):
        """
        q: iterable
            of function for producing View output
        """
        Plasma.__init__(
            self,
            any_group,
            view_x,
            q,
            k_path=[(), ((ok.IMAGE_CHOICE,), (ok.OCR,), (ok.BRW,))]
        )
        self.set_issue()


class Plan(Chi):
    """Manage Plan layer output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, self.put)

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.BORDER)
        self.handle_d[
            planner.connect(fy.SIGNAL_D[ak.BORDER], self.on_plan_option_change)
        ] = planner

    def bore(self, v):
        """
        Manage layer output during a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned

        if self.go:
            self.is_matter |= self.is_switched
        self.realize(v)

    def on_plan_option_change(self, _, arg):
        """Respond to change in PlanOption."""
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage layer output for a Peek, Preview, and render view."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1, self.put)

        self.sub_maya[ok.FRAME] = Frame(any_group, self, (ok.BRW, ok.FRAME))
        self.sub_maya[ok.BUMP] = Bump(any_group, self, (ok.BRW, ok.BUMP))
        self.sub_maya[ok.BLUR_BELOW] = BlurBelow(any_group, self, (), ok.BRW)
        self.sub_maya[LIGHT] = Light(any_group, self, ok.BORDER)
        self.handle_d[
            self.any_group.connect(si.BACK_CHANGE, self.on_back_change)
        ] = self.any_group

    def bore(self, v):
        """
        Manage layer output during a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH]
        is_back = v.is_back

        if self.go:
            self.is_matter |= take_type_vote(v, d)

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)

            self.sub_maya[ok.BUMP].do(v, d[ok.BRW][ok.BUMP], self.is_matter)

            if not self.is_face:
                is_back |= self.sub_maya[ok.FRAME].do(
                    v, d[ok.BRW][ok.FRAME], self.is_matter
                )

            self.sub_maya[ok.BLUR_BELOW].do(
                v, d[ok.BRW][ok.BLUR_BELOW], is_back, self.is_matter
            )
            self.sub_maya[LIGHT].do(v, self.is_matter)
            v.is_back |= is_back


class Main:
    """Identify the Maya as main."""
    vote_type = MAIN

    def __init__(self):
        return


class WorkMain(Main, Work):
    """Is for main window option."""

    def __init__(self, *arg):
        """
        arg: tuple
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *arg)


# Canvas_______________________________________________________________________
class Cloth:
    """Factor Plan and Work Canvas."""

    def __init__(self):
        self.do_matter = do_canvas


class PlanCanvas(Plan, Canvas, Main, Cloth):
    """Manage simulated Plan/Canvas/Border layer output."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Plan.__init__(self, any_group)
        Canvas.__init__(self)
        Main.__init__(self)
        Cloth.__init__(self)


class WorkCanvas(WorkMain, Canvas, Cloth):
    """Manage simulated Work/Canvas/Border layer output."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        WorkMain.__init__(self, any_group)
        Canvas.__init__(self)
        Cloth.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


class Cellular:
    """Factor Plan and Work Cell."""
    is_face = False

    def __init__(self):
        self.do_matter = do_main_cell


class PlanCell(Plan, Main, Cell, Cellular):
    """Use to manage Plan/Cell layer output."""
    is_face = False
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Plan.__init__(self, any_group)
        Main.__init__(self)
        Cell.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, Cell, Cellular):
    """Use to manage Work/Cell layer output."""
    is_face = False
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        WorkMain.__init__(self, any_group)
        Cell.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per__________________________________________________________________________
class Per:
    """Factor Plan and Work Per."""
    vote_type = PER

    def __init__(self, do_matter, k):
        """
        do_matter: function
            Call to produce layer output.

        k: tuple
            (row, column)
            cell index; Goo key
        """
        self.do_matter = do_matter
        self.k = k
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell/Per_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Use to manage Plan/Cell/Per layer output."""
    is_face = False
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int; Goo key
        """
        Plan.__init__(self, any_group)
        Per.__init__(self, do_cell, k)


class WorkCellPer(Work, Per):
    """Use to manage Work/Cell/Per layer output."""
    is_face = False
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        Create a layer output for Per Cell.

        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group)
        Per.__init__(self, do_cell, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    """Factor Plan and Work Face."""
    is_face = True

    def __init__(self):
        self.do_matter = do_main_face

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_image(v, self, self.model.face_q)


class PlanFace(Face, Plan, Main, FaceRoute):
    """Manage Plan/Face layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        self.do_matter = do_main_face

        Face.__init__(self)
        Plan.__init__(self, any_group)
        Main.__init__(self)
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, FaceRoute):
    """Manage Work/Face layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            with Face options
        """
        self.do_matter = do_main_face

        Face.__init__(self)
        WorkMain.__init__(self, any_group)
        FaceRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face/Per_____________________________________________________________________
class FacePer(Per):
    """Factor Plan and Work Face/Per."""
    is_face = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacePer(Plan, FacePer):
    """Use to manage Plan/Face/Per layer output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        k: tuple
            grid cell index
            (row, column, face)
            of int
        """
        Plan.__init__(self, any_group)
        FacePer.__init__(self, do_face, k)


class WorkFacePer(Work, FacePer):
    """Manage Work/Face/Per layer output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            grid cell index
            (row, column, face)
            of int
        """
        Work.__init__(self, any_group)
        FacePer.__init__(self, do_face, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing_______________________________________________________________________
class Facing:
    """Factor Plan and Work Facing."""
    is_face = False

    def __init__(self):
        self.do_matter = do_main_facing

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_image(v, self, self.model.face_q)


class PlanFacing(Facing, Main, Plan, FaceRoute):
    """Manage Plan/Facing output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Facing.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group)
        FaceRoute.__init__(self, PlanFacingPer)


class WorkFacing(Facing, WorkMain, FaceRoute):
    """Manage Work/Facing output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Facing.__init__(self)
        WorkMain.__init__(self, any_group)
        FaceRoute.__init__(self, WorkFacingPer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing/Per___________________________________________________________________
class FacingPer(Per):
    """Factor Plan and Work Facing/Per."""
    is_face = False

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacingPer(Plan, FacingPer):
    """Manage Plan/Facing/Per output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group)
        FacingPer.__init__(self, do_facing, k)


class WorkFacingPer(Work, FacingPer):
    """Manage Work/Facing/Per layer output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        Create a Maya for Per Cell.

        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group)
        FacingPer.__init__(self, do_facing, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
