#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame import Filler, grow_frame, do_metal_sel
from roller_fu import (
    apply_mask,
    clone_layer,
    clone_opaque_layer,
    discard_mask,
    load_selection,
    make_layer_group,
    merge_layer,
    merge_layer_group,
    remove_z,
    select_item,
    set_saturation
)
from roller_maya import check_matter, check_mix_wrap, make_group_wrap
from roller_maya_build import Build
from roller_maya_light import Light
from roller_maya_noise import Noise
from roller_maya_shadow import Shadow
from roller_one_gegl import emboss
from roller_one_the import The
from roller_view_real import (
    FILLER,
    LIGHT,
    add_wip_layer,
    clip_to_wip,
    get_light,
    get_noise,
    mask_sel
)
import gimpfu as fu

pdb = fu.pdb


def do_filler(v, maya):
    """
    Draw filler layer.

    v: View
    maya: StretchTray
    Return: layer
        with filler material
    """
    j = v.j

    # source layer, 'z'
    z = clone_opaque_layer(maya.cast.matter, n="Left")

    if (
        z.width != v.wip.w or
        z.height != v.wip.h or
        z.offsets != v.wip.position
    ):
        clip_to_wip(v, z)

    if z.mask:
        apply_mask(z)

    group = make_layer_group(
        j, "Stretch", parent=maya.group, z=z, offset=get_light(maya)
    )

    apply_mask(z)
    pdb.gimp_selection_none(j)

    for x, z1 in enumerate((
        z,
        clone_layer(z, n="Right"),
        clone_layer(z, n="Top"),
        clone_layer(z, n="Bottom")
    )):
        pdb.plug_in_wind(
            j, z1,
            .0,                 # Threshold All
            x,                  # direction
            100,                # maximum strength
            0,                  # wind algorithm
            1,                  # leading edge
        )

        # threshold all pixel, '.0'
        pdb.plug_in_threshold_alpha(j, z1, .0)

    # Make the wind output opaque.
    z1 = merge_layer_group(group)
    z = clone_opaque_layer(z1)

    remove_z(z1)
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .25, 1., .75)
    )
    set_saturation(z, maya.value_d[ok.SATURATION])

    z1 = clone_layer(z, n="Hard Light")
    z1.mode = fu.LAYER_MODE_HARDLIGHT
    z1.opacity = 80.

    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .45, 1., .54)
    )

    # depth, '3'
    emboss(z, v.glow_ball.azimuth, v.glow_ball.elevation, 3)

    z = merge_layer(z1)
    z.name = z.parent.name + " Stretch Tray"
    return z


def do_frame(v, maya):
    """
    Create a wrap type frame around the cast and the Filler.

    v: View
    maya: Frame
    Return: layer
        with Frame/Wrap
    """
    j = v.j
    d = maya.value_d[ok.WRW][ok.FILLER_ST]

    maya.sub_maya[FILLER].do(v, d, maya.is_change, maya.is_matter)
    make_1st_frame_sel(v, maya)

    first_sel = pdb.gimp_selection_save(j)
    second_sel = make_2nd_frame_sel(v, maya)

    # layer for the emboss, 'z'
    z = add_wip_layer(
        v, "Stretch Tray", maya.group, offset=get_light(maya) + get_noise(maya)
    )

    # Begin merging selection.
    load_selection(j, first_sel)

    # Remove overlapping selection.
    load_selection(j, second_sel, option=fu.CHANNEL_OP_SUBTRACT)

    # There are two selections merged without overlap.
    load_selection(j, second_sel, option=fu.CHANNEL_OP_ADD)

    # Finish the frame.
    # 'matter' layer, 'z'
    z = do_metal_sel(v, z, maya.value_d[ok.WRW][ok.WRAP])

    for i in (first_sel, second_sel):
        pdb.gimp_image_remove_channel(j, i)
    return z


def make_1st_frame_sel(v, maya):
    """
    Make an inner and outer metallic frame.

    v: View
    maya: Frame
        sub Stretch Tray

    Return: layer
        with the frame
    """
    d = maya.value_d[ok.WRW][ok.FILLER_ST]
    e = maya.value_d[ok.WRW][ok.WRAP]
    j = v.j
    cast = maya.cast.matter

    # Grow the selection for each frame part.
    select_item(cast)
    grow_frame(j, e[ok.WIDTH], e[ok.TYPE])

    # inner frame selection, 'sel'
    sel = pdb.gimp_selection_save(j)

    grow_frame(j, d[ok.WIDTH], e[ok.TYPE])

    # inner and filler frame selection, 'sel1'
    sel1 = pdb.gimp_selection_save(j)

    grow_frame(j, e[ok.WIDTH], e[ok.TYPE])

    # inner, filler, and outer selection, 'sel2'
    sel2 = pdb.gimp_selection_save(j)

    load_selection(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

    # outer frame selection, 'sel3'
    sel3 = pdb.gimp_selection_save(j)

    load_selection(j, sel1)
    load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

    # Cover-up the emboss on the inner and outer frame.
    grow_frame(j, 1., ff.ANGULAR)

    # filler selection
    if pdb.gimp_item_is_valid(maya.filler_sel):
        pdb.gimp_image_remove_channel(v.j, maya.filler_sel)

    maya.filler_sel = pdb.gimp_selection_save(j)

    # Make an inner frame selection.
    load_selection(j, sel)
    select_item(cast, option=fu.CHANNEL_OP_SUBTRACT)
    load_selection(j, sel3, option=fu.CHANNEL_OP_ADD)

    for i in (sel, sel1, sel2, sel3):
        pdb.gimp_image_remove_channel(j, i)


def make_2nd_frame_sel(v, maya):
    """
    Make an inner and outer metallic frame.

    v: View
    maya: Frame
    Return: layer
        with the frame
    """
    d = maya.value_d[ok.WRW][ok.WRAP]
    j = v.j
    z = maya.sub_maya[FILLER].matter

    # Grow the selection for each frame part.
    load_selection(j, maya.filler_sel)

    # Remove the mask from a previous viewing.
    discard_mask(z)

    select_item(z, option=fu.CHANNEL_OP_INTERSECT)
    grow_frame(j, d[ok.WIDTH], d[ok.TYPE])
    select_item(maya.sub_maya[FILLER].matter, option=fu.CHANNEL_OP_SUBTRACT)
    return pdb.gimp_selection_save(j)


class StretchTray(Build):
    """
    Make a frame by stretching cast pixel horizontally and vertically.
    """
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Is the key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_filler: function
            Call to make filler material

        k: string
            Is the Option key to the Filler dict found in the 'ok.WRW' row.
        """
        self.filler_sel = None
        self.is_change = False
        k = self.filler_k = ok.FILLER_ST

        Build.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.WRW, ok.WRAP), k_path + (ok.WRW, k)],
            do_frame
        )

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.SRW, ok.NOISE_D)
        )
        self.sub_maya[FILLER] = Filler(
            any_group, self, k_path + (ok.WRW, k), do_filler
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group,
            self,
            k_path + (ok.SRW, ok.SHADOW),
            (self.cast, self, self.sub_maya[FILLER])
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_change = is_change
        self.is_matter |= is_change
        is_filler = False
        filler = self.sub_maya[FILLER]

        self.realize(v)

        # Process Filler here if there is no Frame/Wrap change.
        if not self.is_matter:
            is_filler = filler.do(
                v, d[ok.WRW][ok.FILLER_ST], is_change, self.is_matter
            )

        # Only mask Filler layer when frame changes.
        if self.is_matter:
            load_selection(v.j, self.filler_sel)
            mask_sel(filler.matter)

            # Gradient Light's timing was off in the
            # previous call due to the mask change.
            filler.sub_maya[LIGHT].do(v, is_filler)

        self.sub_maya[ok.NOISE_D].do(
            v, d[ok.SRW][ok.NOISE_D], is_change, self.is_matter
        )

        # background changed flag, 'm'
        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], is_change, self.is_matter
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m

    def reset(self):
        """Call when the View image is removed."""
        if self.filler_sel:
            pdb.gimp_image_remove_channel(The.view.j, self.filler_sel)
            self.filler_sel = None
        super(Build, self).reset()
