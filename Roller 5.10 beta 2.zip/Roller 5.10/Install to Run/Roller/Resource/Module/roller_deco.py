#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Deco as dc, Gradient as fg, Mask as ms
from roller_constant_key import Group as gk, Option as ok
from roller_deco_mask import ROUTE_MASK
from roller_def import get_default_value
from roller_fu import (
    add_layer,
    blur_selection,
    clear_selection,
    clear_inverse_selection,
    clone_layer,
    copy_all_image,
    get_select_bounds,
    get_select_coord,
    invert_and_desaturate,
    invert_selection,
    isolate_selection,
    load_selection,
    make_clouds,
    make_layer_group,
    merge_layer_group,
    paste_layer,
    remove_layers,
    remove_z,
    select_item,
    select_rect,
    select_shape,
    shape_clipboard,
    verify_layer,
    verify_layer_group
)
from roller_one_cat import Cat
from roller_one_rect import Rect
from roller_view_contain import One
from roller_view_hub import (
    brush_stroke,
    color_selection_default,
    get_mean_color,
    get_gradient_points,
    set_fill_context_default,
    set_gimp_gradient,
    set_gimp_pattern
)
from roller_view_preset import combine_seed
from roller_view_real import clip_to_wip, get_light, insert_copy, make_group
import gimpfu as fu
import math

pdb = fu.pdb


def add_group_mask(j, z):
    """
    Make a mask group for mask output.

    j: GIMP image
        work-in-progress

    z: layer
        Its parent is the group's parent.

    Return: layer
        the new group
    """
    return make_layer_group(
        j, "Mask Group", parent=z.parent, offset=len(z.parent.layers)
    )


def add_group_type(v, maya):
    """
    Make a deco's Type group. A Type group is eventually merged.
    Depends on 'v.deco.type_' and 'maya.group'.

    Return: layer
        the new group
    """
    return make_group(
        v, v.deco.type_, maya.group, offset=len(maya.group.layers)
    )


def attach_mask_sel(z):
    """
    Attach a mask layer, made from a selection, to another layer.
    Depends upon a mask selection and an actual layer.

    z: layer
        Receive mask.

    Return: mask or None
        newly created
    """
    if z:
        if not pdb.gimp_selection_is_empty(z.image):
            mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)

            pdb.gimp_layer_add_mask(z, mask)
            return mask


def do_mean_color(v, maya, z):
    """
    Make a Mean Color layer. The Mean
    Color is calculated from a selection.

    v: View
    maya: Maya
        not used

    z: layer
        WIP

    Return: layer
        Has the mean color.
    """
    color = get_mean_color(v.deco.bg_z)

    color_selection_default(z, color)
    return z


def do_below(v, maya, z):
    """
    Make material from the background.

    v: View
    maya: Maya
    z: layer
        Has material.

    Return: layer
        Has backdrop clone.
    """
    j = v.j
    d = maya.value_d
    sel = pdb.gimp_selection_save(j)
    z1 = clone_layer(v.deco.bg_z)

    remove_z(z)
    load_selection(j, sel)

    if d[ok.BLUR]:
        blur_selection(z1, d[ok.BLUR])

    z1.name = z1.parent.name + " Below"

    clear_inverse_selection(z1)
    pdb.gimp_image_remove_channel(j, sel)

    # The background copy layer is in the group, '1'.
    pdb.gimp_image_reorder_item(j, z1, z1.parent, get_light(maya) + 1)
    return z1


def do_brush(v, z, d):
    """
    Paint Fringe material using a selection provided by the caller.

    v: View
    z: layer
        to receive paint

    d: dict
        Fringe Preset
        {Option key: value}
    """
    def _set_foreground_color():
        """
        Set the foreground color for the brush to use.
        Rotate through the multiple color option.
        """
        if is_multi_color:
            v.deco.color_x = v.deco.color_x + 1 \
                if v.deco.color_x < max_x else 0
            pdb.gimp_context_set_foreground(
                color_q[v.deco.color_x]
            )

    j = v.j
    e = d[ok.BRW][ok.BRUSH_D]
    callback = None

    combine_seed(v, e)

    if v.deco.type_ == dc.MULTI_COLOR:
        v.deco.color_x = 0
        is_multi_color = True
        color_q = d[ok.COLOR_6]
        max_x = d[ok.COLOR_COUNT] - 1
        callback = _set_foreground_color

    elif v.deco.type_ == dc.AS_IS:
        pdb.gimp_context_set_foreground(Cat.foreground)

    pdb.gimp_context_set_antialias(1)
    pdb.gimp_selection_shrink(j, int(d[ok.CONTRACT]))
    if not pdb.gimp_selection_is_empty(j):
        pdb.gimp_context_set_opacity(e[ok.OPACITY])
        pdb.plug_in_sel2path(j, z)

        if j.active_vectors:
            for stroke in j.active_vectors.strokes:
                brush_stroke(
                    z,
                    e[ok.BRUSH],
                    e[ok.BRUSH_SIZE],
                    stroke,
                    e[ok.BRUSH_SPACING],
                    e[ok.ANGLE_JITTER],
                    callback=callback,
                    hardness=e[ok.HARDNESS],
                    angle=e[ok.BRUSH_ANGLE]
                )

            # Remove, from the image, the path created by 'plug_in_sel2path'.
            pdb.gimp_image_remove_vectors(j, j.active_vectors)


def do_clouds(v, maya, z):
    """
    Fill a selection with solid noise.

    v: View
    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with clouds
    """
    make_clouds(z, int(maya.value_d[ok.SEED] + v.glow_ball.seed))
    return z


def do_color(v, maya, z):
    """
    Fill a selection with a color. Is context sensitive.

    v: View
        not used

    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with the color material
    """
    color = maya.value_d[ok.COLOR_1]

    color_selection_default(z, color)
    return z


def do_gradient(v, maya, z):
    """
    Fill a selection with a gradient.

    v: View
    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with the gradient material
    """
    def _draw():
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(d[ok.GRADIENT_TYPE]),
            0,                 # gradient offset
            1,                 # Super sample is true.
            3,                 # super sample max depth
            .0,                # super sample threshold all
            1,                 # Dither is true.
            start_x, start_y,
            end_x, end_y
        )

    j = v.j
    d = maya.value_d
    sel = pdb.gimp_selection_save(j)

    # Begin rectangle calculation.
    # The gradient draws in a rectangle space which
    # is made by the greater bounds of the intersection
    # of the canvas rectangle and the current selection.
    x, y, w, h = maya.rect
    x1, y1, x2, y2 = get_select_coord(j)
    x = min(max(.0, x), x1)
    y = min(max(.0, y), y1)
    w = max(w, x2 - x1)
    h = max(h, y2 - y1)
    # End rectangle calculation.

    set_fill_context_default()
    set_gimp_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        fu.GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(0)

    start_x, end_x, start_y, end_y = get_gradient_points(d, x, y, w, h)

    select_rect(j, x, y, w, h)
    _draw()
    load_selection(j, sel)
    clear_inverse_selection(z)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_image(v, maya, z):
    """
    Fill a selection with an image.

    v: View
    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with the image material
    """
    j = v.j
    d = maya.value_d
    j1 = v.deco.image
    sel = pdb.gimp_selection_save(j)
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    w, h = x1 - x, y1 - y

    if j1:
        j2 = j1.j

        pdb.gimp_selection_none(j)
        copy_all_image(j2)
        shape_clipboard(w, h)

        z1 = paste_layer(z)

        pdb.gimp_layer_set_offsets(z1, x, y)

        # Resize the pasted layer.
        z = pdb.gimp_image_merge_down(z.image, z1, fu.CLIP_TO_IMAGE)

        if sel:
            load_selection(j, sel)
            clear_inverse_selection(z)
        if d[ok.BLUR]:
            select_item(z)
            if not pdb.gimp_selection_is_empty(j):
                blur_selection(z, d[ok.BLUR])

    else:
        remove_z(z)
        z = None

    if sel:
        pdb.gimp_image_remove_channel(j, sel)
    return z


def do_netting(v, maya, z):
    """
    Fill a selection with netting material.

    v: View
    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with the netting material
    """
    j = v.j
    d = maya.value_d
    w = int(d[ok.NLS])
    color = d[ok.COLOR_1]
    w1 = int(d[ok.NET_LINE_W])
    x, y = get_select_bounds(j)[1:3]
    x, y = map(int, (x, y))
    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.plug_in_grid(
        j, z,
        w1, w, y,
        color,
        255,           # opacity
        w1, w, x,
        color,
        255,           # opacity
        0, 0, 0,
        color,
        255
    )
    isolate_selection(z, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_pattern(v, maya, z):
    """
    Fill a selection with a pattern.

    v: View
        not used

    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with pattern
    """
    d = maya.value_d

    set_fill_context_default()
    set_gimp_pattern(d[ok.PATTERN])
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, .0, .0)

    if d[ok.BLUR]:
        blur_selection(z, d[ok.BLUR])
    return z


def do_plasma(v, maya, z):
    """
    Fill a selection with plasma.

    v: View
    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with plasma material
    """
    j = v.j
    d = maya.value_d
    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, int(d[ok.SEED] + v.glow_ball.seed), 3.)

    if d[ok.BLUR]:
        blur_selection(z, d[ok.BLUR])

    isolate_selection(z, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def feather_mask(j, d):
    """
    Feather a Mask selection.

    j: GIMP image
        Is the render.

    d: dict
        Mask Preset
        {Option key: value}

    Return: state of selection
    """
    if not pdb.gimp_selection_is_empty(j) and d[ok.FEATHER]:
        sel = pdb.gimp_selection_save(j)
        a = d[ok.FEATHER]
        f = a / d[ok.STEPS]
        b = f
        if a:
            while a > b:
                pdb.gimp_selection_feather(j, b)
                b = min(b + f, a)

        load_selection(j, sel, option=fu.CHANNEL_OP_INTERSECT)
        pdb.gimp_image_remove_channel(j, sel)


def finish_backed(v):
    """
    If the background was used in deco production,
    then remove the prepped background copy layer.

    v: View
    """
    if v.deco.bg_z:
        pdb.gimp_image_remove_layer(v.j, v.deco.bg_z)


def finish_facing_mask(j, z, group):
    """
    Apply a mask to a merged layer group.

    j: GIMP image
    z: layer
        Receive mask.

    group: layer
        Merge to create the mask's selection source.

    Return: drawable
        mask
    """
    z1 = merge_layer_group(group)

    select_item(z1)

    mask = attach_mask_sel(z)

    remove_z(z1)
    return mask


def get_clip_to_cell(d):
    """
    Fetch the CLIP_TO_CELL option's value.

    d: dict
        deco Preset

    Return: int
        0 or 1
    """
    a = d.get(ok.CLIP_TO_CELL)

    if a is not None:
        return a
    return d[ok.OCR][ok.CLIP_TO_CELL]


def get_obey_margins(d):
    """
    Fetch the OBEY_MARGINS option's value. If not
    present, return True as the default deco behavior.

    d: dict
        deco Preset

    Return: int
        0 or 1
        same as bool
    """
    a = d.get(ok.OBEY_MARGINS)

    if a is not None:
        return a

    a = d.get(ok.OCR)

    if a is not None:
        return a[ok.OBEY_MARGINS]
    return 1


def make_cell_face_mask(v, maya, mask_d):
    """
    Apply Box Face Mask for a cell.

    v: View
    maya: Maya
    mask_d: dict
        Mask Preset

    Return: layer or None
        mask
    """
    z = maya.matter
    j = v.j
    group = add_group_mask(j, z)

    produce_facing_mask(v, maya, group, mask_d, maya.k)
    return finish_facing_mask(j, z, group)


def make_cell_facing_mask(v, maya, mask_d):
    """
    Apply a Box Face mask for a cell.

    v: View
    maya: Maya
    mask_d: dict
        Mask Preset

    Return: layer or None
        mask
    """
    j = v.j
    z = maya.matter
    group = add_group_mask(j, z)

    produce_facing_mask(v, maya, group, mask_d, maya.k)
    return finish_facing_mask(v.j, z, group)


def make_deco_mask(v, maya):
    """
    Mask a Plaque or an Image cell.

    v: View
    maya: Maya
    Return: mask or None
    """
    z = maya.matter

    select_item(z)
    make_mask_sel(v, maya, maya.value_d[ok.MRW][ok.MASK])
    return attach_mask_sel(z)


def make_deco_material(v, maya, group):
    """
    Produce deco layer. Set 'v.deco.type_', and a
    selection for deco-processing before calling.

    v: View
    maya: Maya
    group: layer
        Is the parent group of the deco output.

    Return: layer or None
        with material
    """
    n = v.deco.type_
    if n in ROUTE_DECO:
        if not pdb.gimp_selection_is_empty(v.j):
            z = verify_layer(
                ROUTE_DECO[n](
                    v,
                    maya,
                    add_layer(
                        v.j,
                        group.name + " " + n,
                        parent=group,
                        offset=len(group.layers)
                    )
                )
            )
            if z:
                invert_and_desaturate(maya.value_d[ok.IDR], z)
            return z


def make_main_face_mask(v, maya, mask_d):
    """
    Apply Box Face Mask for main.

    v: View
    maya: Maya
    mask_d: dict
        Mask Preset
        {Option key: value}

    Return: layer
        the mask
    """
    j = v.j
    z = maya.matter
    group = add_group_mask(j, z)

    for k in maya.main_q:
        produce_facing_mask(v, maya, group, mask_d, k)
    return finish_facing_mask(j, z, group)


def make_main_facing_mask(v, maya, mask_d):
    """
    Apply Facing mask for main.

    v: View
    maya: Maya
    mask_d: dict
        Mask Preset
        {Option key: value}

    p: function
        Call to make cell Facing Mask.

    Return: layer
        the mask
    """
    j = v.j
    z = maya.matter
    model = maya.model
    group = add_group_mask(j, z)

    for k in maya.main_q:
        z1 = produce_facing_mask(v, maya, group, mask_d, k)
        model.clip_facing(z1, k)
    return finish_facing_mask(j, z, group)


def make_mask_sel(v, maya, d):
    """
    Form a mask selection from a selection. Is dependent on
    a selection. The selection is the rectangular bounds of the mask.

    v: View
    maya: Maya
    d: dict
        Mask Preset

    Return: state of selection
        The selection is ready to become a mask.
    """
    j = v.j
    mask_type = d[ok.TYPE]
    p = ROUTE_MASK.get(mask_type)
    is_sel, x, y, x1, y1 = get_select_bounds(j)

    if is_sel:
        if p:
            e = maya.value_d[ok.MRW][ok.MASK]
            w, h = x1 - x, y1 - y
            w1, h1 = w * d[ok.HORZ_SCALE], h * d[ok.VERT_SCALE]

            # Create a mask-selection from the existing selection.
            p(
                j,
                One(
                    d=e,
                    maya=maya,

                    # Is the size of the mask influence, 'scale'.
                    scale=Rect(x + (w - w1) // 2., y + (h - h1) // 2., w1, h1),

                    # Is the size of the cast's alpha, 'sel'.
                    sel=Rect(x, y, w, h),
                )
            )
            if e[ok.CUT_OUT]:
                sel = pdb.gimp_selection_save(j)

                select_rect(j, x, y, w, h)
                load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
                pdb.gimp_image_remove_channel(j, sel)

        elif mask_type == ms.FRINGE:
            sel = pdb.gimp_selection_save(j)
            e = get_default_value(gk.FRINGE)
            e[ok.CONTRACT] = d[ok.CONTRACT]
            e[ok.BRW][ok.BRUSH_D] = d[ok.IBR][ok.BRUSH_D]
            z = add_layer(j, "Paint")

            paint(v, z, e)
            load_selection(j, sel)
            select_item(z, option=fu.CHANNEL_OP_SUBTRACT)
            pdb.gimp_image_remove_channel(j, sel)
            pdb.gimp_image_remove_layer(j, z)

        feather_mask(j, d)
        rotate_mask(j, d)
    else:
        pdb.gimp_selection_none(j)


def paint(v, z, d):
    """
    Create Fringe brush stroke.

    v: View
    z: layer
        for Fringe material

    d: dict
        Fringe Preset
    """
    j = v.j

    if not pdb.gimp_selection_is_empty(j):
        do_brush(v, z, d)
    if get_clip_to_cell(d):
        select_item(z)
        if not pdb.gimp_selection_is_empty(j):
            select_shape(j, v.deco.shape)
            invert_selection(j)
            clear_selection(z)


def prep_backed(v, maya, z):
    """
    If the deco type depends on the visible background,
    then create a copy of the background. Both main or
    Per deco, expect the background copy to be set
    when their output functions are called.

    The blur below layer is hidden because it is
    part of the background.

    v: View
    maya: Maya
        not used

    z: layer
        parent group to place copy
    """
    if v.deco.type_ in dc.BACKED:
        v.deco.bg_z = insert_copy(v, z, z.parent, is_hide=True)
    else:
        v.deco.bg_z = None


def produce_facing_mask(v, maya, group, d, arg):
    """
    Create a mask for transformed Face/Facing. Is GIMP
    context needs to be prepped prior to calling.

    v: View
    maya: Maya
    group: layer
        destination of output

    d: dict
        Mask Preset

    arg: tuple
        Face/Facing index

    Return: layer
        with mask
    """
    j = v.j
    z = add_layer(j, "Mask", parent=group)
    maya.rect = maya.model.get_facing_rect(arg)
    w, h = maya.rect[2:]

    select_rect(j, .0, .0, w, h)
    make_mask_sel(v, maya, d)
    color_selection_default(z, (255, 255, 255))
    return transform_foam(
        v, (.0, .0, w, h), z, maya.model.get_facing_foam(arg)
    )


def produce_main_facing(v, maya, p):
    """
    Create Plaque Face for the main option settings.

    v: View
    maya: Maya
    p: function
        Call to produce output.

    Return: layer or None
        with material
    """
    group = add_group_type(v, maya)

    prep_backed(v, maya, group)

    for k in maya.main_q:
        maya.k = k
        p(v, maya, group)

    finish_backed(v)
    return verify_layer_group(group)


def produce_per_facing(v, maya, p):
    """
    Make deco for Per Face/Facing.

    v: View
    maya: Maya
    p: function
        Call to produce output.

    Return: layer or None
        with material
    """
    group = add_group_type(v, maya)

    prep_backed(v, maya, group)
    p(v, maya, group)
    finish_backed(v)
    return verify_layer_group(group)


def ready_canvas_rect(v, maya, option=fu.CHANNEL_OP_REPLACE):
    """
    Prepare a Canvas rectangle and shape.

    v: View
    maya: Maya
    option: gimpfu enum or None
        If not None, the canvas' rectangle is selected.
    """
    if get_obey_margins(maya.value_d):
        x, y, w, h = maya.rect = maya.model.canvas_pocket.rect

    else:
        x, y, w, h = maya.rect = maya.model.canvas_rect

    x1, y1 = x + w, y + h
    v.deco.shape = x, y, x1, y, x1, y1, x, y1
    if option:
        select_shape(v.j, v.deco.shape, option=option)


def ready_shape(v, maya, option=fu.CHANNEL_OP_REPLACE):
    """
    Set 'v.deco.shape' and 'maya.rect'. Select
    the shape when 'option' is not None.

    v: View
    maya: Maya
    option: gimpfu enum or None
        If not None, then the canvas' rectangle is selected.
    """
    a = maya.model
    k = maya.k

    # An Image Preset doesn't have the OBEY_MARGINS option.
    if get_obey_margins(maya.value_d):
        # the pocket shape
        maya.rect = a.get_pocket(k).rect
        v.deco.shape = a.get_shape(k)

    else:
        maya.rect = a.get_shift_rect(k)
        v.deco.shape = a.get_plaque(k)
    if option is not None:
        select_shape(v.j, v.deco.shape, option=option)


def rotate_mask(j, d):
    """
    Rotate a Mask selection.

    j: GIMP image
        Is the render.

    d: dict
        Mask Preset

    Return: state of selection
    """
    if not pdb.gimp_selection_is_empty(j) and d[ok.ANGLE]:
        z = add_layer(j, "Rotate")

        color_selection_default(z, (0, 0, 0))

        # auto-center, 'True'; x and y, '0'
        z1 = pdb.gimp_item_transform_rotate(
            z, math.radians(d[ok.ANGLE]), True, .0, .0
        )

        select_item(z1)
        remove_layers((z, z1))


def test_image(v, maya):
    """
    If the deco type is an image, determine if an
    image has been assigned. Assign 'v.deco.image'.

    v: View
    maya: Maya
    Return: bool
        Is not None if a valid image is assigned
    """
    go = True

    if v.deco.type_ == dc.IMAGE:
        go = v.deco.image = maya.get_image(maya.k)
    return go


def transform_foam(v, rect, z, q):
    """
    Shape rectangular material into a polygon.

    v: View
    rect: tuple
        (x, y, w, h)
        input material to transform

    z: layer
        Is disposable input.

    q: tuple
        x, y float series
        (topleft, top-right, bottom-left, bottom-right)

    Return: layer
        with the transformed material
    """
    select_rect(v.j, *rect)

    # Transform the selected material into a floating selection layer.
    z1 = pdb.gimp_item_transform_perspective(z, *q)

    pdb.gimp_floating_sel_to_layer(z1)

    remove_z(z)
    clip_to_wip(v, z1)
    return z1


# {deco type: function}
ROUTE_DECO = {
    dc.MEAN_COLOR: do_mean_color,
    dc.BELOW: do_below,
    dc.CLOUDS: do_clouds,
    dc.COLOR: do_color,
    dc.GRADIENT: do_gradient,
    dc.IMAGE: do_image,
    dc.NETTING: do_netting,
    dc.PATTERN: do_pattern,
    dc.PLASMA: do_plasma
}
