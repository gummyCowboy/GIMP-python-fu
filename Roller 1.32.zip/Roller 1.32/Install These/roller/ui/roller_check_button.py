#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_wig import Wig
import gtk


class RCheckButton(Wig):
    """
    This is a custom GTK CheckButton.

    Is attached to its own Alignment.
    """

    def __init__(self, n, p, key=None, pad=0):
        """
        Create CheckButton and Alignment.

        n: label text
        p: callback function
        key: widget key
        pad: flag
            If it's true, the CheckButton is padded.
        """
        w = ForWidget.MARGIN
        g = self.g = gtk.Alignment(0, 0, 0, 0)
        g1 = gtk.CheckButton(label=n)

        Wig.__init__(self, p, key=key, widget=g1)

        g.add(g1)
        g1.connect('clicked', self.callback)
        g1.connect('activate', self.callback)

        if pad:
            g.set_padding(w / 2, w / 2, w, w)

    def get_value(self):
        """
        Return the value of the CheckButton.

        Is part of a UI widget template.
        """
        return int(self.wig.get_active())

    def set_value(self, a):
        """
        Set the CheckButton checked state.

        Is part of a UI widget template.

        a: int
        """
        self.wig.set_active(a)
