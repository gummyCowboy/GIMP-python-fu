#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gtk


class RLabel:
    """This is a custom GTK Label."""

    def __init__(self, n, pad=(0, 0, 0, 0), align=(0, 0, 0, 0)):
        """
        n: label text
        a: padding tuple (top, bottom, left, right)
        """
        g = self.label = gtk.Label(n)
        g1 = self.g = gtk.Alignment(*align)

        g1.set_padding(*pad)
        g1.add(g)

    def destroy(self):
        """Destroys the sub-widgets."""
        self.label.destroy()
        self.g.destroy()
