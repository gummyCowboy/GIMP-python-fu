#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForCell
from roller_splitter import Splitter
from roller_button import RButton
from roller_check_button import RCheckButton


class GroupPerCell(RCheckButton):
    """
    Has a UICell window opener Button and a per-cell CheckButton.
    """

    def __init__(self, p, p1, n, k, g, x):
        u"""
        p: callback function
        p1: open window function
        n: Button label
        k: CheckButton's key
        g: container
        x: ‟win_x” index
        """
        self.key = k
        self.update_window_for_checkbutton = p
        self.update_window_for_button = p1
        self.x = x
        self.cell_key = ForCell.CELL_KEY_LIST[x]
        p = self.on_check_button_change
        p1 = self.on_button_action
        g1 = Splitter(pad_x=1)

        RCheckButton.__init__(self, "Per Cell", p, key=k)

        g2 = self.g1 = RButton(n, p1)

        g1.left.add(self.g)
        g1.right.add(g2.g)
        g1.pack()
        g.add(g1.g)

    def on_check_button_change(self, g):
        """
        Intercept signals from the CheckButton.

        g: CheckButton widget
        """
        self.verify_button()
        self.update_window_for_checkbutton(g)

    def on_button_action(self, _):
        """Intercept changed signal from the Button."""
        self.update_window_for_button(self.x)

    def set_value(self, a):
        """
        Set the value of the CheckButton and is part of a UI widget template.

        Verify the cell window opener button.

        a: int
        """
        RCheckButton.set_value(self, a)
        self.verify_button()

    def verify_button(self):
        """
        The cell window Button is valid only if the CheckButton is checked.
        """
        self.g1.enable() if self.get_value() else self.g1.disable()
