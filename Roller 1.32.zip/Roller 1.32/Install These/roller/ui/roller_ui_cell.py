#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_base import Base
from roller_constant import (
        ForColor,
        ForFormat,
        FormatKey,
        ForWidget,
        UICellKey,
        UIKey,
        WindowKey
    )

from roller_cg import CG
from roller_layout import Images, Cell
from roller_rbox import RBox
from roller_check_button import RCheckButton
from roller_combobox import RComboBox
from roller_eventbox import REventBox
from roller_label import RLabel
from roller_spin_button import RSpinButton
from roller_session import Format
from roller_splitter import Splitter
from roller_switch_button import SwitchButton
from roller_ui_switch import UISwitch
import gtk


class UICell(UISwitch):
    """Draw the Per Cell windows."""

    # GTK will sometimes draw scroll-bars after the window's size changes:
    xtra = 5
    NP = "No Picture"
    PLACEMENT_INDEX, PROPERTY_INDEX = 1, 3
    HEADER_COLOR = 44000, 44000, ForColor.MAX_COLOR

    def __init__(self, d):
        """d: dict"""
        x = CG.overlay = self.win_x = d[UICellKey.WINDOW_INDEX]
        self.merged = d[UICellKey.MERGE_PER_CELL]
        self.format_c = d[UICellKey.FORMAT_OBJ]
        self.placement_widget = []
        self.stat = d[UIKey.STAT]
        d[UIKey.ON_RETURN] = self.do_job
        d[UIKey.WINDOW_POSITION] = (
                WindowKey.MERGE_CELLS,
                WindowKey.MERGE_IMAGE_PLACEMENT,
                WindowKey.MERGE_CELL_MARGIN,
                WindowKey.MERGE_IMAGE_PROPERTY
            )[x]

        d[UIKey.WINDOW_TITLE] = (
            "Merge Cells",
            "Image Placement",
            "Cell Margin",
            "Image Property")[x] + ": Use Escape or Enter"

        self._init_merge_cells(d)

        # cell window format copy:
        CG.format_c = Format(self.format_c.format)
        CG.cell = Cell(CG.format_c.format, self.stat)
        UISwitch.__init__(self, d)

    def _draw_margin_cell(self, d):
        """
        Called by UICell for each cell.

        Draw margin Labels and SpinButtons.

        d: cell dict
        """
        # These widgets use an index:
        if self._isnt_no_picture(d):
            e = self.format_c.format[
                FormatKey.CELL_TABLE_MARGIN][d['row']][d['column']]

            g = CG.grid[d['row']][d['column']]['box']
            for x, n in enumerate(
                    (
                        ForFormat.TOP,
                        ForFormat.BOTTOM,
                        ForFormat.LEFT,
                        ForFormat.RIGHT
                    )):
                g1 = Splitter()
                w = self.stat.height - 1 if x < 2 else self.stat.width - 1
                g2 = RSpinButton(
                        self._on_widget_change,
                        (0, w),
                        key=ForFormat.CELL_MARGIN_SPIN_BUTTON_KEY[x]
                    )

                g2.cell_key = FormatKey.CELL_TABLE_MARGIN
                g2.r, g2.c = d['row'], d['column']
                g2.index = x

                self.keep((g2,))
                g1.both(RLabel(n + ":").g, g2.g)
                g2.set_value(e[x] / 1.)
                g1.pack()
                g.add(g1.g)

    def _draw_placement_cell(self, d):
        """
        Called by UICell for each cell.

        Draw the ComboBoxes for Image Placement.

        d: cell dict
        """
        if self._isnt_no_picture(d):
            ff = ForFormat
            p = self._on_widget_change
            g = [None] * 4

            for x in range(4):
                a = (
                        ff.RESIZE_OPTION,
                        Images.format_img_list,
                        ff.HORIZONTAL_OPTION,
                        ff.VERTICAL_OPTION_LIST
                    )[x]
                g1 = g[x] = RComboBox(p, opt=a)
                g1.index = x
                g1.cell_key = FormatKey.CELL_TABLE_PLACEMENT
                g1.r, g1.c = d['row'], d['column']

                CG.grid[d['row']][d['column']]['box'].add(g1.g)
                self.keep((g1,))

                # The image menu can default to ‟Next” without any
                #  notification. So it's check the menu's at close:
                if x == ff.IMAGE_INDEX:
                    self.placement_widget.append(g1)

            q = self.format_c.format[
                FormatKey.CELL_TABLE_PLACEMENT][d['row']][d['column']]

            for x in range(4):
                g[x].resz, g[x].img, g[x].horz, g[x].vert = \
                    g[0], g[1], g[2], g[3]
                g[x].set_value(q[x])
            if (
                        g1.resz.get_value() == ff.FILL_CELL or
                        g1.img.get_value() == ff.NONE
                    ):
                self.verify_place_menus(g[0])

    def _draw_prop_cell(self, d):
        """
        Called by UICell for each cell.

        Draw the widgets for the Property cell.

        d: dictionary
        """
        if self._isnt_no_picture(d):
            g = CG.grid[d['row']][d['column']]['box']
            p = self._on_widget_change
            q = zip(
                (
                    RCheckButton, RCheckButton, RSpinButton,
                    RSpinButton, RSpinButton
                ),
                (
                    ("Flip Horizontal", p),
                    ("Flip Vertical", p),
                    (p, (-359, 359)),
                    (p, (0, 100)), (p, (0, 200))
                ),
                (
                    ForFormat.FLIP_HORIZONTAL_INDEX,
                    ForFormat.FLIP_VERTICAL_INDEX,
                    ForFormat.ROTATE_INDEX,
                    ForFormat.OPACITY_INDEX,
                    ForFormat.BLUR_BEHIND_INDEX)
                )

            wigs = []
            for x, q1 in enumerate(q):
                g1, c, x1 = q1

                if x < 2:
                    g2 = g1(*c)

                else:
                    label = RLabel((
                        "Rotate:", "Opacity:", "Blur Behind:")[x - 2]).g
                    g2 = g1(*c, label=label)

                g2.index = x1
                g2.r, g2.c = d['row'], d['column']
                g2.cell_key = FormatKey.CELL_TABLE_PROPERTY

                wigs.append(g2)
                self.keep((g2,))

                if x1 == ForFormat.OPACITY_INDEX:
                    op_sb = g2

                if x < 2:
                    # CheckButton:
                    g.add(g2.g)

                else:
                    g3 = Splitter()
                    g3.both(label, g2.g)
                    g3.pack()
                    g.add(g3.g)

            # opacity dependents:
            op_sb.flip_h, op_sb.flip_v, op_sb.rot, op_sb.blur \
                = wigs[:3] + wigs[4:]

            q = self.format_c.format[FormatKey.CELL_TABLE_PROPERTY][
                d['row']][d['column']]

            for x in range(5):
                wigs[x].set_value(q[x])
            if not q[ForFormat.OPACITY_INDEX]:
                self.verify_opacity_depend(wigs[3])

    def _init_merge_cells(self, _):
        """Set the initial data needed to draw cells."""
        d = self.format_c.format
        row, col = d[FormatKey.ROW], d[FormatKey.COLUMN]
        CG.grid = Base.create_2d_table(row, col)

        # Load cell dimensions:
        for r in range(row):
            for c in range(col):
                if self.merged:
                    s = d[FormatKey.CELL_TABLE_MERGE][r][c]

                else:
                    s = 1, 1
                CG.grid[r][c] = {
                        'size': s,
                        'row': r,
                        'column': c
                    }

        # Initialize top-left references:
        for r in range(row):
            for c in range(col):
                e = CG.grid[r][c]
                if CG.is_topleft(e):
                    t = e

                    # Initialize sub-topleft cells:
                    for r1 in range(r, r + t['size'][0]):
                        for c1 in range(c, c + t['size'][1]):
                            if r1 != r or c1 != c:
                                e = CG.grid[r1][c1]
                                e['topleft'] = t['row'], t['column']

    def _isnt_no_picture(self, d):
        """
        Return a flag which is true when the cell has no image.

        d: dict
        """
        e = CG.format_c.format
        m = 1

        # ‟None” image:
        if self.win_x != UICell.PLACEMENT_INDEX:
            if not e[FormatKey.CELL_TABLE_PLACEMENT]:
                m = e[FormatKey.IMAGE] != ForFormat.NONE

            else:
                m = e[FormatKey.CELL_TABLE_PLACEMENT][d['row']][d[
                        'column']][ForFormat.IMAGE_INDEX] != ForFormat.NONE

        # zero opacity:
        if m:
            if self.win_x != UICell.PROPERTY_INDEX:
                if not e[FormatKey.CELL_TABLE_PROPERTY]:
                    m = e[FormatKey.OPACITY] != 0

                else:
                    m = e[
                        FormatKey.CELL_TABLE_PROPERTY][d['row']][d['column']][
                            ForFormat.OPACITY_INDEX] != 0

        if not m:
            # Widens the cell:
            n = UICell.NP + "............" if not d['row'] \
                and not d['column'] else UICell.NP
            CG.grid[d['row']][d['column']]['box'].add(RLabel(n).g)
        return m

    def _on_widget_change(self, g):
        """
        Called when a widget changed display value.

        g: widget
        """
        x = g.index
        k = g.cell_key
        if not self.loading:
            q = list(CG.format_c.format[k][g.r][g.c])
            q[x] = g.get_value()
            CG.format_c.format[k][g.r][g.c] = tuple(q)

            if k == FormatKey.CELL_TABLE_PLACEMENT:
                if x in (ForFormat.RESIZE_INDEX, ForFormat.IMAGE_INDEX):
                    self.verify_place_menus(g)

            elif k == FormatKey.CELL_TABLE_PROPERTY:
                if x == ForFormat.OPACITY_INDEX:
                    self.verify_opacity_depend(g)
        if k == FormatKey.CELL_TABLE_PLACEMENT:
            if x == ForFormat.IMAGE_INDEX:
                n = g.get_value()
                n = n if len(n) > 10 else ""
                g.g.set_tooltip_text(n)

    def do_job(self):
        """Called because the user pressed the Enter key."""
        if self.placement_widget:
            for g in self.placement_widget:
                self._on_widget_change(g)

        self.format_c.format = CG.format_c.format
        return self.close()

    def draw_cell(self, _, d):
        """
        Called by UICell for each cell.

        Initialize the cell's dictionary.

        Draw connectors and cell sizes.

        d: cell dict
        """
        e = CG.grid[d['row']][d['column']]

        CG.draw(e)
        if self.win_x:
            if e['size'] != (-1, -1):
                (
                    self._draw_placement_cell,
                    self._draw_margin_cell,
                    self._draw_prop_cell)[self.win_x - 1](d)

    def draw_window(self):
        """
        Draw the background framework used by the three Per Cell windows.

        Call the Per Cell window owner to draw
        it's overlay on top of the background.

        Is part of the UI window template.
        """
        d = self.format_c.format
        row, col = d[FormatKey.ROW] * 2, d[FormatKey.COLUMN] * 2
        vbox = self.win.vbox
        table = gtk.Table(row, col)
        scroll = gtk.ScrolledWindow()
        is_1st_cell = 1

        scroll.add_with_viewport(table)
        vbox.add(scroll)
        scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        self.buttons = Base.create_2d_table(
            d[FormatKey.ROW], d[FormatKey.COLUMN])

        for r in range(row):
            for c in range(col):
                r1, c1 = r / 2 + 1, c / 2 + 1
                r2, c2 = r / 2 - 1, c / 2 - 1

                if r == 0:
                    if not self.win_x or (self.win_x and c % 2):
                        # column header:
                        g = REventBox(UICell.HEADER_COLOR)
                        g1 = gtk.Frame()

                        if c % 2:
                            g2 = col_label = RLabel(
                                str(c1), align=(0, 0, 1, 0)).g
                            g1.add(g2)

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif c == 0:
                    if not self.win_x or (self.win_x and r % 2):
                        # row header:
                        g = REventBox(UICell.HEADER_COLOR)
                        g1 = gtk.Frame()

                        if r % 2:
                            g2 = row_label = RLabel(
                                    str(r1),
                                    pad=(0, 0, 4, 4),
                                    align=(0, 0, 0, 1)
                                ).g
                            g1.add(g2)

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif r % 2 and c % 2:
                    # Create cell:
                    r3, c3 = d['row'], d['column'] = r / 2, c / 2
                    e = CG.grid[r3][c3]

                    # Add buttons to the cell's dictionary:
                    if r > 1:
                        e['top_b'] = self.buttons[r2][c3]

                    if c > 1:
                        e['left_b'] = self.buttons[r3][c2]

                    g = RBox(0, align=(0, 0, 1, 1))
                    e['pad'] = g.g
                    g1 = e['event_box'] = REventBox(None)
                    g2 = RBox(0, pad=[5, 5, 5, 5])
                    g3 = CG.grid[r3][c3]['box'] = g2.box

                    g.add(g1)
                    g1.add(g2.g)
                    table.attach(g.g, c, c + 1, r, r + 1)
                    self.draw_cell(g3, d)

                    if is_1st_cell:
                        """
                        ‟show_all” causes the ‟vbox” allocation to be
                        calculated which will fail ScrolledWindow's dependency.
                        So it's calculate the scroll region-size manually.
                        """
                        self.win.show_all()

                        # scaling:
                        is_1st_cell = 0
                        w = max(g3.allocation.width, g3.allocation.height)
                        w1, h = w * d[FormatKey.COLUMN], w * d[FormatKey.ROW]
                        w2 = row_label.allocation.width
                        h1 = col_label.allocation.height
                        button_w = 0 if self.win_x else \
                            15 * (d[FormatKey.COLUMN] - 1)

                        button_h = 0 if self.win_x else \
                            15 * (d[FormatKey.ROW] - 1)

                        pad_w = 20 * d[FormatKey.COLUMN]
                        pad_h = 20 * d[FormatKey.ROW]
                        xtra_w, xtra_h = row, col
                        xtra = UICell.xtra
                        xtra += 15 if self.win_x == 3 else 0

                        # totaling:
                        w1 += w2 + pad_w + button_w + xtra_w + \
                            ForWidget.SCROLL_SPAN + xtra

                        h += h1 + pad_h + button_h + xtra_h + \
                            ForWidget.SCROLL_SPAN + xtra

                        w1, h = self.get_remaining_dim(w1, h)
                        self.win.vbox.set_size_request(w1, h)
                    g3.set_size_request(w, w)

                elif not (not r % 2 and not c % 2):
                    if not self.win_x:
                        # connector button:
                        if r % 2:
                            # left button:
                            p = CG.split_horz, CG.connect_left
                            r3, c3 = r, c + 1
                            r4, c4 = r / 2, c / 2 - 1
                            q = (5, 5, 0, 0)

                        else:
                            # upper button:
                            p = CG.split_vert, CG.connect_up
                            r3, c3 = r + 1, c
                            r4, c4 = r / 2 - 1, c / 2
                            q = (0, 0, 5, 5)

                        g = RBox(1, align=(0, 0, 1, 1), pad=q)
                        g1 = self.buttons[r4][c4] = SwitchButton(
                            "+", p, r3, c3, g)

                        g1.set_size(15, 15)
                        g1.set_color(ForColor.BACKGROUND_BUTTON_COLOR)
                        g.add(g1)
                        table.attach(g.g, c, c + 1, r, r + 1)

                else:
                    if not self.win_x:
                        # nothing reactive:
                        g = REventBox(ForColor.BACKGROUND_BUTTON_COLOR)
                        g1 = gtk.HBox()
                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)
