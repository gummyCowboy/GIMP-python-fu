#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import seed
from roller_constant import OptionKey, SessionKey
from roller_border_line import BorderLine
from roller_effect import Effect
import gimpfu as fu


class StainedGlass(Effect):
    """Create a frame with colorful transparent glass."""
    name = SessionKey.STAINED_GLASS
    width_low, width_high = 3, 20

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        self.stat = stat
        BorderLine(
                d,
                stat,
                name=SessionKey.STAINED_GLASS,
                filler=self.do,
                reflect=1
            )

    def do(self, d, z):
        """
        Called from BorderLine. Draws the glass layer.

        Is part of a RenderHub class template.

        d: sub-session dict
        z: process layer

        Return the glass layer.
        """
        return self.do_rotated_layer(d, self.do_job, z)

    def do_job(self, j, z, d):
        """
        Draw the glass panes.

        j: GIMP image
        z: layer
        d: sub-session dict

        Return the glass layer.
        """
        # A random sequence will reproduce itself given the same seed:
        seed(d[OptionKey.RANDOM_SEED])
        return self.draw_color_rectangles(
            j, z, d[OptionKey.PANE_WIDTH], d[OptionKey.PANE_HEIGHT])
