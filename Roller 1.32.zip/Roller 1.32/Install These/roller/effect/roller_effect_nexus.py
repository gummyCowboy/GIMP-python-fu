#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_border_line import BorderLine
from roller_ceramic_chip import CeramicChip
from roller_clear_frame import ClearFrame
from roller_colored_board import ColoredBoard
from roller_drop_shadow import DropShadow
from roller_gradient_bevel import GradientBevel
from roller_jagged_edge import JaggedEdge
from roller_inlay_shadow import InlayShadow
from roller_rounded_edge import RoundedEdge
from roller_stained_glass import StainedGlass


class EffectNexus:
    """
    Create a collection of 3D Effects.

    Used to populate the 3D Effects drop-menu, and
    as a dock for launching a 3D effect function.
    """
    obj = (
            BorderLine,
            CeramicChip,
            ColoredBoard,
            ClearFrame,
            DropShadow,
            GradientBevel,
            InlayShadow,
            JaggedEdge,
            RoundedEdge,
            StainedGlass
        )
    names = [i.name for i in obj]
