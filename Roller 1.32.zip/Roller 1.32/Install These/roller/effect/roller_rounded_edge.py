#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import LayerKey, OptionKey, SessionKey
from roller_fu import Lay
from roller_drop_shadow import DropShadow
from roller_effect import Effect
import gimpfu as fu


class RoundedEdge(Effect):
    """Create a sunken image effect on an image layer."""
    name = SessionKey.ROUNDED_EDGE

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        Effect.__init__(self, d, stat, need_room=False)
        if not stat.cancel and self.has_room:
            DropShadow({}, stat, q=(LayerKey.IMAGE,))

    def do(self, d):
        """
        Draws the shadow as an inlay shadow.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        ok = OptionKey
        d[ok.INHERIT_OPACITY] = True
        layers = []
        color = (255, 255, 255) if d[ok.ROUND_UP] else (0, 0, 0)
        group = self.create_shadow_unit((LayerKey.IMAGE,), layers)

        z = self.do_shadow(
            group,
            0,
            0,
            d[ok.BLUR],
            color,
            (125., 60.)[int(d[ok.ROUND_UP])],
            n=Lay.get_layer_name(self.name, self.stat),
            d=d,
            inlay=1)

        z.mode = fu.LAYER_MODE_NORMAL
        z.name = self.id
        Lay.bury(self.stat.render, group)
        Lay.order(self.stat.render, z, self.active.format)
        Lay.show(layers[0])
