#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_floor_sample import FloorSample
from roller_average_color import AverageColor
from roller_backdrop_image import BackdropImage
from roller_color_fill import ColorFill
from roller_colored_grid import ColoredGrid
from roller_core_design import CoreDesign
from roller_gradient_fill import GradientFill
from roller_image_gradient import ImageGradient
from roller_lost_maze import LostMaze
from roller_mystery_grate import MysteryGrate
from roller_pattern_fill import PatternFill
from roller_transparency import Transparency


class BackdropStyleNexus:
    """
    Create a collection of Backdrop Styles.

    It is used by the Backdrop Styles menu,
    and to assist launching style functions.
    """
    obj = (
            AverageColor,
            BackdropImage,
            ColorFill,
            ColoredGrid,
            CoreDesign,
            FloorSample,
            GradientFill,
            ImageGradient,
            LostMaze,
            MysteryGrate,
            PatternFill,
            Transparency
        )
    names = [i.name for i in obj]
