#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import OptionKey, SessionKey
from roller_fu import Lay
from roller_backdrop_style import BackdropStyle
import gimpfu as fu


class PatternFill(BackdropStyle):
    """Fill the backdrop with a pattern."""
    name = SessionKey.PATTERN_FILL

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        BackdropStyle.__init__(self, d, stat)

    def do(self, d):
        """
        Fills the active layer with a pattern.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        z = Lay.clone(self.stat.render, self.active.layer)

        self.set_fill_context(d)
        pdb.gimp_context_set_pattern(d[OptionKey.PATTERN])
        pdb.gimp_drawable_edit_bucket_fill(
            z,
            fu.FILL_PATTERN,
            d[OptionKey.START_X], d[OptionKey.START_Y])

        Lay.invert(self.active.layer, d[OptionKey.INVERT])
        self.give_render_mask(z)
        self.active.layer = Lay.merge(self.stat.render, z)
