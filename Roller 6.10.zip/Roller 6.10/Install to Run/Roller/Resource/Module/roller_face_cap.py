#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Shape as sh

"""
Define 'face_cap' as a collection of function
for calculating a cap Face's geometry.

The Box direction is the cap position. Each position has
its own function for calculating geometry.
"""


def do_bottom(q, cap_x, cap_y, side):
    """
    Arrange Face attribute geometry where the Cap
    is at the bottom of a Hexagonal cell shape.

    q: tuple
        Define polygon shape.

    cap_x, cap_y: float
        Is the coordinate for the inner vertex.

    side: tuple
        (side1 length, side2 length, side3 length)

    Return: tuple
        (foam, size of the Face)
    """
    return (
        # transform function's input
        (
            q[10], q[11],
            cap_x, cap_y,
            q[8], q[9],
            q[6], q[7]
        ),

        # size of face
        side[0], side[1]
    )


def do_left(q, cap_x, cap_y, side):
    """
    Arrange Face attribute geometry where the Cap
    is on the left side of a truncated hexagonal cell shape.
    """
    return (
        # transform function's input
        (
            q[2], q[3],
            cap_x, cap_y,
            q[0], q[1],
            q[10], q[11]
        ),

        # size of face
        side[2], side[0]
    )


def do_right(q, cap_x, cap_y, side):
    """
    Arrange Face attribute geometry where the cap
    is at the right of a truncated hexagonal cell shape.
    """
    return (
        # transform function's input
        (
            q[4], q[5],
            q[6], q[7],
            cap_x, cap_y,
            q[8], q[9]
        ),

        # size of face
        side[2], side[0]
    )


def do_top(q, cap_x, cap_y, side):
    """
    Arrange geometry where the cap is positioned at the top of the hexagon.
    """
    return (
        # transform function's input
        (
            q[2], q[3],
            q[4], q[5],
            q[0], q[1],
            cap_x, cap_y
        ),

        # size of face
        side[1], side[0]
    )


# {Box type: shape function}
CAP_BUILD = {
    sh.BOTTOM: do_bottom,
    sh.LEFT: do_left,
    sh.RIGHT: do_right,
    sh.TOP: do_top
}
