#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_constant_for import Image as fi
from roller_fu import (
    copy_all_image, get_select_bounds, paste_image, select_item, select_rect
)
from roller_fu_comm import info_msg
from roller_image_pic import Pic
import os

# Single type
SINGLE_AUTOCROP = 'auto'
SINGLE_FILE_PATH = 'file-path'
SINGLE_FLAT = 'flat'
SINGLE_LAYER = 'layer'
SINGLE_SLICE = 'slice'
SINGLE_TAB = 'tab'


def _get_file_from_path(n):
    """
    Get an Image for a File path. Will open a file.

    n: string
        file-path

    Return: GIMP image or None
        as requested
    """
    j = None

    try:
        j = pdb.gimp_file_load(n, n)

    except Exception as ex:
        info_msg(fi.LOAD_ERR).format(n)
        info_msg("The error was:\n" + repr(ex))
    return j


def _make_layer_k(z):
    return "{}/{}".format(z.image.ID, z.ID)


def single_get_autocrop(mage, single):
    """
    Fetch a Single for an auto-cropped image
    when the Type is not waiting.

    mage: Type
        Has an 'is_wait' flag.

    single: Single or Type
        Has a 'get_image' function.

    Return: Single
        Correspond with a flat image.
    """
    namer = single
    j = single.get_image(mage=mage)

    if mage.is_wait:
        # Only load during a view run, so comeback later.
        return mage

    if not j:
        # A None image is done.
        return

    # Autocrop a flattened image. Get the Single for the flat.
    flat = single_get_flat(mage, j, single)
    k = j.ID
    j = flat.get_image(mage=mage)

    if mage.is_wait:
        return mage

    if not j:
        # A None image is done.
        return

    single = Pic.autocrop_d.get(k)

    if single is None:
        single = Pic.autocrop_d[k] = Single((j, namer), SINGLE_AUTOCROP)
        mage.is_wait = not mage.is_load
    return single


def single_get_file_ref(mage):
    """
    Get the Single corresponding with a file-path.
    If the Single doesn't exist, then create one.

    mage: Type
        Has an 'is_wait' flag.

    Return: Single
        Correspond with a GIMP image.
    """
    if mage.i is not None:
        n = mage.file_list[mage.i]
        single = Pic.file_d.get(n)

        if not single:
            single = Pic.file_d[n] = Single(n, SINGLE_FILE_PATH)
            mage.is_wait = not mage.is_load
        return single


def single_get_flat(mage, j, namer):
    """
    Fetch a Single for an image that has only layer. If the
    provided image has more than one layer, create flat image.

    mage: Type
        Has an 'is_wait' flag.

    j: GIMP image
        May have more than one layer.

    namer: GIMP image
        Inherit image name.

    Return: Single
        Correspond with a flat image.
    """
    k = j.ID
    single = Pic.flat_d.get(k)

    if single is None:
        if j and len(j.layers) > 1:
            mage.is_wait = not mage.is_load
        single = Pic.flat_d[k] = Single((j, namer), SINGLE_FLAT)
    return single


def single_get_layer_ref(mage, z):
    """
    Get the Single corresponding with a layer.
    If the Single doesn't exist, then create one.

    mage: Type
        Has an 'is_wait' flag.

    z: layer
        Make into a Single.

    Return: Single
        Correspond with a GIMP image.
    """
    k = _make_layer_k(z)
    single = Pic.layer_d.get(k)

    if not single:
        single = Pic.layer_d[k] = Single(z, SINGLE_LAYER)
        mage.is_wait = not mage.is_load
    return single


def single_get_slice_ref(mage, z, t, namer):
    """
    Get the Single corresponding with a layer.
    If the Single doesn't exist, then create one.

    mage: Type
        Has slice indices.

    z: layer
        Is sliced.

    t: Rect
        Define the slice.

    Return: Single
        Correspond with a GIMP image.
    """
    k = _make_layer_k(z), t.x, t.y, t.w, t.h
    single = Pic.slice_d.get(k)

    if single is None:
        single = Pic.slice_d[k] = Single((mage, z, t, namer), SINGLE_SLICE)
        mage.is_wait = not mage.is_load
    return single


def single_get_tab(mage):
    """
    Get the Single corresponding with an tab index.
    If the Single doesn't exist, then create one.

    mage: Type
        Has an index, 'i'.
        0 to the number of tabs open minus one

    Return: Single or None
        Correspond with an open GIMP image.
    """
    i = mage.i
    if i is not None:
        single = Pic.tab_d.get(i)

        if not single:
            if -1 < i < len(Pic.tab_q):
                single = Pic.tab_d[i] = Single(Pic.tab_q[i], SINGLE_TAB)
        return single


class Single:
    """Translate GIMP image into output ready."""

    def __init__(self, ref, k):
        """
        ref: object
            GIMP image or file path string

        k: string
            Single type
        """
        self.name = ""
        self._image = None
        self.ref = ref

        # Redirect wait-type reference's 'get' function.
        self.get_image = None

        # Initialize Single type-specific.
        {
            SINGLE_AUTOCROP: self._init_autocrop,
            SINGLE_FILE_PATH: self._init_file_path,
            SINGLE_FLAT: self._init_flat,
            SINGLE_LAYER: self._init_layer,
            SINGLE_SLICE: self._init_slice,
            SINGLE_TAB: self._init_tab
        }[k](ref)

    def _init_autocrop(self, q):
        """
        Initialize an autocrop image.

        q: tuple
            (GIMP image, Single)
        """
        j, namer = q
        self._image = j
        self.name = namer.name
        self.get_image = self.get_autocrop_ref

    def _init_file_path(self, n):
        """
        Initialize a file-path reference.

        n: string
            file-path
            Reference an image file in storage.
        """
        self._image = n
        self.name = os.path.splitext(os.path.basename(n))[0]
        self.get_image = self.get_file_ref

    def _init_flat(self, q):
        """
        Initialize a file-path reference.

        q: tuple
            (GIMP image or None, GIMP image)
        """
        j, namer = q
        self._image = j
        self.name = namer.name
        self.get_image = self.get_flat_ref

    def _init_layer(self, z):
        """
        Initialize a layer reference.

        z: GIMP layer
            Reference a layer open in GIMP.
        """
        self._image = z
        self.name = z.name
        self.get_image = self.get_layer_ref

    def _init_slice(self, q):
        """
        q: tuple
            (Type, layer, Rect, Single)
        """
        mage, z, t, namer = q
        self._image = z, t
        self.width, self.height = q[2].size
        self.name = "{} ({}, {})".format(namer.name, mage.r_i, mage.c_i)
        self.get_image = self.get_slice_ref

    def _init_tab(self, j):
        """
        Initialize an open image tab reference.

        j: GIMP image
        """
        self._image = j
        self.width, self.height = j.width, j.height
        self.name = Pic.name_q[Pic.tab_q.index(j)]
        self.get_image = self.get_loaded

    def get_autocrop_ref(self, *_, **d):
        """"
        Create an autocrop image if the flattened image's
        selection size is less than the image size.

        Return: GIMP image or None
        """
        mage = d.get('mage')
        if mage:
            if not mage.is_load:
                mage.is_wait = True
                # Load in a view run.
                return

        z = self._image.layers[0]
        w, h = self._image.width, self._image.height
        self.get_image = self.get_loaded

        select_item(z)

        is_sel, _, _, w1, h1 = get_select_bounds(self._image)
        if is_sel:
            if (w, h) != (w1, h1):
                pdb.gimp_edit_copy(z)

                self._image = paste_image()
                if self._image:
                    Pic.opened_q.append(self._image)
            return self._image

    def get_file_ref(self, *_, **d):
        """
        Create an image for a file-path. Load once.

        Return: GIMP image or None
        """
        mage = d.get('mage')

        if mage:
            if not mage.is_load:
                mage.is_wait = True
                # Load in a view run.
                return

        n = self._image
        self._image = None
        n = n if n and os.path.isfile(n) else None
        self.get_image = self.get_loaded

        if n:
            self._image = _get_file_from_path(n)
            if self._image:
                Pic.opened_q.append(self._image)
        return self._image

    def get_flat_ref(self, *_, **d):
        """
        Create a reference to a flat or flatten image.

        Return: GIMP image or None
        """
        mage = d.get('mage')

        if mage:
            if not mage.is_load:
                mage.is_wait = True
                # Load in a view run.
                return

        self.get_image = self.get_loaded

        if self._image and len(self._image.layers) > 1:
            # Create a flattened image.
            copy_all_image(self._image)

            self._image = paste_image()
            if self._image:
                Pic.opened_q.append(self._image)
        return self._image

    def get_layer_ref(self, *_, **d):
        """
        Create an image for a layer. Load once.

        Return: GIMP image or None
        """
        mage = d.get('mage')

        if mage:
            if not mage.is_load:
                mage.is_wait = True
                # Load in a view run.
                return

        z = self._image
        self.get_image = self.get_loaded

        pdb.gimp_selection_none(z.image)
        pdb.gimp_edit_copy(z)

        self._image = paste_image()

        if self._image:
            Pic.opened_q.append(self._image)
        return self._image

    def get_loaded(self, *_, **__):
        """
        Fetch the GIMP image corresponding with open image tab.

        Return: GIMP image
        """
        return self._image

    def get_slice_ref(self, *_, **d):
        """
        Create an image for a slice. Load once.

        Return: GIMP image or None
        """
        mage = d.get('mage')

        if mage:
            if not mage.is_load:
                mage.is_wait = True
                # Load in a view run.
                return

        z, t = self._image
        self.get_image = self.get_loaded

        select_rect(z.image, *t.rect)
        pdb.gimp_edit_copy_visible(z.image)

        self._image = paste_image()

        if self._image:
            Pic.opened_q.append(self._image)
        return self._image
