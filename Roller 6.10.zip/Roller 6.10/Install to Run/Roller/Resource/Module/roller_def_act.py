#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Cat, Path
from roller_constant_for import (
    Backdrop as bs,
    Below as be,
    Bump as fb,
    Deco as dc,
    Frame as ff,
    Fill as fl,
    Gradient as fg,
    Grid as gr,
    Justification as ju,
    Image as fi,
    Mask as ms,
    Resize as fz,
    Shape as sh,
    Triangle as ft
)
from roller_constant_key import Option as ok, Widget as wk
from roller_fu_comm import show_err
from roller_fu_mode import Mode
from roller_image_pic import Pic
from roller_one_wip import get_factor_h, get_factor_w
import glob
import os

MAX_TAB = 7


# Reduce memory consumption with a list-getter.________________________________
def get_backdrop_type_list():
    return bs.BACKDROP_TYPE


def get_below_type_list():
    return be.TYPE


def get_box_type_list():
    return sh.BOX_TYPE


def get_brush_list():
    return Cat.brush_list


def get_bump_type_list():
    return fb.TYPE


def get_camo_type_list():
    return ff.CAMO_TYPE


def get_cell_shape_list():
    return sh.CELL_SHAPE_LIST


def get_criterion_list():
    return fl.CRITERION_LIST


def get_component_list():
    return bs.COMPONENT


def get_corner_type_list():
    return ms.CORNER_TYPE_Q


def get_deco_type_list():
    return dc.TYPE


def get_edge_mode_list():
    return Mode.EDGE_MODE


def get_frame_list():
    """
    Make a list of frame file for Over/Type.

    Return: list
        of GIMP-opened image name
    """
    files = []
    frame_list = ["None"]
    go = False

    try:
        # Ignore sub-directories.
        files = glob.glob(Path.frame + os.path.sep + "*.png")
        go = True

    except Exception as ex:
        show_err(ex)
        show_err("Roller was unable to load frame images.")

    if go:
        for i in files:
            frame_list += [os.path.splitext(os.path.basename(i))[0]]
    return frame_list


def get_frame_style_list():
    return ff.OVERLAY_TYPE


def get_gradient_angle_list():
    return fg.GRADIENT_ANGLE


def get_gradient_list():
    return Cat.gradient_list


def get_gradient_type_list():
    return fg.GRADIENT_TYPE_LIST


def get_grid_type_list():
    return gr.TYPE_LIST


def get_hexagon_type_list():
    return ms.HEXAGON_TYPE_Q


def get_image_name_list():
    return Pic.name_q


def get_image_type_list():
    return fi.IMAGE_TYPE_LIST


def get_justification_type():
    return ju.TYPE


def get_mask_list():
    return ms.TYPE


def get_mesh_type_list():
    return bs.MESH_TYPE


def get_mode_name_list():
    return Mode.MODE_Q


def get_news_type_list():
    return bs.NEWS_TYPE


def get_noise_list():
    return ff.NOISE_TYPE


def get_octagon_type_list():
    return ms.OCTAGON_TYPE_Q


def get_decay_type_list():
    return ff.DECAY_TYPE


def get_pattern_list():
    return Cat.pattern_list


def get_pin_list():
    return gr.PIN_LIST


def get_profile_list():
    return ff.PROFILE


def get_rectangle_type_list():
    return ms.RECTANGLE_TYPE_Q


def get_resize_type_list():
    return fz.RESIZE_TYPE_LIST


def get_reverb_type_list():
    return bs.REVERB_TYPE


def get_shape_list():
    return (
        sh.RECTANGLE,
        sh.CIRCLE,
        sh.ELLIPSE,
        sh.HEXAGON,
        sh.HEXAGON_TRUNCATED,
        sh.OCTAGON,
        sh.OCTAGON_ON_ITS_SIDE,
        sh.SQUARE,
        sh.SQUARE_MITERED,
        ft.TRIANGLE_DOWN_REGULAR,
        ft.TRIANGLE_LEFT_REGULAR,
        ft.TRIANGLE_RIGHT_REGULAR,
        ft.TRIANGLE_UP_REGULAR
    )


def get_shaped_list():
    return fg.SHAPED_TYPE


def get_spiral_mod_list():
    return bs.SPIRAL_MOD_LIST


def get_triangle_type_list():
    return ms.TRIANGLE_TYPE_Q


def get_wrap_types():
    return ff.WRAP_TYPE_Q


def get_vector_list():
    return bs.VECTOR
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Make tooltip.________________________________________________________________
def get_tip_format(i, indent):
    """
    Make two strings for formatting a dynamic tooltip.
    Unfortunately, the tooltip font is not monospaced, so the
    indented strings don't always align on the same tab stop.

    i: string
        option key

    indent: int
        for formatting tab

    Return: tuple
        (string, string)
        (prefix, postfix)
    """
    # tab distance, '4'
    a = (MAX_TAB, MAX_TAB + 2)[indent >= 4]
    a = a - len(i) // 4 - indent
    return (
        '\t' * indent if indent else " ",
        '\t' * max(1, int(a))
    )


def make_bool_tip(d, i, indent, _):
    """
    Make a tooltip for an option value that is boolean.

    d: dict
        option group Preset

    i: string
        option key

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    n, n1 = get_tip_format(i, indent)
    return n + i + n1 + '{} '.format(bool(d[i]))


def make_heat_tip(d):
    """
    Make a tooltip for the Heat OptionButton.

    d: dict
        Heat Preset
        {Option key: value}

    Return: string
        formatted for option
    """
    if d:
        n = " Heat \n"
        for i, a in d.items():
            n += '\t' + i + ":\t"
            n += "Mode: {},\t".format(a.get(ok.MODE))
            n += "Opacity: {} \n".format(a.get(ok.OPACITY))
    else:
        n = " Heat is empty. \n"

    # Remove the last carriage return.
    n = n[:-2]
    return n


def make_radio_tip(d, i, indent, e):
    """
    Make a tooltip for an option that has two RadioButton.

    d: dict
        Preset

    i: string
        Option key

    indent: int
        for formatting tab

    e: dict
        option's init value

    Return: string
        formatted for option
    """
    n, n1 = get_tip_format(i, indent)
    return n + i + n1 + '{} '.format(e[wk.TEXT][int(d[i])])


def make_rainbow_count_tip(d, k, indent, _):
    """
    Translate multi-line text into a tooltip.

    d: dict
        Preset

    k: string
        Option key

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    k1 = k.split(",")[0]
    n, n1 = get_tip_format(k1, indent)
    n2, n3 = get_tip_format(k1, indent + 1)
    tip = n + k1 + n1

    for i in range(int(d[ok.COLOR_COUNT])):
        tip += ' \n'
        tip += n2 + str(d[k][i]) + n3
    return tip


def make_rainbow_tip(d, k, indent, _):
    """
    The Rainbow Widget has a multiline tooltip and
    changes visible Widget with the number of colors.

    d: dict
        Preset

    k: string
        Option key

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    k1 = k.split(",")[0]
    n, n1 = get_tip_format(k1, indent)
    n2, n3 = get_tip_format(k1, indent + 1)
    tip = n + k1 + n1

    for k1 in d[k]:
        tip += ' \n'
        tip += n2 + str(k1) + n3
    return tip


def make_slider_tip(d, k, indent, _):
    """
    Make a tooltip for an view size factored slider option value.

    d: dict
        Preset

    k: string
        Option key

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    k1 = k.split(",")[0]
    a = get_factor_w(d[k]) \
        if k in (ok.END_X, ok.START_X, ok.LEFT, ok.RIGHT) \
        else get_factor_h(d[k])

    if a == int(a):
        a = int(a)

    n, n1 = get_tip_format(k1, indent)
    return n + k1 + n1 + '{} '.format(a)


def make_text_tip(d, k, indent, _):
    """
    Make a tooltip for an option value that is translated as text.

    d: dict
        Preset

    k: string
        Option key

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    k1 = k.split(",")[0]
    n, n1 = get_tip_format(k1, indent)
    a = d[k]

    if isinstance(a, float) and a == round(a):
        a = int(a)
    return n + k1 + n1 + '{} '.format(a)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


def scour(d, e, seek):
    """
    Recursively peruse a group definition dict collecting Widget init value.

    d: dict
        Reflect group tree structure.
        {Option key: option value or dict of option value}

    e: dict
        Is an option group definition.

    seek: string
        Is the Option key to collect in the data definition tree.

    Return: dict
        with option value
    """
    for k, a in e.items():
        if isinstance(a, dict):
            if seek in a:
                d[k] = a[seek]
            else:
                if k == wk.SUB:
                    # The SUB key is not part of the value dict.
                    b = d
                else:
                    b = d[k] = {}

                scour(b, a, seek)
                if not b and k in d:
                    d.pop(k)
    return d
