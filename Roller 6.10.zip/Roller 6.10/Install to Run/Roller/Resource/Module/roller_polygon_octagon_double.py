#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_model_goo import Goo
from roller_polygon import calc_pin_xy

# The odd row and column intersects are offset in their intersect list.
ODD_INTERSECT_OFFSET = 2
OCTAGON_REMAIN = 1. - sh.OCTAGON_RATIO


class GridOctagonDouble:
    """Calculate a double-spaced grid of octagon shaped cell."""

    @staticmethod
    def calc(model, o):
        """
        Calculate cell rectangle and form polygon for a Model's cell.

        model: Model
        o: One
            Has attribute translated from Cell/Type option.

        Return: dict
            {value: [bool, bool]}
            {cell key: [Plan vote change, Work vote change]}
        """
        def _calc_intersect():
            """
            Calculate vertical and horizontal intersect points.

            Return: tuple
                grid size
            """
            _w1 = w * sh.OCTAGON_RATIO
            _h1 = h * sh.OCTAGON_RATIO
            _w2 = w - _w1
            _h2 = h - _h1
            _w3 = w - _w1 - _w1
            _h3 = h - _h1 - _h1
            _s1 = (column - 1) * _w2 + w, (row - 1) * _h2 + h
            _x, _y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *_s1)
            _s1 = canvas_w + _x, canvas_h + _y

            for _ in range(row):
                q_y.extend(
                    (
                        round(_y),
                        round(_y + _h1),
                        round(_y + _h2),
                        round(_y + h)
                    )
                )
                _y += h + _h3

            for _ in range(column):
                q_x.extend(
                    (
                        round(_x),
                        round(_x + _w1),
                        round(_x + _w2),
                        round(_x + w)
                    )
                )
                _x += w + _w3
            return _s1

        def _get_intersects():
            """
            Get the points for a double-spaced octagon.

            Return: tuple
                of octagon offsets
            """
            # Shifting, '<<' by 2 is the same as
            # multiplying by 4, but faster with integer.
            _c1 = c // 2 << 2
            _r1 = r // 2 << 2

            if c % 2:
                _index_x = ((c - 1) << 2) + 2 - _c1

            else:
                _index_x = (c << 2) - _c1

            if r % 2:
                _index_y = ((r - 1) << 2) + 2 - _r1

            else:
                _index_y = (r << 2) - _r1
            return q_x[_index_x:_index_x+4], q_y[_index_y:_index_y+4]

        vote_d = {}
        did_cell = model.past.did_cell
        row, column = model.grid
        goo_d = model.goo_d
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect

        # [intersect point]
        q_x, q_y = [], []

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w = min(canvas_w, o.column_width)
            h = min(canvas_h, o.row_height)

        elif o.grid_type == gr.SHAPE_COUNT:
            w = canvas_w / (sh.OCTAGON_RATIO + column * OCTAGON_REMAIN)
            h = canvas_h / (sh.OCTAGON_RATIO + row * OCTAGON_REMAIN)
            w = min(w, h)
            w, h = w, w

        else:
            w = canvas_w / (sh.OCTAGON_RATIO + column * OCTAGON_REMAIN)
            h = canvas_h / (sh.OCTAGON_RATIO + row * OCTAGON_REMAIN)

        _calc_intersect()

        for r_c in model.cell_q:
            r, c = r_c
            q, q1 = _get_intersects()
            a = goo_d[r_c] = Goo(r_c)
            x, y = q[0], q1[0]
            x1, y1 = q[3], q1[3]

            # Prevent round to zero with max 1.
            a.cell.rect = a.merged.rect = \
                x, y, max(1., x1 - x), max(1., y1 - y)

            a.form = (
                q[1], y,
                q[2], y,
                x1, q1[1],
                x1, q1[2],
                q[2], y1,
                q[1], y1,
                x, q1[2],
                x, q1[1]
            )
            vote_d[r_c] = did_cell(r_c)
        return vote_d
