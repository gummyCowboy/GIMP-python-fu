#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import FOREGROUND_FILL, pdb  # type: ignore
from roller_constant_key import Option as ok
from roller_fu import merge_layer_group
from roller_maya_style import Style, make_background
from roller_view_hub import do_mod, set_fill_context
from roller_view_real import add_sub_base_group

"""
Define 'backdrop/color_fill' as a Maya-subtype
for managing a variation of backdrop style layer.
"""


def make_style(maya):
    """
    Make a style layer.

    maya: Style
    Return: layer or None
        Backdrop Style material
    """
    d = maya.value_d
    parent = add_sub_base_group(maya)
    z = make_background(parent)

    # RGBA, 'q'
    q = d[ok.COLOR_1A]

    # Use to set the opacity context for bucket fill.
    d[ok.FILL_OPACITY] = q[3] / 255. * 100.

    set_fill_context(d)
    pdb.gimp_context_set_foreground(q)
    pdb.gimp_drawable_edit_bucket_fill(z, FOREGROUND_FILL, .0, .0)

    z = merge_layer_group(parent)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class ColorFill(Style):
    """Create Backdrop Style output."""
    is_dependent = True

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.BRW, ok.MOD, ok.BLUR_D)
            ],
            make_style
        )
