#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Model as md, Option as ok
from roller_many_rect import Rect
from roller_model import CellPast, Model, CELL_CHAIN
from roller_model_cell_branch import CellBranch
from roller_model_facing import Facing
from roller_model_goo import Goo
from roller_one_ring import Ring
from roller_one_wip import Wip, get_factor


def _make_wedge_num(n):
    """
    Convert a sample string to a float. If the string is not numeric the
    string defaults to '1.'.

    n: string
        Is a sub-sample string.

    Return: float
        Is the value of the string.
    """
    q = [i for i in n if i in '0123456789.']

    if not q:
        return 1.

    n = ""

    for a in q:
        n += a
    return float(n)


class Pie(Model, Facing):
    """Is a single cell Model."""
    model_type = md.PIE

    def __init__(self, model_name):
        """
        model_name: string
            Identify the model.
        """
        Model.__init__(self, model_name, CellPast, CELL_CHAIN)
        Facing.__init__(self)

        self.center = .0, .0
        self.rectangle = .0, .0, .0, .0
        self.is_sample = False
        self.arc_q = self.angle_q = self.sample_q = self.pie_shape = None

        self.latch(self.baby, (si.RECT_CHANGE, self.on_rect_change))
        self.latch(Ring.gob, (si.RESIZE, self.on_resize))
        self.on_resize(None, None)

    def calc_grid(self, d):
        """
        Determine the row and column count of the cell grid.
        Depend on the Canvas 'pocket'.

        d: dict
            Cell/Type Preset
        """
        q = []

        if self.is_sample:
            q = d[ok.SAMPLE].split(",")
            q = [i.strip() for i in q]
            q = [_make_wedge_num(i) for i in q]

            if not q:
                q = [1.]
            row = len(q)

        else:
            row = int(d[ok.CELL_COUNT])

        self.sample_q = q
        self.grid = row, 1
        self.baby.emit(si.GRID_CHANGE, self.grid)

    def calc_pie_cell(self, d):
        angle = d[ok.ANGLE]

        if self.is_sample:
            pass

        else:
            pass
        return

    def init_cell_q(self, d):
        """
        Cell's list of cell index doesn't change.

        d: dict
            Cell/Type dict
        """
        if self.is_sample:
            row = len(self.sample_q)

        else:
            row = d[ok.CELL_COUNT]

        self.cell_q = [(r, 0) for r in range(row)]
        self.face_q = [(r, 0, 0) for r in range(row)]

    def init_model_cell(self, d):
        """
        Set the 'cell', 'merged', and 'plaque' value.

        d: dict
            Cell/Type Preset
            {Option key: value}

        Return: dict
            {cell key: [Plan vote, Work vote]}
            Each vote is a vote for change.
        """
        self.goo_d = {}
        return self.calc_pie_cell(d)

    def on_rect_change(self, _, arg):
        """
        Update the Cell's rectangle.

        _: Model
            Sent the signal.

        arg: tuple
            (Rectangle Preset, is sequence flag)
        """
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        x, y, w, h = Wip.get_rect()
        w1 = max(1., get_factor(d[ok.WIDTH], w))
        self.rectangle = (
            # position x, y
            x + get_factor(d[ok.PX], w),
            y + get_factor(d[ok.PY], h),

            # size w, h
            w1, w1
        )
        p(
            si.RECT_CALC, self.past.did_rectangle(self.rectangle)
        )

    def on_resize(self, _, arg):
        """
        Update the Cell's default Canvas setting on a render resize event.

        _: Ring
            Sent the Signal.

        arg: list
            Plan and Work vote.
            not used
        """
        self.canvas_rect = Wip.get_rect()
        self.canvas_pocket = Rect(*self.canvas_rect)

    def update_type(self, arg):
        """
        Update the Model's Cell/Type dependency.

        arg: tuple
            (Cell/Type Preset, is sequence flag)
            A sequence is processed immediately.
        """
        d, is_sequence = arg
        self.is_sample = bool(d[ok.PIE])
        self.pie_shape = d[ok.TYPE]
        p = self.baby.feed if is_sequence else self.baby.give
        vote_d = super(CellBranch, self).update_type(arg)

        self.adapt_missing_cell_step(is_sequence)
        p(si.CELL_RECT_CALC, vote_d)
