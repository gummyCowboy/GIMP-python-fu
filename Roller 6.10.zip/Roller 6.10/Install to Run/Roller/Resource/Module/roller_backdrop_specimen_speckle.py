#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE,
    FILL_PATTERN,
    LAYER_MODE_HARD_MIX,
    LAYER_MODE_LCH_COLOR,
    LAYER_MODE_OVERLAY,
    pdb
)
from roller_a_contain import Run
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def_access import get_default_value
from roller_fu import (
    blur_selection, clone_layer, make_layer_group, merge_layer_group
)
from roller_maya_style import Style
from roller_view_hub import (
    color_layer_default,
    do_gradient_for_layer,
    do_mod,
    set_fill_context,
    set_gimp_pattern
)
from roller_view_real import add_sub_base_group, add_wip_layer

"""
Define 'backdrop/specimen_speckle' as a Maya-subtype
for managing a variation of backdrop style layer.
"""


def make_style(maya):
    """
    Make a style layer.

    maya: SpecimenSpeckle
    Return: layer or None
        the style layer
    """
    def _do_hard_mix(_pattern):
        """
        Create a hard mix layer.

        _pattern: string
            pattern descriptor

        Return: layer
            hard mix
        """
        _z = clone_layer(z, n="Hard Mix")
        _z.opacity = 50.
        _z.mode = LAYER_MODE_HARD_MIX

        set_gimp_pattern(_pattern)

        # x, y layer offset, '1'
        pdb.gimp_drawable_edit_bucket_fill(_z, FILL_PATTERN, .0, .0)

        _do_wind(_z)
        return _z

    def _do_overlay():
        """
        Create an overlay layer.

        Return: layer
            overlay
        """
        _z = clone_layer(z, n="Overlay")
        _z.opacity = 100.
        _z.mode = LAYER_MODE_OVERLAY

        # no linear, '0'
        pdb.gimp_drawable_invert(_z, 0)

        blur_selection(_z, 5)
        return _z

    def _do_wind(_z):
        """
        Do the wind function for each of the four directions.

        _z: layer
            Receive wind.
        """
        # the direction of wind, 'i'
        for i in (0, 1, 2, 3):
            pdb.plug_in_wind(
                j, _z,
                0,              # threshold
                i,
                25,             # strength
                1,              # blast
                1               # leading edge
            )

    j = Run.j
    d = maya.value_d
    group = add_sub_base_group(maya)
    group1 = make_layer_group(j, maya.kind, group, 0)
    base = add_wip_layer("Base", group1)

    color_layer_default(base, d[ok.COLOR_1])

    e = get_default_value(by.GRADIENT_FILL)
    e[ok.GRADIENT] = d[ok.RW1][ok.GRADIENT]
    e[ok.OPACITY] = d[ok.GRADIENT_OPACITY]
    e[ok.REVERSE] = d[ok.REVERSE]
    z = do_gradient_for_layer(e, group1, 0)

    _do_overlay()

    # gradient
    e[ok.END_X] = e[ok.END_Y] = .0
    e[ok.START_X] = e[ok.START_Y] = 1.
    z = do_gradient_for_layer(e, group1, 0)

    set_fill_context(
        {
            ok.THRESHOLD: .6,
            ok.FILL_OPACITY: 100.,
            ok.FILL_MODE: "Normal",
            ok.CRITERION: "Composite"
        }
    )

    e = d[ok.PAR]

    # pattern #1
    z = _do_hard_mix(e[ok.PATTERN_1])
    z = _do_overlay()

    # pattern #2
    z = _do_hard_mix(e[ok.PATTERN_2])
    z = _do_overlay()

    # pattern #3
    z = _do_hard_mix(e[ok.PATTERN_3])

    _do_overlay()

    # phase two
    z = merge_layer_group(group1)
    z1 = clone_layer(z)
    z2 = clone_layer(z1)

    clone_layer(z2)
    blur_selection(z1, 6)
    blur_selection(z2, 6)

    # no linear, '0'
    pdb.gimp_drawable_invert(z1, 0)

    z = merge_layer_group(group)
    z = z1 = clone_layer(z, n="Hard Mix")
    z.mode = LAYER_MODE_HARD_MIX
    z = clone_layer(z, n="LCH Color")
    z.mode = LAYER_MODE_LCH_COLOR

    pdb.plug_in_colorify(j, z, d[ok.COLOR_1])
    pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

    z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

    do_mod(z, d[ok.RW1][ok.MOD])
    return maya.rename_layer(z)


class SpecimenSpeckle(Style):
    """Create Backdrop Style output."""
    is_dependent = True

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.RW1,),
                k_path + (ok.RW1, ok.MOD),
                k_path + (ok.RW1, ok.MOD, ok.BLUR_D),
                k_path + (ok.PAR,)
            ],
            make_style
        )
