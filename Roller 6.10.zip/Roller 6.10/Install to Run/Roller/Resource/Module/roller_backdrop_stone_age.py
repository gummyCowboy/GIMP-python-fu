#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (     # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_MULTIPLY,
    pdb
)
from roller_a_contain import Run
from roller_a_gegl import spread
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clear_inverse_selection,
    clone_layer,
    make_layer_group,
    merge_layer_group,
    remove_z,
    select_item,
    select_rect,
)
from roller_maya_style import Style, make_background
from roller_one_wip import Wip
from roller_view_hub import (
    clipboard_fill_default,
    color_selection,
    do_curves,
    do_mod,
    get_mean_color,
    make_cube_pattern
)
from roller_view_real import add_sub_base_group, add_wip_below

"""
Define 'backdrop/stone_age' as a Maya-subtype
for managing a variation of backdrop style layer.
"""


# Made of x, y pairs that range from .0 to 1..
CURVES = (
    # one
    (
        .0, .0,
        .4, .1,
        .8, .8,
        1., 1.
    ),

    # two
    (
        .0, .0,
        .2, .0,
        .5, 1.,
        .75, 1.,
        1., .0
    ),

    # three
    (
        .0, .0,
        .25, 1.,
        .5, 1.,
        .8, .0,
        1., .0
    ),

    # four
    (
        .0, 1.,
        .25, 1.,
        .55, .0,
        1., .0
    )
)


def draw_layer(j, z, d, layer_num):
    """
    There are four layers, each having a different pattern and
    value range. Each pattern is a cube, but differs by scale.
    The value range is determined by the CURVES settings.

    j: GIMP image
        Is render.

    z: layer
        Backing copy

    d: dict
        Stone Age Preset

    layer_num: int
        distinguish range and type
    """
    # receiving layer, 'z1'
    z1 = clone_layer(z, n="Curves")

    # layer with the color value, 'z2'
    z2 = clone_layer(z, n="Color")

    do_curves(z1, CURVES[layer_num])

    # Erase the black.
    pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

    # layer to receive symbol and color, 'z'
    z = clone_layer(z, n="{} of 4".format(str(layer_num + 1)))
    z.mode = LAYER_MODE_MULTIPLY

    make_cube_pattern(
        d[ok.PATTERN_SIZE] * (layer_num + 1),
        [(255, 255, 255), (187, 187, 187), (127, 127, 127)]
    )
    select_rect(j, *Wip.get_rect())
    clipboard_fill_default(z)
    select_item(z1)
    clear_inverse_selection(z)
    select_item(z1)
    clear_inverse_selection(z2)

    # Get the mean color to fill the layer.
    avg_color = get_mean_color(z2)

    # Fill existing pixels with the mean
    # color using their material selection.
    color_z = add_wip_below(z)

    select_item(z)
    color_selection(color_z, avg_color)
    pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
    remove_z(z1)
    remove_z(z2)


def make_style(maya):
    """
    Make a style layer.

    maya: StoneAge
    Return: layer or None
        Backdrop Style material
    """
    j = Run.j
    d = maya.value_d
    parent = add_sub_base_group(maya)
    group = make_layer_group(j, "WIP", parent, 0)
    z = make_background(group)

    for i in range(4):
        draw_layer(j, z, d, i)

    pdb.gimp_selection_none(j)
    blur_selection(z, 500.)

    z = merge_layer_group(group)
    z = clone_layer(z)
    z.mode = LAYER_MODE_DIFFERENCE

    do_curves(z, (.0, .0, .0431, .3411, 1., 1.))

    arg = (15, 10) if j.width > j.height else (10, 15)

    spread(z, *arg)

    z = merge_layer_group(parent)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class StoneAge(Style):
    """Create Backdrop Style output."""

    def __init__(self, any_group, super_maya, k_path):
        self.init_background(any_group, super_maya, k_path, make_style)
