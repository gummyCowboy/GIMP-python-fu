#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one_tip import Tip
from roller_port_preview import PortPreview
from roller_widget_button import Button
from roller_widget_node import Piece


class PortImageChoice(PortPreview):
    """Is a display container for the Image Choice Preset."""
    window_key = "Image"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_image_options(self, box):
        """
        Draw the Image Choice Preset.

        box : VBox
            container for Widget
        """
        self.draw_group(Piece(
            ok.IMAGE_CHOICE, box, self.repo.any_group.item, has_label=False
        ))

    def draw(self):
        """Draw Widget."""
        self.draw_column((self._draw_image_options, self.draw_process))

    def get_group_value(self):
        """
        Fetch the Preset value.

        Return: dict
            Image Preset
        """
        return self.preset.get_a()

    def on_port_change(self, g):
        """
        Respond to Widget change. Set the tooltip for the Type ComboBox.

        g: Widget
            Is responsible.
        """
        # ComboBox tool-tips don't stick during
        # initialization, so the tips are made on the go.
        if not isinstance(g, Button):
            d = g.any_group.widget_d
            for g1 in d.values():
                if g1.key == ok.TAB:
                    g1.widget.set_tooltip_text(Tip.TAB)
                elif g1.key == ok.IMAGE_NAME:
                    g1.widget.set_tooltip_text(Tip.IMAGE_NAME)
        super(PortImageChoice, self).on_port_change(g)
