#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import floor
from roller_constant_for import Grid as gr, Shape as sh, Triangle as ft
from roller_model_goo import Mesh
from roller_polygon import calc_pin_xy
from roller_polygon_box import calc_box_cell, calc_box_b_w, calc_hex_ratio

"""
Define 'polygon_box_hexagon_trunc' as a class for calculating
base cell vertices of a horizontal Box shape.
"""


class BoxHexT:
    """
    Calculate the grid position and the size of a truncated hexagon cell shape.
    The ends are pointing horizontally. Is a double-spaced cell model-type.
    """

    @staticmethod
    def calc(model, o):
        """
        For Model cell, calculate 'cell' and 'merge'
        rectangle and their inscribed 'form' polygon.

        model: Model
        o: One
            Has Cell/Type option attribute.

        Return: dict
            {value: [bool, bool]}
            {cell key: [Plan vote change, Work vote change]}
        """
        def _arrange():
            """
            Arrange a hexagon shape of x, y coordinate where each
            x, y pair is a polygon vertex. Order coordinate from
            the upper left-most point and connect points clockwise.

            Return: tuple
                shape
            """
            return x, y2, x2, y, x4, y, x5, y1, x3, y3, x1, y3

        def _arrange_flip_x():
            """The x coordinate is flipped."""
            return x, y1, x1, y, x3, y, x5, y2, x4, y3, x2, y3

        def _arrange_flip_xy():
            """The x and y coordinates are flipped."""
            return x, y2, x2, y, x4, y, x5, y1, x3, y3, x1, y3

        def _arrange_flip_y():
            """The y coordinate is flipped."""
            return x, y1, x1, y, x3, y, x5, y2, x4, y3, x2, y3

        def _calc_pin(flip_a_w, flip_b_w, a_grid_w, b_grid_w):
            """
            Justify grid. When a vector is
            flipped, it gains an additional offset.

            flip_a_w, flip_b_w: float
                Each is a span of the grid's 'a' and 'b' vector offsets.
                For this hexagon, 'b' is the 'x' vector,
                and 'a' is 'y' vector.

            a_grid_w, b_grid_w: float
                Each is a span of the grid's 'a' and 'b' dimensions.
                For this hexagon, 'b' is the 'x' vector,
                and 'a' is 'y' vector.

            Return: tuple
                (a, b) ordered x and y pin offsets of float
            """
            _x, _y = calc_pin_xy(
                o.pin,
                x - flip_b_w, y - flip_a_w,
                canvas_w, canvas_h,
                b_grid_w, a_grid_w
            )
            return _y, _x

        is_left = model.is_positive_b = o.box_type == sh.LEFT
        model.is_positive_a = o.cap_y <= .5
        row, column = model.grid
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect
        ratio_w = model.ratio = calc_hex_ratio(o.cap_x, is_left)

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w = min(canvas_w, o.column_width)
            h = min(canvas_h, o.row_height)

        elif o.grid_type == gr.SHAPE_COUNT:
            # cell size, 'w, h'
            w = floor(canvas_w / (ratio_w + column * (1. - ratio_w)))
            h = floor(canvas_h / (.5 + row * .5))

            # two possible solutions
            # hexagon size, 'hex_w, hex_h'
            hex_w, hex_h = h * ft.SCALE_UP, h

            w1 = hex_w * ratio_w
            w2 = hex_w - w1
            h1 = hex_h / 2.

            # Check for overflow.
            if column * w2 + w1 > canvas_w or row * h1 + h1 > canvas_h:
                # solution two
                w, h = w, w * ft.SCALE_DOWN

            else:
                # solution one
                w, h = hex_w, hex_h

        else:
            # Calculate the cell size.
            h = canvas_h / (.5 + row * .5)
            w = canvas_w / (ratio_w + column * (1. - ratio_w))

        w = calc_box_b_w(o.cap_x, w, is_left)

        # Begin cell calc and arrange point.
        vote_d = {}
        goo_d = model.goo_d
        did_cell = model.past.did_cell
        is_flip_y = o.cap_y > .5
        is_flip_x = not is_left      # Is right.
        q_y, q_x, offset_h, offset_w = calc_box_cell(
            o.cap_y - .5 if is_flip_y else .5 - o.cap_y,
            column, row,
            h, w,
            ratio_w,
            is_flip_y, is_flip_x,
            canvas_h, canvas_w,
            _calc_pin
        )
        p = (
            _arrange, _arrange_flip_y, _arrange_flip_x, _arrange_flip_xy
        )[is_flip_y + is_flip_x * 2]

        for r_c in model.cell_q:
            r, c = r_c
            r1 = r * 2
            c1 = c * 4
            x, x1, x2, x3, x4, x5 = q_x[c1:c1 + 6]
            y, y1, y2, y3 = q_y[r1:r1 + 4]
            a = goo_d[r_c] = Mesh(r_c)

            # Prevent round to zero with max 1.
            a.cell.rect = a.merged.rect = \
                x, y, max(1., abs(x5 - x)), max(1., abs(y3 - y))
            a.form = p()
            a.cap_x = a.form_cap_x = a.shift_cap_x = round(x + offset_w)
            a.cap_y = a.form_cap_y = a.shift_cap_y = round(y + offset_h)
            vote_d[r_c] = did_cell(r_c)
        return vote_d
