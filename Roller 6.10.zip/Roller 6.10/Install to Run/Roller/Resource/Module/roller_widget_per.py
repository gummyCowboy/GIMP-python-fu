#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_a_contain import The
from roller_constant_for import Signal as si, Issue as vo
from roller_constant_key import Button as bk, Option as ok, Widget as wk
from roller_def_access import get_vote_d
from roller_one_extract import get_option_list_choice
from roller_one_tip import Tip
from roller_port_per import (
    PortPerCell, PortPerFace, PortPerFacing, PortPerMerge
)
from roller_widget import set_widget_attr
from roller_widget_button import ProcessButton
from roller_widget_check_button import CheckButton
from roller_widget_voter import accept_vote
import gobject  # type: ignore
import gtk      # type: ignore


def compare_views(g):
    """
    Compare both the Plan and view values.

    g: PerGroup
        with value table
    """
    # Do Work and Plan, '2'.
    for i in range(2):
        g.compare_value(i)


def compare_preset(g, new_d, i):
    """
    Compare the Preset with its viewed version.

    g: PerGroup
    new_d: dict
        Is the incoming value.

    i: int
        index to Plan or Work; 0 or 1
    """
    old_d = g.view_value[i]
    is_change = new_d != old_d

    # (row, column) or (row, column, face), 'k'; Preset value dict, 'd'
    for k, d in new_d.items():
        vote_d = {}

        reap_vote(
            vote_d,
            g.default_ballot_d,
            old_d[k] if k in old_d else None,
            d
        )
        g.emit(si.PER_CHANGE, (k, vote_d, i))
    return is_change


def compare_type(g, new_d, i):
    """
    Compare the Table/Cell/Type value with its view value.

    g: PerGroup
        Has viewed value.

    new_d: dict
        incoming value

    i: int
        index to Plan or Work
    """
    old_d = g.view_value[i]
    is_change = old_d != new_d

    for r_c, a in new_d.items():
        if a != old_d[r_c] if r_c in old_d else None:
            m = True

        else:
            m = False
        g.emit(si.PER_CHANGE, (r_c, m, i))
    return is_change


def reap_vote(vote_d, ballot_d, old_d, new_d):
    """
    Compare two Preset values. Have each option cast a vote in a
    vote dict. The option's vote is True if the option has changed.

    vote_d: dict
        Collect vote on issue.

    ballot_d: dict
        {Option key: votes}

    old_d: dict
        old value

    new_d: dict
        new value

    Return: dict
        with vote
    """
    if old_d:
        for i, a in ballot_d.items():
            if i == ok.FRAME:
                if i not in vote_d:
                    vote_d[i] = {}

                k = get_option_list_choice(new_d[i])[0]
                k1 = get_option_list_choice(old_d[i])[0]
                sub_ballot_d = get_vote_d(k)

                # A Frame OptionList has no vote in
                # the ballot dict, so it is checked here.
                if new_d[i][ok.SWITCH] != old_d[i][ok.SWITCH]:
                    reap_ballot(vote_d[i], sub_ballot_d, new_d[i][k])

                elif k == k1:
                    reap_vote(
                        vote_d[i], sub_ballot_d, old_d[i][k], new_d[i][k]
                    )
                else:
                    reap_ballot(vote_d[i], sub_ballot_d, new_d[i][k])

            elif isinstance(a, dict):
                if i not in vote_d:
                    vote_d[i] = {}
                reap_vote(vote_d[i], a, old_d[i], new_d[i])
            elif old_d[i] != new_d[i]:
                accept_vote(vote_d, i, a, True)
    else:
        reap_ballot(vote_d, ballot_d, new_d)


def reap_ballot(vote_d, ballot_d, new_d):
    """
    Collect change vote with a default ballot dict.

    vote_d: dict
        Collect vote on issue.

    ballot_d: dict
        Is the default vote for a Preset.
    """
    for i, a in ballot_d.items():
        if i == ok.FRAME:
            k = get_option_list_choice(new_d[i])[0]
            sub_ballot_d = get_vote_d(k)

            if i not in vote_d:
                vote_d[i] = {}
            reap_ballot(vote_d[i], sub_ballot_d, new_d[i][k])

        elif isinstance(a, dict):
            if i not in vote_d:
                vote_d[i] = {}
            reap_ballot(vote_d[i], a, new_d[i])
        else:
            accept_vote(vote_d, i, a, True)


def update_button_visual(g):
    """
    Update the Open Button's visibility.

    g: PerGroup
        Has button.
    """
    if g.check_button.get_a():
        g.button.show()
    else:
        g.button.hide()


class PerGroup(gtk.Alignment, gobject.GObject, object):
    """Has a Per CheckButton and an Open Button."""
    __gsignals__ = si.PER_D
    change_signal = None
    has_table_label = False

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument for Widget.
        """
        super(gtk.Alignment, self).__init__()
        gobject.GObject.__init__(self)

        # the GTK Alignment setting
        self.set(0, 0, 1, 1)

        self._cancel_value = {}

        # Updated after a view and is a copy of 'self._value'.
        # Is ordered as [Plan, Work].
        self.view_value = [{}, {}]

        # {per key: Preset dict}
        self._value = {}

        set_widget_attr(self, d)

    def hide(self, *_):
        """
        Hide the row in the Table container if the Widget is ready.
        Table sets the 'self.box' to a VBox container.
        """
        # There's a timing issue 'box' during init.
        if hasattr(self, 'box') and self.box:
            self.box.hide()
            self.label_box.hide()

    def show(self, *_):
        """
        Show the row in the Table Widget if the Widget is ready.
        The Table Widget class has set the 'self.box' to a VBox container.
        """
        # There's a timing issue 'box' during init.
        if hasattr(self, 'box') and self.box:
            self.box.show()
            self.label_box.show()


class WithWidget(PerGroup):
    """Create PerGroup Widget."""

    def __init__(self, **d):
        PerGroup.__init__(self, **d)

        # Is true when PortPerTable is open.
        self.edit_mode = False

        self._hbox = gtk.HBox()
        relay = d[wk.RELAY][:]
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

        # CheckButton
        # The CheckButton and Button don't cast vote.
        d.pop(wk.ISSUE)
        d[wk.RELAY].insert(0, self.on_per_switch)
        d[wk.STILL] = True
        d[wk.TOOLTIP] = Tip.PER_CHECK_BUTTON
        d[wk.ALIGN] = 0, 0, 0, 1
        self.check_button = CheckButton(**d)

        # Button
        d[wk.TOOLTIP] = Tip.PER_BUTTON
        d[wk.KEY] = d[wk.TEXT] = bk.OPEN
        d[wk.ALIGN] = 0, 0, 1, 0
        d[wk.RELAY] = relay

        relay.insert(0, self.on_open_button_action)

        self.button = self.widget = ProcessButton(**d)

        self.add(self._hbox)
        for i in (self.check_button, self.button):
            self._hbox.add(i)
            same_size.add_widget(i.widget)

    def check_for_lost(self, q):
        """
        Check Per keys for validity with Cell/Type,
        Cell/Shift, or Cell/Margin change.

        q: list
            [(cell key, ...)]
            Are valid keys.
        """
        lost_q = []
        is_change = False

        for k in self._value.keys():
            if k not in q:
                lost_q.append(k)
                self._value.pop(k)
            else:
                # The Per Maya changed.
                is_change = True

        if is_change:
            # Set the view value to trigger change.
            self.view_value = [{}, {}]
            compare_views(self)
        if lost_q:
            self.emit(si.DISAPPEAR, lost_q)

    def get_a(self):
        """
        Get the Preset table.

        Return: list
            Preset table
            2D (list(s) within a list)
            May be an empty list.
        """
        return self._value

    def intersect_vote(self, vote_d):
        """
        Receive a vote dict and send a change Signal.

        vote_d: dict
            {goo or map key: [Plan vote, Work vote]}
        """
        self.check_for_lost(self.any_group.item.model.cell_q)

        group_vote_q = set()
        q = self._value.keys()

        # Plan and Work vote list, 'a'
        for k, a in vote_d.items():
            if k in q:
                # Plan and Work, '2'
                for i in range(2):
                    d = {ok.IS_CHAIN: a[i]}

                    self.emit(
                        si.PER_CHANGE,
                        (k, {vo.MATTER: d, vo.MODE: d, vo.OPACITY: d}, i)
                    )
                    group_vote_q.update((i,))
        for i in group_vote_q:
            self.any_group.cast_vote(i, ok.PER, vo.PER, True)

    def on_accept_cell_edit(self, d):
        """
        Return from PortPer. Exit edit mode.

        d: dict
            Is the new value for the PerGroup.
        """
        self.set_a(d)
        self.edit_mode = False

        # Free the memory.
        self._cancel_value = None

        if self.button.get_sensitive():
            self.button.widget.grab_focus()
        else:
            self.check_button.widget.grab_focus()

    def on_cancel_cell_edit(self):
        """
        Return from PortPer. Exit from edit
        mode. Restore the original value.
        """
        self.set_a(self._cancel_value)
        self.edit_mode = False

    def on_open_button_action(self, _):
        """
        Respond to an Open Button action.

        _: Button
            Is responsible.
        """
        # Restore the original value on cancel.
        self._cancel_value = deepcopy(self._value)

        # Is True when the cell editor is open.
        self.edit_mode = True

        self.roller_win.bring_dialog(
            self,
            d={
                wk.ON_ACCEPT: self.on_accept_cell_edit,
                wk.ON_CANCEL: self.on_cancel_cell_edit,
            }
        )

    def on_per_switch(self, g):
        """
        Respond to a change event for the Per CheckButton.

        g: CheckButton
            Is responsible.
        """
        if not g.get_a():
            self.set_a({})

        # Plan and Work indices, '2'
        for i in range(2):
            self.any_group.cast_vote(
                i, ok.PER, vo.PER, self._value != self.view_value[i]
            )
        update_button_visual(self)

    def set_a(self, d, i=None):
        """
        Set the PerGroup value.

        d: dict
            {(row, column) or (row, column, face): Preset value dict}

        i: int or None
            Indicate the view origin where zero is Plan and one is Work.
        """
        d = self._value = d if isinstance(d, dict) else {}

        if i is not None:
            self.compare_value(self, i)

        else:
            compare_views(self)

        self.check_button.widget.set_active(bool(d))
        self.any_group.update_option_a(self.key, d)

    def set_view_value(self, i, a):
        """
        Remember the value used during a view run.

        i: int
            Plan or Work index; 0 or 1

         a: dict
            Is the same as 'self._value'
        """
        self.view_value[i] = deepcopy(a)


class Cellular(WithWidget):
    """Factor from Cell and Face PerGroup."""

    def __init__(self, **d):
        WithWidget.__init__(self, **d)
        self.default_ballot_d = get_vote_d(self.any_group.item.key)

    def compare_value(self, i):
        """
        Compare 'self._value' with its view value.
        Route Table/Cell/Type differently.

        i: int
            index to Plan or Work attribute
        """
        d = self.get_a()
        is_change = compare_preset(self, d, i)

        # The Per Widget changed.
        self.any_group.cast_vote(i, ok.PER, vo.PER, is_change)

        self.any_group.cast_vote(
            i, ok.IS_MAIN, vo.MATTER, d.keys() != self.view_value[i].keys()
        )

    def get_item(self, k):
        """
        Fetch an item value from 'self._value'.

        k: tuple
            (r, c) or (r, c, face)
            zero-based cell index (r, c) and face index
            Goo or Map key
        """
        if k in self._value:
            return self._value[k]

    def set_a(self, d, i=None):
        """
        Set the PerGroup value.

        d: dict
            {(row, column): Preset value dict}
            The row and column cell index range from 0
            to the span of the Model's table.

        i: int or None
            Indicate the view origin where zero is Plan and one is Work.
        """
        lost_q = []
        last_value = deepcopy(self._value)

        super(Cellular, self).set_a(d)

        for k in last_value:
            if k not in self._value:
                lost_q.append(k)
        if lost_q:
            self.emit(si.DISAPPEAR, lost_q)


class PerGroupCell(Cellular):
    """Manage Cell PerGroup."""

    def __init__(self, **d):
        self.dialog = PortPerCell
        Cellular.__init__(self, **d)


class PerGroupEmpty(PerGroup):
    """Is basically a dummy PerGroup."""

    def __init__(self, **d):
        PerGroup.__init__(self, **d)

        # never changes
        self.any_group.value_d[ok.PER] = {}

    @staticmethod
    def get_a():
        """
        There is no 'self._value'.

        Return: dict
            empty
        """
        return {}

    def intersect_vote(self, vote_d):
        return

    def set_a(self, *_, **q):
        """Set the PerGroup value."""
        return

    def set_view_value(self, i, _):
        self.view_value[i] = {}


class PerGroupFace(Cellular):
    """
    Manage Face PerGroup. It's value dict key is a Map key,
    (row, column, face), where each tuple item is a zero-based index.
    """

    def __init__(self, **d):
        self.dialog = PortPerFace
        Cellular.__init__(self, **d)

    def intersect_vote(self, vote_d):
        """
        Receive a vote dict and send a change Signal.

        vote_d: dict
            {cell index-type key: [Plan vote, Work vote]}
        """
        self.check_for_lost(self.any_group.item.model.face_q)

        group_vote_q = set()
        q = self._value.keys()

        # zero-based (row, column) index, 'k'
        # Plan and Work vote list, 'a'
        for k, a in vote_d.items():
            # Each Face in the cell has change.
            for face_i in range(3):
                k1 = k + (face_i,)
                if k1 in q:
                    # Plan and Work, '2'
                    for i in range(2):
                        d = {ok.IS_CHAIN: a[i]}

                        self.emit(
                            si.PER_CHANGE,
                            (k1, {vo.MATTER: d, vo.MODE: d, vo.OPACITY: d}, i)
                        )
                        group_vote_q.update((i,))
        for i in group_vote_q:
            self.any_group.cast_vote(i, ok.PER, vo.PER, True)

    def set_a(self, d, i=None):
        """
        Set the PerGroup value.

        d: dict
            {(row, column, face): Preset value dict}

        i: int or None
            Indicate the view origin where zero is Plan and one is Work.
        """
        super(PerGroupFace, self).set_a(d, i=i)

        # Repair.
        for k in self._value.keys():
            if len(k) == 2:
                self._value.pop(k)


class PerGroupFacing(PerGroupFace):
    """
    Manage Face PerGroup. It's value dict key is
    (row, column, 0), where each tuple item is a zero-based index.
    The zero in the key is deviant from the Cell branch because
    some Model dict are shared by both the Cell and Facing branches.
    """

    def __init__(self, **d):
        Cellular.__init__(self, **d)
        self.dialog = PortPerFacing

    def intersect_vote(self, vote_d):
        """
        Receive a vote dict and send a change Signal.

        vote_d: dict
            {cell index-type key: [Plan vote, Work vote]}
        """
        group_vote_q = set()
        q = self._value.keys()

        # zero-based (row, column) index, 'k'
        # Plan and Work vote list, 'a'
        for k, a in vote_d.items():
            # Add Facing index.
            k = k + (0,)
            if k in q:
                # Plan and Work, '2'
                for i in range(2):
                    d = {ok.IS_CHAIN: a[i]}

                    self.emit(
                        si.PER_CHANGE,
                        (k, {vo.MATTER: d, vo.MODE: d, vo.OPACITY: d}, i)
                    )
                    group_vote_q.update((i,))
        for i in group_vote_q:
            self.any_group.cast_vote(i, ok.PER, vo.PER, True)


class PerGroupMerge(WithWidget):
    """Table/Cell/Type's PerGroup for its merge option."""

    def __init__(self, **d):
        self.dialog = PortPerMerge
        WithWidget.__init__(self, **d)

    def compare_value(self, i):
        """
        Compare a value table with a Preview table.
        Route Table/Cell/Type differently.

        i: int
            index to Plan or Work attribute
        """
        d = self.get_a()
        is_change = compare_type(self, d, i)

        # Preset change
        self.any_group.cast_vote(i, ok.PER, vo.PER, is_change)

        # group change
        self.any_group.cast_vote(
            i, ok.IS_MAIN, vo.MATTER, d.keys() != self.view_value[i].keys()
        )

    def on_accept_cell_edit(self, d):
        """
        Return from PortPer. Exit from edit mode.

        d: dict
            the new value for the PerGroup
        """
        super(PerGroupMerge, self).on_accept_cell_edit(d)

        # When the Table/Cell/Type change,
        # the pocket and merge rect need update.
        self.any_group.item.model.baby.give(
            si.CELL_RECT_CHANGE, (self.any_group.value_d, False)
        )

    def on_cancel_cell_edit(self):
        """
        Return from PortPer. Exit from edit
        mode. Restore the 'cancel_value' table.
        """
        super(PerGroupMerge, self).on_cancel_cell_edit()

        # Merge cell may have been altered.
        self.any_group.item.model.baby.give(
            si.CELL_RECT_CHANGE, (self.any_group.value_d, False)
        )

    def on_per_switch(self, g):
        """
        Respond to a Per CheckButton changed event.

        g: CheckButton
            Is responsible.
        """
        if g.get_a() and not The.load_count:
            for r_c in self.any_group.item.model.cell_q:
                self._value[r_c] = 1, 1
        super(PerGroupMerge, self).on_per_switch(g)


# Register custom Signal.
gobject.type_register(PerGroup)
