#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from roller_a_contain import Cat, Deco, Run
from roller_constant_for import Deco as dc
from roller_constant_key import Option as ok
from roller_view_hub import brush_stroke

"""Define 'deco_paint' as having Model/Branch/Leaf paint function."""


def paint(z, d):
    """
    Paint Fringe/Type material onto a
    layer with a provided selection limitation.

    z: layer
        Receive paint.

    d: dict
        Fringe Preset
    """
    def _set_foreground_color():
        """
        Set the foreground color for the brush to use.
        Rotate through the multiple color option.
        """
        if is_multi_color:
            Deco.color_i = Deco.color_i + 1 \
                if Deco.color_i < max_i else 0
            pdb.gimp_context_set_foreground(
                color_q[Deco.color_i]
            )

    j = Run.j
    e = d[ok.RW1][ok.BRUSH_D]
    callback = None

    if d[ok.TYPE] == dc.MULTI_COLOR:
        Deco.color_i = 0
        is_multi_color = True
        color_q = d[ok.COLOR_6]
        max_i = d[ok.COLOR_COUNT] - 1
        callback = _set_foreground_color

    elif d[ok.TYPE] == dc.AS_IS:
        pdb.gimp_context_set_foreground(Cat.foreground)

    pdb.gimp_context_set_antialias(1)
    pdb.gimp_selection_shrink(j, int(d[ok.CONTRACT]))
    if not pdb.gimp_selection_is_empty(j):
        pdb.gimp_context_set_opacity(e[ok.OPACITY])
        pdb.plug_in_sel2path(j, z)
        if j.active_vectors:
            for stroke in j.active_vectors.strokes:
                brush_stroke(
                    z,
                    e[ok.BRUSH],
                    e[ok.BRUSH_SIZE],
                    stroke,
                    e[ok.BRUSH_SPACING],
                    e[ok.ANGLE_JITTER],
                    p=callback,
                    hard=e[ok.HARDNESS],
                    angle=e[ok.BRUSH_ANGLE]
                )

            # Remove, from the image, the path created by 'plug_in_sel2path'.
            pdb.gimp_image_remove_vectors(j, j.active_vectors)
