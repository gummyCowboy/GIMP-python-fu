#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_average_color import AverageColor
from roller_backdrop_image import BackdropImage
from roller_color_fill import ColorFill
from roller_colored_grid import ColoredGrid
from roller_core_design import CoreDesign
from roller_floor_sample import FloorSample
from roller_glass_gaw import GlassGaw
from roller_gradient_fill import GradientFill
from roller_image_gradient import ImageGradient
from roller_light_shaft import LightShaft
from roller_lost_maze import LostMaze
from roller_mystery_grate import MysteryGrate
from roller_pattern_fill import PatternFill
from roller_rainbow_valley import RainbowValley
from roller_spacetime_fabric import SpacetimeFabric
from roller_transparency import Transparency


class BackdropStyleNexus:
    """
    Create a collection of Backdrop Styles.

    Is the content of the Backdrop Styles menu and
    part of the mechanism for launching backdrop styles.
    """
    obj = (
            AverageColor,
            BackdropImage,
            ColorFill,
            ColoredGrid,
            CoreDesign,
            FloorSample,
            GlassGaw,
            GradientFill,
            ImageGradient,
            LightShaft,
            LostMaze,
            MysteryGrate,
            PatternFill,
            RainbowValley,
            SpacetimeFabric,
            Transparency
        )
    names = [i.name for i in obj]
