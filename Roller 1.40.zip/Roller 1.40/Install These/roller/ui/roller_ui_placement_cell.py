#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import (
        ForFormat,
        FormatKey
    )

from roller_combobox import RollerComboBox
from roller_layout import RollerImage
from roller_ui_cell import UICell


class UIPlacementCell(UICell):
    """Create the placement cell window."""

    def __init__(self, d):
        """d: dict"""
        UICell.__init__(self, d)

    def draw_cell(self, d):
        """
        Call for each cell.

        Draw the ComboBoxes for Image Placement.
        Is part of the UICell window template.

        d: cell dict
        """
        if self._is_picture(d):
            ff, fk = ForFormat, FormatKey
            p = self._on_widget_change
            g = [None] * 4

            for x in range(4):
                a = (
                        ff.RESIZE_OPTION,
                        RollerImage.image_list,
                        ff.HORIZONTAL_OPTION,
                        ff.VERTICAL_OPTION_LIST
                    )[x]

                g1 = g[x] = RollerComboBox(p, opt=a)
                g1.index = x
                g1.cell_table_key = fk.CELL_TABLE_PLACEMENT
                g1.r, g1.c = d['row'], d['column']

                self.table[d['row']][d['column']]['box'].add(g1.alignment)
                self.keep((g1,))

                # The image menu can default to "Next" without any
                #  notification. So it's check the menu's at close:
                if x == ff.IMAGE_INDEX:
                    self.placement_widget.append(g1)

            q = self.format[
                fk.CELL_TABLE_PLACEMENT][d['row']][d['column']]

            for x in range(4):
                g[x].resize_combobox, g[x].image_combobox, \
                    g[x].horizontal_combobox, g[x].vertical_combobox = \
                    g[0], g[1], g[2], g[3]
                g[x].set_value(q[x])
            if (
                        g1.resize_combobox.get_value() == ff.FILL_CELL or
                        g1.image_combobox.get_value() == ff.NONE
                    ):
                self.verify_place_menus(g[0])
