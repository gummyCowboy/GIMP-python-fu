#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_base import Base, OZ
from roller_constant import (
        ForCell,
        ForFormat,
        FormatKey,
        ForWidget,
        PresetKey,
        SessionKey,
        UICellKey,
        UIKey,
        WindowKey
    )

from roller_effect_nexus import EffectNexus
from roller_session import Format
from roller_group_per_cell import GroupPerCell
from roller_group_preset import GroupPreset
from roller_preset_format import PresetFormat
from roller_eventbox import REventBox
from roller_button import RollerButton
from roller_check_button import RollerCheckButton
from roller_combobox import RollerComboBox
from roller_entry import RollerEntry
from roller_label import RollerLabel
from roller_layout import RollerImage
from roller_navigation_list import NavigationList
from roller_spin_button import RollerSpinButton
from roller_ui import UI
from roller_ui_fixed_margin_cell import UIFixedMarginCell
from roller_ui_merge_cell import UIMergeCell
from roller_ui_percent_margin_cell import UIPercentMarginCell
from roller_ui_placement_cell import UIPlacementCell
from roller_ui_property_cell import UIPropertyCell
from roller_ui_switch import UISwitch
import gtk


class UIFormat(UISwitch):
    """
    This is a window with format controls and accesses UICell windows.
    """
    CELL_DICT = {
            FormatKey.CELL_TABLE_FIXED_MARGIN: UIFixedMarginCell,
            FormatKey.CELL_TABLE_MERGE: UIMergeCell,
            FormatKey.CELL_TABLE_PERCENT_MARGIN: UIPercentMarginCell,
            FormatKey.CELL_TABLE_PLACEMENT: UIPlacementCell,
            FormatKey.CELL_TABLE_PROPERTY: UIPropertyCell
        }

    GROUP_LABEL = (
            "Format Layer",
            "Layer Cell Grid",
            "Image Placement",
            "Image Property",
            "Layer Margins, Fixed-Value",
            "Layer Margins, Percentage-of-Layer ",
            "Cell Margins, Fixed-Value",
            "Cell Margins, Percentage-of-Cell"
        )

    def __init__(self, d):
        """
        d: dict
            UIFormat dict
        """
        self._start_format = d[UIKey.FORMAT_DICT]
        self._format = deepcopy(self._start_format)
        self._format_index = d[UIKey.FORMAT_INDEX]
        self._layout = d[UIKey.LAYOUT]
        d[UIKey.ON_RETURN] = self.do_job
        d[UIKey.WINDOW_TITLE] = "Format"
        d[UIKey.WINDOW_KEY] = WindowKey.FORMAT
        self.group_box = []
        self.switch_group_box = self.group_visibility = None
        UISwitch.__init__(self, d)

    def _adjust_cell_tables(self):
        """
        Cell tables expand or contract depending on the rows and columns.
        """
        self._expand_cell_tables()
        self._contract_cell_tables()

    def _contract_cell_tables(self):
        """
        Contract Per Cell tables to correspond with the Format dict.

        Checks Merge Cells table for group dimension overflow.
        """
        row = self._format[FormatKey.ROW]
        col = self._format[FormatKey.COLUMN]

        for k in ForCell.CELL_TABLE_DICT:
            if self._format[k]:
                r = len(self._format[k])

                if r > row:
                    # Remove rows:
                    for _ in range(r - row):
                        self._format[k].pop()
                for r in range(len(self._format[k])):
                    c = len(self._format[k][r])
                    if c > col:
                        # Remove columns:
                        for _ in range(c - col):
                            self._format[k][r].pop()
        self._fix_merge_cells()

    def _correct_contracted_cells(self):
        """
        When cells contract, their dimensions change.
        This makes the cut-off cells independent.
        """
        if self._format[FormatKey.MERGE_PER_CELL]:
            r = self._format[FormatKey.ROW]
            r1 = len(self._format[FormatKey.CELL_TABLE_MERGE])
            c = self._format[FormatKey.COLUMN]
            for r2 in range(r1):
                for c1 in range(
                        len(self._format[FormatKey.CELL_TABLE_MERGE][r2])):
                    if r2 >= r or c1 >= c:
                        self._format[FormatKey.CELL_TABLE_MERGE][r2][c1] = 1, 1

    def _correct_merge_overflow(self, s, row, col, r, c):
        """
        Check if the Merge Cells' table has contracted. If so then
        the top-left cells need their dimensions checked for overflow.

        row, col: max location.
        r, c: current location
        s: group dimension
        """
        if s[0] + r > row:
            s = row - r, s[1]

        if s[1] + c > col:
            s = s[0], col - c
        return s

    def _draw_cell_margin_fixed_group(self, g):
        """
        Draw the fixed-value cell margins group.

        g: container
        """
        g1 = self.fixed_cell_margin_sb = list(
            self._draw_margin_group(
                    g,
                    ForFormat.CELL_MARGIN_FIXED_SPIN_BUTTON_KEY,
                    has_per_cell=True
                ))

        g = self.fixed_margin_pc_group = GroupPerCell(
                self.on_widget_change,
                self._open_cell_window,
                "Fixed-Value Cell Margins...",
                FormatKey.FIXED_MARGIN_PER_CELL,
                g,
                FormatKey.CELL_TABLE_FIXED_MARGIN,
            )

        g.wig.connect('clicked', self._set_fixed_margin_dependent)
        self.keep((g1,))

    def _draw_cell_margin_percent_group(self, g):
        """
        Draw the percentage-of-cell cell margins group.

        g: container
        """
        g1 = self.percent_cell_margin_sb = list(
            self._draw_margin_group(
                    g,
                    ForFormat.CELL_MARGIN_PERCENT_SPIN_BUTTON_KEY,
                    is_percent=1,
                    has_per_cell=True
                ),
            )

        g = self.percent_margin_pc_group = GroupPerCell(
                self.on_widget_change,
                self._open_cell_window,
                "Percentage-of-Cell Cell Margins...",
                FormatKey.PERCENT_MARGIN_PER_CELL,
                g,
                FormatKey.CELL_TABLE_PERCENT_MARGIN
            )

        g.wig.connect('clicked', self._set_percent_margin_dependent)
        self.keep((g1,))

    def _draw_grid_group(self, g):
        """
        Draw the grid group.

        g: container
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        a = 1, 100
        p = self.on_widget_change
        g1 = []

        g1.append(RollerLabel("Row:", padding=(0, 0, w, w)))
        g1.append(RollerSpinButton(
                p,
                a,
                key=FormatKey.ROW,
                padding=(0, w1, w, w)
            ))

        self.row_sb = g1[-1]

        g1.append(RollerLabel("Column:", padding=(w1, 0, w, w)))
        g1.append(RollerSpinButton(
                p,
                a,
                key=FormatKey.COLUMN,
                padding=(0, w1, w, w)
            ))

        self.col_sb = g1[-1]

        self.keep(g1)

        for i in g1:
            g.pack_start(i.alignment, expand=False)

        self.merge_pc_group = GroupPerCell(
                p,
                self._open_cell_window,
                "Merge Cells...",
                FormatKey.MERGE_PER_CELL,
                g,
                FormatKey.CELL_TABLE_MERGE
            )

    def _draw_layer_group(self, g):
        """
        Draw a format layer group.

        g: container
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        p = self.on_widget_change
        g1 = []
        g2 = []
        g1.append(RollerLabel("Format Name:", padding=(0, 0, w, w)))
        g2.append(RollerEntry(
                p,
                FormatKey.NAME,
                padding=(0, w1, w, w)
            ))
        g1.append(RollerLabel("3D Effect:", padding=(w1, 0, w, w)))
        g2.append(RollerComboBox(
                p,
                key=FormatKey.EFFECT,
                opt=[ForFormat.NONE] + EffectNexus.names,
                padding=(0, w1, w, w)
            ))

        g2.append(RollerCheckButton(
                FormatKey.SHOW_IN_LAYOUT,
                p,
                FormatKey.SHOW_IN_LAYOUT,
                padding=(w1, w, w, w)
            ))

        self.format_name_e, self.effect_m, self.show_in_layout_cb = g2

        self.keep(g2)

        for x, i in enumerate(g1):
            g.pack_start(i.alignment, expand=False)
            g.pack_start(g2[x].alignment, expand=False)
        g.pack_start(g2[-1].alignment, expand=False)

    def _draw_layer_margin_fixed_group(self, g):
        """
        Draw the layer fixed-value margins.

        g: container
        """
        self.layer_margin_fixed_sb = list(
            self._draw_margin_group(
                    g,
                    ForFormat.LAYER_MARGIN_FIXED_SPIN_BUTTON_KEY
                ))

    def _draw_layer_margin_percent_group(self, g):
        """
        Draw the layer percentage-value margins.

        g: container
        """
        self.layer_margin_percent_sb = list(
            self._draw_margin_group(
                    g,
                    ForFormat.LAYER_MARGIN_PERCENT_SPIN_BUTTON_KEY,
                    is_percent=1
            ))

    def _draw_margin_group(self, g, k, is_percent=0, has_per_cell=False):
        """
        Draw the margin SpinButtons.

        g: GTK container
        k: string
            group key

        is_percent: int, flag
            If true, the SpinButton range is (0..1).

        has_per_cell: flag
            If true, the margins are part of per cell group.

        Return the top, bottom, left, right SpinButton widgets.
        """
        ff = ForFormat
        w = ForWidget.MARGIN
        w1 = w / 2
        w2 = w1 if has_per_cell else w
        a = (0., 1.) if is_percent else (0, 100000)
        p = self.on_widget_change
        sb = RollerSpinButton
        g1 = []

        if is_percent:
            step = .01, .1
            type_index = ForWidget.FLOAT_INDEX

        else:
            step = 1, 1
            type_index = ForWidget.INT_INDEX

        g1.append(RollerLabel("Top:", padding=(w, 0, w, w)))
        g1.append(sb(
                p,
                a,
                key=k[ff.TOP_INDEX],
                label=g1[-1].alignment,
                type_index=type_index,
                padding=(0, w1, w, w),
                step=step,
                precision=6
            ))

        g1.append(RollerLabel("Bottom: ", padding=(w1, 0, w, w)))
        g1.append(sb(
                p,
                a,
                key=k[ff.BOTTOM_INDEX],
                label=g1[-1].alignment,
                type_index=type_index,
                padding=(0, w1, w, w),
                step=step,
                precision=6
            ))

        g1.append(RollerLabel("Left:", padding=(w1, 0, w, w)))
        g1.append(sb(
                p,
                a,
                key=k[ff.LEFT_INDEX],
                label=g1[-1].alignment,
                type_index=type_index,
                padding=(0, w1, w, w),
                step=step,
                precision=6
            ))

        g1.append(RollerLabel("Right:", padding=(w1, 0, w, w)))
        g1.append(sb(
                p,
                a,
                key=k[ff.RIGHT_INDEX],
                label=g1[-1].alignment,
                type_index=type_index,
                padding=(0, w2, w, w),
                step=step,
                precision=6
            ))

        self.keep(g1)

        for i in g1:
            g.pack_start(i.alignment, expand=False)
        return g1[1], g1[3], g1[5], g1[7]

    def _draw_multiple_groups(self, g):
        """
        Draw the format groups.
        Hide the groups that aren't selected.

        g: gtk container
            group box
        """
        q = (
                self._draw_layer_group,
                self._draw_grid_group,
                self._draw_placement_group,
                self._draw_property_group,
                self._draw_layer_margin_fixed_group,
                self._draw_layer_margin_percent_group,
                self._draw_cell_margin_fixed_group,
                self._draw_cell_margin_percent_group
            )

        self.group_visibility = [0] * (len(q) + 1)
        self.switch_group_box = g
        for x, p in enumerate(q):
            g = gtk.VBox()
            self.group_box.append(g)
            g.add(RollerLabel(
                UIFormat.GROUP_LABEL[x] + ":",
                padding=(2, 0, 4, 0)).alignment)
            p(g)

    def _draw_navigation_group(self, g):
        """
        """
        g1 = NavigationList(g, self)
        g1.set_value(UIFormat.GROUP_LABEL)

    def _draw_placement_group(self, g):
        """
        Draw the Placement ComboBoxes.

        g: container
        """
        ff = ForFormat
        w = ForWidget.MARGIN
        rcb = RollerComboBox
        w1 = w / 2
        p = self.on_widget_change
        g1 = []
        g2 = []

        g1.append(rcb(
                p,
                key=FormatKey.RESIZE,
                opt=ff.RESIZE_OPTION,
                padding=(0, w1, w, w)
            ))

        g1.append(rcb(
                p,
                key=FormatKey.IMAGE,
                opt=RollerImage.image_list[:],
                padding=(0, w1, w, w)
            ))

        g1.append(rcb(
                p,
                key=FormatKey.HORIZONTAL,
                opt=ff.HORIZONTAL_OPTION,
                padding=(0, w1, w, w)
            ))

        g1.append(rcb(
                p,
                key=FormatKey.VERTICAL,
                opt=ff.VERTICAL_OPTION_LIST,
                padding=(0, w1, w, w)
            ))

        self.resize_m, self.image_menu, self.horz_m, self.vert_m = g1

        # Connect dependents:
        for i in g1:
            i.resize_combobox, i.image_combobox, \
                i.horizontal_combobox, i.vertical_combobox = g1

        self.keep(g1)
        g2.append(RollerLabel("Resize:", padding=(w1, 0, w, w)))
        g2.append(RollerLabel("Image:", padding=(w1, 0, w, w)))
        g2.append(RollerLabel("Horizontal:", padding=(w1, 0, w, w)))
        g2.append(RollerLabel("Vertical:", padding=(w1, 0, w, w)))

        for x, i in enumerate(g1):
            g.pack_start(g2[x].alignment, expand=False)
            g.pack_start(i.alignment, expand=False)

        g = self.placement_pc_group = GroupPerCell(
                p,
                self._open_cell_window,
                "Placement...",
                FormatKey.PLACEMENT_PER_CELL,
                g,
                FormatKey.CELL_TABLE_PLACEMENT
            )
        g.wig.connect('clicked', self._set_placement_dependent)

    def _draw_preset_group(self, g):
        """
        Draw the Preset ComboBox and Buttons.

        g: container
        """
        self.preset_menu = GroupPreset(
                g,
                self.on_preset_change,
                SessionKey.FORMAT_LIST,
                self.return_format,
                self.win,
                self.preset,
                self.stat
            )

    def _draw_process_group(self, g):
        """
        Draw the Show Layout, Cancel, and Accept Buttons.

        g: container
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        g1 = []

        g1.append(RollerButton(
                "Cancel",
                self.do_no,
                padding=(w1, 0, w, w)
            ))

        g1.append(RollerButton(
                "Show Layout",
                self._show_layout,
                padding=(0, 0, w, w)
            ))

        g1.append(RollerButton(
                "Accept",
                self.do_job,
                padding=(0, w, w, w)
            ))

        self.keep(g1)
        for i in g1:
            g.pack_start(i.alignment, expand=False)

    def _draw_property_group(self, g):
        """
        Draw the property group.

        g: container
        """
        fk = FormatKey
        rsb = RollerSpinButton
        w = ForWidget.MARGIN
        w1 = w / 2
        p = self.on_widget_change
        g1 = []
        g2 = []
        g3 = []
        g4 = []

        g1.append(RollerLabel("Rotate:", padding=(w1, 0, w, w)))
        g1.append(RollerLabel("Opacity:", padding=(w1, 0, w, w)))
        g1.append(RollerLabel("Blur Behind:  ", padding=(w1, 0, w, w)))
        g2.append(RollerCheckButton(
                "Flip Horizontal",
                p,
                fk.FLIP_HORIZONTAL,
                padding=(w1, w1, w, w)
            ))

        g2.append(RollerCheckButton(
                "Flip Vertical",
                p,
                key=fk.FLIP_VERTICAL,
                padding=(0, w1, w, w)
            ))

        g3.append(rsb(
                p,
                (-359, 359),
                key=fk.ROTATE,
                label=g1[0].alignment,
                padding=(0, w1, w, w)
            ))

        g4 = g2 + g3
        g3.append(rsb(
                p,
                (0, 100),
                key=fk.OPACITY,
                label=g1[1].alignment,
                padding=(0, w1, w, w)
            ))

        g5 = g3[-1]

        g3.append(rsb(
                p,
                (0, 200),
                key=fk.BLUR_BEHIND,
                label=g1[2].alignment,
                padding=(0, w1, w, w)
            ))

        g4.append(g3[-1])
        g5.flip_h, g5.flip_v, g5.rot, g5.blur = g4

        g4 = g2 + g3
        self.flip_h_cb, self.flip_v_cb, self.rotate_sb, self.opacity_sb, \
            self.blur_sb = g4

        self.keep(g4)

        for i in g2:
            g.pack_start(i.alignment, expand=False)

        for x, i in enumerate(g1):
            g.pack_start(i.alignment, expand=False)
            g.pack_start(g3[x].alignment, expand=False)

        g = self.property_pc_group = GroupPerCell(
                p,
                self._open_cell_window,
                "Property...",
                fk.PROPERTY_PER_CELL,
                g,
                FormatKey.CELL_TABLE_PROPERTY
            )
        g.wig.connect('clicked', self._set_property_dependent)

    def _expand_cell_table(self, p):
        """
        Expand a cell table based on the row and column counts.

        During an expansion, values are inserted into
        a table from the Format window settings.
        These settings are placed in the "cell" variable.

        Each Per Cell group has its own cell type.

        p: a process that returns a cell value
            and the cell table index for the format
        """
        d = self._format
        cell, x = p()
        row, col = d[FormatKey.ROW], d[FormatKey.COLUMN]

        if not d[x]:
            d[x] = Base.create_2d_table(row, col, a=cell)

        else:
            r = len(d[x])

            if r < row:
                e = []

                for _ in range(col):
                    e.append(cell)
                for r1 in range(row - r):
                    # Add a row with a new list:
                    d[x].append(e[:])
            for r1 in range(row):
                c = len(d[x][r1])
                if c < col:
                    for _ in range(col - c):
                        # Add a column:
                        d[x][r1].append(cell)

    def _expand_cell_tables(self):
        """
        The Per Cell tables need updating because the number
        of rows and/or columns may have increased value.
        """
        for x, p in enumerate([
                    self._init_merge_table,
                    self._init_placement_table,
                    self._init_fixed_margin_table,
                    self._init_percent_margin_table,
                    self._init_property_table
                ]):
            if self.pc_group[x].get_value():
                self._expand_cell_table(p)

    def _fix_merge_cells(self):
        """
        Correct overflow references by reducing
        merged group dimensions in the top-left cells.
        """
        d = self._format
        row, col = d[FormatKey.ROW], d[FormatKey.COLUMN]

        if d[FormatKey.MERGE_PER_CELL]:
            for r in range(row):
                for c in range(col):
                    if r < len(d[FormatKey.CELL_TABLE_MERGE]):
                        if c < len(d[FormatKey.CELL_TABLE_MERGE][r]):
                            d[FormatKey.CELL_TABLE_MERGE][r][c] = \
                                self._correct_merge_overflow(
                                        d[FormatKey.CELL_TABLE_MERGE][r][c],
                                        row,
                                        col,
                                        r, c
                                    )
        self._correct_contracted_cells()

    def _init_fixed_margin_table(self):
        """
        This routine is called by "_expand_cell_table".

        Return the image margins cell table init value and the cell table key.
        """
        q = []

        for k in ForFormat.CELL_MARGIN_FIXED_SPIN_BUTTON_KEY:
            q.append(self._format[k])
        return tuple(q), FormatKey.CELL_TABLE_FIXED_MARGIN

    def _init_merge_table(self):
        """
        This routine is called by "_expand_cell_table".

        Return the merge cell table init value and the cell table key.
        """
        return (1, 1), FormatKey.CELL_TABLE_MERGE

    def _init_percent_margin_table(self):
        """
        This routine is called by "_expand_cell_table".

        Return the image margins cell table init value and the cell table key.
        """
        q = []

        for k in ForFormat.CELL_MARGIN_PERCENT_SPIN_BUTTON_KEY:
            q.append(self._format[k])
        return tuple(q), FormatKey.CELL_TABLE_PERCENT_MARGIN

    def _init_placement_table(self):
        """
        This routine is called by "_expand_cell_table".

        Return the image placement cell table
        init value and the cell table key.
        """
        fk = FormatKey
        d = self._format
        return (
                d[fk.RESIZE],
                d[fk.IMAGE],
                d[fk.HORIZONTAL],
                d[fk.VERTICAL]
            ), fk.CELL_TABLE_PLACEMENT

    def _init_property_table(self):
        """
        This routine is called by "_expand_cell_table".

        Return the property table init value and the cell table key.
        """
        fk = FormatKey
        q = []

        for k in (
                    fk.FLIP_HORIZONTAL,
                    fk.FLIP_VERTICAL,
                    fk.ROTATE,
                    fk.OPACITY,
                    fk.BLUR_BEHIND
                ):
            q.append(self._format[k])
        return tuple(q), fk.CELL_TABLE_PROPERTY

    def _open_cell_window(self, cell_table_key):
        """
        Open a Per Cell window.

        window_key: string
            window key used to access "ForCell.CELL_TABLE_DICT"
            and to distinguish the cell window variant.
        """
        self._adjust_cell_tables()
        d = deepcopy(self._format)

        cell_window = UIFormat.CELL_DICT[cell_table_key]
        cell_window({
                UICellKey.CELL_TABLE_KEY: cell_table_key,
                UIKey.FORMAT_DICT: d,
                UICellKey.MERGE_PER_CELL: self.merge_pc_group.get_value(),
                UIKey.LAYOUT: self._layout,
                UIKey.PARENT: self.win,
                UIKey.STAT: self.stat
            })
        if d != self._format:
            self._format = d

    def _set_fixed_margin_dependent(self, *_):
        """Set fixed-value cell margin dependents."""
        m = self.fixed_margin_pc_group.get_value()
        for g in self.fixed_cell_margin_sb:
            g.disable() if m else g.enable()

    def _set_percent_margin_dependent(self, *_):
        """Set percentage-of-cell cell margin dependents."""
        m = self.percent_margin_pc_group.get_value()
        for g in self.percent_cell_margin_sb:
            g.disable() if m else g.enable()

    def _set_placement_dependent(self, *_):
        """Set placement dependents."""
        m = self.placement_pc_group.get_value()

        if m:
            for g in (
                    self.resize_m, self.horz_m, self.vert_m, self.image_menu):
                g.disable()

        else:
            self.image_menu.enable()
            self.verify_place_menus(self.resize_m)

    def _set_property_dependent(self, *_):
        """Set image dependents."""
        m = self.property_pc_group.get_value()

        if m:
            for g in (
                        self.rotate_sb, self.opacity_sb,
                        self.flip_h_cb, self.flip_v_cb, self.blur_sb
                    ):
                g.disable()

        else:
            self.opacity_sb.enable()
            self.verify_opacity_depend(self.opacity_sb)

    def _show_layout(self, *_):
        """Show a layout sketch-up."""
        self._adjust_cell_tables()

        # Swap the UIMain dict with the work-in-progress dict:
        q = self.stat.session[SessionKey.FORMAT_LIST]
        d = deepcopy(q[self._format_index])
        q[self._format_index] = self._format

        self._layout.show()

        # Restore the UIMain dict:
        q[self._format_index] = d

    def _verify_per_cell_buttons(self):
        """Verify Per Cell dependency."""
        for p in (
                    self._set_placement_dependent,
                    self._set_fixed_margin_dependent,
                    self._set_percent_margin_dependent,
                    self._set_property_dependent
                ):
            p()

    def do_no(self, *_):
        """Cancel the Format window."""
        return self.close()

    def do_job(self, *_):
        """Accept the UIFormat window."""
        for g in self.controls:
            self._format[g.key] = g.get_value()

        # Over-ride default behavior:
        if self.preset_menu.get_text() == ForWidget.UNDEFINED:
            self._format[FormatKey.PRESET] = ForWidget.UNDEFINED

        self._adjust_cell_tables()

        self.stat.session[SessionKey.FORMAT_LIST][self._format_index] = \
            self._format

        # Update the original dict to let
        # UIMain know that the dict was changed:
        self._start_format.update(self._format)

        # Exit:
        return self.close()

    def draw_window(self):
        """
        Draw the window's widgets.

        Is part of the UI window template.
        """
        self.preset = PresetFormat({
                PresetKey.FOLDER: self.stat.preset_folder,
                PresetKey.PARENT: self.win
            })

        g = self.win.vbox
        q = (
                self._draw_navigation_group,
                self._draw_multiple_groups,
                self._draw_preset_group,
                self._draw_process_group
            )

        group_name = (
                "Navigation",
                "",
                "Format Preset",
                "Process"
            )

        for i, p in enumerate(q):
            if not i % 2:
                same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

            box = REventBox(self.color)
            g1 = gtk.VBox()

            if group_name[i]:
                g1.add(RollerLabel(
                    group_name[i] + ":", padding=(2, 0, 4, 0)).alignment)

            box.add(g1)
            p(g1)
            same_size.add_widget(box)
            self.reduce_color()

            # Keep the widgets in memory:
            wig = same_size.get_widgets()
            if i % 2:
                # Add row of same size widgets:
                g2 = gtk.HBox()

                [g2.add(g3) for g3 in reversed(wig)]
                g.add(g2)

        self.pc_group = (
                self.merge_pc_group,
                self.placement_pc_group,
                self.fixed_margin_pc_group,
                self.percent_margin_pc_group,
                self.property_pc_group
            )

        q = self.controls = [
                self.format_name_e,
                self.effect_m,
                self.show_in_layout_cb,
                self.resize_m,
                self.horz_m,
                self.vert_m,
                self.image_menu,
                self.rotate_sb,
                self.opacity_sb,
                self.flip_h_cb,
                self.flip_v_cb,
                self.blur_sb,
                self.property_pc_group,
                self.placement_pc_group,
                self.merge_pc_group,
                self.fixed_margin_pc_group,
                self.percent_margin_pc_group,
                self.row_sb,
                self.col_sb,
                self.preset_menu
            ]

        q += [i for i in self.layer_margin_fixed_sb]
        q += [i for i in self.layer_margin_percent_sb]
        q += [i for i in self.fixed_cell_margin_sb]
        q += [i for i in self.percent_cell_margin_sb]

        self.update_controls(self._format)
        self.verify_opacity_depend(self.opacity_sb, self.property_pc_group)
        self._verify_per_cell_buttons()

    def on_preset_change(self, _, d):
        """
        Load the preset on menu change.

        d: dict
            preset dict or None
        """
        n = self.preset_menu.get_text()
        if n != ForWidget.UNDEFINED:
            OZ.pass_version(d, Format.default, is_format=1)
            self._format = self.load_controls(d)
            self._verify_per_cell_buttons()

    def on_widget_change(self, g):
        """
        A widget changed.

        g: widget
        """
        fk = FormatKey

        if not UI.loading:
            self._format[g.key] = g.get_value()

            if g.key in (
                    fk.RESIZE,
                    fk.HORIZONTAL,
                    fk.VERTICAL,
                    fk.IMAGE
                    ):
                self.verify_place_menus(g)

            elif g.key in (
                    fk.PLACEMENT_PER_CELL,
                    fk.FIXED_MARGIN_PER_CELL,
                    fk.PERCENT_MARGIN_PER_CELL,
                    fk.PROPERTY_PER_CELL) \
                    or g.key == fk.MERGE_PER_CELL:

                # Reset cell data:
                self._format[g.cell_table_key] = None
                self._verify_per_cell_buttons()

            elif g.key == fk.OPACITY:
                self.verify_opacity_depend(g)
            self.preset_is_undefined()
        if g.key == fk.IMAGE:
            n = g.get_value()
            n = n if len(n) > 10 else ""
            g.alignment.set_tooltip_text(n)

    def return_format(self):
        """Use with GroupPreset to save presets."""
        return self._format
