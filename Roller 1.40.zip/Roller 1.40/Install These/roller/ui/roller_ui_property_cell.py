#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import (
        ForFormat,
        FormatKey,
    )

from roller_check_button import RollerCheckButton
from roller_label import RollerLabel
from roller_spin_button import RollerSpinButton
from roller_splitter import Splitter
from roller_ui_cell import UICell


class UIPropertyCell(UICell):
    """Create the property cell window."""

    def __init__(self, d):
        """d: dict"""
        UICell.__init__(self, d)

    def draw_cell(self, d):
        """
        Call for each cell.

        Draw the widgets for the Property cell.
        Is part of the UICell window template.

        d: dict
            cell dictionary
        """
        if self._is_picture(d):
            g = self.table[d['row']][d['column']]['box']
            p = self._on_widget_change
            q = zip(
                (
                    RollerCheckButton, RollerCheckButton, RollerSpinButton,
                    RollerSpinButton, RollerSpinButton
                ),
                (
                    ("Flip Horizontal", p),
                    ("Flip Vertical", p),
                    (p, (-359, 359)),
                    (p, (0, 100)), (p, (0, 200))
                ),
                (
                    ForFormat.FLIP_HORIZONTAL_INDEX,
                    ForFormat.FLIP_VERTICAL_INDEX,
                    ForFormat.ROTATE_INDEX,
                    ForFormat.OPACITY_INDEX,
                    ForFormat.BLUR_BEHIND_INDEX)
                )

            wigs = []
            for x, q1 in enumerate(q):
                g1, c, x1 = q1

                if x < 2:
                    g2 = g1(*c)

                else:
                    label = RollerLabel((
                            "Rotate:",
                            "Opacity:",
                            "Blur Behind:"
                        )[x - 2]).alignment
                    g2 = g1(*c, label=label)

                g2.index = x1
                g2.r, g2.c = d['row'], d['column']
                g2.cell_table_key = FormatKey.CELL_TABLE_PROPERTY

                wigs.append(g2)
                self.keep((g2,))

                if x1 == ForFormat.OPACITY_INDEX:
                    op_sb = g2

                if x < 2:
                    # CheckButton:
                    g.add(g2.alignment)

                else:
                    g3 = Splitter()
                    g3.both(label, g2.alignment)
                    g3.pack()
                    g.add(g3.container)

            # opacity dependents:
            op_sb.flip_h, op_sb.flip_v, op_sb.rot, op_sb.blur \
                = wigs[:3] + wigs[4:]

            q = self.format[FormatKey.CELL_TABLE_PROPERTY][
                d['row']][d['column']]

            for x in range(5):
                wigs[x].set_value(q[x])
            if not q[ForFormat.OPACITY_INDEX]:
                self.verify_opacity_depend(wigs[3])
