#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_widget import Widget
import gtk


class RollerCheckButton(Widget):
    """
    This is a custom GTK CheckButton.

    Is attached to its own Alignment.
    """

    def __init__(self, text, on_action, key=None, padding=None):
        """
        Create CheckButton and Alignment.

        text: string
            label text

        on_action: function
            Call on check button action.

        key: string
            widget key

        padding: tuple of int
            Alignment padding (top, bottom, left, right)
        """
        g = self.alignment = gtk.Alignment(0, 0, 0, 0)
        g1 = gtk.CheckButton(label=text)

        Widget.__init__(self, on_action, key=key, widget=g1)
        g.add(g1)
        g1.connect('clicked', self.callback)
        g1.connect('activate', self.callback)
        if padding:
            g.set_padding(*padding)

    def get_value(self):
        """
        Return the value of the CheckButton.

        Is part of a UI widget template.
        """
        return int(self.wig.get_active())

    def set_value(self, a):
        """
        Set the CheckButton checked state.

        Is part of a UI widget template.

        a: int
        """
        self.wig.set_active(a)
