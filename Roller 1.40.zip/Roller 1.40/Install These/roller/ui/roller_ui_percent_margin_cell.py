#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import (
        ForFormat,
        ForWidget
    )

from roller_ui_cell import UICell


class UIPercentMarginCell(UICell):
    """Create the percentage-of-cell margin cell window."""

    def __init__(self, d):
        """d: dict"""
        UICell.__init__(self, d)

    def draw_cell(self, d):
        """
        Call for each cell.

        Draw margin Labels and SpinButtons.
        Is part of the UICell window template.

        d: dict
            cell dict
        """
        self.draw_margin_cell(
                d,
                ForFormat.CELL_MARGIN_PERCENT_SPIN_BUTTON_KEY,
                (1., 1., 1., 1.),
                step=(.01, .1),
                type_index=ForWidget.FLOAT_INDEX
            )
