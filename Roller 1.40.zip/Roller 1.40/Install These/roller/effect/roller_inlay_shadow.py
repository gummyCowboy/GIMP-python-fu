#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import SessionKey
from roller_shadow import Shadow


class InlayShadow(Shadow):
    """Create a sunken image effect on an image layer."""
    name = SessionKey.INLAY_SHADOW

    def __init__(self, _, stat):
        """stat: Stat"""
        Shadow.__init__(self, SessionKey.INLAY_SHADOW, stat, inlay=1)
