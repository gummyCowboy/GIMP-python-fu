#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_base import OZ
from roller_constant import ForPreset, PickleKey, PresetKey


class Preset:
    """
    Presets are used to store session and format values.

    External presets are created by the user and given a name.
    """

    def __init__(self, d):
        """d: preset dict"""
        pk = PresetKey
        self.default_preset = deepcopy(d[pk.DEFAULT])
        self.internal_presets = d[pk.INTERNAL]
        self.parent = d[pk.PARENT]
        self.name = d[pk.NAME]
        self.folder = d[pk.FOLDER]

    def get_preset(self, n, presets):
        """
        Return a preset from internal and external sources.

        n: name of preset
        presets: preset list
        """
        fp = ForPreset
        d = deepcopy(self.default_preset)

        for q in presets:
            if n == q[fp.NAME_INDEX]:
                if q[fp.SOURCE_INDEX] == fp.EXTERNAL_TYPE:
                    e = OZ.pickle_load({
                            PickleKey.FILE: q[fp.FILE_INDEX],
                            PickleKey.SHOW_ERROR: True
                        })

                    if e:
                        d = e

                        # The preset name must match the file name:
                        d[PresetKey.PRESET] = n
                    break

                else:
                    # Load internal data:
                    d = q[fp.DATA_INDEX]
                break
        return d

    def is_internal(self, n, presets):
        """
        Return true if the preset is an internal-type.

        n: preset name
        """
        for q in presets:
            if n == q[ForPreset.NAME_INDEX]:
                if q[ForPreset.SOURCE_INDEX] == ForPreset.INTERNAL_TYPE:
                    return 1
