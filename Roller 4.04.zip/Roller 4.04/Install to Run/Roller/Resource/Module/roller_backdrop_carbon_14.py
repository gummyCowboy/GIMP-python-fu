#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_view_real import (
    add_sub_base_group, add_wip_layer, finish_style, insert_copy_above
)
from roller_view_hub import make_polar_mask
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make the Backdrop Style.

    v: View
        Has scope variable.

    maya: Style
    Return: layer or None
        with Carbon 14
    """
    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya)
    azimuth = v.glow_ball.azimuth
    size = d[ok.MESH_SIZE]
    z = plasma_layer = add_wip_layer(v, maya, "Plasma")
    group = Lay.group(j, "WIP", parent=parent, z=z)

    # medium-ish turbulence, '3.'
    pdb.plug_in_plasma(j, z, d[ok.SEED], 3.)

    # Create alternate textures for light and dark.
    z = lights = make_polar_mask(z)
    z = dark = make_polar_mask(z, is_dark=True)

    Gegl.saturation(z, .1)

    z = Lay.clone(lights, n="Darken Only")
    z.mode = fu.LAYER_MODE_LUMA_DARKEN_ONLY

    # elevation, '30'; depth, '1'; bump, '1'
    pdb.plug_in_emboss(j, z, azimuth, 30, 1, 1)

    z = Lay.clone(dark, n="HSV Value")
    z.mode = fu.LAYER_MODE_HSV_VALUE

    Lay.blur(z, size * 2)

    z = insert_copy_above(v, z, group.layers[0])
    z.mode = fu.LAYER_MODE_LUMA_LIGHTEN_ONLY
    z = z1 = Lay.clone(plasma_layer, n="Mosaic")

    Sel.rect(v.j, *v.wip.rect)
    pdb.gimp_image_reorder_item(j, z, group, 2)
    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    pdb.plug_in_colortoalpha(j, z, (0, 0, 255))
    pdb.plug_in_colortoalpha(j, z, (0, 255, 0))
    pdb.plug_in_colortoalpha(j, z, (255, 0, 0))
    pdb.plug_in_mosaic(
        j, z,
        size,
        4.,                                 # tile height
        1.,                                 # tile spacing
        d[ok.NEATNESS],
        0,                                  # no split
        azimuth,
        .0,                                 # minimum color variation
        1,                                  # yes, antialias
        1,                                  # yes, color averaging
        bs.MESH_TYPE.index(d[ok.MESH_TYPE]),
        0,                                  # smooth surface
        0                                   # black and white grout
    )

    z.mode = fu.LAYER_MODE_COLOR_ERASE
    z = plasma_layer

    Gegl.saturation(z, .0)
    Lay.blur(z, size)

    z = insert_copy_above(v, z1, group.layers[0])
    z.mode = fu.LAYER_MODE_HSL_COLOR

    pdb.gimp_drawable_invert(z, 0)
    pdb.gimp_image_remove_layer(j, z1)

    z = Lay.merge_group(group)
    z2 = make_polar_mask(z)

    Gegl.saturation(z2, .3)
    Gegl.saturation(z, .3)

    z = pdb.gimp_image_merge_down(j, z2, fu.CLIP_TO_IMAGE)
    z = Lay.clone(z, n="LCH Lightness")

    Gegl.edge(z)

    z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
    z = Lay.merge(z)
    z = make_polar_mask(z, is_dark=False)

    pdb.plug_in_unsharp_mask(
        j, z,
        12.,                                # radius
        1.5,                                # amount
        .0                                  # threshold
    )
    return finish_style(Lay.merge_group(parent), "Carbon 14")


class Carbon14(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
