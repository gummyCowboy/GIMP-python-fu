#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Mask as ms, Shape as sh, Triangle as ft
from roller_constant_key import Option as ok
from roller_one import Rect
from roller_one_extract import ROUTE, Shape
from roller_one_fu import Lay, Mage, Sel
from roller_one_the import The
import gimpfu as fu
import math

RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP
X_IS_0 = Y_IS_0 = NO_ANTIALIAS = 0
YES_AUTO_CENTER = True
pdb = fu.pdb


def calc_scaled_rect(v):
    """
    Calculate the scaled rectangle for a mask shape.

    v: View
    Return: tuple
        the scaled rectangle
        (x, y, w, h)
    """
    w, h = v.mask.scale_w, v.mask.scale_h
    return v.mask.center_x - w / 2., v.mask.center_y - h / 2., w, h


def do_circle(j, v, maya):
    """
    Make a circle selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    # Make a Circle selection.
    w = min(v.mask.scale_w, v.mask.scale_h)
    Sel.ellipse(
        j,
        v.mask.center_x - w / 2., v.mask.center_y - w / 2.,
        w, w
    )


def do_cut_corner_mask(j, v, maya):
    """
    Make a cut corner selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    x, y, w, h = v.mask.sel_x, v.mask.sel_y, v.mask.scale_w, v.mask.scale_h

    # the difference between scale and selection, 'w1, h1'
    w1 = (v.mask.sel_w - w) / 2.
    h1 = (v.mask.sel_h - h) / 2.

    # eight segments
    q = (
        x + w1, y,
        x + v.mask.sel_w - w1, y,
        x + v.mask.sel_w, y + h1,
        x + v.mask.sel_w, y + v.mask.sel_h - h1,
        x + v.mask.sel_w - w1, y + v.mask.sel_h,
        x + w1, y + v.mask.sel_h,
        x, y + v.mask.sel_h - h1,
        x, y + h1
    )
    Sel.polygon(j, q)


def do_eye(j, v, maya):
    """
    Make an eye selection.

    Ellipse Radius Formula Reference
    rechneronline.de/pi/circular-segment.php

    Formula
    radius = (w² / 4 + h²) / 2 / h

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w, h = v.mask.scale_w, v.mask.scale_h / 2.

    # topleft of eye rectangle, 'x, y'
    x = v.mask.center_x - w / 2.
    y = v.mask.center_y - h

    radius = (w * w / 4. + h * h) / 2. / h
    diameter = radius * 2
    x = x - (diameter - w) / 2.

    Sel.ellipse(j, x, y, diameter, diameter)
    Sel.ellipse(
        j,
        x, y - diameter + v.mask.scale_h,
        diameter, diameter,
        option=fu.CHANNEL_OP_INTERSECT
    )


def do_hexagon(j, v, maya):
    """
    Make a hexagon selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w, h = v.mask.scale_w, v.mask.scale_h

    # There are two possible solutions.
    # first solution
    w1, h1 = w, w * UP_RATIO

    # Check for overflow.
    if h1 > h:
        # second solution
        w1, h1 = h * RATIO, h

    q = Shape.calc_hexagon_offset(w1, h1)
    Sel.polygon(
        j,
        Shape.calc_hexagon(
            q, v.mask.center_x - q[0], v.mask.center_y - q[2], w1, h1
        )
    )


def do_hexagon_shear(j, v, maya):
    """
    Make a sheared hexagon selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w, h = v.mask.scale_w / 2., v.mask.scale_h / 2.
    Sel.polygon(
        j,
        Shape.calc_hexagon(
            Shape.calc_hexagon_offset(v.mask.scale_w, v.mask.scale_h),
            v.mask.center_x - w, v.mask.center_y - h,
            v.mask.scale_w, v.mask.scale_h
        )
    )


def do_hexagon_truncated_shear(j, v, maya):
    """
    Make a sheared truncated hexagon selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w, h = v.mask.scale_w / 2., v.mask.scale_h / 2.
    Sel.polygon(
        j,
        Shape.calc_hexagon_truncated(
            v.mask.center_x - w, v.mask.center_y - h,
            v.mask.scale_w, v.mask.scale_h,
            Shape.calc_hexagon_truncated_offset(v.mask.scale_w, v.mask.scale_h)
        )
    )


def do_hexagon_truncated(j, v, maya):
    """
    Make a truncated hexagon selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w, h = v.mask.scale_w, v.mask.scale_h

    # There are two possible solutions.
    # first solution
    w1, h1 = h * UP_RATIO, h

    # Check for overflow.
    if w1 > w:
        # second solution
        w1, h1 = w, w * RATIO

    q = Shape.calc_hexagon_truncated_offset(w1, h1)
    x = v.mask.center_x - q[1]
    y = v.mask.center_y - q[3]
    Sel.polygon(j, Shape.calc_hexagon_truncated(x, y, w1, h1, q))


def do_image(j, v, maya):
    """
    Make an image selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    pdb.gimp_selection_none(j)

    j1 = maya.get_mask_image(maya.r_c)
    if j1:
        Mage.copy_all(j1.j)

        j2 = pdb.gimp_edit_paste_as_new_image()

        # Shape, copy, and delete the image.
        Mage.shape(j2, v.mask.scale_w, v.mask.scale_h)

        z1 = Lay.paste(j.layers[0])

        pdb.gimp_layer_set_offsets(z1, *calc_scaled_rect(v)[:2])
        Sel.item(z1)
        Lay.remove(z1)


def do_octagon(j, v, maya):
    """
    Make an octagon selection.

    Reference
        'math.stackexchange.com/
        questions/22064/
        calculating-a-point-that-lies-on-an-ellipse-given-an-angle'

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w = min(v.mask.scale_w, v.mask.scale_h)

    # topleft, 'x, y'
    x = v.mask.center_x - w / 2.
    y = v.mask.center_y - w / 2.

    q = Shape.calc_octagon_offset(w, w)
    Sel.polygon(j, Shape.calc_octagon_shape(x, y, w, w, q))


def do_octagon_shear(j, v, maya):
    """
    Make a sheared octagon selection.

    Reference to a Helpful Formula
        'math.stackexchange.com/
        questions/22064/
        calculating-a-point-that-lies-on-an-ellipse-given-an-angle'

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w, h = v.mask.scale_w / 2., v.mask.scale_h / 2.
    Sel.polygon(
        j,
        Shape.calc_octagon_shape(
            v.mask.center_x - w, v.mask.center_y - h,
            v.mask.scale_w, v.mask.scale_h,
            Shape.calc_octagon_offset(v.mask.scale_w, v.mask.scale_h)
        )
    )


def do_octagon_side_to_side(j, v, maya):
    """
    Make a sheared side-to-side Octagon selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w = min(v.mask.scale_w, v.mask.scale_h)

    # topleft 'x, y'
    x = v.mask.center_x - w / 2.
    y = v.mask.center_y - w / 2.

    q = Shape.calc_octagon_side_to_side_offset(w, w)
    Sel.polygon(j, Shape.calc_octagon_side_to_side_shape(x, y, w, w, q))


def do_octagon_side_to_side_shear(j, v, maya):
    """
    Make a sheared side-to-side octagon selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w, h = v.mask.scale_w / 2., v.mask.scale_h / 2.
    Sel.polygon(
        j,
        Shape.calc_octagon_side_to_side_shape(
            v.mask.center_x - w, v.mask.center_y - h,
            v.mask.scale_w, v.mask.scale_h,
            Shape.calc_octagon_side_to_side_offset(
                v.mask.scale_w,
                v.mask.scale_h
            )
        )
    )


def do_ellipse(j, v, maya):
    """
    Make an ellipse selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w, h = v.mask.scale_w, v.mask.scale_h
    Sel.ellipse(j, v.mask.center_x - w / 2., v.mask.center_y - h / 2., w, h)


def do_rectangle(j, v, maya):
    """
    Make a rectangle selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w, h = v.mask.scale_w, v.mask.scale_h
    x = v.mask.center_x - w / 2.
    y = v.mask.center_y - h / 2.
    Sel.rect(j, x, y, w, h)


def do_rhombus(j, v, maya):
    """
    Make a rhombus selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w = min(v.mask.scale_w, v.mask.scale_h) / 2.
    x = v.mask.center_x
    y = v.mask.center_y
    q = (
        x, y - w,
        x + w, y,
        x, y + w,
        x - w, y
    )
    Sel.polygon(j, q)


def do_rhombus_shear(j, v, maya):
    """
    Make a sheared rhombus selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w, h = v.mask.scale_w / 2., v.mask.scale_h / 2.
    x = v.mask.center_x
    y = v.mask.center_y

    # four segments
    q = (
        x, y - h,
        x + w, y,
        x, y + h,
        x - w, y
    )
    Sel.polygon(j, q)


def do_rounded_corner(j, v, maya):
    """
    Make a rounded Corner selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    x, y = v.mask.sel_x, v.mask.sel_y
    w = v.mask.sel_w - v.mask.scale_w
    h = v.mask.sel_h - v.mask.scale_h

    # top-left
    Sel.ellipse(j, x, y, w, h)

    # top-right
    x1 = x + v.mask.sel_w - w

    Sel.ellipse(j, x1, y, w, h, option=fu.CHANNEL_OP_ADD)

    # bottom-left
    y1 = y + v.mask.sel_h - h

    Sel.ellipse(j, x, y1, w, h, option=fu.CHANNEL_OP_ADD)

    # bottom-right
    Sel.ellipse(j, x1, y1, w, h, option=fu.CHANNEL_OP_ADD)

    # vertical rectangle
    x2 = x + w / 2.
    w1 = v.mask.sel_w - w

    Sel.rect(j, x2, y, w1, v.mask.sel_h, option=fu.CHANNEL_OP_ADD)

    # horizontal rectangle
    y2 = y + h / 2.
    h1 = v.mask.sel_h - h
    Sel.rect(j, x, y2, v.mask.sel_w, h1, option=fu.CHANNEL_OP_ADD)


def do_square(j, v, maya):
    """
    Make a square selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    w = min(v.mask.scale_w, v.mask.scale_h)
    x = v.mask.center_x - w / 2.
    y = v.mask.center_y - w / 2.
    Sel.rect(j, x, y, w, w)


def do_text(j, v, maya):
    """
    Make a text selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    cat = The.cat
    font = v.mask.d[ok.FONT]

    if font not in cat.font_list:
        font = cat.font_list[0] if cat.font_list else None
    if font is not None:
        font_size = max(v.mask.scale_w, v.mask.scale_h)
        character = v.mask.d[ok.TEXT]
        if character:
            z = Lay.add(j, "text")
            go, z1 = Lay.make_text(
                j, z,
                NO_ANTIALIAS,
                character,
                font_size,
                font,
                (255, 255, 255),
                v.mask.sel_x, v.mask.sel_y,
                v.mask.scale_w, v.mask.scale_h
            )
            if go:
                Sel.item(z1)

                is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

                if is_sel:
                    x = v.mask.center_x - ((x1 - x) / 2.)
                    y = v.mask.center_y - ((y1 - y) / 2.)

                    pdb.gimp_layer_set_offsets(z1, x, y)
                    Sel.item(z1)
                Lay.remove_layers((z, z1))


def do_triangle_down_isosceles(j, v, maya):
    """
    Make a down-facing isosceles triangle selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    Sel.polygon(
        j, ROUTE[ft.TRIANGLE_DOWN_ISOSCELES](
            Rect(
                v.mask.center_x - v.mask.scale_w / 2.,
                v.mask.center_y - v.mask.scale_h / 2.,
                v.mask.scale_w, v.mask.scale_h
            )
        )
    )


def do_triangle_down_shear(j, v, maya):
    """
    Make a sheared down-facing triangle selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    Sel.polygon(
        j, ROUTE[ft.TRIANGLE_DOWN_SHEAR](
            Rect(
                v.mask.center_x - v.mask.scale_w / 2.,
                v.mask.center_y - v.mask.scale_h / 2.,
                v.mask.scale_w, v.mask.scale_h
            )
        )
    )


def do_triangle_left_isosceles(j, v, maya):
    """
    Make a Left-Facing Isosceles Triangle selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    Sel.polygon(
        j, ROUTE[ft.TRIANGLE_LEFT_ISOSCELES](
            Rect(
                v.mask.center_x - v.mask.scale_w / 2.,
                v.mask.center_y - v.mask.scale_h / 2.,
                v.mask.scale_w, v.mask.scale_h
            )
        )
    )


def do_triangle_left_shear(j, v, maya):
    """
    Make a sheared left-facing triangle selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    Sel.polygon(j, ROUTE[
        ft.TRIANGLE_LEFT_SHEAR](
            Rect(
                v.mask.center_x - v.mask.scale_w / 2.,
                v.mask.center_y - v.mask.scale_h / 2.,
                v.mask.scale_w, v.mask.scale_h
            )
        )
    )


def do_triangle_right_isosceles(j, v, maya):
    """
    Make a right-facing isosceles triangle selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    Sel.polygon(
        j, ROUTE[ft.TRIANGLE_RIGHT_ISOSCELES](
            Rect(
                v.mask.center_x - v.mask.scale_w / 2.,
                v.mask.center_y - v.mask.scale_h / 2.,
                v.mask.scale_w, v.mask.scale_h
            )
        )
    )


def do_triangle_right_shear(j, v, maya):
    """
    Make a sheared right-facing triangle selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    Sel.polygon(
        j, ROUTE[ft.TRIANGLE_RIGHT_SHEAR](
            Rect(
                v.mask.center_x - v.mask.scale_w / 2.,
                v.mask.center_y - v.mask.scale_h / 2.,
                v.mask.scale_w, v.mask.scale_h
            )
        )
    )


def do_triangle_up_isosceles(j, v, maya):
    """
    Make an up-facing isosceles triangle selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    Sel.polygon(
        j, ROUTE[ft.TRIANGLE_UP_ISOSCELES](
            Rect(
                v.mask.center_x - v.mask.scale_w / 2.,
                v.mask.center_y - v.mask.scale_h / 2.,
                v.mask.scale_w, v.mask.scale_h
            )
        )
    )


def do_triangle_up_shear(j, v, maya):
    """
    Make a sheared up-facing triangle selection.

    j: GIMP image
        to receive selection

    v: View
    maya: Maya
    """
    Sel.polygon(
        j, ROUTE[ft.TRIANGLE_UP_SHEAR](
            Rect(
                v.mask.center_x - v.mask.scale_w / 2.,
                v.mask.center_y - v.mask.scale_h / 2.,
                v.mask.scale_w, v.mask.scale_h
            )
        )
    )


def feather_mask(j, d):
    """
    Feather a Mask selection.

    j: GIMP image
        Is the render.

    d: dict
        Mask Preset
        {Option key: value}

    Return: state of selection
    """
    if Sel.is_sel(j) and d[ok.FEATHER]:
        a = d[ok.FEATHER]
        f = float(a) / d[ok.STEPS]
        b = f
        if a:
            Mage.expand_image(j, a)

            while a > b:
                pdb.gimp_selection_feather(j, b)
                b = min(b + f, a)
            Mage.contract_image(j, a)


def rotate_mask(j, d):
    """
    Rotate a Mask selection.

    j: GIMP image
        Is the render.

    d: dict
        Mask Preset

    Return: state of selection
    """
    if Sel.is_sel(j) and d[ok.ANGLE]:
        z = Lay.add(j, "Rotate")

        Sel.fill(z, (0, 0, 0))

        z1 = pdb.gimp_item_transform_rotate(
            z,
            math.radians(d[ok.ANGLE]),
            YES_AUTO_CENTER,
            X_IS_0,
            Y_IS_0
        )

        Sel.item(z1)
        Lay.remove_layers((z, z1))


MASK_FUNCTION = {
    sh.CIRCLE: do_circle,
    ms.CUT_CORNER: do_cut_corner_mask,
    ms.EYE: do_eye,
    sh.HEXAGON: do_hexagon,
    sh.HEXAGON_SHEAR: do_hexagon_shear,
    sh.HEXAGON_TRUNCATED: do_hexagon_truncated,
    sh.HEXAGON_TRUNCATED_SHEAR: do_hexagon_truncated_shear,
    ms.IMAGE: do_image,
    sh.OCTAGON: do_octagon,
    sh.OCTAGON_SHEAR: do_octagon_shear,
    sh.OCTAGON_SIDE_TO_SIDE: do_octagon_side_to_side,
    sh.OCTAGON_SIDE_TO_SIDE_SHEAR: do_octagon_side_to_side_shear,
    ms.ELLIPSE: do_ellipse,
    sh.RECTANGLE: do_rectangle,
    sh.RHOMBUS: do_rhombus,
    sh.RHOMBUS_SHEAR: do_rhombus_shear,
    ms.ROUNDED_CORNER: do_rounded_corner,
    sh.SQUARE: do_square,
    ms.TEXT: do_text,
    ft.TRIANGLE_DOWN_ISOSCELES: do_triangle_down_isosceles,
    ft.TRIANGLE_DOWN_SHEAR: do_triangle_down_shear,
    ft.TRIANGLE_LEFT_ISOSCELES: do_triangle_left_isosceles,
    ft.TRIANGLE_LEFT_SHEAR: do_triangle_left_shear,
    ft.TRIANGLE_RIGHT_ISOSCELES: do_triangle_right_isosceles,
    ft.TRIANGLE_RIGHT_SHEAR: do_triangle_right_shear,
    ft.TRIANGLE_UP_ISOSCELES: do_triangle_up_isosceles,
    ft.TRIANGLE_UP_SHEAR: do_triangle_up_shear
}
