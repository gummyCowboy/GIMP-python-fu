#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_maya_style import Style
from roller_def import get_default_value
from roller_one_fu import Lay
from roller_view_real import (
    add_sub_base_group,
    add_wip_layer,
    do_gradient_for_layer,
    finish_style,
    insert_copy_above
)
import gimpfu as fu

LAYER_NUM = "{} of {}"
pdb = fu.pdb


def make_style(v, maya):
    """
    Make the Backdrop Style.

    v: View
    maya: Rainbow Valley
    Return: layer
        with the style material
    """
    def _noise():
        """Adds noise to a layer."""
        if d[ok.POWER]:
            pdb.plug_in_solid_noise(
                j, z,
                0,                      # no tile-able
                1,                      # yes, turbulent
                seed_,
                7,                      # medium detail
                2,                      # horizontal size
                2                       # vertical size
            )
            pdb.plug_in_hsv_noise(
                j, z,
                4,                      # medium holdness
                d[ok.POWER],
                d[ok.POWER],
                d[ok.POWER]
            )

    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya)
    group = Lay.group(j, "WIP", parent=parent)
    n = d[ok.BACKDROP_TYPE]
    seed_ = d[ok.SEED] + v.glow_ball.seed

    if n == bs.BACKDROP_IMAGE:
        z = insert_copy_above(v, parent.layers[0], parent.layers[0])
        pdb.gimp_image_reorder_item(j, z, group, 0)

    elif n == bs.PLASMA:
        z = add_wip_layer(v, maya, "Plasma", group=group)
        pdb.plug_in_plasma(j, z, seed_, 3)

    else:
        e = get_default_value(by.GRADIENT_FILL)
        e[ok.GRADIENT_TYPE] = d[ok.GRADIENT_TYPE]
        e[ok.GRADIENT] = d[ok.GBR][ok.GRADIENT]

        if d[ok.GRADIENT_TYPE] == "Linear":
            e[ok.END_X] = e[ok.START_X] = .5
            e[ok.START_Y] = .0
            e[ok.END_Y] = 1.

        else:
            e[ok.START_X] = e[ok.START_Y] = .5
            e[ok.END_X] = e[ok.END_Y] = .0
        z = do_gradient_for_layer(v, e, group, 0)

    # layer counter, 'x'
    x = 1

    # total layers to make, 'a'
    a = 15
    a += 8 if d[ok.TEXTURE] else 7

    for i in range(10):
        z = Lay.clone(z, n=LAYER_NUM.format(x, a))
        z.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.plug_in_despeckle(j, z, i, 0, 0, 255)

        if i % 2:
            x += 1
            z = Lay.clone(z, n=LAYER_NUM.format(x, a))
            z.mode = fu.LAYER_MODE_LIGHTEN_ONLY

            _noise()

            seed_ += 1

            pdb.plug_in_despeckle(j, z, i, 0, 0, 255)
            z = Lay.merge(z)

        is_engrave = False

        if d[ok.TEXTURE]:
            if i < 7 or i == 9:
                is_engrave = True

        elif i < 7:
            is_engrave = True

        if is_engrave:
            x += 1
            z = Lay.clone(z, n=LAYER_NUM.format(x, a))

            pdb.plug_in_engrave(j, z, max(i, 2), 1)

            z.mode = fu.LAYER_MODE_BURN
            z = Lay.merge(z)

            pdb.plug_in_wind(
                j, z,
                0,              # threshold
                2,              # from top
                50,             # strength
                1,              # blast
                1               # leading edge
            )
        x += 1
    return finish_style(Lay.merge_group(parent), "Rainbow Valley")


class RainbowValley(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.GBR
    is_seeded = True

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            Has the Backdrop Style Button.

        super_maya: Backdrop Maya
        k_path: tuple
            Key path of the Backdrop Style Button.
        """
        Style.__init__(
            self,
            any_group,
            super_maya,
            make_style,
            k_path=[k_path, k_path + (ok.GBR,)]
        )

    def do(self, v, d, is_change):
        """
        Manage layer output.

        v: View
        d: dict
            Rainbow Valley Preset
            {Option key: value}

        is_change: bool
            If True, then the mask needs to be done.
        """
        self.is_dependent = d[ok.BACKDROP_TYPE] == bs.BACKDROP_IMAGE
        super(RainbowValley, self).do(v, d, is_change)
