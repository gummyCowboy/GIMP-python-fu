#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import Signal as si, Widget as fw
from roller_constant_key import (
    Button as bk, Option as ok, Step as sk, Widget as wk
)
from roller_one_extract import collect_step, get_model_branch, make_panel_key
from roller_one_the import The
from roller_port_process import PortProcess
from roller_port_tree import MODEL_TREE
from roller_widget_model_step import ModelStep
from roller_widget_button import (
    AcceptButton, AcceptAllButton, AcceptNoneButton, CancelButton
)
from roller_widget_row import WidgetRow


class PortModelStep(PortProcess):
    """Is a display container for the Model Tree."""
    window_key = "Model Step"

    def __init__(self, d, g):
        """
        g: Button
            Is responsible.
        """
        self._model_step_button = g

        # Collect the Model branch step.
        # the interface step key of Model branch, 'ui_step_q'
        step_q = The.helm.get_all_step_q()

        model_id = The.model_id

        # Is a list of branch render key, 'self._old_step'.
        self._old_step = []

        for i in step_q:
            if len(i) > 1:
                if isinstance(i[1], int):
                    self._old_step += [
                        (model_id.get_name(i[1]),) + get_model_branch(i)
                    ]
        PortProcess.__init__(self, d, g)

    def _draw_lists(self, box):
        """
        Draw, load, and verify the Model Tree option group.

        box: GTK container
            to receive group
        """
        self._model_tree = ModelStep(
            self._model_step_button,
            self._old_step,
            **{
                wk.COLOR: self.color,
                wk.RELAY: [],
                wk.ROLLER_WIN: self.roller_win
            }
        )
        box.add(self._model_tree)

    def draw(self):
        """Draw Widget."""
        self.draw_column((self._draw_lists, self.draw_step_process))

    def draw_step_process(self, box):
        """
        Draw a Widget group with Cancel and Accept options.

        box: GTK Box container
            to receive group
        """
        g = WidgetRow(
            **{
                wk.PADDING: (0, 0, fw.MARGIN, fw.MARGIN),
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win,
                wk.SUB: OrderedDict([
                    (bk.CANCEL, {wk.WIDGET: CancelButton}),
                    (bk.ACCEPT_NONE, {wk.WIDGET: AcceptNoneButton}),
                    (bk.ACCEPT_ALL, {wk.WIDGET: AcceptAllButton}),
                    (bk.ACCEPT, {wk.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        box.add(g)

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return lambda: None, self.on_accept_model_tree

    def on_accept_model_tree(self, g):
        """
        Modify the navigation tree from the new tree.

        g: Button
            Is responsible.
        """
        model_def = []
        model_name_q = []
        get_group = The.helm.get_group
        node = get_group(sk.EXTRA).item.node
        tree_step = []

        # ModelList definition with all Models,
        # offline and online, 'all_def'
        all_def = get_group(sk.MODEL).widget_d[ok.MODEL_LIST].get_model_def()

        if g.key == bk.ACCEPT:
            tree_step = self._model_tree.get_a()

        elif g.key == bk.ACCEPT_ALL:
            for model_name, model_type in all_def:
                # Add a list of step key to the Model Tree Widget.
                # Are steps that were not created previously.
                model_step_q = []

                collect_step(MODEL_TREE, (model_type,), model_step_q)

                # Replace the Model type with the Model name.
                model_step_q = [(model_name,) + i[1:] for i in model_step_q]

                # Convert Model specific group key to step key compatible.
                model_step_q = [
                    i[:-1] + (i[-1].split(",")[0],) for i in model_step_q
                ]
                tree_step += model_step_q

        # user chosen Model name list, 'model_name_q'
        for i in tree_step:
            if i[0] not in model_name_q:
                model_name_q += [i[0]]

        # new step render key list, 'new_step_q'
        new_step_q = [sk.EXTRA + k for k in tree_step]

        # Create a Model definition list for new online Model.
        for i in model_name_q:
            for model_name, model_type in all_def:
                if i == model_name:
                    model_def += [(i, model_type)]

        # Tell NodePanel to update itself.
        node.emit(si.UPDATE_TREE, (new_step_q + sk.DEFAULT_STEP, model_def))

        # Load Preset value dict from the Shelf for a former
        # offline step. Remove step key, from the Shelf,
        # if the step has moved to the navigation tree.

        # SuperPreset, 'e'
        # {step key: value dict}
        e = {}

        for i in The.helm.get_key_q():
            k = make_panel_key(i)
            d = The.shelf.get_step_d(k)
            if d:
                # Add to the SuperPreset for loading.
                e[i] = d
                The.shelf.remove_step(k)

        if e:
            The.preset.load_super(e)
        self.safe.any_group.changed()
