#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_model_goo import Goo
from roller_one import Rect
from roller_one_extract import Shape


class GridRect:
    """
    Calculate the position and the size of cells.
    The cells are rectangular shaped.
    """

    @staticmethod
    def calc(model, o):
        """
        Calculate cell rectangle for a Model's cell.

        model: Model
        o: One
            with Cell Type reference

        Return: list
            [Plan vote, Work vote]
        """
        vote_d = {}
        did_cell = model.past.did_cell
        row, column = model.division
        goo_d = model.goo_d
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w, h = min(canvas_w, o.column_width), min(canvas_h, o.row_height)

            s = w * column, h * row
            w, h = w / 1., h / 1.
            x, y = Shape.calc_pin_offset(
                o.pin_corner, (canvas_w, canvas_h), s, x, y
            )

        elif o.grid_type == gr.SHAPE_COUNT:
            w = canvas_w / column
            h = canvas_h / row
            w = min(w, h)
            s = w * column, w * row
            w, h = w, w
            x, y = Shape.calc_pin_offset(
                o.pin_corner, (canvas_w, canvas_h), s, x, y
            )

        else:
            w = canvas_w / 1. / column
            h = canvas_h / 1. / row

        # intersect points
        q_y = []
        q_x = []

        # Round is a fix here. Remove it and the cell grid has gap.
        for r in range(row + 1):
            q_y.append(round(y))
            y += h

        for c in range(column + 1):
            q_x.append(round(x))
            x += w

        for r in range(row):
            for c in range(column):
                r_c = r, c
                y, y1 = q_y[r], q_y[r + 1]
                x, x1 = q_x[c], q_x[c + 1]
                a = goo_d[r_c] = Goo(r_c)
                b = a.cell = Rect(x, y, max(1, x1 - x), max(1, y1 - y))
                a.merged = b.clone()
                a.plaque = x, y, x1, y, x1, y1, x, y1
                vote_d[r_c] = did_cell(r_c)
        return vote_d
