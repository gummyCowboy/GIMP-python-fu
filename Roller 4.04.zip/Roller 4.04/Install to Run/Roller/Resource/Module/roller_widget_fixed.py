#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk
from roller_widget import Widget
import gtk


class Fixed(Widget):
    """Is a GTK SpinButton."""
    change_signal = 'value-changed'

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        self._precision = 0
        self._limit = d[wk.LIMIT]
        self._greater_g = d[wk.GREATER_G]
        adjustment = self._adjustment = gtk.Adjustment(
            value=0.,
            lower=self._limit[0] / 1.,
            upper=self._limit[1] / 1.,
            step_incr=1,
        )

        d[wk.ALIGN] = 0, 0, 1, 0
        self.spin_button = gtk.SpinButton(
            adjustment=adjustment, climb_rate=1.1, digits=0
        )

        self.spin_button.set_numeric(1)
        self.spin_button.set_increments(1, 10)
        Widget.__init__(self, self.spin_button, **d)
        self.add(self.spin_button)
        self._adjustment.emit('value-changed')

    def get_a(self):
        """
        Get the value of the greater Widget.

        Return: value
            from the greater Widget
        """
        return self._greater_g.get_a()

    def get_lesser_a(self):
        """
        Get the value of the 'gtk.Alignment'.
        Call from the greater Widget.

        Return: numeric
            value of Fixed
        """
        return self.spin_button.get_value_as_int()

    def set_lesser_a(self, a):
        """
        Set the 'gtk.Alignment' value.
        Call from the greater Widget.

        a: numeric
            int or float
        """
        self._adjustment.set_value(a)
