#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import Comm
import gimpfu as fu
import math

pdb = fu.pdb


def get_background(z, n, is_hide=True):
    """
    Get the visible backdrop of a layer.

    z: layer
        with background

    n: string
        The layer name to give to the background layer.

    is_hide: bool
        If False, the WIP layer is included in the visible copy material.

    Return: layer
        the background copy
    """
    def _hide(_z):
        """
        _z: group layer or GIMP image
        """
        for _z1 in _z.layers:
            if _z1 not in branch_q:
                if _z1.visible:
                    hide_q.append(_z1)

            else:
                if hasattr(_z1, 'layers') and _z1 != z:
                    _z = _hide(_z1)
                break
        return _z

    j = z.image
    z1 = z

    # branch of layer parent to work-in-progress layer, 'branch_q'
    branch_q = []

    # hidden layer, 'hide_q'
    hide_q = [z] if is_hide else []

    # Get the outer-most parent of layer, 'z'.
    # Make a list of the parent groups for they may contain additional layers.
    while z1.parent:
        branch_q += [z1.parent]

        # group layer, 'z1'
        z1 = z1.parent

    branch_q.insert(0, z)

    node_z = branch_q[-1]

    # Hide trunk.
    for i in j.layers:
        if i == node_z:
            break
        if i.visible:
            hide_q.append(i)

    # Hide branch.
    if len(branch_q) > 1:
        _hide(node_z)

    for i in hide_q:
        Lay.hide(i)

    z1 = pdb.gimp_layer_new_from_visible(j, j, n)

    for i in hide_q:
        Lay.show(i)
    return z1


class Lay:
    """Organize layer functions."""

    @staticmethod
    def add(j, n, parent=None, offset=0):
        """
        Add a layer to an image.

        j: GIMP image
            to receive layer

        n: string
            new layer name

        parent: layer
            group layer

        offset: int
            from top of a layer stack
            from parent layer
            from 0 to the number of layers in the stack or group

        Return: layer
            newly inserted
        """
        z = Lay.new(j, n)

        pdb.gimp_image_insert_layer(j, z, parent, offset)
        return z

    @staticmethod
    def add_above(z, n=""):
        """
        Insert a new empty layer above an existing layer.

        z: layer
            target of insertion

        n: string
            the new layer name

        Return: layer
            newly added
        """
        return Lay.add(z.image, n, parent=z.parent, offset=Lay.offset(z))

    @staticmethod
    def add_below(z, n=""):
        """
        Insert a new empty layer below an existing layer.

        z: layer
            target of insertion

        n: string or None
            When true, the layer is named.

        Return: layer
            newly added
        """
        return Lay.add(z.image, n, parent=z.parent, offset=Lay.offset(z) + 1)

    @staticmethod
    def apply_mask(z):
        """
        Apply a layer's mask with its image.

        z: layer or None
            with mask
        """
        if z and z.mask:
            pdb.gimp_layer_remove_mask(z, fu.MASK_APPLY)

    @staticmethod
    def blur(z, a):
        """
        Blur a layer.

        z: layer
            to receive blur

        a: float or int
            blur amount
        """
        a = min(float(a), 500.)
        if a:
            if not Sel.is_sel(z.image):
                Sel.item(z)
            pdb.plug_in_gauss_rle2(z.image, z, a, a)

    @staticmethod
    def clear(z):
        """
        Remove the material from a layer.
        Remove the selection if there is one.

        z: layer
            to clear
        """
        pdb.gimp_selection_none(z.image)
        pdb.gimp_drawable_edit_clear(z)

    @staticmethod
    def clear_sel(z, keep_sel=False):
        """
        Clear a layer's selection.

        If there's no selection, do nothing.
        GIMP will clear the layer otherwise.

        z: layer
            to clear material

        keep_sel: flag
            If it's true, then the selection is removed.
        """
        j = z.image

        if Sel.is_sel(j):
            pdb.gimp_edit_clear(z)
        if not keep_sel:
            pdb.gimp_selection_none(j)

    @staticmethod
    def clone(z, n="", no_mask=True):
        """
        Duplicate a layer. The duplicate is placed
        above the copied layer in the layer palette.

        z: layer
            to duplicate

        n: string
            new layer name

        no_mask: bool
            If it is True, then a the source layer's mask is not cloned.

        Return: layer
            the duplicate
        """
        j = z.image

        # A selection will make a floating selection clone.
        pdb.gimp_selection_none(j)

        z1 = pdb.gimp_layer_new_from_drawable(z, j)
        a = Lay.offset(z)

        pdb.gimp_image_insert_layer(j, z1, z.parent, a)
        Lay.set_attr(z1, fu.LAYER_MODE_NORMAL, 100.)

        if z1.mask and no_mask:
            Lay.remove(z1.mask)

        if n:
            z1.name = n
        return z1

    @staticmethod
    def clone_opaque(z, is_opaque=True, n=None):
        """
        Return a duplicate layer with an optional
        transform that can make pixels fully opaque.

        z: layer
            with material

        is_opaque: flag
            When true, the clone is made 100% opaque.

        n: string or None
            new layer name
        """
        j = z.image
        z = Lay.clone(z, n=n, no_mask=False)

        # no semi-transparency
        if is_opaque:
            if pdb.gimp_item_is_group(z):
                z = pdb.gimp_image_merge_layer_group(j, z)

            # threshold all, '.0'
            pdb.plug_in_threshold_alpha(j, z, .0)
        return z

    @staticmethod
    def color_fill(z, q):
        """
        Fill a layer with a color.

        z: layer
            to fill

        q: tuple
            RGB color
        """
        pdb.gimp_selection_all(z.image)
        Sel.fill(z, q)

    @staticmethod
    def create_mask(z, option=fu.ADD_MASK_ALPHA):
        """
        Give a layer an alpha mask.

        z: layer
            to mask

        option: gimpfu enum
            mask type
        """
        mask = pdb.gimp_layer_create_mask(z, option)
        z.add_mask(mask)

    @staticmethod
    def dilate(z):
        """
        Dilate the material on a layer.

        z: layer
            to receive dilation
        """
        pdb.plug_in_dilate(
            z.image,
            z,
            6,              # opaque
            0,              # channel zero
            1.,             # full rate
            0,              # direction mask
            0,              # low limit
            255             # upper limit
        )

    @staticmethod
    def discard_mask(z):
        """
        Delete a layer's mask.

        z: layer or None
            Has mask.
        """
        if z and z.mask:
            pdb.gimp_layer_remove_mask(z, fu.MASK_DISCARD)

    @staticmethod
    def flip(z, horizontal=False):
        """
        Flip a layer horizontally or vertically.

        z: layer
            to flip

        horizontal: flag
            If it's true, flip layer horizontally.

        Return: layer
            the modified layer
        """
        a = fu.ORIENTATION_HORIZONTAL if horizontal \
            else fu.ORIENTATION_VERTICAL
        return pdb.gimp_item_transform_flip_simple(z, a, True, 0)

    @staticmethod
    def get_groups(a, q):
        """
        Recursively step through an image's layers
        while adding group layers to a list.

        a: GIMP image or layer group
            to scan for groups

        q: list
            of layer groups

        Return: last group layer, list of layers
            The list of layers is returned but is
            the same list through each recursion.
        """
        for i in a.layers:
            if pdb.gimp_item_is_group(i):
                q += [i]
                Lay.get_groups(i, q)
        return a, q

    @staticmethod
    def group(j, n, parent=None, offset=0, z=None):
        """
        Create a group layer.

        j: GIMP image
            to receive group

        n: string
            name of group

        parent: layer
            parent layer of group

        offset: int
            offset from the top of group

        z: layer
            to move to the new group

        Return: layer
            the group
        """
        group = pdb.gimp_layer_group_new(j)

        pdb.gimp_image_insert_layer(j, group, parent, offset)

        if z:
            # layer offset below the group layer, '0'
            pdb.gimp_image_reorder_item(j, z, group, 0)

        group.name = n
        group.mode = fu.LAYER_MODE_PASS_THROUGH
        return group

    @staticmethod
    def hide(z):
        """
        Make a layer invisible.

        z: layer
            to hide
        """
        if z.visible:
            pdb.gimp_item_set_visible(z, 0)

    @staticmethod
    def has_pixel(z):
        """
        Return the boolean of the pixel count of a layer. The color
        count is zero if the layer is completely transparent. Remove
        selection so the plug-in function works properly.

        z: layer
            to check

        Return: int
            the number of colors in the layer
        """
        if z:
            pdb.gimp_selection_none(z.image)
            return bool(pdb.plug_in_ccanalyze(z.image, z))

    @staticmethod
    def insert_above(z, z1, n=None):
        """
        Insert a layer above another.

        z: layer
            Has position to insert.

        z1: layer
            to insert
            Has not been added to the image yet.

        Return: layer
            that was inserted
        """
        pdb.gimp_image_insert_layer(z.image, z1, z.parent, Lay.offset(z))

        if n is not None:
            z1.name = n
        return z1

    @staticmethod
    def make_text(
        j, z,
        antialias,
        text,
        font_size,
        font,
        color,
        x, y,
        w, h
    ):
        """
        Create a text layer. Transform the text layer to fit into a rectangle.

        j: GIMP image
            to receive text layer

        z: layer or None
            to receive text

        text: string
            to make on text layer

        font_size: int
            font size of text

        font: string
            font name

        color: tuple
            RGBA

        x, y: int
            topleft coordinate of text

        w, h: int
            boxed text size

        Return: tuple
            bool, layer
            bool
                Is a success flag, where true equates to success.
            layer
                of the transformed text
                Could be None on failure.
        """
        # text layer, 'z1'
        z1 = None

        go = True
        text = text.decode('utf-8').strip()
        offset_z = Lay.offset(z) if z else 0

        # Remove any selection so that 'gimp_text_fontname' returns a layer.
        pdb.gimp_selection_none(j)

        try:
            # Pass None as a layer option so
            # that function will create a new layer.
            # Text layer type, 'z1'
            z1 = pdb.gimp_text_fontname(
                j, None,
                float(x), float(y),
                text,
                0,                      # border
                1,
                float(font_size),
                fu.PIXELS,
                font
            )

        except Exception as ex:
            Comm.show_err(ex)
            Comm.info_msg("Apologies. Roller's text method failed to draw.")
            go = False

        if z1:
            pdb.gimp_text_layer_set_color(z1, color)
            pdb.gimp_text_layer_set_antialias(z1, antialias)
            pdb.plug_in_autocrop_layer(j, z1)

            if w:
                pdb.gimp_item_transform_scale(
                    z1, 0., 0., float(w), float(h)
                )
            if Lay.valid(z):
                # Convert the Text layer to a raster layer.
                # Move the layer, 'z1', from the top of the layer palette
                # so that it can be merged with the target layer, 'z'.
                pdb.gimp_image_reorder_item(j, z1, z.parent, offset_z)
                z1 = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
        return go, z1

    @staticmethod
    def merge(z):
        """
        Merge a layer down, then rename it.

        z: layer
            to merge down

        Return: layer
            after the merge
        """
        n = z.name
        z = pdb.gimp_image_merge_down(z.image, z, fu.CLIP_TO_IMAGE)
        z.name = n
        return z

    @staticmethod
    def merge_group(z, n=None):
        """
        Merge layer group. Resize the merge group to the image size.

        z: layer
            a group

        n: string or None
            name of the group after merging

        Return: layer
            the merged group
        """
        z = pdb.gimp_image_merge_layer_group(z.image, z)

        if n:
            z.name = n
        return z

    @staticmethod
    def new(j, n):
        """
        Create a layer.

        j: GIMP image
            to receive layer

        n: string
            layer name

        Return: layer
            newly created
        """
        z = pdb.gimp_layer_new(
            j,
            j.width, j.height,
            fu.RGBA_IMAGE,
            n,
            100.,                       # opacity
            fu.LAYER_MODE_NORMAL
        )
        return z

    @staticmethod
    def offset(z):
        """
        Get a layer's offset from its parent.

        z: layer
            with an unknown offset

        Return: int
            offset from the parent layer
            from 0 to the number of layers in the group minus one
        """
        if z:
            return pdb.gimp_image_get_item_position(z.image, z)
        return -1

    @staticmethod
    def paste(z, n=""):
        """
        Paste the content of the buffer.

        z: layer
            paste above this layer

        n: string
            name of pasted layer

        Return: layer
            newly created
        """
        j = z.image

        # With a selection, GIMP pastes the buffer
        # material centered around the selection.
        pdb.gimp_selection_none(j)

        z1 = z
        is_group = pdb.gimp_item_is_group(z)

        if is_group:
            # GIMP throws an error if the target layer
            # of a paste operation is a group layer.
            z1 = Lay.add_above(z, "Base")

        z = pdb.gimp_edit_paste(z1, 0)

        pdb.gimp_floating_sel_to_layer(z)

        if is_group:
            Lay.remove(z1)

        if n:
            z.name = n
        return z

    @staticmethod
    def paste_into(group, n=""):
        """
        Paste the content of the buffer into layer group.

        z: layer
            paste above this layer

        n: string
            name of pasted layer

        Return: layer
            newly created
        """
        j = group.image
        base = None

        # With a selection, GIMP pastes the buffer
        # material centered around the selection.
        pdb.gimp_selection_none(j)

        if not group.layers or pdb.gimp_item_is_group(group.layers[0]):
            z = base = Lay.add(j, n, parent=group)

        else:
            z = group.layers[0]

        z = pdb.gimp_edit_paste(z, 0)

        pdb.gimp_floating_sel_to_layer(z)

        if base:
            Lay.remove(base)

        if n:
            z.name = n
        return z

    @staticmethod
    def remove(z):
        """
        Remove a layer if it exists.

        z: layer
            to remove
        """
        if Lay.valid(z):
            if pdb.gimp_item_is_layer_mask(z):
                z1 = pdb.gimp_layer_from_mask(z)
                Lay.discard_mask(z1)
            else:
                pdb.gimp_image_remove_layer(z.image, z)

    @staticmethod
    def remove_layers(a):
        """
        Remove zero or more layers.

        a: iterable or layer
            of layer
            to remove
        """
        if a:
            if isinstance(a, (tuple, list)):
                for i in a:
                    Lay.remove(i)
            else:
                Lay.remove(a)

    @staticmethod
    def rename(z, n):
        """
        Rename a GIMP layer.

        z: layer
            to rename

        n: string
            the layer's new name

        Return: bool
            Is true, if the layer was renamed.
        """
        if Lay.valid(z):
            z.name = n
            return True
        return False

    @staticmethod
    def rotate(z, f):
        """
        Rotate a layer around the center of the image.

        z: layer
            to rotate

        f: float
            angle of rotation in degree
        """
        # If there's a selection, the selection is rotated.
        pdb.gimp_selection_none(z.image)
        pdb.gimp_item_transform_rotate(
            z,
            math.radians(f),
            1,                           # yes, auto-center
            .0, .0                       # x, y
        )

    @staticmethod
    def set_attr(z, mode, opacity):
        """
        Set layer attributes mode and opacity. Hypothetically,
        its faster to set attribute only when changed.

        z: layer
            WIP

        mode: int
            for layer

        opacity: float
            for layer

        Return: bool
            Is True if there is change.
        """
        m = False

        if z:
            if z.opacity != opacity:
                z.opacity = opacity
                m = True
            if z.mode != mode:
                z.mode = mode
                m = True
        return m

    @staticmethod
    def set_mode(z, mode):
        """
        Set the layer mode for a layer.

        z: layer
            WIP

        mode: GIMP layer mode enum
        """
        if z.mode != mode:
            z.mode = mode

    @staticmethod
    def show(z):
        """
        Make a layer visible.

        z: layer
            to show
        """
        if not z.visible:
            pdb.gimp_item_set_visible(z, 1)

    @staticmethod
    def switch(z, z1):
        """
        Remove the first layer. Give the second layer the first layer's name.

        z: layer
            to remove
            Has name.

        z1: layer
            to rename
        """
        n = z.name

        Lay.remove(z)
        z1.name = n

    @staticmethod
    def transfer_mask(z, z1, option=fu.ADD_MASK_ALPHA):
        """
        Transfer a mask from one layer to another.

        z: layer
            to receive mask

        z1: layer
            with the mask

        option: gimpfu enum
            mask-type
        """
        if not z1.mask:
            Lay.create_mask(z1, option=option)
        if not z.mask:
            z.add_mask(pdb.gimp_layer_create_mask(z1, option))

    @staticmethod
    def valid(z):
        """"
        Determine if a layer reference is valid.

        z: layer
            Is it None or invalid?

        Return: bool
            Is true if the layer is valid.
        """
        return z and pdb.gimp_item_is_valid(z)

    @staticmethod
    def verify(z):
        """
        Verify that a layer has material. If the layer
        does not have material, remove the layer. If
        pixels are shifted outside of the image, this
        function will still verify the layer.

        z: layer
            to test

        Return: layer or None
            Is None if the layer had no material.
        """
        if z:
            if Lay.has_pixel(z):
                return z
            pdb.gimp_image_remove_layer(z.image, z)

    @staticmethod
    def verify_group(group):
        """
        Merge a layer group, then verify that the new layer has material.
        If the new layer does not have material, remove it.

        group: layer
            to merge and verify

        Return: layer or None
            the merged group
            Is None if there was no material.
        """
        z = Lay.merge_group(group)
        return Lay.verify(z)


class Sel:
    """Organize selection functions."""

    @staticmethod
    def border(j, z, w, m):
        """
        Make a border selection. When a selection is grown
        incrementally, the selection appears to be angular.

        j: GIMP image
            with selection

        z: layer
            Is the material that the border surround.

        w: int
            expansion amount

        m: bool
            expansion type
            False is rounded.
            True is angular.
        """
        f = z.opacity
        z.opacity = 100.

        Sel.item(z)

        if m:
            pdb.gimp_context_set_antialias(0)
            for _ in range(w):
                pdb.gimp_selection_grow(j, 1)

        else:
            pdb.gimp_context_set_antialias(1)
            pdb.gimp_selection_grow(j, w)

        Sel.item(z, option=fu.CHANNEL_OP_SUBTRACT)
        z.opacity = f

    @staticmethod
    def color(z, q, option=fu.CHANNEL_OP_REPLACE):
        """
        Create a selection based on color.

        z: layer
            to color

        q: tuple
            RGB color
        option: gimpfu enum
            Selection type
        """
        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_sample_merged(0)

        # composite
        pdb.gimp_context_set_sample_criterion(0)
        pdb.gimp_context_set_sample_threshold(.059)
        pdb.gimp_context_set_sample_transparent(1)
        pdb.gimp_image_select_color(z.image, option, z, q)

    @staticmethod
    def ellipse(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE):
        """
        Make an ellipse selection.

        j: GIMP image
            to receive selection

        x, y: numeric
            top-left point of ellipse

        w: numeric
            radius width

        h: numeric
            radius height

        option: GIMP enum
            add, replace, subtract, or intersect
        """
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_feather(0)
        pdb.gimp_image_select_ellipse(j, option, x, y, w, h)

    @staticmethod
    def fill(z, q):
        """
        Fill, within a selection, a layer with a color.

        z: layer
            to apply fill

        q: tuple
            RGB color

        opacity: float
            of the color
        """
        # Preserve.
        q1 = pdb.gimp_context_get_background()

        if len(q) != 4:
            # RGB
            opacity = 100.

        else:
            # RGBA
            opacity = round(q[3] / 255. * 100., 1)

        pdb.gimp_context_set_background(q)
        pdb.gimp_edit_bucket_fill(
            z,
            fu.BACKGROUND_FILL,
            fu.LAYER_MODE_NORMAL,
            opacity,
            .0,                     # threshold all
            0,                      # no sample merge
            0, 0
        )

        # Restore.
        pdb.gimp_context_set_background(q1)

    @staticmethod
    def grow(j, w, m=False):
        """
        Expand a selection. When a selection is grown
        incrementally, the selection appears to be angular.

        j: GIMP image
            with selection

        w: int
            expansion amount

        m: bool
            expansion type
            False is rounded.
            True is angular.
        """
        if m:
            pdb.gimp_context_set_antialias(0)
            for _ in range(w):
                pdb.gimp_selection_grow(j, 1)

        else:
            pdb.gimp_context_set_antialias(1)
            pdb.gimp_selection_grow(j, w)

    @staticmethod
    def invert(j):
        """
        Invert a selection.

        j: GIMP image
            with selection
        """
        if Sel.is_sel(j):
            pdb.gimp_selection_invert(j)

    @staticmethod
    def invert_clear(z, keep_sel=False):
        """
        Invert and clear a selection.

        z: layer
            Is cleared.

        keep_sel: flag
            If it's true, then the selection is the same on exit.
        """
        j = z.image

        if keep_sel:
            sel = pdb.gimp_selection_save(j)

        Sel.invert(j)
        Lay.clear_sel(z)
        if keep_sel:
            Sel.load(j, sel)
            pdb.gimp_image_remove_channel(j, sel)

    @staticmethod
    def is_sel(j):
        """
        Determine if there is a selection.

        j: GIMP image
            with selection

        Return: bool
            If it's true, then there is a selection.
        """
        return not pdb.gimp_selection_is_empty(j)

    @staticmethod
    def isolate(z, sel, keep_sel=False):
        """
        Clear out material not in a selection.

        z: layer
            with material to clear

        sel: selection
            The selection part is preserved and the other part is removed.

        keep_sel: flag
            If true, the selection remains.
        """
        Sel.load(z.image, sel)
        Sel.invert_clear(z, keep_sel=keep_sel)

    @staticmethod
    def item(z, option=fu.CHANNEL_OP_REPLACE):
        """
        Select an item. If the item has a mask,
        select it so that its selection intersects.

        z: layer
            to select

        option: GIMP enum
            selection operation
            replace, add, subtract
        """
        j = z.image
        f = z.opacity

        if f != 100.:
            z.opacity = 100.

        sel = sel1 = None
        is_add = option == fu.CHANNEL_OP_ADD and z.mask
        is_subtract = option == fu.CHANNEL_OP_SUBTRACT and z.mask
        is_intersect = option == fu.CHANNEL_OP_INTERSECT and z.mask

        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_antialias(0)

        if is_add or is_subtract or is_intersect:
            if Sel.is_sel(j):
                sel = pdb.gimp_selection_save(j)

        if z.mask:
            # Create a selection from the material and the mask.
            pdb.gimp_image_select_item(j, fu.CHANNEL_OP_REPLACE, z.mask)
            pdb.gimp_image_select_item(j, fu.CHANNEL_OP_INTERSECT, z)

            if sel:
                if is_add or is_intersect:
                    Sel.load(j, sel, option=option)
                elif is_subtract:
                    if Sel.is_sel(j):
                        sel1 = pdb.gimp_selection_save(j)
                        Sel.load(j, sel)
                        Sel.load(j, sel1, option=option)

        else:
            pdb.gimp_image_select_item(j, option, z)

        if sel:
            pdb.gimp_image_remove_channel(j, sel)
            if sel1:
                pdb.gimp_image_remove_channel(j, sel1)
        if f != 100.:
            # Restore the original opacity.
            z.opacity = f

    @staticmethod
    def load(j, sel, option=fu.CHANNEL_OP_REPLACE):
        """
        Load a previously saved selection.

        j: GIMP image
            to receive selection

        sel: selection
            a selection channel of image

        option: selection operation
            add, replace, subtract
        """
        if Lay.valid(sel):
            pdb.gimp_context_set_feather(0)
            pdb.gimp_context_set_antialias(0)
            pdb.gimp_image_select_item(j, option, sel)
        elif option == fu.CHANNEL_OP_REPLACE:
            pdb.gimp_selection_none(j)

    @staticmethod
    def opaque(z, option=fu.CHANNEL_OP_REPLACE):
        """
        Make a selection from an cloned opaque layer.

        z: layer
            with material to select

        option: GIMP enum
            Is ADD, INTERSECT, REPLACE, or SUBTRACT.
            Is a boolean operation for selection.

        Return: state of selection
        """
        j = z.image
        sel = None

        if option != fu.CHANNEL_OP_REPLACE:
            sel = pdb.gimp_selection_save(j)

        z1 = Lay.clone_opaque(z)

        if sel:
            Sel.load(j, sel)

        Sel.item(z1, option=option)
        pdb.gimp_image_remove_layer(z.image, z1)
        if sel:
            pdb.gimp_image_remove_channel(j, sel)

    @staticmethod
    def polygon(j, q, option=fu.CHANNEL_OP_REPLACE):
        """
        Add a polygon selection to the current selection.

        j: GIMP image
            to receive selection

        q: list
            of points

        option: GIMP enum
            add, subtract, or replace the selection mode
        """
        if q:
            pdb.gimp_context_set_antialias(1)
            pdb.gimp_context_set_feather(0)
            pdb.gimp_image_select_polygon(j, option, len(q), map(float, q))

        else:
            Comm.info_msg("Sorry. Roller failed to draw a polygon.")

    @staticmethod
    def rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE):
        """
        Draw a selection rectangle.

        j: GIMP image
            to receive selection
        """
        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_antialias(0)

        # Correct underflow with '0'.
        pdb.gimp_image_select_rectangle(j, option, x, y, max(0, w), max(0, h))

    @staticmethod
    def shape(j, shape, option=fu.CHANNEL_OP_REPLACE):
        """
        Make a selection based on a layer's cell
        shape, and an image's cell rectangle.

        j: GIMP image
            Has render.

        shape: tuple or dict
            If it is a dict, then the shape is an
            ellipse, otherwise, it is a polygon.

        option: enum
            selection operation
            add, subtract, intersect, or replace
        """
        if len(shape) == 4:
            Sel.ellipse(j, *shape, option=option)
        else:
            Sel.polygon(j, shape, option=option)

    @staticmethod
    def shrink(j, w):
        """
        Shrink a selection. Ensure that antialiasing is on.

        j: GIMP image
            WIP

        w: int
            amount to shrink
        """
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_selection_shrink(j, w)


class Mage:
    """Organize GIMP image-related functions."""

    @staticmethod
    def contract_image(j, a):
        """
        Reverse the image expansion provided by 'expand_image'.

        j: GIMP image
            work-in-progress

        a: int
            the amount to contract / 2
        """
        a = int(a)
        b = a * 2
        pdb.gimp_image_resize(j, j.width - b, j.height - b, -a, -a)

    @staticmethod
    def copy_all(j):
        """
        Copy a visible image while ensuring that it's the whole image.

        j: GIMP image
            to copy visible

        Return: state of the clipboard
        """
        pdb.gimp_selection_all(j)
        pdb.gimp_edit_copy_visible(j)

    @staticmethod
    def expand_image(j, a):
        """
        Enlarge an image on both x and y vectors. Provide extra
        pixel material for the feather process and Inner Shadow.

        j: GIMP image
            work-in-progress

        a: int
            the amount to expand / 2
            Use blur from options as it is the required.
        """
        a = int(a)
        b = a * 2
        pdb.gimp_image_resize(j, j.width + b, j.height + b, a, a)

    @staticmethod
    def rotate(j, a):
        """
        Rotate the base layer of an image.

        j: GIMP image
            to rotate assuming there is only one layer

        a: numeric
            rotation amount in degrees

        Return: layer
            the transformed layer
        """
        pdb.gimp_context_set_transform_direction(fu.TRANSFORM_FORWARD)
        pdb.gimp_context_set_transform_resize(fu.TRANSFORM_RESIZE_ADJUST)
        Lay.rotate(j.layers[0], a)
        pdb.gimp_image_resize_to_layers(j)
        return j.layers[0]

    @staticmethod
    def shape(j, w, h):
        """
        Resize, copy, and close an image.

        j: GIMP image
            with one layer

        w: int
            width to shape

        h: int
            height to shape

        Return: buffered data
            with image
        """
        z = j.layers[0]

        # The last option is the scale around the center, '1'.
        pdb.gimp_layer_scale(z, max(1, w), max(1, h), 1)

        pdb.gimp_image_resize_to_layers(j)

        # Set the selection to the entire image.
        # before copying.
        Mage.copy_all(j)

        pdb.gimp_image_delete(j)
