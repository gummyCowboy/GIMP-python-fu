#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame import Color, do_selection_material
from roller_frame_build import Build
from roller_def import get_default_value
from roller_maya import check_frame_cake, check_matter, make_frame_group
from roller_maya_blur_behind import BlurBehind
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_one_fu import Lay, Mage, Sel
from roller_one_image import Image as ig
from roller_one_the import The
from roller_view_real import COLOR, LIGHT, add_wip_layer, get_light
from roller_view_hub import draw_gradient, get_gradient_points
import gimpfu as fu
import os

pdb = fu.pdb


def apply_color(v, maya, z, d, r_c):
    """
    Color the frame.

    v: View
    maya: Maya
    z: layer
        Is frame.

    d: dict
        Has options.

    r_c: tuple
        (row, column) of int
        cell index

    Return: layer
        with frame material
    """
    Lay.color_fill(z, d[ok.CIR][ok.COLOR_1])
    return z


def apply_gradient(v, maya, z, d, r_c):
    """
    Color the frame with a gradient.

    v: View
    maya: Maya
    z: layer
        Is frame.

    d: dict
        Has options.

    r_c: tuple
        (row, column) of int
        cell index

    Return: layer
        with frame material
    """
    j = v.j
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    w, h = x1 - x, y1 - y
    e = get_default_value("Gradient Fill")

    e.update(d)

    e[ok.GRADIENT] = d[ok.GBRW][ok.GRADIENT]
    start_x, end_x, start_y, end_y = \
        get_gradient_points(
            d[ok.GRADIENT_ANGLE], x - v.wip.x, y - v.wip.y, w, h
        )

    Sel.rect(j, x, y, w, h)
    draw_gradient(z, e, start_x, start_y, end_x, end_y)
    Lay.blur(z, d[ok.BLUR])
    return z


def apply_image(v, maya, z, d, r_c):
    """
    Apply an image to the frame.

    v: View
    maya: Maya
    z: layer
        Has the frame.

    d: dict
        Frame Over Preset

    r_c: tuple
        (row, column) of int
        cell index

    Return: layer
        with the frame
    """
    j = v.j
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    j1 = maya.cause.get_frame_image(r_c)

    if j1:
        j1 = j1.j
        n = z.name

        Mage.copy_all(j1)

        j1 = pdb.gimp_edit_paste_as_new_image()

        Lay.blur(j1.layers[0], d[ok.BLUR])
        Mage.shape(j1, x1 - x, y1 - y)

        z1 = Lay.paste(z)

        pdb.gimp_layer_set_offsets(z1, x, y)

        z = Lay.merge(z1)
        z.name = n
    return z


def apply_plasma(v, maya, z, d, r_c):
    """
    Paint the frame with a plasma.

    v: View
    maya: Maya
    z: layer
        Has the frame.

    d: dict
        Frame Over Preset

    r_c: tuple
        (row, column) of int
        cell index

    Return: layer
        with material
    """
    j = v.j

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(
        j, z,
        d[ok.SEED] + v.glow_ball.seed,
        1.                              # lowest turbulence
    )
    Lay.blur(z, d[ok.BLUR])
    return z


def do_color(v, maya):
    """
    Make an overlay layer for the frame.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    j = v.j

    # Frame Over Preset dict, 'd'
    d = maya.value_d

    a = maya.super_maya
    super_ = maya.cause
    n = d[ok.FRAME_STYLE]

    if n in ROUTE:
        z = add_wip_layer(
            v, maya, "Style", group=a.group, offset=get_light(a)
        )

        if super_.cell_type == 'all' and n in ROUTE_MULTI:
            for r, c in super_.main_cell_q:
                sel = maya.model.get_image_sel((r, c))
                Sel.load(j, sel)
                if Sel.is_sel(j):
                    z = ROUTE_MULTI[n](v, maya, z, d, (r, c))
        else:
            Sel.item(super_.matter)
            if Sel.is_sel(j):
                z = ROUTE[n](v, maya, z, d, super_.r_c)
        return Lay.verify(z)


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: FrameOver
    Return: layer or None
        with the frame
    """
    d = maya.value_d
    if d[ok.FRAME_OVER] != "None":
        return do_selection_material(
            v, maya, do_sel, embellish, "Frame Over", is_clear=False
        )


def do_sel(v, maya, z):
    """
    Make a frame for a selection.

    v: View
    maya: Maya
    z: layer
        to receive the frame
    """
    j = v.j

    # Frame Over Preset dict, 'd'
    d = maya.value_d
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    n = "{}{}{}.png".format(The.frame_path, os.path.sep, d[ok.FRAME_OVER])
    e = get_default_value(ok.IMAGE_CHOICE)
    e[ok.FILE] = n
    e[ok.IMAGE_SOURCE] = ok.FILE

    # Get the GIMP image.
    j1 = ig.get_image(e, v.image_source)

    if j1:
        Mage.copy_all(j1.j)
        Mage.shape(pdb.gimp_edit_paste_as_new_image(), x1 - x, y1 - y)

        n1 = z.name
        z = Lay.paste(z, n="Frame")

        pdb.gimp_layer_set_offsets(z, x, y)

        z = Lay.merge(z)
        z.name = n1
    return z


def embellish(v, maya, z):
    """Is a callback for 'do_selection_material'."""
    return z


class FrameOver(Build):
    """Make an overlay for material."""
    issue_q = 'cake', 'matter', 'shade'
    is_seeded = True
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        self.do_matter = do_matter

        Build.__init__(self, any_group, super_maya, k_path)

        self.sub_maya[ok.BUMP] = Bump(
            any_group, self, k_path + (ok.GBRW, ok.BUMP)
        )
        self.sub_maya[COLOR] = Color(
            any_group,
            self,
            do_color,
            [
                k_path,
                k_path + (ok.CIR,),
                k_path + (ok.CIR, ok.IMAGE_CHOICE),
                k_path + (ok.GBRW,)
            ]
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (self.cause, self), k_path + (ok.SRR, ok.SHADOW)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.OTHER)
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(any_group, self, k_path)

    def do(self, v, d, is_change):
        """
        Produce layer output.

        v: View
        d: dict
            Frame Over Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[ok.BUMP].do(v, d[ok.GBRW][ok.BUMP], self.is_matter)
        self.sub_maya[COLOR].do(v, d, self.is_matter)

        m = self.sub_maya[ok.SHADOW].do(v, d[ok.SRR][ok.SHADOW])

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.sub_maya[ok.BLUR_BEHIND].do(v, d, m or is_back, self.is_matter)
        self.reset_issue()
        return m


ROUTE_MULTI = {
    ff.GRADIENT: apply_gradient,
    ff.IMAGE: apply_image,
}
ROUTE = {
    ff.COLOR: apply_color,
    ff.GRADIENT: apply_gradient,
    ff.IMAGE: apply_image,
    ff.PLASMA: apply_plasma
}
