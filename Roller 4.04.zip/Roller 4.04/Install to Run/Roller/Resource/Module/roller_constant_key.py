#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Keyword class modules have two letter import variables
# that are unique in the context of the program.
# As a rule, two letter variables are either import classes,
# enumerated single letter typed variable names, or
# single letter typed variable names with an underscore.
_BORDER = "Border"
_BOX = "Box"
_BUMP = "Bump"
_CANVAS = "Canvas"
_CAPTION = "Caption"
_CELL = "Cell"
_CELL_SHAPE = "Cell Shape"
_COLOR_PIPE = "Color Pipe"
_CORNER_TAPE = "Corner Tape"
_EXTRA = "Extra"
_FACE = "Face"
_FRINGE = "Fringe"
_IMAGE = "Image"
_INNER_SHADOW = "Inner Shadow"
_JAGGED_EDGE = "Jagged Edge"
_MARGIN = "Margin"
_MASK = "Mask"
_PLAN = "Plan"
_PLAQUE = "Plaque"
_PRESET = "Preset"
_PROPERTY = "Property"
_RANDOM = "Random"
_RECTANGLE = "Rectangle"
_RESIZE = "Resize"
_SHADOW = "Shadow"
_SHADOW_1 = "Shadow #1"
_SHADOW_2 = "Shadow #2"
_SHIFT = "Shift"
_SWITCH = "Switch"
_TYPE = "Type"
LIST_SEPARATOR = "@"


class BackdropStyle:
    """Are group key that identify a Backdrop Style. Import as 'by'."""
    ACRYLIC_SKY = "Acrylic Sky"
    AVERAGE_COLOR = "Average Color"
    CARBON_14 = "Carbon 14"
    CLAY_CHEMISTRY = "Clay Chemistry"
    COLOR_FILL = "Color Fill"
    COLOR_GRID = "Color Grid"
    CRYSTAL_CAVE = "Crystal Cave"
    CORE_DESIGN = "Core Design"
    CUBE_PATTERN = "Cube Pattern"
    CUBISM_COVER = "Cubism Cover"
    DARK_FORT = "Dark Fort"
    DENSITY_GRADIENT = "Density Gradient"
    DROP_ZONE = "Drop Zone"
    ETCH_SKETCH = "Etch Sketch"
    FLOOR_SAMPLE = "Floor Sample"
    GALACTIC_FIELD = "Galactic Field"
    GLASS_GAW = "Glass Gaw"
    GRADIENT_FILL = "Gradient Fill"
    HISTORIC_TRIP = "Historic Trip"
    IMAGE_GRADIENT = "Image Gradient"
    LINE_STONE = "Line Stone"
    LOST_MAZE = "Lost Maze"
    MAZE_BLEND = "Maze Blend"
    MYSTERY_GRATE = "Mystery Grate"
    NANO_SUIT = "Nano Suit"
    NOISE_RIFT = "Noise Rift"
    PATTERN_FILL = "Pattern Fill"
    RAINBOW_VALLEY = "Rainbow Valley"
    RECT_PATTERN = "Rectangle Pattern"
    ROCKY_LANDING = "Rocky Landing"
    SOFT_TOUCH = "Soft Touch"
    SPECIMEN_SPECKLE = "Specimen Speckle"
    SPIRAL_CHANNEL = "Spiral Channel"
    SQUARE_CLOUD = "Square Cloud"
    STONE_AGE = "Stone Age"
    TRAILING_VINE = "Trailing Vine"
    KEY_LIST = (
        ACRYLIC_SKY,
        AVERAGE_COLOR,
        CARBON_14,
        CLAY_CHEMISTRY,
        COLOR_FILL,
        COLOR_GRID,
        CORE_DESIGN,
        CRYSTAL_CAVE,
        CUBE_PATTERN,
        CUBISM_COVER,
        DARK_FORT,
        DENSITY_GRADIENT,
        DROP_ZONE,
        ETCH_SKETCH,
        FLOOR_SAMPLE,
        GALACTIC_FIELD,
        GLASS_GAW,
        GRADIENT_FILL,
        HISTORIC_TRIP,
        IMAGE_GRADIENT,
        LINE_STONE,
        LOST_MAZE,
        MAZE_BLEND,
        MYSTERY_GRATE,
        NANO_SUIT,
        NOISE_RIFT,
        PATTERN_FILL,
        RAINBOW_VALLEY,
        RECT_PATTERN,
        ROCKY_LANDING,
        SOFT_TOUCH,
        SPECIMEN_SPECKLE,
        SPIRAL_CHANNEL,
        SQUARE_CLOUD,
        STONE_AGE,
        TRAILING_VINE
    )


class Button:
    """Has keys used by a Button Widget. Import as 'bk'."""
    ACCEPT = "Accept"
    ACCEPT_ALL = "Accept All"
    ACCEPT_NONE = "Accept None"
    DEL_MODEL = 'del model'
    CANCEL = "Cancel"
    DRAFT = "Draft"
    MANAGE_PRESET = 'manage preset'
    MOVE_DOWN = 'move down'
    MOVE_UP = 'move up'
    OPEN = "Open…"
    PEEK = "Peek"
    PLAN = _PLAN
    NEW_MODEL = 'new model'
    PREVIEW = "Preview"
    RANDOM = _RANDOM
    RENAME = 'rename'
    SAVE_PRESET = 'save preset'
    SELECT_ALL = 'select all'
    SELECT_NONE = 'select none'


class Frame:
    """
    Has keys that identify a Frame. Are a Preset option key. Import as 'ek'.
    """
    BALL_JOINT = "Ball Joint"
    BORDER_LINE = "Border Line"
    BRUSH_PUNCH = "Brush Punch"
    CAMO_PLANET = "Camo Planet"
    CERAMIC_CHIP = "Ceramic Chip"
    CIRCLE_PUNCH = "Circle Punch"
    CLEAR_FRAME = "Clear Frame"
    COLOR_BOARD = "Color Board"
    COLOR_PIPE = _COLOR_PIPE
    CORNER_TAPE = _CORNER_TAPE
    CUTOUT_PLATE = "Cutout Plate"
    CRUMBLE_SHELL = "Crumble Shell"
    FEATHER_STEP = "Feather Step"
    FRAME_OVER = "Frame Over"
    GLASS_REVEAL = "Glass Reveal"
    GRADIENT_LEVEL = "Gradient Level"
    HOT_GLUE = "Hot Glue"
    JAGGED_EDGE = _JAGGED_EDGE
    LINE_FASHION = "Line Fashion"
    MAZE_MIRROR = "Maze Mirror"
    METALLIC_PROFILE = "Metallic Profile"
    PAINT_RUSH = "Paint Rush"
    RAD_WAVE = "Rad Wave"
    RAISED_MAZE = "Raised Maze"
    SHAPE_BURST = "Shape Burst"
    SQUARE_CUT = "Square Cut"
    SQUARE_PUNCH = "Square Punch"
    STAINED_GLASS = "Stained Glass"
    STRETCH_TRAY = "Stretch Tray"
    SHADOWY = "Shadowy"
    WIRE_FENCE = "Wire Fence"
    KEY_LIST = (
        BALL_JOINT,
        BORDER_LINE,
        BRUSH_PUNCH,
        CAMO_PLANET,
        CERAMIC_CHIP,
        CIRCLE_PUNCH,
        CLEAR_FRAME,
        COLOR_BOARD,
        COLOR_PIPE,
        CORNER_TAPE,
        CRUMBLE_SHELL,
        CUTOUT_PLATE,
        FEATHER_STEP,
        FRAME_OVER,
        GLASS_REVEAL,
        GRADIENT_LEVEL,
        HOT_GLUE,
        JAGGED_EDGE,
        LINE_FASHION,
        MAZE_MIRROR,
        METALLIC_PROFILE,
        PAINT_RUSH,
        RAD_WAVE,
        RAISED_MAZE,
        SHADOWY,
        SHAPE_BURST,
        SQUARE_CUT,
        SQUARE_PUNCH,
        STAINED_GLASS,
        STRETCH_TRAY,
        WIRE_FENCE
    )
    KEY_LIST_DECO = list(KEY_LIST)[:]

    for i in (
        BALL_JOINT,
        BRUSH_PUNCH,
        CORNER_TAPE,
        CUTOUT_PLATE,
        FRAME_OVER,
        SHAPE_BURST
    ):
        KEY_LIST_DECO.pop(KEY_LIST_DECO.index(i))


class Group:
    """
    Is a key for an AnyGroup. A comma splits a string to make a
    suitable label as in the case of a Node item. Import as 'gk'.
    """
    BACKDROP = "Backdrop"
    DECO = "Deco"
    EXTRA = _EXTRA
    GLOBAL = "Global"
    GRADIENT_LIGHT = "Gradient Light"
    MODEL = "Model"
    MODEL_NAME = "Model Name"
    SWITCH = _SWITCH

    # Shadow
    INNER_SHADOW = _INNER_SHADOW
    SHADOW_1 = _SHADOW_1
    SHADOW_2 = _SHADOW_2
    SHADOW_PRESET = _PRESET + ", " + _SHADOW

    # shared by Model
    BORDER = _BORDER
    CAPTION = _CAPTION
    FRINGE = _FRINGE
    IMAGE = _IMAGE
    MARGIN = _MARGIN
    PLAQUE = _PLAQUE
    PROPERTY = _PROPERTY
    RECTANGLE = _RECTANGLE
    SHIFT = _SHIFT
    TYPE = _TYPE

    # Box
    PROPERTY_BOX = "Property, Box"
    TYPE_BOX = "Type, Box"

    # Cell Model
    PROPERTY_CELL = "Property, Cell"
    TYPE_CELL = "Type, Cell"

    # Table
    PROPERTY_TABLE = "Property, Table"
    TYPE_TABLE = "Type, Table"

    # Stack
    PROPERTY_STACK = "Property, Stack"
    TYPE_STACK = "Type, Stack"

    # SuperPreset
    PRESET_BOX = "Preset, Box"
    PRESET_CELL = "Preset, Cell"
    PRESET_STACK = "Preset, Stack"
    PRESET_STEPS = "Preset, Steps"
    PRESET_TABLE = "Preset, Table"
    PRESET_SHADOW = "Preset, Shadow"
    SUPER_MODEL = PRESET_BOX, PRESET_CELL, PRESET_STACK, PRESET_TABLE

    # Window
    CELL_EDITOR = 'cell editor'
    MODEL_TREE = "Model Tree"

    PRESET = _PRESET
    IMAGE_SOURCE_USER = _BORDER, FRINGE, IMAGE, PLAQUE, BACKDROP


gk = Group


class Image:
    """Are keys used by the Image class. Import as 'ik'."""
    LOOP = 'loop'
    LOOP_DICT = 'loop_dict'
    NEXT = 'next'
    NEXT_DICT = 'next_dict'
    PREVIOUS = 'previous'
    PREVIOUS_DICT = 'previous_dict'
    SLICE = 'slice'


class Item:
    """Are used in a Node list. Import as 'ie'."""
    CANVAS = _CANVAS
    CELL = _CELL
    FACE = _FACE
    IMAGE = _IMAGE
    MARGIN = _MARGIN
    PRESET = _PRESET
    PROPERTY = _PROPERTY
    RECTANGLE = _RECTANGLE
    SHIFT = _SHIFT
    TYPE = _TYPE


class Model:
    """Has keys used by a Model. Import as 'md'."""
    BOX = _BOX
    CELL = _CELL
    STACK = "Stack"
    TABLE = "Table"

    # The model has only one cell.
    ONE_CELL = CELL, STACK

    # model type
    MODEL_TYPE_LIST = BOX, CELL, STACK, TABLE
    MODEL_TYPE_DICT = {
        gk.TYPE_BOX:  BOX,
        gk.TYPE_CELL: CELL,
        gk.TYPE_STACK: STACK,
        gk.TYPE_TABLE: TABLE
    }


class ModelList:
    """
    Are key used by the ModelList value dict. Import as 'ml'.
    """
    MODEL_DEF = 'model_def'
    OFFLINE = 'offline'
    ONLINE = 'online'

    # indices for the ModelList's 'self._items'
    NAME_INDEX, TYPE_INDEX = 0, 1


md = Model


class Node:
    """
    Are used to identify a Node. Import as 'ny'.
    """
    CANVAS = _CANVAS
    CELL = _CELL
    EXTRA = _EXTRA
    FACE = _FACE
    GROUP = "Group"

    # SuperPreset
    SHADOW = _SHADOW
    STEPS = "Steps"


ny = Node


class Option:
    """
    Each is a key for a Widget option or a vote cast.

    A descriptor with a comma makes the key unique, and a typical
    label will only display the string before the comma.

    An underline in a key value is the signature of a cast key. A cast
    key is not a Widget key but is used for casting an AnyGroup vote.

    Import as 'ok'.
    """
    ADD_OFFSET_X = "Add Offset X"
    ADD_OFFSET_Y = "Add Offset Y"
    AMPLITUDE = "Amplitude"
    ANGLE = "Angle"
    ANGLE_JITTER = "Angle Jitter"
    ANGLE_SHIFT = "Angle Shift"
    AS_LAYERS = "Decompose As Layers"
    AUTOCROP = "Auto-Crop"
    AZIMUTH = "Light Azimuth"
    BACKDROP_BLUR = "Backdrop Blur"
    BBF = 'BBF'
    BACKDROP = "Backdrop"
    BACKDROP_STYLE = "Backdrop Style"
    BACKDROP_TYPE = "Backdrop Type"
    BEVEL_EDGE_W = "Bevel Edge Width"
    BFR = 'BFR'
    BLEND = "Blend"
    BLUR = "Blur"
    BLUR_BEHIND = "Blur Behind"
    BLUR_X = "Blur X"
    BLUR_Y = "Blur Y"
    BORDER = _BORDER
    BORDER_BLUR = "Border Blur"
    BORDER_W = "Border Width"
    BOTTOM_MARGIN = "Bottom, Margin"
    BOX_TYPE = "Box Type"
    BRR = 'BRR'
    BRUSH = "Brush"
    BRUSH_ANGLE = "Brush Angle"
    BRUSH_D = "Brush, D"
    BRUSH_HARDNESS = "Brush Hardness"
    BRUSH_SIZE = "Brush Size"
    BRUSH_SPACING = "Brush Spacing"
    BSR = 'BSR'
    BUMP = _BUMP
    BUMP_DEPTH = "Bump Depth"
    BUMP_TYPE = "Bump Type"
    CAMO_TYPE = "Camo Type"
    MSS = 'MSS'
    CELL_COUNT = "Cell Count"
    CELL_GAP = "Cell Gap"
    CELL_H = "Cell Height"
    CELL_SHAPE = _CELL_SHAPE
    CELL_SIZE = "Cell Size"
    CELL_W = "Cell Width"
    CER = 'CER'
    CFW = "Canvas Frame Width"
    CIRCLE_DIAMETER = "Circle Diameter"
    CLIP_TO_CELL = "Clip to Cell"

    # Color options have a naming scheme.
    # "Color", number of colors, with alpha 'A'
    COLOR_1 = "Color, 1"
    COLOR_1A = "Color, 1A"
    COLOR_2A = "Color, 2A"
    COLOR_3A = "Color, 3A"
    COLOR_6 = "Color, 6"
    COLOR_6A = "Color, 6A"

    COLOR_COUNT = "Color Count"
    COLOR_GRID_TYPE = "Color Grid Type"
    CIR = 'CIR'
    COLORIZE = "Colorize"
    COLORIZE_OPACITY = "Colorize Opacity"
    COLUMN = "Column"
    COLUMN_1 = "Column #1"
    COLUMN_2 = "Column #2"
    COLUMN_COUNT = "Column Count"
    COLUMN_SLICE = "Column Slice Count"
    COLUMN_W = "Column Width"
    COMPONENT = "Color Component"
    CONTRACT = "Contract"
    CONTRAST = "Contrast"
    CORNER_SHIFT = "Corner Shift"
    COVER = "Cover"
    CRITERION = "Criterion"
    CROP_H = "Crop Height"
    CROP_W = "Crop Width"
    CROP_X = "Crop Offset X"
    CROP_Y = "Crop Offset Y"
    CURVE = "Curve"
    DELETE_PLAN = "Delete the Plan folder on exit."
    DEPTH = "Depth"
    DIAGONAL_ROTATION = "Diagonal Rotation"
    DISTRESS_THRESHOLD = "Threshold, Distress"
    ECS = "Equilateral Cell Shape"
    EDGE_MODE = "Edge Mode"
    EDGE_TYPE = "Edge Type"
    ELEVATION = "Elevation"
    EMBOSS = "Emboss"
    END_X = "End X"
    END_Y = "End Y"
    FIW = "Factor of Image Width"
    FCI = "First Cell Indented"
    FCR = 'FCR'
    FEATHER = "Feather"
    FIH = "Factor of Image Height"
    FILE = "File"
    FILL_MODE = "Fill Paint Mode"
    FILL_OPACITY = "Fill Opacity"
    FILLED = "Filled Cell"
    FILTER = "Filter"
    FIT_IMAGE = "Fit image to render"
    FIXED_SIZE_H = "Fixed Size Height"
    FIXED_SIZE_W = "Fixed Size Width"
    FLIP_R = 'flip r'
    FLIP_H = "Flip Horizontal"
    FLIP_V = "Flip Vertical"
    FNR = 'FNR'
    FOLDER = "Folder"
    FOLDER_ORDER = "Folder Order"
    FONT = "Font"
    FONT_SIZE = "Font Size"
    FRAME = "Frame"
    FRAME_METAL = "Frame, Metal"
    FRAME_MODE = "Frame Mode"
    FRAME_OVER = "Frame, Over"
    FRAME_STYLE = "Frame Style"
    FSM = "Frame Style Mode"
    FRAME_TYPE = "Frame Type"
    FRAME_W = "Frame Width"
    FRINGE = _FRINGE
    GAP_TYPE = "Gap Type"
    GAP_W = "Gap Width"
    GBR = 'GBR'
    GLASS_PANE_W = "Glass Pane Width"
    GRADIENT = "Gradient"
    GRADIENT_ANGLE = "Gradient Angle"
    GRADIENT_DIRECTION = "Gradient Direction"
    GRADIENT_MODE = "Gradient Mode"
    GRADIENT_OPACITY = "Gradient Opacity"
    GBRW = 'GBRW'
    GRADIENT_TYPE = "Gradient Type"
    GREY_SCALE = "Grey Scale"
    GRID_SIZE = "Grid Size"
    GRID_TYPE = "Grid Type"
    HEIGHT_CLIP = "Height, Clip"
    HEIGHT_MOD = "Height Mod"
    HORZ_COUNT = "Horizontal Count"
    HORZ_SCALE = "Horizontal Scale"
    IBR = 'IBR'
    IFR = 'IFR'
    IKR = 'IKR'
    IMAGE = _IMAGE
    IMAGE_CHOICE = "Image, Choice"
    IMAGE_NAME = "Image Name"
    IRRW = 'IRRW'
    IMAGE_SOURCE = "Image Source"
    INFLUENCE = "Influence"
    IGR = 'IGR'
    INNER_BLUR = "Inner Blur"
    INNER_FRAME_W = "Inner Frame Width"
    INTENSITY = "Intensity"
    INVERT = "Invert"
    IFRW = 'IFRW'
    IPR = 'IPR'
    IRK = 'IRK'
    IRR = 'IRR'
    IS_BACK = 'is_back'
    IS_CHAIN = 'is_chain'
    IS_EMBOSS = 'is_emboss'
    IS_MAIN = 'is_main'
    IS_NEW = 'is_new'
    IS_PLANNED = 'is_planned'
    IS_ROTATE = 'is_rotate'
    IS_SEED = 'is_seed'
    ITERATIONS = "Iterations"
    JITTER_H = "Jitter Height"
    JITTER_W = "Jitter Width"
    JITTER_X = "Jitter X"
    JITTER_Y = "Jitter Y"
    JUSTIFICATION = "Justification"
    KEEP_GRADIENT = "Keep the Gradient"
    LAYER_COUNT = "Layer Count"
    LAYER_ORDER = "Layer Order"
    LEAD = 'lead'
    LEFT_MARGIN = "Left, Margin"
    LENGTH_SHIFT = "Length Shift"
    LINE_W = "Line Width"
    LOCKED = "Locked Aspect Ratio"
    LOOP_X = "Loop Index"
    LTR = 'LTR'
    MARGIN = "Margin"
    MASK = _MASK
    MBF = 'MBF'
    MASK_TYPE = "Mask Type"
    MAZE_DIRECTION = "Maze Rotation Direction"
    MAZE_TYPE = "Maze Type"
    MESH_SIZE = "Mesh Size"
    MESH_TYPE = "Mesh Type"
    METAL = "Metal"
    MODE = "Paint Mode"
    MODEL_LIST = "Model List"
    MODEL_TYPE = 'model type'
    MRR = 'MRR'
    NAME = "Name"
    NEATNESS = "Neatness"
    NET_LINE_W = "Net Line Width"
    NEXT_X = "Next Index"
    NLS = "Net Line Spacing"
    NODE = 'node'
    NOISE = "Noise"
    NOISE_AMOUNT = "Noise Amount"
    NOISE_D = "Noise, Preset"
    NOISE_OPACITY = "Noise Opacity"
    NOISE_TYPE = "Noise Type"
    NSR = 'NSR'
    NUMERIC_SEQUENCE = "Numeric Sequence"
    OBEY_MARGINS = "Obey Margins"
    OCR = 'OCR'
    OFFSET = "Offset"
    OFFSET_X = "Offset X"
    OFFSET_Y = "Offset Y"
    OPACITY = "Opacity"
    OTHER = "Other"
    PATTERN = "Pattern"
    PATTERN_1 = "Pattern #1"
    PATTERN_2 = "Pattern #2"
    PATTERN_3 = "Pattern #3"
    P3R = 'P3R'
    PATTERN_SIZE = "Pattern Size"
    PBR = 'PBR'
    PER_CELL = "Per Cell"
    PLANNER = "Planner"
    PIN_CORNER = "Pin Corner"
    PLAQUE = _PLAQUE
    PNR = 'PNR'
    POSITION_X = "Position X"
    POSITION_Y = "Position Y"
    POST_BLUR = "Post Blur"
    POWER = "Noise Power"
    PRESET = _PRESET
    PREVIEW_MODE = "Preview Mode"
    PREVIOUS_X = "Previous Index"
    PROFILE = "Profile"
    RANDOM_ORDER = "Random Order"
    RENAME_MODEL = "Rename Model"
    RENDER_H = "Render Height"
    RENDER_W = "Render Width"
    RESIZE = _RESIZE
    RESIZE_TYPE = "Resize Method Type"
    REVERSE = "Reverse"
    RIGHT_MARGIN = "Right, Margin"
    ROTATION = "Rotation"
    ROW = "Row"
    ROW_COUNT = "Row Count"
    ROW_H = "Row Height"
    ROW_SLICE = "Row Slice Count"
    SAMPLE_POINTS = "Sample Points"
    SAMPLE_RADIUS = "Sample Radius"
    SAMPLE_VECTOR = "Sample Vector"
    SATURATION = "Saturation"
    SCATTER_COUNT = "Scatter Count"
    SEED = "Random Seed"
    SHADOW = "Shadow"
    SHADOW_BLUR = "Shadow Blur"
    SHADOW_COLOR = "Shadow Color"
    SHAPE_BURST = "Shape Burst"
    SHIFT_DIRECTION = "Shift Direction"
    SHIFT_GEGL = "Shift, GEGL"
    SKETCH_TEXTURE = "Sketch Texture"
    SLICE = "Slice"
    SLICE_COUNT = "Slice Count"
    SLICE_ORDER = "Slice Order"
    SMOOTHNESS = "Smoothness"
    SOFTEN = "Soften"
    SPECK_NOISE = "Speck Noise"
    SPIRAL_DISTANCE = "Spiral Distance"
    SPIRAL_MOD = "Spiral Mod"
    SPREAD = "Spread"
    SPREAD_DISTRESS = "Spread, Distress"
    SQUARE_DIMENSION = "Square Dimension"
    SRR = 'SRR'
    START_NUMBER = "Start Number"
    START_X = "Start X"
    START_Y = "Start Y"
    START_ANGLE = "Start Angle"
    STEPS = "Steps"
    STEPS_DROP_ZONE = "Steps, Drop Zone"
    STOP_LENGTH = "Stop Length"
    STRIPE = "Stripe"
    STRIPE_H = "Height, Stripe"
    SUPERPIXEL_SIZE = "Superpixel Size"
    SWITCH = _SWITCH
    TAPE_LENGTH = "Tape Length"
    TAPE_W = "Tape Width"
    TEXT = "Text"
    TEXTURE = "Texture"
    TILE_SIZE = "Tile Size"
    THRESHOLD = "Threshold"
    TOP_MARGIN = "Top, Margin"
    TRAIL = 'trail'
    TRANSLUCENT = "Translucent"
    TRIM = "Trimmed Side"
    TYPE_DECO = "Type, Deco"
    UNSHARP_AMOUNT = "Unsharp Amount"
    UNSHARP_RADIUS = "Unsharp Radius"
    UNSHARP_THRESHOLD = "Unsharp Threshold"
    USE_PLASMA = "Use Plasma"
    VERT_COUNT = "Vertical Count"
    VERT_SCALE = "Vertical Scale"
    WAVE_AMPLITUDE = "Wave Amplitude"
    WAVE_PER_LAYER = "Waves Per Layer"
    WAVE_PHASE = "Wave Phase"
    WAVELENGTH = "Wavelength"
    WHIRL = "Whirl"
    WIDTH = "Width"
    WIDTH_CLIP = "Width, Clip"
    WIDTH_MOD = "Width Mod"
    WIP = "Work in Progress"
    WIRE_THICKNESS = "Wire Thickness"


class Pickle:
    """Has keys used with Pickle. Import as 'pc'."""
    DATA = 'data'
    FILE = 'file'
    SHOW_ERROR = 'show_error'


class Plan:
    """Has keys used by Plan activity. Import as 'ak'."""
    BORDER = _BORDER
    CAPTION = _CAPTION
    CELL_SHAPE = _CELL_SHAPE
    CORNER = "Corner"
    DIMENSION = "Dimension"
    FRINGE = _FRINGE
    GRID = "Grid"
    IMAGE = _IMAGE
    MARGIN = _MARGIN
    NAME = "Name"
    PLAQUE = _PLAQUE
    POSITION = "Position"
    RATIO = "Ratio"
    KEY = (
        BORDER,
        CAPTION,
        CELL_SHAPE,
        CORNER,
        DIMENSION,
        FRINGE,
        GRID,
        IMAGE,
        MARGIN,
        NAME,
        PLAQUE,
        POSITION,
        RATIO
    )


class Preset:
    """Has keys used to initialize a Preset. Import as 'pk'."""
    DEFAULT = "Default"
    DELETE = "Delete"
    SAVE = "Save"


class Render:
    """Are keys used by a Render. Import as 'rd'."""
    PLAN = 'plan'
    WORK = 'work'


class Step:
    """Has keys used by option groups. Import as 'sk'."""
    STEPS = ()
    SELECTED_ROW = 'selected_row'
    BACKDROP = gk.BACKDROP,
    EXTRA = ny.EXTRA,
    GLOBAL = gk.GLOBAL,
    GRADIENT_LIGHT = gk.GRADIENT_LIGHT,
    MODEL = EXTRA + (gk.MODEL,)
    PRESET_STEPS = gk.PRESET,
    DEFAULT_STEP = [
        STEPS,
        GLOBAL,
        GRADIENT_LIGHT,
        BACKDROP,
        EXTRA,
        MODEL,
        PRESET_STEPS
    ]

    # Group key to Step key
    GROUP_2_STEP_D = {
        gk.BACKDROP: BACKDROP,
        gk.GLOBAL: GLOBAL,
        gk.GRADIENT_LIGHT: GRADIENT_LIGHT,
        gk.MODEL: MODEL
    }

    # Shadow
    SHADOW_SWITCH = ny.SHADOW, gk.SWITCH
    SHADOW = _SHADOW,
    SHADOW_PRESET = ny.SHADOW, gk.PRESET
    SHADOW_1 = ny.SHADOW, gk.SHADOW_1
    SHADOW_2 = ny.SHADOW, gk.SHADOW_2
    INNER_SHADOW = ny.SHADOW, gk.INNER_SHADOW

    # Model_____________________________________________________________
    # Box
    BOX_CANVAS = EXTRA + (md.BOX, _CANVAS)
    BOX_CANVAS_BORDER = BOX_CANVAS + (_BORDER,)
    BOX_CANVAS_CAPTION = BOX_CANVAS + (_CAPTION,)
    BOX_CANVAS_FRINGE = BOX_CANVAS + (_FRINGE,)
    BOX_CANVAS_IMAGE = BOX_CANVAS + (_IMAGE,)
    BOX_CANVAS_MARGIN = BOX_CANVAS + (_MARGIN,)
    BOX_CANVAS_PLAQUE = BOX_CANVAS + (_PLAQUE,)
    BOX_CANVAS_SHIFT = BOX_CANVAS + (_SHIFT,)
    BOX_CELL = EXTRA + (md.BOX, _CELL)
    BOX_CELL_BORDER = BOX_CELL + (_BORDER,)
    BOX_CELL_CAPTION = BOX_CELL + (_CAPTION,)
    BOX_CELL_FRINGE = BOX_CELL + (_FRINGE,)
    BOX_CELL_IMAGE = BOX_CELL + (_IMAGE,)
    BOX_CELL_MARGIN = BOX_CELL + (_MARGIN,)
    BOX_CELL_PLAQUE = BOX_CELL + (_PLAQUE,)
    BOX_CELL_SHIFT = BOX_CELL + (_SHIFT,)
    BOX_CELL_TYPE = BOX_CELL + (_TYPE,)
    BOX_FACE = EXTRA + (md.BOX, _FACE)
    BOX_FACE_BORDER = BOX_FACE + (_BORDER,)
    BOX_FACE_CAPTION = BOX_FACE + (_CAPTION,)
    BOX_FACE_FRINGE = BOX_FACE + (_FRINGE,)
    BOX_FACE_IMAGE = BOX_FACE + (_IMAGE,)
    BOX_FACE_PLAQUE = BOX_FACE + (_PLAQUE,)
    PER_CELL_BOX = (
        BOX_CELL_BORDER,
        BOX_CELL_CAPTION,
        BOX_CELL_FRINGE,
        BOX_CELL_IMAGE,
        BOX_CELL_MARGIN,
        BOX_CELL_PLAQUE,
        BOX_CELL_SHIFT,
        BOX_FACE_BORDER,
        BOX_FACE_CAPTION,
        BOX_FACE_FRINGE,
        BOX_FACE_IMAGE,
        BOX_FACE_PLAQUE,
    )

    # Cell
    CELL_CELL = EXTRA + (md.CELL, _CELL)
    CELL_CELL_BORDER = CELL_CELL + (_BORDER,)
    CELL_CELL_CAPTION = CELL_CELL + (_CAPTION,)
    CELL_CELL_FRINGE = CELL_CELL + (_FRINGE,)
    CELL_CELL_IMAGE = CELL_CELL + (_IMAGE,)
    CELL_CELL_MARGIN = CELL_CELL + (_MARGIN,)
    CELL_CELL_PLAQUE = CELL_CELL + (_PLAQUE,)
    CELL_CELL_SHIFT = CELL_CELL + (_SHIFT,)

    # Stack
    STACK_CELL = EXTRA + (md.STACK, _CELL)
    STACK_CELL_BORDER = STACK_CELL + (_BORDER,)
    STACK_CELL_CAPTION = STACK_CELL + (_CAPTION,)
    STACK_CELL_FRINGE = STACK_CELL + (_FRINGE,)
    STACK_CELL_IMAGE = STACK_CELL + (_IMAGE,)
    STACK_CELL_MARGIN = STACK_CELL + (_MARGIN,)
    STACK_CELL_PLAQUE = STACK_CELL + (_PLAQUE,)
    STACK_CELL_SHIFT = STACK_CELL + (_SHIFT,)
    PER_CELL_STACK = (
        STACK_CELL_BORDER,
        STACK_CELL_CAPTION,
        STACK_CELL_FRINGE,
        STACK_CELL_IMAGE,
        STACK_CELL_PLAQUE,
        STACK_CELL_MARGIN,
        STACK_CELL_SHIFT
    )

    # Table
    TABLE_CANVAS = EXTRA + (md.TABLE, _CANVAS)
    TABLE_CANVAS_BORDER = TABLE_CANVAS + (_BORDER,)
    TABLE_CANVAS_CAPTION = TABLE_CANVAS + (_CAPTION,)
    TABLE_CANVAS_FRINGE = TABLE_CANVAS + (_FRINGE,)
    TABLE_CANVAS_IMAGE = TABLE_CANVAS + (_IMAGE,)
    TABLE_CANVAS_MARGIN = TABLE_CANVAS + (_MARGIN,)
    TABLE_CANVAS_PLAQUE = TABLE_CANVAS + (_PLAQUE,)
    TABLE_CANVAS_SHIFT = TABLE_CANVAS + (_SHIFT,)
    TABLE_CELL = EXTRA + (md.TABLE, _CELL)
    TABLE_CELL_BORDER = TABLE_CELL + (_BORDER,)
    TABLE_CELL_CAPTION = TABLE_CELL + (_CAPTION,)
    TABLE_CELL_FRINGE = TABLE_CELL + (_FRINGE,)
    TABLE_CELL_IMAGE = TABLE_CELL + (_IMAGE,)
    TABLE_CELL_PLAQUE = TABLE_CELL + (_PLAQUE,)
    TABLE_CELL_MARGIN = TABLE_CELL + (_MARGIN,)
    TABLE_CELL_SHIFT = TABLE_CELL + (_SHIFT,)
    TABLE_CELL_TYPE = TABLE_CELL + (_TYPE,)
    PER_CELL_TABLE = (
        TABLE_CELL_BORDER,
        TABLE_CELL_CAPTION,
        TABLE_CELL_FRINGE,
        TABLE_CELL_IMAGE,
        TABLE_CELL_PLAQUE,
        TABLE_CELL_MARGIN,
        TABLE_CELL_SHIFT,
        TABLE_CELL_TYPE         # no layer output to undo
    )

    # Identify AnyGroup with a visible Per Cell option.
    PER_CELL_GROUP = PER_CELL_TABLE + PER_CELL_STACK + PER_CELL_BOX

    # Identify a Per Cell step for its undo.
    # the negative count of no layer output, '-1'
    PER_CELL_MODEL = PER_CELL_TABLE[:-1] + PER_CELL_STACK + PER_CELL_BOX

    MARGIN_DEPENDENT = _BORDER, _CAPTION, _FRINGE, _IMAGE, _PLAQUE
    MERGE_DEPENDENT = MARGIN_DEPENDENT + (_MARGIN,)
    # ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

    # Cell branch
    CELL_MARGIN = _CELL, _MARGIN
    CELL_SHIFT = _CELL, _SHIFT
    CELL_TYPE = _CELL, _TYPE

    # for Deco AnyGroup___________________________________________________
    # Use with PerCellGroup to clear the Per Cell option on a Preset load.
    # Each item is a render key step that has a hidden Per Cell option.
    NO_PER_CELL = (
        BOX_CANVAS_BORDER,
        BOX_CANVAS_CAPTION,
        BOX_CANVAS_FRINGE,
        BOX_CANVAS_IMAGE,
        BOX_CANVAS_MARGIN,
        BOX_CANVAS_PLAQUE,
        BOX_CANVAS_SHIFT,
        CELL_CELL_BORDER,
        CELL_CELL_CAPTION,
        CELL_CELL_FRINGE,
        CELL_CELL_IMAGE,
        CELL_CELL_MARGIN,
        CELL_CELL_SHIFT,
        CELL_CELL_PLAQUE,
        TABLE_CANVAS_BORDER,
        TABLE_CANVAS_CAPTION,
        TABLE_CANVAS_FRINGE,
        TABLE_CANVAS_IMAGE,
        TABLE_CANVAS_MARGIN,
        TABLE_CANVAS_PLAQUE,
        TABLE_CANVAS_SHIFT
    )
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


class Widget:
    """
    Has key used to initialize a Widget. A key descriptor
    may become a Widget attribute, hence the underline. Import as 'wk'.
    """
    # tuple of float
    # in .0 to 1.
    # a factor of the space to assign
    # for top, bottom, left, right
    ALIGN = 'align'

    # AnyGroup
    # Use to connect widgets with other widget in their group.
    ANY_GROUP = 'any_group'

    # string
    # Identify the render scale axis as either 'x' or 'y'
    # for RenderPair
    AXIS = 'axis'

    # of gtk.Box classes
    BOX = 'box'

    # int
    # Use with the Rainbow Widget.
    # Is the number of ColorButtons in the Rainbow Widget.
    BUTTON_COUNT = 'button_count'

    # a 2D list from Cell Table to its SwitchButton
    CELL_TABLE = 'cell_table'

    # None value
    # Is a flag to identify an option as not having change.
    # Use to screen out an option's change checker.
    CHANGELESS = 'changeless'

    # Use with Entry's string length allocation.
    CHARS = 'chars'

    # string
    # Use with the Choice Window.
    CHOICE = 'choice'

    # int
    # for Event boxes
    COLOR = 'color'

    # int
    # a Node's cubby index
    COLUMN = 'column'

    # string
    # for a Widget Table
    # Is a label string for the left-side of a Table.
    COLUMN_TEXT = 'column_text'

    # GTK container
    CONTAINER = 'container'

    # class
    # type of Window
    DIALOG = 'dialog'

    # Call to get a value for a Widget range.
    FUNCTION = 'function'

    # Is Widget with the proper get_a and set_a function.
    GREATER_G = 'greater_g'

    # GTK Window or Dialog
    GTK_WIN = 'gtk_win'

    # iterable
    # Use with Row.
    KEYS = 'keys'

    # boolean
    # for ColorButton
    # When its true, the ColorButton has an alpha value.
    HAS_ALPHA = 'has_alpha'

    # boolean
    # When True, an AnyGroup has a Randomize button.
    HAS_RANDOM = 'has_random'

    # boolean
    # When True, an AnyGroup has a Preset button.
    HAS_PRESET = 'has_preset'

    # boolean
    # Use to change Item behavior when a Label
    # is not needed for a switchable Preset.
    HAS_SWITCH = 'has_switch'

    # string
    # Is an optional header for a TreeViewList.
    HEADER = 'header'

    # undefined
    # If present in a Widget init argument dict, then
    # AnyGroup will load the group's default dict.
    IS_DEFAULT = 'is_default'

    # undefined
    # Pass to AnyGroup to have it skip widget creation.
    IS_NONE = 'is_none'

    # string
    # Identify layer dependency type.
    ISSUE = 'issue'

    # Item
    # Pass to Node to populate its list.
    ITEM = 'item'

    # string
    # option group
    KEY = 'key'

    # int
    # Use when creating a RadioButton.
    LABEL_X = 'label_x'

    # tuple
    # low, high
    # limit self value range of a Slider
    LIMIT = 'limit'

    # int
    # Set the minimum width of a TreeViewList column.
    MINIMUM_W = 'minimum_w'

    # function
    # a callback for an Accept Button
    ON_ACCEPT = 'on_accept'

    # function
    # a callback for a Cancel Button
    ON_CANCEL = 'on_cancel'

    # tuple
    # Alignment padding
    PADDING = 'padding'

    # numeric value
    # Use with Slider to initialize the GTK Adjustment.
    PAGE_INCR = 'page_incr'

    # int
    # number of digits after the decimal point
    # Is zero for an integer.
    PRECISION = 'precision'

    # RadioButton
    # Is used to define the lead
    # RadioButton for a group of RadioButtons.
    RADIO_GROUP = 'radio_group'

    # tuple
    # Define a random-function limitation.
    RANDOM = 'random'

    # tuple
    # (row, column) cell index
    R_C = 'r_c'

    # list of function
    # Is in the order change callback.
    RELAY = 'relay'

    # tuple
    # Use to configure option view.
    RENDER_KEY = 'render_key'

    # Window class instance
    ROLLER_WIN = 'roller_win'

    # string
    # Is a key for an sub-dict in a Preset.
    ROW_KEY = 'row_key'

    # undefined
    # Pass to a TreeViewList to have it make a scrolled window.
    SCROLL = 'scroll'

    # custom Widget Signal
    # Use to pass a custom signal to a Widget.
    SIGNAL = 'signal'

    # numeric value
    # Use with Slider to initialize the GTK SpinButton.
    STEP_INCR = 'step_incr'

    # tuple
    # Use to id an AnyGroup.
    STEP_KEY = 'step_key'

    # Widget definition group
    SUB = 'sub'

    # string
    # for CheckButton, Label
    TEXT = 'text'

    # function
    # Use to make a tooltip.
    TIPPER = 'tipper'

    # tuple
    # Use to set multiple tooltips.
    TIPS = 'tips'

    # string
    # for a tooltip
    TOOLTIP = 'tooltip'

    # color
    # Use to set the background color of a TreeView.
    TREE_COLOR = 'tree_color'

    # value
    # Use with the AnyGroup definition dict.
    VAL = 'val'

    # Set a Widget class.
    WIDGET = 'widget'

    # string
    # Use to pass a Window's key for storage in the Window position dict.
    WINDOW_KEY = 'window_key'

    # Use when initializing a Widget-type
    # to set a Widget attribute.
    ATTRIBUTE = (
        ALIGN,
        ANY_GROUP,
        COLUMN,
        DIALOG,
        FUNCTION,
        KEY,
        RANDOM,
        ROLLER_WIN,
        ROW_KEY,
        STEP_KEY,
        TEXT
    )
