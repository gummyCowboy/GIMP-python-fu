#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one_fu import Lay, Mage, Sel, get_background
from roller_view_hub import calc_rotated_image_span, do_gradient_job
import gimpfu as fu
import math

COLOR = 'color'
FILLER = 'filler'
INNER = 'inner'
LIGHT = 'light'
SHADOW = 'shadow'
SHADOW1 = 'shadow1'
SHADOW2 = 'shadow2'
pdb = fu.pdb


def add_base_layer(v, group, n="Base"):
    """
    Add a layer at the bottom of its group.

    v: View
    group: layer group
        parent of new layer

    n: string
        appendix for layer name

    Return: layer
        newly added
    """
    return Lay.add(
        v.j, group.name + " " + n, offset=len(group.layers), parent=group
    )


def add_matter_group(v, maya, group):
    """
    Add a layer at the bottom of its group.

    v: View
    group: layer group
        parent of new layer

    n: string
        appendix for layer name

    Return: layer
        newly added
    """
    return Lay.group(
        v.j,
        group.name + " Material",
        offset=len(group.layers) - get_blur_behind(maya),
        parent=group
    )


def add_matter_layer(v, maya, group):
    """
    Add a layer at the bottom of its group.

    v: View
    group: layer group
        parent of new layer

    n: string
        appendix for layer name

    Return: layer
        newly added
    """
    return Lay.add(
        v.j,
        group.name + " Material",
        offset=len(group.layers) - get_blur_behind(maya),
        parent=group
    )


def add_sub_base_group(v, maya, z=None):
    """
    Add a group layer to the top of the Maya group.

    v: View
    maya: Maya
    z: layer
        to move to the group

    Return: layer group
        newly added
    """
    return Lay.group(
        v.j,
        maya.any_group.item.key + " WIP",
        parent=maya.group,
        offset=len(maya.group.layers),
        z=z
    )


def add_top_layer(v, maya, n):
    """
    Add a layer at the top of its group, but below the Gradient Light layer.

    v: View
    maya: Maya
    n: string
        layer name appendix

    Return: layer
        newly added
    """
    return Lay.add(
        v.j,
        maya.group.name + " " + n,
        parent=maya.group,
        offset=get_light(maya)
    )


def add_wip_base(v, maya, n, group):
    """
    Insert a new empty WIP layer at the bottom of a layer group.

    v: View
    maya: Maya
    n: string
        layer name appendix

    Return: layer
        newly added
    """
    return add_wip_layer(v, maya, n, group=group, offset=len(group.layers))


def add_wip_below(v, z, n=""):
    """
    Insert a new empty layer below an existing layer.

    z: layer
        target of insertion

    n: string or None
        When true, the layer is named.

    Return: layer
        newly added
    """
    return add_wip_layer(
        v, z.image, n, group=z.parent, offset=Lay.offset(z) + 1
    )


def add_wip_layer(v, maya, n, group=None, offset=0):
    """
    Make a group layer. Is not for layer palette trunk,
    but is for layer palette branch.

    v: View
    maya: Maya
    n: string
        layer name appendix

    group: layer group or GIMP image
    offset: int
        position the layer

    Return: layer
        as requested
    """
    if not group:
        group = maya.group

    z = pdb.gimp_layer_new(
        v.j,
        v.wip.w, v.wip.h,
        fu.RGBA_IMAGE,
        group.name + " " + n,
        100.,                       # opacity
        fu.LAYER_MODE_NORMAL
    )

    pdb.gimp_layer_set_offsets(z, *v.wip.position)
    pdb.gimp_image_insert_layer(v.j, z, group, offset)
    return z


def clip_to_view(v, z):
    """
    Transform a view sized layer to WIP sized layer.
    Clip the content to the WIP layer bounds.
    """
    j = z.image
    x, y = z.offsets
    pdb.gimp_layer_resize(z, j.width, j.height, x, y)


def clip_to_wip(v, z):
    """
    Transform a view sized layer to WIP sized layer.
    Clip the content to the WIP layer bounds.
    """
    if v.wip.x:
        isolate_wip_rect(v, z)
        x, y = z.offsets
        pdb.gimp_layer_resize(
            z, v.wip.w, v.wip.h, x - v.wip.x, y - v.wip.y
        )


def clone_background(v, z, n="BG Copy", is_hide=True, on_top=False):
    """
    Make a copy of the visible background material below
    a layer. Insert the copy below the layer.

    v: View
    z: layer
        work-in-progress

    n: string
        layer name of clone

    is_hide: bool
        If true, the top layer, 'z', is not visible.

    on_top: bool
        If True, the the clone layer is inserted above layer 'z'.

    Return: layer
        the copy of the background
    """
    z1 = get_background(z, n, is_hide=is_hide)
    x = 0 if on_top else 1

    # Insert the layer below layer 'z'.
    pdb.gimp_image_insert_layer(z.image, z1, z.parent, Lay.offset(z) + x)
    clip_to_wip(v, z1)
    return z1


def do_gradient_for_layer(v, d, group, offset):
    """
    Do Gradient Fill on a layer.

    d: dict
        GradientFill Preset

    group: layer group
        destination of layer

    offset: int
        in destination layer group

    Return: layer
        with gradient material
    """
    return do_rotated_layer(v, d, do_gradient_job, group, offset)


def do_rotated_layer(v, d, p, group, offset):
    """
    Create an enlarged layer before rotating.
    Use a callback to process the rotated layer.

    v: View
    d: dict
        Has options.

    p: callback
        Call to act on the rotated layer before it is returned.

    group: layer
        output destination group

    offset: int
        output position in destination group

    Return: layer
        the rotated layer
    """
    j = group.image
    w, h = v.wip.size

    if d[ok.ANGLE]:
        # Create a new image for the rotation.
        f = calc_rotated_image_span(w, h)
        j1 = pdb.gimp_image_new(f, f, fu.RGB)
        z = Lay.add(j1, "Rotate")

    else:
        j1 = pdb.gimp_image_new(w, h, fu.RGB)
        z = Lay.add(j1, "Rotate")

    z = p(z, d)

    if d[ok.ANGLE]:
        Lay.rotate(z, d[ok.ANGLE])

    Mage.copy_all(j1)

    if not group.layers:
        # Need something to paste on top of.
        base = Lay.add(j, "Base", parent=group)

        z = Lay.paste(group.layers[offset])
        Lay.remove(base)

    else:
        z = Lay.paste(group.layers[offset])

    if d[ok.ANGLE]:
        pdb.gimp_layer_resize_to_image_size(z)
        clip_to_wip(v, z)

    pdb.gimp_image_delete(j1)
    return z


def finish_style(z, n):
    """
    Finish a Backdrop Style by giving the style
    layer a name, an opacity, and a paint mode.

    z: layer
        with material

    n: string
        Backdrop Style key

    Return: layer or None
        with material
    """
    if z:
        z.name = n
    return z


def get_blur_behind(maya):
    """
    Determine the offset for a Blur Behind layer possibility.

    maya: Maya
    Return: int
        Is the layer offset for inserting a layer
        into a parent group with a Color layer.
    """
    if ok.BLUR_BEHIND in maya.sub_maya:
        return int(bool(maya.sub_maya[ok.BLUR_BEHIND].blur_behind))
    return 0


def get_color(maya):
    """
    Determine the offset for a Color layer possibility.

    maya: Maya
    Return: int
        Is the layer offset for inserting a layer
        into a parent group with a Color layer.
    """
    return int(bool(maya.sub_maya[COLOR].matter))


def get_light(maya):
    """
    Determine the offset for a Gradient Light layer possibility.

    maya: Maya
    Return: int
        Is the layer offset for inserting a layer
        into a parent group with a Gradient Light layer.
    """
    if LIGHT in maya.sub_maya:
        return int(bool(maya.sub_maya[LIGHT].matter))
    return 0


def get_noise(maya):
    """
    Determine the offset for a Noise layer possibility.

    maya: Maya
    Return: int
        Is the layer offset for inserting a layer
        into a parent group with a Noise layer.
    """
    return int(bool(maya.sub_maya[ok.NOISE_D].matter))


def insert_copy(v, group, z, is_hide=False):
    """
    Insert a layer into a layer group.

    group: layer
        Is the destination.

    z: layer
        Has position to copy from.

    is_hide: bool
        If True, then the positional layer
        is hidden before making the background copy.

    Return: layer
        that was inserted
    """
    z1 = get_background(z, "Background Copy", is_hide=is_hide)

    pdb.gimp_image_insert_layer(z.image, z1, group, 0)
    clip_to_wip(v, z1)
    return z1


def get_point_on_edge(v, angle):
    """
    Calculate an x, y coordinate for a point intersecting
    a ray, originating from the center of a rectangle,
    and ending at a rectangle boundary.

    s: tuple or list
        size
        width, height
        of int

    angle: float
        degrees
        angle from center of the rectangle

    Return: point
        x, y of float
        the point on the rectangle
    """
    w, h = v.wip.size
    angle = math.radians(angle)
    sine = math.sin(angle)
    cosine = math.cos(angle)

    # distance to the top or the bottom edge (from the center)
    dy = h / 2. if sine > 0 else h / -2.

    # distance to the left or the right edge (from the center)
    dx = w / 2. if cosine > 0 else w / -2.

    # (distance to the vertical line) < (distance to the horizontal line)
    if abs(dx * sine) < abs(dy * cosine):
        # Calculate distance to the vertical line:
        dy = (dx * sine) / cosine

    # (distance to the top or the bottom edge)
    # < (distance to the left or the right edge)
    else:
        dx = (dy * cosine) / sine
    return round(dx + w / 2.) + v.wip.x, round(dy + h / 2.) + v.wip.y


def insert_copy_above(v, z, z1):
    """
    Insert a background copy above another layer.

    z: layer
        Insert the copy above this layer.

    z1: layer
        Has position to copy from.

    Return: layer
        that was inserted
    """
    z2 = get_background(z1, "Background Copy", is_hide=False)

    pdb.gimp_image_insert_layer(z.image, z2, z.parent, Lay.offset(z))
    clip_to_wip(v, z2)
    return z2


def isolate_wip_rect(v, z, keep_sel=False):
    """
    Clear out material not in the View rectangle.

    v: View
    z: layer
        with material to clear

    keep_sel: flag
        If true, the selection remains.
    """
    if v.wip.x:
        Sel.rect(v.j, *v.wip.rect)
        Sel.invert_clear(z, keep_sel=keep_sel)


def make_cast_group(v, maya):
    """
    Make a group layer for a step or a cell sub-step.

    v: View
    maya: Maya
    """
    if not maya.group:
        group = maya.model.create_branch(v, maya)
        maya.group = make_group(v, "Cast", group, offset=get_light(maya))
    return maya.group


def make_canvas_group(v, maya):
    """
    Make a group layer for a Canvas-branch step.

    v: View
    maya: Maya
    """
    if not maya.group:
        maya.group = maya.model.create_branch(v, maya)
    return maya.group


def make_group(v, n, parent, offset=0):
    """
    Make a group layer. Is not for layer palette trunk,
    but is for layer palette branch.

    v: View
    n: string
        layer name

    parent: layer group or GIMP image
    offset: int
        position the group
    Return: group layer
        as requested
    """
    if parent:
        n = parent.name + " " + n
    return Lay.group(v.j, n, parent=parent, offset=offset)


def mask_sub_maya(source_z, sub_z):
    """
    Make a mask for a sub-Maya matter layer.

    source_z: layer
        Is the layer with alpha material to make mask from.

    sub_z: layer or None
        Is the layer to receive the mask.

    Return: layer
        the mask
    """
    if sub_z:
        mode = None

        # Opacity doesn't change the selection.
        if source_z.mode != fu.LAYER_MODE_NORMAL:
            mode = source_z.mode
            Lay.set_mode(source_z, fu.LAYER_MODE_NORMAL)

        Sel.item(source_z, option=fu.CHANNEL_OP_REPLACE)
        mask_sel(sub_z)
        if mode is not None:
            source_z.mode = mode


def mask_sel(z):
    """
    Make a mask for a group from a selection.
    Call with a selection already in place.

    z: layer
        to receive mask
    """
    if z:
        Lay.discard_mask(z)
        if Sel.is_sel(z.image):
            z.add_mask(pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION))


def remove_layer(maya, n):
    """
    Remove a layer given its order attribute.
    Set its reference to None.

    maya: Maya
        Has attribute, 'n'.

    n: string
        layer attribute
    """
    Lay.remove_layers(getattr(maya, n))
    setattr(maya, n, None)
