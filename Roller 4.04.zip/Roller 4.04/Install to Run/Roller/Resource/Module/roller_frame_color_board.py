#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Lucid
from roller_one import Mode
from roller_one_fu import Lay, Sel
from roller_view_real import add_wip_layer, get_color, get_light
import gimpfu as fu

pdb = fu.pdb


def do_color(v, maya):
    """
    Make a color layer.

    v: View
    maya: Maya
    Return: layer
        with color
    """
    pdb.gimp_selection_none(v.j)

    d = maya.value_d
    a = maya.super_maya
    z = add_wip_layer(v, maya, "Color", group=a.group, offset=get_light(a))

    Lay.color_fill(z, d[ok.COLOR_1])
    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: ColorBoard
    Return: layer
        with the frame
    """
    j = v.j
    d = maya.value_d
    group = maya.group

    Sel.border(j, maya.cause.matter, d[ok.FRAME_W], d[ok.FRAME_TYPE])

    z = add_wip_layer(
        v,
        maya,
        "Color Board",
        group=group,
        offset=get_light(maya) + get_color(maya)
    )
    z.opacity = d[ok.OPACITY]
    z.mode = Mode.get_mode(d, k=ok.FRAME_MODE)

    Sel.fill(z, (127, 127, 127))
    return z


class ColorBoard(Lucid):
    """Create a an color edge around material."""

    def __init__(self, *q, **d):
        """
        q: tuple
            Lucid spec

        d: dict
            Lucid spec
        """
        Lucid.__init__(self, *q + (do_matter, do_color), **d)
