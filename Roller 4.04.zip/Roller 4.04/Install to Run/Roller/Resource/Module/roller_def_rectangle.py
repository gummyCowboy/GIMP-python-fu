#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import MAX_SIZE, Issue as vo
from roller_constant_key import Option as ok, Widget as wk
from roller_widget_number_pair import RectPair
from roller_def_share import set_issue

RECTANGLE = OrderedDict([
    (ok.POSITION_X, {
        wk.AXIS: 'x',
        wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
        wk.VAL: 0,
        wk.WIDGET: RectPair
    }),
    (ok.POSITION_Y, {
        wk.AXIS: 'y',
        wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
        wk.VAL: 0,
        wk.WIDGET: RectPair
    }),
    (ok.CELL_W, {
        wk.AXIS: 'x',
        wk.LIMIT: (0, MAX_SIZE),
        wk.VAL: (.0, 1.),
        wk.WIDGET: RectPair
    }),
    (ok.CELL_H, {
        wk.AXIS: 'y',
        wk.LIMIT: (0, MAX_SIZE),
        wk.VAL: (.0, 1.),
        wk.WIDGET: RectPair
    })
])
set_issue(RECTANGLE, (), vo.MATTER, ())
