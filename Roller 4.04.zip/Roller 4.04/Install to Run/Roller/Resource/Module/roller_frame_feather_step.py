#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import MaskGroup
from roller_one_fu import Lay, Sel
from roller_view_real import mask_sel
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Feather the cause material and make a group mask.

    Return: layer
        group mask
    """
    j = v.j
    group = maya.cause.group
    z = Lay.clone_opaque(maya.cause.matter)
    d = maya.value_d
    a = d[ok.FEATHER]
    f = float(a) / d[ok.STEPS]
    b = f

    while a > b:
        Sel.item(z)
        pdb.gimp_selection_feather(j, b)

        b = min(b + f, a)
        if Sel.is_sel(j):
            Sel.invert_clear(z)

    Sel.item(z)
    mask_sel(group)
    Lay.remove(z)
    return group.mask


class FeatherStep(MaskGroup):
    """Feather the edges of material."""

    def __init__(self, *q, **d):
        """
        q: tuple
            MaskGroup spec

        d: dict
            MaskGroup spec
        """
        MaskGroup.__init__(self, *q + (do_matter,), **d)
