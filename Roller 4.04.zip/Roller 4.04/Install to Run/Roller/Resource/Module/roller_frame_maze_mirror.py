#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame import Metal, make_canvas_frame_sel, soften_metal_sel
from roller_one_extract import combine_seed
from roller_one_fu import Lay, Sel
from roller_one_rect_table import RectTable
from roller_view_line_graph import LineGraph
from roller_view_real import isolate_wip_rect
import gimpfu as fu

pdb = fu.pdb


def do_border(v, d):
    """
    Draw a frame of mazes around the edge of canvas.

    v: View
    d: dict
        Maze Mirror Preset
    """
    for r in range(v.maze.row):
        select_maze(v, d, r, 0)
    for c in range(v.maze.column):
        select_maze(v, d, 0, c)


def do_fill(v, d):
    """
    Draw mazes that fill the frame layer.

    v: View
    d: dict
        Maze Mirror Preset
    """
    for r in range(v.maze.row):
        for c in range(v.maze.column):
            select_maze(v, d, r, c)


def draw_corner(v):
    """
    Flip the topleft-quarter selection into the other corners.

    v: View
        Has scope variable.

    Return: state of selection
    """
    j = v.j
    z = Lay.add(j, "Mirror")

    Sel.fill(z, (0, 0, 0))
    isolate_wip_rect(v, z)

    z = Lay.clone(z)

    Lay.flip(z, horizontal=True)

    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
    z = Lay.clone(z)

    Lay.flip(z)

    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    Sel.item(z)
    pdb.gimp_image_remove_layer(j, z)


def select_cc_maze(v, d, r, c):
    """
    Select a counter-clockwise configured maze.

    v: View
        Has scope variable.

    d: dict
        Maze Mirror Preset
        {Option key: value}

    r, c: int
        row, column
        maze position
    """
    line_length = [0, 0]
    line_w = d[ok.LINE_W]
    x, y = v.maze.table[r][c].position
    line_length[0], line_length[1] = v.maze.table[r][c].size
    x1, y1 = x, y
    w = h = 1
    is_down = True
    is_up = is_left = is_right = False
    x2 = 0 if is_left or is_right else 1
    while line_length[x2] - line_w > d[ok.STOP_LENGTH]:
        if is_down:
            x2 = 1
            w = line_w
            h = line_length[x2]

            # next line
            is_right = True
            is_down = False
            x1 = x
            y1 = y + line_length[x2]

        elif is_right:
            x2 = 0
            w = line_length[x2]
            h = line_w

            # next line
            is_up = True
            is_right = False
            x1 = x + line_length[x2] - line_w
            y1 = y

        elif is_up:
            x2 = 1
            w = line_w
            h = line_length[x2]
            y = y - line_length[x2]

            # next line
            is_up = False
            is_left = True
            x1 = x
            y1 = y

        elif is_left:
            x2 = 0
            w = line_length[x2]
            h = line_w
            x -= line_length[x2]

            # next line
            is_left = False
            is_down = True
            x1 = x
            y1 = y

        # Select the line.
        Sel.rect(v.j, x, y, w, h, option=fu.CHANNEL_OP_ADD)

        # next line
        line_length[x2] = int(line_length[x2] * .75)

        x, y = x1, y1
        x2 = int(not x2)
        line_length[x2] = int(line_length[x2] * .85)


def select_cw_maze(v, d, r, c):
    """
    Select a clockwise configured maze.

    v: View
    d: dict
        Maze Mirror Preset

    r, c: int
        row, column
        maze position
    """
    line_length = [0, 0]
    line_w = d[ok.LINE_W]
    x, y = v.maze.table[r][c].position
    line_length[0], line_length[1] = v.maze.table[r][c].size
    x1, y1 = x, y
    w = h = 1
    is_right = True
    is_up = is_left = is_down = False
    x2 = 0 if is_left or is_right else 1
    stop = d[ok.STOP_LENGTH]
    while line_length[x2] - line_w > stop:
        if is_down:
            x2 = 1
            w = line_w
            h = line_length[x2]

            # next line
            is_down = False
            is_left = True
            x1 = x
            y1 = y + line_length[x2] - line_w

        elif is_right:
            x2 = 0
            w = line_length[x2]
            h = line_w

            # next line
            is_right = False
            is_down = True
            x1 = x + line_length[x2]
            y1 = y

        elif is_up:
            x2 = 1
            w = line_w
            h = line_length[x2]
            y = y - line_length[x2]

            # next line
            is_up = False
            is_right = True
            x1 = x
            y1 = y

        elif is_left:
            x2 = 0
            w = line_length[x2]
            h = line_w
            x -= line_length[x2]

            # next line
            is_left = False
            is_up = True
            x1 = x
            y1 = y

        # Select the line.
        Sel.rect(v.j, x, y, w, h, option=fu.CHANNEL_OP_ADD)

        # next line
        line_length[x2] = int(line_length[x2] * .75)

        x, y = x1, y1
        x2 = int(not x2)
        line_length[x2] = int(line_length[x2] * .85)


def select_maze(v, d, r, c):
    """
    Select a maze.

    v: View
    d: dict
        Maze Mirror Preset

    r, c: int
        row, column
        the maze cell position
    """
    if d[ok.MAZE_DIRECTION] == ff.COUNTER_CLOCKWISE:
        select_cc_maze(v, d, r, c)
    else:
        select_cw_maze(v, d, r, c)


def scatter_connector(v, d):
    """
    Graph and select connectors randomly.

    v: View
    d: dict
        Maze Mirror Preset
    """
    a = v.maze
    connector = []
    row, column = a.row, a.column

    if not d[ok.GAP_TYPE]:
        # Random Gap Type
        # Try to get the connector to draw
        # so that it's not on the border.
        r1 = min(1, row - 1)
        c1 = min(1, column - 1)
        for _ in range(a.scatter):
            r = randint(r1, row - 1)
            c = randint(c1, column - 1)
            q = r, c

            while q in connector:
                r = randint(1, row)
                c = randint(1, column)
                q = r, c
            connector.append(q)

    else:
        # Evenly Distributed Gap Type
        r = c = 0
        r1, c1 = row - 1, column - 1
        for _ in range(a.scatter):
            c += d[ok.CELL_GAP]
            while c > c1:
                c -= max(1, c1)
                r += 1

            while r > r1:
                r -= max(1, r1)
            connector.append((r, c))
    for q in connector:
        r, c = q[0], q[1]
        if randint(0, 1):
            a.graph.add_line(
                (r, c),
                (r + 1, c),
                LineGraph.real
            )
        else:
            a.graph.add_line(
                (r, c),
                (r, c + 1),
                LineGraph.real
            )


def scatter_maze(v, d):
    """
    Graph amd select mazes randomly.

    v: View
    d: dict
        Maze Mirror Preset
    """
    a = v.maze
    maze_q = []
    row, column = a.row, a.column

    if d[ok.GAP_TYPE] == ff.RANDOM_TYPE:
        for _ in range(a.scatter):
            r = randint(0, row - 1)
            c = randint(0, column - 1)
            q = r, c

            while q in maze_q:
                r = randint(0, row - 1)
                c = randint(0, column - 1)
                q = r, c
            maze_q.append(q)

    else:
        r = c = 0
        for _ in range(a.scatter):
            c += d[ok.CELL_GAP]
            while c > column - 1:
                c -= max(1, column - 1)
                r += 1

            while r > row - 1:
                r -= max(1, row - 1)
            maze_q.append((r, c))

    for q in maze_q:
        r, c = q[0], q[1]

        select_maze(v, d, r, c)

        if d[ok.MAZE_DIRECTION] == ff.COUNTER_CLOCKWISE:
            a.graph.add_line((r, c), (r + 1, c), LineGraph.real)
        else:
            a.graph.add_line((r, c), (r, c + 1), LineGraph.real)


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: MazeMirror
    Return: layer
        with the frame
    """
    j = v.j
    d = maya.value_d
    e = d[ok.FNR][ok.FRAME_METAL]
    cause = maya.cause.matter
    group = maya.group
    z = Lay.add(
        j, group.name + " Maze Mirror", parent=group, offset=len(group.layers)
    )

    combine_seed(v, d)
    pdb.gimp_selection_none(j)
    Sel.border(j, cause, e[ok.FRAME_W], e[ok.FRAME_TYPE])

    sel = pdb.gimp_selection_save(j)
    sel1 = make_canvas_frame_sel(v, d)
    v.maze = Maze(v, d)

    pdb.gimp_selection_none(j)

    if d[ok.MAZE_TYPE] in (ff.SCATTERED_CONNECTORS, ff.SCATTERED_MAZES):
        graph = v.maze.graph = LineGraph(
            v.wip.rect, d[ok.ROW], d[ok.COLUMN], d[ok.LINE_W]
        )

        if d[ok.MAZE_TYPE] == ff.SCATTERED_CONNECTORS:
            scatter_connector(v, d)

        elif d[ok.MAZE_TYPE] == ff.SCATTERED_MAZES:
            scatter_maze(v, d)

        graph.add_line_to_disconnects()
        graph.select_graph(j)

    elif d[ok.MAZE_TYPE] == ff.COMPOSITION_FRAME:
        do_border(v, d)

    else:
        do_fill(v, d)

    draw_corner(v)

    for i in (sel, sel1):
        if i:
            Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
            pdb.gimp_image_remove_channel(j, i)

    Sel.opaque(cause, option=fu.CHANNEL_OP_SUBTRACT)
    return soften_metal_sel(v, z, e)


class MazeMirror(Metal):
    """
    Is a metallic frame with spiral mazes
    or random connectors filling the Canvas.
    """

    def __init__(self, *q, **d):
        """
        q: tuple
            Metal spec

        d: dict
            Metal spec
        """
        Metal.__init__(self, *q + (do_matter,), **d)


class Maze:
    """Is a container for Maze Mirror."""

    def __init__(self, v, d):
        """
        v: VIew
        d: dict
            Maze Mirror Preset
        """
        # LineGraph, 'graph'
        self.graph = None

        self.row = d[ok.ROW] // 2 + d[ok.ROW] % 2
        self.column = d[ok.COLUMN] // 2 + d[ok.COLUMN] % 2
        self.scatter = min(d[ok.SCATTER_COUNT], self.row * self.column)
        self.table = RectTable(v.wip.rect, d[ok.ROW], d[ok.COLUMN]).table
