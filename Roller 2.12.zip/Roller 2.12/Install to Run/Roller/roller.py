#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script type: Python-fu
Script Title: Roller
Tested on GIMP version: 2.10.24; Windows 10, 64 bit; GTK 2.28.7

What It Does:
    Create image compositions like wallpaper, image boards, and collages.
    Roller is made for fun and for work.

Where The Script Installs:
    See the how-to file.

Get the latest version: github.com/gummycowboy
"""
from gimpfu import pdb
import gimpfu as fu
import os
import pygtk
import sys
pygtk.require("2.0")

DEBUG = 0

if DEBUG:
    # Trace errors by creating a file, if the file doesn't already exist it.
    # Accept and append error messages and piped (">>") print statements:
    import time
    sys.stderr = open("D:\\roller_error1.txt", 'a')

# Append Roller paths to "sys.path" for GIMP's Python
# interpreter. "__file__" is GIMP's plug-in path:
n = os.path.sep
preset_path = os.path.dirname(__file__) + n + u"Roller"
module_path = preset_path + n + u"Module"

# If a folder path isn't in "sys.path", then add the path:
if module_path not in sys.path:
    sys.path.append(module_path)

# The Python interpreter will now look for
# modules inside the Module folder.
# Now imports from the Module folder work.
# A limitation to this import method is that the modules are not
# identified by the interpreter as being part of a Python package:
from roller_one_base import Comm
from roller_one_gegl import Gegl
from roller_one_stat import Stat
from roller_window_main import WindowMain


def start():
    """
    Start the program.

    typical variable usage:
        a : part of a sequence; object, int
        b : See 'a'.
        c : See 'a'; column
        d : dict
        e : dict
        f : float
        g : widget; window
        h : height
        i : iteration
        j : RollerImage; GIMP image; iteration
        k : key
        m : flag
        n : string
        p : process
        q : iterable
        r : row
        s : size
        t : size
        u : point
        v : point
        w : width; span
        x : coordinate; index
        y : coordinate
        z : layer
    """
    # Save the interface context so that it can
    # be restored when the plug-in is done:
    pdb.gimp_context_push()

    # Save the colors for GIMP generated gradients:
    q = pdb.gimp_context_get_background()
    q1 = pdb.gimp_context_get_foreground()

    # for consistency reasons:
    pdb.gimp_context_set_defaults()

    # Return the colors after the default modification:
    pdb.gimp_context_set_background(q)
    pdb.gimp_context_set_foreground(q1)

    pdb.gimp_context_set_interpolation(fu.INTERPOLATION_LOHALO)
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_context_set_sample_transparent(1)

    if DEBUG:
        print >> sys.stderr, "\nRoller,", time.ctime(), "\n"

    stat = Stat()
    stat.roller_path = preset_path
    Gegl.gimp_library = Gegl.load_library('libgimp-2.0')

    # Improve GIMP stability during testing with an exception handler:
    try:
        WindowMain(stat)

    except Exception as ex:
        Comm.show_err("Roller failed at some point: " + repr(ex))
        if DEBUG:
            print >> sys.stderr, ex

    # Return undo functionality:
    if stat.render.has_image:
        pdb.gimp_image_undo_group_end(stat.render.image)

    # Restore the interface context:
    pdb.gimp_context_pop()


fu.register(
    # name
    # Is the dialog title as 'python-fu + name'.
    # The space character is not allowed.
    # "name" is case-sensitive:
    "Roller",

    # tool-tip and window-tip text:
    "Renders image compositions.",

    # help (describe how-to, exceptions and dependencies)
    # Display in the plug-in browser:
    "Creates a new image and does not require an open image.",

    # Display in the plug-in browser:
    "Charles Bartley",

    # Display in the plug-in browser:
    "Charles Bartley",

    # Display in the plug-in browser:
    "2021",

    # menu item descriptor with short-cut key id "_R":
    "_Roller...",

    # image types
    # An empty string is no image needed:
    "",

    # dialog parameters:
    [],

    # results:
    [],

    # dialog function handler
    # The second item is the menu's location for the plug-in:
    start, menu="<Image>/Filters/Render")
if __name__ == "__main__":
    fu.main()
