#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import sqrt
from roller_format_form import Form
from roller_image_effect import LayerKey as nk
from roller_one_constant import (
    ForGradient as fg,
    FormatKey as fk,
    OptionKey as ok,
    SessionKey as sk
)
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import colorsys
import gimpfu as fu

em = Fu.Emboss
pdb = fu.pdb
sn = Fu.SolidNoise
um = Fu.UnsharpMask


class CutoutPlate:
    """Create a rectangular frame with cutout space for image material."""

    def __init__(self, one):
        """
        Do the image-effect.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        parent = one.parent
        d = one.d
        j = stat.render.image
        self.format_name = Lay.get_format_name_from_group(parent)
        image_layer = stat.render.get_image_layer(self.format_name)
        group = Lay.group(
            j,
            one.k,
            parent=parent,
            offset=Lay.offset(j, image_layer) + 1
        )
        sel_rect = []
        w = d[ok.FRAME_WIDTH]
        half = w // 2
        edge = max(min(d[ok.BEVEL_EDGE_WIDTH], half), 1)
        half = max(half - edge, 1)
        span = max(w - edge * 2, 2)
        n = Lay.get_layer_name(nk.FRAME, parent=parent)
        frame_layer = Lay.add(
            j,
            n,
            parent=group
        )

        Lay.color_fill(frame_layer, (255, 255, 255))

        # Cut out the image.
        # Use 'z' to set the alpha of the selection:
        z = Lay.selectable(j, image_layer, d)

        Sel.item(j, z)
        Sel.grow(j, edge, 1)
        Lay.clear_sel(j, frame_layer)
        pdb.gimp_image_remove_layer(j, z)

        # Get the format dict:
        for x, i in enumerate(one.session[sk.FORMAT_LIST]):
            if i[fk.Layer.NAME] == self.format_name:
                form = i
                row, column = stat.layout.get_division(x)
                break

        merged = Form.is_merge_cells(form)

        # Load the image selections. Calculate the frame bounds.
        # Collect the frame bounds for plate clearing.
        # Do one image at a time:
        for r in range(row):
            for c in range(column):
                if merged:
                    s = form[fk.Cell.Grid.PER_CELL][r][c]

                else:
                    # not a dependent cell:
                    s = 1

                # Is it a topleft cell?
                if s != (-1, -1):
                    # Yes, it is a topleft cell:
                    sel = stat.get_image_sel(self.format_name, r, c)
                    if sel:
                        # Calculate the frame bounds:
                        Sel.load(j, sel)
                        Sel.grow(j, edge, 1)
                        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
                        w = x1 - x + span
                        h = y1 - y + span
                        x -= half
                        y -= half
                        sel_rect.append((x, y, w, h))

        pdb.gimp_selection_none(j)

        # Load the expanded rectangle selections:
        for i in sel_rect:
            Sel.rect(j, *i)

        # Clear the material outside of the rectangle selections:
        Sel.clear_outside_of_selection(j, frame_layer)

        self.do_rounded_edge(j, frame_layer, edge)

        # Begin frame decoration.
        # 'z', pattern:
        z = pattern_layer = Lay.add(
            j,
            one.k,
            parent=group,
            offset=Lay.offset(j, frame_layer)
        )
        frame_layer.mode = fu.LAYER_MODE_MULTIPLY

        Sel.item(j, z)
        RenderHub.set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_pattern(d[ok.PATTERN])
        pdb.gimp_drawable_edit_bucket_fill(
            z,
            fu.FILL_PATTERN,
            Fu.BucketFill.X_IS_1,
            Fu.BucketFill.Y_IS_1
        )
        Sel.item(j, frame_layer)
        Sel.clear_outside_of_selection(j, z)
        RenderHub.adjust_mean_value(z)

        if d[ok.NOISE_OPACITY]:
            # noise:
            z = Lay.add(j, one.k, parent=group)
            z.opacity = d[ok.NOISE_OPACITY]

            pdb.plug_in_solid_noise(
                stat.render.image,
                z,
                sn.NO_TILEABLE,
                sn.YES_TURBULENT,
                d[ok.RANDOM_SEED],
                d[ok.DETAIL_LEVEL],
                sn.HORIZONTAL_SIZE_2,
                sn.VERTICAL_SIZE_2
            )
            pdb.plug_in_unsharp_mask(
                j,
                z,
                um.RADIUS_3,
                um.AMOUNT_54,
                um.THRESHOLD_0
            )

            # in case of transparency in the pattern:
            Sel.item(j, pattern_layer)

            sel = self.stat.save_render_sel()
            if sel:
                Sel.item(j, frame_layer)
                Sel.clear_outside_of_selection(j, z)
                pdb.plug_in_colortoalpha(j, z, (127, 127, 127))
                Sel.item(j, z)
                pdb.gimp_selection_feather(j, d[ok.SOFTNESS])
                Sel.invert(j)
                Lay.clear_sel(j, z)
                Sel.load(j, sel)
                Sel.clear_outside_of_selection(j, z)

        frame_layer.opacity = 94.

        pdb.gimp_image_raise_layer_to_top(j, frame_layer)
        Lay.merge_group(
            j,
            group,
            n=Lay.get_layer_name(nk.FRAME, parent=parent)
        )

    def do_rounded_edge(self, j, z, edge):
        """
        Do color blend effect using a color and its luminosity.

        The round effect is calculated using the unit circle formula.
        So 'x' is the luminosity step, and 'y' is the luminosity result.

            x**2 + y**2 = 1

        j: GIMP image
            work-in-progress

        z: layer
            to receive effect

        edge: int
            the number of gradient edge
        """
        amplitude = 255.

        # Are luminosity edge for the x-vector:
        step_x = 1. / (edge - 1)

        # 'a' is the x-value, 'offset' is the y-value:
        a = step_x
        offset = amplitude * sqrt(1. - a * a)
        q = colorsys.hsv_to_rgb(0., 0., offset)

        Sel.item(j, z)
        for i in range(edge):
            sel = self.stat.save_render_sel()
            if sel:
                q = tuple([int(b) for b in q])

                Sel.grow(j, 1, 0)
                Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
                Sel.fill(z, q)
                Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

                # 'luminosity' is on the  y-vector of the unit circle:
                a = step_x * (i + 1)
                if a < 1:
                    value = amplitude * sqrt(1 - a * a)
                    q = colorsys.hsv_to_rgb(0., 0., value)
