#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_caption import Caption
from roller_format_fringe import Fringe
from roller_format_form import Form
from roller_format_image import RollerImage, Rect
from roller_format_image_mask import ImageMask
from roller_format_plaque import Plaque
from roller_grid_deck import GridDeck
from roller_image_effect import LayerKey
from roller_one_constant import (
    ForFormat as ff,
    ForLayer,
    ForLayout,
    FormatKey as fk,
    FreeCellKey as fck,
    LayoutKey as nk,
    OptionKey as ok,
    PlaceKey as pl,
    PlaqueKey,
    PropertyKey as pr,
    SessionKey as sk
)
from roller_one import One
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb
MARGIN = ff.Margin.Index
SHIFT = ff.Cell.SHIFT


class Layout:
    """Manage image place."""

    def __init__(self, stat):
        """
        Init layout variables.

        stat: Stat
            globals
        """
        self.stat = stat
        self._deck = self._active_layer = self.image_group = None
        self.image_group = self.format_group = self.blur_behind_layer = None
        self._init_layout_references()

    def _calc_rect_position(self, d, j, format_x):
        """
        For an image or rectangle, calculate its (x, y) position in a cell.

        d: dict
            format dict

        j: RollerImage
            Has x and y position.

        format_x: int
            index
            corresponding with session's format list
        """
        r, c = j.r, j.c
        x, y = self._get_pocket_position(format_x, r, c, j=j)
        w, h = j.mold.size
        e = Form.get_place(d, r, c)
        n = e[pl.HORIZONTAL]
        n1 = e[pl.VERTICAL]

        if n == ff.Place.CENTER:
            x += (self._get_pocket_width(format_x, r, c, j=j) - w) // 2

        elif n == ff.Place.RIGHT:
            x += self._get_pocket_width(format_x, r, c, j=j) - w

        if n1 == ff.Place.MIDDLE:
            y += (self._get_pocket_height(format_x, r, c, j=j) - h) // 2

        elif n1 == ff.Place.BOTTOM:
            y += self._get_pocket_height(format_x, r, c, j=j) - h

        j.mold.position = x, y
        if r != ForLayout.FREE_CELL:
            self._deck.set_mold(format_x, r, c, (x, y), (w, h))

    def _color_fill(self, q):
        """
        Fill the selection with a color on the current format layer.

        q: tuple
            color (RGB)
        """
        Sel.fill(self._active_layer, q)
        pdb.gimp_displays_flush()

    def _draw_caption(self, session, d, format_x, parent):
        """
        Draw cell caption for layout.

        d: dict
            format dict

        format_x: int
            index

        parent: layer
            layout format group
        """
        if d[fk.LAYOUT_OPTION][nk.CELL_CAPTION]:
            Caption(
                session,
                d,
                format_x,
                self.stat,
                parent=parent,
                is_layout=True
            )

    def _draw_cell_margins(self, session, d, format_x):
        """
        Draw the cell margins.

        Call during a layout demo.

        session: dict
            of session

        d: dict
            of format

        format_x: int
            index in format list
        """
        def select_margins(m):
            """
            Select a margin for a cell.

            m: flag
                If it's true, the margins were selected.

            return:
                m: flag
                same as input 'm'
            """
            a = margin[x]
            p = self._get_margin_rect_width
            p1 = self._get_margin_rect_height
            if a:
                # Unavailable cells have zero dimensions:
                if self._get_pocket_width(format_x, r, c, j=j):
                    m = 1
                    x1, y = self._get_pocket_position(format_x, r, c, j=j)
                    x1 += (
                        0,
                        0,
                        -margin[MARGIN.LEFT],
                        self._get_pocket_width(format_x, r, c, j=j)
                    )[x]
                    y += (
                        -margin[MARGIN.TOP],
                        self._get_pocket_height(format_x, r, c, j=j),
                        0,
                        0
                    )[x]
                    w = (
                        p(session, format_x, r, c, d, j=j),
                        p(session, format_x, r, c, d, j=j),
                        a,
                        a
                    )[x]
                    h = (
                        a,
                        a,
                        p1(session, format_x, r, c, d, j=j),
                        p1(session, format_x, r, c, d, j=j)
                    )[x]
                    Sel.rect(self.stat.render.image, x1, y, w, h)
            return m

        row, col = self._deck.get_division(format_x)
        m = 0
        j = None
        is_double = Form.is_double_space(d)
        just_one = Form.is_draw_one_margin(d) if not is_double else 0

        for r in range(row):
            for c in range(col):
                is_cell = 1

                if is_double:
                    is_cell = Form.is_double_space_cell(r, c, is_double)
                if is_cell:
                    margin = self.get_cell_margin(format_x, r, c, d)
                    for x in range(4):
                        draw = 1

                        # left, right:
                        if x in (MARGIN.LEFT, MARGIN.RIGHT):
                            if just_one and r > 0:
                                draw = 0

                        # top, bottom:
                        else:
                            if just_one and c > 0:
                                draw = 0
                        if draw:
                            m += select_margins(m)

        for cell in d[fk.Layer.CELL_LIST]:
            r = c = ForLayout.FREE_CELL
            j = RollerImage.get_image(
                session,
                cell[pl.IMAGE_PLACE][pl.IMAGE_DICT]
            )
            if not j:
                # Create a dummy image for the missing image:
                j = RollerImage(None, "")

                Form.prep_free_cell_image(j, cell, session['size'])
                margin = Form.combine_margin(
                    cell[fck.Cell.MARGIN],
                    j.cell.width,
                    j.cell.height
                )
            for x in range(4):
                m += select_margins(m)
        if m:
            self._color_fill(ForLayout.CELL_MARGIN_COLOR)

    def _draw_coord(self, session, format_x, j, cell):
        """
        Draw image coordinates at the top-left of an image rectangle.

        session: dict
            of session

        format_x: int
            index to format dict

        j: RollerImage
            work-in-progress

        cell: Cell
            Has position.
        """
        z = self._make_text(str(j.mold.x) + ", " + str(j.mold.y))
        self._draw_text(cell.x + 3, cell.y, z)

    def _draw_corners(self, session, format_x, j, cell):
        """
        Draw image corner coordinates.

        session: dict
            of session

        format_x: int
            index to format dict

        j: RollerImage
            work-in-progress

        cell: Cell
            Has cell rectangle.
        """
        # top-right:
        x = j.mold.x + j.mold.width
        n = str(x) + ", " + str(j.mold.y)
        z = self._make_text(n)

        self._draw_text(cell.x + 3, cell.y + cell.height - z.height, z)

        # bottom-left:
        y = j.mold.y + j.mold.height
        n = str(j.mold.x) + ", " + str(y)
        z = self._make_text(n)
        self._draw_text(
            cell.x + cell.width - z.width - 3,
            cell.y + 3,
            z
        )

    def _draw_dimension(self, session, format_x, j, cell):
        """
        Draw an image's dimension at the bottom-right of an image rectangle.

        session: dict
            of session

        format_x: int
            index to format

        j: RollerImage
            work-in-progress

        cell: Cell
            Has cell rectangle.
        """
        w, h = j.mold.size
        n = str(w) + ", " + str(h)
        z = self._make_text(n)
        self._draw_text(
            cell.x + cell.width - z.width - 3,
            cell.y + cell.height - z.height,
            z
        )

    def _draw_format(self, session, d, format_x, parent):
        """
        Draw a format.

        session: dict
            of session

        d: dict
            of format

        format_x: int
            index in format list

        parent: layer
            layout format group
        """
        e = d[fk.LAYOUT_OPTION]
        is_rectangle = Form.is_rectangle_shape(d)
        is_double = Form.is_double_space(d)
        q = (
            (nk.CELL_MARGINS, self._draw_cell_margins),
            (nk.LAYER_MARGINS, self._draw_layer_margins),
        )

        self._draw_plaque_types(session, d, format_x, is_double)

        if e:
            for i in q:
                if e[i[0]]:
                    i[1](session, d, format_x)

        self._draw_image(session, d, format_x, is_rectangle, is_double)

        if e[nk.GRID]:
            self._draw_grid(session, d, format_x, is_double)
        self._draw_caption(session, d, format_x, parent)

    def _draw_grid(self, session, d, format_x, is_double):
        """
        Draw grid lines.

        session: dict
            of session

        d: dict
            of format

        format_x: int
            index in format list

        is_double: flag
            Is true if the cell table is doubled-spaced.
        """
        m = 0
        row, col = self._deck.get_division(format_x)
        w, h = session['size']
        top, bottom, left, right = Form.get_layer_margin(d, (w, h))

        # Grid lines divide the layer space:
        w1 = w - left - right
        x = left
        h1 = 1

        pdb.gimp_selection_none(self.stat.render.image)

        # Draw rows:
        if row > 1:
            for r in range(1, row):
                c = 0
                is_draw = 1

                if is_double:
                    c = not r % 2 if is_double == SHIFT else r % 2
                    is_draw = Form.is_double_space_cell(r, c, is_double)
                if is_draw:
                    y = self._deck.get_cell_position(format_x, r, c)[1]
                    if 0 < y < h:
                        m = 1
                        Sel.rect(self.stat.render.image, x, y, w1, h1)

        w1, h1 = 1, h - top - bottom
        y = top

        # Draw columns:
        if col > 1:
            for c in range(1, col):
                is_draw = 1
                r = 0

                if is_double:
                    r = not c % 2 if is_double == SHIFT else c % 2
                    is_draw = Form.is_double_space_cell(r, c, is_double)
                if is_draw:
                    x = self._deck.get_cell_position(format_x, r, c)[0]
                    if 0 < x < w:
                        m = 1
                        Sel.rect(self.stat.render.image, x, y, w1, h1)
        if m:
            self._color_fill(ForLayout.GRID_COLOR)

    def _draw_image(self, session, d, format_x, is_rectangle, is_double):
        """
        Draw a rectangle that represents an image.
        Draw image-related text.
        Conditionally apply an image mask.
        Work on the active layer.

        session: dict
            of session

        d: dict
            of format

        format_x: int
            index in format list

        is_rectangle: flag
            Is true if the cell shape is a rectangle.

        is_double: flag
            Is true if the cell table is double-spaced.
        """
        def process_image():
            j.r, j.c = r, c
            j.rotate = Form.get_image_property(d, r, c)[pr.ROTATE]

            pdb.gimp_selection_none(render)
            self._mold_rect(j, d, format_x)
            if j.mold.width and j.mold.height:
                if e[nk.IMAGE]:
                    if j.rotate:
                        self._rotate_image_rect(j, d, format_x)

                    if e[nk.IMAGE_MASK]:
                        sel = stat.save_render_sel()
                        render.active_layer = self._active_layer
                        if ImageMask.make_mask_selection(
                            session,
                            d,
                            stat,
                            format_x,
                            r,
                            c,
                            is_merge,
                            image=j
                        ):
                            Sel.load(
                                render,
                                sel,
                                option=fu.CHANNEL_OP_INTERSECT
                            )

                    if not is_rectangle:
                        Form.select_shape(render, j.shape)
                    self._color_fill(ForLayout.IMAGE_COLOR)

                if r == ForLayout.FREE_CELL:
                    cell = j.cell

                else:
                    cell = self._deck.get_merge_cell_rect(format_x, r, c)
                for i in q:
                    if e[i[0]]:
                        i[1](session, format_x, j, cell)

        stat = self.stat
        render = stat.render.image
        row, col = self._deck.get_division(format_x)
        e = d[fk.LAYOUT_OPTION]
        q = (
            (nk.COORDINATES, self._draw_coord),
            (nk.CORNERS, self._draw_corners),
            (nk.DIMENSIONS, self._draw_dimension),
            (nk.NAME, self._draw_name),
            (nk.RATIOS, self._draw_ratio)
        )
        parent = self._active_layer.parent
        self._active_layer = render.active_layer = parent.layers[0]
        is_merge = Form.is_merge_cells(d)

        pdb.gimp_selection_none(render)

        for r in range(row):
            for c in range(col):
                # 'm' is true when there is a valid cell:
                m = 1

                if is_double:
                    m = Form.is_double_space_cell(r, c, is_double)
                if m:
                    j = self.get_grid_image(
                        session,
                        d,
                        format_x,
                        r,
                        c,
                        is_merge
                    )
                    if j:
                        j.pocket = self._deck.get_pocket(format_x, r, c)
                        j.shape = self._deck.get_shape(format_x, r, c)

                        process_image()
                        RollerImage.close_image(j)
        for d in d[fk.Layer.CELL_LIST]:
            j = RollerImage.get_image(
                session,
                d[pl.IMAGE_PLACE][pl.IMAGE_DICT]
            )
            if j:
                r = c = ForLayout.FREE_CELL

                Form.prep_free_cell_image(j, d, session['size'])
                process_image()
                RollerImage.close_image(j)

    def _draw_layer_margins(self, session, d, format_x):
        """
        Draw the layer margins.

        session: dict
            of session

        d: dict
            Has format.

        format_x: int
            index
            corresponding with session's format list
        """
        m = 0
        size = session['size']
        top, bottom, left, right = Form.get_layer_margin(d, size)

        pdb.gimp_selection_none(self.stat.render.image)
        if any((top, bottom, left, right)):
            for x in range(4):
                m = 1

                if x in (MARGIN.TOP, MARGIN.BOTTOM):
                    # top, bottom:
                    x1 = left
                    w = size[0] - left - right

                    if x == MARGIN.TOP:
                        y = 0
                        h = top

                    else:
                        h = bottom
                        y = size[1] - h

                else:
                    # left, right:
                    h = size[1] - top - bottom
                    y = top

                    if x == MARGIN.LEFT:
                        x1 = 0
                        w = left

                    else:
                        w = right
                        x1 = size[0] - w
                Sel.rect(self.stat.render.image, x1, y, w, h)
            if m:
                self._color_fill(ForLayout.LAYER_MARGIN_COLOR)

    def _draw_layer_plaque(self, session, d, format_x):
        """
        Draw layer plaque and layer fringe mock-ups.

        d: dict
            of format

        format_x: int
            index in format list
        """
        e = d[fk.LAYOUT_OPTION]
        j = self.stat.render.image
        size = session['size']
        if e[nk.LAYER_PLAQUE]:
            d1 = d[PlaqueKey.LAYER_PLAQUE]
            if d1[PlaqueKey.OPACITY] and d1[PlaqueKey.TYPE] != ok.NONE:
                if d1[PlaqueKey.OBEY_MARGINS]:
                    y, bottom, x, right = Form.get_layer_margin(d, size)
                    w = size[0] - x - right
                    h = size[1] - y - bottom

                else:
                    x = y = 0
                    w, h = size

                parent = self._active_layer.parent
                n = Lay.get_layer_name(
                    LayerKey.LAYER_PLAQUE,
                    parent=parent
                )
                z = Lay.add(j, n, parent=parent, offset=len(parent.layers))

                Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
                Sel.fill(
                    z,
                    ForLayout.PLAQUE_COLOR
                )
                pdb.gimp_selection_none(j)

    def _draw_name(self, session, format_x, j, cell):
        """
        Draw a document title at the center of an image rectangle.

        session: dict
            of session

        format_x: int
            index to format dict

        j: RollerImage
            work-in-progress

        cell: Cell
            no use
        """
        z = self._make_text(j.layer_name if j.layer_name else j.image_name)
        x = j.mold.width // 2 + j.mold.x - z.width // 2
        y = j.mold.height // 2 + j.mold.y + z.height // 2
        self._draw_text(x, y, z)

    def _draw_plaque_types(self, session, d, format_x, is_double):
        """
        Draw cell plaque and cell fringe mock-ups.

        d: dict
            of format

        format_x: int
            index in format list

        is_double: flag
            Is true if the cell table is double-spaced.
        """
        def select_plaque(plaque_dict):
            """
            Select a rectangle that represents a cell plaque.

            plaque_dict: dict
                Has plaque.
            """
            one.d = Form.get_cell_plaque(plaque_dict, r, c)
            one.r, one.c = r, c

            if Plaque.is_cell_plaque(d, one, is_double, merged):
                plaque = self.get_plaque(format_x, r, c, j=j1)
                n = Lay.get_layer_name(
                    LayerKey.CELL_PLAQUE,
                    parent=parent
                )
                plaque_layer = Lay.add(
                    j,
                    n,
                    parent=parent,
                    offset=len(parent.layers)
                )

                if not plaque_layer:
                    Lay.add(j, n, parent=parent, offset=len(parent.layers))

                Form.select_shape(j, plaque)
                Sel.fill(
                    plaque_layer,
                    ForLayout.PLAQUE_COLOR
                )
                pdb.gimp_selection_none(j)

        e = d[fk.LAYOUT_OPTION]
        stat = self.stat
        j = stat.render.image
        j1 = None
        row, col = self._deck.get_division(format_x)
        merged = Form.is_merge_cells(d)
        one = One()
        parent = self._active_layer.parent

        if e[nk.CELL_PLAQUE]:
            for r in range(row):
                for c in range(col):
                    m = 1

                    if is_double:
                        m = Form.is_double_space_cell(r, c, is_double)

                    if m:
                        select_plaque(d)

            # for cell list:
            merged = is_double = 0

            for cell in d[fk.Layer.CELL_LIST]:
                r = c = ForLayout.FREE_CELL
                j1 = RollerImage(None, "")

                # Set the 'cell' Rect for 'select_plaque':
                Form.prep_free_cell_image(j1, cell, session['size'])
                select_plaque(cell)

        if e[nk.CELL_FRINGE] or e[nk.LAYER_FRINGE]:
            if e[nk.CELL_FRINGE]:
                if e[nk.LAYER_FRINGE]:
                    is_layout = ff.IS_BOTH_FRINGE

                else:
                    is_layout = ff.IS_CELL_FRINGE

            else:
                is_layout = ff.IS_LAYER_FRINGE
            Fringe(
                session,
                d,
                format_x,
                stat,
                self._active_layer.parent,
                is_layout=is_layout
            )
            self._active_layer = j.active_layer
        self._draw_layer_plaque(session, d, format_x)

    def _draw_ratio(self, session, format_x, j, cell):
        """
        Draw an image ratio at the center of an image rectangle.

        A ratio is an image center point divided by the render size.

        session: dict
            of session

        format_x: int
            index to format

        j: RollerImage
            work-in-progress

        cell: Cell
            Has cell rectangle.
        """
        x = j.mold.width // 2 + j.mold.x
        y = j.mold.height // 2 + j.mold.y
        x1 = x / 1. / session['w']
        y1 = y / 1. / session['h']
        r_x = format(x1, '.2f')
        r_y = format(y1, '.2f')
        n = r_x[int(x1 < 1):] + ", " + r_y[int(y1 < 1):]
        z = self._make_text(n)
        x2 = cell.x + cell.width // 2 - z.width // 2
        y2 = cell.y + cell.height // 2 - z.height // 2
        self._draw_text(x2, y2, z)

    def _draw_text(self, x, y, z):
        """
        Add a text layer to the format group.

        x, y: int
            final position
            screen coordinate

        z: layer
            to receive text
        """
        pdb.gimp_image_insert_layer(
            self.stat.render.image,
            z,
            self.format_group,
            0
        )
        pdb.gimp_text_layer_set_color(z, (255, 255, 255))
        pdb.gimp_layer_set_offsets(z, x, y)
        z.opacity = 66.

    def _get_margin_rect_height(self, session, format_x, r, c, d, j=None):
        """
        Return the height of a cell margin drawing rectangle.

        session: dict
            Has render height.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        d: dict
            format dict

        j: RollerImage
            Has pocket.

        Return: int
            the height of the drawing rectangle
        """
        if r != ForLayout.FREE_CELL:
            if Form.is_draw_one_margin(d):
                top, bottom, _, _ = self.get_cell_margin(format_x, r, c, d)
                top1, bottom1, _, _ = Form.get_layer_margin(d, session['size'])
                return session['h'] - top - bottom - top1 - bottom1

            else:
                return self._get_pocket_height(format_x, r, c)

        # free-range cell:
        return j.pocket.height

    def _get_margin_rect_width(self, session, format_x, r, c, d, j=None):
        """
        Return the width of a cell margin drawing rectangle.

        session: dict
            of session

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        d: dict
            of format

        j: RollerImage
            Has pocket.

        Return: int
            width of rectangle for drawing margin
        """
        if r != ForLayout.FREE_CELL:
            if Form.is_draw_one_margin(d):
                _, _, left, right = self.get_cell_margin(format_x, r, c, d)
                _, _, left1, right1 = Form.get_layer_margin(d, session['size'])
                return session['w'] - left - right - left1 - right1

            else:
                return self._get_pocket_width(format_x, r, c)

        # free-range cell:
        return j.pocket.width

    def _get_pocket_height(self, format_x, r, c, j=None):
        """
        Get the pocket height for a cell.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        j: RollerImage
            Has 'd', its free cell dict.

        Return: int
            pocket height
        """
        if r != ForLayout.FREE_CELL:
            return self._deck.get_pocket(format_x, r, c).height
        return j.pocket.height

    def _get_pocket_position(self, format_x, r, c, j=None):
        """
        Get the pocket topleft coordinate (x, y) for a cell.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        j: RollerImage
            Has 'd', its free cell dict.

        Return: tuple
            position
            x, y
        """
        if r != ForLayout.FREE_CELL:
            return self._deck.get_pocket(format_x, r, c).position

        else:
            return j.pocket.position

    def _get_pocket_width(self, format_x, r, c, j=None):
        """
        Get a pocket's width.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            cell index

        j: RollerImage
            Has 'pocket'.

        Return: int
            pocket width
        """
        if r != ForLayout.FREE_CELL:
            return self._deck.get_pocket(format_x, r, c).width

        # free-range cell:
        return j.pocket.width

    def _init_layout_references(self):
        """Initialize layout variables."""
        self._active_layer = None

    def _make_text(self, n):
        """
        Create a new text layer.

        n: string
            text to display

        Return the new layer.
        """
        z = pdb.gimp_text_layer_new(
            self.stat.render.image,
            n,
            'Sans-serif',
            11.,
            fu.PIXELS
        )
        z.name = ForLayer.LAYER_BULLET + n
        return z

    def _mold_image(self, j, d, format_x):
        """
        Mold an image to fit a cell.

        j: RollerImage
            to fit into cell

        d: dict
            of format

        format_x: int
            index
            corresponding with session's format list

        Return: bool
            Is true if there is material in the buffer.
        """
        pdb.gimp_selection_none(self.stat.render.image)

        is_copy = True

        if j.r != ForLayout.FREE_CELL:
            j.pocket = self._deck.get_pocket(format_x, j.r, j.c)
            j.cell = self._deck.get_merge_cell_rect(format_x, j.r, j.c)
            j.mold.size = j.mold.position = 0, 0
            j.shape = self._deck.get_shape(format_x, j.r, j.c)

        s = j.pocket.size
        e = Form.get_place(d, j.r, j.c)

        # Get resize index for fill, locked, numeric, trim:
        x = Form.get_resize_type_index(e)

        if x in ff.Place.RESIZE_NUMERIC_INDEX:
            is_copy = Form.mold_numerically(j, d, e[pl.RESIZE])

        else:
            (
                Form.mold_lock,
                Form.mold_trim,
                Form.mold_fill,
                Form.mold_cover
            )[x](j, d)

        if j.rotate and is_copy:
            j2 = pdb.gimp_edit_paste_as_new_image()
            z = Lay.rotate(j2, j.rotate)
            t = w, h = z.width, z.height

            pdb.gimp_edit_copy_visible(j2)
            pdb.gimp_image_delete(j2)

            if w > s[0] or h > s[1]:
                t = w, h = Form.calc_lock(s, t)
                j3 = pdb.gimp_edit_paste_as_new_image()
                Form.shape(j3, w, h)
            j.mold.size = t

        if is_copy:
            self._calc_rect_position(d, j, format_x)
        return is_copy

    def _mold_rect(self, j, d, format_x):
        """
        Draw an image rectangle for a layout per the format.

        j: RollerImage
            with image place information

        d: dict
            with format

        format_x: int
            index
            corresponding with session's format list
        """
        s = j.size
        t = j.pocket.size
        n = Form.get_place(d, j.r, j.c)[pl.RESIZE]

        if n == ff.Place.FILL_CELL:
            s1 = t

        elif n == ff.Place.LOCKED:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = Form.calc_lock(t, s)

            else:
                s1 = s

        elif n == ff.Place.TRIM:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = Form.get_trim_size(s, t)
                if s1[1] > t[1]:
                    s1[1] = t[1]

                else:
                    s1[0] = t[0]

            else:
                s1 = s

        elif n == ff.Place.COVER:
            s1 = t

        else:
            # numerically resized:
            s1 = Form.get_numeric_size(j, n)

        j.mold.size = s1

        # The size is invalid if it is None or has a zero for w, h:
        if s1 and s1[0] and s[1]:
            self._calc_rect_position(d, j, format_x)
            Sel.rect(self.stat.render.image, j.mold.x, j.mold.y, *s1)

        else:
            # no image:
            j.mold = Rect((0, 0), (0, 0))

    def _rotate_image_rect(self, j, d, format_x):
        """
        Rotate an image rectangle.

        j: RollerImage
            with cell info

        d: dict
            of format

        format_x: int
            index
            corresponding with session's format list

        Return: state of image
            selection of rotated layer
        """
        render = self.stat.render.image

        # Create a new image with the selection:
        z = Lay.add(
            render,
            j.image_name,
            parent=self.format_group
        )

        Sel.fill(z, ForLayout.IMAGE_COLOR)
        pdb.gimp_edit_copy(z)
        Lay.clear_sel(render, z)

        s = j.pocket.size
        j2 = pdb.gimp_edit_paste_as_new_image()
        z1 = Lay.rotate(j2, j.rotate)

        j.mold.size = z1.width, z1.height

        if j.mold.width > s[0] or j.mold.height > s[1]:
            # The image won't fit into the cell so get the size that will:
            w, h = j.mold.size = Form.calc_lock(s, j.mold.size)
            z1 = pdb.gimp_item_transform_scale(z1, 0, 0, w, h)

        pdb.gimp_edit_copy(z1)
        pdb.gimp_image_delete(j2)

        z4 = Lay.paste(render, z)
        z4.name = Lay.get_layer_name("Rotated " + j.image_name)

        pdb.gimp_image_remove_layer(render, z)
        self._calc_rect_position(d, j, format_x)
        pdb.gimp_layer_set_offsets(z4, j.mold.x, j.mold.y)
        Sel.item(render, z4)
        pdb.gimp_image_remove_layer(render, z4)

    def calc_block(self, d, format_x, start, end):
        """
        Recalculate the pocket sizes for a block of cells.

        d: dict
            of format

        format_x: int
            index
            corresponding with session's format list

        start, end: tuple
            of int
            size
            w, h
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self._deck.calc_pocket(format_x, r, c, d)

    def calc_cell_table(self, session):
        """
        Calculate cell sizes.

        Correct cell size underflow and overflow.

        session: dict
            of session
        """
        RollerImage.init_for_layout()

        format_list = session[sk.FORMAT_LIST]
        self._deck = GridDeck(self.stat, session)

        # Initialize image references:
        for format_x, d in enumerate(format_list):
            is_double = Form.is_double_space(d)
            r, c = self._deck.get_division(format_x)
            is_merge = Form.is_merge_cells(d)
            for i in range(r):
                for j in range(c):
                    m = 1

                    if is_double:
                        m = Form.is_double_space_cell(i, j, is_double)
                    if m:
                        if is_merge:
                            # 's' size of the cell in cell-count:
                            s = d[fk.Cell.Grid.PER_CELL][i][j]

                            if s == (-1, -1):
                                continue

                        e = Form.get_place(d, i, j)[pl.IMAGE_DICT]
                        self._deck.set_image(
                            format_x,
                            i,
                            j,
                            RollerImage.get_image_reference(e)
                        )

    def get_cell_block_size(self, d, format_x, r, c):
        """
        Calculate the cell block size.

        d: dict
            of format

        format_x: int
            index to format in format list

        r, c: int
            row, column
            cell indices
        """
        s = 1, 1

        if d[fk.Cell.Grid.PER_CELL]:
            # 's' size of the cell in cells:
            s = d[fk.Cell.Grid.PER_CELL][r][c]

        # Sub-topleft cells are unavailable:
        if s == (-1, -1):
            w = h = 0

        else:
            s = r + s[0] - 1, c + s[1] - 1
            _, _, w, h = self._deck.calc_cell_block(format_x, (r, c), s)
        return w, h

    def get_cell_margin(self, format_x, r, c, d, size=None):
        """
        Return the image margins for a cell at r, c as
        (top, bottom, left, right) of int.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        d: dict
            format dict

        size: tuple
            w, h
            of cell

        Return: tuple
            top, bottom, left, right
            of int
        """
        if not size:
            size = self._deck.get_merge_cell_size(format_x, r, c)

        if not d[fk.Cell.Margin.PER_CELL]:
            q = d[fk.Cell.MARGIN]

        else:
            q = d[fk.Cell.Margin.PER_CELL][r][c]
        return Form.combine_margin(q, *size)

    def get_division(self, format_x):
        """
        Get the row and column span of a cell grid.

        format_x: int
            index for format list

        Return: tuple
            row, column
            of int
            size of cell grid
        """
        return self._deck.get_division(format_x)

    def get_image_name_from_cell(self, format_x, r, c, j=None):
        """
        Get the image name from a cell or a RollerImage.

        format_x: int
            format index in session's format list

        r, c: int
            cell table index

        j: RollerImage
            Has name.
            for free-range cell

        Return: string or None
            image reference
        """
        if r != ForLayout.FREE_CELL:
            return self._deck.get_image_name(format_x, r, c)

        # free-range cell:
        if j:
            return j.image_name

    def get_layer_name(self, format_x, r, c, j=None):
        """
        Get the layer name for a cell.

        format_x: int
            index to format

        r, c: int
            cell table index

        j: RollerImage
            Has layer name.
        """
        if r != ForLayout.FREE_CELL:
            return self._deck.get_layer_name(format_x, r, c)

        # free-range cell:
        if j:
            return j.layer_name

    def get_merge_cell_rect(self, format_x, r, c):
        """
        Return a 'cell' Rect object.

        format_x: int
            index in session's format list

        r, c: int
            cell index
            Has a 'cell' rectangle.

        Return: Rect
            merged-cell before margins
        """
        return self._deck.get_merge_cell_rect(format_x, r, c)

    def get_mold_from_cell(self, format_x, r, c):
        """
        Get the 'mold' Rect object f    or a cell.

        format_x: int
            index in session's format list

        r, c: int
            cell index

        Return: Rect
            of mold
            Is an image place rectangle.
        """
        return self._deck.get_mold(format_x, r, c)

    def get_grid_image(self, session, d, format_x, r, c, is_merge):
        """
        Get the image for a grid cell.

        session: dict
            of session

        d: dict
            of format

        format_x: int
            index to format in session's format list

        r, c: int
            cell index

        is_merge: flag
            Is true when the cell grid's merge cells option is in play.

        Return: RollerImage
            or None
        """
        j = None
        go = 1

        if is_merge:
            if d[fk.Cell.Grid.PER_CELL][r][c] == (-1, -1):
                go = 0

        if go:
            e = Form.get_place(d, r, c)[pl.IMAGE_DICT]
            j = RollerImage.get_image_from_name(
                session,
                e,
                self._deck.get_image_name(format_x, r, c)
            )
        return j

    def get_plaque(self, format_x, r, c, j=None):
        """
        Get a 'plaque' value.

        d: dict
            of format

        format_x: int
            index in session's format list

        r, c: int
            cell index
            Has 'plaque' item.
        """
        if r != ForLayout.FREE_CELL:
            return self._deck.get_plaque(format_x, r, c)

        # free-range cell:
        return j.plaque

    def get_pocket_rect(self, format_x, r, c):
        """
        Get a cell's pocket rectangle for a cell.

        format_x: int
            index
            corresponding with session's format list

        r, c: int
            row, column
            cell index

        Return: Rect
            of pocket
        """
        return self._deck.get_pocket(format_x, r, c)

    def init_format_references(self):
        """
        Initialize variables when rendering a format.

        Format variables need to be reset per format.
        """
        self.image_group = self.blur_behind_layer = None

    def place_image(self, j, d, format_x, parent):
        """
        Copy and paste images on or above the image layer.

        j: RollerImage
            with GIMP image reference
            Has row and column position.

        d: dict
            of format or free cell

        format_x: int
            index
            corresponding with session's format list

        parent: layer
            group for image layer group

        return: layer
            with image
            Is None when there is no image.
        """
        # The RollerImage's image will enter the copy and paste buffer:
        if self._mold_image(j, d, format_x):
            render = self.stat.render.image
            if not self.image_group:
                self.image_group = Lay.group(
                    render,
                    LayerKey.IMAGE,
                    parent=parent
                )
                Lay.add(render, "Paste Target", parent=self.image_group)

            z = Lay.paste(render, self.image_group.layers[-1])
            e = Form.get_image_property(d, j.r, j.c)
            z.opacity = e[pr.OPACITY]

            pdb.gimp_image_reorder_item(render, z, self.image_group, 0)

            if e[pr.FLIP_HORIZONTAL]:
                Lay.flip(z, horizontal=1)

            if e[pr.FLIP_VERTICAL]:
                z = Lay.flip(z)

            pdb.gimp_layer_set_offsets(z, j.mold.x, j.mold.y)

            if not Form.is_rectangle_shape(d):
                Form.apply_shape_mask(render, j, z)
            return z

    def set_layer_name(self, j, format_x, r, c):
        """
        Set the layer name for a cell.

        j: RollerImage
            Has layer name.

        format_x: int
            index to format

        r, c: int
            cell coordinate indices
        """
        self._deck.set_layer_name(format_x, r, c, j.layer_name)

    def show(self, session):
        """
        Draw the layout.

        session: dict
            of session
        """
        self.stat.render.on_new_layout()
        self._init_layout_references()
        self.calc_cell_table(session)

        stat = self.stat
        q = session[sk.FORMAT_LIST]
        start = len(q) - 1
        z = stat.render.layout_group

        if start > -1:
            # Draw format layouts:
            for x in range(start, -1, -1):
                d = q[x]
                n = d[fk.Layer.NAME]
                z1 = self.format_group = Lay.group(
                    stat.render.image,
                    Lay.get_layer_name("Layout Group: " + n)
                )

                pdb.gimp_image_reorder_item(stat.render.image, z1, z, 0)

                z2 = self._active_layer = Lay.add(
                    stat.render.image,
                    Lay.get_layer_name("Layout: " + n),
                    parent=z1
                )
                z2.opacity = 66.
                self._draw_format(session, d, x, z1)

        pdb.gimp_image_set_active_layer(stat.render.image, z)
        pdb.gimp_selection_none(self.stat.render.image)
        pdb.gimp_displays_flush()
        stat.del_render_sel()
