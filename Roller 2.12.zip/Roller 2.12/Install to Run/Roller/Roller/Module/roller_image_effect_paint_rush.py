#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import ForBackdropStyle as fbs, OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_one_mode import Mode
from roller_image_effect import LayerKey as nk
import gimpfu as fu

ed = Fu.Edge
em = Fu.Emboss
pdb = fu.pdb
DIFF = fu.LAYER_MODE_DIFFERENCE
DIVIDE = fu.LAYER_MODE_DIVIDE
EXTRACT = fu.LAYER_MODE_GRAIN_EXTRACT
FOUR_COORDINATES = 4
LIGHT = fu.LAYER_MODE_LINEAR_LIGHT
MULTIPLY = fu.LAYER_MODE_MULTIPLY
NORMAL = fu.LAYER_MODE_NORMAL
MIXED_EDGE = fbs.PaintRush.WHITE_MIXED, fbs.PaintRush.GREY_MIXED
SUBTRACT = fu.LAYER_MODE_SUBTRACT


class PaintRush:
    """Create a frame around image material from altered image material."""

    def __init__(self, one):
        """
        Do the image-effect.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        parent = one.parent
        d = one.d
        j = stat.render.image
        image_layer = stat.render.get_image_layer(
            Lay.get_format_name_from_group(parent)
        )
        group = Lay.group(
            j,
            one.k,
            parent=parent,
            offset=Lay.offset(j, image_layer)
        )
        x = fbs.PaintRush.TYPE.index(d[ok.EDGE_TYPE])
        group.mode = fu.LAYER_MODE_LIGHTEN_ONLY
        z = Lay.clone(j, image_layer)
        z.mode = (DIVIDE, DIVIDE, EXTRACT, EXTRACT, EXTRACT, EXTRACT)[x]

        pdb.gimp_image_reorder_item(j, z, group, 0)
        pdb.plug_in_edge(j, z, ed.AMOUNT_2, ed.WRAP, ed.SOBEL)

        z = z1 = Lay.clone(j, z)
        z.mode = (SUBTRACT, SUBTRACT, EXTRACT, SUBTRACT, SUBTRACT, SUBTRACT)[x]

        pdb.gimp_image_reorder_item(j, z, group, len(group.layers))

        z = z2 = Lay.clone(j, z)
        z.mode = (LIGHT, LIGHT, LIGHT, LIGHT, LIGHT, NORMAL)[x]
        w = d[ok.FRAME_WIDTH]

        while w:
            w1 = min(w, 500)
            w -= w1
            Lay.blur(j, z, w1)

        if d[ok.EDGE_TYPE] in MIXED_EDGE:
            w = d[ok.FRAME_WIDTH] // 2
            while w:
                w1 = min(w, 500)
                w -= w1
                Gegl.blur(z, w1)

        pdb.gimp_image_reorder_item(j, z, group, len(group.layers))

        # Protect the center with a grey layer:
        z = Lay.clone(j, z1)
        z.mode = fu.LAYER_MODE_BURN

        pdb.gimp_image_reorder_item(j, z, group, 2)
        pdb.gimp_curves_spline(
            z,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 127, 255, 127]
        )
        Sel.item(j, z)
        pdb.gimp_selection_shrink(j, d[ok.FRAME_WIDTH])

        self.sel = stat.save_render_sel()

        Sel.clear_outside_of_selection(j, z)
        Sel.item(j, image_layer)
        self.image_sel = stat.save_render_sel()

        z = Lay.clone(j, z2)
        z.mode = (MULTIPLY, DIFF, DIFF, MULTIPLY, DIFF, DIFF)[x]

        pdb.gimp_image_reorder_item(j, z, group, len(group.layers))

        z = Lay.add(j, one.k, parent=group, offset=len(group.layers))

        Lay.color_fill(z, (127, 127, 127))

        n = d[ok.EDGE_MODE]

        z = z1 = Lay.merge_group(j, group)
        z.mode = Mode.d[n]

        self.clear_selection(j, z)

        if n == "Burn":
            pdb.gimp_drawable_invert(z, 0)

        else:
            pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        if d[ok.POST_BLUR]:
            pdb.gimp_selection_none(j)
            pdb.gimp_edit_copy_visible(j)
            pdb.gimp_image_remove_layer(j, z)

            z = Lay.paste(j, image_layer)

            Lay.blur(j, z, d[ok.POST_BLUR])
            self.clear_selection(j, z)

        if d[ok.EMBOSS]:
            pdb.gimp_edit_copy_visible(j)

            z2 = Lay.paste(j, z)
            z = Lay.clone(j, z2)
            z.mode = fu.LAYER_MODE_OVERLAY

            pdb.plug_in_emboss(
                j,
                z,
                em.AZIMUTH_45,
                em.ELEVATION_30,
                em.DEPTH_3,
                em.EMBOSS
            )
            Sel.load(j, self.sel)

            for i in (z, z1, z2):
                if pdb.gimp_item_is_valid(i):
                    Lay.clear_sel(j, i, no_sel=0)

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            Sel.load(j, self.image_sel)
            Sel.clear_outside_of_selection(j, z)

        if d[ok.COLORIZE]:
            pdb.gimp_edit_copy_visible(j)

            z1 = z
            z = Lay.paste(j, z)
            z = Lay.clone(j, z)
            z.opacity = d[ok.COLORIZE_OPACITY]

            self.clear_selection(j, z)
            pdb.plug_in_colorify(j, z, d[ok.COLOR])

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            pdb.gimp_image_remove_layer(j, z1)
        z.name = Lay.get_layer_name(nk.FRAME, parent=parent)

    def clear_selection(self, j, z):
        """
        Clear the center selection and the area outside of the image material.

        j: GIMP image
            work-in-progress

        z: layer
            with material to clear
        """
        Sel.load(j, self.image_sel)
        Sel.clear_outside_of_selection(j, z)
        Sel.load(j, self.sel)
        Lay.clear_sel(j, z)
