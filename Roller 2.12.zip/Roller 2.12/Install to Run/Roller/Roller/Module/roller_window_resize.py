#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import PortKey, UIKey, WindowKey
from roller_port_resize import PortResize
from roller_window import RollerWindow


class RWResize(RollerWindow):
    """
    Is a GTK dialog with options for settings the size of an assigned image.
    """
    def __init__(self, g):
        """
        Create a window.

        g: RollerButton
            Is responsible.
        """
        d = {UIKey.WINDOW: g.win.win, UIKey.STAT: g.stat}
        self._button = g
        d[UIKey.WINDOW_TITLE] = "Choose Resize Type"
        d[UIKey.WINDOW_KEY] = WindowKey.RESIZE_CHOOSER

        RollerWindow.__init__(self, d)
        d.update(
            {
                UIKey.ON_ACCEPT: self.do_accept,
                UIKey.ON_CANCEL: self.do_cancel,
                UIKey.WINDOW: self,
                UIKey.PORT_KEY: PortKey.NOT_USED
            }
        )

        self.port = PortResize(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()

    def do_cancel(self, *_):
        """
        Close the window.

        Return: true
            GTK, it is done.
        """
        return self.close()

    def do_accept(self, value):
        """
        Accept the image.

        value: string
            for image button

        Return: true
            GTK, it is done.
        """
        self._button.set_value(str(value))
        return self.close()
