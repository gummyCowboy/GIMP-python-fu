#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import ForWidget
from roller_widget_per_cell_button import PerCellButton
from roller_widget_per_cell_check_button import PerCellCheckButton
import gtk

PAD = 0, ForWidget.MARGIN, ForWidget.MARGIN, ForWidget.MARGIN


class GroupPerCell:
    """
    Has a PortCell window-opener Button and a per-cell CheckButton.
    """

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        d['padding'] = PAD
        hbox = gtk.HBox()
        self.button = d['button'] = PerCellButton(**d)
        self.check_button = self.button.check_button = PerCellCheckButton(**d)

        d['container'].add(hbox)
        hbox.pack_start(self.check_button, expand=False)
        hbox.pack_start(self.button, expand=True)

    def hide(self):
        """Hide both the CheckButton and the open-window Button."""
        self.check_button.hide()
        self.button.widget.hide()

    def show(self):
        """Show both the CheckButton and the open-window Button."""
        self.check_button.show()
        self.button.widget.show()
