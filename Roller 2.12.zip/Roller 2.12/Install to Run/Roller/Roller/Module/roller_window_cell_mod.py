#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import (
    PortKey,
    UIKey,
    WindowKey
)
from roller_port_cell_mod import PortCellMod
from roller_window import RollerWindow


class RollerWindowCellMod(RollerWindow):
    """Draw a cell data modification window."""

    def __init__(self, d, r, c):
        """
        Create window.

        d: dict
            Has init values.
            of PortCell

        r, c: int
            cell position
        """
        d[UIKey.WINDOW_KEY] = WindowKey.CELL_MOD

        RollerWindow.__init__(self, d)
        d.update(
            {
                UIKey.ON_ACCEPT: self.do_accept,
                UIKey.ON_CANCEL: self.do_cancel,
                UIKey.WINDOW: self,
                UIKey.PORT_KEY: PortKey.CELL_MOD,
                UIKey.STAT: d[UIKey.STAT],
                UIKey.WINDOW_TITLE: d[UIKey.WINDOW_TITLE]
            }
        )

        self.port = PortCellMod(d, r, c)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.port.verify_widgets()
        self.win.run()
        self.win.destroy()

    def do_accept(self, *_):
        """
        Close the window.

        Return: true
            The key-press is handled.
        """
        return self.close()

    def do_cancel(self):
        """
        Close the window.

        Return: true
            The key-press is handled.
        """
        return self.close()
