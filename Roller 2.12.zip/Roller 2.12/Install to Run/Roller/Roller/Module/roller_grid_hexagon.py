#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import Rect
from roller_grid import Grid
from roller_one_constant import ForFormat as ff, FormatKey as fk

HORIZONTAL = ff.Cell.Shape.HORIZONTAL_ALIGNED
RATIO = ff.Cell.Shape.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = ff.Cell.Shape.TRIANGLE_SCALE_RATIO_UP


class GridHexagon:
    """
    Calculate the position and the size of cells for a hexagon grid.

    Use a double-spaced grid-type.
    """

    def __init__(self, grid):
        """
        Calculate a hexagon cell-size rectangle and hexagon shape.

        When possible, calculate cell shape with intersects.
        Intersects are points on the grid that two or more hexagons share.
        These points may define a cell, a pocket, or the shape.

        grid: One
            Has init values.
        """
        self.grid = grid
        row, column = grid.r, grid.c
        table = grid.table
        shape = grid.cell_shape
        self.is_double = grid.is_double
        self.is_not_shift = self.is_double == ff.Cell.NOT_SHIFT
        s = grid.layer_space
        x_intersect = self.x_intersect = []
        y_intersect = self.y_intersect = []
        is_horizontal = self.is_horizontal = 1 if shape in HORIZONTAL else 0
        is_hexagon = 1 if shape in ff.Cell.Shape.HEXAGON else 0
        ellipse_space = .135 if not is_hexagon else 0
        x, y = grid.offset

        if grid.grid_type == ff.Grid.Index.CELL_SIZE:
            # cell size:
            w, h = grid.column_width / 1., grid.row_height / 1.

            # table size:
            if is_horizontal:
                w1 = w / 2
                h1 = h * .75
                h2 = h - h1
                s1 = column * w1 + w1, row * h1 + h2

            else:
                w1 = w * .75
                w2 = w - w1
                h1 = h / 2
                s1 = column * w1 + w2, row * h1 + h1
            x, y = Grid.calc_pin_offset(grid.pin, s, s1[0], s1[1], x, y)

        elif grid.grid_type == ff.Grid.Index.SHAPE_COUNT:
            # Calculate 's1', 'w', 'h':
            if is_horizontal:
                # cell size:
                w1 = s[0] / (.5 + column * .5)
                h1 = s[1] / (.25 + row * .75)

                # two possible solutions:
                # solution one:
                _w, _h = h1 * RATIO, h1
                w2 = _w / 2
                h2 = _h * .75
                h3 = _h - h2
                s1 = column * w2 + w2, row * h2 + h3

                # solution two:
                _w1, _h1 = w1, w1 * UP_RATIO
                w2 = _w1 / 2
                h2 = _h1 * .75
                h3 = _h1 - h2
                s2 = column * w2 + w2, row * h2 + h3

            else:
                # vertical, cell size:
                w1 = s[0] / (.25 + column * .75)
                h1 = s[1] / (.5 + row * .5)

                # two possible solutions:
                # solution one:
                _w, _h = h1 * UP_RATIO, h1
                w2 = _w * .75
                w3 = _w - w2
                h2 = _h / 2
                s1 = column * w2 + w3, row * h2 + h2

                # solution two:
                _w1, _h1 = w1, w1 * RATIO
                w2 = _w1 * .75
                w3 = _w1 - w2
                h2 = _h1 / 2
                s2 = column * w2 + w3, row * h2 + h2

            # 'round' will infrequently cause an overflow:
            s1 = int(s1[0]), int(s1[1])
            s2 = int(s2[0]), int(s2[1])

            if s1[0] > s[0] or s1[1] > s[1]:
                s1 = s2
                w, h = _w1, _h1

            else:
                w, h = _w, _h
            x, y = Grid.calc_pin_offset(grid.pin, s, s1[0], s1[1], x, y)

        else:
            # cell count:
            if is_horizontal:
                # Calculate cell size for aligned horizontally:
                w = s[0] / (.5 + column * .5)
                h = s[1] / (.25 + row * .75 - ellipse_space)

            else:
                w = s[0] / (.25 + column * .75 - ellipse_space)
                h = s[1] / (.5 + row * .5)

        width, height = w, h

        if is_horizontal:
            w = width / 2
            h = height * .25
            h1 = height / 2

        else:
            w = width * .25
            w1 = width / 2
            h = height / 2

        # cell rectangle:
        for c in range(column + 4):
            if is_horizontal:
                x_intersect.append(int(round(x)))
                x += w

            else:
                x_intersect.append(int(round(x)))

                x += w

                x_intersect.append(int(round(x)))
                x += w1

        for r in range(row + 4):
            if is_horizontal:
                y_intersect.append(int(round(y)))

                y += h

                y_intersect.append(int(round(y)))
                y += h1

            else:
                y_intersect.append(int(round(y)))
                y += h

        for r in range(row):
            for c in range(column):
                if Form.is_double_space_cell(r, c, self.is_double):
                    if is_horizontal:
                        x, x1 = x_intersect[c], x_intersect[c + 2]
                        y, y1 = y_intersect[r * 2], y_intersect[r * 2 + 3]

                    else:
                        x, x1 = x_intersect[c * 2], x_intersect[c * 2 + 3]
                        y, y1 = y_intersect[r], y_intersect[r + 2]

                    point = x, y
                    size = x1 - x, y1 - y

                    # 'cell' is the cell rectangle before margins:
                    table[r][c].cell = Rect(point, size)
                    if size[0]:
                        table[r][c].plaque = self._do_shape(
                            r,
                            c,
                            with_shape=grid.with_shape
                        )

    def _do_per_cell_horizontal(self, r, c, q):
        """
        Get and calculate the points to draw a horizontal hexagon.

        r, c: int
            cell index

        q: tuple
            top, bottom, left, right

        Return: tuple
            of lists
            x-intersect list, x-pocket list, and
            y-intersect list, y-pocket list
            Each list has strict synchronized points.
        """
        top, bottom, left, right = q
        x_list = [-1] * 6
        y_list = [-1] * 6
        x_list_1 = [0] * 6
        y_list_1 = [0] * 6

        # Get points from intersects.
        # of y:
        if not top:
            y_list[1] = self.y_intersect[r * 2]

        if not bottom:
            y_list[4] = self.y_intersect[r * 2 + 3]

        if not top and bottom:
            y_list[0] = self.y_intersect[r * 2 + 1]
            y_list[5] = self.y_intersect[r * 2 + 2]
            y_list[2] = self.y_intersect[r * 2 + 1]
            y_list[3] = self.y_intersect[r * 2 + 2]

        # of x:
        if not left:
            x_list[0] = self.x_intersect[c]
            x_list[5] = self.x_intersect[c]

        if not right:
            x_list[2] = self.x_intersect[c + 2]
            x_list[3] = self.x_intersect[c + 2]

        if not left and not right:
            x_list[1] = self.x_intersect[c + 1]
            x_list[4] = self.x_intersect[c + 1]

        # Calculate pocket-bound hexagon:
        rect = self.grid.table[r][c].pocket

        # of x:
        x_list_1[0] = x_list_1[5] = rect.x
        x_list_1[2] = x_list_1[3] = rect.x + rect.width
        x_list_1[1] = x_list_1[4] = (x_list_1[0] + x_list_1[2]) // 2

        # of y:
        h = rect.height
        y = y_list_1[1] = rect.y
        y_list_1[4] = y + h
        y_list_1[0] = y_list_1[2] = y + int(round(h * .25))
        y_list_1[5] = y_list_1[3] = y + int(round(h * .75))

        # Return the intersect and pocket-bound points:
        return x_list, x_list_1, y_list, y_list_1

    def _do_per_cell_vertical(self, r, c, q):
        """
        Get and calculate the points to make a vertical hexagon.

        r, c: int
            cell index

        q: tuple
            top, bottom, left, right

        Return: tuple
            of lists
            x-intersect list, x-pocket list, and
            y-intersect list, y-pocket list
            Each list has strict-ordered 'x' and 'y' synchronized points.
        """
        top, bottom, left, right = q
        x_list = [-1] * 6
        y_list = [-1] * 6
        x_list_1 = [0] * 6
        y_list_1 = [0] * 6

        # Get intersect points.
        # of y:
        if not top:
            y_list[1] = y_list[2] = self.y_intersect[r]

        if not bottom:
            y_list[4] = y_list[5] = self.y_intersect[r + 2]

        if not top and not bottom:
            y_list[0] = y_list[3] = self.y_intersect[r + 1]

        # of x:
        if not left:
            x_list[0] = self.x_intersect[c * 2]

        if not right:
            x_list[3] = self.x_intersect[c * 2 + 3]

        if not left and not right:
            x_list[1] = x_list[1] = self.x_intersect[c * 2 + 1]
            x_list[2] = x_list[4] = self.x_intersect[c * 2 + 2]

        # Calculate pocket-bound hexagon:
        rect = self.grid.table[r][c].pocket

        # of x:
        x = x_list_1[0] = rect.x
        x_list_1[3] = rect.x + rect.width
        w = x_list_1[3] - x
        x_list_1[1] = x_list_1[5] = x + int(round(w * .25))
        x_list_1[2] = x_list_1[4] = x + int(round(w * .75))

        # of y:
        y_list_1[1] = y_list_1[2] = rect.y
        y_list_1[5] = y_list_1[4] = rect.y + rect.height
        y_list_1[0] = y_list_1[3] = (y_list_1[1] + y_list_1[5]) // 2

        # Return intersect and pocket-bound point lists:
        return x_list, x_list_1, y_list, y_list_1

    def _do_shape(self, r, c, for_pocket=False, with_shape=False):
        """
        Assemble a hexagon shape.

        r, c: int
            cell index

        for_pocket: flag
            If it's true, the row and column indices are adjusted
            to get values from pocket-oriented intersects.

        with_shape: flag
            If it's true, the 'shape' key is also set with the resulting shape.

        Return: tuple
            shape
        """
        x_i, y_i = self.x_intersect, self.y_intersect
        r1, c1 = r, c

        if self.is_horizontal:
            if for_pocket:
                c *= 3
                r *= 2

            x = x_i[c]
            x1 = x_i[c + 1]
            x2 = x_i[c + 2]
            y = y_i[r * 2]
            y1 = y_i[r * 2 + 1]
            y2 = y_i[r * 2 + 2]
            y3 = y_i[r * 2 + 3]
            q = (
                x, y1,
                x1, y,
                x2, y1,
                x2, y2,
                x1, y3,
                x, y2,
            )

        else:
            if for_pocket:
                r *= 3
                c *= 2

            x = x_i[c * 2]
            x1 = x_i[c * 2 + 1]
            x2 = x_i[c * 2 + 2]
            x3 = x_i[c * 2 + 3]
            y = y_i[r]
            y1 = y_i[r + 1]
            y2 = y_i[r + 2]
            q = (
                x, y1,
                x1, y,
                x2, y,
                x3, y1,
                x2, y2,
                x1, y2
            )

        if with_shape or for_pocket:
            self.grid.table[r1][c1].shape = q
        return q

    def calc_shape_per_cell(self, d):
        """
        Calculate the shape of the hexagon from
        the pocket size on a per cell basis.

        Is part of the GridDeck template.
        """
        for r in range(self.grid.r):
            for c in range(self.grid.c):
                if Form.is_double_space_cell(r, c, self.is_double):
                    rect = self.grid.table[r][c].cell
                    if rect.width:
                        q = d[fk.Cell.Margin.PER_CELL][r][c]
                        q = Form.combine_margin(q, rect.width, rect.height)

                        if self.is_horizontal:
                            q = self._do_per_cell_horizontal(r, c, q)

                        else:
                            q = self._do_per_cell_vertical(r, c, q)

                        x_list, x_list_1, y_list, y_list_1 = q
                        q = zip(x_list, x_list_1)
                        q_x = map(Grid.get_point, q)
                        q = zip(y_list, y_list_1)
                        q_y = map(Grid.get_point, q)
                        q = zip(q_x, q_y)
                        self.grid.table[r][c].shape = [j for i in q for j in i]

    def calc_shape_with_pocket(self):
        """
        Calculate the shape of the hexagon from
        the pocket size using intersects.

        Is part of the GridDeck template.
        """
        x_intersect = self.x_intersect = []
        y_intersect = self.y_intersect = []

        for c in range(self.grid.c):
            if self.grid.r == 1:
                r = 0
                if Form.is_double_space_cell(0, c, self.is_double):
                    rect = self.grid.table[r][c].pocket

                else:
                    rect = Rect((0, 0), (0, 0))

            else:
                r = c % 2 if self.is_not_shift else not c % 2
                rect = self.grid.table[r][c].pocket

            x = rect.x

            x_intersect.append(x)

            if self.is_horizontal:
                w = rect.width // 2
                x_intersect.append(x + w)

            else:
                w = rect.width / 3.
                x_intersect.append(x + int(round(w)))
                x_intersect.append(x + int(round(w + w)))
            x_intersect.append(x + rect.width)

        for r in range(self.grid.r):
            if self.grid.c == 1:
                c = 0
                if Form.is_double_space_cell(r, 0, self.is_double):
                    rect = self.grid.table[r][c].pocket

                else:
                    rect = Rect((0, 0), (0, 0))

            else:
                c = r % 2 if self.is_not_shift else not r % 2
                rect = self.grid.table[r][c].pocket

            y = rect.y

            y_intersect.append(y)

            if self.is_horizontal:
                h = rect.height / 3.
                y_intersect.append(y + int(round(h)))
                y_intersect.append(y + int(round(h + h)))

            else:
                h = rect.height // 2
                y_intersect.append(y + h)
            y_intersect.append(y + rect.height)
        for r in range(self.grid.r):
            for c in range(self.grid.c):
                if Form.is_double_space_cell(r, c, self.is_double):
                    if self.grid.table[r][c].pocket.width:
                        self._do_shape(r, c, for_pocket=True)
