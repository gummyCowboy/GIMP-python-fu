#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerKey
from roller_one_constant import ForGradient as fg, OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

em = Fu.Emboss
pdb = fu.pdb
BRIGHTNESS_0 = 0
CONTRAST_30 = 30
FOUR_COORDINATES = 4


class CosmeticPipe:
    """Create a raised painted-pipe appearance for a border."""

    def __init__(self, one):
        """
        Do frame.

        one: One
            Has variables.
        """
        stat = one.stat
        d = one.d
        j = stat.render.image
        z = Lay.search(one.parent, LayerKey.IMAGE)
        w = d[ok.FRAME_WIDTH]
        group = Lay.group(j, one.k, parent=one.parent)
        z1 = Lay.selectable(j, z, d)

        pdb.gimp_image_reorder_item(j, z1, group, 0)

        z2 = Lay.add(
            j,
            z1.name,
            parent=group,
            offset=pdb.gimp_image_get_item_position(j, z1)
        )

        Lay.color_fill(z2, (255, 255, 255))

        # Make two white layers:
        z3 = Lay.clone(j, z2)

        # one white, one black:
        pdb.gimp_drawable_invert(z3, 0)

        Sel.item(j, z1)
        Sel.grow(j, w, d[ok.FRAME_TYPE])
        Sel.item(j, z1, option=fu.CHANNEL_OP_SUBTRACT)

        # frame selection:
        sel = stat.save_render_sel()

        pdb.gimp_image_remove_layer(j, z1)
        Sel.clear_outside_of_selection(j, z3)

        z1 = pdb.gimp_image_merge_down(j, z3, fu.CLIP_TO_IMAGE)

        pdb.gimp_selection_none(j)
        Lay.blur(j, z1, w * 2)

        pdb.plug_in_emboss(
            j,
            z1,
            d[ok.LIGHT_ANGLE],
            em.ELEVATION_50,
            em.DEPTH_100,
            em.EMBOSS
        )
        Lay.blur(j, z1, w * 1.25)

        z2 = Lay.clone(j, z1)
        z2.mode = fu.LAYER_MODE_HARDLIGHT

        RenderHub.set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_pattern(d[ok.PATTERN])
        pdb.gimp_drawable_edit_bucket_fill(
            z1,
            fu.FILL_PATTERN,
            Fu.BucketFill.X_IS_1,
            Fu.BucketFill.Y_IS_1
        )

        z1 = Lay.merge_group(j, group)

        RenderHub.adjust_mean_value(z1)
        pdb.gimp_curves_spline(
            z1,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 15, 255, 155]
        )

        z1.name = Lay.get_layer_name(LayerKey.FRAME, parent=one.parent)
        Sel.isolate(j, z1, sel)
