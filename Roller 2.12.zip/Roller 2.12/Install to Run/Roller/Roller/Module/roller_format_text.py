#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_base import Comm
from roller_one_constant_fu import Fu
import gimpfu as fu

pdb = fu.pdb


class Text(object):
    """
    Manage text functions.

    Is a static class.
    """

    @staticmethod
    def make_text_layer(
        j,
        z,
        antialias,
        x, y,
        text,
        font_size,
        font,
        color,
        w, h
    ):
        """
        Create a text layer.

        Transform the text layer to fit into a rectangle.

        j: GIMP image
            to receive text layer

        z: layer
            to receive text

        x, y: int
            top-left coordinate of text

        text: string
            to make on text layer

        font_size: int
            font size of text

        font: string
            font name

        color: tuple
            RGB

        w, h: int
            boxed text size

        Return: tuple
            flag, layer

            flag
                Is a success flag, where true equates to success.

            layer
                of the transformed text
                Could be None on failure.
        """
        sel = None
        go = 1
        text = text.decode('utf-8')
        text = text.strip()

        try:
            sel = pdb.gimp_text_fontname(
                j,
                z,
                x,
                y,
                text,
                Fu.TextFontName.BORDER_0,
                antialias,
                font_size,
                fu.PIXELS,
                font
            )

        except Exception:
            Comm.info_msg("Apologies. Roller's text method failed to draw.")
            go = 0

        if go:
            pdb.gimp_floating_sel_to_layer(sel)

            z = j.active_layer

            pdb.gimp_text_layer_set_color(z, color)
            pdb.gimp_text_layer_set_antialias(z, antialias)
            pdb.plug_in_autocrop_layer(j, z)

            # context:
            pdb.gimp_context_set_interpolation(fu.INTERPOLATION_NOHALO)
            pdb.gimp_context_set_transform_direction(fu.TRANSFORM_FORWARD)
            pdb.gimp_context_set_transform_resize(fu.TRANSFORM_RESIZE_ADJUST)

            # Scale back:
            if w:
                pdb.gimp_item_transform_scale(z, 0., 0., w, h)
        return go, z
