#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import ForBackdropStyle, ForLayer, OptionKey, SessionKey
from roller_fu import Lay, Sel
from roller_backdrop_style import BackdropStyle
import gimpfu as fu


class HoneyBee(BackdropStyle):
    """Create a backdrop style with layers of mosaic."""
    name = SessionKey.HONEY_BEE

    def __init__(self, d, stat):
        """
        Begin the backdrop style.

        d: dict
            sub-session dict

        stat: Stat
            global variables
        """
        BackdropStyle.__init__(self, d, stat)

    def _clone_layer(self, j, z):
        """
        Duplicate a layer.

        j: GIMP image
        z: layer

        Return the duplicated layer.
        """
        pdb.gimp_selection_all(j)

        z1 = pdb.gimp_layer_copy(z, 1)

        # Insert the layer above the active layer:
        pdb.gimp_image_set_active_layer(j, z)
        pdb.gimp_image_insert_layer(j, z1, self.group, 0)

        # Perceptual space creates smoother masks:
        pdb.gimp_layer_set_composite_space(
                z,
                fu.LAYER_COLOR_SPACE_RGB_PERCEPTUAL
            )

        # Copies the mask, but it's not needed:
        if z1.mask:
            z1.remove_mask(fu.MASK_DISCARD)

        pdb.gimp_selection_none(j)
        return z1

    def _create_polar_mask_selections(self, j, mask_count, is_darks=False):
        """
        Create a base mask, either light or dark.

        j: GIMP image
        is_darks: flag
            If it's true, the group is for the darks-type masks.

        Return a list of polar-type selections.
        """
        n = "Darks" if is_darks else "Lights"
        z = self._clone_layer(j, self.layer)
        selections = []

        pdb.gimp_drawable_desaturate(z, fu.DESATURATE_LUMINANCE)

        if is_darks:
            pdb.gimp_drawable_invert(z, 0)

        channel = pdb.gimp_channel_new_from_component(
                j,
                fu.CHANNEL_RED,
                n,
            )

        pdb.gimp_image_insert_channel(
                j,
                channel,
                None,
                0
            )

        # Select channel to get grayscale pixels where black
        # equates to transparent and white to opaque.
        pdb.gimp_image_select_item(j, fu.CHANNEL_OP_REPLACE, channel)
        selections.append(pdb.gimp_selection_save(j))

        mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)

        pdb.gimp_layer_add_mask(z, mask)

        if mask_count > 1:
            for _ in range(mask_count - 1):
                Sel.invert(j)
                replace_sel = pdb.gimp_selection_save(j)

                # Restore the original selection:
                Sel.invert(j)

                # Subtract inverted selection:
                pdb.gimp_image_select_item(
                        j,
                        fu.CHANNEL_OP_SUBTRACT,
                        replace_sel
                    )

                # The selection will make the mask:
                selections.append(pdb.gimp_selection_save(j))
                pdb.gimp_image_remove_channel(j, replace_sel)

        pdb.gimp_image_remove_layer(j, z)
        pdb.gimp_image_remove_channel(j, channel)
        return selections

    def _create_polar_mask_layers(self, j, selections, mask_index):
        """
        Create the mask layer from the selections.

        j: GIMP image
        selections: iterable
            list of selections that create masks

        mask_index: int
            0: light, 1: dark
        """
        z = self.layer
        mask_name = ("Lights", "Darks")[mask_index]
        for i in selections:
            z = self._clone_layer(j, z)
            z.name = mask_name

            # Load selection for mask:
            pdb.gimp_image_select_item(j, fu.CHANNEL_OP_REPLACE, i)

            # Create the mask from the selection:
            mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)

            pdb.gimp_layer_add_mask(z, mask)
        return z

    @staticmethod
    def _do_mosaic(d, j, z):
        """
        Creates a mosaic pattern.

        j: GIMP image
        z: layer
            Receives mosaic.
        """
        ok = OptionKey
        pdb.plug_in_mosaic(
                j,
                z,
                d[ok.MESH_SIZE],
                4,
                1,
                d[ok.NEATNESS],
                0,
                45,
                .0,
                .2,
                1,
                ForBackdropStyle.MESH_TYPE.index(d[ok.MESH_TYPE]),
                0,
                0
            )

    def do(self, d):
        """
        Is part of a RenderHub class template.

        d: sub-session dict
        """
        j = self.stat.render
        ok = OptionKey
        light_selections = []
        dark_selections = []
        self.group = Lay.group(j, self.name)
        self.group.mode = fu.LAYER_MODE_PASS_THROUGH
        self.layer = plasma_layer = Lay.clone(j, self.active.layer)

        pdb.plug_in_plasma(j, self.layer, d[ok.RANDOM_SEED], 3)

        # Create alternate textures for light and dark:
        light_selections = self._create_polar_mask_selections(
                j,
                1,
                is_darks=False
            )

        dark_selections = self._create_polar_mask_selections(
                j,
                1,
                is_darks=True
            )

        z = self._create_polar_mask_layers(j, light_selections, 0)

        Lay.color_fill(z, (255, 255, 0))
        pdb.script_fu_clothify(j, z, 0, 0, 90, 70, 1)

        z = self._create_polar_mask_layers(j, dark_selections, 1)

        Lay.color_fill(z, (0, 255, 255))
        pdb.plug_in_engrave(j, z, 6, 1)

        z = Lay.clone(j, self.layer)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        Lay.order(j, z, self.group, a=0)
        Lay.invert(z)

        z = Lay.eat(j, self.group)

        # Create additional textures for previous texture:
        self.group = Lay.group(j, self.name)
        self.group.mode = fu.LAYER_MODE_PASS_THROUGH

        Lay.order(j, z, self.group)

        z = Lay.clone(j, z)

        pdb.plug_in_emboss(j, z, 45, 30, 1, 1)

        z = first = self.layer = Lay.eat(j, self.group)
        keep_layer = Lay.clone(j, z)

        Lay.blur(j, keep_layer, 33)

        keep_layer.opacity = 50.
        keep_layer.mode = fu.LAYER_MODE_BURN
        self.group = Lay.group(j, self.name)

        Lay.order(j, z, self.group)

        light_selections = self._create_polar_mask_selections(
                j,
                1,
                is_darks=False
            )

        dark_selections = self._create_polar_mask_selections(
                j,
                1,
                is_darks=True
            )

        z = self._create_polar_mask_layers(j, light_selections, 0)
        z.mode = fu.LAYER_MODE_OVERLAY

        z = self._create_polar_mask_layers(j, dark_selections, 1)
        z.mode = fu.LAYER_MODE_BURN

        HoneyBee._do_mosaic(d, j, z)

        z1 = Lay.clone(j, first)

        Lay.order(j, z1, self.group, 0)

        z1.mode = fu.LAYER_MODE_BURN

        Lay.kopy(j)

        z = Lay.paste(j, z1)

        Lay.blur(j, z1, 30)

        z1.mode = fu.LAYER_MODE_EXCLUSION

        HoneyBee._do_mosaic(d, j, z)

        z = Lay.clone(j, z)

        Lay.invert(z)

        z = Lay.eat(j, self.group)

        # Make the mosaic translucent:
        pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        self.group = Lay.group(j, self.name)

        Lay.order(j, z, self.group)

        z = Lay.clone(j, z)

        Lay.blur(j, plasma_layer, 120)
        pdb.gimp_drawable_desaturate(plasma_layer, fu.DESATURATE_LUMINANCE)
        plasma_layer.mode = fu.LAYER_MODE_HSV_VALUE

        # Use shadow to add depth:
        z1 = Lay.eat(j, self.group)
        z = self.do_shadow(
                z1,
                0,
                0,
                20,
                (0, 0, 0),
                600,
                d=ForLayer.INHERIT_DICT
            )

        z.mode = fu.LAYER_MODE_SPLIT

        Lay.kopy(j)
        Lay.bury(j, z)

        z = Lay.paste(j, z1)
        z.mode = fu.LAYER_MODE_SUBTRACT
        z = Lay.clone(j, self.active.layer)

        Lay.color_fill(z, (127, 127, 127))
        Lay.hide(self.active.layer)

        z = pdb.gimp_image_merge_visible_layers(j, fu.CLIP_TO_IMAGE)

        Lay.show(self.active.layer)
        self.finish_style(z)
