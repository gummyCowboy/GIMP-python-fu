#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import OptionKey, SessionKey
from roller_fu import Lay
from roller_backdrop_style import BackdropStyle
import gimpfu as fu


class RockyLanding(BackdropStyle):
    """
    Create a glassy grid with channels of running with liquid color.
    """
    name = SessionKey.ROCKY_LANDING

    def __init__(
                self,
                d,
                stat,
            ):
        """
        Begin the Rocky Landing backdrop style.

        d: dict
            sub-session dict

        stat: Stat
            global variables
        """
        BackdropStyle.__init__(self, d, stat)

    def do(self, d):
        """
        Mix up a batch of plasma with edge, color erase, and chroma.

        Is part of a RenderHub class template.

        d: dict
            sub-session dict
        """
        j = self.stat.render
        ok = OptionKey
        z = Lay.clone(j, self.active.layer)
        group = Lay.group(j, self.name)

        Lay.order(j, z, group)
        pdb.plug_in_plasma(j, z, d[ok.RANDOM_SEED], 3)

        z1 = Lay.clone(j, z)

        Lay.color_fill(z, (0, 0, 0))

        z = Lay.clone(j, z1)
        z = self.do_edge(j, z, fu.LAYER_MODE_SUBTRACT)
        z = self.do_edge(j, z, fu.LAYER_MODE_LCH_HUE)

        for _ in range(d[ok.BLEND]):
            z = self.do_edge(j, z, fu.LAYER_MODE_COLOR_ERASE)
            z = self.do_edge(j, z, fu.LAYER_MODE_LCH_CHROMA)

        z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
        z1 = Lay.clone(j, z)

        pdb.plug_in_emboss(j, z1, 45, 30., 1, 1)

        z1.mode = fu.LAYER_MODE_OVERLAY

        Lay.invert(z1)

        z = Lay.clone(j, z1)

        pdb.plug_in_despeckle(j, z1, 1, 1, 200, 255)
        Lay.move(z, 0, 2)
        pdb.plug_in_sobel(j, z, 1, 0, 0)

        z.opacity = 83.
        z1.mode = fu.LAYER_MODE_NORMAL
        z1.opacity = 33.

        Lay.order(j, z1, group, a=3)

        z = Lay.eat(j, group)

        Lay.clip(z)
        self.finish_style(z)

    def do_edge(self, j, z, mode):
        """
        Shred the layer with edge and a layer mode.

        j: GIMP image
        z: layer
            layer that is modified

        mode: enum
            layer mode

        Return the modified layer.
        """
        pdb.plug_in_edge(
                j,
                z,
                1.,
                0,
                0
            )

        z.mode = mode
        z = Lay.merge(j, z)
        return Lay.clone(j, z)
