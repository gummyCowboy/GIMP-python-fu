#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from random import randint, seed, uniform
from roller_constant import OptionKey, SessionKey
from roller_fu import Lay
from roller_colored_grid import ColoredGrid
from roller_backdrop_style import BackdropStyle
from roller_base import Base
import gimpfu as fu


class GlassGaw(BackdropStyle):
    """
    Create a glassy grid with channels of running with liquid color.
    """
    name = SessionKey.GLASS_GAW

    def __init__(
                self,
                d,
                stat,
            ):
        """
        d: sub-session dict
            color grid variables

        stat: Stat
            global variables
        """
        BackdropStyle.__init__(self, d, stat)

    def do(self, d):
        """
        Draw a colored grid over the backdrop image.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        j = self.stat.render
        ok = OptionKey
        e = deepcopy(self.stat.session[SessionKey.COLORED_GRID])
        z = Lay.clone(j, self.active.layer)
        e[ok.MODE] = "Normal"
        e[ok.OPACITY] = 100
        e[ok.ROTATE] = 0
        e[ok.THRESHOLD] = 1.
        e[ok.INVERT] = 0

        # Plant the seed that makes the style reproducible:
        seed(d[ok.RANDOM_SEED])

        for i in range(4):
            z = self.do_grid(e, merge=i != 0)
            z1 = Lay.get_active(j)
            z = Lay.clone(j, z1)

        pdb.plug_in_edge(
                j,
                z,
                1.,
                0,
                0
            )

        z2 = Lay.clone(j, z1)
        Lay.blur(j, z2, 20)
        z2.mode = fu.LAYER_MODE_DIFFERENCE
        z3 = Lay.clone(j, z2)
        z4 = Lay.clone(j, z3)
        z4.mode = fu.LAYER_MODE_GRAIN_EXTRACT
        z.mode = fu.LAYER_MODE_DARKEN_ONLY

        Lay.invert(z)
        Lay.blur(j, z, 4)
        pdb.plug_in_unsharp_mask(j, z1, 3., .16, 0)

        group = Lay.group(j, self.name)

        for i in (z1, z3, z2, z4, z):
            Lay.order(j, i, group, a=0)

        z5 = Lay.clone(j, z)
        for _ in range(2):
            pdb.plug_in_erode(j, z5, 1, 7, 1., 7, 0, 128)

        Lay.blur(j, z5, 90)

        z5.mode = fu.LAYER_MODE_MULTIPLY
        z = Lay.eat(j, group)
        self.finish_style(z)

    def do_waves(self, z):
        """
        Do waves on layer.

        z: layer
            Receive wave.
        """
        pdb.plug_in_waves(
                self.stat.render,
                z,
                randint(1, 12),
                1,
                uniform(24., 50.),
                0,
                1
            )

    def do_grid(self, d, merge=1):
        """
        Mixes random grid overlays with waves.

        """
        ok = OptionKey
        j = self.stat.render
        d[ok.ROW] = randint(2, 6)
        d[ok.COLUMN] = randint(2, 6)
        d[ok.COLOR_1] = Base.rnd_col()
        d[ok.COLOR_2] = Base.rnd_col()

        ColoredGrid(
                d,
                self.stat,
                name=self.name,
                layer_key=self.name,
                no_save=1
            )
        z = Lay.get_active(j)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        self.do_waves(z)
        if merge:
            z = Lay.merge(j, z)
            self.do_waves(z)
        return z
