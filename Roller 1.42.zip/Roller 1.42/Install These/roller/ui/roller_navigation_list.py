#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForColor, ForWidget, SessionKey
from roller_box import RollerBox
from roller_widget import Widget
import gtk


class NavigationList(Widget):
    """
    This is widget group with TreeView and TreeView manipulation Buttons.

    Use the NavigationList class template to
    hook feedback from the NavigationList:
        on_list_change: function
            Call when the navigation list changes.
    """

    def __init__(self, g, creator, header="Groups:"):
        """
        Adds the format list and Buttons to a group.

        g: container
        d: widget dict
        creator: class instance
            the one that created the format list

        column_header: string
            navigation-type title
        """
        w = ForWidget.MARGIN
        self.creator = creator
        g1 = RollerBox(ForWidget.HBOX)

        # Format Stack TreeView:
        self.list_store = gtk.ListStore(str, str, str)

        treeview = gtk.TreeView(model=self.list_store)
        treeview.set_headers_visible = 0

        Widget.__init__(
                self,
                creator.on_list_change,
                key=SessionKey.FORMAT_LIST,
                widget=treeview
            )

        # Create column:
        col = gtk.TreeViewColumn(
            header, gtk.CellRendererText(), text=0, foreground=1, background=2)

        col.set_min_width(150)
        col.set_sizing(gtk.TREE_VIEW_COLUMN_AUTOSIZE)

        # Add column to TreeView:
        treeview.append_column(col)

        # When a row is selected, it emits a signal:
        treeview.get_selection().connect('changed', self.selected)
        g1.alignment.set_padding(w / 2, w, w, w)

        # Hide the column header:
        col.set_widget(gtk.Label(""))

        g1.add(treeview)
        g.add(g1.alignment)

    def get_sel_x(self):
        """Return the row index of the selected item."""
        return self.wig.get_selection().get_selected_rows()[1][0][0]

    def selected(self, _):
        self.creator.on_list_change(self.get_sel_x())

    def populate_treeview(self, q):
        """
        Populate the TreeView from a list.
        The previous indexed-list is replaced.

        q: list of string
        """
        self.list_store.clear()
        for n in q:
            self.list_store.append(
                    [n, '#000000', ForColor.SINGLE_CELL_COLOR]
                )

    def select_item(self, x):
        """
        Select, sort of, a TreeView item.

        x: row index in the TreeView
        """
        self.wig.set_cursor(x)

    def set_value(self, q):
        """
        Load the format list from a session dictionary's list of formats.

        Is part of a UI widget template.

        q: list of formats from the session dict
        """
        self.populate_treeview(q)
