#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_button import RollerButton
from roller_check_button import RollerCheckButton


class GroupPerCell(RollerCheckButton):
    """
    Has a UICell window opener Button and a per-cell CheckButton.
    """

    def __init__(
                self,
                checkbutton_action,
                button_action,
                text,
                checkbutton_key,
                container,
                cell_table_key,
            ):
        """
        checkbutton_action: function
            Call on Per Cell CheckButton action.

        button_action: function
            Call on Button action.

        text: string
            Button label

        checkbutton_key: string
            CheckButton's key

        container: object
            Widget or GTK container

        cell_table_key: string
            key to UICell window in "ForCell.CELL_TABLE_DICT"
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        self.key = checkbutton_key
        self.update_window_for_checkbutton = checkbutton_action
        self.update_window_for_button = button_action
        self.cell_table_key = cell_table_key
        p = self.on_check_button_change
        p1 = self.on_button_action
        self._button = RollerButton(text, p1, padding=(w1, w, w, w))

        RollerCheckButton.__init__(
                self,
                "Per Cell",
                p,
                key=checkbutton_key,
                padding=(w1, w1, w, w)
            )

        container.pack_start(self.alignment, expand=False)
        container.pack_start(self._button.alignment, expand=False)
        self.verify_button()

    def on_check_button_change(self, g):
        """
        Intercept signals from the CheckButton.

        g: CheckButton widget
        """
        self.verify_button()
        self.update_window_for_checkbutton(g)

    def on_button_action(self, _):
        """Intercept changed signal from the Button."""
        self.update_window_for_button(self.cell_table_key)

    def set_value(self, a):
        """
        Set the value of the CheckButton and is part of a UI widget template.

        Verify the cell window opener button.

        a: int
        """
        RollerCheckButton.set_value(self, a)
        self.verify_button()

    def verify_button(self):
        """
        The cell window Button is valid only if the CheckButton is checked.
        """
        self._button.enable() if self.get_value() else self._button.disable()
