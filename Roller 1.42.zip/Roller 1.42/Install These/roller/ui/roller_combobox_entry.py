#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_combo import RollerCombo
import gtk


class RollerComboBoxEntry(RollerCombo):
    """
    This ComboBox displays options and text using an Entry.
    The combobox doesn't have separator capability.
    """

    def __init__(self, on_change, **d):
        """
        Create the gtk.ComboBoxEntry.

        The Entry widget will display text not in the drop-menu.

        on_change: function
            Call on change.

        d: dict
            widget dict
        """
        RollerCombo.__init__(self, on_change, gtk.ComboBoxEntry, **d)
        self.wig.child.connect('changed', self.callback)

    def get_text(self):
        """
        Return the value displayed in the Entry.

        The text may or may not be a row in the drop-menu.

        n: text
        """
        return self.wig.child.get_text()

    def set_text(self, n):
        """
        Set the text in the Entry.

        The text does not have to be a row in the drop-menu.

        n: text
        """
        self.wig.child.set_text(n)
