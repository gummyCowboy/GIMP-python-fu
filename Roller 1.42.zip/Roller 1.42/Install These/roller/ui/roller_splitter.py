#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_box import RollerBox
import gtk


class Splitter:
    """Create two equal sized vertical boxes on the x-axis."""

    def __init__(self, padding=None, has_inner_padding=False):
        """
        padding: tuple of int
            Alignment padding (top, bottom, left, right)

        has_inner_padding: flag
            If true, the inner boxes are padded.
        """
        self.box = self.container = gtk.HBox()

        if padding:
            g = self.container = gtk.Alignment(0, 0, 1, 0)
            g.add(self.box)
            g.set_padding(*padding)

        g1 = RollerBox(ForWidget.VBOX, align=(0, 0, 1, 0))
        g2 = RollerBox(ForWidget.VBOX, align=(0, 0, 1, 0))
        self.left, self.right = g1.box, g2.box
        g3 = self.left_a = g1.alignment
        g4 = self.right_a = g2.alignment
        if has_inner_padding:
            w = ForWidget.MARGIN / 2
            g3.set_padding(0, 0, 0, w)
            g4.set_padding(0, 0, w, 0)

    def both(self, g, g1):
        """
        Add two widgets to the Splitter.

        g: left widget
        g1: right widget
        """
        self.left.add(g)
        self.right.add(g1)

    def no_pack(self):
        """Add the two Alignment objects to the box."""
        self.box.add(self.left_a)
        self.box.add(self.right_a)

    def pack(self):
        """
        Make the the two VBoxes the same size.
        Add the same-sized VBoxes to the HBox.

        Call after all of the widgets have been added to the Splitter.
        """
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

        # Transform size:
        for g in (self.left_a, self.right_a):
            same_size.add_widget(g)

        g = reversed(same_size.get_widgets())
        [self.box.add(g1) for g1 in g]
