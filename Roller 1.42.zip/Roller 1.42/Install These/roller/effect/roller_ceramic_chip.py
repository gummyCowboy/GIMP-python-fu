#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from random import seed
from roller_constant import ForBackdropStyle, OptionKey, SessionKey
from roller_border_line import BorderLine
from roller_fu import Lay, Sel
import gimpfu as fu


class CeramicChip(BorderLine):
    """Create a frame with colorful transparent glass."""
    name = SessionKey.CERAMIC_CHIP
    filler_width_low, filler_width_high = 25, 35

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        BorderLine.__init__(
                self,
                d,
                stat,
                name=SessionKey.CERAMIC_CHIP,
                filler=self.do_job,
                has_filler_shadow=True,
                reflect=1
            )

    def do_job(self, z, d):
        """
        Draw the ceramic chip.

        z: layer
        d: sub-session dict

        Return the ceramic layer.
        """
        # A random sequence will reproduce itself given the same seed:
        j = self.stat.render
        ok = OptionKey

        seed(d[ok.RANDOM_SEED])

        z = Lay.add(j, self.name, z=self.group)
        a = min(20, self.stat.width, self.stat.height)
        z = self.draw_color_rectangles(j, z, a, a)
        z.name = Lay.get_layer_name(self.name, self.stat)

        Sel.all(j)
        pdb.plug_in_waves(j, z, 10, 1, 50, 0, 1)
        pdb.plug_in_mosaic(
                j,
                z,
                30,
                1,
                .1,
                .5,
                0,
                d[ok.LIGHT_ANGLE],
                .0,
                1,
                1,
                ForBackdropStyle.MESH_TYPE.index(d[ok.MESH_TYPE]),
                0,
                0
            )

        z = Lay.clone(j, z)
        z.opacity = 50.
        z.mode = fu.LAYER_MODE_LCH_COLOR

        pdb.plug_in_colorify(j, z, d[ok.COLOR_1])

        z = Lay.merge(j, z)

        Sel.isolate(j, z, self.fill_sel)
        return z
