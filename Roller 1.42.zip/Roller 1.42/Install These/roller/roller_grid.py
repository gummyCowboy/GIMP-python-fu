#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_base import Base


class Grid:
    """
    Calculate the coordinates and the size of cells.

    Cells are created when a canvas is divided by rows and columns.
    """

    def __init__(self, s, r, c):
        """
        s: (w, h) of int
            size of the grid

        r, c: int
            row and column scale of the grid

        w, h: int
            render size
        """
        r, c = min(r, s[1]), min(c, s[0])
        self.r, self.c = r, c

        # Calculate cell size.
        # Converting to float prevents int underflow:
        w = self.w = int(max(s[0] / 1.0 / c, 1))
        h = self.h = int(max(s[1] / 1.0 / r, 1))

        # Calculate remainders:
        rx = self.rx = s[0] % c
        ry = self.ry = s[1] % r
        q = self._table = Base.create_2d_table(r, c)
        x = y = 0

        # "ax" and "ay" are insertion points for the remainders.
        # Each insertion point's range is (0..1).
        #
        # Cells are compared with the insertion points by their
        # position along both axis. The cell's position point
        # is the cell's bottom-right point in a row and column position.
        # The cell position points are relative to their axis
        # and range from zero to one (0..1).
        ay = ay1 = 1 / (ry + 1.) if ry else 2
        ax1 = 1 / (rx + 1.) if rx else 2
        f, f1 = r / 1., c / 1.

        for r1 in range(r):
            ax = ax1
            h1 = 0

            if (r1 + 1) / f >= ay:
                h1 = 1
                ay = ay + ay1 if ay + ay1 < .9999999 else 2

            for c1 in range(c):
                w1 = 0
                if (c1 + 1) / f1 >= ax:
                    w1 = 1
                    ax = ax + ax1 if ax + ax1 < .9999999 else 2

                q[r1][c1] = x, y, w + w1, h + h1
                x += w + w1

            x = 0
            y += h + h1

    def block(self, u, v):
        """
        Use when cells are merged, and the merge
        cell's dimension needs to be determined.

        u: (r, c) of int
            top-left cell

        v: (r, c) of int
            bottom-right cell

        Return the top-left coordinates and the scale of an array of cells.
        """
        r1, c1 = u
        x, y, _, _ = self.cell(r1, c1)

        x1, y1, _, _ = self.cell(r1, c1)
        x2, y2, w3, h3 = self.cell(v[0], v[1])

        w = x2 - x1 + w3
        h = y2 - y1 + h3
        return x, y, w, h

    def cell(self, r, c):
        """Return the x, y, w, h of a cell at r, c."""
        return self._table[r][c]
