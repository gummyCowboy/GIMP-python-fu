#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_key import BackdropStyle as by, Option as ok, Widget as wk
from roller_def_act import scour
from roller_def_backdrop_style import MEAN_COLOR
from roller_def_dialog import BACKING
from roller_def_option import SWITCH
from roller_widget_option_button import OptionListButton
from roller_port_option_list import PortStyle

# Define Backdrop Preset.
BACKDROP = OrderedDict([
    (ok.BACKING, deepcopy(BACKING)),
    (ok.BACKDROP_STYLE, {
        wk.STILL: True,
        wk.DIALOG: PortStyle,
        wk.VAL: {
            ok.SWITCH: SWITCH[wk.VAL],
            by.MEAN_COLOR: scour({}, MEAN_COLOR, wk.VAL)
        },
        wk.WIDGET: OptionListButton
    })
])
