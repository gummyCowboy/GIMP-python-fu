#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_a_contain import Globe, PlanZ, Run
from roller_fu import hide_layer, show_layer, validate_item
from roller_one_extract import get_model_list_group


def do_work_step(step_q):
    """
    Perform a peek, preview or finish the render.

    step_q: list
        [Step key, ...]
    """
    def _refresh():
        # Remove selection because the marching ants are slow to draw.
        # Flushing the display will fail if ignored for too long.
        if Run.j:
            pdb.gimp_selection_none(Run.j)
            pdb.gimp_displays_flush()

    is_ice = Globe.hide_layer

    show_work()
    hide_plan()

    # [(navigation step key: AnyGroup)], 'step_q'
    for k, any_group in step_q:
        if is_ice:
            # Freeze GIMP's Layers dock and hide layers.
            if Run.j:
                pdb.gimp_image_freeze_layers(Run.j)
                is_ice = False
                Run.is_frozen = True

        any_group.do()
        _refresh()

    if Run.j:
        z = Run.j.layers[-1]

        if validate_item(z):
            Run.j.active_layer = z
        if Run.is_frozen:
            pdb.gimp_image_thaw_layers(Run.j)
            Run.is_frozen = False
    _refresh()


def hide_plan():
    """Hide the Plan group."""
    z = PlanZ.plan_group
    if validate_item(z):
        hide_layer(z)
        pdb.gimp_displays_flush()


def show_work():
    """Show the Work group."""
    j = Run.j
    if j and j.layers:
        z = j.layers[-1]
        if z and z is not PlanZ.plan_group and validate_item(z):
            if not z.visible:
                show_layer(z)

                model_group = get_model_list_group()
                q = model_group.work.get_model_folder_list()

                for i in q:
                    show_layer(i)
                pdb.gimp_displays_flush()
