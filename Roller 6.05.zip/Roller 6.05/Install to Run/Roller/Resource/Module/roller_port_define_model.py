#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_a_contain import Dog
from roller_constant_for import Signal as si, Widget as fw
from roller_constant_key import (
    Group as gk,
    Item as ie,
    Model as md,
    ModelList as ml,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_one_helm import Helm
from roller_one_ring import Ring
from roller_one_shelf import Shelf
from roller_port_preview import PortPreview
from roller_view_step import get_model_branch
from roller_widget_box import Box as boxer
from roller_widget_check_button import CheckButton
from roller_widget_label import Label
from roller_widget_node import Piece
from roller_widget_row import SelectRow
import gtk  # type: ignore

CANVAS = (
    ie.MARGIN, ie.PLAQUE, ie.FRINGE, ie.BORDER, ie.IMAGE, ie.LINE, ie.CAPTION
)
CELL = (ie.SHIFT,) + CANVAS
FACING = ie.PLAQUE, ie.FRINGE, ie.BORDER, ie.IMAGE, ie.LINE, ie.CAPTION
MODEL_BRANCH = {
    md.BOX: OrderedDict([
        (ie.CANVAS, CANVAS),
        (ie.CELL, CELL),
        (ie.FACE, FACING)
    ]),
    md.CELL: {ie.CELL: CELL},
    md.PYRAMID: OrderedDict([(ie.CANVAS, CANVAS), (ie.CELL, CELL)]),
    md.SIDEWALK: OrderedDict([
        (ie.CANVAS, CANVAS),
        (ie.CELL, CELL),
        (ie.FACING, FACING)
    ]),
    md.STACK: {ie.CELL: CELL},
    md.TABLE: OrderedDict([(ie.CANVAS, CANVAS), (ie.CELL, CELL)])
}
TEXT_DEFINE = "Choose Model Step for a new {} Model."
TEXT_REVISE = "Choose Model Step for the {} Model."


class PortDefineModel(PortPreview):
    """Create a Widget display for Model step membership."""
    window_key = "Define Model"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        self.model_type = None
        self._init_d = d
        self.model_list_g = Helm.get_group(
            sk.MODEL
        ).widget_d[ok.MODEL_LIST]
        PortPreview.__init__(self, d, g)

    def draw_model_option(self, box, label_text):
        """
        Draw step CheckButton.

        box: GTK container
            to receive group
        """
        self.is_dirt = True
        w = fw.MARGIN
        padding = w, w, w, w
        buttons = self.widget_q = []
        piece = Piece(
            gk.DEFINE_MODEL,
            box,
            self.repo.any_group.item,
            group_type='preset',
            has_label=False
        )

        piece.vbox.add(
            Label(
                **{
                    wk.PADDING: padding,
                    wk.TEXT: label_text.format(self.model_type)
                }
            )
        )

        d = {wk.STILL: True, wk.RELAY: []}

        d.update(self._init_d)

        for branch, q in MODEL_BRANCH[self.model_type].items():
            piece.vbox.add(
                Label(**{wk.PADDING: padding, wk.TEXT: "\n{}".format(branch)})
            )

            vbox_list = boxer(), boxer(), boxer()
            hbox = gtk.HBox()

            piece.vbox.add(hbox)

            for i in range(3):
                hbox.add(vbox_list[i])
            for x, i in enumerate(q):
                d[wk.KEY] = md.CHECKBUTTON_KEY.format(i, branch)
                d[wk.TEXT] = i
                buttons.append(CheckButton(padding=(0, 0, w, w), **d))
                vbox_list[x % 3].add(buttons[-1])

        piece.vbox.add(
            Label(**{wk.PADDING: padding, wk.TEXT: "\n"})
        )
        self.any_group = Dog.loner_group(
            **{
                wk.COLOR: self.color,
                wk.IS_DEFAULT: False,
                wk.ITEM: piece,
                wk.PADDING: padding,
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win
            }
        )

    def draw_selector(self, box):
        """
        Create a WidgetRow with two select options.

        box: GTK container
            to receive group
        """
        self._init_d[wk.RELAY] = []
        box.add(SelectRow(self.widget_q, **self._init_d))

    def draw(self):
        """Draw the Port's Widgets."""
        self.draw_column((
            self.draw_define_model, self.draw_selector, self.draw_basic_process
        ))

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return lambda: None, self.on_accept_define_model

    def on_accept_define_model(self, g):
        """
        Modify the navigation tree with a new tree of steps.

        g: Button
            Is responsible.
        """
        q = self.widget_q
        Ring.plug(
            si.MODEL_NEW, {q[x].key: q[x].get_a() for x in range(len(q))}
        )


class PortNewModel(PortDefineModel):
    """Initial the model's available steps."""

    def __init__(self, *q):
        PortDefineModel.__init__(self, *q)

    def draw_define_model(self, box):
        """
        Draw step CheckButton.

        box: GTK container
            to receive group
        """
        self.model_type = self.model_list_g.get_model_type_item()
        self.draw_model_option(box, TEXT_DEFINE)

    def on_accept_define_model(self, g):
        """
        Modify the navigation tree with a new tree of steps.

        g: Button
            Is responsible.
        """
        q = self.widget_q
        Ring.plug(
            si.MODEL_NEW, {q[x].key: q[x].get_a() for x in range(len(q))}
        )


class PortReviseModel(PortDefineModel):
    """Initial the model's available steps."""

    def __init__(self, *q):
        # [branch key] of the selected Model's
        # available step, '_previous_step_q'.
        self.model_name = self._previous_step_q = None

        PortDefineModel.__init__(self, *q)

    def draw_define_model(self, box):
        """
        Override the base class function so
        that step CheckButton can be initialized.

        box: GTK container
            Receive Widget group.
        """
        n = self.model_name = self.model_list_g.get_selected_name()

        for i in self.model_list_g.get_model_def():
            if i[ml.NAME_INDEX] == n:
                self.model_type = i[ml.TYPE_INDEX]
                break

        self.draw_model_option(box, TEXT_REVISE)

        q = get_model_branch(n)

        # list off the Model's shelved panel step key, 'q1'
        q1 = Shelf.get_model_step_q(n)

        # Clip the root branch from the navigation step key.
        # length of a model step key with a Model Preset option, '3'
        q = [i[1:] for i in q if len(i) == 3]
        q += [i[1:] for i in q1 if len(i) == 3]

        # Convert the branch key to a Define Model CheckButton key.
        q = self._previous_step_q = [
            md.CHECKBUTTON_KEY.format(i[1], i[0]) for i in q
        ]

        # Create a list of CheckButton key.
        key_d = {i.key: i for i in self.widget_q}

        # Set CheckButton value if the branch key is available to the user.
        for i in q:
            if i in key_d.keys():
                key_d[i].set_a(1)

    def on_accept_define_model(self, g):
        """
        Modify the navigation tree with the new tree of steps.

        g: Button
            Is responsible.
        """
        q = self.widget_q
        Ring.plug(
            si.MODEL_REVISE,
            (
                {q[x].key: q[x].get_a() for x in range(len(q))},
                self._previous_step_q,
                self.model_name
            )
        )
