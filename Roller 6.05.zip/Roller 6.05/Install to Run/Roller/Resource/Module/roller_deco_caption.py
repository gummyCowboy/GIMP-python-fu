#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, pdb  # type: ignore
from roller_a_contain import Cat, Deco, Run
from roller_constant_for import Caption as pt, Justification as ju, Model as mo
from roller_constant_key import Option as ok
from roller_deco import ready_canvas_rect, ready_shape, transform_foam
from roller_fu import (
    add_layer,
    add_layer_below,
    clear_inverse_selection,
    get_select_coord,
    make_layer_group,
    make_text_layer,
    remove_z,
    select_item,
    select_shape,
    verify_layer,
    verify_layer_group
)
from roller_fu_comm import info_msg
from roller_view_hub import do_mod
from roller_view_preset import calc_margin
from roller_view_real import get_light


def create_cell(maya, d, group, is_main=False):
    """
    Draw text for Cell/Caption/Per.

    maya: Maya
    d: dict
        Caption Preset

    group: layer
        Is the parent parent layer group of cell output.

    is_main: bool
        If True, then the output layer can skip the finish check.

    Return: layer or None
        text
    """
    ready_shape(maya, d, option=None)

    z = draw_text(maya, d, group, maya.k)

    if is_main:
        return z
    return verify_layer(z)


def create_cell_main(maya, d):
    """
    Draw text for Cell/Caption main.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        text
    """
    parent = maya.group
    group = make_layer_group(Run.j, "Material", parent, get_light(maya))

    for k in maya.main_q:
        maya.k = k
        create_cell(maya, d, group, is_main=True)
    return verify_layer_group(group)


def create_face(maya, d, group):
    """
    Draw text for Face/Caption.

    maya: Maya
    d: dict
        Caption Preset

    group: layer
        Is the parent of Face output.
    """
    k = maya.k
    model = maya.model
    Deco.shape = model.get_facing_shape(k)

    # Transform is less likely to be clipped
    # from the topleft corner of the layer, '(.0, .0)'.
    maya.rect = (.0, .0) + model.get_facing_rect(k)[2:]

    # Face index position, '-1;
    z = draw_text(maya, d, group, k, seq_n="abc"[k[-1]], is_clip=False)
    if z:
        # Set the layer size for the transform by
        # merging the text layer with a new layer.
        add_layer_below(z, "Resize")

        z = pdb.gimp_image_merge_down(Run.j, z, CLIP_TO_IMAGE)
        transform_foam(maya.rect, z, model.get_facing_foam(k))


def create_facial_main(maya, d, p):
    """
    Draw text for Face/Caption main.

    maya: Maya
    d: dict
        Caption Preset

    p: function
        Make Facing text layer.

    Return: layer or None
        text
    """
    group = make_layer_group(Run.j, "Material", maya.group, get_light(maya))

    for k in maya.main_q:
        maya.k = k
        p(maya, d, group)
    return verify_layer_group(group)


def create_facial_per(maya, d, p):
    """
    Make text for Face or Facing Caption/Per.

    maya: Maya
    d: dict
        Caption Preset

    p: function
        Make Face/Facing text layer.

    Return: layer or None
        text
    """
    group = make_layer_group(Run.j, "Material", maya.group, get_light(maya))

    p(maya, d, group)
    return verify_layer_group(group)


def create_facing(maya, d, group):
    """
    Draw text for Face/Caption.

    maya: Maya
    d: dict
        Caption Preset

    group: layer
        Is the parent of Face output.
    """
    k = maya.k
    model = maya.model
    Deco.shape = model.get_facing_form(k)

    # Transform is less likely to be clipped
    # from the topleft corner of the layer, '(.0, .0)'.
    maya.rect = (.0, .0) + model.get_facing_rect(k)[2:]

    z = draw_text(maya, d, group, k, is_clip=False)
    if z:
        # Set the layer size for the transform by
        # merging the text layer with a new layer.
        add_layer_below(z, "Resize")

        z = pdb.gimp_image_merge_down(Run.j, z, CLIP_TO_IMAGE)
        z = transform_foam(maya.rect, z, model.get_facing_foam(k))
        model.clip_facing(z, k)


def do(maya, make):
    """
    Prepare and make Caption text output. Plan
    overrides and restores its required option.

    maya: Maya
    make: function
        Make Caption text.

    Return: layer or None
        text
    """
    d = maya.value_d

    if not Run.x:
        # Preserve.
        mode = d[ok.MODE]
        color = d[ok.RW1][ok.COLOR_1]

        # Override.
        d[ok.MODE] = "Normal"
        d[ok.RW1][ok.COLOR_1] = 255, 255, 255

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.x:
        # Restore.
        d[ok.MODE] = mode
        d[ok.RW1][ok.COLOR_1] = color
    return z


def do_canvas(maya):
    """
    Make Canvas/Caption text.

    maya: Maya
    Return: layer or None
        text
    """
    return do(maya, make_canvas)


def do_cell_main(maya):
    """
    Make Cell/Caption text for main.

    maya: Maya
    Return: layer or None
        text
    """
    return do(maya, create_cell_main)


def do_cell_per(maya):
    """
    Draw Cell/Caption/Per text.

    maya: Maya
    Return: layer or None
        text
    """
    return do(maya, make_cell_per)


def do_face_main(maya):
    """
    Draw Face/Caption text for main.

    maya: Maya
    Return: layer or None
        text
    """
    return do(maya, make_face_main)


def do_face_per(maya):
    """
    Draw text for Face/Caption/Per.

    maya: Maya
    Return: layer or None
        text
    """
    return do(maya, make_face_per)


def do_facing_main(maya):
    """
    Draw Facing/Caption text for main.

    maya: Maya
    Return: layer or None
        text material
    """
    return do(maya, make_facing_main)


def do_facing_per(maya):
    """
    Draw Facing/Caption/Per text.

    maya: Maya
    Return: layer or None
        text
    """
    return do(maya, make_facing_per)


def draw_text(maya, d, group, arg, seq_n="", is_clip=True):
    """
    Create text. Call once per Caption instance.

    maya: Maya
    d: dict
        Caption Preset

    group: layer
        Is the parent of the text layer.

    arg: tuple or None
        key for storing text position and height

    seq_n: string
        Append to the sequence value.
        Is used by sub-Face.
        Is only applied if the Caption/Type is Sequence.

    is_clip: bool
        If True, then the text output is clipped to Maya's 'shape' polygon.

    Return: layer or None
        text
    """
    def _get_text():
        """
        Assemble the text as defined by the options.

        Return: string
            the Caption text
        """
        _text = ""
        type_ = d[ok.TYPE]

        if type_ == pt.TEXT:
            _text = d[ok.TEXT]

        elif type_ == pt.SEQUENCE:
            _text = str(
                maya.model.cell_q.index(maya.k[:2]) +
                int(d[ok.START_NUMBER])
            ) + seq_n

        elif type_ == pt.IMAGE_NAME:
            _text = maya.viewed_d[maya.k]

        if type_ in (pt.IMAGE_NAME, pt.SEQUENCE) and _text:
            _n = d[ok.LTR][ok.LEAD]
            _n1 = d[ok.LTR][ok.TRAIL]
            _text = _n + _text + _n1
        return _text

    j = Run.j

    # Caption failsafe layer, 'z'
    z = None

    go = True
    font = d[ok.RW1][ok.FONT]
    text = _get_text()
    color = d[ok.RW1][ok.COLOR_1]

    if font not in Cat.font_list:
        info_msg(mo.MISSING_ITEM.format("Caption", "font", font))
        go = False

    if go:
        if text:
            offset = get_light(maya) if group == maya.group else 0
            go, z = make_text_layer(
                j,
                add_layer(j, "Material", group, offset),
                1,                          # yes, antialias
                text,
                d[ok.FONT_SIZE],
                font,
                color,
                .0, .0,                     # x, y
                .0, .0                      # w, h
            )
        else:
            go = False

    if go:
        # Select the layer for autocrop.
        select_item(z)

        pdb.plug_in_autocrop_layer(j, z)

        rect_x, rect_y, rect_w, rect_h = maya.rect
        x, y, x1, y1 = get_select_coord(j)
        text_w = x1 - x
        text_h = y1 - y
        half_w = text_w / 2.
        half_h = text_h / 2.
        top, bottom, left, right = calc_margin(d[ok.RW1][ok.MARGIN])

        # cell width, height
        w = max(1., rect_w - left - right)
        h = max(1., rect_h - top - bottom)
        n = d[ok.JUSTIFICATION]

        # cell position x, y
        x = rect_x + left
        y = rect_y + top

        # Get 'y'.
        if n in ju.BOTTOM:
            y += h - text_h

        elif n in ju.CENTER_Y:
            y += (h / 2.) - half_h

        # Get 'x'.
        if n in ju.RIGHT:
            x += w - text_w

        elif n in ju.CENTER_X:
            x += (w / 2.) - half_w

        # Move the text layer.
        pdb.gimp_layer_set_offsets(z, int(x), int(y))

        # Save the Cell's text selection for Strip.
        maya.model.set_caption_y(arg, (y, z.height))

        # Clip material outside of the shape.
        if is_clip:
            select_shape(j, Deco.shape)
            clear_inverse_selection(z)

    else:
        remove_z(z)
        z = None
    return z


def make_canvas(maya, d):
    """
    Make Canvas/Caption text.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        text
    """
    ready_canvas_rect(maya, d, option=None)
    return verify_layer(draw_text(maya, d, maya.group, None))


def make_cell_per(maya, d):
    """
    Make text for Cell/Caption/Per.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        text
    """
    return create_cell(maya, d, maya.group)


def make_face_main(maya, d):
    """
    Make Face/Caption text for main.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        text
    """
    return create_facial_main(maya, d, create_face)


def make_face_per(maya, d):
    """
    Make text for Face/Caption/Per.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        text
    """
    return create_facial_per(maya, d, create_face)


def make_facing_main(maya, d):
    """
    Make text for Facing/Caption main.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        text
    """
    return create_facial_main(maya, d, create_facing)


def make_facing_per(maya, d):
    """
    Make text for Facing/Caption/Per.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        text
    """
    return create_facial_per(maya, d, create_facing)
