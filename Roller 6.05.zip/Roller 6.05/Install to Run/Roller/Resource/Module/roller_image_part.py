#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_fu import collect_non_group
from roller_image_pic import Pic
from roller_image_single import (
    single_get_flat, single_get_layer_ref, single_get_slice_ref
)
from roller_one import make_rect_table

vars = 'image: {}, x: {}, layer x: {}, rx: {}, cx: {}, wait: {}'


def do_bottom_up(mage):
    """
    Get the next layer from the bottom-up.

    mage: Type
    Return: Single or None
    """
    single = None
    j = mage.image.get_image(mage=mage)

    if mage.is_wait:
        # Do this function later in a view run.
        return

    layer_q = get_layer_list(j)

    if mage.layer_x == -2:
        # initialize
        mage.layer_x = len(layer_q) - 1

    if mage.layer_x is not None and mage.layer_x >= 0:
        z = layer_q[mage.layer_x]
        single = single_get_layer_ref(mage, z)
        mage.layer_x -= 1

    else:
        # Expired.
        mage.layer_x = None
    return single


def do_layered_slice(mage, do_layer, do_slice):
    """
    Factor bottom Layered and slice function.

    mage: Type
        Has image, indices and flags.

    do_layer: function
        Get image layer from the top or the bottom.

    do_slice: function
        Slice either from the topleft or bottom-right.
    """
    single = None

    is_seek = True

    # Loop through image layer and its slices.
    # Exit on success, expired, or 'is_wait' .
    while is_seek:
        is_seek = False

        # Override the advance layer index.
        x = mage.layer_x

        # a flattened image, 'single'
        single = do_layer(mage)

        if mage.is_wait:
            # Do this function later.
            return

        # If 'single' is None, then there are no more layers.
        if single:
            # a slice image, 'single'
            j = single.get_image(mage=mage)

            if mage.is_wait:
                # Do this function later.
                return

            single = do_slice(mage, z=j.layers[0])

            if single:
                # The layer had a slice, and there may be more.
                mage.layer_x = x
            else:
                # Slice is expired.
                is_seek = True

                # Initialize for the next layer.
                mage.r_x = mage.c_x = -2
    return single


def do_left(mage, z=None):
    """
    Get the next slice from the topleft of a flattened image.

    mage: Type
    layer: layer or None
        Is a layer when Slice is also Layered.

    Return: Single or None
    """
    single = None
    namer = z

    if z is None:
        # May trigger 'is_wait'.
        j = mage.image.get_image(mage=mage)

        if mage.is_wait:
            # Abort.
            return

        flat = single_get_flat(mage, j, mage.image)

        if mage.is_wait:
            # Abort.
            return
        if flat:
            # A 'flat' image has only one layer.
            j = flat.get_image(mage=mage)

            if mage.is_wait:
                # Abort.
                return

            namer = flat
            z = j.layers[0]

    if mage.r_x == -2:
        # Initialize.
        mage.r_x = mage.c_x = 0

    if mage.r_x >= mage.row:
        # Expired.
        mage.r_x = mage.c_x = None

    else:
        q = get_rect_table(mage, z)

        # Rect, 't'
        t = q[int(mage.r_x)][int(mage.c_x)]
        single = single_get_slice_ref(mage, z, t, namer)

        # Advance slice index.
        mage.c_x += 1
        if mage.c_x >= mage.column:
            mage.c_x = 0
            mage.r_x += 1
    return single


def do_right(mage, z=None):
    """
    Get the next slice from the bottom-right of a flattened image.

    mage: Type
    layer: layer or None
        Is a layer when Slice is also Layered.

    Return: Single or None
    """
    single = None
    namer = z

    if z is None:
        j = mage.image.get_image(mage=mage)

        if mage.is_wait:
            # Abort.
            return

        flat = single_get_flat(mage, j, mage.image)

        if mage.is_wait:
            # Abort.
            return
        if flat:
            # A 'flat' image has only one layer.
            j = flat.get_image(mage=mage)

            if mage.is_wait:
                # Abort.
                return

            namer = flat
            z = j.layers[0]

    if mage.r_x == -2:
        # Initialize.
        mage.r_x = mage.row - 1
        mage.c_x = mage.column - 1

    if mage.r_x < 0:
        # Expired.
        mage.r_x = mage.c_x = None

    else:
        q = get_rect_table(mage, z)

        # Rect, 't'
        t = q[int(mage.r_x)][int(mage.c_x)]
        single = single_get_slice_ref(mage, z, t, namer)

        # Advance slice index.
        mage.c_x -= 1
        if mage.c_x < 0:
            mage.c_x = mage.column - 1
            mage.r_x -= 1
    return single


def do_top_down(mage):
    """
    Get the next layer from the top-down.

    mage: Type
    Return: Single or None
    """
    single = None
    j = mage.image.get_image(mage=mage)

    if mage.is_wait:
        # Do this function later.
        return

    layer_q = get_layer_list(j)

    if mage.layer_x == -2:
        # initialize
        mage.layer_x = 0

    if mage.layer_x is not None and mage.layer_x < len(layer_q):
        z = layer_q[mage.layer_x]
        mage.layer_x += 1
        single = single_get_layer_ref(mage, z)

    else:
        # Expired.
        mage.layer_x = None
    return single


def get_layer_list(j):
    """
    Create a list of top-down ordered layers from a GIMP image.
    Recall and store the layer list with Pic's tree dict.

    j: GIMP image
    Return: list
        [layer, ...]
    """
    k = j.name
    q = Pic.tree_d.get(k)

    if q is None:
        q = []
        Pic.tree_d[k] = collect_non_group(j, q)
    return q


def get_rect_table(mage, z):
    """
    Create or recall for a 2D slice table. A 2D slice table is made
    from an image size and the row and column slice options.

    mage: Type
    z: layer
        Is part of an image which has a size
        attribute needed to calculate the slice table.

    Return: 2D list
        Provided for the row and column options and the layer size.
    """
    j = z.image
    k = mage.row, mage.column, j.width, j.height
    q = Pic.rect_table_d.get(k)

    if q is None:
        q = Pic.rect_table_d[k] = make_rect_table(
            (.0, .0, float(j.width), float(j.height)),
            int(mage.row),
            int(mage.column)
        )
    return q


def slice_bottom_left(mage):
    """
    Get the next topleft slice of a Layered bottom-up layer.

    mage: Type
    Return: Single or None
    """
    return do_layered_slice(mage, do_bottom_up, do_left)


def slice_bottom_right(mage):
    """
    Get the next bottom-right slice of a Layered bottom-up layer.

    mage: Type
    Return: Single or None
    """
    return do_layered_slice(mage, do_bottom_up, do_right)


def slice_top_left(mage):
    """
    Get the next topleft slice of a Layered top-down layer.

    mage: Type
    Return: Single or None
    """
    return do_layered_slice(mage, do_top_down, do_left)


def slice_top_right(mage):
    """
    Get the next bottom-right slice of a Layered top-down layer.

    mage: Type
    Return: Single or None
    """
    return do_layered_slice(mage, do_top_down, do_right)
