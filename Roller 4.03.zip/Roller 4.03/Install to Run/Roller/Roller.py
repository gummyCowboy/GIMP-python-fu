#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script type: Python-fu
Script Title: Roller
Tested on GIMP version: 2.10.34; Windows 10, 64 bit; GTK 2.28.7

What It Does:
    Create image composition like wallpaper, an image board, or a collage.

Where The Script Installs:
    See the how-to file.

Get the latest version: github.com/gummycowboy
"""
from gimpfu import pdb
import gimpfu as fu
import os
import pygtk
import sys
pygtk.require("2.0")

# Developer: Bypass GEGL library load warning in the error file.
# Set to True if the Roller won't load when GIMP starts.
IS_ASH = False

# Developer: Is True during development but
# is False if Roller is failing to load or is a release.
IS_DEV = False and not IS_ASH

if IS_ASH:
    # Trace errors by recording them to a file. If
    # the file doesn't exist, create it. Append
    # error messages and piped (">>") print statements.
    sys.stderr = open("D:\\roller_error.txt", 'a')
    print >> sys.stderr, 'Roller started'

# Append Roller paths to "sys.path" for GIMP's Python
# interpreter. "__file__" is GIMP's plug-in path.
n = os.path.sep
preset_path = os.path.dirname(__file__) + n + u"Resource"
module_path = preset_path + n + u"Module"
frame_path = preset_path + n + u"Frame"

# If a folder path isn't in "sys.path", then add the path.
if module_path not in sys.path:
    sys.path.append(module_path)

# The Python interpreter will now look for
# modules inside the Module folder.
# Now imports from the Module folder work.
# A limitation to this import method is that the modules are not
# identified by the interpreter as being part of a Python package.
from roller_one import Comm
from roller_one_gegl import Gegl
from roller_one_cat import Cat
from roller_one_dog import Dog
from roller_one_the import The
from roller_option_preset import Preset, SuperPreset
from roller_preset_lookup import OPTION_D
from roller_view import View
from roller_widget_number_pair import NumberPair
from roller_window_main import WindowMain


def start():
    """
    Start the program.

    __________________________________
    Typed Single Letter Variable Usage
    ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
    a : part of a sequence; object; int
    b : See 'a'.
    c : See 'a'; column
    d : dict
    e : dict
    f : float
    g : widget; window
    h : height; horizontal
    i : iteration
    j : Image; GIMP image; iteration
    k : key
    m : flag; boolean
    n : string
    o : One
    p : function
    q : iterable
    r : row
    s : size
    t : size
    u : point
    v : point; View; vertical
    w : width; span
    x : canvas coordinate; index
    y : canvas coordinate
    z : layer
    ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

    _________________
    Descriptor Prefix
    ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
    on_function : timing
    has_variable_name : bool
    is_variable_name : bool
    _variable_name : nested variable
    _function_name : nested function
    ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

    ___________________
    Descriptor Postfix
    ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
    single variable name : indicate type
    ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

    ___________________
    Capitalized Comment
    ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
    a class, a UI option, language rule
    ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
    _______________________________________________________________
    Line Spacing Style or How I Create Patterns in the Code Format.
    ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
    Over a period of time, I thought I could add some artistic style
    to my code. After much thought and practice, I came up with a code
    format style. This is a short description of the rules I use.

    If the line is same type as the previous line where type is
    either an assignment or a call and not a branch.
        Place the line under the previous line.

    If the line is a logic branch:
        Add a blank line under the previous line.

    If the line is a comment and the previous line is not a comment:
        Add a blank line under the previous line.

    Line Spacing Override
        If the line is the last line in an indentation block.
            Place the line under the previous non-blank line.

        If the previous line is a branch:
            Place the line under the previous line.

        For clarity, if a comment reference is specific to a section of code,
        then add a blank line after last the line of the commented section.
    ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
    """
    if IS_DEV:
        import time
        sys.stderr = open("D:\\roller_error.txt", 'a')
        print >> sys.stderr, "\nRoller,", time.ctime(), "_" * 45, "\n"

    # Save the interface context so that it can
    # be restored when the plug-in is done.
    pdb.gimp_context_push()

    # Save the colors for GIMP generated gradients.
    q = pdb.gimp_context_get_background()
    q1 = pdb.gimp_context_get_foreground()

    # for consistency reasons
    pdb.gimp_context_set_defaults()

    # Return the colors after the default modification.
    pdb.gimp_context_set_background(q)
    pdb.gimp_context_set_foreground(q1)

    pdb.gimp_context_set_sample_transparent(1)
    pdb.gimp_context_set_transform_direction(fu.TRANSFORM_FORWARD)
    pdb.gimp_context_set_transform_resize(fu.TRANSFORM_RESIZE_ADJUST)
    pdb.gimp_context_set_interpolation(fu.INTERPOLATION_NOHALO)
    pdb.gimp_context_set_dynamics("Dynamics Off")
    pdb.gimp_context_set_brush_aspect_ratio(.0)
    pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
    pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)

    # circular reference work-around or global scope class
    cat = The.cat = Cat()
    cat.roller_path = preset_path
    The.frame_path = frame_path
    The.dog = Dog()
    The.option_d = OPTION_D
    The.view = View()
    The.preset = Preset
    The.number_pair = NumberPair
    The.super_preset = SuperPreset

    # Reference
    # gimp-forum.net/Thread-GEGL-problem-two-versions
    Gegl.gimp_library = Gegl.load_library('libgimp-2.0')

    # Improve stability with an exception handler.
    try:
        WindowMain()

    except Exception as ex:
        Comm.show_err("Roller failed at some point: " + repr(ex))
        if IS_DEV or IS_ASH:
            print >> sys.stderr, ex

    finally:
        # Return undo functionality.
        if cat.render.has_image:
            pdb.gimp_image_undo_enable(cat.render.get_image())

        # Restore the interface context.
        pdb.gimp_context_pop()


fu.register(
    # name
    # Is the dialog title as 'python-fu + name'.
    # The space character is not allowed.
    # 'name' is case-sensitive.
    "Roller",

    # tool-tip and window-tip text
    "Render a composition.",

    # help (describe how-to, exceptions and dependencies)
    # Display in the plug-in browser.
    "Creates a new image and does not require an open image.",

    # Display in the plug-in browser.
    "Charles Bartley",

    # Display in the plug-in browser.
    "Charles Bartley",

    # Display in the plug-in browser.
    "2023",

    # menu item descriptor with short-cut key id '_R'
    "_Roller…",

    # image types
    # An empty string is no image needed.
    "",

    # plug-in parameters
    [],

    # results
    [],

    # plug-in function handler
    # The second item is the menu's location for the plug-in.
    start, menu='<Image>/Filters/Render')
if __name__ == '__main__':
    fu.main()
