#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Metal, do_selection_material
from roller_one_extract import combine_seed
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_view_hub import brush_stroke
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Make a frame around material.

    v: View
        Has scope variable.

    maya: Maya
        with frame material
    """
    pdb.gimp_context_set_brush_hardness(.95)
    pdb.gimp_context_set_opacity(100.)
    return do_selection_material(v, maya, do_sel, embellish, "Brush Punch")


def do_sel(v, maya, z):
    """
    Do the fFrame for a selection.

    v: View
    maya: Maya
    z: layer
        to receive material

    Return: layer
        with frame material
    """
    j = v.j
    d = maya.value_d
    e = d[ok.FNR][ok.FRAME_METAL]
    sel = pdb.gimp_selection_save(j)

    Sel.grow(j, e[ok.FRAME_W] + 3, e[ok.FRAME_TYPE])
    Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
    Sel.fill(z, (117, 117, 117))
    pdb.plug_in_sel2path(j, z)

    if j.active_vectors:
        # Preserve.
        q = pdb.gimp_context_get_foreground()

        # Set the color of the brush.
        pdb.gimp_context_set_foreground((137, 137, 137))

        stroke = j.active_vectors.strokes[0]

        combine_seed(v, d)
        pdb.gimp_selection_none(j)
        brush_stroke(
            z,
            d[ok.BRUSH],
            d[ok.BRUSH_SIZE],
            stroke,
            d[ok.BRUSH_SPACING],
            d[ok.ANGLE_JITTER]
        )
        pdb.gimp_image_remove_vectors(j, j.active_vectors)

        # Restore.
        pdb.gimp_context_set_foreground(q)
    return z


def embellish(v, maya, z):
    """
    Add color and depth to frame material.

    v: View
    maya: Maya
    z: layer
        Has frame.

    Return: layer
        with frame material
    """
    pdb.gimp_selection_none(v.j)

    n = z.name
    z = Lay.clone(z)
    z.mode = fu.LAYER_MODE_OVERLAY

    pdb.plug_in_emboss(
        v.j, z,
        v.glow_ball.azimuth,
        v.glow_ball.elevation,
        1,                  # depth
        1                   # emboss
    )
    Lay.blur(z, 1)

    z = Lay.merge(z)
    z.name = n

    Gegl.antialias(z)
    return z


class BrushPunch(Metal):
    """Is a metallic border with an overlapping brush stroke."""

    def __init__(self, *q, **d):
        """
        Prepare the sub-maya.

        q: tuple
            Metal spec

        d: dict
            Metal spec
        """
        Metal.__init__(self, *q + (do_matter,), **d)
