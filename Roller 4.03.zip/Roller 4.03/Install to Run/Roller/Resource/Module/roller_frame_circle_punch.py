#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg
from roller_constant_key import Option as ok
from roller_frame import Metal, do_soft_metal_material
from roller_one_fu import Lay, Mage, Sel
from roller_view_hub import set_fill_context
import gimpfu as fu

pdb = fu.pdb


def make_pattern(z, d):
    """
    Draw circles on a layer. Create a pattern (a black circle). Use the
    clipboard to hold the pattern. Fill the provided layer with the pattern.

    z: layer
        to receive pattern

    d: dict
        Circle Punch Preset
        {Option key: value}

    Return: layer
        work-in-progress
        Has material to select.
    """
    diameter = d[ok.CIRCLE_DIAMETER]
    w = int(diameter * 1.5)
    h = int(w * .8660254)
    j = pdb.gimp_image_new(w, h, fu.RGB)
    z1 = Lay.add(j, 'pattern')

    # A circle at the center of 'z1' will become a hole in the pattern.
    x = (w - diameter) // 2
    y = (h - diameter) // 2

    Lay.color_fill(z1, (255, 255, 255))
    Sel.ellipse(j, x, y, diameter, diameter)
    pdb.gimp_selection_feather(j, 1.)
    Lay.clear_sel(z1)

    # Set the Clipboard Image.
    Mage.copy_all(j)

    pdb.gimp_image_delete(j)
    set_fill_context(fg.FILL_DICT)
    pdb.gimp_context_set_pattern("Clipboard Image")
    pdb.gimp_selection_none(z.image)

    # x, y canvas coordinate, '0'
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, 0, 0)

    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: Frame
    Return: layer
        with the frame
    """
    return do_soft_metal_material(v, maya, make_pattern, "Circle Punch")


class CirclePunch(Metal):
    """Has circular holes in a metallic frame."""

    def __init__(self, *q, **d):
        """
        q: tuple
            Metal spec

        d: dict
            Metal spec
        """
        Metal.__init__(self, *q + (do_matter,), **d)
