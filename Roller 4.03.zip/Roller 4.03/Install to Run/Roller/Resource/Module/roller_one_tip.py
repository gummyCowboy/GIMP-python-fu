#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import BackdropStyle as by, Frame as ek, Model as md

FRAME_TYPE_METAL = " Frame Type: Metal "
FRAME_TYPE_METAL_OTHER = " Frame Type: Metal and Other "
FRAME_TYPE_OTHER = " Frame Type: Other "
FRAME_TYPE_TRANSLUCENT = " Frame Type: Translucent "
STYLE_DEPENDENT = " Uses the Backdrop Image. "
STYLE_INDEPENDENT = " The Backdrop Image is not used. "


class Tip:
    """Has tooltip text string."""
    ADD_SHIFT_XY = \
        " After the first cell, each cell's position \n" \
        " is offset by this amount from the prior \n" \
        " cell in the cell sequence. "
    AMPLITUDE = " Use a higher value to increase the roughness. "
    AUTOCROP = " When checked, empty space around an image is cropped. "
    AZIMUTH = " The light angle is used by an emboss function. "
    BLEND = " Use a higher value to create less textural variation. "
    BLUR_BEHIND = " Blur a darkened copy of the background. "
    CELL_GAP = " Is the number of sequenced cells between two mazes. "
    CLIP_TO_CELL = \
        " If selected, the output is contained \n" \
        " within the contextual bounds. "
    COLOR = " Red\t{} \n Green\t{} \n Blue\t{} "
    COLOR_COUNT = " Is the number of potential colors. "
    COLOR_RGBA = COLOR + "\n Alpha\t{}"
    CONTRACT = \
        " At zero, the brush is applied on the edge of \n" \
        " a cell or source material. With contract, the \n" \
        " edge moves inward toward the center of the subject. "
    CROP_X = \
        " Crop the image from a topleft coordinate \n" \
        " defined by x and y. The size of the \n" \
        " crop is the width and height values. "
    DELETE_MODEL = " Delete the selected model. "
    DELETE_PLAN = " If selected, the Plan layer group is removed on exit. "
    DIAGONAL_ROTATION = \
        " The direction angle is mirrored in the \n" \
        " opposite direction. The result is a vector \n" \
        " that goes through the layer's center, \n" \
        " starting and ending at the layer bounds. "
    DISTRESS_THRESHOLD = " Stress the frame more with a higher value. "
    DRAFT_BUTTON = " Plan steps up to the visible option group. "
    ELEVATION = \
        " Used by an emboss function. It \n" \
        " determines the lightness of an emboss, \n" \
        " where a higher value has greater light. "
    END_X = " Add to the x-axis end coordinate. "
    END_Y = " Add to the y-axis end coordinate. "
    EXPAND_FRAME = \
        " The frame image rectangle is expanded on \n" \
        " both axes by twice this amount. The frame \n " \
        " center remains the center of the image rectangle. "
    FACTOR_H = " Multiply by the render height and add to the result. "
    FIW = \
        " Resize the image by multiplying its scale with factor values. "
    FACTOR_W = " Multiply by the render width and add to the result. "
    FCI = \
        " Select to make the grid's first cell position be row 1, column 2. "
    FEATHER = \
        " The initial feather is this number divided \n" \
        " by steps. Subsequent steps add the initial \n" \
        " value to the feather. This value becomes the \n" \
        " feather amount applied on the last step. "
    FILL_MODE = "Is the paint mode used by the bucket fill. "
    FIXED_SIZE_W = " Resize the image to these dimensions. "
    FONT_SIZE = " Is for Draft/Plan text output. "
    FRINGE_MASK = \
        " Brush strokes painted on the edge of the material form a mask. "
    GRID_FIXED_SIZE = \
        " The canvas space is divided by the dimension \n" \
        " to derive the row and column count. "
    HEIGHT_MOD = " Modify the image height by this amount. "
    IMAGE_LAYERS = \
        " The image's layers are iterated as a tree, \n" \
        " where each layer becomes an image reference. "
    IMAGE_NAME = \
        " The order of image name list is \n" \
        " from GIMP's open image order. "
    IMAGE_NUMERIC = \
        " The order of the numeric list is \n" \
        " from GIMP's open image order. "
    IMAGE_ORDER = \
        " Is the direction of the layer-tree iteration. \n" \
        " With top-down, the first layer is the \n" \
        " layer at the top of the layer palette. \n" \
        " If top-down is off, then the order is \n" \
        " bottom-up, and the first layer is \n" \
        " the bottom layer in the palette. "
    INTENSITY = " Is the shadow opacity but is layered for greater capacity. "
    KEEP_GRADIENT = \
        " Have GIMP save the new gradient in \n" \
        " the user's default gradient folder. "
    LEAD = " Is a caption prefix. "
    LENGTH_SHIFT = \
        " Modify the length of a tape strip, plus or \n" \
        " minus, by a random amount limited by this scale. "
    LOOP_MINUS = \
        " Assign images using a circular-type index variable. \n" \
        " Loop Minus decrements after assigning an image. \n" \
        " It's index rolls-over to the last open image after \n" \
        " the first open image. Both Loop Plus and Loop \n" \
        " Minus use the same index variable. If the Minus \n" \
        " option is used before the Plus option, then the \n" \
        " last open image is the first image reference. "
    LOOP_PLUS = \
        " Assign an image using a circular-type index variable. \n" \
        " Loop Plus increments after assigning an image. \n" \
        " The index rolls-over to the first open image after \n" \
        " the last open image. Both Loop versions use the same \n" \
        " index variable. If the Plus index is used before the \n" \
        " Minus index, then the first open image is the first \n" \
        " image reference. "
    MASK_CIRCLE = \
        " The circle mask's diameter is calculated from the image \n" \
        " size using the horizontal and vertical scale factors.\n\n" \
        " Where the width-diameter equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the height-diameter equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."
    MASK_CUT_CORNER = \
        " The cut corners mask calculates an 8-gon that defines \n" \
        " the corners. This 8-gon is calculated from the \n" \
        " image size using the horizontal and vertical \n\n" \
        " scale factors. Where the uncut-width equals: \n" \
        "\timage width x horizontal scale,\n" \
        " and the uncut-height equals:\n" \
        "\timage height x vertical scale."
    MASK_EYE = \
        " The eye mask's height is the image height multiplied by \n" \
        " the vertical scale factor. The eye mask's width is the \n" \
        " image width multiplied by the horizontal scale factor. "
    MASK_HEXAGON = \
        " A hexagon mask's size is calculated from the image \n" \
        " size using the horizontal and vertical scale factors. \n\n" \
        " Where the width-diameter equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the height-diameter equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, a best fit \n" \
        " is calculated for the hexagon. "
    MASK_HEXAGON_SHEAR = \
        " A sheared hexagon mask's size is calculated from the image \n" \
        " size using the horizontal and vertical scale factors. \n\n" \
        " Where the width-diameter equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the height-diameter equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From this rectangle, a sheared hexagon \n" \
        " is calculated from hexagonal ratios. "
    MASK_IMAGE_1 = \
        " Use an image's alpha channel as a mask. The \n" \
        " mask's scale is transformed by the size of \n" \
        " the image and the vertical and horizontal scales. "
    MASK_OCTAGON = \
        " An octagon mask's sides are calculated from the image \n" \
        " size using the horizontal and vertical scale factors. \n\n" \
        " Where the octagon-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the octagon-height equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."
    MASK_OCTAGON_SHEARED = \
        " A sheared octagon mask's sides are calculated from the \n" \
        " image size using the horizontal and vertical scale factors. \n\n" \
        " Where the octagon-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the octagon-height equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From this rectangle, a sheared octagon \n" \
        " is calculated using octagonal ratios. "
    MASK_OVAL = \
        " The oval mask's dimension is calculated from the image \n" \
        " size using the horizontal and vertical scale factors.\n\n" \
        " Where width-diameter equals: \n" \
        "\timage width x horizontal scale,\n" \
        " and height-diameter equals:\n" \
        "\timage height x vertical scale."
    MASK_RECTANGLE = \
        " The rectangle mask's sides are calculated from the image \n" \
        " size using the horizontal and vertical scale factors.\n\n" \
        " Where the rectangle-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the rectangle-height equals:\n" \
        "\timage height x vertical scale."
    MASK_RHOMBUS = \
        " The rhombus mask's diagonal is calculated from the image \n" \
        " size using the horizontal and vertical scale factors. \n\n" \
        " Where one diagonal-value equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the second diagonal-value equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."
    MASK_RHOMBUS_SHEAR = \
        " The rhombus mask's diagonals are calculated from the image \n" \
        " size using the horizontal and vertical scale factors. \n\n" \
        " Where the width-diagonal equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the height-diagonal equals:\n" \
        "\timage height x vertical scale."
    MASK_ROUND_CORNER = \
        " The rounded corners mask calculates an ellipse that defines \n" \
        " the corners. This ellipse is calculated the from the image \n" \
        " size using the horizontal and vertical scale factors.\n\n" \
        " Where the ellipse-width equals:\n" \
        "\timage width - (image width x horizontal scale), \n" \
        " and the ellipse-height equals:\n" \
        "\timage height - (image height - vertical scale). "
    MASK_SQUARE = \
        " The square mask's side is calculated from the image size \n" \
        " using the horizontal and vertical scale factors.\n\n" \
        " Where one side value equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the second side value equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."
    MASK_TEXT_1 = \
        " The text mask is made from the text in the \n" \
        " 'Text' entry with the font from the 'Font' button. \n\n" \
        " Where the text width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the text height equals:\n" \
        "\timage height x vertical scale."
    MASK_TRIANGLE_DOWN_ISOSCELES = \
        " A triangle mask with equal length sides points down \n" \
        " from center of the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "
    MASK_TRIANGLE_DOWN_SHEAR = \
        " The triangle mask points down and is squeezed \n" \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "
    MASK_TRIANGLE_LEFT_ISOSCELES = \
        " A triangle mask with equal length sides points left \n" \
        " from center of the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "
    MASK_TRIANGLE_LEFT_SHEAR = \
        " The triangle mask is pointing left and is squeezed \n" \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "
    MASK_TRIANGLE_RIGHT_ISOSCELES = \
        " A triangle mask with equal length sides points right \n" \
        " from center of the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "
    MASK_TRIANGLE_RIGHT_SHEAR = \
        " The triangle mask is pointing right and is \n" \
        " squeezed into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "
    MASK_TRIANGLE_UP_ISOSCELES = \
        " A triangle mask with equal length sides points up \n" \
        " from center of the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "
    MASK_TRIANGLE_UP_SHEAR = \
        " The triangle mask is pointing up and is squeezed \n" \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "
    MERGE_CELL = " X:\t\t{} \n Y:\t\t{} \n Width:\t{} \n Height:\t{} "
    MODEL_LIST_NEW = " Make a new model from the type specified. "
    MODEL_LIST_TREE = " active model in inverted layer palette order "
    MODEL_LIST_TYPE = {
        md.BOX:
            " Arrange double-spaced box-shaped \n"
            " cell by row and column. ",
        md.CELL: " Define a cell. ",
        md.STACK: " Layer cell in a stack. ",
        md.TABLE: " Arrange cell by row and column. "
    }
    MODEL_STEP = " Add and remove a step from the navigation tree. "
    MOVE_DOWN = " Move the selected model down in the z-order. "
    MOVE_LEFT = " Remove the selected item from the interface. "
    MOVE_RIGHT = " Move the selected item to the interface. "
    MOVE_UP = " Move the selected model up in the z-order. "
    n = " Apply cell data and show cell to the "
    NAVIGATION = (
        n + "north (ctrl ↑) ",
        n + "south (ctrl ↓) ",
        n + "west (ctrl ←) ",
        n + "east (ctrl →) "
    )

    OBEY_MARGINS = \
        " If selected, the output uses the contextual margins. "
    OFFSET_X_SHIFT = " Move the image on the X-axis. "
    OFFSET_Y_SHIFT = " Move image on the Y-axis. "
    OPTION_LIST = {
        # Backdrop Style
        by.ACRYLIC_SKY: STYLE_DEPENDENT,
        by.AVERAGE_COLOR: STYLE_DEPENDENT,
        by.CARBON_14: STYLE_DEPENDENT,
        by.CLAY_CHEMISTRY: STYLE_DEPENDENT,
        by.COLOR_FILL: STYLE_DEPENDENT,
        by.COLOR_GRID: STYLE_INDEPENDENT,
        by.CORE_DESIGN: STYLE_INDEPENDENT,
        by.CRYSTAL_CAVE: STYLE_INDEPENDENT,
        by.CUBE_PATTERN: STYLE_INDEPENDENT,
        by.DARK_FORT: STYLE_DEPENDENT,
        by.DENSITY_GRADIENT: STYLE_INDEPENDENT,
        by.DROP_ZONE: STYLE_DEPENDENT,
        by.ETCH_SKETCH: STYLE_DEPENDENT,
        by.FLOOR_SAMPLE: STYLE_INDEPENDENT,
        by.GALACTIC_FIELD: STYLE_DEPENDENT,
        by.GLASS_GAW: STYLE_INDEPENDENT,
        by.GRADIENT_FILL: STYLE_INDEPENDENT,
        by.HISTORIC_TRIP: STYLE_DEPENDENT,
        by.IMAGE_GRADIENT: STYLE_DEPENDENT,
        by.LINE_STONE: STYLE_DEPENDENT,
        by.LOST_MAZE: STYLE_INDEPENDENT,
        by.MAZE_BLEND: STYLE_DEPENDENT,
        by.MYSTERY_GRATE: STYLE_INDEPENDENT,
        by.NANO_SUIT: STYLE_DEPENDENT,
        by.PATTERN_FILL: STYLE_DEPENDENT,
        by.RECT_PATTERN: STYLE_INDEPENDENT,
        by.ROCKY_LANDING: STYLE_INDEPENDENT,
        by.SOFT_TOUCH: STYLE_DEPENDENT,
        by.SPECIMEN_SPECKLE: STYLE_INDEPENDENT,
        by.SPIRAL_CHANNEL: STYLE_INDEPENDENT,
        by.SQUARE_CLOUD: STYLE_DEPENDENT,
        by.STONE_AGE: STYLE_DEPENDENT,

        # Frame
        ek.BALL_JOINT: FRAME_TYPE_METAL,
        ek.BORDER_LINE: FRAME_TYPE_METAL,
        ek.BRUSH_PUNCH: FRAME_TYPE_METAL,
        ek.CAMO_PLANET: FRAME_TYPE_METAL,
        ek.CERAMIC_CHIP: FRAME_TYPE_METAL_OTHER,
        ek.CIRCLE_PUNCH: FRAME_TYPE_METAL,
        ek.CLEAR_FRAME: FRAME_TYPE_TRANSLUCENT,
        ek.COLOR_BOARD: FRAME_TYPE_TRANSLUCENT,
        ek.COLOR_PIPE: FRAME_TYPE_TRANSLUCENT,
        ek.CORNER_TAPE: FRAME_TYPE_TRANSLUCENT,
        ek.CRUMBLE_SHELL: FRAME_TYPE_OTHER,
        ek.CUTOUT_PLATE: FRAME_TYPE_OTHER,
        ek.FRAME_OVER: FRAME_TYPE_OTHER,
        ek.GLASS_REVEAL: FRAME_TYPE_TRANSLUCENT,
        ek.GRADIENT_LEVEL: FRAME_TYPE_TRANSLUCENT,
        ek.HOT_GLUE: FRAME_TYPE_TRANSLUCENT,
        ek.LINE_FASHION: FRAME_TYPE_METAL,
        ek.MAZE_MIRROR: FRAME_TYPE_METAL,
        ek.METALLIC_PROFILE: FRAME_TYPE_METAL,
        ek.RAD_WAVE: FRAME_TYPE_METAL,
        ek.RAISED_MAZE: FRAME_TYPE_METAL,
        ek.SHAPE_BURST: FRAME_TYPE_OTHER,
        ek.SQUARE_CUT: FRAME_TYPE_METAL,
        ek.SQUARE_PUNCH: FRAME_TYPE_METAL,
        ek.STAINED_GLASS: " Frame Type: Metal and Translucent ",
        ek.STRETCH_TRAY: FRAME_TYPE_METAL_OTHER,
        ek.WIRE_FENCE: FRAME_TYPE_METAL
    }
    PER_CELL_CHECK_BUTTON = " Modify option per cell. "
    PER_CELL_BUTTON = " Modify a cell option from a cell table layout. "
    PEEK_BUTTON = " Preview steps up to the visible option group. "
    PLAN_BORDER = " Show Border material in Draft/Plan output. "
    PLAN_BUTTON = " Per the Planner option, draw a plan graph. "
    PLAN_CELL_SHAPE = " Draw the cell shape outline. \n" \
        " Requires the Cell/Margin step. "
    PLAN_POSITION = \
        " Display the topleft canvas coordinate of a \n" \
        " cell's position. Requires the Cell/Margin step. "
    PLAN_CORNER = \
        " Display the bottom-right canvas coordinate of a \n" \
        " cell's position. Requires the Cell/Margin step. "
    PLAN_DIMENSION = \
        " Display the size of a cell. Requires the Cell/Margin step. "
    PLAN_GRID = " Draw a grid defined by the model's grid. "
    PLAN_IMAGE_NAME = " Show the name of the image assigned to a cell. "
    PLAN_RATIO = \
        " Display the cell's position ratio. Requires the Cell/Margin step. "
    POST_BLUR = \
        " Create a blurry frame that sits on top \n" \
        " of the source material. The blur is \n" \
        " applied at the end of the processing. "
    POWER = " A higher value increases cloud material. "
    PREVIEW_BUTTON = " Make a render using the navigation tree. "
    SEED = " Randomized output uses this an init value. "
    SEEDING = " Try dynamic to randomize Per Cell output. "
    RENAME_MODEL = " Rename the selected model. "
    REVERSE = " Reverse the order of the gradient colors. "
    ROUNDED = " The Rounded process is faster. "
    SAMPLE_POINTS = " Sample points are evenly distributed between the edges. "
    SATURATION = \
        " Values below one lower the saturation. \n" \
        " Saturation multiplies the saturation of the input. "
    SCATTER_COUNT = " Is the number of mazes to draw. "
    SEED_GLOBAL = " Modify all the random seed in use. "
    SHIFT_H = " Randomize the image's height (+/-). "
    SHIFT_W = " Randomize the image's width (+/-). "
    SHIFT_X = " Randomize the image's x position (+/-). "
    SHIFT_Y = " Randomize the image's y position (+/-). "
    SLICE = " Slice an image using row and column values. "
    SPIRAL_DISTANCE = " Lower the value to increase the spiral count. "
    SPREAD_DISTRESS = \
        " The material scatters increasingly with a higher value. "
    START_NUMBER = " Is the first number displayed in an integer sequence. "
    START_X = " Add to the x-axis start coordinate. "
    START_Y = " Add to the y-axis start coordinate. "
    STEPS = " Repeat feather. "
    STEPS_DROP_ZONE = " Is the number of colors in the resulting gradient. "
    STOP_LENGTH = " A maze branch needs this amount of pixels. "
    STRIPE_H = " Is a factor of the caption's text height. "
    THRESHOLD = \
        " A threshold of 1.0 is a match all \n" \
        " and a threshold of 0.0 is to match none. "
    TRAIL = " Is a caption suffix. "
    USE_PLASMA = \
        " If checked, a plasma layer is used as a background. "
    WIDTH_MOD = " Modify the image width by this amount. "
    WHIRL = " Spin the material around the center of the image. "
    WIP = " Scale the image size. Use to improve render edge-case output. "
