#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_rect_table import RectTable
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_fu import Lay, Sel
from roller_view_real import do_rotated_layer, finish_style
import gimpfu as fu

pdb = fu.pdb


def do_color_grid(v, d, group):
    """
    Do a Color Grid.

    v: View
    d: dict
        Color Grid Preset

    group: layer
        Is destination for output.

    Return: layer
        with Color Grid material
    """
    return do_rotated_layer(v, d, draw_color_grid, group, 0)


def draw_color_grid(z, d):
    """
    Draw a checkerboard with two colors.

    z: layer
        to be replaced by the grid layer

    d: dict
        Color Grid Preset
        {Option key: value}

    Return: layer
        Has a colored grid.
    """
    j = z.image
    x, y = z.offsets
    w, h = z.width, z.height
    row, column = d[ok.ROW], d[ok.COLUMN]
    grid = RectTable((x, y, w, h), row, column).table
    z1 = Lay.add_above(z, n="V")

    # Prep layers for selections.
    Lay.color_fill(z, (255, 255, 255))
    Lay.color_fill(z1, (255, 255, 255))

    pdb.gimp_selection_none(j)

    # Draw horizontal stripes.
    for r in range(0, row, 2):
        Sel.rect(j, 0, grid[r][0].y, w, grid[r][0].h, option=fu.CHANNEL_OP_ADD)

    Sel.fill(z, (0, 0, 0))
    pdb.gimp_selection_none(j)

    # Draw vertical stripes.
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    # row, 'a'
    a = grid[0]

    for c in range(0, column, 2):
        Sel.rect(j, a[c].x, 0, a[c].w, h, option=fu.CHANNEL_OP_ADD)

    Sel.fill(z1, (0, 0, 0))

    # black and white checkerboard layer, 'z'
    z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

    # layer to receive color grid material, 'z1'
    z1 = Lay.add_above(z, "Color Grid")

    # Select by color and fill.
    Sel.color(z, (255, 255, 255))
    Sel.fill(z1, d[ok.COLOR_2A][0])
    Sel.color(z, (0, 0, 0))
    Sel.fill(z1, d[ok.COLOR_2A][1])
    pdb.gimp_selection_none(j)
    Lay.remove(z)
    return z1


def make_style(v, maya):
    """
    Do the Backdrop Style.

    v: View
        Has scope variable.

    maya: Style
    Return: layer
        with Color Grid
    """
    d = maya.value_d
    z = do_color_grid(v, d, maya.group)

    if d[ok.INVERT]:
        pdb.gimp_drawable_invert(z, 0)
    return finish_style(z, "Color Grid")


class ColorGrid(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = False

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
