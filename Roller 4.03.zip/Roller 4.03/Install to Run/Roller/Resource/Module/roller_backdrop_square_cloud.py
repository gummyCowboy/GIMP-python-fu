#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_fu import Lay
from roller_view_real import add_sub_base_group, add_wip_layer, finish_style
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a style layer.

    v: View
    maya: SquareCloud
    Return: layer or None
        with the style material
    """
    j = v.j
    d = maya.value_d
    group = add_sub_base_group(v, maya)
    base = add_wip_layer(v, maya, "Base", group=group)
    z = Lay.clone(base, n="Plasma")

    pdb.gimp_selection_none(j)

    # medium turbulence, '3.5'
    pdb.plug_in_plasma(j, z, d[ok.SEED] + v.glow_ball.seed, 3.5)

    z1 = Lay.clone(z, n="Erode")

    for i in range(10):
        Lay.dilate(z1)
        pdb.plug_in_erode(
            j, z,
            6,                      # propagate opaque
            7,                      # RGB channels
            1.,                     # full rate
            7,                      # RGB channels
            0,                      # low limit
            255                     # upper limit
        )

    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
    pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
    Lay.color_fill(base, (127, 127, 127))

    z2 = Lay.clone(base, n="HSV Saturation")
    z2.mode = fu.LAYER_MODE_HSV_SATURATION

    pdb.gimp_image_reorder_item(j, z2, group, 0)

    z3 = Lay.clone(z, n="Overlay")
    z3.mode = fu.LAYER_MODE_OVERLAY
    z3.opacity = 75.

    pdb.gimp_image_reorder_item(j, z3, group, 0)

    z4 = Lay.clone(z3, n="Darken Only")
    z4.mode = fu.LAYER_MODE_DARKEN_ONLY
    z4.opacity = 30.
    z = Lay.merge_group(group)
    z = Lay.clone(z, n="Colorify")
    z.opacity = 50.

    pdb.plug_in_colorify(j, z, d[ok.COLOR_1])

    z = Lay.merge(z)
    return finish_style(z, "Square Cloud")


class SquareCloud(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_seeded = is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
