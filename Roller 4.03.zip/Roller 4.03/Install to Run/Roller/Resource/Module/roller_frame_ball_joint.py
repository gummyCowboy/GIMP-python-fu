#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Frame, do_selection_material
from roller_one_fu import Lay
from roller_view_hub import brush_stroke, set_gimp_brush
import gimpfu as fu

pdb = fu.pdb


def do_sel(v, maya, z):
    """
    Make a frame from a selection.

    v: View
    maya: Maya
    z: layer
        to receive the frame

    Return: layer
        with the frame material
    """
    j = v.j
    d = maya.value_d

    pdb.plug_in_sel2path(j, z)
    if j.active_vectors:
        stroke = j.active_vectors.strokes[0]

        pdb.gimp_selection_none(j)
        brush_stroke(
            z,
            'dots',
            d[ok.BRUSH_SIZE],
            stroke,
            d[ok.BRUSH_SIZE] / 15.,
            .0
        )
        pdb.gimp_image_remove_vectors(j, j.active_vectors)
    return z


def do_matter(v, maya):
    """
    Add a frame to the image material on a layer.

    v: View
    maya: Maya
    Return: layer
        with the frame material
    """
    init_brush()
    return do_selection_material(v, maya, do_sel, embellish, "Ball Joint")


def embellish(v, maya, z):
    """
    Add color and depth to frame material.

    v: View
    maya: Maya
    z: layer
        Has frame.

    Return: layer
        with the frame material
    """
    n = z.name
    j = v.j
    group = Lay.group(j, n, parent=z.parent, offset=Lay.offset(z), z=z)
    z1 = Lay.clone(z)
    z1.mode = fu.LAYER_MODE_OVERLAY
    z1.opacity = 25.
    z1 = Lay.clone(z1)
    z1.mode = fu.LAYER_MODE_BURN
    z1.opacity = 50.

    pdb.plug_in_emboss(
        j, z,
        v.glow_ball.azimuth,
        v.glow_ball.elevation,
        3,                              # depth
        1                               # emboss
    )
    pdb.gimp_selection_none(j)

    z = Lay.merge_group(group)
    z.name = n

    pdb.gimp_drawable_hue_saturation(
        z,
        fu.HUE_RANGE_ALL,
        0,                              # hue offset
        0,                              # lightness offset
        -50,                            # saturation offset
        0                               # overlap
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_RED,
        6,                              # coordinate count
        (.0, .0, .549, .7568, 1., 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_GREEN,
        6,                              # coordinate count
        (.0, .0, .5176, .4, 1., 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_BLUE,
        8,                              # coordinate count
        (.0, .0, .2117, .0588, .6667, .4901, 1., 1.)
    )
    return z


def init_brush():
    """Initialize the brush before stroking the frame."""
    set_gimp_brush({ok.BRUSH: "dots"})
    pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
    pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
    pdb.gimp_context_set_brush_hardness(.95)
    pdb.gimp_context_set_opacity(100.)


class BallJoint(Frame):
    """Is a metallic frame made with of an overlapping circle brush."""
    INFLUENCE = ok.METAL
    is_embossed = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Frame spec

        d: dict
            Frame spec
        """
        Frame.__init__(self, *q + (do_matter,), **d)
