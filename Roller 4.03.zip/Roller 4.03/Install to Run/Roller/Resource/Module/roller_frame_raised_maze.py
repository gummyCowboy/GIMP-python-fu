#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Metal, make_canvas_frame_sel, soften_metal_sel
from roller_one_fu import Lay, Sel
from roller_view_real import add_wip_layer
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Make the frame.

    v: View
    maya: Frame
    Return: layer
        with the Frame
    """
    def _add():
        """Add a layer to the bottom the Maya group."""
        return add_wip_layer(
            v, maya, "Raised Maze", group=group, offset=len(group.layers)
        )

    j = v.j
    d = maya.value_d
    e = d[ok.FNR][ok.FRAME_METAL]
    group = maya.group
    cause = maya.cause.matter

    # layer for the maze, 'z'
    z = _add()

    sel = make_canvas_frame_sel(v, d)

    Sel.border(j, cause, e[ok.FRAME_W], e[ok.FRAME_TYPE])

    sel1 = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.gimp_context_set_foreground((0, 0, 0))
    pdb.gimp_context_set_background((255, 255, 255))

    pdb.plug_in_maze(
        j, z,
        max(1, v.wip.w // d[ok.COLUMN]),
        max(1, v.wip.h // d[ok.ROW]),
        1,
        0,
        d[ok.SEED] + v.glow_ball.seed,
        0,
        0
    )

    # amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(j, z, 1., 0, 0)

    w = max(d[ok.LINE_W] // 2 - 1, 1)

    for _ in range(w):
        Lay.dilate(z)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    Sel.item(z)
    Lay.remove(z)

    # layer for the emboss, 'z'
    z = _add()

    for i in (sel, sel1):
        if i:
            Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
            pdb.gimp_image_remove_channel(j, i)

    Sel.opaque(cause, option=fu.CHANNEL_OP_SUBTRACT)
    return soften_metal_sel(v, z, e)


class RaisedMaze(Metal):
    """Is a metallic-like border with a raised Maze across the Canvas."""

    def __init__(self, *q, **d):
        """
        q: tuple
            Metal spec

        d: dict
            Metal spec
        """
        Metal.__init__(self, *q + (do_matter,), **d)
