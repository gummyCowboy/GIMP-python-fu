#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok, Step as sk
from roller_frame_build import SubBuild
from roller_maya import check_layer
from roller_view_shadow import make_shadow
from roller_view_real import INNER, SHADOW1, SHADOW2


def check_inner_shadow(v, maya):
    """
    Determine if Inner Shadow material is needed.

    v: View
    maya: Maya
    Return: tuple
        of shadow layer
    """
    if maya.is_inner_shadow:
        return check_layer(v, maya, 'inner_shadow', do_inner_shadow)
    return maya.inner_shadow


def check_shadow_1(v, maya):
    """
    Determine if Shadow 1 material is needed.

    v: View
    maya: Maya
    Return: tuple
        of shadow layer
    """
    if maya.is_shadow_1:
        return check_layer(v, maya, 'shadow_1', do_shadow_1)
    return maya.shadow_1


def check_shadow_2(v, maya):
    """
    Determine if Shadow 2 material is needed.

    v: View
    maya: Maya
    Return: tuple
        of shadow layer
    """
    if maya.is_shadow_2:
        return check_layer(v, maya, 'shadow_2', do_shadow_2)
    return maya.shadow_2


def do_shadow_1(v, maya):
    """
    Do the Shadow #1 Preset in the Shadow Preset.

    v: View
    maya: Shadow
    Return: layer or None
        with shadow
    """
    d = maya.value_d

    # list of layer to cast shadow, 'q'
    q = []

    for i in maya.maya_q:
        q += [getattr(i, 'matter')]

    z = q[0].parent.parent if maya.is_wrap else q[0].parent
    return make_shadow(
        v.j, d, z, q, is_wrap=maya.is_wrap, name=z.name + " Shadow 1"
    )


def do_shadow_2(v, maya):
    """
    Do the Shadow #2 Preset in the Shadow Preset.

    v: View
    maya: Shadow
    Return: layer or None
        with shadow
    """
    d = maya.value_d

    # list of layer to cast shadow, 'q'
    q = []

    for i in maya.maya_q:
        q += [getattr(i, 'matter')]

    z = q[0].parent.parent if maya.is_wrap else q[0].parent
    return make_shadow(
        v.j, d, z, q, is_wrap=maya.is_wrap, name=z.name + " Shadow 2"
    )


def do_inner_shadow(v, maya):
    """
    Do the Inner Shadow in the Shadow Preset.

    v: View
    maya: Shadow
    cast: layer
        to cast shadow

    Return: layer or None
        with shadow
    """
    d = maya.value_d
    z = maya.maya_q[0].matter
    z1 = z.parent
    return make_shadow(
        v.j, d, z1, (z,), is_inner=True, name=z1.name + " Inner Shadow"
    )


class Shadow1(SubBuild):
    issue_q = 'shadow_1',
    put = (check_shadow_1, 'shadow_1'),

    def __init__(self, any_group, super_maya, maya_q, k_path, is_wrap):
        """
        maya_q: iterable
            of Maya
            Each Maya has a matter layer and a 'is_matter' attribute.
            The first Maya's matter layer is used by Inner Shadow.

        is_wrap: bool
            If True, then an outer Shadow layer is placed
            at the bottom of the wrapping parent group.
        """
        self.maya_q = maya_q
        self.is_wrap = is_wrap
        SubBuild.__init__(self, any_group, super_maya, k_path + (sk.SHADOW_1,))

    def do(self, v, d):
        """
        Produce output.

        v: View
        d: dict
            Shadow Preset
            {Option key: value}

        Return: bool
            Is True if there is background change.
        """
        self.value_d = d[sk.SHADOW_1]
        self.is_shadow_1 |= self.super_maya.is_shadow

        if not self.is_shadow_1:
            for i in self.maya_q:
                if i.is_matter or i.is_shade:
                    self.is_shadow_1 = True
                    break

        is_back = self.is_shadow_1

        self.realize(v)
        self.reset_issue()
        return is_back


class Shadow2(SubBuild):
    issue_q = 'shadow_2',
    put = (check_shadow_2, 'shadow_2'),

    def __init__(self, any_group, super_maya, maya_q, k_path, is_wrap):
        """
        maya_q: iterable
            of Maya
            Each Maya has a matter layer and a 'is_matter' attribute.
            The first Maya's matter layer is used by Inner Shadow.

        is_wrap: bool
            If True, then an outer Shadow layer is placed
            at the bottom of the wrapping parent group.
        """
        self.maya_q = maya_q
        self.is_wrap = is_wrap
        SubBuild.__init__(self, any_group, super_maya, k_path + (sk.SHADOW_2,))

    def do(self, v, d):
        """
        Produce output.

        v: View
        d: dict
            Shadow Preset

        Return: bool
            Is True if the background changed.
        """
        self.value_d = d[sk.SHADOW_2]
        self.is_shadow_2 |= self.super_maya.is_shadow

        if not self.is_shadow_2:
            for i in self.maya_q:
                if i.is_matter or i.is_shade:
                    self.is_shadow_2 = True
                    break

        is_back = self.is_shadow_2

        self.realize(v)
        self.reset_issue()
        return is_back


class Inner(SubBuild):
    issue_q = 'inner_shadow',
    put = (check_inner_shadow, 'inner_shadow'),

    def __init__(self, any_group, super_maya, maya_q, k_path):
        """
        maya_q: iterable
            of Maya
            Each Maya has a matter layer and a 'is_matter' attribute.
            The first Maya's matter layer is used by Inner Shadow.

        is_wrap: bool
            If True, then an outer Shadow layer is placed
            at the bottom of the wrapping parent group.
        """
        self.maya_q = maya_q
        SubBuild.__init__(
            self, any_group, super_maya, k_path + (sk.INNER_SHADOW,)
        )

    def do(self, v, d):
        """
        Produce output.

        v: View
        d: dict
            Shadow Preset

        Return: bool
            Is True if there is matter change.
        """
        self.value_d = d[sk.INNER_SHADOW]
        self.is_inner_shadow |= self.super_maya.is_shadow or \
            self.maya_q[0].is_matter
        self.realize_vote(v)


class Shadow(SubBuild):
    """Output layer for a Shadow Preset Button."""
    issue_q = 'shadow',
    put = ()

    def __init__(self, any_group, super_maya, maya_q, k_path, is_wrap=True):
        """
        super_maya: Maya
            Has a Shadow option.

        maya_q: iterable
            of Maya
            Each Maya has a matter layer and a 'is_matter' attribute.
            The first Maya's matter layer is used by Inner Shadow.

        is_wrap: bool
            If True, then an outer Shadow layer is placed
            at the bottom of the wrapping parent group.
        """
        self.maya_q = maya_q
        SubBuild.__init__(
            self, any_group, super_maya, k_path + (sk.SHADOW_SWITCH,)
        )

        self.sub_maya[SHADOW1] = Shadow1(
            any_group, self, maya_q, k_path, is_wrap
        )
        self.sub_maya[SHADOW2] = Shadow2(
            any_group, self, maya_q, k_path, is_wrap
        )
        self.sub_maya[INNER] = Inner(any_group, self, maya_q, k_path)

    def do(self, v, d, is_change=False):
        """
        Produce output.

        v: View
        d: dict
            Shadow Preset

        is_change: bool
            If True, then each shadow type has change.

        Return: bool
            If True, then the background has changed.
        """
        self.value_d = d
        self.go = d[sk.SHADOW_SWITCH][ok.SWITCH]
        self.is_shadow |= is_change
        is_back = False

        if self.go:
            is_back |= self.sub_maya[SHADOW1].do(v, d)
            is_back |= self.sub_maya[SHADOW2].do(v, d)
            self.sub_maya[INNER].do(v, d)

        else:
            is_back = any((
                self.sub_maya[SHADOW1].shadow_1,
                self.sub_maya[SHADOW2].shadow_2,
                self.sub_maya[INNER].inner_shadow,
            ))
            self.die(v)

        self.reset_issue()
        return is_back

    def get_any_vote(self):
        """
        Determine the status of Shadow vote.

        Return: bool
            Is True if there is change.
        """
        return any((
            self.is_shadow,
            self.sub_maya[SHADOW1].is_shadow_1,
            self.sub_maya[SHADOW2].is_shadow_2,
            self.sub_maya[INNER].is_inner_shadow
        ))

    def reset_all_issue(self):
        """Call to reset issue when the 'do' function isn't used."""
        self.reset_issue()
        self.sub_maya[SHADOW1].reset_issue()
        self.sub_maya[SHADOW2].reset_issue()
        self.sub_maya[INNER].reset_issue()
