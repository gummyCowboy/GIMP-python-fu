#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import atan2, cos, sin, radians
from random import randint, uniform
from roller_constant_key import Option as ok
from roller_frame import Color, Shadow1
from roller_frame_build import Build
from roller_maya import check_matter, make_frame_group
from roller_maya_blur_behind import BlurBehind
from roller_maya_light import Light
from roller_one import Rect
from roller_one_extract import combine_seed
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_view_real import (
    COLOR, LIGHT, SHADOW, add_wip_layer, get_color, get_light
)
import gimpfu as fu

# oriented with zero at the north direction
RADIAN_135 = 2.35619
RADIAN_180 = 3.14159
RADIAN_225 = 3.92699
RADIAN_270 = 4.71239
RADIAN_315 = 5.49779
RADIAN_45 = .785398
RADIAN_90 = 1.5708

pdb = fu.pdb


def calc_angle_shift(d):
    """
    Randomize the angle-shift amount.

    d: dict
        Corner Tape Preset
        {Option key: value}

    Return: float
        angle shift
    """
    f = d[ok.ANGLE_SHIFT]
    return uniform(radians(-f), radians(f))


def calc_rotated_bounds(maya, tape):
    """
    Calculate the rotated bounds of the
    work-in-progress image in its original size.

    Calculate the transform amount for the x, y vectors.
    The goal of the transform is to calculate
    the corner points of the cell-placed image.

    The function only works when the original image size ratio
    is the same as the cell image's size ratio. The Locked Resize
    Method will leave the ratio the same, but the other Resize
    Methods modify this ratio.

    maya: CornerTape
    tape: Tape
    """
    q = tape.corners
    j = maya.cause.get_image(tape.r_c)

    if j:
        w, h = j.size
        f = tape.rotate

        # center
        w, h = w / 2., h / 2.

        radius = ((w**2) + (h**2))**0.5

        for i in range(4):
            if not i:
                x, y = -w, h

            elif i == 1:
                x, y = w, h

            elif i == 2:
                x, y = w, -h

            else:
                x, y = -w, -h

            x, y = calc_point(0, 0, atan2(x, y) + f, radius)
            q.append((x, y))

        q_x = [i[0] for i in q]
        q_y = [i[1] for i in q]
        u = min(q_x), min(q_y)
        u1 = max(q_x), max(q_y)
        u = abs(u[0] - u1[0]), abs(u[1] - u1[1])
        tape.transform = tape.rect.w / 1. / u[0], tape.rect.h / 1. / u[1]


def calc_point(x, y, angle, radius):
    """
    Return a point on a circle that corresponds to a rotation.

    x, y: int
        center point

    angle : float
        rotation angle in radians

    radius: float
        the radius of the circle in pixels

    Return: tuple
        (x, y) of float
        the point on the circle
    """
    x = (sin(angle) * radius) + x
    y = (cos(angle) * -radius) + y
    return round(x), round(y)


def calc_tape_length(d):
    """
    Calculate tape length.

    d: dict
        Has options.

    Return: int
        tape length
    """
    return max(
        1,
        d[ok.TAPE_LENGTH] + randint(-d[ok.LENGTH_SHIFT], d[ok.LENGTH_SHIFT])
    )


def do_color(v, maya):
    """
    Make a color overlay layer.

    v: View
    maya: CornerTape
    Return: layer or None
        with material
    """
    d = maya.value_d
    a = maya.super_maya
    z = add_wip_layer(
        v, maya, "Color", group=a.group, offset=get_light(a)
    )

    Lay.color_fill(z, d[ok.COLOR_1])
    return z


def do_matter(v, maya):
    """
    Make a tape layer.

    v: View
    maya: CornerTape
    Return: layer or None
        with material
    """
    j = v.j
    z = None
    parent = maya.group
    offset = get_color(maya) + get_light(maya)
    super_ = maya.cause

    if super_.cell_type == 'all':
        group = Lay.group(j, "Group", parent=parent, offset=offset)
        model = maya.model

        for r, c in super_.main_cell_q:
            sel = model.get_image_sel((r, c))

            Sel.load(j, sel)
            if Sel.is_sel(j):
                do_sel(
                    v,
                    maya,
                    Lay.add(
                        j, "Base", parent=group, offset=len(group.layers)
                    ),
                    (r, c)
                )
        z = Lay.merge_group(group)

    else:
        Sel.item(maya.cause.matter)
        if Sel.is_sel(j):
            z = Lay.add(j, "Base", parent=parent, offset=offset)
            z = do_sel(v, maya, z, maya.cause.r_c)

    z = Lay.verify(z)

    if z:
        z.name = maya.group.name + " Corner Tape"
        z.opacity = 34.
        z.mode = fu.LAYER_MODE_DARKEN_ONLY
    return z


def do_sel(v, maya, z, r_c):
    """
    Add tape to an image. Select the image material prior to calling.

    v: View
    maya: CornerTape
    r_c: tuple or None
        cell table index
        of int

    Return: layer or None
        with material
    """
    j = v.j
    a = Tape(maya, r_c, *pdb.gimp_selection_bounds(j)[1:])

    if a.rotate:
        calc_rotated_bounds(maya, a)

    b = a.rect

    # noise layer, 'z1'
    z1 = Lay.clone(z)
    z1.opacity = 50.

    combine_seed(v, a.d)
    pdb.gimp_selection_none(j)
    Gegl.noise_rgb(
        z1,
        uniform(.001, .04),
        uniform(.001, .04),
        uniform(.001, .04),
        1.,                             # alpha
        a.d[ok.SEED] + v.glow_ball.seed
    )
    select_topleft(v, a, b.x, b.y)
    select_top_right(v, a, b.x + b.w, b.y)
    select_bottom_left(v, a, b.x, b.y + b.h)
    select_bottom_right(v, a, b.x + b.w, b.y + b.h)
    Sel.fill(z, (255, 255, 255))
    Sel.invert_clear(z1)

    for i in range(2):
        pdb.plug_in_shift(j, z, 1, 0)
        pdb.plug_in_shift(j, z, 1, 1)

    Lay.blur(z, 2.)

    z = Lay.merge(z1)

    # Darken the edge.
    Sel.item(z)
    pdb.gimp_selection_shrink(j, 1)
    Sel.invert(j)
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                              # coordinate count
        (.0, .0392, 1., .3137)
    )
    return z


def get_corner_point(tape, x, y, corner_x):
    """
    tape: Tape
    x, y: int
        corner point

    corner_x: int
        index to corner point

    Return: tuple
        of int
        corner point
    """
    def _shift():
        """
        Randomize corner-shift amount.

        Return: int
            corner shift
        """
        _a = a.d[ok.CORNER_SHIFT]
        return randint(-_a, _a)

    a = tape

    if a.rotate:
        x1, y1 = a.corners[corner_x]
        x1 *= a.transform[0]
        y1 *= a.transform[1]
        x = x1 + a.center[0]
        y = y1 + a.center[1]

    x += _shift()
    y += _shift()
    return x, y


def select_tape_rect(v, d, angle, x, y, w):
    """
    Define and select a tape rectangle.

    v: View
    d: dict
        Corner Tape Preset
        {Option key: value}

    x, y: int
        start point

    w: int
        length of tape
    """
    w1 = d[ok.TAPE_W]
    x1, y1 = calc_point(x, y, angle - RADIAN_90, w1)
    x2, y2 = calc_point(x1, y1, angle - RADIAN_180, w)
    x3, y3 = calc_point(x2, y2, angle - RADIAN_270, w1)
    Sel.polygon(
        v.j,
        (x, y, x1, y1, x2, y2, x3, y3),
        option=fu.CHANNEL_OP_ADD
    )


def select_bottom_left(v, tape, x, y):
    """
    Make a selection for the bottom-left corner.

    v: View
    tape: Tape
        Has scope variable.

    x, y: int
        corner point
    """
    d = tape.d
    angle = RADIAN_135 + calc_angle_shift(d) + tape.rotate
    x, y = get_corner_point(tape, x, y, 3)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(v, d, angle, x1, y1, w)


def select_bottom_right(v, tape, x, y):
    """
    Make a selection for the bottom-right corner.

    v: View
    tape: Tape
    x, y: int
        corner point
    """
    d = tape.d
    angle = RADIAN_45 + calc_angle_shift(d) + tape.rotate
    x, y = get_corner_point(tape, x, y, 2)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(v, d, angle, x1, y1, w)


def select_topleft(v, tape, x, y):
    """
    Make a selection for the topleft corner.

    v: View
    tape: Tape
    x, y: int
        corner point
    """
    d = tape.d
    angle = RADIAN_225 + calc_angle_shift(d) + tape.rotate
    x, y = get_corner_point(tape, x, y, 0)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(v, d, angle, x1, y1, w)


def select_top_right(v, tape, x, y):
    """
    Make a selection for the top-right corner.

    v: View
    tape: Tape
    x, y: int
        center point
    """
    d = tape.d
    angle = RADIAN_315 + calc_angle_shift(d) + tape.rotate
    x, y = get_corner_point(tape, x, y, 1)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(v, d, angle, x1, y1, w)


class CornerTape(Build):
    """Simulate a tape image holder."""
    is_seeded = True
    issue_q = 'cake', 'matter'
    put = (make_frame_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            enclosing type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        self.do_matter = do_matter

        Build.__init__(self, any_group, super_maya, k_path)

        self.sub_maya[COLOR] = Color(any_group, self, do_color, k_path)
        self.sub_maya[SHADOW] = Shadow1(any_group, self, k_path)
        self.sub_maya[LIGHT] = Light(any_group, self, ok.TRANSLUCENT)
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(any_group, self, k_path)

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            Corner Tape Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: False
            Shadow did not change the background.
        """
        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[COLOR].do(v, d, self.is_matter)
        self.sub_maya[SHADOW].do(v, d, self.is_matter)
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.sub_maya[ok.BLUR_BEHIND].do(v, d, is_back, self.is_matter)
        self.reset_issue()
        return False


class Tape:
    """Is a container for making Corner Tape material."""

    def __init__(self, maya, r_c, x, y, x1, y1):
        """
        v: View
        maya: Maya
        r_c: tuple or None
            cell index for WIP image

        x, y: int
            topleft corner of the image selection

        x1, y1: int
            bottom-right corner of the image selection
        """
        # Is a sequence of four x, y coordinate tuple.
        # topleft, top-right,bottom-right, bottom-left
        self.corners = []

        # Image selection rectangle, 'rect'
        w = x1 - x
        h = y1 - y
        self.rect = Rect(x, y, w, h)

        # Image selection center point, 'center'
        self.center = x + w / 2., y + h / 2.

        # image rotation
        self.rotate = radians(maya.cause.value_d[ok.ROTATION])

        # float
        # Use when an image has rotation to transform its corner points.
        # Set to failure value, '1.'.
        self.transform = 1., 1.

        # dict
        # Corner Tape Preset
        self.d = maya.value_d

        # tuple or None
        # cell index
        # Is None for Canvas.
        self.r_c = r_c
