#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color, Signal as si
from roller_constant_key import Widget as wk
from roller_widget_box import Eventful
import gobject
import gtk


class ColorfulButton(Eventful, gobject.GObject):
    """This EventBox can change color and respond to signals."""
    # Are signals that can be emitted by this class.
    sig_arg = gobject.SIGNAL_RUN_LAST, None, (gobject.TYPE_PYOBJECT,)
    __gsignals__ = {si.ACCEPT_WINDOW: sig_arg}

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        super(ColorfulButton, self).__init__(None)

        # for custom signal(s)
        gobject.GObject.__init__(self)

        self.background_color = d[wk.COLOR]
        self.any_group = d[wk.ANY_GROUP]
        self.key = d[wk.KEY] if wk.KEY in d else None
        self.update_creator = d[wk.RELAY]
        self.roller_win = d[wk.ROLLER_WIN]

        # Embed the Widget inside a VBox and an HBox.
        g = self.label = gtk.Label(d[wk.TEXT])
        g1 = self.hbox = gtk.HBox()

        self.add(g1)
        g1.add(g)

        a = gtk.gdk
        p = self.connect

        # signals to respond to
        for i in (a.BUTTON_PRESS_MASK, a.FOCUS_CHANGE_MASK, a.KEY_PRESS_MASK):
            self.add_events(i)

        self.set_can_focus(1)
        self.set_color(self.background_color)

        # Avoid the 'button_press_event' as it fails the Widget.
        p('button_release_event', self.on_click)
        p('key_press_event', self.on_key_press)
        p('focus_in_event', self.focus_in)
        p('focus_out_event', self.focus_out)

    def set_color(self, color):
        """
        Set the button's face color.

        color: gtk.gdk.Color
            button color
        """
        self.modify_bg(gtk.STATE_NORMAL, color)

    def on_click(self, *_):
        """Pass the click event to the button owner."""
        self.grab_focus()
        self.update_creator(self)
        return True

    def on_key_press(self, g, a):
        """
        Process a 'space' and 'Return' key-press.

        g: self
        a: signal
            key-press event

        Return: None or True
            Is true when key-press is processed.
        """
        n = gtk.gdk.keyval_name(a.keyval)

        if n == 'space':
            self.update_creator(g)
            return True
        elif n == 'Return':
            g.roller_win.emit(si.ACCEPT_WINDOW, g)
            return True

    def focus_in(self, *_):
        """Change the color of the button to show focus."""
        self.set_color(Color.FOCUS_COLOR)
        return True

    def focus_out(self, *_):
        """Change the color of the button to normal."""
        self.set_color(self.background_color)
        return True

    def set_label(self, n):
        """
        Change the button's text.

        n: string
            for Label
        """
        self.label.set_text(n)

    def set_size(self, w=10, h=10):
        """
        Try to set the size of the button.

        w: int
            width of button

        h: int
            height of button
        """
        self.set_size_request(width=w, height=h)

    def set_text_color(self, color):
        """
        Set the color of the button's text.

        color: gtk.gdk.Color
            for the text
        """
        self.label.modify_fg(gtk.STATE_NORMAL, color)

    def show(self):
        """Display the custom button."""
        super(ColorfulButton, self).show()
        for g in (self.hbox, self.vbox, self.label):
            g.show()


class SwitchButton(ColorfulButton):
    """Use to process cell connection events."""

    def __init__(self, r, c, **d):
        """
        Create the SwitchButton.

        r, c: int
            cell index

        d: dict
            Has init values.
        """
        self.gate = 0
        self.r = r // 2
        self.c = c // 2
        self._cell_table = d[wk.CELL_TABLE]
        self.pad = d[wk.CONTAINER]
        self.on_gate_action = d[wk.RELAY]
        d[wk.RELAY] = self.on_switch_action
        ColorfulButton.__init__(self, **d)

    def on_switch_action(self, _):
        """
        Reverse the switch setting. Call the connection operator.

        Return: True
            Tell GTK that the signal is handled.
        """
        x = self.gate = int(not self.gate)

        self.set_label(("+", "-")[x])
        self.on_gate_action[x](self._cell_table[self.r][self.c])
        return True


# Register the custom signals.
gobject.type_register(ColorfulButton)
