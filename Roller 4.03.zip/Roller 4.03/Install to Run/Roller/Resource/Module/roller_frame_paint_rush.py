#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame_build import Build
from roller_maya import check_frame_cake, check_matter, make_frame_group
from roller_maya_shadow import Shadow
from roller_one import Mode
from roller_one_fu import Lay, Sel
from roller_view_real import clone_background
import gimpfu as fu

MIXED_EDGE = ff.WHITE_MIXED, ff.GREY_MIXED
MODE_1 = (
    fu.LAYER_MODE_DIVIDE,
    fu.LAYER_MODE_DIVIDE,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT
)
MODE_2 = (
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_SUBTRACT
)
MODE_3 = (
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_NORMAL
)
MODE_4 = (
    fu.LAYER_MODE_MULTIPLY,
    fu.LAYER_MODE_DIFFERENCE,
    fu.LAYER_MODE_DIFFERENCE,
    fu.LAYER_MODE_MULTIPLY,
    fu.LAYER_MODE_DIFFERENCE,
    fu.LAYER_MODE_DIFFERENCE
)
pdb = fu.pdb


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: PaintRush
    Return: layer
        with color
    """
    def clear_selection():
        """
        Clear the center selection and the area outside of the image material.
        """
        Sel.load(j, sel1)
        Sel.invert_clear(z)
        Sel.load(j, sel)
        Lay.clear_sel(z)

    j = v.j
    cause = maya.cause.matter
    parent = cause.parent
    d = maya.value_d
    group = Lay.group(
        j,
        "Paint Rush WIP",
        parent=parent,
        offset=Lay.offset(cause)
    )
    x = ff.PAINT_RUSH_TYPE.index(d[ok.EDGE_TYPE])
    group.mode = fu.LAYER_MODE_LIGHTEN_ONLY
    z = first_z = Lay.clone_opaque(cause)
    z.mode = MODE_1[x]

    # A mask interferes with 'clone_background'.
    Lay.discard_mask(maya.group)

    Sel.item(z)
    Sel.invert_clear(z)
    pdb.gimp_image_reorder_item(j, z, group, 0)

    # amount, '2.', wrap, '1', Sobel, '0'
    pdb.plug_in_edge(j, z, 2., 1, 0)

    z = dark_z = Lay.clone(z, n="Dark")
    z.mode = MODE_2[x]

    pdb.gimp_image_lower_item_to_bottom(j, z)

    z = light_z = Lay.clone(z, n="Light")
    z.mode = MODE_3[x]
    w = d[ok.FRAME_W]

    while w:
        w1 = min(w, 500)
        w -= w1
        Lay.blur(z, w1)

    if d[ok.EDGE_TYPE] in MIXED_EDGE:
        w = d[ok.FRAME_W] // 2
        while w:
            w1 = min(w, 500)
            w -= w1
            Lay.blur(z, w1)

    pdb.gimp_image_lower_item_to_bottom(j, z)

    # Protect the center with a grey layer.
    z = Lay.clone(dark_z, n="Burn")
    z.mode = fu.LAYER_MODE_BURN

    pdb.gimp_image_reorder_item(j, z, group, 2)
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .5, 1., .5)
    )
    Sel.item(z)
    pdb.gimp_selection_shrink(j, d[ok.FRAME_W])

    sel = pdb.gimp_selection_save(j)

    Sel.invert_clear(z)
    Sel.item(first_z)

    sel1 = pdb.gimp_selection_save(j)
    z = Lay.clone(light_z, n="Accent")
    z.mode = MODE_4[x]

    pdb.gimp_image_lower_item_to_bottom(j, z)

    z = Lay.add(j, "Grey", parent=group, offset=len(group.layers))

    Lay.color_fill(z, (127, 127, 127))

    n = d[ok.EDGE_MODE]
    z = z1 = Lay.merge_group(group)

    Lay.set_mode(z, Mode.get_mode({ok.MODE: n}))
    clear_selection()

    if n == "Burn":
        pdb.gimp_drawable_invert(z, 0)

    else:
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

    if d[ok.POST_BLUR]:
        blur_z = clone_background(v, z, n="Post Blur")

        pdb.gimp_image_remove_layer(j, z)

        z = blur_z

        Lay.blur(z, d[ok.POST_BLUR])
        clear_selection()

    if d[ok.CER][ok.EMBOSS]:
        emboss_z = clone_background(v, z, is_hide=False, on_top=True)
        z = Lay.clone(emboss_z, n="Overlay")
        z.mode = fu.LAYER_MODE_OVERLAY

        pdb.plug_in_emboss(
            j, z,
            v.glow_ball.azimuth,
            v.glow_ball.elevation,
            3,                  # depth
            1                   # emboss
        )
        Sel.load(j, sel)

        for i in (z, z1, emboss_z):
            if pdb.gimp_item_is_valid(i):
                Lay.clear_sel(i, keep_sel=True)

        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

        Sel.load(j, sel1)
        Sel.invert_clear(z)

    if d[ok.CER][ok.COLORIZE]:
        z = clone_background(
            v, z, n="Colorify", is_hide=False, on_top=True
        )
        z.opacity = d[ok.COLORIZE_OPACITY]

        pdb.plug_in_colorify(j, z, d[ok.COLOR_1])

        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        clear_selection()

    pdb.gimp_image_remove_channel(j, sel)
    pdb.gimp_image_remove_channel(j, sel1)

    z.name = parent.name + " Paint Rush"
    return z


class PaintRush(Build):
    """Create a frame over the subject material by altering it."""
    is_embossed = True
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        self.do_matter = do_matter

        Build.__init__(
            self, any_group, super_maya, k_path=[k_path, k_path + (ok.CER,)]
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (self.cause, self), k_path + (ok.SRR, ok.SHADOW)
        )

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)

        is_back = self.sub_maya[ok.SHADOW].do(v, d[ok.SRR][ok.SHADOW])

        self.reset_issue()
        return is_back
