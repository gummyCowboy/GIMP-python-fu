#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_port_preview import PortPreview
from roller_widget_node import Piece


class PortBrush(PortPreview):
    """Is a display portal for Brush Preset Widget."""
    window_key = "Brush"

    def __init__(self, d, g):
        """
        Create the Port.

        d: dict
            Has init values.

        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_brush(self, box):
        """
        Draw and load the option group.

        box: GTK container
            to receive group
        """
        self.draw_group(Piece(ok.BRUSH_D, box, self.safe.any_group.item))

    def draw(self):
        """
        Draw the Port's widgets.

        g: VBox
            container for the Widgets
        """
        self.draw_column((self._draw_brush, self.draw_process))

    def get_group_value(self):
        """
        Get the Preset value.

        Return: dict
            Brush Preset
        """
        return self.preset.get_a()
