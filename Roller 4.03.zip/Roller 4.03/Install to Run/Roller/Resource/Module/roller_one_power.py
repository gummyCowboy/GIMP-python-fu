#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import Signal as si
import gobject


class Power(gobject.GObject, object):
    """
    Accept signal from object. Keep signal in an OrderedDict.
    Process the signal list when the interface is idle.
    """
    # Reference
    #   github.com/sebp/PyGObject-Tutorial/blob/master/source/objects.txt
    #   library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
    #   zetcode.com/gui/pygtk/signals/
    #   stackoverflow.com/questions/66730/how-do-i-create-a-new-signal-in-pygtk

    # Are signals that can be emitted by this class.
    __gsignals__ = si.POWER_D

    def __init__(self, the):
        """
        the: The
        """
        # for custom signal(s)
        gobject.GObject.__init__(self)
        self._pulse = OrderedDict()
        self._crib = {}
        self.the = the

    def add(self, a, n, arg):
        """
        Add a signal to pulse.

        a: object
            The object to emit the signal.

        n: string
            signal id

        arg: value
            Sent with signal.
        """
        k = id(a), n

        if k in self._pulse:
            self._pulse.pop(k)
        self._pulse[k] = a, n, arg

    def carry(self, baby):
        self._crib[id(baby)] = baby

    def drop(self, baby):
        """
        Remove a Model's update connection.

        baby: Baby
            Is in the crib.
        """
        self._crib.pop(id(baby))

    def plug(self, n, arg):
        """
        Add a Power signal.

        n: string
            Signal type

        arg: value
        """
        self.add(self, n, arg)

    def press(self):
        """Clear the signal list and have sub-signal handler do the same."""
        # There are possible semi-circular usage of Power by a crib sub.
        # experimental discovery, three levels
        # of dependency of signal receiver, '3'
        for i in range(3):
            while self._pulse:
                self.send()

            # Baby id, Baby; 'i, a'
            for _, a in self._crib.items():
                a.press()

    def send(self):
        """Send out a signal found in pulse."""
        if self._pulse:
            # gobject id, gobject; 'i, a'
            for i, a in self._pulse.items():
                sender, signal, arg = a

                self._pulse.pop(i)
                sender.emit(signal, arg)
                break
        else:
            if not self.the.load_count:
                # Baby id, Baby; 'i, a'
                for _, a in self._crib.items():
                    a.rock()
        return True


# Register the custom signals.
gobject.type_register(Power)
