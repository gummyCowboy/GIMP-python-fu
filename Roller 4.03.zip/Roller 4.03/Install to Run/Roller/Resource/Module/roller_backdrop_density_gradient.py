#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_maya_style import Style
from roller_one import Mode
from roller_one_extract import combine_seed
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_view_real import (
    add_sub_base_group,
    add_wip_layer,
    do_gradient_for_layer,
    finish_style,
    insert_copy_above
)
from roller_view_hub import get_gradient_factors
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Do the Backdrop Style.

    v: View
    maya: Style
    Return: layer
        with Density Gradient
    """
    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya)
    z = add_wip_layer(v, maya, "Plasma")
    group = Lay.group(j, "WIP", parent=parent, z=z)

    combine_seed(v, d)
    pdb.gimp_selection_none(j)

    # lowest turbulence, '1.'
    pdb.plug_in_plasma(j, z, d[ok.SEED] + v.glow_ball.seed, 1.)

    z = add_wip_layer(v, maya, "Difference", group=group)
    z.mode = fu.LAYER_MODE_DIFFERENCE

    # medium turbulence, '3.5'
    pdb.plug_in_plasma(j, z, randint(0, 100000), 3.5)

    z = z1 = add_wip_layer(v, maya, "Difference 2", group=group)
    z.mode = fu.LAYER_MODE_DIFFERENCE

    # highest turbulence, '7.'
    pdb.plug_in_plasma(j, z, randint(0, 100000), 7.)

    z = insert_copy_above(v, z, group.layers[0])
    z.mode = fu.LAYER_MODE_GRAIN_EXTRACT

    for i in ((255, 0, 0), (0, 255, 0), (255, 0, 255)):
        pdb.plug_in_colortoalpha(j, z, i)

    pdb.plug_in_unsharp_mask(
        j, z1,
        3.,                     # radius
        100.,                   # amount
        .0                      # threshold
    )
    z2 = Lay.clone(z1, n="Blur")
    Lay.blur(z1, 3)

    z1.mode = fu.LAYER_MODE_NORMAL
    z2.mode = fu.LAYER_MODE_DIFFERENCE
    z = Lay.clone(z1, n="HSV Saturation")
    z.mode = fu.LAYER_MODE_HSV_SATURATION

    pdb.gimp_image_reorder_item(j, z, group, 0)

    z = Lay.clone(z, n="Difference #3")
    z.mode = fu.LAYER_MODE_DIFFERENCE
    z = insert_copy_above(v, z, group.layers[0])
    z.mode = fu.LAYER_MODE_EXCLUSION

    Gegl.emboss(z, v.glow_ball.azimuth, 30, 2)

    z1 = Lay.clone(z, n="Exclusion #2")
    z1.mode = fu.LAYER_MODE_EXCLUSION
    e = get_default_value(by.GRADIENT_FILL)

    e.update(d)

    Lay.merge_group(group)

    e[ok.GRADIENT] = d[ok.GBR][ok.GRADIENT]
    e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
        get_gradient_factors(d[ok.GRADIENT_ANGLE])
    z = do_gradient_for_layer(v, e, parent, 0)
    z.mode = Mode.get_gradient_mode(d)

    Lay.merge(z)
    return finish_style(Lay.merge_group(parent), "Density Gradient")


class DensityGradient(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.GBR
    is_dependent = False
    is_seeded = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        k_path = d['k_path']
        d['k_path'] = [k_path, k_path + (ok.GBR,)]
        Style.__init__(self, *q + (make_style,), **d)
