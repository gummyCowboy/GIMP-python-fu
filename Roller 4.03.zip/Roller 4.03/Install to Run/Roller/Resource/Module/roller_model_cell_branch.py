#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Option as ok
from roller_model import CellPast, Model, CELL_CHAIN
from roller_one_the import The
import gimpfu as fu

pdb = fu.pdb


class CellBranch(Model):
    """Use with Model having only a Cell-branch."""

    def __init__(self, model_name):
        """
        model_name: string
            Identify the model.
        """
        Model.__init__(self, model_name, CellPast, CELL_CHAIN)
        self.rectangle = 0, 0, 0, 0
        self._handle_d[
            self.baby.connect(si.RECTANGLE_CHANGE, self.on_rectangle_change)
        ] = self.baby
        self._handle_d[
            The.power.connect(si.RESIZE, self.on_resize)
        ] = The.power
        self.on_resize(None, None)

    def on_rectangle_change(self, _, arg):
        """
        Update the Cell's rectangle and its dependent.

        _: Model
            Sent the signal.

        arg: tuple
            (Rectangle Preset, is sequence flag)
        """
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        x, y, w, h = The.view.wip.rect
        self.rectangle = (
            # position x, y
            x + d[ok.POSITION_X][0] + int(d[ok.POSITION_X][1] * w),
            y + d[ok.POSITION_Y][0] + int(d[ok.POSITION_Y][1] * h),

            # size w, h
            max(1, d[ok.CELL_W][0] + int(d[ok.CELL_W][1] * w)),
            max(1, d[ok.CELL_H][0] + int(d[ok.CELL_H][1] * h))
        )
        p(
            si.RECTANGLE_CALC, self.past.did_rectangle(self.rectangle)
        )

    def on_resize(self, _, arg):
        """
        Update the Cell's default Canvas setting on a render resize event.

        _: Power
            Sent the Signal.

        arg: list
            Plan and Work vote.
        """
        self.canvas_rect = The.view.wip.rect
        self.canvas_pocket = The.view.wip.clone()

    def update_type(self, arg):
        """
        Update the Model's the Cell Type dependency.

        arg: tuple
            (Cell Type Preset, is sequence flag)
            {Option key: value}
            A sequence is processed immediately.
        """
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        self.cell_shape = d[ok.CELL_SHAPE]
        vote_d = super(CellBranch, self).update_type(arg)

        self.adapt_missing_cell_step(is_sequence)
        p(si.CELL_RECT_CALC, vote_d)
