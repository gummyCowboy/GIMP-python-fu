#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_model_goo import Goo
from roller_one import Rect
from roller_one_extract import Shape


def calc_grid(model, o, get_offset, get_octagon):
    """
    Calculate cell rectangle for a Model's cell.

    model: Model
    o: One
        with Cell Type reference

    get_offset: function
        Use to get the x, y offset for an octagon cell.

    get_octagon: function
        Use to assemble the octagon polygon for the plaque.

    Return: list
        [Plan vote, Work vote]
    """
    vote_d = {}
    did_cell = model.past.did_cell
    row, column = model.division
    goo_d = model.goo_d
    x, y, canvas_w, canvas_h = model.canvas_pocket.rect

    # intersect points
    q_x = []
    q_y = []

    if o.grid_type == gr.CELL_SIZE:
        # Correct cell size overflow.
        w, h = min(canvas_w, o.column_width), min(canvas_h, o.row_height)

        s = w * column, h * row
        w, h = w / 1., h / 1.
        x, y = Shape.calc_pin_offset(
            o.pin_corner, (canvas_w, canvas_h), s, x, y
        )

    elif o.grid_type == gr.SHAPE_COUNT:
        w = canvas_w / column
        h = canvas_h / row
        w = min(w, h)
        s = w * column, w * row
        w, h = w, w
        x, y = Shape.calc_pin_offset(
            o.pin_corner, (canvas_w, canvas_h), s, x, y
        )

    else:
        w = canvas_w / 1. / column
        h = canvas_h / 1. / row

    # Calculate cell rectangle.
    for _ in range(column):
        q_x.append(x)
        x += w

    for _ in range(row):
        q_y.append(y)
        y += h

    q = get_offset(w, h)

    for r_c in model.cell_q:
        r, c = r_c
        x, y = position = q_x[c], q_y[r]
        size = max(1, w), max(1, h)
        a = goo_d[r_c] = Goo(r_c)
        a.cell = a.merged = Rect(*position + size)
        a.plaque = get_octagon(x, y, w, h, q)
        vote_d[r_c] = did_cell(r_c)
    return vote_d


class GridOctagon:
    """
    Calculate the coordinates and the size of cells.
    The cells are octagon shaped.
    """

    @staticmethod
    def calc(model, o):
        """
        Calculate cell rectangle for a Model's cell.

        model: Model
        o: One
            with Cell Type reference

        Return: list
            [Plan vote, Work vote]
        """
        return calc_grid(
            model, o, Shape.calc_octagon_offset, Shape.calc_octagon_shape
        )


class GridSideOctagon:
    """
    Calculate the coordinates and the size of cells.
    The cells are octagon shaped.
    """

    @staticmethod
    def calc(model, o):
        """
        Calculate cell rectangle for a Model's cell.

        model: Model
        o: One
            with Cell Type reference

        Return: list
            [Plan vote, Work vote]
        """
        return calc_grid(
            model,
            o,
            Shape.calc_octagon_side_to_side_offset,
            Shape.calc_octagon_side_to_side_shape
        )
