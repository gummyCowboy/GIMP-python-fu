#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from random import randint, seed
from roller_constant_for import (
    Grid as gr, Issue as vo, Shape as sh, Triangle as ft
)
from roller_constant_key import (
    Group as gk, Item as ie, Option as ok, Step as sk, Widget as wk
)
from roller_one import Base
from roller_one_the import The
import math
import gimpfu as fu

RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP
pdb = fu.pdb


def accept_vote(d, key, issue, vote):
    """
    Update a relational vote dict with issue votes. Is
    recursive when the 'issue' value is a tuple of Issue.

    d: dict
        to hold vote; for Plan or Work

    key: string
        Option

    issue: string or tuple
        string: type of change
        tuple: multiple Issue

    vote: bool
        Is True if the Widget has changed value from its View value.
    """
    if issue and issue != vo.NULL:
        if isinstance(issue, tuple):
            for i in issue:
                accept_vote(d, key, i, vote)
        else:
            if issue not in d:
                d[issue] = {}
            d[issue][key] = vote


def calc_margin(v, d):
    """
    Return the margins after adding the
    fixed-value and the factor margins together.

    v: View
    d: dict or None
        Margin Preset

    Return: list
        top, bottom, left, right
        of numeric
    """
    top = bottom = left = right = 0
    w, h = v.wip.size

    if d and d[ok.SWITCH]:
        top = Factor.get_factor(d[ok.TOP_MARGIN], h)
        bottom = Factor.get_factor(d[ok.BOTTOM_MARGIN], h)
        left = Factor.get_factor(d[ok.LEFT_MARGIN], w)
        right = Factor.get_factor(d[ok.RIGHT_MARGIN], w)

        # Compensate for margin overflow
        # by reserving one pixel for the image.
        if top + bottom >= h:
            top = h / 2.
            bottom = h - top - 1
        if left + right >= w:
            left = w / 2.
            right = w - left - 1
    return top, bottom, left, right


def calc_shift_rect(v, d):
    """
    Calculate a rectangle from another rectangle given a Shift Preset.

    v: View
    d: dict
        Shift Preset

    Return: tuple
        x, y, w, h
        the transformed rectangle
    """
    if d and d[ok.SWITCH]:
        combine_seed(v, d)

        w, h = v.wip.size

        # size
        w1 = Factor.get_factor(d[ok.WIDTH_MOD], w)
        h1 = Factor.get_factor(d[ok.HEIGHT_MOD], h)
        shift_w = Factor.get_factor(d[ok.JITTER_W], w)
        shift_h = Factor.get_factor(d[ok.JITTER_H], h)
        w1 += randint(-shift_w, shift_w)
        h1 += randint(-shift_h, shift_h)

        # position
        x = Factor.get_factor(d[ok.OFFSET_X], w)
        y = Factor.get_factor(d[ok.OFFSET_Y], h)
        shift_x = Factor.get_factor(d[ok.JITTER_X], w)
        shift_y = Factor.get_factor(d[ok.JITTER_Y], h)
        x += randint(-shift_x, shift_x)
        y += randint(-shift_y, shift_y)
        return x, y, w1, h1

    # no change
    return .0, .0, .0, .0


def collect_step(d, render_key, step_q):
    """
    Recursively add navigation step key found in
    a hierarchical step dict to a list.

    d: dict
        with step key structure

    step_key: tuple
        (item, ...)

    step_q: list
        step key collection
    """
    k = render_key[-1]
    step_q += [render_key]
    if wk.ITEM in d[k]:
        for k1 in d[k][wk.ITEM]:
            collect_step(
                d[k][wk.ITEM],
                render_key + (k1,),
                step_q
            )


def combine_seed(v, d):
    """
    Seed Python's random output with combined global and local seed values.

    v: View
    d: dict
        Has a SEED option.
    """
    seed(v.glow_ball.seed + d[ok.SEED])


def extract_value_d(step_key, d):
    """
    Get the Widget value dict for an AnyGroup

    step_key: tuple
        sequenced navigation Node

    d: dict
        Has an AnyGroup value for the step key.

    Return: dict
        {Option key: Widget value}
    """
    any_group = d[step_key] if step_key in d else None
    if any_group:
        return any_group.get_value_d()


def find_visible_preset():
    """
    Find the navigation step key of the visible Preset AnyGroup.
    Know that the terminal group in the navigation tree is not a Node.

    Return: tuple
        (item key, ...)
    """
    def _shoot(_group, _go):
        """
        Find the step key of the visible selected AnyGroup.

        _group: AnyGroup
            Has item.

        _go: bool
            If True, then the last
        """
        if _go:
            _node = _group.item.node
            _x = _node.get_sel_x()
            _x = 0 if _x is None else _x
            _item = _node.get_branch(_x)
            _step_k = _item.any_group.step_key

            if _item.group_type != 'node':
                _go = False
            else:
                _group1 = get_group(_step_k)
                if _group1.item.node:
                    _go, _step_k = _shoot(_group1, _go)
        return _go, _step_k

    get_group = The.helm.get_group
    return _shoot(get_group(sk.STEPS), True)[1]


def find_canvas_margin(step_key):
    """
    Determine if a Canvas Margin step is online.

    step_key: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(step_key, (ie.CANVAS, ie.MARGIN)))


def find_canvas_shift(step_key):
    """
    Determine if a Canvas Shift step is online.

    step_key: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(step_key, (ie.CANVAS, ie.SHIFT)))


def find_cell_margin(step_key):
    """
    Determine if a Cell Margin step is online.

    step_key: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(step_key, sk.CELL_MARGIN))


def find_cell_shift(step_key):
    """
    Determine if a Cell Shift step is online.

    step_key: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(step_key, sk.CELL_SHIFT))


def get_branch_value_d(step_key):
    """
    Get a SuperPreset value dict.

    step_key: tuple
        SuperPreset key in step dict

    Return: dict
        {step key: value}
    """
    d = {}
    helm = The.helm
    get_group = helm.get_group
    q = helm.get_branch_step_q(step_key)

    for i in q:
        a = get_group(i)
        if a.item.group_type in ('node', 'preset'):
            d[i] = a.get_value_d()
    return d


def get_cell_shift(step_key):
    """
    Get a Cell Shift Preset value dict.

    step_key: tuple
        Has a Model reference.

    Return: dict
        Shift Preset
    """
    return get_value_dict(make_model_key(step_key, sk.CELL_SHIFT))


def get_gradient_light():
    """
    Get the Gradient Light Preset value dict.

    step_key: tuple
        Has a Model reference.

    Return: dict
        Shift Preset
    """
    return get_value_dict(sk.GRADIENT_LIGHT)


def get_model(k):
    """
    Return the Model instance for a step key. If the step key
    is not part of a Model branch, then return None.

    k: tuple
        step key
        Has a Model id in position one.

    Return: Model instance or None
    """
    if len(k) > 1:
        return The.model_id.get_model(k[1])


def get_model_branch(k):
    """
    Clip the branch from a step key.

    k: tuple
        navigation step key

    Return: tuple
        any -> (Node key,), (Group key,), (Node key, Group key)
    """
    return k[2:]


def get_model_list_group():
    """
    Fetch the AnyGroup of the ModelList.

    Return: AnyGroup or None
        the ModelList group
    """
    return The.helm.get_group(sk.MODEL)


def get_model_name_list():
    """
    Compile a list of Model names appearing in the navigation tree.

    Return: list
        of Model name
    """
    a = The.helm.get_group(sk.EXTRA)
    return a.widget_d[ok.NODE].get_label_q()[1:]


def get_node_row(d):
    """
    Make a list of selected Node row from a SuperPreset.
    Remove Node reference from the SuperPreset.

    d: dict
        SuperPreset type

    Return: list
        [(AnyGroup with Node, row index)]
    """
    q = []
    get_group = The.helm.get_group

    # value dict, 'e'
    for step_key in d.keys():
        any_group = get_group(step_key)
        if any_group:
            e = d[step_key]

            if e:
                for k, a in e.items():
                    # A loaded Node has a selected
                    # row item in its value dict.
                    if k == 'node':
                        d.pop(step_key)
                        if a and any_group.item.node:
                            # (Node, row index)
                            q += [(any_group.item.node, a[sk.SELECTED_ROW])]
            else:
                # The default Node value is None.
                d.pop(step_key)
    return q


def get_option_list_key(d):
    """
    Find the choice key in a OptionList Preset.

    d: dict
        OptionList Preset

    Return: string or None
        key to the option in the OptionList Preset
        Is None if there is a failure as in an empty dict.
    """
    k = None

    for k in d:
        if k != ok.SWITCH:
            break
    return k


def get_option_list_choice(d):
    """
    Fetch an OptionList key and the option's dictionary.

    d: dict
        Backdrop Style or Frame Preset

    Return: tuple
        (key, Preset value dict)
    """
    k = get_option_list_key(d)
    return k, d[k]


def get_parent_node(step_key):
    """
    Get the Node of a branched AnyGroup.
    The Node may not be in the interface step dict.

    step_key: tuple
        of the branch group

    Return: Node or None
        for the branch group
    """
    k = step_key[:-1]
    any_group = The.helm.get_group(k)
    if any_group:
        return any_group.item.node


def get_planner(step_key):
    """
    Get a Model's Cell / Rectangle Preset value dictionary.

    step_key: tuple
        Is a navigation step key with a Model id reference.
    """
    return get_property_group(step_key).widget_d[ok.PLANNER]


def get_property_group(step_key):
    return The.helm.get_group(make_model_key(step_key, (ie.PROPERTY,)))


def get_step_d(step_q):
    """
    Get the navigation step key dict of a navigation step key list.

    step_q: list
        [step key]

    Return: dict
        {step key: value dict}
    """
    # steps in the View, {step key: option value dict}, 'step_d'
    step_d = OrderedDict()
    get_group = The.helm.get_group

    for i in step_q:
        # AnyGroup, 'a'
        a = get_group(i)

        # Is a terminal point of this branch.
        if a.item.group_type in ('node', 'preset'):
            step_d[i] = a.get_value_d()
    return step_d


def get_value_dict(step_key):
    """
    Get a Widget value dict for an AnyGroup.

    step_key: tuple
        sequenced navigation Node

    Return: dict
        {option key: Widget value}
    """
    any_group = The.helm.get_group(step_key)
    if any_group:
        return any_group.get_value_d()


def get_type_from_step(step_key):
    """
    Get a Widget-key-based Cell Type Preset dict.

    step_key: tuple
        Has a Model Prefix.

    Return: dict
        {Widget key: Widget value}
        Cell Type Preset
    """
    return get_value_dict(make_model_key(step_key, sk.CELL_TYPE))


def make_model_key(k, q):
    """
    Given a Model branch key, append a key to it.

    k: tuple
        Is a Model branch.

    q: tuple
        any -> (Node key,), (Group key,), (Node key, Group key)
    """
    # A Model branch is made of two items, '2'.
    return k[:2] + q


def make_panel_key(step_key, model_name=None):
    """
    Make a panel-usable key from a step key.
    Swap the Model id with a Model name.

    step_key: tuple
        for AnyGroup

    model_id: string or None
        Use to prefetch the Model name.

    Return: tuple
        NodePanel usable key
    """
    a = len(step_key)

    if a < 2:
        # no Model
        return step_key

    if model_name is None:
        model_name = The.model_id.get_name(step_key[1])

    if model_name:
        return step_key[:1] + (model_name,) + step_key[2:]

    # no model
    return step_key


def make_render_key(step_key, model_type):
    """
    Make a render key from a step key. This is done
    by swapping the Model id for a Model type.

    render_key: tuple
        for AnyGroup

    model_type: string
        Model type key
    """
    a = len(step_key)

    if a <= 1:
        # no Model
        return step_key

    elif a == 2 and step_key[1] == gk.MODEL:
        # no Model
        return step_key
    return step_key[:1] + (model_type,) + step_key[2:]


def make_step_key(key):
    """
    Make a navigation step key from a render key. This
    is done by swapping the Model type with a Model id.

    key: tuple
        for AnyGroup
        panel key

    Return: tuple
        step_key
    """
    a = len(key)

    if a <= 1:
        # no Model
        return key

    elif a == 2 and key[-1] == gk.MODEL:
        # no Model
        return key

    model_id = The.model_id.get_id(key[1])

    if model_id:
        return key[:1] + (model_id,) + key[2:]

    # no model
    return key


def scour(d, e, seek):
    """
    Recursively peruse a group definition dict collecting Widget init value.

    d: dict
        Reflect group tree structure.
        {option key: option value or dict of option value}

    e: dict
        Is an option group definition.

    seek: string
        Is the option key to collect in the data definition tree.

    Return: dict
        with option value
    """
    for i, a in e.items():
        if isinstance(a, dict):
            if seek in a:
                d[i] = a[seek]
            else:
                if i == wk.SUB:
                    # The SUB key is not part of the value dict.
                    b = d
                else:
                    b = d[i] = {}

                scour(b, a, seek)
                if not b and i in d:
                    d.pop(i)
    return d


def translate_to_id(d):
    """
    Translate a Model name to a Model id.

    d: dict
        of SuperPreset

    n: string
        Model name

    identity: int
        Is unique to a Model.

    Return: dict
        with step having translated name to identity
    """
    e = {}

    for k in d:
        e[make_step_key(k)] = d[k]
    return e


def translate_to_name(d):
    """
    Replace numeric Model id with its corresponding Model name.

    d: dict
        of steps

    Return: dict
        with translation
    """
    e = {}

    for i, a in d.items():
        e[make_panel_key(i)] = a
    return e


class Shape:
    """Organize functions related to cell and mask shape."""

    @staticmethod
    def bounds(a):
        """
        Return the bounds of a shape.

        a: iterable or dict
            The iterable has x, y numeric pairs.
            The dict of an ellipse has x, y, w, h.

        Return: tuple
            x, y, w, h
            the bounds of the shape
        """
        def _range(_a):
            return min(_a), max(_a)

        if len(a) == 4:
            return a
        else:
            b = len(a)
            q_x = [a[i] for i in range(0, b, 2)]
            q_y = [a[i] for i in range(1, b, 2)]
            min_x, max_x = _range(q_x)
            min_y, max_y = _range(q_y)
            return min_x, min_y, max_x - min_x, max_y - min_y

    @staticmethod
    def calc_hexagon_offset(w, h):
        """
        Calculate offsets of a hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            offsets
        """
        return w / 2., h / 4., h / 2., h * .75

    @staticmethod
    def calc_hexagon(q, x, y, w, h):
        """
        Calculate a hexagon polygon's x, y series.

        q: tuple
            of offsets

        x, y: numeric
            topleft point

        w, h: numeric
            rectangle

        Return: tuple
            of shape
            for the select polygon function
        """
        w1, h1, _, h2 = q

        # The first point is the topleft. The
        # points connect in a clockwise rotation.
        return (
            x, y + h1,
            x + w1, y,
            x + w, y + h1,
            x + w, y + h2,
            x + w1, y + h,
            x, y + h2
        )

    @staticmethod
    def calc_hexagon_truncated_offset(w, h):
        """
        Calculate offsets of a truncated hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            offsets
        """
        return w / 4., w / 2., w * .75, h / 2.

    @staticmethod
    def calc_hexagon_truncated(x, y, w, h, q):
        """
        Calculate the polygon points of a truncated hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            of x, y pairs
            for the select polygon function
        """
        # 'w2' is not used.
        w1, w2, w3, h1 = q

        # The first point is the topleft.
        # The points connect clockwise.
        return (
            x, y + h1,
            x + w1, y,
            x + w3, y,
            x + w, y + h1,
            x + w3, y + h,
            x + w1, y + h,
        )

    @staticmethod
    def calc_lock(w, h, w1, h1):
        """
        Return the size of an image that will fit into a smaller cell.

        w, h: numeric
            image size
            (width, height)

        w1, h1: numeric
            cell size
            (width, height)
            Conform the image size to this size.
        """
        w, h = float(w), float(h)
        w_r = w / w1
        h_r = h / h1

        if w_r > h_r:
            w, h = w1, h * (w1 / w)

        else:
            w, h = w * (h1 / h), h1
        return max(w, 1.), max(h, 1.)

    @staticmethod
    def calc_octagon_side_to_side_offset(w, h):
        """
        Calculate the offsets of a side-to-side octagon using a ratio.

        w, h: numeric
            limiting size

        Return: tuple
            of offsets
        """
        # Use ratio.
        w1 = float(w * sh.OCTAGON_RATIO)
        w2 = w - w1
        h1 = float(h * sh.OCTAGON_RATIO)
        h2 = h - h1
        return w1, w2, h1, h2

    @staticmethod
    def calc_octagon_side_to_side_shape(x, y, w, h, q):
        """
        Calculate the polygon points of a side-to-side octagon using a ratio.

        x, y, w, h: float
            the bounds rectangle of the octagon

        q: tuple
            of offsets for points

        Return: tuple
            of x, y pairs
            for select polygon function
        """
        w1, w2, h1, h2 = q

        # The first point is topleft.
        # The points connect clockwise.
        return (
            x + w1, y,
            x + w2, y,
            x + w, y + h1,
            x + w, y + h2,
            x + w2, y + h,
            x + w1, y + h,
            x, y + h2,
            x, y + h1
        )

    @staticmethod
    def calc_octagon_offset(w, h):
        """
        Calculate the offsets of an octagon.

        w, h: numeric
            limiting size, a cell size

        Return: tuple
            of offsets
        """
        # of cell rectangle
        radius = Base.circumradius(w, h)

        w1 = w / 2.
        h1 = h / 2.
        angle = math.asin(h1 / radius)

        # The process for 'w2' is deliberately
        # not factored as it is a complex formula.
        area = w1 * h1
        w2 = math.tan(angle)**2
        w2 = w2 * w1**2
        w2 = h1**2 + w2
        w2 = math.sqrt(w2)
        w2 = area / w2
        h2 = w2 * math.tan(angle)
        w3 = w1 + w2
        w4 = w1 - w2
        h3 = h1 + h2
        h4 = h1 - h2
        return w4, w1, w3, h4, h1, h3

    @staticmethod
    def calc_octagon_shape(x, y, w, h, q):
        """
        Calculate the polygon points of an octagon with offsets.

        x, y, w, h: float
            the bounds rectangle of the octagon

        q: tuple
            of offsets for points

        Return: tuple
            of x, y pairs
            for select polygon function
        """
        w1, w2, w3, h1, h2, h3 = q

        # The first point is top-center.
        # The direction is clockwise.
        return (
            x + w2, y,
            x + w3, y + h1,
            x + w, y + h2,
            x + w3, y + h3,
            x + w2, y + h,
            x + w1, y + h3,
            x, y + h2,
            x + w1, y + h1
        )

    @staticmethod
    def calc_pin_offset(pin, s, s1, x, y):
        """
        Calculate pin offset given the layer space.
        Fixed-sized cells have a pin corner. Their cell
        grid is pinned or connected to its pin corner.

        pin: string
            pin type

        s: tuple
            size
            of canvas space

        s1: tuple
            w, h of grid in pixel

        x, y: int
            offset
        """
        w, h = s
        w1, h1 = s1

        if pin in gr.PINS_WITH_X_OFFSET:
            x1 = w - w1

            if pin == gr.CENTER:
                x1 /= 2.
            x += x1

        if pin in gr.PINS_WITH_Y_OFFSET:
            y1 = h - h1

            if pin == gr.CENTER:
                y1 /= 2.
            y += y1
        return x, y

    @staticmethod
    def extreme(a):
        """
        Return the extreme x and y coordinates of a shape.

        a: iterable
            The iterable has x, y numeric pairs.

        Return: tuple
            x, y, x1, y1
            left, top, right, bottom
        """
        b = len(a)
        q_x = [a[i] for i in range(0, b, 2)]
        q_y = [a[i] for i in range(1, b, 2)]
        return min(q_x), min(q_y), max(q_x), max(q_y)

    @staticmethod
    def get_h_ellipse_rect(rect):
        """
        Calculate the rectangle shape of a horizontal ellipse.

        rect: Rect
            bounding rectangle for an ellipse

        Return: tuple
            x, y, w, h
        """
        return rect.x, rect.y, rect.w, rect.h - rect.h * sh.ELLIPSE_RATIO

    @staticmethod
    def get_v_ellipse_rect(rect):
        """
        Calculate the rectangle shape of a vertical ellipse.

        rect: Rect
            the bounds rectangle of the ellipse

        Return: tuple
            x, y, w, h
        """
        return rect.x, rect.y, rect.w - rect.w * sh.ELLIPSE_RATIO, rect.h

    @staticmethod
    def is_inverse_triangle(r, c):
        """
        Determine if a vertical or horizontal triangle is inverted.

        r, c: int
            row, column
            cell index

        Return: bool
            Is true when the triangle is inverted.
        """
        return (not r % 2 and c % 2) or (r % 2 and not c % 2)

    @staticmethod
    def top_left(a):
        """
        Return the topleft point of a shape bounds.

        a: iterable or dict
            The iterable has x, y numeric pairs.
            The dict of an ellipse has x, y, w, h.

        Return: tuple
            x, y
            the topleft corner
        """
        if len(a) == 4:
            # x, y at 0, 1
            return a[0], a[1]
        else:
            b = len(a)
            return (
                min([a[i] for i in range(0, b, 2)]),
                min([a[i] for i in range(1, b, 2)])
            )


class FromRect:
    """
    Use to calculate a cell shape. The functions
    receive a Rect and return a tuple or dictionary.

    Tuples are x, y points for drawing polygons. Dictionaries
    contain x, y, w, h, a rectangle, and are used to draw ellipses.
    """

    @staticmethod
    def circle(rect):
        """
        Get a dictionary of a circle.

        rect: Rect
            the bounds rectangle of a cell-like rectangle

        Return: tuple
            (x, y, w, h)
            Define the rectangle bounds of the circle.
        """
        x, y = rect.position
        w, h = rect.size
        center_x, center_y = x + w / 2., y + h / 2.
        w = min(w, h)
        x1 = center_x - w / 2.
        y1 = center_y - w / 2.
        return x1, y1, w, w

    @staticmethod
    def rhombus(rect):
        """
        Get the four points of a Rhombus.
        Maintain the Rhombus shape proportions.

        rect: Rect
            the bounds rectangle for a rhombus

        Return: tuple
            x, y pairs
            for drawing a rhombus
        """
        x, y = rect.position
        w, h = rect.size
        w2 = min(w, h) / 2.
        center_x, center_y = x + w / 2., y + h / 2.
        return (
            center_x - w2, center_y,
            center_x, center_y - w2,
            center_x + w2, center_y,
            center_x, center_y + w2
        )

    @staticmethod
    def rhombus_shear(rect):
        """
        Get the four points of a Sheared Rhombus.

        rect: Rect
            the bounds rectangle for the Sheared Rhombus

        Return: tuple
            x, y pairs
            for drawing a Sheared Rhombus
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = (y + y1) / 2.
        x2 = (x + x1) / 2.
        return x, y2, x2, y, x1, y2, x2, y1

    @staticmethod
    def ellipse(rect):
        """
        Translate a rectangle into a dictionary for an ellipse.

        rect: Rect
            the bounds rectangle for the ellipse

        Return: tuple
            (x, y, w, h)
            Define the rectangle bounds of the ellipse.
        """
        return rect.rect

    @staticmethod
    def hexagon_shear(rect):
        """
        Get the six points of a Sheared Hexagon.

        rect: Rect
            the bounds rectangle for the Sheared Hexagon

        Return: tuple
            x, y pairs
            for drawing a Sheared Hexagon
        """
        return Shape.calc_hexagon(
            Shape.calc_hexagon_offset(*rect.size), *rect.rect
        )

    @staticmethod
    def hexagon(rect):
        """
        Get 6 points of a Hexagon. Maintain the Hexagon shape proportions.

        rect: Rect
            Is the bounds rectangle for the hexagon.

        Return: tuple
            x, y pairs
            for drawing a hexagon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * RATIO, h

        if w1 > w:
            # Solution one doesn't fit the rectangle, so it's solution two.
            w1, h1 = w, w * UP_RATIO

        return Shape.calc_hexagon(
            Shape.calc_hexagon_offset(w1, h1),
            x + (w - w1) / 2.,
            y + (h - h1) / 2.,
            w1, h1
        )

    @staticmethod
    def hexagon_truncated_shear(rect):
        """
        Get the six points of a Sheared Truncated Hexagon.

        rect: Rect
            the bounds rectangle for the Sheared Truncated Hexagon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_hexagon_truncated(
            x, y,
            w, h,
            Shape.calc_hexagon_truncated_offset(w, h)
        )

    @staticmethod
    def hexagon_truncated(rect):
        """
        Get the points of a Truncated Hexagon.
        Maintain the Hexagon shape proportions.

        rect: Rect
            the bounds rectangle for the Truncated Hexagon

        Return: tuple
            x, y pairs
            for drawing a Truncated Hexagon
            a tuple of six coordinates of the hexagon
            connected clockwise
            The first point is the topleft point.
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = float(w), w * RATIO

        if h1 > h:
            # Solution one doesn't fit the rectangle, so it's solution two.
            w1, h1 = h * UP_RATIO, float(h)

        center_x, center_y = (w - w1) / 2., (h - h1) / 2.
        x += center_x
        y += center_y
        return Shape.calc_hexagon_truncated(
            x, y,
            w1, h1,
            Shape.calc_hexagon_truncated_offset(w1, h1)
        )

    @staticmethod
    def octagon(rect):
        """
        Get the eight points of a octagon.
        Maintain the octagon proportions.

        rect: Rect
            the bounds rectangle for the octagon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        w1 = min(w, h)
        offset_x, offset_y = (w - w1) / 2., (h - w1) / 2.
        x += offset_x
        y += offset_y
        return Shape.calc_octagon_shape(
            x, y,
            w1, w1,
            Shape.calc_octagon_offset(w1, w1)
        )

    @staticmethod
    def octagon_shear(rect):
        """
        Get the eight points of a Sheared Octagon.

        rect: Rect
            the bounds rectangle for the Sheared Octagon

        Return: tuple
            x, y pairs
            for drawing an octagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_octagon_shape(
            x, y,
            w, h,
            Shape.calc_octagon_offset(w, h)
        )

    @staticmethod
    def octagon_side_to_side_shear(rect):
        """
        Get the eight points of a Sheared Side-to-Side Octagon.

        rect: Rect
            the bounds rectangle for the Sheared Side-to-Side Octagon

        Return: tuple
            x, y pairs
            for drawing an Octagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_octagon_side_to_side_shape(
            x, y,
            w, h,
            Shape.calc_octagon_side_to_side_offset(w, h)
        )

    @staticmethod
    def octagon_side_to_side(rect):
        """
        Get the eight points of a Side-to-Side Octagon.
        Maintain the Octagon shape proportions.

        rect: Rect
            the bounds rectangle for the Side-to-Side Octagon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        w1 = min(w, h)

        # Center the polygon in the rectangle.
        offset_x, offset_y = (w - w1) / 2., (h - w1) / 2.
        x += offset_x
        y += offset_y
        return Shape.calc_octagon_side_to_side_shape(
            x, y,
            w1, w1,
            Shape.calc_octagon_side_to_side_offset(w1, w1)
        )

    @staticmethod
    def rectangle(rect):
        """
        Translate a rectangle into a tuple of x, y
        coordinates for drawing a Rectangle polygon.

        rect: Rect
            the bounds rectangle for the Rectangle

        Return: tuple
            x, y pairs
            for drawing a Rectangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        return x, y, x1, y, x1, y1, x, y1

    @staticmethod
    def square(rect):
        """
        Get the four points of a Square from the
        topleft corner with a clockwise order.

        rect: Rect
            the bounds rectangle for the Square

        Return: tuple
            x, y pairs
            for drawing a Square
        """
        x, y = rect.position
        w, h = rect.size
        center_x, center_y = x + w / 2., y + h / 2.
        w = min(w, h)
        x1 = center_x - w / 2.
        y1 = center_y - w / 2.
        x2, y2 = x1 + w, y1 + w
        return x1, y1, x2, y1, x2, y2, x1, y2

    @staticmethod
    def triangle_down_shear(rect):
        """
        Get the three points of a Sheared Facing Down Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        x2 = (x + x1) / 2.
        return x, y, x2, y1, x1, y

    @staticmethod
    def triangle_down_isosceles(rect):
        """
        Get the three points of a Facing Down Triangle.
        Maintain an isosceles triangle shape.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * UP_RATIO, h

        if w1 > w:
            # Solution one would overflow the bounds rectangle.
            w1, h1 = w, w * RATIO

        x1, y1 = x + w1, y + h1
        x2 = (x + x1) / 2.

        # Center the triangle.
        offset_x = (w - w1) / 2.
        offset_y = (h - h1) / 2.
        x += offset_x
        x1 += offset_x
        x2 += offset_x
        y += offset_y
        y1 += offset_y
        return x, y, x2, y1, x1, y

    @staticmethod
    def triangle_left_shear(rect):
        """
        Get the three points of a Sheared Facing Left Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = (y + y1) / 2.
        return x1, y, x1, y1, x, y2

    @staticmethod
    def triangle_left_isosceles(rect):
        """
        Get the three points of a Facing Left Isosceles Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * RATIO, h

        if w1 > w:
            # Solution one would overflow the bounds rectangle.
            # solution two
            w1, h1 = w, w * UP_RATIO

        x1, y1 = x + w1, y + h1
        y2 = (y + y1) / 2.

        # Center the triangle.
        offset_x = (w - w1) / 2.
        offset_y = (h - h1) / 2.
        x += offset_x
        x1 += offset_x
        y += offset_y
        y1 += offset_y
        y2 += offset_y
        return x1, y, x1, y1, x, y2

    @staticmethod
    def triangle_right_shear(rect):
        """
        Get the three points of a Sheared Facing Right Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = (y + y1) / 2.
        return x, y, x, y1, x1, y2

    @staticmethod
    def triangle_right_isosceles(rect):
        """
        Get the three points of a Facing Right Isosceles Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * RATIO, h

        if w1 > w:
            # Solution one would overflow the bounds rectangle.
            # solution two
            w1, h1 = w, w * UP_RATIO

        x1, y1 = x + w1, y + h1
        y2 = (y + y1) / 2.

        # Center the triangle.
        offset_x = (w - w1) / 2.
        offset_y = (h - h1) / 2.
        x += offset_x
        x1 += offset_x
        y += offset_y
        y1 += offset_y
        y2 += offset_y
        return x, y, x, y1, x1, y2

    @staticmethod
    def triangle_up_shear(rect):
        """
        Get the three points of a Sheared Facing Up Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        x2 = (x + x1) / 2.
        return x, y1, x2, y, x1, y1

    @staticmethod
    def triangle_up_isosceles(rect):
        """
        Get the three points of a Facing Down Isosceles Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * UP_RATIO, h

        if w1 > w:
            # Solution one would overflow the bounds rectangle.
            w1, h1 = w, w * RATIO

        x1, y1 = x + w1, y + h1
        x2 = (x + x1) / 2.

        # Center the triangle.
        offset_x = (w - w1) / 2.
        offset_y = (h - h1) / 2.
        x += offset_x
        x1 += offset_x
        x2 += offset_x
        y += offset_y
        y1 += offset_y
        return x, y1, x2, y, x1, y1


class Wip:
    """Use the WIP image size. Import as 'nd'."""

    @staticmethod
    def get_factor_h(a):
        """
        Calculate the result for a number pair
        that uses the WIP image height as a factor.

        a: tuple, int, or float
            (fixed value, factor value)
            fixed value, from an earlier version

        Return: numeric
            of the same type as the fixed value
        """
        return Factor.get_factor(a, The.view.wip.h)

    @staticmethod
    def get_factor_w(a):
        """
        Calculate the number for a number pair
        that uses the WIP image width as a factor.

        a: tuple, int, or float
            (fixed value, factor value)
            fixed value, from an earlier version

        Return: numeric
            of the same type as the fixed value
        """
        return Factor.get_factor(a, The.view.wip.w)


class Factor:
    """Produce factored results from NumberPairs."""

    @staticmethod
    def calc_factor(f, w):
        """
        Calculate a factored height.

        f: float
            Is factor variable.
            for example, the View image width

        w: numeric
            scale of factor

        Return: float
            the factor of the height
        """
        return f * w

    @staticmethod
    def get_factor(a, w):
        """
        Calculate a factored width.

        a: tuple or int
            (fixed value, factor value)
            fixed value

        w: numeric
            scale of factor
            for example, the View image height

        Return: numeric
            of the same type as the fixed value
        """
        # result, 'b'
        b = a

        if isinstance(a, tuple):
            b = a[0] + Factor.calc_factor(a[1], w)
            if isinstance(a[0], int):
                b = int(b)
            b = min(b, w)

        elif isinstance(a, float):
            b = Factor.calc_factor(a, w)
        return b


ROUTE = {
    ft.TRIANGLE_DOWN_SHEAR: FromRect.triangle_down_shear,
    ft.TRIANGLE_DOWN_ISOSCELES: FromRect.triangle_down_isosceles,
    ft.TRIANGLE_LEFT_SHEAR: FromRect.triangle_left_shear,
    ft.TRIANGLE_LEFT_ISOSCELES: FromRect.triangle_left_isosceles,
    ft.TRIANGLE_RIGHT_SHEAR: FromRect.triangle_right_shear,
    ft.TRIANGLE_RIGHT_ISOSCELES: FromRect.triangle_right_isosceles,
    ft.TRIANGLE_UP_SHEAR: FromRect.triangle_up_shear,
    ft.TRIANGLE_UP_ISOSCELES: FromRect.triangle_up_isosceles,
    sh.BOX_HORZ_SHEAR: FromRect.hexagon_truncated_shear,
    sh.BOX_HORZ: FromRect.hexagon_truncated,
    sh.BOX_VERT_SHEAR: FromRect.hexagon_shear,
    sh.BOX_VERT: FromRect.hexagon,
    sh.CIRCLE: FromRect.circle,
    sh.CIRCLE_HORIZONTAL: FromRect.circle,
    sh.CIRCLE_VERTICAL: FromRect.circle,
    sh.ELLIPSE: FromRect.ellipse,
    sh.ELLIPSE_HORIZONTAL: FromRect.ellipse,
    sh.ELLIPSE_VERTICAL: FromRect.ellipse,
    sh.HEXAGON: FromRect.hexagon,
    sh.HEXAGON_SHEAR: FromRect.hexagon_shear,
    sh.HEXAGON_TRUNCATED: FromRect.hexagon_truncated,
    sh.HEXAGON_TRUNCATED_SHEAR: FromRect.hexagon_truncated_shear,
    sh.OCTAGON_DOUBLE: FromRect.octagon_side_to_side,
    sh.OCTAGON_DOUBLE_SHEAR: FromRect.octagon_side_to_side_shear,
    sh.OCTAGON: FromRect.octagon,
    sh.OCTAGON_SHEAR: FromRect.octagon_shear,
    sh.OCTAGON_SIDE_TO_SIDE_SHEAR: FromRect.octagon_side_to_side_shear,
    sh.OCTAGON_SIDE_TO_SIDE: FromRect.octagon_side_to_side,
    sh.RECTANGLE: FromRect.rectangle,
    sh.RHOMBUS: FromRect.rhombus,
    sh.RHOMBUS_SHEAR: FromRect.rhombus_shear,
    sh.SQUARE: FromRect.square
}
