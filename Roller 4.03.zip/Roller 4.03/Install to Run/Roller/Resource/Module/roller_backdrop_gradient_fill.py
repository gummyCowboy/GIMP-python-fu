#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_fu import Lay
from roller_view_real import (
    add_sub_base_group, do_gradient_for_layer, finish_style
)
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make the Backdrop Style.

    v: View
    maya: GradientFill
    Return: layer or None
        with the Gradient Fill material
    """
    d = maya.value_d
    d[ok.GRADIENT] = d[ok.GBR][ok.GRADIENT]
    parent = add_sub_base_group(v, maya)

    do_gradient_for_layer(v, d, parent, 0)
    return finish_style(Lay.merge_group(parent), "Gradient Fill")


class GradientFill(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.GBR
    is_dependent = False

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        k_path = d['k_path']
        d['k_path'] = [k_path, k_path + (ok.GBR,), k_path + (ok.IRR,)]
        Style.__init__(self, *q + (make_style,), **d)
