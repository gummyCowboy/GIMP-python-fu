#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_view_real import finish_style, insert_copy
from roller_view_hub import get_canvas_points, invert_color, set_fill_context
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a style layer.

    v: View
        Has scope variable.

    maya: Style
    Return: layer or None
        style layer
    """
    d = maya.value_d
    parent = maya.group
    z = insert_copy(v, parent, parent)

    # RGBA, 'q'
    q = d[ok.COLOR_1A]

    # Use to set the opacity context for bucket fill.
    d[ok.FILL_OPACITY] = q[3] / 255. * 100.

    if d[ok.INVERT]:
        q = invert_color(q)

    # fill point, 'x, y'
    x, y = get_canvas_points(d)[:2]

    # Preserve.
    foreground = pdb.gimp_context_get_foreground()

    set_fill_context(d)
    pdb.gimp_context_set_foreground(q)
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FOREGROUND_FILL, x, y)

    # Restore.
    pdb.gimp_context_set_foreground(foreground)

    return finish_style(z, "Color Fill")


class ColorFill(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
