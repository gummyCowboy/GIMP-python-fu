#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import uniform, randint, seed
from roller_constant_for import Frame as ff
from roller_constant_key import Frame as ek, Option as ok
from roller_frame import MetalFiller
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_view_real import add_wip_layer
import gimpfu as fu

COLOR_BALANCE = (
    (-100., 100., 100.),
    (-100., -100., 100.),
    (-100., 100., -100.),
    (100., -100., -100.),
    (100., -100., 100.),
    (100., 100., -100.)
)
pdb = fu.pdb


def do_filler(v, maya):
    """
    Draw filler material.

    v: View
    maya: Filler
    Return: layer
        with material
    """
    j = v.j
    d = maya.value_d
    z = add_wip_layer(
        v,
        maya,
        "Ceramic Chip",
        group=maya.group,
        offset=len(maya.group.layers)
    )

    seed(v.glow_ball.seed + d[ok.SEED])

    # random turbulence
    pdb.plug_in_plasma(
        j, z, v.glow_ball.seed + d[ok.SEED], uniform(.0, 7.)
    )

    # mid-tones, '1'; yes, preserve luminosity,  '1'
    pdb.gimp_color_balance(z, 1, 1, *COLOR_BALANCE[randint(0, 5)])

    Gegl.waterpixels(z, size=min(256, d[ok.MESH_SIZE]))

    if d[ok.GREY_SCALE]:
        Gegl.saturation(z, .0)

    else:
        Gegl.saturation(z, uniform(.5, 2.))

    pdb.gimp_selection_all(j)
    pdb.plug_in_mosaic(
        j, z,
        d[ok.MESH_SIZE],
        1.,                                     # tile height
        .1,                                     # minimum spacing
        .5,                                     # medium neatness
        0,                                      # no split
        v.glow_ball.azimuth,
        .0,                                     # minimum color variation
        1,                                      # yes, antialias
        1,                                      # yes, average color
        ff.MESH_TYPE.index(d[ok.MESH_TYPE]),
        0,                                      # smooth surface
        0                                       # black and white grout
    )
    Lay.blur(z, 1.5)
    return z


class CeramicChip(MetalFiller):
    """Create a frame with ceramic-like pieces."""
    FRAME_K = ek.CERAMIC_CHIP
    is_seeded = True

    def __init__(self, *q, **d):
        """
        q: tuple
            MetalFiller spec

        d: dict
            MetalFiller spec
        """
        MetalFiller.__init__(self, *q + (do_filler,), **d)
