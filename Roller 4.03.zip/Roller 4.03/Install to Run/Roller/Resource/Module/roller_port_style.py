#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_port_option_list import PortOptionList


class PortStyle(PortOptionList):
    """Is a display container for Backdrop Style."""
    window_key = "Backdrop Style"

    def __init__(self, d, g):
        """
        d: dict
            Has init values.

        g: OptionButton
            Has option values.
        """
        PortOptionList.__init__(self, d, g, ok.BACKDROP_STYLE)
