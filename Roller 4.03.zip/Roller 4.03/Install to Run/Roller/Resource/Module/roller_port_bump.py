#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_port_preview import PortPreview
from roller_widget_node import Piece


class PortBump(PortPreview):
    """Is a display container for Bump Preset Widget."""
    window_key = "Bump"

    def __init__(self, d, g):
        """
        Create the Port.

        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_bump(self, box):
        """
        Draw the Bump Preset option group.

        box: GTK container
            to receive group
        """
        self.draw_group(Piece(ok.BUMP, box, self.safe.any_group.item))

    def draw(self):
        """Draw the Port's Widgets."""
        self.draw_column((self._draw_bump, self.draw_process))

    def get_group_value(self):
        """
        Get the Preset value.

        Return: dict
            Bump Preset
        """
        return self.preset.get_a()
