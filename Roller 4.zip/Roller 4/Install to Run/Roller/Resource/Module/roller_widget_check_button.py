#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_for import Signal as si
from roller_constant_key import Widget as wk
from roller_widget import Widget
import gtk


class CheckButton(Widget):
    """Is a custom GTK CheckButton with an GTK Alignment."""
    change_signal = 'clicked', 'activate'
    has_table_label = False

    def __init__(self, **d):
        """
        Create a CheckButton.

        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.CheckButton(label=d[wk.KEY].split(',')[0])

        Widget.__init__(self, g, **d)
        self.add(g)

    def get_a(self):
        """
        Get the value of the CheckButton.

        Return: int
            of CheckButton checked state
        """
        return int(self.widget.get_active())

    def set_a(self, a):
        """
        Set the CheckButton checked state.

        a: int
        """
        self.widget.set_active(a)
        self.on_voter_change(self.widget)


class CheckButtonPlan(CheckButton):
    """Has a signal attribute."""

    def __init__(self, **d):
        """
        Create a CheckButton.

        d: dict
            Has keyword arguments for Widget.
        """
        self.signal = d[wk.SIGNAL]
        CheckButton.__init__(self, **d)


class CheckButtonRandom(CheckButton):
    """Has a randomize function."""

    def __init__(self, **d):
        """
        Create a CheckButton.

        d: dict
            Has keyword arguments for Widget.
        """
        CheckButton.__init__(self, **d)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

    def randomize(self, *_):
        """Randomize of the CheckButton value."""
        self.set_a(randint(0, 1))
