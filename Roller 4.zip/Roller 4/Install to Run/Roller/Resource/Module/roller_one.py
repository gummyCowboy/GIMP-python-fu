#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from datetime import datetime
from math import sqrt
from random import randint, seed
from roller_constant_for import Color as co, Preset as fp, Widget as fw
from roller_constant_key import Option as ok, Pickle as pc

# 'cpickle' is not available in Python 3.
import cPickle

import gimpfu as fu
import gtk
import os
import random

pdb = fu.pdb


class Base:
    """Has widely used functions."""

    COLOR_DEC = 1900
    INIT_COLOR = co.MAX_COLOR - COLOR_DEC

    @staticmethod
    def add_text_layer(group, z, x, y):
        """
        Add a text layer to the group for Plan.

        group: layer
            parent

        z: layer
            to receive text

        x, y: int
            topleft position
            screen coordinate
        """
        pdb.gimp_image_insert_layer(z.image, z, group, 0)
        pdb.gimp_text_layer_set_color(z, (255, 255, 255))
        pdb.gimp_layer_set_offsets(z, x, y)

    @staticmethod
    def calc_length(x, y, x1, y1):
        """
        Calculate the distance between two points.

        x, y, x1, y1: numeric
            end points of a line (x, y), (x1, y1)

        Return: float
            the distance between the points
        """
        return sqrt((x - x1)**2 + (y - y1)**2)

    @staticmethod
    def circumradius(w, h):
        """
        Calculate the half-diagonal of a rectangle.

        Return: float
            half the length of the rectangle's diagonal
        """
        return sqrt(w**2 + h**2) / 2.

    @staticmethod
    def convert_to_rgb(color):
        """
        Convert gtk.gdk.Color to RGB.

        color: gtk.gdk.Color
            to convert

        Return: RGB
            color
        """
        if isinstance(color.red, int):
            return tuple(
                [i // 257 for i in (color.red, color.green, color.blue)]
            )

    @staticmethod
    def enumerate_name(n, q):
        """
        Enumerate a name given a list of names.
        Ensure the name is unique as in a Node item.

        n: string
            name to check

        q: list
            list of name
            of string

        Return: string
            the enumerated name
        """
        while n[-1].isdigit():
            n = n[:-1]

        n = n.strip()
        a = 1

        while 1:
            n1 = n + " " + str(a)
            if n1 in q:
                a += 1
                break
        return n1

    @staticmethod
    def find_option(d, k, q):
        """
        Fetch an option from a dict where the option location varies.

        d: dict
            with option

        k: string
            key of option to find

        q: iter
            (option key,)
            Has sub-key, k.

        Return: dict or None
            option
        """
        if k in d:
            return d[k]
        for i in q:
            if i in d:
                return d[i][k]

    @staticmethod
    def make_2d_table(r, c, init=0):
        """
        Return a 2D list.

        r, c: int
            size of the 2D table

        init: value
            to init table with

        deep: bool
            When it is True, the init value is deep-copied.
        """
        table = init

        for a in (c, r):
            table = [deepcopy(table) for _ in range(a)]
        return table

    @staticmethod
    def make_text(j, n, font_size):
        """
        Create a new text layer.

        j: GIMP image
            WIP

        n: string
            text to display

        font_size: float
            scale of font

        Return: layer
            with text
        """
        return pdb.gimp_text_layer_new(
            j, n, 'Sans-serif', font_size, fu.PIXELS
        )

    @staticmethod
    def random_rgb():
        """Return a tuple of integer containing random colors (r, g, b)."""
        return randint(0, 255), randint(0, 255), randint(0, 255)

    @staticmethod
    def random_rgba():
        """
        Return a tuple of integer containing
        random color components (r, g, b, a).
        """
        return Base.random_rgb() + (randint(0, 255),)

    @staticmethod
    def reduce_color(color):
        """
        'color' is used by the red and green color
        components. Use when drawing a gtk.EventBox.

        color: tuple
            RGB
        """
        return color - Base.COLOR_DEC

    @staticmethod
    def seal(a, b, c):
        """
        Limit a numeric value to be between two numbers.

        a: value
            to limit

        b: value
            minimum amount

        c: value
            maximum amount

        Return: value
            within seal
        """
        return max(min(c, a), b)

    @staticmethod
    def seed_random():
        """Use a float to randomize Python random number generator."""
        seed(float(datetime.now().microsecond))


class Comm:
    """Has functions that are used to communicate."""

    @staticmethod
    def info_msg(n, handler=fu.ERROR_CONSOLE):
        """
        Use to output a message to the error console.

        n: value
            message

        handler: GIMP enum
            0 - fu.MESSAGE_BOX
            1 - fu.CONSOLE
            2 - fu.ERROR_CONSOLE
        """
        a = pdb.gimp_message_get_handler()
        n = n if isinstance(n, str) else repr(n)

        pdb.gimp_message_set_handler(handler)
        fu.gimp.message(n)
        pdb.gimp_message_set_handler(a)

    @staticmethod
    def pop_up(window, x, n, title):
        """
        Display a message dialog.

        window: window
            GTK window
            parent

        x: int
            message type index
            (question, info)
            0, 1

        n: string
            message

        title: string
            window title

        Return: flag
            It is true if the user responded with yes.
        """
        g = gtk.MessageDialog(
            parent=window,
            flags=gtk.DIALOG_MODAL,
            type=(gtk.MESSAGE_QUESTION, gtk.MESSAGE_INFO)[x],
            buttons=(gtk.BUTTONS_YES_NO, gtk.BUTTONS_CLOSE)[x],
            message_format=n
        )

        g.set_title(title)

        a = g.run()

        g.destroy()
        return int(a == gtk.RESPONSE_YES)

    @staticmethod
    def show_err(a):
        """
        Post an error message to GIMP's error console.

        a: Exception or string
            to show
        """
        # Python 3 does not have basestring.
        if not isinstance(a, basestring):
            a = repr(a)
        Comm.info_msg(a)


class Mode:
    _q = [
        ("Normal", fu.LAYER_MODE_NORMAL),
        ("Dissolve", fu.LAYER_MODE_DISSOLVE),
        ("Color Erase", fu.LAYER_MODE_COLOR_ERASE),
        ("Erase", fu.LAYER_MODE_ERASE),
        ("Merge", fu.LAYER_MODE_MERGE),
        ("Split", fu.LAYER_MODE_SPLIT),
        (fw.LIST_SEPARATOR, None),
        ("Lighten Only", fu.LAYER_MODE_LIGHTEN_ONLY),
        ("Luma Lighten Only", fu.LAYER_MODE_LUMA_LIGHTEN_ONLY),
        ("Screen", fu.LAYER_MODE_SCREEN),
        ("Dodge", fu.LAYER_MODE_DODGE),
        ("Addition", fu.LAYER_MODE_ADDITION),
        (fw.LIST_SEPARATOR * 2, None),
        ("Darken Only", fu.LAYER_MODE_DARKEN_ONLY),
        ("Luma Darken Only", fu.LAYER_MODE_LUMA_DARKEN_ONLY),
        ("Multiply", fu.LAYER_MODE_MULTIPLY),
        ("Burn", fu.LAYER_MODE_BURN),
        ("Linear Burn", fu.LAYER_MODE_LINEAR_BURN),
        (fw.LIST_SEPARATOR * 3, None),
        ("Overlay", fu.LAYER_MODE_OVERLAY),
        ("Hard Light", fu.LAYER_MODE_HARDLIGHT),
        ("Soft Light", fu.LAYER_MODE_SOFTLIGHT),
        ("Vivid Light", fu.LAYER_MODE_VIVID_LIGHT),
        ("Pin Light", fu.LAYER_MODE_PIN_LIGHT),
        ("Linear Light", fu.LAYER_MODE_LINEAR_LIGHT),
        ("Hard Mix", fu.LAYER_MODE_HARD_MIX),
        (fw.LIST_SEPARATOR * 4, None),
        ("Difference", fu.LAYER_MODE_DIFFERENCE),
        ("Exclusion", fu.LAYER_MODE_EXCLUSION),
        ("Subtract", fu.LAYER_MODE_SUBTRACT),
        ("Divide", fu.LAYER_MODE_DIVIDE),
        ("Grain Extract", fu.LAYER_MODE_GRAIN_EXTRACT),
        ("Grain Merge", fu.LAYER_MODE_GRAIN_MERGE),
        (fw.LIST_SEPARATOR * 5, None),
        ("HSV Hue", fu.LAYER_MODE_HSV_HUE),
        ("HSV Saturation", fu.LAYER_MODE_HSV_SATURATION),
        ("HSV Value", fu.LAYER_MODE_HSV_VALUE),
        ("HSL Color", fu.LAYER_MODE_HSL_COLOR),
        (fw.LIST_SEPARATOR * 6, None),
        ("LCH Lightness", fu.LAYER_MODE_LCH_LIGHTNESS),
        ("LCH Chroma", fu.LAYER_MODE_LCH_CHROMA),
        ("LCH Hue", fu.LAYER_MODE_LCH_HUE),
        ("LCH Color", fu.LAYER_MODE_LCH_COLOR),
        ("Luminance", fu.LAYER_MODE_LUMINANCE)
    ]

    # Use with PaintRush.
    EDGE_MODE = (
        "Normal",
        "Lighten Only",
        "Screen",
        "Overlay",
        "Soft Light",
        "Hard Light",
        "Difference",
        "Subtract",
        "Grain Extract",
        "Grain Merge",
        "Divide",
        "HSV Value",
        "HSV Saturation",
        "HSL Color",
        "LCH Lightness",
        "Luminance"
    )
    INFLUENCE_MODE = (
        "Normal",
        "Overlay",
        "Hard Light",
        "Soft Light",
        "Vivid Light",
        "Pin Light",
        "Linear Light",
        "Hard Mix",
        fw.LIST_SEPARATOR,
        "Dissolve",
        "Color Erase",
        "Erase",
        "Merge",
        "Split",
        fw.LIST_SEPARATOR,
        "Lighten Only",
        "Luma Lighten Only",
        "Screen",
        "Dodge",
        "Addition",
        fw.LIST_SEPARATOR,
        "Darken Only",
        "Luma Darken Only",
        "Multiply",
        "Burn",
        "Linear Burn",
        fw.LIST_SEPARATOR,
        "Difference",
        "Exclusion",
        "Subtract",
        "Divide",
        "Grain Extract",
        "Grain Merge",
        fw.LIST_SEPARATOR,
        "LCH Lightness",
        "LCH Chroma",
        "LCH Hue",
        "LCH Color",
        "Luminance",
        fw.LIST_SEPARATOR,
        "HSV Hue",
        "HSV Saturation",
        "HSV Value",
        "HSL Color",
    )

    _d = OrderedDict(_q)
    names = _d.keys()

    @staticmethod
    def get_fill_mode(d):
        """
        Get the enum mode from a English translation. Use with ColorFill.

        d: dict
            Has a MODE option.

        Return: enum
            of layer mode
        """
        return Mode._d[d[ok.FILL_MODE]]

    @staticmethod
    def get_gradient_mode(d):
        """
        Get the enum mode from a English translation. Use with gradient.

        d: dict
            Has a MODE option.

        Return: enum
            of layer mode
        """
        return Mode._d[d[ok.GRADIENT_MODE]]

    @staticmethod
    def get_influence_mode():
        """
        Fetch the Influence Paint Mode list.

        Return: tuple
            of string; Paint Mode type
        """
        return Mode.INFLUENCE_MODE

    @staticmethod
    def get_mode(d, k=ok.MODE):
        """
        Get the enum mode from a English translation.

        d: dict
            Has a MODE option.

        k: string
            mode key

        Return: enum
            of layer mode
        """
        return Mode._d[d[k]]

    @staticmethod
    def rand():
        """Return a randomly selected mode (int)."""
        n = fw.LIST_SEPARATOR
        q = Mode.names

        while fw.LIST_SEPARATOR in n:
            n = random.choice(q)
        return n

    @staticmethod
    def translate(n):
        """
        Translate an English Paint Mode descriptor into GIMP layer mode enum.

        n: string
            paint mode descriptor

        Return: enum
            of layer mode
        """
        return Mode._d[n]


class Oz:
    """Has operating system functionality."""

    @staticmethod
    def ensure_dir(n):
        """
        Ensure a directory exists. Use to make a Preset folder.

        n: string
            file path

        Return two flags.
            err: bool
                error flag

            go: bool
                If it is true, then the operation was successful.
        """
        go = err = False

        if n and not os.path.isdir(os.path.dirname(n)):
            try:
                os.makedirs(os.path.dirname(n))
            except Exception as ex:
                err = True
                Comm.show_err(ex)
                Comm.show_err("Roller is unable to store files at\n" + n)

        else:
            go = True
        return err, go

    @staticmethod
    def format_image_name(j):
        """
        Get the name of an image assigned to a cell.

        j: Image
            Has an image and layer name.

        Return: string
            an image name without file type suffix
        """
        if j.layer_name:
            return j.layer_name

        n = j.image_name

        if os.path.isfile(n):
            return os.path.basename(os.path.splitext(n)[0])
        return n

    @staticmethod
    def get_preset_name(n, n1):
        """
        Format a Preset file name.

        n: string
            preset name

        n1: string
            file specific id

        Return: string
            preset name
        """
        return n + fp.PRESET_SEPARATOR + n1 + ".pkl"

    @staticmethod
    def get_preset_path(n, n1, dir_):
        """
        Construct a file path to a Preset.

        n: string
            Preset key

        n1: string
            file id

        dir_: string
            Preset root directory

        Return: string
            Preset file path
        """
        n2 = os.path.join(dir_, n)
        n3 = os.path.join(n2, Oz.get_preset_name(n, n1))
        return n3

    @staticmethod
    def pickle_dump(d):
        """
        Write a file using 'cPickle'.

        d: dict
            to Pickle

        Return: bool
            Is True if the operation succeeded.
        """
        go = False
        n = d[pc.FILE]
        err, _ = Oz.ensure_dir(n)

        if not err:
            try:
                with open(n, "wb") as output_file:
                    cPickle.dump(d[pc.DATA], output_file)
                go = True
            except Exception as ex:
                Comm.show_err(ex)
                Comm.show_err("Roller is unable to save\n" + n)
        return go

    @staticmethod
    def pickle_load(d):
        """
        Read a 'cPickle' type file.

        d: dict
            of Pickle option

        Return: dict or None
            the data read in
        """
        e = None
        n = d[pc.FILE]
        err, go = Oz.ensure_dir(n)

        if go and not err:
            try:
                with open(n, "rb") as input_file:
                    e = cPickle.load(input_file)
                    if not isinstance(e, dict):
                        # failure
                        e = {}
            except Exception as ex:
                if pc.SHOW_ERROR in d:
                    if d[pc.SHOW_ERROR]:
                        Comm.show_err(ex)
                        Comm.show_err("Roller is unable to load\n" + n)
        return e


class Rect(object):
    """Define a rectangle."""

    def __init__(self, x=0, y=0, w=0, h=0):
        """
        Set the rectangle's initial values.

        x, y: int
            x, y
            position of the rectangle

        w, h: int
            width, height of the rectangle
        """
        self.x, self.y = x, y
        self.w, self.h = w, h

    def center(self):
        """
        Calculate the center point for the rectangle.

        Return: tuple
            (x, y)
            center point
        """
        return self.x + (self.w / 2.), self.y + (self.h / 2.)

    def clone(self):
        """Make a copy of self and return the copy."""
        return Rect(self.x, self.y, self.w, self.h)

    def foam(self):
        """
        Assemble a polygon of coordinates for the rectangle.
        The points are arranged clockwise from the topleft corner.

        Return: tuple
            of x, y series
        """
        w, h = self.x + self.w, self.y + self.h
        return [
            self.x, self.y,
            w, self.y,
            self.x, h,
            w, h
        ]

    @property
    def position(self):
        """
        Fetch the rectangle position.

        Return: tuple
            (x, y)
        """
        return self.x, self.y

    @position.setter
    def position(self, value):
        """
        Set the rectangle position.

        value: tuple
            (x, y); numeric
            the topleft corner of the rectangle
        """
        self.x, self.y = value

    @property
    def rect(self):
        """
        Produce the attributes in a rectangle order.

        Return: tuple
            (x, y, w, h)
        """
        return self.x, self.y, self.w, self.h

    @rect.setter
    def rect(self, q):
        """
        Set the rectangle attributes.

        q: tuple
            (x, y, w, h)
            of numeric
        """
        self.x, self.y, self.w, self.h = q

    @property
    def size(self):
        """Return the rectangle size."""
        return self.w, self.h

    @size.setter
    def size(self, value):
        """
        Set the rectangle size.

        value: tuple
            (width, height); numeric
            the size of the rectangle
        """
        self.w, self.h = value
