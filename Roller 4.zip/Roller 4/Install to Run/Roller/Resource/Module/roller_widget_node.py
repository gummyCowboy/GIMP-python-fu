#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color as co, Signal as si, Widget as fw
from roller_constant_key import Option as ok, Step as sk, Widget as wk
from roller_one_the import The
from roller_widget import set_widget_attr
from roller_widget_label import Label
from roller_widget_tree import TreeViewList
import gtk
import gobject


def add_node_to_list(q):
    """
    Given a step key list, add any Node step key.

    q: list
        [step key]

    Return: list
        [step key] with Node step key
    """
    q1 = [sk.STEPS]
    get_group = The.helm.get_group

    for i in q:
        if len(i) > 1:
            k = i[:-1]
            a = get_group(k)
            if a and a.item.group_type == 'node':
                if k not in q1:
                    q1 += [k]
    return q + q1


def make_item(key, step_key, group_type, model):
    """
    Make an Item for a Node.

    key: string
        Is either a Group or Node key.

    step_key: tuple
        Is the navigation tree path and key to the group.
        (Node item, ...)

    model: Model or None
        Is a Model if the item is part of the Model's navigation tree.

    Return: tuple
        (Item, boolean new status)
    """
    any_group = The.helm.get_group(step_key)

    if any_group:
        item = any_group.item
        is_new = False

    else:
        item = Item(key, model, group_type)
        is_new = True
    return item, is_new


class Node(gtk.Alignment, gobject.GObject, object):
    """
    Is a list of keyed item descriptor. A selected item displays its branch.
    A branch is either a Node or Widget group. An item descriptor
    is part of a step key and is unique, like a key, in the list context.
    """
    has_table_label = False

    # Are signals that can be emitted by this class.
    sig_arg = gobject.SIGNAL_RUN_LAST, None, (gobject.TYPE_PYOBJECT,)
    __gsignals__ = {
        si.ADD_ITEM: sig_arg,
        si.UPDATE_TREE: sig_arg
    }

    def __init__(self, **d):
        """
        Draw a navigation item list.

        d: dict
            Has init values.
        """
        super(gtk.Alignment, self).__init__()

        # for custom signal(s)
        gobject.GObject.__init__(self)

        set_widget_attr(self, d)

        d[wk.COLOR] = co.LIST_CELL_COLOR
        d[wk.PADDING] = 2, 2, fw.MARGIN, fw.MARGIN

        # The HBox is needed for the expose event.
        # The Item VBox's exposure is erratic.
        self.hbox = gtk.HBox()

        self._tree = TreeViewList(**d)
        self.treeview = self._tree.treeview

        self.hbox.add(self._tree)
        self.add(self.hbox)
        The.power.connect(si.NODE_CHANGE, self.fire_select_signal)

        # The TreeView cursor-changed signal will send a signal
        # when a row is clicked even if the row is already selected.
        self._tree.treeview.connect('cursor_changed', self.update_on_change)

        self._tree.treeview.get_selection().connect(
            'changed', self.update_on_change
        )

    @staticmethod
    def fire_select_signal(signal, first_node):
        """
        Fire a signal for the NodePanel 'on_node_change' signal handler.
        The first Node will complete the window draw when selected.

        signal: Signal
            NODE_CHANGE

        first_node: Node
            Is the Node in column zero.
        """
        first_node.select_row(first_node.get_sel_x())

    def get_a(self):
        """
        Get a dict with the selected row of the Node.

        Return: list
            of item key
        """
        return {sk.SELECTED_ROW: self.get_sel_x()}

    def get_branch(self, x):
        """
        Get the Item reference for a list index.

        x: int
            selection index into the Node item list

        Return: Item or None
        """
        if x < len(self._tree.item_q):
            return self._tree.item_q[x]

    @staticmethod
    def get_init(*_):
        """
        Provide a dict and a list for group initialization.

        Return: tuple
            (group def dict, key list)
        """
        return {ok.NODE: {wk.CHANGELESS: True, wk.WIDGET: Node}}, [ok.NODE]

    def get_item_list(self):
        """
        Get the items in the list.

        Return: list
            of Item
        """
        return self._tree.item_q[:]

    def get_label_q(self):
        """
        Get the item key list.

        Return: list
            of item key
        """
        return [i.item for i in self._tree.item_q]

    def get_named_item(self, n):
        """
        Get an Item from the Node's item list
        by supplying its item descriptor.

        n: string
            item key to match
            Is not the Group key, but its split version.

        Return: Item or None
        """
        # Item list, 'q'
        q = self.get_item_list()
        for i in q:
            if i.item == n:
                return i

    def get_sel_x(self):
        """
        Fetch the selection row index for the TreeView.

        Return: int or None
        """
        x = self._tree.get_sel_x()

        if x is None:
            x = 0
        return x

    def insert_row(self, x, item):
        """
        Insert a row into the Node and its item list.

        x: int
            index to row

        item: Item
        """
        list_store = self._tree.list_store

        # item descriptor index, '0'
        # Create the row.
        list_store.set_value(list_store.insert(x), 0, item.item)

        # Set the background color.
        list_store[x] = [item.item, '#000000', co.LIST_CELL_COLOR]

        # Update the easy access list.
        self._tree.item_q.insert(x, item)

    def rename_item(self, old_name, new_name):
        """
        Change the name of an item in the Node.

        x: int
            index to row

        n: string
            new item name
        """
        q = self.get_item_list()
        item_q = self._tree.item_q
        for x, i in enumerate(q):
            if i.item == old_name:
                self._tree.rename_item(x, new_name)
                for x1, item in enumerate(item_q):
                    if item.key == old_name:
                        item.key = item.item = new_name

    def remove_named_item(self, n):
        """
        Remove an item from the list.

        x: int
            row number
        """
        q = self.get_item_list()
        for x, i in enumerate(q):
            if i.item == n:
                self._tree.remove_x(x)
                break

    def repopulate(self, q):
        """
        Synchronize the order of a Node's branches with a list of strings.

        q: list
            of Node branch names having the new order
        """
        self._tree.reset()
        for x, i in enumerate(q):
            self.insert_row(x, i)

    def select_row(self, x):
        """
        Select an item in the Node based on its descriptor.

        x: int
            row index
        """
        self._tree.select_item(x)

    def set_view_value(self, x):
        return

    def update_on_change(self, *_):
        """Update the option group with the change in selection."""
        self.any_group.update_node_a(self.get_a())


class Snitch:
    """Is a super class for an option group container."""

    def __init__(self, key, model):
        """
        string: key or None
            group key

        model: Model instance
            owner of the AnyGroup
        """
        self.is_per_cell = False
        self.item = \
            self.node = \
            self.text = \
            self.vbox = \
            self.label = \
            self.any_group = \
            self.group_type = None
        self.key = key
        self.model = model


class Pit(Snitch):
    """Is a container for a NoneGroup item."""

    def __init__(self):
        Snitch.__init__(self, None, None)
        self.group_type = 'preset'


class Item(Snitch):
    """Is a container for a Node item."""

    def __init__(self, key, model, group_type, label=None, has_switch=False):
        """
        key: string
            Group or Node key

        model: Model
        group_type: string
            Is 'node', 'preset', or 'super_preset'
        """
        Snitch.__init__(self, key, model)

        # a member of ('preset', 'node', 'super_preset'), 'group_type'
        self.group_type = group_type

        self.item = "" if isinstance(key, tuple) else key.split(",")[0]
        self.vbox = gtk.VBox()

        if not has_switch:
            # The Switch does not have a Label.
            text = self.item if label is None else label
            self.label = Label(
                text="{}".format(text),
                padding=(4, 4, 4, 4),
                expand=True
            )
            self.vbox.add(self.label)

    def rename(self, n):
        """
        Rename the item's key and item attributes.

        n: string
            key
        """
        self.key = n
        self.item = n.split(",")[0]


class Piece(Snitch):
    """
    Is a container for a Dialog group item. Has the same attributes as Item.
    """

    def __init__(
        self,
        key,
        container,
        item,
        group_type=None,
        has_label=True,
        is_per_cell=False
    ):
        """
        Make a container for a dialog option group. Add
        the group's container to its parent container.
        Inherit recurring attribute from an Item or a Piece.

        key: string
            Group or Node key

        container: GTK container
            Is the container for the option group.

        item: Item
            Inherit pieces.

        group_type: string
            part of group identity

        has_label: bool
            If True, then the GTK VBox will have a label.
        """
        Snitch.__init__(self, key, item.model)

        self.node = item.node
        self.group_type = item.group_type if group_type is None else group_type
        self.item = key.split(",")[0]
        self.vbox = gtk.VBox()
        self.is_per_cell = is_per_cell

        if has_label:
            self.label = Label(
                text="{}".format(self.item),
                padding=(4, 4, 4, 4),
                expand=True
            )
            self.vbox.add(self.label)
        container.add(self.vbox)


class Dust(Snitch):
    """
    Is a container for a Dialog group item. Has
    the same attributes as Item, but has no values.
    """

    def __init__(self, key=None, model=None):
        Snitch.__init__(self, key, model)
        if key is not None:
            self.item = key.split(",")[0]


# Register the custom signals.
gobject.type_register(Node)
