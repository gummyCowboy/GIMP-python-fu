#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one_fu import Lay, Mage, Sel
from roller_view_hub import do_gradient_job, do_rotated_image
import gimpfu as fu

pdb = fu.pdb


class GradientLight:
    """
    Has functions used to make the GradientLight layer and apply its influence.
    """
    image = None

    @staticmethod
    def insert_z(group):
        """
        Paste a Gradient Light layer at the top of a layer group.

        group: layer group or None for a GIMP image
            output destination

        Return: layer
            the original or its alter
        """
        Mage.copy_all(GradientLight.image)
        return Lay.paste_into(group, group.name + " Gradient Light")

    @staticmethod
    def create(v, maya):
        """
        Create a Gradient Light image. The image is hidden
        from the user and is removed when Roller closes or
        by an GradientLight reset operation. Layers are created
        from the image using a copy visible image function.

        v: View
        maya: Maya
        """
        GradientLight.reset()

        d = maya.value_d
        d[ok.GRADIENT] = d[ok.IGR][ok.GRADIENT]
        j = do_rotated_image(d, do_gradient_job)
        w, h = v.wip.size

        if w != j.width or h != j.height:
            # Select a rectangle from the center of the over-sized rotated
            # image before pasting it as a new Gradient Light image.
            x = (j.width / 2) - (w / 2)
            y = (j.height / 2) - (h / 2)

            Sel.rect(j, x, y, w, h)
            pdb.gimp_edit_copy_visible(j)
            pdb.gimp_image_delete(j)
            j = pdb.gimp_edit_paste_as_new_image()
        GradientLight.image = j

    @staticmethod
    def reset():
        if GradientLight.image:
            pdb.gimp_image_delete(GradientLight.image)
            GradientLight.image = None
