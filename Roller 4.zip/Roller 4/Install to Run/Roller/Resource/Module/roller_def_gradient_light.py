#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Issue as vo
from roller_constant_key import Option as ok
from roller_def_share import (
    ANGLE,
    END_X,
    END_Y,
    GRADIENT_TYPE,
    IGR,
    IRR,
    OFFSET,
    START_X,
    START_Y,
    SWITCH,
    set_issue
)

GRADIENT_LIGHT = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.START_X, deepcopy(START_X)),
    (ok.START_Y, deepcopy(START_Y)),
    (ok.END_X, deepcopy(END_X)),
    (ok.END_Y, deepcopy(END_Y)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.IRR, deepcopy(IRR)),
    (ok.IGR, IGR)
])
set_issue(GRADIENT_LIGHT, None, vo.MATTER, (ok.INFLUENCE,))
