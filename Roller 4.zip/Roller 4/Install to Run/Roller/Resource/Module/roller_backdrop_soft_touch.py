#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_fu import Lay
from roller_view_real import add_sub_base_group, finish_style, insert_copy
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a style layer.

    v: View
    maya: SoftTouch
    Return: layer or None
        Has style material.
    """
    j = v.j
    parent = add_sub_base_group(v, maya)
    z = insert_copy(v, parent, parent)
    group = Lay.group(j, "WIP", parent=parent, z=z)
    z1 = Lay.clone(z)

    Lay.blur(z, 500)

    z1.name = "HSV Hue"
    z1.mode = fu.LAYER_MODE_HSV_HUE

    pdb.plug_in_gimpressionist(j, z1, "Painted_Rock")

    if maya.value_d[ok.INVERT]:
        pdb.gimp_drawable_invert(Lay.merge_group(group), 0)
    return finish_style(Lay.merge_group(parent), "Soft Touch")


class SoftTouch(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
