#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_image import (
    add_image, make_matter_layer, make_plan_group, make_work_group
)
from roller_constant_for import Plan as fy
from roller_constant_key import Option as ok
from roller_maya import MAIN, ImageRoll, check_matter
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_one_fu import Sel
from roller_one_image import Image as ig
from roller_option_group import ManyGroup
from roller_view_option_list import Style
from roller_view_real import LIGHT, get_light, make_group
import gimpfu as fu

BUMP_N = "Backdrop Image Bump"
pdb = fu.pdb


def check_plan_group(v, maya):
    """
    Create a Plan layer group if there isn't one.

    v: View
    maya: Plan
    Return: layer group
        for Plan
    """
    if not maya.group:
        return make_plan_group(v)
    return maya.group


def check_style_group(v, maya):
    """
    Create a Backdrop Style group if needed.

    v: View
    maya: Maya
    """
    if not maya.group:
        return make_style_group(v, maya)
    return maya.group


def check_work_group(v, maya):
    """
    Create a Work layer group if there isn't one.

    v: View
    maya: Work
    Return: layer group
        for Work
    """
    if not maya.group:
        return make_work_group(v)
    return maya.group


def do_matter(v, maya):
    """
    Create a Work matter layer if there isn't one.

    v: View
    maya: Work
    Return: layer
        for Work's Backdrop Image
    """
    z = v.work.backdrop_layer = add_image(v, maya)
    return z


def do_plan_matter(v, maya):
    """
    Create a Plan matter layer if there isn't one.

    v: View
    maya: Plan
    Return: matter layer
        for Plan
    """
    z = v.plan.backdrop_layer = make_matter_layer(v, maya)

    Sel.rect(v.j, *v.wip.rect)
    Sel.fill(z, fy.BACKGROUND_COLOR)
    return z


def do_style(v, maya):
    """
    Determine the status of the Backdrop Style.

    v: View
    maya: Work
    Return: layer
        for Work
    """
    return maya.module.make_style(v, maya, v.j, maya.value_d)


def make_style_group(v, maya):
    """
    Make a Backdrop Style group.

    v: View
    maya: Work
    Return: layer group
        for backdrop
    """
    return make_group(
        v, "Style", maya.super_maya.group, offset=get_light(maya.super_maya)
    )


class Backdrop(ManyGroup):
    """Is used by the Backdrop step."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)


class Chi(ImageRoll):
    """Is factored from Plan and Work."""
    issue_q = 'matter',
    vote_type = MAIN

    def __init__(self, any_group, view_x, q):
        """
        any_group: AnyGroup
            the enclosing Preset's

        view_x: int
        q: iterable
            of layer output function
        """
        ImageRoll.__init__(
            self, any_group, view_x, q, k_path=[(), (ok.IMAGE_CHOICE,)]
        )
        self.set_issue()

    def do(self, v):
        """
        Is an override of the ImageRoll function.

        v: View
        """
        self.prep(v)
        self.dig(v)

    def prep(self, v):
        """
        For every View, there is an image. Is called from ImageRoll.

        v: View
        """
        d = self.value_d[ok.IMAGE_CHOICE]
        image = ig.get_image(d, v.image_source) if d[ok.SWITCH] else None

        if image != self.get_image(None):
            self.is_matter = True
        self.set_image(None, image)


class Plan(Chi):
    put = (check_plan_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        self.do_matter = do_plan_matter
        Chi.__init__(self, any_group, 0, Plan.put)

    def dig(self, v):
        """
        Process Backdrop output.

        v: View
        Return: None
            for undo
        """
        self.realize_vote(v)


class Work(Chi):
    put = (check_work_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Has options.
        """
        self.do_matter = do_matter

        Chi.__init__(self, any_group, 1, Work.put)

        self.sub_maya[ok.BUMP] = Bump(any_group, self, (ok.BUMP,))
        self.sub_maya[ok.BACKDROP_STYLE] = Style(
            any_group, self, (ok.BACKDROP_STYLE,)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.BACKDROP)

    def dig(self, v):
        """
        Process Backdrop output.

        v: View
        Return: None
            for undo
        """
        self.realize(v)
        self.sub_maya[ok.BUMP].do(v, self.value_d[ok.BUMP], self.is_matter)

        z = self.sub_maya[ok.BUMP].matter

        if z and z.name != BUMP_N:
            z.name = "Backdrop Image Bump"

        self.sub_maya[ok.BACKDROP_STYLE].do(
            v, self.value_d[ok.BACKDROP_STYLE], self.is_matter
        )
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
