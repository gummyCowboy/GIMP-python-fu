#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import Rect


class Caption:
    """Store Caption variables during a View run. Import as 'ca'."""

    def __init__(self, image_number=0):
        # Use to pass the sequence number for the Caption text.
        self.image_number = image_number

        # for the Caption type
        self.image_name = ""


class Deco:
    def __init__(self):
        """Store decoration Maya variable during a View run."""
        # Use to reference a background copy.
        self.bg_z = None

        # index to a color variable in a multi-color array.
        self.color_x = 0

        # Image
        # Use when an Image is the Deco Type.
        self.image = None

        # a Model's cell bounds
        self.rect = None

        # a tuple of x, y screen-coordinates used to draw a polygon
        # or
        # a dict, with a rectangle definition for drawing an ellipse
        # Use with margins.
        self.shape = None

        # decoration sub-type
        self.type_ = None


class Global:
    """Store Global Preset value within the View scope."""

    def __init__(self):
        self.seed = 0
        self.azimuth = self.elevation = .0


class One(object):
    """Is a generic-based container."""

    def __init__(self, **d):
        """
        Is an object. All is one. Add attribute to the object.

        d: dict
            Each {key: value} pair that become self attribute
            where key is the attribute id, and the value is attribute's.
        """
        for k, a in d.items():
            setattr(self, k, a)


class Pot:
    """Store Image scope variables during a View run."""

    def __init__(self, is_face):
        # a tuple of x, y screen-coordinates used to draw a rectangle
        self.foam = None

        # Is True when Face Maya is in control.
        self.is_face = is_face

        # Use to skip a transform step where the source
        # rectangle is sized down. # Is true when the source
        # rectangle is smaller than the pocket rectangle.
        self.is_small = False

        # Is the rectangle for the image placement
        # after it has been molded to a cell.
        self.mold = Rect()

        # Is the cell rectangle less the cell margin.
        self.pocket = Rect()

        # Is a Rect for selecting the image source
        # in image transform process.
        self.source = Rect()

        # Is a temp GIMP image that is deleted at the end image place.
        self.temp_image = None
