#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh, Triangle as ft
from roller_model_goo import Goo
from roller_one import Rect
from roller_one_extract import Shape

RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP
TRIANGLE_MAX = 10000000, 11547005


class TriangleHorz:
    """
    Calculate the position and the size of cells for a triangle cell-type.
    The triangle is facing left and right. Use intersects to map points
    shared by multiple triangles. Intersects create seamless triangle joints.
    """

    @staticmethod
    def calc(model, o):
        """
        Calculate cell rectangle for a Model's cell.

        model: Model
        o: One
            with Cell Type reference

        Return: list
            [Plan vote, Work vote]
        """
        def _get_shape():
            """
            Do shape.

            Return: tuple
                shape
            """
            _x, _x1 = q_x[c], q_x[c + 1]
            _y, _y1, _y2 = q_y[r], q_y[r + 1], q_y[r + 2]
            _is_inverse = Shape.is_inverse_triangle(r, c)

            # Both left and right triangles use this
            # function, but the right is the inverse of the left.
            if is_right_type:
                _is_inverse = not _is_inverse

            return (_x, _y, _x1, _y1, _x, _y2) if _is_inverse \
                else (_x1, _y, _x, _y1, _x1, _y2)

        # {r_c: [Plan vote, Work vote]}, 'vote_d'
        vote_d = {}

        did_cell = model.past.did_cell
        row, column = model.division
        goo_d = model.goo_d
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect
        is_right_type = model.cell_shape in ft.RIGHT_TYPE

        # intersect points
        q_x, q_y = [], []

        if o.grid_type in (gr.CELL_SIZE, gr.SHAPE_COUNT):
            # cell size
            if o.grid_type == gr.CELL_SIZE:
                # Correct cell size overflow.
                w = min(canvas_w, o.column_width / 1.)
                h = min(canvas_h, o.row_height / 1.)

                # grid size
                h1 = h / 2.
                h2 = h - h1
                s = column * w, row * h1 + h2

            else:
                # horizontal triangles
                w1 = canvas_w / 1. / column
                h1 = canvas_h / (.5 + row * .5)

                # two possible solutions
                # solution one
                ratio_w, ratio_h = h1 * RATIO, h1
                h2 = ratio_h / 2.
                h3 = ratio_h - h2
                s = column * ratio_w, row * h2 + h3

                # solution two
                ratio_w1, ratio_h1 = w1, w1 * UP_RATIO
                h2 = ratio_h1 / 2.
                h3 = ratio_h1 - h2
                s1 = column * ratio_w1, row * h2 + h3

                # If solution one fails, use solution two.
                if s[0] > canvas_w or s[1] > canvas_h:
                    s = s1
                    w, h = ratio_w1, ratio_h1
                else:
                    w, h = ratio_w, ratio_h
            x, y = Shape.calc_pin_offset(
                o.pin_corner, (canvas_w, canvas_h), s, x, y
            )

        else:
            w = canvas_w / 1. / column
            h = canvas_h / (.5 + row * .5)

        h /= 2.

        # cell rectangle
        for c in range(column + 2):
            q_x += [x]
            x += w

        for r in range(row + 2):
            q_y += [y]
            y += h

        for r_c in model.cell_q:
            r, c = r_c
            y, y1 = q_y[r], q_y[r + 2]
            x, x1 = q_x[c], q_x[c + 1]
            a = goo_d[r_c] = Goo(r_c)
            a.cell = a.merged = Rect(x, y, max(1, x1 - x), max(1, y1 - y))
            a.plaque = _get_shape()
            vote_d[r_c] = did_cell(r_c)
        return vote_d
