#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_extract import combine_seed
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_view_real import (
    add_sub_base_group, finish_style, insert_copy, insert_copy_above
)
import gimpfu as fu

STEP = "Line Stone Step {} of 5"
pdb = fu.pdb


def do_step_one(j, z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = Lay.clone(z)
    group = Lay.group(j, STEP.format(1), parent=parent, z=z)
    z = Lay.clone(z, n="HSV Value")
    z.mode = fu.LAYER_MODE_HSV_VALUE

    Gegl.edge(z)
    pdb.gimp_drawable_invert(z, 0)

    z = Lay.clone(z, n="LCH Lightness")
    z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
    z.opacity = 25.
    z = Lay.clone(z, n="Hard Mix")
    z.mode = fu.LAYER_MODE_HARD_MIX
    z.opacity = 20.
    return Lay.merge_group(group)


def do_step_two(j, z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = Lay.clone(z, n="Erode")
    group = Lay.group(j, STEP.format(2), parent=parent, z=z)

    Lay.dilate(z)
    pdb.plug_in_erode(
        j, z,
        1,                  # propagate black
        7,                  # RGB channels
        1.,                 # full rate
        0,                  # direction mask
        0,                  # lower limit
        255                 # upper limit
    )
    return Lay.merge_group(group)


def do_step_three(j, z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = Lay.clone(z)
    group = Lay.group(j, STEP.format(3), parent=parent, z=z)

    Lay.blur(z, 8)
    pdb.plug_in_despeckle(
        j, z,
        4,
        3,                  # recursive adaptive
        248,                # white cut-off
        7                   # black cut-off
    )
    Lay.dilate(z)

    z = Lay.clone(z, n="HSV Value")
    z.mode = fu.LAYER_MODE_HSV_VALUE
    Lay.dilate(z)
    return Lay.merge_group(group)


def do_step_four(v, j, z, parent):
    """
    Process in multiple phases.

    v: View
    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = Lay.clone(z, n="Clouds")
    group = Lay.group(j, STEP.format(4), parent=parent, z=z)

    # foggify output is on a layer with zero offset.
    pdb.python_fu_foggify(j, z, "Clouds 2", (127, 127, 127), 3., 100.)
    z1 = j.active_layer
    pdb.gimp_layer_set_offsets(z1, *v.wip.position)
    pdb.gimp_layer_resize(z1, v.wip.w, v.wip.h, 0, 0)
    return Lay.merge_group(group)


def make_style(v, maya):
    """
    Make the Backdrop Style.

    v: View
    maya: LineStone
    Return: layer
        with the style material
    """
    combine_seed(v, maya.value_d)

    j = v.j
    parent = add_sub_base_group(v, maya)
    z = insert_copy(v, parent, parent)
    bg_z = Lay.clone(z, "Overlay")
    group = Lay.group(j, "WIP", parent=parent, z=z)
    z = z1 = do_step_one(j, z, group)

    z = do_step_two(j, z, group)
    z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
    z2 = insert_copy_above(v, z, parent.layers[0])

    z.mode = fu.LAYER_MODE_NORMAL
    z = z2
    z.mode = fu.LAYER_MODE_HARD_MIX
    z = insert_copy_above(v, z, parent.layers[0])
    z.mode = fu.LAYER_MODE_HSV_VALUE

    j.remove_layer(z1)
    j.remove_layer(z2)

    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
    z = do_step_three(j, z, group)
    z = do_step_four(v, j, z, group)
    z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
    z = Lay.merge_group(group)

    do_step_five(j, z, bg_z, parent)
    return finish_style(Lay.merge_group(parent), "Line Stone")


def do_step_five(j, z, bg_z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    bg_z: layer
        background clone

    parent: layer
        container group
    """
    group = Lay.group(j, "WIP", parent=parent, z=z)
    z = z1 = Lay.clone(z, n="Overlay #1")
    z.mode = fu.LAYER_MODE_OVERLAY
    z.opacity = 100.

    pdb.plug_in_hsv_noise(
        j, z,
        1,                  # minimum holdness (1 through 8)
        5,                  # hue-distance angle (0 through 180)
        5,                  # saturation-distance (0 through 255)
        5                   # value-distance (0 through 255)
    )
    Gegl.emboss(z, 45., 15., 3)

    # four coordinates, '4'
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,
        (.0, .3921, 1., .6078)
    )

    z = bg_z
    z.mode = fu.LAYER_MODE_OVERLAY
    z.opacity = 100.

    pdb.gimp_image_reorder_item(j, z, group, 1)

    # four coordinates, '4'
    pdb.gimp_drawable_curves_spline(z, fu.HISTOGRAM_VALUE, 4, (.0, 1., 1., .5))

    z = Lay.clone(z, n="Difference")
    z.mode = fu.LAYER_MODE_DIFFERENCE
    z.opacity = 50.
    z = Lay.clone(z, n="Exclusion")
    z.mode = fu.LAYER_MODE_EXCLUSION
    z.opacity = 25.

    Gegl.color_to_grey(z)

    z1.opacity = 50.
    z = Lay.merge_group(group)
    Gegl.unsharp_mask(z, 5., 1.5, .3)


class LineStone(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
