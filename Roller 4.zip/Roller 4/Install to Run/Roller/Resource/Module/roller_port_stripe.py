#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_port_preview import PortPreview
from roller_widget_node import Piece


class PortStripe(PortPreview):
    """Is a display container for the Caption Stripe Preset."""
    window_key = "Stripe"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_stripe_option(self, box):
        """
        Draw the option group.

        box: VBox
            container for the groups
        """
        self.draw_group(Piece(ok.STRIPE, box, self.safe.any_group.item))

    def draw(self):
        """
        Draw Widget.

        g: VBox
            container for the Widgets
        """
        self.draw_column((self._draw_stripe_option, self.draw_process))

    def get_group_value(self):
        """
        Use to get the Preset value.

        Return: dict
            Caption Stripe Preset
        """
        return self.preset.get_a()
