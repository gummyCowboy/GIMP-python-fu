#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Signal as si, Shape as sh
from roller_constant_key import Model as md, Option as ok
from roller_model_grid import Grid
from roller_model_face import BoxFace1, BoxFace2, Cap
from roller_one import Base
import gimpfu as fu

pdb = fu.pdb


class Box(Grid):
    model_type = md.BOX

    def __init__(self, model_name):
        """
        model_name: string
            identity of the model
        """
        Grid.__init__(self, model_name)

        self.is_vertical = False
        self.box_type = self._grid_type = self._face_update_p = None
        self.sub_face = BoxFace1(self), BoxFace2(self), Cap(self)

    def _update_face(self, r, c, q, w, h, a):
        """
        r, c: int
            zero-based cell index

        q: tuple
            (x, y pair, ...)
            Define a rectangle for Face transform.
        """
        center = a.center()
        for i in self.sub_face:
            i.update_face(q, w, h, center, i.table[r][c])

    def calc_main_cell_pocket(self, v, d):
        """
        Calculate the pocket rectangle and shape polygon for main option
        settings Cell-branch. Update the dependent Box Face.

        v: View
        d: dict
            Margin Preset
            {Option key: value}
        """
        super(Box, self).calc_main_cell_pocket(v, d)
        for r, c in self.cell_q:
            a = self.goo_d[(r, c)]
            self._face_update_p(r, c, a.shape, a.shift)

    def calc_cell_pocket(self, v, d, r_c):
        """
        Calculate the pocket rectangle and shape polygon
        for All Cell. Update the dependent Box Face.

        v: View
        d: dict
            Margin Preset

        r_c: tuple
            cell index
        """
        super(Box, self).calc_cell_pocket(v, d, r_c)

        r, c = r_c

        # Goo, 'a'
        a = self.goo_d[r_c]
        self._face_update_p(r, c, a.shape, a.shift)

    def calc_division(self, d):
        """
        Determine the row and column count of the Model.
        Call with after Canvas pocket has been calculated.

        d: dict
            Cell Type Preset
        """
        n = d[ok.GRID_TYPE]
        w, h = self.canvas_pocket.size

        if n == gr.CELL_COUNT:
            r, c = d[ok.ROW_COUNT], d[ok.COLUMN_COUNT]

        elif n == gr.SHAPE_COUNT:
            r, c = d[ok.VERT_COUNT], d[ok.HORZ_COUNT]

        else:
            # cell size
            width = Base.seal(d[ok.COLUMN_W], 1, w)
            height = Base.seal(d[ok.ROW_H], 1, h)
            n = d[ok.BOX_TYPE]

            if n in (sh.LEFT, sh.RIGHT):
                w1, h1 = width * .75, height * .5
                w2, h2 = w - w1, h - h1
                r, c = max(1, int(h2 / h1)), max(1, int(w2 / w1))
            else:
                # vertical box
                w1, h1 = width * .5, height * .75
                w2, h2 = w - w1, h - h1
                r, c = max(1, int(h2 / h1)), max(1, int(w2 / w1))

        self.division = r, c
        self.baby.emit(si.DIVISION_CHANGE, self.division)

    def get_face_foam(self, r, c, face_x):
        return self.sub_face[face_x].table[r][c].foam

    def get_face_merged(self, r, c, face_x):
        return self.sub_face[face_x].table[r][c].merged

    def get_face_pocket(self, r, c, face_x):
        return self.sub_face[face_x].table[r][c].pocket

    def get_face_rect(self, r, c, face_x):
        return self.sub_face[face_x].table[r][c].merged.rect

    def get_face_shape(self, r, c, face_x):
        return self.sub_face[face_x].table[r][c].shape

    def get_face_transform(self, r, c, face_x):
        return self.sub_face[face_x].table[r][c].transform

    def init_cell_q(self, d):
        """
        d: dict
            Cell Type Preset
        """
        is_indent = d[ok.FCI]
        self.cell_q = []

        for r in range(self.division[0]):
            for c in range(self.division[1]):
                if is_indent:
                    if bool((r % 2 and not c % 2) or (not r % 2 and c % 2)):
                        self.cell_q += [(r, c)]
                else:
                    if bool((r % 2 and c % 2) or (not r % 2 and not c % 2)):
                        self.cell_q += [(r, c)]

    def init_model_cell(self, d):
        """
        Calculate cell size..

        d: dict
            Cell Type Preset
            {Option key: value}

        Return: list
            [Plan vote, Work vote]
            Each True vote is a vote for change.
        """
        vote_d = super(Box, self).init_model_cell(d)

        for i in self.sub_face:
            i.update_type()
        return vote_d

    def set_default_pocket(self, is_sequence):
        """
        The Cell Margin step is offline, so a default pocket is calculated.

        is_sequence: bool
            If True, then the chained-sequence is calculated immediately.
        """
        super(Box, self).set_default_pocket(is_sequence)
        for r, c in self.cell_q:
            # Goo, 'a'
            a = self.goo_d[(r, c)]
            self._face_update_p(r, c, a.shape, a.shift)

    def update_horz_face(self, r, c, q, a):
        """
        Call from horizontal Box polygon. Update Face of a cell.

        r, c: int
            cell index

        q: tuple
            (x, y) of float series, eight count

        a: Rect
            cell rectangle
        """
        w = q[4] - q[2]
        h = Base.calc_length(*q[:4])
        self._update_face(r, c, q, w, h, a)

    def update_vert_face(self, r, c, q, a):
        """
        Call from vertical Box polygon. Update Face of a cell.

        r, c: int
            cell index

        q: tuple
            (x, y) of float series, eight count

        a: Rect
            cell rectangle
        """
        w = Base.calc_length(*q[:4])
        h = q[7] - q[5]
        self._update_face(r, c, q, w, h, a)

    def update_type(self, arg):
        """
        Update the cell-type from the Cell Type Preset.

        arg: tuple
            (Box Cell Type Preset, is sequence flag)
            {Option key: value}
            A sequence is processed immediately.
        """
        def _get_cell_shape():
            """
            Get the cell shape according the cell type.

            Return: string
                cell shape descriptor
            """
            if self.is_vertical:
                return sh.BOX_VERT if self.is_equilateral \
                    else sh.BOX_VERT_SHEAR
            return sh.BOX_HORZ if self.is_equilateral else sh.BOX_HORZ_SHEAR

        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        self.is_vertical = d[ok.BOX_TYPE] in (sh.TOP, sh.BOTTOM)
        self.cell_shape = _get_cell_shape()
        self.box_type = d[ok.BOX_TYPE]
        self._face_update_p = (
            self.update_horz_face, self.update_vert_face
        )[int(self.is_vertical)]
        vote_d = super(Box, self).update_type(arg)

        self.adapt_missing_cell_step(is_sequence)
        p(si.CELL_RECT_CALC, vote_d)
