#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Model as md
from roller_deco import ready_canvas_rect
from roller_one import Base
from roller_one_extract import Shape
from roller_one_fu import Lay
from roller_view_real import make_group
import gimpfu as fu

pdb = fu.pdb


def draw_canvas_name(v, maya):
    """
    Draw an image name for a Canvas Image.

    v: View
    maya: Maya
    Return: layer or None
        with the image name
    """
    ready_canvas_rect(v, maya, option=None)

    super_ = maya.super_maya
    j = v.j
    n = super_.get_image_name(None)
    if n:
        z = Base.make_text(j, n, maya.font_size)
        x, y, w, h = maya.model.canvas_pocket.rect
        x = w / 2. + x - z.width / 2.
        y = h / 2. + y + z.height / 2.
        z.name = super_.group.name + " Name"

        Base.add_text_layer(super_.group, z, x, y)
        return z


def draw_main_name(v, maya):
    """
    Draw an image name for a Cell-branch image.

    v: View
    maya: Maya
    Return: layer or None
        with text
    """
    model = maya.model
    j = v.j
    super_ = maya.super_maya
    group = make_group(v, "Name", super_.group)
    font_size = maya.font_size

    for r_c in super_.main_cell_q:
        a = model.get_pocket(r_c)
        x, y, w, h = a.rect
        n = super_.get_image_name(r_c)
        if n:
            z = Base.make_text(j, n, font_size)
            x1 = w / 2. + x - z.width / 2.
            y1 = h / 2. + y + z.height / 2.

            if model.model_type == md.STACK:
                y1 = y1 + r_c[0] * z.height
            Base.add_text_layer(group, z, x1, y1)
    return Lay.verify_group(group)


def draw_cell_name(v, maya):
    """
    Draw an image name for a Cell-branch image.

    v: View
    maya: Maya
    Return: layer or None
        with text
    """
    model = maya.model
    j = v.j
    super_ = maya.super_maya
    r_c = super_.r_c
    a = model.get_pocket(r_c)
    x, y, w, h = a.rect
    n = super_.get_image_name(r_c)
    if n:
        z = Base.make_text(j, n, 13)
        x1 = w / 2. + x - z.width / 2.
        y1 = h / 2. + y + z.height / 2.

        if model.model_type == md.STACK:
            y1 = y1 + maya.r_c[0] * z.height
        return Base.add_text_layer(super_.group, z, x1, y1)


def draw_face_main_name(v, maya):
    """
    Draw an image name for Plan Face for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with text
    """
    super_ = maya.super_maya
    parent = super_.group
    group = make_group(v, "Name", parent)

    for r, c in super_.main_cell_q:
        draw_face_name(maya, group, r, c)
    return Lay.verify_group(group)


def draw_face_cell_name(v, maya):
    """
    Draw an image name for Plan Per Cell Face.

    v: View
    maya: Maya
    Return: layer or None
        with text
    """
    super_ = maya.super_maya
    parent = super_.group
    group = make_group(v, "Name", parent)

    draw_face_name(maya, group, *super_.r_c)
    return Lay.verify_group(group)


def draw_face_name(maya, group, r, c):
    """
    Draw image name for a Face.

    maya: Maya
    group: layer group
        Is where to place text layer.

    r, c: int
        cell index
    """
    model = maya.model
    font_size = maya.font_size
    for face_x in range(3):
        x, y, w, h = Shape.bounds(model.get_face_foam(r, c, face_x))
        n = maya.super_maya.get_face_name(r, c, face_x)
        if n:
            z = Base.make_text(group.image, n, font_size)
            x1 = w / 2. + x - z.width / 2.
            y1 = h / 2. + y + z.height / 2.

            if model.model_type == md.STACK:
                y1 = y1 + r * z.height
            Base.add_text_layer(group, z, x1, y1)
