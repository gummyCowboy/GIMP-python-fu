#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Image as fi
from roller_constant_key import Pickle as pc, Widget as wk
from roller_one import Comm, Oz
from roller_one_fu import Lay, Sel
from roller_one_image import Image as ig
from roller_one_the import The
from roller_port_main import PortMain
from roller_view_gradient_light import GradientLight
from roller_window import Window
import gimpfu as fu
import gobject
import gtk
import os

CRITICAL = "Roller closed itself due to a critical error: "
pdb = fu.pdb


def collapse_loner(j):
    """
    Collapse layer group with only one child.

    j: GIMP image
        Has layer group.
    """
    # list of group layers from the top-down, 'group_q'
    group_q = []

    Lay.get_groups(j, group_q)

    # Remove invisible layer.
    for group in reversed(group_q):
        if len(group.layers) == 1:
            if not pdb.gimp_item_is_group(group.layers[0]):
                Lay.merge_group(group)


def remove_unused_layer(j):
    """
    Remove any layers without material. Is recursive.

    j: GIMP image
        Has sub-layers.
    """
    # list of group layers from the top-down, 'group_q'
    group_q = []

    Lay.get_groups(j, group_q)

    # Remove invisible layer.
    for group in group_q:
        for z in group.layers:
            if not z.visible and not pdb.gimp_item_is_group(z):
                pdb.gimp_image_remove_layer(z.image, z)
            elif not z.opacity:
                pdb.gimp_image_remove_layer(z.image, z)


def remove_unused_group(j):
    """
    Remove any group layers without any children.

    j: GIMP image
        Is render.
    """
    # list of group layers from the top-down, 'group_q'
    group_q = []

    Lay.get_groups(j, group_q)

    # Remove empty groups from the bottom-up.
    [Lay.remove(z) for z in reversed(group_q) if not z.layers]


def resize_layers(z):
    """
    Resize the layers to the image size.

    z: GIMP image or layer
        Has sub-layers.
    """
    # list of group layers from the top-down, 'group_q'
    # Remove invisible layer.
    for i in z.layers:
        pdb.gimp_layer_resize_to_image_size(i)
        if pdb.gimp_item_is_group(i):
            resize_layers(i)


def verify_preset_folder():
    """
    The external directory is where Preset files are stored.

    Return: bool
        It is true if the directory is verified.
    """
    go = False

    try:
        n = The.preset_folder = os.path.join(
            The.cat.roller_path,
            u"Preset"
        )
        go = Oz.ensure_dir(n)[-1]

    except Exception as ex:
        Comm.show_err(ex)
        Comm.show_err(
            "The operating system isn't compatible with Roller."
        )
    return go


class WindowMain(Window):
    """Is Roller's main window."""
    TITLE = "Roller 4"

    def __init__(self):
        """Has the GTK event loop."""
        if verify_preset_folder():
            self._last_window_pose = {}
            cat = The.cat

            # Preserve the selection and active layer of open images.
            sel_q = []
            active_layer_q = []

            self._load_window_pose()
            ig.make_image_list()
            ig.image_undo_start()

            for _, j in ig.roller_image.items():
                active_layer_q.append((j.j, j.j.active_layer))
                sel_q.append((
                    j.j,
                    pdb.gimp_selection_save(j.j) if Sel.is_sel(j.j) else None
                ))
                pdb.gimp_selection_none(j.j)

            # Prepare the Port.
            d = {wk.WINDOW_KEY: WindowMain.TITLE}

            Window.__init__(self, d, is_dialog=False)

            self.port = PortMain({wk.ROLLER_WIN: self})

            self.set_hook(self.port.get_hook())
            self.add(self.port)

            # Display the main window now that it has been
            # initialized with Widgets and values by PortMain.
            self.gtk_win.show_all()

            try:
                # Insert a signal processing function
                # into the main signal processing ring.
                #
                # Reference
                # library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
                gobject.idle_add(The.power.send)

                # Start the main signal processing ring.
                gtk.main()

            except Exception as ex:
                if self.gtk_win is not None:
                    self.close()
                    Comm.show_err(CRITICAL + repr(ex))
                raise

            view_j = cat.render.get_image()

            # Close any opened images.
            for k, q in ig.opened_image_d.items():
                if k not in ig.image_name_list:
                    j = q[fi.IMAGE_INDEX].j
                    if pdb.gimp_image_is_valid(j):
                        pdb.gimp_image_delete(j)

            # Close the GradientLight image.
            if GradientLight.image:
                pdb.gimp_image_delete(GradientLight.image)

            # Restore the selection for open images.
            for i in sel_q:
                j, sel = i[0], i[1]

                if sel is not None:
                    if (
                        pdb.gimp_item_is_valid(sel) and
                        pdb.gimp_image_is_valid(j)
                    ):
                        Sel.load(j, sel)
                        pdb.gimp_image_remove_channel(j, sel)
                else:
                    # Remove a Roller generated selection.
                    pdb.gimp_selection_none(j)

            # Restore the active layer for open images.
            for j, z in active_layer_q:
                if pdb.gimp_image_is_valid(j) and Lay.valid(z):
                    j.active_layer = z

            if view_j:
                a = WindowMain

                if not self.canceled:
                    v = The.view

                    remove_unused_group(view_j)
                    remove_unused_layer(view_j)
                    collapse_loner(view_j)
                    pdb.gimp_image_resize(
                        view_j, *(v.wip.size + (-v.wip.x, -v.wip.y))
                    )
                    resize_layers(view_j)
                a.remove_unused_image_gradient()

            if not self.canceled and view_j:
                # Set the bottom layer as the active layer.
                if len(view_j.layers):
                    view_j.active_layer = view_j.layers[-1]

                # Remove channels.
                [view_j.remove_channel(i) for i in view_j.channels]

            # Save Window position.
            if The.window_pose != self._last_window_pose:
                Oz.pickle_dump({
                    pc.DATA: The.window_pose,
                    pc.FILE: self._window_pose_file
                })
            ig.image_undo_end()

    def _load_window_pose(self):
        """Load the Window position dictionary if it exists."""
        n = self._window_pose_file = Oz.get_preset_path(
            u"Window Position",
            "",
            The.preset_folder
        )
        d = Oz.pickle_load({pc.FILE: n, pc.SHOW_ERROR: False})

        if d:
            The.window_pose = deepcopy(d)
            self._last_window_pose = deepcopy(d)

    @staticmethod
    def remove_unused_image_gradient():
        """
        Delete any image gradients that were
        created but not saved with the render.
        """
        for grad in The.image_gradient_created:
            if grad != The.image_gradient_used:
                pdb.gimp_gradient_delete(grad)
