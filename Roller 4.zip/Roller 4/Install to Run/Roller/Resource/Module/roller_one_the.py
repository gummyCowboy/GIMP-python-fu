#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Signal as si
from roller_constant_key import Step as sk
from roller_one_model_id import ModelId
from roller_one_power import Power


def get_step_q(d, k):
    """
    Make a list of ordered step key as displayed in the navigation tree.

    d: dict
        Has navigation step key of visible option group.

    k: tuple
        navigation step key
        Is the key to the first Node in the tree.

    Return: list
        [step key]
    """
    def _walk(_group):
        """
        Use recursion to walk through the AnyGroup dict.
        Collect the tree's step key in a list.

        _group: AnyGroup
            Has needed info.
        """
        for _item in _group.item.node.get_item_list():
            _step_k = _item.any_group.step_key
            if _item.group_type == 'preset':
                step_q.append(_step_k)

            all_step_q.append(_step_k)
            _group1 = d[_step_k]
            if _group1.item.node:
                _walk(_group1)

    # list of Preset-filtered step key that make up a View.
    step_q = []

    all_step_q = []

    _walk(d[k])
    return all_step_q, step_q


class The:
    """
    Has classes and variables that won't import directly
    due to a circular reference. These variables are
    initialized during Roller start-up.
    """
    # Cat class
    cat = None

    # Dog class
    dog = None

    # Is the frame file path used by FrameOver.
    frame_path = ""

    helm = None

    # Use with ImageGradient to delete unused gradients.
    image_gradient_used = None

    # Use with ImageGradient to delete unused gradients.
    image_gradient_created = []

    # Use to remember the image file path for a OSButton.
    image_path = ""

    # Suppress visibility update.
    load_count = 0

    model_id = ModelId()

    # Is a Lookup dict for Frame and Backdrop Style module.
    option_d = None

    power = None

    # Preset class
    preset = None

    # Is the root folder for Preset storage.
    preset_folder = ""

    shelf = None

    # SuperPreset class
    super_preset = None

    # NumberPair class
    number_pair = None

    # View
    view = None

    # Window position dict
    window_pose = {}


The.power = Power(The)


class Helm:
    """
    Has a dictionary of navigation step key and AnyGroup
    value that are visible in the user interface.
    """

    def __init__(self):
        # {navigation step key: AnyGroup}
        self._helm_d = {}

        # [sequenced navigation step key of Preset type]
        self._step_q = []

        # [sequenced navigation step key of Preset, Node, and SuperPreset type]
        self._all_step_q = []

        The.power.connect(si.PANEL_CHANGE, self.on_node_change)
        return

    def add_step(self, k, a):
        """
        Add an AnyGroup to the Helm dict.

        k: tuple
            navigation step key

        a: AnyGroup
            Correspond with step key.
        """
        self._helm_d[k] = a

    def finds(self, k):
        """
        Determine if a navigation step key is the Helm dict.

        k: tuple
            navigation step key

        Return: bool
            Is True if the key is in the Helm dict.
        """
        return bool(k in self._helm_d)

    def get_all_step_q(self):
        """
        Provide a list of the steps in the navigation tree.

        Return: list
            [navigation step key]; [(node label, model id, node label, ...)]
        """
        return self._all_step_q[:]

    def get_branch_step_q(self, k):
        """
        Make a list of navigation step key that have a sub-step key.

        k: tuple
            Is the navigation step key at the start of a branch.

        Return: list
            containing branch step key
        """
        x = len(k)
        return [i for i in self._helm_d.keys() if k == tuple(i[0:x])]

    def get_group(self, k):
        """
        Fetch an AnyGroup from the Helm dict.

        k: tuple
            navigation step key
        Return: AnyGroup or None
        """
        if k in self._helm_d:
            return self._helm_d[k]

    def get_key_q(self):
        return self._helm_d.keys()

    def get_step_q(self):
        """Return a copy of the navigation step key list."""
        return self._step_q[:]

    def on_node_change(self, *_):
        """
        When there's Node change the main
        window's navigation step list changes.
        """
        self._all_step_q, self._step_q = get_step_q(self._helm_d, sk.STEPS)

    def remove_step(self, k):
        """
        Remove a navigation step key from the Helm dict.

        k: tuple
            navigation step key
        """
        if k in self._helm_d:
            self._helm_d.pop(k)

    def remove_model(self, a):
        """
        Remove step having a Model id reference from the Helm dict.

        a: int
            model id
        """
        d = self._helm_d
        for i in d.keys():
            if a in i:
                d.pop(i)


class Shelf:
    """Use to manage the offline dictionary that Model List loads."""

    def __init__(self):
        # {navigation step key: value dict}
        self._shelf_d = {}

    def clear_shelf(self):
        self._shelf_d.clear()

    def get_shelf_d(self):
        """
        Make a copy of the shelf dict.

        Return: dict
            the shelf dict
        """
        return deepcopy(self._shelf_d)

    def get_step_d(self, k):
        """
        Fetch the offline Preset for a navigation step key.

        k: tuple
            navigation step key

        Return: dict or None
            Is a Preset value dict.
        """
        if k in self._shelf_d:
            return self._shelf_d[k]

    def remove_model(self, a):
        """
        Remove step having a model id reference from the Helm dict.

        a: int
            model id
        """
        d = self._shelf_d
        for i in d.keys():
            if a in i:
                d.pop(i)

    def remove_step(self, k):
        """
        Remove a navigation step key from the shelf dict.

        k: tuple
            navigation step key
        """
        if k in self._shelf_d:
            self._shelf_d.pop(k)

    def set_step(self, k, a):
        """
        Set the value of a navigation step key in the shelf dict.

        k: tuple
            navigation step key

        a: value
            Is the value of the step's Preset.
        """
        self._shelf_d[k] = a

    def set_d(self, d):
        self._shelf_d = d


The.helm = Helm()
The.shelf = Shelf()
