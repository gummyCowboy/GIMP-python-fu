#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_maya_style import Style
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_view_real import (
    add_wip_layer, do_gradient_for_layer, finish_style, insert_copy
)
import gimpfu as fu

BUMP_ROW_K = ok.GBR
pdb = fu.pdb


def make_style(v, maya):
    """
    Do the Backdrop Style.

    v: View
        Has scope variable.

    maya: Style
    Return: layer or None
        with Cubism Cover
    """
    j = v.j
    d = maya.value_d
    n = d[ok.BACKDROP_TYPE]
    seed_ = d[ok.SEED] + v.glow_ball.seed

    if n == bs.PLASMA:
        z = add_wip_layer(v, maya, n)

    elif n == bs.BACKDROP_IMAGE:
        z = insert_copy(v, maya.group, maya.group)

    else:
        z = add_wip_layer(v, maya, "Base", maya.group)

    if n == bs.PLASMA:
        pdb.plug_in_plasma(
            j, z,
            seed_,
            1.                              # lowest turbulence
        )

    elif n == bs.GRADIENT:
        e = get_default_value(by.GRADIENT_FILL)
        e[ok.GRADIENT_TYPE] = d[ok.GRADIENT_TYPE]
        e[ok.GRADIENT] = d[ok.GBR][ok.GRADIENT]

        if d[ok.GRADIENT_TYPE] == "Linear":
            e[ok.END_X] = e[ok.START_X] = .5
            e[ok.START_Y] = .0
            e[ok.END_Y] = 1.

        else:
            e[ok.START_X] = e[ok.START_Y] = .5
            e[ok.END_X] = e[ok.END_Y] = .0

        z = do_gradient_for_layer(v, e, maya.group, 0)
        z = Lay.verify(z)
        if z:
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    if d[ok.BACKDROP_BLUR]:
        Lay.blur(z, d[ok.BACKDROP_BLUR])

    Gegl.cubism(z, size=d[ok.TILE_SIZE], amount=5., seed=seed_)

    z1 = Lay.clone(z, n="Soft light")
    z1.mode = z.mode = fu.LAYER_MODE_SOFTLIGHT

    Gegl.edge(z1)
    pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

    z = Lay.merge(z1)

    Gegl.saturation(z, d[ok.SATURATION])
    return finish_style(z, "Cubism Cover")


class CubismCover(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.GBR
    is_seeded = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        k_path = d['k_path']
        d['k_path'] = [k_path, k_path + (ok.GBR,)]
        Style.__init__(self, *q + (make_style,), **d)

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            Backdrop Style Preset

        go: bool
            If True, then create.

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = d[ok.BACKDROP_TYPE] == bs.BACKDROP_IMAGE
        super(CubismCover, self).do(v, d, is_change)
