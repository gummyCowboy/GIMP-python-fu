#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import Signal as si, Widget as fw
from roller_constant_key import (
    Button as bk,
    Group as gk,
    Item as ie,
    Model as md,
    ModelList as ml,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_model_box import Box
from roller_model_cell import Cell
from roller_model_stack import Stack
from roller_model_table import Table
from roller_one import Base
from roller_one_extract import (
    get_parent_node,
    get_node_row,
    make_panel_key,
    translate_to_id
)
from roller_one_the import The
from roller_one_tip import Tip
from roller_port_rename import PortRename
from roller_port_step import PortModelStep
from roller_port_tree import (
    DEFAULT_MODEL, MAIN_TREE_STEP, create_model_insert_d
)
from roller_widget import set_widget_attr
from roller_widget_box import Box as boxer
from roller_widget_button import Button, MoveDownButton, MoveUpButton
from roller_widget_combo import ComboBox
from roller_widget_button import RenameButton
from roller_widget_row import WidgetRow
from roller_widget_table import create_table
from roller_widget_tree import CHOICE_COLOR, TreeViewList
import gtk

MAKE_MODEL = {md.BOX: Box, md.CELL: Cell, md.STACK: Stack, md.TABLE: Table}
MANAGE = 'manage'
MODEL_STEP = "Model Step"
MODEL_TYPE = "Model Type"
NEED_COUNT = 2, 2, 1, 1, 1
SORT = 'sort'
SORT_KEY = SORT_UP, SORT_DOWN = "Up", "Down"
MANAGE_KEY = NEW, DELETE = "New", "Delete"
BUTTON_CHANGE = DELETE, NEW, SORT_DOWN, SORT_UP


def get_model_list():
    """
    Fetch the list of available Model type.

    Return: list
        of Model type
    """
    return md.MODEL_TYPE_LIST


def collect_online_model(d):
    """
    Find Model name in the online dict.

    d: dict
        online dict
        {panel key: group dict}

    Return: set
        {model name, ...}
    """
    q = set()

    for i in d:
        # Model name position in panel key, '1'
        if len(i) > 1 and i[1] != "Model":
            q.update((i[1],))
    return q


class ModelList(gtk.Alignment, object):
    """
    Is a Widget group with a TreeView and TreeView item manipulation Buttons.
    """
    change_signal = None
    has_table_label = False

    def __init__(self, **d):
        """
        Add an item list and associated Widgets to a group.
        Its value: (model definition, offline dict)

        Define Model character with model definition:
        (model name, model type) -> (string, string)

        Keep Model option group hidden but preserved between
        session with offline dict: {step key: AnyGroup or None}

        d: dict
            Has init values.
        """
        super(gtk.Alignment, self).__init__()
        set_widget_attr(self, d)

        # Use to return focus to a responsible Button.
        self.widget = None

        # [(model name, model type)]
        # Each item in the list is for a model
        # that is either online or offline.
        self._model_def = []

        self.view_value = [None, None]
        self._list_buttons = []
        self._branch_step_d = {}
        self._value = {ml.MODEL_DEF: [], ml.OFFLINE: {}, ml.ONLINE: {}}

        self.dialog = None
        d[wk.SCROLL] = 1
        d[wk.CHANGELESS] = True
        w = fw.MARGIN // 2
        hbox = gtk.HBox()
        relay = d[wk.RELAY][:]
        self._parent_node = get_parent_node(self.step_key)
        self._parent_node.connect(si.UPDATE_TREE, self.on_update_tree)

        # Table Widget keyword arguments, 'e'
        e = {}

        e.update(d)

        # container for the Table Widget, 'vbox'
        vbox = boxer(padding=(0, 0, 0, w))

        d[wk.RELAY].insert(0, self.on_model_list_tree_change)
        d.update({wk.COLOR: CHOICE_COLOR, wk.MINIMUM_W: 70})

        self._show_tree = TreeViewList(**d)
        model_type_relay = d[wk.RELAY] = relay[:]

        model_type_relay.insert(0, self.on_model_type_change)
        self._show_tree.treeview.set_tooltip_text(Tip.MODEL_LIST_TREE)

        # Build a Model Table.
        e['q'] = (
            (
                "Model Type",
                ComboBox,
                dict(
                    e,
                    key=MODEL_TYPE,
                    function=get_model_list,
                    relay=model_type_relay
                )
            ),
            (
                "",
                WidgetRow,
                dict(
                    e,
                    key=MANAGE,
                    relay=relay + [self.verify_buttons],
                    sub=OrderedDict([
                        (bk.NEW_MODEL, {
                            wk.TEXT: "New",
                            wk.TOOLTIP: Tip.MODEL_LIST_NEW,
                            wk.WIDGET: Button
                        }),
                        (bk.DEL_MODEL, {
                            wk.TEXT: "Delete",
                            wk.TOOLTIP: Tip.DELETE_MODEL,
                            wk.WIDGET: Button
                        }),
                        (bk.RENAME, {
                            wk.DIALOG: PortRename,
                            wk.TOOLTIP: Tip.RENAME_MODEL,
                            wk.WIDGET: RenameButton
                        })
                    ])
                )
            ),
            (
                "",
                WidgetRow,
                dict(
                    e,
                    key=SORT,
                    relay=relay + [self.verify_buttons],
                    sub=OrderedDict([
                        (bk.MOVE_UP, {
                            wk.TOOLTIP: Tip.MOVE_UP,
                            wk.WIDGET: MoveUpButton
                        }),
                        (bk.MOVE_DOWN, {
                            wk.TOOLTIP: Tip.MOVE_DOWN,
                            wk.WIDGET: MoveDownButton
                        })
                    ])
                )
            ),
            (
                "",
                Button,
                dict(
                    e,
                    key=MODEL_STEP,
                    text=MODEL_STEP,
                    tooltip=Tip.MODEL_STEP,
                    relay=relay + [self.on_model_step_action]
                )
            )
        )

        # dict of Widgets, 'd'
        d = create_table(vbox, **e)

        self._model_type = d[MODEL_TYPE]

        # Delete Button index, '1'
        self._list_buttons = d[SORT].widget_q + d[MANAGE].widget_q[1:]

        d[MANAGE].get_g(bk.NEW_MODEL).relay.insert(
            0, self.on_new_model_action
        )
        d[MANAGE].get_g(bk.DEL_MODEL).relay.insert(0, self.on_delete_item)
        d[SORT].get_g(bk.MOVE_DOWN).relay.insert(0, self.move_sel_down)
        d[SORT].get_g(bk.MOVE_UP).relay.insert(0, self.move_sel_up)
        for x, i in enumerate(self._list_buttons):
            i.need_count = NEED_COUNT[x]

        # Assign self variable to prevent garbage collection.
        # New Button index, '0'
        self._new_button = d[MANAGE].widget_q[0]

        self._model_step_button = d[MODEL_STEP]

        hbox.add(vbox)
        hbox.add(self._show_tree)
        self.add(hbox)
        self.verify_buttons()

        # Connect event.
        self._show_tree.treeview.connect(
            'key_press_event', self.on_model_list_keypress
        )
        self._show_tree.treeview.get_selection().connect(
            'changed', self.verify_buttons
        )
        The.power.connect(si.PANEL_CHANGE, self.update_branch_d)
        The.power.connect(si.PANEL_CHANGE, self.on_model_list_tree_change)
        The.power.connect(si.RENAME, self.on_rename_action)

        # Do last.
        d[MODEL_TYPE].set_a(md.TABLE)

    def _add_model_name_to_show(self, model_name, model_type, x):
        """
        Create an item for the show list from a Model's name.
        Enumerate the item name until a unique identifier is created.

        model_name: string or None
            identify the Model instance

        model_type: string
            Identify the Model type for Model init functionality.

        x: int
            Is the insertion index into the show tree.
            0 to length of show tree item
        """
        self._show_tree.list_store.insert(
            x,
            [model_name, '#000000', self._show_tree.background_color]
        )
        self._show_tree.item_q.insert(x, (model_name, model_type))
        self.verify_buttons()
        self._show_tree.select_item(x)

    def _delete_model_def_item(self, dead_name):
        """
        Remove an item from the Model definition list.

        dead_name: string
            Is the name of the Model that is to be removed.
        """
        for x, i in enumerate([i[0] for i in self._model_def]):
            if i == dead_name:
                self._model_def.pop(x)
                break

    def _fix_model_name(self, model_name, model_type):
        """
        A Model name is not allowed to contain a comma or a slash.

        model_name: string

        Return: string
            fixed Model name
        """
        n = model_type if model_name is None else model_name

        for i in (",", "/", "\\"):
            n = n.replace(i, "")

        # Model is reserved word.
        if n == "Model":
            n += "_"

        # list of Model names, 'q'
        q = [i[ml.NAME_INDEX] for i in self._model_def]
        q += [gk.MODEL]

        if any([i for i in q if i == n]):
            n = Base.enumerate_name(n, q)
        return n

    def _make_model_branch(self, model_name, model_type):
        """
        Add a Model to the main NodePanel.

        model: Model
            to add to the navigation tree

        model_name: string
            Is an item key for the Extra Node.
        """
        step_q = []

        # Create a Model definition list for the insertion dict, 'model_def'.
        model_def = []
        node_item_q = self._parent_node.get_item_list()[1:]

        for i in node_item_q:
            for name, type_ in self._show_tree.item_q:
                if name == i:
                    model_def += [(i, type_)]

        model_def += [(model_name, model_type)]

        for n, type_ in model_def:
            q = DEFAULT_MODEL[type_]
            step_q += [(n,) + i for i in q]

        d = create_model_insert_d(step_q, model_def)

        MAKE_MODEL[model_type](model_name)

        # is_default, tree_d, key, render_key, row, column
        self._parent_node.emit(
            si.ADD_ITEM, (True, d, sk.STEPS, sk.STEPS, None, 0)
        )

        # The Model group changed.
        self.any_group.changed()

    def _rename_model_def_item(self, old_name, new_name):
        """
        Change the name of a Model stored in the Model definition list.

        old_name: string
        new_name: string
        """
        for x, q in enumerate(self._model_def):
            model_name, model_type = q
            if model_name == old_name:
                self._model_def[x] = new_name, model_type
                break

    def _reorder_node_item(self):
        """Sync the Node item list with the Model list."""
        node_item_q = self._parent_node.get_item_list()
        new_q = [node_item_q[0]]

        for i in self._show_tree.item_q:
            n = i[ml.NAME_INDEX]
            for i1 in node_item_q:
                if n == i1.item:
                    new_q += [i1]
                    break

        self._parent_node.repopulate(new_q)
        self.any_group.changed()
        The.power.emit(si.MODEL_MOVE, None)
        The.power.plug(si.PANEL_CHANGE, None)

    def _update_item_q(self, old_name, new_name):
        """
        Update the show tree's item list.

        old_name: string
            to remove from the item list

        new_name: string
            to insert into the item list
        """
        q = self._show_tree.item_q
        for x, item in enumerate(q):
            if item[0] == old_name:
                q.pop(x)
                q.insert(x, (new_name, item[1]))

    def _update_show_tree(self, x, x1):
        """
        Update the list after a change.

        x: int
            new position

        x1: int
            old position
        """
        q = self._show_tree.item_q[x1]

        self._show_tree.remove_x(x1)
        self.insert_row(x, q)
        self._show_tree.select_item(x)

    def get_a(self):
        """
        Get the value for data storage.

        Return: dict
            ModelList value
        """
        self._value[ml.MODEL_DEF] = self._model_def
        self._value[ml.ONLINE] = self._branch_step_d
        self._value[ml.OFFLINE] = The.shelf.get_shelf_d()
        return self._value

    def get_model_branch_q(self, name_q):
        """
        Collect an online Model navigation step key list.

        name_q: list
            of Model name found in the navigation tree

        Return: list
            [step key]
        """
        q = []

        for model_name in name_q:
            q += self.get_model_branch(model_name)
        return q

    @staticmethod
    def get_model_branch(model_name):
        """
        Collect a Model step key list.

        model_name: string
        Return: list
            [step key]
        """
        return The.helm.get_branch_step_q(
            sk.EXTRA + (The.model_id.get_id(model_name),)
        )

    def get_model_def(self):
        """
        Fetch the Model definition list.

        Return: list
            as requested
        """
        return self._model_def[:]

    def get_selected_name(self):
        """
        From the Model listing, return the name with the selection.

        Return: string or None
            the selected Model's name
        """
        x = self._show_tree.get_sel_x()

        if x is not None:
            # Model name index, '0'
            return self._show_tree.item_q[x][0]

    def insert_row(self, x, q):
        """
        Insert a row into ModelList TreeView.

        x: int
            index to row

        q: tuple
            (Model Name, Model Type)
            to insert
        """
        list_store = self._show_tree.list_store

        # Model name index, '0'
        list_store.set_value(list_store.insert(x), 0, q[0])

        # Set the row's background color.
        list_store[x][2] = self._show_tree.background_color
        self._show_tree.item_q.insert(x, q)

    def move_sel_down(self, g):
        """
        Move a selection down one line in the TreeView.
        If 'x' selection is at the bottom of the list,
        then the item rotates to the top of the list.

        g: Button
            Is responsible.
        """
        x = x1 = self._show_tree.get_sel_x()
        a = len(self._show_tree.item_q)
        x += 1

        if x == a:
            x = 0

        self._update_show_tree(x, x1)
        g.widget.grab_focus()
        self._reorder_node_item()

    def move_sel_up(self, g):
        """
        Move a selection up one line in the TreeView.
        If 'x' selection is at the top of the list, then
        the item rotates to the bottom of the list.

        g: Button
            Is responsible
        """
        x = x1 = self._show_tree.get_sel_x()
        x -= 1

        if x < 0:
            x = len(self._show_tree.item_q) - 1

        self._update_show_tree(x, x1)
        g.widget.grab_focus()
        self._reorder_node_item()

    def on_delete_item(self, *_):
        """Delete a row in the TreeView."""
        x = self._show_tree.get_sel_x()

        if x is not None:
            n = self._show_tree.item_q[x][ml.NAME_INDEX]
            sel = self._show_tree.treeview.get_selection()
            if sel:
                self._show_tree.remove_x(x)
                self.verify_buttons()
                self._new_button.widget.grab_focus()

                model_id = The.model_id.get_id(n)
                model = The.model_id.get_model(model_id)

                model.baby.emit(si.MODEL_DIE, model)
                self._parent_node.remove_named_item(n)
                self._delete_model_def_item(n)
                The.shelf.remove_model(model_id)
                The.helm.remove_model(model_id)
                The.model_id.delete_with_name(n)
                The.power.plug(si.PANEL_CHANGE, None)
                return True

    def on_model_list_keypress(self, _, a):
        """
        Use to catch a Delete keypress.

        a: GTK Event
            of keypress
        """
        n = gtk.gdk.keyval_name(a.keyval)
        if len(self._show_tree.item_q):
            if n == 'Delete':
                return self.on_delete_item()

    def on_model_list_tree_change(self, *_):
        """
        Update the sensitivity of the Model Step Button.
        """
        self._model_step_button.set_sensitive(bool(self._model_def))

    @staticmethod
    def on_model_type_change(g):
        """
        Respond to a Model Type change event.

        g: ComboBox
            Is responsible.
        """
        k = g.get_a()
        if k in Tip.MODEL_LIST_TYPE:
            g.set_tooltip_text(Tip.MODEL_LIST_TYPE[k])

    def on_model_step_action(self, g):
        """
        Respond to an ModelTree Button click by opening a ModelTree Window.

        g: Button
            ModelStep type
        """
        self.widget = g
        self.dialog = PortModelStep
        self.roller_win.bring_dialog(self)
        return True

    def on_new_model_action(self, g):
        """
        Respond to a New Model action.

        g: Button
            New
        """
        model_type = self._model_type.get_a()
        model_name = self._fix_model_name(None, model_type)

        self._add_model_name_to_show(model_name, model_type, 0)
        self._model_def.insert(0, (model_name, model_type))
        self._make_model_branch(model_name, model_type)
        return True

    def on_rename_action(self, _, new_name):
        """
        Respond to a Rename Button action.

        _: Power
        new_name: string
            Is the new name for the selected Model.
        """
        # row index, 'x'
        x = self._show_tree.get_sel_x()
        old_name, model_type = self._show_tree.item_q[x]

        if old_name != new_name:
            new_name = self._fix_model_name(new_name, model_type)

            # Rename the Model in the ModelList.
            self._show_tree.rename_item(x, new_name)
            self._update_item_q(old_name, new_name)
            self._rename_model_def_item(old_name, new_name)

            # Rename the Model in the parent Node.
            item = self._parent_node.get_named_item(old_name)

            self._parent_node.rename_item(old_name, new_name)
            item.rename(new_name)

            # Rename the Label in the Model's Node branch.
            item.label.set_label_value(new_name)

            # Update the Model Id dict.
            The.model_id.rename(old_name, new_name)

            # Update the online branch dict.
            The.power.plug(si.PANEL_CHANGE, None)

            # Rename layer.
            The.power.emit(si.MODEL_RENAME, (old_name, new_name))
        return True

    def on_update_tree(self, sender, arg):
        """
        Respond to navigation tree structure update signal.
        Remove item and Node from tree that is no longer used.
        Add new item and Node to the tree from a new step key list.

        sender: Node
        arg: tuple
            ([new step key], [(model name, model type)])
        """
        while self._show_tree.item_q:
            self._show_tree.remove_x(0)

        for model_name, model_type in arg[1]:
            self._add_model_name_to_show(
                model_name, model_type, len(self._show_tree.item_q)
            )

    def set_a(self, d):
        """
        Load the item list from the owner's list.

        d: dict
            ModelList value
            {
                ml.MODEL_DEF: model def list,
                ml.ONLINE: SuperPreset,
                ml.OFFLINE: SuperPreset
            }

            SuperPreset
            {panel key: Preset value dict}

            A panel key has the Model name at index one.
            (label, model name, label, ...)

            Preset value dict
            {Option key: value}
        """
        # Before loading a ModelList Preset, clear the previous Model(s).
        while self._show_tree.item_q:
            self._show_tree.select_item(0)
            self.on_delete_item()

        # Remove incompatible Model type.
        del self._model_def[:]

        for model_name, model_type in d[ml.MODEL_DEF]:
            if model_type in md.MODEL_TYPE_LIST:
                self._model_def += [(model_name, model_type)]

        load_d = d[ml.ONLINE]

        The.shelf.set_d(d[ml.OFFLINE])

        if load_d:
            load_step_q = d[ml.ONLINE].keys() + MAIN_TREE_STEP
            online_model = collect_online_model(d[ml.ONLINE])

            # list of Model that are referenced in the online dict, 'model_def'
            model_def = []

            for model_name, model_type in self._model_def:
                if model_name in online_model:
                    self._add_model_name_to_show(
                        model_name, model_type, len(self._show_tree.item_q)
                    )

                    # Add a one per Model Preset step key.
                    load_step_q += [sk.EXTRA + (model_name,) + (ie.PRESET,)]
                    model_def += [(model_name, model_type)]
            if model_def:
                # Update the navigation tree.
                get_parent_node(sk.STEPS).emit(
                    si.UPDATE_TREE, (load_step_q, model_def)
                )

                load_d = translate_to_id(load_d)
                q = get_node_row(load_d)

                The.preset.load_super(load_d)

                # Select row after the Model branch tree is loaded.
                # A row is then in the same position as it was
                # when the SuperPreset was saved.
                for node, row in q:
                    node.select_row(row)

        The.power.plug(si.PANEL_CHANGE, None)

        # In this case, Power's plug function
        # is too slow, so the direct emission.
        The.power.emit(
            si.NODE_CHANGE, The.helm.get_group(sk.STEPS).widget_d[ok.NODE]
        )

    def set_view_value(self, x, a):
        """
        ModelList remembers its parent Node value as its
        state is used to detect background change by
        Model Maya.

        x: int
            Plan or Work index

        a: dict
            ModelList value
            not used
        """
        # Ignore the Model Item at the top of the list, '1'.
        self.view_value[x] = self._parent_node.get_item_list()[1:]

    def verify_buttons(self, *_):
        """Verify the Buttons dependent on the list's size."""

        def disable_buttons():
            """
            Disable the dependent Buttons as there
            is no item selected in the ModelList.
            """
            for _g in self._list_buttons:
                _g.disable()
                _g.set_tooltip_text("")

        sel = self._show_tree.treeview.get_selection()

        if sel:
            # GtkTreeIter, 'iter_'
            iter_ = sel.get_selected()[1]

            if iter_:
                # The move and delete Buttons are dependent
                # on their selection state and the list size.
                x = self._show_tree.get_sel_x()
                for g in self._list_buttons:
                    if (
                        len(self._show_tree.item_q) >= g.need_count and
                        x is not None
                    ):
                        g.enable()
                        g.set_tooltip_text(g.tooltip_text)
                    else:
                        g.disable()
                        g.set_tooltip_text("")
            else:
                disable_buttons()
        else:
            disable_buttons()

    def update_branch_d(self, _, arg):
        """
        The branch dict is the online portion of self value.
        The dict is dependent on AnyGroup initialization.

        _: Power
            Sent the Signal.

        arg: None
        """
        # Set up the branch dict for the getter.
        # Link directly with value dict for speed as this is an expensive op.
        self._branch_step_d.clear()

        # online Model name list, 'name_q'
        name_q = self._parent_node.get_label_q()[1:]

        for i in self.get_model_branch_q(name_q):
            a = The.helm.get_group(i)
            if a:
                if a.item.group_type in ('node', 'preset'):
                    self._branch_step_d[make_panel_key(i)] = a.value_d
        self.any_group.update_option_a(self.key, self.get_a())

        # Sort the model definition list.
        top_def = [
            q for n in name_q for q in self._model_def if n == q[ml.NAME_INDEX]
        ]
        off_def = [
            q for q in self._model_def if q[ml.NAME_INDEX] not in name_q
        ]

        # Empty the model definition list (Python 2.7).
        # Reference
        # stackoverflow.com/questions/1400608/how-to-empty-a-list
        # Python 3: list.clear()
        del self._model_def[:]

        for q in top_def + off_def:
            self._model_def += [q]
