#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_port_preview import PortPreview
from roller_widget_node import Piece


class PortNoise(PortPreview):
    """Is a display container for the Noise Preset."""
    window_key = "Noise"

    def __init__(self, d, g):
        """
        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_noise(self, box):
        """
        Draw the Frame Noise Preset option group.

        box: GTK container
            to receive group
        """
        self.draw_group(Piece(ok.NOISE_D, box, self.safe.any_group.item))

    def draw(self):
        """Draw Widget."""
        self.draw_column((self._draw_noise, self.draw_random_process_group))

    def get_group_value(self):
        """
        Get the Preset value.

        Return: dict
            Bump Preset
        """
        return self.preset.get_a()
