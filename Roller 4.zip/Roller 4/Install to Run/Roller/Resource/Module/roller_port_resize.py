#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_port_preview import PortPreview
from roller_widget_node import Piece


class PortResize(PortPreview):
    """Is a display container for the Resize Preset."""
    window_key = "Resize"

    def __init__(self, d, g):
        """
        d: dict
            Has init values.

        g: Button
            Has a Resize Method Preset dict as its value.
        """
        PortPreview.__init__(self, d, g)

    def _draw_resize_option(self, box):
        """
        Draw the option group.

        box: VBox
            container for the group
        """
        self.draw_group(Piece(ok.RESIZE, box, self.safe.any_group.item))

    def draw(self):
        """
        Draw Widget.

        g: VBox
            container for Widget
        """
        self.draw_column((self._draw_resize_option, self.draw_process))

    def get_group_value(self):
        """
        Get the Resize Method Preset value.

        Return: dict
            Resize Method Preset
        """
        return self.preset.get_a()
