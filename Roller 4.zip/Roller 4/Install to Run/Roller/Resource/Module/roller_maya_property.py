#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_maya import MAIN, Maya
from roller_option_group import ManyGroup


class Property(ManyGroup):
    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)


class Chi(Maya):
    """Use with Plan and Work."""
    issue_q = ()
    vote_type = MAIN

    def __init__(self, any_group, view_x):
        Maya.__init__(self, any_group, view_x, ())


class Plan(Chi):
    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0)

    def do(self, v):
        """
        v: View
        """
        return


class Work(Chi):
    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1)

    def do(self, v):
        """
        v: View
        """
        return
