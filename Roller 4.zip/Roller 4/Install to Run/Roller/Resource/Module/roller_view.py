#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Signal as si
from roller_constant_key import (
    Image as ik, ModelList as ml, Option as ok, Step as sk
)
from roller_one import Rect
from roller_one_extract import find_visible_preset, get_step_d, translate_to_id
from roller_one_the import The
from roller_view_contain import Caption, Deco, Global, Pot
from roller_view_plan import Plan
from roller_view_work import Work

# Is the state of image index and key used
# by an Image Preset upon the first View run.
IMAGE_SOURCE_D = {
    # Is a condition that will cause an init function
    # to perform by an Image class' function, '-2'.
    ik.LOOP_DICT: {ik.LOOP: -2, ik.SLICE: {}},

    ik.NEXT_DICT: {ik.NEXT: 0, ik.SLICE: {}},
    ik.PREVIOUS_DICT: {ik.PREVIOUS: -2, ik.SLICE: {}},
    ik.SLICE: {}
}


def do_planner(v, step_q):
    """
    Make a render using Plan.

    v: View
    step_q: list
        Is navigation step for Plan.
    """
    v.is_preview = False

    # Plan index, '0'
    v.x = 0
    v.plan.do(v, prep(v, step_q, find_altered(step_q, 0)))


def do_worker(v, step_q, step_d, d):
    """
    Make a render using Work.

    v: View
    step_q: list
        Is navigation step key passed to Work.

    step_d: dict
        {navigation step key: Preset value dict}

    d: dict or None
        Steps Preset, a session type
        Is returned for the final View and its session save.

    Return: tuple
        (the default step value dict, the tree value dict)
    """
    # Work index, '1'
    v.x = 1

    v.work.do(v, prep(v, step_q, find_altered(step_q, 1)))
    return d, step_d


def get_peek_lists():
    """
    Make two lists for a Draft or Peek function. The first list
    are the steps to a View run, and the second list are steps that
    didn't get processed due to the peek limitation.

    Return: tuple
        ([step key], [step key])
    """
    step_key = find_visible_preset()
    q = The.helm.get_step_q()
    x = q.index(step_key) + 1
    return q[:x], q[x:]


def prep(v, step_q, step_x):
    """
    Prepare variables for a View run.

    v: View
    step_q: list
        [navigation step key]
        Initialize the image source dict.

    step_x: int or None
        Is the index to the first navigation step that is altered.

    Return: list
        of Step for the View run
    """
    # Step list for the view run, 'q'
    q = []

    v.is_active = True
    get_group = The.helm.get_group

    if step_x is not None:
        for x, k in enumerate(step_q[step_x:]):
            q += [get_group(k)]

        # Do last.
        is_found = False

        # the index of the step before the first altered step, 'x'
        x = step_x - 1

        while x >= 0:
            # navigation step key, 'k'
            k = step_q[x]
            if k in v.source_d:
                is_found = True
                break
            x -= 1

        if is_found:
            v.image_source = deepcopy(v.source_d[k])
        else:
            # Set to the initial state of image source.
            v.image_source = deepcopy(IMAGE_SOURCE_D)
    return q


def find_altered(steps, view_x):
    """
    The altered state is used to indicate an option group's
    View status. If it's changed, then the step needs
    to be processed.

    There is a chain-inheritance in the step sequence. If a step
    is changed, the succeeding steps are also potentially changed.

    steps: list
        of navigation step key
        of tuple containing a Node label series
        (Node label,)

    view_x: int
        Plan or Work index; 0 or 1

    Return: int or None
        Is the index to the first altered option group.
    """
    get_group = The.helm.get_group
    for x, i in enumerate(steps):
        a = get_group(i)
        if a.item.group_type == 'preset' and a.altered[view_x]:
            return x


def update_after_view(v, non_view_q, x):
    """
    Update AnyGroup that is not part of the last View.

    v: View
    non_view_q: list
        [navigation step key]
        Each item that was not viewed.

    x: int
        0 or 1; Plan or Work
    """
    p = The.helm.get_group
    for k in non_view_q:
        a = p(k)

        if v.is_back:
            a.emit(si.BACK_CHANGE, x)
        a.changed(x)


class View:
    """Perform a View."""

    def __init__(self):
        """Get ready for a View operation."""
        # container
        self.caption = Caption()

        # container
        # Use with a decoration step.
        self.deco = Deco()

        # container
        # Set by the Global AnyGroup.
        self.glow_ball = Global()

        # dict
        # Use with image assignment.
        self.image_source = None

        # Is True when it's running through the steps.
        self.is_active = False

        # Is set by Gradient Light Maya. Is used by Light Maya.
        # Indicate the Gradient Light switch state.
        self.is_light_on = False

        # Is True when Work is doing a Preview.
        self.is_preview = False

        # the rendered GIMP image
        self.j = None

        # Is used to stream background change state.
        self.is_back = False

        # dict
        # value, key -> [snapshot of image source dict: step key]
        self.source_d = {}

        # container
        # Use with Image, 'pot'.
        self.pot = Pot(False)

        # Use with deco Mask, 'mask'.
        self.mask = None

        # Is the image size specified by the User in the Global option group.
        self.wip = Rect()

        # step processors
        self.plan = Plan()
        self.work = Work()

        # Is the displayed actual image size.
        self.view_size = 0, 0

        # Is an index for the split in View take with
        # Plan and Work, where 0 is for Plan and 1 for Work.
        self.x = None

    def _clean_up(self):
        """Clean up after a viewing."""
        self.is_back = self.is_active = False

    def do_draft(self):
        """A Plan View that stops on the active Preset AnyGroup."""
        step_q, q = get_peek_lists()

        do_planner(self, step_q)
        update_after_view(self, q, 0)
        self._clean_up()

    def do_peek(self):
        """A Work View that stops on the active Preset AnyGroup."""
        step_q, q = get_peek_lists()
        self.is_preview = True

        do_worker(self, step_q, get_step_d(step_q), None)
        update_after_view(self, q, 1)
        self._clean_up()

    def do_plan(self):
        """Call to do a Plan View run."""
        d = get_step_d(sk.DEFAULT_STEP)
        step_d = deepcopy(d)

        step_d.update(
            translate_to_id(d[sk.MODEL][ok.MODEL_LIST][ml.ONLINE])
        )
        do_planner(self, The.helm.get_step_q())
        self._clean_up()

    def do_preview(self):
        """Make a render but keep the main window open."""
        self.is_preview = True
        self.do_work()
        self._clean_up()

    def do_render(self):
        """Make a render."""
        self.is_preview = False
        return self.do_work()

    def do_work(self):
        """
        Make a render using Work.

        Return: tuple
            (the default step value dict, the tree value dict)
        """
        d = get_step_d(sk.DEFAULT_STEP)
        step_d = deepcopy(d)

        step_d.update(
            translate_to_id(d[sk.MODEL][ok.MODEL_LIST][ml.ONLINE])
        )
        return do_worker(self, The.helm.get_step_q(), step_d, d)
