#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_constant import OptionKey, SessionKey
from roller_backdrop_style import BackdropStyle
from roller_fu import Lay
import gimpfu as fu


class RainbowValley(BackdropStyle):
    """Fill the backdrop with a colorful abstract."""
    name = SessionKey.RAINBOW_VALLEY

    def __init__(self, d, stat):
        """d: sub-session dict"""
        BackdropStyle.__init__(self, d, stat)

    def do(self, d):
        """
        Creates the droopy rainbow effect.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        e = deepcopy(d)
        ok = OptionKey
        j = self.stat.render
        z = Lay.clone(j, self.active.layer)
        self.group = Lay.group(j, self.name)

        pdb.plug_in_plasma(j, z, e[ok.RANDOM_SEED], 3)
        Lay.order(j, z, self.group)

        for i in range(10):
            z = Lay.clone(j, z)
            z.mode = fu.LAYER_MODE_DIFFERENCE
            pdb.plug_in_despeckle(j, z, i, 0, 0, 255)

            if i % 2:
                z = Lay.clone(j, z)
                z.mode = fu.LAYER_MODE_LIGHTEN_ONLY
                self.noise(z, e)
                e[ok.RANDOM_SEED] += 1
                pdb.plug_in_despeckle(j, z, i, 0, 0, 255)
                z = Lay.merge(j, z)

            do_engrave = 0

            if e[ok.TEXTURE]:
                if i < 7 or i == 9:
                    do_engrave = 1

            elif i < 7:
                do_engrave = 1

            if do_engrave:
                z = Lay.clone(j, z)

                pdb.plug_in_engrave(j, z, max(i, 2), 1)

                z.mode = fu.LAYER_MODE_BURN
                z = Lay.merge(j, z)
                pdb.plug_in_wind(j, z, 0, 2, 50, 1, 1)

        z = z1 = Lay.eat(j, self.group)

        if e[ok.EMBOSS]:
            z = Lay.clone(j, z1)
            pdb.plug_in_emboss(j, z, 45, 30., 1, 1)

            z.mode = fu.LAYER_MODE_OVERLAY
            z = Lay.merge(j, z)
        self.finish_style(z)
