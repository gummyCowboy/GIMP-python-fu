#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_constant import ForGradient, ForLayer, OptionKey, SessionKey
from roller_fu import Lay, Sel
from roller_backdrop_style import BackdropStyle
from roller_gradient_fill import GradientFill
import gimpfu as fu


class LostMaze(BackdropStyle):
    """Use a maze to create regions, a border, and grid lines."""
    name = SessionKey.LOST_MAZE
    row = 4
    column = 4

    def __init__(self, d, stat):
        """
        Let RenderHub have the task.

        d: sub-session dict
        stat: Stat
        """
        BackdropStyle.__init__(self, d, stat)

    def _do_gradient(self):
        """
        Draws a gradient.

        Use ‟self.e” to pass gradient variables.
        """
        GradientFill(
                self.e,
                self.stat,
                name=self.name,
                layer_key=self.name,
                auto=1
            )

    def _do_grid(self, z, q, is_vertical=1):
        """
        Draw grid lines.

        The grid lines are either horizontal
        or vertical, but not both.

        z: layer
            Draw on this layer.

        q: tuple
            arguments for vertical or horizontal lines.

        is_vertical: flag
            If it's true, the arguments are for vertical lines.
        """
        args = self.stat.render, z
        q1 = 0, 0, 0, (0, 0, 0), 0

        if is_vertical:
            args += q1 + q + q1

        else:
            args += q + q1 * 2
        pdb.plug_in_grid(*args)

    def do(self, d):
        """
        Is part of a RenderHub class template.

        d: sub-session dict
        """
        ok = OptionKey
        stat = self.stat
        j = stat.render
        self.group = Lay.group(j, self.name)
        self.group.mode = fu.LAYER_MODE_PASS_THROUGH
        z = maze_layer = Lay.add(j, self.name, z=self.group)
        w = stat.width / d[ok.COLUMN]
        h = stat.height / d[ok.ROW]

        pdb.gimp_context_set_foreground((0, 0, 0))
        pdb.gimp_context_set_background((255, 255, 255))
        pdb.plug_in_maze(j, z, w, h, True, 0, d[ok.RANDOM_SEED], 0, 0)

        z = Lay.clone(j, z)

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        alpha_layer = Lay.clone(j, z)
        alpha_layer.mode = fu.LAYER_MODE_DIFFERENCE

        Sel.none(j)
        pdb.plug_in_edge(j, maze_layer, 1., 0, 0)

        # Expand the border:
        for _ in range(2):
            pdb.plug_in_dilate(
                    j,
                    maze_layer,
                    6,
                    0,
                    1.,
                    0,
                    0,
                    255
                )

        pdb.plug_in_colortoalpha(j, maze_layer, (0, 0, 0))

        # horizontal lines:
        h1 = min(max(6, h / 5), self.stat.height)

        self._do_grid(z, (h1, h1 + 1, 0, (0, 0, 0), 255), is_vertical=0)
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        z = Lay.merge(j, z)
        e = self.e = deepcopy(ForGradient.LINEAR_DICT)
        e.update(d)
        e[ok.START_X] = self.stat.width - 1
        e[ok.START_Y] = self.stat.height - 1
        e[ok.END_X] = e[ok.END_Y] = 0

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        Sel.item(j, z)

        sel = Sel.save(j)

        Sel.none(j)
        Lay.activate(j, z)
        self._do_gradient()

        z = Lay.get_active(j)

        Sel.isolate(j, z, sel)
        self.shadow(z, blur=8., op=140., offset_x=3, offset_y=3)
        Sel.none(j)

        # vertical lines:
        z = Lay.add(j, self.name, z=self.group, a=len(self.group.layers) + 1)

        Lay.color_fill(z, (255, 255, 255))
        Sel.all(j)

        v1 = min(max(12, w / 12), self.stat.width)

        self._do_grid(z, (v1, v1 + 1, 0, (0, 0, 0), 255))
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        self.shadow(
                z,
                blur=10,
                op=200.,
                d=ForLayer.INHERIT_DICT,
                inlay=1
            )

        self.shadow(z, blur=10, op=200.)

        # background:
        e[ok.END_X] = e[ok.START_X] = self.stat.width / 2
        e[ok.START_Y] = self.stat.height / 2
        e[ok.END_Y] = 0
        e[ok.GRADIENT_TYPE] = "Bilinear"
        z = Lay.add(j, self.name, z=self.group, a=len(self.group.layers) + 1)

        Lay.activate(j, z)
        self._do_gradient()
        Lay.order(j, alpha_layer, self.group, a=4)
        Lay.blur(j, alpha_layer, max(v1 * 2, h1 * 2))

        # grain effect:
        z = Lay.clone(j, alpha_layer)

        Lay.order(j, z, self.group, a=6)

        z.mode = fu.LAYER_MODE_GRAIN_EXTRACT

        Lay.invert(z, 1)

        z = Lay.eat(j, self.group)
        self.finish_style(z)
