#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForCell, ForWidget
from roller_splitter import Splitter
from roller_button import RollerButton
from roller_check_button import RollerCheckButton


class GroupPerCell(RollerCheckButton):
    """
    Has a UICell window opener Button and a per-cell CheckButton.
    """

    def __init__(
                self,
                checkbutton_action,
                button_action,
                text,
                checkbutton_key,
                container,
                window_index
            ):
        u"""
        checkbutton_action: function
            Call on Per Cell CheckButton action.

        button_action: function
            Call on Button action.

        text: string
            Button label

        checkbutton_key: string
            CheckButton's key

        container: object
            Widget or GTK container

        window_index: int
            index to UICell window
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        self.key = checkbutton_key
        self.update_window_for_checkbutton = checkbutton_action
        self.update_window_for_button = button_action
        self.x = window_index
        self.cell_key = ForCell.CELL_KEY_LIST[window_index]
        p = self.on_check_button_change
        p1 = self.on_button_action
        g1 = Splitter(padding=(w1, w, w, w), has_inner_padding=False)

        RollerCheckButton.__init__(self, "Per Cell", p, key=checkbutton_key)

        g2 = self.g1 = RollerButton(text, p1)

        g1.left.add(self.alignment)
        g1.right.add(g2.alignment)
        g1.pack()
        container.add(g1.container)

    def on_check_button_change(self, g):
        """
        Intercept signals from the CheckButton.

        g: CheckButton widget
        """
        self.verify_button()
        self.update_window_for_checkbutton(g)

    def on_button_action(self, _):
        """Intercept changed signal from the Button."""
        self.update_window_for_button(self.x)

    def set_value(self, a):
        """
        Set the value of the CheckButton and is part of a UI widget template.

        Verify the cell window opener button.

        a: int
        """
        RollerCheckButton.set_value(self, a)
        self.verify_button()

    def verify_button(self):
        """
        The cell window Button is valid only if the CheckButton is checked.
        """
        self.g1.enable() if self.get_value() else self.g1.disable()
