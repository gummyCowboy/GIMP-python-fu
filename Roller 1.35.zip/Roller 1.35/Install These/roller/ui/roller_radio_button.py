#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_widget import Widget
import gtk


class RollerRadioButton(Widget):
    """This is GTK RadioButton attached to an Alignment."""

    def __init__(self, on_action, text, widget_key, group):
        """
        on_action: function
            on action function

        text: string
            label text

        widget_key: string
            widget key

        group: RollerRadioButton
            first widget in the button group or None
        """
        g = self.alignment = gtk.Alignment(0, 0, 1, 0)
        g1 = gtk.RadioButton(group, text)

        Widget.__init__(self, on_action, key=widget_key, widget=g1)

        g1.connect("toggled", self.callback)
        g.add(g1)

    def get_value(self):
        """
        Return the value of the RadioButton.

        Is part of a UI widget template.
        """
        return self.wig.get_active()

    def set_value(self, value):
        """
        Set the value of the RadioButton.

        Is part of a UI widget template.

        value: int (0..1)
        """
        self.wig.set_active(value)
