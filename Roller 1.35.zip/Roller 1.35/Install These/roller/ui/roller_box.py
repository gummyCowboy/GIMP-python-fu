#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gtk


class RollerBox:
    """This is a GTK Box widget with an Alignment."""

    def __init__(self, index, align=(0, 0, 0, 0), padding=None):
        """
        index: int
            The index to box-type where
                0 is a VBox,
                1 is a HBox, and
                2 is a VButtonBox.

        align: tuple (f, f, f, f)
            Alignment

        padding: tuple of int
            (top, bottom, left, right)
        """
        g = self.alignment = gtk.Alignment(*align)
        g1 = self.box = (gtk.VBox, gtk.HBox, gtk.VButtonBox)[index]()

        if padding:
            g.set_padding(*padding)
        g.add(g1)

    def add(self, g):
        """g: GTK widget"""
        self.box.add(g)
