#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import ForLayer, LayerKey, OptionKey, SessionKey
from roller_drop_shadow import DropShadow
from roller_effect import Effect
from roller_fu import Lay, Sel
from roller_shadow import Shadow
import gimpfu as fu


class ClearFrame(Effect):
    """Create a translucent border around an image(s)."""
    name = SessionKey.CLEAR_FRAME
    width_low, width_high = 20, 50

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        Effect.__init__(self, d, stat)
        if self.has_room:
            if not stat.cancel:
                DropShadow(
                    {}, stat, q=(SessionKey.CLEAR_FRAME, LayerKey.IMAGE))

            if not stat.cancel:
                Shadow(
                        SessionKey.IMAGE_EDGE_SHADOW,
                        stat,
                        q=(LayerKey.IMAGE,),
                        inlay=1
                    )
            if not stat.cancel:
                self.do_behind_shadow(
                        SessionKey.DROP_SHADOW,
                        (LayerKey.IMAGE,),
                        self.sel
                    )

    def _do_edge(self, j, z, z1, q):
        """
        Use to create an overlay edge effect
        where the light source is directly above
        the subject.

        j: GIMP image
        z: group
        z1: layer
        q: background color
            The background color needs to differ from the subject.
            It is used to turn transparent pixels into opaque pixels.

        Return the layer with the edge.
        """
        edge = Lay.clone(j, z1)
        bg = Lay.new(j, "bg")

        Lay.color_fill(bg, q)
        Lay.place(j, bg, z1=z, a=1)

        edge = Lay.merge(j, edge)

        pdb.plug_in_edge(
                j,
                edge,
                1.,
                0,
                0
            )

        Sel.item(j, z1)
        Sel.kleer(j, edge)

        edge.mode = fu.LAYER_MODE_OVERLAY
        return Lay.merge(j, edge)

    @staticmethod
    def _edge_color(q):
        """
        Return an edge color for a color.

        q: color
        """
        q1 = [0] * 3

        for x, a in enumerate(q):
            q1[x] = 0 if a > 127 else 255
        return tuple(q1)

    def do(self, d):
        """
        Draws the clear frame.

        The clear frame creates two layers. One layer forms an edge
        around the image, and the other expands to form the frame.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        ok = OptionKey
        j = self.stat.render
        frame = [0, 0]
        n = self.id
        q = ClearFrame._edge_color(d[ok.COLOR_1])
        z = Lay.group(j, self.id, z=self.active.format)
        select_layer = Lay.selectable(
                j,
                Lay.get_active_image(self.stat),
                ForLayer.INHERIT_DICT
            )

        # Creates two layers:
        for x in range(2):
            Sel.item(j, select_layer)
            Sel.grow(
                    j,
                    (d[ok.BORDER_WIDTH] + 5, 5)[x],
                    d[ok.BORDER_TYPE]
                )

            z1 = Lay.add(j, n, z=z)

            Sel.fill(z1, d[ok.COLOR_1])
            Sel.item(j, select_layer)
            Lay.klear(j, z1)
            frame[x] = self._do_edge(j, z, z1, q)

        Lay.bury(j, select_layer)

        wide = frame[d[ok.BORDER_WIDTH] < 5]

        self.blur_bg(d, wide)

        # Add shadow and merge:
        z1 = self.do_shadow(frame[1], 0, 0, 5, (0, 0, 0), 100)

        Lay.order(j, z1, z)

        z1.mode = fu.LAYER_MODE_NORMAL
        frame[0].opacity = 55.
        frame[1].mode = fu.LAYER_MODE_OVERLAY
        z = Lay.eat(j, z)
        z.opacity = 55.
        z.name = Lay.get_layer_name(SessionKey.CLEAR_FRAME, self.stat)

        # Make an opaque selection for ‟self.do_behind_shadow”:
        z2 = Lay.selectable(j, z, ForLayer.INHERIT_DICT)

        Sel.item(j, z2)
        Lay.bury(j, z2)

        # Save selection for blurred behind:
        self.sel = Sel.save(j)

        Sel.none(j)
        Lay.anti(j, z)
