#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant import ForPreset, PresetKey, SessionKey
from roller_preset import Preset
from roller_session import Session
from roller_ui import UI


class PresetSession(Preset):
    """
    This is the Preset used in the Form group.

    Its Preset is the Session data, and
    the window position dictionary.
    """

    def __init__(self, d):
        """d: preset dict"""
        pk = PresetKey
        e = d[pk.DEFAULT] = deepcopy(Session.default)

        # Don't deepcopy UI.win so that the
        # default preset will still up-to-date:
        e[SessionKey.WINDOW] = UI.win
        d[pk.INTERNAL] = [
                [ForPreset.INTERNAL_TYPE, pk.DEFAULT, e]
            ]
        d[pk.NAME] = "Session"
        Preset.__init__(self, d)
