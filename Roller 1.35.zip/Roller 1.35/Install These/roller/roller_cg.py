#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForColor, FormatKey
from roller_label import RollerLabel
import gtk


class CG:
    """Manage cell grouping and serve UICell."""

    # ‟overlay” is a flag. When it is true,
    # merge cell controls are not displayed.
    overlay = 0

    # ‟cell” is a Cell.
    # It's used when displaying cell sizes in a Merge Cells window.
    cell = None

    # Format object:
    format_c = None

    grid = {}
    LABEL_ID = "w: ", "h: ", "x: ", "y: "
    LAB_WIDTH = 'label_width'
    LAB_KEY_LIST = LAB_WIDTH, 'label_height', 'label_x', 'label_y'

    # Use to update button padding:
    button_clicked = False

    @staticmethod
    def _calc_bottom_right(d):
        """
        Return the row and column for the
        bottom-right cell of a merged cell group.

        d: top-left cell dict
        """
        return d['row'] + d['size'][0] - 1, d['column'] + d['size'][1] - 1

    @staticmethod
    def _generate_group(slices):
        """
        Slice organize themselves into one or two groups.

        A slice is a cell group with a piece of itself
        removed by a ‟connect_up” or ‟connect_left” process
        and the resulting merge group.

        slices: a dict of dictionaries where each defines a group of cells
        """
        for k in slices:
            # Sort the two possible groups
            # into a larger and smaller group (short).
            # The larger group will have the greater cell count.
            # The smaller group will be the cells not in the larger group.
            # If there's only one group,
            # the smaller group won't get initialized.
            #
            # Starts by finding the longer and shorter row.
            u = slices[k]['size']
            long_row_width = long_row_height = 0
            long_col_width = long_col_height = 0
            short_col_width = short_row_height = 0
            short_row_width = short_col_height = 0
            start_long_row = [0, 0]
            start_short_row = [0, 0]
            start_long_col = [0, 0]
            start_short_col = [0, 0]

            # The key is the topleft coordinate (r, c):
            for r in range(k[0], k[0] + u[0]):
                row_width = 0
                first_col = -1

                for c in range(k[1], k[1] + u[1]):
                    if CG._is_vector(k, r, c):
                        row_width += 1
                        if first_col < 0:
                            first_col = c

                    elif row_width:
                        break

                if row_width > long_row_width:
                    if long_row_width > 0:
                        # Second group inherits from the first group:
                        short_row_width = long_row_width
                        short_row_height = long_row_height
                        start_short_row = start_long_row

                    # Initialize first group:
                    long_row_width = row_width
                    long_row_height = 1
                    start_long_row = r, first_col

                elif row_width:
                    # The vector is long or short:
                    if row_width == long_row_width:
                        long_row_height += 1

                    else:
                        if short_row_height:
                            # Add another row:
                            short_row_height += 1

                        else:
                            # Initialize second group:
                            short_row_width = row_width
                            start_short_row = r, first_col
                            short_row_height = 1

            # Start finding the long and short column:
            for c in range(k[1], k[1] + u[1]):
                col_height = 0
                first_row = -1

                for r in range(k[0], k[0] + u[0]):
                    if CG._is_vector(k, r, c):
                        col_height += 1
                        if first_row < 0:
                            first_row = r

                    elif col_height:
                        break

                if col_height > long_col_height:
                    if long_col_height > 0:
                        # Second group inherits from the first group:
                        short_col_width = long_col_width
                        short_col_height = long_col_height
                        start_short_col = start_long_col

                    # Initialize first group:
                    long_col_height = col_height
                    long_col_width = 1
                    start_long_col = first_row, c

                elif col_height:
                    # The vector is long or short:
                    if col_height == long_col_height:
                        long_col_width += 1

                    else:
                        if short_col_height:
                            short_col_width += 1

                        else:
                            # Initialize second group:
                            short_col_width = 1
                            short_col_height = col_height
                            start_short_col = first_row, c

            row_cells = long_row_width * long_row_height
            col_cells = long_col_height * long_col_width
            v = 0

            if row_cells >= col_cells:
                u = long_row_height, long_row_width
                d = CG.grid[start_long_row[0]][start_long_row[1]]

                # Process second group if it was initialized:
                if short_row_width > 0:
                    v = short_row_height, short_row_width
                    d1 = CG.grid[
                        start_short_row[0]][start_short_row[1]]

            else:
                u = long_col_height, long_col_width
                d = CG.grid[start_long_col[0]][start_long_col[1]]

                # Process second group if it was initialized:
                if short_col_height > 0:
                    v = short_col_height, short_col_width
                    d1 = CG.grid[
                        start_short_col[0]][start_short_col[1]]

            CG._set_group(d, u)

            # Set the second group if there was one:
            if v:
                CG._set_group(d1, v)

    @staticmethod
    def _get_d(r, c):
        """Return the dictionary for the cell at r, c."""
        return CG.grid[r][c]

    @staticmethod
    def _get_start_end_of_top(d):
        """
        Return the row and column for the current
        cell and its bottom-right cell.

        d: cell dict
        """
        s = d['row'], d['column']
        t = s[0] + d['size'][0] - 1, s[1] + d['size'][1] - 1
        return s, t

    @staticmethod
    def _get_topleft(d=None, u=None):
        """
        Top-left is the cell located at the top-left of a group.

        Sub-top-left cells refer to the top-left
        cell through a ‟topleft” key.

        d: cell dict
        u: (r, c)
        """
        if u:
            d = CG.grid[u[0]][u[1]]

        if d['size'][0] < 0:
            v = d['topleft']

        else:
            v = d['row'], d['column']
        return CG.grid[v[0]][v[1]]

    @staticmethod
    def _is_group(d):
        """
        Return true if a cell is part of a group.

        d: cell dict
        """
        return CG.is_topleft(d) or d['size'] == (-1, -1)

    @staticmethod
    def _is_outside(d, r, c, s):
        """
        Return true if the cell has cells that
        exist outside the bounds of a rectangle.

        d: cell dict
        r, c, s: bounds
        """
        if d['row'] < r or d['column'] < c or d['row'] \
                + d['size'][0] > r + s[0] or d['column'] \
                + d['size'][1] > c + s[1]:
            return 1

    @staticmethod
    def _is_vector(u, r, c):
        """
        Return true if the cell (r, c) is still
        referencing a top-left cell at ‟u”.

        u:  (r, c)
        """
        d = CG.grid[r][c]

        # Independent cells are not part of a vector:
        if CG._is_group(d):
            a = CG._get_topleft(d)

            # Cell must refer to its old top:
            if a['row'] == u[0] and a['column'] == u[1]:
                return 1

    @staticmethod
    def _merge_groups(top, origin):
        """
        Merge two groups into a new group.

        top: top-left cell
        origin: top-left cell
        """
        # Get bottom-rights:
        o_b_r = CG._calc_bottom_right(origin)
        t_b_r = CG._calc_bottom_right(top)

        # Merge group settings:
        m_pos = min(
            top['row'], origin['row']), min(top['column'], origin['column'])

        m_b_r = tuple(max(o, m) for o, m in zip(o_b_r, t_b_r))
        diff = tuple(n - m for n, m in zip(m_b_r, m_pos))
        v = diff[0] + 1, diff[1] + 1

        # Get top-left cell's dict of the merged group:
        m = CG._get_d(m_pos[0], m_pos[1])

        """
        Create a dictionary of potential slices.

        Slices are groups that are part of a merged group rectangle,
        but are exclusive of top and origin groups.

        Slices also have cells outside the bounds of the merged group.
        """
        sliced = {}

        for r in range(m_pos[0], m_pos[0] + v[0]):
            for c in range(m_pos[1], m_pos[1] + v[1]):
                d = CG.grid[r][c]
                if CG._is_group(d):
                    t = CG._get_topleft(d)
                    if t['row'] != top['row'] or t['column'] != top['column']:
                        if (
                                t['row'] != origin['row'] or
                                t['column'] != origin['column']
                                ):
                            if CG._is_outside(t, m['row'], m['column'], v):
                                key = t['row'], t['column']
                                if key not in sliced:
                                    sliced[key] = {'size': t['size']}

        CG._set_group(m, v)
        CG._generate_group(sliced)

    @staticmethod
    def _set_block_looks(start, end):
        """
        Set the appearance of a block of cells.

        start: (r, c) for the top-left cell
        end: (r, c) for the bottom-right cell
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                CG._set_cell_looks(CG._get_d(r, c), start, end)

    @staticmethod
    def _set_cell_looks(d, start, end):
        """
        Set a cell's appearance.

        d: cell dict
        start: (r, c) for the top-left cell
        end: (r, c) for the bottom-right cell
        """
        if d['size'] == (1, 1):
            CG._set_single_looks(d)

        else:
            # The cell is a member of a group:
            k = 'left_b'
            k1 = 'top_b'

            # cell neighbor flags:
            top = d['row'] > start[0]
            bottom = d['row'] < end[0]
            left = d['column'] > start[1]
            right = d['column'] < end[1]

            # top, bottom, left, right:
            w = [5, 5, 5, 5]

            for x, i in enumerate((top, bottom, left, right)):
                if i:
                    w[x] = 0

            d['pad'].set_padding(*w)
            CG._set_group_looks(d)
            if not CG.overlay:
                # button updates:
                if k in d:
                    if left:
                        w = [5, 5, 0, 0]
                        for x, i in enumerate((top, bottom)):
                            if i:
                                w[x] = 0
                        d[k].pad.alignment.set_padding(*w)
                        d[k].set_label("-")
                        d[k].gate = 1

                    else:
                        d[k].set_label("+")
                        d[k].gate = 0
                        d[k].pad.alignment.set_padding(5, 5, 0, 0)

                if k1 in d:
                    if top:
                        w = [0, 0, 5, 5]
                        for x, i in enumerate((left, right)):
                            if i:
                                w[x + 2] = 0

                        d[k1].pad.alignment.set_padding(*w)
                        d[k1].set_label("-")
                        d[k1].gate = 1

                    else:
                        d[k1].set_label("+")
                        d[k1].gate = 0
                        d[k1].pad.alignment.set_padding(0, 0, 5, 5)
        CG._update_cell_label(d)

    @staticmethod
    def _set_group(top, s):
        """
        Set a group's sub-cell's attributes and the group's appearance.

        top: a new group dict
        s: group's new dimensions
        """
        top['size'] = s
        start, end = CG._get_start_end_of_top(top)

        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                if r != top['row'] or c != top['column']:
                    CG._set_subtop(top, CG.grid[r][c])
        CG._update_block(start, end)

    @staticmethod
    def _set_group_looks(d):
        """
        Change the appearance of a cell's frame to appear merged.

        d: cell dict
        """
        d['event_box'].modify_bg(gtk.STATE_NORMAL, gtk.gdk.Color(
            54000, 54000, ForColor.MAX_COLOR))

    @staticmethod
    def _set_single_looks(d):
        """
        Change the appearance of a cell's frame to appear independent.

        d: cell dict
        """
        d['pad'].set_padding(5, 5, 5, 5)
        d['event_box'].modify_bg(
            gtk.STATE_NORMAL, gtk.gdk.Color(56000, 56000, ForColor.MAX_COLOR))

        if CG.button_clicked:
            for k in ('left_b', 'top_b'):
                d[k].set_label("+")
                d[k].gate = 0

                if k == 'left_b':
                    d[k].pad.alignment.set_padding(5, 5, 0, 0)
                if k == 'top_b':
                    d[k].pad.alignment.set_padding(0, 0, 5, 5)

    @staticmethod
    def _set_subtop(d, e):
        """
        Use when a cell is merged into a group.

        Modify the cell's dictionary to identify the cell as sub-top.

        d: the top-left cell's dict
        e: the sub-top cell's dict
        """
        e['topleft'] = d['row'], d['column']
        e['size'] = -1, -1

    @staticmethod
    def _update_block(start, end):
        """
        Update format data, cell size table,
        and the cell appearance for a block of cells.

        start: the top-left cell in the block
        end: the bottom-right cell in the block
        """
        CG._update_format(start, end)
        CG.cell.calc_block(start, end, CG.format_c.format)
        CG._set_block_looks(start, end)

    @staticmethod
    def _update_cell_label(d):
        """
        Call whenever a cell is drawn.

        Update the cell dimension labels.

        d: cell dict
        """
        if not CG.overlay:
            if CG.is_topleft(d) or d['size'] == (1, 1):
                b = CG.cell.get_cell_info(d['row'], d['column'])

                if CG.LAB_WIDTH in d:
                    for x, k in enumerate(CG.LAB_KEY_LIST):
                        d[k].label.set_text(CG.LABEL_ID[x] + str(b[x]))

                else:
                    for x, k in enumerate(CG.LAB_KEY_LIST):
                        g = d[k] = RollerLabel(CG.LABEL_ID[x] + str(b[x]))

                        d['box'].add(d[k].alignment)

                        # Need to show both:
                        g.alignment.show()
                        g.label.show()

            else:
                if CG.LAB_WIDTH in d:
                    # Delete the Labels:
                    for k in CG.LAB_KEY_LIST:
                        b = d[k]

                        d['box'].remove(b.alignment)
                        d.pop(k)
                        b.destroy()

    @staticmethod
    def _update_format(start, end):
        """
        Update the format data for a block of cells.

        start: the top-left cell in the block
        end: the bottom-right cell in the block.
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                CG.format_c.format[FormatKey.CELL_TABLE_MERGE][r][c] = \
                    CG.grid[r][c]['size']

    @staticmethod
    def connect_left(d):
        """
        Connect cells horizontally.

        d: cell dict
        """
        CG.button_clicked = True
        origin = CG._get_topleft(d=d)
        top = CG._get_topleft(u=(d['row'], d['column'] - 1))

        CG._merge_groups(top, origin)
        CG.button_clicked = False

    @staticmethod
    def connect_up(d):
        """
        Connect cells vertically.

        d: cell dict
        """
        CG.button_clicked = True
        origin = CG._get_topleft(d=d)
        top = CG._get_topleft(u=(d['row'] - 1, d['column']))
        CG._merge_groups(top, origin)
        CG.button_clicked = False

    @staticmethod
    def draw(d):
        """
        Draw a cell and its connectors.

        d: cell dict
        """
        g = CG._get_topleft(d=d)
        start, end = CG._get_start_end_of_top(g)
        CG._set_cell_looks(d, start, end)

    @staticmethod
    def is_topleft(d):
        """
        Return true if the cell is a top-left cell.

        d: cell dict
        """
        return d['size'][0] > 1 or d['size'][1] > 1

    @staticmethod
    def split_horz(d):
        """
        The user has clicked a horizontal black connector.

        Divide the group containing this connector of two columns.

        d: cell dict
        """
        CG.button_clicked = True
        c = d['column']
        top = CG._get_topleft(d=d)
        w = c - top['column']
        w1 = top['size'][1] - w
        e = CG._get_d(top['row'], top['column'] + w)

        CG._set_group(e, (top['size'][0], w1))
        CG._set_group(top, (top['size'][0], w))
        CG.button_clicked = False

    @staticmethod
    def split_vert(d):
        """
        The user has clicked a vertical black connector.

        Divide the group containing this connector of two rows.

        d: cell dict
        """
        CG.button_clicked = True
        r = d['row']
        top = CG._get_topleft(d=d)
        h = r - top['row']
        h1 = top['size'][0] - h
        e = CG._get_d(top['row'] + h, top['column'])

        # Create a new groups from the split:
        CG._set_group(e, (h1, top['size'][1]))
        CG._set_group(top, (h, top['size'][1]))
        CG.button_clicked = False
