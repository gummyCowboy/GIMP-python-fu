#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame import Noise, Overlay, do_metal_wrap
from roller_frame_build import Build
from roller_fu import (
    clone_layer,
    color_fill_selection,
    merge_layer,
    select_item,
    set_saturation
)
from roller_maya import check_matter, check_mix_wrap, make_frame_group
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_one_gegl import noise_rgb, video_degradation, waterpixels
from roller_view_real import (
    OVERLAY, LIGHT, add_wip_layer, get_light, get_noise
)
import gimpfu as fu

pdb = fu.pdb


def do_overlay(v, maya):
    """
    Make a color layer.

    v: View
    maya: Maya
    Return: layer
        with color
    """
    pdb.gimp_selection_none(v.j)

    d = maya.value_d
    a = maya.cause
    z = add_wip_layer(
        v, maya, "Overlay", maya.super_maya.group, offset=get_light(a)
    )
    noise = int(d[ok.SEED] + v.glow_ball.seed)

    for i in range(3):
        q = ff.COMPONENT[d[ok.CAMO_TYPE]] + (noise + i,)
        noise_rgb(z, *q)

    waterpixels(z)
    pdb.gimp_brightness_contrast(z, 0, 75)
    set_saturation(z, d[ok.SATURATION])
    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: Frame
    Return: layer
        with the frame material
    """
    z = do_metal_wrap(v, maya)
    z = clone_layer(z)

    select_item(z)
    color_fill_selection(z, (127, 127, 127))
    video_degradation(z, 'dots')

    pdb.gimp_drawable_curves_spline(
        z,
        0,                          # HISTOGRAM_VALUE, '0'
        4,                          # four coordinates
        (.0, .2, 1., .8)
    )

    z.mode = fu.LAYER_MODE_HARDLIGHT
    z.opacity = 65.
    return merge_layer(z)


class CamoPlanet(Build):
    """Is a metallic frame with a water pixel overlay."""
    is_seeded = is_embossed = True
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Option key,)
            Is the key path to the responsible Frame Button.
        """
        Build.__init__(
            self, any_group, super_maya, k_path + (ok.WRW, ok.WRAP), do_matter
        )

        self.sub_maya[OVERLAY] = Overlay(
            any_group, self, k_path + (ok.WRW, ok.OVERLAY_CP), do_overlay
        )
        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.SRW, ok.NOISE_D)
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cause, self)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Camo Planet Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[OVERLAY].do(
            v, d[ok.WRW][ok.OVERLAY_CP], is_change, self.is_matter
        )
        self.sub_maya[ok.NOISE_D].do(
            v, d[ok.SRW][ok.NOISE_D], is_change, self.is_matter
        )

        is_back = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], self.is_matter, is_change
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)

        z = self.sub_maya[OVERLAY].matter

        if z:
            a = get_light(self) + get_noise(self)
            pdb.gimp_image_reorder_item(v.j, z, self.group, a)

        self.reset_issue()
        return is_back
