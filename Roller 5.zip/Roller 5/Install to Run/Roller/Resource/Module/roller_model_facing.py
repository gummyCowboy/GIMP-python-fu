#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Facing:
    """
    A Face or Facing navigation branch has a 'map' dict
    for recalling an item's different configurations.
    """

    def __init__(self):
        # Each Face or Facing in the Model has its own Goo.
        # {(row, column, face): Goo}
        self.map_d = None

    def get_facing_foam(self, k):
        return self.map_d[k].foam

    def get_facing_form(self, k):
        return self.map_d[k].form

    def get_facing_merged(self, k):
        return self.map_d[k].merged.clone()

    def get_facing_rect(self, k):
        return self.map_d[k].merged.rect

    def get_facing_shape(self, k):
        return self.map_d[k].shape

    def get_facing_transform(self, k):
        return self.map_d[k].transform
