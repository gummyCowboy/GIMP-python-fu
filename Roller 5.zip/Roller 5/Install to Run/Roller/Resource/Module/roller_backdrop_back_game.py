#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    color_fill_selection,
    desaturate,
    merge_layer_group,
    select_polygon,
    set_layer_mode
)
from roller_maya_style import Style, make_background
from roller_fu_mode import translate_mode
from roller_view_real import finish_style
from roller_view_hub import invert_color
from roller_view_real import add_wip_layer, make_layer_group
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a style layer.

    v: View
    maya: Style
    Return: layer or None
        Style layer
    """
    j = v.j
    d = maya.value_d
    back_z = make_background(v, maya, d)
    group = make_layer_group(j, "WIP", parent=maya.group, z=back_z)
    column = int(d[ok.COLUMN])

    # Preserve.
    foreground = pdb.gimp_context_get_foreground()

    # x-vector coordinate list, 'q_x'
    # Begin calculating 'q_x' for vertical triangle polygon drawing.
    x, y, canvas_w, h = v.wip.rect
    y1 = y + h
    w = canvas_w / (.5 + column * .5)
    q_x = []
    w /= 2.
    x -= w

    # remainder total, 'f_x'
    f_x = .0

    for c in range(column + 5):
        x, f = divmod(x, 1.)
        f_x += f

        if f_x >= .999:
            x += 1.
            f_x -= 1.

        q_x += [x]
        x += w

    # first color
    pdb.gimp_selection_none(j)

    z = add_wip_layer(v, maya, "Color 1", group=group)

    for c in range(0, column + 2, 2):
        select_polygon(
            j,
            (q_x[c], y1, q_x[c + 1], y, q_x[c + 2], y1),
            option=fu.CHANNEL_OP_ADD
        )

    q = d[ok.COLOR_2A][0]

    if d[ok.IDR][ok.INVERT]:
        q = invert_color(q)

    set_layer_mode(z, translate_mode(d[ok.COLOR_1_MODE]))
    color_fill_selection(z, q)

    a = d[ok.BLUR_BEHIND_COLOR_1]

    if a:
        blur_selection(back_z, a)

    # second color
    pdb.gimp_selection_none(j)

    z = add_wip_layer(v, maya, "Color 2", group=group)

    for c in range(0, column + 2, 2):
        select_polygon(
            j,
            (q_x[c + 1], y, q_x[c + 2], y1, q_x[c + 3], y),
            option=fu.CHANNEL_OP_ADD
        )

    q = d[ok.COLOR_2A][1]

    if d[ok.IDR][ok.INVERT]:
        q = invert_color(q)

    set_layer_mode(z, translate_mode(d[ok.COLOR_2_MODE]))
    color_fill_selection(z, q)

    a = d[ok.BLUR_BEHIND_COLOR_2]

    if a:
        blur_selection(back_z, a)

    # Restore.
    pdb.gimp_context_set_foreground(foreground)

    z = merge_layer_group(group)

    if d[ok.IDR][ok.DESATURATE]:
        desaturate(z)
    return finish_style(z, "Back Game")


class BackGame(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BRW][ok.BACKGROUND][ok.TYPE] == bs.BACKDROP_IMAGE
        super(BackGame, self).do(v, d, is_change)
