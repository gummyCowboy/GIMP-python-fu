#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_fu import (
    add_layer,
    copy_all_image,
    create_image,
    invert_and_desaturate,
    paste_layer_into
)
from roller_one_the import The
from roller_view_hub import do_gradient_job
import gimpfu as fu

pdb = fu.pdb


def create_gradient(v, maya):
    """
    Create a Gradient Light image. The image is hidden from
    the user and is removed when Roller closes or by an
    GradientLight change operation. Gradient Light layers are
    created from the image using a copy visible image function.

    v: View
    maya: Maya
    """
    reset_gradient()

    d = maya.value_d
    d[ok.GRADIENT] = d[ok.IGR][ok.GRADIENT]
    w, h = The.view.wip.size
    j = GradientLight.image = create_image(int(w), int(h))

    do_gradient_job(add_layer(j, "Process"), d)
    invert_and_desaturate(d[ok.IRR], j.layers[0])


def insert_gradient(group):
    """
    Paste a Gradient Light layer at the top of a layer group.

    group: layer group or None for a GIMP image
        output destination

    Return: layer
        the original or its alter
    """
    copy_all_image(GradientLight.image)
    return paste_layer_into(group, group.name + " Gradient Light")


def reset_gradient():
    if GradientLight.image:
        pdb.gimp_image_delete(GradientLight.image)
        GradientLight.image = None


class GradientLight:
    """Remember Gradient Light image."""
    image = None
