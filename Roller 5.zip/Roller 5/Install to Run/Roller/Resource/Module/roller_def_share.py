#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import (
    MAX_SIZE,
    BackdropStyle as bs,
    Bump as fb,
    Caption as pt,
    Frame as ff,
    Fill as fl,
    Gradient as fg,
    GradientLight as gl,
    Grid as gr,
    Justification as ju,
    Image as fi,
    Mask as ms,
    Resize as fz,
    Shape as sh,
    Issue as vo
)
from roller_constant_key import (
    Button as bk,
    Frame as ek,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_fu_comm import show_err
from roller_fu_mode import Mode
from roller_one_extract import scour
from roller_one_image import Image as ig
from roller_one_the import The, get_factor_h, get_factor_w
from roller_one_tip import Tip
from roller_port_choice import PortChoice
from roller_port_generic import (
    PortBackground,
    PortBlurBehind,
    PortBrush,
    PortBump,
    PortCamoPlanetOverlay,
    PortCeramicChipFiller,
    PortCirclePunchFiller,
    PortClearFrameWrap,
    PortColorBoardWrap,
    PortColorOverlay,
    PortColorPipeWrap,
    PortCrumbleShellWrap,
    PortCutoutPlateOverlay,
    PortCutoutPlateWrap,
    PortFrameOverOverlay,
    PortLineFashionFiller,
    PortLinkMirrorFiller,
    PortMargin,
    PortNailPolishOverlay,
    PortNailPolishWrap,
    PortNoise,
    PortRadWaveFiller,
    PortRaisedMazeFiller,
    PortResize,
    PortShadowBasic,
    PortSquareCutFiller,
    PortSquarePunchFiller,
    PortStainedGlassFiller,
    PortStencil,
    PortStretchTrayFiller,
    PortStripe,
    PortTape,
    PortWireFrameFiller,
    PortWrap
)
from roller_port_option_list import PortFrame
from roller_port_image_choice import PortImageChoice
from roller_port_influence import PortInfluence
from roller_port_mask import PortMask
from roller_port_shadow import PortShadow
from roller_widget_button import (
    ColorButton,
    FileButton,
    FolderButton,
    RandomButton,
    RandomColorButton
)
from roller_widget_check_button import CheckButton, CheckButtonRandom
from roller_widget_combo import CaptionComboBox, ComboBox
from roller_widget_entry import Entry
from roller_widget_influence import InfluenceRow
from roller_widget_label import (
    CoverLabel,
    FilledLabel,
    LockedLabel,
    ModelTypeLabel,
    NextXLabel,
    PreviousXLabel,
    TrimLabel
)
from roller_widget_number_pair import CanvasPair, RectPair, RenderPair
from roller_widget_option_button import (
    InfluenceButton,
    ListButton,
    OptionButton,
    OptionListButton
)
from roller_widget_per import PerGroup
from roller_widget_slider import RandomSlider, Slider
from roller_widget_radio import RadioRandomColumn, SwitchRadio
from roller_widget_row import Rainbow, WidgetRow
import glob
import gtk
import os

MAX_TAB = 7
NO_MATTER = (
    ok.BLUR_BEHIND,
    ok.MODE,
    ok.OPACITY,
    ok.NOISE_D,
    ok.PER,
    ok.SHADOW
)
screen_w, screen_h = gtk.gdk.screen_width(), gtk.gdk.screen_height()


def get_cell_shape_list():
    """
    Use to replace the list with a function
    call in order to reduce memory consumption.
    """
    return sh.CELL_SHAPE_LIST


def get_criterion_list():
    return fl.CRITERION_LIST


def get_backdrop_type_list():
    return bs.BACKDROP_TYPE


def get_brush_list():
    """
    Return: list
        of available GIMP brush
    """
    return The.cat.brush_list


def get_bump_type_list():
    return fb.TYPE


def get_camo_type_list():
    return ff.CAMO_TYPE


def get_corner_type_list():
    return ms.CORNER_TYPE_Q


def get_frame_list():
    """
    Make a list of frame file for Frame Over.

    Return: list
        of GIMP-opened image name
    """
    files = []
    frame_list = ["None"]
    go = False

    try:
        # Ignore sub-directories.
        files = glob.glob(The.frame_path + os.path.sep + "*.png")
        go = True

    except Exception as ex:
        show_err(ex)
        show_err("Roller was unable to load frame images.")
    if go:
        for i in files:
            frame_list += [os.path.splitext(os.path.basename(i))[0]]
    return frame_list


def get_frame_style_list():
    return ff.OVERLAY_TYPE


def get_gradient_angle_list():
    return fg.GRADIENT_ANGLE


def get_gradient_list():
    """
    Return: list
        of available GIMP gradient
    """
    return The.cat.gradient_list


def get_gradient_type_list():
    return fg.GRADIENT_TYPE_LIST


def get_grid_type_list():
    return gr.TYPE_LIST


def get_hexagon_type_list():
    return ms.HEXAGON_TYPE_Q


def get_image_name_list():
    return ig.image_name_list


def get_image_source_list():
    return fi.IMAGE_SOURCE_LIST


def get_justification_type():
    return ju.TYPE


def get_mask_list():
    return ms.TYPE


def get_mesh_type_list():
    return bs.MESH_TYPE


def get_noise_list():
    return ff.NOISE_TYPE


def get_mode_name_list():
    return Mode.q


def get_nail_polish_list():
    return ff.NAIL_POLISH


def get_numeric_ref_list():
    return ig.numeric_ref_list


def get_octagon_type_list():
    return ms.OCTAGON_TYPE_Q


def get_pattern_list():
    """
    Return: list
        [pattern, ...]
    """
    return The.cat.pattern_list


def get_pin_list():
    return gr.PIN_LIST


def get_profile_list():
    return ff.PROFILE


def get_rectangle_type_list():
    return ms.RECTANGLE_TYPE_Q


def get_resize_type_list():
    return fz.RESIZE_TYPE_LIST


def get_tip_format(i, indent):
    """
    Make two strings for formatting a dynamic tooltip.

    i: string
        option key

    indent: int
        for formatting tab

    Return: tuple
        (string, string)
        (prefix, postfix)
    """
    a = (MAX_TAB, MAX_TAB + 2)[indent >= 4]
    a = a - len(i) // 4 - indent

    return (
        '\t' * indent if indent else " ",
        '\t' * max(1, int(a))
    )


def get_triangle_type_list():
    return ms.TRIANGLE_TYPE_Q


def get_wrap_types():
    return ff.WRAP_TYPE_Q


def make_bool_tip(d, i, indent, _):
    """
    Make a tooltip for an option value that is boolean.

    d: dict
        option group Preset

    i: string
        option key

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    n, n1 = get_tip_format(i, indent)
    return n + i + n1 + '{} '.format(bool(d[i]))


def make_influence_tip(d):
    """
    Make a tooltip for the Influence OptionButton.

    d: dict
        Influence Preset
        {Option key: value}

    q: list
        ordered group key

    Return: string
        formatted for option
    """
    n = " Influence \n"

    for i in gl.INFLUENCE_KEY:
        a = d[i]
        if isinstance(a, dict):
            n += '\t' + i + " \n"
            n1, n2 = get_tip_format("Mode", 2)

            # Mode, '0'
            n += n1 + "Mode" + n2 + "{} \n".format(a[ok.MODE])

            n1, n2 = get_tip_format("Opacity", 2)

            # Opacity '1'
            n += n1 + "Opacity" + n2 + "{} \n".format(a[ok.OPACITY])

    # Remove the last carriage return.
    n = n[:-2]
    return n


def make_radio_tip(d, i, indent, e):
    """
    Make a tooltip for an option that has two RadioButton.

    d: dict
        option group Preset

    i: string
        option key

    indent: int
        for formatting tab

    e: dict
        option init

    Return: string
        formatted for option
    """
    n, n1 = get_tip_format(i, indent)
    return n + i + n1 + '{} '.format(e[wk.TEXT][int(d[i])])


def make_rainbow_count_tip(d, i, indent, _):
    """
    Translate multi-line text into a tooltip.

    d: dict
        option group Preset

    i: string
        option key

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    i1 = i.split(",")[0]
    n, n1 = get_tip_format(i1, indent)
    n2, n3 = get_tip_format(i1, indent + 1)
    tip = n + i1 + n1

    for x in range(int(d[ok.COLOR_COUNT])):
        tip += ' \n'
        tip += n2 + str(d[i][x]) + n3
    return tip


def make_rainbow_tip(d, i, indent, _):
    """
    The Rainbow Widget has a multiline tooltip and
    changes visible Widget with the number of colors.

    d: dict
        option group Preset

    i: string
        option key

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    i1 = i.split(",")[0]
    n, n1 = get_tip_format(i1, indent)
    n2, n3 = get_tip_format(i1, indent + 1)
    tip = n + i1 + n1

    for x, i1 in enumerate(d[i]):
        tip += ' \n'
        tip += n2 + str(i1) + n3
    return tip


def make_slider_tip(d, i, indent, _):
    """
    Make a tooltip for an View size factored slider option value.

    d: dict
        option group Preset

    i: string
        option key

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    i1 = i.split(",")[0]
    a = get_factor_w(d[i]) \
        if i in (ok.END_X, ok.START_X, ok.LEFT, ok.RIGHT) \
        else get_factor_h(d[i])
    n, n1 = get_tip_format(i1, indent)
    return n + i1 + n1 + '{} '.format(a)


def make_text_tip(d, i, indent, _):
    """
    Make a tooltip for an option value that is translated as text.

    d: dict
        option group Preset

    i: string
        option key

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    i1 = i.split(",")[0]
    n, n1 = get_tip_format(i1, indent)
    a = d[i]

    if isinstance(a, float) and a == round(a):
        a = int(a)
    return n + i1 + n1 + '{} '.format(a)


def set_issue(d, keys, issue, no_vote):
    """
    Recursively peruse a group definition dict setting an
    issue value into the group's sub-option dict.

    d: dict
        Is initially a Preset, but could also be a sub-Preset dict
        in a recursive call.

    keys: iterable
        of Option key
        Create an exclusive voter roll or leave empty
        to allow all the Widget to receive the issue.

    issue: string or tuple
        Maya check issue, flags, for layer production.

    no_vote: iterable
        of Option key
        Use to filter out unwanted vote recipient.
    """
    if isinstance(issue, tuple):
        for i in issue:
            set_issue(d, keys, i, no_vote)
    for i, a in d.items():
        if isinstance(a, dict):
            if wk.VAL in a:
                if (not keys or i in keys) and i not in no_vote:
                    a[wk.ISSUE] = issue
            else:
                if i not in no_vote:
                    set_issue(a, keys, issue, no_vote)


ANGLE = {
    wk.LIMIT: (-359., 359.),
    wk.PRECISION: 2,
    wk.RANDOM_Q: (-359., 359.),
    wk.STEP_INCR: .1,
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
ANGLE_JITTER = {
    wk.LIMIT: (.0, 180.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 180.),
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
BLUR = {
    wk.LIMIT: (.0, 500.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 50.),
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
BLOCK_W = {
    wk.AXIS: 'x',
    wk.LIMIT: (0, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.VAL: (0, .2),
    wk.WIDGET: RectPair
}
BLOCK_H = {
    wk.AXIS: 'y',
    wk.LIMIT: (0, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.VAL: (0, .2),
    wk.WIDGET: RectPair
}
BLUR_XY = {
    wk.LIMIT: (1., 100.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (3., 20.),
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
BRUSH = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortChoice,
    wk.FUNCTION: get_brush_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: "C_Normal Brush 80",
    wk.WIDGET: ListButton
}
BRUSH_SIZE = {
    wk.LIMIT: (10, 9999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (25, 125),
    wk.TIPPER: make_text_tip,
    wk.VAL: 100.,
    wk.WIDGET: RandomSlider
}
BRUSH_SPACING = {
    wk.LIMIT: (10., 5000.),
    wk.PAGE_INCR: 10,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (25., 125.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 100.,
    wk.WIDGET: RandomSlider
}
CAPTION_TYPE = {
    wk.TIPPER: make_text_tip,
    wk.VAL: pt.TEXT,
    wk.WIDGET: CaptionComboBox
}
CELL_SHAPE_CELL = {
    wk.FUNCTION: get_cell_shape_list,
    wk.ISSUE: vo.MATTER,
    wk.VAL: sh.RECTANGLE,
    wk.WIDGET: ComboBox
}
CELL_SIZE = {
    wk.LIMIT: (1, MAX_SIZE),
    wk.PAGE_INCR: 100,
    wk.TOOLTIP: Tip.GRID_FIXED_SIZE,
    wk.VAL: 250.,
    wk.WIDGET: Slider
}
CLIP = {
    wk.LIMIT: (6, 1024),
    wk.RANDOM_Q: (108, 1024),
    wk.TIPPER: make_text_tip,
    wk.VAL: 512.,
    wk.WIDGET: RandomSlider
}
CLIP_TO_CELL = {
    wk.TIPPER: make_bool_tip,
    wk.TOOLTIP: Tip.CLIP_TO_CELL,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
COLOR_1 = {
    wk.TIPPER: make_text_tip,
    wk.VAL: (0, 0, 0),
    wk.WIDGET: RandomColorButton
}
COLOR_2A = {
    wk.BUTTON_COUNT: 2,
    wk.HAS_ALPHA: True,
    wk.TIPPER: make_rainbow_tip,
    wk.VAL: ((64, 64, 64, 255), (187, 187, 187, 255)),
    wk.WIDGET: Rainbow
}
CONTRACT = {
    wk.LIMIT: (0, 9999),
    wk.PAGE_INCR: 50,
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.CONTRACT,
    wk.VAL: .0,
    wk.WIDGET: Slider
}
CONTRAST = {
    wk.LIMIT: (-127, 127),
    wk.RANDOM_Q: (-127, 127),
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
CRITERION = {
    wk.FUNCTION: get_criterion_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: fl.COMPOSITE,
    wk.WIDGET: ComboBox
}
CROP_XY = {
    wk.LIMIT: (0, MAX_SIZE),
    wk.PAGE_INCR: 10,
    wk.TIPPER: make_slider_tip,
    wk.VAL: .0,
    wk.WIDGET: Slider
}
DECO_TYPE = {
    wk.TIPPER: make_text_tip,
    wk.VAL: "",
    wk.WIDGET: ComboBox
}
DESATURATE = {
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
EMBOSS = {
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButtonRandom
}
END_X = {
    wk.AXIS: 'x',
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.END_X,),
    wk.VAL: (0, 1.),
    wk.WIDGET: CanvasPair
}
END_Y = {
    wk.AXIS: 'y',
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.END_Y,),
    wk.VAL: (0, 1.),
    wk.WIDGET: CanvasPair
}
FACTOR_SIZE = {
    wk.LIMIT: (.0, 2.),
    wk.PRECISION: 6,
    wk.STEP_INCR: .01,
    wk.TIPPER: make_text_tip,
    wk.VAL: 1.,
    wk.WIDGET: Slider,
}
FCI = {
    wk.TOOLTIP: Tip.FCI,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
FEATHER = {
    wk.LIMIT: (0, 1000),
    wk.PAGE_INCR: 50,
    wk.RANDOM_Q: (50, 300),
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.FEATHER,
    wk.VAL: 200.,
    wk.WIDGET: RandomSlider
}
FILL_MODE = {
    wk.FUNCTION: get_mode_name_list,
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.FILL_MODE,
    wk.VAL: "Normal",
    wk.WIDGET: ComboBox
}
FIXED_SIZE = {
    wk.LIMIT: (1, MAX_SIZE),
    wk.PAGE_INCR: 100,
    wk.TIPPER: make_text_tip,
    wk.VAL: 200.,
    wk.WIDGET: Slider
}
FLIP = {
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
FONT = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortChoice,
    wk.TIPPER: make_text_tip,
    wk.VAL: "Tahoma",
    wk.WIDGET: ListButton
}
FONT_SIZE = {
    wk.LIMIT: (4, 999),
    wk.PAGE_INCR: 10,
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.FONT_SIZE,
    wk.VAL: 24.,
    wk.WIDGET: Slider
}
FRAME_W = {
    wk.LIMIT: (1, 999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (1., 50.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 6.,
    wk.WIDGET: RandomSlider
}
GAP_W = {
    # Is limited by GIMP's clipboard to
    # pattern function where the maximum side
    # dimension for the clipboard is 1024.
    wk.LIMIT: (1, 512),

    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (12, 100),
    wk.TIPPER: make_text_tip,
    wk.VAL: 24.,
    wk.WIDGET: RandomSlider
}
GRADIENT = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortChoice,
    wk.FUNCTION: get_gradient_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: "Default",
    wk.WIDGET: ListButton
}
GRADIENT_ANGLE = {
    wk.FUNCTION: get_gradient_angle_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: fg.TOP_CENTER_TO_BOTTOM_CENTER,
    wk.WIDGET: ComboBox
}
GRADIENT_END_X = {
    wk.AXIS: 'x',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.END_X,),
    wk.VAL: (0, 1.),
    wk.WIDGET: RectPair
}
GRADIENT_END_Y = {
    wk.AXIS: 'y',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.END_Y,),
    wk.VAL: (0, 1.),
    wk.WIDGET: RectPair
}
GRADIENT_START_X = {
    wk.AXIS: 'x',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.START_X,),
    wk.VAL: (0, .0),
    wk.WIDGET: RectPair
}
GRADIENT_START_Y = {
    wk.AXIS: 'y',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.START_Y,),
    wk.VAL: (0, .0),
    wk.WIDGET: RectPair
}
GRADIENT_TYPE = {
    wk.FUNCTION: get_gradient_type_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: fg.LINEAR,
    wk.WIDGET: ComboBox
}
GRID_COUNT = {
    wk.LIMIT: (1, 100),
    wk.PAGE_INCR: 2,
    wk.VAL: 1.,
    wk.WIDGET: Slider
}
GRID_SIZE = {
    wk.VAL: "",
    wk.WIDGET: ModelTypeLabel
}
GRID_TYPE = {
    wk.FUNCTION: get_grid_type_list,
    wk.VAL: gr.CELL_COUNT,
    wk.WIDGET: ComboBox
}
INTENSITY = {
    wk.LIMIT: (0, 1000),
    wk.PAGE_INCR: 25,
    wk.RANDOM_Q: (50, 200),
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.INTENSITY,
    wk.VAL: 0.,
    wk.WIDGET: RandomSlider
}
INVERT = {
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButtonRandom
}
JUSTIFICATION = {
    wk.FUNCTION: get_justification_type,
    wk.TIPPER: make_text_tip,
    wk.VAL: ju.CENTER,
    wk.WIDGET: ComboBox
}
KEEP_GRADIENT = {
    wk.TOOLTIP: Tip.KEEP_GRADIENT,
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
LINE_W = {
    # Is limited by GIMP's clipboard to
    # pattern function where the maximum side
    # dimension for the clipboard is 1024.
    wk.LIMIT: (1, 512),

    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (1, 30),
    wk.TIPPER: make_text_tip,
    wk.VAL: 6.,
    wk.WIDGET: RandomSlider
}
MESH_SIZE = {
    wk.LIMIT: (8, 1000),
    wk.RANDOM_Q: (25, 100),
    wk.TIPPER: make_text_tip,
    wk.VAL: 50.,
    wk.WIDGET: RandomSlider
}
MAX_POLAR = {
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.VAL: 0.,
    wk.WIDGET: RenderPair
}
MAX_POSITIVE = {
    wk.LIMIT: (0, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.VAL: 0.,
    wk.WIDGET: RenderPair
}
MESH_TYPE = {
    wk.FUNCTION: get_mesh_type_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: bs.SQUARE,
    wk.WIDGET: ComboBox
}
MASK_SCALE = {
    wk.LIMIT: (.001, 1.),
    wk.PRECISION: 3,
    wk.STEP_INCR: .01,
    wk.TIPPER: make_text_tip,
    wk.VAL: 1.,
    wk.WIDGET: Slider
}
MODE = {
    wk.FUNCTION: get_mode_name_list,
    wk.ISSUE: vo.MODE,
    wk.TIPPER: make_text_tip,
    wk.VAL: "Normal",
    wk.WIDGET: ComboBox
}
NEATNESS = {
    wk.LIMIT: (.0, 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.0, 1.),
    wk.STEP_INCR: .01,
    wk.TIPPER: make_text_tip,
    wk.VAL: 1.,
    wk.WIDGET: RandomSlider
}
NET_LINE = {
    wk.LIMIT: (1, 9999),
    wk.PAGE_INCR: 10,
    wk.TIPPER: make_text_tip,
    wk.VAL: 6.,
    wk.WIDGET: Slider
}
NOISE_AMOUNT = {
    wk.LIMIT: (1, 15),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (1, 15),
    wk.TIPPER: make_text_tip,
    wk.VAL: 2.,
    wk.WIDGET: RandomSlider
}
OBEY_MARGINS = {
    wk.TOOLTIP: Tip.OBEY_MARGINS,
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
OFFSET = {
    wk.LIMIT: (0, 9999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (0, 20),
    wk.TIPPER: make_text_tip,
    wk.VAL: 0.,
    wk.WIDGET: RandomSlider
}
OFFSET_XY = {
    wk.LIMIT: (-4096, 4096),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (-30, 30),
    wk.TIPPER: make_text_tip,
    wk.VAL: 0.,
    wk.WIDGET: RandomSlider
}
OPACITY = {
    wk.ISSUE: (vo.OPACITY, vo.SHADE),
    wk.LIMIT: (.0, 100.),
    wk.PAGE_INCR: 10.,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 100.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 100.,
    wk.WIDGET: RandomSlider
}
PATTERN = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortChoice,
    wk.FUNCTION: get_pattern_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: "Pine",
    wk.WIDGET: ListButton
}
PER = {
    wk.ISSUE: vo.PER,
    wk.VAL: {},
    wk.WIDGET: PerGroup
}
PIN = {
    wk.FUNCTION: get_pin_list,
    wk.VAL: gr.CENTER,
    wk.WIDGET: ComboBox
}
PROFILE = {
    wk.FUNCTION: get_profile_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: ff.BAND,
    wk.WIDGET: ComboBox
}
R_C = {
    wk.LIMIT: (1, 999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (1, 50),
    wk.TIPPER: make_text_tip,
    wk.VAL: 5.,
    wk.WIDGET: RandomSlider
}
RANDOM = {wk.WIDGET: RandomButton}
RANDOM_ORDER = {
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButtonRandom
}
REVERSE = {
    wk.TOOLTIP: Tip.REVERSE,
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButtonRandom
}
HSL = {
    wk.LIMIT: (-100., 100.),
    wk.PAGE_INCR: 10.,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (-100., 100.),
    wk.STEP_INCR: 1.,
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
SEED = {
    wk.LIMIT: (0, 99999),
    wk.RANDOM_Q: (0, 99999),
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.SEED,
    wk.VAL: 0.,
    wk.WIDGET: RandomSlider
}
SHADOW_BLUR = {
    wk.LIMIT: (.0, 500.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 40.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 15.,
    wk.WIDGET: RandomSlider
}
SHADOW_COLOR = {
    wk.TIPPER: make_text_tip,
    wk.VAL: (0, 0, 0),
    wk.WIDGET: ColorButton
}
SPECK_NOISE = {
    wk.LIMIT: (.05, 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.05, 1.),
    wk.STEP_INCR: .01,
    wk.TIPPER: make_text_tip,
    wk.VAL: .22,
    wk.WIDGET: RandomSlider
}
START_X = {
    wk.AXIS: 'x',
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.START_X,),
    wk.VAL: (0, .0),
    wk.WIDGET: CanvasPair
}
START_Y = {
    wk.AXIS: 'y',
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.START_Y,),
    wk.VAL: (0, .0),
    wk.WIDGET: CanvasPair
}
STEPS = {
    wk.LIMIT: (1, 50),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (1, 12),
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.STEPS,
    wk.VAL: 6.,
    wk.WIDGET: RandomSlider
}
SUPERPIXEL_SIZE = {
    wk.LIMIT: (8, 256),
    wk.RANDOM_Q: (8, 256),
    wk.TIPPER: make_text_tip,
    wk.VAL: 32.,
    wk.WIDGET: RandomSlider
}
SWITCH = {
    wk.COLUMN_TEXT: ok.SWITCH,
    wk.TEXT: ("Off", "On"),
    wk.VAL: 0,
    wk.WIDGET: SwitchRadio
}
TEXT = {
    wk.CHARS: 15,
    wk.TIPPER: make_text_tip,
    wk.VAL: "",
    wk.WIDGET: Entry
}
THRESHOLD = {
    wk.LIMIT: (.0, 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.33, 1.),
    wk.STEP_INCR: .01,
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.THRESHOLD,
    wk.VAL: 1.,
    wk.WIDGET: RandomSlider
}
WAVE_AMPLITUDE = {
    wk.LIMIT: (.0, 100.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 11.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 4.,
    wk.WIDGET: RandomSlider
}
WAVELENGTH = {
    wk.LIMIT: (.5, 50.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (10., 50.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 16.,
    wk.WIDGET: RandomSlider
}
WIDTH = {
    wk.LIMIT: (3, 9999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (3, 100),
    wk.TIPPER: make_text_tip,
    wk.VAL: 30,
    wk.WIDGET: RandomSlider
}
WRAP_TYPE = {
    wk.FUNCTION: get_wrap_types,
    wk.TIPPER: make_text_tip,
    wk.VAL: ff.RECTANGLE,
    wk.WIDGET: ComboBox
}
CFW = deepcopy(FRAME_W)
CFW[wk.LIMIT] = 0, 999
CFW[wk.VAL] = 0.
CROP_X = deepcopy(CROP_XY)
CROP_Y = deepcopy(CROP_XY)
GRADIENT_MODE = deepcopy(MODE)
MARGIN_X = deepcopy(MAX_POSITIVE)
MARGIN_Y = deepcopy(MAX_POSITIVE)
NOISE_OPACITY = deepcopy(OPACITY)
NOISE_OPACITY[wk.VAL] = 30.
OVERLAY_MODE = deepcopy(MODE)
OVERLAY_MODE[wk.VAL] = "Overlay"

CROP_X.update({wk.TOOLTIP: Tip.CROP_X})
MARGIN_X.update({wk.AXIS: 'x'})
MARGIN_Y.update({wk.AXIS: 'y'})

# Blur Behind__________________________________________________________________
BLUR_BEHIND = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBlurBehind,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BLUR, deepcopy(BLUR)),
        (ok.LIGHTNESS, deepcopy(HSL)),
        (ok.OPAQUE, {
            wk.TOOLTIP: Tip.OPAQUE,
            wk.TIPPER: make_bool_tip,
            wk.VAL: 0,
            wk.WIDGET: CheckButton
        })
    ]),
    wk.WIDGET: OptionButton
}

set_issue(BLUR_BEHIND[wk.SUB], (), vo.BLUR_BEHIND, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Bump_________________________________________________________________________
BUMP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBump,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, {
            wk.FUNCTION: get_bump_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: fb.CLOTH,
            wk.WIDGET: ComboBox
        }),
        (ok.MODE, deepcopy(OVERLAY_MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BLUR_X, deepcopy(BLUR_XY)),
        (ok.BLUR_Y, deepcopy(BLUR_XY)),
        (ok.NOISE, deepcopy(SPECK_NOISE)),
        (ok.BUMP_DEPTH, {
            wk.LIMIT: (1, 100),
            wk.RANDOM_Q: (1, 4),
            wk.TIPPER: make_text_tip,
            wk.VAL: 1.,
            wk.WIDGET: RandomSlider
        }),
        (ok.INVERT, deepcopy(INVERT))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(BUMP[wk.SUB], None, vo.MATTER, NO_MATTER)

a = BUMP[wk.SUB]
a[ok.BLUR_X][wk.VAL] = 48.
a[ok.BLUR_Y][wk.VAL] = 6.
BUMP[wk.SUB][ok.TYPE][wk.VAL] = fb.NOISE

BUMP[wk.SUB][ok.NOISE].update({wk.LIMIT: (.0, 1.), wk.VAL: .075})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Row__________________________________________________________________________
BRR = {
    wk.SUB: OrderedDict([
        (ok.BUMP, deepcopy(BUMP)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}
CER = {
    wk.SUB: OrderedDict([
        (ok.COLORIZE, {
            wk.TIPPER: make_bool_tip,
            wk.VAL: 0,
            wk.WIDGET: CheckButtonRandom
        }),
        (ok.EMBOSS, deepcopy(EMBOSS)),
    ]),
    wk.WIDGET: WidgetRow
}
FCR = {
    wk.SUB: OrderedDict([
        (ok.FONT, deepcopy(FONT)),
        (ok.COLOR_1, deepcopy(COLOR_1))
    ]),
    wk.WIDGET: WidgetRow
}
FCR[wk.SUB][ok.COLOR_1][wk.VAL] = 0, 0, 0
FLIP_R = {
    wk.SUB: OrderedDict([
        (ok.FLIP_H, deepcopy(FLIP)),
        (ok.FLIP_V, deepcopy(FLIP))
    ]),
    wk.WIDGET: WidgetRow
}
GBR = {
    wk.SUB: OrderedDict([
        (ok.GRADIENT, deepcopy(GRADIENT)),
        (ok.BUMP, deepcopy(BUMP)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}
GRR = {
    wk.SUB: OrderedDict([
        (ok.GRADIENT, deepcopy(GRADIENT)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}
IDT = {
    wk.SUB: OrderedDict([
        (ok.INVERT, deepcopy(INVERT)),
        (ok.DESATURATE, deepcopy(DESATURATE)),
        (ok.TEXTURE, {
            wk.TIPPER: make_text_tip,
            wk.VAL: 0,
            wk.WIDGET: CheckButtonRandom
        })
    ]),
    wk.WIDGET: WidgetRow
}
IDR = {
    wk.SUB: OrderedDict([
        (ok.INVERT, deepcopy(INVERT)),
        (ok.DESATURATE, deepcopy(DESATURATE)),
    ]),
    wk.WIDGET: WidgetRow
}
IRR = {
    wk.SUB: OrderedDict([
        (ok.INVERT, deepcopy(INVERT)),
        (ok.DESATURATE, deepcopy(DESATURATE)),
        (ok.REVERSE, deepcopy(REVERSE))
    ]),
    wk.WIDGET: WidgetRow
}

# Lead / Trail Row_____________________________________________________________
LTR = {
    wk.COLUMN_TEXT: "Lead / Trail Text",
    wk.SUB: OrderedDict([
        (ok.LEAD, deepcopy(TEXT)),
        (ok.TRAIL, deepcopy(TEXT)),
    ]),
    wk.WIDGET: WidgetRow
}
LTR[wk.SUB][ok.LEAD][wk.TOOLTIP] = Tip.LEAD
LTR[wk.SUB][ok.TRAIL][wk.TOOLTIP] = Tip.TRAIL
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

IDF = {
    wk.SUB: OrderedDict([
        (ok.INVERT, deepcopy(INVERT)),
        (ok.DESATURATE, deepcopy(DESATURATE)),
        (ok.FLIP_V, deepcopy(FLIP))
    ]),
    wk.WIDGET: WidgetRow
}
IFR = {
    wk.SUB: OrderedDict([
        (ok.FLIP_V, deepcopy(FLIP)),
        (ok.RANDOM_ORDER, deepcopy(RANDOM_ORDER))
    ]),
    wk.WIDGET: WidgetRow
}
IFRW = {
    wk.SUB: OrderedDict([
        (ok.INVERT, deepcopy(INVERT)),
        (ok.FLIP_V, deepcopy(FLIP))
    ]),
    wk.WIDGET: WidgetRow
}
IDK = {
    wk.SUB: OrderedDict([
        (ok.INVERT, deepcopy(INVERT)),
        (ok.DESATURATE, deepcopy(DESATURATE)),
        (ok.KEEP_GRADIENT, deepcopy(KEEP_GRADIENT))
    ]),
    wk.WIDGET: WidgetRow
}
OCR = {
    wk.SUB: OrderedDict([
        (ok.OBEY_MARGINS, deepcopy(OBEY_MARGINS)),
        (ok.CLIP_TO_CELL, deepcopy(CLIP_TO_CELL)),
    ]),
    wk.WIDGET: WidgetRow
}
P3R = {
    wk.SUB: OrderedDict([
        (ok.PATTERN_1, deepcopy(PATTERN)),
        (ok.PATTERN_2, deepcopy(PATTERN)),
        (ok.PATTERN_3, deepcopy(PATTERN))
    ]),
    wk.WIDGET: WidgetRow
}
RKR = {
    wk.SUB: OrderedDict([
        (ok.REVERSE, deepcopy(REVERSE)),
        (ok.KEEP_GRADIENT, deepcopy(KEEP_GRADIENT))
    ]),
    wk.WIDGET: WidgetRow
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Influence Row________________________________________________________________
INFLUENCE = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortInfluence,
    wk.SUB: OrderedDict([
        (ok.BACKDROP, {
            wk.VAL: {ok.MODE: "Normal", ok.OPACITY: .0},
            wk.WIDGET: InfluenceRow
        }),
        (ok.BORDER, {
            wk.VAL: {ok.MODE: "Hard Light", ok.OPACITY: .0},
            wk.WIDGET: InfluenceRow
        }),
        (ok.FRINGE, {
            wk.VAL: {ok.MODE: "Linear Light", ok.OPACITY: .0},
            wk.WIDGET: InfluenceRow
        }),
        (ok.PLAQUE, {
            wk.VAL: {ok.MODE: "Overlay", ok.OPACITY: .0},
            wk.WIDGET: InfluenceRow
        }),
        (ok.IMAGE, {
            wk.VAL: {ok.MODE: "Normal", ok.OPACITY: .0},
            wk.WIDGET: InfluenceRow
        }),
        (ok.METAL, {
            wk.VAL: {ok.MODE: "Hard Light", ok.OPACITY: .0},
            wk.WIDGET: InfluenceRow
        }),
        (ok.OTHER, {
            wk.VAL: {ok.MODE: "Normal", ok.OPACITY: .0},
            wk.WIDGET: InfluenceRow
        }),
        (ok.TRANSLUCENT, {
            wk.VAL: {ok.MODE: "Pin Light", ok.OPACITY: .0},
            wk.WIDGET: InfluenceRow
        })
    ]),
    wk.TIPPER: make_influence_tip,
    wk.VAL: gl.INFLUENCE_D,
    wk.WIDGET: InfluenceButton
}
IGR = {
    wk.SUB: OrderedDict([
        (ok.INFLUENCE, deepcopy(INFLUENCE)),
        (ok.GRADIENT, deepcopy(GRADIENT)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Average Color________________________________________________________________
AVERAGE_COLOR = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.IDR, deepcopy(IDR)),
    (ok.BRW, deepcopy(BRR))
])

for i in (ok.INVERT, ok.DESATURATE):
    AVERAGE_COLOR[ok.IDR][wk.SUB][i][wk.ISSUE] = vo.MATTER
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Background___________________________________________________________________
BACKGROUND = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBackground,
    wk.SUB: OrderedDict([
        (ok.TYPE, {
            wk.FUNCTION: get_backdrop_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: bs.BACKDROP_IMAGE,
            wk.WIDGET: ComboBox
        }),
        (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
        (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
        (ok.BLUR, deepcopy(BLUR)),
        (ok.SEED, deepcopy(SEED)),
        (ok.GRR, deepcopy(GRR))
    ]),
    wk.WIDGET: OptionButton
}
BBR = {
    wk.SUB: OrderedDict([
        (ok.BACKGROUND, deepcopy(BACKGROUND)),
        (ok.BUMP, deepcopy(BUMP)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Brush Dialog_________________________________________________________________
BRUSH_DIALOG = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBrush,
    wk.SUB: OrderedDict([
        (ok.BRUSH_SIZE, deepcopy(BRUSH_SIZE)),
        (ok.BRUSH_SPACING, deepcopy(BRUSH_SPACING)),
        (ok.BRUSH_ANGLE, {
            wk.LIMIT: (-180., 180.),
            wk.PRECISION: 1,
            wk.TIPPER: make_text_tip,
            wk.VAL: .0,
            wk.WIDGET: Slider,
        }),
        (ok.ANGLE_JITTER, deepcopy(ANGLE_JITTER)),
        (ok.BRUSH_HARDNESS, {
            wk.LIMIT: (.001, 1.),
            wk.PRECISION: 3,
            wk.STEP_INCR: .01,
            wk.TIPPER: make_text_tip,
            wk.VAL: 1.,
            wk.WIDGET: Slider
        }),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.SEED, deepcopy(SEED)),
        (ok.BRUSH, deepcopy(BRUSH))
    ]),
    wk.WIDGET: OptionButton
}
RC_SLICE = {
    wk.LIMIT: (1, 100),
    wk.TIPPER: make_text_tip,
    wk.VAL: 1.,
    wk.WIDGET: Slider
}

set_issue(BRUSH_DIALOG[wk.SUB], (), vo.MATTER, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Image Choice_________________________________________________________________
IMAGE_CHOICE = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortImageChoice,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.IMAGE_SOURCE, {
            wk.FUNCTION: get_image_source_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ok.NEXT_X,
            wk.WIDGET: ComboBox
        }),
        (ok.NUMERIC_SEQUENCE, {
            wk.FUNCTION: get_numeric_ref_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: fi.FIRST_IMAGE,
            wk.WIDGET: ComboBox
        }),
        (ok.IMAGE_NAME, {
            wk.FUNCTION: get_image_name_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: ComboBox
        }),
        (ok.NEXT_X, {wk.WIDGET: NextXLabel}),
        (ok.PREVIOUS_X, {wk.WIDGET: PreviousXLabel}),
        (ok.LOOP_X, {
            wk.TEXT: fi.LOOP_TYPE,
            wk.TIPPER: make_radio_tip,
            wk.TIPS: (Tip.LOOP_PLUS, Tip.LOOP_MINUS),
            wk.VAL: 0,
            wk.WIDGET: RadioRandomColumn
        }),
        (ok.FILE, {
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: FileButton
        }),
        (ok.FOLDER, {
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: FolderButton
        }),
        (ok.FILTER, {
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: Entry
        }),
        (ok.FOLDER_ORDER, {
            wk.TEXT: fi.FOLDER_ORDER_LIST,
            wk.TIPPER: make_radio_tip,
            wk.VAL: 0,
            wk.WIDGET: RadioRandomColumn
        }),
        (ok.AS_LAYERS, {
            wk.TIPPER: make_bool_tip,
            wk.TOOLTIP: Tip.IMAGE_LAYERS,
            wk.VAL: 0,
            wk.WIDGET: CheckButton
        }),
        (ok.LAYER_ORDER, {
            wk.TEXT: fi.LAYER_ORDER_LIST,
            wk.TIPPER: make_radio_tip,
            wk.TOOLTIP: Tip.IMAGE_ORDER,
            wk.VAL: 0,
            wk.WIDGET: RadioRandomColumn
        }),
        (ok.SLICE, {
            wk.TIPPER: make_bool_tip,
            wk.TOOLTIP: Tip.SLICE,
            wk.VAL: 0,
            wk.WIDGET: CheckButton
        }),
        (ok.ROW_SLICE, deepcopy(RC_SLICE)),
        (ok.COLUMN_SLICE, deepcopy(RC_SLICE)),
        (ok.SLICE_ORDER, {
            wk.TEXT: fi.SLICE_ORDER_LIST,
            wk.TIPPER: make_radio_tip,
            wk.VAL: 0,
            wk.WIDGET: RadioRandomColumn
        }),
        (ok.AUTOCROP, {
            wk.TIPPER: make_bool_tip,
            wk.TOOLTIP: Tip.AUTOCROP,
            wk.VAL: 0,
            wk.WIDGET: CheckButton
        }),
        (ok.RANDOM_ORDER, deepcopy(RANDOM_ORDER)),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(
    IMAGE_CHOICE[wk.SUB], (), vo.MATTER, NO_MATTER + (
        ok.NEXT_X, ok.PREVIOUS_X, ok.FILE, ok.FOLDER
    )
)

CIR = {
    wk.SUB: OrderedDict([
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE))
     ]),
    wk.WIDGET: WidgetRow
}
IBR = {
    wk.SUB: OrderedDict([
        (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (ok.BRUSH_D, deepcopy(BRUSH_DIALOG))
    ]),
    wk.WIDGET: WidgetRow
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Mask_________________________________________________________________________
MASK = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortMask,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.MASK_TYPE, {
            wk.FUNCTION: get_mask_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: "Circle",
            wk.WIDGET: ComboBox
        }),
        (ok.CORNER_TYPE, {
            wk.FUNCTION: get_corner_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ms.CUT_CORNER,
            wk.WIDGET: ComboBox
        }),
        (ok.HEXAGON_TYPE, {
            wk.FUNCTION: get_hexagon_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: sh.HEXAGON,
            wk.WIDGET: ComboBox
        }),
        (ok.OCTAGON_TYPE, {
            wk.FUNCTION: get_octagon_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: sh.OCTAGON,
            wk.WIDGET: ComboBox
        }),
        (ok.RECTANGLE_TYPE, {
            wk.FUNCTION: get_rectangle_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: sh.RECTANGLE,
            wk.WIDGET: ComboBox
        }),
        (ok.TRIANGLE_TYPE, {
            wk.FUNCTION: get_triangle_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ms.TRIANGLE_UP_REGULAR,
            wk.WIDGET: ComboBox
        }),
        (ok.TEXT, {
            wk.CHARS: 15,
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: Entry
        }),
        (ok.HORZ_SCALE, deepcopy(MASK_SCALE)),
        (ok.VERT_SCALE, deepcopy(MASK_SCALE)),
        (ok.PUPIL_SCALE, deepcopy(MASK_SCALE)),
        (ok.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE)),
        (ok.FEATHER, deepcopy(FEATHER)),
        (ok.STEPS, deepcopy(STEPS)),
        (ok.ANGLE, deepcopy(ANGLE)),
        (ok.CONTRACT, deepcopy(CONTRACT)),
        (ok.CUT_OUT, {
            wk.TOOLTIP: Tip.CUT_OUT,
            wk.TIPPER: make_bool_tip,
            wk.VAL: 0,
            wk.WIDGET: CheckButton
        }),
        (ok.FONT, deepcopy(FONT)),
        (ok.IBR, deepcopy(IBR))
    ]),
    wk.WIDGET: OptionButton
}
a = MASK[wk.SUB]
a[ok.FEATHER][wk.VAL] = 0.
a[ok.PUPIL_SCALE][wk.VAL] = .33
a[ok.PARALLELOGRAM_SCALE][wk.VAL] = .5

set_issue(MASK, None, vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Resize ______________________________________________________________________
RESIZE = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortResize,
    wk.SUB: OrderedDict([
        (ok.TYPE, {
            wk.FUNCTION: get_resize_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ok.LOCKED,
            wk.WIDGET: ComboBox
        }),
        (ok.LOCKED, {wk.WIDGET: LockedLabel}),
        (ok.TRIM, {wk.WIDGET: TrimLabel}),
        (ok.FILLED, {wk.WIDGET: FilledLabel}),
        (ok.COVER, {wk.WIDGET: CoverLabel}),
        (ok.FIXED_SIZE_W, deepcopy(FIXED_SIZE)),
        (ok.FIXED_SIZE_H, deepcopy(FIXED_SIZE)),
        (ok.FIW, deepcopy(FACTOR_SIZE)),
        (ok.FIH, deepcopy(FACTOR_SIZE)),
        (ok.CROP_X, deepcopy(CROP_X)),
        (ok.CROP_Y, deepcopy(CROP_Y)),
        (ok.CROP_W, deepcopy(FIXED_SIZE)),
        (ok.CROP_H, deepcopy(FIXED_SIZE))
    ]),
    wk.WIDGET: OptionButton
}
a = RESIZE[wk.SUB]
a[ok.FIXED_SIZE_W][wk.TOOLTIP] = Tip.FIXED_SIZE_W
a[ok.FIW][wk.TOOLTIP] = Tip.FIW

set_issue(RESIZE, None, vo.MATTER, ())

RESIZE_1 = deepcopy(RESIZE)
RESIZE_1[wk.SUB][ok.TYPE][wk.VAL] = ok.COVER
IRRW = {
    wk.SUB: OrderedDict([
        (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (ok.RESIZE, deepcopy(RESIZE))
    ]),
    wk.WIDGET: WidgetRow
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Noise Metal__________________________________________________________________
NOISE_D = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortNoise,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, {
            wk.FUNCTION: get_noise_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ff.INK,
            wk.WIDGET: ComboBox
        }),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BLUR, deepcopy(BLUR)),
        (ok.NOISE_AMOUNT, deepcopy(NOISE_AMOUNT)),
        (ok.SPECK_NOISE, deepcopy(SPECK_NOISE)),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}
NOISE_D[wk.SUB][ok.BLUR].update({wk.RANDOM_Q: (.0, 15.), wk.VAL: 1.5})

set_issue(NOISE_D[wk.SUB], (), vo.NOISE, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Margin_______________________________________________________________________
# Use for both Caption and for an option group.
MARGIN = OrderedDict([
    (wk.CHANGELESS, True),
    (wk.DIALOG, PortMargin),
    (wk.SUB, OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TOP, deepcopy(MARGIN_Y)),
        (ok.BOTTOM, deepcopy(MARGIN_Y)),
        (ok.LEFT, deepcopy(MARGIN_X)),
        (ok.RIGHT, deepcopy(MARGIN_X)),
        (ok.PER, deepcopy(PER))
    ])),
    (wk.WIDGET, OptionButton)
])

set_issue(MARGIN[wk.SUB], None, vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stripe_______________________________________________________________________
STRIPE = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortStripe,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.HEIGHT, {
            wk.LIMIT: (.1, 7.),
            wk.PRECISION: 1,
            wk.STEP_INCR: .1,
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.STRIPE_H,
            wk.VAL: 1.5,
            wk.WIDGET: Slider
        }),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND))
    ]),
    wk.WIDGET: OptionButton
}
a = STRIPE[wk.SUB]
a[ok.COLOR_1][wk.VAL] = 127, 127, 127

set_issue(STRIPE[wk.SUB], None, vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Shadow_______________________________________________________________________
SELECTED_ROW = {'node': {'selected_row': {wk.VAL: 0}}}
SWITCH_GROUP = {ok.SWITCH: deepcopy(SWITCH)}
INNER_SHADOW = OrderedDict([
    (ok.INTENSITY, deepcopy(INTENSITY)),
    (ok.BLUR, {
        wk.ISSUE: vo.INNER_SHADOW,
        wk.LIMIT: (.0, 500.),
        wk.PRECISION: 1,
        wk.RANDOM_Q: (.0, 50.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 15.,
        wk.WIDGET: RandomSlider
    }),
    (ok.OFFSET_X, deepcopy(OFFSET_XY)),
    (ok.OFFSET_Y, deepcopy(OFFSET_XY)),
    (ok.SHADOW_COLOR, deepcopy(SHADOW_COLOR)),
    (bk.RANDOM, deepcopy(RANDOM))
])
_SHADOW_NUM = OrderedDict([
    (ok.INTENSITY, deepcopy(INTENSITY)),
    (ok.BLUR, deepcopy(SHADOW_BLUR)),
    (ok.OFFSET_X, deepcopy(OFFSET_XY)),
    (ok.OFFSET_Y, deepcopy(OFFSET_XY)),
    (ok.SHADOW_COLOR, deepcopy(SHADOW_COLOR)),
    (bk.RANDOM, deepcopy(RANDOM))
])
SHADOW_1 = deepcopy(_SHADOW_NUM)
SHADOW_2 = deepcopy(_SHADOW_NUM)

set_issue(SHADOW_1, (), vo.SHADOW_1, ())
set_issue(SHADOW_2, (), vo.SHADOW_2, ())
set_issue(INNER_SHADOW, (), vo.INNER_SHADOW, ())
set_issue(SWITCH_GROUP, (), vo.SHADOW, ())

SHADOW = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortShadow,
    wk.SUB: OrderedDict([
        (sk.SHADOW_SWITCH, deepcopy(SWITCH_GROUP)),
        (sk.SHADOW, deepcopy(SELECTED_ROW)),
        (sk.SHADOW_1, deepcopy(SHADOW_1)),
        (sk.SHADOW_2, deepcopy(SHADOW_2)),
        (sk.INNER_SHADOW, deepcopy(INNER_SHADOW)),
    ]),
    wk.WIDGET: OptionButton
}
BSRR = {
    wk.SUB: OrderedDict([
        (ok.BUMP, deepcopy(BUMP)),
        (ok.SHADOW, deepcopy(SHADOW)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}
MSS = {
    wk.SUB: OrderedDict([
        (ok.MARGIN, deepcopy(MARGIN)),
        (ok.SHADOW, deepcopy(SHADOW)),
        (ok.STRIPE, deepcopy(STRIPE))
    ]),
    wk.WIDGET: WidgetRow
}
BSR = {
    wk.SUB: OrderedDict([
        (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
        (ok.SHADOW, deepcopy(SHADOW))
    ]),
    wk.WIDGET: WidgetRow
}

# Corner Tape__________________________________________________________________
SHADOW_BASIC = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortShadowBasic,
    wk.SUB: OrderedDict([
        (ok.INTENSITY, deepcopy(INTENSITY)),
        (ok.BLUR, deepcopy(SHADOW_BLUR)),
        (ok.COLOR_1, deepcopy(COLOR_1))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(SHADOW_BASIC[wk.SUB], (), vo.SHADOW, ())

BSR1 = {
    wk.SUB: OrderedDict([
        (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
        (ok.SHADOW_BASIC, deepcopy(SHADOW_BASIC))
    ]),
    wk.WIDGET: WidgetRow
}
BSR2 = {
    wk.SUB: OrderedDict([
        (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
        (ok.SHADOW_BASIC, deepcopy(SHADOW_BASIC)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

BBS = {
    wk.SUB: OrderedDict([
        (ok.BUMP, deepcopy(BUMP)),
        (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
        (ok.SHADOW, deepcopy(SHADOW)),
    ]),
    wk.WIDGET: WidgetRow
}
GSR = {
    wk.SUB: OrderedDict([
        (ok.GRADIENT, deepcopy(GRADIENT)),
        (ok.SHADOW, deepcopy(SHADOW)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}
NBR = {
    wk.SUB: OrderedDict([
        (ok.NOISE_D, deepcopy(NOISE_D)),
        (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND))
    ]),
    wk.WIDGET: WidgetRow
}
NBS = {
    wk.SUB: OrderedDict([
        (ok.NOISE_D, deepcopy(NOISE_D)),
        (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
        (ok.SHADOW, deepcopy(SHADOW))
    ]),
    wk.WIDGET: WidgetRow
}
NSR = {
    wk.SUB: OrderedDict([
        (ok.NOISE_D, deepcopy(NOISE_D)),
        (ok.SHADOW, deepcopy(SHADOW))
    ]),
    wk.WIDGET: WidgetRow
}
SRR = {
    wk.SUB: OrderedDict([
        (ok.SHADOW, deepcopy(SHADOW)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap_________________________________________________________________________
WRAP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortWrap,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.DEPTH, deepcopy(BLUR)),
        (ok.CONTRAST, deepcopy(CONTRAST)),
        (ok.SOFTEN, deepcopy(BLUR)),
        (ok.EMBOSS, deepcopy(EMBOSS)),
        (ok.COLOR_1, deepcopy(COLOR_1))
    ]),
    wk.WIDGET: OptionButton
}
a = WRAP[wk.SUB]
a[ok.EMBOSS][wk.VAL] = 1
a[ok.COLOR_1][wk.VAL] = 127, 127, 127

a[ok.DEPTH].update({
    wk.LIMIT: (1., 100.), wk.RANDOM_Q: (1., 25.), wk.VAL: 1.
})
a[ok.SOFTEN].update({
    wk.LIMIT: (.0, 50.), wk.RANDOM_Q: (.0, 8.), wk.STEP_INCR: .1, wk.VAL: .0
})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Color Board_____________________________________________________________
WRAP_CB = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortColorBoardWrap,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH))
    ]),
    wk.WIDGET: OptionButton
}

# Wrap Clear Frame_____________________________________________________________
WRAP_CF = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortClearFrameWrap,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.INNER_FRAME_W, {
            wk.LIMIT: (4, 14),
            wk.RANDOM_Q: (4, 12),
            wk.TIPPER: make_text_tip,
            wk.VAL: 5.,
            wk.WIDGET: RandomSlider
        }),
    ]),
    wk.WIDGET: OptionButton
}
WRAP_CF[wk.SUB][ok.WIDTH][wk.VAL] = 30.
WRAP_CF[wk.SUB][ok.OPACITY][wk.VAL] = 33.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Color Pipe______________________________________________________________
WRAP_CP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortColorPipeWrap,
    wk.SUB: OrderedDict([
        (ok.PROFILE, deepcopy(PROFILE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH))
    ]),
    wk.WIDGET: OptionButton
}

# Wrap Crumble Shell___________________________________________________________
WRAP_CS = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortCrumbleShellWrap,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.SPREAD, {
            wk.LIMIT: (1., 100.),
            wk.PAGE_INCR: 5.,
            wk.PRECISION: 1,
            wk.RANDOM_Q: (8., 16.),
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.SPREAD_DISTRESS,
            wk.VAL: 12.,
            wk.WIDGET: RandomSlider
        }),
        (ok.DISTRESS, {
            wk.LIMIT: (1., 254.),
            wk.PRECISION: 1,
            wk.RANDOM_Q: (1., 254.),
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.DISTRESS_THRESHOLD,
            wk.VAL: 127.,
            wk.WIDGET: RandomSlider
        }),
        (ok.SEED, deepcopy(SEED)),
    ]),
    wk.WIDGET: OptionButton
}

WRAP_CS[wk.SUB][ok.WIDTH].update({wk.RANDOM_Q: (15, 35), wk.VAL: 15.})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Color Pipe______________________________________________________________
WRAP_CU = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortCutoutPlateWrap,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.BEVEL_W, {
            wk.LIMIT: (0, 999),
            wk.PAGE_INCR: 2,
            wk.RANDOM_Q: (4, 8),
            wk.TIPPER: make_text_tip,
            wk.VAL: 3.,
            wk.WIDGET: RandomSlider
        }),
    ]),
    wk.WIDGET: OptionButton
}

# Wrap Nail Polish_____________________________________________________________
WRAP_NP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortNailPolishWrap,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.COLOR_1, deepcopy(COLOR_1))
    ]),
    wk.WIDGET: OptionButton
}
a = WRAP_NP[wk.SUB]
a[ok.COLOR_1][wk.VAL] = 94, 180, 123
a[ok.OPACITY][wk.VAL] = 50.
a[ok.MODE][wk.VAL] = "Grain Merge"
a[ok.WIDTH].update({wk.RANDOM_Q: (15, 55), wk.VAL: 30.})

# Stencil Frame Over___________________________________________________________
STENCIL = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortStencil,
    wk.SUB: OrderedDict([
        (ok.FRAME_OVER, {
            wk.FUNCTION: get_frame_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: ComboBox
        }),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
    ]),
    wk.WIDGET: OptionButton
}

for i in (STENCIL, WRAP, WRAP_CB, WRAP_CF, WRAP_CP, WRAP_CS, WRAP_CU, WRAP_NP):
    set_issue(i[wk.SUB], (), vo.MATTER, NO_MATTER)

set_issue(
    WRAP[wk.SUB],
    (ok.DEPTH, ok.CONTRAST, ok.SOFTEN, ok.EMBOSS), vo.MATTER_EMBOSS,
    ()
)

WBR = {
    wk.SUB: OrderedDict([
        (ok.WRAP, deepcopy(WRAP)),
        (ok.BRUSH_D, deepcopy(BRUSH_DIALOG)),
    ]),
    wk.WIDGET: WidgetRow
}
WNR = {
    wk.SUB: OrderedDict([
        (ok.WRAP, deepcopy(WRAP)),
        (ok.NOISE_D, deepcopy(NOISE_D))
    ]),
    wk.WIDGET: WidgetRow
}
WNS = {
    wk.SUB: OrderedDict([
        (ok.WRAP, deepcopy(WRAP)),
        (ok.NOISE_D, deepcopy(NOISE_D)),
        (ok.SHADOW, deepcopy(SHADOW))
    ]),
    wk.WIDGET: WidgetRow
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

BORDER_LINE = OrderedDict([(ok.WRW, deepcopy(WNS))])

# Corner Tape__________________________________________________________________
TAPE = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortTape,
    wk.SUB: OrderedDict([
        (ok.LENGTH, {
            wk.LIMIT: (5, 1000),
            wk.PAGE_INCR: 10,
            wk.RANDOM_Q: (80, 150),
            wk.TIPPER: make_text_tip,
            wk.VAL: 150.,
            wk.WIDGET: RandomSlider
        }),
        (ok.WIDTH, {
            wk.LIMIT: (5, 999),
            wk.PAGE_INCR: 10,
            wk.RANDOM_Q: (30, 60),
            wk.TIPPER: make_text_tip,
            wk.VAL: 50.,
            wk.WIDGET: RandomSlider
        }),
        (ok.ANGLE_SHIFT, {
            wk.LIMIT: (.0, 180.),
            wk.PRECISION: 1,
            wk.RANDOM_Q: (.0, 11.),
            wk.TIPPER: make_text_tip,
            wk.VAL: 5.,
            wk.WIDGET: RandomSlider
        }),
        (ok.CORNER_SHIFT, {
            wk.LIMIT: (0, 100),
            wk.PAGE_INCR: 5,
            wk.RANDOM_Q: (0, 18),
            wk.TIPPER: make_text_tip,
            wk.VAL: 9.,
            wk.WIDGET: RandomSlider
        }),
        (ok.LENGTH_SHIFT, {
            wk.LIMIT: (0, 999),
            wk.PAGE_INCR: 10,
            wk.RANDOM_Q: (10, 40),
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.LENGTH_SHIFT,
            wk.VAL: 10.,
            wk.WIDGET: RandomSlider
        }),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(TAPE[wk.SUB], (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Ceramic Chip Filler__________________________________________________________
FILLER_CC = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortCeramicChipFiller,
    wk.SUB: OrderedDict([
        (ok.MESH_TYPE, deepcopy(MESH_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.MESH_SIZE, deepcopy(MESH_SIZE)),
        (ok.SEED, deepcopy(SEED)),
        (ok.GREY_SCALE, {
            wk.TIPPER: make_bool_tip,
            wk.VAL: 0,
            wk.WIDGET: CheckButtonRandom
        })
    ]),
    wk.WIDGET: OptionButton
}

# Circle Punch Filler__________________________________________________________
FILLER_CP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortCirclePunchFiller,
    wk.SUB: OrderedDict([
        (ok.CIRCLE_DIAMETER, {
            # Is limited by GIMP's clipboard to
            # pattern function where the maximum side
            # span for the clipboard is 1024.
            wk.LIMIT: (12, 680),
            wk.RANDOM_Q: (12, 100),
            wk.TIPPER: make_text_tip,
            wk.VAL: 30.,
            wk.WIDGET: RandomSlider
        }),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# Line Fashion Filler__________________________________________________________
FILLER_LF = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortLineFashionFiller,
    wk.SUB: OrderedDict([
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.GAP_W, deepcopy(GAP_W)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# Link Mirror Filler___________________________________________________________
FILLER_LM = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortLinkMirrorFiller,
    wk.SUB: OrderedDict([
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.CFW, deepcopy(CFW)),
        (ok.SCATTER_COUNT, {
            wk.LIMIT: (1, 100),
            wk.PAGE_INCR: 5,
            wk.RANDOM_Q: (2, 20),
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.SCATTER_COUNT,
            wk.VAL: 5.,
            wk.WIDGET: RandomSlider
        }),
        (ok.SEED, deepcopy(SEED)),
    ]),
    wk.WIDGET: OptionButton
}

# Rad Wave Filler______________________________________________________________
FILLER_RW = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortRadWaveFiller,
    wk.SUB: OrderedDict([
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.CFW, deepcopy(CFW)),
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.WAVE_AMPLITUDE, deepcopy(WAVE_AMPLITUDE)),
        (ok.WAVELENGTH, deepcopy(WAVELENGTH)),
        (ok.WHIRL, {
            wk.LIMIT: (-720, 720),
            wk.PAGE_INCR: 10,
            wk.RANDOM_Q: (-30, 30),
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.WHIRL,
            wk.VAL: 45.,
            wk.WIDGET: RandomSlider
        })
    ]),
    wk.WIDGET: OptionButton
}

# Raised Maze Filler___________________________________________________________
FILLER_RM = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortRaisedMazeFiller,
    wk.SUB: OrderedDict([
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.CFW, deepcopy(CFW)),
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}


for i in (ok.ROW, ok.COLUMN):
    FILLER_RM[wk.SUB][i][wk.LIMIT] = 4, 999
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Square Cut Filler____________________________________________________________
FILLER_SC = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortSquareCutFiller,
    wk.SUB: OrderedDict([
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

for i in (ok.ROW, ok.COLUMN):
    FILLER_SC[wk.SUB][i][wk.VAL] = 15.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Square Punch Filler__________________________________________________________
FILLER_SP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortSquarePunchFiller,
    wk.SUB: OrderedDict([
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.GAP_W, deepcopy(GAP_W)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# Stained Glass Filler_________________________________________________________
FILLER_SG = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortStainedGlassFiller,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.GLASS_PANE_W, deepcopy(WIDTH)),
        (ok.ANGLE, deepcopy(ANGLE)),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}

a = FILLER_SG[wk.SUB]
a[ok.OPACITY][wk.VAL] = 40.
a[ok.GLASS_PANE_W][wk.RANDOM_Q] = 25, 100
a[ok.GLASS_PANE_W][wk.VAL] = 72.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stretch Tray Filler__________________________________________________________
FILLER_ST = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortStretchTrayFiller,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.SATURATION, deepcopy(HSL))
    ]),
    wk.WIDGET: OptionButton
}
FILLER_ST[wk.SUB][ok.SATURATION][wk.VAL] = .24
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stretch Tray Filler__________________________________________________________
FILLER_WF = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortWireFrameFiller,
    wk.SUB: OrderedDict([
        (ok.MESH_TYPE, deepcopy(MESH_TYPE)),
        (ok.MESH_SIZE, deepcopy(MESH_SIZE)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.WIRE_THICKNESS, {
            wk.LIMIT: (3, 30),
            wk.RANDOM_Q: (4, 10),
            wk.TIPPER: make_text_tip,
            wk.VAL: 3.,
            wk.WIDGET: RandomSlider
        }),
        (ok.NEATNESS, deepcopy(NEATNESS)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Has Filler Maya.
for i in (FILLER_CC, FILLER_LM, FILLER_RM, FILLER_RW, FILLER_SG, FILLER_ST):
    set_issue(i, (), vo.FILLER, NO_MATTER)

# Merged filler with Wrap.
for i in (FILLER_CP, FILLER_LF, FILLER_SC, FILLER_SP, FILLER_WF):
    set_issue(i, (), vo.MATTER, NO_MATTER)

for i in (FILLER_CC, FILLER_ST):
    i[wk.SUB][ok.WIDTH].update({wk.ISSUE: vo.MATTER, wk.VAL: 36})

for i in (ok.ROW, ok.COLUMN):
    FILLER_LM[wk.SUB][i][wk.LIMIT] = 3, 100

# Overlay Color________________________________________________________________
OVERLAY_CF = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortColorOverlay,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(OVERLAY_MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.COLOR_1, deepcopy(COLOR_1))
    ]),
    wk.WIDGET: OptionButton
}
a = OVERLAY_CF[wk.SUB]
a[ok.COLOR_1][wk.VAL] = 231, 231, 194
a[ok.OPACITY][wk.VAL] = 50.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Overlay Camo Planet__________________________________________________________
OVERLAY_CP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortCamoPlanetOverlay,
    wk.SUB: OrderedDict([
        (ok.CAMO_TYPE, {
            wk.FUNCTION: get_camo_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ff.COMPOSITE,
            wk.WIDGET: ComboBox
        }),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.SATURATION, deepcopy(HSL)),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}
a = OVERLAY_CP[wk.SUB]
a[ok.MODE][wk.VAL] = "Hard Light"
a[ok.SATURATION][wk.VAL] = .3
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Overlay Cutout Plate_________________________________________________________
OVERLAY_CU = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortCutoutPlateOverlay,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.PATTERN, deepcopy(PATTERN))
    ]),
    wk.WIDGET: OptionButton
}

OVERLAY_CU[wk.SUB][ok.OPACITY][wk.VAL] = 90.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Overlay Cutout Plate_________________________________________________________
OVERLAY_FO = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortFrameOverOverlay,
    wk.SUB: OrderedDict([
        (ok.TYPE, {
            wk.FUNCTION: get_frame_style_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ff.CLOUDS,
            wk.WIDGET: ComboBox
        }),
        (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
        (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BLUR, deepcopy(BLUR)),
        (ok.SEED, deepcopy(SEED)),
        (ok.CIR, deepcopy(CIR)),
        (ok.GPR, {
            wk.SUB: OrderedDict([
                (ok.GRADIENT, deepcopy(GRADIENT)),
                (ok.PATTERN, deepcopy(PATTERN))
            ]),
            wk.WIDGET: WidgetRow
        })
    ]),
    wk.WIDGET: OptionButton
}

# Overlay Nail Polish__________________________________________________________
OVERLAY_NP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortNailPolishOverlay,
    wk.SUB: OrderedDict([
        (ok.TYPE, {
            wk.FUNCTION: get_nail_polish_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ff.BACKDROP,
            wk.WIDGET: ComboBox
        }),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.PATTERN, deepcopy(PATTERN)),
        (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE))
    ]),
    wk.WIDGET: OptionButton
}
OVERLAY_NP[wk.SUB][ok.OPACITY][wk.VAL] = 12.
OVERLAY_NP[wk.SUB][ok.MODE][wk.VAL] = "Subtract"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

for i in (OVERLAY_CF, OVERLAY_CP, OVERLAY_CU, OVERLAY_FO, OVERLAY_NP):
    set_issue(i[wk.SUB], (), vo.OVERLAY, (NO_MATTER))

FRAME = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortFrame,
    wk.ISSUE: vo.NULL,              # Needed by PerGroup.
    wk.VAL: {
        ok.SWITCH: SWITCH[wk.VAL],
        ek.BORDER_LINE: scour({}, BORDER_LINE, wk.VAL)
    },
    wk.WIDGET: OptionListButton
}
BBR1 = {
    wk.SUB: OrderedDict([
        (ok.BRUSH_D, deepcopy(BRUSH_DIALOG)),
        (ok.BUMP, deepcopy(BUMP))
    ]),
    wk.WIDGET: WidgetRow
}
BBF = {
    wk.SUB: OrderedDict([
        (ok.BUMP, deepcopy(BUMP)),
        (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
        (ok.FRAME, deepcopy(FRAME))
    ]),
    wk.WIDGET: WidgetRow
}
BFR1 = {
    wk.SUB: OrderedDict([
        (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
        (ok.FRAME, deepcopy(FRAME))
    ]),
    wk.WIDGET: WidgetRow
}
MBR = {
    wk.SUB: OrderedDict([
        (ok.MASK, deepcopy(MASK)),
        (ok.BUMP, deepcopy(BUMP))
    ]),
    wk.WIDGET: WidgetRow
}
MBF = {
    wk.SUB: OrderedDict([
        (ok.MASK, deepcopy(MASK)),
        (ok.BLUR_BEHIND, deepcopy(BLUR_BEHIND)),
        (ok.FRAME, deepcopy(FRAME))
    ]),
    wk.WIDGET: WidgetRow
}
