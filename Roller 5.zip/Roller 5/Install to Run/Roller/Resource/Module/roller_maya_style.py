#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_frame_build import Build
from roller_fu import blur_selection, make_clouds, verify_layer
from roller_maya import MAIN, check_matter, check_mix_basic
from roller_maya_bump import Bump
from roller_view_hub import get_gradient_factors
from roller_view_real import (
    add_wip_layer,
    do_gradient_for_layer,
    get_light,
    insert_copy,
    make_group,
    mask_sub_maya,
)
import gimpfu as fu

pdb = fu.pdb


def check_style_group(v, maya):
    """
    Create a Backdrop Style layer group if needed.

    v: View
    maya: Maya
    Return: layer group
        the Backdrop Style group
    """
    if not maya.group:
        return make_group(
            v,
            "Style",
            maya.cause.group,
            offset=get_light(maya.cause)
        )
    return maya.group


def make_background(v, maya, d):
    """
    Create a background layer for a Backdrop Style's base material.

    v: View
    maya: Maya
        Style

    d: dict
        Style Preset

    Return: layer
        with base material for a Backdrop Style process
    """
    j = v.j
    d = d[ok.BRW][ok.BACKGROUND]
    n = d[ok.TYPE]

    pdb.gimp_selection_none(j)

    if n in (bs.CLOUDS, bs.PLASMA):
        z = add_wip_layer(v, maya, n)
        seed_ = int(d[ok.SEED] + v.glow_ball.seed)

        if n == bs.PLASMA:
            # low-end turbulence, '1.5'
            pdb.plug_in_plasma(j, z, seed_, 1.5)
        else:
            make_clouds(z, seed_)

    elif n == bs.BACKDROP_IMAGE:
        z = insert_copy(v, maya.group, maya.group)

    elif n == bs.GRADIENT:
        add_wip_layer(v, maya, "Base", maya.group)

        e = get_default_value(by.GRADIENT_FILL)
        e[ok.GRADIENT] = d[ok.GRR][ok.GRADIENT]
        e[ok.GRADIENT_TYPE] = d[ok.GRADIENT_TYPE]
        e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
            get_gradient_factors(d[ok.GRADIENT_ANGLE])

        z = do_gradient_for_layer(v, e, maya.group, 0)
        z = verify_layer(z)
        if z:
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    if d[ok.BLUR]:
        blur_selection(z, d[ok.BLUR])
    return z


class Style(Build):
    """Factor Backdrop Style Maya."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (check_style_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )
    vote_type = MAIN

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
        k_path: iterable
            (Option key, ...)

        do_matter: function
            Call to make style layer.
        """
        Build.__init__(self, any_group, super_maya, k_path, do_matter)
        self.sub_maya[ok.BUMP] = Bump(
            any_group,
            self,
            k_path + (ok.BRW, ok.BUMP) if isinstance(k_path, tuple)
            else k_path[0] + (ok.BRW, ok.BUMP)
        )

    def do(self, v, d, is_change):
        """
        Manage layer output for Backdrop Style during a View run.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.value_d = d

        if not self.is_matter and self.is_dependent and v.is_back:
            self.is_matter = True

        self.realize(v)

        if self.is_matter or is_change:
            mask_sub_maya(self.cause.matter, self.matter)

        self.sub_maya[ok.BUMP].do(
            v, self.value_d[ok.BRW][ok.BUMP], self.is_matter
        )
        self.reset_issue()

    def init_background(self, any_group, super_maya, k_path, make_style):
        """
        Call during init when a Backdrop Style has the
        Background option, 'ok.BRW'. Adjust the incoming
        key path so the Background option can count its vote.

        any_group: AnyGroup
        super_maya: Maya
        k_path: tuple
            (Option key, ...)

        make_style: function
            Call to produce a Backdrop Style layer.
        """
        self.is_seeded = self.is_dependent = True
        k_path = [
            k_path,
            k_path + (ok.BRW,),
            k_path + (ok.BRW, ok.BACKGROUND),
            k_path + (ok.BRW, ok.BACKGROUND, ok.GRR),
            k_path + (ok.IDR,)
        ]
        Style.__init__(self, any_group, super_maya, k_path, make_style)
