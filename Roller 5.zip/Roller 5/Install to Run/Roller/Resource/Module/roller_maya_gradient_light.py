#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Option as ok
from roller_maya import MAIN, Maya
from roller_one_the import The
from roller_option_group import ManyGroup
from roller_view_gradient_light import create_gradient, reset_gradient


def make_gradient_light(v, maya):
    """
    Make Gradient Light and/or remove it.

    v: View
    maya: Work
    """
    if maya.is_matter:
        reset_gradient()
        create_gradient(v, maya)


class Light(ManyGroup):
    """Create Widget group and assign a View processor."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)


class Plan(Maya):
    """Doesn't have layer output. Is a template for a View/Plan run."""
    issue_q = ()
    vote_type = MAIN

    def __init__(self, any_group):
        Maya.__init__(self, any_group, 0, ())

    def do(self, v):
        """
        Plan doesn't have Gradient Light.

        v: View
        Return: None
            for undo
        """
        return


class Work(Maya):
    """Manage Gradient Light layer output."""
    put = (make_gradient_light, 'matter'),
    issue_q = 'matter',
    vote_type = MAIN

    def __init__(self, any_group):
        Maya.__init__(
            self,
            any_group,
            1,
            Work.put,
            k_path=[(), (ok.IRR,), (ok.IGR, ok.GRADIENT)]
        )
        self.set_issue()
        self.handle_d[
            any_group.booth.connect(si.VOTE_CHANGE, Work.on_light_change)
        ] = any_group.booth

    def do(self, v):
        """
        Manage Gradient Light layer output for a View run.

        v: View
        Return: None
            for undo
        """
        self.go = self.value_d[ok.SWITCH]
        self.realize_vote(v)

    def die(self, _):
        """
        Override the Maya class function.

        _: View
        """
        reset_gradient()

    @staticmethod
    def on_light_change(_, arg):
        """
        Respond to change in Gradient Light option.
        Notify gradient light subscriber.

        _: AnyGroup
            Sent the signal.

        arg: dict
            AnyGroup's vote collection
        """
        The.power.plug(si.LIGHT_CHANGE, None)
