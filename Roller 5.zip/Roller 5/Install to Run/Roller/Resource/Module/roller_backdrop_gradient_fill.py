#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_fu import invert_and_desaturate, merge_layer_group
from roller_maya_style import Style
from roller_view_real import (
    add_sub_base_group, do_gradient_for_layer, finish_style
)


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: GradientFill
    Return: layer or None
        with Gradient Fill material
    """
    d = maya.value_d
    d[ok.GRADIENT] = d[ok.BRW][ok.GRADIENT]
    parent = add_sub_base_group(v, maya)

    do_gradient_for_layer(v, d, parent, 0)

    z = merge_layer_group(parent)

    invert_and_desaturate(d[ok.IRR], z)
    return finish_style(z, "Gradient Fill")


class GradientFill(Style):
    """Create Backdrop Style output."""
    is_dependent = False

    def __init__(self, any_group, super_maya, k_path):
        k_path = [k_path, k_path + (ok.BRW,), k_path + (ok.IRR,)]
        Style.__init__(self, any_group, super_maya, k_path, make_style)
