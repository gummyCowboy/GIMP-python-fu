#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_fu import (
    clone_layer, invert_and_desaturate, make_layer_group, merge_layer_group
)
from roller_maya_style import Style, make_background
from roller_one_gegl import engrave, video_degradation
from roller_view_real import add_sub_base_group, finish_style
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: NanoSuit
    Return: layer
        with style material
    """
    d = maya.value_d
    z = make_background(v, maya, d)
    parent = add_sub_base_group(v, maya, z=z)
    group = make_layer_group(v.j, "WIP", parent=parent, z=z)

    video_degradation(z, 'dots')

    z = clone_layer(z, n="Difference")
    z.mode = fu.LAYER_MODE_DIFFERENCE

    engrave(z, 3)
    pdb.gimp_drawable_curves_spline(z, fu.HISTOGRAM_VALUE, 4, (.0, .5, 1., 1.))

    z = merge_layer_group(group)

    invert_and_desaturate(d[ok.IDR], z)
    return finish_style(merge_layer_group(parent), "Nano Suit")


class NanoSuit(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BRW][ok.BACKGROUND][ok.TYPE] == bs.BACKDROP_IMAGE
        super(NanoSuit, self).do(v, d, is_change)
