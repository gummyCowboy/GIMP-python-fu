#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice
from roller_constant_for import Caption as pt, Signal as si, Widget as fw
from roller_constant_key import Model as md, Node as ny, Widget as wk
from roller_widget import Widget
import gtk
import pango


def get_caption_all_list():
    return pt.ALL_OPTION


def get_caption_no_sequence_list():
    return pt.NO_SEQUENCE_OPTION


def get_caption_text_list():
    return (pt.TEXT,)


class Combo(Widget):
    """Is a base class for a ComboBox-type class."""
    change_signal = 'changed'

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        self.item_q = []
        self.store = gtk.ListStore(str)
        g = d['sub_type'](self.store)
        d[wk.RELAY].insert(0, self.set_tooltip)
        Widget.__init__(self, g, **d)

        # Limit the horizontal size of the the ComboBox.
        a = gtk.CellRendererText()
        a.props.ellipsize = pango.ELLIPSIZE_END

        g.pack_start(a)
        self.add(g)

        if d['sub_type'] == gtk.ComboBox:
            g.add_attribute(a, 'text', 0)

        else:
            g.child.set_editable(0)

        if wk.FUNCTION in d:
            self.item_q = self.function()

        self.populate_list(self.item_q)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

    def get_a(self):
        """
        Get the activated item in the ComboBox.

        Return: string
            active option
        """
        if len(self.item_q):
            return self.item_q[self.widget.get_active()]
        else:
            return ""

    def populate_list(self, q):
        """
        Set the options for the ComboBox.

        q: iterable
            of option strings
        """
        self.store.clear()
        self.item_q = q
        for n in q:
            self.store.append([n])

    def randomize(self, *_):
        """Generate a random value for the NumberPair."""
        if self.item_q:
            n = fw.LIST_SEPARATOR

            while fw.LIST_SEPARATOR in n:
                n = choice(self.item_q)
            self.set_a(n)

    def set_a(self, n):
        """
        Set the ComboBox's display.

        n: string
            to display
        """
        if n in self.item_q:
            x = self.item_q.index(n)

        elif hasattr(self, 'set_text'):
            self.set_text(n)
            x = -1

        else:
            x = 0
        if x > -1:
            self.widget.set_active(x)

    def set_tooltip(self, *_):
        """
        Call when the ComboBox changes. Add a tooltip for long strings.
        """
        if hasattr(self, 'get_text'):
            n = self.get_text()

        else:
            n = self.get_a()

        # '22' is arbitrary and from the observation of gtk on my
        # screen. The string's pixel length is difficult to obtain.
        n = " {} ".format(n)
        n = n if len(n) > 22 else ""

        self.set_tooltip_text(n)


class ComboBox(Combo):
    """Has a list separator."""
    has_table_label = True

    def __init__(self, **d):
        """
        d: dict
            to initialize the Widget
        """
        Combo.__init__(self, **dict(d, sub_type=gtk.ComboBox))
        self.widget.set_row_separator_func(ComboBox._set_mode_separator)

    @staticmethod
    def _set_mode_separator(model, itr):
        """
        Determine if the current item in the list is a
        separator. Use when populating the option list.

        model: gtk.ListStore
        itr: gtk.iter

        Return: flag
            Is true if the item is a separator.
        """
        n = model.get_value(itr, 0)
        if n:
            return fw.LIST_SEPARATOR in n


class CaptionComboBox(ComboBox):
    """Use to initialize the Caption Type option."""

    def __init__(self, **d):
        """
        d: dict
            to initialize the Widget
        """
        a = d[wk.ANY_GROUP]

        if a.render_key[2] == ny.FACE:
            p = get_caption_text_list

        elif (
            a.item.model.model_type == md.CELL or
            a.render_key[-2] == ny.CANVAS
        ):
            # A numeric sequence in not a Caption Type.
            p = get_caption_no_sequence_list

        else:
            p = get_caption_all_list

        d[wk.FUNCTION] = p
        ComboBox.__init__(self, **d)
