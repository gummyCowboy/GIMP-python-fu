#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_fu import (
    blur_selection,
    clone_layer,
    hide_layer,
    invert_and_desaturate,
    make_layer_group,
    merge_layer,
    merge_layer_group
)
from roller_maya_style import Style, make_background
from roller_fu_mode import get_gradient_mode
from roller_one_gegl import emboss, unsharp_mask, waterpixels
from roller_view_real import (
    add_sub_base_group,
    do_gradient_for_layer,
    finish_style,
    insert_copy_above
)
from roller_view_hub import get_gradient_factors
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: GalacticField
    Return: layer
        with Galactic Field material
    """
    def _make_group():
        return make_layer_group(v.j, "WIP", parent=parent, z=z)

    j = v.j
    d = maya.value_d
    z = make_background(v, maya, d)
    parent = add_sub_base_group(v, maya, z=z)
    key = maya.any_group.item.key
    group = _make_group()
    n = "Dotify"
    z1 = clone_layer(z, n=n)
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    pdb.plug_in_gimpressionist(j, z1, n)

    z2 = insert_copy_above(v, z1, group.layers[0])
    z2.mode = fu.LAYER_MODE_HARD_MIX

    emboss(z2, v.glow_ball.azimuth, 12, 3)

    n = "Embroidery"
    z3 = clone_layer(z, n=n)
    z3.mode = fu.LAYER_MODE_COLOR_ERASE

    pdb.plug_in_gimpressionist(j, z3, n)

    z4 = insert_copy_above(v, z, group.layers[0])

    hide_layer(z3)
    blur_selection(z, 500)

    z5 = insert_copy_above(v, z4, group.layers[0])
    z5.mode = fu.LAYER_MODE_SOFTLIGHT

    hide_layer(z1)
    hide_layer(z2)

    z = merge_layer_group(group, n="Group 1")
    group = _make_group()
    z1 = clone_layer(z, n="Difference")
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    unsharp_mask(z1, 3., .5, .0)

    z = insert_copy_above(v, z1, group.layers[0])
    z.mode = fu.LAYER_MODE_SOFTLIGHT

    hide_layer(z1)

    z = merge_layer_group(group, n="Group 2")
    group = _make_group()
    z = clone_layer(z, n="Grain Extract")
    z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
    z.opacity = 50.

    waterpixels(z)
    blur_selection(z, 7)

    z = clone_layer(z, n="Difference")
    z.mode = fu.LAYER_MODE_DIFFERENCE
    z.opacity = 100.
    z = merge_layer_group(group, n=key + " WIP")
    e = get_default_value(by.GRADIENT_FILL)
    e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
        get_gradient_factors(d[ok.GRADIENT_ANGLE])

    e.update(d)

    z = do_gradient_for_layer(v, e, parent, 0)
    z.mode = get_gradient_mode(d)
    z.opacity = d[ok.GRADIENT_OPACITY]

    merge_layer(z)

    z = merge_layer_group(parent)

    invert_and_desaturate(d[ok.IDR], z)
    return finish_style(z, "Galactic Field")


class GalacticField(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BRW][ok.BACKGROUND][ok.TYPE] == bs.BACKDROP_IMAGE
        super(GalacticField, self).do(v, d, is_change)
