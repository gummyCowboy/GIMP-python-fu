#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_color_grid import do_color_grid
from roller_constant_for import Gradient as fg
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_fu import (
    clone_layer,
    create_mask,
    flip_layer,
    invert_and_desaturate,
    merge_layer_group,
    transfer_mask
)
from roller_maya_style import Style
from roller_option_preset import Preset
from roller_view_hub import do_stylish_shadow
from roller_view_real import (
    add_sub_base_group, clip_to_wip, do_gradient_for_layer, finish_style
)
import gimpfu as fu

pdb = fu.pdb


def do_1st_layer(v, j, d, e, d1, group):
    """
    Create a diamond-slat layer and a shadow.

    j: GIMP image
        Is the render.

    d: dict
        Color Grid Preset
        {Option key: value}

    e: dict
        Gradient Fill Preset
        {Option key: value}

    d1: dict
        Mystery Grate Preset
        {Option key: value}

    group: layer group
        work-in-progress
    """
    d[ok.ROW] = 2
    d[ok.COLUMN] = d1[ok.COLUMN_1]
    d[ok.MODE] = "Normal"
    d[ok.ANGLE] = 45.
    d[ok.BUMP] = Preset.get_default_value(ok.BUMP)
    z = do_color_grid(v, d, group)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    do_stylish_shadow(z)
    create_mask(z)

    e[ok.START_X] = e[ok.START_Y] = 0, 0.
    e[ok.END_X] = e[ok.END_Y] = 0, 1.
    do_gradient(v, e, z)


def do_2nd_layer(v, j, d, e, d1, group):
    """
    Process the second layer.

    v: View
    j: GIMP image
        Is the render.

    d: dict
        Color Grid Preset dict

    e: dict
        Gradient Fill Preset
        {Option key: value}

    d1: dict
        Mystery Grate Preset
        {Option key: value}

    group: layer group
        work-in-progress
    """
    d[ok.COLUMN] = d1[ok.COLUMN_2]
    z = do_color_grid(v, d, group)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    do_stylish_shadow(z)
    create_mask(z)

    e[ok.END_X] = e[ok.END_Y] = 0, 0.
    e[ok.START_X] = e[ok.START_Y] = 0, 1.
    return do_gradient(v, e, z)


def do_3rd_layer(z):
    """
    Process the third layer.

    z: layer
        work-in-progress
    """
    z = clone_layer(z)

    flip_layer(z, is_h=True)
    do_stylish_shadow(z)
    create_mask(z)


def do_gradient(v, d, z):
    """
    Draw a gradient.

    v: View
    d: dict
        Gradient Fill Preset

    z: layer
        to receive the gradient

    Return: layer
        with the gradient
    """
    j = z.image
    z1 = do_gradient_for_layer(v, d, z.parent, 0)

    transfer_mask(z1, z)
    return pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: MysteryGrate
    Return: layer
        with the style material
    """
    j = v.j
    d = maya.value_d
    e = get_default_value(by.GRADIENT_FILL)
    d[ok.GRADIENT] = d[ok.BRW][ok.GRADIENT]
    d[ok.GRADIENT_TYPE] = fg.LINEAR

    e.update(d)

    d1 = get_default_value(by.COLOR_GRID)
    d1[ok.ANGLE] = 45.
    parent = maya.group
    z = do_gradient_for_layer(v, e, parent, 0)
    z.name = "Base"
    group = add_sub_base_group(v, maya, z=z)

    do_1st_layer(v, j, d1, e, d, group)

    z1 = do_2nd_layer(v, j, d1, e, d, group)

    do_3rd_layer(z1)

    e[ok.START_X] = e[ok.END_Y] = 0, 1.
    e[ok.END_X] = e[ok.START_Y] = 0, .0
    z = merge_layer_group(group)

    clip_to_wip(v, z)
    invert_and_desaturate(d[ok.IRR], z)
    return finish_style(z, "Mystery Grate")


class MysteryGrate(Style):
    """Create Backdrop Style output."""
    is_dependent = False

    def __init__(self, any_group, super_maya, k_path):
        k_path = [k_path, k_path + (ok.BRW,), k_path + (ok.IRR,)]
        Style.__init__(self, any_group, super_maya, k_path, make_style)
