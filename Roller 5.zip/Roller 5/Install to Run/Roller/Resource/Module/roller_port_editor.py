#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Color as co, Signal as si, Widget as fw
from roller_constant_key import Option as ok, Widget as wk
from roller_one_the import The
from roller_one_tip import Tip
from roller_port_preview import PortPreview
from roller_widget_box import Box as boxer, Eventful
from roller_widget_button import (
    AcceptButton,
    Button,
    CancelButton,
    NavButton,
    PlanButton,
    PreviewButton,
    ProcessButton
)
from roller_widget_label import Label
from roller_widget_node import Dust, Piece
from roller_widget_radio import RadioRow
from roller_widget_table import get_darker_color
import gtk

PAD = 0, 0, fw.MARGIN, fw.MARGIN


def set_button(m, g):
    """
    Set a Button's sensitivity.

    m: bool
        If true, then enable the Widget.

    g: Widget
        Button
    """
    g.enable() if m else g.disable()


class PortEditor(PortPreview):
    """Is a Preset editor called from a Per response."""

    def __init__(self, d, g):
        """
        d: dict
            PortCell

        g: PortPer
            Is responsible.
        """
        self._cell_label = self.any_group = None
        self._row, self._column = g.division
        self.r_c = d[wk.R_C]
        self._is_face = d[wk.IS_FACE]

        # Is True when the port is closing via a return key.
        self.is_return_key = True

        # Apply option value, '0'. Clear option value, '1'.
        self._edit_mode = 0

        self.option_d = {wk.HAS_PRESET: True, wk.IS_DEFAULT: False}
        PortPreview.__init__(self, d, g)

    def _is_cell(self, r, c):
        """
        Determine if a cell is a valid cell.

        r, c: int
            cell index

        Return: bool
            Is True if the cell is a valid cell.
        """
        return self.safe.gum_table[r][c].is_cell

    def _view_east_cell(self, *_):
        """Move the cell focus to the right."""
        self.update_safe()
        self._east_button.set_tooltip_text("")

        for c in range(self.r_c[1] + 1, self._column):
            gum = self.safe.gum_table[self.r_c[0]][c]
            if gum.is_cell or gum.is_topleft:
                self.r_c = self.r_c[0], c

                self.safe.set_active_cell(*self.r_c)
                break
        self.set_widget_value()

    def _view_north_cell(self, *_):
        """Move the cell focus upward."""
        self.update_safe()
        self._north_button.set_tooltip_text("")

        for r in range(self.r_c[0] - 1, -1, -1):
            gum = self.safe.gum_table[r][self.r_c[1]]
            if gum.is_cell or gum.is_topleft:
                self.r_c = r, self.r_c[1]

                self.safe.set_active_cell(*self.r_c)
                break
        self.set_widget_value()

    def _view_south_cell(self, *_):
        """Move the cell focus downward."""
        self.update_safe()
        self._south_button.set_tooltip_text("")

        for r in range(self.r_c[0] + 1, self._row):
            gum = self.safe.gum_table[r][self.r_c[1]]
            if gum.is_cell or gum.is_topleft:
                self.r_c = r, self.r_c[1]

                self.safe.set_active_cell(*self.r_c)
                break
        self.set_widget_value()

    def _view_west_cell(self, *_):
        """Move the cell focus to the left."""
        self.update_safe()
        self._west_button.set_tooltip_text("")

        for c in range(self.r_c[1] - 1, -1, -1):
            gum = self.safe.gum_table[self.r_c[0]][c]
            if gum.is_cell or gum.is_topleft:
                self.r_c = self.r_c[0], c

                self.safe.set_active_cell(*self.r_c)
                break
        self.set_widget_value()

    def apply_to_1st_half(self, _):
        """
        Set the Preset value for the current cell
        and cells in the first half of the cell table.
        """
        self.is_return_key = False
        r_c = self.r_c
        half = int(round(self._row * self._column / 2))
        x = 0
        q = [r_c]
        for r in range(self._row):
            if x >= half:
                break
            for c in range(self._column):
                if (r, c) != r_c and self._is_cell(r, c):
                    q += [(r, c)]

                x += 1
                if x >= half:
                    break

        self.safe.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def apply_to_2nd_half(self, _):
        """
        Set the Preset value for the current cell and
        the cells in the second half of the cell table.
        """
        self.is_return_key = False
        r_c = self.r_c
        half = int(round(self._row * self._column / 2))
        x = 0
        q = [r_c]
        for r in range(self._row):
            for c in range(self._column):
                if x >= half and (r, c) != r_c and self._is_cell(r, c):
                    q += [(r, c)]
                x += 1

        self.safe.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def apply_to_all(self, _):
        """Set the Preset value for all cells."""
        self.is_return_key = False
        r_c = self.r_c
        q = [r_c]

        for r in range(self._row):
            for c in range(self._column):
                if (r, c) != r_c and self._is_cell(r, c):
                    q += [(r, c)]

        self.safe.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def apply_to_cell(self, _):
        """
        Set Preset value for the active cell.
        The AcceptButton sends an ACCEPT_WINDOW Signal,
        so 'accept_preview' is not called.
        """
        self.is_return_key = False
        self.update_safe()

    def apply_to_column(self, _):
        """Set the Preset value for the current cell table column."""
        self.is_return_key = False
        row, c = self.r_c
        q = [self.r_c]

        for r in range(self._row):
            if r != row and self._is_cell(r, c):
                q += [(r, c)]

        self.safe.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def apply_checkerboard(self, _):
        """
        Set the Preset value for the current
        cell and odd numbered sequenced-cells.
        """
        self.is_return_key = False
        r_c = self.r_c
        q = [r_c]
        remain = (r_c[0] + r_c[1]) % 2

        for r in range(self._row):
            for c in range(self._column):
                if (
                    (r + c) % 2 == remain and
                    (r, c) != r_c and
                    self._is_cell(r, c)
                ):
                    q += [(r, c)]

        self.safe.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def apply_to_row(self, _):
        """
        Set the Preset value to the current cell table row.

        _: Button
            not in use

        Return: True
            The key-press is handled.
        """
        self.is_return_key = False
        r, column = self.r_c
        q = [self.r_c]

        for c in range(self._column):
            if c != column and self._is_cell(r, c):
                q += [(r, c)]

        self.safe.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def _do_control_arrow(self, n):
        """
        Respond to a control-arrow keypress. Change the Preset value for the
        cell indicated by the arrow key. The target cell may not exist.

        n: string
            arrow key-press
        """
        r, c = self.r_c
        m = False

        if n == "Down":
            if r + 1 != self._row:
                for r1 in range(r + 1, self._row):
                    if self._is_cell(r1, c):
                        m = True
                        break
                if m:
                    self._view_south_cell()

        elif n == "Up":
            if r != 0:
                for r1 in range(r - 1, -1, -1):
                    if self._is_cell(r1, c):
                        m = True
                        break
                if m:
                    self._view_north_cell()

        elif n == "Left":
            if c != 0:
                for c1 in range(c - 1, -1, -1):
                    if self._is_cell(r, c1):
                        m = True
                        break
                if m:
                    self._view_west_cell()
        elif n == "Right":
            if c + 1 != self._column:
                for c1 in range(c + 1, self._column):
                    if self._is_cell(r, c1):
                        m = True
                        break
                if m:
                    self._view_east_cell()

    def _get_value_d(self):
        """
        Collect Widget value from the current Preset.

        Return: dict or None
            Is None if the cell is a main cell.
        """
        d = None

        if d is None:
            d = self.any_group.get_preset_g().get_a()

        if d == self.safe.main_edit_d or self._edit_mode == 1:
            d = None
        return d

    def accept_preview(self):
        self.roller_win.emit(si.ACCEPT_WINDOW, self)

    def accept_cell_editor(self, *_):
        """
        Accept option.

        _: Preset
            not used
        """
        if self.is_return_key:
            self.update_safe()
        self.safe.on_cell_editor_close()

    def cancel_cell_editor(self):
        """Close the cell editor."""
        self.safe.on_cell_editor_close()

    def draw(self):
        """Draw the Port's Widgets."""
        self.option_d[wk.COLOR] = self.color
        self.option_d[wk.ROLLER_WIN] = self.roller_win
        self.option_d[wk.RELAY] = [self.on_port_change]
        self.option_d[wk.RENDER_KEY] = \
            self.safe.safe.any_group.render_key + (ok.PER,)
        r, c = self.r_c
        self._cell_label = Label(
            padding=(4, 4, 4, 4),
            text="Cell Data:\tRow: {}\tColumn: {}".format(r + 1, c + 1)
        )
        hbox = gtk.HBox()

        # cell data group
        box = Eventful(self.color)
        a = self.safe.cell_table_group.item
        piece = self.option_d[wk.ITEM] = Piece(
            a.key,
            box,
            a,
            group_type='preset',
            has_label=False,
            is_per=True
        )

        self.reduce_color()
        piece.vbox.add(self._cell_label)

        self.any_group = The.dog.many_group(**self.option_d)

        # navigation group
        self.reduce_color()
        self.draw_navigation(piece.vbox)
        self.reduce_color()

        box1 = self.draw_distribution()

        self.set_widget_value()
        hbox.add(box)
        hbox.add(box1)
        self.add(hbox)
        self.roller_win.gtk_win.connect(
            'key_press_event', self.on_arrow_keypress
        )

    def draw_distribution(self):
        """
        Draw the processing Buttons.

        Return: Eventful
            contains group
        """
        w = fw.MARGIN
        box = Eventful(self.color)
        vbox = boxer(align=(0, 0, 1, 1))
        none_group = The.dog.none_group(**{wk.ITEM: Dust()})
        d = {
            wk.ANY_GROUP: none_group,
            wk.PADDING: PAD,
            wk.ROLLER_WIN: self.roller_win
        }

        box.add(vbox)

        q = self.get_distributor_q(d)
        alignment = gtk.Alignment(0, 0, 0, 0)
        table = gtk.Table(len(q), 1)
        option_count = len(q)
        color = self.color

        self.keep(q)
        table.set_row_spacings(1)
        alignment.set_padding(w, w, w, w)

        for x, i in enumerate(q):
            color = get_darker_color(color, option_count)
            color1 = color, color, co.MAX_COLOR
            box1 = Eventful(color1)

            box1.add(i)
            table.attach(box1, 0, 1, x, x + 1)

        alignment.add(table)
        vbox.add(alignment)
        return box

    def get_group_value(self):
        """
        Call before doing a View run.

        Return: list
            cell table
        """
        if self._edit_mode:
            return None
        return self._get_value_d()

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return self.cancel_cell_editor, self.accept_cell_editor

    def make_distributor_q(self, d):
        """
        Create a list of Widget for Preset distribution to the cell table.

        d: dict
            Has Widget init value.

        Return: list
            [Widget, ...]
        """
        # Widget, 'q'
        return [RadioRow(
            any_group=self.any_group,
            padding=(2, 0, 4, 0),
            relay=[self.set_edit_mode],
            roller_win=self.roller_win,
            text=("Apply", "Clear"),
            tips=(
                " Apply the option values. ",
                " Return value to the main option setting. "
            )
        ), CancelButton(
            **dict(d, relay=[])
        ), ProcessButton(
            **dict(d, relay=[self.apply_to_row], text="Row")
        ), ProcessButton(
            **dict(d, relay=[self.apply_to_column], text="Column")
        ), ProcessButton(
            **dict(d, relay=[self.apply_to_all], text="All Cell")
        ), ProcessButton(
            **dict(d, relay=[self.apply_checkerboard], text="Checkerboard")
        ), ProcessButton(
            **dict(d, relay=[self.apply_to_1st_half], text="Cell & 1st Half")
        ), ProcessButton(
            **dict(d, relay=[self.apply_to_2nd_half], text="Cell & 2nd Half")
        ), PlanButton(
            **dict(d, relay=[])), PreviewButton(**dict(d, relay=[])
        ), AcceptButton(
            **dict(d, relay=[self.apply_to_cell])
        )]

    def make_navigation(self, container):
        """
        Draw four horizontally oriented Buttons
        used to navigate the cell table.

        container: container
            container for the Buttons
        """
        w = fw.MARGIN
        box = Eventful(self.color)
        vbox = boxer()
        hbox = boxer(box=gtk.HButtonBox, align=(0, 0, 0, 0))
        d = {
            wk.ON_DIALOG_CLOSE: self.verify_nav_button,
            wk.ROLLER_WIN: self.roller_win
        }

        vbox.pack_start(
            Label(padding=(2, 4, 4, 0), text="Cell Navigation:")
        )
        vbox.pack_start(hbox, expand=False)
        box.add(vbox)
        container.pack_start(box, expand=False)
        hbox.set_padding(0, 0, w, w)

        self._north_button = NavButton(
            **dict(
                d,
                relay=[self._view_north_cell],
                text="↑",
                tooltip=Tip.NAVIGATION[0]
            )
        )
        self._south_button = NavButton(
            **dict(
                d,
                relay=[self._view_south_cell],
                text="↓",
                tooltip=Tip.NAVIGATION[1]
            )
        )
        self._west_button = NavButton(
            **dict(
                d,
                relay=[self._view_west_cell],
                text="←",
                tooltip=Tip.NAVIGATION[2]
            )
        )
        self._east_button = NavButton(
            **dict(
                d,
                relay=[self._view_east_cell],
                text="→",
                tooltip=Tip.NAVIGATION[3]
            )
        )
        for x, i in enumerate(
            (
                self._north_button,
                self._south_button,
                self._west_button,
                self._east_button
            )
        ):
            hbox.pack_start(i, expand=False)

    def on_arrow_keypress(self, _, event):
        """
        Check to see if the user pressed the control
        key and an arrow key at the same time.

        event: keypress
            looking for an arrow-key pressed Event

        Return: None or True
            Is true if the keypress is handled.
        """
        n = gtk.gdk.keyval_name(event.keyval)
        control_pressed = event.state & gtk.gdk.CONTROL_MASK
        if control_pressed and n in ('Left', 'Right', 'Up', 'Down'):
            self._do_control_arrow(n)
            return True

    def set_edit_mode(self, g):
        """
        Set the edit mode used by a processing Button.

        g: RadioRow
            Is responsible.
        """
        self._edit_mode = g.get_a()

    def set_widget_value(self):
        """Set Widget value. The current cell is at 'self.r_c'."""
        d = self.safe.get_a()

        if not d:
            d = deepcopy(self.safe.main_edit_d)

        self.any_group.get_preset_g().set_without_per(d)
        self.verify_nav_button()
        self._cell_label.widget.set_text(
            "Cell\tRow: {}\tColumn: {}".format(
                self.r_c[0] + 1, self.r_c[1] + 1
            )
        )

    def update_safe(self):
        """Update the cell table, the tooltip, and the Label color."""
        self.safe.set_a(self._get_value_d())

    def verify_nav_button(self, *_):
        """
        Verify the navigation Button given the current cell.
        Scan the cell table for a valid cell.
        """
        # the active cell index, 'r, c'
        r, c = self.r_c

        if r + 1 == self._row:
            self._south_button.disable()

        else:
            m = False

            for r1 in range(r + 1, self._row):
                if self._is_cell(r1, c):
                    m = True
                    break
            set_button(m, self._south_button)

        if r == 0:
            self._north_button.disable()

        else:
            m = False

            for r1 in range(r - 1, -1, -1):
                if self._is_cell(r1, c):
                    m = True
                    break
            set_button(m, self._north_button)

        if c + 1 == self._column:
            self._east_button.disable()

        else:
            m = False

            for c1 in range(c + 1, self._column):
                if self._is_cell(r, c1):
                    m = True
                    break
            set_button(m, self._east_button)

        if c == 0:
            self._west_button.disable()
        else:
            m = False

            for c1 in range(c - 1, -1, -1):
                if self._is_cell(r, c1):
                    m = True
                    break
            set_button(m, self._west_button)


class PortCellEditor(PortEditor):
    """Create a cell editor Port."""
    window_key = "Cell Editor"

    def __init__(self, d, g):
        """
        d: dict
            of PortCell

        g: PortCellEditor
            Is responsible.
        """
        PortEditor.__init__(self, d, g)

    def draw_navigation(self, vbox):
        self.make_navigation(vbox)

    def get_distributor_q(self, d):
        """
        Create Per Cell's Button list for processing Preset.

        d: dict
            Has common init variable.
        """
        return self.make_distributor_q(d)


class PortFaceEditor(PortEditor):
    """Create a cell and face editor Port."""
    window_key = "Face Editor"

    def __init__(self, d, g):
        self.face_x = 0
        self.face_index_g = None

        g.set_active_face(0)
        PortEditor.__init__(self, d, g)

    def apply_to_all_face(self, _):
        """Apply Widget value for all cells."""
        self.is_return_key = False

        self.safe.set_cell_faces(self._get_value_d())
        self.accept_preview()

    def make_face_row(self, container):
        """
        Draw four horizontally oriented Buttons
        used to navigate the cell table.

        container: container
            for the Buttons
        """
        w = fw.MARGIN
        box = Eventful(self.color)
        hbox = boxer(box=gtk.HButtonBox, align=(0, 0, 0, 0))
        self.face_index_g = RadioRow(
            any_group=self.any_group,
            key='face',
            padding=(2, 0, 4, 0),
            relay=[self.on_face_change],
            roller_win=self.roller_win,
            text=self.safe.model.get_face_text()
        )

        hbox.add(Label(padding=(2, 4, 4, 0), text="Face:"))
        hbox.pack_start(self.face_index_g)
        box.add(hbox)
        container.pack_start(box, expand=False)
        hbox.set_padding(0, 0, w, w)

    def draw_navigation(self, vbox):
        self.make_face_row(vbox)
        self.make_navigation(vbox)

    def get_distributor_q(self, d):
        """
        Insert a Face Group Button into the Per Cell's Button list.

        d: dict
            Has common init variable.
        """
        g_q = self.make_distributor_q(d)

        # The Button is inserted before "All Cell".
        g_q.insert(
            4,
            Button(
                **dict(d, relay=[self.apply_to_all_face], text="Face Group")
            )
        )
        return g_q

    def on_face_change(self, g):
        """
        Respond to change in the Face index Widget.
        Switch the Preset value on display.

        g: RadioButton
            Is responsible.
        """
        self.update_safe()

        self.face_x = self.face_index_g.get_a()

        self.safe.set_active_face(self.face_x)
        self.set_widget_value()
