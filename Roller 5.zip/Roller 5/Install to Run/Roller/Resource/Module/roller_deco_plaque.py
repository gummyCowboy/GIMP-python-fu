#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    finish_backed,
    make_cell_face_mask,
    make_cell_facing_mask,
    make_deco_material,
    make_main_face_mask,
    make_main_facing_mask,
    make_sel_mask,
    prep_backed,
    produce_main_facing,
    produce_per_facing,
    ready_canvas_rect,
    ready_shape,
    test_image,
    transform_foam
)
from roller_fu import load_selection, select_shape, verify_layer_group
from roller_view_real import make_group
import gimpfu as fu

PLAN_COLOR_D = {
    ny.CELL: fy.CELL_PLAQUE_COLOR,
    ny.CANVAS: fy.CANVAS_PLAQUE_COLOR,
    ny.FACE: fy.FACE_PLAQUE_COLOR,
    ny.FACING: fy.FACING_PLAQUE_COLOR
}
pdb = fu.pdb


def do(v, maya, make):
    """
    Create Plaque for a navigation branch.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    d = maya.value_d

    if not v.x:
        # Preserve.
        type_ = d[ok.TYPE]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = PLAN_COLOR_D[maya.any_group.render_key[-2]]

    v.deco.type_ = d[ok.TYPE]
    z = make(v, maya)

    if not v.x:
        # Restore.
        d[ok.TYPE] = type_
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_main_cell(v, maya):
    """
    Draw Cell/Per Plaque.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main)


def do_main_face(v, maya):
    """
    Draw Face Plaque for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_face)


def do_main_facing(v, maya):
    """
    Draw Facing Plaque for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_facing)


def do_canvas(v, maya):
    """
    Draw Canvas branch Plaque.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_canvas)


def do_cell(v, maya):
    """
    Draw Plaque for Cell/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell)


def do_face(v, maya):
    """
    Draw Face/Per Plaque.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_face)


def do_facing(v, maya):
    """
    Draw Facing/Per Plaque.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_facing)


def i_make_cell_face_mask(v, maya):
    """
    Apply the Mask option to Face/Per output.

    v: View
    maya: Maya
    Return: mask layer or None
    """
    return make_cell_face_mask(
        v, maya, maya.value_d[ok.MRW][ok.MASK]
    )


def i_make_cell_facing_mask(v, maya):
    """
    Apply the Mask option to Facing/Per output.

    v: View
    maya: Maya
    Return: mask layer or None
    """
    return make_cell_facing_mask(
        v, maya, maya.value_d[ok.MRW][ok.MASK]
    )


def i_make_main_face_mask(v, maya):
    """
    Apply Mask to Plaque Face main option settings.

    v: View
    maya: Maya
    Return: mask layer or None
    """
    return make_main_face_mask(
        v, maya, maya.value_d[ok.MRW][ok.MASK]
    )


def i_make_main_facing_mask(v, maya):
    """
    Apply Mask to Plaque Facing main option settings.

    v: View
    maya: Maya
    Return: mask layer or None
    """
    return make_main_facing_mask(
        v, maya, maya.value_d[ok.MRW][ok.MASK]
    )


def make_canvas(v, maya):
    """
    Draw Canvas Plaque material.

    v: View
    maya: Maya
    Return: layer or None
        with Plaque material
    """
    if test_image(v, maya):
        prep_backed(v, maya, maya.group)
        ready_canvas_rect(v, maya)

        z = make_deco_material(v, maya, maya.group)

        finish_backed(v)
        return z


def make_cell_face(v, maya):
    """
    Make Plaque for Face/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_per_facing(v, maya, make_face)


def make_cell_facing(v, maya):
    """
    Make Plaque for Facing/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_per_facing(v, maya, make_facing)


def make_cell(v, maya):
    """
    Make Plaque for a cell.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    if test_image(v, maya):
        prep_backed(v, maya, maya.group)
        ready_shape(v, maya)

        z = make_deco_material(v, maya, maya.group)

        finish_backed(v)
        return z


def make_face(v, maya, group):
    """
    Make Plaque for Face.

    v: View
    maya: Maya
    group: layer group
        Is the destination of Face layer output.
    """
    is_color = False
    model = maya.model
    k = maya.k
    go = test_image(v, maya)

    if v.deco.type_ in (dc.AVERAGE_COLOR, dc.COLOR):
        is_color = True

    if go:
        maya.rect = model.get_facing_rect(k)

        if is_color:
            v.deco.shape = model.get_facing_shape(k)

        else:
            maya.rect = model.get_facing_rect(k)
            v.deco.shape = model.get_facing_form(k)

        select_shape(v.j, v.deco.shape)

        z = make_deco_material(v, maya, group)
        if z and not is_color:
            transform_foam(v, maya.rect, z, model.get_facing_foam(k))


def make_facing(v, maya, group):
    """
    Make Plaque for Facing.

    v: View
    maya: Maya
    group: layer group
        Is the destination of Facing layer output.

    Return: layer or None
        with Facing Plaque
    """
    is_color = False
    k = maya.k
    model = maya.model
    go = test_image(v, maya)

    if go:
        if v.deco.type_ in (dc.AVERAGE_COLOR, dc.COLOR):
            is_color = True

        maya.rect = model.get_facing_rect(k)

        if is_color:
            v.deco.shape = model.get_facing_shape(k)

        else:
            maya.rect = model.get_facing_rect(k)
            v.deco.shape = model.get_facing_form(k)

        select_shape(v.j, v.deco.shape)

        z = make_deco_material(v, maya, group)

        if z and not is_color:
            z = transform_foam(v, maya.rect, z, model.get_facing_foam(k))
            model.clip_facing(z, k)
        return z


def make_main_face(v, maya):
    """
    Create Plaque Face for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_main_facing(v, maya, make_face)


def make_main_facing(v, maya):
    """
    Create Plaque Facing for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_main_facing(v, maya, make_facing)


def make_main(v, maya):
    """
    Create Plaque for the Cell branch main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    def _do_average_color():
        _parent = maya.group
        _group = make_group(v, "Material", _parent, offset=len(_parent.layers))

        prep_backed(v, maya, _group)

        for _k in maya.main_q:
            maya.k = _k

            ready_shape(v, maya)
            make_deco_material(v, maya, _group)

        finish_backed(v)
        return verify_layer_group(_group)

    def _do_one_material():
        _z = None

        prep_backed(v, maya, maya.group)

        # Create a single selection.
        # Image type is not one material, so there's no image check.
        pdb.gimp_selection_none(j)

        for _k in maya.main_q:
            maya.k = _k
            ready_shape(v, maya, option=fu.CHANNEL_OP_ADD)

        if test_image(v, maya):
            _z = make_deco_material(v, maya, maya.group)

        finish_backed(v)
        return _z

    def _do_many_material():
        """
        Inside a group, make a layer with its own material for each
        cell. Collapse the group and return the resulting layer.
        """
        _parent = maya.group
        _group = make_group(v, "Material", _parent, offset=len(_parent.layers))

        for _k in maya.main_q:
            maya.k = _k
            if test_image(v, maya):
                ready_shape(v, maya)
                make_deco_material(v, maya, _group)
        return verify_layer_group(_group)

    j = v.j

    if v.deco.type_ == dc.AVERAGE_COLOR:
        return _do_average_color()

    elif v.deco.type_ not in dc.PER_TYPE:
        # All the Plaque is the same
        # material and is applied one time.
        return _do_one_material()
    else:
        # All the Plaque is the same material,
        # but applied cell-by-cell.
        return _do_many_material()


def mask_main_cell(v, maya):
    """
    Mask a Plaque layer from the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        mask
    """
    j = v.j
    z = maya.matter
    d = maya.value_d
    sel = mask = None
    mask_d = d[ok.MRW][ok.MASK]

    pdb.gimp_selection_none(j)

    for k in maya.main_q:
        maya.k = k
        ready_shape(v, maya)

        if not pdb.gimp_selection_is_empty(j):
            make_sel_mask(v, maya, mask_d)

        if sel:
            load_selection(j, sel, option=fu.CHANNEL_OP_ADD)
            pdb.gimp_image_remove_channel(j, sel)
        if not pdb.gimp_selection_is_empty(j):
            sel = pdb.gimp_selection_save(j)

    if sel:
        pdb.gimp_image_remove_channel(j, sel)

    if not pdb.gimp_selection_is_empty(j):
        mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)
        pdb.gimp_layer_add_mask(z, mask)
    return mask
