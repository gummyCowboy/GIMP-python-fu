#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Fill as fl, Frame as ff, Gradient as fg
from roller_constant_key import Option as ok
from roller_frame import do_selection_material, grow_frame
from roller_frame_build import Build
from roller_fu import blur_selection, get_select_coord
from roller_maya import check_matter, check_mix_basic, make_frame_group
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_one_gegl import unsharp_mask
from roller_view_hub import set_fill_context, set_gimp_gradient
from roller_view_real import LIGHT
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: ShapeBurst
    Return: layer
        with the frame
    """
    # Shape Burst Preset dict, 'd'
    d = maya.value_d

    set_fill_context(fl.FILL_DICT)
    set_gimp_gradient(d[ok.SRW])
    pdb.gimp_context_set_gradient_blend_color_space(
        fu.GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(d[ok.IRR][ok.REVERSE])
    return do_selection_material(v, maya, do_sel, embellish, "Shape Burst")


def do_sel(v, maya, z):
    """
    Do the Frame for a selection.

    v: View
    maya: Maya

    z: layer
        to receive frame

    Return: layer
        with frame material
    """
    # Shape Burst Preset dict, 'd'
    d = maya.value_d

    grow_frame(v.j, d[ok.WIDTH], ff.RECTANGLE)

    x, y, x1, y1 = get_select_coord(v.j)

    pdb.gimp_drawable_edit_gradient_fill(
        z,
        fg.GRADIENT_TYPE_LIST.index(d[ok.SHAPED_TYPE]),
        0,                                         # offset
        1,                                         # yes, super-sample
        3,                                         # maximum super-sample depth
        .0,                                        # super-sample threshold
        1,                                         # yes, dither
        (x1 + x) / 2., (y1 + y) / 2.,              # start point
        x, y                                       # end point
    )
    return z


def embellish(v, maya, z):
    """
    Modify the frame material.

    v: View
    maya: ShapeBurst
    z: layer
        Has the frame.

    Return: layer
        with the frame
    """
    # Shape Burst Preset dict, 'd'
    d = maya.value_d

    pdb.gimp_selection_none(v.j)

    if d[ok.UNSHARP_AMOUNT] and d[ok.UNSHARP_RADIUS]:
        unsharp_mask(z, d[ok.UNSHARP_RADIUS], d[ok.UNSHARP_AMOUNT], .0)
        blur_selection(z, 1)

    if d[ok.IRR][ok.INVERT]:
        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)
    return z


class ShapeBurst(Build):
    """Create a frame from a shape-burst type of gradient."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        Build.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.IRR,), k_path + (ok.SRW,)],
            do_matter
        )

        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cause, self)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.OTHER)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Shape Burst Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)

        is_back = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], self.is_matter, is_change
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return is_back
