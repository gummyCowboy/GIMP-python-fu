#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Issue as vo
from roller_constant_key import BackdropStyle as by, Option as ok, Widget as wk
from roller_def_share import (
    AVERAGE_COLOR,
    BLUR,
    BUMP,
    IMAGE_CHOICE,
    INVERT,
    SWITCH,
    set_issue
)
from roller_one_extract import scour
from roller_widget_check_button import CheckButton
from roller_widget_option_button import OptionListButton
from roller_port_option_list import PortStyle

BACKDROP = OrderedDict([
    (ok.BLUR, deepcopy(BLUR)),
    (ok.FIT_IMAGE, {
        wk.VAL: 1,
        wk.WIDGET: CheckButton
    }),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
    (ok.BUMP, deepcopy(BUMP)),
    (ok.BACKDROP_STYLE, {
        wk.CHANGELESS: True,
        wk.DIALOG: PortStyle,
        wk.VAL: {
            ok.SWITCH: SWITCH[wk.VAL],
            by.AVERAGE_COLOR: scour({}, AVERAGE_COLOR, wk.VAL)
        },
        wk.WIDGET: OptionListButton
    })
])
set_issue(
    BACKDROP,
    (ok.BLUR, ok.FIT_IMAGE, ok.INVERT),
    vo.MATTER,
    ()
)
