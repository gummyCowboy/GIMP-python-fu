#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import sqrt
from roller_constant_for import Fill as fl, Frame as ff
from roller_constant_key import Option as ok
from roller_frame import Overlay, Noise, do_selection_material, grow_frame
from roller_frame_build import Build
from roller_fu import (
    blur_selection,
    clear_selection,
    color_fill_selection,
    get_select_coord,
    load_selection,
    select_rect
)
from roller_maya import check_matter, check_mix_wrap, make_frame_group
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_view_hub import (
    adjust_mean_value, set_fill_context, set_gimp_pattern
)
from roller_view_real import OVERLAY, LIGHT, add_wip_layer, get_light, get_noise
import colorsys
import gimpfu as fu

pdb = fu.pdb


def do_color(v, maya):
    """
    Make a pattern layer to overlay the frame.

    v: View
    maya: Maya
    Return: layer or None
        with pattern material
    """
    # the Cutout Plate Preset dict, 'd'
    d = maya.value_d

    a = maya.super_maya
    z = add_wip_layer(
        v, v.j, "Pattern", group=a.group, offset=get_light(a) + get_noise(a)
    )
    z.mode = fu.LAYER_MODE_MULTIPLY

    pdb.gimp_selection_none(v.j)
    set_fill_context(fl.FILL_DICT)
    set_gimp_pattern(d[ok.PATTERN])

    # x, y coordinate, '0'
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, .0, .0)
    adjust_mean_value(z)
    return z


def do_matter(v, maya):
    """
    Make a frame layer.

    v: View
    maya: CutoutPlate
    Return: layer
        with frame material
    """
    return do_selection_material(v, maya, do_sel, embellish, "Cutout Plate")


def do_rounded_edge(j, z, edge):
    """
    Create a color blend frame using a color and its luminosity.
    The round appearance is calculated using the unit circle formula,
    where 'x' is the luminosity step, and 'y' is the luminosity result.

        x**2 + y**2 = 1

    On entrance, expect a selection to add round edge.

    j: GIMP image
        work-in-progress

    z: layer
        to receive material

    edge: float
        the number of gradient edge steps
    """
    # the x-vector steps, 'f'
    f = 1. / max(1., (edge - 1.))

    # start color, RGB, 'q'
    # '255.' is the high-end of the range for the luminosity.
    q = colorsys.hsv_to_rgb(0., .0, 255. * sqrt(1. - f**2.))

    for i in range(int(edge)):
        if not pdb.gimp_selection_is_empty(j):
            a = pdb.gimp_selection_save(j)
            q = tuple([int(b) for b in q])

            grow_frame(j, 1., ff.ANGULAR)
            load_selection(j, a, option=fu.CHANNEL_OP_SUBTRACT)
            color_fill_selection(z, q)
            load_selection(j, a, option=fu.CHANNEL_OP_ADD)
            blur_selection(z, 2)

            # Equate luminosity with the y-intersect on the unit circle.
            y = f * (i + 1.)

            if y < 1:
                # red and green, '.0'
                q = colorsys.hsv_to_rgb(.0, .0, 255. * sqrt(1. - y**2.))
            pdb.gimp_image_remove_channel(j, a)


def do_sel(v, maya, z):
    """
    Make a frame for a selection.

    v: View
    maya: Maya

    z: layer
        to receive material
    """
    j = v.j

    # the Cutout Plate Preset dict, 'd'
    d = maya.value_d[ok.WRW][ok.WRAP_CU]

    x, y, x1, y1 = get_select_coord(j)
    w1 = d[ok.WIDTH]
    edge = min(d[ok.BEVEL_W], w1 // 2. - w1 % 2)

    # Frame width exceed edge width by at least one pixel.
    w1 = max(edge * 2. + 1., w1)

    x = x - w1 + edge
    y = y - w1 + edge
    w = x1 + w1 - edge
    h = y1 + w1 - edge

    # When the rounded edge is made, the edge space is filled.
    grow_frame(j, edge, ff.ROUNDED)

    # image plus edge, 'sel1'
    sel = pdb.gimp_selection_save(j)

    clear_selection(z)
    select_rect(j, x, y, w - x, h - y)
    load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

    pdb.gimp_image_remove_channel(j, sel)
    color_fill_selection(z, (255, 255, 255))
    do_rounded_edge(j, z, edge)
    return z


def embellish(maya, j, z):
    """
    Modify the frame material.

    j: GIMP image
        the View image

    z: layer
        Has frame material.

    Return: layer
        with frame material
    """
    blur_selection(z, 1)
    return z


class CutoutPlate(Build):
    """Create a rectangular frame with cutout space for the cause material."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP_CU

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in the Preset's vote dict.
            (Option key, ...)
        """
        self.do_color = do_color

        Build.__init__(
            self,
            any_group,
            super_maya,
            k_path + (ok.WRW, ok.WRAP_CU),
            do_matter
        )

        self.sub_maya[OVERLAY] = Overlay(
            any_group, self, k_path + (ok.WRW, ok.OVERLAY_CU), do_color
        )
        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.SRW, ok.NOISE_D)
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cause, self)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.OTHER)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame Cutout Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[OVERLAY].do(
            v, d[ok.WRW][ok.OVERLAY_CU], is_change, self.is_matter
        )
        self.sub_maya[ok.NOISE_D].do(
            v, d[ok.SRW][ok.NOISE_D], is_change, self.is_matter
        )

        is_back = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], self.is_matter, is_change
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return is_back
