#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_fu import (
    clone_layer,
    invert_and_desaturate,
    flip_layer,
    merge_layer_group,
    set_saturation
)
from roller_maya_style import Style
from roller_view_real import (
    add_sub_base_group,
    add_wip_layer,
    finish_style,
    insert_copy_above,
    make_layer_group
)
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Create a Crystal Cave Backdrop Style layer.

    v: View
    maya: Style
    Return: layer or None
        with Crystal Cave
    """
    def _flip():
        """Flip a layer both horizontally and vertically."""
        flip_layer(z2)
        flip_layer(z2, is_h=True)

    def _make_group():
        """
        Make a layer group.

        Return:
            group: layer
                new
        """
        return make_layer_group(j, "WIP", parent=parent, z=z)

    j = v.j
    d = maya.value_d
    a = v.glow_ball
    parent = add_sub_base_group(v, maya)
    seed_ = int(d[ok.SEED] + a.seed)
    z = add_wip_layer(v, maya, "Plasma")
    group = _make_group()

    # medium turbulence, '3.5'
    pdb.plug_in_plasma(j, z, seed_, 3.5)

    z1 = clone_layer(z, n="Erase")

    pdb.plug_in_emboss(
        j, z,
        a.azimuth,
        a.elevation,
        2,                  # depth
        1                   # emboss type
    )

    z2 = clone_layer(z, n="Linear Light")

    clone_layer(z2, n="Linear Light #2")
    pdb.plug_in_emboss(
        j, z1,
        a.azimuth,
        a.elevation,
        100,                # maximum depth
        1                   # emboss type
    )

    z1.mode = fu.LAYER_MODE_COLOR_ERASE

    pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
    pdb.gimp_image_reorder_item(j, z2, z2.parent, 0)

    z2.mode = fu.LAYER_MODE_LINEAR_LIGHT
    z = merge_layer_group(group)
    z.name = "Group #1"
    group = _make_group()
    z1 = clone_layer(z, n="Exclusion")
    z1.mode = fu.LAYER_MODE_EXCLUSION

    pdb.plug_in_despeckle(
        j, z,
        16,                     # radius
        3,                      # recursive adaptive
        64,                     # white cut-off
        191                     # black cut-off
    )

    pdb.plug_in_unsharp_mask(
        j, z,
        12.,                    # radius
        54.,                    # amount
        .0                      # threshold
    )

    for _ in range(3):
        pdb.plug_in_wind(
            j, z,
            10,                 # threshold
            0,                  # from left
            30,                 # strength
            0,                  # wind
            1                   # leading edge
        )

    z = merge_layer_group(group)
    z.name = "Group #2"
    group = _make_group()
    z1 = clone_layer(z, n="Plasma")
    z2 = clone_layer(z1, n="Dodge")

    # lowest turbulence, '1.'
    pdb.plug_in_plasma(j, z1, seed_, 1.)

    z1.mode = fu.LAYER_MODE_HSV_VALUE
    z1.opacity = 10.

    pdb.plug_in_erode(
        j, z,
        1,                      # propagate black
        7,                      # RGB channels
        1.,                     # full rate
        0,                      # direction mask
        0,                      # lower limit
        255                     # upper limit
    )
    _flip()

    z2.mode = fu.LAYER_MODE_DODGE
    z3 = insert_copy_above(v, z2, group.layers[0])
    z3.mode = fu.LAYER_MODE_DIFFERENCE
    z2.mode = fu.LAYER_MODE_HSV_VALUE
    z2.opacity = 50.

    _flip()

    z1.mode = fu.LAYER_MODE_BURN
    z1.opacity = 100.

    set_saturation(z1, -95.)

    z4 = insert_copy_above(v, z3, group.layers[0])
    z4.mode = fu.LAYER_MODE_HSV_VALUE

    pdb.gimp_image_remove_layer(j, z1)

    z5 = clone_layer(z4, n="Exclusion")
    z5.mode = fu.LAYER_MODE_EXCLUSION
    z5.opacity = 50.
    z = merge_layer_group(group)
    z.name = "Group #3"
    _make_group()
    z1 = clone_layer(z, n="Hard Light")

    # no linear, '0'
    pdb.gimp_drawable_invert(z1, 0)

    # blur horizontal, '3.'; blur vertical, '36.'
    pdb.plug_in_gauss_rle2(j, z1, 3., 36.)

    z1.mode = fu.LAYER_MODE_HARDLIGHT
    z1.opacity = 75.
    z = clone_layer(z1)
    z.mode = fu.LAYER_MODE_HARDLIGHT
    z.opacity = 65.
    z = merge_layer_group(parent)

    invert_and_desaturate(d[ok.IDR], z)
    return finish_style(z, "Crystal Cave")


class CrystalCave(Style):
    """Create Backdrop Style output."""
    is_dependent = False
    is_seeded = True

    def __init__(self, any_group, super_maya, k_path):
        k_path = [k_path, k_path + (ok.IDR,)]
        Style.__init__(self, any_group, super_maya, k_path, make_style)
