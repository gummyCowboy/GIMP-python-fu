#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice, randint
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clear_inverse_selection,
    merge_layer_group,
    select_item,
    select_rect
)
from roller_maya_style import Style, make_background
from roller_view_preset import combine_seed
from roller_view_real import add_sub_base_group, add_wip_layer, finish_style
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: NoiseRift
    Return: layer
        with the style material
    """
    def _add_noise():
        """Create noise."""
        _m = True

        if ok.NOISE_OPACITY in d:
            if not d[ok.NOISE_OPACITY]:
                _m = False
        if _m:
            # Generate noise line.
            # The horizontal and vertical sizes are randomized.
            pdb.plug_in_solid_noise(
                j, z,
                0,                      # no tile-able
                1,                      # yes, turbulent
                int(d[ok.SEED] + v.glow_ball.seed),
                int(d[ok.NOISE_AMOUNT]),
                float(randint(1, 3)),
                float(randint(1, 3)),
            )

            # Harden the noise.
            # The radius is randomized.
            pdb.plug_in_unsharp_mask(
                j, z,
                choice((1., 3.)),
                54.,                    # amount
                .0                      # threshold
            )

            # Remove the white noise.
            select_item(z)
            clear_inverse_selection(z)
            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))

            if d[ok.BLUR]:
                select_rect(v.j, *v.wip.rect)
                blur_selection(z, d[ok.BLUR])

    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya, z=make_background(v, maya, d))
    z = add_wip_layer(v, maya, "Noise", group=parent)

    combine_seed(v, d)
    _add_noise()
    pdb.gimp_selection_none(j)

    z = merge_layer_group(parent)

    if d[ok.INVERT]:
        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)
    return finish_style(z, "Noise Rift")


class NoiseRift(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BRW][ok.BACKGROUND][ok.TYPE] == bs.BACKDROP_IMAGE
        super(NoiseRift, self).do(v, d, is_change)
