#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_fu import blur_selection, clone_layer, merge_layer_group
from roller_maya_style import Style, make_background
from roller_view_real import add_sub_base_group, finish_style
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a style layer.

    v: View
    maya: SoftTouch
    Return: layer or None
        Has style material.
    """
    j = v.j
    d = maya.value_d
    z = make_background(v, maya, d)
    parent = add_sub_base_group(v, maya, z=z)
    z1 = clone_layer(z)

    blur_selection(z, 500)

    z1.name = "HSV Hue"
    z1.mode = fu.LAYER_MODE_HSV_HUE

    pdb.plug_in_gimpressionist(j, z1, "Painted_Rock")

    z = merge_layer_group(parent)

    if d[ok.INVERT]:
        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)
    return finish_style(z, "Soft Touch")


class SoftTouch(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BRW][ok.BACKGROUND][ok.TYPE] == bs.BACKDROP_IMAGE
        super(SoftTouch, self).do(v, d, is_change)
