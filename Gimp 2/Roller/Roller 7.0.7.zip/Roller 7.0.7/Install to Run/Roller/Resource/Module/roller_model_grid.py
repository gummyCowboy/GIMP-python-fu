#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import One
from roller_constant import Signal as si
from roller_constant_identity import Identity as de
from roller_many_rect import Rect
from roller_model import Model, Past
from roller_utility import seal
from roller_wip import Wip
from roller_polygon_route import CALC_POLYGON
from roller_preset import calc_margin, calc_shift_rect
from roller_step import find_canvas_margin

# Is ordered by step sequence.
CHAIN = (
    si.CANVAS_RECT_CALC,
    si.CANVAS_SHIFT_CHANGE,
    si.CANVAS_SHIFT_CALC,
    si.CANVAS_MARGIN_CHANGE,
    si.CANVAS_MARGIN_CALC,
    si.CELL_RECT_CHANGE,
    si.CELL_RECT_CALC,
    si.CELL_SHIFT_CHANGE,
    si.CELL_SHIFT_CALC,
    si.CELL_MARGIN_CHANGE,
    si.CELL_MARGIN_CALC
)


class GridPast(Past):
    """Record a view run's state of a Grid for future change determination."""
    def __init__(self, model):
        self._canvas_t = [None, None]
        self._canvas_pocket = [Rect(), Rect()]

        Past.__init__(self, model)
        for i in (
            (si.CANVAS_MARGIN_VIEW, self.on_canvas_margin_view),
            (si.CANVAS_SHIFT_VIEW, self.on_canvas_shift_view)
        ):
            self.connect(*i)

    def did_canvas_pocket(self, pocket):
        """
        Did the Canvas pocket change?

        pocket: Rect
            Compare with the snap-shot value.

        Return: list
            [Plan vote, Work vote]
            where a True vote is change
        """
        q = []

        for i in range(2):
            if self._canvas_pocket[i]:
                q.append(pocket.rect != self._canvas_pocket[i].rect)
            else:
                q.append(True)
        return q

    def did_canvas_rect(self, t):
        """
        Did the Canvas rectangle change?

        rect: tuple
            (x, y, w, h)

        Return: list
            [Plan vote, Work vote]
            where a True vote is change
        """
        return [t != i for i in self._canvas_t]

    def on_canvas_margin_view(self, _, i):
        """
        Respond to a Canvas/Margin viewing by recording its pocket.

        _: Past
            Sent the Signal.

        i: int
            plan or work view-type index
            0 or 1
        """
        self._canvas_pocket[i].rect = self._model.canvas_pocket.rect

    def on_canvas_shift_view(self, _, i):
        """
        Respond to a Canvas/Shift view by recording its 'canvas_rect'.

        _: Past
            Sent the Signal.

        i: int
            plan or work; view-type index; 0 or 1
        """
        self._canvas_t[i] = self._model.canvas_rect


class Grid(Model):
    """Factor Model having multiple row and/or column."""

    def __init__(self, model_name):
        """
        model_name: string
            Identify the model in a step-key (file storage type)
            and as a unique Node item.
        """
        Model.__init__(self, model_name, GridPast, CHAIN)

        self.canvas_rect = self.canvas_margin = .0, .0, .0, .0
        self.canvas_pocket = Rect()
        for i, p in (
            (si.CANVAS_SHIFT_CHANGE, self.on_canvas_shift_change),
            (si.CANVAS_MARGIN_CHANGE, self.on_canvas_margin_change),
        ):
            self.latch(self.baby, (i, p))

    def calc_canvas_pocket(self, arg):
        """
        Calculate Canvas/Margin.

        arg: tuple
            (Margin Preset, is sequence flag)
        """
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        self.canvas_margin = top, bottom, left, right = calc_margin(d)
        x, y, w, h = self.canvas_rect
        self.canvas_pocket.position = x + left, y + top
        self.canvas_pocket.size = w - left - right, h - top - bottom
        p(
            si.CANVAS_MARGIN_CALC,
            self.past.did_canvas_pocket(self.canvas_pocket)
        )

    def calc_canvas_shift(self, arg):
        """
        The Canvas rectangle is calculated from the
        WIP size and the Canvas/Shift Preset.

        arg: tuple
            (Shift Preset, is sequence flag)
        """
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        w, h = Wip.get_size()
        x, y, w1, h1 = calc_shift_rect(d)
        self.canvas_rect = x + Wip.x, y + Wip.y, w + w1, h + h1

        if not find_canvas_margin(self.model_name):
            self.canvas_pocket.rect = self.canvas_rect
            p(
                si.CANVAS_MARGIN_CALC,
                self.past.did_canvas_pocket(self.canvas_pocket)
            )
        else:
            p(
                si.CANVAS_RECT_CALC,
                self.past.did_canvas_rect(self.canvas_rect)
            )

    def init_model_cell(self, d):
        """
        Calculate cell, merged, and form value.

        d: dict
            Cell/Type Preset
            {Identity: value}

        Return: list
            [Plan vote, Work vote]
            Each vote is a vote for change.
        """
        o = One()
        self.goo_d = {}

        for k, a in d.items():
            setattr(o, k.lower().replace(" ", "_"), a)

        if o.grid_type == de.CELL_SIZE:
            o.column_width = seal(d[de.COLUMN_W], 1., self.canvas_pocket.w)
            o.row_height = seal(d[de.ROW_H], 1., self.canvas_pocket.h)
        return CALC_POLYGON[self.cell_shape](self, o)

    def on_canvas_margin_change(self, _, arg):
        """
        When Canvas/Margin has change, the Canvas pocket is updated.

        _: Baby
            Sent the signal.

        arg: tuple
            (Margin Preset, is sequence flag)
        """
        self.calc_canvas_pocket(arg)

    def on_canvas_shift_change(self, _, arg):
        """
        When Canvas/Shift has change, the Canvas rectangle is updated.

        _: Baby
            Sent the signal.

        arg: tuple
            (Shift Preset, is sequence flag)
        """
        self.calc_canvas_shift(arg)
