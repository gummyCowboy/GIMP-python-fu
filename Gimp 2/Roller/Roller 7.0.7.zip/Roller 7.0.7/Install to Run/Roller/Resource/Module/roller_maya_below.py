#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Signal as si, VoteType as vt
from roller_constant_identity import Identity as de
from roller_container import Deco, Run
from roller_gimp_image import check_matter, clip_to_wip, copy_below
from roller_gimp_layer import (
    clone_layer, remove_layer, select_opaque, select_layer
)
from roller_gimp_selection import invert_selection, select_rect
from roller_maya import on_global
from roller_maya_build import SubBuild
from roller_maya_layer import check_mix_basic
from roller_preset_mod import do_mod
from roller_gimp_mask import mask_from_maya
from roller_wip import Wip


def do_below_matter(maya):
    """
    Do Below's layer output for its super-maya's matter layer.

    maya: Below
    Return: layer or None
        Below 'matter'
    """
    j = Run.j
    group = maya.super_maya.group
    d = maya.value_d

    # When there is no Below matter layer, 'z'.
    z = None

    if group:
        # Below 'matter' layer, 'z'
        if Deco.bg_z:
            z = clone_layer(Deco.bg_z)

        else:
            z = copy_below(group)

        z.name = group.name + " Below"

        select_rect(j, *Wip.get_rect())
        do_mod(z, d[de.MOD])
        clip_to_wip(z)
    return z


class Below(SubBuild):
    """Manage Below layer output for work-view-type views."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (check_matter, 'matter'), (check_mix_basic, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            It's 'matter' layer alpha becomes the output mask
            for the the Below matter layer.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        self.is_no_mask = False

        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (de.MOD,), k_path + (de.MOD, de.BLUR_D)],
            do_below_matter
        )
        self.latch(any_group, (si.BACK_CHANGE, self.on_back_change))

    def do(self, d, is_back, is_mask):
        """
        Manage layer output during a view run.

        d: dict or None
            Below Preset

        is_back: bool or None
            Is True when the background has change.

        is_mask: bool
            If True, then the Below is masked from its above layer.

        Return: bool
            Is True if Below changed.
        """
        def _select_matter(_z, option=None):
            _p = select_opaque if d[de.OPAQUE] else select_layer

            _p(_z, option=option)
            if is_invert:
                invert_selection(Run.j)

        # background changed flag, 'm'
        m = False

        self.value_d = d
        self.go = d[de.SWITCH] and bool(self.super_maya.matter)

        if self.go:
            self.is_matter = self.is_matter or is_back

        else:
            # There's change if the matter layer is removed.
            m = bool(self.matter)

        self.realize()

        if self.matter and (self.is_matter or is_mask):
            is_invert = d[de.TYPE] == de.INVERT_MASK

            if d[de.TYPE] == de.MASK or is_invert:
                mask_from_maya(self.super_maya, self.matter, p=_select_matter)
                m = True
            else:
                z = self.matter.mask
                m = bool(z)
                remove_layer(z)

        self.reset_issue()
        return m

    def on_back_change(self, _, i):
        """
        The background changed.

        _: AnyGroup
            Sent the Signal.

        i: int
            view-type index; 0 or 1; plan or work
        """
        if i == self.view_i:
            arg = [None, None]
            arg[i] = True
            on_global(self, arg, vt.IS_BACK)
