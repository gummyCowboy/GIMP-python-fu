#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_accent_color_grid import draw_color_grid
from roller_constant_identity import Identity as de
from roller_frame import do_frame_with_filler
from roller_frame_alt import FrameBasic
from roller_def_access import get_default_d
from roller_image_render import Render


def do_matter(maya):
    """
    Make a frame.

    maya: Checker
    Return: layer
        Wrap 'matter'
    """
    return do_frame_with_filler(maya, make_pattern)


def make_pattern(z, d):
    """
    Make a black and white rectangle pattern.
    Assume selection is none.

    z: layer
        Receive pattern.

    d: dict
        Checker/Filler Preset

    Return: layer
        Has a checkerboard pattern.
    """
    j = Render.provide()
    e = get_default_d(de.COLOR_FILL)

    e.update(d)

    z = draw_color_grid(z, e)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    return z


class Checker(FrameBasic):
    filler_k = de.FILLER_CH
    kind = material = de.CHECKER
    wrap_k = de.WRAP_PA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
