#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_INTERSECT,
    CHANNEL_OP_REPLACE,
    CHANNEL_OP_SUBTRACT,
    LAYER_MODE_SOFTLIGHT,
    pdb
)
from random import uniform
from roller_constant import SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_frame_alt import Overlap
from roller_gegl import emboss, waves
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import add_layer, copy_below, make_group_layer
from roller_gimp_layer import (
    blur_selection,
    clear_inverse_selection,
    color_layer,
    color_selection,
    discard_mask,
    isolate_channel,
    select_layer
)
from roller_gimp_selection import select_channel
from roller_preset import combine_seed


def select_bump_color(z):
    """
    Create a bump selection.

    z: layer
        Is sampled.

    Return: state of selection
    """
    pdb.gimp_context_set_feather(1)
    pdb.gimp_context_set_feather_radius(3., 3.)

    # composite, '0'
    pdb.gimp_context_set_sample_criterion(0)

    pdb.gimp_context_set_sample_threshold(.33)
    pdb.gimp_image_select_color(
        z.image, CHANNEL_OP_REPLACE, z, (255, 255, 255)
    )


def select_bg_white(z):
    """
    Create a selection from white color. Inherit
    GIMP context settings from 'select_bump_color'.

    z: layer
        Is sampled.

    Return: state of selection
    """
    pdb.gimp_context_set_feather_radius(4., 4.5)
    pdb.gimp_context_set_sample_threshold(.13)
    pdb.gimp_image_select_color(
        z.image, CHANNEL_OP_REPLACE, z, (255, 255, 255)
    )


def do_matter(maya):
    """
    Make a frame.

    maya: Wrap type
    Return: layer
        Wrap 'matter'
    """
    j = Run.j
    d = maya.value_d
    cast_z = maya.cast.matter
    sc = None

    combine_seed(d)
    set_fill_context_default()

    # A mask interferes with 'clone_background'.
    discard_mask(maya.group)

    group = make_group_layer(j, maya.group, maya.get_light(), "Material")
    bump_z = add_layer(j, group, 0, "Bump")

    color_layer(bump_z, (48, 48, 48))
    select_layer(cast_z)

    if d[de.CLIP]:
        sc = pdb.gimp_selection_save(j)

    # Make a border overlapping the cast.
    pdb.gimp_selection_border(j,     int(sum(divmod(d[de.WIDTH], 2.))))

    color_selection(bump_z, (255, 255, 255))

    bg_z = copy_below(bump_z, n="Base")

    pdb.gimp_selection_none(j)
    waves(
        bump_z,
        x=uniform(.1, .9),
        y=uniform(.1, .9),
        amplitude=d[de.AMPLITUDE],
        period=d[de.PERIOD],
        phi=d[de.PHASE]
    )
    blur_selection(bump_z, d[de.SOFTEN] * 2.)
    select_bump_color(bump_z)

    if sc:
        select_channel(j, sc, option=CHANNEL_OP_SUBTRACT)

    sc1 = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    emboss(bump_z, Globe.azimuth, 45., int(d[de.SOFTEN]))
    isolate_channel(bump_z, sc1)

    bg_z.mode = LAYER_MODE_SOFTLIGHT

    blur_selection(bg_z, d[de.SOFTEN] * 2)
    select_bg_white(bg_z)
    pdb.gimp_image_select_item(j, CHANNEL_OP_INTERSECT, bump_z)
    clear_inverse_selection(bg_z)
    pdb.gimp_image_reorder_item(j, bg_z, group, 0)

    z = pdb.gimp_image_merge_layer_group(j, group)

    for i in (sc, sc1):
        if i:
            pdb.gimp_image_remove_channel(j, i)
    return z


class Glue(Overlap):
    """Create a translucent type of frame that has a gluey tube appearance."""
    is_embossed = True
    kind = material = de.GLUE
    wrap_k = de.WRAP_GL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Is responsible for the Maya.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        Overlap.__init__(self, any_group, super_maya, k_path, do_matter)

    def do(self, d, is_change):
        """
        Glue is background change sensitive.

        d: dict
            frame Preset

        is_change: bool
            Is the state of the super-maya's matter and/or mask.
        """
        self.sub_maya[sm.WRAP].is_matter |= Run.is_back
        super(Glue, self).do(d, is_change)
