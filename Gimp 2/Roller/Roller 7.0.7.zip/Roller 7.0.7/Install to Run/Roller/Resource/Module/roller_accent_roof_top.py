#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb    # type: ignore
from random import randint
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_context import set_fill_context_default
from roller_gimp_layer import color_selection
from roller_gimp_image import add_base_layer, add_sub_maya_group, add_wip_layer
from roller_gimp_selection import select_polygon, select_rect
from roller_maya_sub_accent import SubAccent
from roller_polygon import make_coord_list
from roller_preset import combine_seed
from roller_utility import make_2d_table
from roller_wip import Wip


def create_background(j, z, d, q_x, column, right):
    """
    Create a striped background for the stretched boxes.

    j: GIMP image
    z: layer
        Receive color column.

    q_x: list
    column: int
        Is the column count from the user interface.

    right_x: int
    """
    left, top, _, h = Wip.get_rect()
    for i, color in enumerate(d[de.COLOR_3][1:]):
        pdb.gimp_selection_none(j)

        for c in range(column):
            c1 = c * 2

            if i % 2:
                x = q_x[c1 + 1]
                w = q_x[c1 + 2] - x

            else:
                x = q_x[c1]
                w = q_x[c1 + 1] - x
            if left <= x < right:
                select_rect(
                    j, x, top, w, h, option=CHANNEL_OP_ADD
                )
        color_selection(z, color)


def do_matter(maya):
    """
    Make a matter layer.

    maya: RoofTop
    Return: layer or None
        'matter'
    """
    def _cell_is_valid(_r, _c):
        """
        The cells are double spaced, and the cell at (0, 0) is not a cell.

        _r, _c: numeric
            cell index

        Return: bool
            Is True if the cell is valid.
        """
        if is_odd and _r == 0 and _c == 0:
            return False
        return bool((_r % 2 and _c % 2) or (not _r % 2 and not _c % 2))

    def _do_left():
        """Select the left face of the box."""
        select_polygon(
            j,
            (x, y1, x1, y2, x1, bottom_y, x, bottom_y),
            option=CHANNEL_OP_ADD
        )

    def _do_right():
        """Select the right face of the box."""
        select_polygon(
            j,
            (x1, y2, x2, y1, x2, bottom_y, x1, bottom_y),
            option=CHANNEL_OP_ADD
        )

    def _do_top():
        """Select the top face of the box."""
        select_polygon(
            j,
            (x, y1, x1, y, x2, y1, x1, y2),
            option=CHANNEL_OP_ADD
        )

    def _get_previous_y():
        """
        Ensure that the boxes in the row above
        the current cell are above the current cell.

        Return: float
            y-coordinate of the limiting box
            at the lowest position in the graph.
        """
        _y = Wip.y - row_h
        _r = r - 1
        _c = c - 1
        _c1 = c + 1

        if _r >= 0:
            if _c >= 0 and _cell_is_valid(_r, _c):
                _y = table_y[_r][_c] + top_h
            if _r <= row and _c1 <= column:
                _y = max(y, table_y[_r][_c1] + top_h)
        return _y

    j = Run.j
    d = maya.value_d
    parent = add_sub_maya_group(maya)

    combine_seed(d)
    set_fill_context_default()

    # Calculate grid.
    row, column = int(d[de.ROW]), int(d[de.COLUMN])
    a, b = divmod(column, 2)
    double_column = a + b
    column_w = round(Wip.w / double_column)
    row_h = round(Wip.h / row)
    half_column_w = column_w / 2.
    top_h = min(half_column_w, row_h / 2.)
    bottom_y = Wip.y + Wip.h
    right = Wip.x + Wip.w
    is_odd = column % 2
    row1 = row + 1
    column1 = column + 1
    a = double_column * 2
    q_x = make_coord_list(Wip.w, a, Wip.x, pre=1, post=a)
    table_y = make_2d_table(row1, column1)

    # Limit random 'y' with row space.
    for r in range(row):
        y = Wip.y
        for c in range(column1):
            if _cell_is_valid(r, c):
                # Randomize height to get y.
                y = _get_previous_y()

                if r > 0:
                    y = float(randint(int(y), int(y + row_h)))

                else:
                    y = float(randint(int(y), int(y + top_h)))
                table_y[r][c] = y

    z = add_base_layer(parent, "Background")

    create_background(j, z, d, q_x, column, right)

    # Each row has its own layer.
    for r in range(row):
        z = add_wip_layer("Row " + str(r), parent)

        for i, color in enumerate(d[de.COLOR_3]):
            pdb.gimp_selection_none(j)
            for c in range(column1):
                if _cell_is_valid(r, c):
                    # Accumulate selection for color fill.
                    x = q_x[c]
                    x1 = q_x[c + 1]
                    x2 = q_x[c + 2]
                    y = table_y[r][c]
                    if y < bottom_y:
                        y1 = y + top_h
                        y2 = y1 + top_h
                        (_do_top, _do_left, _do_right)[i]()
            color_selection(z, color)

    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class RoofTop(SubAccent):
    """Create Accent output."""
    kind = de.ROOF_TOP

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)
