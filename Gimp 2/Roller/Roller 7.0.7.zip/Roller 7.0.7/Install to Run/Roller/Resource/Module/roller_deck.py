#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import LAYER_MODE_NORMAL, RGBA_IMAGE, pdb   # type: ignore
from roller_gimp_image import make_group_layer, paste_layer_into
from roller_gimp_layer import verify_layer


class Deck:
    """
    Manage a group layer where each of its
    layers become part of a merged group.
    """

    def __init__(self, j, parent, position, n):
        self.count = 0
        self.j = j
        self.group_name = n
        self._group = make_group_layer(j, parent, position, n)

    def add(self):
        """
        Add a layer to the top of the group layer.

        Return: layer
            new
        """
        self.check()

        j = self.j
        self.count += 1
        z = pdb.gimp_layer_new(
            j,
            j.width, j.height,
            RGBA_IMAGE,
            str(self.count),
            100.,                       # opacity
            LAYER_MODE_NORMAL
        )

        pdb.gimp_image_insert_layer(j, z, self._group, 0)
        return z

    def check(self):
        """
        If the number of layers in the group layer exceeds a limit,
        then merge the group layer, and recreate it placing the
        merged output into a new group layer.
        """
        if self.count > 9:
            # Compress group.
            self.count = 1
            j = self.j
            z = pdb.gimp_image_merge_layer_group(j, self._group)
            z.name = "1"
            self._group = make_group_layer(
                j,
                z.parent,
                pdb.gimp_image_get_item_position(j, z),
                self.group_name
            )
            pdb.gimp_image_reorder_item(j, z, self._group, 0)

    def exit(self):
        """
        Merge the group layer and verify that resulting layer.
        This an end of life event for a Deck instance.

        Return: layer
            verified merged result
        """
        return verify_layer(
            pdb.gimp_image_merge_layer_group(self.j, self._group)
        )

    def get_group(self):
        return self._group

    def insert(self, z):
        """
        Insert a layer at the top of the group layer.

        z: layer
            Insert into group.
        """
        self.check()

        self.count += 1
        pdb.gimp_image_insert_layer(self.j, z, self._group, 0)

    def merge(self):
        """
        Merge the group layer. Is the end of life for a Deck instance.

        Return: layer or None
            Merge group layer.
        """
        return pdb.gimp_image_merge_layer_group(self.j, self._group)

    def paste(self):
        """
        Paste the Gimp internal buffer on to the top of the Deck's group layer.

        Return: layer
            pasted result
        """
        self.check()

        self.count += 1
        return paste_layer_into(self.j, self._group, n=str(self.count))

    def update_count(self):
        """
        Count the number of layers in the
        group layer and update the internal counter.
        """
        self.count = len(self._group.layers)
