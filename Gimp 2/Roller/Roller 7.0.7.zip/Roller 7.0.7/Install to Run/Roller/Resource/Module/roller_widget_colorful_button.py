#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Color as co, Define as df, Signal as si
from roller_constant_identity import Identity as de
from roller_widget_box import Eventful
import gobject  # type: ignore
import gtk      # type: ignore


GTK_MASK_SET = {
    gtk.gdk.BUTTON_PRESS_MASK,
    gtk.gdk.FOCUS_CHANGE_MASK,
    gtk.gdk.KEY_PRESS_MASK
}


class ColorfulEvent(Eventful, gobject.GObject):
    """Factor ColorfulButton and PerCellButton."""
    # Are signals that can be emitted by this class.
    __gsignals__ = si.PER_BUTTON_DICT

    def __init__(self, **d):
        super(ColorfulEvent, self).__init__(None)

        # for custom signal(s)
        gobject.GObject.__init__(self)

        self._background_color = d[df.COLOR]
        self.any_group = d[df.ANY_GROUP]
        self._updater = d[df.RELAY]
        self.roller_win = d[df.ROLLER_WIN]
        self.key = d.get(df.KEY)

        # Embed the Widget inside a VBox and an HBox.
        g = self.label = gtk.Label(d[df.TEXT])
        g1 = self.hbox = gtk.HBox()

        self.add(g1)
        g1.add(g)

        # Respond to signal.
        for i in GTK_MASK_SET:
            self.add_events(i)

        self.set_can_focus(1)
        self.set_color(self._background_color)
        self.connect('key_press_event', self.on_key_press)
        self.connect('focus_in_event', self.focus_in)
        self.connect('focus_out_event', self.focus_out)

    def focus_in(self, *_):
        """Change the color of the button to show focus."""
        self.set_color(co.FOCUS_COLOR)
        return True

    def focus_out(self, *_):
        """Change the color of the button to normal."""
        self.set_color(self._background_color)
        return True

    def on_key_press(self, g, a):
        """
        Process 'space' and 'Return' keypress.

        g: self
        a: signal
            keypress event

        Return: None or True
            Is true when keypress is processed.
        """
        n = gtk.gdk.keyval_name(a.keyval)

        if n == 'space':
            self._updater(g)
            return True
        elif n == 'Return':
            g.roller_win.emit(si.ACCEPT_WINDOW, g)
            return True

    def set_color(self, color):
        """
        Set the button's face color.

        color: gtk.gdk.Color
            button color
        """
        self.modify_bg(gtk.STATE_NORMAL, color)

    def set_label(self, n):
        """
        Change the button's text.

        n: string
            for Label
        """
        self.label.set_text(n)

    def set_size(self, w=10, h=10):
        """
        Try to set the size of the button.

        w: int
            width of button

        h: int
            height of button
        """
        self.set_size_request(width=w, height=h)

    def set_text_color(self, color):
        """
        Set the color of the button's text.

        color: gtk.gdk.Color
            for the text
        """
        self.label.modify_fg(gtk.STATE_NORMAL, color)

    def show(self):
        """Display the custom button."""
        super(ColorfulEvent, self).show()
        for g in (self.hbox, self.vbox, self.label):
            g.show()


class ColorfulButton(ColorfulEvent):
    """Is a rectangle area that can change color and respond to signals."""

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        ColorfulEvent.__init__(self, **d)

        # Avoid the 'button_press_event' as it fails the Widget.
        self.connect('button_release_event', self.on_click)

    def on_click(self, *_):
        """Pass the click event to the button owner."""
        self.grab_focus()
        self._updater(self)
        return True


class PerCellButton(ColorfulEvent):
    """
    Is a rectangular area that can change color, respond
    to signal, and display a throw switch menu.
    """

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        ColorfulEvent.__init__(self, **d)

        self.get_owner_a = d[df.GET_A]
        self.throw_switch = d[df.SET_A]

        self.set_can_focus(1)
        self.set_color(self._background_color)

        # Avoid the 'button_press_event' as it fails the Widget.
        self.connect('button_release_event', self.on_colorful_button_click)

        self.menu = gtk.Menu()
        self.menu_item = gtk.MenuItem("Throw Switch")

        self.menu_item.connect('activate', self.on_throw_switch)
        self.menu.append(self.menu_item)
        self.menu_item.show()
        self.menu.show()

    def on_switchable_clicked(self, _, event):
        """
        React to a mouse button click on the button. If the
        button is right-clicked, create a popup menu.

        _: self
            not used

        event: gtk.gdk.Event
        """
        d = self.get_owner_a(self.key)
        a = d.get(de.SWITCH) if d else None
        if a is not None:
            # gtk right-mouse button enum, '3'
            if event.button == 3:
                self.menu.popup(None, None, None, event.button, event.time)

    def on_throw_switch(self, *_):
        """
        Respond to a throw switch request from the right-click popup menu.

        _: tuple
            (sender, signal)
            not  used
        """
        d = self.get_owner_a(self.key)
        if d:
            a = d.get(de.SWITCH, 0)
            d[de.SWITCH] = int(not a)
            self.throw_switch(d, self.key)

    def on_colorful_button_click(self, button, event):
        """Pass the click event to the button owner."""
        if event.button == 3:
            self.on_switchable_clicked(button, event)
        else:
            self.grab_focus()
            self._updater(self)


class SwitchButton(ColorfulButton):
    """Process cell connection events."""

    def __init__(self, r, c, **d):
        """
        Create the SwitchButton.

        r, c: int
            cell index

        d: dict
            Has init values.
        """
        self.gate = 0
        self.r = r // 2
        self.c = c // 2
        self._cell_table = d[df.CELL_TABLE]
        self.pad = d[df.CONTAINER]
        self.on_gate_action = d[df.RELAY]
        d[df.RELAY] = self.on_switch_action
        ColorfulButton.__init__(self, **d)

    def on_switch_action(self, _):
        """
        Reverse the switch setting. Call the connection operator.

        Return: True
            Tell GTK that the signal is handled.
        """
        i = self.gate = int(not self.gate)

        self.set_label(("+", "-")[i])
        self.on_gate_action[i](self._cell_table[self.r][self.c])
        return True


# Register the custom signals.
gobject.type_register(ColorfulEvent)
