#!/usr/bin/env python
# -*- coding: utf-8 -*-
# noinspection PyUnresolvedReferences
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD,
    CHANNEL_OP_INTERSECT,
    CHANNEL_OP_REPLACE,
    CHANNEL_OP_SUBTRACT,
    GRADIENT_BLEND_RGB_PERCEPTUAL,
    pdb
)
from random import randint
from roller_container import Cat
from roller_constant import Gradient as fg, Row as rk, Triangle as ft
from roller_constant_identity import Identity as de
from roller_deco_paint import paint_fringe
from roller_def_access import get_default_d
from roller_gimp_context import set_fill_context_default
from roller_gimp_gradient import get_gradient_points
from roller_gimp_image import (
    add_layer, image_copy_all, paste_layer, shape_clipboard
)
from roller_gimp_layer import (
    blur_selection,
    color_selection_default,
    discard_mask,
    make_polar_mask,
    make_text_layer,
    select_layer
)
from roller_gimp_layers import remove_layers
from roller_gimp_selection import (
    get_select_coord,
    get_select_bounds,
    select_channel,
    select_ellipse,
    select_polygon,
    select_rect
)
from roller_image_change import ref_get_image
from roller_polygon import (
    ROUTE_SHAPE,
    arrange_hexagon,
    arrange_hexagon_truncated,
    arrange_octagon,
    arrange_octagon_on_its_side,
    calc_hexagon_offset,
    calc_hexagon_truncated_offset,
    calc_octagon_offset,
    calc_octagon_on_its_side_offset,
    calc_parallelogram_left,
    calc_parallelogram_right
)
from roller_preset import combine_seed

"""
Define the container, 'o'.

o: One
    d: Mask Preset
    maya: Maya
        Is responsible for the Mask layer.

    scale: Rect
        Is the size of the mask influence. Is the product
        of the horizontal and vertical scales and 't'.

    t: Rect
        Is the size of the cast's alpha. Cast receives the mask.
"""


def calc_square_rect(o):
    """
    Calculate the dimension and position of a square scaled selection.

    o: One
    Return: tuple
        (w, x, y)
        Define a scaled square.
    """
    w = min(o.scale.w, o.scale.h)
    w1 = w / 2.
    x, y = o.t.center()
    return w, x - w1, y - w1


def do_circle(j, o):
    """
    Make a circle selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    w, x, y = calc_square_rect(o)
    select_ellipse(j, x, y, w, w)


def do_cut_corner_mask(j, o):
    """
    Make a cut corner selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    x, y, w, h = o.t.rect

    # the difference between scale and selection, 'w1, h1'
    w1 = (w - o.scale.w) / 2.
    h1 = (h - o.scale.h) / 2.

    # eight vertices defining segments
    q = (
        x + w1, y,
        x + w - w1, y,
        x + w, y + h1,
        x + w, y + h - h1,
        x + w - w1, y + h,
        x + w1, y + h,
        x, y + h - h1,
        x, y + h1
    )
    select_polygon(j, q)


def do_darks(j, o):
    """
    Make a selection based on the dark profile of a layer.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    do_polar_mask(j, o, is_dark=True)


def do_diamond(j, o):
    """
    Make a sheared diamond selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    w, h = o.scale.w / 2., o.scale.h / 2.
    x, y = o.t.center()

    # four vertices defining segments
    q = (
        x, y - h,
        x + w, y,
        x, y + h,
        x - w, y
    )
    select_polygon(j, q)


def do_ellipse(j, o):
    """
    Make an elliptical selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_ellipse(j, *o.scale.rect)


def do_ellipse_notch(j, o):
    """
    Cut an ellipse from each corner.

    j: GIMP image
    o: One
    Return: state of selection
    """
    x, y, w, h = o.t.rect
    scale_w, scale_h = o.scale.size

    # the difference between scale and selection, 'w1, h1'
    w1 = (w - scale_w) / 2.
    h1 = (h - scale_h) / 2.

    # x
    x1 = x - w1
    x2 = x + w - w1

    # y
    y1 = y - h1
    y2 = y + h - h1

    select_rect(j, *o.t.rect)

    w2 = w1 * 2
    h2 = h1 * 2
    for x, y in ((x1, y1), (x1, y2), (x2, y1), (x2, y2)):
        select_ellipse(j, x, y, w2, h2, option=CHANNEL_OP_SUBTRACT)


def do_eye(j, o):
    """
    Make an eye selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    do_eye_opening(j, o)

    x, y, x1, y1 = get_select_coord(j)
    h = y1 - y
    h1 = h * o.d[de.PUPIL_SCALE]
    w = x1 - x
    x2 = x + (w - h) / 2.
    offset = (h - h1) / 2.

    select_ellipse(
        j, x2, y + 1., h, max(1., h - 2.), option=CHANNEL_OP_SUBTRACT
    )
    select_ellipse(
        j, x2 + offset, y + offset, h1, h1, option=CHANNEL_OP_ADD
    )


def do_eye_opening(j, o):
    """
    Make an eye selection.

    Ellipse Radius Formula Reference
    rechneronline.de/pi/circular-segment.php

    Formula
    radius = (w² / 4 + h²) / 2 / h

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    w, h = o.scale.w, o.scale.h / 2.
    center_x, center_y = o.t.center()

    # topleft of eye rectangle, 'x, y'
    x = center_x - w / 2.
    y = center_y - h

    radius = (w * w / 4. + h * h) / 2. / h
    diameter = radius * 2.
    x = x - (diameter - w) / 2.

    select_ellipse(j, x, y, diameter, diameter)
    select_ellipse(
        j,
        x, y - diameter + o.scale.h,
        diameter, diameter,
        option=CHANNEL_OP_INTERSECT
    )


def do_fringe(j, o):
    """
    Cut a Fringe-like selection from cast.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    d = o.d
    sc = pdb.gimp_selection_save(j)
    e = get_default_d(de.FRINGE)
    n = e[de.TYPE] = de.COLOR
    e[de.CONTRACT] = d[de.CONTRACT]
    e[rk.RW1][de.BRUSH_D] = d[rk.RW1][de.BRUSH_D]
    z = add_layer(j, None, 0, "Selectable")

    pdb.gimp_selection_shrink(j, int(d[de.CONTRACT]))
    paint_fringe(z, e, n)
    select_channel(j, sc)
    pdb.gimp_image_select_item(j, CHANNEL_OP_SUBTRACT, z)
    pdb.gimp_image_remove_channel(j, sc)
    pdb.gimp_image_remove_layer(j, z)


def do_gradient(j, o):
    """
    Make a gradient selection. Create a selection
    based on alpha material from a gradient having
    a transparent and white segments.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    # Mask Preset dict, 'd'
    d = o.d

    # Is a temporary layer for the gradient, 'z'.
    z = add_layer(j, None, 0, "Gradient")

    # Determine the gradient's start and end points.
    x, x1, y, y1 = get_gradient_points(d, *o.scale.rect)

    # Create a temporary GIMP gradient to source the mask-selection from.
    grad = pdb.gimp_gradient_new("Roller-Temp-Mask")

    # segment index, '0'
    pdb.gimp_gradient_segment_set_left_color(grad, 0, (1., 1., 1., .0), .0)
    pdb.gimp_gradient_segment_set_right_color(grad, 0, (1., 1., 1., 1.), 100.)

    # Draw the gradient.
    set_fill_context_default()
    pdb.gimp_context_set_gradient(grad)
    pdb.gimp_context_set_gradient_blend_color_space(
        GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(0)
    pdb.gimp_drawable_edit_gradient_fill(
        z,
        fg.GRADIENT_TYPE_LIST.index(d[de.GRADIENT_TYPE]),
        0,                                  # offset
        1,                                  # yes, do super-sample
        3,                                  # max depth
        .0,                                 # super-sample threshold
        1,                                  # yes, dither
        x, y,                               # start point
        x1, y1                              # end point
    )

    # Select the alpha in the gradient rectangle.
    # The selection is the output of this function.
    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)

    # Clean-up.
    pdb.gimp_image_remove_layer(j, z)
    pdb.gimp_gradient_delete(grad)


def do_hexagon(j, o):
    """
    Make a hexagon selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    w, h = o.scale.w, o.scale.h
    center_x, center_y = o.t.center()

    # There are two possible solutions.
    # first solution
    w1, h1 = w, w * ft.SCALE_UP

    # Check for overflow.
    if h1 > h:
        # second solution
        w1, h1 = h * ft.SCALE_DOWN, h

    q = calc_hexagon_offset(w1, h1)
    select_polygon(
        j,
        arrange_hexagon(q, center_x - q[0], center_y - q[2], w1, h1)
    )


def do_hexagon_shear(j, o):
    """
    Make a sheared hexagon selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(
        j,
        arrange_hexagon(calc_hexagon_offset(*o.scale.size), *o.scale.rect)
    )


def do_hexagon_truncated_shear(j, o):
    """
    Make a sheared truncated hexagon selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(
        j,
        arrange_hexagon_truncated(
            calc_hexagon_truncated_offset(*o.scale.size), *o.scale.rect
        )
    )


def do_hexagon_truncated(j, o):
    """
    Make a truncated hexagon selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    center_x, center_y = o.t.center()
    w, h = o.scale.w, o.scale.h

    # There are two possible solutions.
    # first solution
    w1, h1 = h * ft.SCALE_UP, h

    # Check for overflow.
    if w1 > w:
        # second solution
        w1, h1 = w, w * ft.SCALE_DOWN

    q = calc_hexagon_truncated_offset(w1, h1)
    x = center_x - q[1]
    y = center_y - q[3]
    select_polygon(j, arrange_hexagon_truncated(q, x, y, w1, h1))


def do_image(j, o):
    """
    Make an image selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    pdb.gimp_selection_none(j)

    # mask index, '1'
    j1 = ref_get_image(o.maya.any_group, o.maya.k, 1)

    if j1:
        image_copy_all(j1)
        shape_clipboard(*o.scale.size)

        z1 = paste_layer(j.layers[0])

        pdb.gimp_layer_set_offsets(z1, int(o.scale.x), int(o.scale.y))
        pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z1)
        pdb.gimp_image_remove_layer(j, z1)


def do_lights(j, o):
    """
    Make a selection based on the lights profile of a layer.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    do_polar_mask(j, o)


def do_miter_square(j, o):
    """
    Make a square, rotated by 45 degrees, selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    w = min(o.scale.w, o.scale.h) / 2.
    x, y = o.t.center()
    q = (
        x, y - w,
        x + w, y,
        x, y + w,
        x - w, y
    )
    select_polygon(j, q)


def do_octagon(j, o):
    """
    Make an octagon selection.

    Reference
        'math.stackexchange.com/
        questions/22064/
        calculating-a-point-that-lies-on-an-ellipse-given-an-angle'

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    w, x, y = calc_square_rect(o)
    q = calc_octagon_offset(w, w)
    select_polygon(j, arrange_octagon(q, x, y, w, w))


def do_octagon_shear(j, o):
    """
    Make a sheared octagon selection.

    Reference to a Helpful Formula
        'math.stackexchange.com/
        questions/22064/
        calculating-a-point-that-lies-on-an-ellipse-given-an-angle'

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(
        j,
        arrange_octagon(calc_octagon_offset(*o.scale.size), *o.scale.rect)
    )


def do_octagon_on_its_side(j, o):
    """
    Make an Octagon on its side selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    w, x, y = calc_square_rect(o)
    q = calc_octagon_on_its_side_offset(w, w)
    select_polygon(j, arrange_octagon_on_its_side(q, x, y, w, w))


def do_octagon_on_its_side_shear(j, o):
    """
    Make a sheared octagon that its on its side selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(
        j,
        arrange_octagon_on_its_side(
            calc_octagon_on_its_side_offset(*o.scale.size), *o.scale.rect
        )
    )


def do_opaque(j, o):
    """
    Intersect the scale rectangle with the Maya's matter layer.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_layer(o.maya.matter)
    select_rect(j, *o.scale.rect, option=CHANNEL_OP_INTERSECT)


def do_parallelogram_left(j, o):
    """
    Make an parallelogram left selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(
        j, calc_parallelogram_left(o.scale, o.d[de.PARALLELOGRAM_SCALE])
    )


def do_parallelogram_right(j, o):
    """
    Make an parallelogram right selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(
        j, calc_parallelogram_right(o.scale, o.d[de.PARALLELOGRAM_SCALE])
    )


def do_rectangle_notch(j, o):
    """
    Make a plus sign selection.

    j: GIMP image
    o: One
    Return: state of selection
    """
    x, y, w, h = o.t.rect
    scale_w, scale_h = o.scale.size

    # the difference between scale and selection, 'w1, h1'
    w1 = (w - scale_w) / 2.
    h1 = (h - scale_h) / 2.
    x1 = x + w1
    x2 = x1 + scale_w
    x3 = x + w
    y1 = y + h1
    y2 = y1 + scale_h
    y3 = y + h
    select_polygon(j, (
        x, y1,
        x1, y1,
        x1, y,
        x2, y,
        x2, y1,
        x3, y1,
        x3, y2,
        x2, y2,
        x2, y3,
        x1, y3,
        x1, y2,
        x, y2
    ))


def do_rectangle(j, o):
    """
    Make a rectangle selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_rect(j, *o.scale.rect)


def do_rip(j, o):
    """
    Rip edge then select.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    d = o.d
    z = add_layer(j, None, 0, "Rip")
    amp = int(d[de.AMP])

    select_layer(o.maya.matter)
    select_rect(j, *o.scale.rect, option=CHANNEL_OP_INTERSECT)
    pdb.gimp_selection_shrink(j, max(6, amp + 1))
    color_selection_default(z, (255, 255, 255))
    combine_seed(d)
    pdb.gimp_selection_none(j)

    for _ in range(4):
        a = randint(0, 1)

        pdb.plug_in_shift(j, z, randint(1, amp), a)
        pdb.plug_in_shift(j, z, randint(1, amp), int(not a))

    # RGB mode, '0'
    pdb.plug_in_oilify(j, z, int(d[de.SMOOTH]), 0)

    # threshold all, '.0'
    pdb.plug_in_threshold_alpha(j, z, .0)

    blur_selection(z, 1.)
    pdb.gimp_image_remove_layer(j, z)


def do_rounded_corner(j, o):
    """
    Make a rounded corner selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    x, y = o.t.x, o.t.y
    w = o.t.w - o.scale.w
    h = o.t.h - o.scale.h

    # topleft
    select_ellipse(j, x, y, w, h)

    # top-right
    x1 = x + o.t.w - w

    select_ellipse(j, x1, y, w, h, option=CHANNEL_OP_ADD)

    # bottom-left
    y1 = y + o.t.h - h

    select_ellipse(j, x, y1, w, h, option=CHANNEL_OP_ADD)

    # bottom-right
    select_ellipse(j, x1, y1, w, h, option=CHANNEL_OP_ADD)

    # vertical rectangle
    x2 = x + w / 2.
    w1 = o.t.w - w

    select_rect(j, x2, y, w1, o.t.h, option=CHANNEL_OP_ADD)

    # horizontal rectangle
    y2 = y + h / 2.
    h1 = o.t.h - h
    select_rect(j, x, y2, o.t.w, h1, option=CHANNEL_OP_ADD)


def do_square(j, o):
    """
    Make a square selection.

    j: GIMP image
        Receive selection.

    maya: Maya
    Return: state of selection
    """
    w, x, y = calc_square_rect(o)
    select_rect(j, x, y, w, w)


def do_text(j, o):
    """
    Make a text selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    font = o.d[de.FONT]

    if font not in Cat.font_list:
        font = Cat.font_list[0] if Cat.font_list else None
    if font is not None:
        font_size = max(o.scale.w, o.scale.h)
        character = o.d[de.TEXT]
        if character:
            z = add_layer(j, None, 0, "Text")
            go, z1 = make_text_layer(
                j, z,
                0,                      # no antialias
                character,
                font_size,
                font,
                (255, 255, 255),
                o.t.x, o.t.y,
                o.scale.w, o.scale.h
            )
            if go:
                pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z1)

                is_sel, x, y, x1, y1 = get_select_bounds(j)

                if is_sel:
                    center_x, center_y = o.t.center()
                    x = center_x - (x1 - x) / 2.
                    y = center_y - (y1 - y) / 2.

                    pdb.gimp_layer_set_offsets(z1, int(x), int(y))
                    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z1)
                remove_layers((z, z1))


def do_triangle_bottom_left(j, o):
    """
    Select half of a scaled rectangle with a triangle
    positioned in the bottom-left corner of the rectangle.

    j: GIMP image
    o: One
    Return: state of selection
    """
    x, y, w, h = o.scale.rect
    x1 = x + w
    y1 = y + h
    select_polygon(j, (x, y, x1, y1, x, y1))


def do_triangle_bottom_right(j, o):
    """
    Select half of a scaled rectangle with a triangle
    positioned in the bottom-right corner of the rectangle.

    j: GIMP image
    o: One
    Return: state of selection
    """
    x, y, w, h = o.scale.rect
    x1 = x + w
    y1 = y + h
    select_polygon(j, (x1, y, x1, y1, x, y1))


def do_triangle_topleft(j, o):
    """
    Select half of a scaled rectangle with a triangle
    positioned in the topleft corner of the rectangle.

    j: GIMP image
    o: One
    Return: state of selection
    """
    x, y, w, h = o.scale.rect
    x1 = x + w
    y1 = y + h
    select_polygon(j, (x, y, x1, y, x, y1))


def do_triangle_top_right(j, o):
    """
    Select half of a scaled rectangle with a triangle
    positioned in the top-right corner of the rectangle.

    j: GIMP image
    o: One
    Return: state of selection
    """
    x, y, w, h = o.scale.rect
    x1 = x + w
    y1 = y + h
    select_polygon(j, (x, y, x1, y, x1, y1))


def do_triangle_down_regular(j, o):
    """
    Make a down-facing regular triangle selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(j, ROUTE_SHAPE[de.TRIANGLE_DOWN_REGULAR](o.scale))


def do_triangle_down_shear(j, o):
    """
    Make a sheared down-facing triangle selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(j, ROUTE_SHAPE[de.TRIANGLE_DOWN_SHEAR](o.scale))


def do_triangle_left_regular(j, o):
    """
    Make a left-facing regular triangle selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(j, ROUTE_SHAPE[de.TRIANGLE_LEFT_REGULAR](o.scale))


def do_triangle_left_shear(j, o):
    """
    Make a sheared left-facing triangle selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(j, ROUTE_SHAPE[de.TRIANGLE_LEFT_SHEAR](o.scale))


def do_triangle_right_regular(j, o):
    """
    Make a right-facing regular triangle selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(j, ROUTE_SHAPE[de.TRIANGLE_RIGHT_REGULAR](o.scale))


def do_triangle_right_shear(j, o):
    """
    Make a sheared right-facing triangle selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(j, ROUTE_SHAPE[de.TRIANGLE_RIGHT_SHEAR](o.scale))


def do_triangle_up_regular(j, o):
    """
    Make an up-facing regular triangle selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(
        j, ROUTE_SHAPE[de.TRIANGLE_UP_REGULAR](o.scale))


def do_triangle_up_shear(j, o):
    """
    Make a sheared up-facing triangle selection.

    j: GIMP image
        Receive selection.

    o: One
    Return: state of selection
    """
    select_polygon(j, ROUTE_SHAPE[de.TRIANGLE_UP_SHEAR](o.scale))


def dispatch_corner(j, o):
    """
    Dispatch corner mask function depending on the Corner Type.

    j: Image
    o: One
    Return: state of selection
    """
    p = ROUTE_CORNER.get(o.d[de.CORNER_TYPE])
    if p:
        p(j, o)


def dispatch_hexagon(j, o):
    """
    Dispatch Hexagon Mask function.

    j: Image
    o: One
    Return: state of selection
    """
    p = ROUTE_HEXAGON.get(o.d[de.HEXAGON_TYPE])
    if p:
        p(j, o)


def dispatch_octagon(j, o):
    """
    Dispatch Octagon Mask function.

    j: Image
    o: One
    Return: state of selection
    """
    p = ROUTE_OCTAGON.get(o.d[de.OCTAGON_TYPE])
    if p:
        p(j, o)


def dispatch_rectangle(j, o):
    """
    Dispatch Rectangle Mask function.

    j: Image
    o: One
    Return: state of selection
    """
    p = ROUTE_RECTANGLE.get(o.d[de.RECTANGLE_TYPE])
    if p:
        p(j, o)


def dispatch_triangle(j, o):
    """
    Dispatch Triangle Mask function.

    j: Image
    o: One
        Contain mask variable.

    Return: state of selection
    """
    p = ROUTE_TRIANGLE.get(o.d[de.TRIANGLE_TYPE])
    if p:
        p(j, o)


def do_polar_mask(j, o, is_dark=False):
    """
    Make a selection based on a lights or darks profile of a layer.

    j: GIMP image
        Receive selection.

    o: One
        Contain mask variable.

    is_dark: bool
        If it is True, the mask hides the light-side pixels.
    """
    z = o.maya.matter

    make_polar_mask(z, is_dark=is_dark)
    do_rectangle(j, o)
    pdb.gimp_image_select_item(j, CHANNEL_OP_INTERSECT, z.mask)
    discard_mask(z)


# {mask type: make mask-selection function}
ROUTE_CORNER = {
    de.CUT_CORNER: do_cut_corner_mask,
    de.ELLIPSE_NOTCH: do_ellipse_notch,
    de.RECTANGLE_NOTCH: do_rectangle_notch,
    de.ROUNDED_CORNER: do_rounded_corner
}
ROUTE_HEXAGON = {
    de.HEXAGON: do_hexagon,
    de.HEXAGON_SHEAR: do_hexagon_shear,
    de.HEXAGON_TRUNCATED: do_hexagon_truncated,
    de.HEXAGON_TRUNCATED_SHEAR: do_hexagon_truncated_shear
}
ROUTE_OCTAGON = {
    de.OCTAGON: do_octagon,
    de.OCTAGON_SHEAR: do_octagon_shear,
    de.OCTAGON_ON_ITS_SIDE: do_octagon_on_its_side,
    de.OCTAGON_ON_ITS_SIDE_SHEAR: do_octagon_on_its_side_shear,
}
ROUTE_RECTANGLE = {
    de.MITER_SQUARE: do_miter_square,
    de.RECTANGLE: do_rectangle,
    de.SQUARE: do_square
}
ROUTE_TRIANGLE = {
    de.TRIANGLE_BOTTOM_LEFT: do_triangle_bottom_left,
    de.TRIANGLE_BOTTOM_RIGHT: do_triangle_bottom_right,
    de.TRIANGLE_DOWN_REGULAR: do_triangle_down_regular,
    de.TRIANGLE_DOWN_SHEAR: do_triangle_down_shear,
    de.TRIANGLE_LEFT_REGULAR: do_triangle_left_regular,
    de.TRIANGLE_LEFT_SHEAR: do_triangle_left_shear,
    de.TRIANGLE_RIGHT_REGULAR: do_triangle_right_regular,
    de.TRIANGLE_RIGHT_SHEAR: do_triangle_right_shear,
    de.TRIANGLE_TOP_RIGHT: do_triangle_top_right,
    de.TRIANGLE_TOPLEFT: do_triangle_topleft,
    de.TRIANGLE_UP_REGULAR: do_triangle_up_regular,
    de.TRIANGLE_UP_SHEAR: do_triangle_up_shear
}
ROUTE_MASK = {
    de.CIRCLE: do_circle,
    de.CORNER: dispatch_corner,
    de.DARKS: do_darks,
    de.DIAMOND: do_diamond,
    de.ELLIPSE: do_ellipse,
    de.EYE_OPENING: do_eye_opening,
    de.EYE: do_eye,
    de.FRINGE: do_fringe,
    de.GRADIENT: do_gradient,
    de.HEXAGON: dispatch_hexagon,
    de.IMAGE: do_image,
    de.LIGHTS: do_lights,
    de.OCTAGON: dispatch_octagon,
    de.OPAQUE: do_opaque,
    de.PARALLELOGRAM_LEFT: do_parallelogram_left,
    de.PARALLELOGRAM_RIGHT: do_parallelogram_right,
    de.RECTANGLE: dispatch_rectangle,
    de.RIP: do_rip,
    de.TEXT: do_text,
    de.TRIANGLE: dispatch_triangle
}
