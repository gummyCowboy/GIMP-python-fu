#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_helm import Helm
from roller_image_ref import Ref
from roller_image_type import INIT_TYPE_STATE, TYPE_CLASS, get_precursor_state
from roller_preset import get_option_list_choice


def _assign_group_ref(any_group, type_loaded):
    """
    Assign reference for the AnyGroup.
    Load/complete a file reference with Maya.

    any_group: AnyGroup
        Assign images for this group.

    type_loaded: set
        Init indices only once.
        When a type is loaded, it's an initial state for a Type
        instance indicating that first reference is being assigned.
    """
    d = Ref.grid_ref_d[any_group.id]
    value_d = any_group.get_value_d()
    wait_q = []
    any_group_i = Ref.any_group_q.index(any_group)
    a = any_group.image_slot_count

    for k in any_group.get_keys():
        is_first = False

        # list of image assignments for an assignee, 'q'
        # It's length is dependent upon the Preset.
        q = d.get(k)

        if q is None:
            # Initialize.
            q = d[k] = [[None] * a, [None] * a]

        type_key_q, single_q = q

        if k is None:
            # Canvas
            e = value_d

        else:
            e = value_d[de.PER].get(k)
            if e is None:
                e = value_d

        for i in range(a):
            b = type_k = None

            # Image Choice Preset, 'd1'
            # The list is ordered for the getter. This is the setter phase.
            d1 = [_get_main_d, _get_mask_d, _get_frame_d][i](any_group, e)

            if d1:
                n = d1[de.TYPE]
                type_ = TYPE_CLASS[n]
                type_k = type_.make_key(d1)
                b = Ref.type_d.get(type_k)

                if b is None:
                    b = Ref.type_d[type_k] = type_(d1, type_k)
                    Ref.state_d[type_k] = {-1: INIT_TYPE_STATE}
                    is_first = True
                    type_loaded.add(type_k)
                else:
                    if type_k not in type_loaded:
                        type_loaded.add(type_k)
                        is_first = True

            type_key_q[i] = type_k

            if b:
                waiter = type_k, b

                if b.is_wait:
                    # Redo assignment from the beginning of AnyGroup.
                    single_q[i] = b
                    if waiter not in wait_q:
                        wait_q.append(waiter)
                else:
                    # Assign image image reference
                    # for recall during a view run.
                    single_q[i] = b.start(any_group_i) \
                        if is_first else b.resume(any_group_i)
                    if b.is_wait and waiter not in wait_q:
                        wait_q.append(waiter)
            else:
                single_q[i] = None
    for q in wait_q:
        # Each Type is waiting for a file load.
        # Type instance, 'type_'
        type_k, type_ = q
        for k, q1 in d.items():
            type_key_q, single_q = q1
            for i, k1 in enumerate(type_key_q):
                if k1 == type_k:
                    # Have the Type instance to redo its entire solution.
                    single_q[i] = type_

        state = get_precursor_state(type_k, any_group_i)
        Ref.state_d[type_k][any_group_i] = state
        type_.set_state(state)


def _clear_follower(i):
    """
    Remove precursor state for a changed AnyGroup.

    i: int
        changed-AnyGroup index
    """
    for d in Ref.state_d.values():
        for k in d.keys():
            if k >= i:
                d.pop(k)


def _get_frame_d(any_group, d):
    """
    Get the Image Choice dict in a Frame-type.

    d: dict
        Preset

    Return: dict or None
        Image Choice Preset
    """
    if d[de.SWITCH]:
        e = d[any_group.frame_row_k].get(de.FRAME)
        if e[de.SWITCH]:
            k, d1 = get_option_list_choice(e)
            if k == de.OVER:
                d2 = d1[rk.BRW][de.OVERLAY_OV]
                if d2[de.TYPE] == de.IMAGE:
                    d3 = d2[de.IMAGE_CHOICE]
                    if d3[de.SWITCH]:
                        return d3


def _get_main_d(any_group, d):
    """
    Get the Image Choice dict in main.

    d: dict
        Preset

    Return: dict or None
        Image Choice Preset
    """
    return any_group.get_image_d(d)


def _get_mask_d(_, d):
    """
    Get the Image Choice dict in Mask.

    d: dict
        Preset

    Return: dict or None
        Image Choice Preset
    """
    if d[de.SWITCH]:
        e = d[rk.RW1][de.MASK]
        if e[de.SWITCH] and e[de.TYPE] == de.IMAGE:
            d1 = e[rk.RW1][de.IMAGE_CHOICE]
            if d1[de.SWITCH]:
                return d1


def on_global_seed(*_):
    for i, a in enumerate(Ref.any_group_q):
        if a in Ref.image_q:
            Ref.change_q.add(i)


def on_helm_change(_, step_q):
    """
    Receive Helm change signal.

    _: Ring or None
        not used

    step_q: list
        [Model-name-step-key, ...]
    """
    # Reset assignment.
    Ref.any_group_q = []
    Ref.image_q = set()
    Ref.change_q = set()
    Ref.step_q = step_q
    Ref.state_d = {}

    # Load the workload set.
    for i, k in enumerate(step_q):
        any_group = Helm.get_group(k)
        if any_group:
            Ref.any_group_q.append(any_group)

            # Add missing.
            if hasattr(any_group, 'image_slot_count'):
                Ref.image_q.add(any_group)
                Ref.change_q.add(i)
                any_group.changed()
                if any_group.id not in Ref.grid_ref_d:
                    Ref.grid_ref_d[any_group.id] = OrderedDict()

    id_list = [i.id for i in Ref.any_group_q]

    # k: AnyGroup.id
    for k in Ref.grid_ref_d.keys():
        if k not in id_list:
            Ref.grid_ref_d.pop(k)


def on_ring_empty(_, __, type_loaded=None):
    """
    Process workload when nothing else is happening.

    _: Ring or None
        not used

    __: None
    type_loaded: set
        {type key, ...}
        Remember previous initialized type during image assignment.
    """
    if Ref.change_q:
        if type_loaded is None:
            type_loaded = set()

        i = min(Ref.change_q)
        Ref.change_q -= {i}
        any_group = Ref.any_group_q[i]
        _assign_group_ref(any_group, type_loaded)


def ref_get_image(any_group, k, i):
    """
    Fetch the GIMP image assigned for an AnyGroup.

    any_group: AnyGroup
        Has a grid of image reference.

    k: tuple
        Goo or Map key

    i: int
        index of the image reference in the 'grid_ref_d' value.
        The index is ordered by image user:
            0: cast
            1: mask
            2: frame

    Return: GIMP image or None
        Is the outcome of a Preset's image reference.
    """
    if Ref.change_q:
        # Some changes occur during a view run.
        ref_on_view_run()

    # reference dict, 'a'
    # a -> {Goo key: View reference list}
    # View reference list -> [Plan reference list, Work reference list]
    # reference list -> [main, mask, frame] where each is an image reference
    a = Ref.grid_ref_d.get(any_group.id)
    if a:
        single_q = a[k][1]
        single = single_q[i]
        if single:
            return single.get_image(
                single_q, i, Ref.any_group_q.index(any_group)
            )


def ref_get_image_name(any_group, k, i):
    """
    Fetch the image name for an AnyGroup.

    any_group: AnyGroup
        Has a grid of image reference.

    k: tuple
        Goo or Map key

    i: int
        index of the image reference in the 'grid_ref_d' value.
        The index is ordered by image user:
            0: cast
            1: mask
            2: frame

    Return: string or None
        image name
    """
    single_q = Ref.grid_ref_d[any_group.id][k][1]
    single = single_q[i]
    if single:
        return single.name


def ref_on_grid_change(any_group, q):
    """
    Respond to Cell/Type option change.

    any_group: AnyGroup
        Has change.

    q: list
        [goo or map key, ...]
    """
    # Warning: calling 'ref_on_group_change'
    # from here produces an infinite loop.

    d = Ref.grid_ref_d[any_group.id] = OrderedDict()
    a = any_group.image_slot_count

    for i in q:
        # Init each reference.
        # [type-handler list, Single assignment list]
        d[i] = [[None] * a, [None] * a]
    on_global_seed()


def ref_on_group_change(any_group, *_):
    """
    Respond to AnyGroup option change.

    any_group: AnyGroup
        One of its options has change.

    _: tuple
        (None,)
    """
    if any_group not in Ref.any_group_q:
        on_helm_change(None, Helm.get_step_q())
    if any_group in Ref.any_group_q:
        i = Ref.any_group_q.index(any_group)

        _clear_follower(i)
        for i1 in range(i, len(Ref.any_group_q), 1):
            if Ref.any_group_q[i1] in Ref.image_q:
                Ref.change_q.add(i1)


def ref_on_view_run():
    """Finish doing the workload."""
    type_loaded = set()
    while Ref.change_q:
        on_ring_empty(None, None, type_loaded=type_loaded)
