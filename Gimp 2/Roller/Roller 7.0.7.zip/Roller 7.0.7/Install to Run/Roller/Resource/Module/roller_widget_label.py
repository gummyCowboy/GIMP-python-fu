#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Define as df, Signal as si
from roller_widget import Widget
import gtk  # type: ignore


class Label(Widget):
    """Is a custom GTK Label."""
    change_signal = None
    has_table_label = False

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        g = gtk.Label(d[df.TEXT])

        if not d.get(df.ALIGN):
            d[df.ALIGN] = 0, 0, 0, 0

        Widget.__init__(self, g, **d)
        self.add(g)

    @staticmethod
    def get_ui():
        return None

    def set_label_value(self, a):
        """
        Change the display value of the Label.

        a: string
            the new display value
        """
        if isinstance(a, str):
            self.widget.set_label(a)

    def set_ui(self, a):
        """
        a: undefined
            not used
        """
        return


class CoverLabel(Label):
    """Use with a Image Choice as documentation."""
    def __init__(self, **d):
        """
        d: dict
            Has init value.
        """
        d[df.TEXT] = \
            "If necessary, the image is resized so that it can fill\n" \
            "the rectangle to the greatest degree. The method may\n" \
            "enlarge the image with a locked aspect ratio. In the\n" \
            "process, a portion of the image may be clipped. The\n" \
            "image justification determines the clipped side."
        Label.__init__(self, **d)


class LockedLabel(Label):
    """Use with an Image Choice dialog as documentation."""
    def __init__(self, **d):
        """
        d: dict
            Has init value.
        """
        d[df.TEXT] = \
            "The images proportions are locked and a best fit\n" \
            "is applied if necessary. The image is not enlarged."
        Label.__init__(self, **d)


class FilledLabel(Label):
    """Use with a Image Choice as documentation."""
    def __init__(self, **d):
        """
        d: dict
            Has init value.
        """
        d[df.TEXT] = \
            "The image is resized so that it fills the rectangle.\n" \
            "Its aspect ratio will be that of the rectangle."
        Label.__init__(self, **d)


class NextXLabel(Label):
    """Use with an Image Choice dialog as documentation."""
    def __init__(self, **d):
        """
        d: dict
            Has init value.
        """
        d[df.TEXT] = \
            " Assign an image using an index variable. \n" \
            " Begin with the the left image tab\n" \
            " and end with the last right image tab."
        Label.__init__(self, **d)


class PreviousXLabel(Label):
    """Describe within an Image Choice dialog the Previous option."""
    def __init__(self, **d):
        """
        d: dict
            Has init value.
        """
        d[df.TEXT] = \
            " Assign an image using an index \n" \
            " variable. Begin with the right image tab \n" \
            " and end with the left image tab. "
        Label.__init__(self, **d)


class PropertyTypeLabel(Label):
    """Use with a Model Property group to reveal the Model type."""
    def __init__(self, **d):
        """
        d: dict
            Initialize the Label.
        """
        d[df.TEXT] = "Model Type: {}".format(
            d[df.ANY_GROUP].dna.model.model_type
        )
        Label.__init__(self, **d)


class TrimLabel(Label):
    """Use with an Image Choice dialog as documentation."""
    def __init__(self, **d):
        """
        d: dict
            Initialize the Label.
        """
        d[df.TEXT] = \
            "If necessary, the image is resized so that it can\n" \
            "fill the rectangle to the greatest degree without\n" \
            "enlarging the image. In the process, a side of the\n" \
            "image may be trimmed. The image justification\n" \
            "determines the trimmed side(s)."
        Label.__init__(self, **d)


class ModelTypeLabel(Label):
    """Display row and column counts."""
    TEMPLATE = "Row: {}, Column: {}"

    def __init__(self, **d):
        """
        d: dict
            Has init value.
        """
        d[df.TEXT] = ModelTypeLabel.TEMPLATE.format(0, 0)
        d[df.ALIGN] = 0, 0, 1, 1

        Label.__init__(self, **d)
        self.latch(
            self.any_group.dna.model.baby,
            (si.GRID_CHANGE, self.on_grid_change)
        )

    def on_grid_change(self, _, arg):
        """
        Respond to change in a Model's grid.

        _: Model
            Sent the signal

        arg: tuple
            (row span, column span); the grid value
        """
        self.set_label_value(ModelTypeLabel.TEMPLATE.format(*arg))
