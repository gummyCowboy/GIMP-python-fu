#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Shape as sh, Triangle as ft
from roller_constant_identity import Identity as de
from roller_polygon_box import calc_box_b_w
from math import asin, atan2, cos, radians, sin, sqrt, tan

# Pin orientation
X_OFFSET = {
    de.BOTTOM_CENTER, de.BOTTOM_RIGHT,
    de.CENTER, de.CENTER_RIGHT,
    de.TOP_CENTER, de.TOP_RIGHT
}
Y_OFFSET = {
    de.BOTTOM_CENTER, de.BOTTOM_LEFT, de.BOTTOM_RIGHT,
    de.CENTER, de.CENTER_LEFT, de.CENTER_RIGHT
}

# Are Pin values where a topleft oriented
# grid is offset or centered in its canvas.
X_CENTER = {de.BOTTOM_CENTER, de.CENTER, de.TOP_CENTER}
Y_CENTER = {de.CENTER, de.CENTER_LEFT, de.CENTER_RIGHT}


def arrange_hexagon(q, x, y, w, h):
    """
    Calculate a hexagon's polygon's x, y series.

    q: tuple
        offsets

    x, y: float
        topleft point

    w, h: float
        rectangle

    Return: tuple
        x, y vertex pairs in a series
        Use with a select polygon function.
    """
    w1, h1, _, h2 = q
    x1 = x + w1
    x2 = x + w
    y1 = y + h1
    y2 = y + h2

    # The first point is the topleft. The
    # vertices connect in a clockwise rotation.
    return (
        x, y1,
        x1, y,
        x2, y1,
        x2, y2,
        x1, y + h,
        x, y2
    )


def arrange_hexagon_truncated(q, x, y, w, h):
    """
    Calculate the polygon vertices of a truncated hexagon.

    w, h: float
        The rectangle bounds of the hexagon.

    Return: tuple
        x, y vertex pairs
        for the select polygon function
    """
    w1, _, w3, h1 = q
    x1 = x + w1
    x2 = x + w3
    y1 = y + h1
    y2 = y + h

    # The first point is the topleft.
    # The vertices connect clockwise.
    return (
        x, y1,
        x1, y,
        x2, y,
        x + w, y1,
        x2, y2,
        x1, y2,
    )


def arrange_octagon(q, x, y, w, h):
    """
    Calculate the polygon vertices of an octagon with offsets.

    q: tuple
        offsets for the vertices

    x, y, w, h: float
        Is the bounds rectangle of the octagon.

    Return: tuple
        x, y vertex pairs in a connected series
        for select polygon function
    """
    w1, w2, w3, h1, h2, h3 = q
    x0 = x + w1
    x1 = x + w2
    x3 = x + w3
    y1 = y + h1
    y2 = y + h2
    y3 = y + h3

    # The first point is top-center.
    # The direction is clockwise.
    return (
        x1, y,
        x3, y1,
        x + w, y2,
        x3, y3,
        x1, y + h,
        x0, y3,
        x, y2,
        x0, y1
    )


def arrange_octagon_on_its_side(q, x, y, w, h):
    """
    Calculate the polygon vertices of an octagon on its side.

    x, y, w, h: float
        Is the bounds rectangle of the octagon.

    q: tuple
        Are offsets for the vertices.

    Return: tuple
        x, y vertex pairs in a connected point series
        for select polygon function
    """
    w1, w2, h1, h2 = q
    x1 = x + w1
    x2 = x + w2
    x3 = x + w
    y1 = y + h1
    y2 = y + h2
    y3 = y + h

    # The first point is the left-most upper.
    # The vertices connect clockwise.
    return (
        x1, y,
        x2, y,
        x3, y1,
        x3, y2,
        x2, y3,
        x1, y3,
        x, y2,
        x, y1
    )


def arrange_rectangle(t):
    """
    Translate a rectangle into a tuple of x, y
    coordinates for drawing a Rectangle polygon.

    t: Rect
        Define the rectangle.

    Return: tuple
        x, y vertex pairs
        for drawing a Rectangle
    """
    x, y, w, h = t.rect
    x1, y1 = x + w, y + h
    return x, y, x1, y, x1, y1, x, y1


def calc_box_hex(box, a, t, d):
    """
    For a vertical hexagon, calculate a Box shape with is
    dependent on its Box/Cell/Type/Box Type and its inner Cap vertex
    position.

    The cell rectangle will change if the cap is off center.

    box: Box
        the model

    a: Mesh
        Store cell geometry.

    t: Rect
        cell size and position

    d: dict
        Box/Cell/Type Preset
        Has Cap X and Y options.

    Return: tuple
        (x, y, ...) series of float
        Define a Box hexagon.
    """
    w, h = t.size

    # There are two possible solutions.
    # solution one
    w1, h1 = h * ft.SCALE_DOWN, h

    if w1 > w:
        # Solution one doesn't fit the rectangle, so it's solution two.
        w1, h1 = w, w * ft.SCALE_UP
    return calc_box_hex_any(box, a, t, d, w1, h1)


def calc_box_hex_any(box, a, t, d, w, h):
    def _arrange():
        """
        Arrange a hexagon shape of x, y coordinate where each
        x, y pair is a polygon vertex. Order coordinate from
        the upper left-most point and connect points clockwise.

        Return: tuple
            shape
        """
        return x, y2, x2, y, x3, y1, x3, y3, x1, y5, x, y4

    def _arrange_flip_x():
        """The x coordinate is flipped."""
        return x, y1, x1, y, x3, y2, x3, y4, x2, y5, x, y3

    def _arrange_flip_xy():
        """The x and y coordinates are flipped."""
        return x, y2, x2, y, x3, y1, x3, y3, x1, y5, x, y4

    def _arrange_flip_y():
        """The y coordinate is flipped."""
        return x, y1, x1, y, x3, y2, x3, y4, x2, y5, x, y3

    # Adapt to cap offset.
    h1 = calc_box_b_w(d[de.CAP_Y], h, box.is_positive_b)
    a_w1, a_w2, b_w1, b_w2, b_w3, b_w4, offset_a, offset_b = calc_box_offset(
        d[de.CAP_X], w, h1, box.ratio
    )
    x, y = t.position
    is_flip_x = not box.is_positive_a
    is_flip_y = not box.is_positive_b
    w2 = t.w = a_w1 + a_w2
    h2 = t.h = b_w1 + b_w4

    # Center the hexagon.
    x = t.x = x + (w - w2) / 2.
    y = t.y = y + (h - h2) / 2.

    offset_a, offset_b = flip_box_offset(
        is_flip_x, is_flip_y, w2, h2, offset_a, offset_b
    )
    a.cap_x = x + offset_a
    a.cap_y = y + offset_b
    x1, x2, x3 = map(round, sorted((x + a_w1, x + a_w2, x + w2)))
    y1, y2, y3, y4, y5 = map(
        round, sorted((y + b_w1, y + b_w2, y + b_w3, y + b_w4, y + h2))
    )
    return (
        _arrange, _arrange_flip_y, _arrange_flip_x, _arrange_flip_xy
    )[is_flip_y + is_flip_x * 2]()


def calc_box_hex_shear(box, a, t, d):
    """
    For a sheared vertical hexagon, calculate a Box shape with is
    dependent on its Box/Cell/Type/Box Type and its inner Cap vertex
    position.

    Update the bounding rectangle.

    box: Box
        the model

    a: Mesh
        Store cell geometry.

    t: Rect
        cell size and position

    d: dict
        Box/Cell/Type Preset
        Has Cap X and Y options.

    Return: tuple
        (x, y, ...) series of float
        Define a Box hexagon.
    """
    return calc_box_hex_any(box, a, t, d, *t.size)


def calc_box_offset(cap, a_w, b_w, ratio):
    """
    Calculate cap offset for any hexagon. Use 'a' and 'b' to
    define hexagon vectors where the 'a' side has three
    vertices and the 'b' side has four vertices.

    cap: float
        the hexagon's 'a' Cap

    a_w, b_w: float
        the size of the hexagon when pointing vertically

    ratio: float
        Multiply 'b's span by this value to get the first 'b' offset.

    Return: tuple
        hexagon offsets
        (
            'a' offset 1,
            'a' offset 2,
            'b' offset 1,
            'b' offset 2,
            'b' offset 3,
            'b' offset 4,
            'a' cap offset,
            'b' cap offset
        )
    """
    # Calc cap position.
    shift = cap - .5 if cap > .5 else .5 - cap

    # a
    a_w2 = a_w / 2.
    a_w1 = offset_a = a_w2 - a_w * shift

    # b
    b_w2 = b_w * ratio
    b_w4 = b_w - b_w2
    shift_b = b_w2 * shift * -2.
    b_w1 = b_w2 + shift_b
    b_w3 = b_w4 + shift_b
    offset_b = b_w2 + b_w1
    return a_w1, a_w2, b_w1, b_w2, b_w3, b_w4, offset_a, offset_b


def calc_box_hexT(box, a, t, d):
    """
    For a truncated hexagon, calculate a Box shape with is
    dependent on its Box/Cell/Type/Box Type and its inner Cap vertex
    position.

    Update the bounding rectangle.

    box: Box
    a: Mesh
        Store cell geometry.

    t: Rect
        cell size and position

    d: dict
        Box/Cell/Type Preset

    Return: tuple
        (x, y, ...) series of float
        Define a Box hexagon.
    """
    w, h = t.size

    # There are two possible solutions.
    # solution one
    w1, h1 = w, w * ft.SCALE_DOWN

    if h1 > h:
        # Solution one doesn't fit the rectangle, so it's solution two.
        w1, h1 = h * ft.SCALE_UP, h
    return calc_box_hexT_any(box, a, t, d, w1, h1)


def calc_box_hexT_any(box, a, t, d, w, h):
    """
    For a truncated hexagon, calculate a Box shape with is
    dependent on its Box/Cell/Type/Box Type and its inner Cap vertex
    position.

    Update the bounding rectangle.

    box: Box
    a: Mesh
        Store cell geometry.

    t: Rect
        cell size and position

    d: dict
        Box/Cell/Type Preset

    Return: tuple
        (x, y, ...) series of float
        Define a Box hexagon.
    """
    def _arrange():
        """
        Arrange a hexagon shape of x, y coordinate where each
        x, y pair is a polygon vertex. Order coordinate from
        the upper left-most point and connect points clockwise.

        Return: tuple
            shape
        """
        return x, y2, x2, y, x4, y, x5, y1, x3, y3, x1, y3

    def _arrange_flip_x():
        """The x coordinate is flipped."""
        return x, y1, x1, y, x3, y, x5, y2, x4, y3, x2, y3

    def _arrange_flip_xy():
        """The x and y coordinates are flipped."""
        return x, y2, x2, y, x4, y, x5, y1, x3, y3, x1, y3

    def _arrange_flip_y():
        """The y coordinate is flipped."""
        return x, y1, x1, y, x3, y, x5, y2, x4, y3, x2, y3

    # Adapt to cap offset.
    w1 = calc_box_b_w(d[de.CAP_X], w, box.is_positive_b)
    a_w1, a_w2, b_w1, b_w2, b_w3, b_w4, offset_a, offset_b = calc_box_offset(
        d[de.CAP_Y], h, w1, box.ratio
    )
    x, y = t.position
    is_flip_y = not box.is_positive_a
    is_flip_x = not box.is_positive_b
    h2 = t.h = a_w1 + a_w2
    w2 = t.w = b_w1 + b_w4

    # Center the hexagon.
    x = t.x = x + (w - w2) / 2.
    y = t.y = y + (h - h2) / 2.

    offset_a, offset_b = flip_box_offset(
        is_flip_y, is_flip_x, h2, w2, offset_a, offset_b
    )
    a.cap_x = x + offset_b
    a.cap_y = y + offset_a
    y1, y2, y3 = map(round, sorted((y + a_w1, y + a_w2, y + h2)))
    x1, x2, x3, x4, x5 = map(
        round, sorted((x + b_w1, x + b_w2, x + b_w3, x + b_w4, x + w2))
    )
    return (
        _arrange, _arrange_flip_y, _arrange_flip_x, _arrange_flip_xy
    )[is_flip_y + is_flip_x * 2]()


def calc_box_hexT_shear(box, a, t, d):
    """
    For a sheared vertical hexagon, calculate a Box shape with is
    dependent on its Box/Cell/Type/Box Type and its inner Cap vertex
    position.

    The cell rectangle will change if the cap is off center.

    box: Box
        the model

    a: Mesh
        Store cell geometry.

    t: Rect
        cell size and position

    d: dict
        Box/Cell/Type Preset
        Has Cap X and Y options.
    """
    return calc_box_hexT_any(box, a, t, d, *t.size)


def calc_circle(t):
    """
    Calculate a bounds rectangle for drawing a circle.

    t: Rect
        Is the bounds rectangle of the circle.

    Return: tuple
        (x, y, w, h)
        Define the rectangle bounds of the circle.
    """
    w, h = t.size
    center_x, center_y = t.center()
    w = round(min(w, h))
    x1 = round(center_x - w / 2.)
    y1 = round(center_y - w / 2.)
    return x1, y1, w, w


def calc_circumradius(w, h):
    """
    Calculate the half-diagonal of a rectangle.

    Return: float
        Is half the length of the rectangle's diagonal.
    """
    return sqrt(w**2. + h**2.) / 2.


def calc_diamond(t):
    """
    Get the four vertices of a diamond.

    t: Rect
        Is the bounds rectangle for the diamond.

    Return: tuple
        x, y pairs in a connected point series
        for drawing a diamond
    """
    x, y, w, h = t.rect
    x1, y1 = x + w, y + h
    y2 = round((y + y1) / 2.)
    x2 = round((x + x1) / 2.)
    return x, y2, x2, y, x1, y2, x2, y1


def calc_hexagon(t):
    """
    Calculate six vertices of a Hexagon.
    Maintain the Hexagon shape proportions.

    t: Rect
        Is the bounds rectangle for the hexagon.

    Return: tuple
        x, y pairs
        for drawing a hexagon
    """
    x, y, w, h = t.rect

    # There are two possible solutions.
    # solution one
    w1, h1 = h * ft.SCALE_DOWN, h

    if w1 > w:
        # Solution one doesn't fit the rectangle, so it's solution two.
        w1, h1 = w, w * ft.SCALE_UP
    return arrange_hexagon(
        calc_hexagon_offset(w1, h1),
        x + round((w - w1) / 2.),
        y + round((h - h1) / 2.),
        round(w1), round(h1)
    )


def calc_hexagon_offset(w, h):
    """
    Calculate hexagon offsets.

    w, h: float
        rectangle

    Return: tuple
        offsets
    """
    return map(round, (w / 2., h / 4., h / 2., h * .75))


def calc_hexagon_shear(t):
    """
    Get the six vertices of a Sheared Hexagon.

    t: Rect
        Is the bounds rectangle of the Sheared Hexagon.

    Return: tuple
        x, y pairs
        for drawing a Sheared Hexagon
    """
    return arrange_hexagon(calc_hexagon_offset(*t.size), *t.rect)


def calc_hexagon_truncated(t):
    """
    Get the vertices of a Truncated Hexagon.
    Maintain the hexagon shape proportions.

    t: Rect
        Is the bounds rectangle of the Truncated Hexagon.

    Return: tuple
        x, y pairs
        for drawing a Truncated Hexagon
        The six coordinates of the hexagon are connected clockwise.
        The first point is the topleft point.
    """
    x, y, w, h = t.rect

    # There are two possible solutions.
    # solution one
    w1, h1 = w, w * ft.SCALE_DOWN

    if h1 > h:
        # Solution one doesn't fit the rectangle, so it's solution two.
        w1, h1 = h * ft.SCALE_UP, h

    center_w, center_h = (w - w1) / 2., (h - h1) / 2.
    x += center_w
    y += center_h
    return arrange_hexagon_truncated(
        calc_hexagon_truncated_offset(w1, h1),
        round(x),
        round(y),
        round(w1),
        round(h1)
    )


def calc_hexagon_truncated_offset(w, h):
    """
    Calculate offsets of a Truncated Hexagon.

    w, h: float
        rectangle size

    Return: tuple
        offsets
    """
    return map(round, (w / 4., w / 2., w * .75, h / 2.))


def calc_hexagon_truncated_shear(t):
    """
    Get the six vertices of a Sheared Truncated Hexagon.

    t: Rect
        Is the bounds rectangle of the Sheared Truncated Hexagon.

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    w, h = t.size
    return arrange_hexagon_truncated(
        calc_hexagon_truncated_offset(w, h), t.x, t.y, w, h
    )


def calc_length(x, y, x1, y1):
    """
    Calculate the distance between two points.

    x, y, x1, y1: float
        Are the end points of a line -> (x, y), (x1, y1).

    Return: float
        Is the distance between the points.
    """
    return sqrt((x - x1)**2. + (y - y1)**2.)


def calc_octagon(t):
    """
    Get the eight vertices of a octagon.
    Maintain normal octagon proportions.

    t: Rect
        Is the bounds rectangle of the octagon.

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y, w, h = t.rect
    w1 = min(w, h)
    x += round((w - w1) / 2.)
    y += round((h - w1) / 2.)
    return arrange_octagon(calc_octagon_offset(w1, w1), x, y, w1, w1)


def calc_octagon_offset(w, h):
    """
    Calculate the offsets of an octagon.

    w, h: float
        Is the bounds of the octagon.

    Return: tuple
        six offsets
    """
    # the cell rectangle half-diagonal, 'radius'
    # Prevent a possible divide by zero error.
    radius = max(.01, calc_circumradius(w, h))

    w1 = w / 2.
    h1 = h / 2.
    angle = asin(h1 / radius)

    # The process for 'w2' is deliberately
    # not factored as this is a complex formula.
    area = w1 * h1
    w2 = tan(angle)**2.
    w2 = w2 * w1**2.
    w2 = h1**2. + w2
    w2 = sqrt(w2)
    w2 = area / w2
    h2 = w2 * tan(angle)
    w3 = w1 + w2
    w4 = w1 - w2
    h3 = h1 + h2
    h4 = h1 - h2
    return map(round, (w4, w1, w3, h4, h1, h3))


def calc_octagon_shear(t):
    """
    Get the eight vertices of a Sheared Octagon.

    t: Rect
        Is the bounds rectangle of the Sheared Octagon.

    Return: tuple
        x, y pairs
        for drawing an octagon
    """
    x, y, w, h = t.rect
    return arrange_octagon(calc_octagon_offset(w, h), x, y, w, h)


def calc_octagon_on_its_side(t):
    """
    Get the eight vertices of an octagon that on its side.

    t: Rect
        Is the bounds rectangle of the octagon.

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y, w, h = t.rect
    w1 = min(w, h)

    # Center the polygon in the rectangle.
    x += round((w - w1) / 2.)
    y += round((h - w1) / 2.)
    return arrange_octagon_on_its_side(
        calc_octagon_on_its_side_offset(w1, w1), x, y, w1, w1
    )


def calc_octagon_on_its_side_offset(w, h):
    """
    Calculate the offsets of a octagon that on its side using a ratio.

    w, h: float
        Is the rectangle bounds of the octagon.

    Return: tuple
        offsets
    """
    # Use ratio.
    w1 = w * sh.OCTAGON_RATIO
    w2 = w - w1
    h1 = h * sh.OCTAGON_RATIO
    h2 = h - h1
    return map(round, (w1, w2, h1, h2))


def calc_octagon_on_its_side_shear(t):
    """
    Get the eight vertices of a Sheared Octagon that on its side.

    t: Rect
        Is the bounds rectangle.

    Return: tuple
        x, y pairs
        for drawing an Octagon
    """
    w, h = t.size
    return arrange_octagon_on_its_side(
        calc_octagon_on_its_side_offset(w, h), t.x, t.y, w, h
    )


def calc_parallelogram_left(t, scale):
    """
    Calculate a left parallelogram.

    t: Rect
        Is the parallelogram's container rectangle.

    scale: float
        .001 to 1.
        Is the scale of the parallelogram top and bottom side
        and is multiplied by the parallelogram's container width.

    Return: tuple
        the parallelogram's polygon
    """
    w, h = t.size
    center_x, center_y = t.center()
    x = center_x - w / 2.
    y = center_y - h / 2.
    y1 = y + h
    w1 = w * scale
    x1 = x + w1
    x2 = x + w
    x3 = x2 - w1
    return map(round, (x, y, x1, y, x2, y1, x3, y1))


def calc_parallelogram_right(t, scale):
    """
    Calculate a right parallelogram.

    t: Rect
        Is the parallelogram's container rectangle.

    scale: float
        .001 to 1.
        Is the scale of the parallelogram top and bottom side
        and is multiplied by the parallelogram's container width.

    Return: tuple
        the parallelogram's polygon
    """
    w, h = t.size
    center_x, center_y = t.center()
    x = center_x - w / 2.
    y = center_y - h / 2.
    y1 = y + h
    w1 = w * scale
    x1 = x + w - w1
    x2 = x + w
    x3 = x + w1
    return map(round, (x1, y, x2, y, x3, y1, x, y1))


def calc_pin_xy(pin, x, y, w, h, w1, h1):
    """
    Justify a topleft positioned cell grid using a pin
    corner by calculating x and y offsets given the
    canvas size and cell grid size.

    pin: string
        pin type

    x, y: int
        topleft point of the canvas

    w, h: int
        canvas size

    w1, h1: float
        cell grid size

    Return: tuple
        the topleft point for the grid
        (x, y) of float
    """
    if pin in X_OFFSET:
        x1 = w - w1

        if pin in X_CENTER:
            x1 /= 2.
        x += x1

    if pin in Y_OFFSET:
        y1 = h - h1

        if pin in Y_CENTER:
            y1 /= 2.
        y += y1
    return round(x), round(y)


def calc_miter_square(t):
    """
    Get the four vertices of a square.

    t: Rect
        Is the bounds rectangle of the square.

    Return: tuple
        x, y pairs
        for drawing a rotated square
    """
    w, h = t.size
    w2 = round(min(w, h) / 2.)
    center_x, center_y = map(round, (t.center()))
    return (
        center_x - w2, center_y,
        center_x, center_y - w2,
        center_x + w2, center_y,
        center_x, center_y + w2
    )


def calc_rotated_point(x, y, angle, radius):
    """
    Return a point on a circle that corresponds to an angle.

    x, y: float
        center point

    angle : float
        rotation angle in radian

    radius: float
        the radius of the circle in pixel

    Return: list
        [x, y] of float
        Is the point that lies on the circle.
    """
    return [(sin(angle) * radius) + x, (cos(angle) * -radius) + y]


def calc_square(t):
    """
    Get the four vertices of a Square.

    t: Rect
        Is the bounds rectangle of the Square.

    Return: tuple
        x, y pairs
        for drawing a Square
    """
    w, h = t.size
    center_x, center_y = t.center()
    w = min(w, h)
    x1 = center_x - w / 2.
    y1 = center_y - w / 2.
    x2, y2 = x1 + w, y1 + w
    return map(round, (x1, y1, x2, y1, x2, y2, x1, y2))


def calc_triangle_down_regular(t):
    """
    Get the three vertices of a Down Triangle.
    Maintain an regular triangle shape.

    t: Rect
        Is the bounds rectangle of the polygon.

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y, w, h = t.rect

    # There are two possible solutions.
    # solution one
    w1, h1 = h * ft.SCALE_UP, h

    if w1 > w:
        # Solution one would overflow the bounds rectangle.
        w1, h1 = w, w * ft.SCALE_DOWN

    x1, y1 = x + w1, y + h1
    x2 = (x + x1) / 2.

    # Center the triangle.
    offset_x = (w - w1) / 2.
    offset_y = (h - h1) / 2.
    x += offset_x
    x1 += offset_x
    x2 += offset_x
    y += offset_y
    y1 += offset_y
    return map(round, (x, y, x2, y1, x1, y))


def calc_triangle_down_shear(t):
    """
    Get the three vertices of a Sheared Down Triangle.

    t: Rect
        Is the bounds rectangle of the polygon.

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y, w, h = t.rect
    x1, y1 = x + w, y + h
    x2 = round((x + x1) / 2.)
    return x, y, x2, y1, x1, y


def calc_triangle_left_regular(t):
    """
    Get the three vertices of a Left Regular Triangle.

    t: Rect
        Is the bounds rectangle of the polygon.

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y, w, h = t.rect

    # There are two possible solutions.
    # solution one
    w1, h1 = h * ft.SCALE_DOWN, h

    if w1 > w:
        # Solution one would overflow the bounds rectangle.
        # solution two
        w1, h1 = w, w * ft.SCALE_UP

    x1, y1 = x + w1, y + h1
    y2 = (y + y1) / 2.

    # Center the triangle.
    offset_x = (w - w1) / 2.
    offset_y = (h - h1) / 2.
    x += offset_x
    x1 += offset_x
    y += offset_y
    y1 += offset_y
    y2 += offset_y
    return map(round, (x1, y, x1, y1, x, y2))


def calc_triangle_left_shear(t):
    """
    Get the three vertices of a Sheared Left Triangle.

    t: Rect
        Is the bounds rectangle of the polygon.

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y, w, h = t.rect
    x1, y1 = x + w, y + h
    y2 = round((y + y1) / 2.)
    return x1, y, x1, y1, x, y2


def calc_triangle_right_regular(t):
    """
    Get the three vertices of a Right Regular Triangle.

    t: Rect
        Is the bounds rectangle of the polygon.

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y, w, h = t.rect

    # There are two possible solutions.
    # solution one
    w1, h1 = h * ft.SCALE_DOWN, h

    if w1 > w:
        # Solution one would overflow the bounds rectangle.
        # solution two
        w1, h1 = w, w * ft.SCALE_UP

    x1, y1 = x + w1, y + h1
    y2 = (y + y1) / 2.

    # Center the triangle.
    offset_x = (w - w1) / 2.
    offset_y = (h - h1) / 2.
    x += offset_x
    x1 += offset_x
    y += offset_y
    y1 += offset_y
    y2 += offset_y
    return map(round, (x, y, x, y1, x1, y2))


def calc_triangle_right_shear(t):
    """
    Get the three vertices of a Right Sheared Triangle.

    t: Rect
        Is the bounds rectangle of the polygon.

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y, w, h = t.rect
    x1, y1 = x + w, y + h
    y2 = round((y + y1) / 2.)
    return x, y, x, y1, x1, y2


def calc_triangle_up_regular(t):
    """
    Get the three vertices of a Down Regular Triangle.

    t: Rect
        Is the bounds rectangle of the polygon.

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y, w, h = t.rect

    # There are two possible solutions.
    # solution one
    w1, h1 = h * ft.SCALE_UP, h

    if w1 > w:
        # Solution one would overflow the bounds rectangle.
        w1, h1 = w, w * ft.SCALE_DOWN

    x1, y1 = x + w1, y + h1
    x2 = (x + x1) / 2.

    # Center the triangle.
    offset_x = (w - w1) / 2.
    offset_y = (h - h1) / 2.
    x += offset_x
    x1 += offset_x
    x2 += offset_x
    y += offset_y
    y1 += offset_y
    return map(round, (x, y1, x2, y, x1, y1))


def calc_triangle_up_shear(t):
    """
    Get the three vertices of a Sheared Up Triangle.

    t: Rect
        Is the bounds rectangle of the polygon.

    Return: tuple
        x, y pairs
        for drawing the polygon
    """
    x, y, w, h = t.rect
    x1, y1 = x + w, y + h
    x2 = round((x + x1) / 2.)
    return x, y1, x2, y, x1, y1


def flip_box_offset(is_flip_a, is_flip_b, a_w, b_w, offset_a, offset_b):
    """
    If a Box's Face's is flipped, recalculate offset so
    that its offset is subtracted from the end of its span.

    is_flip_a, is_flip_b: bool
        Are the Box's Faces flipped?

    a_w, b_w: float
        the hexagon's 'a' and 'b' span
        'a' has three vertices and 'b' has four.

    offset_a, offset_b: float
        The offsets are set for a topleft hexagon,
        but get flipped by the other Box Types.

    Return: tuple
        (offset 'a' cap, offset 'b' cap)
    """
    if is_flip_a:
        # The offset is the polygon's 'a' span minus the positive offset.
        offset_a = a_w - offset_a

    if is_flip_b:
        # The offset is the polygon's 'b' span minus the positive offset.
        offset_b = b_w - offset_b
    return offset_a, offset_b


def get_bounds(a):
    """
    Return the bounds of a shape.

    a: iterable
        The iterable has point defining x, y float pairs.

    Return: tuple
        (x, y, w, h)
        Is the bounds of the shape.
    """
    def _extent(_a):
        return min(_a), max(_a)

    if len(a) == 4:
        return a
    else:
        b = len(a)
        min_x, max_x = _extent([a[i] for i in range(0, b, 2)])
        min_y, max_y = _extent([a[i] for i in range(1, b, 2)])
        return min_x, min_y, max_x - min_x, max_y - min_y


def get_ellipse(t):
    """
    Return a rectangle definition.

    t: Rect
        the bounds rectangle for the ellipse

    Return: tuple
        (x, y, w, h)
        Define the rectangle bounds of the ellipse.
    """
    return t.rect


def get_extreme(a):
    """
    Return the extreme x and y coordinates of a shape.

    a: iterable
        The iterable has x, y float pairs.

    Return: tuple
        x, y, x1, y1
        left, top, right, bottom
    """
    b = len(a)
    q_x = [a[i] for i in range(0, b, 2)]
    q_y = [a[i] for i in range(1, b, 2)]
    return min(q_x), min(q_y), max(q_x), max(q_y)


def get_intersection(p, p1, p2, p3):
    """
    Given two lines that are known to intersect,
    find their intersecting point.

    Reference
    'stackoverflow.com/questions/563198/how-do-you
    -detect-where-two-line-segments-intersect'

    p, p1: tuple
        ((x, y), (x, y)) of float
        Define a line.

    p2, p3: tuple
        ((x, y), (x, y)) of float
        Define a line.

    Return: list
        [float x, float y]
        Is their intersect point.
    """
    s_x = p1[0] - p[0]
    s_y = p1[1] - p[1]
    s1_x = p3[0] - p2[0]
    s1_y = p3[1] - p2[1]
    s2_x = p[0] - p2[0]
    s2_y = p[1] - p2[1]

    # scalar, 't'
    f = (s_x * s1_y - s1_x * s_y)
    t = ((s1_x * s2_y - s1_y * s2_x) / f) if f != .0 else 1.
    return [p[0] + (t * s_x), p[1] + (t * s_y)]


def get_h_ellipse_rect(t):
    """
    Calculate the rectangle bounds of a horizontal ellipse.

    t: Rect
        Is the bounding rectangle for the ellipse.

    Return: tuple
        (x, y, w, h)
    """
    return t.x, t.y, t.w, t.h - round(t.h * sh.ELLIPSE_RATIO)


def get_v_ellipse_rect(t):
    """
    Calculate the rectangle bounds of a vertical ellipse.

    t: Rect
        Is the bounding rectangle for the ellipse.

    Return: tuple
        (x, y, w, h)
    """
    return t.x, t.y, t.w - round(t.w * sh.ELLIPSE_RATIO), t.h


def make_coord_list(length, divisor, start, pre=0, post=0, span=.0):
    """
    Create a list of coordinate float values by dividing
    a span into close-to-equal parts.

    length: float
        Is the divided length.

    divisor: float
        Divide length by this quantity.

    x: float
        Is the start coordinate. Add this value to each coordinate.

    pre: int
        Create additional coordinates of this
        quantity extending before start.

    post: int
        Create additional coordinates of this
        quantity. extending after the end of length.

    span: float
        When it's not zero, this value is used for the grid width.

    Return: list
        [coordinate, ...]
    """
    # Is the list of coordinates that is returned, 'q'.
    q = []

    x = start
    w = span if span else length / divisor
    end = start + length

    # On remainder full, add one to the coordinate.
    for _ in range(divisor):
        q.append(round(x))
        x += w

    q.append(round(end))

    if pre:
        # Make prefix coordinates.
        q1 = []
        x = start - w

        for _ in range(pre):
            q1.append(round(x))
            x -= w

        q1.extend(q)
        q = q1

    if post:
        # Make postfix coordinates.
        x = end + w
        for _ in range(post):
            q.append(round(x))
            x += w
    return q


def rotate_points(point_q, center, radius, f):
    """
    Rotate rectangle corner point around their center point.

    point_q: iter
        x, y points, float

    center: tuple
        (x, y) of float
        Is the center rotation.

    radius: float
        Is the half-diagonal of the output rectangle.

    f: float
        rotation amount in degree

    Return: list
        rotated points
    """
    q = []
    f = radians(f)
    center_x, center_y = center

    for i in range(0, 8, 2):
        x, y = point_q[i], point_q[i + 1]

        # Don't ask me why this works (x/y).
        q.extend(
            calc_rotated_point(center_x, center_y, atan2(x, y) + f, radius)
        )
    return q


def shift_center(q, x, y, invert=-1):
    """
    Adjust the points in a rectangular polygon by
    x and y offset. Invert the y value in order to convert
    the canvas coordinate into a Cartesian coordinate.

    q: iter
        x, y series, eight coordinates
        Define a rectangle polygon.

    x, y: float
        Is the amount offset to offset polygon point.

    invert: int
        A valid value is either -1 or 1.
    """
    # a rectangle polygon's x, y series with a zero center, 'q1'
    q1 = []

    for i in range(0, 8, 2):
        q1.extend([q[i] - x, (q[i + 1] - y) * invert])
    return q1


def invert_triangle(r, c):
    """
    Determine if a vertical or horizontal triangle is inverted.

    r, c: int
        row, column
        cell index

    Return: bool
        Is true when the triangle is inverted.
    """
    return (not r % 2 and c % 2) or (r % 2 and not c % 2)


# {string: function}
# {polygon descriptor: polygon calculator}
ROUTE_SHAPE = {
    de.TRIANGLE_DOWN_REGULAR: calc_triangle_down_regular,
    de.TRIANGLE_DOWN_SHEAR: calc_triangle_down_shear,
    de.TRIANGLE_LEFT_REGULAR: calc_triangle_left_regular,
    de.TRIANGLE_LEFT_SHEAR: calc_triangle_left_shear,
    de.TRIANGLE_RIGHT_SHEAR: calc_triangle_right_shear,
    de.TRIANGLE_RIGHT_REGULAR: calc_triangle_right_regular,
    de.TRIANGLE_UP_SHEAR: calc_triangle_up_shear,
    de.TRIANGLE_UP_REGULAR: calc_triangle_up_regular,
    de.CIRCLE: calc_circle,
    de.CIRCLE_HORIZONTAL: calc_circle,
    de.CIRCLE_VERTICAL: calc_circle,
    de.DIAMOND: calc_diamond,
    de.ELLIPSE: get_ellipse,
    de.ELLIPSE_HORIZONTAL: get_ellipse,
    de.ELLIPSE_VERTICAL: get_ellipse,
    de.HEXAGON: calc_hexagon,
    de.HEXAGON_SHEAR: calc_hexagon_shear,
    de.HEXAGON_TRUNCATED: calc_hexagon_truncated,
    de.HEXAGON_TRUNCATED_SHEAR: calc_hexagon_truncated_shear,
    de.OCTAGON_DOUBLE: calc_octagon_on_its_side,
    de.OCTAGON_DOUBLE_SHEAR: calc_octagon_on_its_side_shear,
    de.OCTAGON: calc_octagon,
    de.OCTAGON_SHEAR: calc_octagon_shear,
    de.OCTAGON_ON_ITS_SIDE_SHEAR: calc_octagon_on_its_side_shear,
    de.OCTAGON_ON_ITS_SIDE: calc_octagon_on_its_side,
    de.RECTANGLE: arrange_rectangle,
    de.SQUARE: calc_square,
    de.MITER_SQUARE: calc_miter_square
}

# Parallelogram, 'POG'
ROUTE_POG = {
    de.PARALLELOGRAM_ALT_LEFT: calc_parallelogram_left,
    de.PARALLELOGRAM_ALT_RIGHT: calc_parallelogram_right,
    de.PARALLELOGRAM_LEFT: calc_parallelogram_left,
    de.PARALLELOGRAM_RIGHT: calc_parallelogram_right,
}

# Box
ROUTE_BOX = {
    sh.BOX_HORIZONTAL: calc_box_hexT,
    sh.BOX_HORIZONTAL_SHEAR: calc_box_hexT_shear,
    sh.BOX_VERTICAL: calc_box_hex,
    sh.BOX_VERTICAL_SHEAR: calc_box_hex_shear
}
