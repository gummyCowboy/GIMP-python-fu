#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD, CHANNEL_OP_INTERSECT, CHANNEL_OP_SUBTRACT, pdb
)
from roller_constant import Deco as dc, Plan as ak, Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_deco import (
    coloring, ready_canvas_rect, ready_shape, transform_foam
)
from roller_deco_output import exit_deck_type, exit_one_type, init_deco_type
from roller_deco_router import create_facial_main, create_facial_per
from roller_gimp_layer import clear_inverse_selection
from roller_gimp_selection import (
    select_channel, select_polygon, select_rect
)
from roller_preset_mod import do_mod
from roller_step import get_branch_part


def create_face(j, maya, d, arg, p):
    """
    Process a Face/Plaque item.

    j: Gimp Image
        WIP

    maya: Maya
        'maya_border' variety

    d: dict
        Plaque Preset

    arg: tuple
        Border/Type specific

    p: function
        Call to make Border/Type layer output.
    """
    model = maya.model
    k = maya.k
    n = d[de.TYPE]
    is_color = coloring(n)
    maya.rect = model.get_facing_rect(k)

    if is_color:
        select_polygon(j, model.get_facing_shape(k))
        select_border(d)

    else:
        select_rect(j, *maya.rect)

    z = p(*arg)
    if z and not is_color:
        z = transform_foam(maya.rect, z, model.get_facing_foam(k))

        select_polygon(j, model.get_facing_shape(k))
        select_border(d)
        clear_inverse_selection(z)


def do(maya, make):
    """
    Create Border output. If Plan is active,
    temporarily override Preset option with Plan setting.

    maya: Maya
        'maya_border' variety

    make: function
        Make Border material.

    Return: layer or None
        Border material
    """
    d = maya.value_d

    if not Run.i:
        # Preserve.
        type_ = d[de.TYPE]
        mode = d[de.MODE]
        color = d[de.COLOR_1]

        # Plan override.
        d[de.TYPE] = de.COLOR
        d[de.MODE] = "Normal"
        d[de.COLOR_1] = {
            de.CELL: ak.CELL_BORDER_COLOR,
            de.CANVAS: ak.CANVAS_BORDER_COLOR,
            de.FACE: ak.FACE_BORDER_COLOR,
            de.FACING: ak.FACE_BORDER_COLOR
        }[get_branch_part(maya.any_group.type_step_k)]

    z = make(maya, d)

    if z:
        do_mod(z, d[rk.BRW][de.MOD])

    if not Run.i:
        # Restore.
        d[de.TYPE] = type_
        d[de.MODE] = mode
        d[de.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Draw Canvas/Border.

    maya: Maya
        'maya_border' variety

    Return: layer or None
        Border material
    """
    return do(maya, make_canvas)


def do_cell_main(maya):
    """
    Draw main Cell/Border.

    maya: Maya
        'maya_border' variety

    Return: layer or None
        Border material
    """
    return do(maya, make_cell_main)


def do_cell_per(maya):
    """
    Draw Cell/Border/Per.

    maya: Maya
        'maya_border' variety

    Return: layer or None
        Border material
    """
    return do(maya, make_cell_per)


def do_face_main(maya):
    """
    Draw main Face/Border.

    maya: Maya
        'maya_border' variety

    Return: layer or None
        Border material
    """
    return do(maya, make_face_main)


def do_face_per(maya):
    """
    Draw Face/Border/Per.

    maya: Maya
        'maya_border' variety

    Return: layer or None
        Border material
    """
    return do(maya, make_face_per)


def do_facing_main(maya):
    """
    Draw main Facing/Border.

    maya: Maya
        'maya_border' variety

    Return: layer or None
        Border material
    """
    return do(maya, make_facing_main)


def do_facing_per(maya):
    """
    Draw Facing/Border/Per.

    maya: Maya
        'maya_border' variety

    Return: layer or None
        Border material
    """
    return do(maya, make_facing_per)


def make_canvas(maya, d):
    """
    Draw Canvas/Border.

    maya: Maya
        'maya_border' variety

    d: dict
        Border Preset

    Return: layer or None
        Border material
    """
    ready_canvas_rect(maya, d, option=None)

    j = Run.j
    x, y, w, h = maya.rect
    border_w = d[de.WIDTH]
    w1 = border_w * 2.
    arg, p = init_deco_type(
        d[de.TYPE], j, maya, maya.group, d, maya.get_light(), False
    )

    select_rect(j, *maya.rect)

    # Cut out an interior rectangle.
    select_rect(
        j,
        x + border_w, y + border_w,
        max(1., w - w1), max(1., h - w1),
        option=CHANNEL_OP_SUBTRACT
    )

    z = p(*arg)
    return exit_one_type(z)


def make_cell_main(maya, d):
    """
    Make main Cell/Border.

    maya: Maya
        'maya_border' variety

    d: dict
        Border Preset

    Return: layer or None
        Border material
    """
    def _do_many_material():
        """
        The cells have the same Border type, but
        the material is applied cell-by-cell.
        """
        for _k in maya.main_q:
            maya.k = _k

            ready_shape(maya, d)
            select_border(d)
            p(*arg)
        return exit_deck_type(n, *arg)

    def _do_one_material():
        """
        The cells have the same Border material,
        so their selection is combined.
        """
        # Combine Cell selection, '_sc'.
        _sc = None

        pdb.gimp_selection_none(j)

        for _k in maya.main_q:
            maya.k = _k

            ready_shape(maya, d)
            select_border(d)

            if _sc:
                select_channel(j, _sc, option=CHANNEL_OP_ADD)
                pdb.gimp_image_remove_channel(j, _sc)
            _sc = pdb.gimp_selection_save(j)

        _z = p(*arg)

        if _sc:
            pdb.gimp_image_remove_channel(j, _sc)
        return exit_one_type(_z)

    j = Run.j
    n = d[de.TYPE]
    is_per = n in dc.PER_TYPE_SET
    arg, p = init_deco_type(
        n, j, maya, maya.group, d, maya.get_light(), is_per
    )

    if is_per:
        # All the Border is the same material
        # and is applied to a selected cell layer.
        return _do_many_material()
    else:
        # All the Border is the same
        # material and is applied one time.
        return _do_one_material()


def make_cell_per(maya, d):
    """
    Make Cell/Border/Per.

    maya: Maya
        'maya_border' variety

    d: dict
        Border Preset

    Return: layer or None
        Border material
    """
    arg, p = init_deco_type(
        d[de.TYPE], Run.j, maya, maya.group, d, maya.get_light(), False
    )

    ready_shape(maya, d)
    select_border(d)
    return exit_one_type(p(*arg))


def make_face_main(maya, d):
    """
    Draw main Face/Border.

    maya: Maya
        'maya_border' variety

    d: dict
        Border Preset

    Return: layer or None
        Border material
    """
    return create_facial_main(maya, d, create_face)


def make_face_per(maya, d):
    """
    Make Face/Border/Per.

    maya: Maya
        'maya_border' variety

    d: dict
        Border Preset

    Return: layer or None
        Border material
    """
    return create_facial_per(maya, d, create_face)


def make_facing_main(maya, d):
    """
    Make main Facing/Border.

    maya: Maya
        'maya_border' variety

    d: dict
        Border Preset

    Return: layer or None
        Border material
    """
    return create_facial_main(maya, d, create_face)


def make_facing_per(maya, d):
    """
    Make Facing/Border/Per.

    maya: Maya
        'maya_border' variety

    d: dict
        Border Preset

    Return: layer or None
        Border material
    """
    return create_facial_per(maya, d, create_face)


def select_border(d):
    """
    Make a Border selection for a cell.
    Prepare the selection state before calling.

    d: dict
        Border Preset

    Return: state of selection
    """
    j = Run.j
    sc = pdb.gimp_selection_save(j)

    pdb.gimp_selection_border(j, int(d[de.WIDTH]))
    select_channel(j, sc, option=CHANNEL_OP_INTERSECT)
    pdb.gimp_image_remove_channel(j, sc)
