#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (  # type: ignore
    CHANNEL_OP_ADD,
    CHANNEL_OP_INTERSECT,
    CHANNEL_OP_REPLACE,
    CHANNEL_OP_SUBTRACT,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_frame import (
    make_canvas_frame_sc, emboss_selection, select_wrap
)
from roller_frame_alt import FrameBasic
from roller_gegl import waves
from roller_gimp_image import add_layer
from roller_gimp_layer import (
    color_selection_default, select_layer, verify_layer
)
from roller_gimp_selection import select_channel, select_rect
from roller_utility import make_rect_table


def do_matter(maya):
    """
    Make a Wrap frame.

    maya: Rad
    Return: layer
        Wrap output
    """
    j = Run.j
    d = maya.value_d
    e = maya.super_maya.value_d[rk.BRW][de.FILLER_RA]
    t = maya.model.canvas_rect
    cast_z = maya.cast.matter

    select_wrap(j, cast_z, d[de.WIDTH], d[de.TYPE])

    wrap_sc = pdb.gimp_selection_save(j)

    # Canvas frame
    pdb.gimp_selection_none(j)
    make_canvas_frame_sc(maya, cast_z, e)

    canvas_frame_sc = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)

    # layer for the wire, 'z'
    z = add_layer(j, None, 0, "Material")

    width, height = map(float, Globe.view_size)
    w1 = e[de.LINE_W]
    row, column = int(e[de.ROW]), int(e[de.COLUMN])

    if w1:
        grid = make_rect_table(t, row, column)

        for r in range(1, row):
            select_rect(
                j, .0, grid[r][0].y, width, w1, option=CHANNEL_OP_ADD
            )
        for c in range(1, column):
            select_rect(
                j, grid[0][c].x, .0, w1, height, option=CHANNEL_OP_ADD
            )

    color_selection_default(z, (0, 0, 0))
    pdb.gimp_selection_none(j)
    waves(z, amplitude=e[de.AMPLITUDE], period=e[de.PERIOD])
    pdb.gimp_selection_none(j)

    # mid-pinch, '.0'; radius, '2.'
    pdb.plug_in_whirl_pinch(j, z, e[de.WHIRL], .0, 2.)

    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)

    if e[de.CLIP]:
        select_layer(cast_z, option=CHANNEL_OP_SUBTRACT)

    pdb.gimp_image_remove_layer(j, z)

    # layer for the combined frame, 'z'
    z = add_layer(j, maya.group, maya.get_light(), "Material")

    for i in (wrap_sc, canvas_frame_sc):
        select_channel(j, i, option=CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, i)

    # Clip selection to canvas.
    select_rect(Run.j, *t, option=CHANNEL_OP_INTERSECT)

    return verify_layer(emboss_selection(z, d))


class Rad(FrameBasic):
    filler_k = de.FILLER_RA
    kind = material = de.RAD
    wrap_k = de.WRAP_CA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
