#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Shape as sh
from roller_constant_identity import Identity as de
from roller_polygon import get_h_ellipse_rect
from roller_polygon_hexagon import calc_hexagon


def calc_ellipse_horz(model, o):
    """
    Calculate a grid of ellipse shaped cell,
    aligned horizontally, and double-spaced.

    For Model cell, calculate 'cell' and 'merge'
    rectangle and their inscribed 'form' polygon.

    model: Model
    o: One
        Has translated Cell/Type option as attribute.

    Return: dict
        {value: [bool, bool]}
        {cell key: [Plan vote change, Work vote change]}
    """
    vote_d = calc_hexagon(model, o, ellipse_space=sh.ELLIPSE_RATIO)
    goo_d = model.goo_d

    if o.grid_type != de.CELL_SIZE:
        # by count
        did_cell = model.past.did_cell

        for r_c in model.cell_q:
            a = goo_d[r_c]

            # The ellipse rect is smaller than the hexagon rect.
            a.cell.rect = a.merged.rect = get_h_ellipse_rect(a.cell)
            vote_d[r_c] = did_cell(r_c)

    for r_c in model.cell_q:
        a = goo_d[r_c]
        a.form = a.cell.rect
    return vote_d
