#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_identity import Identity as de

"""
Include function for calculating Box Face geometry for 'face_1'.

The Box direction is the Face position. Each position
has its own function for calculating geometry.
"""


def do_bottom(q, cap_x, cap_y, side):
    """
    Prepare a left-side mirrored polygon for the Bottom Box/Cell/Type.

    q: tuple
        Define polygon shape.

    cap_x, cap_y: float
        Is the coordinate for the inner vertex.

    side: tuple
        (side1 length, side2 length, side3 length)

    Return: tuple
        (foam, and size of the Face)
    """
    return (
        # transform function's input
        (
            q[0], q[1],
            q[2], q[3],
            q[10], q[11],
            cap_x, cap_y
        ),

        # size of face
        side[0], side[2]
    )


def do_left(q, cap_x, cap_y, side):
    """Prepare a top-side mirrored polygon for the left Box/Cell/Type."""
    return (
        # transform function's input
        (
            q[2], q[3],
            q[4], q[5],
            cap_x, cap_y,
            q[6], q[7]
        ),

        # size of face
        side[1], side[2]
    )


def do_right(q, cap_x, cap_y, side):
    """Prepare a top-side mirrored polygon for the right Box/Cell/Type."""
    # transform function's input
    return (
        (
            q[2], q[3],
            q[4], q[5],
            q[0], q[1],
            cap_x, cap_y
        ),

        # size of face
        side[1], side[0]
    )


def do_top(q, cap_x, cap_y, side):
    """
    Prepare a left-side mirrored polygon for the top Box/Cell/Type.

    Return: tuple
        (foam, and size of the Face)
    """
    return (
        # transform function's input
        (
            q[0], q[1],
            cap_x, cap_y,
            q[10], q[11],
            q[8], q[9]
        ),

        # size of face
        side[1], side[2]
    )


FACE1_BUILD = {
    de.BOTTOM: do_bottom,
    de.LEFT: do_left,
    de.RIGHT: do_right,
    de.TOP: do_top
}
