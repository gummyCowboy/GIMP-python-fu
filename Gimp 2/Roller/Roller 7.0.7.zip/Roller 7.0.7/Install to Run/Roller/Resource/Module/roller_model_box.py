#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Grid as gr, Signal as si, Shape as sh
from roller_constant_identity import Identity as de
from roller_model_face import ROUTE_TRANSFORM
from roller_model_facing import Facing
from roller_model_goo import Map
from roller_model_grid import Grid
from roller_face_cap import CAP_BUILD
from roller_face_1 import FACE1_BUILD
from roller_face_2 import FACE2_BUILD
from roller_utility import seal
from roller_polygon import calc_length

ROUTE_BUILD = CAP_BUILD, FACE1_BUILD, FACE2_BUILD
FACE_ORDER_D = {
    de.BOTTOM: (1, 2, 0),
    de.LEFT: (0, 1, 2),
    de.RIGHT: (1, 0, 2),
    de.TOP: (0, 1, 2)
}

# Box direction
H_BOX_SET = {de.LEFT, de.RIGHT}
V_BOX_SET = {de.TOP, de.BOTTOM}

# Face descriptor
H_FACE_TEXT_Q = "Cap", "Top", "Bottom"
V_FACE_TEXT_Q = "Cap", "Left", "Right"


def calc_side(q):
    """
    Calculate the length of a mirrored hexagonal polygon's three
    segments starting from the segment rooted at the left-most-top
    and proceeding with clockwise connected segments.

    q: tuple
        (x, y, ...); 12 coordinates of float in a series

    Return: tuple
        (length of side, length of side1, length of side2)
    """
    return map(
        round,
        (calc_length(*q[0:4]), calc_length(*q[2:6]), calc_length(*q[4:8]))
    )


class Box(Grid, Facing):
    """
    Has three Faces that can be arranged in four directions.
    The Faces are Cap, Left, and Right. The directions are Top, Bottom,
    Left, and Right. Assign Face's attribute geometry according to the
    Box direction.

    Face attribute geometry
        foam
            tuple
            Is a flag-shaped ordered series of points that
            Face transform uses to create Face output.

            flag-shape: topleft, top-right, bottom-left, bottom-right

        form
            tuple
            Is the merged rectangle defined as a GIMP polygon. There
            are four points that connect four segments making a
            rectangle. The attribute is used by deco to create
            an input/output selection.

        merged
            Rect
            Make a source rectangle for the Face transform.

        shape
            tuple
            Define a Face defined as a GIMP polygon. There are four points.
    """
    model_type = de.BOX

    def __init__(self, model_name):
        """
        model_name: string
            identity of the model
        """
        Grid.__init__(self, model_name)
        Facing.__init__(self)

        self.face_q = []
        self.is_positive_a = self.is_positive_b = self.is_vertical = True
        self.ratio = self.box_type = self._grid_type = self.face_order_q = None

    def _update_face(self, a, k, q, x, y, cap_x, cap_y, side):
        """
        Update Face attribute with cell size.

        a: Map
            Define Face property.

        k: tuple
            zero-based cell indices; Map key
            (row, column, face)

        arg: tuple
            Define the cell content.
            (shape, left, top, cap x, cap y)
        """
        n = self.box_type
        a.foam, w, h = ROUTE_BUILD[self.face_order_q[k[-1]]][n](
            q, cap_x, cap_y, side
        )
        a.merged.rect = x, y, w, h

        # Calculate the 'form' input selection rectangular polygon.
        x1 = x + w
        y1 = y + h
        a.form = x, y, x1, y, x1, y1, x, y1
        a.shape = tuple(a.foam[0:4]) + tuple(a.foam[6:8]) + tuple(a.foam[4:6])

    def calc_main_cell_pocket(self, d):
        """
        Calculate the 'pocket' rectangle and 'shape' polygon for
        Box/Cell main. Update the dependent Box/Face.

        d: dict
            Margin Preset
        """
        super(Box, self).calc_main_cell_pocket(d)

        e = self.goo_d
        d1 = self.map_d
        for r_c in self.cell_q:
            # Mesh, 'a'
            a = e[r_c]
            q = a.shape
            arg = q, q[0], q[3], a.cap_x, a.cap_y, calc_side(q)
            for i in range(3):
                k = r_c + (i,)
                self._update_face(d1[k], k, *arg)

    def calc_cell_pocket(self, d, r_c):
        """
        Calculate the 'pocket' rectangle and 'shape' polygon
        for Box/Cell main. Update the dependent Box/Face.

        d: dict
            Margin Preset

        r_c: tuple
            cell index; Mesh key
        """
        super(Box, self).calc_cell_pocket(d, r_c)

        # Mesh, 'a'
        a = self.goo_d[r_c]
        q = a.shape
        arg = q, q[0], q[3], a.cap_x, a.cap_y, calc_side(q)
        e = self.map_d

        # face count of box, '3'
        for i in range(3):
            k = r_c + (i,)
            self._update_face(e[k], k, *arg)

    def calc_grid(self, d):
        """
        Count grid row and column span. Depend on Canvas pocket.

        Have Baby emit a sequence Signal that grid-value has changed.

        d: dict
            Cell/Type Preset
        """
        n = d[de.GRID_TYPE]
        w, h = self.canvas_pocket.size

        if n in gr.COUNT_SET:
            r, c = d[de.ROW], d[de.COLUMN]

        else:
            # cell size
            width = seal(d[de.COLUMN_W], 1., w)
            height = seal(d[de.ROW_H], 1., h)
            n = d[de.BOX_TYPE]

            if n in H_BOX_SET:
                w1, h1 = width * .75, height * .5
                w2, h2 = w - w1, h - h1
                r, c = max(1, h2 / h1), max(1, w2 / w1)
            else:
                # vertical box
                w1, h1 = width * .5, height * .75
                w2, h2 = w - w1, h - h1
                r, c = max(1, h2 / h1), max(1, w2 / w1)

        self.grid = int(r), int(c)
        self.baby.emit(si.GRID_CHANGE, self.grid)

    def clip_facing(self, *_):
        """Box is Face Model type. Call with a Facing Model type."""
        return

    def get_face_text(self):
        """
        Define the order of Face from the Cell/Type Preset's Box Type.

        Return: list
            [string, ...]; length of three; one for each Box Face
            Identify Face by index.
        """
        q = (H_FACE_TEXT_Q, V_FACE_TEXT_Q)[int(self.is_vertical)]
        return [q[self.face_order_q[i]] for i in range(3)]

    def init_cell_q(self, d):
        """
        Make a list of valid cell and an additional
        list with with the cell's Face indices.

        d: dict
            Cell/Type Preset
        """
        is_indent = d[de.INDENT] and not (self.grid[0] == self.grid[1] == 1)
        self.face_q = []
        self.cell_q = []

        for r in range(self.grid[0]):
            for c in range(self.grid[1]):
                if is_indent:
                    is_cell = bool(
                        (r % 2 and not c % 2) or (not r % 2 and c % 2)
                    )

                else:
                    is_cell = bool(
                        (r % 2 and c % 2) or (not r % 2 and not c % 2)
                    )
                if is_cell:
                    self.cell_q.append((r, c))
                    for i in range(3):
                        self.face_q.append((r, c, i))

    def init_model_cell(self, d):
        """
        Calculate cell size and Face attribute geometry.

        d: dict
            Cell/Type Preset
            {Identity: value}

        Return: list
            [Plan vote, Work vote]
            A True vote is a vote for change.
        """
        vote_d = super(Box, self).init_model_cell(d)
        e = self.map_d = {}
        n = self.box_type

        # Init map dict.
        for k in self.face_q:
            i = self.face_order_q[k[-1]]
            e[k] = Map(d, ROUTE_TRANSFORM[i][n])
        return vote_d

    def set_default_pocket(self, is_sequence):
        """
        Calculate a default 'pocket' for a UI-missing Cell/Margin step.

        is_sequence: bool
            If True, then the chained-sequence is calculated immediately.
        """
        super(Box, self).set_default_pocket(is_sequence)

        d = self.map_d
        for r_c in self.cell_q:
            # Mesh, 'a'
            a = self.goo_d[r_c]
            q = a.shape
            arg = q, q[0], q[3], a.cap_x, a.cap_y, calc_side(q)

            # Face count, '3'
            for i in range(3):
                k = r_c + (i,)
                self._update_face(d[k], k, *arg)

    def update_type(self, arg):
        """
        Update Cell/Type dependency.

        arg: tuple
            (Box/Cell/Type Preset, is sequence flag)
            {Identity: value}
            A sequence is processed immediately.
        """
        def _get_cell_shape():
            """
            Get the cell-shape given the Box Type.

            Return: string
                cell-shape descriptor
            """
            if self.is_vertical:
                return sh.BOX_VERTICAL if self.is_equilateral \
                    else sh.BOX_VERTICAL_SHEAR
            return sh.BOX_HORIZONTAL if self.is_equilateral else sh.BOX_HORIZONTAL_SHEAR

        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        self.is_vertical = d[de.BOX_TYPE] in V_BOX_SET
        self.box_type = d[de.BOX_TYPE]

        self.set_cell_shape(_get_cell_shape())

        # Set the order of processing and its image assignment.
        # Is consistently ordered from topleft to bottom-right.
        self.face_order_q = FACE_ORDER_D[self.box_type]

        vote_d = super(Box, self).update_type(arg)

        self.adapt_missing_cell_step(is_sequence)
        p(si.CELL_RECT_CALC, vote_d)
