#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_gimp_image import check_matter
from roller_maya import Maya

SEED_SET = {de.FRINGE, de.RIP}


def do_mask_matter(maya):
    """
    Mask the super-maya's matter layer.

    maya: Work
    Return: layer or None
        Has a mask attached if requested.
    """
    return maya.do_mask(maya.super_maya, maya.value_d)


class Mask(Maya):
    """Manage Mask Preset layer output."""
    put = (check_matter, 'matter'),
    is_seeded = True
    issue_q = 'matter',

    def __init__(
        self, any_group, super_maya, view_i, do_mask, get_mask_d, k_path
    ):
        """
        any_group: AnyGroup
            Is the director of Mask production.

        super_maya: Maya
            Is from the enclosing Preset.

        view_i: int
            plan or work; 0 or 1; view-type index

        do_mask: function
            Produce a Mask layer.

        get_mask_d: function
            Get the Mask's value dict.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_mask = do_mask
        self.do_matter = do_mask_matter
        self.get_mask_d = get_mask_d
        Maya.__init__(
            self,
            any_group,
            view_i,
            Mask.put,
            [
                k_path,
                k_path + (rk.RW1, de.IMAGE_CHOICE),
                k_path + (rk.RW1, de.BRUSH_D)
            ]
        )

    def do(self, d, is_change):
        """
        Manage layer output during a view run. Call only when
        the super-maya has a matter layer.

        d: dict
            Mask Preset

        is_change: bool
            Is True if the mask source layer has change.

        Return: bool
            Is True if Mask output changed.
        """
        self.value_d = d
        self.go = d[de.SWITCH]

        if self.go:
            m = self.is_matter = self.is_matter or is_change

        else:
            m = bool(self.matter)

        self.realize()
        self.reset_issue()
        return m

    def on_global_seed(self, _, arg):
        """
        The Global Seed option has changed.

        If the Mask output is random-seed dependent,
        cast a matter-changed vote for this class.

        _: Ring
            Sent the signal.

        arg: tuple
            (Plan vote, Work vote)
        """
        d = self.get_mask_d()

        if d and d[de.TYPE] in SEED_SET:
            super(Mask, self).on_global_seed(_, arg)
        else:
            self.great_vote_d = {}
