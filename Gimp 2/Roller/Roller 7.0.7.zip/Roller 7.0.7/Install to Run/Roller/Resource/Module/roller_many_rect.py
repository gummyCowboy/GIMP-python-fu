#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Rect(object):
    """Define a rectangle."""

    def __init__(self, x=.0, y=.0, w=.0, h=.0):
        """
        Set the rectangle's initial values.

        x, y: numeric
            x, y
            position of the rectangle

        w, h: numeric
            width, height of the rectangle
        """
        self.x, self.y, self.w, self.h = map(float, (x, y, w, h))

    def center(self):
        """
        Calculate the center point for the rectangle.

        Return: tuple
            (x, y)
            center point
        """
        return self.x + (self.w / 2.), self.y + (self.h / 2.)

    def foam(self):
        """
        Assemble a flag-ordered polygon with coordinates for the rectangle.
        The points are arranged for the transform function:
        [topleft, top-right, bottom-left, bottom-right]

        Return: list
            [x, y, ...] series
        """
        w, h = self.x + self.w, self.y + self.h

        # four vertices
        return [self.x, self.y, w, self.y, self.x, h, w, h]

    @property
    def position(self):
        """
        Fetch the rectangle position.

        Return: tuple
            (x, y)
        """
        return self.x, self.y

    @position.setter
    def position(self, value):
        """
        Set the rectangle position.

        value: tuple
            (x, y); numeric
            the topleft corner of the rectangle
        """
        self.x, self.y = map(float, value)

    @property
    def rect(self):
        """
        Arrange attribute in rectangular order.

        Return: tuple
            (x, y, w, h)
        """
        return self.x, self.y, self.w, self.h

    @rect.setter
    def rect(self, q):
        """
        Set the rectangle attributes.

        q: tuple
            (x, y, w, h)
            of numeric
        """
        self.x, self.y, self.w, self.h = map(float, q)

    @property
    def size(self):
        """Return the rectangle size."""
        return self.w, self.h

    @size.setter
    def size(self, value):
        """
        Set the rectangle size.

        value: tuple
            (width, height); numeric
            the size of the rectangle
        """
        self.w, self.h = map(float, value)
