#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_BURN,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_LIGHTEN_ONLY,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gimp_image import make_group_layer
from roller_gimp_layer import clone_layer
from roller_maya_sub_accent import SubAccent

LAYER_NUM = "{} of {}"


def do_matter(maya):
    """
    Make a matter layer.

    maya: Rainbow Valley
    Return: layer
        'matter'
    """
    def _noise():
        """Add cloud noise to a layer."""
        if power:
            pdb.plug_in_solid_noise(
                j, z,
                0,                      # no tile-able
                1,                      # yes, turbulent
                seed_,
                7,                      # medium detail
                2.,                     # horizontal size
                2.                      # vertical size
            )

            # medium holdness, '4'
            pdb.plug_in_hsv_noise(j, z, 4, power, power, power)

    j = Run.j
    d = maya.value_d
    z = maya.bg_z
    maya.bg_z = None
    parent = make_group_layer(
        j, maya.group, maya.get_light(), "Condenser", z=z
    )
    seed_ = int(d[de.RANDOM_SEED] + Globe.seed)
    is_texture = d[de.ENGRAVE]
    power = int(d[de.POWER])

    # layer counter, 'count'
    count = 1

    # total layers to make, 'a'
    a = 15
    a += 8 if is_texture else 7

    for i in range(10):
        z = clone_layer(z, n=LAYER_NUM.format(count, a))
        z.mode = LAYER_MODE_DIFFERENCE

        pdb.plug_in_despeckle(j, z, i, 0, 0, 255)

        if i % 2:
            count += 1
            z = clone_layer(z, n=LAYER_NUM.format(count, a))
            z.mode = LAYER_MODE_LIGHTEN_ONLY

            _noise()

            seed_ += 1

            pdb.plug_in_despeckle(j, z, i, 0, 0, 255)
            z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

        is_engrave = False

        if is_texture:
            if i < 7 or i == 9:
                is_engrave = True

        elif i < 7:
            is_engrave = True

        if is_engrave:
            count += 1
            z = clone_layer(z, n=LAYER_NUM.format(count, a))

            pdb.plug_in_engrave(j, z, max(i, 2), 1)

            z.mode = LAYER_MODE_BURN
            z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
            pdb.plug_in_wind(
                j, z,
                0,              # threshold
                2,              # from top
                50,             # strength
                1,              # blast
                1               # leading edge
            )
        count += 1
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class RainbowValley(SubAccent):
    """Create Accent output."""
    kind = de.RAINBOW_VALLEY

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, True, is_old)
