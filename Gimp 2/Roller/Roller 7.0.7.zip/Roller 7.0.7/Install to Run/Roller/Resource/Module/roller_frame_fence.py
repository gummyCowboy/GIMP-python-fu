#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_container import Globe
from roller_gegl import antialias
from roller_constant import Frame as ek
from roller_constant_identity import Identity as de
from roller_frame import do_frame_with_filler
from roller_frame_alt import FrameBasic


def make_pattern(z, d):
    """
    Make a pattern from a black and white mosaic.
    Assume selection is none.

    z: layer
        Receive pattern.

    d: dict
        Fence Preset

    Return: layer
        mosaic pattern
    """
    j = z.image

    pdb.plug_in_mosaic(
        j,
        z,
        d[de.MESH_SIZE],
        1.,                                     # tile height
        d[de.WIRE_THICKNESS],
        d[de.NEATNESS],
        0,                                      # no split
        Globe.azimuth,
        .0,                                     # minimum color variation
        1,                                      # yes, antialias
        1,                                      # yes, average color
        ek.MESH_TYPE_LIST.index(d[de.MESH_TYPE]),
        0,                                      # smooth surface
        0                                       # black and white grout
    )

    # Erase white pixel.
    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))

    return z


def do_matter(maya):
    """
    Make a frame.

    maya: Fence
    Return: layer
        Wrap output
    """
    z = do_frame_with_filler(maya, make_pattern)

    antialias(z)
    return z


class Fence(FrameBasic):
    filler_k = de.FILLER_FE
    kind = material = de.FENCE
    wrap_k = de.WRAP_PA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
