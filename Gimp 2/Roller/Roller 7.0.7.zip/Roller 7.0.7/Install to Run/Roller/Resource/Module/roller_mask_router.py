#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    ADD_MASK_SELECTION,
    CHANNEL_OP_ADD,
    CHANNEL_OP_SUBTRACT,
    CHANNEL_OP_REPLACE,
    pdb
)
from roller_constant_identity import Identity as de
from roller_container import One, Run
from roller_deco import ready_shape, transform_foam
from roller_gimp_selection import (
    get_select_bounds, select_channel, select_rect
)
from roller_gimp_group_layer import merge_group_layer
from roller_gimp_image import add_layer, make_group_layer
from roller_gimp_layer import (
    clear_inverse_selection,
    color_selection_default,
    remove_layer,
    select_layer
)
from roller_gimp_layers import remove_layers
from roller_many_rect import Rect
from roller_mask_actor import ROUTE_MASK
import math


def add_group_mask(j, z):
    """
    Make a mask group for merging mask output.

    j: GIMP image
        Receive group layer.

    z: layer
        Its parent is the group's parent.

    Return: layer
        the new group
    """
    return make_group_layer(j, z.parent, 0, "Mask Group")


def attach_mask_sel(z):
    """
    Attach a mask layer, made from a selection, to another layer.
    Depends upon a mask selection and an actual layer.

    z: layer
        Receive mask.

    Return: mask or None
        newly created
    """
    if z:
        if not pdb.gimp_selection_is_empty(z.image):
            mask = pdb.gimp_layer_create_mask(z, ADD_MASK_SELECTION)

            pdb.gimp_layer_add_mask(z, mask)
            return mask


def create_face_main_mask(maya, d):
    """
    Apply Box Face Mask for main.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer
        mask material
    """
    j = Run.j
    z = maya.matter
    group = add_group_mask(j, z)

    for k in maya.main_q:
        create_facial_mask(maya, group, d, k)
    return finish_facing_mask(z, group)


def create_face_per_mask(maya, d):
    """
    Apply Box/Face/Per Mask.

    maya: Mask
    d: dict
        Mask Preset

    Return: layer or None
        mask
    """
    z = maya.matter
    j = Run.j
    group = add_group_mask(j, z)

    create_facial_mask(maya, group, d, maya.k)
    return finish_facing_mask(z, group)


def create_facial_mask(maya, group, d, arg):
    """
    Create a mask for transformed Face or Facing.
    Prep GIMP context prior to calling.

    maya: Maya
    group: layer
        destination of output

    d: dict
        Mask Preset

    arg: tuple
        Face or Facing map key

    Return: layer
        mask
    """
    j = Run.j
    z = add_layer(j, group, 0, "Mask")
    maya.rect = maya.model.get_facing_rect(arg)
    w, h = maya.rect[2:]

    select_rect(j, .0, .0, w, h)
    make_mask_sel(j, maya, d)
    color_selection_default(z, (255, 255, 255))
    return transform_foam(
        (.0, .0, w, h), z, maya.model.get_facing_foam(arg)
    )


def create_facing_main_mask(maya, d):
    """
    Apply Facing mask for main.

    maya: Maya
    d: dict
        Mask Preset

    p: function
        Make cell Facing Mask.

    Return: layer
        mask
    """
    j = Run.j
    z = maya.matter
    model = maya.model
    group = add_group_mask(j, z)

    for k in maya.main_q:
        z1 = create_facial_mask(maya, group, d, k)
        model.clip_facing(z1, k)
    return finish_facing_mask(z, group)


def feather_mask(j, d):
    """
    Feather a Mask selection. Require an existing selection.

    j: GIMP image
        Is the render.

    d: dict
        Mask Preset

    Return: state of selection
    """
    if not pdb.gimp_selection_is_empty(j) and d[de.FEATHER]:
        z = add_layer(j, None, 0, "Feather")

        color_selection_default(z, (255, 255, 255))

        a = d[de.FEATHER]
        f = a / d[de.STEPS]
        b = f

        while a > b:
            pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)
            pdb.gimp_selection_feather(j, b)

            b += f
            if not pdb.gimp_selection_is_empty(j):
                clear_inverse_selection(z)

        pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)
        pdb.gimp_image_remove_layer(j, z)


def finish_facing_mask(z, group):
    """
    Mask a merged group layer.

    z: layer
        Receive mask.

    group: layer
        Merge to create the mask's selection source.

    Return: drawable
        mask
    """
    z1 = merge_group_layer(group)

    select_layer(z1)

    mask = attach_mask_sel(z)

    remove_layer(z1)
    return mask


def make_facing_per_mask(maya, d):
    """
    Apply a Box/Facing Mask for Per.

    maya: Mask
    d: dict
        Mask Preset

    Return: layer or None
        mask
    """
    j = Run.j
    z = maya.matter
    group = add_group_mask(j, z)

    create_facial_mask(maya, group, d, maya.k)
    return finish_facing_mask(z, group)


def make_mask_sel(j, maya, d):
    """
    Create a mask selection from the current selection. The
    current selection determines the rectangular bounds of the mask.

    j: GIMP image
    maya: Maya
        Has 'matter', 'k', 'any_group' attributes.

    d: dict
        Mask Preset

    Return: state of selection
        The selection is ready to become a mask.
    """
    mask_type = d[de.TYPE]
    p = ROUTE_MASK.get(mask_type)
    is_sel, x, y, x1, y1 = get_select_bounds(j)

    if is_sel:
        if p:
            w, h = x1 - x, y1 - y
            w1, h1 = w * d[de.HORZ_SCALE], h * d[de.VERT_SCALE]

            # Create a mask-selection from the existing selection.
            p(
                j,
                One(
                    d=d,
                    maya=maya,

                    # Is the size of the mask influence, 'scale'.
                    scale=Rect(x + (w - w1) // 2., y + (h - h1) // 2., w1, h1),

                    # Is the bounding size of the cast material, 't'.
                    t=Rect(x, y, w, h),
                )
            )
            if d[de.INVERT]:
                sc = pdb.gimp_selection_save(j)

                select_rect(j, x, y, w, h)
                select_channel(j, sc, option=CHANNEL_OP_SUBTRACT)
                pdb.gimp_image_remove_channel(j, sc)

        feather_mask(j, d)
        rotate_mask(j, d)
    else:
        pdb.gimp_selection_none(j)


def mask_cell_main(maya, d):
    """
    Mask a main deco layer.

    maya: Maya
        Deco level (e.g. Border.WorkCell)

    d: dict
        Mask Preset

    Return: layer or None
        mask material
    """
    j = Run.j
    z = maya.matter

    # selection channel, 'sc'
    sc = None

    pdb.gimp_selection_none(j)

    # Create a selection from the main cells.
    for k in maya.main_q:
        maya.k = k
        ready_shape(maya, maya.value_d)

        if not pdb.gimp_selection_is_empty(j):
            make_mask_sel(j, maya, d)

        if sc:
            select_channel(j, sc, option=CHANNEL_OP_ADD)
            pdb.gimp_image_remove_channel(j, sc)
        if not pdb.gimp_selection_is_empty(j):
            sc = pdb.gimp_selection_save(j)

    if sc:
        pdb.gimp_image_remove_channel(j, sc)
    return attach_mask_sel(z)


def mask_cell_per(maya, d):
    """
    Mask a cell.

    maya: Maya
    d: dict
        Mask Preset

    Return: mask or None
    """
    z = maya.matter

    select_layer(z)
    make_mask_sel(Run.j, maya, d)
    return attach_mask_sel(z)


def mask_face_main(maya, d):
    """
    Mask Face/Plaque for main.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer
        mask material or None
    """
    return create_face_main_mask(maya, d)


def mask_face_per(maya, d):
    """
    Mask Face/Per output.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer
        mask
    """
    return create_face_per_mask(maya, d)


def mask_facing_main(maya, d):
    """
    Mask Facing for main.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer
        mask material
    """
    return create_facing_main_mask(maya, d)


def mask_facing_per(maya, d):
    """
    Mask Facing/Per output.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer
        mask
    """
    return make_facing_per_mask(maya, d)


def rotate_mask(j, d):
    """
    Rotate a Mask selection.

    j: GIMP image
        Is the render.

    d: dict
        Mask Preset

    Return: state of selection
    """
    if not pdb.gimp_selection_is_empty(j) and d[de.ANGLE]:
        z = add_layer(j, None, 0, "Rotate")

        color_selection_default(z, (0, 0, 0))

        # auto-center, 'True'; x and y, '0'
        z1 = pdb.gimp_item_transform_rotate(
            z, math.radians(d[de.ANGLE]), True, .0, .0
        )

        select_layer(z1)
        remove_layers((z, z1))
