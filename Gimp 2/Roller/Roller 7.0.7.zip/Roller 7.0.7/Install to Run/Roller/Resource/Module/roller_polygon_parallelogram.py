#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_identity import Identity as de
from roller_model_goo import Goo
from roller_polygon import calc_pin_xy, make_coord_list


def calc_parallelogram(model, o):
    """
    Calculate a grid leaning parallelogram shaped cell.

    For Model cell, calculate 'cell' and 'merge'
    rectangle and their inscribed 'form' polygon.

    model: Model
    o: One
        Has Cell/Type option as attribute.

    Return: dict
        {value: [bool, bool]}
        {cell key: [Plan vote change, Work vote change]}
    """
    vote_d = {}
    did_cell = model.past.did_cell
    row, column = model.grid
    goo_d = model.goo_d
    x, y, canvas_w, canvas_h = model.canvas_pocket.rect
    scale = o.parallelogram_scale

    # [intersect, ...]
    bottom_q = []
    top_q = []
    cell_q = []

    if o.grid_type == de.CELL_SIZE:
        # cell size
        # Correct cell size overflow.
        w = min(canvas_w, o.column_width)
        h = min(canvas_h, o.row_height)

        # grid size
        w1 = w * scale
        w2 = w - w1
        s = column * w1 + w2, row * h
        x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

    else:
        # Calculate the cell size for cell count.
        scale_1 = 1. - scale
        w = canvas_w / (scale_1 + column * scale)
        h = canvas_h / row
        w1 = w * scale
        w2 = w - w1

    if o.cell_shape == de.PARALLELOGRAM_RIGHT:
        x1 = x
        x += w2

    else:
        # left parallelogram
        x1 = x + w2

    for c in range(column + 2):
        top_q.append(round(x))
        bottom_q.append(round(x1))
        x += w1
        x1 += w1

    q_y = make_coord_list(canvas_h, row + 1, y, span=h)

    for c in range(column):
        cell_q += [min(top_q[c], bottom_q[c])]
        cell_q += [max(top_q[c + 1], bottom_q[c + 1])]

    for r_c in model.cell_q:
        r, c = r_c
        c1 = c * 2
        y, y1 = q_y[r], q_y[r + 1]
        a = goo_d[r_c] = Goo(r_c)
        x, x1 = cell_q[c1], cell_q[c1 + 1]

        # Prevent round to zero with max 1.
        a.cell.rect = a.merged.rect = \
            x, y, max(1., x1 - x), max(1., y1 - y)

        x, x1 = top_q[c], top_q[c + 1]
        x3, x2 = bottom_q[c], bottom_q[c + 1]
        a.form = x, y, x1, y, x2, y1, x3, y1
        vote_d[r_c] = did_cell(r_c)
    return vote_d
