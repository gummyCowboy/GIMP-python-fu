#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_any_group import ModelGroup
from roller_constant import Issue as vo, Signal as si, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_deco_margin import do_cell_main, do_cell_per, do_canvas
from roller_gimp_image import make_canvas_group, make_cast_group
from roller_maya import Canvas, CellRoute, Per, Runner
from roller_maya_detail import Detail, PlanMargin, PlanShape
from roller_plan_detail import (
    do_main_corner,
    do_main_dimension,
    do_main_position,
    do_main_ratio,
    do_main_shape,
    do_per_corner,
    do_per_dimension,
    do_per_position,
    do_per_ratio,
    do_per_shape
)
from roller_step import (
    find_canvas_shift, find_cell_shift, get_branch_part
)


class Margin(ModelGroup):
    """
    Create Margin Widget group. Assign view run
    processors and connect signal handlers.
    """

    def __init__(self, **d):
        ModelGroup.__init__(self, **d)

        node_k = get_branch_part(self.name_step_k)
        self.plan = {de.CANVAS: PlanCanvas, de.CELL: PlanCell}[node_k](self)
        self.work = {de.CANVAS: WorkCanvas, de.CELL: WorkCell}[node_k](self)
        baby = self.dna.model.baby
        self._is_cell = False

        if node_k == de.CELL:
            self._is_cell = True
            self._sequence_signal = si.CELL_MARGIN_CHANGE
            self.latch(baby, (si.CELL_SHIFT_CALC, self.on_cell_calc))
            self.latch(
                self.get_widget(de.PER), (si.PER_CHANGE, self.update_model)
            )

        elif node_k == de.CANVAS:
            # Respond to Model's Canvas change.
            self.latch(baby, (si.CANVAS_RECT_CALC, self.on_sequence_change))
            self._sequence_signal = si.CANVAS_MARGIN_CHANGE

        self.latch(self.booth, (si.VOTE_CHANGE, self.update_model))
        self.latch(self, (si.SEQUENCE, self.on_sequence))

    def do(self):
        """
        Override the AnyGroup function so that Past's view Signal can be sent.
        """
        super(Margin, self).do()

        p = self.dna.model.past.emit

        if self._is_cell:
            p(si.CELL_MARGIN_VIEW, Run.i)

            # Adapt to a missing Shift step.
            if not find_cell_shift(self.name_step_k):
                p(si.CELL_SHIFT_VIEW, Run.i)
        else:
            p(si.CANVAS_MARGIN_VIEW, Run.i)

            # Adapt to a missing Shift step.
            if not find_canvas_shift(self.name_step_k):
                p(si.CANVAS_SHIFT_VIEW, Run.i)

    def on_sequence(self, *_):
        """
        Update the Model's Margin values pronto.

        _: tuple
            (
                AnyGroup -> Sent the Signal., list ->
                [bool, bool]
                [plan vote, work vote]
                Indicate change with a True value.
            )
        """
        d = self.get_value_d()
        self.dna.model.baby.feed(self._sequence_signal, (d, True))

    def update_model(self, *_):
        """Respond to change in the Margin AnyGroup."""
        d = self.get_value_d()
        self.dna.model.baby.give(self._sequence_signal, (d, False))


class Chi(Runner):
    """Factor both plan and work-view-type Margin Maya."""

    def __init__(self, any_group, view_i, put):
        Runner.__init__(self, any_group, view_i, put, ())

    def get_value_d(self):
        return self.any_group.get_value_d()


# view-type____________________________________________________________________
class Plan(Chi):
    """Manage Draft and Plan view-type layer output."""
    put = (make_cast_group, 'group'),

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, self.put)


class Work(Chi):
    """A Margin work-view-type doesn't have layer output."""
    issue_q = 'matter',

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1, ())

    def dig(self):
        return
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Canvas_______________________________________________________________________
class PlanCanvas(Plan, Canvas):
    """Manage Canvas/Margin plan-view-type layer output."""
    issue_q = 'matter',
    put = (make_canvas_group, 'group'),
    vote_type = vo.MAIN

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Manage Widget reference and value.
        """
        self.do_matter = do_canvas

        Plan.__init__(self, any_group)
        Canvas.__init__(self)
        self.sub_maya[sm.MARGIN] = PlanMargin(any_group, self, do_canvas)

    def bore(self):
        """Manage layer output during a view run."""
        self.realize()
        self.sub_maya[sm.MARGIN].do()


class WorkCanvas(Work):
    """Doesn't have layer output."""
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Work.__init__(self, any_group)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Cell_________________________________________________________________________
class PlanSub(Plan):
    """Factor PlanCell and PlanPerCell."""

    def __init__(self, any_group, detail_sub_d, do_margin):
        """
        any_group: AnyGroup
        detail_sub_d:
            # POSITION, CORNER, DIMENSION, RATIO, CELL_SHAPE
            {detail sub type: make detail function, ...}

        do_margin: function
            Produce margin layer output.
        """
        Plan.__init__(self, any_group)

        self.sub_maya[sm.MARGIN] = PlanMargin(any_group, self, do_margin)
        self.sub_maya[sm.POSITION] = Detail(
            any_group, self, detail_sub_d[de.POSITION], de.POSITION
        )
        self.sub_maya[sm.CORNER] = Detail(
            any_group, self, detail_sub_d[de.CORNER], de.CORNER
        )
        self.sub_maya[sm.DIMENSION] = Detail(
            any_group, self, detail_sub_d[de.DIMENSION], de.DIMENSION
        )
        self.sub_maya[sm.RATIO] = Detail(
            any_group, self, detail_sub_d[de.RATIO], de.RATIO
        )
        self.sub_maya[sm.CELL_SHAPE] = PlanShape(
            any_group, self, detail_sub_d[de.CELL_SHAPE]
        )

    def bore(self):
        """Manage layer output during a view run."""
        self.realize()
        self.sub_maya[sm.MARGIN].do()
        self.sub_maya[sm.POSITION].do()
        self.sub_maya[sm.CORNER].do()
        self.sub_maya[sm.DIMENSION].do()
        self.sub_maya[sm.RATIO].do()
        self.sub_maya[sm.CELL_SHAPE].do()


class PlanCell(PlanSub, CellRoute):
    """Manage Cell/Margin plan-view-type layer output."""
    issue_q = 'matter', 'per'
    vote_type = vo.MAIN

    def __init__(self, any_group):
        self.do_matter = do_cell_main
        PlanSub.__init__(
            self,
            any_group,
            {
                de.CELL_SHAPE: do_main_shape,
                de.CORNER: do_main_corner,
                de.DIMENSION: do_main_dimension,
                de.POSITION: do_main_position,
                de.RATIO: do_main_ratio
            },
            do_cell_main
        )
        CellRoute.__init__(self, PlanCellPer)


class WorkCell(Work):
    """Has no layer output."""
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Work.__init__(self, any_group)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Cell/Per_____________________________________________________________________
class PlanCellPer(Per, PlanSub):
    """Manage plan-view-type Cell/Margin layer output for Per."""
    issue_q = 'matter', 'per'
    vote_type = vo.PER

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        PlanSub.__init__(
            self,
            any_group,
            {
                de.CELL_SHAPE: do_per_shape,
                de.CORNER: do_per_corner,
                de.DIMENSION: do_per_dimension,
                de.POSITION: do_per_position,
                de.RATIO: do_per_ratio
            },
            do_cell_per
        )
        Per.__init__(self, do_cell_per, k)
