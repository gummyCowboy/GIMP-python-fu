#!/usr/bin/env python
# -*- coding: utf-8 -*-
# noinspection PyUnresolvedReferences
from gimpfu import (   # type: ignore
    CLIP_TO_IMAGE, HISTOGRAM_ALPHA, HISTOGRAM_VALUE, LAYER_MODE_DIFFERENCE, pdb
)
from random import choice, randint, seed
from roller_constant import Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gegl import (
    edge, median_blur, neon, noise_rgb, spread, unsharp_mask, waterpixels
)
from roller_gimp_image import (
    add_layer_below, add_wip_base, check_matter, make_group_layer
)
from roller_gimp_layer import (
    blur_selection,
    clone_layer,
    clone_opaque_layer,
    color_layer_default,
    do_curves,
    make_clouds,
    saturate
)
from roller_gimp_mask import mask_from_maya
from roller_maya_build import SubBuild
from roller_maya_bump import Bump
from roller_maya_layer import check_mix_basic
from roller_preset_mod import do_mod


def do_drip_noise(j, z, d):
    """
    Make Drip Noise. Ensure there's no selection present,
    or this function will fail its intended outcome.

    j: GIMP image
        WIP

    z: layer
        Receive noise.

    d: dict
        Noise Preset

    Return: layer
        Has Noise output.
    """
    w = int(d[de.LENGTH])

    # Create edge with black background.
    pdb.plug_in_edge(z.image, z, 3, 1, 0)

    # Remove excessive edge.
    pdb.plug_in_erode(
        j, z,
        1,                     # propagate black
        7,                     # RGB channels
        1.,                    # full rate
        7,                     # direction mask
        0,                     # low limit
        255                    # upper limit
    )

    for i in range(w):
        # Create down-stroke line.
        pdb.plug_in_wind(
            j, z,
            .0,                 # Threshold All
            3,                  # bottom direction
            w - i,              # 1 <= strength <= 100
            0,                  # wind algorithm
            1,                  # leading edge
        )

        # Flatten the grey.
        unsharp_mask(z, .5, w - i, .0)

        # Create gradient density.
        median_blur(
            z,
            w - i,              # radius
            50.,
            alpha=50.
        )

        # Create an edge on the bottom of the drip.
        pdb.gimp_drawable_curves_spline(
            z,
            HISTOGRAM_VALUE,
            10,
            (.0, .0, .38, .0, .41, 1., .42, .42, 1., 1.)
        )

    # Remove most color.
    saturate(z, -90.)

    # Remove some gray.
    pdb.gimp_drawable_curves_spline(
        z, HISTOGRAM_VALUE, 6, (.0, .0, .1, .0, 1., 1.)
    )

    # Soften any line.
    median_blur(
        z,
        1,                      # radius
        50.,
        alpha=50.
    )

    # Remove black pixel created from 'edge' function.
    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

    # Invert light pixel to dark.
    pdb.gimp_drawable_invert(z, 0)

    if d[de.OPAQUE]:
        # Make opaque.
        z1 = z
        z = clone_opaque_layer(z)
        pdb.gimp_image_remove_layer(j, z1)
    return z


def do_ink_noise(j, z, d):
    """
    Make Ink Noise.

    j: GIMP image
        Has layer.

    z: layer
        Receive noise.

    d: dict
        Noise Preset

    Return: layer
        Has Noise output.
    """
    # lowest turbulence, '1.'
    pdb.plug_in_plasma(j, z, int(d[de.RANDOM_SEED] + Globe.seed), 1.)

    pdb.gimp_drawable_posterize(z, 2)
    neon(z, 1., 1.)
    pdb.gimp_selection_all(j)
    blur_selection(z, 4.)
    pdb.gimp_drawable_threshold(z, 0, .50, 1.)
    blur_selection(z, 1.)
    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    pdb.gimp_drawable_invert(z, 0)

    z1 = clone_layer(z)
    z1.mode = LAYER_MODE_DIFFERENCE

    blur_selection(z, 1.5)
    return pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)


def do_noise_matter(maya):
    """
    Create a Noise layer.

    maya: Maya
        Noise

    Return: layer
        Has Noise output.
    """
    j = Run.j
    d = maya.value_d
    group = maya.group
    n = d[de.TYPE]

    if n == de.DRIP:
        z = clone_layer(maya.super_maya.matter)
        z1 = add_layer_below(z, "Clouds")

        make_clouds(z1, int(d[de.RANDOM_SEED] + Globe.seed))
        unsharp_mask(z1, d[de.RADIUS], 300., .0)

        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
        z.name = "{} {}".format(group.name, "Material")
        pdb.gimp_image_reorder_item(j, z, group, 0)

    else:
        z = add_wip_base("Material", group)

    pdb.gimp_selection_none(j)

    z = ROUTE_NOISE[n](j, z, d)
    return do_mod(z, d[rk.BRW][de.MOD])


def do_rift_noise(j, z, d):
    """
    Make Rift Noise for a layer.

    j: GIMP image
        Has layer.

    z: layer
        Receive noise.

    d: dict
        Noise Preset

    Return: layer
        noise
    """
    seed_ = int(Globe.seed + d[de.RANDOM_SEED])

    seed(seed_)

    # Generate line.
    # The horizontal and vertical sizes are randomized.
    pdb.plug_in_solid_noise(
        j, z,
        0,                      # no tile-able
        1,                      # yes, turbulent
        seed_,
        int(d[de.NOISE_AMOUNT]),
        float(randint(1, 4)),
        float(randint(1, 4))
    )

    # Harden the noise.
    # The radius is randomized.
    pdb.plug_in_unsharp_mask(
        j, z,
        choice((1., 4.)),
        54.,                    # amount
        .0                      # threshold
    )

    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
    return z


def do_speck_noise(j, z, d):
    """
    Make Speck Noise for a layer.

    j: GIMP image
        Has layer.

    z: layer
        Receive noise.

    d: dict
        Noise Preset
        {Identity: value}

    Return: layer
        Has Noise output.
    """
    z1 = clone_layer(z)
    f = (d[de.SPECK_NOISE] + .5) / 7.

    # red, green, and blue noise, 'noise'
    pdb.plug_in_rgb_noise(
        j, z1,
        1,                    # independent
        0,                    # not correlated
        .0,
        .0,                   # green
        .0,                   # blue
        f
    )

    color_layer_default(z, (255, 255, 255))

    z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

    for i in range(4):
        pdb.plug_in_erode(
            j, z,
            1,                # propagate black
            7,                # RGB channels
            1.,               # full rate
            0,                # direction mask
            0,                # lower limit
            12                # upper limit
        )
        pdb.plug_in_rgb_noise(
            j, z,
            1,                # independent
            0,                # not correlated
            f,                # red
            f,                # green
            f,                # blue
            .0
        )

    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
    saturate(z, -75.)
    edge(z)
    blur_selection(z, 1.)
    pdb.gimp_selection_none(j)

    pdb.plug_in_despeckle(
        j, z,
        1,                    # radius
        3,                    # recursive adaptive
        0,                    # white cut-off
        255                   # black cut-off
    )
    pdb.plug_in_unsharp_mask(
        j, z,
        12.,                  # radius
        50.,                  # amount
        .0                    # threshold
    )
    pdb.gimp_drawable_curves_spline(
        z,
        HISTOGRAM_ALPHA,
        8,                    # coordinate count
        (.0, .0, .25, .0, .62, .62, .9, 1.)
    )
    do_curves(z, (.0, .0, 1., .8))
    return z


def do_water_noise(j, z, d):
    """
    Make WaterPixel Noise for a layer.

    j: GIMP image
        Has layer.
        not used

    z: layer
        Receive noise.

    d: dict
        Noise Preset

    Return: layer
        Has Noise output.
    """
    a = int(d[de.RANDOM_SEED] + Globe.seed)

    for i in range(3):
        noise_rgb(z, 1., 1., 1., 1., a + i)

    pdb.gimp_selection_none(j)
    waterpixels(z)
    pdb.gimp_brightness_contrast(z, 0, 75)

    b = 10

    for _ in range(3):
        spread(z, a, amount_x=b, amount_y=b)
        b -= 2

    pdb.plug_in_colortoalpha(j, z, (127, 127, 127))
    return z


def make_group(maya):
    """
    Make a Noise group layer. Is a sub-group of the super maya's group layer.

    maya: Maya
    Return: group layer
        Noise output parent
    """
    parent = maya.super_maya.group
    group = maya.group

    if not group:
        return make_group_layer(Run.j, parent, 0, de.NOISE)
    return group


class Noise(SubBuild):
    """Process change for a Noise Preset."""
    is_seeded = True
    issue_q = 'mode', 'matter', 'opacity'
    put = (
        (make_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            origin of option

        super_maya: Maya
            The Maya's 'matter' layer alpha masks the output noise.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        bump_q = k_path + (rk.BRW, de.BUMP)

        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (rk.BRW, de.MOD),
                k_path + (rk.BRW, de.MOD, de.BLUR_D)
            ],
            do_noise_matter
        )
        self.sub_maya[sm.BUMP] = Bump(any_group, self, bump_q)

    def do(self, d, is_change, is_mask):
        """
        Manage layer output during a view run.

        d: dict
            Noise Preset
            {Identity: value}

        is_change: bool
            Is True if the cast Maya has change.

        is_mask: bool
            Is True if the super-maya has change.

        Return: bool
            Is True if the Noise changed.
        """
        self.value_d = d
        self.is_matter |= is_change
        self.go = d[de.SWITCH]

        if self.go:
            self.is_matter |= is_change
            m = self.is_matter or is_mask

        else:
            m = bool(self.matter)

        self.realize()

        if self.go:
            if self.matter:
                if m:
                    mask_from_maya(self.super_maya, self.matter)
                self.sub_maya[sm.BUMP].do(
                    d[rk.BRW][de.BUMP], self.is_matter, is_mask
                )
            else:
                self.die()

        self.reset_issue()
        return m


# {Noise type: Noise output function}
ROUTE_NOISE = {
    de.INK: do_ink_noise,
    de.DRIP: do_drip_noise,
    de.RIFT: do_rift_noise,
    de.SPECK: do_speck_noise,
    de.WATER: do_water_noise
}
