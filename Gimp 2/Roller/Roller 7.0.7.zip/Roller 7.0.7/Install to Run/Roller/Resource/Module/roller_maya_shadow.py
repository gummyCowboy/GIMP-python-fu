#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Run
from roller_constant import SubMaya as sm
from roller_constant_identity import Identity as de
from roller_gimp_image import check_matter
from roller_gimp_layer import clear_selection, set_layer_mode, select_layer
from roller_gimp_selection import invert_selection
from roller_maya_build import SubBuild
from roller_gimp_mode import get_mode
from roller_preset_shadow import make_shadow, make_shadow_inner


def check_mix_shadow(maya):
    """
    Determine Shadow layer mode change.

    maya: Maya
    """
    z = maya.matter
    if z:
        if maya.is_mode:
            Run.is_back |= set_layer_mode(z, get_mode(maya.value_d))


def do_inner_shadow(maya):
    """
    Create an Inner Shadow layer.

    maya: Shadow
    Return: layer or None
        Inner Shadow
    """
    z = maya.super_maya.group
    if z:
        return make_shadow_inner(
            maya.value_d,
            z,
            maya.cast_maya[0].matter,
            name=z.name + " Inner Shadow"
        )


def do_inner_shadow_overlap(maya):
    """
    Create an Inner Shadow layer from an overlap layer.

    maya: Shadow
    Return: layer or None
        Inner Shadow
    """
    # Inner Shadow layer list, 'q'
    # The primary cast is skipped, '1'.
    q = [a.matter for a in maya.cast_maya[1:]]
    parent = maya.super_maya.group
    z = make_shadow(
        maya.value_d, parent, q, name=parent.name + " Inner Shadow "
    )
    cast_z = maya.cast_maya[0].matter

    select_layer(cast_z)
    invert_selection(cast_z.image)
    clear_selection(z)
    return z


def do_shadow_1(maya):
    """
    Create a Shadow 1 layer.

    maya: Shadow
    Return: layer or None
        Shadow #1
    """
    return do_shadow_num(maya, "1")


def do_shadow_2(maya):
    """
    Create a Shadow 2 layer.

    maya: Shadow
    Return: layer or None
        Shadow #2
    """
    return do_shadow_num(maya, "2")


def do_shadow_num(maya, n):
    """
    Create a numbered Shadow layer.

    maya: Shadow
    n: string
        Shadow number
        1 or 2

    Return: layer or None
        shadow
    """
    # list of layer to cast shadow, 'q'
    q = []

    for i in maya.cast_maya:
        q.append(i.matter)

    z = maya.super_maya.group
    if z:
        return make_shadow(maya.value_d, z, q, name=z.name + " Shadow " + n)


class Shadow1(SubBuild):
    """
    Manage Shadow 1 layer output. Shadow 1 can process multiple caster layer,
    and in the layer dock, its shadow output is below any caster layer.
    """
    issue_q = 'matter', 'mode'
    put = (check_matter, 'matter'), (check_mix_shadow, None)

    def __init__(self, any_group, super_maya, cast_maya, k_path):
        """
        any_group: AnyGroup
            origin of option

        super_maya: Maya
            Is the super Shadow.

        cast_maya: tuple
            (Maya, ...)
            Each Maya's 'matter' layer alpha forms the caster.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        self.cast_maya = cast_maya
        SubBuild.__init__(
            self, any_group, super_maya, k_path + (de.SHADOW_1,), do_shadow_1
        )

    def do(self, d, is_outer):
        """
        Manage layer output during a view run.

        d: dict
            Shadow Preset
            {Identity: Widget value}

        is_outer: bool
            Is True if the shadow caster group has change.

        Return: bool
            Is True if there was change.
        """
        d = self.value_d = d[de.SHADOW_1]
        self.go = d[de.SWITCH]
        self.is_matter |= is_outer

        self.realize()

        m = self.is_matter

        self.reset_issue()
        return m


class Shadow2(SubBuild):
    """
    Produces in the same way as Shadow 1, but has different key attribute.
    """
    issue_q = 'matter', 'mode'
    put = (check_matter, 'matter'), (check_mix_shadow, None)

    def __init__(self, any_group, super_maya, cast_maya, k_path):
        """
        any_group: AnyGroup
            Is where this option originates.

        super_maya: Maya
            Is the super Shadow.

        cast_maya: tuple
            (Maya, ...)
            Each Maya's 'matter' layer alpha forms the caster.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        self.cast_maya = cast_maya
        SubBuild.__init__(
            self, any_group, super_maya, k_path + (de.SHADOW_2,), do_shadow_2
        )

    def do(self, d, is_outer):
        """
        Manage layer output during a view run.

        d: dict
            Shadow Preset

        is_outer: bool
            Is True if the shadow caster group has change.

        Return: bool
            Is True if there was change.
        """
        d = self.value_d = d[de.SHADOW_2]
        self.go = d[de.SWITCH]
        self.is_matter |= is_outer

        self.realize()

        m = self.is_matter

        self.reset_issue()
        return m


class Inner(SubBuild):
    """
    Manage Inner Shadow layer output. Inner Shadow processes one caster layer,
    and in the Layers dock, its shadow output lies above the caster layer.
    """
    issue_q = 'matter', 'mode'
    put = (check_matter, 'matter'), (check_mix_shadow, None)

    def __init__(self, any_group, super_maya, cast_maya, k_path):
        """
        any_group: AnyGroup
            Is the origin of this option.

        super_maya: Maya
            Is the super Shadow.

        cast_maya: tuple
            (Maya, ...)
            The Maya in position zero is the Inner Shadow caster.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        self.cast_maya = cast_maya
        self.is_check_inward = len(cast_maya) > 1
        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            k_path + (de.INNER_SHADOW,),
            self.do_matter
        )

    def do(self, d, is_inner):
        """
        Manage layer output during a view run.

        d: dict
            Shadow Preset

        is_inner: bool
            Is True if the shadow caster has change.

        Return: bool
            Is True if the Inner Shadow changed.
        """
        d = self.value_d = d[de.INNER_SHADOW]
        self.go = d[de.SWITCH]
        m = self.is_matter = self.is_matter or is_inner

        self.realize_vote()
        return m

    def do_matter(self, *q):
        """
        Route the Inner Shadow function depending on the Frame/Wrap/Type.

        q: tuple
            (Maya,)
        """
        # output function, 'p'
        p = do_inner_shadow

        if self.is_check_inward:
            # If 'is_inward', then the wrap affects the inner shadow.
            if self.cast_maya[1].is_inward:
                p = do_inner_shadow_overlap
        return p(*q)


class Shadow(SubBuild):
    """Manage layer output for a Shadow Preset."""
    issue_q = 'matter',
    put = ()

    def __init__(self, any_group, super_maya, cast_maya, k_path):
        """
        cast_maya: tuple
            (Maya, ...)
            Each Maya's 'matter' layer alpha becomes part of the output.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.

        super_maya: Maya
            Has the output destination group layer.

        cast_maya: tuple
            Ordered where the branch shadow caster is first.
            (Maya, ...)
            Each Maya's 'matter' layer alpha is a caster.
            If 'has_inner', then the first Maya casts inner shadow.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        SubBuild.__init__(
            self, any_group, super_maya, k_path + (de.SHADOW_SWITCH,), None
        )

        self.group = None
        self.sub_maya[sm.SHADOW1] = Shadow1(any_group, self, cast_maya, k_path)
        self.sub_maya[sm.SHADOW2] = Shadow2(any_group, self, cast_maya, k_path)
        self.sub_maya[sm.INSET] = Inner(any_group, self, cast_maya, k_path)

    def do(self, d, is_inner, is_outer, group):
        """
        Manage layer output during a view run.

        d: dict
            Shadow Preset

        is_inner: bool
            Is True if the shadow caster has change.

        is_outer: bool
            Is True if the shadow caster group has change.

        group: group layer
            Parent Shadow #1 and Shadow #2 output.

        Return: bool
            Is True if Shadow changed.
        """
        self.value_d = d
        self.group = group
        self.go = d[de.SHADOW_SWITCH][de.SWITCH]
        e = self.sub_maya

        if self.go:
            is_outer |= self.is_matter
            m = e[sm.SHADOW1].do(d, is_outer)
            m |= e[sm.SHADOW2].do(d, is_outer)
            m |= e[sm.INSET].do(d, is_inner)

        else:
            m = bool(
                e[sm.SHADOW1].matter or
                e[sm.SHADOW2].matter or
                e[sm.INSET].matter
            )
            self.die()

        self.reset_issue()
        return m

    def get_any_vote(self):
        """
        Determine the status of Shadow vote.

        Return: bool
            Is True if there is change.
        """
        return (
            self.is_matter or
            self.sub_maya[sm.SHADOW1].is_matter or
            self.sub_maya[sm.SHADOW2].is_matter or
            self.sub_maya[sm.INSET].is_matter
        )

    def reset_all_issue(self):
        """Call to reset issue when the 'do' function isn't used."""
        self.reset_issue()
        self.sub_maya[sm.SHADOW1].reset_issue()
        self.sub_maya[sm.SHADOW2].reset_issue()
        self.sub_maya[sm.INSET].reset_issue()
