#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_widget_box import Box as boxer
import gtk  # type: ignore


class Splitter:
    """Create two equal-sized vertical boxes on the x-axis."""

    def __init__(self, padding=None, has_inner_padding=False):
        """
        Create the Splitter.

        padding: tuple
            of int
            'gtk.Alignment' padding
            top, bottom, left, right

        has_inner_padding: flag
            If True, then the inner boxes are padded.
        """
        self.box = self.container = gtk.HBox()

        if padding:
            g = self.container = gtk.Alignment(0, 0, 1, 0)
            g.add(self.box)
            g.set_padding(*padding)

        g = self.left = boxer(align=(0, 0, 1, 1))
        g1 = self.right = boxer(align=(0, 0, 1, 1))

        if has_inner_padding:
            g.set_padding(0, 0, 0, 2)
            g1.set_padding(0, 0, 2, 0)

    def both(self, g, g1):
        """
        Add two Widgets to the Splitter.

        g: widget
            left side

        g1: widget
            right side
        """
        self.left.add(g)
        self.right.add(g1)

    def no_pack(self):
        """Add the two 'gtk.Alignment' objects to the box."""
        self.box.add(self.left)
        self.box.add(self.right)

    def pack(self):
        """
        Make the the two VBoxes the same size.
        Add the same-sized VBoxes to the HBox.
        """
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

        # Transform the size.
        q = self.left, self.right
        for g in q:
            same_size.add_widget(g)
            self.box.add(g)
