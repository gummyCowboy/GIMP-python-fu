#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant import SCROLL_SPAN, Define as df, Signal as si
from roller_utility import seal
from roller_helm import Helm
from roller_oz import make_preset_path, json_load
from roller_ring import Ring
import gobject  # type: ignore
import gtk      # type: ignore

TITLE = "Roller 7.0.7"


def load_window_pose():
    """Load the Window position dictionary if it exists."""
    if not Window.has_loaded_pose:
        n = Window.pose_file = make_preset_path(
            u"Window Position", u"Window Position"
        )
        d = json_load(n, is_shown=False)

        if d:
            Window.pose_d = deepcopy(d)
            Window.last_pose_d = deepcopy(d)
        Window.has_loaded_pose = True


class Window(gobject.GObject):
    """Is a GTK Window or GTK Dialog."""
    # Are signal that can be emitted by this class.
    __gsignals__ = si.WINDOW_DICT

    # Window position dict
    # {string: tuple} -> {Window key: (x, y)}
    pose_d = {}

    # path to the Window position file, 'pose_file'
    pose_file = ""

    # The Window position dict that has been saved/loaded.
    last_pose_d = {}

    # Is True after the first file load op.
    has_loaded_pose = False

    def __init__(self, d, is_dialog=True):
        """
        Create a window.

        The new Window can be the main Window or a Dialog.

        d: dict
            Initialize the Window.
        """
        def _center():
            return w // 2, h // 2

        # for custom signal(s)
        gobject.GObject.__init__(self)

        self.port = self._cancel_hook = self._accept_hook = None
        self.is_dialog = is_dialog
        self.canceled = False

        # Is the Window's key for the Window position dict, 'self.pose_key'.
        self.pose_key = d[df.WINDOW_KEY]

        if is_dialog:
            self.is_main = False

            # no buttons, 'None'
            g = self.gtk_win = gtk.Dialog(
                d[df.WINDOW_KEY],
                d[df.GTK_WIN],
                gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
                None
            )

        else:
            # main
            self.is_main = True
            g = self.gtk_win = gtk.Window()
            g.set_title(TITLE)

        a = self.gtk_win.allocation
        w, h = Window.get_screen_res()

        if is_dialog:
            # Make sure the position isn't off screen.
            e = Window.pose_d
            x, y = e.get(self.pose_key, _center())
            x = seal(x, 0, w - a.width)
            y = seal(y, 0, h - a.height - SCROLL_SPAN)

        else:
            x, y = _center()

            # IN Windows 10 measured Window and divided by 2, '170' and '220'
            x, y = x - 170, y - 220

            x, y = max(0, x), max(0, y)

        g.move(x, y)
        self.gtk_win.connect('delete_event', self.cancel_window)
        self.connect(si.ACCEPT_WINDOW, self.accept_window)
        self.connect(si.CANCEL_WINDOW, self.cancel_window)
        Ring.gob.connect(si.WINDOW_SIZE_CHANGE, self.on_window_size_change)
        Ring.gob.connect(si.WINDOW_XY_CHANGE, self.on_window_xy_change)

    def _close(self, *_):
        """
        Close the window. Possibly exit the main loop.

        _: tuple
            (GTK window, GTK Event)
            Triggered close window.

        Return: true
            Tell GTK that the closing operation is handled.
        """
        g = self.gtk_win
        x, y = g.get_position()

        if min(x, y) > -1:
            if not self.is_main:
                Window.pose_d[self.pose_key] = x, y

        if self.is_dialog:
            g.response(0)

        else:
            g.destroy()
            gtk.main_quit()
            self.gtk_win = None

        # Let GTK know that a key-type event has been handled.
        return True

    def accept_window(self, _, g):
        """
        Call the Port accept-hook and close the Window.

        _: Window
            Sent the Signal.

        g: Button
            Is responsible.

        Return: True
            GTK, it is done.
        """
        if self._accept_hook:
            if self.is_main:
                self.gtk_win.iconify()
            self._accept_hook(g)
        return self._close()

    def add(self, g):
        """
        Add an object to the Window.

        g: object
            to add to the Window
        """
        self.gtk_win.add(g)

    def bring_dialog(self, g, d=None):
        """
        Make a GTK Dialog Window.

        g: OptionButton
            Referred to as 'repo'.
            Is responsible.

        d: dict or None
            Initialize the Port.
        """
        d = {} if not d else d
        get_key_q = Helm.get_key_q
        before = get_key_q()

        Ring.pressure()
        load_window_pose()
        self.emit(si.DIALOG_OPEN, self)

        dialog = Window(
            {
                df.GTK_WIN: g.roller_win.gtk_win,
                df.WINDOW_KEY: g.dialog.window_key
            },
            is_dialog=True
        )
        gtk_win = dialog.gtk_win

        d.update({df.ROLLER_WIN: dialog})

        port = dialog.port = g.dialog(d, g)

        port.draw()
        dialog.set_hook(port.get_hook())
        gtk_win.vbox.add(port)
        gtk_win.show_all()
        dialog.emit(si.DIALOG_DRAWN, self)
        gtk_win.run()
        gtk_win.destroy()
        self.emit(si.DIALOG_CLOSE, self)

        # Remove non-reusable AnyGroup.
        if port.is_dirt:
            for i in get_key_q():
                if i not in before:
                    Helm.remove_step(i)

        g.widget.grab_focus()

    def cancel_window(self, *_):
        """
        Close the GTK Window or Dialog.

        _: tuple
            not used

        Return: True
            GTK, it is done.
        """
        self.canceled = True

        if self._cancel_hook:
            self._cancel_hook()
        return self._close()

    def get_remaining_dim(self, w, h):
        """
        Keep the Window from drawing off screen.
        Return the width and height of the screen space
        to the right and bottom of the Window.
        """
        w1, h1 = Window.get_screen_res()

        if self.pose_key in Window.pose_d:
            x, y = Window.pose_d[self.pose_key]

        else:
            x = w1 // 2
            y = h1 // 2

        x = seal(x, x + SCROLL_SPAN, w1 - 200)
        y = seal(y, y + SCROLL_SPAN, h1 - 200)
        return min(w, w1 - x), min(h, h1 - y)

    @staticmethod
    def get_screen_res():
        """
        Return: tuple
             width, height
             screen's dimension
        """
        return gtk.gdk.screen_width(), gtk.gdk.screen_height()

    def on_window_xy_change(self, *_):
        """
        Resize a Window, but the allocation isn't correct so the process
        only works on the second resize attempt with the old Window size.
        In other words, the process is one-step behind the current state.
        """
        if self.gtk_win:
            w, h = Window.get_screen_res()
            a = self.gtk_win.allocation
            x, y = self.gtk_win.get_position()
            x1 = seal(x, 0, w - a.width)
            y1 = seal(y, 0, h - a.height - SCROLL_SPAN)
            if (x, y) != (x1, y1):
                # GTK has an invalid state where the position is negative.
                if x1 > -a.width and y1 > -a.height:
                    self.gtk_win.move(x1, y1)
        return True

    def on_window_size_change(self, *_):
        """
        Resize a Window, but the allocation isn't correct so the process
        only works on the second resize attempt with the old Window size.
        In other words, the process is one-step behind the current state.
        """
        if self.gtk_win:
            self.gtk_win.resize(1, 1)
            Ring.plug(si.WINDOW_XY_CHANGE, self)
        return True

    def resize(self):
        """Add a change size signal to the signal filter."""
        Ring.plug(si.WINDOW_SIZE_CHANGE, self)

    def set_hook(self, hook_q):
        """
        Set the Cancel and Accept Port hooks.

        hook_q: tuple
            (function, function) -> (Cancel hook, Accept hook)
        """
        self._cancel_hook, self._accept_hook = hook_q


# Register the custom signals.
gobject.type_register(Window)
