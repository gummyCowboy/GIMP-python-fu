#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_identity import Identity as de
from roller_tooltip_text import Tip
from roller_port_preview import PortPreview
from roller_widget_button import Button
from roller_widget_dna import DNA


class PortImageChoice(PortPreview):
    """Is a display container for the Image Choice Preset."""
    window_key = "Image"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_image_options(self, box):
        """
        Draw the Image Choice Preset.

        box : VBox
            container for Widget
        """
        dna = DNA(de.IMAGE_CHOICE, {'make_vbox', 'switched'}, {})

        dna.inherit(self.repo.any_group.dna, False)
        box.add(dna.vbox)
        self.draw_group(dna)

    def draw(self):
        """Draw Widget."""
        self.draw_column((self._draw_image_options, self.draw_process))

    def get_group_value(self):
        """
        Fetch the Preset value.

        Return: dict
            Image Preset
        """
        return self.any_group.get_value_d()

    def on_port_change(self, g):
        """
        Respond to Widget change. Set the tooltip for the Type ComboBox.

        g: Widget
            Is responsible.
        """
        # ComboBox tool-tips don't stick during
        # initialization, so the tips are made on the go.
        if not isinstance(g, Button) and self.any_group:
            d = self.any_group.get_value_d()
            for k in d:
                if k == de.TAB:
                    g1 = self.any_group.get_widget(k)
                    g1.widget.set_tooltip_text(Tip.TAB)
                elif k == de.IMAGE_NAME:
                    g1 = self.any_group.get_widget(k)
                    g1.widget.set_tooltip_text(Tip.IMAGE_NAME)
        super(PortImageChoice, self).on_port_change(g)
