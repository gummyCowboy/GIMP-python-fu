#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import (   # type: ignore
    HISTOGRAM_BLUE,
    HISTOGRAM_GREEN,
    HISTOGRAM_RED,
    LAYER_MODE_ADDITION,
    LAYER_MODE_BURN,
    LAYER_MODE_OVERLAY,
    LAYER_MODE_SCREEN,
    LAYER_MODE_VIVID_LIGHT,
    pdb
)
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_frame import do_image_selection
from roller_frame_alt import Overlap
from roller_gimp_context import prep_brush, set_gimp_brush
from roller_gimp_image import make_group_layer
from roller_gimp_layer import (
    clone_layer, do_curves, get_layer_position, saturate
)
from roller_preset_brush import brush_stroke


def do_matter(maya):
    """
    Add a frame to the image material on a layer.

    maya: Wrap
    Return: layer
        Wrap 'matter'
    """
    # Wrap Preset, 'd'
    d = maya.value_d
    init_brush(d)
    return do_image_selection(
        maya, do_selection, embellish, "Material", is_clip=d[de.CLIP]
    )


def do_selection(maya, z):
    """
    Make a frame from a selection.

    maya: Joint
    z: layer
        Receive the frame.

    Return: layer
        Wrap material
    """
    j = Run.j
    d = maya.value_d

    pdb.plug_in_sel2path(j, z)
    pdb.gimp_context_set_opacity(100.)

    if j.active_vectors:
        e = deepcopy(d)
        e[de.BRUSH] = 'dots'
        e[de.HARDNESS] = 1.
        e[de.OPACITY] = 100.
        e[de.BRUSH_SPACING] = d[de.BRUSH_SIZE] / 15.
        e[de.UPSCALE] = \
            e[de.UP_SPACE] = \
            e[de.BRUSH_ANGLE] = \
            e[de.ANGLE_JITTER] = .0

        for stroke in j.active_vectors.strokes:
            brush_stroke(z, e, e[de.BRUSH], stroke)
        pdb.gimp_image_remove_vectors(j, j.active_vectors)
    return z


def embellish(_, z):
    """
    Add color and depth to frame material.

    _: Maya
        not used

    z: layer
        Has frame.

    Return: layer
        Wrap material
    """
    j = Run.j
    group = make_group_layer(j, z.parent, get_layer_position(z), "Wrap", z=z)
    z1 = clone_layer(z)
    z1.mode = LAYER_MODE_OVERLAY
    z1.opacity = 25.
    z1 = clone_layer(z1)
    z1.mode = LAYER_MODE_BURN
    z1.opacity = 25.

    pdb.plug_in_emboss(
        j, z,
        Globe.azimuth,
        Globe.elevation,
        3,                              # depth
        1                               # emboss
    )
    do_curves(z, (.0, .2, 8., .6, 1., 1.))

    z1 = clone_layer(z)
    z2 = clone_layer(z1)
    z3 = clone_layer(z2)
    z1.mode = LAYER_MODE_VIVID_LIGHT
    z1.opacity = 80.
    z2.mode = LAYER_MODE_SCREEN
    z3.mode = LAYER_MODE_ADDITION
    z = pdb.gimp_image_merge_layer_group(j, group)

    pdb.gimp_drawable_curves_spline(
        z,
        HISTOGRAM_RED,
        6,                              # coordinate count
        (.0, .0, .5, .8, 1., 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        HISTOGRAM_GREEN,
        6,                              # coordinate count
        (.0, .0, .5, .3, 1., 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        HISTOGRAM_BLUE,
        8,                              # coordinate count
        (.0, .0, .2, .06, .7, .5, 1., 1.)
    )
    saturate(z, -33.)
    return z


def init_brush(d):
    """Initialize the brush before stroking the frame."""
    prep_brush()
    set_gimp_brush("dots")
    pdb.gimp_context_set_brush_size(d[de.BRUSH_SIZE])


class Joint(Overlap):
    is_embossed = True
    kind = material = de.JOINT
    wrap_k = de.WRAP_JO

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        Overlap.__init__(self, any_group, super_maya, k_path, do_matter)
