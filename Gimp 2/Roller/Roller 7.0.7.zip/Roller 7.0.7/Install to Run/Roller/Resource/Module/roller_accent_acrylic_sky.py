#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (        # type: ignore
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_EXCLUSION,
    LAYER_MODE_LCH_LIGHTNESS,
    LAYER_MODE_SUBTRACT,
    pdb
)
from roller_container import Globe, Run
from roller_gegl import edge, shift, waterpixels
from roller_constant import Accent as by, Row as rk
from roller_constant_identity import Identity as de
from roller_gimp_image import insert_copy
from roller_gimp_layer import blur_selection, clone_layer, dilate
from roller_maya_sub_accent import SubAccent


def do_matter(maya):
    """
    Make a Acrylic Sky matter layer.

    maya: AcrylicSky
    Return: layer or None
        'matter'
    """
    def copier(_n):
        """
        Copy the output.

        _n: string
            layer name of copy

        Return: layer
            the copy
        """
        return insert_copy(group, parent)

    j = Run.j
    d = maya.value_d
    z = maya.bg_z
    parent, group = maya.init_background_groups(j)
    maya.bg_z = None
    bg_z = clone_layer(z, n="Exclusion")
    z1 = clone_layer(z, n="Difference")
    z2 = clone_layer(z1, n="Subtract")
    z.mode = z2.mode = LAYER_MODE_SUBTRACT
    z1.mode = LAYER_MODE_DIFFERENCE

    blur_selection(z, 60)
    blur_selection(z1, 30)
    pdb.plug_in_gimpressionist(j, z2, "Furry")

    z = copier("LCH Lightness")
    z.mode = LAYER_MODE_LCH_LIGHTNESS

    waterpixels(z, size=int(d[de.SUPERPIXEL_SIZE]))

    z = clone_layer(z, n="Edge")

    edge(z)

    z = copier("Waterpixels")

    waterpixels(z)

    z.mode = LAYER_MODE_LCH_LIGHTNESS
    z = copier("Dilate")

    # no linear, '0'
    pdb.gimp_drawable_invert(z, 0)

    dilate(z)
    dilate(z)

    bg_z.mode = LAYER_MODE_EXCLUSION

    blur_selection(bg_z, 500)
    pdb.gimp_image_reorder_item(j, bg_z, group, 0)

    z = pdb.gimp_image_merge_layer_group(j, group)

    # Create a paint brush texture.
    # I put 'int' on the RadioRow output,
    # SHIFT_DIRECTION, as a float got into a Preset.
    shift(
        z,
        by.SHIFT_DIRECTION_LIST[int(d[de.SHIFT_DIRECTION])].lower(),
        d[de.SHIFT],
        int(d[de.RANDOM_SEED] + Globe.seed)
    )

    blur_selection(z, 1)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class AcrylicSky(SubAccent):
    kind = de.ACRYLIC_SKY

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
