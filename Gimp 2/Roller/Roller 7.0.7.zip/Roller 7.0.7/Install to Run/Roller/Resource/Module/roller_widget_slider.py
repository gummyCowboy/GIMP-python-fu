#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, uniform
from roller_container import Globe
from roller_constant import Define as df, Signal as si
from roller_constant_identity import Identity as de
from roller_ring import Ring
from roller_wip import Wip
from roller_widget import Widget
import gobject  # type: ignore
import gtk      # type: ignore

RESPOND_KEY = {'space', 'Return'}


class Slider(Widget):
    """
    Combine an HScale, a left arrow Button, a right arrow
    Button, and a SpinButton with the same Adjustment.
    """
    change_signal = 'value-changed'
    has_table_label = True

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        self._precision = d.get(df.PRECISION, 0)
        self._limit = map(float, d[df.LIMIT])
        self._greater_g = d.get(df.GREATER_G)
        hbox = gtk.HBox()

        if df.PAGE_INCR in d:
            self._page_incr = d[df.PAGE_INCR]

        else:
            spread = self._limit[1] - self._limit[0]
            divisor = 20 if spread > 40 else 10

            if self._precision > 0:
                divisor = float(divisor)
            self._page_incr = round(spread / divisor, self._precision)

        # step increment
        if self._precision == 0:
            climb_rate = .12
            step_inc = (1., self._page_incr)

        else:
            climb_rate = .025

            if df.STEP_INCR in d:
                step_inc = d[df.STEP_INCR], self._page_incr

            elif self._precision == 1:
                if self._limit[1] < 5.:
                    step_inc = .1, self._page_incr
                else:
                    step_inc = 1., self._page_incr
            else:
                step_inc = .01, self._page_incr

        adjustment = self._adjustment = gtk.Adjustment(
            value=.0,
            lower=self._limit[0],
            upper=self._limit[1],
            step_incr=step_inc[0],
            page_incr=self._page_incr,
            page_size=0.
        )

        # a horizontal scale
        g = gtk.HScale(adjustment=adjustment)

        g.set_digits(self._precision)
        g.set_update_policy(gtk.UPDATE_DISCONTINUOUS)

        # Hide the numeric output text.
        #
        # Reference
        # roojs.com/seed/gir-1.2-gtk-3.0/gjs/Gtk.Scale.html
        g.set_draw_value(False)

        d[df.ALIGN] = 0, 0, 1, 0

        g.set_size_request(100, 1)
        Widget.__init__(self, g, **d)

        left_button = self.left_button = gtk.Button()
        right_button = self.right_button = gtk.Button()
        left_arrow = gtk.Arrow(gtk.ARROW_LEFT, gtk.SHADOW_NONE)
        right_arrow = gtk.Arrow(gtk.ARROW_RIGHT, gtk.SHADOW_NONE)
        spin_button = self.spin_button = gtk.SpinButton(
            adjustment=adjustment,
            digits=self._precision,
            climb_rate=climb_rate
        )

        spin_button.set_update_policy(gtk.UPDATE_DISCONTINUOUS)
        spin_button.set_increments(*step_inc)
        left_button.add(left_arrow)
        right_button.add(right_arrow)
        hbox.pack_start(left_button, expand=False)
        hbox.pack_start(g, expand=True)
        hbox.pack_start(right_button, expand=False)
        hbox.pack_start(spin_button, expand=False)
        self.add(hbox)
        g.set_value_pos(gtk.POS_LEFT)

        # Do connections last.
        left_button.connect('clicked', self.on_left_arrow_button)
        right_button.connect('clicked', self.on_right_arrow_button)

        for i in (left_button, right_button):
            i.connect('key_press_event', self.on_key_press)
        spin_button.connect('key_press_event', self.on_key_press)

    def _on_key_press(self, g, event):
        """
        Process an arrow Button keypress.

        g: gtk.Button
            active

        event: gtk.Event
            keypress

        Return: None or True
            Is True if the keypress is processed.
        """
        n = gtk.gdk.keyval_name(event.keyval)
        if n in RESPOND_KEY:
            if g == self.left_button:
                self.on_left_arrow_button()

            else:
                self.on_right_arrow_button()

            # Tell GTK the signal is processed.
            return True

    def get_ui(self):
        """
        Get the value of the Widget. If part of a greater
        Widget, then return the greater Widget's value.

        Return: numeric
            value of Slider
        """
        if self._greater_g:
            return self._greater_g.get_ui()
        return round(self._adjustment.get_value(), self._precision)

    def get_lesser_a(self):
        """
        Get the value of the Widget.

        Return: numeric
            value of Slider
        """
        return round(self._adjustment.get_value(), self._precision)

    def set_ui(self, a):
        """
        Set the Widget's value.

        a: value
            Expect int or float.

        Return: numeric
        """
        if not isinstance(a, (int, float)):
            a = 0.

        self._adjustment.set_value(round(a, self._precision))
        return a

    def on_left_arrow_button(self, *_):
        """Respond to a left arrow Button click."""
        a = self._adjustment.get_value()
        if a > self._limit[0]:
            a -= self._page_incr
            self._adjustment.set_value(a)

    def on_right_arrow_button(self, *_):
        """Respond to the right arrow Button click."""
        a = self._adjustment.get_value()
        if a < self._limit[1]:
            a += self._page_incr
            self._adjustment.set_value(a)

    def on_value_changed(self, *_):
        """
        The adjustment value changed. Enable
        or disable the arrow Buttons accordingly.
        """
        a = self._adjustment.get_value()
        b = 1 if a > self._limit[0] else 0
        c = 1 if a < self._limit[1] else 0

        self.left_button.set_sensitive(b)
        self.right_button.set_sensitive(c)


class FontSizeSlider(Slider, gobject.GObject, object):
    """Send a font size change signal."""
    __gsignals__ = si.FONT_SIZE_D

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        d[df.RELAY].insert(0, self.on_font_size_change)
        Slider.__init__(self, **d)
        gobject.GObject.__init__(self)

    def on_font_size_change(self, *_):
        """
        Let the Font Size Widget listener know
        that the Font Size Widget has changed.
        """
        a = self.get_ui()
        b = self.any_group.get_view_a(0, self.key)
        self.emit(si.FONT_SIZE_CHANGE, (a, a != b))


class RandomSlider(Slider):
    """Randomize itself."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        Slider.__init__(self, **d)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

    def randomize(self, *_):
        """Randomize the Slider value."""
        if self._precision:
            self.load_a(round(uniform(*self.random_q), self._precision))
        else:
            # A precision of zero is an integer display.
            self.load_a(float(randint(*self.random_q)))


class RenderSlider(Slider):
    """Respond to render size change."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        d[df.RELAY].insert(0, self.on_render_slider_change)
        Slider.__init__(self, **d)

    def on_render_slider_change(self, *_):
        """A render scale Widget changed."""
        w, h = Wip.get_size()

        if self.key == de.RENDER_W:
            w = self.get_lesser_a()

        else:
            h = self.get_lesser_a()

        Wip.w, Wip.h = w, h

        Ring.gob.emit(si.VIEW_SIZE_CHANGE, self)
        return True


class WIPSlider(Slider):
    """
    Manage the view's 'wip' rectangle by responding to change
    in the render size. The Widget multiplies its value by the
    view size to determine the 'wip' size and position.
    """

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        d[df.RELAY].insert(0, self.on_wip_change)
        Slider.__init__(self, **d)
        Ring.gob.connect(si.VIEW_SIZE_CHANGE, self.on_wip_change)

    def on_wip_change(self, *_):
        """Respond to change in the render size or the WIP scale."""
        f = self.get_lesser_a()
        w, h = Wip.get_size()
        w1, h1 = Globe.view_size = map(round, (w * f, h * f))
        Wip.x = (w1 - w) // 2.
        Wip.y = (h1 - h) // 2.
        return True


class RowCountSlider(Slider):
    """Send a row count changed signal."""

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        d[df.RELAY].insert(0, self.on_row_count_change)
        Slider.__init__(self, **d)

    def on_row_count_change(self, *_):
        """
        Respond to change in the row count slider.
        Notify row count change listener.
        """
        Ring.plug(si.ROW_CHANGE, self)


# Register the custom signals.
gobject.type_register(FontSizeSlider)
