#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_any_group import DecoGroup
from roller_constant import Plan as ak, Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_deco import finish_backed
from roller_deco_line import (
    do_canvas, do_cell_per, do_cell_main, do_facial_per, do_facial_main
)
from roller_gimp_image import check_matter, make_canvas_group, make_cast_group
from roller_maya import Canvas, CellRoute, FaceRoute, Main, Per, Runner
from roller_maya_add import Add
from roller_maya_bulb import Bulb
from roller_maya_frame import Frame
from roller_maya_layer import check_mix_basic
from roller_step import get_planner


class Line(DecoGroup):
    """Create Line Preset Widget and assign view-type runners."""
    frame_row_k = rk.BRW

    def __init__(self, **d):
        DecoGroup.__init__(self, **d)

        self.plan = {
            de.CANVAS: PlanCanvas,
            de.CELL: PlanCell,
            de.FACE: PlanFace,
            de.FACING: PlanFace
        }[self.branch_k](self)
        self.work = {
            de.CANVAS: WorkCanvas,
            de.CELL: WorkCell,
            de.FACE: WorkFace,
            de.FACING: WorkFace
        }[self.branch_k](self)


class Chi(Runner):
    """Factor Plan and Work."""

    def __init__(self, any_group, view_i, put):
        Runner.__init__(
            self,
            any_group,
            view_i,
            put,
            [
                (),
                (rk.BRW, de.MOD),
                (rk.BRW, de.MOD, de.BLUR_D)
            ]
        )


# view-type____________________________________________________________________
class Plan(Chi):
    """Manage Draft and Plan view-type layer output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        """
        any_group: AnyGroup
        """
        Chi.__init__(self, any_group, 0, self.put)

        planner = get_planner(any_group.name_step_k)
        self.is_planned = planner.get_widget_a(de.LINE)
        self.latch(
            planner, (ak.SIGNAL_DICT[de.LINE], self.on_plan_option_change)
        )

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d = self.get_value_d()
        self.go = d[de.SWITCH] and self.is_planned
        self.is_matter |= self.is_switched
        self.realize()

    def on_plan_option_change(self, _, arg):
        """
        Respond to change from Planner's Line option.

        arg: tuple
            (bool, bool)
            (
                Is True if the Line option is checked in Planner.,
                Is True if the Line option in Planner changed.
            )
        """
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage layer output for Peek, Preview, and the final view."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Line
        """
        Chi.__init__(self, any_group, 1, self.put)

        self.sub_maya[sm.ADD] = Add(any_group, self, (rk.BRW, de.ADD))
        self.sub_maya[sm.FRAME] = Frame(any_group, self, (rk.BRW, de.FRAME))
        self.sub_maya[sm.BULB] = Bulb(any_group, self, de.LINE)

    def bore(self):
        """Produce layer output during a view run."""
        d = self.value_d = self.get_value_d()
        self.go = d[de.SWITCH]
        is_back = Run.is_back

        self.realize()
        if self.go:
            if self.matter:
                self.sub_maya[sm.ADD].do(
                    d[rk.BRW][de.ADD],
                    self.is_matter,
                    self.is_matter,
                    is_back,
                    self.group
                )
                finish_backed()
                self.sub_maya[sm.FRAME].do(d[rk.BRW][de.FRAME], self.is_matter)
                self.sub_maya[sm.BULB].do(self.is_matter)
            else:
                finish_backed()
                self.die()
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


class WorkMain(Main, Work):
    """Factor Main and Work."""

    def __init__(self, *arg):
        """
        arg: tuple
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *arg)


# Canvas_______________________________________________________________________
class Cloth:
    """Factor Plan and Work Canvas."""

    def __init__(self):
        self.do_matter = do_canvas


class PlanCanvas(Cloth, Main, Plan, Canvas):
    """Manage Plan Canvas/Line output."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Cloth.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group)
        Canvas.__init__(self)


class WorkCanvas(Cloth, WorkMain, Canvas):
    """Manage Work Canvas/Line output."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's option group
        """
        Cloth.__init__(self)
        WorkMain.__init__(self, any_group)
        Canvas.__init__(self)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Cell_________________________________________________________________________
class Cellular:
    """Is factored from Plan and Work Cell."""
    is_face = is_facial = False

    def __init__(self):
        self.do_matter = do_cell_main


class PlanCell(Main, Plan, CellRoute, Cellular):
    """Manage Plan Cell/Line output for main."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Main.__init__(self)
        Plan.__init__(self, any_group)
        CellRoute.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, CellRoute, Cellular):
    """Manage Work Cell/Line output for main."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        WorkMain.__init__(self, any_group)
        CellRoute.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Plan Cell/Line Per output."""
    is_face = is_facial = False
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group)
        Per.__init__(self, do_cell_per, k)


class WorkCellPer(Work, Per):
    """Manage Work Cell/Line/Per output."""
    is_face = is_facial = False
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group)
        Per.__init__(self, do_cell_per, k)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Face_________________________________________________________________________
class Face:
    """Factor Plan and Work Face."""
    is_face = is_facial = True

    def __init__(self):
        self.do_matter = do_facial_main


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage Plan Face/Line output for main."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group)
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, FaceRoute):
    """Manage Work Face/Line output for main."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Face.__init__(self)
        WorkMain.__init__(self, any_group)
        FaceRoute.__init__(self, WorkFacePer)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Face Per_____________________________________________________________________
class FacePer(Per):
    """Factor Plan and Work Face/Line/Per."""
    is_face = is_facial = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacePer(Plan, FacePer):
    """Manage Plan Face/Line output for Per."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c, face);
            of int; Goo key
        """
        Plan.__init__(self, any_group)
        FacePer.__init__(self, do_facial_per, k)


class WorkFacePer(Work, FacePer):
    """Manage Work Face/Line output for Per."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int; Goo key
        """
        Work.__init__(self, any_group)
        FacePer.__init__(self, do_facial_per, k)
