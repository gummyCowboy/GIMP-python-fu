#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_container import PresetIO
from roller_oz import make_preset_path, make_preset_file_name, json_dump
from roller_constant import Define as df
from roller_constant_identity import Identity as de
from roller_comm import pop_up
from roller_port import Port
from roller_widget_box import Eventful
from roller_widget_button import AcceptButton, CancelButton
from roller_widget_entry import Entry
from roller_widget_label import Label
from roller_widget_row import WidgetRow
from roller_widget_splitter import Splitter
import gtk  # type: ignore
import os
import platform

DUPLICATE_FILE = \
    "The file,\n\n{},\n\nalready exists. " \
    "Do you want to overwrite the existing file?"

# Reference
# en.wikipedia.org/wiki/Filename#Reserved_characters_and_words
INVALID_CHAR = "/?%*:|<>" + '"' + "'" + "\\"


def save_file(gtk_win, d, key, n, is_overwrite=False):
    """
    Save a Preset to a file after checking if it already
    exists and possibly asking for permission to overwrite.

    gtk_win: GTK Window
        Is responsible.

    d: dict
        Preset or SuperPreset

    key: string
        Preset key

    n: string
        second part of the file path
        file name

    is_overwrite: bool
        If it's False, a pop-up will confirm a file over-write.

    Return: bool
        Is True if the file was written without error.
    """
    # When in Windows OS, remove invalid file name characters.
    if platform.system() == "Windows":
        for i in INVALID_CHAR:
            n = n.replace(i, "")

    if not n:
        n = "Preset"

    path = make_preset_path(key, n)
    go = True

    if not is_overwrite:
        if path:
            if os.path.isfile(path):
                n = DUPLICATE_FILE.format(path)
                go = pop_up(gtk_win, 0, n, "Duplicate File")

    if go:
        go = json_dump(d, path)
    return go


class PortSave(Port):
    """Interactively save a Preset."""
    window_key = "Save Preset"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: Button
            Is responsible.
        """
        self._file_name_label = \
            self._file_name_entry = \
            self._save_button = None
        self.preset_key = g.any_group.dna.key
        Port.__init__(self, d, g)

    def _draw_file_info_group(self, g):
        """
        Display the Preset file's location.

        g: GTK container
            Contain and display Widget.
        """
        self.reduce_color()

        n = os.path.dirname(make_preset_path(self.preset_key, ""))
        drive, path = os.path.splitdrive(n)
        g1 = Splitter(padding=(2, 2, 4, 4), has_inner_padding=True)
        g2 = Eventful(self.color)
        g3 = gtk.VBox()

        self.reduce_color()

        g4 = Eventful(self.color)
        g5 = gtk.VBox()
        g6 = self._file_name_label = Label(text="")

        g2.add(g3)
        g4.add(g5)
        g1.both(g2, g4)
        g3.add(Label(text="Drive:"))
        g3.add(Label(text="Folder:"))
        g3.add(Label(text="File Name:"))
        g5.add(Label(text=drive))
        g5.add(Label(text=path))
        g5.add(g6)
        g1.no_pack()
        g.add(g1.container)
        self._draw_file_name(self._file_name_entry)

    def _draw_file_name(self, g):
        """
        Call whenever the Preset name entry changes. Update
        the file location group with the latest file name.

        g: GTK Entry
            file name Entry
        """
        if self._file_name_label:
            n = make_preset_file_name(g.get_ui())

            self._file_name_label.set_label_value(n)
            if self._save_button:
                if g.get_ui().lower() == de.DEFAULT.lower():
                    self._save_button.set_sensitive(0)
                else:
                    self._save_button.set_sensitive(1)

    def _draw_process_group(self, vbox):
        """
        Draw the Cancel and Save Buttons for the Port.

        vbox: VBox
            Contain and display Widget.
        """
        button_row = WidgetRow(
            **{
                df.PADDING: (0, 0, 4, 4),
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win,
                df.SUB: OrderedDict([
                    (de.CANCEL, {df.WIDGET: CancelButton}),
                    (de.ACCEPT, {df.WIDGET: AcceptButton})
                ])
            }
        )

        # AcceptButton index, '1'
        self._save_button = button_row.widget_q[1]

        vbox.add(button_row)
        self.keep(button_row)

    def _draw_variable_group(self, vbox):
        """
        Create an Entry for naming the Preset.

        vbox: VBox
            Contain and display Widget.
        """
        g = self._file_name_entry = Entry(
            padding=(0, 2, 4, 4),
            relay=[self._draw_file_name],
            roller_win=self.roller_win
        )

        vbox.add(Label(padding=(2, 0, 4, 4), text="Preset Name:"))
        vbox.add(g)
        g.set_ui(PresetIO.preset_name)
        g.widget.select_region(0, -1)

    def accept_save_window(self, *_):
        """Save the Preset to a file."""
        preset = self.repo.any_group.get_widget(de.PRESET)
        d = preset.get_a()
        n = self._file_name_entry.get_ui()
        if save_file(self.roller_win.gtk_win, d, self.preset_key, n):
            PresetIO.preset_name = n

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return lambda: None, self.accept_save_window

    def draw(self):
        """Draw Port Widget."""
        # function to draw an option group, 'process_q'
        process_q = (
            self._draw_variable_group,
            self._draw_file_info_group,
            self._draw_process_group
        )

        label_q = (
            "Type: {}\n".format(self.preset_key), "\nFile Location:", ""
        )

        for i, p in enumerate(process_q):
            box = Eventful(self.color)
            vbox = gtk.VBox()

            box.add(vbox)
            self.add(box)

            if label_q[i]:
                vbox.add(Label(text=label_q[i], padding=(2, 0, 4, 0)))

            p(vbox)
            self.reduce_color()
