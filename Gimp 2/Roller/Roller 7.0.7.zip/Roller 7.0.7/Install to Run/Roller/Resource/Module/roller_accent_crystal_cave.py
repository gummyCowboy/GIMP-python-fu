#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_BURN,
    LAYER_MODE_COLOR_ERASE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_DODGE,
    LAYER_MODE_EXCLUSION,
    LAYER_MODE_HARDLIGHT,
    LAYER_MODE_HSV_VALUE,
    LAYER_MODE_LINEAR_LIGHT,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gimp_image import (
    add_wip_layer, add_sub_maya_group, insert_copy_above, make_group_layer
)
from roller_gimp_layer import clone_layer, flip_layer, saturate
from roller_maya_sub_accent import SubAccent


def do_matter(maya):
    """
    Create a Crystal Cave matter layer.

    maya: CrystalCave
    Return: layer or None
        Crystal Cave material
    """
    def _flip():
        """Flip a layer both horizontally and vertically."""
        flip_layer(z2)
        flip_layer(z2, is_h=True)

    def _make_group():
        """
        Make a group layer.

        Return: group layer
            new
        """
        return make_group_layer(j, parent, 0, "Condenser", z=z)

    j = Run.j
    d = maya.value_d
    parent = add_sub_maya_group(maya)
    seed_ = int(d[de.RANDOM_SEED] + Globe.seed)
    z = add_wip_layer("Plasma", maya.group)
    group = _make_group()

    # medium turbulence, '3.5'
    pdb.plug_in_plasma(j, z, seed_, 3.5)

    z1 = clone_layer(z, n="Erase")

    pdb.plug_in_emboss(
        j, z,
        Globe.azimuth,
        Globe.elevation,
        2,                  # depth
        1                   # emboss type
    )

    z2 = clone_layer(z, n="Linear Light")

    clone_layer(z2, n="Linear Light #2")
    pdb.plug_in_emboss(
        j, z1,
        Globe.azimuth,
        Globe.elevation,
        100,                # maximum depth
        1                   # emboss type
    )

    z1.mode = LAYER_MODE_COLOR_ERASE

    pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
    pdb.gimp_image_reorder_item(j, z2, z2.parent, 0)

    z2.mode = LAYER_MODE_LINEAR_LIGHT
    z = pdb.gimp_image_merge_layer_group(j, group)
    z.name = "Group #1"
    group = _make_group()
    z1 = clone_layer(z, n="Exclusion")
    z1.mode = LAYER_MODE_EXCLUSION

    pdb.plug_in_despeckle(
        j, z,
        16,                     # radius
        3,                      # recursive adaptive
        64,                     # white cut-off
        191                     # black cut-off
    )
    pdb.plug_in_unsharp_mask(
        j, z,
        12.,                    # radius
        54.,                    # amount
        .0                      # threshold
    )

    for _ in range(3):
        pdb.plug_in_wind(
            j, z,
            10,                 # threshold
            0,                  # from left
            30,                 # strength
            0,                  # wind
            1                   # leading edge
        )

    z = pdb.gimp_image_merge_layer_group(j, group)
    z.name = "Group #2"
    group = _make_group()
    z1 = clone_layer(z, n="Plasma")
    z2 = clone_layer(z1, n="Dodge")

    # lowest turbulence, '1.'
    pdb.plug_in_plasma(j, z1, seed_, 1.)

    z1.mode = LAYER_MODE_HSV_VALUE
    z1.opacity = 10.

    pdb.plug_in_erode(
        j, z,
        1,                      # propagate black
        7,                      # RGB channels
        1.,                     # full rate
        0,                      # direction mask
        0,                      # lower limit
        255                     # upper limit
    )
    _flip()

    z2.mode = LAYER_MODE_DODGE
    z3 = insert_copy_above(z2, group.layers[0])
    z3.mode = LAYER_MODE_DIFFERENCE
    z2.mode = LAYER_MODE_HSV_VALUE
    z2.opacity = 50.

    _flip()

    z1.mode = LAYER_MODE_BURN
    z1.opacity = 100.

    saturate(z1, -95.)

    z4 = insert_copy_above(z3, group.layers[0])
    z4.mode = LAYER_MODE_HSV_VALUE

    pdb.gimp_image_remove_layer(j, z1)

    z5 = clone_layer(z4, n="Exclusion")
    z5.mode = LAYER_MODE_EXCLUSION
    z5.opacity = 50.
    z = pdb.gimp_image_merge_layer_group(j, group)
    z.name = "Group #3"
    _make_group()
    z1 = clone_layer(z, n="Hard Light")

    # no linear, '0'
    pdb.gimp_drawable_invert(z1, 0)

    # blur horizontal, '3.'; blur vertical, '36.'
    pdb.plug_in_gauss_rle2(j, z1, 3., 36.)

    z1.mode = LAYER_MODE_HARDLIGHT
    z1.opacity = 75.
    z = clone_layer(z1)
    z.mode = LAYER_MODE_HARDLIGHT
    z.opacity = 65.
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class CrystalCave(SubAccent):
    """Create Accent output."""
    kind = de.CRYSTAL_CAVE

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)
