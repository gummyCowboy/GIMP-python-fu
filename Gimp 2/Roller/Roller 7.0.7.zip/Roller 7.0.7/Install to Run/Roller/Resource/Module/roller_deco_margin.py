#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (  # type: ignore
    CHANNEL_OP_ADD, CHANNEL_OP_REPLACE, pdb
)
from roller_container import Run
from roller_constant import Plan as ak
from roller_gimp_image import add_layer
from roller_gimp_layer import color_selection_default
from roller_gimp_selection import select_rect
from roller_preset import calc_margin


def do_cell_main(maya):
    """
    Draw Cell/Margin for main.

    Return: layer or None
        Margin material
    """
    j = Run.j

    pdb.gimp_selection_none(j)

    for k in maya.super_maya.main_q:
        maya.k = k
        select_cell_material(maya, option=CHANNEL_OP_ADD)

    if not pdb.gimp_selection_is_empty(j):
        z = add_layer(j, maya.super_maya.group, 0, "Margin")
        z.opacity = 66.

        color_selection_default(z, ak.CELL_MARGIN_COLOR)
        return z


def do_canvas(maya):
    """
    Draw Canvas/Margin for Plan.

    maya: CanvasMargin
    Return: layer or None
        Margin material
    """
    model = maya.model
    j = Run.j
    left_x, top_y, w, h = model.canvas_rect
    right_x = left_x + w
    bottom_y = top_y + h

    pdb.gimp_selection_none(j)

    q = top, bottom, left, right = model.canvas_margin

    for i, a in enumerate(q):
        if a:
            if i in (0, 1):
                # top, bottom
                x1 = left + left_x
                w1 = w - left - right

                if i == 0:
                    y = top_y
                    h1 = top
                else:
                    h1 = bottom
                    y = bottom_y - h1

            else:
                # left, right
                h1 = h - top - bottom
                y = top + top_y

                if i == 2:
                    x1 = left_x
                    w1 = left
                else:
                    w1 = right
                    x1 = right_x - w1
            select_rect(j, x1, y, w1, h1, option=CHANNEL_OP_ADD)
    if not pdb.gimp_selection_is_empty(j):
        z = add_layer(j, maya.super_maya.group, 0, "Margin")
        z.opacity = 66.

        color_selection_default(z, ak.CANVAS_MARGIN_COLOR)
        return z


def do_cell_per(maya):
    """
    Draw Cell/Margin/Per.

    maya: Maya
    Return: layer
        Margin material
    """
    def select_margins():
        """
        Select a margin for a cell.

        Return: Selection
            state of image
        """
        if a:
            _width = max(1., w - left - right)
            _height = max(1., h - top - bottom)
            _x = x + (left, left, .0, _width + left)[i]
            _y = y + (.0, _height + top, top, top)[i]
            _w = (_width, _width, a, a)[i]
            _h = (a, a, _height, _height)[i]
            select_rect(j, _x, _y, _w, _h, option=CHANNEL_OP_ADD)

    j = Run.j
    super_ = maya.super_maya
    goo = maya.model.goo_d[super_.k]
    x, y, w, h = goo.shift.rect
    x1, y1, w1, h1 = goo.pocket.rect
    left = x1 - x
    right = (x + w) - (x1 + w1)
    top = y1 - y
    bottom = (y + h) - (y1 + h1)

    pdb.gimp_selection_none(j)

    for i in range(4):
        a = (top, bottom, left, right)[i]
        select_margins()
    if not pdb.gimp_selection_is_empty(j):
        z = add_layer(j, super_.group, 0, "Margin")
        z.opacity = 66.

        color_selection_default(z, ak.CELL_MARGIN_COLOR)
        return z


def select_cell_material(maya, option=CHANNEL_OP_REPLACE):
    """
    Select Cell/Margin for Maya.

    maya: Maya
    option: gimpfu enum
        Specify selection option, add, replace, subtract, or intersect.

    Return: state of selection
    """
    j = Run.j
    x, y, w, h = maya.model.get_shift_rect(maya.k)
    q = top, bottom, left, right = calc_margin(maya.get_value_d())
    for i in range(4):
        a = q[i]
        if a:
            width = max(1., w - left - right)
            height = max(1., h - top - bottom)
            x1 = x + (left, left, .0, width + left)[i]
            y1 = y + (.0, height + top, top, top)[i]
            w1 = (width, width, a, a)[i]
            h1 = (a, a, height, height)[i]
            select_rect(j, x1, y1, w1, h1, option=option)
