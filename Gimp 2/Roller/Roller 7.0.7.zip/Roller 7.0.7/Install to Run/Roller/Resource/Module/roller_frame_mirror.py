#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD,
    CHANNEL_OP_SUBTRACT,
    CHANNEL_OP_REPLACE,
    CLIP_TO_IMAGE,
    pdb
)
from random import choice, randint
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_frame import (
    make_canvas_frame_sc, emboss_selection, select_wrap
)
from roller_frame_alt import FrameBasic
from roller_gimp_image import add_layer
from roller_gimp_layer import (
    clone_layer, color_selection_default, select_layer, verify_layer
)
from roller_gimp_selection import select_channel, select_rect
from roller_preset import combine_seed
from roller_utility import make_2d_table, make_rect_table

# connection type enum
# A graph boundary is a virtual connection.
NONE, REAL, VIRTUAL = 0, 1, 2

# screen-oriented start-point direction index
RIGHT_I, DOWN_I, LEFT_I, UP_I,  = range(4)

# Determine the direction index of an end-point.
# Up and down switch. Left and right switch.
OPPOSITE_DIR_I = 2, 3, 0, 1

ACTUAL_SET = {REAL, VIRTUAL}


def do_matter(maya):
    """
    Make the frame.

    maya: Mirror
    Return: layer
        with the Frame
    """
    j = Run.j
    d = maya.value_d
    e = maya.super_maya.value_d[rk.BRW][de.FILLER_MI]
    cast_z = maya.cast.matter

    select_wrap(j, cast_z, d[de.WIDTH], d[de.TYPE])

    wrap_sc = pdb.gimp_selection_save(j)

    # Canvas frame
    pdb.gimp_selection_none(j)
    make_canvas_frame_sc(maya, cast_z, e)

    canvas_frame_sc = pdb.gimp_selection_save(j)

    combine_seed(e)

    z = add_layer(j, maya.group, maya.get_light(), "Material")
    graph = LineGraph(
        maya.model.canvas_rect, int(e[de.ROW]), int(e[de.COLUMN])
    )

    graph.add_real(e[de.SCATTER_COUNT])
    graph.connect_line()
    graph.draw_connection(j, float(e[de.LINE_W]))
    draw_corner(*maya.model.canvas_rect)

    if e[de.CLIP]:
        select_layer(cast_z, option=CHANNEL_OP_SUBTRACT)

    for i in (wrap_sc, canvas_frame_sc):
        select_channel(j, i, option=CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, i)
    return verify_layer(emboss_selection(z, d))


def draw_corner(x, y, w, h):
    """
    Flip the topleft-quarter selection into the other canvas corners.
    The GIMP's context needed here are global, and set when Roller starts.

    q: tuple
        canvas rectangle
        (x, y, w, h)

    Return: state of selection
    """
    j = Run.j
    z = add_layer(j, None, 0, "Corner")

    color_selection_default(z, (0, 0, 0))

    z = clone_layer(z)

    # midpoint to flip horizontally, 'x1'
    x1 = (x + x + w) / 2.
    z = pdb.gimp_item_transform_flip(z, x1, y, x1, y + h)
    z = pdb.gimp_image_merge_down(z.image, z, CLIP_TO_IMAGE)
    z = clone_layer(z)

    # midpoint to flip vertically, 'y1'
    y1 = (y + y + h) / 2.
    z = pdb.gimp_item_transform_flip(z, x, y1, x + w, y1)
    z = pdb.gimp_image_merge_down(z.image, z, CLIP_TO_IMAGE)

    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)
    pdb.gimp_image_remove_layer(j, z)


def get_end_point_index(r, c, dir_i):
    """
    Determine the cell index of a cell connection
    which depends on one of four directions
    indicated by direction index.

    dir_i: int
        0 to 3
        direction index

    Return: tuple
        (row, column)
        cell index of the connected cell
    """
    # point direction tuple, (left, down, right, up)
    return r + (0, 1, 0, -1)[dir_i], c + (1, 0, -1, 0)[dir_i]


def what_is_real_state(a):
    """
    Determine if a point is REAL and connected.

    a: list
        [direction index]
        [right, down, left, up]
    """
    is_real = False
    count = 0

    # direction index, 'b'
    for b in a:
        if b == REAL:
            is_real = True
            count += 1
        elif b == VIRTUAL:
            count += 1
    return is_real, count


class LineGraph:
    """Create randomized connectors for Mirror. """

    def __init__(self, rect, row, column):
        """
        rect: tuple
            (x, y, w, h) of float
            space for graph

        row: int
            row count

        column: int
            column count
        """
        a, b = divmod(row, 2)
        graph_row = a + b + 1
        a, b = divmod(column, 2)
        graph_column = a + b + 1

        # endian index with a connector, 'last'
        last_r = graph_row - 1
        last_c = self.last_c = graph_column - 1

        self._rc_q = [(r, c) for r in range(last_r) for c in range(last_c)]
        self._grid = make_rect_table(rect, row, column)
        q = self.graph = make_2d_table(graph_row, graph_column)

        # Initialize the line matrix to a disconnected state.
        for r in range(graph_row):
            for c in range(graph_column):
                self.graph[r][c] = [0] * 4

        # connection type for the graph's edges, 'a'
        a = VIRTUAL

        # The graph boundaries are connected by virtual connections.
        for c in range(graph_column):
            q[0][c][UP_I] = q[0][c][LEFT_I] = q[0][c][RIGHT_I] = \
                q[last_r][c][DOWN_I] = q[last_r][c][LEFT_I] = \
                q[last_r][c][RIGHT_I] = a

        for r in range(graph_row):
            q[r][0][LEFT_I] = q[r][0][UP_I] = q[r][0][DOWN_I] = \
                q[r][last_c][RIGHT_I] = q[r][last_c][UP_I] = \
                q[r][last_c][DOWN_I] = a

    def add_real(self, add_count):
        """
        Add REAL points to the line graph.

        add_count: float
            Is the requested number of points to add to the graph.
        """
        graph = self.graph
        q = [(r, c, dir_i) for dir_i in range(4) for r, c in self._rc_q]
        while len(q) and add_count:
            r, c, dir_i = choice(q)
            a = graph[r][c]
            if a[dir_i] == NONE:
                add_count -= 1.

                # start point
                a[dir_i] = REAL

                # end-point
                r1, c1 = get_end_point_index(r, c, dir_i)
                dir_i1 = OPPOSITE_DIR_I[dir_i]
                b = graph[r1][c1]

                if b[dir_i1] == NONE:
                    b[dir_i1] = REAL
                if (r1, c1, dir_i1) in q:
                    q.pop(q.index((r1, c1, dir_i1)))
            q.pop(q.index((r, c, dir_i)))

    def connect_line(self):
        """
        Scan through the 'self.graph' table for disconnected points.

        When all disconnected points are connected, the scan stops.
        Connections end at the graph boundaries or with self-contained loops.

        A line segment has end points. Each point has up to four directions
        that lines can connect. There are two connection vector types.
        Once a line segment has two connections that are
        real and/or virtual, then the point is connected.
        """
        graph = self.graph
        real_q = []

        # Create a list of (row, column) of disconnected REAL point.
        for r, c in self._rc_q:
            # Determine if the point at (r, c) is connected
            # and real. If the connect count is less than
            # two, then the point is disconnected.
            is_real, count = what_is_real_state(graph[r][c])
            if is_real and count < 2:
                real_q.append((r, c))

        while real_q:
            r, c = choice(real_q)

            # Find a disconnected direction.
            while 1:
                dir_i = randint(0, 3)
                if graph[r][c][dir_i] == NONE:
                    # Found it.
                    break

            # Add a line from this point.
            r1, c1 = get_end_point_index(r, c, dir_i)
            dir_i1 = OPPOSITE_DIR_I[dir_i]
            graph[r][c][dir_i] = graph[r1][c1][dir_i1] = REAL

            real_q.pop(real_q.index((r, c)))

            is_real, count = what_is_real_state(graph[r1][c1])
            if is_real and count < 2:
                real_q.append((r1, c1))

    def draw_connection(self, j, line_w):
        """
        Select REAL type connection in the graph.

        j: GIMP image
            Receive selection.

        line_w: int
            Define selection size.
            For vertical, it is the width of the selection rectangle.
            For horizontal, it is the height of the selection rectangle.

        Return: state of selection
        """
        q = self.graph
        q1 = self._grid

        pdb.gimp_selection_none(j)
        for r, c in self._rc_q:
            a = q[r][c]

            # direction index, 'dir_i'
            for dir_i in range(2):
                if a[dir_i] == REAL:
                    r1, c1 = get_end_point_index(r, c, dir_i)
                    dir_i1 = OPPOSITE_DIR_I[dir_i]
                    if q[r1][c1][dir_i1] in ACTUAL_SET:
                        x, y = q1[r][c].position
                        x1, y1 = q1[r1][c1].position
                        w, h = abs(x - x1), abs(y - y1)

                        if not w:
                            w = line_w

                        else:
                            if c1 != self.last_c:
                                w += line_w
                            h = line_w
                        select_rect(j, x, y, w, h, option=CHANNEL_OP_ADD)


class Mirror(FrameBasic):
    filler_k = de.FILLER_MI
    kind = material = de.MIRROR
    wrap_k = de.WRAP_CA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
