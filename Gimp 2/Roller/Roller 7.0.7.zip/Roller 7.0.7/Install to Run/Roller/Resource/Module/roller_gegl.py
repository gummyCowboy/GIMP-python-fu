#!/usr/bin/env python
# -*- coding: utf-8 -*-
from ctypes import CDLL, POINTER, Structure, c_char_p, c_void_p, util
from gimpfu import pdb  # type: ignore
from roller_comm import show_err
import sys

# Reference
# gegl.org/operations/index.html
# %d - integer
# %s - keep format
# %f - floating point
# %g - general number
CUBISM = 'cubism tile-size=%f tile-saturation=%f seed=%d'
EDGE = 'edge algorithm=sobel amount=2. border=2'
EDGE_LAPLACE = 'edge-laplace'
EMBOSS = 'emboss azimuth=%f elevation=%f depth=%d'
ENGRAVE = 'engrave row-height=%d'
G_BLUR = 'gaussian-blur std-dev-x=%f std-dev-y=%f'
HIGH_PASS = "high-pass std-dev=%f contrast=%f"
MEDIAN_BLUR = 'median-blur radius=%d percentile=%f alpha-percentile=%f'
NEON = 'edge-neon radius=%f amount=%f'
NOISE_CIE_LCH = \
    'noise-cie-lch holdness=%d lightness-distance=%f ' \
    'chroma-distance=%f hue-distance=%f seed=%d'
NOISE_RGB = 'noise-rgb red=%f, blue=%f, green=%f, alpha=%f, seed=%d'
NOISE_SLUR = 'noise-slur pct-random=%f, repeat=%d, seed=%d'
OILIFY = 'oilify mask-radius=%d exponent=%d'
PIXELIZE = 'pixelize size-x=%d size-y=%d'
SATURATION = 'saturation scale=%f'
SHIFT = 'shift direction=%s shift=%d seed=%d'
SPREAD = 'noise-spread amount-x=%d amount-y=%d seed=%d'
UNSHARP_MASK = 'unsharp-mask std-dev=%f scale=%f threshold=%f'
VIDEO_DEGRADE = 'video-degradation pattern=%s'
WATERPIXELS = 'waterpixels size=%d'
WAVES = 'waves x=%f y=%f amplitude=%f period=%f phi=%f aspect=%f'
WIND = 'wind threshold=0 edge=both strength=30, style=wind direction=%s'

# GEGL command that don't work.
#   cell-noise
#   simplex-noise
#   noise-hsv (hue-distance works, but saturation and value distance fail.)


def _do_gegl(z, n):
    """
    Perform a GEGL function.

    z: drawable
        processing

    n: string
        GEGL graph operation
    """
    class GeglBuffer(Structure):
        pass

    # drawable id, 'id_'
    z_id = z.ID

    a = Gegl.gimp_library
    b = Gegl.gegl_library

    if b:
        a.gimp_drawable_get_shadow_buffer.restype = POINTER(GeglBuffer)
        a.gimp_drawable_get_buffer.restype = POINTER(GeglBuffer)

        non_empty, x, y, w, h = pdb.gimp_drawable_mask_intersect(z)
        if non_empty:
            source = a.gimp_drawable_get_buffer(z_id)
            target = a.gimp_drawable_get_shadow_buffer(z_id)

            b.gegl_buffer_flush.restype = None
            b.gegl_render_op(
                source, target, 'gegl:gegl', b"string", c_char_p(n), c_void_p()
            )
            b.gegl_buffer_flush(target)
            a.gimp_drawable_merge_shadow(z_id, PushUndo=True)
            a.gimp_drawable_update(z_id, x, y, w, h)
    else:
        show_err(
            "Roller is unable to run a GEGL process: {}".format(n)
        )


def pixelize(z, w, h):
    """
    Simplify an image into an array of solid-colored rectangles.

    Reference
    gegl.org/operations/gegl-pixelize.html

    z: layer
        WIP

    w: int
        block width

    h: int
        block height
    """
    _do_gegl(z, PIXELIZE % (w, h))


def antialias(z):
    """
    Perform antialias using the Scale3X edge-extrapolation algorithm.

    Reference
    gegl.org/operations/gegl-antialias.html

    z: layer
        work-in-progress
    """
    _do_gegl(z, 'antialias')


def blur(z, f):
    """
    Performs an averaging of neighboring pixels
    with the normal distribution as weighting.

    Appears to double the blur compared to 'pdb.plug_in_gauss_rle2'.

    Reference
    gegl.org/operations/gegl-gaussian-blur.html

    z: layer
        work-in-progress

    f: float
        standard deviation for x and y
    """
    if f:
        f = min(f, 1500.)
        _do_gegl(z, G_BLUR % (f, f))


def cell_noise(z, _, __):
    """
    Generate a cellular texture.

    Reference
    gegl.org/operations/gegl-cell-noise.html

    z: layer
        work-in-progress

    _: float
        scale of the noise
        .0 to 20.
        not used

    __: int
        Randomize the output.
        not used
    """
    # works
    # _do_gegl(z, 'noise-hsv  hue-distance=%f  saturation-distance%f value-distance=%f' % (180., 1., 1.))
    # works
    # _do_gegl(z, 'noise-hsv  hue-distance=%f  saturation-distance%f value-distance=%f' % (.0, .0, .0))
    # doesn't work
    # _do_gegl(z, 'noise-hsv  hue-distance=%f  saturation-distance%f value-distance=%f' % (.0, 1., .0))
    # doesn't work
    # _do_gegl(z, 'noise-hsv  hue-distance=%f  saturation-distance%f value-distance=%f' % (.0, 0., 1.))
    _do_gegl(
        z,
        'noise-hsv  hue-distance=%f'
        '  saturation-distance%f value-distance=%f' % (50., .0, .0)
    )


def color_to_grey(z):
    """
    Color to grayscale conversion, uses envelopes formed with the STRESS
    approach to perform local color-difference preserving grayscale generation.

    Reference
    gegl.org/operations/gegl-c2g.html

    z: layer
        work-in-progress
    """
    _do_gegl(z, 'c2g')


def cubism(z, size=20., amount=2., seed=0):
    """
    Convert the image into randomly rotated square
    blobs, somehow resembling a cubist painting style.

    Reference
    gegl.org/operations/gegl-cubism.html

    z: layer
        work-in-progress

    size: float
        of tile
        in .0 to 256.

    amount: float
        saturation of tiles
        in .0 to 10.

    seed: int
        to change output
    """
    _do_gegl(z, CUBISM % (size, amount, seed))


def edge(z):
    """
    Several simple methods for detecting edges.

    Reference
    gegl.org/operations/gegl-edge.html

    z: layer
        work-in-progress
    """
    _do_gegl(z, EDGE)


def emboss(z, azimuth, elevation, depth):
    """
    Simulates an image created by embossing.

    Reference
    gegl.org/operations/gegl-emboss.html

    z: layer
        work-in-progress

    azimuth: float
        for emboss

    elevation: float
        higher is lighter

    depth: int
        for emboss
    """
    _do_gegl(z, EMBOSS % (azimuth, elevation, depth))


def engrave(z, height):
    """
    Simulate an antique engraving.

    Reference
    gegl.org/operations/gegl-engrave.html

    z: layer
        to be transformed

    height: int
        resolution in pixels
    """
    _do_gegl(z, ENGRAVE % (height,))


def high_pass(z, deviation, contrast):
    """
    Enhances fine details.

    Reference
    gegl.org/operations/gegl-high-pass.html

    z: layer
        to receive effect

    deviation: float
        standard deviation (spatial scale factor)

    contrast: float
        of high-pass
    """
    _do_gegl(z, HIGH_PASS % (deviation, contrast))


def image_gradient(z):
    """
    Compute gradient magnitude and/or direction by central differences.

    Reference
    gegl.org/operations/gegl-image-gradient.html

    z: layer
        work-in-progress
    """
    _do_gegl(z, 'image-gradient')


def laplace(z):
    """
    High-resolution edge detection

    Reference
    gegl.org/operations/gegl-edge-laplace.html

    z: layer
        work-in-progress
    """
    _do_gegl(z, EDGE_LAPLACE)


def median_blur(z, radius, percentile, alpha=50.):
    """
    Do the GEGL Median Blur function.
    Blur resulting from computing the median
    color in the neighborhood of each pixel.

    Reference
    gegl.org/operations/gegl-median-blur.html

    z: layer
        Receive blur.

    radius: int
        neighborhood radius of blur influence
        A negative value will calculate with inverted percentiles.
        -400 to 400

    percentile: float
        neighborhood color percentile
        .0 to 100.

    alpha: float
        neighborhood alpha percentile
        .0 to 100.
    """
    _do_gegl(z, MEDIAN_BLUR % (min(400, radius), percentile, alpha))


def neon(z, radius, amount):
    """
    Do the GEGL Edge Neon. Performs edge detection
    using a Gaussian derivative method.

    Reference
    gegl.org/operations/gegl-edge-neon.html

    z: layer
        WIP

    radius: float
        .0 to 1500.

    amount: float
        strength of effect
        .0 to 100.
    """
    _do_gegl(z, NEON % (radius, amount))


def noise_cie_lch(z, dull=1, light=19., chroma=100., hue=.0, seed=1):
    """
    Randomize lightness, chroma and hue independently.

    Reference
    gegl.org/operations/gegl-noise-cie-lch.html

    z: layer
        work-in-progress

    dull: float
        Lower the value to add more noise.
        in 1 to 8

    light: float
        Raise the value to increase lightness.
        in .0 to 100.

    chroma: float
        Raise the value to add more saturation.
        in .0 to 100.

    hue: float
        shift the hue-based noise
        in .0 to 180.
        180 is desaturated

    seed: int
        Change output.
    """
    _do_gegl(z, NOISE_CIE_LCH % (dull, light, chroma, hue, seed))


def noise_rgb(z, red, green, blue, alpha, seed):
    """
    Distort colors by random amounts.

    Reference
    gegl.org/operations/gegl-noise-rgb.html

    red, green, blue, alpha: float
        color component
        .0 to 1.

    seed: int
        Randomize noise graph.
    """
    _do_gegl(z, NOISE_RGB % (red, green, blue, alpha, seed))


def noise_slur(z, percent, repeat, seed):
    """
    Randomly slide some pixels downward (similar to melting).

    Reference
    gegl.org/operations/gegl-noise-slur.html

    percent: float
        from .0 to 100.
        randomization

    repeat: int
        from 1 to 100
        pattern

    seed: int
        for random generator
    """
    _do_gegl(z, NOISE_SLUR % (percent, repeat, seed))


def oilify(z, radius, exponent):
    """
    Emulate an oil painting.

    Reference
    gegl.org/operations/gegl-oilify.html

    radius: int
        Radius of circle around pixel, can also be
        scaled per pixel by a buffer on the aux pad.

    exponent: int
        Exponent for processing; controls smoothness -
        can be scaled per pixel with a buffer on the aux2 pad.
    """
    _do_gegl(z, OILIFY % (radius, exponent))


def shift(z, direction, amount, seed):
    """
    Shift each row or column of pixel by a random amount.

    Reference
    gegl.org/operations/gegl-shift.html

    z: layer
        work-in-progress

    direction: string
        horizontal or vertical

    amount: int
        length of shift
        in 0 to 200

    seed: int
        Change output.
    """
    _do_gegl(z, SHIFT % (direction, amount, seed))


def spread(z, seed, amount_x=5, amount_y=5):
    """
    Move pixel around randomly.

    Reference
    gegl.org/operations/gegl-noise-spread.html

    z: layer
        Receive spread.

    seed: int
        random seed

    amount_x, amount_y: int
        vertical and horizontal spread
        0 to 512
    """
    _do_gegl(z, SPREAD % (amount_x, amount_y, seed))


def unsharp_mask(z, radius, amount, threshold):
    """
    Sharpen image, by adding difference to blurred image, a
    technique for sharpening originally used in darkrooms.

    Reference
    gegl.org/operations/gegl-unsharp-mask.html

    z: layer
        work-in-progress

    radius: float
        span of effect
        .0 to 1500.

    amount: float
        strength
        .0 to 300.

    threshold: float
        .0 is all, 1. is none?
    """
    _do_gegl(z, UNSHARP_MASK % (radius, amount, threshold))


def video_degradation(z, pattern):
    """
    Do the GEGL video degradation function.
    Simulate the degradation of being on
    an old low-dotpitch RGB video monitor.

    Reference
    gegl.org/operations/gegl-video-degradation.html

    z: layer
        Receive effect.

    pattern: string
        'dots' is one option.
        as in the drop-down from the GIMP dialog
    """
    _do_gegl(z, VIDEO_DEGRADE % pattern)


def waterpixels(z, size=32):
    """
    Make superpixels based on the watershed transformation.

    Reference
    gegl.org/operations/gegl-waterpixels.html

    size: int
        of superpixel
        8 to 256
    """
    _do_gegl(z, WATERPIXELS % size)


def waves(z, x=.5, y=.5, amplitude=25., period=100., phi=.0, aspect=1.):
    """
    Distort the image with waves.

    Reference
    gegl.org/operations/gegl-waves.html

    z: layer
        Receive effect.

    x: float
        Center the effect on the x-axis.
        .0 to 1.

    y: float
        Center the effect on the y-axis.
        .0 to 1.

    amplitude: float
        Change the amplitude of the ripple.
        .0 to 1000.

    period: float
        Change the wavelength of the ripple.
        .1 to 1000.

    phi: float
        Shift the phase.
        -1. to 1.

    aspect: float
        Shorten the wavelength.
        .1 to 10.
    """
    _do_gegl(z, WAVES % (x, y, amplitude, period, phi, aspect))


def wind(z, direction):
    """
    Is a wind-like bleed effect.

    Future Reference
    The option 'style' is either wind or blast.
    The option 'edge' is either both, leading, or trailing.

    Reference
    gegl.org/operations/gegl-wind.html

    z: layer
        WIP

    direction: string
        top, bottom, left, right
    """
    _do_gegl(z, WIND % direction)


class Gegl:
    """
    Provide global GEGL functionality access. Has minimal
    dependencies so it won't create a circular import problem.
    """
    # DLL
    gimp_library = gegl_library = None

    @staticmethod
    def load_library(library_name):
        """
        Load a library for GEGL command function.
        The library name differs with the operating system.

        library_name: string
            OS dependent library name

        Return: library or None
            as referenced by 'library_name'
        """
        n = sys.platform

        if n == 'linux' or n == 'linux2':
            library_name = library_name + '.so.0'

        elif n == 'win32':
            # Search for the library name from
            # the PATH environment variable.
            library_name = util.find_library(library_name + '-0')

        else:
            library_name = ""
        if library_name:
            # Load the dynamic link library.
            return CDLL(library_name)


# Load the library once as this an expensive operation.
Gegl.gegl_library = Gegl.load_library('libgegl-0.4')
