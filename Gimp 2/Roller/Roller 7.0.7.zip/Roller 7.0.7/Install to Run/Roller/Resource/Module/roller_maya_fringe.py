#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_any_group import DecoImageGroup
from roller_constant import (
    Issue as vo,
    Plan as ak,
    Row as rk,
    Signal as si,
    SubMaya as sm
)
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_deco import finish_backed
from roller_deco_fringe import (
    do_canvas,
    do_cell_main,
    do_cell_per,
    do_face_main,
    do_face_per,
    do_facing_main,
    do_facing_per
)
from roller_gimp_image import check_matter, make_canvas_group, make_cast_group
from roller_mask_router import (
    mask_cell_main,
    mask_cell_per,
    mask_face_main,
    mask_face_per,
    mask_facing_main,
    mask_facing_per
)
from roller_maya import Canvas, Cell, FaceRoute, Main, Per, Change
from roller_maya_add import Add
from roller_maya_bulb import Bulb
from roller_maya_frame import Frame
from roller_maya_layer import check_mix_basic
from roller_maya_mask import Mask
from roller_maya_vote import take_background_vote
from roller_step import get_planner


class Fringe(DecoImageGroup):
    """
    Create a Widget group. Assign view-run-type runners
    and connect responsible signal handler.
    """
    frame_row_k = rk.BRW

    def __init__(self, **d):
        """
        d: dict
            Initialize the AnyGroup.
        """
        DecoImageGroup.__init__(self, **d)

        self.plan = {
            de.CANVAS: PlanCanvas,
            de.CELL: PlanCell,
            de.FACE: PlanFace,
            de.FACING: PlanFacing
        }[self.branch_k](self)
        self.work = {
            de.CANVAS: WorkCanvas,
            de.CELL: WorkCell,
            de.FACE: WorkFace,
            de.FACING: WorkFacing
        }[self.branch_k](self)

    @staticmethod
    def get_image_d(d):
        """
        Fetch the Image Choice Preset if its use.

        d: dict
            Fringe Preset

        Return: dict or None
            Image Choice Preset
        """
        if d[de.SWITCH]:
            if d[de.TYPE] == de.IMAGE:
                e = d[de.IMAGE_CHOICE]
                if e[de.SWITCH]:
                    return e


class Chi(Change):
    """Factor Plan and Work."""

    def __init__(self, any_group, view_i, q, make_mask, get_mask_d):
        """
        any_group: Fringe
        view_i: int
            0 or 1; plan or work; view-type index

        q: iterable
            Connect view-type function output with a
            created Maya attribute using a string.
            [(output function, Maya attribute), ...]

        make_mask: function
            Mask Fringe layer.

        get_mask_d: function
            Retrieve the Mask Preset.
        """
        Change.__init__(
            self,
            any_group,
            view_i,
            q,
            [
                (),
                (de.GRID,),
                (rk.BRW, de.MOD),
                (rk.BRW, de.MOD, de.BLUR_D),
                (rk.RW1, de.BRUSH_D),
                (de.IMAGE_CHOICE,)
            ]
        )

        self.sub_maya[sm.MASK] = Mask(
            any_group, self, view_i, make_mask, get_mask_d, (rk.RW1, de.MASK)
        )


# view-type____________________________________________________________________
class Plan(Chi):
    """Manage Draft and Plan view-type layer output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, make_mask, get_mask_d):
        Chi.__init__(self, any_group, 0, self.put, make_mask, get_mask_d)

        planner = get_planner(any_group.name_step_k)
        self.is_planned = planner.get_widget_a(de.FRINGE)
        self.latch(
            planner, (ak.SIGNAL_DICT[de.FRINGE], self.on_plan_option_change)
        )

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d = self.get_value_d()
        self.go = d[de.SWITCH] and self.is_planned

        if self.go:
            self.is_matter |= self.is_switched
        self.realize()

    def on_plan_option_change(self, _, arg):
        """
        Respond to change in Planner's Fringe option.

        _: Signal
        arg: tuple
            (bool, bool)
            (
                boolean state of the Fringe option,
                boolean state of the Fringe option since the last view run
            )
        """
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage layer output for Peek, Preview, and the final view."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, make_mask, get_mask_d):
        Chi.__init__(self, any_group, 1, self.put, make_mask, get_mask_d)

        self.sub_maya[sm.ADD] = Add(any_group, self, (rk.BRW, de.ADD))
        self.sub_maya[sm.FRAME] = Frame(any_group, self, (rk.BRW, de.FRAME))
        self.sub_maya[sm.BULB] = Bulb(any_group, self, de.FRINGE)
        self.latch(any_group, (si.BACK_CHANGE, self.on_back_change))

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d = self.get_value_d()
        self.go = d[de.SWITCH]
        is_back = Run.is_back

        if self.go:
            self.is_matter |= take_background_vote(d)

        self.realize()
        if self.go:
            if self.matter:
                is_mask = self.sub_maya[sm.MASK].do(
                    d[rk.RW1][de.MASK], self.is_matter
                )

                self.sub_maya[sm.ADD].do(
                    d[rk.BRW][de.ADD],
                    self.is_matter,
                    is_mask,
                    is_back,
                    self.group
                )
                finish_backed()

                m = self.is_matter or is_mask

                self.sub_maya[sm.FRAME].do(d[rk.BRW][de.FRAME], m)
                self.sub_maya[sm.BULB].do(m)
            else:
                finish_backed()
                self.die()
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


class WorkMain(Main, Work):
    """Factor work-view-type main option settings."""

    def __init__(self, *arg):
        """
        arg: tuple
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *arg + (self.get_mask_d,))


# Canvas_______________________________________________________________________
class Cloth:
    """Factor Plan and Work Canvas."""
    def __init__(self):
        self.do_matter = do_canvas


class PlanCanvas(Cloth, Main, Plan, Canvas):
    """Manage plan-view-type Canvas layer output."""
    issue_q = vo.PLAN_LIST
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Cloth.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, mask_cell_per, self.get_mask_d)
        Canvas.__init__(self)


class WorkCanvas(Cloth, WorkMain, Canvas):
    """Manage Work/Canvas layer output."""
    issue_q = vo.WORK_LIST
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        Cloth.__init__(self)
        WorkMain.__init__(self, any_group, mask_cell_per)
        Canvas.__init__(self)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Cell_________________________________________________________________________
class Cellular:
    """Manage Cell branch layer output."""
    is_face = is_facial = False

    def __init__(self):
        self.do_matter = do_cell_main


class PlanCell(Main, Plan, Cell, Cellular):
    """Manage plan-view-type Cell layer output."""
    issue_q = vo.PLAN_PER_LIST

    def __init__(self, any_group):
        Main.__init__(self)
        Plan.__init__(self, any_group, mask_cell_main, self.get_mask_d)
        Cell.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, Cell, Cellular):
    """Manage Work/Cell layer output."""
    issue_q = vo.WORK_PER_LIST

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Fringe
        """
        WorkMain.__init__(self, any_group, mask_cell_main)
        Cell.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Cell/Per layer output for Plan and Draft views."""
    is_face = is_facial = False
    issue_q = vo.PLAN_LIST

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group, mask_cell_per, self.get_mask_d)
        Per.__init__(self, do_cell_per, k)


class WorkCellPer(Work, Per):
    """Manage Cell/Per layer output for Peek, Preview, and render."""
    is_face = is_facial = False
    issue_q = vo.WORK_LIST

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group, mask_cell_per, self.get_mask_d)
        Per.__init__(self, do_cell_per, k)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Face_________________________________________________________________________
class Face:
    """Manage Face layer output."""
    is_face = is_facial = True

    def __init__(self):
        self.do_matter = do_face_main


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage plan-view-type Face layer output."""
    issue_q = vo.PLAN_PER_LIST

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, mask_face_main, self.get_mask_d)
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, FaceRoute):
    """Manage Work/Face layer output."""
    issue_q = vo.WORK_PER_LIST

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            with Face options
        """
        Face.__init__(self)
        WorkMain.__init__(self, any_group, mask_face_main)
        FaceRoute.__init__(self, WorkFacePer)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Face Per Cell________________________________________________________________
class FacePer(Per):
    """Manage Work/Face/Per layer output."""
    is_face = is_facial = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacePer(Plan, FacePer):
    """Manage plan-view-type Face/Per layer output."""
    issue_q = vo.PLAN_LIST

    def __init__(self, any_group, k):
        """
        k: tuple
            (row, column, face)
        """
        Plan.__init__(self, any_group, mask_face_per, self.get_mask_d)
        FacePer.__init__(self, do_face_per, k)


class WorkFacePer(Work, FacePer):
    """Manage Work/Face/Per layer output."""
    issue_q = vo.WORK_LIST

    def __init__(self, any_group, k):
        """
        k: tuple
            (row, column, face)
        """
        Work.__init__(self, any_group, mask_face_per, self.get_mask_d)
        FacePer.__init__(self, do_face_per, k)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Facing_______________________________________________________________________
class Facing:
    """Factor Plan and Work Facing."""
    is_face = False
    is_facial = True

    def __init__(self):
        self.do_matter = do_facing_main


class PlanFacing(Facing, Main, Plan, FaceRoute):
    """Manage Plan/Facing layer output."""
    issue_q = vo.PLAN_PER_LIST

    def __init__(self, any_group):
        Facing.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, mask_facing_main, self.get_mask_d)
        FaceRoute.__init__(self, PlanFacingPer)


class WorkFacing(Facing, WorkMain, FaceRoute):
    """Manage Work/Facing layer output."""
    issue_q = vo.WORK_PER_LIST

    def __init__(self, any_group):
        """
        any_group: Fringe
        """
        Facing.__init__(self)
        WorkMain.__init__(self, any_group, mask_facing_main)
        FaceRoute.__init__(self, WorkFacingPer)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Facing Per Cell______________________________________________________________
class FacingPer(Per):
    """Factor Plan and Work Facing/Per."""
    is_face = False
    is_facial = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacingPer(Plan, FacingPer):
    """Manage Plan/Facing/Per output."""
    issue_q = vo.PLAN_LIST

    def __init__(self, any_group, k):
        """
        any_group: Fringe
        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group, mask_facing_per, self.get_mask_d)
        FacingPer.__init__(self, do_facing_per, k)


class WorkFacingPer(Work, FacingPer):
    """Manage Work/Facing/Per output."""
    issue_q = vo.WORK_LIST

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group, mask_facing_per, self.get_mask_d)
        FacingPer.__init__(self, do_facing_per, k)
