#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Signal as si
from roller_constant_identity import Identity as de
from roller_model_cell_branch import CellBranch
from roller_model_goo import Goo
from roller_wip import get_factor_h, get_factor_w
from roller_polygon import ROUTE_POG, ROUTE_SHAPE


class Stack(CellBranch):
    """
    It's grid has multiple row and one column. An
    additional row cell position has an offset option.
    """
    model_type = de.STACK

    def __init__(self, model_name):
        """
        model_name: string
            Identify the model.
        """
        CellBranch.__init__(self, model_name)

    def calc_grid(self, d):
        """
        Calculate the Stack's grid size in row and column span.

        d: dict
            Cell/Type Preset
        """
        self.grid = int(d[de.CELL_COUNT]), 1
        self.baby.emit(si.GRID_CHANGE, self.grid)

    def init_cell_q(self, _):
        """
        Create a sorted list of valid cell index,
        'cell_q' -> [(row, column), ...].

        _: dict
            Cell/Type Preset
        """
        self.cell_q = [(r, 0) for r in range(self.grid[0])]

    def init_model_cell(self, d):
        """
        Calculate the cell rectangle, the merged
        rectangle, and their inscribed form polygon.

        d: dict
            Cell/Type Preset

        Return: list
            [Plan vote, Work vote]
            Each True vote is a vote for change.
        """
        self.goo_d = {}
        vote_d = {}
        add_x = add_y = 0
        inc_x = get_factor_w(d[de.ADD_OFFSET_X])
        inc_y = get_factor_h(d[de.ADD_OFFSET_Y])
        x, y, w, h = self.rectangle

        for r_c in self.cell_q:
            a = self.goo_d[r_c] = Goo(r_c)
            a.cell.rect = a.merged.rect = x + add_x, y + add_y, w, h

            if self.route_i == 0:
                a.form = ROUTE_SHAPE[self.cell_shape](a.cell)

            else:
                a.form = ROUTE_POG[self.cell_shape](
                    a.cell, d[de.PARALLELOGRAM_SCALE]
                )

            vote_d[r_c] = self.past.did_cell(r_c)
            add_x += inc_x
            add_y += inc_y
        return vote_d
