#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_REPLACE, CLIP_TO_IMAGE, pdb  # type: ignore
from roller_comm import info_msg
from roller_constant import Justification as ju, Row as rk
from roller_constant_identity import Identity as de
from roller_container import Cat, Deco, Run
from roller_deck import Deck
from roller_deco import ready_canvas_rect, ready_shape, transform_foam
from roller_gimp_image import add_layer, add_layer_below
from roller_gimp_layer import (
    clear_inverse_selection, make_text_layer, remove_layer, verify_layer
)
from roller_gimp_selection import get_select_coord, select_shape
from roller_preset import calc_margin
from roller_preset_mod import do_mod

LEAD_SET = {de.IMAGE_NAME, de.SEQUENCE}
MISSING_ITEM = "Roller {} can't find a {}, {}."


def add_caption_z(j, maya):
    """
    Create a layer for Caption material.

    j: Gimp Image
        WIP

    maya: Maya
        'maya_caption' variety

    Return: layer
        Receive text.
    """
    return add_layer(j, maya.group, maya.get_light(), "Material")


def create_cell(j, maya, z, d):
    """
    Draw text for Cell/Caption/Per.

    j: Gimp Image
        WIP

    maya: Maya
        'maya_caption' variety

    z: layer
        Receive text.

    d: dict
        Caption Preset

    is_main: bool
        If True, then the output layer can skip the finish check.

    Return: layer or None
        Caption material
    """
    ready_shape(maya, d, option=None)
    return draw_text(j, maya, z, d)


def create_cell_main(maya, d):
    """
    Draw text for Cell/Caption main.

    maya: Maya
        'maya_caption' variety

    d: dict
        Caption Preset

    Return: layer or None
        Caption material
    """
    j = Run.j
    deck = Deck(Run.j, maya.group, maya.get_light(), "Material")

    for k in maya.main_q:
        maya.k = k
        create_cell(j, maya, deck.add(), d)
    return deck.exit()


def create_face(j, maya, z, d):
    """
    Draw text for Face/Caption.

    j: Gimp Image
        WIP

    maya: Maya
        'maya_caption' variety

    z: layer
        Receive text.

    d: dict
        Caption Preset

    Return: layer or None
        Caption material
    """
    k = maya.k
    model = maya.model
    Deco.shape = model.get_facing_shape(k)

    # Transform is less likely to be clipped
    # from the topleft corner of the layer, '(.0, .0)'.
    maya.rect = (.0, .0) + model.get_facing_rect(k)[2:]

    # Face index position, '-1;
    z = draw_text(j, maya, z, d, seq_n="abc"[k[-1]], is_clip=False)

    if z:
        n = z.name

        # Set the layer size for the transform by
        # merging the text layer with a new layer.
        add_layer_below(z, "Resize")

        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
        z.name = n
        z = transform_foam(maya.rect, z, model.get_facing_foam(k))
    return z


def create_facial_main(maya, d, p):
    """
    Draw text for Face/Caption main.

    maya: Maya
        'maya_caption' variety

    d: dict
        Caption Preset

    p: function
        Make Facing text layer.

    Return: layer or None
        Caption material
    """
    j = Run.j
    deck = Deck(j, maya.group, maya.get_light(), "Material")

    for k in maya.main_q:
        maya.k = k
        p(j, maya, deck.add(), d)
    return deck.exit()


def create_facial_per(maya, d, p):
    """
    Make text for Face or Facing Caption/Per.

    maya: Maya
        'maya_caption' variety

    d: dict
        Caption Preset

    p: function
        Make Face/Facing text layer.

    Return: layer or None
        Caption material
    """
    j = Run.j
    return verify_layer(p(j, maya, add_caption_z(j, maya), d))


def create_facing(j, maya, z, d):
    """
    Draw text for Face/Caption.

    j: Gimp Image
        WIP

    maya: Maya
        'maya_caption' variety

    z: layer
        Receive text.

    d: dict
        Caption Preset

    Return: layer or None
        Caption material
    """
    k = maya.k
    model = maya.model
    Deco.shape = model.get_facing_form(k)

    # Transform is less likely to be clipped
    # from the topleft corner of the layer, '(.0, .0)'.
    maya.rect = (.0, .0) + model.get_facing_rect(k)[2:]

    z = draw_text(j, maya, z, d, is_clip=False)

    if z:
        n = z.name

        # Set the layer size for the transform by
        # merging the text layer with a new layer.
        add_layer_below(z, "Resize")

        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
        z.name = n
        z = transform_foam(maya.rect, z, model.get_facing_foam(k))
        model.clip_facing(z, k)
    return z


def do(maya, make):
    """
    Prepare and make Caption text output. Plan
    overrides and restores its required option.

    maya: Maya
        'maya_caption' variety

    make: function
        Make Caption text.

    Return: layer or None
        Caption material
    """
    d = maya.value_d

    if not Run.i:
        # Preserve.
        mode = d[de.MODE]
        color = d[rk.RW1][de.COLOR_1]

        # Override.
        d[de.MODE] = "Normal"
        d[rk.RW1][de.COLOR_1] = 255, 255, 255

    z = make(maya, d)

    if z:
        do_mod(z, d[rk.BRW][de.MOD])

    if not Run.i:
        # Restore.
        d[de.MODE] = mode
        d[rk.RW1][de.COLOR_1] = color
    return z


def do_canvas(maya):
    """
    Make Canvas/Caption text.

    maya: Maya
        'maya_caption' variety

    Return: layer or None
        Caption material
    """
    return do(maya, make_canvas)


def do_cell_main(maya):
    """
    Make Cell/Caption text for main.

    maya: Maya
        'maya_caption' variety

    Return: layer or None
        Caption material
    """
    return do(maya, create_cell_main)


def do_cell_per(maya):
    """
    Draw Cell/Caption/Per text.

    maya: Maya
        'maya_caption' variety

    Return: layer or None
        Caption material
    """
    return do(maya, make_cell_per)


def do_face_main(maya):
    """
    Draw Face/Caption text for main.

    maya: Maya
        'maya_caption' variety

    Return: layer or None
        Caption material
    """
    return do(maya, make_face_main)


def do_face_per(maya):
    """
    Draw text for Face/Caption/Per.

    maya: Maya
        'maya_caption' variety

    Return: layer or None
        Caption material
    """
    return do(maya, make_face_per)


def do_facing_main(maya):
    """
    Draw Facing/Caption text for main.

    maya: Maya
        'maya_caption' variety

    Return: layer or None
        Caption material
    """
    return do(maya, make_facing_main)


def do_facing_per(maya):
    """
    Draw Facing/Caption/Per text.

    maya: Maya
        'maya_caption' variety

    Return: layer or None
        Caption material
    """
    return do(maya, make_facing_per)


def draw_text(j, maya, z, d, seq_n="", is_clip=True):
    """
    Create text. Call once per Caption instance.

    j: Gimp Image
        WIP

    maya: Maya
        'maya_caption' variety

    z: layer
        Receive text.

    d: dict
        Caption Preset

    seq_n: string
        Append to the sequence value.
        Is used by sub-Face.
        Is only applied if the Caption/Type is Sequence.

    is_clip: bool
        If True, then the text output is clipped to Maya's 'shape' polygon.

    Return: layer or None
        Caption material
    """
    def _get_text():
        """
        Assemble the text as defined by the options.

        Return: string
            the Caption text
        """
        _text = ""
        type_ = d[de.TYPE]

        if type_ == de.TEXT:
            _text = d[de.TEXT]

        elif type_ == de.SEQUENCE:
            _text = str(
                maya.model.cell_q.index(maya.k[:2]) +
                int(d[de.START_NUMBER])
            ) + seq_n

        elif type_ == de.IMAGE_NAME:
            _text = maya.any_group.image_name_d.get(k, "")

        if type_ in LEAD_SET and _text:
            _n = d[rk.LTR][rk.LEAD]
            _n1 = d[rk.LTR][rk.TRAIL]
            _text = _n + _text + _n1
        return _text

    go = True
    k = maya.k
    font = d[rk.RW1][de.FONT]
    text = _get_text()
    color = d[rk.RW1][de.COLOR_1]

    if font not in Cat.font_list:
        info_msg(MISSING_ITEM.format("Caption", "font", font))
        go = False

    if go:
        if text:
            go, z = make_text_layer(
                j, z,
                1,                          # yes, antialias
                text,
                d[de.FONT_SIZE],
                font,
                color,
                .0, .0,                     # x, y
                .0, .0                      # w, h
            )
        else:
            go = False

    if go:
        # Select the layer for autocrop.
        pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)

        pdb.plug_in_autocrop_layer(j, z)

        rect_x, rect_y, rect_w, rect_h = maya.rect
        x, y, x1, y1 = get_select_coord(j)
        text_w = x1 - x
        text_h = y1 - y
        half_w = text_w / 2.
        half_h = text_h / 2.
        top, bottom, left, right = calc_margin(d[rk.RW1][de.MARGIN])

        # cell width, height
        w = max(1., rect_w - left - right)
        h = max(1., rect_h - top - bottom)
        n = d[de.JUSTIFY]

        # cell position x, y
        x = rect_x + left
        y = rect_y + top

        # Get 'y'.
        if n in ju.BOTTOM_SET:
            y += h - text_h

        elif n in ju.CENTER_Y_SET:
            y += (h / 2.) - half_h

        # Get 'x'.
        if n in ju.RIGHT_SET:
            x += w - text_w

        elif n in ju.CENTER_X_SET:
            x += (w / 2.) - half_w

        # Move the text layer.
        pdb.gimp_layer_set_offsets(z, int(x), int(y))

        # Save the Cell's text selection for Strip.
        maya.model.set_caption_y(k, (y, z.height))

        # Clip material outside of the shape.
        if is_clip:
            select_shape(j, Deco.shape)
            clear_inverse_selection(z)

    else:
        remove_layer(z)
        z = None
    return z


def make_canvas(maya, d):
    """
    Make Canvas/Caption text.

    maya: Maya
        'maya_caption' variety

    d: dict
        Caption Preset

    Return: layer or None
        Caption material
    """
    j = Run.j

    ready_canvas_rect(maya, d, option=None)
    return verify_layer(draw_text(j, maya, add_caption_z(j, maya), d))


def make_cell_per(maya, d):
    """
    Make text for Cell/Caption/Per.

    maya: Maya
        'maya_caption' variety

    d: dict
        Caption Preset

    Return: layer or None
        text
    """
    j = Run.j
    return verify_layer(create_cell(j, maya, add_caption_z(j, maya), d))


def make_face_main(maya, d):
    """
    Make Face/Caption text for main.

    maya: Maya
        'maya_caption' variety

    d: dict
        Caption Preset

    Return: layer or None
        Caption material
    """
    return create_facial_main(maya, d, create_face)


def make_face_per(maya, d):
    """
    Make text for Face/Caption/Per.

    maya: Maya
        'maya_caption' variety

    d: dict
        Caption Preset

    Return: layer or None
        Caption material
    """
    return verify_layer(create_facial_per(maya, d, create_face))


def make_facing_main(maya, d):
    """
    Make text for Facing/Caption main.

    maya: Maya
    d: dict
        Caption Preset

    Return: layer or None
        Caption material
    """
    return create_facial_main(maya, d, create_facing)


def make_facing_per(maya, d):
    """
    Make text for Facing/Caption/Per.

    maya: Maya
        'maya_caption' variety

    d: dict
        Caption Preset

    Return: layer or None
        Caption material
    """
    return create_facial_per(maya, d, create_facing)
