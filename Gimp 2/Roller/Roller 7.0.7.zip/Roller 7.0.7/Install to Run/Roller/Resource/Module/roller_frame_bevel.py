#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    FILL_PATTERN,
    CHANNEL_OP_ADD,
    CHANNEL_OP_SUBTRACT,
    LAYER_MODE_MULTIPLY,
    pdb
)
from math import sqrt
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_frame import do_image_selection, grow_wrap
from roller_frame_alt import FrameOverlay
from roller_gimp_context import set_fill_context_default, set_gimp_pattern
from roller_gimp_image import add_layer
from roller_gimp_layer import adjust_intensity, blur_selection, color_selection
from roller_gimp_selection import (
    get_select_bounds, select_channel, select_rect
)
import colorsys


def do_overlay(maya):
    """
    Make a pattern layer to overlay the frame.

    maya: Overlay
    Return: layer or None
        pattern
    """
    # Bevel Preset dict, 'd'
    d = maya.value_d

    z = add_layer(Run.j, maya.group, maya.get_light(), "Material")
    z.mode = LAYER_MODE_MULTIPLY

    pdb.gimp_selection_none(Run.j)
    set_fill_context_default()
    set_gimp_pattern(d[de.PATTERN])
    pdb.gimp_drawable_edit_bucket_fill(z, FILL_PATTERN, .0, .0)
    adjust_intensity(z)
    return z


def do_matter(maya):
    """
    Make a Wrap layer.

    maya: Bevel
    Return: layer
        Wrap output
    """
    return do_image_selection(maya, do_selection, embellish, "Material")


def do_rounded_edge(j, z, d, edge):
    """
    Create a color blend frame using a color and its luminosity.
    The round appearance is calculated using the unit circle formula,
    where 'x' is the luminosity step, and 'y' is the luminosity result.

        x**2 + y**2 = 1

    On entrance, expect a selection to add round edge.

    j: GIMP image
        work-in-progress

    z: layer
        Receive material.

    d: dict
        Bevel/Wrap Preset

    edge: float
        the number of gradient edge steps
    """
    h = d[de.HEIGHT]

    # the x-vector steps, 'f'
    f = 1. / max(1., (edge - 1.))

    # start color, RGB, 'q'
    q = colorsys.hsv_to_rgb(0., .0, h * sqrt(1. - f**2.))

    set_fill_context_default()
    for i in range(int(edge)):
        if not pdb.gimp_selection_is_empty(j):
            a = pdb.gimp_selection_save(j)
            q = tuple([int(b) for b in q])

            grow_wrap(j, None, 1., de.ANGULAR)
            select_channel(j, a, option=CHANNEL_OP_SUBTRACT)

            color_selection(z, q)
            select_channel(j, a, option=CHANNEL_OP_ADD)

            # Equate luminosity with the y-intersect on the unit circle.
            y = f * (i + 1.)

            if y < 1:
                # red and green, '.0'
                q = colorsys.hsv_to_rgb(.0, .0, h * sqrt(1. - y**2.))
            pdb.gimp_image_remove_channel(j, a)


def do_selection(maya, z):
    """
    Make Wrap for a selection. Expect a cast selection to be in place.
    Convert the cast selection to a rectangle selection in order to improve
    bevel output because the cast selection has anti-aliasing.

    maya: Maya
    z: layer
        Receive material.
    """
    j = Run.j

    # Bevel/Wrap Preset dict, 'd'
    d = maya.value_d

    is_sel, x, y, x1, y1 = get_select_bounds(j)

    if is_sel:
        w = d[de.WIDTH]
        edge = max(1., d[de.BEVEL_W] / 2., d[de.BEVEL_W])
        h = int(d[de.HEIGHT])

        # Create and save a selection for the inner bevel.
        # Convert to the selection to a rectangle selection.
        select_rect(j, x, y, x1 - x, y1 - y)

        grow_wrap(j, None, edge, de.RECTANGLE)

        sc = pdb.gimp_selection_save(j)

        # Frame width exceed edge width by at least one pixel.
        w += (edge * 2)

        x2 = x - w + edge
        y2 = y - w + edge
        x3 = x1 + w - edge
        y3 = y1 + w - edge

        select_rect(j, x2, y2, x3 - x2, y3 - y2)

        # Cut the inner rectangle out. The inner bevel grows inward.
        select_channel(j, sc, option=CHANNEL_OP_SUBTRACT)

        # The selection is useless.
        pdb.gimp_image_remove_channel(j, sc)

        color_selection(z, (h, h, h))

        # '180' is chosen as a subjective best match for perceptual grey.
        do_rounded_edge(j, z, d, edge)
    return z


def embellish(_, z):
    """
    Modify the Wrap material.

    _: Maya
        not used

    z: layer
        Has frame material.

    Return: layer
        Wrap material
    """
    blur_selection(z, 1)
    return z


class Bevel(FrameOverlay):
    kind = material = de.BEVEL
    overlay_k = de.OVERLAY_BE
    shade_row = rk.RW1
    wrap_k = de.WRAP_BE

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        FrameOverlay.__init__(
            self, any_group, super_maya, k_path, do_matter, do_overlay
        )
