#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import (
    MAX_SIZE,
    Backdrop as bs,
    Below as be,
    Blur as bu,
    Bump as fb,
    Caption as pt,
    Deco as dc,
    Frame as ff,
    Fill as fl,
    Gradient as fg,
    Grid as gr,
    Image as fi,
    Justification as ju,
    Mask as ms,
    Shape as sh,
    Issue as vo
)
from roller_constant_key import Option as ok, Widget as wk
from roller_def_act import (
    get_backdrop_type_list,
    get_below_type_list,
    get_box_type_list,
    get_brush_list,
    get_bump_type_list,
    get_camo_type_list,
    get_cell_shape_list,
    get_corner_type_list,
    get_criterion_list,
    get_decay_type_list,
    get_deco_type_list,
    get_edge_mode_list,
    get_frame_list,
    get_frame_style_list,
    get_justification_type,
    get_gradient_angle_list,
    get_gradient_list,
    get_gradient_type_list,
    get_grid_type_list,
    get_hexagon_type_list,
    get_image_name_list,
    get_image_type_list,
    get_mask_list,
    get_mesh_type_list,
    get_mode_name_list,
    get_news_type_list,
    get_noise_list,
    get_octagon_type_list,
    get_pattern_list,
    get_pin_list,
    get_profile_list,
    get_rectangle_type_list,
    get_resize_type_list,
    get_reverb_type_list,
    get_shape_list,
    get_shaped_list,
    get_spiral_mod_list,
    get_triangle_type_list,
    get_vector_list,
    get_wrap_types,
    make_bool_tip,
    make_radio_tip,
    make_rainbow_count_tip,
    make_rainbow_tip,
    make_slider_tip,
    make_text_tip
)
from roller_one_tip import Tip
from roller_port_choice import PortChoice
from roller_widget_button import RandomButton, RandomColorButton
from roller_widget_check_button import CheckButton, CheckButtonRandom
from roller_widget_combo import CaptionComboBox, ComboBox
from roller_widget_entry import Entry
from roller_widget_label import ModelTypeLabel
from roller_widget_number_pair import (
    CanvasPair, GradientPair, RectPair, RenderPair
)
from roller_widget_option_button import ListButton
from roller_widget_per import PerGroup
from roller_widget_slider import RandomSlider, Slider
from roller_widget_radio import (
    RadioRow, RadioRandomColumn, RadioRandomRow, SwitchRadio
)
from roller_widget_row import Rainbow
import sys

"""Define Widget option."""

# Base Type____________________________________________________________________
_CANVAS_PAIR = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0),
    wk.WIDGET: CanvasPair
}
_CHECK_BUTTON = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
_CHECK_BUTTON_RANDOM = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButtonRandom
}
_COMBO_BOX = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_text_tip,
    wk.WIDGET: ComboBox
}
_ENTRY = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_text_tip,
    wk.WIDGET: Entry
}
_LIST_BUTTON = {
    wk.STILL: True,
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_text_tip,
    wk.WIDGET: ListButton
}
_GRADIENT_PAIR = {
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_slider_tip,
    wk.WIDGET: GradientPair
}
_RAINBOW = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_rainbow_tip,
    wk.WIDGET: Rainbow
}
_RADIO_ROW = {
    wk.ISSUE: vo.MATTER,
    wk.RANDOM_Q: (0, 1),
    wk.TIPPER: make_radio_tip,
    wk.VAL: 0,
    wk.WIDGET: RadioRow
}
_RADIO_RANDOM_COLUMN = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_radio_tip,
    wk.VAL: 0,
    wk.WIDGET: RadioRandomColumn
}
_RADIO_RANDOM_ROW = {
    wk.ISSUE: vo.MATTER,
    wk.RANDOM_Q: (0, 1),
    wk.TIPPER: make_radio_tip,
    wk.VAL: 0,
    wk.WIDGET: RadioRandomRow
}
_RANDOM_COLOR_BUTTON = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_text_tip,
    wk.WIDGET: RandomColorButton
}
_RANDOM_SLIDER = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_text_tip,
    wk.WIDGET: RandomSlider
}
_RECT_PAIR = {
    wk.ISSUE: vo.MATTER,
    wk.LIMIT: (0, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.VAL: (0, .2),
    wk.WIDGET: RectPair
}
_RENDER_PAIR = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0),
    wk.WIDGET: RenderPair
}
_SLIDER = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_text_tip,
    wk.WIDGET: Slider
}
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

AMP = {
    wk.LIMIT: (2, 30),
    wk.RANDOM_Q: (2, 30),
    wk.TOOLTIP: Tip.AMP,
    wk.VAL: 3.
}
AMPLITUDE = {
    wk.LIMIT: (.0, 1000.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 20.),
    wk.VAL: 4.
}
AMPLITUDE_1 = {
    wk.LIMIT: (.0, .5),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.0, .5),
    wk.VAL: .25
}
ANGLE = {
    wk.LIMIT: (-359., 359.),
    wk.PAGE_INCR: 30.,
    wk.PRECISION: 2,
    wk.RANDOM_Q: (-359., 359.),
    wk.STEP_INCR: .1,
    wk.VAL: .0
}
ANGLE_JITTER = {
    wk.LIMIT: (.0, 180.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 180.),
    wk.VAL: .0
}
ANGLE_SHIFT = {
    wk.LIMIT: (.0, 180.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 11.),
    wk.VAL: 5.
}
AUTOCROP = {wk.TOOLTIP: Tip.AUTOCROP}
BACKING_TYPE = {
    wk.FUNCTION: get_backdrop_type_list,
    wk.VAL: bs.COLOR
}
BELOW_TYPE = {
    wk.FUNCTION: get_below_type_list,
    wk.LABEL_TIP: Tip.BELOW_TYPE,
    wk.VAL: be.MASK
}
BEVEL_W = {
    wk.LIMIT: (0, 999),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (4, 8),
    wk.VAL: 10.
}
BLEND = {
    wk.LIMIT: (1, 60),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (5, 20),
    wk.TOOLTIP: Tip.BLEND,
    wk.VAL: 12.
}
BLOCK_W = {wk.AXIS: 'x'}
BLOCK_H = {wk.AXIS: 'y'}
BLUR = {
    wk.LIMIT: (.0, 500.),
    wk.PRECISION: 1,
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (.0, 50.),
    wk.STEP_INCR: 1.,
    wk.VAL: .0
}
BLUR_POST = {wk.TOOLTIP: Tip.BLUR_POST}
BLUR_PRE = {wk.TOOLTIP: Tip.BLUR_PRE}

BLUR_POST.update(BLUR)
BLUR_PRE.update(BLUR)

for d_ in (BLUR_POST, BLUR_PRE):
    d_.update({wk.PAGE_INCR: 5, wk.RANDOM_Q: (.0, 10.)})

BLUR_TYPE = {wk.COLUMN_TEXT: ok.TYPE, wk.TEXT: bu.TYPE}
BLUR_XY = {
    wk.LIMIT: (1., 100.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (3., 20.),
    wk.VAL: .0
}
BORDER_W = {
    wk.LIMIT: (1, 9999),
    wk.PAGE_INCR: 10,
    wk.VAL: 4.
}
BOX_TYPE = {
    wk.FUNCTION: get_box_type_list,
    wk.LABEL_TIP: Tip.BOX_TYPE,
    wk.VAL: sh.TOP
}
BRUSH = {
    wk.DIALOG: PortChoice,
    wk.FUNCTION: get_brush_list,
    wk.VAL: "C_Normal Brush 80"
}
BRUSH_ANGLE = {
    wk.LIMIT: (-180., 180.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (-180., 180.),
    wk.VAL: .0
}
BRUSH_SIZE = {
    wk.LIMIT: (10, 9999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (25, 125),
    wk.VAL: 100.
}
BRUSH_SPACING = {
    wk.LIMIT: (1., 5000.),
    wk.PAGE_INCR: 10,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (25., 125.),
    wk.VAL: 100.
}
BUMP_DEPTH = {
    wk.LIMIT: (1, 100),
    wk.RANDOM_Q: (1, 4),
    wk.VAL: 1.
}
BUMP_TYPE = {
    wk.FUNCTION: get_bump_type_list,
    wk.VAL: fb.CLOTH
}
CAMO_TYPE = {
    wk.FUNCTION: get_camo_type_list,
    wk.VAL: ff.COMPOSITE
}
CAP_XY = {
    wk.LIMIT: (.0, 1.),
    wk.PAGE_INCR: .1,
    wk.PRECISION: 3,
    wk.STEP_INCR: .01,
    wk.VAL: .5
}
CAPTION_TYPE = {
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_text_tip,
    wk.VAL: pt.TEXT,
    wk.WIDGET: CaptionComboBox
}
CELL_SHAPE_CELL = {
    wk.FUNCTION: get_cell_shape_list,
    wk.VAL: sh.RECTANGLE
}
CELL_SIZE = {
    wk.LIMIT: (1, MAX_SIZE),
    wk.PAGE_INCR: 100,
    wk.TOOLTIP: Tip.CELL_SIZE,
    wk.VAL: 250.
}
CELL_SIZE_ETCH = {
    wk.LIMIT: (1, 1500),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (1, 100),
    wk.VAL: 9.
}
CIRCLE_DIAMETER = {
    # Is limited by GIMP's clipboard to
    # pattern function where the maximum side
    # span for the clipboard is 1024.
    wk.LIMIT: (12, 680),
    wk.RANDOM_Q: (12, 100),
    wk.VAL: 30.
}
CLIP = {wk.TOOLTIP: Tip.CLIP}
CLIPBOARD = {
    wk.LIMIT: (6, 1024),
    wk.RANDOM_Q: (108, 1024),
    wk.VAL: 512.
}
COLOR_1 = {wk.VAL: (0, 0, 0)}
COLOR_1A = {
    wk.HAS_ALPHA: True,
    wk.VAL: (127, 127, 127, 255)
}
COLOR_2 = {
    wk.BUTTON_COUNT: 2,
    wk.VAL: ((0, 0, 0), (255, 255, 255))
}
COLOR_2A = {
    wk.BUTTON_COUNT: 2,
    wk.HAS_ALPHA: True,
    wk.VAL: ((64, 64, 64, 255), (187, 187, 187, 255))
}
COLOR_3 = {
    wk.BUTTON_COUNT: 3,
    wk.VAL: (
        (160, 160, 160),
        (110, 110, 110),
        (70, 70, 70)
    )
}
COLOR_3A = {
    wk.BUTTON_COUNT: 3,
    wk.HAS_ALPHA: True,
    wk.VAL: (
        (24, 104, 174, 255),
        (217, 165, 179, 255),
        (198, 215, 235, 255)
    )
}
COLOR_6 = {
    wk.BUTTON_COUNT: 6,
    wk.VAL: (
        (0, 0, 0),
        (51, 51, 51),
        (102, 102, 102),
        (153, 153, 153),
        (204, 204, 204),
        (255, 255, 255)
    )
}
COLOR_6A = {
    wk.BUTTON_COUNT: 6,
    wk.HAS_ALPHA: True,
    wk.VAL: (
        (51, 51, 51, 255),
        (204, 204, 204, 255),
        (0, 0, 0, 255),
        (255, 255, 255, 255),
        (102, 102, 102, 255),
        (153, 153, 153, 255)
    )
}
COLOR_COUNT = {
    wk.LIMIT: (2, 6),
    wk.PAGE_INCR: 1,
    wk.RANDOM_Q: (2, 6),
    wk.TOOLTIP: Tip.COLOR_COUNT,
    wk.VAL: 2.
}
COLOR_COUNT_FRINGE = {
    wk.LIMIT: (1, 6),
    wk.PAGE_INCR: 1,
    wk.TOOLTIP: Tip.COLOR_COUNT,
    wk.VAL: 1.
}
COLOR_GRID_TYPE = {wk.TEXT: bs.COLOR_GRID_TYPE}
COLORIZE = {}
CONTRACT = {
    wk.LIMIT: (0, 9999),
    wk.PAGE_INCR: 50,
    wk.TOOLTIP: Tip.CONTRACT,
    wk.VAL: .0
}
CONTRAST = {
    wk.LIMIT: (-127, 127),
    wk.RANDOM_Q: (-30, 30),
    wk.VAL: .0
}
CORNER_SHIFT = {
    wk.LIMIT: (0, 100),
    wk.PAGE_INCR: 5,
    wk.RANDOM_Q: (0, 18),
    wk.VAL: 9.
}
CORNER_TYPE = {
    wk.FUNCTION: get_corner_type_list,
    wk.VAL: ms.CUT_CORNER
}
CRITERION = {
    wk.FUNCTION: get_criterion_list,
    wk.VAL: fl.COMPOSITE
}
CROP_XY = {
    wk.LIMIT: (0, MAX_SIZE),
    wk.PAGE_INCR: 10,
    wk.VAL: .0
}
CUT_OUT = {wk.TOOLTIP: Tip.CUT_OUT}
DECO_TYPE = {wk.FUNCTION: get_deco_type_list, wk.VAL: dc.COLOR}
DEPTH = {
    wk.LIMIT: (1., 100.),
    wk.PAGE_INCR: 5,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (1., 25.),
    wk.STEP_INCR: 1.,
    wk.VAL: 1.
}
DESATURATE = {}
DIAGONAL = {
    wk.LIMIT: (-359.9, 359.9),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (-359.9, 359.9),
    wk.VAL: 45.
}
DISTRESS = {
    wk.LIMIT: (1., 254.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (1., 254.),
    wk.TOOLTIP: Tip.DISTRESS,
    wk.VAL: 127.
}
EDGE_MODE = {
    wk.FUNCTION: get_edge_mode_list,
    wk.VAL: "Lighten Only"
}
EDGE_TYPE = {
    wk.FUNCTION: get_decay_type_list,
    wk.VAL: ff.WHITE_SOFT
}
EMBOSS = {}
EMBOSS_MODE = {
    wk.FUNCTION: get_mode_name_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: "Overlay"
}
FACTOR_SIZE = {
    wk.LIMIT: (.0, 2.),
    wk.PRECISION: 6,
    wk.STEP_INCR: .01,
    wk.VAL: 1.
}
FEATHER = {
    wk.LIMIT: (0, 1000),
    wk.PAGE_INCR: 50,
    wk.RANDOM_Q: (50, 300),
    wk.TOOLTIP: Tip.FEATHER,
    wk.VAL: 200.
}
FILL_MODE = {
    wk.FUNCTION: get_mode_name_list,
    wk.TOOLTIP: Tip.FILL_MODE,
    wk.VAL: "Normal"
}
FILTER = {wk.VAL: ""}
FIXED_SIZE = {
    wk.LIMIT: (1, MAX_SIZE),
    wk.PAGE_INCR: 100,
    wk.VAL: 200.
}
FLIP = {}
FOLDER_ORDER = {wk.TEXT: fi.FOLDER_ORDER_LIST}
FONT = {
    wk.DIALOG: PortChoice,
    wk.TIPPER: make_text_tip,
    wk.VAL: "Tahoma"
}
FONT_SIZE = {
    wk.LIMIT: (4, 999),
    wk.PAGE_INCR: 10,
    wk.TOOLTIP: Tip.FONT_SIZE,
    wk.VAL: 24.
}
FRAME_W = {
    wk.LIMIT: (1, 999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (1., 50.),
    wk.VAL: 6.
}
GAP_W = {
    # Is limited by GIMP's clipboard to
    # pattern function where the maximum side
    # dimension for the clipboard is 1024.
    wk.LIMIT: (1, 512),

    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (12, 100),
    wk.VAL: 24.
}
GRADIENT = {
    wk.DIALOG: PortChoice,
    wk.FUNCTION: get_gradient_list,
    wk.VAL: "Default"
}
GRADIENT_ANGLE = {
    wk.FUNCTION: get_gradient_angle_list,
    wk.VAL: fg.TOP_CENTER_TO_BOTTOM_CENTER
}
GRADIENT_DIRECTION = {wk.TEXT: bs.DIRECTION}
GRADIENT_END_X = {
    wk.AXIS: 'x',
    wk.TIPS: (Tip.END_X,),
    wk.VAL: (0, 1.)
}
GRADIENT_END_Y = {
    wk.AXIS: 'y',
    wk.TIPS: (Tip.END_Y,),
    wk.VAL: (0, 1.)
}
GRADIENT_START_X = {
    wk.AXIS: 'x',
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0)
}
GRADIENT_START_Y = {
    wk.AXIS: 'y',
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0)
}
GRADIENT_TYPE = {
    wk.FUNCTION: get_gradient_type_list,
    wk.VAL: fg.LINEAR
}
GRID_COUNT = {
    wk.LIMIT: (1, 100),
    wk.PAGE_INCR: 2,
    wk.VAL: 1.
}
GRID_SIZE = {
    wk.VAL: "",
    wk.WIDGET: ModelTypeLabel
}
GRID_TYPE = {
    wk.FUNCTION: get_grid_type_list,
    wk.LABEL_TIP: Tip.GRID_TYPE,
    wk.VAL: gr.CELL_COUNT
}
HARDNESS = {
    wk.LIMIT: (.001, 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.25, 1.),
    wk.STEP_INCR: .01,
    wk.VAL: 1.
}
HEXAGON_TYPE = {
    wk.FUNCTION: get_hexagon_type_list,
    wk.VAL: sh.HEXAGON
}
HSL = {
    wk.LIMIT: (-100., 100.),
    wk.PAGE_INCR: 10.,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (-100., 100.),
    wk.STEP_INCR: 1.,
    wk.VAL: .0
}
IMAGE_NAME = {
    wk.FUNCTION: get_image_name_list,
    wk.VAL: ""
}
IMAGE_TYPE = {
    wk.FUNCTION: get_image_type_list,
    wk.VAL: ok.NEXT
}
INDENT = {wk.TOOLTIP: Tip.INDENT}
INNER_FRAME_W = {
    wk.LIMIT: (4, 14),
    wk.RANDOM_Q: (4, 14),
    wk.VAL: 5.
}
INTENSITY = {
    wk.LIMIT: (0, 1000),
    wk.PAGE_INCR: 25,
    wk.RANDOM_Q: (50, 200),
    wk.TOOLTIP: Tip.INTENSITY,
    wk.VAL: 0.
}
INVERT = {}
INWARD = {wk.TOOLTIP: Tip.INWARD}
ITERATIONS = {
    wk.LIMIT: (0, 100),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (0, 20),
    wk.VAL: 12.
}
JUSTIFICATION = {
    wk.FUNCTION: get_justification_type,
    wk.VAL: ju.CENTER
}
KEEP = {wk.TOOLTIP: Tip.KEEP}
LAYER_COUNT = {
    wk.LIMIT: (3, 20),
    wk.RANDOM_Q: (4, 8),
    wk.VAL: 7.
}
LAYER_ORDER = {
    wk.TEXT: fi.LAYER_ORDER_LIST,
    wk.TOOLTIP: Tip.LAYER_ORDER
}
LAYERED = {wk.TOOLTIP: Tip.LAYERED}
LENGTH = {
    wk.LIMIT: (5, 1000),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (80, 150),
    wk.VAL: 150.
}
LENGTH_SHIFT = {
    wk.LIMIT: (0, 999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (10, 40),
    wk.TOOLTIP: Tip.LENGTH_SHIFT,
    wk.VAL: 10.
}
LINE_W = {
    # Is limited by GIMP's clipboard to
    # pattern function where the maximum side
    # dimension for the clipboard is 1024.
    wk.LIMIT: (1, 512),

    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (1, 30),
    wk.VAL: 6.
}
LINE_W_LINE = {
    wk.LIMIT: (1, 9999),
    wk.PAGE_INCR: 2,
    wk.VAL: 2.
}
LOOP = {
    wk.TEXT: fi.LOOP_TYPE,
    wk.TIPS: (Tip.LOOP_PLUS, Tip.LOOP_MINUS)
}
MASK_TYPE = {
    wk.FUNCTION: get_mask_list,
    wk.VAL: "Circle"
}
MAX_POLAR_X = {
    wk.AXIS: 'x',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
}
MAX_POLAR_Y = {
    wk.AXIS: 'y',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE)
}
MAX_POSITIVE_X = {
    wk.AXIS: 'x',
    wk.LIMIT: (0, MAX_SIZE)
}
MAX_POSITIVE_Y = {
    wk.AXIS: 'y',
    wk.LIMIT: (0, MAX_SIZE)
}
MESH_TYPE = {
    wk.FUNCTION: get_mesh_type_list,
    wk.VAL: bs.SQUARE
}
MASK_SCALE = {
    wk.LIMIT: (.001, 1.),
    wk.PRECISION: 3,
    wk.STEP_INCR: .01,
    wk.VAL: 1.
}
MAZE = {
    wk.LIMIT: (4, 999),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (4, 50),
    wk.VAL: 10.
}
MESH_SIZE = {
    wk.LIMIT: (8, 1000),
    wk.RANDOM_Q: (25, 100),
    wk.VAL: 50.
}
MODE = {
    wk.FUNCTION: get_mode_name_list,
    wk.ISSUE: vo.MODE,
    wk.TIPPER: make_text_tip,
    wk.VAL: "Normal",
    wk.WIDGET: ComboBox
}
NAME_DROP = {wk.VAL: "Drop Zone"}
NAME_GRADIENT = {wk.VAL: "Sampled Gradient"}
NEATNESS = {
    wk.LIMIT: (.0, 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.0, 1.),
    wk.STEP_INCR: .01,
    wk.VAL: 1.
}
NET_LINE = {
    wk.LIMIT: (1, 9999),
    wk.PAGE_INCR: 10,
    wk.VAL: 6.
}
NOISE_AMOUNT = {
    wk.LIMIT: (1, 15),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (1, 15),
    wk.VAL: 2.
}
NOISE_TYPE = {
    wk.FUNCTION: get_noise_list,
    wk.VAL: ff.INK
}
OBEY_MARGIN = {wk.TOOLTIP: Tip.OBEY_MARGIN}
OCTAGON_TYPE = {
    wk.FUNCTION: get_octagon_type_list,
    wk.VAL: sh.OCTAGON
}
OFFSET = {
    wk.LIMIT: (0, 9999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (0, 10),
    wk.VAL: 0.
}
OFFSET_XY = {
    wk.LIMIT: (-4096, 4096),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (-30, 30),
    wk.VAL: 0.
}
OPACITY = {
    wk.ISSUE: vo.OPACITY,
    wk.LIMIT: (.0, 100.),
    wk.PAGE_INCR: 10.,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 100.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 100.,
    wk.WIDGET: RandomSlider
}
OPAQUE = {wk.TOOLTIP: Tip.OPAQUE}
OVERFLOW_OV_TYPE = {
    wk.FUNCTION: get_frame_style_list,
    wk.VAL: ff.CLOUDS
}
PATTERN = {
    wk.DIALOG: PortChoice,
    wk.FUNCTION: get_pattern_list,
    wk.VAL: "Pine"
}
PATTERN_SIZE = {
    # Limit due to GIMP's clipboard to
    # pattern function where the maximum side
    # dimension for the clipboard is 1024.
    wk.LIMIT: (24, 256),
    wk.RANDOM_Q: (120, 256),
    wk.VAL: 120.
}
PER = {
    wk.ISSUE: vo.PER,
    wk.VAL: {},
    wk.WIDGET: PerGroup
}
PERCENTILE = {
    wk.LIMIT: (.0, 100.),
    wk.PAGE_INCR: 10,
    wk.PRECISION: 2,
    wk.RANDOM_Q: (.0, 100.),
    wk.STEP_INCR: 1,
    wk.TOOLTIP: Tip.PERCENTILE,
    wk.VAL: 50.
}
PERIOD = {
    wk.LIMIT: (.1, 1000.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (10., 500.),
    wk.VAL: 36.
}
PHASE = {
    wk.LIMIT: (-1., 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (-1., 1.),
    wk.VAL: .0
}
PIN = {
    wk.FUNCTION: get_pin_list,
    wk.LABEL_TIP: Tip.PIN,
    wk.VAL: gr.CENTER
}
POWER = {
    wk.LIMIT: (0, 180),
    wk.RANDOM_Q: (0, 180),
    wk.TOOLTIP: Tip.POWER,
    wk.VAL: 0.
}
PREVIEW_MODE = {wk.TEXT: ("Show Gradient", "Show Samples.")}
PROFILE = {
    wk.FUNCTION: get_profile_list,
    wk.VAL: ff.BAND
}
R_C = {
    wk.LIMIT: (1, 999),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (1, 50),
    wk.VAL: 5.
}
RADIUS = {
    wk.LIMIT: (-400, 400),
    wk.PAGE_INCR: 5,
    wk.RANDOM_Q: (-20, 20),
    wk.STEP_INCR: 1,
    wk.VAL: 3
}
RANDOM = {
    wk.STILL: True,
    wk.WIDGET: RandomButton
}
RANDOM_ORDER = {}
RC_SLICE = {
    wk.LIMIT: (1, 100),
    wk.VAL: 1.
}
RECTANGLE_TYPE = {
    wk.FUNCTION: get_rectangle_type_list,
    wk.VAL: sh.RECTANGLE
}
RESIZE_TYPE = {
    wk.FUNCTION: get_resize_type_list,
    wk.VAL: ok.LOCKED
}
REVERB = {
    wk.LIMIT: (.0, 1.),
    wk.PRECISION: 2,
    wk.RANDOM_Q: (.0, 1.),
    wk.STEP_INCR: .1,
    wk.VAL: 1.
}
REVERB_TYPE = {
    wk.FUNCTION: get_reverb_type_list,
    wk.VAL: bs.RANDOM_COLOR
}
REVERSE = {wk.TOOLTIP: Tip.REVERSE}
SAMPLE_COUNT = {
    wk.LIMIT: (2, 50),
    wk.RANDOM_Q: (2, 12),
    wk.TOOLTIP: Tip.SAMPLE_COUNT,
    wk.VAL: 5.
}
SAMPLE_RADIUS = {
    wk.LIMIT: (1., 100.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (10., 50.),
    wk.VAL: 15.
}
SAMPLE_VECTOR = {
    wk.FUNCTION: get_vector_list,
    wk.VAL: bs.VERTICAL
}
SCATTER_COUNT = {
    wk.LIMIT: (1, 100),
    wk.PAGE_INCR: 5,
    wk.RANDOM_Q: (2, 20),
    wk.TOOLTIP: Tip.SCATTER_COUNT,
    wk.VAL: 5.
}
SEED = {
    wk.LIMIT: (0, 99999),
    wk.RANDOM_Q: (0, 99999),
    wk.TOOLTIP: Tip.SEED,
    wk.VAL: 0.
}
SHADOW_BLUR = {
    wk.LIMIT: (.0, 500.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 50.),
    wk.VAL: 15.
}
SHAPE = {
    wk.FUNCTION: get_shape_list,
    wk.VAL: sh.RECTANGLE
}
SHAPED_TYPE = {
    wk.FUNCTION: get_shaped_list,
    wk.VAL: fg.SHAPED_DIMPLED
}
SHIFT = {
    wk.LIMIT: (0, 200),
    wk.RANDOM_Q: (0, 200),
    wk.VAL: 200.
}
SHIFT_DIRECTION = {wk.TEXT: bs.SHIFT_DIRECTION}
SIZE_XY = {
    wk.LIMIT: (.0, 500.),
    wk.PAGE_INCR: 10.,
    wk.PRECISION: 2,
    wk.RANDOM_Q: (.0, 100.),
    wk.STEP_INCR: 1.,
    wk.VAL: .0
}
SKETCH_TEXTURE = {
    wk.FUNCTION: get_news_type_list,
    wk.VAL: bs.DOT
}
SLICE = {wk.TOOLTIP: Tip.SLICE}
SLICE_COUNT = {
    wk.LIMIT: (2, 60),
    wk.RANDOM_Q: (2, 15),
    wk.VAL: 6.
}
SLICE_ORDER = {wk.TEXT: fi.SLICE_ORDER_LIST}
SMOOTH = {
    wk.LIMIT: (3, 20),
    wk.RANDOM_Q: (5, 12),
    wk.VAL: 4.
}
START_NUMBER = {
    wk.LIMIT: (-sys.maxint, sys.maxint),
    wk.PAGE_INCR: 100,
    wk.TOOLTIP: Tip.START_NUMBER,
    wk.VAL: 1.
}
STENCIL_TYPE = {
    wk.FUNCTION: get_frame_list,
    wk.VAL: "None"
}
SPECK_NOISE = {
    wk.LIMIT: (.05, 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.05, 1.),
    wk.STEP_INCR: .01,
    wk.VAL: .22
}
SPIRAL_DISTANCE = {
    wk.LIMIT: (.001, .5),
    wk.RANDOM_Q: (.001, .5),
    wk.PRECISION: 3,
    wk.TOOLTIP: Tip.SPIRAL_DISTANCE,
    wk.VAL: .1
}
SPIRAL_MOD = {
    wk.FUNCTION: get_spiral_mod_list,
    wk.VAL: "None"
}
SPREAD = {
    wk.LIMIT: (0, 512),
    wk.RANDOM_Q: (0, 512),
    wk.VAL: 512.
}
SPREAD_WRAP_CR = {
    wk.LIMIT: (1., 100.),
    wk.PAGE_INCR: 5.,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (8., 16.),
    wk.TOOLTIP: Tip.SPREAD,
    wk.VAL: 12.
}
START_X = {wk.AXIS: 'x'}
START_Y = {wk.AXIS: 'y'}
STEPS = {
    wk.LIMIT: (1, 50),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (1, 12),
    wk.TOOLTIP: Tip.STEPS,
    wk.VAL: 6.
}
STEPS_DROP = {
    wk.LIMIT: (2, 100),
    wk.RANDOM_Q: (2, 12),
    wk.TOOLTIP: Tip.STEPS_DROP_ZONE,
    wk.VAL: 12.
}
STRIP_HEIGHT = {
    wk.LIMIT: (.0, 7.),
    wk.PRECISION: 2,
    wk.RANDOM_Q: (.1, 7.),
    wk.STEP_INCR: .1,
    wk.TOOLTIP: Tip.STRIP_H,
    wk.VAL: 1.5
}
SUPERPIXEL_SIZE = {
    wk.LIMIT: (8, 256),
    wk.RANDOM_Q: (8, 256),
    wk.VAL: 32.
}
SWITCH = {
    wk.COLUMN_TEXT: ok.SWITCH,
    wk.ISSUE: vo.MATTER,
    wk.TEXT: ("Off", "On"),
    wk.VAL: 0,
    wk.WIDGET: SwitchRadio
}
TAB = {
    wk.LIMIT: (1, 999),
    wk.PAGE_INCR: 2,
    wk.VAL: 1.
}
TAPE_WIDTH = {
    wk.LIMIT: (5, 999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (30, 60),
    wk.VAL: 50.
}
TEXT = {
    wk.CHARS: 15,
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_text_tip,
    wk.VAL: "",
    wk.WIDGET: Entry
}
TEXTURE = {}
THRESHOLD = {
    wk.LIMIT: (.0, 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.33, 1.),
    wk.STEP_INCR: .01,
    wk.TOOLTIP: Tip.THRESHOLD,
    wk.VAL: 1.
}
TILE_SIZE = {
    wk.LIMIT: (2., 256.),
    wk.RANDOM_Q: (7, 45),
    wk.VAL: 20.
}
TRIANGLE_TYPE = {
    wk.FUNCTION: get_triangle_type_list,
    wk.VAL: ms.TRIANGLE_UP_REGULAR
}
UNSHARP_AMOUNT = {
    wk.LIMIT: (.0, 300.),
    wk.PAGE_INCR: 10.,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 50.),
    wk.VAL: 10.
}
UNSHARP_RADIUS = {
    wk.LIMIT: (.0, 1500.),
    wk.PAGE_INCR: 10.,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 50.),
    wk.VAL: 11.
}
UNSHARP_THRESHOLD = {
    wk.LIMIT: (.0, .1),
    wk.PRECISION: 2,
    wk.RANDOM_Q: (.0, .1),
    wk.TIPPER: make_text_tip,
    wk.VAL: .03
}
UP = {
    wk.LIMIT: (.0, 10.),
    wk.PAGE_INCR: 1.,
    wk.PRECISION: 2,
    wk.RANDOM_Q: (.0, .5),
    wk.STEP_INCR: .1,
    wk.TOOLTIP: Tip.UPSCALE,
    wk.VAL: .0
}
UP_SPACE = {wk.TOOLTIP: Tip.UP_SPACE}
UPSCALE = {wk.TOOLTIP: Tip.UPSCALE}

UP_SPACE.update(UP)
UPSCALE.update(UP)

WAVE_COUNT = {
    wk.LIMIT: (1, 24),
    wk.RANDOM_Q: (1, 24),
    wk.VAL: 1.
}
WAVE_PER_LAYER = {
    wk.LIMIT: (1, 18),
    wk.RANDOM_Q: (1, 18),
    wk.VAL: 5.
}
WHIRL = {
    wk.LIMIT: (-720, 720),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (-30, 30),
    wk.TOOLTIP: Tip.WHIRL,
    wk.VAL: 45.
}
WIDTH = {
    wk.LIMIT: (1, 9999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (1, 100),
    wk.VAL: 30
}
WIRE_THICKNESS = {
    wk.LIMIT: (1, 30),
    wk.RANDOM_Q: (4, 10),
    wk.VAL: 3.
}
WOBBLE_FACTOR = {
    wk.LIMIT: (.0, 1.),
    wk.PRECISION: 2,
    wk.RANDOM_Q: (.01, 1.),
    wk.VAL: .08
}
WRAP_TYPE = {
    wk.FUNCTION: get_wrap_types,
    wk.VAL: ff.ROUNDED
}

# Update option definition with a factored Widget type.________________________
for i in (START_X, START_Y):
    i.update(_CANVAS_PAIR)

for i in (
    AUTOCROP, CUT_OUT, FLIP, INDENT, INWARD, KEEP, LAYERED, OBEY_MARGIN,
    OPAQUE, SLICE
):
    i.update(_CHECK_BUTTON)

for i in (
    CLIP, COLORIZE, DESATURATE, EMBOSS, INVERT, RANDOM_ORDER, REVERSE, TEXTURE
):
    i.update(_CHECK_BUTTON_RANDOM)

for i in (
    BACKING_TYPE, BELOW_TYPE, BOX_TYPE, BUMP_TYPE, CAMO_TYPE, CELL_SHAPE_CELL,
    CORNER_TYPE, CRITERION, DECO_TYPE, EDGE_MODE,
    EMBOSS_MODE, EDGE_TYPE, FILL_MODE,
    GRADIENT_ANGLE, GRADIENT_TYPE, GRID_TYPE, HEXAGON_TYPE,
    IMAGE_NAME, IMAGE_TYPE, JUSTIFICATION, MASK_TYPE, MESH_TYPE,
    NOISE_TYPE, OCTAGON_TYPE, OVERFLOW_OV_TYPE,
    PIN, PROFILE, RECTANGLE_TYPE, RESIZE_TYPE, REVERB_TYPE,
    SAMPLE_VECTOR, SHAPE, SHAPED_TYPE, SKETCH_TEXTURE, SPIRAL_MOD,
    STENCIL_TYPE, TRIANGLE_TYPE, WRAP_TYPE
):
    i.update(_COMBO_BOX)

for i in (FILTER, NAME_DROP, NAME_GRADIENT):
    i.update(_ENTRY)

for i in (GRADIENT_END_X, GRADIENT_END_Y, GRADIENT_START_X, GRADIENT_START_Y):
    i.update(_GRADIENT_PAIR)

for i in (BRUSH, FONT, GRADIENT, PATTERN):
    i.update(_LIST_BUTTON)

for i in (FOLDER_ORDER, LAYER_ORDER, LOOP, SLICE_ORDER):
    i.update(_RADIO_RANDOM_COLUMN)

for i in (PREVIEW_MODE,):
    i.update(_RADIO_ROW)

for i in (COLOR_2, COLOR_2A, COLOR_3, COLOR_3A, COLOR_6, COLOR_6A):
    i.update(_RAINBOW)

for i in (COLOR_1, COLOR_1A):
    i.update(_RANDOM_COLOR_BUTTON)

for i in (BLUR_TYPE, COLOR_GRID_TYPE, GRADIENT_DIRECTION, SHIFT_DIRECTION):
    i.update(_RADIO_RANDOM_ROW)

for i in (
    AMP,  AMPLITUDE, AMPLITUDE_1, ANGLE, ANGLE_JITTER, ANGLE_SHIFT, BEVEL_W,
    BLEND, BLUR, BLUR_POST, BLUR_PRE, BLUR_XY, BRUSH_ANGLE,
    BRUSH_SPACING, BRUSH_SIZE, BUMP_DEPTH,
    CELL_SIZE_ETCH, CAP_XY, CIRCLE_DIAMETER, CLIPBOARD, COLOR_COUNT,
    CONTRAST, CORNER_SHIFT, DIAGONAL,
    DEPTH, DISTRESS, FEATHER, FRAME_W, GAP_W,
    HARDNESS, HSL, INNER_FRAME_W, INTENSITY, ITERATIONS, LAYER_COUNT, LENGTH,
    LENGTH_SHIFT, LINE_W, MAZE, MESH_SIZE, NEATNESS, NOISE_AMOUNT,
    OFFSET, OFFSET_XY, PATTERN_SIZE, PERCENTILE, PERIOD, PHASE, POWER,
    R_C, RADIUS, REVERB, SEED, SAMPLE_COUNT,
    SAMPLE_RADIUS, SCATTER_COUNT, SHADOW_BLUR,
    SHIFT, SLICE_COUNT, SMOOTH, SPECK_NOISE, SPIRAL_DISTANCE, SPREAD,
    SPREAD_WRAP_CR, STEPS, STEPS_DROP, SIZE_XY, STRIP_HEIGHT,
    SUPERPIXEL_SIZE, TAPE_WIDTH, THRESHOLD, TILE_SIZE, UNSHARP_AMOUNT,
    UNSHARP_RADIUS, UNSHARP_THRESHOLD, UP_SPACE, UPSCALE, WAVE_PER_LAYER,
    WAVE_COUNT, WHIRL, WIDTH, WIRE_THICKNESS, WOBBLE_FACTOR
):
    i.update(_RANDOM_SLIDER)

for i in (BLOCK_H, BLOCK_W):
    i.update(_RECT_PAIR)

for i in (MAX_POLAR_X, MAX_POLAR_Y, MAX_POSITIVE_X, MAX_POSITIVE_Y):
    i.update(_RENDER_PAIR)

for i in (
    BORDER_W, CELL_SIZE, COLOR_COUNT_FRINGE, CONTRACT, CROP_XY,
    FACTOR_SIZE, FIXED_SIZE, FONT_SIZE, GRID_COUNT, LINE_W_LINE,
    MASK_SCALE, NET_LINE, TAB, RC_SLICE, START_NUMBER
):
    i.update(_SLIDER)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

for i in (COLOR_6, COLOR_6A):
    i.update({wk.TIPPER: make_rainbow_count_tip})

# CFW
CFW = deepcopy(FRAME_W)
CFW[wk.LIMIT] = 0, 999
CFW[wk.VAL] = 0.

# Crop X
CROP_X = deepcopy(CROP_XY)
CROP_X[wk.TOOLTIP] = Tip.CROP_X

CROP_Y = deepcopy(CROP_XY)

# Gradient Opacity
GRADIENT_OPACITY = deepcopy(OPACITY)
GRADIENT_OPACITY[wk.VAL] = 50.

# Matter Mode
MATTER_MODE = deepcopy(MODE)
MATTER_MODE[wk.ISSUE] = vo.MATTER

# Noise Opacity
NOISE_OPACITY = deepcopy(OPACITY)
NOISE_OPACITY[wk.VAL] = 30.
NOISE_OPACITY[wk.ISSUE] = vo.MATTER

# Overlay Mode
OVERLAY_MODE = deepcopy(MODE)
OVERLAY_MODE[wk.VAL] = "Overlay"
