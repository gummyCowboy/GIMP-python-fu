#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_SUBTRACT,
    CLIP_TO_IMAGE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_OVERLAY,
    pdb
)
from roller_a_contain import Run, Globe
from roller_a_gegl import noise_rgb
from roller_constant_key import Material as ma, Option as ok
from roller_frame_alt import FrameBasic
from roller_fu import (
    add_layer,
    clear_inverse_selection,
    clone_layer,
    clone_opaque_layer,
    dilate,
    load_selection,
    remove_z,
    saturate,

    select_opaque
)
from roller_fu_comm import show_err
from roller_view_hub import do_curves
from roller_view_real import get_light

"""
Define 'frame_crumble' as a Maya-subtype
for managing a variation of Frame type.
"""

SAWTOOTH = (
    .0, .0,
    .166, .166,
    .167, .1,
    .333, .333,
    .334, .166,
    .5, .5,
    .501, .25,
    .666, .666,
    .667, .444,
    1., 1.
)


def do_matter(maya):
    """
    Make a Crumble frame.

    maya: Crumble
    Return: layer or None
        Wrap output
    """
    j = Run.j
    d = maya.value_d
    go = False
    cast_z = maya.cast.matter
    sel = None

    # failed frame layer, 'z'
    z = wip_z = None

    select_opaque(cast_z)

    if not pdb.gimp_selection_is_empty(j):
        if d[ok.CLIP]:
            sel = pdb.gimp_selection_save(j)

        z = wip_z = add_layer(j, "Material", maya.group, get_light(maya))

        # Make a border overlapping the matter.
        pdb.gimp_selection_border(j, int(d[ok.WIDTH]))

        try:
            # Can throw an error if the image size is too small.
            # Create crumble selection from the frame selection.
            pdb.script_fu_distress_selection(
                j, z,
                d[ok.DISTRESS],
                d[ok.SPREAD],
                4., 2.,
                1, 1                          # smooth horizontal and vertical
            )

        except Exception as ex:
            show_err(ex)
        if not pdb.gimp_selection_is_empty(j) and d[ok.CLIP]:
            load_selection(j, sel, option=CHANNEL_OP_SUBTRACT)

    if sel:
        pdb.gimp_image_remove_channel(j, sel)

    if not pdb.gimp_selection_is_empty(j):
        a = pdb.gimp_selection_save(j)

        # Add noise to the selection.
        # GEGL's Simplex-Noise failed me, so I use this.
        for i in range(12):
            noise_rgb(
                z,
                1., 1., 1., 1.,
                int(d[ok.SEED] + Globe.seed) + i
            )

            if i % 2:
                pdb.plug_in_erode(
                    j, z,
                    1,                      # propagate black
                    7,                      # RGB channels
                    1.,                     # full rate
                    7,                      # direction mask
                    0,                      # lower limit
                    255                     # upper limit
                )
            else:
                dilate(z)

        pdb.plug_in_despeckle(
            j, z,
            3,                  # radius
            3,                  # recursive adaptive
            0,                  # black start point
            255                 # white end point
        )

        z = clone_layer(z, n="Difference")
        z.mode = LAYER_MODE_DIFFERENCE
        go = True

        load_selection(j, a)
        clear_inverse_selection(z)
        pdb.gimp_image_remove_channel(j, a)

    if go:
        pdb.plug_in_colortoalpha(j, z, (1., 1., 1.))
        saturate(z, -85.)

        z = clone_layer(z, n="Burn")

        dilate(z)

        z.mode = LAYER_MODE_OVERLAY
        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
        z = clone_opaque_layer(z, n="Burn")
        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

        do_curves(z, SAWTOOTH)

        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

        pdb.plug_in_unsharp_mask(
            j, z,
            4.,                                 # radius
            .5,                                 # amount
            .0                                  # threshold
        )
        remove_z(wip_z)
    return z


class Crumble(FrameBasic):
    is_seeded = True
    kind = material = ma.CRUMBLE
    wrap_k = ok.WRAP_CR

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
