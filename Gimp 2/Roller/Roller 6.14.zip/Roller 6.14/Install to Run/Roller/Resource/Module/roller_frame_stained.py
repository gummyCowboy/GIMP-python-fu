#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CLIP_TO_IMAGE,
    HISTOGRAM_VALUE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_DIVIDE,
    LAYER_MODE_LUMA_DARKEN_ONLY,
    LAYER_MODE_NORMAL,
    pdb
)
from roller_a_contain import Run
from roller_a_gegl import edge, high_pass
from roller_constant_key import Material as ma, Option as ok
from roller_frame import do_alt_frame
from roller_frame_alt import AltWrapFiller
from roller_fu import (
    add_layer,
    clone_layer,
    get_item_size,
    get_layer_position,
    saturate,
    select_rect
)
from roller_one import random_rgb
from roller_view_hub import (
    color_selection,
    do_curves,
    do_mod,
    do_rotated_layer,
    set_fill_context_default
)
from roller_view_preset import combine_seed
from roller_view_real import get_light

"""
Define 'frame_stained' as a Maya-subtype
for managing a variation of Frame type.
"""


def do_matter(maya):
    """
    Make a frame.

    maya: Stained
    Return: layer
        Stained/Wrap 'matter'
    """
    return do_alt_frame(maya)


def do_filler(maya):
    """
    Draw Filler material.

    maya: AltFiller
    z: layer
        Receive pattern.

    d: dict
        Stained Preset

    sel: GIMP selection channel
        Is the chip area.

    Return: layer
        Stained/Filler layer
    """
    j = Run.j
    d = maya.value_d

    combine_seed(d)

    z = add_layer(j, "Material", maya.group, get_light(maya))
    z1 = do_rotated_layer(d, draw_color, z.parent, get_layer_position(z))
    z2 = clone_layer(z1)

    edge(z2)

    z3 = clone_layer(z2)
    z.mode = LAYER_MODE_DIVIDE
    z2 = pdb.gimp_image_merge_down(j, z3, CLIP_TO_IMAGE)

    # Remove the color.
    saturate(z2, -100.)

    do_curves(z2, (.0, .0, .7, 1.))

    # Convert the layer to be a black edge on white material.
    # no linear, '0'
    pdb.gimp_drawable_invert(z2, 0)

    z2.mode = LAYER_MODE_LUMA_DARKEN_ONLY
    z1 = pdb.gimp_image_merge_down(j, z2, CLIP_TO_IMAGE)

    saturate(z1, 30.)

    z2 = clone_layer(z1)

    high_pass(z2, 4., 1.)

    z2.mode = LAYER_MODE_DIFFERENCE
    z1 = pdb.gimp_image_merge_down(j, z2, CLIP_TO_IMAGE)
    z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

    # Curves won't work with a selection.
    pdb.gimp_selection_none(j)

    pdb.gimp_drawable_curves_spline(
        z, HISTOGRAM_VALUE, 6, (.0, .0, .3764, .545, 1., 1.)
    )
    do_mod(z, d[ok.BRW][ok.MOD])
    return z


def draw_color(z, d):
    """
    Create color rectangles from two layers of color stripes.

    z: layer
        layer to draw on

    d: dict
        Stained Preset

    Return: layer
        Has color grid.
    """
    # vertical panes
    j = z.image
    x = y = x1 = y1 = .0
    w1, h1 = get_item_size(j)
    z.mode, z.opacity = LAYER_MODE_NORMAL, 100.
    w = d[ok.PANE_W]

    set_fill_context_default()

    while x < w1:
        x1 = min(x1 + w, w1)

        select_rect(j, x, .0, x1 - x, h1)
        color_selection(z, random_rgb())
        x = x1

    z = clone_layer(z, n="Difference")
    z.mode = LAYER_MODE_DIFFERENCE

    # horizontal panes
    while y < h1:
        y1 = min(y1 + w, h1)

        select_rect(j, .0, y, w1, y1 - y)
        color_selection(z, random_rgb())
        y = y1
    return pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)


class Stained(AltWrapFiller):
    filler_k = ok.FILLER_S1
    kind = material = ma.STAINED
    shade_row = ok.BRW
    wrap_k = ok.WRAP_FI

    def __init__(self, any_group, super_maya, k_path):
        AltWrapFiller.__init__(
            self, any_group, super_maya, k_path, do_matter, do_filler
        )
