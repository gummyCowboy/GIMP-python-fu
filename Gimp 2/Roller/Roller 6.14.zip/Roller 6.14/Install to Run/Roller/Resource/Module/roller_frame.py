#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD,
    CHANNEL_OP_INTERSECT,
    CHANNEL_OP_SUBTRACT,
    CLIP_TO_IMAGE,
    pdb
)
from roller_a_contain import Globe, Run
from roller_a_gegl import emboss
from roller_constant_for import Frame as ff
from roller_constant_key import Group as gk, Option as ok, SubMaya as sm
from roller_def_access import get_default_value
from roller_fu import (
    add_layer,
    add_layer_above,
    clear_selection,
    get_layer_position,
    get_select_bounds,
    isolate_selection,
    load_selection,
    move_layer,
    remove_z,
    select_item,
    select_rect,
    verify_layer
)
from roller_fu_mode import get_mode
from roller_maya_build import SubBuild
from roller_maya_layer import check_matter
from roller_a_gegl import blur
from roller_view_hub import (
    color_layer, color_selection, do_rotated_layer, set_fill_context_default
)
from roller_view_real import clip_to_wip, get_light, mask_sel
from roller_view_shadow import make_shadow

"""
Define 'frame' as a factored function and as sub-Maya
class for managing factored Frame type.
"""


def do_alt_frame(maya):
    """
    Make an embossed frame.

    maya: Maya
    Return: layer or None
        frame
    """
    d = maya.value_d
    j = Run.j

    # Add a pattern layer to the bottom of the Maya's group layer, 'z'.
    z = add_layer(j, "Material", maya.group, get_light(maya))

    remove_sel(maya, 'filler_sel')

    maya.filler_sel = make_filler_frame_sel(maya, j, d)
    z = verify_layer(do_emboss_sel(z, d))

    if z:
        z.name = z.parent.name + " " + maya.super_maya.kind
    return z


def do_embossed_wrap(maya):
    """
    Make a frame around material.

    maya: Maya
    Return: layer
        frame
    """
    j = Run.j
    d = maya.value_d
    group = maya.group

    # layer for the emboss, 'z'
    z = add_layer(j, "Material", group, get_light(maya))

    select_wrap(j, maya.cast.matter, d[ok.WIDTH], d[ok.TYPE])
    return do_emboss_sel(z, d)


def do_cast_shadow(maya):
    """
    Process shadow for the cast.

    maya: Maya
        Frame sub-type

    Return: layer or None
        shadow
    """
    d = get_default_value(gk.SHADOW_1)
    frame = maya.super_maya
    cast = frame.cast
    group = cast.group.parent

    d.update(maya.value_d)
    return make_shadow(
        d,
        group,
        (cast.matter,),
        name=group.name + " Shadow"
    )


def do_embossed_frame(maya, make_pattern):
    """
    Make an embossed frame.

    maya: Maya
    make_pattern: function
        Make Filler selection.

    Return: layer or None
        frame
    """
    def _draw(_z):
        """
        Return a layer having a pattern fill.

        _z: layer
            Maya matter layer
        """
        return do_rotated_layer(
            filler_d,
            make_pattern,
            maya.group,
            len(maya.group.layers) - 1
        )

    d = maya.value_d
    filler_d = maya.super_maya.value_d[ok.BRW][maya.super_maya.filler_k]
    j = Run.j
    cast_z = maya.cast.matter

    # Add a pattern layer towards the top of the Maya's group layer, 'z'.
    z = add_layer(j, "Material", maya.group, get_light(maya))

    make_pattern_frame_sel(j, cast_z, d, _draw)
    return do_emboss_sel(z, d)


def do_emboss_sel(z, d):
    """
    Fill a selection with grey color and emboss it.

    z: layer
        to fill
        WIP

    d: dict
        Wrap-type Preset

    Return: layer
        frame
    """
    j = Run.j

    set_fill_context_default()

    if d[ok.EMBOSS]:
        n = z.name
        sel = pdb.gimp_selection_save(j)

        color_selection(z, d[ok.COLOR_1])

        z1 = add_layer_above(z, "Outside")
        z2 = add_layer_above(z1, "Emboss")

        color_selection(z2, (190, 190, 190))
        pdb.gimp_selection_none(j)
        color_layer(z1, (65, 65, 65))

        z1 = pdb.gimp_image_merge_down(j, z2, CLIP_TO_IMAGE)

        blur(z1, d[ok.PRE_BLUR])
        emboss(z1, Globe.azimuth, Globe.elevation, int(d[ok.DEPTH]))
        blur(z1, d[ok.POST_BLUR])

        z1.mode = get_mode(d, k=ok.EMBOSS_MODE)
        z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
        z.name = n

        # brightness, '0'
        if d[ok.CONTRAST]:
            pdb.gimp_brightness_contrast(z, 0, int(d[ok.CONTRAST]))

        isolate_selection(z, sel)
        pdb.gimp_image_remove_channel(j, sel)
        clip_to_wip(z)

    else:
        color_selection(z, d[ok.COLOR_1])
    return z


def do_selection(maya, do_sel, embellish, n, is_clear=True):
    """
    Process the material for a frame.

    maya: Maya
    do_sel: function
        Process main cast selection on a per basis,
        or from a Maya having a key (e.g. Canvas branch).

    embellish: function
        Process the material layer.

    n: string
        layer name appendix
        Frame kind
        Prefix with a space character.

    is_clear: bool
        If True, then the cast's alpha selection
        is removed from the output layer.

    Return: layer or None
        frame
    """
    j = Run.j
    model = maya.model
    super_ = maya.cast
    cast = super_.matter
    z = add_layer(j, n, maya.group, get_light(maya))

    # Check to see if the caller is a grid, 'main_q'.
    if hasattr(super_, 'main_q'):
        for k in super_.main_q:
            maya.k = k
            sel = model.get_image_sel(k)

            load_selection(j, sel)

            if cast.mask:
                pdb.gimp_image_select_item(
                    j, CHANNEL_OP_INTERSECT, cast.mask
                )
            if not pdb.gimp_selection_is_empty(j):
                z = do_sel(maya, z)

    else:
        maya.k = super_.k

        select_item(cast)
        if not pdb.gimp_selection_is_empty(j):
            z = do_sel(maya, z)

    if is_clear:
        select_item(cast)
        clear_selection(z)

    z = verify_layer(z)

    if z:
        z = embellish(maya, z)
        z.name = z.parent.name + " " + n
        clip_to_wip(z)
    return z


def grow_wrap(j, w, n):
    """
    Expand a Wrap selection depending on the Wrap/Type.

    j: GIMP image
        Has selection.

    w: float
        expansion amount

    n: string
        Wrap Type
    """
    def _angular():
        pdb.gimp_context_set_antialias(0)
        for _ in range(int(w)):
            pdb.gimp_selection_grow(j, 1)

    def _rectangle():
        _is_sel, _x, _y, _x1, _y1 = get_select_bounds(j)
        if _is_sel:
            _x -= w
            _y -= w
            _w = _x1 + w - _x
            _h = _y1 + w - _y
            select_rect(j, _x, _y, _w, _h)

    def _rounded():
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_selection_grow(j, int(w))

    {ff.ANGULAR: _angular, ff.RECTANGLE: _rectangle, ff.ROUNDED: _rounded}[n]()


def make_canvas_frame_sel(maya, d):
    """
    Make a selection border around the render.

    maya: Maya
        Has a 'model' attribute.

    d: dict
        a Frame-type Preset

    Return: GIMP selection or None, state of selection
        canvas border
    """
    w = d[ok.CFW]
    if w:
        j = Run.j
        x, y, w1, h = maya.model.canvas_rect
        select_rect(j, x, y, w1, h)
        select_rect(
            j,
            x + w, y + w,
            w1 - w - w, h - w - w,
            option=CHANNEL_OP_SUBTRACT
        )
        return pdb.gimp_selection_save(j)


def make_pattern_frame_sel(j, z, d, p):
    """
    Make a selection for frame material.

    j: GIMP image
        Has frame.

    z: layer
        Maya matter

    d: dict
        Frame-type Preset

    p: function
        Make the pattern.

    Return: state of selection
    """
    select_item(z)
    grow_wrap(j, d[ok.WIDTH], d[ok.TYPE])

    sel = pdb.gimp_selection_save(j)

    grow_wrap(j, d[ok.FILLER_W], d[ok.TYPE])

    sel1 = pdb.gimp_selection_save(j)

    grow_wrap(j, d[ok.WIDTH], d[ok.TYPE])

    sel2 = pdb.gimp_selection_save(j)

    load_selection(j, sel1, option=CHANNEL_OP_SUBTRACT)

    # outer selection, 'sel3'
    sel3 = pdb.gimp_selection_save(j)

    z1 = p(z)

    load_selection(j, sel1)
    load_selection(j, sel, option=CHANNEL_OP_SUBTRACT)
    select_item(z1, option=CHANNEL_OP_INTERSECT)
    remove_z(z1)

    # Filler selection, 'sel4'
    sel4 = pdb.gimp_selection_save(j)

    # Make an inner Wrap selection.
    load_selection(j, sel)
    select_item(z, option=CHANNEL_OP_SUBTRACT)

    # Combine selections.
    load_selection(j, sel3, option=CHANNEL_OP_ADD)
    load_selection(j, sel4, option=CHANNEL_OP_ADD)
    for i in (sel, sel1, sel2, sel3, sel4):
        pdb.gimp_image_remove_channel(j, i)


def make_filler_frame_sel(maya, j, d):
    """
    Make a selection for a frame having Filler material.

    j: GIMP image
        view output

    d: dict
        Wrap Preset

    Return: GIMP selection channel and GIMP's state of selection
    """
    z = maya.cast.matter

    select_item(z)
    grow_wrap(j, d[ok.WIDTH], d[ok.TYPE])

    sel = pdb.gimp_selection_save(j)

    grow_wrap(j, d[ok.FILLER_W], d[ok.TYPE])

    sel1 = pdb.gimp_selection_save(j)

    grow_wrap(j, d[ok.WIDTH], d[ok.TYPE])

    sel2 = pdb.gimp_selection_save(j)

    load_selection(j, sel1, option=CHANNEL_OP_SUBTRACT)

    # outer selection, 'sel3'
    sel3 = pdb.gimp_selection_save(j)

    load_selection(j, sel1)
    load_selection(j, sel, option=CHANNEL_OP_SUBTRACT)

    # Filler selection, 'sel4'
    sel4 = pdb.gimp_selection_save(j)

    # Make an inner Wrap selection.
    load_selection(j, sel)
    select_item(z, option=CHANNEL_OP_SUBTRACT)

    # Combine selections.
    load_selection(j, sel3, option=CHANNEL_OP_ADD)
    load_selection(j, sel4, option=CHANNEL_OP_SUBTRACT)

    for i in (sel, sel1, sel2, sel3):
        pdb.gimp_image_remove_channel(j, i)
    return sel4


def mask_filler_layer(j, filler, sel):
    """
    Mask a Filler matter from a selection created by a frame.

    j: GIMP image
        Receive selection.

    filler: Filler
        Has Filler and group layer.

    sel: GIMP selection
        Apply to the layer.
    """
    if sel:
        load_selection(j, sel)
        mask_sel(filler.matter)


def remove_sel(maya, n):
    """
    Remove a stored selection for a Maya.

    maya: Maya
    n: string
        Is the selection's attribute descriptor.
    """
    a = getattr(maya, n)
    if a:
        pdb.gimp_image_remove_channel(Run.j, a)
        setattr(maya, n, None)


def select_wrap(j, z, w, n, is_cut=True):
    """
    Make a Wrap selection around a layer's alpha.

    j: GIMP image
        Has selection.

    z: layer
        Surround material with Wrap.

    w: float
        Expand selection.

    n: string
        Wrap/Type

    is_cut: bool
        If True, then the layer's selection
        is removed from the frame selection.
    """
    f = z.opacity
    z.opacity = 100.

    select_item(z)
    grow_wrap(j, w, n)

    if is_cut:
        select_item(z, option=CHANNEL_OP_SUBTRACT)
    z.opacity = f


def sort_shadow_layer(maya, m, offset, z):
    """
    Sort Shadow layer inside a Shadow layer group.

    maya: Maya
        Has Shadow sub-maya.

    m: bool
        If True then sort the Shadow layers.

    offset: int
        Inner Shadow position

    z: layer
        Cast Shadow.
    """
    if m:
        # Move and sort Shadow layer to the group layer.
        # This is the layer order in the layer group:
        #    Shadow #2
        #    Shadow #1
        j = Run.j
        a = pdb.gimp_image_get_item_position(j, z) + 1
        e = maya.sub_maya[sm.SHADOW].sub_maya
        z1 = z.parent

        # an ordered list of Shadow 'matter' layer, 'q'
        q = [e[i].matter for i in (sm.SHADOW2, sm.SHADOW1)]

        for i in q:
            a += move_layer(j, i, z1, a)

        z = maya.sub_maya[sm.SHADOW].sub_maya[sm.INNER].matter
        if z:
            move_layer(j, z, z1, offset)


class ShadowBasic(SubBuild):
    """Manage a shadow layer."""
    issue_q = 'matter',
    put = (check_matter, 'matter'),

    def __init__(self, any_group, super_maya, k_path):
        """
        super_maya: Maya
            Is the enclosing Maya.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, do_cast_shadow)

    def do(self, d, is_change):
        """
        Manage layer output.

        d: dict
            Frame-type Preset

        Return: bool
            Is True when the Shadow has change.
        """
        is_back = Run.is_back
        self.value_d = d
        self.is_matter |= is_change

        self.realize()

        if self.is_matter:
            z = self.super_maya.matter
            pdb.gimp_image_reorder_item(
                Run.j, self.matter, z.parent, get_layer_position(z) + 1
            )

        self.reset_issue()
        return is_back != Run.is_back
