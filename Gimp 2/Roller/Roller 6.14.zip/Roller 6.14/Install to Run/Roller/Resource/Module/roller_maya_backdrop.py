#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import PlanZ, Run
from roller_constant_for import Deco as dc, Plan as fy, Signal as si
from roller_constant_key import Option as ok, SubMaya as sm
from roller_fu import make_layer_group, select_rect
from roller_image_grind import ref_on_group_change
from roller_maya import Maya, Main
from roller_maya_layer import check_matter
from roller_maya_backing import Backing, make_backing_layer
from roller_one_wip import Wip
from roller_option_group import ManyGroup
from roller_view_hub import color_selection_default
from roller_view_option_list import BackdropStyle

"""
Define 'backdrop/backdrop' as a Maya-subtype
for managing the backdrop group output.
"""


def check_plan_group(maya):
    """
    Create a Plan layer group.

    maya: Plan
    Return: layer group
        Parent Plan output.
    """
    if not maya.group:
        return make_plan_backdrop_group()
    return maya.group


def do_plan_matter(maya):
    """
    Create a Plan Backdrop layer.

    maya: Plan
    Return: matter layer
        Simulate a Backing layer.
    """
    z = make_backing_layer(maya)

    select_rect(Run.j, *Wip.get_rect())
    color_selection_default(z, fy.BACKGROUND_COLOR)
    return z


def make_plan_backdrop_group():
    """
    Make a Plan Backdrop group.

    Return: layer group
        Backdrop simulation group
    """
    return make_layer_group(Run.j, "Backdrop", PlanZ.plan_group, 0)


class Backdrop(ManyGroup):
    """
    Create Widget group and assign a Backdrop
    step processor for view run type.
    """
    image_slot_count = 1
    image_k_path = ok.BACKING,

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)
        self.latch(self, (si.GROUP_CHANGE, ref_on_group_change))

    @staticmethod
    def get_image_d(d):
        """
        Return the Image Choice Preset if its use.

        d: dict
            Backdrop Preset
        """
        if d[ok.BACKING][ok.SWITCH]:
            if d[ok.BACKING][ok.TYPE] == dc.IMAGE:
                e = d[ok.BACKING][ok.IMAGE_CHOICE]
                if e[ok.SWITCH]:
                    return e

    @staticmethod
    def get_keys():
        """Return a list of image reference key."""
        return [None]


class Chi(Maya, Main):
    """Factor Plan and Work."""
    issue_q = 'matter',

    def __init__(self, any_group, view_i, q):
        """
        any_group: AnyGroup
            Backdrop option group

        view_i: int
            Plan or Work; 0 or 1

        q: iterable
            layer output function
            the Maya's 'put' attribute
        """
        Maya.__init__(self, any_group, view_i, q, ())
        Main.__init__(self)
        self.set_issue()


class Plan(Chi):
    """Manage the Backdrop layer output for Draft and Plan."""
    put = (check_plan_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, Plan.put)
        self.do_matter = do_plan_matter

    def do(self):
        """
        Manage Backdrop output during a view run.

        Return: None
            for undo
        """
        self.realize_vote()


class Work(Chi):
    """
    Manage the Backdrop layer output for Peek, Preview and the final render.
    """
    put = ()

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Has options.
        """
        Chi.__init__(self, any_group, 1, Work.put)

        cast_maya = self.sub_maya[sm.BACKING] = Backing(any_group)
        self.sub_maya[sm.BACKDROP_STYLE] = BackdropStyle(
            any_group, cast_maya, (ok.BACKDROP_STYLE,)
        )

    def do(self):
        """Manage Backdrop layer during a view run."""
        d = self.value_d
        backing = self.sub_maya[sm.BACKING]

        # Is Backing Maya change boolean state, 'm'.
        m = backing.do(d[ok.BACKING])

        self.sub_maya[sm.BACKDROP_STYLE].do(
            d[ok.BACKDROP_STYLE], m, backing.matter
        )
