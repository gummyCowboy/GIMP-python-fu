#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import radians
from random import randrange
from roller_a_contain import Run
from roller_constant_for import Backdrop as bs
from roller_constant_key import Option as ok, Step as sk, SubMaya as sm
from roller_fu import merge_layer_group, remove_z, select_polygon
from roller_maya_shadow import Shadow
from roller_maya_style import Style
from roller_one_wip import Wip
from roller_view_hub import (
    calc_gradient,
    color_selection,
    do_mod,
    get_mean_color,
    set_fill_context_default
)
from roller_view_preset import combine_seed
from roller_view_real import (
    add_sub_base_group,
    add_wip_layer,
    clip_to_wip,
    get_point_on_edge,
    insert_copy
)
from roller_view_shadow import make_shadow, make_shadow_inner

"""
Define 'backdrop/floor_sample' as a Maya-subtype
for managing a variation of backdrop style layer.
"""

LEFT, TOP, RIGHT, BOTTOM = range(4)


def exit_mean_color(z):
    """
    z: layer
        background copy
    """
    remove_z(z)


def fetch_mean_color(_, z):
    """
    _: int
        0..n
        wedge sequence

    z: layer
        background copy

    Return: tuple
        RGB
    """
    return get_mean_color(z)


def get_next_color(ray, start_color, step_q):
    """
    ray: int
        0..n
        wedge sequence

    start_color: tuple
        RGBA

    step_q: list
        [float,  float, float, float]
        Add float to the start color component.

    Return: tuple
        RGBA
    """
    if ray:
        # Calculate the next polygon color.
        color = ()
        for i in range(4):
            b = step_q[i] * ray
            color += (start_color[i] + int(b),)

    else:
        color = start_color
    return color


def get_random_color(*_):
    """
    Return: tuple
        RGB
    """
    return tuple([randrange(256) for _ in range(3)])


def init_color(_, d):
    """
    _: group layer
        not used

    d: dict
        Floor Sample Preset

    Return: tuple
        (start color, color step list for RGBA)
        color step list -> [float, float, float, float]
    """
    a, b = d[ok.COLOR_2A]
    return a, calc_gradient(a, b, int(d[ok.SLICE_COUNT]))


def init_mean_color(group, _):
    """
    group: group layer
        Copy its background.

    _: dict
        Floor Sample Preset

    Return: tuple
        (background copy layer,)
    """
    return (insert_copy(group, group, is_hide=True),)


EXIT_TYPE = {
    bs.COLOR: lambda *_: None,
    bs.MEAN_COLOR: exit_mean_color,
    bs.RANDOM_COLOR: lambda *_: None
}
GET_COLOR = {
    bs.COLOR: get_next_color,
    bs.MEAN_COLOR: fetch_mean_color,
    bs.RANDOM_COLOR: get_random_color
}
INIT_TYPE = {
    bs.COLOR: init_color,
    bs.MEAN_COLOR: init_mean_color,
    bs.RANDOM_COLOR: lambda *_: ()
}


def do_shadow_preset(d, outer_cast_q, inner_cast_z, parent):
    """
    Make up to three shadow layers.

    d: dict
        Shadow SuperPreset

    outer_cast_q: tuple
        (layer, ...)
        Pass to Shadow #1 and Shadow #2.

    inner_cast_z: layer
        Cast an inner shadow.

    parent: layer group
        Where the shadow layer is placed.
    """
    make_shadow(
        d[sk.SHADOW_1],
        parent,
        outer_cast_q,
        name=parent.name + " Shadow 1"
    )
    make_shadow(
        d[sk.SHADOW_2],
        parent,
        outer_cast_q,
        name=parent.name + " Shadow 2"
    )
    make_shadow_inner(
        d[sk.INNER_SHADOW],
        parent,
        inner_cast_z,
        name=parent.name + " Inner Shadow"
    )


def make_style(maya):
    """
    Draw a fan of wedges colored by one color transiting to another.

    maya: Style
    Return: layer or None
        Floor Sample material
    """
    def _get_side(_x, _y):
        """
        Determine the side that a vector intersects.

        _x, _y: float
            point on the rectangle bounds

        Return: int
            index to the side the vector intersects
        """
        if _x >= right_x and _y < bottom_y:
            return RIGHT

        if _y >= bottom_y and _x > left_x:
            return BOTTOM

        if _x <= left_x and _y > top_y:
            return LEFT
        return TOP

    j = Run.j
    d = maya.value_d
    n = d[ok.TYPE]
    shadow_d = d[ok.RW1][ok.SHADOW]
    has_shadow = shadow_d[sk.SHADOW_SWITCH][ok.SWITCH]

    combine_seed(d)
    set_fill_context_default()

    angle = radians(360. / d[ok.SLICE_COUNT])
    slice_cnt = int(d[ok.SLICE_COUNT])
    left_x, top_y, w, h = Wip.get_rect()
    right_x = w + left_x
    bottom_y = h + top_y
    center_x, center_y = Wip.center()
    start_angle = radians(d[ok.ANGLE])
    group = add_sub_base_group(maya)
    type_arg = INIT_TYPE[n](group, d)

    # Index by side. The order is TOP, RIGHT, BOTTOM, LEFT.
    corner_q = (
        (left_x, top_y),
        (right_x, top_y),
        (right_x, bottom_y),
        (left_x, bottom_y)
    )

    # Collect vector rectangle intersect.
    # intersect
    q_x = []
    q_y = []

    for _ in range(slice_cnt):
        x, y = get_point_on_edge(start_angle)
        q_x += [x]
        q_y += [y]
        start_angle += angle

    # Add repeating start vector to simplify the final polygon arrangement.
    q_x += [q_x[0]]
    q_y += [q_y[0]]

    # Assemble and draw color filled polygon.
    for ray_i in range(slice_cnt):
        # The variables 'side 1' and 'side 2'
        # are the sides of the image-rectangle
        # that the arc begins and ends.
        # line 1
        x, y = q_x[ray_i], q_y[ray_i]
        q = center_x, center_y, x, y
        side_1 = _get_side(x, y)

        # line 2
        x1, y1 = q_x[ray_i + 1], q_y[ray_i + 1]
        side_2 = _get_side(x1, y1)

        if side_1 != side_2:
            # Add corner points to the polygon.
            side_x = side_1
            for _ in range(4):
                # Add a corner point.
                q += corner_q[side_x]

                if side_x == side_2:
                    break

                side_x += 1
                if side_x > BOTTOM:
                    side_x = 0

        q += x1, y1

        select_polygon(j, q)

        z = add_wip_layer("Edge", group)

        color_selection(z, GET_COLOR[n](ray_i, *type_arg))
        if has_shadow:
            do_shadow_preset(shadow_d, (z,), z, group)

    EXIT_TYPE[n](*type_arg)

    z = merge_layer_group(group)

    clip_to_wip(z)
    do_mod(z, d[ok.RW1][ok.MOD])
    return maya.rename_layer(z)


class FloorSample(Style):
    """Create Backdrop Style output."""
    dependency = bs.DEPENDENT

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Has the Backdrop Style Button.

        super_maya: Backdrop Maya
        k_path: tuple
            Is the key path to the Backdrop Style
            Button in the AnyGroup's vote dict.
        """
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.RW1, ok.SHADOW),
                k_path + (ok.RW1, ok.MOD),
                k_path + (ok.RW1, ok.MOD, ok.BLUR_D)
            ],
            make_style
        )
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group, self, (self,), k_path + (ok.RW1, ok.SHADOW)
        )

    def do(self, z, d, is_change):
        """
        Produce or modify layer output. Override Style's function.

        z: layer
            Backing output
            not used

        d: dict
            Backdrop Style Preset

        is_change: bool
            not used
            Is the state of the super Maya's matter and/or mask.
            Floor Sample is independent of the Backing layer.
        """
        self.value_d = d
        is_draw = is_change if d[ok.TYPE] == bs.MEAN_COLOR else False
        self.is_matter |= (is_draw or self.sub_maya[sm.SHADOW].get_any_vote())

        self.realize()
        self.sub_maya[sm.ADD].do(
            d[ok.BRW][ok.ADD_ALT], self.is_matter, self.is_matter, is_change
        )
        self.sub_maya[sm.SHADOW].reset_all_issue()
        self.reset_issue()
