#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Facing:
    """
    A Face or Facing navigation branch has a 'map' dict
    for recalling a Facing's configuration.
    """

    def __init__(self):
        # Each Face or Facing in the Model has its own Map.
        # {(row, column, face): Map}
        self.map_d = None

    def get_facing_foam(self, k):
        """
        Return: tuple
            a transform perspective format
        """
        return self.map_d[k].foam

    def get_facing_form(self, k):
        """
        Return: tuple
            Is a cell rectangle in polygon selection form.
            an x, y series of eight coordinates
            Ordered by points, (topleft, top-right, bottom-right, bottom-left).
        """
        return self.map_d[k].form

    def get_facing_merged(self, k):
        """
        Return tuple
            Is the facing rectangle. Is a
            scaled up version of the cell rectangle
            and is used by the transform perspective function.
            four float values
            (x, y, width, height)
        """
        return self.map_d[k].merged.rect

    def get_facing_rect(self, k):
        """See 'get_facing_merged'."""
        return self.map_d[k].merged.rect

    def get_facing_shape(self, k):
        """
        Retrieve a GIMP polygon of the Facing's shape.

        The points are arranged from the
        (left-most, top) in a clockwise direction.
         """
        return self.map_d[k].shape

    def get_facing_transform(self, k):
        """
        Return: function
        """
        return self.map_d[k].transform
