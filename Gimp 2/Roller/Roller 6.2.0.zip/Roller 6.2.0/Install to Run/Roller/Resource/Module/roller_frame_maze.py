#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD,
    CHANNEL_OP_INTERSECT,
    CHANNEL_OP_REPLACE,
    CHANNEL_OP_SUBTRACT,
    pdb
)
from roller_a_contain import Globe, Run
from roller_constant_key import Material as ma, Option as ok
from roller_frame import (
    make_canvas_frame_sel, do_emboss_sel, select_wrap
)
from roller_frame_alt import FrameBasic
from roller_fu import (
    add_layer,
    load_selection,
    select_rect,
    select_z,
    verify_layer
)
from roller_view_hub import set_gimp_brush
from roller_view_real import get_light

"""
Define 'frame_maze' as a Maya-subtype
for managing a variation of Frame type.
"""


def do_matter(maya):
    """
    Make the frame.

    maya: Maze/Wrap
    Return: layer
        Wrap 'matter'
    """
    j = Run.j
    d = maya.value_d
    e = maya.super_maya.value_d[ok.BRW][ok.FILLER_MA]
    x, y, w, h = maya.model.canvas_rect
    cast_z = maya.cast.matter

    select_wrap(j, cast_z, d[ok.WIDTH], d[ok.TYPE])

    wrap_sel = pdb.gimp_selection_save(j)

    # Canvas frame
    pdb.gimp_selection_none(j)
    make_canvas_frame_sel(maya, cast_z, e)

    canvas_frame_sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)

    # layer for the maze, 'z'
    z = add_layer(j, None, 0, "Maze")
    z1 = add_layer(j, None, 0, "Material")

    pdb.gimp_context_set_foreground((0, 0, 0))
    pdb.gimp_context_set_background((255, 255, 255))
    pdb.plug_in_maze(
        j, z,
        int(max(1, w // e[ok.COLUMN])),     # passage scale
        int(max(1, h // e[ok.ROW])),        # passage scale
        1,                                      # yes, tileable
        0,                                      # depth first algorithm
        int(e[ok.SEED] + Globe.seed),
        0,                                      # multiple, not clearly defined
        0                                       # offset, not clearly defined
    )

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)
    do_stroke(z1, e[ok.LINE_W])
    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z1)

    if e[ok.CLIP]:
        select_z(cast_z, option=CHANNEL_OP_SUBTRACT)

    for i in (z, z1):
        pdb.gimp_image_remove_layer(j, i)

    # layer for the combined frame, 'z'
    z = add_layer(j, maya.group, get_light(maya), "Material")

    for i in (wrap_sel, canvas_frame_sel):
        load_selection(j, i, option=CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, i)

    # Clip selection to canvas.
    select_rect(Run.j, x, y, w, h, option=CHANNEL_OP_INTERSECT)

    return verify_layer(do_emboss_sel(z, d))


def do_stroke(z, w):
    """
    Stoke the maze selection.

    z: layer
        Receive stroke material.

    w: float
        Is the width of the brush stroke.
    """
    set_gimp_brush("C_Normal Brush 80")
    pdb.gimp_context_set_antialias(0)
    pdb.gimp_context_set_brush_angle(.0)
    pdb.gimp_context_set_brush_hardness(1.)
    pdb.gimp_context_set_brush_size(w)
    pdb.gimp_context_set_foreground((0, 0, 0))
    pdb.gimp_context_set_opacity(100.)
    pdb.gimp_drawable_edit_stroke_selection(z)


class Maze(FrameBasic):
    filler_k = ok.FILLER_MA
    kind = material = ma.MAZE
    wrap_k = ok.WRAP_CA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
