#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_key import Option as ok
from roller_fu import make_layer_group, set_layer_attr, set_layer_mode
from roller_fu_mode import translate_mode
from roller_view_real import remove_maya_z

"""
Define 'maya_layer' as a function collection
that check and make layer during a view run.
"""


def check_layer(maya, n, p):
    """
    Make a new layer and remove its old layer counterpart,
    if it exists. The layer is assumed to need an update.

    maya: Maya

    n: string
        Maya's layer attribute descriptor

    p: function
        Call to make layer output.

    Return: layer or None
        material
    """
    z = getattr(maya, n)

    if z:
        remove_maya_z(maya, n)
        Run.is_back = True

    z = p(maya)

    if z:
        Run.is_back = True
    return z


def check_matter(maya):
    """
    Act on matter issue change.

    maya: Maya
    Return: layer or None
        material
    """
    if maya.is_matter:
        return check_layer(maya, 'matter', maya.do_matter)
    return maya.matter


def check_mix(maya, issue, mode, opacity):
    """
    Determine a layer's Mode or Opacity change.

    maya: Maya
    issue: string
        Maya sub-attribute
        The string is prefix with 'is_' to create an attribute id.

    mode: string
        GIMP Mode descriptor
        Is the layer's desired Mode.

    opacity: float
        Is the layer's desired opacity.
    """
    z = maya.matter
    if z:
        if getattr(maya, 'is_' + issue):
            m = set_layer_attr(z, translate_mode(mode), opacity)
            Run.is_back |= m
        else:
            if maya.is_mode:
                m = set_layer_mode(z, translate_mode(mode))
                Run.is_back |= m
            if maya.is_opacity:
                if z.opacity != opacity:
                    z.opacity = opacity
                    Run.is_back = True


def check_mix_basic(maya):
    """
    Determine the matter layer's mode or opacity change.

    maya: Maya
    """
    d = maya.value_d
    check_mix(maya, 'matter', d[ok.MODE], d[ok.OPACITY])


def make_group_brush(maya):
    """
    Make a Brush layer group. Is a
    sub-group of the super maya's layer group.

    maya: Maya
    Return: layer group
        Brush parent
    """
    return make_group_sub(maya, maya.super_maya.kind + " Brush")


def make_group_filler(maya):
    """
    Make a Filler layer group. Is
    a sub-group of the super Maya's layer group.

    maya: Maya
    Return: layer group
        Filler parent
    """
    return make_group_sub(maya, maya.super_maya.kind + " Filler")


def make_group_overlay(maya):
    """
    Make an Overlay layer group. Is
    a sub-group of the super Maya's layer group.

    maya: Maya
    Return: layer group
        Overlay parent
    """
    return make_group_sub(maya, maya.super_maya.kind + " Overlay")


def make_group_sub(maya, n):
    """
    Make a layer group. Is a sub-group of the super Maya's layer group.

    maya: Maya
    n: string
        group name appendix

    Return: layer group
        parent for material
    """
    parent = maya.cast.group.parent
    group = maya.group

    if not group:
        return make_layer_group(Run.j, parent, 0, n)
    return group


def make_group_wrap(maya):
    """
    Make a Wrap layer group. Is a
    sub-group of the super maya's layer group.

    maya: Maya
    Return: layer group
        Wrap parent
    """
    return make_group_sub(maya, maya.super_maya.kind + " Wrap")
