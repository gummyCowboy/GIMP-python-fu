#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_a_contain import Dog
from roller_constant_for import Color as co, Widget as fw
from roller_constant_key import Option as ok, Widget as wk
from roller_one import make_2d_table
from roller_one_tip import Tip
from roller_one_wip import Wip
from roller_port import Port
from roller_option_squish import make_tooltip
from roller_widget_box import Box as boxer, Eventful
from roller_widget_colorful_button import (
    ColorfulButton, PerCellButton, SwitchButton
)
from roller_widget_label import Label
from roller_widget_node import Dust
from roller_port_editor import PortCellEditor, PortFaceEditor
import gtk  # type: ignore

# cell padding
PAD = 1
PADDING = [PAD, PAD, PAD, PAD]
H_PAD = [0, 0, PAD, PAD]
V_PAD = [PAD, PAD, 0, 0]

NO_CELL = " Is not a cell. "
HEADER_COLOR = co.HEADER_COLOR
TITLE = "Cell Grid: Try escape, enter, space-bar to cancel, save, edit."


def calc_bottom_right(gum):
    """
    Return the row and column for the bottom-right cell of a merge-cell group.

    gum: Gum
        from a topleft cell
    """
    return gum.r + gum.s[0] - 1, gum.c + gum.s[1] - 1


def is_outside(gum, r, c, s):
    """
    Determine if a cell has cells that exist outside the bounds of a rectangle.

    gum: Gum
        Has cell data.

    r, c: int
        row, column

    s: tuple (w, h)
        cell block bounds in cell count

    Return: flag
        Is True if the cell is or its group has
        cells outside of the cell block rectangle.
    """
    if gum.r < r or \
            gum.c < c or \
            gum.r + gum.s[0] > r + s[0] or \
            gum.c + gum.s[1] > c + s[1]:
        return 1


def set_sub_top(a, b):
    """
    Modify a cell's Gum to identify the cell as being sub-topleft.

    a: Gum
        the topleft cell

    b: Gum
        the sub-topleft cell
    """
    b.topleft = a

    # Indicate that the cell has been merged and is
    # dependent on the topleft cell, '-1, -1'.
    b.s = -1, -1


class PortPer(Port):
    """Draw a table of cell(s) reflecting a Per value."""
    window_key = "Cell Grid"

    def __init__(self, d, g):
        """
        d: dict
            Has keyword argument.

        g: PerGroup
            Is responsible.
        """
        for i in d.keys():
            setattr(self, i, d[i])

        self.row_label = self.column_label = None
        self._split_cells = False
        self.on_per_cell_cancel = d[wk.ON_CANCEL]
        self.on_per_cell_accept = d[wk.ON_ACCEPT]
        self.model = g.any_group.item.model
        self.group_key = g.any_group.item.key
        self._per_d = deepcopy(g.get_a())
        r, c = self.grid = self.model.grid
        self._table_grid = r * 2, c * 2

        # Use to determine if the Cell Editor has modified a cell.
        # A Per Preset has no Per Preset value.
        self.main_edit_d = deepcopy(g.any_group.value_d)
        self.main_edit_d[ok.PER] = {}

        # Calculate the cell's display size.
        w = max(r, c)
        self._more = max(5, w)

        if w < 10:
            size = 500 // w

        elif w < 15:
            size = 50

        else:
            size = 25

        self.cell_height = size
        self.cell_table_group = Dog.none_group(**{
            wk.ITEM: Dust(key=self.group_key, model=self.model)
        })

        d.update({
            wk.ON_ACCEPT: self.on_accept_cell_table,
            wk.ON_CANCEL: self.on_cancel_cell_table
        })

    def draw_column_header(self, c, c1):
        """
        Draw a column header.

        c: int
            cell table column

        c1: int
            display column
        """
        # column header
        g = Eventful(HEADER_COLOR)
        g1 = gtk.Frame()

        if c % 2:
            g2 = self.col_label = Label(align=(0, 0, 1, 1), text=str(c1))
            g1.add(g2)

        g.add(g1)
        return g

    def draw_row_header(self, r, r1):
        """
        Draw the row header.

        r: int
            table row

        r1: int
            row number
        """
        # row header
        g = Eventful(HEADER_COLOR)
        g1 = gtk.Frame()

        if r % 2:
            g2 = self.row_label = Label(align=(0, 0, 1, 1), text=str(r1))
            g1.add(g2)

        g.add(g1)
        return g

    def init_table(self, is_table):
        """
        Initialize data needed to draw the cell table.

        is_table: bool
            Is True if PortPerMerge is calling.
        """
        row, column = self.grid

        # A cell corresponds with its Gum instance.
        self.gum_table = make_2d_table(row, column)

        # Load the cell dimension.
        for r in range(row):
            for c in range(column):
                if is_table:
                    s = self._per_d[(r, c)]

                else:
                    s = 1, 1
                self.gum_table[r][c] = Gum(
                    s, r, c, (r, c) in self.model.cell_q
                )

        # Initialize the 'topleft' reference.
        for r in range(row):
            for c in range(column):
                gum = self.gum_table[r][c]
                if gum.is_topleft:
                    # Initialize the sub-topleft cell.
                    for r1 in range(r, r + gum.s[0]):
                        for c1 in range(c, c + gum.s[1]):
                            if r1 != r or c1 != c:
                                a = self.gum_table[r1][c1]
                                a.topleft = gum

    def get_group_value(self):
        """
        Call before doing a cancel-able view.

        Return: list
            cell table
        """
        return deepcopy(self._per_d)

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return self.on_cancel_cell_table, self.on_accept_cell_table

    def get_symbol(self, d, r, c):
        """
        Get the symbol for a display Box.

        d: dict
            Preset from 'per_d'

        r, c: int
            Is the cell index of the Box.

        Return: string
            Represent the state of the cell. Is it a cell or not?
        """
        if self.gum_table[r][c].is_cell and d:
            # Has Preset.
            return "❑"
        else:
            # Is a main cell with no Per Preset.
            return "…"

    def get_topleft(self, gum=None, u=None):
        """
        A topleft cell is the cell located at the topleft
        corner of a cell block. Sub-topleft cells refer
        to the topleft cell through Gum's 'topleft' attribute.

        gum: Gum
            Has cell data.

        u: tuple
            row, column

        Return: Gum
            a topleft cell
        """
        if u:
            gum = self.gum_table[u[0]][u[1]]

        if gum.s[0] < 0:
            gum1 = gum.topleft
            v = gum1.r, gum1.c

        else:
            v = gum.r, gum.c
        return self.gum_table[v[0]][v[1]]

    def on_accept_cell_table(self, *_):
        """Accept the cell table."""
        self.on_per_cell_accept(self._per_d)

    def on_cancel_cell_table(self, *_):
        """
        Close the Port and return the Per dict to its original state.
        """
        self.on_per_cell_cancel()

    def set_cell_face(self, gum, start, end, is_table=True):
        """
        Set a cell's appearance.

        gum: Gum
            Has cell data.

        start: tuple
            (r, c); topleft cell index

        end: tuple
            (r, c); bottom-right cell index
        """
        if gum.s == (1, 1):
            self.set_single_looks(gum)

        else:
            # The cell is a member of a group.
            #
            # cell neighbor flags
            top = gum.r > start[0]
            bottom = gum.r < end[0]
            left = gum.c > start[1]
            right = gum.c < end[1]

            # top, bottom, left, right
            w = [PAD, PAD, PAD, PAD]

            for i, a in enumerate((top, bottom, left, right)):
                if a:
                    w[i] = 0

            gum.pad_box.set_padding(*w)

            # button updates
            if gum.left_button:
                g = gum.left_button

                if left:
                    w = V_PAD[:]
                    for i, a in enumerate((top, bottom)):
                        if a:
                            w[i] = 0

                    g.pad.set_padding(*w)
                    g.set_label(" - ")
                    g.gate = 1
                else:
                    g.set_label(" + ")
                    g.pad.set_padding(*V_PAD)
                    g.gate = 0
            if gum.top_button:
                g = gum.top_button

                if top:
                    w = H_PAD[:]

                    for i, a in enumerate((left, right)):
                        if a:
                            w[i + 2] = 0

                    g.pad.set_padding(*w)
                    g.set_label(" - ")
                    g.gate = 1
                else:
                    g.set_label(" + ")
                    g.pad.set_padding(*H_PAD)
                    g.gate = 0
        if is_table:
            self._update_cell_tooltip(gum)

    def set_single_looks(self, gum):
        """
        Change the appearance of a cell's frame to appear independent.
        If the cell is changing because of a split cells
        operation, then update the cell's SwitchButtons.

        gum: Gum
            Has cell values.
        """
        gum.pad_box.set_padding(*PADDING)
        if self._split_cells:
            for g in (gum.left_button, gum.top_button):
                if g:
                    g.set_label(" + ")

                    g.gate = 0

                    if g == gum.left_button:
                        g.pad.set_padding(*V_PAD)
                    else:
                        g.pad.set_padding(*H_PAD)


class PortPerCell(PortPer):
    """Display a Cell/.../Per table for cell level Preset access."""

    def __init__(self, d, g, is_face=False):
        """
        d: dict
            Has keyword argument.

        g: PerGroupCell
            Is responsible.

        is_face: bool
            Is True if Face is calling.
        """
        # Use to return focus to the responsible
        # Button after a dialog close, 'self.widget'.
        self.widget = None

        self.r_c = 0, 0
        self._is_face = is_face
        self.dialog = PortFaceEditor if self._is_face else PortCellEditor

        PortPer.__init__(self, d, g)
        self.init_table(False)
        Port.__init__(self, d, g)
        self.roller_win.gtk_win.set_title(TITLE)

    def _draw_cell(self, r, c):
        """
        Call for each cell in the Table Widget.

        r, c: int
            row, column
            cell position
            from 0 to n, where n is the Table's span minus one.
        """
        gum = self.gum_table[r][c]
        start, end = self.get_topleft(gum=gum).corners
        self.set_cell_face(gum, start, end, is_table=False)
        if gum.is_topleft:
            self.set_tooltip(r, c)

    def _draw_first_cell(self):
        """
        Draw the first cell in the Table Widget. The size of the
        first cell will be the screen size of every cell in the Table.

        The 'self.roller_win.gtk_win.show_all' function
        causes the 'vbox' allocation to be calculated
        which will fail ScrolledWindow's dependency.
        So it's calculate the scroll region-size manually.

        Return:
            the width of the cell in pixels
            of int
        """
        row, column = self.grid

        self.roller_win.gtk_win.show_all()

        # scale
        w = self.cell_height
        w1, h = w * column, w * row
        button_w = button_h = 0
        pad_w = 4 * column
        pad_h = 4 * row
        extra_w, extra_h = self._table_grid
        extra = self._more + 15

        # sum
        w1 += 1 + pad_w + button_w + extra_w + fw.SCROLL_SPAN + extra
        h += 1 + pad_h + button_h + extra_h + fw.SCROLL_SPAN + extra
        w1, h = self.roller_win.get_remaining_dim(w1, h)

        self.set_size_request(w1, h)
        return w

    def _open_cell_editor(self, g):
        """
        Open a cell editor GTK Dialog.

        g: ColorfulButton
            Is responsible.
        """
        self.r_c = g.key
        self.widget = g
        self.roller_win.bring_dialog(
            self, d={wk.R_C: g.key, wk.IS_FACE: self._is_face}
        )

    def draw(self):
        """Draw a cell table."""
        w = 1
        row, column = self._table_grid
        table = gtk.Table(row, column)
        scroll = gtk.ScrolledWindow()
        is_1st_cell = True
        black_box = Eventful((0, 0, 0))
        black_box.add(table)
        scroll.add_with_viewport(black_box)
        self.add(scroll)
        scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        for r in range(row):
            for c in range(column):
                r1, c1 = r // 2 + 1, c // 2 + 1

                if r == 0:
                    if c % 2:
                        g = self.draw_column_header(c, c1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif c == 0:
                    if r % 2:
                        g = self.draw_row_header(r, r1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif r % 2 and c % 2:
                    # Create the cell.
                    r3, c3 = r // 2, c // 2
                    gum = self.gum_table[r3][c3]
                    g = gum.pad_box = boxer(align=(0, 0, 1, 1))

                    # In the Table, there are several Widget type. A
                    # cell Widget is either an Eventful - an invalid cell,
                    # or a ColorfulButton - a valid cell. The ColorfulButton
                    # is given a short-cut name, 'box', in the Gum container.
                    if gum.is_topleft:
                        g1 = self.make_cell_button(r3, c3)

                    elif not gum.is_cell:
                        g1 = Eventful(co.CELL_COLOR)

                        if not gum.is_dependent:
                            g1.set_tooltip_text(NO_CELL)
                        else:
                            g1.set_tooltip_text(NO_CELL)

                    else:
                        g1 = self.make_cell_button(r3, c3)

                    g2 = self.gum_table[r3][c3].box = g1

                    g.add(g1)
                    table.attach(g, c, c + 1, r, r + 1)
                    self._draw_cell(r3, c3)

                    if is_1st_cell:
                        w = self._draw_first_cell()
                        is_1st_cell = False
                    g2.set_size_request(w, w)

    def get_a(self, r_c=None):
        """
        Fetch the value of a cell in the value dict.

        r_c: tuple
            (row, column)

        Return: dict or None
            Preset
            A main cell is None.
        """
        k = self.r_c if r_c is None else r_c
        return self.get_a_with_k(k)

    def get_a_with_k(self, k):
        """
        Fetch the value of a cell in the value dict.

        r_c: tuple
            (row, column)

        Return: dict or None
            Preset
            A main cell is None.
        """
        r, c = k[:2]

        self.gum_table[r][c].box.label.set_text("☍")
        return self._per_d.get(k)

    def get_a_from_menu(self, k):
        """
        Fetch the value of a cell in the value dict.

        r_c: tuple
            (row, column)

        is_editor: bool
            Is True if the caller is the cell editor.

        Return: dict or None
            Preset
            A main cell is None.
        """
        return self._per_d.get(k)

    def get_cell_symbol(self, r, c):
        """
        Get the symbol for a cell.

        r, c: int
            the cell index of the Box
        """
        return self.get_symbol(self._per_d.get((r, c)), r, c)

    def make_cell_button(self, r, c):
        """
        Make a ColorfulButton.

        r, c: int
            row, column
            cell position

        Return: ColorfulButton
            newly created
        """
        return PerCellButton(
            color=co.CELL_COLOR,
            any_group=self.cell_table_group,
            get_a=self.get_a_from_menu,
            key=(r, c),
            relay=self._open_cell_editor,
            roller_win=self.roller_win,
            set_a=self.throw_switch,
            text=self.get_cell_symbol(r, c)
        )

    def on_cell_editor_close(self):
        """Set the current cell to normal, non-edit, mode."""
        for r in range(self.grid[0]):
            for c in range(self.grid[1]):
                gum = self.gum_table[r][c]
                if gum.is_cell:
                    gum.box.label.set_text(
                        self.get_cell_symbol(r, c)
                    )
                    self.set_tooltip(r, c)

    def set_a(self, d, r_c=None, i=None):
        """
        Set the value of a cell in the value dict.

        d: dict
            Preset

        r_c: tuple
            (row, column)

        i: int or None
            Plan or Work index
            not used
        """
        k = self.r_c if r_c is None else r_c
        self.set_a_with_k(d, k)

    def set_a_with_k(self, d, k, is_change=False):
        """
        Set the value of a cell in the Per value dict.

        d: dict
            Preset

        k: tuple
            Per dict key

        is_change: bool
            If True, then the symbol color is set to white.
        """
        r, c = k[:2]
        box = self.gum_table[r][c].box
        e = self._per_d
        is_change = (d != e.get(k)) or is_change

        if d:
            e[k] = deepcopy(d)

        elif k in e:
            e.pop(k)

        box.label.set_label(self.get_cell_symbol(r, c))

        if is_change:
            box.label.modify_fg(gtk.STATE_NORMAL, co.WHITE)
        self.set_tooltip(r, c)

    def set_active_cell(self, r, c):
        """
        Set the active cell, 'self.r_c', for get
        and set operation from the cell editor.

        r, c: int
            cell index for the cell in focus
        """
        # the previous cell
        r1, c1 = self.r_c

        self.gum_table[r1][c1].box.label.set_label(
            self.get_cell_symbol(r1, c1)
        )

        self.r_c = r, c

        # the new cell
        self.gum_table[r][c].box.label.set_text("☍")

    def set_cell_array(self, d, q):
        """
        Set the value of cell from an array of cell index.

        d: dict or None
            Preset for each cell

        q: list
            of (r, c); cell index
        """
        for k in q:
            self.r_c = k
            self.set_a(d)

    def set_tooltip(self, r, c):
        """
        Set a cell's tooltip.

        r, c: int
            zero-based cell index
            The cell has a Widget to receive a tooltip.
        """
        d = self._per_d[(r, c)] if (r, c) in self._per_d else None
        g = self.gum_table[r][c].box

        if not d:
            g.set_tooltip_text(" Is main. ")
        else:
            g.set_tooltip_text(make_tooltip(self.group_key, d, "", 0))

    def throw_switch(self, d, r_c):
        self.set_a_with_k(d, r_c, is_change=True)


class PortPerFace(PortPerCell):
    """Display a Face/.../Per table for Preset access."""

    def __init__(self, d, g, is_face=True):
        """
        d: dict
            Has keyword argument.

        g: PerGroupMerge
            Is responsible.

        is_face: bool
            If it is True, then Face output is required from the editor.
        """
        self.face_i = 0

        if is_face:
            self.face_tip_text = g.any_group.item.model.get_face_text()
        PortPerCell.__init__(self, d, g, is_face=is_face)

    def get_a(self):
        """
        Fetch the value of a cell in the value dict.

        Return: dict or None
            Preset
            A main cell is None.
        """
        k = self.r_c + (self.face_i,)
        return self.get_a_with_k(k)

    def make_cell_button(self, r, c):
        """
        Make a ColorfulButton.

        r, c: int
            row, column
            cell position

        Return: ColorfulButton
            newly created
        """
        return ColorfulButton(
            any_group=self.cell_table_group,
            color=co.CELL_COLOR,
            key=(r, c),
            relay=self._open_cell_editor,
            roller_win=self.roller_win,
            text=self.get_cell_symbol(r, c)
        )

    def get_cell_symbol(self, r, c):
        """
        Get the symbol for a display cell.

        r, c: int
            cell index
        """
        # Check to see if any of the Face have a dict.
        # Three Box Face, '3'
        for i in range(3):
            d = self._per_d.get((r, c, i))
            if d:
                break
        return self.get_symbol(d, r, c)

    def set_a(self, d, face_i=None, i=None):
        """
        Set the value of a cell in the value dict.

        d: dict
            Preset

        face_i: int
            Face index

        i: int or None
            Plan or Work index
            not used
        """
        if face_i is None:
            face_i = self.face_i

        else:
            self.face_i = face_i

        k = self.r_c + (face_i,)
        self.set_a_with_k(d, k)

    def set_active_face(self, face_i):
        """
        Set the active face index, 'self.face_i',
        for cell editor get and set operation.

        face_i: int
            0 to 2; The Box Model has three Faces.
        """
        self.face_i = face_i

    def set_cell_faces(self, d):
        """
        Set the three Face values to a Preset value dict.

        d: dict
            Preset value
        """
        # the total number of Face per cell , '3'
        for i in range(3):
            self.set_a(d, face_i=i)

    def set_tooltip(self, r, c):
        """
        Set a cell's tooltip.

        r, c: int
            zero-based cell index
            The cell has a Widget to receive a tooltip.
        """
        q = [i for i in range(3) if (r, c, i) in self._per_d]
        g = self.gum_table[r][c].box

        if not q:
            g.set_tooltip_text(" Is main cell. ")
        else:
            n = "Faces"

            # one line for each face, '3'
            for i in range(3):
                n1 = "\n\t" + self.face_tip_text[i]
                n1 += " Is per. " if i in q else " Is main. "
                n += n1
            g.set_tooltip_text(n)


class PortPerFacing(PortPerFace):
    """Display a Facing/.../Per table for Preset access."""

    def __init__(self, d, g):
        """
        d: dict
            Has keyword argument.

        g: PerGroupMerge
            Is responsible.
        """
        PortPerFace.__init__(self, d, g, is_face=False)

    def get_cell_symbol(self, r, c):
        """
        Get the symbol for a Box.

        r, c: int
            the cell index of the Box
        """
        return self.get_symbol(self._per_d.get((r, c, 0)), r, c)

    def set_tooltip(self, r, c):
        """
        Set a cell's tooltip.

        r, c: int
            zero-based cell index
            The cell has a Widget to receive a tooltip.
        """
        d = self._per_d[(r, c, 0)] if (r, c, 0) in self._per_d else None
        g = self.gum_table[r][c].box

        if not d:
            g.set_tooltip_text(" Is main cell. ")
        else:
            g.set_tooltip_text(make_tooltip(self.group_key, d, "", 0))


class PortPerMerge(PortPer):
    """Display a Cell/Type/Per table for merging cell."""

    def __init__(self, d, g):
        """
        d: dict
            Has keyword argument.

        g: PerGroupMerge
            Is responsible.
        """
        PortPer.__init__(self, d, g)
        self.init_table(True)

        self._switch_button_table = make_2d_table(*self.grid)

        Port.__init__(self, d, g)
        self.roller_win.gtk_win.set_title(TITLE)

    def _draw_cell(self, r, c):
        """
        Call for each cell in the Table Widget.

        r, c: int
            row, column
            cell position
            from 0 to n, where n is the Table's span minus one.
        """
        gum = self.gum_table[r][c]
        start, end = self.get_topleft(gum=gum).corners
        self.set_cell_face(gum, start, end)

    def _draw_connector(self, r, c):
        """
        Draw a connector SwitchButton.

        r, c: int
            row, column
        """
        # A connector SwitchButton is either on the
        # left-side or on the top of a ColorfulButton.
        if r % 2:
            # left SwitchButton
            p = [self.split_horz, self.connect_left]
            r3, c3 = r, c + 1
            r4, c4 = r // 2, c // 2 - 1
            q = (PAD, PAD, 0, 0)

        else:
            # upper SwitchButton
            p = [self.split_vert, self.connect_up]
            r3, c3 = r + 1, c
            r4, c4 = r // 2 - 1, c // 2
            q = (0, 0, PAD, PAD)

        g = boxer(box=gtk.HBox, align=(0, 0, 1, 1), padding=q)
        g1 = self._switch_button_table[r4][c4] = SwitchButton(
            r3, c3,
            cell_table=self.gum_table,
            color=co.CONNECTOR_COLOR,
            container=g,
            any_group=self.cell_table_group,
            relay=p,
            roller_win=self.roller_win,
            text="+"
        )

        g1.set_size(8, 8)
        return g, g1

    def _draw_first_cell(self):
        """
        Draw the first cell in the Table Widget. The size of
        the first cell will be the size of every cell in the Table.

        The 'self.roller_win.gtk_win.show_all' function
        causes the 'vbox' allocation to be calculated
        which will fail ScrolledWindow's dependency.
        So it's calculate the scroll region-size manually.

        Return:
            the width of the cell in pixels
            of int
        """
        row, column = self.grid

        self.roller_win.gtk_win.show_all()

        # scale
        w = self.cell_height
        w1, h = w * column, w * row
        button_w = 15 * (column - 1)
        button_h = 15 * (row - 1)
        pad_w = 4 * column
        pad_h = 4 * row
        extra_w, extra_h = self._table_grid
        extra = self._more + 15

        # sum
        w1 += 1 + pad_w + button_w + extra_w + fw.SCROLL_SPAN + extra
        h += 1 + pad_h + button_h + extra_h + fw.SCROLL_SPAN + extra
        w1, h = self.roller_win.get_remaining_dim(w1, h)

        self.set_size_request(w1, h)
        return w

    def _generate_group(self, slices):
        """
        Slices organize themselves into one or more groups. A slice
        is a cell group with a piece of itself removed by a 'connect_up'
        or 'connect_left' process and a consuming merge-cell group.

        slices: dict
            of dictionaries where each defines a group of cells
        """
        gum1 = None
        for k in slices:
            # Sort the two possible groups into a
            # larger and a smaller group (short).
            # The larger group will have the greater cell count.
            # The smaller group will be the cells not in the larger group.
            # If there's only one group,
            # the smaller group is not initialized.
            #
            # Starts by finding the longer and shorter row.
            u = slices[k]['size']
            long_row_width = long_row_height = 0
            long_col_width = long_col_height = 0
            short_col_width = short_row_height = 0
            short_row_width = short_col_height = 0
            start_long_row = [0, 0]
            start_short_row = [0, 0]
            start_long_col = [0, 0]
            start_short_col = [0, 0]

            # The key is the topleft coordinate (r, c).
            for r in range(k[0], k[0] + u[0]):
                row_width = 0
                first_col = -1

                for c in range(k[1], k[1] + u[1]):
                    if self._is_vector(k, r, c):
                        row_width += 1
                        if first_col < 0:
                            first_col = c
                    elif row_width:
                        break

                if row_width > long_row_width:
                    if long_row_width > 0:
                        # The second group inherits from the first group.
                        short_row_width = long_row_width
                        short_row_height = long_row_height
                        start_short_row = start_long_row

                    # Initialize the first group.
                    long_row_width = row_width
                    long_row_height = 1
                    start_long_row = r, first_col
                elif row_width:
                    # The vector is long or short.
                    if row_width == long_row_width:
                        long_row_height += 1
                    else:
                        if short_row_height:
                            # Add another row.
                            short_row_height += 1
                        else:
                            # Initialize the second group.
                            short_row_width = row_width
                            start_short_row = r, first_col
                            short_row_height = 1

            # Start finding the long and short column.
            for c in range(k[1], k[1] + u[1]):
                col_height = 0
                first_row = -1

                for r in range(k[0], k[0] + u[0]):
                    if self._is_vector(k, r, c):
                        col_height += 1
                        if first_row < 0:
                            first_row = r
                    elif col_height:
                        break

                if col_height > long_col_height:
                    if long_col_height > 0:
                        # Second group inherits from the first group.
                        short_col_width = long_col_width
                        short_col_height = long_col_height
                        start_short_col = start_long_col

                    # Initialize first group.
                    long_col_height = col_height
                    long_col_width = 1
                    start_long_col = first_row, c
                elif col_height:
                    # The vector is long or short.
                    if col_height == long_col_height:
                        long_col_width += 1
                    else:
                        if short_col_height:
                            short_col_width += 1
                        else:
                            # Initialize the second group.
                            short_col_width = 1
                            short_col_height = col_height
                            start_short_col = first_row, c

            row_cells = long_row_width * long_row_height
            col_cells = long_col_height * long_col_width

            # the second group's dimensions, 'v'
            v = 0

            if row_cells >= col_cells:
                u = long_row_height, long_row_width
                gum = self.gum_table[
                    start_long_row[0]][start_long_row[1]]

                # Process the second group if it was initialized.
                if short_row_width > 0:
                    v = short_row_height, short_row_width
                    gum1 = self.gum_table[
                        start_short_row[0]][start_short_row[1]]

            else:
                u = long_col_height, long_col_width
                gum = self.gum_table[
                    start_long_col[0]][start_long_col[1]]

                # Process the second group if it was initialized.
                if short_col_height > 0:
                    v = short_col_height, short_col_width
                    gum1 = self.gum_table[
                        start_short_col[0]][start_short_col[1]]

            self._set_group(gum, u)

            # Set the second group if there was one.
            if v:
                self._set_group(gum1, v)

    def _merge_groups(self, top, origin):
        """
        Merge two groups into a new group.

        top: Gum
            the topleft cell of a cell block

        origin: Gum
            the topleft cell of another cell block
        """
        # Get the bottom-rights.
        o_b_r = calc_bottom_right(origin)
        t_b_r = calc_bottom_right(top)

        # Merge the group settings.
        m_pos = min(top.r, origin.r), min(top.c, origin.c)
        m_b_r = tuple(max(o, m) for o, m in zip(o_b_r, t_b_r))
        diff = tuple(n - m for n, m in zip(m_b_r, m_pos))
        v = diff[0] + 1, diff[1] + 1

        # Get the topleft cell's dict of the merged group.
        m = self.gum_table[m_pos[0]][m_pos[1]]

        # Create a dictionary of potential slices.
        #
        # Slices are groups that are part of a merged group
        # rectangle, but are exclusive from top and origin groups.
        #
        # Also, slices have cells outside the bounds of the merged group.
        sliced = {}

        for r in range(m_pos[0], m_pos[0] + v[0]):
            for c in range(m_pos[1], m_pos[1] + v[1]):
                gum = self.gum_table[r][c]
                if gum.is_group:
                    t = self.get_topleft(gum=gum)
                    if t.r != top.r or t.c != top.c:
                        if t.r != origin.r or t.c != origin.c:
                            if is_outside(
                                t,
                                m.r, m.c,
                                v
                            ):
                                key = t.r, t.c
                                if key not in sliced:
                                    sliced[key] = {'size': t.s}

        self._set_group(m, v)
        self._generate_group(sliced)

    def _set_block_face(self, start, end):
        """
        Set the appearance of a block of cells.

        start: tuple
            (r, c) for the topleft cell

        end: tuple
            (r, c) for the bottom-right cell
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self.set_cell_face(self.gum_table[r][c], start, end)

    def _set_group(self, top, s):
        """
        Set sub-topleft cell attributes and the group's appearance.

        top: Gum
            for a new group

        s: tuple (w, h)
            group's new dimensions
        """
        top.s = s
        start, end = top.corners

        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                if r != top.r or c != top.c:
                    set_sub_top(top, self.gum_table[r][c])
        self._update_block(start, end)

    def _update_block(self, start, end):
        """
        Update the cell size and the cell appearance for a block of cells.

        start: Gum
            the topleft cell in the block

        end: Gum
            the bottom-right cell in the block
        """
        self._update_table(start, end)
        self.model.update_cell_block(start, end)
        self._set_block_face(start, end)

    def _update_cell_tooltip(self, gum):
        """
        Call whenever a cell is drawn. Update the
        cell dimension tooltip for merge-cell.

        gum: Gum
            Has cell data.
        """
        g, s = gum.box, gum.s
        if gum.is_topleft:
            x, y, w, h = self.model.get_merge_rect((gum.r, gum.c))
            x -= Wip.x
            y -= Wip.y
            tip = Tip.MERGE_CELL.format(*map(int, (x, y, w, h)))
            g.set_tooltip_text(tip)
            if s != (1, 1):
                start, end = gum.corners
                for r in range(start[0], end[0] + 1):
                    for c in range(start[1], end[1] + 1):
                        if self.gum_table[r][c].box:
                            g1 = self.gum_table[r][c].box
                            if g != g1:
                                g1.set_tooltip_text("")

    def _update_table(self, start, end):
        """
        Update the size attribute for a block of cells.

        start: tuple of int
            the topleft cell in the block
            (r, c)

        end: tuple of int
            the bottom-right cell in the block
            (r, c)
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self._per_d[(r, c)] = self.gum_table[r][c].s

    def _is_vector(self, u, r, c):
        """
        Determine if a cell (r, c) is still referencing a topleft cell at 'u'.

        u: tuple
            (row, column)

        Return: bool
            Is true if the topleft cell is still referenced.
        """
        # Get the cell dict.
        gum = self.gum_table[r][c]

        # Independent cells are not part of a vector.
        if gum.is_group:
            a = self.get_topleft(gum=gum)
            # Gum must refer to its old top.
            return a.r == u[0] and a.c == u[1]

    def connect_left(self, gum):
        """
        Connect cells horizontally.

        gum: Gum
            Has cell data.
        """
        origin = self.get_topleft(gum=gum)
        top = self.get_topleft(u=(gum.r, gum.c - 1))
        self._merge_groups(top, origin)

    def connect_up(self, gum):
        """
        Connect cells vertically.

        gum: Gum
            Has cell data.
        """
        origin = self.get_topleft(gum=gum)
        top = self.get_topleft(u=(gum.r - 1, gum.c))
        self._merge_groups(top, origin)

    def draw(self):
        """Draw a cell table."""
        w = 1
        row, column = self._table_grid
        table = gtk.Table(row, column)
        scroll = gtk.ScrolledWindow()
        is_1st_cell = True
        black_box = Eventful((0, 0, 0))
        black_box.add(table)
        scroll.add_with_viewport(black_box)
        self.add(scroll)
        scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        for r in range(row):
            for c in range(column):
                r1, c1 = r // 2 + 1, c // 2 + 1
                r2, c2 = r // 2 - 1, c // 2 - 1

                if r == 0:
                    g = self.draw_column_header(c, c1)
                    table.attach(g, c, c + 1, r, r + 1)

                elif c == 0:
                    g = self.draw_row_header(r, r1)
                    table.attach(g, c, c + 1, r, r + 1)

                elif r % 2 and c % 2:
                    # Create the cell.
                    r3, c3 = r // 2, c // 2
                    gum = self.gum_table[r3][c3]

                    # Store Button ref with gum.
                    if r > 1:
                        gum.top_button = self._switch_button_table[r2][c3]

                    if c > 1:
                        gum.left_button = self._switch_button_table[r3][c2]

                    g = gum.pad_box = boxer(align=(0, 0, 1, 1))
                    g1 = Eventful(co.CELL_COLOR)

                    if not gum.is_cell:
                        g1.set_tooltip_text(NO_CELL)

                    g2 = self.gum_table[r3][c3].box = g1

                    g.add(g1)
                    table.attach(g, c, c + 1, r, r + 1)
                    self._draw_cell(r3, c3)

                    if is_1st_cell:
                        w = self._draw_first_cell()
                        is_1st_cell = False
                    g2.set_size_request(w, w)

                elif not (not r % 2 and not c % 2):
                    g, g1 = self._draw_connector(r, c)

                    g.add(g1)
                    table.attach(g, c, c + 1, r, r + 1)

                else:
                    # This is the square pixel space that lies
                    # at the four corners of a cell group. It
                    # is not active but serves aesthetics.
                    g = Eventful(co.CONNECTOR_COLOR)
                    g1 = gtk.HBox()

                    g.add(g1)
                    table.attach(g, c, c + 1, r, r + 1)

    def make_cell_button(self, r, c):
        """
        Make a ColorfulButton and add its
        cell coordinates to the ColorfulButton.

        r, c: int
            row, column
            cell position

        Return: ColorfulButton
            newly created
        """
        return ColorfulButton(
            any_group=self.cell_table_group,
            color=co.CELL_COLOR,
            key=(r, c),
            relay=self._open_cell_editor,
            roller_win=self.roller_win,
            text=self.get_cell_symbol(r, c)
        )

    def split_horz(self, gum):
        """
        The user has clicked a disconnect horizontal connector.
        Divide the group containing this connector by two columns.

        gum: Gum
            Has cell data.
        """
        self._split_cells = True
        c = gum.c
        top = self.get_topleft(gum=gum)
        w = c - top.c
        w1 = top.s[1] - w
        gum1 = self.gum_table[top.r][top.c + w]

        self._set_group(gum1, (top.s[0], w1))
        self._set_group(top, (top.s[0], w))
        self._split_cells = False

    def split_vert(self, gum):
        """
        The user has clicked a disconnect vertical connector.
        Divide the group containing this connector by two rows.

        gum: Gum
            Has cell data.
        """
        self._split_cells = True
        r = gum.r
        top = self.get_topleft(gum=gum)
        h = r - top.r
        h1 = top.s[0] - h
        gum1 = self.gum_table[top.r + h][top.c]

        # Create new groups from the split.
        self._set_group(gum1, (h1, top.s[1]))
        self._set_group(top, (h, top.s[1]))
        self._split_cells = False


class Gum(object):
    """Use with cell table as a container for cell management."""

    def __init__(self, s, r, c, is_cell):
        """
        Create a cell storage object.

        s: tuple
            cell size
            in cells

        r, c: int
            cell index

        is_cell: flag
            Use with hexagonal.
        """
        # size of the cell in cell count
        # (w, h)
        self.s = s

        # row and column cell table indices
        self.r, self.c = r, c

        # Gum
        # If the cell is not a topleft cell,
        # then this refers to its topleft cell.
        self.topleft = None

        # Are SwitchButton on the side of the cell in
        # the merge-cell Cell Table Window.
        self.top_button = self.left_button = None

        # bool
        # Is true if the cell is not
        # a double-spaced cell with an invalid cell index.
        self.is_cell = is_cell

        # VBox with padding
        self.pad_box = None

        # Is an Eventful or a ColorfulButton.
        self.box = None

    @property
    def is_dependent(self):
        """
        Dependent cells are not a topleft cell,
        but part of a group of merge-cell.
        """
        return self.s == (-1, -1)

    @property
    def is_group(self):
        """Grouped cells are merge-cell."""
        return self.is_topleft or self.s == (-1, -1)

    @property
    def is_topleft(self):
        """
        Determine if a cell is a topleft cell.

        Return: bool
            Is true if the cell is a topleft cell.
        """
        return (self.s[0] >= 1 or self.s[1] >= 1) and self.is_cell

    @property
    def corners(self):
        """
        Return the row and column indices for a
        cell and its bottom-right cell.
        """
        s = self.r, self.c
        t = s[0] + self.s[0] - 1, s[1] + self.s[1] - 1
        return s, t
