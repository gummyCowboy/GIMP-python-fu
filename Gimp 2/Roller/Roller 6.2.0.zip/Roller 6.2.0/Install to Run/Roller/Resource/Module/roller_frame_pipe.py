#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, CHANNEL_OP_SUBTRACT, pdb  # type: ignore
from roller_a_contain import Run
from roller_constant_for import Frame as ff
from roller_constant_key import Material as ma, Option as ok
from roller_frame import grow_wrap
from roller_frame_alt import FrameOverlay
from roller_fu import add_layer, load_selection, select_z
from roller_fu_mode import get_mode
from roller_view_hub import (
    ROUTE_PROFILE, color_layer, color_selection, set_fill_context_default
)
from roller_view_real import get_light

"""
Define 'frame_pipe' as a Maya-subtype
for managing a variation of Frame type.
"""


def do_overlay(maya):
    """
    Make a color layer.

    maya: Overlay
    Return: layer
        with color
    """
    pdb.gimp_selection_none(Run.j)

    d = maya.value_d
    z = add_layer(Run.j, maya.group, get_light(maya), "Material")

    color_layer(z, d[ok.COLOR_1])
    return z


def do_matter(maya):
    """
    Make a frame.

    maya: Pipe
    Return: layer or None
        Pipe Wrap 'matter'
    """
    d = maya.value_d
    z = add_layer(Run.j, maya.group, get_light(maya), "Material")
    w = d[ok.WIDTH]
    q = ROUTE_PROFILE[d[ok.PROFILE]](w)

    set_fill_context_default()
    select_z(maya.cast.matter)
    draw_profile(z, w, d[ok.HEIGHT], q)

    z.opacity = d[ok.OPACITY]
    z.mode = get_mode(d, k=ok.MODE)
    return z


def draw_profile(z, w, h, q):
    """
    Draw a color-type gradient frame using a profile.

    z: layer
        Receive profile color.

    w: float
        width of profile

    h: float
        height of profile

    q: list
        of profile
        in .0 to 1.
    """
    j = z.image

    # selections
    a = b = None

    for i in range(int(w)):
        if a:
            # Do now to save memory for large frames.
            pdb.gimp_image_remove_channel(j, a)

        a = b = pdb.gimp_selection_save(j)
        if b:
            grow_wrap(j, None, 1, ff.ANGULAR)
            load_selection(j, b, option=CHANNEL_OP_SUBTRACT)

            color = int(round(q[i] * h))

            color_selection(z, (color, color, color))
            load_selection(j, b, option=CHANNEL_OP_ADD)
    if b:
        pdb.gimp_image_remove_channel(j, b)


class Pipe(FrameOverlay):
    kind = material = ma.PIPE
    overlay_k = ok.OVERLAY_CO
    shade_row = ok.RW1
    wrap_k = ok.WRAP_PI

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        FrameOverlay.__init__(
            self, any_group, super_maya, k_path, do_matter, do_overlay
        )
