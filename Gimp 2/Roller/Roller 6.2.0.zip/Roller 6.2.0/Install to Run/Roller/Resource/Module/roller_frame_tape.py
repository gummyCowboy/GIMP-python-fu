#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (  # type: ignore
    CLIP_TO_IMAGE, CHANNEL_OP_ADD, LAYER_MODE_DARKEN_ONLY, pdb
)
from math import atan2, cos, sin, radians
from random import randint, uniform
from roller_a_contain import Globe, Run
from roller_a_gegl import noise_rgb
from roller_constant_key import Material as ma, Option as ok, SubMaya as sm
from roller_frame import ShadowBasic
from roller_frame_alt import AddAbove
from roller_fu import (
    add_layer,
    blur_selection,
    clear_inverse_selection,
    clear_selection,
    clone_layer,
    get_item_size,
    get_select_coord,
    invert_selection,
    load_selection,
    make_layer_group,
    merge_layer_group,
    select_z,
    select_z_iffy,
    select_polygon,
    verify_layer
)
from roller_image_grind import ref_get_image
from roller_maya_below import Below
from roller_maya_build import Build, SubBuild
from roller_maya_layer import (
    check_matter, check_mix_basic, make_group_overlay, make_group_sub
)
from roller_maya_light import Light
from roller_many_rect import Rect
from roller_view_hub import (
    color_layer, color_selection, do_curves, set_fill_context_default
)
from roller_view_preset import combine_seed
from roller_view_real import get_light, mask_sub_maya

"""
Define 'frame_tape' as a Maya-subtype
for managing a variation of Frame type.
"""


def calc_angle_shift(d):
    """
    Randomize the angle-shift amount.

    d: dict
        Tape Preset
        {Option key: value}

    Return: float
        angle shift
    """
    f = d[ok.ANGLE_SHIFT]
    return uniform(radians(-f), radians(f))


def calc_rotated_bounds(maya):
    """
    Calculate the rotated bounds of the
    work-in-progress image in its original size.

    Calculate the transform amount for the x, y vectors.
    The goal of the transform is to calculate
    the corner points of the a placed image.

    The function only works when the original image size ratio
    is the same as the cell image's size ratio. The Locked Resize
    Method will leave the ratio the same, but the other Resize
    Methods typically modify this ratio.

    maya: Tape
    """
    q = Bag.corners
    j = ref_get_image(maya.any_group, Bag.k, 0)

    if j:
        w, h = get_item_size(j)
        f = Bag.angle

        # center
        w, h = w / 2., h / 2.

        radius = ((w**2.) + (h**2.))**.5

        for i in range(4):
            if not i:
                x, y = -w, h

            elif i == 1:
                x, y = w, h

            elif i == 2:
                x, y = w, -h

            else:
                x, y = -w, -h

            x, y = calc_point(.0, .0, atan2(x, y) + f, radius)
            q.append((x, y))

        q_x = [i[0] for i in q]
        q_y = [i[1] for i in q]
        u = min(q_x), min(q_y)
        u1 = max(q_x), max(q_y)
        u = abs(u[0] - u1[0]), abs(u[1] - u1[1])
        Bag.transform = Bag.rect.w / u[0], Bag.rect.h / u[1]


def calc_point(x, y, angle, radius):
    """
    Return a point on a circle that intersects with at a
    vector starting from the center of the circle at a angle.

    x, y: float
        center point

    angle : float
        rotation angle in radians

    radius: float
        the radius of the circle in pixels

    Return: tuple
        (x, y) of float
        the point on the circle
    """
    x = (sin(angle) * radius) + x
    y = (cos(angle) * -radius) + y
    return round(x), round(y)


def calc_tape_length(d):
    """
    Calculate tape length.

    d: dict
        Has options.

    Return: float
        tape length
    """
    return max(
        1.,
        d[ok.LENGTH] + randint(-d[ok.LENGTH_SHIFT], d[ok.LENGTH_SHIFT])
    )


def do_matter(maya):
    """
    Make a tape layer.

    maya: Tape
    Return: layer or None
        material
    """
    j = Run.j
    z = None
    parent = maya.group
    offset = get_light(maya)
    super_ = maya.cast

    set_fill_context_default()

    # Check to see if the caller is a grid, 'main_q'.
    if hasattr(super_, 'main_q'):
        group = make_layer_group(j, parent, offset, "Material")
        model = maya.model

        for k in super_.main_q:
            sel = model.get_image_sel(k)

            load_selection(j, sel)
            if not pdb.gimp_selection_is_empty(j):
                do_sel(maya, add_layer(j, group, offset, "Base"), k)
        z = merge_layer_group(group)

    else:
        select_z_iffy(j, maya.cast.matter)
        if not pdb.gimp_selection_is_empty(j):
            z = add_layer(j, parent, offset, "Material")
            z = do_sel(maya, z, maya.cast.k)

    z = verify_layer(z)

    if z:
        z.opacity = 34.
        z.mode = LAYER_MODE_DARKEN_ONLY
    return z


def do_overlay(maya):
    """
    Make a color overlay layer.

    maya: Overlay
    Return: layer or None
        material
    """
    d = maya.value_d
    z = add_layer(Run.j, maya.group, get_light(maya), "Material")

    color_layer(z, d[ok.COLOR_1])
    return z


def do_sel(maya, z, k):
    """
    Draw tape. Select the image material prior to calling.

    maya: Tape
    k: tuple or None
        (row, column)

    Return: layer or None
        material
    """
    j = Run.j
    a = Bag(maya, k, *get_select_coord(j))

    if a.angle:
        calc_rotated_bounds(maya)

    b = a.rect

    # noise layer, 'z1'
    z1 = clone_layer(z)
    z1.opacity = 50.

    combine_seed(a.d)
    pdb.gimp_selection_none(j)
    noise_rgb(
        z1,
        uniform(.001, .04),
        uniform(.001, .04),
        uniform(.001, .04),
        1.,                             # alpha
        int(a.d[ok.SEED] + Globe.seed)
    )
    select_topleft(b.x, b.y)
    select_top_right(b.x + b.w, b.y)
    select_bottom_left(b.x, b.y + b.h)
    select_bottom_right(b.x + b.w, b.y + b.h)
    color_selection(z, (255, 255, 255))
    clear_inverse_selection(z1)

    for i in range(2):
        pdb.plug_in_shift(j, z, 1, 0)
        pdb.plug_in_shift(j, z, 1, 1)

    blur_selection(z, 2.)

    z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

    # Darken the edge.
    select_z(z)
    pdb.gimp_selection_shrink(j, 1)
    invert_selection(j)
    do_curves(z, (.0, .0392, 1., .3137))
    return z


def get_corner_point(x, y, corner_i):
    """
    x, y: int
        corner point

    corner_i: int
        index to corner point

    Return: tuple
        of int
        corner point
    """
    def _shift():
        """
        Randomize corner-shift amount.

        Return: int
            corner shift
        """
        _a = a.d[ok.CORNER_SHIFT]
        return randint(-_a, _a)

    a = Bag

    if a.angle:
        x1, y1 = a.corners[corner_i]
        x1 *= a.transform[0]
        y1 *= a.transform[1]
        x = x1 + a.center[0]
        y = y1 + a.center[1]

    x += _shift()
    y += _shift()
    return x, y


def make_group_tape(maya):
    """
    Make a Wrap layer group. Is a
    sub-group of the super maya's layer group.

    maya: Maya
    Return: layer group
        Wrap parent
    """
    return make_group_sub(maya, "Tape")


def select_tape_rect(d, angle, x, y, w):
    """
    Define and select a tape rectangle.

    d: dict
        Tape Preset
        {Option key: value}

    x, y: int
        start point

    w: int
        length of tape
    """
    w1 = d[ok.WIDTH]

    # 90 degrees in radian, 1.5708
    x1, y1 = calc_point(x, y, angle - 1.5708, w1)

    # 180 degrees in radian, 3.14159
    x2, y2 = calc_point(x1, y1, angle - 3.14159, w)

    # 270 degrees in radian, 4.71239
    x3, y3 = calc_point(x2, y2, angle - 4.71239, w1)

    select_polygon(
        Run.j,
        (x, y, x1, y1, x2, y2, x3, y3),
        option=CHANNEL_OP_ADD
    )


def select_bottom_left(x, y):
    """
    Make a selection for the bottom-left corner.

    x, y: float
        corner point
    """
    d = Bag.d

    # 135 degrees in radian, 2.35619
    angle = 2.35619 + calc_angle_shift(d) + Bag.angle

    x, y = get_corner_point(x, y, 3)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(d, angle, x1, y1, w)


def select_bottom_right(x, y):
    """
    Make a selection for the bottom-right corner.

    x, y: int
        corner point
    """
    d = Bag.d

    # 45 degrees in radian, .785398
    angle = .785398 + calc_angle_shift(d) + Bag.angle

    x, y = get_corner_point(x, y, 2)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(d, angle, x1, y1, w)


def select_topleft(x, y):
    """
    Make a selection for the topleft corner.

    x, y: int
        corner point
    """
    d = Bag.d

    # 225 degrees in radian, 3.92699
    angle = 3.92699 + calc_angle_shift(d) + Bag.angle

    x, y = get_corner_point(x, y, 0)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(d, angle, x1, y1, w)


def select_top_right(x, y):
    """
    Make a selection for the top-right corner.

    x, y: float
        center point
    """
    d = Bag.d

    # 315 degrees in radian, 5.49779
    angle = 5.49779 + calc_angle_shift(d) + Bag.angle

    x, y = get_corner_point(x, y, 1)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(d, angle, x1, y1, w)


class Overlay(SubBuild):
    """
    Process change for an overlay layer.
    Change its blend with its super Maya mask.
    """
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_overlay, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        """
        super_maya: Maya
            Is the enclosing Maya.

        k_path: tuple
            (Option key, ...)
            Are path key to its vote dict.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, do_overlay)

        self.sub_maya[sm.ADD] = AddAbove(
            any_group, self, k_path + (ok.ADD_ABOVE,)
        )
        self.sub_maya[sm.LIGHT] = Light(
            any_group, self, ma.TAPE_OVERLAY
        )

    def do(self, d, is_change, is_mask, _):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        is_change: bool
            If it is True, then a mask is drawn on the Color layer.

        is_mask: bool
            Is True if the frame Maya has change.

        _: bool
            Is True if the background changed.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize()

        if self.matter:
            if self.is_matter or is_mask:
                mask_sub_maya(self.super_maya.matter, self.matter)

            self.sub_maya[sm.ADD].do(
                d[ok.ADD_ABOVE], self.is_matter, self.is_matter
            )
            self.sub_maya[sm.LIGHT].do(is_change)

        else:
            self.die()
        self.reset_issue()


class Tape(Build):
    """Simulate a tape holding an image in place."""
    is_seeded = True
    issue_q = 'matter', 'mode', 'opacity'
    kind = material = ma.TAPE
    put = (make_group_tape, 'group'), (check_matter, 'matter')
    shade_row = ok.RW1

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            enclosing type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        Build.__init__(
            self,
            any_group,
            super_maya,
            k_path + (ok.BRW, ok.WRAP_TA),
            do_matter
        )

        self.sub_maya[sm.OVERLAY] = Overlay(
            any_group, self, k_path + (ok.BRW, ok.OVERLAY_CO)
        )
        self.sub_maya[sm.SHADOW] = ShadowBasic(
            any_group, self, k_path + (ok.RW1, ok.SHADOW_BASIC)
        )
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.TAPE)
        self.sub_maya[sm.BELOW] = Below(
            any_group, self, k_path + (ok.RW1, ok.BELOW)
        )

    def do(self, d, is_change):
        """
        Produce and modify layer output.

        d: dict
            Tape Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.value_d = d
        is_back = Run.is_back
        self.is_matter |= is_change

        self.realize()

        if self.matter:
            self.sub_maya[sm.OVERLAY].do(
                d[ok.BRW][ok.OVERLAY_CO], is_change, self.is_matter, is_back
            )

            m = self.sub_maya[sm.SHADOW].do(
                d[ok.RW1][ok.SHADOW_BASIC], self.is_matter
            )

            if m or self.is_matter:
                # Remove shadow from behind tape.
                select_z(self.matter)
                clear_selection(self.sub_maya[sm.SHADOW].matter)

            self.sub_maya[sm.LIGHT].do(self.is_matter)
            self.sub_maya[sm.BELOW].do(
                d[ok.RW1][ok.BELOW], m or is_back, self.is_matter
            )

        else:
            self.die()
        self.reset_issue()


class Bag:
    """Is a container for making Tape material."""
    angle = .0
    center = .0, .0
    corners = []
    d = {}
    k = ""
    rect = None
    transform = ()

    def __init__(self, maya, k, x, y, x1, y1):
        """
        maya: Maya
        k: tuple or None
            cell index for WIP image

        x, y: float
            topleft corner of the image selection

        x1, y1: float
            bottom-right corner of the image selection
        """
        # Is a sequence of four x, y coordinate tuple.
        # topleft, top-right,bottom-right, bottom-left
        Bag.corners = []

        # Image selection rectangle, 'rect'
        w = x1 - x
        h = y1 - y
        Bag.rect = Rect(x, y, w, h)

        # Image selection center point, 'center'
        Bag.center = x + w / 2., y + h / 2.

        # image angle in the Image Preset
        Bag.angle = radians(maya.cast.value_d.get(ok.ANGLE, .0))

        # float
        # Use when an image has rotation to transform its corner points.
        # Set to failure value, '1.'.
        Bag.transform = 1., 1.

        # dict
        # Tape Preset
        Bag.d = maya.value_d[ok.BRW][ok.WRAP_TA]

        # tuple or None
        # cell index
        # Is None for Canvas.
        Bag.k = k
