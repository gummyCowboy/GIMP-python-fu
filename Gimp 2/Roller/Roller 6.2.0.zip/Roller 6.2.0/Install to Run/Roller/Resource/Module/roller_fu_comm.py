#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import ERROR_CONSOLE, gimp, pdb  # type: ignore
import gtk           # type: ignore

"""
Define 'fu_comm' as a collection of function used to
communicate with the user through Gimp's interface.
"""


def info_msg(n, handler=ERROR_CONSOLE):
    """
    Output a message to the user.

    n: value
        message

    handler: GIMP enum
        0 - MESSAGE_BOX
        1 - CONSOLE
        2 - ERROR_CONSOLE
    """
    a = pdb.gimp_message_get_handler()
    n = n if isinstance(n, str) else repr(n)

    pdb.gimp_message_set_handler(handler)
    gimp.message(n)
    pdb.gimp_message_set_handler(a)


def pop_up(window, i, n, title):
    """
    Display a message dialog.

    window: window
        GTK window
        parent

    i: int
        message type index
        question, info; 0, 1

    n: string
        message

    title: string
        window title

    Return: bool
        Is True if the user response is yes.
    """
    g = gtk.MessageDialog(
        parent=window,
        flags=gtk.DIALOG_MODAL,
        type=(gtk.MESSAGE_QUESTION, gtk.MESSAGE_INFO)[i],
        buttons=(gtk.BUTTONS_YES_NO, gtk.BUTTONS_CLOSE)[i],
        message_format=n
    )

    g.set_title(title)

    a = g.run()

    g.destroy()
    return a == gtk.RESPONSE_YES


def show_err(a):
    """
    Post an error message to GIMP's error console.

    a: Exception or string
        Show in GIMP's error console.
    """
    # Python 3 does not have basestring.
    if not isinstance(a, basestring):
        a = repr(a)
    info_msg(a)
