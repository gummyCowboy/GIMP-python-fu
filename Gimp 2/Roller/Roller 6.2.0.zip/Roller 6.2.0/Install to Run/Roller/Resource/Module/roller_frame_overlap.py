#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, CHANNEL_OP_SUBTRACT      # type: ignore
from roller_a_contain import Run
from roller_constant_key import Material as ma, Option as ok
from roller_frame import do_emboss_sel, do_selection
from roller_frame_alt import FrameBasic
from roller_fu import (
    get_select_coord, select_z, select_rect, select_ellipse
)
from roller_view_hub import color_selection, set_fill_context_default

"""
Define 'frame_overlap' as a Maya-subtype
for managing a variation of Frame cell-by-cell type.
"""


def do_matter(maya):
    """
    Make a frame.

    maya: Overlap
    Return: layer
        Wrap 'matter'
    """
    return do_selection(
        maya, paint_selection, embellish, "Material", is_clear=False
    )


def paint_selection(maya, z):
    """
    Draw a frame around a selection. The
    code is split by the CLOCKWISE option.

    maya: Overlap/Wrap
    Return: layer or None
        material
    """
    def _add_bottom_left():
        select_ellipse(j, left, y1, w, w, option=CHANNEL_OP_ADD)

    def _add_bottom_right():
        select_ellipse(j, x1, y1, w, w, option=CHANNEL_OP_ADD)

    def _add_topleft():
        select_ellipse(j, left, top, w, w, option=CHANNEL_OP_ADD)

    def _add_top_right():
        select_ellipse(j, x1, top, w, w, option=CHANNEL_OP_ADD)

    def _do_ccw():
        """The overlap is counter-clockwise."""
        # Select and color horizontal side.
        # left side
        select_rect(j, left, y - w1, w, h)
        _add_topleft()

        # right side
        select_rect(j, x1, y, w, h, option=CHANNEL_OP_ADD)
        _add_bottom_right()

        color_selection(z, color)

        # Select and color vertical side.
        # top
        select_rect(j, x, top, h1, w)
        _add_top_right()

        # bottom
        select_rect(j, x - w1, y1, h1, w, option=CHANNEL_OP_ADD)
        _add_bottom_left()

        color_selection(z, color1)

        # Select and color corner hook.
        # Begin horizontal color.
        # bottom-left
        select_rect(j, left, y1, w, w1)
        _add_bottom_left()
        _subtract_bottom_left()

        # top-right
        select_rect(j, x1, y - w1, w, w1, option=CHANNEL_OP_ADD)
        _add_top_right()
        _subtract_top_right()

        # Complete horizontal color.
        color_selection(z, color)

        # Begin vertical color.
        # topleft
        select_rect(j, left + w1, top, w1, w)
        _add_topleft()
        _subtract_topleft()

        # bottom-right
        select_rect(j, x1, y1, w1, w, option=CHANNEL_OP_ADD)
        _add_bottom_right()
        _subtract_bottom_right()

        # Complete vertical color.
        color_selection(z, color1)

    def _do_cw():
        """The overlap is clockwise."""
        # Select and color horizontal side.
        # left side
        select_rect(j, left, y, w, h)
        _add_bottom_left()

        # right side
        select_rect(j, x1, y - w1, w, h, option=CHANNEL_OP_ADD)
        _add_top_right()

        color_selection(z, color)

        # Select and color vertical side.
        # top
        select_rect(j, x - w1, top, h1, w)
        _add_topleft()

        # bottom
        select_rect(j, x, y1, h1, w, option=CHANNEL_OP_ADD)
        _add_bottom_right()

        color_selection(z, color1)

        # Select and color corner hook.
        # Begin horizontal color.
        # topleft
        select_rect(j, left, y - w1, w, w1)
        _add_topleft()
        _subtract_topleft()

        # bottom-right
        select_rect(j, x1, y1, w, w1, option=CHANNEL_OP_ADD)
        _add_bottom_right()
        _subtract_bottom_right()

        # Complete horizontal color.
        color_selection(z, color)

        # Begin vertical color.
        # bottom-left
        select_rect(j, left + w1, y1, w1, w)
        _add_bottom_left()
        _subtract_bottom_left()

        # top-right
        select_rect(j, x1, top, w1, w, option=CHANNEL_OP_ADD)
        _add_top_right()
        _subtract_top_right()

        # Complete vertical color.
        color_selection(z, color1)

    def _subtract_bottom_left():
        select_ellipse(
            j, left + w2, y1 + w2, w1, w1, option=CHANNEL_OP_SUBTRACT
        )

    def _subtract_bottom_right():
        select_ellipse(j, x1 + w2, y1 + w2, w1, w1, option=CHANNEL_OP_SUBTRACT)

    def _subtract_topleft():
        select_ellipse(
            j, left + w2, top + w2, w1, w1, option=CHANNEL_OP_SUBTRACT
        )

    def _subtract_top_right():
        select_ellipse(
            j, x1 + w2, top + w2, w1, w1, option=CHANNEL_OP_SUBTRACT
        )

    j = Run.j
    d = maya.value_d
    x, y, x1, y1 = get_select_coord(j)
    w = d[ok.WIDTH]
    color, color1 = d[ok.COLOR_2]
    top = y - w            # topmost point y
    left = x - w           # leftmost point x
    a, b = divmod(w, 2)    # corner rect and ellipse
    w1 = a + b             # ellipse
    w2 = w // 4.           # inner ellipse
    h = y1 - y + w1        # vertical side length
    h1 = x1 - x + w1       # horizontal side length

    set_fill_context_default()
    (_do_ccw, _do_cw)[int(d[ok.CLOCKWISE])]()
    return z


def embellish(maya, z):
    """
    The 'do_selection' function is required.

    maya: Wrap, Overlap
    z: layer
        Has colored frame.

    Return: layer
        Wrap material
    """
    select_z(z)
    return do_emboss_sel(z, maya.value_d, is_coloring=False)


class Overlap(FrameBasic):
    is_embossed = True
    kind = material = ma.OVERLAP
    wrap_k = ok.WRAP_OL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Define a key path to the Frame Preset in its vote dict.
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
