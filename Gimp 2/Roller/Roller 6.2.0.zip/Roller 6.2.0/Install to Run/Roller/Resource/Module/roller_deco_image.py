#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb   # type: ignore
from roller_a_contain import Deco, Place, Run
from roller_constant_key import Option as ok
from roller_deco import ready_canvas_rect, ready_shape
from roller_deco_imagery import place_image
from roller_fu import verify_layer
from roller_image_grind import ref_get_image
from roller_view_deck import Deck
from roller_view_hub import do_mod
from roller_view_real import get_light

"""
Define 'deco_image' as a collection of
routing function for Model/branch/Image output.
"""


def create_cell(maya, d, deck, is_main=False):
    """
    Place an image in a cell.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    deck: Deck or None
        Is the parent layer for image output.

    is_main: bool
        Is True when the caller is the main cell Maya version.

    Return: layer or None
        image
    """
    j = ref_get_image(maya.any_group, maya.k, 0)
    if j:
        ready_shape(maya, d, option=None)
        Place.set_rect(*maya.rect)
        return place_image(j, maya, d, deck, is_main)


def create_main(maya, d, p):
    """
    Place main branch/Image.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    p: function
        Place image.

    Return: layer or None
        image material
    """
    j = Run.j
    deck = Deck(j, maya.group, get_light(maya), "Material")
    arg = d, deck       # 'deck' is last for exit function.

    for k in maya.main_q:
        maya.k = k
        p(maya, *arg, is_main=True)
    return deck.exit()


def create_face(maya, d, deck, is_main=False):
    """
    Place Face image.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    deck: Deck
        Is the parent of Face output.

    is_main: bool
        Main Maya image output is placed on the same layer.

    Return: layer or None
        Image material
    """
    k = maya.k
    model = maya.model
    j = ref_get_image(maya.any_group, k, 0)
    if j:
        Place.set_rect(*model.get_facing_merged(k))
        maya.rect = model.get_facing_rect(k)
        Deco.shape = model.get_facing_shape(k)
        return place_image(j, maya, d, deck, is_main)


def create_facial_per(maya, d, p):
    """
    Place image for Face or Facing Per.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    p: function
        Place Face or Facing Per image.

    Return: layer or None
        image
    """
    return p(maya, d, None)


def create_facing(maya, d, deck, is_main=False):
    """
    Create Facing image layer.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    deck: Deck or None
        Is the parent of Facing output.

    is_main: bool
        Main Maya image output is placed on the same layer.

    Return: layer or None
        Image output
    """
    k = maya.k
    model = maya.model
    j = ref_get_image(maya.any_group, k, 0)
    if j:
        Place.set_rect(*model.get_facing_merged(k))
        return place_image(j, maya, d, deck, is_main)


def do(maya, make):
    """
    Prepare and route image placement.

    maya: Maya
        'maya_image' variety

    make: function
        Call to make image layer.

    Return: layer or None
        image material
    """
    d = maya.value_d

    if not Run.i:
        # Preserve.
        mode = d[ok.MODE]

        # Plan override.
        d[ok.MODE] = "Normal"

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.i:
        # Restore.
        d[ok.MODE] = mode
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Place image for the Canvas/Image.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        image
    """
    return do(maya, make_canvas)


def do_cell_main(maya):
    """
    Place image for Cell main option.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        image material
    """
    return do(maya, make_cell_main)


def do_cell_per(maya):
    """
    Place image for Cell/Per.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        image
    """
    return do(maya, make_cell_per)


def do_face_main(maya):
    """
    Place image for the Face main.

    maya: Maya
    Return: layer or None
        image material
    """
    return do(maya, make_face_main)


def do_face_per(maya):
    """
    Place image for Face/Per.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        image
    """
    return do(maya, make_face_per)


def do_facing_main(maya):
    """
    Place image for the Facing main.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        image material
    """
    return do(maya, make_facing_main)


def do_facing_per(maya):
    """
    Place image for Facing/Per.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        image
    """
    return do(maya, make_facing_per)


def make_canvas(maya, d):
    """
    Place a Canvas Image.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    Return: layer or None
        image
    """
    j = ref_get_image(maya.any_group, None, 0)
    if j:
        ready_canvas_rect(maya, d, option=None)
        Place.set_rect(*maya.rect)
        return verify_layer(place_image(j, maya, d, None, False))


def make_cell_main(maya, d):
    """
    Place image for Cell main.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    Return: layer or None
        image material
    """
    return create_main(maya, d, create_cell)


def make_cell_per(maya, d):
    """
    Is needed for its argument signature.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    Return: layer or None
        image
    """
    return verify_layer(create_cell(maya, d, None))


def make_face_main(maya, d):
    """
    Place image for Face main.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    Return: layer or None
        image material
    """
    return create_main(maya, d, create_face)


def make_face_per(maya, d):
    """
    Place image for Face/Per.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    Return: layer or None
        image
    """
    return create_facial_per(maya, d, create_face)


def make_facing_main(maya, d):
    """
    Place image for Face main.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    Return: layer or None
        image material
    """
    return create_main(maya, d, create_facing)


def make_facing_per(maya, d):
    """
    Place image for Facing/Per.

    maya: Maya
        'maya_image' variety

    d: dict
        Image Preset

    Return: layer or None
        image
    """
    return create_facial_per(maya, d, create_facing)
