#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, CHANNEL_OP_SUBTRACT, pdb  # type: ignore
from random import randrange
from roller_a_contain import Run
from roller_a_gegl import median_blur
from roller_constant_for import Backdrop as bs
from roller_constant_key import Option as ok, SubMaya as sm
from roller_fu import (
    remove_z, select_ellipse, select_rect, select_z
)
from roller_maya_style import Style
from roller_one_wip import Wip
from roller_view_hub import (
    color_selection, do_mod, get_mean_color, set_fill_context_default
)
from roller_view_preset import combine_seed
from roller_view_real import add_wip_base, insert_copy

"""
Define 'backdrop/corner_overlap' as a Maya-subtype
for managing the Corner Overlap backdrop style layer output.
"""


def exit_mean_color(z):
    """
    Delete the background copy.

    z: layer
        background copy
    """
    remove_z(z)


def fetch_mean_color(z):
    """
    z: layer
        background copy

    Return: tuple
        RGB
    """
    return get_mean_color(z)


def get_average_color(color1, color2):
    """
    Average two colors.

    color1: tuple
        RGB

    color2: tuple
        RGB

    Return: tuple
        RGB
    """
    color = ()

    # RGB, '3'
    for x in range(3):
        color += ((color1[x] + color2[x]) // 2,)
    return color


def get_color_1(color1, _):
    """
    color1: tuple
        RGB

    _: tuple
        RGB

    Return: tuple
        RGB
    """
    return color1


def get_color_2(_, color2):
    """
    _: tuple
        RGB

    color2: tuple
        RGB

    Return: tuple
        RGB
    """
    return color2


def generate_random_color():
    """
    Return: tuple
        (RGB, RGB)
    """
    return tuple([randrange(256) for _ in range(3)])


def init_random_color(*_):
    """
    Return: tuple
        RGB
    """
    return generate_random_color(), generate_random_color()


def init_color(_, d):
    """
    _: group layer
    d: dict
        Corner Overlap Preset

    Return: tuple
        (RGB, RGB)
    """
    return d[ok.COLOR_2]


def init_mean_color(group, _):
    """
    group: group layer
        Copy its background.

    _: dict
        Floor Sample Preset

    Return: tuple
        (background copy layer,)
    """
    return insert_copy(group, group, is_hide=True),


EXIT_TYPE = {
    bs.COLOR: lambda *_: None,
    bs.MEAN_COLOR: exit_mean_color,
    bs.RANDOM_COLOR: lambda *_: None
}
INIT_TYPE = {
    bs.COLOR: init_color,
    bs.MEAN_COLOR: init_mean_color,
    bs.RANDOM_COLOR: init_random_color
}
GET_COLOR_1 = {
    bs.COLOR: get_color_1,
    bs.MEAN_COLOR: fetch_mean_color,
    bs.RANDOM_COLOR: get_color_1
}
GET_COLOR_2 = {
    bs.COLOR: get_color_2,
    bs.MEAN_COLOR: fetch_mean_color,
    bs.RANDOM_COLOR: get_color_2
}
GET_FILL_COLOR = {
    bs.COLOR: get_average_color,
    bs.MEAN_COLOR: fetch_mean_color,
    bs.RANDOM_COLOR: get_average_color
}


def make_style(maya):
    """
    Create a Corner Overlap layer.

    maya: Style
    Return: layer or None
        Drop Zone material
    """
    j = Run.j
    d = maya.value_d

    combine_seed(d)
    set_fill_context_default()
    pdb.gimp_selection_none(j)

    type_ = d[ok.TYPE]
    type_arg = INIT_TYPE[type_](maya.group, d)
    z = add_wip_base("Corner Overlap WIP", maya.group)

    # Fill selections with material for each selection.
    paint_selection(z, type_, d[ok.CLOCKWISE], type_arg)

    if d[ok.FILLED]:
        select_rect(j, *Wip.get_rect())
        select_z(z, option=CHANNEL_OP_SUBTRACT)
        color_selection(z, GET_FILL_COLOR[type_](*type_arg))

    EXIT_TYPE[type_](*type_arg)
    pdb.gimp_selection_none(j)
    median_blur(z, 2., 50.)
    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


def paint_selection(z, type_, clockwise, type_arg):

    def _add_bottom_left_circle():
        select_ellipse(j, left, y1, w, w, option=CHANNEL_OP_ADD)

    def _add_bottom_right_circle():
        select_ellipse(j, x1, y1, w, w, option=CHANNEL_OP_ADD)

    def _add_topleft_circle():
        select_ellipse(j, left, top, w, w, option=CHANNEL_OP_ADD)

    def _add_top_right_circle():
        select_ellipse(j, x1, top, w, w, option=CHANNEL_OP_ADD)

    def _do_ccw():
        """The overlap is counter-clockwise."""
        # Select and color horizontal side.
        # left side
        select_rect(j, left, top + w1, w, h)
        _add_topleft_circle()

        # right side
        select_rect(j, x1, y - w1, w, h, option=CHANNEL_OP_ADD)
        _add_bottom_right_circle()

        color_selection(z, GET_COLOR_1[type_](*type_arg))

        # Select and color vertical side.
        # top
        select_rect(j, x, top, h1, w)   # topleft corner appears wrong?
        _add_top_right_circle()

        # bottom
        select_rect(j, x - w1, y1, h1, w, option=CHANNEL_OP_ADD)
        _add_bottom_left_circle()

        color_selection(z, GET_COLOR_2[type_](*type_arg))

        # Select and color corner hook.
        # Begin horizontal color.
        # bottom-left
        select_rect(j, left, y1, w, w1)
        _add_bottom_left_circle()
        _subtract_bottom_left()

        # top-right
        select_rect(j, x1, y - w1, w, w1, option=CHANNEL_OP_ADD)
        _add_top_right_circle()
        _subtract_top_right()

        # Complete horizontal color.
        color_selection(z, GET_COLOR_1[type_](*type_arg))

        # Begin vertical color.
        # topleft
        select_rect(j, left + w1, top, w1, w)
        _add_topleft_circle()
        _subtract_topleft()

        # bottom-right
        select_rect(j, x1, y1, w1, w, option=CHANNEL_OP_ADD)
        _add_bottom_right_circle()
        _subtract_bottom_right()

        # Complete vertical color.
        color_selection(z, GET_COLOR_2[type_](*type_arg))

    def _do_cw():
        """The overlap is clockwise."""
        # Select and color horizontal side.
        # left side
        select_rect(j, left, y - w1, w, h)
        _add_bottom_left_circle()

        # right side
        select_rect(j, x1, y - w1, w, h, option=CHANNEL_OP_ADD)
        _add_top_right_circle()

        color_selection(z, GET_COLOR_1[type_](*type_arg))

        # Select and color vertical side.
        # top
        select_rect(j, x - w1, top, h1, w)
        _add_topleft_circle()

        # bottom
        select_rect(j, x, y1, h1, w, option=CHANNEL_OP_ADD)
        _add_bottom_right_circle()

        color_selection(z, GET_COLOR_2[type_](*type_arg))

        # Select and color corner hook.
        # Begin horizontal color.
        # topleft
        select_rect(j, left, y - w1, w, w1)
        _add_topleft_circle()
        _subtract_topleft()

        # bottom-right
        select_rect(j, x1, y1, w, w1, option=CHANNEL_OP_ADD)
        _add_bottom_right_circle()
        _subtract_bottom_right()

        # Complete horizontal color.
        color_selection(z, GET_COLOR_1[type_](*type_arg))

        # Begin vertical color.
        # bottom-left
        select_rect(j, left + w1, y1, w1, w)
        _add_bottom_left_circle()
        _subtract_bottom_left()

        # top-right
        select_rect(j, x1, top, w1, w, option=CHANNEL_OP_ADD)
        _add_top_right_circle()
        _subtract_top_right()

        # Complete vertical color.
        color_selection(z, GET_COLOR_2[type_](*type_arg))

    def _subtract_bottom_left():
        select_ellipse(
            j, left + w2, y1 + w2, w1, w1, option=CHANNEL_OP_SUBTRACT
        )

    def _subtract_bottom_right():
        select_ellipse(j, x1 + w2, y1 + w2, w1, w1, option=CHANNEL_OP_SUBTRACT)

    def _subtract_topleft():
        select_ellipse(
            j, left + w2, top + w2, w1, w1, option=CHANNEL_OP_SUBTRACT
        )

    def _subtract_top_right():
        select_ellipse(
            j, x1 + w2, top + w2, w1, w1, option=CHANNEL_OP_SUBTRACT
        )

    j = Run.j
    left, top, image_w, image_h = Wip.get_rect()
    w = min(image_w, image_h) // 3
    x = left + w
    y = top + w
    x1 = left + image_w - w
    y1 = top + image_h - w
    a, b = divmod(w, 2)           # corner rect and ellipse
    w1 = a + b                    # overlap circle
    w2 = w // 4.                  # inner ellipse
    h = image_h - w               # vertical side length
    h1 = image_w - w - w1         # horizontal side length

    set_fill_context_default()
    (_do_ccw, _do_cw)[clockwise]()


class CornerOverlap(Style):
    """Create Backdrop Style output."""
    dependency = bs.DEPENDENT

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.BRW, ok.MOD, ok.BLUR_D)
            ],
            make_style
        )

    def do(self, z, d, is_change):
        """
        Produce or modify layer output. Override Style's function.

        z: layer
            Backing output
            not used

        d: dict
            Backdrop Style Preset

        is_change: bool
            not used
            Is the state of the super Maya's matter and/or mask.
            Floor Sample is independent of the Backing layer.
        """
        self.value_d = d
        is_draw = is_change if d[ok.TYPE] == bs.MEAN_COLOR else False
        self.is_matter |= is_draw

        self.realize()
        self.sub_maya[sm.ADD].do(
            d[ok.BRW][ok.ADD_ALT], self.is_matter, self.is_matter, is_change
        )
        self.reset_issue()
