#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from roller_a_contain import Run
from roller_constant_for import Backdrop as bs
from roller_constant_key import Option as ok
from roller_fu import (
    add_layer, create_image, paste_layer, rotate_image
)
from roller_maya_style import Style
from roller_view_hub import (
    calc_rotated_image_span,
    clipboard_fill,
    do_mod,
    make_cube_pattern,
    set_fill_context_default
)
from roller_view_real import add_wip_layer, clip_to_wip

"""
Define 'backdrop/cube_pattern' as a Maya-subtype
for managing a variation of backdrop style layer.
"""


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: Style
    Return: layer
        Backdrop Style material
    """
    j = Run.j
    d = maya.value_d
    key = maya.any_group.item.key

    set_fill_context_default()
    make_cube_pattern(d[ok.HEIGHT], d[ok.COLOR_3A])

    if d[ok.ANGLE]:
        w = calc_rotated_image_span(j.width, j.height)
        j1 = create_image(w, w)
        z = add_layer(j1, None, 0, key)

        clipboard_fill(z)
        rotate_image(j1, d[ok.ANGLE])
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

        z = paste_layer(maya.group, n=key)

        pdb.gimp_image_reorder_item(j, z, maya.group, 0)
        pdb.gimp_layer_resize_to_image_size(z)
        clip_to_wip(z)

    else:
        # pattern layer, 'z'
        z = add_wip_layer(key, maya.group)
        clipboard_fill(z)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class CubePattern(Style):
    """Create Backdrop Style output."""
    dependency = bs.INDEPENDENT

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self, any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.BRW, ok.MOD, ok.BLUR_D)
            ],
            make_style
        )
