#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_for import Caption as pt, Plan as fy
from roller_constant_key import (
    Item as ie,
    Material as ma,
    Node as ny,
    Option as ok,
    Plan as ak,
    SubMaya as sm
)
from roller_deco import finish_backed
from roller_deco_caption import (
    do_canvas,
    do_cell_main,
    do_cell_per,
    do_face_main,
    do_face_per,
    do_facing_main,
    do_facing_per
)
from roller_deco_strip import (
    do_canvas_strip,
    do_cell_main_strip,
    do_cell_per_strip,
    do_face_main_strip,
    do_face_per_strip,
    do_facing_main_strip,
    do_facing_per_strip
)
from roller_image_grind import ref_get_image_name
from roller_maya import Canvas, CellRoute, FaceRoute, Main, Per, Runner
from roller_maya_layer import check_matter, check_mix_basic
from roller_maya_light import Light
from roller_maya_strip import Strip
from roller_maya_add import Add
from roller_one_helm import Helm
from roller_option_group import DecoGroup
from roller_view_branch import make_canvas_group, make_cast_group
from roller_view_step import get_planner

"""Define 'maya_caption' as a Caption option group's manager class."""


class Caption(DecoGroup):
    """
    Create a Widget group. Assign view run processor.
    Connect responsible signal handler.
    """

    def __init__(self, **d):
        DecoGroup.__init__(self, **d)

        self.image_name_d = {}
        self.plan = {
            ny.CANVAS: PlanCanvas,
            ny.CELL: PlanCell,
            ny.FACE: PlanFace,
            ny.FACING: PlanFacing
        }[self.branch_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas,
            ny.CELL: WorkCell,
            ny.FACE: WorkFace,
            ny.FACING: WorkFacing
        }[self.branch_k](self)


class Chi(Runner):
    """Factor Plan and Work."""

    def __init__(self, any_group, view_i, p, q):
        """
        any_group: AnyGroup
            Caption

        view_i: int
            0 or 1; Plan or Work index

        p: function
            Make Strip material.

        q: iterable
            of function for producing output
        """
        Runner.__init__(
            self,
            any_group,
            view_i,
            q,
            [
                (),
                (ok.RW1,),                  # Per vote dict's Font/Color
                (ok.RW1, ok.FONT),          # main's vote dict's Font position
                (ok.RW1, ok.MARGIN),
                (ok.LTR,),
                (ok.BRW, ok.MOD),
                (ok.BRW, ok.MOD, ok.BLUR_D)
            ]
        )
        self.set_issue()

        self.sub_maya[sm.STRIP] = Strip(
            any_group, self, view_i, p, (ok.BRW, ok.STRIP)
        )
        self.image_path = self.any_group.nav_k[:-1] + (ie.IMAGE,)

    def prep(self):
        """
        Determine if there was any branch/Image name change
        that effect Caption output.
        """
        image_group = Helm.get_group(self.image_path)
        if image_group:
            d = self.value_d[ok.PER]
            e = self.any_group.image_name_d

            # main Maya's Per Maya reference, 'per_d'
            # Canvas doesn't have Per.
            per_d = self.per_d if hasattr(self, 'per_d') else {}
            for k in self.any_group.get_keys():
                if k in d:
                    value_d = d[k] if d[k] else self.value_d

                else:
                    value_d = self.value_d
                if value_d[ok.SWITCH] and value_d[ok.TYPE] == pt.IMAGE_NAME:
                    n = e.get(k)
                    n1 = e[k] = ref_get_image_name(image_group, k, 0)
                    m = n != n1
                    if m:
                        # The image ref changed.
                        this_maya = self if k not in d else per_d[k]
                        this_maya.is_matter = True


class Plan(Chi):
    """Manage Plan layer output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, p):
        """
        any_group: AnyGroup
            Caption

        p: function
            Make Strip material.
        """
        Chi.__init__(self, any_group, 0, p, self.put)

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.CAPTION)
        self.latch(
            planner, (fy.SIGNAL_D[ak.CAPTION], self.on_plan_option_change)
        )

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned

        if self.go:
            self.is_matter |= self.is_switched

        self.realize()
        if self.go:
            if self.matter:
                self.sub_maya[sm.STRIP].do(d, self.is_matter, False)
            else:
                self.die()

    def on_plan_option_change(self, _, arg):
        """Respond to change in PlanOption."""
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage Work layer output."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, p):
        """
        any_group: AnyGroup
            Caption

        p: function
            Make Strip material.
        """
        Chi.__init__(self, any_group, 1, p, self.put)

        self.sub_maya[sm.ADD] = Add(any_group, self, (ok.BRW, ok.ADD))
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.CAPTION)

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d
        self.go = d[ok.SWITCH]
        is_back = Run.is_back

        self.realize()
        if self.go:
            if self.matter:
                self.sub_maya[sm.ADD].do(
                    d[ok.BRW][ok.ADD],
                    self.is_matter,
                    self.is_matter,
                    is_back,
                    self.group
                )
                finish_backed()
                self.sub_maya[sm.STRIP].do(d, self.is_matter, is_back)
                self.sub_maya[sm.LIGHT].do(self.is_matter)
            else:
                finish_backed()
                self.die()


# Canvas_______________________________________________________________________
class Cloth:
    """Factor Plan and Work Canvas Maya."""

    def __init__(self):
        self.do_matter = do_canvas


class PlanCanvas(Main, Plan, Canvas, Cloth):
    """Manage Plan's Canvas/Caption layer output."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Caption
        """
        self.do_matter = do_canvas

        Main.__init__(self)
        Plan.__init__(self, any_group, do_canvas_strip)
        Canvas.__init__(self)
        Cloth.__init__(self)


class WorkCanvas(Main, Work, Canvas, Cloth):
    """Manage Work's Canvas/Caption layer output."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Caption
        """
        self.do_matter = do_canvas

        Main.__init__(self)
        Work.__init__(self, any_group, do_canvas_strip)
        Canvas.__init__(self)
        Cloth.__init__(self)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Cell_________________________________________________________________________
class Cellular:
    """Factor Plan and Work Cell Maya."""

    def __init__(self):
        self.do_matter = do_cell_main


class PlanCell(Main, Plan, CellRoute, Cellular):
    """Manage Plan Cell layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        self.do_matter = do_cell_main

        Main.__init__(self)
        Plan.__init__(self, any_group, do_cell_main_strip)
        CellRoute.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(Main, Work, CellRoute, Cellular):
    """Manage Work Cell layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        self.do_matter = do_cell_main

        Main.__init__(self)
        Work.__init__(self, any_group, do_cell_main_strip)
        CellRoute.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Plan Cell/Per output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
        k: tuple
            (row, column); Goo key
        """
        Plan.__init__(self, any_group, do_cell_per_strip)
        Per.__init__(self, do_cell_per, k)


class WorkCellPer(Work, Per):
    """Manage Work Cell/Per output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
        k: tuple
            (row, column)
        """
        Work.__init__(self, any_group, do_cell_per_strip)
        Per.__init__(self, do_cell_per, k)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Face_________________________________________________________________________
class Face:
    """Factor Plan and Work Face Maya."""

    def __init__(self):
        self.do_matter = do_face_main


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage Plan Face output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, do_face_main_strip)
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, Main, Work, FaceRoute):
    """Manage Work Face layer output for main."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            with Face options
        """
        Face.__init__(self)
        Main.__init__(self)
        Work.__init__(self, any_group, do_face_main_strip)
        FaceRoute.__init__(self, WorkFacePer)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Face Per Cell________________________________________________________________
class PlanFacePer(Plan, Per):
    """Manage Plan Face/Caption Per layer output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            Caption

        k: tuple
            (row, column); cell index
        """
        Plan.__init__(self, any_group, do_face_per_strip)
        Per.__init__(self, do_face_per, k)


class WorkFacePer(Work, Per):
    """Manage Work/Face/Per output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            owner

        k: tuple
            (row, column); cell index
        """
        Work.__init__(self, any_group, do_face_per_strip)
        Per.__init__(self, do_face_per, k)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Facing_______________________________________________________________________
class Facing:
    """Factor Plan and Work Facing."""

    def __init__(self):
        self.do_matter = do_facing_main


class PlanFacing(Facing, Main, Plan, FaceRoute):
    """Manage Plan Facing/Caption layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Facing.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, do_facing_main_strip)
        FaceRoute.__init__(self, PlanFacingPer)


class WorkFacing(Facing, Main, Work, FaceRoute):
    """Manage Work Facing/Caption layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Facing.__init__(self)
        Main.__init__(self)
        Work.__init__(self, any_group, do_facing_main_strip)
        FaceRoute.__init__(self, WorkFacingPer)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Facing Per Cell______________________________________________________________
class FacingPer(Per):
    """Factor Plan and Work Facing/Caption Per Maya."""

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacingPer(Plan, FacingPer):
    """Manage Plan Facing/Caption Per."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c); cell index; of int; Goo key
        """
        Plan.__init__(self, any_group, do_facing_per_strip)
        FacingPer.__init__(self, do_facing_per, k)


class WorkFacingPer(Work, FacingPer):
    """Manage Work Facing/Caption/Per."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int; Goo key
        """
        Work.__init__(self, any_group, do_facing_per_strip)
        FacingPer.__init__(self, do_facing_per, k)
