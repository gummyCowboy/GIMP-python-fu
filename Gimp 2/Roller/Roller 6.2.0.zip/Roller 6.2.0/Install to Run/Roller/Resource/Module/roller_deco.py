#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_REPLACE, pdb   # type: ignore
from roller_a_contain import Deco, Run
from roller_constant_for import Deco as dc
from roller_constant_key import Option as ok
from roller_fu import select_rect, select_shape
from roller_view_real import clip_to_view

"""Define 'deco' as having Model/deco-branch/leaf output function."""


def coloring(n):
    """
    Is the deco type performed by a color fill?

    n: string
        deco branch-type/Type

    Return: bool
        Is True if the deco op is a color selection fill.
    """
    return n in dc.COLORING


def finish_backed():
    """
    If a copied background was made in deco production, then remove this copy.
    """
    if Deco.bg_z:
        pdb.gimp_image_remove_layer(Run.j, Deco.bg_z)
        Deco.bg_z = None


def ready_canvas_rect(maya, d, option=CHANNEL_OP_REPLACE):
    """
    Prepare a Canvas rectangle and shape. Select the rectangle
    when 'option' is not None.

    maya: Maya
    d: dict
        deco type Preset

    option: gimpfu enum or None
        If not None, the canvas' rectangle is selected.
    """
    if d.get(ok.OBEY_MARGIN):
        x, y, w, h = maya.rect = maya.model.canvas_pocket.rect

    else:
        x, y, w, h = maya.rect = maya.model.canvas_rect

    x1, y1 = x + w, y + h
    Deco.shape = x, y, x1, y, x1, y1, x, y1
    if option:
        select_shape(Run.j, Deco.shape, option=option)


def ready_shape(maya, d, option=CHANNEL_OP_REPLACE):
    """
    Set 'Deco.shape' and 'maya.rect'. Select
    the shape when 'option' is not None.

    maya: Maya
    d: dict
        deco type Preset

    option: gimpfu enum or None
        If not None, then the shape is selected.
    """
    a = maya.model
    k = maya.k

    # Mask doesn't have the OBEY_MARGIN option.
    if d.get(ok.OBEY_MARGIN, True):
        # the pocket shape
        maya.rect = a.get_pocket_rect(k)
        Deco.shape = a.get_shape(k)

    else:
        maya.rect = a.get_shift_rect(k)
        Deco.shape = a.get_plaque(k)
    if option is not None:
        select_shape(Run.j, Deco.shape, option=option)


def transform_foam(rect, z, q):
    """
    Shape rectangular material into a polygon.

    rect: tuple
        (x, y, w, h)
        input material to transform

    z: layer
        Dispose after transform.

    q: tuple
        x, y float series
        (topleft, top-right, bottom-left, bottom-right)

    Return: layer
        transformed material
    """
    select_rect(Run.j, *rect)

    n = z.name

    # Transform the selected material into a floating selection layer.
    z1 = pdb.gimp_item_transform_perspective(z, *q)

    if pdb.gimp_layer_is_floating_sel(z1):
        pdb.gimp_floating_sel_to_layer(z1)
        clip_to_view(z1)
        pdb.gimp_image_remove_layer(z.image, z)
        z1.name = n
    return z1
