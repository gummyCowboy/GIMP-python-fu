#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from gimpfu import pdb   # type: ignore
from roller_a_contain import Run
from roller_constant_key import Group as gk, Item as ie
from roller_fu import make_layer_group
from roller_view_real import get_light
from roller_view_step import get_model_branch_key

# {group key: sortable position ordinal}
LEAF_D = OrderedDict([
    (gk.CAPTION, 0),
    (gk.LINE, 1),
    (gk.IMAGE, 2),
    (gk.BORDER, 3),
    (gk.FRINGE, 4),
    (gk.PLAQUE, 5),
    (gk.MARGIN, 6),
    (gk.TYPE, 7)
])

# {Node/branch item key: sortable position ordinal}
BRANCH_D = OrderedDict([
    (ie.FACING, 0),
    (ie.FACE, 1),
    (ie.CELL, 2),
    (ie.CANVAS, 3),
])

CREATE_ARG = BRANCH_D, LEAF_D, None


def create_branch(maya):
    """
    Create a layer group for a Model branch.

    maya: Maya
        Needs a layer group in the correct position.

    Return: layer group
        newly created
    """
    j = Run.j
    step_k = get_model_branch_key(maya.node_path)

    # Model layer group for Plan or Work, 'parent'
    parent = maya.model.group_q[Run.i]

    # If there isn't a Model group, then the caller is out-of-sync.
    if parent:
        # index to item in step key, 'i'
        for i, item_k in enumerate(step_k):
            # Find the sub-step's layer group.
            group = None
            n = item_k

            for z in parent.layers:
                if z.name.split(" ")[-1] == n:
                    group = z
                    break

            if not group:
                group = make_layer_group(j, None, 0, item_k)
                group.name = parent.name + " " + item_k

                # Create a layer group. 'i' is in the range of 0 to 2.
                CREATE_DISPATCH[i](j, parent, group, CREATE_ARG[i], item_k)
            parent = group
    return parent


def _insert_branch(j, parent, group, d, item_k):
    """
    Insert branch and leaf into a Model layer tree.

    parent: layer group

    d: dict or None
        {descriptor: ordinal}
    """
    # [item key, ...]
    q = []

    for z in parent.layers:
        n = z.name
        q.append(n.split(" ")[-1])

    # [position ordinal, ...]
    q1 = []

    for k in q:
        q1.append(d.get(k))

    ordinal = d.get(item_k)
    q1.append(ordinal)
    q1 = sorted(q1)

    # Is the offset from the top of parent, '_i'.
    i = q1.index(ordinal)

    pdb.gimp_image_reorder_item(j, group, parent, i)


def _sort_branch(j, parent, group, *_):
    """
    _: tuple
        (None, string -> group layer name segment)

    """
    """Sort Main and Per branches."""
    n = group.name
    i = 0
    is_below = True

    for i, _n1 in enumerate(parent.layers):
        if n > _n1.name:
            is_below = False
            break

    if is_below:
        # Insert the group below the last layer in parent.
        i += 1
    pdb.gimp_image_reorder_item(j, group, parent, i)


def make_cast_group(maya):
    """
    Make a group layer for a Cell/leaf.

    maya: Maya
    """
    if not maya.group:
        group = create_branch(maya)
        maya.group = make_layer_group(Run.j, group, get_light(maya), "Cast")
    return maya.group


def make_canvas_group(maya):
    """
    Make a group layer for a Canvas/leaf step.

    maya: Maya
    """
    if not maya.group:
        maya.group = create_branch(maya)
    return maya.group


# {layer group depth: position layer group function}
CREATE_DISPATCH = {0: _insert_branch, 1: _insert_branch, 2: _sort_branch}
