#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb  # type: ignore
from roller_a_contain import Run
from roller_constant_for import (
    Issue as vo, Plan as fy, Shape as sh, Signal as si
)
from roller_constant_key import Model as md, Option as ok, Plan as ak
from roller_maya import Maya
from roller_maya_layer import check_matter
from roller_fu import add_layer, select_rect
from roller_one_ring import Ring
from roller_option_group import ModelGroup
from roller_view_hub import color_selection_default
from roller_view_branch import make_cast_group
from roller_view_step import find_cell_margin, find_cell_shift, get_planner


def draw_grid(maya):
    """
    Draw line corresponding with a Model's row and column grid.

    maya: Maya
    Return: layer or None
        Grid line
    """
    model = maya.model
    j = Run.j
    row, column = model.grid
    left, top, w, h = model.canvas_pocket.rect
    is_double = model.cell_shape in sh.DOUBLE
    is_indent = maya.value_d[ok.INDENT] if ok.INDENT in maya.value_d else False
    a = None

    pdb.gimp_selection_none(j)

    # Draw row line.
    for r in range(0, row):
        c = 0

        if is_double and r != row:
            c = not r % 2 if is_indent else r % 2
            c = min(column - 1, c)

        a = model.goo_d.get((r, c))
        if a:
            a = a.cell
            select_rect(j, left, a.y, w, 1., option=CHANNEL_OP_ADD)

    if a:
        # Is the last row line, the enclosing row line.
        select_rect(j, left, a.y + a.h, w, 1., option=CHANNEL_OP_ADD)

    a = None

    # Draw column line.
    for c in range(0, column):
        r = 0

        if is_double and c != column:
            r = not c % 2 if is_indent else c % 2
            r = min(row - 1, r)

        a = model.goo_d.get((r, c))
        if a:
            a = a.cell
            select_rect(j, a.x, top, 1., h, option=CHANNEL_OP_ADD)

    if a:
        # Is the last line, the enclosing column line.
        select_rect(j, a.x + a.w, top, 1., h, option=CHANNEL_OP_ADD)
    if not pdb.gimp_selection_is_empty(j):
        z = add_layer(j, maya.group, 0, "Grid")
        z.opacity = 66.

        color_selection_default(z, fy.GRID_COLOR)
        return z


class Type(ModelGroup):
    """
    Assign Plan and Work delegates for view run processing.
    Keep the Model up-to-date with Cell/Type change.
    """

    def __init__(self, **d):
        ModelGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)
        baby = self.item.model.baby

        if self.item.model.model_type in md.ONE_CELL:
            self.latch(baby, (si.RECTANGLE_CALC, self.on_sequence_change))
            self.latch(Ring.gob, (si.RESIZE, self.on_sequence))

        else:
            # Respond to Model's Canvas change.
            self.latch(baby, (si.CANVAS_MARGIN_CALC, self.on_sequence_change))
            if ok.PER in self.widget_d:
                self.latch(
                    self.widget_d[ok.PER], (si.PER_CHANGE, self.update_model)
                )

        self.latch(self.booth, (si.VOTE_CHANGE, self.update_model))
        self.latch(self, (si.SEQUENCE, self.on_sequence))

    def do(self):
        """
        Override the AnyGroup function so that Past's view Signal can be sent.
        """
        p = self.item.model.past.emit

        super(Type, self).do()
        p(si.CELL_RECT_VIEW, Run.i)
        if (
            not find_cell_margin(self.nav_k) and
            not find_cell_shift(self.nav_k)
        ):
            p(si.CELL_SHIFT_VIEW, Run.i)
            p(si.CELL_MARGIN_VIEW, Run.i)

    def update_model(self, *_):
        """Respond to change in the Cell/Type Preset."""
        self.item.model.baby.give(si.CELL_RECT_CHANGE, (self.value_d, False))

    def on_sequence(self, *_):
        """
        Update the Model.
        _: tuple
            (AnyGroup -> Sent the Signal., list ->
            [Plan vote, Work vote])
        """
        self.item.model.baby.feed(si.CELL_RECT_CHANGE, (self.value_d, True))


class Chi(Maya):
    """Factor Plan and Work layer output."""
    issue_q = 'matter', 'per'
    vote_type = vo.MAIN

    def __init__(self, any_group, view_i, put):
        Maya.__init__(self, any_group, view_i, put, ())
        self.reset_issue()


class Plan(Chi):
    """Manage Draft and Plan layer output for a Cell/Type step."""

    def __init__(self, any_group):
        Chi.__init__(
            self,
            any_group,
            0,
            ((make_cast_group, 'group'), (check_matter, 'matter'))
        )

        self.do_matter = draw_grid
        self.nav_k = any_group.nav_k
        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.GRID)

        self.set_issue()
        self.latch(planner, (fy.SIGNAL_D[ak.GRID], self.on_grid_plan_change))

    def do(self):
        """Manage layer output during a view run."""
        self.go = self.is_planned
        self.realize_vote()

    def on_grid_plan_change(self, _, arg):
        """
        Receive a Signal when the Planner Grid option
        is activated. Update 'go' dependency.

        _: PlanOption
            Sent the signal.

        arg: tuple
            (the value of the Margin CheckButton, its change state)
        """
        self.is_planned, m = arg

        self.any_group.accept_vote(0, ok.IS_PLANNED, vo.MATTER, m)
        self.take_vote(self.any_group.vote_q[0])


class Work(Chi):
    """Manage layer output for the Cell/Type step."""
    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1, ())

    def do(self):
        # no layer output
        self.reset_issue()
