#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Issue as vo
from roller_constant_key import Option as ok, SubMaya as sm
from roller_maya import Maya
from roller_preset_lookup import CLASS_FRAME, CLASS_BACKDROP_STYLE
from roller_one_extract import get_option_list_choice


class OptionList(Maya):
    """
    The Backdrop Style and the Frame Button use
    an OptionList to manage their sub-types.
    """
    issue_q = 'switch',

    def __init__(self, any_group, super_maya, path_prefix, lookup_d):
        """
        any_group: AnyGroup
        super_maya: Maya
        path_prefix: tuple
            (Option key, ...)
            Are keys to a sub-vote dict in the super Maya's vote dict.

        lookup_d:
            {Backdrop Style key or Frame key: its output producing class}
        """
        self._maya_type = None
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self._lookup_d = lookup_d
        self._path_prefix = path_prefix

        Maya.__init__(self, any_group, 1, (), vo.NO_VOTE)
        self.is_frame = lookup_d == CLASS_FRAME

    def do(self, value_d, is_change, z=None):
        """
        Manage layer output during a view run.

        value_d: dict
            OptionList Preset

        is_change: bool
            Is the state of change of the super Maya's matter and mask.

        z: layer
            Backing output
        """
        def _die():
            _link = self.sub_maya.get(sm.LINK)
            if _link:
                _link.die()
                self.sub_maya.pop(sm.LINK)
            self._maya_type = None

        # Preset key, 'k'; Preset value dict, 'd'
        # The Preset is either a sub-Backdrop Style or a sub-Frame.
        k, d = get_option_list_choice(value_d)

        maya_type = self._lookup_d[k] if k in self._lookup_d else None

        if sm.LINK in self.sub_maya and maya_type != self._maya_type:
            # The Maya type changed. Remove the old output.
            _die()

        if maya_type:
            self.go = value_d[ok.SWITCH]

            if self.is_frame:
                self.go &= bool(self.super_maya.matter)

            if self.go:
                if sm.LINK not in self.sub_maya:
                    self.sub_maya[sm.LINK] = maya_type(
                        self.any_group, self, self._path_prefix
                    )

                # Style adds the Backing layer, 'z'
                q = (d, is_change) if self.is_frame else (z, d, is_change)
                self.sub_maya[sm.LINK].do(*q)
            else:
                _die()
        self._maya_type = maya_type


class Frame(OptionList):
    """Process change for a Frame Preset."""

    def __init__(self, *arg):
        """
        arg: tuple
            OptionList spec
        """
        OptionList.__init__(self, *arg + (CLASS_FRAME,))


class BackdropStyle(OptionList):
    """Process change for a Backdrop Style Preset."""

    def __init__(self, *arg):
        """
        arg: tuple
            OptionList spec
        """
        OptionList.__init__(self, *arg + (CLASS_BACKDROP_STYLE,))
