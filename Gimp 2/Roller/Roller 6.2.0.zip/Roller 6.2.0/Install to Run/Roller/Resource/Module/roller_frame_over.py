#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, FILL_PATTERN, pdb   # type: ignore
from roller_a_contain import Globe, Path, Run
from roller_constant_for import Frame as ff
from roller_constant_key import Material as ma, Option as ok, SubMaya as sm
from roller_frame import do_selection
from roller_frame_alt import OverlapWrap
from roller_def_access import get_default_value
from roller_fu import (
    add_layer,
    image_copy_all,
    get_select_coord,
    load_selection,
    make_clouds,
    paste_layer,
    select_z,
    select_rect,
    shape_clipboard,
    verify_layer
)
from roller_image_pic import Pic
from roller_image_grind import ref_get_image
from roller_image_single import SINGLE_FILE_PATH, Single
from roller_maya_add import Add
from roller_maya_build import Build, SubBuild
from roller_maya_layer import check_matter, check_mix_basic, make_group_overlay
from roller_maya_light import Light
from roller_one_wip import Wip
from roller_view_hub import (
    color_layer_default,
    do_mod,
    draw_gradient,
    get_gradient_points,
    set_fill_context_default,
    set_gimp_pattern
)
from roller_view_real import get_light, mask_sub_maya
import os

"""
Define 'frame_over' as a Maya-subtype
for managing a variation of Frame type.
"""


def apply_clouds(__, z, d, _):
    """
    Make clouds for am overlay selection.

    __: Maya
    z: layer
        Is frame.

    d: dict
        Over Preset

    _: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        with overlay material
    """
    make_clouds(z, int(d[ok.SEED] + Globe.seed))
    return z


def apply_color(__, z, d, _):
    """
    Color the overlay.

    __: Maya
    z: layer
        Is frame.

    d: dict
        Over Preset

    _: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        overlay
    """
    color_layer_default(z, d[ok.COLOR_1])
    return z


def apply_gradient(__, z, d, _):
    """
    Color the overlay with a gradient.

    __: Maya
    z: layer
        Is frame.

    d: dict
        Over Preset

    _: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        overlay
    """
    j = Run.j
    x, y, x1, y1 = get_select_coord(j)
    w, h = x1 - x, y1 - y
    e = get_default_value("Gradient Fill")

    e.update(d)

    e[ok.GRADIENT] = d[ok.GRADIENT]
    start_x, end_x, start_y, end_y = \
        get_gradient_points(d, x - Wip.x, y - Wip.y, w, h)

    select_rect(j, x, y, w, h)
    draw_gradient(z, e, start_x, start_y, end_x, end_y)
    return z


def apply_image(maya, z, *_):
    """
    Apply an image to the overlay.

    maya: SubBuild
    z: layer
        Has the frame.

    _: tuple
        d: dict
            Over Preset

        k: tuple
            (row, column) of int
            cell index and Goo key

    Return: layer
        overlay
    """
    j = Run.j
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]

    # frame index, '2'
    j1 = ref_get_image(maya.any_group, maya.cast.k, 2)

    if j1:
        image_copy_all(j1)
        shape_clipboard(x1 - x, y1 - y)

        z1 = paste_layer(z)

        pdb.gimp_layer_set_offsets(z1, x, y)
        z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
    return z


def apply_pattern(__, z, d, _):
    """
    Paint the overlay with a pattern.

    __: Maya
    z: layer
        Receive the overlay.

    d: dict
        Over Preset

    _: tuple
        (row, column) of int
        cell index and Goo key
        not used

    Return: layer
        overlay
    """
    set_fill_context_default()
    set_gimp_pattern(d[ok.PATTERN])

    # x and y fill origin point, '0., 0,'
    pdb.gimp_drawable_edit_bucket_fill(z, FILL_PATTERN, .0, .0)
    return z


def apply_plasma(__, z, d, _):
    """
    Paint the overlay with plasma.

    _: Maya
    z: layer
        Receive the plasma.

    d: dict
        Over Preset

    _: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        overlay
    """
    j = Run.j

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(
        j, z,
        int(d[ok.SEED] + Globe.seed),
        1.                                 # lowest turbulence
    )
    return z


def do_matter(maya):
    """
    Make a frame.

    maya: Over
    Return: layer or None
        Over/Stencil 'matter'
    """
    if maya.value_d[ok.TYPE] != "None":
        return do_selection(
            maya, do_sel, embellish, "Material", is_clear=False
        )


def do_overlay(maya):
    """
    Make an overlay layer for the Stencil.

    maya: Overlay
    Return: layer or None
        overlay
    """
    def _select_rect():
        _x, _y, _x1, _y1 = get_select_coord(j)
        select_rect(j, _x, _y, _x1 - _x, _y1 - _y)

    j = Run.j

    # Over Preset dict, 'd'
    d = maya.value_d

    super_ = maya.cast
    n = d[ok.TYPE]
    if n in ROUTE_COLOR:
        z = add_layer(j, maya.group, get_light(maya), "Material")

        # Check to see if the caller is a grid, 'main_q'.
        if hasattr(super_, 'main_q') and n in ROUTE_GRID:
            for r, c in super_.main_q:
                sel = maya.model.get_image_sel((r, c))

                load_selection(j, sel)
                _select_rect()
                if not pdb.gimp_selection_is_empty(j):
                    z = ROUTE_GRID[n](maya, z, d, (r, c))
            if z:
                do_mod(z, d[ok.BRW][ok.MOD])

        else:
            select_z(super_.matter)
            _select_rect()
            if not pdb.gimp_selection_is_empty(j):
                z = ROUTE_COLOR[n](maya, z, d, super_.k)
                if z:
                    do_mod(z, d[ok.BRW][ok.MOD])
        return verify_layer(z)


def do_sel(maya, z):
    """
    Make a frame for a selection.

    maya: Maya
    z: layer
        Receive Stencil material
    """
    j = Run.j

    # Over Preset dict, 'd'
    d = maya.value_d
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]

    # Get the GIMP image.
    # Frame index, '1'
    j1 = get_frame_image(d)

    if j1:
        image_copy_all(j1)
        shape_clipboard(x1 - x, y1 - y)

        z = paste_layer(z, n="Frame")

        pdb.gimp_layer_set_offsets(z, x, y)
        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
    return z


def embellish(_, z):
    """
    Is a callback for 'do_selection'.

    _: Maya
    """
    return z


def get_frame_image(d):
    """
    Retrieve a GIMP image corresponding with Stencil/Type.

    d: dict
        Over Preset

    Return: GIMP image or None
        Stencil
    """
    if d[ok.TYPE] != "None":
        e = Over.frame_d
        n = d[ok.TYPE]
        single = e.get(n)

        if single is None:
            file_path = "{}{}{}.png".format(Path.frame, os.path.sep, n)
            e[n] = single = Single(file_path, SINGLE_FILE_PATH)
            j = single.get_image()
            Pic.opened_q.append(j)

        else:
            j = single.get_image()
        return j


class OverOverlay(SubBuild):
    """
    Process change for an overlay layer.
    Change its blend with its super Maya mask.
    """
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_overlay, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        """
        super_maya: Maya
            Is the enclosing Maya.

        k_path: tuple
            (Option key, ...)
            Are path key to its vote dict.

        material: string
            Material key
        """
        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.IMAGE_CHOICE,),
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.BRW, ok.MOD, ok.BLUR_D)
            ],
            do_overlay
        )
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.OVER + ma.OVERLAY)

    def do(self, d, is_change, is_mask):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        is_change: bool
            If it is True, then a mask is drawn on the Color layer.

        is_mask: bool
            Is True if the frame Maya has change.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize()

        if self.matter:
            if self.is_matter or is_mask:
                mask_sub_maya(
                    self.super_maya.sub_maya[sm.WRAP].matter, self.matter
                )
            self.sub_maya[sm.LIGHT].do(is_change)

        else:
            self.die()
        self.reset_issue()


class Over(Build):
    # {Stencil Type: Single}
    frame_d = {}

    is_seeded = True
    put = issue_q = ()
    kind = material = ma.OVER
    overlay_k = ok.OVERLAY_OV
    wrap_k = ok.STENCIL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        Build.__init__(self, any_group, super_maya, k_path, do_matter)

        self.sub_maya[sm.WRAP] = OverlapWrap(
            any_group,
            self,
            [k_path, k_path + (ok.BRW, self.wrap_k)],
            do_matter
        )
        self.sub_maya[sm.OVERLAY] = OverOverlay(
            any_group, self, k_path + (ok.BRW, ok.OVERLAY_OV)
        )
        self.sub_maya[sm.ADD] = Add(
            any_group, self.sub_maya[sm.WRAP], k_path + (ok.BRW, ok.ADD)
        )

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            Bevel Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        m = is_change
        wrap = self.sub_maya[sm.WRAP]

        self.realize()

        m |= wrap.do(d[ok.BRW][self.wrap_k], is_change)

        if wrap.matter:
            self.sub_maya[sm.OVERLAY].do(d[ok.BRW][ok.OVERLAY_OV], m, m)
            self.sub_maya[sm.ADD].do(
                d[ok.BRW][ok.ADD], m, m, is_back, wrap.group
            )

        else:
            self.die()
        self.reset_issue()


# Are Over types that are applied to each cell individually.
ROUTE_GRID = {
    ff.GRADIENT: apply_gradient,
    ff.IMAGE: apply_image,
}

# Are Over types that are applied one time.
ROUTE_COLOR = {
    ff.CLOUDS: apply_clouds,
    ff.COLOR: apply_color,
    ff.GRADIENT: apply_gradient,
    ff.IMAGE: apply_image,
    ff.PATTERN: apply_pattern,
    ff.PLASMA: apply_plasma
}
