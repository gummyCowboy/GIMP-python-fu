#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from random import randrange
from roller_a_contain import Cat, Deco, Run
from roller_constant_for import Deco as dc
from roller_constant_key import Option as ok
from roller_view_hub import brush_stroke
from roller_view_preset import combine_seed

"""Define 'deco_paint' as having Model/Branch/Leaf paint function."""


def paint(z, d, n):
    """
    Paint Fringe/Type material onto a
    layer with a provided selection limitation.

    z: layer
        Receive paint.

    d: dict
        Fringe Preset
    """
    def _do_multi_color():
        """
        Set the foreground color for the brush to use.
        Rotate through the multiple color option.
        """
        pdb.gimp_context_set_foreground(color_q[Deco.color_i])
        Deco.color_i = Deco.color_i + 1 \
            if Deco.color_i < max_i else 0

    def _do_random_colors():
        """
        Set the foreground color to a random color which the stroke brush uses.
        """
        pdb.gimp_context_set_foreground(
            tuple([randrange(256) for _ in range(3)])
        )

    j = Run.j
    e = d[ok.RW1][ok.BRUSH_D]
    callback = None

    if n == dc.MULTI_COLOR:
        color_q = d[ok.COLOR_6]
        max_i = d[ok.COLOR_COUNT] - 1

        if max_i:
            Deco.color_i = 0
            callback = _do_multi_color
        else:
            pdb.gimp_context_set_foreground(color_q[0])

    elif n == dc.AS_IS:
        pdb.gimp_context_set_foreground(Cat.foreground)

    elif n == dc.RANDOM_COLORS:
        callback = _do_random_colors

    combine_seed(e)
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_selection_shrink(j, int(d[ok.CONTRACT]))
    if not pdb.gimp_selection_is_empty(j):
        pdb.gimp_context_set_opacity(e[ok.OPACITY])
        pdb.plug_in_sel2path(j, z)
        if j.active_vectors:
            for stroke in j.active_vectors.strokes:
                brush_stroke(z, e, e[ok.BRUSH], stroke, callback)

            # Remove, from the image, the path created by 'plug_in_sel2path'.
            pdb.gimp_image_remove_vectors(j, j.active_vectors)
