#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_INTERSECT, CHANNEL_OP_REPLACE, pdb
)
from roller_a_contain import Deco, Run
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    coloring, ready_canvas_rect, ready_shape, transform_foam
)
from roller_deco_output import (
    get_deck, exit_deck_type, exit_one_type, init_deco_type
)
from roller_deco_paint import paint
from roller_deco_router import create_facial_main, create_facial_per
from roller_fu import (
    add_layer,
    clear_inverse_selection,
    load_selection,
    select_z,
    select_rect,
    select_shape
)
from roller_view_deck import Deck
from roller_view_hub import do_mod
from roller_view_real import get_light

"""Define 'deco_fringe' as having Model/Branch/Fringe output function."""


def apply_material(j, z, n, arg, p):
    """
    Apply Fringe/Type material to a selection.

    j: Gimp Image
        WIP

    z: layer
        Has raw Fringe material.

    n: string
        Fringe/Type

    arg: tuple
        Fringe/Type specific

    p: function
        Call to apply Fringe/Type material to a selection.
    """
    # As Is and Multi-Color are no ready-to-go.
    if n not in dc.NO_APPLY:
        select_z(z)
        pdb.gimp_image_remove_layer(j, z)
        return p(*arg)
    return z


def create_facial(j, maya, d, arg, p):
    """
    Process a Face/Fringe item.

    j: Gimp Image
        WIP

    maya: Maya
        'maya_fringe' variety

    d: dict
        Fringe Preset

    arg: tuple
        Fringe/Type specific

    p: function
        Call to make deco branch-type/Type layer output.
    """
    k = maya.k
    model = maya.model
    n = d[ok.TYPE]
    is_color = coloring(n)
    rect = maya.rect = model.get_facing_rect(k)
    Deco.shape = model.get_facing_form(k)
    group = maya.group if n == dc.COLOR else get_deck(arg).get_group()
    z = add_layer(j, group, 0, n)

    select_rect(j, *rect)
    paint_sel(j, z, d, n)

    # Create a transformed selectable.
    z = transform_foam(rect, z, model.get_facing_foam(k))

    # Create a rectangular transformed material.
    if not is_color:
        select_rect(j, *rect)

    else:
        pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)
        if not maya.is_face:
            select_rect(
                j,
                *maya.model.goo_d[maya.k[:2]].shift.rect,
                option=CHANNEL_OP_INTERSECT
            )

    z1 = p(*arg)

    if z1:
        if not is_color:
            z1 = transform_foam(maya.rect, z1, model.get_facing_foam(k))

            pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)
            clear_inverse_selection(z1)

        pdb.gimp_image_remove_layer(j, z)
        return z1

    # As-Is, Multi-Color
    return z


def create_facing(j, maya, d, arg, p):
    """
    Process a Facing/Fringe item.

    j: Gimp Image
        WIP

    maya: Maya
        'maya_fringe' variety

    d: dict
        Fringe Preset

    arg: tuple
        Fringe/Type specific

    p: function
        Call to apply Fringe to a selection.

    Return: layer or None
        Fringe material
    """
    z = create_facial(j, maya, d, arg, p)

    if d[ok.TYPE] != dc.COLOR:
        select_rect(j, *maya.model.get_shift_rect(maya.k[:2]))
        clear_inverse_selection(z)
    return z


def do(maya, make):
    """
    Make Fringe material. If the view run is a Plan-type,
    adjust the option settings to produce Plan output.

    maya: Maya
        'maya_fringe' variety

    make: function
        Create Fringe layer.

    Return: layer or None
        matter
    """
    d = maya.value_d

    if not Run.i:
        # Preserve.
        type_ = d[ok.TYPE]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = {
            ny.CELL: fy.CELL_FRINGE_COLOR,
            ny.CANVAS: fy.CANVAS_FRINGE_COLOR,
            ny.FACE: fy.FACE_FRINGE_COLOR,
            ny.FACING: fy.FACE_FRINGE_COLOR
        }[maya.any_group.render_key[-2]]

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.i:
        # Restore.
        d[ok.TYPE] = type_
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Make Canvas/Fringe output.

    maya: Maya
        'maya_fringe' variety

    Return: layer or None
        Fringe material
    """
    return do(maya, make_canvas)


def do_cell_main(maya):
    """
    Make main Cell/Fringe.

    maya: Maya
        'maya_fringe' variety

    Return: layer or None
        Fringe material
    """
    return do(maya, make_cell_main)


def do_cell_per(maya):
    """
    Make Cell/Fringe/Per layer output.

    maya: Maya
        'maya_fringe' variety

    Return: layer or None
        Fringe material
    """
    return do(maya, make_cell_per)


def do_face_main(maya):
    """
    Draw main Face/Fringe.

    maya: Maya
        'maya_fringe' variety

    Return: layer or None
        Fringe material
    """
    return do(maya, make_face_main)


def do_face_per(maya):
    """
    Make Face/Fringe/Per layer output.

    maya: Maya
        'maya_fringe' variety

    Return: layer or None
        Fringe material
    """
    return do(maya, make_face_per)


def do_facing_main(maya):
    """
    Make Face/Fringe for main.

    maya: Maya
        'maya_fringe' variety

    Return: layer or None
        Fringe material
    """
    return do(maya, make_facing_main)


def do_facing_per(maya):
    """
    Draw Facing/Fringe/Per layer output.

    maya: Maya
        'maya_fringe' variety

    Return: layer or None
        Fringe material
    """
    return do(maya, make_facing_per)


def make_canvas(maya, d):
    """
    Draw Canvas/Fringe material.

    maya: Maya
        'maya_fringe' variety

    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    j = Run.j
    n = d[ok.TYPE]
    arg, p = init_deco_type(n, j, maya, maya.group, d, get_light(maya), False)

    ready_canvas_rect(maya, d, option=None)
    return exit_one_type(
        paint_shape(j, add_layer(j, maya.group, 0, n), d, n, arg, p)
    )


def make_cell_main(maya, d):
    """
    Make main Cell/Fringe.

    maya: Maya
        'maya_fringe' variety

    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    def _do_many_material():
        """
        The cells have the same Fringe material, but
        the material has to be applied cell-by-cell.
        """
        arg, p = init_deco_type(
            n, j, maya, maya.group, d, get_light(maya), True
        )
        deck = get_deck(arg)

        for _k in maya.main_q:
            maya.k = _k

            ready_shape(maya, d, option=None)
            paint_shape(j, deck.add(), d, n, arg, p)
        return exit_deck_type(n, *arg)

    def _do_one_material():
        """
        The cells have the same Fringe material,
        so the output is combined on one layer.
        """
        deck = Deck(j, maya.group, get_light(maya), n)

        for _k in maya.main_q:
            maya.k = _k

            ready_shape(maya, d)
            paint_sel(j, deck.add(), d, n)

        _z = deck.merge()
        if _z:
            arg, p = init_deco_type(
                n, j, maya, maya.group, d, get_light(maya), False
            )
            return apply_material(j, _z, n, arg, p)

    j = Run.j
    n = d[ok.TYPE]

    if n in dc.FRINGE_PER_TYPE:
        return _do_many_material()
    else:
        # All the Fringe is the same
        # material and is applied one time.
        return _do_one_material()


def make_cell_per(maya, d):
    """
    Make Cell/Fringe/Per.

    maya: Maya
        'maya_fringe' variety

    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    j = Run.j
    n = d[ok.TYPE]
    arg, p = init_deco_type(n, j, maya, maya.group, d, get_light(maya), False)

    ready_shape(maya, d)
    return exit_one_type(
        paint_shape(j, add_layer(j, maya.group, 0, n), d, n, arg, p)
    )


def make_face_main(maya, d):
    """
    Make main Face/Fringe.

    maya: Maya
        'maya_fringe' variety

    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    return create_facial_main(maya, d, create_facial)


def make_face_per(maya, d):
    """
    Make Face/Fringe/Per.

    maya: Maya
        'maya_fringe' variety

    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    return create_facial_per(maya, d, create_facial)


def make_facing_main(maya, d):
    """
    Create main Facing/Fringe.

    maya: Maya
        'maya_fringe' variety

    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    return create_facial_main(maya, d, create_facing)


def make_facing_per(maya, d):
    """
    Make Facing/Fringe/Per.

    maya: Maya
        'maya_fringe' variety

    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    return create_facial_per(maya, d, create_facing)


def paint_shape(j, z, d, n, arg, p):
    """
    Paint Fringe and apply material.

    j: Gimp Image
        WIP

    z: layer
        Receive paint.

    d: dict
        Fringe Preset

    arg: tuple
        Fringe/Type specific

    p: function
        Apply Fringe/Type material to a selection.

    Return: layer or None
        Fringe material
    """
    select_shape(j, Deco.shape)
    paint_sel(j, z, d, n)
    return apply_material(j, z, n, arg, p)


def paint_sel(j, z, d, n):
    """
    Paint Fringe around a selection boundary. The painted
    Fringe is clipped to the existing selection.

    j: Gimp Image
        WIP

    z: layer
        Receive raw Fringe paint.

    d: dict
        Fringe Preset

    n: string
        Fringe/Type
    """
    if not pdb.gimp_selection_is_empty(j):
        sel = pdb.gimp_selection_save(j)

        paint(z, d, n)
        select_z(z)
        load_selection(j, sel, option=CHANNEL_OP_INTERSECT)
        clear_inverse_selection(z)
        pdb.gimp_image_remove_channel(j, sel)
