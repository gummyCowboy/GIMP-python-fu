#!/usr/bin/env python
# -*- coding: utf-8 -*-
# noinspection PyUnresolvedReferences
from gimpfu import (   # type: ignore
    HISTOGRAM_VALUE, LAYER_MODE_OVERLAY, CLIP_TO_IMAGE, pdb
)
from roller_a_contain import Globe
from roller_constant_for import Bump as fb
from roller_constant_key import Option as ok
from roller_maya_build import SubBuild
from roller_maya_layer import check_matter, check_mix_basic
from roller_fu import clone_layer, clone_opaque_layer, layer_has_pixel
from roller_a_gegl import emboss, engrave, video_degradation
from roller_view_real import mask_from_maya

"""Include function and class used to make Bump layer output."""


def do_bump_matter(maya):
    """
    Make a Bump layer.

    Return: layer or None
        Bump material
    """
    d = maya.value_d
    z = maya.super_maya.matter
    if layer_has_pixel(z):
        return make_bump(z, d)


def do_cloth(j, z, d):
    pdb.script_fu_clothify(
        j, z,
        d[ok.BLUR_X], d[ok.BLUR_Y],
        Globe.azimuth,
        max(1., min(90., Globe.elevation)),
        min(50., d[ok.DEPTH])
    )
    return z


def do_crosshatch(j, z, d):
    pdb.plug_in_gimpressionist(j, z, "Crosshatch")
    return z


def do_edge(j, z, d):
    # wrap, '1'; Sobel, '0'
    pdb.plug_in_edge(z.image, z, d[ok.AMOUNT], 1, 0)
    return z


def do_nada(j, z, d):
    return z


def do_nano(j, z, d):
    video_degradation(z, 'dots')

    z1 = clone_layer(z, n="Nano")
    z1.mode = LAYER_MODE_OVERLAY
    z1.opacity = 83.

    engrave(z1, 3)
    pdb.gimp_drawable_curves_spline(
        z1,
        HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .5, 1., 1.)
    )
    return pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)


# Initialize once.
# {Bump/Type: Bump output function}
BUMP_ROUTE = {
    fb.CLOTH: do_cloth,
    fb.CROSSHATCH: do_crosshatch,
    fb.EDGE: do_edge,
    fb.NANO: do_nano,
    fb.NOISE: do_nada
}


def make_bump(z, d):
    """
    Create a Bump layer given a Bump Preset.

    z: layer
        Clone and bump.

    d: dict
        Bump Preset

    Return: layer
        Bump output
    """
    z1 = None

    if z:
        j = z.image
        f = d[ok.NOISE]
        z1 = clone_opaque_layer(z, n="Bump")

        # Curves won't work with a selection.
        pdb.gimp_selection_none(j)

        z1 = BUMP_ROUTE[d[ok.TYPE]](j, z1, d)

        if f:
            # red, green, and blue noise, 'noise'
            pdb.plug_in_rgb_noise(
                j, z1,
                1,                  # independent
                0,                  # not correlated
                f,
                f,
                f,
                .0                  # zero noise
            )

        emboss(z1, int(Globe.azimuth), int(Globe.elevation), int(d[ok.DEPTH]))

        if d[ok.INVERT]:
            # no linear, '0'
            pdb.gimp_drawable_invert(z1, 0)
        z1.name = z.name + " Bump"
    return z1


class Bump(SubBuild):
    """Manage Bump layer output for a Bump Preset."""
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (check_matter, 'matter'), (check_mix_basic, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            This Maya's 'matter' layer alpha creates an output mask.

        k_path: tuple or list
            (Option key, ...)
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, do_bump_matter)

    def do(self, d, is_change, is_mask):
        """
        Manage layer output during a view run.

        d: dict or None
            Bump Preset
            Maybe None if 'go' is False.

        is_change: bool
            Is True if the source layer for
            the Bump material has matter change.

        is_mask: bool
            Is True if the source layer's mask changed.

        Return: bool
            Is True if the Bump changed.
        """
        self.value_d = d
        self.go = d[ok.SWITCH]

        if self.go:
            self.is_matter |= is_change
            m = self.is_matter or is_mask

        else:
            m = bool(self.matter)

        self.realize()

        if m:
            mask_from_maya(self.super_maya, self.matter)

        self.reset_issue()
        return m
