#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb   # type: ignore
from roller_a_contain import Run
from roller_fu import load_selection
from roller_mask_router import (
    attach_mask_sel,
    create_face_main_mask,
    create_facing_main_mask,
    create_face_per_mask,
    make_facing_per_mask,
    make_mask_sel
)


def mask_cell_main(maya, d):
    """
    Mask Cell/Image main layer.

    maya: Maya
        'maya_image' variety

    d: dict
        Mask Preset

    Return: layer or None
        mask material
    """
    j = Run.j
    z = maya.matter
    sel = None
    model = maya.model

    pdb.gimp_selection_none(j)

    for k in maya.main_q:
        maya.k = k
        image_sel = model.get_image_sel(k)
        if image_sel:
            load_selection(j, image_sel)

            if not pdb.gimp_selection_is_empty(j):
                make_mask_sel(j, maya, d)

            if sel:
                load_selection(j, sel, option=CHANNEL_OP_ADD)
                pdb.gimp_image_remove_channel(j, sel)
            if not pdb.gimp_selection_is_empty(j):
                sel = pdb.gimp_selection_save(j)

    if sel:
        pdb.gimp_image_remove_channel(j, sel)
    return attach_mask_sel(z)


def mask_face_main(maya, d):
    """
    Mask image on Face/Image main layer.

    maya: Mask
        'maya_image' variety

    d: dict
        Mask Preset

    Return: layer or None
        mask material
    """
    return create_face_main_mask(maya, d)


def mask_face_per(maya, d):
    """
    Mask image on Face/Per layer.

    maya: Mask
        'maya_image' variety

    d: dict
        Mask Preset

    Return: layer or None
        mask
    """
    return create_face_per_mask(maya, d)


def mask_facing_main(maya, d):
    """
    Mask image on main Facing layer.

    maya: Mask
        'maya_image' variety

    d: dict
        Mask Preset

    Return: layer or None
        mask material
    """
    return create_facing_main_mask(maya, d)


def mask_facing_per(maya, d):
    """
    Mask image on Facing/Per layer.

    maya: Mask
        'maya_image' variety

    d: dict
        Mask Preset

    Return: layer or None
        mask
    """
    return make_facing_per_mask(maya, d)
