#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_model_goo import Goo
from roller_polygon import calc_pin_xy, make_coord_list


def calc_miter_square(model, o):
    """
    For Model cell, calculate 'cell' and 'merge'
    rectangle and their inscribed 'form' polygon.

    model: Model
    o: One
        Has converted Cell/Type reference in a readable format.

    Return: dict
        {value: [bool, bool]}
        {cell key: [Plan vote change, Work vote change]}
    """
    vote_d = {}
    did_cell = model.past.did_cell
    row, column = model.grid
    goo_d = model.goo_d
    x, y, canvas_w, canvas_h = model.canvas_pocket.rect

    if o.grid_type == gr.CELL_SIZE:
        # Correct cell size overflow.
        w = min(canvas_w, o.column_width)
        h = min(canvas_h, o.row_height)

        # grid size
        w1, h1 = w / 2., h / 2.
        s = w + (column - 1) * w1, h + (row - 1) * h1
        x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

    elif o.grid_type == gr.SHAPE_COUNT:
        # cell size
        w = canvas_w / (.5 + column * .5)
        h = canvas_h / (.5 + row * .5)
        w = min(w, h)
        w, h = w, w

        # grid size
        h1 = h / 2.
        s = column * h1 + h1, row * h1 + h1
        x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

    else:
        w = canvas_w / (.5 + column * .5)
        h = canvas_h / (.5 + row * .5)

    w1 = w / 2.
    h1 = h / 2.

    # [intersect coordinate, ...]
    q_x = make_coord_list(canvas_w, column + 2, x, span=w1)
    q_y = make_coord_list(canvas_h, row + 2, y, span=h1)

    for r_c in model.cell_q:
        r, c = r_c
        y, y1, y2 = q_y[r], q_y[r + 1], q_y[r + 2]
        x, x1, x2 = q_x[c], q_x[c + 1], q_x[c + 2]
        a = goo_d[r_c] = Goo(r_c)

        # Prevent round to zero with max 1.
        a.cell.rect = a.merged.rect = \
            x, y, max(1., x2 - x), max(1., y2 - y)

        a.form = x, y1, x1, y, x2, y1, x1, y2
        vote_d[r_c] = did_cell(r_c)
    return vote_d
