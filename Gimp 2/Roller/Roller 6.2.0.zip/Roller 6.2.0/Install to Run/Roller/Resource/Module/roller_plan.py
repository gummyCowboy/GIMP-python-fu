#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore

"""Define 'plan' as having common 'maya_plan' function."""


def add_text_layer(z, x, y, p):
    """
    Add a text layer to a group for Plan.

    z: text layer
        Has text.

    x, y: numeric acting as integer
        Place text at this topleft position.

    p: function
        Insert the layer into a group.
    """
    p(z)
    pdb.gimp_text_layer_set_color(z, (255, 255, 255))
    pdb.gimp_layer_set_offsets(z, int(x), int(y))
