#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Deco, Run
from roller_constant_for import Below as be, Signal as si
from roller_constant_key import Option as ok
from roller_fu import (
    clone_layer,
    invert_selection,
    remove_z,
    select_z,
    select_opaque,
    select_rect
)
from roller_maya import on_global
from roller_maya_build import SubBuild
from roller_maya_layer import check_matter, check_mix_basic
from roller_one_wip import Wip
from roller_view_hub import do_mod
from roller_view_real import clip_to_wip, clone_background, mask_from_maya

"""
Define 'maya_below' as a sub-Maya, option group owned,
class for managing the Below option's layer output.
"""


def do_below_matter(maya):
    """
    Do the Below output for the super Maya's matter layer.

    maya: Below
    Return: layer or None
        Below 'matter'
    """
    j = Run.j
    group = maya.super_maya.group
    d = maya.value_d

    # When there is no Below layer, 'z'.
    z = None

    if group:
        # Below 'matter' layer, 'z'
        if Deco.bg_z:
            z = clone_layer(Deco.bg_z)

        else:
            z = clone_background(group)

        z.name = group.name + " Below"

        select_rect(j, *Wip.get_rect())
        do_mod(z, d[ok.MOD])
        clip_to_wip(z)
    return z


class Below(SubBuild):
    """Manage Below layer output."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (check_matter, 'matter'), (check_mix_basic, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            It's 'matter' layer alpha becomes the output mask.
        """
        self.is_no_mask = False

        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path, k_path + (ok.MOD,), k_path + (ok.MOD, ok.BLUR_D)
            ] if isinstance(k_path, tuple) else
            k_path + [k_path[0] + (ok.MOD, ok.BLUR_D)],
            do_below_matter
        )
        self.latch(any_group, (si.BACK_CHANGE, self.on_back_change))

    def do(self, d, is_back, is_mask):
        """
        Manage layer output during a view run.

        d: dict or None
            Below Preset

        is_back: bool or None
            Is True when the background has change.

        is_mask: bool
            If True, then the Below is masked from its above layer.

        Return: bool
            Is True if Below changed.
        """
        def _select_matter(_z, option=None):
            _p = select_opaque if d[ok.OPAQUE] else select_z

            _p(_z, option=option)
            if is_invert:
                invert_selection(Run.j)

        # background changed flag, 'm'
        m = False

        self.value_d = d
        self.go = d[ok.SWITCH] and bool(self.super_maya.matter)

        if self.go:
            self.is_matter = self.is_matter or is_back

        else:
            # There's change if the matter layer is removed.
            m = bool(self.matter)

        self.realize()

        if self.matter and (self.is_matter or is_mask):
            is_invert = d[ok.TYPE] == be.INVERT_MASK

            if d[ok.TYPE] == be.MASK or is_invert:
                mask_from_maya(self.super_maya, self.matter, p=_select_matter)
                m = True
            else:
                z = self.matter.mask
                m = bool(z)
                remove_z(z)

        self.reset_issue()
        return m

    def on_back_change(self, _, i):
        """
        The background changed.

        _: AnyGroup
            Sent the Signal.

        i: int
            Plan or Work index
        """
        if i == self.view_i:
            arg = [None, None]
            arg[i] = True
            on_global(self, arg, ok.IS_BACK)
