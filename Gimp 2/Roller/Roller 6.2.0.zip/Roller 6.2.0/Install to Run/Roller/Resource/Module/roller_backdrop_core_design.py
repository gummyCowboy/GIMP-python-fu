#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (      # type: ignore
    CHANNEL_OP_ADD, LAYER_MODE_LIGHTEN_ONLY, LAYER_MODE_DARKEN_ONLY, pdb
)
from roller_a_contain import Cat, Run
from roller_constant_for import Backdrop as bs
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def_access import get_default_value
from roller_fu import (
    clear_selection,
    clear_inverse_selection,
    clone_layer,
    flip_layer,
    merge_layer_group,
    select_polygon,
    select_rect
)
from roller_maya_style import Style
from roller_one import make_rect_table
from roller_one_wip import Wip
from roller_view_hub import create_dual_gradient, do_gradient_for_layer, do_mod
from roller_view_real import add_sub_base_group, clip_to_wip
from roller_view_shadow import do_stylish_shadow

"""
Define 'backdrop/core_design' as a Maya-subtype
for managing a variation of backdrop style layer.
"""


def make_style(maya):
    """
    Do the Backdrop Style.

    maya: Style
    Return: layer
        Backdrop Style material
    """
    def _do_gradient(_n):
        """
        Draw a gradient.

        _n: string
            name of the gradient layer

        Return: layer
            gradient
        """
        _z = do_gradient_for_layer(e, group, 0)
        _z.name = _n

        pdb.gimp_image_reorder_item(j, _z, group, len(group.layers))
        return _z

    def _do_select():
        """Select an area defined by an array of points."""
        select_polygon(j, q, option=CHANNEL_OP_ADD)

    def _double(_n, _m=False):
        """
        Duplicate a layer and flip it depending on a flag.

        _n: string
            name of flipped layer

        _m: bool
            If it's True, the layer is flipped horizontally.
        """
        _z = clone_layer(z, n=_n)

        flip_layer(_z, is_h=_m)
        return _z

    j = Run.j
    d = maya.value_d
    gradients = Cat.gradient_list
    e = get_default_value(by.GRADIENT_FILL)
    row, column = int(d[ok.ROW]), int(d[ok.COLUMN])
    e[ok.GRADIENT] = d[ok.RW1][ok.GRADIENT]
    left_x, top_y, w, h = Wip.get_rect()
    center_x, center_y = Wip.center()
    color = tuple([255 - i for i in d[ok.COLOR_1]])

    e.update(d)
    pdb.gimp_selection_none(j)

    grid = make_rect_table((.0, .0, w, h), row, column)
    group = add_sub_base_group(maya)

    # Calculate the points using their relative position.
    y = h // 5. + top_y
    right_x = w + left_x
    bottom_y = h + top_y

    # The triangle is facing down.
    q = left_x, y, right_x, y, center_x, bottom_y

    e[ok.START_X], e[ok.START_Y] = (0, .5), (0, 1.)
    e[ok.END_X], e[ok.END_Y] = (0, .5), (0, .2)

    z = _do_gradient("Down Triangle")
    z.mode = LAYER_MODE_LIGHTEN_ONLY

    _do_select()
    clear_inverse_selection(z)
    clip_to_wip(do_stylish_shadow(z, intensity=50.))

    pdb.gimp_selection_none(j)

    z1 = _double("Up Triangle")
    z1.mode = LAYER_MODE_DARKEN_ONLY

    clip_to_wip(do_stylish_shadow(z1, intensity=50.))
    pdb.gimp_selection_none(j)

    # horizontal
    for r1 in range(0, row, 2):
        select_rect(
            j,
            left_x,
            grid[r1][0].y + top_y,
            w,
            grid[r1][0].h,
            option=CHANNEL_OP_ADD
        )

    clear_selection(z1)
    clip_to_wip(do_stylish_shadow(z1, intensity=50.))

    # row, 'a'
    a = grid[0]

    # vertical
    for c1 in range(0, column, 2):
        select_rect(
            j, a[c1].x + left_x, top_y, a[c1].w, h, option=CHANNEL_OP_ADD
        )

    clear_selection(z)
    do_stylish_shadow(z, intensity=50.)

    grad = e[ok.GRADIENT] = create_dual_gradient(
        by.CORE_DESIGN, d[ok.COLOR_1], color
    )
    e[ok.OFFSET] = 0

    # left
    e[ok.START_X] = 0, .0
    e[ok.START_Y] = e[ok.END_X] = e[ok.END_Y] = 0, .5

    pdb.gimp_selection_none(j)

    z = _do_gradient("Left")
    q = left_x, top_y, left_x, bottom_y, center_x, center_y

    _do_select()
    clear_inverse_selection(z)
    _double("Right", _m=True)

    # top
    e[ok.START_Y] = 0, .0
    e[ok.START_X] = e[ok.END_X] = e[ok.END_Y] = 0, .5
    z = _do_gradient("Top")
    q = left_x, top_y, right_x, top_y, center_x, center_y + 1

    _do_select()
    clear_inverse_selection(z)

    # bottom
    _double("Bottom")
    pdb.gimp_gradient_delete(grad)
    gradients.pop(-1)

    z = merge_layer_group(group)

    clip_to_wip(z)
    do_mod(z, d[ok.RW1][ok.MOD])
    return maya.rename_layer(z)


class CoreDesign(Style):
    """Create Backdrop Style output."""
    dependency = bs.INDEPENDENT

    def __init__(self, any_group, super_maya, k_path):
        k_path = [
            k_path,
            k_path + (ok.RW1,),
            k_path + (ok.RW1, ok.MOD),
            k_path + (ok.RW1, ok.MOD, ok.BLUR_D)
        ]
        Style.__init__(self, any_group, super_maya, k_path, make_style)
