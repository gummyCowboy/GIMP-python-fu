#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_INTERSECT, CHANNEL_OP_SUBTRACT, pdb
)
from roller_constant_for import Frame as ff
from roller_fu import get_select_bounds, select_rect, select_z

"""
Define 'frame_type' as collection of function for generating Wrap selection.
"""


def do_angular(j, z, w):
    """
    j: GIMP image
    z: layer or None
        Has cast.

    w: float
        Frame width

    Return: state of selection
    """
    pdb.gimp_context_set_antialias(0)

    for _ in range(int(w)):
        pdb.gimp_selection_grow(j, 1)
    if z:
        select_z(z, option=CHANNEL_OP_SUBTRACT)


def do_inside(j, z, w):
    """
    j: GIMP image
    z: layer
        Has cast.

    w: float
        Frame width

    Return: state of selection
    """
    pdb.gimp_selection_border(j, int(w))
    select_z(z, option=CHANNEL_OP_INTERSECT)


def do_overlap(j, _, w):
    """
    j: GIMP image
    _: layer
        Has cast.

    w: float
        Frame width

    Return: state of selection
    """
    pdb.gimp_selection_border(j, int(w))


def do_rectangle(j, z, w):
    """
    j: GIMP image
    z: layer or None
        Has cast.

    w: float
        Frame width

    Return: state of selection
    """
    is_sel, x, y, x1, y1 = get_select_bounds(j)

    if is_sel:
        select_rect(j, x - w, y - w, x1 + w + w - x, y1 + w + w - y)
        if z:
            select_z(z, option=CHANNEL_OP_SUBTRACT)


def do_rounded(j, z, w):
    """
    j: GIMP image
    z: layer
        Has cast.

    w: float
        Frame width

    Return: state of selection
    """
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_selection_border(j, int(w))
    select_z(z, option=CHANNEL_OP_SUBTRACT)


EXPAND_ROUTE = {
    ff.ANGULAR: do_angular,
    ff.INSIDE: do_rounded,
    ff.OVERLAP: do_rounded,
    ff.RECTANGLE: do_rectangle,
    ff.ROUNDED: do_rounded
}
WRAP_ROUTE = {
    ff.ANGULAR: do_angular,
    ff.INSIDE: do_inside,
    ff.OVERLAP: do_overlap,
    ff.RECTANGLE: do_rectangle,
    ff.ROUNDED: do_rounded
}


def expand_wrap(j, z, w, n):
    """
    Expand a Wrap selection depending on the Wrap/Type.

    j: GIMP image
        Has selection.

    z: layer
        Has cast.

    w: float
        expansion amount

    n: string
        Wrap Type
    """
    EXPAND_ROUTE[n](j, z, w)


def grow_wrap(j, z, w, n):
    """
    Expand a Wrap selection depending on the Wrap/Type.

    j: GIMP image
        Has selection.

    z: layer
        Has cast.

    w: float
        expansion amount
        Zero is allowed by selection function.

    n: string
        Wrap Type
    """
    WRAP_ROUTE[n](j, z, w)
