#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import (
    BackdropStyle as by,
    Frame as ek,
    Group as gk,
    ModelList as ml,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_def_backdrop_style import (
    ACRYLIC_SKY,
    BACK_GAME,
    CLAY_CHEMISTRY,
    COLOR_FILL,
    COLOR_GRID,
    CORE_DESIGN,
    CORNER_OVERLAP,
    CRYSTAL_CAVE,
    CUBE_PATTERN,
    CUBISM_COVER,
    DARK_FORT,
    DENSITY_GRADIENT,
    DROP_ZONE,
    ETCH_SKETCH,
    FADING_MAZE,
    FLOOR_SAMPLE,
    GALACTIC_FIELD,
    GLASS_GAW,
    GRADIENT_FILL,
    HISTORIC_TRIP,
    IMAGE_GRADIENT,
    LINE_STONE,
    LOST_MAZE,
    MAZE_BLEND,
    MEAN_COLOR,
    MYSTERY_GRATE,
    NOISE_RIFT,
    PAPER_WASTE,
    PATTERN_FILL,
    RAINBOW_VALLEY,
    RECT_PATTERN,
    ROCKY_LANDING,
    ROOF_TOP,
    SOFT_TOUCH,
    SPECIMEN_SPECKLE,
    SPIRAL_CHANNEL,
    SQUARE_CLOUD,
    STONE_AGE,
    TRAILING_VINE,
    TRIANGLE_REVERB,
    WAVE_FILL
)
from roller_def_backdrop import BACKDROP
from roller_def_cell_type import (
    TYPE_BOX, TYPE_CELL, TYPE_PYRAMID, TYPE_SIDEWALK, TYPE_STACK, TYPE_TABLE
)
from roller_def_frame import (
    BEVEL,
    BRUSHY,
    BURST,
    CAMO,
    CERAMIC,
    CHECKER,
    MAZE,
    CLEAR,
    CRUMBLE,
    DECAY,
    FENCE,
    GLUE,
    GRADUAL,
    HOLEY,
    JOINT,
    MECHA,
    MIRROR,
    OVER,
    OVERLAP,
    PIPE,
    RAD,
    STAINED,
    STRETCH,
    STRIPE,
    TAPE,
    WOBBLE
)
from roller_def_global import GLOBAL
from roller_def_gradient_light import GRADIENT_LIGHT, HEAT
from roller_def_property import PLANNER, PROPERTY
from roller_def_rectangle import RECTANGLE
from roller_def_dialog import (
    ADD,
    ADD_ABOVE,
    ADD_ALT,
    BACKING,
    BELOW,
    BASIC,
    BLUR_DIALOG,
    BRUSH_DIALOG,
    BRUSH_D1,
    BUMP,
    FILLER_CE,
    FILLER_CH,
    FILLER_MA,
    FILLER_FE,
    FILLER_HO,
    FILLER_MI,
    FILLER_ME,
    FILLER_RA,
    FILLER_S1,
    FILLER_S2,
    FILLER_S3,
    IMAGE_CHOICE,
    INNER_SHADOW,
    MARGIN,
    MASK,
    MOD,
    NOISE_D,
    OVERLAY_BE,
    OVERLAY_CA,
    OVERLAY_CO,
    OVERLAY_OV,
    RESIZE,
    SHADOW_1,
    SHADOW_2,
    STRIP,
    SWITCH_GROUP,
    SHADOW,
    SHADOW_BASIC,
    STENCIL,
    WRAP,
    WRAP_AB,
    WRAP_AL,
    WRAP_BE,
    WRAP_BU,
    WRAP_CL,
    WRAP_CR,
    WRAP_DE,
    WRAP_FI,
    WRAP_GL,
    WRAP_GR,
    WRAP_JO,
    WRAP_CA,
    WRAP_OL,
    WRAP_PA,
    WRAP_PI,
    WRAP_TA,
    WRAP_WO
)
from roller_def_model import (
    BORDER,
    CAPTION,
    FRINGE,
    IMAGE,
    LINE,
    PLAQUE,
    SHIFT
)
from roller_widget_entry import Entry
from roller_widget_model_list import ModelList

"""Organize Preset definition for program retrieval."""

BACKDROP_DEF = {
    by.ACRYLIC_SKY: ACRYLIC_SKY,
    by.BACK_GAME: BACK_GAME,
    by.CLAY_CHEMISTRY: CLAY_CHEMISTRY,
    by.COLOR_FILL: COLOR_FILL,
    by.COLOR_GRID: COLOR_GRID,
    by.CORE_DESIGN: CORE_DESIGN,
    by.CORNER_OVERLAP: CORNER_OVERLAP,
    by.CRYSTAL_CAVE: CRYSTAL_CAVE,
    by.CUBE_PATTERN: CUBE_PATTERN,
    by.CUBISM_COVER: CUBISM_COVER,
    by.DARK_FORT: DARK_FORT,
    by.DROP_ZONE: DROP_ZONE,
    by.DENSITY_GRADIENT: DENSITY_GRADIENT,
    by.ETCH_SKETCH: ETCH_SKETCH,
    by.FADING_MAZE: FADING_MAZE,
    by.FLOOR_SAMPLE: FLOOR_SAMPLE,
    by.GALACTIC_FIELD: GALACTIC_FIELD,
    by.GLASS_GAW: GLASS_GAW,
    by.GRADIENT_FILL: GRADIENT_FILL,
    by.HISTORIC_TRIP: HISTORIC_TRIP,
    by.IMAGE_GRADIENT: IMAGE_GRADIENT,
    by.LINE_STONE: LINE_STONE,
    by.LOST_MAZE: LOST_MAZE,
    by.MAZE_BLEND: MAZE_BLEND,
    by.MEAN_COLOR: MEAN_COLOR,
    by.MYSTERY_GRATE: MYSTERY_GRATE,
    by.NOISE_RIFT: NOISE_RIFT,
    by.PAPER_WASTE: PAPER_WASTE,
    by.PATTERN_FILL: PATTERN_FILL,
    by.RAINBOW_VALLEY: RAINBOW_VALLEY,
    by.RECT_PATTERN: RECT_PATTERN,
    by.ROCKY_LANDING: ROCKY_LANDING,
    by.ROOF_TOP: ROOF_TOP,
    by.SOFT_TOUCH: SOFT_TOUCH,
    by.SPECIMEN_SPECKLE: SPECIMEN_SPECKLE,
    by.SPIRAL_CHANNEL: SPIRAL_CHANNEL,
    by.SQUARE_CLOUD: SQUARE_CLOUD,
    by.STONE_AGE: STONE_AGE,
    by.TRAILING_VINE: TRAILING_VINE,
    by.TRIANGLE_REVERB: TRIANGLE_REVERB,
    by.WAVE_FILL: WAVE_FILL
}
DEFINE_MODEL = {}
FRAME_DEF = {
    ek.BASIC: BASIC,
    ek.BEVEL: BEVEL,
    ek.BRUSHY: BRUSHY,
    ek.BURST: BURST,
    ek.CAMO: CAMO,
    ek.CERAMIC: CERAMIC,
    ek.CHECKER: CHECKER,
    ek.MAZE: MAZE,
    ek.CLEAR: CLEAR,
    ek.CRUMBLE: CRUMBLE,
    ek.DECAY: DECAY,
    ek.FENCE: FENCE,
    ek.GLUE: GLUE,
    ek.GRADUAL: GRADUAL,
    ek.HOLEY: HOLEY,
    ek.JOINT: JOINT,
    ek.MECHA: MECHA,
    ek.MIRROR: MIRROR,
    ek.OVER: OVER,
    ek.OVERLAP: OVERLAP,
    ek.PIPE: PIPE,
    ek.RAD: RAD,
    ek.STAINED: STAINED,
    ek.STRETCH: STRETCH,
    ek.STRIPE: STRIPE,
    ek.TAPE: TAPE,
    ek.WOBBLE: WOBBLE
}

# Model________________________________________________________________________
MODEL_LIST = {
    wk.SUB: {
        ml.MODEL_DEF: {wk.VAL: []},
        ml.SHELVED: {wk.VAL: {}},
        ml.ACTIVE: {wk.VAL: {}},
    },
    wk.WIDGET: ModelList
}
MODEL = {ok.MODEL_LIST: MODEL_LIST}
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

MODEL_DEF = {
    gk.BORDER: BORDER,
    gk.CAPTION: CAPTION,
    gk.FRINGE: FRINGE,
    gk.IMAGE: IMAGE,
    gk.LINE: LINE,
    gk.PLAQUE: PLAQUE,
    gk.PROPERTY: PROPERTY,
    gk.RECTANGLE: RECTANGLE,
    gk.SHIFT: SHIFT,
    gk.TYPE_BOX: TYPE_BOX,
    gk.TYPE_CELL: TYPE_CELL,
    gk.TYPE_PYRAMID: TYPE_PYRAMID,
    gk.TYPE_SIDEWALK: TYPE_SIDEWALK,
    gk.TYPE_STACK: TYPE_STACK,
    gk.TYPE_TABLE: TYPE_TABLE,
    ok.PLANNER: PLANNER,
    ok.SHADOW: SHADOW
}
MODEL_NAME = {
    ok.RENAME_MODEL: {
        wk.STILL: True,
        wk.VAL: "",
        wk.WIDGET: Entry
    }
}

# These group keys have a 'wk.SUB' item and
# a dialog option in their definition.
SUB_GROUP_DEF = {
    gk.SHADOW_PRESET: SHADOW,
    ok.ADD: ADD,
    ok.ADD_ABOVE: ADD_ABOVE,
    ok.ADD_ALT: ADD_ALT,
    ok.BACKING: BACKING,
    ok.BELOW: BELOW,
    ok.BLUR_D: BLUR_DIALOG,
    ok.BRUSH_D: BRUSH_DIALOG,
    ok.BRUSH_D1: BRUSH_D1,
    ok.BUMP: BUMP,
    ok.FILLER_CE: FILLER_CE,
    ok.FILLER_CH: FILLER_CH,
    ok.FILLER_MA: FILLER_MA,
    ok.FILLER_HO: FILLER_HO,
    ok.FILLER_FE: FILLER_FE,
    ok.FILLER_ME: FILLER_ME,
    ok.FILLER_MI: FILLER_MI,
    ok.FILLER_RA: FILLER_RA,
    ok.FILLER_S1: FILLER_S1,
    ok.FILLER_S2: FILLER_S2,
    ok.FILLER_S3: FILLER_S3,
    ok.HEAT: HEAT,
    ok.IMAGE_CHOICE: IMAGE_CHOICE,
    ok.MARGIN: MARGIN,
    ok.MASK: MASK,
    ok.MOD: MOD,
    ok.NOISE_D: NOISE_D,
    ok.OVERLAY_BE: OVERLAY_BE,
    ok.OVERLAY_CA: OVERLAY_CA,
    ok.OVERLAY_CO: OVERLAY_CO,
    ok.OVERLAY_OV: OVERLAY_OV,
    ok.RESIZE: RESIZE,
    ok.SHADOW_BASIC: SHADOW_BASIC,
    ok.STENCIL: STENCIL,
    ok.STRIP: STRIP,
    ok.WRAP_TA: WRAP_TA,
    ok.WRAP: WRAP,
    ok.WRAP_AB: WRAP_AB,
    ok.WRAP_AL: WRAP_AL,
    ok.WRAP_BE: WRAP_BE,
    ok.WRAP_BU: WRAP_BU,
    ok.WRAP_CL: WRAP_CL,
    ok.WRAP_CR: WRAP_CR,
    ok.WRAP_DE: WRAP_DE,
    ok.WRAP_FI: WRAP_FI,
    ok.WRAP_GR: WRAP_GR,
    ok.WRAP_GL: WRAP_GL,
    ok.WRAP_JO: WRAP_JO,
    ok.WRAP_CA: WRAP_CA,
    ok.WRAP_OL: WRAP_OL,
    ok.WRAP_PA: WRAP_PA,
    ok.WRAP_PI: WRAP_PI,
    ok.WRAP_WO: WRAP_WO
}

SHADOW_DEF = {
    ok.SWITCH: SWITCH_GROUP,
    gk.SHADOW_1: SHADOW_1,
    gk.SHADOW_2: SHADOW_2,
    gk.INNER_SHADOW: INNER_SHADOW,
    sk.INNER_SHADOW: INNER_SHADOW,
    sk.SHADOW_1: SHADOW_1,
    sk.SHADOW_2: SHADOW_2
}
GROUP_DEF = {
    gk.BACKDROP: BACKDROP,
    gk.DEFINE_MODEL: DEFINE_MODEL,
    gk.GRADIENT_LIGHT: GRADIENT_LIGHT,
    gk.GLOBAL: GLOBAL,
    gk.MODEL: MODEL,
    gk.MODEL_NAME: MODEL_NAME,
    ok.MODEL_LIST: MODEL_LIST
}

for i in (
    BACKDROP_DEF, FRAME_DEF, MODEL_DEF, SHADOW_DEF
):
    GROUP_DEF.update(i)
