#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Issue as vo
from roller_maya import Maya
from roller_option_group import ManyGroup


class Property(ManyGroup):
    """Create a Widget group and assign view run processor."""
    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)


class Chi(Maya):
    """Factor Plan and Work."""
    issue_q = ()
    vote_type = vo.MAIN

    def __init__(self, any_group, view_i):
        Maya.__init__(self, any_group, view_i, (), vo.NO_VOTE)

    def do(self):
        return


class Plan(Chi):
    """Property has no layer output."""
    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0)


class Work(Chi):
    """Property has no layer output."""
    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1)
