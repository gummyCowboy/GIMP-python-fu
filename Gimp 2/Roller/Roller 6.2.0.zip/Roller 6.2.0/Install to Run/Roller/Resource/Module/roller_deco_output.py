#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import (   # type: ignore
    EXPAND_AS_NECESSARY, FILL_PATTERN, GRADIENT_BLEND_RGB_PERCEPTUAL, pdb
)
from random import randrange, seed
from roller_a_contain import Deco, Globe
from roller_constant_for import Deco as dc, Gradient as fg
from roller_constant_key import Option as ok
from roller_fu import (
    add_layer,
    clear_inverse_selection,
    get_select_bounds,
    isolate_selection,
    load_selection,
    make_clouds,
    paste_layer,
    paste_layer_into,
    select_z,
    shape_clipboard,
    verify_layer
)
from roller_image_grind import ref_get_image
from roller_view_deck import Deck
from roller_view_hub import (
    color_selection,
    get_gradient_points,
    get_mean_color,
    image_copy_all,
    set_fill_context_default,
    set_gimp_gradient,
    set_gimp_pattern
)
from roller_view_preset import combine_seed
from roller_view_real import insert_copy

"""
Define 'deco_output' as a collection of deco-branch
function for producing branch/Type material.
"""


def deal_as_is(_):
    """
    Intercede Type/As Is layer production when making Deck output.

    _: Deck
        not used

    Return: None
    """
    return


def deal_clouds(d, deck):
    """
    Intercede Type/Clouds layer production when making Deck output.

    d: dict
        deco-branch Preset

    deck: Deck
        Create a Deck layer for Clouds.

    Return: layer
        Clouds material
    """
    return do_clouds(deck.add(), d)


def deal_gradient(maya, d, deck):
    """
    Intercede Type/Gradient layer production when making Deck output.

    maya: Maya
        deco-branch

    d: dict
        deco-branch Preset

    deck: Deck
        Create a Deck layer for Gradient.

    Return: layer
        Gradient material
    """
    return do_gradient(maya, d, deck.add())


def deal_image(j, maya, deck):
    """
    Intercede Type/Image non-facial layer production when making Deck output.

    maya: Maya
        deco-branch

    j: Gimp Image
        WIP

    deck: Deck
        Get the layer group for nested Image output.

    Return: layer or None
        Image material
    """
    return do_image(j, maya, deck.get_group())


def deal_image_facial(j, maya, deck):
    """
    Intercede Type/Image facial layer production when making Deck output.

    j: Gimp Image
        WIP

    maya: Maya
        deco-branch

    deck: Deck
        Create a Deck layer for Image.

    Return: layer or None
        Image material
    """
    return do_image_facial(j, maya, deck.add())


def deal_mean_color(deck):
    """
    Intercede Type/Color layer production when making Deck output.

    deck: Deck
        Create a Deck layer for Color.

    Return: layer
        Color material
    """
    return do_mean_color(deck.add())


def deal_multi_color(_):
    """
    Intercede Type/Multi-Color layer production when making Deck output.

    _: Deck
        not used

    Return: None
    """
    return


def deal_netting(j, d, deck):
    """
    Intercede Type/Netting layer production when making Deck output.

    maya: Maya
        deco-branch

    j: Gimp Image
        WIP

    d: dict
        deco-branch Preset

    deck: Deck
        Create a Deck layer for Netting.

    Return: layer
        Netting material
    """
    return do_netting(j, deck.add(), d)


def deal_pattern(deck):
    """
    Intercede Type/Pattern layer production when making Deck output.

    deck: Deck
        Create a Deck layer for Pattern.

    Return: layer
        Pattern material
    """
    return do_pattern(deck.add())


def deal_plasma(j, d, deck):
    """
    Intercede Type/Plasma layer production when making Deck output.

    j: Gimp Image
        WIP

    d: dict
        deco-branch Preset

    deck: Deck
        Create a Deck layer for Plasma.

    Return: layer
        Plasma material
    """
    return do_plasma(j, deck.add(), d)


def deal_random_color(d, deck):
    """
    Intercede Type/Random Color layer production when making Deck output.

    d: dict
        deco-branch Preset

    deck: Deck
        Create a Deck layer for Plasma.

    Return: layer
        Random Color material
    """
    return do_random_color(deck.add(), d)


def deal_random_colors(_):
    """
    Intercede Type/Random Colors layer production when making Deck output.

    _: Deck
        not used

    Return: None
    """
    return


def do_clouds(z, d):
    """
    Fill a selection with solid noise.

    z: layer
        Receive Clouds.

    d: dict
        deco-branch Preset

    Return: layer
        Clouds material
    """
    make_clouds(z, int(d[ok.SEED] + Globe.seed))
    return z


def do_color(z, color):
    """
    Fill a selection with a color.

    z: layer
        Receive Color.

    color: tuple
        RGB

    Return: layer
        Color material
    """
    color_selection(z, color)
    return z


def do_image(j, maya, group):
    """
    Fill a selection for Image non-facial.

    j: Gimp Image
        WIP

    maya: Maya
        deco-branch

    group: layer group
        Receive Image.

    Return: layer or None
        Image material
    """
    j1 = ref_get_image(maya.any_group, maya.k, 0)
    sel = None

    if j1:
        n = group.name
        x, y, w, h = maya.rect

        if not pdb.gimp_selection_is_empty(j):
            sel = pdb.gimp_selection_save(j)

        image_copy_all(j1)
        shape_clipboard(w, h)

        z = paste_layer_into(j, group)

        pdb.gimp_layer_set_offsets(z, x, y)

        z.name = n + " Image"
        if sel:
            load_selection(j, sel)
            clear_inverse_selection(z)

    else:
        z = None
    return z


def do_image_facial(j, maya, z):
    """
    Fill a selection for Image facial.

    j: Gimp Image
        WIP

    maya: Maya
        deco-branch

    z: layer
        Paste Image above this layer and merge the two layers.

    Return: layer or None
        Image material
    """
    j1 = ref_get_image(maya.any_group, maya.k, 0)

    if j1:
        image_copy_all(j1)

        z1 = paste_layer(z)

        # Pasted on top of a layer.
        z = pdb.gimp_image_merge_down(z.image, z1, EXPAND_AS_NECESSARY)

        # Update 'maya.rect' for facial's transform perspective.
        select_z(z)

        x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
        maya.rect = x, y, x1 - x, y1 - y

    else:
        z = None
    return z


def do_gradient(maya, d, z):
    """
    Fill a selection with Gradient.

    maya: Maya
        deco-branch

    z: layer
        Receive Gradient.

    Return: layer
        Gradient material
    """
    start_x, end_x, start_y, end_y = get_gradient_points(d, *maya.rect)

    pdb.gimp_drawable_edit_gradient_fill(
        z,
        fg.GRADIENT_TYPE_LIST.index(d[ok.GRADIENT_TYPE]),
        0,                 # gradient offset
        1,                 # Super sample is true.
        3,                 # super sample max depth
        .0,                # super sample threshold all
        1,                 # Dither is true.
        start_x, start_y,
        end_x, end_y
    )
    return z


def do_mean_color(z):
    """
    Make a Mean Color layer. The Mean
    Color is calculated from a selection.

    z: layer
        Receive Mean Color.
    """
    color_selection(z, get_mean_color(Deco.bg_z))
    return z


def do_netting(j, z, d):
    """
    Fill a selection with Netting.

    j: Gimp Image
        WIP

    z: layer
        Receive Netting.

    d: dict
        deco-branch Preset

    Return: layer
        Netting material
    """
    w = int(d[ok.NLS])
    color = d[ok.COLOR_1]
    w1 = int(d[ok.NET_LINE_W])
    x, y = get_select_bounds(j)[1:3]
    x, y = map(int, (x, y))
    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.plug_in_grid(
        j, z,
        w1, w, y,
        color,
        255,           # opacity
        w1, w, x,
        color,
        255,           # opacity
        0, 0, 0,
        color,
        255
    )
    isolate_selection(z, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_pattern(z):
    """
    Fill a selection with Pattern.

    z: layer
        Receive Pattern.

    Return: layer
        Pattern material
    """
    pdb.gimp_drawable_edit_bucket_fill(z, FILL_PATTERN, .0, .0)
    return z


def do_plasma(j, z, d):
    """
    Fill a selection with Plasma.

    j: Gimp Image
        WIP

    z: layer
        Receive Plasma.

    d: dict
        deco-branch Preset

    Return: layer
        Plasma material
    """
    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, int(d[ok.SEED] + Globe.seed), 3.)
    isolate_selection(z, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_random_color(z, d):
    """
    Fill a selection with Random Color.

    z: layer
        Receive Random Color.

    d: dict
        deco-branch Preset

    Return: layer
        Random Color
    """
    Deco.seed += 1

    seed(int(Globe.seed + d[ok.SEED] + Deco.seed))
    color_selection(z, tuple([randrange(256) for _ in range(3)]))
    return z


def exit_deck_type(n, *arg):
    """
    Finish Deck layer processing.

    n: string
        deco-branch/Type

    arg: tuple
        deco-branch/Type specific

    Return: layer or None
        Type material
    """
    if n != dc.COLOR:
        return get_deck(arg).exit()
    return verify_layer(*arg)


def exit_one_type(z):
    """
    Finish deco layer processing where there is only one layer.

    z: layer
        Has deco-branch/Type material.

    Return: layer or None
        Type material
    """
    return verify_layer(z)


def get_deck(arg):
    """
    Fetch the Deck value from a deco-branch/Type argument.

    Return: Deck
    """
    return arg[-1]


def init_as_is(j, __, group, _, position, is_deck):
    """
    Initialize Type/As Is specific requirements.

    j: Gimp Image
        WIP

    __: Maya
        deco-branch genome

    group: layer group
        Receive layer output.

    _: dict
        deco-branch Preset

    position: int
        Is the offset of Gradient layer output from the top of 'group'.

    is_deck: bool
        If True, then create a Deck to store nested layer output.
    """
    if is_deck:
        return (Deck(j, group, position, "As Is"),), deal_as_is
    return (None,), lambda *_: None


def init_clouds(j, _, group, d, position, is_deck):
    """
    Initialize Type/Clouds specific requirements.
    For arguments, see 'init_as_is'.
    """
    combine_seed(d)

    if is_deck:
        return (d, Deck(j, group, position, "Clouds")), deal_clouds
    return (add_layer(j, group, position, "Clouds"), d), do_clouds


def init_color(j, _, group, d, position, __):
    """
    Initialize Type/Color specific requirements.
    For arguments, see 'init_as_is'.
    """
    set_fill_context_default()
    return (add_layer(j, group, position, "Color"), d[ok.COLOR_1]), do_color


def init_deco_type(n, *arg):
    """
    Initialize deco-branch/Type specific processing.

    n: string
        deco-branch/Type

    arg: tuple
        maya: Maya
            deco-branch genome

        j: Gimp Image
            WIP

        d: dict
            deco-branch Preset

        is_deck: bool
            If True, then create a Deck for stacking nested layer output.

    Return: tuple
        Is deco-branch/Type specific.
    """
    return INIT_DECO[n](*arg)


def init_facial_type(n, *arg):
    """
    Initialize deco-branch (facial)/Type specific processing.

    n: string
        deco/Type

    arg: tuple
        See 'init_deco_type'.

    Return: tuple
        Is function specific.
    """
    return INIT_FACIAL[n](*arg)


def init_gradient(j, maya, group, d, position, is_deck):
    """
    Initialize Type/Gradient specific requirements.
    For arguments, see 'init_as_is'.
    """
    set_fill_context_default()
    set_gimp_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(0)

    if is_deck:
        return (maya, d, Deck(j, group, position, "Gradient")), deal_gradient
    return (maya, d, add_layer(j, group, position, "Gradient")), do_gradient


def init_image(j, maya, group, _, position, is_deck):
    """
    Initialize Type/Image (non-facial) specific requirements.
    For arguments, see 'init_as_is'.
    """
    if is_deck:
        return (j, maya, Deck(j, group, position, "Image")), deal_image
    return (j, maya, group), do_image


def init_image_facial(j, maya, group, _, position, is_deck):
    """
    Initialize Type/Image (facial) specific requirements.
    For arguments, see 'init_as_is'.
    """
    if is_deck:
        return (j, maya, Deck(j, group, position, "Image")), deal_image_facial
    return (j, maya, add_layer(j, group, position, "Image")), do_image_facial


def init_mean_color(j, __, group, _, position, is_deck):
    """
    Initialize Type/Mean Color specific requirements.
    For arguments, see 'init_as_is'.
    """
    Deco.bg_z = insert_copy(None, group, is_hide=True)
    set_fill_context_default()

    if is_deck:
        return (Deck(j, group, position, "Mean Color"),), deal_mean_color
    return (add_layer(j, group, position, "Mean Color"),), do_mean_color


def init_multi_color(j, __, group, _, position, is_deck):
    """
    Initialize Type/Multi-Color specific requirements.
    For arguments, see 'init_as_is'.
    """
    set_fill_context_default()

    if is_deck:
        return (Deck(j, group, position, "Multi-Color"),), deal_multi_color
    return (None,), lambda *_: None


def init_netting(j, _, group, d, position, is_deck):
    """
    Initialize Type/Netting specific requirements.
    For arguments, see 'init_as_is'.
    """
    if is_deck:
        return (j, d, Deck(j, group, position, "Netting")), deal_netting
    return (j, add_layer(j, group, position, "Netting"), d), do_netting


def init_pattern(j, _, group, d, position, is_deck):
    """
    Initialize Type/Pattern specific requirements.
    For arguments, see 'init_as_is'.
    """
    set_fill_context_default()
    set_gimp_pattern(d[ok.PATTERN])

    if is_deck:
        return (Deck(j, group, position, "Pattern"),), deal_pattern
    return (add_layer(j, group, position, "Pattern"),), do_pattern


def init_plasma(j, _, group, d, position, is_deck):
    """
    Initialize Type/Plasma specific requirements.
    For arguments, see 'init_as_is'.
    """
    combine_seed(d)

    if is_deck:
        return (j, d, Deck(j, group, position, "Plasma")), deal_plasma
    return (j, add_layer(j, group, position, "Plasma"), d), do_plasma


def init_random_color(j, _, group, d, position, is_deck):
    """
    Initialize Type/Random Color specific requirements.
    For arguments, see 'init_as_is'.
    """
    Deco.seed = 0

    set_fill_context_default()

    if is_deck:
        return (d, Deck(j, group, position, "Random Color")), deal_random_color
    return (add_layer(j, group, position, "Random Color"), d), do_random_color


def init_random_colors(j, __, group, _, position, is_deck):
    """
    Initialize Type/Random Colors specific requirements.
    The Random Seed is not Fringe, but the Brush Preset's.
    For arguments, see 'init_as_is'.
    """
    set_fill_context_default()

    if is_deck:
        return (Deck(j, group, position, "Random Colors"),), deal_random_colors
    return (None,), lambda *_: None


# {deco branch-type/Type string: init deco-branch/Type function}
INIT_DECO = {
    dc.AS_IS: init_as_is,
    dc.CLOUDS: init_clouds,
    dc.COLOR: init_color,
    dc.GRADIENT: init_gradient,
    dc.IMAGE: init_image,
    dc.MEAN_COLOR: init_mean_color,
    dc.MULTI_COLOR: init_multi_color,
    dc.NETTING: init_netting,
    dc.PATTERN: init_pattern,
    dc.PLASMA: init_plasma,
    dc.RANDOM_COLOR: init_random_color,
    dc.RANDOM_COLORS: init_random_colors
}

# Use with facial Maya.
INIT_FACIAL = deepcopy(INIT_DECO)
INIT_FACIAL[dc.IMAGE] = init_image_facial
