#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb    # type: ignore
from roller_a_contain import Deco, Run
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    coloring,
    ready_canvas_rect,
    ready_shape,
    select_rect,
    transform_foam
)
from roller_deco_output import exit_deck_type, exit_one_type, init_deco_type
from roller_deco_router import create_facial_main, create_facial_per
from roller_fu import select_shape
from roller_view_hub import do_mod
from roller_view_real import get_light


def create_face(j, maya, d, arg, p):
    """
    Process a Plaque/Face item.

    j: Gimp Image
        WIP

    maya: Maya
        'maya_plaque' variety

    d: dict
        Plaque Preset

    arg: tuple
        deco-branch/Type specific

    p: function
        Call to make deco-branch/Type layer output.
    """
    model = maya.model
    k = maya.k
    n = d[ok.TYPE]
    is_color = coloring(n)
    maya.rect = model.get_facing_rect(k)

    if is_color:
        Deco.shape = model.get_facing_shape(k)

    else:
        maya.rect = model.get_facing_rect(k)
        Deco.shape = model.get_facing_form(k)

    select_shape(j, Deco.shape)

    z = p(*arg)
    if z and not is_color:
        transform_foam(maya.rect, z, model.get_facing_foam(k))


def create_facing(j, maya, d, arg, p):
    """
    Process a Facing/Plaque item.

    j: Gimp Image
        WIP

    maya: Maya
        'maya_plaque' variety

    d: dict
        Plaque Preset

    arg: tuple
        deco-branch/Type specific

    p: function
        Output deco-branch/Type layer.

    Return: layer or None
        Plaque material
    """
    k = maya.k
    model = maya.model
    n = d[ok.TYPE]
    is_color = coloring(n)
    maya.rect = model.get_facing_rect(k)

    if is_color:
        Deco.shape = model.get_facing_shape(k)

    else:
        maya.rect = model.get_facing_rect(k)
        Deco.shape = model.get_facing_form(k)

    if is_color:
        select_shape(j, Deco.shape)

    else:
        select_rect(j, *maya.rect)

    z = p(*arg)

    if z and not is_color:
        z = transform_foam(maya.rect, z, model.get_facing_foam(k))
        model.clip_facing(z, k)
    return z


def do(maya, make):
    """
    Create Plaque for a navigation branch.

    maya: Maya
        'maya_plaque' variety

    Return: layer or None
        Plaque material
    """
    d = maya.value_d

    if not Run.i:
        # Preserve.
        type_ = d[ok.TYPE]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = {
            ny.CELL: fy.CELL_PLAQUE_COLOR,
            ny.CANVAS: fy.CANVAS_PLAQUE_COLOR,
            ny.FACE: fy.FACE_PLAQUE_COLOR,
            ny.FACING: fy.FACE_PLAQUE_COLOR
        }[maya.any_group.render_key[-2]]

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.i:
        # Restore.
        d[ok.TYPE] = type_
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Draw Canvas/Plaque.

    maya: Maya
        'maya_plaque' variety

    Return: layer or None
        Plaque material
    """
    return do(maya, make_canvas)


def do_cell_main(maya):
    """
    Draw Cell/Plaque for main.

    maya: Maya
        'maya_plaque' variety

    Return: layer or None
        Plaque material
    """
    return do(maya, make_cell_main)


def do_cell_per(maya):
    """
    Draw Cell/Plaque/Per.

    maya: Maya
        'maya_plaque' variety

    Return: layer or None
        Plaque material
    """
    return do(maya, make_cell_per)


def do_face_main(maya):
    """
    Draw Face/Plaque for main.

    maya: Maya
        'maya_plaque' variety

    Return: layer or None
        Plaque material
    """
    return do(maya, make_face_main)


def do_face_per(maya):
    """
    Draw Face/Plaque/Per.

    maya: Maya
        'maya_plaque' variety

    Return: layer or None
        Plaque material
    """
    return do(maya, make_face_per)


def do_facing_main(maya):
    """
    Draw Facing/Plaque for main.

    maya: Maya
        'maya_plaque' variety

    Return: layer or None
        Plaque material
    """
    return do(maya, make_facing_main)


def do_facing_per(maya):
    """
    Draw Facing/Plaque/Per.

    maya: Maya
        'maya_plaque' variety

    Return: layer or None
        Plaque material
    """
    return do(maya, make_facing_per)


def make_canvas(maya, d):
    """
    Draw Canvas/Plaque material.

    maya: Maya
        'maya_plaque' variety

    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    arg, p = init_deco_type(
        d[ok.TYPE], Run.j, maya, maya.group, d, get_light(maya), False
    )

    ready_canvas_rect(maya, d)

    z = p(*arg)
    return exit_one_type(z)


def make_cell_main(maya, d):
    """
    Create main Cell/Plaque.

    maya: Maya
        'maya_plaque' variety

    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    def _do_many_material():
        """
        Inside a group, make a layer with its own material for each
        cell. Collapse the group and return the resulting layer.
        """
        for _k in maya.main_q:
            maya.k = _k

            ready_shape(maya, d)
            p(*arg)
        return exit_deck_type(n, *arg)

    def _do_one_material():
        # Create a single selection.
        # Image type is not one material, so there's no image check.
        pdb.gimp_selection_none(j)

        for _k in maya.main_q:
            maya.k = _k
            ready_shape(maya, d, option=CHANNEL_OP_ADD)

        _z = p(*arg)
        return exit_one_type(_z)

    j = Run.j
    n = d[ok.TYPE]
    is_per = n in dc.PER_TYPE
    arg, p = init_deco_type(n, j, maya, maya.group, d, get_light(maya), is_per)

    if is_per:
        # All the Plaque is the same material,
        # but is applied cell-by-cell.
        return _do_many_material()
    else:
        # All the Plaque is the same
        # material and is applied one time.
        return _do_one_material()


def make_cell_per(maya, d):
    """
    Make Model/Cell/Plaque/Per.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    arg, p = init_deco_type(
        d[ok.TYPE], Run.j, maya, maya.group, d, get_light(maya), False
    )

    ready_shape(maya, d)
    return exit_one_type(p(*arg))


def make_face_main(maya, d):
    """
    Create main Face/Plaque.

    maya: Maya
        'maya_plaque' variety

    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    return create_facial_main(maya, d, create_face)


def make_face_per(maya, d):
    """
    Make Face/Plaque/Per.

    maya: Maya
        'maya_plaque' variety

    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    return create_facial_per(maya, d, create_face)


def make_facing_main(maya, d):
    """
    Create main Facing/Plaque.

    maya: Maya
        'maya_plaque' variety

    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    return create_facial_main(maya, d, create_facing)


def make_facing_per(maya, d):
    """
    Make Facing/Plaque/Per.

    maya: Maya
        'maya_plaque' variety

    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    return create_facial_per(maya, d, create_facing)
