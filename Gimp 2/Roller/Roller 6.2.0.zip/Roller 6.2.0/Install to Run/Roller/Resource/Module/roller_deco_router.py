#!/usr/bin/env python
# -*- coding: utf-8 -*-
# from gimpfu import pdb   # type: ignore
from roller_a_contain import Run
from roller_constant_for import Deco as dc
from roller_constant_key import Option as ok
from roller_deco_output import exit_deck_type, exit_one_type, init_facial_type
from roller_view_real import get_light


"""
Define 'deco_router' as a collection of routing
function for facial/deco-branch/Type output.
"""


def create_facial_main(maya, d, output):
    """
    Create main Face or Facing output.

    maya: Maya
        deco-branch

    d: dict
        deco-branch Preset

    output: function
        Produce output.

    Return: layer or None
        facial material
    """
    j = Run.j
    n = d[ok.TYPE]
    arg, p = init_facial_type(n, j, maya, maya.group, d, get_light(maya), True)

    for k in maya.main_q:
        maya.k = k
        output(j, maya, d, arg, p)

    if n == dc.COLOR:
        # layer index, '0'
        return exit_one_type(arg[0])
    return exit_deck_type(n, *arg)


def create_facial_per(maya, d, output):
    """
    Make deco for Face or Facing Per.

    maya: Maya
        deco-branch

    d: dict
        deco-branch Preset

    output: function
        Produce output.

    Return: layer or None
        facial material
    """
    j = Run.j
    n = d[ok.TYPE]
    arg, p = init_facial_type(n, j, maya, maya.group, d, get_light(maya), True)

    output(j, maya, d, arg, p)

    if n == dc.COLOR:
        # layer index, '0'
        return exit_one_type(arg[0])
    return exit_deck_type(n, *arg)
