#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_REPLACE, CHANNEL_OP_SUBTRACT, pdb  # type: ignore
from random import randrange
from roller_a_contain import Cat, Run, The
from roller_a_gegl import median_blur
from roller_constant_for import Backdrop as bs, Shape as sh, Triangle as ft
from roller_constant_key import Option as ok, SubMaya as sm
from roller_fu import remove_z, select_shape, select_rect
from roller_many_rect import Rect
from roller_maya_style import Style
from roller_one import enumerate_name
from roller_one_wip import Wip
from roller_polygon import (
    calc_circumradius,
    calc_hexagon,
    calc_hexagon_truncated,
    calc_octagon,
    calc_octagon_on_its_side,
    calc_miter_square,
    calc_triangle_down_regular,
    calc_triangle_left_regular,
    calc_triangle_right_regular,
    calc_triangle_up_regular
)
from roller_view_hub import (
    calc_gradient,
    color_selection,
    create_gradient,
    do_mod,
    get_mean_color,
    set_fill_context_default
)
from roller_view_preset import combine_seed
from roller_view_real import add_wip_base, insert_copy

"""
Define 'backdrop/drop_zone' as a Maya-subtype
for managing a variation of backdrop style layer.
"""


def exit_mean_color(z):
    """
    z: layer
        background copy
    """
    remove_z(z)


def get_color(step, q, stair):
    """
    Get the color for filling a step selection.

    step: int
        0 to the number of steps - 1

    q: tuple
        RGBA; start color

    stair: list
        [float, float, float, float]
        Calculate a linear gradient having multiple steps.

    Return: tuple
        RGB
    """
    if step:
        start_color = q
        q = ()
        for i in range(4):
            b = stair[i] * step
            q += (start_color[i] + int(b),)
    return q


def fetch_mean_color(_, z):
    """
    _: int
        0..n
        drop sequence

    z: layer
        background copy

    Return: tuple
        RGB
    """
    return get_mean_color(z) + (255,)


def get_random_color(*_):
    """
    Return: tuple
        RGB
    """
    return tuple([randrange(256) for _ in range(3)]) + (255,)


def init_color(_, d):
    """
    _: group layer
    d: dict
        Drop Zone Preset

    Return: tuple
        RGB, list -> [float, float, float]; Add float to component.
    """
    steps = d[ok.STEPS]
    color, color1 = d[ok.COLOR_2A]

    # RGBA of int, 'stair'
    # Add to the start color once per iteration.
    stair = calc_gradient(color, color1, steps)

    # Set the 'color_selection' function's input to
    # the correct format (a tuple).
    # tuple of RGBA ordered integer, 'start_color'
    start_color = tuple([int(i) for i in color])

    return start_color, stair


def init_mean_color(group, _):
    """
    group: group layer
        Copy its background.

    _: dict
        Floor Sample Preset

    Return: tuple
        (background copy layer,)
    """
    return (insert_copy(group, group, is_hide=True),)


def make_style(maya):
    """
    Draw shrinking polygon.

    maya: Style
    Return: layer or None
        Drop Zone material
    """
    j = Run.j
    d = maya.value_d

    combine_seed(d)
    set_fill_context_default()
    pdb.gimp_selection_none(j)

    grad = None
    is_keep = d[ok.KEEP]
    type_ = d[ok.TYPE]
    x, y, w, h = Wip.get_rect()
    steps = d[ok.STEPS]
    mod_w = w / steps / 2.
    mod_h = h / steps / 2.
    type_arg = INIT_TYPE[type_](maya.group, d)
    z = add_wip_base("Drop Zone WIP", maya.group)
    shape = d[ok.SHAPE]
    last_step = int(steps) - 1

    # Initialize a Gimp saved gradient.
    if is_keep:
        # Make a unique gradient name.
        gradients = Cat.gradient_list

        # gradient name, 'n'
        n = d[ok.NAME]

        if not n:
            n = "Drop Zone"

        if n in gradients:
            n = enumerate_name(n, gradients)

        # Create a gradient with evenly spaced
        # segments, one for each color.
        grad = create_gradient(n, is_keep)

        # start segment, '0'; end segment, '0'
        pdb.gimp_gradient_segment_range_split_uniform(grad, 0, 0, int(steps))

    # list of shape argument, one per step
    # [tuple, ...], 'step_q'
    step_q = []

    # Calculate shapes for each step.
    for step in range(int(steps)):
        w = max(1., w)
        h = max(1., h)
        step_q.append(ROUTE_CALC[shape](x, y, w, h))

        # Define the next rectangle.
        x += mod_w
        y += mod_h
        w -= (mod_w * 2.)
        h -= (mod_h * 2.)

    # Fill shapes with material for each step.
    for step in range(int(steps)):
        ROUTE_SELECT[shape](j, step_q[step])

        if step != last_step:
            ROUTE_SELECT[shape](
                j, step_q[step + 1], option=CHANNEL_OP_SUBTRACT
            )

        color = GET_COLOR[type_](step, *type_arg)

        color_selection(z, color)
        if is_keep:
            # arg, (gradient, segment index, color, opacity)
            # The opacity value has to be rounded
            # as it will overflow with float-sum (e.g. 100.00000007).
            arg = grad, step, color[:3], round(color[3] / 255. * 100., 1)

            # The start and end color is the same for a segment.
            pdb.gimp_gradient_segment_set_left_color(*arg)
            pdb.gimp_gradient_segment_set_right_color(*arg)

    EXIT_TYPE[type_](*type_arg)
    pdb.gimp_selection_none(j)

    # Create a gradient if the user desires.
    if is_keep:
        # This gradient is kept and is
        # saved to a file when GIMP closes.
        The.grad = grad

    median_blur(z, 2., 50.)
    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


def calc_circle(x, y, w, h):
    """
    Calculate a circle given an inscribed rectangle.

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    radius = calc_circumradius(w, h)
    w1 = radius * 2.
    x1 = x - (w1 - w) / 2.
    y1 = y - (w1 - h) / 2.
    return x1, y1, w1, w1


def calc_ellipse(x, y, w, h):
    """
    Calculate an ellipse given an inscribed rectangle.

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    # square-root of 2, '1.41'
    w1, h1 = w * 1.41421356, h * 1.41421356

    x1 = x - (w1 - w) / 2.
    y1 = y - (h1 - h) / 2.
    return x1, y1, w1, h1


def calc_hex(x, y, w, h):
    """
    Calculate a hexagon that is circumscribing a rectangle.

    Reference
    calcresource.com/geom-hexagon.html

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    inscribe_radius = calc_circumradius(w, h)
    circum_radius = inscribe_radius * ft.SCALE_UP
    w1 = inscribe_radius * 2.
    h1 = circum_radius * 2.
    x1 = x - (w1 - w) / 2.
    y1 = y - (h1 - h) / 2.
    return calc_hexagon(Rect(x1, y1, w1, h1))


def calc_hex_truncated(x, y, w, h):
    """
    Calculate a truncated hexagon that is circumscribing a rectangle.

    Reference
    calcresource.com/geom-hexagon.html

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    inscribe_radius = calc_circumradius(w, h)
    circum_radius = inscribe_radius * ft.SCALE_UP
    w1 = circum_radius * 2.
    h1 = inscribe_radius * 2.
    x1 = x - (w1 - w) / 2.
    y1 = y - (h1 - h) / 2.
    return calc_hexagon_truncated(Rect(x1, y1, w1, h1))


def calc_rect(x, y, w, h):
    """
    Calculate a square that is circumscribing a rectangle.

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    return x, y, w, h


def calc_step_miter_square(x, y, w, h):
    """
    Calculate a square that has been rotated 45 degrees.

    Reference
    varsitytutors.com/hotmath/hotmath_help/topics/circles-inscribed-in-squares

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    side = calc_circumradius(w, h) * 2.

    # square-root of 2, '1.41'
    diagonal = side * 1.41421356

    x -= (diagonal - w) / 2.
    y -= (diagonal - h) / 2.
    return calc_miter_square(Rect(x, y, diagonal, diagonal))


def calc_step_octagon(x, y, w, h):
    """
    Calculate an octagon that is circumscribing a rectangle.

    Reference
    calcresource.com/geom-octagon.html

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    w2 = (calc_circumradius(w, h) / sh.OCTAGON_CIRCUMRADIUS_RATIO) * 2.
    x -= (w2 - w) / 2.
    y -= (w2 - h) / 2.
    return calc_octagon(Rect(x, y, w2, w2))


def calc_step_octagon_on_its_side(x, y, w, h):
    """
    Calculate an octagon on its side that is circumscribing a rectangle.

    Reference
    calcresource.com/geom-octagon.html

    q: tuple
        x, y: float
        rectangle position

        w, h: float
        rectangle size

    Return: tuple
    """
    w2 = (calc_circumradius(w, h) / sh.OCTAGON_CIRCUMRADIUS_RATIO) * 2.
    x -= (w2 - w) / 2.
    y -= (w2 - h) / 2.
    return calc_octagon_on_its_side(Rect(x, y, w2, w2))


def calc_square(x, y, w, h):
    """
    Calculate a square that is circumscribing a rectangle.

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    w1 = max(w, h)
    x -= (w1 - w) / 2.
    y -= (w1 - h) / 2.
    return x, y, w1, w1


def calc_triangle_down_equal(x, y, w, h):
    """
    Calculate an regular triangle that is facing down.
    The triangle is centered and inscribes the rectangle.

    Reference
    brilliant.org/wiki/properties-of-equilateral-triangles/

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    h1 = h / 2.
    radius = calc_circumradius(w, h)

    # height of triangle, 'h2'
    # width of rectangle, 'w1'
    h2 = radius * 3.
    w1 = ft.SCALE_UP * h2
    x1 = x - (w1 - w) / 2.
    y1 = y - radius + h1
    return calc_triangle_down_regular(Rect(x1, y1, w1, h2))


def calc_triangle_left_equal(x, y, w, h):
    """
    Calculate an regular triangle that is facing left.
    The triangle is centered and inscribes the rectangle.

    Reference
    brilliant.org/wiki/properties-of-equilateral-triangles/

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    w1 = w / 2.
    radius = calc_circumradius(w, h)

    # width of triangle, 'w2'
    # height of rectangle, 'h1'
    w2 = radius * 3.
    h1 = ft.SCALE_UP * w2
    x1 = x - (radius * 2.) + w1
    y1 = y - (h1 - h) / 2.
    return calc_triangle_left_regular(Rect(x1, y1, w2, h1))


def calc_triangle_right_equal(x, y, w, h):
    """
    Calculate an regular triangle that is facing right.
    The triangle is centered and inscribes the rectangle.

    Reference
    brilliant.org/wiki/properties-of-equilateral-triangles/

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    w1 = w / 2.
    radius = calc_circumradius(w, h)

    # width of triangle, 'w2'
    # height of rectangle, 'h1'
    w2 = radius * 3.
    h1 = ft.SCALE_UP * w2
    x1 = x - radius + w1
    y1 = y - (h1 - h) / 2.
    return calc_triangle_right_regular(Rect(x1, y1, w2, h1))


def calc_triangle_up_equal(x, y, w, h):
    """
    Calculate an regular triangle that is facing up.
    The triangle is centered and inscribes the rectangle.

    Reference
    brilliant.org/wiki/properties-of-equilateral-triangles/

    x, y: float
        rectangle position

    w, h: float
        rectangle size

    Return: tuple
    """
    h1 = h / 2.
    radius = calc_circumradius(w, h)

    # height of triangle, 'h2'
    # width of rectangle, 'w1'
    h2 = radius * 3.
    w1 = ft.SCALE_UP * h2
    x1 = x - (w1 - w) / 2.
    y1 = y - (radius * 2.) + h1
    return calc_triangle_up_regular(Rect(x1, y1, w1, h2))


def select_step_shape(j, arg, option=CHANNEL_OP_REPLACE):
    """
    Select a circle given an inscribed rectangle.

    j: Gimp Image
    arg: tuple
        Pass to 'select_shape'.

    option: Gimp Enum
        CHANNEL_OP...

    Return: state of selection
    """
    select_shape(j, arg, option=option)


def select_step_rect(j, arg, option=CHANNEL_OP_REPLACE):
    """
    Select a square that is circumscribing a rectangle.

    arg: tuple
        Pass to 'select_rect'.

    Return: state of selection
    """
    select_rect(j, *arg, option=option)


class DropZone(Style):
    """Create Backdrop Style output."""
    dependency = bs.DEPENDENT

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.BRW, ok.MOD, ok.BLUR_D)
            ],
            make_style
        )

    def do(self, z, d, is_change):
        """
        Produce or modify layer output. Override Style's function.

        z: layer
            Backing output
            not used

        d: dict
            Backdrop Style Preset

        is_change: bool
            not used
            Is the state of the super Maya's matter and/or mask.
            Floor Sample is independent of the Backing layer.
        """
        self.value_d = d
        is_draw = is_change if d[ok.TYPE] == bs.MEAN_COLOR else False
        self.is_matter |= is_draw

        self.realize()
        self.sub_maya[sm.ADD].do(
            d[ok.BRW][ok.ADD_ALT], self.is_matter, self.is_matter, is_change
        )
        self.reset_issue()


EXIT_TYPE = {
    bs.COLOR: lambda *_: None,
    bs.MEAN_COLOR: exit_mean_color,
    bs.RANDOM_COLOR: lambda *_: None
}
INIT_TYPE = {
    bs.COLOR: init_color,
    bs.MEAN_COLOR: init_mean_color,
    bs.RANDOM_COLOR: lambda *_: ()
}
GET_COLOR = {
    bs.COLOR: get_color,
    bs.MEAN_COLOR: fetch_mean_color,
    bs.RANDOM_COLOR: get_random_color
}
ROUTE_CALC = {
    sh.CIRCLE: calc_circle,
    sh.ELLIPSE: calc_ellipse,
    sh.HEXAGON: calc_hex,
    sh.HEXAGON_TRUNCATED: calc_hex_truncated,
    sh.OCTAGON: calc_step_octagon,
    sh.OCTAGON_ON_ITS_SIDE: calc_step_octagon_on_its_side,
    sh.SQUARE: calc_square,
    sh.MITER_SQUARE: calc_step_miter_square,
    ft.TRIANGLE_DOWN_REGULAR: calc_triangle_down_equal,
    ft.TRIANGLE_LEFT_REGULAR: calc_triangle_left_equal,
    ft.TRIANGLE_RIGHT_REGULAR: calc_triangle_right_equal,
    ft.TRIANGLE_UP_REGULAR: calc_triangle_up_equal,
    sh.RECTANGLE: calc_rect
}
ROUTE_SELECT = {
    sh.CIRCLE: select_shape,
    sh.ELLIPSE: select_shape,
    sh.HEXAGON: select_shape,
    sh.HEXAGON_TRUNCATED: select_shape,
    sh.OCTAGON: select_shape,
    sh.OCTAGON_ON_ITS_SIDE: select_shape,
    sh.SQUARE: select_step_rect,
    sh.MITER_SQUARE: select_shape,
    ft.TRIANGLE_DOWN_REGULAR: select_shape,
    ft.TRIANGLE_LEFT_REGULAR: select_shape,
    ft.TRIANGLE_RIGHT_REGULAR: select_shape,
    ft.TRIANGLE_UP_REGULAR: select_shape,
    sh.RECTANGLE: select_step_rect
}
