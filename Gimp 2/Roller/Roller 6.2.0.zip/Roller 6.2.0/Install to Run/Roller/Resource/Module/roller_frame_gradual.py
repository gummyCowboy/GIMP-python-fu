#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, CHANNEL_OP_SUBTRACT, pdb   # type: ignore
from roller_a_contain import Run
from roller_constant_for import Frame as ff
from roller_constant_key import Material as ma, Option as ok
from roller_frame import grow_wrap
from roller_frame_alt import FrameBasic
from roller_fu import (
    add_layer, clear_selection, load_selection, select_z
)
from roller_view_hub import (
    calc_gradient, color_selection, set_fill_context_default
)
from roller_view_real import get_light

"""
Define 'frame_gradual' as a Maya-subtype
for managing a variation of Frame type.
"""


def do_matter(maya):
    """
    Make a frame.

    maya: Gradual
    Return: layer
        Wrap frame
    """
    j = Run.j
    d = maya.value_d
    start_color, end_color = d[ok.COLOR_2A]
    steps = d[ok.WIDTH]
    cast = maya.cast.matter
    z = add_layer(j, maya.group, get_light(maya), "Material")

    # Begin gradient construction.
    step = calc_gradient(start_color, end_color, steps)
    q = list(start_color)
    sel = None

    set_fill_context_default()
    select_z(cast)

    for i in range(int(steps)):
        if not pdb.gimp_selection_is_empty(j):
            sel = pdb.gimp_selection_save(j)

            grow_wrap(j, None, 1., ff.ANGULAR)
            load_selection(j, sel, option=CHANNEL_OP_SUBTRACT)
            color_selection(z, tuple(q))
            load_selection(j, sel, option=CHANNEL_OP_ADD)
            for i1 in range(4):
                q[i1] = start_color[i1] + int(step[i1] * (i + 1))
        pdb.gimp_image_remove_channel(j, sel)

    select_z(cast)
    clear_selection(z)
    return z


class Gradual(FrameBasic):
    kind = material = ma.GRADUAL
    wrap_k = ok.WRAP_GR

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
