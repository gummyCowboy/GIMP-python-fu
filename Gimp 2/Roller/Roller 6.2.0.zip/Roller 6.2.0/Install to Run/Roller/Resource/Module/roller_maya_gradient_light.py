#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_REPLACE, pdb  # type: ignore
from copy import deepcopy
from roller_a_contain import Gradient
from roller_constant_for import Issue as vo, Signal as si
from roller_constant_key import Option as ok, SubMaya as sm
from roller_fu import add_layer, create_image, discard_mask
from roller_image_grind import ref_on_group_change
from roller_mask_router import attach_mask_sel, make_mask_sel
from roller_maya import Maya
from roller_maya_mask import Mask
from roller_one_ring import Ring
from roller_one_wip import Wip
from roller_option_group import ManyGroup
from roller_view_hub import do_gradient_job, do_mod


def create_gradient(maya):
    """
    Create a Gradient Light image. The image is hidden from
    the user and is removed when Roller closes or by an
    GradientLight change operation. Gradient Light layers are
    created from the image using a copy visible image function.

    maya: Maya
    """
    reset_gradient(maya)

    d = deepcopy(maya.value_d)
    d[ok.GRADIENT] = d[ok.RW1][ok.GRADIENT]
    w, h = Wip.get_size()
    j = Gradient.image = create_image(int(w), int(h))
    z = maya.matter = add_layer(j, None, 0, "Process")

    do_gradient_job(z, d)
    do_mod(z, d[ok.RW1][ok.MOD])


def do_mask(maya, d):
    """
    maya: Light
    d: dict
        Mask Preset
    """
    z = maya.matter

    discard_mask(z)
    pdb.gimp_image_select_item(z.image, CHANNEL_OP_REPLACE, z)
    make_mask_sel(Gradient.image, maya, d)
    attach_mask_sel(z)


def make_gradient_light(maya):
    """
    Make Gradient Light and/or remove it.

    maya: Work
    """
    if maya.is_matter:
        create_gradient(maya)
    return maya.matter


def reset_gradient(maya):
    if Gradient.image:
        pdb.gimp_image_delete(Gradient.image)
        maya.matter = Gradient.image = None


class Light(ManyGroup):
    """Create Widget group and assign view run processor."""
    image_slot_count = 2

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)
        self.latch(self, (si.GROUP_CHANGE, ref_on_group_change))

    @staticmethod
    def get_image_d(d):
        """
        Image assignment expects this function, but there is no image.

        d: dict
            Gradient Light Preset
        """
        return

    @staticmethod
    def get_keys():
        return [None]


class Plan(Maya):
    """Doesn't have layer output. Is a template for a Plan run."""
    issue_q = ()
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Maya.__init__(self, any_group, 0, (), vo.NO_VOTE)

    def do(self):
        """
        Plan doesn't have Gradient Light.

        Return: None
            for undo
        """
        return


class Work(Maya):
    """Manage Gradient Light layer output."""
    put = (make_gradient_light, 'matter'),
    issue_q = 'matter',
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Maya.__init__(
            self,
            any_group,
            1,
            Work.put,
            [
                (),
                (ok.RW1,),
                (ok.RW1, ok.GRADIENT),
                (ok.RW1, ok.MASK),
                (ok.RW1, ok.MOD),
                (ok.RW1, ok.MOD, ok.BLUR_D)
            ]
        )
        self.sub_maya[sm.MASK] = Mask(
            any_group, self, 1, do_mask, self.get_mask_d, (ok.RW1, ok.MASK)
        )
        self.set_issue()
        self.latch(any_group.booth, (si.VOTE_CHANGE, Work.on_light_change))

    def do(self):
        """Manage Gradient Light layer output for a Work run."""
        self.go = self.value_d[ok.SWITCH]

        self.realize()

        if Gradient.image:
            self.sub_maya[sm.MASK].do(
                self.value_d[ok.RW1][ok.MASK], self.is_matter
            )
        self.reset_issue()

    def die(self):
        """Override the Maya class function."""
        reset_gradient(self)

    def get_mask_d(self):
        return self.value_d[ok.RW1][ok.MASK]

    @staticmethod
    def on_light_change(*_):
        """
        Respond to change in Gradient Light option.
        Notify Gradient Light subscriber.

        _: tuple
            (AnyGroup; Sent the signal.,
            dict; AnyGroup's vote collection)
        """
        Ring.plug(si.LIGHT_CHANGE, None)
