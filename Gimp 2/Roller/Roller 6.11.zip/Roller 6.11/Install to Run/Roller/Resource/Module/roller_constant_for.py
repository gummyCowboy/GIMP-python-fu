#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Are supplemental class module with a two letter import variable
# that are unique in the context of the program.
from roller_constant_key import Option as ok, Plan as ak
import gobject  # type: ignore
import gtk      # type: ignore

_AS_IS = "As Is"
_BLUE = "Blue"
_CIRCLE = "Circle"
_CLOCKWISE, _COUNTER_CLOCKWISE = 0, 1
_CLOUDS = "Clouds"
_COLOR = "Color"
_COMPOSITE = "Composite"
_DIAMOND = "Diamond"
_ELLIPSE = "Ellipse"
_GRADIENT = "Gradient"
_GREEN = "Green"
_HEXAGON = "Hexagon"
_HEXAGON_SHEAR = "Hexagon, Sheared"
_HEXAGON_TRUNCATED = "Hexagon, Truncated"
_HEXAGON_TRUNCATED_SHEAR = "Hexagon, Truncated, Sheared"
_IMAGE = "Image"
_LIST_SEPARATOR = "★"
_MEAN_COLOR = "Mean Color"

# Mesh Type is Enum ordered.
_MESH_TYPE = "Square", "Hexagon", "Octagon", "Triangle"

_MULTI_COLOR = "Multi-Color"
_NETTING = "Netting"
_OCTAGON = "Octagon"
_OCTAGON_SHEAR = "Octagon, Sheared"
_OCTAGON_ON_ITS_SIDE = "Octagon, On Its Side"
_OCTAGON_ON_ITS_SIDE_SHEAR = "Octagon, On Its Side, Sheared"
_PARALLELOGRAM_LEFT = "Parallelogram, Left"
_PARALLELOGRAM_RIGHT = "Parallelogram, Right"
_PATTERN = "Pattern"
_PLASMA = "Plasma"
_RECTANGLE = "Rectangle"
_RED = "Red"
_SQUARE = "Square"
_MITER_SQUARE = "Miter Square"
_TRIANGLE_DOWN_SHEAR = "Triangle, Down, Sheared"
_TRIANGLE_DOWN_REGULAR = "Triangle, Down, Regular"
_TRIANGLE_LEFT_SHEAR = "Triangle, Left, Sheared"
_TRIANGLE_LEFT_REGULAR = "Triangle, Left, Regular"
_TRIANGLE_RIGHT_SHEAR = "Triangle, Right, Sheared"
_TRIANGLE_RIGHT_REGULAR = "Triangle, Right, Regular"
_TRIANGLE_UP_SHEAR = "Triangle, Up, Sheared"
_TRIANGLE_UP_REGULAR = "Triangle, Up, Regular"
MAX_SIZE = 524288
MAX_SIZE_F = 524288.


class Backdrop:
    """Import as 'bs'."""
    BLUE = _BLUE
    CLOCKWISE, COUNTER_CLOCKWISE = _CLOCKWISE, _COUNTER_CLOCKWISE
    COLOR_GRID_TYPE = "Checkerboard", "Brick"
    CLOUDS = _CLOUDS
    COLOR = _COLOR
    COMPONENT = _RED, _GREEN, _BLUE
    DIAGONAL = "Diagonal"
    DIRECTION = "Clockwise", "Counter-Clockwise"
    DOT = "Dot"
    FLIP_BOTH = "Flip Both Axis"
    GRADIENT = _GRADIENT
    GREEN = _GREEN
    HORIZONTAL = "Horizontal"
    HORIZONTAL_FLIP = "Horizontal Flip"
    IMAGE = _IMAGE
    MEAN_COLOR = _MEAN_COLOR
    MESH_TYPE = _MESH_TYPE
    NEWS_TYPE = DOT, "Line", "Diamond", "Euclidean Dot", "PS-Diamond"
    PATTERN = _PATTERN
    PLASMA = _PLASMA
    RANDOM_COLOR = "Random Color"
    RANDOM_PATTERN = "Random Pattern"
    RED = _RED
    SHIFT_DIRECTION = "Vertical", "Horizontal"
    SHOW_GRADIENT, SHOW_SAMPLE = 0, 1
    SQUARE = _SQUARE
    COLOR = _COLOR
    VERTICAL = "Vertical"
    VERTICAL_FLIP = "Vertical Flip"

    # dependent________________________________________________________
    BACKDROP_TYPE = CLOUDS, COLOR, GRADIENT, IMAGE, PATTERN, PLASMA
    REVERB_TYPE = (
        MEAN_COLOR,
        _RED,
        _GREEN,
        _BLUE,
        _PATTERN,
        COLOR,
        RANDOM_COLOR,
        RANDOM_PATTERN,
    )
    SPIRAL_MOD_LIST = "None", HORIZONTAL_FLIP, VERTICAL_FLIP, FLIP_BOTH
    VECTOR = VERTICAL, HORIZONTAL, DIAGONAL
    # ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


class Below:
    """Import as 'be'."""
    INVERT_MASK = "Invert Mask"
    MASK = "Mask"
    NO_MASK = "No Mask"
    TYPE = MASK, INVERT_MASK, NO_MASK


class Blur:
    """Import as 'bu'."""
    GAUSSIAN = "Gaussian"
    MEDIAN = "Median"
    TYPE = GAUSSIAN, MEDIAN


class Bump:
    """Import as 'fb'."""
    CLOTH = "Cloth"
    CROSSHATCH = "Crosshatch"
    NANO = "Nano"
    NOISE = "Noise"
    HAS_BUMP = CLOTH, CROSSHATCH, NANO, NOISE
    HAS_NOISE = NANO, NOISE
    TYPE = CLOTH, CROSSHATCH, NANO, NOISE


class Caption:
    """Import as 'pt'."""
    IMAGE_NAME = "Image Name"
    SEQUENCE = "Sequence"
    TEXT = "Text"
    ALL_OPTION = IMAGE_NAME, SEQUENCE, TEXT
    NO_SEQUENCE_OPTION = IMAGE_NAME, TEXT
    TEXT_OPTION = TEXT,


class Color:
    """Import as 'co'."""
    MAX_COLOR = 65535

    # colored button
    ACTIVE_COLOR = gtk.gdk.Color(55000, 55000, 0)
    CELL_COLOR = gtk.gdk.Color(55000, 55000, MAX_COLOR)
    CONNECTOR_COLOR = gtk.gdk.Color(52000, 52000, MAX_COLOR)
    CONNECTED_COLOR = gtk.gdk.Color(MAX_COLOR, 0, 0)
    FOCUS_COLOR = gtk.gdk.Color(50000, 44000, MAX_COLOR)

    HEADER_COLOR = 44000, 44000, MAX_COLOR
    LIST_CELL_COLOR = gtk.gdk.Color(51000, 61000, 50000)
    WHITE = gtk.gdk.Color(MAX_COLOR, MAX_COLOR, MAX_COLOR)
    MISSING_FILE = gtk.gdk.Color(MAX_COLOR, MAX_COLOR, MAX_COLOR // 2)

    # GTK Box
    COLOR_DEC = 1900
    INIT_COLOR = MAX_COLOR - COLOR_DEC


class Deco:
    """Has values used by Plaque, Fringe, Border and Line. Import as 'dc'."""
    AS_IS = _AS_IS
    MEAN_COLOR = _MEAN_COLOR
    COLOR = _COLOR
    CLOUDS = _CLOUDS
    GRADIENT = _GRADIENT
    IMAGE = _IMAGE
    MULTI_COLOR = _MULTI_COLOR
    NETTING = _NETTING
    PATTERN = _PATTERN
    PLASMA = _PLASMA
    RANDOM_COLOR = "Random Color"

    # branch type enum
    CANVAS, CELL, FACE = 0, 1, 2

    # Are Deco type that apply their material on one Preset at a time,
    FRINGE_PER_TYPE = {
        AS_IS, GRADIENT, IMAGE, MEAN_COLOR, MULTI_COLOR, RANDOM_COLOR
    }
    PER_TYPE = {GRADIENT, IMAGE, MEAN_COLOR, RANDOM_COLOR}

    ONE_IMAGE_TYPE = ok.TAB, ok.FILE
    TYPE = [
        CLOUDS,
        COLOR,
        GRADIENT,
        IMAGE,
        MEAN_COLOR,
        NETTING,
        PATTERN,
        PLASMA,
        RANDOM_COLOR
    ]
    FRINGE_TYPE = [AS_IS] + TYPE
    FRINGE_TYPE.insert(6, MULTI_COLOR)


class Frame:
    """Import as 'ff'."""
    AQUA = "Aqua"
    BLUE = "Blue"
    PURPLE = "Purple"
    COMPOSITE = _COMPOSITE
    GREEN = "Green"
    YELLOW = "Yellow"
    RED = _RED

    # Overlay
    COLOR = _COLOR
    GRADIENT = _GRADIENT
    IMAGE = _IMAGE
    PLASMA = _PLASMA
    CLOUDS = _CLOUDS

    MESH_TYPE = _MESH_TYPE
    PATTERN = _PATTERN

    # Decay
    WHITE_HARD = "Hard Edge on White"
    WHITE_MIXED = "Mixed Edge on White"
    WHITE_SOFT = "Soft Edge on White"
    GREY_HARD = "Hard Edge on Grey"
    GREY_MIXED = "Mixed Edge on Grey"
    GREY_SOFT = "Soft Edge on Grey"
    DECAY_TYPE = (
        WHITE_SOFT,
        WHITE_MIXED,
        WHITE_HARD,
        GREY_SOFT,
        GREY_MIXED,
        GREY_HARD
    )

    # Frame Type
    ANGULAR = "Angular"
    RECTANGLE = "Rectangle"
    ROUNDED = "Rounded"

    # Bevel Frame Type
    BAND = "Band"
    BEVEL = "Bevel"
    RAISE = "Raise"
    ROUND = "Round"
    SINK = "Sink"

    # Noise
    INK = "Ink"
    RIFT = "Rift"
    SPECK = "Speck"
    WATER = "Water"

    # dependent
    CAMO_TYPE = COMPOSITE, GREEN, RED, BLUE, AQUA, PURPLE, YELLOW
    COMPONENT = {
        BLUE: (.0, 1., .0, .25),
        AQUA: (.0, 1., 1., 1.),
        PURPLE: (1., 1., .0, .25),
        COMPOSITE: (1., 1., 1., 1.),
        GREEN: (.0, .0, 1., 1.),
        YELLOW: (1., .0, 1., .5),
        RED: (1., .0, .0, .5)
    }
    NOISE_TYPE = INK, RIFT, SPECK, WATER
    OVERLAY_TYPE = CLOUDS, COLOR, GRADIENT, IMAGE, PATTERN, PLASMA
    PROFILE = BAND, BEVEL, RAISE, ROUND, SINK
    WRAP_TYPE_Q = ANGULAR, RECTANGLE, ROUNDED


class Fill:
    """Import as 'fl'."""
    COMPOSITE = _COMPOSITE
    CRITERION_LIST = (
        COMPOSITE,
        _RED,
        "Green",
        "Blue",
        "Hue",
        "Saturation",
        "Value",
        "Alpha",
        "LCH-Lightness",
        "LCH-Chroma",
        "LCH Hue"
    )


class Gradient:
    """Import as 'fg'."""
    BOTTOM_CENTER_TO_TOP_CENTER = "Bottom-center to Top-center"
    BOTTOM_LEFT_TO_TOP_RIGHT = "Bottom-left to Top-right"
    BOTTOM_RIGHT_TO_TOP_LEFT = "Bottom-right to Top-left"
    CENTER_BOTTOM = "Center to Bottom-center"
    CENTER_LEFT = "Center to Center-left"
    CENTER_RIGHT = "Center to Center-right"
    CENTER_TOP = "Center to Top-center"
    CENTER_LEFT_TO_CENTER_RIGHT = "Center-left to Center-right"
    CENTER_RIGHT_TO_CENTER_LEFT = "Center-right to Center-left"
    LINEAR = "Linear"
    RADIAL = "Radial"
    SHAPED_ANGULAR = "Shaped (angular)"
    SHAPED_DIMPLED = "Shaped (dimpled)"
    SHAPED_SPHERICAL = "Shaped (spherical)"
    SPIRAL_CLOCKWISE = "Spiral-Clockwise"
    SPIRAL_COUNTER_CW = "Spiral-Counter-Clockwise"
    SQUARE = _SQUARE
    TOP_CENTER_TO_BOTTOM_CENTER = "Top-center to Bottom-center"
    TOP_LEFT_TO_BOTTOM_RIGHT = "Top-left to Bottom-right"
    TOP_RIGHT_TO_BOTTOM_LEFT = "Top-right to Bottom-left"
    GRADIENT_ANGLE = (
        CENTER_BOTTOM,
        CENTER_LEFT,
        CENTER_RIGHT,
        CENTER_TOP,
        TOP_LEFT_TO_BOTTOM_RIGHT,
        TOP_CENTER_TO_BOTTOM_CENTER,
        TOP_RIGHT_TO_BOTTOM_LEFT,
        BOTTOM_LEFT_TO_TOP_RIGHT,
        BOTTOM_CENTER_TO_TOP_CENTER,
        BOTTOM_RIGHT_TO_TOP_LEFT,
        CENTER_LEFT_TO_CENTER_RIGHT,
        CENTER_RIGHT_TO_CENTER_LEFT
    )

    # Translate a gradient angle into x, y factor pairs.
    # The key is a gradient angle.
    # The value is a tuple: (start x, end x, start y, end y) of factor values.
    GRADIENT_XY = {
        CENTER_BOTTOM: (.5, .5, .5, 1.),
        CENTER_LEFT: (.5, .0, .5, .5),
        CENTER_RIGHT: (.5, 1., .5, .5),
        CENTER_TOP: (.5, .5, .5, .0),
        TOP_LEFT_TO_BOTTOM_RIGHT: (.0, 1., .0, 1.),
        TOP_CENTER_TO_BOTTOM_CENTER: (.5, .5, .0, 1.),
        TOP_RIGHT_TO_BOTTOM_LEFT: (1., .0, .0, 1.),
        BOTTOM_LEFT_TO_TOP_RIGHT: (.0, 1., 1., .0),
        BOTTOM_CENTER_TO_TOP_CENTER: (.5, .5, 1., .0),
        BOTTOM_RIGHT_TO_TOP_LEFT: (1., .0, 1., .0),
        CENTER_LEFT_TO_CENTER_RIGHT: (.0, 1., .5, .5),
        CENTER_RIGHT_TO_CENTER_LEFT: (1., .0, .5, .5)
    }

    GRADIENT_TYPE_LIST = (
        LINEAR,
        "Bilinear",
        RADIAL,
        SQUARE,
        "Conical Symmetric",
        "Conical ASymmetric",
        SHAPED_ANGULAR,
        SHAPED_DIMPLED,
        SHAPED_SPHERICAL,
        SPIRAL_CLOCKWISE,
        SPIRAL_COUNTER_CW
    )
    SHAPED_TYPE = SHAPED_ANGULAR, SHAPED_DIMPLED, SHAPED_SPHERICAL


class Grid:
    """Has values used by a Cell/Type option group. Import as 'gr'."""
    CELL_COUNT = "Cell Count"
    CELL_SIZE = "Cell Size"
    SHAPE_COUNT = "Shape Count"
    TYPE_LIST = CELL_COUNT, CELL_SIZE, SHAPE_COUNT

    # pin
    BOTTOM_LEFT = "Bottom-Left"
    BOTTOM_CENTER = "Bottom-Center"
    BOTTOM_RIGHT = "Bottom-Right"
    CENTER = "Center"
    CENTER_LEFT = "Center-Left"
    CENTER_RIGHT = "Center-Right"
    TOP_CENTER = "Top-Center"
    TOP_LEFT = "Top-Left"
    TOP_RIGHT = "Top-Right"
    PIN_LIST = (
        CENTER, CENTER_LEFT, CENTER_RIGHT,
        TOP_CENTER, TOP_LEFT, TOP_RIGHT,
        BOTTOM_CENTER, BOTTOM_LEFT, BOTTOM_RIGHT
    )

    # Are Pin values where a topleft oriented
    # grid is offset or centered in its canvas.
    X_OFFSET = (
        BOTTOM_CENTER, BOTTOM_RIGHT,
        CENTER, CENTER_RIGHT,
        TOP_CENTER, TOP_RIGHT
    )
    Y_OFFSET = (
        BOTTOM_CENTER, BOTTOM_LEFT, BOTTOM_RIGHT,
        CENTER, CENTER_LEFT, CENTER_RIGHT
    )
    X_CENTER = BOTTOM_CENTER, CENTER, TOP_CENTER
    Y_CENTER = CENTER, CENTER_LEFT, CENTER_RIGHT


class Justification:
    """Import as 'ju'."""
    TOP_LEFT = "Top-Left"
    TOP_CENTER = "Top-Center"
    TOP_RIGHT = "Top-Right"
    LEFT_CENTER = "Left-Center"
    CENTER = "Center"
    RIGHT_CENTER = "Right-Center"
    BOTTOM_LEFT = "Bottom-Left"
    BOTTOM_CENTER = "Bottom-Center"
    BOTTOM_RIGHT = "Bottom-Right"
    TYPE = (
        CENTER,
        TOP_LEFT,
        TOP_CENTER,
        TOP_RIGHT,
        LEFT_CENTER,
        RIGHT_CENTER,
        BOTTOM_LEFT,
        BOTTOM_CENTER,
        BOTTOM_RIGHT
    )
    BOTTOM = BOTTOM_CENTER, BOTTOM_LEFT, BOTTOM_RIGHT
    CENTER_X = BOTTOM_CENTER, CENTER, TOP_CENTER
    CENTER_Y = CENTER, LEFT_CENTER, RIGHT_CENTER
    LEFT = BOTTOM_LEFT, LEFT_CENTER, TOP_LEFT
    RIGHT = BOTTOM_RIGHT, RIGHT_CENTER, TOP_RIGHT
    TOP = TOP_CENTER, TOP_LEFT, TOP_RIGHT


class Image:
    """Import as 'fi'."""
    # Use with the file selector as a filter.
    EXTENSION = (
        ".avif", ".avifs",
        ".xcf",
        ".jpg", ".jpeg", ".jpe", ".jif", ".jfif", ".jfi",
        ".png",
        ".gif", ".webp",
        ".tiff", ".tif",
        ".ps", ".psd",
        ".raw", ".rw2", ".arw", ".cr2", ".cr3", ".crw", ".nrw", ".k25",
        ".bmp", ".dib",
        ".jp2", ".j2k", ".jpx", ".jpm", ".mj2",
        ".ico",
        ".svg",
        ".pdf", ".mng", ".pcx", ".pcc", ".xpm",
        ".pix", ".matte", ".mask", ".alpha", ".als",
        ".fli", ".flc",
        ".xcf.bz2", ".xcfbz2",
        ".dds",
        ".dcm", ".dicom",
        ".hgt",
        ".eps",
        ".fit", ".fits",
        ".g3",
        ".gbr", ".gbp",
        ".gih",
        "xcf.gz.xcfgz",
        ".heic.heif.avif",
        ".j2c", ".jpc",
        ".jxl",
        ".cel",
        ".wmf", ".apm",
        ".ora",
        ".psp", ".tub", ".pspimage",
        ".pnm", ".ppm", ".pgm", ".pbm", ".pfm",
        ".hdr",
        ".dng",
        ".qtk",
        ".ari",
        ".bay",
        ".rdc",
        ".erf",
        ".raf",
        ".3fr", ".fff",
        ".data",
        ".dc2", ".dcr", ".kdc", ".kc2",
        ".mos",
        ".rwl",
        ".pxn",
        ".mef",
        ".mdc", ".mnw",
        ".orf",
        ".pef",
        ".cine", ".cin",
        ".cap", ".iiq",
        ".snw",
        ".x3f",
        ".srf", ".sr2",
        ".sgi", ".rgb", ".rgba", ".bw", ".icon",
        ".im1", ".im8", ".im24", ".im32", ".rs", ".ras", ".sun",
        ".tga", ".vda", ".icb", ".vst",
        ".xwd", ".bitmap",
        ".xcf.xz", ".xcfxz"
    )

    FIRST_IMAGE = "1st Image"
    FOLDER_ORDER_LIST = "Ascending (A to Z)", "Descending (Z to A)"
    LAYER_ORDER_LIST = "Bottom-Up", "Top-Down"
    LOAD_ERR = \
        "Roller tried to load an image file:\n'{}'\n and an error occurred."
    LOOP_MINUS = "Loop-Minus"
    LOOP_PLUS = "Loop-Plus"
    NEXT = "Next"
    PREVIOUS = "Previous"
    RANDOM = "Random"
    READ_ERR = "Roller tried to read from a" \
        " folder:\n'{}'\n and an error occurred."
    SLICE_ORDER_LIST = "Topleft to Bottom-Right", "Bottom-Right to Topleft"

    # dependent______________________
    # index-ordered
    LOOP_TYPE = LOOP_PLUS, LOOP_MINUS
    IMAGE_TYPE_LIST = (
        ok.FILE,
        ok.FOLDER,
        ok.IMAGE_NAME,
        ok.LOOP,
        ok.NEXT,
        ok.PREVIOUS,
        RANDOM,
        ok.TAB
    )


class Issue:
    """Identify output change-type. Double as a key. Import as 'vo'."""
    EMBOSS = 'emboss'
    MAIN = 'main'
    MATTER = 'matter'
    MODE = 'mode'
    OPACITY = 'opacity'
    NO_VOTE = 'NO'
    NULL = 'null'
    PER = 'per'
    SEED = 'seed'
    SWITCHED = 'switched'
    PLAN = _IMAGE, MATTER, SWITCHED
    PLAN_PER = MATTER, PER, SWITCHED
    WORK = MATTER, MODE, OPACITY
    WORK_PER = MATTER, MODE, OPACITY, PER


class Mask:
    """Import as 'ms'."""
    CIRCLE = _CIRCLE
    CORNER = "Corner"
    CUT_CORNER = "Cut Corner"
    DARKS = "Darks"
    ELLIPSE = _ELLIPSE
    ELLIPSE_NOTCH = "Ellipse Notch"
    EYE = "Eye"
    EYE_OPENING = "Eye Opening"
    FRINGE = "Fringe"
    GRADIENT = _GRADIENT
    IMAGE = _IMAGE
    LIGHTS = "Lights"
    PARALLELOGRAM_LEFT = _PARALLELOGRAM_LEFT
    PARALLELOGRAM_RIGHT = _PARALLELOGRAM_RIGHT
    RECTANGLE_NOTCH = "Rectangle Notch"
    RIP = "Rip"
    ROUNDED_CORNER = "Rounded Corner"
    TEXT = "Text"
    TRIANGLE = "Triangle"
    TRIANGLE_BOTTOM_LEFT = "Triangle, Bottom-Left"
    TRIANGLE_BOTTOM_RIGHT = "Triangle, Bottom-Right"
    TRIANGLE_TOPLEFT = "Triangle, Topleft"
    TRIANGLE_TOP_RIGHT = "Triangle, Top-Right"
    TRIANGLE_UP_REGULAR = _TRIANGLE_UP_REGULAR
    CORNER_TYPE_Q = (
        CUT_CORNER, ELLIPSE_NOTCH, RECTANGLE_NOTCH, ROUNDED_CORNER
    )
    HEXAGON_TYPE_Q = (
        _HEXAGON,
        _HEXAGON_SHEAR,
        _HEXAGON_TRUNCATED,
        _HEXAGON_TRUNCATED_SHEAR
    )
    OCTAGON_TYPE_Q = (
        _OCTAGON,
        _OCTAGON_SHEAR,
        _OCTAGON_ON_ITS_SIDE,
        _OCTAGON_ON_ITS_SIDE_SHEAR
    )
    RECTANGLE_TYPE_Q = (
        _MITER_SQUARE,
        _RECTANGLE,
        _SQUARE
    )
    TRIANGLE_TYPE_Q = (
        TRIANGLE_BOTTOM_LEFT,
        TRIANGLE_BOTTOM_RIGHT,
        _TRIANGLE_DOWN_REGULAR,
        _TRIANGLE_DOWN_SHEAR,
        _TRIANGLE_LEFT_REGULAR,
        _TRIANGLE_LEFT_SHEAR,
        _TRIANGLE_RIGHT_REGULAR,
        _TRIANGLE_RIGHT_SHEAR,
        TRIANGLE_TOPLEFT,
        TRIANGLE_TOP_RIGHT,
        TRIANGLE_UP_REGULAR,
        _TRIANGLE_UP_SHEAR
    )
    TYPE = [
        CIRCLE,
        CORNER,
        DARKS,
        _DIAMOND,
        ELLIPSE,
        EYE,
        EYE_OPENING,
        FRINGE,
        GRADIENT,
        _HEXAGON,
        IMAGE,
        LIGHTS,
        _OCTAGON,
        PARALLELOGRAM_LEFT,
        PARALLELOGRAM_RIGHT,
        _RECTANGLE,
        RIP,
        TEXT,
        TRIANGLE
    ]
    FACE_TYPE = TYPE[:]
    for i in (DARKS, LIGHTS):
        FACE_TYPE.pop(FACE_TYPE.index(i))


class Model:
    """Import as 'mo'."""
    MISSING_ITEM = "Roller {} can't find a {}, {}."

    # cell type
    CANVAS = 'canvas'


class NodePanel:
    """Import as np."""
    # main window's panel  or a dialog (Shadow)
    MAIN, SUB = range(2)


# Plan_________________________________________________________________________
class Plan:
    """Has values used by Plan. Import as 'fy'."""
    BACKGROUND_COLOR = 0, 0, 0

    # Items are:
    #   RGB
    #   Plan output color
    #   in layer z-order, bottom to top
    attr_q_ = (
        'CANVAS_LINE_COLOR',
        'CANVAS_MARGIN_COLOR',
        'CANVAS_PLAQUE_COLOR',
        'CANVAS_FRINGE_COLOR',
        'CANVAS_BORDER_COLOR',
        'CANVAS_LINE_COLOR',
        'CANVAS_STRIP_COLOR',
        'GRID_COLOR',
        'SHAPE_COLOR',
        'CELL_MARGIN_COLOR',
        'CELL_PLAQUE_COLOR',
        'CELL_FRINGE_COLOR',
        'CELL_BORDER_COLOR',
        'CELL_LINE_COLOR',
        'CELL_STRIP_COLOR',
        'FACE_PLAQUE_COLOR',
        'FACE_FRINGE_COLOR',
        'FACE_BORDER_COLOR',
        'FACE_LINE_COLOR',
        'FACE_STRIP_COLOR'
    )

    # {PlanOption Widget key: its GObject signal}
    SIGNAL_D = {
        i: i.replace(" ", "_").lower() + '_plan_change' for i in ak.KEY
    }


# Set class attribute and its value from
# string as its less redundant (less code).
# R, G, B component, 'a'
a = 24

for n in Plan.attr_q_:
    setattr(Plan, n, (a, a, a))
    a += 4
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


class Preset:
    """Import as 'fp'."""
    DEFAULT = u"Default"
    PRESET_SEPARATOR = "+"


class Resize:
    """Import as 'fz'."""
    CROP = "Crop"
    FIXED = "Fixed"
    FACTOR = "Factor"
    TEXT_TYPE = ok.COVER, ok.FILLED, ok.LOCKED, ok.TRIM
    RESIZE_TYPE_LIST = (
        ok.COVER,
        CROP,
        FACTOR,
        ok.FILLED,
        FIXED,
        ok.LOCKED,
        ok.TRIM
    )


class Triangle:
    """Import as 'ft'."""
    # width/height ratios of an equilateral triangle
    SCALE_UP = 1.1547005

    # Is also the sine of 60 degrees.
    SCALE_DOWN = .8660254

    TRIANGLE_DOWN_SHEAR = _TRIANGLE_DOWN_SHEAR
    TRIANGLE_DOWN_REGULAR = _TRIANGLE_DOWN_REGULAR
    TRIANGLE_LEFT_SHEAR = _TRIANGLE_LEFT_SHEAR
    TRIANGLE_LEFT_REGULAR = _TRIANGLE_LEFT_REGULAR
    TRIANGLE_RIGHT_SHEAR = _TRIANGLE_RIGHT_SHEAR
    TRIANGLE_RIGHT_REGULAR = _TRIANGLE_RIGHT_REGULAR
    TRIANGLE_UP_SHEAR = _TRIANGLE_UP_SHEAR
    TRIANGLE_UP_REGULAR = _TRIANGLE_UP_REGULAR
    DOWN_TYPE = TRIANGLE_DOWN_SHEAR, TRIANGLE_DOWN_REGULAR
    RIGHT_TYPE = TRIANGLE_RIGHT_SHEAR, TRIANGLE_RIGHT_REGULAR
    TRIANGLE = (
        TRIANGLE_DOWN_SHEAR,
        TRIANGLE_DOWN_REGULAR,
        TRIANGLE_LEFT_SHEAR,
        TRIANGLE_LEFT_REGULAR,
        TRIANGLE_RIGHT_SHEAR,
        TRIANGLE_RIGHT_REGULAR,
        TRIANGLE_UP_SHEAR,
        TRIANGLE_UP_REGULAR
    )
    HORIZONTAL_TRIANGLE = (
        TRIANGLE_LEFT_SHEAR,
        TRIANGLE_LEFT_REGULAR,
        TRIANGLE_RIGHT_SHEAR,
        TRIANGLE_RIGHT_REGULAR
    )
    VERTICAL_TRIANGLE = (
        TRIANGLE_DOWN_SHEAR,
        TRIANGLE_DOWN_REGULAR,
        TRIANGLE_UP_SHEAR,
        TRIANGLE_UP_REGULAR
    )
    INVERTED = {
        TRIANGLE_DOWN_SHEAR: TRIANGLE_UP_SHEAR,
        TRIANGLE_DOWN_REGULAR: TRIANGLE_UP_REGULAR,
        TRIANGLE_LEFT_SHEAR: TRIANGLE_RIGHT_SHEAR,
        TRIANGLE_LEFT_REGULAR: TRIANGLE_RIGHT_REGULAR,
        TRIANGLE_RIGHT_SHEAR: TRIANGLE_LEFT_SHEAR,
        TRIANGLE_RIGHT_REGULAR: TRIANGLE_LEFT_REGULAR,
        TRIANGLE_UP_SHEAR: TRIANGLE_DOWN_SHEAR,
        TRIANGLE_UP_REGULAR: TRIANGLE_DOWN_REGULAR
    }


class Shape:
    """Import as 'sh'."""
    BOTTOM = "Bottom"
    BOX_HORZ = 'box horz'
    BOX_HORZ_SHEAR = 'box horz shear'
    BOX_VERT = 'box vert'
    BOX_VERT_SHEAR = 'box vert shear'
    CIRCLE = _CIRCLE
    CIRCLE_HORIZONTAL = "Circle, Horizontally Aligned"
    CIRCLE_VERTICAL = "Circle, Vertically Aligned"
    DIAMOND = _DIAMOND
    ELLIPSE = _ELLIPSE
    ELLIPSE_HORIZONTAL = "Ellipse, Horizontally Aligned"
    ELLIPSE_RATIO = .13466
    ELLIPSE_VERTICAL = "Ellipse, Vertically Aligned"
    ELLIPSE_LIST = ELLIPSE_HORIZONTAL, ELLIPSE_VERTICAL
    HEXAGON_SHEAR = _HEXAGON_SHEAR
    HEXAGON = _HEXAGON
    HEXAGON_TRUNCATED = _HEXAGON_TRUNCATED
    HEXAGON_TRUNCATED_SHEAR = _HEXAGON_TRUNCATED_SHEAR
    LEFT = "Left"
    OCTAGON = _OCTAGON
    OCTAGON_SHEAR = _OCTAGON_SHEAR
    OCTAGON_ON_ITS_SIDE_SHEAR = _OCTAGON_ON_ITS_SIDE_SHEAR
    OCTAGON_DOUBLE_SHEAR = "Octagon, Double-spaced, Sheared"
    OCTAGON_ON_ITS_SIDE = _OCTAGON_ON_ITS_SIDE
    OCTAGON_DOUBLE = "Octagon, Double-spaced"
    OCTAGON_RATIO = .2928932188

    # circumscribe radius = inscribe radius / OCTAGON_CIRCUMRADIUS_RATIO
    OCTAGON_CIRCUMRADIUS_RATIO = .93

    PARALLELOGRAM_ALT_LEFT = "Parallelogram, Alt-Left"
    PARALLELOGRAM_ALT_RIGHT = "Parallelogram, Alt-Right"
    PARALLELOGRAM_LEFT = _PARALLELOGRAM_LEFT
    PARALLELOGRAM_RIGHT = _PARALLELOGRAM_RIGHT
    PYRAMID = 'pyramid'
    RECTANGLE = _RECTANGLE
    REGULAR = (
        OCTAGON_SHEAR,
        OCTAGON_ON_ITS_SIDE_SHEAR,
        OCTAGON_ON_ITS_SIDE,
        OCTAGON_DOUBLE,
        RECTANGLE,
        _SQUARE
    )
    RIGHT = "Right"
    SQUARE = _SQUARE
    MITER_SQUARE = _MITER_SQUARE
    TOP = "Top"
    EQUILATERAL_BOX = HEXAGON, HEXAGON_TRUNCATED
    BOX_SHAPE_LIST = HEXAGON_SHEAR, HEXAGON_TRUNCATED_SHEAR
    BOX_TYPE = TOP, BOTTOM, LEFT, RIGHT
    CURVED = ELLIPSE_LIST + (
        CIRCLE, CIRCLE_HORIZONTAL, CIRCLE_VERTICAL, ELLIPSE
    )
    DOUBLE = (
        ELLIPSE_LIST +
        (
            DIAMOND,
            BOX_HORZ,
            BOX_HORZ_SHEAR,
            BOX_VERT,
            BOX_VERT_SHEAR,
            CIRCLE_VERTICAL,
            CIRCLE_HORIZONTAL,
            HEXAGON,
            HEXAGON_SHEAR,
            HEXAGON_TRUNCATED,
            HEXAGON_TRUNCATED_SHEAR,
            MITER_SQUARE,
            OCTAGON_DOUBLE_SHEAR,
            OCTAGON_DOUBLE
        )
    )
    CELL_SHAPE_LIST = (
        RECTANGLE,
        CIRCLE,
        DIAMOND,
        ELLIPSE,
        HEXAGON_SHEAR,
        HEXAGON,
        HEXAGON_TRUNCATED_SHEAR,
        HEXAGON_TRUNCATED,
        MITER_SQUARE,
        OCTAGON_SHEAR,
        OCTAGON,
        OCTAGON_ON_ITS_SIDE_SHEAR,
        OCTAGON_ON_ITS_SIDE,
        _PARALLELOGRAM_LEFT,
        _PARALLELOGRAM_RIGHT,
        SQUARE,
        _TRIANGLE_DOWN_SHEAR,
        _TRIANGLE_DOWN_REGULAR,
        _TRIANGLE_LEFT_SHEAR,
        _TRIANGLE_LEFT_REGULAR,
        _TRIANGLE_RIGHT_SHEAR,
        _TRIANGLE_RIGHT_REGULAR,
        _TRIANGLE_UP_SHEAR,
        _TRIANGLE_UP_REGULAR
    )
    EQUILATERAL_LIST = (
        CIRCLE_HORIZONTAL,
        CIRCLE_VERTICAL,
        HEXAGON,
        HEXAGON_TRUNCATED,
        OCTAGON,
        OCTAGON_ON_ITS_SIDE,
        OCTAGON_DOUBLE,
        SQUARE,
        MITER_SQUARE,
        _TRIANGLE_DOWN_REGULAR,
        _TRIANGLE_LEFT_REGULAR,
        _TRIANGLE_RIGHT_REGULAR,
        _TRIANGLE_UP_REGULAR
    )
    SHAPE_LIST = (
        RECTANGLE,
        DIAMOND,
        ELLIPSE_HORIZONTAL,
        ELLIPSE_VERTICAL,
        HEXAGON_SHEAR,
        HEXAGON_TRUNCATED_SHEAR,
        OCTAGON_SHEAR,
        OCTAGON_ON_ITS_SIDE_SHEAR,
        OCTAGON_DOUBLE_SHEAR,
        PARALLELOGRAM_ALT_LEFT,
        PARALLELOGRAM_ALT_RIGHT,
        _PARALLELOGRAM_LEFT,
        _PARALLELOGRAM_RIGHT,
        _TRIANGLE_DOWN_SHEAR,
        _TRIANGLE_LEFT_SHEAR,
        _TRIANGLE_RIGHT_SHEAR,
        _TRIANGLE_UP_SHEAR
    )
    EQUILATERAL_TYPE = (
        CIRCLE,
        CIRCLE_HORIZONTAL,
        CIRCLE_VERTICAL,
        HEXAGON,
        HEXAGON_TRUNCATED,
        MITER_SQUARE,
        OCTAGON_ON_ITS_SIDE,
        OCTAGON_DOUBLE,
        OCTAGON,
        SQUARE,
        _TRIANGLE_DOWN_REGULAR,
        _TRIANGLE_LEFT_REGULAR,
        _TRIANGLE_RIGHT_REGULAR,
        _TRIANGLE_UP_REGULAR
    )

    # Has an alternate ego.
    ALT_PARALLELOGRAM = {
        PARALLELOGRAM_ALT_LEFT: PARALLELOGRAM_ALT_RIGHT,
        PARALLELOGRAM_ALT_RIGHT: PARALLELOGRAM_ALT_LEFT
    }


class Signal:
    """Import as 'si'."""
    ACCEPT_FOCUS = 'accept_focus'
    ACCEPT_WINDOW = 'accept_window'
    ADD_ITEM = 'add_item'
    AFTER_VIEW = 'after_view'
    BACK_CHANGE = 'back_change'
    CANCEL_WINDOW = 'cancel_window'
    CANVAS_MARGIN_CALC = 'canvas_margin_calc'
    CANVAS_MARGIN_CHANGE = 'canvas_margin_change'
    CANVAS_MARGIN_VIEW = 'canvas_margin_view'
    CANVAS_RECT_CALC = 'canvas_rect_calc'
    CANVAS_SHIFT_CHANGE = 'canvas_shift_change'
    CANVAS_SHIFT_CALC = 'canvas_shift_calc'
    CANVAS_SHIFT_VIEW = 'canvas_shift_view'
    CELL_MARGIN_CALC = 'cell_margin_calc'
    CELL_MARGIN_CHANGE = 'cell_margin_change'
    CELL_MARGIN_VIEW = 'cell_margin_view'
    CELL_RECT_CALC = 'cell_rect_calc'
    CELL_RECT_CHANGE = 'cell_rect_change'
    CELL_RECT_VIEW = 'cell_rect_view'
    CELL_SHIFT_CALC = 'cell_shift_calc'
    CELL_SHIFT_CHANGE = 'cell_shift_change'
    CELL_SHIFT_VIEW = 'cell_shift_view'
    CLOSE_VIEW_IMAGE = 'close_view_image'
    COLOR_CHANGE = 'color_change'
    COMBO_CREATED = 'combo_created'
    DIALOG_CLOSE = 'dialog_close'
    DIALOG_DRAWN = 'dialog_drawn'
    DIALOG_OPEN = 'dialog_open'
    DISAPPEAR = 'disappear'
    EMBOSS_CHANGE = 'emboss_change'
    FONT_SIZE_CHANGE = 'font_size_change'
    GLOBAL_EMBOSS = 'global_emboss'
    GLOBAL_SEED = 'global_seed'
    GRID_CHANGE = 'grid_change'
    GROUP_CHANGE = 'group_change'
    GROUP_VIEW = 'group_view'
    HELM_CHANGE = 'helm_change'
    LIGHT_CHANGE = 'light_change'
    MAKE_MATERIAL = 'make_material'
    MODEL_CREATED = 'model_created'
    MODEL_MOVE = 'model_move'
    MODEL_NEW = 'model_new'
    MODEL_RENAME = 'model_rename'
    MODEL_REVISE = 'model_revise'
    PANEL_CHANGE = 'panel_change'
    PEEK = 'peek'
    PER_CHANGE = 'per_change'
    PREVIEW = 'preview'
    RANDOMIZE = 'randomize'
    RECTANGLE_CALC = 'rectangle_calc'
    RECTANGLE_CHANGE = 'rectangle_change'
    RECTANGLE_VIEW = 'rectangle_view'
    REMOVE_MATERIAL = 'remove_material'
    RENAME = 'rename'
    RESIZE = 'resize'
    RING_CLEARED = 'ring_cleared'
    RING_EMPTY = 'ring_empty'
    ROW_CHANGE = 'row_change'
    SEED_CHANGE = 'seed_change'
    SELECT_ITEM = 'select_item'
    SEQUENCE = 'sequence'
    UPDATE_TREE = 'update_tree'
    UI_CHANGE = 'ui_change'
    VALIDATE = 'validate'
    VIEW_SIZE_CHANGE = 'view_size_change'
    VOTE_CHANGE = 'vote_change'
    WINDOW_SIZE_CHANGE = 'window_size_change'
    WINDOW_XY_CHANGE = 'window_xy_change'
    run_first = gobject.SIGNAL_RUN_FIRST, None, (gobject.TYPE_PYOBJECT,)
    run_last = gobject.SIGNAL_RUN_LAST, None, (gobject.TYPE_PYOBJECT,)
    BOOTH_D = {VOTE_CHANGE: run_first}
    COMBO_D = {COMBO_CREATED: run_last}
    FONT_SIZE_D = {FONT_SIZE_CHANGE: run_first}
    GROUP_D = {
        AFTER_VIEW: run_last,
        BACK_CHANGE: run_first,
        DISAPPEAR: run_first,
        GROUP_CHANGE: run_first,
        GROUP_VIEW: run_first,
        RANDOMIZE: run_first,
        SEQUENCE: run_first
    }
    BUTTON_D = {
        MAKE_MATERIAL: run_first,
        REMOVE_MATERIAL: run_first,
        VALIDATE: run_first
    }
    IMAGE_D = {CLOSE_VIEW_IMAGE: run_first}
    MODEL_D = {
        CANVAS_MARGIN_CALC: run_first,
        CANVAS_MARGIN_CHANGE: run_first,
        CANVAS_RECT_CALC: run_first,
        CANVAS_SHIFT_CALC: run_first,
        CANVAS_SHIFT_CHANGE: run_first,
        CELL_MARGIN_CALC: run_first,
        CELL_MARGIN_CHANGE: run_first,
        CELL_RECT_CALC: run_first,
        CELL_RECT_CHANGE: run_first,
        CELL_SHIFT_CALC: run_first,
        CELL_SHIFT_CHANGE: run_first,
        GRID_CHANGE: run_first,
        RECTANGLE_CALC: run_first,
        RECTANGLE_CHANGE: run_first
    }
    NODE_D = {
        ADD_ITEM: run_first,
        SELECT_ITEM: run_first,
        UPDATE_TREE: run_first
    }
    PAST_D = {
        CANVAS_MARGIN_VIEW: run_first,
        CANVAS_SHIFT_VIEW: run_first,
        CELL_MARGIN_VIEW: run_first,
        CELL_RECT_VIEW: run_first,
        CELL_SHIFT_VIEW: run_first,
        RECTANGLE_VIEW: run_first
    }
    PER_D = {
        DISAPPEAR: run_first,
        PER_CHANGE: run_first
    }
    PER_BUTTON_D = {ACCEPT_WINDOW: run_last}
    PLANNER_D = {}
    RAINBOW_D = {COLOR_CHANGE: run_first}
    RING_D = {
        COMBO_CREATED: run_first,
        GLOBAL_EMBOSS: run_first,
        GLOBAL_SEED: run_first,
        HELM_CHANGE: run_first,
        LIGHT_CHANGE: run_first,
        MODEL_CREATED: run_first,
        MODEL_MOVE: run_first,
        MODEL_NEW: run_first,
        MODEL_RENAME: run_first,
        MODEL_REVISE: run_first,
        PANEL_CHANGE: run_first,
        RENAME: run_first,
        RESIZE: run_first,
        RING_EMPTY: run_first,
        RING_CLEARED: run_first,
        ROW_CHANGE: run_first,
        UI_CHANGE: run_first,
        VIEW_SIZE_CHANGE: run_first,
        WINDOW_SIZE_CHANGE: run_first,
        WINDOW_XY_CHANGE: run_first
    }
    WINDOW_D = {
        ACCEPT_FOCUS: run_last,
        ACCEPT_WINDOW: run_last,
        CANCEL_WINDOW: run_last,
        DIALOG_CLOSE: run_last,
        DIALOG_DRAWN: run_last,
        DIALOG_OPEN: run_last,
        PEEK: run_last,
        PREVIEW: run_last
    }
    for i, a in Plan.SIGNAL_D.items():
        PLANNER_D[a] = run_first


class Widget:
    """Import as 'fw'."""
    LAST_USED = "Last Used"
    LIST_SEPARATOR = _LIST_SEPARATOR
    MARGIN = 4
    SCROLL_SPAN = 22
