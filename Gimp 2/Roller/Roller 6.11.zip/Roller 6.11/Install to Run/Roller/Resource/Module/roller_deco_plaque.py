#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb    # type: ignore
from roller_a_contain import Deco, Run
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    add_group_type,
    coloring,
    prep_deco_type,
    create_facial_main,
    create_facial_per,
    make_deco_material,
    ready_canvas_rect,
    ready_shape,
    select_rect,
    test_image,
    transform_foam
)
from roller_fu import select_shape, verify_layer_group
from roller_view_hub import do_mod


def create_face(maya, d, group):
    """
    Process a Face/Plaque item.

    maya: Maya
    d: dict
        Plaque Preset

    group: layer group
        Is the parent of Face layer output.
    """
    model = maya.model
    k = maya.k
    if test_image(maya, d):
        is_color = coloring(d)
        maya.rect = model.get_facing_rect(k)

        if is_color:
            Deco.shape = model.get_facing_shape(k)

        else:
            maya.rect = model.get_facing_rect(k)
            Deco.shape = model.get_facing_form(k)

        select_shape(Run.j, Deco.shape)

        z = make_deco_material(maya, d, group)
        if z and not is_color:
            transform_foam(maya.rect, z, model.get_facing_foam(k))


def create_facing(maya, d, group):
    """
    Process a Facing/Plaque item.

    maya: Maya
    d: dict
        Plaque Preset

    group: layer group
        Is the parent of Facing layer output.

    Return: layer or None
        Facing Plaque
    """
    k = maya.k
    model = maya.model
    if test_image(maya, d):
        is_color = coloring(d)
        maya.rect = model.get_facing_rect(k)

        if is_color:
            Deco.shape = model.get_facing_shape(k)

        else:
            maya.rect = model.get_facing_rect(k)
            Deco.shape = model.get_facing_form(k)

        if is_color:
            select_shape(Run.j, Deco.shape)

        else:
            select_rect(Run.j, *maya.rect)

        z = make_deco_material(maya, d, group)

        if z and not is_color:
            z = transform_foam(maya.rect, z, model.get_facing_foam(k))
            model.clip_facing(z, k)
        return z


def do(maya, make):
    """
    Create Plaque for a navigation branch.

    maya: Maya
    Return: layer or None
        Facing Plaque
    """
    d = maya.value_d

    if not Run.i:
        # Preserve.
        type_ = d[ok.TYPE]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = {
            ny.CELL: fy.CELL_PLAQUE_COLOR,
            ny.CANVAS: fy.CANVAS_PLAQUE_COLOR,
            ny.FACE: fy.FACE_PLAQUE_COLOR,
            ny.FACING: fy.FACE_PLAQUE_COLOR
        }[maya.any_group.render_key[-2]]

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.i:
        # Restore.
        d[ok.TYPE] = type_
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Draw Canvas/Plaque.

    maya: Maya
    Return: layer or None
        Plaque material
    """
    return do(maya, make_canvas)


def do_cell_main(maya):
    """
    Draw Cell/Plaque for main.

    maya: Maya
    Return: layer or None
        Plaque material
    """
    return do(maya, make_cell_main)


def do_cell_per(maya):
    """
    Draw Cell/Plaque/Per.

    maya: Maya
    Return: layer or None
        Plaque material
    """
    return do(maya, make_cell_per)


def do_face_main(maya):
    """
    Draw Face/Plaque for main.

    maya: Maya
    Return: layer or None
        Plaque material
    """
    return do(maya, make_face_main)


def do_face_per(maya):
    """
    Draw Face/Plaque/Per.

    maya: Maya
    Return: layer or None
        Plaque material
    """
    return do(maya, make_face_per)


def do_facing_main(maya):
    """
    Draw Facing/Plaque for main.

    maya: Maya
    Return: layer or None
        Plaque material
    """
    return do(maya, make_facing_main)


def do_facing_per(maya):
    """
    Draw Facing/Plaque/Per.

    maya: Maya
    Return: layer or None
        Plaque material
    """
    return do(maya, make_facing_per)


def make_canvas(maya, d):
    """
    Draw Canvas/Plaque material.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    if test_image(maya, d):
        prep_deco_type(d, maya.group)
        ready_canvas_rect(maya, d)
        return make_deco_material(maya, d, maya.group)


def make_cell_main(maya, d):
    """
    Create Cell/Plaque for main.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    def _do_one_material():
        _z = None

        # Create a single selection.
        # Image type is not one material, so there's no image check.
        pdb.gimp_selection_none(j)

        for _k in maya.main_q:
            maya.k = _k
            ready_shape(maya, d, option=CHANNEL_OP_ADD)

        if test_image(maya, d):
            _z = make_deco_material(maya, d, maya.group)
        return _z

    def _do_many_material():
        """
        Inside a group, make a layer with its own material for each
        cell. Collapse the group and return the resulting layer.
        """
        _group = add_group_type(maya, d)

        prep_deco_type(d, maya.group)

        for _k in maya.main_q:
            maya.k = _k
            if test_image(maya, d):
                ready_shape(maya, d)
                make_deco_material(maya, d, _group)
        return verify_layer_group(_group)

    j = Run.j
    n = d[ok.TYPE]

    if n in dc.PER_TYPE:
        # All the Plaque is the same material,
        # but is applied cell-by-cell.
        return _do_many_material()
    else:
        # All the Plaque is the same
        # material and is applied one time.
        return _do_one_material()


def make_cell_per(maya, d):
    """
    Make Cell/Plaque/Per.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    if test_image(maya, d):
        prep_deco_type(d, maya.group)
        ready_shape(maya, d)
        return make_deco_material(maya, d, maya.group)


def make_face_main(maya, d):
    """
    Create Face/Plaque for main.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    return create_facial_main(maya, d, create_face)


def make_face_per(maya, d):
    """
    Make Face/Plaque/Per.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    return create_facial_per(maya, d, create_face)


def make_facing_main(maya, d):
    """
    Create Facing/Plaque for main.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    return create_facial_main(maya, d, create_facing)


def make_facing_per(maya, d):
    """
    Make Facing/Plaque/Per.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        Plaque material
    """
    return create_facial_per(maya, d, create_facing)
