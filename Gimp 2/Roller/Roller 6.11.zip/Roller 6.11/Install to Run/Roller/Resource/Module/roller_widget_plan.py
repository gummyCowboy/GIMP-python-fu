#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import Plan as fy, Signal as si, Widget as fw
from roller_constant_key import Option as ok, Plan as ak, Widget as wk
from roller_one_tip import Tip
from roller_widget import set_widget_attr
from roller_widget_box import Box as boxer
from roller_widget_check_button import CheckButtonPlan
from roller_widget_row import SelectRow
import gobject  # type: ignore
import gtk      # type: ignore

TOOLTIP = {
    ak.BORDER: Tip.PLAN_BORDER,
    ak.CELL_SHAPE: Tip.PLAN_CELL_SHAPE,
    ak.CORNER: Tip.PLAN_CORNER,
    ak.DIMENSION: Tip.PLAN_DIMENSION,
    ak.GRID: Tip.PLAN_GRID,
    ak.NAME: Tip.PLAN_IMAGE_NAME,
    ak.POSITION: Tip.PLAN_POSITION,
    ak.RATIO: Tip.PLAN_RATIO
}


class PlanOption(boxer, gobject.GObject, object):
    """Has CheckButtons for filtering Plan output."""
    __gsignals__ = si.PLANNER_D
    change_signal = None
    has_table_label = True

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        w = fw.MARGIN
        w1 = w // 2
        buttons = []
        vbox_list = boxer(), boxer()
        relay = d[wk.RELAY][:]

        # {Plan sub-option key: CheckButton}
        self._check_button_d = {}

        set_widget_attr(self, d)
        boxer.__init__(self, box=gtk.VBox, padding=(w, w1, 0, 0))
        gobject.GObject.__init__(self)

        hbox = gtk.HBox()
        keys = d[wk.VAL]
        d[wk.ROW_KEY] = ok.PLANNER
        d[wk.RELAY].insert(0, self.on_plan_button_switch)

        for k in keys:
            d[wk.KEY] = k
            d[wk.TEXT] = k
            d[wk.ISSUE] = k.lower()
            d[wk.SIGNAL] = fy.SIGNAL_D[k]

            buttons.append(CheckButtonPlan(padding=(0, 0, w, w), **d))

            self._check_button_d[k] = buttons[-1]
            if k in TOOLTIP:
                buttons[-1].set_tooltip_text(TOOLTIP[k])

        d[wk.RELAY] = relay

        d.pop(wk.ROW_KEY)
        d.pop(wk.ISSUE)
        hbox.add(vbox_list[0])
        hbox.add(vbox_list[1])
        self.add(hbox)
        self.add(SelectRow(buttons, **d))

        vbox = vbox_list[0]
        midpoint = len(buttons) // 2 + len(buttons) % 2
        d[wk.RELAY] = relay
        for i, button in enumerate(buttons):
            if i == midpoint:
                vbox = vbox_list[1]
            vbox.add(button)

    def get_a(self):
        """
        Assemble a dictionary of Plan sub-option value.

        Return: dict
            {Plan sub-option key: Widget value}
        """
        d = OrderedDict()

        for k, g in self._check_button_d.items():
            d[k] = g.get_a()
        return d

    def get_option_a(self, k):
        """
        Fetch the value of a Plan option CheckButton.

        k: string
            sub-option key

        Return: bool
            0 or 1
            Is the value of the CheckButton in the interface.
        """
        return self._check_button_d[k].get_a()

    def on_plan_button_switch(self, g):
        """
        A Plan CheckButton was switched. Send a Signal
        notifying Plan sub-option change listener.

        g: CheckButton
            Is responsible.
        """
        a = g.get_a()
        self.emit(g.signal, (a, a != g.view_value[0]))

    def set_a(self, d):
        """
        Set the value of the CheckButtons.

        d: dict
            for group
        """
        e = self._check_button_d
        [e[k].set_a(d[k]) for k in d if k in e]

    def set_view_value(self, i, d):
        """
        The view value is the value of the Widget after
        its navigation step is processed during a view run.

        i: int
            Plan or Work index

        d: dict
            PlanOption value
        """
        if i == 0:
            for k, a in d.items():
                self._check_button_d[k].view_value[0] = a


# Register the custom signals.
gobject.type_register(PlanOption)
