#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Triangle as ft
from roller_model_goo import Goo
from roller_polygon import (
    calc_pin_xy, make_coord_list, invert_triangle
)


def calc_triangle_horz(model, o):
    """
    Calculate a grid of horizontally facing cell triangle.

    For Model cell, calculate 'cell' and 'merge'
    rectangle and their inscribed 'form' polygon.

    model: Model
    o: One
        Has Cell/Type Option key as attribute.

    Return: dict
        {value: [bool, bool]}
        {cell key: [Plan vote change, Work vote change]}
    """
    def _get_shape():
        """
        Do shape.

        Return: tuple
            shape
        """
        _is_inverse = invert_triangle(r, c)

        # Both left and right triangles use this
        # function, but the right is the inverse of the left.
        if is_right:
            _is_inverse = not _is_inverse

        return (x, y, x1, y1, x, y2) if _is_inverse \
            else (x1, y, x, y1, x1, y2)

    # {r_c: [Plan vote, Work vote]}, 'vote_d'
    vote_d = {}

    did_cell = model.past.did_cell
    row, column = model.grid
    is_right = model.cell_shape in ft.RIGHT_TYPE
    goo_d = model.goo_d
    x, y, canvas_w, canvas_h = model.canvas_pocket.rect

    if o.grid_type in (gr.CELL_SIZE, gr.SHAPE_COUNT):
        # cell size
        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w = min(canvas_w, o.column_width)
            h = min(canvas_h, o.row_height)

            # grid size
            h1 = h / 2.
            h2 = h - h1
            s = column * w, row * h1 + h2

        else:
            # horizontal triangles
            w1 = canvas_w / column
            h1 = canvas_h / (.5 + row * .5)

            # two possible solutions
            # solution one
            ratio_w, ratio_h = h1 * ft.SCALE_DOWN, h1
            h2 = ratio_h / 2.
            h3 = ratio_h - h2
            s = column * ratio_w, row * h2 + h3

            # solution two
            ratio_w1, ratio_h1 = w1, w1 * ft.SCALE_UP
            h2 = ratio_h1 / 2.
            h3 = ratio_h1 - h2
            s1 = column * ratio_w1, row * h2 + h3

            # If solution one fails, use solution two.
            if s[0] > canvas_w or s[1] > canvas_h:
                s = s1
                w, h = ratio_w1, ratio_h1
            else:
                w, h = ratio_w, ratio_h
        x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

    else:
        w = canvas_w / column
        h = canvas_h / (.5 + row * .5)

    h /= 2.
    q_x = make_coord_list(canvas_w, column + 2, x, span=w)
    q_y = make_coord_list(canvas_h, row + 2, y, span=h)

    for r_c in model.cell_q:
        r, c = r_c
        y, y1, y2 = q_y[r], q_y[r + 1], q_y[r + 2]
        x, x1 = q_x[c], q_x[c + 1]
        a = goo_d[r_c] = Goo(r_c)

        # Prevent round to zero with max 1.
        a.cell.rect = a.merged.rect = \
            x, y, max(1., x1 - x), max(1., y2 - y)

        a.form = _get_shape()
        vote_d[r_c] = did_cell(r_c)
    return vote_d
