#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_EXCLUSION,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_HSV_SATURATION,
    LAYER_MODE_NORMAL,
    pdb
)
from random import randint
from roller_a_contain import Globe, Run
from roller_a_gegl import emboss
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def_access import get_default_value
from roller_fu import (
    blur_selection, clone_layer, make_layer_group, merge_layer_group
)
from roller_fu_mode import get_gradient_mode
from roller_maya_style import Style
from roller_view_hub import do_gradient_for_layer, do_mod
from roller_view_preset import combine_seed
from roller_view_real import (
    add_sub_base_group, add_wip_layer, insert_copy_above
)
from roller_view_hub import get_gradient_factors

"""
Define 'backdrop/density_gradient' as a Maya-subtype
for managing a variation of backdrop style layer.
"""


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: Style
    Return: layer
        Density Gradient material
    """
    j = Run.j
    d = maya.value_d
    parent = add_sub_base_group(maya)
    z = add_wip_layer("Plasma", maya.group)
    group = make_layer_group(j, "WIP", parent, 0, z=z)

    combine_seed(d)
    pdb.gimp_selection_none(j)

    # lowest turbulence, '1.'
    pdb.plug_in_plasma(j, z, int(d[ok.SEED] + Globe.seed), 1.)

    z = add_wip_layer("Difference", group)
    z.mode = LAYER_MODE_DIFFERENCE

    # medium turbulence, '3.5'
    pdb.plug_in_plasma(j, z, randint(0, 100000), 3.5)

    z = z1 = add_wip_layer("Difference 2", group)
    z.mode = LAYER_MODE_DIFFERENCE

    # highest turbulence, '7.'
    pdb.plug_in_plasma(j, z, randint(0, 100000), 7.)

    z = insert_copy_above(z, group.layers[0])
    z.mode = LAYER_MODE_GRAIN_EXTRACT

    for i in ((255, 0, 0), (0, 255, 0), (255, 0, 255)):
        pdb.plug_in_colortoalpha(j, z, i)

    pdb.plug_in_unsharp_mask(
        j, z1,
        3.,                     # radius
        100.,                   # amount
        .0                      # threshold
    )
    z2 = clone_layer(z1, n="Blur")

    blur_selection(z1, 3)

    z1.mode = LAYER_MODE_NORMAL
    z2.mode = LAYER_MODE_DIFFERENCE
    z = clone_layer(z1, n="HSV Saturation")
    z.mode = LAYER_MODE_HSV_SATURATION

    pdb.gimp_image_reorder_item(j, z, group, 0)

    z = clone_layer(z, n="Difference #3")
    z.mode = LAYER_MODE_DIFFERENCE
    z = insert_copy_above(z, group.layers[0])
    z.mode = LAYER_MODE_EXCLUSION

    emboss(z, Globe.azimuth, 30, 2)

    z1 = clone_layer(z, n="Exclusion #2")
    z1.mode = LAYER_MODE_EXCLUSION
    e = get_default_value(by.GRADIENT_FILL)

    e.update(d)

    merge_layer_group(group)

    e[ok.GRADIENT] = d[ok.RW1][ok.GRADIENT]
    e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
        get_gradient_factors(d)
    z = do_gradient_for_layer(e, parent, 0)
    z.mode = get_gradient_mode(d)

    pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

    z = merge_layer_group(parent)

    do_mod(z, d[ok.RW1][ok.MOD])
    return maya.rename_layer(z)


class DensityGradient(Style):
    """Create Backdrop Style output."""
    is_dependent = False
    is_seeded = True

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.RW1,),
                k_path + (ok.RW1, ok.MOD),
                k_path + (ok.RW1, ok.MOD, ok.BLUR_D)
            ],
            make_style
        )
