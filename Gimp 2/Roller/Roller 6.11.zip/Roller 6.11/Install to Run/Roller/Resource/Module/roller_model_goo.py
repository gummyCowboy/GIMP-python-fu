#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_many_rect import Rect

"""
Define 'model_goo' as having containers for
storing a Cell, Face, and Facing's property.
"""


class Goo(object):
    """Contain  Cell attribute."""

    def __init__(self, k):
        """
        k: tuple
            cell key
            (row, column)
        """
        # cell index and key
        self.k = k

        # Rect
        # Is the original cell rectangle,
        # before the 'merged' cell is calculated.
        self.cell = Rect()

        # Is the 'plaque' polygon before Cell/Shift
        # and is inscribed inside the 'merged' rectangle.
        self.form = None

        # Rect
        # Is the cell rectangle, except with the Table Model,
        # where it is the cell size of a cell block.
        self.merged = Rect()

        # tuple
        # Is the Cell polygon shape without margin
        # and is derived from the Shift rectangle.
        self.plaque = None

        # Rect
        # Is the cell rectangle within margin.
        self.pocket = Rect()

        # tuple
        # Is the cell polygon shape that is
        # derived from the 'pocket' rectangle.
        self.shape = None

        # Rect
        # Is the 'merged' rectangle after it has shifted.
        self.shift = Rect()


class Map:
    """Contain Facial attribute."""

    def __init__(self, d, p):
        """
        d: dict
            Cell/Type Preset

        p: function
            Call to transform a rectangle into output suitable foam.
        """
        # function
        # Clip rotated material.
        self.clip_p = None

        # tuple
        # Is a flag-ordered x, y float series.
        # (point, ...) -> (topleft, top-right, bottom-left, bottom-right)
        self.foam = None

        # function
        # Calculate 'foam' from a rectangle.
        self.foam_p = None

        # tuple
        # input polygon selection
        self.form = None

        # Rect
        # input rectangle selection
        self.merged = Rect()

        # tuple
        # output for a color fill
        self.shape = None

        # function
        # Shape a rectangle into output 'foam'.
        self.transform = p

        self.is_inward = d.get(ok.INWARD)


class Mesh(Goo):
    """Contain Box/Face attribute."""

    def __init__(self, k):
        Goo.__init__(self, k)

        # Is the Cap Face's inner vertex position, 'cap_x, cap_y'.
        # for when there is no Shift or Margin change. Is also
        # the final value used by Face geometry.
        # Is the Cap value set by Box/Cell/Type, 'form_cap'.
        # Is the Cap value set by Shift change, 'shift_cap'.
        self.cap_x = \
            self.cap_y = \
            self.form_cap_x = \
            self.form_cap_y = \
            self.shift_cap_x = \
            self.shift_cap_y = .0
