#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Plan as ak, Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_image import check_matter, make_group_layer
from roller_gimp_layer import get_layer_position
from roller_maya import Maya
from roller_maya_add import Add
from roller_maya_bulb import Bulb
from roller_maya_layer import check_mix_basic
from roller_step import get_branch_part


def check_strip_matter(maya):
    """
    Plan uses this function to change the color
    of the Strip before drawing itself.

    Return: layer or None
        Has Strip.
    """
    def _do(_maya):
        _e = maya.get_value_d()
        _color = _e[de.COLOR_1]

        # Override.
        _e[de.COLOR_1] = {
            de.CELL: ak.CELL_STRIP_COLOR,
            de.CANVAS: ak.CANVAS_STRIP_COLOR,
            de.FACE: ak.FACE_STRIP_COLOR,
            de.FACING: ak.FACE_STRIP_COLOR
        }[get_branch_part(maya.any_group.type_step_k)]

        _z = _do_matter(maya)
        _e[de.COLOR_1] = _color

        if _z:
            _z.opacity = 66.
        return _z

    _do_matter = maya.do_matter
    maya.do_matter = _do
    return check_matter(maya)


def make_strip_group(maya):
    """
    Make a group layer for the Strip layer.

    maya: Maya
    Return: group layer
    """
    if not maya.group:
        z = maya.super_maya.group
        maya.group = make_group_layer(
            Run.j, z.parent, get_layer_position(z) + 1, "Strip"
        )
    return maya.group


class Strip(Maya):
    """Manage Strip layer output."""
    # An issue become become a boolean attribute
    # (e.g. 'matter' -> 'is_matter').
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, super_maya, view_i, do_strip, k_path):
        """
        super_maya: Maya
            the greater Maya; a Caption Maya variant

        view_i: int
            0 or 1; plan or work; view-type index

        do_strip: function
            Call to make Strip material.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        put = (make_strip_group, (check_strip_matter, check_matter)[view_i],)
        issue_q = 'group', 'matter'
        self.do_matter = do_strip

        if view_i:
            put += (check_mix_basic,)
            issue_q += (None,)

        Maya.__init__(self, any_group, view_i, zip(put, issue_q), k_path)
        if view_i:
            self.sub_maya[sm.ADD] = Add(any_group, self, k_path + (de.ADD,))
            self.sub_maya[sm.BULB] = Bulb(any_group, self, de.STRIP)

    def do(self, d, is_change, is_back):
        """
        Manage layer output during a view run.

        d: dict
            Caption Preset
            {Identity: value}

        is_change: bool
            Is True if Caption has changed.

        is_back: bool
            Is True if the background has changed.
        """
        d = self.value_d = d[rk.BRW][de.STRIP]
        self.go = d[de.SWITCH]

        if self.go:
            self.is_matter |= is_change

        self.realize()

        if self.go:
            if self.matter:
                if self.view_i:
                    self.sub_maya[sm.ADD].do(
                        d[de.ADD],
                        self.is_matter,
                        self.is_matter,
                        is_back,
                        self.group
                    )
                    self.sub_maya[sm.BULB].do(self.is_matter)
            else:
                self.die()
        self.reset_issue()
