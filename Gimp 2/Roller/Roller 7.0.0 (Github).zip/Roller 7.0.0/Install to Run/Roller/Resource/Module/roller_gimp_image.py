#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from gimpfu import (   # type: ignore
    LAYER_MODE_NORMAL,
    LAYER_MODE_PASS_THROUGH,
    RGB,
    RGBA_IMAGE,
    pdb
)
from roller_constant_identity import Identity as de
from roller_container import PlanZ, Run
from roller_gimp_layer import (
    clear_inverse_selection, get_layer_position, hide_layer, show_layer
)
from roller_gimp_selection import select_rect
from roller_step import get_model_branch_key, get_parts
from roller_wip import Wip

# {group key: sortable position ordinal}
LEAF_D = OrderedDict([
    (de.CAPTION, 0),
    (de.LINE, 1),
    (de.IMAGE, 2),
    (de.BORDER, 3),
    (de.FRINGE, 4),
    (de.PLAQUE, 5),
    (de.MARGIN, 6),
    (de.TYPE, 7)
])

# {Node/branch item key: sortable position ordinal}
BRANCH_D = OrderedDict([
    (de.FACING, 0),
    (de.FACE, 1),
    (de.CELL, 2),
    (de.CANVAS, 3),
])

CREATE_ARG = BRANCH_D, LEAF_D, None


def _check_layer(maya, n, p):
    """
    Make a new layer and remove its old layer counterpart,
    if it exists. The layer is assumed to need an update.

    maya: Maya

    n: string
        Maya's layer attribute descriptor

    p: function
        Call to make layer output.

    Return: layer or None
        material
    """
    # 'is_back' flag, 'm'
    m = False
    z = getattr(maya, n)

    if z:
        maya.remove_put(n)
        m = True

    z = p(maya)

    if z or m:
        Run.is_back = True
    return z


def _create_branch(maya):
    """
    Create a group layer for a Model branch.

    maya: Maya
        Needs a group layer in the correct position.

    Return: group layer
        newly created
    """
    j = Run.j
    step_k = get_model_branch_key(maya.any_group.name_step_k)
    parts = get_parts(step_k)

    parts.append(maya.layer_postfix)

    # Model group layer for plan or work view-type, 'parent'
    parent = maya.model.group_layer_list[Run.i]

    # If there isn't a Model group, then the caller is out-of-sync.
    if parent:
        # index to item in step-key, 'i'
        for i, item_k in enumerate(parts):
            # Find the sub-step's group layer.
            group = None
            n = item_k

            for z in parent.layers:
                if z.name.split(" ")[-1] == n:
                    group = z
                    break

            if not group:
                group = make_group_layer(j, None, 0, item_k)
                group.name = parent.name + " " + item_k

                # Create a group layer. 'i' is in the range of 0 to 2.
                CREATE_DISPATCH[i](j, parent, group, CREATE_ARG[i], item_k)
            parent = group
    return parent


def _insert_branch(j, parent, group, d, item_k):
    """
    Insert branch and leaf into a Model layer tree.

    parent: group layer

    d: dict or None
        {descriptor: ordinal}
    """
    # [item key, ...]
    q = []

    for z in parent.layers:
        n = z.name
        q.append(n.split(" ")[-1])

    # [position ordinal, ...]
    q1 = []

    for k in q:
        q1.append(d.get(k))

    ordinal = d.get(item_k)
    q1.append(ordinal)
    q1 = sorted(q1)

    # Is the offset from the top of parent, '_i'.
    i = q1.index(ordinal)

    pdb.gimp_image_reorder_item(j, group, parent, i)


def _sort_branch(j, parent, group, *_):
    """
    _: tuple
        (None, string -> group layer name segment)

    """
    """Sort Main and Per branches."""
    n = group.name
    i = 0
    is_below = True

    for i, _n1 in enumerate(parent.layers):
        if n > _n1.name:
            is_below = False
            break

    if is_below:
        # Insert the group below the last layer in parent.
        i += 1
    pdb.gimp_image_reorder_item(j, group, parent, i)


def add_base_layer(parent, n):
    """
    Add a layer at the bottom of a group layer.

    parent: group layer
        Is the parent of the new layer.

    n: string
        Name the layer with a suffix.

    Return: layer
        newly added
    """
    return add_layer(parent.image, parent, len(parent.layers), n)


def add_layer(j, parent, offset, n):
    """
    Add a layer to an image.

    j: GIMP image
        Receive layer.

    n: string
        Name the new layer.

    parent: layer or None
        group layer

    offset: int
        Is the position from top of the Layers trunk or the parent layer.
        Zero to 'n' where 'n' is the number of layers in the trunk or group.

    Return: layer
        newly inserted
    """
    if parent:
        n = parent.name + " " + n

    z = pdb.gimp_layer_new(
        j,
        j.width, j.height,
        RGBA_IMAGE,
        n,
        100.,                       # opacity
        LAYER_MODE_NORMAL
    )

    pdb.gimp_image_insert_layer(j, z, parent, offset)
    return z


def add_layer_above(z, n):
    """
    Insert a new empty layer above an existing layer.

    z: layer
        target of insertion

    n: string
        the new layer name

    Return: layer
        newly added
    """
    return add_layer(z.image, z.parent, get_layer_position(z), n)


def add_layer_below(z, n):
    """
    Insert a new empty layer below an existing layer.

    z: layer
        target of insertion

    n: string or None
        When true, the layer is named.

    Return: layer
        newly added
    """
    return add_layer(z.image, z.parent, get_layer_position(z) + 1, n)


def add_sub_maya_group(maya):
    """
    Add a group layer to the bottom of a Maya group layer.

    maya: Maya
    Return: group layer
        newly added
    """
    return make_group_layer(
        Run.j,
        maya.group,
        len(maya.group.layers),
        maya.any_group.dna.key + " WIP"
    )


def add_wip_above(z, n=""):
    """
    Insert a new empty WIP layer above an existing layer.

    z: layer
        Has position of insertion.

    n: string
        Name the layer.

    Return: layer
        newly added
    """
    return add_wip_layer(n, z.parent, offset=get_layer_position(z))


def add_wip_base(n, parent):
    """
    Insert a new empty WIP layer at the bottom of a group layer.

    n: string
        layer name suffix

    parent: group layer
        Is the parent of the inserted base layer.

    Return: layer
        newly added
    """
    return add_wip_layer(n, parent, offset=len(parent.layers))


def add_wip_below(z, n=""):
    """
    Insert a new empty WIP layer below an existing layer.

    z: layer
        Has position of insertion.

    n: string
        Name the layer.

    Return: layer
        newly added
    """
    return add_wip_layer(n, z.parent, offset=get_layer_position(z) + 1)


def add_wip_layer(n, parent, offset=0):
    """
    Make a WIP layer. Is not for the Layers
    trunk, but is for a group layer branch.

    n: string
        layer name suffix

    parent: group layer or None
        Is the parent of the new layer.

    offset: int
        Position the layer from the top of the group layer.

    Return: layer
        as requested
    """
    n = parent.name + " " + n if parent else n
    x, y, w, h = map(int, Wip.get_rect())
    z = pdb.gimp_layer_new(
        Run.j,
        w, h,
        RGBA_IMAGE,
        n,
        100.,                       # opacity
        LAYER_MODE_NORMAL
    )

    pdb.gimp_layer_set_offsets(z, x, y)
    pdb.gimp_image_insert_layer(Run.j, z, parent, offset)
    return z


def check_matter(maya):
    """
    Act on matter issue change.

    maya: Maya
    Return: layer or None
        material
    """
    if maya.is_matter:
        return _check_layer(maya, 'matter', maya.do_matter)
    return maya.matter


def clip_to_wip(z):
    """
    Transform a layer to a WIP sized layer.
    Crop the content to the WIP layer bounds.

    z: layer or None
        Crop its content to the Wip size.
    """
    if z:
        if Wip.x:
            select_rect(Run.j, *Wip.get_rect())
            clear_inverse_selection(z)

        x, y = z.offsets
        q = map(int, (Wip.w, Wip.h, x - Wip.x, y - Wip.y))
        pdb.gimp_layer_resize(z, *q)


def copy_below(z, n="BG Copy", is_hide=True, on_top=False):
    """
    Make a copy of the visible background material
    below a layer. Insert the copy below the layer
    unless flagged otherwise.

    z: layer
        Copy its background.

    n: string
        Name the clone layer.

    is_hide: bool
        If true, the top layer, 'z', is not part of the copy.

    on_top: bool
        If True, the copy layer is inserted above layer 'z'.

    Return: layer
        Is the copy of the background.
    """
    j = z.image
    z1 = get_background(z, n, is_hide=is_hide)
    i = 0 if on_top else 1

    pdb.gimp_image_insert_layer(j, z1, z.parent, get_layer_position(z) + i)
    clip_to_wip(z1)
    return z1


def create_image(w, h):
    """
    Create a temporary GIMP image that has its undo turned off.

    w, h: int
        Is the size of the new image.

    Return: GIMP image
        as requested
    """
    j = pdb.gimp_image_new(max(1, w), max(1, h), RGB)

    pdb.gimp_image_undo_disable(j)
    return j


def get_background(z, n, is_hide=True):
    """
    Get the visible background of a layer.

    z: layer
        Copy its background.

    n: string
        Name the copied background layer.

    is_hide: bool
        If False, the provided layer is visible in the copy.

    Return: layer
        the background copy
    """
    def _hide(_z):
        """
        _z: group layer or GIMP image
        """
        for _z1 in _z.layers:
            if _z1 not in branch_q:
                if _z1.visible:
                    hide_q.append(_z1)

            else:
                if hasattr(_z1, 'layers') and _z1 != z:
                    _z = _hide(_z1)
                break
        return _z

    j = z.image
    z1 = z

    # branch of layer parent to work-in-progress layer, 'branch_q'
    branch_q = [z]

    # hidden layer, 'hide_q'
    hide_q = [z] if is_hide else []

    # Get the outer-most parent of layer, 'z'.
    # Make a list of the parent groups for they may contain additional layers.
    while z1.parent:
        branch_q.append(z1.parent)

        # group layer, 'z1'
        z1 = z1.parent

    node_z = branch_q[-1]

    # Hide trunk.
    for i in j.layers:
        if i == node_z:
            break
        if i.visible:
            hide_q.append(i)

    # Hide branch.
    if len(branch_q) > 1:
        _hide(node_z)

    for i in hide_q:
        hide_layer(i)

    z1 = pdb.gimp_layer_new_from_visible(j, j, n)

    for i in hide_q:
        show_layer(i)
    return z1


def image_copy_all(j):
    """
    Copy a visible image while ensuring that it's the
    whole image by modifying the image's selection.

    j: GIMP image
        Copy visible pixel.

    Return: state of the clipboard
    """
    pdb.gimp_selection_all(j)
    pdb.gimp_edit_copy_visible(j)


def insert_copy(group, z, is_hide=False):
    """
    Insert a background copy layer into a group layer.

    group: layer
        Is the destination.

    z: layer
        Copy from its position.

    is_hide: bool
        If True, then the positional layer is
        hidden before making the background copy.

    Return: layer
        that was inserted
    """
    j = z.image
    z1 = get_background(z, "Background Copy", is_hide=is_hide)

    pdb.gimp_image_insert_layer(j, z1, group, 0)
    clip_to_wip(z1)
    return z1


def insert_copy_above(z, z1):
    """
    Insert a background copy layer above another layer.

    z: layer
        Insert the copy above this layer.

    z1: layer
        Copy from its position.

    Return: layer
        that was inserted
    """
    j = z.image
    z2 = get_background(z1, "Background Copy", is_hide=False)

    pdb.gimp_image_insert_layer(j, z2, z.parent, get_layer_position(z))
    clip_to_wip(z2)
    return z2


def make_cast_group(maya):
    """
    Make a group layer for a Cell/leaf.

    maya: Maya
    """
    if not maya.group:
        group = _create_branch(maya)
        maya.group = make_group_layer(Run.j, group, maya.get_light(), "Cast")
    return maya.group


def make_canvas_group(maya):
    """
    Make a group layer for a Canvas/leaf step.

    maya: Maya
    """
    if not maya.group:
        maya.group = _create_branch(maya)
    return maya.group


def make_group_filler(maya):
    """
    Make a Filler group layer. Is
    a sub-group of the super-maya's group layer.

    maya: Maya
    Return: group layer
        Filler parent
    """
    return make_group_sub(maya, maya.super_maya.kind + " Filler")


def make_group_layer(j, parent, offset, n, z=None):
    """
    Create a group layer.

    j: GIMP image
        Receive group.

    parent: layer or None
        Is the parent layer of the group.

    offset: int
        Is the offset from the top of the parent to insert the group.

    n: string
        Name the group.

    z: layer
        Move to the new group.

    Return: layer
        the group
    """
    group = pdb.gimp_layer_group_new(j)

    pdb.gimp_image_insert_layer(j, group, parent, offset)

    if z:
        # layer offset below the group layer, '0'
        pdb.gimp_image_reorder_item(j, z, group, 0)

    if parent:
        n = parent.name + " " + n

    group.name = n
    group.mode = LAYER_MODE_PASS_THROUGH
    return group


def make_group_overlay(maya):
    """
    Make an Overlay group layer. Is
    a sub-group of the super-maya's group layer.

    maya: Maya
    Return: group layer
        Overlay parent
    """
    return make_group_sub(maya, maya.super_maya.kind + " Overlay")


def make_group_sub(maya, n):
    """
    Make a group layer. Is a sub-group of the super-maya's group layer.

    maya: Maya
    n: string
        group name appendix

    Return: group layer
        parent for material
    """
    parent = maya.cast.group.parent
    group = maya.group

    if not group:
        return make_group_layer(Run.j, parent, 0, n)
    return group


def make_group_wrap(maya):
    """
    Make a Wrap group layer. Is a
    sub-group of the super maya's group layer.

    maya: Maya
    Return: group layer
        Wrap parent
    """
    return make_group_sub(maya, maya.super_maya.kind + " Wrap")


def make_plan_group(_):
    """
    Make a Plan group layer if there isn't one.

    _: maya
        not used

    Return: group layer
        for Plan
    """
    if not PlanZ.plan_group:
        PlanZ.plan_group = make_group_layer(Run.j, None, 0, "Plan")
    return PlanZ.plan_group


def paste_image():
    """
    Paste the content of the clipboard as a new image.

    Return: GIMP image
        Has undo turned off.
    """
    j = pdb.gimp_edit_paste_as_new_image()

    pdb.gimp_image_undo_disable(j)
    return j


def paste_layer(z, n=""):
    """
    Paste the content of the clipboard.

    z: layer
        Paste above this layer.

    n: string
        Name the pasted layer.

    Return: layer
        newly created
    """
    j = z.image

    # With a selection, GIMP pastes the buffer
    # material centered around the selection.
    pdb.gimp_selection_none(j)

    z1 = z
    is_group = pdb.gimp_item_is_group(z)

    if is_group:
        # GIMP throws an error if the target layer
        # of a paste operation is a group layer.
        z1 = add_layer_above(z, "Base")

    z = pdb.gimp_edit_paste(z1, 0)

    pdb.gimp_floating_sel_to_layer(z)

    if is_group:
        pdb.gimp_image_remove_layer(j, z1)

    if n:
        z.name = n
    return z


def paste_layer_into(j, z, n=""):
    """
    Paste the content of the buffer into a
    group layer or on top of another layer.

    j: Gimp Image
        WIP

    z: layer or group layer
        Paste above this layer or as first layer in this group layer.

    n: string
        Name the pasted layer.

    Return: layer
        newly created
    """
    base = new_z = None

    if z:
        if pdb.gimp_item_is_group(z):
            if z.layers:
                z1 = z.layers[0]
                if not pdb.gimp_item_is_group(z1):
                    # Found a layer to paste onto.
                    z = base = z1
        else:
            # Paste onto layer 'base'.
            base = z

    if not base:
        # Create a layer to paste onto.
        new_z = pdb.gimp_layer_new(
            j,
            j.width, j.height,
            RGBA_IMAGE,
            "Base",
            100.,                       # opacity
            LAYER_MODE_NORMAL
        )
        pdb.gimp_image_insert_layer(j, new_z, z, 0)
        z = new_z

    # With a selection, GIMP pastes the buffer
    # material centered around the selection.
    pdb.gimp_selection_none(j)

    z1 = pdb.gimp_edit_paste(z, 0)

    pdb.gimp_floating_sel_to_layer(z1)

    if new_z:
        pdb.gimp_image_remove_layer(j, new_z)

    if n:
        z1.name = n
    return z1


def shape_clipboard(w, h, callback=None):
    """
    Paste, Resize, copy, and close an image.
    Expect image in the clipboard.

    w: int
        width to shape

    h: int
        height to shape

    callback: function
        Call before the clipboard is returned.
        Enable manipulation of the shaped image.

    Return: clipboard
        Has image copy.
    """
    j = paste_image()
    z = j.layers[0]

    # The last option is to scale around the center, '1'.
    pdb.gimp_layer_scale(z, max(1, w), max(1, h), 1)

    pdb.gimp_image_resize_to_layers(j)

    if callback:
        callback(j)

    # Set the selection to the entire image before copying.
    image_copy_all(j)

    # Clean-up.
    pdb.gimp_image_delete(j)


# {group layer depth: position group layer function}
CREATE_DISPATCH = {0: _insert_branch, 1: _insert_branch, 2: _sort_branch}
