#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant import MAX_SIZE, Define as df, Issue as vo
from roller_constant_identity import Identity as de
from roller_tooltip_text import Tip
from roller_widget_number_pair import RectPair

# Define Rectangle Preset.
RECTANGLE = OrderedDict([
    (de.POSITION_X, {
        df.AXIS: 'x',
        df.ISSUE: vo.MATTER,
        df.LIMIT: (-MAX_SIZE, MAX_SIZE),
        df.VALUE: 0.,
        df.WIDGET: RectPair
    }),
    (de.POSITION_Y, {
        df.AXIS: 'y',
        df.ISSUE: vo.MATTER,
        df.LIMIT: (-MAX_SIZE, MAX_SIZE),
        df.VALUE: 0.,
        df.WIDGET: RectPair
    }),
    (de.CELL_W, {
        df.AXIS: 'x',
        df.ISSUE: vo.MATTER,
        df.LIMIT: (0, MAX_SIZE),
        df.TIPS: (Tip.END_X,),
        df.VALUE: (.0, 1.),
        df.WIDGET: RectPair
    }),
    (de.CELL_H, {
        df.AXIS: 'y',
        df.ISSUE: vo.MATTER,
        df.LIMIT: (0, MAX_SIZE),
        df.TIPS: (Tip.END_Y,),
        df.VALUE: (.0, 1.),
        df.WIDGET: RectPair
    })
])
