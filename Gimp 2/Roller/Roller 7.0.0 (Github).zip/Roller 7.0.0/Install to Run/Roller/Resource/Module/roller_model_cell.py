#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_identity import Identity as de
from roller_model_cell_branch import CellBranch
from roller_model_goo import Goo
from roller_polygon import ROUTE_POG, ROUTE_SHAPE


class Cell(CellBranch):
    """Is a single cell Model."""
    model_type = de.CELL

    def __init__(self, model_name):
        """
        model_name: string
            Identify the model.
        """
        CellBranch.__init__(self, model_name)
        self.grid = 1, 1
        self.cell_q = [(0, 0)]
        self.goo_d = {(0, 0): Goo((0, 0))}

    def calc_grid(self, *_):
        """The model's grid doesn't change."""
        return

    def init_cell_q(self, d):
        """
        Cell's list of cell index doesn't change.

        d: dict
            Cell/Type dict
        """
        return

    def init_model_cell(self, d):
        """
        Begin setting the 'cell', 'merged', 'form',
        and 'plaque' value in the Goo.

        d: dict
            Cell/Type Preset
            {Identity: value}

        Return: dict
            {cell key: [Plan vote, Work vote]}
            Each vote is a vote for change.
        """
        a = self.goo_d[(0, 0)] = Goo((0, 0))
        a.cell.rect = a.merged.rect = self.rectangle

        if self.route_i == 0:
            a.form = ROUTE_SHAPE[self.cell_shape](a.cell)

        else:
            a.form = ROUTE_POG[self.cell_shape](
                a.cell, d[de.PARALLELOGRAM_SCALE]
            )
        return {(0, 0): self.past.did_rectangle(self.rectangle)}
