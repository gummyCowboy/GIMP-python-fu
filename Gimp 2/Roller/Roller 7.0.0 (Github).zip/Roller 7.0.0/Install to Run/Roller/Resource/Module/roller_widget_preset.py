#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_oz import make_preset_path, json_load
from roller_constant import Define as df
from roller_constant_identity import Identity as de
from roller_def_access import get_default_d
from roller_port_preset import PortPreset
from roller_port_save import PortSave
from roller_widget_button import ManagePresetButton, SaveButton
from roller_widget_row import WidgetRow
import os

"""
A Preset dict has the following structure:

OrderedDict:
    {Identity or RowKey: Widget value}
"""


class Preset(WidgetRow):
    """Manage option group Widget value from a WidgetRow."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Preset WidgetRow.
        """
        self.preset_key = d[df.DNA].key

        d.update(
            {df.SUB: OrderedDict([
                (de.MANAGE, {
                    df.DIALOG: PortPreset,
                    df.WIDGET: ManagePresetButton
                }),
                (de.SAVE, {
                    df.DIALOG: PortSave,
                    df.WIDGET: SaveButton
                })
            ])}
        )
        WidgetRow.__init__(self, **d)

    def get_a(self):
        """
        Retrieve the AnyGroup value dict. Most likely this function is called
        when saving a Preset. It's required because SuperPreset has to
        collect its return value.
        """
        return self.any_group.get_value_d()

    def load_file(self, n, preset_key):
        """
        Load a Preset dict.

        n: string
            user name of Preset

        preset_key: string
            integral to path

        Return: dict
            the loaded Preset
        """
        file_path = make_preset_path(preset_key, n)

        if os.path.isfile(file_path):
            # Preset dict, 'd'
            d = json_load(file_path)

        else:
            # If the Preset is a SuperPreset, then it's an empty dict, 'd'.
            d = get_default_d(preset_key)

        self.set_ui(d)
        return d

    def set_ui(self, d):
        self.any_group.load_widget_d(d)
