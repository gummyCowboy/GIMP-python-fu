#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Issue as vo, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_maya import Maya
from roller_preset import get_option_list_choice
from roller_preset_lookup import CLASS_FRAME


class Frame(Maya):
    """
    Manage change in the Frame/OptionList frame-type by creating
    and removing frame-type Maya. Monitor the Frame/Switch state
    and incorporate into frame-type Maya's life-cycle management.
    """
    issue_q = 'switch',

    def __init__(self, any_group, super_maya, path_prefix):
        """
        any_group: AnyGroup
        super_maya: Maya
        path_prefix: tuple
            (Identity, ...)
            Is the key-path to this Maya's Preset.

        lookup_d:
            {Accent key or Frame key: its output producing Maya class}
        """
        self._maya_type = None
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self._path_prefix = path_prefix
        Maya.__init__(self, any_group, 1, (), vo.NO_VOTE)

    def do(self, value_d, is_change):
        """
        Manage layer output during a view run.

        value_d: dict
            OptionList Preset

        is_change: bool
            Is the state of change of the super-maya's matter and mask.
        """
        def _die():
            _link = self.sub_maya.get(sm.LINK)
            if _link:
                _link.die()
                self.sub_maya.pop(sm.LINK)
            self._maya_type = None

        # sub-Frame Preset key, 'k'; sub-Frame Preset value dict, 'd'
        k, d = get_option_list_choice(value_d)

        maya_type = CLASS_FRAME.get(k)

        if sm.LINK in self.sub_maya and maya_type != self._maya_type:
            # The Maya type changed. Remove the old output.
            _die()

        if maya_type:
            self.go = value_d[de.SWITCH]
            self.go &= bool(self.super_maya.matter)

            if self.go:
                if sm.LINK not in self.sub_maya:
                    self.sub_maya[sm.LINK] = maya_type(
                        self.any_group, self, self._path_prefix
                    )
                self.sub_maya[sm.LINK].do(d, is_change)
            else:
                _die()
        self._maya_type = maya_type
