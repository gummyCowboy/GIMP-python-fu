#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_container import The
from roller_constant import (
    Define as df, Issue as vo, Signal as si, VoteType as vt
)
from roller_constant_identity import Identity as de
from roller_def_access import get_vote_d
from roller_port_per import (
    PortPerCell, PortPerFace, PortPerFacing, PortPerMerge
)
from roller_preset import get_option_list_key
from roller_tooltip_text import Tip
from roller_widget import set_widget_attr
from roller_widget_button import ProcessButton
from roller_widget_check_button import CheckButton
from roller_widget_voter import accept_vote
import gobject  # type: ignore
import gtk      # type: ignore


def compare_views(g):
    """
    Compare both the Plan and view values.

    g: PerGroup
        with value table
    """
    # Do Work and Plan, '2'.
    for i in range(2):
        g.compare_value(i)


def compare_preset(g, new_d, i):
    """
    Compare the Preset with its viewed version.

    g: PerGroup
    new_d: dict
        Is the incoming value.

    i: int
        plan or work; view-type index; 0 or 1
    """
    old_d = g.any_group.get_view_a(i, de.PER)

    if old_d is None:
        old_d = {}

    is_change = new_d != old_d

    # (row, column) or (row, column, face), 'k'; Preset value dict, 'd'
    for k, d in new_d.items():
        vote_d = {}

        reap_vote(vote_d, g.default_ballot_d, old_d.get(k, {}), d)
        g.emit(si.PER_CHANGE, (k, vote_d, i))
    return is_change


def compare_type(g, new_d, i):
    """
    Compare the Table/Cell/Type value with its view value.

    g: PerGroup
        Has viewed value.

    new_d: dict
        incoming value

    i: int
        index to plan or work view-type
    """
    old_d = g.any_group.get_view_a(i, de.PER)

    if old_d is None:
        old_d = {}

    is_change = old_d != new_d

    for k, a in new_d.items():
        m = a != old_d.get(k)
        g.emit(si.PER_CHANGE, (k, m, i))
    return is_change


def reap_vote(vote_d, ballot_d, old_d, new_d):
    """
    Compare two Preset values. Have each option cast a vote in a
    vote dict. The option's vote is True if the option has changed.

    vote_d: dict
        Collect vote on issue.

    ballot_d: dict
        {Identity: votes}

    old_d: dict
        old value

    new_d: dict
        new value

    Return: dict
        with vote
    """
    if old_d:
        # Identity, 'k'; issue, 'a'
        for i, a in ballot_d.items():
            if i == de.FRAME:
                if i not in vote_d:
                    vote_d[i] = {}

                new_frame_d = new_d[i]
                old_frame_d = old_d[i]
                new_option_list_d = new_frame_d[de.OPTION_LIST]
                old_option_list_d = old_frame_d[de.OPTION_LIST]
                k = get_option_list_key(new_option_list_d)
                k1 = get_option_list_key(old_option_list_d)
                sub_ballot_d = get_vote_d(k)

                accept_vote(
                    vote_d[i],
                    i,
                    a[de.SWITCH],
                    new_frame_d[de.SWITCH] != old_frame_d[de.SWITCH]
                )
                if k == k1:
                    # The two Presets are comparable.
                    reap_vote(
                        vote_d[i],
                        sub_ballot_d,
                        old_option_list_d[k],
                        new_option_list_d[k]
                    )
                else:
                    # The two Presets are not comparable.
                    # Cast default vote.
                    reap_ballot(vote_d, sub_ballot_d, new_option_list_d[k])

            elif isinstance(a, dict):
                if i not in vote_d:
                    vote_d[i] = {}
                reap_vote(vote_d[i], a, old_d[i], new_d[i])
            elif old_d[i] != new_d[i]:
                accept_vote(vote_d, i, a, True)
    else:
        reap_ballot(vote_d, ballot_d, new_d)


def reap_ballot(vote_d, ballot_d, new_d):
    """
    Collect change vote with a default ballot dict.

    vote_d: dict
        Collect vote on issue.

    ballot_d: dict
        Is the default vote for a Preset.
    """
    for i, a in ballot_d.items():
        if i == de.FRAME:
            if i not in vote_d:
                vote_d[i] = {}

            # Frame/Switch issue
            accept_vote(vote_d[i], de.SWITCH, a[de.SWITCH], True)

            # i.e. {"Basic": Basic Preset}, 'option_list_d'
            option_list_d = new_d[i][de.OPTION_LIST]

            k = get_option_list_key(option_list_d)
            sub_ballot_d = get_vote_d(k)
            reap_ballot(vote_d[i], sub_ballot_d, option_list_d[k])

        elif isinstance(a, dict):
            if i not in vote_d:
                vote_d[i] = {}
            reap_ballot(vote_d[i], a, new_d[i])
        else:
            accept_vote(vote_d, i, a, True)


def update_button_visual(g):
    """
    Update the Open Button's visibility.

    g: PerGroup
        Has button.
    """
    if g.check_button.get_ui():
        g.button.show()
    else:
        g.button.hide()


class PerGroup(gtk.Alignment, gobject.GObject, object):
    """Has a Per CheckButton and an Open Button."""
    __gsignals__ = si.PER_DICT
    change_signal = None
    has_table_label = False

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument for Widget.
        """
        super(gtk.Alignment, self).__init__()
        gobject.GObject.__init__(self)

        # the GTK Alignment setting
        self.set(0, 0, 1, 1)

        self._cancel_value = {}

        # {per key: Preset dict}
        self._value = {}

        set_widget_attr(self, d)

    def hide(self, *_):
        """
        Hide the row in the Table container if the Widget is ready.
        Table sets the 'self.box' to a VBox container.
        """
        # There's a timing issue 'box' during init.
        if hasattr(self, 'box') and self.box:
            self.box.hide()
            self.label_box.hide()

    def show(self, *_):
        """
        Show the row in the Table Widget if the Widget is ready.
        The Table Widget class has set the 'self.box' to a VBox container.
        """
        # There's a timing issue 'box' during init.
        if hasattr(self, 'box') and self.box:
            self.box.show()
            self.label_box.show()


class WithWidget(PerGroup):
    """Create PerGroup Widget."""

    def __init__(self, **d):
        PerGroup.__init__(self, **d)

        # Is true when PortPerTable is open.
        self.is_edit_mode = False

        self._hbox = gtk.HBox()
        relay = d[df.RELAY][:]
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

        # CheckButton
        # The CheckButton and Button don't cast vote.
        d.pop(df.ISSUE)
        d[df.RELAY].insert(0, self.on_per_switch)
        d[df.NO_VOTE] = True
        d[df.TOOLTIP] = Tip.PER_CHECK_BUTTON
        d[df.ALIGN] = 0, 0, 0, 1
        self.check_button = CheckButton(**d)

        # Button
        d[df.TOOLTIP] = Tip.PER_BUTTON
        d[df.KEY] = d[df.TEXT] = de.OPEN
        d[df.ALIGN] = 0, 0, 1, 0
        d[df.RELAY] = relay

        relay.insert(0, self.on_open_button_action)

        self.button = self.widget = ProcessButton(**d)

        self.add(self._hbox)
        for i in (self.check_button, self.button):
            self._hbox.add(i)
            same_size.add_widget(i.widget)

    def check_for_lost(self, q):
        """
        Check Per keys for validity with Cell/Type,
        Cell/Shift, or Cell/Margin change.

        q: list
            [(cell key, ...)]
            Are valid keys.
        """
        lost_q = []
        is_change = False

        for k in self._value.keys():
            if k not in q:
                lost_q.append(k)
                self._value.pop(k)
            else:
                # The Per Maya changed.
                is_change = True

        if is_change:
            # Set the view value to trigger change.
            compare_views(self)
        if lost_q:
            self.emit(si.DISAPPEAR, lost_q)

    def get_a(self):
        """
        Fetch the group value from its AnyGroup.

        Return: dict
            {row-column tuple: Preset value dict} or
            {row-column-facial tuple: Preset value dict}
        """
        a = self._value

        if a is None:
            a = {}
        return a

    def get_ui(self):
        """
        Return: dict
            {row-column string: Preset value dict} or
            {row-column-facial string: Preset value dict}
        """
        return self._value

    def intersect_vote(self, vote_d):
        """
        Receive a vote dict and send a change Signal.

        vote_d: dict
            {goo or map key: [Plan vote, Work vote]}
        """
        self.check_for_lost(self.any_group.dna.model.cell_q)

        group_vote_q = set()
        q = self._value.keys()

        # Plan and Work vote list, 'a'
        for k, a in vote_d.items():
            if k in q:
                # Plan and Work, '2'
                for i in range(2):
                    d = {vt.IS_CHAIN: a[i]}

                    self.emit(
                        si.PER_CHANGE,
                        (k, {vo.MATTER: d, vo.MODE: d, vo.OPACITY: d}, i)
                    )
                    group_vote_q.update((i,))
        for i in group_vote_q:
            self.any_group.cast_vote(i, de.PER, vo.PER, True)

    def load_a(self, d):
        """
        d: dict
        """
        d = self.set_ui(d)
        self.any_group.set_widget_a(de.PER, d)

    def on_accept_cell_edit(self, d):
        """
        Return from PortPer. Exit edit mode.

        d: dict
            Is the new value for the PerGroup.
        """
        self.set_ui(d)
        self.is_edit_mode = False

        # Free the memory.
        self._cancel_value = None

        if self.button.get_sensitive():
            self.button.widget.grab_focus()
        else:
            self.check_button.widget.grab_focus()

    def on_cancel_cell_edit(self):
        """
        Return from PortPer. Exit from edit
        mode. Restore the original value.
        """
        self.set_ui(self._cancel_value)
        self.is_edit_mode = False

    def on_open_button_action(self, _):
        """
        Respond to an Open Button action.

        _: Button
            Is responsible.
        """
        # Restore the original value on cancel.
        self._cancel_value = deepcopy(self._value)

        # Is True when the cell editor is open.
        self.is_edit_mode = True

        self.roller_win.bring_dialog(
            self,
            d={
                df.ON_ACCEPT: self.on_accept_cell_edit,
                df.ON_CANCEL: self.on_cancel_cell_edit,
            }
        )

    def on_per_switch(self, g):
        """
        Respond to a change event for the Per CheckButton.

        g: CheckButton
            Is responsible.
        """
        if not g.get_ui():
            self.set_ui({})

        # Plan and Work indices, '2'
        for i in range(2):
            a = self.any_group.get_view_a(i, de.PER)
            self.any_group.cast_vote(i, de.PER, vo.PER, self._value != a)
        update_button_visual(self)

    def set_ui(self, d):
        """
        d: dict or None
            {row-column string: Preset value dict}

        Return: dict
            {PerGroup type-key string: Preset value dict}
        """
        d = self._value = d if isinstance(d, dict) else {}

        compare_views(self)
        self.check_button.widget.set_active(bool(d))
        self.any_group.set_widget_a(de.PER, d)
        return d


class Cellular(WithWidget):
    """Factor from Cell and Face PerGroup."""

    def __init__(self, **d):
        WithWidget.__init__(self, **d)
        self.default_ballot_d = get_vote_d(self.any_group.dna.key)

    def compare_value(self, i):
        """
        Compare 'self._value' with its view value.
        Route Table/Cell/Type differently.

        i: int
            index to plan or work view-type attribute
        """
        d = self.get_ui()
        is_change = compare_preset(self, d, i)

        # The Per Widget changed.
        self.any_group.cast_vote(i, de.PER, vo.PER, is_change)

        a = self.any_group.get_view_a(i, de.PER)

        if a is None:
            a = {}

        self.any_group.cast_vote(
            i, vt.IS_MAIN, vo.MATTER, d.keys() != a.keys()
        )

    def set_ui(self, d):
        """
        Set the PerGroup value. The key-type is a string.

        d: dict
            {row-column string: Preset value dict}
            The row and column cell index range from 0
            to the span of the Model's table.

        Return: dict
        """
        lost_q = []
        last_value = deepcopy(self._value)

        d = super(Cellular, self).set_ui(d)

        for k in last_value:
            if k not in self._value:
                lost_q.append(k)

        if lost_q:
            self.emit(si.DISAPPEAR, lost_q)
        return d


class PerGroupCell(Cellular):
    """Manage Cell PerGroup."""

    def __init__(self, **d):
        self.dialog = PortPerCell
        Cellular.__init__(self, **d)


class PerGroupEmpty(PerGroup):
    """Is basically a dummy PerGroup."""

    def __init__(self, **d):
        PerGroup.__init__(self, **d)

    @staticmethod
    def get_ui():
        """
        There is no 'self._value'.

        Return: dict
            empty
        """
        return {}

    def intersect_vote(self, vote_d):
        return

    def load_a(self, *_, **d):
        """Set the PerGroup value."""
        self.any_group.set_widget_a(de.PER, {})

    def set_ui(self, *_, **d):
        """Set the PerGroup value."""
        return {}


class PerGroupFace(Cellular):
    """
    Manage Face PerGroup. It's value dict key is a Map key,
    (row, column, face), where each tuple item is a zero-based index.
    """

    def __init__(self, **d):
        self.dialog = PortPerFace
        Cellular.__init__(self, **d)

    def intersect_vote(self, vote_d):
        """
        Receive a vote dict and send a change Signal.

        vote_d: dict
            {cell index-type key: [Plan vote, Work vote]}
        """
        self.check_for_lost(self.any_group.dna.model.face_q)

        group_vote_q = set()
        q = self._value.keys()

        # zero-based (row, column) index, 'k'
        # Plan and Work vote list, 'a'
        for k, a in vote_d.items():
            # Each Face in the cell has change.
            for face_i in range(3):
                k1 = k + (face_i,)
                if k1 in q:
                    # Plan and Work, '2'
                    for i in range(2):
                        d = {vt.IS_CHAIN: a[i]}

                        self.emit(
                            si.PER_CHANGE,
                            (k1, {vo.MATTER: d, vo.MODE: d, vo.OPACITY: d}, i)
                        )
                        group_vote_q.update((i,))
        for i in group_vote_q:
            self.any_group.cast_vote(i, de.PER, vo.PER, True)

    def load_a(self, d):
        """
        d: dict
            {sub-PerGroup key string: Preset dict}
        """
        d = self.set_ui(d)
        self.any_group.set_widget_a(de.PER, d)

    def set_ui(self, d):
        """
        Set the PerGroup value. The key-type is a string.

        d: dict
            {row-column-face string: Preset value dict}

        Return: dict
            {row-column-face string: Preset value dict}
        """
        return super(PerGroupFace, self).set_ui(d)


class PerGroupFacing(PerGroupFace):
    """
    Manage Face PerGroup. It's value dict key is
    (row, column, 0), where each tuple item is a zero-based index.
    The zero in the key is deviant from the Cell branch because
    some Model dict are shared by both the Cell and Facing branches.
    """

    def __init__(self, **d):
        Cellular.__init__(self, **d)
        self.dialog = PortPerFacing

    def intersect_vote(self, vote_d):
        """
        Receive a vote dict and send a change Signal.

        vote_d: dict
            {cell index-type key: [Plan vote, Work vote]}
        """
        group_vote_q = set()
        q = self._value.keys()

        # zero-based (row, column) index, 'k'
        # Plan and Work vote list, 'a'
        for k, a in vote_d.items():
            # Add Facing index.
            k = k + (0,)
            if k in q:
                # Plan and Work, '2'
                for i in range(2):
                    d = {vt.IS_CHAIN: a[i]}

                    self.emit(
                        si.PER_CHANGE,
                        (k, {vo.MATTER: d, vo.MODE: d, vo.OPACITY: d}, i)
                    )
                    group_vote_q.update((i,))
        for i in group_vote_q:
            self.any_group.cast_vote(i, de.PER, vo.PER, True)


class PerGroupMerge(WithWidget):
    """Table/Cell/Type's PerGroup for its merge option."""

    def __init__(self, **d):
        self.dialog = PortPerMerge
        WithWidget.__init__(self, **d)

    def compare_value(self, i):
        """
        Compare a value table with a Preview table.
        Route Table/Cell/Type differently.

        i: int
            index to plan or work view-type attribute
        """
        d = self.get_ui()
        is_change = compare_type(self, d, i)

        # Preset change
        self.any_group.cast_vote(i, de.PER, vo.PER, is_change)

        a = self.any_group.get_view_a(i, de.PER)

        if a is None:
            a = {}
        self.any_group.cast_vote(
            i, vt.IS_MAIN, vo.MATTER, d.keys() != a.keys()
        )

    def on_accept_cell_edit(self, d):
        """
        Return from PortPer. Exit from edit mode.

        d: dict
            the new value for the PerGroup
        """
        super(PerGroupMerge, self).on_accept_cell_edit(d)

        # When the Table/Cell/Type change,
        # the pocket and merge rect need update.
        self.any_group.dna.model.baby.give(
            si.CELL_RECT_CHANGE, (self.any_group.get_value_d(), False)
        )

    def on_cancel_cell_edit(self):
        """
        Return from PortPer. Exit from edit
        mode. Restore the 'cancel_value' table.
        """
        super(PerGroupMerge, self).on_cancel_cell_edit()

        # Merge cell may have been altered.
        self.any_group.dna.model.baby.give(
            si.CELL_RECT_CHANGE, (self.any_group.get_value_d(), False)
        )

    def on_per_switch(self, g):
        """
        Respond to a Per CheckButton changed event.

        g: CheckButton
            Is responsible.
        """
        if not The.load_count:
            for r_c in self.any_group.dna.model.cell_q:
                self._value[r_c] = 1, 1
        super(PerGroupMerge, self).on_per_switch(g)


# Register custom Signal.
gobject.type_register(PerGroup)
