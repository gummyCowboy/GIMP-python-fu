#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_SUBTRACT, pdb      # type: ignore
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_image import add_sub_maya_group, add_wip_above, add_wip_layer
from roller_gimp_layer import color_selection_default
from roller_gimp_mode import get_mode
from roller_gimp_selection import select_polygon
from roller_maya_sub_accent import SubAccent
from roller_wip import Wip


def do_matter(maya):
    """
    Make a matter layer for CoreDesign.

    maya: CoreDesign
    Return: layer
        'matter'
    """
    j = Run.j
    d = maya.value_d
    left, top, width, height = Wip.get_rect()
    center_x, center_y = Wip.center()
    group = add_sub_maya_group(maya)
    z = add_wip_layer("Polygon 1", group)
    z1 = add_wip_above(z, "Overlay")
    z2 = add_wip_above(z, "Polygon")
    z1.mode = get_mode(d, de.OVERLAY)

    pdb.gimp_selection_none(j)

    right = width + left
    bottom = height + top
    is_vertical = not d[de.HORIZONTAL]

    if is_vertical:
        y = top + height / 4
        y1 = top + height * 3 / 4
        polygon = left, y, right, y, center_x, bottom     # down
        polygon1 = left, y1, right, y1, center_x, top     # up

    else:
        x = left + width / 4
        x1 = left + width * 3 / 4
        polygon = x, top, x, bottom, right, center_y  # right
        polygon1 = x1, top, x1, bottom, left, center_y  # left

    select_polygon(j, polygon)
    select_polygon(j, polygon1, option=CHANNEL_OP_SUBTRACT)
    color_selection_default(z2, d[de.COLOR_2A][1])
    select_polygon(j, polygon1)
    color_selection_default(z, d[de.COLOR_2A][0])
    select_polygon(j, polygon)
    pdb.gimp_image_select_item(j, CHANNEL_OP_SUBTRACT, z2)
    color_selection_default(z1, d[de.COLOR_2A][1])
    return maya.finish(pdb.gimp_image_merge_layer_group(j, group), d[rk.BRW])


class CoreDesign(SubAccent):
    kind = de.CORE_DESIGN

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, False, is_old)
