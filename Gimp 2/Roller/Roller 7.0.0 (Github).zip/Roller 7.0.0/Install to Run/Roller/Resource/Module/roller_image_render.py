#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import RGB, pdb  # type: ignore
from roller_container import Globe, PlanZ, Run
from roller_constant import Signal as si
from roller_ice import freeze, thaw
import gobject       # type: ignore


def create_render(w, h):
    """
    Create a render image. Only call during a View run.

    w, h: numeric
        new image size
    """
    if Run.j:
        PlanZ.plan_group = None

        # The view image is the wrong size.
        Render.gob.emit(si.CLOSE_VIEW_IMAGE, Run.j)

        thaw()
        pdb.gimp_display_delete(Render._display)

    Run.j = pdb.gimp_image_new(int(w), int(h), RGB)

    # Show in GIMP:
    Render._display = pdb.gimp_display_new(Run.j)

    freeze()

    # Turn off undo functionality to save
    # memory and to improve performance.
    pdb.gimp_image_undo_disable(Run.j)


class Render(gobject.GObject, object):
    """Use to create and change the render image."""
    __gsignals__ = si.IMAGE_DICT
    _display = None

    # for Signal processing
    gob = None

    def __init__(self):
        """Init for a new view image."""
        gobject.GObject.__init__(self)
        Render.gob = self

    @staticmethod
    def provide():
        """
        Get the view's output image. If it doesn't exist, then create it.

        Return: GIMP image
            Is from a view run or is a new image.
        """
        if not Run.j:
            create_render(*Globe.view_size)
        return Run.j


if not Render.gob:
    Render()

# Register custom signal.
gobject.type_register(Render)
