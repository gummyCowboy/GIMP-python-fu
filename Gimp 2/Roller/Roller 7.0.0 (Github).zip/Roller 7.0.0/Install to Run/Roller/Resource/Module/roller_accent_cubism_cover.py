#!/usr/bin/env python
# -*- coding: utf-8 -
from gimpfu import CLIP_TO_IMAGE, LAYER_MODE_SOFTLIGHT, pdb      # type: ignore
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gegl import cubism, edge
from roller_gimp_image import make_group_layer
from roller_gimp_layer import clone_layer
from roller_maya_sub_accent import SubAccent


def do_matter(maya):
    """
    Make a matter layer.

    maya: CubismCover
    Return: layer
        Cubism Cover material
    """
    j = Run.j
    d = maya.value_d
    z = maya.bg_z
    maya.bg_z = None
    parent = make_group_layer(
        j, maya.group, maya.get_light(), "Condenser", z=z
    )

    cubism(z, size=d[de.TILE_SIZE], amount=5., seed=int(Globe.seed))

    z1 = clone_layer(z, n="Soft light")
    z1.mode = z.mode = LAYER_MODE_SOFTLIGHT

    edge(z1)
    pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
    pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class CubismCover(SubAccent):
    """Create Accent output."""
    kind = de.CUBISM_COVER

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
