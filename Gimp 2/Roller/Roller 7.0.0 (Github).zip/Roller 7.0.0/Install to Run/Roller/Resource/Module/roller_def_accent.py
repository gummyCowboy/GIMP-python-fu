#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import Define as df, Issue as vo, Row as rk
from roller_constant_identity import Identity as de
from roller_def_dialog import ARW, BLUR_DIALOG, GMR, MAR, MOD, P2R, P3R, SHADOW
from roller_def_option import (
    AMPLITUDE_1,
    ANGLE,
    BLEND,
    BLOCK_H,
    BLOCK_W,
    CELL_SIZE_ETCH,
    CLIPBOARD,
    CLOCKWISE,
    COLOR_1,
    COLOR_1A,
    COLOR_2,
    COLOR_2A,
    COLOR_3,
    COLOR_3A,
    COLOR_6A,
    COLOR_COUNT,
    COLOR_GRID_TYPE,
    CRITERION,
    FILL_MODE,
    FILLED,
    GRADIENT,
    GRADIENT_ANGLE,
    GRADIENT_DIRECTION,
    GRADIENT_TYPE,
    HEIGHT_CUBE,
    HORIZONTAL,
    ITERATIONS,
    KEEP,
    LAYER_COUNT,
    MATTER_MODE,
    MAZE,
    MEAN_COLOR,
    MODE,
    NAME_DROP,
    NOISE_AMOUNT,
    OFFSET,
    OPACITY,
    PATTERN,
    PATTERN_SIZE,
    POWER,
    R_C,
    RANDOM_ORDER,
    REVERB,
    REVERB_TYPE,
    REVERSE,
    SEED,
    SHAPE,
    SHIFT,
    SHIFT_DIRECTION,
    SKETCH_TEXTURE,
    SLICE_COUNT,
    SPIRAL_DISTANCE,
    SPIRAL_MOD,
    SPREAD,
    STEPS_DROP,
    STYLE_TYPE,
    SUPERPIXEL_SIZE,
    ENGRAVE,
    THRESHOLD,
    TILE_SIZE,
    WAVE_COUNT,
    WAVE_FILL_TYPE,
    WAVE_PER_LAYER
)
from roller_widget_row import WidgetRow

"""Define the Accent Preset and its option list."""

CUBE_D = {df.COLOR_NAME_LIST: ("Cap", "Left-side", "Right-side")}
ACRYLIC_SKY = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.SHIFT, deepcopy(SHIFT)),
    (de.SUPERPIXEL_SIZE, deepcopy(SUPERPIXEL_SIZE)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.SHIFT_DIRECTION, deepcopy(SHIFT_DIRECTION)),
    (rk.BRW, deepcopy(MAR))
])

# Back Game____________________________________________________________________
BACK_GAME = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.TRIANGLE, deepcopy(R_C)),
    (de.HORIZONTAL, deepcopy(HORIZONTAL)),
    (de.MEAN_COLOR, deepcopy(MEAN_COLOR)),
    (de.COLOR_2A, deepcopy(COLOR_2A)),
    (rk.BRW, deepcopy(MAR))
])
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Clay Chemistry_______________________________________________________________
CLAY_CHEMISTRY = OrderedDict([
    (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (de.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (rk.RW1, deepcopy(GMR)),
    (rk.BRW, deepcopy(ARW))
])

CLAY_CHEMISTRY[de.GRADIENT_OPACITY].update({
    df.ISSUE: vo.MATTER, df.VALUE: 50.
})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

COLOR_FILL = OrderedDict([
    (de.CRITERION, deepcopy(CRITERION)),
    (de.FILL_MODE, deepcopy(FILL_MODE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.THRESHOLD, deepcopy(THRESHOLD)),
    (de.COLOR_1A, deepcopy(COLOR_1A)),
    (rk.BRW, deepcopy(MAR))
])

# Color Grid___________________________________________________________________
COLOR_GRID = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.ROW, deepcopy(R_C)),
    (de.COLUMN, deepcopy(R_C)),
    (de.ANGLE, deepcopy(ANGLE)),
    (de.MEAN_COLOR, deepcopy(MEAN_COLOR)),
    (de.COLOR_2A, deepcopy(COLOR_2A)),
    (rk.BRW, deepcopy(MAR))
])

COLOR_GRID[de.COLOR_2A].update(
    {df.COLOR_NAME_LIST: (" First Cell", " Second Cell")}
)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

CRYSTAL_CAVE = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (rk.BRW, deepcopy(MAR))
])

# Cube Pattern_________________________________________________________________
CUBE_PATTERN = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.HEIGHT, deepcopy(HEIGHT_CUBE)),
    (de.ANGLE, deepcopy(ANGLE)),
    (de.COLOR_3A, deepcopy(COLOR_3A)),
    (rk.BRW, deepcopy(MAR))
])

CUBE_PATTERN[de.COLOR_3A].update(deepcopy(CUBE_D))
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

CUBISM_COVER = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.TILE_SIZE, deepcopy(TILE_SIZE)),
    (rk.BRW, deepcopy(MAR))
])

# Corner Overlap_______________________________________________________________
CORNER_OVERLAP = OrderedDict([
    (de.TYPE, deepcopy(STYLE_TYPE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.CLOCKWISE, deepcopy(CLOCKWISE)),
    (de.FILLED, deepcopy(FILLED)),
    (de.COLOR_2, deepcopy(COLOR_2)),
    (rk.BRW, deepcopy(MAR))
])
CORNER_OVERLAP[de.FILLED][df.VALUE] = 1

CORNER_OVERLAP[de.COLOR_2].update({
    df.COLOR_NAME_LIST: ("Left & Right", "Top & Bottom"),
    df.VALUE: ((255, 255, 255), (0, 0, 0))
})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Dark Fort____________________________________________________________________
DARK_FORT = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.ROW, deepcopy(R_C)),
    (de.COLUMN, deepcopy(R_C)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (rk.BRW, deepcopy(MAR))
])

for i in (de.ROW, de.COLUMN):
    DARK_FORT[i][df.RANDOM_Q] = 4, 16
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Density Gradient__________________________________________________________
DENSITY_GRADIENT = OrderedDict([
    (de.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (de.GRADIENT_MODE, deepcopy(MATTER_MODE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (rk.RW1, deepcopy(GMR)),
    (rk.BRW, deepcopy(ARW))
])
DENSITY_GRADIENT[de.GRADIENT_ANGLE][df.VALUE] = de.TOP_CENTER_TO_BOTTOM_CENTER
DENSITY_GRADIENT[de.GRADIENT_MODE][df.VALUE] = "Luma Lighten Only"
DENSITY_GRADIENT[rk.RW1][df.SUB][de.GRADIENT][df.VALUE] = "Desert Sunset"
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Drop Zone____________________________________________________________________
DROP_ZONE = OrderedDict([
    (de.NAME, deepcopy(NAME_DROP)),
    (de.TYPE, deepcopy(STYLE_TYPE)),
    (de.SHAPE, deepcopy(SHAPE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.STEPS, deepcopy(STEPS_DROP)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.KEEP, deepcopy(KEEP)),
    (de.COLOR_2A, deepcopy(COLOR_2A)),
    (rk.BRW, deepcopy(MAR))
])

DROP_ZONE[de.COLOR_2A].update({
    df.COLOR_NAME_LIST: ("Perimeter", "Center"),
    df.VALUE:  ((255, 255, 255, 255), (0, 0, 0, 255))
})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

ETCH_SKETCH = OrderedDict([
    (de.SKETCH_TEXTURE, deepcopy(SKETCH_TEXTURE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.CELL_SIZE, deepcopy(CELL_SIZE_ETCH)),
    (rk.BRW, deepcopy(MAR))
])

# Fading Maze__________________________________________________________________
FADING_MAZE = OrderedDict([
    (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (de.GRADIENT_MODE, deepcopy(MATTER_MODE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (de.ROW, deepcopy(R_C)),
    (de.COLUMN, deepcopy(R_C)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.COLOR_2A, deepcopy(COLOR_2A)),
    (rk.RW1, deepcopy(GMR)),
    (rk.BRW, deepcopy(ARW))
])
FADING_MAZE[de.GRADIENT_MODE][df.VALUE] = "Overlay"

for i in (de.GRADIENT_MODE, de.GRADIENT_OPACITY):
    FADING_MAZE[i][df.ISSUE] = vo.MATTER

for i in (de.ROW, de.COLUMN):
    FADING_MAZE[i][df.PAGE_INCR] = 10

for i in (de.ROW, de.COLUMN):
    FADING_MAZE[i][df.RANDOM_Q] = 4, 199
    FADING_MAZE[i][df.LIMIT] = 4, 999
    FADING_MAZE[i][df.VALUE] = (6., 12.)[i == de.COLUMN]
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Floor Sample_________________________________________________________________
FLOOR_SAMPLE = OrderedDict([
    (de.TYPE, deepcopy(STYLE_TYPE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.SLICE_COUNT, deepcopy(SLICE_COUNT)),
    (de.ANGLE, deepcopy(ANGLE)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.COLOR_2A, deepcopy(COLOR_2A)),
    (rk.RW1, {
        df.SUB: OrderedDict([
            (de.SHADOW, deepcopy(SHADOW)),
            (de.MOD, deepcopy(MOD))
        ]),
        df.WIDGET: WidgetRow
    }),
    (rk.BRW, deepcopy(MAR))
])

FLOOR_SAMPLE[de.COLOR_2A].update(
    {df.COLOR_NAME_LIST: (" Start", " End")}
)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Galactic Field_______________________________________________________________
GALACTIC_FIELD = OrderedDict([
    (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (de.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (de.GRADIENT_MODE, deepcopy(MATTER_MODE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (rk.RW1, deepcopy(GMR)),
    (rk.BRW, deepcopy(ARW))
])
GALACTIC_FIELD[de.GRADIENT_ANGLE][df.VALUE] = de.TOP_CENTER_TO_BOTTOM_CENTER
GALACTIC_FIELD[de.GRADIENT_MODE][df.VALUE] = "Subtract"
GALACTIC_FIELD[de.GRADIENT_OPACITY][df.ISSUE] = vo.MATTER
GALACTIC_FIELD[rk.RW1][df.SUB][de.GRADIENT][df.VALUE] = "Galactic Field"
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

GLASS_GAW = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (rk.BRW, deepcopy(MAR))
])
GRADIENT_FILL = OrderedDict([
    (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (de.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.GRADIENT, deepcopy(GRADIENT)),
    (rk.BRW, deepcopy(MAR))
])
HISTORIC_TRIP = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.ITERATIONS, deepcopy(ITERATIONS)),
    (de.SPREAD, deepcopy(SPREAD)),
    (de.SUPERPIXEL_SIZE, deepcopy(SUPERPIXEL_SIZE)),
    (rk.BRW, deepcopy(MAR))
])
LINE_STONE = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (rk.BRW, deepcopy(MAR))
])

# Lost Maze____________________________________________________________________
LOST_MAZE = OrderedDict([
    (de.GRADIENT_ANGLE, GRADIENT_ANGLE),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.ROW, deepcopy(MAZE)),
    (de.COLUMN, deepcopy(MAZE)),
    (de.OFFSET, deepcopy(OFFSET)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.REVERSE, deepcopy(REVERSE)),
    (de.BLUR_D, deepcopy(BLUR_DIALOG)),
    (rk.RW1, deepcopy(GMR)),
    (rk.BRW, deepcopy(ARW))
])
a = LOST_MAZE[de.BLUR_D][df.SUB]
a[de.SWITCH][df.VALUE] = 1
a[de.SIZE_X][df.VALUE] = 10.
a[de.SIZE_Y][df.VALUE] = 500.
a[de.RADIUS][df.VALUE] = 100.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Maze Blend___________________________________________________________________
MAZE_BLEND = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.ROW, deepcopy(MAZE)),
    (de.COLUMN, deepcopy(MAZE)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (rk.BRW, deepcopy(MAR))
])
MAZE_BLEND[de.ROW][df.VALUE] = 4.
MAZE_BLEND[de.COLUMN][df.VALUE] = 100.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Mystery Grate________________________________________________________________
MYSTERY_GRATE = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.COLUMN_1, deepcopy(R_C)),
    (de.COLUMN_2, deepcopy(R_C)),
    (de.OFFSET, deepcopy(OFFSET)),
    (de.REVERSE, deepcopy(REVERSE)),
    (rk.RW1, deepcopy(GMR)),
    (rk.BRW, deepcopy(ARW))
])
MYSTERY_GRATE[de.COLUMN_1][df.VALUE] = 16.
MYSTERY_GRATE[de.COLUMN_2][df.VALUE] = 160.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Noise Rift___________________________________________________________________
NOISE_RIFT = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.NOISE_AMOUNT, deepcopy(NOISE_AMOUNT)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (rk.BRW, deepcopy(MAR))
])
NOISE_RIFT[de.NOISE_AMOUNT][df.VALUE] = 1.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

PAPER_WASTE = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.BLOCK_W, deepcopy(BLOCK_W)),
    (de.BLOCK_H, deepcopy(BLOCK_H)),
    (rk.BRW, deepcopy(MAR))
])

# Pattern Fill_________________________________________________________________
PATTERN_FILL = OrderedDict([
    (de.CRITERION, deepcopy(CRITERION)),
    (de.FILL_MODE, deepcopy(FILL_MODE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.FILL_OPACITY, deepcopy(OPACITY)),
    (de.THRESHOLD, deepcopy(THRESHOLD)),
    (rk.RW1, {
        df.SUB: OrderedDict([
            (de.PATTERN, deepcopy(PATTERN)),
            (de.MOD, deepcopy(MOD))
        ]),
        df.WIDGET: WidgetRow
    }),
    (rk.BRW, deepcopy(ARW))
])
PATTERN_FILL[de.FILL_OPACITY][df.ISSUE] = vo.MATTER
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

RAINBOW_VALLEY = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.POWER, deepcopy(POWER)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.ENGRAVE, deepcopy(ENGRAVE)),
    (rk.BRW, deepcopy(MAR))
])
RECT_PATTERN = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.WIDTH, deepcopy(CLIPBOARD)),
    (de.HEIGHT, deepcopy(CLIPBOARD)),
    (de.COLOR_COUNT, deepcopy(COLOR_COUNT)),
    (de.ANGLE, deepcopy(ANGLE)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.RANDOM_ORDER, deepcopy(RANDOM_ORDER)),
    (de.COLOR_GRID_TYPE, deepcopy(COLOR_GRID_TYPE)),
    (de.COLOR_6A, deepcopy(COLOR_6A)),
    (rk.BRW, deepcopy(MAR))
])
ROCKY_LANDING = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.BLEND, deepcopy(BLEND)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (rk.BRW, deepcopy(MAR))
])

# Roof Top_____________________________________________________________________
ROOF_TOP = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.ROW, deepcopy(R_C)),
    (de.COLUMN, deepcopy(R_C)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.COLOR_3, deepcopy(COLOR_3)),
    (rk.BRW, deepcopy(MAR))
])

for i in (de.ROW, de.COLUMN):
    ROOF_TOP[i][df.RANDOM_Q] = 4, 12

ROOF_TOP[de.COLOR_3].update(deepcopy(CUBE_D))
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

SOFT_TOUCH = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (rk.BRW, deepcopy(MAR))
])

# Specimen Speckle_____________________________________________________________
SPECIMEN_SPECKLE = OrderedDict([
    (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (de.COLOR_1, deepcopy(COLOR_1)),
    (rk.PAR, deepcopy(P3R)),
    (rk.RW1, deepcopy(GMR)),
    (rk.BRW, deepcopy(ARW))
])
SPECIMEN_SPECKLE[de.COLOR_1][df.VALUE] = 176, 82, 0
a = SPECIMEN_SPECKLE[rk.PAR][df.SUB]
a[de.PATTERN_1][df.VALUE] = "Crack"
a[de.PATTERN_2][df.VALUE] = "Leopard"
a[de.PATTERN_3][df.VALUE] = "Paper"

SPECIMEN_SPECKLE[de.GRADIENT_OPACITY].update({
    df.ISSUE: vo.MATTER, df.VALUE: 50.
})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Spiral Channel_______________________________________________________________
SPIRAL_CHANNEL = OrderedDict([
    (de.SPIRAL_MOD, deepcopy(SPIRAL_MOD)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.SPIRAL_DISTANCE, deepcopy(SPIRAL_DISTANCE)),
    (de.ROW, deepcopy(R_C)),
    (de.COLUMN, deepcopy(R_C)),
    (de.GRADIENT_DIRECTION, deepcopy(GRADIENT_DIRECTION)),
    (de.COLOR_1, deepcopy(COLOR_1)),
    (rk.BRW, deepcopy(MAR))
])
SPIRAL_CHANNEL[de.COLOR_1][df.VALUE] = 75, 75, 75
SPIRAL_CHANNEL[de.ROW][df.VALUE] = 1.
SPIRAL_CHANNEL[de.COLUMN][df.VALUE] = 1.
SPIRAL_CHANNEL[de.SPIRAL_MOD][df.VALUE] = de.HORIZONTAL_FLIP

d = {df.RANDOM_Q: (1, 10), df.PAGE_INCR: 2, df.LIMIT: (1, 100)}

SPIRAL_CHANNEL[de.ROW].update(deepcopy(d))
SPIRAL_CHANNEL[de.COLUMN].update(deepcopy(d))
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

SQUARE_CLOUD = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.COLOR_1, deepcopy(COLOR_1)),
    (rk.BRW, deepcopy(MAR))
])
STONE_AGE = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.PATTERN_SIZE, deepcopy(PATTERN_SIZE)),
    (rk.BRW, deepcopy(MAR))
])
TRAILING_VINE = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.LAYER_COUNT, deepcopy(LAYER_COUNT)),
    (de.WAVE_PER_LAYER, deepcopy(WAVE_PER_LAYER)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (rk.BRW, deepcopy(MAR))
])

# Triangle Reverb______________________________________________________________
a = TRIANGLE_REVERB = OrderedDict([
    (de.TYPE, deepcopy(REVERB_TYPE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.REVERB, deepcopy(REVERB)),
    (de.ROW, deepcopy(R_C)),
    (de.COLUMN, deepcopy(R_C)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (rk.PAR, deepcopy(P2R)),
    (de.COLOR_2A, deepcopy(COLOR_2A)),
    (rk.BRW, deepcopy(MAR))
])

for i in (de.ROW, de.COLUMN):
    a[i][df.RANDOM_Q] = 1, 10
    a[i][df.VALUE] = 6.

a1 = a[rk.BRW][df.SUB][de.MOD][df.SUB]
a2 = a1[de.BLUR_D][df.SUB]
a1[de.SWITCH][df.VALUE] = a2[de.SWITCH][df.VALUE] = 1
a2[de.TYPE][df.VALUE] = 1
a2[de.RADIUS][df.VALUE] = 1.
a[rk.PAR][df.SUB][de.PATTERN_1][df.VALUE] = "Leather"
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

WAVE_FILL = OrderedDict([
    (de.TYPE, deepcopy(WAVE_FILL_TYPE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.WAVE_COUNT, deepcopy(WAVE_COUNT)),
    (de.AMPLITUDE, deepcopy(AMPLITUDE_1)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.HORIZONTAL, deepcopy(HORIZONTAL)),
    (de.COLOR_2, deepcopy(COLOR_2)),
    (rk.BRW, deepcopy(MAR))
])
WAVE_FILL[de.COLOR_2].update(
    {df.COLOR_NAME_LIST: (" First Color", " Last Color")}
)
