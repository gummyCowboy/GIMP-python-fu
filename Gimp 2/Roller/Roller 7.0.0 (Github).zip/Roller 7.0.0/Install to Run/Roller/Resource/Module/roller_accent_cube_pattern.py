#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from roller_container import Run
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_gimp_context import set_fill_context_default
from roller_gimp_layer import clipboard_fill, rotate_image_single_layer
from roller_gimp_image import (
    add_layer, add_wip_layer, clip_to_wip, create_image, paste_layer
)
from roller_maya_sub_accent import SubAccent
from roller_pattern import make_cube_pattern
from roller_utility import calc_rotated_image_span


def do_matter(maya):
    """
    Make a matter layer for CubePattern.

    maya: CubePattern
    Return: layer
        'matter'
    """
    j = Run.j
    d = maya.value_d
    key = maya.any_group.dna.key

    set_fill_context_default()
    make_cube_pattern(d[de.HEIGHT], d[de.COLOR_3A])

    if d[de.ANGLE]:
        w = calc_rotated_image_span(j.width, j.height)
        j1 = create_image(w, w)
        z = add_layer(j1, None, 0, key)

        clipboard_fill(z)
        rotate_image_single_layer(j1, d[de.ANGLE])
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

        z = paste_layer(maya.group, n=key)

        pdb.gimp_image_reorder_item(j, z, maya.group, 0)
        pdb.gimp_layer_resize_to_image_size(z)
        clip_to_wip(z)

    else:
        # pattern layer, 'z'
        z = add_wip_layer(key, maya.group)
        clipboard_fill(z)
    return maya.finish(z, d[rk.BRW])


class CubePattern(SubAccent):
    """Create Accent output."""
    kind = de.CUBE_PATTERN

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
