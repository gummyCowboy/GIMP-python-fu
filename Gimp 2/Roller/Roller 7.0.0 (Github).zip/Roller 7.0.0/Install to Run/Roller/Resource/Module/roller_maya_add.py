#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Run
from roller_constant import Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_gimp_layer import reorder_layer
from roller_maya_below import Below
from roller_maya_build import SubBuild
from roller_maya_bump import Bump
from roller_maya_color import Color
from roller_maya_inset import Inset
from roller_maya_noise import Noise
from roller_maya_shadow import Shadow


class Add(SubBuild):
    """Manage Add Preset output for a work-view-type viewer."""
    put = issue_q = ()

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Is the owner of the Add option.

        super_maya: Maya
            The Maya's 'matter' layer alpha is used as a mask.

        k_path: tuple
            (Identity, ...)
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.BELOW] = Below(
            any_group, super_maya, k_path + (rk.BRW, de.BELOW)
        )
        self.sub_maya[sm.BUMP] = Bump(
            any_group, super_maya, k_path + (rk.RW1, de.BUMP)
        )
        self.sub_maya[sm.COLOR] = Color(
            any_group, super_maya, k_path + (de.COLOR,)
        )
        self.sub_maya[sm.NOISE] = Noise(
            any_group, super_maya, k_path + (rk.RW1, de.NOISE_D)
        )
        cast_maya = (self.cast, super_maya) if self.cast else (super_maya,)
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group, super_maya, cast_maya, k_path + (rk.BRW, de.SHADOW)
        )

    def do(self, d, is_change, is_mask, is_back, group):
        """
        Manage layer output during a view run.

        d: dict or None
            Add Preset
            Maybe None if 'go' is False.

        is_change: bool
            Is True if the source layer for
            the Add material has matter change.

        is_mask: bool
            Is True if the source layer's mask changed.

        is_back: bool
            Is True if the background is changed.

        group: group layer
            Parent Shadow layer output.
        """
        self.value_d = d
        self.go = d[de.SWITCH]
        m = False
        is_change |= is_mask

        if self.go:
            j = Run.j
            e = self.sub_maya
            arg = is_change, is_mask
            shadow = e[sm.SHADOW]
            d1 = shadow.sub_maya
            m |= e[sm.BELOW].do(d[rk.BRW][de.BELOW], is_back, is_change)
            m |= shadow.do(d[rk.BRW][de.SHADOW], is_change, is_change, group)
            m |= e[sm.BUMP].do(d[rk.RW1][de.BUMP], *arg)
            m |= e[sm.NOISE].do(d[rk.RW1][de.NOISE_D], *arg)
            m |= e[sm.COLOR].do(d[de.COLOR], *arg)
            if m:
                # Arrange layer.
                # This is the layer order in the group layer:
                #    Light
                #    Inner Shadow
                #    Color
                #    Noise group
                #    Bump
                #    material
                #    Below
                #    Shadow #2
                #    Shadow #1

                # top-down layer position measured from the parent, 'a'
                a = 0

                b = self.super_maya.sub_maya.get(sm.BULB)
                q = [
                    b.matter if b else None,
                    e[sm.COLOR].matter,
                    d1[sm.INSET].matter,
                    e[sm.NOISE].group,
                    e[sm.BUMP].matter,
                    self.super_maya.matter,
                    e[sm.BELOW].matter,
                    d1[sm.SHADOW2].matter,
                    d1[sm.SHADOW1].matter
                ]
                for i in q:
                    a += reorder_layer(j, i, group, a)
        else:
            self.die()


class AddAbove(SubBuild):
    """Manage Add Preset output for Work."""
    put = issue_q = ()

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            This Maya's 'matter' layer alpha masks output.
            Its also the target of Add function.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.BUMP] = Bump(
            any_group, super_maya, k_path + (rk.BRW, de.BUMP)
        )
        self.sub_maya[sm.COLOR] = Color(
            any_group, super_maya, k_path + (rk.RW1, de.COLOR)
        )
        self.sub_maya[sm.INSET] = Inset(
            any_group, super_maya, k_path + (rk.RW1, de.INSET)
        )
        self.sub_maya[sm.NOISE] = Noise(
            any_group, super_maya, k_path + (rk.BRW, de.NOISE_D)
        )

    def do(self, d, is_change, is_mask):
        """
        Manage layer output during a view run.

        d: dict or None
            Bump Preset
            Maybe None if 'go' is False.

        is_change: bool
            Is True if the source layer for
            the Bump material has matter change.

        is_mask: bool
            Is True if the source layer's mask changed.

        Return: bool
            Is True if Add changed anything.
        """
        self.value_d = d
        self.go = d[de.SWITCH]
        m = False
        is_change |= is_mask

        if self.go:
            j = Run.j
            e = self.sub_maya
            arg = is_change, is_mask
            m |= e[sm.BUMP].do(d[rk.BRW][de.BUMP], *arg)
            m |= e[sm.NOISE].do(d[rk.BRW][de.NOISE_D], *arg)
            m |= e[sm.INSET].do(d[rk.RW1][de.INSET], is_change)
            m |= e[sm.COLOR].do(d[rk.RW1][de.COLOR], *arg)
            if m:
                # Sort layer order.
                # This is the layer order in the group layer:
                #    Light
                #    Color
                #    Noise group
                #    Bump
                #    Inset
                #    material

                # layer position, 'a'
                a = 0

                q = [
                    self.super_maya.sub_maya[sm.BULB].matter,
                    e[sm.COLOR].matter,
                    e[sm.INSET].matter,
                    e[sm.NOISE].group,
                    e[sm.BUMP].matter,
                    self.super_maya.matter,
                ]
                z = self.super_maya.group
                for i in q:
                    a += reorder_layer(j, i, z, a)
        else:
            self.die()


class AltAdd(SubBuild):
    """Manage Add Preset output for a work-view-type viewer."""
    put = issue_q = ()

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Is the owner of the AltAdd option.

        super_maya: Maya
            This Maya's 'matter' layer alpha masks output.
            Its also the target of Add function.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.BELOW] = Below(
            any_group, super_maya, k_path + (rk.BRW, de.BELOW)
        )
        self.sub_maya[sm.BUMP] = Bump(
            any_group, super_maya, k_path + (rk.BRW, de.BUMP)
        )
        self.sub_maya[sm.COLOR] = Color(
            any_group, super_maya, k_path + (de.COLOR,)
        )
        self.sub_maya[sm.INSET] = Inset(
            any_group, super_maya, k_path + (rk.RW1, de.INSET)
        )
        self.sub_maya[sm.NOISE] = Noise(
            any_group, super_maya, k_path + (rk.RW1, de.NOISE_D)
        )

    def do(self, d, is_change, is_mask, is_back):
        """
        Manage layer output during a view run.

        d: dict or None
            Bump Preset
            Maybe None if 'go' is False.

        is_change: bool
            Is True if the source layer for
            the Bump material has matter change.

        is_mask: bool
            Is True if the source layer's mask changed.

        is_back: bool
            Is True if the background is changed.
        """
        self.value_d = d
        self.go = d[de.SWITCH]
        m = False
        is_change |= is_mask

        if self.go:
            j = Run.j
            e = self.sub_maya
            arg = is_change, is_mask
            m |= e[sm.BELOW].do(d[rk.BRW][de.BELOW], is_back, is_change)
            m |= e[sm.BUMP].do(d[rk.BRW][de.BUMP], *arg)
            m |= e[sm.NOISE].do(d[rk.RW1][de.NOISE_D], *arg)
            m |= e[sm.INSET].do(d[rk.RW1][de.INSET], is_change)
            m |= e[sm.COLOR].do(d[de.COLOR], *arg)
            if m:
                # Sort layer order.
                # This is the layer order in the group layer:
                #    Light
                #    Color
                #    Noise group
                #    Bump
                #    Inset
                #    material
                #    Below

                # layer position, 'a'
                a = 0

                b = self.super_maya.sub_maya.get(sm.BULB)
                q = [
                    b.matter if b else None,
                    e[sm.COLOR].matter,
                    e[sm.INSET].matter,
                    e[sm.NOISE].group,
                    e[sm.BUMP].matter,
                    self.super_maya.matter,
                    e[sm.BELOW].matter
                ]
                z = self.super_maya.group
                for i in q:
                    a += reorder_layer(j, i, z, a)
        else:
            self.die()
