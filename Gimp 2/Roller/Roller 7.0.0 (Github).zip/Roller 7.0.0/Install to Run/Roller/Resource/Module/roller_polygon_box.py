#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Define 'polygon_box' as function factored from Box polygon."""


def calc_box_b_w(cap, b_w, is_positive_b):
    """
    Calculate the dimensions of the box for cell count.

    'a' is the halved vector of the hexagon.
    'b' is the duel symmetrically clipped vector of the hexagon.

    cap: float
        Is from the Cap X or Cap Y option.

    a_w, b_w: float
        Is the cell size.
        for 'a' and 'b' where 'a' has three
        vertices on its side and 'b' has four.

    is_positive_b: bool
        Is True if Box shape Top or Left are calling.
    """
    # Change in ratio, 'f'; no change, '.0'.
    f = .0

    if is_positive_b:
        if cap > .5:
            # Reduce.
            f = cap - .5

    else:
        # bottom
        if cap < .5:
            # Reduce height.
            f = .5 - cap

    b_w -= (b_w * f)
    return b_w


def calc_box_cell(
    shift,
    div_b, div_a,
    a_w, b_w,
    ratio,
    is_flip_a, is_flip_b,
    canvas_a, canvas_b,
    pin_p
):
    """
    Create intersect points for hexagonal grid.

    'a' is the halved vector of the hexagon.
    'b' is the duel symmetrically clipped vector of the hexagon.

    shift: float
        .0 to .5
        from the Cap options
        Shift left and up for topleft.

    div_b, div_a: int
        Determine how many intersects to generate.

    a_w, b_w: float
        size of the hexagon

    ratio: float
        Calculate symmetrical hexagon point.

    is_flip_a, is_flip_b: bool
        If True, then the coordinates
        are subtracted from the grid span.
        Both Bottom and Right are flipped.

    canvas_a, canvas_b: float
        span of canvas vector for the cell grid

        Flip Box types use this to subtract their
        offsets.

    pin_p: function
        Calculate pin. Justify the grid.
    """
    # intersect coordinate for 'a' and 'b', 'a_q', 'b_q'
    a_q = []
    b_q = []

    # a
    # Is the different between even and odd 'a' pairs, 'a_w2'.
    a_w2 = a_w / 2.

    shift_a = a_w * shift
    a_w1 = offset_a = a_w2 - shift_a

    # b
    b_w2 = b_w * ratio
    b_w4 = b_w - b_w2
    shift_b = b_w2 * shift * -2.
    b_w1 = b_w2 + shift_b
    b_w3 = b_w4 + shift_b
    offset_b = b_w2 + b_w1
    a_grid_w, b_grid_w = div_a * a_w2 + a_w1, div_b * b_w4 + b_w1

    # Justify grid.
    a, b = pin_p(
        canvas_a - a_grid_w if is_flip_a else .0,
        canvas_b - b_grid_w if is_flip_b else .0,
        a_grid_w, b_grid_w
    )

    if is_flip_a:
        a += canvas_a

        # Make the offsets negative.
        a_w1, a_w2 = map(lambda i: -i, (a_w1, a_w2))

    for _ in range(div_a):
        a_q.extend([round(a), round(a + a_w1)])
        a += a_w2

    a_q.extend([round(a), round(a + a_w1)])

    if is_flip_b:
        b += canvas_b

        # Make the offsets negative.
        b_w1, b_w2, b_w3, b_w4 = map(lambda i: -i, (b_w1, b_w2, b_w3, b_w4))

    for _ in range(div_b):
        b_q.extend(
            [round(b), round(b + b_w1), round(b + b_w2), round(b + b_w3)]
        )
        b += b_w4

    # Tack on the last overlapping coordinates.
    b_q.extend([round(b), round(b + b_w1)])

    # Reverse the list order for flipped to match the cell order.
    if is_flip_b:
        b_q = b_q[::-1]

        # The offset is the polygon's 'b' span minus the positive offset.
        offset_b = b_q[5] - b_q[0] - offset_b

    if is_flip_a:
        a_q = a_q[::-1]

        # The offset is the polygon's 'a' span minus the positive offset.
        offset_a = a_q[3] - a_q[0] - offset_a
    return a_q, b_q, offset_a, offset_b


def calc_hex_ratio(h, is_positive_b):
    """
    A normal ratio for a hexagon is .25.
    Use to calculate hexagon vertex height for
    the side with four vertices. The 'w' side
    has three vertices.

    h: float
        from the Cap X and Cap Y option.

    is_positive_b: bool
        Is True if Box shape Top or Left are calling.
    """
    if h < .5:
        if is_positive_b:
            # The topleft side vertex moves up, and the left
            # side vertices move apart on the 'y' or 'b' vector.
            return h / 2.
        else:
            return .25 + -(h - .5) * .5

    if h > .5:
        if is_positive_b:
            # The topleft side vertex moves down, and the left
            # side vertices move apart on the 'y' or 'b' vector.
            return .25 + ((h - .5) * .5)
        else:
            return (1. - h) / 2.

    # unchanged
    return .25
