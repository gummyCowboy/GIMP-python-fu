#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant import Define as df, Signal as si
from roller_constant_identity import Identity as de
from roller_container import The
from roller_ring import Ring
from roller_widget import set_widget_attr
from roller_widget_box import Box as boxer
from roller_widget_button import RowListButton
from roller_widget_row import WidgetRow
from roller_widget_tree import CHOICE_COLOR, TreeViewList
import gtk  # type: ignore

INIT_ROW_ITEM = "Row: {}, Column: 1"
NEW_ROW_ITEM = "Row: {}, Column: {}"
ROW_Q = ["Row: 1, Column: 1"]


class RowList(gtk.Alignment, object):
    """Display a TreeView and TreeView item manipulation Buttons."""
    change_signal = None
    has_table_label = False

    def __init__(self, **d):
        # Use to return focus to a responsible Button.
        self.widget = None

        self._list_buttons = []
        self.dialog = self._row_count_g = None
        d[df.SCROLL] = d[df.NO_VOTE] = True
        self.issue = d[df.ISSUE]

        super(gtk.Alignment, self).__init__()
        set_widget_attr(self, d)

        relay = d[df.RELAY][:]
        hbox = gtk.HBox()

        hbox.add(gtk.Label("\n" * 6))

        # WidgetRow keyword arguments, 'e'
        e = {}

        e.update(d)

        # container for the Table Widget, 'vbox'
        vbox = boxer(padding=(0, 2, 0, 2))

        d.update({df.COLOR: CHOICE_COLOR, df.MINIMUM_W: 70})

        self._row_tree = TreeViewList(**d)

        hbox.add(self._row_tree)
        vbox.add(gtk.Label("Column Per Row List:"))
        vbox.add(hbox)

        e[df.RELAY] = relay

        e.update(
            {df.SUB: OrderedDict([
                (de.ADD_COLUMN, {
                    df.ROW_LIST: self,
                    df.NO_VOTE: True,
                    df.TEXT: de.ADD_COLUMN,
                    df.WIDGET: RowListButton
                }),
                (de.SUBTRACT_COLUMN, {
                    df.ROW_LIST: self,
                    df.NO_VOTE: True,
                    df.TEXT: de.SUBTRACT_COLUMN,
                    df.WIDGET: RowListButton
                })
            ])}
        )

        widget_row = WidgetRow(**e)
        self._add_column_g = widget_row.get_g(de.ADD_COLUMN)
        self._subtract_column_g = widget_row.get_g(de.SUBTRACT_COLUMN)

        vbox.add(widget_row)
        self.add(vbox)

        # Connect event.
        self._row_tree.treeview.get_selection().connect(
            'changed', self.on_row_tree_list_change
        )
        self._add_column_g.relay.insert(0, self.on_add_column_action)
        self._subtract_column_g.relay.insert(0, self.on_subtract_column_action)
        Ring.gob.connect(si.ROW_CHANGE, self.on_row_count_change)

        self._row_tree.set_ui(ROW_Q)
        self.on_row_tree_list_change()

    def append_row(self):
        """Add an item to the RowList."""
        self._row_tree.append_item(
            INIT_ROW_ITEM.format(len(self._row_tree.item_list) + 1)
        )

    def get_a(self):
        """
        Retrieve the AnyGroup value.

        Return: list
            Found in AnyGroup.
        """
        return self.update_any_group.get_widget_a(self.key)

    def get_ui(self):
        """
        Get the condensed value of the RowList.

        Return: list
            [column count, ...]
            The column count corresponds with a zero-based row index.
        """
        return [int(i.split(" ")[-1]) for i in self._row_tree.item_list]

    def get_selected_r(self):
        return self._row_tree.get_selected_r()

    def load_a(self, q):
        """
        Translate a list of column count into a RowList value.
        Update the AnyGroup's value dict and have the AnyGroup
        cast the RowList's vote.

        q: list
            [column count]
            The column count corresponds with a zero-based row index.
        """
        if q:
            self._row_tree.reset()

            for i, a in enumerate(q):
                self._row_tree.append_item(NEW_ROW_ITEM.format(i + 1, a))
            self.update_any_group()

    def on_add_column_action(self, _):
        """
        Add an item to the RowList.

        _: Button
            not used
        """
        q = self._row_tree.item_list
        i = self.get_selected_r()
        if i is not None:
            n = q[i]
            a = min(100, int(n.split(" ")[-1]) + 1)

            self._row_tree.rename_item(i, NEW_ROW_ITEM.format(i + 1, a))
            self.update_any_group()
            self.on_row_tree_list_change()

    def on_subtract_column_action(self, _):
        """
        Reduce the value of the column count for the selected RowList item.

        _: Button
            not used
        """
        q = self._row_tree.item_list
        i = self.get_selected_r()
        if i is not None:
            n = q[i]
            a = max(1, int(n.split(" ")[-1]) - 1)

            self._row_tree.rename_item(i, NEW_ROW_ITEM.format(i + 1, a))
            self.update_any_group()
            self.on_row_tree_list_change()

    def on_row_count_change(self, _, g):
        """
        Respond to change in the RowCountSlider. Adjust RowList
        value to correspond with the row count Widget value. Verify
        that the signal is sent by the RowCountSlider in the
        same AnyGroup (a partner).

        _: Signal
            row count changed

        g: RowCountSlider
            Is responsible. Is not necessarily a partner.
        """
        if not self._row_count_g:
            self._row_count_g = self.any_group.get_widget(de.ROW)
        if not The.load_count and self._row_count_g and g == self._row_count_g:
            q = self._row_tree.item_list

            # current row count, 'a'
            a = len(q) if q else 0

            # requested row count, 'b'
            b = int(g.get_ui())

            if a > b:
                q = q[:b]
                self._row_tree.set_ui(q)

            elif a < b:
                for i in range(b - a):
                    self.append_row()
            if a != b:
                self.update_any_group()

    def update_any_group(self):
        """Update the AnyGroup's value dict and cast a change vote."""
        # RowList's condensed value, 'a'
        a = self.get_ui()
        p = self.any_group.get_view_a

        for i in range(2):
            self.any_group.cast_vote(
                i, self.key, self.issue, a != p(i, self.key)
            )
        self.any_group.set_widget_a(self.key, a)

    def on_row_tree_list_change(self, *_):
        """
        Verify the Buttons dependent on a list selection and column count.
        """
        i = self.get_selected_r()

        if i is None:
            self._add_column_g.set_sensitive(0)
            self._subtract_column_g.set_sensitive(0)
        else:
            a = int(self._row_tree.get_selected_item().split(" ")[-1])

            self._subtract_column_g.set_sensitive(int(a > 1))
            self._add_column_g.set_sensitive(int(a < 100))
