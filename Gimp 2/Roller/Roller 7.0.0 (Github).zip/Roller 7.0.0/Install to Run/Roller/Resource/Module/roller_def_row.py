#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import Define as df, Row as rk
from roller_constant_identity import Identity as de
from roller_def_option import (
    COLOR_1,
    DESATURATE,
    FONT,
    GRADIENT,
    INVERT,
    PATTERN,
    RANDOM,
    TEXT
)
from roller_widget_row import WidgetRow

"""Include row option definition."""

ARW = {
    df.SUB: OrderedDict([
        (de.ADD_ALT, deepcopy(ADD_ALT)),
        (de.RANDOM, deepcopy(RANDOM))
    ]),
    df.WIDGET: WidgetRow
}

# Font / Color Row_____________________________________________________________
FCM = {
    df.SUB: OrderedDict([
        (de.FONT, deepcopy(FONT)),
        (de.COLOR_1, deepcopy(COLOR_1)),
        (de.MARGIN, deepcopy(MARGIN))
    ]),
    df.WIDGET: WidgetRow
}

GMR = {
    df.SUB: OrderedDict([
        (de.GRADIENT, deepcopy(GRADIENT)),
        (de.MOD, deepcopy(MOD))
    ]),
    df.WIDGET: WidgetRow
}
GMM = {
    df.SUB: OrderedDict([
        (de.GRADIENT, deepcopy(GRADIENT)),
        (de.MOD, deepcopy(MOD)),
        (de.MASK, deepcopy(MASK))
    ]),
    df.WIDGET: WidgetRow
}
IDR = {
    df.SUB: OrderedDict([
        (de.INVERT, deepcopy(INVERT)),
        (de.DESATURATE, deepcopy(DESATURATE)),
    ]),
    df.WIDGET: WidgetRow
}
IMR = {
    df.SUB: OrderedDict([
        (de.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (de.MASK, deepcopy(MASK)),
    ]),
    df.WIDGET: WidgetRow
}
IRM = {
    df.SUB: OrderedDict([
        (de.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (de.RESIZE, deepcopy(RESIZE)),
        (de.MASK, deepcopy(MASK))
    ]),
    df.WIDGET: WidgetRow
}

# Lead / Trail Row_____________________________________________________________
LTR = {
    df.COLUMN_TEXT: "Lead & Trail",
    df.SUB: OrderedDict([
        (rk.LEAD, deepcopy(TEXT)),
        (rk.TRAIL, deepcopy(TEXT)),
    ]),
    df.WIDGET: WidgetRow
}
LTR[df.SUB][rk.LEAD][df.TOOLTIP] = Tip.LEAD
LTR[df.SUB][rk.TRAIL][df.TOOLTIP] = Tip.TRAIL
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

MAF = {
    df.SUB: OrderedDict([
        (de.MOD, deepcopy(MOD)),
        (de.ADD, deepcopy(ADD)),
        (de.FRAME, deepcopy(FRAME))
    ]),
    df.WIDGET: WidgetRow
}
MAW = {
    df.SUB: OrderedDict([
        (de.MOD, deepcopy(MOD)),
        (de.ADD, deepcopy(ADD))
    ]),
    df.WIDGET: WidgetRow
}
MFR = {
    df.SUB: OrderedDict([
        (de.MASK, deepcopy(MASK)),
        (de.FRAME, deepcopy(FRAME))
    ]),
    df.WIDGET: WidgetRow
}
P2R = {
    df.SUB: OrderedDict([
        (de.PATTERN_1, deepcopy(PATTERN)),
        (de.PATTERN_2, deepcopy(PATTERN))
    ]),
    df.WIDGET: WidgetRow
}
P3R = {
    df.SUB: OrderedDict([
        (de.PATTERN_1, deepcopy(PATTERN)),
        (de.PATTERN_2, deepcopy(PATTERN)),
        (de.PATTERN_3, deepcopy(PATTERN))
    ]),
    df.WIDGET: WidgetRow
}
