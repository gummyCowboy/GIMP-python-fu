#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    ADD_MASK_ALPHA,
    ADD_MASK_CHANNEL,
    BACKGROUND_FILL,
    CHANNEL_GRAY,
    CHANNEL_OP_ADD,
    CHANNEL_OP_INTERSECT,
    CHANNEL_OP_REPLACE,
    CHANNEL_OP_SUBTRACT,
    CLIP_TO_IMAGE,
    FILL_PATTERN,
    HISTOGRAM_VALUE,
    HUE_RANGE_ALL,
    LAYER_MODE_NORMAL,
    MASK_APPLY,
    MASK_DISCARD,
    ORIENTATION_HORIZONTAL,
    ORIENTATION_VERTICAL,
    PIXELS,
    pdb
)
from roller_constant_identity import Identity as de
from roller_comm import info_msg, show_err
from roller_gimp_context import set_background, set_fill_context_default
from roller_gimp_item import get_item_size, validate_item
from roller_gimp_selection import (
    invert_selection, select_channel, select_rect
)
import math


def adjust_intensity(z):
    """
    Adjust a layer's material so that it's mean
    intensity is within a theoretical bounds.

    z: layer
        Adjust pixel.
    """
    def _histogram():
        """
        Determine the mean intensity.

        Return: float
            mean intensity
        """
        # start range, '.0'; end range, '1.'; mean index, '0'
        return pdb.gimp_drawable_histogram(z, HISTOGRAM_VALUE, .0, 1.)[0]

    def _curves():
        """
        Adjust the layer's middle range using the 'ratio'
        of the theoretical mean and the actual mean.
        """
        pdb.gimp_drawable_curves_spline(
            z,
            HISTOGRAM_VALUE,
            8,                                              # coordinate count
            (.0, .0, .3, .3 * ratio, .7, .7 * ratio, 1., 1.)
        )

    # Curves won't work with a selection.
    pdb.gimp_selection_none(z.image)

    mean = _histogram()

    # If the layer is only black pixels, the mean will be zero.
    if mean:
        # Consider 3 classes of intensity.
        if mean < 85.:
            # theoretical 100
            theory = (128. + mean) / 2.

        elif mean > 170.:
            # theoretical 155
            theory = (127. + mean) / 2.

        else:
            # regular
            theory = 127.5

        mean_min = theory - 16.
        mean_max = theory + 16.

        # Adjust for minimum mean.
        if mean_min > mean != theory:
            ratio = theory / mean
            for i in range(10):
                _curves()
                mean = _histogram()
                if mean >= mean_min:
                    break
        # Adjust for maximum mean.
        if mean_max < mean != theory:
            ratio = theory / mean
            for i in range(10):
                _curves()
                mean = _histogram()
                if mean <= mean_max:
                    break


def apply_mask(z):
    """
    Apply a layer's mask.

    z: layer or None
        Has mask that hasn't been applied.
    """
    if z and z.mask:
        pdb.gimp_layer_remove_mask(z, MASK_APPLY)


def blur_selection(z, a):
    """
    Blur a selection or a layer if there is no selection.

    z: layer
        Receive blur.

    a: float or int
        blur amount
    """
    if a:
        a = min(float(a), 500.)

        if pdb.gimp_selection_is_empty(z.image):
            select_layer(z)
        pdb.plug_in_gauss_rle2(z.image, z, a, a)


def clear_channel(j, z, sc):
    """
    Load a selection channel and clear layer content.

    j: Gimp image
        Has layer and receives selection.

    z: layer
        Has material to clear.

    sc: channel
        Load as a selection.
    """
    select_channel(j, sc)
    clear_selection(z)


def clear_inverse_selection(z, is_keep=False):
    """
    Invert and clear a selection.

    z: layer
        Clear material.

    is_keep: bool
        If it's True, then the selection is the same on exit.
    """
    if z:
        j = z.image

        if is_keep:
            sc = pdb.gimp_selection_save(j)

        invert_selection(j)
        clear_selection(z)
        if is_keep:
            select_channel(j, sc)
            pdb.gimp_image_remove_channel(j, sc)


def clear_selection(z, is_keep=False):
    """
    Clear a layer's selection.

    If there's no selection, do nothing.
    GIMP will clear the layer otherwise.

    z: layer
        Clear material.

    is_keep: bool
        If it's False, then the selection is removed.
    """
    if z:
        j = z.image

        if not pdb.gimp_selection_is_empty(j):
            pdb.gimp_edit_clear(z)
        if not is_keep:
            pdb.gimp_selection_none(j)


def clip_to_view(z):
    """
    Transform a layer to the view size which is also the render image size.
    Layer content is clipped to the image bounds.

    z: layer
        Resize to the view size.
    """
    j = z.image
    pdb.gimp_layer_resize(z, j.width, j.height, *z.offsets)


def clone_layer(z, n="", no_mask=True):
    """
    Duplicate a layer. The duplicate is placed
    above the copied layer in the layer order.

    z: layer
        Duplicate.

    n: string
        Name the clone.

    no_mask: bool
        If it is True, then the source layer's mask is not cloned.

    Return: layer or None
        the duplicate
    """
    if z:
        j = z.image

        # A selection will make a floating selection clone.
        pdb.gimp_selection_none(j)

        z1 = pdb.gimp_layer_new_from_drawable(z, j)
        a = get_layer_position(z)

        pdb.gimp_image_insert_layer(j, z1, z.parent, a)
        set_layer_attr(z1, LAYER_MODE_NORMAL, 100.)

        if z1.mask and no_mask:
            remove_layer(z1.mask)

        if n:
            z1.name = n
        return z1


def clone_opaque_layer(z, is_opaque=True, n=None):
    """
    Return a duplicate layer with an optional
    transform to make its pixel fully opaque.

    z: layer
        Clone.

    is_opaque: flag
        When True, the clone is made 100% opaque.

    n: string or None
        Name the clone.

    Return: layer or None
        the clone
    """
    if z:
        j = z.image
        z = clone_layer(z, n=n, no_mask=False)

        # no semi-transparency
        if is_opaque:
            if pdb.gimp_item_is_group(z):
                z = pdb.gimp_image_merge_layer_group(j, z)

            # threshold all, '0'
            pdb.plug_in_threshold_alpha(j, z, 0)
        return z


def clipboard_fill(z):
    """
    Fill a layer with a Clipboard Image pattern.

    z: layer
        Fill.
    """
    pdb.gimp_context_set_pattern("Clipboard Image")
    pdb.gimp_drawable_edit_bucket_fill(z, FILL_PATTERN, .0, .0)


def clipboard_fill_arg(*q):
    """
    Fill a layer with a "Clipboard Image" pattern.

    q: tuple
        (layer, not used)

    Return: layer
        for calling function
    """
    z = q[0]

    pdb.gimp_context_set_pattern("Clipboard Image")
    pdb.gimp_drawable_edit_bucket_fill(z, FILL_PATTERN, .0, .0)
    return z


def color_layer(z, q):
    """
    Fill a layer with a color.

    z: layer
        Receive color.

    q: tuple
        RGB color
    """
    select_layer_rect(z)
    color_selection(z, q)


def color_layer_default(z, q):
    """
    Fill a layer with a color.

    z: layer
        Receive color.

    q: tuple
        RGB color
    """
    select_layer_rect(z)
    color_selection_default(z, q)


def color_selection(z, q):
    """
    Fill a layer's selection with a color. Is context sensitive.

    z: layer
        Apply fill.

    q: tuple
        RGB or RGBA color

    opacity: float
        of the color
    """
    if len(q) != 4:
        # RGB
        opacity = 100.

    else:
        # RGBA
        opacity = round(q[3] / 255. * 100., 1)

    set_background(q)
    pdb.gimp_edit_bucket_fill(
        z,
        BACKGROUND_FILL,
        LAYER_MODE_NORMAL,
        opacity,
        1.,                     # threshold all
        0,                      # no sample merge
        .0, .0                  # x, y fill point
    )


def color_selection_default(z, q):
    """
    Fill a selection with color. Use the default context.

    z: layer
        Receive color.

    q: tuple
        RGB color
    """
    set_fill_context_default()
    color_selection(z, q)


def create_mask(z, option=ADD_MASK_ALPHA):
    """
    Give a layer a mask.

    z: layer
        Mask.

    option: gimpfu enum
        mask type
    """
    mask = pdb.gimp_layer_create_mask(z, option)
    z.add_mask(mask)


def dilate(z):
    """
    Dilate pixel on a layer.

    z: layer
        Receive dilation.
    """
    pdb.plug_in_dilate(
        z.image,
        z,
        6,              # opaque
        0,              # channel zero
        1.,             # full rate
        0,              # direction mask
        0,              # low limit
        255             # upper limit
    )


def discard_mask(z):
    """
    Delete a layer's mask.

    z: layer or None
        Has mask.
    """
    if z and z.mask:
        pdb.gimp_layer_remove_mask(z, MASK_DISCARD)


def do_curves(z, q):
    """
    Execute GIMP's curve function to alter a layer's
    histogram value. Remove an existing selection.

    z: layer
        Modify with curves.

    q: iterable
        (input float, output float, ...) series
        The input and output range is from 0.0 to 1.0.
    """
    # Curves won't work with a selection.
    pdb.gimp_selection_none(z.image)
    pdb.gimp_drawable_curves_spline(z, HISTOGRAM_VALUE, len(q), q)


def do_saturate(z, d):
    """
    Adjust a layer's saturation.

    z: layer
        Change saturation.

    d: dict
        Has a SATURATION Identity.
    """
    f = d[de.SATURATION]
    if f:
        saturate(z, f)


def flip_layer(z, is_h=False):
    """
    Flip a layer horizontally or vertically.

    z: layer
        Flip pixel.

    is_h: bool
        If it's True, then flip the layer horizontally.
        Otherwise, flip the layer vertically.
    """
    a = ORIENTATION_HORIZONTAL if is_h \
        else ORIENTATION_VERTICAL

    # axis, '0'
    pdb.gimp_selection_none(z.image)
    pdb.gimp_item_transform_flip_simple(z, a, True, 0)


def get_layer_offsets(z):
    """
    Convert a layer offsets to float.

    z: layer

    Return: tuple
        (x, y) of float
        offsets; position of layer
    """
    return map(float, z.offsets)


def get_layer_position(z):
    """
    Get a layer's top-down offset from its parent group.

    z: layer
        Determine its position.

    Return: int
        offset from the parent layer
        from 0 to the number of layers in the group minus one
    """
    if z:
        return pdb.gimp_image_get_item_position(z.image, z)
    return -1


def get_mean_color(z):
    """
    Use GIMP's histogram function to collect the mean value
    of the red, green, and blue channels. If there's
    a selection, the selected material is sampled.

    z: layer
        Sample its material.

    Return: tuple
        RGB
    """
    # (r, g, b) where each value is .0 to 255, 'q'.
    q = ()

    for i in (1, 2, 3):
        q += (int(pdb.gimp_drawable_histogram(z, i, .0, 1.)[0]),)
    return q


def hide_layer(z):
    """
    Make a layer invisible.

    z: layer
        Hide.
    """
    if z.visible:
        pdb.gimp_item_set_visible(z, 0)


def isolate_channel(z, sc, is_keep=False):
    """
    Clear out material not in a selection.

    z: layer
        Clear.

    sc: selection channel
        The selection part is preserved and the other part is removed.

    is_keep: flag
        If it's True, then the selection remains.
    """
    select_channel(z.image, sc)
    clear_inverse_selection(z, is_keep=is_keep)


def make_clouds(z, seed_):
    """
    Fill a layer with solid noise which looks a bit like clouds.

    z: layer
        Receive noise.

    seed_: int
        Generate unique noise.
    """
    pdb.plug_in_solid_noise(
        z.image, z,
        0,                      # no tile-able
        0,                      # no, turbulent
        seed_,
        7,                      # medium detail
        2.,                     # horizontal size
        2.                      # vertical size
    )


def make_plan_text_layer(j, n, font_size):
    """
    Create a new text layer.

    j: GIMP image
        Receive text layer.

    n: string
        text to display

    font_size: float
        scale of font

    Return: layer
        text
    """
    return pdb.gimp_text_layer_new(
        j, n, 'Sans-serif', font_size, PIXELS
    )


def make_polar_mask(z, is_dark=False):
    """
    Create a dark or light mask.

    is_dark: bool
        If it's True, then make a dark mask.

    Return: layer
        mask
    """
    def _hide(_z):
        """
        Hide every layer except 'z'.

        _z: group layer or GIMP image
        """
        for _z1 in _z.layers:
            if _z1 != clone:
                if pdb.gimp_item_is_group(_z1):
                    _hide(_z1)
                elif _z1.visible:
                    hide_q.append(_z1)
                    hide_layer(_z1)

    hide_q = []
    j = z.image
    n = "Dark" if is_dark else "Light"
    clone = clone_layer(z, n=n)

    _hide(j)
    discard_mask(clone)

    if is_dark:
        pdb.gimp_drawable_invert(clone, 0)

    # Work only one visible layer to get its channel.
    channel = pdb.gimp_channel_new_from_component(j, CHANNEL_GRAY, n)

    for i in hide_q:
        show_layer(i)

    # parent channel, 'None'; position to insert channel, '0'
    pdb.gimp_image_insert_channel(j, channel, None, 0)

    pdb.gimp_image_set_active_channel(j, channel)

    mask = pdb.gimp_layer_create_mask(z, ADD_MASK_CHANNEL)

    pdb.gimp_layer_add_mask(z, mask)
    pdb.gimp_image_remove_channel(j, channel)
    pdb.gimp_image_remove_layer(j, clone)


def make_text_layer(j, z, antialias, text, size, font, color, x, y, w, h):
    """
    Create a text layer. Transform the text layer to fit into a rectangle.

    j: GIMP image
        Receive text layer.

    z: layer or None
        Receive text.

    text: string
        to make on text layer

    size: float
        Is the font size of text.

    font: string
        font name

    color: tuple
        RGBA

    x, y: float
        topleft coordinate of text

    w, h: float
        Transform the completed text size.

    Return: tuple
        (bool, layer)
        bool
            Is a success flag, where true equates to success.

        layer
            transformed text
            Could be None on failure.
    """
    # text layer, 'z1'
    z1 = None

    go = True
    text = text.decode('utf-8').strip()
    offset_z = get_layer_position(z) if z else 0

    # Remove any selection so that 'gimp_text_fontname' returns a layer.
    pdb.gimp_selection_none(j)

    try:
        # Pass None as a layer option so
        # that function will create a new layer.
        # Text layer type, 'z1'
        z1 = pdb.gimp_text_fontname(
            j, None,
            x, y,
            text,
            0,                      # border
            1,
            size,
            PIXELS,
            font
        )

    except Exception as ex:
        show_err(ex)
        info_msg("Apologies. Roller's text method failed to draw.")
        go = False

    if z1:
        pdb.gimp_text_layer_set_color(z1, color)

        pdb.gimp_text_layer_set_antialias(z1, antialias)
        pdb.plug_in_autocrop_layer(j, z1)

        if w:
            pdb.gimp_item_transform_scale(z1, 0., 0., w, h)
        if validate_item(z):
            # Convert the Text layer to a raster layer.
            # Move the layer, 'z1', from the top of the layer stack.
            # so that it can be merged with the target layer, 'z'.
            pdb.gimp_image_reorder_item(j, z1, z.parent, offset_z)
            z1 = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
    return go, z1


def not_empty(z):
    """
    Return the boolean of the pixel count of a layer. The color
    count is zero if the layer is completely transparent. Remove
    selection so the plug-in function works properly.

    z: layer
        to check

    Return: bool
        Is True if the layer exists and has a pixel.
    """
    if z:
        pdb.gimp_selection_none(z.image)
        return bool(pdb.plug_in_ccanalyze(z.image, z))
    return False


def remove_layer(z):
    """
    Remove a drawable, a layer or mask, if it exists.

    z: drawable or None
        Remove.
    """
    if validate_item(z):
        if pdb.gimp_item_is_layer_mask(z):
            z1 = pdb.gimp_layer_from_mask(z)
            discard_mask(z1)
        else:
            pdb.gimp_image_remove_layer(z.image, z)


def reorder_layer(j, z, parent, offset):
    """
    Arrange a layer.

    j: GIMP image
        WIP

    z: layer or None
        Arrange.

    parent: group layer
        The layer is moved to this group.

    offset: int
        Is the layer's correct position.
        0 .. n where n is the number of layers in the group

    Return: int
        Is one if the layer is not None. Is zero if the layer is None.
    """
    if z:
        a = pdb.gimp_image_get_item_position(j, z)

        if a != offset or z.parent != parent:
            pdb.gimp_image_reorder_item(j, z, parent, offset)
        return 1
    return 0


def rotate_image_single_layer(j, a):
    """
    Rotate the base layer of an image.

    j: GIMP image
        Rotate assuming there is only one layer.

    a: numeric
        Is the rotation amount in degree.

    Return: layer
        the transformed layer
    """
    rotate_layer(j.layers[0], a)
    pdb.gimp_image_resize_to_layers(j)
    return j.layers[0]


def rotate_layer(z, f):
    """
    Rotate a layer around the center of its image.

    z: layer
        Rotate.

    f: float
        Is the rotation angle in degree.
    """
    # If there's a selection, the selection would be rotated.
    pdb.gimp_selection_none(z.image)
    pdb.gimp_item_transform_rotate(
        z,
        math.radians(f),
        1,                           # yes, auto-center
        .0, .0                       # x, y
    )


def saturate(z, f):
    """
    Adjust a layer's saturation.

    z: layer
        Is the target of the op.

    f: float
        -100. to 100.0
        from no saturation to full
    """
    # hue offset, '.0'; lightness, '.0'; overlap, '.0'
    pdb.gimp_drawable_hue_saturation(z, HUE_RANGE_ALL, .0, .0, f, .0)


def select_layer(z, option=CHANNEL_OP_REPLACE):
    """
    Select an item. If the item has a mask,
    select it so that its selection intersects.

    z: layer or None
        Select.

    option: GIMP enum
        selection operation
        replace, add, subtract, or intersect

    Return: state of selection
    """
    j = z.image
    sc = sc1 = None
    is_add = option == CHANNEL_OP_ADD and z.mask
    is_subtract = option == CHANNEL_OP_SUBTRACT and z.mask
    is_intersect = option == CHANNEL_OP_INTERSECT and z.mask

    pdb.gimp_context_set_feather(0)
    pdb.gimp_context_set_antialias(0)

    if is_add or is_subtract or is_intersect:
        if not pdb.gimp_selection_is_empty(j):
            sc = pdb.gimp_selection_save(j)

    if z.mask:
        # Select the item and its mask intersection.
        pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z.mask)
        pdb.gimp_image_select_item(j, CHANNEL_OP_INTERSECT, z)

        if sc:
            if is_add or is_intersect:
                select_channel(j, sc, option=option)
            elif is_subtract:
                if not pdb.gimp_selection_is_empty(j):
                    sc1 = pdb.gimp_selection_save(j)

                    select_channel(j, sc)
                    select_channel(j, sc1, option=option)

    else:
        pdb.gimp_image_select_item(j, option, z)
    if sc:
        pdb.gimp_image_remove_channel(j, sc)
        if sc1:
            pdb.gimp_image_remove_channel(j, sc1)


def select_layer_iffy(j, z, option=CHANNEL_OP_REPLACE):
    """
    Select an item. If the item has a mask,
    select it so that its selection intersects.
    If the layer reference is empty, then select None.

    j: Gimp Image
        owner of hypothetical layer 'z'.

    z: layer or None
        Select.

    option: GIMP enum
        selection operation
        replace, add, subtract, or intersect

    Return: state of selection
    """
    if z:
        select_layer(z, option=option)
    else:
        pdb.gimp_selection_none(j)


def select_layer_rect(z):
    """
    Select a layer's bounds using its offsets and size.

    z: layer
        Select a bounding rectangle.

    Return: state of selection
    """
    w, h = get_item_size(z)
    x, y = get_layer_offsets(z)
    select_rect(z.image, x, y, w, h)


def select_opaque(z, option=CHANNEL_OP_REPLACE):
    """
    Make a selection from an cloned opaque layer.

    z: layer
        Select.

    option: GIMP enum
        Is ADD, INTERSECT, REPLACE, or SUBTRACT.

    Return: state of selection
    """
    if z:
        j = z.image
        sc = None

        if option != CHANNEL_OP_REPLACE:
            sc = pdb.gimp_selection_save(j)

        z1 = clone_opaque_layer(z)

        if sc:
            select_channel(j, sc)

        select_layer(z1, option=option)
        pdb.gimp_image_remove_layer(z.image, z1)
        if sc:
            pdb.gimp_image_remove_channel(j, sc)


def set_layer_attr(z, mode, opacity):
    """
    Set layer attributes mode and opacity. Hypothetically,
    its faster to set attribute only when it's changed.

    z: layer
        WIP

    mode: GIMP layer mode enum
        Change the layer's mode.

    opacity: float
        Change the layer's opacity.

    Return: bool
        Is True if there is change.
    """
    m = False

    if z.opacity != opacity:
        z.opacity = opacity
        m = True

    if z.mode != mode and mode is not None:
        z.mode = mode
        m = True
    return m


def set_layer_mode(z, mode):
    """
    Set a layer's mode.

    z: layer
        WIP

    mode: GIMP layer mode enum
        Change the layer's mode.

    Return: bool
        Is True if there is change.
    """
    if z.mode != mode:
        z.mode = mode
        return True
    return False


def show_layer(z):
    """
    Make a layer visible.

    z: layer
        to show
    """
    if not z.visible:
        pdb.gimp_item_set_visible(z, 1)


def verify_group_layer(group):
    """
    Merge a group layer, then verify that the new layer has a
    pixel. If the new layer does not have a pixel, remove it.

    group: layer
        Merge and verify.

    Return: layer or None
        Is the product of merged group.
        Is None if there was no pixel.
    """
    return verify_layer(
        pdb.gimp_image_merge_layer_group(group.image, group)
    )


def verify_layer(z):
    """
    Verify that a layer has a pixel. If the layer
    does not have a pixel, remove the layer.

    z: layer
        Test for pixel.

    Return: layer or None
        Is None if the layer had no material.
    """
    if not_empty(z):
        return z
    if z:
        pdb.gimp_image_remove_layer(z.image, z)
