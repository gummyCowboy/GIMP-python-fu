#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from roller_constant import Issue as vo, Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_image import (
    add_sub_maya_group, check_matter, copy_below, make_group_layer
)
from roller_gimp_layer import not_empty
from roller_maya import Maya
from roller_maya_add import Add
from roller_maya_layer import check_mix_basic
from roller_preset_mod import do_mod

ADD_PATH = rk.BRW, de.ADD
MOD_PATH = [
    (),
    (de.BLUR_D,),
    (rk.BRW, de.MOD),
    (rk.BRW, de.MOD, de.BLUR_D),
    (rk.RW1, de.MOD),
    (rk.RW1, de.MOD, de.BLUR_D)
]


class SubAccent(Maya):
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )
    vote_type = vo.MAIN

    def __init__(self, any_group, do_matter, is_dependent, is_seeded, is_old):
        self.bg_z = None
        self.do_matter = do_matter
        self.is_seeded = is_seeded
        self.is_dependent = is_dependent

        # work-view-type index, '1'
        Maya.__init__(self, any_group, 1, SubAccent.put, MOD_PATH)

        self.sub_maya[sm.ADD] = Add(any_group, self, ADD_PATH)
        if is_old:
            self.reset_issue()

    def do(self, group):
        """
        Create SubAccent matter and Add matter.

        group: group layer
            Accent created.
        """
        is_dead = False
        d = self.value_d = self.any_group.get_value_d()

        if self.is_dependent:
            if Run.is_back:
                self.is_matter = True

        go = self.is_matter or self.is_mode or self.is_opacity
        self.group = group

        if self.is_matter:
            if self.is_dependent:
                self.bg_z = copy_below(self.group)
                if not not_empty(self.bg_z):
                    go = False
                    is_dead = True

        if go:
            self.realize()

        if self.matter and not is_dead:
            self.sub_maya[sm.ADD].do(
                d[rk.BRW][de.ADD],
                self.is_matter,
                self.is_matter,
                Run.is_back,
                group
            )

        else:
            self.die()

        if self.bg_z:
            pdb.gimp_image_remove_layer(Run.j, self.bg_z)
            self.bg_z = None
        self.reset_issue()

    def finish(self, z, d):
        """
        z: layer
            'matter'

        d: dict
            MOD Preset

        Return: layer
            SubAccent 'matter'
        """
        if z:
            z = do_mod(z, d[de.MOD])
            z.name = "{} {}".format(self.group.name, self.kind)
        return z

    def init_background_groups(self, j):
        """
        Create two layer groups. Add a layer to the innermost group.

        Return: tuple
            (group layer, group layer, layer)
            (top, middle, bottom)
        """
        parent = add_sub_maya_group(self)
        group = make_group_layer(j, parent, 0, "Group")

        pdb.gimp_image_reorder_item(j, self.bg_z, group, 0)
        return parent, group
