#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_container import Globe, PlanZ, The
from roller_constant import NodePanel as np, Step as sk
from roller_constant_identity import Identity as de
from roller_def_tree import MAIN_TREE_D
from roller_gimp_layer import remove_layer
from roller_helm import Helm
from roller_preset_last_used import LastUsed
from roller_port import Port
from roller_port_process import PortProcess
from roller_widget_node_panel import NodePanel


def _load_steps():
    """Load the steps from the previous session."""
    # Use the Steps SuperPreset to load the last used file.
    g = Helm.get_group(de.PRESET_STEPS).get_widget(de.PRESET)
    d = g.load_file(de.LAST_USED, g.any_group.dna.key)
    if d:
        LastUsed.d = deepcopy(d)


class PortMain(PortProcess):
    """Display main Window Widget."""

    def __init__(self, d):
        """Make a navigation tree."""
        self._node_panel = NodePanel(d, self.on_port_change, np.MAIN)

        PortProcess.__init__(self, d, None)

        The.load_count += 1

        self.draw()
        _load_steps()
        The.load_count -= 1

    def accept_main_port(self, *_):
        """
        Begin a render.

        Return: True
            The keypress is handled.
        """
        if Globe.delete_plan:
            remove_layer(PlanZ.plan_group)
            PlanZ.plan_group = None

        # 'do_render' index, '4'
        Port.view.run(4)
        return True

    @staticmethod
    def cancel_main_port(*_):
        """
        Close the Window.

        Return: True
            The keypress is handled.
        """
        # ImageGradient may have produced a gradient.
        The.grad = None

    def draw(self):
        """Draw the Port's Widgets."""
        self.draw_row((self.draw_navigation, self.draw_process))

    def draw_navigation(self, g):
        """
        Draw a navigation tree.

        g: GTK container
            Receive a group of Widgets.
        """
        g.add(self._node_panel)
        self._node_panel.create_panel(MAIN_TREE_D, de.STEPS, sk.STEPS)

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return self.cancel_main_port, self.accept_main_port
