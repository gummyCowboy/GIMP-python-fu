#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Dog, The
from roller_constant import Color as co, Define as df, Signal as si, Step as sk
from roller_constant_identity import Identity as de
from roller_def_tree import create_steps_insert_d
from roller_utility import reduce_color
from roller_helm import Helm
from roller_ring import Ring
from roller_shelf import Shelf
from roller_option_squish import hide_options
from roller_step import (
    connect_sub_str,
    count_parts,
    get_branch_part,
    get_model,
    get_type_text
)
from roller_widget_box import Eventful
from roller_widget_dna import DNA
import gtk  # type: ignore

LEAF_SET = {'make_vbox'}
NODE_SET = {'labeled', 'make_vbox', 'node'}


def get_k(node):
    return node.any_group.name_step_k


def _remove_empty_node():
    """Remove Node that has no DNA or label."""
    for i in Helm.get_all_step_list():
        # AnyGroup, 'a'
        a = Helm.get_group(i)
        if a and a.dna.is_node:
            if not a.get_widget(de.NODE).get_label_list():
                # It's useless.
                _remove_node(i)


def _remove_with_dna(dna):
    """
    Remove DNA from the Node. Move its AnyGroup value from the
    Helm dict to the Shelf dict. Recursively remove empty Node.

    dna: DNA
        Remove from Node list.
    """
    name_step_k = dna.any_group.name_step_k
    node = dna.get_parent_node()
    if node:
        node.remove_item_by_type(dna.type_)
        _shelve_group(name_step_k)
        Ring.plug(si.PANEL_CHANGE, None)
        if not node.get_label_list():
            dna = node.get_dna_by_type(get_branch_part(name_step_k))

            # Is it still around?
            if dna:
                _remove_with_dna(dna)


def _remove_node(name_step_k):
    """
    Remove a Node from the interface.

    name_step_k: string
        Has a Model name reference.
    """
    any_group = Helm.get_group(name_step_k)
    if any_group:
        if any_group.dna.is_node:
            _remove_with_dna(any_group.dna)


def _remove_non_node(name_step_k):
    """
    Remove a non-Node Widget AnyGroup from the interface.

    name_step_k: string
        Has a Model name reference.

    Return: bool
        Is True if the DNA's fingerprint was removed.
    """
    any_group = Helm.get_group(name_step_k)

    if any_group:
        if not any_group.dna.is_node:
            _remove_with_dna(any_group.dna)
            return True
    return False


def _shelve_group(name_step_k):
    """
    Move a step and its value dict from the Helm to the Shelf.
    This happens when the user has modified the navigation tree.

    name_step_k: string
        Its first part is a Model name. Has at least two parts.
    """
    any_group = Helm.get_group(name_step_k)

    if any_group and any_group.dna.is_preset:
        Shelf.set_step(name_step_k, any_group.get_value_d())
        Helm.remove_step(name_step_k)
        any_group.emit(si.DISAPPEAR, None)

    elif any_group and not any_group.dna.is_preset:
        # Node and SuperPreset are not shelved.
        Helm.remove_step(name_step_k)
        any_group.emit(si.DISAPPEAR, None)
    if count_parts(name_step_k) == 1:
        # Remove Model.
        Helm.remove_step(name_step_k)
        if any_group.dna.model:
            any_group.dna.model.die()


# Is a new style class reference for Python 2.7, 'object'.
class NodePanel(gtk.HBox, object):
    """
    Is a gtk.HBox container row with a column of VBox, 'cubby'.
    A cubby is a host for container sharing via a VBox swap operation.
    Has a navigation tree with an interface branch and an AnyGroup leaf.
    """
    _color = co.INIT_COLOR
    colors = []

    # Calculate a background color gradient.
    # number of cubby allocated, '7'
    for i in range(7):
        colors.append(_color)
        _color = reduce_color(_color)

    def __init__(self, d, on_change, panel_type):
        """
        Create an HBox.

        d: dict
            Has init option for Widget.

        on_change: function
            Except for Node, is the initial on
            change function for AnyGroup init.

        panel_type: int
            NodePanel enum
        """
        self.cubby_q = []
        self.first_node = None
        self._option_d = d
        self._on_change = on_change
        self.panel_type = panel_type
        self.roller_win = d[df.ROLLER_WIN]
        super(gtk.HBox, self).__init__()

    def _add_cubby(self):
        """
        Add a VBox to the HBox row.

        Return: GTK VBox
            new cubby
        """
        box = Eventful(NodePanel.colors[len(self.cubby_q)])
        vbox = gtk.VBox()
        self.cubby_q.append(vbox)

        box.add(vbox)
        self.add(box)

        # The default behavior of the 'add' function
        # doesn't guarantee that a box is visible.
        box.show()
        vbox.show()
        return vbox

    def _create_leaf(self, parent_node, tree_d, key, row, column, name_step_k):
        """
        Create a leaf option group. A leaf is represented by the last
        part of a step-key and contains user option.

        parent_node: Node
            parent of leaf

        tree_d: dict
            Define the order and type of items in the navigation tree.

        key: string
            Preset

        row: int
            The leaf has an Node item that is
            offset from the top of the leaf's parent node.

        column: int
            cubby index

        name_step_k: string
            Define the leaf's path. Formats include:
                'leaf'
                'model.leaf'
                'model.branch.leaf'
        """
        true_attr_set = set(LEAF_SET)
        true_attr_set.update(tree_d[key][df.TRUE_ATTR])
        dna = DNA(
            key,
            true_attr_set,
            {'model': get_model(name_step_k), 'parent_node': parent_node}
        )

        parent_node.insert_r(row, dna)

        d = {
            df.COLOR: NodePanel.colors[column],
            df.DNA: dna,
            df.RELAY: [self._on_change],
            df.NAME_STEP_K: name_step_k,
            df.TREE_COLOR: NodePanel.colors[column]
        }

        d.update(self._option_d)
        d.update(tree_d[dna.key])

        if key in Dog.class_group:
            # Preset
            dna.any_group = Dog.class_group[key](**d)
            Ring.plug(si.PANEL_CHANGE, self.panel_type)
        else:
            # SuperPreset
            dna.any_group = Dog.many_group(**d)
            Ring.plug(si.PANEL_CHANGE, self.panel_type)

    def _create_node(self, parent_node, tree_d, key, name_step_k, row, column):
        """
        Create an AnyGroup that contains a Node.

        parent_node: Node
            parent of leaf

        tree_d: dict
            Define a navigation tree.

        key: string
            Group or Node key
            Model name

        name_step_k: string
            Has a period for a delimiter.
            A Part is a Node or leaf UI option group.
            Made by joining the parts the delimiter.

        row: int or None
            insertion index into a parent Node

        column: int
            0 to 6
            'cubby' index
        """
        k = key if name_step_k else sk.STEPS
        d = tree_d[k][df.DNA]
        cubby = self._get_cubby(column)
        dna = DNA(
            key,
            NODE_SET,
            {'model': get_model(name_step_k), 'parent_node': parent_node}
        )

        if not cubby.get_children():
            cubby.add(dna.vbox)

        if row is not None:
            parent_node.insert_r(row, dna)

        e = {
            df.COLUMN: column,
            df.DNA: dna,
            df.RELAY: [self.on_node_change],
            df.ROLLER_WIN: self.roller_win,
            df.NAME_STEP_K: name_step_k,
            df.TREE_COLOR: NodePanel.colors[column]
        }
        dna.any_group = Dog.loner_group(**e)
        this_node = dna.any_group.get_widget(de.NODE)

        if column == 0:
            self.first_node = this_node

        this_node.connect(si.ADD_ITEM, self.on_add_item)
        this_node.connect(si.UPDATE_TREE, self.on_update_tree)
        Ring.plug(si.PANEL_CHANGE, self.panel_type)
        for row, node_text in enumerate(d.keys()):
            self._make_node_or_leaf(
                this_node, d, node_text, name_step_k, row, column + 1
            )

    def _get_cubby(self, column):
        """
        Fetch the VBox for a NodePanel column.

        column: int
            0 to 6
            cubby index

        Return: VBox or None
            the cubby
        """
        if column < len(self.cubby_q):
            return self.cubby_q[column]

        # Make a cubby for the next column.
        return self._add_cubby()

    def _grow_node_branch(self, parent_node, tree_d, key, name_step_k, column):
        """
        Update the navigation tree from a Node.

        parent_node: Node
            parent to the next addition

        tree_d: dict
            Define a navigation tree.

        key: string
            Group, Model, or Node key

        name_step_k: string
            Where the path corresponds with joined Node and Leaf item,
            and a Model is identified by its name.

        column: int
            0 to 6
            index to 'cubby'
        """
        d = tree_d[key][df.DNA]
        for row, k in enumerate(d.keys()):
            self._make_node_or_leaf(
                parent_node, d, k, name_step_k, row, column + 1
            )

    def _make_node_or_leaf(
        self, parent_node, tree_d, key, name_step_k, row, column
    ):
        """
        Make a branch or leaf. Is recursive with 'self._create_node'.

        parent_node: Node
            parent to the next navigation item

        tree_d: dict or None
            Define a navigation tree.

        key: string
            Identity

        name_step_k: string
            Where the path is made of joined Node and Leaf item,
            and a Model is identified by its name.

        row: int
            insertion index into a Node

        column: int
            index to the NodePanel cubby
            0 to 6
        """
        if count_parts(name_step_k) > 1:
            # Model step-key are unique to due to their Model name.
            name_step_k = connect_sub_str(name_step_k, get_type_text(key))

        else:
            # Steps Preset and Shadow Preset need unique name-step-key.
            name_step_k = connect_sub_str(name_step_k, key)

        is_create_node = 'node' in tree_d[key][df.TRUE_ATTR]
        any_group = Helm.get_group(name_step_k)

        if any_group:
            # A leaf is a dead-end, so check for Node.
            if is_create_node:
                parent_node = any_group.get_node()
                self._grow_node_branch(
                    parent_node,
                    tree_d,
                    key,
                    name_step_k,
                    column
                )
        else:
            if is_create_node:
                self._create_node(
                    parent_node, tree_d, key, name_step_k, row, column
                )
            else:
                self._create_leaf(
                    parent_node, tree_d, key, row, column, name_step_k
                )

    def create_panel(self, tree_d, key, name_step_k):
        """
        Fill the NodePanel with Node, Preset, and SuperPreset items.

        tree_d: dict
            Define a navigation tree.

        key: string
            SuperPreset, Preset, Node, or Model name/key

        name_step_k: string
            Has a period for a delimiter.
            A Part is a Node or leaf UI option group.
            Made by joining the parts with an inserted delimiter.
        """
        d = tree_d[name_step_k][df.DNA]
        cubby = self._get_cubby(0)
        dna = DNA(key, NODE_SET, {})

        if not cubby.get_children():
            cubby.add(dna.vbox)

        e = {
            df.COLUMN: 0,
            df.DNA: dna,
            df.RELAY: [self.on_node_change],
            df.ROLLER_WIN: self.roller_win,
            df.NAME_STEP_K: name_step_k,
            df.TREE_COLOR: NodePanel.colors[0]
        }
        dna.any_group = Dog.loner_group(**e)
        this_node = self.first_node = dna.any_group.get_widget(de.NODE)

        this_node.connect(si.ADD_ITEM, self.on_add_item)
        this_node.connect(si.UPDATE_TREE, self.on_update_tree)
        Ring.plug(si.PANEL_CHANGE, self.panel_type)
        for row, k in enumerate(d.keys()):
            self._make_node_or_leaf(this_node, d, k, "", row, 1)

    def on_add_item(self, _, arg):
        """
        Add an item to the NodePanel via a custom NodePanel Signal.

        _: Node
            Sent the Signal.

        arg: tuple
            (dict, string)
            (tree_d, model_name)
        """
        # Delay change vote emission.
        The.load_count += 1

        tree_d, model_name = arg
        any_group = Helm.get_group(sk.STEPS)
        node = any_group.get_widget(de.NODE)
        label_list = node.get_label_list()

        # Is the adding-item a new Model or a Model/branch?
        if model_name in label_list:
            # Is an existing row, so its a Model/branch.
            r = label_list.index(model_name)

        else:
            # Its a new Model. Add to the end.
            r = node.get_row_count() - 1

        self._make_node_or_leaf(
            self.first_node, tree_d, model_name, sk.STEPS, r, 1
        )

        # End delay.
        The.load_count -= 1

    def on_node_change(self, g):
        """
        Respond when the selection changes in a Node item
        list. Is a signal handler for a TreeViewList.

        g: Node or TreeViewList
            Is responsible.
        """
        def _remove():
            """
            Remove option groups with two columns or more into
            the navigation box from the current column.
            """
            _column = len(self.cubby_q)
            _a = g.column + 2
            if _a < _column:
                # VBox, '_i'
                for _i in range(_a, _column):
                    # VBox, '_j'
                    for _j in self.cubby_q[_i].get_children():
                        self.cubby_q[_i].remove(_j)

        # the selected branch DNA, 'dna'
        dna = g.get_item_by_row(g.get_selected_r())

        # Prevent a critical error from a failed state.
        if dna:
            # A cubby is a parent GTK VBox with switchable children.
            cubby = self._get_cubby(g.column + 1)

            # Switch off.
            if not dna.is_node:
                _remove()

            # Switch off.
            for child in cubby.get_children():
                if child != dna.vbox:
                    cubby.remove(child)

            # Switch on.
            if not dna.vbox.parent:
                cubby.add(dna.vbox)

            dna.vbox.set_visible(1)
            dna.vbox.show_all()

            if not dna.is_node and dna.any_group.is_squish:
                # Squish Widgets from here for less flicker.
                hide_options(dna.any_group)

            if dna.is_node:
                self.on_node_change(dna.any_group.get_node())

            self.roller_win.resize()
            Ring.plug(si.UI_CHANGE, g)

    def on_update_tree(self, _, arg):
        """
        Respond to a navigation tree structure update signal.
        Remove item and Node from the tree that are no longer used. Add
        new item and Node to the tree from a new Model-name-step-key list.

        _: Node
            Sent the Signal.

        arg: tuple
            (new Model name step list, active Model dict)
            ([Model-name-step-key, ...], {model name: model type})
            Exclude shelved Model in the active Model dict.
        """
        # Delay change vote emission.
        The.load_count += 1

        new_step_list, model_d = arg
        old_step_list = Helm.get_all_step_list()
        remove_set = set(old_step_list) - set(new_step_list)
        remove_set -= sk.DEFAULT_NAME_STEP_KEYS

        for i in remove_set.copy():
            if _remove_non_node(i):
                remove_set -= {i}

        for i in remove_set:
            _remove_node(i)

        if new_step_list:
            self._grow_node_branch(
                self.first_node,
                create_steps_insert_d(new_step_list, model_d),
                sk.STEPS,
                sk.STEPS,
                0
            )

        _remove_empty_node()
        The.load_count -= 1
