#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (  # type: ignore
    CHANNEL_OP_REPLACE, CHANNEL_OP_SUBTRACT, gimp, pdb
)
from math import cos, radians, sin
from random import random
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_frame import emboss_selection, select_wrap
from roller_frame_alt import Overlap
from roller_gimp_image import add_layer
from roller_gimp_layer import select_layer
from roller_preset import combine_seed

# pi x 2, FULL_CIRCLE
FULL_CIRCLE = 6.283185307179586

# A lower increment value increases the wavelength.
INCREMENT = 1.5
HALF_INC = .5 * INCREMENT
QUART_INC = .25 * INCREMENT

gimp_stroke = gimp.VectorsBezierStroke

# fast look-up list
cos_q = []
sin_q = []

# Is the number of indices created by the INCREMENT value, '5'.
for a_ in range(int(INCREMENT + 1)):
    cos_q.append(cos(radians(a_)))
    sin_q.append(sin(radians(a_)))


def create_wobble_path(j, wobble_factor, active_vectors):
    """
    Adapt Tin Tran's 'wobble3d.py' GIMP plug-in.
    Create a wobble path from the active path.

    j: GIMP image
        WIP

    wobble_factor: float
        .0 to 1.
        Create greater wobble with a higher value.

    active_vectors: gimp.vectors
    """
    point_x = 50
    point_y = point_z = 0
    new_vectors = pdb.gimp_vectors_new(j, "3D wobble hand-scribble")
    temp_vectors = pdb.gimp_vectors_new(j, "Temp vectors for speed")
    remove_stroke = temp_vectors.remove_stroke
    pitch = random() * FULL_CIRCLE
    roll = random() * FULL_CIRCLE
    yaw = random() * FULL_CIRCLE
    stroke_x = stroke_y = current_stroke_count = 0
    is_valid = False

    for source_stroke in active_vectors.strokes:
        current_stroke_count += 1

        # precision, '.1'
        stroke_length = source_stroke.get_length(.1)

        source_point_q, is_closed = source_stroke.points
        distance = 0
        old_x = old_y = last_distance = -1

        # Count coordinate.
        start_i = 0

        # Store single distance.
        distance_q = []

        end_total_distance = []
        distance_up_to_now = 0
        stroke_point_count = len(source_point_q) / 6

        # Get the first short Stroke.
        fast_stroke = gimp_stroke(
            temp_vectors, source_point_q[start_i:start_i + 12], 0
        )
        start_i += 6

        # precision, '.1'
        this_distance = temp_vectors.strokes[0].get_length(.1)

        distance_q.append(this_distance)
        distance_up_to_now += this_distance
        end_total_distance.append(distance_up_to_now)
        current_index = 1
        current_stroke_index = 0
        current_short_stroke = fast_stroke
        get_point_at_dist = current_short_stroke.get_point_at_dist
        this_stroke_distance = 0
        stroke_point_q = []

        while distance < stroke_length:
            pitch += random() * HALF_INC-QUART_INC

            if pitch < -INCREMENT:
                pitch = -INCREMENT

            elif pitch > INCREMENT:
                pitch = INCREMENT

            roll += random() * HALF_INC - QUART_INC

            if roll < -INCREMENT:
                roll = -INCREMENT

            elif roll > INCREMENT:
                roll = INCREMENT

            yaw += random() * HALF_INC - QUART_INC

            if yaw < -INCREMENT:
                yaw = -INCREMENT

            elif yaw > INCREMENT:
                yaw = INCREMENT

            int_yaw = int(yaw)
            cosine1 = cos_q[int_yaw]
            sine1 = sin_q[int_yaw]
            int_pitch = int(pitch)
            cosine2 = cos_q[int_pitch]
            sine2 = sin_q[int_pitch]
            int_roll = int(roll)
            cosine3 = cos_q[int_roll]
            sine3 = sin_q[int_roll]
            x = point_x
            y = point_y
            z = point_z
            point_x = \
                cosine1 * cosine2 * x + \
                (cosine1 * sine2 * sine3 - sine1 * cosine3) * y + \
                (cosine1 * sine2 * cosine3 + sine1 * sine3) * z
            point_y = \
                sine1 * cosine2 * x + \
                (sine1 * sine2 * sine3 + cosine1 * cosine3) * y + \
                (sine1 * sine2 * cosine3 - cosine1 * sine3) * z
            point_z = \
                -sine2 * x + \
                cosine2 * sine3 * y + \
                cosine2 * cosine3 * z

            # Don't need to get points if it's within 1 pixel,
            # just let it use the previous point.
            if distance - last_distance > .999999:
                while distance > end_total_distance[current_stroke_index]:
                    if current_index < stroke_point_count - 1:
                        remove_stroke(fast_stroke)
                        fast_stroke = gimp_stroke(
                            temp_vectors,
                            source_point_q[start_i:start_i + 12],
                            0
                        )
                        start_i += 6

                        # precision, '.1'
                        this_distance = fast_stroke.get_length(.1)

                        distance_q.append(this_distance)
                        distance_up_to_now += this_distance
                        end_total_distance.append(distance_up_to_now)
                        current_index += 1

                    elif (
                        current_index == stroke_point_count - 1 and is_closed
                    ):
                        remove_stroke(fast_stroke)
                        fast_stroke = gimp_stroke(
                            temp_vectors,
                            source_point_q[start_i:start_i + 6] +
                            source_point_q[0:6],
                            0
                        )
                        start_i += 6

                        # precision, '.1'
                        this_distance = fast_stroke.get_length(.1)

                        distance_q.append(this_distance)
                        distance_up_to_now += this_distance
                        end_total_distance.append(distance_up_to_now)
                        current_index += 1

                    # Move to the next stroke.
                    current_stroke_index += 1
                    current_short_stroke = fast_stroke
                    get_point_at_dist = current_short_stroke.get_point_at_dist
                    this_stroke_distance = distance_q[current_stroke_index] - (
                        end_total_distance[current_stroke_index] - distance
                    )

                # slope, '_'; precision, '.1'
                stroke_x, stroke_y, _, is_valid = get_point_at_dist(
                    this_stroke_distance, .1
                )
                last_distance = distance

            x1 = stroke_x + point_x * wobble_factor
            y1 = stroke_y + point_y * wobble_factor

            # new distance-delta reach, '.99'
            if (abs(x1 - old_x) > .99 or abs(y1 - old_y) > .99) and is_valid:
                old_x = x1
                old_y = y1
                stroke_point_q.extend([x1, y1] * 3)

            distance_inc = random()
            distance += distance_inc
            this_stroke_distance += distance_inc

        if temp_vectors.strokes:
            remove_stroke(fast_stroke)

        # Add the points to the 'new_vectors' path.
        gimp_stroke(new_vectors, stroke_point_q, is_closed)
    pdb.gimp_image_insert_vectors(j, new_vectors, None, 0)


def do_matter(maya):
    """
    Make a frame around cast layer pixel.

    maya: Maya
    Return: layer or None
        Wrap frame
    """
    j = Run.j
    d = maya.value_d
    group = maya.group
    cast_z = maya.cast.matter

    # layer for the emboss, 'z'
    z = add_layer(j, group, maya.get_light(), "Material")

    combine_seed(d)
    select_wobble_frame(j, cast_z, d)

    if not pdb.gimp_selection_is_empty(j):
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_feather(.75)
        pdb.plug_in_sel2path(j, z)

        active_vectors = pdb.gimp_image_get_active_vectors(j)
        if active_vectors:
            create_wobble_path(j, d[de.WOBBLE_FACTOR], active_vectors)

            path = pdb.gimp_image_get_active_vectors(j)

            pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, path)

            while j.active_vectors:
                pdb.gimp_image_remove_vectors(j, j.active_vectors)

            if d[de.CLIP]:
                select_layer(cast_z, option=CHANNEL_OP_SUBTRACT)
            return emboss_selection(z, d)
    pdb.gimp_image_remove_layer(j, z)


def select_wobble_frame(j, z, d):
    """
    Make a frame selection. The frame width is divided into
    an expansion and contraction amount. The resulting
    selection overlaps the frame by the contraction amount.

    j: GIMP image
        Receive selection.

    z: layer
        Is the material that the frame surrounds. Refer to as 'cast'.

    d: dict
        Over Preset

    Return: selection or None
    """
    f = z.opacity
    z.opacity = 100.
    n = d[de.TYPE]

    select_wrap(j, z, d[de.WIDTH], n)
    z.opacity = f


class Wobble(Overlap):
    is_embossed = True
    kind = material = de.WOBBLE
    shade_row = rk.BRW
    wrap_k = de.WRAP_WO

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        Overlap.__init__(
            self, any_group, super_maya, k_path, do_matter
        )
