#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
import sys


class Id:
    """Create an unique integer identifier for an object."""
    # {long integer, ...}
    id_q = set()

    @staticmethod
    def make():
        """Create an id."""
        a = randint(-sys.maxint, sys.maxint)

        while a in Id.id_q:
            a = randint(-sys.maxint, sys.maxint)

        Id.id_q.add(a)
        return a
