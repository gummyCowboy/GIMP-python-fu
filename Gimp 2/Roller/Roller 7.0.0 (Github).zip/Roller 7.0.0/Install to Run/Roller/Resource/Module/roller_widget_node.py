#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant import (
    Color as co, Define as df, Node as nw, Signal as si, Step as sk
)
from roller_constant_identity import Identity as de
from roller_helm import Helm
from roller_ring import Ring
from roller_step import get_parts, prune_step_k
from roller_widget import set_widget_attr
from roller_widget_tree import TreeViewList, rename_item
import gtk      # type: ignore
import gobject  # type: ignore


def get_visibility(node):
    """
    Determine if a Node is in the selected navigation path.

    g: Node
        in question
    """
    def _get_dna(_k):
        # Node, '_g'
        _g = get_any_group(_k).get_node()
        _r = _g.get_selected_r()

        # Get DNA.
        return _g.get_item_by_row(0 if _r is None else _r)

    is_visible = True
    name_step_k = node.any_group.name_step_k

    # Steps is always visible.
    if name_step_k != sk.STEPS:
        if name_step_k == de.SHADOW:
            # The Shadow Node is always visible.
            return True

        # Get the selected item in the Steps Node.
        get_any_group = Helm.get_group
        type_ = _get_dna(sk.STEPS).type_
        parts = get_parts(name_step_k)
        part_count = len(parts)

        # Check each part in the key to see if it is selected.
        for i, n in enumerate(parts):
            if n != type_:
                # 'item' is selected. 'n' is not.
                is_visible = False
                break
            if i + 1 < part_count:
                type_ = _get_dna(prune_step_k(name_step_k, i + 1)).type_
    return is_visible


class Node(gtk.Alignment, gobject.GObject, object):
    """
    Is a list Widget of keyed type descriptor. A selected item
    displays a branch option group. A branch is either
    a Node or a leaf as in a Widget group. An item descriptor is part of
    a step-key and is unique, like a key, in the Node list context.
    """
    has_table_label = False

    # Are signals that can be emitted by this class.
    __gsignals__ = si.NODE_DICT

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        super(gtk.Alignment, self).__init__()

        # Enable custom signal.
        gobject.GObject.__init__(self)

        set_widget_attr(self, d)

        # Is set during a SuperPreset load, 'self._selected_row'.
        self._selected_row = None

        d[df.COLOR] = co.LIST_CELL_COLOR
        d[df.PADDING] = 2, 2, 4, 4

        # The HBox is needed for the expose event.
        # The Item VBox's exposure is erratic.
        self.hbox = gtk.HBox()

        self._tree = TreeViewList(**d)
        self.treeview = self._tree.treeview

        self.hbox.add(self._tree)
        self.add(self.hbox)

        # The TreeView cursor-changed signal will send a signal
        # when a row is clicked even if the row is already selected.
        self._tree.treeview.connect('cursor_changed', self.update_on_change)

        self._tree.treeview.get_selection().connect(
            'changed', self.update_on_change
        )
        self.connect(si.SELECT_ITEM, self.on_select_item)
        Ring.gob.connect(si.RING_CLEARED, self.on_ring_cleared)

    def copy_item_list(self):
        """
        Get a item list copy.

        Return: list
            [DNA, ...]
        """
        return self._tree.copy_item_list()

    @staticmethod
    def get_init_d(*_):
        """
        Provide a dict and a list for group initialization.

        Return: dict
            Use during object init.
        """
        return {de.NODE: {df.NO_VOTE: True, df.WIDGET: Node}}

    def get_dna_by_type(self, n):
        """
        Get a DNA instance from the Node's item list given its item descriptor.

        n: string
            Node item to match
            Is not the Group key, but its split version.

        Return: DNA or None
        """
        # DNA, 'i'
        for i in self._tree.item_list:
            if i.type_ == n:
                return i

    def get_item_by_row(self, r):
        return self._tree.get_item_by_row(r)

    def get_label_list(self):
        """
        Get a Item key list.

        Return: list
            [DNA type string, ...]
        """
        return [i.type_ for i in self._tree.item_list]

    def get_selected_r(self):
        """
        Fetch the selection row index for the TreeView.

        Return: int or None
            zero-based row number
        """
        r = self._tree.get_selected_r()
        return 0 if r is None else r

    def get_row_count(self):
        return len(self._tree.item_list)

    def get_ui(self):
        """
        Get a dict with the selected row of the Node.

        Return: dict
            {tuple: int}
            {SELECTED_ROW: selected row}
        """
        return {nw.SELECTED_ROW: self.get_selected_r()}

    def insert_r(self, r, dna):
        """
        Insert a row into the Node and its item list.

        r: int
            row index

        dna: DNA
            It's 'type_' attribute is used as label text.
        """
        list_store = self._tree.list_store

        # item descriptor index, '0'
        # Create the row.
        list_store.set_value(list_store.insert(r), 0, dna.type_)

        # Set the background color.
        list_store[r] = [dna.type_, '#000000', co.LIST_CELL_COLOR]

        # Update the easy access list.
        self._tree.item_list.insert(r, dna)

    def load_a(self, d):
        """
        Select a row. Save selected row in the AnyGroup.
        """
        e = self.set_ui(d)
        self.any_group.set_node_a(e)

    def on_ring_cleared(self, *_):
        """
        Select a Node item.

        _: tuple
            (Ring, None)
        """
        if self._selected_row is not None:
            if self._selected_row < len(self._tree.item_list):
                if get_visibility(self):
                    self.select_r(self._selected_row)
                else:
                    # Turn off 'on_node_change' in the 'relay' so
                    # that it won't get called to display the Node.
                    relay = self._tree.relay
                    self._tree.relay = []

                    self.select_r(self._selected_row)
                    self._tree.relay = relay
            self._selected_row = None

    def on_select_item(self, _, r):
        """
        Respond to a 'si.SELECT_ITEM'. Make Node
        selection if a Preset isn't loading.

        _: Sent the Signal.
        r: int
            row index
        """
        self._selected_row = r

    def rename_item(self, old_name, new_name):
        """
        Change the name of an item in the Node.

        old_name: string
            Replace with new name.

        new_name: string
            new item name
        """
        for r, dna in enumerate(self._tree.item_list):
            if dna.type_ == old_name:
                rename_item(self._tree, r, new_name)
                dna.key = dna.type_ = new_name

    def remove_item_by_type(self, n):
        """
        Remove an item from the list.

        n: string
            item text
        """
        for r, dna in enumerate(self._tree.item_list):
            if dna.type_ == n:
                self._tree.remove_row(r)
                break

    def repopulate(self, q):
        """
        Synchronize the order of a Node's branches with a list of strings.

        q: list
            Are Node branch names in the new order.
        """
        self._tree.reset()
        for r, dna in enumerate(q):
            self.insert_r(r, dna)

    def select_r(self, r):
        """
        Select an item in the Node based on its descriptor.

        r: int or None
            row index
        """
        if not isinstance(r, int):
            r = 0
        if r < len(self._tree.item_list):
            # Proceed on valid row.
            self._tree.select_r(r)

    def set_ui(self, d):
        """
        Get a dict with the selected row of the Node.

        d: dict
            {SELECTED_ROW: selected row}

        Return: dict
            {SELECTED_ROW: selected row}
        """
        r = d.get(nw.SELECTED_ROW, 0)

        self.select_r(r)
        return {nw.SELECTED_ROW, r}

    def sort_item_list(self, input_list):
        """
        Sort the order of a Node's item list.

        input_q: iterable
            [item text, ...] -> [DNA.type_, ...]
        """
        def _move():
            # Remove the existing DNA reference.
            # DNA, '_a'
            for _r, _a in enumerate(self._tree.item_list):
                if _a.type_ == n:
                    self._tree.remove_row(_r)
                    break

            # Re-insert the DNA reference.
            self.insert_r(r, d[n])

        # {type text: DNA}, 'd'
        d = OrderedDict()

        for a in self._tree.item_list:
            d[a.type_] = a

        keys = d.keys()

        # Ensure that the two lists synchronized.
        if len(input_list) == len(keys):
            for r, type_ in enumerate(keys):
                n = input_list[r]
                if type_ != n:
                    _move()

    def update_on_change(self, *_):
        """Update the option group with the change in selection."""
        self.any_group.set_node_a(self.get_ui())


# Register the custom signals.
gobject.type_register(Node)
