#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Maya import and export business
from roller_constant_identity import Identity as de
from roller_maya_accent import Accent
from roller_maya_border import Border
from roller_maya_caption import Caption
from roller_maya_fringe import Fringe
from roller_maya_global import Global
from roller_maya_light import Light
from roller_maya_image import Image
from roller_maya_line import Line
from roller_maya_model import Model
from roller_maya_margin import Margin
from roller_maya_plaque import Plaque
from roller_maya_property import Property
from roller_maya_rectangle import Rectangle
from roller_maya_shift import Shift
from roller_maya_background import Background
from roller_maya_type import Type

# Translate group key to Maya class.
# {option group key: AnyGroup}
CLASS_GROUP = {
    de.ACCENT: Accent,
    de.BACKGROUND: Background,
    de.BORDER: Border,
    de.CAPTION: Caption,
    de.FRINGE: Fringe,
    de.GLOBAL: Global,
    de.IMAGE: Image,
    de.LINE: Line,
    de.LIGHT: Light,
    de.MARGIN: Margin,
    de.MODEL: Model,
    de.PLAQUE: Plaque,
    de.PROPERTY: Property,
    de.RECTANGLE: Rectangle,
    de.SHIFT: Shift,
    de.TYPE_BOX: Type,
    de.TYPE_CELL: Type,
    de.TYPE_PYRAMID: Type,
    de.TYPE_SIDEWALK: Type,
    de.TYPE_STACK: Type,
    de.TYPE_TABLE: Type
}
