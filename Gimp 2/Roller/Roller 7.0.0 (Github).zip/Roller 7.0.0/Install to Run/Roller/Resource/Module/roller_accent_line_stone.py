#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_EXCLUSION,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_HARD_MIX,
    LAYER_MODE_HSV_VALUE,
    LAYER_MODE_LCH_LIGHTNESS,
    LAYER_MODE_NORMAL,
    LAYER_MODE_OVERLAY,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gegl import color_to_grey, edge, emboss, unsharp_mask
from roller_gimp_image import insert_copy_above, make_group_layer
from roller_gimp_layer import blur_selection, clone_layer, dilate, do_curves
from roller_maya_sub_accent import SubAccent
from roller_preset import combine_seed
from roller_wip import Wip

STEP = "Line Stone Step {} of 5"


def do_matter(maya):
    """
    Make a matter layer for LineStone.

    maya: LineStone
    Return: layer
        'matter'
    """
    def _do_step_one():
        """
        Process in multiple phases.

        Return: layer
            work-in-progress
        """
        _z = clone_layer(z)
        _group = make_group_layer(
            j, group, maya.get_light(), STEP.format(1), z=_z
        )
        _z = clone_layer(_z, n="HSV Value")
        _z.mode = LAYER_MODE_HSV_VALUE

        edge(_z)

        # no linear, '0'
        pdb.gimp_drawable_invert(_z, 0)

        _z = clone_layer(_z, n="LCH Lightness")
        _z.mode = LAYER_MODE_LCH_LIGHTNESS
        _z.opacity = 25.
        _z = clone_layer(_z, n="Hard Mix")
        _z.mode = LAYER_MODE_HARD_MIX
        _z.opacity = 20.
        return pdb.gimp_image_merge_layer_group(j, _group)

    def _do_step_two():
        """
        Process in multiple phases.

        Return: layer
            work-in-progress
        """
        _z = clone_layer(z, n="Erode")
        _group = make_group_layer(j, group, 0, STEP.format(2), z=_z)

        dilate(_z)
        pdb.plug_in_erode(
            j, _z,
            1,                  # propagate black
            7,                  # RGB channels
            1.,                 # full rate
            0,                  # direction mask
            0,                  # lower limit
            255                 # upper limit
        )
        return pdb.gimp_image_merge_layer_group(j, _group)

    def _do_step_three():
        """
        Process in multiple phases.

        Return: layer
            work-in-progress
        """
        _z = clone_layer(z)
        _group = make_group_layer(j, group, 0, STEP.format(3), z=_z)

        blur_selection(_z, 8)
        pdb.plug_in_despeckle(
            j, _z,
            4,
            3,                  # recursive adaptive
            248,                # white cut-off
            7                   # black cut-off
        )
        dilate(_z)

        _z = clone_layer(_z, n="HSV Value")
        _z.mode = LAYER_MODE_HSV_VALUE

        dilate(_z)
        return pdb.gimp_image_merge_layer_group(j, _group)

    def _do_step_four():
        """
        Process in multiple phases.

        Return: layer
            work-in-progress
        """
        _z = clone_layer(z, n="Clouds")
        _group = make_group_layer(j, group, 0, STEP.format(4), z=_z)

        # The foggify output is on a layer with zero offset.
        pdb.python_fu_foggify(j, _z, "Clouds 2", (127, 127, 127), 3., 100.)
        _z1 = j.active_layer
        _x, _y, _w, _h = map(int, Wip.get_rect())
        pdb.gimp_layer_set_offsets(_z1, _x, _y)
        pdb.gimp_layer_resize(_z1, _w, _h, 0, 0)        # offset x, y: '0'
        return pdb.gimp_image_merge_layer_group(j, _group)

    def _do_step_five(_z):
        """
        Process in multiple phases.

        _z: layer
            work-in-progress

        Return: layer
            Is matter layer.
        """
        _group = make_group_layer(
            j, maya.group, maya.get_light(), "WIP", z=_z
        )
        _z = _z1 = clone_layer(_z, n="Overlay #1")
        _z.mode = LAYER_MODE_OVERLAY
        _z.opacity = 100.

        pdb.plug_in_hsv_noise(
            j, _z,
            1,                  # minimum holdness (1 through 8)
            20,                 # hue-distance angle (0 through 180)
            20,                 # saturation-distance (0 through 255)
            20                  # value-distance (0 through 255)
        )
        emboss(_z, 45., 15., 3)
        do_curves(_z, (.0, .3921, 1., .6078))

        _z = clone_bg_z
        _z.mode = LAYER_MODE_OVERLAY
        _z.opacity = 100.

        pdb.gimp_image_reorder_item(j, _z, _group, 1)
        do_curves(_z, (.0, 1., 1., .5))

        _z = clone_layer(_z, n="Difference")
        _z.mode = LAYER_MODE_DIFFERENCE
        _z.opacity = 50.
        _z = clone_layer(_z, n="Exclusion")
        _z.mode = LAYER_MODE_EXCLUSION
        _z.opacity = 25.

        color_to_grey(_z)

        _z1.opacity = 50.
        _z = pdb.gimp_image_merge_layer_group(j, _group)
        unsharp_mask(_z, 5., 1.5, .3)
        return _z

    j = Run.j
    d = maya.value_d

    combine_seed(d)

    parent, group = maya.init_background_groups(j)
    z = maya.bg_z
    maya.bg_z = None
    clone_bg_z = clone_layer(z)
    pdb.gimp_image_reorder_item(j, clone_bg_z, maya.group, 0)

    z = z1 = _do_step_one()
    z = _do_step_two()
    z.mode = LAYER_MODE_GRAIN_EXTRACT
    z2 = insert_copy_above(z, parent.layers[0])
    z.mode = LAYER_MODE_NORMAL
    z = z2
    z.mode = LAYER_MODE_HARD_MIX
    z = insert_copy_above(z, parent.layers[0])
    z.mode = LAYER_MODE_HSV_VALUE

    j.remove_layer(z1)
    j.remove_layer(z2)

    z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
    z = _do_step_three()
    z = _do_step_four()
    z.mode = LAYER_MODE_LCH_LIGHTNESS
    z = pdb.gimp_image_merge_layer_group(j, group)
    z = _do_step_five(pdb.gimp_image_merge_layer_group(j, parent))
    return maya.finish(z, d[rk.BRW])


class LineStone(SubAccent):
    """Create Accent output."""
    kind = de.LINE_STONE

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, True, is_old)
