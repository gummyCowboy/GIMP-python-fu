#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_accent_acrylic_sky import AcrylicSky
from roller_accent_back_game import BackGame
from roller_accent_clay_chemistry import ClayChemistry
from roller_accent_color_fill import ColorFill
from roller_accent_corner_overlap import CornerOverlap
from roller_accent_crystal_cave import CrystalCave
from roller_accent_cube_pattern import CubePattern
from roller_accent_cubism_cover import CubismCover
from roller_accent_dark_fort import DarkFort
from roller_accent_density_gradient import DensityGradient
from roller_accent_drop_zone import DropZone
from roller_accent_etch_sketch import EtchSketch
from roller_accent_fading_maze import FadingMaze
from roller_accent_floor_sample import FloorSample
from roller_accent_color_grid import ColorGrid
from roller_accent_galactic_field import GalacticField
from roller_accent_glass_gaw import GlassGaw
from roller_accent_gradient_fill import GradientFill
from roller_accent_historic_trip import HistoricTrip
from roller_accent_line_stone import LineStone
from roller_accent_lost_maze import LostMaze
from roller_accent_maze_blend import MazeBlend
from roller_accent_mean_color import MeanColor
from roller_accent_grate_mystery import GrateMystery
from roller_accent_noise_rift import NoiseRift
from roller_accent_paper_waste import PaperWaste
from roller_accent_pattern_fill import PatternFill
from roller_accent_rainbow_valley import RainbowValley
from roller_accent_rect_pattern import RectPattern
from roller_accent_rocky_landing import RockyLanding
from roller_accent_roof_top import RoofTop
from roller_accent_soft_touch import SoftTouch
from roller_accent_specimen_speckle import SpecimenSpeckle
from roller_accent_spiral_channel import SpiralChannel
from roller_accent_square_cloud import SquareCloud
from roller_accent_stone_age import StoneAge
from roller_accent_trail_vine import TrailVine
from roller_accent_triangle_reverb import TriangleReverb
from roller_accent_wave_fill import WaveFill
from roller_constant_identity import Identity as de
from roller_frame_basic import Basic
from roller_frame_bevel import Bevel
from roller_frame_brushy import Brushy
from roller_frame_burst import Burst
from roller_frame_camo import Camo
from roller_frame_ceramic import Ceramic
from roller_frame_checker import Checker
from roller_frame_maze import Maze
from roller_frame_clear import Clear
from roller_frame_crumble import Crumble
from roller_frame_decay import Decay
from roller_frame_fence import Fence
from roller_frame_glue import Glue
from roller_frame_gradual import Gradual
from roller_frame_holey import Holey
from roller_frame_joint import Joint
from roller_frame_mecha import Mecha
from roller_frame_mirror import Mirror
from roller_frame_net import Net
from roller_frame_over import Over
from roller_frame_overlap import Overlap
from roller_frame_pipe import Pipe
from roller_frame_rad import Rad
from roller_frame_stained import Stained
from roller_frame_stretch import Stretch
from roller_frame_stripe import Stripe
from roller_frame_tape import Tape
from roller_frame_wobble import Wobble

# Find an OptionList choice's class.
# {Frame key: Frame Maya}
CLASS_FRAME = {
    de.BASIC: Basic,
    de.BEVEL: Bevel,
    de.BRUSHY: Brushy,
    de.BURST: Burst,
    de.CAMO: Camo,
    de.CERAMIC: Ceramic,
    de.CHECKER: Checker,
    de.MAZE: Maze,
    de.CLEAR: Clear,
    de.CRUMBLE: Crumble,
    de.DECAY: Decay,
    de.GRADUAL: Gradual,
    de.GLUE: Glue,
    de.HOLEY: Holey,
    de.JOINT: Joint,
    de.MIRROR: Mirror,
    de.NET: Net,
    de.OVER: Over,
    de.PIPE: Pipe,
    de.RAD: Rad,
    de.MECHA: Mecha,
    de.OVERLAP: Overlap,
    de.STAINED: Stained,
    de.WOBBLE: Wobble,
    de.STRETCH: Stretch,
    de.STRIPE: Stripe,
    de.TAPE: Tape,
    de.FENCE: Fence
}

# {Accent key: Maya}
CLASS_ACCENT = {
    de.ACRYLIC_SKY: AcrylicSky,
    de.BACK_GAME: BackGame,
    de.CLAY_CHEMISTRY: ClayChemistry,
    de.COLOR_FILL: ColorFill,
    de.COLOR_GRID: ColorGrid,
    de.CORNER_OVERLAP: CornerOverlap,
    de.CRYSTAL_CAVE: CrystalCave,
    de.CUBE_PATTERN: CubePattern,
    de.CUBISM_COVER: CubismCover,
    de.DARK_FORT: DarkFort,
    de.DENSITY_GRADIENT: DensityGradient,
    de.DROP_ZONE: DropZone,
    de.ETCH_SKETCH: EtchSketch,
    de.FADING_MAZE: FadingMaze,
    de.FLOOR_SAMPLE: FloorSample,
    de.GALACTIC_FIELD: GalacticField,
    de.GLASS_GAW: GlassGaw,
    de.GRADIENT_FILL: GradientFill,
    de.HISTORIC_TRIP: HistoricTrip,
    de.LINE_STONE: LineStone,
    de.LOST_MAZE: LostMaze,
    de.MAZE_BLEND: MazeBlend,
    de.MEAN_COLOR: MeanColor,
    de.GRATE_MYSTERY: GrateMystery,
    de.NOISE_RIFT: NoiseRift,
    de.PAPER_WASTE: PaperWaste,
    de.PATTERN_FILL: PatternFill,
    de.RAINBOW_VALLEY: RainbowValley,
    de.RECT_PATTERN: RectPattern,
    de.ROCKY_LANDING: RockyLanding,
    de.ROOF_TOP: RoofTop,
    de.SOFT_TOUCH: SoftTouch,
    de.SPECIMEN_SPECKLE: SpecimenSpeckle,
    de.SPIRAL_CHANNEL: SpiralChannel,
    de.SQUARE_CLOUD: SquareCloud,
    de.STONE_AGE: StoneAge,
    de.TRAIL_VINE: TrailVine,
    de.TRIANGLE_REVERB: TriangleReverb,
    de.WAVE_FILL: WaveFill
}
