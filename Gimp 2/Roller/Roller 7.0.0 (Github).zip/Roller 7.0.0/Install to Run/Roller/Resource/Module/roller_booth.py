#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gobject  # type: ignore
from roller_constant import Signal as si
from roller_ring import Ring


class Booth(gobject.GObject, object):
    """
    Accept AnyGroup vote. Call from Ring when the interface
    is idle and after a Preset has finished loading.
    """
    # Reference
    #   github.com/sebp/PyGObject-Tutorial/blob/master/source/objects.txt
    #   library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
    #   zetcode.com/gui/pygtk/signals/
    #   stackoverflow.com/questions/66730/how-do-i-create-a-new-signal-in-pygtk

    # Are custom signal that can be emitted by this class.
    __gsignals__ = si.BOOTH_DICT

    def __init__(self):
        # for custom signal
        gobject.GObject.__init__(self)

        # {int: int} of cast
        self.signal_d = {}

        Ring.carry(self)

    def cast(self, i):
        """
        Add a Model signal.

        i: int
            plan or work; view-type index; 0 or 1
        """
        self.signal_d[i] = None

    def pressure(self):
        """Send signal until the signal dict is clear."""
        while self.signal_d:
            i = self.signal_d.keys()[0]
            self.signal_d.pop(i)
            self.emit(si.VOTE_CHANGE, i)

    def turn(self):
        """Send out a Signal."""
        for i in self.signal_d.keys():
            self.signal_d.pop(i)
            self.emit(si.VOTE_CHANGE, i)
            break
