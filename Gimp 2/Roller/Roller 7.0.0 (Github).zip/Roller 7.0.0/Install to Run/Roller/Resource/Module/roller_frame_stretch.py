#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD,
    CHANNEL_OP_INTERSECT,
    CHANNEL_OP_SUBTRACT,
    CLIP_TO_IMAGE,
    HISTOGRAM_VALUE,
    LAYER_MODE_HARDLIGHT,
    pdb
)
from roller_constant import Frame as ek, Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_frame import (
    expand_wrap,
    emboss_selection,
    make_filler_frame_sc,
    remove_sc,
    sort_shadow_layer
)
from roller_frame_alt import AltFiller
from roller_gegl import emboss
from roller_gimp_image import (
    add_layer, add_wip_below, check_matter, make_group_layer, make_group_wrap
)
from roller_gimp_layer import (
    apply_mask,
    clone_layer,
    clone_opaque_layer,
    remove_layer,
    select_layer,
    set_layer_attr
)
from roller_gimp_mode import translate_mode
from roller_gimp_selection import select_channel
from roller_maya_add import AltAdd
from roller_maya_build import Build, SubBuild
from roller_maya_bulb import Bulb
from roller_maya_layer import check_mix_basic
from roller_maya_shadow import Shadow
from roller_preset_mod import do_mod


def do_matter(maya):
    """
    Make a frame.

    maya: StretchWrap
    Return: layer
        raw Stretch Wrap 'matter'
    """
    j = Run.j

    for n in ('filler_sc', 'wrap_sc'):
        remove_sc(maya, n)

    maya.filler_sc = make_filler_frame_sc(j, maya.cast.matter, maya.value_d)
    maya.wrap_sc = pdb.gimp_selection_save(j) \
        if not pdb.gimp_selection_is_empty(j) else None
    return add_layer(j, maya.group, maya.get_light(), "Material")


def do_filler(maya):
    """
    Draw Filler material.

    maya: AltFiller
    Return: layer
        Stretch Filler 'matter'
    """
    j = Run.j
    d = maya.value_d

    # source layer, 'z'
    z = clone_opaque_layer(maya.cast.matter, n="Left")

    add_wip_below(z, "Filler")

    z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
    group = make_group_layer(
        j, maya.group, maya.get_light(), "Material", z=z,
    )

    apply_mask(z)
    pdb.gimp_selection_none(j)

    for i, z in enumerate((
        z,
        clone_layer(z, n="Right"),
        clone_layer(z, n="Top"),
        clone_layer(z, n="Bottom")
    )):
        pdb.plug_in_wind(
            j, z,
            .0,                 # Threshold All
            i,                  # direction
            100,                # maximum strength
            0,                  # wind algorithm
            1,                  # leading edge
        )

        # threshold all pixel, '.0'
        pdb.plug_in_threshold_alpha(j, z, .0)

    # Make the wind output opaque.
    z = pdb.gimp_image_merge_layer_group(j, group)
    z1 = clone_opaque_layer(z)

    pdb.gimp_image_remove_layer(j, z)
    pdb.gimp_drawable_curves_spline(
        z1,
        HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .25, 1., .75)
    )

    z2 = clone_layer(z1, n="Hard Light")
    z2.mode = LAYER_MODE_HARDLIGHT
    z2.opacity = 80.

    pdb.gimp_drawable_curves_spline(
        z2,
        HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .45, 1., .54)
    )

    # depth, '3'
    emboss(z2, Globe.azimuth, Globe.elevation, 3)

    z = pdb.gimp_image_merge_down(j, z2, CLIP_TO_IMAGE)
    z.name = z.parent.name + " Material"

    do_mod(z, d[rk.BRW][de.MOD])
    return z


def make_stretch_frame_sel(d, z, cast_z, wrap_sc, filler_sc):
    """
    Make a Filler area selection.

    d: dict
        Wrap, Fill Preset

    z: layer
        Filler output

    wrap_sc: GIMP selection channel
        Define initial wrap.

    filler_sc: GIMP selection channel
        Limit filler area.

    Return: GIMP state of selection
    """
    j = Run.j
    w = d[de.WIDTH]

    if w:
        select_channel(j, filler_sc)
        select_layer(z, option=CHANNEL_OP_INTERSECT)
        expand_wrap(
            j, z, w,
            de.ANGULAR if d[de.TYPE] == de.RECTANGLE else d[de.TYPE]
        )
        select_layer(z, option=CHANNEL_OP_SUBTRACT)
        select_layer(cast_z, option=CHANNEL_OP_SUBTRACT)
        select_channel(j, wrap_sc, option=CHANNEL_OP_ADD)
    else:
        pdb.gimp_selection_none(j)


class StretchWrap(SubBuild):
    filler_k = de.FILLER_S2
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )
    wrap_k = de.WRAP_FI

    def __init__(self, any_group, super_maya, k_path):
        """
        super_maya: Maya
            Frame type

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        # In its cast-Maya, Shadow/Inner looks for 'is_inward'.
        self.is_inward = self.was_inward = self.is_inward_change = False

        k_path = k_path + (rk.BRW, de.WRAP_FI)

        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (de.EMBOSS,)],
            do_matter
        )

        self.filler_sc = self.wrap_sc = None
        self.matter_changed = False
        self.sub_maya[sm.ADD] = AltAdd(any_group, self, k_path + (de.ADD_ALT,))
        self.sub_maya[sm.BULB] = Bulb(any_group, self, de.STRETCH)

    def do(self, d, is_change, is_back):
        """
        Produce layer output.

        d: dict
            Wrap Preset

        is_change: bool
            Is True if the cast Maya has change.

        is_back: bool
            Is True if the background changed.
        """
        self.value_d = d
        m = self.matter_changed = self.is_matter = self.is_matter or is_change
        self.was_inward = self.is_inward
        self.is_inward = d.get(de.TYPE) in ek.INWARD_SET
        self.is_inward_change = m and (self.is_inward or self.was_inward)

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(d[de.ADD_ALT], m, m, is_back)

        else:
            self.die()
        self.reset_issue()

    def reset(self):
        """Call when the view image is removed."""
        for i in (self.filler_sc, self.wrap_sc):
            if i:
                pdb.gimp_image_remove_channel(Run.j, i)

        self.filler_sc = self.wrap_sc = None
        super(StretchWrap, self).reset()


class Stretch(Build):
    filler_k = de.FILLER_S2
    put = issue_q = ()
    kind = material = de.STRETCH
    shade_row = rk.BRW
    wrap_k = de.WRAP_FI

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        Build.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.WRAP] = StretchWrap(any_group, self, k_path)
        self.sub_maya[sm.FILLER] = AltFiller(
            any_group, self, k_path, do_filler
        )
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group,
            self,
            (self.cast, self.sub_maya[sm.WRAP], self.sub_maya[sm.FILLER]),
            k_path + (rk.BRW, de.SHADOW)
        )

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        m: bool
            Is the state of the super-maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        shadow = self.sub_maya[sm.SHADOW]
        wrap = self.sub_maya[sm.WRAP]
        wrap_d = d[rk.BRW][de.WRAP_FI]
        filler = self.sub_maya[sm.FILLER]

        wrap.do(wrap_d, is_change, is_back)
        filler.do(
            d[rk.BRW][self.filler_k],
            is_change,
            wrap.matter_changed,
            is_back,
            wrap.filler_sc
        )

        if wrap.matter_changed:
            make_stretch_frame_sel(
                wrap_d,
                filler.matter,
                self.cast.matter,
                wrap.wrap_sc,
                wrap.filler_sc
            )

            if pdb.gimp_selection_is_empty(Run.j):
                remove_layer(wrap.matter)
                wrap.matter = None

            else:
                wrap.matter = emboss_selection(wrap.matter, wrap_d)
                set_layer_attr(
                    wrap.matter,
                    translate_mode(wrap_d[de.MODE]),
                    wrap_d[de.OPACITY]
                )

        if wrap.filler_sc:
            m = shadow.do(
                d[rk.BRW][de.SHADOW],
                is_change or wrap.is_inward_change,
                wrap.matter_changed,
                wrap.group
            )
            sort_shadow_layer(self, m, wrap.get_light(), wrap.matter)
            wrap.sub_maya[sm.BULB].do(wrap.matter_changed)

        else:
            self.die()
        self.reset_issue()
