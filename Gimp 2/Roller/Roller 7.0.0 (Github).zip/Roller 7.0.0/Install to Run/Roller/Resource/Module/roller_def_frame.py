#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import Define as df, Row as rk
from roller_constant_identity import Identity as de
from roller_def_dialog import (
    ADD,
    BELOW,
    BRUSH_D1,
    FILLER_CE,
    FILLER_CH,
    FILLER_FE,
    FILLER_HO,
    FILLER_ME,
    FILLER_MI,
    FILLER_MA,
    FILLER_RA,
    FILLER_S1,
    FILLER_S2,
    FILLER_S3,
    OVERLAY_CA,
    OVERLAY_BE,
    OVERLAY_OV,
    SHADOW,
    STENCIL,
    WRAP_AB,
    WRAP_AL,
    WRAP_BE,
    WRAP_BU,
    WRAP_CA,
    WRAP_CL,
    WRAP_CR,
    WRAP_DE,
    WRAP_FI,
    WRAP_GL,
    WRAP_GR,
    WRAP_JO,
    WRAP_NT,
    WRAP_OL,
    WRAP_PA,
    WRAP_PI,
    WRAP_TA,
    WRAP_WO
)
from roller_widget_row import WidgetRow

"""Define Frame type Preset."""

# Bevel________________________________________________________________________
BEVEL = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_BE, deepcopy(WRAP_BE)),
            (de.OVERLAY_BE, OVERLAY_BE)
        ]),
        df.WIDGET: WidgetRow
    }),
    (rk.RW1, {
        df.SUB: OrderedDict([
            (de.SHADOW, deepcopy(SHADOW)),
            (de.BELOW, deepcopy(BELOW))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Brushy_______________________________________________________________________
BRUSHY = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_AL, deepcopy(WRAP_AL)),
            (de.BRUSH_D1, deepcopy(BRUSH_D1)),
            (de.SHADOW, deepcopy(SHADOW))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Burst________________________________________________________________________
BURST = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_BU, deepcopy(WRAP_BU)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Camo_________________________________________________________________________
CAMO = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_AB, deepcopy(WRAP_AB)),
            (de.OVERLAY_CA, OVERLAY_CA)
        ]),
        df.WIDGET: WidgetRow
    }),
    (rk.RW1, {
        df.SUB: OrderedDict([
            (de.SHADOW, deepcopy(SHADOW)),
            (de.BELOW, deepcopy(BELOW))
        ]),
        df.WIDGET: WidgetRow
    })
])
CAMO[rk.BRW][df.SUB][de.WRAP_AB][df.SUB][de.WIDTH][df.VALUE] = 30.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Ceramic______________________________________________________________________
CERAMIC = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_FI, deepcopy(WRAP_FI)),
            (de.FILLER_CE, FILLER_CE),
            (de.SHADOW, deepcopy(SHADOW))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Checker______________________________________________________________________
CHECKER = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_PA, deepcopy(WRAP_PA)),
            (de.FILLER_CH, FILLER_CH),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Clear________________________________________________________________________
CLEAR = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_CL, deepcopy(WRAP_CL)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Crumble______________________________________________________________________
CRUMBLE = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_CR, deepcopy(WRAP_CR)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Decay________________________________________________________________________
DECAY = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_DE, deepcopy(WRAP_DE)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Fence___________________________________________________________________
FENCE = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_PA, deepcopy(WRAP_PA)),
            (de.FILLER_FE, FILLER_FE),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Glue_________________________________________________________________________
GLUE = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_GL, deepcopy(WRAP_GL)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Gradual______________________________________________________________________
GRADUAL = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_GR, deepcopy(WRAP_GR)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Holey________________________________________________________________________
HOLEY = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_PA, deepcopy(WRAP_PA)),
            (de.FILLER_HO, FILLER_HO),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Joint________________________________________________________________________
JOINT = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_JO, deepcopy(WRAP_JO)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Maze_________________________________________________________________________
MAZE = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_CA, deepcopy(WRAP_CA)),
            (de.FILLER_MA, FILLER_MA),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Mecha________________________________________________________________________
MECHA = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_PA, deepcopy(WRAP_PA)),
            (de.FILLER_ME, FILLER_ME),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Mirror_______________________________________________________________________
MIRROR = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_CA, deepcopy(WRAP_CA)),
            (de.FILLER_MI, FILLER_MI),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Net__________________________________________________________________________
NET = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_NT, deepcopy(WRAP_NT)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Over_________________________________________________________________________
OVER = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.STENCIL, deepcopy(STENCIL)),
            (de.OVERLAY_OV, OVERLAY_OV),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Overlap______________________________________________________________________
OVERLAP = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_OL, deepcopy(WRAP_OL)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Pipe_________________________________________________________________________
PIPE = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_PI, deepcopy(WRAP_PI)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Rad__________________________________________________________________________
RAD = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_CA, deepcopy(WRAP_CA)),
            (de.FILLER_RA, FILLER_RA),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Stained______________________________________________________________________
STAINED = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_FI, deepcopy(WRAP_FI)),
            (de.FILLER_S1, FILLER_S1),
            (de.SHADOW, deepcopy(SHADOW))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Stretch______________________________________________________________________
STRETCH = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_FI, deepcopy(WRAP_FI)),
            (de.FILLER_S2, FILLER_S2),
            (de.SHADOW, deepcopy(SHADOW))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Stripe_______________________________________________________________________
STRIPE = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_PA, deepcopy(WRAP_PA)),
            (de.FILLER_S3, FILLER_S3),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Tape_________________________________________________________________________
TAPE = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_TA, deepcopy(WRAP_TA)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])

# Customize the Add Preset.
a = TAPE[rk.BRW][df.SUB][de.ADD][df.SUB]
a[de.SWITCH][df.VALUE] = 1
a1 = a[de.COLOR][df.SUB]
a1[de.SWITCH][df.VALUE] = 1
a1[de.COLOR_1][df.VALUE] = 230, 220, 210
a1[de.OPACITY][df.VALUE] = 16.
a1[de.MODE][df.VALUE] = "Normal"
a1 = a[rk.BRW][df.SUB][de.SHADOW][df.SUB]
a1[de.SHADOW_SWITCH][de.SWITCH][df.VALUE] = 1

# Shadow 1 and Inner Shadow
a2 = a1[de.SHADOW_1]
a3 = a1[de.INNER_SHADOW]
a2[de.SWITCH][df.VALUE] = a3[de.SWITCH][df.VALUE] = 1
a2[de.INTENSITY][df.VALUE] = a3[de.INTENSITY][df.VALUE] = 50.
a2[de.BLUR][df.VALUE] = a3[de.BLUR][df.VALUE] = 3.
a2[de.BLUR][df.RANDOM_Q] = a3[de.BLUR][df.RANDOM_Q] = 2., 10.

# Below
a1 = a[rk.BRW][df.SUB][de.BELOW][df.SUB]
a1[de.SWITCH][df.VALUE] = 1

# Below/Mod
a1 = a1[de.MOD][df.SUB]
a1[de.SWITCH][df.VALUE] = 1

# Mod/Blur
a1 = a1[de.BLUR_D][df.SUB]
a1[de.SWITCH][df.VALUE] = 1

# Change value and random limit.
for i in (de.SIZE_X, de.SIZE_Y):
    a1[i].update({df.VALUE: 3., df.RANDOM_Q: (1., 6.)})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wobble_______________________________________________________________________
WOBBLE = OrderedDict([
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.WRAP_WO, deepcopy(WRAP_WO)),
            (de.ADD, deepcopy(ADD))
        ]),
        df.WIDGET: WidgetRow
    })
])
