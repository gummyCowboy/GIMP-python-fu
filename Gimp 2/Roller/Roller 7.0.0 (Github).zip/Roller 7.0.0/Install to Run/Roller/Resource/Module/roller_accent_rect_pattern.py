#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from random import randint
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import add_layer, create_image, image_copy_all
from roller_gimp_layer import clipboard_fill_arg, color_selection
from roller_gimp_selection import select_rect
from roller_maya_sub_accent import SubAccent
from roller_polygon import make_coord_list
from roller_preset import combine_seed, do_rotated_layer


def make_pattern(d):
    """
    Make a rectangle pattern. The pattern is made-to-order and
    is then transferred to the canvas via the clipboard.

    d: dict
        Rectangle Pattern Preset
        {Identity: value}

    Return: image in the clipboard
        Is the pattern.
    """
    q_x1 = []

    set_fill_context_default()

    # pattern size
    width, height = d[de.WIDTH], d[de.HEIGHT]

    # Make a hidden image to draw the pattern on, 'j'.
    j = create_image(int(width), int(height))
    z = add_layer(j, None, 0, "Pattern")

    row = column = int(d[de.COLOR_COUNT])

    # Calculate the size of the rectangle, 'w, h'.
    # Use the rectangle to make selections for color fill.
    w, h = width / row, height / row

    is_brick = d[de.COLOR_GRID_TYPE]
    is_random = d[de.RANDOM_ORDER]

    # x-intersect list, 'q_x'
    # for both checkerboard and brick
    q_x = []
    x = y = 0
    column1 = column + 4

    for i in range(1, column1):
        q_x.append(round(x))
        x += w

    if is_brick:
        # x-intersect array for brick odd rows, 'q_x1'
        q_x1 = [.0]
        x = w / 2.
        for i in range(1, column1):
            q_x1.append(round(x))
            x += w

    # y-intersect array, 'q_y'
    q_y = make_coord_list(height, row + 1, y, span=h)

    for r in range(row):
        if is_brick and r % 2:
            # Need an extra column for the half-cut bricks.
            brick = column + 1

        else:
            brick = column
        for c in range(brick):
            if is_random:
                # Get a random color from the color options.
                color = d[de.COLOR_6A][randint(0, row - 1)]

            else:
                # Get the next color in the wrap-around color scheme.
                index = r * row + r + c

                while index >= row:
                    index -= row
                color = d[de.COLOR_6A][index]

            if is_brick and r % 2:
                x = q_x1[c]
                w = q_x1[c + 1] - x

            else:
                x = q_x[c]
                w = q_x[c + 1] - x

            y = q_y[r]
            h = q_y[r + 1] - q_y[r]

            # Select and fill the calculated rectangle.
            select_rect(j, x, y, w, h)
            color_selection(z, color)

    # Set the Clipboard Image for the pattern fill op.
    image_copy_all(j)

    # Close the tile image as the pattern is done.
    pdb.gimp_image_delete(j)


def do_matter(maya):
    """
    Make a matter layer.

    maya: RectanglePattern
    Return: layer
        'matter'
    """
    d = maya.value_d

    set_fill_context_default()
    combine_seed(d)
    make_pattern(d)
    return maya.finish(
        do_rotated_layer(d, clipboard_fill_arg, maya.group, 0), d[rk.BRW]
    )


class RectPattern(SubAccent):
    """Create Accent output."""
    kind = de.RECT_PATTERN

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, False, is_old)
