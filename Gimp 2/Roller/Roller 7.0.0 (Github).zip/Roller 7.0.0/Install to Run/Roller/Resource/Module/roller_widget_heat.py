#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import (
    Color as co, Define as df, Material as ma, Signal as si
)
from roller_constant_identity import Identity as de
from roller_def_access import get_default_d
from roller_def_option import MODE, OPACITY
from roller_port_choice import PortChoice
from roller_port_remove import PortRemove
from roller_step import get_type_text
from roller_widget import set_widget_attr
from roller_widget_box import Eventful
from roller_widget_button import (
    MakeMaterialButton, ProcessButton, RemoveButton
)
from roller_widget_combo import ComboBox
from roller_widget_label import Label
from roller_widget_preset import Preset
from roller_widget_row import WidgetRow
from roller_widget_slider import RandomSlider
from roller_widget_table import get_darker_color
import gtk      # type: ignore


class HeatTable(gtk.Alignment, object):
    """Modify Heat option. """

    def __init__(self, **d):
        set_widget_attr(self, d)
        super(gtk.Alignment, self).__init__()
        self.set(0, 0, 1, 1)

        self.roller_win = d[df.ROLLER_WIN]
        self._heat_row_d = OrderedDict()
        self._hbox_d = {}
        self._size_group_q = []
        self._mode_d = \
            self._materialize_button = \
            self._preset = \
            self._remove_button = \
            self._opacity_d = \
            self._row_color = \
            self._sort_button = \
            self._material_vbox = \
            self._scrolled_window = None
        color = self._make_heat_table(**d)

        self._make_preset_table(color, **d)
        self.any_group.set_widget(de.HEAT, self)

    def _add_box_q(self, box_q, k=None):
        """
        Create an Hbox for a HeatRow.

        box_q: list
            [Eventful] x 3

        k: string or None
            Material key
            Own the HBox.
        """
        hbox = gtk.HBox()

        if k:
            self._hbox_d[k] = hbox

        for i in box_q:
            hbox.pack_start(i)
        self._material_vbox.pack_start(hbox, expand=False)

    def _make_eventful(self):
        return [Eventful(self._row_color) for _ in range(3)]

    def _make_heat_table(self, **d):
        """
        Create an empty gtk Table.

        d: dict
            Initialize the Table.
        """
        color = d[df.COLOR]
        e = heat_d = get_default_d(de.HEAT)
        row = len(e) + 1

        heat_key_list = heat_d.keys()
        self._opacity_d = deepcopy(OPACITY)
        self._mode_d = deepcopy(MODE)
        self._material_vbox = gtk.VBox()
        color = get_darker_color(color, row + 1)
        self._row_color = color, color, co.MAX_COLOR
        self._scrolled_window = gtk.ScrolledWindow()
        eventful = Eventful(self._row_color)       # ScrolledWindow's bg-color
        k = None

        for e in (self._opacity_d, self._mode_d):
            e.update({df.NO_VOTE: True})

        self._opacity_d.update(d)
        self._mode_d.update(d)
        self.set_padding(0, 0, 4, 4)

        # column count, '3'
        for i in range(3):
            self._size_group_q.append(gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH))

        for r in range(row):
            box_q = self._make_eventful()

            if r == 0:
                # Table header
                g = gtk.Label("\t\t\tMode\t\t\t")
                g1 = gtk.Label("Opacity")

                box_q[1].add(g)
                box_q[2].add(g1)
                self._size_group_q[1].add_widget(g)
                self._size_group_q[2].add_widget(g1)

            else:
                # Material option
                k = heat_key_list[r - 1]
                self._heat_row_d[k] = HeatRow(
                    k, box_q, self._mode_d, self._opacity_d, self._size_group_q
                )
            self._add_box_q(box_q, k=k)

        self.add(self._material_vbox)
        self._scrolled_window.set_policy(
            gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC
        )
        eventful.add(self)
        self._scrolled_window.add_with_viewport(eventful)
        d[df.DNA].vbox.add(self._scrolled_window)
        self._scrolled_window.set_size_request(500, 100)
        return color

    def _make_material(self, k):
        """
        Make a material HBox.

        k: string
            Material key
        """
        box_q = self._make_eventful()
        self._heat_row_d[k] = HeatRow(
            k, box_q, self._mode_d, self._opacity_d, self._size_group_q
        )

        self._heat_row_d[k].mode.set_ui("Normal")
        self._add_box_q(box_q, k=k)
        self._material_vbox.show_all()
        self._validate_button()

    def _make_preset_table(self, color1, **d):
        """
        Create a gtk Table for Heat Preset Buttons.

        color1: tuple
            GIMP color
            'color' is in 'd'.

        d: dict
            Has init value.
        """
        alignment = gtk.Alignment(0, 0, 1, 1)
        color1 = get_darker_color(color1, 2)

        # row count, '2'; column count, '2'
        self._table = gtk.Table(2, 2)

        self._table.set_row_spacings(1)

        # Life-cycle Buttons
        # WidgetRow init dict, 'd1'
        d1 = {}

        d1.update(d)
        d1.update(
            {df.SUB: OrderedDict([
                (de.MATERIALIZE, {
                    df.DIALOG: PortChoice,
                    df.GET_A: self.get_make_material_list,
                    df.WIDGET: MakeMaterialButton
                }),
                (de.REMOVE, {
                    df.DIALOG: PortRemove,
                    df.GET_A: self.get_remove_material_list,
                    df.WIDGET: RemoveButton
                }),
                (de.SORT, {
                    df.TEXT: "Sort",
                    df.WIDGET: ProcessButton
                })
            ])}
        )

        box_q = [Eventful(color1) for _ in range(2)]
        widget_row = WidgetRow(**d1)
        self._materialize_button = widget_row.get_g(de.MATERIALIZE)
        self._remove_button = widget_row.get_g(de.REMOVE)
        self._sort_button = widget_row.get_g(de.SORT)

        self._sort_button.relay.insert(0, self.on_sort_material)
        box_q[1].add(widget_row)
        self._table.attach(box_q[0], 0, 1, 0, 1)
        self._table.attach(box_q[1], 1, 2, 0, 1)

        # Preset Row
        color1 = get_darker_color(color1, 2)
        box_q = [Eventful(color1) for _ in range(2)]
        e = dict(d, key=de.PRESET)
        self._preset = Preset(**e)

        d[df.ANY_GROUP].set_widget(de.PRESET, self._preset)
        box_q[0].add(gtk.Label("Heat Preset"))
        box_q[1].add(self._preset)
        self._table.attach(box_q[0], 0, 1, 1, 2)
        self._table.attach(box_q[1], 1, 2, 1, 2)
        alignment.add(self._table)
        d[df.DNA].vbox.add(alignment)
        alignment.set_padding(0, 0, 4, 4)
        self._materialize_button.connect(si.MATERIALIZE, self.on_make_material)
        self._remove_button.connect(
            si.REMOVE_MATERIAL, self.on_remove_material
        )
        for g in (self._remove_button, self._sort_button):
            g.connect(si.VALIDATE, self._validate_button)
        self._validate_button()

    def _update_scroll_window_size(self):
        """
        Hard coding the size request because I was
        unable to get allocation value from gtk.
        """
        h = (len(self._hbox_d) + 1) * 40
        if h > 100:
            self._scrolled_window.set_size_request(500, min(200, h))

    def _validate_button(self, *_):
        """
        The Remove and Sort Button are valid
        if there are two or more materials.
        """
        a = len(self._hbox_d)
        for g in (self._remove_button, self._sort_button):
            if g:
                g.set_sensitive(1) if a else g.set_sensitive(0)

    def get_ui(self):
        """
        Fetch the value of the Heat Table via Widget.

        Return: dict
            Heat value
        """
        heat_d = OrderedDict()

        # Material key, 'k'; HeatRow, 'a'
        for k, a in self._heat_row_d.items():
            heat_d[k] = a.get_ui()
        return heat_d

    def get_make_material_list(self):
        """
        Fetch a list of possible new Heat Material.

        Return: dict
            {material Identity: (mode, opacity)}
        """
        return [i for i in ma.KEY_LIST if i not in self._heat_row_d.keys()]

    def get_remove_material_list(self):
        """
        Fetch a list of active Heat Material.
        The Background material is not removable.

        Return: list
            [Material key, ...]
        """
        return self._heat_row_d.keys()

    def load_a(self, d):
        """
        Load the material table.

        d: dict or None
            Heat Preset or Heat Widget value
            Preset -> {de.HEAT: heat widget value dict}
            Widget -> {material key: heat row value}
            HeatRow -> {de.OPACITY: float, de.MODE: string}
        """
        if d is None:
            d = {}

        # Is the Widget value in Preset form?
        if d.get(de.HEAT):
            # Transform Preset into Widget form.
            d = d.get(de.HEAT)

        a = self.set_ui(d)
        self.any_group.set_widget_a(self.key, a)

    def on_make_material(self, _, k):
        """
        Respond to an accept action from a make material dialog.

        _: MakeMaterialButton
        k: string
            Material key or None
        """
        if k:
            self._make_material(k)
            self._update_scroll_window_size()
            self.any_group.set_widget_a(self.key, self.get_ui())

    def on_remove_material(self, _, q):
        """
        Remove material not in a list.

        _: MakeMaterialButton
        q: set or None
            [Material key, ...]
            Material that is not deleted.
        """
        if q is None:
            pass

        else:
            # Create a set of material to remove, 'q'.
            q1 = set(self._heat_row_d.keys())
            q = q1 - q
            for k in q:
                self.remove_material(k)
        if q:
            self.roller_win.resize()
        self.any_group.set_widget_a(self.key, self.get_ui())

    def on_sort_material(self, *_):
        """Sort the materials."""
        q = sorted(self._heat_row_d.keys())
        e = OrderedDict()

        for k in q:
            heat_row = self._heat_row_d[k]
            e[k] = heat_row.get_ui()
        self.load_a(e)

    def remove_material(self, k):
        hbox = self._hbox_d.get(k)
        if hbox:
            self._hbox_d.pop(k)
            hbox.parent.remove(hbox)
            if k in self._heat_row_d:
                self._heat_row_d.pop(k)

    def set_ui(self, heat_d):
        """
        Set the value of the Heat Table.

        heat_d: OrderedDict
            {material Identity: {Mode str: str, Opacity str: float}}

        Return: OrderedDict
            {material Identity: {Mode str: str, Opacity str: float}}
        """
        d = OrderedDict()

        for k in self._heat_row_d.keys():
            self.remove_material(k)

        for k, a in heat_d.items():
            if k in self._heat_row_d.keys():
                self._heat_row_d[k].set_ui(a)
                d[k] = a
            elif k in ma.KEY_LIST:
                self._make_material(k)
                self._heat_row_d[k].set_ui(a)
                d[k] = a

        self._update_scroll_window_size()
        return d


class HeatRow:
    """Make a Row having a Paint Mode and an Opacity Widget."""

    def __init__(self, k, box_q, mode_d, opacity_d, size_group):
        """
        Create a Paint Mode and an Opacity Widget and add them to Eventful.

        k: string
            Material key

        box_q: list
            of Eventful for adding the Mode and Opacity options

        mode_d: dict
            Is the Mode Widget's init dict.

        opacity_d: dict
            Is the Opacity Widget's init dict.

        size_group: list
            [gtk.SizeGroup] x 3
            Make Widget the same size.
        """
        label = Label(text=get_type_text(k))
        self.mode = ComboBox(**mode_d)
        self.opacity = RandomSlider(**opacity_d)

        box_q[0].add(label)
        box_q[1].add(self.mode)
        box_q[2].add(self.opacity)
        label.set_padding(0, 0, 0, 4)
        self.mode.set_padding(0, 0, 4, 0)
        for i, g in enumerate((label, self.mode, self.opacity)):
            size_group[i].add_widget(g)

    def get_ui(self):
        """
        Return the value of the HeatRow Widget.

        Return: dict
            HeatRow value
        """
        return {
            de.MODE: self.mode.get_ui(),
            de.OPACITY: self.opacity.get_ui()
        }

    def set_ui(self, d):
        """
        Set the value of the HeatRow Widget.

        d: dict
            HeatRow value

        Return: dict or None
            HeatRow value
        """
        if isinstance(d, dict):
            self.mode.set_ui(d[de.MODE])
            self.opacity.set_ui(d[de.OPACITY])
            return d
