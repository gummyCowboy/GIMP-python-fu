#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Dog, The
from roller_constant import Define as df, Signal as si
from roller_constant_identity import Identity as de
from roller_ring import Ring
from roller_port_preview import PortPreview
from roller_widget_dna import DNA
from roller_widget_label import Label


class PortRename(PortPreview):
    """Rename a Model."""
    window_key = "Rename Model"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Is responsible.
        """
        self._entry = self._old_name = None
        PortPreview.__init__(self, d, g)

    def draw_entry(self, box):
        """
        Draw a rename group.

        box: GTK container
            Receive Widget group.
        """
        self.is_dirt = True
        padding = 4, 4, 4, 4
        n = self._old_name = The.model_list.get_selected_name()
        dna = DNA(de.MODEL_NAME, {'make_vbox', 'preset'}, {})

        dna.inherit(self.repo.any_group.dna, True)
        box.add(dna.vbox)
        dna.vbox.add(
            Label(
                **{
                    df.PADDING: padding,
                    df.TEXT: "\nPrevious Name:\n\t{}\n\nNew Name:".format(n)
                }
            )
        )

        a = Dog.loner_group(
            **{
                df.COLOR: self.color,
                df.DNA: dna,
                df.PADDING: padding,
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win
            }
        )
        self._entry = a.get_widget(de.RENAME_MODEL)
        self._entry.set_ui(n)

    def draw(self):
        """Draw Widget."""
        self.draw_row((self.draw_entry, self.draw_basic_process))

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return lambda: None, self.on_accept_rename_model

    def on_accept_rename_model(self, *_):
        Ring.plug(si.RENAME, (self._old_name, self._entry.get_ui()))
