#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_constant_identity import Identity as de
from roller_frame import do_frame_with_filler
from roller_frame_alt import FrameBasic
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import add_layer, create_image, image_copy_all
from roller_gimp_layer import clear_selection, clipboard_fill, color_layer
from roller_gimp_selection import select_ellipse


def do_matter(maya):
    """
    Make a frame.

    maya: Holey
    Return: layer
        Holey/Wrap 'matter'
    """
    return do_frame_with_filler(maya, make_pattern)


def make_pattern(z, d):
    """
    Draw circles on a layer. Create a pattern (a black circle). Use the
    clipboard to hold the pattern. Fill the provided layer with the pattern.
    Assume selection is none.

    z: layer
        Receive pattern.

    d: dict
        Holey Preset

    Return: layer
        work-in-progress
        Has material to select.
    """
    diameter = d[de.CIRCLE_DIAMETER]
    w = diameter * 1.5
    h = w * .8660254
    j = create_image(int(w), int(h))
    z1 = add_layer(j, None, 0, "Pattern")

    # A circle at the center of 'z1' will become a hole in the pattern.
    x = (w - diameter) // 2.
    y = (h - diameter) // 2.

    set_fill_context_default()
    color_layer(z1, (255, 255, 255))
    select_ellipse(j, x, y, diameter, diameter)
    pdb.gimp_selection_feather(j, 1.)
    clear_selection(z1)

    # Set the Clipboard Image.
    image_copy_all(j)

    pdb.gimp_image_delete(j)
    pdb.gimp_selection_none(z.image)
    clipboard_fill(z)
    return z


class Holey(FrameBasic):
    filler_k = de.FILLER_HO
    kind = material = de.HOLEY
    wrap_k = de.WRAP_PA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
