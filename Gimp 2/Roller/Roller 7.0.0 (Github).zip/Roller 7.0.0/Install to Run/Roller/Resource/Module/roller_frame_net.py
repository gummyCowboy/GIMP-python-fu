#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD, CHANNEL_OP_REPLACE, CHANNEL_OP_SUBTRACT, CLIP_TO_IMAGE, pdb
)
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_deco_output import do_grid
from roller_frame import do_image_selection
from roller_frame_alt import FrameBasic
from roller_frame_type import grow_wrap_channel
from roller_gegl import emboss
from roller_gimp_image import add_layer_above, add_layer_below
from roller_gimp_layer import (
    blur_selection,
    clone_layer,
    color_layer,
    color_selection_default,
    isolate_channel
)
from roller_gimp_mode import get_mode
from roller_gimp_selection import get_select_coord, select_channel, select_rect


def _emboss_layer(j, z, d):
    """
    Emboss a layer.

    j: Gimp Image
        WIP

    z: layer
        Has Net material.

    d: dict
        Net/Wrap Preset

    Return: layer
        frame
    """
    e = d[de.EMBOSS]
    if e[de.SWITCH]:
        pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)

        frame_sc = pdb.gimp_selection_save(j)
        z1 = add_layer_below(z, "Outside")
        z2 = clone_layer(z)

        pdb.gimp_selection_none(j)
        color_layer(z1, (0, 0, 0))

        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

        blur_selection(z, e[de.PRE_BLUR])
        emboss(z, Globe.azimuth, Globe.elevation, int(e[de.DEPTH]))
        blur_selection(z, e[de.POST_BLUR])
        isolate_channel(z, frame_sc)
        pdb.gimp_image_remove_channel(j, frame_sc)

        # brightness, '0'
        if e[de.CONTRAST]:
            pdb.gimp_brightness_contrast(z, 0, int(e[de.CONTRAST]))

        z2.mode = get_mode(e)
        z = pdb.gimp_image_merge_down(j, z2, CLIP_TO_IMAGE)
    return z


def do_matter(maya):
    """
    Make a frame.

    maya: Net/Wrap
    Return: layer
        Wrap material
    """
    return do_image_selection(
        maya, do_selection, embellish, "Material", is_clip=False
    )


def do_selection(maya, z):
    """
    Do the Frame for a selection.

    maya: Net/Wrap
    z: layer
        Receive frame.
        'matter'

    Return: layer
        Wrap material
    """
    j = Run.j
    d = maya.value_d
    color = d[de.COLOR_1]
    type_ = d[de.TYPE]
    width = d[de.WIDTH]
    z = add_layer_above(z, "Color")

    # Net/Wrap Preset dict, 'd'
    d = maya.value_d

    image_sc = pdb.gimp_selection_save(j)
    frame_w = width + d[de.FILLER_W]

    grow_wrap_channel(j, image_sc, frame_w, type_)

    x, y, x1, y1 = get_select_coord(j)
    frame_sc = pdb.gimp_selection_save(j)

    select_rect(j, x, y, x1 - x, y1 - y)

    z = do_grid(j, z, d)

    isolate_channel(z, frame_sc)

    # Add inner and outer frame.
    select_channel(j, image_sc)
    grow_wrap_channel(j, image_sc, width, type_)

    inner_sc = pdb.gimp_selection_save(j)

    # outer
    select_channel(j, frame_sc)
    grow_wrap_channel(j, image_sc, width, type_)

    # Combine selection to make frame.
    select_channel(j, frame_sc, CHANNEL_OP_SUBTRACT)
    select_channel(j, inner_sc, CHANNEL_OP_ADD)

    color_selection_default(z, color)

    for a in (frame_sc, image_sc, inner_sc):
        pdb.gimp_image_remove_channel(j, a)
    return pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)


def embellish(maya, z):
    """
    Is called from 'do_selection', so its a contract.

    maya: Net/Wrap
    z: layer
        Has Wrap material.

    Return: layer
        Wrap material
    """
    # Emboss the net.
    return _emboss_layer(Run.j, z, maya.value_d)


class Net(FrameBasic):
    is_embossed = True
    kind = material = de.NET
    wrap_k = de.WRAP_NT

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
