#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from random import randint
from roller_container import Dog, The
from roller_constant import (
    Accent as by,
    Color as co,
    Deco as dc,
    Define as df,
    Frame as ek,
    Signal as si
)
from roller_constant_identity import Identity as de
from roller_def_access import get_default_d
from roller_utility import reduce_color, seed_random
from roller_ring import Ring
from roller_tooltip_text import Tip
from roller_step import get_branch_part, get_deco_part
from roller_widget import Widget
from roller_widget_box import Eventful
from roller_widget_button import ProcessButton
from roller_widget_combo import ComboBox
from roller_widget_dna import DNA
from roller_widget_label import Label
from roller_widget_tree import TreeViewList
import gtk  # type: ignore

KEY_SET = set(by.KEY_LIST + ek.KEY_LIST)


def get_accent_abstract():
    return [
        de.CUBISM_COVER, de.ETCH_SKETCH,
        de.GLASS_GAW, de.RAINBOW_VALLEY, de.SQUARE_CLOUD,
        de.TRAIL_VINE, de.WAVE_FILL
    ]


def get_accent_basic():
    return [
        de.COLOR_FILL, de.GRADIENT_FILL, de.MEAN_COLOR, de.PATTERN_FILL
    ]


def get_accent_design():
    return [
        de.DROP_ZONE, de.CORNER_OVERLAP,
        de.FLOOR_SAMPLE, de.LOST_MAZE,
        de.MAZE_BLEND, de.GRATE_MYSTERY,
        de.ROOF_TOP, de.TRIANGLE_REVERB
    ]


def get_accent_key_list():
    return by.KEY_LIST


def get_accent_pattern():
    return [
        de.BACK_GAME, de.COLOR_GRID, de.CUBE_PATTERN,
        de.RECT_PATTERN, de.SPIRAL_CHANNEL
    ]


def get_accent_texture():
    return [
        de.ACRYLIC_SKY, de.CLAY_CHEMISTRY,
        de.CRYSTAL_CAVE, de.DARK_FORT,
        de.DENSITY_GRADIENT, de.FADING_MAZE,
        de.GALACTIC_FIELD, de.HISTORIC_TRIP,
        de.LINE_STONE, de.NOISE_RIFT,
        de.PAPER_WASTE, de.ROCKY_LANDING,
        de.SOFT_TOUCH, de.SPECIMEN_SPECKLE, de.STONE_AGE
    ]


def get_frame_canvas_scale():
    return [de.MAZE, de.MIRROR, de.RAD]


def get_frame_cell():
    return [de.BEVEL, de.BURST, de.NET, de.OVER, de.OVERLAP, de.TAPE]


def get_frame_filler():
    return [de.CERAMIC, de.STAINED, de.STRETCH]


def get_frame_embossed():
    return [
        de.BASIC, de.BRUSHY,
        de.CAMO, de.CHECKER,
        de.FENCE, de.HOLEY,
        de.JOINT, de.MECHA,
        de.STRIPE, de.WOBBLE
    ]


def get_frame_embossed_limited():
    return [
        de.BASIC, de.BRUSHY, de.CAMO, de.CHECKER, de.FENCE,
        de.HOLEY, de.MECHA, de.STRIPE, de.WOBBLE
    ]


def get_frame_key_list():
    return ek.KEY_LIST


def get_frame_key_list_limited():
    return ek.DECO_KEY_LIST


def get_frame_other():
    return [de.CRUMBLE, de.DECAY, de.GRADUAL]


def get_frame_overlay():
    return [de.CLEAR, de.GLUE, de.PIPE]


ACCENT_CATEGORY = OrderedDict([
    ("All", get_accent_key_list),
    ("Abstract", get_accent_abstract),
    ("Basic", get_accent_basic),
    ("Design", get_accent_design),
    ("Pattern", get_accent_pattern),
    ("Texture", get_accent_texture)
])
FRAME_CATEGORY = OrderedDict([
    ("All", get_frame_key_list),
    ("Canvas Scale", get_frame_canvas_scale),
    ("Cell-by-Cell", get_frame_cell),
    ("Filler", get_frame_filler),
    ("Embossed", get_frame_embossed),
    ("Other", get_frame_other),
    ("Overlay", get_frame_overlay)
])
LIMITED_FRAME_CATEGORY = OrderedDict([
    ("All", get_frame_key_list_limited),
    ("Canvas Scale", get_frame_canvas_scale),
    ("Filler", get_frame_filler),
    ("Embossed", get_frame_embossed_limited),
    ("Other", get_frame_other),
    ("Overlay", get_frame_overlay)
])

# {option type: category dict}
CATEGORY_D = {
    de.ACCENT: ACCENT_CATEGORY,
    de.FRAME: FRAME_CATEGORY,
    de.LIMITED: LIMITED_FRAME_CATEGORY
}

# {option type: All category list getter}
GET_ALL_FUNCTION = {
    de.ACCENT: get_accent_key_list,
    de.FRAME: get_frame_key_list,
    de.LIMITED: get_frame_key_list_limited
}

# {option type: option key}
DEFAULT_KEY_D = {
    de.ACCENT: de.ACRYLIC_SKY,
    de.FRAME: de.BASIC,
    de.LIMITED: de.BASIC
}


def frame_limited(any_group):
    """
    any_group: AnyGroup
    Return: bool
        Is True if the leaf uses limited Frame type only.
    """
    m = False
    k = any_group.type_step_k

    if get_branch_part(k) in dc.FACIAL_SET:
        m = True

    elif get_deco_part(k) != de.IMAGE:
        m = True
    return m


class OptionList(Widget):
    """Is a Treeview composed of a list."""
    change_signal = None
    has_table_label = False

    # Remember option.
    _category_selection_d = {}
    _preset_d = {}

    def __init__(self, **d):
        """
        d: dict
            Has option.
        """
        self._label_h = \
            self._option_k = \
            self._option_panel = \
            self._category_list = \
            self._option_list_d = \
            self._category_combo = \
            self._option_any_group = None
        self._panel = gtk.HBox()

        Widget.__init__(self, self._panel, **d)
        super(gtk.Alignment, self).add(self._panel)

        self._option_type_k = d[df.DNA].type_
        self.is_accent = self._option_type_k == de.ACCENT
        self._list_color = reduce_color(d[df.COLOR])
        self._panel_color = self.option_color = reduce_color(self._list_color)
        The.load_count += 1

        self._init_category_list()
        self._draw_list()
        self._make_panel()
        self._option_tree.select_r(0)
        self._option_tree.relay.insert(0, self.on_option_list_act)
        The.load_count -= 1

    def _create_new_any_group(self, key):
        dna = DNA(key, {'make_vbox', 'preset'}, {})

        dna.inherit(self.any_group.dna, True)
        self._option_panel.add(dna.vbox)

        any_group = Dog.sub_any_group(
            self.any_group,
            **{
                df.COLOR: self.option_color,
                df.DNA: dna,
                df.RELAY: self.relay,
                df.ROLLER_WIN: self.roller_win
            }
        )
        any_group.type_step_k = key
        return any_group

    def _draw_list(self):
        """
        Draw a choice list for serving a selectable Preset.

        d: dict
            Has option.
        """
        d = {
            df.ANY_GROUP: self.any_group,
            df.ROLLER_WIN: self.roller_win
        }
        self._label_h = gtk.Label("\n")

        # category ComboBox
        e = {df.FUNCTION: self._get_category, df.RELAY: self.relay[:]}

        e.update(d)
        e[df.RELAY].insert(0, self.on_category_change)

        self._category_combo = ComboBox(**e)

        self._category_combo.set_ui("All")

        # option TreeViewList
        k = self._get_sub_option_type()
        p = GET_ALL_FUNCTION[k]
        e = {
            df.ALIGN: (0, 0, 1, 1),
            df.COLOR: co.LIST_CELL_COLOR,
            df.FUNCTION: p,
            df.MINIMUM_W: 1,
            df.RELAY: self.relay[:],
            df.SCROLL: 1,
            df.TREE_COLOR: self._list_color
        }

        e.update(d)

        self._option_tree = TreeViewList(**e)

        self._option_tree.set_padding(0, 4, 4, 4)
        self._option_tree.set_ui(p())

        # option Random Button
        e = {df.RELAY: self.relay[:]}
        e[df.KEY] = e[df.TEXT] = "Random"

        e.update(d)
        e[df.RELAY].insert(0, self.randomize)

        button = ProcessButton(**e)

        # Contain tree and Combobox.
        vbox = gtk.VBox()
        hbox = gtk.HBox()

        self.add(vbox)
        hbox.add(self._label_h)
        vbox.add(
            Label(
                **{df.TEXT: "{} Category:  ".format(self._option_type_k)}
            )
        )
        vbox.add(self._category_combo)
        hbox.add(self._option_tree)
        vbox.add(hbox)
        vbox.add(button)

    def _get_category(self):
        return self._category_list

    def _get_sub_option_type(self):
        """
        Get the key used to determine the Category list.

        Return: string
            Category list key
        """
        k = self._option_type_k

        if k == de.FRAME:
            if frame_limited(self.any_group):
                k = de.LIMITED
        return k

    def _init_category_list(self):
        """
        Set the option list dict required to access a sub-category Preset list.
        """
        k = self._get_sub_option_type()
        d = self._option_list_d = CATEGORY_D[k]
        self._category_list = d.keys()

    def _make_panel(self):
        """
        Make a GTK HBox panel for the list choice.
        """
        self._option_panel = gtk.HBox()
        box = Eventful(self._panel_color)

        box.add(self._option_panel)
        self.add(box)

    def add(self, g):
        """
        Add an object to the HBox at the top of the container hierarchy.

        g: object
        """
        self._panel.add(g)

    def get_sub_any_group(self):
        return self._option_any_group

    def get_a(self):
        """
        Retrieve the value of the list and
        Preset. Use the AnyGroup value for speed.

        Return: dict
            {Preset key: Preset dict}
        """
        # Use Option AnyGroup for key, as it's
        # more reliable than the TreeView.
        a = self._option_any_group
        return {a.type_step_k: a.get_value_d()} if a else {None: None}

    def get_ui(self):
        """
        Retrieve the value of the list and Preset.

        Return: dict
            {Preset key: Preset dict}
        """
        return self.get_a()

    def load_a(self, d):
        d = self.set_ui(d)
        self.any_group.set_sub_widget_a(self.row_key, self.key, d)

    def on_category_change(self, g):
        """
        Respond to change in the category ComboBox.

        g: ComboBox
            category list
            Is responsible.
        """
        if not The.load_count:
            # Set the option list and select the previous selection.
            r = 0
            k = g.get_ui()
            q = self._option_list_d[k]()

            self._option_tree.set_ui(q)

            n = OptionList._category_selection_d.get(k)

            if n is not None:
                q = self._option_tree.item_list
                if n in q:
                    r = q.index(n)
            self._option_tree.select_r(r)
        return True

    def on_option_list_act(self, *_):
        """
        Receive TreeViewList change signal.

        Return: True
            The signal is processed.
        """
        if self._option_panel:
            self.on_option_list_choice(
                key=self._option_tree.get_selected_item()
            )
        return True

    def on_option_list_choice(self, key=None):
        """
        Respond to list change. For each choice,
        create an AnyGroup. Change Widget visibility.

        key: string
            Preset's Identity
        """
        def _adjust_vbox_h():
            _a = any_group.count_widget()

            if _a < 8:
                _a = 8

            else:
                _a = _a + (_a // 2)
            self._label_h.set_label("\n" * _a)

        if key is None:
            key = self._option_tree.get_selected_item()

        if self._option_k:
            OptionList._preset_d[self._option_k] = \
                self._option_any_group.get_value_d()

        OptionList._category_selection_d[
            self._category_combo.get_ui()] = key

        if key != self._option_k:
            self.remove_option_vbox()

            any_group = self._option_any_group = self._create_new_any_group(
                key
            )
            _adjust_vbox_h()

        else:
            any_group = self._option_any_group

        # Update visual.
        self._option_tree.treeview.set_tooltip_text(
            Tip.OPTION_LIST[key] if key in Tip.OPTION_LIST else ""
        )

        # Make ViewButton sensitive.
        self.relay[-1](self)

        if self.is_accent:
            # Accent needs to reset AnyGroup vote dict.
            self.any_group.emit(si.ACCENT_CHANGE, self)

        d = OptionList._preset_d.get(key)

        if d:
            any_group.load_widget_d(d)

        self._option_k = key

        any_group.dna.vbox.show_all()
        Ring.add(self.any_group, si.GROUP_CHANGE, None)
        self.roller_win.resize()

    def randomize(self, *_):
        """Select a random choice from the list."""
        seed_random()
        self._option_tree.select_r(
            randint(0, len(self._option_tree.item_list) - 1)
        )

    def remove_option_vbox(self):
        """
        Remove the VBox child from the option panel so
        that the VBox can be reused by another option.
        """
        for child in self._option_panel.get_children():
            # Remove the previous VBox from
            # the panel, but don't delete it.
            #
            # Reference
            # 'stackoverflow.com/questions/5614840/pygtk-remove-a
            # -widget-from-a-container-and-reuse-it-later'
            self._option_panel.remove(child)
            break

    def set_ui(self, d):
        """
        Select an item in the list. Load its Preset.

        d: dict
            {Preset key: Preset value dict}

        Return: dict
            {Preset key: Preset value dict}
        """
        # Preset key, 'k'
        k = d.keys()[0]

        if not k or self.any_group.is_loading_default:
            # Abort.
            return d

        if k not in KEY_SET:
            # Repair.
            k = DEFAULT_KEY_D[self._option_type_k]
            d = {k: get_default_d(k)}

        q = self._option_tree.item_list

        if q:
            if self._option_panel:
                self.on_option_list_choice(key=k)
                self._option_any_group.load_widget_d(d[k])

            self._option_tree.treeview.set_cursor(q.index(k) if k in q else 0)

            # gtk.TreeSelection, 'selection'
            selection = self._option_tree.treeview.get_selection()
            if selection:
                model, iter_ = selection.get_selected()
                if iter_:
                    path = model.get_path(iter_)
                    self._option_tree.treeview.scroll_to_cell(path)
        return d
