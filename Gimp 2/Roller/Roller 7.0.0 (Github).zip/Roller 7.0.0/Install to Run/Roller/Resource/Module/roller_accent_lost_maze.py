#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CHANNEL_OP_REPLACE,
    CLIP_TO_IMAGE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_GRAIN_EXTRACT,
    pdb
)
from roller_preset_blur import do_blur
from roller_constant import Gradient as fg, Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_deco_output import init_deco_type
from roller_def_access import get_default_d
from roller_gimp_image import add_sub_maya_group, add_wip_layer
from roller_gimp_layer import (
    clone_layer,
    color_layer_default,
    dilate,
    flip_layer,
    isolate_channel
)
from roller_gimp_selection import select_rect
from roller_maya_sub_accent import SubAccent
from roller_preset_shadow import do_stylish_shadow
from roller_wip import Wip


def do_grid(z, q, is_vertical=True):
    """
    Draw grid lines. The grid lines are either
    horizontal or vertical, but not both.

    z: layer
        Receive grid material.

    q: tuple
        argument for vertical or horizontal line

    is_vertical: bool
        If it's True, the argument is for a vertical line.
    """
    arg = z.image, z
    q1 = 0, 0, 0, (0, 0, 0), 0

    if is_vertical:
        arg += q1 + q + q1

    else:
        arg += q + q1 * 2
    pdb.plug_in_grid(*arg)


def do_matter(maya):
    """
    Make a matter layer for LostMaze.

    maya: LostMaze
    Return: layer
        'matter'
    """
    j = Run.j
    d = maya.value_d
    group = add_sub_maya_group(maya)
    z = maze_layer = add_wip_layer("Base", group)
    w = max(1, int(Wip.w // d[de.COLUMN]))
    h = max(1, int(Wip.h // d[de.ROW]))
    seed_ = int(d[de.RANDOM_SEED] + Globe.seed)

    pdb.gimp_context_set_foreground((0, 0, 0))
    pdb.gimp_context_set_background((255, 255, 255))
    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)
    pdb.plug_in_maze(
        j, z,
        w, h,               # passage scale
        1,                  # yes, tileable
        0,                  # depth first algorithm
        seed_,
        0,                  # multiple, not clearly defined
        0                   # offset, not clearly defined
    )

    z = clone_layer(z, n="Alpha")

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

    alpha_layer = clone_layer(z, n="Difference")
    alpha_layer.mode = LAYER_MODE_DIFFERENCE

    pdb.gimp_selection_none(j)

    # no wrap, '0'; SOBEL, '0'
    pdb.plug_in_edge(j, maze_layer, 1., 0, 0)

    # Expand the border.
    for _ in range(2):
        dilate(maze_layer)

    pdb.plug_in_colortoalpha(j, maze_layer, (0, 0, 0))

    # horizontal line
    h1 = min(max(6, h // 5), int(Wip.h))

    do_grid(
        z,
        (h1, h1 + 1, 0, (0, 0, 0), 255),
        is_vertical=False
    )
    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

    z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
    e = maya.gradient_d

    e.update(d)

    e[de.GRADIENT] = d[rk.RW1][de.GRADIENT]

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)

    white_sc = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.gimp_image_set_active_layer(j, z)

    maya.rect = Wip.get_rect()
    arg, p = init_deco_type(de.GRADIENT, j, maya, group, e, 0, False)

    select_rect(j, *maya.rect)

    z = p(*arg)
    n = d[de.GRADIENT_ANGLE]
    x = y = 0.

    if n in fg.LEFT_GRADIENT_ANGLE:
        x = 3.

    elif n in fg.RIGHT_GRADIENT_ANGLE:
        x = -3.

    if n in fg.TOP_GRADIENT_ANGLE:
        y = 3.

    elif n in fg.BOTTOM_GRADIENT_ANGLE:
        y = -3.

    isolate_channel(z, white_sc)
    do_stylish_shadow(
        z, blur=9., intensity=150., offset_x=x, offset_y=y
    )
    pdb.gimp_selection_none(j)

    # vertical line
    z = add_wip_layer(
        "Vertical Line", group, offset=len(group.layers) + 1
    )

    color_layer_default(z, (255, 255, 255))
    pdb.gimp_selection_all(j)

    v1 = min(max(12, w // 12), int(Wip.h))

    do_grid(z, (v1, v1 + 1, 0, (0, 0, 0), 255))
    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    do_stylish_shadow(z, blur=10, intensity=200., is_inner=True)
    do_stylish_shadow(z, blur=10, intensity=200.)

    # background
    select_rect(j, *maya.rect)

    arg, p = init_deco_type(de.GRADIENT, j, maya, group, e, 0, False)
    z = p(*arg)

    pdb.gimp_image_lower_item_to_bottom(j, z)
    pdb.gimp_image_reorder_item(j, alpha_layer, group, 4)
    do_blur(alpha_layer, d[de.BLUR_D])
    flip_layer(z)
    flip_layer(z, is_h=True)

    # grain
    z = clone_layer(alpha_layer, n="Grain Extract")

    pdb.gimp_image_reorder_item(j, z, group, 6)

    z.mode = LAYER_MODE_GRAIN_EXTRACT
    z.opacity = 100.

    # no linear, '0'
    pdb.gimp_drawable_invert(z, 0)

    pdb.gimp_image_remove_channel(j, white_sc)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, group), d[rk.RW1]
    )


class LostMaze(SubAccent):
    """Create Accent output."""
    kind = de.LOST_MAZE

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)
        self.gradient_d = get_default_d(de.GRADIENT_FILL)
        self.gradient_d[de.GRADIENT_TYPE] = "Linear"
