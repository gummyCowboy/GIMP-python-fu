#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import Color as co
from roller_constant_identity import Identity as de
from roller_container import Path
from roller_comm import show_err
import json
import os


def convert_json_to_per(d):
    """
    Convert Per key to tuple type.

    d: dict
        Preset or SuperPreset
    """
    for k, a in d.items():
        if k == de.PER:
            e = {}

            if isinstance(a, dict):
                for k1, b in a.items():
                    e[convert_str_to_r_c(k1)] = b
            d[k] = e
        elif isinstance(a, dict):
            convert_json_to_per(a)


def convert_list_color(d):
    """
    Convert Color list-value to tuple-value.
    [R, G, B, A] -> (R, G, B, A)

    d: dict
        Preset or SuperPreset
    """
    for k, a in d.items():
        if isinstance(a, dict):
            convert_list_color(a)

        elif k in co.SINGLE_COLOR_SET:
            d[k] = tuple(d[k])
        elif k in co.MULTI_COLOR_SET:
            d[k] = [tuple(color) for color in d[k]]


def convert_per_to_json(d):
    """
    Convert Per key to string type.

    d: dict
        Preset or SuperPreset
    """
    for k, a in d.items():
        if k == de.PER:
            e = {}

            if isinstance(a, dict):
                for k1, b in a.items():
                    e[convert_rc_to_str(k1)] = b
            d[k] = e
        elif isinstance(a, dict):
            convert_per_to_json(a)


def convert_rc_to_str(k):
    """
    Convert an iterable of integer to a Goo key string.

    Return: list
        [Goo key, ...] -> ['1,1', '1,2', ...]
    """
    return ",".join(map(str, k))


def convert_str_to_r_c(k):
    """
    Convert an iterable of string to a list containing row and column integer.

    Return: tuple
        of int
        (row, column) or (row, column, facial)
    """
    return tuple(map(int, k.split(',')))


def ensure_dir(n):
    """
    Ensure a directory exists. Use to make a Preset folder.

    n: string
        file path

    Return two flags.
        err: bool
            error flag

        go: bool
            If it is true, then the operation was successful.
    """
    go = err = False

    if n and not os.path.isdir(os.path.dirname(n)):
        try:
            os.makedirs(os.path.dirname(n))
        except Exception:
            err = True
            show_err("Roller is unable to store files at\n" + n)

    else:
        go = True
    return err, go


def make_preset_file_name(n):
    """
    Format a Preset file name.

    n: string
        Preset user-defined name

    Return: string
        file name
    """
    return "{}.json".format(n)


def make_preset_path(n, n1):
    """
    Construct a file path to a Preset file.

    n: string
        Preset key

    n1: string
        file identifier

    Return: string
        Preset file path
    """
    n2 = os.path.join(Path.preset, n)
    return os.path.join(n2, make_preset_file_name(n1))


def json_dump(d, n):
    """
    Write a Roller Preset file using 'json'.

    d: dict
        output data

    n: string
        file path

    Return: bool
        Is True if the operation succeeded.
    """
    go = False
    err, _ = ensure_dir(n)

    if d:
        d = deepcopy(d)
        convert_per_to_json(d)

    if not err:
        try:
            with open(n, "w") as output_file:
                json.dump(d, output_file)
            go = True
        except Exception as ex:
            show_err(ex)
            show_err("Roller is unable to save:\n" + n)
    return go


def json_load(n, is_shown=True):
    """
    Read a Roller 'json' Preset file. Keep the order of the
    file's dict items.

    n: string
        file path

    show_err: bool
        If it is False, then a load error is not displayed.

    Return: dict or None
        input data
    """
    d = {}
    err, go = ensure_dir(n)

    if go and not err:
        try:
            with open(n, "r") as input_file:
                d = json.load(input_file, object_pairs_hook=OrderedDict)
                if not isinstance(d, dict):
                    # failure
                    d = {}
        except Exception as ex:
            if is_shown:
                show_err(ex)
                show_err("Roller is unable to load json\n" + n)

    convert_json_to_per(d)
    convert_list_color(d)
    return d
