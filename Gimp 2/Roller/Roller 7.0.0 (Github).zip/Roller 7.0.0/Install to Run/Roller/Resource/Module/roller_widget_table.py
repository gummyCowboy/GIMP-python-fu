#!/usr/bin/env python
# -*- coding: utf-8 -*-
# from roller_comm import info_msg
from roller_constant import Color as co, Define as df
from roller_widget_box import Eventful
from roller_widget_label import Label
from roller_widget_option_list import OptionList
import gtk  # type: ignore

LABEL_INDEX, WIDGET_INDEX, KEY_ARG_INDEX = range(3)


def create_table(container, **d):
    """
    Create a GTK Table with added Widget given a list of Widget argument.

    container: GTK container
        Is for the Table.

    d: dict
        Has keyword arguments.
        Must have:
        df.COLOR, start color row 1
        'q', list of Widget arguments

    Return: dict
        {Identity: Widget}
        A Widget must have a key if it is to be returned.
    """
    # [(label text, Widget-type, Widget init arg), ...], 'widget_list'
    widget_list = d[df.WIDGET_LIST]

    e = {}
    color = d[df.COLOR]
    alignment = gtk.Alignment(.5, .5, 1, 0)
    table = gtk.Table(len(widget_list), 2)
    option_count = len(widget_list)

    alignment.set_padding(4, 4, 2, 2)
    table.set_row_spacings(1)

    # row, 'r'; tuple (label text, Widget, Widget def), 'widget_arg'
    for r, widget_arg in enumerate(widget_list):
        if not r:
            # Expand the right-column with an invisible label Widget.
            table.attach(gtk.Label("\t" * 6), 1, 2, r, r + 1)

        # primary Widget, 'g'
        g = widget_arg[WIDGET_INDEX](**widget_arg[KEY_ARG_INDEX])

        is_option_list = isinstance(g, OptionList)
        color = get_darker_color(color, option_count)
        color1 = color, color, co.MAX_COLOR
        text = widget_arg[LABEL_INDEX]

        if not is_option_list:
            g.label_box = Eventful(color1)
            if text:
                label = g.label = Label(text=text)

                g.label_box.add(label)
                label.set_padding(0, 0, 4, 2)

        if g.key is not None:
            e[g.key] = g

        g.box = Eventful(color1)

        g.set_padding(0, 0, 2, 4)
        g.box.add(g)

        if is_option_list:
            table.attach(g.box, 0, 2, r, r + 1, yoptions=gtk.FILL)
        else:
            table.attach(g.label_box, 0, 1, r, r + 1)
            table.attach(g.box, 1, 2, r, r + 1, yoptions=gtk.FILL)

    alignment.add(table)
    container.add(alignment)
    return e


def get_darker_color(color, step_count):
    """
    Calculate a darker blue color using a step count.

    color: int
        Decrease its value to obtain result.
        Is the red and green component.

    step_count: int
        Use to compute amount to reduce.

    Return: int
        for a darker color
    """
    return color - 14000 // (step_count + 1)
