#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import GRADIENT_BLEND_RGB_PERCEPTUAL, pdb   # type: ignore
from roller_container import Run
from roller_gegl import unsharp_mask
from roller_constant import Gradient as fg, Row as rk
from roller_constant_identity import Identity as de
from roller_gimp_context import set_fill_context_default, set_gimp_gradient
from roller_frame import do_image_selection, grow_wrap
from roller_frame_alt import FrameBasic
from roller_gimp_layer import blur_selection
from roller_gimp_selection import get_select_coord


def do_matter(maya):
    """
    Make a frame.

    maya: Burst
    Return: layer
        Wrap material
    """
    # Burst Preset dict, 'd'
    d = maya.value_d

    set_fill_context_default()
    set_gimp_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(d[rk.RW1][de.REVERSE])
    return do_image_selection(maya, do_selection, embellish, "Material")


def do_selection(maya, z):
    """
    Do the Frame for a selection.

    maya: Maya
    z: layer
        to receive frame

    Return: layer
        Wrap material
    """
    # Burst Preset dict, 'd'
    d = maya.value_d

    grow_wrap(Run.j, None, d[de.WIDTH], de.RECTANGLE)

    x, y, x1, y1 = get_select_coord(Run.j)

    pdb.gimp_drawable_edit_gradient_fill(
        z,
        fg.GRADIENT_TYPE_LIST.index(d[de.SHAPED_TYPE]),
        0,                                         # offset
        1,                                         # yes, super-sample
        3,                                         # maximum super-sample depth
        .0,                                        # super-sample threshold
        1,                                         # yes, dither
        (x1 + x) / 2., (y1 + y) / 2.,              # start point
        x, y                                       # end point
    )
    return z


def embellish(maya, z):
    """
    Modify the Wrap material.

    maya: Burst
    z: layer
        Has Wrap material.

    Return: layer
        Wrap material
    """
    # Burst Preset dict, 'd'
    d = maya.value_d

    pdb.gimp_selection_none(Run.j)

    if d[de.UNSHARP_AMOUNT] and d[de.UNSHARP_RADIUS]:
        unsharp_mask(z, d[de.UNSHARP_RADIUS], d[de.UNSHARP_AMOUNT], .0)
        blur_selection(z, 1)

    if d[rk.RW1][de.INVERT]:
        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)
    return z


class Burst(FrameBasic):
    kind = material = de.BURST
    wrap_k = de.WRAP_BU

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
