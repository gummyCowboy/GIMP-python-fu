#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Define as df, Signal as si
from roller_widget_voter import Voter
import gtk  # type: ignore

# Are Widget type that accept a Return key for the Accept function.
RETURNABLE_SET = {
    gtk.CheckButton,
    gtk.Entry,
    gtk.HScale,
    gtk.RadioButton,
    gtk.ScrolledWindow,
    gtk.SpinButton,
    gtk.ToggleButton,
    gtk.TreeView
}


def set_widget_attr(g, d):
    """
    Create Widget attribute from filtered keyword.

    g: Widget or object
        Receive attribute.

    d: dict
        Has keyword.
    """
    # Screen out attribute with an inclusion list.
    for i in df.ATTRIBUTE_SET:
        if i in d:
            setattr(g, i, d[i])


class Widget(gtk.Alignment, Voter, object):
    """
    Is a 'new-style' class with a super class 'gtk.Alignment'.
    Has widget-factored functions and attributes. Sub-Widget classes
    need to init the Widget class before connecting Signal.
    """

    def __init__(self, g, **d):
        """
        g: sub-widget
            of sub-class

        d: dict
            Has init values.
        """
        # Need in Python 2 but not in Python 3.
        # Reference
        #   stackoverflow.com/questions/17509846/
        #   python-super-arguments-why-not-superobj
        super(gtk.Alignment, self).__init__()

        self.align = 0, 0, 1, 1
        self.widget = g
        self.box = self.key = self.label = self.row_key = self.label_box = None

        for i in (df.ANY_GROUP, df.ROW_KEY):
            if i not in d:
                d[i] = None

        set_widget_attr(self, d)

        self.relay = d[df.RELAY][:] if df.RELAY in d else None

        Voter.__init__(self, **d)
        self.set(*self.align)

        if self.any_group:
            self.latch(self.any_group, (si.DISAPPEAR, self.on_disappear))

        if df.PADDING in d:
            self.set_padding(*d[df.PADDING])

        if df.TOOLTIP in d:
            g.set_tooltip_text(d[df.TOOLTIP])

        a = self.change_signal
        if a:
            self.latch(g, ('key_press_event', self.on_key_press))
            if isinstance(a, tuple):
                for i in a:
                    self.latch(g, (i, self.on_widget_change))
            else:
                self.latch(g, (a, self.on_widget_change))

    def get_sensitive(self):
        """
        Get the Widget's sensitivity. Call the Widget's gtk
        function. Override the 'gtk.Alignment' super-class.

        Return: int
            sensitivity; 0 or 1
        """
        return self.widget.get_sensitive()

    def grab_focus(self):
        """Call the underlying gtk Widget."""
        self.widget.grab_focus()

    def hide(self):
        """Hide the Widget and its attached Label."""
        if self.box:
            self.box.hide()

        else:
            self.widget.hide()

        if self.label_box:
            self.label_box.hide()
        elif self.label:
            self.label.widget.hide()

    def on_key_press(self, g, a):
        """
        Respond to a keypress event.

        g: Widget
            Is responsible.

        a: gtk.Event
            a keypress type

        Return: None or True
            Is True if the keypress is handled.
        """
        if g.get_visible():
            n = gtk.gdk.keyval_name(a.keyval)

            if n == 'Escape':
                self.roller_win.emit(si.CANCEL_WINDOW, self)
                return True

            if n == 'Return':
                if type(g) in RETURNABLE_SET:
                    self.roller_win.emit(si.ACCEPT_WINDOW, self)
                    return True

            if n in ('P', 'p'):
                if a.state & gtk.gdk.CONTROL_MASK:
                    self.roller_win.emit(
                        si.PREVIEW, self.roller_win.gtk_win.get_focus()
                    )
                    return True
            if n in ('E', 'e'):
                if a.state & gtk.gdk.CONTROL_MASK:
                    self.roller_win.emit(
                        si.PEEK, self.roller_win.gtk_win.get_focus()
                    )
                    return True

    def on_widget_change(self, *_):
        """
        Call each function in the relay on Widget change.

        Return: True
            Tell GTK that the signal is handled.
        """
        for i in self.relay:
            i(self)
        return True

    def set_sensitive(self, a):
        """
        Set the Widget's sensitivity. Call the Widget's
        GDK function. Override the 'gtk.Alignment' super-class.

        a: int
            sensitivity
            0 or 1
        """
        self.widget.set_sensitive(a)

    def set_tooltip_text(self, tooltip):
        """
        Set the Widget's tooltip.

        tooltip: string
            Apply to the Widget.
        """
        self.widget.set_tooltip_text(tooltip)

    def show(self):
        """Show the Widget, its attached Label, and its background EventBox."""
        # Eventful, 'box'
        if self.box:
            self.box.show()

        else:
            self.widget.show()

        if self.label_box:
            self.label_box.show()
        elif self.label:
            self.label.widget.show()
