#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_step import get_sub_type_text, get_type_text
from roller_widget_label import Label
import gtk  # type: ignore

# Use post-fix attribute string to create DNA attribute.
DNA_ATTRIBUTE_SET = {
    'labeled', 'make_vbox', 'node', 'parent_node', 'per', 'preset',
    'simple', 'super_preset', 'switched', 'make_vbox'
}


class DNA:
    """Track a UI item's role."""

    def __init__(self, key, true_attr_set, attr_d):
        """
        key: string
            un-parsed Preset, Node, or SuperPreset key

        true_attr_set: set
            {boolean attribute string, ...}
            Set this instance's attribute to True.
            Set exception boolean attribute to False.

        attr_d: dict
            {attribute string: attribute value}
            Tracked attribute:
                node, text, vbox, model, any_group
        """
        # mandatory attribute
        self.node = self.type_ = self.label = self.sub_type = None
        self.key = key

        self.set_type(key)

        # attribute with non-boolean value set by 'attr_d'
        self.label_text = \
            self.vbox = \
            self.model = \
            self.any_group = None

        for k, a in attr_d.items():
            setattr(self, k, a)

        # boolean attribute
        false_attr_set = DNA_ATTRIBUTE_SET - true_attr_set

        for n in true_attr_set:
            setattr(self, 'is_{}'.format(n), True)

        for n in false_attr_set:
            setattr(self, 'is_{}'.format(n), False)

        if self.is_make_vbox:
            self.vbox = gtk.VBox()
        if not self.is_switched and self.vbox:
            if self.label_text is None:
                self.label_text = self.type_

            self.label = Label(
                text="{}".format(self.label_text),
                padding=(4, 4, 4, 4),
                expand=True
            )
            self.vbox.add(self.label)

    def inherit(self, dna, is_labeled):
        """
        Copy another DNA's attribute's to this DNA.

        dna: DNA
            Copy.
        """
        for k in DNA_ATTRIBUTE_SET:
            n = 'is_' + k
            setattr(self, n, getattr(dna, n))
        if self.is_labeled and is_labeled:
            self.label = Label(
                text=self.type_, padding=(4, 4, 4, 4), expand=True
            )
            self.vbox.add(self.label)

    def get_parent_node(self):
        return self.parent_node

    def rename(self, key):
        """
        Rename the item's key and item attributes.

        key: string
            Identity
        """
        self.key = key
        self.set_type(key)

    def set_type(self, key):
        self.type_ = get_type_text(key) if key is not None else None
        self.sub_type = get_sub_type_text(key) if key is not None else None
