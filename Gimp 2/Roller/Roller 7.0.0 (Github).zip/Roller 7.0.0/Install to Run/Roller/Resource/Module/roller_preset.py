#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from random import randint, seed
from roller_constant import Step as sk
from roller_constant_identity import Identity as de
from roller_container import Globe
from roller_gimp_image import (
    add_layer, clip_to_wip, create_image, image_copy_all, paste_layer
)
from roller_gimp_layer import rotate_layer
from roller_helm import Helm
from roller_utility import calc_rotated_image_span
from roller_wip import Wip, get_factor


def calc_margin(d):
    """
    Return margin values after adding their fixed and factor value together.

    d: dict or None
        Margin Preset

    Return: list
        top, bottom, left, right
        of numeric
    """
    top = bottom = left = right = 0
    w, h = Wip.get_size()

    if d and d[de.SWITCH]:
        top = get_factor(d[de.TOP], h)
        bottom = get_factor(d[de.BOTTOM], h)
        left = get_factor(d[de.LEFT], w)
        right = get_factor(d[de.RIGHT], w)

        # Compensate for margin overflow
        # by reserving one pixel for the image.
        if top + bottom >= h:
            top = h / 2.
            bottom = h - top - 1
        if left + right >= w:
            left = w / 2.
            right = w - left - 1
    return top, bottom, left, right


def calc_shift_rect(d):
    """
    Calculate a rectangle from another rectangle given a Shift Preset.

    d: dict
        Shift Preset

    Return: tuple
        x, y, w, h
        the transformed rectangle
    """
    if d and d[de.SWITCH]:
        combine_seed(d)

        w, h = Wip.get_size()

        # size
        w1 = get_factor(d[de.WIDTH_MOD], w)
        h1 = get_factor(d[de.HEIGHT_MOD], h)
        shift_w = get_factor(d[de.JITTER_W], w)
        shift_h = get_factor(d[de.JITTER_H], h)
        w1 += randint(-shift_w, shift_w)
        h1 += randint(-shift_h, shift_h)

        # position
        x = get_factor(d[de.OFFSET_X], w)
        y = get_factor(d[de.OFFSET_Y], h)
        shift_x = get_factor(d[de.JITTER_X], w)
        shift_y = get_factor(d[de.JITTER_Y], h)
        x += randint(-shift_x, shift_x)
        y += randint(-shift_y, shift_y)
        x, y, w, h = map(round, (map(int, (x, y, w, h))))
        return x, y, w1, h1

    # no change
    return .0, .0, .0, .0


def combine_seed(d):
    """
    Seed Python's random output with combined global and local seed values.

    d: dict
        Has a SEED option.
    """
    seed(int(Globe.seed + d[de.RANDOM_SEED]))


def do_rotated_layer(d, p, group, offset):
    """
    Create an enlarged layer before rotating.
    Use a callback to process the rotated layer.

    d: dict
        Has options.

    p: callback
        Act on the rotated layer before it is finished.

    group: layer
        output parent group

    offset: int
        output position in destination group

    Return: layer
        the rotated layer
    """
    j = group.image
    w, h = map(int, Wip.get_size())
    f = d[de.ANGLE]

    if f:
        # Create a new image for the rotation.
        a = calc_rotated_image_span(w, h)
        j1 = create_image(a, a)
        z = add_layer(j1, None, 0, "Rotate")

    else:
        j1 = create_image(w, h)
        z = add_layer(j1, None,  0, "Rotate")

    z = p(z, d)

    if f:
        rotate_layer(z, f)

    image_copy_all(j1)

    if not group.layers:
        # Need a layer to paste on top of.
        base = add_layer(j, group, 0, "Base")
        z = paste_layer(group.layers[offset])
        pdb.gimp_image_remove_layer(j, base)

    else:
        z = paste_layer(group.layers[offset])

    if f:
        pdb.gimp_layer_resize_to_image_size(z)
        clip_to_wip(z)

    pdb.gimp_image_delete(j1)
    return z


def find_visible_preset():
    """
    Find the Model-name-step-key of the visible Preset AnyGroup.
    A terminal option group, a leaf, in the navigation tree is never a Node.

    Return: tuple
        (item key, ...)
    """
    def _shoot(_any_group, _go):
        """
        Find the step-key of the visible selected AnyGroup.

        _any_group: AnyGroup
            Has DNA.

        _go: bool
            If True, then the recursion is done.
        """
        _name_step_k = None

        if _go:
            _node = _any_group.get_node()
            _i = _node.get_selected_r()
            _dna = _node.get_item_by_row(0 if _i is None else _i)
            _name_step_k = _dna.any_group.name_step_k

            if not _dna.is_node:
                _go = False
            else:
                _next_any_group = get_group(_name_step_k)
                if _next_any_group.get_node():
                    _go, _name_step_k = _shoot(_next_any_group, _go)
        return _go, _name_step_k

    get_group = Helm.get_group
    return _shoot(get_group(sk.STEPS), True)[1]


def get_line_fill_state(d):
    """
    Let the caller know the boolean fill-state given the stroke method
    found in a provided Line Preset.

    If the stroke method is the brush-method, then the fill-state
    is True.

    d: dict
        Line Preset

    Return: bool
        Is True, if the stroke-method is the brush-method.
    """
    # METHOD, '0' or '1'; line or brush
    return bool(d[de.METHOD])


def get_heat_d():
    """
    Find the Light AnyGroup and extract its Heat dict.

    Return: dict or None
        Heat Preset
    """
    any_group = Helm.get_group(de.LIGHT)
    return any_group.get_heat_d()


def get_option_list_key(d):
    """
    Find the choice, a Preset, key in a OptionList Preset.

    d: dict
        OptionList Preset

    Return: string or None
        key to the option in the OptionList Preset
        Is None if there is a failure as in an empty dict.
    """
    return d.keys()[0]


def get_option_list_choice(d):
    """
    Fetch an OptionList key and the option's Preset.

    d: dict
        OptionServe Preset

    Return:tuple
        (Preset key, Preset value dict)
    """
    # There's only one key.
    e = d.get(de.OPTION_LIST)

    if e:
        k = e.keys()[0]
        return k, e[k]
    return None, None
