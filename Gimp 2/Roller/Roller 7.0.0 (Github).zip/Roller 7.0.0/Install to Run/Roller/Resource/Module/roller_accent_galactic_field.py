#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (      # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_COLOR_ERASE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_HARD_MIX,
    LAYER_MODE_SOFTLIGHT,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_deco_output import init_deco_type
from roller_def_access import get_default_d
from roller_gimp_mode import get_gradient_mode
from roller_gegl import emboss, unsharp_mask, waterpixels
from roller_gimp_selection import select_rect
from roller_gimp_group_layer import merge_group_layer
from roller_gimp_image import insert_copy_above, make_group_layer
from roller_gimp_layer import blur_selection, clone_layer, hide_layer
from roller_maya_sub_accent import SubAccent
from roller_wip import Wip


def do_matter(maya):
    """
    Make a matter layer.

    maya: GalacticField
    Return: layer
        GalacticField material
    """
    def _make_group():
        return make_group_layer(Run.j, parent, 0, "WIP", z=z)

    j = Run.j
    d = maya.value_d
    parent, group = maya.init_background_groups(j)
    z = maya.bg_z
    maya.bg_z = None
    key = de.GALACTIC_FIELD
    n = "Dotify"
    z1 = clone_layer(z, n=n)
    z1.mode = LAYER_MODE_DIFFERENCE

    pdb.plug_in_gimpressionist(j, z1, n)

    z2 = insert_copy_above(z1, group.layers[0])
    z2.mode = LAYER_MODE_HARD_MIX

    emboss(z2, Globe.azimuth, 12, 3)

    n = "Embroidery"
    z3 = clone_layer(z, n=n)
    z3.mode = LAYER_MODE_COLOR_ERASE

    pdb.plug_in_gimpressionist(j, z3, n)

    z4 = insert_copy_above(z, group.layers[0])

    hide_layer(z3)
    blur_selection(z, 500)

    z5 = insert_copy_above(z4, group.layers[0])
    z5.mode = LAYER_MODE_SOFTLIGHT

    hide_layer(z1)
    hide_layer(z2)

    z = merge_group_layer(group, n="Group 1")
    group = _make_group()
    z1 = clone_layer(z, n="Difference")
    z1.mode = LAYER_MODE_DIFFERENCE

    unsharp_mask(z1, 3., .5, .0)

    z = insert_copy_above(z1, group.layers[0])
    z.mode = LAYER_MODE_SOFTLIGHT

    hide_layer(z1)

    z = merge_group_layer(group, n="Group 2")
    group = _make_group()
    z = clone_layer(z, n="Grain Extract")
    z.mode = LAYER_MODE_GRAIN_EXTRACT
    z.opacity = 40.

    waterpixels(z)
    blur_selection(z, 8)

    z = clone_layer(z, n="Difference")
    z.mode = LAYER_MODE_DIFFERENCE
    z.opacity = 100.
    z = merge_group_layer(group, n=key + " WIP")
    e = maya.gradient_d

    e.update(d)

    e[de.GRADIENT] = d[rk.RW1][de.GRADIENT]
    arg, p = init_deco_type(de.GRADIENT, j, maya, parent, e, 0, False)
    maya.rect = Wip.get_rect()

    select_rect(j, *maya.rect)

    z = p(*arg)
    z.mode = get_gradient_mode(d)
    z.opacity = d[de.GRADIENT_OPACITY]

    pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.RW1]
    )


class GalacticField(SubAccent):
    """Create Accent output."""
    kind = de.GALACTIC_FIELD

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
        self.gradient_d = get_default_d(de.GRADIENT_FILL)
