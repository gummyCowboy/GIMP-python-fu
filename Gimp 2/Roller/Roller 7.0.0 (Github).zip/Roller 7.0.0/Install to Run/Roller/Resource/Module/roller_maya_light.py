#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_REPLACE, pdb  # type: ignore
from roller_any_group import ManyGroup
from roller_constant import Issue as vo, Row as rk, Signal as si, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Lit, Run
from roller_deco_output import init_deco_type
from roller_gimp_image import check_matter
from roller_gimp_selection import select_rect
from roller_gimp_layer import discard_mask, hide_layer, not_empty
from roller_image_change import ref_get_image, ref_on_group_change
from roller_mask_router import attach_mask_sel, make_mask_sel
from roller_maya import Maya
from roller_maya_mask import Mask
from roller_preset_mod import do_mod
from roller_ring import Ring
from roller_wip import Wip


def do_mask(maya, d):
    """
    Mask the maya's matter layer given the current selection
    and a Mask Preset. Replace an existing mask if one exists
    by removing it from the matter layer.

    maya: Light
    d: dict
        Mask Preset
    """
    z = maya.matter

    discard_mask(z)
    pdb.gimp_image_select_item(z.image, CHANNEL_OP_REPLACE, z)
    make_mask_sel(z.image, maya, d)
    attach_mask_sel(z)


def do_matter(maya):
    """
    Create a Light matter layer from the Light's
    option group's Widget values in the UI.

    maya: Work
    Return: layer
        Light material
    """
    j = Run.j
    d = maya.value_d
    offset = 0
    maya.rect = Wip.get_rect()

    if j.layers:
        offset = len(j.layers)

    arg, p = init_deco_type(d[de.TYPE], j, maya, None, d, offset, False)

    select_rect(j, *maya.rect)

    z = p(*arg)

    if z:
        if not_empty(z):
            z = do_mod(z, d[rk.RW1][de.MOD])

    if z:
        hide_layer(z)
        z.name = "Light {}".format(d[de.TYPE])
    return z


class Light(ManyGroup):
    """
    Create a Light Preset's Widget group and assign view-type runners.
    Connect the image reference change monitor to the
    AnyGroup's value-changed event.
    """
    image_slot_count = 2

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)
        self.latch(self, (si.GROUP_CHANGE, ref_on_group_change))

    def get_heat_d(self):
        """
        Retrieve the Heat dict.

        Return: dict or None
            Heat Preset
        """
        d = self.get_value_d()
        if d:
            return d[rk.RW2][de.HEAT]

    @staticmethod
    def get_image_d(d):
        """
        Image assignment expects this function, but there is no image.

        d: dict
            Light Preset

        Return: dict
            Image Choice Preset
        """
        return d.get(de.IMAGE_CHOICE, {})

    @staticmethod
    def get_keys():
        return [None]


class Plan(Maya):
    """
    For the Light AnyGroup, create a plan-view-type
    runner that doesn't have layer output.
    """
    issue_q = ()
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Maya.__init__(self, any_group, 0, (), vo.NO_VOTE)

    def do(self):
        """
        Ths plan-view-type doer doesn't have Light matter output.

        Return: None
            for undo
        """
        return


class Work(Maya):
    """Manage Peek, Preview, and final view layer output."""
    put = (check_matter, 'matter'),
    issue_q = 'matter',
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Maya.__init__(
            self,
            any_group,
            1,
            Work.put,
            [
                (),
                (de.IMAGE_CHOICE,),
                (rk.RW1,),
                (rk.RW1, de.MASK),
                (rk.RW1, de.MOD),
                (rk.RW1, de.MOD, de.BLUR_D)
            ]
        )

        self.viewed_image = None
        self.do_matter = do_matter
        self.sub_maya[sm.MASK] = Mask(
            any_group, self, 1, do_mask, self.get_mask_d, (rk.RW1, de.MASK)
        )
        self.latch(any_group.booth, (si.VOTE_CHANGE, self.on_light_change))

    def do(self):
        """Manage Light layer output during a work-view-type run."""
        d = self.value_d = self.any_group.get_value_d()
        self.go = d[de.SWITCH]

        self.realize()

        if self.go:
            if self.matter:
                self.sub_maya[sm.MASK].do(d[rk.RW1][de.MASK], self.is_matter)

        Lit.z = self.matter
        self.reset_issue()

    def get_mask_d(self):
        return self.any_group.get_sub_widget_a(rk.RW1, de.MASK)

    def get_switch(self):
        return self.any_group.get_widget_a(de.SWITCH)

    def get_value_d(self):
        return self.any_group.get_value_d()

    def on_light_change(self, *_):
        """
        Respond to change in Light option.
        Notify Light subscriber.

        _: tuple
            (AnyGroup; Sent the signal.,
            dict; AnyGroup's vote collection)
        """
        Ring.plug(si.LIGHT_CHANGE, self.is_matter)

    def prep(self):
        """
        Determine if a relevant Light Preset's Image reference has changed.
        On change, update the classes' matter-changed flag.
        """
        d = self.get_value_d()
        if d[de.TYPE] == de.IMAGE:
            j = self.viewed_image
            j1 = self.viewed_image = ref_get_image(self.any_group, None, 0)
            self.is_matter |= j != j1
