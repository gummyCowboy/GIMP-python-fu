#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_container import The
from roller_constant import Node as nw, Signal as si, Step as sk
from roller_constant_identity import Identity as de
from roller_def_access import get_default_d
from roller_def_tree import DEFAULT_MODEL_BRANCH_D
from roller_helm import Helm
from roller_utility import make_split_key
from roller_widget_preset import Preset
from roller_step import (
    append_parts,
    connect_sub_str,
    get_branch_value_d,
    get_first_part,
    get_last_part,
    get_model,
    get_parts
)

"""
A SuperPreset dict has the following structure:

OrderedDict:
    {Model-name-step-key: Preset value dict}
"""

# Model Preset key
SUPER_MODEL_LIST = (
    de.PRESET_BOX,
    de.PRESET_CELL,
    de.PRESET_PYRAMID,
    de.PRESET_SIDEWALK,
    de.PRESET_STACK,
    de.PRESET_TABLE
)

SPLIT_LEAF_KEY = {de.PRESET, de.TYPE}


def get_dna_key_default_value(any_group):
    """
    Get the default value for an option.

    any_group: AnyGroup
    """
    return get_default_d(any_group.dna.key)


def get_model_default_value(any_group):
    """
    Create a SuperPreset with a Model's default value.

    any_group: AnyGroup
        Identify Model SuperPreset.

    Return: dict
        Model specific SuperPreset
    """
    d = {}
    model_type = any_group.dna.sub_type
    name = any_group.dna.model.model_name

    # Convert Model-type-step-key to Model-name-step-key.
    # the default Model branch list, 'q'
    q = DEFAULT_MODEL_BRANCH_D[model_type]

    for step_k in q:
        key = get_last_part(step_k)

        if key not in SPLIT_LEAF_KEY:
            e = get_default_d(key)

        else:
            e = get_default_d(make_split_key(key, model_type))
        d[connect_sub_str(name, step_k)] = e

    d[name] = None
    return d


def get_steps_default(_):
    """
    Make a Steps Preset having a default value.

    _: AnyGroup
    """
    return {
        step_k: get_default_d(step_k)
        for step_k in sk.DEFAULT_STEPS_PRESET_LIST
    }


def load_super(d):
    """
    Load Widget from a SuperPreset dictionary.

    d: dict
        SuperPreset
        {Model-name-step-key: AnyGroup value dict}
    """
    # Set the values of the options.
    # an AnyGroup value dict, 'e'
    # Model-name-step-key, 'k'
    for k, e in d.items():
        any_group = Helm.get_group(k)
        if any_group:
            a = any_group.dna
            if a.is_preset or a.is_simple:
                any_group.load_widget_d(e)


def select_node(d):
    """
    Peruse a SuperPreset value dict finding Node item.
    For each, Node item signal the Node to select a row.

    d: dict
        {Model-name-step-k: value dict}
    """
    # Model-name-step-key, 'k'
    for k, a in d.items():
        any_group = Helm.get_group(k)
        if any_group:
            node = any_group.get_node()
            if node:
                e = a.get(de.NODE)

                if e:
                    # {selected row: row}, 'e'
                    row = e[nw.SELECTED_ROW]
                    node.emit(si.SELECT_ITEM, row)
                else:
                    # default behavior
                    node.emit(si.SELECT_ITEM, 0)
        if k == de.MODEL:
            # ModelList has Model/Node selected row.
            select_node(d[k][de.MODEL_LIST][de.ACTIVE])


class SuperPreset(Preset):
    """
    Has multiple Preset where its Preset has a Preset key that is
    a step-name-key which defines the step type and content.

    it's value -> {Model-name-step-key: Preset value dict}
    """

    def __init__(self, **d):
        """
        d: dict
            Has keyword init values.
        """
        Preset.__init__(self, **d)

    def get_a(self):
        """
        Assemble a SuperPreset dictionary for saving.

        Return: dict
            SuperPreset
            {Model-name-step-key: Preset value dict}
        """
        if self.preset_key == de.PRESET_STEPS:
            k = sk.STEPS

        elif self.preset_key == de.SHADOW_PRESET:
            # Shadow has a comma in its Preset key.
            k = de.SHADOW

        else:
            # Model types
            k = get_first_part(self.any_group.name_step_k)
        return get_branch_value_d(k)

    def get_default_super_preset(self):
        """
        Create a default SuperPreset value.

        Return: dict
            {Model-name-step-key: Preset value dict}
        """
        return deepcopy(DEFAULT_SUPER_PRESET_D[self.preset_key](
            self.any_group)
        )

    @staticmethod
    def get_init_d(*_):
        """
        A SuperPreset group during its
        initialization is empty having no Widget.
        """
        return {}

    def load_a(self, d):
        """
        Override the WidgetRow function.
        Re-route call to 'set_ui'

        d: dict or None
            {Model-name-step-key: Preset value dict}
        """
        self.set_ui(d)

    def update_model_tree(self, d):
        """
        When loading a Model Preset, the navigation
        tree is transformed by the incoming step list.

        d: dict
            Model SuperPreset
            {Model-name-step-key: Preset value dict}
        """
        # Add or update Model.
        model = get_model(self.any_group.name_step_k)
        model_name = model.model_name
        model_type = model.model_type
        a = The.model_list
        old_r = a.get_model_row(model_name)
        new_model_name = get_first_part(d.keys()[0])

        a.delete_model(model_name)

        new_model_name = a._fix_model_name(new_model_name, model_type)

        a.create_model(new_model_name, model_type)

        new_r = a.get_model_row(new_model_name)

        if new_r != old_r:
            a.change_row_position(old_r, new_r)

        # Rename Model name in the incoming SuperPreset
        # with the new Model name prefix.
        # {Renamed Model-name-step-key: Preset value dict}, 'e'
        e = {}

        for k, d1 in d.items():
            parts = get_parts(k)
            k = append_parts(new_model_name, parts[1:])
            e[k] = d1
        a.add_model_step(new_model_name, model_type, e)

    def set_ui(self, d):
        """
        Load a SuperPreset Widget collective.

        d: dict
            SuperPreset
            {Model-name-step-key: Preset value dict}
        """
        The.load_count += 1

        if not d:
            d = self.get_default_super_preset()

        if self.preset_key in SUPER_MODEL_LIST:
            self.update_model_tree(d)

        load_super(d)
        select_node(d)
        The.load_count -= 1


# {SuperPreset key: function; get the default value}
DEFAULT_SUPER_PRESET_D = {
    de.PRESET_STEPS: get_steps_default,
    de.PRESET_BOX: get_model_default_value,
    de.PRESET_CELL: get_model_default_value,
    de.PRESET_STACK: get_model_default_value,
    de.PRESET_TABLE: get_model_default_value,
    de.SHADOW_PRESET: get_dna_key_default_value
}
