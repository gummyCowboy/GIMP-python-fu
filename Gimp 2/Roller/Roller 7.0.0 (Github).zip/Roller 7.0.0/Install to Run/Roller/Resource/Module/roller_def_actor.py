#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_comm import show_err
from roller_constant import (
    Accent as by,
    Background as ba,
    Below as be,
    Bump as fb,
    Color as co,
    Deco as dc,
    Define as df,
    Frame as ek,
    Fill as fl,
    Gradient as fg,
    Grid as gr,
    Justification as ju,
    Image as fi,
    Light as ig,
    Mask as ms,
    Noise as ni,
    Resize as fz,
    Shape as sh
)
from roller_container import Cat, Path
from roller_gimp_mode import EDGE_MODE_LIST, MODE_LIST
from roller_image_pic import Pic
import glob
import os


# Reduce memory consumption with a Combobox-value getter.
def get_background_type_list():
    return ba.TYPE_LIST


def get_below_type_list():
    return be.TYPE_LIST


def get_box_type_list():
    return sh.BOX_TYPE_LIST


def get_brush_list():
    return Cat.brush_list


def get_bump_type_list():
    return fb.TYPE_LIST


def get_camo_type_list():
    return ek.CAMO_TYPE_LIST


def get_cell_shape_list():
    return sh.CELL_SHAPE_LIST


def get_criterion_list():
    return fl.CRITERION_LIST


def get_component_list():
    return co.COMPONENT_LIST


def get_corner_type_list():
    return ms.CORNER_TYPE_LIST


def get_deco_type_list():
    return dc.TYPE_LIST


def get_edge_mode_list():
    return EDGE_MODE_LIST


def get_frame_list():
    """
    Make a list of frame file for Over/Type.

    Return: list
        of GIMP-opened image name
    """
    files = []
    frame_list = ["None"]
    go = False

    try:
        # Ignore sub-directories.
        files = glob.glob(Path.frame + os.path.sep + "*.png")
        go = True

    except Exception as ex:
        show_err(ex)
        show_err("Roller was unable to load frame images.")

    if go:
        for i in files:
            frame_list.append(os.path.splitext(os.path.basename(i))[0])
    return frame_list


def get_accent_type_list():
    return by.ACCENT_TYPE_LIST


def get_frame_overlay_type_list():
    return ek.OVERLAY_TYPE_LIST


def get_gradient_angle_list():
    return fg.GRADIENT_ANGLE_LIST


def get_gradient_list():
    return Cat.gradient_list


def get_gradient_type_list():
    return fg.GRADIENT_TYPE_LIST


def get_grid_type_list():
    return gr.TYPE_LIST


def get_hexagon_type_list():
    return ms.HEXAGON_TYPE_LIST


def get_image_name_list():
    return Pic.name_list


def get_image_type_list():
    return fi.IMAGE_TYPE_LIST


def get_justification_type():
    return ju.TYPE_LIST


def get_light_type_list():
    return ig.TYPE_LIST


def get_mask_list():
    return ms.TYPE_LIST


def get_mesh_type_list():
    return by.MESH_TYPE_LIST


def get_mode_name_list():
    return MODE_LIST


def get_news_type_list():
    return by.NEWS_TYPE_LIST


def get_noise_list():
    return ni.NOISE_TYPE_LIST


def get_octagon_type_list():
    return ms.OCTAGON_TYPE_LIST


def get_decay_type_list():
    return ek.DECAY_TYPE_LIST


def get_pattern_list():
    return Cat.pattern_list


def get_pin_list():
    return gr.PIN_LIST


def get_profile_list():
    return ek.PROFILE_LIST


def get_rectangle_type_list():
    return ms.RECTANGLE_TYPE_LIST


def get_resize_type_list():
    return fz.RESIZE_TYPE_LIST


def get_reverb_type_list():
    return by.REVERB_TYPE_LIST


def get_shape_list():
    return sh.SHAPE_LIST


def get_shaped_list():
    return fg.SHAPED_TYPE_LIST


def get_spiral_mod_list():
    return by.SPIRAL_MOD_LIST


def get_triangle_type_list():
    return ms.TRIANGLE_TYPE_LIST


def get_wave_fill_type_list():
    return by.WAVE_FILL_TYPE


def get_wrap_types():
    return ek.WRAP_TYPE_LIST
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


def scour(d, e, seek):
    """
    Recursively peruse a group definition dict collecting Widget init value.

    d: dict
        Reflect group tree structure.
        {Identity: option value or dict of option value}

    e: dict
        Is an option group definition.

    seek: string
        Is the Identity to collect in the data definition tree.

    Return: dict
        with option value
    """
    for k, a in e.items():
        if isinstance(a, dict):
            if seek in a:
                d[k] = a[seek]
            else:
                if k == df.SUB:
                    # The SUB key is not part of the value dict.
                    b = d
                else:
                    b = d[k] = {}

                scour(b, a, seek)
                if not b and k in d:
                    d.pop(k)
    return d
