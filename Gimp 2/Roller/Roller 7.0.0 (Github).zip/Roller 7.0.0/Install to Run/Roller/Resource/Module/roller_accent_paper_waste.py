#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import LAYER_MODE_GRAIN_EXTRACT, pdb   # type: ignore
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gegl import cubism, median_blur, neon, pixelize
from roller_gimp_image import make_group_layer
from roller_gimp_layer import clone_layer
from roller_maya_sub_accent import SubAccent
from roller_wip import Wip, get_factor_w, get_factor_h


def do_matter(maya):
    """
    Make a matter layer.

    maya: PaperWaste
    Return: layer
        'matter'
    """
    j = Run.j
    d = maya.value_d
    z = maya.bg_z
    maya.bg_z = None
    parent = make_group_layer(
        j, maya.group, maya.get_light(), "Condenser", z=z
    )
    w = max(1, int(get_factor_w(d[de.BLOCK_W])))
    h = max(1, int(get_factor_h(d[de.BLOCK_H])))
    z1 = clone_layer(z, n="Curvy")

    # background color, 'z'
    pixelize(z, *Wip.get_size())

    # shredded curvy edge with alpha holes, 'z1'
    pixelize(z1, w, h)
    median_blur(z1, (w + h) / 4, 50.)
    cubism(z1, 9., 3.)
    cubism(z1, 6., 3.)
    cubism(z1, 3., 3.)

    # bumpy paper stack, 'z2'
    z2 = clone_layer(z1, n="Bumpy")

    neon(z2, 5., .0)

    z2.mode = LAYER_MODE_GRAIN_EXTRACT
    z2.opacity = 50.
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class PaperWaste(SubAccent):
    """Create Accent output."""
    kind = de.PAPER_WASTE

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
