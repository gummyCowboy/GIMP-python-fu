#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, pdb   # type: ignore
from random import uniform, randint, seed
from roller_constant import Frame as ek, Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_frame import do_alt_frame
from roller_frame_alt import AltWrapFiller
from roller_gimp_image import add_layer
from roller_gimp_layer import blur_selection, clone_layer
from roller_gimp_selection import select_channel
from roller_preset_mod import do_mod

COLOR_BALANCE = (
    (-100., 100., 100.),
    (-100., -100., 100.),
    (-100., 100., -100.),
    (100., -100., -100.),
    (100., -100., 100.),
    (100., 100., -100.)
)


def do_matter(maya):
    """
    Make Wrap.

    maya: Ceramic
    Return: layer
        Wrap frame
    """
    return do_alt_frame(maya)


def do_filler(maya):
    """
    Draw Filler material.

    maya: AltFiller
    Return: layer
        Ceramic Filler material
    """
    j = Run.j
    d = maya.value_d
    seed_ = int(Globe.seed + d[de.RANDOM_SEED])
    z = add_layer(j, maya.group, maya.get_light(), "Material")

    pdb.gimp_selection_none(j)
    seed(seed_)

    # random turbulence
    pdb.plug_in_plasma(j, z, seed_, uniform(1., 7.))

    z1 = clone_layer(z)

    # mid-tones, '1'; yes, preserve luminosity,  '1'
    pdb.gimp_color_balance(z1, 1, 1, *COLOR_BALANCE[randint(0, 5)])

    z1.opacity = 30.
    z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

    select_channel(j, maya.filler_sc)
    pdb.plug_in_mosaic(
        j, z,
        d[de.MESH_SIZE],
        1.,                                         # tile height
        .1,                                         # minimum spacing
        d.get(de.NEATNESS, .5),                     # medium neatness
        0,                                          # no split
        Globe.azimuth,
        .0,                                         # minimum color variation
        1,                                          # yes, antialias
        1,                                          # yes, average color
        ek.MESH_TYPE_LIST.index(d[de.MESH_TYPE]),
        0,                                          # smooth surface
        0                                           # black and white grout
    )
    blur_selection(z, 1.5)
    do_mod(z, d[rk.BRW][de.MOD])
    return z


class Ceramic(AltWrapFiller):
    filler_k = de.FILLER_CE
    kind = material = de.CERAMIC
    shade_row = rk.BRW
    wrap_k = de.WRAP_FI

    def __init__(self, any_group, super_maya, k_path):
        AltWrapFiller.__init__(
            self, any_group, super_maya, k_path, do_matter, do_filler
        )
