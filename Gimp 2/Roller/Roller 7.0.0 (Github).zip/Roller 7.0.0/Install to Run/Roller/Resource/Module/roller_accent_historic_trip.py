#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_DISSOLVE,
    LAYER_MODE_GRAIN_MERGE,
    LAYER_MODE_HSV_VALUE,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gegl import emboss, spread, waterpixels
from roller_gimp_image import insert_copy_above, make_group_layer
from roller_gimp_layer import (
    blur_selection, clone_layer, color_layer_default, get_mean_color
)
from roller_maya_sub_accent import SubAccent


def do_matter(maya):
    """
    Make an Accent matter layer.

    maya: HistoricTrip
    Return: layer
        'matter'
    """
    def _merge(_z, _n):
        """
        Merge a group layer and set resulting layer's paint mode.

        _z: group layer
            to merge

        _n: string
            version number

        Return: layer
            Is the result of the merge.
        """
        _z = pdb.gimp_image_merge_layer_group(j, _z)
        _z.mode = LAYER_MODE_GRAIN_MERGE
        _z.name = "Grain Merge " + _n
        pdb.plug_in_colortoalpha(j, _z, (0, 0, 0))
        return _z

    j = Run.j
    d = maya.value_d
    parent, group = maya.init_background_groups(j)
    z = maya.bg_z
    maya.bg_z = None
    key = de.HISTORIC_TRIP
    bg_1 = clone_layer(z, n="Original #1")
    bg_2 = clone_layer(z, n="Original #3")
    group1 = make_group_layer(j, group, 0, key + " WIP #2", z=bg_1)
    group2 = make_group_layer(j, group, 0, "Sub-Group", z=bg_2)
    z2 = clone_layer(bg_1, n="Difference #1")
    z2.mode = LAYER_MODE_DIFFERENCE
    color = get_mean_color(z)
    loop_cnt = int(d[de.ITERATIONS])
    spread_a = int(d[de.SPREAD])

    for _ in range(loop_cnt):
        spread(z2, 0, amount_x=spread_a, amount_y=min(6, spread_a))

    z2 = clone_layer(bg_2, n="Difference #2")
    z2.mode = LAYER_MODE_DIFFERENCE

    for _ in range(loop_cnt):
        spread(z2, 0, amount_x=min(6, spread_a), amount_y=spread_a)

    color_layer_default(z, color)

    z1 = _merge(group1, "#1")
    z2 = _merge(group2, "#2")
    z = insert_copy_above(z2, parent.layers[0])
    dissolve_z = clone_layer(z, n="Dissolve")
    z.mode = LAYER_MODE_HSV_VALUE

    emboss(z1, Globe.azimuth, 12, 1)
    emboss(z2, Globe.azimuth, 12, 1)
    waterpixels(z, size=int(d[de.SUPERPIXEL_SIZE]))
    dissolve_z.mode = LAYER_MODE_DISSOLVE
    dissolve_z.opacity = 50.
    blur_selection(dissolve_z, 1)
    insert_copy_above(dissolve_z, parent.layers[0])
    pdb.gimp_image_merge_layer_group(j, group)

    z = pdb.gimp_image_merge_layer_group(j, parent)

    pdb.plug_in_despeckle(
        j, z,
        1,                  # radius
        0,
        -1,                 # black cut-off
        256                 # white cut-off
    )
    return maya.finish(z, d[rk.BRW])


class HistoricTrip(SubAccent):
    """Create Accent output."""
    kind = de.HISTORIC_TRIP

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
