#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import LAYER_MODE_HSV_HUE, pdb   # type: ignore
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_image import make_group_layer
from roller_gimp_layer import blur_selection, clone_layer
from roller_maya_sub_accent import SubAccent


def do_matter(maya):
    """
    Make a matter layer for SoftTouch.

    maya: SoftTouch
    Return: layer or None
        'matter'
    """
    j = Run.j
    d = maya.value_d
    z = maya.bg_z
    maya.bg_z = None
    parent = make_group_layer(
        j, maya.group, maya.get_light(), "Condenser", z=z
    )
    z1 = clone_layer(z)

    blur_selection(z, 500)

    z1.name = "HSV Hue"
    z1.mode = LAYER_MODE_HSV_HUE

    pdb.plug_in_gimpressionist(j, z1, "Painted_Rock")
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class SoftTouch(SubAccent):
    """Create Accent output."""
    kind = de.SOFT_TOUCH

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
