#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_DARKEN_ONLY,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_MULTIPLY,
    pdb
)
from random import randint, uniform
from roller_accent_color_grid import do_color_grid
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_def_access import get_default_d
from roller_gegl import waves
from roller_gimp_context import prep_replace_color_default
from roller_gimp_image import add_sub_maya_group, insert_copy, make_group_layer
from roller_gimp_layer import blur_selection, clone_layer, color_selection
from roller_gimp_selection import select_color
from roller_maya_sub_accent import SubAccent
from roller_preset import combine_seed
from roller_utility import random_rgb
from roller_wip import Wip


def do_matter(maya):
    """
    Make a 'matter' layer for GlassGaw

    maya: GlassGaw
    Return: layer
        Glass Gaw output
    """
    def _do_grid(_merge):
        """
        Mix random grid overlays with waves.

        _merge: bool
            If it's true, the color grid layer
            is merged with the layer below.
        """
        def do_waves():
            """Do waves on a layer."""
            waves(_z, amplitude=uniform(1., 12.), period=uniform(24., w))

        e[de.ROW] = randint(2, 6)
        e[de.COLUMN] = randint(2, 6)
        _z = do_color_grid(e, group)

        select_color(_z, (255, 255, 255))
        color_selection(_z, random_rgb() + (255,))
        select_color(z, (0, 0, 0))
        color_selection(_z, random_rgb() + (255,))
        pdb.gimp_selection_none(j)

        _z.mode = LAYER_MODE_DIFFERENCE

        do_waves()

        if _merge:
            _z = pdb.gimp_image_merge_down(j, _z, CLIP_TO_IMAGE)
            do_waves()
        return _z

    def _make_group(_n):
        return make_group_layer(j, parent, 0, key + _n, z=z)

    j = Run.j
    d = maya.value_d
    e = get_default_d(de.COLOR_GRID)
    key = de.GLASS_GAW
    parent = add_sub_maya_group(maya)
    z = insert_copy(parent, parent, is_hide=True)
    group = _make_group(" Group 1 WIP")
    w = max(25., min(1000., Wip.w, Wip.h))

    prep_replace_color_default()
    combine_seed(d)

    for i in range(4):
        z1 = _do_grid(i != 0)
        z = clone_layer(z1, n="Grid " + str(i + 1))

    # edge amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(j, z, 1., 0, 0)

    z2 = clone_layer(z1, n="Difference")

    blur_selection(z2, 20)

    z2.mode = LAYER_MODE_DIFFERENCE
    z3 = clone_layer(z2, n="Difference 2")
    z3.mode = LAYER_MODE_DIFFERENCE
    z4 = clone_layer(z3, n="Grain Extract")
    z4.mode = LAYER_MODE_GRAIN_EXTRACT
    z.mode = LAYER_MODE_DARKEN_ONLY

    # no linear, '0'
    pdb.gimp_drawable_invert(z, 0)

    blur_selection(z, 4)
    pdb.plug_in_unsharp_mask(
        j, z1,
        3.,                     # radius
        .16,                    # amount
        .0                      # threshold
    )

    group1 = _make_group(" Group 2 WIP")

    for i in (z1, z3, z2, z4, z):
        pdb.gimp_image_reorder_item(j, i, group1, 0)

    z5 = clone_layer(z, n="Erode")

    for _ in range(2):
        pdb.plug_in_erode(
            j, z5,
            1,              # propagate black
            7,              # RGB channels
            1.,             # full rate
            7,              # direction mask
            0,              # lower limit
            128             # upper limit
        )

    blur_selection(z5, 90)
    j.remove_layer(group)

    z5.mode = LAYER_MODE_MULTIPLY
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class GlassGaw(SubAccent):
    """Create Accent output."""
    kind = de.GLASS_GAW

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)
