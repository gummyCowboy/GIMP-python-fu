#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Mold
from roller_constant_identity import Identity as de
from roller_polygon import get_intersection

# Calculate the 'foam' needed for an image placement. The intersection of two
# lines make a 'foam' vertex. The lines are sides of the Face's 'merged'
# rectangle and the Mold rectangle. Define four lines, then intersect them.


def make_h_face(maya):
    """
    Return: list
        foam
        x, y float series in flag-shape order
        Each x, y pair is a polygon vertex.
    """
    q = maya.model.get_facing_foam(maya.k)
    foam_w = q[2] - q[0]
    foam_h = q[5] - q[1]
    merged_x, merged_y, w, h = maya.model.get_facing_merged(maya.k)

    # foam for Mold, 'q1'
    q1 = []

    if w and h:
        # rectangle offset percentage
        x_f = (Mold.x - merged_x) / w
        x1_f = x_f + Mold.w / w
        y_f = (Mold.y - merged_y) / h
        y1_f = y_f + Mold.h / h

        # six coordinates of four lines
        x = x_f * foam_w + q[0]
        x1 = x1_f * foam_w + q[0]
        y = y_f * foam_h + q[1]
        y1 = y1_f * foam_h + q[1]
        y2 = y_f * foam_h + q[3]
        y3 = y1_f * foam_h + q[3]

        # four lines that intersect
        line = (x, q[1]), (x, q[5])
        line_1 = (x1, q[1]), (x1, q[5])
        line_2 = (q[0], y), (q[2], y2)
        line_3 = (q[0], y1), (q[2], y3)

        q1.extend(get_intersection(*line + line_2))
        q1.extend(get_intersection(*line_1 + line_2))
        q1.extend(get_intersection(*line + line_3))
        q1.extend(get_intersection(*line_1 + line_3))
        return q1

    # underflow
    return [.0] * 8


def make_v_face(maya):
    """
    maya: Maya
    Return: list
        foam
        x, y float series in flag-shape order
        Each x, y pair is a polygon vertex.
    """
    q = maya.model.get_facing_foam(maya.k)
    foam_w = q[2] - q[0]
    foam_h = q[5] - q[1]
    merged_x, merged_y, w, h = maya.model.get_facing_merged(maya.k)
    q1 = []

    if w and h:
        # rectangle height offset percentage, '*_f'
        y_f = (Mold.y - merged_y) / h
        y1_f = y_f + Mold.h / h

        # y-factor
        y = y_f * foam_h + q[1]
        y1 = y1_f * foam_h + q[1]
        y2 = y_f * foam_h + q[3]
        y3 = y1_f * foam_h + q[3]

        # x-slope
        y_diff = q[0] - q[4]

        if y_diff:
            slope = (q[1] - q[5]) / y_diff
            x = (y - q[1]) / slope + q[0]
            x1 = (y1 - q[1]) / slope + q[0]
            x2 = (y2 - q[1]) / slope + q[2] + foam_w
            x3 = (y3 - q[1]) / slope + q[2] + foam_w

            # line from NW to SE
            line = (x, y), (x2, y2)
            line_1 = (x1, y1), (x3, y3)

            # rectangle width offset percentage, '*_f'
            x_f = (Mold.x - merged_x) / w
            x1_f = x_f + Mold.w / w

            # x-factor
            x4 = x_f * foam_w + q[0]
            x5 = x1_f * foam_w + q[0]
            x6 = x_f * foam_w + q[4]
            x7 = x1_f * foam_w + q[4]

            # y-slope
            y_diff = q[0] - q[2]
            if y_diff:
                slope = (q[1] - q[3]) / y_diff
                y4 = slope * (x4 - q[0]) + q[1]
                y5 = slope * (x5 - q[0]) + q[1]
                y6 = slope * (x6 - q[4]) + q[5]
                y7 = slope * (x7 - q[4]) + q[5]

                # line from NE to SW
                line_2 = (x4, y4), (x6, y6)
                line_3 = (x5, y5), (x7, y7)

                # foam derived from the Mold rectangle, 'q1'
                q1.extend(get_intersection(*line + line_2))
                q1.extend(get_intersection(*line + line_3))
                q1.extend(get_intersection(*line_1 + line_2))
                q1.extend(get_intersection(*line_1 + line_3))
                return q1

    # underflow
    return [.0] * 8


ROUTE_TRANSFORM = (
    # Cap Transform
    {
        de.BOTTOM: make_v_face,
        de.LEFT: make_v_face,
        de.RIGHT: make_v_face,
        de.TOP: make_v_face
    },

    # Face 1 Transform
    {
        de.BOTTOM: make_h_face,
        de.LEFT: make_v_face,
        de.RIGHT: make_v_face,
        de.TOP: make_h_face
    },

    # Face 2 Transform
    {
        de.BOTTOM: make_h_face,
        de.LEFT: make_v_face,
        de.RIGHT: make_v_face,
        de.TOP: make_h_face
    }
)
