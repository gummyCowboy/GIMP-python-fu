#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_def_access import get_default_d
from roller_gimp_image import add_wip_base
from roller_gimp_layer import color_selection_default, get_mean_color
from roller_gimp_selection import select_rect
from roller_maya_sub_accent import SubAccent
from roller_wip import Wip


def do_matter(maya):
    """
    Make an Accent layer.

    maya: MeanColor
    Return: layer or None
        Accent material
    """
    d = maya.value_d
    z = add_wip_base("Mean Color", maya.group)
    e = get_default_d(de.COLOR_FILL)

    e.update(d)
    select_rect(Run.j, *Wip.get_rect())

    # RGB, 'q'
    q = get_mean_color(maya.bg_z)

    color_selection_default(z, q)
    return maya.finish(z, d[rk.BRW])


class MeanColor(SubAccent):
    """Create Accent output."""
    kind = de.MEAN_COLOR

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
