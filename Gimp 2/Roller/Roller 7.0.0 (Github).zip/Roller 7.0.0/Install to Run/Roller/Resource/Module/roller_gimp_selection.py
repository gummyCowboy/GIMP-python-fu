#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_REPLACE, pdb   # type: ignore
from roller_comm import info_msg
from roller_gimp_item import validate_item


def get_select_coord(j):
    """
    Convert the selection bounds value to float.

    j: GIMP image
        Has selection.

    Return: tuple
        (x, y, x1, y1) of float
    """
    return map(float, pdb.gimp_selection_bounds(j)[1:])


def get_select_bounds(j):
    """
    Convert the selection bounds value to float.

    j: GIMP image
        Has selection.

    Return: tuple
        (is_selection, x, y, x1, y1)
        (bool, float series...)
    """
    q = pdb.gimp_selection_bounds(j)
    return (q[0],) + tuple(map(float, q[1:]))


def invert_selection(j):
    """
    Invert a selection.

    j: GIMP image
        Has selection.
    """
    if not pdb.gimp_selection_is_empty(j):
        pdb.gimp_selection_invert(j)


def select_channel(j, sc, option=CHANNEL_OP_REPLACE):
    """
    Load a previously saved selection.

    j: GIMP image
        Receive selection.

    sc: selection channel
        Is a selection channel from the image.

    option: selection operation
        gimpfu enum
        add, intersect, replace, subtract
    """
    if validate_item(sc):
        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_antialias(0)
        pdb.gimp_image_select_item(j, option, sc)
    elif option == CHANNEL_OP_REPLACE:
        pdb.gimp_selection_none(j)


def select_color(z, q, option=CHANNEL_OP_REPLACE, threshold=.05):
    """
    Select pixel of a color.

    z: layer
        Select its material.

    q: tuple
        RGB color

    option: gimpfu enum
        selection operation type

    threshold: float
        .0 to 1.
        A greater value increases sample match quantity.
    """
    pdb.gimp_context_set_feather(0)
    pdb.gimp_context_set_sample_criterion(0)
    pdb.gimp_context_set_sample_threshold(threshold)
    pdb.gimp_image_select_color(z.image, option, z, q)


def select_ellipse(j, x, y, w, h, option=CHANNEL_OP_REPLACE):
    """
    Make an ellipse selection.

    j: GIMP image
        Receive selection.

    x, y: float
        top-left point of the ellipse

    w: float
        radius width

    h: float
        radius height

    option: GIMP enum
        add, replace, subtract, or intersect
    """
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_context_set_feather(0)
    pdb.gimp_image_select_ellipse(j, option, x, y, w, h)


def select_polygon(j, q, option=CHANNEL_OP_REPLACE):
    """
    Select a polygon defined by an connected array of x, y coordinate.

    j: GIMP image
        Receive selection.

    q: list or tuple
        [x, y, ...]
        Each x, y pair is a point. Connect points by their order.

    option: GIMP enum
        add, subtract, or replace selection
    """
    if q:
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_feather(0)
        pdb.gimp_image_select_polygon(j, option, len(q), q)
    else:
        info_msg("Roller failed to draw a polygon.")


def select_rect(j, x, y, w, h, option=CHANNEL_OP_REPLACE):
    """
    Select a rectangle.

    j: GIMP image
        Receive selection.

    x, y, w, h: float
        Define a rectangle.

    option: GIMP enum
        Modify an existing selection.
    """
    pdb.gimp_context_set_feather(0)
    pdb.gimp_context_set_antialias(0)

    # Correct underflow with '0'.
    pdb.gimp_image_select_rectangle(j, option, x, y, max(.0, w), max(.0, h))


def select_shape(j, q, option=CHANNEL_OP_REPLACE):
    """
    Select a polygon. If there only four values in the polygon
    then select an ellipse from an rectangle (x, y, w, h).

    j: GIMP image
        Receive selection.

    q: tuple
        (x, y, ...) series of vertices
        Connect polygon point series.

    option: enum
        selection operation
        add, subtract, intersect, or replace
        Modify an existing selection.
    """
    if len(q) == 4:
        select_ellipse(j, *q, option=option)
    else:
        select_polygon(j, q, option=option)


def shrink_selection(j, w):
    """
    Shrink a selection. Ensure that antialiasing is on.

    j: GIMP image
        Has selection.

    w: numeric
        Is the shrink amount.
    """
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_selection_shrink(j, int(w))
