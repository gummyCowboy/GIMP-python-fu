#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import Define as df, Row as rk
from roller_constant_identity import Identity as de
from roller_def_dialog import ADD_ABOVE, IMAGE_CHOICE, MOD
from roller_def_option import (
    BACKGROUND_TYPE,
    COLOR_1,
    GRADIENT,
    GRADIENT_ANGLE,
    GRADIENT_TYPE,
    PATTERN,
    SEED
)
from roller_widget_row import WidgetRow


# Define Background Preset.
BACKGROUND = OrderedDict([
    (de.TYPE, deepcopy(BACKGROUND_TYPE)),
    (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (de.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.COLOR_1, deepcopy(COLOR_1)),
    (de.PATTERN, deepcopy(PATTERN)),
    (de.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
    (de.GRADIENT, deepcopy(GRADIENT)),
    (rk.RW1, deepcopy(
        {
            df.SUB: OrderedDict([
                (de.MOD, deepcopy(MOD)),
                (de.ADD_ABOVE, deepcopy(ADD_ABOVE))
            ]),
            df.WIDGET: WidgetRow
        }
    ))
])
