#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_maya import Maya


class SubMaya(Maya):
    """Factor Build and SubBuild. Make layer output for a work-view-type view."""

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        Require 'put' attribute in calling sub-class.

        any_group: AnyGroup
            option owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple or list
            (Identity, ...)
            [(Identity, ...), (Identity, ...)]

        do_matter: function
            Call to make primary layer.
        """
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter
        Maya.__init__(self, any_group, 1, self.put, k_path)


class Build(SubMaya):
    """
    Is for sub-Maya of an option-list sourced Maya.
    Has a 'cast' variable for referencing the super-maya's super-maya.
    """

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        any_group: AnyGroup
            Is the progenitor of this Maya.

        super_maya: Maya
            The superior Maya containing this sub-maya.

        k_path: tuple or list
            Register relevant key-path with AnyGroup's voting mechanism.
            (Identity, ...)
            [(Identity, ...), (Identity, ...)]

        do_matter: function
            Call to make the primary matter layer.
        """
        self.cast = super_maya.super_maya
        SubMaya.__init__(self, any_group, super_maya, k_path, do_matter)


class SubBuild(SubMaya):
    """
    Is for option-list sourced sub-Maya. Has an inherited 'cast' variable
    for retrieving the super-maya's matter layer. Frame-type Maya are in a
    fixed-nest structure with an intermediary super-maya like this:
    super/super/sub.
    """
    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        any_group: AnyGroup
            option owner

        super_maya: Maya
            The superior Maya containing this sub-maya.

        k_path: tuple or list
            (Identity, ...)
            [(Identity, ...), (Identity, ...)]

        do_matter: function
            Call to make primary layer.
        """
        self.cast = super_maya.cast if hasattr(super_maya, 'cast') else None
        SubMaya.__init__(self, any_group, super_maya, k_path, do_matter)
