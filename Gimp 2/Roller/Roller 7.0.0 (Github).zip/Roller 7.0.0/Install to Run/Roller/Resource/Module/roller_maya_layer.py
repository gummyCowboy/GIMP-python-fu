#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Run
from roller_constant_identity import Identity as de
from roller_gimp_mode import translate_mode
from roller_gimp_layer import set_layer_attr, set_layer_mode


def check_mix(maya, issue, mode, opacity):
    """
    Set the maya's matter layer's Mode or Opacity
    when they've changed value.

    Update the current view's background-changed
    flag when either layer property has changed.

    maya: Maya
    issue: string
        Maya sub-attribute
        The string is prefix with 'is_' to create an attribute id.

    mode: string
        GIMP Mode descriptor
        Is the layer's desired Mode.

    opacity: float
        Is the layer's desired opacity.
    """
    z = maya.matter
    if z:
        if getattr(maya, 'is_' + issue):
            Run.is_back |= set_layer_attr(z, translate_mode(mode), opacity)
        else:
            if maya.is_mode:
                Run.is_back |= set_layer_mode(z, translate_mode(mode))
            if maya.is_opacity:
                if z.opacity != opacity:
                    z.opacity = opacity
                    Run.is_back = True


def check_mix_basic(maya):
    """
    Update the maya's matter layer's mode or opacity settings.

    maya: Maya
    """
    d = maya.value_d
    check_mix(maya, 'matter', d[de.MODE], d[de.OPACITY])
