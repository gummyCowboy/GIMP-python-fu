#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Handle(object):
    """
    Manage the birth and death of Signal connection.
    Is a sub-object for Python 2.7.
    """

    def __init__(self):
        self._handle_d = {}

    def latch(self, emitter, arg):
        """
        Make a connection. Remember the connection for erasure on death.

        emitter: object
            Is a gobject that can emit signal

        arg: tuple
            (signal type, function)
            Pass to the connect function.
        """
        self._handle_d[emitter.connect(*arg)] = emitter

    def unlatch(self):
        """Disconnect Signal. Reset the handle dict."""
        for i, a in self._handle_d.items():
            a.disconnect(i)
        self._handle_d = {}
