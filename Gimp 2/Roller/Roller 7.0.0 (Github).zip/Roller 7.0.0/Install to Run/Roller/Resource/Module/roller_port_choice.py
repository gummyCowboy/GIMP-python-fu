#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Dog
from roller_constant import Define as df
from roller_port_preview import PortPreview
from roller_widget_dna import DNA
from roller_widget_tree import ChoiceList


class PortChoice(PortPreview):
    """Display ChoiceWindow Widget."""
    window_key = "Choose Option"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Has a Widget value.
        """
        self._choice_list = None
        self._list = g.get_list()
        PortPreview.__init__(self, d, g)

    def _draw_list_group(self, g):
        """
        Draw the list group.

        g: GTK container
            for list group
        """
        self._choice_list = ChoiceList(
            **{
                df.ANY_GROUP: self.any_group,
                df.FUNCTION: self.get_choice_list,
                df.CHOICE: self.repo.get_a(),
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win,
                df.TREE_COLOR: self.color
            }
        )
        self.treeview = self._choice_list.treeview
        g.pack_start(self._choice_list, expand=True)

    def draw(self):
        """
        Draw Widget.

        g: VBox
            Contain Widget.
        """
        # The NoneGroup is needed for signal and change processing.
        self.any_group = Dog.none_group(**{df.DNA: DNA(None, {'preset'}, {})})

        self.draw_list(
            (self._draw_list_group, self.draw_random_process_group),
            ("Available {}".format(self.repo.key), "")
        )
        self.roller_win.gtk_win.vbox.set_size_request(400, 400)

    def get_choice_list(self):
        return self._list[:]

    def get_group_value(self):
        """
        Fetch the value of the list selection.

        Return: string
            Is the choice from the choice list.
        """
        a = self._choice_list.get_selected_item()

        if a is None:
            if self._list:
                a = self._list[0]
            else:
                a = ""
        return a
