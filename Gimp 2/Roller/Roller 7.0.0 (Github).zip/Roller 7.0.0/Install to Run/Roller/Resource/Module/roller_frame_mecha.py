#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_constant_identity import Identity as de
from roller_frame import do_frame_with_filler
from roller_frame_alt import FrameBasic
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import add_layer, create_image, image_copy_all
from roller_gimp_layer import clipboard_fill, color_layer, color_selection
from roller_gimp_selection import select_rect


def do_matter(maya):
    """
    Make Wrap material.

    maya: Mecha
    Return: layer
        Mecha Wrap 'matter'
    """
    set_fill_context_default()
    return do_frame_with_filler(maya, make_pattern)


def make_pattern(z, d):
    """
    Draw a rectangle on a rotated layer. Create a pattern
    (a black square). Use the clipboard to hold the
    pattern. Fill the provided layer with the pattern.
    Assume selection is none.

    z: layer
        Receive pattern.

    d: dict
        Mecha Preset
        {Identity: value}

    Return: layer
        Has the pattern.
    """
    gap_w = d[de.GAP_W]
    w = gap_w + d[de.LINE_W]
    j1 = create_image(int(w), int(w))
    z1 = add_layer(j1, None, 0, "Pattern")

    color_layer(z1, (255, 255, 255))

    # A rectangle at the center of 'z1' will become a hole in the pattern.
    x = y = d[de.LINE_W] / 2.

    select_rect(j1, x, y, gap_w, gap_w)
    color_selection(z1, (0, 0, 0))

    # Fill the Clipboard buffer.
    image_copy_all(j1)

    pdb.gimp_image_delete(j1)
    clipboard_fill(z)
    pdb.plug_in_colortoalpha(z.image, z, (0, 0, 0))
    return z


class Mecha(FrameBasic):
    filler_k = de.FILLER_ME
    kind = material = de.MECHA
    wrap_k = de.WRAP_PA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
