#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_any_group import ManyGroup
from roller_constant import Issue as vo, Row as rk, Signal as si
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gimp_image import make_plan_group
from roller_ice import Ice
from roller_image_render import create_render
from roller_maya import Maya
from roller_ring import Ring


def check_view_image(maya):
    """
    Process view-image-size change.

    maya: Maya
    Return: None
    """
    if maya.is_matter:
        w, h = Globe.view_size
        w1, h1 = (Run.j.width, Run.j.height) if Run.j else (0, 0)
        if w != w1 or h != h1:
            create_render(w, h)
            Ring.pressure()


def on_delete_plan_change(g):
    """
    Store the Delete Plan setting for global access.

    g: CheckButton
        Delete Plan
    """
    Globe.delete_plan = g.get_ui()


def on_hide_layer_change(g):
    """
    Store the Hide Layer setting for view's layer production.

    g: CheckButton
        Hide Layer
    """
    Ice.is_hide_layer = g.get_ui()


class Global(ManyGroup):
    """Assign view-type runner and connect responsible signal handler."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)

        # Insert responder into the relay.
        for k, p in (
            (de.AZIMUTH, self.on_emboss_change),
            (de.ELEVATION, self.on_emboss_change),
            (de.RENDER_W, self.on_view_size_change),
            (de.RENDER_H, self.on_view_size_change),
            (de.RANDOM_SEED, self.on_seed_change),
            (de.WIP, self.on_view_size_change)
        ):
            g = self.get_widget(k)

            g.relay.insert(0, p)
            p(g)

        g_row = self.get_widget(rk.RW1)

        g_row.get_g(de.HIDE_LAYER).relay.insert(0, on_hide_layer_change)
        g_row.get_g(de.DELETE_PLAN).relay.insert(0, on_delete_plan_change)

    def on_emboss_change(self, _):
        """
        Respond to change in an emboss type Widget.

        _: Widget
            Is responsible.
        """
        g = self.get_widget(de.ELEVATION)
        g1 = self.get_widget(de.AZIMUTH)
        a = Globe.elevation = g.get_ui()
        b = Globe.azimuth = g1.get_ui()
        plan_a, work_a = self.get_view_q(de.ELEVATION)
        plan_b, work_b = self.get_view_q(de.AZIMUTH)
        Ring.plug(
            si.GLOBAL_EMBOSS,
            (
                a != plan_a or a != work_a,
                b != plan_b or b != work_b
            )
        )

    def on_seed_change(self, _):
        """
        Respond to change in the Global Random Seed Widget.

        _: Widget
            Roller type
            Is responsible.
        """
        g = self.get_widget(de.RANDOM_SEED)
        a = Globe.seed = g.get_ui()
        plan_a, work_a = self.get_view_q(de.RANDOM_SEED)
        Ring.plug(si.GLOBAL_SEED, (a != plan_a, a != work_a))

    def on_view_size_change(self, _):
        """
        Respond to a view-image-size option value change. Send a RESIZE vote.

        g: Widget
            a view-image-size type; Has changed.
        """
        g = self.get_widget(de.RENDER_W)
        g1 = self.get_widget(de.RENDER_H)
        g2 = self.get_widget(de.WIP)
        w = g.get_ui()
        h = g1.get_ui()
        a = g2.get_ui()
        plan_w, work_w = self.get_view_q(de.RENDER_W)
        plan_h, work_h = self.get_view_q(de.RENDER_H)
        plan_a, work_a = self.get_view_q(de.WIP)
        Ring.plug(
            si.RESIZE,
            [
                # plan-view-type vote
                w != plan_w or
                h != plan_h or
                a != plan_a,

                # work-view-type vote
                w != work_w or
                h != work_h or
                a != work_a
            ]
        )


class Chi(Maya):
    """Factor Plan and Work Maya."""
    issue_q = 'matter',
    vote_type = vo.MAIN

    def __init__(self, any_group, view_i, put):
        Maya.__init__(self, any_group, view_i, put, ())

    def do(self):
        """
        Return: None
            for undo
        """
        self.realize_vote()


class Plan(Chi):
    """Manage Draft and Plan response to Global option."""
    put = (check_view_image, 'matter'), (make_plan_group, 'group')

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, Plan.put)


class Work(Chi):
    """Manage Peek, Preview, and render response to Global option."""
    put = (check_view_image, 'matter'),

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1, Work.put)
