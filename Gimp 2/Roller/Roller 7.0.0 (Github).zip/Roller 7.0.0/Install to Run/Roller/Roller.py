#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script type: Python-fu
Script Title: Roller
Developed on GIMP version 2.10 with Windows 10, GTK 2.28.7, and GIMP 2.10.38.

What It Does
    Create image composition like wallpaper, an image board, or a collage.

Where The Script Installs
    See the how-to file.

Get the latest version: github.com/gummycowboy
"""
from gimpfu import (
    INTERPOLATION_NOHALO,
    TRANSFORM_FORWARD,
    TRANSFORM_RESIZE_ADJUST,
    main,
    pdb,
    register
)
import os
import pygtk
import sys
pygtk.require("2.0")

error_file = None
IS_DEV_PC = os.environ.get('gummy_cowboy', False)

# Developer: Bypass GEGL library load warning in the error file.
# Set to True if the Roller won't load when GIMP or Roller start.
IS_ASH = False and IS_DEV_PC

# Developer: Is True during development but is False if Roller is a release.
IS_DEV = IS_DEV_PC and not IS_ASH

if IS_ASH:
    # Trace errors by recording them to a file. If
    # the file doesn't exist, create it. Append
    # error messages and piped (">>") print statements.
    error_file = sys.stderr = open("D:\\error.txt", 'a')
    print >> sys.stderr, 'Roller started'               # noqa

# Append Roller paths to "sys.path" for GIMP's Python
# interpreter. "__file__" is GIMP's plug-in path.
# Python 3: 'u' is not needed.
n = os.path.sep
resource_path = os.path.dirname(__file__) + n + u"Resource"
module_path = resource_path + n + u"Module"
frame_path = resource_path + n + u"Frame"

# If a folder path isn't in "sys.path", then add the path.
if module_path not in sys.path:
    sys.path.append(module_path)

# The Python interpreter will now look for
# modules inside the Module folder.
# A limitation to this import method is that the modules are not
# identified by the interpreter as being part of a Python package.
from roller_container import Cat, Dog, Path, Run        # noqa
from roller_gegl import Gegl                          # noqa
from roller_any_group import (                          # noqa
    LonerGroup, ManyGroup, NoneGroup, OptionAnyGroup
)
from roller_def import GROUP_DEF, SUB_GROUP_DEF         # noqa; Initialize.
from roller_def_access import Def                       # noqa
from roller_image_change import (                        # noqa
    on_global_seed, on_helm_change, on_ring_empty
)
from roller_image_ref import Ref                        # noqa
from roller_image_pic import Pic                        # noqa
from roller_option_maya import CLASS_GROUP              # noqa
from roller_port import Port                            # noqa
from roller_view import View                      # noqa
from roller_window_main import WindowMain               # noqa


def start():
    """
    Start the program.

    __________________________________
    Typed Single Letter Variable Usage
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
    a : object; int
    b : See 'a'.
    c : See 'a'; column
    d : dict
    e : dict
    f : float
    g : widget; window
    h : height; horizontal
    i : iteration; index
    j : Image; GIMP image
    k : key
    m : flag; boolean
    n : string
    o : One
    p : function
    q : set, tuple, list, or generator
    r : row
    s : size; sign
    t : Rect
    u : point
    v : point; vertical
    w : width; span, a length
    x : axis coordinate
    y : axis coordinate
    z : layer
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

    ____________________________
    Double Letter Variable Usage
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
    double : reserved import shorthand
    ex : Exception
    sc : Selection Channel
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

    _________________
    Descriptor Prefix
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
    on_function: timing
    has_variable_name: bool
    is_variable_name: bool
    _variable_name: nested variable
    _function_name: nested function
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

    ___________________
    Descriptor Postfix
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
    single variable name: indicate type
    _variable_name_: double nested
    text_: Remove Python keyword conflict.
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

    ___________________
    Capitalized Comment
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
    a class, a UI option, language rule
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

    _______________________________________________________________
    Line Spacing Style or How I Create Patterns in the Code Format.
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
    Over a period of time, I thought I could add some artistic style
    to my code. After much thought and practice, I came up with a code
    format style. This is a short description of the rules I use.

    Observe types of code line: assignment, function, branch, and comment.

    Organize by type: If the line is the same type as the previous line where
    type is either an assignment or a call and not a branch.
        Place the line under the previous line.

    Paragraph with branch: If the line is a logic branch:
        Add a blank line under the previous line.

    Add to Space to comment: If the line is a comment and the previous line
    is not a comment:
        Add a blank line under the previous line.

    Show comment section: For clarity, if a comment reference is specific
        section of code, then add a blank line after last the line of the
        commented section.

    Line Spacing Override
        Tuck last line: If the line is the last line in an indentation block.
            Place the line under the previous non-blank line.

        Group paragraph line: If the previous line is a branch:
            Place the first line under the branch line.

    Lint
        Use Flake8, Pylance, and Code Spell Checker with Microsoft's Visual
        Studio Code.
    ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
    """
    global error_file

    if IS_DEV:
        # Output piped (">>") print statement to a file. If
        # the file doesn't exist, create it, otherwise, append
        # error message and print statement to the existing file.
        import time
        error_file = sys.stderr = open("D:\\error.txt", 'a')
        print >> sys.stderr, "\nRoller,", time.ctime(), "_" * 40, "\n"  # noqa

    # Save the interface context so that it can
    # be restored when the plug-in is done.
    pdb.gimp_context_push()

    Def(GROUP_DEF, SUB_GROUP_DEF)
    Pic()
    Ref(on_helm_change, on_ring_empty, on_global_seed)
    Cat.load()
    Dog.load(CLASS_GROUP, LonerGroup, ManyGroup, NoneGroup, OptionAnyGroup)

    # Improve consistency.
    pdb.gimp_context_set_defaults()

    # Are context used in the entirety of the program.
    pdb.gimp_context_set_brush_aspect_ratio(.0)             # same x and y
    pdb.gimp_context_set_brush_force(1.)
    pdb.gimp_context_set_diagonal_neighbors(1)
    pdb.gimp_context_set_dynamics("Dynamics Off")
    pdb.gimp_context_set_interpolation(INTERPOLATION_NOHALO)
    pdb.gimp_context_set_paint_method('gimp-paintbrush')
    pdb.gimp_context_set_sample_merged(0)
    pdb.gimp_context_set_sample_transparent(1)
    pdb.gimp_context_set_transform_direction(TRANSFORM_FORWARD)
    pdb.gimp_context_set_transform_resize(TRANSFORM_RESIZE_ADJUST)

    # circular reference work-around or global scope class
    Path.resource = resource_path
    Path.frame = frame_path
    Path.preset = os.path.join(resource_path, u"Preset")

    # Connect View with Port ProcessButton handler.
    Port.view = View

    # Reference
    # gimp-forum.net/Thread-GEGL-problem-two-versions
    Gegl.gimp_library = Gegl.load_library('libgimp-2.0')

    WindowMain()

    # Return undo functionality.
    if Run.j and pdb.gimp_image_is_valid(Run.j):
        pdb.gimp_image_undo_enable(Run.j)

    # Restore the interface context.
    pdb.gimp_context_pop()

    if error_file:
        error_file.close()


register(
    # name
    # Is the dialog title as 'python-fu + name'.
    # The space character is not allowed.
    # 'name' is case-sensitive.
    "Roller",

    # tool-tip and window-tip text
    "Render a composition.",

    # help (describe how-to, exceptions and dependencies)
    # Display in the plug-in browser.
    "Creates a new image and does not require an open image.",

    # Display in the plug-in browser.
    "Charles Bartley",

    # Display in the plug-in browser.
    "Charles Bartley",

    # Display in the plug-in browser.
    "2025",

    # menu item descriptor with short-cut key id '_R'
    "_Roller…",

    # image types
    # An empty string is no image needed for plug-in.
    "",

    # plug-in parameters
    [],

    # results
    [],

    # plug-in function handler
    # The second item is the menu's location for the plug-in.
    start, menu='<Image>/Filters/Render')
if __name__ == '__main__':
    main()
