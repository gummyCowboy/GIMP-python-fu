#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, LAYER_MODE_DODGE, pdb   # type: ignore
from roller_a_contain import Run
from roller_constant_key import Material as ma, Option as ok
from roller_frame import select_wrap
from roller_frame_alt import FrameOverlay
from roller_fu import (
    add_layer,
    add_layer_above,
    clear_selection,
    clear_inverse_selection,
    clone_layer,
    make_layer_group,
    merge_layer_group,
    select_item
)
from roller_view_hub import (
    color_layer, color_selection, set_fill_context_default
)
from roller_view_real import get_light
from roller_view_shadow import do_stylish_shadow

"""
Define 'frame_clear' as a Maya-subtype
for managing a variation of Frame type.
"""


def do_matter(maya):
    """
    Make a Wrap frame.

    maya: Clear
    Return: layer
        Wrap 'matter'
    """
    j = Run.j
    d = maya.value_d
    cast = maya.cast.matter
    frame_q = []
    w = d[ok.INNER_FRAME_W]
    group = make_layer_group(j, "Material", maya.group, get_light(maya))

    set_fill_context_default()
    select_item(cast)

    if not pdb.gimp_selection_is_empty(j):
        # Create two layers.
        for i in range(2):
            # Add layer to the bottom of the group layer.
            z = add_layer(j, ("1", "2")[i], group, len(group.layers))

            select_wrap(
                j, cast, (w, d[ok.WIDTH] + w)[i], d[ok.TYPE]
            )
            color_selection(z, (127, 127, 127))

            z = give_edge(j, z)
            frame_q += [z]

        z = do_stylish_shadow(frame_q[0], blur=5., intensity=130.)
        if z:
            select_item(cast)
            clear_selection(z)
    return merge_layer_group(group)


def do_overlay(maya):
    """
    Make a color overlay layer.

    maya: Overlay
    Return: layer
        color overlay
    """
    pdb.gimp_selection_none(Run.j)

    d = maya.value_d
    z = add_layer(Run.j, "Material", maya.group, get_light(maya))

    color_layer(z, d[ok.COLOR_1])
    return z


def give_edge(j, z):
    """
    Give the frame an edge.

    j: GIMP image
        WIP

    z: layer
        Give edge.

    Return: layer
        with edge
    """
    z1 = clone_layer(z, "Material")
    z2 = add_layer_above(z, "Back")

    color_layer(z2, (100, 100, 100))

    z1 = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

    # amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(z.image, z1, 1., .0, .0)

    z1.mode = LAYER_MODE_DODGE

    select_item(z)
    clear_inverse_selection(z1)
    return pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)


class Clear(FrameOverlay):
    kind = material = ma.CLEAR
    overlay_k = ok.OVERLAY_CO
    shade_row = ok.RW1
    wrap_k = ok.WRAP_CL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            option owner

        super_maya: Maya
            deco type

        k_path: tuple
            Is the Option key path to the Frame Button.
        """
        FrameOverlay.__init__(
            self, any_group, super_maya, k_path, do_matter, do_overlay
        )
