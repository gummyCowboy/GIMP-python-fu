#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_acrylic_sky import AcrylicSky
from roller_backdrop_back_game import BackGame
from roller_backdrop_clay_chemistry import ClayChemistry
from roller_backdrop_color_fill import ColorFill
from roller_backdrop_color_grid import ColorGrid
from roller_backdrop_core_design import CoreDesign
from roller_backdrop_crystal_cave import CrystalCave
from roller_backdrop_cube_pattern import CubePattern
from roller_backdrop_cubism_cover import CubismCover
from roller_backdrop_dark_fort import DarkFort
from roller_backdrop_density_gradient import DensityGradient
from roller_backdrop_drop_zone import DropZone
from roller_backdrop_etch_sketch import EtchSketch
from roller_backdrop_fading_maze import FadingMaze
from roller_backdrop_floor_sample import FloorSample
from roller_backdrop_galactic_field import GalacticField
from roller_backdrop_glass_gaw import GlassGaw
from roller_backdrop_gradient_fill import GradientFill
from roller_backdrop_historic_trip import HistoricTrip
from roller_backdrop_image_gradient import ImageGradient
from roller_backdrop_line_stone import LineStone
from roller_backdrop_lost_maze import LostMaze
from roller_backdrop_maze_blend import MazeBlend
from roller_backdrop_mean_color import MeanColor
from roller_backdrop_mystery_grate import MysteryGrate
from roller_backdrop_noise_rift import NoiseRift
from roller_backdrop_paper_waste import PaperWaste
from roller_backdrop_pattern_fill import PatternFill
from roller_backdrop_rainbow_valley import RainbowValley
from roller_backdrop_rect_pattern import RectPattern
from roller_backdrop_rocky_landing import RockyLanding
from roller_backdrop_roof_top import RoofTop
from roller_backdrop_soft_touch import SoftTouch
from roller_backdrop_specimen_speckle import SpecimenSpeckle
from roller_backdrop_spiral_channel import SpiralChannel
from roller_backdrop_square_cloud import SquareCloud
from roller_backdrop_stone_age import StoneAge
from roller_backdrop_trailing_vine import TrailingVine
from roller_backdrop_triangle_reverb import TriangleReverb
from roller_backdrop_wave_fill import WaveFill
from roller_constant_key import BackdropStyle as by, Frame as ek
from roller_frame_basic import Basic
from roller_frame_bevel import Bevel
from roller_frame_brushy import Brushy
from roller_frame_burst import Burst
from roller_frame_camo import Camo
from roller_frame_ceramic import Ceramic
from roller_frame_checker import Checker
from roller_frame_circuit import Circuit
from roller_frame_clear import Clear
from roller_frame_crumble import Crumble
from roller_frame_decay import Decay
from roller_frame_fence import Fence
from roller_frame_glue import Glue
from roller_frame_gradual import Gradual
from roller_frame_holey import Holey
from roller_frame_joint import Joint
from roller_frame_mecha import Mecha
from roller_frame_mirror import Mirror
from roller_frame_over import Over
from roller_frame_overlap import Overlap
from roller_frame_pipe import Pipe
from roller_frame_rad import Rad
from roller_frame_stained import Stained
from roller_frame_stretch import Stretch
from roller_frame_stripe import Stripe
from roller_frame_tape import Tape
from roller_frame_wobble import Wobble

# Find an OptionList choice's class.
# {Frame key: Frame Maya}
CLASS_FRAME = {
    ek.BASIC: Basic,
    ek.BEVEL: Bevel,
    ek.BRUSHY: Brushy,
    ek.BURST: Burst,
    ek.CAMO: Camo,
    ek.CERAMIC: Ceramic,
    ek.CHECKER: Checker,
    ek.CIRCUIT: Circuit,
    ek.CLEAR: Clear,
    ek.CRUMBLE: Crumble,
    ek.DECAY: Decay,
    ek.GRADUAL: Gradual,
    ek.GLUE: Glue,
    ek.HOLEY: Holey,
    ek.JOINT: Joint,
    ek.MIRROR: Mirror,
    ek.OVER: Over,
    ek.PIPE: Pipe,
    ek.RAD: Rad,
    ek.MECHA: Mecha,
    ek.OVERLAP: Overlap,
    ek.STAINED: Stained,
    ek.WOBBLE: Wobble,
    ek.STRETCH: Stretch,
    ek.STRIPE: Stripe,
    ek.TAPE: Tape,
    ek.FENCE: Fence
}

# {Backdrop Style key: Style Maya}
CLASS_BACKDROP_STYLE = {
    by.ACRYLIC_SKY: AcrylicSky,
    by.BACK_GAME: BackGame,
    by.CLAY_CHEMISTRY: ClayChemistry,
    by.COLOR_FILL: ColorFill,
    by.COLOR_GRID: ColorGrid,
    by.CORE_DESIGN: CoreDesign,
    by.CRYSTAL_CAVE: CrystalCave,
    by.CUBE_PATTERN: CubePattern,
    by.CUBISM_COVER: CubismCover,
    by.DARK_FORT: DarkFort,
    by.FADING_MAZE: FadingMaze,
    by.DENSITY_GRADIENT: DensityGradient,
    by.DROP_ZONE: DropZone,
    by.ETCH_SKETCH: EtchSketch,
    by.FLOOR_SAMPLE: FloorSample,
    by.GALACTIC_FIELD: GalacticField,
    by.GLASS_GAW: GlassGaw,
    by.GRADIENT_FILL: GradientFill,
    by.HISTORIC_TRIP: HistoricTrip,
    by.IMAGE_GRADIENT: ImageGradient,
    by.LINE_STONE: LineStone,
    by.LOST_MAZE: LostMaze,
    by.MAZE_BLEND: MazeBlend,
    by.MEAN_COLOR: MeanColor,
    by.MYSTERY_GRATE: MysteryGrate,
    by.NOISE_RIFT: NoiseRift,
    by.PAPER_WASTE: PaperWaste,
    by.PATTERN_FILL: PatternFill,
    by.RAINBOW_VALLEY: RainbowValley,
    by.RECT_PATTERN: RectPattern,
    by.ROCKY_LANDING: RockyLanding,
    by.ROOF_TOP: RoofTop,
    by.SOFT_TOUCH: SoftTouch,
    by.SPECIMEN_SPECKLE: SpecimenSpeckle,
    by.SPIRAL_CHANNEL: SpiralChannel,
    by.SQUARE_CLOUD: SquareCloud,
    by.STONE_AGE: StoneAge,
    by.TRAILING_VINE: TrailingVine,
    by.TRIANGLE_REVERB: TriangleReverb,
    by.WAVE_FILL: WaveFill
}
