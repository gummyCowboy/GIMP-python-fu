#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    ADD_MASK_ALPHA,
    CHANNEL_OP_ADD,
    CHANNEL_OP_INTERSECT,
    CHANNEL_OP_REPLACE,
    CHANNEL_OP_SUBTRACT,
    CLIP_TO_IMAGE,
    HUE_RANGE_ALL,
    LAYER_MODE_NORMAL,
    LAYER_MODE_PASS_THROUGH,
    MASK_APPLY,
    MASK_DISCARD,
    ORIENTATION_HORIZONTAL,
    ORIENTATION_VERTICAL,
    PIXELS,
    RGB,
    RGBA_IMAGE,
    TRANSFORM_FORWARD,
    TRANSFORM_RESIZE_ADJUST,
    pdb
)
from roller_fu_comm import info_msg, show_err
from roller_constant_key import Option as ok
import math

"""
Define 'fu' as function performing 'pdb' tasks involving
selection and layer management.
"""


def add_base_layer(group, n):
    """
    Add a layer at the bottom of a layer group.

    group: layer group
        parent of new layer

    n: string
        Name the layer with a suffix.

    Return: layer
        newly added
    """
    return add_layer(group.image, n, group, len(group.layers))


def add_layer(j, n, parent, offset):
    """
    Add a layer to an image.

    j: GIMP image
        Receive layer.

    n: string
        Name the new layer.

    parent: layer or None
        group layer

    offset: int
        Is the position from top of the Layers trunk or the parent layer.
        Zero to 'n' where 'n' is the number of layers in the trunk or group.

    Return: layer
        newly inserted
    """
    if parent:
        n = parent.name + " " + n

    z = pdb.gimp_layer_new(
        j,
        j.width, j.height,
        RGBA_IMAGE,
        n,
        100.,                       # opacity
        LAYER_MODE_NORMAL
    )

    pdb.gimp_image_insert_layer(j, z, parent, offset)
    return z


def add_layer_above(z, n):
    """
    Insert a new empty layer above an existing layer.

    z: layer
        target of insertion

    n: string
        the new layer name

    Return: layer
        newly added
    """
    return add_layer(z.image, n, z.parent, get_layer_position(z))


def add_layer_below(z, n):
    """
    Insert a new empty layer below an existing layer.

    z: layer
        target of insertion

    n: string or None
        When true, the layer is named.

    Return: layer
        newly added
    """
    return add_layer(z.image, n, z.parent, get_layer_position(z) + 1)


def adjust_saturation(z, d):
    """
    Adjust a layer's saturation.

    z: layer
        Change saturation.

    d: dict
        Has a SATURATION Option key.
    """
    f = d[ok.SATURATION]
    if f:
        saturate(z, f)


def apply_mask(z):
    """
    Apply a layer's mask.

    z: layer or None
        Has mask that hasn't been applied.
    """
    if z and z.mask:
        pdb.gimp_layer_remove_mask(z, MASK_APPLY)


def blur_selection(z, a):
    """
    Blur a selection or a layer if there is no selection.

    z: layer
        Receive blur.

    a: float or int
        blur amount
    """
    if a:
        a = min(float(a), 500.)

        if pdb.gimp_selection_is_empty(z.image):
            select_z(z)
        pdb.plug_in_gauss_rle2(z.image, z, a, a)


def clear_inverse_selection(z, is_keep=False):
    """
    Invert and clear a selection.

    z: layer
        Clear material.

    is_keep: bool
        If it's True, then the selection is the same on exit.
    """
    if z:
        j = z.image

        if is_keep:
            sel = pdb.gimp_selection_save(j)

        invert_selection(j)
        clear_selection(z)
        if is_keep:
            load_selection(j, sel)
            pdb.gimp_image_remove_channel(j, sel)


def clear_selection(z, is_keep=False):
    """
    Clear a layer's selection.

    If there's no selection, do nothing.
    GIMP will clear the layer otherwise.

    z: layer
        Clear material.

    is_keep: bool
        If it's False, then the selection is removed.
    """
    if z:
        j = z.image

        if not pdb.gimp_selection_is_empty(j):
            pdb.gimp_edit_clear(z)
        if not is_keep:
            pdb.gimp_selection_none(j)


def clone_layer(z, n="", no_mask=True):
    """
    Duplicate a layer. The duplicate is placed
    above the copied layer in the layer order.

    z: layer
        Duplicate.

    n: string
        Name the clone.

    no_mask: bool
        If it is True, then the source layer's mask is not cloned.

    Return: layer or None
        the duplicate
    """
    if z:
        j = z.image

        # A selection will make a floating selection clone.
        pdb.gimp_selection_none(j)

        z1 = pdb.gimp_layer_new_from_drawable(z, j)
        a = get_layer_position(z)

        pdb.gimp_image_insert_layer(j, z1, z.parent, a)
        set_layer_attr(z1, LAYER_MODE_NORMAL, 100.)

        if z1.mask and no_mask:
            remove_z(z1.mask)

        if n:
            z1.name = n
        return z1


def clone_opaque_layer(z, is_opaque=True, n=None):
    """
    Return a duplicate layer with an optional
    transform to make its pixel fully opaque.

    z: layer
        Clone.

    is_opaque: flag
        When True, the clone is made 100% opaque.

    n: string or None
        Name the clone.

    Return: layer or None
        the clone
    """
    if z:
        j = z.image
        z = clone_layer(z, n=n, no_mask=False)

        # no semi-transparency
        if is_opaque:
            if pdb.gimp_item_is_group(z):
                z = pdb.gimp_image_merge_layer_group(j, z)

            # threshold all, '0'
            pdb.plug_in_threshold_alpha(j, z, 0)
        return z


def collect_group(a, q):
    """
    Recursively step through an image's layers
    while adding group layers to a list.

    a: GIMP image or layer group
        Scan for layer group.

    q: list
        [layer group, ...]
    """
    for i in a.layers:
        if pdb.gimp_item_is_group(i):
            q += [i]
            collect_group(i, q)


def collect_non_group(a, q):
    """
    Recursively step through an image's layers
    while adding non-group layers to a list.

    a: GIMP image or layer group
        Scan for non-layer group.

    q: list
        [drawable, ...]
    """
    for i in a.layers:
        if pdb.gimp_item_is_group(i):
            collect_non_group(i, q)
        else:
            q += [i]


def image_copy_all(j):
    """
    Copy a visible image while ensuring that it's the
    whole image by modifying the image's selection.

    j: GIMP image
        Copy visible pixel.

    Return: state of the clipboard
    """
    pdb.gimp_selection_all(j)
    pdb.gimp_edit_copy_visible(j)


def create_image(w, h):
    """
    Create a temporary GIMP image that has its undo turned off.

    w, h: int
        Is the size of the new image.

    Return: GIMP image
        as requested
    """
    j = pdb.gimp_image_new(w, h, RGB)

    pdb.gimp_image_undo_disable(j)
    return j


def create_mask(z, option=ADD_MASK_ALPHA):
    """
    Give a layer a mask.

    z: layer
        Mask.

    option: gimpfu enum
        mask type
    """
    mask = pdb.gimp_layer_create_mask(z, option)
    z.add_mask(mask)


def dilate(z):
    """
    Dilate pixel on a layer.

    z: layer
        Receive dilation.
    """
    pdb.plug_in_dilate(
        z.image,
        z,
        6,              # opaque
        0,              # channel zero
        1.,             # full rate
        0,              # direction mask
        0,              # low limit
        255             # upper limit
    )


def discard_mask(z):
    """
    Delete a layer's mask.

    z: layer or None
        Has mask.
    """
    if z and z.mask:
        pdb.gimp_layer_remove_mask(z, MASK_DISCARD)


def flip_layer(z, is_h=False):
    """
    Flip a layer horizontally or vertically.

    z: layer
        Flip pixel.

    is_h: bool
        If it's True, then flip the layer horizontally.
        Otherwise, flip the layer vertically.
    """
    a = ORIENTATION_HORIZONTAL if is_h \
        else ORIENTATION_VERTICAL

    # axis, '0'
    pdb.gimp_selection_none(z.image)
    pdb.gimp_item_transform_flip_simple(z, a, True, 0)


def get_background(z, n, is_hide=True):
    """
    Get the visible backdrop of a layer.

    z: layer
        Copy its background.

    n: string
        Name the copied background layer.

    is_hide: bool
        If False, the WIP layer is included in the copy.

    Return: layer
        the background copy
    """
    def _hide(_z):
        """
        _z: group layer or GIMP image
        """
        for _z1 in _z.layers:
            if _z1 not in branch_q:
                if _z1.visible:
                    hide_q.append(_z1)

            else:
                if hasattr(_z1, 'layers') and _z1 != z:
                    _z = _hide(_z1)
                break
        return _z

    j = z.image
    z1 = z

    # branch of layer parent to work-in-progress layer, 'branch_q'
    branch_q = [z]

    # hidden layer, 'hide_q'
    hide_q = [z] if is_hide else []

    # Get the outer-most parent of layer, 'z'.
    # Make a list of the parent groups for they may contain additional layers.
    while z1.parent:
        branch_q += [z1.parent]

        # group layer, 'z1'
        z1 = z1.parent

    node_z = branch_q[-1]

    # Hide trunk.
    for i in j.layers:
        if i == node_z:
            break
        if i.visible:
            hide_q.append(i)

    # Hide branch.
    if len(branch_q) > 1:
        _hide(node_z)

    for i in hide_q:
        hide_layer(i)

    z1 = pdb.gimp_layer_new_from_visible(j, j, n)

    for i in hide_q:
        show_layer(i)
    return z1


def get_item_size(a):
    """
    Convert an item size to float. The item
    has attributes 'width' and 'height'.

    a: GIMP image or drawable

    Return: tuple
        (width, height) of float
        image size
    """
    return map(round, (a.width, a.height))


def get_layer_position(z):
    """
    Get a layer's top-down offset from its parent group.

    z: layer
        Determine its position.

    Return: int
        offset from the parent layer
        from 0 to the number of layers in the group minus one
    """
    if z:
        return pdb.gimp_image_get_item_position(z.image, z)
    return -1


def get_layer_offsets(z):
    """
    Convert a layer offsets to float.

    z: layer

    Return: tuple
        (x, y) of float
        offsets; position of layer
    """
    return map(float, z.offsets)


def get_select_coord(j):
    """
    Convert the selection bounds value to float.

    j: GIMP image
        Has selection.

    Return: tuple
        (x, y, x1, y1) of float
    """
    return map(float, pdb.gimp_selection_bounds(j)[1:])


def get_select_bounds(j):
    """
    Convert the selection bounds value to float.

    j: GIMP image
        Has selection.

    Return: tuple
        (is_selection, x, y, x1, y1)
        (bool, float series...)
    """
    q = pdb.gimp_selection_bounds(j)
    return (q[0],) + tuple(map(float, q[1:]))


def hide_layer(z):
    """
    Make a layer invisible.

    z: layer
        Hide.
    """
    if z.visible:
        pdb.gimp_item_set_visible(z, 0)


def invert_selection(j):
    """
    Invert a selection.

    j: GIMP image
        Has selection.
    """
    if not pdb.gimp_selection_is_empty(j):
        pdb.gimp_selection_invert(j)


def isolate_selection(z, sel, is_keep=False):
    """
    Clear out material not in a selection.

    z: layer
        Clear.

    sel: selection
        The selection part is preserved and the other part is removed.

    is_keep: flag
        If it's True, then the selection remains.
    """
    load_selection(z.image, sel)
    clear_inverse_selection(z, is_keep=is_keep)


def layer_has_pixel(z):
    """
    Return the boolean of the pixel count of a layer. The color
    count is zero if the layer is completely transparent. Remove
    selection so the plug-in function works properly.

    z: layer
        to check

    Return: bool
        Is True if the layer exists and has a pixel.
    """
    if z:
        pdb.gimp_selection_none(z.image)
        return bool(pdb.plug_in_ccanalyze(z.image, z))
    return False


def load_selection(j, sel, option=CHANNEL_OP_REPLACE):
    """
    Load a previously saved selection.

    j: GIMP image
        Receive selection.

    sel: selection
        Is a selection channel of the image.

    option: selection operation
        gimpfu enum
        add, intersect, replace, subtract
    """
    if validate_item(sel):
        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_antialias(0)
        pdb.gimp_image_select_item(j, option, sel)
    elif option == CHANNEL_OP_REPLACE:
        pdb.gimp_selection_none(j)


def make_clouds(z, seed_):
    pdb.plug_in_solid_noise(
        z.image, z,
        0,                      # no tile-able
        0,                      # no, turbulent
        seed_,
        7,                      # medium detail
        2.,                     # horizontal size
        2.                      # vertical size
    )


def make_layer_group(j, n, parent, offset, z=None):
    """
    Create a group layer.

    j: GIMP image
        Receive group.

    n: string
        Name the group.

    parent: layer or None
        Is the parent layer of the group.

    offset: int
        Is the offset from the top of the parent to insert the group.

    z: layer
        Move to the new group.

    Return: layer
        the group
    """
    group = pdb.gimp_layer_group_new(j)

    pdb.gimp_image_insert_layer(j, group, parent, offset)

    if z:
        # layer offset below the group layer, '0'
        pdb.gimp_image_reorder_item(j, z, group, 0)

    if parent:
        n = parent.name + " " + n

    group.name = n
    group.mode = LAYER_MODE_PASS_THROUGH
    return group


def make_text_layer(j, z, antialias, text, size, font, color, x, y, w, h):
    """
    Create a text layer. Transform the text layer to fit into a rectangle.

    j: GIMP image
        Receive text layer.

    z: layer or None
        Receive text.

    text: string
        to make on text layer

    size: float
        Is the font size of text.

    font: string
        font name

    color: tuple
        RGBA

    x, y: float
        topleft coordinate of text

    w, h: float
        Transform the completed text size.

    Return: tuple
        (bool, layer)
        bool
            Is a success flag, where true equates to success.

        layer
            transformed text
            Could be None on failure.
    """
    # text layer, 'z1'
    z1 = None

    go = True
    text = text.decode('utf-8').strip()
    offset_z = get_layer_position(z) if z else 0

    # Remove any selection so that 'gimp_text_fontname' returns a layer.
    pdb.gimp_selection_none(j)

    try:
        # Pass None as a layer option so
        # that function will create a new layer.
        # Text layer type, 'z1'
        z1 = pdb.gimp_text_fontname(
            j, None,
            x, y,
            text,
            0,                      # border
            1,
            size,
            PIXELS,
            font
        )

    except Exception as ex:
        show_err(ex)
        info_msg("Apologies. Roller's text method failed to draw.")
        go = False

    if z1:
        pdb.gimp_text_layer_set_color(z1, color)
        pdb.gimp_text_layer_set_antialias(z1, antialias)
        pdb.plug_in_autocrop_layer(j, z1)

        if w:
            pdb.gimp_item_transform_scale(z1, 0., 0., w, h)
        if validate_item(z):
            # Convert the Text layer to a raster layer.
            # Move the layer, 'z1', from the top of the layer stack.
            # so that it can be merged with the target layer, 'z'.
            pdb.gimp_image_reorder_item(j, z1, z.parent, offset_z)
            z1 = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
    return go, z1


def merge_layer_group(z, n=None):
    """
    Merge layer group.

    z: layer
        Merge.

    n: string or None
        Name the merged layer.

    Return: layer
        Merged.
    """
    z = pdb.gimp_image_merge_layer_group(z.image, z)

    if n:
        z.name = n
    return z


def move_layer(j, z, parent, offset):
    """
    Arrange a layer.

    j: GIMP image
        Is render.

    z: layer or None
        Arrange.

    parent: layer group
        The layer is moved to this group.

    offset: int
        Is the layer's correct position.
        0 .. n where n is the number of layers in the group

    Return: int
        Is one if the layer is not None. Is zero if the layer is None.
    """
    if z:
        a = pdb.gimp_image_get_item_position(j, z)

        if a != offset or z.parent != parent:
            pdb.gimp_image_reorder_item(j, z, parent, offset)
        return 1
    return 0


def paste_image():
    """
    Paste the content of the clipboard as a new image.

    Return: GIMP image
        Has undo turned off.
    """
    j = pdb.gimp_edit_paste_as_new_image()

    pdb.gimp_image_undo_disable(j)
    return j


def paste_layer(z, n=""):
    """
    Paste the content of the clipboard.

    z: layer
        Paste above this layer.

    n: string
        Name the pasted layer.

    Return: layer
        newly created
    """
    j = z.image

    # With a selection, GIMP pastes the buffer
    # material centered around the selection.
    pdb.gimp_selection_none(j)

    z1 = z
    is_group = pdb.gimp_item_is_group(z)

    if is_group:
        # GIMP throws an error if the target layer
        # of a paste operation is a group layer.
        z1 = add_layer_above(z, "Base")

    z = pdb.gimp_edit_paste(z1, 0)

    pdb.gimp_floating_sel_to_layer(z)

    if is_group:
        remove_z(z1)

    if n:
        z.name = n
    return z


def paste_layer_into(group, n=""):
    """
    Paste the content of the buffer into a layer group.
    Is for the render image only.

    z: layer
        Paste above this layer.

    n: string
        Name the pasted layer.

    Return: layer
        newly created
    """
    j = group.image
    base = None

    if not group.layers or pdb.gimp_item_is_group(group.layers[0]):
        z = base = j.layers[-1].layers[-1]

    else:
        z = group.layers[0]

    # With a selection, GIMP pastes the buffer
    # material centered around the selection.
    pdb.gimp_selection_none(j)

    z = pdb.gimp_edit_paste(z, 0)

    pdb.gimp_floating_sel_to_layer(z)

    if base:
        pdb.gimp_image_reorder_item(j, z, group, 0)

    if n:
        z.name = n
    return z


def remove_layers(a):
    """
    Remove zero or more layers.

    a: iterable or layer
        (layer, ...)
        Remove.
    """
    if a:
        if isinstance(a, (tuple, list)):
            for i in a:
                remove_z(i)
        else:
            remove_z(a)


def remove_z(z):
    """
    Remove a drawable, a layer or mask, if it exists.

    z: drawable
        Remove.
    """
    if validate_item(z):
        if pdb.gimp_item_is_layer_mask(z):
            z1 = pdb.gimp_layer_from_mask(z)
            discard_mask(z1)
        else:
            pdb.gimp_image_remove_layer(z.image, z)


def rotate_image(j, a):
    """
    Rotate the base layer of an image.

    j: GIMP image
        Rotate assuming there is only one layer.

    a: numeric
        Is the rotation amount in degree.

    Return: layer
        the transformed layer
    """
    pdb.gimp_context_set_transform_direction(TRANSFORM_FORWARD)
    pdb.gimp_context_set_transform_resize(TRANSFORM_RESIZE_ADJUST)
    rotate_layer(j.layers[0], a)
    pdb.gimp_image_resize_to_layers(j)
    return j.layers[0]


def rotate_layer(z, f):
    """
    Rotate a layer around the center of its image.

    z: layer
        Rotate.

    f: float
        Is the rotation angle in degree.
    """
    # If there's a selection, the selection would be rotated.
    pdb.gimp_selection_none(z.image)
    pdb.gimp_item_transform_rotate(
        z,
        math.radians(f),
        1,                           # yes, auto-center
        .0, .0                       # x, y
    )


def saturate(z, f):
    """
    Adjust a layer's saturation.

    z: layer
        Is the target of the op.

    f: float
        -100. to 100.0
        from no saturation to full
    """
    # hue offset, '.0'; lightness, '.0'; overlap, '.0'
    pdb.gimp_drawable_hue_saturation(z, HUE_RANGE_ALL, .0, .0, f, .0)


def select_color(z, q, option=CHANNEL_OP_REPLACE, threshold=.05):
    """
    Select pixel of a color.

    z: layer
        Select its material.

    q: tuple
        RGB color

    option: gimpfu enum
        selection operation type

    threshold: float
        .0 to 1.
        A greater value increases sample match quantity.
    """
    pdb.gimp_context_set_feather(0)
    pdb.gimp_context_set_sample_criterion(0)
    pdb.gimp_context_set_sample_threshold(threshold)
    pdb.gimp_image_select_color(z.image, option, z, q)


def select_ellipse(j, x, y, w, h, option=CHANNEL_OP_REPLACE):
    """
    Make an ellipse selection.

    j: GIMP image
        Receive selection.

    x, y: float
        top-left point of the ellipse

    w: float
        radius width

    h: float
        radius height

    option: GIMP enum
        add, replace, subtract, or intersect
    """
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_context_set_feather(0)
    pdb.gimp_image_select_ellipse(j, option, x, y, w, h)


def select_item(z, option=CHANNEL_OP_REPLACE):
    """
    Select an item. If the item has a mask,
    select it so that its selection intersects.

    z: layer or None
        Select.

    option: GIMP enum
        selection operation
        replace, add, subtract, or intersect

    Return: state of selection
    """
    if z:
        select_z(z, option=option)


def select_opaque(z, option=CHANNEL_OP_REPLACE):
    """
    Make a selection from an cloned opaque layer.

    z: layer
        Select.

    option: GIMP enum
        Is ADD, INTERSECT, REPLACE, or SUBTRACT.

    Return: state of selection
    """
    if z:
        j = z.image
        sel = None

        if option != CHANNEL_OP_REPLACE:
            sel = pdb.gimp_selection_save(j)

        z1 = clone_opaque_layer(z)

        if sel:
            load_selection(j, sel)

        select_z(z1, option=option)
        pdb.gimp_image_remove_layer(z.image, z1)
        if sel:
            pdb.gimp_image_remove_channel(j, sel)


def select_polygon(j, q, option=CHANNEL_OP_REPLACE):
    """
    Select a polygon defined by an connected array of x, y coordinate.

    j: GIMP image
        Receive selection.

    q: list or tuple
        [x, y, ...]
        Each x, y pair is a point. Connect points by their order.

    option: GIMP enum
        add, subtract, or replace selection
    """
    if q:
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_feather(0)
        pdb.gimp_image_select_polygon(j, option, len(q), q)
    else:
        info_msg("Roller failed to draw a polygon.")


def select_rect(j, x, y, w, h, option=CHANNEL_OP_REPLACE):
    """
    Select a rectangle.

    j: GIMP image
        Receive selection.

    x, y, w, h: float
        Define a rectangle.

    option: GIMP enum
        Modify an existing selection.
    """
    pdb.gimp_context_set_feather(0)
    pdb.gimp_context_set_antialias(0)

    # Correct underflow with '0'.
    pdb.gimp_image_select_rectangle(j, option, x, y, max(.0, w), max(.0, h))


def select_shape(j, q, option=CHANNEL_OP_REPLACE):
    """
    Select a polygon. If there only four values in the polygon
    then select an ellipse from an rectangle (x, y, w, h).

    j: GIMP image
        Receive selection.

    q: tuple
        (x, y, ...) series of vertices
        Connect polygon point series.

    option: enum
        selection operation
        add, subtract, intersect, or replace
        Modify an existing selection.
    """
    if len(q) == 4:
        select_ellipse(j, *q, option=option)
    else:
        select_polygon(j, q, option=option)


def select_z(z, option=CHANNEL_OP_REPLACE):
    """
    Select an item. If the item has a mask,
    select it so that its selection intersects.

    z: layer or None
        Select.

    option: GIMP enum
        selection operation
        replace, add, subtract, or intersect

    Return: state of selection
    """
    j = z.image
    sel = sel1 = None
    is_add = option == CHANNEL_OP_ADD and z.mask
    is_subtract = option == CHANNEL_OP_SUBTRACT and z.mask
    is_intersect = option == CHANNEL_OP_INTERSECT and z.mask

    pdb.gimp_context_set_feather(0)
    pdb.gimp_context_set_antialias(0)

    if is_add or is_subtract or is_intersect:
        if not pdb.gimp_selection_is_empty(j):
            sel = pdb.gimp_selection_save(j)

    if z.mask:
        # Select the item and its mask intersection.
        pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z.mask)
        pdb.gimp_image_select_item(j, CHANNEL_OP_INTERSECT, z)

        if sel:
            if is_add or is_intersect:
                load_selection(j, sel, option=option)
            elif is_subtract:
                if not pdb.gimp_selection_is_empty(j):
                    sel1 = pdb.gimp_selection_save(j)

                    load_selection(j, sel)
                    load_selection(j, sel1, option=option)

    else:
        pdb.gimp_image_select_item(j, option, z)
    if sel:
        pdb.gimp_image_remove_channel(j, sel)
        if sel1:
            pdb.gimp_image_remove_channel(j, sel1)


def set_layer_attr(z, mode, opacity):
    """
    Set layer attributes mode and opacity. Hypothetically,
    its faster to set attribute only when it's changed.

    z: layer
        WIP

    mode: GIMP layer mode enum
        Change the layer's mode.

    opacity: float
        Change the layer's opacity.

    Return: bool
        Is True if there is change.
    """
    m = False

    if z.opacity != opacity:
        z.opacity = opacity
        m = True
    if z.mode != mode:
        z.mode = mode
        m = True
    return m


def set_layer_mode(z, mode):
    """
    Set a layer's mode.

    z: layer
        WIP

    mode: GIMP layer mode enum
        Change the layer's mode.

    Return: bool
        Is True if there is change.
    """
    if z.mode != mode:
        z.mode = mode
        return True
    return False


def shape_clipboard(w, h, callback=None):
    """
    Paste, Resize, copy, and close an image.
    Expect image in the clipboard.

    w: int
        width to shape

    h: int
        height to shape

    callback: function
        Call before the clipboard is returned.
        Enable manipulation of the shaped image.

    Return: clipboard
        Has image copy.
    """
    j = paste_image()
    z = j.layers[0]

    # The last option is to scale around the center, '1'.
    pdb.gimp_layer_scale(z, max(1, w), max(1, h), 1)

    pdb.gimp_image_resize_to_layers(j)

    if callback:
        callback(j)

    # Set the selection to the entire image before copying.
    image_copy_all(j)

    # Clean-up.
    pdb.gimp_image_delete(j)


def show_layer(z):
    """
    Make a layer visible.

    z: layer
        to show
    """
    if not z.visible:
        pdb.gimp_item_set_visible(z, 1)


def shrink_selection(j, w):
    """
    Shrink a selection. Ensure that antialiasing is on.

    j: GIMP image
        Has selection.

    w: numeric
        Is the shrink amount.
    """
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_selection_shrink(j, int(w))


def transfer_mask(z, z1, option=ADD_MASK_ALPHA):
    """
    Transfer a mask from one layer to another.

    z: layer
        Receive mask.

    z1: layer
        Has the mask.

    option: gimpfu enum
        Define the mask-type.
    """
    if not z1.mask:
        create_mask(z1, option=option)
    if not z.mask:
        z.add_mask(pdb.gimp_layer_create_mask(z1, option))


def validate_item(a):
    """"
    Determine if an item reference is valid.

    a: item
        Could be None or invalid.

    Return: bool
        Is true if the item is valid.
    """
    return a and pdb.gimp_item_is_valid(a)


def verify_layer(z):
    """
    Verify that a layer has a pixel. If the layer
    does not have a pixel, remove the layer.

    z: layer
        Test for pixel.

    Return: layer or None
        Is None if the layer had no material.
    """
    if layer_has_pixel(z):
        return z
    if z:
        pdb.gimp_image_remove_layer(z.image, z)


def verify_layer_group(group):
    """
    Merge a layer group, then verify that the new layer has a
    pixel. If the new layer does not have a pixel, remove it.

    group: layer
        Merge and verify.

    Return: layer or None
        Is the product of merged group.
        Is None if there was no pixel.
    """
    return verify_layer(merge_layer_group(group))
