#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Define 'constant/key' as a reference source for program scope dictionary key.

A keyword class module has a two letter import variable
that is unique in the context of the program.

As a code rule, a two letter variable is either an import class ('ok'),
an enumerated single letter typed variable name ('d1'), or
single letter typed variable names with an underscore ('_f' or 'f_'),
an Exception ('ex') or an Roller object id ('id').

Make label text from the prefix of a string containing a comma.
"""
_BACKDROP = "Backdrop"
_BORDER = "Border"
_BASIC = "Basic"
_BEVEL = "Bevel"
_BOX = "Box"
_BRUSHY = "Brushy"
_BUMP = "Bump"
_BURST = "Burst"
_CAMO = "Camo"
_CANVAS = "Canvas"
_CAPTION = "Caption"
_CELL = "Cell"
_CELL_SHAPE = "Cell Shape"
_CERAMIC = "Ceramic"
_CHECKER = "Checker"
_CIRCUIT = "Circuit"
_CLEAR = "Clear"
_CRUMBLE = "Crumble"
_DECAY = "Decay"
_FACE = "Face"
_FACING = "Facing"
_FENCE = "Fence"
_FRINGE = "Fringe"
_GRADUAL = "Gradual"
_HOLEY = "Holey"
_GLUE = "Glue"
_IMAGE = "Image"
_INNER_SHADOW = "Inner Shadow"
_JOINT = "Joint"
_LINE = "Line"
_MIRROR = "Mirror"
_MARGIN = "Margin"
_MASK = "Mask"
_MECHA = "Mecha"
_OVER = "Over"
_OVERLAP = "Overlap"
_PIPE = "Pipe"
_PLAN = "Plan"
_PLAQUE = "Plaque"
_PRESET = "Preset"
_PROPERTY = "Property"
_RAD = "Rad"
_RANDOM = "Random"
_RECTANGLE = "Rectangle"
_RESIZE = "Resize"
_SHADOW = "Shadow"
_SHADOW_1 = "Shadow #1"
_SHADOW_2 = "Shadow #2"
_SHIFT = "Shift"
_STAINED = "Stained"
_STEPS = "Steps"
_STRETCH = "Stretch"
_STRIP = "Strip"
_STRIPE = "Stripe"
_SWITCH = "Switch"
_TAPE = "Tape"
_TYPE = "Type"
_WOBBLE = "Wobble"
LIST_SEPARATOR = "@"


class BackdropStyle:
    """Import as 'by'."""
    ACRYLIC_SKY = "Acrylic Sky"
    BACK_GAME = "Back Game"
    CLAY_CHEMISTRY = "Clay Chemistry"
    COLOR_FILL = "Color Fill"
    COLOR_GRID = "Color Grid"
    CRYSTAL_CAVE = "Crystal Cave"
    CORE_DESIGN = "Core Design"
    CUBE_PATTERN = "Cube Pattern"
    CUBISM_COVER = "Cubism Cover"
    DARK_FORT = "Dark Fort"
    FADING_MAZE = "Fading Maze"
    DENSITY_GRADIENT = "Density Gradient"
    DROP_ZONE = "Drop Zone"
    ETCH_SKETCH = "Etch Sketch"
    FLOOR_SAMPLE = "Floor Sample"
    GALACTIC_FIELD = "Galactic Field"
    GLASS_GAW = "Glass Gaw"
    GRADIENT_FILL = "Gradient Fill"
    HISTORIC_TRIP = "Historic Trip"
    IMAGE_GRADIENT = "Image Gradient"
    LINE_STONE = "Line Stone"
    LOST_MAZE = "Lost Maze"
    MAZE_BLEND = "Maze Blend"
    MEAN_COLOR = "Mean Color"
    MYSTERY_GRATE = "Mystery Grate"
    NOISE_RIFT = "Noise Rift"
    PAPER_WASTE = "Paper Waste"
    PATTERN_FILL = "Pattern Fill"
    RAINBOW_VALLEY = "Rainbow Valley"
    RECT_PATTERN = "Rectangle Pattern"
    ROCKY_LANDING = "Rocky Landing"
    ROOF_TOP = "Roof Top"
    SOFT_TOUCH = "Soft Touch"
    SPECIMEN_SPECKLE = "Specimen Speckle"
    SPIRAL_CHANNEL = "Spiral Channel"
    SQUARE_CLOUD = "Square Cloud"
    STONE_AGE = "Stone Age"
    TRAILING_VINE = "Trailing Vine"
    TRIANGLE_REVERB = "Triangle Reverb"
    WAVE_FILL = "Wave Fill"
    KEY_LIST = (
        ACRYLIC_SKY,
        BACK_GAME,
        CLAY_CHEMISTRY,
        COLOR_FILL,
        COLOR_GRID,
        CORE_DESIGN,
        CRYSTAL_CAVE,
        CUBE_PATTERN,
        CUBISM_COVER,
        DARK_FORT,
        DENSITY_GRADIENT,
        DROP_ZONE,
        ETCH_SKETCH,
        FADING_MAZE,
        FLOOR_SAMPLE,
        GALACTIC_FIELD,
        GLASS_GAW,
        GRADIENT_FILL,
        HISTORIC_TRIP,
        IMAGE_GRADIENT,
        LINE_STONE,
        LOST_MAZE,
        MAZE_BLEND,
        MEAN_COLOR,
        MYSTERY_GRATE,
        NOISE_RIFT,
        PAPER_WASTE,
        PATTERN_FILL,
        RAINBOW_VALLEY,
        RECT_PATTERN,
        ROCKY_LANDING,
        ROOF_TOP,
        SOFT_TOUCH,
        SPECIMEN_SPECKLE,
        SPIRAL_CHANNEL,
        SQUARE_CLOUD,
        STONE_AGE,
        TRAILING_VINE,
        TRIANGLE_REVERB,
        WAVE_FILL
    )


class Button:
    """Import as 'bk'."""
    ACCEPT = "Accept"
    ACCEPT_ALL = "Accept All"
    ACCEPT_NONE = "Accept None"
    ADD_COLUMN = 'Add Column'
    DEL_MODEL = 'del model'
    CANCEL = "Cancel"
    DRAFT = "Draft"
    MAKE = 'make'
    MANAGE_PRESET = 'manage preset'
    MINUS = 'minus'
    MOVE_DOWN = 'move down'
    MOVE_UP = 'move up'
    OPEN = "Open…"
    PEEK = "Peek"
    PLAN = _PLAN
    NEW_MODEL = 'new model'
    PREVIEW = "Preview"
    RANDOM = _RANDOM
    RENAME = 'rename'
    REMOVE = 'remove'
    REVISE = 'revise'
    SHELVE = "Shelve"
    SUBTRACT_COLUMN = 'Subtract Column'
    SAVE_PRESET = 'save preset'
    SELECT_ALL = 'select all'
    SELECT_NONE = 'select none'


class Frame:
    """Import as 'ek'."""
    BASIC = _BASIC
    BEVEL = _BEVEL
    BRUSHY = _BRUSHY
    BURST = _BURST
    CAMO = _CAMO
    CERAMIC = _CERAMIC
    CHECKER = _CHECKER
    CLEAR = _CLEAR
    CRUMBLE = _CRUMBLE
    CIRCUIT = _CIRCUIT
    DECAY = _DECAY
    FENCE = _FENCE
    GLUE = _GLUE
    GRADUAL = _GRADUAL
    HOLEY = _HOLEY
    JOINT = _JOINT
    MECHA = _MECHA
    MIRROR = _MIRROR
    OVER = _OVER
    OVERLAP = _OVERLAP
    PIPE = _PIPE
    RAD = _RAD
    STAINED = _STAINED
    STRETCH = _STRETCH
    STRIPE = _STRIPE
    TAPE = _TAPE
    WOBBLE = _WOBBLE
    KEY_LIST = (
        BASIC, BEVEL,
        BRUSHY, BURST,
        CAMO, CERAMIC,
        CHECKER, CIRCUIT,
        CLEAR, CRUMBLE,
        DECAY, FENCE,
        GLUE, GRADUAL,
        HOLEY, JOINT,
        MECHA, MIRROR,
        OVER, OVERLAP,
        PIPE, RAD,
        STAINED, STRETCH,
        STRIPE, TAPE,
        WOBBLE
    )
    DECO_KEY_LIST = list(KEY_LIST)[:]
    for i in (BEVEL, OVER, OVERLAP, JOINT, BURST, TAPE):
        DECO_KEY_LIST.pop(DECO_KEY_LIST.index(i))


class Group:
    """Use with an AnyGroup. Import as 'gk'."""
    BACKDROP = _BACKDROP
    DECO = "Deco"
    GLOBAL = "Global"
    GRADIENT_LIGHT = "Gradient Light"
    MODEL = "Model"
    PROPERTY = _PROPERTY
    SWITCH = _SWITCH

    # Shadow
    INNER_SHADOW = _INNER_SHADOW
    SHADOW_1 = _SHADOW_1
    SHADOW_2 = _SHADOW_2
    SHADOW_PRESET = _PRESET + ", " + _SHADOW

    # shared by Model
    BORDER = _BORDER
    CAPTION = _CAPTION
    FRINGE = _FRINGE
    IMAGE = _IMAGE
    LINE = _LINE
    MARGIN = _MARGIN
    PLAQUE = _PLAQUE
    RECTANGLE = _RECTANGLE
    SHIFT = _SHIFT
    TYPE = _TYPE

    # Box
    TYPE_BOX = "Type, Box"

    # Cell Model
    TYPE_CELL = "Type, Cell"

    # Pyramid
    TYPE_PYRAMID = "Type, Pyramid"

    # Stack
    TYPE_STACK = "Type, Stack"

    # Sidewalk
    TYPE_SIDEWALK = "Type, Sidewalk"

    # Table
    TYPE_TABLE = "Type, Table"

    # SuperPreset
    PRESET_BOX = "Preset, Box"
    PRESET_CELL = "Preset, Cell"
    PRESET_PYRAMID = "Preset, Pyramid"
    PRESET_SIDEWALK = "Preset, Sidewalk"
    PRESET_STACK = "Preset, Stack"
    PRESET_STEPS = "Preset, Steps"
    PRESET_TABLE = "Preset, Table"
    PRESET_SHADOW = "Preset, Shadow"
    SUPER_MODEL = (
        PRESET_BOX,
        PRESET_CELL,
        PRESET_PYRAMID,
        PRESET_SIDEWALK,
        PRESET_STACK,
        PRESET_TABLE
    )

    # Window
    CELL_EDITOR = 'cell editor'
    DEFINE_MODEL = "Define Model"
    MODEL_NAME = "Model Name"
    MODEL_TREE = "Model Tree"

    PRESET = _PRESET
    STEPS_DEFAULT = [GLOBAL, GRADIENT_LIGHT, BACKDROP, MODEL, PRESET_STEPS]


gk = Group


class Image:
    """Import as 'ik'."""
    LOOP = 'loop'
    LOOP_DICT = 'loop_dict'
    NEXT = 'next'
    NEXT_DICT = 'next_dict'
    PREVIOUS = 'previous'
    PREVIOUS_DICT = 'previous_dict'
    SLICE = 'slice'


class Item:
    """Use with a Node list. Import as 'ie'."""
    BORDER = _BORDER
    CANVAS = _CANVAS
    CAPTION = _CAPTION
    CELL = _CELL
    FACE = _FACE
    FACING = _FACING
    FRINGE = _FRINGE
    IMAGE = _IMAGE
    LINE = _LINE
    MARGIN = _MARGIN
    PLAQUE = _PLAQUE
    PRESET = _PRESET
    PROPERTY = _PROPERTY
    RECTANGLE = _RECTANGLE
    SHIFT = _SHIFT
    TYPE = _TYPE


class Material:
    """Identify a Heat Preset option. Import as 'ma'."""
    BRUSH = " Brush"
    FILLER = " Filler"
    OVERLAY = " Overlay"
    BACKDROP = _BACKDROP
    BORDER = _BORDER
    CAPTION = _CAPTION
    FRINGE = _FRINGE
    IMAGE = _IMAGE
    JOINT = _JOINT
    LINE = _LINE
    PLAQUE = _PLAQUE
    STRIP = _STRIP

    # Frame-type
    BASIC = _BASIC
    BEVEL = _BEVEL
    BEVEL_OVERLAY = _BEVEL + OVERLAY
    BRUSHY = _BRUSHY
    BRUSHY_BRUSH = _BRUSHY + BRUSH
    BURST = _BURST
    CAMO = _CAMO
    CAMO_OVERLAY = CAMO + OVERLAY
    CERAMIC = _CERAMIC
    CERAMIC_FILLER = _CERAMIC + FILLER
    CHECKER = _CHECKER
    CIRCUIT = _CIRCUIT
    CLEAR = _CLEAR
    CLEAR_OVERLAY = _CLEAR + OVERLAY
    CRUMBLE = _CRUMBLE
    DECAY = _DECAY
    FENCE = _FENCE
    GLUE = _GLUE
    GRADUAL = _GRADUAL
    HOLEY = _HOLEY
    MECHA = _MECHA
    MIRROR = _MIRROR
    OVER = _OVER
    OVER_OVERLAY = _OVER + OVERLAY
    OVERLAP = _OVERLAP
    PIPE = _PIPE
    PIPE_OVERLAY = _PIPE + OVERLAY
    RAD = _RAD
    STAINED = _STAINED
    STAINED_FILLER = _STAINED + FILLER
    STRETCH = _STRETCH
    STRETCH_FILLER = _STRETCH + FILLER
    STRIPE = _STRIPE
    TAPE = _TAPE
    TAPE_OVERLAY = _TAPE + OVERLAY
    WOBBLE = _WOBBLE
    KEY_Q = (
        BACKDROP,
        BORDER,
        CAPTION,
        FRINGE,
        IMAGE,
        LINE,
        PLAQUE,
        STRIP,
        BASIC,
        BEVEL,
        BEVEL_OVERLAY,
        BRUSHY,
        BRUSHY_BRUSH,
        BURST,
        CAMO,
        CAMO_OVERLAY,
        CERAMIC,
        CERAMIC_FILLER,
        CHECKER,
        CIRCUIT,
        CLEAR,
        CLEAR_OVERLAY,
        CRUMBLE,
        DECAY,
        FENCE,
        GLUE,
        GRADUAL,
        HOLEY,
        JOINT,
        MECHA,
        MIRROR,
        OVER,
        OVER_OVERLAY,
        OVERLAP,
        PIPE,
        PIPE_OVERLAY,
        RAD,
        STAINED,
        STAINED_FILLER,
        STRETCH,
        STRETCH_FILLER,
        STRIPE,
        TAPE,
        WOBBLE
    )


class Model:
    """Import as 'md'."""
    BOX = _BOX
    CELL = _CELL
    PYRAMID = "Pyramid"
    SIDEWALK = "Sidewalk"
    STACK = "Stack"
    TABLE = "Table"

    # Are model that have only one cell.
    ONE_CELL = CELL, STACK

    # Model type
    MODEL_TYPE_LIST = BOX, CELL, PYRAMID, SIDEWALK, STACK, TABLE
    MODEL_TYPE_DICT = {
        gk.TYPE_BOX:  BOX,
        gk.TYPE_CELL: CELL,
        gk.TYPE_PYRAMID: PYRAMID,
        gk.TYPE_STACK: STACK,
        gk.TYPE_SIDEWALK: SIDEWALK,
        gk.TYPE_TABLE: TABLE
    }

    # Model branch format used in PortDefineModel.
    CHECKBUTTON_KEY = "{},{}"


md = Model


class ModelList:
    """Import as 'ml'."""
    MODEL_DEF = 'model_def'
    SHELVED = 'shelved'
    ACTIVE = 'active'

    # indices for the ModelList's 'self._items'
    NAME_INDEX, TYPE_INDEX = 0, 1


class Node:
    """Import as 'ny'."""
    CANVAS = _CANVAS
    CELL = _CELL
    FACE = _FACE
    FACING = _FACING

    # SuperPreset
    SHADOW = _SHADOW
    STEPS = _STEPS


ny = Node


class Option:
    """
    Share a Preset dict and play a role in a Preset dict or a vote dict.

    Split a option group voting dict into visible option and cast key creating
    two types of AnyGroup voter. Differentiate the two by their lineage, the
    cast key is born out of voting necessity of an external influence such as
    Global. While the option key is responsible for relaying user input via the
    UI.

    Distinguish cast key from option key by defining the value in a lower-case
    string and substituting an underline character for space character.

    Change a common key into a unique key, (e.g. Add), by splitting the key
    string into a label and a postfix with a comma.

    Import as 'ok'.
    """
    ADD = "Add"
    ADD_ABOVE = "Add, Above"
    ADD_ALT = "Add, Alt"
    ADD_OFFSET_X = "Add Offset X"
    ADD_OFFSET_Y = "Add Offset Y"
    ALPHA_PERCENTILE = "Alpha Percentile"
    AMP = "Amp"
    AMPLITUDE = "Amplitude"
    ANGLE = "Angle"
    ANGLE_JITTER = "Angle Jitter"
    ANGLE_SHIFT = "Angle Shift"
    AUTOCROP = "Auto-Crop"
    AZIMUTH = "Light Azimuth"
    BACKDROP = "Backdrop"
    BACKDROP_STYLE = "Backdrop Style"
    BACKING = "Backing"
    BELOW = "Below"
    BEVEL_W = "Bevel Width"
    BLEND = "Blend"
    BLOCK_H = "Block Height"
    BLOCK_W = "Block Width"
    BLUR = "Blur"
    BLUR_D = "Blur, Group"
    BELOW_COLOR_1 = "Blur Below Color #1"
    BELOW_COLOR_2 = "Blur Below Color #2"
    BLUR_X = "Blur X"
    BLUR_Y = "Blur Y"
    BORDER = _BORDER
    BORDER_W = "Border Width"
    BOTTOM = "Bottom"
    BOX_TYPE = "Box Type"
    BRIGHTNESS = "Brightness"
    BRUSH = "Brush"
    BRUSH_ANGLE = "Brush Angle"
    BRUSH_D = "Brush, Group"
    BRUSH_D1 = "Brush, Brushy"
    BRUSH_SIZE = "Brush Size"
    BRUSH_SPACING = "Brush Spacing"
    BRW = 'BRW'                             # button row
    BUMP = _BUMP
    BUMP_DEPTH = "Bump Depth"
    CAMO_TYPE = "Camo Type"
    CAP_X = "Cap X"
    CAP_Y = "Cap Y"
    CAPTION = _CAPTION
    CELL_COUNT = "Cell Count"
    CELL_H = "Cell Height"
    CELL_SHAPE = _CELL_SHAPE
    CELL_SIZE = "Cell Size"
    CELL_W = "Cell Width"
    CFW = "Canvas Frame Width"
    CIRCLE_DIAMETER = "Circle Diameter"
    CLIP = "Clip"
    CLOCKWISE = "Clockwise"

    # Color options have a naming scheme.
    # "Color", number of colors, with alpha 'A'
    COLOR_1 = "Color, 1"
    COLOR_1A = "Color, 1A"
    COLOR_2 = "Color, 2"
    COLOR_2A = "Color, 2A"
    COLOR_3 = "Color, 3"
    COLOR_3A = "Color, 3A"
    COLOR_6 = "Color, 6"
    COLOR_6A = "Color, 6A"

    COLOR_1_MODE = "Color #1 Mode"
    COLOR_2_MODE = "Color #2 Mode"
    COLOR_COUNT = "Color Count"
    COLOR_GRID_TYPE = "Color Grid Type"
    COLORIZE = "Colorize"
    COLORIZE_OPACITY = "Colorize Opacity"
    COLUMN = "Column"
    COLUMN_1 = "Column #1"
    COLUMN_2 = "Column #2"
    COLUMN_COUNT_Q = "Column Count"         # list
    COLUMN_W = "Column Width"
    COMPONENT = "Color Component"
    CONTRACT = "Contract"
    CONTRAST = "Contrast"
    CORNER_TYPE = "Corner Type"
    CORNER_SHIFT = "Corner Shift"
    COVER = "Cover"
    CRITERION = "Criterion"
    CROP_H = "Crop Height"
    CROP_W = "Crop Width"
    CROP_X = "Crop Offset X"
    CROP_Y = "Crop Offset Y"
    CURVE = "Curve"
    CUT_OUT = "Cut-Out"
    DELETE_PLAN = "Delete Plan"
    DEPTH = "Depth"
    DESATURATE = "Desaturate"
    DIAGONAL = "Diagonal"
    DIRECTION = "Direction"
    DISTRESS = "Distress"
    ECS = "Equilateral Cell Shape"
    EDGE_MODE = "Edge Mode"
    EDGE_TYPE = "Edge Type"
    ELEVATION = "Elevation"
    EMBOSS = "Emboss"
    EMBOSS_MODE = "Emboss Mode"
    END_X = "End X"
    END_Y = "End Y"
    FEATHER = "Feather"
    FILE = "File"
    FILL_MODE = "Fill Paint Mode"
    FILL_OPACITY = "Fill Opacity"
    FILLED = "Filled"
    FILLER = "Filler"
    FILLER_W = "Filler Width"
    FILLER_CE = "Filler, Ceramic"
    FILLER_CH = "Filler, Checker"
    FILLER_CI = "Filler, Circuit"
    FILLER_FE = "Filler, Fence"
    FILLER_HO = "Filler, Holey"
    FILLER_ME = "Filler, Mecha"
    FILLER_MI = "Filler, Mirror"
    FILLER_RA = "Filler, Rad"
    FILLER_S1 = "Filler, Stained"
    FILLER_S2 = "Filler, Stretch"
    FILLER_S3 = "Filler, Stripe"
    FILTER = "Filter"
    FIXED_H = "Height, Fixed"
    FIXED_W = "Width, Fixed"
    FLIP_H = "Flip Horizontal"
    FLIP_V = "Flip Vertical"
    FOLDER = "Folder"
    FOLDER_ORDER = "Folder Order"
    FONT = "Font"
    FONT_SIZE = "Font Size"
    FRAME = "Frame"
    FRINGE = _FRINGE
    GAP_W = "Gap Width"
    GPR = 'GPR'                             # Gradient, Pattern, Image Choice
    GRADIENT = "Gradient"
    GRADIENT_ANGLE = "Gradient Angle"
    GRADIENT_DIRECTION = "Gradient Direction"
    GRADIENT_MODE = "Gradient Mode"
    GRADIENT_OPACITY = "Gradient Opacity"
    GRADIENT_TYPE = "Gradient Type"
    GRID_SIZE = "Grid Size"
    GRID_TYPE = "Grid Type"
    HARDNESS = "Hardness"
    HEAT = "Heat"
    HEIGHT = "Height"
    HEIGHT_MOD = "Height Mod"
    HEXAGON_TYPE = "Hexagon Type"
    HIDE_LAYER = "Hide Layer"
    HORZ_SCALE = "Horizontal Scale"
    IMAGE = _IMAGE
    IMAGE_CHOICE = "Image, Choice"
    IMAGE_NAME = "Image Name"
    INDENT = "Indent"
    INNER_FRAME_W = "Inner Frame Width"
    INTENSITY = "Intensity"
    INVERT = "Invert"
    INWARD = "Inward"
    IS_BACK = 'is_back'
    IS_CHAIN = 'is_chain'
    IS_EMBOSS = 'is_emboss'
    IS_MAIN = 'is_main'
    IS_NEW = 'is_new'
    IS_PLANNED = 'is_planned'
    IS_ROTATE = 'is_rotate'
    IS_SEED = 'is_seed'
    ITERATIONS = "Iterations"
    JITTER_H = "Jitter Height"
    JITTER_W = "Jitter Width"
    JITTER_X = "Jitter X"
    JITTER_Y = "Jitter Y"
    JUSTIFY = "Justify"
    KEEP = "Keep"
    LAYERED = "Layered"
    LAYER_COUNT = "Layer Count"
    LAYER_ORDER = "Layer Order"
    LEAD = 'lead'
    LEFT = "Left"
    LENGTH = "Length"
    LENGTH_SHIFT = "Length Shift"
    LINE = _LINE
    LINE_W = "Line Width"
    LOCKED = "Locked"
    LOOP = "Loop"
    LTR = 'LTR'                             # Lead, Trail, row
    MARGIN = "Margin"
    MASK = _MASK
    MESH_SIZE = "Mesh Size"
    MESH_TYPE = "Mesh Type"
    MODE = "Mode"
    MODEL_LIST = "Model List"
    MODEL_TYPE = 'model type'
    NAME = "Name"
    NEATNESS = "Neatness"
    NET_LINE_W = "Net Line Width"
    NEXT = "Next"
    NLS = "Net Line Spacing"
    MOD = "Mod"
    NODE = 'node'
    NOISE = "Noise"
    NOISE_AMOUNT = "Noise Amount"
    NOISE_D = "Noise, Group"
    NOISE_OPACITY = "Noise Opacity"
    OBEY_MARGIN = "Obey Margin"
    OCTAGON_TYPE = "Octagon Type"
    OFFSET = "Offset"
    OFFSET_X = "Offset X"
    OFFSET_Y = "Offset Y"
    OPACITY = "Opacity"
    OPAQUE = "Opaque"
    OVERLAP = "Overlap"
    OVERLAY = "Overlay"
    OVERLAY_BE = "Overlay, Bevel"
    OVERLAY_CA = "Overlay, Camo"
    OVERLAY_CO = "Overlay, Color"
    OVERLAY_OV = "Overlay, Over"
    PANE_W = "Pane Width"
    PATTERN = "Pattern"
    PATTERN_1 = "Pattern #1"
    PATTERN_2 = "Pattern #2"
    PATTERN_3 = "Pattern #3"
    PAR = 'PAR'                             # Pattern row
    PARALLELOGRAM_SCALE = "Parallelogram Scale"
    PATTERN_SIZE = "Pattern Size"
    PER = "Per"
    PERCENTILE = "Percentile"
    PERIOD = "Period"
    PHASE = "Phase"
    PIN = "Pin"
    PLANNER = "Planner"
    PLAQUE = _PLAQUE
    POSITION_X = "Position X"
    POSITION_Y = "Position Y"
    POST_BLUR = "Post Blur"
    POWER = "Noise Power"
    PRE_BLUR = "Pre-Blur"
    PRESET = _PRESET
    PREVIEW_MODE = "Preview Mode"
    PREVIOUS = "Previous"
    PROFILE = "Profile"
    PUPIL_SCALE = "Pupil Scale"
    RADIUS = "Radius"
    RANDOM_ORDER = "Random Order"
    RECTANGLE_TYPE = "Rectangle Type"
    RENAME_MODEL = "Rename Model"
    RENDER_H = "Render Height"
    RENDER_W = "Render Width"
    RESIZE = _RESIZE
    REVERB = "Reverb"
    REVERSE = "Reverse"
    RIGHT = "Right"
    ROW = "Row"
    ROW_H = "Row Height"
    RW1 = 'RW1'                             # first Button Row
    RW2 = 'RW2'                             # second Button Row
    SAMPLE_COUNT = "Sample Count"
    SAMPLE_RADIUS = "Sample Radius"
    SAMPLE_VECTOR = "Sample Vector"
    SATURATION = "Saturation"
    SCATTER_COUNT = "Scatter Count"
    SEED = "Random Seed"
    SHADOW = "Shadow"
    SHADOW_BASIC = "Shadow, Basic"
    SHAPE = "Shape"
    SHAPED_TYPE = "Shaped Type"
    SHIFT_DIRECTION = "Shift Direction"
    SHIFT = "Shift"
    SIZE_X = "Size X"
    SIZE_Y = "Size Y"
    SKETCH_TEXTURE = "Sketch Texture"
    SLICE = "Slice"
    SLICE_COUNT = "Slice Count"
    SLICE_ORDER = "Slice Order"
    SMOOTH = "Smooth"
    SOFTEN = "Soften"
    SPECK_NOISE = "Speck Noise"
    SPIRAL_DISTANCE = "Spiral Distance"
    SPIRAL_MOD = "Spiral Mod"
    SPREAD = "Spread"
    START_NUMBER = "Start Number"
    START_X = "Start X"
    START_Y = "Start Y"
    STENCIL = "Stencil"
    STEPS = _STEPS
    STRIP = _STRIP
    SUPERPIXEL_SIZE = "Superpixel Size"
    SWITCH = _SWITCH
    TAB = "Tab"
    TEXT = "Text"
    TEXTURE = "Texture"
    TILE_SIZE = "Tile Size"
    THRESHOLD = "Threshold"
    TOP = "Top"
    TRAIL = 'trail'
    TRIANGLE_TYPE = "Triangle Type"
    TRIM = "Trim"
    TYPE = "Type"
    UNSHARP_AMOUNT = "Unsharp Amount"
    UNSHARP_RADIUS = "Unsharp Radius"
    UNSHARP_THRESHOLD = "Unsharp Threshold"
    UPSCALE = "Upscale"
    UP_SPACE = "Up Space"
    VERT_SCALE = "Vertical Scale"
    WAVE_COUNT = "Wave Count"
    WAVE_PER_LAYER = "Waves Per Layer"
    WHIRL = "Whirl"
    WIDTH = "Width"
    WIDTH_MOD = "Width Mod"
    WIP = "Work in Progress"
    WIRE_THICKNESS = "Wire Thickness"
    WOBBLE_FACTOR = "Wobble Factor"
    WRAP = "Wrap"
    WRAP_AB = "Wrap, Above"
    WRAP_AL = "Wrap, Alt"
    WRAP_BE = "Wrap, Bevel"
    WRAP_BU = "Wrap, Burst"
    WRAP_CL = "Wrap, Clear"
    WRAP_CR = "Wrap, Crumble"
    WRAP_DE = "Wrap, Decay"
    WRAP_OL = "Wrap, Overlap"
    WRAP_PA = "Wrap, Pattern"
    WRAP_PI = "Wrap, Pipe"
    WRAP_FI = "Wrap, Fill"
    WRAP_GL = "Wrap, Glue"
    WRAP_GR = "Wrap, Gradual"
    WRAP_JO = "Wrap, Joint"
    WRAP_TA = "Wrap, Tape"
    WRAP_WO = "Wrap, Wobble"


class Plan:
    """Import as 'ak'."""
    BORDER = _BORDER
    CAPTION = _CAPTION
    CELL_SHAPE = _CELL_SHAPE
    CORNER = "Corner"
    DIMENSION = "Dimension"
    FRINGE = _FRINGE
    GRID = "Grid"
    IMAGE = _IMAGE
    LINE = _LINE
    MARGIN = _MARGIN
    NAME = "Name"
    PLAQUE = _PLAQUE
    POSITION = "Position"
    RATIO = "Ratio"
    KEY = (
        BORDER,
        CAPTION,
        CELL_SHAPE,
        CORNER,
        DIMENSION,
        FRINGE,
        GRID,
        IMAGE,
        LINE,
        MARGIN,
        NAME,
        PLAQUE,
        POSITION,
        RATIO
    )


class Preset:
    """Has keys used to initialize a Preset. Import as 'pk'."""
    DEFAULT = "Default"
    DELETE = "Delete"
    SAVE = "Save"


class Step:
    """Use with an option group. Import as 'sk'."""
    STEPS = ()
    SELECTED_ROW = 'selected_row'
    BACKDROP = gk.BACKDROP,
    GLOBAL = gk.GLOBAL,
    GRADIENT_LIGHT = gk.GRADIENT_LIGHT,
    MODEL = gk.MODEL,
    PRESET_STEPS = gk.PRESET,
    DEFAULT_STEP = [
        STEPS,
        GLOBAL,
        GRADIENT_LIGHT,
        BACKDROP,
        MODEL,
        PRESET_STEPS
    ]

    # Group key to Step key
    GROUP_2_STEP_D = {
        gk.BACKDROP: BACKDROP,
        gk.GLOBAL: GLOBAL,
        gk.GRADIENT_LIGHT: GRADIENT_LIGHT,
        gk.MODEL: MODEL
    }

    # Shadow
    SHADOW_SWITCH = ny.SHADOW, gk.SWITCH
    SHADOW = _SHADOW,
    SHADOW_PRESET = ny.SHADOW, gk.PRESET
    SHADOW_1 = ny.SHADOW, gk.SHADOW_1
    SHADOW_2 = ny.SHADOW, gk.SHADOW_2
    INNER_SHADOW = ny.SHADOW, gk.INNER_SHADOW

    # Model____________________________________________________________________
    # Box
    BOX_CANVAS = md.BOX, _CANVAS
    BOX_CELL = md.BOX, _CELL
    BOX_FACE = md.BOX, _FACE

    # Cell
    CELL_CELL = md.CELL, _CELL

    # Pyramid
    PYRAMID_CANVAS = md.PYRAMID, _CANVAS
    PYRAMID_CELL = md.PYRAMID, _CELL

    # Sidewalk
    SIDEWALK_CANVAS = md.SIDEWALK, _CANVAS
    SIDEWALK_CELL = md.SIDEWALK, _CELL
    SIDEWALK_FACING = md.SIDEWALK, _FACING

    # Stack
    STACK_CELL = md.STACK, _CELL

    # Table
    TABLE_CANVAS = md.TABLE, _CANVAS
    TABLE_CELL = md.TABLE, _CELL

    # Identify AnyGroup with a visible Per Cell option.
    PER_GROUP = (
        BOX_CELL,
        BOX_FACE,
        PYRAMID_CELL,
        SIDEWALK_CELL,
        SIDEWALK_FACING,
        STACK_CELL,
        TABLE_CELL
    )

    MARGIN_DEPENDENT = _BORDER, _CAPTION, _FRINGE, _IMAGE, _LINE, _PLAQUE
    MERGE_DEPENDENT = MARGIN_DEPENDENT + (_MARGIN,)

    # Cell branch
    CELL_MARGIN = _CELL, _MARGIN
    CELL_SHIFT = _CELL, _SHIFT
    CELL_TYPE = _CELL, _TYPE


class SubMaya:
    """Import as 'sm'."""
    ADD = 'add'
    BACKDROP_STYLE = 'b_style'
    BACKING = 'backing'
    BELOW = 'below'
    BUMP = 'bump'
    CELL_SHAPE = 'c_shape'
    CORNER = 'corner'
    DIMENSION = 'dim'
    FILLER = 'filler'
    FRAME = 'frame'
    INNER = 'inner'
    LIGHT = 'light'

    # Is a generic key to a Frame sub-type. Identify current Frame/Maya.
    LINK = 'link'

    MARGIN = 'margin'
    MASK = 'mask'
    NAME = 'name'
    NOISE = 'noise'
    OVERLAY = 'overlay'
    POSITION = 'pos'
    RATIO = 'ratio'
    SHADOW = 'shadow'
    SHADOW1 = 'shadow1'
    SHADOW2 = 'shadow2'
    STRIP = 'strip'
    WRAP = 'wrap'


class Widget:
    """
    Initialize a Widget. A key descriptor may become a Widget
    attribute, hence the underline. Import as 'wk'.
    """
    # tuple of float
    # in .0 to 1.
    # a factor of the space to assign
    # for top, bottom, left, right
    ALIGN = 'align'

    # AnyGroup
    # Use to connect widgets with other widget in their group.
    ANY_GROUP = 'any_group'

    # string
    # Identify the render scale axis as either 'x' or 'y'
    # for RenderPair
    AXIS = 'axis'

    # of gtk.Box classes
    BOX = 'box'

    # int
    # Use with the Rainbow Widget or the Radio Widget.
    # Is the number of ColorButtons in the Rainbow Widget.
    # Is the number of Radio Buttons in the Radio group.
    BUTTON_COUNT = 'button_count'

    # a 2D list from Cell Table to its SwitchButton
    CELL_TABLE = 'cell_table'

    # Use with Entry's string length allocation.
    CHARS = 'chars'

    # string
    # Use with the Choice Window.
    CHOICE = 'choice'

    # int
    # for Event boxes
    COLOR = 'color'

    # int
    # a Node's cubby index
    COLUMN = 'column'

    # string
    # for a Widget Table
    # Is a label string for the left-side of a Table.
    COLUMN_TEXT = 'column_text'

    # GTK container
    CONTAINER = 'container'

    # class
    # type of Window
    DIALOG = 'dialog'

    # Call to get a value for a Widget range.
    FUNCTION = 'function'

    # function
    # Call to get the value of a widget.
    GET_A = 'get_a'

    # Is Widget with the proper get_a and set_a function.
    GREATER_G = 'greater_g'

    # GTK Window or Dialog
    GTK_WIN = 'gtk_win'

    # boolean
    # for ColorButton
    # When its true, the ColorButton has an alpha value.
    HAS_ALPHA = 'has_alpha'

    # boolean
    # When True, an AnyGroup has a Randomize button.
    HAS_RANDOM = 'has_random'

    # boolean
    # When True, an AnyGroup has a Preset button.
    HAS_PRESET = 'has_preset'

    # boolean
    # Use to change Item behavior when a Label
    # is not needed for a switchable Preset.
    HAS_SWITCH = 'has_switch'

    # string
    # Is an optional header for a TreeViewList.
    HEADER = 'header'

    # undefined
    # If present in a Widget init argument dict, then
    # AnyGroup will load the group's default dict.
    IS_DEFAULT = 'is_default'

    # bool
    # Identify a Face. Used by PortPer and PortCellEditor.
    IS_FACE = 'is_face'

    # undefined
    # Pass to AnyGroup to have it skip widget creation.
    IS_NONE = 'is_none'

    # string
    # Identify layer dependency type.
    ISSUE = 'issue'

    # Item
    # Pass to Node to populate its list.
    ITEM = 'item'

    # string
    # option group
    KEY = 'key'

    # int
    # Use when creating a RadioButton.
    LABEL_I = 'label_i'

    # text
    # Give Combo a Label tooltip.
    LABEL_TIP = 'label_tip'

    # tuple
    # low, high
    # limit self value range of a Slider
    LIMIT = 'limit'

    # int
    # Set the minimum width of a TreeViewList column.
    MINIMUM_W = 'minimum_w'

    # tuple
    # Identify an AnyGroup's Preset.
    # (node item) or (model id, node item, ...)
    NAV_K = 'nav_k'

    # function
    # a callback for an Accept Button
    ON_ACCEPT = 'on_accept'

    # function
    # a callback for a Cancel Button
    ON_CANCEL = 'on_cancel'

    # function
    # Is a callback for a ProcessButton override.
    ON_DIALOG_CLOSE = 'on_dialog_close'

    # tuple
    # Alignment padding
    PADDING = 'padding'

    # numeric value
    # Initialize a Slider's GTK Adjustment.
    PAGE_INCR = 'page_incr'

    # int
    # number of digits after the decimal point
    # Is zero for an integer.
    PRECISION = 'precision'

    # RadioButton
    # RadioButton for a group of RadioButtons.
    RADIO_GROUP = 'radio_group'

    # tuple
    # Define a random-function limitation.
    RANDOM_Q = 'random_q'

    # tuple
    # (row, column) cell index; Goo key
    R_C = 'r_c'

    # list of function
    # Notify listener on option change.
    RELAY = 'relay'

    # tuple
    # Use to configure option view.
    RENDER_KEY = 'render_key'

    # Window class instance
    ROLLER_WIN = 'roller_win'

    # string
    # Is a key for an sub-dict in a Preset.
    ROW_KEY = 'row_key'

    # undefined
    # Pass to a TreeViewList to have it make a scrolled window.
    SCROLL = 'scroll'

    # function
    # Call to set the value of a widget.
    SET_A = 'set_a'

    # custom Widget Signal
    # Use to pass a custom signal to a Widget.
    SIGNAL = 'signal'

    # numeric value
    # Use with Slider to initialize the GTK SpinButton.
    STEP_INCR = 'step_incr'

    # None value
    # Is a flag to identify an option as not having change.
    # Skip an option's change checker.
    STILL = 'still'

    # Widget definition group
    SUB = 'sub'

    # string
    # for CheckButton, Label
    TEXT = 'text'

    # function
    # Use to make a tooltip.
    TIPPER = 'tipper'

    # tuple
    # Use to set multiple tooltips.
    TIPS = 'tips'

    # string
    # for a tooltip
    TOOLTIP = 'tooltip'

    # color
    # Use to set the background color of a TreeView.
    TREE_COLOR = 'tree_color'

    # value
    # Use with the AnyGroup definition dict.
    VAL = 'val'

    # Set a Widget class.
    WIDGET = 'widget'

    # string
    # Use to pass a Window's key for storage in the Window position dict.
    WINDOW_KEY = 'window_key'

    # Use when initializing a Widget-type
    # to set a Widget attribute.
    ATTRIBUTE = (
        ALIGN,
        ANY_GROUP,
        COLUMN,
        DIALOG,
        FUNCTION,
        KEY,
        NAV_K,
        RANDOM_Q,
        ROLLER_WIN,
        ROW_KEY,
        TEXT
    )
