#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from random import randint, uniform
from roller_a_contain import Run
from roller_constant_for import Backdrop as bs
from roller_constant_key import Option as ok
from roller_fu import blur_selection, merge_layer_group
from roller_one import random_rgb
from roller_maya_style import Style
from roller_one_wip import Wip
from roller_view_hub import do_mod, prep_brush, set_draw_line_brush
from roller_view_preset import combine_seed
from roller_view_real import add_sub_base_group, add_wip_layer, clip_to_wip
from roller_view_shadow import make_shadow
import math

"""
Define 'backdrop/trailing_vine' as a Maya-subtype
for managing a variation of backdrop style layer.
"""

SHADOW_D = {
    ok.BLUR: 20.,
    ok.INTENSITY: 100.,
    ok.MODE: "Normal",
    ok.OFFSET_X: -6.,
    ok.OFFSET_Y: .0,
    ok.COLOR_1: (0, 0, 0)
}


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: TrailingVine
    Return: layer or None
        Backdrop Style material
    """
    def _plot_wave():
        """
        Calculate the points for a wave that starts
        at the top of the layer and ends at its bottom.

        Return: list
            [x, y, ...]
            plot
        """
        _q = []
        _y = _angle = .0

        # Pi x 2, '6.28318'
        _f = 6.28318 / wave_length

        while _y < bottom_y:
            _x = math.sin(_angle) * amplitude + x
            _q += [_x, _y]
            _y += 1
            _angle += _f
        return _q

    j = Run.j
    d = maya.value_d
    group = add_sub_base_group(maya)
    e = SHADOW_D
    w, h = Wip.get_size()
    count = int(d[ok.LAYER_COUNT])
    shadow_blur_dec = 90. / count
    bottom_y = h + Wip.y

    combine_seed(d)
    set_draw_line_brush()
    prep_brush()

    for i in range(count):
        amplitude = max(20., w * uniform(.0, .04))
        amp_inc = max(10., w * uniform(.0, .02))
        offset = h * uniform(-.5, .5)
        wave_length = h + offset
        z = add_wip_layer("{} of {}".format(i + 1, count), group)
        e[ok.BLUR] = max(30., (90. - i * 10. - shadow_blur_dec))

        # pixel size, '1.5'
        pdb.gimp_context_set_brush_size(1.5 + i // 2.)
        pdb.gimp_context_set_foreground(random_rgb())

        for _ in range(int(d[ok.WAVE_PER_LAYER])):
            x = randint(0, w)
            q = _plot_wave()

            pdb.gimp_selection_none(j)
            pdb.gimp_paintbrush_default(z, len(q), q)
            amplitude += amp_inc

        z2 = make_shadow(e, group, (z,))

        if z2:
            pdb.gimp_image_reorder_item(j, z2, group, 1)
        blur_selection(z, (count - i) * 3.)

    z = merge_layer_group(group)

    clip_to_wip(z)
    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class TrailingVine(Style):
    """Create Backdrop Style output."""
    dependency = bs.INDEPENDENT

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self, any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.BRW, ok.MOD, ok.BLUR_D)
            ],
            make_style
        )
