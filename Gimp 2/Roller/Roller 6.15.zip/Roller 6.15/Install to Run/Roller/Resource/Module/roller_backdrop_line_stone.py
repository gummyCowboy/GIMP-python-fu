#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE,
    HISTOGRAM_VALUE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_EXCLUSION,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_HARD_MIX,
    LAYER_MODE_HSV_VALUE,
    LAYER_MODE_LCH_LIGHTNESS,
    LAYER_MODE_NORMAL,
    LAYER_MODE_OVERLAY,
    pdb
)
from roller_a_contain import Run
from roller_a_gegl import color_to_grey, edge, emboss, unsharp_mask
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clone_layer,
    dilate,
    make_layer_group,
    merge_layer_group
)
from roller_maya_style import Style, make_background
from roller_one_wip import Wip
from roller_view_hub import do_curves, do_mod
from roller_view_preset import combine_seed
from roller_view_real import insert_copy_above

"""
Define 'backdrop/line_stone' as a Maya-subtype
for managing a variation of backdrop style layer.
"""

STEP = "Line Stone Step {} of 5"


def do_step_one(j, z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = clone_layer(z)
    group = make_layer_group(j, STEP.format(1), parent, 0, z=z)
    z = clone_layer(z, n="HSV Value")
    z.mode = LAYER_MODE_HSV_VALUE

    edge(z)

    # no linear, '0'
    pdb.gimp_drawable_invert(z, 0)

    z = clone_layer(z, n="LCH Lightness")
    z.mode = LAYER_MODE_LCH_LIGHTNESS
    z.opacity = 25.
    z = clone_layer(z, n="Hard Mix")
    z.mode = LAYER_MODE_HARD_MIX
    z.opacity = 20.
    return merge_layer_group(group)


def do_step_two(j, z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = clone_layer(z, n="Erode")
    group = make_layer_group(j, STEP.format(2), parent, 0, z=z)

    dilate(z)
    pdb.plug_in_erode(
        j, z,
        1,                  # propagate black
        7,                  # RGB channels
        1.,                 # full rate
        0,                  # direction mask
        0,                  # lower limit
        255                 # upper limit
    )
    return merge_layer_group(group)


def do_step_three(j, z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = clone_layer(z)
    group = make_layer_group(j, STEP.format(3), parent, 0, z=z)

    blur_selection(z, 8)
    pdb.plug_in_despeckle(
        j, z,
        4,
        3,                  # recursive adaptive
        248,                # white cut-off
        7                   # black cut-off
    )
    dilate(z)

    z = clone_layer(z, n="HSV Value")
    z.mode = LAYER_MODE_HSV_VALUE

    dilate(z)
    return merge_layer_group(group)


def do_step_four(j, z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = clone_layer(z, n="Clouds")
    group = make_layer_group(j, STEP.format(4), parent, 0, z=z)

    # The foggify output is on a layer with zero offset.
    pdb.python_fu_foggify(j, z, "Clouds 2", (127, 127, 127), 3., 100.)
    z1 = j.active_layer
    x, y, w, h = map(int, Wip.get_rect())
    pdb.gimp_layer_set_offsets(z1, x, y)
    pdb.gimp_layer_resize(z1, w, h, 0, 0)           # offset x, y: '0'
    return merge_layer_group(group)


def do_step_five(j, z, bg_z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    bg_z: layer
        background clone

    parent: layer
        container group
    """
    group = make_layer_group(j, "WIP", parent, 0, z=z)
    z = z1 = clone_layer(z, n="Overlay #1")
    z.mode = LAYER_MODE_OVERLAY
    z.opacity = 100.

    pdb.plug_in_hsv_noise(
        j, z,
        1,                  # minimum holdness (1 through 8)
        5,                  # hue-distance angle (0 through 180)
        5,                  # saturation-distance (0 through 255)
        5                   # value-distance (0 through 255)
    )
    emboss(z, 45., 15., 3)
    do_curves(z, (.0, .3921, 1., .6078))

    z = bg_z
    z.mode = LAYER_MODE_OVERLAY
    z.opacity = 100.

    pdb.gimp_image_reorder_item(j, z, group, 1)

    # four coordinates, '4'
    pdb.gimp_drawable_curves_spline(z, HISTOGRAM_VALUE, 4, (.0, 1., 1., .5))

    z = clone_layer(z, n="Difference")
    z.mode = LAYER_MODE_DIFFERENCE
    z.opacity = 50.
    z = clone_layer(z, n="Exclusion")
    z.mode = LAYER_MODE_EXCLUSION
    z.opacity = 25.

    color_to_grey(z)

    z1.opacity = 50.
    z = merge_layer_group(group)
    unsharp_mask(z, 5., 1.5, .3)


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: LineStone
    Return: layer
        Backdrop Style material
    """
    j = Run.j
    d = maya.value_d

    combine_seed(d)
    parent, group, z = make_background(j, maya)
    bg_z = clone_layer(z, "Overlay")

    pdb.gimp_image_reorder_item(j, bg_z, parent, 1)

    z = z1 = do_step_one(j, z, group)
    z = do_step_two(j, z, group)
    z.mode = LAYER_MODE_GRAIN_EXTRACT
    z2 = insert_copy_above(z, parent.layers[0])
    z.mode = LAYER_MODE_NORMAL
    z = z2
    z.mode = LAYER_MODE_HARD_MIX
    z = insert_copy_above(z, parent.layers[0])
    z.mode = LAYER_MODE_HSV_VALUE

    j.remove_layer(z1)
    j.remove_layer(z2)

    z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
    z = do_step_three(j, z, group)
    z = do_step_four(j, z, group)
    z.mode = LAYER_MODE_LCH_LIGHTNESS
    z = merge_layer_group(group)

    do_step_five(j, z, bg_z, parent)

    z = merge_layer_group(parent)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class LineStone(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
