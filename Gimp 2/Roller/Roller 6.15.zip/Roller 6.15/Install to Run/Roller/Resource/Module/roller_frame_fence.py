#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_a_contain import Globe
from roller_a_gegl import antialias
from roller_constant_for import Frame as ff
from roller_constant_key import Material as ma, Option as ok
from roller_frame import do_embossed_frame
from roller_frame_alt import FrameBasic

"""
Define 'frame_freeze' as a Maya-subtype
for managing a variation of Frame type.
"""


def make_pattern(z, d):
    """
    Make a pattern from a black and white mosaic.

    z: layer
        Receive pattern.

    d: dict
        Fence Preset

    Return: layer
        mosaic pattern
    """
    j = z.image

    pdb.plug_in_mosaic(
        j,
        z,
        d[ok.MESH_SIZE],
        1.,                                     # tile height
        d[ok.WIRE_THICKNESS],
        d[ok.NEATNESS],
        0,                                      # no split
        Globe.azimuth,
        .0,                                     # minimum color variation
        1,                                      # yes, antialias
        1,                                      # yes, average color
        ff.MESH_TYPE.index(d[ok.MESH_TYPE]),
        0,                                      # smooth surface
        0                                       # black and white grout
    )

    # Erase white pixel.
    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))

    return z


def do_matter(maya):
    """
    Make a frame.

    maya: Fence
    Return: layer
        Wrap output
    """
    z = do_embossed_frame(maya, make_pattern)

    antialias(z)
    return z


class Fence(FrameBasic):
    filler_k = ok.FILLER_FE
    kind = material = ma.FENCE
    wrap_k = ok.WRAP_PA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
