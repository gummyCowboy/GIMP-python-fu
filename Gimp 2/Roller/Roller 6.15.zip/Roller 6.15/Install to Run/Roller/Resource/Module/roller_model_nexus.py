#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Model as md
from roller_model_box import Box
from roller_model_cell import Cell
from roller_model_pyramid import Pyramid
from roller_model_sidewalk import Sidewalk
from roller_model_stack import Stack
from roller_model_table import Table

"""Translate a Model type into a Model class."""


# {Model Type, Model class}
CLASS_MODEL = {
    md.BOX: Box,
    md.CELL: Cell,
    md.PYRAMID: Pyramid,
    md.SIDEWALK: Sidewalk,
    md.STACK: Stack,
    md.TABLE: Table
}
