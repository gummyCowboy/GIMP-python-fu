#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_EXCLUSION,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_HSV_HUE,
    LAYER_MODE_LINEAR_LIGHT,
    LAYER_MODE_LUMA_LIGHTEN_ONLY,
    LAYER_MODE_OVERLAY,
    LAYER_MODE_PIN_LIGHT,
    pdb
)
from roller_a_contain import Globe, Run
from roller_a_gegl import (
    edge, emboss, median_blur, unsharp_mask, waterpixels
)
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def_access import get_default_value
from roller_fu import (
    blur_selection,
    clone_layer,
    dilate,
    hide_layer,
    make_layer_group,
    merge_layer_group,
    select_rect
)
from roller_maya_style import Style, make_background
from roller_one_wip import Wip
from roller_view_hub import (
    color_layer_default, do_gradient_for_layer, do_mod, get_gradient_factors
)
from roller_view_real import add_wip_layer, insert_copy

"""
Define 'backdrop/clay_chemistry' as a Maya-subtype
for managing a variation of backdrop style layer.
"""


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: Style
    Return: layer
        Backdrop Style material
    """
    j = Run.j
    d = maya.value_d
    parent, group, z = make_background(j, maya)
    backdrop_z = clone_layer(z)

    pdb.gimp_image_reorder_item(j, backdrop_z, parent, 1)

    z1 = clone_layer(z)

    blur_selection(z, 300)

    z1.name = "HSV Hue"
    z1.mode = LAYER_MODE_HSV_HUE

    pdb.plug_in_gimpressionist(j, z1, "Painted_Rock")

    z = insert_copy(group,  z1)
    z.mode = LAYER_MODE_DIFFERENCE

    edge(z)

    z = insert_copy(group, z)
    z.mode = LAYER_MODE_EXCLUSION

    select_rect(j, *Wip.get_rect())
    dilate(z)
    waterpixels(z)
    unsharp_mask(z, 3., 30., .0)

    z = insert_copy(group, z)
    z = clone_layer(z, n="Linear Light")
    z.mode = LAYER_MODE_LINEAR_LIGHT

    blur_selection(z, 12)

    z = insert_copy(group, z)

    dilate(z)
    dilate(z)

    z.mode = LAYER_MODE_GRAIN_EXTRACT
    z1 = merge_layer_group(group)
    group = make_layer_group(j, "WIP", parent, 0, z=z1)
    z2 = clone_layer(z1, n="Luma Lighten Only")

    waterpixels(z2)

    z2.mode = LAYER_MODE_LUMA_LIGHTEN_ONLY
    z2 = pdb.gimp_image_merge_down(j, z2, CLIP_TO_IMAGE)
    z3 = clone_layer(z2, n="Median Blur")

    median_blur(z3, 32, 50.)

    z4 = clone_layer(z3, n="Pin Light")
    z4.mode = LAYER_MODE_PIN_LIGHT

    edge(z4)
    pdb.plug_in_erode(
        j, z4,
        1,                              # propagate black
        7,                              # RGB channels
        1.,                             # full rate
        7,                              # direction mask
        0,                              # low limit
        255                             # upper limit
    )

    z = insert_copy(group, z4)
    z2.mode = LAYER_MODE_OVERLAY
    z.opacity = 33.

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    emboss(z2, Globe.azimuth, 12., 1.)
    hide_layer(z3)
    hide_layer(z4)

    e = get_default_value(by.GRADIENT_FILL)
    e[ok.GRADIENT] = d[ok.RW1][ok.GRADIENT]
    e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
        get_gradient_factors(d)
    e[ok.REVERSE] = d[ok.REVERSE]
    z1 = do_gradient_for_layer(e, group, len(group.layers) - 1)
    z = add_wip_layer("Back", group, offset=len(group.layers) + 1)
    z.opacity = z1.opacity = d[ok.GRADIENT_OPACITY]

    color_layer_default(z, (64, 64, 64))
    blur_selection(backdrop_z, 300)
    pdb.gimp_image_reorder_item(
        j, backdrop_z, group, len(group.layers) + 1
    )

    z = merge_layer_group(parent)

    do_mod(z, d[ok.RW1][ok.MOD])
    return maya.rename_layer(z)


class ClayChemistry(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
