#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Deco as dc
from roller_constant_key import Option as ok, Widget as wk
from roller_def_dialog import (
    ADD,
    BRUSH_DIALOG,
    FCM,
    IMAGE_CHOICE,
    IMR,
    IRM,
    LTR,
    MAF,
    MASK,
    MAW,
    MFR,
    MOD,
    STRIP
)
from roller_def_option import (
    ANGLE,
    BORDER_W,
    BRUSH,
    CAPTION_TYPE,
    COLOR_1,
    COLOR_6,
    COLOR_COUNT_FRINGE,
    CONTRACT,
    DECO_TYPE,
    FONT_SIZE,
    GRADIENT,
    GRADIENT_ANGLE,
    GRADIENT_TYPE,
    HARDNESS,
    JUSTIFICATION,
    LINE_W_LINE,
    MAX_POLAR_X,
    MAX_POLAR_Y,
    MAX_POSITIVE_X,
    MAX_POSITIVE_Y,
    MODE,
    NET_LINE,
    OBEY_MARGIN,
    OPACITY,
    PATTERN,
    PER,
    SEED,
    START_NUMBER,
    SWITCH,
    TEXT
)
from roller_widget_row import WidgetRow

"""Define sub-Model decorator Preset."""

net_line_w = deepcopy(NET_LINE)
net_line_w[wk.VAL] = 2.


def get_fringe_type_list():
    return dc.FRINGE_TYPE


# Border_______________________________________________________________________
BORDER = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.TYPE, deepcopy(DECO_TYPE)),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BORDER_W, deepcopy(BORDER_W)),
    (ok.NLS, deepcopy(NET_LINE)),
    (ok.NET_LINE_W, net_line_w),
    (ok.SEED, deepcopy(SEED)),
    (ok.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.GRADIENT, deepcopy(GRADIENT)),
    (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
    (ok.PATTERN, deepcopy(PATTERN)),
    (ok.RW1, deepcopy(MFR)),
    (ok.BRW, deepcopy(MAW)),
    (ok.PER, deepcopy(PER))
])
BORDER[ok.COLOR_1][wk.VAL] = 127, 127, 127
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Caption______________________________________________________________________
CAPTION = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.TYPE, deepcopy(CAPTION_TYPE)),
    (ok.JUSTIFY, deepcopy(JUSTIFICATION)),
    (ok.TEXT, deepcopy(TEXT)),
    (ok.LTR, deepcopy(LTR)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.FONT_SIZE, deepcopy(FONT_SIZE)),
    (ok.START_NUMBER, deepcopy(START_NUMBER)),
    (ok.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (ok.RW1, deepcopy(FCM)),
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.MOD, deepcopy(MOD)),
            (ok.ADD, ADD),
            (ok.STRIP, deepcopy(STRIP))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.PER, deepcopy(PER))
])
CAPTION[ok.RW1][wk.SUB][ok.COLOR_1][wk.TOOLTIP] = "Text Color"
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Fringe_______________________________________________________________________
FRINGE = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.TYPE, deepcopy(DECO_TYPE)),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.CONTRACT, deepcopy(CONTRACT)),
    (ok.COLOR_COUNT, deepcopy(COLOR_COUNT_FRINGE)),
    (ok.NLS, deepcopy(NET_LINE)),
    (ok.NET_LINE_W, net_line_w),
    (ok.SEED, deepcopy(SEED)),
    (ok.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (ok.COLOR_6, deepcopy(COLOR_6)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.GRADIENT, deepcopy(GRADIENT)),
    (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
    (ok.PATTERN, deepcopy(PATTERN)),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.BRUSH_D, deepcopy(BRUSH_DIALOG)),
            (ok.MASK, deepcopy(MASK))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.BRW, deepcopy(MAF)),
    (ok.PER, deepcopy(PER))
])
FRINGE[ok.TYPE][wk.FUNCTION] = get_fringe_type_list
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Image__________________________________________________________
IMAGE = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.JUSTIFY, deepcopy(JUSTIFICATION)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (ok.RW1, deepcopy(IRM)),
    (ok.BRW, deepcopy(MAF)),
    (ok.PER, deepcopy(PER))
])
IMAGE[ok.RW1][wk.SUB][ok.IMAGE_CHOICE][wk.SUB][ok.TYPE][wk.VAL] = ok.LOOP
IMAGE[ok.OBEY_MARGIN][wk.VAL] = 1
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Line_________________________________________________________________________
LINE = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.LINE_W, deepcopy(LINE_W_LINE)),
    (ok.HARDNESS, deepcopy(HARDNESS)),
    (ok.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.COLOR_1, deepcopy(COLOR_1)),
            (ok.BRUSH, deepcopy(BRUSH))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.BRW, deepcopy(MAF)),
    (ok.PER, deepcopy(PER))
])
LINE[ok.RW1][wk.SUB][ok.BRUSH][wk.VAL] = "1. Pixel"
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Plaque_______________________________________________________________________
PLAQUE = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.TYPE, deepcopy(DECO_TYPE)),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.NLS, deepcopy(NET_LINE)),
    (ok.NET_LINE_W, net_line_w),
    (ok.SEED, deepcopy(SEED)),
    (ok.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.GRADIENT, deepcopy(GRADIENT)),
    (ok.PATTERN, deepcopy(PATTERN)),
    (ok.RW1, deepcopy(IMR)),
    (ok.BRW, deepcopy(MAF)),
    (ok.PER, deepcopy(PER))
])
PLAQUE[ok.COLOR_1][wk.VAL] = 255, 255, 255
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Shift________________________________________________________________________
SHIFT = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.OFFSET_X, deepcopy(MAX_POLAR_X)),
    (ok.OFFSET_Y, deepcopy(MAX_POLAR_Y)),
    (ok.WIDTH_MOD, deepcopy(MAX_POLAR_X)),
    (ok.HEIGHT_MOD, deepcopy(MAX_POLAR_Y)),
    (ok.JITTER_X, deepcopy(MAX_POSITIVE_X)),
    (ok.JITTER_Y, deepcopy(MAX_POSITIVE_Y)),
    (ok.JITTER_W, deepcopy(MAX_POSITIVE_X)),
    (ok.JITTER_H, deepcopy(MAX_POSITIVE_Y)),
    (ok.SEED, deepcopy(SEED)),
    (ok.PER, deepcopy(PER))
])

for i in (ok.JITTER_X, ok.JITTER_W, ok.OFFSET_X, ok.WIDTH_MOD):
    SHIFT[i].update({wk.AXIS: 'x'})
for i in (ok.HEIGHT_MOD, ok.JITTER_H, ok.JITTER_Y, ok.OFFSET_Y):
    SHIFT[i].update({wk.AXIS: 'y'})
