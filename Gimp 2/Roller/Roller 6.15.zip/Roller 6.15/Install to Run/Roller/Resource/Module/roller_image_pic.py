#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import gimp, pdb  # type: ignore


def image_undo_end():
    """
    The changes are bundled. Call after
    placing images with Work or Plan.
    """
    for j in Pic.tab_q:
        if pdb.gimp_image_is_valid(j):
            pdb.gimp_image_undo_group_end(j)


def image_undo_start():
    """
    Roll image changes into a ball. Call
    before placing images with Work or Plan.
    """
    for j in Pic.tab_q:
        if pdb.gimp_image_is_valid(j):
            pdb.gimp_image_undo_group_start(j)


class Pic:
    """Store image reference with a mostly static class."""
    # Retrieve a previously auto-cropped image.
    # {image id: Single}
    autocrop_d = {}

    # Reuse a loaded file-path image.
    # {file-path string: Single}.
    file_d = {}

    # Recall flat or flatten image reference.
    # {image id: Single}
    flat_d = {}

    # Folder Reference________________________________________________
    # The dict is used to store a file list for each folder reference.
    #
    # The key is a tuple: (folder path string, filter string).
    # The value is a file list.
    # The file list is a list of file-path string found in the folder.
    # The sub-folder content is not included in the file list.
    folder_d = {}

    # Recall GIMP image made from a GIMP layer.
    # {GIMP layer id: GIMP image}
    layer_d = {}

    # Are of GIMP image name from image already open when Roller starts.
    # [string, ...]
    name_q = []

    # Close opened GIMP image on Roller exit.
    # [GIMP image]
    opened_q = []

    # The key is a tuple:
    # (row slice count, column slice count, image width, image height).
    # The value is a 2D list.
    rect_table_d = {}

    # Recall slice Single.
    # {(layer id, x, y, w, h): Single}
    # Define a rectangle with x, y, w, h.
    slice_d = {}

    # Is the total number of image tab when Roller starts.
    tab_count = 0

    # Are Single made from open image.
    # {tab index: Single}
    tab_d = {}

    # Are open image in image tab that are
    # already open in GIMP when Roller starts.
    tab_q = []

    # Recall GIMP image layer tree.
    # The layer order is top-down.
    # {GIMP image id: list of layer}
    tree_d = {}

    def __init__(self):
        """
        Collect related data for images. GIMP's
        image list data is right to left tab ordered.
        """
        # post-fix image number tuple (GIMP image id)
        id_q = pdb.gimp_image_list()[1][::-1]

        Pic.tab_q = gimp.image_list()[::-1]
        Pic.tab_count = len(Pic.tab_q)

        q = Pic.name_q = [
            j.name + "-" + str(id_q[i]) for i, j in enumerate(Pic.tab_q)
        ]
        if not q:
            # There is no open image.
            q.append("None")
