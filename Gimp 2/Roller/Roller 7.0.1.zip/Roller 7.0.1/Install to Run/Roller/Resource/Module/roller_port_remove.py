#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Define as df
from roller_port_preview import PortPreview
from roller_widget_box import Box as boxer
from roller_widget_button import AcceptButton, Button, CancelButton
from roller_widget_tree import ChoiceList
import gtk  # type: ignore


class PortRemove(PortPreview):
    """Remove a Heat material."""
    window_key = "Remove Material"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: Button
            responsible
        """
        self._del_button = \
            self._chooser = \
            self._accept_button = \
            self._cancel_button = None
        self._item_k = g.any_group.dna.key
        self._get_list = g.get_list
        PortPreview.__init__(self, d, g)

    def _draw_list_group(self, g):
        """
        Draw a ChoiceList containing a Preset list.

        g: GTK container
            for list group
        """
        self._chooser = ChoiceList(
            **{
                df.CHOICE: self._get_list()[0],
                df.FUNCTION: self._get_list,
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win,
                df.TREE_COLOR: self.color
            }
        )

        g.pack_start(self._chooser, expand=True)

        # Connect event.
        self._chooser.treeview.connect(
            'key_press_event', self._on_choice_list_keypress
        )

    def _get_selection(self):
        """
        Get the selection in the ChoiceList.

        Return: int or None
            0 to n
        """
        if self._chooser:
            return self._chooser.get_selected_r()

    def delete_item(self, *_):
        """
        Delete the selected item from the list.

        _: Delete Button
            not used
        """
        i = self._get_selection()

        if i is not None:
            self._chooser.remove_row(i)
        self.on_port_change()

    def draw_process_group(self, g):
        """
        Draw a Widget group having process Buttons.

        g: GTK container
            Receive Widget group.
        """
        hbox = boxer(box=gtk.HBox, align=(0, 0, 1, 1))
        self._cancel_button = CancelButton(
            align=(0, 0, 1, 0),
            padding=(4, 4, 4, 2),
            relay=[],
            roller_win=self.roller_win,
        )
        self._del_button = Button(
            align=(0, 0, 1, 0),
            padding=(4, 4, 2, 2),
            relay=[self.delete_item],
            roller_win=self.roller_win,
            text="Delete"
        )
        self._accept_button = AcceptButton(
            align=(0, 0, 1, 0),
            padding=(4, 4, 2, 4),
            relay=[],
            roller_win=self.roller_win,
        )

        for i in (self._cancel_button, self._del_button, self._accept_button):
            hbox.add(i)
        g.pack_end(hbox, expand=False)

    def draw(self):
        """Draw Widget."""
        self.draw_list(
            (self._draw_list_group, self.draw_process_group),
            ("Remove Material ", "")
        )
        self.roller_win.gtk_win.vbox.set_size_request(350, 350)
        self.on_port_change()

    def get_group_value(self):
        """
        Provide the value of the ChoiceList.

        Return: set
            {material key, ...}
        """
        return set(self._chooser.item_list)

    def _on_choice_list_keypress(self, _, event):
        """
        Respond to ChoiceList Treeview keypress. Determine
        if the keypress is a Delete key, call the
        confirmation dialog.

        _: Treeview
        event: GTK Event
        """
        if gtk.gdk.keyval_name(event.keyval) == 'Delete':
            self.delete_item()
            return True

    def on_port_change(self, *_):
        """
        Respond to a choice list change.

        _: tuple
            not used
        """
        g = self._del_button
        if g:
            if self._get_selection() is not None:
                g.set_sensitive(1)
            else:
                g.set_sensitive(0)
