#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_container import Dog, The
from roller_constant import Define as df, Signal as si
from roller_constant_identity import Identity as de
from roller_ring import Ring
from roller_shelf import Shelf
from roller_port_preview import PortPreview
from roller_step import (
    connect_sub_str,
    count_parts,
    drop_first_part,
    get_branch_step_list,
    get_first_part,
    get_last_part
)
from roller_widget_box import Box as boxer
from roller_widget_check_button import CheckButton
from roller_widget_dna import DNA
from roller_widget_label import Label
from roller_widget_row import SelectRow
import gtk  # type: ignore

CANVAS = (
    de.MARGIN, de.PLAQUE, de.FRINGE, de.BORDER, de.IMAGE, de.LINE, de.CAPTION
)
CELL = (de.SHIFT,) + CANVAS

# Model branch format used in PortReviseModel.
CHECKBUTTON_KEY = "{},{}"

FACING = de.PLAQUE, de.FRINGE, de.BORDER, de.IMAGE, de.LINE, de.CAPTION
MODEL_BRANCH = {
    de.BOX: OrderedDict([
        (de.CANVAS, CANVAS),
        (de.CELL, CELL),
        (de.FACE, FACING)
    ]),
    de.CELL: {de.CELL: CELL},
    de.PYRAMID: OrderedDict([(de.CANVAS, CANVAS), (de.CELL, CELL)]),
    de.SIDEWALK: OrderedDict([
        (de.CANVAS, CANVAS),
        (de.CELL, CELL),
        (de.FACING, FACING)
    ]),
    de.STACK: {de.CELL: CELL},
    de.TABLE: OrderedDict([(de.CANVAS, CANVAS), (de.CELL, CELL)])
}
TEXT_REVISE = \
    "Choose Model Step for the {} Model.\n" \
    "Activate a Step with the Model/Step… button."


def format_checkbutton_k(k):
    """
    k: string
        "leaf.branch"

    Return: string
        "branch.leaf"
    """
    q = k.split(',')
    return connect_sub_str(q[1], q[0])


class PortReviseModel(PortPreview):
    """Initial the model's available steps."""
    window_key = "Refine Model"

    def __init__(self, d, g):
        self.model_type = None
        self._init_d = d
        self.model_name = The.model_list.get_selected_name()

        # [branch-leaf-key, ...] of the current Model's
        # available step, '_previous_step_list'.
        # branch-leaf-key -> 'branch.leaf'
        self._previous_step_list = []

        PortPreview.__init__(self, d, g)

    def draw(self):
        """Draw the Port's Widgets."""
        self.draw_column((
            self.draw_revise_model, self.draw_selector, self.draw_basic_process
        ))

    def draw_revise_model(self, box):
        """
        Override the base class function so
        that step CheckButton can be initialized.

        box: GTK container
            Receive Widget group.
        """
        d = The.model_list.get_model_dict()
        self.model_type = d.get(self.model_name)

        self.draw_model_option(box, TEXT_REVISE)

        # Get all of the Model's sub-Model-name-step-key
        # into a list. The step-key can be found in the
        # Shelf or in the navigation tree.
        # An example of sub-Model-name-step-key is 'Cell.Image'.
        # Init to Model's active branch step list, 'q'.
        q = get_branch_step_list(self.model_name)

        # list of the Model's shelved Model-name-step-key, 'q1'
        q1 = Shelf.get_model_only_step_list(self.model_name)

        # Collect branch-step-key as ['branch.leaf', ...], 'q'.
        # length of a branched leaf Model step-key, '3'
        q = [drop_first_part(i) for i in q if count_parts(i) == 3]
        q.extend([drop_first_part(i) for i in q1 if count_parts(i) == 3])

        # Convert the branch key to a Define Model CheckButton key.
        # branch-leaf-key, 'i'
        self._previous_step_list = q
        q = [
            CHECKBUTTON_KEY.format(
                get_last_part(i), get_first_part(i)) for i in q
        ]

        # Create a list of CheckButton key.
        key_d = {i.key: i for i in self.widget_q}

        # Initialize CheckButton value when the branch
        # key has been defined with the Model.
        # string formatted as 'branch,leaf', 'i'
        for i in q:
            if i in key_d.keys():
                key_d[i].set_ui(1)

    def draw_model_option(self, box, label_text):
        """
        Draw step CheckButton.

        box: GTK container
            Receive AnyGroup option.
        """
        self.is_dirt = True
        buttons = self.widget_q = []
        dna = DNA(de.REVISE_MODEL, {'make_vbox', 'preset'}, {})

        dna.inherit(self.repo.any_group.dna, False)
        box.add(dna.vbox)
        dna.vbox.add(
            Label(
                **{
                    df.PADDING: (4, 4, 4, 4),
                    df.TEXT: label_text.format(self.model_type)
                }
            )
        )

        d = {df.NO_VOTE: True, df.RELAY: []}

        d.update(self._init_d)

        for branch, q in MODEL_BRANCH[self.model_type].items():
            dna.vbox.add(
                Label(
                    **{
                        df.PADDING: (4, 4, 4, 4),
                        df.TEXT: "\n{}".format(branch)
                    }
                )
            )

            vbox_list = boxer(), boxer(), boxer()
            hbox = gtk.HBox()

            dna.vbox.add(hbox)

            for i in range(3):
                hbox.add(vbox_list[i])
            for i, n in enumerate(q):
                d[df.KEY] = CHECKBUTTON_KEY.format(n, branch)
                d[df.TEXT] = n
                buttons.append(CheckButton(padding=(0, 0, 4, 4), **d))
                vbox_list[i % 3].add(buttons[-1])

        dna.vbox.add(
            Label(**{df.PADDING: (4, 4, 4, 4), df.TEXT: "\n"})
        )
        self.any_group = Dog.none_group(
            **{
                df.COLOR: self.color,
                df.DNA: dna,
                df.PADDING: (4, 4, 4, 4),
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win
            }
        )

    def draw_selector(self, box):
        """
        Create a WidgetRow with two select options.

        box: GTK container
            to receive group
        """
        self._init_d[df.RELAY] = []
        box.add(SelectRow(self.widget_q, **self._init_d))

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return self.on_cancel_revise_model, self.on_accept_revise_model

    def on_cancel_revise_model(self, *_):
        """
        Send ModelList's change signal, so that
        it can update its Step Button's sensitivity.

        _: undefined
        """
        Ring.plug(si.MODEL_LIST_CHANGE, None)

    def on_accept_revise_model(self, _):
        """
        Modify the navigation tree with the new tree of steps.

        _: Button
            Is responsible.
        """
        q = self.widget_q
        Ring.plug(
            si.MODEL_REVISE,
            (
                {
                    format_checkbutton_k(q[i].key): q[i].get_ui()
                    for i in range(len(q))
                },
                self._previous_step_list,
                self.model_name
            )
        )
