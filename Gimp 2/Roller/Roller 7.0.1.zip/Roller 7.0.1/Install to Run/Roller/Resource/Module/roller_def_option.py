#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant import (
    MAX_SIZE, Define as df, Image as fi, Issue as vo
)
from roller_constant_identity import Identity as de
from roller_def_actor import (
    get_background_type_list,
    get_below_type_list,
    get_box_type_list,
    get_brush_list,
    get_bump_type_list,
    get_camo_type_list,
    get_cell_shape_list,
    get_corner_type_list,
    get_criterion_list,
    get_decay_type_list,
    get_deco_type_list,
    get_edge_mode_list,
    get_accent_type_list,
    get_frame_list,
    get_frame_overlay_type_list,
    get_justification_type,
    get_gradient_angle_list,
    get_gradient_list,
    get_gradient_type_list,
    get_grid_type_list,
    get_hexagon_type_list,
    get_image_name_list,
    get_image_type_list,
    get_light_type_list,
    get_mask_list,
    get_mesh_type_list,
    get_mode_name_list,
    get_news_type_list,
    get_noise_list,
    get_octagon_type_list,
    get_pattern_list,
    get_pin_list,
    get_profile_list,
    get_rectangle_type_list,
    get_resize_type_list,
    get_reverb_type_list,
    get_shape_list,
    get_shaped_list,
    get_spiral_mod_list,
    get_triangle_type_list,
    get_wave_fill_type_list,
    get_wrap_types,
)
from roller_tooltip_text import Tip
from roller_tooltip_actor import (
    make_bool_tip,
    make_radio_tip,
    make_rainbow_count_tip,
    make_rainbow_tip,
    make_slider_tip,
    make_text_tip
)
from roller_port_choice import PortChoice
from roller_widget_button import RandomButton
from roller_widget_check_button import CheckButton, CheckButtonRandom
from roller_widget_color_button import RandomColorButton
from roller_widget_combo import CaptionComboBox, ComboBox
from roller_widget_entry import Entry
from roller_widget_label import ModelTypeLabel
from roller_widget_number_pair import RectPair, RenderPair
from roller_widget_value_button import ListButton
from roller_widget_per import PerGroup
from roller_widget_slider import RandomSlider, Slider
from roller_widget_radio import (
    RadioRandomColumn, RadioRandomRow, SwitchRadio
)
from roller_widget_row import Rainbow
import sys

"""Define Widget option."""

# Base Type____________________________________________________________________
_CHECK_BUTTON = {
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_bool_tip,
    df.VALUE: 0,
    df.WIDGET: CheckButton
}
_CHECK_BUTTON_RANDOM = {
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_bool_tip,
    df.VALUE: 0,
    df.WIDGET: CheckButtonRandom
}
_COMBO_BOX = {
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_text_tip,
    df.WIDGET: ComboBox
}
_ENTRY = {
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_text_tip,
    df.WIDGET: Entry
}
_LIST_BUTTON = {
    df.NO_VOTE: True,
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_text_tip,
    df.WIDGET: ListButton
}
_RAINBOW = {
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_rainbow_tip,
    df.WIDGET: Rainbow
}
_RADIO_RANDOM_COLUMN = {
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_radio_tip,
    df.VALUE: 0,
    df.WIDGET: RadioRandomColumn
}
_RADIO_RANDOM_ROW = {
    df.ISSUE: vo.MATTER,
    df.RANDOM_Q: (0, 1),
    df.TIP_P: make_radio_tip,
    df.VALUE: 0,
    df.WIDGET: RadioRandomRow
}
_RANDOM_COLOR_BUTTON = {
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_text_tip,
    df.WIDGET: RandomColorButton
}
_RANDOM_SLIDER = {
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_text_tip,
    df.WIDGET: RandomSlider
}
_RECT_PAIR = {
    df.ISSUE: vo.MATTER,
    df.LIMIT: (0, MAX_SIZE),
    df.TIP_P: make_slider_tip,
    df.VALUE: (0, .2),
    df.WIDGET: RectPair
}
_RENDER_PAIR = {
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_slider_tip,
    df.TIPS: (Tip.SLIDER_INT_PART,),
    df.VALUE: (0, .0),
    df.WIDGET: RenderPair
}
_SLIDER = {
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_text_tip,
    df.WIDGET: Slider
}
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

AMOUNT = {
    df.LIMIT: (1, 10),
    df.RANDOM_Q: (1, 10),
    df.VALUE: 1.
}
AMP = {
    df.LIMIT: (2, 30),
    df.RANDOM_Q: (2, 30),
    df.TOOLTIP: Tip.AMP,
    df.VALUE: 3.
}
AMPLITUDE = {
    df.LIMIT: (.0, 1000.),
    df.PRECISION: 1,
    df.RANDOM_Q: (.0, 20.),
    df.VALUE: 4.
}
AMPLITUDE_1 = {
    df.LIMIT: (.0, .5),
    df.PRECISION: 3,
    df.RANDOM_Q: (.0, .5),
    df.VALUE: .25
}
ANGLE = {
    df.LIMIT: (-359., 359.),
    df.PAGE_INCR: 30.,
    df.PRECISION: 2,
    df.RANDOM_Q: (-359., 359.),
    df.STEP_INCR: .1,
    df.VALUE: .0
}
ANGLE_JITTER = {
    df.LIMIT: (.0, 180.),
    df.PRECISION: 1,
    df.RANDOM_Q: (.0, 180.),
    df.VALUE: .0
}
ANGLE_SHIFT = {
    df.LIMIT: (.0, 180.),
    df.PRECISION: 1,
    df.RANDOM_Q: (.0, 11.),
    df.TOOLTIP: Tip.DEGREES,
    df.VALUE: 5.
}
AUTOCROP = {df.TOOLTIP: Tip.AUTOCROP}
BACKGROUND_TYPE = {
    df.FUNCTION: get_background_type_list,
    df.VALUE: de.COLOR
}
BELOW_TYPE = {
    df.FUNCTION: get_below_type_list,
    df.LABEL_TIP: Tip.BELOW_TYPE,
    df.VALUE: de.MASK
}
BEVEL_H = {
    df.LIMIT: (0, 255),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (60, 255),
    df.VALUE: 245.
}
BEVEL_W = {
    df.LIMIT: (0, 999),
    df.PAGE_INCR: 2,
    df.RANDOM_Q: (4, 8),
    df.VALUE: 10.
}
BLEND = {
    df.LIMIT: (1, 60),
    df.PAGE_INCR: 2,
    df.RANDOM_Q: (5, 20),
    df.TOOLTIP: Tip.BLEND,
    df.VALUE: 12.
}
BLOCK_W = {df.AXIS: 'x'}
BLOCK_H = {df.AXIS: 'y'}
BLUR = {
    df.LIMIT: (.0, 500.),
    df.PRECISION: 1,
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (.0, 50.),
    df.STEP_INCR: 1.,
    df.VALUE: .0
}
BLUR_POST = {df.TOOLTIP: Tip.BLUR_POST}
BLUR_PRE = {df.TOOLTIP: Tip.BLUR_PRE}

BLUR_POST.update(BLUR)
BLUR_PRE.update(BLUR)

for d_ in (BLUR_POST, BLUR_PRE):
    d_.update({df.PAGE_INCR: 5, df.RANDOM_Q: (.0, 10.)})

BLUR_TYPE = {df.COLUMN_TEXT: de.TYPE, df.TEXT: (de.GAUSSIAN, de.MEDIAN)}
BLUR_XY = {
    df.LIMIT: (1., 100.),
    df.PRECISION: 1,
    df.RANDOM_Q: (3., 20.),
    df.VALUE: .0
}
BORDER_W = {
    df.LIMIT: (1, 9999),
    df.PAGE_INCR: 10,
    df.VALUE: 6.
}
BOX_TYPE = {
    df.FUNCTION: get_box_type_list,
    df.LABEL_TIP: Tip.BOX_TYPE,
    df.VALUE: de.TOP
}
BRUSH = {
    df.DIALOG: PortChoice,
    df.FUNCTION: get_brush_list,
    df.VALUE: "C_Normal Brush 80"
}
BRUSH_ANGLE = {
    df.LIMIT: (-180., 180.),
    df.PRECISION: 1,
    df.RANDOM_Q: (-180., 180.),
    df.VALUE: .0
}
BRUSH_SIZE = {
    df.LIMIT: (10, 9999),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (25, 125),
    df.TOOLTIP: Tip.BRUSH_SIZE,
    df.VALUE: 100.
}
BRUSH_SPACING = {
    df.LIMIT: (1., 5000.),
    df.PAGE_INCR: 10,
    df.PRECISION: 1,
    df.RANDOM_Q: (25., 125.),
    df.VALUE: 100.
}
BUMP_DEPTH = {
    df.LIMIT: (1, 100),
    df.RANDOM_Q: (1, 4),
    df.VALUE: 1.
}
BUMP_TYPE = {
    df.FUNCTION: get_bump_type_list,
    df.VALUE: de.CLOTH
}
CAMO_TYPE = {
    df.FUNCTION: get_camo_type_list,
    df.VALUE: de.COMPOSITE
}
CAP_XY = {
    df.LIMIT: (.0, 1.),
    df.PAGE_INCR: .1,
    df.PRECISION: 3,
    df.STEP_INCR: .01,
    df.VALUE: .5
}
CAPTION_TYPE = {
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_text_tip,
    df.VALUE: de.TEXT,
    df.WIDGET: CaptionComboBox
}
CELL_SHAPE_CELL = {
    df.FUNCTION: get_cell_shape_list,
    df.VALUE: de.RECTANGLE
}
CELL_SIZE = {
    df.LIMIT: (1, MAX_SIZE),
    df.PAGE_INCR: 100,
    df.TOOLTIP: Tip.CELL_SIZE,
    df.VALUE: 250.
}
CELL_SIZE_ETCH = {
    df.LIMIT: (1, 1500),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (1, 100),
    df.VALUE: 9.
}
CIRCLE_DIAMETER = {
    # Is limited by GIMP's clipboard to
    # pattern function where the maximum side
    # span for the clipboard is 1024.
    df.LIMIT: (12, 680),
    df.RANDOM_Q: (12, 100),
    df.VALUE: 30.
}
CLIP = {df.TOOLTIP: Tip.CLIP}
CLIP_FRINGE = {df.TOOLTIP: Tip.CLIP_FRINGE}
CLIPBOARD = {
    df.LIMIT: (6, 1024),
    df.RANDOM_Q: (108, 1024),
    df.VALUE: 512.
}
CLOCKWISE = {}
COLOR_1 = {df.VALUE: (0, 0, 0)}
COLOR_EMBOSS = {df.VALUE: (127, 127, 127)}
COLOR_1A = {
    df.HAS_ALPHA: True,
    df.VALUE: (127, 127, 127, 255)
}
COLOR_2 = {
    df.BUTTON_COUNT: 2,
    df.VALUE: ((0, 0, 0), (255, 255, 255))
}
COLOR_2B = {
    df.BUTTON_COUNT: 2,
    df.VALUE: ((110, 110, 110), (145, 145, 145))
}
COLOR_2A = {
    df.BUTTON_COUNT: 2,
    df.HAS_ALPHA: True,
    df.VALUE: ((64, 64, 64, 255), (187, 187, 187, 255))
}
COLOR_3 = {
    df.BUTTON_COUNT: 3,
    df.VALUE: (
        (160, 160, 160),
        (110, 110, 110),
        (70, 70, 70)
    )
}
COLOR_3A = {
    df.BUTTON_COUNT: 3,
    df.HAS_ALPHA: True,
    df.VALUE: (
        (24, 104, 174, 255),
        (217, 165, 179, 255),
        (198, 215, 235, 255)
    )
}
COLOR_6 = {
    df.BUTTON_COUNT: 6,
    df.VALUE: (
        (0, 0, 0),
        (51, 51, 51),
        (102, 102, 102),
        (153, 153, 153),
        (204, 204, 204),
        (255, 255, 255)
    )
}
COLOR_6A = {
    df.BUTTON_COUNT: 6,
    df.HAS_ALPHA: True,
    df.VALUE: (
        (51, 51, 51, 255),
        (204, 204, 204, 255),
        (0, 0, 0, 255),
        (255, 255, 255, 255),
        (102, 102, 102, 255),
        (153, 153, 153, 255)
    )
}
COLOR_COUNT = {
    df.LIMIT: (2, 6),
    df.PAGE_INCR: 1,
    df.RANDOM_Q: (2, 6),
    df.TOOLTIP: Tip.COLOR_COUNT,
    df.VALUE: 2.
}
COLOR_COUNT_FRINGE = {
    df.LIMIT: (1, 6),
    df.PAGE_INCR: 1,
    df.TOOLTIP: Tip.COLOR_COUNT,
    df.VALUE: 1.
}
COLOR_GRID_TYPE = {df.TEXT: ("Checkerboard", "Brick")}
COLORIZE = {}
CONTRACT = {
    df.LIMIT: (0, 9999),
    df.PAGE_INCR: 50,
    df.TOOLTIP: Tip.CONTRACT,
    df.VALUE: .0
}
CONTRAST = {
    df.LIMIT: (-127, 127),
    df.RANDOM_Q: (-30, 30),
    df.VALUE: .0
}
CORNER_SHIFT = {
    df.LIMIT: (0, 100),
    df.PAGE_INCR: 5,
    df.RANDOM_Q: (0, 18),
    df.TOOLTIP: Tip.PIXELS,
    df.VALUE: 9.
}
CORNER_TYPE = {
    df.FUNCTION: get_corner_type_list,
    df.VALUE: de.CUT_CORNER
}
CRITERION = {
    df.FUNCTION: get_criterion_list,
    df.VALUE: de.COMPOSITE
}
CROP_XY = {
    df.LIMIT: (0, MAX_SIZE),
    df.PAGE_INCR: 10,
    df.VALUE: .0
}
DECO_TYPE = {df.FUNCTION: get_deco_type_list, df.VALUE: de.COLOR}
DEPTH = {
    df.LIMIT: (1., 100.),
    df.PAGE_INCR: 5,
    df.PRECISION: 1,
    df.RANDOM_Q: (1., 25.),
    df.STEP_INCR: 1.,
    df.VALUE: 1.
}
DESATURATE = {}
DISTRESS = {
    df.LIMIT: (1., 254.),
    df.PRECISION: 1,
    df.RANDOM_Q: (1., 254.),
    df.TOOLTIP: Tip.DISTRESS,
    df.VALUE: 127.
}
EDGE_MODE = {
    df.FUNCTION: get_edge_mode_list,
    df.VALUE: "Lighten Only"
}
EDGE_TYPE = {
    df.FUNCTION: get_decay_type_list,
    df.VALUE: de.WHITE_SOFT
}
ENGRAVE = {}
FACTOR_SIZE = {
    df.LIMIT: (.0, 2.),
    df.PAGE_INCR: .1,
    df.PRECISION: 6,
    df.STEP_INCR: .01,
    df.VALUE: 1.
}
FEATHER = {
    df.LIMIT: (0, 1000),
    df.PAGE_INCR: 50,
    df.RANDOM_Q: (50, 300),
    df.TOOLTIP: Tip.FEATHER,
    df.VALUE: 200.
}
FILL_MODE = {
    df.FUNCTION: get_mode_name_list,
    df.TOOLTIP: Tip.FILL_MODE,
    df.VALUE: "Normal"
}
FILLED = {}
FILTER = {df.VALUE: ""}
FIXED_SIZE = {
    df.LIMIT: (1, MAX_SIZE),
    df.PAGE_INCR: 100,
    df.VALUE: 200.
}
FLIP = {df.TOOLTIP: Tip.FLIP}
FOLDER_ORDER = {df.TEXT: fi.FOLDER_ORDER_LIST}
FONT = {
    df.DIALOG: PortChoice,
    df.TIP_P: make_text_tip,
    df.VALUE: "Tahoma"
}
FONT_SIZE = {
    df.LIMIT: (4, 999),
    df.PAGE_INCR: 10,
    df.TOOLTIP: Tip.FONT_SIZE,
    df.VALUE: 24.
}
FRAME_W = {
    df.LIMIT: (0, 999),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (1., 50.),
    df.VALUE: 12.
}
FRAME_W1 = {
    df.LIMIT: (1, 999),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (1., 50.),
    df.VALUE: 12.
}
GAP_W = {
    # Is limited by GIMP's clipboard to
    # pattern function where the maximum side
    # dimension for the clipboard is 1024.
    df.LIMIT: (1, 512),

    df.PAGE_INCR: 10,
    df.RANDOM_Q: (12, 100),
    df.VALUE: 24.
}
GRADIENT = {
    df.DIALOG: PortChoice,
    df.FUNCTION: get_gradient_list,
    df.VALUE: "Default"
}
GRADIENT_ANGLE = {
    df.FUNCTION: get_gradient_angle_list,
    df.VALUE: de.TOP_CENTER_TO_BOTTOM_CENTER
}
GRADIENT_DIRECTION = {df.TEXT: (de.CLOCKWISE, de.COUNTER_CLOCKWISE)}
GRADIENT_TYPE = {
    df.FUNCTION: get_gradient_type_list,
    df.VALUE: de.LINEAR
}
GRID_COUNT = {
    df.LIMIT: (1, 100),
    df.PAGE_INCR: 2,
    df.VALUE: 1.
}
GRID_SIZE = {
    df.VALUE: "",
    df.WIDGET: ModelTypeLabel
}
GRID_TYPE = {
    df.FUNCTION: get_grid_type_list,
    df.LABEL_TIP: Tip.GRID_TYPE,
    df.VALUE: de.CELL_COUNT
}
HARDNESS = {
    df.LIMIT: (.001, 1.),
    df.PRECISION: 3,
    df.RANDOM_Q: (.25, 1.),
    df.STEP_INCR: .01,
    df.VALUE: 1.
}
HEIGHT_CUBE = {
    df.LIMIT: (6, 682),         # 1024 / 1.5, '682'
    df.RANDOM_Q: (108, 682),
    df.VALUE: 512.
}
HEXAGON_TYPE = {
    df.FUNCTION: get_hexagon_type_list,
    df.VALUE: de.HEXAGON
}
HORIZONTAL = {}
HSL = {
    df.LIMIT: (-100., 100.),
    df.PAGE_INCR: 10.,
    df.PRECISION: 1,
    df.RANDOM_Q: (-100., 100.),
    df.STEP_INCR: 1.,
    df.VALUE: .0
}
IMAGE_NAME = {
    df.FUNCTION: get_image_name_list,
    df.VALUE: ""
}
IMAGE_TYPE = {
    df.FUNCTION: get_image_type_list,
    df.VALUE: de.NEXT
}
INDENT = {df.TOOLTIP: Tip.INDENT}
INNER_FRAME_W = {
    df.LIMIT: (4, 99),
    df.RANDOM_Q: (4, 14),
    df.VALUE: 5.
}
INTENSITY = {
    df.LIMIT: (0, 1000),
    df.PAGE_INCR: 25,
    df.RANDOM_Q: (50, 200),
    df.TOOLTIP: Tip.INTENSITY,
    df.VALUE: 0.
}
INVERT = {}
INVERT_MASK = {df.TOOLTIP: Tip.INVERT}
INWARD = {df.TOOLTIP: Tip.INWARD}
ITERATIONS = {
    df.LIMIT: (0, 100),
    df.PAGE_INCR: 2,
    df.RANDOM_Q: (0, 20),
    df.VALUE: 12.
}
JUSTIFICATION = {
    df.FUNCTION: get_justification_type,
    df.VALUE: de.CENTER
}
KEEP = {df.TOOLTIP: Tip.KEEP}
LAYER_COUNT = {
    df.LIMIT: (3, 20),
    df.RANDOM_Q: (4, 8),
    df.VALUE: 7.
}
LAYER_ORDER = {
    df.TEXT: fi.LAYER_ORDER_LIST,
    df.TOOLTIP: Tip.LAYER_ORDER
}
LAYERED = {df.TOOLTIP: Tip.LAYERED}
LENGTH = {
    df.LIMIT: (5, 1000),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (80, 150),
    df.VALUE: 150.
}
LENGTH_DRIP = {
    df.LIMIT: (1, 99),
    df.PAGE_INCR: 2,
    df.RANDOM_Q: (1, 10),
    df.VALUE: 4.
}
LENGTH_SHIFT = {
    df.LIMIT: (0, 999),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (10, 40),
    df.TOOLTIP: Tip.LENGTH_SHIFT,
    df.VALUE: 10.
}
LIGHT_TYPE = {
    df.FUNCTION: get_light_type_list,
    df.VALUE: de.GRADIENT
}
LINE_W = {
    # Is limited by GIMP's clipboard to
    # pattern function where the maximum side
    # dimension for the clipboard is 1024.
    df.LIMIT: (1, 512),

    df.PAGE_INCR: 10,
    df.RANDOM_Q: (1, 30),
    df.VALUE: 6.
}
LOOP = {
    df.TEXT: fi.LOOP_TYPE_LIST,
    df.TIPS: (Tip.LOOP_PLUS, Tip.LOOP_MINUS)
}
MASK_TYPE = {
    df.FUNCTION: get_mask_list,
    df.VALUE: "Circle"
}
MAX_POLAR_X = {
    df.AXIS: 'x',
    df.LIMIT: (-MAX_SIZE, MAX_SIZE),
}
MAX_POLAR_Y = {
    df.AXIS: 'y',
    df.LIMIT: (-MAX_SIZE, MAX_SIZE)
}
MAX_POSITIVE_X = {
    df.AXIS: 'x',
    df.LIMIT: (0, MAX_SIZE)
}
MAX_POSITIVE_Y = {
    df.AXIS: 'y',
    df.LIMIT: (0, MAX_SIZE)
}
MESH_TYPE = {
    df.FUNCTION: get_mesh_type_list,
    df.VALUE: de.SQUARE
}
MASK_SCALE = {
    df.LIMIT: (.001, 1.),
    df.PRECISION: 3,
    df.STEP_INCR: .01,
    df.VALUE: 1.
}
MAZE = {
    df.LIMIT: (4, 999),
    df.PAGE_INCR: 2,
    df.RANDOM_Q: (4, 50),
    df.VALUE: 10.
}
MEAN_COLOR = {}
MESH_SIZE = {
    df.LIMIT: (8, 1000),
    df.RANDOM_Q: (25, 100),
    df.TOOLTIP: Tip.MESH_SIZE,
    df.VALUE: 50.
}
METHOD = {df.COLUMN_TEXT: de.METHOD, df.TEXT: (de.LINE, de.BRUSH)}
MODE = {
    df.FUNCTION: get_mode_name_list,
    df.ISSUE: vo.MODE,
    df.TIP_P: make_text_tip,
    df.VALUE: "Normal",
    df.WIDGET: ComboBox
}
NAME_DROP = {df.VALUE: "Drop Zone"}
NEATNESS = {
    df.LIMIT: (.0, 1.),
    df.PRECISION: 3,
    df.RANDOM_Q: (.0, 1.),
    df.STEP_INCR: .01,
    df.VALUE: 1.
}
NOISE_AMOUNT = {
    df.LIMIT: (1, 15),
    df.PAGE_INCR: 2,
    df.RANDOM_Q: (1, 15),
    df.VALUE: 2.
}
NOISE_TYPE = {
    df.FUNCTION: get_noise_list,
    df.VALUE: de.INK
}
OBEY_MARGIN = {df.TOOLTIP: Tip.OBEY_MARGIN}
OCTAGON_TYPE = {
    df.FUNCTION: get_octagon_type_list,
    df.VALUE: de.OCTAGON
}
OFFSET = {
    df.LIMIT: (0, 9999),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (0, 10),
    df.VALUE: 0.
}
OFFSET_XY = {
    df.LIMIT: (-4096, 4096),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (-30, 30),
    df.VALUE: 0.
}
OPACITY = {
    df.ISSUE: vo.OPACITY,
    df.LIMIT: (.0, 100.),
    df.PAGE_INCR: 10.,
    df.PRECISION: 1,
    df.RANDOM_Q: (.0, 100.),
    df.TIP_P: make_text_tip,
    df.VALUE: 100.,
    df.WIDGET: RandomSlider
}
OPAQUE = {df.TOOLTIP: Tip.OPAQUE}
OPAQUE_NOISE = {}
OVER_OVERLAY_TYPE = {
    df.FUNCTION: get_frame_overlay_type_list,
    df.VALUE: de.CLOUDS
}
PATTERN = {
    df.DIALOG: PortChoice,
    df.FUNCTION: get_pattern_list,
    df.VALUE: "Pine"
}
PATTERN_SIZE = {
    # Limit due to GIMP's clipboard to
    # pattern function where the maximum side
    # dimension for the clipboard is 1024.
    df.LIMIT: (24, 256),
    df.RANDOM_Q: (120, 256),
    df.VALUE: 120.
}
PER = {
    df.ISSUE: vo.PER,
    df.VALUE: {},
    df.WIDGET: PerGroup
}
PERCENTILE = {
    df.LIMIT: (.0, 100.),
    df.PAGE_INCR: 10,
    df.PRECISION: 2,
    df.RANDOM_Q: (.0, 100.),
    df.STEP_INCR: 1,
    df.TOOLTIP: Tip.PERCENTILE,
    df.VALUE: 50.
}
PERIOD = {
    df.LIMIT: (.1, 1000.),
    df.PRECISION: 1,
    df.RANDOM_Q: (10., 500.),
    df.VALUE: 36.
}
PHASE = {
    df.LIMIT: (-1., 1.),
    df.PRECISION: 3,
    df.RANDOM_Q: (-1., 1.),
    df.VALUE: .0
}
PIN = {
    df.FUNCTION: get_pin_list,
    df.LABEL_TIP: Tip.PIN,
    df.VALUE: de.CENTER
}
POWER = {
    df.LIMIT: (0, 180),
    df.RANDOM_Q: (0, 180),
    df.TOOLTIP: Tip.POWER,
    df.VALUE: 0.
}
PROFILE = {
    df.FUNCTION: get_profile_list,
    df.VALUE: de.BAND
}
R_C = {
    df.LIMIT: (1, 999),
    df.PAGE_INCR: 2,
    df.RANDOM_Q: (1, 50),
    df.VALUE: 5.
}
RADIUS = {
    df.LIMIT: (-400, 400),
    df.PAGE_INCR: 5,
    df.RANDOM_Q: (-20, 20),
    df.STEP_INCR: 1,
    df.VALUE: 3
}
RADIUS_DRIP = {
    df.LIMIT: (1, 1500),
    df.PAGE_INCR: 5,
    df.RANDOM_Q: (0, 1500),
    df.STEP_INCR: 1,
    df.TOOLTIP: Tip.RADIUS_DRIP,
    df.VALUE: 10
}
RANDOM = {
    df.WIDGET: RandomButton
}
RANDOM_ORDER = {}
RC_SLICE = {
    df.LIMIT: (1, 100),
    df.VALUE: 1.
}
RECTANGLE_TYPE = {
    df.FUNCTION: get_rectangle_type_list,
    df.VALUE: de.RECTANGLE
}
RESIZE_TYPE = {
    df.FUNCTION: get_resize_type_list,
    df.VALUE: de.LOCKED
}
REVERB = {
    df.LIMIT: (.0, 1.),
    df.PRECISION: 2,
    df.RANDOM_Q: (.0, 1.),
    df.STEP_INCR: .1,
    df.VALUE: 1.
}
REVERB_TYPE = {
    df.FUNCTION: get_reverb_type_list,
    df.VALUE: de.RANDOM_COLOR
}
REVERSE = {df.TOOLTIP: Tip.REVERSE}
SCATTER_COUNT = {
    df.LIMIT: (1, 100),
    df.PAGE_INCR: 5,
    df.RANDOM_Q: (2, 20),
    df.TOOLTIP: Tip.SCATTER_COUNT,
    df.VALUE: 5.
}
SELECT = {
    df.COLUMN_TEXT: de.SELECT,
    df.TEXT: (de.LAYER, de.IMAGE),
    df.TIPS: Tip.SELECT
}
SEED = {
    df.LIMIT: (0, 99999),
    df.RANDOM_Q: (0, 99999),
    df.TOOLTIP: Tip.SEED,
    df.VALUE: 0.
}
SHADOW_BLUR = {
    df.LIMIT: (.0, 500.),
    df.PRECISION: 1,
    df.RANDOM_Q: (.0, 50.),
    df.VALUE: 15.
}
SHAPE = {
    df.FUNCTION: get_shape_list,
    df.VALUE: de.RECTANGLE
}
SHAPED_TYPE = {
    df.FUNCTION: get_shaped_list,
    df.VALUE: de.SHAPED_DIMPLED
}
SHIFT = {
    df.LIMIT: (0, 200),
    df.RANDOM_Q: (0, 200),
    df.VALUE: 200.
}
SHIFT_DIRECTION = {df.TEXT: (de.VERTICAL, de.HORIZONTAL)}
SIZE_XY = {
    df.LIMIT: (.0, 500.),
    df.PAGE_INCR: 10.,
    df.PRECISION: 2,
    df.RANDOM_Q: (.0, 100.),
    df.STEP_INCR: 1.,
    df.VALUE: .0
}
SKETCH_TEXTURE = {
    df.FUNCTION: get_news_type_list,
    df.VALUE: de.DOT
}
SLICE = {df.TOOLTIP: Tip.SLICE}
SLICE_COUNT = {
    df.LIMIT: (2, 60),
    df.RANDOM_Q: (2, 15),
    df.VALUE: 6.
}
SLICE_ORDER = {df.TEXT: fi.SLICE_ORDER_LIST}
SMOOTH = {
    df.LIMIT: (3, 20),
    df.RANDOM_Q: (5, 12),
    df.VALUE: 4.
}
START_NUMBER = {
    df.LIMIT: (-sys.maxint, sys.maxint),
    df.PAGE_INCR: 100,
    df.TOOLTIP: Tip.START_NUMBER,
    df.VALUE: 1.
}
STENCIL_TYPE = {
    df.FUNCTION: get_frame_list,
    df.VALUE: "None"
}
SPECK_NOISE = {
    df.LIMIT: (.05, 1.),
    df.PRECISION: 3,
    df.RANDOM_Q: (.05, 1.),
    df.STEP_INCR: .01,
    df.VALUE: .22
}
SPIRAL_DISTANCE = {
    df.LIMIT: (.001, .5),
    df.RANDOM_Q: (.001, .5),
    df.PRECISION: 3,
    df.TOOLTIP: Tip.SPIRAL_DISTANCE,
    df.VALUE: .1
}
SPIRAL_MOD = {
    df.FUNCTION: get_spiral_mod_list,
    df.VALUE: "None"
}
SPREAD = {
    df.LIMIT: (0, 512),
    df.RANDOM_Q: (0, 512),
    df.VALUE: 512.
}
SPREAD_WRAP_CR = {
    df.LIMIT: (1., 100.),
    df.PAGE_INCR: 5.,
    df.PRECISION: 1,
    df.RANDOM_Q: (8., 16.),
    df.TOOLTIP: Tip.SPREAD,
    df.VALUE: 12.
}
START_X = {df.AXIS: 'x'}
START_Y = {df.AXIS: 'y'}
STEPS = {
    df.LIMIT: (1, 50),
    df.PAGE_INCR: 2,
    df.RANDOM_Q: (1, 12),
    df.TOOLTIP: Tip.STEPS,
    df.VALUE: 6.
}
STEPS_DROP = {
    df.LIMIT: (2, 100),
    df.RANDOM_Q: (2, 12),
    df.TOOLTIP: Tip.STEPS_DROP_ZONE,
    df.VALUE: 6.
}
STRIP_HEIGHT = {
    df.LIMIT: (.0, 7.),
    df.PRECISION: 2,
    df.RANDOM_Q: (.1, 7.),
    df.STEP_INCR: .1,
    df.TOOLTIP: Tip.STRIP_H,
    df.VALUE: 1.5
}
STYLE_TYPE = {
    df.FUNCTION: get_accent_type_list,
    df.VALUE: de.COLOR
}
SUPERPIXEL_SIZE = {
    df.LIMIT: (8, 256),
    df.RANDOM_Q: (8, 256),
    df.VALUE: 32.
}
SWITCH = {
    df.COLUMN_TEXT: de.SWITCH,
    df.ISSUE: vo.MATTER,
    df.TEXT: ("Off", "On"),
    df.VALUE: 0,
    df.WIDGET: SwitchRadio
}
TAB = {
    df.LIMIT: (1, 999),
    df.PAGE_INCR: 2,
    df.VALUE: 1.
}
TAPE_WIDTH = {
    df.LIMIT: (5, 999),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (30, 60),
    df.VALUE: 50.
}
TEXT = {
    df.CHARS: 15,
    df.ISSUE: vo.MATTER,
    df.TIP_P: make_text_tip,
    df.VALUE: "",
    df.WIDGET: Entry
}
THRESHOLD = {
    df.LIMIT: (.0, 1.),
    df.PRECISION: 3,
    df.RANDOM_Q: (.33, 1.),
    df.STEP_INCR: .01,
    df.TOOLTIP: Tip.THRESHOLD,
    df.VALUE: 1.
}
TILE_SIZE = {
    df.LIMIT: (2., 256.),
    df.RANDOM_Q: (7, 45),
    df.VALUE: 20.
}
TRIANGLE_TYPE = {
    df.FUNCTION: get_triangle_type_list,
    df.VALUE: de.TRIANGLE_UP_REGULAR
}
UNSHARP_AMOUNT = {
    df.LIMIT: (.0, 300.),
    df.PAGE_INCR: 10.,
    df.PRECISION: 1,
    df.RANDOM_Q: (.0, 50.),
    df.VALUE: 10.
}
UNSHARP_RADIUS = {
    df.LIMIT: (.0, 1500.),
    df.PAGE_INCR: 10.,
    df.PRECISION: 1,
    df.RANDOM_Q: (.0, 50.),
    df.VALUE: 11.
}
UNSHARP_THRESHOLD = {
    df.LIMIT: (.0, .1),
    df.PRECISION: 2,
    df.RANDOM_Q: (.0, .1),
    df.TIP_P: make_text_tip,
    df.VALUE: .03
}
UP = {
    df.LIMIT: (.0, 10.),
    df.PAGE_INCR: 1.,
    df.PRECISION: 2,
    df.RANDOM_Q: (.0, .5),
    df.STEP_INCR: .1,
    df.TOOLTIP: Tip.UPSCALE,
    df.VALUE: .0
}
UP_SPACE = {df.TOOLTIP: Tip.UP_SPACE}
UPSCALE = {df.TOOLTIP: Tip.UPSCALE}

UP_SPACE.update(UP)
UPSCALE.update(UP)

WAVE_COUNT = {
    df.LIMIT: (1, 24),
    df.RANDOM_Q: (1, 12),
    df.VALUE: 1.
}
WAVE_FILL_TYPE = {
    df.FUNCTION: get_wave_fill_type_list,
    df.VALUE: de.COLOR
}
WAVE_PER_LAYER = {
    df.LIMIT: (1, 18),
    df.RANDOM_Q: (1, 18),
    df.VALUE: 5.
}
WHIRL = {
    df.LIMIT: (-720, 720),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (-30, 30),
    df.TOOLTIP: Tip.WHIRL,
    df.VALUE: 45.
}
WIDTH = {
    df.LIMIT: (1, 9999),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (1, 100),
    df.VALUE: 30
}
WIDTH_0 = {
    df.LIMIT: (0, 9999),
    df.PAGE_INCR: 10,
    df.RANDOM_Q: (0, 100),
    df.VALUE: 30
}
WIDTH_LINE = {
    df.LIMIT: (1, 9999),
    df.PAGE_INCR: 2,
    df.VALUE: 2.
}
WIRE_THICKNESS = {
    df.LIMIT: (1, 30),
    df.RANDOM_Q: (4, 10),
    df.VALUE: 3.
}
WOBBLE_FACTOR = {
    df.LIMIT: (.0, 1.),
    df.PRECISION: 2,
    df.RANDOM_Q: (.01, 1.),
    df.VALUE: .08
}
WRAP_TYPE = {
    df.FUNCTION: get_wrap_types,
    df.VALUE: de.ROUNDED
}

# Update option definition with a factored Widget type.________________________
for i in (
    AUTOCROP, CLOCKWISE, INVERT_MASK, FILLED, FLIP, INDENT,
    INWARD, KEEP, LAYERED, OBEY_MARGIN, OPAQUE, SLICE
):
    i.update(_CHECK_BUTTON)

for i in (
    CLIP, CLIP_FRINGE, COLORIZE, DESATURATE, HORIZONTAL,
    INVERT, MEAN_COLOR, RANDOM_ORDER, REVERSE, ENGRAVE
):
    i.update(_CHECK_BUTTON_RANDOM)

for i in (
    BACKGROUND_TYPE, BELOW_TYPE, BOX_TYPE,
    BUMP_TYPE, CAMO_TYPE, CELL_SHAPE_CELL,
    CORNER_TYPE, CRITERION, DECO_TYPE, EDGE_MODE,
    EDGE_TYPE, FILL_MODE, STYLE_TYPE,
    GRADIENT_ANGLE, GRADIENT_TYPE, GRID_TYPE, HEXAGON_TYPE,
    IMAGE_NAME, IMAGE_TYPE, JUSTIFICATION,
    LIGHT_TYPE, MASK_TYPE, MESH_TYPE,
    NOISE_TYPE, OCTAGON_TYPE, OVER_OVERLAY_TYPE,
    PIN, PROFILE,
    RECTANGLE_TYPE, RESIZE_TYPE, REVERB_TYPE,
    SHAPE, SHAPED_TYPE, SKETCH_TEXTURE, SPIRAL_MOD,
    STENCIL_TYPE, TRIANGLE_TYPE, WAVE_FILL_TYPE, WRAP_TYPE
):
    i.update(_COMBO_BOX)

for i in (FILTER, NAME_DROP,):
    i.update(_ENTRY)

for i in (BRUSH, FONT, GRADIENT, PATTERN):
    i.update(_LIST_BUTTON)

for i in (FOLDER_ORDER, LAYER_ORDER, LOOP, SLICE_ORDER):
    i.update(_RADIO_RANDOM_COLUMN)

for i in (COLOR_2, COLOR_2A, COLOR_2B, COLOR_3, COLOR_3A, COLOR_6, COLOR_6A):
    i.update(_RAINBOW)

for i in (COLOR_1, COLOR_1A, COLOR_EMBOSS):
    i.update(_RANDOM_COLOR_BUTTON)

for i in (
    BLUR_TYPE, COLOR_GRID_TYPE, GRADIENT_DIRECTION,
    METHOD, SELECT, SHIFT_DIRECTION
):
    i.update(_RADIO_RANDOM_ROW)

for i in (
    AMOUNT, AMP,  AMPLITUDE, AMPLITUDE_1, ANGLE,
    ANGLE_JITTER, ANGLE_SHIFT, BEVEL_H, BEVEL_W,
    BLEND, BLUR, BLUR_POST, BLUR_PRE, BLUR_XY,
    BRUSH_ANGLE, BRUSH_SPACING, BRUSH_SIZE, BUMP_DEPTH,
    CELL_SIZE_ETCH, CAP_XY, CIRCLE_DIAMETER, CLIPBOARD,
    COLOR_COUNT, CONTRAST, CORNER_SHIFT,
    DEPTH, DISTRESS, FEATHER, FRAME_W, FRAME_W1, GAP_W,
    HARDNESS, HEIGHT_CUBE, HSL, INNER_FRAME_W, INTENSITY, ITERATIONS,
    LAYER_COUNT, LENGTH, LENGTH_DRIP, LENGTH_SHIFT, LINE_W,
    MAZE, MESH_SIZE, NEATNESS, NOISE_AMOUNT,
    OFFSET, OFFSET_XY, PATTERN_SIZE, PERCENTILE, PERIOD,
    PHASE, POWER, R_C, RADIUS, RADIUS_DRIP,
    REVERB, SEED, SCATTER_COUNT, SHADOW_BLUR,
    SHIFT, SLICE_COUNT, SMOOTH, SPECK_NOISE, SPIRAL_DISTANCE, SPREAD,
    SPREAD_WRAP_CR, STEPS, STEPS_DROP, SIZE_XY, STRIP_HEIGHT,
    SUPERPIXEL_SIZE, TAPE_WIDTH, THRESHOLD, TILE_SIZE, UNSHARP_AMOUNT,
    UNSHARP_RADIUS, UNSHARP_THRESHOLD, UP_SPACE, UPSCALE, WAVE_PER_LAYER,
    WAVE_COUNT, WHIRL, WIDTH, WIDTH_0, WIRE_THICKNESS, WOBBLE_FACTOR
):
    i.update(_RANDOM_SLIDER)

for i in (BLOCK_H, BLOCK_W):
    i.update(_RECT_PAIR)

for i in (MAX_POLAR_X, MAX_POLAR_Y, MAX_POSITIVE_X, MAX_POSITIVE_Y):
    i.update(_RENDER_PAIR)

for i in (
    BORDER_W, CELL_SIZE, COLOR_COUNT_FRINGE, CONTRACT, CROP_XY,
    FACTOR_SIZE, FIXED_SIZE, FONT_SIZE, GRID_COUNT, WIDTH_LINE,
    MASK_SCALE, TAB, RC_SLICE, START_NUMBER
):
    i.update(_SLIDER)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

for i in (COLOR_6, COLOR_6A):
    i.update({df.TIP_P: make_rainbow_count_tip})

# CFW
CFW = deepcopy(FRAME_W)
CFW[df.LIMIT] = 0, 999
CFW[df.VALUE] = 0.

# Crop X
CROP_X = deepcopy(CROP_XY)
CROP_X[df.TOOLTIP] = Tip.CROP_X

CROP_Y = deepcopy(CROP_XY)

# Gradient Opacity
GRADIENT_OPACITY = deepcopy(OPACITY)
GRADIENT_OPACITY[df.VALUE] = 50.

# Matter Mode
MATTER_MODE = deepcopy(MODE)
MATTER_MODE[df.ISSUE] = vo.MATTER

# Noise Opacity
NOISE_OPACITY = deepcopy(OPACITY)
NOISE_OPACITY[df.VALUE] = 30.
NOISE_OPACITY[df.ISSUE] = vo.MATTER

# Overlay Mode
OVERLAY_MODE = deepcopy(MODE)
OVERLAY_MODE[df.VALUE] = "Overlay"
