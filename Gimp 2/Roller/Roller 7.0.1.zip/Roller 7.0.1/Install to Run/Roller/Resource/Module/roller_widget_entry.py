#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Define as df
from roller_widget import Widget
import gtk  # type: ignore


class Entry(Widget):
    """Customize a GTK Entry."""
    change_signal = 'changed'
    has_table_label = True

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        g = gtk.Entry()

        Widget.__init__(self, g, **d)

        if df.CHARS in d:
            g.set_width_chars(d[df.CHARS])
        self.add(g)

    def get_ui(self):
        """
        Get the value displayed in the Entry.

        Return: string
            from the gtk.Entry
        """
        return self.widget.get_text()

    def set_ui(self, n):
        """
        Set the value displayed in the Entry.

        n: string
            Give to the GTK Entry.

        Return: string
            Displayed value.
        """
        if not isinstance(n, basestring):
            n = ""

        self.widget.set_text(n)
        return n
