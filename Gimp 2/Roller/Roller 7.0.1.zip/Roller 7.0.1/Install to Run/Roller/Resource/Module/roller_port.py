#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Color as co, Define as df, Signal as si
from roller_utility import reduce_color
from roller_ring import Ring
import gtk  # type: ignore


class Port(gtk.VBox, object):
    """Display Widget in a GTK VBox."""
    # View class
    view = None

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: Widget or None
            Is responsible.
        """
        self.is_dirt = False
        self._pig = []
        self.roller_win = d[df.ROLLER_WIN]
        self.repo = g

        super(gtk.VBox, self).__init__()
        self.color = co.INIT_COLOR

    def report(self, g, view_i):
        """
        Perform a view run. Set the repo's value
        after fetching the Port's group value.
        Is recursive.

        Note that 'repo' is set by the dialog that
        is opened by a Button's activation.
        Refer to this Button as 'repo'.

        Port stack:
            main
                dialog (repeat)

        When a dialog is open, its value dict is passed to its
        parent Port. Eventually, the value dict arrives at
        the main AnyGroup and the view run is performed.

        g: ValueButton
            Is responsible for activating the view process
            or opening a dialog.

        view_i: int
            Identify the view run type.
        """
        # Update AnyGroup, in case of queued signal.
        Ring.pressure()

        repo = self.repo

        if repo:
            # There's an underlying Window/Port, 'repo'.
            repo.load_a(self.get_group_value())
            repo.roller_win.port.report(g, view_i)
        else:
            # The chain of Port is updated, and the Port is main.
            Port.view.run(view_i)

    def keep(self, q):
        """
        Put Widget reference into 'self._pig'. Keep the GTK
        garbage collection from removing Widget connection
        from the parent Window when a GTK Dialog is opened.

        q: iterable (tuple or list)
            Widgets
        """
        [self._pig.append(g) for g in q]

    def on_port_change(self, g):
        """
        A Widget changed. Respond to changes in the interface.

        g: Widget
            Is responsible.
        """
        if g.any_group:
            # Update squishy interface and View.
            Ring.add(g.any_group, si.GROUP_CHANGE, None)

        repo = self.repo

        while repo:
            a = repo
            repo = repo.roller_win.port.repo

            # A main-type port has no 'repo'.
            if not repo:
                # Update View.
                Ring.add(a.any_group, si.GROUP_CHANGE, None)
        Ring.plug(si.UI_CHANGE, g)

    def reduce_color(self):
        """Lower the red and green components of 'self.color'."""
        self.color = reduce_color(self.color)
