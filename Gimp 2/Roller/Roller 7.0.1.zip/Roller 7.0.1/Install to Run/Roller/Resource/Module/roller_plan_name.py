#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_deck import Deck
from roller_deco import ready_canvas_rect
from roller_gimp_layer import make_plan_text_layer, verify_layer
from roller_image_change import ref_get_image_name
from roller_plan import add_text_layer
from roller_polygon import get_bounds


def create_facial_name(k, j, maya, font_size, p):
    """
    Draw Face/Image name.
    See 'create_name' for argument description.

    Return: layer
        text
    """
    model = maya.model
    x, y, w, h = get_bounds(model.get_facing_foam(k))

    # The super-maya is PlanFace or PlanFacing in the 'maya_image'.
    n = maya.super_maya.get_facial_name(k)
    if n:
        z = make_plan_text_layer(j, n, font_size)
        x1 = w / 2. + x - z.width / 2.
        y1 = h / 2. + y + z.height / 2.

        if model.model_type == de.STACK:
            y1 = y1 + k[0] * z.height

        add_text_layer(z, x1, y1, p)
        return z


def create_facial_main_name(maya, p):
    """
    Draw an image name for Plan Face or Facing for main.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        text material
    """
    def _insert(_z):
        deck.insert(_z)

    j = Run.j
    super_ = maya.super_maya
    deck = Deck(j, super_.group, 0, "Name")
    arg = j, maya, maya.font_size, _insert

    for k in super_.main_q:
        p(k, *arg)
    return deck.exit()


def create_facial_per_name(maya, p):
    """
    Draw an image name for Plan Facing or Face Per.

    maya: Maya
        'maya_image' variety

    p: function
        Create Face/Facing name.

    Return: layer or None
        text material
    """
    def _insert(_z):
        pdb.gimp_image_insert_layer(j, _z, group, 0)
        _z.name = group.name + " Name"

    j = Run.j
    super_ = maya.super_maya
    group = super_.group
    return verify_layer(p(super_.k, j, maya, maya.font_size, _insert))


def create_name(k, j, maya, font_size, p):
    """
    Create a layer with an image name text positioned
    near the center of a Cell's pocket rectangle.

    k: tuple
        goo key

    j: Gimp Image
        WIP

    maya: Maya
        'maya_image' variety

    font_size: int
        Set the size of the output text.

    p: function
        Insert the text layer into a group.

    Return: layer
        text
    """
    model = maya.model
    x, y, w, h = model.get_pocket_rect(k)
    n = ref_get_image_name(maya.any_group, k, 0)

    if n:
        z = make_plan_text_layer(j, n, font_size)
        x1 = w / 2. + x - z.width / 2.
        y1 = h / 2. + y - z.height / 2.

        if model.model_type == de.STACK:
            y1 = y1 + k[0] * z.height

        add_text_layer(z, x1, y1, p)
        return z


def do_canvas_name(maya):
    """
    Draw image name for Canvas/Image.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        text
    """
    def _insert(_z):
        pdb.gimp_image_insert_layer(j, _z, group, 0)
        _z.name = group.name + " Name"

    ready_canvas_rect(maya, maya.value_d, option=None)

    j = Run.j
    group = maya.super_maya.group
    n = ref_get_image_name(maya.any_group, None, 0)
    if n:
        z = make_plan_text_layer(j, n, maya.font_size)
        x, y, w, h = maya.model.canvas_pocket.rect
        x = w / 2. + x - z.width / 2.
        y = h / 2. + y + z.height / 2.
        z.name = group.name + " Name"

        add_text_layer(z, x, y, _insert)
        return verify_layer(z)


def do_cell_main_name(maya):
    """
    Draw an image name for Cell/Image main.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        text material
    """
    def _insert(_z):
        deck.insert(_z)

    j = Run.j
    super_ = maya.super_maya
    deck = Deck(j, super_.group, 0, "Name")
    arg = j, maya, maya.font_size, _insert

    for k in super_.main_q:
        create_name(k, *arg)
    return deck.exit()


def do_cell_per_name(maya):
    """
    Draw an image name for Cell/Image/Per.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        text
    """
    def _insert(_z):
        pdb.gimp_image_insert_layer(j, _z, group, 0)
        _z.name = group.name + " Name"

    j = Run.j
    a = maya.super_maya
    k = a.k
    group = a.group
    return verify_layer(create_name(k, j, maya, maya.font_size, _insert))


def do_face_main_name(maya):
    """
    Draw Plan Face/Image name for main.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        text material
    """
    def _insert(_z):
        deck.insert(_z)

    j = Run.j
    super_ = maya.super_maya
    deck = Deck(j, super_.group, 0, "Name")
    arg = j, maya, maya.font_size, _insert

    for k in super_.main_q:
        create_facial_name(k, *arg)
    return deck.exit()


def do_face_per_name(maya):
    """
    Draw an image name for Plan Face/Image/Per.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        text
    """
    return create_facial_per_name(maya, create_facial_name)


def do_facing_per_name(maya):
    """
    Draw an image name for Plan Facing/Per.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        text
    """
    return create_facial_per_name(maya, create_facial_name)


def do_facing_main_name(maya):
    """
    Draw Plan Face/Image main.

    maya: Maya
        'maya_image' variety

    Return: layer or None
        text material
    """
    return create_facial_main_name(maya, create_facial_name)
