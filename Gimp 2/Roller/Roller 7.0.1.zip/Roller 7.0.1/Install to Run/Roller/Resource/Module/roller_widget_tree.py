#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant import Color as co, Define as df, Signal as si
from roller_widget import Widget
import gtk  # type: ignore

CHOICE_COLOR = '#A8F8CF'


def get_treeview_item(treeview):
    """
    Return the item selected in a TreeViewList.

    treeview: TreeViewList
        Has list of item.

    Return: string or None
        item
    """
    n = None

    # GTK TreeSelection, 'a'
    a = treeview.get_selection()

    if a:
        model, iter_ = a.get_selected()
        if iter_:
            n = model.get_value(iter_, 0)
    return n


def rename_item(tree, r, n):
    tree.list_store.set_value(tree.list_store[r].iter, 0, n)


class TreeViewList(Widget):
    """
    Is base class for a Roller TreeView list Widget.

    Reference
    'scentric.net/tutorial/'
    """
    change_signal = 'cursor_changed'
    has_table_label = False

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        # list of string equal to the visible tree values, 'item_list'
        self.item_list = d[df.FUNCTION]() if df.FUNCTION in d else []

        # for the cell
        self._background_color = d[df.COLOR]

        g = self.treeview = gtk.TreeView()
        g.set_headers_visible = 0
        self.scrolled_window = gtk.ScrolledWindow() if df.SCROLL in d else None

        if self.scrolled_window:
            self.scrolled_window.set_policy(
                gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC
            )
            self.scrolled_window.add(g)
            g = self.scrolled_window

        if df.HEADER not in d:
            d[df.HEADER] = ""

        if df.MINIMUM_W not in d:
            d[df.MINIMUM_W] = 1

        Widget.__init__(self, self.treeview, **d)

        self.list_store = gtk.ListStore(str, str, str)

        self.treeview.set_model(self.list_store)
        self.add(g)

        # Create a column.
        col = gtk.TreeViewColumn(
            d[df.HEADER],
            gtk.CellRendererText(),
            text=0,
            foreground=1,
            background=2
        )

        col.set_min_width(d[df.MINIMUM_W])

        # Add the column to the TreeView.
        self.treeview.append_column(col)

        if not d[df.HEADER]:
            # Hide the column header with a dummy Label.
            col.set_widget(gtk.Label(""))

        # Modify the base color or the background color of the Treeview.
        #
        # Reference
        # mail.gnome.org/archives/gtk-app-devel-list/2015-June/msg00026.html
        # kksou.com/php-gtk2/sample-codes/set-the-background-color-of-GtkTreeView.php
        color = d[df.TREE_COLOR]
        self.treeview.modify_base(
            gtk.STATE_NORMAL, gtk.gdk.Color(color, color, co.MAX_COLOR)
        )

    def append_item(self, n):
        """
        Add an item to the list.

        n: string
            item to add
        """
        self.list_store.append([n, '#000000', self._background_color])
        self.item_list.append(n)

    def copy_item_list(self):
        """
        Get a item list copy.

        Return: list
            [DNA, ...]
        """
        return self.item_list[:]

    def get_ui(self):
        """
        Get the item list.

        Return: list
            [item, ...]; item list
        """
        return self.copy_item_list()

    def get_selected_item(self):
        """
        Get the selected item in the list.

        Return: string
            from the list selection
        """
        return get_treeview_item(self.treeview)

    def get_selected_r(self):
        """
        Determine the row index of the selected item.

        Return: int or None
            in 0 to n, where n is the length of the list minus one
        """
        i = iter_ = None

        # GTK TreeSelection, 'a'
        #
        # Reference
        # 'stackoverflow.com/questions/7938007/how-to-get-
        # value-from-selected-item-in-treeview-in-pygtk'
        a = self.treeview.get_selection()

        if a:
            # GtkTreeIter, 'iter_'
            iter_ = a.get_selected_rows()[1]

        if iter_:
            i = iter_[0][0]
        return i

    def get_item_row_number(self, n):
        """
        Match a descriptor to an item from the Node's item list.

        n: string
            item to match

        Return: int or None
            row index
        """
        for i, n1 in enumerate(self.item_list):
            if n1 == n:
                return i

    def get_item_by_row(self, r):
        """
        Get the Item reference for a list index.

        r: int
            selection index into the Node item list

        Return: Item or None
        """
        if r < len(self.item_list):
            return self.item_list[r]

    def insert_row(self, i, n):
        """
        Insert a row into the TreeView and its item list.

        i: int
            index to row position

        n: string
            Insert this value.
        """
        list_store = self.list_store

        # item descriptor index, '0'
        # Create the row.
        list_store.set_value(list_store.insert(i), 0, n)

        # Set the background color.
        list_store[i] = [n, '#000000', self._background_color]

        # Update the easy access list.
        self.item_list.insert(i, n)

    def is_valid_selection(self, i):
        """
        Determine if a value is a valid selection.

        i: int or None
            a selection index

        Return: bool
            Is True when the selection value is valid.
        """
        if i is not None:
            if len(self.item_list) and len(self.item_list) >= i:
                return True
        return False

    def populate_item_list(self, q):
        """
        Populate the TreeView from a list.
        The previous indexed-list is replaced.

        q: list
            of string
        """
        self.reset()

        # Append items to the list.
        for n in q:
            self.append_item(n)

    def rename_item(self, r, n):
        """
        Change the name of an item in the TreeView and its in the item list.

        r: int
            row index

        n: string
            new item name
        """
        rename_item(self, r, n)
        self.item_list[r] = n

    def remove_row(self, r):
        """
        Remove an item from the list using its index in the list.
        Is a get-item-index partner, so None is a valid row value.

        r: int or None
            row index
        """
        if isinstance(r, int):
            list_store_row = self.list_store[r]

            self.item_list.pop(r)
            self.list_store.remove(list_store_row.iter)

    def reset(self):
        """
        Replace the ListStore with a new one as
        old one's iterator is probably used up.
        """
        # Replace "TreeView.ListStore's" iterator.
        self.item_list = []
        self.list_store = gtk.ListStore(str, str, str)
        self.treeview.set_model(self.list_store)

    def select_r(self, r):
        """
        Select a TreeView item.

        r: int or None
            row index in the TreeView
            0 to n
        """
        if not isinstance(r, int):
            r = 0

        self.treeview.set_cursor(r)

        # GTK TreeSelection, 'selection'
        selection = self.treeview.get_selection()
        if selection:
            model, iter_ = selection.get_selected()
            if iter_:
                path = model.get_path(iter_)
                self.treeview.scroll_to_cell(path)

    def set_ui(self, q):
        """
        Load the Treeview from a list.

        q: iterable
            items to display in the Widget

        Return: list
            Displayed items.
        """
        # Disconnect cursor change signal.
        # Debug.
        q1 = self.relay
        self.relay = []
        q = [n for n in q if isinstance(n, basestring)]

        self.populate_item_list(q)
        self.relay = q1
        return q


class ChoiceList(TreeViewList):
    """Is a Treeview composed of a list."""

    def __init__(self, **d):
        """
        Create a Treeview list. Use for when the value is a string.

        d: dict
            Initialize the Widget.
        """
        d[df.COLOR] = CHOICE_COLOR
        d[df.SCROLL] = 1

        TreeViewList.__init__(self, **d)
        self.populate_item_list(self.item_list)

        if df.ANY_GROUP not in d:
            self.any_group = None

        else:
            self.any_group.connect(si.RANDOMIZE, self.randomize)

        # Select the previous choice for the user.
        i = self.item_list.index(d[df.CHOICE]) \
            if d[df.CHOICE] in self.item_list else 0

        self.treeview.set_cursor(i)

        # GTK TreeSelection, 'selection'
        selection = self.treeview.get_selection()
        model, iter_ = selection.get_selected()
        if iter_:
            path = model.get_path(iter_)
            self.treeview.scroll_to_cell(path)

    def randomize(self, *_):
        """Randomize a choice in the list."""
        if len(self.item_list) > 1:
            self.select_r(randint(0, len(self.item_list) - 1))
