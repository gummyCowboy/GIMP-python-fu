#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_REPLACE,
    LAYER_MODE_MULTIPLY,
    LAYER_MODE_OVERLAY, pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gimp_context import prep_replace_color_default
from roller_gimp_image import make_group_layer
from roller_gimp_layer import (
    blur_selection,
    clear_inverse_selection,
    clone_layer,
    color_layer,
    dilate,
    get_mean_color
)
from roller_gimp_selection import (
    invert_selection, select_channel, select_color
)
from roller_maya_sub_accent import SubAccent
from roller_wip import Wip


def do_matter(maya):
    """
    maya: MazeBlend
    Return: layer
        'matter'
    """
    j = Run.j
    d = maya.value_d
    z = maya.bg_z
    maya.bg_z = None
    parent = make_group_layer(
        j, maya.group, maya.get_light(), "Condenser", z=z
    )
    color = get_mean_color(z)

    prep_replace_color_default()
    color_layer(z, color)

    z1 = clone_layer(z, n="Multiply")
    z1.mode = LAYER_MODE_MULTIPLY
    z1.opacity = 25.
    w = max(1, int(Wip.w // d[de.COLUMN]))
    h = max(1, int(Wip.h // d[de.ROW]))
    w1 = (w + h) / 1.5
    seed_ = int(d[de.RANDOM_SEED] + Globe.seed)

    pdb.gimp_context_set_background((0, 0, 0))
    pdb.gimp_context_set_foreground((255, 255, 255))
    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z1)
    pdb.plug_in_maze(
        j, z1,
        w, h,               # passage scale
        1,                  # yes, tileable
        0,                  # depth first algorithm
        seed_,
        0,                  # multiple, not clearly defined
        0                   # offset, not clearly defined
    )
    select_color(z1, (255, 255, 255))

    white_sc = pdb.gimp_selection_save(j)
    z2 = clone_layer(z1, n="Overlay")
    z2.mode = LAYER_MODE_OVERLAY

    # edge amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(j, z1, 1., 0, 0)

    for _ in range(4):
        dilate(z1)

    # no linear, '0'
    pdb.gimp_drawable_invert(z2, 0)

    color_layer(z2, (127, 127, 127))
    select_channel(j, white_sc)
    clear_inverse_selection(z2)
    pdb.plug_in_emboss(
        j, z2,
        Globe.azimuth,
        Globe.elevation,
        3,                  # depth
        1                   # emboss type
    )
    pdb.gimp_drawable_invert(z1, 0)
    blur_selection(z1, w1)
    select_channel(j, white_sc)
    invert_selection(j)
    clear_inverse_selection(z1)
    pdb.gimp_image_remove_channel(j, white_sc)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class MazeBlend(SubAccent):
    """Create Accent output."""
    kind = de.MAZE_BLEND

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
