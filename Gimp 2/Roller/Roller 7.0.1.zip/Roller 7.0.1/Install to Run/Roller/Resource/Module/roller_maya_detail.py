#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import The
from roller_constant import Issue as vo, Plan as ak, Signal as si
from roller_constant_identity import Identity as de
from roller_gimp_image import check_matter
from roller_maya import Maya
from roller_ring import Ring
from roller_step import get_property_group, get_planner


class Detail(Maya):
    """"Manage Plan output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, super_maya, do_matter, key):
        """
        any_group: AnyGroup
            Margin producer

        super_maya: Maya
            Margin plan or work-view-type Maya
            Delegate Detail layer output.

        do_matter: function
            Make detail layer output.

        key: string
            PlanOption Widget key
            Determine the output's 'go' status from the Property AnyGroup.
        """
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter
        font_size_g = get_property_group(
            any_group.name_step_k).get_widget(de.FONT_SIZE)
        self.font_size = font_size_g.get_ui()

        Maya.__init__(
            self, any_group, 0, ((check_matter, 'matter'),), vo.NO_VOTE
        )

        # PlanOption, 'planner'
        planner = get_planner(any_group.name_step_k)
        self.is_planned = planner.get_widget_a(key)

        self.latch(planner, (ak.SIGNAL_DICT[key], self.on_plan_option_change))
        self.latch(
            font_size_g, (si.FONT_SIZE_CHANGE, self.on_font_size_change)
        )

    def do(self):
        """Manage layer output during a view run."""
        self.go = self.is_planned
        self.is_matter |= self.is_switched or self.super_maya.is_matter

        self.realize()
        self.reset_issue()

    def on_plan_option_change(self, _, arg):
        """
        Receive a Signal when a Plan option is activated.
        Update the 'go' dependency with 'self.is_planned'.

        _: PlanOption
            Sent the signal.

        arg: tuple
            (the value of the Margin CheckButton, its change state)
        """
        self.is_planned, self.is_switched = arg

    def on_font_size_change(self, g, q):
        """
        Respond to change in the Font Size Widget value.

        g: Widget
            Font Size

        q: tuple
            (float, bool)
            (font size, is-changed)
        """
        if The.load_count:
            # Resend the signal after loading Preset.
            Ring.add(g, si.FONT_SIZE_CHANGE, q)
        else:
            self.font_size, is_change = q
            self.is_matter |= is_change


class PlanMargin(Maya):
    """Manage Margin dependent layer output for Plan."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, super_maya, do_matter):
        self.is_switched = False
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter

        Maya.__init__(
            self, any_group, 0, ((check_matter, 'matter'),), vo.NO_VOTE
        )

        planner = get_planner(any_group.name_step_k)
        self.is_planned = planner.get_widget_a(de.MARGIN)
        self.latch(
            planner, (ak.SIGNAL_DICT[de.MARGIN], self.on_plan_option_change)
        )

    def do(self):
        """Manage layer output during a view run."""
        self.go = self.is_planned and self.super_maya.value_d.get(de.SWITCH)
        self.is_matter = self.is_switched or self.super_maya.is_matter

        self.realize()
        self.reset_issue()

    def get_value_d(self):
        return self.any_group.get_value_d()

    def on_plan_option_change(self, _, arg):
        """
        Receive a Signal when the Planner Margin option is modified.

        _: PlanOption
            Sent the signal.

        arg: tuple
            (the value of the Margin CheckButton, its change state)
        """
        self.is_planned, self.is_switched = arg


class PlanShape(Maya):
    """Manage Cell/shape and Per/shape layer output for Plan."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, super_maya, do_matter):
        self.is_switched = False
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter

        Maya.__init__(
            self, any_group, 0, ((check_matter, 'matter'),), vo.NO_VOTE
        )

        planner = get_planner(any_group.name_step_k)
        self.is_planned = planner.get_widget_a(de.CELL_SHAPE)
        self.latch(
            planner,
            (ak.SIGNAL_DICT[de.CELL_SHAPE], self.on_plan_option_change)
        )

    def do(self):
        """Manage a Plan shape layer during a view run."""
        self.go = self.is_planned
        self.is_matter = self.is_switched or self.super_maya.is_matter

        self.realize()
        self.reset_issue()

    def on_plan_option_change(self, _, arg):
        """
        Receive a Signal when the Plan option is activated.
        Update the 'go' dependency with 'self.is_planned'.

        _: PlanOption
            Sent the signal.

        arg: tuple
            (the value of the Property/Margin CheckButton, its change state)
        """
        self.is_planned, self.is_switched = arg
