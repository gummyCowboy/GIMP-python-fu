#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_SUBTRACT,
    CLIP_TO_IMAGE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_OVERLAY,
    pdb
)
from roller_comm import info_msg
from roller_constant_identity import Identity as de
from roller_container import Run, Globe
from roller_frame_alt import Overlap
from roller_frame_type import grow_wrap_channel
from roller_gegl import noise_rgb
from roller_gimp_image import add_layer
from roller_gimp_layer import (
    clear_inverse_selection,
    clone_layer,
    clone_opaque_layer,
    dilate,
    do_curves,
    remove_layer,
    saturate,
    select_opaque
)
from roller_gimp_selection import select_channel

SAWTOOTH = (
    .0, .0,
    .166, .166,
    .167, .1,
    .333, .333,
    .334, .166,
    .5, .5,
    .501, .25,
    .666, .666,
    .667, .444,
    1., 1.
)


def do_matter(maya):
    """
    Make a Crumble frame.

    maya: Crumble
    Return: layer or None
        Wrap output
    """
    j = Run.j
    d = maya.value_d
    go = False
    cast_z = maya.cast.matter
    image_sc = None
    n = d[de.TYPE]

    # failed frame layer, 'z'
    z = wip_z = None

    select_opaque(cast_z)

    if not pdb.gimp_selection_is_empty(j):
        image_sc = pdb.gimp_selection_save(j)

        # The distress function looks for an active layer.
        z = wip_z = j.active_layer = add_layer(
            j, maya.group, maya.get_light(), "Material"
        )

        grow_wrap_channel(j, image_sc, d[de.WIDTH], n)

        try:
            # Throw a critical error if the image size is too small.
            # Create crumble selection from the frame selection.
            pdb.script_fu_distress_selection(
                j, z,
                d[de.DISTRESS],
                d[de.SPREAD],
                4., 2.,
                1, 1                          # smooth horizontal and vertical
            )

        except Exception:
            info_msg(
                "Roller suggests that you try"
                " increasing the render or cell size."
            )
        if not pdb.gimp_selection_is_empty(j) and d[de.CLIP]:
            select_channel(j, image_sc, option=CHANNEL_OP_SUBTRACT)

    if image_sc:
        pdb.gimp_image_remove_channel(j, image_sc)

    if not pdb.gimp_selection_is_empty(j):
        frame_sc = pdb.gimp_selection_save(j)

        # Add noise to the selection.
        # GEGL's Simplex-Noise failed me, so I use this.
        for i in range(12):
            noise_rgb(
                z,
                1., 1., 1., 1.,
                int(d[de.RANDOM_SEED] + Globe.seed) + i
            )

            if i % 2:
                pdb.plug_in_erode(
                    j, z,
                    1,                      # propagate black
                    7,                      # RGB channels
                    1.,                     # full rate
                    7,                      # direction mask
                    0,                      # lower limit
                    255                     # upper limit
                )
            else:
                dilate(z)

        pdb.plug_in_despeckle(
            j, z,
            3,                  # radius
            3,                  # recursive adaptive
            0,                  # black start point
            255                 # white end point
        )

        z = clone_layer(z, n="Difference")
        z.mode = LAYER_MODE_DIFFERENCE
        go = True

        select_channel(j, frame_sc)
        clear_inverse_selection(z)
        pdb.gimp_image_remove_channel(j, frame_sc)

    if go:
        pdb.plug_in_colortoalpha(j, z, (1., 1., 1.))
        saturate(z, -85.)

        z = clone_layer(z, n="Burn")

        dilate(z)

        z.mode = LAYER_MODE_OVERLAY
        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
        z = clone_opaque_layer(z, n="Burn")
        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

        do_curves(z, SAWTOOTH)

        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

        # radius, '4.'; amount, '.5'; threshold, '.0'
        pdb.plug_in_unsharp_mask(j, z, 4., .5, .0)

        remove_layer(wip_z)
    return z


class Crumble(Overlap):
    is_seeded = True
    kind = material = de.CRUMBLE
    wrap_k = de.WRAP_CR

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        Overlap.__init__(self, any_group, super_maya, k_path, do_matter)
