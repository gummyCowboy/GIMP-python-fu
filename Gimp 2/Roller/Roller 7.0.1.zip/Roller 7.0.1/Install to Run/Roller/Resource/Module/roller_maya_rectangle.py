#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Run
from roller_any_group import ManyGroup
from roller_constant import Issue as vo, Signal as si
from roller_maya import Maya
from roller_ring import Ring


class Rectangle(ManyGroup):
    """
    Create a Widget group, assign view-run-type runners,
    and connect responsible Signal handler.
    """

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)
        self.work = Chi(self, 1)
        self.plan = Chi(self, 0)

        self.latch(self.booth, (si.VOTE_CHANGE, self.update_model))
        self.latch(self, (si.SEQUENCE, self.on_sequence))
        self.latch(Ring.gob, (si.RESIZE, self.on_sequence))

    def do(self):
        """
        Override the AnyGroup function so that Past's view Signal can be sent.
        """
        super(Rectangle, self).do()
        self.dna.model.past.emit(si.RECTANGLE_VIEW, Run.i)

    def on_sequence(self, *_):
        """
        Update the Model immediately.

        _: tuple
            (AnyGroup -> Sent the Signal., list ->
            [Plan vote, Work vote])
        """
        self.dna.model.baby.feed(
            si.RECTANGLE_CHANGE, (self.get_value_d(), True)
        )

    def update_model(self, *_):
        """Update the Model as time permits."""
        self.dna.model.baby.give(
            si.RECTANGLE_CHANGE, (self.get_value_d(), False)
        )


class Chi(Maya):
    """Rectangle has no layer output."""
    issue_q = 'matter',
    vote_type = vo.MAIN

    def __init__(self, any_group, view_i):
        Maya.__init__(self, any_group, view_i, (), ())

    def do(self):
        """Is called by a view run step processor."""
        self.reset_issue()
