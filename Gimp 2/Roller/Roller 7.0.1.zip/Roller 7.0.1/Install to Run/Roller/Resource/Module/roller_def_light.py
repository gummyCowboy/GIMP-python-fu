#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import Define as df, Row as rk
from roller_constant_identity import Identity as de
from roller_def_dialog import IMAGE_CHOICE, MMR
from roller_def_option import (
    COLOR_1,
    GRADIENT,
    GRADIENT_ANGLE,
    GRADIENT_TYPE,
    LIGHT_TYPE,
    PATTERN,
    RANDOM,
    SEED,
    SWITCH
)
from roller_tooltip_actor import make_heat_tip
from roller_port_heat import PortHeat
from roller_widget_value_button import HeatButton
from roller_widget_row import WidgetRow

"""Define Light Preset."""

HEAT = {
    df.NO_VOTE: True,
    df.DIALOG: PortHeat,
    df.VALUE: OrderedDict(),
    df.TIP_P: make_heat_tip,
    df.WIDGET: HeatButton
}
LIGHT = OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.TYPE, deepcopy(LIGHT_TYPE)),
    (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (de.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.COLOR_1, deepcopy(COLOR_1)),
    (de.PATTERN, deepcopy(PATTERN)),
    (de.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
    (de.GRADIENT, deepcopy(GRADIENT)),
    (rk.RW1, deepcopy(MMR)),
    (rk.RW2, {
        df.SUB: OrderedDict([
            (de.HEAT, deepcopy(HEAT)),
            (de.RANDOM, deepcopy(RANDOM))
        ]),
        df.WIDGET: WidgetRow
    })
])
