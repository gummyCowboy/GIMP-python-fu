#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Define as df, Issue as vo
from roller_many_handle import Handle


def accept_vote(d, key, issue, vote):
    """
    Update a vote dict with issue votes. Is
    recursive when the 'issue' value is a tuple of Issue.

    d: dict
        to hold vote; for plan or work view-type

    key: string
        Identity

    issue: string or tuple
        string: type of change
        tuple: multiple Issue

    vote: bool
        Is True if the Widget has changed value from its view value.
    """
    if issue and issue != vo.NULL:
        if isinstance(issue, tuple):
            for i in issue:
                accept_vote(d, key, i, vote)
        else:
            if issue not in d:
                d[issue] = {}
            d[issue][key] = vote


class Voter(Handle):
    """Subscribe to Signal. Receive Signal. Cast vote."""

    def __init__(self, **d):
        """
        d: dict
            Init.
        """
        Handle.__init__(self)

        self.issue = d.get(df.ISSUE)
        self.is_vote = df.NO_VOTE not in d
        if self.is_vote:
            if self.key and self.change_signal:
                if self.issue:
                    self.relay.append(self.on_voter_change)
                else:
                    # The option does not vote but effects change.
                    self.relay.append(self.on_simple_change)

    def get_a(self):
        """
        Fetch the value of the Widget stored in the AnyGroup.

        Return: value
            Widget's
        """
        return self.any_group.get_sub_widget_a(self.row_key, self.key)

    def load_a(self, a):
        """
        Set the value of the Widget's display. Update its
        AnyGroup with its latest value.

        a: value
            Give to Widget.
        """
        # A still-type doesn't have a value.
        if self.is_vote:
            a = self.set_ui(a)
            self.any_group.set_sub_widget_a(self.row_key, self.key, a)

    def on_disappear(self, *_):
        """
        The AnyGroup is no longer in service, so disconnect its subscription.
        _: tuple
        """
        self.unlatch()

    def on_simple_change(self, _):
        """
        Flag the option group as changed.

        _: GTK Widget
            Signal sender
            Is responsible for change.
        """
        self.any_group.changed()

    def on_voter_change(self, *_):
        """
        Cast change vote.

        _: tuple or None
            (GTK Widget,)
            Signal sender
            Is responsible for change.
        """
        if self.any_group:
            a = self.get_ui()

            for i in range(2):
                b = self.any_group.get_view_a(i, self.key)
                self.any_group.cast_vote(i, self.key, self.issue, a != b)
            self.any_group.set_sub_widget_a(self.row_key, self.key, a)
