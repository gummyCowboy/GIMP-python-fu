#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    pdb, CHANNEL_OP_REPLACE, FOREGROUND_FILL, SELECT_CRITERION_COMPOSITE
)
from random import uniform
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gegl import median_blur
from roller_gimp_context import (
    prep_brush, set_draw_line_brush, set_fill_context_default, set_foreground
)
from roller_gimp_image import add_wip_base
from roller_gimp_layer import color_selection, get_mean_color
from roller_maya_sub_accent import SubAccent
from roller_preset import combine_seed
from roller_utility import random_rgb
from roller_wip import Wip
import math


def prep_alternate(d):
    """
    Prepare the alternate color output.

    d: dict
        Wave Fill Preset

    Return: list
        [RGB, ...]
    """
    i = False
    color_q = []

    for _ in range(int(d[de.WAVE_COUNT]) + 1):
        color_q.append(d[de.COLOR_2][i])
        i = not i
    return color_q


def calc_color(d):
    """
    Calculate the a color gradient between two colors.

    d: dict
        Wave Fill Preset

    Return: list
        [RGB, ...]
        RGB is a tuple, (int, int, int), or,
        (red, green, blue) color component.
        0 <= component <= 255
    """
    return do_color_calc(d[de.COLOR_2][0], d[de.COLOR_2][1], d[de.WAVE_COUNT])


def calc_mean_color(d):
    """
    Generate a black and white gradient
    for mean color separation and selection.

    d: dict
        Wave Fill Preset

    Return: list
        [RGB, ...]
        RGB is a tuple, (int, int, int), or,
        (red, green, blue) color component.
        0 <= component <= 255
    """
    return do_color_calc((0, 0, 0), (255, 255, 255), d[de.WAVE_COUNT])


def calc_random_color(d):
    """
    Generate random colors for each wave section.

    d: dict
        Wave Fill Preset

    Return: list
        [RGB, ...]
        RGB is a tuple, (int, int, int), or,
        (red, green, blue) color component.
        0 <= component <= 255
    """
    return [random_rgb() for _ in range(int(d[de.WAVE_COUNT] + 1))]


def do_color_calc(color, color1, a):
    """
    Calculate a gradient between two colors. The number colors
    or gradient steps is equal to the wave count plus one.

    color, color1: iterable
        RGB

    a: float
        Is the number of wave lines.

    Return: list
        [RGB, ...]
        RGB is a tuple, (int, int, int), or,
        (red, green, blue) color component.
        0 <= component <= 255
    """
    color_q = []
    red, green, blue = color
    red1, green1, blue1 = color1
    step_q = (red1 - red) / a, (green1 - green) / a, (blue1 - blue) / a

    for _ in range(int(a) + 1):
        red, green, blue = map(int, (red, green, blue))
        color_q.append((red, green, blue))

        red += step_q[0]
        green += step_q[1]
        blue += step_q[2]
    return color_q


def do_matter(maya):
    """
    Make a matter layer for WaveFill.

    maya: WaveFill
    Return: layer or None
        'matter'
    """
    j = Run.j
    d = maya.value_d
    parent = maya.group
    z = add_wip_base("Base", parent)
    is_vertical = bool(d[de.HORIZONTAL])

    combine_seed(d)
    prep_brush()
    set_draw_line_brush()
    set_fill_context_default()
    pdb.gimp_context_set_brush_size(3.)
    pdb.gimp_selection_none(j)
    pdb.gimp_context_set_antialias(1)

    # Stop Fill at 100% opaqueness, '.63'.
    pdb.gimp_context_set_sample_threshold(.63)

    color_q = ROUTE_TYPE[d[de.TYPE]](d)
    a = int(d[de.WAVE_COUNT])
    amp_h = Wip.h / a / 2.
    amp = round(amp_h * d[de.AMPLITUDE])
    y = step_y = round(Wip.h / (a + 1))
    x = step_x = round(Wip.w / (a + 1))

    # Fill all the waves except the last wave.
    for i in range(a):
        if is_vertical:
            q, fill_x, min_y = plot_left_to_right(y, amp)
            fill_y = max(0., min_y - 5.)

        else:
            q, min_x, fill_y = plot_top_to_bottom(x, amp)
            fill_x = max(0., min_x - 5.)

        color = color_q[i]

        set_foreground(color)
        pdb.gimp_paintbrush_default(z, len(q), q)
        fill_wave(z, color, fill_x, fill_y)

        y = round(y + step_y)
        x = round(x + step_x)

    # Fill the last wave.
    if is_vertical:
        fill_y = Wip.h - 1

    else:
        fill_x = Wip.w - 1

    color = color_q[i + 1]

    fill_wave(z, color, fill_x, fill_y)

    if d[de.TYPE] == de.MEAN_COLOR:
        do_mean_color(j, parent, z, maya.bg_z, color_q)

    median_blur(z, 2., 50.)
    return maya.finish(z, d[rk.BRW])


def do_mean_color(j, group, z, bg_z, color_q):
    """
    Replace color with the background's mean color.

    j: Gimp Image
        WIP

    z: layer
        Replace color.

    color_q: list
        [RGB, ...]
        Use to create selection.
    """
    # Assume that the color deviates by .01%.
    pdb.gimp_context_set_sample_threshold(.01)

    for color in color_q:
        pdb.gimp_image_select_color(j, CHANNEL_OP_REPLACE, z, color)
        color_selection(z, get_mean_color(bg_z))
    pdb.gimp_selection_none(j)


def fill_wave(z, color, x, y):
    """
    Fill a wave region. At start, the filled region has no material.
    Spread color, like a fluid, into this region and stop at opaque pixel.

    z: layer
        Receive fill color.

    color: tuple
        RGB

    x, y: float
        Fill point.
    """
    pdb.gimp_context_set_sample_criterion(SELECT_CRITERION_COMPOSITE)
    set_foreground(color)
    pdb.gimp_drawable_edit_bucket_fill(z, FOREGROUND_FILL, x, y)


def plot_top_to_bottom(start_x, amplitude):
    """
    Calculate the points for a wave that starts
    on the left of a Wip-sized layer and ends at its right.

    start_x: float
        Is the coordinate for the base line for the vertical wave.

    amplitude: float
        Distinguish wave.

    Return: tuple
        (list, minimum x position, fill y value)
        (plotted [x, y, ...], x, y)
    """
    q = []
    angle = uniform(.0, 6.28)
    h = wave_length = Wip.h
    min_x = Wip.w
    fill_y = 0

    # Pi x 2, '6.28318'
    f = 6.28318 / wave_length

    # Ensure that the line closes the vertical space, '1'.
    for y in range(int(h) + 1):
        y = float(y)
        x = math.cos(angle) * amplitude
        x = round(x + start_x)

        if x < min_x:
            min_x = x
            fill_y = y

        q.extend([x, y])
        angle += f
    return q, min_x, fill_y


def plot_left_to_right(start_y, amplitude):
    """
    Calculate the points for a wave that starts
    on the left of a Wip-sized layer and ends at its right.

    start_y: float
        Is the coordinate for the base line for the horizontal wave.

    amplitude: float
        Distinguish wave.

    Return: tuple
        (list, fill x position, minimum y value)
        (plotted [x, y, ...], x, y)
    """
    q = []
    angle = uniform(.0, 6.28)
    w = wave_length = Wip.w
    min_y = Wip.h
    fill_x = 0

    # Pi x 2, '6.28318'
    f = 6.28318 / wave_length

    # Ensure that the line closes the horizontal space, '1'.
    for x in range(int(w) + 1):
        x = float(x)
        y = math.sin(angle) * amplitude
        y = round(y + start_y)

        if y < min_y:
            min_y = y
            fill_x = x

        q.extend([x, y])
        angle += f
    return q, fill_x, min_y


class WaveFill(SubAccent):
    kind = de.WAVE_FILL

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)

    def do(self, *arg):
        """Check if the background has change."""
        d = self.any_group.get_value_d()
        self.is_dependent = d[de.TYPE] == de.MEAN_COLOR
        super(WaveFill, self).do(*arg)


ROUTE_TYPE = {
    de.ALTERNATE: prep_alternate,
    de.COLOR: calc_color,
    de.MEAN_COLOR: calc_mean_color,
    de.RANDOM_COLOR: calc_random_color
}
