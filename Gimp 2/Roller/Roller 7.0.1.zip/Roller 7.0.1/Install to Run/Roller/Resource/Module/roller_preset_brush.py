#!/usr/bin/env python
# -*- coding: utf-8 -*-
# noinspection PyUnresolvedReferences
from gimpfu import pdb   # type: ignore
from math import atan2, degrees
from roller_utility import seal
from random import uniform
from roller_constant_identity import Identity as de
from roller_gimp_context import set_gimp_brush


def brush_stroke(z, d, brush, stroke, p=None):
    """
    Brush stroke a path.

    z: layer
        Receive brush material.

    d: dict
        Brush Preset

    brush: Gimp Brush
    stroke: GIMP path
        Has brush stroke.

    p: function or None
        Call before each brush stroke.
    """
    def _calc_angle():
        """Modify the angle with the jitter value."""
        _angle = angle + uniform(-jitter, jitter)

        while _angle > 180.:
            _angle -= 180.

        while _angle < -180.:
            _angle += 180.
        return _angle

    def _calc_stroke_angle(_p1, _p2, _f):
        """
        Calculate the angle of the brush given the
        base angle and a point with a tangent.

        _p1, _p2: points
            Form a tangent.

        _f: float
            of brush
            base angle
        """
        _x, _y = _p1
        _x1, _y1 = _p2
        return (
            (_f + degrees(atan2(_y - _y1, _x - _x1))) % 360.
        ) - 180.

    def _get_end_tangent():
        """Compute the position of the end-point for a tangent."""
        _points = stroke.points[0]

        # end point
        _x, _y = _points[-4:-2]

        # start point
        _x1, _y1 = _points[-6:-4]

        if abs(_x - _x1) < .00001 and abs(_y - _y1) < .00001:
            _x1, _y1 = stroke.get_point_at_dist(
                stroke.get_length(.001) - .5, .01
            )[0:2]
        return _x1, _y1

    def _get_origin_tangent():
        """
        Compute the origin-point position of a tangent.

        Return: tuple
            origin point
            x, y
        """
        _points = stroke.points[0]

        # origin
        _x, _y = _points[2:4]

        # tangent
        _x1, _y1 = _points[4:6]

        if abs(_x - _x1) < .001 and abs(_y - _y1) < .001:
            _x1, _y1 = stroke.get_point_at_dist(.5, .01)[0:2]
        return _x1, _y1

    def _set_hardness():
        """Set the brush hardness."""
        pdb.gimp_context_set_brush_hardness(seal(hard, .01, 1.))

    def _stroke(_q, _f):
        """
        Make a brush stroke.

        _q: list
            [point, ...]

        _f: float
            brush angle in degrees
        """
        if p:
            # Callback.
            p()

        pdb.gimp_context_set_brush_angle(_f)

        # number of stroke points, '2'; strokes, '_q'
        pdb.gimp_paintbrush_default(z, 2, _q)

    def _up_space():
        return avg_w + uniform(.0, up_space) * avg_w if up_space else avg_w

    w = d[de.BRUSH_SIZE]
    spacing = d[de.BRUSH_SPACING]
    jitter = d[de.ANGLE_JITTER]
    up_space = d[de.UP_SPACE]
    upscale = d[de.UPSCALE]
    angle = d[de.BRUSH_ANGLE]
    hard = d[de.HARDNESS]
    length = stroke.get_length(.1)
    points, is_closed = stroke.points
    intervals = round((length / spacing))

    if intervals:
        avg_w = length / intervals

        pdb.gimp_selection_none(z.image)
        pdb.gimp_context_set_stroke_method(1)       # brush, '1'
        set_gimp_brush(brush)
        _set_hardness()
        pdb.gimp_context_set_brush_size(w)

        # The first and last stroke are special.
        # first point
        _stroke(
            points[2:4],
            _calc_stroke_angle(
                points[2:4], _get_origin_tangent(), _calc_angle()
            )
        )

        point = _up_space()

        while point < length:
            if upscale:
                pdb.gimp_context_set_brush_size(
                    w + uniform(.0, upscale) * w
                )

            # Fix a closed-loop's end-point overflow, 'f'.
            f = point // 1.

            x1, y1 = stroke.get_point_at_dist(f, .1)[0:2]
            x2, y2 = stroke.get_point_at_dist(.5 + f, .1)[0:2]
            _stroke(
                (x1, y1), _calc_stroke_angle((x1, y1), (x2, y2), _calc_angle())
            )
            point += _up_space()

        # last point
        if not is_closed:
            _stroke(
                points[-4:-2],
                _calc_stroke_angle(
                    _get_end_tangent(), points[-4:-2], _calc_angle()
                )
            )
