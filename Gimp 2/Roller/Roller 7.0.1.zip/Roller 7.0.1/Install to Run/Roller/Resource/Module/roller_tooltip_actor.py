#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Define as df, Widget as wi
from roller_constant_identity import Identity as de
from roller_def_access import get_init_d
from roller_preset import get_option_list_key
from roller_option_squish import ROUTE_SQUISH
from roller_step import get_type_text
from roller_widget_row import Rainbow, WidgetRow
from roller_wip import get_factor_h, get_factor_w

FACTOR_H_SET = {de.END_X, de.START_X, de.LEFT, de.RIGHT}
MAX_TAB = 7
NO_SHADOW_TIP_SET = {de.SHADOW, de.SHADOW_SWITCH}


def _create_option_tooltip(key, d, tooltip, indent):
    """
    Make a tooltip for a Preset.

    key: string
        Identify Preset.

    d: dict
        Preset
        {Identity: Widget value}

    tooltip: string
        WIP

    indent: int
        Is the count of the tab prefix.

    Return: string
        tooltip
    """
    if key in ROUTE_SQUISH:
        hidden_set = ROUTE_SQUISH[key](
            d,
            {i for i in d if i not in wi.VISIBLE_SET},
            None,
            None
        ).union((de.SWITCH,))

    else:
        hidden_set = set()

    widget_row_set = set()
    default_d = get_init_d(key)
    visible_set = set(d.keys()) - hidden_set

    if default_d:
        # Make a list of hidden row key.
        for i, a in default_d.items():
            # SuperPreset has a 'still' option which is not a dict.
            if isinstance(a, dict):
                row_g = default_d[i].get(df.WIDGET)

                if row_g == WidgetRow:
                    widget_row_set.add(i)
                elif row_g == Rainbow:
                    rainbow_q = _find_rainbow(i, hidden_set)
                    if rainbow_q:
                        # number of visible ColorButton index, '1'
                        if not rainbow_q[1]:
                            # No button is visible.
                            visible_set -= {i}

    else:
        # Option list (Frame and Accent) doesn't have a default.
        k = get_option_list_key(d)

        # During development, a None key has thrown an error.
        # The None key was fixed, but check 'k' for stability.
        if k:
            tooltip = create_tooltip(k, d[k], tooltip, indent)

    if default_d:
        # Process option.
        for k, e in default_d.items():
            # Check to see if the option is visible.
            if k in visible_set and k not in widget_row_set:
                # Check option definition for a tooltip function.
                p = e.get(df.TIP_P) if default_d else None

                if p:
                    tooltip += '\n'
                    tooltip += p(d, k, indent, e)
                else:
                    a = d.get(k)

                    # Some keys have no value (e.g. NEXT_INDEX, COVER, etc.).
                    if isinstance(a, dict):
                        tooltip = create_tooltip(k, a, tooltip, indent)
            else:
                # A Row has multiple option.
                if k in widget_row_set:
                    sub_row_q = e[df.SUB].keys()
                    hidden_row_q = []

                    # Filter out sub-row key that is hidden.
                    for i in hidden_set:
                        # index to a row key, '0'
                        if i[0] == k:
                            # (row key, (sub-row key, ...)), 'i'
                            # index to a sub-row key tuple, '1'
                            for i1 in i[1]:
                                hidden_row_q.append(i1)
                    for i in sub_row_q:
                        if i not in hidden_row_q:
                            e = default_d[k][df.SUB][i]

                            if i == de.FRAME:
                                # This is a Frame Preset in a sub-row.
                                tooltip = create_tooltip(
                                    i, d[k][i], tooltip, indent
                                )
                            else:
                                # Sub-row options can be a sub-branch
                                # or an option end-point (leaf).
                                if e.get(df.SUB):
                                    # Adapt to dynamic 'd' modification.
                                    d1 = d.get(k)
                                    if d1:
                                        sub = d1.get(i)
                                        if sub:
                                            # Is a branch.
                                            tooltip = create_tooltip(
                                                i, sub, tooltip, indent
                                            )
                                else:
                                    # A Random button doesn't
                                    # have a tip processor.
                                    p = e.get(df.TIP_P)
                                    if p:
                                        tooltip += '\n'
                                        tooltip += p(d[k], i, indent, e)
    return tooltip


def _create_shadow_tooltip(key, d, tooltip, indent):
    """
    Make a tooltip for the Shadow SuperPreset.

    key: string
        Is the Shadow key.

    d: dict
        Shadow SuperPreset

    tooltip: string
        tooltip WIP

    indent: int
        Format the tooltip.

    Return: string
        the tooltip
    """
    default_d = get_init_d(key)
    e = default_d[df.SUB]       # default_d: Is a group def, not a sub-group.

    for k in e.keys():
        if k not in NO_SHADOW_TIP_SET:
            tooltip = create_tooltip(k, d[k], tooltip, indent)
    return tooltip


def _find_rainbow(k, hidden_set):
    """
    Scan hidden widget key set looking for a tuple containing a key.

    k: string
        Identity

    hidden_set: set
        May contain a tuple containing a key.

    Return: tuple or None
        (Identity, ...)
    """
    for a in hidden_set:
        if isinstance(a, tuple):
            if a[0] == k:
                return a


def _get_tip_format(i, indent):
    """
    Make two strings for formatting a dynamic tooltip.
    Unfortunately, the tooltip font is not monospaced, so the
    indented strings don't always align on the same tab stop.

    i: string
        option key

    indent: int
        for formatting tab

    Return: tuple
        (string, string)
        (prefix, postfix)
    """
    # tab distance, '4'
    a = (MAX_TAB, MAX_TAB + 2)[indent >= 4]
    a = a - len(i) // 4 - indent
    return (
        '\t' * indent if indent else " ",
        '\t' * max(1, int(a))
    )


def create_tooltip(key, d, tooltip, indent):
    """
    Make a tooltip for a Preset.

    key: string
        Identify Preset.

    d: dict
        Preset

    tooltip: string
        WIP

    indent: int
        Is the count of the tab prefix.

    Return: string
        tooltip
    """
    def _check_per():
        """
        The dict, 'd', is a Per type. Per doesn't have a tooltip.

        Return: string
            tooltip
        """
        return pre_tooltip

    def _check_shadow():
        """
        The dict, 'd', is a Shadow SuperPreset.

        Return: string
            tooltip
        """
        if not d[de.SHADOW_SWITCH][de.SWITCH]:
            return tooltip + "Off "
        else:
            return _create_shadow_tooltip(key, d, tooltip, indent + 1)

    if key == de.OPTION_LIST:
        # It's a no show option.
        indent -= 1

    else:
        if indent:
            n = '\n' + '\t' * indent

        else:
            n = " "

        k = get_type_text(key)
        pre_tooltip = tooltip
        tooltip += n + k + " "

    # a special Preset processor, 'p'
    p = {de.PER: _check_per, de.SHADOW: _check_shadow}.get(key)

    if p:
        # tooltip, 'a'
        a = p()
        if a:
            return a

    else:
        # Check to see if the Preset is switchable and switched off.
        a = d.get(de.SWITCH)

        if not a and a is not None:
            return tooltip + "Off "
        if tooltip.count('\n') > 20:
            # The tooltip is too long.
            return tooltip + "On "
    return _create_option_tooltip(key, d, tooltip, indent + 1)


def make_bool_tip(d, i, indent, _):
    """
    Make a tooltip for an option value that is boolean.

    d: dict
        option group Preset

    i: string
        option key

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    n, n1 = _get_tip_format(i, indent)
    return n + i + n1 + '{} '.format(bool(d[i]))


def make_heat_tip(d):
    """
    Make a tooltip for the Heat OptionButton.

    d: dict
        Heat Preset
        {Identity: value}

    Return: string
        formatted for option
    """
    if d:
        n = " Heat "
        for k, e in d.items():
            n += '\n\t' + k + ":\t"
            n += "Mode: {},\t".format(e.get(de.MODE))
            n += "Opacity: {} ".format(e.get(de.OPACITY))

    else:
        n = " Heat is empty. "
    return n


def make_radio_tip(d, i, indent, e):
    """
    Make a tooltip for an option that has two RadioButton.

    d: dict
        Preset

    i: string
        Identity

    indent: int
        for formatting tab

    e: dict
        option's init value

    Return: string
        formatted for option
    """
    n, n1 = _get_tip_format(i, indent)
    return n + i + n1 + '{} '.format(e[df.TEXT][int(d[i])])


def make_rainbow_count_tip(d, k, indent, _):
    """
    Translate multi-line text into a tooltip.

    d: dict
        Preset

    k: string
        Identity

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    k1 = get_type_text(k)
    n, n1 = _get_tip_format(k1, indent)
    n2, n3 = _get_tip_format(k1, indent + 1)
    tip = n + k1 + n1

    for i in range(int(d[de.COLOR_COUNT])):
        tip += ' \n'
        tip += n2 + str(d[k][i]) + n3
    return tip


def make_rainbow_tip(d, k, indent, _):
    """
    The Rainbow Widget has a multiline tooltip and
    changes visible Widget with the number of colors.

    d: dict
        Preset

    k: string
        Identity

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    k1 = get_type_text(k)
    n, n1 = _get_tip_format(k1, indent)
    n2, n3 = _get_tip_format(k1, indent + 1)
    tip = n + k1 + n1

    for k1 in d[k]:
        tip += ' \n'
        tip += n2 + str(k1) + n3
    return tip


def make_slider_tip(d, k, indent, _):
    """
    Make a tooltip for an view size factored slider option value.

    d: dict
        Preset

    k: string
        Identity

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    k1 = get_type_text(k)
    a = get_factor_w(d[k]) \
        if k in FACTOR_H_SET \
        else get_factor_h(d[k])

    if a == int(a):
        a = int(a)

    n, n1 = _get_tip_format(k1, indent)
    return n + k1 + n1 + '{} '.format(a)


def make_text_tip(d, k, indent, _):
    """
    Make a tooltip for an option value that is translated as text.

    d: dict
        Preset

    k: string
        Identity

    indent: int
        for formatting tab

    Return: string
        formatted for option
    """
    k1 = get_type_text(k)
    n, n1 = _get_tip_format(k1, indent)
    a = d[k]

    if isinstance(a, float) and a == round(a):
        a = int(a)
    return n + k1 + n1 + '{} '.format(a)
