#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import Deco as dc, Define as df, Row as rk
from roller_constant_identity import Identity as de
from roller_def_dialog import (
    ADD,
    BRUSH_DIALOG,
    FCM,
    GRID,
    IMAGE_CHOICE,
    IMR,
    IRM,
    LTR,
    MAF,
    MASK,
    MAW,
    MFR,
    MOD,
    STRIP
)
from roller_def_option import (
    ANGLE,
    BORDER_W,
    BRUSH,
    CAPTION_TYPE,
    CLIP_FRINGE,
    COLOR_1,
    COLOR_6,
    COLOR_COUNT_FRINGE,
    CONTRACT,
    DECO_TYPE,
    FONT_SIZE,
    GRADIENT,
    GRADIENT_ANGLE,
    GRADIENT_TYPE,
    HARDNESS,
    JUSTIFICATION,
    MAX_POLAR_X,
    MAX_POLAR_Y,
    MAX_POSITIVE_X,
    MAX_POSITIVE_Y,
    METHOD,
    MODE,
    OBEY_MARGIN,
    OPACITY,
    PATTERN,
    PER,
    SEED,
    START_NUMBER,
    SWITCH,
    TEXT,
    WIDTH_LINE
)
from roller_widget_row import WidgetRow


def get_fringe_type_list():
    return dc.FRINGE_TYPE_LIST


# Border_______________________________________________________________________
BORDER = OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.TYPE, deepcopy(DECO_TYPE)),
    (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (de.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.WIDTH, deepcopy(BORDER_W)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (de.GRID, deepcopy(GRID)),
    (de.COLOR_1, deepcopy(COLOR_1)),
    (de.GRADIENT, deepcopy(GRADIENT)),
    (de.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
    (de.PATTERN, deepcopy(PATTERN)),
    (rk.RW1, deepcopy(MFR)),
    (rk.BRW, deepcopy(MAW)),
    (de.PER, deepcopy(PER))
])
BORDER[de.COLOR_1][df.VALUE] = 127, 127, 127
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Caption______________________________________________________________________
CAPTION = OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.TYPE, deepcopy(CAPTION_TYPE)),
    (de.JUSTIFY, deepcopy(JUSTIFICATION)),
    (de.TEXT, deepcopy(TEXT)),
    (rk.LTR, deepcopy(LTR)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.FONT_SIZE, deepcopy(FONT_SIZE)),
    (de.START_NUMBER, deepcopy(START_NUMBER)),
    (de.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (rk.RW1, deepcopy(FCM)),
    (rk.BRW, {
        df.SUB: OrderedDict([
            (de.MOD, deepcopy(MOD)),
            (de.ADD, ADD),
            (de.STRIP, deepcopy(STRIP))
        ]),
        df.WIDGET: WidgetRow
    }),
    (de.PER, deepcopy(PER))
])
CAPTION[rk.RW1][df.SUB][de.COLOR_1][df.TOOLTIP] = "Text Color"
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Fringe_______________________________________________________________________
FRINGE = OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.TYPE, deepcopy(DECO_TYPE)),
    (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (de.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.CONTRACT, deepcopy(CONTRACT)),
    (de.COLOR_COUNT, deepcopy(COLOR_COUNT_FRINGE)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (de.CLIP, deepcopy(CLIP_FRINGE)),
    (de.GRID, deepcopy(GRID)),
    (de.COLOR_6, deepcopy(COLOR_6)),
    (de.COLOR_1, deepcopy(COLOR_1)),
    (de.GRADIENT, deepcopy(GRADIENT)),
    (de.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
    (de.PATTERN, deepcopy(PATTERN)),
    (rk.RW1, {
        df.SUB: OrderedDict([
            (de.BRUSH_D, deepcopy(BRUSH_DIALOG)),
            (de.MASK, deepcopy(MASK))
        ]),
        df.WIDGET: WidgetRow
    }),
    (rk.BRW, deepcopy(MAF)),
    (de.PER, deepcopy(PER))
])
FRINGE[de.TYPE][df.FUNCTION] = get_fringe_type_list
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Image__________________________________________________________
IMAGE = OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.JUSTIFY, deepcopy(JUSTIFICATION)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.ANGLE, deepcopy(ANGLE)),
    (de.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (rk.RW1, deepcopy(IRM)),
    (rk.BRW, deepcopy(MAF)),
    (de.PER, deepcopy(PER))
])
IMAGE[rk.RW1][df.SUB][de.IMAGE_CHOICE][df.SUB][de.TYPE][df.VALUE] = de.LOOP
IMAGE[de.OBEY_MARGIN][df.VALUE] = 1
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Line_________________________________________________________________________
LINE = OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.WIDTH, deepcopy(WIDTH_LINE)),
    (de.HARDNESS, deepcopy(HARDNESS)),
    (de.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (de.METHOD, deepcopy(METHOD)),
    (de.COLOR_1, deepcopy(COLOR_1)),
    (de.BRUSH, deepcopy(BRUSH)),
    (rk.BRW, deepcopy(MAF)),
    (de.PER, deepcopy(PER))
])
LINE[de.BRUSH][df.VALUE] = "1. Pixel"
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Plaque_______________________________________________________________________
PLAQUE = OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.TYPE, deepcopy(DECO_TYPE)),
    (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (de.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.OBEY_MARGIN, deepcopy(OBEY_MARGIN)),
    (de.GRID, deepcopy(GRID)),
    (de.COLOR_1, deepcopy(COLOR_1)),
    (de.GRADIENT, deepcopy(GRADIENT)),
    (de.PATTERN, deepcopy(PATTERN)),
    (rk.RW1, deepcopy(IMR)),
    (rk.BRW, deepcopy(MAF)),
    (de.PER, deepcopy(PER))
])
PLAQUE[de.COLOR_1][df.VALUE] = 255, 255, 255
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Shift________________________________________________________________________
SHIFT = OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.OFFSET_X, deepcopy(MAX_POLAR_X)),
    (de.OFFSET_Y, deepcopy(MAX_POLAR_Y)),
    (de.WIDTH_MOD, deepcopy(MAX_POLAR_X)),
    (de.HEIGHT_MOD, deepcopy(MAX_POLAR_Y)),
    (de.JITTER_X, deepcopy(MAX_POSITIVE_X)),
    (de.JITTER_Y, deepcopy(MAX_POSITIVE_Y)),
    (de.JITTER_W, deepcopy(MAX_POSITIVE_X)),
    (de.JITTER_H, deepcopy(MAX_POSITIVE_Y)),
    (de.RANDOM_SEED, deepcopy(SEED)),
    (de.PER, deepcopy(PER))
])

for i in (de.JITTER_X, de.JITTER_W, de.OFFSET_X, de.WIDTH_MOD):
    SHIFT[i].update({df.AXIS: 'x'})
for i in (de.HEIGHT_MOD, de.JITTER_H, de.JITTER_Y, de.OFFSET_Y):
    SHIFT[i].update({df.AXIS: 'y'})
