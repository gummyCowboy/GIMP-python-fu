#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, CHANNEL_OP_SUBTRACT, pdb   # type: ignore
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_frame import grow_wrap
from roller_frame_alt import FrameBasic
from roller_gimp_context import set_fill_context_default
from roller_gimp_gradient import calc_gradient
from roller_gimp_image import add_layer
from roller_gimp_layer import clear_selection, color_selection, select_layer
from roller_gimp_selection import select_channel


def do_matter(maya):
    """
    Make a frame.

    maya: Gradual
    Return: layer
        Wrap frame
    """
    j = Run.j
    d = maya.value_d
    start_color, end_color = d[de.COLOR_2A]
    steps = d[de.WIDTH]
    cast = maya.cast.matter
    z = add_layer(j, maya.group, maya.get_light(), "Material")

    # Begin gradient construction.
    step = calc_gradient(start_color, end_color, steps)
    q = list(start_color)
    sc = None

    set_fill_context_default()
    select_layer(cast)

    for i in range(int(steps)):
        if not pdb.gimp_selection_is_empty(j):
            sc = pdb.gimp_selection_save(j)

            grow_wrap(j, None, 1., de.ANGULAR)
            select_channel(j, sc, option=CHANNEL_OP_SUBTRACT)
            color_selection(z, tuple(q))
            select_channel(j, sc, option=CHANNEL_OP_ADD)
            for i1 in range(4):
                q[i1] = start_color[i1] + int(step[i1] * (i + 1))
        if sc:
            pdb.gimp_image_remove_channel(j, sc)
            sc = None

    select_layer(cast)
    clear_selection(z)
    return z


class Gradual(FrameBasic):
    kind = material = de.GRADUAL
    wrap_k = de.WRAP_GR

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
