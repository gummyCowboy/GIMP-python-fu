#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant import Define as df
from roller_port_process import PortProcess


class PortPreview(PortProcess):
    """Enable a view run with process Button. Respond to view button action."""

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: object
            Button or Glue
            Reference as 'repo'.
        """
        self.accept_callback = d.get(df.ON_ACCEPT, self.set_repo_value)
        self.cancel_callback = d.get(df.ON_CANCEL)
        self.preview_button = self.plan_button = None
        self._original_value = deepcopy(g.get_a())
        PortProcess.__init__(self, d, g)

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return self.on_cancel_port_preview, self.on_accept_port_preview

    def on_accept_port_preview(self, *_):
        """Respond to an accept action."""
        self.accept_callback(self.get_group_value())

    def on_cancel_port_preview(self):
        """
        Respond to a cancel action.
        Return the original value to the Dialog's precursor, 'repo'.
        """
        self.repo.load_a(self._original_value)
        if self.cancel_callback:
            self.cancel_callback()

    def set_repo_value(self, a):
        """
        Set the 'repo' value.

        a: value
            Pass to the responsible Button.
        """
        self.repo.load_a(a)
