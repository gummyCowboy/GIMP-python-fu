#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Signal as si
from roller_ring import Ring


class Ref:
    """
    Accept AnyGroup vote. Call from Ring when the interface
    is idle and after a Preset has finished loading.
    """
    # Correspond with 'Ref.step_q'.
    # {navigation AnyGroup, ...}
    any_group_q = []

    # {int, }
    # index to AnyGroup in 'Ref.any_group_q'.
    change_q = set()

    # {AnyGroup with image reference, ...}
    image_q = set()

    # Freeze-frame AnyGroup Type-indices for image assignment.
    # {Type-key: {AnyGroup ordinal: Type's state}}
    state_d = {}

    # Each reference AnyGroup has the following properties:
    #   one or more assignment obligations
    #   Canvas has one.
    #   Cell has a cell grid. Face has grid face count, etc.
    #
    #  Each obligation has a varying number of image reference
    #  that need to assigned. The number of image references
    #  varies with the type of the Preset.
    #
    #  The image assignments are stored in a list. Each assignment
    #  is ordered by [primary, mask, frame]
    #
    #  An image assignment three states:
    #    None: no assignment
    #    Type instance: part of a grid and is loading
    #    Single instance: loaded or partially loaded image
    #
    #  'grid_ref_d' purpose is to store the image assignments
    #  for each obligation.
    #
    # To get/set an image assignment, two keys and an index are needed.
    # The first key is an AnyGroup id. The second key is the obligation key.
    # {AnyGroup.id: {obligation key: list of assignments}}
    grid_ref_d = {}

    # {Model-name-step-key, ...}
    step_q = []

    # Store Type handler by its type-key.
    # Each reference has a Type handler or None.
    # {type key: Type instance}
    type_d = {}

    def __init__(self, on_helm_change, on_ring_empty, on_global_seed):
        Ring.gob.connect(si.HELM_CHANGE, on_helm_change)
        Ring.gob.connect(si.RING_EMPTY, on_ring_empty)
        Ring.gob.connect(si.GLOBAL_SEED, on_global_seed)
