#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Model name can be found in:
# Model.model_name
# AnyGroup.name_step_k
# Helm (every item it maintains)
# Shelf (every item it maintains)
# ModelName: '_model_name_d' key.


class ModelName:
    """Use to lessen the impact of Model name change."""
    # {model name (str): Model instance}
    _model_name_d = {}

    @staticmethod
    def add(n, model):
        """
        Add a Model instance to the Model name dict.

        n: string
            Model name

        model: Model
            Has a 'model_name' attribute.
        """
        ModelName._model_name_d[n] = model

    @staticmethod
    def delete(n):
        d = ModelName._model_name_d
        if n in d:
            d.pop(n)

    @staticmethod
    def get_model(n):
        """
        Fetch the Model given its identifier.

        n: string
            Model name

        Return: Model or None
        """
        return ModelName._model_name_d.get(n)

    @staticmethod
    def rename(old_name, new_name):
        """
        Rename a Model.

        old_name: string
            previous Model name

        new_name: string
            new Model name
        """
        d = ModelName._model_name_d
        if old_name in d:
            a = d[old_name]
            a.model_name = new_name     # Model updated.
            d[new_name] = a
            d.pop(old_name)
