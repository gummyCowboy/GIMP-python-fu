#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Define as df, Signal as si
from roller_utility import convert_to_rgb, random_rgb, random_rgba
from roller_tooltip_text import Tip
from roller_widget import Widget
import gtk      # type: ignore


class ColorButton(Widget):
    """Open a color-chooser dialog as an action response."""
    change_signal = 'color_set'
    has_table_label = True

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        g = gtk.ColorButton(color=gtk.gdk.Color(0, 0, 0))
        self._has_alpha = d.get(df.HAS_ALPHA, False)
        self.greater_g = d.get(df.GREATER_G)
        self.color_name = d.get(df.COLOR_NAME)

        d[df.RELAY].insert(0, self.update_tooltip)
        g.set_use_alpha(self._has_alpha)
        Widget.__init__(self, g, **d)
        self.add(g)

    def get_ui(self):
        """
        Get the value of the ColorButton.

        Return: tuple
            color
            RGB
            in 0 to 255
        """
        color = convert_to_rgb(self.widget.get_color())

        if self._has_alpha:
            color = color + (self.widget.get_alpha() // 257,)
        return color

    def set_ui(self, color, is_dialog=False):
        """
        Set the color of the ColorButton.

        color: gtk.gdk.Color
            of button

        is_dialog: bool
            Is True if the value is coming from a color dialog.
            When the value is not coming from a dialog,
            a vote needs to be sent.

        Return: tuple
            RGB or RGBA
        """
        # JSON creates list.
        if isinstance(color, list):
            color = tuple(color)

        if not isinstance(color, tuple):
            color = 0, 0, 0

        color1 = color[:]

        if self._has_alpha:
            if len(color1) < 4:
                # Fix a missing alpha value
                # which may occur with updates.
                color1 += (255,)
            color = color1[:3]

        if not isinstance(color, gtk.gdk.Color):
            if isinstance(color, tuple):
                color = tuple([i * 257 for i in color])

            # in the range of 0 to 65535, 'color'
            # 257 in GDK color is 1.0 RGBA float precision.
            color = gtk.gdk.Color(*color)

        self.widget.set_color(color)

        q = convert_to_rgb(color)
        n = self.color_name + "\n" if self.color_name else ""

        if self._has_alpha:
            self.widget.set_alpha(color1[3] * 257)
            tip = Tip.COLOR_RGBA_INDENT if n else Tip.COLOR_RGBA
            q += (color1[3],)

        else:
            tip = Tip.COLOR_INDENT if n else Tip.COLOR

        tip = n + tip

        if not is_dialog and not self.greater_g:
            self.on_voter_change(self.widget)

        self.set_tooltip_text(tip.format(*q))
        return color1

    def update_tooltip(self, *_):
        """
        Update the Widget's tooltip after the
        user closes the color-chooser dialog.
        Will trigger a vote.
        """
        self.set_ui(self.get_ui(), is_dialog=True)


class RandomColorButton(ColorButton):
    """Is able to randomize."""

    def __init__(self, **d):
        ColorButton.__init__(self, **d)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

    def randomize(self, *_):
        """Randomize the color value."""
        self.load_a(
            random_rgba() if self._has_alpha else random_rgb()
        )


class RainbowColorButton(RandomColorButton):
    """Update Rainbow Widget on change."""

    def __init__(self, **d):
        RandomColorButton.__init__(self, **d)

    def load_a(self, a):
        self.set_ui(a)

    def set_ui(self, color, is_dialog=False):
        color = super(RainbowColorButton, self).set_ui(
            color, is_dialog=is_dialog
        )

        self.greater_g.update_a()
        return color
