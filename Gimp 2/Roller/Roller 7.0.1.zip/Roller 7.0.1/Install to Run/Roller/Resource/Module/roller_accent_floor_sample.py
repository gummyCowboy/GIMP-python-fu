#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb    # type: ignore
from math import radians
from roller_constant import Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_context import set_fill_context_default
from roller_gimp_gradient import calc_gradient
from roller_gimp_image import add_sub_maya_group, add_wip_layer
from roller_gimp_layer import color_selection, get_mean_color
from roller_gimp_selection import select_polygon
from roller_maya_shadow import Shadow
from roller_maya_sub_accent import SubAccent
from roller_preset import combine_seed
from roller_preset_shadow import make_shadow, make_shadow_inner
from roller_utility import get_point_on_edge, random_rgb
from roller_wip import Wip

LEFT, TOP, RIGHT, BOTTOM = range(4)


def fetch_mean_color(_, z):
    """
    _: int
        0..n
        wedge sequence

    z: layer
        background copy

    Return: tuple
        RGB
    """
    return get_mean_color(z)


def get_next_color(ray, start_color, step_q):
    """
    ray: int
        0..n
        wedge sequence

    start_color: tuple
        RGBA

    step_q: list
        [float,  float, float, float]
        Add float to the start color component.

    Return: tuple
        RGBA
    """
    if ray:
        # Calculate the next polygon color.
        color = ()
        for i in range(4):
            b = step_q[i] * ray
            color += (start_color[i] + int(b),)

    else:
        color = start_color
    return color


def init_color(_, d):
    """
    Create an argument for the color type function.

    _: group layer
        not used

    d: dict
        Floor Sample Preset

    Return: tuple
        (start color, color step list for RGBA)
        color step list -> [float, float, float, float]
    """
    a, b = d[de.COLOR_2A]
    return a, calc_gradient(a, b, int(d[de.SLICE_COUNT]))


def init_mean_color(maya, _):
    """
    Create an argument for the mean color type function.

    maya: FloorSample
    _: dict
        Floor Sample Preset

    Return: tuple
        (background copy layer,)
    """
    return (maya.bg_z,)


GET_COLOR = {
    de.COLOR: get_next_color,
    de.MEAN_COLOR: fetch_mean_color,
    de.RANDOM_COLOR: random_rgb
}
INIT_TYPE = {
    de.COLOR: init_color,
    de.MEAN_COLOR: init_mean_color,
    de.RANDOM_COLOR: lambda *_: ()
}


def do_shadow_preset(d, outer_cast_q, inner_cast_z, parent):
    """
    Make up to three shadow layers.

    d: dict
        Shadow SuperPreset

    outer_cast_q: iterable
        [layer, ...]
        Pass to Shadow #1 and Shadow #2.

    inner_cast_z: layer
        Cast an inner shadow.

    parent: group layer
        Determine where the shadow layer is placed. Has position and name.
    """
    e = d[de.SHADOW_1]

    if e[de.SWITCH]:
        make_shadow(
            e, parent, outer_cast_q, name=parent.name + " Shadow 1"
        )

    e = d[de.SHADOW_2]

    if e[de.SWITCH]:
        make_shadow(
            e, parent, outer_cast_q, name=parent.name + " Shadow 2"
        )

    e = d[de.INNER_SHADOW]
    if e[de.SWITCH]:
        make_shadow_inner(
            e, parent, inner_cast_z, name=parent.name + " Inner Shadow"
        )


def do_matter(maya):
    """
    Draw a fan of multi-colored wedges.

    maya: FloorSample
    Return: layer
        Floor Sample output
    """
    def _get_side(_x, _y):
        """
        Determine the side of a the WIP rectangle
        that a wedge vector intersects.

        _x, _y: float
            point on the rectangle bounds

        Return: int
            index to the side the vector intersects
        """
        if _x >= right_x and _y < bottom_y:
            return RIGHT

        if _y >= bottom_y and _x > left_x:
            return BOTTOM

        if _x <= left_x and _y > top_y:
            return LEFT
        return TOP

    j = Run.j
    d = maya.value_d
    n = d[de.TYPE]
    shadow_d = d[rk.RW1][de.SHADOW]
    has_shadow = shadow_d[de.SHADOW_SWITCH][de.SWITCH]

    combine_seed(d)
    set_fill_context_default()

    angle = radians(360. / d[de.SLICE_COUNT])
    slice_cnt = int(d[de.SLICE_COUNT])
    left_x, top_y, w, h = Wip.get_rect()
    right_x = w + left_x
    bottom_y = h + top_y
    center_x, center_y = Wip.center()
    start_angle = radians(d[de.ANGLE])
    group = add_sub_maya_group(maya)
    type_arg = INIT_TYPE[n](maya, d)

    # Index by side. The order is TOP, RIGHT, BOTTOM, LEFT.
    corner_q = (
        (left_x, top_y),
        (right_x, top_y),
        (right_x, bottom_y),
        (left_x, bottom_y)
    )

    # Collect vector rectangle intersect.
    # intersect
    q_x = []
    q_y = []

    for _ in range(slice_cnt):
        x, y = get_point_on_edge(start_angle)
        q_x += [x]
        q_y += [y]
        start_angle += angle

    # Add repeating start vector to simplify the final polygon arrangement.
    q_x += [q_x[0]]
    q_y += [q_y[0]]

    # Assemble and draw color filled polygon.
    for ray_i in range(slice_cnt):
        # The indices 'side 1' and 'side 2'
        # reference the sides of the image-rectangle
        # that the wedge begins and ends.
        # line 1
        x, y = q_x[ray_i], q_y[ray_i]
        q = center_x, center_y, x, y
        side_1 = _get_side(x, y)

        # line 2
        x1, y1 = q_x[ray_i + 1], q_y[ray_i + 1]
        side_2 = _get_side(x1, y1)

        if side_1 != side_2:
            # Add corner points to the polygon.
            side_x = side_1
            for _ in range(4):
                # Add a corner point.
                q += corner_q[side_x]

                if side_x == side_2:
                    break

                side_x += 1
                if side_x > BOTTOM:
                    side_x = 0

        q += x1, y1

        select_polygon(j, q)

        z = add_wip_layer("Edge", group)

        color_selection(z, GET_COLOR[n](ray_i, *type_arg))
        if has_shadow:
            do_shadow_preset(shadow_d, (z,), z, group)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, group), d[rk.RW1]
    )


class FloorSample(SubAccent):
    """Create Accent output."""
    kind = de.FLOOR_SAMPLE

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group, self, (self,), (rk.RW1, de.SHADOW)
        )

    def do(self, *arg):
        """Check if the background has change."""
        d = self.any_group.get_value_d()
        self.is_dependent = d[de.TYPE] == de.MEAN_COLOR
        self.is_matter |= self.sub_maya[sm.SHADOW].get_any_vote()

        super(FloorSample, self).do(*arg)
        self.sub_maya[sm.SHADOW].reset_all_issue()
