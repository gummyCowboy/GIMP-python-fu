#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from collections import OrderedDict
from roller_constant import Define as df, Issue as vo, Row as rk
from roller_constant_identity import Identity as de
from roller_tooltip_text import Tip
from roller_def_option import RANDOM
from roller_widget_check_button import CheckButton
from roller_widget_row import WidgetRow
from roller_widget_slider import RandomSlider, RenderSlider, WIPSlider
import gtk  # type: ignore

# Define the Global Preset.
screen_w, screen_h = gtk.gdk.screen_width(), gtk.gdk.screen_height()
RENDER = {
    df.ISSUE: vo.MATTER,
    df.LIMIT: (1, 524288),
    df.PAGE_INCR: 100,
    df.WIDGET: RenderSlider
}
render_h = RENDER.copy()
render_w = RENDER.copy()

render_h.update({df.VALUE: float(screen_h)})
render_w.update({df.VALUE: float(screen_w)})

GLOBAL = OrderedDict([
    (de.RENDER_W, render_w),
    (de.RENDER_H, render_h),
    (de.WIP, {
        df.ISSUE: vo.MATTER,
        df.LIMIT: (1., 6.),
        df.PAGE_INCR: .5,
        df.PRECISION: 1,
        df.STEP_INCR: .1,
        df.TOOLTIP: Tip.WIP,
        df.VALUE: 1.5,
        df.WIDGET: WIPSlider
    }),
    (de.AZIMUTH, {
        df.ISSUE: vo.EMBOSS,
        df.LIMIT: (.0, 359.9),
        df.PRECISION: 1,
        df.RANDOM_Q: (.0, 359.9),
        df.TOOLTIP: Tip.AZIMUTH,
        df.VALUE: 45.,
        df.WIDGET: RandomSlider
    }),
    (de.ELEVATION, {
        df.COLUMN_TEXT: "Light Elevation",
        df.ISSUE: vo.EMBOSS,
        df.LIMIT: (.0, 180.),
        df.PRECISION: 1,
        df.RANDOM_Q: (7., 21.),
        df.TOOLTIP: Tip.ELEVATION,
        df.VALUE: 13.,
        df.WIDGET: RandomSlider
    }),
    (de.RANDOM_SEED, {
        df.ISSUE: vo.SEED,
        df.LIMIT: (0, 99999),
        df.RANDOM_Q: (0, 99999),
        df.TOOLTIP: Tip.SEED_GLOBAL,
        df.VALUE: 0.,
        df.WIDGET: RandomSlider
    }),
    (rk.RW1, {
        df.SUB: OrderedDict([
            (de.HIDE_LAYER, {
                df.ISSUE: vo.NULL,
                df.TOOLTIP: Tip.HIDE_LAYER,
                df.VALUE: 0,
                df.WIDGET: CheckButton
            }),
            (de.DELETE_PLAN, {
                df.ISSUE: vo.NULL,
                df.TOOLTIP: Tip.DELETE_PLAN,
                df.VALUE: 1,
                df.WIDGET: CheckButton
            })
        ]),
        df.WIDGET: WidgetRow
    }),
    (de.RANDOM, deepcopy(RANDOM))
])
