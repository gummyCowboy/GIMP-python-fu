#!/usr/bin/env python
# -*- coding: utf-8 -*-
# from copy import deepcopy
from random import choice
from roller_constant import Define as df, Signal as si
from roller_constant_identity import Identity as de
from roller_container import Cat
from roller_def_access import get_vote_d, get_default_d
from roller_preset import get_option_list_choice
from roller_ring import Ring
from roller_tooltip_actor import create_tooltip
from roller_step import get_type_text
from roller_widget_button import ProcessButton
from roller_widget_voter import accept_vote
import gtk  # type: ignore


def make_dialog_button_text(key):
    """
    key: string
        May contain a comma that splits the key
        into an interfaced-used and sub-type strings.

    Return: string
        Indicate that the Button opens a dialog.
    """
    return "{}…".format(get_type_text(key))


def gather_vote(vote_d, ballot_d, old_d, new_d):
    """
    Compare two Preset dict. When an item differs,
    record a True vote for the option's issue that is
    found in a ballot dict.

    vote_d: dict
        Collect issue vote.

    ballot_d: dict
        Is structured symmetrically with the Preset dict.

    old_d: dict or None
        old value

    new_d: dict
        new value

    Return: dict
        with vote
    """
    if old_d:
        for i, a in ballot_d.items():
            if isinstance(a, dict):
                if i not in vote_d:
                    vote_d[i] = {}
                gather_vote(vote_d[i], ballot_d[i], old_d.get(i), new_d.get(i))
            elif old_d.get(i) != new_d.get(i):
                accept_vote(vote_d, i, a, True)
    else:
        gather_ballot_vote(vote_d, ballot_d)


def gather_option_list_vote(vote_d, old_d, new_d):
    """
    Collect vote for an OptionListButton.

    vote_d: dict
        {issue: {Identity: bool}}
        Receive vote to be used by Maya.

    old_d: dict or None
        the previous value

    new_d: dict or None
        the incoming value
    """
    if not new_d:
        # Init phase.
        return

    else:
        new_switch = new_d[de.SWITCH]
    if new_switch:
        new_option_k, sub_new_d = get_option_list_choice(new_d)
        ballot_d = get_vote_d(new_option_k)

        if not old_d:
            sub_old_d = old_option_k = None
            old_switch = 0

        else:
            old_option_k, sub_old_d = get_option_list_choice(old_d)
            old_switch = old_d[de.SWITCH]
            if new_option_k != old_option_k:
                sub_old_d = None

        is_switch = old_switch != new_switch

        if is_switch:
            gather_ballot_vote(vote_d, ballot_d)

        elif old_option_k != new_option_k:
            gather_ballot_vote(vote_d, ballot_d)
        else:
            gather_vote(vote_d, ballot_d, sub_old_d, sub_new_d)


def gather_ballot_vote(vote_d, ballot_d):
    """
    Collect vote from the default ballot dict.

    vote_d: dict
        Use to collect vote.

    ballot_d: dict
        Is the default vote for a Preset.
    """
    for i, a in ballot_d.items():
        if isinstance(a, dict):
            if i not in vote_d:
                vote_d[i] = {}
            gather_ballot_vote(vote_d[i], a)
        else:
            accept_vote(vote_d, i, a, True)


def set_relief(g, a):
    """
    Set the relief of a Switchable based on its Switch value.

    g: Switchable
    a: int
        0 or 1; Switch value
    """
    if a:
        # Switch is on.
        g.widget.set_relief(gtk.RELIEF_NORMAL)
    elif a == 0:
        # Switch is off.
        g.widget.set_relief(gtk.RELIEF_NONE)


class ValueButton(ProcessButton):
    """Has an attached value."""
    has_table_label = False

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        self.tip_type = None
        self.tooltip_text = ""
        d[df.TEXT] = make_dialog_button_text(d[df.KEY])

        if df.ROW_KEY not in d:
            d[df.ROW_KEY] = None

        d[df.RELAY].insert(0, self.on_value_button_action)
        ProcessButton.__init__(self, **d)
        self.widget.set_use_underline(False)

    def _update_tooltip(self, a):
        """
        Set the ValueButton's tooltip.

        a: value
            Use to make tooltip.
        """
        if a is not None:
            self.tooltip_text = create_tooltip(self.key, a, "", 0)
            self.set_tooltip_text(self.tooltip_text)

    def get_ui(self):
        """
        Retrieve the value of the Button.

        Return: dict
            Widget stored value.
        """
        return self.any_group.get_sub_widget_a(self.row_key, self.key)

    def load_a(self, a):
        """
        Set the value of the Widget's stored value.
        Override Voter's function.

        a: value
            Give to Widget.
        """
        self.set_ui(a)

    def on_value_button_action(self, _):
        """
        Respond to a Button click. Open a Window.

        _: ValueButton
            activated

        Return: True
            Tell GTK that the signal is processed.
        """
        if self.dialog:
            self.roller_win.bring_dialog(self)
        return True


class Switchable:
    """Has a popup menu with a Throw Switch menu item."""

    def __init__(self, button):
        """
        button: GTK Button
            Receive a Throw Switch menu.
        """
        # Add popup menu.
        # Reference
        # 'stackoverflow.com/questions/6616270/
        # right-click-menu-context-menu-using-pygtk'
        self.menu = gtk.Menu()
        self.menu_item = gtk.MenuItem("Throw Switch")

        self.menu_item.connect('activate', self.on_throw_switch)
        self.menu.append(self.menu_item)
        self.menu_item.show()
        self.menu.show()
        button.connect('button_release_event', self.on_switchable_clicked)

    def on_switchable_clicked(self, _, event):
        """
        React to a mouse button click on the button. If the
        button is right-clicked, create a popup menu.

        _: self
        event: gtk.gdk.Event
        Return: None
            Tell GTK to continue processing the event.
        """
        def _popup():
            # GTK right-mouse button enum, '3'
            if event.button == 3:
                self.menu.popup(None, None, None, event.button, event.time)

        d = self.get_a()
        a = d.get(de.SWITCH)

        if a is not None:
            _popup()
        else:
            a = d.get(de.SHADOW_SWITCH)
            if a is not None:
                _popup()

    def on_throw_switch(self, *_):
        """
        Respond to a throw switch request from the right-click popup menu.

        _: tuple
            (sender, signal)

        Return: None
            Tell GTK to continue processing the event.
        """
        def _flip():
            Ring.add(self.any_group, si.GROUP_CHANGE, None)
            Ring.plug(si.UI_CHANGE, self)

        d = self.get_ui()
        a = d.get(de.SWITCH)

        if a is not None:
            d[de.SWITCH] = int(not a)

            self.load_a(d)
            _flip()
        else:
            b = d.get(de.SHADOW_SWITCH)
            if b:
                a = d[de.SHADOW_SWITCH][de.SWITCH]
                d[de.SHADOW_SWITCH][de.SWITCH] = int(not a)

                self.load_a(d)
                _flip()

    def set_relief(self, d):
        """
        If the Button's value is off, change the Button's relief to none.
        Otherwise, keep the Button's relief at normal.

        d: dict
            {Widget key: Widget value}
        """
        # There is an init state where SWITCH is None.
        set_relief(self, d.get(de.SWITCH))


class OptionButton(ValueButton, Switchable):
    """
    Open a Preset editor dialog. Handle Preset value change.
    Has a Preset tooltip and a Preset value.
    """

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        ValueButton.__init__(self, **d)
        Switchable.__init__(self, self.button)
        self._default_ballot_d = get_vote_d(self.key)

    def set_ui(self, a):
        """
        Override the base class, so that the ValueButton's Label
        and tooltip can be modified. Compare value for change.

        a: dict
            incoming Button value

        Return: dict
            OptionButton value
        """
        if not a:
            a = get_default_d(self.key)

        # A Dialog Button is not main.
        if self.roller_win.is_main:
            vote_q = [{}, {}]
            p = self.any_group.get_view_a

            for i1 in (0, 1):
                gather_vote(
                    vote_q[i1],
                    self._default_ballot_d,
                    p(i1, self.key, row_key=self.row_key),
                    a
                )
            self.any_group.update_sub_g(self.row_key, self.key, vote_q)

        self._update_tooltip(a)
        self.any_group.set_sub_widget_a(self.row_key, self.key, a)
        self.set_relief(a)
        return a


class HeatButton(ValueButton):
    """Customize the 'set_ui' function of ValueButton."""

    def __init__(self, **d):
        self._make_tooltip = d[df.TIP_P]
        ValueButton.__init__(self, **d)

    def set_ui(self, a):
        """
        a: dict or None
            Is the Button's value.

        i: int or None
            Is an index for Plan, Work, or both.
        """
        if a is None:
            a = get_default_d(de.HEAT)

        self.tooltip_text = self._make_tooltip(a)

        self.set_tooltip_text(self.tooltip_text)
        self.any_group.set_sub_widget_a(self.row_key, self.key, a)
        self.any_group.changed(1)
        Ring.plug(si.HEAT_CHANGE, a)

        if a:
            self.widget.set_relief(gtk.RELIEF_NORMAL)

        else:
            self.widget.set_relief(gtk.RELIEF_NONE)
        return a


class OptionListButton(ValueButton, Switchable):
    """
    Activate a Style or Frame option chooser. Compares the OptionList choice.
    """

    def __init__(self, **d):
        ValueButton.__init__(self, **d)
        Switchable.__init__(self, self.button)

    def get_a(self):
        """
        Fetch the value of the Widget stored in the AnyGroup.

        Return: value
            Widget's
        """
        return self.any_group.get_sub_widget_a(self.row_key, self.key)

    def set_ui(self, d):
        """
        a: dict
            Is the Button's value.

        Return: dict
            the Button's value
        """
        if not d:
            d = get_default_d(self.key)

        if self.roller_win.is_main:
            vote_q = [{}, {}]
            p = self.any_group.get_view_a

            for i in (0, 1):
                if d and not d[de.SWITCH]:
                    pass
                else:
                    a = p(i, self.key, row_key=self.row_key)
                    gather_option_list_vote(vote_q[i], a, d)
            self.any_group.update_sub_g(self.row_key, self.key, vote_q)

        self._update_tooltip(d)
        self.any_group.set_sub_widget_a(self.row_key, self.key, d)
        self.set_relief(d)
        return d


class ShadowButton(OptionButton):
    """Has its own 'set_relief' function."""

    def __init__(self, **d):
        OptionButton.__init__(self, **d)

    def set_ui(self, d):
        """Override the OptionButton's function."""
        d = super(ShadowButton, self).set_ui(d)
        a = d.get(de.SHADOW_SWITCH, 0)

        if a:
            a = a[de.SWITCH]

        set_relief(self, a)
        return d


class StringButton(ValueButton):
    """Has a string value."""

    def __init__(self, **d):
        ValueButton.__init__(self, **d)

    def set_ui(self, a):
        """
        Override the super class, so that the ValueButton's Label
        and tooltip can be modified. Compare value for change.

        a: string
            Is the Button's value.

        Return: string
            the Button's value
        """
        if not isinstance(a, basestring):     # noqa
            a = ""

        if self.roller_win.is_main:
            p = self.any_group.get_view_a
            for i1 in (0, 1):
                b = p(i1, self.key, row_key=self.row_key)
                self.any_group.cast_vote(
                    i1, self.key, self.issue, a != b
                )

        if a:
            self.tooltip_text = " {} ".format(a)
            self.set_tooltip_text(self.tooltip_text)

        self.any_group.set_sub_widget_a(self.row_key, self.key, a)
        return a


class ListButton(StringButton):
    """
    Has a function to get a list of choices. Is coupled with RWChoice Window.
    """

    def __init__(self, **d):
        StringButton.__init__(self, **d)
        self.latch(self.any_group, (si.RANDOMIZE, self.randomize))

    def get_list(self):
        """
        Fetch a list that is the source of the Button's value.

        Return: list
            of string
        """
        key = self.key

        if 'pattern' in key.lower():
            key = de.PATTERN

        return {
            de.BRUSH: Cat.brush_list,
            de.FONT: Cat.font_list,
            de.GRADIENT: Cat.gradient_list,
            de.PATTERN: Cat.pattern_list
        }[key]

    def randomize(self, *_):
        """Randomize the value of the Button."""
        self.load_a(choice(self.get_list()))
