#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_identity import Identity as de
from roller_model_goo import Goo
from roller_polygon import calc_pin_xy, make_coord_list


def calc_grid_rect(model, o):
    """
    Calculate a grid of rectangular shaped cell.

    Calculate a Model's 'cell' rectangle,
    'merge' rectangle, and 'form' polygon.

    model: Model
    o: One
        Has translated Cell/Type Preset option.

    Return: dict
        {value: [bool, bool]}
        {cell key: [Plan vote change, Work vote change]}
    """
    vote_d = {}
    did_cell = model.past.did_cell
    row, column = model.grid
    goo_d = model.goo_d
    x, y, canvas_w, canvas_h = model.canvas_pocket.rect

    if o.grid_type == de.CELL_SIZE:
        # Correct cell size overflow.
        w = min(canvas_w, o.column_width)
        h = min(canvas_h, o.row_height)
        s = w * column, h * row
        x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

    elif o.grid_type == de.SHAPE_COUNT:
        w = canvas_w / column
        h = canvas_h / row
        w = min(w, h)
        s = w * column, w * row
        w, h = w, w
        x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

    else:
        w = canvas_w / column
        h = canvas_h / row

    # [intersect coordinate, ...]
    q_x = make_coord_list(canvas_w, column + 1, x, span=w)
    q_y = make_coord_list(canvas_h, row + 1, y, span=h)

    for r in range(row):
        for c in range(column):
            r_c = r, c
            y, y1 = q_y[r], q_y[r + 1]
            x, x1 = q_x[c], q_x[c + 1]
            a = goo_d[r_c] = Goo(r_c)

            # Prevent round to zero with max 1.
            b = a.cell.rect = x, y, max(1., x1 - x), max(1., y1 - y)

            a.merged.rect = b
            a.form = x, y, x1, y, x1, y1, x, y1
            vote_d[r_c] = did_cell(r_c)
    return vote_d
