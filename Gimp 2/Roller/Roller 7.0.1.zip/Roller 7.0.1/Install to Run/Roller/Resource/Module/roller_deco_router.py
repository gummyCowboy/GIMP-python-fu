#!/usr/bin/env python
# -*- coding: utf-8 -*-
# from gimpfu import pdb   # type: ignore
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_deco_output import exit_deck_type, exit_one_type, init_facial_type


def create_facial_main(maya, d, output):
    """
    Create main Face or Facing output.

    maya: Maya
        deco-branch

    d: dict
        deco-branch Preset

    output: function
        Produce output.

    Return: layer or None
        facial material
    """
    j = Run.j
    n = d[de.TYPE]
    arg, p = init_facial_type(
        n, j, maya, maya.group, d, maya.get_light(), True
    )

    for k in maya.main_q:
        maya.k = k
        output(j, maya, d, arg, p)

    if n == de.COLOR:
        # layer index, '0'
        return exit_one_type(arg[0])
    return exit_deck_type(n, *arg)


def create_facial_per(maya, d, output):
    """
    Make deco for Face or Facing Per.

    maya: Maya
        deco-branch

    d: dict
        deco-branch Preset

    output: function
        Produce output.

    Return: layer or None
        facial material
    """
    j = Run.j
    n = d[de.TYPE]
    arg, p = init_facial_type(
        n, j, maya, maya.group, d, maya.get_light(), True
    )

    output(j, maya, d, arg, p)

    if n == de.COLOR:
        # layer index, '0'
        return exit_one_type(arg[0])
    return exit_deck_type(n, *arg)
