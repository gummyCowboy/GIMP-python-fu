#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (      # type: ignore
    CHANNEL_OP_ADD, CLIP_TO_IMAGE, LAYER_MODE_DIFFERENCE, pdb
)
from roller_container import Run
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_gimp_context import prep_replace_color_default
from roller_gimp_image import add_layer_above, add_wip_layer
from roller_gimp_item import get_item_size
from roller_gimp_layer import (
    color_layer, color_selection, get_layer_offsets, get_mean_color
)
from roller_gimp_selection import select_color, select_rect
from roller_maya_sub_accent import SubAccent
from roller_preset import do_rotated_layer
from roller_utility import make_rect_table


def do_color_grid(d, group):
    """
    Draw a Color Grid.

    d: dict
        Color Grid Preset

    group: layer
        Parent the output.

    Return: layer
        Color Grid material
    """
    return do_rotated_layer(d, draw_color_grid, group, 0)


def draw_color_grid(z, d):
    """
    Draw a black and white checkerboard.

    z: layer
        Replace with the checkerboard layer.

    d: dict
        Color Grid Preset

    Return: layer
        Has the checkerboard pattern.
    """
    j = z.image
    x, y = get_layer_offsets(z)
    w, h = get_item_size(z)
    row, column = int(d[de.ROW]), int(d[de.COLUMN])
    grid = make_rect_table((x, y, w, h), row, column)
    z1 = add_layer_above(z, "V")

    # Prep layers for selections.
    for i in (z, z1):
        color_layer(i, (255, 255, 255))

    pdb.gimp_selection_none(j)

    # Draw horizontal stripes.
    for r in range(0, row, 2):
        select_rect(
            j, .0, grid[r][0].y, w, grid[r][0].h, option=CHANNEL_OP_ADD
        )

    color_selection(z, (0, 0, 0))
    pdb.gimp_selection_none(j)

    # Draw vertical stripes.
    z1.mode = LAYER_MODE_DIFFERENCE

    # row, 'a'
    a = grid[0]

    for c in range(0, column, 2):
        select_rect(j, a[c].x, .0, a[c].w, h, option=CHANNEL_OP_ADD)

    color_selection(z1, (0, 0, 0))
    return pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)


def do_matter(maya):
    """
    Create a matter layer.

    maya: ColorGrid
    Return: layer
        Color Grid material
    """
    j = Run.j
    d = maya.value_d

    prep_replace_color_default()

    # black and white checkerboard layer, 'z'
    z = do_color_grid(d, maya.group)

    # result layer, 'z1'
    z1 = add_wip_layer("Colors", maya.group)

    # Select by color and then fill.
    select_color(z, (255, 255, 255))

    is_mean_color = d[de.MEAN_COLOR]
    q = get_mean_color(maya.bg_z) if is_mean_color else d[de.COLOR_2A][1]

    color_selection(z1, q)
    select_color(z, (0, 0, 0))

    q = get_mean_color(maya.bg_z) if is_mean_color else d[de.COLOR_2A][0]

    color_selection(z1, q)
    pdb.gimp_image_remove_layer(j, z)
    return maya.finish(z1, d[rk.BRW])


class ColorGrid(SubAccent):
    """Create Accent output."""
    kind = de.COLOR_GRID

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, False, is_old)

    def do(self, *arg):
        d = self.any_group.get_value_d()
        self.is_dependent = d[de.MEAN_COLOR]
        return super(ColorGrid, self).do(*arg)
