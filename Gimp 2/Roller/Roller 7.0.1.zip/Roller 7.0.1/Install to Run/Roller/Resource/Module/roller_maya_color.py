#!/usr/bin/env python
# -*- coding: utf-8 -*-
# noinspection PyUnresolvedReferences
from roller_constant_identity import Identity as de
from roller_gimp_image import add_wip_layer, check_matter
from roller_gimp_layer import color_selection, not_empty, select_layer_rect
from roller_gimp_mode import get_mode
from roller_maya_build import SubBuild
from roller_maya_layer import check_mix_basic
from roller_gimp_mask import mask_from_maya


def do_matter(maya):
    """
    Make a Color matter layer.

    Return: layer or None
        Color material
    """
    d = maya.value_d
    super_ = maya.super_maya
    z = super_.matter
    if not_empty(z):
        z = add_wip_layer(de.COLOR, super_.group, super_.get_light())

        select_layer_rect(z)
        color_selection(z, d[de.COLOR_1])

        z.mode = get_mode(d)
        z.opacity = d[de.OPACITY]
        return z


class Color(SubBuild):
    """Manage Color layer output for a Color Preset."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (check_matter, 'matter'), (check_mix_basic, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            This Maya's 'matter' layer alpha creates an output mask.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, do_matter)

    def do(self, d, is_change, is_mask):
        """
        Manage layer output during a view run.

        d: dict or None
            Color Preset
            Maybe None if 'go' is False.

        is_change: bool
            Is True if the source layer for
            the Color material has matter change.

        is_mask: bool
            Is True if the source layer's mask changed.

        Return: bool
            Is True if the Color layer changed.
        """
        self.value_d = d
        self.go = d[de.SWITCH]
        m = False

        if self.go:
            self.is_matter |= is_change
            m = self.is_matter or is_mask

        self.realize()

        if self.matter:
            if m:
                mask_from_maya(self.super_maya, self.matter)

        self.reset_issue()
        return m
