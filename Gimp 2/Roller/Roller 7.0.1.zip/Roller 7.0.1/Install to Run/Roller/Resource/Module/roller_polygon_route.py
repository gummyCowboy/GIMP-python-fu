#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Shape as sh
from roller_constant_identity import Identity as de
from roller_polygon_box_hex import calc_box_hex
from roller_polygon_box_hex_trunc import calc_box_hex_trunc
from roller_polygon_circle import calc_grid_circle
from roller_polygon_miter_square import calc_miter_square
from roller_polygon_ellipse_horz import calc_ellipse_horz
from roller_polygon_ellipse_vert import calc_ellipse_vert
from roller_polygon_hexagon import calc_hexagon
from roller_polygon_hexagon_truncated import calc_hex_trunc
from roller_polygon_octagon import calc_octagon
from roller_polygon_octagon_double import calc_octagon_double
from roller_polygon_parallelogram import calc_parallelogram
from roller_polygon_parallelogram_alt import calc_parallelogram_alt
from roller_polygon_rect import calc_grid_rect
from roller_polygon_triangle_horz import calc_triangle_horz
from roller_polygon_triangle_vert import calc_triangle_vert

# Convert a shape descriptor to a cell grid calculator.
# {shape descriptor string: polygon calculator function}
CALC_POLYGON = {
    sh.BOX_HORIZONTAL: calc_box_hex_trunc,
    sh.BOX_HORIZONTAL_SHEAR: calc_box_hex_trunc,
    sh.BOX_VERTICAL: calc_box_hex,
    sh.BOX_VERTICAL_SHEAR: calc_box_hex,
    de.CIRCLE_HORIZONTAL: calc_grid_circle,
    de.CIRCLE_VERTICAL: calc_grid_circle,
    de.DIAMOND: calc_miter_square,
    de.ELLIPSE_HORIZONTAL: calc_ellipse_horz,
    de.ELLIPSE_VERTICAL: calc_ellipse_vert,
    de.HEXAGON: calc_hexagon,
    de.HEXAGON_SHEAR: calc_hexagon,
    de.HEXAGON_TRUNCATED: calc_hex_trunc,
    de.HEXAGON_TRUNCATED_SHEAR: calc_hex_trunc,
    de.MITER_SQUARE: calc_miter_square,
    de.OCTAGON_DOUBLE: calc_octagon_double,
    de.OCTAGON_DOUBLE_SHEAR: calc_octagon_double,
    de.OCTAGON_SHEAR: calc_octagon,
    de.OCTAGON: calc_octagon,
    de.OCTAGON_ON_ITS_SIDE: calc_octagon,
    de.OCTAGON_ON_ITS_SIDE_SHEAR: calc_octagon,
    de.PARALLELOGRAM_ALT_LEFT: calc_parallelogram_alt,
    de.PARALLELOGRAM_ALT_RIGHT: calc_parallelogram_alt,
    de.PARALLELOGRAM_LEFT: calc_parallelogram,
    de.PARALLELOGRAM_RIGHT: calc_parallelogram,
    de.RECTANGLE: calc_grid_rect,
    de.SQUARE: calc_grid_rect,
    de.TRIANGLE_DOWN_SHEAR: calc_triangle_vert,
    de.TRIANGLE_DOWN_REGULAR: calc_triangle_vert,
    de.TRIANGLE_UP_SHEAR: calc_triangle_vert,
    de.TRIANGLE_UP_REGULAR: calc_triangle_vert,
    de.TRIANGLE_LEFT_SHEAR: calc_triangle_horz,
    de.TRIANGLE_LEFT_REGULAR: calc_triangle_horz,
    de.TRIANGLE_RIGHT_SHEAR: calc_triangle_horz,
    de.TRIANGLE_RIGHT_REGULAR: calc_triangle_horz
}
