#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Shape as sh
from roller_constant_identity import Identity as de
from roller_polygon import get_v_ellipse_rect
from roller_polygon_hexagon_truncated import calc_hex_trunc


def calc_ellipse_vert(model, o):
    """
    Calculate a grid of ellipse shaped cells,
    vertically aligned, and double-spaced.

    Calculate 'cell' and 'merge' rectangles and
    a 'form' polygon for each cell.

    model: Model
    o: One
        Has attribute made from a translated Cell/Type Preset.

    Return: dict
        {value: [bool, bool]}
        {cell key: [Plan vote change, Work vote change]}
    """
    goo_d = model.goo_d
    vote_d = calc_hex_trunc(
        model, o, ellipse_space=sh.ELLIPSE_RATIO
    )

    if o.grid_type != de.CELL_SIZE:
        # by count
        did_cell = model.past.did_cell

        for r_c in model.cell_q:
            a = goo_d[r_c]

            # The ellipse rect is smaller than the hexagon rect.
            a.form = a.cell.rect = a.merged.rect = get_v_ellipse_rect(
                a.cell
            )
            vote_d[r_c] = did_cell(r_c)

    for r_c in model.cell_q:
        a = goo_d[r_c]
        a.form = a.cell.rect
    return vote_d
