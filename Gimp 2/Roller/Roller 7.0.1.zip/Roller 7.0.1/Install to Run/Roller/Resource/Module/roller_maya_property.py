#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_any_group import ManyGroup
from roller_constant import Issue as vo
from roller_maya import Maya


class Property(ManyGroup):
    """Create a Widget group and assign view-type runner."""
    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)


class Chi(Maya):
    """Factor Plan and Work."""
    issue_q = ()
    vote_type = vo.MAIN

    def __init__(self, any_group, view_i):
        Maya.__init__(self, any_group, view_i, (), vo.NO_VOTE)

    def do(self):
        return


class Plan(Chi):
    """Property has no layer output."""
    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0)


class Work(Chi):
    """Property has no layer output."""
    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1)
