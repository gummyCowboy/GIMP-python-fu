#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (  # type: ignore
    CLIP_TO_IMAGE, CHANNEL_OP_ADD, LAYER_MODE_DARKEN_ONLY, pdb
)
from math import atan2, cos, sin, radians
from random import randint, uniform
from roller_constant import Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gegl import noise_rgb
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import (
    add_layer, check_matter, make_group_layer, make_group_sub
)
from roller_gimp_item import get_item_size
from roller_gimp_layer import (
    blur_selection,
    clear_inverse_selection,
    clone_layer,
    color_selection,
    do_curves,
    invert_selection,
    select_layer,
    select_layer_iffy,
    verify_layer
)
from roller_gimp_selection import (
    get_select_coord, select_channel, select_polygon
)
from roller_image_change import ref_get_image
from roller_maya_add import Add
from roller_maya_build import Build
from roller_maya_bulb import Bulb
from roller_many_rect import Rect
from roller_preset import combine_seed


def calc_angle_shift(d):
    """
    Randomize the angle-shift amount.

    d: dict
        Tape Preset
        {Identity: value}

    Return: float
        angle shift
    """
    f = d[de.ANGLE_SHIFT]
    return uniform(radians(-f), radians(f))


def calc_rotated_bounds(maya):
    """
    Calculate the rotated bounds of the
    work-in-progress image in its original size.

    Calculate the transform amount for the x, y vectors.
    The goal of the transform is to calculate
    the corner points of the a placed image.

    The function only works when the original image size ratio
    is the same as the cell image's size ratio. The Locked Resize
    Method will leave the ratio the same, but the other Resize
    Methods typically modify this ratio.

    maya: Tape
    """
    q = Bag.corners
    j = ref_get_image(maya.any_group, Bag.k, 0)
    if j:
        w, h = get_item_size(j)
        f = Bag.angle

        # center
        w, h = w / 2., h / 2.

        radius = ((w**2.) + (h**2.))**.5

        for i in range(4):
            if not i:
                x, y = -w, h

            elif i == 1:
                x, y = w, h

            elif i == 2:
                x, y = w, -h

            else:
                x, y = -w, -h

            x, y = calc_point(.0, .0, atan2(x, y) + f, radius)
            q.append((x, y))

        q_x = [i[0] for i in q]
        q_y = [i[1] for i in q]
        u = min(q_x), min(q_y)
        u1 = max(q_x), max(q_y)
        u = abs(u[0] - u1[0]), abs(u[1] - u1[1])
        Bag.transform = Bag.rect.w / u[0], Bag.rect.h / u[1]


def calc_point(x, y, angle, radius):
    """
    Return a point on a circle that intersects with at a
    vector starting from the center of the circle at a angle.

    x, y: float
        center point

    angle : float
        rotation angle in radians

    radius: float
        the radius of the circle in pixels

    Return: tuple
        (x, y) of float
        the point on the circle
    """
    x = (sin(angle) * radius) + x
    y = (cos(angle) * -radius) + y
    return round(x), round(y)


def calc_tape_length(d):
    """
    Calculate tape length.

    d: dict
        Has options.

    Return: float
        tape length
    """
    return max(
        1.,
        d[de.LENGTH] + randint(-d[de.LENGTH_SHIFT], d[de.LENGTH_SHIFT])
    )


def do_matter(maya):
    """
    Make a tape layer.

    maya: Tape
    Return: layer or None
        material
    """
    j = Run.j
    z = None
    parent = maya.group
    offset = maya.get_light()
    super_ = maya.cast

    set_fill_context_default()

    # Check to see if the caller is a grid, 'main_q'.
    if hasattr(super_, 'main_q'):
        group = make_group_layer(j, parent, offset, "Material")
        model = maya.model

        for k in super_.main_q:
            select_channel(j, model.get_image_sc(k))
            if not pdb.gimp_selection_is_empty(j):
                do_selection(maya, add_layer(j, group, offset, "Base"), k)
        z = pdb.gimp_image_merge_layer_group(j, group)

    else:
        select_layer_iffy(j, maya.cast.matter)
        if not pdb.gimp_selection_is_empty(j):
            z = add_layer(j, parent, offset, "Material")
            z = do_selection(maya, z, maya.cast.k)

    z = verify_layer(z)

    if z:
        z.opacity = 34.
        z.mode = LAYER_MODE_DARKEN_ONLY
    return z


def do_selection(maya, z, k):
    """
    Draw tape. Select the image material prior to calling.

    maya: Tape
    k: tuple or None
        (row, column)

    Return: layer or None
        material
    """
    j = Run.j
    a = Bag(maya, k, *get_select_coord(j))

    if a.angle:
        calc_rotated_bounds(maya)

    b = a.rect

    # noise layer, 'z1'
    z1 = clone_layer(z)
    z1.opacity = 50.

    combine_seed(a.d)
    pdb.gimp_selection_none(j)
    noise_rgb(
        z1,
        uniform(.001, .04),
        uniform(.001, .04),
        uniform(.001, .04),
        1.,                             # alpha
        int(a.d[de.RANDOM_SEED] + Globe.seed)
    )
    select_topleft(b.x, b.y)
    select_top_right(b.x + b.w, b.y)
    select_bottom_left(b.x, b.y + b.h)
    select_bottom_right(b.x + b.w, b.y + b.h)
    color_selection(z, (255, 255, 255))
    clear_inverse_selection(z1)

    for i in range(2):
        pdb.plug_in_shift(j, z, 1, 0)
        pdb.plug_in_shift(j, z, 1, 1)

    blur_selection(z, 2.)

    z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

    # Darken the edge.
    select_layer(z)
    pdb.gimp_selection_shrink(j, 1)
    invert_selection(j)
    do_curves(z, (.0, .0392, 1., .3137))
    return z


def get_corner_point(x, y, corner_i):
    """
    x, y: int
        corner point

    corner_i: int
        index to corner point

    Return: tuple
        of int
        corner point
    """
    def _shift():
        """
        Randomize corner-shift amount.

        Return: int
            corner shift
        """
        _a = a.d[de.CORNER_SHIFT]
        return randint(-_a, _a)

    a = Bag

    if a.angle:
        x1, y1 = a.corners[corner_i]
        x1 *= a.transform[0]
        y1 *= a.transform[1]
        x = x1 + a.center[0]
        y = y1 + a.center[1]

    x += _shift()
    y += _shift()
    return x, y


def make_group_tape(maya):
    """
    Make a Wrap group layer. Is a
    sub-group of the super maya's group layer.

    maya: Maya
    Return: group layer
        Wrap parent
    """
    return make_group_sub(maya, "Tape")


def select_tape_rect(d, angle, x, y, w):
    """
    Define and select a tape rectangle.

    d: dict
        Tape Preset
        {Identity: value}

    x, y: int
        start point

    w: int
        length of tape
    """
    w1 = d[de.WIDTH]

    # 90 degrees in radian, 1.5708
    x1, y1 = calc_point(x, y, angle - 1.5708, w1)

    # 180 degrees in radian, 3.14159
    x2, y2 = calc_point(x1, y1, angle - 3.14159, w)

    # 270 degrees in radian, 4.71239
    x3, y3 = calc_point(x2, y2, angle - 4.71239, w1)

    select_polygon(
        Run.j,
        (x, y, x1, y1, x2, y2, x3, y3),
        option=CHANNEL_OP_ADD
    )


def select_bottom_left(x, y):
    """
    Make a selection for the bottom-left corner.

    x, y: float
        corner point
    """
    d = Bag.d

    # 135 degrees in radian, 2.35619
    angle = 2.35619 + calc_angle_shift(d) + Bag.angle

    x, y = get_corner_point(x, y, 3)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(d, angle, x1, y1, w)


def select_bottom_right(x, y):
    """
    Make a selection for the bottom-right corner.

    x, y: int
        corner point
    """
    d = Bag.d

    # 45 degrees in radian, .785398
    angle = .785398 + calc_angle_shift(d) + Bag.angle

    x, y = get_corner_point(x, y, 2)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(d, angle, x1, y1, w)


def select_topleft(x, y):
    """
    Make a selection for the topleft corner.

    x, y: int
        corner point
    """
    d = Bag.d

    # 225 degrees in radian, 3.92699
    angle = 3.92699 + calc_angle_shift(d) + Bag.angle

    x, y = get_corner_point(x, y, 0)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(d, angle, x1, y1, w)


def select_top_right(x, y):
    """
    Make a selection for the top-right corner.

    x, y: float
        center point
    """
    d = Bag.d

    # 315 degrees in radian, 5.49779
    angle = 5.49779 + calc_angle_shift(d) + Bag.angle

    x, y = get_corner_point(x, y, 1)
    w = calc_tape_length(d)
    x1, y1 = calc_point(x, y, angle, w / 2.)
    select_tape_rect(d, angle, x1, y1, w)


class Tape(Build):
    """Simulate a tape holding an image in place."""
    is_inward = is_seeded = True
    issue_q = 'matter', 'mode', 'opacity'
    kind = material = de.TAPE
    put = (make_group_tape, 'group'), (check_matter, 'matter')
    shade_row = rk.RW1

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            enclosing type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        Build.__init__(
            self,
            any_group,
            super_maya,
            k_path + (rk.BRW, de.WRAP_TA),
            do_matter
        )
        self.sub_maya[sm.ADD] = Add(any_group, self, k_path + (rk.BRW, de.ADD))
        self.sub_maya[sm.BULB] = Bulb(any_group, self, de.TAPE)

    def do(self, d, is_change):
        """
        Produce and modify layer output.

        d: dict
            Tape Preset
            {Identity: value}

        is_change: bool
            Is the state of the super-maya's matter and/or mask.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(
                d[rk.BRW][de.ADD],
                self.is_matter,
                self.is_matter,
                Run.is_back,
                self.group
            )
            self.sub_maya[sm.BULB].do(self.is_matter)

        else:
            self.die()
        self.reset_issue()


class Bag:
    """Is a container for making Tape material."""
    angle = .0
    center = .0, .0
    corners = []
    d = {}
    k = ""
    rect = None
    transform = ()

    def __init__(self, maya, k, x, y, x1, y1):
        """
        maya: Maya
        k: tuple or None
            cell index for WIP image

        x, y: float
            topleft corner of the image selection

        x1, y1: float
            bottom-right corner of the image selection
        """
        # Is a sequence of four x, y coordinate tuple.
        # topleft, top-right,bottom-right, bottom-left
        Bag.corners = []

        # Image selection rectangle, 'rect'
        w = x1 - x
        h = y1 - y
        Bag.rect = Rect(x, y, w, h)

        # Image selection center point, 'center'
        Bag.center = x + w / 2., y + h / 2.

        # image angle in the Image Preset
        Bag.angle = radians(maya.cast.value_d.get(de.ANGLE, .0))

        # float
        # Use when an image has rotation to transform its corner points.
        # Set to failure value, '1.'.
        Bag.transform = 1., 1.

        # dict
        # Tape Preset
        Bag.d = maya.value_d[rk.BRW][de.WRAP_TA]

        # tuple or None
        # cell index
        # Is None for Canvas.
        Bag.k = k
