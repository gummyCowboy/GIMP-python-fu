#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (     # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_COLOR_ERASE,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_LCH_CHROMA,
    LAYER_MODE_LCH_HUE,
    LAYER_MODE_NORMAL,
    LAYER_MODE_OVERLAY,
    LAYER_MODE_SUBTRACT,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gimp_image import add_sub_maya_group, add_wip_layer
from roller_gimp_layer import clone_layer, color_layer_default
from roller_maya_sub_accent import SubAccent
from roller_wip import Wip

EDGE = "{} of {}"


def do_edge(z, mode, i, reps):
    """
    Shred the layer with the edge function and a layer mode.

    z: layer
        work-in-progress
        Is modified.

    mode: enum
        GIMP layer mode

    i: int
        repetition number

    reps: int
        number of repetitions

    Return: layer
        with modifications
    """
    j = z.image

    # amount, '1.'; no wrap, '0'; SOBEL, '0'
    pdb.plug_in_edge(j, z, 1., 0, 0)

    z.mode = mode
    z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
    return clone_layer(z, n=EDGE.format(str(i), str(reps)))


def do_matter(maya):
    """
    Make a material layer.

    maya: RockyLanding
    Return: layer
        'matter'
    """
    j = Run.j
    d = maya.value_d
    group = add_sub_maya_group(maya)
    z = add_wip_layer("Rocky Landing WIP", group)
    reps = int(d[de.BLEND])
    reps1 = reps * 2 + 4

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, int(d[de.RANDOM_SEED] + Globe.seed), 3.)

    z1 = clone_layer(z, n=EDGE.format("1", reps1))

    color_layer_default(z, (0, 0, 0))

    z = clone_layer(z1, n=EDGE.format("2", reps1))
    z = do_edge(z, LAYER_MODE_SUBTRACT, 3, reps1)
    z = do_edge(z, LAYER_MODE_LCH_HUE, 4, reps1)
    edge = 5

    for i in range(reps):
        z = do_edge(z, LAYER_MODE_COLOR_ERASE, edge, reps1)
        z = do_edge(z, LAYER_MODE_LCH_CHROMA, edge + 1, reps1)
        edge += 2

    z.mode = LAYER_MODE_GRAIN_EXTRACT
    z1 = clone_layer(z, n="Overlay")

    # elevation, '30.'; depth, '1'; bump map, '1'
    pdb.plug_in_emboss(j, z1, Globe.azimuth, 30., 1, 1)

    z1.mode = LAYER_MODE_OVERLAY

    # no linear, '0'
    pdb.gimp_drawable_invert(z1, 0)

    z = clone_layer(z1, n="Despeckle")

    pdb.plug_in_despeckle(j, z1, 1, 1, 200, 255)
    pdb.gimp_layer_set_offsets(z, int(Wip.x), int(Wip.y) + 2)
    pdb.plug_in_sobel(j, z, 1, 0, 0)

    z.opacity = 83.
    z1.mode = LAYER_MODE_NORMAL
    z1.opacity = 33.

    pdb.gimp_image_reorder_item(j, z1, group, 3)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, group), d[rk.BRW]
    )


class RockyLanding(SubAccent):
    """Create Accent output."""
    kind = de.ROCKY_LANDING

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)
