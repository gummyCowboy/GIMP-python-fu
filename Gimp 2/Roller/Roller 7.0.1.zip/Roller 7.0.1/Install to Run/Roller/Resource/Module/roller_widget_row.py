#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from random import randint
from roller_constant import Define as df
from roller_constant_identity import Identity as de
from roller_utility import random_rgb
from roller_widget import set_widget_attr
from roller_widget_color_button import RainbowColorButton
from roller_widget_button import Button
import gtk  # type: ignore

CROSS_OVER_SET = {df.SUB, df.TEXT, df.WIDGET}


class Row(gtk.Alignment):
    """
    Is a GTK HBox container for multiple widgets that share a Table Widget row.
    """
    change_signal = None

    def __init__(self, **d):
        """
        Create an HBox.

        d: dict
            Initialize the Row.
        """
        super(gtk.Alignment, self).__init__()

        # The 'label' reference is a Label Widget displayed
        # in the Table container and is created by the Table.
        self.box = self.label = self.label_box = None

        self.any_group = None

        # [Widget, ...], 'widget_q'
        self.widget_q = []

        # {Widget key: Widget}, 'widget_d'
        self.widget_d = OrderedDict()

        if df.KEY not in d:
            d[df.KEY] = None

        set_widget_attr(self, d)

        self.row_key = d[df.KEY]
        self.hbox = gtk.HBox()
        self.add(self.hbox)

    def hide(self):
        """Hide its Widget and Label."""
        self.box.hide()
        self.label_box.hide()

    def show(self):
        """Show its Widget and Label."""
        self.box.show()
        self.label_box.show()


class WidgetRow(Row):
    """
    Is a Row with an array of Widget. Access
    Widget through a 'widget_q' attribute.
    """
    has_table_label = False

    def __init__(self, **d):
        """
        Create an HBox occupied by an array of Widget.

        d: dict
            Has init values.
        """
        Row.__init__(self, **d)

        add_widget_q = []
        self.keys = []
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        padding = d.get(df.PADDING)
        d[df.ALIGN] = 0, 0, 1, 0
        d[df.ROW_KEY] = self.row_key
        d[df.ANY_GROUP] = self.any_group
        relay = d[df.RELAY][:]
        index_ = 0

        # iterable of option def, 'key_d'
        key_d = d[df.SUB]

        # circular or cross-over
        for g in CROSS_OVER_SET:
            if g in d:
                d.pop(g)

        for key, arg_d in key_d.items():
            arg_d.update(d)

            arg_d[df.KEY] = key
            is_not_random = key != de.RANDOM

            if key != de.RANDOM:
                self.keys.append(key)

            if index_ == 0:
                # Widget is on the left.
                arg_d[df.PADDING] = 2, 2, 0, 1

            elif index_ == len(key_d) - 1:
                # Widget is on the right.
                arg_d[df.PADDING] = 2, 2, 1, 0

            else:
                # Widget is in the middle.
                arg_d[df.PADDING] = 2, 2, 1, 1

            arg_d[df.RELAY] = relay[:]
            g = arg_d[df.WIDGET](**arg_d)

            if is_not_random:
                self.widget_q.append(g)
                self.widget_d[key] = g

            add_widget_q.append(g)
            index_ += 1

        if padding:
            self.set_padding(*padding)
        for g in add_widget_q:
            self.hbox.pack_start(g, expand=True)
            same_size.add_widget(g.widget)

    def get_g(self, k):
        """
        Return the value of a of a Row owned Widget by its key.

        k: string
            Widget key

        Return: Widget or None
        """
        return self.widget_d.get(k)

    def get_ui(self):
        """
        Collect the value of Row Widget.

        Return: dict
            {Widget key: Widget value}
        """
        return {k: g.get_ui() for k, g in self.widget_d.items()}

    def load_a(self, d):
        """
        Load Row Widget value.
        WidgetRow doesn't have a value of its own.

        d: dict or None
            {Widget key: Widget value}
        """
        if d:
            for k, a in d.items():
                g = self.widget_d.get(k)
                if g:
                    g.load_a(a)

    def update_visibility(self, hide_q):
        """
        Hide or show each Widget in the Row.

        hide_q: tuple
            (Identity, ...)
            to hide
        """
        for g in self.widget_q:
            g.hide() if g.key in hide_q else g.show()


class Rainbow(Row):
    """Is an GTK HBox with two or more ColorButtons."""
    has_table_label = True

    def __init__(self, **d):
        """
        d: dict
            Initialize the Rainbow.
        """
        Row.__init__(self, **d)

        self._has_alpha = d.get(df.HAS_ALPHA, False)
        d[df.ALIGN] = 0, 0, 1, 0
        d[df.GREATER_G] = self
        padding = d.get(df.PADDING)
        count = d[df.BUTTON_COUNT]
        self.issue = d[df.ISSUE]
        is_named_color = d.get(df.COLOR_NAME_LIST)
        d[df.KEY] = None
        d.pop(df.ISSUE)

        for i in range(count):
            if i == 0:
                d[df.PADDING] = 2, 2, 0, 1

            elif i == count - 1:
                d[df.PADDING] = 2, 2, 1, 0

            else:
                # Button in the middle
                d[df.PADDING] = 2, 2, 1, 1

            if is_named_color:
                d[df.COLOR_NAME] = d[df.COLOR_NAME_LIST][i]
            self.widget_q.append(RainbowColorButton(**d))

        if padding:
            self.set_padding(*padding)
        for g in self.widget_q:
            self.hbox.pack_start(g, expand=True)

    def get_ui(self):
        """
        Collect the values of the ColorButtons.

        Return: list
            [color values, ...]
        """
        return [g.get_ui() for g in self.widget_q]

    def load_a(self, q):
        """
        Load Row Widget value.
        WidgetRow doesn't have a value of its own.

        q: list
            [color, ...]
        """
        q = self.set_ui(q)
        self.any_group.set_widget_a(self.key, q)

    def randomize(self):
        """Randomize the values of the ColorButtons."""
        for g in self.widget_q:
            # RGB, 'q'
            q = random_rgb()

            if self._has_alpha:
                # RGBA, 'q'
                q += (randint(0, 255),)
            g.load_a(q)

    def set_ui(self, q):
        """
        Set the colors of the ColorButtons.

        q: iterable
            Has color values.
        """
        for i, a in enumerate(q):
            self.widget_q[i].set_ui(a)

        # plan and work render-type quantity, '2'
        for i in range(2):
            view_q = self.any_group.get_view_a(i, self.key)
            self.any_group.cast_vote(i, self.key, self.issue, q != view_q)
        return q

    def update_a(self):
        """A RainbowColorButton has changed. Update the AnyGroup."""
        q = self.get_ui()

        self.any_group.set_widget_a(self.key, q)

        # plan and work view-value quantity, '2'
        for i in range(2):
            view_q = self.any_group.get_view_a(i, self.key)
            self.any_group.cast_vote(i, self.key, self.issue, q != view_q)

    def update_visibility(self, color_count):
        """
        The number of visible ColorButtons is dependent on the color count.

        color_count: int
            the number of ColorButtons to show
        """
        for i, g in enumerate(self.widget_q):
            g.show() if i < color_count else g.hide()
        self.label.hide() if not color_count else self.label.show()


class SelectRow(WidgetRow):
    """
    Has two Buttons, Select All and Select
    None. Manipulate a list of CheckButton.
    """

    def __init__(self, widget_q, **d):
        self._widget_q = widget_q
        d[df.PADDING] = 0, 0, 4, 4
        d[df.RELAY] = d[df.RELAY][:]

        d[df.RELAY].insert(0, self.on_select_button)

        d[df.SUB] = OrderedDict([
            (de.SELECT_ALL, {
                df.NO_VOTE: True,
                df.KEY: None,
                df.TEXT: de.SELECT_ALL,
                df.WIDGET: Button
            }),
            (de.SELECT_NONE, {
                df.NO_VOTE: True,
                df.KEY: None,
                df.TEXT: de.SELECT_NONE,
                df.WIDGET: Button
            })
        ])
        WidgetRow.__init__(self, **d)

    def on_select_button(self, g):
        """
        Respond to Button action.

        g: Button
            Is responsible.
        """
        a = int(g.key == de.SELECT_ALL)
        for i in self._widget_q:
            i.set_ui(a)
