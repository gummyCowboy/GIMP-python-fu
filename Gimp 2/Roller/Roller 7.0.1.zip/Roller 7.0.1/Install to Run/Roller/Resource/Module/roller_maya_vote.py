#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Issue as vo
from roller_constant_identity import Identity as de
from roller_container import Run


def bag_vote(maya, d, k_path):
    """
    Extract vote from a Maya vote dict. Convert issue key
    found in a collected vote dict to Maya vote attribute.

    maya: Maya
        Receive issue vote.

    d: dict
        Has issue vote.

    k_path: tuple
        (Identity, ...)
        Locate Maya vote.
    """
    for k in k_path:
        if k in d:
            d = d[k]
        else:
            d = {}
            break

    # Identity, 'i'; sub-vote dict, 'a'
    for i, a in d.items():
        if i in maya.issue_q and isinstance(a, dict):
            n = 'is_' + i
            vote = None

            for b in a.values():
                if isinstance(b, bool):
                    if vote is None:
                        vote = b

                    else:
                        vote |= b
                    if vote:
                        break
            if vote is not None:
                setattr(maya, n, vote)
    take_great_vote(maya)


def get_sub_maya_vote(d, row_k, k):
    """
    From a vote dict, find a sub-maya vote dict.

    d: dict
        Has issue vote.

    row_k: string
        Is a Row key where the option is found.

    k: string
        Is an Identity with accumulated vote.

    Return: dict
        Is the sub-Maya vote dict.
    """
    if row_k:
        # nested
        a = d.get(row_k)
        if a:
            b = a.get(k)
            if b:
                return b
    return d.get(k, {})


def on_global(maya, arg, option_k):
    """
    Respond to a Global option change.

    maya: Maya
    arg: list
        [Plan vote, Work vote]

    option_k: string
        Identity
        Is responsible for the vote.
    """
    d = maya.great_vote_d

    # Find the Cell Maya and set its 'per' vote to True.
    # The 'per' issue is voted on when a Per Cell Maya
    # has change, or in this case, when there is Global change.
    chain = maya

    while chain:
        if 'per' in chain.issue_q:
            # Found the Cell Maya, 'chain'.
            if not chain.is_per:
                a = chain.any_group

                a.accept_vote(1, option_k, vo.PER, True)
                chain.take_vote(a.vote_q[1])
                break
        chain = chain.super_maya if hasattr(chain, 'super_maya') else None

    if vo.MATTER not in d:
        d[vo.MATTER] = {}

    d[vo.MATTER][option_k] = arg[maya.view_i]

    take_great_vote(maya)
    maya.any_group.changed(maya.view_i)


def take_background_vote(d):
    """
    Border, Fringe, and Plaque have background
    sensitive types. If the background has changed
    with these types, then vote for change for their
    cast layer.

    d: dict
        deco type Preset
        {Identity: value}

    Return: bool
        If true, then the matter layer has change.
    """
    if Run.is_back and d[de.TYPE] == de.MEAN_COLOR:
        return True
    return False


def take_great_vote(maya):
    """
    Set Maya issue from the great vote dict.

    maya: Maya
    """
    for i, a in maya.great_vote_d.items():
        if i in maya.issue_q and isinstance(a, dict):
            n = 'is_' + i
            vote = None

            for b in a.values():
                if isinstance(b, bool):
                    if vote is None:
                        vote = b

                    else:
                        vote |= b
                    if vote:
                        break
            if vote is not None:
                vote |= getattr(maya, n)
                if vote:
                    setattr(maya, n, vote)
