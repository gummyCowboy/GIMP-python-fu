#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import sqrt
from roller_constant_identity import Identity as de

BAND = [1., 1., .0, .0]


def calc_band_profile(w):
    """
    Calculate a Band profile.

    w: float
        length of profile

    Return: list
        a profile
    """
    w, a = divmod(int(w), 4)
    return BAND * w + BAND[:a]


def calc_bevel_profile(w):
    """
    Calculate a 45 degree Bevel profile.

    w: float
        width of the bevel

    Return: list
        a profile
        in .0 to 1.
    """
    # the y-axis values, 'q'
    # The y value is useful for adjusting a
    # color's lightness, value, or other property.
    q = []

    # the value to increment 'x', 'f'
    # the y mid-point, '.5'
    f = 1. if w == 1. else 2. / w
    x = f / 2.

    for i in range(int(w)):
        if x < 1.:
            q.append(x)

        else:
            q.append(1. - (x - 1.))
        x += f
    return q


def calc_raise_profile(w):
    """
    Calculate a Raise profile.

    w: float
        width of profile or frame

    Return: list
        a profile
        .0 to 1.
    """
    q = []
    f = 1. / w
    a = 1. - f / 2.

    for i in range(int(w)):
        q.append(a)
        a -= f
    return q


def calc_round_profile(w):
    """
    Calculate a Round profile using the unit circle
    formula given the width of the profile.

    w: float
        width of profile

    Return: list
        a profile
        [.0 to 1., ...]
    """
    # the y-axis values, 'q'
    # The y value is useful for adjusting a
    # color's lightness, value, or other property.
    q = []

    # the value to increment 'x', 'f'
    # the range of x from -1 to 1, '2.'
    # 'w + 5.' produces the mid-point on the y-axis, '.5'.
    f = 2. / (w + 5.) if w == 1. else 2. / w

    # 'x' is given a mid-value between the zero increment and its first.
    x = -1. + f / 2.

    for _ in range(int(w)):
        q.append(sqrt(1. - x**2.))
        x += f
    return q


def calc_sink_profile(w):
    """
    Calculate a Sink profile.

    w: float
        width of profile

    Return: list
        a profile
        .0 to 1.
    """
    q = []
    f = 1. / w
    x = f / 2.

    for _ in range(int(w)):
        q.append(x)
        x += f
    return q


# {profile type: function to calculate its profile}
ROUTE_PROFILE = {
    de.BAND: calc_band_profile,
    de.BEVEL: calc_bevel_profile,
    de.ROUND: calc_round_profile,
    de.RAISE: calc_raise_profile,
    de.SINK: calc_sink_profile
}
