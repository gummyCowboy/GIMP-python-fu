#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import FILL_PATTERN, LAYER_MODE_NORMAL, pdb   # type: ignore
from roller_container import Cat
from roller_comm import info_msg
from roller_constant import Fill as fl
from roller_constant_identity import Identity as de
from roller_gimp_mode import get_fill_mode


def clipboard_fill_default(z):
    """
    Fill a layer with a "Clipboard Image"
    pattern after prepping GIMP's context.

    z: layer
        Fill.
    """
    set_fill_context_default()
    pdb.gimp_context_set_pattern("Clipboard Image")
    pdb.gimp_drawable_edit_bucket_fill(z, FILL_PATTERN, .0, .0)


def prep_brush():
    """Set default brush context for drawing line."""
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_context_set_brush_angle(.0)
    pdb.gimp_context_set_brush_hardness(.95)
    pdb.gimp_context_set_opacity(100.)


def prep_replace_color_default():
    """Set GIMP context for default color selection and selection fill."""
    pdb.gimp_context_set_feather(0)
    pdb.gimp_context_set_opacity(100.)
    pdb.gimp_context_set_paint_mode(LAYER_MODE_NORMAL)
    pdb.gimp_context_set_sample_criterion(0)
    pdb.gimp_context_set_sample_threshold(1.)


def set_draw_line_brush():
    """Consistently use the same brush for drawing line."""
    set_gimp_brush("C_Normal Brush 80")


def set_fill_context_default():
    """Use a default fill dict to init fill context."""
    set_fill_context({
        de.THRESHOLD: 1.,                   # Match all.
        de.CRITERION: de.COMPOSITE,
        de.FILL_MODE: "Normal",
        de.FILL_OPACITY: 100.
    })


def set_fill_context(d):
    """
    Set the context for a fill-type operation.
    Call before actualizing a bucket fill operation.

    d: dict
        Has fill options.
    """
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_context_set_opacity(d[de.FILL_OPACITY])
    pdb.gimp_context_set_paint_mode(get_fill_mode(d))
    pdb.gimp_context_set_sample_criterion(
        fl.CRITERION_LIST.index(d[de.CRITERION])
    )
    pdb.gimp_context_set_sample_threshold(d[de.THRESHOLD])


def set_gimp_brush(n):
    """
    Set the brush for a brush-stroke operation. Make sure the brush exists.

    n: string
        GIMP brush descriptor
    """
    q = Cat.brush_list

    if n not in q:
        info_msg("A brush was not found: " + repr(n))
        n = q[0] if q else None
    if n is not None:
        pdb.gimp_context_set_brush(n)


def set_gimp_gradient(d):
    """
    Set the gradient for a gradient fill
    operation. Make sure the gradient exists.

    d: dict
        Has a gradient option.
    """
    n = d[de.GRADIENT]
    q = Cat.gradient_list

    # Set FG and BG color.
    set_background(Cat.background)
    set_foreground(Cat.foreground)

    if n not in q:
        info_msg("A gradient was not found: " + repr(n))
        n = q[0] if q else None
    if n is not None:
        pdb.gimp_context_set_gradient(n)


def set_gimp_pattern(n):
    """
    Set the pattern for a pattern fill
    operation. Make sure the pattern exists.

    n: string
        pattern descriptor
    """
    q = Cat.pattern_list

    if n not in q:
        info_msg("A pattern was not found: " + repr(n))
        n = q[0] if q else None
    if n is not None:
        pdb.gimp_context_set_pattern(n)


def set_background(q):
    """
    Set the background color in Gimp context.

    q: tuple or list
        RGB
    """
    pdb.gimp_context_set_background(q)


def set_foreground(q):
    """
    Set the foreground color in Gimp context.

    q: tuple or list
        RGB
    """
    pdb.gimp_context_set_foreground(q)
