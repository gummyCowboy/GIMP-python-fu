#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_container import Back, Lit, PlanZ, Run, The
from roller_gimp_item import validate_item
from roller_gimp_layer import hide_layer, show_layer
from roller_helm import Helm
from roller_ice import Ice, freeze, thaw


def do_work_step(first, last):
    """
    Perform a peek, preview or finish the render.

    first, last: int
        Is the range of step to perform.
    """
    def _refresh():
        # Remove selection because the marching ants are slow to draw.
        # Flushing the display will fail if ignored for too long.
        if Run.j:
            pdb.gimp_selection_none(Run.j)
            pdb.gimp_displays_flush()

    is_cold = Ice.is_hide_layer

    show_work()
    hide_plan()

    # [(Model-name-step-key: AnyGroup)], 'step_q'
    for i in range(first, last):
        if is_cold:
            if Run.j:
                freeze()
                is_cold = False

        if i == Back.i:
            Run.is_back = True
            Back.i = None

        Helm.any_group_list[i].do()
        _refresh()

    j = Run.j

    if j:
        if j.layers:
            j.active_layer = j.layers[0]
        thaw()
    _refresh()


def hide_plan():
    """Hide the Plan group."""
    z = PlanZ.plan_group
    if validate_item(z):
        hide_layer(z)
        pdb.gimp_displays_flush()


def show_work():
    """Show the Work group."""
    j = Run.j
    no_change_q = PlanZ.plan_group, Lit.z
    if j:
        for z in j.layers:
            m = z not in no_change_q
            if z and m:
                if not z.visible:
                    show_layer(z)

        model_group = The.model_list.any_group
        q = model_group.work.get_model_folder_list()

        for i in q:
            show_layer(i)
        pdb.gimp_displays_flush()
