#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Frame as ek, Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_frame import mask_filler_layer, remove_sc, sort_shadow_layer
from roller_gimp_image import (
    check_matter, make_group_filler, make_group_overlay, make_group_wrap
)
from roller_maya_add import Add, AddAbove, AltAdd
from roller_maya_below import Below
from roller_maya_build import Build, SubBuild
from roller_maya_bulb import Bulb
from roller_maya_layer import check_mix_basic
from roller_maya_shadow import Shadow
from roller_gimp_mask import mask_sub_maya


class Wrap(SubBuild):
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        super_maya: Maya
            Frame type

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.

        do_matter: function
            Make a wrap layer.
        """
        # In its cast-Maya, Shadow/Inner looks for 'is_inward'.
        self.is_inward = self.was_inward = self.is_inward_change = False

        self.wrap_k = super_maya.wrap_k
        self.kind = super_maya.kind

        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (rk.RW1,),
                k_path + (de.GRID,),
                k_path + (de.EMBOSS,)
            ],
            do_matter
        )
        self.sub_maya[sm.BULB] = Bulb(any_group, self, super_maya.material)

    def do(self, d, is_change):
        """
        Manage layer output during a view run.

        d: dict
            Wrap Preset

        is_change: bool
            Is True if the cast Maya has change.

        Return: bool
            Is True if the matter layer changed.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change
        self.was_inward = self.is_inward
        self.is_inward = d.get(de.TYPE) in ek.INWARD_SET
        self.is_inward_change = m and (self.is_inward or self.was_inward)

        self.realize()

        if self.matter:
            self.sub_maya[sm.BULB].do(m)

        self.reset_issue()
        return m


class AddAboveWrap(SubBuild):
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        super_maya: Maya
            Frame sub-type

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.

        do_matter: function
            Make a wrap layer.
        """
        # In its cast-Maya, Shadow/Inner looks for 'is_inward'.
        self.is_inward = self.was_inward = self.is_inward_change = False

        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (de.EMBOSS,)],
            do_matter
        )

        self.sub_maya[sm.ADD] = AddAbove(
            any_group, self, k_path + (de.ADD_ABOVE,)
        )
        self.sub_maya[sm.BULB] = Bulb(any_group, self, super_maya.material)

    def do(self, d, is_change, _):
        """
        Produce layer output.

        d: dict
            Wrap Preset

        is_change: bool
            Is True if the cast Maya has change.

        _: bool
            Is True if the background changed.

        Return: bool
            Is True if the matter layer changed.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change
        self.was_inward = self.is_inward
        self.is_inward = d.get(de.TYPE) in ek.INWARD_SET
        self.is_inward_change = m and (self.is_inward or self.was_inward)

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(d[de.ADD_ABOVE], m, m)
            self.sub_maya[sm.BULB].do(self.is_matter)

        else:
            self.die()

        self.reset_issue()
        return m


class AltFiller(SubBuild):
    """Manage Filler layer output."""
    is_seeded = is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_filler, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path, do_filler):
        """
        super_maya: Maya
            Frame type

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.

        do_filler: function
            Call to make a filler layer.
        """
        self.filler_sc = None
        self.filler_k = super_maya.filler_k
        k_path += (rk.BRW, self.filler_k)

        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (rk.BRW, de.MOD),
                k_path + (rk.BRW, de.MOD, de.BLUR_D)
            ],
            do_filler
        )

        self.sub_maya[sm.ADD] = AltAdd(
            any_group, self, k_path + (rk.BRW, de.ADD_ALT,)
        )
        self.sub_maya[sm.BULB] = Bulb(
            any_group, self, super_maya.material + " " + de.FILLER
        )

    def do(self, d, is_change, is_mask, is_back, filler_sc):
        """
        Produce GIMP layer output during a view run.

        d: dict
            frame Preset

        is_change: bool
            Is True if the cast Maya has change.

        is_mask: bool
            Is True if the mask has change.

        is_back: bool
            Is True if the background changed.

        filler_sc: GIMP selection channel
            Mask the 'matter' layer.
        """
        self.value_d = d
        self.filler_sc = filler_sc
        self.is_matter |= is_change

        self.realize()

        if self.matter:
            if self.is_matter or is_mask:
                mask_filler_layer(Run.j, self, filler_sc)

            self.sub_maya[sm.ADD].do(
                d[rk.BRW][de.ADD_ALT], self.is_matter, is_mask, is_back
            )
            self.sub_maya[sm.BULB].do(is_change or is_mask)

        else:
            self.die()
        self.reset_issue()


class AltWrapSel(SubBuild):
    """Alt-Wrap-Selection corresponds with the Frame's Filler."""
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )
    wrap_k = de.WRAP_AL

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        super_maya: Maya
            Wrap type

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.

        do_matter: function
            Make a wrap layer.
        """
        # In its cast-Maya, Shadow/Inner looks for 'is_inward'.
        self.is_inward = self.was_inward = self.is_inward_change = False

        self.filler_sc = None
        self.wrap_k = super_maya.wrap_k
        self.filler_k = super_maya.filler_k
        k_path = k_path + (rk.BRW, self.wrap_k)

        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (de.EMBOSS,)],
            do_matter
        )

        self.sub_maya[sm.ADD] = AltAdd(any_group, self, k_path + (de.ADD_ALT,))
        self.sub_maya[sm.BULB] = Bulb(any_group, self, super_maya.material)

    def do(self, d, is_change, is_back):
        """
        Manage layer output.

        d: dict
            Wrap Preset

        is_change: bool
            Is True if the cast Maya has change.

        is_back: bool
            Is True if the background changed.

        Return: bool
            Is True if the wrap layer changed.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change
        self.was_inward = self.is_inward
        self.is_inward = d.get(de.TYPE) in ek.INWARD_SET
        self.is_inward_change = m and (self.is_inward or self.was_inward)

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(d[de.ADD_ALT], m, m, is_back)
            self.sub_maya[sm.BULB].do(self.is_matter)

        else:
            self.die()

        self.reset_issue()
        return m

    def reset(self):
        """Call when the view image is removed."""
        remove_sc(self, 'filler_sc')
        super(AltWrapSel, self).reset()


class AltWrapFiller(Build):
    is_embossed = True
    put = issue_q = ()

    def __init__(self, any_group, super_maya, k_path, do_matter, do_filler):
        """
        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.

        do_matter: function
            Make a matter layer.

        do_filler: function
            Make a filler layer.
        """
        Build.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.WRAP] = AltWrapSel(
            any_group, self, k_path, do_matter
        )
        self.sub_maya[sm.FILLER] = AltFiller(
            any_group, self, k_path, do_filler
        )
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group,
            self,
            (self.cast, self.sub_maya[sm.WRAP], self.sub_maya[sm.FILLER]),
            k_path + (rk.BRW, de.SHADOW)
        )

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        is_change: bool
            Is the state of the super-maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        m = is_change
        e = self.sub_maya
        wrap = e[sm.WRAP]

        self.realize()

        m |= wrap.do(d[rk.BRW][self.wrap_k], is_change, is_back)

        e[sm.FILLER].do(
            d[rk.BRW][self.filler_k],
            is_change,
            m,
            is_back,
            wrap.filler_sc
        )

        m = e[sm.SHADOW].do(
            d[rk.BRW][de.SHADOW],
            is_change or wrap.is_inward_change,
            m,
            wrap.group
        )

        sort_shadow_layer(self, m, wrap.get_light(), wrap.matter)
        self.reset_issue()


class FrameBasic(Build):
    put = issue_q = ()

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.

        do_matter: function
            Call to make the frame layer.
        """
        Build.__init__(self, any_group, super_maya, k_path, do_matter)

        self.sub_maya[sm.WRAP] = Wrap(
            any_group, self, k_path + (rk.BRW, self.wrap_k), do_matter
        )
        self.sub_maya[sm.ADD] = Add(
            any_group, self.sub_maya[sm.WRAP], k_path + (rk.BRW, de.ADD)
        )

    def add_filler_k_path(self, k_path):
        """
        Add the Filler's k-path to the Wrap's k-path.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        self.sub_maya[sm.WRAP].k_path += [k_path + (rk.BRW, self.filler_k)]

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            sub-Frame Preset

        is_change: bool
            Is the state of the super-maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        m = is_change
        wrap = self.sub_maya[sm.WRAP]

        self.realize()

        m |= wrap.do(d[rk.BRW][self.wrap_k], is_change)

        if wrap.matter:
            self.sub_maya[sm.ADD].do(
                d[rk.BRW][de.ADD], m, m, is_back, wrap.group
            )

        else:
            self.die()
        self.reset_issue()


class Overlap(Build):
    """The Wrap is always Overlap."""
    put = issue_q = ()

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.

        do_matter: function
            Call to make Wrap material.
        """
        Build.__init__(self, any_group, super_maya, k_path, do_matter)

        self.sub_maya[sm.WRAP] = OverlapWrap(
            any_group, self, k_path + (rk.BRW, self.wrap_k), do_matter
        )
        self.sub_maya[sm.ADD] = Add(
            any_group, self.sub_maya[sm.WRAP], k_path + (rk.BRW, de.ADD)
        )

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            sub-Frame Preset

        is_change: bool
            Is the state of the super-maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        m = is_change
        wrap = self.sub_maya[sm.WRAP]

        self.realize()

        m |= wrap.do(d[rk.BRW][self.wrap_k], is_change)

        if wrap.matter:
            self.sub_maya[sm.ADD].do(
                d[rk.BRW][de.ADD], m, m, is_back, wrap.group
            )

        else:
            self.die()
        self.reset_issue()


class OverlapWrap(SubBuild):
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        super_maya: Maya
            Frame type

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.

        do_matter: function
            Make a wrap layer.
        """
        # In its cast-Maya, Shadow/Inner looks for 'is_inward'.
        self.is_inward_change = False
        self.is_inward = True

        self.wrap_k = super_maya.wrap_k
        self.kind = super_maya.kind

        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (de.EMBOSS,)],
            do_matter
        )
        self.sub_maya[sm.BULB] = Bulb(any_group, self, super_maya.material)

    def do(self, d, is_change):
        """
        Manage layer output during a view run.

        d: dict
            Wrap Preset

        is_change: bool
            Is True if the cast Maya has change.

        Return: bool
            Is True if the matter layer changed.
        """
        self.value_d = d
        m = self.is_matter = self.is_inward_change = \
            self.is_matter or is_change

        self.realize()

        if self.matter:
            self.sub_maya[sm.BULB].do(m)

        self.reset_issue()
        return m


class Overlay(SubBuild):
    """Manage an overlay output."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_overlay, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path, do_overlay):
        """
        super_maya: Maya
            Is the enclosing Maya.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.

        do_overlay: function
            Make an overlay layer.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, do_overlay)

        self.sub_maya[sm.ADD] = AddAbove(
            any_group, self, k_path + (de.ADD_ABOVE,)
        )
        self.sub_maya[sm.BULB] = Bulb(
            any_group, self, super_maya.material + " " + de.OVERLAY
        )

    def do(self, d, is_change, is_mask, _):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        is_change: bool
            If it is True, then a mask is drawn on the Overlay layer.

        is_mask: bool
            Is True if the frame Maya has change.

        _: bool
            Is True if the background changed.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize()

        if self.matter:
            if self.is_matter or is_mask:
                mask_sub_maya(
                    self.super_maya.sub_maya[sm.WRAP].matter, self.matter
                )

            self.sub_maya[sm.ADD].do(
                d[de.ADD_ABOVE], self.is_matter, self.is_matter or is_mask
            )
            self.sub_maya[sm.BULB].do(is_change)

        else:
            self.die()
        self.reset_issue()


class FrameOverlay(Build):
    put = issue_q = ()

    def __init__(self, any_group, super_maya, k_path, do_matter, do_overlay):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.

        do_matter: function
            Produce Wrap output.

        do_overlay: function
            Produce Overlay output.
        """
        Build.__init__(self, any_group, super_maya, k_path, do_matter)

        rap = self.sub_maya[sm.WRAP] = AddAboveWrap(
            any_group, self, k_path + (rk.BRW, self.wrap_k), do_matter
        )
        self.sub_maya[sm.OVERLAY] = Overlay(
            any_group,
            self,
            k_path + (rk.BRW, self.overlay_k),
            do_overlay
        )
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group,
            self,
            (self.cast, rap),
            k_path + (self.shade_row, de.SHADOW)
        )
        self.sub_maya[sm.BELOW] = Below(
            any_group, rap, k_path + (self.shade_row, de.BELOW)
        )

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            Bevel Preset
            {Identity: value}

        is_change: bool
            Is the state of the super-maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        m = is_change
        wrap = self.sub_maya[sm.WRAP]

        self.realize()

        m |= wrap.do(
            d[rk.BRW][self.wrap_k], is_change, is_back
        )

        if wrap.matter:
            self.sub_maya[sm.OVERLAY].do(
                d[rk.BRW][self.overlay_k], is_change, m, is_back
            )

            m1 = self.sub_maya[sm.SHADOW].do(
                d[self.shade_row][de.SHADOW],
                is_change or wrap.is_inward_change,
                m,
                wrap.group
            )

            sort_shadow_layer(self, m1, wrap.get_light(), wrap.matter)
            self.sub_maya[sm.BELOW].do(d[
                self.shade_row][de.BELOW], is_back or m1, m
            )

        else:
            self.die()
        self.reset_issue()
