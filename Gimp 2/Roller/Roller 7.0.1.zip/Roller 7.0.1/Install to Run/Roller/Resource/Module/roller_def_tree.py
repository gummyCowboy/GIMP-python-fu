#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import Define as df, Step as sk
from roller_constant_identity import Identity as de
from roller_step import connect_sub_str, get_parts, get_type_text

"""Include data structure and function for producing UI navigation."""

# AnyGroup with a Preset
preset = {df.TRUE_ATTR: {'preset'}}
preset_switch = {df.TRUE_ATTR: {'preset', 'switched'}}
preset_random = {df.HAS_RANDOM: True, df.TRUE_ATTR: {'preset'}}

# AnyGroup without a savable Preset
simple = {df.TRUE_ATTR: {'simple', 'switched'}}

# AnyGroup with only a SuperPreset
super_ = {df.TRUE_ATTR: {'super_preset'}}

BORDER_ARG = de.BORDER, preset_switch
CAPTION_ARG = de.CAPTION, preset_switch
FRINGE_ARG = de.FRINGE, preset_switch
IMAGE_ARG = de.IMAGE, preset_switch
LINE_ARG = de.LINE, preset_switch,
MARGIN_ARG = de.MARGIN, preset_switch
PLAQUE_ARG = de.PLAQUE, preset_switch
RECTANGLE_ARG = de.RECTANGLE, preset
SHIFT_ARG = de.SHIFT, preset_switch
DECO_D = OrderedDict([
    SHIFT_ARG, MARGIN_ARG, PLAQUE_ARG, FRINGE_ARG,
    BORDER_ARG, IMAGE_ARG, LINE_ARG, CAPTION_ARG
])
FACE_D = OrderedDict([
    PLAQUE_ARG, FRINGE_ARG, BORDER_ARG, IMAGE_ARG, LINE_ARG, CAPTION_ARG
])
FACING_D = deepcopy(FACE_D)
CANVAS = de.CANVAS, {df.DNA: DECO_D, df.TRUE_ATTR: {'node'}}
CELL_NODE_LIST = [de.CELL]
MULTI_CELL_LIST = [
    de.PROPERTY,
    connect_sub_str(de.CANVAS, de.SHIFT),
    connect_sub_str(de.CELL, de.TYPE),
    de.PRESET
]
MULTI_CELL_BRANCH_LIST = MULTI_CELL_LIST + CELL_NODE_LIST
ONE_CELL_LIST = [
    de.PROPERTY,
    connect_sub_str(de.CELL, de.TYPE),
    connect_sub_str(de.CELL, de.RECTANGLE),
    de.PRESET
]
ONE_CELL_BRANCH_LIST = ONE_CELL_LIST + CELL_NODE_LIST
DEFAULT_MODEL_D = {
    de.BOX: MULTI_CELL_LIST,
    de.CELL: ONE_CELL_LIST,
    de.PYRAMID: MULTI_CELL_LIST,
    de.SIDEWALK: MULTI_CELL_LIST,
    de.STACK: ONE_CELL_LIST,
    de.TABLE: MULTI_CELL_LIST
}
DEFAULT_MODEL_BRANCH_D = {
    de.BOX: MULTI_CELL_BRANCH_LIST,
    de.CELL: ONE_CELL_BRANCH_LIST,
    de.PYRAMID: MULTI_CELL_BRANCH_LIST,
    de.SIDEWALK: MULTI_CELL_BRANCH_LIST,
    de.STACK: ONE_CELL_BRANCH_LIST,
    de.TABLE: MULTI_CELL_BRANCH_LIST
}
MAIN_TREE_D = {
    sk.STEPS: {
        df.DNA: OrderedDict([
            (de.GLOBAL, preset_random),
            (de.LIGHT, preset_switch),
            (de.BACKGROUND, preset),
            (de.ACCENT, preset_switch),
            (de.MODEL, preset),
            (de.PRESET_STEPS, super_)
        ]),
        df.TRUE_ATTR: {'node'}
    }
}
MAIN_TREE_STEP_LIST = [
    sk.STEPS,
    de.GLOBAL,
    de.LIGHT,
    de.BACKGROUND,
    de.ACCENT,
    de.MODEL,
    de.PRESET_STEPS
]
SHADOW_TREE_D = {
    de.SHADOW: {
        df.DNA: OrderedDict([
            (de.SHADOW_SWITCH, simple),
            (de.SHADOW_1, preset_switch),
            (de.SHADOW_2, preset_switch),
            (de.INNER_SHADOW, preset_switch),
            (de.PRESET_SHADOW, super_)
        ]),
        df.TRUE_ATTR: {'node'}
    }
}
INSERT_MODEL_D = {
    sk.STEPS: {
        df.DNA: {},
        df.TRUE_ATTR: {'node'}
    }
}
INSERT_STEPS_D = deepcopy(INSERT_MODEL_D)

INSERT_STEPS_D.update(deepcopy(MAIN_TREE_D))

# 'Preset, Steps' is inserted at the end of the insertion process
# in 'create_steps_insert_d'.
INSERT_STEPS_D[sk.STEPS][df.DNA].pop(de.PRESET_STEPS)

BOX_CELL_D = OrderedDict([(de.TYPE_BOX, preset)])
CELL_CELL_D = OrderedDict([RECTANGLE_ARG, (de.TYPE_CELL, preset)])
PYRAMID_CELL_D = OrderedDict([(de.TYPE_PYRAMID, preset)])
SIDEWALK_CELL_D = OrderedDict([(de.TYPE_SIDEWALK, preset)])
STACK_CELL_D = OrderedDict([RECTANGLE_ARG, (de.TYPE_STACK, preset)])
TABLE_CELL_D = OrderedDict([(de.TYPE_TABLE, preset)])

for i_ in (
    BOX_CELL_D,
    CELL_CELL_D,
    PYRAMID_CELL_D,
    SIDEWALK_CELL_D,
    STACK_CELL_D,
    TABLE_CELL_D
):
    i_.update(deepcopy(DECO_D))

MODEL_TREE_D = {
    de.BOX: {
        df.DNA: OrderedDict([
            (de.PROPERTY, preset),
            CANVAS,
            (de.CELL, {df.DNA: BOX_CELL_D, df.TRUE_ATTR: {'node'}}),
            (de.FACE, {df.DNA: FACE_D, df.TRUE_ATTR: {'node'}}),
            (de.PRESET_BOX, super_)
        ]),
        df.TRUE_ATTR: {'node'}
    },
    de.CELL: {
        df.DNA: OrderedDict([
            (de.PROPERTY, preset),
            (de.CELL, {df.DNA: CELL_CELL_D, df.TRUE_ATTR: {'node'}}),
            (de.PRESET_CELL, super_)
        ]),
        df.TRUE_ATTR: {'node'}
    },
    de.PYRAMID: {
        df.DNA: OrderedDict([
            (de.PROPERTY, preset),
            CANVAS,
            (de.CELL, {df.DNA: PYRAMID_CELL_D, df.TRUE_ATTR: {'node'}}),
            (de.PRESET_PYRAMID, super_)
        ]),
        df.TRUE_ATTR: {'node'}
    },
    de.SIDEWALK: {
        df.DNA: OrderedDict([
            (de.PROPERTY, preset),
            CANVAS,
            (de.CELL, {df.DNA: SIDEWALK_CELL_D, df.TRUE_ATTR: {'node'}}),
            (de.FACING, {df.DNA: FACING_D, df.TRUE_ATTR: {'node'}}),
            (de.PRESET_SIDEWALK, super_)
        ]),
        df.TRUE_ATTR: {'node'}
    },
    de.STACK:  {
        df.DNA: OrderedDict([
            (de.PROPERTY, preset),
            (de.CELL, {df.DNA: STACK_CELL_D, df.TRUE_ATTR: {'node'}}),
            (de.PRESET_STACK, super_)
        ]),
        df.TRUE_ATTR: {'node'}
    },
    de.TABLE: {
        df.DNA: OrderedDict([
            (de.PROPERTY, preset),
            CANVAS,
            (de.CELL, {df.DNA: TABLE_CELL_D, df.TRUE_ATTR: {'node'}}),
            (de.PRESET_TABLE, super_)
        ]),
        df.TRUE_ATTR: {'node'}
    }
}


def create_model_insert_d(q, model_d):
    """
    Create a dictionary for inserting
    hierarchical structured sequenced step-key.

    q: list
        [Model-name-step-key, ...]
        Add to navigation tree.

    model_d: OrderedDict
        {Model name: Model type}

    Return: dict
        hierarchically structured and relationally sequenced
    """
    step_d = OrderedDict()
    add_d = OrderedDict()
    insert_d = {}

    for name_step_k in q:
        d = step_d
        for part in get_parts(name_step_k):
            if part not in d:
                d[part] = OrderedDict()
            d = d[part]

    for model_name, model_type in model_d.items():
        add_d[model_name] = deepcopy(MODEL_TREE_D[model_type])

    # Restructure Model dictionary.
    remove_unused_step(add_d, step_d)

    insert_d.update(add_d)
    return insert_d


def create_steps_insert_d(q, model_d):
    """
    Create a dictionary for inserting a hierarchical
    structured and relational sequenced step-key.

    q: list
        [Model-name-step-key, ...]
        Add to navigation tree.

    model_d: OrderedDict
        {model name: model type}

    Return: dict
        hierarchically structured and relationally sequenced
    """
    step_d = {sk.STEPS: OrderedDict()}
    add_d = OrderedDict()
    insert_d = deepcopy(INSERT_STEPS_D)
    model_path_d = insert_d[sk.STEPS][df.DNA]

    for name_step_k in q:
        d = step_d[sk.STEPS]
        for part in get_parts(name_step_k):
            if part not in d:
                d[part] = OrderedDict()
            d = d[part]

    model_path_d.update(add_d)

    for model_name, model_type in model_d.items():
        model_path_d[model_name] = deepcopy(MODEL_TREE_D[model_type])

    # Restructure Model dictionary.
    remove_unused_step(insert_d, step_d)

    # Add to the end of Steps item list after the inserted Model branch.
    insert_d[sk.STEPS][df.DNA][de.PRESET_STEPS] = super_

    return insert_d


def remove_unused_step(add_d, step_d):
    """
    Recursively remove item from a NodePanel structure dict
    according to the hierarchically arranged insert dict keys.

    add_d: dict
        structure dict
        Has a default structure and order.

    step_d: dict
        insert type
        Has the desired structure, but not order.
    """
    for i in add_d.keys():
        # Transform group key to an item key.
        item = get_type_text(i)

        if item not in step_d.keys():
            add_d.pop(i)

        # Node has ITEM.
        elif df.DNA in add_d[i]:
            remove_unused_step(add_d[i][df.DNA], step_d[item])
