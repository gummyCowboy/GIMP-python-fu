#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_identity import Identity as de
from roller_helm import Helm
from roller_port_save import save_file


class LastUsed:
    # SuperPreset
    # {Model-type-step-key: Preset value dict}, d
    d = None

    @staticmethod
    def write():
        """Write a Last Used Preset for the session."""
        g = Helm.get_group(de.PRESET_STEPS).get_widget(de.PRESET)
        d = g.get_a()
        if d and d != LastUsed.d:
            save_file(
                None, d, de.PRESET_STEPS, de.LAST_USED, is_overwrite=True
            )
