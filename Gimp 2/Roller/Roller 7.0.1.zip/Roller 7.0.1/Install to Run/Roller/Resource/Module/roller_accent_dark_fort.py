#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import (  # type: ignore
    CHANNEL_OP_REPLACE,
    CLIP_TO_IMAGE,
    DESATURATE_LUMINANCE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_HSV_VALUE,
    pdb
)
from roller_accent_color_grid import do_color_grid
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gegl import unsharp_mask
from roller_gimp_image import add_sub_maya_group
from roller_gimp_layer import (
    blur_selection, clear_selection, clone_layer, flip_layer
)
from roller_gimp_selection import select_channel, select_color
from roller_maya_sub_accent import SubAccent


def do_matter(maya):
    """
    Make a Dark Fort matter layer.

    maya: DarkFort
    Return: layer or None
        Dark Fort material
    """
    def _noise():
        """Add noise by color."""
        # Create a selection from black pixel.
        pdb.gimp_by_color_select(
            z,
            (0, 0, 0),
            0,                      # threshold
            CHANNEL_OP_REPLACE,
            1,                      # yes, antialias
            0,                      # no feather
            .0,                     # feather radius
            0                       # no sample merged
        )

        # Clear the black grid.
        clear_selection(z)

        pdb.plug_in_rgb_noise(
            j, z,
            1,                      # yes, independent
            0,                      # no correlated
            .1,                     # R noise
            .1,                     # G noise
            .1,                     # B noise
            .0                      # A noise
        )
        pdb.plug_in_emboss(
            j, z,
            azimuth,
            elevation,
            3,                      # depth
            0                       # bump
        )
        pdb.plug_in_despeckle(
            j, z,
            15,                     # radius
            1,                      # adaptive
            0,                      # black cut-off
            255                     # white cut-off
        )
        pdb.plug_in_despeckle(
            j, z,
            15,                     # radius
            1,                      # adaptive
            0,                      # black cut-off
            255                     # white cut-off
        )

    j = Run.j
    d = maya.value_d
    parent = add_sub_maya_group(maya)
    azimuth = Globe.azimuth
    elevation = Globe.elevation
    e = deepcopy(d)
    e[de.ANGLE] = .0
    grid = do_color_grid(e, parent)
    z = clone_layer(grid, n="Noise")

    select_color(z, (0, 0, 0))

    black_sc = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    _noise()

    z1 = clone_layer(z, n="HSV Value")
    z1.mode = LAYER_MODE_HSV_VALUE

    flip_layer(z1, is_h=True)
    pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

    z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
    z1 = clone_layer(z, n="Difference")
    z1.mode = LAYER_MODE_DIFFERENCE

    # lowest turbulence, '1.'
    pdb.plug_in_plasma(j, z, int(d[de.RANDOM_SEED] + Globe.seed), 1.)

    z = clone_layer(z, n="Unsharp Mask")

    select_channel(j, black_sc)
    blur_selection(z, 1)
    unsharp_mask(z, 2., .5, 0.)
    pdb.gimp_selection_none(j)

    z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

    pdb.gimp_drawable_desaturate(z, DESATURATE_LUMINANCE)

    # depth '3'; bump, '0'
    pdb.plug_in_emboss(j, z, azimuth, elevation, 3, 0)

    pdb.gimp_image_remove_channel(j, black_sc)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class DarkFort(SubAccent):
    """Create Accent output."""
    kind = de.DARK_FORT

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)
