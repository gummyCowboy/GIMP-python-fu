#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant import Define as df
from roller_constant_identity import Identity as de
from roller_def_accent import (
    ACRYLIC_SKY,
    BACK_GAME,
    CLAY_CHEMISTRY,
    COLOR_FILL,
    COLOR_GRID,
    CORNER_OVERLAP,
    CRYSTAL_CAVE,
    CUBE_PATTERN,
    CUBISM_COVER,
    DARK_FORT,
    DENSITY_GRADIENT,
    DROP_ZONE,
    ETCH_SKETCH,
    FADING_MAZE,
    FLOOR_SAMPLE,
    GALACTIC_FIELD,
    GLASS_GAW,
    GRADIENT_FILL,
    HISTORIC_TRIP,
    LINE_STONE,
    LOST_MAZE,
    MAZE_BLEND,
    MYSTERY_GRATE,
    NOISE_RIFT,
    PAPER_WASTE,
    PATTERN_FILL,
    RAINBOW_VALLEY,
    RECT_PATTERN,
    ROCKY_LANDING,
    ROOF_TOP,
    SOFT_TOUCH,
    SPECIMEN_SPECKLE,
    SPIRAL_CHANNEL,
    SQUARE_CLOUD,
    STONE_AGE,
    TRAILING_VINE,
    TRIANGLE_REVERB,
    WAVE_FILL
)
from roller_def_background import BACKGROUND
from roller_def_cell_type import (
    TYPE_BOX, TYPE_CELL, TYPE_PYRAMID, TYPE_SIDEWALK, TYPE_STACK, TYPE_TABLE
)
from roller_def_frame import (
    BEVEL,
    BRUSHY,
    BURST,
    CAMO,
    CERAMIC,
    CHECKER,
    MAZE,
    CLEAR,
    CRUMBLE,
    DECAY,
    FENCE,
    GLUE,
    GRADUAL,
    HOLEY,
    JOINT,
    MECHA,
    MIRROR,
    NET,
    OVER,
    OVERLAP,
    PIPE,
    RAD,
    STAINED,
    STRETCH,
    STRIPE,
    TAPE,
    WOBBLE
)
from roller_def_global import GLOBAL
from roller_def_light import LIGHT, HEAT
from roller_def_property import PLANNER, PROPERTY
from roller_def_rectangle import RECTANGLE
from roller_def_dialog import (
    ACCENT,
    ADD,
    ADD_ABOVE,
    ADD_ALT,
    BELOW,
    BASIC,
    BLUR_DIALOG,
    BRUSH_DIALOG,
    BRUSH_D1,
    BUMP,
    COLOR,
    EMBOSS,
    FILLER_CE,
    FILLER_CH,
    FILLER_FE,
    FILLER_HO,
    FILLER_MA,
    FILLER_MI,
    FILLER_ME,
    FILLER_RA,
    FILLER_S1,
    FILLER_S2,
    FILLER_S3,
    FRAME,
    GRID,
    IMAGE_CHOICE,
    INSET,
    INNER_SHADOW,
    MARGIN,
    MASK,
    MEAN_COLOR,
    MOD,
    NOISE_D,
    OVERLAY_BE,
    OVERLAY_CA,
    OVERLAY_OV,
    RESIZE,
    SHADOW,
    SHADOW_1,
    SHADOW_2,
    SHADOW_SWITCH,
    STRIP,
    STENCIL,
    WRAP,
    WRAP_AB,
    WRAP_AL,
    WRAP_BE,
    WRAP_BU,
    WRAP_CA,
    WRAP_CL,
    WRAP_CR,
    WRAP_DE,
    WRAP_FI,
    WRAP_GL,
    WRAP_GR,
    WRAP_JO,
    WRAP_NT,
    WRAP_OL,
    WRAP_PA,
    WRAP_PI,
    WRAP_TA,
    WRAP_WO
)
from roller_def_model import (
    BORDER,
    CAPTION,
    FRINGE,
    IMAGE,
    LINE,
    PLAQUE,
    SHIFT
)
from roller_widget_entry import Entry
from roller_widget_model_list import ModelList

"""Organize Preset definition for program retrieval."""

ACCENT_DEF = {
    de.ACRYLIC_SKY: ACRYLIC_SKY,
    de.BACK_GAME: BACK_GAME,
    de.CLAY_CHEMISTRY: CLAY_CHEMISTRY,
    de.COLOR_FILL: COLOR_FILL,
    de.COLOR_GRID: COLOR_GRID,
    de.CORNER_OVERLAP: CORNER_OVERLAP,
    de.CRYSTAL_CAVE: CRYSTAL_CAVE,
    de.CUBE_PATTERN: CUBE_PATTERN,
    de.CUBISM_COVER: CUBISM_COVER,
    de.DARK_FORT: DARK_FORT,
    de.DROP_ZONE: DROP_ZONE,
    de.DENSITY_GRADIENT: DENSITY_GRADIENT,
    de.ETCH_SKETCH: ETCH_SKETCH,
    de.FADING_MAZE: FADING_MAZE,
    de.FLOOR_SAMPLE: FLOOR_SAMPLE,
    de.GALACTIC_FIELD: GALACTIC_FIELD,
    de.GLASS_GAW: GLASS_GAW,
    de.GRADIENT_FILL: GRADIENT_FILL,
    de.HISTORIC_TRIP: HISTORIC_TRIP,
    de.LINE_STONE: LINE_STONE,
    de.LOST_MAZE: LOST_MAZE,
    de.MAZE_BLEND: MAZE_BLEND,
    de.MEAN_COLOR: MEAN_COLOR,
    de.GRATE_MYSTERY: MYSTERY_GRATE,
    de.NOISE_RIFT: NOISE_RIFT,
    de.PAPER_WASTE: PAPER_WASTE,
    de.PATTERN_FILL: PATTERN_FILL,
    de.RAINBOW_VALLEY: RAINBOW_VALLEY,
    de.RECT_PATTERN: RECT_PATTERN,
    de.ROCKY_LANDING: ROCKY_LANDING,
    de.ROOF_TOP: ROOF_TOP,
    de.SOFT_TOUCH: SOFT_TOUCH,
    de.SPECIMEN_SPECKLE: SPECIMEN_SPECKLE,
    de.SPIRAL_CHANNEL: SPIRAL_CHANNEL,
    de.SQUARE_CLOUD: SQUARE_CLOUD,
    de.STONE_AGE: STONE_AGE,
    de.TRAIL_VINE: TRAILING_VINE,
    de.TRIANGLE_REVERB: TRIANGLE_REVERB,
    de.WAVE_FILL: WAVE_FILL
}
REVISE_MODEL = {}
FRAME_DEF = {
    de.BASIC: BASIC,
    de.BEVEL: BEVEL,
    de.BRUSHY: BRUSHY,
    de.BURST: BURST,
    de.CAMO: CAMO,
    de.CERAMIC: CERAMIC,
    de.CHECKER: CHECKER,
    de.MAZE: MAZE,
    de.CLEAR: CLEAR,
    de.CRUMBLE: CRUMBLE,
    de.DECAY: DECAY,
    de.FENCE: FENCE,
    de.GLUE: GLUE,
    de.GRADUAL: GRADUAL,
    de.HOLEY: HOLEY,
    de.JOINT: JOINT,
    de.MECHA: MECHA,
    de.MIRROR: MIRROR,
    de.NET: NET,
    de.OVER: OVER,
    de.OVERLAP: OVERLAP,
    de.PIPE: PIPE,
    de.RAD: RAD,
    de.STAINED: STAINED,
    de.STRETCH: STRETCH,
    de.STRIPE: STRIPE,
    de.TAPE: TAPE,
    de.WOBBLE: WOBBLE
}

# Model________________________________________________________________________
MODEL_LIST = {
    df.SUB: {
        de.MODEL: {df.VALUE: OrderedDict()},
        de.SHELF: {df.VALUE: OrderedDict()},
        de.ACTIVE: {df.VALUE: OrderedDict()},
    },
    df.WIDGET: ModelList
}
MODEL = {de.MODEL_LIST: MODEL_LIST}
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

MODEL_DEF = {
    de.BORDER: BORDER,
    de.CAPTION: CAPTION,
    de.FRINGE: FRINGE,
    de.IMAGE: IMAGE,
    de.LINE: LINE,
    de.PLAQUE: PLAQUE,
    de.PROPERTY: PROPERTY,
    de.RECTANGLE: RECTANGLE,
    de.SHIFT: SHIFT,
    de.TYPE_BOX: TYPE_BOX,
    de.TYPE_CELL: TYPE_CELL,
    de.TYPE_PYRAMID: TYPE_PYRAMID,
    de.TYPE_SIDEWALK: TYPE_SIDEWALK,
    de.TYPE_STACK: TYPE_STACK,
    de.TYPE_TABLE: TYPE_TABLE,
    de.PLANNER: PLANNER,
    de.SHADOW: SHADOW
}
MODEL_NAME = {
    de.RENAME_MODEL: {
        df.NO_VOTE: True,
        df.VALUE: "",
        df.WIDGET: Entry
    }
}

# These group keys have a 'df.SUB' item and
# a dialog option in their definition.
SUB_GROUP_DEF = {
    de.ADD_ABOVE: ADD_ABOVE,
    de.ADD_ALT: ADD_ALT,
    de.ADD: ADD,
    de.BACKGROUND: BACKGROUND,
    de.BELOW: BELOW,
    de.BLUR_D: BLUR_DIALOG,
    de.BRUSH_D: BRUSH_DIALOG,
    de.BRUSH_D1: BRUSH_D1,
    de.BUMP: BUMP,
    de.COLOR: COLOR,
    de.EMBOSS: EMBOSS,
    de.FILLER_CE: FILLER_CE,
    de.FILLER_CH: FILLER_CH,
    de.FILLER_FE: FILLER_FE,
    de.FILLER_HO: FILLER_HO,
    de.FILLER_MA: FILLER_MA,
    de.FILLER_ME: FILLER_ME,
    de.FILLER_MI: FILLER_MI,
    de.FILLER_RA: FILLER_RA,
    de.FILLER_S1: FILLER_S1,
    de.FILLER_S2: FILLER_S2,
    de.FILLER_S3: FILLER_S3,
    de.FRAME: FRAME,
    de.GRID: GRID,
    de.IMAGE_CHOICE: IMAGE_CHOICE,
    de.INSET: INSET,
    de.MARGIN: MARGIN,
    de.MASK: MASK,
    de.MOD: MOD,
    de.NOISE_D: NOISE_D,
    de.OVERLAY_BE: OVERLAY_BE,
    de.OVERLAY_CA: OVERLAY_CA,
    de.OVERLAY_OV: OVERLAY_OV,
    de.RESIZE: RESIZE,
    de.SHADOW_PRESET: SHADOW,
    de.STENCIL: STENCIL,
    de.STRIP: STRIP,
    de.WRAP_AB: WRAP_AB,
    de.WRAP_AL: WRAP_AL,
    de.WRAP_BE: WRAP_BE,
    de.WRAP_BU: WRAP_BU,
    de.WRAP_CA: WRAP_CA,
    de.WRAP_CL: WRAP_CL,
    de.WRAP_CR: WRAP_CR,
    de.WRAP_DE: WRAP_DE,
    de.WRAP_FI: WRAP_FI,
    de.WRAP_GL: WRAP_GL,
    de.WRAP_GR: WRAP_GR,
    de.WRAP_JO: WRAP_JO,
    de.WRAP_NT: WRAP_NT,
    de.WRAP_OL: WRAP_OL,
    de.WRAP_PA: WRAP_PA,
    de.WRAP_PI: WRAP_PI,
    de.WRAP_TA: WRAP_TA,
    de.WRAP_WO: WRAP_WO,
    de.WRAP: WRAP
}

SHADOW_DEF = {
    de.SHADOW_SWITCH: SHADOW_SWITCH,
    de.SHADOW_1: SHADOW_1,
    de.SHADOW_2: SHADOW_2,
    de.INNER_SHADOW: INNER_SHADOW
}
GROUP_DEF = {
    de.ACCENT: ACCENT,
    de.BACKGROUND: BACKGROUND,
    de.REVISE_MODEL: REVISE_MODEL,
    de.LIGHT: LIGHT,
    de.GLOBAL: GLOBAL,
    de.HEAT: HEAT,
    de.MODEL: MODEL,
    de.MODEL_NAME: MODEL_NAME,
    de.MODEL_LIST: MODEL_LIST,
}

for i in (
    ACCENT_DEF, FRAME_DEF, MODEL_DEF, SHADOW_DEF
):
    GROUP_DEF.update(i)
