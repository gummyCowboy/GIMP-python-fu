#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    LAYER_MODE_BURN,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_DIVIDE,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_LIGHTEN_ONLY,
    LAYER_MODE_LINEAR_LIGHT,
    LAYER_MODE_MULTIPLY,
    LAYER_MODE_NORMAL,
    LAYER_MODE_SUBTRACT,
    CLIP_TO_IMAGE,
    pdb
)
from roller_constant import Frame as ek
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_frame_alt import FrameBasic
from roller_gimp_image import add_wip_base, copy_below, make_group_layer
from roller_gimp_layer import (
    blur_selection,
    clear_inverse_selection,
    clear_selection,
    clone_layer,
    clone_opaque_layer,
    color_layer_default,
    do_curves,
    select_layer,
    set_layer_mode
)
from roller_gimp_mode import get_mode
from roller_gimp_selection import select_channel

MIXED_SET = {de.WHITE_MIXED, de.GREY_MIXED}
MODE_1 = (
    LAYER_MODE_DIVIDE,
    LAYER_MODE_DIVIDE,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_GRAIN_EXTRACT
)
MODE_2 = (
    LAYER_MODE_SUBTRACT,
    LAYER_MODE_SUBTRACT,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_SUBTRACT,
    LAYER_MODE_SUBTRACT,
    LAYER_MODE_SUBTRACT
)
MODE_3 = (
    LAYER_MODE_LINEAR_LIGHT,
    LAYER_MODE_LINEAR_LIGHT,
    LAYER_MODE_LINEAR_LIGHT,
    LAYER_MODE_LINEAR_LIGHT,
    LAYER_MODE_LINEAR_LIGHT,
    LAYER_MODE_NORMAL
)
MODE_4 = (
    LAYER_MODE_MULTIPLY,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_MULTIPLY,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_DIFFERENCE
)


def _make_matter_group(maya):
    """
    Add a material group layer to a group layer.

    maya: Maya
        Must have a Light sub-Maya and a layer 'group'.

    Return: layer
        newly added
    """
    return make_group_layer(Run.j, maya.group,  maya.get_light(), "Material")


def do_matter(maya):
    """
    Make a frame.

    maya: Decay
    Return: layer
        with color
    """
    def _clear_selection():
        """
        Clear the center selection and the area outside of the image material.
        """
        select_channel(j, sc1)
        clear_inverse_selection(z)
        select_channel(j, sc)
        clear_selection(z)

    j = Run.j
    cast = maya.cast.matter
    d = maya.value_d
    group = _make_matter_group(maya)
    i = ek.DECAY_TYPE_LIST.index(d[de.EDGE_TYPE])
    group.mode = LAYER_MODE_LIGHTEN_ONLY
    z = first_z = clone_opaque_layer(cast)
    z.mode = MODE_1[i]

    select_layer(z)
    clear_inverse_selection(z)
    pdb.gimp_image_reorder_item(j, z, group, 0)

    # amount, '2.'; wrap, '1'; Sobel, '0'
    pdb.plug_in_edge(j, z, 2., 1, 0)

    z = dark_z = clone_layer(z, n="Dark")
    z.mode = MODE_2[i]

    pdb.gimp_image_lower_item_to_bottom(j, z)

    z = light_z = clone_layer(z, n="Light")
    z.mode = MODE_3[i]
    w = d[de.WIDTH]

    while w:
        w1 = min(w, 500.)
        w -= w1
        blur_selection(z, w1)

    if d[de.EDGE_TYPE] in MIXED_SET:
        w = d[de.WIDTH] // 2.
        while w:
            w1 = min(w, 500.)
            w -= w1
            blur_selection(z, w1)

    pdb.gimp_image_lower_item_to_bottom(j, z)

    # Protect the center with a grey layer.
    z = clone_layer(dark_z, n="Burn")
    z.mode = LAYER_MODE_BURN

    pdb.gimp_image_reorder_item(j, z, group, 2)
    do_curves(z, (.0, .5, 1., .5))
    select_layer(z)
    pdb.gimp_selection_shrink(j, int(d[de.WIDTH]))

    sc = pdb.gimp_selection_save(j)

    clear_inverse_selection(z)
    select_layer(first_z)

    sc1 = pdb.gimp_selection_save(j)
    z = clone_layer(light_z, n="Accent")
    z.mode = MODE_4[i]

    pdb.gimp_image_lower_item_to_bottom(j, z)

    z = add_wip_base("Grey", group)

    color_layer_default(z, (127, 127, 127))

    n = d[de.EDGE_MODE]
    z = pdb.gimp_image_merge_layer_group(j, group)

    set_layer_mode(z, get_mode({de.MODE: n}))
    _clear_selection()

    if n == "Burn":
        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)

    else:
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

    if d[de.POST_BLUR]:
        blur_z = copy_below(z, n="Post Blur", is_hide=False)

        pdb.gimp_image_remove_layer(j, z)

        z = blur_z

        blur_selection(z, d[de.POST_BLUR])
        _clear_selection()

    if d[de.COLORIZE]:
        z = copy_below(z, n="Colorify", is_hide=False, on_top=True)
        z.opacity = d[de.COLORIZE_OPACITY]

        pdb.plug_in_colorify(j, z, d[de.COLOR_1])

        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
        _clear_selection()

    for i in (sc, sc1):
        pdb.gimp_image_remove_channel(j, i)
    return z


class Decay(FrameBasic):
    kind = material = de.DECAY
    wrap_k = de.WRAP_DE

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
