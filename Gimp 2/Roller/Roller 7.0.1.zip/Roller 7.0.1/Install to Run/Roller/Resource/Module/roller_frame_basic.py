#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_identity import Identity as de
from roller_frame import do_frame_wrap
from roller_frame_alt import FrameBasic


class Basic(FrameBasic):
    is_embossed = True
    kind = material = de.BASIC
    wrap_k = de.WRAP

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        FrameBasic.__init__(
            self, any_group, super_maya, k_path, do_frame_wrap
        )
