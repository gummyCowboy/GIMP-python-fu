#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import GRADIENT_BLEND_RGB_PERCEPTUAL, pdb   # type: ignore
from roller_container import Cat, The
from roller_constant import Gradient as fg
from roller_constant_identity import Identity as de
from roller_gimp_context import set_fill_context_default, set_gimp_gradient
from roller_wip import get_factor_h, get_factor_w


def calc_gradient(color, color1, steps):
    """
    Calculate the color-steps for a gradient. A color-step
    is a value that is added to one color's components as
    a gradient for the color to become the second color.
    Each RGB color component has its own color-step value.

    color, color1: tuple
        RGB

    steps: float
        the number of steps

    Return: list
        [step value for each color component in a RGB or RGBA tuple]
    """
    # the number of color components, 'w'
    # Is three for RGB and four for RGBA.
    w = len(color)

    # [(RGBA or RGB), ...], 'q'
    q = [0] * w

    # Need the color distance to calculate a color step.
    if steps > 1.:
        for i in range(w):
            q[i] = (color1[i] - color[i]) / (steps - 1.)
    return q


def create_dual_gradient(n, left_color, right_color):
    """
    Create a GIMP gradient using two colors. The gradient has
    one segment where one color occupies the start and the
    other color occupies the end of the segment.
    The opacity of the gradient is 100%.

    n: string
        Name the gradient.

    left_color: tuple
        RGB

    right_color: tuple
        RGB

    Return: string
        Is the name GIMP gave the new gradient.
    """
    grad = pdb.gimp_gradient_new(n)

    Cat.gradient_list.append(grad)

    # segment index, '0'; end point opacity, '100.'
    pdb.gimp_gradient_segment_set_left_color(grad, 0, left_color, 100.)
    pdb.gimp_gradient_segment_set_right_color(grad, 0, right_color, 100.)

    return grad


def create_gradient(n, is_keep):
    """
    Create a GIMP gradient.

    n: string
        name of the gradient

    is_keep: bool
        If saving the gradient for reuse, then set to True.
    """
    if The.grad:
        pdb.gimp_gradient_delete(The.grad)
        The.grad = None

    grad = pdb.gimp_gradient_new(n)

    if is_keep:
        The.grad = grad
    return grad


def draw_gradient(z, d, x, y, x1, y1):
    """
    Paint a gradient.

    z: layer
        Receive gradient.

    d: dict
        Gradient Fill Preset

    x, y: float
        start point

    x1, y1: float
        end point

    Return: layer
        gradient
    """
    set_fill_context_default()
    pdb.gimp_context_set_gradient_blend_color_space(
        GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    set_gimp_gradient(d)
    pdb.gimp_context_set_gradient_reverse(d[de.REVERSE])
    pdb.gimp_drawable_edit_gradient_fill(
        z,
        fg.GRADIENT_TYPE_LIST.index(d[de.GRADIENT_TYPE]),
        d[de.OFFSET],
        1,                                  # yes, do super-sample
        3,                                  # max depth
        .06,                                # super-sample threshold
        1,                                  # yes, dither
        x, y,
        x1, y1
    )
    return z


def get_canvas_points(d):
    """
    Return layer points for start and end coordinates in the WIP context.

    d: dict
        Has start and end points.
        Has fixed and factored layer point tuples.

    Return:
        start and end coordinates
        x, y, x1, y1
    """
    # Add fixed and factored values.
    x = get_factor_w(d[de.START_X])
    y = get_factor_h(d[de.START_Y])

    # ColorFIll doesn't use end points.
    if de.END_X in d:
        x1 = get_factor_w(d[de.END_X])
        y1 = get_factor_h(d[de.END_Y])

    else:
        x1 = y1 = .0
    return x, y, x1, y1


def get_gradient_factors(d):
    """
    Get the factor points for a gradient
    given a gradient angle descriptor.

    The returned factor values are multiplied by a
    scale variable to arrive at an x, y point
    that is then used to plot a gradient direction.

    d: dict
        Has a GRADIENT_ANGLE Identity.

    Return: tuple
        of float
        start x, end x, start y, end y
        in .0 to 1.
    """
    n = d[de.GRADIENT_ANGLE]
    n1 = d.get(de.GRADIENT_TYPE)

    if n1 is None or n1 not in fg.SHAPED_TYPE_LIST:
        if n in fg.GRADIENT_XY_DICT:
            return fg.GRADIENT_XY_DICT[n]

    # shape-burst
    return .0, 1., .0, 1.


def get_gradient_points(d, x, y, w, h):
    """
    Calculate the start and end coordinates for a gradient.

    d: dict
        Has a GRADIENT_ANGLE Identity.

    x, y: numeric
        topleft gradient space offset

    w, h: numeric
        size of the gradient's space

    Return: tuple
        (float, ...)
        start x, end x, start y, end y
        0. to n
    """
    start_x, end_x, start_y, end_y = get_gradient_factors(d)
    start_x = x + start_x * w
    end_x = x + end_x * w
    start_y = y + start_y * h
    end_y = y + end_y * h
    return start_x, end_x, start_y, end_y
