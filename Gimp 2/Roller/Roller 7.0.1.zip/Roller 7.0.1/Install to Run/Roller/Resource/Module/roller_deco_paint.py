#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from roller_container import Cat, Deco, Run
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_gimp_context import set_foreground
from roller_preset import combine_seed
from roller_preset_brush import brush_stroke
from roller_utility import random_rgb


def paint_fringe(z, d, n):
    """
    Paint Fringe/Type material onto a
    layer with a provided selection limitation.

    z: layer
        Receive paint.

    d: dict
        Fringe Preset
    """
    def _do_multi_color():
        """
        Set the foreground color for the brush to use.
        Rotate through the multiple color option.
        """
        set_foreground(color_q[Deco.color_i])
        Deco.color_i = Deco.color_i + 1 \
            if Deco.color_i < max_i else 0

    def _do_random_colors():
        """
        Set the foreground color to a random color which the stroke brush uses.
        """
        pdb.gimp_context_set_foreground(random_rgb())

    j = Run.j
    if not pdb.gimp_selection_is_empty(j):
        e = d[rk.RW1][de.BRUSH_D]
        callback = None

        if n == de.MULTI_COLOR:
            color_q = d[de.COLOR_6]
            max_i = d[de.COLOR_COUNT] - 1

            if max_i:
                Deco.color_i = 0
                callback = _do_multi_color
            else:
                set_foreground(color_q[0])

        elif n == de.AS_IS:
            set_foreground(Cat.foreground)

        elif n == de.RANDOM_COLORS:
            callback = _do_random_colors

        combine_seed(e)
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_opacity(e[de.OPACITY])
        pdb.plug_in_sel2path(j, z)
        if j.active_vectors:
            for stroke in j.active_vectors.strokes:
                brush_stroke(z, e, e[de.BRUSH], stroke, callback)

            # Remove, from the image, the path created by 'plug_in_sel2path'.
            pdb.gimp_image_remove_vectors(j, j.active_vectors)
