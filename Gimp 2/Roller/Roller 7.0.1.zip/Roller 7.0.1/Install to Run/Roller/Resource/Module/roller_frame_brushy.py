#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from roller_constant import Frame as ek, Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_frame import do_frame_wrap, emboss_selection, sort_shadow_layer
from roller_gimp_image import (
    add_layer, check_matter, make_group_sub, make_group_wrap
)
from roller_gimp_layer import clear_selection, do_curves, select_layer
from roller_maya_add import AltAdd
from roller_maya_build import Build, SubBuild
from roller_maya_bulb import Bulb
from roller_maya_layer import check_mix_basic
from roller_maya_shadow import Shadow
from roller_preset import combine_seed
from roller_preset_brush import brush_stroke


def _make_group_brush(maya):
    """
    Make a Brush group layer. Is a
    sub-group of the super maya's group layer.

    maya: Maya
    Return: group layer
        Brush parent
    """
    return make_group_sub(maya, maya.super_maya.kind + " Brush")


def do_brush(maya):
    """
    Make a filler layer for the frame layer.

    maya: Brush
    Return: layer or None
        Brush output
    """
    j = Run.j
    d = maya.super_maya.value_d[rk.BRW][de.WRAP_AL]
    e = maya.value_d
    cast_z = maya.cast.matter

    # WIP layer will fail, so use the view-sized layer.
    z = add_layer(j, maya.group, maya.get_light(), "Material")

    select_layer(cast_z)
    pdb.plug_in_sel2path(j, cast_z)
    pdb.gimp_context_set_opacity(100.)

    if j.active_vectors:
        combine_seed(e)

        for stroke in j.active_vectors.strokes:
            brush_stroke(z, e, e[rk.BRW][de.BRUSH], stroke)

        select_layer(z)
        z = emboss_selection(z, d)

    if e[de.CLIP]:
        select_layer(cast_z)
        clear_selection(z)

    pdb.gimp_selection_all(j)
    return z


def do_matter(maya):
    """
    Make a Wrap layer.

    maya: BrushWrap
    Return: layer
        Wrap output
    """
    z = do_frame_wrap(maya)

    do_curves(z, (.0, .0, 1., .94))
    return z


class BrushWrap(SubBuild):
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )
    wrap_k = de.WRAP_AL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        # In its cast-Maya, Shadow/Inner looks for 'is_inward'.
        self.is_inward = self.was_inward = self.is_inward_change = False

        k_path = k_path + (rk.BRW, de.WRAP_AL)

        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (de.EMBOSS,)],
            do_matter
        )

        self.sub_maya[sm.ADD] = AltAdd(
            any_group, self, k_path + (de.ADD_ALT,)
        )
        self.sub_maya[sm.BULB] = Bulb(any_group, self, de.BRUSHY)

    def do(self, d, is_change, is_back):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        is_change: bool
            Is the state of the cast Maya's matter and/or mask.

        is_back: bool
            Is True if the background has changed.

        Return: bool
            Is True if the 'matter' layer changed.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change
        self.was_inward = self.is_inward
        self.is_inward = d.get(de.TYPE) in ek.INWARD_SET
        self.is_inward_change = m and (self.is_inward or self.was_inward)

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(d[de.ADD_ALT], m, m, is_back)
            self.sub_maya[sm.BULB].do(m)

        else:
            self.die()

        self.reset_issue()
        return m

    def set_inward(self, m):
        """
        Set the 'inward' state of the Wrap.

        m: bool
        """
        self.is_inward = m


class Brush(SubBuild):
    is_seeded = is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (_make_group_brush, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            Frame type

        k_path: tuple
            (Identity, ...)
            path to this sub-Frame option
        """
        k_path = k_path + (rk.BRW, de.BRUSH_D1)

        SubBuild.__init__(
            self, any_group, super_maya, [k_path, k_path + (rk.BRW,)], do_brush
        )

        self.sub_maya[sm.ADD] = AltAdd(
            any_group, self, k_path + (rk.BRW, de.ADD_ALT)
        )
        self.sub_maya[sm.BULB] = Bulb(any_group, self, de.BRUSHY_BRUSH)

    def do(self, d, is_change, is_back):
        """
        Manage layer output during a view run.

        d: dict
            Brushy's Brush Dialog Preset

        is_change: bool
            Is the state of the cast Maya's matter and/or mask.

        is_back: bool
            Is True if the background has changed.

        Return: bool
            Is True when there is layer change.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(d[rk.BRW][de.ADD_ALT], m, m, is_back)
            self.sub_maya[sm.BULB].do(m)

        else:
            self.die()

        self.reset_issue()
        return m


class Brushy(Build):
    is_seeded = is_embossed = True
    put = issue_q = ()
    kind = material = de.BRUSHY
    shade_row = rk.BRW

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity,)
            Is the key path to the responsible Frame Button.
        """
        Build.__init__(self, any_group, super_maya, k_path, None)

        self.is_emboss = None
        self.sub_maya[sm.WRAP] = BrushWrap(any_group, self, k_path)
        self.sub_maya[sm.FILLER] = Brush(any_group, self, k_path)
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group,
            self,
            (self.cast, self.sub_maya[sm.WRAP], self.sub_maya[sm.FILLER]),
            k_path + (rk.BRW, de.SHADOW,)
        )

    def do(self, d, is_change):
        """
        Manage layer output during a view run.

        d: dict
            Brushy Preset

        is_change: bool
            Is the state of the super-maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        wrap = self.sub_maya[sm.WRAP]

        self.realize()

        m = wrap.do(d[rk.BRW][de.WRAP_AL], is_change, is_back)
        if wrap.matter:
            # Brushy/Filler Preset dict, 'e'
            e = d[rk.BRW][de.BRUSH_D1]

            if not e[de.CLIP]:
                wrap.set_inward(True)

            m1 = self.sub_maya[sm.FILLER].do(e, is_change or m, is_back)
            m2 = self.sub_maya[sm.SHADOW].do(
                d[rk.BRW][de.SHADOW],
                is_change or wrap.is_inward_change,
                m or m1, wrap.group
            )
            sort_shadow_layer(
                self, m or m1 or m2, wrap.get_light(), wrap.matter
            )

        else:
            self.die()
        self.reset_issue()
