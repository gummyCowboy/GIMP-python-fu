#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE,
    FILL_PATTERN,
    LAYER_MODE_HARD_MIX,
    LAYER_MODE_LCH_COLOR,
    LAYER_MODE_OVERLAY,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_context import set_fill_context, set_gimp_pattern
from roller_deco_output import init_deco_type
from roller_def_access import get_default_d
from roller_gimp_image import add_wip_layer, clip_to_wip
from roller_gimp_layer import blur_selection, clone_layer, color_layer_default
from roller_gimp_selection import select_rect
from roller_maya_sub_accent import SubAccent
from roller_wip import Wip


def _merge(j, z):
    z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

    clip_to_wip(z)
    return z


def do_matter(maya):
    """
    Make a matter layer for SpecimenSpeckle.

    maya: SpecimenSpeckle
    Return: layer or None
        'matter'
    """
    def _do_gradient():
        _arg, _p = init_deco_type(de.GRADIENT, j, maya, group, e, 0, False)
        maya.rect = Wip.get_rect()

        select_rect(j, *maya.rect)
        return _p(*_arg)

    def _do_hard_mix(_pattern):
        """
        Create a hard mix layer.

        _pattern: string
            pattern descriptor

        Return: layer
            hard mix
        """
        _z = clone_layer(z, n="Hard Mix")
        _z.opacity = 50.
        _z.mode = LAYER_MODE_HARD_MIX

        set_gimp_pattern(_pattern)

        # x, y layer offset, '1'
        pdb.gimp_drawable_edit_bucket_fill(_z, FILL_PATTERN, .0, .0)

        _do_wind(_z)
        return _z

    def _do_overlay():
        """
        Create an overlay layer.

        Return: layer
            overlay
        """
        _z = clone_layer(z, n="Overlay")
        _z.opacity = 100.
        _z.mode = LAYER_MODE_OVERLAY

        # no linear, '0'
        pdb.gimp_drawable_invert(_z, 0)

        blur_selection(_z, 5)
        return _z

    def _do_wind(_z):
        """
        Do the wind function for each of the four directions.

        _z: layer
            Receive wind.
        """
        # the direction of wind, 'i'
        for i in (0, 1, 2, 3):
            pdb.plug_in_wind(
                j, _z,
                0,              # threshold
                i,
                25,             # strength
                1,              # blast
                1               # leading edge
            )

    j = Run.j
    d = maya.value_d
    parent, group = maya.init_background_groups(j)
    base = add_wip_layer("Base", group)
    maya.bg_z = None

    color_layer_default(base, d[de.COLOR_1])

    e = get_default_d(de.GRADIENT_FILL)
    e[de.GRADIENT] = d[rk.RW1][de.GRADIENT]
    e[de.GRADIENT_TYPE] = d[de.GRADIENT_TYPE]

    z = _do_gradient()
    z.opacity = d[de.GRADIENT_OPACITY]
    z = _do_overlay()
    z = _merge(j, z)

    e[de.GRADIENT_ANGLE] = de.BOTTOM_CENTER_TO_TOP_CENTER
    z = _do_gradient()
    z.opacity = d[de.GRADIENT_OPACITY]

    set_fill_context(
        {
            de.THRESHOLD: .6,
            de.FILL_OPACITY: 100.,
            de.FILL_MODE: "Normal",
            de.CRITERION: "Composite"
        }
    )

    e = d[rk.PAR]

    # pattern #1
    z = _do_hard_mix(e[de.PATTERN_1])
    z = _do_overlay()
    z = _merge(j, z)

    # pattern #2
    z = _do_hard_mix(e[de.PATTERN_2])
    z = _do_overlay()

    # pattern #3
    z = _do_hard_mix(e[de.PATTERN_3])

    _do_overlay()

    # phase two
    z = pdb.gimp_image_merge_layer_group(j, group)
    z1 = clone_layer(z)
    z2 = clone_layer(z1)

    clone_layer(z2)
    blur_selection(z1, 6)
    blur_selection(z2, 6)

    # no linear, '0'
    pdb.gimp_drawable_invert(z1, 0)

    z = pdb.gimp_image_merge_layer_group(j, parent)
    z = z1 = clone_layer(z, n="Hard Mix")
    z.mode = LAYER_MODE_HARD_MIX
    z = clone_layer(z, n="LCH Color")
    z.mode = LAYER_MODE_LCH_COLOR

    pdb.plug_in_colorify(j, z, d[de.COLOR_1])
    pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
    return maya.finish(
        pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE), d[rk.RW1]
    )


class SpecimenSpeckle(SubAccent):
    """Create Accent output."""
    kind = de.SPECIMEN_SPECKLE

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
