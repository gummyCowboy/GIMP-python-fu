#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_container import Dog
from roller_constant import Define as df
from roller_constant_identity import Identity as de
from roller_port_preview import PortPreview
from roller_step import connect_sub_str
from roller_widget_dna import DNA

TRUE_ATTR_SET = {'make_preset', 'make_vbox', 'preset', 'switched'}


class PortOptionList(PortPreview):
    """Factor Accent and Frame Port."""
    window_key = de.OPTION_LIST

    def __init__(self, d, g, k):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Has option values.

        k: string
            Preset key
        """
        self._preset_key = k
        self._init_value_d = deepcopy(g.get_a())
        PortPreview.__init__(self, d, g)

    def _draw_option_list(self, vbox):
        """
        Draw the OptionList Widget group.

        vbox: GTK container
            Receive Widget group.
        """
        dna = DNA(self._preset_key, TRUE_ATTR_SET, {})

        dna.inherit(self.repo.any_group.dna, False)
        vbox.add(dna.vbox)

        d = {
            df.COLOR: self.color,
            df.DNA: dna,
            df.RELAY: [self.on_port_change],
            df.ROLLER_WIN: self.roller_win,
            df.TYPE_STEP_K: connect_sub_str(
                self.repo.any_group.type_step_k, self._preset_key
            )
        }
        self.any_group = Dog.many_group(**d)
        self.any_group.load_widget_d(self._init_value_d)

    def draw(self):
        """Draw Widget."""
        self.is_dirt = True
        self.draw_column((self._draw_option_list, self.draw_process))

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return self.on_cancel_port_preview, self.on_accept_port_preview

    def get_group_value(self):
        """
        Get the value of AnyGroup Widget.

        Return: dict
            Frame Preset
        """
        return self.any_group.extract_widget_d()


class PortFrame(PortOptionList):
    """Display a Frame-type server."""
    window_key = de.FRAME

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Is responsible.
        """
        PortOptionList.__init__(self, d, g, de.FRAME)
