#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_constant import Shape as sh, Signal as si, Triangle as ft
from roller_constant_identity import Identity as de
from roller_gimp_layer import remove_layer
from roller_many_handle import Handle
from roller_model_goo import Goo
from roller_model_name import ModelName
from roller_ring import Ring
from roller_image_render import Render
from roller_polygon import (
    ROUTE_BOX, ROUTE_POG, ROUTE_SHAPE, invert_triangle
)
from roller_preset import calc_margin, calc_shift_rect
from roller_step import find_cell_margin, get_cell_shift
import gobject       # type: ignore

# Order by a chain of responsibility and dependence.
# Use with a Cell branch Model.
CELL_CHAIN = (
    si.RECTANGLE_CHANGE,
    si.RECTANGLE_CALC,
    si.CELL_RECT_CHANGE,
    si.CELL_RECT_CALC,
    si.CELL_SHIFT_CHANGE,
    si.CELL_SHIFT_CALC,
    si.CELL_MARGIN_CHANGE,
    si.CELL_MARGIN_CALC
)


def get_main_q(d, q):
    """
    Produce a list of the main option settings' from
    a Model key list and a Preset dict.

    d: dict
        Preset that has a Per Cell option.

    q: list
        [(r, c) or (r, c, face), ...]

    Return: list
        list of (r, c) or (r, c, face) sorted in reverse order
        [(row, column)]
    """
    per = d[de.PER]

    if per:
        return [k for k in q if k not in per]
    return q


class Past(gobject.GObject, object):
    """Remember the state of Model variables from the last view run."""

    # Are signals that can be emitted by this class.
    __gsignals__ = si.PAST_DICT

    def __init__(self, model):
        """
        model: Model
        """
        self._goo_q = [{}, {}]
        self._grid = [(0, 0), (0, 0)]

        gobject.GObject.__init__(self)

        self._model = model
        for i in (
            (si.CELL_MARGIN_VIEW, self.on_cell_margin_view),
            (si.CELL_RECT_VIEW, self.on_cell_rect_view),
            (si.CELL_SHIFT_VIEW, self.on_cell_shift_view)
        ):
            self.connect(*i)

    def _did_grid(self):
        """
        Did the Model's row and column count change?

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        return [self._grid[i] != self._model.grid for i in range(2)]

    def did_cell(self, k):
        """
        Did Cell rectangle change?

        k: tuple
            (row, column)
            cell index
            key to cell

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_grid()
        a = self._goo_q
        b = self._model.goo_d[k].cell.rect
        b1 = self._model.goo_d[k].plaque

        # Plan and Work, '2'
        for i in range(2):
            if not vote_q[i]:
                if k in a[i]:
                    # Goo, 'a1'
                    a1 = a[i][k]
                    vote_q[i] = a1.cell.rect != b or a1.plaque != b1
                else:
                    vote_q[i] = True
        return vote_q

    def did_cell_pocket(self, k):
        """
        Did Cell pocket change?

        k: tuple
            cell index

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_grid()
        a = self._goo_q

        # Goo, 'b, a1'
        b = self._model.goo_d[k]

        for i in range(2):
            if not vote_q[i]:
                if k in a[i]:
                    a1 = a[i][k]
                    vote_q[i] = a1.shape != b.shape
                else:
                    vote_q[i] = True
        return vote_q

    def did_cell_shift(self, r_c):
        """
        Did Cell Shift change?

        r_c: tuple
            cell index

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_grid()
        a = self._goo_q
        b = self._model.goo_d[r_c]

        for i in range(2):
            if not vote_q[i]:
                if r_c in a[i]:
                    # Goo, 'a1'
                    a1 = a[i][r_c]
                    vote_q[i] = (
                        a1.plaque != b.plaque or a1.shift.rect != b.shift.rect
                    )
                else:
                    vote_q[i] = True
        return vote_q

    def did_merged(self, r_c):
        """
        Did Cell merged change?

        r_c: tuple
            zero-based cell index and key
            (row, column)

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_grid()
        a = self._goo_q
        b = self._model.goo_d[r_c]

        for i in range(2):
            if not vote_q[i]:
                if r_c in a[i]:
                    vote_q[i] = a[i][r_c].merged.rect != b.merged.rect
                else:
                    vote_q[i] = True
        return vote_q

    def on_cell_margin_view(self, _, i):
        """
        Respond to a Cell/Margin view by recording its state.

        _: Past
            Sent the Signal.

        i: int
            plan or work; view-type index; 0 or 1
        """
        d = self._goo_q[i]

        # (row, column), Goo; 'k, a'
        for k, a in self._model.goo_d.items():
            d[k].pocket.rect = a.pocket.rect
            d[k].shape = a.shape

    def on_cell_rect_view(self, _, i):
        """
        Respond to a Cell/Type view by recording its variables.

        _: Past
            Sent the Signal.

        i: int
            plan or work; view-type index; 0 or 1
        """
        self._grid[i] = self._model.grid
        d = self._goo_q[i] = {}

        # (row, column), Goo; 'k, a'
        for k, a in self._model.goo_d.items():
            d[k] = Goo(k)
            d[k].cell.rect = a.cell.rect
            d[k].merged.rect = a.merged.rect

    def on_cell_shift_view(self, _, i):
        """
        Respond to a Cell/Shift view by recording its variables.

        _: Past
            Sent the Signal.

        i: int
            plan or work; view-type index; 0 or 1
        """
        d = self._goo_q[i]

        # (row, column), Goo; 'k, a'
        for k, a in self._model.goo_d.items():
            d[k].shift.rect = a.shift.rect


class CellPast(Past):
    """
    Record a Cell-branch Model's view run state for change determination.
    """
    def __init__(self, model):
        self._rectangle = [None, None]

        Past.__init__(self, model)
        self.connect(si.RECTANGLE_VIEW, self.on_rectangle_view),

    def did_rectangle(self, rectangle):
        """
        Did the Cell/Rectangle change?

        pocket: Rect
            Compare with the viewed value.

        Return: list
            [Plan vote, Work vote]
            where a True vote is change
        """
        q = []

        for i in range(2):
            if self._rectangle[i]:
                q.append(rectangle != self._rectangle[i])
            else:
                q.append(True)
        return q

    def on_rectangle_view(self, _, i):
        """
        Respond to a Rectangle view by recording its state.

        _: Past
            Sent the Signal.

        i: int
            plan or work; view-type index; 0 or 1
        """
        self._rectangle[i] = self._model.rectangle


class Baby(gobject.GObject, object):
    """
    Accept Model type signal.
    Call from Ring when the interface is idle
    and after a Preset has finished loading.
    Send Signal ordered by a chain of responsibility.
    """
    # Reference
    #   github.com/sebp/PyGObject-Tutorial/blob/master/source/objects.txt
    #   library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
    #   zetcode.com/gui/pygtk/signals/
    #   stackoverflow.com/questions/66730/how-do-i-create-a-new-signal-in-pygtk

    # Are signals that can be emitted by this class.
    __gsignals__ = si.MODEL_DICT

    def __init__(self, chain):
        """
        chain: tuple
            (Signal, ...)
            Signal are sent from the beginning of the chain first.
            A signal handler will often add more signals to Baby.
        """
        # for custom signal(s)
        gobject.GObject.__init__(self)

        self._chain = chain

        # The chain of responsibility is processed in an orderly manner.
        # {Signal: value}
        self.signal_d = {}

        # Subscribe to idle processing.
        Ring.carry(self)

    def feed(self, signal, arg):
        """
        Emit a Signal after removing it from the Signal dict.

        signal: Signal
        arg: value
        """
        if signal in self.signal_d:
            self.signal_d.pop(signal)
        self.emit(signal, arg)

    def give(self, k, arg):
        """
        Add a Model Signal for later emission.

        k: string
            Signal type

        arg: value
        """
        if k in self._chain:
            self.signal_d[k] = k, arg

    def pressure(self):
        """Send Signal until the Signal dict is clear."""
        sending = True
        while sending:
            sending = False
            q = self.signal_d.keys()
            if q:
                for i in self._chain:
                    if i in q:
                        signal, arg = self.signal_d[i]

                        self.signal_d.pop(i)
                        self.emit(signal, arg)

                        # The signal dict can change after sending a signal.
                        sending = True
                        break

    def turn(self):
        """Send out a Signal found in Signal dict."""
        q = self.signal_d.keys()
        if q:
            # Signal emission is ordered by a responsibility chain.
            for i in self._chain:
                if i in q:
                    signal, arg = self.signal_d[i]

                    self.signal_d.pop(i)
                    self.emit(signal, arg)
                    break


class Model(Handle):
    """Factor Model type."""

    def __init__(self, model_name, past, chain):
        """
        model_name: string
            Identify the Model in ModelName and interface.

        past: object
            Record a snap-shot of a view run.

        chain: tuple
            of Signal ordered by a chain of responsibility
        """
        Handle.__init__(self)

        self._image_sel_d = {}
        self._caption_sel_d = {}
        self.cell_q = []
        self.goo_d = {}
        self.route_i = self.cell_shape = self.cell_type_d = None
        self.is_alt = \
            self.is_polygon = \
            self.is_triangle = \
            self.is_rectangle = \
            self.is_equilateral = False

        # (padding width, ...) for a (row, column, face) Per group
        self.per_padding = 0, 0, 0

        # [Plan output's Model group layer, Work output's Model group layer]
        self.group_layer_list = [None, None]

        self.model_name = model_name

        ModelName.add(model_name, self)

        self.grid = 0, 0
        self.past = past(self)
        self.baby = Baby(chain)

        for i, p in (
            (si.CELL_MARGIN_CHANGE, self.on_cell_margin_change),
            (si.CELL_RECT_CHANGE, self.on_cell_rect_change),
            (si.CELL_SHIFT_CHANGE, self.on_cell_shift_change)
        ):
            self.latch(self.baby, (i, p))

        Ring.gob.emit(si.MODEL_CREATED, self)
        Render.gob.connect(si.CLOSE_VIEW_IMAGE, self.on_close_view_image)

    def adapt_cell_shape(self, r_c):
        """
        A triangle Cell shape is inverted with every other cell.
        An alt-parallelogram shape is inverted with every odd row.

        r_c: tuple
            (row, column)
            zero-based Goo key

        Return: string
            cell shape
        """
        n = self.cell_shape

        if self.is_triangle:
            if invert_triangle(*r_c):
                return ft.INVERTED_DICT[n]
            return n

        elif self.is_alt:
            # On every odd row, switch parallelogram.
            if r_c[0] % 2:
                return sh.ALT_PARALLELOGRAM_DICT[n]
        return n

    def adapt_missing_cell_step(self, is_sequence):
        """
        Check Cell/Shift and Cell/Margin to see
        if its step is missing. If so, then set
        the default value for the property.

        is_sequence: bool
            If True, then the chain of responsibility
            sequence is calculated immediately.
        """
        d = get_cell_shift(self.model_name)

        if not d:
            self.set_default_shift(d, is_sequence)
            if not find_cell_margin(self.model_name):
                self.set_default_pocket(is_sequence)

    def calc_cell_pocket(self, d, k):
        """
        Calculate the pocket rectangle and shape polygon for Per.

        d: dict
            Margin Preset
            {Identity: value}

        k: tuple
            cell key
            (row, column)

        Return: list
            [Plan vote, Work vote]
            A True vote is vote for change.
        """
        q = calc_margin(d)
        is_margin = any(q)
        return self.calc_pocket(is_margin, q, k)

    def calc_cell_shift(self, d, k):
        """
        Update the Cell/Shift rectangle and 'plaque'
        polygon for a Cell given a Shift Preset
        and a previously calculated 'form' polygon.

        d: dict
            Shift Preset

        k: tuple
            Goo key

        Return: list
            [Plan vote, Work vote]
            Has vote on cell's Shift change since the last view run.
        """
        x, y, w, h = calc_shift_rect(d)

        # Goo, 'a'
        a = self.goo_d[k]
        x1, y1, w1, h1 = a.merged.rect
        a.shift.rect = x + x1, y + y1, w + w1, h + h1

        # Define polygon point before margin, 'plaque'.
        if any((x, y, w, h)):
            # Calculate the polygon with the Shift rectangle, 'plaque'.
            i = self.route_i
            n = self.adapt_cell_shape(k)

            if i == 0:
                a.plaque = ROUTE_SHAPE[n](a.shift)

            elif i == 1:
                a.plaque = ROUTE_POG[n](
                    a.shift, self.cell_type_d.get(de.PARALLELOGRAM_SCALE)
                )
            else:
                a.plaque = ROUTE_BOX[n](self, a, a.shift, self.cell_type_d)
                a.shift_cap_x, a.shift_cap_y = a.cap_x, a.cap_y

        else:
            a.plaque = a.form

            # Box index, '2'
            if self.route_i == 2:
                a.cap_x, a.cap_y = a.form_cap_x, a.form_cap_y
        return self.past.did_cell_shift(k)

    def calc_main_cell_pocket(self, arg):
        """
        Calculate the 'pocket' rectangle and 'shape' polygon for main Cell.

        arg: tuple
            (Cell/Margin Preset, is sequence flag)
            ({Identity: value}, bool)
        """
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        q = calc_margin(d)
        is_margin = any(q)
        per = d[de.PER]
        vote_d = {}

        for k in self.cell_q:
            if k in per:
                vote_d[k] = self.calc_cell_pocket(per[k], k)
            else:
                vote_d[k] = self.calc_pocket(is_margin, q, k)
        p(si.CELL_MARGIN_CALC, vote_d)

    def calc_main_cell_shift(self, arg):
        """
        Update the Cell/Shift rectangle for main Cell given a Shift Preset.

        arg: tuple
            (Shift Preset, is sequence flag)
        """
        vote_d = {}
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        per = d[de.PER]

        for r_c in self.cell_q:
            if r_c in per:
                vote_d[r_c] = self.calc_cell_shift(per[r_c], r_c)
            else:
                vote_d[r_c] = self.calc_cell_shift(d, r_c)

        p(si.CELL_SHIFT_CALC, vote_d)
        if not find_cell_margin(self.model_name):
            self.set_default_pocket(is_sequence)

    def calc_pocket(self, is_margin, q, k):
        """
        Update the 'pocket' rectangle and 'shape' polygon for a cell.

        is_margin: bool
            Is True if the cell has a margin.

        q: tuple
            (top, bottom, left, right) of float
            margin span

        k: tuple
            Goo key
            (row, column)
            zero-based grid index

        Return: iterable
            [Plan vote, Work vote]
            A vote is True if the 'pocket' or 'shape' changed value.
        """
        # Goo instance, 'a'
        a = self.goo_d[k]

        top, bottom, left, right = q
        x, y, w, h = a.shift.rect

        if is_margin:
            x += left
            y += top
            w = max(1., w - left - right)
            h = max(1., h - top - bottom)

        a.pocket.rect = x, y, w, h

        if is_margin:
            # Calculate the polygon within the margin, 'shape'.
            i = self.route_i
            n = self.adapt_cell_shape(k)

            # There's a timing issue with 'adapt_cell_shape' for 'n'.
            if n:
                if i == 0:
                    a.shape = ROUTE_SHAPE[n](a.pocket)

                elif i == 1:
                    a.shape = ROUTE_POG[n](
                        a.pocket, self.cell_type_d.get(de.PARALLELOGRAM_SCALE)
                    )
                else:
                    a.shape = ROUTE_BOX[n](self, a, a.pocket, self.cell_type_d)

        else:
            a.shape = a.plaque

            # Box index, '2'
            if self.route_i == 2:
                a.cap_x, a.cap_y = a.shift_cap_x, a.shift_cap_y
        return self.past.did_cell_pocket(k)

    def die(self):
        """Delete the Model. Remove some connections."""
        self.unlatch()

        for z in self.group_layer_list:
            remove_layer(z)

        self.group_layer_list = [None, None]

        Ring.drop(self.baby)
        ModelName.delete(self.model_name)

    def get_caption_y(self, k):
        """
        Get a Caption Text selection.

        k: value
            Goo or Map key

        Return: tuple
            (position y, height of Caption text)
        """
        return self._caption_sel_d.get(k)

    def get_equilateral_type(self):
        """
        Determine if the cell shape has equal side length.

        Return: bool
            Is True if the cell shape is equilateral.
        """
        return self.cell_shape in sh.EQUILATERAL_TYPE_LIST

    def get_image_sc(self, k):
        """
        Get an image selection from its assignment.

        k: value
            Goo or Map key

        Return: Gimp selection reference or None
        """
        return self._image_sel_d.get(k)

    def get_main_cell_list(self, d):
        """
        Produce a list of the main option settings' cell index.

        d: dict
            A Preset that has a Per Cell option.

        Return: list
            list of (r, c) sorted in reverse order
            [(row, column)]
        """
        return get_main_q(d, self.cell_q)

    def get_merge_rect(self, k):
        """
        Get the cell rectangle from a cell's 'merged' value.

        k: int
            (row, column)
            (row, column, face/facing)
            zero-based cell index

        Return: tuple
            the rectangle of the cell post 'merged'
            x, y, w, h
        """
        return self.goo_d[k].merged.rect

    def get_plaque(self, k):
        """
        Get a cell's 'plaque' value.

        k: tuple
            (row, column)
            zero-based cell index
            Goo key

        Return: tuple
            Draw a 'plaque' polygon.
        """
        return self.goo_d[k].plaque

    def get_pocket_rect(self, k):
        """
        Get the cell 'pocket'.

        k: tuple
            Goo key
            (row, column)
            zero-based cell index

        Return: tuple
            (x, y, w, h)
            the rectangle of the cell within margin
        """
        return self.goo_d[k].pocket.rect

    def get_shape(self, k):
        """
        Get a Cell's 'shape' tuple.

        k: tuple
            Goo key
            (row, column)
            zero-based cell index

        Return: object
            Draw a 'shape' polygon.
        """
        return self.goo_d[k].shape

    def get_shift_rect(self, k):
        """
        Get the Cell/Shift rectangle.

        k: tuple
            Goo key
            (row, column)
            zero-based cell index

        Return: tuple
            (x, y, w, h)
            the rectangle of the shifted cell
        """
        return self.goo_d[k].shift.rect

    def on_cell_margin_change(self, _, arg):
        """
        Respond to change in the main Cell/Margin.

        _: Baby
            Sent the Signal.

        arg: tuple
            (Shift Preset, is sequence flag)
        """
        self.calc_main_cell_pocket(arg)

    def on_cell_rect_change(self, _, arg):
        """
        Respond to change in the Cell/Type.

        _: Baby
            Sent the Signal.

        arg: tuple
            (Cell/Type Preset, is sequence flag)
            {Identity: value}
        """
        self.update_type(arg)

    def on_cell_shift_change(self, _, arg):
        """
        Respond to change in the main Cell/Shift.

        _: Baby
            Sent the signal.

        arg: dict
            Shift Preset
        """
        self.calc_main_cell_shift(arg)

    def on_close_view_image(self, *_):
        """Reset Model's group layer reference."""
        # Plan and Work both have a Model group layer.
        self.group_layer_list = [None, None]

    def set_caption_y(self, k, q):
        """
        Save a Caption Text's properties.

        k: value
            key to the Caption properties

        q: tuple
            (position y, height of Caption text)
        """
        self._caption_sel_d[k] = q

    def set_default_pocket(self, is_sequence):
        """
        Set the Cell 'pocket' to the Cell/Shift rectangle.
        Calc the Cell shape using Cell/Shift rectangle.

        is_sequence: bool
            If True, then the chained-sequence is calculated immediately.
        """
        vote_d = {}
        p = self.baby.feed if is_sequence else self.baby.give

        for r_c in self.cell_q:
            vote_d[r_c] = self.calc_pocket(False, (0, 0, 0, 0), r_c)
        p(si.CELL_MARGIN_CALC, vote_d)

    def set_default_shift(self, d, is_sequence):
        """
        Set the Cell/Shift to the Cell 'merged' rectangle.
        Calc the Cell 'plaque' using the same rectangle.

        d: dict
            Cell/Shift Preset

        is_sequence: bool
            If True, then the sequence is calculated immediately.
        """
        vote_d = {}
        p = self.baby.feed if is_sequence else self.baby.give

        for r_c in self.cell_q:
            vote_d[r_c] = self.calc_cell_shift(d, r_c)
        p(si.CELL_SHIFT_CALC, vote_d)

    def set_image_sc(self, j, k):
        """
        Store an image selection as a channel.

        j: Gimp image
            Has selection.

        k: value
            Goo or Map key
        """
        # Gimp selection channel, 'a'
        a = self._image_sel_d.get(k)

        if a:
            if pdb.gimp_item_is_valid(a):
                pdb.gimp_image_remove_channel(j, a)
        self._image_sel_d[k] = pdb.gimp_selection_save(j)

    def set_cell_shape(self, n):
        """
        Set the value of the 'self.cell_shape', and set
        the value of the cell-shape's calculator-dict index.
        The index is used by polygon calculator routing.

        n: string
            cell shape descriptor and key to polygon calculator
        """
        self.cell_shape = n

        if ROUTE_SHAPE.get(n):
            self.route_i = 0

        elif ROUTE_POG.get(n):
            self.route_i = 1
        else:
            self.route_i = 2

    def set_per_padding(self):
        """
        Set the padding width for a Per group layer's 'row.column.face' format.
        """
        # row index, '0'; column index, '1'; face is always zero, '0'
        self.per_padding = len(str(self.grid[0])), len(str(self.grid[1])), 0

    def update_type(self, arg):
        """
        Update common Model variable for Cell/Type.

        arg: tuple
            (Cell/Type Preset, is sequence flag)

        Return: list
            [Plan vote, Work vote]
            where a True vote is change
        """
        d = self.cell_type_d = arg[0]
        self.is_equilateral = self.get_equilateral_type()
        self.is_rectangle = self.cell_shape == de.RECTANGLE
        self.is_alt = self.cell_shape in sh.ALT_PARALLELOGRAM_DICT
        self.is_triangle = self.cell_shape in ft.TRIANGLE_LIST
        self.is_polygon = self.cell_shape not in sh.CURVED_SET

        self.calc_grid(d)
        self.init_cell_q(d)
        self.set_per_padding()
        return self.init_model_cell(d)


# Register the custom signals.
gobject.type_register(Baby)
