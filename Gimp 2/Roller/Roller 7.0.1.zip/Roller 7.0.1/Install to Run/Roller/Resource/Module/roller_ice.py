#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from roller_container import Run


def freeze():
    if Ice.is_hide_layer and not Ice.is_froze:
        pdb.gimp_image_freeze_layers(Run.j)
        Ice.is_froze = 1


def thaw():
    if Ice.is_froze:
        pdb.gimp_image_thaw_layers(Run.j)
        Ice.is_froze = 0


class Ice:
    """
    Record a View run's layer thaw and freeze state, along with
    the Global option's trigger value for layer freezing.
    """
    is_froze = is_hide_layer = 0
