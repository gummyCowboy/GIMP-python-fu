#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Back, Run
from roller_image_change import ref_on_view_run
from roller_helm import Helm
from roller_preset import find_visible_preset
from roller_preset_last_used import LastUsed
from roller_ring import Ring
from roller_view_plan import do_plan_step
from roller_view_work import do_work_step


class View:
    """Route view-run-type ProcessButton action to produce rendered output."""
    first = [0, 0]
    last = [0, 0]

    @staticmethod
    def _run_planner():
        """Call the plan-view-type output loop."""
        Run.i = 0                     # plan-view-type index, '0'
        do_plan_step(View.get_first(0), View.get_last(0))

    @staticmethod
    def _run_worker():
        """Call the work-view-type output loop."""
        Run.i = 1                     # work index, '1'
        do_work_step(View.get_first(1), View.get_last(1))

    @staticmethod
    def _set_last_to_visible_group(view_i):
        """
        Set the 'last' index using the index of the visible AnyGroup.
        Set the index so that the visible AnyGroup is processed.

        view_i: int
            plan or work view-type View-type
        """
        name_step_k = find_visible_preset()
        i = Helm.step_list.index(name_step_k) + 1

        first = View.get_first(view_i)

        if i <= first:
            i = first + 1
        View.set_last(view_i, i)

    @staticmethod
    def _set_last_item_index(view_i):
        """
        Set the 'last' index to the length of the step list.
        """
        View.set_last(view_i, len(Helm.step_list))

    @staticmethod
    def do_draft():
        """Is a plan-view-type run that stops on the active Preset AnyGroup."""
        View._set_last_to_visible_group(0)

        first = View.last[0]

        View._run_planner()
        View.set_first(0, first)

    @staticmethod
    def do_peek():
        """Is a work-view-type run that stops on the active Preset AnyGroup."""
        Run.is_preview = True
        View._set_last_to_visible_group(1)

        first = View.last[1]

        View._run_worker()
        View.set_first(1, first)
        Back.i = first

    @staticmethod
    def do_plan():
        """Call to do a Plan view run."""
        View._set_last_item_index(0)
        View._run_planner()

    @staticmethod
    def do_preview():
        """
        Make a work-view-type run that stops after
        completing each step in the navigation tree.
        """
        Run.is_preview = True

        View._set_last_item_index(1)
        View._run_worker()

    @staticmethod
    def do_render():
        """
        Make a final work-view-type run and
        write the session's Steps SuperPreset.
        """
        Run.is_preview = False

        View._set_last_item_index(1)
        View._run_worker()
        LastUsed.write()

    @staticmethod
    def get_first(view_i):
        return View.first[view_i]

    @staticmethod
    def get_last(view_i):
        return View.last[view_i]

    @staticmethod
    def on_group_change(any_group):
        """
        When there's Group change, the first index changes.

        any_group: AnyGroup
            There was option change.

        view_i: int
            plan or work view-type

        arg: None
        """
        q = Helm.any_group_list
        if any_group in q:
            i = q.index(any_group)
            for i1 in range(2):
                if i < View.get_first(i1):
                    View.set_first(i1, i)

    @staticmethod
    def run(run_index):
        """
        Respond to a view-run-type ProcessButton action.

        view_index: int
            Identify the view response.
            Plan, Preview, Draft, Peek
        """
        Ring.pressure()
        ref_on_view_run()
        VIEW_ROUTE[run_index]()

        view_i = VIEW_INDICES[run_index]

        View.set_first(view_i, View.get_last(view_i))
        Run.is_back = False

    @staticmethod
    def set_first(view_i, a):
        View.first[view_i] = a

    @staticmethod
    def set_last(view_i, a):
        View.last[view_i] = a


VIEW_ROUTE = [
    View.do_plan,
    View.do_preview,
    View.do_draft,
    View.do_peek,
    View.do_render
]
VIEW_INDICES = 0, 1, 0, 1, 1
