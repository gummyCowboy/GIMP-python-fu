#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import FILL_PATTERN, pdb  # type: ignore
from roller_container import Run
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_gimp_context import set_fill_context, set_gimp_pattern
from roller_maya_sub_accent import SubAccent


def do_matter(maya):
    """
    Make a matter layer.

    maya: PatternFill
    Return: layer
        'matter'
    """
    d = maya.value_d
    z = maya.bg_z
    maya.bg_z = None

    pdb.gimp_image_reorder_item(Run.j, z, maya.group, 0)
    set_fill_context(d)
    set_gimp_pattern(d[rk.RW1][de.PATTERN])
    pdb.gimp_drawable_edit_bucket_fill(z, FILL_PATTERN, .0, .0)
    return maya.finish(z, d[rk.RW1])


class PatternFill(SubAccent):
    """Create Accent output."""
    kind = de.PATTERN_FILL

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
