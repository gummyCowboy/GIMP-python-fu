#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_INTERSECT, CHANNEL_OP_SUBTRACT, pdb
)
from roller_constant_identity import Identity as de
from roller_gimp_layer import select_layer
from roller_gimp_selection import get_select_bounds, select_rect


def do_angular(j, z, w):
    """
    Select wrap item before calling.

    j: Gimp Image
    z: layer or None
        Subtract from selection.

    w: float
        Frame width

    Return: state of selection
    """
    pdb.gimp_context_set_antialias(0)

    for _ in range(int(w)):
        pdb.gimp_selection_grow(j, 1)
    if z:
        select_layer(z, option=CHANNEL_OP_SUBTRACT)


def do_angular_channel(j, sc, w):
    """
    Select wrap item before calling.

    j: Gimp Image
    sc: selection channel or None
        Subtract from selection.

    w: float
        Frame width

    Return: state of selection
    """
    pdb.gimp_context_set_antialias(0)

    for _ in range(int(w)):
        pdb.gimp_selection_grow(j, 1)
    if sc:
        pdb.gimp_image_select_item(j, CHANNEL_OP_SUBTRACT, sc)


def do_inside(j, z, w):
    """
    Select wrap item before calling.

    j: Gimp Image
    z: layer
        Intersect with selection.

    w: float
        Frame width

    Return: state of selection
    """
    pdb.gimp_selection_border(j, int(w))
    select_layer(z, option=CHANNEL_OP_INTERSECT)


def do_inside_channel(j, sc, w):
    """
    Select wrap item before calling.

    j: Gimp Image
    sc: selection channel
        Intersect with selection.

    w: float
        Frame width

    Return: state of selection
    """
    pdb.gimp_selection_border(j, int(w))
    pdb.gimp_image_select_item(j, CHANNEL_OP_INTERSECT, sc)


def do_overlap(j, _, w):
    """
    Select wrap item before calling.

    j: Gimp Image
    _: layer
    w: float
        Frame width

    Return: state of selection
    """
    pdb.gimp_selection_border(j, int(w))


def do_rectangle(j, z, w):
    """
    Select wrap item before calling.

    j: Gimp Image
    z: layer or None
        Subtract from selection.

    w: float
        Frame width

    Return: state of selection
    """
    is_sel, x, y, x1, y1 = get_select_bounds(j)

    if is_sel:
        select_rect(j, x - w, y - w, x1 + w + w - x, y1 + w + w - y)
        if z:
            select_layer(z, option=CHANNEL_OP_SUBTRACT)


def do_rectangle_channel(j, sc, w):
    """
    Select wrap item before calling.

    j: Gimp Image
    sc: selection channel or None
        Subtract from selection.

    w: float
        Frame width

    Return: state of selection
    """
    is_sel, x, y, x1, y1 = get_select_bounds(j)
    if is_sel:
        select_rect(j, x - w, y - w, x1 + w + w - x, y1 + w + w - y)
        if sc:
            pdb.gimp_image_select_item(j, CHANNEL_OP_SUBTRACT, sc)


def do_rounded(j, z, w):
    """
    Select wrap item before calling.

    j: Gimp Image
    z: layer
        Subtract from selection.

    w: float
        Frame width

    Return: state of selection
    """
    if w == 1:
        # The border selection function fails when the width is '1'.
        do_angular(j, z, w)
    else:
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_selection_border(j, int(w))
        select_layer(z, option=CHANNEL_OP_SUBTRACT)


def do_rounded_channel(j, sc, w):
    """
    Select wrap item before calling.

    j: Gimp Image
    sc: selection channel
        Subtract from selection.

    w: float
        Frame width

    Return: state of selection
    """
    if w == 1:
        # The border selection function fails when the width is '1'.
        do_angular_channel(j, sc, w)
    else:
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_selection_border(j, int(w))
        pdb.gimp_image_select_item(j, CHANNEL_OP_SUBTRACT, sc)


# {Frame Type: grow frame-type function}
EXPAND_ROUTE = {
    de.ANGULAR: do_angular,
    de.INSIDE: do_rounded,
    de.OVERLAP: do_rounded,
    de.RECTANGLE: do_rectangle,
    de.ROUNDED: do_rounded
}
WRAP_ROUTE = {
    de.ANGULAR: do_angular,
    de.INSIDE: do_inside,
    de.OVERLAP: do_overlap,
    de.RECTANGLE: do_rectangle,
    de.ROUNDED: do_rounded
}
CHANNEL_ROUTE = {
    de.ANGULAR: do_angular_channel,
    de.INSIDE: do_inside_channel,
    de.OVERLAP: do_overlap,
    de.RECTANGLE: do_rectangle_channel,
    de.ROUNDED: do_rounded_channel
}


def expand_wrap(j, z, w, n):
    """
    Expand a Wrap selection depending on the Wrap/Type.
    Select wrap item before calling.

    j: Gimp Image
        Has selection.

    z: layer
        Has cast.

    w: float
        expansion amount

    n: string
        Wrap Type
    """
    EXPAND_ROUTE[n](j, z, w)


def grow_wrap(j, z, w, n):
    """
    Expand a Wrap selection depending on the Wrap/Type.
    Select wrap item before calling.

    j: Gimp Image
        Has selection.

    z: layer
        Has cast.

    w: float
        expansion amount
        Zero is allowed by selection function.

    n: string
        Wrap Type
    """
    WRAP_ROUTE[n](j, z, w)


def grow_wrap_channel(j, sc, w, n):
    """
    Expand a Wrap selection depending on the Wrap/Type.
    Select wrap item before calling.

    j: Gimp Image
        Has selection.

    sc: selection channel
        Has cast.

    w: float
        expansion amount
        Zero is allowed by selection function.

    n: string
        Wrap Type
    """
    CHANNEL_ROUTE[n](j, sc, w)
