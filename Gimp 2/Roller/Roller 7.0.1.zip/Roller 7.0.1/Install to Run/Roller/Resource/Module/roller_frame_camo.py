#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, LAYER_MODE_HARDLIGHT, pdb  # type: ignore
from roller_constant import Frame as ek, Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_frame import do_frame_wrap
from roller_frame_alt import FrameOverlay
from roller_gegl import noise_rgb, video_degradation, waterpixels
from roller_gimp_image import add_layer
from roller_gimp_layer import (
    clone_layer, color_selection_default, do_saturate, select_layer
)


def do_overlay(maya):
    """
    Make an overlay layer from waterpixels.

    maya: Overlay
    Return: layer
        overlay
    """
    pdb.gimp_selection_none(Run.j)

    d = maya.value_d
    z = add_layer(Run.j, maya.group, maya.get_light(), "Material")
    noise = int(d[de.RANDOM_SEED] + Globe.seed)

    for i in range(3):
        q = ek.COMPONENT_DICT[d[de.CAMO_TYPE]] + (noise + i,)
        noise_rgb(z, *q)

    waterpixels(z)
    pdb.gimp_brightness_contrast(z, 0, 75)
    do_saturate(z, d)
    return z


def do_matter(maya):
    """
    Make a frame.

    maya: Camo
    Return: layer
        Wrap output
    """
    z = do_frame_wrap(maya)
    z = clone_layer(z)

    select_layer(z)
    color_selection_default(z, (127, 127, 127))

    # Curves won't work as expected with a selection.
    pdb.gimp_selection_none(Run.j)

    video_degradation(z, 'dots')
    pdb.gimp_drawable_curves_spline(
        z,
        0,                          # HISTOGRAM_VALUE, '0'
        4,                          # four coordinates
        (.0, .2, 1., .8)
    )

    z.mode = LAYER_MODE_HARDLIGHT
    z.opacity = 65.
    return pdb.gimp_image_merge_down(Run.j, z, CLIP_TO_IMAGE)


class Camo(FrameOverlay):
    add_row = shade_row = rk.RW1
    is_seeded = True
    kind = material = de.CAMO
    overlay_k = de.OVERLAY_CA
    wrap_k = de.WRAP_AB

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        FrameOverlay.__init__(
            self, any_group, super_maya, k_path, do_matter, do_overlay
        )
