#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (pdb, CHANNEL_OP_ADD, FILL_PATTERN)  # type: ignore
from random import choice, randint, randrange, uniform
from roller_constant import Color as co, Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_context import set_fill_context_default, set_gimp_pattern
from roller_gimp_image import add_base_layer, add_sub_maya_group, clip_to_wip
from roller_gimp_layer import get_mean_color, remove_layer, color_selection
from roller_gimp_selection import select_polygon
from roller_maya_sub_accent import SubAccent
from roller_polygon import make_coord_list, invert_triangle
from roller_port_per import make_2d_table
from roller_preset import combine_seed
from roller_utility import random_rgb, seal
from roller_wip import Wip
import colorsys


def do_color(z, color):
    """
    Fill the current selection with a color.

    z: layer
        Receive color within selection.

    color: tuple
        RGB or RGBA
        (0..255, 0..255, 0..255, 0..255)
    """
    color_selection(z, color)


def do_rgb(z, hsv):
    """
    Fill the current selection with random blue biased color.

    z: layer
        Receive color within selection.

    hsv: tuple
        (hue, saturation, value)
        from colorsys
        (.0 to 1., .0 to 1., .0 to 1.)
    """
    color_selection(
        z, tuple(map(int, colorsys.hsv_to_rgb(
            hsv[0] + seal(uniform(-.1, .1), .0, 1.),
            uniform(.0, 1.),
            seal(hsv[2] + randrange(-18, 18), 0, 255)
        )))
    )


def do_mean_color(z, bg_z):
    """
    Fill the current selection with the mean
    color of a layer-selection's background.

    z: layer
        Receive color within selection.
    """
    color_selection(z, get_mean_color(bg_z))


def do_pattern(z, n):
    """
    Fill the current selection with a GIMP pattern.

    n: string
        GIMP pattern descriptor
    """
    set_gimp_pattern(n)
    pdb.gimp_drawable_edit_bucket_fill(z, FILL_PATTERN, .0, .0)


def do_random_color(z):
    """
    Fill the current selection with a random GIMP color.

    z: layer
        Receive color within selection.
    """
    color_selection(z, random_rgb())


def calc_cell_shape(t, r, c, cell_q):
    """
    Initialize a 2D table reflecting in dimension a double-spaced
    triangle grid and storing a cell triangle's polygon shape.

    t: Rect
        Define the bounds of the triangle grid.

    r, c: float
        Divide the grid into cell giving each cell a 2D index-type offset.

    cell_q: list
        [(r, c), ...]
        [(valid cell position), ...]

    Return: 2D list
        [[(shape, ...)], ...]
        a table of cell where each cell is a tuple defining a polygon
        made from simulated-reverberation on a sheared vertical
        triangle shape
    """
    x, y, canvas_w, canvas_h = t
    row, column = map(int, (r, c))
    table = make_2d_table(row + 2, column + 4)

    # Calculate the cell size.
    w = canvas_w / (.5 + column * .5)
    h = canvas_h / row
    w /= 2.

    # Expand the canvas and grid size to cover edge case
    # with triangle for vertical oriented triangle.
    w1 = w + w
    x -= w1
    y -= h
    canvas_w += (w1 + w1)
    canvas_h += (h + h)
    row += 2
    column += 4
    w = canvas_w / (.5 + column * .5)
    w /= 2

    # Calculate intersect coordinate for a grid
    # defined by vertically aligned triangle shape.
    q_x = make_coord_list(canvas_w, column + 2, x, span=w)
    q_y = make_coord_list(canvas_h, row + 1, y, span=h)

    for r in range(row):
        for c in range(column):
            cell_q.append((r, c))

    # Load cell grid table with polygon shape.
    for r_c in cell_q:
        r, c = r_c

        y, y1 = q_y[r], q_y[r + 1]
        x, x1, x2 = q_x[c: c + 3]

        # The 'y' value flips when inverted.
        _is_inverse = invert_triangle(r, c)

        table[r][c] = [(x, y), (x1, y1), (x2, y)] if _is_inverse \
            else [(x, y1), (x1, y), (x2, y1)]
    return table, w, h


def do_matter(maya):
    """
    Make a matter layer for TriangleReverb.

    maya: TriangleReverb
    Return: layer or None
        'matter'
    """
    def _process_pattern():
        """
        Fill triangle polygon using a checkerboard alternate pattern scheme.
        """
        _select_odd()
        do_pattern(z, d[rk.PAR][de.PATTERN_2])
        _select_even()
        do_pattern(z, d[rk.PAR][de.PATTERN_1])

    def _process_color():
        """Fill triangle polygon using a checkerboard color scheme."""
        _select_odd()
        do_color(z, d[de.COLOR_2A][1])
        _select_even()
        do_color(z, d[de.COLOR_2A][0])

    def _select_even():
        """Create a selection of even remainder cell index triangle polygon."""
        pdb.gimp_selection_none(j)
        for _r_c in cell_q:
            _r, _c = _r_c
            if not (_r + _c) % 2:
                _q = table[_r][_c]
                _shape = ()

                for _point in _q:
                    _shape += point_d[_point]
                select_polygon(j, _shape, option=CHANNEL_OP_ADD)

    def _select_odd():
        """Create a selection of odd remainder cell index triangle polygon."""
        pdb.gimp_selection_none(j)
        for _r_c in cell_q:
            _r, _c = _r_c
            if (_r + _c) % 2:
                _q = table[_r][_c]
                _shape = ()

                for _point in _q:
                    _shape += point_d[_point]
                select_polygon(j, _shape, option=CHANNEL_OP_ADD)

    j = Run.j
    point_d = {}

    # list of valid double-spaced cell inclusive
    # to a grid of triangle polygon, 'cell_q'; [(r, c), ...]
    cell_q = []

    d = maya.value_d
    k = d[de.TYPE]
    p = {de.PATTERN: _process_pattern, de.COLOR: _process_color}.get(k)

    combine_seed(d)

    parent = add_sub_maya_group(maya)
    z = add_base_layer(parent, "Background")
    z = pdb.gimp_image_merge_layer_group(j, parent)
    table, w, h = calc_cell_shape(
        Wip.get_rect(), d[de.ROW], d[de.COLUMN], cell_q
    )
    f = d[de.REVERB]
    w1, h1 = int((w / 2.) * f), int((h / 2.) * f)

    # Load the point dictionary with intersect point as key and value.
    for r_c in cell_q:
        r, c = r_c
        for point in table[r][c]:
            point_d[point] = point

    # Reverb point by as much as +-50% of the cell rectangle scale.
    for point in point_d.values():
        point_d[point] = (
            point[0] + reverb(w1) * choice((-1, 1)),
            point[1] + reverb(h1) * choice((-1, 1))
        )

    set_fill_context_default()

    # Fill triangle per the fill type.
    if p:
        p()

    else:
        arg = (z,)
        p = TYPE_FILL[k]
        is_mean = k == de.MEAN_COLOR

        if is_mean:
            arg += (maya.bg_z,)

        elif k in co.COMPONENT_LIST:
            # Create a base color, 'color', then convert it
            # to a HSV tuple for randomizing saturation.
            color = [0, 0, 0]
            color[co.COMPONENT_LIST.index(k)] = randint(25, 255)
            arg = arg + (colorsys.rgb_to_hsv(*color),)

        # r_c: (int, int)
        for r_c in cell_q:
            r, c = r_c
            shape = ()

            for point in table[r][c]:
                shape += point_d[point]

            select_polygon(j, shape)
            p(*arg)
        if is_mean:
            remove_layer(maya.bg_z)
            maya.bg_z = None

    pdb.gimp_selection_none(j)
    clip_to_wip(z)
    return maya.finish(z, d[rk.BRW])


def reverb(w):
    """
    Modify a limit within a range starting at zero.

    w: int
        0..n

    Return: int
        The value is in the range of zero to 'w'.
    """
    return randrange(w) if w else w


class TriangleReverb(SubAccent):
    kind = de.TRIANGLE_REVERB

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)

    def do(self, *arg):
        """Check if the background has change."""
        d = self.any_group.get_value_d()
        self.is_dependent = d[de.TYPE] == de.MEAN_COLOR
        super(TriangleReverb, self).do(*arg)


# Dispatch fill-response based on fill-type.
# {Triangle Reverb/Type: fill function}
TYPE_FILL = {
    de.BLUE: do_rgb,
    de.GREEN: do_rgb,
    de.MEAN_COLOR: do_mean_color,
    de.RANDOM_COLOR: do_random_color,
    de.RED: do_rgb
}
