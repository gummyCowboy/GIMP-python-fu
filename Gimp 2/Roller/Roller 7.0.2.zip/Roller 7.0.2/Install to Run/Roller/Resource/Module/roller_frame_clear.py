#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, LAYER_MODE_DODGE, pdb   # type: ignore
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_frame import select_wrap
from roller_frame_alt import FrameBasic
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import add_layer, add_layer_above, make_group_layer
from roller_gimp_layer import (
    clear_inverse_selection,
    clear_selection,
    clone_layer,
    color_layer,
    color_selection,
    select_layer
)
from roller_preset_shadow import do_stylish_shadow


def do_matter(maya):
    """
    Make a Wrap frame.

    maya: Clear
    Return: layer
        Wrap 'matter'
    """
    j = Run.j
    d = maya.value_d
    cast = maya.cast.matter
    frame_q = []
    w = d[de.INNER_FRAME_W]
    group = make_group_layer(j, maya.group, maya.get_light(), "Material")

    set_fill_context_default()
    select_layer(cast)

    if not pdb.gimp_selection_is_empty(j):
        # Create two layers.
        for i in range(2):
            # Add layer to the bottom of the group layer.
            z = add_layer(j, group, len(group.layers), ("1", "2")[i])

            select_wrap(
                j, cast, (w, d[de.WIDTH] + w)[i], d[de.TYPE]
            )
            color_selection(z, (127, 127, 127))

            z = give_edge(j, z)
            frame_q.append(z)

        z = do_stylish_shadow(frame_q[0], blur=5., intensity=130.)
        if z:
            select_layer(cast)
            clear_selection(z)
    return pdb.gimp_image_merge_layer_group(j, group)


def give_edge(j, z):
    """
    Give the frame an edge.

    j: GIMP image
        WIP

    z: layer
        Give edge.

    Return: layer
        with edge
    """
    z1 = clone_layer(z, "Material")
    z2 = add_layer_above(z, "Back")

    color_layer(z2, (100, 100, 100))

    z1 = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

    # amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(z.image, z1, 1., .0, .0)

    z1.mode = LAYER_MODE_DODGE

    select_layer(z)
    clear_inverse_selection(z1)
    return pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)


class Clear(FrameBasic):
    kind = material = de.CLEAR
    wrap_k = de.WRAP_CL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            option owner

        super_maya: Maya
            deco type

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
