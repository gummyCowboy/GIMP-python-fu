#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD, pdb
)
from roller_constant import Triangle as ft
from roller_gimp_image import add_layer, create_image, image_copy_all
from roller_gimp_layer import color_layer, color_selection
from roller_gimp_selection import select_polygon
from roller_many_rect import Rect
from roller_polygon import calc_hexagon


def make_cube_pattern(fixed_h, colors):
    """
    Make a cube tile pattern with three shades applied to the visible
    sides. In order to create the shaded sides, two of the
    sides need to be filled with a unique shade. The side
    that forms the top of the cube is made from the background
    color. The shaded sides are first selected then filled.
    Is GIMP context sensitive.

    fixed_h: float
        height of pattern

    colors: tuple
        RGB or RGBA

    Return: clipboard
        pattern
    """
    tile_w = fixed_h * ft.SCALE_DOWN

    # a tuple of six points, 12 values, making up a hexagon,
    # connected clockwise, and starting from the upper-left point, 'q'
    q = calc_hexagon(Rect(.0, .0, tile_w, fixed_h))

    # at the left hexagon's, 'center...'
    center_x, center_y = q[2], q[9] / 2.

    # below the top hexagons, 'y1, y2'
    y1 = q[9] + q[5]
    tile_h = q[9] + center_y

    # for the right hexagon
    center_x2 = center_x + q[4]

    # Create the tile from a new image that doesn't get displayed.
    j = create_image(int(tile_w), int(tile_h))

    pattern_layer = add_layer(j, None, 0, "Pattern")

    # make a fill all?
    color_layer(pattern_layer, colors[0])

    # Start the right side selections.
    pdb.gimp_selection_none(j)

    # The polygon points are connected in a clockwise rotation.
    right_poly = (
        (.0, .0, q[2], q[3], q[0], q[1]),
        (q[4], .0, q[4] + q[2], .0, q[4], q[1]),
        (center_x, center_y, q[4], q[5], q[6], q[7], q[8], q[9]),
        (center_x2, center_y, tile_w, q[5], tile_w, q[7], center_x2, q[9]),
        (.0, y1, q[2], q[9], q[2], tile_h, .0, tile_h),
        (q[4], y1, center_x2, q[9], center_x2, tile_h, q[4], tile_h)
    )

    for q1 in right_poly:
        select_polygon(j, q1, option=CHANNEL_OP_ADD)

    # Fill the right side.
    color_selection(pattern_layer, colors[1])

    # Start the left side selections.
    pdb.gimp_selection_none(j)

    # The polygon points are connected in a clockwise rotation.
    left_poly = (
        (q[2], .0, q[4], .0, q[4], q[5]),
        (q[4] + q[2], .0, tile_w, .0, tile_w, q[5]),
        (.0, q[1], center_x, center_y, q[2], q[9], .0, q[11]),
        (q[4], q[1], center_x2, center_y, center_x2, q[9], q[4], q[11]),
        (q[2], q[9], q[4], y1, q[4], tile_h, q[2], tile_h),
        (center_x2, q[9], tile_w, y1, tile_w, tile_h, center_x2, tile_h)
    )

    for q1 in left_poly:
        select_polygon(j, q1, option=CHANNEL_OP_ADD)

    # Fill the left side.
    color_selection(pattern_layer, colors[2])

    # Set the Clipboard Image for the pattern fill op.
    image_copy_all(j)

    # Close the tile image as the pattern is done.
    pdb.gimp_image_delete(j)
