#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import (
    Define as df, Issue as vo, Node as nw, Row as rk
)
from roller_constant_identity import Identity as de
from roller_def_actor import scour
from roller_def_option import (
    AMOUNT,
    AMP,
    AMPLITUDE,
    ANGLE_JITTER,
    ANGLE_SHIFT,
    ANGLE,
    AUTOCROP,
    BELOW_TYPE,
    BEVEL_H,
    BEVEL_W,
    BLUR_POST,
    BLUR_PRE,
    BLUR_TYPE,
    BLUR_XY,
    BLUR,
    BRUSH_ANGLE,
    BRUSH_SIZE,
    BRUSH_SPACING,
    BRUSH,
    BUMP_DEPTH,
    BUMP_TYPE,
    CAMO_TYPE,
    CFW,
    CIRCLE_DIAMETER,
    CLIP,
    CLOCKWISE,
    COLOR_1,
    COLOR_2A,
    COLOR_2B,
    COLOR_EMBOSS,
    COLORIZE,
    CONTRACT,
    CONTRAST,
    CORNER_SHIFT,
    CORNER_TYPE,
    CROP_X,
    CROP_Y,
    DEPTH,
    DESATURATE,
    DISTRESS,
    EDGE_MODE,
    EDGE_TYPE,
    FACTOR_SIZE,
    FEATHER,
    FILTER,
    FIXED_SIZE,
    FLIP,
    FOLDER_ORDER,
    FONT,
    FRAME_W,
    FRAME_W1,
    GAP_W,
    GRADIENT_ANGLE,
    GRADIENT_TYPE,
    GRADIENT,
    HARDNESS,
    HEXAGON_TYPE,
    HSL,
    IMAGE_NAME,
    IMAGE_TYPE,
    INNER_FRAME_W,
    INTENSITY,
    INVERT,
    INVERT_MASK,
    LAYER_ORDER,
    LAYERED,
    LENGTH,
    LENGTH_DRIP,
    LENGTH_SHIFT,
    LINE_W,
    LOOP,
    MASK_SCALE,
    MASK_TYPE,
    MAX_POSITIVE_X,
    MAX_POSITIVE_Y,
    MESH_SIZE,
    MESH_TYPE,
    MODE,
    NEATNESS,
    NOISE_AMOUNT,
    NOISE_TYPE,
    OCTAGON_TYPE,
    OFFSET_XY,
    OPACITY,
    OPAQUE,
    OVER_OVERLAY_TYPE,
    OVERLAY_MODE,
    PATTERN,
    PER,
    PERCENTILE,
    PERIOD,
    PHASE,
    PROFILE,
    R_C,
    RADIUS,
    RADIUS_DRIP,
    RANDOM,
    RC_SLICE,
    RECTANGLE_TYPE,
    RESIZE_TYPE,
    REVERSE,
    SCATTER_COUNT,
    SELECT,
    SEED,
    SHADOW_BLUR,
    SHAPED_TYPE,
    SIZE_XY,
    SLICE_ORDER,
    SLICE,
    SMOOTH,
    SPECK_NOISE,
    SPREAD_WRAP_CR,
    STENCIL_TYPE,
    STEPS,
    STRIP_HEIGHT,
    SWITCH,
    TAB,
    TAPE_WIDTH,
    TEXT,
    TRIANGLE_TYPE,
    UNSHARP_AMOUNT,
    UNSHARP_RADIUS,
    UNSHARP_THRESHOLD,
    UP_SPACE,
    UPSCALE,
    WHIRL,
    WIDTH,
    WIDTH_0,
    WIRE_THICKNESS,
    WOBBLE_FACTOR,
    WRAP_TYPE
)
from roller_tooltip_text import Tip
from roller_tooltip_actor import make_text_tip
from roller_port_generic import (
    PortAdd,
    PortAddAbove,
    PortAddAlt,
    PortBelow,
    PortBlur,
    PortBrush,
    PortBrushPD,
    PortBump,
    PortColor,
    PortEmboss,
    PortFillerCeramic,
    PortFillerChecker,
    PortFillerFence,
    PortFillerHoley,
    PortFillerMaze,
    PortFillerMecha,
    PortFillerMirror,
    PortFillerRad,
    PortFillerStained,
    PortFillerStretch,
    PortFillerStripe,
    PortGrid,
    PortInset,
    PortMargin,
    PortMod,
    PortNoise,
    PortOverlayBevel,
    PortOverlayCamo,
    PortOverlayOver,
    PortResize,
    PortStencil,
    PortStrip,
    PortTape,
    PortWrap,
    PortWrapAddAbove,
    PortWrapAlt,
    PortWrapBevel,
    PortWrapBurst,
    PortWrapCanvas,
    PortWrapClear,
    PortWrapCrumble,
    PortWrapDecay,
    PortWrapFill,
    PortWrapGlue,
    PortWrapGradual,
    PortWrapJoint,
    PortWrapNet,
    PortWrapOverlap,
    PortWrapPattern,
    PortWrapPipe,
    PortWrapWobble
)
from roller_port_option_serve import PortFrame
from roller_port_image_choice import PortImageChoice
from roller_port_mask import PortMask
from roller_port_shadow import PortShadow
from roller_widget_button import FileButton, FolderButton
from roller_widget_label import (
    CoverLabel,
    FilledLabel,
    LockedLabel,
    NextXLabel,
    PreviousXLabel,
    TrimLabel
)
from roller_widget_option_list import OptionList
from roller_widget_value_button import (
    OptionButton, OptionListButton, ShadowButton
)
from roller_widget_row import WidgetRow

"""Define Dialog accessible Preset. Define Row configuration."""

# Bump_________________________________________________________________________
BUMP = {
    df.NO_VOTE: True,
    df.DIALOG: PortBump,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.TYPE, deepcopy(BUMP_TYPE)),
        (de.MODE, deepcopy(OVERLAY_MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.NOISE, deepcopy(SPECK_NOISE)),
        (de.AMOUNT, deepcopy(AMOUNT)),
        (de.BLUR_X, deepcopy(BLUR_XY)),
        (de.BLUR_Y, deepcopy(BLUR_XY)),
        (de.DEPTH, deepcopy(BUMP_DEPTH)),
        (de.INVERT, deepcopy(INVERT))
    ]),
    df.WIDGET: OptionButton
}
a_ = BUMP[df.SUB]
a_[de.BLUR_X][df.VALUE] = 48.
a_[de.BLUR_Y][df.VALUE] = 6.
BUMP[df.SUB][de.TYPE][df.VALUE] = de.NOISE

BUMP[df.SUB][de.NOISE].update({df.LIMIT: (.0, 1.), df.VALUE: .07})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Brush Dialog_________________________________________________________________
BRUSH_DIALOG = {
    df.NO_VOTE: True,
    df.DIALOG: PortBrush,
    df.SUB: OrderedDict([
        (de.BRUSH_SIZE, deepcopy(BRUSH_SIZE)),
        (de.BRUSH_SPACING, deepcopy(BRUSH_SPACING)),
        (de.BRUSH_ANGLE, deepcopy(BRUSH_ANGLE)),
        (de.ANGLE_JITTER, deepcopy(ANGLE_JITTER)),
        (de.HARDNESS, deepcopy(HARDNESS)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.UPSCALE, deepcopy(UPSCALE)),
        (de.UP_SPACE, deepcopy(UP_SPACE)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (de.BRUSH, deepcopy(BRUSH))
    ]),
    df.WIDGET: OptionButton
}
BRUSH_DIALOG[df.SUB][de.OPACITY][df.ISSUE] = vo.MATTER
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Emboss_______________________________________________________________________
EMBOSS = {
    df.NO_VOTE: True,
    df.DIALOG: PortEmboss,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.MODE, deepcopy(MODE)),
        (de.DEPTH, deepcopy(DEPTH)),
        (de.CONTRAST, deepcopy(CONTRAST)),
        (de.PRE_BLUR, deepcopy(BLUR_PRE)),
        (de.POST_BLUR, deepcopy(BLUR_POST))
    ]),
    df.WIDGET: OptionButton
}

EMBOSS[df.SUB][de.MODE].update({df.ISSUE: vo.MATTER, df.VALUE: "Overlay"})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Grid_________________________________________________________________________
GRID = {
    df.NO_VOTE: True,
    df.DIALOG: PortGrid,
    df.SUB: OrderedDict([
        (de.WIDTH, deepcopy(WIDTH)),
        (de.HEIGHT, deepcopy(WIDTH)),
        (de.LINE_W, deepcopy(WIDTH_0)),
        (de.LINE_H, deepcopy(WIDTH_0))
    ]),
    df.WIDGET: OptionButton
}

for k in (de.LINE_W, de.LINE_H):
    GRID[df.SUB][k][df.VALUE] = 4.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Image Choice_________________________________________________________________
IMAGE_CHOICE = {
    df.NO_VOTE: True,
    df.DIALOG: PortImageChoice,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.TYPE, deepcopy(IMAGE_TYPE)),
        (de.TAB, deepcopy(TAB)),
        (de.IMAGE_NAME, deepcopy(IMAGE_NAME)),
        (de.NEXT, {df.WIDGET: NextXLabel}),
        (de.PREVIOUS, {df.WIDGET: PreviousXLabel}),
        (de.LOOP, deepcopy(LOOP)),
        (de.FILE, {
            df.TIP_P: make_text_tip,
            df.VALUE: "",
            df.WIDGET: FileButton
        }),
        (de.FOLDER, {
            df.TIP_P: make_text_tip,
            df.VALUE: "",
            df.WIDGET: FolderButton
        }),
        (de.FILTER, deepcopy(FILTER)),
        (de.FOLDER_ORDER, deepcopy(FOLDER_ORDER)),
        (de.LAYERED, deepcopy(LAYERED)),
        (de.LAYER_ORDER, deepcopy(LAYER_ORDER)),
        (de.SLICE, deepcopy(SLICE)),
        (de.ROW, deepcopy(RC_SLICE)),
        (de.COLUMN, deepcopy(RC_SLICE)),
        (de.SLICE_ORDER, deepcopy(SLICE_ORDER)),
        (de.AUTOCROP, deepcopy(AUTOCROP)),
        (de.RANDOM_SEED, deepcopy(SEED))
    ]),
    df.WIDGET: OptionButton
}

# Mask_________________________________________________________________________
MASK = {
    df.NO_VOTE: True,
    df.DIALOG: PortMask,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.TYPE, deepcopy(MASK_TYPE)),
        (de.CORNER_TYPE, deepcopy(CORNER_TYPE)),
        (de.HEXAGON_TYPE, deepcopy(HEXAGON_TYPE)),
        (de.OCTAGON_TYPE, deepcopy(OCTAGON_TYPE)),
        (de.RECTANGLE_TYPE, deepcopy(RECTANGLE_TYPE)),
        (de.TRIANGLE_TYPE, deepcopy(TRIANGLE_TYPE)),
        (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
        (de.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
        (de.TEXT, deepcopy(TEXT)),
        (de.HORZ_SCALE, deepcopy(MASK_SCALE)),
        (de.VERT_SCALE, deepcopy(MASK_SCALE)),
        (de.PUPIL_SCALE, deepcopy(MASK_SCALE)),
        (de.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE)),
        (de.FEATHER, deepcopy(FEATHER)),
        (de.STEPS, deepcopy(STEPS)),
        (de.AMP, deepcopy(AMP)),
        (de.SMOOTH, deepcopy(SMOOTH)),
        (de.ANGLE, deepcopy(ANGLE)),
        (de.CONTRACT, deepcopy(CONTRACT)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (de.INVERT, deepcopy(INVERT_MASK)),
        (de.FONT, deepcopy(FONT)),
        (rk.RW1, {
            df.SUB: OrderedDict([
                (de.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
                (de.BRUSH_D, deepcopy(BRUSH_DIALOG))
            ]),
            df.WIDGET: WidgetRow
        })
    ]),
    df.WIDGET: OptionButton
}
a_ = MASK[df.SUB]
a_[de.FEATHER][df.VALUE] = 0.
a_[de.PUPIL_SCALE][df.VALUE] = .33
a_[de.PARALLELOGRAM_SCALE][df.VALUE] = .5
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Resize ______________________________________________________________________
RESIZE = {
    df.NO_VOTE: True,
    df.DIALOG: PortResize,
    df.SUB: OrderedDict([
        (de.TYPE, deepcopy(RESIZE_TYPE)),
        (de.LOCKED, {df.WIDGET: LockedLabel}),
        (de.TRIM, {df.WIDGET: TrimLabel}),
        (de.FILLED, {df.WIDGET: FilledLabel}),
        (de.COVER, {df.WIDGET: CoverLabel}),
        (de.FIXED_W, deepcopy(FIXED_SIZE)),
        (de.FIXED_H, deepcopy(FIXED_SIZE)),
        (de.WIDTH, deepcopy(FACTOR_SIZE)),
        (de.HEIGHT, deepcopy(FACTOR_SIZE)),
        (de.CROP_X, deepcopy(CROP_X)),
        (de.CROP_Y, deepcopy(CROP_Y)),
        (de.CROP_W, deepcopy(FIXED_SIZE)),
        (de.CROP_H, deepcopy(FIXED_SIZE))
    ]),
    df.WIDGET: OptionButton
}
a_ = RESIZE[df.SUB]
a_[de.FIXED_W][df.TOOLTIP] = Tip.FIXED_W
a_[de.WIDTH][df.TOOLTIP] = Tip.WH_FACTOR
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Margin_______________________________________________________________________
MARGIN = {
    df.NO_VOTE: True,
    df.DIALOG: PortMargin,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.TOP, deepcopy(MAX_POSITIVE_Y)),
        (de.BOTTOM, deepcopy(MAX_POSITIVE_Y)),
        (de.LEFT, deepcopy(MAX_POSITIVE_X)),
        (de.RIGHT, deepcopy(MAX_POSITIVE_X)),
        (de.PER, deepcopy(PER))
    ]),
    df.WIDGET: OptionButton
}

# Shadow_______________________________________________________________________
SELECTED_ROW = {de.NODE: {nw.SELECTED_ROW: {df.VALUE: 0}}}
SHADOW_SWITCH = {de.SWITCH: deepcopy(SWITCH)}
INNER_SHADOW = OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.MODE, deepcopy(MODE)),
    (de.INTENSITY, deepcopy(INTENSITY)),
    (de.BLUR, deepcopy(SHADOW_BLUR)),
    (de.OFFSET_X, deepcopy(OFFSET_XY)),
    (de.OFFSET_Y, deepcopy(OFFSET_XY)),
    (de.COLOR_1, deepcopy(COLOR_1)),
    (de.RANDOM, deepcopy(RANDOM))
])
SHADOW_NUM = OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.MODE, deepcopy(MODE)),
    (de.INTENSITY, deepcopy(INTENSITY)),
    (de.BLUR, deepcopy(SHADOW_BLUR)),
    (de.OFFSET_X, deepcopy(OFFSET_XY)),
    (de.OFFSET_Y, deepcopy(OFFSET_XY)),
    (de.COLOR_1, deepcopy(COLOR_1)),
    (de.RANDOM, deepcopy(RANDOM))
])
SHADOW_1 = deepcopy(SHADOW_NUM)
SHADOW_2 = deepcopy(SHADOW_NUM)
SHADOW = {
    df.NO_VOTE: True,
    df.DIALOG: PortShadow,
    df.SUB: OrderedDict([
        (de.SHADOW_SWITCH, deepcopy(SHADOW_SWITCH)),
        (de.SHADOW_1, deepcopy(SHADOW_1)),
        (de.SHADOW_2, deepcopy(SHADOW_2)),
        (de.INNER_SHADOW, deepcopy(INNER_SHADOW)),
    ]),
    df.WIDGET: ShadowButton
}
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Tape__________________________________________________________________
WRAP_TA = {
    df.NO_VOTE: True,
    df.DIALOG: PortTape,
    df.SUB: OrderedDict([
        (de.LENGTH, deepcopy(LENGTH)),
        (de.WIDTH, deepcopy(TAPE_WIDTH)),
        (de.ANGLE_SHIFT, deepcopy(ANGLE_SHIFT)),
        (de.CORNER_SHIFT, deepcopy(CORNER_SHIFT)),
        (de.LENGTH_SHIFT, deepcopy(LENGTH_SHIFT)),
        (de.RANDOM_SEED, deepcopy(SEED))
    ]),
    df.WIDGET: OptionButton
}

BLUR_DIALOG = {
    df.NO_VOTE: True,
    df.DIALOG: PortBlur,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.SIZE_X, deepcopy(SIZE_XY)),
        (de.SIZE_Y, deepcopy(SIZE_XY)),
        (de.RADIUS, deepcopy(RADIUS)),
        (de.PERCENTILE, deepcopy(PERCENTILE)),
        (de.ALPHA_PERCENTILE, deepcopy(PERCENTILE)),
        (de.TYPE, deepcopy(BLUR_TYPE)),
        (de.SELECT, deepcopy(SELECT))
    ]),
    df.WIDGET: OptionButton
}

# Noise _______________________________________________________________________
MOD = {
    df.NO_VOTE: True,
    df.DIALOG: PortMod,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.SATURATION, deepcopy(HSL)),
        (de.BRIGHTNESS, deepcopy(HSL)),
        (de.CONTRAST, deepcopy(CONTRAST)),
        (de.INVERT, deepcopy(INVERT)),
        (de.FLIP_H, deepcopy(FLIP)),
        (de.FLIP_V, deepcopy(FLIP)),
        (de.BLUR_D, deepcopy(BLUR_DIALOG))
    ]),
    df.WIDGET: OptionButton
}
BBR = {
    df.SUB: OrderedDict([
        (de.BUMP, deepcopy(BUMP)),
        (de.MOD, deepcopy(MOD))
    ]),
    df.WIDGET: WidgetRow
}
NOISE_D = {
    df.NO_VOTE: True,
    df.DIALOG: PortNoise,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.TYPE, deepcopy(NOISE_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.NOISE_AMOUNT, deepcopy(NOISE_AMOUNT)),
        (de.SPECK_NOISE, deepcopy(SPECK_NOISE)),
        (de.LENGTH, deepcopy(LENGTH_DRIP)),
        (de.RADIUS, deepcopy(RADIUS_DRIP)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (de.OPAQUE, deepcopy(OPAQUE)),
        (rk.BRW, deepcopy(BBR))
    ]),
    df.WIDGET: OptionButton
}
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

BELOW = {
    df.NO_VOTE: True,
    df.DIALOG: PortBelow,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.TYPE, deepcopy(BELOW_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.OPAQUE, deepcopy(OPAQUE)),
        (de.MOD, deepcopy(MOD))
    ]),
    df.WIDGET: OptionButton
}

# Color _______________________________________________________________________
COLOR = {
    df.NO_VOTE: True,
    df.DIALOG: PortColor,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.COLOR_1, deepcopy(COLOR_1))
    ]),
    df.WIDGET: OptionButton
}
COLOR[df.SUB][de.COLOR_1][df.VALUE] = 0, 255, 0
COLOR[df.SUB][de.MODE][df.VALUE] = "LCH Color"
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

INSET = {
    df.NO_VOTE: True,
    df.DIALOG: PortInset,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.MODE, deepcopy(MODE)),
        (de.INTENSITY, deepcopy(INTENSITY)),
        (de.BLUR, deepcopy(SHADOW_BLUR)),
        (de.OFFSET_X, deepcopy(OFFSET_XY)),
        (de.OFFSET_Y, deepcopy(OFFSET_XY)),
        (de.COLOR_1, deepcopy(COLOR_1)),
        (de.RANDOM, deepcopy(RANDOM))
    ]),
    df.WIDGET: OptionButton
}
ADD = {
    df.NO_VOTE: True,
    df.DIALOG: PortAdd,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.COLOR, deepcopy(COLOR)),
        (rk.RW1, deepcopy({
            df.SUB: OrderedDict([
                (de.NOISE_D, deepcopy(NOISE_D)),
                (de.BUMP, deepcopy(BUMP))
            ]),
            df.WIDGET: WidgetRow
        })),
        (rk.BRW, {
            df.SUB: OrderedDict([
                (de.BELOW, deepcopy(BELOW)),
                (de.SHADOW, deepcopy(SHADOW))
            ]),
            df.WIDGET: WidgetRow
        })
    ]),
    df.WIDGET: OptionButton
}
ADD_ABOVE = {
    df.NO_VOTE: True,
    df.DIALOG: PortAddAbove,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (rk.RW1, deepcopy({
            df.SUB: OrderedDict([
                (de.COLOR, deepcopy(COLOR)),
                (de.INSET, deepcopy(INSET))
            ]),
            df.WIDGET: WidgetRow
        })),
        (rk.BRW, {
            df.SUB: OrderedDict([
                (de.NOISE_D, deepcopy(NOISE_D)),
                (de.BUMP, deepcopy(BUMP))
            ]),
            df.WIDGET: WidgetRow
        })
    ]),
    df.WIDGET: OptionButton
}
ADD_ALT = {
    df.NO_VOTE: True,
    df.DIALOG: PortAddAlt,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.COLOR, deepcopy(COLOR)),
        (rk.RW1, deepcopy({
            df.SUB: OrderedDict([
                (de.NOISE_D, deepcopy(NOISE_D)),
                (de.INSET, deepcopy(INSET))
            ]),
            df.WIDGET: WidgetRow
        })),
        (rk.BRW, {
            df.SUB: OrderedDict([
                (de.BUMP, deepcopy(BUMP)),
                (de.BELOW, deepcopy(BELOW))
            ]),
            df.WIDGET: WidgetRow
        })
    ]),

    df.WIDGET: OptionButton
}

# Brushy Brush_________________________________________________________________
BRUSH_D1 = {
    df.NO_VOTE: True,
    df.DIALOG: PortBrushPD,
    df.SUB: OrderedDict([
        (de.MODE, deepcopy(MODE)),
        (de.BRUSH_SIZE, deepcopy(BRUSH_SIZE)),
        (de.BRUSH_SPACING, deepcopy(BRUSH_SPACING)),
        (de.BRUSH_ANGLE, deepcopy(BRUSH_ANGLE)),
        (de.ANGLE_JITTER, deepcopy(ANGLE_JITTER)),
        (de.HARDNESS, deepcopy(HARDNESS)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.UPSCALE, deepcopy(UPSCALE)),
        (de.UP_SPACE, deepcopy(UP_SPACE)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (de.CLIP, deepcopy(CLIP)),
        (rk.BRW, {
            df.SUB: OrderedDict([
                (de.BRUSH, deepcopy(BRUSH)),
                (de.ADD_ALT, deepcopy(ADD_ALT))
            ]),
            df.WIDGET: WidgetRow
        })
    ]),
    df.WIDGET: OptionButton
}
BRUSH_D1[df.SUB][de.CLIP][df.VALUE] = 1
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Ceramic Filler_______________________________________________________________
FILLER_CE = {
    df.NO_VOTE: True,
    df.DIALOG: PortFillerCeramic,
    df.SUB: OrderedDict([
        (de.MESH_TYPE, deepcopy(MESH_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.MESH_SIZE, deepcopy(MESH_SIZE)),
        (de.NEATNESS, deepcopy(NEATNESS)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (rk.BRW, {
            df.SUB: OrderedDict([
                (de.MOD, deepcopy(MOD)),
                (de.ADD_ALT, deepcopy(ADD_ALT))
            ]),
            df.WIDGET: WidgetRow
        })
    ]),
    df.WIDGET: OptionButton
}

FILLER_CE[df.SUB][de.NEATNESS][df.VALUE] = .5
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Checker Filler_______________________________________________________________
FILLER_CH = {
    df.NO_VOTE: True,
    df.DIALOG: PortFillerChecker,
    df.SUB: OrderedDict([
        (de.ROW, deepcopy(R_C)),
        (de.COLUMN, deepcopy(R_C)),
        (de.ANGLE, deepcopy(ANGLE))
    ]),
    df.WIDGET: OptionButton
}

for i_ in (de.ROW, de.COLUMN):
    FILLER_CH[df.SUB][i_][df.VALUE] = 15.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Fence Filler_________________________________________________________________
FILLER_FE = {
    df.NO_VOTE: True,
    df.DIALOG: PortFillerFence,
    df.SUB: OrderedDict([
        (de.MESH_TYPE, deepcopy(MESH_TYPE)),
        (de.MESH_SIZE, deepcopy(MESH_SIZE)),
        (de.WIRE_THICKNESS, deepcopy(WIRE_THICKNESS)),
        (de.NEATNESS, deepcopy(NEATNESS)),
        (de.ANGLE, deepcopy(ANGLE))
    ]),
    df.WIDGET: OptionButton
}

# Holey Filler_________________________________________________________________
FILLER_HO = {
    df.NO_VOTE: True,
    df.DIALOG: PortFillerHoley,
    df.SUB: OrderedDict([
        (de.CIRCLE_DIAMETER, deepcopy(CIRCLE_DIAMETER)),
        (de.ANGLE, deepcopy(ANGLE))
    ]),
    df.WIDGET: OptionButton
}

# Maze Filler__________________________________________________________________
FILLER_MA = {
    df.NO_VOTE: True,
    df.DIALOG: PortFillerMaze,
    df.SUB: OrderedDict([
        (de.LINE_W, deepcopy(LINE_W)),
        (de.CFW, deepcopy(CFW)),
        (de.ROW, deepcopy(R_C)),
        (de.COLUMN, deepcopy(R_C)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (de.CLIP, deepcopy(CLIP))
    ]),
    df.WIDGET: OptionButton
}
FILLER_MA[df.SUB][de.CLIP][df.VALUE] = 1

for i_ in (de.ROW, de.COLUMN):
    FILLER_MA[df.SUB][i_][df.LIMIT] = 4, 999
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Mecha Filler__________________________________________________________
FILLER_ME = {
    df.NO_VOTE: True,
    df.DIALOG: PortFillerMecha,
    df.SUB: OrderedDict([
        (de.LINE_W, deepcopy(LINE_W)),
        (de.GAP_W, deepcopy(GAP_W)),
        (de.ANGLE, deepcopy(ANGLE))
    ]),
    df.WIDGET: OptionButton
}

# Mirror Filler________________________________________________________________
FILLER_MI = {
    df.NO_VOTE: True,
    df.DIALOG: PortFillerMirror,
    df.SUB: OrderedDict([
        (de.LINE_W, deepcopy(LINE_W)),
        (de.CFW, deepcopy(CFW)),
        (de.ROW, deepcopy(R_C)),
        (de.COLUMN, deepcopy(R_C)),
        (de.SCATTER_COUNT, deepcopy(SCATTER_COUNT)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (de.CLIP, deepcopy(CLIP))
    ]),
    df.WIDGET: OptionButton
}
FILLER_MI[df.SUB][de.CLIP][df.VALUE] = 1

for i_ in (de.ROW, de.COLUMN):
    FILLER_MI[df.SUB][i_][df.LIMIT] = 3, 100
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Rad Filler___________________________________________________________________
FILLER_RA = {
    df.NO_VOTE: True,
    df.DIALOG: PortFillerRad,
    df.SUB: OrderedDict([
        (de.LINE_W, deepcopy(LINE_W)),
        (de.CFW, deepcopy(CFW)),
        (de.ROW, deepcopy(R_C)),
        (de.COLUMN, deepcopy(R_C)),
        (de.AMPLITUDE, deepcopy(AMPLITUDE)),
        (de.PERIOD, deepcopy(PERIOD)),
        (de.WHIRL, deepcopy(WHIRL)),
        (de.CLIP, deepcopy(CLIP))
    ]),
    df.WIDGET: OptionButton
}
FILLER_RA[df.SUB][de.CLIP][df.VALUE] = 1
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Stained Filler_______________________________________________________________
FILLER_S1 = {
    df.NO_VOTE: True,
    df.DIALOG: PortFillerStained,
    df.SUB: OrderedDict([
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.PANE_W, deepcopy(WIDTH)),
        (de.ANGLE, deepcopy(ANGLE)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (rk.BRW, {
            df.SUB: OrderedDict([
                (de.MOD, deepcopy(MOD)),
                (de.ADD_ALT, deepcopy(ADD_ALT))
            ]),
            df.WIDGET: WidgetRow
        })
    ]),
    df.WIDGET: OptionButton
}

a_ = FILLER_S1[df.SUB]
a_[de.PANE_W][df.RANDOM_Q] = 25, 100
a_[de.PANE_W][df.VALUE] = 72.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Stretch Filler_______________________________________________________________
FILLER_S2 = {
    df.NO_VOTE: True,
    df.DIALOG: PortFillerStretch,
    df.SUB: OrderedDict([
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (rk.BRW, {
            df.SUB: OrderedDict([
                (de.MOD, deepcopy(MOD)),
                (de.ADD_ALT, deepcopy(ADD_ALT))
            ]),
            df.WIDGET: WidgetRow
        })
    ]),
    df.WIDGET: OptionButton
}
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Stripe Filler__________________________________________________________
FILLER_S3 = {
    df.NO_VOTE: True,
    df.DIALOG: PortFillerStripe,
    df.SUB: OrderedDict([
        (de.LINE_W, deepcopy(LINE_W)),
        (de.GAP_W, deepcopy(GAP_W)),
        (de.ANGLE, deepcopy(ANGLE))
    ]),
    df.WIDGET: OptionButton
}

# Overlay Bevel________________________________________________________________
OVERLAY_BE = {
    df.NO_VOTE: True,
    df.DIALOG: PortOverlayBevel,
    df.SUB: OrderedDict([
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.PATTERN, deepcopy(PATTERN)),
        (de.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    df.WIDGET: OptionButton
}
OVERLAY_BE[df.SUB][de.MODE][df.VALUE] = "Overlay"
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Overlay Camo_________________________________________________________________
OVERLAY_CA = {
    df.NO_VOTE: True,
    df.DIALOG: PortOverlayCamo,
    df.SUB: OrderedDict([
        (de.CAMO_TYPE, deepcopy(CAMO_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.SATURATION, deepcopy(HSL)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (de.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    df.WIDGET: OptionButton
}
a_ = OVERLAY_CA[df.SUB]
a_[de.MODE][df.VALUE] = "Hard Light"
a_[de.SATURATION][df.VALUE] = 30.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Overlay Over___________________________________________________________
OVERLAY_OV = {
    df.NO_VOTE: True,
    df.DIALOG: PortOverlayOver,
    df.SUB: OrderedDict([
        (de.TYPE, deepcopy(OVER_OVERLAY_TYPE)),
        (de.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
        (de.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (de.COLOR_1, deepcopy(COLOR_1)),
        (de.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (de.GRADIENT, deepcopy(GRADIENT)),
        (de.PATTERN, deepcopy(PATTERN)),
        (de.MOD, deepcopy(MOD))
    ]),
    df.WIDGET: OptionButton
}
OVERLAY_OV[df.SUB][de.MODE][df.VALUE] = "Overlay"
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Strip________________________________________________________________________
STRIP = {
    df.NO_VOTE: True,
    df.DIALOG: PortStrip,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.HEIGHT, deepcopy(STRIP_HEIGHT)),
        (de.COLOR_1, deepcopy(COLOR_EMBOSS)),
        (de.ADD, deepcopy(ADD)),
    ]),
    df.WIDGET: OptionButton
}

# Wrap_________________________________________________________________________
WRAP = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrap,
    df.SUB: OrderedDict([
        (de.TYPE, deepcopy(WRAP_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W1)),
        (de.EMBOSS, deepcopy(EMBOSS)),
        (de.COLOR_1, deepcopy(COLOR_EMBOSS))
    ]),
    df.WIDGET: OptionButton
}

# Wrap Above___________________________________________________________________
WRAP_AB = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapAddAbove,
    df.SUB: OrderedDict([]),
    df.WIDGET: OptionButton
}
WRAP_AB[df.SUB].update(deepcopy(WRAP[df.SUB]))
WRAP_AB[df.SUB][de.ADD_ABOVE] = deepcopy(ADD_ABOVE)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Alt_____________________________________________________________________
WRAP_AL = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapAlt,
    df.SUB: OrderedDict([]),
    df.WIDGET: OptionButton
}
WRAP_AL[df.SUB].update(deepcopy(WRAP[df.SUB]))
WRAP_AL[df.SUB][de.WIDTH][df.LIMIT] = 0, 999
WRAP_AL[df.SUB][de.ADD_ALT] = deepcopy(ADD_ALT)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Bevel___________________________________________________________________
WRAP_BE = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapBevel,
    df.SUB: OrderedDict([
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(WIDTH)),
        (de.HEIGHT, deepcopy(BEVEL_H)),
        (de.BEVEL_W, deepcopy(BEVEL_W)),
        (de.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    df.WIDGET: OptionButton
}
WRAP_BE[df.SUB][de.BEVEL_W][df.VALUE] = 24.
WRAP_BE[df.SUB][de.WIDTH][df.VALUE] = 3.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Burst___________________________________________________________________
WRAP_BU = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapBurst,
    df.SUB: OrderedDict([
        (de.SHAPED_TYPE, deepcopy(SHAPED_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W1)),
        (de.UNSHARP_AMOUNT, deepcopy(UNSHARP_AMOUNT)),
        (de.UNSHARP_RADIUS, deepcopy(UNSHARP_RADIUS)),
        (de.UNSHARP_THRESHOLD, deepcopy(UNSHARP_THRESHOLD)),
        (rk.RW1, {
            df.SUB: OrderedDict([
                (de.INVERT, deepcopy(INVERT)),
                (de.REVERSE, deepcopy(REVERSE))
            ]),
            df.WIDGET: WidgetRow
        }),
        (de.GRADIENT, deepcopy(GRADIENT))
    ]),
    df.WIDGET: OptionButton
}
WRAP_BU[df.SUB][de.GRADIENT][df.VALUE] = "Brushed Aluminium"
WRAP_BU[df.SUB][de.WIDTH][df.VALUE] = 50.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Canvas__________________________________________________________________
WRAP_CA = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapCanvas,
    df.SUB: OrderedDict([
        (de.TYPE, deepcopy(WRAP_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W)),
        (de.EMBOSS, deepcopy(EMBOSS)),
        (de.COLOR_1, deepcopy(COLOR_EMBOSS))
    ]),
    df.WIDGET: OptionButton
}

# Wrap Clear___________________________________________________________________
WRAP_CL = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapClear,
    df.SUB: OrderedDict([
        (de.TYPE, deepcopy(WRAP_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(WIDTH)),
        (de.INNER_FRAME_W, deepcopy(INNER_FRAME_W))
    ]),
    df.WIDGET: OptionButton
}
WRAP_CL[df.SUB][de.WIDTH][df.VALUE] = 30.
WRAP_CL[df.SUB][de.OPACITY][df.VALUE] = 50.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Crumble_________________________________________________________________
WRAP_CR = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapCrumble,
    df.SUB: OrderedDict([
        (de.TYPE, deepcopy(WRAP_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W1)),
        (de.SPREAD, deepcopy(SPREAD_WRAP_CR)),
        (de.DISTRESS, deepcopy(DISTRESS)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (de.CLIP, deepcopy(CLIP))
    ]),
    df.WIDGET: OptionButton
}

WRAP_CR[df.SUB][de.WIDTH].update({df.RANDOM_Q: (15, 35), df.VALUE: 15.})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Decay___________________________________________________________________
WRAP_DE = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapDecay,
    df.SUB: OrderedDict([
        (de.EDGE_TYPE, deepcopy(EDGE_TYPE)),
        (de.EDGE_MODE, deepcopy(EDGE_MODE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W1)),
        (de.POST_BLUR, deepcopy(BLUR)),
        (de.COLORIZE_OPACITY, deepcopy(OPACITY)),
        (de.COLOR_1, deepcopy(COLOR_1)),
        (de.COLORIZE, deepcopy(COLORIZE)),
    ]),
    df.WIDGET: OptionButton
}
WRAP_DE[df.SUB][de.WIDTH][df.VALUE] = 80.
WRAP_DE[df.SUB][de.COLOR_1][df.VALUE] = 175, 90, 10
WRAP_DE[df.SUB][de.COLORIZE_OPACITY].update(
    {df.ISSUE: vo.MATTER, df.VALUE: 70.}
)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Filler__________________________________________________________________
WRAP_FI = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapFill,
    df.SUB: OrderedDict([
        (de.TYPE, deepcopy(WRAP_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W)),
        (de.FILLER_W, deepcopy(WIDTH)),
        (de.EMBOSS, deepcopy(EMBOSS)),
        (de.COLOR_1, deepcopy(COLOR_EMBOSS)),
        (de.ADD_ALT, deepcopy(ADD_ALT))
    ]),
    df.WIDGET: OptionButton
}

# Wrap Glue____________________________________________________________________
WRAP_GL = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapGlue,
    df.SUB: OrderedDict([
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W1)),
        (de.SOFTEN, deepcopy(BLUR)),
        (de.AMPLITUDE, deepcopy(AMPLITUDE)),
        (de.PERIOD, deepcopy(PERIOD)),
        (de.PHASE, deepcopy(PHASE)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (de.CLIP, deepcopy(CLIP))
    ]),
    df.WIDGET: OptionButton
}
WRAP_GL[df.SUB][de.MODE][df.VALUE] = "Overlay"
WRAP_GL[df.SUB][de.WIDTH][df.VALUE] = 5.
WRAP_GL[df.SUB][de.SOFTEN].update({df.RANDOM_Q: (1., 3.), df.VALUE: 2.})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Gradual_________________________________________________________________
WRAP_GR = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapGradual,
    df.SUB: OrderedDict([
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W1)),
        (de.COLOR_2A, deepcopy(COLOR_2A))
    ]),
    df.WIDGET: OptionButton
}
WRAP_GR[df.SUB][de.WIDTH][df.VALUE] = 30.

WRAP_GR[df.SUB][de.COLOR_2A].update({
    df.COLOR_NAME_LIST: ("Inside", "Outside"),
    df.VALUE: ((116, 77, 43, 255), (160, 105, 28, 255))
})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Joint___________________________________________________________________
WRAP_JO = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapJoint,
    df.SUB: OrderedDict([
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.BRUSH_SIZE, deepcopy(BRUSH_SIZE)),
        (de.CLIP, deepcopy(CLIP))
    ]),
    df.WIDGET: OptionButton
}
WRAP_JO[df.SUB][de.CLIP][df.VALUE] = 1
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Net_____________________________________________________________________
WRAP_NT = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapNet,
    df.SUB: OrderedDict([
        (de.TYPE, deepcopy(WRAP_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W1)),
        (de.FILLER_W, deepcopy(FRAME_W)),
        (de.EMBOSS, deepcopy(EMBOSS)),
        (de.GRID, deepcopy(GRID)),
        (de.COLOR_1, deepcopy(COLOR_1))
    ]),
    df.WIDGET: OptionButton
}

for k in (de.LINE_W, de.LINE_H):
    WRAP_NT[df.SUB][de.GRID][df.SUB][k][df.VALUE] = 6

for k in (de.WIDTH, de.HEIGHT):
    WRAP_NT[df.SUB][de.GRID][df.SUB][k][df.VALUE] = 44

WRAP_NT[df.SUB][de.COLOR_1][df.VALUE] = (100, 120, 30)
WRAP_NT[df.SUB][de.FILLER_W][df.VALUE] = 42
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Overlap_________________________________________________________________
WRAP_OL = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapOverlap,
    df.SUB: OrderedDict([
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W1)),
        (de.CLOCKWISE, deepcopy(CLOCKWISE)),
        (de.EMBOSS, deepcopy(EMBOSS)),
        (de.COLOR_2, deepcopy(COLOR_2B))
    ]),
    df.WIDGET: OptionButton
}
WRAP_OL[df.SUB][de.WIDTH][df.VALUE] = 36.

WRAP_OL[df.SUB][de.COLOR_2].update({
    df.COLOR_NAME_LIST: (" Vertical", " Horizontal")
})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wrap Pipe____________________________________________________________________
WRAP_PI = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapPipe,
    df.SUB: OrderedDict([
        (de.PROFILE, deepcopy(PROFILE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(WIDTH)),
        (de.HEIGHT, deepcopy(BEVEL_H))
    ]),
    df.WIDGET: OptionButton
}

# Wrap Pattern_________________________________________________________________
WRAP_PA = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapPattern,
    df.SUB: OrderedDict([
        (de.TYPE, deepcopy(WRAP_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W)),
        (de.FILLER_W, deepcopy(WIDTH)),
        (de.EMBOSS, deepcopy(EMBOSS)),
        (de.COLOR_1, deepcopy(COLOR_EMBOSS))
    ]),
    df.WIDGET: OptionButton
}

# Wrap Wobble__________________________________________________________________
WRAP_WO = {
    df.NO_VOTE: True,
    df.DIALOG: PortWrapWobble,
    df.SUB: OrderedDict([
        (de.TYPE, deepcopy(WRAP_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY)),
        (de.WIDTH, deepcopy(FRAME_W1)),
        (de.WOBBLE_FACTOR, deepcopy(WOBBLE_FACTOR)),
        (de.RANDOM_SEED, deepcopy(SEED)),
        (de.CLIP, deepcopy(CLIP)),
        (de.EMBOSS, deepcopy(EMBOSS)),
        (de.COLOR_1, deepcopy(COLOR_EMBOSS)),
    ]),
    df.WIDGET: OptionButton
}
a = WRAP_WO[df.SUB]
a[de.TYPE][df.VALUE] = de.OVERLAP
a[de.WIDTH].update({df.RANDOM_Q: (1, 50), df.VALUE: 12.})
a = a[de.EMBOSS][df.SUB]
a[de.SWITCH][df.VALUE] = 1
a[de.DEPTH][df.VALUE] = 10.
a[de.CONTRAST][df.VALUE] = -36
a[de.PRE_BLUR][df.VALUE] = 10.
a[de.POST_BLUR][df.VALUE] = 6.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Stencil Over_________________________________________________________________
STENCIL = {
    df.NO_VOTE: True,
    df.DIALOG: PortStencil,
    df.SUB: OrderedDict([
        (de.TYPE, deepcopy(STENCIL_TYPE)),
        (de.MODE, deepcopy(MODE)),
        (de.OPACITY, deepcopy(OPACITY))
    ]),
    df.WIDGET: OptionButton
}
STENCIL[df.SUB][de.OPACITY][df.VALUE] = .0
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Basic________________________________________________________________________
BASIC = OrderedDict([(rk.BRW, {
    df.SUB: OrderedDict([
        (de.WRAP, deepcopy(WRAP)),
        (de.ADD, deepcopy(ADD))
    ]),
    df.WIDGET: WidgetRow
})])

# Frame________________________________________________________________________
# Create k-path with a VALUE dictionary, a list-type won't work.
FRAME_OPTION_LIST = {
    df.ISSUE: vo.MATTER,
    df.VALUE: {de.BASIC: scour({}, BASIC, df.VALUE)},
    df.WIDGET: OptionList
}
FRAME = {
    df.NO_VOTE: True,
    df.DIALOG: PortFrame,
    df.SUB: OrderedDict([
        (de.SWITCH, deepcopy(SWITCH)),
        (de.OPTION_LIST, deepcopy(FRAME_OPTION_LIST))
    ]),
    df.WIDGET: OptionListButton
}
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Accent_______________________________________________________________________
ARW = {
    df.SUB: OrderedDict([
        (de.ADD, deepcopy(ADD)),
        (de.RANDOM, deepcopy(RANDOM))
    ]),
    df.WIDGET: WidgetRow
}
MAR = {
    df.SUB: OrderedDict([
        (de.MOD, deepcopy(MOD)),
        (de.ADD, deepcopy(ADD)),
        (de.RANDOM, deepcopy(RANDOM))
    ]),
    df.WIDGET: WidgetRow
}
MEAN_COLOR = OrderedDict([
    (de.MODE, deepcopy(MODE)),
    (de.OPACITY, deepcopy(OPACITY)),
    (rk.BRW, deepcopy(MAR))
])
ACCENT_OPTION_LIST = {
    df.ISSUE: vo.MATTER,
    df.VALUE: {de.MEAN_COLOR: scour({}, MEAN_COLOR, df.VALUE)},
    df.WIDGET: OptionList
}
ACCENT = OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.OPTION_LIST, deepcopy(ACCENT_OPTION_LIST))
])

# Font / Color Row_____________________________________________________________
FCM = {
    df.SUB: OrderedDict([
        (de.FONT, deepcopy(FONT)),
        (de.COLOR_1, deepcopy(COLOR_1)),
        (de.MARGIN, deepcopy(MARGIN))
    ]),
    df.WIDGET: WidgetRow
}
GMR = {
    df.SUB: OrderedDict([
        (de.GRADIENT, deepcopy(GRADIENT)),
        (de.MOD, deepcopy(MOD))
    ]),
    df.WIDGET: WidgetRow
}
MMR = {
    df.SUB: OrderedDict([
        (de.MOD, deepcopy(MOD)),
        (de.MASK, deepcopy(MASK))
    ]),
    df.WIDGET: WidgetRow
}
IDR = {
    df.SUB: OrderedDict([
        (de.INVERT, deepcopy(INVERT)),
        (de.DESATURATE, deepcopy(DESATURATE)),
    ]),
    df.WIDGET: WidgetRow
}
IMR = {
    df.SUB: OrderedDict([
        (de.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (de.MASK, deepcopy(MASK)),
    ]),
    df.WIDGET: WidgetRow
}
IRM = {
    df.SUB: OrderedDict([
        (de.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (de.RESIZE, deepcopy(RESIZE)),
        (de.MASK, deepcopy(MASK))
    ]),
    df.WIDGET: WidgetRow
}

# Lead / Trail Row_____________________________________________________________
LTR = {
    df.COLUMN_TEXT: "Lead & Trail",
    df.SUB: OrderedDict([
        (rk.LEAD, deepcopy(TEXT)),
        (rk.TRAIL, deepcopy(TEXT)),
    ]),
    df.WIDGET: WidgetRow
}
LTR[df.SUB][rk.LEAD][df.TOOLTIP] = Tip.LEAD
LTR[df.SUB][rk.TRAIL][df.TOOLTIP] = Tip.TRAIL
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

MAF = {
    df.SUB: OrderedDict([
        (de.MOD, deepcopy(MOD)),
        (de.ADD, deepcopy(ADD)),
        (de.FRAME, deepcopy(FRAME))
    ]),
    df.WIDGET: WidgetRow
}
MAW = {
    df.SUB: OrderedDict([
        (de.MOD, deepcopy(MOD)),
        (de.ADD, deepcopy(ADD))
    ]),
    df.WIDGET: WidgetRow
}
MFR = {
    df.SUB: OrderedDict([
        (de.MASK, deepcopy(MASK)),
        (de.FRAME, deepcopy(FRAME))
    ]),
    df.WIDGET: WidgetRow
}
P2R = {
    df.SUB: OrderedDict([
        (de.PATTERN_1, deepcopy(PATTERN)),
        (de.PATTERN_2, deepcopy(PATTERN))
    ]),
    df.WIDGET: WidgetRow
}
P3R = {
    df.SUB: OrderedDict([
        (de.PATTERN_1, deepcopy(PATTERN)),
        (de.PATTERN_2, deepcopy(PATTERN)),
        (de.PATTERN_3, deepcopy(PATTERN))
    ]),
    df.WIDGET: WidgetRow
}
