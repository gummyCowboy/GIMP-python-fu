#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from collections import OrderedDict
from roller_any_group import ManyGroup
from roller_constant import Issue as vo, NodePanel as np, Signal as si
from roller_constant_identity import Identity as de
from roller_container import PlanZ, Run, The
from roller_gimp_image import make_group_layer, make_plan_group
from roller_gimp_item import validate_item
from roller_gimp_layer import remove_layer
from roller_image_render import Render
from roller_maya import Maya
from roller_model_name import ModelName
from roller_ring import Ring

# {Plan group layer name (str): ordinal rank (int)}
PLAN_GROUP_LAYER = OrderedDict([
    # bottom layer ordinal, '999'
    ("{} {}".format(de.PLAN, de.BACKGROUND), 999)
])

# {group layer name (str): ordinal rank (int)}
WORK_GROUP_LAYER = OrderedDict([
    # top layer ordinal, '0'
    (de.PLAN, 0),

    # above the Light layer ordinal, '997'
    (de.ACCENT, 997),

    # bottom layer ordinal, '999'
    (de.BACKGROUND, 999)
])


class Model(ManyGroup):
    """Create Model Widget group and assign view-run-type runners."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)


class Chi(Maya):
    """Factor Plan and Work."""
    issue_q = 'back', 'matter'
    vote_type = vo.MAIN

    def __init__(self, any_group, view_i, prefix):
        """
        any_group: AnyGroup
            Has Model Widget group.

        view_i: int
            0 or 1; plan or work; view-type index

        prefix: string
            Prefix a Model group layer name.
        """
        self._prefix = prefix

        Maya.__init__(self, any_group, view_i, (), ())
        Render.gob.connect(si.CLOSE_VIEW_IMAGE, self.on_close_view_image)
        for i in (
            (si.MODEL_CREATED, self.on_model_created),
            (si.MODEL_MOVE, self.on_active_model_change),
            (si.MODEL_RENAME, self.on_model_rename),
            (si.PANEL_CHANGE, self.on_panel_change)
        ):
            Ring.gob.connect(*i)

    def do(self):
        """Manage layer output during a view run."""
        if self.is_matter:
            self.position_model_group()
            self.is_matter = False

        if self.is_back:
            Run.is_back = True
        self.reset_issue()

    def ensure_model_group(self, d):
        """
        Create Model group layer for the active Model.

        d: dict
            {Model name: Model}
        """
        if Run.j:
            i = self.view_i

            if i:
                group = None

            else:
                if not PlanZ.plan_group:
                    make_plan_group(self)
                group = PlanZ.plan_group
            for n, model in d.items():
                if model:
                    parent = model.group_layer_list[i]
                    if not parent:
                        # Create the Model's group layer.
                        model.group_layer_list[i] = make_group_layer(
                            Run.j, group, 0, n
                        )

    def on_close_view_image(self, *_):
        """The layer groups are gone, and new ones will be needed."""
        self.is_back = self.is_matter = True

    def on_model_created(self, *_):
        """
        A new Model has change.

        _: tuple
            (Ring -> Sent the Signal., Model -> newly created)
        """
        self.is_back = self.is_matter = True

    def on_model_rename(self, _, arg):
        """
        Rename Model owned layer.

        _: Ring
            Sent the Signal.

        arg: tuple
            (old name, new name)
        """
        def _rename(_z, _n, _i):
            """
            Recursively rename sub-Model layer.

            _z: group layer or GIMP image
            _n: string
                name prefix

            _i: int
                offset of layer name to replace
            """
            for _z1 in _z.layers:
                _z1.name = self._prefix + _n + _z1.name[_i:]
                if hasattr(_z1, 'layers'):
                    _rename(_z1, _n, _i)

        old_name, new_name = arg

        # Rename the layer output.
        # The Model's group layer is at a top of a layer tree.
        model = ModelName.get_model(new_name)
        if model:
            # (Plan, Work) index, '0 or 1'
            z = model.group_layer_list[self.view_i]
            if z:
                # old layer name cut-off index, 'i'
                i = len(old_name) + len(self._prefix)
                z.name = self._prefix + new_name + z.name[i:]
                _rename(z, new_name, i)

    def on_panel_change(self, _, arg):
        """
        _: gobject
            Sent the signal.

        arg: None or panel type enum
        """
        if arg != np.SUB:
            Run.is_back = True
            self.is_back = True

    def position_model_group(self):
        """
        Ensure the Model group layer order is in
        sync with ModelList's Model order.
        """
        j = Run.j
        if j:
            i = self.view_i
            name_q = The.model_list.get_active_model_name_list()
            if name_q:
                # {Model name: Model}, 'd'
                model_d = {n: ModelName.get_model(n) for n in name_q}

                self.ensure_model_group(model_d)

                order_d = self.prep_position(name_q[::-1])

                # Make a list of existing layer name
                # sorted by their ordinal position.
                # Layer offset will then be a layer
                # name's index in the sorted list.
                if i:
                    group = None
                    q = j.layers

                else:
                    group = PlanZ.plan_group
                    q = group.layers

                # Sort the list of ordinals so a
                # layer position offset can be derived.
                order_q = sorted([
                    order_d[z.name] for z in q if z.name in order_d
                ])

                # Process the active models.
                for offset, ordinal in enumerate(order_q):
                    for k, a in order_d.items():
                        if a == ordinal:
                            z = pdb.gimp_image_get_layer_by_name(j, k)

                            pdb.gimp_image_reorder_item(j, z, group, offset)
                            break
                pdb.gimp_displays_flush()

    def prep_position(self, name_q):
        """
        Create an order dict with the structure:
        {folder name: positional ordinal}.
        Fetch a list of layers for the view context.
        Depends on the view's output image, 'Run.j'.

        name_q: iterable
            [layer name, ...]

        Return: dict
            {layer name: position ordinal}
        """
        prefix = self._prefix

        # Make a list of layers to sort, 'q'.
        if self.view_i:
            q = [z for z in Run.j.layers if pdb.gimp_item_is_group(z)]
            d = WORK_GROUP_LAYER.copy()

        else:
            q = PlanZ.plan_group.layers
            d = PLAN_GROUP_LAYER.copy()

        for i1, n in enumerate(name_q, 1):
            d[prefix + n] = i1

        for i1, z in enumerate(q, 500):
            if d.get(z.name) is None:
                # Clean-up a dead Model.
                remove_layer(z)
        return d


class Plan(Chi):
    """Manage Model group layer for Plan."""

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, "{} ".format(de.PLAN))

    def on_active_model_change(self, *_):
        """
        Respond to a change of a Model's
        group layer position in the layer dock.
        """
        if PlanZ.plan_group:
            self.position_model_group()


class Work(Chi):
    """Manage Model group layer for Work."""

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Use to acquire the ModelList Widget.
        """
        Chi.__init__(self, any_group, 1, "")

    def get_model_folder_list(self):
        """
        Make a list of active Model group layer.

        Return: list
            [active Model group layer, ...]
        """
        name_q = The.model_list.get_active_model_name_list()
        model_q = [ModelName.get_model(n) for n in name_q]
        q = []

        for i in model_q:
            z = i.group_layer_list[1]
            if validate_item(z):
                q.append(z)
        return q

    def on_active_model_change(self, *_):
        """
        Respond to a change of a Model's
        group layer position in the Layers tree.
        """
        self.position_model_group()
