#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant import Step as sk
from roller_constant_identity import Identity as de
from roller_model_name import ModelName
from roller_helm import Helm

"""
________
Step Key
‾‾‾‾‾‾‾‾
A Step key identifies interface items such as a branching item list (a Node),
a group of options (a Preset), or a grouped Preset (a SuperPreset).

Nodes work together to structure the interface like a tree by creating
branches. A Preset effects the output and are ordered by their order in
the tree. A SuperPreset is like a limb on the tree. The limb can have
Node, Preset, and SuperPreset.

________________
Step Key Variant
‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
All step-key variants are string with a
period delimiter separating the navigation tree parts.

Model-name-step-key
    'model name.branch' or 'model name.branch.leaf'
    Reflect the current state of the interface.

Model-type-step-key
    'model type.branch' or 'model type.branch.leaf'
    Manage Model step creation and deletion.

__________________
Step Key Structure
‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
    Connect path item into a single string, delimiting
    each part with a period.

    A path item, a part, is a Node descriptor, a Preset key,
    or a SuperPreset key.
"""

SUPER_DEFAULT_STEP = {
    de.SHADOW: sk.DEFAULT_SHADOW_PRESET_LIST,
    sk.STEPS: sk.DEFAULT_STEPS_PRESET_LIST
}


def append_parts(step_k, q):
    """
    Append a part to a list of step-key parts.

    step_k: string
        Delimited with period.

    q: list
        [part, ...]; [string, ...]

    Return: string
        step-key
    """
    return connect_parts([step_k] + q)


def connect_parts(q):
    """
    Connect an iterable of strings into a step-key.

    q: iterable
        [string, ...]

    Return: string
        step-key format
    """
    return '.'.join(q)


def connect_sub_str(step_k, n):
    """
    Attach a string to a step-key.

    step_k: string
        a path

    n: string
        Append to step-key in a path format.

    Return: string
        the new path
    """
    if step_k:
        # Model branch
        return "{}.{}".format(step_k, n)

    # Steps item
    return n


def convert_name_to_type(step_k, model_type):
    """
    Make a Model-type-step-key from a Model-name-step-key
    by swapping the Model name for a Model type.

    step_key: tuple
        Model-name-step-key

    model_type: string
        Model type

    Return: Model-type-step-key or None
    """
    parts = get_parts(step_k)

    if len(parts) > 1:
        return append_parts(model_type, parts[1:])
    return step_k


def count_parts(step_k):
    """
    Count the number of parts in a step-key.

    step_k: string
        The parts are separated by a period.

    Return: int
        the number of parts in the step-key
    """
    return len(get_parts(step_k))


def drop_first_part(step_k):
    """
    Given a step-key, remove its first part.

    step_k: string
        step-key
        Assumed to be a Model branch having at least two parts.

    Return: string
        Trimmed step-key.
    """
    parts = get_parts(step_k)[1:]
    return connect_parts(parts)


def drop_last_part(step_k):
    """
    Given a step-key, remove its last part.

    step_k: string
        step-key

    Return: string
        Trimmed step-key.
    """
    parts = get_parts(step_k)[:-1]
    return connect_parts(parts)


def extract_value_d(name_step_k, d):
    """
    Get the Widget value dict for an AnyGroup.

    model_step_k: string
        "part.part..."

    d: dict
        {Model-name-step-key: AnyGroup}

    Return: dict or None
        {Identity: Widget value}
    """
    any_group = d.get(name_step_k)
    if any_group:
        return any_group.get_value_d()


def find_canvas_margin(name_step_k):
    """
    For a Model, determine if a Canvas/Margin step is active.

    name_step_k: string
        Model name is the first part.

    Return: bool
        Is True if the step is in the navigation tree.
    """
    return Helm.finds(
        make_model_branch(name_step_k, connect_parts((de.CANVAS, de.MARGIN)))
    )


def find_canvas_shift(name_step_k):
    """
    For a Model, determine if a Canvas/Shift step is active.

    name_step_k: string
    Return: bool
        Is True if the step is in the navigation tree.
    """
    return Helm.finds(
        make_model_branch(name_step_k, connect_parts((de.CANVAS, de.SHIFT)))
    )


def find_cell_margin(name_step_k):
    """
    For a Model, determine if a Cell/Margin step is active.

    name_step_k: string
    Return: bool
        Is True if the step is in the navigation tree.
    """
    return Helm.finds(make_model_branch(name_step_k, sk.CELL_MARGIN))


def find_cell_shift(name_step_k):
    """
    For a Model, determine if a Cell/Shift step is active.

    name_step_k: string
    Return: bool
        Is True if the step is in the navigation tree.
    """
    return Helm.finds(make_model_branch(name_step_k, sk.CELL_SHIFT))


def get_branch_part(step_k):
    """
    Assume the given step-key contains a Model branch. Return the
    branch descriptor.

    step_k: string
        UI item path

    Return: string
        Describe branch Node.
    """
    return get_parts(step_k)[-2]


def get_branch_step_list(branch_k):
    """
    Make a list of Model-name-step-key that have a sub-step-key.

    branch: string
        Is the Model-name-step-key at the start of a branch.

    Return: list
        Each item is part of the branch.
        [Model-name-step-key, ...]
    """
    # branch list -> [Model-name-step-key, ...], 'q'
    q = SUPER_DEFAULT_STEP.get(branch_k, [])

    if not q:
        # Model-branch
        keys = Helm.get_key_q()
        branch_parts = get_parts(branch_k)
        part_count = len(branch_parts)
        for name_step_k in keys:
            parts = get_parts(name_step_k)
            if parts[:part_count] == branch_parts:
                q.append(name_step_k)
    return q


def get_branch_value_d(branch_k):
    """
    Get a SuperPreset value dict made from a navigation tree branch.

    branch_k: string
        SuperPreset branch key

    Return: dict
        {Model-name-step-key: value dict}
    """
    d = {}
    p = Helm.get_group
    q = get_branch_step_list(branch_k)

    for name_step_k in q:
        # AnyGroup, 'a'
        a = p(name_step_k)
        if a and not a.dna.is_super_preset:
            d[name_step_k] = a.get_value_d()
    return d


def get_cell_shift(name_step_k):
    """
    Get a Cell/Shift Preset value dict.

    name_step_k: string
    Return: dict
        Shift Preset
    """
    any_group = Helm.get_group(make_model_branch(name_step_k, sk.CELL_SHIFT))
    if any_group:
        return any_group.get_value_d()


def get_deco_part(step_k):
    """
    Return a deco-type leaf name in the given branch.
    The deco-type leaves are always the third item in
    a step-key.

    step_k: string
        UI item path

    Return: string or None
        Describe branch Node.
    """
    parts = get_parts(step_k)
    if len(parts) > 2:
        return parts[2]


def get_first_part(step_k):
    """
    Get the first sub-string in a step-key.
    The step-key is delimited with a period.

    k: string
        step-key

    Return: string
        first part
    """
    return get_parts(step_k)[0]


def get_last_part(step_k):
    """
    Get the last sub-string in a step-key.

    step_k: string
        "part,..."; Part is either a Node or a leaf.
        The string is delimited by comma.

    Return: string
        step-key part
    """
    return get_parts(step_k)[-1]


def get_model(name_step_k):
    """
    Return the Model instance for a step-key. If the step-key
    is not part of a Model branch, then return None.

    name_step_k: string
    Return: Model instance or None
    """
    if count_parts(name_step_k):
        return ModelName.get_model(get_first_part(name_step_k))


def get_model_branch_key(name_step_k):
    """
    Clip the Model branch item from a step-key.

    name_step_k: string
    Return: string
        branch step-key
    """
    return drop_first_part(name_step_k)


def get_parts(step_k):
    """
    Create a list of step-key parts.

    step_k: string
        Delimited by a period.
    """
    return step_k.split('.')


def get_planner(name_step_k):
    """
    Get a Model's Property/Planner Preset value.

    name_step_k: string
        Is a Model-name-step-key having a Model name reference.

    Return: dict
        Planner Preset
    """
    return get_property_group(name_step_k).get_widget(de.PLANNER)


def get_property_group(name_step_k):
    return Helm.get_group(make_model_branch(name_step_k, de.PROPERTY))


def get_step_d(step_q):
    """
    Get the Model-name-step-key dict of a Model-name-step-key list.
    Include Node and Preset in list. Exclude SuperPreset.

    step_q: list
        [Model-name-step-key, ...]

    Return: dict
        {Model-name-step-key: value dict}
    """
    # steps in a view run, {step-key: option value dict}, 'step_d'
    step_d = OrderedDict()

    get_group = Helm.get_group

    # step-key, 'i'
    for name_step_k in step_q:
        # AnyGroup, 'a'
        a = get_group(name_step_k)
        if a and not a.dna.is_super_preset:
            # Is a terminal point of this branch.
            step_d[name_step_k] = a.get_value_d()
    return step_d


def make_model_branch(step_k, n):
    """
    Given a Model branch key, append a key to it.

    step_k: string
        Is a Model branch.

    n: string
        sub-step-key path
        'part', 'part.part', etc.
    """
    # A Model branch starts after the Model reference
    # which is the first part of a step-key.
    model = get_first_part(step_k)
    return connect_sub_str(model, n)


def get_type_text(n):
    """
    Some Preset keys have a comma in their string value. The comma
    is used to create a sub-type.

    For Example: "type, sub-type"

    n: string
        Node or Preset key

    Return: string
        type descriptor
    """
    return n.split(",")[0]


def get_sub_type_text(n):
    """
    Remove the non-visible sub-part of an item key or a step-key part.

    n: string
        descriptor; May resemble "label text, sub-type text" format.

    Return: string
        sub-type descriptor
    """
    q = n.split(",")

    if len(q) > 1:
        return q[1].strip()
    return ""


def key_has_model(step_k):
    """
    A step-key has a Model reference if its
    number of parts is greater than one.

    step_k: string
        Parts delimited with a period.

    Return: bool
        Is True if a list of parts has a Model reference.
    """
    return bool(ModelName.get_model(get_parts(step_k)[0]))


def prune_step_k(step_k, i):
    """
    Remove part or parts from the end of a step-key.

    step_k: string
        Parts delimited by a period.

    i: int
        Trim off step-key.

    Return: string
        step-key
    """
    parts = get_parts(step_k)
    return connect_parts(parts[:i])


def rename_model_in_step_d(d, old_name, new_name):
    """
    Rename every Model-name-step-key in a dict where
    the key is part of a Model's branch.

    d: dict
        {Model-name-step-k: value}
    """
    # Model-name-step-key, 'k'
    # value, 'a'
    for k, a in d.items():
        parts = get_parts(k)
        if parts[0] == old_name:
            d.pop(k)
            d[append_parts(new_name, parts[1:])] = a
