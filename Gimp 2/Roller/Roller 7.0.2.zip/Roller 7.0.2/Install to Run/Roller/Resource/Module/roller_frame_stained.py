#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_DIVIDE,
    LAYER_MODE_LUMA_DARKEN_ONLY,
    LAYER_MODE_NORMAL,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_frame import do_alt_frame
from roller_frame_alt import AltWrapFiller
from roller_gegl import edge, high_pass
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import add_layer
from roller_gimp_item import get_item_size
from roller_gimp_layer import (
    clone_layer, color_selection, do_curves, get_layer_position, saturate
)
from roller_gimp_selection import select_rect
from roller_preset import combine_seed, do_rotated_layer
from roller_preset_mod import do_mod
from roller_utility import random_rgb


def do_matter(maya):
    """
    Make a frame.

    maya: Stained
    Return: layer
        Stained/Wrap 'matter'
    """
    return do_alt_frame(maya)


def do_filler(maya):
    """
    Draw Filler material.

    maya: AltFiller
    z: layer
        Receive pattern.

    d: dict
        Stained Preset

    sel: GIMP selection channel
        Is the chip area.

    Return: layer
        Stained/Filler layer
    """
    j = Run.j
    d = maya.value_d

    combine_seed(d)

    z = add_layer(j, maya.group, maya.get_light(), "Material")
    z1 = do_rotated_layer(d, draw_color, z.parent, get_layer_position(z))
    z2 = clone_layer(z1)

    edge(z2)

    z3 = clone_layer(z2)
    z.mode = LAYER_MODE_DIVIDE
    z2 = pdb.gimp_image_merge_down(j, z3, CLIP_TO_IMAGE)

    # Remove the color.
    saturate(z2, -100.)

    do_curves(z2, (.0, .0, .7, 1.))

    # Convert the layer to be a black edge on white material.
    # no linear, '0'
    pdb.gimp_drawable_invert(z2, 0)

    z2.mode = LAYER_MODE_LUMA_DARKEN_ONLY
    z1 = pdb.gimp_image_merge_down(j, z2, CLIP_TO_IMAGE)

    saturate(z1, 30.)

    z2 = clone_layer(z1)

    high_pass(z2, 4., 1.)

    z2.mode = LAYER_MODE_DIFFERENCE
    z1 = pdb.gimp_image_merge_down(j, z2, CLIP_TO_IMAGE)
    z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

    do_curves(z, (.0, .0, .3764, .545, 1., 1.))
    do_mod(z, d[rk.BRW][de.MOD])
    return z


def draw_color(z, d):
    """
    Create color rectangles from two layers of color stripes.

    z: layer
        layer to draw on

    d: dict
        Stained Preset

    Return: layer
        Has color grid.
    """
    # vertical panes
    j = z.image
    x = y = x1 = y1 = .0
    w1, h1 = get_item_size(j)
    z.mode, z.opacity = LAYER_MODE_NORMAL, 100.
    w = d[de.PANE_W]

    set_fill_context_default()

    while x < w1:
        x1 = min(x1 + w, w1)

        select_rect(j, x, .0, x1 - x, h1)
        color_selection(z, random_rgb())
        x = x1

    z = clone_layer(z, n="Difference")
    z.mode = LAYER_MODE_DIFFERENCE

    # horizontal panes
    while y < h1:
        y1 = min(y1 + w, h1)

        select_rect(j, .0, y, w1, y1 - y)
        color_selection(z, random_rgb())
        y = y1
    return pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)


class Stained(AltWrapFiller):
    filler_k = de.FILLER_S1
    kind = material = de.STAINED
    shade_row = rk.BRW
    wrap_k = de.WRAP_FI

    def __init__(self, any_group, super_maya, k_path):
        AltWrapFiller.__init__(
            self, any_group, super_maya, k_path, do_matter, do_filler
        )
