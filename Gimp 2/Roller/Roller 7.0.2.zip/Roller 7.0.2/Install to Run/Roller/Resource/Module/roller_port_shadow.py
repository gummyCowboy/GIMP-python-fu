#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Define as df, NodePanel as np
from roller_constant_identity import Identity as de
from roller_def_tree import SHADOW_TREE_D
from roller_helm import Helm
from roller_port_preview import PortPreview
from roller_step import get_branch_value_d
from roller_widget_node_panel import NodePanel


class PortShadow(PortPreview):
    """Edit Shadow SuperPreset."""
    window_key = "Shadow"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Has option values.
        """
        self._node_panel = NodePanel(
            {df.ROLLER_WIN: d[df.ROLLER_WIN]}, self.on_port_change, np.SUB
        )
        PortPreview.__init__(self, d, g)

    def _draw_navigation(self, box):
        """
        Make a navigation tree.

        box: GTK container
            to receive group
        """
        box.add(self._node_panel)

        # tree dict, Node's AnyGroup key, Model-name-step-key
        self._node_panel.create_panel(SHADOW_TREE_D, de.SHADOW, de.SHADOW)

        any_group = Helm.get_group(de.SHADOW_PRESET)
        g = any_group.get_widget(de.PRESET)
        d = self.repo.get_a()
        g.load_a(d)

    def draw(self):
        """Draw Widget."""
        # Tell the Window class to clean-up after the Port with 'is_dirt'.
        self.is_dirt = True

        self.draw_row((self._draw_navigation, self.draw_process))

    @staticmethod
    def get_group_value():
        """
        Fetch the Shadow SuperPreset from the Helm.

        Return: dict
            Shadow SuperPreset
        """
        return get_branch_value_d(de.SHADOW)
