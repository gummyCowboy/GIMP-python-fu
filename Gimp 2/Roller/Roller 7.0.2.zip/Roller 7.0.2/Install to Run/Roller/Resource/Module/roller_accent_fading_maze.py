#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, pdb  # type: ignore
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_deco_output import init_deco_type
from roller_def_access import get_default_d
from roller_gimp_context import set_background, set_foreground
from roller_gimp_image import (
    add_sub_maya_group,
    add_wip_layer,
    clear_inverse_selection,
    clip_to_wip,
    make_group_layer
)
from roller_gimp_layer import clone_layer, flip_layer
from roller_gimp_mode import get_gradient_mode
from roller_gimp_selection import select_polygon, select_rect
from roller_maya_sub_accent import SubAccent
from roller_preset import combine_seed
from roller_wip import Wip


def do_matter(maya):
    """
    Make a matter layer.

    maya: Fading Maze
    Return: layer
        'matter'
    """
    def transform():
        # Transform three times.
        # left
        pdb.gimp_item_transform_perspective(z, *left_q)

        # bottom
        pdb.gimp_item_transform_perspective(z1, *bottom_q)

        # top
        pdb.gimp_item_transform_perspective(z2, *top_q)

    j = Run.j
    d = maya.value_d
    group = add_sub_maya_group(maya)
    z = add_wip_layer("Base", group)

    # Start maze.
    combine_seed(d)
    set_background(d[de.COLOR_2A][0])
    set_foreground(d[de.COLOR_2A][1])

    w = max(1, Wip.w // d[de.COLUMN])
    h = max(1, Wip.h // d[de.ROW])

    pdb.plug_in_maze(
        j, z,
        w, h,               # passage scale
        1,                  # yes, tileable
        0,                  # depth first algorithm
        d[de.RANDOM_SEED] + Globe.seed,
        0,                  # multiple
        0                   # offset
    )

    # primary output, 'z'
    z = pdb.gimp_image_merge_layer_group(j, group)
    group = add_sub_maya_group(maya)

    # Move the primary output to the group.
    pdb.gimp_image_reorder_item(j, z, group, 0)

    z1 = clone_layer(z)
    z2 = clone_layer(z1)

    pdb.gimp_selection_none(j)

    # Calculate transform coordinate.
    x = Wip.x
    y = Wip.y
    x1 = x + Wip.w
    y1 = y + Wip.h
    mid_x = (x + x1) / 2.
    mid_y = (y + y1) / 2.
    mid_x1 = mid_x - 1
    mid_y1 = mid_y - 1
    mid_x2 = mid_x + 1

    # Coordinate is a float.
    # point order: topleft, top-right, bottom-left, bottom-right
    left_q = map(round, (x, y - 1, mid_x2, mid_y - 1, x, y1, mid_x2, y1))
    bottom_q = map(round, (mid_x1, mid_y1, x1, mid_y1, x, y1, x1, y1))
    top_q = map(round, (x, y, x1, y, mid_x, mid_y, x1, mid_y))

    transform()
    pdb.gimp_image_merge_layer_group(j, group)

    group = make_group_layer(j, maya.group, 0, "Gradient")

    # Start gradient.
    e = maya.gradient_d

    e.update(d)

    e[de.GRADIENT] = d[rk.RW1][de.GRADIENT]
    arg, p = init_deco_type(de.GRADIENT, j, maya, group, e, 0, False)
    maya.rect = Wip.get_rect()

    select_rect(j, *maya.rect)

    z = p(*arg)

    clip_to_wip(z)

    z1 = clone_layer(z)
    z2 = clone_layer(z1)

    flip_layer(z2)
    pdb.gimp_selection_none(j)
    transform()

    # Remove overlapping layer material.
    select_polygon(j, (x, y - 1, mid_x, mid_y - 1, x, y1))
    clear_inverse_selection(group.layers[2])

    z = pdb.gimp_image_merge_layer_group(j, group)
    z.opacity = d[de.GRADIENT_OPACITY]
    z.mode = get_gradient_mode(d)
    return maya.finish(
        pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE), d[rk.RW1]
    )


class FadingMaze(SubAccent):
    kind = de.FADING_MAZE

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)

        self.gradient_d = get_default_d(de.GRADIENT_FILL)
        self.gradient_d[de.GRADIENT_TYPE] = de.TOP_CENTER_TO_BOTTOM_CENTER
