#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Signal as si, Step as sk
from roller_constant_identity import Identity as de
from roller_ring import Ring


def get_nav_step_list(d, k):
    """
    Maintain a lists of Model-name-step-key and AnyGroup, each
    sorted by the navigation tree's process order.

    d: dict
        Has Model-name-step-key of visible option group.
        {Model-name-step-key: AnyGroup}

    k: string
        Model-name-step-key
        (Node label, ...); Use the Model name for Model reference.
        Is the key to the first Node in the tree.

    Return: tuple
        ([Model-name-step-key, ...], [AnyGroup, ...])
    """
    def _walk(_any_group):
        """
        Use recursion to walk through the AnyGroup dict.
        Collect Model-name-step-key by its group type.

        _any_group: AnyGroup
            Is a Node.
        """
        for _dna in _any_group.get_node().copy_item_list():
            _name_step_k = _dna.any_group.name_step_k

            if _dna.is_preset:
                step_q.append(_name_step_k)
                group_q.append(_dna.any_group)

            _next_any_group = d[_name_step_k]
            if _next_any_group.dna.is_node:
                _walk(_next_any_group)

    # Is a list of Preset-filtered step-key that make up a view, 'step_q'.
    # [Preset's Model-name-step-key, ...]
    step_q = []

    # [AnyGroup, ...]; Synchronize with 'step_q'.
    group_q = []

    _walk(d[k])
    return step_q, group_q


class Helm:
    """
    Has a dictionary of Model-name-step-key with AnyGroup
    value that are visible in the user interface.
    """
    # {Model-name-step-key: AnyGroup}
    _d = {}

    # Read-only with the exception of Helm.
    # [sequenced by process order, Model-name-step-key of AnyGroup Preset-type]
    step_list = []

    # Synchronized with 'step_list'.
    # [sequenced by process order, Model-name-step-key of AnyGroup Preset-type]
    any_group_list = []

    is_virgin = True

    @staticmethod
    def add_step(k, a):
        """
        Add an AnyGroup to the Helm dict.

        k: string
            Model-name-step-key

        a: AnyGroup
            Correspond with step-key.
        """
        Helm._d[k] = a

    @staticmethod
    def finds(k):
        """
        Determine if a Model-name-step-key is the Helm dict.

        k: string
            Model-name-step-key

        Return: bool
            Is True if the key is in the Helm dict.
        """
        return k in Helm._d

    @staticmethod
    def get_all_step_list():
        """
        Provide a list of the steps in the navigation tree.

        Return: list
            [Model-name-step-key, ...]
        """
        return Helm._d.keys()

    @staticmethod
    def get_group(k):
        """
        Fetch an AnyGroup from the Helm dict.

        k: string
            Model-name-step-key

        Return: AnyGroup or None
        """
        return Helm._d.get(k)

    @staticmethod
    def get_key_q():
        """Return a list of active Model-name-step-key."""
        return Helm._d.keys()

    @staticmethod
    def get_step_q():
        """Return a copy of the Model-name-step-key list."""
        return Helm.step_list[:]

    @staticmethod
    def on_panel_change(_, arg):
        """
        When there's NodePanel change, the step list needs to be updated.

        _: gobject
            Sent the signal.

        arg: None or panel type enum
        """
        Helm.step_list, Helm.any_group_list = get_nav_step_list(
            Helm._d, sk.STEPS
        )
        Ring.plug(si.HELM_CHANGE, Helm.step_list)

        # Mark Model group as changed, so the AnyGroup
        # chain checks for the background change.
        Ring.add(Helm.get_group(de.MODEL), si.GROUP_CHANGE, None)

    @staticmethod
    def remove_step(k):
        """
        Remove a Model-name-step-key from the Helm dict.

        k: string
            Model-name-step-key
        """
        if k in Helm._d:
            Helm._d.pop(k)

    @staticmethod
    def remove_model(a):
        """
        Remove step having a given Model name reference from the Helm dict.

        a: string
            Model name
        """
        d = Helm._d
        for i in d.keys():
            k = i.split('.')[0]
            if a == k:
                d.pop(i)

    @staticmethod
    def rename_model(p, old_name, new_name):
        """
        Rename a Model. Find and replace the old name with the new name.

        p: function
            Call to rename step.
        """
        p(Helm._d, old_name, new_name)


if Helm.is_virgin:
    Ring.gob.connect(si.PANEL_CHANGE, Helm.on_panel_change)
    Helm.is_virgin = False
