#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import (
    Deco as dc,
    Gradient as fg,
    Grid as gr,
    Shape as sh,
    Row as rk,
    Widget as wi
)
from roller_constant_identity import Identity as de
from roller_preset import get_line_fill_state
from roller_step import count_parts, get_branch_part

"""
The collection of 'get_hidden' function have the same signature.
The order of the arguments follows a pattern of usage: more to less.

def get_hidden...()
    Make a hidden Widget key set.

    d: dict
        Preset
        {Identity: Widget value}

    q: set
        {key, ...}
        Hide option when its Switch is off.

    any_group: AnyGroup
    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
"""

COMMON_FORMAT_SET = {de.PLAN, de.PREVIEW}

# EXCLUDE______________________________________________________________________
# Sub-Type options are excluded when the Preset's
# Type is not a match in the Type collection.
# The 'EXCLUDE' type dict has the following structure:
# {(Type, ...): sub-Type option}
EXCLUDE_BACKGROUND_D = {
    (de.CLOUDS, de.PLASMA): {de.RANDOM_SEED},
    (de.COLOR,): {de.COLOR_1},
    (de.GRADIENT,): {de.GRADIENT, de.GRADIENT_ANGLE, de.GRADIENT_TYPE},
    (de.IMAGE,): {de.FILLED, de.IMAGE_CHOICE},
    (de.PATTERN,): {de.PATTERN}
}
EXCLUDE_BLUR_D = {
    0: {de.SIZE_X, de.SIZE_Y},
    1: {de.RADIUS, de.PERCENTILE, de.ALPHA_PERCENTILE}
}
EXCLUDE_BUMP_D = {
    de.CLOTH: {de.BLUR_X, de.BLUR_Y},
    de.EDGE: {de.AMOUNT}
}
EXCLUDE_DROP_ZONE_D = {
    de.COLOR: {de.COLOR_2A},
    de.RANDOM_COLOR: {de.RANDOM_SEED}
}
EXCLUDE_CORNER_OVERLAP_D = {
    de.COLOR: {de.COLOR_2},
    de.RANDOM_COLOR: {de.RANDOM_SEED}
}
EXCLUDE_MASK_D = {
    (de.EYE,): {de.PUPIL_SCALE},
    (de.FRINGE,): ([(rk.RW1, (de.BRUSH_D,)), de.CONTRACT]),
    (de.GRADIENT,): {de.GRADIENT_ANGLE, de.GRADIENT_TYPE},
    (de.IMAGE, de.FRINGE): {rk.RW1},
    (de.IMAGE,): ([(rk.RW1, (de.IMAGE_CHOICE,))]),
    (de.PARALLELOGRAM_LEFT, de.PARALLELOGRAM_RIGHT): {de.PARALLELOGRAM_SCALE},
    (de.RIP,): {de.AMP, de.SMOOTH, de.RANDOM_SEED},
    (de.TEXT,): (de.TEXT, de.FONT)
}
EXCLUDE_NOISE_D = {
    (de.DRIP,): {de.LENGTH, de.OPAQUE, de.RADIUS},
    (de.INK, de.RIFT, de.RIFT): {de.RANDOM_SEED},
    (de.RIFT,): {de.NOISE_AMOUNT},
    (de.SPECK,): {de.SPECK_NOISE}
}
CELL_COUNT_SET = {de.PER}
CELL_SIZE_SET = {de.COLUMN_W, de.GRID_SIZE, de.ROW_H}
EXCLUDE_DECO_D = {
    (de.CLOUDS, de.PLASMA, de.RANDOM_COLOR): {de.RANDOM_SEED},
    (de.COLOR, de.GRID): {de.COLOR_1},
    (de.GRADIENT,): {de.GRADIENT, de.GRADIENT_ANGLE, de.GRADIENT_TYPE},
    (de.IMAGE,): ([(rk.RW1, (de.IMAGE_CHOICE,))]),
    (de.GRID,): {de.GRID},
    (de.PATTERN,): {de.PATTERN}
}
EXCLUDE_BORDER_D = {}
EXCLUDE_BORDER_D.update(EXCLUDE_DECO_D)
EXCLUDE_BORDER_D.update({(de.IMAGE,): {de.IMAGE_CHOICE}})
EXCLUDE_BOX_D = {
    (de.CELL_COUNT,): CELL_COUNT_SET,
    (de.CELL_COUNT, de.SHAPE_COUNT): {de.COLUMN, de.ROW},
    (de.CELL_SIZE,): CELL_SIZE_SET
}
EXCLUDE_CAPTION_D = {
    (de.TEXT,): {de.TEXT},
    (de.SEQUENCE,): {de.START_NUMBER},
    (de.SEQUENCE, de.IMAGE_NAME): {rk.LTR}
}
EXCLUDE_FLOOR_SAMPLE_D = {
    de.COLOR: {de.COLOR_2A},
    de.RANDOM_COLOR: {de.RANDOM_SEED}
}
EXCLUDE_FRINGE_D = {(de.MULTI_COLOR,): {de.COLOR_6, de.COLOR_COUNT}}
EXCLUDE_FRINGE_D.update(EXCLUDE_DECO_D)
EXCLUDE_FRINGE_D.update({(de.IMAGE,): {de.IMAGE_CHOICE}})
EXCLUDE_IMAGE_D = {
    (de.FILE,): {de.FILE},
    (de.FOLDER, de.RANDOM): {de.FOLDER, de.FILTER},
    (de.IMAGE_NAME,): {de.IMAGE_NAME},
    (de.LOOP,): {de.LOOP},
    (de.NEXT,): {de.NEXT},
    (de.PREVIOUS,): {de.PREVIOUS},
    (de.RANDOM,): {de.RANDOM_SEED},
    (de.TAB,): {de.TAB}
}
EXCLUDE_OVER_D = {
    (de.CLOUDS, de.PLASMA): {de.RANDOM_SEED},
    (de.COLOR,): {de.COLOR_1},
    (de.GRADIENT,): {de.GRADIENT, de.GRADIENT_ANGLE, de.GRADIENT_TYPE},
    (de.IMAGE,): {de.IMAGE_CHOICE},
    (de.PATTERN,): {de.PATTERN}
}
EXCLUDE_RESIZE_D = {
    de.CROP: {de.CROP_H, de.CROP_W, de.CROP_X, de.CROP_Y},
    de.FIXED: {de.FIXED_H, de.FIXED_W},
    de.FACTOR: {de.HEIGHT, de.WIDTH},
    de.COVER: {de.COVER},
    de.FILLED: {de.FILLED},
    de.LOCKED: {de.LOCKED},
    de.TRIM: {de.TRIM}
}
EXCLUDE_TABLE_D = {
    (de.CELL_COUNT,): CELL_COUNT_SET,
    (de.CELL_COUNT, de.CELL_SIZE): {de.CELL_SHAPE},
    (de.CELL_SIZE,): CELL_SIZE_SET,
    (de.CELL_SIZE, de.SHAPE_COUNT): {de.PIN},
    (de.SHAPE_COUNT,): {de.ECS},
    (de.CELL_COUNT, de.SHAPE_COUNT): {de.COLUMN, de.ROW}
}
# EXCLUDE‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

DECAY_SET = {de.COLOR_1, de.COLORIZE_OPACITY}
PARALLELOGRAM_SET = (
    de.PARALLELOGRAM_ALT_LEFT,
    de.PARALLELOGRAM_ALT_RIGHT,
    de.PARALLELOGRAM_LEFT,
    de.PARALLELOGRAM_RIGHT
)
MASK_FRINGE_SET = {de.HORZ_SCALE, de.VERT_SCALE}
MASK_SUB_TYPE_SET = (
    (de.CORNER, de.CORNER_TYPE),
    (de.HEXAGON, de.HEXAGON_TYPE),
    (de.OCTAGON, de.OCTAGON_TYPE),
    (de.RECTANGLE, de.RECTANGLE_TYPE),
    (de.TRIANGLE, de.TRIANGLE_TYPE)
)
WAVE_COLOR_SET = de.ALTERNATE, de.COLOR


def _hide_gradient_type(d, q, n):
    """
    For deco option group, hide sub-gradient option.

    d: dict
        deco Preset

    q: set
        {Identity, ...}
        Are hidden from the user.

    n: string
        deco Type
    """
    if n == de.GRADIENT:
        # Shape-burst gradients radiate from the center.
        if d.get(de.GRADIENT_TYPE) in fg.SHAPED_TYPE_LIST:
            q.update({de.GRADIENT_ANGLE})


def do_per(group):
    """
    Change the Per/Open Button's visibility.

    group: AnyGroup
    """
    if group:
        g = group.get_widget(de.PER)
        if g:
            # A PerGroupEmpty has no sub-Widget.
            if hasattr(g, 'button'):
                # Open Button
                g1 = g.button

                if not g.check_button.get_ui():
                    g1.hide()
                else:
                    g1.show()


def get_hidden_background(d, q, *_):
    n = d.get(de.TYPE)

    if n == de.EMPTY:
        q.update(([(rk.RW1, (de.BUMP, de.MOD))]))
        return q - {de.TYPE}

    q = set()
    n = d.get(de.TYPE)

    q.update(([(rk.RW1, ())]))

    for i, a in EXCLUDE_BACKGROUND_D.items():
        if n not in i:
            q.update(a)

    _hide_gradient_type(d, q, n)
    return q


def got_hidden_blur(d, q, *_):
    if d.get(de.SWITCH):
        q = set()
        n = d.get(de.TYPE)

        for i, a in EXCLUDE_BLUR_D.items():
            if n != i:
                q.update(a)
    return q


def get_hidden_border(d, q, any_group, branch_k):
    if d.get(de.SWITCH):
        q = set()
        n = d.get(de.TYPE)

        for i, a in EXCLUDE_BORDER_D.items():
            if n not in i:
                q.update(a)

        _hide_gradient_type(d, q, n)
        if branch_k in dc.FACIAL_SET:
            q.update({de.OBEY_MARGIN})

    do_per(any_group)
    return q


def get_hidden_box(d, *_):
    q = set()
    n = d.get(de.GRID_TYPE)
    r = None

    for i, a in EXCLUDE_BOX_D.items():
        if n not in i:
            q.update(a)

    if n in gr.COUNT_SET:
        r, c = d.get(de.ROW), d.get(de.COLUMN)

    if r is not None:
        if r == c and r == 1:
            # Hide First Cell Indented checkbox.
            q.update({de.INDENT})
    return q


def get_hidden_bump(d, q, *_):
    if d.get(de.SWITCH):
        q = set()
        n = d.get(de.TYPE)
        for i, a in EXCLUDE_BUMP_D.items():
            if n != i:
                q.update(a)
    return q


def get_hidden_caption(d, q, any_group, branch_k):
    if d.get(de.SWITCH):
        n = d.get(de.TYPE)

        if n == de.TEXT and not d[de.TEXT]:
            q -= {de.TYPE, de.TEXT}
        else:
            # hidden Widget key, 'q'
            q = set()

            for i, a in EXCLUDE_CAPTION_D.items():
                if n not in i:
                    q.update(a)

            # Face and Facing Caption don't have the Clip-to-Cell option.
            if branch_k in dc.FACIAL_SET:
                q.update({de.OBEY_MARGIN})

    do_per(any_group)
    return q


def get_hidden_cell(d, *_):
    q = set()
    n = d.get(de.CELL_SHAPE)

    if n not in PARALLELOGRAM_SET:
        q.update({de.PARALLELOGRAM_SCALE})
    return q


def get_hidden_mean_colored(d, *_):
    q = set()

    if d.get(de.MEAN_COLOR):
        q.update(([(de.COLOR_2A, 0)]))

    else:
        q.update(([(de.COLOR_2A, 2)]))
    return q


def get_hidden_corner_overlap(d, *_):
    q = set()
    n = d.get(de.TYPE)

    for i, a in EXCLUDE_CORNER_OVERLAP_D.items():
        if n != i:
            q.update(a)
    return q


def get_hidden_decay(d, *_):
    q = set()

    if not d.get(de.COLORIZE):
        q.update(DECAY_SET)
    return q


def get_hidden_drop_zone(d, *_):
    q = set()
    n = d.get(de.TYPE)

    for i, a in EXCLUDE_DROP_ZONE_D.items():
        if n != i:
            q.update(a)

    if not d[de.KEEP]:
        q.update({de.NAME})
    return q


def get_hidden_floor_sample(d, *_):
    q = set()
    n = d.get(de.TYPE)

    for i, a in EXCLUDE_FLOOR_SAMPLE_D.items():
        if n != i:
            q.update(a)
    return q


def get_hidden_option_list(d, *_):
    q = set()

    if not d.get(de.SWITCH):
        q = {de.OPTION_LIST}
    return q


def get_hidden_fringe(d, q, any_group, branch_k):
    if d.get(de.SWITCH):
        q = set()
        n = d.get(de.TYPE)

        for i, a in EXCLUDE_FRINGE_D.items():
            if n not in i:
                q.update(a)

        _hide_gradient_type(d, q, n)

        if n == de.MULTI_COLOR:
            q.update(([(de.COLOR_6, d[de.COLOR_COUNT])]))

        if branch_k in dc.FACIAL_SET:
            q.update({de.OBEY_MARGIN})

    do_per(any_group)
    return q


def get_hidden_accent_gradient(d, *_):
    q = set()

    _hide_gradient_type(d, q, de.GRADIENT)
    return q


def get_hidden_gradient(d, *_):
    q = set()

    _hide_gradient_type(d, q, de.GRADIENT)
    return q


def get_hidden_image(d, q, any_group, branch_k):
    if d.get(de.SWITCH):
        q = set()
        if branch_k in dc.FACIAL_SET:
            q.update({de.ANGLE, de.JUSTIFY, de.OBEY_MARGIN})

    do_per(any_group)
    return q


def get_hidden_image_choice(d, q, *_):
    if d.get(de.SWITCH):
        q = set()
        n = d.get(de.TYPE)

        for i, a in EXCLUDE_IMAGE_D.items():
            if n not in i:
                q.update(a)

        # Folder and Random have overlap.
        if n != de.FOLDER:
            q.update({de.FOLDER_ORDER})

        if not d[de.LAYERED]:
            q.update({de.LAYER_ORDER})
        if not d[de.SLICE]:
            q.update({de.COLUMN, de.ROW, de.SLICE_ORDER})
    return q


def get_hidden_inset(d, q, *_):
    if d.get(de.SWITCH):
        q -= {de.INTENSITY}
        if d.get(de.INTENSITY):
            q = set()
    return q


def get_hidden_light(d, q, *_):
    if d.get(de.SWITCH):
        q = set()
        n = d.get(de.TYPE)

        for i, a in EXCLUDE_BACKGROUND_D.items():
            if n not in i:
                q.update(a)
        _hide_gradient_type(d, q, n)
    return q


def get_hidden_line(d, q, any_group, branch_k):
    if d.get(de.SWITCH):
        q = set()

        if branch_k in dc.FACIAL_SET:
            # Face and Facing don't have a Margin group.
            q.update({de.OBEY_MARGIN})
        if not get_line_fill_state(d):
            q.update((de.BRUSH, de.HARDNESS))

    do_per(any_group)
    return q


def get_hidden_mask(d, q, *_):
    if d.get(de.SWITCH):
        n = d.get(de.TYPE)

        if n == de.TEXT and not d[de.TEXT]:
            q -= {de.TYPE, de.TEXT}
        else:
            q = set()

            for i, a in EXCLUDE_MASK_D.items():
                if n not in i:
                    q.update(a)

            _hide_gradient_type(d, q, n)

            for sub_type, mask_k in MASK_SUB_TYPE_SET:
                if n != sub_type:
                    q.update({mask_k})

            if n == de.FRINGE:
                q.update(MASK_FRINGE_SET)
            if not d[de.FEATHER]:
                q.update({de.STEPS})
    return q


def get_hidden_mod(d, q, *_):
    if d.get(de.SWITCH):
        q = set()
        if not d.get(de.COLORIZE):
            q = {de.COLOR_1, de.MODE, de.OPACITY}
    return q


def get_hidden_noise(d, q, *_):
    if d.get(de.SWITCH):
        q = set()
        n = d.get(de.TYPE)
        for i, a in EXCLUDE_NOISE_D.items():
            if n not in i:
                q.update(a)
    return q


def get_hidden_over_overlay(d, *_):
    q = set()
    n = d.get(de.TYPE)

    for i, a in EXCLUDE_OVER_D.items():
        if n not in i:
            q.update(a)

    if n == de.COLOR:
        q.update({de.BLUR})

    _hide_gradient_type(d, q, n)
    return q


def get_hidden_plaque(d, q, any_group, branch_k):
    if d.get(de.SWITCH):
        q = set()
        n = d.get(de.TYPE)

        for i, a in EXCLUDE_DECO_D.items():
            if n not in i:
                q.update(a)

        if n == de.IMAGE:
            q.update(([(rk.RW1, ())]))

        _hide_gradient_type(d, q, n)
        if branch_k in dc.FACIAL_SET:
            q.update({de.OBEY_MARGIN})

    do_per(any_group)
    return q


def get_hidden_rect_pattern(d, *_):
    return {(de.COLOR_6A, d[de.COLOR_COUNT])}


def get_hidden_resize(d, *_):
    q = set()
    n = d.get(de.TYPE)

    for i, a in EXCLUDE_RESIZE_D.items():
        if n != i:
            q.update(a)
    return q


def get_hidden_shadow(d, q, *_):
    if d.get(de.SWITCH):
        q -= {de.INTENSITY}
        if d.get(de.INTENSITY):
            q = set()
    return q


def get_hidden_stencil(d, q, *_):
    n = d.get(de.TYPE)

    if n == "None":
        q -= {de.TYPE}

    else:
        q = set()
    return q


def get_hidden_switch(d, q, any_group, _):
    if d.get(de.SWITCH):
        q = set()

    do_per(any_group)
    return q


def get_hidden_table(d, q, any_group, _):
    q = set()
    n = d.get(de.GRID_TYPE)

    for i, a in EXCLUDE_TABLE_D.items():
        if n not in i:
            q.update(a)

    if d.get(de.CELL_SHAPE) != de.RECTANGLE:
        q.update({de.PER})

    if n == de.SHAPE_COUNT:
        n1 = d.get(de.ECS)

    else:
        n1 = d.get(de.CELL_SHAPE)

    if n1 not in sh.DOUBLE_SET:
        q.update({de.INDENT})

    if n1 not in PARALLELOGRAM_SET:
        q.update({de.PARALLELOGRAM_SCALE})

    if n == de.CELL_COUNT or d.get(de.CELL_SHAPE) == de.RECTANGLE:
        # The Per option is for merging cells and
        # is pointless if there is only one cell.
        if (d.get(de.ROW) == 1 and d.get(de.COLUMN) == 1):
            q.update({de.PER})

    if de.PER not in q:
        do_per(any_group)
    return q


def get_hidden_triangle_reverb(d, *_):
    q = set()
    n = d.get(de.TYPE)

    if n == de.PATTERN:
        q.update(([(rk.PAR, ())]))

    else:
        q.update(([(rk.PAR, (de.PATTERN_1, de.PATTERN_2))]))

    if n == de.COLOR:
        q.update(([(de.COLOR_2A, 2)]))

    else:
        q.update(([(de.COLOR_2A, 0)]))
    return q


def get_hidden_wave_fill(d, *_):
    q = set()

    if d.get(de.TYPE) not in WAVE_COLOR_SET:
        q.update(([(de.COLOR_2, 0)]))
    else:
        q.update(([(de.COLOR_2, 2)]))
    return q


def hide_option(any_group):
    """
    Set option visibility for an AnyGroup.

    any_group: AnyGroup
    """
    d = any_group.get_value_d()
    branch_k = None
    if any_group:
        type_step_k = any_group.type_step_k

        if count_parts(type_step_k) > 2:
            # index for a Model branch (Canvas, Cell, Face, Facing), '1'
            branch_k = get_branch_part(type_step_k)
        set_visibility(
            any_group, ROUTE_SQUISH[any_group.dna.key](
                d,
                {k for k in d if k not in wi.VISIBLE_SET},
                any_group,
                branch_k
            )
        )


def hide_options(any_group):
    """
    Set option visibility for an AnyGroup and its embedded sub-AnyGroup.

    any_group: AnyGroup
    """
    hide_option(any_group)

    a = any_group.sub_any_group
    if a:
        hide_option(a)


def set_visibility(any_group, q):
    """
    Set Widget visibility for an option group.

    d: dict
        {Widget key: Widget}

    q: set
        Hide Widget key.
        {Widget's Preset/Identity, ...}
    """
    g = None
    d = any_group.get_value_d()
    q1 = {i for i in d.keys()} - q

    # Ensure that common Widget types are always showing.
    q1.update(COMMON_FORMAT_SET)

    for i in d:
        g = any_group.get_widget(i)

        g.show() if i in q1 else g.hide()
        if i == de.PER:
            pass

    for i in q:
        if isinstance(i, tuple):
            # (Widget key, argument for visibility)
            # Widget key index, '0'; argument index, '1'
            g = any_group.get_widget(i[0])
            g.update_visibility(i[1])
    if g:
        g.roller_win.resize()


# {Preset key: function}
# The functions return an iterable of hidden option key.
ROUTE_SQUISH = {
    de.ACCENT: get_hidden_option_list,
    de.ADD_ABOVE: get_hidden_switch,
    de.ADD_ALT: get_hidden_switch,
    de.ADD: get_hidden_switch,
    de.BACK_GAME: get_hidden_mean_colored,
    de.BACKGROUND: get_hidden_background,
    de.BELOW: get_hidden_switch,
    de.BLUR_D: got_hidden_blur,
    de.BORDER: get_hidden_border,
    de.BUMP: get_hidden_bump,
    de.CAPTION: get_hidden_caption,
    de.CLAY_CHEMISTRY: get_hidden_accent_gradient,
    de.COLOR: get_hidden_switch,
    de.COLOR_GRID: get_hidden_mean_colored,
    de.CORNER_OVERLAP: get_hidden_corner_overlap,
    de.DROP_ZONE: get_hidden_drop_zone,
    de.EMBOSS: get_hidden_switch,
    de.FLOOR_SAMPLE: get_hidden_floor_sample,
    de.FRAME: get_hidden_option_list,
    de.FRINGE: get_hidden_fringe,
    de.GALACTIC_FIELD: get_hidden_accent_gradient,
    de.GRADIENT_FILL: get_hidden_gradient,
    de.IMAGE_CHOICE: get_hidden_image_choice,
    de.IMAGE: get_hidden_image,
    de.INSET: get_hidden_inset,
    de.INNER_SHADOW: get_hidden_shadow,
    de.LIGHT: get_hidden_light,
    de.LINE: get_hidden_line,
    de.MARGIN: get_hidden_switch,
    de.MASK: get_hidden_mask,
    de.MOD: get_hidden_mod,
    de.NOISE_D: get_hidden_noise,
    de.OVERLAY_OV: get_hidden_over_overlay,
    de.PLAQUE: get_hidden_plaque,
    de.RECT_PATTERN: get_hidden_rect_pattern,
    de.RESIZE: get_hidden_resize,
    de.SHADOW_1: get_hidden_shadow,
    de.SHADOW_2: get_hidden_shadow,
    de.SHIFT: get_hidden_switch,
    de.STENCIL: get_hidden_stencil,
    de.STRIP: get_hidden_switch,
    de.TRIANGLE_REVERB: get_hidden_triangle_reverb,
    de.TYPE_BOX: get_hidden_box,
    de.TYPE_CELL: get_hidden_cell,
    de.TYPE_STACK: get_hidden_cell,
    de.TYPE_TABLE: get_hidden_table,
    de.WAVE_FILL: get_hidden_wave_fill,
    de.WRAP_DE: get_hidden_decay,
    de.INNER_SHADOW: get_hidden_shadow,
    de.SHADOW_1: get_hidden_shadow,
    de.SHADOW_2: get_hidden_shadow
}
