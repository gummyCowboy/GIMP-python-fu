#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import FOREGROUND_FILL, pdb  # type: ignore
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_context import set_fill_context, set_foreground
from roller_maya_sub_accent import SubAccent


def do_matter(maya):
    """
    Make a matter layer for ColorFill.

    maya: ColorFill
    Return: layer or None
        'matter'
    """
    d = maya.value_d
    z = maya.bg_z
    maya.bg_z = None

    pdb.gimp_image_reorder_item(Run.j, z, maya.group, maya.get_light())

    # RGBA, 'q'
    q = d[de.COLOR_1A]

    # Use to set the opacity context for bucket fill.
    d[de.FILL_OPACITY] = q[3] / 255. * 100.

    set_fill_context(d)
    set_foreground(q)
    pdb.gimp_drawable_edit_bucket_fill(z, FOREGROUND_FILL, .0, .0)
    return maya.finish(z, d[rk.BRW])


class ColorFill(SubAccent):
    kind = de.COLOR_FILL

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
