#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_container import The
from roller_constant import Define as df, Step as sk, Signal as si
from roller_constant_identity import Identity as de
from roller_helm import Helm
from roller_shelf import Shelf
from roller_preset_super import load_super
from roller_port_process import PortProcess
from roller_step import (
    connect_sub_str,
    drop_last_part,
    get_first_part,
    get_model_branch_key,
    get_parts
)
from roller_utility import make_split_key
from roller_widget_step import Step
from roller_widget_button import (
    AcceptButton, AcceptAllButton, AcceptNoneButton, CancelButton
)
from roller_widget_row import WidgetRow

NO_SHOW = (
    "Cell.Rectangle", "Cell.Type", "Property", "Preset", "Canvas.Shift"
)


class PortStep(PortProcess):
    """Display a Model-oriented step manager."""
    window_key = "Step"

    def __init__(self, d, g):
        """
        g: Button
            Is responsible.
        """
        self._step = None
        self._no_show_set = set()
        PortProcess.__init__(self, d, g)

    def _draw_lists(self, box):
        """
        Draw, load, and verify the Step option group.

        box: GTK container
            Receive Widget group.
        """
        active_set = set()
        shelf_set = set()
        active_list = Helm.get_all_step_list()
        shelf_list = Shelf.get_step_list()
        q = The.model_list.get_complete_model_name_list()

        self._load_model_step(q, active_list, active_set)
        self._load_model_step(q, shelf_list, shelf_set)

        self._step = Step(
            shelf_set,
            active_set,
            **{
                df.COLOR: self.color,
                df.RELAY: [],
                df.ROLLER_WIN: self.roller_win
            }
        )
        box.add(self._step)

    def _load_model_step(self, model_name_list, load_list, load_set):
        """
        Load a set of Model-name-step-key from a comprehensive Model list.
        Some step are not shown in the Step Widget, so they are put away
        for re-addition.

        model_name_list: list
            [Model name, ...]
            Has every Model in the currents Steps.

        load_set: list
            [Model-name=step-key, ...]
            Model default steps are included.

        load_set: set
            {Model-name=step-key, ...}
            Model default steps are not included.
        """
        for name_step_k in load_list:
            parts = get_parts(name_step_k)
            name = parts[0]
            if name in model_name_list:
                load_set.add(name)

                branch = get_model_branch_key(name_step_k)
                name_step_k = connect_sub_str(name, branch)

                if branch in NO_SHOW:
                    self._no_show_set.add(name_step_k)

                elif "," in name_step_k:
                    # A Model Preset has a comma.
                    self._no_show_set.add(name_step_k)
                elif branch:
                    load_set.add(name_step_k)

                    # Include branch node step.
                    # deco leaf step length, '3'
                    if len(parts) >= 2:
                        load_set.add(connect_sub_str(parts[0], parts[1]))

    def draw(self):
        """Draw Widget."""
        self.draw_column((self._draw_lists, self.draw_step_process))

    def draw_step_process(self, box):
        """
        Draw a Widget group with cancel and accept options.

        box: GTK Box container
            Receive Widget group.
        """
        g = WidgetRow(
            **{
                df.PADDING: (0, 0, 4, 4),
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win,
                df.SUB: OrderedDict([
                    (de.CANCEL, {df.WIDGET: CancelButton}),
                    (de.ACCEPT_NONE, {df.WIDGET: AcceptNoneButton}),
                    (de.ACCEPT_ALL, {df.WIDGET: AcceptAllButton}),
                    (de.ACCEPT, {df.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        box.add(g)

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return lambda: None, self.on_accept_model_step

    def on_accept_model_step(self, g):
        """
        Modify the navigation step tree with a new tree.

        g: Widget
            Is responsible or is in focus.
        """
        model_d = OrderedDict()
        tree_step_list = []
        get_group = Helm.get_group
        node = get_group(sk.STEPS).get_node()

        # ModelList dict with all Models,
        # shelved and active, 'all_model_d'
        all_model_d = The.model_list.get_model_dict()

        active_model_d = The.model_list.create_active_model_dict()

        if g.key != de.ACCEPT_NONE:
            tree_step_list = self._step.get_ui(
                is_all=g.key == de.ACCEPT_ALL
            )

        # the user chosen Model name set, 'model_name_set'
        new_name_set = {get_first_part(i) for i in tree_step_list}

        # Add 'no show' step for chosen Model.
        for name_step_k in self._no_show_set:
            model_name = get_first_part(name_step_k)
            if model_name in new_name_set:
                tree_step_list.append(name_step_k)

        # Add branch.
        for name_step_k in tree_step_list[::]:
            branch = drop_last_part(name_step_k)
            if branch not in tree_step_list:
                tree_step_list.append(branch)

        # Init the Model dict in the existing order.
        for model_name, model_type in active_model_d.items():
            if model_name in new_name_set:
                model_d[model_name] = model_type
                new_name_set -= {model_name}

        # Newly added Model are tacked onto
        # the end of the Model dict.
        for n in new_name_set:
            model_d[n] = all_model_d[n]

        for model_name in all_model_d:
            if model_name in model_d:
                if model_name not in active_model_d:
                    # Activate a shelved Model.
                    node.emit(si.MODEL_ACTIVE, model_name)

        # Add Model/Preset.
        for model_name, model_type in model_d.items():
            n = make_split_key(de.PRESET, model_type)
            k = connect_sub_str(model_name, n)
            if k not in tree_step_list:
                tree_step_list.append(k)

        # Tell NodePanel to update itself.
        node.emit(si.UPDATE_TREE, (tree_step_list, model_d))

        # SuperPreset, 'e'
        # {Model-name-step-key: value dict}
        e = {}

        for k in Helm.get_key_q():
            d = Shelf.get_step_d(k)
            if d:
                # Add to the SuperPreset for loading.
                e[k] = d
                Shelf.remove_step(k)

        if e:
            load_super(e)
        self.repo.any_group.changed()
