#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb  # type: ignore
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import add_wip_layer
from roller_gimp_layer import color_selection, get_mean_color
from roller_gimp_selection import invert_selection, select_polygon
from roller_maya_sub_accent import SubAccent
from roller_polygon import make_coord_list
from roller_wip import Wip


def do_matter(maya):
    """
    Make a matter layer for BackGame

    maya: BackGame
    Return: layer or None
        'matter'
    """
    j = Run.j
    d = maya.value_d
    count = int(d[de.TRIANGLE])

    set_fill_context_default()

    # x-vector coordinate list, 'q_x'
    # Begin calculating 'q_x' for vertical triangle polygon drawing.
    x, y, canvas_w, canvas_h = Wip.get_rect()

    # first color
    pdb.gimp_selection_none(j)

    z = add_wip_layer("Colors", maya.group)

    if d[de.HORIZONTAL]:
        y1 = y + canvas_h
        w = canvas_w / (.5 + count * .5)
        w /= 2.
        x -= w
        q_x = make_coord_list(canvas_w, count + 5, x, span=w)
        for c in range(0, count + 2, 2):
            select_polygon(
                j,
                (q_x[c], y1, q_x[c + 1], y, q_x[c + 2], y1),
                option=CHANNEL_OP_ADD
            )

    else:
        # vertical
        x1 = x + canvas_w
        h = canvas_h / (.5 + count * .5)
        h /= 2.
        y -= h
        q_y = make_coord_list(canvas_h, count + 5, y, span=h)
        for r in range(0, count + 2, 2):
            select_polygon(
                j,
                (x1, q_y[r], x, q_y[r + 1], x1, q_y[r + 2]),
                option=CHANNEL_OP_ADD
            )

    is_mean_color = d[de.MEAN_COLOR]
    q = get_mean_color(maya.bg_z) if is_mean_color else d[de.COLOR_2A][0]

    color_selection(z, q)

    # second color
    invert_selection(j)

    q = get_mean_color(maya.bg_z) if is_mean_color else d[de.COLOR_2A][1]

    color_selection(z, q)
    return maya.finish(z, d[rk.BRW])


class BackGame(SubAccent):
    """Create Accent output."""
    kind = de.BACK_GAME

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, False, is_old)

    def do(self, *arg):
        d = self.any_group.get_value_d()
        self.is_dependent = d[de.MEAN_COLOR]
        return super(BackGame, self).do(*arg)
