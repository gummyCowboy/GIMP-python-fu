#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_comm import show_err
from roller_constant import Define as df
from roller_container import Run, The
from roller_gimp_item import validate_item
from roller_gimp_layer import remove_layer
from roller_gimp_layers import collect_group, collect_non_group
from roller_gimp_selection import select_channel
from roller_image_pic import Pic, image_undo_end, image_undo_start
from roller_oz import json_dump
from roller_ring import Ring
from roller_wip import Wip
from roller_port_main import PortMain
from roller_window import Window
import gobject       # type: ignore
import gtk           # type: ignore

CRITICAL = "Roller closed itself due to a critical error: "


def collapse_tree(j):
    """
    Move grouped layers to the Layers trunk.

    j: GIMP image
        Is render.
    """
    # a top-down ordered list of drawable in the Render, z_q.
    z_q = []

    collect_non_group(j, z_q)
    for z in reversed(z_q):
        if not z.visible:
            pdb.gimp_image_remove_layer(j, z)

        elif not z.opacity:
            pdb.gimp_image_remove_layer(j, z)
        else:
            if z.parent and len(z.parent.layers) == 1:
                # Fix a Pass-through layer problem
                # when there is only one layer in the group.
                # Reference
                # 'gimp-forum.net/Thread-Why-is-the-Pass-through'
                # '-layer-mode-changing-this-image'
                mode, name = z.mode, z.name
                z = pdb.gimp_image_merge_layer_group(j, z.parent)
                z.mode, z.name = mode, name
            pdb.gimp_image_reorder_item(j, z, None, 0)


def delete_created_image():
    for j in Pic.opened_q:
        if pdb.gimp_image_is_valid(j):
            pdb.gimp_image_delete(j)


def remove_group(j):
    """
    Remove group layers without any children.

    j: GIMP image
        Is render.
    """
    # list of group layers from the top-down, 'group_q'
    group_q = []

    collect_group(j, group_q)

    # Remove empty groups from the bottom-up.
    for z in reversed(group_q):
        remove_layer(z)


def restore_open_image_selection(sc_list):
    # Restore the selection for open images.
    for j, sc in sc_list:
        if sc is not None:
            if (
                pdb.gimp_item_is_valid(sc) and
                pdb.gimp_image_is_valid(j)
            ):
                select_channel(j, sc)
                pdb.gimp_image_remove_channel(j, sc)
        else:
            if pdb.gimp_image_is_valid(j):
                # Remove a Roller generated selection.
                pdb.gimp_selection_none(j)


def restore_open_image_active_layer(active_layer_list):
    # Restore the active layer for open images.
    for j, z in active_layer_list:
        if pdb.gimp_image_is_valid(j) and validate_item(z):
            j.active_layer = z


def save_dialog_pose():
    # Save Window position.
    if Window.pose_d != Window.last_pose_d:
        json_dump(Window.pose_d, Window.pose_file)


def save_open_image_state(active_layer_list, sc_list):
    for j in Pic.tab_q:
        if pdb.gimp_image_is_valid(j):
            active_layer_list.append((j, j.active_layer))
            sc_list.append((
                j,
                pdb.gimp_selection_save(j)
                if not pdb.gimp_selection_is_empty(j) else None
            ))
            pdb.gimp_selection_none(j)


class WindowMain(Window):
    """Is Roller's main window."""

    def __init__(self):
        """Has the GTK event loop."""
        # Preserve the selection and active layer of open images.
        sc_list = []
        active_layer_list = []

        image_undo_start()
        save_open_image_state(active_layer_list, sc_list)
        Window.__init__(self, {df.WINDOW_KEY: 'main'}, is_dialog=False)

        self.port = PortMain({df.ROLLER_WIN: self})

        self.set_hook(self.port.get_hook())
        self.add(self.port)
        self.gtk_win.show_all()

        try:
            # Insert a signal processing function
            # into the main signal processing ring.
            #
            # Reference
            # library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
            gobject.idle_add(Ring.send)

            # Start the main signal processing ring.
            gtk.main()

        except Exception as ex:
            if self.gtk_win is not None:
                self.close()
                show_err(CRITICAL + repr(ex))
            raise

        delete_created_image()
        restore_open_image_selection(sc_list)
        restore_open_image_active_layer(active_layer_list)
        self._finish_render(Run.j)
        self._delete_grad()
        save_dialog_pose()
        image_undo_end()

    def _delete_grad(self):
        if self.canceled and The.grad:
            pdb.gimp_gradient_delete(The.grad)
            The.grad = None

    def _finish_render(self, j):
        if j and not self.canceled:
            collapse_tree(j)
            remove_group(j)
            pdb.gimp_image_crop(
                j, *map(int, (Wip.get_size() + (Wip.x, Wip.y)))
            )

            # Set the bottom layer as the active layer.
            if len(j.layers):
                j.active_layer = j.layers[-1]

            # Remove channels.
            [j.remove_channel(i) for i in j.channels]
