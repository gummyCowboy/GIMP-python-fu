#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_constant import (
    Issue as vo, Row as rk, VoteType as vt, Signal as si, SubMaya as sm
)
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_layer import remove_layer
from roller_gimp_layers import remove_layers
from roller_image_render import Render
from roller_many_handle import Handle
from roller_maya_vote import bag_vote, on_global
from roller_model import get_main_q
from roller_ring import Ring


def _init_per(maya, k):
    """
    During a view run, set the main and per layer prefix string.

    Identify main option group and its sub-group layers as main with a
    padded period (e.g. ' .').

    Identify per option group and its sub-group layers with a padded string
    made from their cell and/or face indices (e.g. ' 1.1' and ' 1.1.1').

    maya: Maya
        Per variety

    k: tuple
        (row, column) or (row, column, face)
        key to Per value
    """
    maya.value_d = maya.get_value_d()
    n = ""
    pad_q = maya.model.per_padding

    for i, n1 in enumerate(k):
        n1 = str(n1 + 1)
        n1 = n1.rjust(pad_q[i], "0")
        n += n1
        if i < len(k) - 1:
            n += "."
    maya.layer_postfix = n


def _prep_main_step(maya):
    """
    maya: Maya
    """
    pdb.gimp_selection_none(Run.j)
    if not maya.main_q:
        # The main option group's cell/face item-list was empty,
        # so remove any existing layer.
        maya.die()


def _retire_sub_maya(sub_maya):
    """
    Remove Maya layer output including its sub-Maya layer output.

    sub_maya: dict
        of sub-Maya
        {sub-Maya identifier: sub-Maya instance} -> {string: Maya}
    """
    # maya, 'a'
    for a in sub_maya.values():
        a.set_issue()
        _retire_sub_maya(a.sub_maya)
        for i in a.order:
            if i:
                a.remove_put(i)


class Maya(Handle):
    """Factor Maya type."""

    def __init__(self, any_group, view_i, q, k_path):
        """
        any_group: AnyGroup
        view_i: int
            0 or 1; plan or work; view-type index

        q: tuple or None
            ((function, function-output-name), ...)

            Connect a function's return value to a boolean class attribute.
            Create the attribute from the function-output-name by
            prefixing the string with an 'is_' string
            (e.g 'matter' becomes the class variable 'self.is_matter')

            Further on, process the function with calls inside a 'self.realize'
            function in the same order as these function-string-pairs.

        k_path: tuple or list
            Is a series of sequenced keys reflecting the Maya's nested value
            dict location. AnyGroup inserts votes into a hierarchical vote
            dict that also reflects this main Preset structure. Maya counts
            votes by judging issue votes found at the k-path location in
            the AnyGroup vote dict.
            (Identity, ...)
            [(Identity, ...), ...]
        """
        Handle.__init__(self)

        self.value_d = None
        self.go = True
        self.great_vote_d = {}
        self.k_path = k_path

        # None, (row, column), or (row, column, face), 'self.k'
        # Identify a Maya item and mirror Model Goo-key, 'self.k'.
        self.k = None

        self.rect = None

        # Become part of group layer name output.
        # A period represents the main option output.
        # Per changes this to represent its item key:
        # (r, c) or (r, c, facial)
        self.layer_postfix = "."

        self.any_group = any_group
        self.view_i = view_i
        self.model = any_group.dna.model
        self.per_group = any_group.get_widget(de.PER)

        # Process during a view run. function list, 'self._make'.
        self._make = [i[0] for i in q]

        # Give name to function output layer
        # with an attribute list, 'self.order'.
        self.order = [i[1] for i in q]

        # Produce additional layer output with sub-Maya.
        # {SubMaya-id-string: Maya}
        self.sub_maya = {}

        # Are layer output reference (e.g. 'self.matter')
        for p, n in q:
            if n:
                setattr(self, n, None)

        self.set_issue()

        if k_path == vo.NO_VOTE:
            self.take_vote = lambda *_q, **_d: None

        else:
            self.take_vote = self.scan_vote if isinstance(k_path, list) \
                else self.grab_vote

        self.latch(Render.gob, (si.CLOSE_VIEW_IMAGE, self.on_close_view_image))
        self.latch(Ring.gob, (si.RESIZE, self.on_resize))
        self.latch(any_group, (si.DISAPPEAR, self.on_disappear_group))
        if k_path != vo.NO_VOTE:
            if hasattr(self, 'is_seeded'):
                self.latch(Ring.gob, (si.GLOBAL_SEED, self.on_global_seed))

            if hasattr(self, 'is_embossed'):
                self.latch(
                    Ring.gob, (si.GLOBAL_EMBOSS, self.on_global_emboss)
                )
            if self.vote_type == vo.MAIN:
                self.latch(
                    any_group.booth, (si.VOTE_CHANGE, self.on_vote_change)
                )
                self.latch(any_group, (si.SEQUENCE, self.on_sequence))

    def die(self):
        """Remove its layer output."""
        for i in self.order:
            if i:
                z = getattr(self, i)
                if z:
                    remove_layer(z)
                    setattr(self, i, None)
                    Run.is_back = True

        _retire_sub_maya({None: self})
        self.set_issue()

    def get_light(self):
        """
        Determine if a Light matter layer is present.
        If so, then return its group layer offset of one.
        Otherwise, return zero for no offset.

        The Light matter layer is always on top
        in the group layer's of order of layer-children.

        Return: int
            0 or 1
        """
        a = self.sub_maya.get(sm.BULB)

        if a:
            return int(bool(a.matter))

        # A plan-view-type run doesn't have Light matter output.
        return 0

    def get_matter(self):
        """
        Retrieve the matter layer.

        Return: layer or None
        """
        return self.matter

    def grab_vote(self, d):
        """
        Vote on issue given a vote dict.

        d: dict
            Has relational vote.
        """
        bag_vote(self, d, self.k_path)

    def on_close_view_image(self, _, arg):
        """
        Reset the Plan group layer reference as it was deleted
        when its image closed.

        _: ViewImage
            Sent the Signal.

        arg: not used
        """
        for i in self.order:
            if i:
                setattr(self, i, None)
        self.reset()

    def on_disappear(self, _, q):
        """
        The Maya is no longer used, so disconnect its subscription.

        q: tuple
            set of (row, column) or (row, column, face)
            Identify Maya with the view and cell index.
        """
        def _unplug(_maya):
            _maya.die()
            _maya.unlatch()

        def _poof(_maya):
            """
            Remove the Maya's ability to take sub-vote
            by removing nested sub-maya recursively.
            """
            for _maya in _maya.sub_maya.values():
                _unplug(_maya)
                _poof(_maya)
            _maya.sub_maya = {}

        for k in q:
            if k in self.per_d:
                maya = self.per_d[k]

                _unplug(maya)
                self.per_d.pop(k)
                _poof(maya)
        pdb.gimp_displays_flush()

    def on_disappear_group(self, *_):
        """
        The Maya is no longer used, so disconnect its subscription.

        _: AnyGroup, arg
            (Sent the Signal., None)
        """
        self.die()
        self.unlatch()

        # Remove the Maya's ability to take sub-vote.
        self.per_d = self.sub_maya = {}

        pdb.gimp_displays_flush()

    def on_global_emboss(self, _, arg):
        """
        Respond to a Global emboss option change.

        _: Ring
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
        """
        on_global(self, arg, vt.IS_EMBOSS)

    def on_global_seed(self, _, arg):
        """
        Respond to a Global Random Seed option change.

        _: Ring
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
        """
        on_global(self, arg, vt.IS_SEED)

    def on_resize(self, *_):
        """
        Cast a view-image-size change vote for both view-types.

        *_: tuple
            (Ring sent the signal., [Plan vote, Work vote])
        """
        on_global(self, [True, True], vt.IS_NEW)

    def on_sequence(self, *_):
        """
        Respond to change taking place in a Model sequence calculation.
        The 'matter' vote has already been added to the AnyGroup's vote
        dict, but now it needs to be scanned for True vote.

        _: tuple
            (AnyGroup, list)
            (Sent the Signal., [Plan vote, Work vote])
        """
        # Plan and Work, '2'
        for i in range(2):
            self.take_vote(self.any_group.vote_q[i])

    def on_vote_change(self, _, i):
        """
        Respond to a VOTE_CHANGE Signal from its AnyGroup.
        Convert vote-dict-change to Maya-issue.

        i: int
            plan or work; view-type index; 0 or 1
        """
        if i == self.view_i:
            self.take_vote(self.any_group.vote_q[i])

    def realize(self):
        """Create and delete layer output."""
        if not self.go:
            self.die()
        else:
            for i, n in enumerate(self.order):
                a = self._make[i](self)
                if n:
                    setattr(self, n, a)

    def realize_vote(self):
        """Call to manage layer output and then reset the vote."""
        self.realize()
        self.reset_issue()

    def reset(self):
        """Call when the view image closes."""
        for i in self.issue_q:
            self.any_group.cast_vote(self.view_i, vt.IS_NEW, i, True)

    def reset_issue(self):
        """Indicate no change in output status."""
        self.great_vote_d = {}
        for i in self.issue_q:
            setattr(self, 'is_' + i, False)

    def remove_put(self, n):
        """
        Remove a layer given its attribute
        descriptor. Set its reference to None.

        maya: Maya
            Has the attribute that references a layer(s).

        n: string
            layer attribute descriptor
        """
        remove_layers(getattr(self, n))
        setattr(self, n, None)

    def scan_vote(self, d):
        """
        Vote on issue given a vote dict with multiple vote sources.

        d: dict
            Has relational and nested vote.
        """
        for k_q in self.k_path:
            bag_vote(self, d, k_q)

    def set_issue(self):
        """Set issue for self and sub-Maya to True."""
        for i in self.issue_q:
            setattr(self, 'is_' + i, True)
        for a in self.sub_maya.values():
            a.set_issue()


class Runner(Maya):
    """
    Call 'prep' and 'dig' functions with a 'do' function during a view run.
    """

    def __init__(self, *q):
        """
        q: tuple
            Maya spec
        """
        Maya.__init__(self, *q)

    def do(self):
        """
        Is an entry point for AnyGroup during a view run.

        The 'dig' function is a kick-off point
        found in different Maya solutions.
        """
        self.value_d = self.get_value_d()

        self.prep()
        self.dig()

    def prep(self):
        return


class Mage(Runner):
    """Compare image reference for change."""

    def __init__(self, any_group, view_i, q, k_path):
        Runner.__init__(self, any_group, view_i, q, k_path)

    def prep(self):
        """On image change, set matter change issue."""
        self.any_group.check_image_change(self)


class Main:
    """Identify the Maya as main."""
    vote_type = vo.MAIN

    def __init__(self):
        return

    def get_mask_d(self):
        return self.get_value_d()[rk.RW1][de.MASK]

    def get_value_d(self):
        return self.any_group.get_value_d()


class Per:
    """Factor Plan and Work Per. Init after initializing Maya."""
    vote_type = vo.PER

    def __init__(self, do_matter, k):
        """
        do_matter: function
            Produce layer output.

        k: tuple
            (row, column)
            cell index; Goo key
        """
        self.do_matter = do_matter
        self.k = k
        self.latch(self.per_group, (si.PER_CHANGE, self.on_per_change))

    def get_mask_d(self):
        d = self.get_value_d()
        if d:
            return d[rk.RW1][de.MASK]

    def get_value_d(self):
        d = self.any_group.get_value_d()
        d = d.get(de.PER, {})
        return d.get(self.k)

    def on_per_change(self, _, arg):
        """
        Respond to change from its PerGroup.
        Create Per Cell Maya to mirror PerGroup cell addition.

        _: PerGroup
            Sent the Signal.

        arg: tuple
            ((row, column), vote dict, view index)
            The row and column work together as a cell index.
            The vote dict has vote for cell referenced by the cell index.
        """
        def _trickle(_d):
            """
            Recursively trickle down the vote through the sub-maya pyramid.

            _d: dict
                sub-Maya
                {sub-Maya key: Maya}
            """
            for _b in _d.values():
                _b.take_vote(d)
                _trickle(_b.sub_maya)

        k, d, i = arg

        if i == self.view_i and k == self.k:
            self.take_vote(d)
            _trickle(self.sub_maya)
        Ring.add(self.any_group, si.GROUP_CHANGE, None)


class PerRoute:
    """Factor CellRoute and FaceRoute"""

    def __init__(self, per_type):
        """
        per_type: Class
            Per Maya
        """
        self.per_type = per_type

        # Has Maya for each Per.
        # key, value -> {(r, c) or (r, c, face): Per Maya}
        self.per_d = {}

        self.latch(self.per_group, (si.DISAPPEAR, self.on_disappear))
        self.latch(self.per_group, (si.PER_CHANGE, self.on_per_d_change))

    def rig(self, q):
        """
        Process main and Per output for a step during a view run.

        q: list
            Is a list of Per key for the Model.
        """
        d = self.per_d

        _prep_main_step(self)

        # main output
        self.bore()

        # Per output
        # Check 'per' vote, 'is_per'.
        if self.is_per or Run.is_back:
            for k in q:
                if k in d:
                    maya = d[k]

                    _init_per(maya, k)
                    maya.bore()
                    maya.reset_issue()
        self.reset_issue()

    def on_per_d_change(self, _, arg):
        """
        Respond to change from the AnyGroup's PerGroup.
        Create Per Cell Maya to mirror PerGroup cell addition.

        _: PerGroup
            Sent the Signal.

        arg: tuple
            ((row, column) or (row, column, face), vote dict, view index)
            The row and column work together as a cell index and Goo key.
            The vote dict has vote for cell referenced by the cell index.
        """
        k, vote_d, i = arg
        if i == self.view_i:
            if k not in self.per_d:
                self.per_d[k] = self.per_type(self.any_group, k)


class CellRoute(PerRoute):
    """Has a list of Cell branch key."""

    def __init__(self, per_type):
        self.main_q = []
        PerRoute.__init__(self, per_type)

    def dig(self):
        self.main_q = get_main_q(self.value_d, self.model.cell_q)
        self.rig(self.model.cell_q)


class FaceRoute(PerRoute):
    """Has a list of Face branch key."""

    def __init__(self, per_type):
        self.main_q = []
        PerRoute.__init__(self, per_type)

    def dig(self):
        self.main_q = get_main_q(self.value_d, self.model.face_q)
        self.rig(self.model.face_q)


class Cell(CellRoute):
    """Use with deco step that secede Cell Margin."""

    def __init__(self, per_type):
        CellRoute.__init__(self, per_type)


class Canvas:
    """Has Canvas branch function."""
    is_face = is_facial = False
    vote_type = vo.MAIN
    appendage = "."

    def __init__(self):
        self.k = None

    def dig(self):
        """Produce layer output."""
        self.bore()
        self.reset_issue()


class Change(Mage):
    """
    Use with Border, Fringe and Plaque. Respond to
    Global's Random Seed option-change and
    layer-background-change.
    """
    is_seeded = True

    def __init__(self, any_group, view_i, q, k_path):
        Mage.__init__(self, any_group, view_i, q, k_path)

    def on_global_seed(self, _, arg):
        """
        The Global Random Seed option has changed.
        Check to see if the layer output is seed dependent.

        _: Ring
            Sent the signal.

        arg: tuple
            (Plan vote, Work vote)
        """
        d = self.get_value_d()

        if d:
            if d[de.TYPE] not in (
                de.IMAGE, de.PLASMA, de.CLOUDS, de.RANDOM_COLOR
            ):
                # no change
                arg = [False, False]
        super(Change, self).on_global_seed(_, arg)

    def on_back_change(self, _, i):
        """
        The layer background changed for the group.

        _: AnyGroup
            Sent the Signal.

        i: int
            plan or work view-type index
        """
        if i == self.view_i:
            d = self.get_value_d()
            if d[de.TYPE] == de.MEAN_COLOR:
                arg = [None, None]
                arg[i] = True
                on_global(self, arg, vt.IS_BACK)
