#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from roller_container import Run
from roller_constant_identity import Identity as de
from roller_gimp_layer import do_curves, do_saturate, flip_layer
from roller_preset_blur import do_blur


def do_mod(z, d):
    """
    Modify a layer using Mod Preset settings, while expecting
    a selection to be active for the blur function.

    z: layer
        Modify.

    d: dict
        Mod Preset

    Return: layer
        Modified.
    """
    def _do_contrast(_f):
        """
        Alter a layer's contrast with curves.

        _f: float
            -100. to 100.
            black to white
        """
        if _f:
            # brightness, '0'
            pdb.gimp_brightness_contrast(z, 0, int(_f))

    def _set_brightness(_f):
        """
        Alter a layer's lightness with curves.

        _f: float
            -100. to 100.
            black to white
        """
        if _f:
            if _f < .0:
                _black = .0
                _white = 1. + (_f / 100.)

            else:
                _black = _f / 100.
                _white = 1.
            do_curves(z, (.0, _black, 1., _white))

    if d[de.SWITCH]:
        # plan or work view-index, 'm'
        m = Run.i

        j = z.image

        pdb.gimp_selection_none(j)

        if m:
            if d[de.INVERT]:
                # no linear, '0'
                pdb.gimp_drawable_invert(z, 0)

        if d[de.FLIP_H]:
            flip_layer(z, is_h=True)

        if d[de.FLIP_V]:
            # vertical flip
            flip_layer(z)
        if m:
            do_saturate(z, d)
            _set_brightness(d[de.BRIGHTNESS])
            _do_contrast(d[de.CONTRAST])
            do_blur(z, d[de.BLUR_D])
    return z
