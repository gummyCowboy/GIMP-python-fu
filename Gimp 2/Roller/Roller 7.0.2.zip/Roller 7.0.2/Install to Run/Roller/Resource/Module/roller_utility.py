#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from datetime import datetime
from math import ceil
from random import randint, seed
from roller_constant import Color as co
from roller_many_rect import Rect
from roller_polygon import calc_circumradius
from roller_wip import Wip
import colorsys
import math


def calc_rotated_image_span(w, h):
    """
    Calculate the size of an image span where each side has equal length.

    w, h: numeric
        rectangle size

    Return: int
        size of image side
    """
    return int(ceil(calc_circumradius(w, h)) * 2.)


def convert_to_rgb(color):
    """
    Convert gtk.gdk.Color to RGB.

    color: gtk.gdk.Color
        Convert.

    Return: RGB
        color
    """
    if isinstance(color.red, int):
        return tuple(
            [i // 257 for i in (color.red, color.green, color.blue)]
        )


def enumerate_name(n, q):
    """
    Enumerate a name given a list of names.
    Ensure the name is unique to the list.

    n: string
        name to check

    q: list
        list of name

    Return: string
        the enumerated name
    """
    while n[-1].isdigit():
        n = n[:-1]

    n = n.strip()
    a = 1

    while 1:
        n1 = n + " " + str(a)

        if n1 in q:
            a += 1
        else:
            break
    return n1


def get_nested(d, key_list):
    """
    Create an empty item if needed.

    d: dict
        Has a nested item.

    key_list: list
        [key, ...]
        Return the item at the end of the list.

    Return: tuple
        (dict with last item, last key, last key-item value)
    """
    if d is None:
        d = {}

    e = d
    a = len(key_list) - 1

    for i, k in enumerate(key_list):
        if k not in d:
            d[k] = {} if i < a else None

        e = d
        d = d[k]
    return e, k, d


def get_point_on_edge(angle):
    """
    Calculate an x, y coordinate for a point intersecting
    a ray, originating from the center of a rectangle,
    and ending at a rectangle boundary.

    angle: float
        radians
        angle from center of the rectangle

    Return: point
        x, y of float
        the point on the rectangle
    """
    x, y, w, h = Wip.get_rect()
    sine = math.sin(angle)
    cosine = math.cos(angle)
    h1 = h / 2.
    w1 = w / 2.

    # distance to the top or the bottom edge (from the center), 'h2'
    h2 = h1 if sine > .0 else -h1

    # distance to the left or the right edge (from the center), 'w2'
    w2 = w1 if cosine > .0 else -w1

    # (distance to the vertical line) < (distance to the horizontal line)
    if abs(w2 * sine) < abs(h2 * cosine):
        # Calculate distance to the vertical line:
        h2 = (w2 * sine) / cosine

    # (distance to the top or the bottom edge)
    # < (distance to the left or the right edge)
    else:
        w2 = (h2 * cosine) / sine
    return round(w2 + w1 + x), round(h2 + h1 + y)


def hsv_to_rgb(q):
    """
    Convert HSV to RGB.

    q: iterable
        HSV
        in .0 to 1.

    Return: tuple
        RGB
        0. to 255.
    """
    return tuple([int(round(i1 * 255)) for i1 in colorsys.hsv_to_rgb(*q)])


def invert_color(q):
    """
    Calculate an inverted color.

    q: tuple
        RGB or RGBA

    Return: tuple
        RGB or RGBA
        the inverted color
    """
    if len(q) == 3:
        # RGB
        return tuple([255 - i for i in q])

    # RGBA
    return tuple([255 - i for i in q[:3]]) + (q[3],)


def make_2d_table(r, c, init=0):
    """
    Return a 2D list.

    r, c: int
        size of the 2D table

    init: value
        Initialize value.

    deep: bool
        When it is True, the init value is deep-copied.
    """
    table = init

    for a in (c, r):
        table = [deepcopy(table) for _ in range(a)]
    return table


def make_rect_table(rect, row, column):
    """
    Create a cell table. Calculate the rectangle of each cell.
    Use a Rect object to store the position and size of a cell.

    rect: tuple
        (x, y, w, h) of float
        space for the grid

    row, column: int
        row and column scale of the cell table

    Return: 2D list
        Is a table where a list rows have list
        of cells corresponding the column count.
        to access a cell use row then column index:
            table[row index][column index]
    """
    x, y, w, h = rect
    w = w / column
    h = h / row
    q_y = []
    q_x = []
    q = make_2d_table(row, column)

    for r in range(row + 1):
        q_y.append(round(y))
        y += h

    for c in range(column + 1):
        q_x.append(round(x))
        x += w
    for r in range(row):
        for c in range(column):
            y, y1 = q_y[r], q_y[r + 1]
            x, x1 = q_x[c], q_x[c + 1]
            q[r][c] = Rect(x, y, x1 - x, y1 - y)
    return q


def make_split_key(prefix, postfix):
    """
    Combine two strings to form a sub-type key,
    for example: "Property, Table".

    prefix: string
        Precede comma.

    postfix: string
        Follow comma.

    Return: string
        now with comma
    """
    return "{}, {}".format(prefix, postfix)


def random_rgb(*_):
    """Return a tuple of integer containing random colors (r, g, b)."""
    return randint(0, 255), randint(0, 255), randint(0, 255)


def random_rgba():
    """
    Return a tuple of integer containing
    random color components (r, g, b, a).
    """
    return random_rgb() + (randint(0, 255),)


def reduce_color(color):
    """
    'color' is used by the red and green color
    components. Use when drawing a gtk.EventBox.

    color: tuple
        RGB
    """
    return color - co.COLOR_DEC


def rgb_to_hsv(q):
    """
    Convert RGB to HSV.

    q: iterable
        of int
        RGB

    Return: tuple
        HSV
            float in .0 to 1.
            float in .0 to 1.
            float in 0. to 255.
    """
    return colorsys.rgb_to_hsv(*[(i / 255.) for i in q])


def seal(a, b, c):
    """
    Limit a numeric value to a range.

    a: value
        Limit this value.

    b: value
        minimum amount

    c: value
        maximum amount

    Return: value
        within range
    """
    return max(min(c, a), b)


def seed_random():
    """Randomize Python random number generator."""
    seed(float(datetime.now().microsecond))
