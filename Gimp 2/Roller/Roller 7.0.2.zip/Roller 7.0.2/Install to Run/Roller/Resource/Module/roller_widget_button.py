#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Path
from roller_constant import Define as df, Image as fi, Signal as si
from roller_constant_identity import Identity as de
from roller_comm import pop_up
from roller_utility import seed_random
from roller_ring import Ring
from roller_tooltip_text import Tip
from roller_widget_entry import Entry
from roller_widget_box import Box as boxer
from roller_widget import Widget
import gobject  # type: ignore
import gtk      # type: ignore
import os


FILE_ONLY = \
    "The selected item is a folder, " \
    "and the entry is for an image file only."
FOLDER_ONLY = \
    "The selected item is not a folder, " \
    "and the entry is for folders only. "


def on_accept_action(g):
    """
    Respond to an AcceptButton action. Let
    the Window know that it is accepted.

    g: Button
        Is responsible.
    """
    g.roller_win.emit(si.ACCEPT_WINDOW, g)


def on_cancel_action(g):
    """
    Respond to a CancelButton click. Let
    the Window know that it is canceled.

    g: Button
        Is responsible.
    """
    g.roller_win.emit(si.CANCEL_WINDOW, g)


class Button(Widget, gobject.GObject):
    """Is a custom GTK Button."""
    __gsignals__ = si.BUTTON_DICT
    change_signal = 'clicked'
    has_table_label = False

    def __init__(self, **d):
        """
        Create a gtk.Button that is attached to an gtk.Alignment.

        d: dict
            Initialize Widget.
        """
        self._sensitive = 1
        self.tooltip_text = d.get(df.TOOLTIP, "")

        # There is no basestring in Python 3.
        if isinstance(d[df.TEXT], basestring):          # noqa
            g = self.button = gtk.Button(d[df.TEXT])

        else:
            # arrow
            g = gtk.Button()
            g.add(d[df.TEXT])

        # Not every Button declares a group.
        self.any_group = None

        # A Button is invalid if it is in a Window buried by a GTK Dialog.
        self.is_valid = True

        Widget.__init__(self, g, **d)

        # for custom signal(s)
        gobject.GObject.__init__(self)

        self.add(g)
        self.roller_win.connect(si.DIALOG_OPEN, self.on_view_dialog_open)
        self.roller_win.connect(si.DIALOG_CLOSE, self.on_view_dialog_close)

    def on_bring_dialog_button(self, *_):
        """Open a Preset dialog."""
        self.roller_win.bring_dialog(self)

    def on_view_dialog_close(self, *_):
        """
        A GTK Dialog Window closed, so the button is valid.

        _: Button
            Is responsible.
        """
        self.is_valid = True

        self.set_sensitive(self._sensitive)
        self.set_tooltip_text(self.tooltip_text)
        self.emit(si.VALIDATE, None)

    def on_view_dialog_open(self, *_):
        """
        A GTK Dialog Window opened, so the Button is invalid.

        _: Button
            Is responsible.
        """
        self._sensitive = self.get_sensitive()
        self.is_valid = False
        self.set_sensitive(0)
        self.set_tooltip_text("")


class ProcessButton(Button):
    """Doesn't send change vote to its AnyGroup."""

    def __init__(self, **d):
        """
        d: dict
            Initialize Widget.
        """
        d[df.NO_VOTE] = True
        Button.__init__(self, **d)


class Accept(ProcessButton):
    """Accept a Window."""

    def __init__(self, a, **d):
        """
        d: dict
            Initialize the Widget.
        """
        d[df.TEXT] = a

        d[df.RELAY].insert(0, on_accept_action)
        ProcessButton.__init__(self, **d)


class AcceptButton(Accept):
    """Accept a Window. Listen for ACCEPT_FOCUS Signal."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument. Has Accept spec.
        """
        Accept.__init__(self, de.ACCEPT, **d)
        self.roller_win.connect(si.ACCEPT_FOCUS, self.accept_focus)

    def accept_focus(self, *_):
        """
        Take the interface focus.

        Return: True
            Let GTK know that the signal is handled.
        """
        self.widget.grab_focus()
        return True


class AcceptAllButton(Accept):
    """Accept a Window."""

    def __init__(self, **d):
        """
        d: dict
            Initialize Widget.
        """
        Accept.__init__(self, de.ACCEPT_ALL, **d)


class AcceptNoneButton(Accept):
    """Accept a Window."""

    def __init__(self, **d):
        """
        d: dict
            Initialize Widget.
        """
        Accept.__init__(self, de.ACCEPT_NONE, **d)


class CancelButton(ProcessButton):
    """Cancel a Window."""

    def __init__(self, **d):
        """
        d: dict
            Initialize Widget.
        """
        d[df.TEXT] = de.CANCEL

        d[df.RELAY].insert(0, on_cancel_action)
        ProcessButton.__init__(self, **d)


class NavButton(ProcessButton):
    """Override the Button's 'on_view_dialog_close' function."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        self.on_dialog_close = d[df.ON_DIALOG_CLOSE]
        ProcessButton.__init__(self, **d)

    def on_view_dialog_close(self, *_):
        """
        A GTK Dialog Window closed, so the button is valid.

        _: Button
            Is responsible.
        """
        self.on_dialog_close()
        self.set_tooltip_text(self.tooltip_text)


class RowListButton(Button):
    """Override the 'Button.on_view_dialog_close'."""

    def __init__(self, **d):
        self._row_list = d.get(df.ROW_LIST)
        Button.__init__(self, **d)

    def on_view_dialog_close(self, *_):
        super(RowListButton, self).on_view_dialog_close()
        if self._row_list and self._row_list.get_selected_r() is None:
            self.set_sensitive(0)


class ViewButton(ProcessButton):
    """Perform a view run."""

    def __init__(self, **d):
        """
        d: dict
            Initialize Widget.
        """
        d[df.KEY] = d[df.TEXT]

        d[df.RELAY].insert(0, self.on_view_action)
        ProcessButton.__init__(self, **d)
        Ring.gob.connect(si.UI_CHANGE, self.update_sensitivity)

    def on_view(self, window, widget):
        """
        Call each function in the relay on Widget change.

        window: Window
            Window has Widget

        widget: Widget
            Widget could be this Widget or another Widget with focus.

        Return: True
            Tell GTK that the signal is handled.
        """
        self.on_widget_change(*(window, widget))
        widget.grab_focus()

    def on_view_action(self, g):
        """
        Disable the Button after a view run.

        g: ViewButton
        """
        self.set_sensitive(0)
        self.set_tooltip_text("")
        g.roller_win.port.report(g, self.VIEW_TYPE)
        self.roller_win.emit(si.ACCEPT_FOCUS, self)

    def update_sensitivity(self, _, spark):
        """
        When the user interface changes, a View Button becomes sensitive.

        _: SignalFilter
            Sent the signal.

        spark: object
            Is responsible for initiating the signal.
        """
        if (
            self.is_valid and
            spark != self and
            spark.roller_win == self.roller_win
        ):
            if not self.get_sensitive():
                self.set_sensitive(1)
                self.set_tooltip_text(self.tooltip_text)


class DialogButton(ProcessButton):
    """Open a dialog on action."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        self.dialog = d[df.DIALOG]
        d[df.TEXT] += "…"

        d[df.RELAY].insert(0, self.on_bring_dialog_button)
        ProcessButton.__init__(self, **d)


class DraftButton(ViewButton):
    """Run a View Draft."""
    VIEW_TYPE = 2

    def __init__(self, **d):
        """
        d: dict
            Initialize Widget.
        """
        d[df.TEXT] = de.DRAFT
        d[df.TOOLTIP] = Tip.DRAFT_BUTTON
        ViewButton.__init__(self, **d)


class MakeMaterialButton(DialogButton):
    """Open a Make Heat Material dialog."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        self.get_list = d[df.GET_A]
        d[df.TEXT] = de.MATERIALIZE
        d[df.TOOLTIP] = Tip.MATERIALIZE
        DialogButton.__init__(self, **d)

    def load_a(self, n):
        """
        Send a Signal with an Accept value
        received from the ChoiceList.

        value: string
            Material key
        """
        self.emit(si.MATERIALIZE, n)


class ManagePresetButton(DialogButton):
    """Use to open a Preset file manager dialog."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        d[df.TEXT] = de.MANAGE
        DialogButton.__init__(self, **d)


class PeekButton(ViewButton):
    """Perform a Peek run on action."""
    VIEW_TYPE = 3

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        d[df.TEXT] = de.PEEK
        d[df.TOOLTIP] = Tip.PEEK_BUTTON
        ViewButton.__init__(self, **d)
        self.roller_win.connect(si.PEEK, self.on_view)


class PlanButton(ViewButton):
    """Run a Plan view."""
    VIEW_TYPE = 0

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[df.TEXT] = de.PLAN
        d[df.TOOLTIP] = Tip.PLAN_BUTTON
        ViewButton.__init__(self, **d)


class PreviewButton(ViewButton):
    """Run a Preview."""
    VIEW_TYPE = 1

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        d[df.TEXT] = de.PREVIEW
        d[df.TOOLTIP] = Tip.PREVIEW_BUTTON
        ViewButton.__init__(self, **d)
        self.roller_win.connect(si.PREVIEW, self.on_view)


class RandomButton(ProcessButton):
    """Randomize AnyGroup option value."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        d[df.TEXT] = de.RANDOM

        d[df.RELAY].insert(0, self.do_random)
        ProcessButton.__init__(self, **d)

    def do_random(self, _):
        """
        Have AnyGroup relative option randomize their value.

        _: self
        """
        seed_random()
        self.any_group.emit(si.RANDOMIZE, self)


class RemoveButton(DialogButton):
    """Open a Remove Heat material dialog."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        self.get_list = d[df.GET_A]
        d[df.TEXT] = de.REMOVE
        DialogButton.__init__(self, **d)

    def load_a(self, value):
        """
        Send a Signal with an Accept value
        received from the caller.

        value: list
            [Material key, ...]
        """
        self.emit(si.REMOVE_MATERIAL, value)


class RenameButton(DialogButton):
    """Rename a Model."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        d[df.TEXT] = de.RENAME
        DialogButton.__init__(self, **d)


class ReviseButton(DialogButton):
    """Add and remove Model step from the Model."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        d[df.TEXT] = de.REVISE
        DialogButton.__init__(self, **d)


class SaveButton(DialogButton):
    """Save a Preset file."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        d[df.TEXT] = de.SAVE
        DialogButton.__init__(self, **d)


class MoveDownButton(ProcessButton):
    """Display an Arrow on the Button."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        d[df.TEXT] = gtk.Arrow(gtk.ARROW_DOWN, gtk.SHADOW_NONE)
        ProcessButton.__init__(self, **d)


class MoveUpButton(ProcessButton):
    """Display an Arrow on the Button."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Button.
        """
        d[df.TEXT] = gtk.Arrow(gtk.ARROW_UP, gtk.SHADOW_NONE)
        ProcessButton.__init__(self, **d)


class OSButton(Widget):
    """Factor FileButton and FolderButton."""
    change_signal = None
    has_table_label = False

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        key = d[df.KEY]
        d[df.NO_VOTE] = True
        box = self.box = boxer()
        d[df.CHARS] = 45
        relay = d[df.RELAY]
        d[df.RELAY] = [self.on_os_entry_change]
        d[df.KEY] = key + "_entry"
        g = self.os_entry = Entry(**d)
        d[df.RELAY] = relay
        d[df.KEY] = key
        self.os_button = Button(**d)

        Widget.__init__(self, g.widget, **d)
        box.add(g)
        box.add(self.os_button)
        self.add(box)

    def get_ui(self):
        """
        Get the value of the Entry.

        Return: string
            Is a file or folder reference.
        """
        return self.os_entry.get_ui()

    def load_a(self, a):
        """
        It's not a voter, so this function gets called instead.

        a: string
            Define path.
        """
        a = self.set_ui(a)
        self.any_group.set_sub_widget_a(self.row_key, self.key, a)

    def set_ui(self, n):
        """
        Set the value of the Entry.

        n: string
            Is a file or folder reference.

        Return: string
            Is a file or folder reference.
        """
        if not isinstance(n, basestring):       # noqa
            n = ""

        self.os_entry.set_ui(n)
        return n

    def on_os_entry_change(self, *_):
        """Let listener (e.g. Preview Button) know that there was change."""
        Ring.plug(si.UI_CHANGE, self.os_entry)


class FileButton(OSButton):
    """
    Open a dialog for choosing an image file. Has an
    Entry partner to store a dialog choice.
    """

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.

        """
        d[df.TEXT] = "Select a File…"
        d[df.RELAY] = [self.get_file_entry_item]
        OSButton.__init__(self, **d)

    def get_file_entry_item(self, *_):
        """Open a file chooser dialog."""
        dialog = gtk.FileChooserDialog(
            title="Choose an Image File",
            parent=self.roller_win.gtk_win,
            action=gtk.FILE_CHOOSER_ACTION_OPEN,
            buttons=(
                de.CANCEL,
                gtk.RESPONSE_CANCEL,
                de.ACCEPT,
                gtk.RESPONSE_ACCEPT
            )
        )
        file_filter = gtk.FileFilter()
        n = self.os_entry.get_ui()

        if not n:
            n = Path.image

        # Reference
        # en.wikipedia.org/wiki/File_URI_scheme
        n = "file://localhost/" + os.path.dirname(n)

        dialog.set_current_folder_uri(n)
        file_filter.set_name("Images")

        for i in fi.EXTENSION_LIST:
            file_filter.add_pattern("*" + i)

        dialog.add_filter(file_filter)

        response = dialog.run()

        # Okay response enum, '-3'
        n = dialog.get_filename() if response == -3 else ""

        dialog.destroy()

        if n:
            Path.image = n

            if not os.path.isfile(n):
                pop_up(
                    self.roller_win.gtk_win,        # Use dialog.
                    1,
                    FILE_ONLY.format(n),
                    "Wrong Item Type"
                )
                n = ""
            if n:
                self.load_a(n)
        return True


class FolderButton(OSButton):
    """
    Open a dialog for choosing a folder. Has an
    Entry partner to store a dialog choice.
    """

    def __init__(self, **d):
        """
        Draw an Entry and a Button.

        d: dict
            Initialize the Widget.
        """
        d[df.TEXT] = "Select a Folder…"

        d[df.RELAY].insert(0, self._get_folder_entry_item)
        OSButton.__init__(self, **d)

    def _get_folder_entry_item(self, *_):
        """Open a folder chooser dialog."""
        action = gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER
        dialog = gtk.FileChooserDialog(
            title="Choose an Image Folder",
            parent=self.roller_win.gtk_win,
            action=action,
            buttons=(
                "Cancel",
                gtk.RESPONSE_CANCEL,
                "Accept",
                gtk.RESPONSE_ACCEPT
            )
        )
        n = self.os_entry.get_ui()

        if not n:
            n = Path.image

        if os.path.isdir(n):
            # Reference
            # en.wikipedia.org/wiki/File_URI_scheme
            n = "file://localhost/" + n

            # Set the initial folder.
            dialog.set_current_folder_uri(n)

        response = dialog.run()

        # Okay response enum, '-3'
        n = dialog.get_filename() if response == -3 else ""

        dialog.destroy()
        if n:
            Path.image = n
            if not os.path.isdir(n):
                pop_up(
                    self.roller_win.gtk_win,        # use dialog
                    1,
                    FOLDER_ONLY.format(n),
                    "Wrong Item Type"
                )
                n = ""
            if n:
                self.load_a(n)


# Register the custom signals.
gobject.type_register(Button)
