#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Run
from roller_constant_identity import Identity as de
from roller_gimp_image import check_matter
from roller_gimp_layer import set_layer_mode
from roller_gimp_mode import get_mode
from roller_maya_build import SubBuild
from roller_preset_shadow import make_shadow_inner


def check_mix_shadows(maya):
    """
    Update the current view's background-changed
    flag on Shadow layer mode change.

    maya: Maya
    """
    z = maya.matter
    if z:
        if maya.is_mode:
            Run.is_back |= set_layer_mode(z, get_mode(maya.value_d))


def do_matter(maya):
    """
    Create an Inset shadow layer if the maya's super-maya is live.

    maya: Inset
    Return: layer
        Inset material
    """
    z = maya.super_maya.group
    if z:
        return make_shadow_inner(
            maya.value_d,
            z,
            maya.super_maya.matter,
            name="{} {}".format(z.name, "Inset")
        )


class Inset(SubBuild):
    """Manage Inset Shadow layer output."""
    issue_q = 'matter', 'mode'
    put = (check_matter, 'matter'), (check_mix_shadows, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Is the origin of this option.

        super_maya: Maya
            Is the super Shadow.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, do_matter)

    def do(self, d, is_change):
        """
        Manage layer output during a view run.

        d: dict
            Shadow Preset

        is_change: bool
            Is True if the shadow caster has change.

        Return: bool
            Is True if Inset changed the render.
        """
        self.go = d[de.SWITCH]
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change

        self.realize_vote()
        return m
