#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_deco_output import init_deco_type
from roller_gimp_selection import select_rect
from roller_maya_sub_accent import SubAccent
from roller_wip import Wip


def do_matter(maya):
    """
    Create a matter layer.

    maya: Work
    Return: layer
        'matter'
    """
    j = Run.j
    d = maya.value_d
    arg, p = init_deco_type(
        de.GRADIENT, j, maya, maya.group, d, maya.get_light(), False
    )
    maya.rect = Wip.get_rect()

    select_rect(j, *maya.rect)

    z = p(*arg)
    return maya.finish(z, d[rk.BRW])


class GradientFill(SubAccent):
    """Create Accent output."""
    kind = de.GRADIENT_FILL

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, False, is_old)
