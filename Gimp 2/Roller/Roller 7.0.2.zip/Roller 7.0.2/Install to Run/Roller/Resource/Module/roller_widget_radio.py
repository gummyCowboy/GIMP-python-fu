#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant import Define as df, Signal as si
from roller_utility import seal
from roller_widget import Widget
import gtk  # type: ignore


def check_radio(i, max_a):
    """
    i: value
        index to RadioButton

    max_a: int
        maximum allowed value

    Return: int
        Passed check.
    """
    if isinstance(i, (bool, float)):
        i = int(i)

    if not isinstance(i, int):
        i = 0
    return seal(i, 0, max_a)


class RadioGroup:
    """Use to manage a group of RadioButtons."""

    def __init__(self, q, k):
        """
        Receive the RadioButtons. The RadioButtons
        are assumed to be part of the same group.

        q: iterable
            group of related RadioButtons

        k: string
            group key
        """
        self.widget_q = q[:]
        self.key = k

    def get_ui(self):
        """
        Find the active RadioButton. There's
        always one RadioButton that is active.

        Return: int
            index into group
            in 0 to n
        """
        for i, g in enumerate(self.widget_q):
            if g.get_ui():
                return i

        # fail-safe
        return 0

    def set_ui(self, i):
        """
        Set a RadioButton in the group as active. Only
        one RadioButton in a group can be active.

        i: integer
            index into group

        Return: int
            Widget index
        """
        i = check_radio(i, len(self.widget_q) - 1)

        self.widget_q[i].set_ui(1)
        return i

    def hide(self):
        """Hide the RadioButtons in this group."""
        for i in self.widget_q:
            i.hide()

    def show(self):
        """Show the RadioButtons in this group."""
        for i in self.widget_q:
            i.show()


class RadioButton(Widget):
    """
    Is a GTK RadioButton attached to an GTK Alignment.
    RadioButtons are grouped together and identify
    their group by referencing their first member.
    """
    change_signal = 'realize', 'toggled'

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        g = gtk.RadioButton(d[df.RADIO_GROUP], d[df.TEXT][d[df.LABEL_I]])

        Widget.__init__(self, g, **d)
        self.add(g)

    def get_ui(self):
        """
        Get the value of the RadioButton.

        Return: int
            0 or 1
        """
        # Intermittently, 'get_active' returns boolean.
        return int(self.widget.get_active())

    def set_ui(self, i):
        """
        Set the value of the RadioButton.

        i: int
            0 or 1

        Return: int
            Displayed value.
        """
        i = check_radio(i, 1)

        self.widget.set_active(i)
        return i


class Radio(Widget):
    """Is a super class for the Radio-type classes."""
    change_signal = 'toggled'
    has_table_label = False

    def __init__(self, **d):
        """
        Create the Widgets.

        d: dict
            Has Init values.
        """
        # Is set by the Table container.
        group = self.label = None

        q = self.widget_q = []

        for i in range(len(d[df.TEXT])):
            q.append(RadioButton(**dict(d, label_i=i, radio_group=group)))
            group = q[0].widget

        Widget.__init__(self, q[0].widget, **d)

        # GTK container for the radio buttons
        self.box = d[df.BOX]

        for i in q:
            self.box.pack_start(i, expand=True)

        self.add(self.box)

        self.radio_group = RadioGroup(q, self.key)
        if df.TIPS in d:
            for i, g in enumerate(q):
                g.widget.set_tooltip_text(d[df.TIPS][i])

    def get_ui(self):
        """
        Get the value of the RadioGroup.

        Return: int
            index to the active RadioButton
        """
        return self.radio_group.get_ui()

    def hide(self):
        """Hide the Buttons and their Label."""
        if self.box:
            if self.box.get_visible():
                self.box.hide()
        self.label_box.hide()

    def set_ui(self, i):
        """
        Set the value in the RadioGroup.

        i: int
            index to a RadioButton

        Return: int
            Widget index
        """
        i = self.radio_group.set_ui(i)

        self.on_voter_change(self.widget)   # group Widget
        return i

    def show(self):
        """Hide the Buttons and their Label."""
        if self.box:
            if not self.box.get_visible():
                self.box.show()
        self.label_box.show()


class RadioRandom(Radio):
    """Randomize select state."""

    def __init__(self, **d):
        Radio.__init__(self, **d)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

    def randomize(self, *_):
        """Randomize the Widget value."""
        self.load_a(randint(0, len(self.widget_q) - 1))


class RadioRandomColumn(RadioRandom):
    """Create a VBox with RadioButtons."""

    def __init__(self, **d):
        """
        d: dict
            Initialize thw Widget.
        """
        d[df.BOX] = gtk.VBox()
        RadioRandom.__init__(self, **d)


class RadioRandomRow(RadioRandom):
    """Create a HBox with RadioButtons."""

    def __init__(self, **d):
        """
        d: dict
            Initialize thw Widget.
        """
        d[df.BOX] = gtk.HBox()
        RadioRandom.__init__(self, **d)


class RadioRow(Radio):
    """Is a Table suited Row Widget that does not randomize."""

    def __init__(self, **d):
        """
        d: dict
            Initialize thw Widget.
        """
        d[df.BOX] = gtk.HBox()
        Radio.__init__(self, **d)


class SwitchRadio(Radio):
    """Randomize switch state."""

    def __init__(self, **d):
        """
        d: dict
            Initialize thw Widget.
        """
        d[df.BOX] = gtk.HBox()
        Radio.__init__(self, **d)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

    def randomize(self, *_):
        """Turn on the Switch."""
        self.load_a(1)
