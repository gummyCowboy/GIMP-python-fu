#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    LAYER_MODE_DARKEN_ONLY, LAYER_MODE_OVERLAY, pdb
)
from roller_constant import Accent as by, Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gimp_group_layer import merge_group_layer
from roller_gimp_image import add_sub_maya_group, make_group_layer
from roller_gimp_layer import (
    blur_selection, clear_selection, clone_layer, do_curves
)
from roller_gimp_selection import select_color
from roller_maya_sub_accent import SubAccent


def do_matter(maya):
    """
    Create a Etch Sketch matter layer.

    maya: EtchSketch
    Return: layer or None
        Etch Sketch material
    """
    def _do_step_1():
        """
        Increase the strength of the line.

        Return: layer
            with modification
        """
        _group = make_group_layer(j, parent, 0, "Step 1", z=z)
        _z1 = clone_layer(z, n="Overlay")
        _z1.mode = LAYER_MODE_OVERLAY

        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)

        return merge_group_layer(_group, n="Step 1")

    def _do_step_2():
        """
        Apply newsprint to line.

        Return: layer
            with modification
        """
        _f = Globe.azimuth

        while _f < 0:
            _f += 360

        _group = make_group_layer(j, parent, 0, "Step 2", z=bg_z)

        pdb.gimp_image_reorder_item(j, z, _group, 0)

        z.mode = LAYER_MODE_DARKEN_ONLY
        _type = by.NEWS_TYPE_LIST.index(d[de.SKETCH_TEXTURE])

        pdb.plug_in_newsprint(
            j, z,
            int(d[de.CELL_SIZE]),
            1,                  # RGB
            100,                # black
            _f,
            _type,
            _f,
            _type,
            _f,
            _type,
            _f,
            _type,
            2                   # sample
        )

        select_color(bg_z, (0, 0, 0), threshold=.25)
        clear_selection(z)
        blur_selection(bg_z, 500)
        do_curves(bg_z, (.0, .1, 1., .9))
        return merge_group_layer(_group, n="Step 2")

    j = Run.j
    d = maya.value_d
    parent = add_sub_maya_group(maya)
    z = maya.bg_z
    maya.bg_z = None
    bg_z = clone_layer(z)

    pdb.plug_in_edge(
        j, z,
        1.,             # edge amount
        0,              # no wrap
        0               # Sobel
    )

    z = _do_step_1()

    _do_step_2()
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class EtchSketch(SubAccent):
    kind = de.ETCH_SKETCH

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
