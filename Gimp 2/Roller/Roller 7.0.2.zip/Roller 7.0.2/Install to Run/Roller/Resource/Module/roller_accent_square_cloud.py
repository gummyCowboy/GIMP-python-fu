#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_DARKEN_ONLY,
    LAYER_MODE_HSV_SATURATION,
    LAYER_MODE_OVERLAY,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gimp_image import add_sub_maya_group, add_wip_layer
from roller_gimp_layer import clone_layer, color_layer_default, dilate
from roller_maya_sub_accent import SubAccent


def do_matter(maya):
    """
    Make a matter layer for SquareCloud.

    maya: SquareCloud
    Return: layer or None
        'matter'
    """
    j = Run.j
    d = maya.value_d
    parent = add_sub_maya_group(maya)
    base = add_wip_layer("Base", parent)
    z = clone_layer(base, n="Plasma")

    pdb.gimp_selection_none(j)

    # medium turbulence, '3.5'
    pdb.plug_in_plasma(j, z, int(d[de.RANDOM_SEED] + Globe.seed), 3.5)

    z1 = clone_layer(z, n="Erode")

    for i in range(10):
        dilate(z1)
        pdb.plug_in_erode(
            j, z,
            6,                      # propagate opaque
            7,                      # RGB channels
            1.,                     # full rate
            7,                      # RGB channels
            0,                      # low limit
            255                     # upper limit
        )

    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
    pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
    color_layer_default(base, (127, 127, 127))

    z2 = clone_layer(base, n="HSV Saturation")
    z2.mode = LAYER_MODE_HSV_SATURATION

    pdb.gimp_image_reorder_item(j, z2, parent, 0)

    z3 = clone_layer(z, n="Overlay")
    z3.mode = LAYER_MODE_OVERLAY
    z3.opacity = 75.

    pdb.gimp_image_reorder_item(j, z3, parent, 0)

    z4 = clone_layer(z3, n="Darken Only")
    z4.mode = LAYER_MODE_DARKEN_ONLY
    z4.opacity = 30.
    z = pdb.gimp_image_merge_layer_group(j, parent)
    z = clone_layer(z, n="Colorify")
    z.opacity = 50.

    pdb.plug_in_colorify(j, z, d[de.COLOR_1])
    return maya.finish(
        pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE), d[rk.BRW]
    )


class SquareCloud(SubAccent):
    """Create Accent output."""
    kind = de.SQUARE_CLOUD

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)
