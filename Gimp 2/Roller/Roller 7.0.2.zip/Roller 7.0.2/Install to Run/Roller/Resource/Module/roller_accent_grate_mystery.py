#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, pdb  # type: ignore
from roller_accent_color_grid import do_color_grid
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_deco_output import init_deco_type
from roller_def_access import get_default_d
from roller_gimp_image import add_sub_maya_group, clip_to_wip
from roller_gimp_layer import clone_layer, create_mask, flip_layer
from roller_gimp_layers import transfer_mask
from roller_gimp_selection import select_rect
from roller_maya_sub_accent import SubAccent
from roller_preset_shadow import do_stylish_shadow
from roller_wip import Wip


def do_1st_layer(maya, j, d, e, d1, group):
    """
    Create a diamond-slat layer and a shadow.

    maya: Work
    j: GIMP image
        Is the render.

    d: dict
        Color Grid Preset

    e: dict
        Gradient Fill Preset

    d1: dict
        Mystery Grate Preset

    group: group layer
        parent of output
    """
    d[de.ROW] = 2
    d[de.COLUMN] = d1[de.COLUMN_1]
    d[de.MODE] = "Normal"
    d[de.ANGLE] = 45.
    z = do_color_grid(d, group)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    do_stylish_shadow(z, blur=30)
    create_mask(z)
    do_gradient(maya, e, z)


def do_2nd_layer(maya, j, d, e, d1, group):
    """
    Process the second layer.

    maya: Work
    j: GIMP image
        Is the render.

    d: dict
        Color Grid Preset dict

    e: dict
        Gradient Fill Preset

    d1: dict
        Mystery Grate Preset

    group: group layer
        parent of output
    """
    d[de.COLUMN] = d1[de.COLUMN_2]
    z = do_color_grid(d, group)
    e[de.GRADIENT_ANGLE] = de.BOTTOM_RIGHT_TO_TOP_LEFT

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    do_stylish_shadow(z, blur=22)
    create_mask(z)
    return do_gradient(maya, e, z)


def do_3rd_layer(z):
    """
    Process the third layer.

    z: layer
        Modify.
    """
    z = clone_layer(z)

    flip_layer(z, is_h=True)
    do_stylish_shadow(z, blur=15)
    create_mask(z)


def do_gradient(maya, d, z):
    """
    Draw a gradient.

    d: dict
        Gradient Fill Preset

    z: layer
        Receive the gradient.

    Return: layer
        gradient
    """
    j = z.image
    arg, p = init_deco_type(de.GRADIENT, j, maya, z.parent, d, 0, False)

    select_rect(j, *maya.rect)

    z1 = p(*arg)

    for i in (z, z1):
        clip_to_wip(i)

    transfer_mask(z1, z)
    return pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)


def do_matter(maya):
    """
    Make an Accent layer.

    maya: MysteryGrate
    Return: layer
        'matter'
    """
    j = Run.j
    d = maya.value_d
    e = maya.gradient_d
    e[de.GRADIENT] = d[rk.RW1][de.GRADIENT]
    e[de.GRADIENT_TYPE] = de.LINEAR
    e[de.GRADIENT_ANGLE] = de.TOP_LEFT_TO_BOTTOM_RIGHT

    e.update(d)

    d1 = maya.color_grid_d
    d1[de.ANGLE] = 45.
    group = add_sub_maya_group(maya)
    arg, p = init_deco_type(de.GRADIENT, j, maya, group, e, 0, False)
    maya.rect = Wip.get_rect()

    select_rect(j, *maya.rect)

    z = p(*arg)
    z.name = "Base"

    do_1st_layer(maya, j, d1, e, d, group)

    z1 = do_2nd_layer(maya, j, d1, e, d, group)

    do_3rd_layer(z1)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, group), d[rk.RW1]
    )


class GrateMystery(SubAccent):
    """Create Accent output."""
    kind = de.GRATE_MYSTERY

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, False, is_old)
        self.gradient_d = get_default_d(de.GRADIENT_FILL)
        self.color_grid_d = get_default_d(de.COLOR_GRID)
