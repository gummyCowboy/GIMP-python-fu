#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import floor
from roller_constant import Triangle as ft
from roller_constant_identity import Identity as de
from roller_model_goo import Goo
from roller_polygon import calc_pin_xy, make_coord_list


def calc_hexagon(model, o, ellipse_space=.0):
    """
    Calculate a double-spaced grid of regular shaped hexagon cell.

    Calculate cell rectangle for a Model's cell.

    model: Model
    o: One
        Has Cell/Type Option as attribute.

    Return: dict
        {value: [bool, bool]}
        {cell key: [Plan vote change, Work vote change]}
    """
    def _arrange():
        """
        Arrange a hexagon shape of x, y coordinate
        where each x, y pair is a polygon vertex.

        Return: tuple
            shape
        """
        return x, y1, x1, y, x2, y1, x2, y2, x1, y3, x, y2

    vote_d = {}
    did_cell = model.past.did_cell
    row, column = model.grid
    goo_d = model.goo_d
    x, y, canvas_w, canvas_h = model.canvas_pocket.rect

    if o.grid_type == de.CELL_SIZE:
        # Correct cell size overflow.
        w = min(canvas_w, o.column_width)
        h = min(canvas_h, o.row_height)

        # grid size
        w1 = w / 2.
        h1 = h * .75
        h2 = h - h1

        s = column * w1 + w1, row * h1 + h2

        # topleft corner, 'x, y'
        x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

    elif o.grid_type == de.SHAPE_COUNT:
        # Calculate 's', 'w', 'h'.
        # cell size
        w = floor(canvas_w / (.5 + column * .5))
        h = floor(canvas_h / (.25 + row * .75))

        # two possible solutions
        # solution one
        # hexagon size, 'hex_w, hex_h'
        hex_w, hex_h = h * ft.SCALE_DOWN, h

        w1 = hex_w / 2.
        h1 = hex_h * .75
        h2 = hex_h - h1
        s = column * w1 + w1, row * h1 + h2

        if s[0] > canvas_w or s[1] > canvas_h:
            # solution two
            h = w * ft.SCALE_UP
            w1 = w / 2.
            h1 = h * .75
            h2 = h - h1
            s = column * w1 + w1, row * h1 + h2

        else:
            w, h = hex_w, hex_h
        x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

    else:
        # cell count
        # Calculate the cell size.
        w = canvas_w / (.5 + column * .5)
        h = canvas_h / (.25 + row * .75 - ellipse_space)

    w = w / 2.
    h1 = h * .25
    h2 = h - h1

    # [intersect, ...]
    q_x = make_coord_list(canvas_w, column + 2, x, span=w)
    q_y = []

    for _ in range(row + 1):
        q_y.extend([round(y), round(y + h1)])
        y += h2

    for r_c in model.cell_q:
        r, c = r_c
        r1 = r * 2
        x, x1, x2 = q_x[c:c + 3]
        y, y1, y2, y3 = q_y[r1:r1 + 4]
        a = goo_d[r_c] = Goo(r_c)

        # Prevent round to zero with max 1..
        a.cell.rect = a.merged.rect = \
            x, y, max(1., (x2 - x)), max(1., y3 - y)

        vote_d[r_c] = did_cell(r_c)
        a.form = _arrange()
    return vote_d
