#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_EXCLUSION,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_HSV_HUE,
    LAYER_MODE_LINEAR_LIGHT,
    LAYER_MODE_LUMA_LIGHTEN_ONLY,
    LAYER_MODE_OVERLAY,
    LAYER_MODE_PIN_LIGHT,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_deco_output import init_deco_type
from roller_def_access import get_default_d
from roller_gegl import (
    edge, emboss, median_blur, unsharp_mask, waterpixels
)
from roller_gimp_image import add_wip_layer, insert_copy, make_group_layer
from roller_gimp_layer import (
    blur_selection, clone_layer, color_layer_default, dilate, hide_layer
)
from roller_gimp_selection import select_rect
from roller_maya_sub_accent import SubAccent
from roller_wip import Wip


def do_matter(maya):
    """
    Make a matter layer for ClayChemistry.

    maya: ClayChemistry
    Return: layer
        'matter'
    """
    j = Run.j
    d = maya.value_d
    z = maya.bg_z
    parent, group = maya.init_background_groups(j)
    bg_z = clone_layer(z)
    maya.bg_z = None

    pdb.gimp_image_reorder_item(j, bg_z, parent, 1)

    z1 = clone_layer(z)

    blur_selection(z, 300)

    z1.name = "HSV Hue"
    z1.mode = LAYER_MODE_HSV_HUE

    pdb.plug_in_gimpressionist(j, z1, "Painted_Rock")

    z = insert_copy(group, z1)
    z.mode = LAYER_MODE_DIFFERENCE

    edge(z)

    z = insert_copy(group, z)
    z.mode = LAYER_MODE_EXCLUSION

    select_rect(j, *Wip.get_rect())
    dilate(z)
    waterpixels(z)
    unsharp_mask(z, 3., 30., .0)

    z = insert_copy(group, z)
    z = clone_layer(z, n="Linear Light")
    z.mode = LAYER_MODE_LINEAR_LIGHT

    blur_selection(z, 12)

    z = insert_copy(group, z)

    dilate(z)
    dilate(z)

    z.mode = LAYER_MODE_GRAIN_EXTRACT
    z1 = pdb.gimp_image_merge_layer_group(j, group)
    group = make_group_layer(j, parent, 0, "WIP", z=z1)
    z2 = clone_layer(z1, n="Luma Lighten Only")

    waterpixels(z2)

    z2.mode = LAYER_MODE_LUMA_LIGHTEN_ONLY
    z2 = pdb.gimp_image_merge_down(j, z2, CLIP_TO_IMAGE)
    z3 = clone_layer(z2, n="Median Blur")

    median_blur(z3, 32, 50.)

    z4 = clone_layer(z3, n="Pin Light")
    z4.mode = LAYER_MODE_PIN_LIGHT

    edge(z4)
    pdb.plug_in_erode(
        j, z4,
        1,                              # propagate black
        7,                              # RGB channels
        1.,                             # full rate
        7,                              # direction mask
        0,                              # low limit
        255                             # upper limit
    )

    z = insert_copy(group, z4)
    z2.mode = LAYER_MODE_OVERLAY
    z.opacity = 33.

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    emboss(z2, Globe.azimuth, 12., 1.)
    hide_layer(z3)
    hide_layer(z4)

    e = maya.gradient_d

    e.update(d)

    e[de.GRADIENT] = d[rk.RW1][de.GRADIENT]
    arg, p = init_deco_type(
        de.GRADIENT, j, maya, group, e, len(group.layers) + 1, False
    )
    maya.rect = Wip.get_rect()

    select_rect(j, *maya.rect)

    z1 = p(*arg)
    z = add_wip_layer("Back", group, offset=len(group.layers) + 1)
    z.opacity = z1.opacity = d[de.GRADIENT_OPACITY]

    color_layer_default(z, (64, 64, 64))
    blur_selection(bg_z, 300)
    pdb.gimp_image_reorder_item(
        j, bg_z, group, len(group.layers) + 1
    )
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.RW1]
    )


class ClayChemistry(SubAccent):
    kind = de.CLAY_CHEMISTRY

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
        d = self.gradient_d = get_default_d(de.GRADIENT_FILL)
        d[de.OFFSET] = 0
