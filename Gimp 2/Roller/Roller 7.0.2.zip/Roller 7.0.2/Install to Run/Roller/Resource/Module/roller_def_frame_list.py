#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import df
from roller_constant_identity import de
from roller_def_option import SWITCH
from roller_widget_option_list import OptionList

OPTION_LIST = {
    df.STILL: True,
    df.WIDGET: OptionList
}
FRAME_LIST =  OrderedDict([
    (de.SWITCH, deepcopy(SWITCH)),
    (de.OPTION_LIST,  deepcopy(OPTION_LIST))
])
