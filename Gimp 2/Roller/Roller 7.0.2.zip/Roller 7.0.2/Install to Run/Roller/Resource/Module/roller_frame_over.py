#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, FILL_PATTERN, pdb   # type: ignore
from roller_constant import Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Globe, Path, Run
from roller_def_access import get_default_d
from roller_frame import do_image_selection
from roller_frame_alt import OverlapWrap
from roller_gimp_context import set_fill_context_default, set_gimp_pattern
from roller_gimp_gradient import draw_gradient, get_gradient_points
from roller_gimp_image import (
    add_layer,
    check_matter,
    image_copy_all,
    make_group_overlay,
    paste_layer,
    shape_clipboard
)
from roller_gimp_layer import color_layer_default
from roller_gimp_layer import make_clouds, select_layer, verify_layer
from roller_gimp_selection import (
    get_select_coord, select_channel, select_rect
)
from roller_image_change import ref_get_image
from roller_image_pic import Pic
from roller_image_single import SINGLE_FILE_PATH, Single
from roller_maya_add import Add
from roller_maya_build import Build, SubBuild
from roller_maya_bulb import Bulb
from roller_maya_layer import check_mix_basic
from roller_preset_mod import do_mod
from roller_gimp_mask import mask_sub_maya
from roller_wip import Wip
import os


def apply_clouds(__, z, d, _):
    """
    Make clouds for am overlay selection.

    __: Maya
    z: layer
        Is frame.

    d: dict
        Over/Overlay Preset

    _: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        with overlay material
    """
    make_clouds(z, int(d[de.RANDOM_SEED] + Globe.seed))
    return z


def apply_color(__, z, d, _):
    """
    Color the overlay.

    __: Maya
    z: layer
        Is frame.

    d: dict
        Over/Overlay Preset

    _: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        overlay
    """
    color_layer_default(z, d[de.COLOR_1])
    return z


def apply_gradient(__, z, d, _):
    """
    Color the overlay with a gradient.

    __: Maya
    z: layer
        Is frame.

    d: dict
        Over/Overlay Preset

    _: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        overlay
    """
    j = Run.j
    x, y, x1, y1 = get_select_coord(j)
    w, h = x1 - x, y1 - y
    e = get_default_d("Gradient Fill")

    e.update(d)

    e[de.GRADIENT] = d[de.GRADIENT]
    start_x, end_x, start_y, end_y = \
        get_gradient_points(d, x - Wip.x, y - Wip.y, w, h)

    select_rect(j, x, y, w, h)
    draw_gradient(z, e, start_x, start_y, end_x, end_y)
    return z


def apply_image(maya, z, _, k):
    """
    Apply an image to the overlay.

    maya: SubBuild
    z: layer
        Has the frame.

    d: dict
        Over/Overlay Preset

    k: tuple
        Goo key; (r, c)

    Return: layer
        overlay
    """
    j = Run.j
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]

    # frame index, '2'
    j1 = ref_get_image(maya.any_group, k, 2)

    if j1:
        image_copy_all(j1)
        shape_clipboard(x1 - x, y1 - y)

        z1 = paste_layer(z)

        pdb.gimp_layer_set_offsets(z1, x, y)
        z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
    return z


def apply_pattern(__, z, d, _):
    """
    Paint the overlay with a pattern.

    __: Maya
    z: layer
        Receive the overlay.

    d: dict
        Over/Overlay Preset

    _: tuple
        (row, column) of int
        cell index and Goo key
        not used

    Return: layer
        overlay
    """
    set_fill_context_default()
    set_gimp_pattern(d[de.PATTERN])

    # x and y fill origin point, '0., 0,'
    pdb.gimp_drawable_edit_bucket_fill(z, FILL_PATTERN, .0, .0)
    return z


def apply_plasma(__, z, d, _):
    """
    Paint the overlay with plasma.

    _: Maya
    z: layer
        Receive the plasma.

    d: dict
        Over/Overlay Preset

    _: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        overlay
    """
    j = Run.j

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(
        j, z,
        int(d[de.RANDOM_SEED] + Globe.seed),
        1.                                 # lowest turbulence
    )
    return z


def do_matter(maya):
    """
    Make a frame.

    maya: Over
    Return: layer or None
        Over/Stencil 'matter'
    """
    if maya.value_d[de.TYPE] != "None":
        return do_image_selection(
            maya, do_selection, embellish, "Material", is_clip=False
        )


def do_overlay(maya):
    """
    Make an overlay layer for the Stencil.

    maya: Overlay
    Return: layer or None
        overlay
    """
    def _select_rect():
        """Select the rectangle from the bounds of the current selection."""
        _x, _y, _x1, _y1 = get_select_coord(j)
        select_rect(j, _x, _y, _x1 - _x, _y1 - _y)

    j = Run.j

    # Over/Overlay Preset dict, 'd'
    d = maya.value_d

    super_ = maya.cast
    n = d[de.TYPE]
    if n in ROUTE_TYPE:
        z = add_layer(j, maya.group, maya.get_light(), "Material")

        # Check to see if the caller is a grid, 'main_q'.
        if hasattr(super_, 'main_q') and n in ROUTE_GRID:
            for r, c in super_.main_q:
                select_channel(j, maya.model.get_image_sc((r, c)))
                _select_rect()
                if not pdb.gimp_selection_is_empty(j):
                    z = ROUTE_GRID[n](maya, z, d, (r, c))
            if z:
                do_mod(z, d[de.MOD])

        else:
            select_layer(super_.matter)
            _select_rect()
            if not pdb.gimp_selection_is_empty(j):
                z = ROUTE_TYPE[n](maya, z, d, super_.k)
                if z:
                    do_mod(z, d[de.MOD])
        return verify_layer(z)


def do_selection(maya, z):
    """
    Make a frame for a selection.

    maya: Maya
    z: layer
        Receive Stencil material
    """
    j = Run.j

    # Over Preset dict, 'd'
    d = maya.value_d
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]

    # Get the GIMP image.
    # Frame index, '1'
    j1 = get_frame_image(d)

    if j1:
        image_copy_all(j1)
        shape_clipboard(x1 - x, y1 - y)

        z = paste_layer(z, n="Frame")

        pdb.gimp_layer_set_offsets(z, x, y)
        z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
    return z


def embellish(_, z):
    """
    Is a callback for 'do_selection'.

    _: Maya
    """
    return z


def get_frame_image(d):
    """
    Retrieve a GIMP image corresponding with Stencil/Type.

    d: dict
        Over Preset

    Return: GIMP image or None
        Stencil
    """
    if d[de.TYPE] != "None":
        e = Over.frame_d
        n = d[de.TYPE]
        single = e.get(n)

        if single is None:
            file_path = "{}{}{}.png".format(Path.frame, os.path.sep, n)
            e[n] = single = Single(file_path, SINGLE_FILE_PATH)
            j = single.get_image()
            Pic.opened_q.append(j)

        else:
            j = single.get_image()
        return j


class OverOverlay(SubBuild):
    """
    Process change for an overlay layer.
    Change its blend with its super-maya mask.
    """
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_overlay, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Bridge user and Maya.

        super_maya: Maya
            Is the enclosing Maya.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (de.IMAGE_CHOICE,),
                k_path + (de.MOD,),
                k_path + (de.MOD, de.BLUR_D)
            ],
            do_overlay
        )
        self.viewed_image = None
        self.sub_maya[sm.BULB] = Bulb(any_group, self, de.OVER_OVERLAY)

    def do(self, d, is_change, is_mask):
        """
        Check, modify, and produce layer output.

        d: dict
            Over/Overlay Preset

        is_change: bool
            If it is True, then a mask is drawn on the Color layer.

        is_mask: bool
            Is True if the frame Maya has change.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize()

        if self.matter:
            if self.is_matter or is_mask:
                mask_sub_maya(
                    self.super_maya.sub_maya[sm.WRAP].matter, self.matter
                )
            self.sub_maya[sm.BULB].do(is_change)

        else:
            self.die()
        self.reset_issue()


class Over(Build):
    # {Stencil Type: Single}
    frame_d = {}

    is_seeded = True
    put = issue_q = ()
    kind = material = de.OVER
    overlay_k = de.OVERLAY_OV
    wrap_k = de.STENCIL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        Build.__init__(self, any_group, super_maya, k_path, do_matter)

        self.sub_maya[sm.WRAP] = OverlapWrap(
            any_group, self, k_path + (rk.BRW, de.STENCIL), do_matter
        )
        self.sub_maya[sm.OVERLAY] = OverOverlay(
            any_group, self, k_path + (rk.BRW, de.OVERLAY_OV)
        )
        self.sub_maya[sm.ADD] = Add(
            any_group, self.sub_maya[sm.WRAP], k_path + (rk.BRW, de.ADD)
        )

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            Bevel Preset
            {Identity: value}

        is_change: bool
            Is the state of the super-maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        m = is_change
        wrap = self.sub_maya[sm.WRAP]

        self.realize()

        m |= wrap.do(d[rk.BRW][self.wrap_k], is_change)

        if wrap.matter:
            self.sub_maya[sm.OVERLAY].do(d[rk.BRW][de.OVERLAY_OV], m, m)
            self.sub_maya[sm.ADD].do(
                d[rk.BRW][de.ADD], m, m, is_back, wrap.group
            )

        else:
            self.die()
        self.reset_issue()


# Are Over types that are applied to each cell individually.
ROUTE_GRID = {
    de.GRADIENT: apply_gradient,
    de.IMAGE: apply_image,
}

# Are Over types that are applied one time.
ROUTE_TYPE = {
    de.CLOUDS: apply_clouds,
    de.COLOR: apply_color,
    de.GRADIENT: apply_gradient,
    de.IMAGE: apply_image,
    de.PATTERN: apply_pattern,
    de.PLASMA: apply_plasma
}
