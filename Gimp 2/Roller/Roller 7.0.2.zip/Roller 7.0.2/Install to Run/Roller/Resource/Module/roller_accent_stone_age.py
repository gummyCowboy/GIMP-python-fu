#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (     # type: ignore
    CHANNEL_OP_REPLACE,
    CLIP_TO_IMAGE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_MULTIPLY,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gegl import spread
from roller_gimp_context import clipboard_fill_default
from roller_gimp_image import add_wip_below
from roller_gimp_layer import (
    blur_selection,
    clear_inverse_selection,
    clone_layer,
    color_selection,
    do_curves,
    get_mean_color,
    remove_layer
)
from roller_gimp_selection import select_rect
from roller_maya_sub_accent import SubAccent
from roller_pattern import make_cube_pattern
from roller_wip import Wip

# Made of x, y pairs that range from 0.0 to 1.0.
CURVES = (
    # one
    (
        .0, .0,
        .4, .1,
        .8, .8,
        1., 1.
    ),

    # two
    (
        .0, .0,
        .2, .0,
        .5, 1.,
        .75, 1.,
        1., .0
    ),

    # three
    (
        .0, .0,
        .25, 1.,
        .5, 1.,
        .8, .0,
        1., .0
    ),

    # four
    (
        .0, 1.,
        .25, 1.,
        .55, .0,
        1., .0
    )
)


def draw_layer(j, z, d, layer_num):
    """
    There are four layers, each having a different pattern and
    value range. Each pattern is a cube, but differs by scale.
    The value range is determined by the CURVES settings.

    j: GIMP image
        Is render.

    z: layer
        Background copy

    d: dict
        Stone Age Preset

    layer_num: int
        distinguish range and type
    """
    # receiving layer, 'z1'
    z1 = clone_layer(z, n="Curves")

    # layer with the color value, 'z2'
    z2 = clone_layer(z, n="Color")

    do_curves(z1, CURVES[layer_num])

    # Erase the black.
    pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

    # layer to receive symbol and color, 'z'
    z = clone_layer(z, n="{} of 4".format(str(layer_num + 1)))
    z.mode = LAYER_MODE_MULTIPLY

    make_cube_pattern(
        d[de.PATTERN_SIZE] * (layer_num + 1),
        [(255, 255, 255), (187, 187, 187), (127, 127, 127)]
    )
    select_rect(j, *Wip.get_rect())
    clipboard_fill_default(z)
    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z1)
    clear_inverse_selection(z)
    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z1)
    clear_inverse_selection(z2)

    # Get the mean color to fill the layer.
    avg_color = get_mean_color(z2)

    # Fill existing pixels with the mean
    # color using their material selection.
    color_z = add_wip_below(z)

    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)
    color_selection(color_z, avg_color)
    pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
    remove_layer(z1)
    remove_layer(z2)


def do_matter(maya):
    """
    Make a matter layer for StoneAge.

    maya: StoneAge
    Return: layer or None
        'matter'
    """
    j = Run.j
    d = maya.value_d
    parent, group = maya.init_background_groups(j)
    z = maya.bg_z
    maya.bg_z = None

    for i in range(4):
        draw_layer(j, z, d, i)

    pdb.gimp_selection_none(j)
    blur_selection(z, 500.)

    z = pdb.gimp_image_merge_layer_group(j, group)
    z = clone_layer(z)
    z.mode = LAYER_MODE_DIFFERENCE

    do_curves(z, (.0, .0, .0431, .3411, 1., 1.))

    arg = (15, 10) if j.width > j.height else (10, 15)

    spread(z, *arg)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class StoneAge(SubAccent):
    """Create Accent output."""
    kind = de.STONE_AGE

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, True, False, is_old)
