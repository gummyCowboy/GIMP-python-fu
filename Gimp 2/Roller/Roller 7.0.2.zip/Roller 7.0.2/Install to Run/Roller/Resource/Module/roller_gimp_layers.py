#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import ADD_MASK_ALPHA, pdb   # type: ignore
from roller_gimp_layer import create_mask, remove_layer


def collect_group(a, q):
    """
    Recursively step through an image's layers
    while adding group layers to a list.

    a: GIMP image or group layer
        Scan for group layer.

    q: list
        [group layer, ...]
    """
    for i in a.layers:
        if pdb.gimp_item_is_group(i):
            q.append(i)
            collect_group(i, q)


def collect_non_group(a, q):
    """
    Recursively step through an image's layers
    while adding non-group layers to a list.

    a: GIMP image or group layer
        Scan for non-group layer.

    q: list
        [drawable, ...]
    """
    for i in a.layers:
        if pdb.gimp_item_is_group(i):
            collect_non_group(i, q)
        else:
            q.append(i)


def remove_layers(a):
    """
    Remove zero or more layers.

    a: iterable or layer
        (layer, ...)
        Remove.
    """
    if a:
        if isinstance(a, (tuple, list)):
            for i in a:
                remove_layer(i)
        else:
            remove_layer(a)


def transfer_mask(z, z1, option=ADD_MASK_ALPHA):
    """
    Transfer a mask from one layer to another.

    z: layer
        Receive mask.

    z1: layer
        Has the mask.

    option: gimpfu enum
        Define the mask-type.
    """
    if not z1.mask:
        create_mask(z1, option=option)
    if not z.mask:
        z.add_mask(pdb.gimp_layer_create_mask(z1, option))
