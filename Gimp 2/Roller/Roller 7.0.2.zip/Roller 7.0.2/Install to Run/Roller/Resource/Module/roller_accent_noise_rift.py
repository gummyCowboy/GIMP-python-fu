#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_REPLACE, pdb   # type: ignore
from random import choice, randint
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_gimp_image import add_sub_maya_group, add_wip_layer
from roller_gimp_layer import clear_inverse_selection
from roller_maya_sub_accent import SubAccent
from roller_preset import combine_seed


def do_matter(maya):
    """
    Make a matter layer for NoiseRift.

    maya: NoiseRift
    Return: layer
        'matter'
    """
    def _add_noise():
        _m = True

        if de.NOISE_OPACITY in d:
            if not d[de.NOISE_OPACITY]:
                _m = False
        if _m:
            # Generate noise line.
            # The horizontal and vertical sizes are randomized.
            pdb.plug_in_solid_noise(
                j, z,
                0,                      # no tile-able
                1,                      # yes, turbulent
                int(d[de.RANDOM_SEED] + Globe.seed),
                int(d[de.NOISE_AMOUNT]),
                float(randint(1, 3)),
                float(randint(1, 3)),
            )

            # Aggregate the noise.
            # The radius is randomized.
            pdb.plug_in_unsharp_mask(
                j, z,
                choice((1., 3.)),
                54.,                    # amount
                .0                      # threshold
            )

            # Remove the white noise.
            pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)
            clear_inverse_selection(z)
            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))

    j = Run.j
    d = maya.value_d
    parent = add_sub_maya_group(maya)
    z = add_wip_layer("Noise", parent)

    combine_seed(d)
    _add_noise()
    pdb.gimp_selection_none(j)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class NoiseRift(SubAccent):
    """Create Accent output."""
    kind = de.NOISE_RIFT

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)
