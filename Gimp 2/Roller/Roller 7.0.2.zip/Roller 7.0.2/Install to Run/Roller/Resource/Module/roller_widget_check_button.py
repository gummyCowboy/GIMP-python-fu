#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant import Define as df, Signal as si
from roller_step import get_type_text
from roller_widget import Widget
import gtk  # type: ignore


class CheckButton(Widget):
    """Customize GTK CheckButton with a GTK Alignment."""
    change_signal = 'clicked', 'activate'
    has_table_label = False

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        g = gtk.CheckButton(label=get_type_text(d[df.KEY]))

        Widget.__init__(self, g, **d)
        self.add(g)

    def get_ui(self):
        """
        Get the value of the CheckButton.

        Return: int
            CheckButton checked state
        """
        return int(self.widget.get_active())

    def set_ui(self, a):
        """
        Set the CheckButton checked state.

        a: int
        Return: int
            Display value.
        """
        if isinstance(float, bool):
            a = int(a)

        elif not isinstance(a, int):
            a = 0

        self.widget.set_active(a)
        return a


class CheckButtonPlan(CheckButton):
    """Has a signal attribute."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        self.signal = d[df.SIGNAL]
        CheckButton.__init__(self, **d)


class CheckButtonRandom(CheckButton):
    """Randomize output."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        CheckButton.__init__(self, **d)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

    def randomize(self, *_):
        """Randomize the CheckButton value."""
        self.load_a(randint(0, 1))
