#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_identity import Identity as de
from roller_model_box import Box
from roller_model_cell import Cell
from roller_model_pyramid import Pyramid
from roller_model_sidewalk import Sidewalk
from roller_model_stack import Stack
from roller_model_table import Table


# {Model Type, Model class}
CLASS_MODEL = {
    de.BOX: Box,
    de.CELL: Cell,
    de.PYRAMID: Pyramid,
    de.SIDEWALK: Sidewalk,
    de.STACK: Stack,
    de.TABLE: Table
}
