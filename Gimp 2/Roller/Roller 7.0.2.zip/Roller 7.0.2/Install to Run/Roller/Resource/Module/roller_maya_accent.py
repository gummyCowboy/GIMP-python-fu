#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_any_group import ManyGroup
from roller_constant import Issue as vo, Signal as si, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_image import add_sub_maya_group, insert_copy, make_group_layer
from roller_gimp_layer import get_layer_position
from roller_helm import Helm
from roller_maya import Main, Maya
from roller_maya_bulb import Bulb
from roller_preset import get_option_list_key
from roller_preset_lookup import CLASS_ACCENT


def copy_background(j, maya):
    """
    Copy the visible background below the Accent group
    layer as the Accent's base layer.

    j: GIMP image
        the WIP render

    maya: Maya
        Has a group layer.

    Return: tuple
        (parent layer, group layer, background layer)
    """
    parent = add_sub_maya_group(maya)
    group = make_group_layer(j, parent, 0, "Sub")
    z = insert_copy(group, group, is_hide=True)
    return parent, group, z


def make_group(maya):
    """
    Make the Accent group layer.

    maya: Maya
    Return: group layer
        specific to Accent
    """
    group = maya.group

    if not group:
        any_group = Helm.get_group(de.BACKGROUND)
        a = get_layer_position(any_group.work.group)
        return make_group_layer(Run.j, None, a, de.ACCENT)
    return group


class Accent(ManyGroup):
    """
    Create Widget group and assign an Accent
    step processor for both view run types.
    """

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)
        self.latch(self, (si.ACCENT_CHANGE, self.work.on_accent_type_change))


class Chi(Maya, Main):
    """Factor Plan and Work."""

    def __init__(self, any_group, view_i, q):
        """
        any_group: AnyGroup
            Accent

        view_i: int
            plan or work; view-type index; 0 or 1

        q: iterable
            layer output function
            the Maya's 'put' attribute
        """
        Maya.__init__(self, any_group, view_i, q, ())
        Main.__init__(self)


class Plan(Chi):
    """Manage Accent layer output for both Draft and Plan views."""
    put = issue_q = ()

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, Plan.put)

    def do(self):
        """There's no output."""
        self.reset_issue()


class Work(Chi):
    """Manage Accent layer output for both Peek and Preview views."""
    issue_q = ()
    put = (make_group, 'group'),
    vote_type = vo.MAIN

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Owns the option.
        """
        self._sub_accent = \
            self._sub_accent_k = \
            self._rendered_sub = \
            self._sub_any_group = None

        Chi.__init__(self, any_group, 1, Work.put)

        self.sub_maya[sm.BULB] = Bulb(any_group, self, de.ACCENT)
        self.option_list = self.any_group.get_widget(de.OPTION_LIST)
        self._sub_any_group = self.option_list.get_sub_any_group()
        g = self.any_group.get_widget(de.SWITCH)
        g.relay.insert(0, self.on_accent_switch)

    def do(self):
        """
        Manage layer output for Accent during a view run.

        d: dict
            Accent Preset
        """
        d = self.value_d = self.any_group.get_value_d()
        self.go = d[de.SWITCH]

        if self._rendered_sub is not self._sub_accent:
            if self._rendered_sub:
                self._rendered_sub.die()

        if self.go:
            self.realize()

            m = self._sub_accent.is_matter

            self._sub_any_group.do(self.group)
            self.sub_maya[sm.BULB].do(m)

        else:
            if self._sub_accent:
                self._sub_accent.die()
            self.die()

        self._rendered_sub = self._sub_accent
        self.reset_issue()

    def get_matter(self):
        """
        Retrieve the SubAccent matter layer. Accent doesn't have
        a matter layer of its own.

        Return: layer or None
        """
        if self._sub_accent:
            return self._sub_accent.matter

    def on_accent_switch(self, *_):
        self.on_accent_type_change(None, self.option_list)

    def on_accent_type_change(self, _, option_list):
        """
        Respond to change in the Accent OptionList's TreeviewList.

        _: AnyGroup
            Sent the Signal.

        option_list: OptionList
            It's value is a sub-Accent key and Preset value dict.
        """
        # SubAccent Preset dict, 'd'
        d = option_list.get_ui()

        # SubAccent name-key, 'k'
        k = get_option_list_key(d)
        if k != self._sub_accent_k:
            self._switch_sub_accent(option_list, k)

    def _switch_sub_accent(self, option_list, k):
        """
        The SubAccent type has changed. Update
        the necessary SubAccent connections.

        option_list: OptionList
            Owns SubAccent Widget.

        k: string
            SubAccent key
        """
        any_group = option_list.get_sub_any_group()
        self._sub_accent_k = k

        # Is there a SubAccent connected at 'work'?
        if any_group.does_work():
            self._sub_any_group = any_group
            self._sub_accent = any_group.work

        else:
            # SubAccent class, 'a'
            a = CLASS_ACCENT.get(k)
            if a:
                self._sub_any_group = any_group

                # Create new SubAccent.
                self._sub_accent = \
                    self._sub_any_group.work = \
                    a(any_group, self._sub_accent is self._rendered_sub)
