#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD,
    CHANNEL_OP_INTERSECT,
    CHANNEL_OP_SUBTRACT,
    CLIP_TO_IMAGE,
    pdb
)
from roller_constant import Frame as ek, Row as rk, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_frame_type import expand_wrap, grow_wrap
from roller_gimp_mode import get_mode
from roller_gegl import emboss
from roller_gimp_selection import select_channel, select_rect
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import add_layer, add_layer_above
from roller_gimp_layer import (
    blur_selection,
    clear_selection,
    color_layer,
    color_selection,
    isolate_channel,
    remove_layer,
    reorder_layer,
    select_layer,
    verify_layer
)
from roller_preset import do_rotated_layer
from roller_gimp_mask import mask_selection


def do_alt_frame(maya):
    """
    Make a frame that has a Filler function and a selection channel.

    maya: Maya
    Return: layer or None
        frame
    """
    d = maya.value_d
    j = Run.j

    # Add a pattern layer to the bottom of the Maya's group layer, 'z'.
    z = add_layer(j, maya.group, maya.get_light(), "Material")

    # selection channel, 'sc'
    remove_sc(maya, 'filler_sc')

    maya.filler_sc = make_filler_frame_sc(j, maya.cast.matter, d)
    z = verify_layer(emboss_selection(z, d))

    if z:
        z.name = z.parent.name + " " + maya.super_maya.kind
    return z


def do_frame_wrap(maya):
    """
    Make a frame around material.

    maya: Maya
    Return: layer
        frame
    """
    j = Run.j
    d = maya.value_d
    group = maya.group

    # layer for the emboss, 'z'
    z = add_layer(j, group, maya.get_light(), "Material")

    select_wrap(j, maya.cast.matter, d[de.WIDTH], d[de.TYPE])
    return emboss_selection(z, d)


def do_frame_with_filler(maya, make_pattern):
    """
    Make a frame that has a Filler.

    maya: Maya
    make_pattern: function
        Make Filler selection.

    Return: layer or None
        frame
    """
    def _draw(_z):
        """
        Return a layer having a pattern fill.

        _z: layer
            Maya matter layer
        """
        return do_rotated_layer(
            filler_d,
            make_pattern,
            maya.group,
            len(maya.group.layers) - 1
        )

    d = maya.value_d
    filler_d = maya.super_maya.value_d[rk.BRW][maya.super_maya.filler_k]
    j = Run.j
    cast_z = maya.cast.matter

    # Add a pattern layer towards the top of the Maya's group layer, 'z'.
    z = add_layer(j, maya.group, maya.get_light(), "Material")

    make_pattern_frame_sc(j, cast_z, d, _draw)
    return emboss_selection(z, d)


def emboss_selection(z, d, is_coloring=True):
    """
    Fill a selection with a color and emboss it.

    z: layer
        to fill
        WIP

    d: dict
        Wrap-type Preset

    is_coloring: bool
        When True, the input layer is colored with COLOR_1.

    Return: layer
        frame
    """
    j = Run.j

    if not pdb.gimp_selection_is_empty(j):
        set_fill_context_default()

        e = d[de.EMBOSS]
        if e[de.SWITCH]:
            n = z.name
            sc = pdb.gimp_selection_save(j)

            if is_coloring:
                color_selection(z, d[de.COLOR_1])

            z1 = add_layer_above(z, "Outside")
            z2 = add_layer_above(z1, "Inside")

            color_selection(z2, (255, 255, 255))
            pdb.gimp_selection_none(j)
            color_layer(z1, (0, 0, 0))

            z1 = pdb.gimp_image_merge_down(j, z2, CLIP_TO_IMAGE)

            blur_selection(z1, e[de.PRE_BLUR])
            emboss(z1, Globe.azimuth, Globe.elevation, int(e[de.DEPTH]))
            blur_selection(z1, e[de.POST_BLUR])

            z1.mode = get_mode(e)

            z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
            z.name = n

            if e[de.CONTRAST]:
                # brightness, '0'
                pdb.gimp_brightness_contrast(z, 0, int(e[de.CONTRAST]))

            isolate_channel(z, sc)
            pdb.gimp_image_remove_channel(j, sc)

        elif is_coloring:
            color_selection(z, d[de.COLOR_1])
    return z


def do_image_selection(maya, do_selection, embellish, n, is_clip=True):
    """
    Process the material for a frame cell-by-cell.
    Each cell that has an image selection is processed
    by loading this selection, then calling a 'do_selection' function,
    and a follow-up 'embellish' function.

    maya: Maya
    do_selection: function
        Process main cast selection on a per item basis,
        or from a Maya having a key (e.g. Canvas branch).

    embellish: function
        Process the material layer.

    n: string
        layer name appendix
        Frame kind
        Prefix with a space character.

    is_clip: bool
        If True, then the cast's alpha selection
        is removed from the output layer.

    Return: layer or None
        frame
    """
    j = Run.j
    model = maya.model
    super_ = maya.cast
    cast = super_.matter
    z = add_layer(j, maya.group, maya.get_light(), n)

    # Check to see if the caller is a main grid, 'main_q'.
    if hasattr(super_, 'main_q'):
        for k in super_.main_q:
            maya.k = k

            select_channel(j, model.get_image_sc(k))

            if cast.mask:
                pdb.gimp_image_select_item(
                    j, CHANNEL_OP_INTERSECT, cast.mask
                )
            if not pdb.gimp_selection_is_empty(j):
                z = do_selection(maya, z)

    else:
        maya.k = super_.k

        select_layer(cast)
        if not pdb.gimp_selection_is_empty(j):
            z = do_selection(maya, z)

    if is_clip:
        select_layer(cast)
        clear_selection(z)

    z = verify_layer(z)

    if z:
        z = embellish(maya, z)
        z.name = z.parent.name + " " + n
    return z


def make_canvas_frame_sc(maya, z, d):
    """
    Make a selection border around the render.

    maya: Maya
        Has a 'model' attribute.

    z: dict
        cast layer
        Subtract its selection from the canvas frame.

    d: dict
        a Frame-type Preset

    Return: GIMP selection or None, state of selection
        canvas border
    """
    w = d[de.CFW]
    if w:
        j = Run.j
        x, y, w1, h = maya.model.canvas_rect
        select_rect(j, x, y, w1, h)
        select_rect(
            j,
            x + w, y + w,
            w1 - w - w, h - w - w,
            option=CHANNEL_OP_SUBTRACT
        )
        select_layer(z, option=CHANNEL_OP_SUBTRACT)
        return pdb.gimp_selection_save(j)


def make_filler_frame_sc(j, z, d):
    """
    Make a selection for a frame having Filler material.

    j: GIMP image
        view output

    d: dict
        Wrap Preset

    Return: GIMP selection channel and GIMP's state of selection
        state of selection: the wrap
        filler selection
    """
    n = d[de.TYPE]
    a = d[de.FILLER_W]
    w = d[de.WIDTH]
    is_inward = n in ek.INWARD_SET

    select_wrap(j, z, w, n)

    inner = pdb.gimp_selection_save(j)

    # Make a bubble.
    select_layer(z, option=CHANNEL_OP_ADD)

    inner1 = pdb.gimp_selection_save(j)

    expand_wrap(j, z, a, n)
    select_channel(j, inner, option=CHANNEL_OP_SUBTRACT)

    # Is still bubble.
    filler1 = pdb.gimp_selection_save(j)

    select_channel(j, inner1, option=CHANNEL_OP_ADD)  # Grow outward only.
    expand_wrap(j, z, w, n)
    select_channel(j, filler1, option=CHANNEL_OP_SUBTRACT)

    # Is frame ready.
    outer = pdb.gimp_selection_save(j)

    # Make an inner Wrap selection.
    # Combine selections.
    select_channel(j, inner)
    select_channel(j, outer, option=CHANNEL_OP_ADD)

    # Clean up.
    for i in (inner, inner1, outer):
        pdb.gimp_image_remove_channel(j, i)
    return filler1


def make_pattern_frame_sc(j, z, d, p):
    """
    Make a selection for frame material.

    j: GIMP image
        Has frame.

    z: layer
        Maya matter

    d: dict
        Frame-type Preset

    p: function
        Make the pattern.

    Return: GIMP selection channel and GIMP's state of selection
        state of selection: the wrap
    """
    filler = make_filler_frame_sc(j, z, d)
    wrap = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)

    z1 = p(z)

    select_channel(j, filler)
    select_layer(z1, option=CHANNEL_OP_INTERSECT)
    remove_layer(z1)
    select_channel(j, wrap, option=CHANNEL_OP_ADD)

    # Clean up.
    for i in (filler, wrap):
        pdb.gimp_image_remove_channel(j, i)


def mask_filler_layer(j, filler, sc):
    """
    Mask a Filler matter from a selection channel created by a frame.

    j: GIMP image
        Receive selection.

    filler: Filler
        Has Filler and group layer.

    sc: selection channel
        Make into mask for the 'filler.matter'.
    """
    if sc:
        select_channel(j, sc)
        mask_selection(filler.matter)


def remove_sc(maya, n):
    """
    Remove a Mayan selection channel.

    maya: Maya
    n: string
        Is the selection channel's attribute descriptor.
    """
    a = getattr(maya, n)
    if a:
        pdb.gimp_image_remove_channel(Run.j, a)
        setattr(maya, n, None)


def select_wrap(j, z, w, n):
    """
    Make a Wrap selection around a layer's alpha.

    j: GIMP image
        Has selection.

    z: layer
        Surround material with Wrap.

    w: float
        Expand selection.

    n: string
        Wrap/Type
    """
    f = z.opacity
    z.opacity = 100.

    select_layer(z)
    grow_wrap(j, z, w, n)
    z.opacity = f


def sort_shadow_layer(maya, m, offset, z):
    """
    Sort Shadow layer inside a Shadow group layer.

    maya: Maya
        Has Shadow sub-maya.

    m: bool
        If True then sort the Shadow layers.

    offset: int
        Inner Shadow position

    z: layer
        Cast Shadow.
    """
    if m and z:
        # Move and sort Shadow layer to the group layer.
        # This is the layer order in the group layer:
        #    Shadow #2
        #    Shadow #1
        j = Run.j
        a = pdb.gimp_image_get_item_position(j, z) + 1
        e = maya.sub_maya[sm.SHADOW].sub_maya
        z1 = z.parent

        # an ordered list of Shadow 'matter' layer, 'q'
        q = [e[i].matter for i in (sm.SHADOW2, sm.SHADOW1)]

        for i in q:
            a += reorder_layer(j, i, z1, a)

        z = maya.sub_maya[sm.SHADOW].sub_maya[sm.INSET].matter
        if z:
            reorder_layer(j, z, z1, offset)
