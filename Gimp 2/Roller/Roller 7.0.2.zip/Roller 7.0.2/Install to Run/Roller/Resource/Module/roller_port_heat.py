#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_container import Dog
from roller_constant import Define as df
from roller_constant_identity import Identity as de
from roller_port_preview import PortPreview
from roller_widget_button import (
    AcceptButton,
    CancelButton,
    PlanButton,
    PreviewButton,
    RandomButton
)
from roller_widget_dna import DNA
from roller_widget_heat import HeatTable
from roller_widget_row import WidgetRow


class PortHeat(PortPreview):
    """Edit the Heat Preset."""
    window_key = "Heat"

    def __init__(self, d, g):
        """
        d: dict
            Initialize Port.

        g: OptionButton
            Is responsible.
        """
        self._heat_table = None
        PortPreview.__init__(self, d, g)

    def draw_heat(self, box):
        """
        Draw the Heat option group.

        box: VBox
            Contain Widget.
        """
        dna = DNA(de.HEAT, {'make_vbox'}, {})

        dna.inherit(self.repo.any_group.dna, True)
        box.add(dna.vbox)

        d = {
            df.COLOR: self.color,
            df.DNA: dna,
            df.KEY: self.repo.key,
            df.RELAY: [self.on_port_change],
            df.ROLLER_WIN: self.roller_win,
            df.ROW_KEY: None
        }
        self.any_group = d[df.ANY_GROUP] = Dog.none_group(**d)
        self._heat_table = HeatTable(**d)
        self._heat_table.load_a(self.repo.get_a())

    def draw(self):
        """Draw Widget."""
        self.draw_column((self.draw_heat, self.draw_heat_process))

    def draw_heat_process(self, vbox):
        """
        Draw a group of process Button.

        vbox: GTK container
            Receive Widget group.
        """
        g = WidgetRow(
            **{
                df.ANY_GROUP: self.any_group,
                df.PADDING: (0, 0, 4, 4),
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win,
                df.SUB: OrderedDict([
                    (de.CANCEL, {df.WIDGET: CancelButton}),
                    (de.RANDOM, {df.WIDGET: RandomButton}),
                    (de.PLAN, {df.WIDGET: PlanButton}),
                    (de.PREVIEW, {df.WIDGET: PreviewButton}),
                    (de.ACCEPT, {df.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        vbox.add(g)

    def get_group_value(self):
        """
        Fetch the Heat Table value.

        Return: dict
            Heat Preset
        """
        return self._heat_table.get_ui()
