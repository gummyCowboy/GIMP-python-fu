#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Are supplemental class module with a two letter import variable
# that are unique in the context of the program.
from roller_constant_identity import Identity as de
import gobject  # type: ignores
import gtk      # type: ignore

_MESH_TYPE_LIST = de.SQUARE, de.HEXAGON, de.OCTAGON, de.TRIANGLE
LIST_SEPARATOR = "@"
MAX_SIZE = 524288
MAX_SIZE_F = 524288.
SCROLL_SPAN = 22


class Accent:
    """Import as 'by'."""
    ACCENT_TYPE_LIST = de.COLOR, de.MEAN_COLOR, de.RANDOM_COLOR
    CLOCKWISE, COUNTER_CLOCKWISE = 0, 1
    KEY_LIST = (
        de.ACRYLIC_SKY, de.BACK_GAME,
        de.CLAY_CHEMISTRY, de.COLOR_FILL,
        de.COLOR_GRID, de.CORNER_OVERLAP, de.CRYSTAL_CAVE,
        de.CUBE_PATTERN, de.CUBISM_COVER,
        de.DARK_FORT, de.DENSITY_GRADIENT,
        de.DROP_ZONE, de.ETCH_SKETCH,
        de.FADING_MAZE, de.FLOOR_SAMPLE,
        de.GALACTIC_FIELD, de.GLASS_GAW,
        de.GRADIENT_FILL,  de.GRATE_MYSTERY,
        de.HISTORIC_TRIP, de.LINE_STONE,
        de.LOST_MAZE, de.MAZE_BLEND,
        de.MEAN_COLOR, de.NOISE_RIFT, de.PAPER_WASTE,
        de.PATTERN_FILL, de.RAINBOW_VALLEY,
        de.RECT_PATTERN, de.ROCKY_LANDING,
        de.ROOF_TOP, de.SOFT_TOUCH,
        de.SPECIMEN_SPECKLE, de.SPIRAL_CHANNEL,
        de.SQUARE_CLOUD, de.STONE_AGE,
        de.TRAIL_VINE, de.TRIANGLE_REVERB, de.WAVE_FILL
    )
    MESH_TYPE_LIST = _MESH_TYPE_LIST   # Mesh Type is Enum ordered.
    NEWS_TYPE_LIST = (
        de.DOT, de.LINE, de.DIAMOND, de.EUCLIDEAN_DOT, de.PS_DIAMOND
    )
    REVERB_TYPE_LIST = (
        de.MEAN_COLOR,
        de.RED,
        de.GREEN,
        de.BLUE,
        de.PATTERN,
        de.COLOR,
        de.RANDOM_COLOR
    )
    SHIFT_DIRECTION_LIST = de.VERTICAL, de.HORIZONTAL
    SPIRAL_MOD_LIST = (
        "None", de.HORIZONTAL_FLIP, de.VERTICAL_FLIP, de.FLIP_BOTH
    )
    WAVE_FILL_TYPE = de.ALTERNATE, de.COLOR, de.MEAN_COLOR, de.RANDOM_COLOR


class Background:
    """Import as 'ba'."""
    TYPE_LIST = (
        de.EMPTY,
        de.CLOUDS,
        de.COLOR,
        de.GRADIENT,
        de.IMAGE,
        de.PATTERN,
        de.PLASMA
    )


class Below:
    """Import as 'be'."""
    TYPE_LIST = de.MASK, de.INVERT_MASK, de.NO_MASK


class Blur:
    """Import as 'bu'."""
    TYPE_LIST = de.GAUSSIAN, de.MEDIAN


class Bump:
    """Import as 'fb'."""
    TYPE_LIST = de.CLOTH, de.CROSSHATCH, de.EDGE, de.NANO, de.NOISE


class Color:
    """Import as 'co'."""
    COMPONENT_LIST = de.RED, de.GREEN, de.BLUE
    MAX_COLOR = 65535

    # colored button
    ACTIVE_COLOR = gtk.gdk.Color(55000, 55000, 0)
    CELL_COLOR = gtk.gdk.Color(55000, 55000, MAX_COLOR)
    CONNECTOR_COLOR = gtk.gdk.Color(52000, 52000, MAX_COLOR)
    CONNECTED_COLOR = gtk.gdk.Color(MAX_COLOR, 0, 0)
    FOCUS_COLOR = gtk.gdk.Color(50000, 44000, MAX_COLOR)

    HEADER_COLOR = 44000, 44000, MAX_COLOR
    LIST_CELL_COLOR = gtk.gdk.Color(61000, 61000, 49000)
    WHITE = gtk.gdk.Color(MAX_COLOR, MAX_COLOR, MAX_COLOR)
    MISSING_FILE = gtk.gdk.Color(MAX_COLOR, MAX_COLOR, MAX_COLOR // 2)

    # GTK Box
    COLOR_DEC = 1900
    INIT_COLOR = MAX_COLOR - COLOR_DEC

    # Correct JSON tuple to list conversion.
    SINGLE_COLOR_SET = {de.COLOR, de.COLOR_1, de.COLOR_1A}
    MULTI_COLOR_SET = {
        de.COLOR_2,
        de.COLOR_2A,
        de.COLOR_3,
        de.COLOR_3A,
        de.COLOR_6,
        de.COLOR_6A
    }


class Deco:
    """Has values used by Plaque, Fringe, Border and Line. Import as 'dc'."""
    COLORING_SET = {de.COLOR, de.MEAN_COLOR, de.RANDOM_COLOR}
    FACIAL_SET = {de.FACE, de.FACING}
    FRINGE_PER_SET = {
        de.GRADIENT, de.IMAGE, de.MEAN_COLOR, de.MULTI_COLOR, de.RANDOM_COLOR
    }
    CELL_MARGIN_CALC_SET = {de.CELL, de.FACE}
    PER_TYPE_SET = {de.GRADIENT, de.IMAGE, de.MEAN_COLOR, de.RANDOM_COLOR}
    NO_APPLY_SET = {de.AS_IS, de.MULTI_COLOR, de.RANDOM_COLORS}
    ONE_IMAGE_TYPE_SET = {de.TAB, de.FILE}
    TYPE_LIST = [
        de.CLOUDS,
        de.COLOR,
        de.GRADIENT,
        de.GRID,
        de.IMAGE,
        de.MEAN_COLOR,
        de.PATTERN,
        de.PLASMA,
        de.RANDOM_COLOR
    ]
    FRINGE_TYPE_LIST = [de.AS_IS] + TYPE_LIST
    FRINGE_TYPE_LIST.insert(6, de.MULTI_COLOR)
    FRINGE_TYPE_LIST.append(de.RANDOM_COLORS)


class Define:
    """
    Are Preset definition dict key.

    Import as 'df'.
    """
    # tuple of float
    # in .0 to 1.
    # a factor of the space to assign
    # for top, bottom, left, right
    ALIGN = 'align'

    # AnyGroup
    # Use to connect widgets with other widget in their group.
    ANY_GROUP = 'any_group'

    # string
    # Identify the render scale axis as either 'x' or 'y'
    # for RenderPair
    AXIS = 'axis'

    # of gtk.Box classes
    BOX = 'box'

    # int
    # Use with the Rainbow Widget or the Radio Widget.
    # Is the number of ColorButtons in the Rainbow Widget.
    # Is the number of Radio Buttons in the Radio group.
    BUTTON_COUNT = 'button_count'

    # a 2D list from Cell Table to its SwitchButton
    CELL_TABLE = 'cell_table'

    # Use with Entry's string length allocation.
    CHARS = 'chars'

    # string
    # Use with the Choice Window.
    CHOICE = 'choice'

    # int
    # Give to Event boxes.
    COLOR = 'color'

    # string
    # Make the ColorButton's tooltip more descriptive.
    COLOR_NAME = 'color_name'

    # iterable
    # Provide Rainbow with ColorButton COLOR_NAME.
    COLOR_NAME_LIST = 'color_name_list'

    # int
    # a Node's cubby index
    COLUMN = 'column'

    # string
    # for a Widget Table
    # Is a label string for the left-side of a Table.
    COLUMN_TEXT = 'column_text'

    # GTK container
    CONTAINER = 'container'

    # class
    # type of Window
    DIALOG = 'dialog'

    # DNA
    # Populate the interface with Preset, Node, and SuperPreset items.
    DNA = 'dna'

    # Call to get a value for a Widget range.
    FUNCTION = 'function'

    # function
    # Call to get the value of a widget.
    GET_A = 'get_a'

    # Is Widget with the proper get_a and set_a function.
    GREATER_G = 'greater_g'

    # GTK Window or Dialog
    GTK_WIN = 'gtk_win'

    # boolean
    # for ColorButton
    # When its true, the ColorButton has an alpha value.
    HAS_ALPHA = 'has_alpha'

    # boolean
    # When True, an AnyGroup has a Randomize button.
    HAS_RANDOM = 'has_random'

    # string
    # Is an optional header for a TreeViewList.
    HEADER = 'header'

    # bool
    # Identify a Face. Used by PortPer and PortCellEditor.
    IS_FACE = 'is_face'

    # bool
    # Set to True to have AnyGroup skip Widget creation.
    IS_NONE = 'is_none'

    # string
    # Identify layer dependency type.
    ISSUE = 'issue'

    # string
    # option group
    KEY = 'key'

    # int
    # Use when creating a RadioButton.
    LABEL_I = 'label_i'

    # text
    # Give Combo a Label tooltip.
    LABEL_TIP = 'label_tip'

    # tuple
    # low, high
    # limit self value range of a Slider
    LIMIT = 'limit'

    # int
    # Set the minimum width of a TreeViewList column.
    MINIMUM_W = 'minimum_w'

    # string
    # Identify an AnyGroup's Preset.
    # path of 'node-label.leaf-label'
    NAME_STEP_K = 'name_step_k'

    # function
    # a callback for an Accept Button
    ON_ACCEPT = 'on_accept'

    # function
    # a callback for a Cancel Button
    ON_CANCEL = 'on_cancel'

    # function
    # Is a callback for a ProcessButton override.
    ON_DIALOG_CLOSE = 'on_dialog_close'

    # tuple
    # Alignment padding
    PADDING = 'padding'

    # numeric value
    # Initialize a Slider's GTK Adjustment.
    PAGE_INCR = 'page_incr'

    # int
    # number of digits after the decimal point
    # Is zero for an integer.
    PRECISION = 'precision'

    # RadioButton
    # RadioButton for a group of RadioButtons.
    RADIO_GROUP = 'radio_group'

    # tuple
    # Define a random-function limitation.
    RANDOM_Q = 'random_q'

    # tuple
    # (row, column) cell index; Goo key
    R_C = 'r_c'

    # list of function
    # Notify listener on option change.
    RELAY = 'relay'

    # Window class instance
    ROLLER_WIN = 'roller_win'

    # string
    # Is a key for an sub-dict in a Preset.
    ROW_KEY = 'row_key'

    # RowList
    # RowButton calls with a RowList.
    ROW_LIST = 'row_list'

    # undefined
    # Pass to a TreeViewList to have it make a scrolled window.
    SCROLL = 'scroll'

    # function
    # Call to set the value of a widget.
    SET_A = 'set_a'

    # custom Widget Signal
    # Use to pass a custom signal to a Widget.
    SIGNAL = 'signal'

    # numeric value
    # Use with Slider to initialize the GTK SpinButton.
    STEP_INCR = 'step_incr'

    # None value
    # Identify an option or Preset as not having a stored value.
    NO_VOTE = 'no_value'

    # dict
    # Widget definition group
    SUB = 'sub'

    # string
    # for CheckButton, Label
    TEXT = 'text'

    # function
    # Use to make a tooltip.
    TIP_P = 'tip_p'

    # tuple
    # Use to set multiple tooltips.
    TIPS = 'tips'

    # string
    # for a tooltip
    TOOLTIP = 'tooltip'

    # color
    # Use to set the background color of a TreeView.
    TREE_COLOR = 'tree_color'

    # set
    # Initialize DNA true attribute.
    TRUE_ATTR = 'true_attr'

    # string
    # Pass the step-key during init.
    TYPE_STEP_K = 'type_step_k'

    # value
    # Initialize a Widget's value.
    VALUE = 'value'

    # Set a Widget class.
    WIDGET = 'widget'

    # list
    # [Widget arg, ...]
    # Define Widget for 'create_table'.
    WIDGET_LIST = 'widget_list'

    # string
    # Use to pass a Window's key for storage in the Window position dict.
    WINDOW_KEY = 'window_key'

    # Use when initializing a Widget-type
    # to set a Widget attribute.
    ATTRIBUTE_SET = {
        ALIGN,
        ANY_GROUP,
        COLUMN,
        DIALOG,
        FUNCTION,
        KEY,
        RANDOM_Q,
        ROLLER_WIN,
        ROW_KEY,
        TEXT
    }


class Fill:
    """Import as 'fl'."""
    CRITERION_LIST = (
        de.COMPOSITE,
        de.RED,
        de.GREEN,
        de.BLUE,
        de.HUE,
        de.SATURATION,
        de.VALUE,
        de.ALPHA,
        de.LCH_LIGHTNESS,
        de.LCH_CHROMA,
        de.LCU_HUE
    )


class Frame:
    """Import as 'ek'."""
    KEY_LIST = (
        de.BASIC, de.BEVEL,
        de.BRUSHY, de.BURST,
        de.CAMO, de.CERAMIC, de.CHECKER,
        de.CLEAR, de.CRUMBLE,
        de.DECAY, de.FENCE,
        de.GLUE, de.GRADUAL,
        de.HOLEY, de.JOINT, de.MAZE,
        de.MECHA, de.MIRROR, de.NET,
        de.OVER, de.OVERLAP,
        de.PIPE, de.RAD,
        de.STAINED, de.STRETCH,
        de.STRIPE, de.TAPE,
        de.WOBBLE
    )
    DECO_KEY_LIST = list(KEY_LIST)

    for _ in (
        de.BEVEL, de.BURST, de.JOINT, de.NET, de.OVER, de.OVERLAP, de.TAPE
    ):
        DECO_KEY_LIST.pop(DECO_KEY_LIST.index(_))

    DECAY_TYPE_LIST = (
        de.WHITE_SOFT,
        de.WHITE_MIXED,
        de.WHITE_HARD,
        de.GREY_SOFT,
        de.GREY_MIXED,
        de.GREY_HARD
    )

    # Frame Type
    INWARD_SET = {de.OVERLAP, de.INSIDE}

    # dependent
    CAMO_TYPE_LIST = (
        de.COMPOSITE, de.GREEN, de.RED, de.BLUE, de.AQUA, de.PURPLE, de.YELLOW
    )
    COMPONENT_DICT = {
        de.BLUE: (.0, 1., .0, .25),
        de.AQUA: (.0, 1., 1., 1.),
        de.PURPLE: (1., 1., .0, .25),
        de.COMPOSITE: (1., 1., 1., 1.),
        de.GREEN: (.0, .0, 1., 1.),
        de.YELLOW: (1., .0, 1., .5),
        de.RED: (1., .0, .0, .5)
    }
    MESH_TYPE_LIST = _MESH_TYPE_LIST
    OVERLAY_TYPE_LIST = (
        de.CLOUDS, de.COLOR, de.GRADIENT, de.IMAGE, de.PATTERN, de.PLASMA
    )
    PROFILE_LIST = de.BAND, de.BEVEL, de.RAISE, de.ROUND, de.SINK
    WRAP_TYPE_LIST = (
        de.ANGULAR, de.INSIDE, de.OVERLAP, de.RECTANGLE, de.ROUNDED
    )


class Gradient:
    """Import as 'fg'."""
    GRADIENT_ANGLE_LIST = (
        de.CENTER_TO_BOTTOM_CENTER,
        de.CENTER_TO_CENTER_LEFT,
        de.CENTER_TO_CENTER_RIGHT,
        de.CENTER_TO_TOP_CENTER,
        de.TOP_LEFT_TO_BOTTOM_RIGHT,
        de.TOP_CENTER_TO_BOTTOM_CENTER,
        de.TOP_RIGHT_TO_BOTTOM_LEFT,
        de.BOTTOM_LEFT_TO_TOP_RIGHT,
        de.BOTTOM_CENTER_TO_TOP_CENTER,
        de.BOTTOM_RIGHT_TO_TOP_LEFT,
        de.CENTER_LEFT_TO_CENTER_RIGHT,
        de.CENTER_RIGHT_TO_CENTER_LEFT
    )

    # Translate a gradient angle into x, y factor pairs.
    # The key is a gradient angle.
    # The value is a tuple: (start x, end x, start y, end y) of factor values.
    GRADIENT_XY_DICT = {
        de.CENTER_LEFT_TO_CENTER: (.5, .0, .5, .5),
        de.CENTER_RIGHT_TO_CENTER: (.5, 1., .5, .5),
        de.CENTER_TO_BOTTOM_CENTER: (.5, .5, .5, 1.),
        de.CENTER_TO_CENTER_LEFT: (.5, .0, .5, .5),
        de.CENTER_TO_CENTER_RIGHT: (.5, 1., .5, .5),
        de.CENTER_TO_TOP_CENTER: (.5, .5, .5, .0),
        de.TOP_LEFT_TO_BOTTOM_RIGHT: (.0, 1., .0, 1.),
        de.TOP_CENTER_TO_BOTTOM_CENTER: (.5, .5, .0, 1.),
        de.TOP_RIGHT_TO_BOTTOM_LEFT: (1., .0, .0, 1.),
        de.BOTTOM_LEFT_TO_TOP_RIGHT: (.0, 1., 1., .0),
        de.BOTTOM_CENTER_TO_TOP_CENTER: (.5, .5, 1., .0),
        de.BOTTOM_RIGHT_TO_TOP_LEFT: (1., .0, 1., .0),
        de.CENTER_LEFT_TO_CENTER_RIGHT: (.0, 1., .5, .5),
        de.CENTER_RIGHT_TO_CENTER_LEFT: (1., .0, .5, .5)
    }

    GRADIENT_TYPE_LIST = (
        de.LINEAR,
        de.BILINEAR,
        de.RADIAL,
        de.SQUARE,
        de.CONICAL_SYMMETRIC,
        de.CONICAL_ASYMMETRIC,
        de.SHAPED_ANGULAR,
        de.SHAPED_DIMPLED,
        de.SHAPED_SPHERICAL,
        de.SPIRAL_CLOCKWISE,
        de.SPIRAL_COUNTER_CW
    )
    SHAPED_TYPE_LIST = (
        de.SHAPED_ANGULAR, de.SHAPED_DIMPLED, de.SHAPED_SPHERICAL
    )

    # light angle
    LEFT_GRADIENT_ANGLE = {
        de.BOTTOM_LEFT_TO_TOP_RIGHT,
        de.CENTER_LEFT_TO_CENTER,
        de.CENTER_LEFT_TO_CENTER_RIGHT,
        de.TOP_LEFT_TO_BOTTOM_RIGHT
    }
    RIGHT_GRADIENT_ANGLE = {
        de.BOTTOM_RIGHT_TO_TOP_LEFT,
        de.CENTER_RIGHT_TO_CENTER,
        de.CENTER_RIGHT_TO_CENTER_LEFT,
        de.TOP_RIGHT_TO_BOTTOM_LEFT
    }
    TOP_GRADIENT_ANGLE = {
        de.CENTER_TO_BOTTOM_CENTER,
        de.TOP_CENTER_TO_BOTTOM_CENTER,
        de.TOP_LEFT_TO_BOTTOM_RIGHT,
        de.TOP_RIGHT_TO_BOTTOM_LEFT
    }
    BOTTOM_GRADIENT_ANGLE = {
        de.BOTTOM_CENTER_TO_TOP_CENTER,
        de.BOTTOM_LEFT_TO_TOP_RIGHT,
        de.BOTTOM_RIGHT_TO_TOP_LEFT,
        de.CENTER_TO_TOP_CENTER
    }


class Grid:
    """Has values used by a Cell/Type option group. Import as 'gr'."""
    COUNT_SET = {de.CELL_COUNT, de.SHAPE_COUNT}
    PIN_LIST = (
        de.CENTER, de.CENTER_LEFT, de.CENTER_RIGHT,
        de.TOP_CENTER, de.TOP_LEFT, de.TOP_RIGHT,
        de.BOTTOM_CENTER, de.BOTTOM_LEFT, de.BOTTOM_RIGHT
    )
    TYPE_LIST = de.CELL_COUNT, de.CELL_SIZE, de.SHAPE_COUNT


class Image:
    """Import as 'fi'."""
    LOOP = 'loop'
    LOOP_DICT = 'loop_dict'
    NEXT = 'next'
    NEXT_DICT = 'next_dict'
    PREVIOUS = 'previous'
    PREVIOUS_DICT = 'previous_dict'
    SLICE = 'slice'

    # Use with the file selector as a filter.
    EXTENSION_LIST = (
        ".avif", ".avifs",
        ".xcf",
        ".jpg", ".jpeg", ".jpe", ".jif", ".jfif", ".jfi",
        ".png",
        ".gif", ".webp",
        ".tiff", ".tif",
        ".ps", ".psd",
        ".raw", ".rw2", ".arw", ".cr2", ".cr3", ".crw", ".nrw", ".k25",
        ".bmp", ".dib",
        ".jp2", ".j2k", ".jpx", ".jpm", ".mj2",
        ".ico",
        ".svg",
        ".pdf", ".mng", ".pcx", ".pcc", ".xpm",
        ".pix", ".matte", ".mask", ".alpha", ".als",
        ".fli", ".flc",
        ".xcf.bz2", ".xcfbz2",
        ".dds",
        ".dcm", ".dicom",
        ".hgt",
        ".eps",
        ".fit", ".fits",
        ".g3",
        ".gbr", ".gbp",
        ".gih",
        "xcf.gz.xcfgz",
        ".heic.heif.avif",
        ".j2c", ".jpc",
        ".jxl",
        ".cel",
        ".wmf", ".apm",
        ".ora",
        ".psp", ".tub", ".pspimage",
        ".pnm", ".ppm", ".pgm", ".pbm", ".pfm",
        ".hdr",
        ".dng",
        ".qtk",
        ".ari",
        ".bay",
        ".rdc",
        ".erf",
        ".raf",
        ".3fr", ".fff",
        ".data",
        ".dc2", ".dcr", ".kdc", ".kc2",
        ".mos",
        ".rwl",
        ".pxn",
        ".mef",
        ".mdc", ".mnw",
        ".orf",
        ".pef",
        ".cine", ".cin",
        ".cap", ".iiq",
        ".snw",
        ".x3f",
        ".srf", ".sr2",
        ".sgi", ".rgb", ".rgba", ".bw", ".icon",
        ".im1", ".im8", ".im24", ".im32", ".rs", ".ras", ".sun",
        ".tga", ".vda", ".icb", ".vst",
        ".xwd", ".bitmap",
        ".xcf.xz", ".xcfxz"
    )

    FOLDER_ORDER_LIST = "Ascending (A to Z)", "Descending (Z to A)"
    IMAGE_TYPE_LIST = (
        de.FILE,
        de.FOLDER,
        de.IMAGE_NAME,
        de.LOOP,
        de.NEXT,
        de.PREVIOUS,
        de.RANDOM,
        de.TAB
    )
    LAYER_ORDER_LIST = "Bottom-Up", "Top-Down"
    LOAD_ERR = \
        "Roller tried to load an image file:\n'{}'\n and an error occurred."
    LOOP_TYPE_LIST = de.LOOP_PLUS, de.LOOP_MINUS   # index-ordered
    READ_ERR = "Roller tried to read from a" \
        " folder:\n'{}'\n and an error occurred."
    SLICE_ORDER_LIST = "Topleft to Bottom-Right", "Bottom-Right to Topleft"


class Issue:
    """Identify output change-type. Double as a key. Import as 'vo'."""
    EMBOSS = 'emboss'
    MAIN = 'main'
    MATTER = 'matter'
    MODE = 'mode'
    OPACITY = 'opacity'
    NO_VOTE = 'NO'
    NULL = 'null'
    PER = 'per'
    SEED = 'seed'
    SWITCHED = 'switched'
    PLAN_LIST = 'image', MATTER, SWITCHED
    PLAN_PER_LIST = MATTER, PER, SWITCHED
    WORK_LIST = MATTER, MODE, OPACITY
    WORK_PER_LIST = MATTER, MODE, OPACITY, PER


class Justification:
    """Import as 'ju'."""
    TYPE_LIST = (
        de.CENTER,
        de.TOP_LEFT,
        de.TOP_CENTER,
        de.TOP_RIGHT,
        de.LEFT_CENTER,
        de.RIGHT_CENTER,
        de.BOTTOM_LEFT,
        de.BOTTOM_CENTER,
        de.BOTTOM_RIGHT
    )
    BOTTOM_SET = {de.BOTTOM_CENTER, de.BOTTOM_LEFT, de.BOTTOM_RIGHT}
    CENTER_X_SET = {de.BOTTOM_CENTER, de.CENTER, de.TOP_CENTER}
    CENTER_Y_SET = {de.CENTER, de.LEFT_CENTER, de.RIGHT_CENTER}
    LEFT_SET = {de.BOTTOM_LEFT, de.LEFT_CENTER, de.TOP_LEFT}
    RIGHT_SET = {de.BOTTOM_RIGHT, de.RIGHT_CENTER, de.TOP_RIGHT}
    TOP_SET = {de.TOP_CENTER, de.TOP_LEFT, de.TOP_RIGHT}


class Light:
    """Import as 'ig'."""
    TYPE_LIST = (
        de.CLOUDS,
        de.COLOR,
        de.GRADIENT,
        de.IMAGE,
        de.PATTERN,
        de.PLASMA
    )


class Mask:
    """Import as 'ms'."""
    CORNER_TYPE_LIST = (
        de.CUT_CORNER, de.ELLIPSE_NOTCH, de.RECTANGLE_NOTCH, de.ROUNDED_CORNER
    )
    HEXAGON_TYPE_LIST = (
        de.HEXAGON,
        de.HEXAGON_SHEAR,
        de.HEXAGON_TRUNCATED,
        de.HEXAGON_TRUNCATED_SHEAR
    )
    OCTAGON_TYPE_LIST = (
        de.OCTAGON,
        de.OCTAGON_SHEAR,
        de.OCTAGON_ON_ITS_SIDE,
        de.OCTAGON_ON_ITS_SIDE_SHEAR
    )
    RECTANGLE_TYPE_LIST = (de.MITER_SQUARE, de.RECTANGLE, de.SQUARE)
    TRIANGLE_TYPE_LIST = (
        de.TRIANGLE_BOTTOM_LEFT,
        de.TRIANGLE_BOTTOM_RIGHT,
        de.TRIANGLE_DOWN_REGULAR,
        de.TRIANGLE_DOWN_SHEAR,
        de.TRIANGLE_LEFT_REGULAR,
        de.TRIANGLE_LEFT_SHEAR,
        de.TRIANGLE_RIGHT_REGULAR,
        de.TRIANGLE_RIGHT_SHEAR,
        de.TRIANGLE_TOPLEFT,
        de.TRIANGLE_TOP_RIGHT,
        de.TRIANGLE_UP_REGULAR,
        de.TRIANGLE_UP_SHEAR
    )
    TYPE_LIST = [
        de.CIRCLE,
        de.CORNER,
        de.DARKS,
        de.DIAMOND,
        de.ELLIPSE,
        de.EYE,
        de.EYE_OPENING,
        de.FRINGE,
        de.GRADIENT,
        de.HEXAGON,
        de.IMAGE,
        de.LIGHTS,
        de.OCTAGON,
        de.OPAQUE,
        de.PARALLELOGRAM_LEFT,
        de.PARALLELOGRAM_RIGHT,
        de.RECTANGLE,
        de.RIP,
        de.TEXT,
        de.TRIANGLE
    ]
    FACE_TYPE_LIST = TYPE_LIST[:]
    for _ in (de.DARKS, de.LIGHTS):
        FACE_TYPE_LIST.pop(FACE_TYPE_LIST.index(_))


class Material:
    """Identify a Heat Preset option. Import as 'ma'."""
    _ = set()

    _.update(Accent.KEY_LIST)
    _.update(Frame.KEY_LIST)
    _.update((
        de.ACCENT,
        de.BACKGROUND,
        de.BORDER,
        de.CAPTION,
        de.FRINGE,
        de.IMAGE,
        de.LINE,
        de.PLAQUE,
        de.STRIP
    ))

    for k in (de.CERAMIC, de.STAINED, de.STRETCH):
        _.update(("{} Filler".format(k),))
    KEY_LIST = sorted(list(_))


class Model:
    """Import as 'md'."""
    # Are model that have only one cell.
    ONE_CELL_SET = {de.CELL, de.STACK}


class Node:
    """Import as nw."""
    SELECTED_ROW = 'selected_row'


class NodePanel:
    """Import as np."""
    # main window's panel  or a dialog (Shadow)
    MAIN, SUB = range(2)


class Noise:
    """Import as ni."""
    NOISE_TYPE_LIST = de.DRIP, de.INK, de.RIFT, de.SPECK, de.WATER


# Plan_________________________________________________________________________
class Plan:
    """Import as 'ak'."""
    KEY_LIST = (
        de.BORDER,
        de.CAPTION,
        de.CELL_SHAPE,
        de.CORNER,
        de.DIMENSION,
        de.FRINGE,
        de.GRID,
        de.IMAGE,
        de.LINE,
        de.MARGIN,
        de.NAME,
        de.PLAQUE,
        de.POSITION,
        de.RATIO
    )

    # Items are:
    #   RGB
    #   Plan output color
    #   in layer z-order, bottom to top
    attr_q_ = (
        'CANVAS_LINE_COLOR',
        'CANVAS_MARGIN_COLOR',
        'CANVAS_PLAQUE_COLOR',
        'CANVAS_FRINGE_COLOR',
        'CANVAS_BORDER_COLOR',
        'CANVAS_LINE_COLOR',
        'CANVAS_STRIP_COLOR',
        'GRID_COLOR',
        'SHAPE_COLOR',
        'CELL_MARGIN_COLOR',
        'CELL_PLAQUE_COLOR',
        'CELL_FRINGE_COLOR',
        'CELL_BORDER_COLOR',
        'CELL_LINE_COLOR',
        'CELL_STRIP_COLOR',
        'FACE_PLAQUE_COLOR',
        'FACE_FRINGE_COLOR',
        'FACE_BORDER_COLOR',
        'FACE_LINE_COLOR',
        'FACE_STRIP_COLOR'
    )

    # {PlanOption Widget key: its GObject signal}
    SIGNAL_DICT = {
        i: i.replace(" ", "_").lower() + '_plan_change' for i in KEY_LIST
    }


# Set class attribute and its value from
# string as its less redundant (less code).
# R, G, B component, 'a'
a = 24

for n in Plan.attr_q_:
    # grey component, 'a'
    setattr(Plan, n, (a, a, a))
    a += 4
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


class Resize:
    """Import as 'fz'."""
    RESIZE_TYPE_LIST = (
        de.COVER,
        de.CROP,
        de.FACTOR,
        de.FILLED,
        de.FIXED,
        de.LOCKED,
        de.TRIM
    )


class Row:
    """
    A Row key is not displayed, so they're abbreviated
    and not capitalized. Import as 'rk'.
    """
    BRW = 'brw'                             # button row
    LEAD = 'lead'                           # Caption text
    TRAIL = 'trail'                         # Caption text
    LTR = 'ltr'                             # Lead, Trail, row
    PAR = 'par'                             # Pattern row
    RW1 = 'rw1'                             # first Button Row
    RW2 = 'rw2'                             # second Button Row


class Shape:
    """Import as 'sh'."""
    BOX_HORIZONTAL, BOX_HORIZONTAL_SHEAR, BOX_VERTICAL, BOX_VERTICAL_SHEAR \
        = range(4)
    ELLIPSE_RATIO = .13466
    ELLIPSE_SET = {de.ELLIPSE_HORIZONTAL, de.ELLIPSE_VERTICAL}
    OCTAGON_RATIO = .2928932188

    # circumscribe radius = inscribe radius / OCTAGON_CIRCUMRADIUS_RATIO
    OCTAGON_CIRCUMRADIUS_RATIO = .93

    REGULAR_SET = {
        de.OCTAGON_SHEAR,
        de.OCTAGON_ON_ITS_SIDE_SHEAR,
        de.OCTAGON_ON_ITS_SIDE,
        de.OCTAGON_DOUBLE,
        de.RECTANGLE,
        de.SQUARE
    }
    BOX_SHAPE_LIST = de.HEXAGON_SHEAR, de.HEXAGON_TRUNCATED_SHEAR
    BOX_TYPE_LIST = de.TOP, de.BOTTOM, de.LEFT, de.RIGHT
    CURVED_SET = set()
    CURVED_SET.update(ELLIPSE_SET)
    CURVED_SET.update(
        {de.CIRCLE, de.CIRCLE_HORIZONTAL, de.CIRCLE_VERTICAL, de.ELLIPSE}
    )
    DOUBLE_SET = set()
    DOUBLE_SET.update(ELLIPSE_SET)
    DOUBLE_SET.update(
        {
            de.DIAMOND,
            BOX_HORIZONTAL,
            BOX_HORIZONTAL_SHEAR,
            BOX_VERTICAL,
            BOX_VERTICAL_SHEAR,
            de.CIRCLE_VERTICAL,
            de.CIRCLE_HORIZONTAL,
            de.HEXAGON,
            de.HEXAGON_SHEAR,
            de.HEXAGON_TRUNCATED,
            de.HEXAGON_TRUNCATED_SHEAR,
            de.MITER_SQUARE,
            de.OCTAGON_DOUBLE_SHEAR,
            de.OCTAGON_DOUBLE
        }
    )
    CELL_SHAPE_LIST = (
        de.RECTANGLE,
        de.CIRCLE,
        de.DIAMOND,
        de.ELLIPSE,
        de.HEXAGON_SHEAR,
        de.HEXAGON,
        de.HEXAGON_TRUNCATED_SHEAR,
        de.HEXAGON_TRUNCATED,
        de.MITER_SQUARE,
        de.OCTAGON_SHEAR,
        de.OCTAGON,
        de.OCTAGON_ON_ITS_SIDE_SHEAR,
        de.OCTAGON_ON_ITS_SIDE,
        de.PARALLELOGRAM_LEFT,
        de.PARALLELOGRAM_RIGHT,
        de.SQUARE,
        de.TRIANGLE_DOWN_SHEAR,
        de.TRIANGLE_DOWN_REGULAR,
        de.TRIANGLE_LEFT_SHEAR,
        de.TRIANGLE_LEFT_REGULAR,
        de.TRIANGLE_RIGHT_SHEAR,
        de.TRIANGLE_RIGHT_REGULAR,
        de.TRIANGLE_UP_SHEAR,
        de.TRIANGLE_UP_REGULAR
    )
    TABLE_EQUILATERAL_LIST = (
        de.CIRCLE_HORIZONTAL,
        de.CIRCLE_VERTICAL,
        de.HEXAGON,
        de.HEXAGON_TRUNCATED,
        de.OCTAGON,
        de.OCTAGON_ON_ITS_SIDE,
        de.OCTAGON_DOUBLE,
        de.SQUARE,
        de.MITER_SQUARE,
        de.TRIANGLE_DOWN_REGULAR,
        de.TRIANGLE_LEFT_REGULAR,
        de.TRIANGLE_RIGHT_REGULAR,
        de.TRIANGLE_UP_REGULAR
    )
    TABLE_SHAPE_LIST = (
        de.RECTANGLE,
        de.DIAMOND,
        de.ELLIPSE_HORIZONTAL,
        de.ELLIPSE_VERTICAL,
        de.HEXAGON_SHEAR,
        de.HEXAGON_TRUNCATED_SHEAR,
        de.OCTAGON_SHEAR,
        de.OCTAGON_ON_ITS_SIDE_SHEAR,
        de.OCTAGON_DOUBLE_SHEAR,
        de.PARALLELOGRAM_ALT_LEFT,
        de.PARALLELOGRAM_ALT_RIGHT,
        de.PARALLELOGRAM_LEFT,
        de.PARALLELOGRAM_RIGHT,
        de.TRIANGLE_DOWN_SHEAR,
        de.TRIANGLE_LEFT_SHEAR,
        de.TRIANGLE_RIGHT_SHEAR,
        de.TRIANGLE_UP_SHEAR
    )
    EQUILATERAL_TYPE_LIST = (
        de.CIRCLE,
        de.CIRCLE_HORIZONTAL,
        de.CIRCLE_VERTICAL,
        de.HEXAGON,
        de.HEXAGON_TRUNCATED,
        de.MITER_SQUARE,
        de.OCTAGON_ON_ITS_SIDE,
        de.OCTAGON_DOUBLE,
        de.OCTAGON,
        de.SQUARE,
        de.TRIANGLE_DOWN_REGULAR,
        de.TRIANGLE_LEFT_REGULAR,
        de.TRIANGLE_RIGHT_REGULAR,
        de.TRIANGLE_UP_REGULAR
    )
    SHAPE_LIST = (
        de.RECTANGLE,
        de.CIRCLE,
        de.ELLIPSE,
        de.HEXAGON,
        de.HEXAGON_TRUNCATED,
        de.OCTAGON,
        de.OCTAGON_ON_ITS_SIDE,
        de.SQUARE,
        de.MITER_SQUARE,
        de.TRIANGLE_DOWN_REGULAR,
        de.TRIANGLE_LEFT_REGULAR,
        de.TRIANGLE_RIGHT_REGULAR,
        de.TRIANGLE_UP_REGULAR
    )

    # Has an alternate ego.
    ALT_PARALLELOGRAM_DICT = {
        de.PARALLELOGRAM_ALT_LEFT: de.PARALLELOGRAM_ALT_RIGHT,
        de.PARALLELOGRAM_ALT_RIGHT: de.PARALLELOGRAM_ALT_LEFT
    }


class Signal:
    """Import as 'si'."""
    ACCEPT_FOCUS = 'accept_focus'
    ACCEPT_WINDOW = 'accept_window'
    ACCENT_CHANGE = 'accent_change'
    ADD_ITEM = 'add_item'
    BACK_CHANGE = 'back_change'
    CANCEL_WINDOW = 'cancel_window'
    CANVAS_MARGIN_CALC = 'canvas_margin_calc'
    CANVAS_MARGIN_CHANGE = 'canvas_margin_change'
    CANVAS_MARGIN_VIEW = 'canvas_margin_view'
    CANVAS_RECT_CALC = 'canvas_rect_calc'
    CANVAS_SHIFT_CHANGE = 'canvas_shift_change'
    CANVAS_SHIFT_CALC = 'canvas_shift_calc'
    CANVAS_SHIFT_VIEW = 'canvas_shift_view'
    CELL_MARGIN_CALC = 'cell_margin_calc'
    CELL_MARGIN_CHANGE = 'cell_margin_change'
    CELL_MARGIN_VIEW = 'cell_margin_view'
    CELL_RECT_CALC = 'cell_rect_calc'
    CELL_RECT_CHANGE = 'cell_rect_change'
    CELL_RECT_VIEW = 'cell_rect_view'
    CELL_SHIFT_CALC = 'cell_shift_calc'
    CELL_SHIFT_CHANGE = 'cell_shift_change'
    CELL_SHIFT_VIEW = 'cell_shift_view'
    CLOSE_VIEW_IMAGE = 'close_view_image'
    COLOR_CHANGE = 'color_change'
    COMBO_CREATED = 'combo_created'
    DIALOG_CLOSE = 'dialog_close'
    DIALOG_DRAWN = 'dialog_drawn'
    DIALOG_OPEN = 'dialog_open'
    DISAPPEAR = 'disappear'
    EMBOSS_CHANGE = 'emboss_change'
    FONT_SIZE_CHANGE = 'font_size_change'
    GLOBAL_EMBOSS = 'global_emboss'
    GLOBAL_SEED = 'global_seed'
    GRID_CHANGE = 'grid_change'
    GROUP_CHANGE = 'group_change'
    HEAT_CHANGE = 'heat_change'
    HELM_CHANGE = 'helm_change'
    LIGHT_CHANGE = 'light_change'
    MAIN_CREATED = 'main_created'
    MATERIALIZE = 'materialize'
    MODEL_CREATED = 'model_created'
    MODEL_LIST_CHANGE = 'model_list_change'
    MODEL_MOVE = 'model_move'
    MODEL_ACTIVE = 'model_new'
    MODEL_RENAME = 'model_rename'
    MODEL_REVISE = 'model_revise'
    PANEL_CHANGE = 'panel_change'
    PEEK = 'peek'
    PER_CHANGE = 'per_change'
    PREVIEW = 'preview'
    RANDOMIZE = 'randomize'
    RECTANGLE_CALC = 'rectangle_calc'
    RECTANGLE_CHANGE = 'rectangle_change'
    RECTANGLE_VIEW = 'rectangle_view'
    REMOVE_MATERIAL = 'remove_material'
    RENAME = 'rename'
    RESIZE = 'resize'
    RING_CLEARED = 'ring_cleared'
    RING_EMPTY = 'ring_empty'
    ROW_CHANGE = 'row_change'
    SEED_CHANGE = 'seed_change'
    SELECT_ITEM = 'select_item'
    SEQUENCE = 'sequence'
    SWITCH_ACTIVE = 'switch_active'
    UPDATE_TREE = 'update_tree'
    UI_CHANGE = 'ui_change'
    VALIDATE = 'validate'
    VIEW_SIZE_CHANGE = 'view_size_change'
    VOTE_CHANGE = 'vote_change'
    WINDOW_SIZE_CHANGE = 'window_size_change'
    WINDOW_XY_CHANGE = 'window_xy_change'
    run_first = gobject.SIGNAL_RUN_FIRST, None, (gobject.TYPE_PYOBJECT,)
    run_last = gobject.SIGNAL_RUN_LAST, None, (gobject.TYPE_PYOBJECT,)
    BOOTH_DICT = {VOTE_CHANGE: run_first}
    COMBO_DICT = {COMBO_CREATED: run_last}
    FONT_SIZE_D = {FONT_SIZE_CHANGE: run_first}
    GROUP_DICT = {
        ACCENT_CHANGE: run_first,
        BACK_CHANGE: run_first,
        DISAPPEAR: run_first,
        GROUP_CHANGE: run_first,
        RANDOMIZE: run_first,
        SEQUENCE: run_first,
        SWITCH_ACTIVE: run_first
    }
    BUTTON_DICT = {
        MATERIALIZE: run_first,
        REMOVE_MATERIAL: run_first,
        VALIDATE: run_first
    }
    IMAGE_DICT = {CLOSE_VIEW_IMAGE: run_first}
    MODEL_DICT = {
        CANVAS_MARGIN_CALC: run_first,
        CANVAS_MARGIN_CHANGE: run_first,
        CANVAS_RECT_CALC: run_first,
        CANVAS_SHIFT_CALC: run_first,
        CANVAS_SHIFT_CHANGE: run_first,
        CELL_MARGIN_CALC: run_first,
        CELL_MARGIN_CHANGE: run_first,
        CELL_RECT_CALC: run_first,
        CELL_RECT_CHANGE: run_first,
        CELL_SHIFT_CALC: run_first,
        CELL_SHIFT_CHANGE: run_first,
        GRID_CHANGE: run_first,
        RECTANGLE_CALC: run_first,
        RECTANGLE_CHANGE: run_first
    }
    NODE_DICT = {
        ADD_ITEM: run_first,
        MODEL_ACTIVE: run_first,
        SELECT_ITEM: run_first,
        UPDATE_TREE: run_first
    }
    PAST_DICT = {
        CANVAS_MARGIN_VIEW: run_first,
        CANVAS_SHIFT_VIEW: run_first,
        CELL_MARGIN_VIEW: run_first,
        CELL_RECT_VIEW: run_first,
        CELL_SHIFT_VIEW: run_first,
        RECTANGLE_VIEW: run_first
    }
    PER_DICT = {
        DISAPPEAR: run_first,
        PER_CHANGE: run_first
    }
    PER_BUTTON_DICT = {ACCEPT_WINDOW: run_last}
    PLANNER_DICT = {}
    RAINBOW_DICT = {COLOR_CHANGE: run_first}
    RING_DICT = {
        COMBO_CREATED: run_first,
        GLOBAL_EMBOSS: run_first,
        GLOBAL_SEED: run_first,
        HEAT_CHANGE: run_first,
        HELM_CHANGE: run_first,
        LIGHT_CHANGE: run_first,
        MODEL_CREATED: run_first,
        MODEL_LIST_CHANGE: run_last,
        MODEL_MOVE: run_first,
        MODEL_RENAME: run_first,
        MODEL_REVISE: run_first,
        PANEL_CHANGE: run_first,
        RENAME: run_first,
        RESIZE: run_first,
        RING_EMPTY: run_last,
        RING_CLEARED: run_last,
        ROW_CHANGE: run_first,
        UI_CHANGE: run_last,
        VIEW_SIZE_CHANGE: run_first,
        WINDOW_SIZE_CHANGE: run_last,
        WINDOW_XY_CHANGE: run_last
    }
    WINDOW_DICT = {
        ACCEPT_FOCUS: run_last,
        ACCEPT_WINDOW: run_last,
        CANCEL_WINDOW: run_last,
        DIALOG_CLOSE: run_last,
        DIALOG_DRAWN: run_last,
        DIALOG_OPEN: run_last,
        MAIN_CREATED: run_last,
        PEEK: run_last,
        PREVIEW: run_last
    }
    for _ in Plan.SIGNAL_DICT.values():
        PLANNER_DICT[_] = run_first


class Step:
    """Use with an option group. Import as 'sk'."""
    # Steps SuperPreset
    STEPS = ""
    DEFAULT_NAME_STEP_KEYS = {
        STEPS,
        de.GLOBAL,
        de.LIGHT,
        de.BACKGROUND,
        de.ACCENT,
        de.MODEL,
        de.PRESET_STEPS
    }
    DEFAULT_STEPS_PRESET_LIST = (
        STEPS, de.GLOBAL, de.LIGHT, de.BACKGROUND, de.ACCENT, de.MODEL
    )
    DEFAULT_SHADOW_PRESET_LIST = (
        de.SHADOW, de.SHADOW_SWITCH, de.SHADOW_1, de.SHADOW_2, de.INNER_SHADOW
    )

    # Model____________________________________________________________________
    # Box
    BOX_CANVAS = "{}.{}".format(de.BOX, de.CANVAS)
    BOX_CELL = "{}.{}".format(de.BOX, de.CELL)
    BOX_FACE = "{}.{}".format(de.BOX, de.FACE)

    # Cell
    CELL_CELL = "{}.{}".format(de.CELL, de.CELL)

    # Pyramid
    PYRAMID_CANVAS = "{}.{}".format(de.PYRAMID, de.CANVAS)
    PYRAMID_CELL = "{}.{}".format(de.PYRAMID, de.CELL)

    # Sidewalk
    SIDEWALK_CANVAS = "{}.{}".format(de.SIDEWALK, de.CANVAS)
    SIDEWALK_CELL = "{}.{}".format(de.SIDEWALK, de.CELL)
    SIDEWALK_FACING = "{}.{}".format(de.SIDEWALK, de.FACING)

    # Stack
    STACK_CELL = "{}.{}".format(de.STACK, de.CELL)

    # Table
    TABLE_CANVAS = "{}.{}".format(de.TABLE, de.CANVAS)
    TABLE_CELL = "{}.{}".format(de.TABLE, de.CELL)

    # Identify AnyGroup with a visible Per Cell option.
    PER_GROUP_SET = {
        BOX_CELL,
        BOX_FACE,
        PYRAMID_CELL,
        SIDEWALK_CELL,
        SIDEWALK_FACING,
        STACK_CELL,
        TABLE_CELL
    }

    MARGIN_DEPENDENT_SET = {
        de.BORDER, de.CAPTION, de.FRINGE, de.IMAGE, de.LINE, de.PLAQUE
    }
    MERGE_DEPENDENT_SET = set()
    MERGE_DEPENDENT_SET.update(MARGIN_DEPENDENT_SET)
    MERGE_DEPENDENT_SET.update({de.MARGIN})

    # Cell branch
    CELL_MARGIN = "{}.{}".format(de.CELL, de.MARGIN)
    CELL_SHIFT = "{}.{}".format(de.CELL, de.SHIFT)
    CELL_TYPE = "{}.{}".format(de.CELL, de.TYPE)


class SubMaya:
    """Import as 'sm'."""
    ADD = 'add'
    BELOW = 'below'
    BUMP = 'bump'
    CELL_SHAPE = 'c_shape'
    COLOR = 'color'
    CORNER = 'corner'
    DIMENSION = 'dim'
    FILLER = 'filler'
    FRAME = 'frame'
    INSET = 'inset'
    BULB = 'bulb'

    # Is a generic key to a Frame sub-type. Identify Frame/Maya.
    LINK = 'link'

    MARGIN = 'margin'
    MASK = 'mask'
    NAME = 'name'
    NOISE = 'noise'
    OVERLAY = 'overlay'
    POSITION = 'pos'
    RATIO = 'ratio'
    SHADOW = 'shadow'
    SHADOW1 = 'shadow1'
    SHADOW2 = 'shadow2'
    STRIP = 'strip'
    WRAP = 'wrap'


class Triangle:
    """Import as 'ft'."""
    # width/height ratios of an equilateral triangle
    SCALE_UP = 1.1547005

    # Is also the sine of 60 degrees.
    SCALE_DOWN = .8660254

    DOWN_SET = {de.TRIANGLE_DOWN_SHEAR, de.TRIANGLE_DOWN_REGULAR}
    RIGHT_SET = {de.TRIANGLE_RIGHT_SHEAR, de.TRIANGLE_RIGHT_REGULAR}
    CELL_SIZE_SET = {de.CELL_SIZE, de.SHAPE_COUNT}
    TRIANGLE_LIST = (
        de.TRIANGLE_DOWN_SHEAR,
        de.TRIANGLE_DOWN_REGULAR,
        de.TRIANGLE_LEFT_SHEAR,
        de.TRIANGLE_LEFT_REGULAR,
        de.TRIANGLE_RIGHT_SHEAR,
        de.TRIANGLE_RIGHT_REGULAR,
        de.TRIANGLE_UP_SHEAR,
        de.TRIANGLE_UP_REGULAR
    )
    INVERTED_DICT = {
        de.TRIANGLE_DOWN_SHEAR: de.TRIANGLE_UP_SHEAR,
        de.TRIANGLE_DOWN_REGULAR: de.TRIANGLE_UP_REGULAR,
        de.TRIANGLE_LEFT_SHEAR: de.TRIANGLE_RIGHT_SHEAR,
        de.TRIANGLE_LEFT_REGULAR: de.TRIANGLE_RIGHT_REGULAR,
        de.TRIANGLE_RIGHT_SHEAR: de.TRIANGLE_LEFT_SHEAR,
        de.TRIANGLE_RIGHT_REGULAR: de.TRIANGLE_LEFT_REGULAR,
        de.TRIANGLE_UP_SHEAR: de.TRIANGLE_DOWN_SHEAR,
        de.TRIANGLE_UP_REGULAR: de.TRIANGLE_DOWN_REGULAR
    }


class VoteType:
    """These items are added to an AnyGroup's vote dict. Import as 'vt'."""
    IS_BACK = 'is_back'
    IS_CHAIN = 'is_chain'
    IS_EMBOSS = 'is_emboss'
    IS_MAIN = 'is_main'
    IS_NEW = 'is_new'
    IS_PLANNED = 'is_planned'
    IS_SEED = 'is_seed'


class Widget:
    """Import as wi."""
    VISIBLE_SET = {de.PRESET, de.PER, de.RANDOM, de.SWITCH}
