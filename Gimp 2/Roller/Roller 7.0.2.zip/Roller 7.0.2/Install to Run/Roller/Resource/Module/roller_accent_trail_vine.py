#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from random import randint, uniform
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gimp_context import prep_brush, set_draw_line_brush
from roller_gimp_image import add_sub_maya_group, add_wip_layer
from roller_gimp_layer import blur_selection
from roller_maya_sub_accent import SubAccent
from roller_preset import combine_seed
from roller_preset_shadow import make_shadow
from roller_utility import random_rgb
from roller_wip import Wip
import math

SHADOW_D = {
    de.BLUR: 20.,
    de.INTENSITY: 100.,
    de.MODE: "Normal",
    de.OFFSET_X: -6.,
    de.OFFSET_Y: .0,
    de.COLOR_1: (0, 0, 0)
}


def do_matter(maya):
    """
    Make a matter layer for TrialingVine.

    maya: TrailingVine
    Return: layer or None
        'matter'
    """
    def _plot_wave():
        """
        Calculate the points for a wave that starts
        at the top of the layer and ends at its bottom.

        Return: list
            [x, y, ...]
            plot
        """
        _q = []
        _y = _angle = .0

        # Pi x 2, '6.28318'
        _f = 6.28318 / wave_length

        while _y < bottom_y:
            _x = math.sin(_angle) * amplitude + x
            _q.extend([_x, _y])
            _y += 1
            _angle += _f
        return _q

    j = Run.j
    d = maya.value_d
    parent = add_sub_maya_group(maya)
    e = SHADOW_D
    w, h = Wip.get_size()
    count = int(d[de.LAYER_COUNT])
    shadow_blur_dec = 90. / count
    bottom_y = h + Wip.y

    combine_seed(d)
    set_draw_line_brush()
    prep_brush()

    for i in range(count):
        amplitude = max(20., w * uniform(.0, .04))
        amp_inc = max(10., w * uniform(.0, .02))
        offset = h * uniform(-.5, .5)
        wave_length = h + offset
        z = add_wip_layer("{} of {}".format(i + 1, count), parent)
        e[de.BLUR] = max(30., (90. - i * 10. - shadow_blur_dec))

        # pixel size, '1.5'
        pdb.gimp_context_set_brush_size(1.5 + i // 2.)
        pdb.gimp_context_set_foreground(random_rgb())

        for _ in range(int(d[de.WAVE_PER_LAYER])):
            x = randint(0, w)
            q = _plot_wave()

            pdb.gimp_selection_none(j)
            pdb.gimp_paintbrush_default(z, len(q), q)
            amplitude += amp_inc

        z2 = make_shadow(e, parent, (z,))

        if z2:
            pdb.gimp_image_reorder_item(j, z2, parent, 1)
        blur_selection(z, (count - i) * 3.)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.BRW]
    )


class TrailVine(SubAccent):
    """Create Accent output."""
    kind = de.TRAIL_VINE

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)
