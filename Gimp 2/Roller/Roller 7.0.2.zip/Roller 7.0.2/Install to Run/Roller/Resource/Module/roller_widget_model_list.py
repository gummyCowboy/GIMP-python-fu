#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import Define as df, Signal as si
from roller_constant_identity import Identity as de
from roller_container import The
from roller_def_access import get_default_d
from roller_def_tree import DEFAULT_MODEL_D, create_model_insert_d
from roller_helm import Helm
from roller_model_name import ModelName
from roller_model_nexus import CLASS_MODEL
from roller_port_rename import PortRename
from roller_port_revise_model import PortReviseModel
from roller_port_step import PortStep
from roller_preset_super import load_super
from roller_ring import Ring
from roller_shelf import Shelf
from roller_tooltip_text import Tip
from roller_step import (
    append_parts,
    connect_sub_str,
    count_parts,
    get_last_part,
    get_branch_step_list,
    get_parts,
    rename_model_in_step_d
)
from roller_utility import enumerate_name, make_split_key
from roller_widget import set_widget_attr
from roller_widget_box import Box as boxer
from roller_widget_button import (
    Button,
    MoveDownButton,
    MoveUpButton,
    ProcessButton,
    RenameButton,
    ReviseButton
)
from roller_widget_combo import ComboBox
from roller_widget_row import WidgetRow
from roller_widget_table import create_table
from roller_widget_tree import CHOICE_COLOR, TreeViewList
import gtk  # type: ignore

INVALID_CHAR_SET = {",", ".", "/", "\\"}
MANAGE = 'manage'
MODEL_TYPE = de.TYPE
MODIFY = 'modify'
NEED_COUNT = 2, 2, 1, 1, 1, 1
SORT = 'sort'
SORT_KEY = de.UP, de.DOWN
MANAGE_KEY = de.NEW, de.DELETE
BUTTON_CHANGE = de.DELETE, de.NEW, de.DOWN, de.UP

# Display label.
STEPS_NODE_ITEM_LIST = [
    de.GLOBAL, de.LIGHT, de.BACKGROUND, de.ACCENT, de.MODEL, de.PRESET
]
MODEL_LIST = de.BOX, de.CELL, de.PYRAMID, de.SIDEWALK, de.STACK, de.TABLE


def collect_active_model(d):
    """
    Find Model name in the active dict.

    d: dict
        active dict
        {Model-name-step-key: Preset value dict}

    Return: list
        [model name, ...]
    """
    # Model panel key, without a branch, length , '1'
    # Model name position in Model-name-step-key, '0'
    return [step_k for step_k in d if count_parts(step_k) == 1]


def get_model_list():
    """
    Fetch a list of available Model type.

    Return: list
        of Model type
    """
    return MODEL_LIST


class ModelList(gtk.Alignment, object):
    """Is a Widget group for managing Model and Model step."""
    change_signal = None
    has_table_label = False

    def __init__(self, **d):
        The.model_list = self

        super(gtk.Alignment, self).__init__()
        set_widget_attr(self, d)

        # Return focus to a responsible Button.
        self.widget = None

        # Identify a Model type, 'self._model_type_d'.
        # {model name: Model type}
        # Each item in the list is for a named Model. A
        # Model is either in the Shelf or is active.
        self._model_type_d = {}

        self._branch_step_d = OrderedDict()
        self._list_buttons = []
        self._value = {
            de.MODEL: {},
            de.SHELF: OrderedDict(),
            de.ACTIVE: OrderedDict()
        }

        self.dialog = None
        d[df.SCROLL] = d[df.NO_VOTE] = True
        hbox = gtk.HBox()
        relay = d[df.RELAY][:]
        self._parent_node = self.any_group.dna.get_parent_node()
        self._parent_node.connect(si.UPDATE_TREE, self.on_update_tree)

        # Table Widget keyword arguments, 'e'
        e = {}

        e.update(d)

        # container for the Table Widget, 'vbox'
        vbox = boxer(padding=(0, 0, 0, 2))

        d[df.RELAY].insert(0, self.on_change_nexus)
        d.update({df.COLOR: CHOICE_COLOR, df.MINIMUM_W: 70})

        d[df.HEADER] = de.ACTIVE
        self._active_tree = TreeViewList(**d)
        model_type_relay = d[df.RELAY] = relay[:]

        model_type_relay.insert(0, self.on_model_type_change)
        self._active_tree.treeview.set_tooltip_text(Tip.MODEL_LIST_TREE)

        # Build a Model Table.
        e[df.WIDGET_LIST] = (
            (
                MODEL_TYPE,
                ComboBox,
                dict(
                    e,
                    key=MODEL_TYPE,
                    function=get_model_list,
                    relay=model_type_relay
                )
            ),
            (
                "",
                WidgetRow,
                dict(
                    e,
                    key=MANAGE,
                    relay=relay + [self.verify_button],
                    sub=OrderedDict([
                        (de.NEW, {
                            df.TEXT: de.NEW,
                            df.TOOLTIP: Tip.MODEL_LIST_NEW,
                            df.WIDGET: ProcessButton
                        }),
                        (de.DELETE, {
                            df.TEXT: de.DELETE,
                            df.TOOLTIP: Tip.DELETE_MODEL,
                            df.WIDGET: Button
                        })
                    ])
                )
            ),
            (
                "",
                WidgetRow,
                dict(
                    e,
                    key=MODIFY,
                    relay=relay + [self.verify_button],
                    sub=OrderedDict([
                        (de.RENAME, {
                            df.DIALOG: PortRename,
                            df.TOOLTIP: Tip.RENAME_MODEL,
                            df.WIDGET: RenameButton
                        }),
                        (de.REVISE, {
                            df.DIALOG: PortReviseModel,
                            df.TOOLTIP: Tip.REVISE_MODEL,
                            df.WIDGET: ReviseButton
                        })
                    ])
                )
            ),
            (
                "",
                WidgetRow,
                dict(
                    e,
                    key=SORT,
                    relay=relay + [self.verify_button],
                    sub=OrderedDict([
                        (de.UP, {
                            df.TOOLTIP: Tip.MOVE_UP,
                            df.WIDGET: MoveUpButton
                        }),
                        (de.DOWN, {
                            df.TOOLTIP: Tip.MOVE_DOWN,
                            df.WIDGET: MoveDownButton
                        })
                    ])
                )
            ),
            (
                "",
                Button,
                dict(
                    e,
                    key=de.STEP,
                    text=de.STEP + "…",
                    tooltip=Tip.STEP,
                    relay=relay + [self.on_step_action]
                )
            )
        )

        # dict of Widgets, 'd'
        d = create_table(vbox, **e)

        # the Delete Button index, '1'
        self._list_buttons = d[SORT].widget_q + \
            d[MANAGE].widget_q[1:] + d[MODIFY].widget_q

        self._rename_button = d[MODIFY].widget_q[0]
        self._model_type_g = d[MODEL_TYPE]
        d[MANAGE].get_g(de.DELETE).relay.insert(0, self.on_delete_item)
        d[MANAGE].get_g(de.NEW).relay.insert(0, self.on_new_button)
        d[SORT].get_g(de.DOWN).relay.insert(0, self.on_move_sel_down)
        d[SORT].get_g(de.UP).relay.insert(0, self.on_move_sel_up)

        for i, g in enumerate(self._list_buttons):
            g.need_count = NEED_COUNT[i]

        self.roller_win.connect(si.DIALOG_CLOSE, self.verify_button)

        # Assign self variable to prevent garbage collection.
        # New Button index, '0'
        self._new_button = d[MANAGE].widget_q[0]

        self._step_button = d[de.STEP]

        hbox.add(vbox)
        hbox.pack_start(self._active_tree, expand=True)
        self.add(hbox)
        self.verify_button()

        # Connect event.
        self._active_tree.treeview.connect(
            'key_press_event', self.on_model_list_keypress
        )
        self._active_tree.treeview.get_selection().connect(
            'changed', self.verify_button
        )
        Ring.gob.connect(si.PANEL_CHANGE, self.on_panel_change)
        Ring.gob.connect(si.PANEL_CHANGE, self.on_change_nexus)
        Ring.gob.connect(si.RENAME, self.on_rename_action)
        Ring.gob.connect(si.MODEL_REVISE, self.on_model_revise)
        Ring.gob.connect(si.MODEL_LIST_CHANGE, self.on_model_list_change)
        self._parent_node.connect(si.MODEL_ACTIVE, self.on_model_active)

        # Do last.
        d[MODEL_TYPE].set_ui(de.TABLE)

    def _add_model_to_active_tree(self, model_name):
        """
        Create an item for the active Model list from a Model's name.

        model_name: string or None
            a Model key
            Is the identity of the Model found in the 'self._model_d' dict.
        """
        self._active_tree.append_item(model_name)
        self.verify_button()
        self._active_tree.select_r(len(self._active_tree.item_list))
        Ring.plug(si.MODEL_MOVE, None)

    def _delete_model_dict_item(self, dead_name):
        """
        Remove an item from the Model dict.

        dead_name: string
            Is the name of the Model that is to be removed.
        """
        if dead_name in self._model_type_d:
            self._model_type_d.pop(dead_name)

    def _fix_model_name(self, model_name, model_type):
        """
        A Model name is not allowed to contain a comma or a slash.

        model_name: string
        Return: string
            fixed Model name
        """
        n = model_type if model_name is None else model_name

        # Remove reserved step-key path character.
        # Comma is used in SuperPreset Preset key.
        # Period is used to delimit a step-key.
        # The slashes are used by Step to create a path.
        for i in INVALID_CHAR_SET:
            n = n.replace(i, "")

        # Any default Steps Node item are reserved
        # word as a Node item is also a key.
        # list of default item matched with the model name, 'q'
        if any([i for i in STEPS_NODE_ITEM_LIST if i == n]):
            # Change the name to a different key.
            n += "_"

        # list of Model names, 'q'
        q = self._model_type_d.keys()

        q.append(de.MODEL)

        if any([i for i in q if i == n]):
            n = enumerate_name(n, q)
        return n

    def _load_model_dict(self, model_d):
        """
        Reset the Model dict with a new Model dict.

        model_d: dict
            {Model name: Model type}
            Store active and shelved Model.
        """
        self._model_type_d.clear()

        for model_name, model_type in model_d.items():
            # Check Model compatibility.
            if model_type in MODEL_LIST:
                # Is a valid Model type.
                self._model_type_d[model_name] = model_type

    def _make_model_branch(self, model_name, model_type):
        """
        Add a Model to the main NodePanel.

        model: Model
            Add to the navigation tree.

        model_name: string
            Is an item key for the Steps Node.
        """
        step_list = [
            connect_sub_str(model_name, n1)
            for n1 in DEFAULT_MODEL_D[model_type]
        ]
        d = create_model_insert_d(step_list, {model_name: model_type})

        CLASS_MODEL[model_type](model_name)
        self._parent_node.emit(si.ADD_ITEM, (d, model_name))
        self._update_step_node(self.get_active_model_name_list())

        # The Model group changed.
        self.any_group.changed()

    def _rename_model_dict_item(self, old_name, new_name):
        """
        Change the name of a Model stored in the Model dict.

        old_name: string
        new_name: string
        """
        if old_name in self._model_type_d:
            model_type = self._model_type_d[old_name]

            self._model_type_d.pop(old_name)
            self._model_type_d[new_name] = model_type

    def _update_branch_d(self, name_q):
        """
        Update the ModelList value.

        name_q: list
            [model name, ...]
        """
        # Maintain the branch dict for the getter.
        # Link directly with value dict for speed as this is an expensive op.
        self._branch_step_d.clear()

        for name_step_k in self.collect_model_branch_list(name_q):
            # AnyGroup, 'a'
            a = Helm.get_group(name_step_k)
            if a:
                if not a.dna.is_super_preset:
                    self._branch_step_d[name_step_k] = a.get_value_d()

        self.any_group.set_widget_a(self.key, self.get_ui())
        return name_q

    def _update_active_tree(self, new_r, old_r):
        """
        Update the active Model list after changing the order of a Model.

        new_r: int
            new position

        old_r: int
            old position
        """
        n = self._active_tree.item_list[old_r]

        self._active_tree.remove_row(old_r)
        self._active_tree.insert_row(new_r, n)
        self._active_tree.select_r(new_r)

        # Update interested party.
        Ring.plug(si.MODEL_MOVE, None)

    def _update_step_node(self, name_q):
        """
        Sort Model item in the Steps Node. Fix the Steps
        Node being out of sync with the active Model TreeViewList.

        name_q: list
            [model name, ...]
            of active Model
        """
        self._parent_node.sort_item_list(
            STEPS_NODE_ITEM_LIST[:-1] + name_q + STEPS_NODE_ITEM_LIST[-1:]
        )

    def add_model_step(self, model_name, model_type, active_d):
        """
        Add active step to a new Model.

        model_name: string
            Identify the Model.

        model_type: string
            Identify Model-type.

        active_d: dict
            Add these steps to the navigation tree.
            Model SuperPreset
            {Model-name=step-key: Preset value dict}
        """
        if active_d:
            load_step_list = self._branch_step_d.keys()

            load_step_list.extend(active_d.keys())

            # Ensure Model.Preset step.
            n = make_split_key(de.PRESET, model_type)
            k = connect_sub_str(model_name, n)

            if k not in load_step_list:
                # Add a Model's Preset step-key.
                load_step_list.append(k)

            # Update the interface with the Model's step list.
            self._parent_node.emit(
                si.UPDATE_TREE,
                (load_step_list, self.create_active_model_dict())
            )

            # Load Preset value.
            load_super(active_d)

            # Update NodePanel-change listener.
            Ring.plug(si.PANEL_CHANGE, None)

    def change_row_position(self, new_r, old_r):
        """
        Change the row position of an active Model.

        new_r: int
            Is the new row position.
            0 to n

        old_r: int
            Is the old row position.
            0 to n
        """
        self._update_active_tree(new_r, old_r)
        self._update_step_node(self.get_active_model_name_list())
        Ring.plug(si.PANEL_CHANGE, None)

    @staticmethod
    def collect_model_branch_list(model_name_q):
        """
        Collect an active Model-name-step-key list.

        model_name_q: iterable
            [Model name, ...]
            Find each in the navigation tree.

        Return: list
            [Model-name=step-key, ...]
        """
        # [Model-name=step-key, ...], 'q'
        q = []

        for model_name in model_name_q:
            q.extend(get_branch_step_list(model_name))
        return q

    def create_active_model_dict(self):
        """
        Create a model dict limited to active Model.

        Return: dict
            {model name string: model type string}
            Consists of only active Model.
        """
        # {model name: model type}, 'd'
        d = OrderedDict()

        for model_name in self._active_tree.item_list:
            d[model_name] = self._model_type_d[model_name]
        return d

    def create_model(self, model_name, model_type):
        """
        Create a Model having default branch only.

        model_name: string
            Distinguish Model.

        model_type: string
            Model class descriptor
        """
        self._add_model_to_active_tree(model_name)
        self._model_type_d[model_name] = model_type
        self._make_model_branch(model_name, model_type)

    def delete_model(self, model_name):
        """
        Delete a Model given its Model name.

        model_name: string
            Identify the Model.
        """
        r = self.get_model_row(model_name)
        if r is not None:
            self._active_tree.select_r(r)
            self.on_delete_item()

    def get_complete_model_name_list(self):
        """
        Create a list of Model name for each
        Model in the ModelList's Model dict.

        Return: list
            [model name -> str, ...]
            All the Models are listed.
        """
        return self._model_type_d.keys()

    def get_model_row(self, model_name):
        """
        Determine a Model's row position in the active TreeView
        given the Model's name.

        model_name: string
            Identify the Model.

        Return: int or None
            row number; 0 to the number of items in the active tree minus one
        """
        return self._active_tree.get_item_row_number(model_name)

    def get_ui(self):
        """
        Get the value for data storage.

        Return: dict
            ModelList value
        """
        self._value[de.MODEL] = self._model_type_d
        self._value[de.ACTIVE] = self._branch_step_d
        self._value[de.SHELF] = Shelf.get_shelf_d()
        return self._value

    def get_active_model_name_list(self):
        """
        Make a list of active Model name.

        Return: list
            [model name, ...]
        """
        return self._active_tree.item_list[:]

    def get_model_dict(self):
        """
        Copy the Model dict.

        Return: dict
            {model name string: model type string}
        """
        return deepcopy(self._model_type_d)

    def get_selected_name(self):
        """
        From the active Model listing, return the name with the selection.

        Return: string or None
            the selected Model's name
        """
        r = self._active_tree.get_selected_r()
        if r is not None:
            return self._active_tree.item_list[r]

    def load_a(self, d):
        d = self.set_ui(d)
        self.any_group.set_widget_a(self.key, d)

    def on_change_nexus(self, *_):
        """Update the sensitivity of the Model Step Button."""
        Ring.plug(si.MODEL_LIST_CHANGE, None)

    def on_delete_item(self, *_):
        """Delete a row in the active TreeViewList."""
        r = self._active_tree.get_selected_r()
        if r is not None:
            # Model name, 'n'
            n = self._active_tree.item_list[r]

            if self._active_tree.treeview.get_selection():
                self._active_tree.remove_row(r)
                self.verify_button()

                model = ModelName.get_model(n)

                self._parent_node.remove_item_by_type(n)
                self._delete_model_dict_item(n)
                Shelf.remove_model(n)
                Helm.remove_model(n)
                model.die()
                Ring.plug(si.PANEL_CHANGE, None)

    def on_model_list_change(self, *_):
        self._step_button.set_sensitive(bool(self._model_type_d))

    def on_model_list_keypress(self, _, a):
        """
        Catch a Delete keypress.

        a: GTK Event
            keypress

        Return: True or None
            Is True when the keypress is handled.
        """
        n = gtk.gdk.keyval_name(a.keyval)
        if len(self._active_tree.item_list):
            if n == 'Delete':
                self.on_delete_item()
                return True
            if n == 'F2':
                self._rename_button.on_bring_dialog_button()
                return True

    def on_new_button(self, _):
        """
        _: ProcessButton
            Activated.
        """
        model_type = self._model_type_g.get_ui()
        model_name = self._fix_model_name(None, model_type)

        self.create_model(model_name, model_type)
        self._active_tree.select_r(len(self._active_tree.item_list) - 1)

    def on_model_active(self, _, model_name):
        """
        A shelved Model has been moved to the
        active Model list.

        Create a default Model.

        _: object
            Sent the Signal.

        model_name: string
            Identify Model.
        """
        self.create_model(model_name, self._model_type_d[model_name])

    def on_model_shelve(self, _, model_name):
        """
        Update the active tree.

        model_name: string
            Identify Model.
        """
        for r, name in enumerate(self._active_tree.item_list):
            if name == model_name:
                self._active_tree.remove_row(r)
                break

    @staticmethod
    def on_model_type_change(g):
        """
        Respond to a Model Type change event.

        g: ComboBox
            Is responsible.
        """
        k = g.get_ui()
        if k in Tip.MODEL_LIST_TYPE:
            g.set_tooltip_text(Tip.MODEL_LIST_TYPE[k])

    def on_model_revise(self, _, arg):
        """
        Alter the steps available for a Model. Respond to user
        accept action from the Revise Model dialog.

        _: Ring
        arg: tuple
            (
                branch-leaf-dict -> {branch-leaf-key: boolean selected value},
                    branch-leaf-key -> 'branch.leaf'
                    the new state
                list -> [branch-leaf-key, ...],
                    the previous state
                string -> Model name
            )

        Return: True
            Let GTK know that the signal was processed.
        """
        def _remove(_node, _name_step_k, _item_k):
            """
            Remove an item from a Node and its layer output.

            _node: Node
                Has item to remove.

            _name_step_k: string
                Is the Model-name-step-key of the item to remove.

            _item_k: string
                Is the item's display value.
            """
            # Remove layer output.
            any_group.emit(si.DISAPPEAR, None)

            _node.remove_item_by_type(_item_k)
            Helm.remove_step(_name_step_k)

        is_visible = False
        d, previous_list, model_name = arg

        # Create a list of Model-name-step-key for the selection option.
        for branch_leaf_k, is_include in d.items():
            parts = get_parts(branch_leaf_k)
            name_step_k = append_parts(model_name, parts)

            if is_include:
                if branch_leaf_k not in previous_list:
                    # Make the step available. Add the step to Shelf.
                    Shelf.set_step(
                        name_step_k,
                        get_default_d(get_last_part(name_step_k))
                    )
            else:
                # Remove the step from the Model.
                if Shelf.finds(name_step_k):
                    # The step is shelved.
                    Shelf.remove_step(name_step_k)

                # The step is visible.
                any_group = Helm.get_group(name_step_k)
                if any_group:
                    is_visible = True
                    node = any_group.dna.get_parent_node()
                    _remove(node, name_step_k, any_group.dna.key)

                    # Remove Node's when its label-list is empty.
                    if not node.get_label_list():
                        parent_node = node.any_group.dna.get_parent_node()
                        _remove(
                            parent_node,
                            node.any_group.name_step_k,
                            node.any_group.dna.key
                        )

        if is_visible:
            Ring.plug(si.PANEL_CHANGE, None)
        self._update_branch_d(self._parent_node.get_label_list()[5:-1])

    def on_move_sel_down(self, g):
        """
        Move a selection down one line in the active Model TreeViewList.
        If the selection row is at the bottom of the list,
        then rotate the item to the top of the list.

        g: Button
            Is responsible.
        """
        new_r = old_r = self._active_tree.get_selected_r()
        a = len(self._active_tree.item_list)
        new_r += 1

        if new_r == a:
            new_r = 0

        self.change_row_position(new_r, old_r)
        g.widget.grab_focus()

    def on_move_sel_up(self, g):
        """
        Move a selection up one line in the Active Model TreeView.
        If selection row is at the top of the list,
        then the item rotates to the bottom of the list.

        g: Button
            Is responsible
        """
        new_r = old_r = self._active_tree.get_selected_r()
        new_r -= 1

        if new_r < 0:
            new_r = len(self._active_tree.item_list) - 1

        self.change_row_position(new_r, old_r)
        g.widget.grab_focus()

    def on_panel_change(self, *_):
        """
        The branch dict has active Model. The dict
        is dependent on AnyGroup initialization.

        _: tuple
            (Ring, None)
        """
        # active Model name list, 'name_q'
        name_q = self.get_active_model_name_list()

        self._update_branch_d(name_q)
        self._update_step_node(name_q)

    def on_rename_action(self, _, name_q):
        """
        Respond to a Rename Button action.

        _: Ring
        name_q: tuple
            (old Model name str, new Model name str)
        """
        old_name, new_name = name_q

        if old_name != new_name:
            model_type = self._model_type_d[old_name]
            new_name = self._fix_model_name(new_name, model_type)
            i = self._active_tree.item_list.index(old_name)

            # Rename the Model in the Active list.
            self._active_tree.rename_item(i, new_name)

            # Rename the Model in the Model dict.
            self._rename_model_dict_item(old_name, new_name)

            # Rename the Model in the parent Node.
            dna = self._parent_node.get_dna_by_type(old_name)

            self._parent_node.rename_item(old_name, new_name)
            dna.rename(new_name)

            # Rename the item in the Model's branch VBox.
            dna.label.set_label_value(new_name)

            # Update the Model name dict and Model.
            ModelName.rename(old_name, new_name)

            # Update Helm.
            Helm.rename_model(rename_model_in_step_d, old_name, new_name)

            # Update Shelf.
            Shelf.rename_model(rename_model_in_step_d, old_name, new_name)

            # Update AnyGroup in Model branch.
            step_list = get_branch_step_list(new_name)

            for name_step_k in step_list:
                any_group = Helm.get_group(name_step_k)
                any_group.name_step_k = name_step_k

            # Update the active branch dict.
            Ring.plug(si.PANEL_CHANGE, None)

            # Rename layer.
            Ring.gob.emit(si.MODEL_RENAME, (old_name, new_name))

    def on_step_action(self, g):
        """
        Open a Model Step Window.

        g: Button
            Is Model Step.
        """
        self.widget = g
        self.dialog = PortStep
        self.roller_win.bring_dialog(self)

    def on_update_tree(self, _, arg):
        """
        Respond to a navigation tree structure update signal.
        Remove item and Node from the tree that is no longer used.
        Add new item and Node to the tree from a new step-key list.

        _: Node
        arg: tuple
            ([Model-name-step-key], {model name: model type})
            (new step, new model definition)
        """
        self._active_tree.reset()
        for model_name in arg[1].keys():
            self._add_model_to_active_tree(model_name)

    def set_ui(self, d):
        """
        Load the active Model list and the Shelf from a dictionary.

        d: dict
            ModelList value
            {
                de.MODEL: model dict,
                de.ACTIVE: SuperPreset,
                de.SHELF: SuperPreset
            }

            SuperPreset
            {Model-name-step-key: Preset value dict}

            Preset value dict
            {Identity: value}

        Return: dict
            ModelList value
        """
        # Before loading a ModelList Preset, clear the previous Model(s).
        while self._active_tree.item_list:
            self._active_tree.select_r(0)
            self.on_delete_item()

        self._model_type_d.clear()
        Shelf.set_d(d[de.SHELF])

        active_d = d[de.ACTIVE]
        load_step_list = active_d.keys()

        # Build active Model, 'model_d'.
        # 'model_d' -> {Model name: Model type}
        # Order Model for Node's item insertion order.
        model_d = OrderedDict()

        active_model_list = collect_active_model(active_d)

        for model_name in active_model_list:
            model_type = model_d[model_name] = d[de.MODEL].get(model_name)
            if model_type:
                self.create_model(model_name, model_type)

                # Add a Model's Preset step-key.
                load_step_list.extend([
                    connect_sub_str(model_name, de.PRESET)
                ])

        if model_d:
            self._parent_node.emit(si.UPDATE_TREE, (load_step_list, model_d))
            load_super(active_d)

        self._model_type_d.update(d[de.MODEL])
        Ring.plug(si.PANEL_CHANGE, None)
        return d

    def verify_button(self, *_):
        """Verify Button depending on the active TreeView state."""

        def disable_buttons():
            """
            Disable the dependent Buttons when there
            is no item selected in the ModelList.
            """
            for _g in self._list_buttons:
                _g.set_sensitive(0)
                _g.set_tooltip_text("")

        is_disable = True

        if self.get_selected_name() is not None:
            # The move and delete Buttons are dependent
            # on their selection state and the active TreeViewList size.
            r = self._active_tree.get_selected_r()
            if r is not None:
                is_disable = False
                for g in self._list_buttons:
                    if (
                        len(self._active_tree.item_list) >= g.need_count
                    ):
                        g.set_sensitive(1)
                        g.set_tooltip_text(g.tooltip_text)
                    else:
                        g.set_sensitive(0)
                        g.set_tooltip_text("")
        if is_disable:
            disable_buttons()
