#!/usr/bin/env python
# -*- coding: utf-8 -*-
# from gimpfu import CLIP_TO_IMAGE, FILL_PATTERN, pdb   # type: ignore
from roller_any_group import ManyGroup
from roller_constant import Row as rk, Signal as si, SubMaya as sm
from roller_constant_identity import Identity as de
from roller_container import PlanZ, Run
from roller_deco_output import init_deco_type
from roller_gimp_image import add_wip_layer, check_matter, make_group_layer
from roller_gimp_layer import color_selection_default, not_empty
from roller_gimp_selection import select_rect
from roller_image_change import ref_get_image, ref_on_group_change
from roller_maya import Main, Maya
from roller_maya_bulb import Bulb
from roller_maya_add import AddAbove
from roller_preset_mod import do_mod
from roller_wip import Wip


def check_plan_group(maya):
    """
    Create the root Plan group layer during a plan-view-type view run.

    maya: Plan
    Return: group layer
        Parent Plan output.
    """
    if not maya.group:
        return make_plan_group()
    return maya.group


def check_work_group(maya):
    """
    Create a Background group layer.

    maya: Work
    Return: group layer
        Owned by Background.
    """
    if not maya.group:
        return make_work_group()
    return maya.group


def do_matter(maya):
    """
    Create a Background layer.

    maya: Work
    Return: layer
        Background material
    """
    j = Run.j
    d = maya.value_d
    offset = maya.get_light()

    arg, p = init_deco_type(
        d[de.TYPE], j, maya, maya.group, d, offset, False
    )
    maya.rect = Wip.get_rect()

    select_rect(j, *maya.rect)

    z = p(*arg)

    if z:
        if not_empty(z):
            z = do_mod(z, d[rk.RW1][de.MOD])
    return z


def do_plan_matter(maya):
    """
    Create a Plan Background layer.

    maya: Plan
    Return: matter layer
        Simulate a Background layer.
    """
    z = make_background_layer(maya)

    select_rect(Run.j, *Wip.get_rect())
    color_selection_default(z, (0, 0, 0))
    return z


def make_background_layer(maya):
    """
    Create a Background image layer during a view run.

    maya: Maya
    Return: layer
        Is new.
    """
    return add_wip_layer(
        "Background Empty", maya.group, offset=len(maya.group.layers)
    )


def make_plan_group():
    """
    Make a Background group for a plan-view-type view.

    Return: group layer
        black background
    """
    return make_group_layer(Run.j, PlanZ.plan_group, 0, de.BACKGROUND)


def make_work_group():
    """
    Make a Background group layer during a work-view-type view.

    Return: group layer
        Is for Background output.
    """
    a = int(bool(PlanZ.plan_group))
    return make_group_layer(Run.j, None, a, de.BACKGROUND)


class Background(ManyGroup):
    """
    Create Widget group and assign a Background
    step processor for each view run type.
    """
    image_slot_count = 1
    image_k_path = de.BACKGROUND,

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)
        self.latch(self, (si.GROUP_CHANGE, ref_on_group_change))

    @staticmethod
    def get_image_d(d):
        """
        Return the Background/Image Choice Preset if its use.

        d: dict
            Background Preset
        """
        if d[de.TYPE] == de.IMAGE:
            e = d[de.IMAGE_CHOICE]
            if e[de.SWITCH]:
                return e

    @staticmethod
    def get_keys():
        """
        Return a list of image reference key.
        There is no Mask or Frame reference.
        """
        # 'None' is a key value here and not an empty.
        return [None]


class Chi(Maya, Main):
    """Factor Plan and Work."""
    issue_q = 'matter',

    def __init__(self, any_group, view_i, q):
        """
        any_group: AnyGroup
            Is the owner of Background Preset Widget.

        view_i: int
            plan or work; 0 or 1; view-type index

        q: iterable
            layer output function
            the Maya's 'put' attribute
        """
        Maya.__init__(self, any_group, view_i, q, ())
        Main.__init__(self)


class Plan(Chi):
    """Manage the Background layer output for Draft and Plan views."""
    put = (check_plan_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, Plan.put)
        self.do_matter = do_plan_matter

    def do(self):
        """
        Manage Background output during a view run.

        Return: None
            for undo
        """
        self.realize_vote()


class Work(Chi):
    """Manage the Background layer output for Peek and Preview views."""
    is_seeded = True
    issue_q = 'matter',
    put = (check_work_group, 'group'), (check_matter, 'matter'),

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Is the Background option group.
        """
        self.viewed_image = None

        # work-view-type index, '1'
        Maya.__init__(
            self,
            any_group,
            1,
            Work.put,
            [
                (),
                (de.IMAGE_CHOICE,),
                (rk.RW1, de.MOD),
                (rk.RW1, de.MOD, de.BLUR_D)
            ]
        )
        Main.__init__(self)

        self.do_matter = do_matter
        self.sub_maya[sm.ADD] = AddAbove(
            any_group, self, (rk.RW1, de.ADD_ABOVE)
        )
        self.sub_maya[sm.BULB] = Bulb(any_group, self, de.BACKGROUND)

    def do(self):
        """
        Manage the Background layer during a view run.

        Return: bool
            Is True if Background matter has change.
        """
        d = self.value_d = self.any_group.get_value_d()

        self.prep()
        self.realize()
        self.sub_maya[sm.ADD].do(
            d[rk.RW1][de.ADD_ABOVE], self.is_matter, self.is_matter
        )
        self.sub_maya[sm.BULB].do(self.is_matter)
        self.reset_issue()

    def prep(self):
        """
        Determine if the Background image changed since the last view.
        If there is change update the matter change flag.
        """
        j = self.viewed_image
        j1 = self.viewed_image = ref_get_image(self.any_group, None, 0)
        self.is_matter |= j != j1
