#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_step import get_first_part

# Note that a Model-name-step-key uses a model name
# (e.g. '(Table 1, Cell, Type)' is a Model-name-step-key.).


class Shelf:
    """Manage the offline dictionary that ModelList loads."""
    # {Model-name-step-key: Preset value dict}
    _d = {}

    @staticmethod
    def clear_shelf():
        Shelf._d.clear()

    @staticmethod
    def finds(k):
        """
        Determine if a Model-name-step-key is shelved.

        k: string
            Model-name-step-key

        Return: bool
            Is True if the key is shelved.
        """
        return bool(k in Shelf._d)

    @staticmethod
    def get_model_only_step_list(n):
        """
        Create a list of a Model's Model-name-step-key.

        n: string
            Model name
            Only step with this model name will be returned.

        Return: list
            [Model-name-step-key,]
        """
        # # Model-name-step-key, 'i'
        return [i for i in Shelf._d.keys() if n == get_first_part(i)]

    @staticmethod
    def get_shelf_d():
        """
        Make a copy of the shelf dict.

        Return: dict
            shelf dict copy
        """
        return deepcopy(Shelf._d)

    @staticmethod
    def get_step_d(k):
        """
        Fetch the shelved Preset for a Model-name-step-key.

        k: string
            Model-name-step-key

        Return: dict or None
            Is a Preset value dict.
        """
        if k in Shelf._d:
            return Shelf._d[k]

    @staticmethod
    def get_step_list():
        """
        Fetch a list of shelved Model-name-step-key.

        Return: list
            [Model-name-step-key, ...]
        """
        return Shelf._d.keys()

    @staticmethod
    def remove_model(k):
        """
        Remove step having a Model name reference from the shelf dict.

        k: string
            Model name key
        """
        d = Shelf._d

        # Model-name-step-key, 'i'
        for i in d.keys():
            # index of a model name in a Model-name-step-key, '0'
            if k == get_first_part(i):
                d.pop(i)

    @staticmethod
    def remove_step(k):
        """
        Remove a Model-name-step-key from the shelf dict.

        k: string
            Model-name-step-key
        """
        if k in Shelf._d:
            Shelf._d.pop(k)

    @staticmethod
    def rename_model(p, old_name, new_name):
        """
        Rename a Model. Find and replace the old name with the new name.

        p: function
            Call to rename step.
        """
        p(Shelf._d, old_name, new_name)

    @staticmethod
    def set_d(d):
        """
        Set the Shelf dict from a new dict.

        d: dict
            {Model-name-step-key: value dict}
        """
        Shelf._d = d

    @staticmethod
    def set_step(k, a):
        """
        Set the value of a Model-name-step-key in the shelf dict.

        k: string
            Model-name-step-key

        a: value
            Is the value of the step's Preset.
        """
        Shelf._d[k] = a
