#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_identity import Identity as de

"""Define Widget tooltip."""

_ACCEPT = " Accept and show cell to the "
_REQUIRE = " Requires the Cell/Margin step. "
_DEPENDENT = " Uses the Background layer. "
_INDEPENDENT = " Doesn't use the Background layer. "
_MEAN_DEPENDENT = " The Type/Mean Color is dependent on the Background layer. "


class Tip:
    """Has tooltip text string."""
    ADD_SHIFT_XY = \
        " After the first cell, each cell's position \n" \
        " is offset by this amount from the prior \n" \
        " cell in the cell sequence. "
    AMP = " A higher value to increases the roughness. "
    AUTOCROP = " Crop empty space around an image. "
    AZIMUTH = " The light angle is used by emboss. "
    BELOW_TYPE = " The layer above is the source of the mask. "
    BLEND = " A higher value to reduces textural variation. "
    BLUR_POST = " Blur after the emboss to clear artifact. "
    BLUR_PRE = " Blur before the emboss to soften edge. "
    BOX_TYPE = " The direction of the cap determines the type. "
    BRUSH_SIZE = " process time: less scale > more scale  "
    CAP_X = \
        " Move the inner cap vertex along the \n" \
        " x-axis by this factor of the box width. "
    CAP_Y = \
        " Move the inner cap vertex along the \n" \
        " y-axis by this factor of the box height. "
    CELL_SIZE = \
        " The canvas space is divided by this \n" \
        " to derive the row and column count. "
    CLIP = " Clip the internal frame output. "
    CLIP_FRINGE = " Clip Fringe inside its selection-stroke. "
    COLOR = " Red\t{} \n Green\t{} \n Blue\t{} "
    COLOR_COUNT = " Is the number of potential colors. "
    COLOR_INDENT = " \tRed \t{} \n \tGreen\t{} \n \tBlue\t{} "
    COLOR_RGBA = COLOR + "\n Alpha\t{}"
    COLOR_RGBA_INDENT = COLOR_INDENT + "\t\n\tAlpha\t{}"
    CONTRACT = " Move the brush stroke inward toward the center. "
    CROP_X = \
        " Crop the image with a rectangle \n" \
        " defined by X, Y, Width, and Height. "
    DEGREES = " degrees "
    DELETE_MODEL = " Delete the selected model (Delete). "
    DELETE_PLAN = " Remove the Plan output after rendering. "
    DISTRESS = " Stress the frame more with a higher value. "
    DRAFT_BUTTON = " Plan steps up to the visible option group. "
    ELEVATION = " Increase value to lighten emboss output. "
    END_X = " Add to the x-axis end coordinate. "
    END_Y = " Add to the y-axis end coordinate. "
    FACTOR_H = " Multiply by the render height and add to the result. "
    FACTOR_W = " Multiply by the render width and add to the result. "
    FEATHER = \
        " The initial feather is this number divided \n" \
        " by steps. Subsequent steps add the initial \n" \
        " value to the feather. This value becomes the \n" \
        " feather amount applied on the last step. "
    FILL_MODE = "Is the paint mode used by the bucket fill. "
    FIXED_W = " Resize the image to these dimensions. "
    FLIP = " Flip the entire layer. "
    FONT_SIZE = " Is for Draft/Plan text output. "
    FRINGE_MASK = " Paint brush strokes around the edge masking the material. "
    GRID_TYPE = " Effect the shape and size of a cell's bounding rectangle. "
    HEIGHT_MOD = " Modify the image height by this amount. "
    HIDE_LAYER = " Hide Layers in the dock for faster processing. "
    IMAGE_NAME = \
        " The order of image name list is \n" \
        " from GIMP's open image order. "
    INDENT = " Make the grid's first cell position be row 1, column 2. "
    INVERT = \
        " Invert the mask making it cut-out instead of cut-around. "
    LAYER_ORDER = \
        " Is the direction of the layer-tree iteration. \n" \
        " With top-down, the first layer is the \n" \
        " layer at the top of the layer tree. \n" \
        " If top-down is off, then the order is \n" \
        " bottom-up, and the first layer is \n" \
        " the bottom layer in the tree. "
    INTENSITY = " Modify the shadow opacity. "
    INWARD = " Make Facing output face toward the center. "
    KEEP = " Have GIMP save a new gradient. "
    LAYERED = \
        " The image's layers are iterated as a tree, \n" \
        " where each layer becomes an image reference. "
    LEAD = " Prefix the output. "
    LENGTH_SHIFT = " Randomize the pixel length of a tape strip. "
    LOOP_MINUS = \
        " Assign an image using a circular-type index variable. \n" \
        " Loop Minus decrements after assigning an image. \n" \
        " It's index rolls-over to the last open image after \n" \
        " the first open image. Both Loop Plus and Loop \n" \
        " Minus use the same index variable. If the Minus \n" \
        " option is used before the Plus option, then the \n" \
        " last open image is the first image reference. "
    LOOP_PLUS = \
        " Assign an image using a circular-type index variable. \n" \
        " Loop Plus increments after assigning an image. \n" \
        " The index rolls-over to the first open image after \n" \
        " the last open image. Both Loop versions use the same \n" \
        " index variable. If the Plus index is used before the \n" \
        " Minus index, then the first open image is the first \n" \
        " image reference. "
    MATERIALIZE = \
        " Include an output-type layer to receive a light-layer. "
    MERGE_CELL = " X:\t\t{} \n Y:\t\t{} \n Width:\t{} \n Height:\t{} "
    MESH_SIZE = " process time: less scale < more scale  "
    MODEL_LIST_NEW = " Make a new model. "
    MODEL_LIST_TREE = " active model in inverted layer order "
    MODEL_LIST_TYPE = {
        de.BOX:
            " Arrange double-spaced box-shaped \n"
            " cell by row and column. ",
        de.CELL: " Define a cell. ",
        de.PYRAMID: " Define cell in a triangular-shaped stack. ",
        de.SIDEWALK:
            " Arrange cell in an hollow rectangle. \n"
            " Resembles the Monopoly game layout. ",
        de.STACK: " Layer cell in a stack. ",
        de.TABLE: " Arrange cell by row and column. "
    }
    MOVE_UP = MOVE_DOWN = " Change the order of Model output. "
    MOVE_LEFT = " Remove the selected item from the interface. "
    MOVE_RIGHT = " Move the selected item to the interface. "
    NAVIGATION = (
        _ACCEPT + "north (ctrl ↑) ",
        _ACCEPT + "south (ctrl ↓) ",
        _ACCEPT + "west (ctrl ←) ",
        _ACCEPT + "east (ctrl →) "
    )
    OBEY_MARGIN = " Constrict output with branch margin. "
    OPAQUE = " Make the blur's mask source opaque. "
    OPTION_LIST = {
        # Accent
        de.ACRYLIC_SKY: _DEPENDENT,
        de.BACK_GAME: _MEAN_DEPENDENT,
        de.CLAY_CHEMISTRY: _DEPENDENT,
        de.COLOR_FILL: _DEPENDENT,
        de.COLOR_GRID: _MEAN_DEPENDENT,
        de.CORNER_OVERLAP: _MEAN_DEPENDENT,
        de.CUBE_PATTERN: _INDEPENDENT,
        de.CUBISM_COVER: _DEPENDENT,
        de.CRYSTAL_CAVE: _INDEPENDENT,
        de.DARK_FORT: _INDEPENDENT,
        de.FADING_MAZE: _INDEPENDENT,
        de.DENSITY_GRADIENT: _INDEPENDENT,
        de.DROP_ZONE: _MEAN_DEPENDENT,
        de.ETCH_SKETCH: _DEPENDENT,
        de.FLOOR_SAMPLE: _MEAN_DEPENDENT,
        de.GALACTIC_FIELD: _DEPENDENT,
        de.GLASS_GAW: _INDEPENDENT,
        de.GRADIENT_FILL: _INDEPENDENT,
        de.HISTORIC_TRIP: _DEPENDENT,
        de.LINE_STONE: _DEPENDENT,
        de.LOST_MAZE: _INDEPENDENT,
        de.MAZE_BLEND: _DEPENDENT,
        de.MEAN_COLOR: _DEPENDENT,
        de.GRATE_MYSTERY: _INDEPENDENT,
        de.NOISE_RIFT: _INDEPENDENT,
        de.PAPER_WASTE: _DEPENDENT,
        de.PATTERN_FILL: _INDEPENDENT,
        de.RAINBOW_VALLEY: _DEPENDENT,
        de.RECT_PATTERN: _INDEPENDENT,
        de.ROCKY_LANDING: _INDEPENDENT,
        de.ROOF_TOP: _INDEPENDENT,
        de.SOFT_TOUCH: _DEPENDENT,
        de.SPECIMEN_SPECKLE: _DEPENDENT,
        de.SPIRAL_CHANNEL: _INDEPENDENT,
        de.SQUARE_CLOUD: _DEPENDENT,
        de.STONE_AGE: _DEPENDENT,
        de.TRAIL_VINE: _INDEPENDENT,
        de.TRIANGLE_REVERB: _MEAN_DEPENDENT,
        de.WAVE_FILL: _MEAN_DEPENDENT
    }
    PER_CHECK_BUTTON = " Define option as either main or per. "
    PER_BUTTON = " Open a per option table. "
    PEEK_BUTTON = " Preview steps up to the visible option group (ctrl-e). "
    PERCENTILE = " darker < 50% < lighter "
    PIN = " Justify the cell grid. "
    PIXELS = " pixels "
    PLAN_BORDER = " Show Border material in Draft/Plan output. "
    PLAN_BUTTON = " Draw a plan graph using the Planner options. "
    PLAN_CELL_SHAPE = " Draw cell shape outline. \n" + _REQUIRE
    PLAN_CORNER = \
        " Display the bottom-left and top-right \n" \
        " coordinate of a cell's position. \n" + _REQUIRE
    PLAN_POSITION = \
        " Display the topleft coordinate of a cell's position. \n" \
        + _REQUIRE
    PLAN_DIMENSION = " Display the size of a cell. " + _REQUIRE
    PLAN_GRID = " Draw the model's grid. "
    PLAN_IMAGE_NAME = \
        " Show the name of image assigned to a cell. \n " \
        " Is dependent on the Planner/Image option \n " \
        " and an Image step. "
    PLAN_RATIO = " Display the cell's position ratio. \n" + _REQUIRE
    POWER = " Increase cloud material with a higher value. "
    PREVIEW_BUTTON = " Make a render using the navigation tree (ctrl-p). "
    RADIUS_DRIP = " Spread drip across transparent to opaque edge. "
    RENAME_MODEL = " Rename the selected model (F2). "
    REVISE_MODEL = " Revise available step for the selected active model. "
    REVERSE = " Reverse the order of the gradient colors. "
    SCATTER_COUNT = " Is the number of mazes to draw. "
    SEED = " Randomized output uses this an init value. "
    SEED_GLOBAL = " Add to any random seed. "
    SELECT = " the layer's alpha ", " the image rectangle "
    SHIFT_H = " Randomize the image's height (+/-). "
    SHIFT_W = " Randomize the image's width (+/-). "
    SHIFT_X = " Randomize the image's x position (+/-). "
    SHIFT_Y = " Randomize the image's y position (+/-). "
    SLICE = " Cut an image into rectangles using row and column values. "
    SLIDER_INT_PART = " Add to the result with the factored calculation. "
    SPIRAL_DISTANCE = " Lower the value to increase the spiral count. "
    SPREAD = " Increase scattering. "
    START_NUMBER = " Set the first number of the sequence. "
    STEP = " Add and remove step from the navigation tree. "
    STEPS = " Repeat feather. "
    STEPS_DROP_ZONE = " Is the number of colors in the resulting gradient. "
    STRIP_H = " Factor the caption's text height. "
    TAB = \
        " The order of the numeric list is \n" \
        " from GIMP's open image order. "
    THRESHOLD = \
        " A threshold of 1.0 is a match all, \n" \
        " and a threshold of 0.0 is to match none. "
    TRAIL = " Suffix the output. "
    UPSCALE = " Randomize brush size with an additional random factor. "
    UP_SPACE = " Randomize brush spacing with an additional random factor. "
    WH_FACTOR = " Scale of the image by a factor. "
    WHIRL = " Spin the material around the center of the image. "
    WIDTH_MOD = " Modify the image width by this amount. "
    WIP = " Scale the image size. Improve the render's edge-case output. "
