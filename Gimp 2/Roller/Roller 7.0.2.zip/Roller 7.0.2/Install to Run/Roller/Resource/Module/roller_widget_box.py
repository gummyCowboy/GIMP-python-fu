#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Color as co, Define as df
import gtk  # type: ignore

# {Widget key: value}
DEFAULT_ATTR_D = {
    df.ALIGN: (0, 0, 0, 0),
    df.BOX: gtk.VBox,
    df.PADDING: (0, 0, 0, 0)
}


class Box(gtk.Alignment):
    """Is a gtk Box widget with an gtk Alignment. Import as 'boxer'."""

    def __init__(self, **d):
        """
         keys:
            box_type: class
                either VBox, HBox, VButtonBox, HButtonBox

            align: tuple
                of float
                top, bottom, left, right
                Alignment
                in .0 to 1.

            padding: tuple of int
                top, bottom, left, right
        """
        super(gtk.Alignment, self).__init__()

        # Insure Box attribute.
        for k in DEFAULT_ATTR_D:
            a = d[k] if k in d else DEFAULT_ATTR_D[k]
            setattr(self, k, a)

        self.box = self.box()

        self.set(*self.align)
        self.set_padding(*self.padding)
        super(gtk.Alignment, self).add(self.box)

    def add(self, g):
        """
        Add a Widget to the Box.

        g: gtk widget
            Add to Box.
        """
        self.box.add(g)

    def get_children(self):
        return self.box.get_children()

    def pack_start(self, g, **d):
        """
        Place a Widget in the Box.

        g: gtk widget
            Is packed into this container.

        d: dict
            keyword options
        """
        self.box.pack_start(g, **d)


class Eventful(gtk.EventBox):
    """Is a gtk EventBox with a color option."""

    def __init__(self, color):
        """
        color: None, int, tuple, or gtk color
            Is the background color for the container.
        """
        super(gtk.EventBox, self).__init__()

        self.color = color
        if color is not None:
            if isinstance(color, int):
                q = gtk.gdk.Color(color, color, co.MAX_COLOR)

            elif isinstance(color, tuple):
                q = gtk.gdk.Color(*color)

            else:
                q = color
            self.modify_bg(gtk.STATE_NORMAL, q)


class ColorHBox(Eventful):
    """Is a gtk HBox with a color background."""

    def __init__(self, color):
        """
        color: gtk color
            Is the background color for the HBox.
        """
        Eventful.__init__(self, color)

        self.hbox = gtk.HBox()
        super(Eventful, self).add(self.hbox)

    def add(self, widget):
        """
        Add an object to the gtk Hbox.

        widget: object
            Add to the HBox.
        """
        self.hbox.add(widget)

    def pack_start(self, g, **kwarg):
        """
        Connect to the HBox function.

        g: object
            Is packed.

        kwarg: dict
            for the VBox function
        """
        self.hbox.pack_start(g, **kwarg)


class ColorVBox(Eventful):
    """Is a gtk VBox with a color background."""

    def __init__(self, color):
        """
        color: gtk color
            Is the background color for the HBox.

        is_node: bool
            Is true when the container is for a Node.
        """
        Eventful.__init__(self, color)

        self.vbox = gtk.VBox()
        super(Eventful, self).add(self.vbox)

    def add(self, widget):
        """
        Add an object to the gtk Hbox.

        widget: object
            Add to the HBox.
        """
        self.vbox.add(widget)

    def pack_end(self, g, **kwarg):
        """
        Connect to the VBox function.

        g: object
            Is packed.

        kwarg: dict
            for the VBox function
        """
        self.vbox.pack_end(g, **kwarg)

    def pack_start(self, g, **kwarg):
        """
        Provide a connection to the VBox function.

        g: object
            Is packed.

        kwarg: dict
            for the VBox function
        """
        self.vbox.pack_start(g, **kwarg)
