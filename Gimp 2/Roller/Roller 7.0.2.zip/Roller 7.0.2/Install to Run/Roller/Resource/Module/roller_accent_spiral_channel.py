#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import LAYER_MODE_DIFFERENCE, pdb  # type: ignore
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Cat, Run
from roller_gimp_gradient import create_dual_gradient, draw_gradient
from roller_gimp_image import (
    add_layer,
    add_sub_maya_group,
    clip_to_wip,
    create_image,
    make_group_layer,
    paste_layer_into
)
from roller_gimp_item import get_item_size
from roller_gimp_layer import clone_layer, flip_layer
from roller_maya_sub_accent import SubAccent
from roller_wip import Wip

HORZ_SET = {de.HORIZONTAL_FLIP, de.FLIP_BOTH}
VERT_SET = {de.VERTICAL_FLIP, de.FLIP_BOTH}


def get_layer_points(d, w, h):
    """
    Return the layer points for start and end coordinates.

    d: dict
        Has start and end points.
        factor layer points
        in .0 to 1.

    w, h: float
        size of render or canvas

    Return:
        start and end coordinates
        x, y, x1, y1
    """
    x = d[de.START_X] * w
    y = d[de.START_Y] * h

    if de.END_X in d:
        x1 = d[de.END_X] * w
        y1 = d[de.END_Y] * h

    else:
        x1 = y1 = 0
    return x, y, x1, y1


def do_matter(maya):
    """
    Make a matter layer. The main process is to draw a spiral
    gradient at the center of an image tile, then tile the output.

    maya: SpiralChannel
    Return: layer
        SpiralChannel 'matter'
    """
    j = j1 = Run.j
    d = maya.value_d
    group = add_sub_maya_group(maya)

    # A WIP layer fails.
    z = add_layer(j, group, 0, "Base")

    e = maya.gradient_d

    if d[de.GRADIENT_DIRECTION] == de.COUNTER_CLOCKWISE:
        e[de.GRADIENT_TYPE] = de.SPIRAL_COUNTER_CW

    else:
        e[de.GRADIENT_TYPE] = de.SPIRAL_CLOCKWISE

    e[de.END_X] = .5 + d[de.SPIRAL_DISTANCE]
    color = d[de.COLOR_1]

    # The color inverts when using the difference mode.
    # This reverses that.
    if d[de.SPIRAL_MOD] != "None":
        color = tuple([255 - i for i in d[de.COLOR_1]])

    grad = e[de.GRADIENT] = create_dual_gradient(
        "Spiral Channel", color, (255, 255, 255)
    )
    e[de.OFFSET] = 0
    is_tile = False
    left_x, top_y, w, h = Wip.get_rect()
    row, column = map(int, (d[de.ROW], d[de.COLUMN]))

    if row > 1 or column > 1:
        is_tile = True
        w = w // column
        h = h // row
        j1 = create_image(int(w), int(h))
        z = add_layer(j1, None, 0, "Tile")
        pdb.gimp_image_set_active_layer(j1, z)

    x, y, x1, y1 = get_layer_points(e, w, h)

    if not is_tile:
        x += left_x
        y += top_y
        x1 += left_x
        y1 += top_y

    z = draw_gradient(z, e, x, y, x1, y1)

    if d[de.SPIRAL_MOD] != "None":
        z = clone_layer(z)
        z.mode = LAYER_MODE_DIFFERENCE

        if d[de.SPIRAL_MOD] in HORZ_SET:
            flip_layer(z, is_h=True)
        if d[de.SPIRAL_MOD] in VERT_SET:
            flip_layer(z)

    if is_tile:
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

        tiles = make_group_layer(j, group, 0, "Tiles")
        x = left_x
        y = top_y

        # column tiling
        z = first = paste_layer_into(j, tiles)
        pdb.gimp_image_reorder_item(j, z, tiles, 0)

        for c in range(column):
            if c:
                z = clone_layer(first)
                x = (c * w) + left_x

            if c % 2:
                flip_layer(z, is_h=True)
            pdb.gimp_layer_set_offsets(z, int(x), int(y))

        z = first = pdb.gimp_image_merge_layer_group(j, tiles)

        # row tiling
        if row > 1:
            tiles = make_group_layer(j, group, 0, "Tiles", z=z)
            x = left_x

            for r in range(row - 1):
                z = clone_layer(first)

                if not r % 2:
                    flip_layer(z)

                y += h
                pdb.gimp_layer_set_offsets(z, int(x), int(y))
            z = pdb.gimp_image_merge_layer_group(j, tiles)

        w1, h1 = get_item_size(z)
        w, h = Wip.get_size()
        if (w, h) != (w1, h1):
            w = (w - z.width) / 2. + left_x
            h = (h - z.height) / 2. + top_y
            pdb.gimp_layer_set_offsets(z, int(w), int(h))

    z = pdb.gimp_image_merge_layer_group(j, group)

    # Remove the newly created gradient.
    pdb.gimp_gradient_delete(grad)
    Cat.gradient_list.pop(-1)
    clip_to_wip(z)
    return maya.finish(z, d[rk.BRW])


class SpiralChannel(SubAccent):
    """Create Accent output."""
    kind = de.SPIRAL_CHANNEL

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, False, is_old)

        d = self.gradient_d = {}
        d[de.OFFSET] = d[de.REVERSE] = 0
        d[de.START_X] = d[de.START_Y] = d[de.END_Y] = .5
