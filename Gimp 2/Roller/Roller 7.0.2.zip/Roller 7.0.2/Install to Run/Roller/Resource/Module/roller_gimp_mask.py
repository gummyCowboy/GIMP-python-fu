#!/usr/bin/env python
# -*- coding: utf-8 -*-
# noinspection PyUnresolvedReferences
from gimpfu import (   # type: ignore
    ADD_MASK_BLACK, ADD_MASK_SELECTION, CHANNEL_OP_ADD, pdb
)
from roller_container import Run
from roller_gimp_layer import discard_mask, select_layer


def mask_from_maya(alpha, sub_z, p=select_layer):
    """
    Mask a layer from multiple Maya 'matter' layer alpha.

    alpha: Maya
        Its 'Maya.matter' layer's alpha creates the mask.

    sub_z: layer or None
        Is the layer to receive the mask.

    p: function
        Select source layer.

    Return: layer
        mask
    """
    if sub_z:
        pdb.gimp_selection_none(Run.j)

        z = alpha.matter

        if z:
            p(z, option=CHANNEL_OP_ADD)
        mask_selection(sub_z)


def mask_selection(z):
    """
    Make a mask for a layer from a selection.
    Call with a selection already in place.

    z: layer
        to receive mask
    """
    if z:
        discard_mask(z)
        if not pdb.gimp_selection_is_empty(z.image):
            z.add_mask(pdb.gimp_layer_create_mask(z, ADD_MASK_SELECTION))
        else:
            # There is no source for the mask, so mask everything.
            z.add_mask(pdb.gimp_layer_create_mask(z, ADD_MASK_BLACK))


def mask_sub_maya(source_z, sub_z):
    """
    Make a mask for a sub-Maya matter layer from a source layer's alpha.

    source_z: layer
        Derive a mask from the layer's alpha material.

    sub_z: layer or None
        Receive the mask.

    Return: layer
        mask
    """
    if sub_z and source_z:
        select_layer(source_z)
        mask_selection(sub_z)
