#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_comm import show_err
from roller_constant import Plan as ak, Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_deco import ready_canvas_rect, ready_shape
from roller_gimp_context import set_foreground, set_gimp_brush
from roller_gimp_image import add_layer
from roller_gimp_layer import (
    color_selection, select_layer, verify_layer
)
from roller_preset import get_line_fill_state
from roller_gimp_selection import select_shape
from roller_preset_mod import do_mod
from roller_step import get_branch_part


def add_line_layer(j, maya):
    """
    Add a layer named after "Material" to the top of the Maya's group.

    j: GIMP image
        Is render.

    maya: Maya
    Return: layer
        newly added
    """
    return add_layer(j, maya.group, maya.get_light(), "Material")


def color_brush_layer(z, d):
    """
    If the Line stroke-method is the paint-method, then the stroked
    output needs to be colored with the Line/Color option value.

    Given a layer with stroked output, select it, and fill the selection
    using the Line Preset's Color option.

    z: layer
        Has Line output made with the brush-method.

    d: dict
        Line Preset
    """
    if get_line_fill_state(d):
        select_layer(z)
        if not pdb.gimp_selection_is_empty(z.image):
            color_selection(z, d[de.COLOR_1])


def do(maya, make):
    """
    Create Line for a navigation branch.

    maya: Maya
    Return: layer or None
        Line material
    """
    # Line Preset, 'd'
    d = maya.value_d

    if not Run.i:
        # Preserve.
        mode = d[de.MODE]
        color = d[de.COLOR_1]

        # Plan override.
        d[de.MODE] = "Normal"
        d[de.COLOR_1] = {
            de.CANVAS: ak.CANVAS_LINE_COLOR,
            de.CELL: ak.CELL_LINE_COLOR,
            de.FACE: ak.FACE_LINE_COLOR,
            de.FACING: ak.FACE_LINE_COLOR
        }[get_branch_part(maya.any_group.type_step_k)]

    z = make(maya, d)

    if z:
        do_mod(z, d[rk.BRW][de.MOD])

    if not Run.i:
        # Restore.
        d[de.MODE] = mode
        d[de.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Draw Canvas/Line.

    maya: Maya
    Return: layer or None
        Line material
    """
    return do(maya, make_canvas)


def do_cell_main(maya):
    """
    Draw Cell/Line/Per.

    maya: Maya
    Return: layer or None
        Line material
    """
    return do(maya, make_cell_main)


def do_cell_per(maya):
    """
    Draw Cell/Line/Per.

    maya: Maya
    Return: layer or None
        Line material
    """
    return do(maya, make_cell_per)


def do_facial_main(maya):
    """
    Draw Face or Facing Line/Per.

    maya: Maya
    Return: layer or None
        Line material
    """
    return do(maya, make_facial_main)


def do_facial_per(maya):
    """
    Draw Line for Face or Facing/Line/Per.

    maya: Maya
    Return: layer or None
        Line material
    """
    return do(maya, make_facial_per)


def make_canvas(maya, d):
    """
    Draw Canvas/Line material.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        Line material
    """
    j = Run.j
    z = add_line_layer(j, maya)

    ready_canvas_rect(maya, d)

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)

    color_brush_layer(z, d)
    return verify_layer(z)


def make_cell_main(maya, d):
    """
    Create material Cell/Line main.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        Line material
    """
    j = Run.j
    z = add_line_layer(j, maya)

    prep_line(d)

    # cell key, 'k'
    for k in maya.main_q:
        maya.k = k
        ready_shape(maya, d)
        if not pdb.gimp_selection_is_empty(j):
            pdb.gimp_drawable_edit_stroke_selection(z)

    color_brush_layer(z, d)
    return verify_layer(z)


def make_cell_per(maya, d):
    """
    Make output for Cell/Line/Per.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        Line material
    """
    j = Run.j
    z = add_line_layer(j, maya)

    ready_shape(maya, d)

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)

    color_brush_layer(z, d)
    return verify_layer(z)


def make_facial_main(maya, d):
    """
    Make output for Face or Facing Line/Per.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        Line material
    """
    j = Run.j
    z = add_line_layer(j, maya)

    prep_line(d)

    for k in maya.main_q:
        select_shape(j, maya.model.get_facing_shape(k))
        if not pdb.gimp_selection_is_empty(j):
            # Can throw an error if the image size is too small.
            try:
                pdb.gimp_drawable_edit_stroke_selection(z)
            except Exception as ex:
                show_err(ex)

    color_brush_layer(z, d)
    return verify_layer(z)


def make_facial_per(maya, d):
    """
    Make output for Face or Facing Line/Per.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        Line material
    """
    j = Run.j
    z = add_line_layer(j, maya)

    select_shape(j, maya.model.get_facing_shape(maya.k))

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)
    return verify_layer(z)


def prep_line(d):
    """
    Prepare to draw Line.

    d: dict
        Line Preset
    """
    pdb.gimp_context_set_stroke_method(d[de.METHOD])
    pdb.gimp_context_set_antialias(1)

    if get_line_fill_state(d):
        # brush
        pdb.gimp_context_set_brush_size(d[de.WIDTH])
        set_gimp_brush(d[de.BRUSH])
        pdb.gimp_context_set_brush_angle(.0)
        pdb.gimp_context_set_brush_hardness(d[de.HARDNESS])

    else:
        # line
        pdb.gimp_context_set_line_width(d[de.WIDTH])

    pdb.gimp_context_set_opacity(100.)
    set_foreground(d[de.COLOR_1])
