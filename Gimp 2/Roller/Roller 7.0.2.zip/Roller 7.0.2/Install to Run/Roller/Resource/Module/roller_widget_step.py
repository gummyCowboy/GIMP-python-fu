#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Color as co, Define as df, Signal as si
from roller_constant_identity import Identity as de
from roller_tooltip_text import Tip
from roller_widget import set_widget_attr
from roller_widget_button import Button
from roller_widget_label import Label
from roller_widget_tree import get_treeview_item, TreeViewList
import gtk  # type: ignore

MODEL_GROUP = (
    de.BORDER,
    de.CAPTION,
    de.FRINGE,
    de.IMAGE,
    de.LINE,
    de.MARGIN,
    de.PLAQUE,
    de.RECTANGLE,
    de.SHIFT,
    de.TYPE
)


class Step(gtk.Alignment, object):
    """
    Compose the user interface with a Model step
    filter. A Model step can be shelved or active.
    """

    def __init__(self, shelf_set, active_set, **d):
        """
        branch_set: list
            [Model branch, ...]

        d: dict
            Has option.
        """
        super(gtk.Alignment, self).__init__()
        set_widget_attr(self, d)

        self.relay = d[df.RELAY]
        self._active_set = active_set
        self._shelf_set = shelf_set
        hbox = gtk.HBox()

        hbox.add(gtk.Label("\n" * 22))

        d[df.SCROLL] = 1
        d[df.PADDING] = 4, 4, 4, 4
        d[df.TREE_COLOR] = d[df.COLOR]
        d[df.COLOR] = co.LIST_CELL_COLOR
        d[df.MINIMUM_W] = 100

        self._draw_shelf_tree(hbox, **d)
        self._draw_move_button(hbox, **d)
        self._draw_nav_tree(hbox, **d)
        self.add(hbox)
        self._init_list()

        # Trigger a change signal.
        self._shelf_tree.select_r(0)

        self._verify_buttons()

    def _draw_move_button(self, hbox, **d):
        """
        Draw a list for selected Model item.

        hbox: GTK HBox
            Contain the list.

        d: dict
            Initialize the list.
        """
        vbox = gtk.VBox()
        d[df.TEXT] = gtk.Arrow(gtk.ARROW_LEFT, gtk.SHADOW_NONE)
        d[df.TOOLTIP] = Tip.MOVE_LEFT
        d[df.RELAY] = self.relay[:] + [self.on_move_left_action]
        self.move_left = Button(**d)
        d[df.TEXT] = gtk.Arrow(gtk.ARROW_RIGHT, gtk.SHADOW_NONE)
        d[df.TOOLTIP] = Tip.MOVE_RIGHT
        d[df.RELAY] = self.relay[:] + [self.on_move_right_action]
        self.move_right = Button(**d)

        vbox.pack_start(Label(**{df.TEXT: " "}), expand=False)
        vbox.add(self.move_right)
        vbox.add(self.move_left)
        hbox.add(vbox)

    def _draw_nav_tree(self, hbox, **d):
        """
        Draw a Navigation list for Model item. Items in an accepted
        Use list are integrated into the navigation tree.

        hbox: GTK HBox
            Is the container for the list.

        d: dict
            Initialize the navigation list.
        """
        vbox = gtk.VBox()
        d[df.RELAY] = self.relay[:]

        d[df.RELAY].insert(0, self.on_step_list_change)

        # Has step for the interface navigation tree, '_nav_tree'.
        self._nav_tree = TreeViewList(**d)

        vbox.pack_start(Label(**{df.TEXT: de.ACTIVE}), expand=False)
        vbox.pack_start(self._nav_tree, expand=True)
        hbox.pack_start(vbox, expand=True)

    def _draw_shelf_tree(self, hbox, **d):
        """
        Draw a list of shelved Model item.

        hbox: GTK HBox
            Contain the list.

        d: dict
            Initialize the shelf list.
        """
        vbox = gtk.VBox()
        d[df.RELAY] = self.relay[:]

        d[df.RELAY].insert(0, self.on_model_list_change)

        # Has step for the offline dict, '_offline_tree'.
        self._shelf_tree = TreeViewList(**d)

        vbox.pack_start(Label(**{df.TEXT: de.SHELF}), expand=False)
        vbox.pack_start(self._shelf_tree, expand=True)
        hbox.pack_start(vbox, expand=True)

    def _init_list(self):
        """
        A Model has a step-key that is visible in the navigation tree
        or is available to add to that tree. Create two lists, one for
        the visible and the other for the available. Load each
        TreeViewList per its assignment.
        """
        self._shelf_tree.populate_item_list(sorted(list(self._shelf_set)))
        self._nav_tree.populate_item_list(sorted(list(self._active_set)))

    def _move_item(self, from_tree, to_tree):
        """
        Move an item from one TreeView to the other.

        from_tree: TreeViewList
        to_tree: TreeViewList
        """
        n = get_treeview_item(from_tree.treeview)

        if n is not None:
            from_tree.remove_row(from_tree.get_selected_r())

            if n not in to_tree.item_list:
                to_tree.insert_row(len(to_tree.item_list), n)

            i = len(n)

            # Transfer Node branch, 'q'.
            for q in from_tree.item_list[:]:
                if n in q[:i] and q[:i + 1][-1] == '.':
                    from_tree.remove_row(from_tree.get_item_row_number(q))
                    if q not in to_tree.item_list:
                        to_tree.insert_row(len(to_tree.item_list), q)

        self._verify_buttons()
        self.roller_win.emit(si.ACCEPT_FOCUS, None)

    def _verify_buttons(self):
        self._verify_left_button()
        self._verify_right_button()

    def _verify_left_button(self):
        """
        The left Button is dependent on a selection in the 'Use' TreeView.
        """
        self.move_left.set_sensitive(
            self._nav_tree.get_selected_r() is not None
        )

    def _verify_right_button(self):
        """
        The right Button is dependent on a selection in the 'Shelf' TreeView.
        """
        self.move_right.set_sensitive(
            self._shelf_tree.get_selected_r() is not None
        )

    def get_ui(self, is_all=False):
        """
        Retrieve the value of the TreeView.

        is_all: bool
            If its True, then the combined Shelf
            and Navigation lists to the caller.

        Return: list
            [Model-name-step-key, ...]
            The accepted value.
        """
        q = self._shelf_tree.item_list + self._nav_tree.item_list \
            if is_all else self._nav_tree.item_list
        return q

    def on_model_list_change(self, *_):
        """Respond to a change in the Model list."""
        self._verify_right_button()

    def on_move_left_action(self, *_):
        """
        Move the selected item from the 'Use' TreeView to the 'Shelf' TreeView.
        """
        self._move_item(self._nav_tree, self._shelf_tree)

    def on_move_right_action(self, *_):
        """
        Move the selected item from the 'Shelf' TreeView to the 'Use' TreeView.
        """
        self._move_item(self._shelf_tree, self._nav_tree)

    def on_step_list_change(self, *_):
        """Respond to a change in the 'Use' list."""
        self._verify_left_button()
