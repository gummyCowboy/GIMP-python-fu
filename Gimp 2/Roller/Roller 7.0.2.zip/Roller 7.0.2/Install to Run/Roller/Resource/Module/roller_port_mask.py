#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import Deco as dc, Mask as ms
from roller_constant_identity import Identity as de
from roller_port_preview import PortPreview
from roller_step import count_parts, get_branch_part
from roller_widget_dna import DNA

TRUE_ATTR_SET = {'make_vbox', 'preset', 'switched'}


class PortMask(PortPreview):
    """Display a Mask Preset for editing."""
    window_key = "Mask"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_mask_option(self, box):
        """
        Draw the Mask option group.

        box: VBox
            container for the option group
        """
        group = self.repo.any_group
        k = group.type_step_k
        dna = DNA(de.MASK, TRUE_ATTR_SET, {})

        dna.inherit(group.dna, False)
        box.add(dna.vbox)
        self.draw_group(dna)

        if (
            count_parts(k) >= 2 and
            get_branch_part(k) in dc.FACIAL_SET
        ):
            # Face and Facing have limited Mask Type.
            g = self.any_group.get_widget(de.TYPE)
            n = g.get_ui()

            g.populate_list(ms.FACE_TYPE_LIST)
            g.load_a(n)

    def draw(self):
        """
        Draw Widget.

        g: VBox
            Contain Widgets.
        """
        self.draw_column((self._draw_mask_option, self.draw_process))

    def get_group_value(self):
        """
        Get the Preset value.

        Return: dict
            Mask Preset
        """
        return self.any_group.get_value_d()
