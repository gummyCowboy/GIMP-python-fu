#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import Define as df, Issue as vo, Shape as sh
from roller_constant_identity import Identity as de
from roller_def_option import (
    BOX_TYPE,
    CELL_SHAPE_CELL,
    CELL_SIZE,
    CAP_XY,
    GRID_COUNT,
    GRID_SIZE,
    GRID_TYPE,
    INDENT,
    INWARD,
    MASK_SCALE,
    MAX_POLAR_X,
    MAX_POLAR_Y,
    PER,
    PIN
)
from roller_tooltip_text import Tip
from roller_widget_combo import ComboBox
from roller_widget_radio import SwitchRadio
from roller_widget_row_list import RowList
from roller_widget_slider import RowCountSlider


def get_table_equilateral_list():
    return sh.TABLE_EQUILATERAL_LIST


def get_table_shape_list():
    return sh.TABLE_SHAPE_LIST


# Define Model/Cell/Type Preset.
#
# Type Box_____________________________________________________________________
TYPE_BOX = OrderedDict([
    (de.BOX_TYPE, deepcopy(BOX_TYPE)),
    (de.GRID_TYPE, deepcopy(GRID_TYPE)),
    (de.PIN, deepcopy(PIN)),
    (de.ROW, deepcopy(GRID_COUNT)),
    (de.COLUMN, deepcopy(GRID_COUNT)),
    (de.CAP_X, deepcopy(CAP_XY)),
    (de.CAP_Y, deepcopy(CAP_XY)),
    (de.ROW_H, deepcopy(CELL_SIZE)),
    (de.COLUMN_W, deepcopy(CELL_SIZE)),
    (de.INDENT, deepcopy(INDENT)),
    (de.GRID_SIZE, deepcopy(GRID_SIZE))
])
TYPE_BOX[de.CAP_X][df.TOOLTIP] = Tip.CAP_X
TYPE_BOX[de.CAP_Y][df.TOOLTIP] = Tip.CAP_Y
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Type Cell____________________________________________________________________
TYPE_CELL = OrderedDict([
    (de.CELL_SHAPE, deepcopy(CELL_SHAPE_CELL)),
    (de.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE))
])
TYPE_CELL[de.PARALLELOGRAM_SCALE][df.VALUE] = .7
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Type Pyramid_________________________________________________________________
TYPE_PYRAMID = OrderedDict([
    (de.DIRECTION, {
        df.COLUMN_TEXT: de.DIRECTION,
        df.ISSUE: vo.MATTER,
        df.TEXT: ("Up", "Down"),
        df.VALUE: 0,
        df.WIDGET: SwitchRadio
    }),
    (de.ROW, {
        df.ISSUE: vo.MATTER,
        df.LIMIT: (1, 100),
        df.PAGE_INCR: 2,
        df.VALUE: 1.,
        df.WIDGET: RowCountSlider
    }),
    (de.COLUMN_COUNT_Q, deepcopy({
        df.ISSUE: vo.MATTER,
        df.VALUE: [1],
        df.WIDGET: RowList
    })),
])

# Type Sidewalk________________________________________________________________
TYPE_SIDEWALK = OrderedDict([
    (de.ROW, deepcopy(GRID_COUNT)),
    (de.COLUMN, deepcopy(GRID_COUNT)),
    (de.INWARD, deepcopy(INWARD))
])

for i in (de.ROW, de.COLUMN):
    TYPE_SIDEWALK[i][df.VALUE] = 2.
    TYPE_SIDEWALK[i][df.LIMIT] = 2, 100
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Type Stack___________________________________________________________________
TYPE_STACK = OrderedDict([
    (de.CELL_SHAPE, deepcopy(CELL_SHAPE_CELL)),
    (de.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE)),
    (de.CELL_COUNT, deepcopy(GRID_COUNT)),
    (de.ADD_OFFSET_X, deepcopy(MAX_POLAR_X)),
    (de.ADD_OFFSET_Y, deepcopy(MAX_POLAR_Y))
])

for i, i1 in enumerate((de.ADD_OFFSET_X, de.ADD_OFFSET_Y)):
    TYPE_STACK[i1].update({
        df.AXIS: ('x', 'y')[i],
        df.TOOLTIP: Tip.ADD_SHIFT_XY
    })
TYPE_STACK[de.PARALLELOGRAM_SCALE][df.VALUE] = .7
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Type Table___________________________________________________________________
TYPE_TABLE = OrderedDict([
    (de.GRID_TYPE, GRID_TYPE),
    (de.CELL_SHAPE, {
        df.FUNCTION: get_table_shape_list,
        df.ISSUE: vo.MATTER,
        df.VALUE: de.RECTANGLE,
        df.WIDGET: ComboBox
    }),
    (de.ECS, {
        df.FUNCTION: get_table_equilateral_list,
        df.ISSUE: vo.MATTER,
        df.VALUE: de.SQUARE,
        df.WIDGET: ComboBox
    }),
    (de.PIN, deepcopy(PIN)),
    (de.ROW, deepcopy(GRID_COUNT)),
    (de.COLUMN, deepcopy(GRID_COUNT)),
    (de.ROW_H, deepcopy(CELL_SIZE)),
    (de.COLUMN_W, deepcopy(CELL_SIZE)),
    (de.INDENT, deepcopy(INDENT)),
    (de.GRID_SIZE, deepcopy(GRID_SIZE)),
    (de.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE)),
    (de.PER, deepcopy(PER))
])
TYPE_TABLE[de.PARALLELOGRAM_SCALE][df.VALUE] = .7
