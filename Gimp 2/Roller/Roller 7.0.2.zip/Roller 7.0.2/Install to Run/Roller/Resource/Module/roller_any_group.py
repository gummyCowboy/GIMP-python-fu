#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_booth import Booth
from roller_constant import (
    Deco as dc,
    Define as df,
    Issue as vo,
    Signal as si,
    Step as sk,
    SubMaya as sm,
    VoteType as vt
)
from roller_constant_identity import Identity as de
from roller_container import Run, The
from roller_def_access import get_default_d, get_init_d
from roller_id import Id
from roller_image_change import (
    ref_get_image, ref_on_grid_change, ref_on_group_change
)
from roller_many_handle import Handle
from roller_helm import Helm
from roller_ring import Ring
from roller_port import Port
from roller_option_squish import ROUTE_SQUISH, hide_options
from roller_preset import get_option_list_choice
from roller_preset_super import SuperPreset
from roller_step import (
    connect_sub_str,
    convert_name_to_type,
    get_branch_part,
    get_last_part,
    get_parts,
    get_sub_type_text,
    get_type_text
)
from roller_widget_node import Node
from roller_widget_per import (
    PerGroupCell, PerGroupEmpty, PerGroupFace, PerGroupFacing, PerGroupMerge
)
from roller_widget_preset import Preset
from roller_widget_table import create_table
from roller_widget_voter import accept_vote
import gobject  # type: ignore

# argument index enum
LABEL_I, WIDGET_I, KEY_ARG_I = range(3)


def assign_per_widget(type_step_k):
    """
    Determine the sub-PerWidget type for the option group.

    type_step_k: string
        Its Preset has a Per option.

    Return: class
        sub-PerWidget
    """
    if not type_step_k:
        return PerGroupEmpty

    leaf = get_last_part(type_step_k)

    # PortCellEditor's Per branch key index, '-1'
    if leaf == de.PER:
        return PerGroupEmpty

    if leaf == de.TYPE:
        return PerGroupMerge

    parts = get_parts(type_step_k)

    if len(parts) < 3:
        return PerGroupEmpty

    # type-step-key -> model-branch-leaf
    model_branch = connect_sub_str(parts[0], parts[1])

    # Check model-branch key.
    if model_branch not in sk.PER_GROUP_SET:
        return PerGroupEmpty

    branch = parts[1]

    if branch == de.FACE:
        return PerGroupFace

    if branch == de.FACING:
        return PerGroupFacing
    return PerGroupCell


def get_init_type(dna):
    """
    Determine the init class for an option group given its DNA.

    dna: DNA
    Return: class or None
        init type
    """
    if dna.is_preset:
        return Preset
    if dna.is_node:
        return Node
    if dna.is_super_preset:
        return SuperPreset


class AnyGroup(gobject.GObject, Handle):
    """Create a group of Widget with the same output goal."""
    # Are signals that can be emitted by this class.
    __gsignals__ = si.GROUP_DICT

    def __init__(self, draw_option, **d):
        """
        draw_option: function
            Add option.

        d: dict
            Initialize the option group.
            mandatory: df.DNA
        """
        gobject.GObject.__init__(self)
        Handle.__init__(self)

        self._value_d = {}
        self.id = Id.make()
        self._view_value = [None, None]
        self.altered = [False, False]
        self.sub_any_group = None
        self.is_loading_default = False

        # Has nexus type data, 'dna'.
        dna = self.dna = d[df.DNA]
        dna.any_group = self

        # default Maya
        self.plan = self.work = Nada()

        # Collect change vote for main option settings.
        # [plan vote dict, work vote dict]
        self.vote_q = [{}, {}]

        # Made of the selected Node items that lead to the option group.
        # Is a Model-name-step-key where
        # the Model name corresponds with a Model instance.
        name_k = self.name_step_k = d.get(df.NAME_STEP_K)

        if name_k is not None:
            # Register the option group with a global group dict.
            Helm.add_step(self.name_step_k, self)

        # Has Widget that populate an option group.
        # {Identity: Widget}
        # If a Widget has a key value of None, then it isn't included here.
        self._widget_d = {}

        model = dna.model

        if model and name_k is not None:
            self.type_step_k = convert_name_to_type(name_k, model.model_type)

        elif df.TYPE_STEP_K in d:
            # Per Cell has no step-key, and option view has a need to know.
            self.type_step_k = d[df.TYPE_STEP_K]

        else:
            self.type_step_k = name_k

        self.is_squish = bool(ROUTE_SQUISH.get(dna.key))
        self.booth = Booth()

        if not d.get(df.IS_NONE):
            # Define Widget during init.
            # [(widget label, Widget, Widget init dict), ...], 'widget_list'
            widget_list = d[df.WIDGET_LIST] = []

            key = dna.key
            d[df.ANY_GROUP] = self
            init_d = get_init_d(key) if dna.is_preset or dna.is_simple \
                else [Node, SuperPreset][dna.is_super_preset].get_init_d(key)
            relay = d[df.RELAY][:]

            for k in init_d.keys():
                arg_d = init_d[k]
                arg_d[df.KEY] = k

                if k == de.PER:
                    arg_d[df.WIDGET] = assign_per_widget(self.type_step_k)

                widget = arg_d[df.WIDGET]

                arg_d.update(d)

                # label text, 'n'
                if k == de.SWITCH:
                    n = dna.type_

                elif df.COLUMN_TEXT in arg_d:
                    n = arg_d[df.COLUMN_TEXT]

                elif widget.has_table_label:
                    n = arg_d[df.TEXT] = get_type_text(k)

                else:
                    # Next and Previous Label have no left side Label.
                    n = ""

                d[df.RELAY] = relay[:]
                widget_list.append([n, widget, arg_d])

            if not dna.is_node and not dna.is_simple:
                # Insert a Preset Widget.
                if dna.is_preset:
                    preset_name = dna.type_

                else:
                    # Per-Preset and SuperPreset
                    preset_name = get_sub_type_text(key)

                d[df.RELAY] = relay[:]

                widget_list.append([
                    "{} Preset".format(preset_name),
                    get_init_type(dna),
                    dict(d, key=de.PRESET)
                ])
            if widget_list:
                self._widget_d = draw_option(dna.vbox, **d)
                if dna.is_preset or dna.is_simple:
                    self.is_loading_default = True
                    self.load_widget_d(get_default_d(key))
                    self.is_loading_default = False

        self.latch(self, (si.GROUP_CHANGE, self.on_changed))
        self.latch(self, (si.DISAPPEAR, self.on_disappear))

    def _cast_sub_vote(self, k, row_k, vote_q):
        """
        Cast vote from a sub-WidgetRow Widget.
        Vote is accumulating in 'self.vote_q'.

        k: string
            Identity

        row_k: string
            Row Identity

        vote_q: list
            [plan vote dict, work vote dict] from the Widget
        """
        # plan and work view-type index range, '2'
        for i in range(2):
            d = self.vote_q[i]

            if row_k:
                if row_k not in d:
                    d[row_k] = {k: {}}
                d[row_k][k] = vote_q[i]

            else:
                d[k] = vote_q[i]
            self.booth.cast(i)

    def accept_vote(self, i, k, issue, vote):
        """
        Accept vote for a Widget in the AnyGroup.
        Record vote on Widget action. Clear
        vote when the AnyGroup's output is produced.

        i: int
            plan or work view-type index

        k: string
            Option or cast key
            Is an Identity referencing a responsible Widget.
            A cast key is a Widget influencer, but not a Widget reference.

        issue: Issue
            Maya inspects vote for each issue.

        vote: bool
            A True value indicates that the Widget's
            value changed from the previous view.
            If any option or cast key has a True vote, then
            the issue equals True.

            For example,
            'matter' is an issue, typically, the core aspect layer of an
            option group. 'is_matter' is its Maya attribute.
            When 'Maya.is_matter' equals True, then the issue's output
            is produced unless other circumstances override.
        """
        accept_vote(self.vote_q[i], k, issue, vote)
        self.changed(i=i)

    def cast_vote(self, i, k, issue, vote):
        """
        Add a vote to the vote dict. Tell Booth about a vote change.

        i: int
            plan or work; view-type index; 0 or 1

        k: string
            option key or cast key

        issue: string or tuple
            issue type or (issue type,)

        vote: bool
            Is True if the Widget has changed value from its view value.
        """
        self.accept_vote(i, k, issue, vote)
        self.booth.cast(i)

    def changed(self, i=None):
        """
        Update group visibility.

        i: int or None
            0 to 1; plan or work view-type
            None for both
        """
        if i is None:
            self.altered = [True, True]

        else:
            self.altered[i] = True
        Ring.add(self, si.GROUP_CHANGE, None)

    def count_widget(self):
        """
        Give AnyGroup Widget total count.

        Return: int
            Is the number of Widget in the AnyGroup widget dict.
        """
        return len(self._widget_d)

    def do(self, *arg):
        """Produce option group output as part of a view run."""
        i = Run.i
        maya = (self.plan, self.work)[i]

        maya.do(*arg)

        self._view_value[i] = deepcopy(self._value_d)
        self.vote_q[i] = {}
        self.altered[i] = False

    def does_work(self):
        """
        If the AnyGroup is a Nada type, then it doesn't do work.

        Return: bool
            Is True if the AnyGroup is not Nada.
        """
        return not isinstance(self.work, Nada)

    def extract_widget_d(self):
        """
        Place extracted Widget value in the 'value_d'.
        """
        for k in self._value_d:
            self._value_d[k] = self.unload_widget(k)
        return self._value_d

    def get_node(self):
        """
        Call to get a LonerGroup's Node Widget.

        Return: Node or None
        """
        return self._widget_d.get(de.NODE)

    def get_sub_widget_a(self, row_k, k):
        """
        Retrieve the value for a Widget.

        row_k: string or None
            Is the Row key found in the value dict.

        k: string
            Identity

        Return: value or None
            Widget's value
        """
        # Warning: Avoid Widget dict as it would circle back.
        if row_k:
            if row_k not in self._value_d:
                a = None
            else:
                a = self._value_d[row_k].get(k)

        else:
            a = self._value_d.get(k)
        return a

    def get_view_a(self, i, key, row_key=None):
        """
        Get the value of a Widget from the last run.

        i: int
            render-type index
            plan or work

        key: string
            Identify an option.

        row_key: string or None
            Identify a sub-dictionary.

        Return: value or None
            from the last View run of the render-type
        """
        d = self._view_value[i]

        if d and row_key:
            d = d.get(row_key)
        if d:
            return d.get(key)

    def get_view_q(self, key, row_key=None):
        """
        Get the value of a Widget from the last run.

        i: int
            render-type index
            plan or work

        key: string
            Identify an option.

        row_key: string or None
            Identify a sub-dictionary.

        Return: value or None
            from the last View run of the render-type
        """
        def _get_a():
            _d = self._view_value[i]

            if _d and row_key:
                _d = _d.get(row_key)
            if _d:
                return _d.get(key)

        q = []

        # plan and work, '2'
        for i in range(2):
            q.append(_get_a())
        return q

    def get_view_d(self, i):
        """
        Get the value of a Widget from the last run.

        i: int
            render-type index
            plan or work

        Return: dict or None
            from the last View run of the render-type
        """
        return self._view_value[i]

    def get_widget(self, k):
        """
        Fetch an AnyGroup Widget given its key.

        Return: widget or None
        """
        return self._widget_d.get(k)

    def get_widget_a(self, k):
        return self._value_d.get(k)

    def get_value_d(self):
        """
        Fetch the value of each Widget in the group.

        Return: dict
            {Identity: Widget value}
        """
        return self._value_d

    def load_widget_d(self, d, skip=None):
        """
        Load Widget with value.

        d: dict
            {Widget key: value}

        skip: value or None
            If it is a value, then this key's Widget won't be loaded.
        """
        for k, g in self._widget_d.items():
            if skip:
                if skip == k:
                    continue
            g.load_a(d.get(k))

    def on_changed(self, *_):
        """
        Respond to group change by updating option visibility.

        _: tuple
            not used
        """
        if self.is_squish:
            if The.load_count:
                # Come back after loading.
                Ring.add(self, si.GROUP_CHANGE, None)
            else:
                hide_options(self)

        # Skip during a Preset load.
        if not The.load_count:
            if Port.view:
                Port.view.on_group_change(self)

    def on_disappear(self, *_):
        """
        The AnyGroup is no longer in service, so disconnect its subscription.
        """
        self.unlatch()
        Ring.drop(self.booth)

    def set_node_a(self, a):
        """
        For Node use. Update its value in the value dict.

        a: value
            from a Node
        """
        self._value_d[de.NODE] = a

    def set_sub_widget_a(self, row_k, k, a):
        """
        Update the value dict for a Widget.
        Can update a sub-WidgetRow Widget's value.

        row_k: string or None
            Is the Row key found in the value dict.

        k: string
            Identity

        a: value
            for the value dict
        """
        if row_k:
            if row_k not in self._value_d:
                self._value_d[row_k] = {}
            self._value_d[row_k][k] = a
        else:
            self._value_d[k] = a

    def set_value_d(self, d):
        self._value_d = d

    def set_widget(self, k, g):
        """
        Set the stored value item for a Widget.

        k: string
            Identity

        g: Widget
            Store in widget dict.
        """
        self._widget_d[k] = g

    def set_widget_a(self, k, a):
        """
        Set the stored value item for a Widget.

        k: string
            Identity

        a: value
            Store in value dict.
        """
        self._value_d[k] = a

    def unload_widget(self, k):
        """
        Retrieve the value from a Widget.

        k: value
            Widget key

        Return: value or None
        """
        g = self._widget_d.get(k)
        if g:
            return g.get_ui()

    def unload_widget_d(self):
        """
        Retrieve the value from the AnyGroup's Widget dict.

        k: value
            Widget key

        Return: dict
            {Widget key: Widget value}
        """
        d = {}

        for k in self._widget_d:
            d[k] = self.unload_widget(k)
        return d

    def update_sub_g(self, row_k, k, vote_q):
        """
        Update a Widget value in the value dict.
        Use with a still-type (a non-voter) Widget.
        Is acceptable for normal Widget or sub-WidgetRow Widget.
        Cast the Widget's vote for change.

        row_k: string or None
            Is a Row key found in the value dict.

        k: string
            Option or sub-Row dict key

        vote_q:
            [plan vote dict, work vote dict]
            a vote dict structure:
            {
                Issue: {Identity: bool},
                Sub-Maya Identity: issue: {Identity: bool},
                Row key: {
                    Sub-Maya Identity: issue: {Identity: bool}
                }
            }
        """
        self._cast_sub_vote(k, row_k, vote_q)
        self.changed()


class LonerGroup(AnyGroup):
    """
    For a Widget that doesn't need a Table container for options.
    """

    def __init__(self, **d):
        AnyGroup.__init__(self, self.create_object, **d)

    @staticmethod
    def create_object(container, **d):
        """
        Place a Widget in a container.

        d: dict
            Has keyword variables.

        Return: dict
            {Identity: Widget}
        """
        i = d[df.WIDGET_LIST][0]
        g = i[WIDGET_I](**i[KEY_ARG_I])

        container.pack_start(g, expand=True)
        return {g.key: g}


class ManyGroup(AnyGroup):
    """
    Has a Table container having two columns for containing Widget option.
    """

    def __init__(self, **d):
        AnyGroup.__init__(self, create_table, **d)


class ModelGroup(ManyGroup):
    """Process Model sequence change and chain of responsibility."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

    def on_cell_calc(self, _, vote_d):
        """
        Receive a Model/Cell calc Signal.

        _: Baby
            Sent the Signal.

        vote_d: dict
            {(r, c): [plan vote, work vote]}
            (r, c): (row, column); a zero-based cell index; Goo key
            'vote': bool
        """
        self.on_chain_change(vote_d)
        self._widget_d[de.PER].intersect_vote(vote_d)

    def on_chain_change(self, vote_d):
        """
        The option group is an origin of change.

        vote_d: dict
            {(r, c): [plan vote, work vote]}
            (r, c): (row, column); a zero-based cell index; Goo key
            'vote': bool
        """
        vote_q = [False, False]
        q = self.dna.model.get_main_cell_list(self._value_d)

        # (row, column), [plan vote, work vote]; 'k, q1'
        for k, q1 in vote_d.items():
            if k in q:
                vote_q = [m or vote_q[i] for i, m in enumerate(q1)]
                if vote_q == [True, True]:
                    break
        self.on_sequence_change(self, vote_q)

    def on_sequence_change(self, _, arg):
        """
        Sequence change is processed promptly. Where as Baby
        waits for the interface to be idle before sending and
        and starting a chain sequence.

        _: AnyGroup
            Sent the signal.

        arg: list
            [plan vote, work vote]
        """
        # plan and work view-type index, 'i'
        for i in range(2):
            self.cast_vote(i, vt.IS_CHAIN, vo.MATTER, arg[i])
        self.emit(si.SEQUENCE, arg)


class DecoGroup(ModelGroup):
    """A deco group finishes chain of responsibility processing."""

    def __init__(self, **d):
        ModelGroup.__init__(self, **d)

        # node key, 'k'; its reverse position '-2'
        self.branch_k = get_branch_part(self.name_step_k)

        if self.branch_k in dc.FACIAL_SET:
            # Face has no Margin to receive update from Shift, so
            # Line receive update directly from Shift instead of Margin.
            self.latch(
                self.dna.model.baby, (si.CELL_SHIFT_CALC, self.on_cell_calc)
            )

        if self.branch_k in dc.CELL_MARGIN_CALC_SET:
            self.latch(
                self.dna.model.baby, (si.CELL_MARGIN_CALC, self.on_cell_calc)
            )
        elif self.branch_k == de.CANVAS:
            # Respond to Model Canvas change.
            self.latch(
                self.dna.model.baby,
                (si.CANVAS_MARGIN_CALC, self.on_sequence_change)
            )

    def get_keys(self):
        """
        Fetch a list of keys for AnyGroup. The keys are
        determined by the branch and provided by the model.

        Return: list
            [assignment key, ...]
        """
        def _canvas():
            return [None]

        def _cell():
            return self.dna.model.cell_q

        def _face():
            return self.dna.model.face_q

        return {
            de.CANVAS: _canvas,
            de.CELL: _cell,
            de.FACE: _face,
            de.FACING: _face
        }[self.branch_k]()


class DecoImageGroup(DecoGroup):
    """Assign image using Ring."""
    image_slot_count = 3

    def __init__(self, **d):
        # Image reference dict, 'j_d'
        # {Maya goo or map key: [GIMP image or None, ...]}
        # Image reference list: [Image, Mask, Frame]
        self.j_d = {}

        DecoGroup.__init__(self, **d)
        self.latch(self, (si.GROUP_CHANGE, ref_on_group_change))
        self.latch(
            self.dna.model.baby, (si.CELL_RECT_CALC, self.on_grid_change)
        )

    def on_grid_change(self, *_):
        """
        Update Ref on the grid change.

        _: tuple
            (Baby, dict -> Contain vote.)
        """
        ref_on_grid_change(self, self.get_keys())

    def check_image_change(self, maya):
        """
        Check image reference between views, and flag 'matter' change.
        """
        d = maya.value_d[de.PER]
        e = self.j_d
        a = self.image_slot_count

        # main Maya's Per Maya reference, 'per_d'
        per_d = maya.per_d if hasattr(maya, 'per_d') else {}

        for k in self.get_keys():
            q = e.get(k)

            if q is None:
                # Initialize image slot.
                q = e[k] = [None] * a
            for i in range(a):
                j = q[i]
                j1 = q[i] = ref_get_image(self, k, i)
                m = j != j1
                if m:
                    # The image ref changed.
                    this_maya = maya if k not in d else per_d[k]

                    if i == 0:
                        this_maya.is_matter = True

                    elif i == 1:
                        this_maya.sub_maya[sm.MASK].is_matter = True
                    else:
                        this_maya.sub_maya[sm.FRAME].is_matter = True


class Nada:
    """Use with an option group that has no Maya (e.g. a SuperPreset group)."""

    def __init__(self, *_, **__):
        return

    def do(self, *_):
        return

    def reset(self, *_):
        return

    def reset_issue(self, *_):
        return

    def set_issue(self, *_):
        return


class NoneGroup(AnyGroup):
    """Has no options, but has AnyGroup attribute."""

    def __init__(self, **d):
        d[df.IS_NONE] = 1
        AnyGroup.__init__(self, lambda a, **e: None, **d)


class OptionAnyGroup(AnyGroup):
    """Have a nested AnyGroup notify a super AnyGroup of change."""

    def __init__(self, any_group, **d):
        self.super_any_group = any_group

        AnyGroup.__init__(self, create_table, **d)
        if self.is_squish:
            any_group.sub_any_group = self

    def changed(self, *_, **d):
        super(OptionAnyGroup, self).changed(*_, **d)
        self.super_any_group.changed(*_, **d)

    def connect_dict(self):
        """
        The Option List has a nested AnyGroup dict that is
        set during list-option-change. This function
        keeps the super AnyGroup updated with this value change.
        """
        d = self.super_any_group.get_value_d()
        e = self.get_value_d()
        k, d1 = get_option_list_choice(d)

        if d1 is not e:
            # OptionList value dict, 'a'
            a = self.super_any_group.unload_widget(de.OPTION_LIST)
            self.super_any_group.set_widget_a(de.OPTION_LIST, a)

    def on_changed(self, *_):
        super(OptionAnyGroup, self).on_changed()
        self.super_any_group.on_changed()
        self.connect_dict()


# Register the custom signals.
gobject.type_register(AnyGroup)
