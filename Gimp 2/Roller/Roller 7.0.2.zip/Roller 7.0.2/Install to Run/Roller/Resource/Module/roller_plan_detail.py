#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb  # type: ignore
from roller_constant import Plan as ak
from roller_constant_identity import Identity as de
from roller_container import Deco, Run
from roller_deck import Deck
from roller_deco_border import select_border
from roller_def_access import get_default_d
from roller_gimp_image import add_layer
from roller_gimp_layer import (
    color_selection_default, make_plan_text_layer, verify_layer
)
from roller_gimp_selection import select_channel, select_shape
from roller_plan import add_text_layer
from roller_wip import Wip


def do_main_corner(maya):
    """
    Draw cell corner coordinate for main cell.

    maya: Maya
    Return: layer or None
    """
    return make_main(maya, "Corner", draw_corner)


def do_main_dimension(maya):
    """
    Draw cell dimension for main cell.

    maya: Maya
    Return: layer or None
    """
    return make_main(maya, "Dimension", draw_dimension)


def do_main_position(maya):
    """
    Draw cell position at the topleft of main cell.

    maya: Maya
    Return: layer or None
    """
    return make_main(maya, "Position", draw_position)


def do_main_ratio(maya):
    """
    Draw a cell ratio at the center of a cell. A ratio
    is calculated as the cell center point divided by the render size.

    maya: Maya
    """
    return make_main(maya, "Ratio", draw_ratio)


def do_main_shape(maya):
    """
    Draw cell shape for main cell.

    maya: Maya
    """
    j = Run.j
    arg = j, maya

    for k in maya.super_maya.main_q:
        create_shape_sel(k, *arg)
    return verify_layer(fill_shape(j, maya))


def do_per_position(maya):
    """
    Draw the cell position at the topleft for Cell/Per.

    maya: Maya
    Return: layer or None
    """
    return make_per(maya, "Position", draw_position)


def do_per_corner(maya):
    """
    Draw corner coordinate for Cell/Per.

    maya: Maya
    Return: layer or None
    """
    return make_multiple_per(maya, "Corner", draw_corner)


def do_per_dimension(maya):
    """
    Draw cell dimension for Cell/Per.

    maya: Maya
    Return: layer or None
    """
    return make_per(maya, "Dimension", draw_dimension)


def do_per_ratio(maya):
    """
    Draw cell ratio for Cell/Per.

    maya: Maya
    Return: layer or None
    """
    return make_per(maya, "Ratio", draw_ratio)


def do_per_shape(maya):
    """
    Draw cell shape for Cell/Per.

    maya: Maya
    Return: layer or None
    """
    j = Run.j

    create_shape_sel(maya.super_maya.k, j, maya)
    return verify_layer(fill_shape(j, maya))


def draw_corner(k, j, maya, p):
    """
    Draw two cell pocket corner. Draw them at the bottom-left
    and top-right corners of a cell.

    k: tuple
        zero-based cell index
        (row, column)

    j: Gimp Image
        WIP

    maya: Detail
    p: function
        Call to insert the text layer output.
    """
    # Modify the pocket position that is in in view
    # image space to be in render image space.
    x, y, w, h = maya.model.get_pocket_rect(k)
    x1 = x - Wip.x
    y1 = y - Wip.y
    x2 = x1 + w
    y2 = y1 + h
    x1, x2, y1, y2 = map(int, (x1, x2, y1, y2))

    # top-right
    z = make_plan_text_layer(j, "{}, {}".format(x2, y1), maya.font_size)

    add_text_layer(z, x + w - z.width - 3., y, p)

    # bottom-left
    z = make_plan_text_layer(j, "{}, {}".format(x1, y2), maya.font_size)
    add_text_layer(z, x + 3., y + h - z.height, p)


def draw_dimension(k, j, maya, p):
    """
    Draw a cell dimension at the bottom-right corner of a cell.
    See 'draw_corner' for argument description.

    Return: layer
        text
    """
    x, y, w, h = maya.model.get_pocket_rect(k)
    z = make_plan_text_layer(
        j, str(int(w)) + ", " + str(int(h)), maya.font_size
    )

    add_text_layer(z, x + w - z.width - 3., y + h - z.height, p)
    return z


def draw_position(k, j, maya, p):
    """
    Draw the cell pocket position at the topleft corner of a cell.
    See 'draw_corner' for argument description.

    Return: layer
        text
    """
    model = maya.model
    x, y = model.get_pocket_rect(k)[:2]
    x1 = x - Wip.x
    y1 = y - Wip.y
    z = make_plan_text_layer(
        j,
        "{}, {}".format(*map(int, (x1, y1))),
        maya.font_size
    )

    add_text_layer(z, x + 3., y, p)
    return z


def draw_ratio(k, j, maya, p):
    """
    Draw a cell's position ratio in the WIP rectangle context.
    See 'draw_corner' for argument description.

    Return: layer
        text
    """
    model = maya.model

    # view space pocket rectangle
    x, y, w, h = model.get_pocket_rect(k)

    # WIP relative position
    x1 = x - Wip.x
    y1 = y - Wip.y

    # ratio
    f_x = (w / 2. + x1) / Wip.w
    f_y = (h / 2. + y1) / Wip.h

    # format
    r_x = format(f_x, '.2f')
    r_y = format(f_y, '.2f')

    z = make_plan_text_layer(
        j,
        r_x[int(f_x < 1.):] + ", " + r_y[int(f_y < 1.):],
        maya.font_size
    )

    add_text_layer(
        z, x + w / 2. - z.width / 2., y + h / 2. - z.height / 2., p
    )
    return z


def create_shape_sel(k, j, maya):
    """
    Draw a Cell Model's cell shape.

    k: tuple
        goo or map key

    j: Gimp Image
        WIP

    maya: PlanShape
    Return: state of Gimp's selection
    """
    model = maya.model
    sc = pdb.gimp_selection_save(j) \
        if not pdb.gimp_selection_is_empty(j) else None
    d = get_default_d(de.BORDER)
    maya.k = k
    d[de.WIDTH] = 2.
    d[de.TYPE] = de.COLOR
    Deco.shape = model.get_plaque(k)

    select_shape(j, Deco.shape)
    select_border(d)
    if sc:
        select_channel(j, sc, option=CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, sc)


def fill_shape(j, maya):
    """
    Fill a selection with a color.

    j: Gimp Image
        WIP

    maya: PlanShape
    Return: layer or None
        Cell Shape material
    """
    if not pdb.gimp_selection_is_empty(j):
        z = add_layer(j, maya.super_maya.group, 0, "Cell Shape")
        z.opacity = 66.

        color_selection_default(z, ak.SHAPE_COLOR)
        return z


def make_main(maya, n, p):
    """
    Process layer output for the main option settings.

    maya: Maya
    n: string
        layer name

    p: function
        Call to make layer output.

    Return: layer or None
    """
    def _insert(_z):
        deck.insert(_z)

    j = Run.j
    deck = Deck(j, maya.super_maya.group, 0, n)
    arg = j, maya, _insert

    for k in maya.super_maya.main_q:
        p(k, *arg)
    return deck.exit()


def make_multiple_per(maya, n, p):
    """
    Process layer output for Per settings
    where there is multiple layer output for a Maya.

    maya: Maya
    n: string
        layer name

    p: function
        Call to make layer output.

    Return: layer or None
    """
    def _insert(_z):
        deck.insert(_z)

    j = Run.j
    deck = Deck(j, maya.super_maya.group, 0, n)

    p(maya.super_maya.k, j, maya, _insert)
    return deck.exit()


def make_per(maya, n, p):
    """
    Process layer output for Per settings.

    maya: Maya
    n: string
        layer name

    p: function
        Call to make layer output.

    Return: layer or None
    """
    def _insert(_z):
        pdb.gimp_image_insert_layer(j, _z, group, 0)
        _z.name = group.name + " " + n

    j = Run.j
    group = maya.super_maya.group
    return verify_layer(p(maya.super_maya.k, j, maya, _insert))
