#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_container import Run
from roller_any_group import ModelGroup
from roller_constant import Issue as vo, Signal as si
from roller_constant_identity import Identity as de
from roller_maya import Runner
from roller_ring import Ring
from roller_step import (
    find_canvas_margin, find_cell_margin, get_branch_part
)


class Shift(ModelGroup):
    """
    Create a Shift Preset Widget group. Assign
    view-type runner and connect signal handler.
    """

    def __init__(self, **d):
        ModelGroup.__init__(self, **d)

        self._is_cell = False
        node_k = get_branch_part(self.name_step_k)
        self.plan = {de.CANVAS: PlanCanvas, de.CELL: PlanCell}[node_k](self)
        self.work = {de.CANVAS: WorkCanvas, de.CELL: WorkCell}[node_k](self)

        if node_k == de.CELL:
            self._is_cell = True
            self._sequence_signal = si.CELL_SHIFT_CHANGE

            self.latch(
                self.dna.model.baby, (si.CELL_RECT_CALC, self.on_cell_calc)
            )
            self.latch(
                self.get_widget(de.PER), (si.PER_CHANGE, self.update_model)
            )

        elif node_k == de.CANVAS:
            # Canvas hook
            self._sequence_signal = si.CANVAS_SHIFT_CHANGE
            self.latch(Ring.gob, (si.RESIZE, self.on_sequence))

        self.latch(self.booth, (si.VOTE_CHANGE, self.update_model))
        self.latch(self, (si.SEQUENCE, self.on_sequence))

    def do(self):
        """
        Override the AnyGroup function so that Past's view Signal can be sent.
        """
        super(Shift, self).do()

        p = self.dna.model.past.emit

        if self._is_cell:
            p(si.CELL_SHIFT_VIEW, Run.i)

            # Adapt to a missing Cell/Margin step.
            if not find_cell_margin(self.name_step_k):
                p(si.CELL_MARGIN_VIEW, Run.i)
        else:
            p(si.CANVAS_SHIFT_VIEW, Run.i)

            # Adapt to a missing Canvas/Margin step.
            if not find_canvas_margin(self.name_step_k):
                p(si.CANVAS_MARGIN_VIEW, Run.i)

    def on_sequence(self, *_):
        """
        Update the Model pronto.

        _: tuple
            (AnyGroup, list)
        """
        self.dna.model.baby.feed(self._sequence_signal, (self._value_d, True))

    def update_model(self, *_):
        """Update the Model as time permits."""
        self.dna.model.baby.give(self._sequence_signal, (self._value_d, False))


class Chi(Runner):
    """Factor Plan and Work."""
    issue_q = 'matter',

    def __init__(self, any_group, view_i):
        Runner.__init__(self, any_group, view_i, (), ())

    def dig(self):
        self.reset_issue()

    def get_value_d(self):
        return self.any_group.get_value_d()


# view-type____________________________________________________________________
class Plan(Chi):
    """Shift has no layer output. Is part of the AnyGroup template."""

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0)


class Work(Chi):
    """Shift has no layer output. Is part of the AnyGroup template."""

    def __init__(self, any_group):
        """
        q: iterable
            output function
        """
        Chi.__init__(self, any_group, 1)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Canvas_______________________________________________________________________
class PlanCanvas(Plan):
    """Shift has no layer output. Is part of the AnyGroup template."""
    vote_type = vo.MAIN

    def __init__(self, any_group):
        """
        any_group: Shift
        """
        Plan.__init__(self, any_group)


class WorkCanvas(Work):
    """Shift has no layer output. Is part of the AnyGroup template."""
    vote_type = vo.MAIN

    def __init__(self, any_group):
        """
        any_group: Shift
        """
        Work.__init__(self, any_group)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# Cell_________________________________________________________________________
class PlanCell(Plan):
    """Shift has no layer output. Is part of the AnyGroup template."""
    issue_q = 'matter', 'per'
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Plan.__init__(self, any_group)


class WorkCell(Work):
    """Shift has no layer output. Is part of the AnyGroup template."""
    issue_q = 'matter', 'per'
    vote_type = vo.MAIN

    def __init__(self, any_group):
        Work.__init__(self, any_group)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
