#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant import Define as df, Issue as vo
from roller_constant_identity import Identity as de
from roller_def_option import FONT_SIZE
from roller_widget_label import PropertyTypeLabel
from roller_widget_plan import PlanOption
from roller_widget_slider import FontSizeSlider

"""Define the Model/Property Preset."""
PLANNER = OrderedDict([
    (de.BORDER, 0),
    (de.CAPTION, 0),
    (de.CELL_SHAPE, 0),
    (de.CORNER, 0),
    (de.DIMENSION, 0),
    (de.FRINGE, 0),
    (de.GRID, 0),
    (de.IMAGE, 0),
    (de.LINE, 0),
    (de.MARGIN, 0),
    (de.NAME, 0),
    (de.PLAQUE, 0),
    (de.POSITION, 0),
    (de.RATIO, 0)
])
property_d = OrderedDict([
    (de.MODEL_TYPE, {
        df.ISSUE: vo.NULL,
        df.WIDGET: PropertyTypeLabel
    }),
    (de.PLANNER, {df.VALUE: deepcopy(PLANNER), df.WIDGET: PlanOption}),
    (de.FONT_SIZE, deepcopy(FONT_SIZE))
])

property_d[de.FONT_SIZE].update({
    df.VALUE: 12.,
    df.WIDGET: FontSizeSlider
})
PROPERTY = deepcopy(property_d)
