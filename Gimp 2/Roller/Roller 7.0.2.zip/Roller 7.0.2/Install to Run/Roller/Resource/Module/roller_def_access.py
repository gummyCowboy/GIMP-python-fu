#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant import Define as df
from roller_def_actor import scour


def get_default_d(k):
    """
    Fetch a Widget group's default option value.

    k: string
        Group key

    Return: dict
        {option key: value}
        Use to load a default Preset.
    """
    return deepcopy(Def.default_d.get(k, {}))


def get_group_keys(k):
    """
    Fetch a Widget group's option key list depending on the
    option's definition structure.

    k: string
        Group key

    Return: list
        [option key]
    """
    a = Def.group_def.get(k)
    if a:
        return a.keys()

    a = Def.sub_group_def.get(k)

    if a:
        return a[df.SUB].keys()

    # Should not get here.
    return []


def get_init_d(k):
    """
    Fetch Widget init argument for a Widget group.

    k: string
        Preset key

    Return: dict
        Define option.
        {Define and Identity: value}
    """
    d = Def.group_def.get(k)

    if d:
        return deepcopy(d)

    d = Def.sub_group_def.get(k)
    if d:
        return deepcopy(d[df.SUB])


def get_vote_d(k):
    """
    Fetch the prefab vote dict for a Preset.

    k: string
        Identity

    Return: dict
        Is the default vote dict for the Preset.
    """
    return Def.vote_d.get(k, {})


class Def:
    """Access Preset definition and vote dict."""
    default_d = {}
    group_def = {}
    sub_group_def = {}
    vote_d = {}

    def __init__(self, group_def, sub_group_def):
        """
        group_def: dict
            {Preset key: Preset definition dict}

        sub_group_def: dict
            {sub-Preset key: sub-Preset definition dict}
        """
        d = Def.group_def = group_def
        e = Def.sub_group_def = sub_group_def

        # Load the vote dict.
        for i in d:
            Def.vote_d[i] = scour({}, d[i], df.ISSUE)

        for i in e:
            Def.vote_d[i] = scour({}, e[i], df.ISSUE)

        # Load the default Preset value dict.
        for i in d:
            Def.default_d[i] = scour({}, d[i], df.VALUE)
        for i in e:
            Def.default_d[i] = scour({}, e[i], df.VALUE)
