#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    CLIP_TO_IMAGE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_EXCLUSION,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_HSV_SATURATION,
    LAYER_MODE_NORMAL,
    pdb
)
from random import randint
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_deco_output import init_deco_type
from roller_def_access import get_default_d
from roller_gimp_mode import get_gradient_mode
from roller_gegl import emboss
from roller_gimp_image import (
    add_sub_maya_group, add_wip_layer, insert_copy_above, make_group_layer
)
from roller_gimp_layer import blur_selection, clone_layer
from roller_gimp_selection import select_rect
from roller_maya_sub_accent import SubAccent
from roller_preset import combine_seed
from roller_wip import Wip


def do_matter(maya):
    """
    Make a matter layer.

    maya: DensityGradient
    Return: layer
        'matter'
    """
    j = Run.j
    d = maya.value_d
    parent = add_sub_maya_group(maya)
    z = add_wip_layer("Plasma", maya.group)
    group = make_group_layer(j, parent, 0, "Sub", z=z)

    combine_seed(d)
    pdb.gimp_selection_none(j)

    # lowest turbulence, '1.'
    pdb.plug_in_plasma(j, z, int(d[de.RANDOM_SEED] + Globe.seed), 1.)

    z = add_wip_layer("Difference", group)
    z.mode = LAYER_MODE_DIFFERENCE

    # medium turbulence, '3.5'
    pdb.plug_in_plasma(j, z, randint(0, 100000), 3.5)

    z = z1 = add_wip_layer("Difference 2", group)
    z.mode = LAYER_MODE_DIFFERENCE

    # highest turbulence, '7.'
    pdb.plug_in_plasma(j, z, randint(0, 100000), 7.)

    z = insert_copy_above(z, group.layers[0])
    z.mode = LAYER_MODE_GRAIN_EXTRACT

    for i in ((255, 0, 0), (0, 255, 0), (255, 0, 255)):
        pdb.plug_in_colortoalpha(j, z, i)

    pdb.plug_in_unsharp_mask(
        j, z1,
        3.,                     # radius
        100.,                   # amount
        .0                      # threshold
    )
    z2 = clone_layer(z1, n="Blur")

    blur_selection(z1, 3)

    z1.mode = LAYER_MODE_NORMAL
    z2.mode = LAYER_MODE_DIFFERENCE
    z = clone_layer(z1, n="HSV Saturation")
    z.mode = LAYER_MODE_HSV_SATURATION

    pdb.gimp_image_reorder_item(j, z, group, 0)

    z = clone_layer(z, n="Difference #3")
    z.mode = LAYER_MODE_DIFFERENCE
    z = insert_copy_above(z, group.layers[0])
    z.mode = LAYER_MODE_EXCLUSION

    emboss(z, Globe.azimuth, 30, 2)

    z1 = clone_layer(z, n="Exclusion #2")
    z1.mode = LAYER_MODE_EXCLUSION
    e = get_default_d(de.GRADIENT_FILL)

    e.update(d)
    pdb.gimp_image_merge_layer_group(j, group)

    e[de.GRADIENT] = d[rk.RW1][de.GRADIENT]
    arg, p = init_deco_type(de.GRADIENT, j, maya, parent, e, 0, False)
    maya.rect = Wip.get_rect()

    select_rect(j, *maya.rect)

    z = p(*arg)
    z.mode = get_gradient_mode(d)

    pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)
    return maya.finish(
        pdb.gimp_image_merge_layer_group(j, parent), d[rk.RW1]
    )


class DensityGradient(SubAccent):
    """Create Accent output."""
    kind = de.DENSITY_GRADIENT

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)
