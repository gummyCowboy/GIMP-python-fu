#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice
from roller_constant import LIST_SEPARATOR, Define as df, Signal as si
from roller_constant_identity import Identity as de
from roller_ring import Ring
from roller_step import get_branch_part
from roller_widget import Widget
import gobject  # type: ignore
import gtk    # type: ignore
import pango  # type: ignore


def get_caption_all_list():
    return de.IMAGE_NAME, de.SEQUENCE, de.TEXT


def get_caption_no_sequence_list():
    return de.IMAGE_NAME, de.TEXT


def get_caption_text_list():
    return (de.TEXT,)


class Combo(Widget, gobject.GObject):
    """Is a base class for a ComboBox-type class."""
    __gsignals__ = si.COMBO_DICT
    change_signal = 'changed'

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        self.item_list = []
        self.store = gtk.ListStore(str)
        g = d['sub_type'](self.store)
        d[df.RELAY].insert(0, self.set_tooltip)
        Widget.__init__(self, g, **d)

        # for custom signal(s)
        gobject.GObject.__init__(self)

        # Limit the horizontal size of the the ComboBox.
        a = gtk.CellRendererText()
        a.props.ellipsize = pango.ELLIPSIZE_END

        g.pack_start(a)
        self.add(g)

        if d['sub_type'] == gtk.ComboBox:
            g.add_attribute(a, 'text', 0)

        else:
            g.child.set_editable(0)

        if df.FUNCTION in d:
            self.item_list = self.function()

        self.populate_list(self.item_list)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

        n = d.get(df.LABEL_TIP)
        if n:
            self.connect(si.COMBO_CREATED, self.on_combo_created)
            Ring.add(self, si.COMBO_CREATED, n)

    def get_ui(self):
        """
        Get the activated item in the ComboBox.

        Return: string
            active option
        """
        if len(self.item_list):
            return self.item_list[self.widget.get_active()]
        else:
            return ""

    def on_combo_created(self, _, arg):
        """
        Create a tooltip for the Combo's Label.

        _: gobject
            Is the signal's sender but is not used.

        arg: string
            Is the Label's tooltip.
        """
        self.label.widget.set_tooltip_text(arg)

    def populate_list(self, q):
        """
        Set the options for the ComboBox.

        q: iterable
            of option strings
        """
        self.store.clear()
        self.item_list = q
        for n in q:
            self.store.append([n])

    def randomize(self, *_):
        """Generate a random value for the NumberPair."""
        if self.item_list:
            n = LIST_SEPARATOR

            while LIST_SEPARATOR in n:
                n = choice(self.item_list)
            self.load_a(n)

    def set_ui(self, n):
        """
        Set the ComboBox's display.

        n: string
            Display value.

        Return: n
            Displayed value.
        """
        if not isinstance(n, basestring):
            n = ""

        if n in self.item_list:
            i = self.item_list.index(n)

        elif hasattr(self, 'set_text'):
            self.set_text(n)
            i = -1

        else:
            i = 0
            n = self.item_list[0]

        if i > -1:
            self.widget.set_active(i)
        return n

    def set_tooltip(self, *_):
        """
        Call when the ComboBox changes. Add a tooltip for long strings.
        """
        if hasattr(self, 'get_text'):
            n = self.get_text()

        else:
            n = self.get_ui()

        # '22' is arbitrary and from the observation of gtk on my
        # screen. The string's pixel length is difficult to obtain.
        n = " {} ".format(n)
        n = n if len(n) > 22 else ""

        self.set_tooltip_text(n)


class ComboBox(Combo):
    """Has a list separator."""
    has_table_label = True

    def __init__(self, **d):
        """
        d: dict
            to initialize the Widget
        """
        Combo.__init__(self, **dict(d, sub_type=gtk.ComboBox))
        self.widget.set_row_separator_func(ComboBox._set_mode_separator)

    @staticmethod
    def _set_mode_separator(model, itr):
        """
        Determine if the current item in the list is a
        separator. Use when populating the option list.

        model: gtk.ListStore
        itr: gtk.iter

        Return: flag
            Is true if the item is a separator.
        """
        n = model.get_value(itr, 0)
        if n:
            return LIST_SEPARATOR in n


class CaptionComboBox(ComboBox):
    """Use to initialize the Caption Type option."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        a = d[df.ANY_GROUP]

        if get_branch_part(a.type_step_k) == de.FACE:
            p = get_caption_text_list

        elif (
            a.dna.model.model_type == de.CELL or
            get_branch_part(a.type_step_k) == de.CANVAS
        ):
            # A numeric sequence in not a Caption Type.
            p = get_caption_no_sequence_list

        else:
            p = get_caption_all_list

        d[df.FUNCTION] = p
        ComboBox.__init__(self, **d)


# Register the custom signals.
gobject.type_register(Combo)
