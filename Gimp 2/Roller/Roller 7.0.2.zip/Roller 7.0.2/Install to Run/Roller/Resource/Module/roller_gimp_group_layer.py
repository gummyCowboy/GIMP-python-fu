#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb       # type: ignore


def merge_group_layer(group, n=None):
    """
    Merge group layer.

    z: group layer
        Merge.

    n: string or None
        Name the merged layer.

    Return: layer
        Merged.
    """
    group = pdb.gimp_image_merge_layer_group(group.image, group)

    if n:
        group.name = n
    return group
