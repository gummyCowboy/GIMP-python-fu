#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb  # type: ignore
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_def_access import get_default_d
from roller_gimp_mode import get_mode
from roller_gimp_image import add_layer, make_group_layer
from roller_gimp_layer import (
    clone_layer, select_layer_iffy, verify_group_layer, verify_layer
)
from roller_gimp_selection import invert_selection


def do_stylish_shadow(
    z, blur=15., intensity=130., offset_x=.0, offset_y=.0, is_inner=False
):
    """
    Create a shadow layer.

    z: layer
        shadow caster

    blur: float
        shadow blur

    intensity: float
        shadow opacity
        .0 to 1000.

    offset_x: float
        shadow offset on x-axis (-, +)

    offset_y: float
        shadow offset on y-axis (-, +)

    is_inner: flag
        If True, the shadow is an Inner Shadow type.

    Return: layer
        the shadow layer
    """
    if is_inner:
        d = get_default_d(de.INNER_SHADOW)
        p = make_shadow_inner
        arg = d, z.parent, z

    else:
        d = get_default_d(de.SHADOW_1)
        p = make_shadow
        arg = d, z.parent, [z]

    d[de.BLUR] = blur
    d[de.INTENSITY] = intensity
    d[de.OFFSET_X] = offset_x
    d[de.OFFSET_Y] = offset_y
    return p(*arg, name="Shadow")


def make_shadow(d, parent, cast_q, name=None):
    """
    Make a shadow.

    d: dict
        Shadow Preset
        {Identity: value}

    parent: group layer
        Has name and position.

    cast_q: tuple or list
        [layer, ...]
        Combine each layer's alpha selection into a singular caster.

    name: string or None
        Name the output layer.

    Return: layer
        shadow
    """
    intensity = d[de.INTENSITY]
    if cast_q and intensity:
        j = Run.j
        group = make_group_layer(j, None, 0, "Shadow")
        base_z = add_layer(j, group, 0, "Temp")
        color = d[de.COLOR_1]

        pdb.gimp_selection_none(j)

        for z in cast_q:
            select_layer_iffy(j, z, option=CHANNEL_OP_ADD)

        if not pdb.gimp_selection_is_empty(j):
            if intensity > 100.:
                layer_count = intensity // 100.
                intensity = intensity / (layer_count + 1)

            else:
                layer_count = 0

            # base layer for the shadow output, 'z1'
            # Make shadow from the layer's alpha selection.
            pdb.script_fu_drop_shadow(
                j, base_z,
                d[de.OFFSET_X], d[de.OFFSET_Y],
                d[de.BLUR],
                color,
                intensity,
                0                       # no resizing
            )
            if layer_count:
                # Increase the shadow intensity by
                # stacking duplicate shadow layers.
                z = group.layers[0]
                for i in range(int(layer_count)):
                    z = clone_layer(z)

        pdb.gimp_selection_none(j)

        z = verify_group_layer(group)

        if z:
            z.mode = get_mode(d)

            pdb.gimp_image_reorder_item(j, z, parent, 0)

            if name is not None:
                z.name = name
        return z


def make_shadow_inner(d, parent, cast_z, name=None):
    """
    Make an Inner Shadow.

    d: dict
        Shadow Preset

    parent: group layer
        Has name and position.

    cast_z: layer or None
        Cast Inner Shadow with this layer.

    name: string or None
        Name the output layer.

    Return: layer
        shadow
    """
    intensity = d[de.INTENSITY]

    if cast_z and intensity:
        j = Run.j
        group = make_group_layer(j, None, 0, "Shadow")
        base_z = add_layer(j, group, 0, "Temp")
        color = d[de.COLOR_1]

        select_layer_iffy(j, cast_z)
        invert_selection(j)

        if not pdb.gimp_selection_is_empty(j):
            if intensity > 100.:
                layer_count = intensity // 100.
                intensity = intensity / (layer_count + 1)

            else:
                layer_count = 0

            # base layer for the shadow output, 'z1'
            # Make shadow from the layer's alpha selection.
            pdb.script_fu_drop_shadow(
                j, base_z,
                d[de.OFFSET_X], d[de.OFFSET_Y],
                d[de.BLUR],
                color,
                intensity,
                0                       # no resizing
            )
            if layer_count:
                # Increase shadow intensity by
                # stacking duplicate shadow layers.
                z = group.layers[0]
                for i in range(int(layer_count)):
                    z = clone_layer(z)

        pdb.gimp_image_remove_layer(j, base_z)
        pdb.gimp_selection_none(j)

        z = verify_layer(pdb.gimp_image_merge_layer_group(j, group))

        if z:
            z.mode = get_mode(d)

            pdb.gimp_image_reorder_item(j, z, parent, 0)
            if name is not None:
                z.name = name
        return z
