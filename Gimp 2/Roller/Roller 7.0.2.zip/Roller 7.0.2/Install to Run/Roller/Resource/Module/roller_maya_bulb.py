#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import ADD_MASK_ALPHA, MASK_APPLY, pdb  # type: ignore
from roller_constant import Issue as vo, Signal as si
from roller_constant_identity import Identity as de
from roller_container import Lit, Run
from roller_gimp_mode import translate_mode
from roller_gimp_image import check_matter
from roller_gimp_layer import set_layer_attr, show_layer
from roller_helm import Helm
from roller_maya_build import SubBuild
from roller_ring import Ring
from roller_gimp_mask import mask_sub_maya
from roller_preset import get_heat_d


def copy_light_layer():
    """
    Make a copy of Light matter.

    Return: tuple
        (copied layer, the Light layer's name)
        (None, "") when empty
    """
    # Light's matter layer, 'z'
    z = Lit.z

    if z:
        return pdb.gimp_layer_new_from_drawable(z, Run.j), z.name
    return None, ""


def do_matter(maya):
    """
    Insert a Light layer copy at the top of a super-maya group layer.

    maya: Light
    Return: layer
        Has Light material.
    """
    z, n = copy_light_layer()

    if z:
        group = maya.super_maya.group

        pdb.gimp_image_insert_layer(Run.j, z, group, 0)

        if z.mask:
            pdb.gimp_layer_remove_mask(z, MASK_APPLY)

        show_layer(z)
        z.name = "{} {}".format(group.name, n)
    return z


class Bulb(SubBuild):
    """Manage Light layer output for Heat/Material."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (check_matter, 'matter'),

    def __init__(self, any_group, super_maya, material):
        """
        any_group: AnyGroup
            Manage Light layer output for a work-view-type view.

        super_maya: Maya
            Has control over Bulb layer output.

        material: string
            Material key
        """
        self._material = material
        self._mode = None
        self._opacity = .0
        self.has_matter = False

        SubBuild.__init__(self, any_group, super_maya, vo.NO_VOTE, do_matter)
        self.latch(Ring.gob, (si.LIGHT_CHANGE, self.on_light_change))
        self.latch(Ring.gob, (si.HEAT_CHANGE, self.on_heat_change))
        self._light = Helm.get_group(de.LIGHT).work
        d = get_heat_d()
        if d:
            self.on_heat_change(None, d)

    def do(self, is_change):
        """
        Manage layer output during a view run.

        is_change: bool
            Is True when the super-maya has either matter or mask change.
        """
        self.go = self.super_maya.go and \
            self._light.get_switch() and self.has_matter

        self.realize()

        if self.go:
            if self.matter:
                if self.is_mode or self.is_opacity or self.is_matter:
                    m = set_layer_attr(
                        self.matter, translate_mode(self._mode), self._opacity
                    )
                    Run.is_back |= m
                if self.is_matter or is_change:
                    self.mask_light_layer()
        self.reset_issue()

    def mask_light_layer(self):
        """
        Mask the Bulb's matter layer using a
        super-maya matter layer's alpha selection.
        """
        mask_sub_maya(self.super_maya.get_matter(), self.matter)

    def on_heat_change(self, _, heat_d):
        """
        Respond to change in Heat/Material value.
        Check if Bulb has Light/Heat/Material.

        _: Ring
        heat_d: dict
            {material Identity: {'mode': mode string, 'opacity': float}}
        """
        d = heat_d.get(self._material)

        if d:
            # Mode
            mode = d.get(de.MODE)
            self.is_mode |= mode != self._mode
            self._mode = mode

            # Opacity
            opacity = d.get(de.OPACITY)
            self.is_opacity |= opacity != self._opacity
            self._opacity = opacity

            # matter
            has_matter = bool(self.matter)
            self.has_matter = has_matter or self._opacity
            self.is_matter |= not has_matter

        else:
            # no output or null output
            self._mode = None
            self._opacity = .0
            self.has_matter = False

    def on_light_change(self, ring, is_matter):
        """
        Respond to Light option change.

        ring: Ring
        is_matter: bool
            Is True when Light has change.
        """
        self.is_matter |= is_matter

    def reset(self):
        """
        Call when there is the view image closes
        such as during an image resize event.
        """
        self.is_mode = self.is_opacity = self.is_matter = True
