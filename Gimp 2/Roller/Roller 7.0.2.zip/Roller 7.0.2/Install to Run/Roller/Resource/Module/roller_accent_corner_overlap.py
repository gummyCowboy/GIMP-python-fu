#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, CHANNEL_OP_SUBTRACT, pdb  # type: ignore
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_gegl import median_blur
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import add_wip_base
from roller_gimp_layer import color_selection, get_mean_color, select_layer
from roller_gimp_selection import select_ellipse, select_rect
from roller_maya_sub_accent import SubAccent
from roller_preset import combine_seed
from roller_utility import random_rgb
from roller_wip import Wip


def get_average_color(color1, color2):
    """
    Average two colors.

    color1: tuple
        RGB

    color2: tuple
        RGB

    Return: tuple
        RGB
    """
    color = ()

    # RGB, '3'
    for x in range(3):
        color += ((color1[x] + color2[x]) // 2,)
    return color


def get_color_1(color1, _):
    """
    color1: tuple
        RGB

    _: tuple
        RGB

    Return: tuple
        RGB
    """
    return color1


def get_color_2(_, color2):
    """
    _: tuple
        RGB

    color2: tuple
        RGB

    Return: tuple
        RGB
    """
    return color2


def init_random_color(*_):
    """
    Return: tuple
        RGB
    """
    return random_rgb(), random_rgb()


def init_color(_, d):
    """
    _: group layer
    d: dict
        Corner Overlap Preset

    Return: tuple
        (RGB, RGB)
    """
    return d[de.COLOR_2]


def init_mean_color(maya, _):
    """
    maya: CornerOverlap
    _: dict
        CornerOverlap Preset

    Return: tuple
        (background copy layer,)
    """
    return maya.bg_z,


INIT_TYPE = {
    de.COLOR: init_color,
    de.MEAN_COLOR: init_mean_color,
    de.RANDOM_COLOR: init_random_color
}
GET_COLOR_1 = {
    de.COLOR: get_color_1,
    de.MEAN_COLOR: get_mean_color,
    de.RANDOM_COLOR: get_color_1
}
GET_COLOR_2 = {
    de.COLOR: get_color_2,
    de.MEAN_COLOR: get_mean_color,
    de.RANDOM_COLOR: get_color_2
}
GET_FILL_COLOR = {
    de.COLOR: get_average_color,
    de.MEAN_COLOR: get_mean_color,
    de.RANDOM_COLOR: get_average_color
}


def do_matter(maya):
    """
    Create a Corner Overlap layer.

    maya: CornerOverlap
    Return: layer or None
        'matter'
    """
    j = Run.j
    d = maya.value_d

    combine_seed(d)
    set_fill_context_default()
    pdb.gimp_selection_none(j)

    type_ = d[de.TYPE]
    type_arg = INIT_TYPE[type_](maya, d)
    z = add_wip_base("Corner Overlap WIP", maya.group)

    # Fill selections with material for each selection.
    paint_selection(z, type_, d[de.CLOCKWISE], type_arg)

    if d[de.FILLED]:
        select_rect(j, *Wip.get_rect())
        select_layer(z, option=CHANNEL_OP_SUBTRACT)
        color_selection(z, GET_FILL_COLOR[type_](*type_arg))

    pdb.gimp_selection_none(j)
    median_blur(z, 2., 50.)
    return maya.finish(z, d[rk.BRW])


def paint_selection(z, type_, clockwise, type_arg):
    def _add_bottom_left_circle():
        select_ellipse(j, left, y1, w, w, option=CHANNEL_OP_ADD)

    def _add_bottom_right_circle():
        select_ellipse(j, x1, y1, w, w, option=CHANNEL_OP_ADD)

    def _add_topleft_circle():
        select_ellipse(j, left, top, w, w, option=CHANNEL_OP_ADD)

    def _add_top_right_circle():
        select_ellipse(j, x1, top, w, w, option=CHANNEL_OP_ADD)

    def _do_ccw():
        """The overlap is counter-clockwise."""
        # Select and color horizontal side.
        # left side
        select_rect(j, left, top + w1, w, h)
        _add_topleft_circle()

        # right side
        select_rect(j, x1, y - w1, w, h, option=CHANNEL_OP_ADD)
        _add_bottom_right_circle()

        color_selection(z, GET_COLOR_1[type_](*type_arg))

        # Select and color vertical side.
        # top
        select_rect(j, x, top, h1, w)   # topleft corner appears wrong?
        _add_top_right_circle()

        # bottom
        select_rect(j, x - w1, y1, h1, w, option=CHANNEL_OP_ADD)
        _add_bottom_left_circle()

        color_selection(z, GET_COLOR_2[type_](*type_arg))

        # Select and color corner hook.
        # Begin horizontal color.
        # bottom-left
        select_rect(j, left, y1, w, w1)
        _add_bottom_left_circle()
        _subtract_bottom_left()

        # top-right
        select_rect(j, x1, y - w1, w, w1, option=CHANNEL_OP_ADD)
        _add_top_right_circle()
        _subtract_top_right()

        # Complete horizontal color.
        color_selection(z, GET_COLOR_1[type_](*type_arg))

        # Begin vertical color.
        # topleft
        select_rect(j, left + w1, top, w1, w)
        _add_topleft_circle()
        _subtract_topleft()

        # bottom-right
        select_rect(j, x1, y1, w1, w, option=CHANNEL_OP_ADD)
        _add_bottom_right_circle()
        _subtract_bottom_right()

        # Complete vertical color.
        color_selection(z, GET_COLOR_2[type_](*type_arg))

    def _do_cw():
        """The overlap is clockwise."""
        # Select and color horizontal side.
        # left side
        select_rect(j, left, y - w1, w, h)
        _add_bottom_left_circle()

        # right side
        select_rect(j, x1, y - w1, w, h, option=CHANNEL_OP_ADD)
        _add_top_right_circle()

        color_selection(z, GET_COLOR_1[type_](*type_arg))

        # Select and color vertical side.
        # top
        select_rect(j, x - w1, top, h1, w)
        _add_topleft_circle()

        # bottom
        select_rect(j, x, y1, h1, w, option=CHANNEL_OP_ADD)
        _add_bottom_right_circle()

        color_selection(z, GET_COLOR_2[type_](*type_arg))

        # Select and color corner hook.
        # Begin horizontal color.
        # topleft
        select_rect(j, left, y - w1, w, w1)
        _add_topleft_circle()
        _subtract_topleft()

        # bottom-right
        select_rect(j, x1, y1, w, w1, option=CHANNEL_OP_ADD)
        _add_bottom_right_circle()
        _subtract_bottom_right()

        # Complete horizontal color.
        color_selection(z, GET_COLOR_1[type_](*type_arg))

        # Begin vertical color.
        # bottom-left
        select_rect(j, left + w1, y1, w1, w)
        _add_bottom_left_circle()
        _subtract_bottom_left()

        # top-right
        select_rect(j, x1, top, w1, w, option=CHANNEL_OP_ADD)
        _add_top_right_circle()
        _subtract_top_right()

        # Complete vertical color.
        color_selection(z, GET_COLOR_2[type_](*type_arg))

    def _subtract_bottom_left():
        select_ellipse(
            j, left + w2, y1 + w2, w1, w1, option=CHANNEL_OP_SUBTRACT
        )

    def _subtract_bottom_right():
        select_ellipse(j, x1 + w2, y1 + w2, w1, w1, option=CHANNEL_OP_SUBTRACT)

    def _subtract_topleft():
        select_ellipse(
            j, left + w2, top + w2, w1, w1, option=CHANNEL_OP_SUBTRACT
        )

    def _subtract_top_right():
        select_ellipse(
            j, x1 + w2, top + w2, w1, w1, option=CHANNEL_OP_SUBTRACT
        )

    j = Run.j
    left, top, image_w, image_h = Wip.get_rect()
    w = min(image_w, image_h) // 3
    x = left + w
    y = top + w
    x1 = left + image_w - w
    y1 = top + image_h - w
    a, b = divmod(w, 2)           # corner rect and ellipse
    w1 = a + b                    # overlap circle
    w2 = w // 4.                  # inner ellipse
    h = image_h - w               # vertical side length
    h1 = image_w - w - w1         # horizontal side length

    set_fill_context_default()
    (_do_ccw, _do_cw)[clockwise]()


class CornerOverlap(SubAccent):
    kind = de.CORNER_OVERLAP

    def __init__(self, any_group, is_old):
        SubAccent.__init__(self, any_group, do_matter, False, True, is_old)

    def do(self, *arg):
        """Check if the background has change."""
        d = self.any_group.get_value_d()
        self.is_dependent = d[de.TYPE] == de.MEAN_COLOR
        super(CornerOverlap, self).do(*arg)
