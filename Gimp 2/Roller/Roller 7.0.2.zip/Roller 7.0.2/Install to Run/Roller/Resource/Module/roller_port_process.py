#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_container import Dog
from roller_constant import Define as df
from roller_constant_identity import Identity as de
from roller_port import Port
from roller_widget_button import (
    AcceptButton,
    CancelButton,
    DraftButton,
    PeekButton,
    PlanButton,
    PreviewButton,
    RandomButton
)
from roller_widget_box import ColorHBox, ColorVBox, Eventful
from roller_widget_label import Label
from roller_widget_row import WidgetRow
import gtk  # type: ignore


class PortProcess(Port):
    """Factor Port processing."""

    def __init__(self, d, g):
        """
        d: dict
            Has init variable.

        g: Widget or None
            Is responsible.
        """
        self.any_group = None
        Port.__init__(self, d, g)

    def draw_basic_process(self, box):
        """
        Draw a Widget group with Cancel and Accept options.

        box: GTK Box container
            Receive Widget group.
        """
        g = WidgetRow(
            **{
                df.PADDING: (0, 0, 4, 4),
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win,
                df.SUB: OrderedDict([
                    (de.CANCEL, {df.WIDGET: CancelButton}),
                    (de.ACCEPT, {df.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        box.add(g)

    def draw_column(self, function_q):
        """
        Draw the Port's Widget stacked as a column VBox container.

        function_q: iterable
            of function
        """
        self.draw_rc(ColorVBox, function_q)

    def draw_group(self, dna):
        """
        Draw simple dialog option.

        dna: DNA
            Has group attribute.
        """
        self.any_group = Dog.many_group(
            **{
                df.COLOR: self.color,
                df.DNA: dna,
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win
            }
        )
        self.any_group.type_step_k = dna.type_
        self.any_group.load_widget_d(self.repo.get_a())

    def draw_list(self, function_q, label_q):
        """
        Draw the Port's Widget stacked as a column VBox container.

        function_q: iterable
            [function, ...]

        label_q: iterable
            [Label descriptor, ...]
        """
        for i, p in enumerate(function_q):
            box = Eventful(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if label_q[i]:
                vbox.pack_start(
                    Label(padding=(4, 4, 4, 4), text=label_q[i] + ":"),
                    expand=False
                )

            p(vbox)
            self.reduce_color()
            self.pack_start(box, expand=(True, False)[i])
        self.roller_win.gtk_win.vbox.set_size_request(350, 350)

    def draw_process(self, hbox):
        """
        Draw a Widget group with viewing options.

        vbox: GTK Box container
            Receive Widget group.
        """
        g = WidgetRow(
            **{
                df.PADDING: (0, 0, 4, 4),
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win,
                df.SUB: OrderedDict([
                    (de.CANCEL, {df.WIDGET: CancelButton}),
                    (de.DRAFT, {df.WIDGET: DraftButton}),
                    (de.PEEK, {df.WIDGET: PeekButton}),
                    (de.PLAN, {df.WIDGET: PlanButton}),
                    (de.PREVIEW, {df.WIDGET: PreviewButton}),
                    (de.ACCEPT, {df.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        hbox.add(g)

    def draw_random_process_group(self, vbox):
        """
        Draw a group with viewing Buttons.

        vbox: GTK container
            Receive Widget group.
        """
        g = WidgetRow(
            **{
                df.ANY_GROUP: self.any_group,
                df.PADDING: (0, 0, 4, 4),
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win,
                df.SUB: OrderedDict([
                    (de.CANCEL, {df.WIDGET: CancelButton}),
                    (de.DRAFT, {df.WIDGET: DraftButton}),
                    (de.PEEK, {df.WIDGET: PeekButton}),
                    (de.RANDOM, {df.WIDGET: RandomButton}),
                    (de.PLAN, {df.WIDGET: PlanButton}),
                    (de.PREVIEW, {df.WIDGET: PreviewButton}),
                    (de.ACCEPT, {df.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        vbox.add(g)

    def draw_rc(self, box_type, function_q):
        """
        Draw the Port's Widget in the specified container.
        Each container has a color background assigned from 'self.color'.

        box_type: class
            Is the container type to make for the Widget group.

        function_q: iterable
            of function
        """
        for p in function_q:
            box = box_type(self.color)

            self.add(box)
            p(box)
            self.reduce_color()

    def draw_row(self, function_q):
        """
        Draw the Port's Widget arranged as a row in an HBox container.

        function_q: iterable
            of function
        """
        self.draw_rc(ColorHBox, function_q)
