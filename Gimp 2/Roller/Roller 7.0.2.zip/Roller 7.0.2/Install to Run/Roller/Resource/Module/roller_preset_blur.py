#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from roller_gegl import median_blur
from roller_constant_identity import Identity as de
from roller_gimp_layer import select_layer
from roller_gimp_selection import select_rect
from roller_wip import Wip


def do_blur(z, d):
    """
    Process Blur Preset output.

    z: layer
        Receive blur.

    d: dict
        Blur Preset
    """
    def _do_gaussian():
        if pdb.gimp_selection_is_empty(j):
            pdb.gimp_selection_all(j)
        pdb.plug_in_gauss_rle2(j, z, d[de.SIZE_X], d[de.SIZE_Y])

    def _do_median():
        median_blur(
            z,
            int(d[de.RADIUS]),
            d[de.PERCENTILE],
            alpha=d[de.ALPHA_PERCENTILE]
        )

    if d[de.SWITCH]:
        j = z.image

        if d.get(de.SELECT):
            select_rect(j, *Wip.get_rect())

        else:
            select_layer(z)
        (_do_gaussian, _do_median)[d[de.TYPE]]()
