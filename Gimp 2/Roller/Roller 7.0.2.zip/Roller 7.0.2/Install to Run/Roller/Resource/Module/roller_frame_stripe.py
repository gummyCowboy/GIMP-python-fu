#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_constant_identity import Identity as de
from roller_frame import do_frame_with_filler
from roller_frame_alt import FrameBasic
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import add_layer, create_image, image_copy_all
from roller_gimp_layer import clipboard_fill, color_selection
from roller_gimp_selection import select_rect


def do_matter(maya):
    """
    Make a frame.

    maya: Stripe
    Return: layer
        Wrap 'matter'
    """
    set_fill_context_default()
    return do_frame_with_filler(maya, make_pattern)


def make_pattern(z, d):
    """
    Make a stripe pattern. Assume selection is none.

    z: layer
        Receive pattern.

    d: dict
        Stripe Preset

    Return: layer
        Has material to select.
    """
    w = d[de.LINE_W]
    w1 = d[de.GAP_W] + w
    j1 = create_image(int(w1), int(w1))
    z1 = add_layer(j1, None, 0, "Pattern")
    y = (w1 - w) // 2.

    select_rect(j1, .0, y, w1, w)
    color_selection(z1, (0, 0, 0))

    # Set the Clipboard Image.
    image_copy_all(j1)

    pdb.gimp_image_delete(j1)
    clipboard_fill(z)
    return z


class Stripe(FrameBasic):
    filler_k = de.FILLER_S3
    kind = material = de.STRIPE
    wrap_k = de.WRAP_PA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
