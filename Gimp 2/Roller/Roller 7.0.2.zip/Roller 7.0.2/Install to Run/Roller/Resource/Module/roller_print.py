#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
import sys

"""Include debug function. Use 'noqa' to hide error message in VS Code."""


def print_a(a):
    """
    Print a message to the error file. Use during development.
    Move VS Code Flake8's error message to this module.

    a: object
    """
    print >> sys.stderr, a               # noqa


def print_all(*arg):
    """
    Write zero to n number of messages.

    arg: tuple or None
    """
    for a in arg:
        if isinstance(a, dict):
            print_d(a)

        elif isinstance(a, (list, set, tuple)):
            print_q('All', a)
        else:
            print_a(a)


def print_always(arg):
    """
    Write message to a 'always_error.txt' file.
    Use when Roller crashes in an infinite loop,
    or a Signal error causes problems.

    arg: value
        Print to a file.
    """
    a = sys.stderr
    file_ = sys.stderr = open("D:\\always_error.txt", 'a')

    if isinstance(arg, dict):
        print_d(arg)

    elif isinstance(arg, (list, set, tuple)):
        print_q('Always', arg)
    else:
        print_a(arg)

    sys.stderr = a
    file_.close()


def print_children(g):
    """
    Print message to the error file. Use during development.
    Move VS Code Flake8's error message to this module.

    This function creates a hierarchical tree struct
    with a container's children.

    g: GTK Container
    """
    def _loop(_g, _indent):
        for _child in _g.get_children():
            _n = "\t" * _indent

            if hasattr(_child, 'get_children'):
                print >> sys.stderr, '{}{} visible: {}'.format(       # noqa
                    _n, _child, _child.get_sensitive())
                _loop(_child, _indent + 1)
            else:
                print >> sys.stderr, '{}{} visible: {}'.format(       # noqa
                    _n, _child, _child.get_sensitive())

    _loop(g, 0)


def print_context():
    print_a('anti-alias {}'.format(pdb.gimp_context_get_antialias()))
    print_a('feather {}'.format(pdb.gimp_context_get_feather()))
    print_a('brush angle {}'.format(pdb.gimp_context_get_brush_angle()))
    print_a('brush hardness {}'.format(pdb.gimp_context_get_brush_hardness()))
    print_a('mode {}'.format(pdb.gimp_context_get_paint_mode()))
    print_a('opacity {}'.format(pdb.gimp_context_get_opacity()))
    print_a('sample criterion {}'.format(
        pdb.gimp_context_get_sample_criterion())
    )
    print_a('threshold {}'.format(pdb.gimp_context_get_sample_threshold()))
    print_a('foreground {}'.format(pdb.gimp_context_get_foreground()))
    print_a('background {}'.format(pdb.gimp_context_get_background()))
    print_a('brush {}'.format(pdb.gimp_context_get_brush()))
    print_a('gradient {}'.format(pdb.gimp_context_get_gradient()))
    print_a('pattern {}'.format(pdb.gimp_context_get_pattern()))


def print_d(d):
    """
    Print message to the error file. Use during development.
    Move VS Code Flake8's error message to this module.

    This function creates a hierarchical tree struct
    with all dict items.

    d: dict
    """
    def _loop(_d, _indent):
        for _k, _a in _d.items():
            _n = "\t" * _indent

            if isinstance(_a, dict):
                print >> sys.stderr, '{}{}:'.format(_n, _k)           # noqa
                _loop(_a, _indent + 1)
            else:
                print >> sys.stderr, '{}{}: {}'.format(_n, _k, _a)    # noqa

    if isinstance(d, dict):
        _loop(d, 0)
    else:
        print_a(
            'The function print_d arg is not dict, but is a {}'.format(type(d))
        )


def print_d_id(d):
    """
    Print message to the error file. Use during development.
    Move VS Code Flake8's error message to this module.

    This function creates a hierarchical tree struct
    with only dict keys and their id.

    d: dict
    """
    def _loop(_d, _indent):
        for _k, _a in _d.items():
            _n = "\t" * _indent
            if isinstance(_a, dict):
                print >> sys.stderr, '{}{}: {}:'.format(_n, _k, id(_a))  # noqa
                _loop(_a, _indent + 1)
    _loop(d, 0)


def print_d_struct(d):
    """
    Print message to the error file. Use during development.
    Move VS Code Flake8's error message to this module.

    This function creates a hierarchical tree struct
    with only dict keys.

    d: dict
    """
    def _loop(_d, _indent):
        for _k, _a in _d.items():
            _n = "\t" * _indent
            if isinstance(_a, dict):
                print >> sys.stderr, '{}{}:'.format(_n, _k)           # noqa
                _loop(_a, _indent + 1)
    _loop(d, 0)


def print_q(n, q):
    """
    Print message to the error file. Use during development.
    Move VS Code Flake8's error message to this module.

    n: label
    q: iterable
    """
    print >> sys.stderr, n
    for i in q:
        print >> sys.stderr, '\t{}'.format(i)               # noqa
