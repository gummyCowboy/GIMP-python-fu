#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore


def get_item_size(a):
    """
    Convert an item size to float. The item
    has attributes 'width' and 'height'.

    a: GIMP image or drawable

    Return: tuple
        (width, height) of float
        image size
    """
    return map(round, (a.width, a.height))


def validate_item(a):
    """"
    Determine if an item reference is valid.

    a: item
        Could be None or invalid.

    Return: bool
        Is true if the item is valid.
    """
    return a and pdb.gimp_item_is_valid(a)
