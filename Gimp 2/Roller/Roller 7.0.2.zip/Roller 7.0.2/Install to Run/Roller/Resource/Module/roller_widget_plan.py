#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant import Define as df, Plan as ak, Signal as si
from roller_constant_identity import Identity as de
from roller_tooltip_text import Tip
from roller_widget import set_widget_attr
from roller_widget_box import Box as boxer
from roller_widget_check_button import CheckButtonPlan
from roller_widget_row import SelectRow
import gobject  # type: ignore
import gtk      # type: ignore

TOOLTIP = {
    de.BORDER: Tip.PLAN_BORDER,
    de.CELL_SHAPE: Tip.PLAN_CELL_SHAPE,
    de.CORNER: Tip.PLAN_CORNER,
    de.DIMENSION: Tip.PLAN_DIMENSION,
    de.GRID: Tip.PLAN_GRID,
    de.NAME: Tip.PLAN_IMAGE_NAME,
    de.POSITION: Tip.PLAN_POSITION,
    de.RATIO: Tip.PLAN_RATIO
}


class PlanOption(boxer, gobject.GObject, object):
    """Has CheckButtons for filtering Plan output."""
    __gsignals__ = si.PLANNER_DICT
    change_signal = None
    has_table_label = True

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        buttons = []
        vbox_list = boxer(), boxer()
        relay = d[df.RELAY][:]

        # {Plan sub-option key: CheckButton}
        self._check_button_d = {}

        set_widget_attr(self, d)
        boxer.__init__(self, box=gtk.VBox, padding=(4, 2, 0, 0))
        gobject.GObject.__init__(self)

        hbox = gtk.HBox()
        keys = d[df.VALUE]
        d[df.ROW_KEY] = de.PLANNER
        d[df.RELAY].insert(0, self.on_plan_button_switch)

        for k in keys:
            d[df.KEY] = k
            d[df.TEXT] = k
            d[df.ISSUE] = k.lower()
            d[df.SIGNAL] = ak.SIGNAL_DICT[k]

            buttons.append(CheckButtonPlan(padding=(0, 0, 4, 4), **d))

            self._check_button_d[k] = buttons[-1]
            if k in TOOLTIP:
                buttons[-1].set_tooltip_text(TOOLTIP[k])

        d[df.RELAY] = relay

        d.pop(df.ROW_KEY)
        d.pop(df.ISSUE)
        hbox.add(vbox_list[0])
        hbox.add(vbox_list[1])
        self.add(hbox)
        self.add(SelectRow(buttons, **d))

        vbox = vbox_list[0]
        midpoint = len(buttons) // 2 + len(buttons) % 2
        d[df.RELAY] = relay
        for i, button in enumerate(buttons):
            if i == midpoint:
                vbox = vbox_list[1]
            vbox.add(button)

    def get_ui(self):
        """
        Assemble a dictionary of Plan sub-option value.

        Return: OrderedDict
            {Plan sub-option key: Widget value}
        """
        d = OrderedDict()

        for k, g in self._check_button_d.items():
            d[k] = g.get_ui()
        return d

    def get_widget_a(self, k):
        """
        Fetch the value of a Plan option CheckButton.

        k: string
            sub-option key

        Return: bool
            0 or 1
            Is the value of the CheckButton in the interface.
        """
        return self._check_button_d[k].get_ui()

    def load_a(self, d):
        """
        Load the CheckButton collective value.

        d: dict
            {sub-PlanOption Identity key: int}
        """
        d = self.set_ui(d)
        self.any_group.set_widget_a(self.key, d)

    def on_plan_button_switch(self, g):
        """
        A Plan CheckButton was switched. Send a Signal
        notifying Plan sub-option change listener.

        g: CheckButton
            Is responsible.
        """
        a = g.get_ui()
        b = g.any_group.get_view_a(0, g.key)
        self.emit(g.signal, (a, a != b))

    def set_ui(self, d):
        """
        Set the value of the CheckButtons.

        d: dict
            for group

        Return: OrderedDict
            PlanOption value
        """
        e = OrderedDict()

        for k, g in self._check_button_d.items():
            if k in d:
                e[k] = g.set_ui(d[k])
            else:
                e[k] = g.set_ui(0)
        return e


# Register the custom signals.
gobject.type_register(PlanOption)
