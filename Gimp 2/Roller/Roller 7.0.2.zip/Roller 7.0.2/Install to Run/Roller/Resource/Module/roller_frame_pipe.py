#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, CHANNEL_OP_SUBTRACT, pdb  # type: ignore
from roller_constant_identity import Identity as de
from roller_container import Run
from roller_frame import grow_wrap
from roller_frame_alt import FrameBasic
from roller_frame_profile import ROUTE_PROFILE
from roller_gimp_context import set_fill_context_default
from roller_gimp_image import add_layer
from roller_gimp_layer import color_selection, select_layer
from roller_gimp_mode import get_mode
from roller_gimp_selection import select_channel


def do_matter(maya):
    """
    Make a frame.

    maya: Pipe
    Return: layer or None
        Pipe Wrap 'matter'
    """
    d = maya.value_d
    z = add_layer(Run.j, maya.group, maya.get_light(), "Material")
    w = d[de.WIDTH]
    q = ROUTE_PROFILE[d[de.PROFILE]](w)

    set_fill_context_default()
    select_layer(maya.cast.matter)
    draw_profile(z, w, d[de.HEIGHT], q)

    z.opacity = d[de.OPACITY]
    z.mode = get_mode(d, k=de.MODE)
    return z


def draw_profile(z, w, h, q):
    """
    Draw a color-type gradient frame using a profile.

    z: layer
        Receive profile color.

    w: float
        width of profile

    h: float
        height of profile

    q: list
        of profile
        in .0 to 1.
    """
    j = z.image

    # selections
    a = b = None

    for i in range(int(w)):
        if a:
            # Do now to save memory for large frames.
            pdb.gimp_image_remove_channel(j, a)

        a = b = pdb.gimp_selection_save(j)
        if b:
            grow_wrap(j, None, 1, de.ANGULAR)
            select_channel(j, b, option=CHANNEL_OP_SUBTRACT)

            color = int(round(q[i] * h))

            color_selection(z, (color, color, color))
            select_channel(j, b, option=CHANNEL_OP_ADD)
    if b:
        pdb.gimp_image_remove_channel(j, b)


class Pipe(FrameBasic):
    kind = material = de.PIPE
    wrap_k = de.WRAP_PI

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Identity, ...)
            Locate Maya vote.
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
