#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_identity import Identity as de
from roller_port_preview import PortPreview
from roller_widget_dna import DNA

GENERIC_ATTR_SET = {'make_vbox', 'preset'}


# PortGeneric__________________________________________________________________
class PortGeneric(PortPreview):
    """Display Preset Widget."""

    def __init__(self, d, g, k, is_random=True, is_switched=True):
        """
        d: dict
            Initialize the Port.

        g: Button
            Is responsible.

        k: string
            Preset Identity
        """
        self.true_attr_set = set()

        self.true_attr_set.update(GENERIC_ATTR_SET)

        if is_switched:
            self.true_attr_set.update({'switched'})

        self._is_random = is_random
        self._preset_k = k
        PortPreview.__init__(self, d, g)

    def _draw(self, box):
        """
        Draw the Preset's option group.

        box: GTK container
            Receive the Widget group.
        """
        dna = DNA(self._preset_k, self.true_attr_set, {})

        dna.inherit(self.repo.any_group.dna, False)
        box.add(dna.vbox)
        self.draw_group(dna)

    def draw(self):
        """Draw Widget."""
        p = self.draw_random_process_group if self._is_random \
            else self.draw_process
        self.draw_column((self._draw, p))

    def get_group_value(self):
        """
        Get the Preset value dict.

        Return: dict
            Preset
        """
        return self.any_group.get_value_d()


class PortBelow(PortGeneric):
    window_key = de.BELOW

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.BELOW)


class PortBlur(PortGeneric):
    window_key = de.BLUR

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.BLUR_D)


class PortBrush(PortGeneric):
    window_key = de.BRUSH

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.BRUSH_D)


class PortBrushPD(PortGeneric):
    window_key = de.BRUSH

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.BRUSH_D1)


class PortBump(PortGeneric):
    window_key = de.BUMP

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.BUMP)


class PortColor(PortGeneric):
    window_key = de.COLOR

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.COLOR)


class PortEmboss(PortGeneric):
    window_key = de.EMBOSS

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.EMBOSS)


class PortGrid(PortGeneric):
    window_key = de.GRID

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.GRID)


class PortInset(PortGeneric):
    window_key = de.INSET

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.INSET)


class PortMargin(PortGeneric):
    window_key = de.MARGIN

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.MARGIN)


class PortMod(PortGeneric):
    window_key = de.MOD

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.MOD)


class PortNoise(PortGeneric):
    window_key = de.NOISE

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.NOISE_D)


class PortResize(PortGeneric):
    window_key = de.RESIZE

    def __init__(self, d, g):
        PortGeneric.__init__(
            self, d, g, de.RESIZE, is_random=False, is_switched=False
        )


class PortStencil(PortGeneric):
    window_key = de.STENCIL

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.STENCIL)


class PortStrip(PortGeneric):
    window_key = de.STRIP

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.STRIP)


class PortTape(PortGeneric):
    window_key = de.TAPE

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.WRAP_TA)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# PortGenericAdd________________________________________________________________
class PortGenericAdd(PortGeneric):
    window_key = de.ADD

    def __init__(self, d, g, k):
        PortGeneric.__init__(self, d, g, k, is_random=False)


class PortAdd(PortGenericAdd):

    def __init__(self, d, g):
        PortGenericAdd.__init__(self, d, g, de.ADD)


class PortAddAbove(PortGenericAdd):

    def __init__(self, d, g):
        PortGenericAdd.__init__(self, d, g, de.ADD_ABOVE)


class PortAddAlt(PortGenericAdd):

    def __init__(self, d, g):
        PortGenericAdd.__init__(self, d, g, de.ADD_ALT)


# PortFiller___________________________________________________________________
class PortFiller(PortGeneric):
    window_key = de.FILLER

    def __init__(self, d, g, k):
        PortGeneric.__init__(self, d, g, k)


class PortFillerCeramic(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, de.FILLER_CE)


class PortFillerChecker(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, de.FILLER_CH)


class PortFillerFence(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, de.FILLER_FE)


class PortFillerHoley(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, de.FILLER_HO)


class PortFillerMaze(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, de.FILLER_MA)


class PortFillerMecha(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, de.FILLER_ME)


class PortFillerMirror(PortFiller):

    def __init__(self, d, g):
        """d, g: PortGeneric spec"""
        PortFiller.__init__(self, d, g, de.FILLER_MI)


class PortFillerRad(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, de.FILLER_RA)


class PortFillerStained(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, de.FILLER_S1)


class PortFillerStretch(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, de.FILLER_S2)


class PortFillerStripe(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, de.FILLER_S3)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# PortOverlay__________________________________________________________________
class PortOverlay(PortGeneric):
    window_key = de.OVERLAY

    def __init__(self, d, g, k):
        PortGeneric.__init__(self, d, g, k)


class PortOverlayBevel(PortOverlay):

    def __init__(self, d, g):
        PortOverlay.__init__(self, d, g, de.OVERLAY_BE)


class PortOverlayCamo(PortOverlay):

    def __init__(self, d, g):
        PortOverlay.__init__(self, d, g, de.OVERLAY_CA)


class PortOverlayOver(PortOverlay):

    def __init__(self, d, g):
        PortOverlay.__init__(self, d, g, de.OVERLAY_OV)
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾


# PortWrap_____________________________________________________________________
class PortWrap(PortGeneric):
    window_key = de.WRAP

    def __init__(self, d, g, k=de.WRAP):
        PortGeneric.__init__(self, d, g, k)


class PortWrapAddAbove(PortGeneric):
    window_key = de.ADD

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, de.WRAP_AB)


class PortWrapAlt(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_AL)


class PortWrapBevel(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_BE)


class PortWrapBurst(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_BU)


class PortWrapCanvas(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_CA)


class PortWrapClear(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_CL)


class PortWrapCrumble(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_CR)


class PortWrapDecay(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_DE)


class PortWrapFill(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_FI)


class PortWrapGlue(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_GL)


class PortWrapGradual(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_GR)


class PortWrapJoint(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_JO)


class PortWrapNet(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_NT)


class PortWrapOverlap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_OL)


class PortWrapPattern(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_PA)


class PortWrapPipe(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_PI)


class PortWrapWobble(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=de.WRAP_WO)
