#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_comm import pop_up, show_err
from roller_constant import Define as df
from roller_constant_identity import Identity as de
from roller_container import PresetIO
from roller_oz import make_preset_path
from roller_port_process import PortProcess
from roller_widget_box import Box as boxer
from roller_widget_button import AcceptButton, Button, CancelButton
from roller_widget_tree import ChoiceList
import glob
import gtk  # type: ignore
import os


def collect_preset(preset_key):
    """
    Collect internal and external Preset.

    preset_key: string
        Preset key

    Return: tuple
        (Preset dict, Preset name list)
    """
    # list of Presets, 'q'
    q = [de.DEFAULT]

    ext_files = []
    go = False
    external_preset = {}
    search_path = make_preset_path(preset_key, u"*")

    try:
        # Ignore sub-directory.
        ext_files = glob.glob(search_path)
        go = True

    except Exception as ex:
        show_err(ex)
        show_err("Roller was unable to load presets.")

    if go:
        # Make an external Preset file list.
        for n in ext_files:
            name = os.path.splitext(os.path.basename(n))[0]
            external_preset[name] = n
            q.append(name)
    return external_preset, q


class PortPreset(PortProcess):
    """Is a Port for loading, saving, and deleting a Preset file."""
    window_key = "Preset"

    def __init__(self, d, g):
        """
        d: dict
            Has init values.

        g: Button
            Is responsible.
        """
        self.item_key = g.any_group.dna.key
        self._external_preset = {}
        self._dependent_button = []
        self._del_button = self._load_button = self._choice_list = None
        PortProcess.__init__(self, d, g)

    def _draw_list_group(self, g):
        """
        Draw a ChoiceList containing a Preset list.

        g: GTK container
            for list group
        """
        self._external_preset, self._preset_list = collect_preset(
            self.item_key
        )
        self._choice_list = ChoiceList(
            **{
                df.CHOICE: "Default",
                df.FUNCTION: self.get_preset_list,
                df.RELAY: [self.on_port_change],
                df.ROLLER_WIN: self.roller_win,
                df.TREE_COLOR: self.color
            }
        )

        g.pack_start(self._choice_list, expand=True)
        self.on_port_change(self._choice_list)

        # Connect event.
        self._choice_list.treeview.connect(
            'key_press_event', self._on_choice_list_keypress
        )

    def _get_selection(self):
        """
        Get the selection in the ChoiceList.

        Return: int or None
            0 to n
        """
        if self._choice_list:
            return self._choice_list.get_selected_r()

    def delete_preset(self, *_):
        """
        Delete the selected Preset.

        _: Button
            the delete Button
            not used
        """
        i = self._get_selection()
        if i is not None:
            n = self._choice_list.get_selected_item()
            if n in self._external_preset:
                path = self._external_preset[n]
                if pop_up(
                    self.roller_win.gtk_win,        # Use dialog.
                    0,
                    "Do you want to delete:\n{}?".format(path),
                    "Delete a File Confirmation"
                ):
                    try:
                        os.remove(path)
                        pop_up(
                            self.roller_win.gtk_win,        # Use dialog.
                            1,
                            "The file:\n" + path + "\nwas removed.",
                            "File Deleted"
                        )
                        self._external_preset.pop(n)
                        self._choice_list.remove_row(i)
                        self.on_port_change(self._choice_list)
                    except Exception as ex:
                        show_err(ex)
                        show_err("Roller was unable to delete the file.")

    def draw_process_group(self, g):
        """
        Draw a Widget group having process Buttons.

        g: GTK container
            to receive group
        """
        hbox = boxer(box=gtk.HBox, align=(0, 0, 1, 1))
        cancel_button = CancelButton(
            align=(0, 0, 1, 0),
            padding=(4, 4, 4, 2),
            relay=[],
            roller_win=self.roller_win,
        )
        self._del_button = Button(
            align=(0, 0, 1, 0),
            padding=(4, 4, 2, 2),
            relay=[self.delete_preset],
            roller_win=self.roller_win,
            text="Delete"
        )
        self._load_button = AcceptButton(
            align=(0, 0, 1, 0),
            padding=(4, 4, 2, 4),
            relay=[],
            roller_win=self.roller_win
        )
        q = cancel_button, self._del_button, self._load_button
        self._dependent_button = self._del_button, self._load_button

        for i in q:
            hbox.add(i)

        g.pack_end(hbox, expand=False)
        self.keep(q)

    def draw(self):
        """Draw Widget."""
        self.draw_list(
            (self._draw_list_group, self.draw_process_group),
            ("Available {}".format(self.item_key), "")
        )
        self.roller_win.gtk_win.vbox.set_size_request(350, 350)

    def get_preset_list(self):
        return self._preset_list

    def load_preset(self, *_):
        """Load a chosen Preset."""
        if self._choice_list.get_selected_r() is not None:
            preset_g = self.repo.any_group.get_widget(de.PRESET)
            n = self._choice_list.get_selected_item()
            PresetIO.preset_name = n if n != de.DEFAULT else de.PRESET

            self.roller_win.gtk_win.hide()
            preset_g.load_file(n, self.item_key)

    def get_group_value(self):
        """
        Load the selected Preset.

        Return: True
            for GTK
        """
        return self.load_preset()

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return lambda: None, self.load_preset

    def _on_choice_list_keypress(self, _, event):
        """
        Respond to ChoiceList Treeview keypress. Determine
        if the keypress is a Delete key, call the
        confirmation dialog.

        _: ChoiceList's GTK TreeView
            not used

        event: GTK Event
            not used
        """
        if gtk.gdk.keyval_name(event.keyval) == 'Delete':
            self.delete_preset()
            return True

    def on_port_change(self, g):
        """
        Respond to a list choice.

        g: ChoiceList
            with a Preset-name list
        """
        if self._get_selection() is not None:
            for i in self._dependent_button:
                i.set_sensitive(1)
        else:
            for i in self._dependent_button:
                i.set_sensitive(0)
