#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD,
    CHANNEL_OP_INTERSECT,
    CHANNEL_OP_REPLACE,
    CHANNEL_OP_SUBTRACT,
    pdb
)
from roller_constant import Row as rk
from roller_constant_identity import Identity as de
from roller_container import Globe, Run
from roller_frame import (
    make_canvas_frame_sc, emboss_selection, select_wrap
)
from roller_frame_alt import FrameBasic
from roller_gimp_context import set_gimp_brush
from roller_gimp_image import add_layer, add_wip_layer
from roller_gimp_layer import select_layer, verify_layer
from roller_gimp_selection import select_channel, select_rect


def do_matter(maya):
    """
    Make the frame.

    maya: Maze/Wrap
    Return: layer
        Wrap 'matter'
    """
    j = Run.j
    d = maya.value_d
    e = maya.super_maya.value_d[rk.BRW][de.FILLER_MA]
    x, y, w, h = maya.model.canvas_rect
    cast_z = maya.cast.matter

    select_wrap(j, cast_z, d[de.WIDTH], d[de.TYPE])

    wrap_sc = pdb.gimp_selection_save(j)

    # Canvas frame
    pdb.gimp_selection_none(j)
    make_canvas_frame_sc(maya, cast_z, e)

    canvas_frame_sc = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)

    # layers for the maze, 'z', 'z1'
    z = add_wip_layer("Maze", None, 0)
    z1 = add_wip_layer("Material", None, 0)

    pdb.gimp_context_set_foreground((0, 0, 0))
    pdb.gimp_context_set_background((255, 255, 255))
    pdb.plug_in_maze(
        j, z,
        int(max(1, w // e[de.COLUMN])),     # passage scale
        int(max(1, h // e[de.ROW])),        # passage scale
        1,                                      # yes, tileable
        0,                                      # depth first algorithm
        int(e[de.RANDOM_SEED] + Globe.seed),
        0,                                      # multiple, not clearly defined
        0                                       # offset, not clearly defined
    )

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z)
    do_stroke(z1, e[de.LINE_W])
    pdb.gimp_image_select_item(j, CHANNEL_OP_REPLACE, z1)

    if e[de.CLIP]:
        select_layer(cast_z, option=CHANNEL_OP_SUBTRACT)

    for i in (z, z1):
        pdb.gimp_image_remove_layer(j, i)

    # layer for the combined frame, 'z'
    z = add_layer(j, maya.group, maya.get_light(), "Material")

    for i in (wrap_sc, canvas_frame_sc):
        select_channel(j, i, option=CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, i)

    # Clip selection to canvas.
    select_rect(Run.j, x, y, w, h, option=CHANNEL_OP_INTERSECT)

    return verify_layer(emboss_selection(z, d))


def do_stroke(z, w):
    """
    Stoke the maze selection.

    z: layer
        Receive stroke material.

    w: float
        Is the width of the stroke.
    """
    pdb.gimp_context_set_antialias(0)
    pdb.gimp_context_set_line_width(w)
    pdb.gimp_context_set_foreground((0, 0, 0))
    pdb.gimp_context_set_opacity(100.)
    pdb.gimp_context_set_stroke_method(0)       # line stroke
    pdb.gimp_drawable_edit_stroke_selection(z)


class Maze(FrameBasic):
    filler_k = de.FILLER_MA
    kind = material = de.MAZE
    wrap_k = de.WRAP_CA

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
