#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_key import ModelList as ml

# Note that a panel step key uses a model name
# (e.g. '(Table 1, Cell, Type)' is a panel step key.).


class Shelf:
    """Manage the offline dictionary that ModelList loads."""
    _d = {}

    @staticmethod
    def clear_shelf():
        Shelf._d.clear()

    @staticmethod
    def finds(k):
        """
        Determine if a panel step key is shelved.

        k: tuple
            panel step key

        Return: bool
            Is True if the key is shelved.
        """
        return bool(k in Shelf._d)

    @staticmethod
    def get_model_step_q(n):
        """
        Create a list of a Model's panel step key.

        n: string
            Model name
            Only step with this model name will be returned.

        Return: list
            [panel step key,]
        """
        # Model name index in a panel step key, '0'
        return [i for i in Shelf._d.keys() if n == i[0]]

    @staticmethod
    def get_shelf_d():
        """
        Make a copy of the shelf dict.

        Return: dict
            shelf dict copy
        """
        return deepcopy(Shelf._d)

    @staticmethod
    def get_step_d(k):
        """
        Fetch the shelved Preset for a panel step key.

        k: tuple
            panel step key

        Return: dict or None
            Is a Preset value dict.
        """
        if k in Shelf._d:
            return Shelf._d[k]

    @staticmethod
    def get_step_q():
        """
        Fetch a list of shelved panel step key.

        Return: list
            [panel key,]
        """
        return Shelf._d.keys()

    @staticmethod
    def remove_model(n):
        """
        Remove step having a Model name reference from the shelf dict.

        n: string
            Model name key
        """
        d = Shelf._d
        for i in d.keys():
            # index of a model name in a panel step key, '0'
            if n == i[0]:
                d.pop(i)

    @staticmethod
    def remove_step(k):
        """
        Remove a panel step key from the shelf dict.

        k: tuple
            panel step key
        """
        if k in Shelf._d:
            Shelf._d.pop(k)

    @staticmethod
    def set_d(d, model_def):
        """
        Set the Shelf dict from a new dict.

        d: dict
            {panel step key: Preset dict}

        model_def: list
            [(Model name, Model type), ...]
        """
        name_q = [i[ml.NAME_INDEX] for i in model_def]

        # Sync the Shelf dict with a Model definition list.
        for i in d.keys():
            # Model name index, '0'
            if i[0] not in name_q:
                # Repair.
                d.pop(i)
        Shelf._d = d

    @staticmethod
    def set_step(k, a):
        """
        Set the value of a panel step key in the shelf dict.

        k: tuple
            panel step key

        a: value
            Is the value of the step's Preset.
        """
        Shelf._d[k] = a
