#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Shape as sh, Triangle as ft
from roller_polygon_box_hex import calc_box_hex
from roller_polygon_box_hex_trunc import calc_box_hexT
from roller_polygon_circle import calc_grid_circle
from roller_polygon_miter_square import calc_miter_square
from roller_polygon_ellipse_horz import calc_ellipse_horz
from roller_polygon_ellipse_vert import calc_ellipse_vert
from roller_polygon_hexagon import calc_hexagon
from roller_polygon_hexagon_truncated import calc_hexT
from roller_polygon_octagon import calc_octagon
from roller_polygon_octagon_double import calc_octagon_double
from roller_polygon_parallelogram import calc_parallelogram
from roller_polygon_parallelogram_alt import calc_parallelogram_alt
from roller_polygon_rect import calc_grid_rect
from roller_polygon_triangle_horz import calc_triangle_horz
from roller_polygon_triangle_vert import calc_triangle_vert

"""
Define 'polygon_route' a look-up dict for translating
a cell shape into its polygon calculator.
"""

# Convert a shape descriptor to a cell grid calculator.
# {shape descriptor string: polygon calculator function}
CALC_POLYGON = {
    sh.BOX_HORZ: calc_box_hexT,
    sh.BOX_HORZ_SHEAR: calc_box_hexT,
    sh.BOX_VERT: calc_box_hex,
    sh.BOX_VERT_SHEAR: calc_box_hex,
    sh.CIRCLE_HORIZONTAL: calc_grid_circle,
    sh.CIRCLE_VERTICAL: calc_grid_circle,
    sh.DIAMOND: calc_miter_square,
    sh.ELLIPSE_HORIZONTAL: calc_ellipse_horz,
    sh.ELLIPSE_VERTICAL: calc_ellipse_vert,
    sh.HEXAGON: calc_hexagon,
    sh.HEXAGON_SHEAR: calc_hexagon,
    sh.HEXAGON_TRUNCATED: calc_hexT,
    sh.HEXAGON_TRUNCATED_SHEAR: calc_hexT,
    sh.MITER_SQUARE: calc_miter_square,
    sh.OCTAGON_DOUBLE: calc_octagon_double,
    sh.OCTAGON_DOUBLE_SHEAR: calc_octagon_double,
    sh.OCTAGON_SHEAR: calc_octagon,
    sh.OCTAGON: calc_octagon,
    sh.OCTAGON_ON_ITS_SIDE: calc_octagon,
    sh.OCTAGON_ON_ITS_SIDE_SHEAR: calc_octagon,
    sh.PARALLELOGRAM_ALT_LEFT: calc_parallelogram_alt,
    sh.PARALLELOGRAM_ALT_RIGHT: calc_parallelogram_alt,
    sh.PARALLELOGRAM_LEFT: calc_parallelogram,
    sh.PARALLELOGRAM_RIGHT: calc_parallelogram,
    sh.RECTANGLE: calc_grid_rect,
    sh.SQUARE: calc_grid_rect,
    ft.TRIANGLE_DOWN_SHEAR: calc_triangle_vert,
    ft.TRIANGLE_DOWN_REGULAR: calc_triangle_vert,
    ft.TRIANGLE_UP_SHEAR: calc_triangle_vert,
    ft.TRIANGLE_UP_REGULAR: calc_triangle_vert,
    ft.TRIANGLE_LEFT_SHEAR: calc_triangle_horz,
    ft.TRIANGLE_LEFT_REGULAR: calc_triangle_horz,
    ft.TRIANGLE_RIGHT_SHEAR: calc_triangle_horz,
    ft.TRIANGLE_RIGHT_REGULAR: calc_triangle_horz
}
