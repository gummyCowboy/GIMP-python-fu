#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_a_contain import Globe, Run
from roller_constant_key import Option as ok
from roller_fu import clone_layer, merge_layer_group
from roller_maya_style import Style
from roller_one_wip import Wip
from roller_view_hub import do_mod
from roller_view_preset import combine_seed
from roller_view_real import add_sub_base_group, add_wip_layer

"""
Define 'backdrop/fading_maze' as a Maya-subtype
for managing a variation of backdrop style layer.
"""


def make_style(maya):
    """
    Make a style layer.

    maya: Style
    Return: layer or None
        Fading Maze material
    """
    j = Run.j
    d = maya.value_d
    group = add_sub_base_group(maya)
    z = add_wip_layer("Base", group)

    combine_seed(d)
    pdb.gimp_context_set_background(d[ok.COLOR_2A][0])
    pdb.gimp_context_set_foreground(d[ok.COLOR_2A][1])

    w = max(1, Wip.w // d[ok.COLUMN])
    h = max(1, Wip.h // d[ok.ROW])

    pdb.plug_in_maze(
        j, z,
        w, h,               # passage scale
        1,                  # yes, tileable
        0,                  # depth first algorithm
        d[ok.SEED] + Globe.seed,
        0,                  # multiple
        0                   # offset
    )

    # primary output, 'z'
    z = merge_layer_group(group)
    group = add_sub_base_group(maya)

    # Move the primary output to the group.
    pdb.gimp_image_reorder_item(j, z, group, 0)

    z1 = clone_layer(z)
    z2 = clone_layer(z1)

    pdb.gimp_selection_none(j)

    # Calculate transform coordinate.
    x = Wip.x
    y = Wip.y
    x1 = x + Wip.w
    y1 = y + Wip.h
    mid_x = (x + x1) / 2.
    mid_y = (y + y1) / 2.
    mid_x1 = mid_x - 1
    mid_y1 = mid_y - 1
    mid_x2 = mid_x + 1

    # Coordinate is a float.
    # point order: topleft, top-right, bottom-left, bottom-right
    q = x, y - 1, mid_x2, mid_y - 1, x, y1, mid_x2, y1
    q1 = mid_x1, mid_y1, x1, mid_y1, x, y1, x1, y1
    q2 = x, y, x1, y, mid_x, mid_y, x1, mid_y

    # Transform three times.
    # left
    pdb.gimp_item_transform_perspective(z, *map(round, q))

    # bottom
    pdb.gimp_item_transform_perspective(z1, *map(round, q1))

    # top
    pdb.gimp_item_transform_perspective(z2, *map(round, q2))

    z = merge_layer_group(group)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class FadingMaze(Style):
    """Create Backdrop Style output."""
    is_dependent = False

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.BRW, ok.MOD, ok.BLUR_D)
            ],
            make_style
        )
