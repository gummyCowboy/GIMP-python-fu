#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Shape as sh

"""
Include function for calculating Box Face geometry for 'face_2'.

The Box direction is the Face position. Each position
has its own function for calculating geometry.
"""


def do_bottom(q, cap_x, cap_y, side):
    """
    Is a right-side mirrored polygon for the Bottom Box Type.

    q: tuple
        Define polygon shape.

    cap_x, cap_y: float
        Is the coordinate for the inner vertex.

    side: tuple
        (side1 length, side2 length, side3 length)

    Return: tuple
        (foam, and size of the Face)
    """
    return (
        # transform function's input
        (
            q[2], q[3],
            q[4], q[5],
            cap_x, cap_y,
            q[6], q[7]
        ),

        # size of face, (w, h)
        side[1], side[2]
    )


def do_left(q, cap_x, cap_y, side):
    """Is a bottom side mirrored polygon for the Left Box Type."""
    return (
        # transform function's input
        (
            cap_x, cap_y,
            q[6], q[7],
            q[10], q[11],
            q[8], q[9]
        ),

        # size of face, (w, h)
        side[1], side[0]
    )


def do_right(q, cap_x, cap_y, side):
    """Is a bottom side mirrored polygon for the Right Box Type."""
    return (
        # transform function's input
        (
            q[0], q[1],
            cap_x, cap_y,
            q[10], q[11],
            q[8], q[9]
        ),

        # size of face, (w, h)
        side[1], side[2]
    )


def do_top(q, cap_x, cap_y, side):
    """
    Is a right side mirrored polygon for the Top Box Type.
    """
    return (
        # transform function's input
        (
            cap_x, cap_y,
            q[4], q[5],
            q[8], q[9],
            q[6], q[7]
        ),

        # size of face, (w, h)
        side[0], side[2]
    )


FACE2_BUILD = {
    sh.BOTTOM: do_bottom,
    sh.LEFT: do_left,
    sh.RIGHT: do_right,
    sh.TOP: do_top
}
