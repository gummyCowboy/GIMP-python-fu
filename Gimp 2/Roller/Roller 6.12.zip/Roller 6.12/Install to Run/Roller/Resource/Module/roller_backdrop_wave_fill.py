#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    pdb, FOREGROUND_FILL, SELECT_CRITERION_COMPOSITE
)
from random import uniform
from roller_a_contain import Run
from roller_a_gegl import median_blur
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_wip import Wip
from roller_view_hub import (
    do_mod, prep_brush, set_draw_line_brush, set_fill_context_default
)
from roller_view_preset import combine_seed
from roller_view_real import add_wip_base
import math

"""
Define 'backdrop/wave_fill' as a Maya-subtype
for managing a variation of backdrop style layer.
"""


def calc_fill_color(d):
    """
    Calculate the a color gradient from given color and its inverse.
    The number colors or gradient steps is equal to the wave count plus
    one.

    d: dict
        Wave Fill Preset

    Return: list
        [RGB, ...]
        RGB is a tuple, (int, int, int), or,
        (red, green, blue) color component.
        0 <= component <= 255
    """
    red, green, blue = d[ok.COLOR_2][0]
    red1, green1, blue1 = d[ok.COLOR_2][1]
    a = d[ok.WAVE_COUNT]
    step_q = (red - red1) / a, (green - green1) / a, (blue - blue1) / a
    color_q = []

    for _ in range(int(a) + 1):
        red1, green1, blue1 = map(int, (red1, green1, blue1))
        color_q.append((red1, green1, blue1))

        red1 += step_q[0]
        green1 += step_q[1]
        blue1 += step_q[2]
    return color_q


def fill_wave(z, color, x, y):
    """
    Fill a wave region. At start, the filled region has no material.
    Spread color, like a fluid, into this region and stop at opaque pixel.

    z: layer
        Receive fill color.

    color: tuple
        RGB

    x, y: float
        Fill point.
    """
    pdb.gimp_context_set_sample_criterion(SELECT_CRITERION_COMPOSITE)
    pdb.gimp_context_set_foreground(color)
    pdb.gimp_drawable_edit_bucket_fill(z, FOREGROUND_FILL, x, y)


def plot_wave(start_y, amplitude):
    """
    Calculate the points for a wave that starts
    on the left of a Wip-sized layer and ends at its right.

    start_y: float
        Is the base line for the horizontal wave.

    amplitude: float
        Distinguish wave.

    Return: list
        [x, y, ...]
        plot
    """
    x = .0
    q = []
    angle = uniform(.0, 6.28)
    w = Wip.w
    wave_length = Wip.w

    # Pi x 2, '6.28318'
    f = 6.28318 / wave_length

    while x < w:
        y = math.sin(angle) * amplitude
        y = round(y + start_y)
        q += [x, y]
        x += 1
        angle += f
    return q


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: Style
    Return: layer or None
        Backdrop Style layer
    """
    j = Run.j
    d = maya.value_d
    parent = maya.group
    z = add_wip_base("Base", parent)

    combine_seed(d)
    prep_brush()
    set_draw_line_brush()
    set_fill_context_default()
    pdb.gimp_context_set_brush_size(3.)
    pdb.gimp_selection_none(j)

    # Stop Fill at 100% opaqueness, '.63'.
    pdb.gimp_context_set_sample_threshold(.63)

    color_q = calc_fill_color(d)
    a = int(d[ok.WAVE_COUNT])
    amp_h = Wip.h / a / 2.
    amp = round(amp_h * d[ok.AMPLITUDE])
    y = step_y = round(Wip.h / (a + 1))
    fill_x = this_y = .0

    # Fill all the waves except the last wave.
    for i in range(a):
        q = plot_wave(y, amp)
        color = color_q[i]
        fill_y = max(.0, round((this_y + q[1]) / 2.))
        this_y = q[1]

        pdb.gimp_context_set_foreground(color)
        pdb.gimp_paintbrush_default(z, len(q), q)
        fill_wave(z, color, fill_x, fill_y)
        y = round(y + step_y)

    # Fill the last wave.
    fill_y = Wip.h - 1
    color = color_q[i + 1]

    fill_wave(z, color, fill_x, fill_y)
    median_blur(z, 2., 50.)
    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class WaveFill(Style):
    """
    Create Backdrop Style output.

    This style was inspired by a video tutorial from PixLab.

    Reference
    youtube.com/watch?v=WEKow9bqtyk
    """
    is_dependent = False

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Has the Backdrop Style Button.

        super_maya: Backdrop Maya
        k_path: tuple
            Is the key path to the Backdrop Style
            Button in the AnyGroup's vote dict.
        """
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.BRW, ok.MOD, ok.BLUR_D)
            ],
            make_style
        )
