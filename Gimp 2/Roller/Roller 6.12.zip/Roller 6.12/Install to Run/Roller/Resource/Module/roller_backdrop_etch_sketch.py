#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (    # type: ignore
    LAYER_MODE_DARKEN_ONLY, LAYER_MODE_OVERLAY, pdb
)
from roller_a_contain import Globe, Run
from roller_constant_for import Backdrop as bs
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clear_selection,
    clone_layer,
    make_layer_group,
    merge_layer_group,
    select_color
)
from roller_maya_style import Style, make_background
from roller_view_hub import do_curves, do_mod

"""
Define 'backdrop/etch_sketch' as a Maya-subtype
for managing a variation of backdrop style layer.
"""

ETCH_WIP = "Etch Sketch WIP"


def make_style(maya):
    """
    Create a Etch Sketch Backdrop Style layer.

    maya: Style
    Return: layer or None
        Etch Sketch material
    """
    def _do_step_1():
        """
        Increase the strength of the line.

        Return: layer
            with modification
        """
        _group = make_layer_group(j, ETCH_WIP, parent, 0, z=z)
        _z1 = clone_layer(z, n="Overlay")
        _z1.mode = LAYER_MODE_OVERLAY

        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)

        return merge_layer_group(_group, n="Step 1")

    def _do_step_2():
        """
        Apply newsprint to line.

        Return: layer
            with modification
        """
        _f = Globe.azimuth

        while _f < 0:
            _f += 360

        _group = make_layer_group(j, ETCH_WIP, parent, 0, z=bg_z)

        pdb.gimp_image_reorder_item(j, z, _group, 0)

        z.mode = LAYER_MODE_DARKEN_ONLY
        _type = bs.NEWS_TYPE.index(d[ok.SKETCH_TEXTURE])

        pdb.plug_in_newsprint(
            j, z,
            int(d[ok.CELL_SIZE]),
            1,                  # RGB
            100,                # black
            _f,
            _type,
            _f,
            _type,
            _f,
            _type,
            _f,
            _type,
            2                   # sample
        )

        select_color(bg_z, (0, 0, 0), threshold=.25)
        clear_selection(z)
        blur_selection(bg_z, 500)
        do_curves(bg_z, (.0, .1, 1., .9))
        return merge_layer_group(_group, n="Step 2")

    j = Run.j
    d = maya.value_d
    parent, group, z = make_background(j, maya)
    bg_z = clone_layer(z)

    pdb.plug_in_edge(
        j, z,
        1.,             # edge amount
        0,              # no wrap
        0               # Sobel
    )

    z = _do_step_1()
    z = _do_step_2()
    z = merge_layer_group(parent)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class EtchSketch(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
