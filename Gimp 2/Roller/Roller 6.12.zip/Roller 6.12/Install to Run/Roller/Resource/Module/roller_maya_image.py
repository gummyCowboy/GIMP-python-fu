#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_for import Image as fi, Issue as vo, Plan as fy
from roller_constant_key import (
    Material as ma, Node as ny, Option as ok, Plan as ak, SubMaya as sm
)
from roller_deco import finish_backed, mask_cell_per
from roller_deco_image import (
    do_canvas,
    do_cell_main,
    do_cell_per,
    do_face_main,
    do_face_per,
    do_facing_main,
    do_facing_per,
    mask_cell_main,
    mask_face_main,
    mask_face_per,
    mask_facing_main,
    mask_facing_per
)
from roller_maya import (
    Canvas, CellRoute, FaceRoute, Mage, Main, Per
)
from roller_maya_layer import check_matter, check_mix_basic
from roller_maya_light import Light
from roller_maya_mask import Mask
from roller_maya_plan_detail import Detail
from roller_maya_plan_name import (
    draw_cell_main_name,
    draw_canvas_name,
    draw_cell_per_name,
    draw_face_main_name,
    draw_face_per_name,
    draw_facing_main_name,
    draw_facing_per_name
)
from roller_maya_add import Add
from roller_option_group import DecoImageGroup
from roller_view_option_list import Frame
from roller_view_real import (
    make_canvas_group, make_cast_group, remove_maya_z
)
from roller_view_step import get_planner

"""Define 'maya_image' as an Image option group's manager class."""


class Image(DecoImageGroup):
    """
    Manage Image Preset layer output. Create Widget
    group and assign Plan and Work delegates. Connect
    Face/Facing to the Cell/Shift calculation Signal
    to update their change state.
    """
    frame_row_k = ok.BRW

    def __init__(self, **d):
        DecoImageGroup.__init__(self, **d)

        self._image_d = self._mask_d = self._frame_d = None
        self.plan = {
            ny.CANVAS: PlanCanvas,
            ny.CELL: PlanCell,
            ny.FACE: PlanFace,
            ny.FACING: PlanFacing
        }[self.branch_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas,
            ny.CELL: WorkCell,
            ny.FACE: WorkFace,
            ny.FACING: WorkFacing
        }[self.branch_k](self)

    @staticmethod
    def get_image_d(d):
        """
        Return the Image Choice Preset if its use.

        d: dict
            Backdrop Preset
        """
        if d[ok.SWITCH]:
            e = d[ok.RW1][ok.IMAGE_CHOICE]
            if e[ok.SWITCH]:
                return e


class Chi(Mage):
    """Factor Plan and Work."""
    is_seeded = True

    def __init__(self, any_group, view_i, make_mask, get_mask_d, q):
        """
        view_i: int
            0 or 1
            Plan or Work index

        make_mask: function
            Manage Mask output for the matter layer.

        q: iterable
            Direct output.
        """
        Mage.__init__(
            self,
            any_group,
            view_i,
            q,
            [
                (),
                (ok.RW1, ok.IMAGE_CHOICE),
                (ok.RW1, ok.RESIZE),
                (ok.BRW, ok.MOD),
                (ok.BRW, ok.MOD, ok.BLUR_D)
            ]
        )
        self.set_issue()

        self.sub_maya[sm.FRAME] = Frame(any_group, self, (ok.BRW, ok.FRAME))
        self.sub_maya[sm.MASK] = Mask(
            any_group, self, view_i, make_mask, get_mask_d, (ok.RW1, ok.MASK)
        )

    def on_global_seed(self, _, arg):
        """
        The Global Random Seed option has changed.
        Check to see if the layer output is seed dependent.

        _: Ring
            Sent the signal.

        arg: tuple
            (Plan vote, Work vote)
        """
        d = self.any_group.value_d if self.vote_type == vo.MAIN else \
            self.per_group.get_item(self.k)
        e = self.any_group.get_image_d(d)

        if e and e[ok.TYPE] != fi.RANDOM:
            # no change
            arg = [False, False]
        super(Chi, self).on_global_seed(_, arg)


class Plan(Chi):
    """Manage layer output for Draft and Plan views."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, make_mask, get_mask_d, draw_name):
        """
        any_group: AnyGroup
        make_mask: function
            Mask the matter layer.

        get_mask_d: function
            Retrieve the Mask Preset from the Image Preset.

        draw_name: function or None
            Make an image name text layer.
        """
        Chi.__init__(self, any_group, 0, make_mask, get_mask_d, self.put)

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.IMAGE)

        self.latch(
            planner, (fy.SIGNAL_D[ak.IMAGE], self.on_plan_option_change)
        )
        if draw_name:
            self.sub_maya[sm.NAME] = Detail(
                any_group, self, draw_name, ak.NAME
            )

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d
        self.go = d[ok.SWITCH]

        if self.go:
            if self.is_planned:
                self.is_matter |= self.is_switched
            else:
                # Produce a layer group and nothing else.
                # Plan Detail/name requires the layer group.
                remove_maya_z(self, 'matter')
                self.is_matter = False

        self.realize()
        if self.go:
            if self.matter:
                self.sub_maya[sm.MASK].do(d[ok.RW1][ok.MASK], self.is_matter)

                a = self.sub_maya[sm.NAME]
                if a:
                    a.do()
            else:
                self.die()

    def on_plan_option_change(self, _, arg):
        """Respond to change in the Planner's Image checkbox."""
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage Peek, Preview, and render view layer output."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, make_mask, get_mask_d):
        """
        make_mask: function
            Mask the matter layer.

        get_mask_d: function
            Fetch a Mask Preset from the Image Preset.
        """
        Chi.__init__(self, any_group, 1, make_mask, get_mask_d, self.put)

        self.sub_maya[sm.ADD] = Add(any_group, self, (ok.BRW, ok.ADD))
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.IMAGE)

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d
        self.go = d[ok.SWITCH]
        is_back = Run.is_back

        self.realize()
        if self.go:
            if self.matter:
                is_mask = self.sub_maya[sm.MASK].do(
                    d[ok.RW1][ok.MASK], self.is_matter
                )
                self.sub_maya[sm.ADD].do(
                    d[ok.BRW][ok.ADD],
                    self.is_matter,
                    is_mask,
                    is_back,
                    self.group
                )
                finish_backed()

                m = self.is_matter or is_mask

                self.sub_maya[sm.FRAME].do(d[ok.BRW][ok.FRAME], m)
                self.sub_maya[sm.LIGHT].do(m)
            else:
                self.die()


class WorkMain(Main, Work):
    """Manage Work layer output for main."""

    def __init__(self, *q, **d):
        """
        arg: tuple
            Work spec

        kwarg: dict
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *q + (self.get_mask_d,), **d)


# Canvas_______________________________________________________________________
class Cloth:
    """Factor Plan and Work Canvas Maya."""

    def __init__(self):
        self.do_matter = do_canvas


class PlanCanvas(Main, Plan, Canvas, Cloth):
    """Manage Plan/Canvas simulated layer output."""
    issue_q = vo.PLAN
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Main.__init__(self)
        Plan.__init__(
            self,
            any_group,
            mask_cell_per,
            self.get_mask_d,
            draw_canvas_name
        )
        Canvas.__init__(self)
        Cloth.__init__(self)


class WorkCanvas(WorkMain, Canvas, Cloth):
    """Manage Work's Canvas output."""
    issue_q = vo.WORK
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        self.do_matter = do_canvas

        # for error test
        WorkMain.__init__(self, any_group, mask_cell_per)
        Canvas.__init__(self)
        Cloth.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:
    """Factor Plan and Work Cell Maya."""
    is_face = False

    def __init__(self):
        self.do_matter = do_cell_main


class PlanCell(Main, Plan, CellRoute, Cellular):
    """Manage Plan Cell output."""
    issue_q = vo.PLAN_PER

    def __init__(self, any_group):
        Main.__init__(self)
        Plan.__init__(
            self,
            any_group,
            mask_cell_main,
            self.get_mask_d,
            draw_cell_main_name
        )
        CellRoute.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, CellRoute, Cellular):
    """Manage Work Cell output."""
    issue_q = vo.WORK_PER

    def __init__(self, any_group):
        WorkMain.__init__(self, any_group, mask_cell_main)
        CellRoute.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Plan Cell/Per output."""
    is_face = False
    issue_q = vo.PLAN

    def __init__(self, any_group, k):
        Plan.__init__(
            self, any_group, mask_cell_per, self.get_mask_d, draw_cell_per_name
        )
        Per.__init__(self, do_cell_per, k)


class WorkCellPer(Work, Per):
    """Manage Work Cell/Per output."""
    is_face = False
    issue_q = vo.WORK

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            Has the Per option.

        k: tuple
            (row, column)
            cell index and Goo key
        """
        Work.__init__(self, any_group, mask_cell_per, self.get_mask_d)
        Per.__init__(self, do_cell_per, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    """Factor from Plan and Work Face Maya."""
    is_face = True

    def __init__(self):
        self.do_matter = do_face_main


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage Plan Face output."""
    issue_q = vo.PLAN_PER

    def __init__(self, any_group):
        self.do_matter = do_face_main

        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(
            self,
            any_group,
            mask_face_main,
            self.get_mask_d,
            draw_face_main_name
        )
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, FaceRoute):
    """Manage Work Face output."""
    issue_q = vo.WORK_PER

    def __init__(self, any_group):
        self.do_matter = do_face_main

        Face.__init__(self)
        WorkMain.__init__(self, any_group, mask_face_main)
        FaceRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per Cell________________________________________________________________
class FacePer(Per):
    """Factor Plan and Work Face/Per Maya."""
    is_face = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacePer(Plan, FacePer):
    """Manage Plan Face/Per output."""
    issue_q = vo.PLAN

    def __init__(self, any_group, k):
        """
        k: tuple
            (row, column, face)
        """
        Plan.__init__(
            self,
            any_group,
            mask_face_per,
            self.get_mask_d,
            draw_face_per_name
        )
        FacePer.__init__(self, do_face_per, k)


class WorkFacePer(Work, FacePer):
    """Manage Work Face/Per output."""
    issue_q = vo.WORK

    def __init__(self, any_group, k):
        """
        k: tuple
            (row, column, face)
        """
        Work.__init__(self, any_group, mask_face_per, self.get_mask_d)
        FacePer.__init__(self, do_face_per, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing_______________________________________________________________________
class Facing:
    """Factor Plan and Work Facing."""
    is_face = True

    def __init__(self):
        self.do_matter = do_facing_main


class PlanFacing(Facing, Main, Plan, FaceRoute):
    """Manage Plan Facing output."""
    issue_q = vo.PLAN_PER

    def __init__(self, any_group):
        Facing.__init__(self)
        Main.__init__(self)
        Plan.__init__(
            self, any_group,
            mask_facing_main,
            self.get_mask_d,
            draw_facing_main_name
        )
        FaceRoute.__init__(self, PlanFacingPer)


class WorkFacing(Facing, WorkMain, FaceRoute):
    """Manage Work Facing output."""
    issue_q = vo.WORK_PER

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Facing.__init__(self)
        WorkMain.__init__(self, any_group, mask_facing_main)
        FaceRoute.__init__(self, WorkFacingPer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing Per Cell______________________________________________________________
class FacingPer(Per):
    """Factor Plan and Work Facing/Per Maya."""
    is_face = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacingPer(Plan, FacingPer):
    """Manage Plan Facing/Image/Per output."""
    issue_q = vo.PLAN

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(
            self,
            any_group,
            mask_facing_per,
            self.get_mask_d,
            draw_facing_per_name
        )
        FacingPer.__init__(self, do_facing_per, k)


class WorkFacingPer(Work, FacingPer):
    """Manage Work Facing/Image/Per output."""
    issue_q = vo.WORK

    def __init__(self, any_group, k):
        """
        Create a Maya for Per Cell.

        k: tuple
            (r, c, 0); cell index; of int
        """
        Work.__init__(
            self, any_group, mask_facing_per, self.get_mask_d
        )
        FacingPer.__init__(self, do_facing_per, k)
