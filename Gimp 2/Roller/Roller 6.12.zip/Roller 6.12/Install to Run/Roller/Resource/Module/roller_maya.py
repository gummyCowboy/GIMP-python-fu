#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_a_contain import Run
from roller_constant_for import Deco as dc, Issue as vo, Signal as si
from roller_constant_key import Option as ok, SubMaya as sm
from roller_fu import remove_z
from roller_image_grind import ref_get_image
from roller_many_handle import Handle
from roller_model import get_main_q
from roller_one_helm import Helm
from roller_one_ring import Ring
from roller_one_render import Render
from roller_view_real import remove_maya_z

"""Define 'maya' as a super class for layer management."""


def bag_vote(maya, d, k_path):
    """
    Extract vote from a Maya vote dict. Convert issue key
    found in a collected vote dict to Maya vote attribute.

    maya: Maya
        Receive issue vote.

    d: dict
        Has issue vote.

    k_path: tuple
        (Option key, ...)
        Is a possibly nested path to vote dict.
    """
    for k in k_path:
        if k in d:
            d = d[k]
        else:
            d = {}
            break

    # Option key, 'i'; sub-vote dict, 'a'
    for i, a in d.items():
        if i in maya.issue_q and isinstance(a, dict):
            n = 'is_' + i
            vote = None

            for b in a.values():
                if isinstance(b, bool):
                    if vote is None:
                        vote = b

                    else:
                        vote |= b
                    if vote:
                        break
            if vote is not None:
                setattr(maya, n, vote)
    take_great_vote(maya)


def get_sub_maya_vote(d, row_k, k):
    """
    From a vote dict, find a sub-maya vote dict.

    d: dict
        Has issue vote.

    row_k: string
        Is a Row key where the option is found.

    k: string
        Is an Option key with accumulated vote.

    Return: dict
        Is the sub-Maya vote dict.
    """
    if row_k:
        # nested
        a = d.get(row_k)
        if a:
            b = a.get(k)
            if b:
                return b
    return d.get(k, {})


def init_per(maya, k):
    """
    Prepare layer output during a view run.

    maya: Maya
        Per variety

    k: tuple
        (row, column) or (row, column, face)
        key to Per value
    """
    maya.value_d = maya.per_group.get_item(k)
    n = ""

    for i, n1 in enumerate(k):
        n += str(n1 + 1)
        if i < len(k) - 1:
            n += "."
    maya.node_path = maya.any_group.nav_k + (n,)


def on_global(maya, arg, option_k):
    """
    Respond to a Global option change.

    maya: Maya
    arg: list
        [Plan vote, Work vote]

    option_k: string
        Option key
        Is responsible for the vote.
    """
    d = maya.great_vote_d

    # Find the Cell Maya and set its 'per' vote to True.
    # The 'per' issue is voted on when a Per Cell Maya
    # has change, or in this case, when there is Global change.
    chain = maya

    while chain:
        if 'per' in chain.issue_q:
            # Found the Cell Maya, 'chain'.
            if not chain.is_per:
                a = chain.any_group

                a.accept_vote(1, option_k, vo.PER, True)
                chain.take_vote(a.vote_q[1])
                break
        chain = chain.super_maya if hasattr(chain, 'super_maya') else None

    if vo.MATTER not in d:
        d[vo.MATTER] = {}

    d[vo.MATTER][option_k] = arg[maya.view_i]

    take_great_vote(maya)
    maya.any_group.changed(maya.view_i)


def prep_main_step(maya):
    """
    maya: Maya
    """
    pdb.gimp_selection_none(Run.j)
    if not maya.main_q:
        maya.die()


def retire_sub_maya(sub_maya):
    """
    Remove Maya layer output and its sub-Maya output.

    sub_maya: dict
        of sub-Maya
        {sub-Maya identifier: sub-Maya instance} -> {string: Maya}
    """
    # maya, 'a'
    for a in sub_maya.values():
        a.set_issue()
        retire_sub_maya(a.sub_maya)
        for i in a.order:
            if i:
                remove_maya_z(a, i)


def take_background_vote(d):
    """
    Border, Fringe, and Plaque have background
    sensitive types. If the background has changed
    with these types, then vote for change for their
    cast layer.

    d: dict
        deco type Preset
        {Option key: value}

    Return: bool
        If true, then the matter layer has change.
    """
    if Run.is_back and d[ok.TYPE] == dc.MEAN_COLOR:
        return True
    return False


def take_great_vote(maya):
    """
    Set Maya issue from the great vote dict.

    maya: Maya
    """
    for i, a in maya.great_vote_d.items():
        if i in maya.issue_q and isinstance(a, dict):
            n = 'is_' + i
            vote = None

            for b in a.values():
                if isinstance(b, bool):
                    if vote is None:
                        vote = b

                    else:
                        vote |= b
                    if vote:
                        break
            if vote is not None:
                vote |= getattr(maya, n)
                if vote:
                    setattr(maya, n, vote)


class Maya(Handle):
    """Factor Maya type. Is a sub-object for Python 2.7."""

    def __init__(self, any_group, view_i, q, k_path):
        """
        any_group: AnyGroup
        view_i: int
            0 or 1; Plan or Work

        q: tuple or None
            ((function, function output name), ...)

            Are function called in sequence. Each function's
            return value, if not None, is assigned to an
            attribute defined by function output name.

        k_path: tuple or list
            (Option key, ...)
            [(Option key, ...), ...]

            A tuple key is a path to a sub-vote dict. The
            key is needed to find an option vote for an issue
            in a vote dict where some options are nested.

            A list of tuple have multiple key path where
            each path is to another vote dict collection
            perused when taking vote.
        """
        Handle.__init__(self)

        self.go = True
        self.great_vote_d = {}
        self.k_path = k_path

        # None, (row, column), or (row, column, face), 'self.k'
        # Is a key for Maya and made for Model Goo synchronicity.
        self.k = None

        self.rect = None

        # Derive from a tuple made from a navigation step key
        # and Maya type, main or Per, a layer group name.
        # This version is a default used by Plan.
        self.node_path = any_group.nav_k

        self.any_group = any_group
        self.view_i = view_i
        self.model = any_group.item.model
        self.value_d = any_group.value_d
        self.per_group = any_group.widget_d.get(ok.PER)

        # Process during a view run. function list, 'self._make'.
        self._make = [i[0] for i in q]

        # Give name to function output layer
        # with an attribute list, 'self.order'.
        self.order = [i[1] for i in q]

        # Produce additional layer output with sub-Maya.
        self.sub_maya = {}

        # Are layer output reference (e.g. 'self.matter')
        for p, n in q:
            if n:
                setattr(self, n, None)

        if k_path == vo.NO_VOTE:
            self.take_vote = lambda *_q, **_d: None

        else:
            self.take_vote = self.scan_vote if isinstance(k_path, list) \
                else self.grab_vote

        self.latch(Render.gob, (si.CLOSE_VIEW_IMAGE, self.on_close_view_image))
        self.latch(Ring.gob, (si.RESIZE, self.on_resize))
        self.latch(Ring.gob, (si.PANEL_CHANGE, self.on_panel_change))
        self.latch(any_group, (si.DISAPPEAR, self.on_disappear_group))
        if k_path != vo.NO_VOTE:
            if hasattr(self, 'is_seeded'):
                self.latch(Ring.gob, (si.GLOBAL_SEED, self.on_global_seed))

            if hasattr(self, 'is_embossed'):
                self.latch(
                    Ring.gob, (si.GLOBAL_EMBOSS, self.on_global_emboss)
                )
            if self.vote_type == vo.MAIN:
                self.latch(
                    any_group.booth, (si.VOTE_CHANGE, self.on_vote_change)
                )
                self.latch(self.any_group, (si.SEQUENCE, self.on_sequence))

    def die(self):
        """Remove its layer output."""
        for i in self.order:
            if i:
                z = getattr(self, i)
                if z:
                    remove_z(z)
                    setattr(self, i, None)
                    Run.is_back = True

        retire_sub_maya({None: self})
        self.set_issue()

    def grab_vote(self, d):
        """
        Vote on issue given a vote dict.

        d: dict
            Has relational vote.
        """
        bag_vote(self, d, self.k_path)

    def on_close_view_image(self, _, arg):
        """
        Reset the Plan group reference as it was deleted.

        _: ViewImage
            Sent the Signal.

        arg: not used
        """
        for i in self.order:
            if i:
                setattr(self, i, None)
        self.reset()

    def on_disappear(self, _, q):
        """
        The Maya is no longer used, so disconnect its subscription.

        q: tuple
            set of (row, column) or (row, column, face)
            Identify Maya with the view and cell index.
        """
        def _unplug(_maya):
            _maya.die()
            _maya.unlatch()

        def _poof(_maya):
            for _maya in _maya.sub_maya.values():
                _unplug(_maya)
                _poof(_maya)
            _maya.sub_maya = {}

        for k in q:
            if k in self.per_d:
                maya = self.per_d[k]

                _unplug(maya)
                self.per_d.pop(k)

                # Remove the Maya's ability to take sub-vote.
                _poof(maya)
        pdb.gimp_displays_flush()

    def on_disappear_group(self, *_):
        """
        The Maya is no longer used, so disconnect its subscription.

        _: AnyGroup, arg
            (Sent the Signal., None)
        """
        self.die()
        self.unlatch()

        # Remove the Maya's ability to take sub-vote.
        self.per_d = self.sub_maya = {}

        pdb.gimp_displays_flush()

    def on_global_emboss(self, _, arg):
        """
        Respond to a Global emboss option change.

        _: Ring
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
        """
        on_global(self, arg, ok.IS_EMBOSS)

    def on_global_seed(self, _, arg):
        """
        Respond to a Global Seed option change.

        _: Ring
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
        """
        on_global(self, arg, ok.IS_SEED)

    def on_panel_change(self, *_):
        """
        Check to see if the Maya is still active. If the Maya
        is shelved or has been deleted, then self-destruct.

        _: Ring
            (Sent the Signal., arg: None)
        """
        if not Helm.finds(self.any_group.nav_k):
            self.die()
            self.unlatch()
            pdb.gimp_displays_flush()

    def on_resize(self, *_):
        """
        Cast a view image size change vote for both Plan and Work.

        *_: tuple
            (Ring sent the signal., [Plan vote, Work vote])
        """
        on_global(self, [True, True], ok.IS_NEW)

    def on_sequence(self, *_):
        """
        Respond to change taking place in a Model sequence calculation.
        The 'matter' vote has already been added to the AnyGroup's vote
        dict, but now it needs to be scanned for True vote.

        _: tuple
            (AnyGroup, list)
            (Sent the Signal., [Plan vote, Work vote])
        """
        # Plan and Work, '2'
        for i in range(2):
            self.take_vote(self.any_group.vote_q[i])

    def on_vote_change(self, _, i):
        """
        Respond to a VOTE_CHANGE Signal from its AnyGroup.
        Convert vote dict change to Maya issue.

        i: int
            Plan or Work
            0 or 1
        """
        if i == self.view_i:
            self.take_vote(self.any_group.vote_q[i])

    def realize(self):
        """Create and delete layer output."""
        if not self.go:
            self.die()
        else:
            for i, n in enumerate(self.order):
                a = self._make[i](self)
                if n:
                    setattr(self, n, a)

    def realize_vote(self):
        """
        Call to manage layer output and then reset the vote.
        """
        self.realize()
        self.reset_issue()

    def reset(self):
        """Call when the view image closes."""
        for i in self.issue_q:
            self.any_group.cast_vote(self.view_i, ok.IS_NEW, i, True)

    def reset_issue(self):
        """Indicate no change in output status."""
        self.great_vote_d = {}
        for i in self.issue_q:
            setattr(self, 'is_' + i, False)

    def scan_vote(self, d):
        """
        Vote on issue given a vote dict with multiple vote sources.

        d: dict
            Has relational and nested vote.
        """
        for k_q in self.k_path:
            bag_vote(self, d, k_q)

    def set_issue(self):
        """Set issue for self and sub-Maya to True."""
        for i in self.issue_q:
            setattr(self, 'is_' + i, True)
        for a in self.sub_maya.values():
            a.set_issue()


class Runner(Maya):
    """Call 'prep' and 'dig' functions during a view run."""

    def __init__(self, *q):
        """
        q: tuple
            Maya spec
        """
        Maya.__init__(self, *q)

    def do(self):
        """
        Is an entry point for AnyGroup during a view run.

        The 'dig' function is found is different Maya solutions.
        """
        self.prep()
        self.dig()

    def prep(self):
        return


class Mage(Runner):
    """Compare image reference for change."""

    def __init__(self, any_group, view_i, q, k_path):
        # {Maya goo or map key: GIMP image or None}
        self.viewed_d = {}

        Runner.__init__(self, any_group, view_i, q, k_path)

    def prep(self):
        """
        On image change, set matter change issue.
        Override the Runner function.
        """
        d = self.value_d[ok.PER]
        e = self.viewed_d
        group = self.any_group
        a = group.image_slot_count

        # main Maya's Per Maya reference, 'per_d'
        per_d = self.per_d if hasattr(self, 'per_d') else {}

        for k in group.get_keys():
            q = e.get(k)

            if q is None:
                # Initialize.
                q = e[k] = [None] * a
            for i in range(a):
                j = q[i]
                j1 = q[i] = ref_get_image(group, k, i)
                m = j != j1
                if m:
                    # The image ref changed.
                    this_maya = self if k not in d else per_d[k]

                    if i == 0:
                        this_maya.is_matter = m

                    elif i == 1:
                        this_maya.sub_maya[sm.MASK].is_matter = m
                    else:
                        this_maya.sub_maya[sm.FRAME].is_matter = m


class Main:
    """Identify the Maya as main."""
    vote_type = vo.MAIN

    def __init__(self):
        return

    def get_mask_d(self):
        return self.any_group.value_d[ok.RW1][ok.MASK]


class Per:
    """Factor Plan and Work Per. Init after Maya."""
    vote_type = vo.PER

    def __init__(self, do_matter, k):
        """
        do_matter: function
            Produce layer output.

        k: tuple
            (row, column)
            cell index; Goo key
        """
        self.do_matter = do_matter
        self.k = k
        self.latch(self.per_group, (si.PER_CHANGE, self.on_per_change))

    def get_mask_d(self):
        d = self.per_group.get_item(self.k)
        if d:
            return d[ok.RW1][ok.MASK]

    def on_per_change(self, _, arg):
        """
        Respond to change from its PerGroup.
        Create Per Cell Maya to mirror PerGroup cell addition.

        _: PerGroup
            Sent the Signal.

        arg: tuple
            ((row, column), vote dict, view index)
            The row and column work together as a cell index.
            The vote dict has vote for cell referenced by the cell index.
        """
        def _trickle(_d):
            """
            Recursively trickle down the vote through the sub-maya pyramid.

            _d: dict
                sub-Maya
                {sub-Maya key: Maya}
            """
            for _b in _d.values():
                _b.take_vote(d)
                _trickle(_b.sub_maya)

        k, d, i = arg

        if i == self.view_i and k == self.k:
            self.take_vote(d)
            _trickle(self.sub_maya)
        Ring.add(self.any_group, si.GROUP_CHANGE, None)


class PerRoute:
    """Factor CellRoute and FaceRoute"""

    def __init__(self, per_type):
        """
        per_type: Class
            Per Maya
        """
        self.per_type = per_type

        # Has Maya for each Per.
        # key, value -> {(r, c) or (r, c, face): Per Maya}
        self.per_d = {}

        self.node_path = self.any_group.nav_k + (".",)

        self.latch(self.per_group, (si.DISAPPEAR, self.on_disappear))
        self.latch(self.per_group, (si.PER_CHANGE, self.on_per_d_change))

    def rig(self, q):
        """
        Process main and Per output for a step during a view run.

        q: list
            Is a list of Per key for the Model.
        """
        d = self.per_d

        prep_main_step(self)

        # main output
        self.bore()

        # Per output
        # Check 'per' vote, 'is_per'.
        if self.is_per or Run.is_back:
            for k in q:
                if k in d:
                    maya = d[k]

                    init_per(maya, k)
                    maya.bore()
                    maya.reset_issue()
        self.reset_issue()

    def on_per_d_change(self, _, arg):
        """
        Respond to change from the AnyGroup's PerGroup.
        Create Per Cell Maya to mirror PerGroup cell addition.

        _: PerGroup
            Sent the Signal.

        arg: tuple
            ((row, column) or (row, column, face), vote dict, view index)
            The row and column work together as a cell index and Goo key.
            The vote dict has vote for cell referenced by the cell index.
        """
        k, vote_d, i = arg
        if i == self.view_i:
            if k not in self.per_d:
                self.per_d[k] = self.per_type(self.any_group, k)


class CellRoute(PerRoute):
    """Has a list of Cell branch key."""

    def __init__(self, per_type):
        self.main_q = []
        PerRoute.__init__(self, per_type)

    def dig(self):
        self.main_q = get_main_q(self.value_d, self.model.cell_q)
        self.rig(self.model.cell_q)


class FaceRoute(PerRoute):
    """Has a list of Face branch key."""

    def __init__(self, per_type):
        self.main_q = []
        PerRoute.__init__(self, per_type)

    def dig(self):
        self.main_q = get_main_q(self.value_d, self.model.face_q)
        self.rig(self.model.face_q)


class Cell(CellRoute):
    """Use with deco step that secede Cell Margin."""

    def __init__(self, per_type):
        CellRoute.__init__(self, per_type)


class Canvas:
    """Has Canvas branch function."""
    is_face = False
    vote_type = vo.MAIN

    def __init__(self):
        self.k = None
        self.node_path = self.any_group.nav_k + (".",)

    def dig(self):
        """Produce layer output."""
        self.bore()
        self.reset_issue()


class Change(Mage):
    """
    Use with Border, Fringe and Plaque. Respond to
    Global's random seed change and layer background
    change.
    """
    is_seeded = True

    def __init__(self, any_group, view_i, q, k_path):
        Mage.__init__(self, any_group, view_i, q, k_path)

    def on_global_seed(self, _, arg):
        """
        The Global Random Seed option has changed.
        Check to see if the layer output is seed dependent.

        _: Ring
            Sent the signal.

        arg: tuple
            (Plan vote, Work vote)
        """
        d = self.any_group.value_d if self.vote_type == vo.MAIN else \
            self.per_group.get_item(self.k)

        if d:
            if d[ok.TYPE] not in (
                dc.IMAGE, dc.PLASMA, dc.CLOUDS, dc.RANDOM_COLOR
            ):
                # no change
                arg = [False, False]
        super(Change, self).on_global_seed(_, arg)

    def on_back_change(self, _, i):
        """
        The layer background changed for the group.

        _: AnyGroup
            Sent the Signal.

        i: int
            Plan or Work index
        """
        if i == self.view_i:
            d = self.any_group.value_d if self.vote_type == vo.MAIN else \
                self.per_group.get_item(self.k)
            if d[ok.TYPE] == dc.MEAN_COLOR:
                arg = [None, None]
                arg[i] = True
                on_global(self, arg, ok.IS_BACK)
