#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CLIP_TO_IMAGE, LAYER_MODE_MULTIPLY, LAYER_MODE_OVERLAY, pdb
)
from roller_a_contain import Globe, Run
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clear_inverse_selection,
    clone_layer,
    dilate,
    invert_selection,
    load_selection,
    make_layer_group,
    merge_layer_group,
    select_color,
    select_z
)
from roller_maya_style import Style, make_background
from roller_one_wip import Wip
from roller_view_hub import (
    color_layer, do_mod, get_mean_color, prep_replace_color_default
)
from roller_view_real import add_wip_layer

"""
Define 'backdrop/maze_blend' as a Maya-subtype
for managing a variation of backdrop style layer.
"""


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: MazeBlend
    Return: layer
        Backdrop Style material
    """
    j = Run.j
    d = maya.value_d
    parent, group, bg_z = make_background(j, maya)
    z = add_wip_layer("Lost Maze Base", parent)
    group = make_layer_group(j, "WIP", parent, 0, z=z)

    prep_replace_color_default()
    color_layer(z, (127, 127, 127))
    pdb.gimp_image_reorder_item(j, bg_z, group, 0)
    select_z(bg_z)

    color = get_mean_color(bg_z)

    color_layer(bg_z, color)

    z = pdb.gimp_image_merge_down(j, bg_z, CLIP_TO_IMAGE)
    z1 = clone_layer(z, n="Multiply")
    z1.mode = LAYER_MODE_MULTIPLY
    z1.opacity = 25.
    w = max(1, int(Wip.w // d[ok.COLUMN]))
    h = max(1, int(Wip.h // d[ok.ROW]))
    w1 = (w + h) / 1.5
    seed_ = int(d[ok.SEED] + Globe.seed)

    pdb.gimp_context_set_background((0, 0, 0))
    pdb.gimp_context_set_foreground((255, 255, 255))
    select_z(z1)
    pdb.plug_in_maze(
        j, z1,
        w, h,               # passage scale
        1,                  # yes, tileable
        0,                  # depth first algorithm
        seed_,
        0,                  # multiple, not clearly defined
        0                   # offset, not clearly defined
    )
    select_color(z1, (255, 255, 255))

    sel = pdb.gimp_selection_save(j)
    z2 = clone_layer(z1, n="Overlay")
    z2.mode = LAYER_MODE_OVERLAY

    # edge amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(j, z1, 1., 0, 0)

    for _ in range(4):
        dilate(z1)

    # no linear, '0'
    pdb.gimp_drawable_invert(z2, 0)

    color_layer(z2, (127, 127, 127))
    load_selection(j, sel)
    clear_inverse_selection(z2)
    pdb.plug_in_emboss(
        j, z2,
        Globe.azimuth,
        Globe.elevation,
        3,                  # depth
        1                   # emboss type
    )
    pdb.gimp_drawable_invert(z1, 0)
    blur_selection(z1, w1)
    load_selection(j, sel)
    invert_selection(j)
    clear_inverse_selection(z1)
    merge_layer_group(group)
    pdb.gimp_image_remove_channel(j, sel)

    z = merge_layer_group(parent)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class MazeBlend(Style):

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
