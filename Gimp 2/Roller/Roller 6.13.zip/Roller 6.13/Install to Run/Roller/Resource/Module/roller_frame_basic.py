#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Material as ma, Option as ok
from roller_frame import do_embossed_wrap
from roller_frame_alt import FrameBasic

"""
Define 'frame_basic' as a Maya-subtype
for managing a variation of Frame type.
"""


class Basic(FrameBasic):
    is_embossed = True
    kind = material = ma.BASIC
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Define a key path to the Frame Preset in its vote dict.
        """
        FrameBasic.__init__(
            self, any_group, super_maya, k_path, do_embossed_wrap
        )
