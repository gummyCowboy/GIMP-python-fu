#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_a_contain import Dog
from roller_constant_for import Color as co, Signal as si, Widget as fw
from roller_constant_key import Option as ok, Widget as wk
from roller_one_tip import Tip
from roller_port_preview import PortPreview
from roller_widget_box import Box as boxer, Eventful
from roller_widget_button import (
    AcceptButton,
    Button,
    CancelButton,
    NavButton,
    PlanButton,
    PreviewButton,
    ProcessButton
)
from roller_widget_label import Label
from roller_widget_node import Dust, Piece
from roller_widget_radio import RadioRow
from roller_widget_table import get_darker_color
import gtk  # type: ignore


def set_button(m, g):
    """
    Set a Button's sensitivity.

    m: bool
        If true, then enable the Widget.

    g: Widget
        Button
    """
    g.enable() if m else g.disable()


class PortEditor(PortPreview):
    """Edit Preset for Per."""

    def __init__(self, d, g):
        """
        d: dict
            PortCell

        g: PortPer
            Is responsible.
        """
        self._cell_label = \
            self._button_east = \
            self._button_west = \
            self._button_north = \
            self._button_south = None

        self._row, self._column = g.grid
        self.r_c = d[wk.R_C]
        self._is_face = d[wk.IS_FACE]

        # Is True when the port is closing via a return key.
        self.is_return_key = True

        # Apply option value, '0'. Clear option value, '1'.
        self._edit_mode = 0

        self.option_d = {wk.HAS_PRESET: True, wk.IS_DEFAULT: False}
        PortPreview.__init__(self, d, g)

    def _is_cell(self, r, c):
        """
        Determine if a cell is a valid cell.

        r, c: int
            cell index

        Return: bool
            Is True if the cell is a valid cell.
        """
        return self.repo.gum_table[r][c].is_cell

    def _view_cell_east(self, *_):
        """Move the cell focus to the right."""
        self.update_repo()
        self._button_east.set_tooltip_text("")

        for c in range(self.r_c[1] + 1, self._column):
            gum = self.repo.gum_table[self.r_c[0]][c]
            if gum.is_cell or gum.is_topleft:
                self.r_c = self.r_c[0], c

                self.repo.set_active_cell(*self.r_c)
                break
        self.set_widget_value()

    def _view_cell_north(self, *_):
        """Move the cell focus upward."""
        self.update_repo()
        self._button_north.set_tooltip_text("")

        for r in range(self.r_c[0] - 1, -1, -1):
            gum = self.repo.gum_table[r][self.r_c[1]]
            if gum.is_cell or gum.is_topleft:
                self.r_c = r, self.r_c[1]

                self.repo.set_active_cell(*self.r_c)
                break
        self.set_widget_value()

    def _view_cell_south(self, *_):
        """Move the cell focus downward."""
        self.update_repo()
        self._button_south.set_tooltip_text("")

        for r in range(self.r_c[0] + 1, self._row):
            gum = self.repo.gum_table[r][self.r_c[1]]
            if gum.is_cell or gum.is_topleft:
                self.r_c = r, self.r_c[1]

                self.repo.set_active_cell(*self.r_c)
                break
        self.set_widget_value()

    def _view_cell_west(self, *_):
        """Move the cell focus to the left."""
        self.update_repo()
        self._button_west.set_tooltip_text("")

        for c in range(self.r_c[1] - 1, -1, -1):
            gum = self.repo.gum_table[self.r_c[0]][c]
            if gum.is_cell or gum.is_topleft:
                self.r_c = self.r_c[0], c

                self.repo.set_active_cell(*self.r_c)
                break
        self.set_widget_value()

    def apply_to_1st_half(self, _):
        """
        Set the Preset value for the current cell
        and cells in the first half of the cell grid.
        """
        self.is_return_key = False
        r_c = self.r_c
        half = int(round(self._row * self._column / 2))
        i = 0
        q = [r_c]
        for r in range(self._row):
            if i >= half:
                break
            for c in range(self._column):
                if (r, c) != r_c and self._is_cell(r, c):
                    q += [(r, c)]

                i += 1
                if i >= half:
                    break

        self.repo.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def apply_to_2nd_half(self, _):
        """
        Set the Preset value for the current cell and
        the cells in the second half of the cell grid.
        """
        self.is_return_key = False
        r_c = self.r_c
        half = int(round(self._row * self._column / 2))
        i = 0
        q = [r_c]
        for r in range(self._row):
            for c in range(self._column):
                if i >= half and (r, c) != r_c and self._is_cell(r, c):
                    q += [(r, c)]
                i += 1

        self.repo.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def apply_to_all(self, _):
        """Set the Preset value for all the cells in the grid."""
        self.is_return_key = False
        r_c = self.r_c
        q = [r_c]

        for r in range(self._row):
            for c in range(self._column):
                if (r, c) != r_c and self._is_cell(r, c):
                    q += [(r, c)]

        self.repo.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def apply_to_cell(self, _):
        """
        Set the Preset value for the active cell.
        The AcceptButton sends an ACCEPT_WINDOW Signal,
        so 'accept_preview' is not called.
        """
        self.is_return_key = False
        self.update_repo()

    def apply_to_column(self, _):
        """Set the Preset value for the current cell grid column."""
        self.is_return_key = False
        row, c = self.r_c
        q = [self.r_c]

        for r in range(self._row):
            if r != row and self._is_cell(r, c):
                q += [(r, c)]

        self.repo.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def apply_checkerboard(self, _):
        """
        Set the Preset value for the current cell and
        additional cells with the same cell remainder.
        """
        self.is_return_key = False
        r_c = self.r_c
        q = [r_c]
        remain = (r_c[0] + r_c[1]) % 2

        for r in range(self._row):
            for c in range(self._column):
                if (
                    (r + c) % 2 == remain and
                    (r, c) != r_c and
                    self._is_cell(r, c)
                ):
                    q += [(r, c)]

        self.repo.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def apply_to_row(self, _):
        """
        Set the Preset value for the current cell grid row.

        _: Button
            not in use
        """
        self.is_return_key = False
        r, column = self.r_c
        q = [self.r_c]

        for c in range(self._column):
            if c != column and self._is_cell(r, c):
                q += [(r, c)]

        self.repo.set_cell_array(self._get_value_d(), q)
        self.accept_preview()

    def _do_control_arrow(self, n):
        """
        Respond to a control-arrow keypress. Change the Preset value for the
        cell indicated by the arrow key. The target cell may not exist.

        n: string
            arrow key-press
        """
        r, c = self.r_c
        m = False

        if n == "Down":
            if r + 1 != self._row:
                for r1 in range(r + 1, self._row):
                    if self._is_cell(r1, c):
                        m = True
                        break
                if m:
                    self._view_cell_south()

        elif n == "Up":
            if r != 0:
                for r1 in range(r - 1, -1, -1):
                    if self._is_cell(r1, c):
                        m = True
                        break
                if m:
                    self._view_cell_north()

        elif n == "Left":
            if c != 0:
                for c1 in range(c - 1, -1, -1):
                    if self._is_cell(r, c1):
                        m = True
                        break
                if m:
                    self._view_cell_west()
        elif n == "Right":
            if c + 1 != self._column:
                for c1 in range(c + 1, self._column):
                    if self._is_cell(r, c1):
                        m = True
                        break
                if m:
                    self._view_cell_east()

    def _get_value_d(self):
        """
        Collect Widget value from the interface.

        Return: dict or None
            Is None if the cell is a main cell.
        """
        d = None

        if d is None:
            d = self.any_group.get_preset_g().get_a()

        if d == self.repo.main_edit_d or self._edit_mode == 1:
            d = None
        return d

    def accept_preview(self):
        self.roller_win.emit(si.ACCEPT_WINDOW, self)

    def accept_cell_editor(self, *_):
        """
        Accept option.

        _: Preset
            not used
        """
        if self.is_return_key:
            self.update_repo()
        self.repo.on_cell_editor_close()

    def cancel_cell_editor(self):
        """Close the cell editor."""
        self.repo.on_cell_editor_close()

    def draw(self):
        """Draw Port Widget."""
        self.option_d[wk.COLOR] = self.color
        self.option_d[wk.ROLLER_WIN] = self.roller_win
        self.option_d[wk.RELAY] = [self.on_port_change]
        self.option_d[wk.RENDER_KEY] = \
            self.repo.repo.any_group.render_key + (ok.PER,)
        r, c = self.r_c
        self._cell_label = Label(
            padding=(4, 4, 4, 4),
            text="Cell Data:\tRow: {}\tColumn: {}".format(r + 1, c + 1)
        )
        hbox = gtk.HBox()

        # cell data group
        box = Eventful(self.color)
        a = self.repo.cell_table_group.item
        piece = self.option_d[wk.ITEM] = Piece(
            a.key,
            box,
            a,
            group_type='preset',
            has_label=False,
            is_per=True
        )

        self.reduce_color()
        piece.vbox.add(self._cell_label)

        self.any_group = Dog.many_group(**self.option_d)

        # navigation group
        self.reduce_color()
        self.draw_navigation(piece.vbox)
        self.reduce_color()

        box1 = self.draw_distribution()

        self.set_widget_value()
        hbox.add(box)
        hbox.add(box1)
        self.add(hbox)
        self.roller_win.gtk_win.connect(
            'key_press_event', self.on_arrow_keypress
        )

    def draw_distribution(self):
        """
        Draw the processing Button.

        Return: Eventful
            contains group
        """
        w = fw.MARGIN
        box = Eventful(self.color)
        vbox = boxer(align=(0, 0, 1, 1))
        none_group = Dog.none_group(**{wk.ITEM: Dust()})
        d = {
            wk.ANY_GROUP: none_group,
            wk.PADDING: (0, 0, w, w),
            wk.ROLLER_WIN: self.roller_win
        }

        box.add(vbox)

        q = self.get_distributor_q(d)
        alignment = gtk.Alignment(0, 0, 0, 0)
        table = gtk.Table(len(q), 1)
        option_count = len(q)
        color = self.color

        self.keep(q)
        table.set_row_spacings(1)
        alignment.set_padding(w, w, w, w)

        for i, g in enumerate(q):
            color = get_darker_color(color, option_count)
            color1 = color, color, co.MAX_COLOR
            box1 = Eventful(color1)

            box1.add(g)
            table.attach(box1, 0, 1, i, i + 1)

        alignment.add(table)
        vbox.add(alignment)
        return box

    def get_group_value(self):
        """
        Call before doing a view run.

        Return: dict
            cell table
        """
        if self._edit_mode:
            return None
        return self._get_value_d()

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return self.cancel_cell_editor, self.accept_cell_editor

    def make_distributor_q(self, d):
        """
        Create a list of Preset distribution Widget.

        d: dict
            Has Widget init value.

        Return: list
            [Widget, ...]
        """
        # Widget, 'q'
        return [RadioRow(
            any_group=self.any_group,
            padding=(2, 0, 4, 0),
            relay=[self.set_edit_mode],
            roller_win=self.roller_win,
            text=("Apply", "Clear"),
            tips=(
                " Apply the option values. ",
                " Return value to the main option setting. "
            )
        ), CancelButton(
            **dict(d, relay=[])
        ), ProcessButton(
            **dict(d, relay=[self.apply_to_row], text="Row")
        ), ProcessButton(
            **dict(d, relay=[self.apply_to_column], text="Column")
        ), ProcessButton(
            **dict(d, relay=[self.apply_to_all], text="All Cell")
        ), ProcessButton(
            **dict(d, relay=[self.apply_checkerboard], text="Checkerboard")
        ), ProcessButton(
            **dict(d, relay=[self.apply_to_1st_half], text="Cell & 1st Half")
        ), ProcessButton(
            **dict(d, relay=[self.apply_to_2nd_half], text="Cell & 2nd Half")
        ), PlanButton(
            **dict(d, relay=[])), PreviewButton(**dict(d, relay=[])
        ), AcceptButton(
            **dict(d, relay=[self.apply_to_cell])
        )]

    def make_navigation(self, container):
        """
        Draw four horizontally oriented Buttons
        used to navigate the cell grid.

        container: container
            container for the Buttons
        """
        w = fw.MARGIN
        box = Eventful(self.color)
        vbox = boxer()
        hbox = boxer(box=gtk.HButtonBox, align=(0, 0, 0, 0))
        d = {
            wk.ON_DIALOG_CLOSE: self.verify_nav_button,
            wk.ROLLER_WIN: self.roller_win
        }

        vbox.pack_start(
            Label(padding=(2, 4, 4, 0), text="Cell Navigation")
        )
        vbox.pack_start(hbox, expand=False)
        box.add(vbox)
        container.pack_start(box, expand=False)
        hbox.set_padding(0, 0, w, w)

        self._button_north = NavButton(
            **dict(
                d,
                relay=[self._view_cell_north],
                text="↑",
                tooltip=Tip.NAVIGATION[0]
            )
        )
        self._button_south = NavButton(
            **dict(
                d,
                relay=[self._view_cell_south],
                text="↓",
                tooltip=Tip.NAVIGATION[1]
            )
        )
        self._button_west = NavButton(
            **dict(
                d,
                relay=[self._view_cell_west],
                text="←",
                tooltip=Tip.NAVIGATION[2]
            )
        )
        self._button_east = NavButton(
            **dict(
                d,
                relay=[self._view_cell_east],
                text="→",
                tooltip=Tip.NAVIGATION[3]
            )
        )
        for g in (
            self._button_north,
            self._button_south,
            self._button_west,
            self._button_east
        ):
            hbox.pack_start(g, expand=False)

    def on_arrow_keypress(self, _, event):
        """
        Check to see if the user pressed the control
        key and an arrow key at the same time.

        event: keypress
            Look for an arrow-key pressed Event.

        Return: None or True
            Is true if the keypress is handled.
        """
        n = gtk.gdk.keyval_name(event.keyval)
        control_pressed = event.state & gtk.gdk.CONTROL_MASK
        if control_pressed and n in ('Left', 'Right', 'Up', 'Down'):
            self._do_control_arrow(n)
            return True

    def set_edit_mode(self, g):
        """
        Set the edit mode used by a processing Button.

        g: RadioRow
            Is responsible.
        """
        self._edit_mode = g.get_a()

    def set_widget_value(self):
        """Set Widget value. The current cell is at 'self.r_c'."""
        d = self.repo.get_a()

        if not d:
            d = deepcopy(self.repo.main_edit_d)

        self.any_group.get_preset_g().set_without_per(d)
        self.verify_nav_button()
        self._cell_label.widget.set_text(
            "Cell\tRow: {}\tColumn: {}".format(
                self.r_c[0] + 1, self.r_c[1] + 1
            )
        )

    def update_repo(self):
        """Update the cell grid, the tooltip, and the Label color."""
        self.repo.set_a(self._get_value_d())

    def verify_nav_button(self, *_):
        """
        Verify the navigation Button given the current cell.
        Scan the cell grid for a valid cell.
        """
        # the active cell index, 'r, c'
        r, c = self.r_c

        if r + 1 == self._row:
            self._button_south.disable()

        else:
            m = False

            for r1 in range(r + 1, self._row):
                if self._is_cell(r1, c):
                    m = True
                    break
            set_button(m, self._button_south)

        if r == 0:
            self._button_north.disable()

        else:
            m = False

            for r1 in range(r - 1, -1, -1):
                if self._is_cell(r1, c):
                    m = True
                    break
            set_button(m, self._button_north)

        if c + 1 == self._column:
            self._button_east.disable()

        else:
            m = False

            for c1 in range(c + 1, self._column):
                if self._is_cell(r, c1):
                    m = True
                    break
            set_button(m, self._button_east)

        if c == 0:
            self._button_west.disable()
        else:
            m = False

            for c1 in range(c - 1, -1, -1):
                if self._is_cell(r, c1):
                    m = True
                    break
            set_button(m, self._button_west)


class PortCellEditor(PortEditor):
    """Create a Cell editor Port."""
    window_key = "Cell Editor"

    def __init__(self, d, g):
        """
        d: dict
            of PortCell

        g: PortCellEditor
            Is responsible.
        """
        PortEditor.__init__(self, d, g)

    def draw_navigation(self, vbox):
        self.make_navigation(vbox)

    def get_distributor_q(self, d):
        """
        Create Per Cell's Button list for processing Preset.

        d: dict
            Has common init variable.
        """
        return self.make_distributor_q(d)


class PortFaceEditor(PortEditor):
    """Create a Face editor Port."""
    window_key = "Face Editor"

    def __init__(self, d, g):
        self.face_i = 0
        self.face_index_g = None

        g.set_active_face(0)
        PortEditor.__init__(self, d, g)

    def apply_to_all_face(self, _):
        """Apply Widget value for all cells."""
        self.is_return_key = False

        self.repo.set_cell_faces(self._get_value_d())
        self.accept_preview()

    def make_face_row(self, container):
        """
        Draw four horizontally oriented Buttons
        used to navigate the cell table.

        container: container
            for the Buttons
        """
        w = fw.MARGIN
        box = Eventful(self.color)
        hbox = boxer(box=gtk.HButtonBox, align=(0, 0, 0, 0))
        self.face_index_g = RadioRow(
            any_group=self.any_group,
            key='face',
            padding=(2, 0, 4, 0),
            relay=[self.on_face_change],
            roller_win=self.roller_win,
            text=self.repo.model.get_face_text()
        )

        hbox.add(Label(padding=(2, 4, 4, 0), text="Face:"))
        hbox.pack_start(self.face_index_g)
        box.add(hbox)
        container.pack_start(box, expand=False)
        hbox.set_padding(0, 0, w, w)

    def draw_navigation(self, vbox):
        self.make_face_row(vbox)
        self.make_navigation(vbox)

    def get_distributor_q(self, d):
        """
        Insert a Face Group Button into a Preset distribution Button list.

        d: dict
            Has common init variable.
        """
        g_q = self.make_distributor_q(d)

        # The Button is inserted before "All Cell".
        g_q.insert(
            4,
            Button(
                **dict(d, relay=[self.apply_to_all_face], text="Face Group")
            )
        )
        return g_q

    def on_face_change(self, _):
        """
        Respond to change in the Face index Widget.
        Switch the Preset value on display.

        _: RadioButton
            Is responsible.
            not used
        """
        self.update_repo()

        self.face_i = self.face_index_g.get_a()

        self.repo.set_active_face(self.face_i)
        self.set_widget_value()
