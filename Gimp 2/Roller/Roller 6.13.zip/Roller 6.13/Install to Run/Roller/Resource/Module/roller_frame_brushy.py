#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, LAYER_MODE_OVERLAY, pdb   # type: ignore
from roller_a_contain import Globe, Run
from roller_a_gegl import emboss
from roller_constant_key import Material as ma, Option as ok, SubMaya as sm
from roller_frame import do_embossed_wrap, sort_shadow_layer
from roller_fu import (
    add_layer,
    blur_selection,
    clear_selection,
    clone_layer,
    select_item
)
from roller_maya_layer import (
    check_matter, check_mix_basic, make_group_brush, make_group_wrap
)
from roller_maya_add import AltAdd
from roller_maya_build import Build, SubBuild
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_view_hub import brush_stroke, do_curves
from roller_view_preset import combine_seed
from roller_view_real import clip_to_wip, get_light

"""
Define 'frame_brushy' as a Maya-subtype
for managing a variation of Frame type.
"""


def do_brush(maya):
    """
    Make a filler layer for the frame layer.

    maya: Brush
    Return: layer or None
        Brush output
    """
    j = Run.j
    d = maya.super_maya.value_d[ok.BRW][ok.WRAP_AL]
    e = maya.value_d
    cast_z = maya.cast.matter

    # WIP layer will fail, so use the view-sized layer.
    z = add_layer(j, "Material", maya.group, get_light(maya))

    select_item(cast_z)
    pdb.plug_in_sel2path(j, cast_z)
    pdb.gimp_context_set_opacity(100.)

    if j.active_vectors:
        # Simulate depth by setting the color of the
        # brush to be a lighter color than the frame.
        if d[ok.EMBOSS]:
            pdb.gimp_context_set_foreground((144, 144, 144))

        else:
            pdb.gimp_context_set_foreground(
                tuple([min(255, i + 17) for i in d[ok.COLOR_1]])
            )

        combine_seed(e)

        for stroke in j.active_vectors.strokes:
            brush_stroke(
                z,
                e[ok.BRW][ok.BRUSH],
                e[ok.BRUSH_SIZE],
                stroke,
                e[ok.BRUSH_SPACING],
                e[ok.ANGLE_JITTER],
                hard=e[ok.HARDNESS],
                angle=e[ok.BRUSH_ANGLE]
            )

        pdb.gimp_image_remove_vectors(j, j.active_vectors)

        if d[ok.EMBOSS]:
            z1 = clone_layer(z)
            z1.mode = LAYER_MODE_OVERLAY

            emboss(z, Globe.azimuth, Globe.elevation, 1)
            z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)

    if e[ok.CLIP]:
        select_item(cast_z)
        clear_selection(z)

    pdb.gimp_selection_all(j)
    blur_selection(z, 1.)
    clip_to_wip(z)
    do_curves(z, (.0, .06, 1., 1.))
    return z


def do_matter(maya):
    """
    Make a Wrap layer.

    maya: BrushWrap
    Return: layer
        Wrap output
    """
    z = do_embossed_wrap(maya)

    do_curves(z, (.0, .0, 1., .94))
    return z


class BrushWrap(SubBuild):
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )
    wrap_k = ok.WRAP_AL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        k_path = k_path + (ok.BRW, ok.WRAP_AL)

        SubBuild.__init__(self, any_group, super_maya, k_path, do_matter)

        self.sub_maya[sm.ADD] = AltAdd(
            any_group, self, k_path + (ok.ADD_ALT,)
        )
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.BRUSHY)

    def do(self, d, is_change, is_back):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        is_change: bool
            Is the state of the cast Maya's matter and/or mask.

        is_back: bool
            Is True if the background has changed.

        Return: bool
            Is True if the 'matter' layer changed.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(d[ok.ADD_ALT], m, m, is_back)
            self.sub_maya[sm.LIGHT].do(m)

        else:
            self.die()

        self.reset_issue()
        return m


class Brush(SubBuild):
    is_seeded = is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_brush, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            Frame type

        k_path: tuple
            (Option key, ...)
            path to this sub-Frame option
        """
        k_path = k_path + (ok.BRW, ok.BRUSH_D1)

        SubBuild.__init__(
            self, any_group, super_maya, [k_path, k_path + (ok.BRW,)], do_brush
        )

        self.sub_maya[sm.ADD] = AltAdd(
            any_group, self, k_path + (ok.BRW, ok.ADD_ALT)
        )
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.BRUSHY_BRUSH)

    def do(self, d, is_change, is_back):
        """
        Manage layer output during a view run.

        d: dict
            Brushy's Brush Dialog Preset

        is_change: bool
            Is the state of the cast Maya's matter and/or mask.

        is_back: bool
            Is True if the background has changed.

        Return: bool
            Is True when there is layer change.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(d[ok.BRW][ok.ADD_ALT], m, m, is_back)
            self.sub_maya[sm.LIGHT].do(m)

        else:
            self.die()

        self.reset_issue()
        return m


class Brushy(Build):
    is_seeded = is_embossed = True
    put = issue_q = ()
    kind = material = ma.BRUSHY
    shade_row = ok.BRW

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Option key,)
            Is the key path to the responsible Frame Button.
        """
        Build.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.WRAP] = BrushWrap(any_group, self, k_path)
        self.sub_maya[sm.FILLER] = Brush(any_group, self, k_path)
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group,
            self,
            (self.cast, self.sub_maya[sm.WRAP], self.sub_maya[sm.FILLER]),
            k_path + (ok.BRW, ok.SHADOW,)
        )

    def do(self, d, is_change):
        """
        Manage layer output during a view run.

        d: dict
            Brushy Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        wrap = self.sub_maya[sm.WRAP]

        self.realize()

        m = self.sub_maya[sm.WRAP].do(
            d[ok.BRW][ok.WRAP_AL], is_change, is_back
        )
        if wrap.matter:
            m1 = self.sub_maya[sm.FILLER].do(
                d[ok.BRW][ok.BRUSH_D1], is_change, is_back
            )
            m2 = self.sub_maya[sm.SHADOW].do(
                d[ok.BRW][ok.SHADOW],
                is_change,
                m or m1,
                self.sub_maya[sm.WRAP].group
            )
            sort_shadow_layer(
                self, m or m1 or m2, get_light(wrap), wrap.matter
            )

        else:
            self.die()
        self.reset_issue()
