#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import floor
from roller_constant_for import Grid as gr, Shape as sh, Triangle as ft
from roller_model_goo import Mesh
from roller_polygon import calc_pin_xy
from roller_polygon_box import (
    calc_box_cell, calc_box_b_w, calc_hex_ratio
)

"""
Define 'polygon_box_hexagon' as a class for calculating
base cell vertices of a vertical Box shape.
"""


def calc_box_hex(model, o):
    """
    Calculate a grid double-spaced, regular shaped, hexagon
    cell. Calculate cell rectangle for a Model's cell.

    model: Model
    o: One
        Has Cell/Type Option as attribute.

    Return: dict
        {value: [bool, bool]}
        {cell key: [Plan vote change, Work vote change]}
    """
    def _arrange():
        """
        Arrange a hexagon shape of x, y coordinate where each
        x, y pair is a polygon vertex. Order coordinate from
        the upper left-most point and connect points clockwise.

        Return: tuple
            shape
        """
        return x, y2, x2, y, x3, y1, x3, y3, x1, y5, x, y4

    def _arrange_flip_x():
        """The x coordinate is flipped."""
        return x, y1, x1, y, x3, y2, x3, y4, x2, y5, x, y3

    def _arrange_flip_xy():
        """The x and y coordinates are flipped."""
        return x, y2, x2, y, x3, y1, x3, y3, x1, y5, x, y4

    def _arrange_flip_y():
        """The y coordinate is flipped."""
        return x, y1, x1, y, x3, y2, x3, y4, x2, y5, x, y3

    def _calc_pin(flip_a_w, flip_b_w, a_grid_w, b_grid_w):
        """
        Justify grid. When a vector is
        flipped, it gains an additional offset.

        flip_a_w, flip_b_w: float
            Each is a span of the grid's 'a' and 'b' vector offsets.
            For this hexagon, 'a' is the 'x' vector,
            and 'b' is 'y' vector.

        a_grid_w, b_grid_w: float
            Each is a span of the grid's 'a' and 'b' dimensions.
            For this hexagon, 'a' is the 'x' vector,
            and 'b' is 'y' vector.

        Return: tuple
            (a, b) ordered x and y pin offsets of float
        """
        return calc_pin_xy(
            o.pin,
            x - flip_a_w, y - flip_b_w,
            canvas_w, canvas_h,
            a_grid_w, b_grid_w
        )

    is_top = model.is_positive_b = o.box_type == sh.TOP
    model.is_positive_a = o.cap_x <= .5
    row, column = model.grid
    x, y, canvas_w, canvas_h = model.canvas_pocket.rect
    ratio_h = model.ratio = calc_hex_ratio(o.cap_y, is_top)

    if o.grid_type == gr.CELL_SIZE:
        # Correct cell size overflow.
        w = min(canvas_w, o.column_width)
        h = min(canvas_h, o.row_height)

    elif o.grid_type == gr.SHAPE_COUNT:
        # cell size, 'w, h'
        w = floor(canvas_w / (.5 + column * .5))
        h = floor(canvas_h / (ratio_h + row * (1. - ratio_h)))

        # two possible solutions
        # hexagon size, 'hex_w, hex_h'
        hex_w, hex_h = h * ft.SCALE_DOWN, h
        w1 = hex_w / 2.
        h1 = hex_h * ratio_h
        h2 = hex_h - h1

        # Check for overflow.
        if column * w1 + w1 > canvas_w or row * h2 + h1 > canvas_h:
            # solution two
            w, h = w, w * ft.SCALE_UP
        else:
            # solution one
            w, h = hex_w, hex_h

    else:
        # Calculate the cell size.
        w = canvas_w / (.5 + column * .5)
        h = canvas_h / (ratio_h + row * (1. - ratio_h))

    h = calc_box_b_w(o.cap_y, h, is_top)

    # Begin cell calc and arrange point.
    is_flip_x = o.cap_x > .5
    is_flip_y = not is_top      # Is bottom.
    did_cell = model.past.did_cell
    goo_d = model.goo_d
    vote_d = {}
    q_x, q_y, offset_w, offset_h = calc_box_cell(
        o.cap_x - .5 if is_flip_x else .5 - o.cap_x,
        row, column,
        w, h,
        ratio_h,
        is_flip_x, is_flip_y,
        canvas_w, canvas_h,
        _calc_pin
    )
    p = (
        _arrange, _arrange_flip_y, _arrange_flip_x, _arrange_flip_xy
    )[is_flip_y + is_flip_x * 2]

    for r_c in model.cell_q:
        r, c = r_c
        r1 = r * 4
        c1 = c * 2
        x, x1, x2, x3 = q_x[c1:c1 + 4]
        y, y1, y2, y3, y4, y5 = q_y[r1:r1 + 6]
        a = goo_d[r_c] = Mesh(r_c)

        # Prevent round to zero with max 1..
        a.cell.rect = a.merged.rect = \
            x, y, max(1., abs(x3 - x)), max(1., abs(y5 - y))

        vote_d[r_c] = did_cell(r_c)
        a.form = p()
        a.cap_x = a.form_cap_x = a.shift_cap_x = round(x + offset_w)
        a.cap_y = a.form_cap_y = a.shift_cap_y = round(y + offset_h)
    return vote_d
