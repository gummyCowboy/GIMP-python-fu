#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import shuffle
from roller_a_contain import Globe
from roller_constant_for import Image as fi
from roller_constant_key import Option as ok
from roller_fu_comm import info_msg
from roller_image_part import (
    slice_bottom_left,
    slice_bottom_right,
    slice_top_left,
    slice_top_right,
    do_bottom_up,
    do_left,
    do_right,
    do_top_down
)
from roller_image_pic import Pic
from roller_image_ref import Ref
from roller_image_single import (
    single_get_autocrop, single_get_file_ref, single_get_tab
)
from roller_view_preset import combine_seed
import os

INIT_TYPE_STATE = -2, -2, -2, -2, None, 0

# {(Layered, layer-order, slice, slice order): seek function}
SEEK_ROUTE = {
    (1, 0, 0, 0): do_bottom_up,
    (1, 1, 0, 0): do_top_down,
    (0, 0, 1, 0): do_left,
    (0, 0, 1, 1): do_right,
    (1, 0, 1, 0): slice_bottom_left,
    (1, 0, 1, 1): slice_bottom_right,
    (1, 1, 1, 0): slice_top_left,
    (1, 1, 1, 1): slice_top_right
}


def _get_file_list(path, n):
    """
    Load a file list with file name-filtered image files.

    file_list: list
        [file-path, ...]

    path: string
        folder-path

    n: string
        file name filter
        Pass files containing this string.
    """
    file_list = Pic.folder_d.get((path, n))

    if file_list is None:
        file_list = []

        try:
            for file_name in os.listdir(path):
                ext = os.path.splitext(file_name)[1]
                if ext.lower() in fi.EXTENSION:
                    if n:
                        if n not in file_name:
                            # Skip file.
                            continue
                    file_list.append(os.path.join(path, file_name))
        except Exception as ex:
            info_msg(fi.READ_ERR.format(path))
            info_msg("The error was:\n" + repr(ex))
            file_list = []
    return sorted(file_list)


def get_precursor_state(type_k, i):
    """
    Search for an AnyGroup's precursor type state.

    type_k: tuple
        Type key

    i: int
        AnyGroup's index in the active AnyGroup list.

    Return: tuple
        Type precursor's state
    """
    pre_i = -1
    d = Ref.state_d.get(type_k)

    if d is None:
        d = Ref.state_d[type_k] = {-1: INIT_TYPE_STATE}

    for k in sorted(d.keys())[::-1]:
        if pre_i < k < i:
            pre_i = k
            break
    return d[pre_i]


def _make_key(d, q=()):
    """
    Make a Type reference key.

    d: dict
        Image Choice Preset

    q: tuple
        Type-specific key prefix
    """
    is_layered = d[ok.LAYERED]
    layered = (is_layered, d[ok.LAYER_ORDER]) \
        if is_layered else (False, False)
    is_sliced = d[ok.SLICE]
    sliced = (is_sliced, d[ok.SLICE_ORDER], d[ok.ROW], d[ok.COLUMN]) \
        if is_sliced else (False, False, 0, 0)
    return (d[ok.TYPE], d[ok.AUTOCROP]) + q + (layered, sliced)


class Type:
    """Factor Image Choice's image type."""

    def __init__(self, d, k, p, a):
        """
        d: dict
            Image Choice Preset

        k: tuple
            Type key

        p: function
            Get the next image for the 'assign_ref' function.

        a: int
            Is the number of advancing images
            before ending a seek loop as a fail.
        """
        self.seek = self.image = None
        self.is_wait = self.is_load = False
        self.i = self.r_i = self.c_i = self.layer_i = -2
        self.file_i = 0
        self.fail_safe = a
        self.row, self.column = d[ok.ROW], d[ok.COLUMN]
        self.is_autocrop = d[ok.AUTOCROP]
        self.type_ = d[ok.TYPE]
        self.key = k
        self.get_next_image = p
        self.seek = SEEK_ROUTE.get(
            (
                d[ok.LAYERED],
                d[ok.LAYER_ORDER] & d[ok.LAYERED],
                d[ok.SLICE],
                d[ok.SLICE_ORDER] & d[ok.SLICE]
            )
        )
        self.init_i()

    def assign_ref(self):
        """
        Get the next Loop image reference.

        Return: GIMP image or None
        """
        if self.seek:
            # Has sub-part.
            if not self.image:
                # Initialize.
                self.image = self.get_next_image(self)

            is_seek = True
            advance_count = 0
            while is_seek:
                if self.image:
                    single = self.seek(self)

                else:
                    # There are no image tab.
                    single = None
                    break

                if self.is_wait:
                    return self

                is_seek = not bool(single)
                if is_seek:
                    self.advance_index()

                    self.image = self.get_next_image(self)
                    advance_count += 1
                    if advance_count > self.fail_safe:
                        # It's possible that none
                        # of the open images have layers.
                        break

        else:
            # no sub-part
            single = self.get_next_image(self)
            self.advance_index()

        if single and self.is_autocrop and not self.is_wait:
            single = single_get_autocrop(self, single)
        return single

    def get_image(self, single_q, i, any_group_i):
        """
        Call to restart a Type that is in an 'is_wait' state.
        Change the 'get_image' function to the Single's version.

        single_q: list
            [Single or Type, ...]
            Has three items.
            Replace a Type reference to a Single reference.

        i: int
            Is the index to the Type's slot in 'single_q'.

        any_group_i: int
            Is the AnyGroup precursor's index.

        Return: GIMP image or None
        """
        self.is_wait = False
        self.is_load = True
        single = single_q[i] = self.assign_ref()
        Ref.state_d[self.key][any_group_i] = self.get_state()
        self.is_load = False
        if single:
            return single.get_image()

    def get_name(self):
        """Use the Single function instead."""
        return

    def get_state(self):
        """Provide the variables needed for the next assignment."""
        return (
            self.i, self.r_i, self.c_i, self.layer_i, self.image, self.file_i
        )

    def resume(self, any_group_i):
        """
        Assign secondary image reference for an AnyGroup.
        Set the state of the object from a previous assignment.

        any_group_i: int
            Is the index of the AnyGroup in an
            AnyGroup list ordered by run sequence.

        Return: Single or None
            Has a GIMP image reference.
        """
        single = self.assign_ref()
        Ref.state_d[self.key][any_group_i] = self.get_state()
        return single

    def start(self, any_group_i):
        """
        Assign the first image reference for an AnyGroup.
        Set the state of the object from a previous assignment.

        any_group_i: int
            Is the index of the AnyGroup in an
            AnyGroup list ordered by run sequence.

        Return: Single or None
            Has a GIMP image reference.
        """
        self.set_state(get_precursor_state(self.key, any_group_i))

        single = self.assign_ref()
        Ref.state_d[self.key][any_group_i] = self.get_state()
        return single

    def set_state(self, q):
        self.i, self.r_i, self.c_i, self.layer_i, self.image, self.file_i = q
        if self.i == -2:
            # Initialize.
            self.init_i()


class File(Type):
    """Manage a File reference."""

    def __init__(self, d, k):
        """
        d: dict
            Image Choice Preset

        k: tuple
            Type key
        """
        self.path = d[ok.FILE]
        self.file_list = [self.path]
        Type.__init__(self, d, k, single_get_file_ref, 1)

    def advance_index(self):
        """Rollover the part indices."""
        self.layer_i = self.r_i = self.c_i = -2

    def init_i(self):
        self.i = 0 if self.path else None

    @staticmethod
    def make_key(d):
        """
        Make a File reference key.

        d: dict
            Image Choice Preset
        """
        return _make_key(d, q=(d[ok.FILE],))


class Folder(Type):
    """Manage a Folder reference."""

    def __init__(self, d, k):
        """
        d: dict
            Image Choice Preset

        k: tuple
            Type key
        """
        self.file_list = []
        self.filter = d[ok.FILTER]
        self.folder_order = d[ok.FOLDER_ORDER]
        self.path = d[ok.FOLDER].strip(os.path.sep)

        if not os.path.isdir(self.path):
            self.path = None

        else:
            self._load_file_list()
        Type.__init__(self, d, k, single_get_file_ref, len(self.file_list))

    def _load_file_list(self):
        """Create a list of file-path."""
        self.file_list = _get_file_list(self.path, self.filter)

    def advance_index(self):
        """Update the file list index."""
        self.layer_i = self.r_i = self.c_i = -2

        if self.i is None:
            # Expired index.
            return

        if self.folder_order:
            # descending
            self.i -= 1
            if self.i < 0:
                # Expire index.
                self.i = None
        else:
            # ascending
            self.i += 1
            if self.i >= len(self.file_list):
                # Expire index.
                self.i = None

    def init_i(self):
        a = len(self.file_list)

        if self.path and a:
            self.i = a - 1 if self.folder_order else 0
        else:
            self.i = None

    @staticmethod
    def make_key(d):
        """
        Make a Folder reference key.

        d: dict
            Image Choice Preset
        """
        return _make_key(
            d, q=(d[ok.FOLDER], d[ok.FILTER], d[ok.FOLDER_ORDER])
        )


class ImageName(Type):
    """Manage an Image Name reference."""

    def __init__(self, d, k):
        """
        d: dict
            Image Choice Preset

        k: tuple
            Type key
        """
        self.image_name = d[ok.IMAGE_NAME]
        Type.__init__(self, d, k, single_get_tab, 1)

    def advance_index(self):
        """Rollover the part indices."""
        self.layer_i = self.r_i = self.c_i = -2

    def init_i(self):
        if self.image_name in Pic.name_q:
            self.i = Pic.name_q.index(self.image_name)
        else:
            self.i = None

    @staticmethod
    def make_key(d):
        """
        Make a ImageName reference key. A key is unique to a Type instance.

        d: dict
            Image Choice Preset
        """
        return _make_key(d, q=(d[ok.IMAGE_NAME],))


class Loop(Type):
    """Manage a Loop reference."""

    def __init__(self, d, k):
        """
        d: dict
            Image Choice Preset

        k: tuple
            Type key
        """
        self.loop_sign = bool(d[ok.LOOP])
        Type.__init__(self, d, k, single_get_tab, Pic.tab_count)

    def advance_index(self):
        """Set the next tab index."""
        self.layer_i = self.r_i = self.c_i = -2
        if self.i is not None:
            if self.loop_sign:
                self.i -= 1

                # negative rollover
                if self.i < 0:
                    self.i = Pic.tab_count - 1
            else:
                self.i += 1

                # positive rollover
                if self.i >= Pic.tab_count:
                    self.i = 0

    def init_i(self):
        self.i = -1 if Pic.tab_count else None
        self.advance_index()

    @staticmethod
    def make_key(d):
        """
        Make a Loop reference key. A key is unique to a Type instance.

        d: dict
            Image Choice Preset
        """
        return _make_key(d, q=(d[ok.LOOP],))


class Next(Type):
    """Manage a Next reference."""

    def __init__(self, d, k):
        """
        d: dict
            Image Choice Preset

        k: tuple
            Type key
        """
        Type.__init__(self, d, k, single_get_tab, Pic.tab_count)

    def advance_index(self):
        """Increment the Next index. On expiration, set the index to None."""
        self.r_i = self.c_i = self.layer_i = -2

        if self.i is None:
            # The index is already expired.
            return

        self.i += 1
        if self.i >= Pic.tab_count:
            self.i = None

    def init_i(self):
        self.i = 0 if Pic.tab_count else None

    @staticmethod
    def make_key(d):
        """
        Make a Next reference key. A key is unique to a Type instance.

        d: dict
            Image Choice Preset
        """
        return _make_key(d)


class Previous(Type):
    """Manage a Previous reference."""

    def __init__(self, d, k):
        """
        d: dict
            Image Choice Preset

        k: tuple
            Type key
        """
        Type.__init__(self, d, k, single_get_tab, Pic.tab_count)

    def advance_index(self):
        """
        Decrement the previous index. On expiration, set the index to None.
        """
        self.r_i = self.c_i = self.layer_i = -2

        if self.i is None:
            # It is already expired.
            return

        if self.i == -2:
            self.i = Pic.tab_count - 1

        self.i -= 1
        if self.i < 0:
            # Expire the index.
            self.i = None

    def init_i(self):
        self.i = Pic.tab_count - 1
        if self.i < 0:
            self.i = None

    @staticmethod
    def make_key(d):
        """
        Make a Previous reference key. A key is unique to a Type instance.

        d: dict
            Image Choice Preset
        """
        return _make_key(d)


class Random(Type):
    """Manage a Random reference."""

    def __init__(self, d, k):
        """
        d: dict
            Image Choice Preset

        k: tuple
            Type key
        """
        self.file_count = 0
        self._index_q = []
        self.file_list = []
        self.filter = d[ok.FILTER]
        self.folder_order = d[ok.FOLDER_ORDER]
        self.path = d[ok.FOLDER].strip(os.path.sep)
        self._seed = d[ok.SEED]

        if not os.path.isdir(self.path):
            self.path = None

        else:
            combine_seed(d)
            self._load_file_list()
        Type.__init__(self, d, k, single_get_file_ref, self.file_count)

    def _load_file_list(self):
        """Create a list of file-path."""
        if self.path:
            k = self.path, self.filter
            self.file_list = Pic.folder_d.get(k)

            if self.file_list is None:
                self.file_list = Pic.folder_d[k] = _get_file_list(*k)

            self.file_count = len(self.file_list)
            self._index_q = range(self.file_count)
            shuffle(self._index_q)

    def advance_index(self):
        """
        Increment the file list index. On expiration, set the index to None.
        """
        self.r_i = self.c_i = self.layer_i = -2

        if self.i is None:
            # The index is already expired.
            return

        self.file_i += 1

        if self.file_i >= self.file_count:
            self.i = None
        else:
            self.i = self._index_q[self.file_i]

    def init_i(self):
        self.i = self._index_q[0] if (self.path and self._index_q) else None
        self.file_i = 0

    @staticmethod
    def make_key(d):
        """
        Make a Folder reference key.

        d: dict
            Image Choice Preset
        """
        return _make_key(
            d, q=(d[ok.FOLDER], d[ok.FILTER], d[ok.SEED] + Globe.seed)
        )


class TabRef(Type):
    """Produce Tab reference layer output."""

    def __init__(self, d, k):
        """
        d: dict
            Image Choice Preset

        k: tuple
            Type key
        """
        self.tab_i = d[ok.TAB]
        Type.__init__(self, d, k, single_get_tab, 1)

    def advance_index(self):
        """Rollover the part indices."""
        self.layer_i = self.r_i = self.c_i = -2

    def init_i(self):
        i = int(self.tab_i) - 1
        # None is an invalid Tab index reference.
        self.i = i if i < len(Pic.name_q) else None

    @staticmethod
    def make_key(d):
        """
        Make a Next reference key. A key is unique to a Type instance.

        d: dict
            Image Choice Preset
        """
        return _make_key(d, q=(d[ok.TAB],))


# {Image Choice Type: sub-Type class}
TYPE_CLASS = {
    ok.FILE: File,
    ok.FOLDER: Folder,
    ok.IMAGE_NAME: ImageName,
    ok.LOOP: Loop,
    ok.NEXT: Next,
    ok.PREVIOUS: Previous,
    fi.RANDOM: Random,
    ok.TAB: TabRef
}
