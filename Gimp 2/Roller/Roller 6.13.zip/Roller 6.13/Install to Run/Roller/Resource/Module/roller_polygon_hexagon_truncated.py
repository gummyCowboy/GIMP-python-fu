#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import floor
from roller_constant_for import Grid as gr, Triangle as ft
from roller_model_goo import Goo
from roller_polygon import calc_pin_xy, make_coord_list


def calc_hexT(model, o, ellipse_space=.0):
    """
    Calculate the grid position and the size of hexagon cell shape.
    The ends are pointing horizontally. Is a double-spaced cell model-type.

    For Model cell, calculate 'cell' and 'merge'
    rectangle and their inscribed 'form' polygon.

    model: Model
    o: One
        Has Cell/Type option attribute.

    Return: dict
        {value: [bool, bool]}
        {cell key: [Plan vote change, Work vote change]}
    """
    def _arrange():
        """
        Arrange a hexagon shape of x, y coordinate
        where each x, y pair is a polygon vertex.

        Return: tuple
            Define a truncated hexagon.
        """
        return x, y1, x1, y, x2, y, x3, y1, x2, y2, x1, y2

    vote_d = {}
    did_cell = model.past.did_cell
    row, column = model.grid
    goo_d = model.goo_d
    x, y, canvas_w, canvas_h = model.canvas_pocket.rect

    if o.grid_type == gr.CELL_SIZE:
        # Correct cell size overflow.
        w = min(canvas_w, o.column_width)
        h = min(canvas_h, o.row_height)

        # grid size
        w1 = w * .75
        w2 = w - w1
        h1 = h / 2.
        s = column * w1 + w2, row * h1 + h1
        x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

    elif o.grid_type == gr.SHAPE_COUNT:
        # Calculate 's', 'w', 'h'.
        # vertical, cell size
        w = floor(canvas_w / (.25 + column * .75))
        h = floor(canvas_h / (.5 + row * .5))

        # two possible solutions
        # solution one
        # hexagon size, 'hex_w, hex_h'
        hex_w, hex_h = h * ft.SCALE_UP, h

        w1 = hex_w * .75
        w2 = hex_w - w1
        h1 = hex_h / 2.
        s = column * w1 + w2, row * h1 + h1

        if s[0] > canvas_w or s[1] > canvas_h:
            # solution two
            h = w * ft.SCALE_DOWN
            w1 = w * .75
            w2 = w - w1
            h1 = h / 2.
            s = column * w1 + w2, row * h1 + h1

        else:
            w, h = hex_w, hex_h
        x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

    else:
        # cell count
        w = canvas_w / (.25 + column * .75 - ellipse_space)
        h = canvas_h / (.5 + row * .5)

    h = h / 2.
    w1 = w * .25
    w2 = w * .75

    # [intersect point]
    q_x = []
    q_y = make_coord_list(canvas_h, row + 2, y, span=h)

    # Add remainder to coordinate when close to one.
    for _ in range(column + 1):
        q_x += [round(x), round(x + w1)]
        x += w2

    for r_c in model.cell_q:
        r, c = r_c
        c1 = c * 2
        x, x1, x2, x3 = q_x[c1:c1 + 4]
        y, y1, y2 = q_y[r:r + 3]
        a = goo_d[r_c] = Goo(r_c)

        # Prevent round to zero with max 1.
        a.cell.rect = a.merged.rect = \
            x, y, max(1., x3 - x), max(1., y2 - y)
        a.form = _arrange()
        vote_d[r_c] = did_cell(r_c)
    return vote_d
