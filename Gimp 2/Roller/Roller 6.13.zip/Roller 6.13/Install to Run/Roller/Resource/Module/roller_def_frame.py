#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_key import Option as ok, Widget as wk
from roller_def_dialog import (
    ADD,
    ADD_ALT,
    BELOW,
    BRUSH_D1,
    FILLER_CE,
    FILLER_HO,
    FILLER_S3,
    FILLER_MI,
    FILLER_CI,
    FILLER_RA,
    FILLER_CH,
    FILLER_S1,
    FILLER_ME,
    FILLER_S2,
    FILLER_FE,
    OVERLAY_CO,
    OVERLAY_CA,
    OVERLAY_BE,
    OVERLAY_OV,
    SHADOW,
    SHADOW_BASIC,
    STENCIL,
    WRAP,
    WRAP_AB,
    WRAP_AL,
    WRAP_BE,
    WRAP_BU,
    WRAP_CL,
    WRAP_CR,
    WRAP_DE,
    WRAP_FI,
    WRAP_GL,
    WRAP_GR,
    WRAP_JO,
    WRAP_PA,
    WRAP_PI,
    WRAP_TA,
    WRAP_WO
)
from roller_widget_row import WidgetRow

"""Define a variety of Frame type Preset."""

# Bevel________________________________________________________________________
BEVEL = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_BE, deepcopy(WRAP_BE)),
            (ok.OVERLAY_BE, OVERLAY_BE)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.BELOW, deepcopy(BELOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Brushy_______________________________________________________________________
BRUSHY = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_AL, deepcopy(WRAP_AL)),
            (ok.BRUSH_D1, deepcopy(BRUSH_D1)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Burst________________________________________________________________________
BURST = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_BU, deepcopy(WRAP_BU)),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Camo_________________________________________________________________________
CAMO = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_AB, deepcopy(WRAP_AB)),
            (ok.OVERLAY_CA, OVERLAY_CA)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.BELOW, deepcopy(BELOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])
CAMO[ok.BRW][wk.SUB][ok.WRAP_AB][wk.SUB][ok.WIDTH][wk.VAL] = 30.
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Ceramic______________________________________________________________________
CERAMIC = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_FI, deepcopy(WRAP_FI)),
            (ok.FILLER_CE, FILLER_CE),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Checker______________________________________________________________________
CHECKER = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_PA, deepcopy(WRAP_PA)),
            (ok.FILLER_CH, FILLER_CH),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Circuit______________________________________________________________________
CIRCUIT = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_CI, FILLER_CI),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Clear________________________________________________________________________
CLEAR = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_CL, deepcopy(WRAP_CL)),
            (ok.OVERLAY_CO, deepcopy(OVERLAY_CO))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.BELOW, deepcopy(BELOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Crumble______________________________________________________________________
CRUMBLE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_CR, deepcopy(WRAP_CR)),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Decay________________________________________________________________________
DECAY = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_DE, deepcopy(WRAP_DE)),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Fence___________________________________________________________________
FENCE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_PA, deepcopy(WRAP_PA)),
            (ok.FILLER_FE, FILLER_FE),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Glue_________________________________________________________________________
GLUE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_GL, deepcopy(WRAP_GL)),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Gradual______________________________________________________________________
GRADUAL = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_GR, deepcopy(WRAP_GR)),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Holey________________________________________________________________________
HOLEY = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_PA, deepcopy(WRAP_PA)),
            (ok.FILLER_HO, FILLER_HO),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Joint________________________________________________________________________
JOINT = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_JO, deepcopy(WRAP_JO)),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Mecha________________________________________________________________________
MECHA = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_PA, deepcopy(WRAP_PA)),
            (ok.FILLER_ME, FILLER_ME),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Mirror_______________________________________________________________________
MIRROR = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_MI, FILLER_MI),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Over_________________________________________________________________________
OVER = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.STENCIL, deepcopy(STENCIL)),
            (ok.OVERLAY_OV, OVERLAY_OV)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.BELOW, deepcopy(BELOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Pipe_________________________________________________________________________
PIPE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_PI, deepcopy(WRAP_PI)),
            (ok.OVERLAY_CO, deepcopy(OVERLAY_CO))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.BELOW, deepcopy(BELOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Rad__________________________________________________________________________
RAD = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_RA, FILLER_RA),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Stained______________________________________________________________________
STAINED = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_FI, deepcopy(WRAP_FI)),
            (ok.FILLER_S1, FILLER_S1),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Stretch______________________________________________________________________
STRETCH = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_FI, deepcopy(WRAP_FI)),
            (ok.FILLER_S2, FILLER_S2),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Stripe_______________________________________________________________________
STRIPE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_PA, deepcopy(WRAP_PA)),
            (ok.FILLER_S3, FILLER_S3),
            (ok.ADD, deepcopy(ADD))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Tape_________________________________________________________________________
TAPE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_TA, deepcopy(WRAP_TA)),
            (ok.OVERLAY_CO, deepcopy(OVERLAY_CO))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.BELOW, deepcopy(BELOW)),
            (ok.SHADOW_BASIC, deepcopy(SHADOW_BASIC))
        ]),
        wk.WIDGET: WidgetRow
    })
])
a = TAPE[ok.BRW][wk.SUB][ok.OVERLAY_CO][wk.SUB]
a[ok.COLOR_1][wk.VAL] = 230, 220, 210
a[ok.OPACITY][wk.VAL] = 15.
a[ok.MODE][wk.VAL] = "Normal"
a = TAPE[ok.RW1][wk.SUB][ok.SHADOW_BASIC][wk.SUB]
a[ok.INTENSITY][wk.VAL] = 75.
a[ok.BLUR][wk.VAL] = 7.
a[ok.BLUR][wk.RANDOM_Q] = 2., 10.
a = TAPE[ok.RW1][wk.SUB][ok.BELOW][wk.SUB]
a[ok.SWITCH][wk.VAL] = 1

# Switch on Below/Mod.
a1 = a[ok.MOD][wk.SUB]
a1[ok.SWITCH][wk.VAL] = 1

# Switch on Mod/Blur
a2 = a1[ok.BLUR_D][wk.SUB]
a2[ok.SWITCH][wk.VAL] = 1

# Change value and random limit.
for i in (ok.SIZE_X, ok.SIZE_Y):
    a2[i].update({wk.VAL: 3., wk.RANDOM_Q: (1., 6.)})
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

# Wobble_______________________________________________________________________
WOBBLE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_WO, deepcopy(WRAP_WO)),
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])
