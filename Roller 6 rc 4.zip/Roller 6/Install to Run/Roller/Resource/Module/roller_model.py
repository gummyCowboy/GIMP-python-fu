#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_constant_for import Shape as sh, Signal as si, Triangle as ft
from roller_constant_key import Option as ok
from roller_fu import remove_z
from roller_many_handle import Handle
from roller_model_goo import Goo
from roller_model_id import ModelId
from roller_one_ring import Ring
from roller_one_render import Render
from roller_polygon import ROUTE_SHAPE, ROUTE_POG, what_is_inverse_triangle
from roller_polygon_circle import GridCircle
from roller_polygon_square_mitered import SquareMitered
from roller_polygon_ellipse_horz import EllipseHorz
from roller_polygon_ellipse_vert import EllipseVert
from roller_polygon_hexagon import Hexagon
from roller_polygon_hexagon_truncated import HexagonTruncated
from roller_polygon_octagon import GridOctagon
from roller_polygon_octagon_double import GridOctagonDouble
from roller_polygon_parallelogram import Parallelogram
from roller_polygon_parallelogram_alt import ParallelogramAlt
from roller_polygon_rect import GridRect
from roller_polygon_triangle_horz import TriangleHorz
from roller_polygon_triangle_vert import TriangleVert
from roller_view_preset import calc_margin, calc_shift_rect
from roller_view_step import find_cell_margin, get_cell_shift
import gobject       # type: ignore

# Order by a chain of responsibility and dependence.
# Use with a Cell branch Model.
CELL_CHAIN = (
    si.RECTANGLE_CHANGE,
    si.RECTANGLE_CALC,
    si.CELL_RECT_CHANGE,
    si.CELL_RECT_CALC,
    si.CELL_SHIFT_CHANGE,
    si.CELL_SHIFT_CALC,
    si.CELL_MARGIN_CHANGE,
    si.CELL_MARGIN_CALC
)

# Convert a shape descriptor to a cell grid calculator.
CLASS_SHAPE = {
    sh.BOX_HORZ: HexagonTruncated,
    sh.BOX_HORZ_SHEAR: HexagonTruncated,
    sh.BOX_VERT: Hexagon,
    sh.BOX_VERT_SHEAR: Hexagon,
    sh.CIRCLE_HORIZONTAL: GridCircle,
    sh.CIRCLE_VERTICAL: GridCircle,
    sh.DIAMOND: SquareMitered,
    sh.ELLIPSE_HORIZONTAL: EllipseHorz,
    sh.ELLIPSE_VERTICAL: EllipseVert,
    sh.HEXAGON: Hexagon,
    sh.HEXAGON_SHEAR: Hexagon,
    sh.HEXAGON_TRUNCATED: HexagonTruncated,
    sh.HEXAGON_TRUNCATED_SHEAR: HexagonTruncated,
    sh.OCTAGON_DOUBLE: GridOctagonDouble,
    sh.OCTAGON_DOUBLE_SHEAR: GridOctagonDouble,
    sh.OCTAGON_SHEAR: GridOctagon,
    sh.OCTAGON: GridOctagon,
    sh.OCTAGON_ON_ITS_SIDE: GridOctagon,
    sh.OCTAGON_ON_ITS_SIDE_SHEAR: GridOctagon,
    sh.PARALLELOGRAM_ALT_LEFT: ParallelogramAlt,
    sh.PARALLELOGRAM_ALT_RIGHT: ParallelogramAlt,
    sh.PARALLELOGRAM_LEFT: Parallelogram,
    sh.PARALLELOGRAM_RIGHT: Parallelogram,
    sh.RECTANGLE: GridRect,
    sh.SQUARE: GridRect,
    sh.SQUARE_MITERED: SquareMitered,
    ft.TRIANGLE_DOWN_SHEAR: TriangleVert,
    ft.TRIANGLE_DOWN_REGULAR: TriangleVert,
    ft.TRIANGLE_UP_SHEAR: TriangleVert,
    ft.TRIANGLE_UP_REGULAR: TriangleVert,
    ft.TRIANGLE_LEFT_SHEAR: TriangleHorz,
    ft.TRIANGLE_LEFT_REGULAR: TriangleHorz,
    ft.TRIANGLE_RIGHT_SHEAR: TriangleHorz,
    ft.TRIANGLE_RIGHT_REGULAR: TriangleHorz
}


def get_main_q(d, q):
    """
    Produce a list of the main option settings' from
    a Model key list and a Preset dict.

    d: dict
        Preset that has a Per Cell option.

    q: list
        [(r, c) or (r, c, x), ...]

    Return: list
        list of (r, c) or (r, c, x) sorted in reverse order
        [(row, column)]
    """
    per = d[ok.PER]

    if per:
        return [k for k in q if k not in per]
    return q


class Past(gobject.GObject, object):
    """Remember the state of Model variables from the last view run."""

    # Are signals that can be emitted by this class.
    __gsignals__ = si.PAST_D

    def __init__(self, model):
        """
        model: Model
        """
        self._goo_q = [{}, {}]
        self._grid = [(0, 0), (0, 0)]

        gobject.GObject.__init__(self)

        self._model = model
        for i in (
            (si.CELL_MARGIN_VIEW, self.on_cell_margin_view),
            (si.CELL_RECT_VIEW, self.on_cell_rect_view),
            (si.CELL_SHIFT_VIEW, self.on_cell_shift_view)
        ):
            self.connect(*i)

    def _did_grid(self):
        """
        Did the Model's row and column count change?

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        return [self._grid[x] != self._model.grid for x in range(2)]

    def did_cell(self, r_c):
        """
        Did Cell rectangle change?

        r_c: tuple
            (row, column)
            cell index
            key to cell

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_grid()
        a = self._goo_q
        b = self._model.goo_d[r_c].cell.rect
        b1 = self._model.goo_d[r_c].plaque

        # Plan and Work, '2'
        for x in range(2):
            if not vote_q[x]:
                if r_c in a[x]:
                    # Goo, 'a1'
                    a1 = a[x][r_c]
                    vote_q[x] = a1.cell.rect != b or a1.plaque != b1
                else:
                    vote_q[x] = True
        return vote_q

    def did_cell_pocket(self, r_c):
        """
        Did Cell pocket change?

        r_c: tuple
            cell index

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_grid()
        a = self._goo_q

        # Goo, 'b, a1'
        b = self._model.goo_d[r_c]

        for x in range(2):
            if not vote_q[x]:
                if r_c in a[x]:
                    # Goo, 'a1'
                    a1 = a[x][r_c]
                    vote_q[x] = a1.shape != b.shape
                else:
                    vote_q[x] = True
        return vote_q

    def did_cell_shift(self, r_c):
        """
        Did Cell Shift change?

        r_c: tuple
            cell index

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_grid()

        a = self._goo_q
        b = self._model.goo_d[r_c]

        for x in range(2):
            if not vote_q[x]:
                if r_c in a[x]:
                    # Goo, 'a1'
                    a1 = a[x][r_c]
                    vote_q[x] = (
                        a1.plaque != b.plaque or a1.shift.rect != b.shift.rect
                    )
                else:
                    vote_q[x] = True
        return vote_q

    def did_merged(self, r_c):
        """
        Did Cell merged change?

        r_c: tuple
            zero-based cell index and key
            (row, column)

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_grid()

        a = self._goo_q
        b = self._model.goo_d[r_c]

        for x in range(2):
            if not vote_q[x]:
                if r_c in a[x]:
                    vote_q[x] = a[x][r_c].merged.rect != b.merged.rect
                else:
                    vote_q[x] = True
        return vote_q

    def on_cell_margin_view(self, _, x):
        """
        Respond to a Cell/Margin view by recording its state.

        _: Past
            Sent the Signal.

        x: int
            Plan or Work index
            0 or 1
        """
        d = self._goo_q[x]

        # (row, column), Goo; 'r_c, a'
        for r_c, a in self._model.goo_d.items():
            d[r_c].pocket.rect = a.pocket.rect
            d[r_c].shape = a.shape

    def on_cell_rect_view(self, _, x):
        """
        Respond to a Cell/Type view by recording its variables.

        _: Past
            Sent the Signal.

        x: int
            Plan or Work index
            0 or 1
        """
        self._grid[x] = self._model.grid
        d = self._goo_q[x] = {}

        # (row, column), Goo; 'r_c, a'
        for r_c, a in self._model.goo_d.items():
            d[r_c] = Goo(r_c)
            d[r_c].cell.rect = a.cell.rect
            d[r_c].merged.rect = a.merged.rect

    def on_cell_shift_view(self, _, x):
        """
        Respond to a Cell/Shift view by recording its variables.

        _: Past
            Sent the Signal.

        x: int
            Plan or Work index
            0 or 1
        """
        d = self._goo_q[x]

        # (row, column), Goo; 'r_c, a'
        for r_c, a in self._model.goo_d.items():
            d[r_c].shift.rect = a.shift.rect


class CellPast(Past):
    """
    Record a Cell-branch Model's view run state for change determination.
    """
    def __init__(self, model):
        self._rectangle = [None, None]

        Past.__init__(self, model)
        self.connect(si.RECTANGLE_VIEW, self.on_rectangle_view),

    def did_rectangle(self, rectangle):
        """
        Did the Cell/Rectangle change?

        pocket: Rect
            Compare with the viewed value.

        Return: list
            [Plan vote, Work vote]
            where a True vote is change
        """
        q = []

        for i in range(2):
            if self._rectangle[i]:
                q.append(rectangle != self._rectangle[i])
            else:
                q.append(True)
        return q

    def on_rectangle_view(self, _, x):
        """
        Respond to a Rectangle view by recording its state.

        _: Past
            Sent the Signal.

        x: int
            Plan or Work index
            0 or 1
        """
        self._rectangle[x] = self._model.rectangle


class Baby(gobject.GObject, object):
    """
    Accept Model type signal.
    Call from Ring when the interface is idle
    and after a Preset has finished loading.
    Send Signal ordered by a chain of responsibility.
    """
    # Reference
    #   github.com/sebp/PyGObject-Tutorial/blob/master/source/objects.txt
    #   library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
    #   zetcode.com/gui/pygtk/signals/
    #   stackoverflow.com/questions/66730/how-do-i-create-a-new-signal-in-pygtk

    # Are signals that can be emitted by this class.
    __gsignals__ = si.MODEL_D

    def __init__(self, chain):
        """
        chain: tuple
            (Signal, ...)
            Signal are sent from the beginning of the chain first.
            A signal handler will often add more signals to Baby.
        """
        # for custom signal(s)
        gobject.GObject.__init__(self)

        self._chain = chain

        # The chain of responsibility is processed in an orderly manner.
        # {Signal: value}
        self.signal_d = {}

        # Subscribe to idle processing.
        Ring.carry(self)

    def feed(self, signal, arg):
        """
        Emit a Signal after removing it from the Signal dict.

        signal: Signal
        arg: value
        """
        if signal in self.signal_d:
            self.signal_d.pop(signal)
        self.emit(signal, arg)

    def give(self, k, arg):
        """
        Add a Model Signal for later emission.

        k: string
            Signal type

        arg: value
        """
        if k in self._chain:
            self.signal_d[k] = k, arg

    def pressure(self):
        """Send Signal until the Signal dict is clear."""
        sending = True
        while sending:
            sending = False
            q = self.signal_d.keys()
            if q:
                for i in self._chain:
                    if i in q:
                        signal, arg = self.signal_d[i]

                        self.signal_d.pop(i)
                        self.emit(signal, arg)

                        # The signal dict can change after sending a signal.
                        sending = True
                        break

    def turn(self):
        """Send out a Signal found in Signal dict."""
        q = self.signal_d.keys()
        if q:
            # Signal emission is ordered by a responsibility chain.
            for i in self._chain:
                if i in q:
                    signal, arg = self.signal_d[i]

                    self.signal_d.pop(i)
                    self.emit(signal, arg)
                    break


class Model(Handle):
    """Factor Model type."""

    def __init__(self, model_name, past, chain):
        """
        model_name: string
            Identify the Model in ModelId and interface.

        past: object
            Record a snap-shot of a view run.

        chain: tuple
            of Signal ordered by a chain of responsibility
        """
        Handle.__init__(self)

        self._image_sel_d = {}
        self._caption_sel_d = {}
        self.cell_q = []
        self.goo_d = {}
        self.cell_shape = self.cell_type_d = None
        self.is_alt = \
            self.is_polygon = \
            self.is_triangle = \
            self.is_rectangle = \
            self.is_equilateral = False

        # [Plan output's Model layer group, Work output's Model layer group]
        self.group_q = [None, None]

        self.grid = 0, 0
        self.model_id = ModelId.make_id(model_name, self)
        self.nav_k = self.model_id,
        self.past = past(self)
        self.baby = Baby(chain)

        for i, p in (
            (si.CELL_MARGIN_CHANGE, self.on_cell_margin_change),
            (si.CELL_RECT_CHANGE, self.on_cell_rect_change),
            (si.CELL_SHIFT_CHANGE, self.on_cell_shift_change)
        ):
            self.latch(self.baby, (i, p))

        Ring.gob.emit(si.MODEL_CREATED, self)
        Render.gob.connect(si.CLOSE_VIEW_IMAGE, self.on_close_view_image)

    def adapt_cell_shape(self, r_c):
        """
        A triangle Cell shape is inverted with every other cell.
        An alt-parallelogram shape is inverted with every odd row.

        r_c: tuple
            (row, column)
            zero-based Goo key

        Return: string
            cell shape
        """
        n = self.cell_shape

        if self.is_triangle:
            if what_is_inverse_triangle(*r_c):
                return ft.INVERTED[n]
            return n

        elif self.is_alt:
            # On every odd row, switch parallelogram.
            if r_c[0] % 2:
                return sh.ALT_PARALLELOGRAM[n]
        return n

    def adapt_missing_cell_step(self, is_sequence):
        """
        Check Cell/Shift and Cell/Margin to see
        if its step is missing. If so, then set
        the default value for the property.

        is_sequence: bool
            If True, then the chain of responsibility
            sequence is calculated immediately.
        """
        d = get_cell_shift(self.nav_k)

        if not d:
            self.set_default_shift(d, is_sequence)
            if not find_cell_margin(self.nav_k):
                self.set_default_pocket(is_sequence)

    def calc_cell_pocket(self, d, r_c):
        """
        Calculate the pocket rectangle and shape polygon for Per.

        d: dict
            Margin Preset
            {Option key: value}

        r_c: tuple
            cell key
            (row, column)

        Return: list
            [Plan vote, Work vote]
            A True vote is vote for change.
        """
        q = calc_margin(d)
        is_margin = any(q)
        return self.calc_pocket(is_margin, q, r_c)

    def calc_cell_shift(self, d, k):
        """
        Update the Cell/Shift rectangle and 'plaque'
        polygon for a Cell given a Shift Preset
        and a previously calculated 'form' polygon.

        d: dict
            Shift Preset

        k: tuple
            Goo key

        Return: list
            [Plan vote, Work vote]
            Has vote on cell's Shift change since the last view run.
        """
        x, y, w, h = calc_shift_rect(d)

        # Goo, 'a'
        a = self.goo_d[k]
        x1, y1, w1, h1 = a.merged.rect
        a.shift.rect = x + x1, y + y1, w + w1, h + h1

        if any((x, y, w, h)):
            n = self.adapt_cell_shape(k)
            if n:
                p = ROUTE_SHAPE.get(n)
                a.plaque = p(a.shift) if p else ROUTE_POG[n](
                    a.shift, self.cell_type_d[ok.PARALLELOGRAM_SCALE]
                )

        else:
            a.plaque = a.form
        return self.past.did_cell_shift(k)

    def calc_main_cell_pocket(self, arg):
        """
        Calculate the 'pocket' rectangle and 'shape' polygon for main Cell.

        arg: tuple
            (Cell/Margin Preset, is sequence flag)
            ({Option key: value}, bool)
        """
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        q = calc_margin(d)
        is_margin = any(q)
        per = d[ok.PER]
        vote_d = {}

        for r_c in self.cell_q:
            if r_c in per:
                vote_d[r_c] = self.calc_cell_pocket(per[r_c], r_c)
            else:
                vote_d[r_c] = self.calc_pocket(is_margin, q, r_c)
        p(si.CELL_MARGIN_CALC, vote_d)

    def calc_main_cell_shift(self, arg):
        """
        Update the Cell/Shift rectangle for main Cell given a Shift Preset.

        arg: tuple
            (Shift Preset, is sequence flag)
        """
        vote_d = {}
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        per = d[ok.PER]

        for r_c in self.cell_q:
            if r_c in per:
                vote_d[r_c] = self.calc_cell_shift(per[r_c], r_c)
            else:
                vote_d[r_c] = self.calc_cell_shift(d, r_c)

        p(si.CELL_SHIFT_CALC, vote_d)
        if not find_cell_margin(self.nav_k):
            self.set_default_pocket(is_sequence)

    def calc_pocket(self, is_margin, q, r_c):
        """
        Update the 'pocket' rectangle and 'shape' polygon for a cell.

        is_margin: bool
            Is True if the cell has a margin.

        q: tuple
            (top, bottom, left, right) of numeric
            margin value

        r_c: tuple
            Goo key
            (row, column)
            zero-based grid index

        Return: iterable
            [Plan vote, Work vote]
            A vote is True if the 'pocket' or 'shape' changed value.
        """
        # Goo instance, 'a'
        a = self.goo_d[r_c]

        top, bottom, left, right = q
        n = self.adapt_cell_shape(r_c)
        x, y, w, h = a.shift.rect

        if is_margin:
            x += left
            y += top
            w = max(1., w - left - right)
            h = max(1., h - top - bottom)

        a.pocket.rect = x, y, w, h

        if is_margin:
            p = ROUTE_SHAPE.get(n)
            a.shape = p(a.pocket) if p else ROUTE_POG[n](
                a.pocket, self.cell_type_d[ok.PARALLELOGRAM_SCALE]
            )

        else:
            a.shape = a.plaque
        return self.past.did_cell_pocket(r_c)

    def die(self):
        """Delete the Model. Remove some connections."""
        self.unlatch()

        for z in self.group_q:
            if z:
                remove_z(z)

        self.group_q = [None, None]

        Ring.drop(self.baby)
        ModelId.delete_with_id(self.model_id)

    def get_caption_y(self, k):
        """
        Get a Caption Text selection.

        k: value
            Goo or Map key

        Return: tuple
            (position y, height of Caption text)
        """
        return self._caption_sel_d.get(k)

    def get_equilateral_type(self):
        """
        Determine if the cell shape has equal side length.

        Return: bool
            Is True if the cell shape is equilateral.
        """
        return self.cell_shape in sh.EQUILATERAL_TYPE

    def get_image_sel(self, k):
        """
        Get an image selection from its assignment.

        k: value
            Goo or Map key

        Return: GIMP selection reference or None
        """
        return self._image_sel_d.get(k)

    def get_main_cell_list(self, d):
        """
        Produce a list of the main option settings' cell index.

        d: dict
            A Preset that has a Per Cell option.

        Return: list
            list of (r, c) sorted in reverse order
            [(row, column)]
        """
        return get_main_q(d, self.cell_q)

    def get_merge_rect(self, k):
        """
        Get the cell rectangle from a cell's 'merged' value.

        k: int
            (row, column)
            (row, column, face/facing)
            zero-based cell index

        Return: tuple
            the rectangle of the cell post 'merged'
            x, y, w, h
        """
        return self.goo_d[k].merged.rect

    def get_plaque(self, k):
        """
        Get a cell's 'plaque' value.

        k: tuple
            (row, column)
            zero-based cell index
            Goo key

        Return: tuple
            Draw a 'plaque' polygon.
        """
        return self.goo_d[k].plaque

    def get_pocket_rect(self, k):
        """
        Get the cell 'pocket'.

        k: tuple
            Goo key
            (row, column)
            zero-based cell index

        Return: tuple
            (x, y, w, h)
            the rectangle of the cell within margin
        """
        return self.goo_d[k].pocket.rect

    def get_shape(self, k):
        """
        Get a Cell's 'shape' tuple.

        k: tuple
            Goo key
            (row, column)
            zero-based cell index

        Return: object
            Draw a 'shape' polygon.
        """
        return self.goo_d[k].shape

    def get_shift_rect(self, k):
        """
        Get the Cell/Shift rectangle.

        k: tuple
            Goo key
            (row, column)
            zero-based cell index

        Return: tuple
            (x, y, w, h)
            the rectangle of the shifted cell
        """
        return self.goo_d[k].shift.rect

    def on_cell_margin_change(self, _, arg):
        """
        Respond to change in the main Cell/Margin.

        _: Baby
            Sent the Signal.

        arg: tuple
            (Shift Preset, is sequence flag)
        """
        self.calc_main_cell_pocket(arg)

    def on_cell_rect_change(self, _, arg):
        """
        Respond to change in the Cell/Type.

        _: Baby
            Sent the Signal.

        arg: tuple
            (Cell/Type Preset, is sequence flag)
            {Option key: value}
        """
        self.update_type(arg)

    def on_cell_shift_change(self, _, arg):
        """
        Respond to change in the main Cell/Shift.

        _: Baby
            Sent the signal.

        arg: dict
            Shift Preset value
        """
        self.calc_main_cell_shift(arg)

    def on_close_view_image(self, *_):
        """Reset Model's group layer reference."""
        # Plan and Work both have a Model layer group.
        self.group_q = [None, None]

    def set_caption_y(self, k, q):
        """
        Save a Caption Text's properties.

        k: value
            key to the Caption properties

        q: tuple
            (position y, height of Caption text)
        """
        self._caption_sel_d[k] = q

    def set_default_pocket(self, is_sequence):
        """
        Set the Cell 'pocket' to the Cell/Shift rectangle.
        Calc the Cell shape using Cell/Shift rectangle.

        is_sequence: bool
            If True, then the chained-sequence is calculated immediately.
        """
        vote_d = {}
        p = self.baby.feed if is_sequence else self.baby.give

        for r_c in self.cell_q:
            vote_d[r_c] = self.calc_pocket(False, (0, 0, 0, 0), r_c)
        p(si.CELL_MARGIN_CALC, vote_d)

    def set_default_shift(self, d, is_sequence):
        """
        Set the Cell/Shift to the Cell 'merged' rectangle.
        Calc the Cell 'plaque' using the same rectangle.

        d: dict
            Cell/Shift Preset

        is_sequence: bool
            If True, then the sequence is calculated immediately.
        """
        vote_d = {}
        p = self.baby.feed if is_sequence else self.baby.give

        for r_c in self.cell_q:
            vote_d[r_c] = self.calc_cell_shift(d, r_c)
        p(si.CELL_SHIFT_CALC, vote_d)

    def set_image_sel(self, j, k):
        """
        Store an image selection.

        j: GIMP image
            Has selection.

        k: value
            Goo or Map key
        """
        # GIMP selection channel, 'a'
        a = self._image_sel_d.get(k)

        if a:
            if pdb.gimp_item_is_valid(a):
                pdb.gimp_image_remove_channel(j, a)
        self._image_sel_d[k] = pdb.gimp_selection_save(j)

    def update_type(self, arg):
        """
        Update common Model variable for Cell/Type.

        arg: tuple
            (Cell/Type Preset, is sequence flag)

        Return: list
            [Plan vote, Work vote]
            where a True vote is change
        """
        d = self.cell_type_d = arg[0]
        self.is_equilateral = self.get_equilateral_type()
        self.is_rectangle = self.cell_shape == sh.RECTANGLE
        self.is_alt = self.cell_shape in sh.ALT_PARALLELOGRAM
        self.is_triangle = self.cell_shape in ft.TRIANGLE
        self.is_polygon = self.cell_shape not in sh.CURVED

        self.calc_grid(d)
        self.init_cell_q(d)
        return self.init_model_cell(d)


# Register the custom signals.
gobject.type_register(Baby)
