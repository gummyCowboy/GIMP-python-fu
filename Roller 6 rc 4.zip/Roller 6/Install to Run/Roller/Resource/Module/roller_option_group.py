#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run, The
from roller_constant_for import Issue as vo, Signal as si
from roller_constant_key import (
    Button as bk,
    Node as ny,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_def_access import get_init
from roller_image_ref import ref_on_grid_change, ref_on_group_change
from roller_many_handle import Handle
from roller_one import Id
from roller_one_helm import Helm
from roller_one_ring import Ring
from roller_option_preset import Preset, SuperPreset
from roller_option_squish import ROUTE_SQUISH, all_visible, hide_option
from roller_view_step import make_render_key
from roller_widget_node import Node
from roller_widget_per import (
    PerGroupCell, PerGroupEmpty, PerGroupFace, PerGroupFacing, PerGroupMerge
)
from roller_widget_table import create_table
from roller_widget_voter import accept_vote
import gobject  # type: ignore

# An option group has three types.
GROUP_TYPE = {
    'node': Node,
    'preset': Preset,
    'super_preset': SuperPreset
}

# argument index enum
LABEL_X, WIDGET_X, KEY_ARG_X = range(3)

NO_VALUE = ok.PRESET, bk.RANDOM


class Booth(gobject.GObject, object):
    """
    Accept AnyGroup vote. Call from Ring when the interface
    is idle and after a Preset has finished loading.
    """
    # Reference
    #   github.com/sebp/PyGObject-Tutorial/blob/master/source/objects.txt
    #   library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
    #   zetcode.com/gui/pygtk/signals/
    #   stackoverflow.com/questions/66730/how-do-i-create-a-new-signal-in-pygtk

    # Are custom signal that can be emitted by this class.
    __gsignals__ = si.BOOTH_D

    def __init__(self):
        # for custom signal(s)
        gobject.GObject.__init__(self)

        # {int: int} of cast
        self.signal_d = {}

        Ring.carry(self)

    def cast(self, x):
        """
        Add a Model signal.

        x: int
            Plan or Work
            0 or 1
        """
        self.signal_d[x] = None

    def pressure(self):
        """Send signal until the signal dict is clear."""
        while self.signal_d:
            i = self.signal_d.keys()[0]
            self.signal_d.pop(i)
            self.emit(si.VOTE_CHANGE, i)

    def turn(self):
        """Send out a Signal."""
        for i in self.signal_d.keys():
            self.signal_d.pop(i)
            self.emit(si.VOTE_CHANGE, i)
            break


class AnyGroup(gobject.GObject, Handle):
    """Create a group of Widget with the same output goal."""
    # Are signals that can be emitted by this class.
    __gsignals__ = si.GROUP_D

    def __init__(self, draw_option, **d):
        """
        draw_option: function
            Add option.

        d: dict
            Initialize the option group.
            mandatory: wk.ITEM and wk.IS_DEFAULT
        """
        def _assign_per_g():
            """
            Determine the sub-PerWidget type for the option group.

            Return: class
                sub-PerWidget
            """
            _k = self.render_key

            if not _k:
                return PerGroupEmpty

            # PortCellEditor's Per branch key index, '-1'
            elif _k[-1] == ok.PER:
                return PerGroupEmpty

            # Table/Cell/Type's index, '-1'
            elif _k[-1] == ok.TYPE:
                return PerGroupMerge

            # Two items identify an option group type.
            elif _k[:2] not in sk.PER_GROUP:
                return PerGroupEmpty

            # branch key index, '1'
            elif _k[1] == ny.FACE:
                return PerGroupFace

            elif _k[1] == ny.FACING:
                return PerGroupFacing
            return PerGroupCell

        gobject.GObject.__init__(self)
        Handle.__init__(self)

        self.value_d = {}
        self.id = Id.make()
        self._view_value = [None, None]
        self.altered = [False, False]

        # Has nexus type data, 'item'.
        item = self.item = d[wk.ITEM]
        item.any_group = self

        # default Maya
        self.plan = self.work = Nada()

        # Collect change vote for main option settings.
        # [Plan vote dict, Work vote dict]
        self.vote_q = [{}, {}]

        # Made of the selected Node items that lead to the option group.
        # Is a navigation type step key where
        # the Model id is the Model reference.
        k = self.nav_k = d.get(wk.NAV_K)

        if k is not None:
            # Register the option group with a global group dict.
            Helm.add_step(self.nav_k, self)

        # Has Widget that populate an option group.
        # {Option key: Widget}
        # If a Widget has a key value of None, then it isn't included here.
        self.widget_d = {}

        # A render key is made of Node item, but has
        # a model-type for the Model reference.
        model = item.model

        if model and k is not None:
            self.render_key = make_render_key(k, model.model_type)

        elif wk.RENDER_KEY in d:
            # Per Cell has no step key and option view has a need to know.
            self.render_key = d[wk.RENDER_KEY]

        else:
            self.render_key = k

        # Is the group squash-able?
        self.is_squish = False
        p = ROUTE_SQUISH.get(item.key)

        if p and p != all_visible:
            # Yes, the group is squishy.
            self.is_squish = True

        self.booth = Booth()

        if d.get(wk.IS_NONE) is None:
            q = []
            key = item.key
            d[wk.ANY_GROUP] = self
            group_type = item.group_type
            type_ = GROUP_TYPE[group_type]
            group_d, keys = get_init(key) if group_type == 'preset' \
                else type_.get_init(key)
            relay = d[wk.RELAY][:]

            for i in keys:
                arg_d = group_d[i]
                arg_d[wk.KEY] = i

                if i == ok.PER:
                    arg_d[wk.WIDGET] = _assign_per_g()

                widget = arg_d[wk.WIDGET]

                arg_d.update(d)

                # label text, 'n'
                if i == ok.SWITCH:
                    n = item.item

                elif wk.COLUMN_TEXT in arg_d:
                    n = arg_d[wk.COLUMN_TEXT]

                elif widget.has_table_label:
                    n = arg_d[wk.TEXT] = i.split(",")[0]

                else:
                    # Next and Previous Label have no left side Label.
                    n = ""

                d[wk.RELAY] = relay[:]
                q.append([n, widget, arg_d])

            if wk.HAS_PRESET in d:
                if group_type == 'preset':
                    label = item.item

                else:
                    # Per Preset and SuperPreset
                    label = key.split(",")[1].strip()

                d[wk.RELAY] = relay[:]

                q += (
                    [
                        "%s Preset:" % (label,), type_, dict(d, key=ok.PRESET)
                    ],
                )
            if q:
                self.widget_d = draw_option(item.vbox, **dict(d, q=q))
                if (
                    d[wk.IS_DEFAULT] and
                    group_type not in ('super_preset', 'node')
                ):
                    # Preset option group type
                    Preset.load_default(self.widget_d, key)

        self.latch(self, (si.GROUP_CHANGE, self.on_changed))
        self.latch(self, (si.DISAPPEAR, self.on_disappear))

    def _cast_sub_vote(self, k, row_k, vote_q):
        """
        Cast vote from a sub-WidgetRow Widget.
        Vote is accumulating in 'self.vote_q'.

        k: string
            Option key

        row_k: string
            Row Option key

        vote_q: list
            [Plan vote dict, Work vote dict] from the Widget
        """
        # Plan and Work index range, '2'
        for x in range(2):
            d = self.vote_q[x]

            if row_k:
                if row_k not in d:
                    d[row_k] = {k: {}}
                d[row_k][k] = vote_q[x]

            else:
                d[k] = vote_q[x]
            self.booth.cast(x)

    def accept_vote(self, x, k, issue, vote):
        """
        Accept vote for a Widget in the AnyGroup.
        Record vote on Widget action. Clear
        vote when the AnyGroup's output is produced.

        x: int
            Plan or Work index

        k: string
            Option or cast key
            Is an Option key referencing a responsible Widget.
            A cast key is a Widget influencer, but not a Widget reference.

        issue: Issue
            Maya inspects vote for each issue.

        vote: bool
            A True value indicates that the Widget's
            value changed from the previous view.
            If any option or cast key has a True vote, then
            the issue equals True.

            For example,
            'matter' is an issue, typically, the core aspect layer of an
            option group. 'is_matter' is its Maya attribute.
            When 'Maya.is_matter' equals True, then the issue's output
            is produced unless other circumstances override.
        """
        accept_vote(self.vote_q[x], k, issue, vote)
        self.changed(x)

    def cast_vote(self, x, k, issue, vote):
        """
        Add a vote to the vote dict.

        x: int
            Plan or Work index; 0 or 1

        k: string
            option key or cast key

        issue: string or tuple
            issue type or (issue type,)

        vote: bool
            Is True if the Widget has changed value from its view value.
        """
        self.accept_vote(x, k, issue, vote)
        self.booth.cast(x)

    def changed(self, x=None):
        """
        Update group visibility.

        x: int or None
            0 to 1; Plan, Work
            None for both
        """
        if x is None:
            self.altered = [True, True]

        else:
            self.altered[x] = True
        Ring.add(self, si.GROUP_CHANGE, None)

    def do(self):
        """Produce option group output as part of a view run."""
        x = Run.x
        maya = (self.plan, self.work)[x]

        maya.do()
        self.set_view_value()

        self.vote_q[x] = {}
        self.altered[x] = False
        Ring.add(self, si.GROUP_VIEW, x)

    def on_changed(self, *_):
        """
        Respond to group change by updating option visibility.

        _: tuple
            not used
        """
        if self.is_squish:
            if The.load_count:
                # Come back after loading.
                Ring.add(self, si.GROUP_CHANGE, None)
            else:
                hide_option(self)

    def on_disappear(self, *_):
        """
        The AnyGroup is no longer in service, so disconnect its subscription.
        """
        self.unlatch()
        Ring.drop(self.booth)

    def get_preset_g(self):
        """
        Fetch the Preset Widget in the Widget dict if the key exists.
s
        Return: Widget or None
            Is the Preset option from this group.
        """
        return self.widget_d.get(ok.PRESET)

    def get_value_d(self):
        """
        Fetch the value of each Widget in the group.

        Return: dict
            {Option key: Widget value}
        """
        return self.value_d

    def set_view_value(self):
        """
        The view value is used by Widget to determine change
        between view runs. A view value is the Widget value
        at the point when its output is viewed.

        x: int
            Plan or Work index; 0 or 1
        """
        x = Run.x
        d = self.widget_d
        e = self.value_d
        for i in d:
            if i in e:
                d[i].set_view_value(x, e[i])

    def update_option_a(self, k, a):
        """
        Update the value dict for a Widget.

        k: string
            option and value dict key

        a: value
            value dict
        """
        self.value_d[k] = a

    def update_sub_g(self, k, row_k, a, vote_q):
        """
        Update a Widget value in the value dict.
        Use with a non-Voter type Widget.
        Is acceptable for normal Widget or sub-WidgetRow Widget.
        Cast the Widget's vote for change.

        k: string
            Option or sub-Row dict key

        row_k: string or None
            Is a Row key found in the value dict.

        a: value
            incoming option value

        vote_q:
            [Plan vote dict, Work vote dict]
            a vote dict structure:
            {
                Issue: {Option key: bool},
                Sub-Maya Option key: issue: {Option key: bool},
                Row key: {
                    Sub-Maya Option key: issue: {Option key: bool}
                }
            }
        """
        if row_k:
            if row_k not in self.value_d:
                self.value_d[row_k] = {}
            self.value_d[row_k][k] = a

        else:
            self.value_d[k] = a

        self._cast_sub_vote(k, row_k, vote_q)
        self.changed()

    def set_sub_widget_a(self, k, row_k, a):
        """
        Update the value dict for a Widget.
        Can update a sub-WidgetRow Widget's value.

        k: string
            Option key

        row_k: string or None
            Is the Row key found in the value dict.

        a: value
            for the value dict
        """
        if row_k:
            if row_k not in self.value_d:
                self.value_d[row_k] = {}
            self.value_d[row_k][k] = a
        else:
            self.value_d[k] = a

    def update_node_a(self, a):
        """
        For Node use. Update its value in the value dict.

        a: value
            from a Node
        """
        self.value_d['node'] = a


class LonerGroup(AnyGroup):
    """
    For a Widget that doesn't need a Table container for options.
    """

    def __init__(self, **d):
        AnyGroup.__init__(self, self.create_object, **d)

    @staticmethod
    def create_object(container, **d):
        """
        Place a Widget in a container.

        d: dict
            Has keyword variables.

        Return: dict
            {Option key: Widget}
        """
        i = d['q'][0]
        g = i[WIDGET_X](**i[KEY_ARG_X])

        container.pack_start(g, expand=True)
        return {g.key: g}


class ManyGroup(AnyGroup):
    """Has a Table container for Widget option."""

    def __init__(self, **d):
        AnyGroup.__init__(self, create_table, **d)


class NoneGroup(AnyGroup):
    """Has no options, but has AnyGroup attribute."""

    def __init__(self, **d):
        d[wk.IS_NONE] = 1
        AnyGroup.__init__(self, lambda a, **e: None, **d)


class ModelGroup(ManyGroup):
    """Process Model sequence change and chain of responsibility."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

    def on_cell_calc(self, _, vote_d):
        """
        Receive a Model/Cell calc Signal.

        _: Baby
            Sent the Signal.

        vote_d: dict
            {(r, c): [Plan vote, Work vote]}
            (r, c): (row, column); a zero-based cell index; Goo key
            'vote': bool
        """
        self.on_chain_change(vote_d)
        self.widget_d[ok.PER].intersect_vote(vote_d)

    def on_chain_change(self, vote_d):
        """
        The option group is an origin of change.

        vote_d: dict
            {(r, c): [Plan vote, Work vote]}
            (r, c): (row, column); a zero-based cell index; Goo key
            'vote': bool
        """
        vote_q = [False, False]
        q = self.item.model.get_main_cell_list(self.value_d)

        # (row, column), [Plan vote, Work vote]; 'k, q1'
        for k, q1 in vote_d.items():
            if k in q:
                vote_q = [i or vote_q[x] for x, i in enumerate(q1)]
                if vote_q == [True, True]:
                    break
        self.on_sequence_change(self, vote_q)

    def on_sequence_change(self, _, arg):
        """
        Sequence change is processed promptly. Where as Baby
        waits for the interface to be idle before sending and
        and starting a chain sequence.

        _: AnyGroup
            Sent the signal.

        arg: list
            [Plan vote, Work vote]
        """
        for x in range(2):
            # Plan and Work index, 'x'
            self.cast_vote(x, ok.IS_CHAIN, vo.MATTER, arg[x])
        self.emit(si.SEQUENCE, arg)


class DecoGroup(ModelGroup):
    """A deco group finishes chain of responsibility processing."""

    def __init__(self, **d):
        ModelGroup.__init__(self, **d)

        # node key, 'k'; its reverse position '-2'
        self.branch_k = self.nav_k[-2]

        if self.branch_k == ny.CELL:
            self.latch(
                self.item.model.baby, (si.CELL_MARGIN_CALC, self.on_cell_calc)
            )
        elif self.branch_k == ny.CANVAS:
            # Respond to Model Canvas change.
            self.latch(
                self.item.model.baby,
                (si.CANVAS_MARGIN_CALC, self.on_sequence_change)
            )

    def get_keys(self):
        """
        Fetch a list of keys for AnyGroup. The keys are
        determined by the branch and provided by the model.

        Return: list
            [assignment key, ...]
        """
        def _canvas():
            return [None]

        def _cell():
            return self.item.model.cell_q

        def _face():
            return self.item.model.face_q

        return {
            ny.CANVAS: _canvas,
            ny.CELL: _cell,
            ny.FACE: _face,
            ny.FACING: _face
        }[self.branch_k]()


class DecoImageGroup(DecoGroup):
    """Assign image using Ring."""
    image_slot_count = 3

    def __init__(self, **d):
        DecoGroup.__init__(self, **d)
        self.latch(self, (si.GROUP_CHANGE, ref_on_group_change))
        self.latch(
            self.item.model.baby, (si.CELL_RECT_CALC, self.on_grid_change)
        )

    def on_grid_change(self, baby, vote_d):
        """
        Update Ref on the grid change.

        baby: Baby
            not used

        vote_d: dict
            not used
        """
        ref_on_grid_change(self, self.get_keys())


class Nada:
    """Use with an option group that has no Maya (e.g. a SuperPreset group)."""

    def __init__(self, *_, **__):
        return

    def do(self, *_):
        return

    def reset(self, *_):
        return

    def reset_issue(self, *_):
        return

    def set_issue(self, *_):
        return


# Register the custom signals.
gobject.type_register(AnyGroup)
