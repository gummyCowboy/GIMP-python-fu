#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from collections import OrderedDict
from roller_constant_for import MAX_SIZE, Issue as vo
from roller_constant_key import Button as bk, Option as ok, Widget as wk
from roller_one_tip import Tip
from roller_def_option import RANDOM
from roller_widget_check_button import CheckButton
from roller_widget_row import WidgetRow
from roller_widget_slider import RandomSlider, RenderSlider, WIPSlider
import gtk  # type: ignore

# Define the Global Preset.
screen_w, screen_h = gtk.gdk.screen_width(), gtk.gdk.screen_height()
RENDER = {
    wk.ISSUE: vo.MATTER,
    wk.LIMIT: (1, MAX_SIZE),
    wk.PAGE_INCR: 100,
    wk.WIDGET: RenderSlider
}
render_h = RENDER.copy()
render_w = RENDER.copy()

render_h.update({wk.VAL: float(screen_h)})
render_w.update({wk.VAL: float(screen_w)})

GLOBAL = OrderedDict([
    (ok.RENDER_W, render_w),
    (ok.RENDER_H, render_h),
    (ok.WIP, {
        wk.ISSUE: vo.MATTER,
        wk.LIMIT: (1., 2.),
        wk.PAGE_INCR: .1,
        wk.PRECISION: 1,
        wk.TOOLTIP: Tip.WIP,
        wk.VAL: 1.2,
        wk.WIDGET: WIPSlider
    }),
    (ok.AZIMUTH, {
        wk.ISSUE: vo.EMBOSS,
        wk.LIMIT: (.0, 359.),
        wk.PRECISION: 1,
        wk.RANDOM_Q: (.0, 359.),
        wk.TOOLTIP: Tip.AZIMUTH,
        wk.VAL: 45.,
        wk.WIDGET: RandomSlider
    }),
    (ok.ELEVATION, {
        wk.COLUMN_TEXT: "Light Elevation",
        wk.ISSUE: vo.EMBOSS,
        wk.LIMIT: (.0, 180.),
        wk.PRECISION: 1,
        wk.RANDOM_Q: (7., 21.),
        wk.TOOLTIP: Tip.ELEVATION,
        wk.VAL: 13.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SEED, {
        wk.ISSUE: vo.SEED,
        wk.LIMIT: (0, 99999),
        wk.RANDOM_Q: (0, 99999),
        wk.TOOLTIP: Tip.SEED_GLOBAL,
        wk.VAL: 0.,
        wk.WIDGET: RandomSlider
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.HIDE_LAYER, {
                wk.ISSUE: vo.NULL,
                wk.TOOLTIP: Tip.HIDE_LAYER,
                wk.VAL: 0,
                wk.WIDGET: CheckButton
            }),
            (ok.DELETE_PLAN, {
                wk.ISSUE: vo.NULL,
                wk.TOOLTIP: Tip.DELETE_PLAN,
                wk.VAL: 1,
                wk.WIDGET: CheckButton
            })
        ]),
        wk.WIDGET: WidgetRow
    }),
    (bk.RANDOM, deepcopy(RANDOM))
])
