#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Step as sk
from roller_one_ring import Ring


def get_nav_step_list(d, k):
    """
    Make a list of navigation step key sorted
    by the navigation tree's process order.

    d: dict
        Has navigation step key of visible option group.
        {navigation step key: AnyGroup}

    k: tuple
        navigation step key
        (Node label, ...); Use Model id for Model reference.
        Is the key to the first Node in the tree.

    Return: tuple
        (SuperPreset step key list, Preset step key list)
    """
    def _walk(_group):
        """
        Use recursion to walk through the AnyGroup dict.
        Collect navigation step key by its group type.

        _group: AnyGroup
            Is either a Node, SuperPreset, or Preset type.
        """
        for _item in _group.item.node.get_item_list():
            _step_k = _item.any_group.nav_k

            if _item.group_type == 'preset':
                step_q.append(_step_k)
                preset_step_q.append(_step_k)

            elif _item.group_type == 'super_preset':
                preset_step_q.append(_step_k)

            _group1 = d[_step_k]
            if _group1.item.node:
                _walk(_group1)

    # Is a list of Preset-filtered step key that make up a view, 'step_q'.
    # [Preset navigation step key, ...]
    step_q = []

    # [SuperPreset navigation step key, ...]
    preset_step_q = []

    _walk(d[k])
    return preset_step_q, step_q


class Helm:
    """
    Has a dictionary of navigation step key with AnyGroup
    value that are visible in the user interface.
    """
    # {navigation step key: AnyGroup}
    _helm_d = {}

    # [sequenced navigation step key of Preset type]
    _step_q = []

    # [sequenced navigation step key of Preset, Node, and SuperPreset type]
    _all_step_q = []

    # [sequenced navigation step key of Preset and SuperPreset type]
    _preset_step_q = []

    is_virgin = True

    @staticmethod
    def add_step(k, a):
        """
        Add an AnyGroup to the Helm dict.

        k: tuple
            navigation step key

        a: AnyGroup
            Correspond with step key.
        """
        Helm._helm_d[k] = a

    @staticmethod
    def finds(k):
        """
        Determine if a navigation step key is the Helm dict.

        k: tuple
            navigation step key

        Return: bool
            Is True if the key is in the Helm dict.
        """
        return bool(k in Helm._helm_d)

    @staticmethod
    def get_all_step_q():
        """
        Provide a list of the steps in the navigation tree.

        Return: list
            [navigation step key]; [(node label, model id, node label, ...)]
        """
        return Helm._helm_d.keys()

    @staticmethod
    def get_branch_step_q(k):
        """
        Make a list of navigation step key that have a sub-step key.

        k: tuple
            Is the navigation step key at the start of a branch.

        Return: list
            containing branch step key
        """
        x = len(k)
        return [i for i in Helm._helm_d.keys() if k == tuple(i[0:x])]

    @staticmethod
    def get_group(k):
        """
        Fetch an AnyGroup from the Helm dict.

        k: tuple
            navigation step key

        Return: AnyGroup or None
        """
        if k in Helm._helm_d:
            return Helm._helm_d[k]

    @staticmethod
    def get_key_q():
        """Return a list of active navigation step key."""
        return Helm._helm_d.keys()

    @staticmethod
    def get_preset_step_q():
        """
        Compile a list of navigation step key ordered by process order
        excluding Node step key.

        Return: list
            [navigation step key, ...]
            navigation step key -> (Node label,), (Model id, Node label, ...)
        """
        return Helm._preset_step_q[:]

    @staticmethod
    def get_step_q():
        """Return a copy of the navigation step key list."""
        return Helm._step_q[:]

    @staticmethod
    def on_panel_change(*_):
        """
        When there's NodePanel change, the step lists needs to be updated.
        """
        Helm._preset_step_q, Helm._step_q = get_nav_step_list(
            Helm._helm_d, sk.STEPS
        )
        Ring.plug(si.HELM_CHANGE, Helm._step_q)

    @staticmethod
    def remove_step(k):
        """
        Remove a navigation step key from the Helm dict.

        k: tuple
            navigation step key
        """
        if k in Helm._helm_d:
            Helm._helm_d.pop(k)

    @staticmethod
    def remove_model(a):
        """
        Remove step having a given Model id reference from the Helm dict.

        a: int
            model id
        """
        d = Helm._helm_d
        for i in d.keys():
            if a in i:
                d.pop(i)


if Helm.is_virgin:
    Ring.gob.connect(si.PANEL_CHANGE, Helm.on_panel_change)
    Helm.is_virgin = False
