#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_a_contain import Dog
from roller_constant_for import Widget as fw
from roller_constant_key import Button as bk, Option as ok, Widget as wk
from roller_port import Port
from roller_widget_button import (
    AcceptButton,
    CancelButton,
    DraftButton,
    PeekButton,
    PlanButton,
    PreviewButton,
    RandomButton
)
from roller_widget_box import ColorHBox, ColorVBox, Eventful
from roller_widget_label import Label
from roller_widget_row import WidgetRow
import gtk  # type: ignore


class PortProcess(Port):
    """Factor Port processing."""

    def __init__(self, d, g):
        """
        d: dict
            Has init variable.

        g: Widget or None
            Is responsible.
        """
        self.preset = self.any_group = None
        Port.__init__(self, d, g)

    def draw_basic_process(self, box):
        """
        Draw a Widget group with Cancel and Accept options.

        box: GTK Box container
            Receive Widget group.
        """
        g = WidgetRow(
            **{
                wk.PADDING: (0, 0, fw.MARGIN, fw.MARGIN),
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win,
                wk.SUB: OrderedDict([
                    (bk.CANCEL, {wk.WIDGET: CancelButton}),
                    (bk.ACCEPT, {wk.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        box.add(g)

    def draw_column(self, function_q):
        """
        Draw the Port's Widget stacked as a column VBox container.

        function_q: iterable
            of function
        """
        self.draw_rc(ColorVBox, function_q)

    def draw_group(self, piece):
        """
        Draw simple dialog option.

        piece: Piece
            Has group attribute.
        """
        self.any_group = Dog.many_group(
            **{
                wk.COLOR: self.color,
                wk.IS_DEFAULT: False,
                wk.ITEM: piece,
                wk.HAS_PRESET: True,
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win
            }
        )
        self.any_group.render_key = self.repo.any_group.render_key
        self.preset = self.any_group.widget_d[ok.PRESET]
        self.preset.set_a(self.repo.get_a())

    def draw_list(self, function_q, label_q):
        """
        Draw the Port's Widget stacked as a column VBox container.

        function_q: iterable
            of function

        label_q: string
            of Label descriptor
        """
        for x, p in enumerate(function_q):
            box = Eventful(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if label_q[x]:
                vbox.pack_start(
                    Label(padding=(4, 4, 4, 4), text=label_q[x] + ":"),
                    expand=False
                )

            p(vbox)
            self.reduce_color()
            self.pack_start(box, expand=(True, False)[x])
        self.roller_win.gtk_win.vbox.set_size_request(350, 350)

    def draw_process(self, hbox):
        """
        Draw a Widget group with viewing options.

        vbox: GTK Box container
            Receive Widget group.
        """
        g = WidgetRow(
            **{
                wk.PADDING: (0, 0, fw.MARGIN, fw.MARGIN),
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win,
                wk.SUB: OrderedDict([
                    (bk.CANCEL, {wk.WIDGET: CancelButton}),
                    (bk.DRAFT, {wk.WIDGET: DraftButton}),
                    (bk.PEEK, {wk.WIDGET: PeekButton}),
                    (bk.PLAN, {wk.WIDGET: PlanButton}),
                    (bk.PREVIEW, {wk.WIDGET: PreviewButton}),
                    (bk.ACCEPT, {wk.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        hbox.add(g)

    def draw_random_process_group(self, vbox):
        """
        Draw a group with viewing Buttons.

        vbox: GTK container
            Receive Widget group.
        """
        g = WidgetRow(
            **{
                wk.ANY_GROUP: self.any_group,
                wk.PADDING: (0, 0, fw.MARGIN, fw.MARGIN),
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win,
                wk.SUB: OrderedDict([
                    (bk.CANCEL, {wk.WIDGET: CancelButton}),
                    (bk.DRAFT, {wk.WIDGET: DraftButton}),
                    (bk.PEEK, {wk.WIDGET: PeekButton}),
                    (bk.RANDOM, {wk.WIDGET: RandomButton}),
                    (bk.PLAN, {wk.WIDGET: PlanButton}),
                    (bk.PREVIEW, {wk.WIDGET: PreviewButton}),
                    (bk.ACCEPT, {wk.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        vbox.add(g)

    def draw_rc(self, box_type, function_q):
        """
        Draw the Port's Widget in the specified container.
        Each container has a color background assigned from 'self.color'.

        box_type: class
            Is the container type to make for the Widget group.

        function_q: iterable
            of function
        """
        for x, p in enumerate(function_q):
            box = box_type(self.color)

            self.add(box)
            p(box)
            self.reduce_color()

    def draw_row(self, function_q):
        """
        Draw the Port's Widget arranged as a row in an HBox container.

        function_q: iterable
            of function
        """
        self.draw_rc(ColorHBox, function_q)
