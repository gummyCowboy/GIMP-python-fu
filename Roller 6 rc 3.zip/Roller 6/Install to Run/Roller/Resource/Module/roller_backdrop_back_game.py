#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb  # type: ignore
from roller_a_contain import Run
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    make_layer_group,
    merge_layer_group,
    select_polygon,
    set_layer_mode
)
from roller_fu_mode import translate_mode
from roller_maya_style import Style, make_background
from roller_one_wip import Wip
from roller_polygon import make_coord_list
from roller_view_hub import color_selection, do_mod, set_fill_context_default
from roller_view_real import add_wip_layer


def make_style(maya):
    """
    Make a style layer.

    maya: Style
    Return: layer or None
        Backdrop Style material
    """
    j = Run.j
    d = maya.value_d
    group = make_layer_group(j, "WIP", maya.group, 0)
    back_z = make_background(group)
    column = int(d[ok.COLUMN])

    set_fill_context_default()

    # x-vector coordinate list, 'q_x'
    # Begin calculating 'q_x' for vertical triangle polygon drawing.
    x, y, canvas_w, h = Wip.get_rect()
    y1 = y + h
    w = canvas_w / (.5 + column * .5)
    w /= 2.
    x -= w
    q_x = make_coord_list(canvas_w, column + 5, x, span=w)

    # first color
    pdb.gimp_selection_none(j)

    z = add_wip_layer("Color 1", group)

    for c in range(0, column + 2, 2):
        select_polygon(
            j,
            (q_x[c], y1, q_x[c + 1], y, q_x[c + 2], y1),
            option=CHANNEL_OP_ADD
        )

    q = d[ok.COLOR_2A][0]

    set_layer_mode(z, translate_mode(d[ok.COLOR_1_MODE]))
    color_selection(z, q)

    a = d[ok.BELOW_COLOR_1]

    if a:
        blur_selection(back_z, a)

    # second color
    pdb.gimp_selection_none(j)

    z = add_wip_layer("Color 2", group)

    for c in range(0, column + 2, 2):
        select_polygon(
            j,
            (q_x[c + 1], y, q_x[c + 2], y1, q_x[c + 3], y),
            option=CHANNEL_OP_ADD
        )

    q = d[ok.COLOR_2A][1]

    set_layer_mode(z, translate_mode(d[ok.COLOR_2_MODE]))
    color_selection(z, q)

    a = d[ok.BELOW_COLOR_2]

    if a:
        blur_selection(back_z, a)

    z = merge_layer_group(group)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class BackGame(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
