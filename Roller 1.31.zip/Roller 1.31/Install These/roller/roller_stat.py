#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_base import Comm
from roller_constant import SessionKey
from math import sqrt


class Stat(object):
    """
    Used as a common ground for essential program variables.

    Has zero dependencies so it won't create a circular import problem.
    """
    def __init__(self):
        self._radius = 0

        # Layout:
        self.has_layout = False

        # job state:
        self.cancel = 1

        # job output image:
        self.render = None

        # automate state:
        # 0 is manual;
        # 1 is last-used;
        # 2 is randomized;
        # 3 is randomized and skip saving the sub-session dict.
        self.auto = 0

        # the session dict:
        self.session = {}

        # the number of format layers rendered:
        self.format_count = 0

        # the root folder for preset storage:
        self.preset_folder = None

    @property
    def height(self):
        return self.session[SessionKey.HEIGHT]

    @height.setter
    def height(self, _):
        """Is an invalid access."""
        raise Stat.StatWriteError('height')

    @property
    def radius(self):
        """Get the render's rectangle's diagonal length."""
        if self._radius:
            return self._radius

        else:
            s = self.size
            self._radius = int(sqrt(s[0]**2 + s[1]**2) / 2)
            return self._radius

    @radius.setter
    def radius(self, _):
        """Is an invalid access."""
        raise Stat.StatWriteError('radius')

    @property
    def size(self):
        """Return the render size."""
        return self.session[SessionKey.WIDTH], self.session[SessionKey.HEIGHT]

    @size.setter
    def size(self, _):
        """Is an invalid access."""
        raise Stat.StatWriteError('size')

    @property
    def width(self):
        """Return the render size."""
        return self.session[SessionKey.WIDTH]

    @width.setter
    def width(self, _):
        """Is an invalid access."""
        raise Stat.StatWriteError('width')

    class StatWriteError(Exception):
        """
        Called when a function attempts to write to a read-only property.
        """
        def __init__(self, n):
            """
            There was an write error.

            Spit out the variable name.

            n: function name
            """
            self.value = "StatWriteError: Attempted to write to a read-only " \
                "property: Stat.{}.".format(n)
            Comm.info_msg(self.value)

        def __str__(self):
            """
            Return the string value of the error message.

            This an Exception template function.
            """
            return repr(self.value)
