#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_base import Base
from roller_constant import (
    ForFormat,
    ForLayer,
    FormatKey,
    ForWidget,
    LayerKey,
    LayoutKey,
    SessionKey)

from roller_fu import Lay, Sel
from roller_grid import Grid
import gimp
import gimpfu as fu


class Layout:
    """Manage image placement."""
    pix = 0

    # layout layer margin:
    LAYER_MARGIN_COLOR = 200, 200, 206

    # layout cell margin:
    CELL_MARGIN_COLOR = 150, 156, 150

    # layout image rectangle:
    IMAGE_COLOR = 106, 100, 100

    # layout background:
    BACKGROUND_COLOR = 25, 25, 25

    # layout cell lines:
    GRID_COLOR = 225, 225, 225

    def __init__(self, stat):
        """stat: Stat"""
        self.stat = stat
        self._init_layout_references()

    def _draw_cell_margins(self, d):
        """
        Draw the cell margins.

        Called during a layout demo.

        d: format dict
        """
        just_one = Layout.is_draw_one_margin(d)
        row, col = d[FormatKey.ROW], d[FormatKey.COLUMN]
        cell = self._cell
        m = 0
        for r in range(row):
            for c in range(col):
                margin = Layout.get_cell_margin(r, c, d)
                for x in range(4):
                    draw = 1

                    # left, right:
                    if x in (ForFormat.LEFT_INDEX, ForFormat.RIGHT_INDEX):
                        if just_one and r > 0:
                            draw = 0

                    # top, bottom:
                    else:
                        if just_one and c > 0:
                            draw = 0
                    if draw:
                        v = margin[x]
                        if v:
                            # Unavailable cells have zero dimensions:
                            if cell.get_w(r, c):
                                m = 1
                                x1, y = cell.get_pos(r, c)
                                x1 += (
                                        0,
                                        0,
                                        -margin[ForFormat.LEFT_INDEX],
                                        cell.get_w(r, c)
                                    )[x]

                                y += (
                                        -margin[ForFormat.TOP_INDEX],
                                        cell.get_h(r, c),
                                        0,
                                        0
                                    )[x]

                                w = (
                                        cell.get_margin_w(r, c, d),
                                        cell.get_margin_w(r, c, d),
                                        v,
                                        v
                                    )[x]

                                h = (
                                        v,
                                        v,
                                        cell.get_margin_h(r, c, d),
                                        cell.get_margin_h(r, c, d)
                                    )[x]
                                Sel.rect(self.stat.render, x1, y, w, h)
        if m:
            self._color_fill(Layout.CELL_MARGIN_COLOR)

    def _draw_coord(self, j):
        """
        Draw image coordinates at the top-left of an image rectangle.

        j: Img
        """
        z = Lay.text(self.stat.render, str(j.x) + ", " + str(j.y))
        self._draw_text(j.x + 3, j.y, z)

    def _draw_corners(self, j):
        """
        Draw image corner coordinates.

        j: Img
        """
        # top-right:
        x = j.x + j.new_size[0]
        n = str(x) + ", " + str(j.y)
        z = Lay.text(self.stat.render, n)

        self._draw_text(x - z.width - 3, j.y, z)

        # bottom-left:
        y = j.y + j.new_size[1]
        n = str(j.x) + ", " + str(y)
        z = Lay.text(self.stat.render, n)
        self._draw_text(j.x + 3, y - z.height, z)

    def _draw_dim(self, j):
        """
        Draw an image's dimension at the bottom-right of an image rectangle.

        j: image
        """
        w, h = j.new_size[0], j.new_size[1]
        n = str(w) + ", " + str(h)
        z = Lay.text(self.stat.render, n)
        self._draw_text(j.x + w - z.width - 3, j.y + h - z.height, z)

    def _draw_format(self, d):
        """
        Draw a format.

        d: format dict
        """
        self._cell = Cell(d, self.stat)
        e = self.stat.session[SessionKey.LAYOUT_OPTION]
        q = ((
                LayoutKey.CELL_MARGINS, self._draw_cell_margins), (
                LayoutKey.LAYER_MARGINS, self._draw_layer_margins), (
                LayoutKey.GRID, self._draw_grid
            ))

        self._draw_image_types(d)
        if e:
            for i in q:
                if e[i[0]]:
                    i[1](d)

    def _draw_grid(self, d):
        """
        Draw grid lines.

        d: format dict
        """
        m = 0
        fk = FormatKey
        row, col = d[fk.ROW], d[fk.COLUMN]
        w, h = self.stat.width, self.stat.height
        top, left = d[fk.LAYER_MARGIN_TOP], d[fk.LAYER_MARGIN_LEFT]

        # Grid lines divide the layer space:
        w1 = w - left - d[fk.LAYER_MARGIN_RIGHT]
        x = left
        h1 = 1

        # Draw rows:
        if row > 1:
            for r in range(1, row):
                y = self._cell.get_row_y(r) + top
                if 0 < y < h:
                    m = 1
                    Sel.rect(self.stat.render, x, y, w1, h1)

        w1, h1 = 1, h - top - d[fk.LAYER_MARGIN_BOTTOM]
        y = top

        # Draw columns:
        if col > 1:
            for c in range(1, col):
                x = self._cell.get_col_x(c) + left
                if 0 < x < w:
                    m = 1
                    Sel.rect(self.stat.render, x, y, w1, h1)
        if m:
            self._color_fill(Layout.GRID_COLOR)

    def _draw_image_types(self, d):
        """
        Draw a rectangle that represents an image.

        d: format dict
        """
        a = LayoutKey
        row, col = d[FormatKey.ROW], d[FormatKey.COLUMN]
        cell = self._cell
        m = 0
        e = self.stat.session[SessionKey.LAYOUT_OPTION]
        q = ((
                a.COORDINATES, self._draw_coord), (
                a.CORNERS, self._draw_corners), (
                a.DIMENSIONS, self._draw_dim), (
                a.NAME, self._draw_name), (
                a.RATIOS, self._draw_ratio
            ))

        for r in range(row):
            for c in range(col):
                if cell.has_image(r, c, d):
                    m = 1
                    j = Layout.get_image_reference(r, c, d)
                    j.r, j.c = r, c
                    j.rot = Layout.get_rotate(r, c, d)

                    if j.rot:
                        if m:
                            Sel.fill(self._active_layer, Layout.IMAGE_COLOR)
                            Sel.none(self.stat.render)
                            m = 0

                    if j.rot:
                        z = Lay.add(
                            self.stat.render, j.n, z=self.format_group)

                    self.mold_rect(j, d, cell)

                    if j.rot:
                        self._rotate(j, z, cell, d)
                    if e:
                        for i in q:
                            if e[i[0]]:
                                i[1](j)
        if m:
            self._color_fill(Layout.IMAGE_COLOR)

    def _draw_layer_margins(self, d):
        """
        Draw the layer margins.

        d: format dict
        """
        m = 0
        fk, ff = FormatKey, ForFormat
        for x, k in enumerate(ff.LAYER_MARGIN_SPIN_BUTTON_KEY):
            if d[k]:
                m = 1
                if x in (ff.TOP_INDEX, ff.BOTTOM_INDEX):
                    # top, bottom:
                    x1 = d[fk.LAYER_MARGIN_LEFT]
                    w = self.stat.width - d[fk.LAYER_MARGIN_LEFT] \
                        - d[fk.LAYER_MARGIN_RIGHT]

                    h = d[k]

                    if x == ff.TOP_INDEX:
                        y = 0

                    else:
                        y = self.stat.height - d[k]

                else:
                    # left, right:
                    w = d[k]
                    h = self.stat.height - d[fk.LAYER_MARGIN_TOP] - \
                        d[fk.LAYER_MARGIN_BOTTOM]

                    y = d[fk.LAYER_MARGIN_TOP]

                    if x == ff.LEFT_INDEX:
                        x1 = 0

                    else:
                        x1 = self.stat.width - d[k]
                Sel.rect(self.stat.render, x1, y, w, h)
        if m:
            self._color_fill(Layout.LAYER_MARGIN_COLOR)

    def _draw_name(self, j):
        """
        Draw a document title at the center of an image rectangle.

        j: Img
        """
        z = Lay.text(self.stat.render, j.n)
        x = j.new_size[0] / 2 + j.x - z.width / 2
        y = j.new_size[1] / 2 + j.y + z.height / 2
        self._draw_text(x, y, z)

    def _draw_ratio(self, j):
        """
        Draw an image ratio at the center of an image rectangle.

        A ratio is an image center point divided by the render size.

        j: Img
        """
        x = j.new_size[0] / 2 + j.x
        y = j.new_size[1] / 2 + j.y
        x1 = x / 1. / self.stat.width
        y1 = y / 1. / self.stat.height
        r_x = format(x1, '.2f')
        r_y = format(y1, '.2f')
        n = r_x[int(x1 < 1):] + ", " + r_y[int(y1 < 1):]
        z = Lay.text(self.stat.render, n)
        x2 = x - z.width / 2
        y2 = y - z.height / 2
        self._draw_text(x2, y2, z)

    def _draw_text(self, x, y, z):
        """
        Adds a text layer to the format group.

        x, y: final position
        z: text layer
        """
        Lay.place(self.stat.render, z, self.format_group)
        pdb.gimp_text_layer_set_color(z, (255,) * 3)
        Lay.move(z, x, y)
        z.opacity = 66.

    def _color_fill(self, q):
        """
        Fill the selection with a color on the current format layer.

        q: color (RGB tuple)
        """
        Sel.fill(self._active_layer, q)
        Sel.none(self.stat.render)

    def _init_layout_references(self):
        """Initialize layout variables."""
        self._cell = self.format_group = self._active_layer = None
        self.layout_size = self.layout_background = self.blur_behind_layer = None

    def _rotate(self, j, z, cell, d):
        """
        Rotate an image rectangle.

        j: Img
        z: rotation layer
        cell: Cell
        d: format dict
        """
        # Create a new image with the selection:
        Sel.fill(z, Layout.IMAGE_COLOR)
        Sel.kopy(z)
        Lay.klear(self.stat.render, z)

        s = cell.get_cell_size(j.r, j.c)
        j2 = Img.paste()
        z1 = Lay.rotate(j2, j.rot)

        j.new_size = z1.width, z1.height

        if j.new_size[0] > s[0] or j.new_size[1] > s[1]:
            # The image won't fit into the cell so get the size that will:
            w, h = j.new_size = Img.calc_lock(s, j.new_size)
            z1 = pdb.gimp_item_transform_scale(z1, 0, 0, w, h)

        Sel.kopy(z1)
        Img.bury(j2)

        z4 = Lay.paste(self.stat.render, z)
        z4.name = Lay.get_layer_name("Rotated " + j.n, self.stat)

        Lay.bury(self.stat.render, z)
        cell.calc_rect_pos(d, j)
        Lay.move(z4, j.x, j.y)
        z4.opacity = 66.

    def do_blur_behind(self, image_layer, blur):
        """
        Create a blur behind layer if one doesn't exist.

        Use an opaque selection of an image
        to blur the area on the blur behind layer.

        image_layer: layer
        blur: blur amount
        """
        j = self.stat.render
        z = self.blur_behind_layer

        if not z:
            # Create the Blur Behind layer:
            Lay.hide(self.image_group)
            Lay.kopy(j)
            Lay.show(self.image_group)

            z = self.blur_behind_layer = Lay.paste(
                j, Lay.get_backdrop_layer(j))
            z.name = Lay.get_layer_name(LayerKey.BLUR_BEHIND, self.stat)
        z1 = Lay.selectable(j, image_layer, ForLayer.INHERIT_DICT)

        Sel.item(j, z1)
        Lay.blur(j, z, blur)
        Lay.bury(j, z1)
        Sel.none(j)

    @staticmethod
    def get_cell_margin(r, c, d):
        """
        Return the image margins for a cell at r, c.

        d: format dict
        """
        if not d[FormatKey.MARGIN_PER_CELL]:
            return \
                    d[FormatKey.CELL_MARGIN_TOP], \
                    d[FormatKey.CELL_MARGIN_BOTTOM], \
                    d[FormatKey.CELL_MARGIN_LEFT], \
                    d[FormatKey.CELL_MARGIN_RIGHT]

        else:
            return d[FormatKey.CELL_TABLE_MARGIN][r][c]

    @staticmethod
    def get_blur_behind(j, d):
        """
        Return the value of an image's blur behind setting.

        j: Img
        d: format dict
        """
        if d[FormatKey.PROPERTY_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PROPERTY][j.r][j.c][
                ForFormat.BLUR_BEHIND_INDEX]

        else:
            return d[FormatKey.BLUR_BEHIND]

    @staticmethod
    def get_flip_h(j, d):
        """
        Return the flip horizontal flag of an image being placed.

        j: Img
        d: format dict
        """
        if d[FormatKey.PROPERTY_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PROPERTY][j.r][j.c][
                ForFormat.FLIP_HORIZONTAL_INDEX]

        else:
            return d[FormatKey.FLIP_HORIZONTAL]

    @staticmethod
    def get_flip_v(j, d):
        """
        Return the flip vertical flag of an image being placed.

        j: Img
        d: format dict
        """
        if d[FormatKey.PROPERTY_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PROPERTY][j.r][j.c][
                ForFormat.FLIP_VERTICAL_INDEX]

        else:
            return d[FormatKey.FLIP_VERTICAL]

    @staticmethod
    def get_horz_just(r, c, d):
        """
        Return the horizontal justification for the cell at r, c.

        d: format dict
        """
        if d[FormatKey.PLACEMENT_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PLACEMENT][r][c][
                ForFormat.HORIZONTAL_INDEX]

        else:
            return d[FormatKey.HORIZONTAL]

    @staticmethod
    def get_image_reference(r, c, d):
        """
        Return an Img object for the cell at r, c.

        d: format dict
        """
        if not d[FormatKey.PLACEMENT_PER_CELL]:
            n = d[FormatKey.IMAGE]

        else:
            n = d[FormatKey.CELL_TABLE_PLACEMENT][r][c][
                ForFormat.IMAGE_INDEX]
        return Img.get_image(n)

    @staticmethod
    def sel_img_trim(d, j, j1):
        """
        Used to get the cell-size scaled image pixels
        for a trimmed or non-resized image.

        Create a selection rectangle for the image transfer.

        Copy the selection.

        d: Format dict
        j: Img
        j1: GIMP image

        Return the selection size.
        """
        # Need to select from one layer only:
        m = 0

        if len(j1.layers) > 1:
            Lay.kopy(j1)
            m = 1
            j1 = Img.paste()

        r, c = j.r, j.c
        n = Layout.get_horz_just(r, c, d)
        s = j.cell_size
        t = j1.width, j1.height

        if n == ForFormat.LEFT:
            x = 0
            x1 = s[0]

        elif n == ForFormat.CENTER:
            x = max(t[0] / 2 - s[0] / 2, 0)
            x1 = min(t[0] / 2 + s[0] / 2 + s[0] % 2, t[0])

        else:
            x = max(t[0] - s[0], 0)
            x1 = t[0]

        n1 = Layout.get_vert_just(r, c, d)

        if n1 == ForFormat.TOP:
            y = 0
            y1 = s[1]

        elif n1 == ForFormat.MIDDLE:
            y = max(t[1] / 2 - s[1] / 2, 0)
            y1 = min(t[1] / 2 + s[1] / 2 + s[1] % 2, t[1])

        else:
            y = max(t[1] - s[1], 0)
            y1 = t[1]

        # Correct for underflow:
        if x == x1:
            x1 += 1

        if y == y1:
            y1 += 1

        w = max(x1 - x, 1)
        h = max(y1 - y, 1)

        Sel.rect(j1, x, y, w, h, mode=fu.CHANNEL_OP_REPLACE)

        Sel.kopy(j1.layers[0])
        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j1)

        if m:
            Img.bury(j1)
        return x1 - x, y1 - y

    @staticmethod
    def get_placement(r, c, d):
        """
        Return the image placement for a cell at r, c.

        d: format dict
        """
        fk = FormatKey

        if not d[fk.PLACEMENT_PER_CELL]:
            return \
                d[fk.RESIZE], \
                d[fk.IMAGE], \
                d[fk.HORIZONTAL], \
                d[fk.VERTICAL]

        else:
            return d[fk.CELL_TABLE_PLACEMENT][r][c]

    @staticmethod
    def get_prop_opacity(r, c, d):
        """
        Return the opacity property of a cell at r, c.

        d: format dict
        """
        fk = FormatKey

        if d[fk.PROPERTY_PER_CELL]:
            return d[fk.CELL_TABLE_PROPERTY][r][c][ForFormat.OPACITY_INDEX]

        else:
            return d[fk.OPACITY]

    @staticmethod
    def get_resize_type(r, c, d):
        """
        Return the resize type for the cell at r, c.

        d: format dict
        """
        if d[FormatKey.PLACEMENT_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PLACEMENT][r][c][0]

        else:
            return d[FormatKey.RESIZE]

    @staticmethod
    def get_rotate(r, c, d):
        """
        Return the resize type for the cell at r, c.

        d: format dict
        """
        if d[FormatKey.PROPERTY_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PROPERTY][r][c][
                ForFormat.ROTATE_INDEX]

        else:
            return d[FormatKey.ROTATE]

    @staticmethod
    def get_vert_just(r, c, d):
        """
        Return the vertical justification for the cell at r, c.

        d: format dict
        """
        if d[FormatKey.PLACEMENT_PER_CELL]:
            return d[FormatKey.CELL_TABLE_PLACEMENT][r][c][
                ForFormat.VERTICAL_INDEX]

        else:
            return d[FormatKey.VERTICAL]

    @staticmethod
    def is_draw_one_margin(d):
        """
        Return true when drawing one margin per row or column.

        d: format dict
        """
        return not any((
                d[FormatKey.PLACEMENT_PER_CELL],
                d[FormatKey.MARGIN_PER_CELL],
                d[FormatKey.MERGE_PER_CELL],
                d[FormatKey.PROPERTY_PER_CELL]
            ))

    def do_new_render(self):
        """Creates a new image for the layout and render."""
        j = self.stat.render = Img.new(self.stat.width, self.stat.height)

        # Turn on undo functionality:
        pdb.gimp_image_undo_group_start(j)

    def mold(self, j, d, cell):
        """
        Mold an image to fit a cell.

        d: format dict
        cell: Cell
        """
        Sel.none(self.stat.render)

        s = j.cell_size = cell.get_cell_size(j.r, j.c)

        # Resize index for fill, locked, none, trim:
        x = ForFormat.RESIZE_OPTION.index(
            Layout.get_resize_type(j.r, j.c, d))

        (
            Img.mold_fill,
            Img.mold_lock,
            Img.mold_none,
            Img.mold_trim
        )[x](j, d)

        if j.rot:
            j2 = Img.paste()
            z = Lay.rotate(j2, j.rot)
            t = w, h = z.width, z.height

            Lay.kopy(j2)
            Img.bury(j2)

            if w > s[0] or h > s[1]:
                t = w, h = Img.calc_lock(s, t)
                j3 = Img.paste()
                Img.shape(j3, w, h)
            j.new_size = t
        cell.calc_rect_pos(d, j)

    def mold_rect(self, j, d, cell):
        """
        Draw an image rectangle for a layout
        that corresponds with the format.

        d: format dict
        cell: Cell
        """
        s = j.size
        t = j.cell_size = cell.get_cell_size(j.r, j.c)

        typ = Layout.get_resize_type(j.r, j.c, d)

        if typ == ForFormat.FILL_CELL:
            s1 = t

        elif typ == ForFormat.LOCKED:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = Img.calc_lock(t, s)

            else:
                s1 = s

        elif typ == ForFormat.NONE:
            s1 = list(s)

            if s[0] > t[0]:
                s1[0] = t[0]
            if s[1] > t[1]:
                s1[1] = t[1]

        else:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = Img.get_trim_size(s, t)
                if s1[1] > t[1]:
                    s1[1] = t[1]

                else:
                    s1[0] = t[0]

            else:
                s1 = s

        j.new_size = s1

        cell.calc_rect_pos(d, j)
        Sel.rect(self.stat.render, j.x, j.y, *s1)

    def place_image(self, j, d, cell):
        """
        Copies and pastes images on or above the image layer.

        j: Img
        d: format dict
        cell: Cell
        """
        # The Img's image will enter the copy and paste buffer:
        self.mold(j, d, cell)

        if not self.pix:
            a = 1 if self.stat.has_layout else 0
            self.image_group = Lay.group(
                    self.stat.render,
                    Lay.get_layer_name(d[FormatKey.NAME], self.stat),
                    a=a
                )

        z = Lay.paste(self.stat.render, self.stat.render.layers[-1])
        z.opacity = Layout.get_prop_opacity(j.r, j.c, d) / 1.

        Lay.order(self.stat.render, z, self.image_group)

        if Layout.get_flip_h(j, d):
            Lay.flip(z, horz=1)

        if Layout.get_flip_v(j, d):
            z = Lay.flip(z)

        Lay.move(z, j.x, j.y)

        blur = Layout.get_blur_behind(j, d)

        if blur:
            self.do_blur_behind(z, blur)
        self.pix += 1

    def remove_background(self):
        """
        Deletes the Layouut's background layer.

        Updates layout references.
        """
        Lay.bury(self.stat.render, self.layout_background)
        self.layout_background = None

    def remove_layout_group(self):
        """
        Deletes the Layouut's background layer.

        Updates layout references.
        """
        Lay.bury(self.stat.render, self.layout_group)
        self._init_layout_references()

    def show(self):
        """Draw the layout."""
        stat = self.stat
        Images.next_x = 0
        s = stat.size

        if self.layout_background:
            if self.layout_size != s:
                # Delete old layout:
                pdb.gimp_image_undo_group_end(stat.render)
                pdb.gimp_display_delete(self.display)
                self.layout_background = stat.has_layout = None

        if not self.layout_background:
            # Create a new layout:
            self.do_new_render()
            z = self.layout_background = Lay.add(
                    stat.render,
                    "Layout Background"
                )

            self.display = pdb.gimp_display_new(stat.render)
            self.layout_size = stat.width, stat.height
            Lay.color_fill(z, Layout.BACKGROUND_COLOR)

        q = self.stat.session[SessionKey.FORMAT_LIST]
        start = len(q) - 1

        if self.stat.has_layout:
            # Delete group:
            Lay.bury(stat.render, self.layout_group)

        if start > -1:
            # new group:
            z = self.layout_group = Lay.group(
                    stat.render,
                    Lay.get_layer_name("Layout", self.stat)
                )

        # Draw format layouts:
        for x in range(start, -1, -1):
            stat.has_layout = 1
            d = q[x]
            n = d[FormatKey.NAME]
            z1 = self.format_group = Lay.group(
                    stat.render,
                    Lay.get_layer_name("Layout Group: " + n, self.stat)
                )

            Lay.order(stat.render, z1, z)
            z1 = self._active_layer = Lay.add(
                    stat.render,
                    Lay.get_layer_name("Layout: " + n, self.stat),
                    z=z1
                )

            z1.opacity = 66.
            self._draw_format(d)

        Lay.activate(stat.render, z)
        pdb.gimp_displays_flush()


class Img:
    """
    Used to manage an open image.

    The Images class creates a list of Img objectsfor layout design.
    """

    def __init__(self, j, n):
        """
        j: image
        n: image name
        """
        Sel.none(j)
        self.j = j
        self.n = n
        self.size = j.width, j.height

    @staticmethod
    def bury(j):
        """
        Delete an image that doesn't have a display.

        j: GIMP image
        """
        pdb.gimp_image_delete(j)

    @staticmethod
    def calc_lock(s, t):
        """
        Return the size of an image that will fit into a smaller cell.

        s: cell size
        t: image size
        """
        w_r = float(t[0]) / s[0]
        h_r = float(t[1]) / s[1]

        if w_r > h_r:
            w, h = s[0], int(t[1] * (s[0] / float(t[0])))

        else:
            w, h = int(t[0] * (s[1] / float(t[1]))), s[1]

        # underflow:
        return w + int(int(w) == 0), h + int(int(h) == 0)

    @staticmethod
    def get_image(n):
        """
        Return an Img object.

        n: name of image
        """
        a = Images

        if n == ForFormat.NEXT:
            j = a.get_next()

        elif n in a.image_names:
            x = a.image_names.index(n)
            j = a.images[x]

        else:
            x = a.relative_names.index(n)
            j = a.images[x]
        return j

    @staticmethod
    def get_trim_size(s, t):
        """
        Return the size of the trim.

        s: image size
        t: cell size
        """
        w_r = t[0] / 1. / s[0]
        h_r = t[1] / 1. / s[1]

        if s[0] < t[0] and s[1] < t[1]:
            # No trim needed:
            w, h = s

        else:
            if w_r < h_r:
                # The image height is closer to the cell size:
                w, h = int(s[0] * h_r), t[1]
                h = min(h, s[1])

            else:
                # The image width is closer to the cell size:
                w, h = int(s[0] * w_r), int(s[1] * w_r)
                w = min(w, s[0])

        # underflow:
        return [w + int(int(w) == 0), h + int(int(h) == 0)]

    @staticmethod
    def mold_fill(j, _):
        """
        Resize a fill-image resize-type.

        Return with the image data in the buffer.
        """
        if j.size != j.cell_size:
            Lay.kopy(j.j)
            j1 = Img.paste()
            j.new_size = w, h = j.cell_size
            Img.shape(j1, w, h)

        else:
            j.new_size = j.size
            Lay.kopy(j.j)

    @staticmethod
    def mold_lock(j, _):
        """
        Resize a locked image resize-type.

        Return with the image data in the buffer.
        """
        Lay.kopy(j.j)
        if j.size[0] > j.cell_size[0] or j.size[1] > j.cell_size[1]:
            # down-size:
            w, h = Img.calc_lock(j.cell_size, j.size)
            j1 = Img.paste()
            Img.shape(j1, w, h)

        else:
            w, h = j.size
        j.new_size = w, h

    @staticmethod
    def mold_none(j, d):
        """
        Resize a None-image resize-type.

        Return with the image data in the buffer.

        d: format dict
        """
        if j.size[0] > j.cell_size[0] or j.size[1] > j.cell_size[1]:
            # Copy a rectangle:
            j.new_size = Layout.sel_img_trim(d, j, j.j)

        else:
            j.new_size = j.size
            Lay.kopy(j.j)

    @staticmethod
    def mold_trim(j, d):
        """
        Resize a None-image resize-type.

        Return with the image data in the buffer.

        d: format dict
        """
        s = s1 = j.size
        t = j.cell_size

        Lay.kopy(j.j)

        if s[0] > t[0] or s[1] > t[1]:
            w, h = Img.get_trim_size(s, t)
            j1 = Img.paste()
            Img.shape(j1, w, h)

            j1 = Img.paste()
            s1 = Layout.sel_img_trim(d, j, j1)

            # Copy selection:
            Lay.kopy(j1)
            Img.bury(j1)
        j.new_size = s1

    @staticmethod
    def new(w, h):
        """
        Create a new image based on the global scales.

        w, h: size of the new image

        Return the new image.
        """
        return pdb.gimp_image_new(w, h, fu.RGB)

    @staticmethod
    def paste():
        """
        Paste the buffer as a new image.

        Return the new image.
        """
        return pdb.gimp_edit_paste_as_new_image()

    @staticmethod
    def shape(j, w, h):
        """
        Resize, copy, and close an image.

        j: GIMP image with one layer
        w: width
        h: height
        """
        z = j.layers[0]

        pdb.gimp_layer_scale(z, w, h, 1)
        pdb.gimp_image_resize_to_layers(j)
        Lay.kopy(j)
        Img.bury(j)


class Images:
    """Used to manage the open images."""
    # number of valid images:
    image_count = 0

    # next image index:
    next_x = 0

    # open images:
    images = []

    # valid image names:
    image_names = []
    format_img_list = []
    relative_names = []

    @staticmethod
    def get_img():
        """Collect related data for images."""
        # post-fix image number tuple:
        q = pdb.gimp_image_list()[1][::-1]

        # gimp.Image list:
        q1 = reversed(gimp.image_list())

        for x, j in enumerate(q1):
            n = j.name + "-" + str(q[x])
            Images.images.append(Img(j, n))

        q = Images.image_names = Images.make_image_name_list()
        Images.image_count = len(q)

        for i in range(len(q)):
            go = 1
            while go:
                go = q.count(q[i]) - 1
                if go:
                    x = q.index(q[i])
                    q[x] = Images.images[x].n = q[x] + " (" + str(go) + ")"

        # Make list for format:
        q = Images.format_img_list = Images.image_names[:]
        b = Images.relative_names

        for i in range(len(q)):
            n = str(i + 1)
            a1 = i + 1

            if i == 0 or (a1 > 20 and a1 % 10 == 1):
                c = n + "st"

            elif i == 1 or (a1 > 20 and a1 % 10 == 2):
                c = n + "nd"

            elif i == 2 or (a1 > 20 and a1 % 10 == 3):
                c = n + "rd"

            else:
                c = n + "th"
            b.append(c + " Image")

        q.append("★")

        q += b

        q.insert(0, ForFormat.NEXT)
        q.insert(1, ForFormat.NONE)
        q.insert(2, ForWidget.LIST_SEPARATOR)

    @staticmethod
    def get_next():
        """Return the next Img or none."""
        j = None
        a = Images

        if a.next_x < a.image_count:
            j = a.images[a.next_x]
            a.next_x += 1
        return j

    @staticmethod
    def make_image_name_list():
        """Return a list of valid image names."""
        return [i.n for i in Images.images]


class Cell:
    """Calculate cell-related dimensions."""

    def __init__(self, d, stat):
        """
        Create a new cell table, ‟tb”, to store the cell sizes.

        Calculate cell sizes.

        Correct cell size underflow.

        d : format dict
        stat: Stat
        """
        fk = FormatKey
        self.stat = stat
        r, c = d[fk.ROW], d[fk.COLUMN] = self.r, self.c = (
                    min(d[fk.ROW], self.stat.height),
                    min(d[fk.COLUMN], self.stat.width)
                )

        # cell table with cell keys: 'x', 'y', 'w', 'h':
        self.tb = Base.create_2d_table(r, c)

        # Calculate layer size:
        w = self.stat.width - d[fk.LAYER_MARGIN_LEFT] - \
            d[fk.LAYER_MARGIN_RIGHT]

        h = self.stat.height - d[fk.LAYER_MARGIN_TOP] - \
            d[fk.LAYER_MARGIN_BOTTOM]

        # ‟s” is the size of a cell before image margins are subtracted
        # and after layer margins are subtracted from the layer size:
        s = (
                Base.seal(w, 1, self.stat.width),
                Base.seal(h, 1, self.stat.height)
            )

        self.odd = Grid(s, self.r, self.c)

        # Cells reduce their size with cell margins:
        for r in range(self.r):
            for c in range(self.c):
                self.calc_cell(r, c, d)

    def calc_block(self, start, end, d):
        """Recalculate the cell sizes for a block of cells."""
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self.calc_cell(r, c, d)

    def calc_cell(self, r, c, d):
        """
        Adds a dict entry to ‟self.tb” for the cell at r, c.

        d: format dict
        """
        # If merging cells:
        if d[FormatKey.MERGE_PER_CELL]:
            s = d[FormatKey.CELL_TABLE_MERGE][r][c]

            # Sub-top-left cells are unavailable:
            if s == (-1, -1):
                x = y = w = h = 0

            else:
                k1 = (r + s[0] - 1, c + s[1] - 1)
                x, y, w, h = self.odd.block((r, c), k1)

        else:
            x, y, w, h = self.odd.cell(r, c)

        if w:
            a = Layout.get_cell_margin(r, c, d)
            x += a[ForFormat.LEFT_INDEX] + d[FormatKey.LAYER_MARGIN_LEFT]
            y += a[ForFormat.TOP_INDEX] + d[FormatKey.LAYER_MARGIN_TOP]

            # Correct for margin overflow errors:
            x = Base.seal(x, 0, self.stat.width - 1)
            y = Base.seal(y, 0, self.stat.height - 1)
            w = w - a[ForFormat.LEFT_INDEX] - a[ForFormat.RIGHT_INDEX]
            h = h - a[ForFormat.TOP_INDEX] - a[ForFormat.BOTTOM_INDEX]

            # Set ‟w”, ‟h” to the minimum value if size underflowed:
            w, h = max(w, 1), max(h, 1)
        self.tb[r][c] = {'x': x, 'y': y, 'w': w, 'h': h}

    def calc_rect_pos(self, d, j):
        """
        For an image or rectangle, calculate its (x, y) position in a cell.

        d: format dict
        j: Img
        """
        r, c = j.r, j.c
        x, y = self.get_pos(r, c)
        w, h = j.new_size[0], j.new_size[1]

        n = Layout.get_horz_just(r, c, d)
        n1 = Layout.get_vert_just(r, c, d)

        if n == ForFormat.CENTER:
            self.get_w(r, c)
            x += (self.get_w(r, c) - w) / 2

        elif n == ForFormat.RIGHT:
            x += self.get_w(r, c) - w

        if n1 == ForFormat.MIDDLE:
            y += (self.get_h(r, c) - h) / 2

        elif n1 == ForFormat.BOTTOM:
            y += self.get_h(r, c) - h
        j.x, j.y = x, y

    def get_cell_info(self, r, c):
        """Return a cell's dimension and position for a cell at r, c."""
        return (
            self.tb[r][c]['w'], self.tb[r][c]['h'],
            self.tb[r][c]['x'], self.tb[r][c]['y'])

    def get_cell_size(self, r, c):
        """Return a cell's width and height for a cell at r, c."""
        return self.tb[r][c]['w'], self.tb[r][c]['h']

    def get_col_x(self, c):
        """Return the coordinate x for column, c."""
        x, _, _, _ = self.odd.cell(0, c)
        return x

    def get_row_y(self, r):
        """Return the coordinate y for row, r."""
        _, y, _, _ = self.odd.cell(r, 0)
        return y

    def get_h(self, r, c):
        """Return the cell height for a cell at r, c."""
        return self.tb[r][c]['h']

    def get_margin_h(self, r, c, d):
        """
        Return the height of an image margin for the cell at r, c.

        d: format dict
        """
        if Layout.is_draw_one_margin(d):
            a = Layout.get_cell_margin(r, c, d)
            return self.stat.height - d[FormatKey.LAYER_MARGIN_TOP] - \
                d[FormatKey.LAYER_MARGIN_BOTTOM] - a[ForFormat.TOP_INDEX] - \
                a[ForFormat.BOTTOM_INDEX]

        else:
            return self.get_h(r, c)

    def get_margin_w(self, r, c, d):
        """
        Return the width of an image margin at r, c.

        d: format dict.
        """
        fk = FormatKey
        if Layout.is_draw_one_margin(d):
            a = Layout.get_cell_margin(r, c, d)
            return self.stat.width - d[fk.LAYER_MARGIN_LEFT] - \
                d[fk.LAYER_MARGIN_RIGHT] - a[ForFormat.LEFT_INDEX] -\
                a[ForFormat.RIGHT_INDEX]

        else:
            return self.get_w(r, c)

    def get_pos(self, r, c):
        """Return the cell coordinate (x, y) for a cell at r, c."""
        return self.tb[r][c]['x'], self.tb[r][c]['y']

    def get_w(self, r, c):
        """Return the cell width for a cell at r, c."""
        return self.tb[r][c]['w']

    def has_image(self, r, c, d):
        """
        Return true if a cell has an available image at r, c.

        d: format dict
        """
        if self.get_w(r, c):
            a = Layout.get_placement(r, c, d)
            n = a[ForFormat.IMAGE_INDEX]

            if n == ForFormat.NONE or not Layout.get_prop_opacity(r, c, d):
                return 0

            if n == ForFormat.NEXT:
                if Images.image_count > Images.next_x:
                    return 1

                else:
                    return 0
            if n in Images.format_img_list:
                return 1
