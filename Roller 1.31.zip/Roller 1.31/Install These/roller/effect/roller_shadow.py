#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import OptionKey, SessionKey
from roller_effect import Effect
from roller_fu import Lay, Sel
import gimpfu as fu


class Shadow(Effect):
    """
    Creates a shadow layer.

    Used by shadow effects.
    """

    def __init__(self, k, stat, q=None, inlay=0):
        """
        k: effect name
        stat: Stat
        q: layer tuple
            layers that cast shadow as a unit
        inlay: flag: invert selection when true
        """
        self.name = k
        self.inlay = inlay
        d = stat.session[k]
        Effect.__init__(self, d, stat, q=q, layer_key=k)

    def do(self, d):
        """
        Draws a shadow.

        Is part of an RenderHub class template.

        d: sub-session dict
        """
        # Use a selection so the shadow doesn't appear below the image:
        ok = OptionKey
        j = self.stat.render
        m = self.inlay
        q1 = []
        grp = self.create_shadow_unit(self.caster, q1)

        if m:
            # inlay-type shadow:
            d[ok.OFFSET_X] = d[ok.OFFSET_Y] = 0

        else:
            grp1 = Lay.selectable(j, grp, d)
            Lay.bury(j, grp)
            grp = grp1

        if ok.INHERIT_OPACITY not in d:
            d[ok.INHERIT_OPACITY] = 1

        z = self.active.layer = self.do_shadow(
            grp,
            d[ok.OFFSET_X],
            d[ok.OFFSET_Y],
            d[ok.BLUR],
            d[ok.SHADOW_COLOR],
            d[ok.INTENSITY],
            n=Lay.get_layer_name(self.name, self.stat),
            d=d,
            inlay=m)

        Lay.bury(j, grp)

        if z:
            a = len(self.active.format.layers) if not m else 0
            Lay.order(j, z, self.active.format, a=a)
            if self.name == SessionKey.KEY_LIGHT_SHADOW:
                z.mode = fu.LAYER_MODE_NORMAL

        [Lay.show(i) for i in q1]
        Sel.none(j)
