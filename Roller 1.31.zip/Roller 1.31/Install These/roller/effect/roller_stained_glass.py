#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import seed
from roller_base import Base
from roller_constant import OptionKey, SessionKey
from roller_border_line import BorderLine
from roller_effect import Effect
from roller_fu import Lay, Sel
import gimpfu as fu


class StainedGlass(Effect):
    """Create a frame with colorful transparent glass."""
    name = SessionKey.STAINED_GLASS
    width_low, width_high = 3, 20

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        self.stat = stat
        BorderLine(
                d,
                stat,
                name=SessionKey.STAINED_GLASS,
                filler=self.do,
                reflect=1
            )

    def do(self, d, z):
        """
        Called from BorderLine. Draws the glass layer.

        Is part of an RenderHub class template.

        d: sub-session dict
        z: process layer

        Return the glass layer.
        """
        return self.do_rotated_layer(d, self.do_job, z)

    def do_job(self, j, z, d):
        """
        Draw the glass panes.

        j: GIMP image
        z: layer
        d: sub-session dict

        Return the glass layer.
        """
        # A random sequence will reproduce itself given the same seed:
        seed(d[OptionKey.RANDOM_SEED])

        # vertical panes:
        x = y = x1 = y1 = 0
        w, h = d[OptionKey.PANE_WIDTH], d[OptionKey.PANE_HEIGHT]
        w1, h1 = j.width, j.height
        z.mode, z.opacity = fu.LAYER_MODE_NORMAL, 100.

        while x < w1:
            x1 = min(x1 + w, w1)

            Sel.rect(j, x, 0, x1 - x, h1, mode=fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, Base.rnd_col())
            x = x1

        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        # horizontal panes:
        while y < h1:
            y1 = min(y1 + h, h1)

            Sel.rect(j, 0, y, w1, y1 - y, mode=fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, Base.rnd_col())
            y = y1
        return Lay.merge(j, z)
