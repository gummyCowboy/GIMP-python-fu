#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget, WidgetKey
from roller_wig import Wig
import gtk
import pango


class RCombo(Wig):
    """Used by RComboBox and RComboBoxE."""

    def __init__(self, p, sub, **d):
        """
        p: callback function
        sub: sub-class
        d: widget dict
        """
        wk = WidgetKey
        w = ForWidget.MARGIN
        self.opt = []
        self.length = 0
        g = self.g = gtk.Alignment(0, 0, 1, 0)

        self.store = gtk.ListStore(str)
        g1 = d[wk.WIDGET] = sub(self.store)

        Wig.__init__(self, p, **d)

        # Limit the horizontal size of the the combobox:
        a = gtk.CellRendererText()
        a.props.ellipsize = pango.ELLIPSIZE_END

        g1.pack_start(a)
        g.add(g1)

        if sub == gtk.ComboBox:
            g1.add_attribute(a, 'text', 0)

        else:
            g1.child.set_editable(0)

        if wk.PAD_X in d:
            if d[wk.PAD_X]:
                # ‟pad_x” is (1..3):
                x = d[wk.PAD_X] - 1
                g.set_padding(0, (0, w / 2, w)[x], w, w)
        if wk.OPT in d:
            self.populate_list(d[wk.OPT])

    def get_value(self):
        """
        Return the activated item in the ComboBox.

        Is part of a UI widget template.
        """
        return self.opt[self.wig.get_active()]

    def populate_list(self, q):
        """
        Set the options for the ComboBox.

        q: iter of option strings
        """
        self.store.clear()

        self.opt = q

        for n in q:
            self.store.append([n])
        self.length = len(q)

    def set_value(self, n):
        """
        Set the ComboBox's display.

        Is part of a UI widget template.

        n: string to display
        """
        if n in self.opt:
            x = self.opt.index(n)

        else:
            x = 0
        self.wig.set_active(x)
