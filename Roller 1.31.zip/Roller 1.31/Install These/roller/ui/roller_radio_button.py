#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_wig import Wig
import gtk


class RRadioButton(Wig):
    """This is GTK RadioButton attached to an Alignment."""

    def __init__(self, p, n, k, group):
        """
        p: callback function
        n: label text
        k: widget key
        group: first widget in the button group or None
        x: index in group
        """
        g = self.g = gtk.Alignment(0, 0, 1, 0)
        g1 = gtk.RadioButton(group, n)

        Wig.__init__(self, p, key=k, widget=g1)

        g1.connect("toggled", self.callback)
        g.add(g1)

    def get_value(self):
        """
        Return the value of the RadioButton.

        Is part of a UI widget template.
        """
        return self.wig.get_active()

    def set_value(self, a):
        """
        Set the value of the RadioButton.

        Is part of a UI widget template.

        a: int (0..1)
        """
        self.wig.set_active(a)
