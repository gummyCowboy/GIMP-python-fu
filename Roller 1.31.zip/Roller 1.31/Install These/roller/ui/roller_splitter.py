#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_rbox import RBox
import gtk


class Splitter:
    """Create two equal sized vertical boxes on the x-axis."""

    def __init__(self, pad_x=0):
        """
        pad_x: index to padding (1..3)
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        self.g = self.box = gtk.HBox()

        if pad_x:
            g = self.g = gtk.Alignment(0, 0, 1, 0)
            x = pad_x - 1
            g.add(self.box)
            g.set_padding(w1, (w, 0, w1, w)[x], w, w)

        g1 = RBox(0, align=(0, 0, 1, 0))
        g2 = RBox(0, align=(0, 0, 1, 0))
        self.left, self.right = g1.box, g2.box
        g3 = self.left_a = g1.g
        g4 = self.right_a = g2.g
        if 1 < pad_x < 4:
            g3.set_padding(0, 0, 0, w1)
            g4.set_padding(0, 0, w1, 0)

    def both(self, g, g1):
        """
        Add two widgets to the Splitter.

        g: left widget
        g1: right widget
        """
        self.left.add(g)
        self.right.add(g1)

    def no_pack(self):
        """Add the two Alignment objects to the box."""
        self.box.add(self.left_a)
        self.box.add(self.right_a)

    def pack(self):
        """
        Make the the two VBoxes the same size.
        Add the same-sized VBoxes to the HBox.

        Called after all of the widgets have been added to the Splitter.
        """
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

        # Transform size:
        for g in (self.left_a, self.right_a):
            same_size.add_widget(g)

        g = reversed(same_size.get_widgets())
        [self.box.add(g1) for g1 in g]
