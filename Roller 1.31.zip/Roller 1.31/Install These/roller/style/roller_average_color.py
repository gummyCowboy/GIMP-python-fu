#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import OptionKey, SessionKey
from roller_fu import Lay
from roller_backdrop_style import BackdropStyle


class AverageColor(BackdropStyle):
    """Use pixelize to create an approximate average color."""
    name = SessionKey.AVERAGE_COLOR

    def __init__(self, d, stat):
        """
        Let RenderHub have the task.

        d: sub-session dict
        stat: Stat
        """
        BackdropStyle.__init__(self, d, stat)

    def do(self, d):
        """
        Use pixelize to average the image's color.

        Is part of an RenderHub class template.

        d: sub-session dict
        """
        j = self.stat.render
        z = Lay.clone(j, self.active.layer)
        z.mode, z.opacity = self.get_mode(d)

        pdb.plug_in_pixelize2(j, z, self.stat.width, self.stat.height)
        Lay.invert(z, d[OptionKey.INVERT])
        self.give_render_mask(z)
        self.active.layer = Lay.merge(j, z)
