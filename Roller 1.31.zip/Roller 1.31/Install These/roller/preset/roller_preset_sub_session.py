#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant import ForPreset, ForWidget, OptionKey, PresetKey
from roller_preset import Preset
from roller_session import Session


class PresetSubSession(Preset):
    """
    This is the Preset used in the Form group.

    Its preset is a sub-session dictionary type.
    """

    def __init__(self, d, stat):
        """
        Creates a sub-session preset.

        Sub-session presets are used by backdrop styles
        and 3D effects to populate a preset menu.

        d: preset dict
        """
        e = d[PresetKey.DEFAULT] = deepcopy(Session.default[d[OptionKey.NAME]])
        q = [
                [PresetKey.DEFAULT, e],
                [ForWidget.LAST_USED, stat.session[d[OptionKey.NAME]]]
            ]
        k = PresetKey.INTERNAL
        q1 = []

        if k in d:
            for q2 in d[k]:
                q.append(q2)

        for q2 in q:
            q1.append([ForPreset.INTERNAL_TYPE] + q2)

        d[k] = q1
        Preset.__init__(self, d)
