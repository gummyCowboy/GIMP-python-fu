#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, seed
from roller_constant_key import Layer as nk, Option as ok
from roller_constant_fu import Fu
from roller_one import Hat
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb
ta = Fu.ThresholdAlpha


class JaggedEdge:
    """Create a jagged edge around image material."""

    @staticmethod
    def do(one):
        """
        Do the Jagged Edge image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: tuple
            Jagged Edge layer, image layer
        """
        cat = Hat.cat
        d = one.d
        j = cat.render.image
        image_layer = one.image_layer
        z = Lay.clone(image_layer)

        Lay.apply_mask(z)

        z1 = Lay.clone(z)

        seed(d[ok.RANDOM_SEED])
        Sel.item(z)
        pdb.gimp_selection_shrink(j, max(d[ok.AMPLITUDE] + 1, 6))
        Sel.invert_clear(z)
        Lay.hide(image_layer)

        for x in range(4):
            a = randint(0, 1)
            pdb.plug_in_shift(j, z, randint(1, d[ok.AMPLITUDE]), a)
            pdb.plug_in_shift(j, z, randint(1, d[ok.AMPLITUDE]), int(not a))

        pdb.plug_in_oilify(j, z, d[ok.SMOOTHNESS], Fu.Oilify.RGB_MODE)
        pdb.plug_in_threshold_alpha(j, z, ta.THRESHOLD_ALL)

        # Transfer the alpha to make a Jagged Edge:
        Sel.item(z)

        Sel.invert_clear(z1)
        pdb.gimp_image_remove_layer(j, z)

        one.shadow_layer = [z1]
        z1.name = Lay.name(z1.parent, one.k)

        cat.register_layer((one.model_name, nk.IMAGE), z1)
        return z1
