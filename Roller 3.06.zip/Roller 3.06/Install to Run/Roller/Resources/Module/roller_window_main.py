#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Image as fi, Widget as fw
from roller_constant_key import (
    Group as gk,
    Option as ok,
    Pickle as pc,
    Step as sk,
    Widget as wk,
    Window as wi
)
from roller_model_image import Image
from roller_one import Comm, Hat, OZ
from roller_one_fu import Sel
from roller_option_preset import Preset, SuperPreset
from roller_port_main import PortMain
from roller_render_gradient_light import GradientLight
from roller_window import Window
from roller_window_save import RWSave
import gimpfu as fu
import gtk
import os

pdb = fu.pdb
DONE = 1
IE = ok.IMAGE_EFFECT


def verify_preset_folder():
    """
    The external directory is where preset files are stored.

    Return: flag
        It is true if the directory is verified.
    """
    go = False

    try:
        n = Hat.cat.preset_folder = os.path.join(
            Hat.cat.roller_path,
            u"Preset"
        )
        go = OZ.ensure_dir(n)[-1]

    except Exception as ex:
        Comm.show_err(ex)
        Comm.show_err(
            "The operating system isn't compatible with Roller."
        )
    return go


class WindowMain(Window):
    """Is the plug-in's main window."""

    def __init__(self):
        """Has the GTK event loop."""
        if verify_preset_folder():
            self._load_window_pose()
            Image.make_image_list()

            self.canceled = True
            cat = Hat.cat

            cat.option.create_frame_list()

            # Preserve the selection and active layer of open images:
            selections = []
            active_layer = []

            for _, j in Image.roller_image.items():
                active_layer.append((j.j, j.j.active_layer))
                if Sel.is_sel(j.j):
                    sel = pdb.gimp_selection_save(j.j)
                    selections.append((j.j, sel))
                    pdb.gimp_selection_none(j.j)

            # Prepare Port:
            d = {wk.WINDOW_KEY: wi.MAIN}

            Window.__init__(self, d)

            d = {
                wk.ON_CANCEL: self.cancel,
                wk.ON_ACCEPT: self.accept_main,
                wk.WIN: self
            }
            self.port = PortMain(d)

            self.win.show_all()
            gtk.main()

            # Close any opened images:
            for k, q in Image.opened_images.items():
                if k not in Image.image_names:
                    pdb.gimp_image_delete(q[fi.IMAGE_INDEX].j)

            # Close the GradientLight image:
            if GradientLight.image:
                pdb.gimp_image_delete(GradientLight.image)

            # Restore the selection of open images:
            for i in selections:
                j, sel = i[0], i[1]

                Sel.load(j, sel)
                if pdb.gimp_item_is_valid(sel):
                    pdb.gimp_image_remove_channel(j, sel)

            # Restore the active layer of open images:
            for i in active_layer:
                if i[1]:
                    i[0].active_layer = i[1]

            if cat.render.has_image:
                if not self.canceled:
                    WindowMain.remove_unused_group()
                    WindowMain.remove_unused_layer(cat.render.image)
                WindowMain.remove_unused_image_gradients()
            Image.image_undo_end()

    def _load_window_pose(self):
        """Load the window position dictionary if it exists."""
        cat = Hat.cat
        n = self._window_pose_file = OZ.get_preset_path(
            u"Window Position",
            "",
            cat.preset_folder
        )
        d = OZ.pickle_load({pc.FILE: n, pc.SHOW_ERROR: False})

        if d:
            cat.window_pose = deepcopy(d)
            self._last_window_pose = deepcopy(d)
        else:
            self._last_window_pose = {}

    @staticmethod
    def _render(steps):
        """
        Render the form.

        steps: list
            of render steps
            k, v: path, dict of option group value
        """
        cat = Hat.cat

        cat.viewer.do(steps)
        if cat.render.has_image:
            j = cat.render.image
            z = j.layers[-1]
            z.name = z.name.split(":")[0] + " Finish"
            z1 = cat.plan.plan_group

            if z1:
                z1.name = z1.name.split(":")[0]

            j.active_layer = z
            pdb.gimp_selection_none(j)

    def _write_last_used(self, d, steps, last_session):
        """
        Write the last used dictionaries in the session.

        d: dict
            of preset
        """
        cat = Hat.cat
        go = True
        e = SuperPreset.translate_to_name(d)

        if e != last_session:
            go = self._write_option(e, gk.PRESET_STEPS)

        d1 = cat.group_dict
        q = set()

        # Before saving the step presets,
        # create a set of keys because
        # many preset-types are repeated:
        for step in steps:
            # Presets are distinguished by their group key:
            if step in d1:
                group = d1[step]
                if group.group_type == Preset and group.preset:
                    q.add(group.group_key)

        # Write a last-used preset for the collected set
        # of presets that was used in the render.
        # Reverse the order so that the last-used is correct:
        for step in reversed(steps):
            if go:
                # Presets are distinguished by their group key:
                if step in d1:
                    k = d1[step].group_key
                    if k in q:
                        q.remove(k)
                        go = self._write_option(d[step], k)

        if go:
            if cat.window_pose != self._last_window_pose:
                OZ.pickle_dump({
                    pc.DATA: cat.window_pose,
                    pc.FILE: self._window_pose_file
                })

    def _write_option(self, d, group_key):
        """
        Write a last-used file for a preset.

        d: dict
            Has last-used options.

        group_key: string
            option key/name
            Use to name file and its folder

        Return: bool
            Is true if the file was saved.
        """
        return RWSave.write(
            self.win,
            d,
            group_key,
            fw.LAST_USED,
            overwrite=True
        )

    def accept_main(self, steps, last_session):
        """
        Begin a render.

        steps: list
            of steps for the render

        last_session: dict
            of session

        Return: true
            The key-press was processed.
        """
        self.canceled = False
        cat = Hat.cat

        if cat.group_dict[sk.GLOBAL].d[ok.DELETE_PLANS].get_value():
            cat.plan.delete()

        else:
            cat.plan.delete_backdrop()

        WindowMain._render(steps)
        self._write_last_used(
            SuperPreset.get_steps(sk.STEPS,  with_list=False)[0],
            steps,
            last_session
        )

        # Wait for the render to finish so that the options can be collected:
        self.close()

        # Clean-up:
        cat.del_long_term_sel()

        # for GTK:
        return DONE

    @staticmethod
    def remove_unused_layer(z):
        """
        Remove any layers without effect.
        Is recursive.

        z: layer or GIMP image
            Has sub-layers.
        """
        for i in z.layers:
            if not i.visible and not pdb.gimp_item_is_group(i):
                pdb.gimp_image_remove_layer(i.image, i)

            elif not i.opacity:
                pdb.gimp_image_remove_layer(i.image, i)
            elif pdb.gimp_item_is_group(i):
                # recursive:
                WindowMain.remove_unused_layer(i)

    @staticmethod
    def remove_unused_group():
        """Remove any group layers without any children."""
        cat = Hat.cat
        if cat.render.has_image:
            j = Hat.cat.render.image
            if len(j.layers):
                for i in j.layers:
                    if pdb.gimp_item_is_group(i):
                        if not len(i.layers):
                            pdb.gimp_image_remove_layer(j, i)

    @staticmethod
    def remove_unused_image_gradients():
        """
        Delete any image gradients that were
        created but not saved with the render:
        """
        for grad in Hat.cat.image_gradients_created:
            if grad != Hat.cat.image_gradient_used:
                pdb.gimp_gradient_delete(grad)
