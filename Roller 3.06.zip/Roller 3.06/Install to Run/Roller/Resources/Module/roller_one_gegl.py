#!/usr/bin/env python
# -*- coding: utf-8 -*-
from ctypes import c_char_p, c_void_p, CDLL, POINTER, Structure, util
from gimpfu import pdb
import sys

CUBISM = 'cubism tile-size=%f tile-saturation=%f seed=%d'
EDGE = 'edge algorithm=sobel amount=2. border=2'
EMBOSS = 'emboss azimuth=%d elevation=%d depth=%d'
ENGRAVE = 'engrave row-height=%d'
G_BLUR = 'gaussian-blur std-dev-x=%f std-dev-y=%f'
MEDIAN_BLUR = 'median-blur radius=%d percentile=%f alpha-percentile=50.'
NOISE_CIE_LCH = \
    'noise-cie-lch holdness=%d lightness-distance=%f ' \
    'chroma-distance=%f hue-distance=%f seed=%d'

NOISE_RGB = 'noise-rgb red=%f, blue=%f, green=%f, alpha=%f, seed=%d'
NOISE_SLUR = 'noise-slur pct-random=%f, repeat=%d, seed=%d'
OILIFY = 'oilify mask-radius=%d exponent=%d'
SATURATION = 'saturation scale=%f'
SHIFT = 'shift direction=%s shift=%d seed=%d'
SPREAD = 'noise-spread amount-x=%d amount-y=%d seed=%d'
UNSHARP_MASK = 'unsharp-mask std-dev=%f scale=%f threshold=%f'
VIDEO_DEGRADE = 'video-degradation pattern=%s'
WAVES = 'waves amplitude=%f aspect=%f period=%f'


class Gegl:
    """
    Use as a common ground for essential program variables.

    Has minimal dependencies so it won't create a circular import problem.
    """
    # DLL:
    gimp_library = None

    @staticmethod
    def _do_gegl(z, n):
        """
        Perform a GEGL function.

        z: drawable
            work-in-progress

        n: string
            of GEGL graph
        """
        class GeglBuffer(Structure):
            pass

        # drawable id:
        _id = z.ID

        go = False
        gegl = Gegl.load_library('libgegl-0.4')
        gimp = Gegl.gimp_library

        if gegl:
            go = gegl.gegl_init(None, None)
        if go:
            gimp.gimp_drawable_get_shadow_buffer.restype = POINTER(GeglBuffer)
            gimp.gimp_drawable_get_buffer.restype = POINTER(GeglBuffer)

            is_sel, x, y, w, h = pdb.gimp_drawable_mask_intersect(z)
            args = [b"string", c_char_p(n), c_void_p()]
            if is_sel:
                source = gimp.gimp_drawable_get_buffer(_id)
                target = gimp.gimp_drawable_get_shadow_buffer(_id)
                if gegl.gegl_render_op(source, target, 'gegl:gegl', *args):
                    gegl.gegl_buffer_flush(target)
                    gimp.gimp_drawable_merge_shadow(_id, PushUndo=True)
                    gimp.gimp_drawable_update(_id, x, y, w, h)
                    gimp.gimp_displays_flush()

    @staticmethod
    def blur(z, f):
        """
        Do the GEGL gaussian blur.

        z: layer
            work-in-progress

        f: float
            standard deviation for x and y
        """
        f = min(float(f), 1500.)
        Gegl._do_gegl(z, G_BLUR % (f, f))

    @staticmethod
    def color_to_grey(z):
        """
        Do the GEGL color to grey function.

        z: layer
            work-in-progress
        """
        Gegl._do_gegl(z, 'c2g')

    @staticmethod
    def cubism(z, size=20., amount=2., seed=0):
        """
        Do the GEGL cubism function.

        z: layer
            work-in-progress

        size: float
            of tile
            in .0 to 256.

        amount: float
            saturation of tiles
            in .0 to 10.

        seed: int
            to change output
        """
        Gegl._do_gegl(z, CUBISM % (size, amount, seed))

    @staticmethod
    def edge(z):
        """
        Do the GEGL sobel edge.

        z: layer
            work-in-progress
        """
        Gegl._do_gegl(z, EDGE)

    @staticmethod
    def emboss(z, azimuth, elevation, depth):
        """
        Do the GEGL emboss.

        z: layer
            work-in-progress

        azimuth: int
            for emboss

        elevation: int
            higher is lighter

        depth: int
            for emboss
        """
        Gegl._do_gegl(z, EMBOSS % (azimuth, elevation, depth))

    @staticmethod
    def engrave(z, height):
        """
        Simulate an antique engraving.

        Reference:
        gegl.org/operations/gegl-engrave.html

        z: layer
            to be transformed

        height: int
            resolution in pixels
        """
        Gegl._do_gegl(z, ENGRAVE % (height,))

    @staticmethod
    def image_gradient(z):
        """
        Do the GEGL image gradient function.

        z: layer
            work-in-progress
        """
        Gegl._do_gegl(z, 'image-gradient')

    @staticmethod
    def load_library(library_name):
        """
        Load library for GEGL command function.
        The library name differs with the operating system.

        library_name: string
            OS dependent library name

        Return: library or None
            as referenced by 'library_name'
        """
        n = sys.platform

        if n == 'linux' or n == 'linux2':
            library_name = library_name + '.so.0'

        elif n == 'win32':
            # Search for the library name from
            # the PATH environment variable:
            library_name = util.find_library(library_name + '-0')

        else:
            library_name = ""
        if library_name:
            # Load the dynamic link library:
            return CDLL(library_name)

    @staticmethod
    def median_blur(z, radius, percentile):
        """
        Do the GEGL Median Blur function.

        Blur resulting from computing the median
        color in the neighborhood of each pixel.

        Reference:
        gegl.org/operations/gegl-median-blur.html

        z: layer
            target of blur

        radius: int
            of blur influence
            neighborhood radius
            A negative value will calculate with inverted percentiles.

        percentile: float
            neighborhood color percentile
        """
        Gegl._do_gegl(z, MEDIAN_BLUR % (radius, percentile))

    @staticmethod
    def noise_cie_lch(z, dull=1, light=19., chroma=100., hue=0., seed=1):
        """
        Do the GEGL CIE LCH Noise.

        z: layer
            work-in-progress

        dull: float
            lower value adds more noise
            in 1 to 8

        light: float
            higher value increases lightness
            in .0 to 100.

        chroma: float
            higher value adds saturation
            in .0 to 100.

        hue: float
            shifts the hue the noise
            in .0 to 180.
            180 is desaturated

        seed: int
            Change output.
        """
        Gegl._do_gegl(z, NOISE_CIE_LCH % (dull, light, chroma, hue, seed))

    @staticmethod
    def noise_rgb(z, red, green, blue, alpha, seed):
        """
        Distort colors by random amounts.

        red, green, blue, alpha: float
            color component

        seed: int
            of noise graph
        """
        Gegl._do_gegl(z, NOISE_RGB % (red, green, blue, alpha, seed))

    @staticmethod
    def noise_slur(z, percent, repeat, seed):
        """
        Randomly slide some pixels downward (similar to melting).

        percent: float
            from .0 to 100.
            randomization

        repeat: int
            from 1 to 100
            pattern

        seed: int
            for random generator
        """
        Gegl._do_gegl(z, NOISE_SLUR % (percent, repeat, seed))

    @staticmethod
    def oilify(z, radius, exponent):
        """
        Emulate an oil painting.

        Reference:
        gegl.org/operations/gegl-oilify.html

        radius: int
            Radius of circle around pixel, can also be
            scaled per pixel by a buffer on the aux pad.

        exponent: int
            Exponent for processing; controls smoothness -
            can be scaled per pixel with a buffer on the aux2 pad.
        """
        Gegl._do_gegl(z, OILIFY % (radius, exponent))

    @staticmethod
    def saturation(z, amount):
        """
        Do the GEGL unsharp mask.

        z: layer
            work-in-progress

        amount: float
            saturation shift
        """
        Gegl._do_gegl(z, SATURATION % (amount,))

    @staticmethod
    def shift(z, direction, amount, seed):
        """
        Do the GEGL unsharp mask.

        z: layer
            work-in-progress

        direction: string
            horizontal or vertical

        amount: int
            length of shift
            in 0 to 200

        seed: int
            Change output.
        """
        Gegl._do_gegl(z, SHIFT % (direction, amount, seed))

    @staticmethod
    def spread(z, seed, amount_x=5, amount_y=5):
        """
        Move pixels around randomly.

        z: layer
            to receive spread

        seed: int
            random seed

        amount_x, amount_y: int
            vertical and horizontal spread
        """
        Gegl._do_gegl(z, SPREAD % (amount_x, amount_y, seed))

    @staticmethod
    def unsharp_mask(z, radius, amount, threshold):
        """
        Do the GEGL unsharp mask.

        z: layer
            work-in-progress

        radius: float
            span of effect

        amount: float
            as in strength

        threshold: float
            .0 is all, 1. is none?
        """
        Gegl._do_gegl(z, UNSHARP_MASK % (radius, amount, threshold))

    @staticmethod
    def video_degradation(z, pattern):
        """
        Do the GEGL video degradation function.

        Simulates the degradation of being on
        an old low-dotpitch RGB video monitor.

        Reference:
        gegl.org/operations/gegl-video-degradation.html

        z: layer
            to be transformed

        pattern: string
            'dots' is one option.
            as in the drop-down from the GIMP dialog
        """
        Gegl._do_gegl(z, VIDEO_DEGRADE % pattern)

    @staticmethod
    def waterpixels(z, size=32):
        """
        Superpixels based on the watershed transformation.

        size: int
            of superpixel
        """
        Gegl._do_gegl(z, 'waterpixels size=%d' % size)

    @staticmethod
    def waves(z, amplitude, aspect, period):
        """
        Distort the image with waves.

        Reference:
        gegl.org/operations/gegl-waves.html

        z: layer
            to be transformed

        amplitude: float
            amplitude of the ripple

        aspect: float
            aspect ratio

        period: float
            wavelength of the ripple
        """
        Gegl._do_gegl(z, WAVES % (amplitude, aspect, period))
