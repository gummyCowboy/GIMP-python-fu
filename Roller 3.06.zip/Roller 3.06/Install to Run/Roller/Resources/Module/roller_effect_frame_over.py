#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Model as mo,
    Frame as fo,
    Gradient as fg,
    Plan as fy
)
from roller_constant_key import Group as gk, Model as md, Option as ok
from roller_constant_fu import Fu
from roller_model_image import Image
from roller_one import Comm, Hat
from roller_one_fu import Lay, Mage, Sel
from roller_option_preset import Preset
from roller_render_hub import RenderHub
import gimpfu as fu
import os

gf = Fu.GradientFill
pdb = fu.pdb
SEP = os.path.sep


def do_color(z, d, _):
    """
    Color the frame with a single color.

    z: layer
        Is frame.

    d: dict
        Has options.

    _: dict
        image index
        unused

    Return: layer
        with frame material
    """
    Sel.item(z)
    Sel.fill(z, d[ok.COLOR])
    return z


def do_gradient(z, d, _):
    """
    Color the frame with a gradient.

    z: layer
        Is frame.

    d: dict
        Has options.

    _: dict
        image index
        unused

    Return: layer
        with frame material
    """
    def draw_gradient(_start_x, _end_x, _start_y, _end_y):
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(d[ok.GRADIENT_TYPE]),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            _start_x, _start_y,
            _end_x, _end_y
        )

    j = z.image
    gradient = d[ok.GRADIENT]

    if gradient not in Hat.cat.gradient_list:
        Comm.info_msg(
            mo.MISSING_ITEM.format("Frame Mold", "gradient", gradient)
        )

    else:
        RenderHub.set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_gradient(gradient)
        pdb.gimp_context_set_gradient_blend_color_space(
            fu.GRADIENT_BLEND_RGB_PERCEPTUAL
        )
        pdb.gimp_context_set_gradient_reverse(0)
        Sel.item(z)

        is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        w, h = x1 - x, y1 - y
        if is_sel:
            sel = Hat.cat.save_short_term_sel()
            start_x, end_x, start_y, end_y =\
                RenderHub.get_gradient_points(
                    d[ok.GRADIENT_ANGLE],
                    x, y,
                    w, h
                )

            Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
            draw_gradient(start_x, end_x, start_y, end_y)
            Lay.blur(z, d[ok.BLUR])
            Sel.isolate(z, sel)
    return z


def do_grid(one):
    """
    Process a grid.

    one: One
        Has variables.

    return: layer
        with frame material
    """
    row, column = one.grid.division

    for r in range(row):
        for c in range(column):
            make_frame(one, r, c)


def do_image(z, d, image_index):
    """
    Color the frame with a plasma.

    z: layer
        Is frame.

    d: dict
        Has options.

    Return: layer
        with frame material
    """
    j = z.image
    e = d[ok.IMAGE]
    j1 = Image.get_image(e, image_index)

    if j1:
        j1 = j1.j

        Sel.item(z)

        sel = Hat.cat.save_short_term_sel()

        if sel:
            Mage.copy_all(j1)
            Image.close_image(j1)

            j1 = pdb.gimp_edit_paste_as_new_image()

            Sel.load(j, sel)

            _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

            Mage.shape(j1, x1 - x, y1 - y)
            pdb.gimp_selection_none(j)

            z1 = Lay.paste(z)

            pdb.gimp_layer_set_offsets(z1, x, y)
            Lay.blur(z1, d[ok.BLUR])
            Sel.isolate(z1, sel)

            n = z.name

            pdb.gimp_image_remove_layer(j, z)

            z1.name = n
            return z1
    return z


def do_plasma(z, d, _):
    """
    Color the frame with a plasma.

    z: layer
        Is frame.

    d: dict
        Has options.

    _: dict
        image index
        unused

    Return: layer
        with frame material
    """
    j = z.image

    Sel.item(z)

    sel = Hat.cat.save_short_term_sel()

    if sel:
        pdb.gimp_selection_none(j)
        pdb.plug_in_plasma(
            j, z,
            d[ok.RANDOM_SEED],
            Fu.Plasma.LOWEST_TURBULENCE
        )
        Sel.load(j, sel)
        Sel.invert_clear(z, keep_sel=True)
        Lay.blur(z, d[ok.BLUR])
    return z


def make_frame(one, r, c):
    """
    Make a frame.

    one: One
        Has variables.

    r, c: int
        cell index
    """
    cat = Hat.cat
    j = cat.render.image
    d = one.d
    parent = one.parent

    cat.join_selection(one.model_name, r, c)
    if Sel.is_sel(j):
        sel = cat.save_short_term_sel()

        # Is there a frame layer?
        if not one.frame_layer:
            # Is the image layer located?

            # Add the group layer above the image layer:
            group = Lay.group(j, Lay.name(parent, one.k), parent=parent)
            one.frame_layer = Lay.add(j, "Frame", parent=group)

        # Has the frame image been loaded?
        if not one.frame_image:
            n = "{}{}{}.png".format(cat.frame_path, SEP, d[ok.FRAME])
            e = Preset.get_default(gk.IMAGE_CHOICE)
            e[ok.FILE] = n
            e[ok.IMAGE_SOURCE] = ok.FILE

            # Get the GIMP image:
            j1 = Image.get_image(e, one.image_index)
            if j1:
                one.frame_image = j1.j
        if one.frame_image:
            Mage.copy_all(one.frame_image)

            j1 = pdb.gimp_edit_paste_as_new_image()

            Sel.load(j, sel)

            _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

            Mage.shape(j1, x1 - x, y1 - y)
            pdb.gimp_selection_none(j)

            z = Lay.paste(one.frame_layer)

            pdb.gimp_layer_set_offsets(z, x, y)
            Sel.load(j, sel)
            Sel.invert_clear(z)


class FrameOver:
    """Create a frame-mask overlay on each image cell."""

    @staticmethod
    def do(one):
        """
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer or None
            with Frame Over
        """
        d = one.d
        if d[ok.OPACITY] and d[ok.FRAME] != "None":
            one.frame_layer = one.frame_image = None

            if one.context == md.TABLE:
                do_grid(one)

            else:
                r = fy.CUSTOM_CELL
                make_frame(one, r, r)

            # Is there a frame layer?
            z = one.frame_layer
            if z:
                e = {
                    fo.COLOR: do_color,
                    fo.GRADIENT: do_gradient,
                    fo.IMAGE: do_image,
                    fo.PLASMA: do_plasma
                }

                # Create the combined frame layer:
                z = Lay.merge_group(z.parent)

                n = d[ok.FRAME_STYLE]

                if n in e:
                    z = e[n](z, d, one.image_index)

                z = RenderHub.bump(z, d[ok.BUMP])
                z.mode, z.opacity = RenderHub.get_mode(d)

                if d[ok.BLUR_BEHIND]:
                    if RenderHub.blur_behind_frame(z, d[ok.BLUR_BEHIND]):
                        z = Lay.merge(z)

                one.shadow_layer = [one.image_layer]
                return z
