#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_color_grid import ColorGrid
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu

cs = Fu.ColorSelect
de = Fu.Despeckle
ed = Fu.Edge
em = Fu.Emboss
pdb = fu.pdb
rn = Fu.RGBNoise


def noise(z, color, light_angle, elevation):
    """
    Add noise to the colored part grid.

    z: layer
        work-in-progress

    color: tuple
        RGB
    """
    j = z.image

    # Create a selection from black pixels:
    pdb.gimp_by_color_select(
        z,
        color,
        cs.THRESHOLD_0,
        fu.CHANNEL_OP_REPLACE,
        cs.YES_ANTIALIAS,
        cs.NO_FEATHER,
        cs.FEATHER_RADIUS_0,
        cs.NO_SAMPLE_MERGED
    )

    # Clear the black grid:
    Lay.clear_sel(z)

    pdb.plug_in_rgb_noise(
        j, z,
        rn.YES_INDEPENDENT,
        rn.NO_CORRELATED,
        rn.NOISE_TENTH,
        rn.NOISE_TENTH,
        rn.NOISE_TENTH,
        rn.NOISE_ZERO
    )
    pdb.plug_in_emboss(
        j, z,
        light_angle,
        elevation,
        em.DEPTH_3,
        em.BUMP
    )
    pdb.plug_in_despeckle(
        j, z,
        de.RADIUS_4,
        de.ADAPTIVE,
        de.BLACK_7,
        de.WHITE_248
    )
    pdb.plug_in_despeckle(
        j, z,
        de.RADIUS_30,
        de.ADAPTIVE,
        de.BLACK_7,
        de.WHITE_248
    )


class DarkFort:
    """Create a dark texture that resembles a brick wall."""

    @staticmethod
    def do(one):
        """
        Do the Dark Fort backdrop style.
        Is backdrop-style template function.

        one: One
            Has variables.

        Return: layer or None
            with Dark Fort
        """
        cat = Hat.cat
        j = cat.render.image
        d = one.d
        if d[ok.OPACITY]:
            group = Lay.group(j, one.k)
            z = Lay.add(j, one.k)

            pdb.gimp_image_reorder_item(j, z, group, 0)

            light_angle = cat.light_angle
            elevation = cat.elevation
            d[ok.COLOR_1] = 0, 0, 0
            d[ok.COLOR_2] = 255, 255, 255
            d[ok.BUMP] = {ok.BUMP_TYPE: "None"}
            grid = ColorGrid.draw_color_grid(z, d)
            z = Lay.clone(grid)

            Sel.color(z, (0, 0, 0))

            sel = cat.save_short_term_sel()

            pdb.gimp_selection_none(j)
            noise(z, (0, 0, 0), light_angle, elevation)

            z1 = Lay.clone(z)
            z1.mode = fu.LAYER_MODE_HSV_VALUE

            Lay.flip(z1, horizontal=1)
            pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
            z1 = Lay.clone(z)
            z1.mode = fu.LAYER_MODE_DIFFERENCE

            pdb.plug_in_plasma(
                j, z,
                d[ok.RANDOM_SEED],
                Fu.Plasma.LOWEST_TURBULENCE
            )
            z = Lay.clone(z)

            Sel.load(j, sel)
            Lay.blur(z, 1)
            Gegl.unsharp_mask(z, 2., .5, 0.)
            pdb.gimp_selection_none(j)

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            pdb.gimp_drawable_desaturate(z, fu.DESATURATE_LUMINANCE)
            pdb.plug_in_emboss(
                j, z,
                light_angle,
                elevation,
                em.DEPTH_3,
                em.BUMP
            )

            z = Lay.merge_group(group)
            z.mode, z.opacity = RenderHub.get_mode(d)

            Lay.clone(one.z)
            return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
