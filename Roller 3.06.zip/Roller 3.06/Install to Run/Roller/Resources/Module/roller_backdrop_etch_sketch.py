#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
import gimpfu as fu

pdb = fu.pdb

em = Fu.Emboss
np = Fu.NewsPrint
FOUR_COORDINATES = 4


def do_step_1(z):
    """
    Increase the strength of the line.

    z: layer
        Has line.
    """
    j = z.image
    group = Lay.group(j, "Step 1", layer=z)
    z1 = Lay.clone(z)
    z1.mode = fu.LAYER_MODE_OVERLAY

    pdb.gimp_drawable_invert(z, 0)
    return Lay.merge_group(group)


def do_step_2(z, z1, d):
    """
    Apply news print to line.

    z: layer
        Has line.

    z1: layer
        copy of the original layer

    d: dict
        Has options.
    """
    f = Hat.cat.light_angle
    while f < 0:
        f += 360

    j = z.image
    group = Lay.group(j, "Step 2", layer=z1)

    pdb.gimp_image_reorder_item(j, z, group, 0)

    z.mode = fu.LAYER_MODE_DARKEN_ONLY
    _type = bs.NEWS_TYPE.index(d[ok.SKETCH_TEXTURE])

    pdb.plug_in_newsprint(
        j, z,
        d[ok.CELL_SIZE],
        np.RGB,
        np.BLACK_100,
        f,
        _type,
        f,
        _type,
        f,
        _type,
        f,
        _type,
        np.SAMPLE_2
    )

    q = 0, 0, 0

    pdb.gimp_context_set_feather(0)
    pdb.gimp_context_set_sample_merged(0)
    pdb.gimp_context_set_sample_criterion(0)
    pdb.gimp_context_set_sample_threshold(.25)
    pdb.gimp_context_set_sample_transparent(1)
    pdb.gimp_image_select_color(j, fu.CHANNEL_OP_REPLACE, z1, q)
    Lay.clear_sel(z)
    Lay.blur(z1, 500)
    pdb.gimp_curves_spline(
        z1,
        fu.HISTOGRAM_VALUE,
        FOUR_COORDINATES,
        [0, 100, 255, 155]
    )

    z.opacity = d[ok.OPACITY]
    return Lay.merge_group(group)


def do_step_3(z, d):
    """
    Do invert and / or emboss.

    z: layer
        Has line.

    d: dict
        Has options.

    elevation: float
        for emboss
    """
    j = z.image
    group = Lay.group(j, "Step 3", layer=z)

    if d[ok.INVERT]:
        pdb.gimp_drawable_invert(z, 0)

    if d[ok.EMBOSS]:
        z1 = Lay.clone(z)
        z1.mode = fu.LAYER_MODE_HARDLIGHT
        pdb.plug_in_emboss(
            j, z1,
            Hat.cat.light_angle,
            Hat.cat.elevation,
            em.DEPTH_1,
            em.EMBOSS
        )
    return Lay.merge_group(group)


class EtchSketch:
    """Use edge and newsprint to create a broken line style."""

    @staticmethod
    def do(one):
        """
        Create a Etch Sketch backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with Etch Sketch
        """
        d = one.d
        if Lay.has_pixel(one.z) and d[ok.OPACITY]:
            z = Lay.clone(one.z)

            pdb.plug_in_edge(
                z.image, z,
                Fu.Edge.AMOUNT_1,
                Fu.Edge.NO_WRAP,
                Fu.Edge.SOBEL
            )

            z = do_step_1(z)
            z = do_step_2(z, Lay.clone(one.z), d)
            z = do_step_3(z, d)
            return z
