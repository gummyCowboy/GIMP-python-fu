#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import Comm, GroupId
from roller_one_fu import Sel
from roller_model_plan import Plan
from roller_option import Option
from roller_render_image import RenderImage
from roller_render_product import Product
from roller_render_view import View
import gimpfu as fu

pdb = fu.pdb

# Use to differentiate a mask selection from the other selections:
MASK_TYPE = 0


class Cat(object):
    """
    Use as a common ground for essential program variables.

    Has minimal dependencies so it won't create a circular import problem.
    """

    def __init__(self):
        """Initialize global and property variables."""

        # Use to track layers:
        # The key is (model name, layer key).
        # The value is a layer:
        self._layers = {}

        # alpha channels:
        self._long_term_sel = []

        # ImageRender image:
        self._render_image = None

        # Short-term selection:
        self._short_term_sel = []

        # Just do once:
        self.brush_list = sorted(pdb.gimp_brushes_get_list(None)[1])

        # Use to save caption stripe selections:
        self.caption_stripe_sel = {}

        # Just do once:
        self.font_list = sorted(pdb.gimp_fonts_get_list(None)[1])

        # Holds frame files:
        self.frame_path = ""

        # Just do once:
        self.gradient_list = sorted(pdb.gimp_gradients_get_list(None)[1])

        # option groups:
        self.group_dict = {}

        # GroupId is encodes grid and custom cell names:
        self.group_id = GroupId()

        # Use with ImageGradient to delete unused gradients:
        self.image_gradients_created = []

        # Use with ImageGradient to delete unused gradients:
        self.image_gradient_used = None

        # Use to remember the image file path:
        self.image_file_path = ""

        # Use to remember the image folder path:
        self.image_folder_path = ""

        # for blur behind image selection
        self.image_sel = {}

        # by Image Mask for image-effect:
        self.mask_sel = {}

        # Only one Option object is
        # needed through-out the program:
        self.option = Option()

        # Just do once:
        self.pattern_list = sorted(pdb.gimp_patterns_get_list(None)[1])

        # Use when drawing plans:
        self.plan = Plan()

        # blur-behind plaque selection
        self.plaque_sel = {}

        # the root folder for preset storage:
        self.preset_folder = None

        # Use this class instance to render:
        self.product = Product()

        # 'roller_path' is where are Roller
        # modules and presets are stored:
        self.roller_path = ""

        # Use to manage render preview:
        self.viewer = View()

        # window position dict:
        self.window_pose = {}

        #
        # render variables
        #
        # Set by the Globals group:
        self.elevation = .0
        self.is_close_file = False
        self.light_angle = .0

        # of Gradient Light
        # It's option dictionary:
        self.gradient_light_d = None

        # position in stack for inserting its layer:
        self.gradient_light_position = 0

        # of paths
        # Set by the Model group:
        self.model_list = []

    def _del_vectors(self):
        """Delete the render's vectors (paths)."""
        j = self.render.image
        for i in j.vectors:
            pdb.gimp_image_remove_vectors(j, i)

    def _save_dict_sel(self, d, k):
        """
        Save a selection. Remove older selection with the same identity.

        d: dict
            of selection

        n: string
            item name

        r, c: int
            cell index
        """
        sel = self._save_selection()

        if k in d:
            # Get rid of the old selection:
            channel = d[k]
            d.pop(k)
            if pdb.gimp_item_is_valid(channel):
                pdb.gimp_image_remove_channel(self.render.image, channel)
        if sel:
            d[k] = sel

    def _save_selection(self):
        """
        Save a copy of the selection to the alpha channel.

        Return the selection or None.
        """
        j = self.render.image

        # Would save nothing (a black mask) if that was case:
        if Sel.is_sel(j):
            self._long_term_sel.append(pdb.gimp_selection_save(j))
            return self._long_term_sel[-1]

    def del_channels(self, d):
        """
        Delete channels stored in a dict.

        d: dict
            original
        """
        j = self.render.image
        for i, channel in d.items():
            if pdb.gimp_item_is_valid(channel):
                pdb.gimp_image_remove_channel(j, channel)

    def del_long_term_sel(self):
        """Remove the collection of selections from GIMP."""
        j = self.render.image
        q = self._long_term_sel
        self.caption_stripe_sel = {}
        self.image_sel = {}
        self.mask_sel = {}
        self.plaque_sel = {}

        for channel in q:
            if pdb.gimp_item_is_valid(channel):
                pdb.gimp_image_remove_channel(j, channel)
        self._long_term_sel = []

    def del_short_term_sel(self):
        """
        Remove the collection of render selections from GIMP.
        Render selections are generated by a render or preview.
        """
        j = self.render.image
        q = self._short_term_sel

        self._del_vectors()

        for channel in q:
            if pdb.gimp_item_is_valid(channel):
                pdb.gimp_image_remove_channel(j, channel)
        self._short_term_sel = []

    def del_selections(self, d):
        """
        Delete the selections from a dictionary.

        d: dict
            of selections
        """
        j = self.render.image
        for k, channel in d.items():
            if pdb.gimp_item_is_valid(channel):
                pdb.gimp_image_remove_channel(j, channel)

    def get_caption_stripe_sel(self, n, r, c):
        """
        Get the image selection for a cell.

        n: string
            part of the selection id
            a z-list item name

        r, c: int
            row, column
            cell index

        Return: GIMP selection or None
            for cell-oriented image
        """
        k = r, n, c
        d = self.caption_stripe_sel
        return d[k] if k in d else None

    def get_image_sel(self, n, r, c):
        """
        Get the image selection for a cell.

        n: string
            part of the selection id
            a z-list item name

        r, c: int
            row, column
            cell index

        Return: GIMP selection or None
            for cell-oriented image
        """
        k = r, c, n
        d = self.image_sel
        return d[k] if k in d else None

    def get_layer(self, k):
        """
        Get a registered layer.

        k: tuple
            key to layer
            (model name, layer key)

        Return: layer or None
            the registered layer
        """
        d = self._layers
        return d[k] if k in d else None

    def get_mask_sel(self, n, r, c):
        """
        Get the mask selection for a cell.

        n: string
            part of the selection id
            a z-list item name (key)

        r, c: int
            row, column
            cell index

        Return: GIMP selection or None
            for cell-oriented mask
        """
        k = r, c, n, MASK_TYPE
        d = self.mask_sel
        return d[k] if k in d else None

    def get_plaque_sel(self, n, r, c):
        """
        Get the plaque selection for a cell.

        n: string
            part of the selection id
            a z-list item name (key)

        r, c: int
            row, column
            cell index

        Return: GIMP selection or None
            for cell-oriented plaque
        """
        k = n, r, c
        d = self.plaque_sel
        return d[k] if k in d else None

    def has_layer(self, k):
        """
        Determine if a layer is registered.

        k: tuple
            (model name, layer key)
        """
        return k in self._layers

    def is_caption_sel(self, n, r, c):
        """
        Determine if a cell has a caption stripe selection.

        n: string
            part of the selection id
            a z-list item name (key)

        r, c: int
            row, column
            cell index

        Return: bool
            Is true if the caption stripe selection exists.
        """
        return (r, n, c) in self.caption_stripe_sel

    def is_image_sel(self, n, r, c):
        """
        Determine if an image selection has been saved.

        n: string
            item name from a z-list

        r, c: int
            cell index
            or a custom cell enum
        """
        return (r, c, n) in self.image_sel

    def is_plaque_sel(self, n, r, c):
        """
        Determine if a cell has a plaque selection.

        n: string
            part of the selection id
            a z-list item name (key)

        r, c: int
            row, column
            cell index

        Return: bool
            Is true if the plaque selection exists.
        """
        return (n, r, c) in self.plaque_sel

    def join_selection(self, n, r, c):
        """
        Intersect and image and mask selection.

        n: string
            item name
            a model name

        r, c: int
            cell index

        Return: image Selection or None
            state of image
        """
        j = self.render.image
        sel = self.get_image_sel(n, r, c)

        pdb.gimp_selection_none(j)
        if sel:
            Sel.load(j, sel)
            sel1 = self.get_mask_sel(n, r, c)
            if sel1:
                Sel.load(j, sel1, option=fu.CHANNEL_OP_INTERSECT)

    def register_layer(self, k, z):
        """
        Store a reference to a layer.

        k: tuple
            (model name, layer key)

        z: layer
            of layer-key
        """
        self._layers[k] = z

    @property
    def render(self):
        """Get the image where the render is applied."""
        if self._render_image:
            return self._render_image
        else:
            self._render_image = RenderImage()
            return self._render_image

    @render.setter
    def render(self, *_):
        """Is an invalid access."""
        raise Cat.WriteError('render')

    def reset_dict(self):
        """Remove layer and selection registrations."""
        self._layers = {}
        self.caption_stripe_sel = {}
        self.image_sel = {}
        self.mask_sel = {}
        self.plaque_sel = {}

    def save_caption_stripe_sel(self, z, n, r, c):
        """
        Add a caption stripe selection to its dict.

        z: layer
            Has image.

        n: string
            item name
            from a z-list grid or custom cell

        r, c: int
            row, column
            cell index
        """
        Sel.item(z)
        self._save_dict_sel(self.caption_stripe_sel, (r, n, c))

    def save_image_sel(self, z, n, r, c):
        """
        Add an image selection to the image selection dict.

        z: layer
            Has image.

        n: string
            item name
            from a z-list grid or custom cell

        r, c: int
            row, column
            cell index
        """
        Sel.item(z)
        self._save_dict_sel(self.image_sel, (r, c, n))

    def save_mask_sel(self, n, r, c):
        """
        Add a mask selection to the mask selection dict.
        The mask selection is the current selection.

        n: string
            item name
            from a z-list grid or custom cell

        r, c: int
            row, column
            cell index
        """
        self._save_dict_sel(self.mask_sel, (r, c, n, MASK_TYPE))

    def save_plaque_sel(self, n, r, c):
        """
        Add a plaque selection to the plaque selection dict.

        n: string
            part of the selection id
            a z-list item name

        r, c: int
            row, column
            cell index
        """
        self._save_dict_sel(self.plaque_sel, (n, r, c))

    def save_short_term_sel(self):
        """
        Save a copy of the selection to the alpha channel.
        Is a selection that is to be removed after a plan or render view.

        Return: selection or None
            Is none if there is no selection.
        """
        j = self.render.image

        # Would save nothing (a black mask) if that was case:
        if Sel.is_sel(j):
            self._short_term_sel.append(pdb.gimp_selection_save(j))
            return self._short_term_sel[-1]

    def unregister_layer(self, z, key=None):
        """
        Remove a layer reference from the layer dict.

        z: layer
            to remove
        """
        d = self._layers

        if key:
            if key in d:
                d.pop(key)
        else:
            k, i = -1, -2

            for i, a in d.items():
                if a == z:
                    k = i
                    break
            if k == i:
                d.pop(k)

    class WriteError(Exception):
        """
        Use when a function attempts to write to a read-only property.
        """
        def __init__(self, n):
            """
            There was a write error.

            Spit out the variable name.

            n: string
                function name
            """
            self.value = "WriteError: Attempted to write to a read-only " \
                "property: Cat.{}.".format(n)
            Comm.info_msg(self.value)

        def __str__(self):
            """
            Return the string value of the error message.

            This an Exception template function.
            """
            return repr(self.value)
