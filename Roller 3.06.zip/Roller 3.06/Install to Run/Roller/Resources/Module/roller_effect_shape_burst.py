#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg, Plan as fy
from roller_constant_fu import Fu
from roller_constant_key import Model as md, Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
CUSTOM = fy.CUSTOM_CELL


def process_grid(j, z, one):
    """
    Do effect for each image in the cell grid.

    j: GIMP image
        Is render.

    z: layer
        to receive effect

    one: One
        Has options.
    """
    # Do one image at a time:
    d = one.grid.grid_d
    is_merge_cell = one.grid.is_merge_cell
    s = 1
    for r in range(one.r):
        for c in range(one.c):
            if is_merge_cell:
                s = d[ok.PER_CELL][r][c]

            # Is it a dependent cell?
            if s != (-1, -1):
                Hat.cat.join_selection(one.model_name, r, c)
                process_image(j, z, one)


def process_image(j, z, one):
    """
    Do the effect for an image.

    j: GIMP image
        Is render.

    z: layer
        to receive effect

    one: One
        Has options.
    """
    if Sel.is_sel(j):
        d = one.d

        Sel.grow(j, d[ok.FRAME_WIDTH], 1)

        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(d[ok.SHAPE_BURST]),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            (x1 + x) / 2, (y1 + y) / 2,
            x, y
        )


class ShapeBurst:
    """Create a border from a shape-burst type of gradient."""

    @staticmethod
    def do(one):
        """
        Do the image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer or None
            with frame
        """
        cat = Hat.cat
        j = cat.render.image
        d = one.d
        parent = one.parent
        group = Lay.group(j, Lay.name(parent, one.k), parent=parent)
        z = Lay.add(j, one.k, parent=group)

        RenderHub.set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_gradient(d[ok.GRADIENT])
        pdb.gimp_context_set_gradient_blend_color_space(
            fu.GRADIENT_BLEND_RGB_PERCEPTUAL
        )
        pdb.gimp_context_set_gradient_reverse(d[ok.REVERSE])

        if one.context == md.TABLE:
            process_grid(j, z, one)

        else:
            # custom cell:
            r = CUSTOM
            cat.join_selection(one.model_name, r, r)
            if Sel.is_sel(j):
                process_image(j, z, one)

        z = Lay.merge_group(group)

        pdb.gimp_selection_none(j)

        if d[ok.INVERT]:
            pdb.gimp_drawable_invert(z, 0)

        if d[ok.UNSHARP_AMOUNT] and d[ok.UNSHARP_RADIUS]:
            Gegl.unsharp_mask(z, d[ok.UNSHARP_RADIUS], d[ok.UNSHARP_AMOUNT], .0)
            Gegl.blur(z, .5)

        Lay.clear_image_sel(one.image_layer, z)

        z = GradientLight.apply_light(z, ok.OTHER_FRAME)

        if z:
            one.shadow_layer += [one.image_layer, z]
        return z
