#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk, Window as wi
from roller_port_light import PortLight
from roller_window import Window


class RWLight(Window):
    """Is a GTK dialog for setting Gradient Light influence."""
    def __init__(self, g):
        """
        Create a window.

        g: OptionButton
            Has values.
        """
        self.safe = g
        d = {
            wk.WIN: g.win.win,
            wk.WINDOW_KEY: wi.INFLUENCER,
            wk.WINDOW_TITLE: "Set Gradient Light Influence"
        }

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortLight(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()
