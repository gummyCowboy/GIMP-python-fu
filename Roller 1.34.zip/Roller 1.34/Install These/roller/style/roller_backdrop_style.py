#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import ForLayer, ForFill, OptionKey
from roller_render_hub import RenderHub
from roller_fu import Lay
from roller_mode import Mode
import gimpfu as fu


class BackdropStyle(RenderHub):
    """
    Is an intermediary for backdrop styles and RenderHub.

    Has common style functions.
    """

    def __init__(self, d, stat, layer_key=ForLayer.BACKDROP, active=None):
        """
        Rename the backdrop layer and pass the rod to RenderHub.

        RenderHub will delegate the job.

        d: sub-session dict
        stat: Stat
        layer_key: layer key
        active: layer
            the active layer
        """
        if layer_key == ForLayer.BACKDROP:
            Lay.get_backdrop_layer(stat.render).name = Lay.get_layer_name(
                self.name, stat)
        RenderHub.__init__(self, d, stat, layer_key, active=active)

    def finish_style(self, z):
        """
        Call when a backdrop style has completed.

        Set the active layer after taking its mask.

        z: layer
            the new active layer
        """
        self.give_render_mask(z)
        self.active.layer = Lay.merge(self.stat.render, z)

    @staticmethod
    def invert_color(q):
        """
        Return an inverted color.

        q: RGB
        """
        return tuple([255 - i for i in q])

    def set_fill_context(self, d):
        """
        Set the context for current fill-type operation.

        Call before a bucket fill operation.

        d: sub-session dict
        """
        pdb.gimp_context_set_sample_threshold(d[OptionKey.THRESHOLD])
        pdb.gimp_context_set_opacity(d[OptionKey.OPACITY])
        pdb.gimp_context_set_paint_mode(Mode.get_x(d[OptionKey.MODE]))
        pdb.gimp_context_set_sample_criterion(
            ForFill.CRITERIA_LIST.index(d[OptionKey.CRITERIA]))

    def shadow(
                self,
                z,
                blur=15.,
                op=130.,
                offset_x=0,
                offset_y=0,
                d=None,
                inlay=0):
        """
        z: layer
        blur: float
            shadow blur

        op: float
            shadow opacity

        offset_x: int
            shadow offset on x-axis (-, +)

        offset_y: int
            shadow offset on y-axis (-, +)

        d: inherit dict
            Has an INHERIT_OPACITY item. Needed
            when using the inlay option.

        inlay: flag
            If true, the shadow is an inlay type.

        Return the shadow.
        """
        x = Lay.offset(z, self.group)
        z = self.do_shadow(
                z,
                offset_x,
                offset_y,
                blur,
                (0, 0, 0),
                op,
                "",
                d=d,
                inlay=inlay)
        z.mode = fu.LAYER_MODE_NORMAL

        if inlay:
            x -= 1
        Lay.order(self.stat.render, z, self.group, a=x + 1)
        return z
