#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_backdrop_style import BackdropStyle
from roller_colored_grid import ColoredGrid
from roller_constant import (
        ForGradient,
        ForRender,
        OptionKey,
        SessionKey
    )

from roller_fu import Lay
from roller_gradient_fill import GradientFill


class MysteryGrate(BackdropStyle):
    """Has grate-like layers."""
    name = SessionKey.MYSTERY_GRATE
    column = 1

    def __init__(self, d, stat):
        """
        Start MysteryGrate.

        Is part of a RenderHub class template.

        d: sub-session dict
        stat: Stat
        """
        BackdropStyle.__init__(self, d, stat)

    def _do_1st_layer(self):
        """Create a diamond layer and a shadow."""
        ok = OptionKey

        Lay.add(self.stat.render, self.name, z=self.group)

        d, e = self.d2, self.e
        d[ok.ROW] = 1
        d[ok.COLUMN] = self.d1[ok.COLUMN_1]
        d[ok.COLOR_1] = (255, 255, 255)
        d[ok.COLOR_2] = (0, 0, 0)
        d[ok.MODE] = "Normal"
        d[ok.OPACITY] = 100
        d[ok.ROTATE] = 45

        ColoredGrid(
                d,
                self.stat,
                name=self.name,
                layer_key=self.name
            )

        z = Lay.get_active(self.stat.render)

        pdb.plug_in_colortoalpha(self.stat.render, z, (0, 0, 0))
        self.shadow(z)
        Lay.masked(z)

        e[ok.START_X] = e[ok.START_Y] = 0
        e[ok.END_X], e[ok.END_Y] = self.stat.width - 1, self.stat.height - 1
        self._do_gradient(z)

    def _do_2nd_layer(self):
        """the second layer"""
        ok = OptionKey
        d, e = self.d2, self.e

        Lay.add(self.stat.render, self.name, z=self.group)

        d[ok.COLOR_1] = (0, 0, 0)
        d[ok.COLOR_2] = (255, 255, 255)
        d[ok.COLUMN] = self.d1[ok.COLUMN_2]

        ColoredGrid(
                d,
                self.stat,
                name=self.name,
                layer_key=self.name
            )

        z = Lay.get_active(self.stat.render)

        pdb.plug_in_colortoalpha(self.stat.render, z, (0, 0, 0))
        self.shadow(z)
        Lay.masked(z)

        e[ok.END_X] = e[ok.END_Y] = 0
        e[ok.START_X], e[ok.START_Y] = (
            self.stat.width - 1, self.stat.height - 1)
        return self._do_gradient(z)

    def _do_3rd_layer(self, z):
        """z: layer"""
        z = Lay.clone(self.stat.render, z)

        Lay.flip(z, horz=1)
        self.shadow(z)
        Lay.masked(z)

    def _do_gradient(self, z):
        """z: layer"""
        Lay.clone(self.stat.render, z)

        GradientFill(
                self.e,
                self.stat,
                name=self.name,
                layer_key=self.name,
                auto=1
            )

        z1 = Lay.get_active(self.stat.render)

        Lay.give_mask(z1, z)
        return Lay.merge(self.stat.render, z1)

    def do(self, d):
        """
        Draw the effect.

        Is part of a RenderHub class template.

        d: sub-session dict
        """
        a = self.stat.auto
        ok = OptionKey
        self.stat.auto = ForRender.AUTO_NO_SAVE
        e = self.e = deepcopy(ForGradient.LINEAR_DICT)

        e.update(d)

        self.d1 = d
        self.d2 = deepcopy(self.stat.session[SessionKey.COLORED_GRID])
        self.d2[ok.ROTATE] = 45
        layer = Lay.add(self.stat.render, self.name)
        self.group = Lay.group(self.stat.render, self.name)

        Lay.color_fill(layer, (127, 127, 127))
        self._do_1st_layer()

        z1 = self._do_2nd_layer()

        self._do_3rd_layer(z1)

        e[ok.START_X] = self.stat.width - 1
        e[ok.END_X] = e[ok.START_Y] = 0
        e[ok.END_Y] = self.stat.height - 1
        z = Lay.eat(self.stat.render, self.group)

        self._do_gradient(layer)

        layer = Lay.merge(self.stat.render, z)
        self.stat.auto = a
        self.finish_style(layer)
