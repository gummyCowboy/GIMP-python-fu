#!/usr/bin/env python
# -*- coding: utf-8 -*-
import glob
import os
from roller_base import OZ, Comm
from roller_constant import ForPreset, ForWidget, PresetKey, UIKey
from roller_combobox_entry import RollerComboBoxEntry
from roller_button import RollerButton
from roller_label import RollerLabel
from roller_splitter import Splitter
from roller_ui import UI
from roller_ui_save import UISave


class GroupPreset(RollerComboBoxEntry):
    """Manage a preset group of widgets."""

    def __init__(
                self,
                container,
                on_change,
                preset_name,
                get_data,
                parent,
                preset,
                has_label=False
            ):
        """
        container: gtk container
            container for group preset widgets

        on_change: function
            Call on preset menu change.

        preset_name: string
            name of preset. Use to modify preset file name.

        get_data: function
            Use to retrieve the dict that gets saved.

        parent: GTK.window
            owner window

        preset: Preset

        has_label: flag
            If it's true, a label is created for the menu.
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        self.name = preset_name
        self.get_data = get_data
        self.parent = parent
        self.preset = preset
        self.presets = []
        self.key = PresetKey.PRESET
        self._update_window = on_change
        q = (0, w / 2, w, w) if container else (0, 0, 0, 0)

        self.collect_presets()
        RollerComboBoxEntry.__init__(
                self,
                self.on_preset_change,
                key=PresetKey.PRESET,
                opt=self.opt,
                padding=q
            )

        if container:
            padding = w1, w, w, w
            has_inner_padding = True

        else:
            padding = None
            has_inner_padding = False

        g = self.box = Splitter(
                padding=padding,
                has_inner_padding=has_inner_padding
            )

        g1 = self.save_b = RollerButton("Save", self.save)
        g2 = self.del_b = RollerButton("Delete", self.delete)
        q = ForWidget.TOPLEFT if container else (0, 0, 0, 0)
        g5 = None

        if has_label:
            g5 = self.label = RollerLabel(preset_name + " Preset:", padding=q)
        if container:
            g.both(g1.alignment, g2.alignment)
            g.pack()

            if g5:
                container.add(g5.alignment)

            container.add(self.alignment)
            container.add(g.container)

    def collect_presets(self):
        u"""Create a list, ‟self.opt”, of internal and external presets."""
        q = self.presets = []

        # menu options:
        self.opt = []
        ext_files = []
        go = 0
        a = self.preset

        try:
            search_path = OZ.get_preset_path(a.name, u"*", self.preset.folder)

            # Ignore sub-directories:
            ext_files = glob.glob(search_path)
            go = 1

        except Exception as ex:
            Comm.show_err(ex)
            Comm.show_err("Roller was unable to load presets.")

        if go:
            # Loads internal presets into a list:
            [q.append(i) for i in a.internal_presets]

            # Makes an external preset file list:
            for n in ext_files:
                file_name = os.path.basename(n)
                split_name = file_name.split(ForPreset.PRESET_SEPARATOR)
                combined_name = u""

                for n1 in range(1, len(split_name)):
                    combined_name = combined_name + split_name[n1]

                types = combined_name.split(u".")
                name = types[0]
                q.append([ForPreset.EXTERNAL_TYPE, name, n])
            for i in q:
                self.opt.append(i[ForPreset.NAME_INDEX])

    def delete(self, *_):
        """Delete a preset file."""
        n = self.get_value()

        # Get the file's full file name so that it can be deleted:
        for n1 in self.presets:
            if n1[ForPreset.NAME_INDEX].lower() == n.lower():
                n2 = n1[ForPreset.FILE_INDEX]
                if Comm.pop_up(
                            self.parent,
                            0,
                            "Do you want to delete:\n" + n2 + "?",
                            "Delete File Confirmation"
                        ):
                    try:
                        os.remove(n2)

                        Comm.pop_up(
                                self.parent,
                                1,
                                "The file:\n" + n2 + "\nwas removed.",
                                "File Deleted"
                            )
                        self.refresh(ForWidget.UNDEFINED)

                    except Exception as ex:
                        Comm.show_err(ex)
                        Comm.show_err(
                            "Roller was unable to delete the file.")
                break

    def on_preset_change(self, g):
        """
        When the ComboBoxE is activated, the
        delete Button needs to be verified.

        g: ComboBoxE
        """
        fw = ForWidget
        if not UI.loading:
            n = self.get_text()

            if n not in (PresetKey.DEFAULT, fw.UNDEFINED, fw.LAST_USED):
                UISave.preset_name = self.get_value()
            if n != fw.UNDEFINED:
                d = self.preset.get_preset(n, self.presets)

                self.verify_del_button()
                self._update_window(g, d)

    def refresh(self, n):
        """
        The state of the preset menu has changed.

        n: the name to display on the menu
        """
        fw = ForWidget
        UI.loading += 1

        self.collect_presets()
        self.populate_list(self.opt)

        p = self.set_value if n in self.opt else self.set_text

        p(n)

        if n not in (PresetKey.DEFAULT, fw.UNDEFINED, fw.LAST_USED):
            UISave.preset_name = n
        UI.loading -= 1

    def save(self, *_):
        """Save a preset file."""
        if UISave({
                    PresetKey.GET_DATA: self.get_data,
                    PresetKey.PRESET: self.preset,
                    UIKey.PARENT: self.parent,
                }).reply:
            self.refresh(UISave.preset_name)

    def verify_del_button(self):
        """The delete Button is valid for an external preset."""
        a = self.del_b
        x = 0 if self.preset.is_internal(self.get_text(), self.presets) else 1
        (a.disable, a.enable)[x]()
