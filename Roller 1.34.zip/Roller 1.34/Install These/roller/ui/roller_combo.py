#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import WidgetKey
from roller_widget import Widget
import gtk
import pango


class RollerCombo(Widget):
    """Use with RollerComboBox and RComboBoxE."""

    def __init__(self, on_change, sub_class, **d):
        """
        on_change: function
            Call on_change.

        sub_class: class
            widget sub-class

        d: dict
            widget dict
        """
        wk = WidgetKey
        self.opt = []
        self.length = 0
        g = self.alignment = gtk.Alignment(0, 0, 1, 0)
        self.store = gtk.ListStore(str)
        g1 = d[wk.WIDGET] = sub_class(self.store)

        Widget.__init__(self, on_change, **d)

        # Limit the horizontal size of the the combobox:
        a = gtk.CellRendererText()
        a.props.ellipsize = pango.ELLIPSIZE_END

        g1.pack_start(a)
        g.add(g1)

        if sub_class == gtk.ComboBox:
            g1.add_attribute(a, 'text', 0)

        else:
            g1.child.set_editable(0)

        if wk.PADDING in d:
            g.set_padding(*d[wk.PADDING])
        if wk.OPT in d:
            self.populate_list(d[wk.OPT])

    def get_value(self):
        """
        Return the activated item in the ComboBox.

        Is part of a UI widget template.
        """
        return self.opt[self.wig.get_active()]

    def populate_list(self, q):
        """
        Set the options for the ComboBox.

        q: iterable of option strings
        """
        self.store.clear()

        self.opt = q

        for n in q:
            self.store.append([n])
        self.length = len(q)

    def set_value(self, n):
        """
        Set the ComboBox's display.

        Is part of a UI widget template.

        n: string to display
        """
        if n in self.opt:
            x = self.opt.index(n)

        else:
            x = 0
        self.wig.set_active(x)
