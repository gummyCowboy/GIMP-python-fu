#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForColor
import gtk


class ColoredButton(gtk.EventBox):
    """This Button changes color."""

    def __init__(self, n, on_action):
        """
        n: string
            button text

        on_action: function
            Call on action.
        """
        super(ColoredButton, self).__init__()

        self.update_window = on_action

        # Embed widget inside VBox and HBox:
        g = self.label = gtk.Label(n)
        g1 = self.hbox = gtk.HBox()

        self.add(g1)
        g1.add(g)

        # events to react to:
        a = gtk.gdk
        p = self.connect

        for i in (
                    a.BUTTON_RELEASE_MASK,
                    a.BUTTON_PRESS_MASK,
                    a.ENTER_NOTIFY_MASK,
                    a.LEAVE_NOTIFY_MASK,
                    a.FOCUS_CHANGE_MASK,
                    a.KEY_PRESS_MASK,
                    a.KEY_RELEASE_MASK
                ):
            self.add_events(i)

        self.set_can_focus(1)
        p('button_press_event', self.on_click)
        p('key_press_event', self.on_key_press)
        p('focus_in_event', self.focus_in)
        p('focus_out_event', self.focus_out)

    def on_click(self, g, *_):
        """
        Pass the click event to the button owner.

        g: self
        """
        self.update_window(g)
        self.grab_focus()

    def on_key_press(self, g, a):
        """
        Process a 'space' key-press.

        g: self
        a: key-press event
        """
        if gtk.gdk.keyval_name(a.keyval) == 'space':
            self.update_window(g)
            return 1

    def focus_in(self, *_):
        """Change the color of the button to show focus."""
        self.set_color(gtk.gdk.Color(50000, 50000, ForColor.MAX_COLOR))

    def focus_out(self, *_):
        """Change the color of the button to normal."""
        self.set_color(ForColor.BACKGROUND_BUTTON_COLOR)

    def set_color(self, color, state=gtk.STATE_NORMAL):
        """
        Set the button-face color.

        color: gtk.gdk.Color
        state: normal or disabled
        """
        self.modify_bg(state, color)

    def set_label(self, n):
        """
        Change button's text.

        n: string
        """
        self.label.set_text(n)

    def set_size(self, w=10, h=10):
        """
        Try to set the size of the button.

        w: width of widget, int
        h: height of widget, int
        """
        self.set_size_request(width=w, height=h)

    def set_text_color(self, color, state=gtk.STATE_NORMAL):
        """
        Set the color of the button's text.

        color: gtk.gdk.Color
        state: normal or disabled
        """
        self.label.modify_fg(state, color)

    def show(self):
        """Draw the custom button."""
        super(ColoredButton, self).show()
        for g in (self.hbox, self.vbox, self.label):
            g.show()
