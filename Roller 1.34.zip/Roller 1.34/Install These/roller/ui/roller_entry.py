#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_widget import Widget
import gtk


class RollerEntry(Widget):
    """This is a custom GTK Entry."""

    def __init__(self, on_change, widget_key, padding=None):
        """
        on_change: function
            Call on change.

        widget_key: string
            widget's key

        padding: tuple of int
            Alignment padding (top, bottom, left, right)
        """
        g = self.alignment = gtk.Alignment(0, 0, 1, 0)
        g1 = gtk.Entry(100)

        Widget.__init__(self, on_change, key=widget_key, widget=g1)
        g.add(g1)
        g1.connect('changed', self.callback)
        if padding:
            g.set_padding(*padding)

    def get_value(self):
        """
        Return the value displayed in the Entry.

        Is part of a UI widget template.
        """
        return self.wig.get_text()

    def set_value(self, n):
        """
        Set the value displayed in the the Entry.

        Is part of a UI widget template.

        n: string to place in the Entry
        """
        self.wig.set_text(n)
