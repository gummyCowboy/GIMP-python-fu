#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_widget import Widget
import gtk


class RollerColorButton(Widget):
    """This is a color button that opens a color-chooser dialog."""

    def __init__(self, on_change, color, widget_key):
        """
        on_change: function
            Call on change.

        color: tuple
            color (r, g, b)

        widget_key: string
            widget key
        """
        w = ForWidget.MARGIN
        g = self.alignment = gtk.Alignment(0, 0, 1, 0)
        g1 = gtk.ColorButton(color=RollerColorButton._convert_color(color))

        Widget.__init__(self, on_change, key=widget_key, widget=g1)
        g1.connect('clicked', self.callback)
        g.add(g1)
        g.set_padding(w / 2, w / 2, 0, 0)

    @staticmethod
    def _convert_color(color):
        """
        Convert COLOR to GdkColor.

        color: (r, g, b) (0..255)
        """
        color = [i / 255. for i in color]
        return gtk.gdk.Color(*color)

    def get_value(self):
        """
        Return the value of the button as (r, g, b) (0..255).

        Is part of a UI widget template.
        """
        a = self.wig.get_color()
        return tuple([int(i / 256) for i in (a.red, a.green, a.blue)])

    def set_value(self, color):
        """
        Set the color of the button.

        Is part of a UI widget template.

        color: color: (r, g, b): (0..255)
        """
        self.wig.set_color(RollerColorButton._convert_color(color))
