#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_base import OZ, Comm
from roller_constant import (
        ForPreset,
        ForWidget,
        PickleKey,
        PresetKey,
        UIKey,
        WindowKey
    )

from roller_button import RollerButton
from roller_entry import RollerEntry
from roller_eventbox import REventBox
from roller_label import RollerLabel
from roller_splitter import Splitter
from roller_ui_switch import UISwitch
import os
import gtk


class UISave(UISwitch):
    """This window gets a preset name then saves the preset."""
    preset_name = "New Preset"

    DUPE = "The file,\n\n{},\n\nalready exists. Do you want to overwrite?"

    def __init__(self, d):
        """d: dict"""
        self.get_data = d[PresetKey.GET_DATA]
        a = self.preset = d[PresetKey.PRESET]
        d[UIKey.ON_RETURN] = self._save
        d[UIKey.WINDOW_TITLE] = "Name the " + a.name + " Preset"
        d[UIKey.WINDOW_POSITION] = WindowKey.SAVE
        self.filename_label = self.save_b = None
        UISwitch.__init__(self, d)

    def _draw_file_info_group(self, g):
        """
        The file info group shows the user the preset file's location.

        g: container
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        self.reduce_color()
        n = os.path.dirname(
            OZ.get_preset_path(self.preset.name, "", self.preset.folder))

        drive, path = os.path.splitdrive(n)
        g1 = Splitter(padding=(w1, w1, w, w), has_inner_padding=True)
        g2 = REventBox(self.color)
        g3 = gtk.VBox()

        self.reduce_color()

        g4 = REventBox(self.color)
        g5 = self.file_name_box = gtk.VBox()
        g6 = self.filename_label = RollerLabel("")

        g2.add(g3)
        g4.add(g5)
        g1.both(g2, g4)
        g3.add(RollerLabel("Drive:").alignment)
        g3.add(RollerLabel("Folder:").alignment)
        g3.add(RollerLabel("File Name:").alignment)
        g5.add(RollerLabel(drive).alignment)
        g5.add(RollerLabel(path).alignment)
        g5.add(g6.alignment)
        g1.no_pack()
        g.add(g1.container)
        self._draw_file_name(self.file_name_e)

    def _draw_file_name(self, g):
        """
        Call whenever the preset name Entry changes.

        Update the File Location group with the latest file name.

        g: file name Entry
        """
        if self.filename_label:
            n = OZ.get_preset_name(
                self.preset.name,
                g.get_value())
            self.filename_label.label.set_text(n)
            if self.save_b:
                if g.get_value().lower() in (
                            PresetKey.DEFAULT.lower(),
                            ForPreset.KEY_LIGHT_COMPLIMENT.lower(),
                            ForPreset.COLORED_DIAMONDS.lower()
                        ):
                    self.save_b.disable()

                else:
                    self.save_b.enable()

    def _draw_process_group(self, g):
        """
        Draw the Cancel and Save Buttons for the window.

        g: container
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        g1 = Splitter(padding=(w1, w1, w, w), has_inner_padding=True)
        g2 = self.save_b = RollerButton("Save", self._save)
        g3 = self.cancel_b = RollerButton("Cancel", self.close)

        g1.both(g3.alignment, g2.alignment)
        g1.pack()
        g.add(g1.container)

    def _draw_variable_group(self, g):
        """
        Create an Entry for naming the preset.

        g: container
        """
        w = ForWidget.MARGIN
        g1 = self.file_name_e = RollerEntry(
                self._draw_file_name,
                None,
                padding=(0, w / 2, w, w)
            )

        g.add(RollerLabel("Preset Name:", padding=ForWidget.TOPLEFT).alignment)
        g.add(g1.alignment)
        g1.set_value(UISave.preset_name)
        g1.wig.select_region(0, -1)

    def draw_window(self):
        """
        Draw the window's controls.

        Is part of the UI window template.
        """
        g = self.win.vbox
        q = (
            self._draw_variable_group,
            self._draw_file_info_group,
            self._draw_process_group)

        q1 = "Variables", "File Location", "Process"

        for x, p in enumerate(q):
            box = REventBox(self.color)
            g1 = gtk.VBox()

            box.add(g1)
            g.add(box)
            g1.add(RollerLabel(q1[x] + ":", padding=(2, 0, 4, 0)).alignment)
            p(g1)
            self.reduce_color()

    def _save(self, *_):
        """
        Attempts to write the preset and if successful
        updates the preset menu and closes the window.
        """
        d = deepcopy(self.get_data())
        n = d[PresetKey.PRESET] = self.file_name_e.get_value()
        if self._write(d):
            UISave.preset_name = n
            self.reply = 1
            return self.close()

    def _write(self, d):
        """
        Write the preset, after checking if it already
        exists and asking permission to over-write.

        d: dict that gets saved

        Return a result flag where true is a successful write.
        """
        path = OZ.get_preset_path(
            self.preset.name, self.file_name_e.get_value(), self.preset.folder)

        m = 1

        if os.path.isfile(path):
            n = UISave.DUPE.format(path)
            m = Comm.pop_up(self.win, 0, n, "Duplicate File")

        if m:
            m = OZ.pickle_dump({
                    PickleKey.DATA: d,
                    PickleKey.FILE: path
                })
        return m
