#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import sqrt
from roller_constant_for import Grid as gr, Shape as sh, Triangle as ft
from roller_constant_key import (
    Model as md,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_one import Base, Hat, Rect
import math
import sys
import gimpfu as fu

pdb = fu.pdb
RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP


def get_option_values(step):
    """
    Get the option values from the interface.

    step: tuple
        option group key

    Return: dict
        {Widget key: Widget value}
    """
    d = {}

    # OptionGroup, 'a'
    a = Hat.cat.group_dict[step]

    # OptionGroup Widget dict, 'e'
    e = a.d

    # option key, 'i' and its Widget, 'g'
    for i, g in e.items():
        # The Preset Widget is not part of the group.
        if i != wk.PRESET:
            d[i] = g.get_value()
    return d


def set_per_cell_value(d, step):
    """
    Set the Per Cell cell table of a Preset dict.

    d: dict
        Preset

    step: tuple
        for getting option group
    """
    a = Hat.cat.group_dict[step].per_cell_group
    d[ok.PER_CELL] = a.get_value() if a else None


class Step:
    """
    Organize step functions. A step is a tuple made from the Node
    label sequence of a navigation tree. Use a step tuple as a key
    to retrieve its OptionGroup from the global 'Hat.cat.group_dict'.
    """

    @staticmethod
    def get_canvas_margin(step):
        """
        Get a Model's Canvas Margins.

        step: tuple
            of sub-steps

        Return: tuple
            top, bottom, left, right
            of int
        """
        return Form.calc_margin(
            Step.get_dict_from_step(
                step[:3] + (sk.CANVAS, sk.MARGIN),
                add_per_cell=False
            ),
            *Render.size()
        )

    @staticmethod
    def get_canvas_plaque(step):
        """
        Get a Canvas Plaque Preset dictionary.

        step: tuple
            Has a Model prefix.
        """
        return Step.get_dict_from_step(step[:3] + (sk.CANVAS, sk.PLAQUE))

    @staticmethod
    def get_cell_caption_form(o):
        """
        Get a cell Caption dict without the Per Cell cell table.

        o: One
            Has step (tuple), model (string), r, c (int).

        Return: dict
            cell Caption Preset
        """
        step = o.step
        step = step[:3] + (sk.IMAGE, sk.CAPTION)
        d = Step.get_dict_from_step(step)

        if o.model_type in md.ONE_CELL:
            return d

        q = d[ok.PER_CELL]
        return q[o.r][o.c] if q else d

    @staticmethod
    def get_cell_margin(step):
        """
        Get a cell Margin and its Per Cell cell table.

        step: tuple
            Has a Model reference in the third position.

        Return: dict
            Cell Margin Preset with its Per Cell cell table
        """
        return Step.get_dict_from_step(step[:3] + (sk.CELL, sk.MARGIN))

    @staticmethod
    def get_cell_plaque(step):
        """
        Get a Cell Plaque with its Per Cell cell table.

        step: tuple
            Has a Model reference in the third position.

        Return: dict
            cell Plaque
        """
        return Step.get_dict_from_step(step[:3] + (sk.CELL, sk.PLAQUE))

    @staticmethod
    def get_dict_from_step(step, add_per_cell=True):
        """
        Get a Widget-key-based dict from a group of Widgets.

        step: tuple
            of Node label

        add_per_cell: bool
            When true, include the Per Cell cell table in the return dict.

        Return: dict
            {Widget key: Widget value}
        """
        d = get_option_values(step)
        if add_per_cell:
            set_per_cell_value(d, step)
        return d

    @staticmethod
    def get_face_index(step):
        """
        Extract the Face index from a step.

        step: tuple
            Has a "Face " sub-step.

        Return: int or None
            Face index
        """
        # Skip the Model prefix in the step with '3:'.
        for i in reversed(step[3:]):
            for x, j in enumerate(sk.FACES):
                if j in i:
                    return x

    @staticmethod
    def get_model_type(step):
        """
        Determine the Model Type from a step.
        The step must represent at least three Nodes.
        """
        return md.MODEL_TYPE_DICT[
            Hat.cat.group_dict[step[:3] + (sk.CELL, sk.TYPE)].group_key
        ]

    @staticmethod
    def get_per_cell_for_table(step, cell_key):
        """
        Make a step to the cell Type option group. Get it's Preset dict.

        step: tuple
            (Node label,)
            Has prefix.

        cell_key: string
            group key for a Table's Cell Type OptionGroup
            Is postfix.

        Return: list
            Per Cell cell table
        """
        return Hat.cat.group_dict[
            step[:3] + (sk.CELL, cell_key)
        ].per_cell_group.get_value()

    @staticmethod
    def get_place_chunk(o):
        """
        Get a Place Preset dict and its Per Cell cell table.

        o: One
            Has variables.

        Return: dict
            Place Preset
        """
        return Step.get_dict_from_step(o.step[:3] + (sk.IMAGE, sk.PLACE))

    @staticmethod
    def get_place_form(o):
        """
        Get a Place Preset.

        o: One
            Has variables.

        Return: dict
            of cell place form
        """
        step = o.step[:3] + (sk.IMAGE, sk.PLACE)
        d = Step.get_dict_from_step(step)

        if o.model_type in md.ONE_CELL:
            return d

        q = d[ok.PER_CELL]
        return q[o.r][o.c] if q else d

    @staticmethod
    def get_rectangle_dict(step):
        """
        Get a Model's Cell / Rectangle Preset dictionary.

        step: tuple
            Has a Model reference.
        """
        return Step.get_dict_from_step(
            step[:3] + (sk.CELL, sk.RECTANGLE),
            add_per_cell=False
        )

    @staticmethod
    def get_type_from_step(step, add_per_cell=True):
        """
        Get a Widget-key-based Cell Type Preset dict.

        step: tuple
            Has a Model Prefix.

        add_per_cell: bool
            If it is true, the Per Cell cell
            table is added to the return dict.

        Return: dict
            {Widget key: Widget value}
            Cell Type Preset
        """
        step = step[:3] + (sk.CELL, sk.TYPE)
        e = Hat.cat.group_dict

        # OptionGroup, 'a'
        d = get_option_values(step)

        if add_per_cell:
            # Include the Per Cell cell table.
            step = Step.make_per_cell_step(step)
            if step in e:
                d[ok.PER_CELL] = e[step].d[ok.PER_CELL].get_value()
        return d

    @staticmethod
    def has_margin(d):
        """
        Determine if a cell has any Cell Margin value.

        d: dict
            of margins, form

        r, c: int
            cell index

        Return: bool
            Is true if the Margin Preset dict has a value other than zero.
        """
        return any(d.values())

    @staticmethod
    def make_per_cell_step(step):
        """
        Create a step from a option group to its Per Cell group.

        Return: tuple
            the step to the option's attached Per Cell group
        """
        return step[:-1] + (step[-1] + ", Per Cell",)


class Form:
    """Organize functions that work with an OptionGroup dictionary."""

    @staticmethod
    def calc_margin(d, w, h):
        """
        Return the margins after adding the
        fixed-value and the factor margins together.

        d: dict
            Margin Preset

        w, h: int
            cell size or Render size

        Return: list
            top, bottom, left, right
            of int
        """
        top = bottom = left = right = 0

        if d:
            top = Render.get_factor_h(d[ok.MARGIN_TOP])
            bottom = Render.get_factor_h(d[ok.MARGIN_BOTTOM])
            left = Render.get_factor_w(d[ok.MARGIN_LEFT])
            right = Render.get_factor_w(d[ok.MARGIN_RIGHT])

            # Compensate for margin overflow
            # by reserving one pixel for the image.
            if top + bottom >= h:
                top = h // 2
                bottom = h - top - 1
            if left + right >= w:
                left = w // 2
                right = w - left - 1
        return top, bottom, left, right

    @staticmethod
    def get_cell_rect(d):
        """
        Calculate a cell rectangle.

        d: dict
            Cell Rectangle Preset
        """
        w, h = Render.size()
        return Rect(
            # position x, y
            d[ok.POSITION_X][0] + int(d[ok.POSITION_X][1] * w),
            d[ok.POSITION_Y][0] + int(d[ok.POSITION_Y][1] * h),

            # size w, h
            max(1, d[ok.CELL_WIDTH][0] + int(d[ok.CELL_WIDTH][1] * w)),
            max(1, d[ok.CELL_HEIGHT][0] + int(d[ok.CELL_HEIGHT][1] * h))
        )

    @staticmethod
    def get_face_chunk(d, step, k):
        """
        Get a Preset dict, from the form or from the Per Cell cell table.

        d: dict
            Preset with a Per Cell cell table

        step: tuple
            Has a Model reference.

        k: string
            Node label for a group step

        Return: dict
            Face Preset
        """
        if d[ok.FACE_TYPE]:
            # Already has the Per Cell cell table.
            pass

        else:
            step = step[:3] + (sk.CELL, sk.FACE, k, sk.GROUP)
            d = get_option_values(step)
            set_per_cell_value(d, step)
        return d

    @staticmethod
    def get_face_chunk_from_step(step, k, face_x):
        """
        Get a Preset dict, from the form or from its Per Cell cell table.

        step: tuple
            Has a Model reference.

        k: string
            Node label for a group step

        face_x: int
            Face index

        Return: dict
            Preset
        """
        model = step[:3]
        step = model + (sk.CELL, sk.FACE, k, sk.FACE_PAD + str(face_x + 1))
        d = get_option_values(step)

        if not d[ok.FACE_TYPE]:
            # Get Group Face Type.
            step = model + (sk.CELL, sk.FACE, k, sk.GROUP)
            d = get_option_values(step)

        set_per_cell_value(d, step)
        return d

    @staticmethod
    def get_face_form(o, k, r, c):
        """
        Get a Preset dict, from its form or from the Per Cell cell table.

        o: One
            Has d, a Preset dict, with or without the Per Cell cell table
            Has r, c, int, cell index.

        k: string
            Node label for a group step

        r, c: int
            cell index for its Per Cell cell table

        Return: dict
            Preset without its Per Cell cell table
        """
        # Could be the Group or the Face Preset.
        d = o.d

        if ok.FACE_TYPE in d and o.d[ok.FACE_TYPE]:
            # Face, Face Type
            d = o.d

        else:
            # Group, Face Type
            step = o.step[:3] + (sk.CELL, sk.FACE, k, sk.GROUP)
            d = get_option_values(step)
            set_per_cell_value(d, step)

        if d[ok.PER_CELL]:
            d = d[ok.PER_CELL][r][c]
        return d

    @staticmethod
    def get_form(o):
        """
        Get a Preset dict, from its from or from the Per Cell cell table.

        o: One
            Has d, a Preset dict, with or without the Per Cell cell table
            Has r, c, int, cell index.

        Return: dict
            Preset
        """
        d = o.d
        if ok.PER_CELL in d and d[ok.PER_CELL]:
            return d[ok.PER_CELL][o.r][o.c]
        return d

    @staticmethod
    def get_image_rotate(o):
        """
        Get the rotation value from a Place Preset dict.

        o: One
            Has d, a Preset dict, with or without a Per Cell cell table
            Has r, c, int, cell index.

        Return: float
            the image rotation for the cell
        """
        return Form.get_form(o)[ok.ROTATE]


class Shape:
    """Organize functions related to cell and mask shape."""

    @staticmethod
    def bounds(a):
        """
        Return the bounds of a shape.

        a: iterable or dict
            The iterable has x, y numeric pairs.
            The dict of an ellipse has x, y, w, h.

        Return: tuple
            x, y, w, h
            the bounds of the shape
        """
        if isinstance(a, dict):
            return a['x'], a['y'], a['w'], a['h']
        else:
            min_x = min_y = sys.maxint
            max_x = max_y = -sys.maxint

            for x, i in enumerate(a):
                if not x % 2:
                    min_x = min(i, min_x)
                    max_x = max(i, max_x)
                else:
                    min_y = min(i, min_y)
                    max_y = max(i, max_y)
            return min_x, min_y, max_x - min_x, max_y - min_y

    @staticmethod
    def calc_hexagon_regular_offset(w, h):
        """
        Calculate offsets of a regular hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            offsets
        """
        return round(w / 2.), round(h / 4.), round(h / 2.), round(h * .75)

    @staticmethod
    def calc_hexagon_regular_shape(x, y, w, h, q):
        """
        Calculate the polygon points of a regular hexagon.

        w, h: numeric
            rectangle

        q: tuple
            of offsets

        Return: tuple
            of shape
            for the select polygon function
        """
        w1, h1, _, h2 = q

        # The first point is the topleft. The
        # points connect in a clockwise rotation.
        return (
            x, y + h1,
            x + w1, y,
            x + w, y + h1,
            x + w, y + h2,
            x + w1, y + h,
            x, y + h2
        )

    @staticmethod
    def calc_hexagon_truncated_offset(w, h):
        """
        Calculate offsets of a truncated hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            offsets
        """
        return round(w / 4.), round(w / 2.), round(w * .75), round(h / 2.)

    @staticmethod
    def calc_hexagon_truncated_shape(x, y, w, h, q):
        """
        Calculate the polygon points of a truncated hexagon.

        w, h: numeric
            rectangle

        Return: tuple
            of x, y pairs
            for the select polygon function
        """
        # 'w2' is not used.
        w1, w2, w3, h1 = q

        # The first point is the topleft.
        # The points connect clockwise.
        return (
            x, y + h1,
            x + w1, y,
            x + w3, y,
            x + w, y + h1,
            x + w3, y + h,
            x + w1, y + h,
        )

    @staticmethod
    def calc_horizontal_ellipse(rect):
        """
        Calculate the rectangle shape of a horizontal ellipse.

        rect: Rect
            bounding rectangle for an ellipse

        Return: dict
            with shape
        """
        h = round(rect.h * sh.ELLIPSE_RATIO)
        return {'x': rect.x, 'y': rect.y, 'w': rect.w, 'h': rect.h - h}

    @staticmethod
    def calc_lock(s, t):
        """
        Return the size of an image that will fit into a smaller cell.

        s: tuple
            of int
            cell size
            (w, h)
            Conform the image size to this size.

        t: tuple
            of int
            image size
            (w, h)
        """
        w_r = float(t[0]) / s[0]
        h_r = float(t[1]) / s[1]

        if w_r > h_r:
            w, h = s[0], int(t[1] * (s[0] / float(t[0])))

        else:
            w, h = int(t[0] * (s[1] / float(t[1]))), s[1]
        return max(w, 1), max(h, 1)

    @staticmethod
    def calc_octagon_side_to_side_offset(w, h):
        """
        Calculate the offsets of a side-to-side octagon using a ratio.

        w, h: numeric
            size of cell

        Return: tuple
            of offsets
        """
        # Use ratio.
        w1 = float(w * sh.OCTAGON_RATIO)
        w2 = w - w1
        h1 = float(h * sh.OCTAGON_RATIO)
        h2 = h - h1
        return w1, w2, h1, h2

    @staticmethod
    def calc_octagon_side_to_side_shape(x, y, w, h, q):
        """
        Calculate the polygon points of a side-to-side octagon using a ratio.

        x, y, w, h: float
            the bounds rectangle of the octagon

        q: tuple
            of offsets for points

        Return: tuple
            of x, y pairs
            for select polygon function
        """
        w1, w2, h1, h2 = q

        # The first point is topleft.
        # The points connect clockwise.
        return (
            x + w1, y,
            x + w2, y,
            x + w, y + h1,
            x + w, y + h2,
            x + w2, y + h,
            x + w1, y + h,
            x, y + h2,
            x, y + h1
        )

    @staticmethod
    def calc_octagon_offset(w, h):
        """
        Calculate the offsets of an octagon.

        w, h: numeric
            size of cell

        Return: tuple
            of offsets
        """
        # of cell rectangle
        radius = Base.circumradius(w, h)

        w1 = w / 2.
        h1 = h / 2.
        angle = math.asin(h1 / radius)

        # The process for 'w2' is deliberately
        # not factored as it is a complex formula.
        _w = w1 * h1
        w2 = math.tan(angle)**2
        w2 = w2 * w1**2
        w2 = h1**2 + w2
        w2 = math.sqrt(w2)
        w2 = _w / w2
        h2 = w2 * math.tan(angle)
        w3 = w1 + w2
        w4 = w1 - w2
        h3 = h1 + h2
        h4 = h1 - h2
        return (
            round(w4),
            round(w1),
            round(w3),
            round(h4),
            round(h1),
            round(h3)
        )

    @staticmethod
    def calc_octagon_shape(x, y, w, h, q):
        """
        Calculate the polygon points of an octagon using a ratio.

        x, y, w, h: float
            the bounds rectangle of the octagon

        q: tuple
            of offsets for points

        Return: tuple
            of x, y pairs
            for select polygon function
        """
        w1, w2, w3, h1, h2, h3 = q

        # The first point is top-center.
        # The direction is clockwise.
        return (
            x + w2, y,
            x + w3, y + h1,
            x + w, y + h2,
            x + w3, y + h3,
            x + w2, y + h,
            x + w1, y + h3,
            x, y + h2,
            x + w1, y + h1
        )

    @staticmethod
    def calc_pin_offset(pin, s, w, h, x, y):
        """
        Calculate pin offset given the layer space.
        Fixed-sized cells have a pin corner. Their cell
        grid is pinned or connected to its pin corner.

        pin: string
            pin type

        s: tuple
            size
            w, h
            of layer space

        w, h: int
            size of the grid in pixels

        x, y: int
            offset
        """
        if pin in gr.PINS_WITH_X_OFFSET:
            x1 = s[0] - w

            if pin == gr.CENTER:
                x1 //= 2
            x += x1

        if pin in gr.PINS_WITH_Y_OFFSET:
            y1 = s[1] - h

            if pin == gr.CENTER:
                y1 //= 2
            y += y1
        return x, y

    @staticmethod
    def calc_vertical_ellipse(rect):
        """
        Calculate the rectangle shape of a vertical ellipse.

        rect: Rect
            the bounds rectangle of the ellipse

        Return: dict
            with shape
        """
        w = int(round(rect.w * .135))
        return {'x': rect.x, 'y': rect.y, 'w': rect.w - w, 'h': rect.h}

    @staticmethod
    def is_allocated_cell(model, r, c):
        """
        Determine if a cell is a valid cell in a Grid-type
        Model. Double-space shapes allocate every other cell.

        If the Model is not shifted, then only cells
        where the row and column have the same
        remainder when divided by two are valid.

        If the Model is shifted, then only cells
        where the row and column have different
        remainders when divided by two are valid.

        model: Model
            Has a cell table.

        r, c: int
            row, column
            cell index

        double_type: enum
            a polarized and typed value
            Is polarized by the double-spaced grid property.
            Is sub-typed by the Cell Shift option.

        Return: bool
            Is true if the cell is valid.
        """
        a = model.double_type

        if a == sh.NOT_DOUBLE_SPACE:
            return True
        return Shape.is_double_cell(a, r, c)

    @staticmethod
    def is_double_cell(a, r, c):
        """
        Given a double-spaced cell table, determine
        if a cell is actually a cell. With a double-spaced
        grid, every other cell is a null cell.

        a: int
            enum for double-spaced cell-shift type

        r, c: int
            cell index

        return bool
            Is true if the cell is valid.
        """
        if a == sh.SHIFT:
            return (r % 2 and not c % 2) or (not r % 2 and c % 2)
        return (r % 2 and c % 2) or (not r % 2 and not c % 2)

    @staticmethod
    def is_rectangular_shape(shape):
        """
        Determine if a cell shape is rectangular.

        shape: string
            shape descriptor

        Return: bool
            Is true if the cell shape is rectangular shaped.
        """
        return shape in (sh.RECTANGLE, sh.SQUARE)

    @staticmethod
    def is_inverse_triangle(r, c):
        """
        Determine if a triangle is inverted,
        either vertically or horizontally.

        r, c: int
            row, column
            cell index

        Return: bool
            Is true when the triangle is inverted.
        """
        return (not r % 2 and c % 2) or (r % 2 and not c % 2)

    @staticmethod
    def transform_face(o, z):
        """
        Transform a layer using perspective.

        o: One
            Has variables r, c, face_x.

        z: layer
            Has material to transform.

        Return: layer
            with transformation
        """
        # The transform function will fail
        # miserably if there's a selection.
        pdb.gimp_selection_none(Hat.cat.render.image)

        pdb.gimp_context_set_interpolation(fu.INTERPOLATION_LOHALO)
        pdb.gimp_context_set_transform_direction(fu.TRANSFORM_FORWARD)
        pdb.gimp_context_set_transform_resize(fu.TRANSFORM_RESIZE_ADJUST)
        return pdb.gimp_item_transform_perspective(
            z,
            *o.model.get_corner(o.face_x, o.r, o.c)
        )


class FromRect:
    """
    Has functions for calculating a cell shape. The
    functions receive a Rect and return a tuple or dictionary.

    Tuples are x, y points for drawing polygons. Dictionaries
    contain x, y, w, h, a rectangle, and are used to draw ellipses.
    """

    @staticmethod
    def circle(rect):
        """
        Get a dictionary of a circle.

        rect: Rect
            the bounds rectangle for the circle

        Return: dict
            the centered rectangle bounds of a circle
        """
        x, y = rect.position
        w, h = rect.size
        center_x, center_y = x + w / 2., y + h / 2.
        w = min(w, h)
        x1 = center_x - w / 2.
        y1 = center_y - w / 2.
        return {'x': round(x1), 'y': round(y1), 'w': w, 'h': w}

    @staticmethod
    def rhombus_shear(rect):
        """
        Get the four points of a Sheared Rhombus.

        rect: Rect
            the bounds rectangle for the Sheared Rhombus

        Return: tuple
            x, y pairs
            for drawing a Sheared Rhombus
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = round((y + y1) / 2.)
        x2 = round((x + x1) / 2.)
        return x, y2, x2, y, x1, y2, x2, y1

    @staticmethod
    def rhombus_regular(rect):
        """
        Get the four points of a Rhombus.
        Maintain the Rhombus shape proportions.

        rect: Rect
            the bounds rectangle for the regular Rhombus

        Return: tuple
            x, y pairs
            for drawing a regular Rhombus
        """
        x, y = rect.position
        w, h = rect.size
        w2 = round(min(w, h) / 2.)
        center_x, center_y = round(x + w / 2.), round(y + h / 2.)
        return (
            center_x - w2, center_y,
            center_x, center_y - w2,
            center_x + w2, center_y,
            center_x, center_y + w2
        )

    @staticmethod
    def ellipse(rect):
        """
        Translate a rectangle into a dictionary for an ellipse.

        rect: Rect
            the bounds rectangle for the ellipse

        Return: dict
            with key, value pairs that define a rectangle
        """
        return {'x': rect.x, 'y': rect.y, 'w': rect.w, 'h': rect.h}

    @staticmethod
    def hexagon_regular_shear(rect):
        """
        Get the six points of a Sheared Hexagon.

        rect: Rect
            the bounds rectangle for the Sheared Hexagon

        Return: tuple
            x, y pairs
            for drawing a Sheared Hexagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_hexagon_regular_shape(
            x, y,
            w, h,
            Shape.calc_hexagon_regular_offset(w, h)
        )

    @staticmethod
    def hexagon_regular(rect):
        """
        Get 6 points of a Hexagon.
        Maintain the Hexagon shape proportions.

        rect: Rect
            the bounds rectangle for the regular Hexagon

        Return: tuple
            x, y pairs
            for drawing a regular Hexagon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * RATIO, h

        if w1 > w:
            # Solution one doesn't fit the rectangle, so it's solution two.
            w1, h1 = w, w * UP_RATIO

        center_x, center_y = round((w - w1) / 2.), round((h - h1) / 2.)
        x += center_x
        y += center_y
        return Shape.calc_hexagon_regular_shape(
            x, y,
            w1, h1,
            Shape.calc_hexagon_regular_offset(w1, h1)
        )

    @staticmethod
    def hexagon_truncated_shear(rect):
        """
        Get the six points of a Sheared Truncated Hexagon.

        rect: Rect
            the bounds rectangle for the Sheared Truncated Hexagon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_hexagon_truncated_shape(
            x, y,
            w, h,
            Shape.calc_hexagon_truncated_offset(w, h)
        )

    @staticmethod
    def hexagon_truncated(rect):
        """
        Get the points of a Truncated Hexagon.
        Maintain the Hexagon shape proportions.

        rect: Rect
            the bounds rectangle for the Truncated Hexagon

        Return: tuple
            x, y pairs
            for drawing a Truncated Hexagon
            a tuple of six coordinates of the hexagon
            connected clockwise
            The first point is the topleft point.
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = float(w), round(w * RATIO)

        if h1 > h:
            # Solution one doesn't fit the rectangle, so it's solution two.
            w1, h1 = round(h * UP_RATIO), float(h)

        center_x, center_y = round((w - w1) / 2.), round((h - h1) / 2.)
        x += center_x
        y += center_y
        return Shape.calc_hexagon_truncated_shape(
            x, y,
            w1, h1,
            Shape.calc_hexagon_truncated_offset(w1, h1)
        )

    @staticmethod
    def octagon_shear(rect):
        """
        Get the eight points of a Sheared Octagon.

        rect: Rect
            the bounds rectangle for the Sheared Octagon

        Return: tuple
            x, y pairs
            for drawing an octagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_octagon_shape(
            x, y,
            w, h,
            Shape.calc_octagon_offset(w, h)
        )

    @staticmethod
    def octagon_side_to_side_shear(rect):
        """
        Get the eight points of a Sheared Side-to-Side Octagon.

        rect: Rect
            the bounds rectangle for the Sheared Side-to-Side Octagon

        Return: tuple
            x, y pairs
            for drawing an Octagon
        """
        x, y = rect.position
        w, h = rect.size
        return Shape.calc_octagon_side_to_side_shape(
            x, y,
            w, h,
            Shape.calc_octagon_side_to_side_offset(w, h)
        )

    @staticmethod
    def octagon_side_to_side(rect):
        """
        Get the eight points of a Side-to-Side Octagon.
        Maintain the Octagon shape proportions.

        rect: Rect
            the bounds rectangle for the Side-to-Side Octagon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        w1 = min(w, h)

        # Center the polygon in the rectangle.
        offset_x, offset_y = round((w - w1) / 2.), round((h - w1) / 2.)
        x += offset_x
        y += offset_y
        return Shape.calc_octagon_side_to_side_shape(
            x, y,
            w1, w1,
            Shape.calc_octagon_side_to_side_offset(w1, w1)
        )

    @staticmethod
    def octagon_regular(rect):
        """
        Get the eight points of a regular Octagon.
        Maintain regular Octagon proportions.

        rect: Rect
            the bounds rectangle for the regular Octagon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        w1 = min(w, h)

        offset_x, offset_y = round((w - w1) / 2.), round((h - w1) / 2.)
        x += offset_x
        y += offset_y
        return Shape.calc_octagon_shape(
            x, y,
            w1, w1,
            Shape.calc_octagon_offset(w1, w1)
        )

    @staticmethod
    def rectangle(rect):
        """
        Translate a rectangle into a tuple of x, y
        coordinates for drawing a Rectangle polygon.

        rect: Rect
            the bounds rectangle for the Rectangle

        Return: tuple
            x, y pairs
            for drawing a Rectangle
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        return x, y, x1, y, x1, y1, x, y1

    @staticmethod
    def square(rect):
        """
        Get the four points of a Square from the
        topleft corner with a clockwise order.

        rect: Rect
            the bounds rectangle for the Square

        Return: tuple
            x, y pairs
            for drawing a Square
        """
        x, y = rect.position
        w, h = rect.size
        center_x, center_y = round(x + w / 2.), round(y + h / 2.)
        w = min(w, h)
        x1 = center_x - round(w / 2.)
        y1 = center_y - round(w / 2.)
        x2, y2 = x1 + w, y1 + w
        return x1, y1, x2, y1, x2, y2, x1, y2

    @staticmethod
    def triangle_down_shear(rect):
        """
        Get the three points of a Sheared Facing Down Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        x2 = round((x + x1) / 2.)
        return x, y, x2, y1, x1, y

    @staticmethod
    def triangle_down_isosceles(rect):
        """
        Get the three points of a Facing Down Triangle.
        Maintain an isosceles triangle shape.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * UP_RATIO, h

        if w1 > w:
            # Solution one would overflow the bounds rectangle.
            w1, h1 = w, w * RATIO

        x1, y1 = x + w1, y + h1
        x2 = round((x + x1) / 2.)

        # Center the triangle.
        offset_x = round((w - w1) / 2.)
        offset_y = round((h - h1) / 2.)
        x += offset_x
        x1 += offset_x
        x2 += offset_x
        y += offset_y
        y1 += offset_y
        return x, y, x2, y1, x1, y

    @staticmethod
    def triangle_left_shear(rect):
        """
        Get the three points of a Sheared Facing Left Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = float((y + y1) / 2.)
        return x1, y, x1, y1, x, y2

    @staticmethod
    def triangle_left_isosceles(rect):
        """
        Get the three points of a Facing Left Isosceles Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * RATIO, h

        if w1 > w:
            # Solution one would overflow the bounds rectangle.
            # solution two
            w1, h1 = w, w * UP_RATIO

        x1, y1 = x + w1, y + h1
        y2 = round((y + y1) / 2.)

        # Center the triangle.
        offset_x = round((w - w1) / 2.)
        offset_y = round((h - h1) / 2.)
        x += offset_x
        x1 += offset_x
        y += offset_y
        y1 += offset_y
        y2 += offset_y
        return x1, y, x1, y1, x, y2

    @staticmethod
    def triangle_right_shear(rect):
        """
        Get the three points of a Sheared Facing Right Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        y2 = round((y + y1) / 2.)
        return x, y, x, y1, x1, y2

    @staticmethod
    def triangle_right_isosceles(rect):
        """
        Get the three points of a Facing Right Isosceles Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * RATIO, h

        if w1 > w:
            # Solution one would overflow the bounds rectangle.
            # solution two
            w1, h1 = w, w * UP_RATIO

        x1, y1 = x + w1, y + h1
        y2 = round((y + y1) / 2.)

        # Center the triangle.
        offset_x = (w - w1) / 2.
        offset_y = (h - h1) / 2.
        x += offset_x
        x1 += offset_x
        y += offset_y
        y1 += offset_y
        y2 += offset_y
        return (
            x, y,
            x, round(y1),
            round(x1), round(y2)
        )

    @staticmethod
    def triangle_up_shear(rect):
        """
        Get the three points of a Sheared Facing Up Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size
        x1, y1 = x + w, y + h
        x2 = round((x + x1) / 2.)
        return x, y1, x2, y, x1, y1

    @staticmethod
    def triangle_up_isosceles(rect):
        """
        Get the three points of a Facing Down Isosceles Triangle.

        rect: Rect
            the bounds rectangle for the polygon

        Return: tuple
            x, y pairs
            for drawing the polygon
        """
        x, y = rect.position
        w, h = rect.size

        # There are two possible solutions.
        # solution one
        w1, h1 = h * UP_RATIO, h

        if w1 > w:
            # Solution one would overflow the bounds rectangle.
            w1, h1 = w, w * RATIO

        x1, y1 = x + w1, y + h1
        x2 = round((x + x1) / 2.)

        # Center the triangle.
        offset_x = (w - w1) / 2.
        offset_y = (h - h1) / 2.
        x += offset_x
        x1 += offset_x
        x2 += offset_x
        y += offset_y
        y1 += offset_y
        return (
            x, round(y1),
            round(x2), y,
            round(x1), round(y1)
        )


class Render:
    """Use the Render size."""

    @staticmethod
    def calc_factor_h(f):
        return f * Render.height()

    @staticmethod
    def calc_factor_w(f):
        return f * Render.width()

    @staticmethod
    def get_factor_h(a):
        """
        Calculate the number for a number pair
        that uses the Render height as a factor.

        a: tuple, int, or float
            (fixed value, factor value)
            fixed value, from an earlier version

        Return: numeric
            of the same type as the fixed value
        """
        return Factor.get_factor(a, Render.height())

    @staticmethod
    def get_factor_w(a):
        """
        Calculate the number for a number pair
        that uses the Render width as a factor.

        a: tuple, int, or float
            (fixed value, factor value)
            fixed value, from an earlier version

        Return: numeric
            of the same type as the fixed value
        """
        return Factor.get_factor(a, Render.width())

    @staticmethod
    def get_factor_s(q):
        """
        Calculate the number for a number pair
        that uses the Render size as a factor.

        q: tuple
            (fixed value, factor value)

        Return: int
            of the same type as the fixed value
        """
        w, h = Render.size()
        return q[0] + int(q[1] * sqrt(w * h))

    @staticmethod
    def height():
        """
        Get the Render width from the interface.

        Return: int
            width of the Render
        """
        return Hat.cat.group_dict[sk.GLOBAL].d[ok.RENDER_HEIGHT].get_value()

    @staticmethod
    def size():
        """
        Get the Render size from the interface.

        Return: tuple
            of int
            Render size
            width, height
        """
        d = Hat.cat.group_dict[sk.GLOBAL].d
        return d[ok.RENDER_WIDTH].get_value(), d[ok.RENDER_HEIGHT].get_value()

    @staticmethod
    def width():
        """
        Get the Render width from the interface.

        Return: int
            width of Render
        """
        return Hat.cat.group_dict[sk.GLOBAL].d[ok.RENDER_WIDTH].get_value()


class Factor:
    """Produce factored results from NumberPairs."""

    @staticmethod
    def calc_factor(f, w):
        """
        Calculate the factored Render height.

        f: float
            Is factor variable.
            for example, the Render width

        w: numeric
            scale of factor

        Return: int
            the factor of the Render height
        """
        return f * w

    @staticmethod
    def get_factor(a, w):
        """
        Calculate the number for a number pair
        that uses the Render width as a factor.

        a: tuple or int
            (fixed value, factor value)
            fixed value

        w: numeric
            scale of factor
            for example, the Render height

        Return: numeric
            of the same type as the fixed value
        """
        # result, 'b'
        b = a

        if isinstance(a, tuple):
            b = a[0] + Factor.calc_factor(a[1], w)

            if isinstance(a[0], int):
                b = int(b)
            b = min(b, w)

        elif isinstance(a, float):
            b = Factor.calc_factor(a, w)
        return b


class Canvas:
    """Use the canvas size."""

    @staticmethod
    def calc_factor_h(f):
        return f * (Render.height() - 1)

    @staticmethod
    def calc_factor_w(f):
        return f * (Render.width() - 1)

    @staticmethod
    def get_factor_h(a):
        """
        Calculate the number for a number pair
        that uses the Render height as a factor.

        a: tuple, int, or float
            (fixed value, factor value)
            fixed value, from an earlier version

        Return: numeric
            of the same type as the fixed value
        """
        return Factor.get_factor(a, Render.height() - 1)

    @staticmethod
    def get_factor_w(a):
        """
        Calculate the number for a number pair
        that uses the Render width as a factor.

        a: tuple, int, or float
            (fixed value, factor value)
            fixed value, from an earlier version

        Return: numeric
            of the same type as the fixed value
        """
        return Factor.get_factor(a, Render.width() - 1)


dispatch = {
    ft.TRIANGLE_DOWN_SHEAR: FromRect.triangle_down_shear,
    ft.TRIANGLE_DOWN_ISOSCELES: FromRect.triangle_down_isosceles,
    ft.TRIANGLE_LEFT_SHEAR: FromRect.triangle_left_shear,
    ft.TRIANGLE_LEFT_ISOSCELES: FromRect.triangle_left_isosceles,
    ft.TRIANGLE_RIGHT_SHEAR: FromRect.triangle_right_shear,
    ft.TRIANGLE_RIGHT_ISOSCELES: FromRect.triangle_right_isosceles,
    ft.TRIANGLE_UP_SHEAR: FromRect.triangle_up_shear,
    ft.TRIANGLE_UP_ISOSCELES: FromRect.triangle_up_isosceles,
    sh.BOX_HORZ_SHEAR: FromRect.hexagon_truncated_shear,
    sh.BOX_HORZ: FromRect.hexagon_truncated,
    sh.BOX_VERT_SHEAR: FromRect.hexagon_regular_shear,
    sh.BOX_VERT: FromRect.hexagon_regular,
    sh.CIRCLE: FromRect.circle,
    sh.CIRCLE_HORIZONTAL: FromRect.circle,
    sh.CIRCLE_VERTICAL: FromRect.circle,
    sh.ELLIPSE: FromRect.ellipse,
    sh.ELLIPSE_HORIZONTAL: FromRect.ellipse,
    sh.ELLIPSE_VERTICAL: FromRect.ellipse,
    sh.HEXAGON_REGULAR: FromRect.hexagon_regular,
    sh.HEXAGON_REGULAR_SHEAR: FromRect.hexagon_regular_shear,
    sh.HEXAGON_TRUNCATED: FromRect.hexagon_truncated,
    sh.HEXAGON_TRUNCATED_SHEAR: FromRect.hexagon_truncated_shear,
    sh.OCTAGON_DOUBLE_REGULAR: FromRect.octagon_side_to_side,
    sh.OCTAGON_DOUBLE_SHEAR: FromRect.octagon_side_to_side_shear,
    sh.OCTAGON_REGULAR: FromRect.octagon_regular,
    sh.OCTAGON_SHEAR: FromRect.octagon_shear,
    sh.OCTAGON_SIDE_TO_SIDE_SHEAR: FromRect.octagon_side_to_side_shear,
    sh.OCTAGON_SIDE_TO_SIDE_REGULAR: FromRect.octagon_side_to_side,
    sh.RECTANGLE: FromRect.rectangle,
    sh.RHOMBUS: FromRect.rhombus_regular,
    sh.RHOMBUS_SHEAR: FromRect.rhombus_shear,
    sh.SQUARE: FromRect.square
}
