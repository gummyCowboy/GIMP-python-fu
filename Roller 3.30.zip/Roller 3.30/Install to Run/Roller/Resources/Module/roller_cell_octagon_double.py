#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_one import Rect
from roller_one_extract import Shape

# The odd row and column intersects are offset in their intersect list.
ODD_INTERSECT_OFFSET = 2
OCTAGON_REMAIN = 1. - sh.OCTAGON_RATIO


class GridOctagonDouble:
    """
    Calculate the points for the shape of cells. The cells
    are octagon shaped and are placed in a double-spaced model.
    The sides of the octagon appear to be side-to-side.
    """

    def __init__(self, o):
        """
        Calculate cell size and octagon shape.

        o: One
            Has init values.
        """
        def _calc_intersects():
            """
            Calculate vertical and horizontal intersect points.

            Return: tuple
                table size
            """
            _w1 = w * sh.OCTAGON_RATIO
            _h1 = h * sh.OCTAGON_RATIO
            _w2 = w - _w1
            _h2 = h - _h1
            _w3 = w - _w1 - _w1
            _h3 = h - _h1 - _h1
            _s1 = (column - 1) * _w2 + w, (row - 1) * _h2 + h
            _x, _y = Shape.calc_pin_offset(
                o.pin_corner,
                s,
                _s1[0], _s1[1],
                x, y
            )
            _s1 = s[0] + _x, s[1] + _y

            for _ in range(row):
                for i in (_y, _y + _h1, _y + _h2, _y + h):
                    q_y.append(i)
                _y += h + _h3

            for _ in range(column):
                for i in (_x, _x + _w1, _x + _w2, _x + w):
                    q_x.append(i)
                _x += w + _w3
            return _s1

        def _get_intersects():
            """
            Get the points for a double-spaced octagon.

            Return: tuple
                of octagon offsets
            """
            _c1 = c // 2 * 4
            _r1 = r // 2 * 4

            if c % 2:
                _index_x = (c - 1) * 4 + 2 - _c1

            else:
                _index_x = c * 4 - _c1

            if r % 2:
                _index_y = (r - 1) * 4 + 2 - _r1
            else:
                _index_y = r * 4 - _r1
            return q_x[_index_x:_index_x+4], q_y[_index_y:_index_y+4]

        row, column = o.r, o.c
        table = o.model.table
        s = o.layer_space
        x, y = o.offset

        # intersect points
        q_x, q_y = [], []

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w, h = min(s[0], o.column_width / 1.), min(s[1], o.row_height / 1.)

        elif o.grid_type == gr.SHAPE_COUNT:
            w = s[0] / (sh.OCTAGON_RATIO + column * OCTAGON_REMAIN)
            h = s[1] / (sh.OCTAGON_RATIO + row * OCTAGON_REMAIN)
            w = min(w, h)
            w, h = w, w

        else:
            w = s[0] / (sh.OCTAGON_RATIO + column * OCTAGON_REMAIN)
            h = s[1] / (sh.OCTAGON_RATIO + row * OCTAGON_REMAIN)

        s1 = _calc_intersects()

        # Compose the points.
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(o.model, r, c):
                    q, q1 = _get_intersects()
                    position = q[0], q1[0]
                    size = q[3] - q[0], q1[3] - q1[0]

                    if size[0] > s1[0] or size[1] > s1[1]:
                        size = position = 0, 0

                    # Cell, 'a'
                    a = table[r][c]

                    # Is the cell rectangle before margins, 'cell'.
                    a.cell = Rect(position[0], position[1], size[0], size[1])
                    if size[0]:
                        a.shape = a.plaque = (
                            q[1], q1[0],
                            q[2], q1[0],
                            q[3], q1[1],
                            q[3], q1[2],
                            q[2], q1[3],
                            q[1], q1[3],
                            q[0], q1[2],
                            q[0], q1[1]
                        )
