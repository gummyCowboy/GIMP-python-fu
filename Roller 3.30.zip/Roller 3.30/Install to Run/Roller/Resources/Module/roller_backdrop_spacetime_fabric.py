#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_color_grid import ColorGrid
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Base, Hat
from roller_one_extract import Render
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
import gimpfu as fu

pdb = fu.pdb
WIND = "{} #{} of 40"
WIND1 = "{} #{} of 12"


class SpacetimeFabric:
    """Use wind to shred lines and make a fabric texture."""

    @staticmethod
    def do(o):
        """
        Create the Spacetime Fabric Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            with Spacetime Fabric
        """
        cat = Hat.cat
        j = cat.render.image

        # Backdrop Image layer, 'o.z'
        if Lay.has_pixel(o.z):
            # Spacetime Fabric Preset dict, 'd'
            d = o.d

            # Create a black and white checkerboard layer, 'z'.
            # Group key, 'o.k'
            d[ok.COLOR_2A] = (0, 0, 0, 255), (255, 255, 255, 255)
            z = ColorGrid.draw_color_grid(Lay.add(j, o.k), d)

            s = Render.size()
            w = s[0] // d[ok.COLUMN]
            h = s[1] // d[ok.ROW]
            w = min(w, h)
            w = max(1, w // 4)

            pdb.plug_in_edge(j, z, 10, 1, 4)

            for _ in range(w):
                Lay.dilate(z)

            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
            Sel.item(z)

            white_sel = cat.save_short_term_sel()

            pdb.gimp_selection_none(j)
            j.remove_layer(z)

            # Create three layers, one for each color.
            z = red = Lay.clone(o.z, n="Red")
            group = Lay.group(j, o.k, z=z)
            z = green = Lay.clone(z, n="Green")
            blue = Lay.clone(z, n="Blue")
            n = d[ok.COMPONENT]

            pdb.plug_in_colortoalpha(j, red, (0, 255, 255))
            pdb.plug_in_colortoalpha(j, green, (255, 0, 255))
            pdb.plug_in_colortoalpha(j, blue, (255, 255, 0))

            if n == "Red":
                z = red
                q = green, blue

            elif n == "Green":
                z = green
                q = red, blue

            else:
                z = blue
                q = red, green

            Sel.load(j, white_sel)
            Lay.clear_sel(z, keep_sel=True)
            pdb.gimp_selection_none(j)

            # Seal the strength of wind effect, 'w1'.
            w1 = Base.seal(w // 2, 2, 100)

            # loop feedback counter, 'x'
            x = 1

            # Shred the edges of the top layer.
            for i in range(10):
                # wind direction, 'i1'
                for i1 in range(4):
                    z.name = WIND.format(n, x)
                    x += 1

                    pdb.plug_in_wind(
                        j, z,
                        Fu.Wind.THRESHOLD_0,
                        i1,
                        w1,
                        Fu.Wind.BLAST,
                        Fu.Wind.LEADING_EDGE
                    )
                    Gegl.blur(z, 12)

            pdb.gimp_image_reorder_item(j, z, group, 0)

            # Add texture to the bottom layers.
            for z in q:
                # loop feedback counter, 'x'
                x = 1

                n = z.name
                for i in range(3):
                    for i1 in range(4):
                        z.name = WIND1.format(n, x)
                        x += 1

                        pdb.plug_in_wind(
                            j, z,
                            Fu.Wind.THRESHOLD_0,
                            i1,
                            (50, 25, 12)[i],
                            Fu.Wind.BLAST,
                            Fu.Wind.LEADING_EDGE
                        )

                z = Lay.clone(z, n="Burn")

                pdb.plug_in_engrave(j, z, i + 2, 1)

                z.mode = fu.LAYER_MODE_BURN
                pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            z = Lay.merge_group(group)

            if d[ok.EMBOSS]:
                group = Lay.group(j, o.k, z=z)
                z1 = Lay.clone(z, n="Emboss")

                pdb.plug_in_emboss(j, z1, cat.azimuth, 30., 1, 1)

                z1.mode = fu.LAYER_MODE_OVERLAY
                z = Lay.clone(z1, n="Grain Merge")
                z.mode = fu.LAYER_MODE_GRAIN_MERGE
                z = Lay.clone(z1, n="Difference")
                z.mode = fu.LAYER_MODE_DIFFERENCE
                z.opacity = 50.
                z = Lay.merge_group(group)
                pdb.gimp_drawable_invert(z, 0)
            return z
