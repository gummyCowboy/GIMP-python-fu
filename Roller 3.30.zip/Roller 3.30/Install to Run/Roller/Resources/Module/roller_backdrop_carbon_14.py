#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
mo = Fu.Mosaic


class Carbon14:
    """Create a Backdrop Style with layers of grungy mosaic tiles."""

    @staticmethod
    def do(o):
        """
        Make the Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            with Carbon 14
        """
        cat = Hat.cat
        j = cat.render.image

        # Carbon 14 Preset dict, 'd'
        d = o.d

        if d[ok.OPACITY]:
            size = d[ok.MESH_SIZE]
            group = Lay.group(j, o.k)

            # Group key, 'o.k'
            z = plasma_layer = Lay.add(j, o.k + " WIP")

            group1 = Lay.group(j, o.k, parent=group)

            pdb.gimp_image_reorder_item(j, z, group, 1)
            pdb.plug_in_plasma(j, z, d[ok.RANDOM_SEED], 3)

            # Create alternate textures for light and dark.
            z = lights = RenderHub.make_polar_mask(j, z)
            z = dark = RenderHub.make_polar_mask(j, z, is_dark=True)

            Gegl.saturation(z, .1)

            z = Lay.clone(lights, n="Darken Only")
            z.mode = fu.LAYER_MODE_LUMA_DARKEN_ONLY

            pdb.plug_in_emboss(j, z, cat.azimuth, 30, 1, 1)

            z = Lay.clone(dark, n="HSV Value")
            z.mode = fu.LAYER_MODE_HSV_VALUE

            Lay.blur(z, size * 2)
            pdb.gimp_edit_copy_visible(j)

            z = Lay.paste(z, n="Luma Lighten Only")
            z.mode = fu.LAYER_MODE_LUMA_LIGHTEN_ONLY
            z1 = Lay.merge_group(group1)

            pdb.plug_in_colortoalpha(j, z1, (255, 255, 255))
            pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

            z = z2 = Lay.clone(plasma_layer, n="Mosaic")

            pdb.gimp_image_reorder_item(j, z, group, 2)
            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
            pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
            pdb.plug_in_colortoalpha(j, z, (0, 0, 255))
            pdb.plug_in_colortoalpha(j, z, (0, 255, 0))
            pdb.plug_in_colortoalpha(j, z, (255, 0, 0))
            pdb.plug_in_mosaic(
                j, z,
                size,
                mo.TILE_HEIGHT_4,
                mo.TILE_SPACING_1,
                d[ok.NEATNESS],
                mo.NO_SPLIT,
                cat.azimuth,
                mo.MIN_COLOR_VARIATION,
                mo.YES_ANTIALIAS,
                mo.YES_COLOR_AVERAGING,
                bs.MESH_TYPE.index(d[ok.MESH_TYPE]),
                mo.SMOOTH_SURFACE,
                mo.BLACK_AND_WHITE_GROUT
            )

            z.mode = fu.LAYER_MODE_COLOR_ERASE
            z = plasma_layer

            Gegl.saturation(z, .0)
            Lay.blur(z, size)
            Gegl.emboss(z, cat.azimuth, cat.elevation, 1)
            Lay.hide(z1)
            pdb.gimp_edit_copy_visible(j)
            Lay.show(z1)

            z = Lay.paste(z2, n="HSL Color")
            z.mode = fu.LAYER_MODE_HSL_COLOR

            pdb.gimp_drawable_invert(z, 0)
            j.remove_layer(z2)

            z = Lay.merge_group(group)
            z1 = RenderHub.make_polar_mask(j, z)

            Gegl.saturation(z1, .3)
            Gegl.saturation(z, .3)

            z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
            z = Lay.clone(z, n="LCH Lightness")

            Gegl.edge(z)

            z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
            z.opacity = 80.
            z = Lay.merge(z)
            return RenderHub.finish_style(o, d, z, has_mode=True)
