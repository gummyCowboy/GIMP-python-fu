#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Group as gk, Widget as wk, Window as wi
from roller_option_group import OptionGroup
from roller_option_preset import Preset
from roller_option_preset_dict import PresetDict
from roller_port_preview import PortPreview
from roller_window import Window
from roller_window_save import RWSave


class RWStripe(Window):
    """Is a GTK Dialog for defining a Caption Background Stripe."""
    def __init__(self, g):
        """
        Create a Window.

        g: OptionButton
            Has a Preset dict as 'self.value'.
        """
        self.safe = g
        d = {
            wk.WIN: g.win.win,
            wk.WINDOW_KEY: wi.STRIPE,
            wk.WINDOW_TITLE: "Define Caption Background Stripe"
        }

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortStripe(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()


class PortStripe(PortPreview):
    """Make Widgets for a Caption Stripe Port."""

    def __init__(self, d, g):
        """
        Create the Port. Draw the Widgets.

        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_stripe_options(self, g):
        """
        Draw the option group.

        g: VBox
            container for the groups
        """
        k = gk.BACKGROUND_STRIPE
        d = OptionGroup.draw_group(
            **{
                wk.COLOR: self.color,
                wk.CONTAINER: g,
                wk.GROUP_KEY: k,
                wk.GROUP_TYPE: Preset,
                wk.HAS_PRESET: True,
                wk.IS_DEFAULT: False,
                wk.KEYS: PresetDict.get_keys(k),
                wk.ON_KEY_PRESS: self.on_key_press,
                wk.ON_PREVIEW_BUTTON: self.task_preview,
                wk.ON_WIDGET_CHANGE: self.on_widget_change,
                wk.STEP: (k,),
                wk.PORT: self,
                wk.SAVE_WINDOW: RWSave,
                wk.WIN: self.roller_window
            }
        )
        g = self.preset = d[wk.PRESET]
        self.group = g.group
        g.load_preset(self.safe.get_value())

    def draw_port(self, g):
        """
        Draw the Port's Widgets. Is part of the Port template.

        g: VBox
            container for the Widgets
        """
        self.draw_simple_dialog_port(
            g,
            (self._draw_stripe_options, self.draw_preview_process),
            ("Define Stripe", "")
        )

    def get_group_value(self):
        """
        Use to get the Preset value. Is a PortPreview template function.

        Return: dict
            Caption Stripe Preset
        """
        return self.preset.get_value()
