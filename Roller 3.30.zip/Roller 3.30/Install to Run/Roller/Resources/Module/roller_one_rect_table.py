#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import Base, Rect


class RectTable:
    """
    Create a cell table for a rectangular cell shape.
    Calculate the coordinates and the size of cells.
    Use a Rect object to store the position and size of a cell.
    """

    def __init__(self, s, row, column):
        """
        Calculate cell size. Access the cell
        table with the object's 'table' attribute.

        s: (w, h) of int
            size of the grid

        row, column: int
            row and column scale of the cell table
        """
        w = s[0] / 1. / column
        h = s[1] / 1. / row
        x = y = 0.
        q_y = []
        q_x = []
        q = self.table = Base.make_2d_table(row, column)

        for r in range(row + 1):
            q_y.append(int(round(y)))
            y += h

        for c in range(column + 1):
            q_x.append(int(round(x)))
            x += w
        for r in range(row):
            for c in range(column):
                y, y1 = q_y[r], q_y[r + 1]
                x, x1 = q_x[c], q_x[c + 1]
                q[r][c] = Rect(x, y, x1 - x, y1 - y)
