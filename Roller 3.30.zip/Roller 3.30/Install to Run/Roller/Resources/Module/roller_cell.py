#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import Rect


class Cell(object):
    """Use with a cell table to hold cell properties."""

    def __init__(self, r, c):
        """
        Is a cell attribute object.

        r, c: int
            cell index
        """
        # row and column cell table indices
        self.r, self.c = r, c

        # Rect
        # Has the topleft coordinate and the size of the cell.
        self.cell = None

        # Is an Image reference.
        self.image = ""

        # Rect
        # Use to store merged cell size.
        self.merge_cell = None

        # Is a Rect for Place.
        self.mold = None

        # tuple
        # Use with Plaque and Fringe to get cell shape without margin.
        self.plaque = None

        # Rect
        # Is the cell rectangle with margins.
        self.pocket = None

        # tuple
        # Use when rendering to get the cell shape within margins.
        self.shape = None

        # float
        # Use to change image layer palette order.
        self.z_image = .0


class BoxCell(Cell):
    """
    Use with Box model. Has additional properties for the polygons.
    """

    def __init__(self, r, c):
        """
        Initialize the object.

        r, c: int
            cell index in a cell table
        """
        Cell.__init__(self, r, c)

        # There are three polygons in each cell.
        # Polygons are defined with points.
        self.poly = None

        # There are three rectangles in each cell
        # one for each Box Face.
        # Rectangles are Rect objects.
        self.face_rect = None

        # There are three image size tuples that are calculated
        # from the face polygons and are used for placing images.
        self.image_size = None

        # one for each face
        self.mold = [Rect(), Rect(), Rect()]

        # Is the name of the image assigned to the Box / Cell / Face.
        self.image_name = ["", "", ""]
