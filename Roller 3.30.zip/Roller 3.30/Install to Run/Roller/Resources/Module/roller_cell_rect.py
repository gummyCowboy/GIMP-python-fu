#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_one import Rect
from roller_one_extract import Shape


class GridRect:
    """
    Calculate the position and the size of cells.
    The cells are rectangular shaped.
    """

    def __init__(self, o):
        """
        Calculate cell size for a rectangle shape.

        o: One
            Has init values.
        """
        row, column, table = o.r, o.c, o.model.table
        x, y = o.offset
        s = o.layer_space

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w, h = min(s[0], o.column_width / 1.), min(s[1], o.row_height / 1.)

            s1 = w * column, h * row
            w, h = w / 1., h / 1.
            x, y = Shape.calc_pin_offset(
                o.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        elif o.grid_type == gr.SHAPE_COUNT:
            w = s[0] // column
            h = s[1] // row
            w = min(w, h)
            s1 = w * column, w * row
            w, h = w, w
            x, y = Shape.calc_pin_offset(
                o.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            w = s[0] / 1. / column
            h = s[1] / 1. / row

        # intersect points
        q_y = []
        q_x = []

        for r in range(row + 1):
            q_y.append(round(y))
            y += h

        for c in range(column + 1):
            q_x.append(round(x))
            x += w
        for r in range(row):
            for c in range(column):
                y, y1 = q_y[r], q_y[r + 1]
                x, x1 = q_x[c], q_x[c + 1]
                position = x, y
                size = x1 - x, y1 - y

                # Cell, 'a'
                a = table[r][c]

                # Is the cell before margins, 'cell'.
                a.cell = Rect(position[0], position[1], size[0], size[1])

                x1, y1 = x + size[0], y + size[1]
                q = x, y, x1, y, x1, y1, x, y1
                a.shape = a.plaque = q
