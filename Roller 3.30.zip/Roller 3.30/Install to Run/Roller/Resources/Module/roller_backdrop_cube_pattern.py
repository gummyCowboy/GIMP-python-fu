#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import Base, Hat
from roller_constant_for import Gradient as fg
from roller_constant_key import Option as ok
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class CubePattern:
    """Create a cube pattern."""

    @staticmethod
    def do(o):
        """
        Do the Backdrop Style.

        o: One
            Has variables.

        Return: layer
            with Cube Pattern
        """
        def fill_it_():
            """Fill a layer with the clipboard image pattern."""
            RenderHub.set_fill_context(fg.FILL_DICT)
            pdb.gimp_context_set_pattern("Clipboard Image")
            pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, 0, 0)

        j = Hat.cat.render.image

        # Color Cube Preset dict, 'o.d'
        d = o.d

        # Group key, 'o.k'
        # layer name, 'n'
        n = o.k + " WIP"

        RenderHub.make_cube_pattern(
            d[ok.HEIGHT_CLIP],
            d[ok.COLOR_3A],
            d[ok.FLIP_VERTICAL]
        )

        if d[ok.ROTATE]:
            w = Base.circumradius(j.width, j.height) * 2
            j1 = pdb.gimp_image_new(w, w, fu.RGB)
            z = Lay.add(j1, o.k)

            fill_it_()

            Lay.rotate(j1, d[ok.ROTATE])
            pdb.gimp_edit_copy_visible(j1)
            pdb.gimp_image_delete(j1)

            # Backdrop Image layer, 'o.z'
            z = Lay.paste(o.z, n)

            pdb.gimp_layer_resize_to_image_size(z)

        else:
            # pattern layer, 'z'
            z = Lay.add(j, n)
            fill_it_()

        if d[ok.INVERT]:
            pdb.gimp_drawable_invert(z, 0)
        return RenderHub.finish_style(o, d, z, has_mode=True)
