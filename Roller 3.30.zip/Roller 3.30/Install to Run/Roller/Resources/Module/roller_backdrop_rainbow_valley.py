#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_fu import Fu
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat, One
from roller_one_fu import Lay
from roller_option_preset_dict import PresetDict
import gimpfu as fu

pdb = fu.pdb
sn = Fu.SolidNoise
LAYER_NUM = "#{} of {}"


class RainbowValley:
    """Fill the backdrop with a colorful abstract."""

    @staticmethod
    def do(o):
        """
        Create the Rainbow Valley Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            Has material.
        """
        def noise():
            """Adds noise to a layer."""
            if d[ok.POWER]:
                pdb.plug_in_solid_noise(
                    j, z,
                    sn.NO_TILEABLE,
                    sn.YES_TURBULENT,
                    d[ok.RANDOM_SEED],
                    sn.MEDIUM_DETAIL,
                    sn.HORIZONTAL_SIZE_2,
                    sn.VERTICAL_SIZE_2
                )
                pdb.plug_in_hsv_noise(
                    j, z,
                    Fu.HSVNoise.MEDIUM_HOLDNESS,
                    d[ok.POWER],
                    d[ok.POWER],
                    d[ok.POWER]
                )

        # Rainbow Valley Preset dict, 'o.d'
        d = o.d

        j = Hat.cat.render.image

        # Group key, 'o.k'
        group = Lay.group(j, o.k)

        n = d[ok.BACKDROP_TYPE]
        go = True

        if n == bs.BACKDROP_IMAGE:
            # If the Backdrop Image is empty,
            # Rainbow Valley will produce nothing.
            # Backdrop Image layer, 'o.z'
            if Lay.has_pixel(o.z):
                z = Lay.clone(o.z, n=o.k + " WIP")
                pdb.gimp_image_reorder_item(j, z, group, 0)
            else:
                go = False
                j.remove_layer(group)

        elif n == bs.PLASMA:
            z = Lay.add(j, o.k + " WIP", parent=group)
            pdb.plug_in_plasma(j, z, d[ok.RANDOM_SEED], 3)

        else:
            e = PresetDict.get_default(by.GRADIENT_FILL)
            e[ok.GRADIENT_TYPE] = d[ok.GRADIENT_TYPE]
            e[ok.GRADIENT] = d[ok.GRADIENT]

            if d[ok.GRADIENT_TYPE] == "Linear":
                e[ok.END_X] = e[ok.START_X] = .5
                e[ok.START_Y] = .0
                e[ok.END_Y] = 1.

            else:
                e[ok.START_X] = e[ok.START_Y] = .5
                e[ok.END_X] = e[ok.END_Y] = .0

            z = Lay.add(j, o.k + " WIP", parent=group)
            z = GradientFill.do_layer(j, One(d=e, z=z))

            pdb.gimp_image_reorder_item(j, z, group, 0)
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

        if go:
            # layer counter, 'x'
            x = 1

            # total layers to make, 'a'
            a = 15
            a += 8 if d[ok.TEXTURE] else 7

            for i in range(10):
                z = Lay.clone(z, n=LAYER_NUM.format(x, a))
                z.mode = fu.LAYER_MODE_DIFFERENCE

                pdb.plug_in_despeckle(j, z, i, 0, 0, 255)

                if i % 2:
                    x += 1
                    z = Lay.clone(z, n=LAYER_NUM.format(x, a))
                    z.mode = fu.LAYER_MODE_LIGHTEN_ONLY

                    noise()

                    d[ok.RANDOM_SEED] += 1

                    pdb.plug_in_despeckle(j, z, i, 0, 0, 255)
                    z = Lay.merge(z)

                is_engrave = False

                if d[ok.TEXTURE]:
                    if i < 7 or i == 9:
                        is_engrave = True

                elif i < 7:
                    is_engrave = True

                if is_engrave:
                    x += 1
                    z = Lay.clone(z, n=LAYER_NUM.format(x, a))

                    pdb.plug_in_engrave(j, z, max(i, 2), 1)

                    z.mode = fu.LAYER_MODE_BURN
                    z = Lay.merge(z)

                    pdb.plug_in_wind(
                        j, z,
                        Fu.Wind.THRESHOLD_0,
                        Fu.Wind.FROM_TOP,
                        Fu.Wind.STRENGTH_50,
                        Fu.Wind.BLAST,
                        Fu.Wind.LEADING_EDGE
                    )

                x += 1

            z = Lay.merge_group(group)

            if d[ok.EMBOSS]:
                z = Lay.clone(z, n="Overlay")
                z.mode = fu.LAYER_MODE_OVERLAY

                pdb.plug_in_emboss(j, z, Hat.cat.azimuth, 30., 1, 1)
                z = Lay.merge(z)
            return z
