#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, uniform
from roller_backdrop_color_grid import ColorGrid
from roller_constant_fu import Fu
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Base, Hat
from roller_one_fu import Lay
from roller_option_preset_dict import PresetDict
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
ed = Fu.Edge
er = Fu.Erode
um = Fu.UnsharpMask
wa = Fu.Waves


class GlassGaw:
    """Create a glassy grid with channels of liquid color."""

    @staticmethod
    def do(o):
        """
        Draw squiggly lines of translucent color.

        o: One
            Has variables.

        Return: layer or None
            with Glass Gaw
        """
        def do_grid(_merge):
            """
            Mix random grid overlays with waves.

            _merge: bool
                If it's true, the color grid layer
                is merged with the layer below.
            """
            def do_waves():
                """Do waves on a layer."""
                pdb.plug_in_waves(
                    j, _z,
                    randint(1, 12),
                    wa.PHASE_1,
                    uniform(24., 50.),
                    wa.SMEARED,
                    wa.USE_REFLECTION
                )

            e[ok.ROW] = randint(2, 6)
            e[ok.COLUMN] = randint(2, 6)
            e[ok.COLOR_2A] = Base.rnd_col() + (255,), Base.rnd_col() + (255,)
            _z = ColorGrid.draw_color_grid(Lay.add(j, "Grid", parent=group), e)
            _z.mode = fu.LAYER_MODE_DIFFERENCE

            do_waves()

            if _merge:
                _z = pdb.gimp_image_merge_down(j, _z, fu.CLIP_TO_IMAGE)
                do_waves()
            return _z

        cat = Hat.cat
        j = cat.render.image

        # Glass Gaw Preset dict, 'o.d'
        d = o.d

        if d[ok.OPACITY]:
            e = PresetDict.get_default(by.COLOR_GRID)

            # Backdrop Image layer, 'o.z'
            # Group key, 'o.k'
            z = Lay.clone(o.z, n=o.k)
            group = Lay.group(j, o.k + " Group 1 WIP", z=z)

            # Plant the seed that makes the style reproducible.
            cat.seed(d)

            for i in range(4):
                z1 = do_grid(i != 0)
                z = Lay.clone(z1, n="Grid " + str(i + 1))

            pdb.plug_in_edge(j, z, ed.AMOUNT_1, ed.NO_WRAP, ed.SOBEL)

            z2 = Lay.clone(z1, n="Difference")

            Lay.blur(z2, 20)

            z2.mode = fu.LAYER_MODE_DIFFERENCE
            z3 = Lay.clone(z2, n="Difference 2")
            z4 = Lay.clone(z3, n="Grain Extract")
            z4.mode = fu.LAYER_MODE_GRAIN_EXTRACT
            z.mode = fu.LAYER_MODE_DARKEN_ONLY

            pdb.gimp_drawable_invert(z, 0)
            Lay.blur(z, 4)
            pdb.plug_in_unsharp_mask(
                j, z1,
                um.RADIUS_3,
                um.AMOUNT_POINT_16,
                um.THRESHOLD_0
            )

            group1 = Lay.group(j, o.k + " Group 2 WIP")

            for i in (z1, z3, z2, z4, z):
                pdb.gimp_image_reorder_item(j, i, group1, 0)

            z5 = Lay.clone(z, n="Erode")

            for _ in range(2):
                pdb.plug_in_erode(
                    j, z5,
                    er.PROPAGATE_BLACK,
                    er.RGB_CHANNELS,
                    er.FULL_RATE,
                    er.DIRECTION_MASK_7,
                    er.LOW_LIMIT_0,
                    er.UPPER_LIMIT_128
                )

            Lay.blur(z5, 90)
            j.remove_layer(group)

            z5.mode = fu.LAYER_MODE_MULTIPLY
            z = Lay.merge_group(group1)
            return RenderHub.finish_style(o, d, z, has_mode=True)
