#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Widget as fw
from roller_constant_key import Button as bk, Widget as wk
from roller_one import Hat
from roller_one_draw import Draw
from roller_option_preset import PerCell
from roller_port import Port
from roller_widget_button import Button, PreviewButton
import gtk


class PortPreview(Port):
    """Make previews possible in satellite Windows."""

    def __init__(self, d, g):
        """
        Initialize variables.

        d: dict
            Has init values.

        g: OptionButton
            Has option values.
        """
        # a relay
        self._accept_preview_port = d[wk.ON_ACCEPT]
        self._cancel_preview_port = d[wk.ON_CANCEL]
        d[wk.ON_ACCEPT] = self.accept_preview
        d[wk.ON_CANCEL] = self._cancel

        # Is a Button or a PerCellGroup. Has the option data.
        self.safe = g

        self._previewer = g.on_preview_button
        self._previous_value = g.get_value()
        self._original_value = deepcopy(self._previous_value)
        self._preview_button = None
        step = g.group.step
        self._safe_group = g.group
        e = Hat.cat.group_dict

        if e[step].group_type == PerCell:
            step = step[:-1] + ((str(step[-1]).replace(", Per Cell", '')),)
            self._safe_group = e[step]
        Port.__init__(self, d)

    def accept_preview(self, *_):
        """
        Respond to an Accept action from the Port.
        Set the option group as changed if that is the case.

        a: value
            of options from an OptionButton

        Return: True
            from the relay
            for the GTK event handler
        """
        self._safe_group.unseen = True
        a = self.get_group_value()

        self._set_change(a)
        return self._accept_preview_port(a)

    def _cancel(self, *_):
        """
        Respond to a Cancel action from the Port.
        Set the option group as changed if that is the case.
        Restore the OptionButton value to its original value.

        Return: True or None
            from the relay
            for the GTK event handler
        """
        a = self._original_value
        self._set_change(a)
        self.safe.set_value(a)
        return self._cancel_preview_port()

    def _set_change(self, a):
        """
        Mark the Button's option group as changed.

        a: string or dict
            Button value
        """
        if self._previous_value != a:
            self._safe_group.changed = self._safe_group.unseen = True

    def draw_preview_process(self, g):
        """
        Draw the process group with an additional Preview Button.

        g: VBox
            container for Widgets
        """
        def on_action(_g):
            if _g.key == bk.CANCEL:
                return self._cancel()

            elif _g.key == bk.ACCEPT:
                return self.accept_preview()
            else:
                self.task_preview(_g)

        w = fw.MARGIN // 2
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        hbox = gtk.HBox()
        d = {
            wk.ALIGN: (0, 0, 1, 0),
            wk.GROUP: self.group,
            wk.ON_WIDGET_CHANGE: on_action,
            wk.KEY: bk.CANCEL,
            wk.TEXT: bk.CANCEL,
            wk.PADDING: (w, w, w, w)
        }
        g1 = Button(**d)
        d[wk.PADDING] = w, w, w, w
        d[wk.ON_PREVIEW_BUTTON] = self.task_preview
        g2 = self._preview_button = PreviewButton(**d)
        d[wk.KEY] = d[wk.TEXT] = bk.ACCEPT
        d[wk.PADDING] = w, w, w, w
        g3 = Button(**d)

        for i in (g1, g2, g3):
            hbox.pack_start(i, expand=1)
            same_size.add_widget(i.widget)

        self.keep((g1, g3))
        g.add(hbox)

    def on_widget_change(self, g):
        """
        Relay a change event from the Port's Widgets.
        Set the sensitivity of the Preview Button.

        g: Widget
            Is responsible for the change event.

        Return: True
            for the GTK event handler
        """
        if self._preview_button and not Draw.load_count:
            self._preview_button.set_sensitive(1)
        return True

    def task_preview(self, g, *_):
        """
        Create a preview. Set the OptionButton's
        value to the Port's value.
        Remember Port's value as a last used value.

        g: PreviewButton
            Is responsible.

        _: OptionGroup
            not used
        """
        a = self.get_group_value()

        self._set_change(a)

        self._previous_value = deepcopy(a)

        self.safe.set_value(a)
        self._previewer(g, self._safe_group)
