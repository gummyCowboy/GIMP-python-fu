#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Base, Hat, One
from roller_one_extract import Canvas, Render
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import colorsys
import gimpfu as fu

pdb = fu.pdb
is_preview = False


def do_diagonal(d, z, color, s):
    """
    Sample colors and return a gradient's start and end points.

    d: dict
        Has options.

    z: layer
        of Backdrop Image

    color: list
        of sampled color

    s: tuple
        width, height of render

    return: tuple
        start point, end point
    """
    a = d[ok.SAMPLE_POINTS]
    q = get_diagonal_points(d, a, s)

    for i in range(a):
        x, y = q[i]
        color[i] = pick_color(d, z, x, y)

    u = q[0][0] / 1. / s[0], q[0][1] / 1. / s[1]
    v = q[-1][0] / 1. / s[0], q[-1][1] / 1. / s[1]
    return (0, u[0]), (0, u[1]), (0, v[0]), (0, v[1])


def do_horizontal(d, z, color, s):
    """
    Sample colors and return a gradient's start and end points.

    d: dict
        Has options.

    z: layer
        of Backdrop Image

    color: list
        of sampled color

    s: tuple
        width, height of render

    return: tuple
        start point, end point
    """
    a = d[ok.SAMPLE_POINTS]
    q = get_horizontal_points(d, a, s)

    for i in range(a):
        x, y = q[i]
        color[i] = pick_color(d, z, x, y)
    return (0, .0), (0, .5), (0, 1.), (0, .5)


def do_vertical(d, z, color, s):
    """
    Sample colors and return a gradient's start and end points.

    d: dict
        Has options.

    z: layer
        of Backdrop Image

    color: list
        of sampled color

    s: tuple
        width, height of render

    return: tuple
        start point, end point
    """
    a = d[ok.SAMPLE_POINTS]
    q = get_vertical_points(d, a, s)

    for i in range(a):
        x, y = q[i]
        color[i] = pick_color(d, z, x, y)
    return (0, .5), (0, .0), (0, .5), (0, 1.)


def get_horizontal_points(d, a, s):
    """
    Get the sample points for the horizontal vector.

    d: dict
        Has options.

    a: int
        sample point count

    s: tuple
        width, height of render

    return: list
        of sample point coordinate
    """
    x = 0
    f = Canvas.get_factor_h(d[ok.START_Y])
    y = int(f)
    q = []
    w = s[0] // (a + 1)

    for i in range(a):
        x = min(x + w, s[0] - 1)
        q.append((x, y))
    return q


def get_diagonal_points(d, a, s):
    """
    Get the sample points for the topleft vector.

    d: dict
        Has options.

    a: int
        sample point count

    s: tuple
        width, height of render

    return: list
        of sample point coordinate
    """
    f = d[ok.DIAGONAL_ROTATION]
    x, y = RenderHub.get_point_on_rectangle(s, f)
    x1, y1 = RenderHub.get_point_on_rectangle(s, f + 180)
    q = []
    b = a + 1

    # run, rise of slope
    w = (x1 - x) / b
    h = (y1 - y) / b

    for i in range(a):
        x = min(x + w, s[0] - 1)
        y = min(y + h, s[1] - 1)
        q.append((x, y))
    return q


def get_vertical_points(d, a, s):
    """
    Get the sample points for the vertical vector.

    d: dict
        Has options.

    a: int
        sample point count

    s: tuple
        width, height of render

    return: list
        of sample point coordinate
    """
    f = Canvas.get_factor_w(d[ok.START_X])
    x = int(f)
    y = 0
    q = []
    h = s[1] // (a + 1)

    for i in range(a):
        y = min(y + h, s[1] - 1)
        q.append((x, y))
    return q


def pick_color(d, z, x, y):
    """
    Pick a color from the canvas.

    d: dict
        Has options.

    z: layer
        the backdrop image

    x, y: int
        coordinate to pick from

    Return: color
        the color
        RGBA
    """
    # In GIMP 2.10.30,
    # 'pdb.gimp_image_pick_color' Is supposed to get
    # the average color, but the calculations are off
    # by as much as 50%. The error appears to magnify
    # as the radius grows.
    return pdb.gimp_image_pick_color(
        z.image, z,
        float(x), float(y),
        Fu.PickColor.NO_SAMPLE_MERGED,
        Fu.PickColor.YES_SAMPLE_RADIUS,
        d[ok.SAMPLE_RADIUS]
    )


def show_preview(z, d, a, x, option_group, color, s):
    """
    Show a preview with the sample areas filled with sampled colors.

    z: layer
        of Backdrop Image

    d: dict
        ImageGradient Preset

    a: int
        sample point count

    x: int
        vector index

    color: list
        of sampled color

    option_group: dict
        Has a change flag.

    s: tuple
        width, height of render
    """
    j = Hat.cat.render.image
    group = Lay.group(j, "Preview")

    pdb.gimp_selection_none(j)
    pdb.gimp_context_set_foreground((0, 0, 0))

    # Keep RenderProduct from removing the preview.
    option_group.changed = True

    q = (
        get_vertical_points,
        get_horizontal_points,
        get_diagonal_points
    )[x](d, a, s)

    # Set 'color'.
    GET_POINTS[x](d, z, color, s)

    w = d[ok.SAMPLE_RADIUS]
    w1 = w + w
    w2 = w + 1
    w3 = w2 * 2

    # Draw a line.
    line = q[0][0], q[0][1], q[-1][0], q[-1][1]
    line_layer = Lay.add(j, "Line", parent=group)
    sample_layer = Lay.add(j, "Sample", parent=group)
    color1 = color

    RenderHub.set_brush_details()
    pdb.gimp_paintbrush_default(line_layer, len(line), line)

    for x1, u in enumerate(q):
        x, y = u
        r, g, b, alpha = [(i / 255.) for i in color1[x1]]
        hsv = colorsys.rgb_to_hsv(r, g, b)
        color = (0, 0, 0) if hsv[2] > .5 else (255, 255, 255)

        if alpha < 1.:
            z = Lay.add(j, "Alpha", parent=group)
            z1 = Lay.add(j, "Alpha 2", parent=group)
            z1.opacity = 100. * alpha

        else:
            z = z1 = sample_layer

        Sel.ellipse(j, x - w2, y - w2, w3, w3, fu.CHANNEL_OP_REPLACE)
        Sel.fill(z, color)
        Sel.ellipse(j, x - w, y - w, w1, w1, fu.CHANNEL_OP_REPLACE)

        if z1.opacity:
            Sel.fill(z1, (r, g, b))
        if z1.opacity < 100.:
            # Remove the material as it is visible when semi-opaque.
            Lay.clear_sel(line_layer, keep_sel=True)
            Lay.clear_sel(z)
    return Lay.merge_group(group)


GET_POINTS = do_vertical, do_horizontal, do_diagonal


class ImageGradient:
    """Create a gradient from an image."""

    # Use to clear a previous gradient sample.
    grad = None

    @staticmethod
    def do(o):
        """
        Create an Image Gradient Backdrop Style.

        The ImageGradient's Preview button does not disable
        if the preview mode is set to Show Samples.

        o: One
            Has variables.

        Return: layer or None
            with Image Gradient
        """
        global is_preview

        cat = Hat.cat
        s = Render.size()

        # ImageGradient Preset dict, 'd'
        d = o.d

        # Backdrop Style layer, 'z'
        z = o.z

        if Lay.has_pixel(z) and d[ok.OPACITY]:
            a = d[ok.SAMPLE_POINTS]

            # gradient Preset dict, 'e'
            e = deepcopy(d)

            e[ok.OFFSET] = 0
            color = [0] * a
            x = bs.VECTOR.index(d[ok.SAMPLE_VECTOR])
            is_preview = Hat.dog.product.is_preview

            # Preserve.
            q = pdb.gimp_context_get_foreground()

            pdb.gimp_context_set_sample_transparent(1)

            if d[ok.PREVIEW_MODE] == bs.SHOW_SAMPLE and is_preview:
                z = show_preview(z, d, a, x, cat.group_dict[o.step], color, s)

            else:
                z = ImageGradient.show_gradient(z, d, e, a, x, color, s)

                Lay.clone(o.z)

                z = Lay.merge(z)
                z = RenderHub.bump(z, d[ok.BUMP])

            # Restore.
            pdb.gimp_context_set_foreground(q)

            return z

    @staticmethod
    def show_gradient(z, d, e, a, x, color, s):
        """
        Draw the Image Gradient.

        z: layer
            with Backdrop Image

        d: dict
            ImageGradient Preset

        e: dict
            modified options for drawing gradient

        a: int
            sample points

        x: int
            sample vector index

        s: tuple
            width, height of render
        """
        cat = Hat.cat
        create_q = cat.image_gradients_created

        if ImageGradient.grad:
            if ImageGradient.grad in create_q:
                create_q.pop(create_q.index(ImageGradient.grad))

            pdb.gimp_gradient_delete(ImageGradient.grad)
            ImageGradient.grad = None

        gradients = Hat.cat.gradient_list

        # gradient name, 'n'
        n = d[ok.NAME]

        # The option name is needed in the gradient list so that
        # 'RenderHub.set_gradient' will pass the gradient-exists test.
        if n in gradients:
            n = Base.enumerate_name(n, gradients)

        gradients += [n]
        ImageGradient.grad = e[ok.GRADIENT] = pdb.gimp_gradient_new(n)

        if a > 2:
            pdb.gimp_gradient_segment_range_split_uniform(
                ImageGradient.grad,
                0,
                0,
                a - 1
            )

        # Set 'color'.
        e[ok.START_X], e[ok.START_Y], e[ok.END_X], e[ok.END_Y] = \
            GET_POINTS[x](e, z, color, s)

        for x in range(a - 1):
            opacity = color[x].alpha * 100.

            pdb.gimp_gradient_segment_set_left_color(
                ImageGradient.grad,
                x,
                color[x],
                opacity
            )

            opacity = color[x + 1].alpha * 100.
            pdb.gimp_gradient_segment_set_right_color(
                ImageGradient.grad,
                x,
                color[x + 1],
                opacity
            )

        # gradient layer, 'z'
        z = GradientFill.do_layer(z.image, One(d=e, k="Gradient"))

        if d[ok.KEEP_GRADIENT]:
            # Store image gradients so they can
            # be deleted before the program closes.
            create_q.append(ImageGradient.grad)

            # The gradient is kept. The gradient is
            # saved to a file when GIMP closes.
            Hat.cat.image_gradient_used = ImageGradient.grad

        else:
            pdb.gimp_gradient_delete(ImageGradient.grad)
            ImageGradient.grad = None

        gradients.pop(-1)
        return z
