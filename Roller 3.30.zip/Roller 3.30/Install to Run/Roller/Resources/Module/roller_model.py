#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import (
    Grid as gr,
    Group as og,
    Shape as sh,
    Triangle as ft
)
from roller_constant_key import (
    Group as gk,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_one import Hat, Rect
from roller_one_extract import dispatch, Form, Render, Shape, Step
from roller_cell import BoxCell, Cell
from roller_cell_box_horz import BoxHorz
from roller_cell_box_vert import BoxVert
from roller_cell_circle import GridCircle
from roller_cell_rhombus import GridRhombus
from roller_cell_ellipse import GridEllipse
from roller_cell_ellipse_horz import EllipsisHorz
from roller_cell_ellipse_vert import EllipsisVert
from roller_cell_hexagon_regular import HexagonRegular
from roller_cell_hexagon_truncated import HexagonTruncated
from roller_cell_octagon import GridOctagon
from roller_cell_octagon_double import GridOctagonDouble
from roller_cell_rect import GridRect
from roller_cell_triangle_horz import TriangleHorz
from roller_cell_triangle_vert import TriangleVert
from roller_model_box import Box as bx
from roller_one import One, Base

# Use to convert a shape descriptor to a Shape-making class.
SHAPES = {
    sh.BOX_HORZ: BoxHorz,
    sh.BOX_HORZ_SHEAR: BoxHorz,
    sh.BOX_VERT: BoxVert,
    sh.BOX_VERT_SHEAR: BoxVert,
    sh.CIRCLE_HORIZONTAL: GridCircle,
    sh.CIRCLE_VERTICAL: GridCircle,
    sh.ELLIPSE: GridEllipse,
    sh.ELLIPSE_HORIZONTAL: EllipsisHorz,
    sh.ELLIPSE_VERTICAL: EllipsisVert,
    sh.HEXAGON_REGULAR: HexagonRegular,
    sh.HEXAGON_REGULAR_SHEAR: HexagonRegular,
    sh.HEXAGON_TRUNCATED: HexagonTruncated,
    sh.HEXAGON_TRUNCATED_SHEAR: HexagonTruncated,
    sh.OCTAGON_DOUBLE_REGULAR: GridOctagonDouble,
    sh.OCTAGON_DOUBLE_SHEAR: GridOctagonDouble,
    sh.OCTAGON_SHEAR: GridOctagon,
    sh.OCTAGON_REGULAR: GridOctagon,
    sh.OCTAGON_SIDE_TO_SIDE_REGULAR: GridOctagon,
    sh.OCTAGON_SIDE_TO_SIDE_SHEAR: GridOctagon,
    sh.RECTANGLE: GridRect,
    sh.RHOMBUS: GridRhombus,
    sh.RHOMBUS_SHEAR: GridRhombus,
    sh.SQUARE: GridRect,
    ft.TRIANGLE_DOWN_SHEAR: TriangleVert,
    ft.TRIANGLE_DOWN_ISOSCELES: TriangleVert,
    ft.TRIANGLE_UP_SHEAR: TriangleVert,
    ft.TRIANGLE_UP_ISOSCELES: TriangleVert,
    ft.TRIANGLE_LEFT_SHEAR: TriangleHorz,
    ft.TRIANGLE_LEFT_ISOSCELES: TriangleHorz,
    ft.TRIANGLE_RIGHT_SHEAR: TriangleHorz,
    ft.TRIANGLE_RIGHT_ISOSCELES: TriangleHorz
}


def contract_cell_table(q, row, col):
    """
    Contract a Per Cell cell table a to correspond with a Model's Cell
    Type dict. Check the cell table r list-size overflow.

    q: 2D list
        of cell table

    row, col: int
        cell table size
        row, column span
    """
    if q:
        r = len(q)

        if r > row:
            # Remove rows.
            for _ in range(r - row):
                q.pop()
        for r in range(len(q)):
            c = len(q[r])
            if c > col:
                # Remove columns.
                for _ in range(c - col):
                    q[r].pop()


def correct_contracted_cells(q, row, col):
    """
    Use with a Table Model's Type cell table When cells
    contract, the list-size shrinks. This causes some
    of the cut-off cells to become independent, '(1, 1)'.

    q: 2D list
        of cell table

    row, col: int
        cell table size
        row, column span
    """
    if q:
        r, c = row, col
        r1 = len(q)
        for r2 in range(r1):
            for c1 in range(len(q[r2])):
                if r2 >= r or c1 >= c:
                    q[r2][c1] = 1, 1
    return q


def correct_merge_overflow(s, row, col, r, c):
    """
    Use with a Table Model's Type cell table. Check
    if the cell table has contracted. If so then the effected
    topleft cell needs its dimensions checked for overflow.

    s: tuple of int (w, h)
        group dimension

    row, col: int
        max location

    r, c: int
        current location
    """
    if s[0] + r > row:
        s = row - r, s[1]

    if s[1] + c > col:
        s = s[0], col - c
    return s


def expand_cell_table(q, row, col, a):
    """
    Expand a cell table based on the row and column
    counts. During an expansion, values are inserted
    into a cell table from its form option group.

    q: 2D list
        cell table

    row, col: int
        cell table size
        row, column span

    a: value
        to initialize the cell table

    Return: list
        of cell table
    """
    if not q:
        q = Base.make_2d_table(row, col, init=a, deep=True)

    else:
        # current row count, 'r'
        r = len(q)

        if r < row:
            e = []

            for _ in range(col):
                e.append(deepcopy(a))
            for r1 in range(row - r):
                # Add a row with a new list.
                q.append(deepcopy(e))
        for r1 in range(row):
            c = len(q[r1])
            if c < col:
                for _ in range(col - c):
                    # Add a column.
                    q[r1].append(deepcopy(a))
    return q


def fix_cell_table_size(q, r, c, a):
    """
    A cell table may expand or contract depending on the cell table size.

    q: 2D list
        a cell table
        of option values

    r, c: int
        row, column span of cell table

    a: value
        to initialize cell table

    Return: list
        of cells
        2D
        lists within a list
    """
    q = expand_cell_table(q, r, c, a)

    contract_cell_table(q, r, c)
    return q


def fix_merge_cells(q, row, col):
    """
    The Table Model's merge cell dimensions may overflow if a
    cell table contracts in size. Correct the overflow references by
    reducing the merge-cell block dimensions stored in topleft cells.

    q: list
        a cell table

    row, col: int
        cell table span
    """
    if q:
        for r in range(row):
            for c in range(col):
                if r < len(q):
                    if c < len(q[r]):
                        q[r][c] = correct_merge_overflow(
                            q[r][c],
                            row, col,
                            r, c
                        )
    q = correct_contracted_cells(q, row, col)
    return q


def fix_table(step, r, c, k):
    """
    Fix the scale of a Per Cell option group's cell table.
    A Per Cell Widget has a its own cell table.

    step: tuple
        step prefix created from the model

    r, c: int
        cell index

    k: string
        Per Cell option group key
    """
    d = Hat.cat.group_dict

    # Is a timing issue, where the step's option group hasn't been initialized.
    if step in d:
        g = d[step].per_cell_group
        if g:
            if g.check_button.get_value():
                d1 = Step.get_dict_from_step(step)
                table = d1[ok.PER_CELL]

                if k == gk.PER_CELL_TYPE:
                    table = fix_cell_table_size(table, r, c, (1, 1))
                    table = fix_merge_cells(table, r, c)

                else:
                    d1.pop(ok.PER_CELL)
                    table = fix_cell_table_size(table, r, c, d1)
                g.set_value(table)


class Model:
    """Has functions and variables common to sub-Model classes."""

    def __init__(self, o):
        """
        Initialize variables.

        o: One
            Has init variables.

        cell attributes
            image: Image assigned
            image_name: string, name of image assigned
            merge_cell: rectangle of merge-cell; Used by Table.
            mold: rectangle of image that was placed
            plaque: cell shape with margins
            pocket: rectangle of a cell with margins
            rect: rectangle of a cell
            shape: cell shape
        """
        self.d = self.rect = self.table = self.cell_shape = None
        self.canvas_margin = 0, 0, 0, 0
        self.double_type = sh.NOT_DOUBLE_SPACE
        self.step = o.step if hasattr(o, wk.STEP) else None
        self.add_shift_x = \
            self.add_shift_y = \
            self.add_shift_rotate = \
            self.add_shift_w = \
            self.add_shift_h = \
            self.is_merge_cell = \
            self.is_regular_shape = \
            self.is_not_rectangular = \
            self.is_rectangle = False

        # default
        self.division = 1, 1

    def get_normal_type(self):
        """
        Determine if the cell shape is a normal type. Normal
        types have symmetry in the length of their sides.

        Return: bool
            Is true if the cell shape is a normal type.
        """
        return self.cell_shape in sh.NORMAL_TYPE

    def get_rotation(self, r, c):
        """
        Get the rotation angle for a given cell. Is calculated
        with the Shift Preset options in the Place Preset.

        r, c: int
            cell index

        Return: float
            rotation
        """
        return self.table[r][c].rotation

    def get_cell_position(self, r, c):
        """
        Get a cell's position.

        r, c: int
            cell index

        Return: tuple
            position of cell
            x, y
        """
        return self.table[r][c].cell.position

    def get_cell_rect(self, r, c):
        """
        Get a cell's rectangle.

        table: list
            of cells

        r, c: int
            cell index

        Return: Rect
            of cell
        """
        return self.table[r][c].cell.clone()

    def get_image(self, r, c):
        """
        Get the image assigned to a cell.

        r, c: int
            cell index

        Return: Image or None
            as assigned
        """
        a = self.table[r][c]
        if hasattr(a, 'image'):
            return a.image

    def get_image_name(self, r, c):
        """
        Get the name of an image assigned to a cell.

        r, c: int
            cell index

        Return: string or None
            an image name
        """
        a = self.table[r][c]
        if hasattr(a, 'image_name'):
            return a.image_name

    def get_merge_cell_rect(self, r, c):
        """
        Get a cell's size in the context of possible merge-cell.

        r, c: int
            cell index

        Return: tuple
            cell indices, cell dimensions
            x, y, w, h
        """
        return self.table[r][c].merge_cell.clone()

    def get_mold(self, r, c):
        """
        Mold is a rectangle used by the last step when placing an image.

        r, c: int
            cell index

        Return: Rect
            of mold
            the rectangle for the final image placement
        """
        return self.table[r][c].mold.clone()

    def get_plaque(self, r, c):
        """
        Get a cell's Plaque value. Is a usually a
        tuple of points, but may be a dictionary.

        r, c: int
            cell index

        Return: tuple or dict
            for drawing a Plaque polygon
        """
        return self.table[r][c].plaque

    def get_pocket(self, r, c):
        """
        Get the cell pocket.

        r, c: int
            cell index

        Return: Rect
            of mold
            the rectangle of the cell with margins
        """
        return self.table[r][c].pocket.clone()

    def get_cell_definition(self, d, r, c):
        """
        Get the Cell Plaque or shape and the Cell Rect
        or cell pocket for a Preset with a Obey Margins option.

        d: dict
            Preset

        r, c: int
            Cell index

        Return: tuple
            (Rect, tuple)
            (cell bounds, for drawing a Plaque/shape)
        """
        if d[ok.OBEY_MARGINS]:
            a = self.get_pocket(r, c)
            b = self.get_shape(r, c)

        else:
            a = self.get_cell_rect(r, c)
            b = self.get_plaque(r, c)
        return a, b

    def get_shape(self, r, c):
        """
        Get the shape tuple or dict. Ellipse
        shapes are represented by a dictionary.
        The other shapes are in a list or a tuple.

        r, c: int
            cell index

        Return: object
            of shape
        """
        return self.table[r][c].shape

    def get_z_height(self, r, c):
        """
        Get the z-height of an image layer from its cell index.

        r, c: int
            cell index
        """
        return self.table[r][c].z_height

    def set_image(self, r, c, j):
        """
        Store the image assigned to a cell.

        r, c: int
            cell index

        j: Image
            as assigned
        """
        self.table[r][c].image = j

    def set_image_name(self, r, c, n):
        """
        Store the image name assigned to a cell.

        r, c: int
            cell index

        n: string
            image name
        """
        self.table[r][c].image_name = n

    def set_mold(self, r, c, x, y, w, h):
        """
        Set the 'mold' position. The 'mold' is a rectangle
        used by the final step when placing an image.

        x, y: int
            screen coordinate
            topleft corner of the rectangle

        w, h: int
            size of the rectangle
        """
        self.table[r][c].mold = Rect(x, y, w, h)

    def set_plaque(self, r, c, a):
        """
        Update a cell Plaque. Is used when drawing or mapping a Plaque polygon.

        r, c: int
            cell index

        a: value
            plaque
        """
        self.table[r][c].plaque = a

    def set_rotation(self, r, c, f):
        """
        Store angle rotation, with jitter, for an image in a cell.

        r, c: int
            cell index

        f: float
            Has combined rotation and jitter.
        """
        self.table[r][c].rotation = f

    def set_z_height(self, r, c, a):
        """
        Update a z-height value for a cell.

        r, c: int
            cell index

        a: int
            designated z-shift
        """
        self.table[r][c].z_height = a

    def update_rectangle(self, o):
        """
        Update the cell rectangle for a single-cell-type
        of Model, (i.e. Stack or Custom Cell).

        o: One
            d: dict, rectangle preset
        """
        self.rect = Form.get_cell_rect(o.d)

    def update_pocket(self, r, c, x, y, w, h, is_margin):
        """
        Set the pocket rectangle and, if needed, update the shape.

        r, c: int
            cell index

        x, y: int
            the pocket's canvas coordinate
            the topleft corner of the pocket

        w, h: int
            pocket dimension

        is_margin: bool
            Is true when the cell has a cell margin.
        """
        # a Cell, 'a'
        a = self.table[r][c]

        b = a.pocket = Rect(x, y, w, h)

        # Update the cell shape if the pocket size has changed.
        if is_margin:
            n = self.cell_shape
            a.shape = dispatch[n](b)


class CustomCell(Model):
    """Is a single cell Model with one potential image."""

    def __init__(self, o):
        """
        Initialize the table.

        o: One
            Has variables.
        """
        Model.__init__(self, o)

    def _calc_cell(self):
        """Calculate the cell size for the cell table."""
        a = self.table[0][0]

        a.shape = a.plaque = dispatch[self.cell_shape](self.rect)
        a.cell = self.rect.clone()

    def calc_pocket(self, o):
        """
        Calculate the pocket, plaque, and shape.

        o: One
            d: dict
                Cell Margin Preset with its Per Cell cell table
        """
        q = top, bottom, left, right = Form.calc_margin(o.d, *Render.size())
        x, y = self.rect.position
        w, h = self.rect.size
        is_margin = False

        if any(q):
            is_margin = True
            x += left
            y += top
            w = max(w - left - right, 1)
            h = max(h - top - bottom, 1)

        shape = dispatch[self.cell_shape](Rect(x, y, w, h))

        # The pocket size will change if the cell shape is normalized.
        if self.is_regular_shape and is_margin:
            x, y, w, h = Shape.bounds(shape)

        self.update_pocket(0, 0, x, y, w, h, is_margin)

    def clone(self):
        """
        Make a copy of a CustomCell instance.

        Return: CustomCell
            a copy of self
        """
        a = CustomCell(One())

        # Copy the attributes.
        Base.deep_update(a.__dict__, self.__dict__)
        return a

    def update_cell_rect(self, o):
        """
        Update the Custom Cell given a Rectangle Preset dict.

        o: One
            d: dict
                Rectangle Preset dict
        """
        # Rectangle Preset dict, 'd'
        self.d = o.d

        self.update_rectangle(o)

        table = self.table = Base.make_2d_table(1, 1)
        self.table[0][0] = Cell(0, 0)

        self._calc_cell()

        # The merge cell rectangle is the same as the cell rectangle.
        table[0][0].merge_cell = table[0][0].cell.clone()

    def update_type(self, o):
        """
        Update the cell shape and related variables.

        o: One
            Has variables.
        """
        self.cell_shape = o.d[ok.CUSTOM_CELL_SHAPE]
        self.is_rectangle = self.cell_shape == sh.RECTANGLE
        self.is_regular_shape = self.get_normal_type()
        self.is_not_rectangular = not Shape.is_rectangular_shape(
            self.cell_shape
        )


class Grid(Model):
    """Use with Models with the potential for multiple row and columns."""

    def __init__(self, o):
        """
        Initialize a cell table.

        o: One
            Has variables.
        """
        Model.__init__(self, o)

    def _calc_cell(self):
        """Calculate the cell sizes for the cell table."""
        # Type Preset dict, 'self.d'
        e = self.d

        size = Render.size()
        top, bottom, left, right = self.canvas_margin
        o = One(
            double_type=self.double_type,
            model=self,
            is_table=True,
            offset=(left, top)
        )
        o.r, o.c = self.division
        o.layer_space = (
            Base.seal(size[0] - left - right, 1, size[0]),
            Base.seal(size[1] - top - bottom, 1, size[1])
        )

        for k, a in e.items():
            k1 = k.lower().replace(" ", "_")
            setattr(o, k1, a)
        SHAPES[self.cell_shape](o)

    @staticmethod
    def fix_tables(step, r, c):
        """
        Fix the scale of the Per Cell cell tables.
        Each Per Cell Widget has a its own cell table.

        step: tuple
            with a Model reference in a prefix-tuple

        r, c: int
            cell index
        """
        # Update the Per Cell cell tables.
        d = og.PER_CELL_DEPENDENT
        prefix = step[:3]
        for i in d:
            fix_table(prefix + d[i], r, c, i)


class Box(Grid):
    """Use with the Box Model to maintain cell properties."""

    # for retrieving images
    face_count = 3

    def __init__(self, o):
        """
        Initialize a cell table for a Box Model.

        o: One
            Has an optional step.
        """
        Grid.__init__(self, o)
        self.is_rectangle = False
        self._box_type = self._grid_type = None
        self.is_not_rectangular = True

    def _calc_grid_division(self):
        """
        Determine the row and column count.

        Return: tuple
            of int
            row, column
            cell index
        """
        # Type Preset dict, 'self.d'
        d = self.d

        n = self._grid_type = d[ok.GRID_TYPE]
        s = Render.size()

        if n == gr.CELL_COUNT:
            # shear-type
            r, c = (
                min(d[ok.ROW_COUNT], s[1]),
                min(d[ok.COLUMN_COUNT], s[0])
            )

        elif n == gr.SHAPE_COUNT:
            # shear-type
            r, c = (
                min(d[ok.VERT_COUNT], s[1]),
                min(d[ok.HORZ_COUNT], s[0])
            )

        else:
            # regular shape type
            top, bottom, left, right = self.canvas_margin
            w = s[0] - left - right
            h = s[1] - top - bottom
            width = min(w, d[ok.COLUMN_WIDTH])
            height = min(h, d[ok.ROW_HEIGHT])
            n = d[ok.BOX_TYPE]

            if n in (sh.LEFT, sh.RIGHT):
                w1, h1 = width * .75, height * .5
                w2, h2 = w - w1, h - h1
                r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)

            else:
                # vertical box
                w1, h1 = width * .5, height * .75
                w2, h2 = w - w1, h - h1
                r, c = max(1, int(h2 / h1)), max(1, int(w2 / w1))
        return r, c

    def _get_common_cell_size(self):
        """
        Get the cell size for a non-merge-cell table type.

        Return: tuple
            width, height of cell
        """
        r = c = 0

        if self.d[ok.CELL_SHIFT]:
            c = 1
            if self.division[1] == 1:
                if self.division[0] == 1:
                    # There is only one cell, and it isn't allocated.
                    c = -1
                else:
                    r, c = 1, 0

        if c > -1:
            w, h = self.get_cell_rect(r, c).size

        else:
            # invalid margins
            w = h = 0
        return w, h

    def calc_pocket(self, o):
        """
        Calculate the cell pocket and update the shape.

        o: One
            Has variables.
        """
        # Cell Margin Preset dict, 'o.d'
        d = o.d

        # list of margins
        q = []

        row, column = self.division
        s = Render.size()
        n = self.cell_shape
        is_per_cell = d[ok.PER_CELL]
        p = bx.get_face_function(self._box_type)

        if not is_per_cell:
            q = top, bottom, left, right = Form.calc_margin(d, *s)

        for r in range(row):
            for c in range(column):
                if Shape.is_double_cell(self.double_type, r, c):
                    rect = self.get_cell_rect(r, c)
                    x, y = rect.position
                    w, h = rect.size
                    is_margin = False
                    if w:
                        if is_per_cell:
                            o.r, o.c = r, c
                            e = is_per_cell[r][c]
                            q = top, bottom, left, right = Form.calc_margin(
                                e,
                                *s
                            )
                        if any(q):
                            is_margin = True
                            x += left
                            y += top
                            x = Base.seal(x, 0, s[0] - 1)
                            y = Base.seal(y, 0, s[1] - 1)
                            w = max(w - left - right, 1)
                            h = max(h - top - bottom, 1)

                    # The pocket size will change if
                    # the cell shape is regular shaped.
                    if self.is_regular_shape and is_margin:
                        x, y, w, h = Shape.bounds(
                            dispatch[n](Rect(x, y, w, h))
                        )

                    # a BoxCell instance, 'a'
                    a = self.table[r][c]

                    b = a.pocket = Rect(x, y, w, h)

                    # Update the cell shape if the pocket size has changed.
                    if is_margin:
                        q = a.shape = dispatch[n](b)
                        p(
                            a,
                            q,
                            round(q[0] + (q[6] - q[0]) / 2.),
                            round(q[3] + (q[9] - q[3]) / 2.)
                        )

    def clone(self):
        """
        Make a copy of a Box instance.

        Return: Box
            a copy of self
        """
        a = Box(One())

        # Copy the attributes.
        Base.deep_update(a.__dict__, self.__dict__)
        return a

    @staticmethod
    def fix_tables(step, r, c):
        """
        Fix the scale of the Per Cell cell tables.
        A Per Cell Widget has its own cell table.
        The cell tables need to stay in sync with cell table size.

        step: tuple
            with a Model reference in a tuple-prefix

        r, c: int
            cell index
        """
        # Update the Per Cell cell tables.
        prefix = step[:3]
        d = og.FACE_PER_CELL_DEPENDENT

        for i in d:
            fix_table(prefix + (sk.CELL, sk.FACE) + d[i], r, c, i)

        d = og.BOX_PER_CELL_DEPENDENT
        for i in d:
            fix_table(prefix + d[i], r, c, i)

    def get_corner(self, face_x, r, c):
        """
        Retrieve the points for a Cell Face transform function.

        face_x: int
            Face number
            0 to 2

        r, c: int
            cell index
        """
        return self.table[r][c].corner[face_x]

    def get_face(self, face_x, r, c):
        """
        Retrieve the polygon for drawing a Cell Face region.

        face_x: int
            Face number
            0 to 2

        r, c: int
            cell index
        """
        return self.table[r][c].poly[face_x]

    def get_face_rect(self, face_x, r, c):
        """
        Retrieve the Rect for a cell Face bounds.

        face_x: int
            Face number
            0 to 2

        r, c: int
            cell index
        """
        return self.table[r][c].face_rect[face_x].clone()

    def get_image_name(self, face_x, r, c):
        """
        Get the name of the image assigned to a cell.

        face_x: int
            face index
            0 to 2

        r, c: int
            cell index

        Return: string or None
            an image name
        """
        return self.table[r][c].image_name[face_x]

    def get_image_size(self, face_x, r, c):
        """
        Retrieve the image dimensions for a Cell Face transform
        process. The dimensions are the length between the
        points of a Cell Face's width and height vectors.

        face_x: int
            Face number
            0 to 2

        r, c: int
            cell index
        """
        return self.table[r][c].image_size[face_x]

    def get_merge_cell_rect(self, r, c):
        """
        Get the cell rectangle. There are no merge cells in the Box Model.

        r, c: int
            cell index
        """
        return self.get_cell_rect(r, c)

    def get_mold(self, face_x, r, c):
        """
        Mold is a rectangle for the last step when placing an image.

        face_x: int
            Box Face index
            0 to 2

        r, c: int
            cell index

        Return: Rect
            of mold
            a rectangle
        """
        return self.table[r][c].mold[face_x].clone()

    def set_image_name(self, n, face_x, r, c):
        """
        Store the name of the image assigned to a cell.

        n: string
            image name

        face_x: int
            face index
            0 to 2

        r, c: int
            cell index
        """
        self.table[r][c].image_name[face_x] = n

    def set_mold(self, face_x, r, c, x, y, w, h):
        """
        Set the mold position. The 'mold' is a rectangle
        for the last step when placing an image.

        face_x: int
            Box Face index

        x, y: int
            screen coordinate
            topleft corner of the rectangle

        w, h: int
            size of the rectangle
        """
        self.table[r][c].mold[face_x] = Rect(x, y, w, h)

    def update_type(self, o):
        """
        Update the cell-type from the Cell Type Preset.

        o: One
            d: dict, cell Type Preset, with a Per Cell cell table
        """
        def get_cell_shape():
            """
            Get the cell shape according the cell type.

            Return: string
                cell shape descriptor
            """
            if d[ok.BOX_TYPE] in (sh.BOTTOM, sh.TOP):
                return sh.BOX_VERT if self.is_regular_shape \
                    else sh.BOX_VERT_SHEAR
            return sh.BOX_HORZ if self.is_regular_shape \
                else sh.BOX_HORZ_SHEAR

        def get_double_type():
            """
            Get the double-type of the cell table.

            Return: enum
                of double-type
            """
            if self.d[ok.CELL_SHIFT]:
                return sh.SHIFT
            else:
                return sh.NOT_SHIFT

        # Cell Type Preset dict, 'd'
        d = self.d = o.d

        r, c = self.division = self._calc_grid_division()
        self.is_regular_shape = self._grid_type == gr.SHAPE_COUNT
        self.cell_shape = get_cell_shape()
        self.double_type = get_double_type()
        self._box_type = d[ok.BOX_TYPE]
        table = self.table = Base.make_2d_table(r, c)
        self.fix_tables(self.step, r, c)

        for i in range(r):
            for j in range(c):
                if Shape.is_double_cell(self.double_type, i, j):
                    table[i][j] = BoxCell(i, j)
        self._calc_cell()


class Table(Grid):
    """
    Calculate the position and the size of cells for a Table Model. Has
    a cell table which is the cell-oriented storage vessel for the Table class.
    The cell table is referred to as 'self.table'.
    """

    def __init__(self, o):
        """
        Initialize the Table Model's cell table.

        o: One
            Has an optional step.
        """
        Grid.__init__(self, o)
        self.is_rectangle = False

    def _calc_grid_division(self):
        """
        Determine the row and column count of the cell table.

        Return: tuple
            of int
            row, column
            cell index
        """
        # Cell Type Preset dict, 'self.d'
        d = self.d

        n = d[ok.GRID_TYPE]
        size = Render.size()

        if n == gr.CELL_COUNT:
            r, c = (
                min(d[ok.ROW_COUNT], size[1]),
                min(d[ok.COLUMN_COUNT], size[0])
            )

        elif n == gr.SHAPE_COUNT:
            r, c = (
                min(d[ok.VERT_COUNT], size[1]),
                min(d[ok.HORZ_COUNT], size[0])
            )

        else:
            # cell size
            top, bottom, left, right = self.canvas_margin
            w = size[0] - left - right
            h = size[1] - top - bottom
            width, height = d[ok.COLUMN_WIDTH], d[ok.ROW_HEIGHT]

            # rectangle and octagon
            r, c = max(h // height, 1), max(w // width, 1)

            # hexagon, ellipse, rhombus, octagon-double, and triangle
            n = self.cell_shape

            if self.is_not_rectangular and n not in sh.OCTAGONS:
                if n in sh.REGULAR_HEXAGON:
                    w1, h1 = width * .5, height * .75
                    w2, h2 = w - w1, h - h1
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)

                elif n in sh.TRUNCATED_HEXAGON:
                    w1, h1 = width * .75, height * .5
                    w2, h2 = w - w1, h - h1
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)

                elif n in ft.VERTICAL_TRIANGLE:
                    w1 = width * .5
                    w2 = w - w1
                    r, c = max(int(h / height), 1), max(int(w2 / w1), 1)

                elif n in ft.HORIZONTAL_TRIANGLE:
                    h1 = height * .5
                    h2 = h - h1
                    r, c = max(int(h2 / h1), 1), max(int(w / width), 1)

                elif n == sh.RHOMBUS_SHEAR:
                    w1, h1 = width * .5, height * .5
                    w2, h2 = w - w1, h - h1
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)
                elif n == sh.OCTAGON_DOUBLE_SHEAR:
                    w1 = width * sh.OCTAGON_RATIO
                    h1 = height * sh.OCTAGON_RATIO
                    w2, h2 = width - w1, height - h1
                    w3, h3 = w - w1, h - h1
                    r, c = max(int(h3 / h2), 1), max(int(w3 / w2), 1)
        return r, c

    def _get_common_cell_size(self):
        """
        Get the cell size.

        Return: tuple
            width, height of cell in pixels
        """
        r = c = 0

        if self.cell_shape in sh.DOUBLE:
            if self.d[ok.CELL_SHIFT]:
                c = 1
                if self.division[1] == 1:
                    if self.division[0] == 1:
                        # There is only one cell, and it isn't allocated.
                        c = -1
                    else:
                        r, c = 1, 0

        if c > -1:
            rect = self.get_merge_cell_rect(r, c)
            w, h = rect.size

        else:
            # invalid cell
            w = h = 0
        return w, h

    def calc_pocket(self, o):
        """
        Calculate the cell pocket and update the shape.

        o: One
            d: dict; Cell Margin Preset with its Per Cell cell table
        """
        # Cell Margin Preset dict, 'o.d'
        d = o.d

        # calculated cell margin list
        q = []

        row, column = self.division
        s = Render.size()
        n = self.cell_shape
        is_per_cell = d[ok.PER_CELL]
        is_triangle = n in ft.TRIANGLE

        if not is_per_cell:
            q = top, bottom, left, right = Form.calc_margin(d, *s)
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(self, r, c):
                    rect = self.get_merge_cell_rect(r, c)
                    x, y = rect.position
                    w, h = rect.size
                    is_margin = False

                    if w:
                        if is_per_cell:
                            o.r, o.c = r, c
                            e = is_per_cell[r][c]
                            q = top, bottom, left, right = Form.calc_margin(
                                e,
                                *s
                            )
                        if any(q):
                            is_margin = True
                            x += left
                            y += top
                            x = Base.seal(x, 0, s[0] - 1)
                            y = Base.seal(y, 0, s[1] - 1)
                            w = max(w - left - right, 1)
                            h = max(h - top - bottom, 1)

                    # The pocket size will change if
                    # the cell shape is regular shaped.
                    if self.is_regular_shape and is_margin:
                        x, y, w, h = Shape.bounds(
                            dispatch[n](Rect(x, y, w, h))
                        )

                    # a Cell instance, 'a'
                    a = self.table[r][c]

                    b = a.pocket = Rect(x, y, w, h)

                    # Update the cell shape if the pocket size has changed.
                    if is_margin:
                        n1 = n

                        if is_triangle:
                            if Shape.is_inverse_triangle(r, c):
                                n1 = ft.INVERTED[n]
                        a.shape = dispatch[n1](b)

    def clone(self):
        """
        Make a copy of the Table instance.

        Return: Table
            a copy
        """
        a = Table(One())

        # Copy the attributes.
        Base.deep_update(a.__dict__, self.__dict__)
        return a

    def get_cell_block(self, u, v):
        """
        Use when cells are merged, and the merge
        cell's dimension needs to be determined.

        u: tuple
            (r, c) of int
            topleft cell

        v: tuple
            (r, c) of int
            bottom-right cell

        Return the topleft coordinates and the
        scale of an rectangular array of cells.
        """
        r1, c1 = u
        x, y = self.get_cell_rect(r1, c1).position
        rect = self.get_cell_rect(v[0], v[1])
        x1, y1 = rect.position
        w, h = rect.size
        w = x1 - x + w
        h = y1 - y + h
        return x, y, w, h

    def update_cell_block(self, u, v):
        """
        Update the merge cell size for a cell block.

        u: tuple
            cell index of the topleft cell of the block

        v: tuple
            cell index of the bottom-right cell of the block
        """
        x, y, w, h = self.get_cell_block(u, v)
        a = self.table[u[0]][u[1]]
        b = a.merge_cell = Rect(x, y, w, h)
        a.shape = a.plaque = dispatch[self.cell_shape](b)

    def update_type(self, o):
        """
        Update the cell-type.

        o: One
            d: dict, Cell Type Preset with it Per Cell cell table
        """
        def get_cell_shape():
            """
            Get the cell shape according the cell type.

            Return: string
                cell shape descriptor
            """
            if d[ok.GRID_TYPE] == gr.SHAPE_COUNT:
                return d[ok.CELL_SHAPE_NORMAL]
            return d[ok.CELL_SHAPE]

        def get_double_type():
            """
            Get the double type of the Model.

            Return: enum
                of double-type
            """
            if self.cell_shape in sh.DOUBLE:
                if self.d[ok.CELL_SHIFT]:
                    return sh.SHIFT
                else:
                    return sh.NOT_SHIFT
            return sh.NOT_DOUBLE_SPACE

        def merge_cell():
            """
            Determine if the Model Cell Type is in merge cell
            mode as when its Per Cell CheckButton is checked.

            Return: bool
                Is true if the Cell Type option group is in merge cell mode.
            """
            if self.is_rectangle:
                return True if ok.PER_CELL in d and d[ok.PER_CELL] else False
            return False

        # Cell Type Preset dict, 'o.d'
        d = self.d = o.d

        self.cell_shape = get_cell_shape()
        self.is_rectangle = self.cell_shape == sh.RECTANGLE
        self.is_regular_shape = self.get_normal_type()
        self.is_not_rectangular = not Shape.is_rectangular_shape(
            self.cell_shape
        )
        self.is_merge_cell = merge_cell()
        self.double_type = get_double_type()
        r, c = self.division = self._calc_grid_division()
        table = self.table = Base.make_2d_table(r, c)

        self.fix_tables(self.step, r, c)

        # The Per Cell cell table was changed by 'fix_tables'.
        self.d[ok.PER_CELL] = Step.get_per_cell_for_table(self.step, sk.TYPE)

        for i in range(r):
            for j in range(c):
                if Shape.is_allocated_cell(self, i, j):
                    table[i][j] = Cell(i, j)

        self._calc_cell()

        # merge cell rectangle
        for i in range(r):
            for j in range(c):
                # Cell, 'a'
                a = table[i][j]

                # if merging cells
                if self.is_merge_cell:
                    # the size of the cell in cell count, 's'
                    s = self.d[ok.PER_CELL][i][j]

                    # Sub-topleft cells are unavailable
                    # and are dependent on the topleft cell.
                    if s == (-1, -1):
                        # If the cell has a width of zero,
                        # then the cell is not an image cell.
                        x = y = w = h = 0

                    elif s == (1, 1):
                        rect = self.get_cell_rect(i, j)
                        x, y = rect.position
                        w, h = rect.size
                    else:
                        s1 = i + s[0] - 1, j + s[1] - 1
                        x, y, w, h = self.get_cell_block((i, j), s1)
                        a.plaque = dispatch[self.cell_shape](
                            Rect(x, y, w, h)
                        )
                else:
                    if Shape.is_allocated_cell(self, i, j):
                        rect = a.cell
                        x, y = rect.position
                        w, h = rect.size
                    else:
                        # Flag an unallocated cell with 'x'.
                        x = -1
                if x > -1:
                    a.merge_cell = Rect(x, y, w, h)


class Stack(Model):
    """Use with the Stack Model for its cell definitions."""

    def __init__(self, o):
        """
        Initialize variables used for rendering. Create a table of
        cells. The Stack Model has one column and one or more rows.

        o: One
            'd': dict
                the Stack Cell Type preset
        """
        Model.__init__(self, o)

        self.cell_count = 1
        self.cell_shape = self.image_group_type = None
        self.is_rectangle = None

    def _calc_cell(self):
        """Calculate the cell sizes for the cell table."""
        rect = dispatch[self.cell_shape](self.rect)

        for r in range(0, self.division[0]):
            a = self.table[r][0]
            a.cell = self.rect.clone()
            a.shape = a.plaque = rect

    def calc_pocket(self, o):
        """
        Calculate cell rectangle, pocket, plaque, and shape.

        o: One
            d: dict, Cell Margin Preset
        """
        c = 0
        row = self.division[0]
        q = top, bottom, left, right = Form.calc_margin(o.d, *Render.size())
        x, y = self.rect.position
        w, h = self.rect.size
        is_margin = False

        if w and any(q):
            is_margin = True
            x += left
            y += top
            w = max(w - left - right, 1)
            h = max(h - top - bottom, 1)

        shape = dispatch[self.cell_shape](Rect(x, y, w, h))

        # The pocket size will change if the cell shape is normalized.
        if self.is_regular_shape and is_margin:
            x, y, w, h = Shape.bounds(shape)

        for r in range(row):
            self.update_pocket(r, c, x, y, w, h, is_margin)

    def clone(self):
        """
        Make a copy of a Stack instance.

        Return: Stack
            a copy of self
        """
        a = Stack(One())

        # Copy the attributes.
        Base.deep_update(a.__dict__, self.__dict__)
        return a

    @staticmethod
    def fix_tables(step, r, _):
        """
        Fix the scale of Per Cell cell tables.
        A Per Cell Widget has a its own cell table.

        step: tuple
            with a Model reference

        r, _: int
            cell index; c = 1
        """
        q = step[:3]
        for i in (gk.PER_CELL_PLACE, gk.PER_CELL_MASK):
            step = q + og.PER_CELL_DEPENDENT[i]
            g = Hat.cat.group_dict[step].per_cell_group
            if g.check_button.get_value():
                d = Step.get_dict_from_step(step)
                table = d[ok.PER_CELL]

                d.pop(ok.PER_CELL)

                table = fix_cell_table_size(table, r, 1, d)
                g.set_value(table)

    def update_cell_rect(self, o):
        """
        Update the Stack's cell rectangle.

        o: One
            d: dict, Rectangle Preset
        """
        self.update_rectangle(o)

        r = self.division[0]

        for i in range(r):
            self.table[i][0] = Cell(i, 0)

        self._calc_cell()

        # The merge cell rectangle is the same as the cell rectangle.
        for i in range(r):
            self.table[i][0].merge_cell = self.table[i][0].cell.clone()

    def update_type(self, o):
        """
        Update the Stack Model's attributes from the Cell Type Preset dict.

        o: One
            d: dict, Cell Type Preset
        """
        # Cell Type Preset dict, 'd'
        d = self.d = o.d

        r = self.cell_count = d[ok.CELL_COUNT]
        self.cell_shape = d[ok.CUSTOM_CELL_SHAPE]
        self.is_rectangle = self.cell_shape == sh.RECTANGLE
        self.is_regular_shape = self.get_normal_type()
        self.is_not_rectangular = not Shape.is_rectangular_shape(
            self.cell_shape
        )
        self.division = r, 1
        self.image_group_type = d[ok.IMAGE_GROUP_TYPE]
        self.add_shift_x = d[ok.ADDING_SHIFT_X]
        self.add_shift_y = d[ok.ADDING_SHIFT_Y]
        self.add_shift_rotate = d[ok.ADDING_SHIFT_ROTATE]
        self.add_shift_w = d[ok.ADDING_SHIFT_W]
        self.add_shift_h = d[ok.ADDING_SHIFT_H]
        self.table = Base.make_2d_table(r, 1)
        self.fix_tables(self.step, r, 1)
