#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_one import Comm
import gimpfu as fu
from roller_one_fu import Lay

pdb = fu.pdb


class Text(object):
    """Manage text functions."""

    @staticmethod
    def make_text_layer(
        j, z,
        antialias,
        x, y,
        text,
        font_size,
        font,
        color,
        w, h
    ):
        """
        Create a text layer. Transform the text layer to fit into a rectangle.

        j: GIMP image
            to receive text layer

        z: layer or None
            to receive text

        x, y: int
            topleft coordinate of text

        text: string
            to make on text layer

        font_size: int
            font size of text

        font: string
            font name

        color: tuple
            RGBA

        w, h: int
            boxed text size

        Return: tuple
            bool, layer
            bool
                Is a success flag, where true equates to success.
            layer
                of the transformed text
                Could be None on failure.
        """
        # text layer, 'z1'
        z1 = None

        go = True
        text = text.decode('utf-8').strip()
        offset_z = Lay.offset(z) if z else 0    

        # Remove any selection so that 'gimp_text_fontname' returns a layer.
        pdb.gimp_selection_none(j)

        try:
            # Pass None as a layer option so
            # that function will create a new layer.
            # Text layer type, 'z1'
            z1 = pdb.gimp_text_fontname(
                j, None,
                float(x), float(y),
                text,
                Fu.TextFontName.BORDER_0,
                # True
                1,
                float(font_size),
                fu.PIXELS,
                font
            )

        except Exception as ex:
            Comm.show_err(ex)
            Comm.info_msg("Apologies. Roller's text method failed to draw.")
            go = False

        if z1:
            pdb.gimp_text_layer_set_color(z1, color)
            pdb.gimp_text_layer_set_antialias(z1, antialias)
            pdb.plug_in_autocrop_layer(j, z1)

            # context
            pdb.gimp_context_set_interpolation(fu.INTERPOLATION_NOHALO)
            pdb.gimp_context_set_transform_direction(fu.TRANSFORM_FORWARD)
            pdb.gimp_context_set_transform_resize(fu.TRANSFORM_RESIZE_ADJUST)

            if w:
                pdb.gimp_item_transform_scale(
                    z1, 0., 0., float(w), float(h)
                )
            if z and pdb.gimp_item_is_valid(z):
                # Move the layer, 'z1', from the top of the layer palette
                # so that it can be merged with the target layer, 'z'.
                pdb.gimp_image_reorder_item(j, z1, z.parent, offset_z)
                z1 = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
        return go, z1
