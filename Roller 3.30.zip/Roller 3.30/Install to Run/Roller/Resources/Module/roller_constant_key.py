#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Keyword class modules have two letter import variables
# that are unique in the context of the program.
# As a rule, two letter variables will be either import classes,
# enumerated single letter typed variable names, or
# single letter typed variable names with an underscore.
BACKDROP_IMAGE = "Backdrop Image"
BRUSH = "Brush"
BUMP = "Bump"
CAPTION_MARGIN = "Margin, Caption"
COLOR_PIPE = "Color Pipe"
CORNER_TAPE = "Corner Tape"
INNER_SHADOW = "Inner Shadow"
JAGGED_EDGE = "Jagged Edge"
LIST_SEPARATOR = "★"
PLAQUE_MASK = "Plaque Mask"
RESIZE_METHOD = "Resize Method"
SHADOW_1 = "Shadow #1"
SHADOW_2 = "Shadow #2"
SHADOW_TYPE = "Shadow Type"
TRI_SHADOW = "Tri-Shadow"


class BackdropStyle:
    """
    Has keys that identify a Backdrop Style.
    Import as 'by'.
    """
    AVERAGE_COLOR = "Average Color"
    BACKDROP_IMAGE = BACKDROP_IMAGE
    CARBON_14 = "Carbon 14"
    CLAY_CHEMISTRY = "Clay Chemistry"
    COLOR_FILL = "Color Fill"
    COLOR_GRID = "Color Grid"
    CRYSTAL_CAVE = "Crystal Cave"
    CORE_DESIGN = "Core Design"
    CUBE_PATTERN = "Cube Pattern"
    CUBISM_COVER = "Cubism Cover"
    DARK_FORT = "Dark Fort"
    DENSITY_GRADIENT = "Density Gradient"
    DROP_ZONE = "Drop Zone"
    ETCH_SKETCH = "Etch Sketch"
    FLOOR_SAMPLE = "Floor Sample"
    GALACTIC_FIELD = "Galactic Field"
    GLASS_GAW = "Glass Gaw"
    GRADIENT_FILL = "Gradient Fill"
    HISTORIC_TRIP = "Historic Trip"
    IMAGE_GRADIENT = "Image Gradient"
    LINE_STONE = "Line Stone"
    LOST_MAZE = "Lost Maze"
    MAZE_BLEND = "Maze Blend"
    MYSTERY_GRATE = "Mystery Grate"
    NANO_SUIT = "Nano Suit"
    NOISE_RIFT = "Noise Rift"
    PATTERN_FILL = "Pattern Fill"
    RAINBOW_VALLEY = "Rainbow Valley"
    RECT_PATTERN = "Rectangle Pattern"
    ROCKY_LANDING = "Rocky Landing"
    SPACETIME_FABRIC = "Spacetime Fabric"
    SPECIMEN_SPECKLE = "Specimen Speckle"
    SPIRAL_CHANNEL = "Spiral Channel"
    SQUARE_CLOUD = "Square Cloud"
    STONE_AGE = "Stone Age"
    TRAILING_VINE = "Trailing Vine"
    WATERY_PAGE = "Watery Page"
    KEY_LIST = (
        AVERAGE_COLOR,
        BACKDROP_IMAGE,
        CARBON_14,
        CLAY_CHEMISTRY,
        COLOR_FILL,
        COLOR_GRID,
        CRYSTAL_CAVE,
        CORE_DESIGN,
        CUBE_PATTERN,
        CUBISM_COVER,
        DARK_FORT,
        DENSITY_GRADIENT,
        DROP_ZONE,
        ETCH_SKETCH,
        FLOOR_SAMPLE,
        GALACTIC_FIELD,
        GLASS_GAW,
        GRADIENT_FILL,
        HISTORIC_TRIP,
        IMAGE_GRADIENT,
        LINE_STONE,
        LOST_MAZE,
        MAZE_BLEND,
        MYSTERY_GRATE,
        NANO_SUIT,
        NOISE_RIFT,
        PATTERN_FILL,
        RAINBOW_VALLEY,
        RECT_PATTERN,
        ROCKY_LANDING,
        SPACETIME_FABRIC,
        SPECIMEN_SPECKLE,
        SPIRAL_CHANNEL,
        SQUARE_CLOUD,
        STONE_AGE,
        TRAILING_VINE,
        WATERY_PAGE
    )


by = BackdropStyle


class Button:
    """
    Has keys used by Button Widgets.
    Import as 'bk'.
    """
    ACCEPT = "Accept"
    CANCEL = "Cancel"
    OPEN = "Open…"
    PER_CELL = 'per_cell_button,'
    PLAN = "Plan"
    PREVIEW = "Preview"
    RANDOM = "Randomize"
    RENDER = "Render"


class Effect:
    """
    Has keys that identify an Image Effect. Are option types.
    Import as 'ek'.
    """
    BALL_JOINT = "Ball Joint"
    BORDER_LINE = "Border Line"
    BRUSH_PUNCH = "Brush Punch"
    CAMO_PLANET = "Camo Planet"
    CERAMIC_CHIP = "Ceramic Chip"
    CIRCLE_PUNCH = "Circle Punch"
    CLEAR_FRAME = "Clear Frame"
    COLOR_BOARD = "Color Board"
    COLOR_PIPE = COLOR_PIPE
    CORNER_TAPE = CORNER_TAPE
    CUTOUT_PLATE = "Cutout Plate"
    CRUMBLE_SHELL = "Crumble Shell"
    FEATHER_STEPS = "Feather Steps"
    FRAME_OVER = "Frame Over"
    GLASS_REVEAL = "Glass Reveal"
    GRADIENT_LEVEL = "Gradient Level"
    HOT_GLUE = "Hot Glue"
    IMAGE_EFFECT = "Image Effect"
    INNER_SHADOW = INNER_SHADOW
    JAGGED_EDGE = JAGGED_EDGE
    LINE_FASHION = "Line Fashion"
    MAZE_MIRROR = "Maze Mirror"
    METALLIC_PROFILE = "Metallic Profile"
    NO_EFFECT = "No Effect"
    PAINT_RUSH = "Paint Rush"
    RAD_WAVE = "Rad Wave"
    RAISED_MAZE = "Raised Maze"
    SHADOW_1 = SHADOW_1
    SHADOW_2 = SHADOW_2
    SHAPE_BURST = "Shape Burst"
    SQUARE_CUT = "Square Cut"
    SQUARE_PUNCH = "Square Punch"
    STAINED_GLASS = "Stained Glass"
    STRETCH_TRAY = "Stretch Tray"
    TRI_SHADOW = TRI_SHADOW
    WIRE_FENCE = "Wire Fence"
    KEY_LIST = (
        BALL_JOINT,
        BORDER_LINE,
        BRUSH_PUNCH,
        CAMO_PLANET,
        CERAMIC_CHIP,
        CIRCLE_PUNCH,
        CLEAR_FRAME,
        COLOR_BOARD,
        COLOR_PIPE,
        CORNER_TAPE,
        CRUMBLE_SHELL,
        CUTOUT_PLATE,
        FEATHER_STEPS,
        FRAME_OVER,
        GLASS_REVEAL,
        GRADIENT_LEVEL,
        HOT_GLUE,
        INNER_SHADOW,
        JAGGED_EDGE,
        LINE_FASHION,
        MAZE_MIRROR,
        METALLIC_PROFILE,
        NO_EFFECT,
        PAINT_RUSH,
        RAD_WAVE,
        RAISED_MAZE,
        SHADOW_1,
        SHADOW_2,
        SHAPE_BURST,
        SQUARE_CUT,
        SQUARE_PUNCH,
        STAINED_GLASS,
        STRETCH_TRAY,
        TRI_SHADOW,
        WIRE_FENCE
    )


class Group:
    """
    Has keys used for Presets of option groups.
    The comas are used to split the string. The first
    part is the UI label, and the whole part is the key.
    Import as 'gk'.
    """
    BACKDROP = "Backdrop"
    BACKDROP_STYLE = "Backdrop Style"
    BACKGROUND_STRIPE = "Background Stripe"
    BLUR_BEHIND = "Blur Behind"
    BRUSH = BRUSH
    BUMP = BUMP
    CAPTION_MARGIN = CAPTION_MARGIN
    EFFECT = "Effect"
    GLOBAL = "Global"
    GRADIENT_LIGHT = "Gradient Light"
    IMAGE_CHOICE = "Image Choice"
    IMAGE_EFFECT = "Image Effect"
    INFLUENCE = "Influence"
    INNER_SHADOW = INNER_SHADOW
    MODEL = "Model"
    PLAQUE_MASK = PLAQUE_MASK
    RECTANGLE = "Rectangle"
    RESIZE_METHOD = RESIZE_METHOD
    SHADOW_1 = SHADOW_1
    SHADOW_2 = SHADOW_2
    SHADOW_TYPE = SHADOW_TYPE
    SHIFT = "Shift"
    STEPS = "Steps"
    TRI_SHADOW = TRI_SHADOW

    # Blur Behind
    CAPTION_BEHIND = "Cell Caption, Blur Behind"
    CLEAR_FRAME_BEHIND = "Clear Frame, Blur Behind"
    COLOR_BOARD_BEHIND = "Color Board, Blur Behind"
    GLASS_REVEAL_BEHIND = "Glass Reveal, Blur Behind"
    GRADIENT_LEVEL_BEHIND = "Gradient Level, Blur Behind"
    IMAGE_BEHIND = "Image, Blur Behind"
    STAINED_GLASS_BEHIND = "Stained Glass, Blur Behind"

    # Box
    BOX_CELL = "Cell, Box"

    # Is needed in order to change the Caption Type options to Text only.
    BOX_CELL_CAPTION = "Caption, Box, Cell"

    # Is needed to filter the Obey Margins
    # option from the Face Plaque option group.
    BOX_CELL_PLAQUE = "Plaque, Box, Cell"

    BOX_MODEL = "Box Model"
    BOX_PROPERTY = "Property, Box"
    TYPE_BOX = "Type, Box"

    # Box Node
    BOX_BORDER = "Border, Box"
    BOX_CAPTION = "Caption, Box"
    BOX_FACE = "Face, Box"
    BOX_FRINGE = "Fringe, Box"
    BOX_IMAGE = "Image, Box"
    BOX_MASK = "Mask, Box"
    BOX_PLACE = "Place, Box"
    BOX_PLAQUE = "Plaque, Box"

    # Box Face, Border
    PER_CELL_GROUP_BORDER = "Group, Border, Per Cell"
    GROUP_BORDER = "Group, Border"
    FACE_1_BORDER = "Face 1, Border"
    FACE_2_BORDER = "Face 2, Border"
    FACE_3_BORDER = "Face 3, Border"

    # Box Face, Caption
    PER_CELL_GROUP_CAPTION = "Group, Caption, Per Cell"
    GROUP_CAPTION = "Group, Caption"
    FACE_1_CAPTION = "Face 1, Caption"
    FACE_2_CAPTION = "Face 2, Caption"
    FACE_3_CAPTION = "Face 3, Caption"

    # Box Face, Fringe
    PER_CELL_GROUP_FRINGE = "Group, Fringe, Per Cell"
    GROUP_FRINGE = "Group, Fringe"
    FACE_1_FRINGE = "Face 1, Fringe"
    FACE_2_FRINGE = "Face 2, Fringe"
    FACE_3_FRINGE = "Face 3, Fringe"

    # Box Face, Mask
    PER_CELL_GROUP_MASK = "Group, Mask, Per Cell"
    GROUP_MASK = "Group, Mask"
    FACE_1_MASK = "Face 1, Mask"
    FACE_2_MASK = "Face 2, Mask"
    FACE_3_MASK = "Face 3, Mask"

    # Box Face, Place
    PER_CELL_GROUP_PLACE = "Group, Place, Per Cell"
    GROUP_PLACE = "Group, Place"
    FACE_PLACE = "Face, Place"
    FACE_1_PLACE = "Face 1, Place"
    FACE_2_PLACE = "Face 2, Place"
    FACE_3_PLACE = "Face 3, Place"

    # Box Face, Plaque
    PER_CELL_GROUP_PLAQUE = "Group, Plaque, Per Cell"
    GROUP_PLAQUE = "Group, Plaque"
    FACE_1_PLAQUE = "Face 1, Plaque"
    FACE_2_PLAQUE = "Face 2, Plaque"
    FACE_3_PLAQUE = "Face 3, Plaque"

    # Use to when adjusting Per Cell visibility.
    BOX_TYPE = (
        BOX_BORDER, BOX_CAPTION, BOX_FRINGE, BOX_MASK, BOX_PLACE, BOX_PLAQUE
    )

    # Canvas
    CANVAS_BORDER = "Border, Canvas"
    CANVAS_CAPTION = "Caption, Canvas"
    CANVAS_FRINGE = "Fringe, Canvas"
    CANVAS_MARGIN = "Margin, Canvas"
    CANVAS_PLAQUE = "Plaque, Canvas"

    # Cell
    CELL_BORDER = "Border, Cell"
    CELL_CAPTION = "Caption, Cell"
    CELL_FRINGE = "Fringe, Cell"
    CELL_MASK = "Mask, Cell"
    CELL_PLACE = "Place, Cell"
    CELL_PLAQUE = "Plaque, Cell"
    CELL_MARGIN = "Margin, Cell"

    # Custom Cell
    CUSTOM_CELL_BORDER = "Border, Custom Cell"
    CUSTOM_CELL_CAPTION = "Caption, Custom Cell"
    CUSTOM_CELL_CELL = "Cell, Custom Cell"
    CUSTOM_CELL_FRINGE = "Fringe, Custom Cell"
    CUSTOM_CELL_IMAGE = "Image, Custom Cell"
    CUSTOM_CELL_MASK = "Mask, Custom Cell"
    CUSTOM_CELL_PLACE = "Place, Custom Cell"
    CUSTOM_CELL_MARGIN = "Margin, Custom Cell"
    CUSTOM_CELL_MODEL = "Custom Cell Model"
    CUSTOM_CELL_PLAQUE = "Plaque, Custom Cell"
    CUSTOM_CELL_PROPERTY = "Property, Custom Cell"
    TYPE_CUSTOM_CELL = "Type, Custom Cell"

    # Table
    CANVAS_GRID = "Canvas, Grid"
    TABLE_CELL = "Cell, Table"
    TABLE_IMAGE = "Image, Table"
    TABLE_MODEL = "Table Model"
    TABLE_PROPERTY = "Property, Table"
    TYPE_TABLE = "Type, Table"

    # Per Cell
    PER_CELL_BORDER = "Border, Per Cell"
    PER_CELL_CAPTION = "Caption, Per Cell"
    PER_CELL_FRINGE = "Fringe, Per Cell"
    PER_CELL_TYPE = "Type, Per Cell"
    PER_CELL_PLACE = "Place, Per Cell"
    PER_CELL_MASK = "Mask, Per Cell"
    PER_CELL_PLAQUE = "Plaque, Per Cell"
    PER_CELL_MARGIN = "Margin, Per Cell"
    PER_CELL_BOX_CAPTION = "Caption, Box, Per Cell"
    PER_CELL_BOX_PLAQUE = "Plaque, Box, Per Cell"

    PER_CELL = 'per_cell'

    # Stack
    TYPE_STACK = "Type, Stack"
    STACK_CELL = "Cell, Stack"
    STACK_CELL_MARGIN = "Margin, Stack"
    STACK_IMAGE = "Image, Stack"
    STACK_PLACE = "Place, Stack"
    STACK_MODEL = "Stack Model"
    STACK_PROPERTY = "Property, Stack"

    # SuperPreset
    PRESET_BOX = "Preset, Box"
    PRESET_CUSTOM_CELL = "Preset, Custom Cell"
    PRESET_STACK = "Preset, Stack"
    PRESET_STEPS = "Preset, Steps"
    PRESET_TABLE = "Preset, Table"
    PRESET_TRI_SHADOW = "Preset, Tri-Shadow"
    PRESET = "Preset"


gk = Group


class Image:
    """
    Are keys used by the Image class.
    Import as 'ik'.
    """
    LOOP = 'loop'
    LOOP_DICT = 'loop_dict'
    NEXT = 'next'
    NEXT_DICT = 'next_dict'
    PREVIOUS = 'previous'
    PREVIOUS_DICT = 'previous_dict'
    SLICE = 'slice'


class Layer:
    """
    Has keys used to id a layer. The key is paired
    with a context identifier in the Cat layer registry.
    Import as 'nk'.
    """
    BORDER = "Border"
    CAPTION = "Caption"
    CANVAS_BORDER = "Canvas Border"
    CANVAS_CAPTION = "Canvas Caption"
    CANVAS_FRINGE = "Canvas Fringe"
    CANVAS_PLAQUE = "Canvas Plaque"
    CAPTION_BEHIND = "Caption Blur Behind"
    CELL_CAPTION = "Cell Caption"
    CELL_FRINGE = "Cell Fringe"
    CELL_PLAQUE = "Cell Plaque"
    CUSTOM_CELL_CAPTION = "Custom Cell Caption"
    FRINGE = "Fringe"
    FRAME = "Frame"
    IMAGE = "Image"
    IMAGE_BEHIND = "Image Blur Behind"
    GRADIENT_LIGHT = "Gradient Light"
    PLACE = "Place"
    PLAQUE = "Plaque"


class Model:
    """
    Has keys used by Models.
    Import as 'md'.
    """
    BOX = "Box"
    CUSTOM_CELL = "Custom Cell"
    STACK = "Stack"
    TABLE = "Table"

    # The model has multiple images.
    MULTI_IMAGE = BOX, STACK, TABLE

    # Identify models with faces.
    HAS_FACE = BOX,

    # indices for the ModelList's 'self._items'
    NAME_INDEX, TYPE_INDEX = 0, 1

    # The model has only one cell.
    ONE_CELL = CUSTOM_CELL, STACK

    # model type
    MODEL_TYPE_LIST = BOX, CUSTOM_CELL, STACK, TABLE
    MODEL_TYPE_DICT = {
        gk.TYPE_BOX:  BOX,
        gk.TYPE_CUSTOM_CELL: CUSTOM_CELL,
        gk.TYPE_STACK: STACK,
        gk.TYPE_TABLE: TABLE
    }


class Option:
    """
    Has keys for options defined in the Option class.
    Descriptors with a comma serve to make the key
    categorically unique, but are split by the
    comas so that only first part is displayed in the UI.
    Import as 'ok'.
    """
    ADDING_SHIFT_H = "Adding Shift Height"
    ADDING_SHIFT_ROTATE = "Adding Shift Rotate"
    ADDING_SHIFT_X = "Adding Shift X"
    ADDING_SHIFT_Y = "Adding Shift Y"
    ADDING_SHIFT_W = "Adding Shift Width"
    AMPLITUDE = "Amplitude"
    ANGLE_JITTER = "Angle Jitter"
    ANGLE_SHIFT = "Angle Shift"
    AS_LAYERS = "Decompose Image As Layers"
    AUTOCROP = "Auto-Crop"
    AZIMUTH = "Light Azimuth"
    BACKDROP_BLUR = "Backdrop Blur"
    BACKDROP_IMAGE_BLUR = "Backdrop Image Blur"
    BACKDROP_IMAGE = BACKDROP_IMAGE
    BACKDROP_INFLUENCE = "Backdrop Influence"
    BACKGROUND_STRIPE = "Background Stripe"
    BACKDROP_STYLE = "Backdrop Style"
    BACKDROP_TYPE = "Backdrop Type"
    BEVEL_EDGE_WIDTH = "Bevel Edge Width"
    BLEND = "Blend"
    BLUR = "Blur"
    BLUR_BEHIND = "Blur Behind"
    BLUR_RADIUS = "Blur Radius"
    BLUR_X = "Blur X"
    BLUR_Y = "Blur Y"
    BORDER_BLUR = "Border Blur"
    BORDER_INFLUENCE = "Border, Influence"
    BORDER_TYPE = "Border Type"
    BORDER_WIDTH = "Border Width"
    BOX_CELL_SHAPE = "Cell Shape, Box"
    BOX_CELL_SHAPE_NORMAL = "Cell Shape, Box Normal"
    BOX_GRID_SIZE = "Grid Size, Box"
    BOX_NAME = "Name, Box"
    BOX_PLAN = "Box Plan"
    BOX_TYPE = "Box Type"
    BRUSH = BRUSH
    BRUSH_ANGLE = "Brush Angle"
    BRUSH_DICT = 'brush_dict'
    BRUSH_HARDNESS = "Brush Hardness"
    BRUSH_SIZE = "Brush Size"
    BRUSH_SPACING = "Brush Spacing"
    BUMP = BUMP
    BUMP_DEPTH = "Bump Depth"
    BUMP_TYPE = "Bump Type"
    CAMO_TYPE = "Camo Type"
    CAPTION_MARGIN = CAPTION_MARGIN
    CAPTION_TYPE = "Caption Type"
    CELL_COUNT = "Cell Count"
    CELL_GAP = "Cell Gap"
    CELL_HEIGHT = "Cell Height"
    CELL_MARGINS = "Cell Margins"
    CELL_NAME = "Cell Name"
    CELL_PLAN = "Cell Plan"
    CELL_SHAPE = "Cell Shape"
    CELL_SHAPE_NORMAL = "Cell Shape (Normal)"
    CELL_SHIFT = "Cell Shift"
    CELL_SIZE = "Cell Size"
    CELL_WIDTH = "Cell Width"
    CIRCLE_DIAMETER = "Circle Diameter"
    CLIP_TO_CELL = "Clip to Cell"
    CLOSE_FILE = 'close_file'

    # Color options have a naming scheme.
    # "Color", number of colors alpha
    # Indicate an alpha channel, 'A'.
    COLOR_1 = "Color, 1"
    COLOR_1A = "Color, 1A"
    COLOR_2A = "Color, 2A"
    COLOR_3A = "Color, 3A"
    COLOR_6 = "Color, 6"
    COLOR_6A = "Color, 6A"

    # Color Count options have a naming scheme.
    # "Color Count", minimum color count, maximum color count
    COLOR_COUNT_1_6 = "Color Count, 1 6"
    COLOR_COUNT_2_6 = "Color Count, 2 6"

    COLOR_GRID_TYPE = "Color Grid Type"
    COLORIZE = "Colorize"
    COLORIZE_OPACITY = "Colorize Opacity"
    COLUMN = "Column"
    COLUMN_1 = "Column #1"
    COLUMN_2 = "Column #2"
    COLUMN_COUNT = "Column Count"
    COLUMN_MAZE = "Column for Maze"
    COLUMN_SLICE = "Column Slice Count"
    COLUMN_WIDTH = "Column Width"
    COMMON_BORDER = "Common Border"
    COMPONENT = "Color Component"
    COMPOSITION_FRAME_WIDTH = "Composition Frame Width"
    CONTRACT = "Contract"
    CORNER_SHIFT = "Corner Shift"
    COVER = "Cover"
    CRITERION = "Criterion"
    CROP_H = "Crop Height"
    CROP_W = "Crop Width"
    CROP_X = "Crop Offset X"
    CROP_Y = "Crop Offset Y"
    CURVE = "Curve"
    CUSTOM_CELL_SHAPE = "Cell Shape, Custom"
    DELETE_PLAN = "Delete the Plan folder on exit."
    DEPTH = "Depth"
    DETAIL_LEVEL = "Noise Amount"
    DIAGONAL_ROTATION = "Diagonal Rotation"
    DISTRESS_SPREAD = "Spread, Distress"
    DISTRESS_THRESHOLD = "Threshold, Distress"
    EDGE_MODE = "Edge Mode"
    EDGE_TYPE = "Edge Type"
    ELEVATION = "Elevation"
    EMBOSS = "Emboss"
    END_OPACITY = "End Opacity"
    END_X = "End X"
    END_Y = "End Y"
    FACE_TYPE = "Face Type"
    FACTOR_HEIGHT = "Height, Factor"
    FACTOR_IMAGE_SIZE_H = "Factor of Image Size Height"
    FACTOR_IMAGE_SIZE_W = "Factor of Image Size Width"
    FACTOR_WIDTH = "Width, Factor"
    FEATHER = "Feather"
    FILE = "File"
    FILLED = "Filled Cell"
    FILTER = "Filter"
    FIT_IMAGE = "Fit image to render"
    FIXED_IMAGE_SIZE_H = "Fixed Size Height"
    FIXED_IMAGE_SIZE_W = "Fixed Size Width"
    FLIP = 'flip'
    FLIP_VERTICAL = "Flip Vertical"
    FOLDER = "Folder"
    FOLDER_ORDER = "Folder Order"
    FONT = "Font"
    FONT_SIZE = "Font Size"
    FRINGE_INFLUENCE = "Fringe, Influence"
    FRAME = "Frame"
    FRAME_STYLE = "Frame Style"
    FRAME_TYPE = "Frame Type"
    FRAME_WIDTH = "Frame Width"
    FRINGE_TYPE = "Fringe Type"
    GAP_TYPE = "Gap Type"
    GAP_WIDTH = "Gap Width"
    GRADIENT = "Gradient"
    GRADIENT_ANGLE = "Gradient Angle"
    GRADIENT_DIRECTION = "Gradient Direction"
    GRADIENT_MODE = "Gradient Mode"
    GRADIENT_ROW = 'gradient row'
    GRADIENT_TYPE = "Gradient Type"
    GREY_SCALE = "Grey Scale"
    GRID_SIZE = "Grid Size"
    GRID_TYPE = "Grid Type"
    HEIGHT_CLIP = "Height, Clip"
    HEIGHT_MOD = "Height Mod"
    HORZ_COUNT = "Horizontal Count"
    HORZ_SCALE = "Horizontal Scale"
    IMAGE = "Image"
    IMAGE_EFFECT = "Image Effect"
    IMAGE_GROUP_TYPE = "Image Group Type"
    IMAGE_INFLUENCE = "Image Influence"
    IMAGE_NAME = "Image Name"
    IMAGE_SOURCE = "Image Source"
    INFLUENCE = "Influence"
    INLAY_BLUR = "Inlay Shadow Blur"
    INNER_FRAME_WIDTH = "Inner Frame Width"
    INTENSITY = "Shadow Intensity"
    INVERT = "Invert"
    INVERT_NOISE = "Invert Noise"
    ITERATIONS = "Iterations"
    JUSTIFICATION = "Justification"
    KEEP_GRADIENT = "Keep the Gradient"
    LAYER_COUNT = "Layer Count"
    LAYER_ORDER = "Layer Order"
    LEADING_TEXT = "Leading Text"
    LENGTH_SHIFT = "Length Shift"
    LINE_WIDTH = "Line Width"
    LOCKED = "Locked Aspect Ratio"
    LOOP_INDEX = "Loop Index"
    MAKE_OPAQUE = "Make Opaque?"
    MARGIN_BOTTOM = "Bottom, Margin"
    MARGIN_LEFT = "Left, Margin"
    MARGIN_RIGHT = "Right, Margin"
    MARGIN_TOP = "Top, Margin"
    MASK_TYPE = "Mask Type"
    MAZE_DIRECTION = "Maze Rotation Direction"
    MAZE_TYPE = "Maze Type"
    MESH_SIZE = "Mesh Size"
    MESH_TYPE = "Mesh Type"
    METAL_FRAME = "Metal Frame"
    MODE = "Paint Mode"
    MODEL_LIST = "Model List"
    NAME = "Name"
    NEATNESS = "Neatness"
    NET_LINE_SPACING = "Net Line Spacing"
    NET_LINE_WIDTH = "Net Line Width"
    NEXT_INDEX = "Next Index"
    NOISE = "Noise"
    NOISE_MODE = "Noise Mode"
    NOISE_OPACITY = "Noise Opacity"
    NUMBER_OF_SLICES = "Number of Slices"
    NUMERIC_SEQUENCE = "Numeric Sequence"
    OBEY_MARGINS = "Obey Margins"
    OFFSET = "Offset"
    OFFSET_X = "Offset X"
    OFFSET_X_SHIFT = "Offset X, Shift"
    OFFSET_Y = "Offset Y"
    OFFSET_Y_SHIFT = "Offset Y, Shift"
    OFFSET_Z = "Offset Z"
    OPACITY = "Opacity"
    OTHER_FRAME = "Other Frame"
    PANE_HEIGHT = "Pane Height"
    PANE_WIDTH = "Pane Width"
    PATTERN = "Pattern"
    PATTERN_1 = "Pattern #1"
    PATTERN_2 = "Pattern #2"
    PATTERN_3 = "Pattern #3"
    PATTERN_SIZE = "Pattern Size"
    PER_CELL = "Per Cell"
    PLAQUE_MASK = PLAQUE_MASK
    PLAQUE_TYPE = "Plaque Type"
    PIN_CORNER = "Pin Corner"
    PLAQUE_INFLUENCE = "Plaque, Influence"
    POSITION_X = "Position X"
    POSITION_Y = "Position Y"
    POST_BLUR = "Post Blur"
    POWER = "Noise Power"
    PREVIEW_MODE = "Preview Mode"
    PREVIOUS_INDEX = "Previous Index"
    PROFILE = "Profile"
    RANDOM = "Random"
    RANDOM_SEED = "Random Seed"
    RENDER_HEIGHT = "Render Height"
    RENDER_WIDTH = "Render Width"
    RESIZE_METHOD = RESIZE_METHOD
    RESIZE_TYPE = "Resize Method Type"
    ROTATE = "Rotate"
    ROTATE_JITTER = "Rotate Jitter"
    ROW = "Row"
    ROW_COUNT = "Row Count"
    ROW_HEIGHT = "Row Height"
    ROW_MAZE = "Row for Maze"
    ROW_SLICE = "Row Slice Count"
    SAMPLE_POINTS = "Sample Points"
    SAMPLE_RADIUS = "Sample Radius"
    SAMPLE_VECTOR = "Sample Vector"
    SATURATION = "Saturation"
    SCATTER_COUNT = "Scatter Count"
    SEED_GLOBAL = "Random Seed, Global"
    SHADOW_BLUR = "Shadow Blur"
    SHADOW_COLOR = "Shadow Color"
    SHADOW_DICT = "Shadow, Dict"
    SHADOW_INFLUENCE = "Shadow, Influence"
    SHADOW_TYPE = SHADOW_TYPE
    SHAPE_BURST = "Shape Burst"
    SHIFT = "Shift"
    SHIFT_DIRECTION = "Shift Direction"
    SHIFT_GEGL = "Shift, GEGL"
    SHIFT_HEIGHT = "Shift Height"
    SHIFT_WIDTH = "Shift Width"
    SHIFT_X = "Shift X"
    SHIFT_Y = "Shift Y"
    SHIFT_Z = "Shift Z"
    SKETCH_TEXTURE = "Sketch Texture"
    SLICE = "Slice"
    SLICE_ORDER = "Slice Order"
    SMOOTHNESS = "Smoothness"
    SOFTNESS = "Noise Softness"
    SPIRAL_DISTANCE = "Spiral Distance"
    SPIRAL_MOD = "Spiral Mod"
    SPREAD = "Spread"
    SQUARE_DIMENSION = "Square Dimension"
    STACK_PLAN = "Stack Plan"
    STACK_NAME = "Stack Name"
    START_NUMBER = "Start Number"
    START_OPACITY = "Start Opacity"
    START_X = "Start X"
    START_Y = "Start Y"
    STARTING_ANGLE = "Starting Angle"
    STEPS = "Steps"
    STEPS_DROP_ZONE = "Steps, Drop Zone"
    STOP_LENGTH = "Stop Length"
    STRIPE_HEIGHT = "Height, Stripe"
    STRIPE_TYPE = "Stripe Type"
    SUPERPIXEL_SIZE = "Superpixel Size"
    TABLE_NAME = "Table Name"
    TABLE_PLAN = "Table Plan"
    TAPE_LENGTH = "Tape Length"
    TAPE_WIDTH = "Tape Width"
    TEXT = "Text"
    TEXTURE = "Texture"
    TILE_SIZE = "Tile Size"
    THRESHOLD = "Threshold"
    TRAILING_TEXT = "Trailing Text"
    TRANSLUCENT_FRAME = "Translucent Frame"
    TRI_SHADOW = TRI_SHADOW
    TRIM = "Trimmed Side"
    UNSHARP_AMOUNT = "Unsharp Amount"
    UNSHARP_RADIUS = "Unsharp Radius"
    UNSHARP_THRESHOLD = "Unsharp Threshold"
    USE_PLASMA = "Use Plasma"
    VERT_COUNT = "Vertical Count"
    VERT_SCALE = "Vertical Scale"
    WAVE_AMPLITUDE = "Wave Amplitude"
    WAVE_PER_LAYER = "Waves Per Layer"
    WAVE_PHASE = "Wave Phase"
    WAVELENGTH = "Wavelength"
    WHIRL = "Whirl"
    WIDTH = "Width"
    WIDTH_CLIP = "Width, Clip"
    WIDTH_MOD = "Width Mod"
    WIRE_THICKNESS = "Wire Thickness"


class Pickle:
    """Has keys used with Pickle. Import as 'pc'."""
    DATA = 'data'
    FILE = 'file'
    SHOW_ERROR = 'show_error'


class Plan:
    """Has keys used by Plan activity. Import as 'ak'."""
    BORDER = "Border"
    CANVAS_FRINGE = "Canvas Fringe"
    CANVAS_MARGIN = "Canvas Margin"
    CANVAS_PLAQUE = "Canvas Plaque"
    CAPTION = "Caption"
    CELL_FRINGE = "Cell Fringe"
    CELL_MARGIN = "Cell Margin"
    CELL_PLAQUE = "Cell Plaque"
    CELL_SHAPE = "Cell Shape"
    COORDINATE = "Coordinate"
    CORNER = "Corner"
    DIMENSION = "Dimension"
    GRID = "Grid"
    IMAGE = "Image"
    IMAGE_MASK = "Image Mask"
    NAME = "Name"
    RATIO = "Ratio"
    RECTANGLE = "Rectangle"


class Preset:
    """Has keys used to initialize a Preset. Import as 'pk'."""
    DEFAULT = "Default"
    DELETE = "Delete"
    FILE_NAME = 'file_name'
    GET_DATA = 'get_data'
    SAVE = "Save"
    WIN = 'win'


class Step:
    """Has keys used by option groups. Import as 'sk'."""
    # Node label
    BORDER = "Border"
    CANVAS = "Canvas"
    CAPTION = "Caption"
    CELL = "Cell"
    FACE = "Face"
    FACE_1 = "Face 1"
    FACE_2 = "Face 2"
    FACE_3 = "Face 3"
    FACE_PAD = "Face "
    FRINGE = "Fringe"
    GROUP = "Group"
    TYPE = "Type"
    IMAGE = "Image"
    MARGIN = "Margin"
    MASK = "Mask"
    PLACE = "Place"
    PLAQUE = "Plaque"
    PROPERTY = "Property"
    RECTANGLE = "Rectangle"

    SELECTED_ROW = 'selected_row'
    STEP_LIST = 'step_list'
    SESSION = 'session'
    STEPS = gk.STEPS,
    FACES = "Face 1", "Face 2", "Face 3"

    # constants
    BACKDROP = gk.STEPS, gk.BACKDROP
    BACKDROP_IMAGE = BACKDROP + (by.BACKDROP_IMAGE,)
    BACKDROP_STYLE = BACKDROP + (gk.BACKDROP_STYLE,)
    EFFECT = gk.STEPS, gk.EFFECT
    GLOBAL = gk.STEPS, gk.GLOBAL
    GRADIENT_LIGHT = gk.STEPS, gk.GRADIENT_LIGHT
    MODEL = EFFECT + (gk.MODEL,)
    STEPS_PRESET = gk.STEPS, gk.PRESET

    # Tri-Shadow
    SHADOW_TYPE = gk.TRI_SHADOW, gk.SHADOW_TYPE
    TRI_SHADOW = gk.TRI_SHADOW,
    TRI_SHADOW_PRESET = gk.TRI_SHADOW, gk.PRESET
    SHADOW_1 = gk.TRI_SHADOW, gk.SHADOW_1
    SHADOW_2 = gk.TRI_SHADOW, gk.SHADOW_2
    INNER_SHADOW = gk.TRI_SHADOW, gk.INNER_SHADOW
    SHADOWS = SHADOW_1, SHADOW_2, INNER_SHADOW

    # Are keys suitable for making a tooltip
    # or a Window title of a Per Cell Window.
    PRESET_TYPE = (BORDER, CAPTION, FRINGE, MARGIN, MASK, PLACE, PLAQUE, TYPE)


class Widget:
    """
    Has keys used to initialize Widgets.
    Import as 'wk'.
    """
    # tuple of float
    # in .0 to 1.
    # a factor of the space to assign
    # for top, bottom, left, right
    ALIGN = 'align'

    # string
    # Identify the render scale axis as either 'x' or 'y'
    # for RenderPair
    AXIS = 'axis'

    # int
    # padding for the bottom of a table
    BOTTOM_PAD = 'bottom_pad'

    # of gtk.Box classes
    BOX = 'box'

    # int
    # Use with the Rainbow Widget.
    # Is the number of ColorButtons in the Rainbow Widget.
    BUTTON_COUNT = 'button_count'

    # list, 2D, a list of lists, a cell table
    CELL_TABLE = 'cell_table'

    # Use with Entry's string length allocation.
    CHARS = 'chars'

    # string
    # Use with the Choice Window.
    CHOICE = 'choice'

    # class
    # type of Choice Window
    CHOICE_WINDOW = 'choice_window'

    # int
    # for Event boxes
    COLOR = 'color'

    # Widget
    # a container for group of Widgets and containers
    CONTAINER = 'container'

    # string
    # for a Widget Table
    # Is a label string for the left-side of a Table.
    COLUMN_TEXT = 'column_text'

    # function
    # Call when a ModelList item is created.
    CREATE_LIST_ITEM = 'create_list_item'

    # function
    # Call when a ModelList item is deleted.
    DELETE_LIST_ITEM = 'delete_list_item'

    # string
    # for NumberPair
    # Identify Slider.
    FACTOR = 'factor'

    # string
    # for NumberPair
    # Identify Slider.
    FIXED = 'fixed'

    # OptionGroup
    # Is the form group of a PerCellGroup.
    FORM_GROUP = 'form_group'

    # bool
    # Use to flag a Cer Cell's form group's Preview-able state.
    FORM_HAS_PREVIEW = 'form_has_preview'

    # Call to get a value for range.
    FUNCTION = 'function'

    # function
    # Get the limit of a Slider.
    GET_LIMIT = 'get_limit'

    # bool
    # Get ComboBox options from a dict.
    # Is model type and preset key dependent.
    GET_OPTION = 'get_option'

    # function
    # Get a random value.
    GET_RANDOM = 'get_random'

    # Get the random function with a key argument.
    GET_WITH_KEY = 'get_with_key'

    # OptionGroup
    # Use to connect widgets with other widget in their group.
    # Use to access an option's OptionGroup.
    GROUP = 'group'

    # identifier
    # Is a preset key at times. Identify a group of widgets.
    GROUP_KEY = 'group_key'

    # object type
    # Use to differentiate the different group types.
    # Preset, NonPreset, and PerCell
    GROUP_TYPE = 'group_type'

    # boolean
    # for ColorButton
    # When its true, the ColorButton has an alpha value.
    HAS_ALPHA = 'has_alpha'

    # boolean
    # When true, an OptionGroup has an effect pair of buttons.
    HAS_EFFECT_PAIR = 'has_effect_pair'

    # boolean
    # When true, an OptionGroup has a grid pair of buttons.
    HAS_VIEW_PAIR = 'has_view_pair'

    # boolean
    # When true, an OptionGroup has a Preview button.
    HAS_PREVIEW = 'has_preview'

    # boolean
    # When true, an OptionGroup has a Randomize button.
    HAS_RANDOM = 'has_random'

    # boolean
    # When true, an OptionGroup has a Preset button.
    HAS_PRESET = 'has_preset'

    # string
    # Is an optional header for a TreeViewList.
    HEADER = 'header'

    # bool
    # When true, the OptionGroup will load a newly
    # drawn preset or non-preset from its default dictionary.
    IS_DEFAULT = 'is_default'

    # int
    # Use with TreeViewList.
    ITEM_COUNT = 'item_count'

    # string
    # option group
    KEY = 'key'

    # list
    # Use to pass keys for an option when drawing an OptionGroup.
    KEYS = 'keys'

    # sensitivity synchronized with another widget.
    # for NumberPair, Label
    LABEL = 'label'

    # int
    # Use when creating a RadioButton.
    LABEL_X = 'label_x'

    # iterable of strings
    # Use with RadioPair.
    LABELS = 'labels'

    # tuple
    # low, high
    # limit self value range of a Slider
    LIMIT = 'limit'

    # list
    # of strings for combobox
    LIST = '_list'

    # list of string
    # of signal ids for subscribe
    LISTEN = 'listen'

    # int
    # Set the minimum width of a TreeViewList column.
    MINIMUM_WIDTH = 'minimum_width'

    # Model
    # Has cell table.
    MODEL = 'model'

    # function
    # Call when a ModelList item is moved.
    MOVE_LIST_ITEM = 'move_list_item'

    # string
    # Use to pass a Model item name.
    NAME = 'name'

    # string
    # key in 'main_dict' of Nodes
    # Use to distinguish option groups in different configurations.
    NODE_KEY = 'node_key'

    # function
    # callback for an Accept Button
    ON_ACCEPT = 'on_accept'

    # function
    # callback for a Cancel Button
    ON_CANCEL = 'on_cancel'

    # function
    # callback on a key-press
    ON_KEY_PRESS = 'on_key_press'

    # function
    # callback for a Preview Button action
    ON_PREVIEW_BUTTON = 'on_preview_button'

    # function
    # callback for Widget change
    ON_WIDGET_CHANGE = 'on_widget_change'

    # function
    # Is a callback for a Button-click action.
    # Use with the OSButton.
    OS_BUTTON_CLICK = 'os_button_click'

    # tuple
    # Alignment padding
    PADDING = 'padding'

    # Port
    # Use to id a port.
    PORT = 'port'

    # int
    # number of digits after the decimal point
    # Is zero for an integer.
    PRECISION = 'precision'

    # string
    # Use as a Widget key for Presets.
    PRESET = "Preset"

    # function
    # Is a callback to show a preview for a satellite Window.
    PREVIEW = 'preview'

    # RadioButton
    # Is used to define the lead
    # RadioButton for a group of RadioButtons.
    RADIO_GROUP = 'radio_group'

    # tuple
    # Define a random-function limitation.
    RANDOM = 'random'

    # bool
    # When true, a Widget has its own random function named 'randomize'.
    RANDOMIZE = 'randomize'

    # RWSave
    # Use to remove a circular import reference problem to a Port.
    SAVE_WINDOW = 'save_window'

    # string
    # signal id
    # Tell a Widget to send a signal when the Widget changes.
    SENDER = 'sender'

    # function
    # Use to set cell tooltips in the cell editor.
    SET_TOOLTIP = 'set_tooltip'

    # tuple
    # Use to id an OptionGroup.
    STEP = 'step'

    # tuple
    # row, column counts of a cell table
    TABLE_SIZE = 'table_size'

    # string
    # for CheckButton, Label
    TEXT = 'text'

    # tuple
    # Use to set multiple tooltips.
    TIPS = 'tips'

    # for OptionButton
    TIP_TYPE = 'tip_type'

    # string
    # for a tooltip
    TOOLTIP = 'tooltip'

    # int
    # padding for the top of a Widget Table
    TOP_PAD = 'top_pad'

    # Set a Widget class.
    WIDGET = 'widget'

    # GTK Window or a Window
    WIN = 'win'

    # string
    # Use to pass a Window's key for storage in the Window position dict.
    WINDOW_KEY = 'window_key'

    # string
    # Use when creating a Window.
    WINDOW_TITLE = 'window_title'


class Window:
    """
    Has keys used in the Window position dictionary.
    Use key with a Window type.
    Import as 'wi'.
    """
    BUMP_CHOOSER = 'bump_chooser'
    BRUSH_CHOOSER = 'brush_chooser'
    CELL_MOD = 'cell_mod'
    CHOOSER = 'chooser'
    INFLUENCER = 'influencer'
    IMAGE_CHOOSER = 'image_chooser'
    MAIN = 'main'
    MARGIN_CHOOSER = 'margin_chooser'
    PRESET = 'preset'
    RESIZE_CHOOSER = 'resize_chooser'
    SAVE = 'save'
    SHADOW_CHOOSER = 'shadow_chooser'
    SHIFT_CHOOSER = 'shift_chooser'
    STRIPE = 'stripe'
