#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import (
    Effect as ek,
    Layer as nk,
    Model as md,
    Option as ok
)
from roller_one import Hat
from roller_one_fu import Lay, Mage, Sel
import gimpfu as fu

pdb = fu.pdb
FEATHER = ek.FEATHER_STEPS


def do_face(j, o):
    """
    Do the Image Effect for each Face.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        with Image Effect
    """
    if len(o.image_layer.layers):
        image_layer = Lay.merge_group(Lay.clone(o.image_layer))
        z = do_image(j, image_layer, o)

        Lay.hide(o.image_layer)
        Lay.remove(image_layer)
        return z


def do_image(j, image_layer, o):
    """
    Feather the image material on a layer.

    image_layer: layer
        with image material

    j: GIMP image
        Is render.
        not used

    o: One
        Has variables.

    Return: layer or None
        with feather
    """
    z = Lay.clone(image_layer)

    if pdb.gimp_item_is_group(z):
        z = Lay.merge_group(z)

    z.name = Lay.name(z.parent, FEATHER)

    Lay.hide(image_layer)
    Lay.show(z)
    FeatherSteps.feather(z, o.d)
    return z


class FeatherSteps:
    """Feather the edges of image material."""

    @staticmethod
    def do(o):
        """
        Do the Feather Steps Image Effect.
        Is an Image Effect template function.

        o: One
            Has variables.

        Return: layer or list of layers
            with Feather Steps
        """
        z = o.image_layer
        j = Hat.cat.render.image

        # Is a list of layers for a Preview undo function, 'undo_z'.
        undo_z = []

        # There is no shadow.
        o.shadow_layer = []

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [do_image(j, i.layers[0], o)]

        else:
            if o.model_type == md.BOX:
                undo_z = do_face(j, o)

            else:
                undo_z = do_image(j, z, o)
            Hat.cat.register_layer(
                (o.render_type, o.model_name, nk.IMAGE),
                undo_z
            )
        return undo_z

    @staticmethod
    def feather(z, d):
        """
        Feather image material with linear growth repeating steps.

        z: layer
            Has image material to feather. Could possibly have a layer mask.

        d: dict
            Has feather options.
        """
        if z:
            j = z.image
            a = d[ok.FEATHER]
            f = float(a) / d[ok.STEPS]
            b = f

            Mage.expand_image(j, a)

            while a > b:
                Sel.make_layer_sel(z)
                pdb.gimp_selection_feather(j, b)

                if Sel.is_sel(j):
                    Sel.invert_clear(z)

                else:
                    break
                b = min(b + f, a)
            Mage.contract_image(j, a)

    @staticmethod
    def feather_layer_sel(z, d):
        """
        Feather material with linear growth
        repeating steps using an existing layer.

        z: layer
            Has material to feather.

        d: dict
            Has feather options.
        """
        if z:
            j = z.image
            a = d[ok.FEATHER]
            f = float(a) / d[ok.STEPS]
            b = f

            Mage.expand_image(j, a)

            while a > b:
                Sel.item(z)
                pdb.gimp_selection_feather(j, b)

                if Sel.is_sel(j):
                    Sel.invert_clear(z)

                else:
                    break
                b = min(b + f, a)
            Mage.contract_image(j, a)

    @staticmethod
    def feather_sel(j, d):
        """
        Feather a selection with linear growth
        repeating steps using an existing selection.

        j: GIMP image
            Has selection.

        d: dict
            Has feather options.
        """
        a = d[ok.FEATHER]
        f = float(a) / d[ok.STEPS]
        b = f
        if a:
            Mage.expand_image(j, a)

            while a > b:
                pdb.gimp_selection_feather(j, b)
                b = min(b + f, a)
            Mage.contract_image(j, a)
