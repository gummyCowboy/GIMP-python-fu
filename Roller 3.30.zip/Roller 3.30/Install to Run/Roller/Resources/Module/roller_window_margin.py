#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk, Window as wi
from roller_option_group import OptionGroup
from roller_option_preset import Preset
from roller_option_preset_dict import PresetDict
from roller_port_preview import PortPreview
from roller_window import Window
from roller_window_save import RWSave


class RWMargin(Window):
    """Is a GTK Dialog for defining a margins."""
    def __init__(self, g):
        """
        Create a Window.

        g: OptionButton
            Is responsible.
        """
        self.safe = g
        d = {
            wk.WIN: g.win.win,
            wk.WINDOW_TITLE: g.key + " Settings",
            wk.WINDOW_KEY: wi.MARGIN_CHOOSER
        }

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortMargin(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()


class PortMargin(PortPreview):
    """Is a Margin Port, a container for the various options."""

    def __init__(self, d, g):
        """
        Draw the Window.

        d: dict
            Has init values.

        g: OptionButton
            Has option values.
        """
        PortPreview.__init__(self, d, g)

    def _draw_margins(self, g):
        """
        Draw and load the option group.

        g: VBox
            container for Widgets
        """
        k = self.safe.key
        d = OptionGroup.draw_group(
            **{
                wk.COLOR: self.color,
                wk.CONTAINER: g,
                wk.GROUP_KEY: k,
                wk.GROUP_TYPE: Preset,
                wk.HAS_PRESET: True,
                wk.IS_DEFAULT: False,
                wk.KEYS: PresetDict.get_keys(k),
                wk.ON_KEY_PRESS: self.on_key_press,
                wk.ON_PREVIEW_BUTTON: self.task_preview,
                wk.ON_WIDGET_CHANGE: self.on_widget_change,
                wk.STEP: self.safe.group.step[:3] + (k,),
                wk.PORT: self,
                wk.SAVE_WINDOW: RWSave,
                wk.WIN: self.roller_window
            }
        )
        g = self.preset = d[wk.PRESET]
        self.group = g.group
        g.load_preset(self.safe.get_value())

    def draw_port(self, g):
        """
        Draw the Port's Widgets. Is part of the Port template.

        g: VBox
            container for the Widgets
        """
        self.draw_simple_dialog_port(
            g,
            (self._draw_margins, self.draw_preview_process),
            ("Set Margins", "")
        )

    def get_group_value(self):
        """
        Get the Preset value. Is a PortPreview template function.

        Return: dict
            Margin Preset
        """
        return self.preset.get_value()
