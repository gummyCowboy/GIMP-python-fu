#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as fo, Gradient as fg
from roller_constant_key import (Group as gk, Layer as nk, Option as ok)
from roller_constant_fu import Fu
from roller_model_image import Image
from roller_one import Hat
from roller_one_fu import Lay, Mage, Sel
from roller_option_preset_dict import PresetDict
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu
import os

gf = Fu.GradientFill
pdb = fu.pdb
SEP = os.path.sep


def do_color(z, d, _):
    """
    Color the frame with a single color.

    z: layer
        Is frame.

    d: dict
        Has options.

    _: dict
        image index
        unused

    Return: layer
        with frame material
    """
    Sel.item(z)
    Sel.fill(z, d[ok.COLOR_1])
    return z


def do_gradient(z, d, _):
    """
    Color the frame with a gradient.

    z: layer
        Is frame.

    d: dict
        Has options.

    _: dict
        image index
        unused

    Return: layer
        with frame material
    """
    j = z.image

    RenderHub.set_fill_context(fg.FILL_DICT)
    RenderHub.set_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        fu.GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(0)
    Sel.item(z)

    is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
    w, h = x1 - x, y1 - y
    if is_sel:
        sel = Hat.cat.save_short_term_sel()
        start_x, end_x, start_y, end_y = \
            RenderHub.get_gradient_points(
                d[ok.GRADIENT_ANGLE],
                x, y,
                w, h
            )

        Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(d[ok.GRADIENT_TYPE]),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            start_x, start_y,
            end_x, end_y
        )

        Lay.blur(z, d[ok.BLUR])
        Sel.isolate(z, sel)
    return z


def do_table(o, z):
    """
    Process a Table Model.

    o: One
        Has variables.

    z: layer
        with image material

    return: layer
        with frame material
    """
    cat = Hat.cat
    row, column = o.model.division
    n = z.parent.name.split(" ")[-1]
    for r in range(row):
        for c in range(column):
            k = o.model_name, r, c

            if o.is_nested_group:
                if cat.get_z_height(k) == n:
                    cat.join_selection(k)
                    make_frame(z, o)
            else:
                # one layer
                cat.join_selection(k)
                make_frame(z, o)


def do_image(z, d, image_index):
    """
    Color the frame with an image.

    z: layer
        Is frame.

    d: dict
        Has options.

    Return: layer
        with frame material
    """
    j = z.image
    e = d[ok.IMAGE]
    j1 = Image.get_image(e, image_index)

    if j1:
        j1 = j1.j

        Sel.item(z)

        sel = Hat.cat.save_short_term_sel()
        if sel:
            Mage.copy_all(j1)
            Image.close_image(j1)

            j1 = pdb.gimp_edit_paste_as_new_image()

            Sel.load(j, sel)

            is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
            if is_sel:
                Mage.shape(j1, x1 - x, y1 - y)
                pdb.gimp_selection_none(j)

                z1 = Lay.paste(z)

                pdb.gimp_layer_set_offsets(z1, x, y)
                Lay.blur(z1, d[ok.BLUR])
                Sel.isolate(z1, sel)

                n = z.name

                j.remove_layer(z)

                z1.name = n
                return z1
    return z


def do_plasma(z, d, _):
    """
    Color the frame with a plasma effect.

    z: layer
        Is frame.

    d: dict
        Has options.

    _: dict
        image index
        unused

    Return: layer
        with frame material
    """
    j = z.image

    Sel.item(z)

    sel = Hat.cat.save_short_term_sel()

    if sel:
        pdb.gimp_selection_none(j)
        pdb.plug_in_plasma(
            j, z,
            d[ok.RANDOM_SEED],
            Fu.Plasma.LOWEST_TURBULENCE
        )
        Sel.load(j, sel)
        Sel.invert_clear(z, keep_sel=True)
        Lay.blur(z, d[ok.BLUR])
    return z


def make_frame(image_layer, o):
    """
    Make a frame. The image material is already selected on entry.

    o: One
        Has variables.

    k: string or tuple
        key to the image selection
    """
    cat = Hat.cat
    j = cat.render.image

    # Frame Over Preset dict, 'o.d'
    d = o.d

    parent = image_layer.parent
    if Sel.is_sel(j):
        sel = cat.save_short_term_sel()

        # Is there a frame layer?
        if not o.frame_layer:
            # Add the group layer above the image layer.
            group = Lay.group(j, Lay.name(parent, o.k), parent=parent)
            o.frame_layer = Lay.add(
                j,
                "Frame Base",
                parent=group,
                offset=Lay.offset(image_layer)
            )

        # Has the frame image been loaded?
        if not o.frame_image:
            n = "{}{}{}.png".format(cat.frame_path, SEP, d[ok.FRAME])
            e = PresetDict.get_default(gk.IMAGE_CHOICE)
            e[ok.FILE] = n
            e[ok.IMAGE_SOURCE] = ok.FILE

            # Get the GIMP image.
            j1 = Image.get_image(e, o.image_index)
            if j1:
                o.frame_image = j1.j
        if o.frame_image:
            Mage.copy_all(o.frame_image)

            j1 = pdb.gimp_edit_paste_as_new_image()

            Sel.load(j, sel)

            is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
            if is_sel:
                Mage.shape(j1, x1 - x, y1 - y)
                pdb.gimp_selection_none(j)

                z = Lay.paste(o.frame_layer, n="Frame")
                pdb.gimp_layer_set_offsets(z, x, y)


def do_layer(image_layer, o):
    """
    Add a frame to the image material on a layer.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    # Frame Over Preset dict, 'o.d'
    d = o.d

    if d[ok.OPACITY] and d[ok.FRAME] != "None":
        o.frame_layer = o.frame_image = None

        if o.is_nested_group:
            do_table(o, image_layer)

        else:
            Sel.make_layer_sel(image_layer)
            make_frame(image_layer, o)
        if o.frame_layer:
            e = {
                fo.COLOR: do_color,
                fo.GRADIENT: do_gradient,
                fo.IMAGE: do_image,
                fo.PLASMA: do_plasma
            }

            # Create the combined frame layer.
            z = Lay.merge_group(o.frame_layer.parent)

            n = d[ok.FRAME_STYLE]

            if n in e:
                z = e[n](z, d, o.image_index)

            z.mode, z.opacity = RenderHub.get_mode(d)

            if d[ok.BLUR_BEHIND]:
                if RenderHub.blur_behind_frame(z, d[ok.BLUR_BEHIND]):
                    z = Lay.merge(z)

            z = RenderHub.bump(z, d[ok.BUMP])
            z = GradientLight.apply_light(z, ok.OTHER_FRAME)

            # Clip Frame Over material to match the image material.
            z1 = Lay.clone_opaque(image_layer)

            Sel.item(z1)
            Sel.invert_clear(z)
            Lay.remove(z1)
            return z


class FrameOver:
    """Create a frame-mask overlay on each image."""

    @staticmethod
    def do(o):
        """
        Make the Frame Over Image Effect. Is an Image Effect template function.

        o: One
            Has variables.

        Return: list of layers
            with Frame Over
        """
        cat = Hat.cat
        j = cat.render.image
        z = o.image_layer
        is_merge_group = False

        # Is a list of layers for a Preview undo function, 'undo_z'.
        undo_z = []

        # for Shadow #1 and Shadow #2
        o.shadow_layer = []

        if o.is_nested_group:
            for i in z.layers:
                z1 = i.layers[0]
                z2 = do_layer(z1, o)
                if z2:
                    Lay.clone(z1)
                    Lay.hide(z1)

                    z2 = Lay.merge(z2)
                    undo_z += [z2]

                    cat.del_image_layer(z1.name)

                    # There's are multiple image/frame layers,
                    # so the image specific save is used.
                    # Is used by the shadow Image Effect.
                    cat.save_image_layer(z2)
            o.shadow_layer = [z]

        else:
            if pdb.gimp_item_is_group(z):
                z1 = Lay.clone(z)
                z = Lay.merge_group(z1)
                is_merge_group = True

            z1 = do_layer(z, o)
            if z1:
                if not is_merge_group:
                    # image layer, 'z'
                    Lay.clone(z)
                    Lay.hide(z)

                else:
                    offset = max(0, pdb.gimp_image_get_item_position(j, z) - 1)
                    pdb.gimp_image_reorder_item(j, z1, o.parent, offset)
                    Lay.hide(o.image_layer)

                # Combine the frame and image into a layer, 'z'.
                z = Lay.merge(z1)

                # There's only one image/frame layer, so the register is used.
                # Is used by the shadow image-effect.
                cat.register_layer(
                    (o.render_type, o.model_name, nk.IMAGE),
                    z
                )

                # The Frame Over layer has the image layer included.
                o.shadow_layer = [z]
                undo_z = [z]
        return undo_z
