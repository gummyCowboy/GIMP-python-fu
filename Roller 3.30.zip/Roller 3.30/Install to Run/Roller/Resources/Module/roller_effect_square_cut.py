#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_color_grid import ColorGrid
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb


def make_sel(o, effect_layer, frame_sel, filler_sel):
    """
    Make square holes in a frame.

    o: One
        Has options.

    effect_layer: layer
        work-in-progress

    frame_sel: Selection
        the frame

    filler_sel: Selection
        for the Square Cut material

    Return: layer
        with Square Cut material
    """
    d = o.d
    cat = Hat.cat
    j = cat.render.image
    z = Lay.add(j, o.k, parent=effect_layer.parent)

    pdb.gimp_selection_none(j)

    d[ok.COLOR_2A] = (0, 0, 0, 255), (255, 255, 255, 255)
    z = ColorGrid.draw_color_grid(z, d)

    Sel.isolate(z, filler_sel)
    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    Sel.item(z)
    Sel.grow(j, 1, 1)
    Sel.load(j, frame_sel, option=fu.CHANNEL_OP_ADD)
    j.remove_layer(z)


class SquareCut:
    """Create a frame with a square grid."""

    @staticmethod
    def do(o):
        """
        Do the Image Effect. Is an Image Effect template function.

        o: One
            Has variables.

        Return: layer or list of layers
            with Square Cut frame
        """
        return BorderLine.do(o, framer=make_sel, filler=lambda *q, **k: None)
