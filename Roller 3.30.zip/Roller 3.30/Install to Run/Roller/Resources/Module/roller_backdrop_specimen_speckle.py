#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat, One
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
DIRECTION = range(4)
X_IS_1 = Y_IS_1 = 1


class SpecimenSpeckle:
    """
    Mix three patterns using layer modes. Shred the patterns
    with a wind function. Use colorize to give it extra
    interest. Use a gradient to increase organic randomness.
    """

    @staticmethod
    def do(o):
        """
        Create the Specimen Speckle Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            with Specimen Speckle
        """
        def do_hard_mix(_pattern):
            """
            Create a Hard Mix layer.

            _pattern: string
                pattern id

            Return: layer
                the hard mix layer
            """
            _z = Lay.clone(z, n="Hard Mix")
            _z.opacity = 50.
            _z.mode = fu.LAYER_MODE_HARD_MIX

            RenderHub.set_pattern({ok.PATTERN: _pattern})
            pdb.gimp_drawable_edit_bucket_fill(
                _z,
                fu.FILL_PATTERN,
                X_IS_1, Y_IS_1
            )

            do_wind(_z)
            return _z

        def do_overlay():
            """
            Create an Overlay layer.

            Return: layer
                the overlay layer
            """
            _z = Lay.clone(z, n="Overlay")
            _z.opacity = 100.
            _z.mode = fu.LAYER_MODE_OVERLAY

            pdb.gimp_drawable_invert(_z, 0)
            Lay.blur(_z, 5)
            return _z

        def do_wind(_z):
            """
            Do the wind function for each of the four directions.

            _z: layer
                to receive wind
            """
            for i in DIRECTION:
                pdb.plug_in_wind(
                    j, _z,
                    Fu.Wind.THRESHOLD_0,
                    i,
                    Fu.Wind.STRENGTH_25,
                    Fu.Wind.BLAST,
                    Fu.Wind.LEADING_EDGE
                )

        cat = Hat.cat
        j = cat.render.image

        # Specimen Speckle Preset dict, 'o.d'
        d = o.d

        if d[ok.OPACITY]:
            # Group key, 'o.k'
            group = Lay.group(j, o.k)

            # Backdrop Image layer, 'o.z'
            # for GradientFill
            o.z = Lay.clone(o.z, n="Duplicate Backdrop Image")

            group1 = Lay.group(j, o.k, parent=group, z=o.z)

            do_wind(o.z)

            n = d[ok.MODE]
            f = d[ok.OPACITY]
            d[ok.MODE] = "Normal"
            d[ok.OPACITY] = 100.
            d[ok.START_X] = d[ok.START_Y] = 0.
            d[ok.END_X] = d[ok.END_Y] = 1.
            one = One(d=d)
            z = GradientFill.do_layer(j, one)

            pdb.gimp_image_reorder_item(j, z, group1, 0)

            d[ok.MODE] = n
            d[ok.OPACITY] = f

            do_overlay()

            # gradient
            d[ok.END_X] = d[ok.END_Y] = 0.
            d[ok.START_X] = d[ok.START_Y] = 1.
            z = GradientFill.do_layer(j, one)
            z.opacity = 50.
            z.mode = fu.LAYER_MODE_NORMAL

            pdb.gimp_image_reorder_item(j, z, group1, 0)
            RenderHub.set_fill_context(
                {
                    ok.THRESHOLD: .6,
                    ok.OPACITY: 100.,
                    ok.MODE: "Normal",
                    ok.CRITERION: "Composite"
                }
            )

            # pattern #1
            z = do_hard_mix(d[ok.PATTERN_1])
            z = do_overlay()

            # pattern #2
            z = do_hard_mix(d[ok.PATTERN_2])
            z = do_overlay()

            # pattern #3
            z = do_hard_mix(d[ok.PATTERN_3])

            do_overlay()

            # phase two
            z = Lay.merge_group(group1)
            z1 = Lay.clone(z)
            z2 = Lay.clone(z1)

            Lay.clone(z2)
            Lay.blur(z1, 6)
            Lay.blur(z2, 6)
            pdb.gimp_drawable_invert(z1, Fu.DrawableInvert.NO_LINEAR)

            z = Lay.merge_group(group)
            z = z1 = Lay.clone(z, n="Hard Mix")
            z.mode = fu.LAYER_MODE_HARD_MIX
            z = Lay.clone(z, n="LCH Color")
            z.mode = fu.LAYER_MODE_LCH_COLOR

            pdb.plug_in_colorify(j, z, d[ok.COLOR_1])
            pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
            return RenderHub.bump(Lay.merge(z), d[ok.BUMP])
