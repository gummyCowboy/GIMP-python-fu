#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as fo
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub, PROFILE
import gimpfu as fu

em = Fu.Emboss
pdb = fu.pdb
um = Fu.UnsharpMask


def do_image(j, image_layer, o):
    """
    Add frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    cat = Hat.cat

    # Glass Reveal Preset dict, 'o.d'
    d = o.d

    if d[ok.OPACITY]:
        parent = image_layer.parent
        group = Lay.group(
            j,
            Lay.name(parent, o.k),
            parent=parent
        )
        z = Lay.add(j, o.k, parent=group)

        # The Stack Model has a group of stacked image layers.
        if pdb.gimp_item_is_group(image_layer):
            z1 = Lay.merge_group(Lay.clone(image_layer))
            z2 = Lay.clone_opaque(z1)

            Lay.remove(z1)
            z1 = z2

        else:
            z1 = Lay.clone_opaque(image_layer)

        color = 255, 255, 255
        w = d[ok.FRAME_WIDTH]
        q = PROFILE[d[ok.PROFILE]](w, *(color,))

        Sel.make_layer_sel(z1)
        RenderHub.draw_color_profile(z, w, q, color)
        j.remove_layer(z1)

        if d[ok.CURVE] != "None":
            q = fo.CURVE_DICT[d[ok.CURVE]]
            pdb.gimp_drawable_curves_spline(z, fu.HISTOGRAM_VALUE, len(q), q)

        if d[ok.EMBOSS]:
            z = Lay.clone(z)

            pdb.plug_in_emboss(
                j, z,
                cat.azimuth,
                cat.elevation,
                w // 3,
                em.BUMP
            )

            z.opacity = 50. if w < 60. else 100.
            z.mode = fu.LAYER_MODE_MULTIPLY
            z = Lay.clone(z)
            z.mode = fu.LAYER_MODE_SCREEN

        z = Lay.merge_group(group)
        z.opacity = d[ok.OPACITY]
        return GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)


class GlassReveal:
    """Create a glass-like border."""

    @staticmethod
    def do(o):
        """
        Do the Image Effect. Is an Image Effect template function.

        o: One
            Has variables.

        Return: layer or list of layers
            with Glass Reveal
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # Is a list of layers for a Preview undo function, 'undo_z'.
        undo_z = []

        # for Shadow #1 and Shadow #2
        o.shadow_layer = []

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [do_image(j, i.layers[0], o)]
            o.shadow_layer = [z]

        else:
            undo_z = do_image(j, z, o)
            if undo_z:
                o.shadow_layer = [undo_z, z]
        return undo_z
