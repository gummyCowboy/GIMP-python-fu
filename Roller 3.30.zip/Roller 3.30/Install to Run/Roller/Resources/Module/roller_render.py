#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Plan as fy, Plaque as aq
from roller_constant_key import (
    Group as gk,
    Image as ik,
    Layer as nk,
    Model as md,
    Option as ok,
    Plan as ak
)
from roller_model import Box, CustomCell, Stack, Table
from roller_model_border import Border
from roller_model_caption import Caption
from roller_model_fringe import Fringe
from roller_model_mask import Mask
from roller_model_place import Place
from roller_model_plaque import Plaque
from roller_one import Base, Hat
from roller_one_extract import Form, Step
from roller_one_fu import Lay
from roller_option_preset_core import Core
import gimpfu as fu

pdb = fu.pdb
PLAN = 'plan'
PRODUCT = 'product'

# Is a dispatch switch for a Border option group.
ASSIGN_BORDER = {
    md.BOX: Border.do_box,
    md.CUSTOM_CELL: Border.do_custom_cell,
    md.STACK: Border.do_custom_cell,
    md.TABLE: Border.do_table
}

# Is a dispatch switch for a Caption option group.
ASSIGN_CAPTION = {
    md.BOX: Caption.do_box,
    md.CUSTOM_CELL: Caption.do_custom_cell,
    md.STACK: Caption.do_stack,
    md.TABLE: Caption.do_grid
}

# Is a dispatch switch for a Fringe option group.
ASSIGN_FRINGE = {
    md.BOX: Fringe.do_box,
    md.CUSTOM_CELL: Fringe.do_custom_cell,
    md.STACK: Fringe.do_custom_cell,
    md.TABLE: Fringe.do_table
}

# Is a dispatch switch for a Mask option group.
ASSIGN_MASK = {
    md.BOX: Mask.do_box,
    md.CUSTOM_CELL: Mask.do_custom_cell,
    md.STACK: Mask.do_stack,
    md.TABLE: Mask.do_layers
}

# Is a dispatch switch for a Place option group.
ASSIGN_PLACE = {
    md.BOX: Place.do_box,
    md.CUSTOM_CELL: Place.do_custom_cell,
    md.STACK: Place.do_stack,
    md.TABLE: Place.do_table
}

# Is a dispatch switch for a Cell-type Plaque option group.
ASSIGN_PLAQUE = {
    md.BOX: Plaque.do_box,
    md.CUSTOM_CELL: Plaque.do_custom_cell,
    md.STACK: Plaque.do_custom_cell,
    md.TABLE: Plaque.do_grid
}


class Render:
    """
    Is factored from the classes Product and Plan.
    Use to make a Preview, Render or Plan in steps. Steps are
    tuples where each selected Node item in the navigation
    tree is included in sequential order: (item1, item2, item3, etc.).
    """
    # Use with the Image class. Is the initial dict
    # structure for the image indices in the Image Preset.
    IMAGE_INDEX = {
        # Is a condition that will cause an init function
        # to perform by an Image class' function, '-2'.
        ik.LOOP_DICT: {ik.LOOP: -2, ik.SLICE: {}},
        ik.NEXT_DICT: {ik.NEXT: 0, ik.SLICE: {}},
        ik.PREVIOUS_DICT: {ik.PREVIOUS: -2, ik.SLICE: {}},
        ik.SLICE: {}
    }

    def __init__(self, render_type):
        """Initialize common variables."""
        self.render_type = render_type
        self.model = \
            self.model_type = \
            self.model_name = \
            self.plan_group = \
            self.model_group = \
            self.backdrop_layer = None

        self.undo = {}
        self.plan_flags = {}
        self.image_index = deepcopy(Render.IMAGE_INDEX)

        # Does not have dependency with Canvas Margin.
        self.non_canvas_d = {
            gk.GLOBAL: self._do_global,

            # Box
            gk.BOX_CELL_CAPTION: self._do_caption,
            gk.BOX_CELL_PLAQUE: self._do_cell_plaque,
            gk.BOX_PROPERTY: self._do_box_property,
            gk.FACE_PLACE: self._do_place,
            gk.GROUP_BORDER: self._do_group_border,
            gk.GROUP_CAPTION: self._do_group_caption,
            gk.GROUP_FRINGE: self._do_group_fringe,
            gk.GROUP_PLACE: self._do_group_place,
            gk.GROUP_PLAQUE: self._do_group_plaque,
            gk.TYPE_BOX: self._do_cell_type,

            # Custom Cell
            gk.CUSTOM_CELL_BORDER: self._do_cell_border,
            gk.CUSTOM_CELL_CAPTION: self._do_caption,
            gk.CUSTOM_CELL_FRINGE: self._do_cell_fringe,
            gk.CUSTOM_CELL_MASK: self._do_mask,
            gk.CUSTOM_CELL_PLACE: self._do_place,
            gk.CUSTOM_CELL_PLAQUE: self._do_cell_plaque,
            gk.CUSTOM_CELL_MARGIN: self._do_margin,
            gk.CUSTOM_CELL_PROPERTY: self._do_custom_cell_property,
            gk.RECTANGLE: self._do_rectangle,
            gk.TYPE_CUSTOM_CELL: self._do_cell_type,

            # Stack
            gk.STACK_CELL_MARGIN: self._do_margin,
            gk.STACK_PLACE: self._do_place,
            gk.TYPE_STACK: self._do_cell_type,
            gk.STACK_PROPERTY: self._do_stack_property,

            # Table
            gk.CELL_BORDER: self._do_cell_border,
            gk.CELL_CAPTION: self._do_caption,
            gk.CELL_FRINGE: self._do_cell_fringe,
            gk.CELL_MASK: self._do_mask,
            gk.CELL_PLACE: self._do_place,
            gk.CELL_MARGIN: self._do_margin,
            gk.CELL_PLAQUE: self._do_cell_plaque,
            gk.TABLE_PROPERTY: self._do_table_property,
            gk.TYPE_TABLE: self._do_cell_type
        }

        # Has dependency with Canvas Margin.
        self.canvas_d = {
            gk.CANVAS_BORDER: self._do_canvas_border,
            gk.CANVAS_CAPTION: self._do_canvas_caption,
            gk.CANVAS_FRINGE: self._do_canvas_fringe,
            gk.CANVAS_PLAQUE: self._do_canvas_plaque
        }

    def _do_box_property(self, o):
        """
        Create a Box Model layer group for the View op.

        o: One
            Has variables.
        """
        self._do_property(o, Box(o), md.BOX, ok.BOX_PLAN)

    def _do_canvas_border(self, o):
        """
        Draw a Canvas Border.

        o: One
            Has variables.
        """
        go = True
        is_plan = False

        if self.render_type == PLAN:
            if not self.plan_flags[ak.BORDER]:
                go = False
            else:
                is_plan = True
                o.color = fy.CANVAS_BORDER_COLOR
        if go:
            z = Border.do_canvas(o, is_plan)

            if is_plan and z:
                z.opacity = 66.
                z.name = nk.CANVAS_BORDER
            self.undo[o.step] = z, Lay.remove

    def _do_canvas_caption(self, o):
        """
        Draw a Canvas Caption.

        o: One
            Has variables.
        """
        go = True
        is_plan = False

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CAPTION]:
                go = False
            else:
                is_plan = True
                o.color = fy.CANVAS_CAPTION_COLOR
        if go:
            z = Caption.do_canvas(o, is_plan)

            if is_plan and z:
                z.opacity = 66.
                z.name = nk.CANVAS_CAPTION
            self.undo[o.step] = z, Lay.remove

    def _do_canvas_fringe(self, o):
        """
        Draw Canvas Fringe.

        o: One
            container
            Has variables.
        """
        go = True
        is_plan = False

        if self.render_type == PLAN:
            is_plan = True

            if not self.plan_flags[ak.CANVAS_FRINGE]:
                go = False
            else:
                o.color = fy.CANVAS_FRINGE_COLOR
        if go:
            d = deepcopy(self.image_index)
            o.plaque_layer = Hat.cat.get_layer(
                (self.render_type, self.model_name, nk.CANVAS_PLAQUE)
            )
            z = Fringe.do_canvas(o, is_plan)

            if is_plan and z:
                z.opacity = 66.
                z.name = nk.CANVAS_FRINGE
            self.undo[o.step] = (
                (z, o.plaque_layer, o.is_mask, o.is_paint, d),
                self._undo_fringe
            )

    def _do_canvas_plaque(self, o):
        """
        Draw a Canvas Plaque.

        o: One
            Has variables.
        """
        cat = Hat.cat
        d = o.d
        e = Base.copy_sel_dict(cat.plaque_sel)
        d1 = deepcopy(self.image_index)
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CANVAS_PLAQUE]:
                go = False
            else:
                is_plan = True
                o.color = fy.CANVAS_PLAQUE_COLOR
                if d[ok.PLAQUE_TYPE] != "None":
                    d[ok.PLAQUE_TYPE] = aq.COLOR
        if go and d[ok.PLAQUE_TYPE] != "None":
            k = self.render_type, self.model_name, nk.CANVAS_PLAQUE

            plaque_layer = cat.get_layer(k)
            z = Plaque.do_canvas(o, is_plan)

            if is_plan and z:
                z.name = nk.CANVAS_PLAQUE
                z.opacity = 66.

            self.undo[o.step] = (
                (z, e, plaque_layer, d1),
                self._undo_canvas_plaque
            )
            # Register the Plaque layer for the Fringe Mask option.
            Hat.cat.register_layer(k, z)

    def _do_caption(self, o):
        """
        Make a Cell-based Caption.

        o: One
            Has variables.
        """
        cat = Hat.cat
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CAPTION]:
                go = False
            else:
                is_plan = True
                o.color = fy.CELL_STRIPE_COLOR
        if go:
            k = (
                self.render_type,
                self.model_name,
                Step.get_face_index(o.step),
                nk.CELL_CAPTION
            )

            caption_layer = cat.get_layer(k)
            d = Base.copy_sel_dict(cat.caption_stripe_sel)
            z = ASSIGN_CAPTION[o.model_type](o, is_plan)

            if is_plan and z:
                z.name = "Cell Caption"
                z.opacity = 66.

            self.undo[o.step] = (z, d, caption_layer), self._undo_caption
            if not is_plan:
                # for the Blur Behind Caption Background Stripe option
                cat.register_layer(k, z)

    def _do_cell_border(self, o):
        """
        Draw Cell-based Borders.

        o: One
            Has variables.
        """
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.BORDER]:
                go = False
            else:
                is_plan = True
                o.color = fy.CELL_BORDER_COLOR
        if go:
            z = ASSIGN_BORDER[o.model_type](o, is_plan)

            if is_plan and z:
                z.name = "Cell Border"
                z.opacity = 66.
            self.undo[o.step] = z, Lay.remove

    def _do_cell_fringe(self, o):
        """
        Draw Cell-based Fringe.

        o: One
            Has variables.
        """
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CELL_FRINGE]:
                go = False
            else:
                is_plan = True
                o.color = fy.CELL_FRINGE_COLOR
        if go:
            d = deepcopy(self.image_index)
            o.plaque_layer = Hat.cat.get_layer(
                (
                    self.render_type,
                    o.model_name,
                    Step.get_face_index(o.step),
                    nk.CELL_PLAQUE
                )
            )
            z = ASSIGN_FRINGE[o.model_type](o, is_plan)

            if is_plan and z:
                z.opacity = 66.
            self.undo[o.step] = (
                (z, o.plaque_layer, o.is_mask, o.is_paint, d),
                self._undo_fringe
            )

    def _do_cell_plaque(self, o):
        """
        Draw Cell-based Plaque material.

        o: One
            Has variables.
        """
        cat = Hat.cat
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CELL_PLAQUE]:
                go = False
            else:
                is_plan = True
                o.color = fy.CELL_PLAQUE_COLOR
        if go:
            k = (
                self.render_type,
                self.model_name,
                Step.get_face_index(o.step),
                nk.CELL_PLAQUE
            )
            plaque_layer = cat.get_layer(k)
            d = Base.copy_sel_dict(cat.plaque_sel)
            e = deepcopy(self.image_index)
            z = ASSIGN_PLAQUE[o.model_type](o, is_plan)

            if z and is_plan:
                z.name = "Cell Plaque"
                z.opacity = 66.

            self.undo[o.step] = (z, d, plaque_layer, e), self._undo_cell_plaque

            # Register the Plaque layer for the Fringe Mask option.
            cat.register_layer(k, z)

    def _do_custom_cell_property(self, o):
        """
        Do a Custom Cell's Property.

        o: One
            Has variables.
        """
        self._do_property(o, CustomCell(o), md.CUSTOM_CELL, ok.CELL_PLAN)

    def _do_cell_type(self, o):
        """
        Do a Model's Cell Type.

        o: One
            Has variables.
        """
        a = self.model.clone()

        self.model.update_type(o)
        self.undo[o.step] = (a,), self._undo_model

    def _do_global(self, o):
        """
        Set the Global options in 'cat'. There
        is no undo for this group's change.

        o: One
            Has variables.
        """
        # Global Preset dict, 'o.d'
        d = o.d

        cat = Hat.cat
        cat.elevation = d[ok.ELEVATION]
        cat.azimuth = d[ok.AZIMUTH]
        cat.is_close_file = d[ok.CLOSE_FILE]
        cat.seed_global = d[ok.SEED_GLOBAL]

        # Trigger a reset if it's needed. A Render
        # size change will make an image reset.
        cat.render.image

        if self.render_type == PLAN and not self.plan_group:
            self.plan_group = Lay.group(cat.render.image, "Plan")

    def _do_group(self, o, k):
        """
        Make a Group layer for a Face Group.

        k: string
            layer name
        """
        cat = Hat.cat
        z = Lay.group(
                cat.render.image,
                Lay.name(self.model_group, k),
                parent=self.model_group
        )

        # Register the Group layer for the Face Preset options.
        cat.register_layer((self.render_type, self.model_name, k), z)

        self.undo[o.step] = z, self._undo_group

    def _do_group_border(self, o):
        """
        Make a group layer for placing the Cell Face Border layers.

        o: One
            Has variables.
        """
        self._do_group(o, nk.BORDER)

    def _do_group_caption(self, o):
        """
        Make a group layer for placing the Cell Face Caption layers.

        o: One
            Has variables.
        """
        self._do_group(o, nk.CAPTION)

    def _do_group_fringe(self, o):
        """
        Make a group layer for placing the Cell Face Fringe layers.

        o: One
            Has variables.
        """
        self._do_group(o, nk.FRINGE)

    def _do_group_place(self, o):
        """
        Make a group layer for placing the Cell Face Place layers.

        o: One
            Has variables.
        """
        self._do_group(o, nk.IMAGE)

    def _do_group_plaque(self, o):
        """
        Make a group layer for placing the Cell Face Plaque layers.

        o: One
            Has variables.
        """
        self._do_group(o, nk.PLAQUE)

    def _do_mask(self, o):
        """
        Process Mask options.

        o: One
            Has variables.
        """
        cat = Hat.cat
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.IMAGE_MASK]:
                go = False
            else:
                o.image_layer = cat.get_layer(
                    (
                        self.render_type,
                        self.model_name,
                        nk.IMAGE
                    )
                )
        if go:
            d = Base.copy_sel_dict(cat.mask_sel)
            e = deepcopy(self.image_index)
            z = ASSIGN_MASK[o.model_type](o)
            self.undo[o.step] = (z, d, e), self._undo_mask

    def _do_place(self, o):
        """
        Process Place options.

        o: One
            Has variables.
        """
        cat = Hat.cat
        go = True
        is_plan = False

        if self.render_type == PLAN:
            is_plan = True
            if not self.plan_flags[ak.IMAGE]:
                go = False
        if go:
            d = Base.copy_sel_dict(cat.image_sel)
            e = deepcopy(self.image_index)
            image_layer = cat.get_layer(
                (self.render_type, o.model_name, nk.IMAGE)
            )

            if isinstance(image_layer, list):
                image_layer = image_layer[:]

            z = ASSIGN_PLACE[o.model_type](o, is_plan)

            if is_plan and z:
                z.name = nk.IMAGE
                z.opacity = 66.
            self.undo[o.step] = (z, d, image_layer, e), self._undo_place

    def _do_margin(self, o):
        """
        With Cell Margin options update cell pocket and shape.

        o: One
            Has variable, 'step'.
        """
        a = self.model.clone()

        self.model.calc_pocket(o)
        self.undo[o.step] = (a,), self._undo_model

    def _do_property(self, o, model, model_type, plan_key):
        """
        Do the Property option for a Model.

        model: Model instance
            with a Property option

        model_type: string
            for Model processing
            Different Model types, in some cases, have differing functions.

        plan_key: string
            for the plan option group
        """
        cat = Hat.cat

        # Property Preset dict, 'o.d'
        d = o.d

        a = self.model.clone() if self.model else None
        n = Hat.dog.group_id.get_name(o.step[2])
        group = self.model_group
        z = self.model_group = Lay.group(
            cat.render.image,
            n,
            offset=Hat.dog.plan.get_offset()
        )
        self.model = model
        q = (
            z,
            a,
            self.model_type,
            self.model_name,
            group,
            deepcopy(self.plan_flags)
        )
        self.model_type = model_type
        self.model_name = n
        self.plan_flags = d[plan_key]
        self.undo[o.step] = q, self._undo_property

    def _do_rectangle(self, o):
        """
        Do a Cell Rectangle.

        o: One
            Has variables.
        """
        a = self.model.clone()

        self.model.update_cell_rect(o)

        # The undo tuple needs the None to synchronize
        # with the Plan module's '_do_rectangle_plan' function.
        self.undo[o.step] = (None, a), self._undo_rectangle

    def _do_stack_property(self, o):
        """
        Create a Stack Model layer group for the render.

        o: One
            Has variables.
        """
        self._do_property(o, Stack(o), md.STACK, ok.STACK_PLAN)

    def _do_table_property(self, o):
        """
        Create a Table Model layer group for the View op.

        o: One
            Has variables.
        """
        self._do_property(o, Table(o), md.TABLE, ok.TABLE_PLAN)

    def _undo_canvas_plaque(self, q):
        """
        Undo a Canvas Plaque operation.

        q: tuple
            (
                plaque layer,
                plaque sel dict,
                previous plaque layer,
                image index dict
            )
        """
        cat = Hat.cat
        z, cat.plaque_sel, plaque_layer, self.image_index = q

        # Register the Canvas Plaque layer for the Canvas Fringe Mask option.
        cat.register_layer(
            (self.render_type, self.model_name, nk.CANVAS_PLAQUE),
            plaque_layer
        )

        # Delete the old layer.
        Lay.remove(z)

    def _undo_caption(self, q):
        """
        Undo a Caption operation.

        q: tuple
            (layer, stripe dict)
        """
        z, Hat.cat.caption_stripe_sel, caption_layer = q

        # Register the Caption layer for the
        # Background Stripe Blur Behind option.
        Hat.cat.register_layer(
            (self.render_type, self.model_name, nk.CELL_CAPTION),
            caption_layer
        )

        # Delete the old layer.
        Lay.remove(z)

    def _undo_cell_plaque(self, q):
        """
        Undo a Cell Plaque operation.

        q: tuple
            (
                layer,
                plaque selection dict,
                previous plaque layer,
                image index dict
            )
        """
        cat = Hat.cat
        z, cat.plaque_sel, plaque_layer, self.image_index = q

        Hat.cat.register_layer(
            (self.render_type, self.model_name, nk.CELL_PLAQUE),
            plaque_layer
        )
        Lay.remove(z)

    def _undo_fringe(self, q):
        """
        Undo a Cell Fringe operation.

        q: tuple
            undo variables
        """
        z, z1, is_mask, is_paint, self.image_index = q

        if is_mask:
            Lay.discard_mask(z1)
        if is_paint:
            Lay.remove(z)

    def _undo_group(self, z):
        """
        Undo a Face Group operation.

        z: layer group
            to remove
        """
        Lay.remove(z)

    def _undo_mask(self, q):
        """
        Undo a Mask process.

        q: tuple
            undo variables
        """
        def delete(_z):
            Lay.discard_mask(_z)

        cat = Hat.cat
        z, cat.mask_sel, self.image_index = q

        if isinstance(z, tuple):
            for i in z:
                delete(i)
        else:
            delete(z)

    def _undo_place(self, q):
        """
        Undo a Place operation.

        q: tuple
            (layer, image selection dict, image index dict)
        """
        cat = Hat.cat
        z, d, image_layer, self.image_index = q

        cat.register_layer(
            (self.render_type, self.model_name, nk.IMAGE),
            image_layer
        )
        Lay.remove_layers(z)
        cat.image_sel = d

    def _undo_model(self, q):
        """
        Undo an option that changed the Model.

        q: tuple
            (a Model instance,)
        """
        self.model = q[0]

    def _undo_property(self, q):
        """
        Undo a Property operation.

        q: tuple
            with undo variables
        """
        z, self.model, self.model_type, self.model_name, self.model_group, \
            self.plan_flags = q
        Lay.remove(z)

    def _undo_rectangle(self, q):
        """
        Undo a Rectangle step.

        q: tuple
            (layer, a Model instance)
        """
        z, self.model = q
        Lay.remove_layers(z)

    def get_preset_d(self, step):
        """
        Get the Preset dict for a step.
        The Box Model has a different step
        architecture than the other Models.

        step: tuple
            Is an OptionGroup key.

        Return: dict
            Preset dict
        """
        # Preset dict, 'd'
        if self.model_type != md.BOX:
            d = Step.get_dict_from_step(step)

        else:
            face_x = Step.get_face_index(step)

            # Is None when the step does not include a Face sub-step, 'face_x'.
            if face_x is not None:
                d = Form.get_face_chunk_from_step(
                    step,
                    Core.get_preset_type(step),
                    face_x
                )
            else:
                d = Step.get_dict_from_step(step)
        return d

    def undo_layer(self, q):
        """
        Undo a layer addition.

        q: tuple
            (layer(s), image index dict)
        """
        z, self.image_index = q

        if isinstance(z, list):
            for i in z:
                Lay.remove(i)
        else:
            Lay.remove(z)

    def undo_steps(self, q, steps):
        """
        Perform the undo functions of expired steps.

        q: list
            of changed steps

        steps: list
            of a previous View operation
        """
        d = Hat.cat.group_dict
        for step in q:
            if step in self.undo:
                a, p = self.undo[step]
                p(a)

            # A reset may have removed a step.
            if step in self.undo:
                self.undo.pop(step)

            # Update group status and Button sensitivity.
            if step not in steps:
                b = d[step]
                if self.render_type == PRODUCT:
                    b.changed = True
                    if b.preview_button:
                        b.preview_button.set_sensitive(1)
                elif self.render_type == PLAN:
                    b.unseen = True
                    if b.plan_button:
                        b.plan_button.set_sensitive(1)
