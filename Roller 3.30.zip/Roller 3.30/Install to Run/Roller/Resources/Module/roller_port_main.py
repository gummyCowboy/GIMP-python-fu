#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as fo, Node as fd, Widget as fw
from roller_constant_key import (
    BackdropStyle as by,
    Button as bk,
    Effect as ek,
    Group as gk,
    Model as md,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_effect import ImageEffect
from roller_one import Hat
from roller_one_draw import Draw
from roller_one_tip import Tip
from roller_option import OptionStat
from roller_option_group import OptionGroup
from roller_option_preset import BEHIND_TYPE, PerCell, Preset
from roller_option_preset_core import Core
from roller_option_preset_dict import PresetDict, NonPresetDict
from roller_port import Port
from roller_port_main_dict import MainDict
from roller_widget_node_panel import NodePanel
from roller_widget_box import Cabinet
from roller_widget_button import OptionButton
from roller_widget_button_pair import ButtonPair
from roller_widget_button import Button
from roller_widget_label import Label
from roller_window_save import RWSave
import gtk


def get_model_list():
    """
    The ModelList has a fixed-value step.

    Return: ModelList
        Has a list of Model item names.
    """
    return Hat.cat.group_dict[sk.MODEL].d[ok.MODEL_LIST]


def get_parent_node(g):
    """
    Get the connected Node of a ModelList OptionGroup.

    g: ModelList
        with OptionGroup and Node

    Return: tuple
        Node
        step of Node
    """
    step = g.group.step[:-1]
    return Hat.cat.group_dict[step].node, step


def insert_node_item(node, group_key, step, x, group_id=None):
    """
    Insert a row into a Node. Create a VBox for the item's
    OptionGroup or use its existing OptionGroup's VBox.

    node: Node
        work-in-progress

    group_key: string
        name of option
        a branch name

    step: string
        OptionGroup key
        Use to determine if the OptionGroup already exists.

    x: int
        insertion index into a Node label list

    group_id: int
        a translation of a Model name

    Return: tuple
        gtk.VBox, boolean
        box from new group; Is true, if the VBox is new.
    """
    if group_id is None:
        group_id = group_key

    d = Hat.cat.group_dict
    k = step + (group_id,)

    if k in d:
        vbox = d[k].vbox
        is_new = False

    else:
        vbox = gtk.VBox()
        is_new = True

    # Add a row.
    node.insert_row(x, group_key, vbox=vbox)

    if is_new:
        g = vbox.label_ = Label(
            text="{}:".format(group_key),
            padding=(4, 4, 4, 4)
        )
        vbox.pack_start(g, expand=True)
    return vbox, is_new


def make_plan(g):
    """
    Create a Plan view.

    g: OptionButton
        Is responsible.
    """
    step = g.group.step

    Hat.dog.plan.prep(Core.get_render_steps(step=step))
    g.set_sensitive(0)
    Core.update_plan_buttons(step)
    if hasattr(g.group, 'preview_button'):
        if g.group.preview_button:
            g.group.preview_button.set_sensitive(1)


def on_del_model_list_item(g, group_key):
    """
    Delete a ModelList item.

    g: ModelList
        Has Model name/key items.

    group_key: string
        the name of the item
    """
    node = get_parent_node(g)[0]
    q = node.get_value()
    x = q.index(group_key)
    node.remove_item(x)


def on_move_model_list_item(g):
    """
    A ModelList has changed the order of its items.
    Respond by rearranging the corresponding items in the Node.

    g: ModelList
        Is responsible.
    """
    node = get_parent_node(g)[0]
    top_item = node.get_value()[0]
    q = [i[0] for i in g.get_value()]
    q = [top_item] + list(reversed(q))
    node.refresh_list(q)


def on_name_change(g):
    """
    Update the three dependencies of a Model name.

    g: Entry
        Has new name.
    """
    if not PortMain.creating_model:
        node, step = get_parent_node(g)

        # The Model's VBox has a label with the Model Name.
        vbox = node.group.vbox
        node = get_parent_node(node)[0]
        _id = [i for i in reversed(step) if isinstance(i, int)][0]
        old_name = Hat.dog.group_id.get_name(_id)
        n = new_name = g.get_value()

        # A Node label is a sub-key for a step tuple.
        # Therefore, the new name cannot match, besides
        # with itself, another in the Node item list.
        q = node.get_value()
        x = q.index(old_name)

        q.pop(x)

        model_list = get_model_list()
        x1 = 1

        while not new_name or new_name in q:
            new_name = n + " #" + str(x1)
            x1 += 1

        # Rename the OptionGroup's VBox Label.
        vbox.label_.set_label_value(new_name + ":")
        Hat.dog.group_id.change_name(_id, new_name)

        # Rename the Node item.
        node.rename_item(x, new_name)

        # Rename the ModelList item.
        names = [i[0] for i in model_list.get_value()]
        model_list.rename_item(names.index(old_name), new_name)


class PortMain(Port):
    """Is for the main Window."""
    TITLE = "Roller 3.30"

    # Use to filter out the name change
    # response to the creation of a new Model.
    creating_model = False

    def __init__(self, d):
        """
        Draw Widgets.

        d: dict
            Has init variables.
        """
        d[wk.WINDOW_TITLE] = PortMain.TITLE
        d[wk.SAVE_WINDOW] = RWSave

        # Is a dict for adding an OptionGroup, 'self.d'.
        # Is passed to OptionGroup during its initialization.
        # The dict's key: values pairs stay the same for every OptionGroup.
        self.d = {
            wk.CREATE_LIST_ITEM: self.on_create_model,
            wk.DELETE_LIST_ITEM: on_del_model_list_item,
            wk.IS_DEFAULT: True,
            wk.MOVE_LIST_ITEM: on_move_model_list_item,
            wk.ON_KEY_PRESS: self.on_key_press,
            wk.ON_PREVIEW_BUTTON: Core.make_preview,
            wk.ON_WIDGET_CHANGE: self.on_widget_change,
            wk.PORT: self,
            wk.SAVE_WINDOW: RWSave
        }

        self._main_d = MainDict()
        self.node_panel = NodePanel(self.d, self._main_d)

        # Are functions responding to change.
        self._on_user_change = {
            bk.PLAN: make_plan,
            bk.RANDOM: Port.randomize_widgets
        }
        self._on_any_change = {
            gk.BACKDROP_STYLE: self.on_backdrop_style_change,
            gk.IMAGE_EFFECT: self.on_image_effect_change,
            ok.BOX_NAME: on_name_change,
            ok.CELL_NAME: on_name_change,
            ok.STACK_NAME: on_name_change,
            ok.TABLE_NAME: on_name_change
        }

        Port.__init__(self, d)
        self._load_steps()

    def _load_steps(self):
        """Load the steps from the previous session."""
        # Use the Steps SuperPreset.
        g = Hat.cat.group_dict[sk.STEPS_PRESET].d[wk.PRESET]
        self._last_session = g.load(
            fw.LAST_USED,
            Core.collect_preset(g.group.group_key)[0]
        )

    def _update_blur_behind_group(self, step, group_key):
        """
        Remove the old and make a new Blur Behind item branch.
        """
        step1 = step
        step = step + (gk.BLUR_BEHIND,)
        d = Hat.cat.group_dict
        if step in d:
            node = d[step].d[gk.BLUR_BEHIND]
            q = node.get_value()

            # Remove the old item.
            if len(q) > node.original_length:
                node.remove_item(2)

            # Add a new item.
            if group_key in fo.BLUR_BEHIND_EFFECT:
                k = step + (group_key,)
                vbox, is_new = insert_node_item(node, group_key, k, 2)
                key = group_key + fd.BLUR_BEHIND
                self._main_d.group_def[key] = BEHIND_TYPE
                if is_new:
                    self.node_panel.draw_options(
                        vbox,
                        key,
                        d[step1].node_key,
                        step
                    )

    def accept(self, *_):
        """
        Begin a Render.

        Return: true
            The key-press is handled.
        """
        self.roller_window.win.iconify()
        return self.accept_port(Core.get_render_steps(), self._last_session)

    def cancel(self, *_):
        """
        Close the Window.

        Return: true
            The key-press is handled.
        """
        # ImageGradient may have produced a gradient.
        Hat.cat.image_gradient_used = None

        return self.cancel_port()

    def draw_navigation(self, g):
        """
        Draw UI navigation components.

        g: GTK container
            to receive a group of Widgets
        """
        a = self.color

        # Init.
        self.node_panel.draw_options(g, gk.STEPS, None, ())

        self.color = a
        for i in range(len(self.node_panel.cabinet)):
            self.reduce_color()

    def draw_port(self, g):
        """
        Draw the Port's Widgets. Is part of the Port template.

        g: VBox
            to receive Port
        """
        self.d[wk.WIN] = self.roller_window
        self.draw_simple_dialog_port(
            g,
            (self.draw_navigation, self.draw_process),
            ("Steps", "")
        )

    def draw_process(self, g):
        """
        Draw a Widget group with Cancel and Accept options.

        g: GTK container
            to receive group
        """
        def on_action(g_):
            self.cancel(g_) if g_.key == bk.CANCEL else self.accept(g_)

        g1 = ButtonPair(
            **{
                wk.ON_WIDGET_CHANGE: on_action,
                wk.PADDING: (0, 0, fw.MARGIN, fw.MARGIN),
                wk.TEXT: (bk.CANCEL, bk.RENDER),
                wk.WIN: self.roller_window
            }
        )

        self.keep(g1)
        g.add(g1)

    def on_backdrop_style_change(self, g):
        """
        Respond to a Backdrop Style OptionList change.

        g: Widget
            Is responsible.
            OptionList
        """
        Draw.load_count += 1
        d = Hat.cat.group_dict
        group_key = g.get_value()
        node = get_parent_node(g)[0]
        rows = len(node.get_value())

        # Remove the old.
        if rows == fd.WITH_BACKDROP_STYLE:
            node.remove_item(2)

        # Add the new.
        if group_key != by.BACKDROP_IMAGE:
            k = sk.BACKDROP + (group_key,)
            vbox = d[k].vbox if k in d else None

            node.append_group(group_key, vbox)

            x = node.get_sel_x()

            if x is not None:
                node.select_item(x)

            else:
                node.select_item(rows - 1)

            # If there was no VBox already in place,
            # then create a new OptionGroup.
            if not vbox:
                # Are OptionGroup initialization variables.
                self.d[wk.IS_DEFAULT] = True
                e = {
                    wk.COLOR: Cabinet.colors[len(k) - 1],
                    wk.CONTAINER: node.get_groupie(2),
                    wk.GROUP_KEY: group_key,
                    wk.GROUP_TYPE: Preset,
                    wk.HAS_PRESET: True,
                    wk.HAS_EFFECT_PAIR: True,
                    wk.KEYS: PresetDict.get_keys(group_key),
                    wk.STEP: k
                }

                e.update(self.d)
                OptionGroup.draw_group(**e)

        # Set the tooltip for the selected OptionList item.
        a = d[sk.BACKDROP_STYLE]

        if ok.BACKDROP_STYLE in a.d:
            g = a.d[ok.BACKDROP_STYLE]
            n = g.get_value()
            g.set_tooltip_text(
                Tip.OPTION_MAIN[n] if n in Tip.OPTION_MAIN else ""
            )
        Draw.load_count -= 1

    def on_create_model(self, g, group_key, _type):
        """
        Create a Model branch for a ModelList New action.

        g: Widget
            Is responsible.
            ModelList

        group_key: string
            name of new Model

        _type: string
            Model type
        """
        Draw.load_count += 1
        PortMain.creating_model = True
        node, step = get_parent_node(g)
        group_id = Hat.dog.group_id.make_id(group_key)
        group_def = self._main_d.group_def

        # step to Model, 'q'
        q = step + (group_id,)

        self.d[wk.IS_DEFAULT] = True
        vbox = insert_node_item(
            node,
            group_key,
            step,
            1,
            group_id=group_id
        )[0]

        # options for 'create_node'
        d = {wk.CONTAINER: vbox, wk.GROUP_KEY: group_key, wk.STEP: q}

        # Model definition, 'e'
        # key: Model key
        # value: (property group key, Model name option key, Model group key)
        e = {
            md.BOX: (gk.BOX_PROPERTY, ok.BOX_NAME, gk.BOX_MODEL),
            md.CUSTOM_CELL: (
                gk.CUSTOM_CELL_PROPERTY,
                ok.CELL_NAME,
                gk.CUSTOM_CELL_MODEL
            ),
            md.STACK: (gk.STACK_PROPERTY, ok.STACK_NAME, gk.STACK_MODEL),
            md.TABLE: (gk.TABLE_PROPERTY, ok.TABLE_NAME, gk.TABLE_MODEL)
        }

        d.update(self.d)

        if _type in e:
            prop_key, name_key, model_key = e[_type]
            group_def[group_id] = group_def[model_key]

            NonPresetDict.update_model_item_name(prop_key, name_key, group_key)
            self.node_panel.create_node(
                d,
                group_key,
                q,
                node_key=group_id
            )
            PortMain.creating_model = False
        Draw.load_count -= 1

    def on_image_effect_change(self, g):
        """
        Process an Image Effect change which
        requires some shuffling of Node items.

        g: Widget
            Is responsible.
            OptionList
        """
        Draw.load_count += 1
        group_key = g.get_value()
        node, step = get_parent_node(g)
        x = node.original_length

        # Remove the previous Image Effect.
        if group_key in ImageEffect.MAIN:
            sel_x = node.get_sel_x()

            while len(node.get_value()) > x:
                node.remove_item(x - 1)

            # Add a new Image Effect.
            keys = OptionStat.get_effect_keys(group_key)
            self.d[wk.IS_DEFAULT] = True

            for x1, key in enumerate(keys):
                vbox, is_new = insert_node_item(node, key, step, x + x1 - 1)
                if is_new:
                    k = step + (key,)

                    # Are option group initialization variables.
                    e = {
                        wk.COLOR: Cabinet.colors[len(k) - 1],
                        wk.CONTAINER: vbox,
                        wk.GROUP_KEY: key,
                        wk.GROUP_TYPE: Preset,
                        wk.KEYS: PresetDict.get_keys(key),
                        wk.STEP: k
                    }

                    if group_key == ek.NO_EFFECT:
                        e[wk.HAS_PREVIEW] = True

                    else:
                        e[wk.HAS_PRESET] = e[wk.HAS_EFFECT_PAIR] = True

                    e.update(self.d)
                    OptionGroup.draw_group(**e)

            self._update_blur_behind_group(step, group_key)

            if sel_x:
                node.select_item(sel_x)
                g.grab_focus()

            # Set a tooltip for the selected list item.
            a = Hat.cat.group_dict[step + (gk.IMAGE_EFFECT,)]
            if ok.IMAGE_EFFECT in a.d:
                g = a.d[ok.IMAGE_EFFECT]
                n = g.get_value()
                g.set_tooltip_text(
                    Tip.OPTION_MAIN[n] if n in Tip.OPTION_MAIN else ""
                )
        Draw.load_count -= 1

    def on_widget_change(self, g, *_):
        """
        A Widget changed. Respond to changes in the interface.

        g: Widget
            Is responsible.
        """
        # OptionGroup, 'a'
        a = g.group

        if g.key in self._on_any_change:
            self._on_any_change[g.key](g)

        else:
            if not (Draw.load_count or Draw.preset_load_count):
                if g.key in self._on_user_change:
                    self._on_user_change[g.key](g)

        # In order for change a process to be accepted, the change status
        # has to be user-instigated and not a product of a Preset load.
        if not (Draw.load_count or Draw.preset_load_count):
            if not isinstance(g, (Button, OptionButton)):
                a.unseen = a.changed = True
                if a.group_type == PerCell:
                    # Update the Per Cell group's form OptionGroup.
                    g1 = a.d[ok.PER_CELL]
                    b = g1.form_group
                    b.unseen = b.changed = True
            if g.key not in (bk.PLAN, bk.PREVIEW):
                Core.update_view_buttons(a.step)
