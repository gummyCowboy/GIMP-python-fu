#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk
from roller_widget import Widget
import gtk


class RadioGroup:
    """Use to manage a group of RadioButtons."""

    def __init__(self, q, k):
        """
        Receive the RadioButtons. The RadioButtons
        are assumed to part of the same group.

        q: iterable
            group of related RadioButtons

        k: string
            group key
        """
        self.buttons = q[:]
        self.key = k

    def get_value(self):
        """
        Find the active RadioButton. There's always one RadioButton
        that is active. Is part of the Widget template.

        Return: int
            index into group
            in 0 to n
        """
        for x, g in enumerate(self.buttons):
            if g.get_value():
                return x

    def set_value(self, x):
        """
        Set a RadioButton in the group as active. Only one RadioButton
        in a group can be active. Is part of the Widget template.

        x: integer
            index into group
        """
        # Repair.
        x = x if isinstance(x, int) else 0

        self.buttons[x].set_value(1)

    def hide(self):
        """Hide the RadioButtons in this group."""
        for i in self.buttons:
            i.hide()

    def show(self):
        """Show the RadioButtons in this group."""
        for i in self.buttons:
            i.show()


class RadioButton(Widget):
    """Is a GTK RadioButton attached to an GTK Alignment."""

    def __init__(self, **d):
        """
        Create a GTK RadioButton. RadioButtons are grouped together
        and identify their group by referencing their first member.

        d: dict
            Has keyword arguments for the Widget.
        """
        g = gtk.RadioButton(
            d[wk.RADIO_GROUP],
            d[wk.LABELS][d[wk.LABEL_X]]
        )

        Widget.__init__(self, g, **d)
        self.add(g)

        # Do connection last.
        g.connect('toggled', self.callback)

    def get_value(self):
        """
        Get the value of the RadioButton. Is part of the Widget template.

        Return: int
            0 or 1
        """
        return self.widget.get_active()

    def set_value(self, value):
        """
        Set the value of the RadioButton. Is part of the Widget template.

        value: int
            0 or 1
        """
        self.widget.set_active(value)


class Radio(Widget):
    """Is a super class for the Radio-type classes."""
    # Need for OptionGroup change subscription.
    change_signal = 'toggled'

    def __init__(self, **d):
        """
        Create the Widgets.

        d: dict
            Has Init values.
        """
        # Is set by the Table container.
        self.label = None

        radio_button = RadioButton(**dict(d, label_x=0, radio_group=None))

        Widget.__init__(self, radio_button.widget, **d)

        # GTK container for the radio buttons
        self.box = d[wk.BOX]

        if wk.TOOLTIP in d:
            d.pop(wk.TOOLTIP)

        q = self.buttons = [
            radio_button,
            RadioButton(**dict(d, label_x=1, radio_group=radio_button.widget))
        ]

        for i in q:
            self.box.pack_start(i, expand=True)

        self.add(self.box)

        self.radio_group = RadioGroup(q, self.key)
        if wk.TIPS in d:
            for x, i in enumerate(q):
                i.widget.set_tooltip_text(d[wk.TIPS][x])

    def get_value(self):
        """
        Get the value of the RadioGroup. Is part of the Widget template.

        Return: int
            index to the active RadioButton
        """
        return self.radio_group.get_value()

    def hide(self):
        """Hide the Buttons and their Label."""
        if self.box and self.label:
            if self.box.get_visible():
                self.box.hide()
                self.label.box.hide()

    def set_value(self, value):
        """
        Set the value in the RadioGroup. Is part of the Widget template.

        value: int
            index to a RadioButton
        """
        self.radio_group.set_value(value)

    def show(self):
        """Hide the Buttons and their Label."""
        if self.box and self.label:
            if not self.box.get_visible():
                self.box.show()
                self.label.box.show()


class RadioColumn(Radio):
    """Create a VBox with RadioButtons."""

    def __init__(self, **d):
        """
        Create the Widgets.

        d: dict
            Has Init values.
        """
        d[wk.BOX] = gtk.VBox()
        Radio.__init__(self, **d)


class RadioRow(Radio):
    """Create a HBox with RadioButtons."""

    def __init__(self, **d):
        """
        Create the Widgets.

        d: dict
            Has Init values.
        """
        d[wk.BOX] = gtk.HBox()
        Radio.__init__(self, **d)
