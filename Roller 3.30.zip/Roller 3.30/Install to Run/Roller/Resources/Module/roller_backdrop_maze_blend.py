#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_extract import Render
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

cs = Fu.ColorSelect
ed = Fu.Edge
em = Fu.Emboss
pdb = fu.pdb
ELEVATION_20 = 20.


class MazeBlend:
    """Use a maze graph to produce a softly blended backdrop."""

    @staticmethod
    def do(o):
        """
        Do the Maze Blend Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            Has Maze Blend.
        """
        cat = Hat.cat
        j = cat.render.image

        # Maze Blend Preset dict, 'o.d'
        d = o.d

        # Backdrop Image layer, 'o.z'
        if Lay.has_pixel(o.z) and d[ok.OPACITY]:
            s = Render.size()

            # Group key, 'o.k'
            group = Lay.group(j, o.k + " WIP")
            z = Lay.add(j, o.k + " Base", parent=group)

            # Preserve.
            q = pdb.gimp_context_get_foreground()
            q1 = pdb.gimp_context_get_background()

            Lay.color_fill(z, (127, 127, 127))

            z = Lay.clone(o.z, n="Pixelize")

            pdb.gimp_image_reorder_item(j, z, group, 0)
            pdb.plug_in_pixelize2(j, z, s[0], s[1])

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            z1 = Lay.clone(z, n="Multiply")
            z1.mode = fu.LAYER_MODE_MULTIPLY
            z1.opacity = 25.
            w = max(1, s[0] // d[ok.COLUMN_MAZE])
            h = max(1, s[1] // d[ok.ROW_MAZE])
            w1 = int((w + h) / 1.5)

            pdb.gimp_selection_none(j)
            pdb.gimp_context_set_background((0, 0, 0))
            pdb.gimp_context_set_foreground((255, 255, 255))
            pdb.plug_in_maze(j, z1, w, h, 1, 0, d[ok.RANDOM_SEED], 0, 0)
            Sel.color(z1, (255, 255, 255))

            sel = cat.save_short_term_sel()
            z2 = Lay.clone(z1, n="Overlay")
            z2.mode = fu.LAYER_MODE_OVERLAY

            pdb.plug_in_edge(j, z1, ed.AMOUNT_1, ed.NO_WRAP, ed.SOBEL)

            for _ in range(4):
                Lay.dilate(z1)

            pdb.gimp_drawable_invert(z2, 0)
            Lay.color_fill(z2, (127, 127, 127))
            Sel.load(j, sel)
            Sel.invert_clear(z2)
            pdb.plug_in_emboss(
                j,
                z2,
                cat.azimuth,
                ELEVATION_20,
                em.DEPTH_3,
                em.EMBOSS
            )
            pdb.gimp_drawable_invert(z1, 0)
            Lay.blur(z1, w1)
            Sel.load(j, sel)
            Sel.invert(j)
            Sel.invert_clear(z1)

            z = Lay.merge_group(group)

            # Restore.
            pdb.gimp_context_set_foreground(q)
            pdb.gimp_context_set_background(q1)

            return RenderHub.finish_style(o, d, z, has_mode=True)
