#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_render_gradient_light import GradientLight
import gimpfu as fu

pdb = fu.pdb
em = Fu.Emboss
ta = Fu.ThresholdAlpha
FOUR_COORDINATES = 4


def do_job(effect_layer, image_layer, o, sel):
    """
    Call from BorderLine. Draw a Stretch Tray frame.

    effect_layer: layer
        Provides parent.

    image_layer: layer
        with image material

    o: One
        with options

    sel: Selection
        for filler material

    Return: layer
        with filler material
    """
    def wind(_z, _dir):
        pdb.plug_in_wind(
            j, _z,
            Fu.Wind.THRESHOLD_0,
            _dir,
            Fu.Wind.STRENGTH_30,
            Fu.Wind.WIND,
            Fu.Wind.LEADING_EDGE,
        )
        pdb.plug_in_threshold_alpha(j, _z, ta.THRESHOLD_ALL)

    cat = Hat.cat
    j = cat.render.image
    parent = effect_layer.parent

    # Duplicate the image layer.
    z = Lay.clone(image_layer)

    group = Lay.group(j, o.k, parent=parent, z=z)

    # The Stack Model has a group of images
    # that act as one layer for the effect.
    if pdb.gimp_item_is_group(z):
        z = Lay.merge_group(z)

    z1 = Lay.clone_opaque(z)

    Lay.apply_mask(z1)

    z2 = Lay.clone(z1, n="Bottom")
    z3 = Lay.clone(z1, n="Left")
    z4 = Lay.clone(z1, n="Right")

    for q in (
        (z1, Fu.Wind.FROM_TOP),
        (z2, Fu.Wind.FROM_BOTTOM),
        (z3, Fu.Wind.FROM_LEFT),
        (z4, Fu.Wind.FROM_RIGHT)
    ):
        wind(*q)

    z = Lay.merge_group(group)

    Sel.load(j, sel)
    Sel.isolate(z, sel)
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,
        (.0, .25, 1., .75)
    )
    Gegl.saturation(z, 10.)

    z1 = Lay.clone(z, n="Hard Light")
    z1.mode = fu.LAYER_MODE_HARDLIGHT
    z1.opacity = 80.

    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        FOUR_COORDINATES,
        (.0, .45, 1., .54)
    )
    pdb.plug_in_emboss(
        j, z,
        cat.azimuth,
        cat.elevation,
        em.DEPTH_3,
        em.EMBOSS
    )

    z = Lay.merge(z1)
    z = GradientLight.apply_light(z, ok.OTHER_FRAME)

    pdb.gimp_image_reorder_item(j, z, parent, 0)
    return z


class StretchTray:
    """
    Make a frame by stretching an image horizontally and vertically.
    """

    @staticmethod
    def do(o):
        """
        Do the Image Effect. Is an Image Effect template function.

        o: One
            Has variables.

        Return: layer, list, or None
            with frame
        """
        return BorderLine.do(o, filler=do_job)
