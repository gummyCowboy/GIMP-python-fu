#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Group as og
from roller_one import Hat


def update_change_flag(steps):
    """
    The change flag is used to indicate an option group's
    render status. If it's changed, then the step needs
    to be done.

    The change flag also has a chain-inheritance. If a step
    is changed, the succeeding steps are also changed.

    steps: list
        of steps (Node Label,)
        Paths are keys to option group Widgets held in 'group_dict'.

    Return: list
        of changed steps
    """
    e = Hat.cat.group_dict
    q = []
    is_change = False

    # Every step after the first changed
    # group is part of a preview.
    # Reset the change status as it is
    # assumed that the render will succeed.
    # Remove the group NO_CHANGE_GROUP
    # as its step won't change a View operation.
    for i in steps:
        a = e[i]
        if not is_change and a.changed:
            is_change = True
        if is_change:
            a.changed = False
            if a.group_key != og.NO_CHANGE_GROUP:
                q += [i]
    return q


class View:
    """
    Perform a View. Keep a previous list of
    steps for optimizing a View undo process.
    """

    def __init__(self):
        """Get ready for View operations."""
        self._previous_steps = []

    def _update_previous_steps(self, steps):
        """
        Update the previous steps for another View op. The previous
        steps are screened. These steps go up to the undo stage.

        steps: list
            for the next View op
        """
        # Set the change status.
        e = Hat.cat.group_dict
        q = []
        is_change = False

        for i in self._previous_steps[::-1]:
            a = e[i]
            if not is_change and a.changed:
                is_change = True
            if is_change:
                if a.group_key != og.NO_CHANGE_GROUP:
                    q += [i]
            else:
                if i not in steps:
                    if a.group_key != og.NO_CHANGE_GROUP:
                        q += [i]
        self._previous_steps = q[::-1]

    def do(self, q, is_preview=False):
        """
        Call to do a View op.

        q: list
            View steps

        is_preview: bool
            Is true when the caller is performing a Preview.
        """
        self._update_previous_steps(q)

        q1 = q[:]

        # steps, 'q'
        q = update_change_flag(q)

        # undo steps, 'q2'
        q2 = self._previous_steps[:]

        # Reverse the order of the previous steps list. The
        # list is the reverse order of a View op step list.
        self._previous_steps = q1[::-1]

        # Process the steps.
        Hat.dog.product.do(q, q2, is_preview)
