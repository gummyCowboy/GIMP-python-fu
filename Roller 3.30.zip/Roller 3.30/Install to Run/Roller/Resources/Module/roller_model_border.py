#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Border as bo, Gradient as fg, Shape as sh
from roller_constant_fu import Fu
from roller_constant_key import Layer as nk, Option as ok
from roller_model_image import Image
from roller_one import Hat
from roller_one_extract import dispatch, Render, Shape, Step
from roller_one_fu import Lay, Mage, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
BORDER = "Border"
ELLIPSE = (
    sh.ELLIPSE_HORIZONTAL,
    sh.ELLIPSE_VERTICAL,
    sh.CIRCLE_HORIZONTAL,
    sh.CIRCLE_VERTICAL,
    sh.ELLIPSE
)


def add_border_layer(j, o, group):
    """
    Add a Border layer to a layer group.

    j: GIMP image
        Is render.

    o: One
        'layer_name': string

    group: layer
        parent of layer

    Return: layer
        for Border material
    """
    return Lay.add(j, n=o.layer_name, parent=group)


def do_average_color(z, o):
    """
    Fill a selection with the Average Color of the background.

    z: layer
        to receive material

    o: One
        not used

    Return: layer
        with Border material
    """
    j = z.image
    sel = pdb.gimp_selection_save(j)
    z1 = Lay.clone_background(z)

    Lay.color_fill(z, RenderHub.get_average_color(z1))
    Lay.remove(z1)
    Sel.isolate(z, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_backdrop(z, o):
    """
    Fill the selection with a copy of the background.

    z: layer
        to receive material

    o: One
        not used

    Return: layer
        with Border material
    """
    z1 = Lay.clone_background(z)

    Lay.remove(z)
    Sel.invert_clear(z1, keep_sel=True)
    return z1


def do_behind(z, d):
    """
    Blur behind Border material and cast a shadow.

    z: layer
        with material

    d: dict
        Border Preset

    Return: layer
        with material
    """
    if d[ok.BLUR_BEHIND]:
        z1 = RenderHub.blur_behind(z, d, has_mode=True)

    else:
        z1 = RenderHub.do_mode(z, d)

    if z1:
        z = RenderHub.bump(z1, d[ok.BUMP])
    return cast_shadow(z, d)


def do_color(z, o):
    """
    Fill with the selection with a color.

    z: layer
        to receive material

    o: One
        Has variables.

    Return: layer
        with Border material
    """
    Sel.fill(z, get_color(o))
    return z


def do_face_per_cell(j, o):
    """
    Draw a Border for a Face.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has Border material.
    """
    z = group = None
    row, column = o.model.division

    for r in range(row):
        for c in range(column):
            if Shape.is_double_cell(o.model.double_type, r, c):
                q = o.model.get_face(o.face_x, r, c)

                # Border Preset dict, 'e'
                e = o.e = o.is_per_cell[r][c]

                w = e[ok.BORDER_WIDTH]
                if w and e[ok.OPACITY] and e[ok.BORDER_TYPE] != "None":
                    Sel.shape(j, q)

                    if Sel.is_sel(j):
                        sel = pdb.gimp_selection_save(j)
                        pdb.gimp_selection_shrink(j, w)

                    else:
                        sel = None

                    sel1 = pdb.gimp_selection_save(j) if Sel.is_sel(j) \
                        else None

                    # Make a Border selection by subtracting
                    # the inner selection from the outer.
                    if sel:
                        Sel.load(j, sel)
                        Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                    if not Sel.is_sel(j):
                        Sel.load(j, sel)

                    if not group:
                        group = make_group(j, o)

                    if Sel.is_sel(j):
                        z = process_selection(
                            add_border_layer(j, o, group),
                            o
                        )
                        if not o.is_plan:
                            z = do_behind(z, e)

                    if sel:
                        pdb.gimp_image_remove_channel(j, sel)
                    if sel1:
                        pdb.gimp_image_remove_channel(j, sel1)

    if group:
        z = Lay.merge_group(group)
    return z


def do_gradient(z, o):
    """
    Fill with the selection with a gradient.

    z: layer
        to receive material

    o: One
        'e': dict
            border dict

    Return: layer
        with Border material
    """
    def draw_gradient():
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(gradient_type),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            start_x, start_y,
            end_x, end_y
        )

    j = z.image

    # Border Preset dict, 'o.e'
    d = o.e

    sel = pdb.gimp_selection_save(j)
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    w, h = x1 - x, y1 - y
    gradient_type = d[ok.GRADIENT_TYPE]

    RenderHub.set_fill_context(fg.FILL_DICT)
    RenderHub.set_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        fu.GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(0)

    start_x, end_x, start_y, end_y =\
        RenderHub.get_gradient_points(
            d[ok.GRADIENT_ANGLE],
            x, y,
            w, h
        )

    Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
    draw_gradient()
    Sel.isolate(z, sel)
    Sel.invert_clear(z, keep_sel=True)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_image(z, o):
    """
    Fill with the selection with an image.

    z: layer
        to receive material

    o: One
        Has variables.

    Return: layer
        with border material
    """
    j = z.image

    # Border Preset dict, 'o.e'
    d = o.e

    j1 = Image.get_image(d[ok.IMAGE], o.image_index)

    if j1:
        sel = pdb.gimp_selection_save(j)
        x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
        w, h = x1 - x, y1 - y
        j2 = j1.j

        pdb.gimp_selection_none(j)
        Mage.copy_all(j2)
        Image.close_image(j1)

        j2 = pdb.gimp_edit_paste_as_new_image()

        Mage.shape(j2, w, h)

        z1 = Lay.paste(z)

        pdb.gimp_layer_set_offsets(z1, x, y)
        Sel.isolate(z1, sel)
        pdb.gimp_image_remove_channel(j, sel)
        z = Lay.merge(z1)
    return z


def do_pattern(z, o):
    """
    Fill with the selection with a pattern.

    z: layer
        to receive material

    o: One
        Has variables.

    Return: layer
        with Border material
    """
    j = z.image
    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    RenderHub.set_fill_context(fg.FILL_DICT)
    RenderHub.set_pattern(o.e)

    n = z.name
    x, y = pdb.gimp_selection_bounds(j)[1:3]
    z1 = Lay.add_above(z, "")

    pdb.gimp_drawable_edit_bucket_fill(z1, fu.FILL_PATTERN, x, y)
    Sel.isolate(z1, sel)
    pdb.gimp_image_remove_channel(j, sel)
    Lay.remove(z)

    z1.name = n
    return z1


def do_plasma(z, o):
    """
    Fill with the selection with plasma.

    z: layer
        to receive material

    o: One
        Has variables.

    Return: layer
        with Border material
    """
    j = z.image
    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, o.e[ok.RANDOM_SEED], 3)
    Sel.isolate(z, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def cast_shadow(z, d):
    """
    Merge a shadow layer with a Border layer if needed.

    z: layer
        with material

    d: dict
        Border Preset

    Return: layer
        with Border material
    """
    if Shadow.get_type(d[ok.TRI_SHADOW]):
        n = z.name
        z = Shadow.do_shadows(d[ok.TRI_SHADOW], z)
        z.name = n
    return z


def do_common_ellipse_grid(j, o):
    """
    Draw a Border for a square cell shape
    without merge-cell or Per Cell.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has Border material.
    """
    # Border Preset dict, 'o.d'
    d = o.d

    row, column = o.model.division
    w = d[ok.BORDER_WIDTH]
    w1 = w // 2
    z = grid_sel = None

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(o.model, r, c):
                Sel.shape(j, o.model.get_shape(r, c))
                Sel.grow(j, w1, 1)

                sel = pdb.gimp_selection_save(j)

                pdb.gimp_selection_shrink(j, w)

                sel1 = pdb.gimp_selection_save(j) if Sel.is_sel(j) else \
                    None

                # Make a Border selection by subtracting
                # the inner selection from the outer.
                Sel.load(j, sel)

                if sel1:
                    Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                if grid_sel:
                    Sel.load(j, grid_sel, option=fu.CHANNEL_OP_ADD)
                    pdb.gimp_image_remove_channel(j, grid_sel)

                grid_sel = pdb.gimp_selection_save(j)

                if sel:
                    pdb.gimp_image_remove_channel(j, sel)
                if sel1:
                    pdb.gimp_image_remove_channel(j, sel1)
    if grid_sel:
        Sel.load(j, grid_sel)

        z = do_ellipse_sel(j, o)
        pdb.gimp_image_remove_channel(j, grid_sel)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_common_polygon_grid(j, o, face_x=None):
    """
    Do a common Border for a polygon, not rectangular, cell shape.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    face_x: int
        Use with model's with multiple faces (i.e. Box).

    Return: layer or None
        Has Border material.
    """
    # Border Preset dict, 'o.e'
    d = o.e

    row, column = o.model.division
    z = None

    # lines
    q = []

    w = d[ok.BORDER_WIDTH]
    w1 = max(1., w / 2.)

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(o.model, r, c):
                if face_x is not None:
                    Sel.polygon(j, o.model.get_face(face_x, r, c))

                else:
                    Sel.polygon(j, o.model.get_shape(r, c))

                sel = pdb.gimp_selection_save(j)

                pdb.gimp_selection_shrink(j, w1)
                if pdb.gimp_item_is_valid(sel):
                    sel1 = pdb.gimp_selection_save(j)

                    if pdb.gimp_item_is_valid(sel1):
                        Sel.load(j, sel)
                        Sel.grow(j, w1, 0)
                        Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)
                        pdb.gimp_image_remove_channel(j, sel1)
                        q += [pdb.gimp_selection_save(j)]
                    pdb.gimp_image_remove_channel(j, sel)

    if q:
        pdb.gimp_selection_none(j)

        z = add_border_layer(j, o, o.parent)

        for i in q:
            Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
            pdb.gimp_image_remove_channel(j, i)
        z = process_selection(z, o)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_common_rect_grid(j, o):
    """
    Do a common Border for a rectangular cell shape.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has Border material.
    """
    # Border Preset dict, 'o.d'
    d = o.d

    row, column = o.model.division
    rect = o.model.get_merge_cell_rect(0, 0)
    left, top = rect.x, rect.y
    rect = o.model.get_merge_cell_rect(row - 1, column - 1)
    right, bottom = rect.x + rect.w, rect.y + rect.h
    x = left
    h1 = d[ok.BORDER_WIDTH]
    h2 = h1 - h1 // 2
    w1 = right - left + h1

    for r in range(row):
        rect = o.model.get_merge_cell_rect(r, 0)
        Sel.rect(j, x - h2, rect.y - h2, w1, h1)

    Sel.rect(j, x - h2, rect.y + rect.h - h2, w1, h1)

    w1, w2 = h1, h2
    h1 = bottom - top + w1
    y = top

    for c in range(column):
        rect = o.model.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x - w2, y - w2, w1, h1)

    Sel.rect(j, rect.x + rect.w - w2, y - w2, w1, h1)

    z = process_selection(add_border_layer(j, o, o.parent), o)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_common_square_grid(j, o):
    """
    Do a common Border for a square cell shape.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has Border material.
    """
    row, column = o.model.division

    # Border Preset dict, 'o.d'
    d = o.d

    w = d[ok.BORDER_WIDTH]
    rect = o.model.get_merge_cell_rect(0, 0)
    w1 = rect.w * column + w
    h1 = rect.h * row + w
    w2 = w - w // 2

    for r in range(row):
        rect = o.model.get_merge_cell_rect(r, 0)
        Sel.rect(j, rect.x - w2, rect.y - w2, w1, w)

    Sel.rect(j, rect.x - w2, rect.y + rect.h - w2, w1, w)

    for c in range(column):
        rect = o.model.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x - w2, rect.y - w2, w, h1)

    Sel.rect(j, rect.x + rect.w - w2, rect.y - w2, w, h1)

    z = process_selection(add_border_layer(j, o, o.parent), o)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_ellipse_sel(j, o):
    """
    Increase the opacity of an ellipse.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer
        Has Border material.
    """
    d = o.d
    group = make_group(j, o)
    f = d[ok.OPACITY]
    d[ok.OPACITY] = 100.
    z = add_border_layer(j, o, group)

    Sel.fill(z, get_color(o))

    d[ok.OPACITY] = f

    for i in range(3):
        Lay.clone(z)

    z = Lay.merge_group(group)

    Sel.item(z)
    return process_selection(z, o)


def do_rect_custom_cell(j, o):
    """
    Draw a rectangle Border for a Custom Cell Model.

    j: GIMP image
        Is render.

    o: One
        Has variables.
    """
    a = o.model.rect
    x, y = a.position
    w, h = a.size

    # Border Preset dict, 'o.d'
    d = o.d

    w1 = d[ok.BORDER_WIDTH]
    w2 = w1 + w1
    Sel.rect(j, x, y, w, h)
    Sel.rect(
        j,
        x + w1,
        y + w1,
        max(1, w - w2),
        max(1, h - w2),
        option=fu.CHANNEL_OP_SUBTRACT
    )
    z = process_selection(add_border_layer(j, o, o.group), o)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_rect_grid(j, o):
    """
    Draw Border material for a rectangle cell shape without merge-cell.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has Border material.
    """
    # Border Preset dict, 'o.d'
    d = o.d

    row, column = o.model.division
    rect = o.model.get_merge_cell_rect(0, 0)
    left, top = rect.x, rect.y
    rect = o.model.get_merge_cell_rect(row - 1, column - 1)
    right, bottom = rect.x + rect.w, rect.y + rect.h
    w1 = right - left
    x = left
    h1 = d[ok.BORDER_WIDTH]

    for r in range(row):
        rect = o.model.get_merge_cell_rect(r, 0)
        Sel.rect(j, x, rect.y, w1, h1)
        Sel.rect(j, x, max(rect.y + rect.h - h1, rect.y), w1, h1)

    w1 = h1
    h1 = bottom - top
    y = top

    for c in range(column):
        rect = o.model.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x, y, w1, h1)
        Sel.rect(j, max(rect.x + rect.w - w1, rect.x), y, w1, h1)
    z = process_selection(add_border_layer(j, o, o.parent), o)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_rect_per_cell(j, o):
    """
    Draw Border material for a rectangle cell shape
    with merged cells and possibly Per Cell.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has Border material.
    """
    # Border Preset dict, 'o.d'
    d = o.d

    row, column = o.model.division
    z = group = None
    is_per_cell = o.is_per_cell

    for r in range(row):
        for c in range(column):
            go = True
            w = 0

            if o.is_merge_cell:
                if o.model.d[ok.PER_CELL][r][c] == (-1, -1):
                    go = False
            if go:
                if is_per_cell:
                    e = o.e = d[ok.PER_CELL][r][c]
                    w = e[ok.BORDER_WIDTH]
                    go = e[ok.BORDER_WIDTH] and e[ok.OPACITY] and \
                        e[ok.BORDER_TYPE] != "None"
                else:
                    e = d
                    w = d[ok.BORDER_WIDTH]
            if go and w:
                w1 = w + w
                rect = o.model.get_merge_cell_rect(r, c)

                Sel.rect(j, rect.x, rect.y, rect.w, rect.h)
                Sel.rect(
                    j,
                    rect.x + w, rect.y + w,
                    max(1, rect.w - w1), max(1, rect.h - w1),
                    option=fu.CHANNEL_OP_SUBTRACT
                )
                if Sel.is_sel(j):
                    if is_per_cell:
                        if not group:
                            group = make_group(j, o)
                        z = process_selection(
                            add_border_layer(j, o, group),
                            o
                        )
                        if not o.is_plan:
                            z = do_behind(z, e)

    if not is_per_cell:
        z = process_selection(add_border_layer(j, o, o.parent), o)
        z = do_behind(z, d)
    if group:
        z = Lay.merge_group(group)
    return z


def do_shape_custom_cell(j, o, n):
    """
    Draw a non-rectangle shaped Custom Cell Border.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    n: string
        shape descriptor

    Return: layer or None
        with Border material
    """
    z = None

    # Border Preset dict, 'o.d'
    d = o.d

    Sel.shape(j, dispatch[n](o.model.rect))

    if Sel.is_sel(j):
        sel = pdb.gimp_selection_save(j)

        pdb.gimp_selection_shrink(j, d[ok.BORDER_WIDTH])

        if Sel.is_sel(j):
            sel1 = pdb.gimp_selection_save(j)

        else:
            sel1 = None

        Sel.load(j, sel)
        Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

        if not Sel.is_sel(j):
            Sel.load(j, sel)

        if n in ELLIPSE:
            z = do_ellipse_sel(j, o)
        else:
            z = process_selection(add_border_layer(j, o, o.group), o)

        if not o.is_plan:
            z = do_behind(z, d)

        pdb.gimp_image_remove_channel(j, sel)
        if sel1:
            pdb.gimp_image_remove_channel(j, sel1)
    return z


def do_shape_grid(j, o, n):
    """
    Draw Border material for a square cell
    shape without merged cells or Per Cell.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    n: string
        shape descriptor

    Return: layer or None
        Has border material.
    """
    # Border Preset dict, 'o.d'
    d = o.d

    row, column = o.model.division
    w = d[ok.BORDER_WIDTH]
    z = grid_sel = None

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(o.model, r, c):
                Sel.shape(j, o.model.get_shape(r, c))

                sel = pdb.gimp_selection_save(j)

                pdb.gimp_selection_shrink(j, w)

                if Sel.is_sel(j):
                    sel1 = pdb.gimp_selection_save(j)

                else:
                    sel1 = None

                # Make a Border selection by subtracting
                # the inner selection from the outer.
                Sel.load(j, sel)
                Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                if grid_sel:
                    Sel.load(j, grid_sel, option=fu.CHANNEL_OP_ADD)
                    pdb.gimp_image_remove_channel(j, grid_sel)

                grid_sel = pdb.gimp_selection_save(j)

                pdb.gimp_image_remove_channel(j, sel)
                if sel1:
                    pdb.gimp_image_remove_channel(j, sel1)

    if grid_sel:
        Sel.load(j, grid_sel)
        pdb.gimp_image_remove_channel(j, grid_sel)

        if n in ELLIPSE:
            z = do_ellipse_sel(j, o)
        else:
            z = process_selection(
                add_border_layer(j, o, o.parent),
                o
            )

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_shape_per_cell(j, o):
    """
    Draw border material for a square cell
    shape without merged cells or per cell.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    # Border Preset dict, 'o.d'
    d = o.d

    z = group = None
    row, column = o.model.division
    n = o.model.cell_shape

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(o.model, r, c):
                # Border Preset dict, 'o.e'
                e = o.e = d[ok.PER_CELL][r][c]

                w = e[ok.BORDER_WIDTH]
                if w and e[ok.OPACITY] and e[ok.BORDER_TYPE] != "None":
                    Sel.shape(j, o.model.get_shape(r, c))

                    if Sel.is_sel(j):
                        sel = pdb.gimp_selection_save(j)
                        pdb.gimp_selection_shrink(j, w)

                    else:
                        sel = None

                    sel1 = pdb.gimp_selection_save(j) if Sel.is_sel(j) \
                        else None

                    # Make a Border selection by subtracting
                    # the inner selection from the outer.
                    if sel:
                        Sel.load(j, sel)
                        Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                    if not Sel.is_sel(j):
                        Sel.load(j, sel)

                    if not group:
                        group = make_group(j, o)

                    if n in ELLIPSE:
                        z = do_ellipse_sel(j, o)
                        pdb.gimp_image_reorder_item(j, z, group, 0)
                        if not o.is_plan:
                            z = do_behind(z, e)

                    else:
                        if Sel.is_sel(j):
                            z = process_selection(
                                add_border_layer(j, o, group),
                                o
                            )
                            if not o.is_plan:
                                z = do_behind(z, e)

                    if sel:
                        pdb.gimp_image_remove_channel(j, sel)
                    if sel1:
                        pdb.gimp_image_remove_channel(j, sel1)

    if group:
        z = Lay.merge_group(group)
    return z


def do_square_grid(j, o):
    """
    Draw Border material for a square cell
    shape without merged cells or Per Cell.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has Border material.
    """
    # Border Preset dict, 'o.d'
    d = o.d

    row, column = o.model.division
    w = d[ok.BORDER_WIDTH]
    rect = o.model.get_merge_cell_rect(0, 0)
    w1 = rect.w * column
    h1 = rect.h * row

    for r in range(row):
        rect = o.model.get_merge_cell_rect(r, 0)
        Sel.rect(j, rect.x, rect.y, w1, w)
        Sel.rect(j, rect.x, max(rect.y + rect.h - w, rect.y), w1, w)

    for c in range(column):
        rect = o.model.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x, rect.y, w, h1)
        Sel.rect(j, max(rect.x + rect.w - w, rect.x), rect.y, w, h1)

    z = process_selection(add_border_layer(j, o, o.parent), o)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def get_color(o):
    """
    Get the color for the Border material.

    d: dict
        Border Preset

    Return: tuple
        RGB
    """
    if o.is_plan:
        return o.color
    return o.e[ok.COLOR_1]


def make_group(j, o):
    """
    Make a group layer for cell border layers.

    j: GIMP image
        work-in-progress

    o: One
        Has layer name and parent.

    Return: layer
        of group type
    """
    return Lay.group(j, o.layer_name, parent=o.parent)


def process_selection(z, o, is_fill=True):
    """
    The selection is the Border. Fill,
    blur, and emboss complete the process.

    z: layer
        for Border material

    o: One
        Has variables.

    is_fill: bool
        When true, the layer selection is filled with the Border color.

    Return: layer or None
        with Border material
    """
    j = z.image

    # Border Preset dict, 'o.e'
    d = o.e

    if Sel.is_sel(j):
        if is_fill:
            if o.is_plan:
                z = do_color(z, o)
            else:
                z = BORDER_FILL[d[ok.BORDER_TYPE]](z, o)

        pdb.gimp_selection_none(j)

        if d[ok.BORDER_BLUR]:
            Lay.blur(z, d[ok.BORDER_BLUR])
        pdb.gimp_selection_none(j)
    return z


class Border:
    """Organize Border access."""

    @staticmethod
    def do_box(o, is_plan):
        """
        Do a Border for a Box Model.

        j: GIMP image
            Is render.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is the Plan class.

        Return: layer or None
            Has Border material.
        """
        cat = Hat.cat
        j = cat.render.image
        z = None

        # Border Preset dict, 'o.d'
        d = o.e = o.d

        o.is_plan = is_plan

        if not is_plan:
            o.parent = cat.get_layer((o.render_type, o.model_name, nk.BORDER))

        o.face_x = Step.get_face_index(o.step)
        is_per_cell = o.is_per_cell = d[ok.PER_CELL]
        is_one_border = not is_per_cell
        o.layer_name = Lay.name(o.parent, BORDER)
        go = True

        if not is_per_cell:
            go = d[ok.BORDER_WIDTH] and d[ok.OPACITY] and \
                d[ok.BORDER_TYPE] != "None"

        if go:
            pdb.gimp_selection_none(j)

            if is_one_border:
                z = do_common_polygon_grid(j, o, face_x=o.face_x)
            else:
                z = do_face_per_cell(j, o)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.BORDER_INFLUENCE)
            if z:
                z.name = Lay.name(
                    o.parent,
                    "Cell Border Face " + str(o.face_x + 1)
                )
        return z

    @staticmethod
    def do_custom_cell(o, is_plan):
        """
        Do Border for a Custom Cell Model.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with Border material
        """
        cat = Hat.cat
        z = group = None

        # Border Preset dict, 'o.d'
        d = o.e = o.d

        o.is_plan = is_plan
        o.layer_name = Lay.name(o.parent, BORDER)

        if (
            d[ok.BORDER_WIDTH] and
            d[ok.OPACITY] and
            d[ok.BORDER_TYPE] != "None"
        ):
            j = cat.render.image
            n = o.model.cell_shape

            if n == sh.RECTANGLE:
                group = o.group = make_group(j, o)
                do_rect_custom_cell(j, o)
            else:
                o.group = o.parent
                z = do_shape_custom_cell(j, o, n)

            if group:
                z = Lay.merge_group(group)
            if not is_plan:
                z = GradientLight.apply_light(z, ok.BORDER_INFLUENCE)
        return z

    @staticmethod
    def do_table(o, is_plan):
        """
        Do a Border for a Table Model.

        j: GIMP image
            Is render.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is the Plan class.

        Return: layer or None
            Has Border material.
        """
        cat = Hat.cat
        j = cat.render.image
        z = None

        # Border preset dict, 'o.d'
        d = o.e = o.d

        n = o.model.cell_shape
        o.is_merge_cell = o.model.is_merge_cell
        o.is_plan = is_plan
        is_per_cell = o.is_per_cell = d[ok.PER_CELL]
        is_one_border = not any((o.is_merge_cell, is_per_cell))
        o.layer_name = Lay.name(o.parent, BORDER)
        go = True

        if not is_per_cell:
            go = d[ok.BORDER_WIDTH] and d[ok.OPACITY] and \
                d[ok.BORDER_TYPE] != "None"

        if go:
            pdb.gimp_selection_none(j)

            if n == sh.RECTANGLE:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_rect_grid(j, o)
                    else:
                        z = do_rect_grid(j, o)
                else:
                    z = do_rect_per_cell(j, o)

            elif n == sh.SQUARE:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_square_grid(j, o)
                    else:
                        z = do_square_grid(j, o)
                else:
                    z = do_rect_per_cell(j, o)

            elif n in ELLIPSE:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_ellipse_grid(j, o)
                    else:
                        z = do_shape_grid(j, o, n)
                else:
                    z = do_shape_per_cell(j, o)
            else:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_polygon_grid(j, o)
                    else:
                        z = do_shape_grid(j, o, n)
                else:
                    z = do_shape_per_cell(j, o)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.BORDER_INFLUENCE)
        return z

    @staticmethod
    def do_canvas(o, is_plan):
        """
        Make a Canvas Border.

        o: One
            Has variables

        Return: layer or None
            Has Border material.
        """
        cat = Hat.cat
        j = cat.render.image

        # Border preset dict, 'o.d'
        d = o.e = o.d

        z = None
        w, h = Render.size()
        o.is_plan = is_plan
        w1 = d[ok.BORDER_WIDTH]

        if w1 and d[ok.OPACITY] and d[ok.BORDER_TYPE] != "None":
            w2 = w1 * 2
            w3 = w1 // 2
            w4 = w1 - w3

            pdb.gimp_selection_none(j)

            if d[ok.OBEY_MARGINS]:
                top, bottom, left, right = o.model.canvas_margin
                width = w - left - right + w1
                height = h - top - bottom + w1
                Sel.rect(j, left - w3, top - w3, width, height)
                Sel.rect(
                    j,
                    left + w4, top + w4,
                    width - w2, height - w2,
                    option=fu.CHANNEL_OP_SUBTRACT
                )

            else:
                Sel.rect(j, 0, 0, w, h)
                Sel.rect(
                    j,
                    w1, w1,
                    w - w2, h - w2,
                    option=fu.CHANNEL_OP_SUBTRACT
                )

            o.layer_name = Lay.name(o.parent, nk.CANVAS_BORDER)
            z = add_border_layer(j, o, o.parent)
            z = process_selection(z, o)
            if not is_plan:
                z = do_behind(z, d)
                z = GradientLight.apply_light(z, ok.BORDER_INFLUENCE)
        return z


BORDER_FILL = {
    bo.AVERAGE_COLOR: do_average_color,
    bo.BACKDROP: do_backdrop,
    bo.COLOR: do_color,
    bo.GRADIENT: do_gradient,
    bo.IMAGE: do_image,
    bo.PATTERN: do_pattern,
    bo.PLASMA: do_plasma
}
