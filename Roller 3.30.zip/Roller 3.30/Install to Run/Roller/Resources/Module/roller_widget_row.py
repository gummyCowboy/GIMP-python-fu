#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Widget as fw
from roller_constant_key import Widget as wk
from roller_one import Hat
import gobject
import gtk


class Row(gtk.Alignment, gobject.GObject):
    """
    Is a GTK HBox container for multiple widgets
    that sit on the same row of a Table Widget.
    """
    # for OptionGroup's change subscription
    change_signal = fw.UI_CHANGE

    # a custom signal for change notification
    __gsignals__ = {
        fw.UI_CHANGE: (
            gobject.SIGNAL_RUN_LAST,
            None,
            (gobject.TYPE_PYOBJECT,)
        )
    }

    def __init__(self, **d):
        """
        Create an HBox.

        d: dict
            Has init values.
        """
        # for custom signal(s)
        gobject.GObject.__init__(self)

        super(gtk.Alignment, self).__init__()

        # The 'label' reference is a Label Widget displayed
        # in the Table container and is created by the Table.
        self.label = None

        self.key = d[wk.KEY] if wk.KEY in d else None
        self.step = d[wk.STEP] if wk.STEP in d else None
        self.win = d[wk.WIN] if wk.WIN in d else None
        self.group = d[wk.GROUP] if wk.GROUP in d else None
        self.hbox = gtk.HBox()
        self.add(self.hbox)

    def hide(self):
        """Hide the Buttons and its attached Label."""
        super(gtk.Alignment, self).hide()
        if self.label:
            if self.label.widget.get_visible():
                self.label.widget.hide()

    def show(self):
        """Show the Buttons and its attached Label."""
        super(gtk.Alignment, self).show()
        if self.label:
            if not self.label.widget.get_visible():
                self.label.widget.show()

    def subscribe(self):
        """
        Connect the Widget to its OptionGroup change subscriber.

        p: function
            to call on change
        """
        self.connect(
            self.change_signal,
            Hat.dog.signal_filter.add_group,
            self.group
        )


# Register the custom signal.
gobject.type_register(Row)
