#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg
from roller_constant_fu import Fu
from roller_constant_key import Model as md, Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb


def do_table(j, z, group, o):
    """
    Do the Image Effect for each image placed in a Table Model.

    j: GIMP image
        Is render.

    z: layer
        to receive effect

    group: layer
        Has parent with name which has an appended z-height.

    o: One
        Has options.
    """
    def do():
        Hat.cat.join_selection(k)
        do_image(j, z, o)

    # Do one image at a time.
    cat = Hat.cat
    d = o.model.d
    is_merge_cell = o.model.is_merge_cell
    n = group.parent.name.split(" ")[-1]
    s = 1
    for r in range(o.r):
        for c in range(o.c):
            if is_merge_cell:
                s = d[ok.PER_CELL][r][c]

            # Is it a dependent cell?
            if s != (-1, -1):
                k = o.model_name, r, c

                if o.is_nested_group:
                    if cat.get_z_height(k) == n:
                        do()
                else:
                    do()


def do_image(j, z, o):
    """
    Do the Image Effect for an image.

    j: GIMP image
        Is render.

    z: layer
        to receive effect

    o: One
        Has options.
    """
    if Sel.is_sel(j):
        # Shape Burst Preset dict, 'o.d'
        d = o.d

        Sel.grow(j, d[ok.FRAME_WIDTH], 1)

        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(d[ok.SHAPE_BURST]),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            (x1 + x) / 2, (y1 + y) / 2,
            x, y
        )


def do_layer(j, image_layer, o):
    """
    Add a frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    # Shape Burst Preset dict, 'd'
    d = o.d

    parent = image_layer.parent
    group = Lay.group(
        j,
        Lay.name(parent, o.k),
        offset=Lay.offset(image_layer) + 1,
        parent=parent
    )
    z = Lay.add(j, o.k, parent=group)

    RenderHub.set_fill_context(fg.FILL_DICT)
    RenderHub.set_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        fu.GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(d[ok.GRADIENT_ROW][1])

    if o.model_type == md.TABLE:
        do_table(j, z, group, o)

    else:
        Sel.make_layer_sel(image_layer)
        do_image(j, z, o)

    z = Lay.merge_group(group)

    pdb.gimp_selection_none(j)

    # Invert the gradient?
    if d[ok.GRADIENT_ROW][0]:
        pdb.gimp_drawable_invert(z, 0)

    if d[ok.UNSHARP_AMOUNT] and d[ok.UNSHARP_RADIUS]:
        Gegl.unsharp_mask(z, d[ok.UNSHARP_RADIUS], d[ok.UNSHARP_AMOUNT], .0)
        Gegl.blur(z, .5)

    Lay.clear_image_sel(image_layer, z)
    return GradientLight.apply_light(z, ok.OTHER_FRAME)


class ShapeBurst:
    """Create a frame from a shape-burst type of gradient."""

    @staticmethod
    def do(o):
        """
        Do the Image Effect.
        Is an Image Effect template function.

        o: One
            Has variables.

        Return: layer or list of layers
            with frame material
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # Is a list of layers for a Preview undo function, 'undo_z'.
        undo_z = []

        # a list of layer(s) for Shadow #1 and Shadow #2
        o.shadow_layer = []

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [do_layer(j, i.layers[0], o)]
            o.shadow_layer = [z]

        else:
            if pdb.gimp_item_is_group(z):
                z = Lay.clone(z)
                z = Lay.merge_group(z)
                undo_z = do_layer(j, z, o)

                Lay.remove(z)
                z = o.image_layer

            else:
                undo_z = do_layer(j, z, o)
            if undo_z:
                if not isinstance(z, list):
                    z = [z]

                if not isinstance(undo_z, list):
                    undo_z = [undo_z]
                o.shadow_layer = undo_z + z
        return undo_z
