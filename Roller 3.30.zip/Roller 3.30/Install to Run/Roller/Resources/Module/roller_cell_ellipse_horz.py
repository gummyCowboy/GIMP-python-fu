#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_cell_hexagon_regular import HexagonRegular
from roller_one import Rect
from roller_one_extract import Shape

CELL_SIZE = gr.CELL_SIZE


class EllipsisHorz(HexagonRegular):
    """
    Calculate the position and the size of cells. The cells are ellipse
    shaped, aligned horizontally, and use a double-spaced model-type.
    """

    def __init__(self, o):
        """
        Calculate the ellipse cell size rectangle and the ellipse shape.

        o: One
            Has init values.
        """
        HexagonRegular.__init__(self, o)
        row, column = o.r, o.c
        table = o.model.table
        is_by_count = False if o.grid_type == CELL_SIZE else True
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(o.model, r, c):
                    # Cell,'a'
                    # cell rectangle, 'b'
                    a = table[r][c]
                    b = a.cell
                    if is_by_count:
                        e = a.shape = a.plaque = Shape.calc_horizontal_ellipse(
                            b
                        )

                        # The ellipse rect is smaller than the hexagon rect.
                        a.cell = Rect(e['x'], e['y'], e['w'], e['h'])
                    else:
                        a.shape = a.plaque = {
                            'x': b.x, 'y': b.y,
                            'w': b.w, 'h': b.h
                        }
