#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Mage, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
X_IS_0 = Y_IS_0 = 0


def draw_squares(z, d):
    """
    Draw squares on a rotated layer. Create a pattern
    (a black square). Use the clipboard to hold the
    pattern. Fill the target layer with the pattern.

    z: layer
        target layer

    d: dict
        Has options.

    Return: layer
        work-in-progress
        Has material to select.
    """
    side = d[ok.GAP_WIDTH]
    w = side + d[ok.LINE_WIDTH]
    j1 = pdb.gimp_image_new(w, w, fu.RGB)
    z1 = Lay.add(j1, "Pattern")

    Lay.color_fill(z1, (255, 255, 255))

    x = (w - side) // 2
    y = (w - side) // 2

    Sel.rect(
        j1,
        x, y,
        w, w,
        option=fu.CHANNEL_OP_REPLACE
    )
    Sel.fill(z1, (0, 0, 0))

    # Set the Clipboard Image.
    Mage.copy_all(j1)

    pdb.gimp_image_delete(j1)
    RenderHub.set_fill_context(fg.FILL_DICT)
    pdb.gimp_context_set_pattern("Clipboard Image")
    pdb.gimp_drawable_edit_bucket_fill(
        z,
        fu.FILL_PATTERN,
        X_IS_0, Y_IS_0
    )
    pdb.plug_in_colortoalpha(z.image, z, (0, 0, 0))
    return z


def make_sel(o, effect_layer, frame_sel, filler_sel):
    """
    Modify the current selection with selected grid
    lines. Add the grid selection to the border
    selection within the bounds of the filler selection.

    o: One
        Has options.

    effect_layer: layer
        work-in-progress

    frame_sel: Selection
        of image frame

    fill_sel: Selection
        space for squares

    Return: state of selection
        of render
    """
    cat = Hat.cat
    j = cat.render.image
    z = Lay.add(j, o.k, parent=effect_layer.parent)
    d = o.d
    z1 = RenderHub.do_rotated_layer(z, d, draw_squares)

    Sel.isolate(z1, filler_sel)
    Sel.item(z1)
    Sel.grow(j, 1, 1)
    pdb.gimp_selection_feather(j, 1)
    j.remove_layer(z1)
    Sel.load(j, frame_sel, option=fu.CHANNEL_OP_ADD)


class SquarePunch:
    """Add square holes to a frame that fits around a BorderLine frame."""

    @staticmethod
    def do(o):
        """
        Do the Square Punch Image Effect. Is an Image Effect template function.

        o: One
            Has variables.

        Return: layer or list of layers
            with Square Punch
        """
        return BorderLine.do(o, framer=make_sel, filler=lambda *_: None)
