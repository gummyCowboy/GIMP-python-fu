#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
import gimpfu as fu

pdb = fu.pdb


def do_image(j, image_layer, o):
    """
    Add a frame around the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer
        with frame material
    """
    # Color Board Preset dict, 'o.d'
    d = o.d

    parent = image_layer.parent

    Sel.make_layer_sel(image_layer)

    sel = Hat.cat.save_short_term_sel()

    Sel.grow(j, d[ok.FRAME_WIDTH], d[ok.FRAME_TYPE])
    Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

    z = Lay.add(j, Lay.name(parent, o.k), parent=parent)

    Sel.fill(z, d[ok.COLOR_1A])
    pdb.plug_in_antialias(j, z)

    # Return layer for undo.
    return GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)


class ColorBoard:
    """Create a an color edge around an image(s)."""

    @staticmethod
    def do(o):
        """
        Do the Colored Board Image Effect.
        Is an Image Effect template function.

        o: One
            Has variables.

        Return: layer or list of layers
            with frame
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # Is a list of layers for a Preview undo function, 'undo_z'.
        undo_z = []

        # a list of layer(s) for Shadow #1 and Shadow #2, 'o.shadow_layer'
        o.shadow_layer = []

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [do_image(j, i.layers[0], o)]
                o.shadow_layer = [z]

        else:
            undo_z = do_image(j, z, o)
            if undo_z:
                o.shadow_layer = [undo_z, z]
        return undo_z
