#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_one import Base, Hat
from roller_constant_for import Gradient as fg
from roller_constant_key import Option as ok
from roller_one_fu import Lay, Mage, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


def make_pattern(d):
    """
    Make a rectangle pattern. The pattern is
    made-to-order and is then transferred
    to the canvas via the clipboard.

    d: dict
        Rectangle Pattern Preset

    Return: image in the clipboard
        Is pattern.
    """
    # pattern size
    width, height = d[ok.WIDTH_CLIP], d[ok.HEIGHT_CLIP]

    # Make a hidden image to draw the pattern on, 'j'.
    j = pdb.gimp_image_new(width, height, fu.RGB)

    z = Lay.add(j, "Pattern")
    count = d[ok.COLOR_COUNT_2_6]

    # Calculate the size of the rectangle, 'w, h'.
    # Use the rectangle to make selections for color fill.
    w, h = float(width) / count, float(height) / count

    is_brick = d[ok.COLOR_GRID_TYPE]
    is_random = d[ok.RANDOM]

    # x-intersect list, 'q_x'
    # for both checkerboard and brick
    q_x = [0] * (count + 1)
    q_x[-1] = width
    x = w

    for i in range(1, count):
        q_x[i] = int(x)
        x += w

    if is_brick:
        # x-intersect array for brick odd rows, 'q_x1'
        q_x1 = [0] * (count + 2)
        q_x1[-1] = width
        x = w / 2

        for i in range(1, count + 1):
            q_x1[i] = int(x)
            x += w

    # y-intersect array, 'q_y'
    q_y = [0] * (count + 1)
    q_y[-1] = height
    y = h

    for i in range(1, count):
        q_y[i] = int(y)
        y += h

    for row in range(count):
        columns = count

        if is_brick and row % 2:
            # Need an extra column for the half-cut bricks.
            columns += 1

        for column in range(columns):
            if is_random:
                # Get a random color from the color options.
                color = d[ok.COLOR_6A][randint(0, count - 1)]

            else:
                # Get the next color in the wrap-around color scheme.
                index = row * count + row + column

                while index >= count:
                    index -= count
                color = d[ok.COLOR_6A][index]

            if is_brick and row % 2:
                x = q_x1[column]
                w = q_x1[column + 1] - q_x1[column]

            else:
                x = q_x[column]
                w = q_x[column + 1] - q_x[column]

            y = q_y[row]
            h = q_y[row + 1] - q_y[row]

            # Select and fill the rectangle.
            Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, color)

    if d[ok.FLIP_VERTICAL]:
        pdb.gimp_selection_none(j)
        Lay.flip(z)

    # Set the Clipboard Image for the pattern fill op.
    Mage.copy_all(j)

    # Close the tile image as the pattern is done.
    pdb.gimp_image_delete(j)


class RectPattern:
    """Create a rectangle pattern."""

    @staticmethod
    def do(o):
        """
        Do the Backdrop Style.

        o: One
            Has variables.

        Return: layer
            with Rectangle Pattern
        """
        def fill_it_():
            """
            Fill the target layer with a Clipboard Image pattern.
            """
            RenderHub.set_fill_context(fg.FILL_DICT)
            pdb.gimp_context_set_pattern("Clipboard Image")
            pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, 0, 0)

        cat = Hat.cat
        j = cat.render.image

        # Rectangle Pattern Preset dict, 'o.d'
        d = o.d

        if d[ok.OPACITY]:
            # layer name, 'n'
            # Group key, 'o.k'
            n = o.k + " WIP"

            cat.seed(d)
            make_pattern(d)

            if d[ok.ROTATE]:
                s = j.width, j.height
                w = Base.circumradius(s[0], s[1]) * 2
                j1 = pdb.gimp_image_new(w, w, fu.RGB)
                z = Lay.add(j1, n)

                fill_it_()

                Lay.rotate(j1, d[ok.ROTATE])
                pdb.gimp_edit_copy_visible(j1)
                pdb.gimp_image_delete(j1)

                # Backdrop Image layer, 'o.z'
                z = Lay.paste(o.z)
                z.name = n

            else:
                z = Lay.add(j, n)
                fill_it_()

            if d[ok.INVERT]:
                pdb.gimp_drawable_invert(z, 0)
            return RenderHub.finish_style(o, d, z, has_mode=True)
