#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Step as fs
from roller_constant_key import (
    Group as gk,
    Model as md,
    Option as ok,
    Pickle as pc,
    Preset as pk,
    Step as sk,
    Widget as wk
)
from roller_one import Comm, Hat, OZ
from roller_one_draw import Draw
from roller_option_preset_core import Core
from roller_option_preset_dict import NonPresetDict, PresetDict
from roller_widget_button_pair import ButtonPair
from roller_widget_tree import Node, OptionList, ModelList
from roller_window_preset import RWPreset
from roller_window_save import RWSave

LOAD_ERR = "Roller is unable to load a preset in its original state."
PRESET_LABEL = "Manage Preset…", "Save Preset…"
PRESET_STEPS = {
    sk.GLOBAL: PresetDict.GLOBAL,
    sk.BACKDROP_STYLE: PresetDict.BACKDROP_STYLE,
    sk.BACKDROP_IMAGE: PresetDict.BACKDROP_IMAGE,
    sk.GRADIENT_LIGHT: PresetDict.GRADIENT_LIGHT,
    sk.MODEL: PresetDict.MODEL
}


def get_group(step):
    """
    Get the OptionGroup and Node of a step.

    step: tuple
        of steps

    Return: tuple
        OptionGroup, Node
    """
    group = Hat.cat.group_dict[step]
    return group, group.node


class Preset(ButtonPair):
    """Use to manage option group Presets."""

    def __init__(self, **d):
        """
        Create an option group Preset.

        d: dict
            Has keyword arguments.
        """
        def on_action(_g):
            if _g.key == PRESET_LABEL[0]:
                RWPreset(_g)
            else:
                RWSave(
                    {
                        pk.GET_DATA: self.get_value,
                        wk.KEY: self.group_key,
                        wk.WIN: self.win.win
                    }
                )

        self.group_key = d[wk.GROUP_KEY]
        self.group = d[wk.GROUP]
        ButtonPair.__init__(
            self,
            key=d[wk.KEY],
            group=d[wk.GROUP],
            on_widget_change=on_action,
            text=PRESET_LABEL,
            win=d[wk.WIN]
        )

    @staticmethod
    def _expand_preset(d, e):
        """
        Expand dict from another dict. Is recursive.

        d: dict
            expanding dict

        e: dict
            source dict
        """
        # Remove old.
        for k in d.keys():
            if k not in e:
                d.pop(k)
        for i in e.keys():
            if i not in d:
                d[i] = deepcopy(e[i])
            if d[i] and isinstance(d[i], dict):
                if e[i] and isinstance(e[i], dict):
                    Preset._expand_preset(d[i], e[i])
                else:
                    # Change type.
                    d[i] = deepcopy(e[i])

    @staticmethod
    def get_default(k):
        """
        Get a Preset dictionary. Is part of a Preset template.

        k: string
            of Preset

        Return: dict
            with default values
        """
        return PresetDict.get_default(k)

    @staticmethod
    def get_keys(k):
        """
        Get the keys belonging to a Preset. Is part of a Preset template.

        k: string
            of Preset

        Return: list
            of Preset keys
        """
        return PresetDict.get_keys(k)

    def get_value(self):
        """
        Return the preset dictionary. Skip
        Widget(s) without keys in the dictionary.
        """
        d = {}
        e = self.group.d

        for i in PresetDict.get_keys(self.group_key):
            d[i] = e[i].get_value()
        return d

    def load(self, n, external_preset):
        """
        Load a Preset dict.

        n: string
            name of Preset; a key

        external_preset: dict
            The key is a Preset name.
            The value is a file path.

        Return: dict
            the loaded Preset
        """
        Draw.load_count += 1

        if external_preset and n in external_preset:
            # Preset dict, 'd'
            d = OZ.pickle_load(
                {
                    pc.FILE: external_preset[n],
                    pc.SHOW_ERROR: True
                }
            )

        else:
            d = PresetDict.get_default(self.group_key)

        self.set_value(d)

        Draw.load_count -= 1
        return d

    def load_preset(self, d):
        """
        Load a Preset dictionary into its corresponding Widgets.

        d: dict
            of Preset
        """
        Draw.load_count += 1

        self.set_value(d)
        Draw.load_count -= 1

    def set_value(self, d):
        """
        Load a Preset from a dictionary.

        d: dict
            Preset dict or None
        """
        Draw.load_count += 1
        e = self.group.d

        if self.group.group_type == PerCell:
            for i, a in d.items():
                # Find the Per Cell key.
                if i in e:
                    Core.check_per_cell(self.group.d[ok.PER_CELL], a)

        else:
            # Synchronize the Preset with the default keys.
            Core.synchronize_preset(d, self.get_default(self.group_key))

        [e[i].set_value(d[i]) for i in e if i in d]
        Draw.load_count -= 1


class SuperPreset(Preset):
    """Has sub-presets."""

    def __init__(self, **d):
        """
        Initialize the Preset.

        d: dict
            Has keyword init values.
        """
        Preset.__init__(self, **d)

    def _expand_tree(self, d, a, g, k, z_list=None):
        """
        Use recursion to walk through the
        option groups setting the list's Widget values.

        d: dict
            of SuperPreset
            Has the values to load into their corresponding Widgets.

        a: OptionGroup
            Has the needed info.

        g: Node
            Has branches.

        k: tuple
            step
            Is the key for the option group dict.

        z_list: ModelList or None

        Return: tuple
            OptionGroup, Node, step key, ModelList
            for recursion
        """
        if g:
            for i in g.get_value():
                # step, a step, key, 'k1'
                k1 = k + (i,)

                if k1 in Hat.cat.group_dict:
                    # OptionGroup, 'a'
                    a = Hat.cat.group_dict[k1]

                    if a.node:
                        g = a.node
                        a, g, k1, z_list = self._expand_tree(
                            d,
                            a,
                            g,
                            k1,
                            z_list=z_list
                        )
                    else:
                        # Widget dict, 'e'
                        e = a.d

                        # SuperPresets are not in the save dict.
                        if k1 in d:
                            # loaded option dict, 'd1'
                            d1 = d[k1]

                            # option group key, 'j', and Widget, 'g'
                            for j, g in e.items():
                                if j in d1:
                                    if isinstance(g, ModelList):
                                        g.set_value(
                                            d1[j],
                                            is_preset=True
                                        )
                                        z_list = g
                                    elif isinstance(g, OptionList):
                                        g.set_value(d1[j])
        return a, g, k, z_list

    def _load_steps(self, d):
        """
        There are two phases to loading a Steps SuperPreset:

        (1) Create the option groups.
        (2) Load the option group values.

        d: dict
            key: step, value: group dict
        """
        # Walk-through the Nodes to get additional steps.
        step = sk.STEPS
        group, node = get_group(step)
        model_list = self._expand_tree(d, group, node, step)[3]

        # Translate a SuperPreset Model name into an id number.
        if model_list:
            for i in model_list.get_value():
                n = i[md.NAME_INDEX]
                _id = Hat.dog.group_id.get_id(n)
                d = Core.translate_to_id(d, n, _id)
                step = sk.EFFECT + (_id,)
                group, node = get_group(step)
                d = Core.translate_model_to_id(
                    d,
                    self._expand_tree(d, group, node, step)[3]
                )
        SuperPreset._load_widgets(d)

    def _load_sub_steps(self, d, q):
        """
        Load Widgets of a sub-SuperPreset.

        d: dict
            of Effect

        q: tuple
            of indices in step where the group id is inserted
        """
        step = self.group.step[:-1]
        group, node = get_group(step)

        # Get ids in the step.
        q1 = []

        for i in q:
            q1 += [step[i]]

        # Translate the name into its id.
        e = {}

        for i, a in d.items():
            # If 'i' is not a tuple, then the dict is the wrong version.
            if isinstance(i, tuple):
                q3 = list(i)

                for j in range(len(q)):
                    q3[q[j]] = q1[j]
                e[tuple(q3)] = a

        d = Core.translate_model_to_id(
            e,
            self._expand_tree(e, group, node, step)[3]
        )
        SuperPreset._load_widgets(d)

    @staticmethod
    def _load_widgets(d):
        """
        Load the Widgets from a translated SuperPreset dictionary.

        d: dict
            of SuperPreset
        """
        is_err = False
        e = Hat.cat.group_dict

        # Set the values of the options.
        for i, d1 in d.items():
            for j, a in d1.items():
                # option value, 'a'
                if j != sk.SELECTED_ROW:
                    if i in e and j in e[i].d:
                        # Don't set it twice.
                        if type(e[i].d[j]) not in (ModelList, OptionList):
                            g = e[i].d[j]
                            g.group.changed = g.group.unseen = True
                            a = Core.update_version(g, a)
                            g.set_value(a)
                    else:
                        if not is_err:
                            # Report an error one time.
                            Comm.info_msg(LOAD_ERR)
                        is_err = True
                else:
                    if a is not None:
                        if i in e:
                            k = [k for k in e[i].d][0]
                            # Select Node item.
                            e[i].d[k].select_item(a)

    @staticmethod
    def _translate_step(q):
        """
        Replace a numeric id with its corresponding name.

        q: tuple
            a step key

        Return: tuple
            the translated step
        """
        q1 = []
        group_id = Hat.dog.group_id

        if len(q) > fs.MODEL_INDEX:
            if isinstance(q[fs.MODEL_INDEX], int):
                q1 += [fs.MODEL_INDEX]

        if q1:
            q2 = list(q)

            for x1 in q1:
                q2[x1] = group_id.get_name(q[x1])
            q = tuple(q2)
        return q

    def get_value(self):
        """
        Assemble a SuperPreset dictionary. Use when saving a SuperPreset.

        Return: dict
            of SuperPreset
            key: step; value: option group dict
        """
        k = sk.STEPS if self.group_key == gk.PRESET_STEPS else \
            self.group.step[:-1]

        d = Core.get_steps(k, with_list=False)[0]
        return Core.translate_to_name(d)

    def set_value(self, d):
        """
        Override the 'set_value' function in the Preset class.

        d: dict
            of SuperPreset
        """
        if not d:
            # Steps in the SuperPreset where each step
            # is a key to an option group, 'q'.
            q = []

            # Use default dict.
            if self.group_key == gk.PRESET_STEPS:
                d = PRESET_STEPS
            else:
                if not Draw.preset_load_count:
                    # Create a default dict.
                    step = self.group.step[:-1]
                    q = Core.get_steps(step, with_dict=False)[1]

                # Remove useless steps.
                for x, i in enumerate([j for j in q]):
                    # Get OptionGroup, 'a'.
                    a = Hat.cat.group_dict[i]
                    if a.group_type not in (Node, SuperPreset):
                        d[i] = a.group_type.get_default(a.group_key)
        if d:
            Draw.preset_load_count += 1

            if self.group_key == gk.PRESET_STEPS:
                self._load_steps(d)

            else:
                # sub-SuperPreset
                if self.group_key in fs.SUPER_PRESET:
                    self._load_sub_steps(d, fs.SUPER_PRESET[self.group_key])
            Draw.preset_load_count -= 1


class NonPreset:
    """
    Are option groups that do not have a Preset.
    """

    @staticmethod
    def get_default(k):
        """
        Get a NonPreset dictionary. Is part of a Preset template.

        k: string
            NonPreset key

        Return: dict
            with default values
        """
        return NonPresetDict.get_default(k)

    @staticmethod
    def get_keys(k):
        """
        Get the keys belonging to a NonPreset. Is part of a Preset template.

        k: string
            NonPreset key

        Return: list
            of Preset key
            of string
        """
        return NonPresetDict.get_keys(k)

    @staticmethod
    def load(d, k):
        """
        Load the default settings for a NonPreset group.

        d: dict
            of Widgets

        k: string
            group key
        """
        Draw.load_count += 1
        e = NonPreset.get_default(k)

        [d[i].set_value(e[i]) for i in e if i in d]
        Draw.load_count -= 1


class PerCell(Preset):
    """
    Inherit the functionality of a Preset.
    Use for an option group that is a PerCellGroup.
    """
    def __init__(self, **d):
        Preset.__init__(self, **d)


BEHIND_TYPE = {wk.HAS_PREVIEW: True, wk.WIDGET: NonPreset}
