#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import GroupId
from roller_option import Option
from roller_render_plan import Plan
from roller_render_product import Product
from roller_render_view import View


class Dog(object):
    """
    Use to initialize a class during program start and
    to remove a circular import reference problem.
    Reference class instance variables from 'Hat.dog'.
    """

    def __init__(self):
        """Initialize global access variables."""

        # Encode Model names with GroupId.
        self.group_id = GroupId()

        # Only one Option instance is needed through-out the program.
        self.option = Option()

        # Use when drawing a Plan.
        self.plan = Plan()

        # Use this class instance to Render or Preview.
        self.product = Product()

        # A class that stockpiles signals and removes duplicates.
        self.signal_filter = None

        # Use to manage the Render View state.
        self.viewer = View()
