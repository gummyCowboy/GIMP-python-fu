#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Effect as ek, Option as ok
from roller_one import Hat, One
from roller_one_extract import Render
from roller_one_fu import Lay, Sel
from roller_option_preset_dict import PresetDict
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

pdb = fu.pdb
LEFT, TOP, RIGHT, BOTTOM = range(4)


class FloorSample:
    """Has wedges colored by a gradient between two colors."""

    @staticmethod
    def do(o):
        """
        Draw the samples wedges.

        o: One
            Has variables.

        Return: layer or None
            with Floor Sample
        """
        cat = Hat.cat

        # Floor Sample Preset dict, 'd'
        d = o.d

        j = cat.render.image
        if d[ok.OPACITY]:
            color, color1 = d[ok.COLOR_2A]

            if d[ok.INVERT]:
                color = RenderHub.invert_color(color)
                color1 = RenderHub.invert_color(color1)

            angle = 360. / d[ok.NUMBER_OF_SLICES]
            steps = d[ok.NUMBER_OF_SLICES]
            s = w, h = Render.size()
            cx, cy = w // 2., h // 2.
            a = d[ok.STARTING_ANGLE]

            # Group key, 'o.k'
            group = Lay.group(j, o.k + " WIP")

            step = RenderHub.calc_gradient(color, color1, steps)
            x, y = RenderHub.get_point_on_rectangle(s, a)
            start_color = color
            e = PresetDict.get_default(ek.SHADOW_1)
            e[ok.SHADOW_COLOR] = d[ok.SHADOW_COLOR]
            e[ok.INTENSITY] = d[ok.INTENSITY]
            e[ok.SHADOW_BLUR] = d[ok.SHADOW_BLUR]
            shadow = One(model_name="", d=e, parent=group)

            for spin in range(steps):
                a += angle
                a = a if a < 360 else a - 360
                a = a if a > 0 else a + 360
                x1, y1 = [
                    int(i) for i in RenderHub.get_point_on_rectangle(s, a)
                ]
                q = cx, cy, x, y
                end = start = None

                # Get the corner points in the arc.
                # The variables 'start' and 'end' are
                # the sides of the image-rectangle
                # that the arc begins and ends.
                #
                # start-point
                for i in range(1):
                    if x == w and y != h:
                        start = RIGHT
                        break

                    if y == h:
                        if x != 0:
                            start = BOTTOM
                            break

                    if x == 0:
                        if y != 0:
                            start = LEFT
                            break
                    start = TOP

                # end-point
                for i in range(1):
                    if x1 == w:
                        if y1 != h:
                            end = RIGHT
                            break

                    if y1 == h:
                        if x != 0:
                            end = BOTTOM
                            break

                    if x1 == 0:
                        if y1 != 0:
                            end = LEFT
                            break
                    end = TOP

                _x = start + 1

                # Add corner points along the span of the arc.
                if start != end:
                    for i in range(4):
                        if _x > BOTTOM:
                            _x = 0

                        q += ((0, h), (0, 0), (w, 0), (w, h))[_x]

                        if _x == end:
                            break
                        _x += 1

                q += x1, y1

                Sel.polygon(j, q)

                x, y = x1, y1
                z = Lay.add(j, "Edge", parent=group)

                Sel.fill(z, color)

                if d[ok.INTENSITY] and d[ok.SHADOW_BLUR]:
                    if spin > 0:
                        shadow.cast = (z,)

                        z = Shadow.do(shadow)
                        pdb.gimp_image_reorder_item(j, z, group, 1)

                color = ()

                for i in range(4):
                    b = step[i] * (spin + 1)
                    color += (start_color[i] + int(b),)
            return RenderHub.finish_style(
                o,
                d,
                Lay.merge_group(group),
                has_mode=True
            )
