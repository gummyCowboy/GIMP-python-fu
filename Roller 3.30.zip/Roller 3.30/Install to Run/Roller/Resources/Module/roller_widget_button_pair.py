#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Widget as fw
from roller_constant_key import Button as bk, Widget as wk
from roller_widget_button import Button, PreviewButton
from roller_widget_row import Row
import gtk


class ButtonPair(Row):
    """
    Is a Row with two Buttons. Button access is through the
    'left_button' and 'right_button' attributes.
    """

    def __init__(self, **d):
        """
        Create an HBox with two Buttons.

        d: dict
            Has init values.
        """
        Row.__init__(self, **d)

        w = fw.MARGIN // 2
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        padding = d[wk.PADDING] if wk.PADDING in d else None
        q = d[wk.TEXT]
        d[wk.KEY] = d[wk.TEXT] = q[0]
        d[wk.PADDING] = w, w, 0, w
        d[wk.ALIGN] = 0, 0, 1, 0
        g = self.left_button = Button(**d)
        n = d[wk.KEY] = d[wk.TEXT] = q[1]
        d[wk.PADDING] = w, w, w, 0
        g1 = self.right_button = PreviewButton(**d) \
            if n == bk.PREVIEW else Button(**d)
        self.buttons = g, g1

        if padding:
            self.set_padding(*padding)
        for i in (g, g1):
            self.hbox.pack_start(i, expand=True)
            same_size.add_widget(i.widget)
