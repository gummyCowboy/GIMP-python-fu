#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
import gimpfu as fu
from roller_render_hub import RenderHub

pdb = fu.pdb

# Made of x, y pairs that range from 0.0 to 1.0.
CURVES = (
    # one
    (
        .0, .0,
        .4, .1,
        .8, .8,
        1., 1.
    ),

    # two
    (
        .0, .0,
        .2, .0,
        .5, 1.,
        .75, 1.,
        1., .0
    ),

    # three
    (
        .0, .0,
        .25, 1.,
        .5, 1.,
        .8, .0,
        1., .0
    ),

    # four
    (
        .0, 1.,
        .25, 1.,
        .55, .0,
        1., .0
    )
)


def draw_layer(j, z, d, layer_num):
    """
    There are four layers, each having a different pattern and
    value range. The pattern is a cube, but differs by scale.
    The value range is determined by the CURVES settings.

    j: GIMP image
        Is render.

    z: layer
        Backdrop Image copy

    d: dict
        Stone Age Preset

    layer_num: int
        distinguish range and type of effect
    """

    # layer to receive range of effect, 'z1'
    z1 = Lay.clone(z, n="Curves")

    # layer with the average color value, 'z2'
    z2 = Lay.clone(z, n="Color")

    pdb.gimp_drawable_curves_spline(
        z1,
        fu.HISTOGRAM_VALUE,
        len(CURVES[layer_num]),
        CURVES[layer_num]
    )

    # Erase the black.
    pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

    # layer to receive symbol and average color, 'z'
    z = Lay.clone(z, n=str(layer_num + 1))
    z.mode = fu.LAYER_MODE_MULTIPLY

    RenderHub.make_cube_pattern(
        d[ok.PATTERN_SIZE] * (layer_num + 1),
        ((255, 255, 255), (187, 187, 187), (127, 127, 127)),
        d[ok.FLIP_VERTICAL]
    )
    RenderHub.set_fill_context(fg.FILL_DICT)
    pdb.gimp_context_set_pattern("Clipboard Image")
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, 0, 0)
    Sel.item(z1)
    Sel.invert_clear(z)
    Sel.item(z1)
    Sel.invert_clear(z2)

    # Get the average color to fill the effect later.
    avg_color = RenderHub.get_average_color(z2)

    # Fill existing pixels with the average
    # color using their material selection.
    color_layer = Lay.add_below(z)

    Sel.item(z)
    Sel.fill(color_layer, avg_color)
    Lay.merge(z)
    Lay.remove(z1)
    Lay.remove(z2)


class StoneAge:
    """Fill the Backdrop Image with layered cubes."""

    @staticmethod
    def do(o):
        """
        Do the Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            with Stone Age material
        """
        j = Hat.cat.render.image

        # Stone Age Preset dict, 'o.d'
        d = o.d

        if d[ok.OPACITY]:
            # Duplicate the Backdrop Image layer, 'o.z'.
            z = Lay.clone(o.z, n=o.k + " Base")

            # Group key, 'o.k'
            group = Lay.group(j, o.k + " WIP", z=z)

            for i in range(4):
                draw_layer(j, z, d, i)

            pdb.gimp_selection_none(j)
            Lay.blur(z, 500)

            z = Lay.merge_group(group)
            z1 = Lay.clone(z)
            z1.mode = fu.LAYER_MODE_DIFFERENCE

            pdb.gimp_drawable_curves_spline(
                z1,
                fu.HISTOGRAM_VALUE,
                6,
                (.0, .0, .0431, .3411, 1., 1.)
            )

            spread = (15, 10) if j.width > j.height else (10, 15)

            Gegl.spread(z, *spread)
            return RenderHub.finish_style(o, d, Lay.merge(z1), has_mode=True)
