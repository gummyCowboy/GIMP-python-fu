#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_backdrop_image import BackdropImage
from roller_constant_for import (
    Border as bo,
    Grid as gr,
    Plan as fy,
    Shape as sh
)
from roller_constant_key import (
    BackdropStyle as by,
    Group as gk,
    Model as md,
    Option as ok,
    Plan as ak,
    Step as sk
)
from roller_model_border import Border
from roller_one import Hat, One, Rect
from roller_one_extract import dispatch, Form, Render, Shape
from roller_one_fu import Lay, Sel
from roller_option_preset_dict import PresetDict
from roller_render import Render as dr
import gimpfu as fu

pdb = fu.pdb
PLAN = 'plan'
READY = ": Ready"
WORK = ": Working"


def draw_cell_info(d, group, rect):
    """
    Draw the cell info per a Plan option.

    d: dict
        of Plan options

    group: layer
        for a new layer

    rect: Rect
        cell rectangle
    """
    if d[ak.COORDINATE]:
        draw_coord(group, rect)

    if d[ak.CORNER]:
        draw_corners(group, rect)

    if d[ak.DIMENSION]:
        draw_dimension(group, rect)
    if d[ak.RATIO]:
        draw_ratio(group, rect)


def draw_coord(group, rect):
    """
    Draw image coordinates at the topleft of a cell.

    group: layer
        Is parent for a new layer.

    rect: Rect
        cell rectangle
    """
    x, y = rect.position
    z = make_text(str(x) + ", " + str(y))
    draw_text(group, z, x + 3, y)


def draw_corners(group, rect):
    """
    Draw image corner coordinates.

    group: layer
        Is parent for new layer.

    rect: Rect
        cell rectangle
    """
    # top-right
    x, y = rect.position
    w, h = rect.size
    n = str(x + w) + ", " + str(y)
    z = make_text(n)

    draw_text(group, z, x + w - z.width - 3, y)

    # bottom-left
    n = str(x) + ", " + str(y + h)
    z = make_text(n)
    draw_text(group, z, x + 3, y + h - z.height)


def draw_custom_cell_shape(j, o):
    """
    Draw a Custom Cell Model's cell shape.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        with shape
    """
    q = Form.calc_margin(o.d, *Render.size())
    q1 = dispatch[o.model.cell_shape](o.model.get_pocket(0, 0))

    if any(q):
        Sel.shape(j, q1)
        pdb.gimp_selection_shrink(j, 1)

        sel = pdb.gimp_selection_save(j)
        z = Lay.add(j, "Cell Shape", parent=o.parent)

        Sel.shape(j, q1)
        Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
        Sel.fill(z, fy.CELL_SHAPE_COLOR)
        pdb.gimp_image_remove_channel(j, sel)

    else:
        o.color = fy.CELL_SHAPE_COLOR
        o.d = PresetDict.get_default(gk.CELL_BORDER)
        o.d[ok.BORDER_WIDTH] = 1
        z = Border.do_custom_cell(o, True)
    return z


def draw_dimension(group, rect):
    """
    Draw an image's dimension at the bottom-right corner of a cell.

    group: layer
        Is parent for a new layer.

    rect: Rect
        cell rectangle
    """
    x, y = rect.position
    w, h = rect.size
    n = str(w) + ", " + str(h)
    z = make_text(n)
    draw_text(group, z, x + w - z.width - 3, y + h - z.height)


def draw_name(group, n, rect, offset_y=0):
    """
    Draw an image name for a cell image.

    group: layer
        Is parent for a new text layer.

    n: string
        to draw

    rect: Rect
        cell rectangle

    offset_y: int
        Change location of the name.

    Return: layer
        with text
    """
    z = make_text(n)
    x, y = rect.position
    w, h = rect.size
    x = w // 2 + x - z.width // 2
    y = h // 2 + y + z.height // 2 + offset_y

    draw_text(group, z, x, y)
    return z


def draw_ratio(group, rect):
    """
    Draw a cell ratio at the center of a cell. A ratio
    is a cell center point divided by the Render size.

    group: layer
        Is parent for a new layer.

    rect: Rect
        cell rectangle
    """
    x, y = rect.position
    w, h = rect.size
    s = Render.size()
    x1 = (w // 2 + x) / 1. / s[0]
    y1 = (h // 2 + y) / 1. / s[1]
    r_x = format(x1, '.2f')
    r_y = format(y1, '.2f')
    n = r_x[int(x1 < 1):] + ", " + r_y[int(y1 < 1):]
    z = make_text(n)
    x2 = x + w // 2 - z.width // 2
    y2 = y + h // 2 - z.height // 2
    draw_text(group, z, x2, y2)


def draw_text(group, z, x, y):
    """
    Add a text layer to the group.

    group: layer
        parent

    z: layer
        to receive text

    x, y: int
        final position
        screen coordinate
    """
    pdb.gimp_image_insert_layer(Hat.cat.render.image, z, group, 0)
    pdb.gimp_text_layer_set_color(z, (255, 255, 255))
    pdb.gimp_layer_set_offsets(z, x, y)
    z.opacity = 66.


def make_text(n):
    """
    Create a new text layer.

    n: string
        text to display

    Return: layer
        with text
    """
    return pdb.gimp_text_layer_new(
        Hat.cat.render.image,
        n,
        'Sans-serif',
        11.,
        fu.PIXELS
    )


def update_unseen_flag(steps):
    """
    The change flag is used to indicate an OptionGroup's Plan
    state. If it's changed, then the Plan View needs to be done.
    The change-status flag also has a chain-inheritance. If a
    step is changed, the succeeding steps are also changed.

    steps: list
        of steps (tuples) (Node item 1,)
        A step is a key to an OptionGroup value in 'cat.group_dict'.

    Return: list
        of changed steps
    """
    e = Hat.cat.group_dict
    q = []
    is_change = False

    # Every step after the first changed group is part of a Plan.
    for i in steps:
        a = e[i]
        if not is_change and a.unseen:
            is_change = True
        if is_change:
            a.unseen = False
            q += [i]
    return q


class Plan(dr):
    """Organize Plan methods."""

    def __init__(self):
        """Initialize variables."""
        dr.__init__(self, PLAN)

        self._previous_steps = []

        self.non_canvas_d.update(
            {
                by.BACKDROP_IMAGE: self._do_backdrop_style,
                gk.CELL_MARGIN: self._do_cell_margin,
                gk.CANVAS_MARGIN: self._do_canvas_margin
            }
        )
        self._extra_op_d = {
            gk.RECTANGLE: self._do_rectangle_plan,

            # Box
            gk.BOX_PROPERTY: self._name_group,
            gk.TYPE_BOX: self._do_grid_type_plan,

            # Custom Cell
            gk.CUSTOM_CELL_PLACE: self._draw_custom_cell_image_name,
            gk.CUSTOM_CELL_MARGIN: self._draw_custom_cell_margin,
            gk.CUSTOM_CELL_PROPERTY: self._name_group,

            # Stack
            gk.STACK_PROPERTY: self._name_group,
            gk.STACK_CELL_MARGIN: self._draw_stack_cell_margin,

            # Table
            gk.CELL_PLACE: self._draw_cell_image_name,
            gk.TABLE_PROPERTY: self._name_group,
            gk.TYPE_TABLE: self._do_grid_type_plan
        }

    def _do_backdrop_style(self, o):
        """
        Create a Plan group and a faux Backdrop Image layer.

        o: One
            Has variables.
        """
        d = deepcopy(self.image_index)
        z = self.backdrop_layer = Lay.add(
            Hat.cat.render.image,
            "Backdrop",
            parent=self.plan_group
        )

        BackdropImage.do(o, is_plan=True)
        Lay.color_fill(z, fy.BACKGROUND_COLOR)
        self.undo[o.step] = (z, d), self.undo_layer

    def _do_cell_margin(self, o):
        """
        Plan Cell Margin. Overrides the Render
        class' function with the same name.

        o: One
            Has variables.
        """
        j = Hat.cat.render.image
        q = [self.model.clone(), None]
        z = None

        self.model.calc_pocket(o)

        if self.plan_flags[ak.CELL_MARGIN]:
            pdb.gimp_selection_none(j)

            z = Lay.add(j, "Cell Margin", parent=self.model_group)
            z.opacity = 66.
            self._draw_cell_margins(o, z)

        if self.plan_flags[ak.CELL_SHAPE]:
            z1 = z

            if o.model_type == md.TABLE:
                z = self.draw_grid_cell_shape(j, z, o)

            elif o.model_type == md.BOX:
                z = self.draw_box_cell_shape(j, z, o)
            if z and z1 and z != z1:
                z = Lay.merge(z)
        if z:
            q[1] = z
            self.undo[o.step] = q, self._undo_plan_cell_margin

    def _do_grid_type_plan(self, o):
        """
        Plan a Grid-type Model.

        o: One
            Has variables.
        """
        a = self.model.clone()
        j = Hat.cat.render.image
        z = group = None
        d = self.plan_flags
        n = "Grid"
        s = 1

        # Cell Type Preset dict, 'o.d'
        is_per_cell = o.d[ok.PER_CELL] if ok.PER_CELL in d else False
        p = self.model.get_merge_cell_rect if o.model_type == md.TABLE else \
            self.model.get_cell_rect

        if d[ak.GRID]:
            group = Lay.group(j, n, parent=self.model_group)
            z = Lay.add(j, n, parent=group)
            self._draw_grid(z)

        if any(
            (
                d[ak.COORDINATE],
                d[ak.CORNER],
                d[ak.DIMENSION],
                d[ak.RATIO]
            )
        ):
            if not group:
                group = Lay.group(j, n, parent=self.model_group)

            row, column = self.model.division
            for r in range(row):
                for c in range(column):
                    if is_per_cell:
                        s = o.d[ok.PER_CELL][r][c]
                    if (
                        Shape.is_allocated_cell(self.model, r, c) and
                        s != (-1, -1)
                    ):
                        draw_cell_info(d, group, p(r, c))

        if group:
            z = Lay.merge_group(group)
        self.undo[o.step] = (a, z), self._undo_grid

    def _do_canvas_margin(self, o):
        """
        Calculate Canvas Margin. Show the margins in the Plan group.

        o: One
            Has variables.
        """
        z = None
        a = self.model.clone()

        # Canvas Margin Preset dict, 'o.d'
        self.model.canvas_margin = Form.calc_margin(o.d, *Render.size())

        if self.plan_flags[ak.CANVAS_MARGIN]:
            z = self._draw_canvas_margins(o)
        self.undo[o.step] = (a, z), self._undo_canvas_margins

    def _do_rectangle_plan(self, o):
        """
        Process a Custom Cell Rectangle step. Is called after
        the '_do_rectangle' function in the Render module.
        """
        cat = Hat.cat
        j = cat.render.image
        d = self.plan_flags
        group = None
        a = self.model.rect
        layers = []

        if self.plan_flags[ak.RECTANGLE]:
            group = Lay.group(j, "Rectangle", parent=self.model_group)
            z = Lay.add(j, "Lines", parent=group)
            s = Render.size()
            x, y = a.position
            w, h = a.size
            layers += [z]

            pdb.gimp_selection_none(j)
            Sel.rect(j, 0, y, s[0], 1)
            Sel.rect(j, 0, y + h, s[0], 1)
            Sel.rect(j, x, 0, 1, s[1])
            Sel.rect(j, x + w, 0, 1, s[1])
            Sel.fill(z, fy.GRID_COLOR)

        if any(
            (d[ak.COORDINATE], d[ak.CORNER], d[ak.DIMENSION], d[ak.RATIO])
        ):
            if not group:
                group = Lay.group(j, "Info", parent=self.model_group)
            draw_cell_info(d, group, a)
        if group:
            # Insert the layer, 'z', into the undo argument
            # made by the Render module's '_do_rectangle' function.
            z = Lay.merge_group(group)
            q, p = self.undo[o.step]
            self.undo[o.step] = (z, q[1]), p

    def _draw_cell_image_name(self, o):
        """
        Draw the image name for a cell image.

        o: One
            Has variables.
        """
        def add_group():
            return Lay.group(
                j,
                "Image Name",
                parent=self.model_group
            )

        if self.plan_flags[ak.NAME]:
            j = Hat.cat.render.image
            model = o.model
            row, column = model.division
            group = None

            if o.model_type == md.STACK:
                offset_y = 0
                for r in range(row):
                    n = model.get_image_name(r, 0)
                    if n:
                        if not group:
                            group = add_group()

                        z = draw_name(
                            group,
                            n,
                            self.model.rect,
                            offset_y=offset_y
                        )
                        offset_y += z.height

            else:
                for r in range(row):
                    for c in range(column):
                        if Shape.is_allocated_cell(model, r, c):
                            n = model.get_image_name(r, c)
                            if n:
                                if not group:
                                    group = add_group()
                                draw_name(
                                    group,
                                    n,
                                    model.get_merge_cell_rect(r, c)
                                )
            if group:
                z = Lay.merge_group(group)

                if o.step in self.undo:
                    q, p = self.undo[o.step]
                    z1, d, image_layer, e = q
                    self.undo[o.step] = ((z, z1), d, image_layer, e), p
                else:
                    self.undo[o.step] = z, Lay.remove

    def _draw_cell_margin(self, o, is_one):
        """
        Select Cell-branch Margin for a cell.

        o: One
            Has model, r, c, d.

        is_one: bool
            Is true when there is only one rectangle to draw.
        """
        def select_margins():
            """
            Select a margin for a cell.

            Return: Selection
                state of image
            """
            if a:
                width, height = rect.size

                if is_one:
                    top1, bottom1, left1, right1 = self.model.canvas_margin

                    if i < 2:
                        width = size[0] - left1 - right1
                    else:
                        height = size[1] - top1 - bottom1

                width = max(1, width - left - right)
                height = max(1, height - top - bottom)
                x, y = rect.position
                x += (left, left, 0, width + left)[i]
                y += (0, height + top, top, top)[i]
                w = (width, width, a, a)[i]
                h = (a, a, height, height)[i]
                Sel.rect(j, x, y, w, h)

        cat = Hat.cat
        e = Form.get_form(o)
        j = cat.render.image
        size = Render.size()

        if o.model_type == md.TABLE:
            rect = self.model.get_merge_cell_rect(o.r, o.c)

        elif o.model_type == md.BOX:
            # Is a grid, but doesn't have merge-cell.
            rect = self.model.get_cell_rect(o.r, o.c)

        else:
            rect = self.model.rect

        q = top, bottom, left, right = Form.calc_margin(e, *rect.size)

        # cell index, 'o.r, o.c'
        for i in range(4):
            a = q[i]

            if i in (2, 3):
                # left, right
                is_draw = True

                if is_one and o.r > 0:
                    is_draw = False
                if is_draw:
                    select_margins()
            else:
                # top, bottom
                is_draw = True

                if is_one and o.c > 0:
                    is_draw = False
                if is_draw:
                    select_margins()

    def _draw_cell_margins(self, o, z):
        """
        Plan Cell-branch Margin.

        o: One
            Has step.

        z: layer
            to draw on
        """
        def is_draw_one_margin():
            """
            There is only one margin to draw if the cells have common bounds.
            """
            return not any(
                (
                    grid_d[ok.PER_CELL],
                    is_merge_cell,
                    d[ok.PER_CELL],
                    grid_d[ok.GRID_TYPE] != gr.CELL_COUNT
                )
            )

        cat = Hat.cat
        j = cat.render.image
        row, column = self.model.division
        model = self.model
        double_type = model.double_type
        is_merge_cell = model.is_merge_cell

        # Margin Preset dict, 'o.d'
        d = o.d

        grid_d = model.d
        is_one = is_draw_one_margin() if not double_type else False

        for r in range(row):
            for c in range(column):
                go = True

                if is_merge_cell:
                    if grid_d[ok.PER_CELL][r][c] == (-1, -1):
                        go = False
                if go:
                    if double_type:
                        go = Shape.is_allocated_cell(model, r, c)
                    if go:
                        o.r, o.c = r, c
                        self._draw_cell_margin(o, is_one)
        if Sel.is_sel(j):
            Sel.fill(z, fy.CELL_MARGIN_COLOR)

    def _draw_custom_cell_margin(self, o):
        """
        Plan Cell-branch Margin.

        o: One
            Has variables.

        z: layer
            to draw on
        """
        j = Hat.cat.render.image

        # layers for undo
        z = z1 = None

        pdb.gimp_selection_none(j)

        if self.plan_flags[ak.CELL_MARGIN]:
            self._draw_cell_margin(o, False)
            if Sel.is_sel(j):
                z = Lay.add(j, "Cell Margins", parent=self.model_group)
                z.opacity = 66.

                Sel.fill(z, fy.CELL_MARGIN_COLOR)

        if self.plan_flags[ak.CELL_SHAPE]:
            z1 = draw_custom_cell_shape(j, o)

        # valid layers, 'q'
        q = [i for i in (z, z1) if i]
        self.undo[o.step] = q, Lay.remove_layers

    def _draw_custom_cell_image_name(self, o):
        """
        Draw the image name for a cell image.

        o: One
            Has variables.
        """
        if self.plan_flags[ak.NAME]:
            n = self.model.get_image_name(0, 0)
            if n:
                z = draw_name(self.model_group, n, self.model.rect)
                z.name = "Image Name"

                if o.step in self.undo:
                    q, p = self.undo[o.step]
                    z1, d, image_layer, e = q
                    self.undo[o.step] = ((z, z1), d, image_layer, e), p
                else:
                    self.undo[o.step] = z, Lay.remove

    def _draw_grid(self, z):
        """
        Draw Model grid lines corresponding
        with the cell rectangle division.

        o: One
            Has variables.

        z: layer
            to draw on
        """
        cat = Hat.cat
        j = cat.render.image

        # fill flag, 'm'
        m = False

        model = self.model
        row, column = model.division
        w, h = Render.size()
        top, bottom, left, right = model.canvas_margin
        double_type = model.double_type

        # Init.
        a = Rect()
        y = 0

        # Grid lines divide the layer space.
        w1 = w - left - right
        x = left
        h1 = 1

        pdb.gimp_selection_none(j)

        # Draw rows.
        for r in range(0, row + 1):
            c = 0
            is_draw = True

            if double_type and r != row:
                c = not r % 2 if double_type == sh.SHIFT else r % 2
                c = min(column - 1, c)
                is_draw = Shape.is_allocated_cell(model, r, c)
            if is_draw:
                if r == row:
                    y += a.h

                else:
                    a = model.get_cell_rect(r, c)
                    y = a.y
                if 0 < y < h:
                    m = True
                    Sel.rect(j, x, y, w1, h1)

        w1, h1 = 1, h - top - bottom
        y = top

        # Draw columns.
        for c in range(0, column + 1):
            is_draw = True
            r = 0
            if double_type and c != column:
                r = not c % 2 if double_type == sh.SHIFT else c % 2
                r = min(row - 1, r)
                is_draw = Shape.is_allocated_cell(model, r, c)
            if is_draw:
                if c == column:
                    x += a.w

                else:
                    a = model.get_cell_rect(r, c)
                    x = a.x
                if 0 < x < w:
                    m = True
                    Sel.rect(j, x, y, w1, h1)
        if m:
            Sel.fill(z, fy.GRID_COLOR)

    def _draw_canvas_margins(self, _):
        """
        Draw Canvas Margin.

        _: One
            not used

        Return: layer or None
            with Canvas Margin
        """
        cat = Hat.cat
        j = cat.render.image
        z = None
        s = Render.size()
        q = top, bottom, left, right = self.model.canvas_margin

        pdb.gimp_selection_none(j)

        if any(q):
            for x, i in enumerate(q):
                if i:
                    if x in (0, 1):
                        # top, bottom
                        x1 = left
                        w = s[0] - left - right

                        if x == 0:
                            y = 0
                            h = top
                        else:
                            h = bottom
                            y = s[1] - h

                    else:
                        # left, right
                        h = s[1] - top - bottom
                        y = top

                        if x == 2:
                            x1 = 0
                            w = left
                        else:
                            w = right
                            x1 = s[0] - w
                    Sel.rect(j, x1, y, w, h)

            z = Lay.add(j, "Layer Margin", parent=self.model_group)
            z.opacity = 66.
            Sel.fill(z, fy.CANVAS_MARGIN_COLOR)
        return z

    def _draw_stack_cell_margin(self, o):
        """
        Draw a Stack Model's Cell-branch Margin.

        o: One
            Has variables.
        """
        j = Hat.cat.render.image
        q = []

        pdb.gimp_selection_none(j)

        if self.plan_flags[ak.CELL_MARGIN]:
            self._draw_cell_margin(o, False)
            if Sel.is_sel(j):
                z = Lay.add(j, "Cell Margins", parent=self.model_group)
                q += [z]
                z.opacity = 66.
                Sel.fill(z, fy.CELL_MARGIN_COLOR)

        if self.plan_flags[ak.CELL_SHAPE]:
            z = draw_custom_cell_shape(j, o)
            q += [z]
        self.undo[o.step] = q, Lay.remove_layers

    def _name_group(self, _):
        """
        Rename a Model folder with a 'Plan' extension.

        _: One
            not used
        """
        z = self.model_group
        z.name = self.model_name + " Plan"
        pdb.gimp_image_reorder_item(z.image, z, self.plan_group, 0)

    def _undo_plan_cell_margin(self, q):
        """
        Undo a Plan Cell Margin operation.

        q: tuple
            (model, layer)
        """
        self.model, z = q
        Lay.remove(z)

    def _undo_grid(self, q):
        """
        Undo a Model operation.

        q: tuple
            (model, layer)
        """
        self.model, z = q
        Lay.remove(z)

    def _undo_canvas_margins(self, q):
        """
        Undo a Canvas Margin operation.

        q: tuple
            (model, layer)
        """
        self.model, z = q
        Lay.remove(z)

    def _update_previous_steps(self, steps):
        """
        Update previous steps from another Plan op. The previous
        steps are screened. These steps go to the undo stage.

        steps: list
            for the next render
        """
        # Set the change status.
        e = Hat.cat.group_dict
        q = []
        is_change = False

        for i in self._previous_steps[::-1]:
            a = e[i]

            if not is_change and a.unseen:
                is_change = True

            if is_change:
                q += [i]
            else:
                if i not in steps:
                    q += [i]
        self._previous_steps = q[::-1]

    def delete(self):
        """Delete the Plan folder."""
        Lay.remove(self.plan_group)
        self.plan_group = None

    def delete_backdrop(self):
        """
        Delete the faux Backdrop Image layer.
        This is a Roller closing procedure.
        """
        Lay.remove(self.backdrop_layer)

    def do(self, steps, undo):
        """
        Perform a Plan View.

        steps: list
            A step is a key to an OptionGroup in 'cat.group_dict'.

        undo: list
            of steps to undo
        """
        cat = Hat.cat
        d = cat.group_dict
        e = self.non_canvas_d
        e1 = self.canvas_d
        e2 = self._extra_op_d
        is_start = True

        self.show()
        self.undo_steps(undo, steps)

        for step in steps:
            j = cat.render.image
            k = d[step].group_key
            d1 = self.get_preset_d(step)
            o = One(
                d=d1,
                model=self.model,
                image_index=self.image_index,
                k=k,
                model_type=self.model_type,
                model_name=self.model_name,
                parent=self.model_group,
                step=step,
                render_type=self.render_type
            )

            pdb.gimp_selection_none(j)

            if is_start:
                z = self.plan_group
                if z:
                    z.name = z.name.split(":")[0] + WORK
                    is_start = False

            if k in e:
                e[k](o)

            elif k in e1:
                e1[k](o)
            if k in e2:
                e2[k](o)

            # Flush the display will fail if ignored for too long.
            pdb.gimp_displays_flush()

        z = self.plan_group
        j = cat.render.image

        if z:
            z.name = z.name.split(":")[0] + READY
            Sel.item(z)
            j.active_layer = z

        elif self.backdrop_layer:
            j.active_layer = self.backdrop_layer
            Sel.item(self.backdrop_layer)

        else:
            pdb.gimp_selection_none(j)
        cat.del_short_term_sel()

    def draw_box_cell_shape(self, j, z, o):
        """
        Draw the cell shape for a Box Model.

        j: GIMP image
            Is render.

        z: layer or None
            to draw on

        o: One
            Has variables.

        Return: layer or None
            the layer with cell shape material
        """
        step = o.step
        d = o.d

        # Set the variables for Border functions.
        o.d = PresetDict.get_default(gk.CELL_BORDER)
        o.color = fy.CELL_SHAPE_COLOR
        o.d = PresetDict.get_default(gk.CELL_BORDER)
        o.d[ok.BORDER_WIDTH] = 2
        o.d[ok.BORDER_TYPE] = bo.COLOR
        o.d[ok.PER_CELL] = []

        # Set Face Type to use dict 'o.d'.
        o.d[ok.FACE_TYPE] = 1

        group = Lay.group(
            j,
            "Cell Shape",
            parent=self.model_group,
            offset=Lay.offset(z)
        )

        for face_x in range(3):
            o.step = step[:3] + (sk.CELL, sk.FACES[face_x])
            z = Border.do_box(o, True)
            if z:
                pdb.gimp_image_reorder_item(j, z, group, 0)

        z = Lay.merge_group(group)
        o.step = step
        o.d = d

        # Return the layer for the undo function.
        return z

    def draw_grid_cell_shape(self, j, z, o):
        """
        Draw a cell shape for a Grid-type Model.

        j: GIMP image
            Is render.

        z: layer or None
            to draw on

        o: One
            Has variables.

        Return: layer or None
            the layer with the cell shape(s)
        """
        # Margin Preset dict, 'o.d'
        d = o.d

        o.color = fy.CELL_SHAPE_COLOR
        q = Form.calc_margin(o.d, *Render.size())
        has_margin = True if any(q) or o.d[ok.PER_CELL] else False
        o.d = PresetDict.get_default(gk.CELL_BORDER)
        o.d[ok.BORDER_WIDTH] = 1

        if has_margin:
            row, column = o.model.division
            for r in range(row):
                for c in range(column):
                    go = True

                    if not Shape.is_allocated_cell(o.model, r, c):
                        go = False

                    if go and o.model.is_merge_cell:
                        if o.model.d[ok.PER_CELL][r][c] == (-1, -1):
                            go = False
                    if go:
                        if not z:
                            z = Lay.add(
                                j,
                                "Cell Shape",
                                parent=self.model_group
                            )

                        q = o.model.get_shape(r, c)

                        Sel.shape(j, q)
                        pdb.gimp_selection_shrink(j, 2)

                        sel = pdb.gimp_selection_save(j)

                        Sel.shape(j, q)
                        Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
                        Sel.fill(z, o.color)
                        pdb.gimp_image_remove_channel(j, sel)

        else:
            # Set the variables for Border functions.
            o.d = PresetDict.get_default(gk.CELL_BORDER)
            o.d[ok.BORDER_WIDTH] = 2
            o.d[ok.BORDER_TYPE] = bo.COLOR
            o.d[ok.PER_CELL] = []
            z = Border.do_table(o, True)
            z.name = "Cell Shape"

        o.d = d

        # Return the layer for undo function.
        return z

    def hide(self):
        """Hide the Plan group."""
        if self.plan_group:
            Lay.hide(self.plan_group)

    def get_offset(self):
        """
        Get the offset needed for Product groups.

        Return: int
            0 or 1
        """
        return 1 if self.plan_group else 0

    def prep(self, q):
        """
        Call to make a Plan View.

        q: list
            Plan steps

        is_preview: bool
            unused
        """
        self._update_previous_steps(q)

        q1 = q[:]

        # Update before the View.
        q = update_unseen_flag(q)

        q2 = self._previous_steps[:]

        # Reverse the order of the list.
        # Undo is the reverse of a View.
        self._previous_steps = q1[::-1]

        # Create the image.
        self.do(q, q2)

    def reset(self):
        """Reset the super-class Render variables."""
        self.image_index = deepcopy(dr.IMAGE_INDEX)
        self.undo = {}
        self.model = self.model_type = self.plan_group = \
            self.model_group = self.model_name = self.backdrop_layer = None

    def show(self):
        """Show the Plan group."""
        if self.plan_group:
            Lay.show(self.plan_group)
