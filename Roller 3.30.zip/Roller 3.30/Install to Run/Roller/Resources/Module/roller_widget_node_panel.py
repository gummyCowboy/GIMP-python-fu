#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Group as og
from roller_constant_key import Option as ok, Widget as wk
from roller_one import Hat
from roller_option_group import OptionGroup
from roller_option_preset import PerCell, Preset
from roller_option_preset_dict import PresetDict
from roller_widget_box import Cabinet, Eventful
from roller_widget_tree import Node
import gtk

# Are flags used to add Buttons to an option group.
BUTTON_KEY = (
    wk.HAS_EFFECT_PAIR,
    wk.HAS_VIEW_PAIR,
    wk.HAS_PREVIEW,
    wk.HAS_RANDOM
)


# Is a new style class reference for Python 2.7, 'object'.
class NodePanel(object):
    """Has functions used for Node navigation."""

    def __init__(self, d, a):
        """
        Use to make navigation columns.

        d: dict
            to initialize Widgets

        a: MainDict
            with Node group definition
        """
        # global dict for adding an option group, 'self.d'
        self.d = d

        self._main_d = a

        # A Port has a pane, a background VBox. If the pane has navigation
        # columns, or Cabinets, then they are stored in 'self.cabinet'.
        # list of Cabinet objects, 'self.cabinet'
        self.cabinet = []

        # Is an gtk.Hbox with stacked Nodes from left to right.
        self.nav_box = None

    def _draw_per_cell(self, d, group_key):
        """
        Draw an option group for the Per Cell type. Per Cell type groups
        have an option group that applies to all cells in a grid, a form,
        and a Per Cell option that applies to cells individually.

        d: dict
            Has group options.

        group_key: string
            identifier
        """
        g = d[wk.CONTAINER]
        d[wk.HAS_PRESET] = True
        vbox = d[wk.CONTAINER] = gtk.VBox()
        form_step = d[wk.STEP]

        # the form Group key, 'k'
        k = d[wk.GROUP_KEY] = og.FORM_GROUP_KEY[group_key]
        d[wk.KEYS] = PresetDict.get_keys(k)

        if self._main_d.group_def[group_key][wk.FORM_HAS_PREVIEW]:
            d[wk.HAS_VIEW_PAIR] = True

        d[wk.BOTTOM_PAD] = 0
        d[wk.GROUP_TYPE] = Preset

        # Widget dict, 'd1'
        d1 = OptionGroup.draw_group(**d)

        # Per Cell
        form_group = d[wk.FORM_GROUP] = Hat.cat.group_dict[form_step]
        d[wk.GROUP_KEY] = group_key
        d[wk.GROUP_TYPE] = PerCell
        vbox1 = d[wk.CONTAINER] = gtk.VBox()
        d[wk.KEYS] = ok.PER_CELL,
        d[wk.TOP_PAD] = 1
        d[wk.STEP] = d[wk.STEP][:-1] + \
            (group_key.split(",")[0] + ", Per Cell",)

        for i in (wk.BOTTOM_PAD, wk.HAS_VIEW_PAIR):
            if i in d:
                d.pop(i)

        d2 = OptionGroup.draw_group(**d)

        # PerCellGroup, 'g1'
        g1 = form_group.per_cell_group = d2[ok.PER_CELL]
        g1.box = vbox1
        g.add(vbox)
        g.add(vbox1)
        if ok.GRID_TYPE in d1:
            d1[ok.GRID_TYPE].group.per_cell = g1

    def create_node(self, d, group_key, step, node_key=None):
        """
        Create a Node option group. Is recursive with
        'self.draw_options'. The option group becomes visible
        when its Node item, a branch, is selected, and a signal
        is sent to the Node's 'on_list_change' function.

        d: dict
            Has Node options.

        group_key: string
            identifier

        step: tuple
            of Nodes to an option group
        """
        if node_key is None:
            node_key = group_key

        column_number = len(step) - 1
        labels = self._main_d.group_def[node_key][wk.LABELS]
        d[wk.LABELS] = [i.split(",")[0] for i in labels]
        d[wk.COLOR] = Cabinet.colors[column_number]
        d[wk.GROUP_TYPE] = Node
        d[wk.NODE_KEY] = node_key
        node = Node(**d)
        node.group = d[wk.GROUP] = OptionGroup(**d)
        node.group.d = {node_key: node}
        node.group.node = node
        for x, i in enumerate(labels):
            self.draw_options(
                node.get_groupie_with_label(i),
                i,
                node_key,
                step
            )

    def draw_options(self, g, group_key, node_key, step):
        """
        Draw the options. Is recursive with 'self.create_node'.

        g: container
            container for options

        group_key: string
            Group key

        node_key: string or int
            Node identifier

        step: tuple
            step
            (Node item,)
        """
        def _add_column():
            if len(self.cabinet) <= column_number:
                _cabinet = Cabinet(column_number)
                _box = Eventful(Cabinet.colors[column_number])

                self.cabinet.append(_cabinet)
                _box.add(_cabinet)
                self.nav_box.add(_box)

                # The default behavior of the 'add' function
                # doesn't guarantee that they are visible.
                _cabinet.show()
                _box.show()

        def _draw_option():
            """Draw an option group."""
            e[wk.KEYS] = a.get_keys(group_key)
            return OptionGroup.draw_group(**e)

        d = self._main_d.group_def
        column_number = len(step)
        step += group_key.split(",")[0],

        if group_key in d:
            _add_column()

            # group definition dict, 'd'
            d = d[group_key]

            # group argument dict, 'e'
            e = {
                wk.COLOR: Cabinet.colors[column_number],
                wk.CONTAINER: g,
                wk.GROUP_KEY: group_key,
                wk.NODE_KEY: node_key,
                wk.STEP: step
            }

            # group type, 'a'
            a = e[wk.GROUP_TYPE] = d[wk.WIDGET]

            e.update(self.d)

            if a == Node:
                self.create_node(e, group_key, step)

            elif a == PerCell:
                self._draw_per_cell(e, group_key)
            else:
                # Synchronize ButtonPair.
                for _i in BUTTON_KEY:
                    if _i in d:
                        e[_i] = True
                        break

                if wk.HAS_PRESET in d:
                    e[wk.HAS_PRESET] = True
                _draw_option()
