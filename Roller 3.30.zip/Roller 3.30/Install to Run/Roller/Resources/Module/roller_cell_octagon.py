#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_one import Rect
from roller_one_extract import Shape


class GridOctagon:
    """
    Calculate the coordinates and the size of cells.
    The cells are octagon shaped.
    """

    def __init__(self, o):
        """
        Calculate cell size and octagon shape.

        o: One
            Has init values.
        """
        def _calc_align_octagon_intersect():
            """
            Calculate the intersect coordinates for an octagon.
            """
            _x = x
            _y = y

            for _ in range(column):
                q_x.append(_x)
                _x += w
            for _ in range(row):
                q_y.append(_y)
                _y += h

        def _calc_octagon_intersect():
            """
            Calculate the intersect coordinates for an octagon.
            """
            _x = x
            _y = y

            for _ in range(column):
                q_x.append(_x)
                _x += w

            for _ in range(row):
                q_y.append(_y)
                _y += h

        row, column = o.r, o.c
        table = o.model.table
        s = o.layer_space
        x, y = o.offset

        # intersect points
        q_x = []
        q_y = []

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w, h = min(s[0], o.column_width / 1.), min(s[1], o.row_height / 1.)

            s1 = w * column, h * row
            w, h = w / 1., h / 1.
            x, y = Shape.calc_pin_offset(
                o.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        elif o.grid_type == gr.SHAPE_COUNT:
            w = s[0] // column
            h = s[1] // row
            w = min(w, h)
            s1 = w * column, w * row
            w, h = w, w
            x, y = Shape.calc_pin_offset(
                o.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            w = s[0] / 1. / column
            h = s[1] / 1. / row

        offset = x, y

        if o.model.cell_shape in (sh.OCTAGON_SHEAR, sh.OCTAGON_REGULAR):
            is_align = False
            _calc_octagon_intersect()
            q = Shape.calc_octagon_offset(w, h)

        else:
            # side-to-side octagon
            is_align = True
            _calc_align_octagon_intersect()
            q = Shape.calc_octagon_side_to_side_offset(w, h)

        s1 = s[0] + offset[0], s[1] + offset[1]

        # Compose the points.
        for r in range(row):
            for c in range(column):
                x, y = position = int(q_x[c]), int(q_y[r])
                size = int(w), int(h)

                if size[0] > s1[0] or size[1] > s1[1]:
                    size = position = 0, 0

                # Cell, 'a'
                a = table[r][c]

                # Is the cell rectangle before margins, 'cell'.
                a.cell = Rect(position[0], position[1], size[0], size[1])
                if size[0]:
                    if is_align:
                        q1 = Shape.calc_octagon_side_to_side_shape(
                            x, y,
                            w, h,
                            q
                        )

                    else:
                        q1 = Shape.calc_octagon_shape(x, y, w, h, q)
                    a.shape = a.plaque = q1
