#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Widget as fw
from roller_constant_key import Widget as wk
from roller_one import Base, Hat
import gtk

NO_BUTTONS = None


class Window:
    """Is a GTK Window or GTK Dialog."""
    is_dialog = False

    def __init__(self, d):
        """
        Create a window.

        The new Window can be a normal Window with it's own event
        handler, or be a Dialog. There can only be one open Window
        with an event handler at a time.

        d: dict
            Has init variables.
        """
        self.is_dialog = Window.is_dialog

        # Is the Window's key for the Window position dict, 'self.pose_key'.
        self.pose_key = d[wk.WINDOW_KEY]

        if Window.is_dialog:
            g = self.win = gtk.Dialog(
                d[wk.WINDOW_TITLE],
                d[wk.WIN],
                gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
                NO_BUTTONS
            )

        else:
            g = self.win = d[wk.WIN] = gtk.Window()
            self.switch_box = gtk.VBox()

            g.add(self.switch_box)
            g.set_position(gtk.WIN_POS_CENTER)

        a = self.win.allocation
        w, h = Window.get_screen_res()

        if self.pose_key in Hat.cat.window_pose:
            # Make sure the position isn't off screen.
            x, y = Hat.cat.window_pose[self.pose_key]
            x = Base.seal(x, 0, w - a.width)
            y = Base.seal(y, 0, h - a.height - fw.SCROLL_SPAN)

        else:
            w1, h1 = max(100, a.width), max(100, a.height)
            x, y = w // 2 - w1 // 2, h // 2 - h1 // 2

        x, y = max(0, x), max(0, y)

        g.move(x, y)
        self.win.connect('delete_event', self.close)
        Window.is_dialog = True

    def cancel(self, *_):
        """
        Close the Window.

        Return: true
            GTK, it is done.
        """
        return self.close()

    def accept(self, d):
        """
        Accept the options. Is part of the satellite Window template:
            'self.safe', a Preset dict

        d: dict
            of options

        Return: true
            GTK, it is done.
        """
        if hasattr(self, 'safe'):
            self.safe.set_value(d)
        return self.close()

    def close(self, *_):
        """
        Close the window. Possibly exit the main loop.

        Return: true
            Tell GTK that the closing operation is handled.
        """
        g = self.win
        x, y = g.get_position()

        if min(x, y) > -1:
            Hat.cat.window_pose[self.pose_key] = x, y

        if self.is_dialog:
            g.hide()
            g.response(0)

        else:
            g.destroy()
            gtk.main_quit()

            # Set to None, so that WindowMain can determine
            # if its window is actually closed.
            self.win = None

        # Let GTK know that a key-type event has been handled.
        return True

    def get_remaining_dim(self, w, h):
        """
        Use to keep the Window from drawing off screen.
        Return the width and height of the screen space
        to the right and bottom of the Window.
        """
        w1, h1 = Window.get_screen_res()

        if self.pose_key in Hat.cat.window_pose:
            x, y = Hat.cat.window_pose[self.pose_key]

        else:
            x = w1 // 2
            y = h1 // 2

        x = Base.seal(x, x + fw.SCROLL_SPAN, w1 - 200)
        y = Base.seal(y, y + fw.SCROLL_SPAN, h1 - 200)
        return min(w, w1 - x), min(h, h1 - y)

    @staticmethod
    def get_screen_res():
        """
        Return: tuple
             width, height
             of the screen's dimension
        """
        return gtk.gdk.screen_width(), gtk.gdk.screen_height()

    def change_size(self):
        """
        Resize a Window, but the allocation isn't correct so the process
        only works on the second resize attempt with the old Window size.
        In other words, the process is one-step behind the current state.
        """
        if self.win:
            self.win.resize(1, 1)

            w, h = Window.get_screen_res()
            a = self.win.allocation
            q = x, y = self.win.get_position()
            x = Base.seal(x, 0, w - a.width)
            y = Base.seal(y, 0, h - a.height - fw.SCROLL_SPAN)
            if (x, y) != q:
                # GTK has an invalid state where the position is negative.
                if min(*q) > -1:
                    self.win.move(x, y)
        return True

    def resize(self):
        """Add a change size signal to the signal filter."""
        Hat.dog.signal_filter.add(fw.WINDOW_SIZE_CHANGE, self)
