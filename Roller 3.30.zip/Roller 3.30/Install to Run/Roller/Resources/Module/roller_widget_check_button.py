#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_for import Widget as fw
from roller_constant_key import Widget as wk
from roller_widget import Widget
from roller_widget_row import Row
import gtk


class CheckButton(Widget):
    """
    Is a custom GTK CheckButton. Is attached to its own GTK Alignment.
    """
    # Need for OptionGroup change subscription.
    change_signal = 'clicked'

    def __init__(self, **d):
        """
        Create a CheckButton.

        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.CheckButton(label=d[wk.TEXT])

        Widget.__init__(self, g, **d)
        self.add(g)

        # Do the connections last.
        g.connect('clicked', self.callback)
        g.connect('activate', self.callback)

    def get_value(self):
        """
        Get the value of the CheckButton. Is part of the Widget template.

        Return: int
            of CheckButton checked state
        """
        return int(self.widget.get_active())

    def set_value(self, a):
        """
        Set the CheckButton checked state. Is part of the Widget template.

        a: int
        """
        self.widget.set_active(a)


class CheckRow(Row):
    """Is a Row with two CheckButtons."""

    def __init__(self, **d):
        """
        Create an HBox with two CheckButtons. The set and
        get value is a tuple of integers from 0 to 1.

        d: dict
            Has init values.
        """
        self.buttons = None

        # Create a relay for the Button change-response.
        self._callback = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self.on_change

        Row.__init__(self, **d)

        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        q = d[wk.LABELS]
        d[wk.KEY] = d[wk.TEXT] = q[0]
        d[wk.ALIGN] = 0, 0, 1, 0
        tips = d[wk.TIPS] if wk.TIPS in d else None

        if tips:
            d[wk.TOOLTIP] = tips[0]

        g = CheckButton(**d)
        d[wk.KEY] = d[wk.TEXT] = q[1]

        if tips:
            d[wk.TOOLTIP] = tips[1]

        g1 = CheckButton(**d)
        self.buttons = g, g1
        for i in (g, g1):
            self.hbox.pack_start(i, expand=True)
            same_size.add_widget(i.widget)

    def on_change(self, _):
        """
        Respond to change in one of the CheckButtons.

        _: CheckButton
            Could be either one.
            no use
        """
        if self.buttons:
            self._callback(self)
            self.emit(fw.UI_CHANGE, self.group)

    def get_value(self):
        """
        Get the values of the two CheckButtons.

        Return: tuple
            (left CheckButton value, right CheckButton value)
        """
        # Is called during the init.
        if self.buttons:
            return (
                self.buttons[0].get_value(),
                self.buttons[1].get_value()
            )
        return 0, 0

    def randomize(self):
        """
        Randomize the values in the two CheckButtons.
        Is an Option template function.
        """
        for i in self.buttons:
            i.set_value(randint(0, 1))

    def set_value(self, a):
        """
        Set the value of the CheckButtons. Is a Widget template function.

        a: tuple
            (left CheckButton value, right CheckButton value)
        """
        if self.buttons:
            for i in range(2):
                self.buttons[i].set_value(a[i])
