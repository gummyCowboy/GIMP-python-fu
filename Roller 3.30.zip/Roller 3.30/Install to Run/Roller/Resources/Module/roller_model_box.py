#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import sqrt
from roller_constant_for import Shape as sh
from roller_one import Rect


class Box:
    """
    Has factored functions from the vertical and horizontal Box Models.

    BoxCell Attribute Descriptions
    corner: tuple
        Are the corner points of a Box Face in a transform-required order.

    poly: tuple
        Are the points of a Box Face for a Face drawing operation.

    face_rect: tuple
        Are bounding rectangles in a Rect object
        of a Box Face's 'poly' points.

    image_size: tuple
        Are the size of the image needed to fill
        a Box Face before it is transformed.

    mold: tuple
        Are rectangles in a Rect object of the image after it
        is placed on a pre-transform-sized 'face_rect' layer.
    """

    @staticmethod
    def get_face_function(n):
        """
        Determine the proper function for a particular Box Type.

        n: string
            Box Type

        Return: function
            for setting a Box Face's polygons
        """
        return (
            Box.set_top,
            Box.set_bottom,
            Box.set_left,
            Box.set_right
        )[sh.BOX_TYPE.index(n)]

    @staticmethod
    def set_bottom(a, q, _, y):
        """
        Set the 'corner', 'poly', and 'face_rect' attributes
        of Box cell Faces for the Bottom Box Type.

        a: BoxCell
            cell in its cell table

        q: tuple
            hexagon points

        _, y: numeric
            center of polygon
        """
        # at the top of the hexagon, 'x'
        x = q[2]

        a.corner = (
            (q[0], q[1], q[2], q[3], q[10], q[11], x, y),
            (q[2], q[3], q[4], q[5], x, y, q[6], q[7]),
            (q[10], q[11], x, y, q[8], q[9], q[6], q[7])
        )
        a.poly = (
            (q[0], q[1], q[2], q[3], x, y, q[10], q[11]),
            (q[2], q[3], q[4], q[5], q[6], q[7], x, y),
            (q[10], q[11], x, y, q[6], q[7], q[8], q[9])
        )
        a.face_rect = (
            Rect(q[0], q[3], q[2] - q[0], q[9] - q[1]),
            Rect(q[2], q[3], q[4] - q[2], q[9] - q[1]),
            Rect(q[0], y, q[6] - q[0], q[9] - y)
        )
        x1 = (q[2] - q[0])**2
        x2 = (q[2] - q[4])**2
        x3 = (q[10] - x)**2
        a.image_size = (
            (
                max(1., round(sqrt(x1 + (q[3] - q[1])**2))),
                max(1., round(sqrt(x1 + (q[1] - q[11])**2)))
            ),
            (
                max(1., round(sqrt(x2 + (q[3] - q[5])**2))),
                max(1., round(sqrt(x2 + (q[3] - y)**2)))
            ),
            (
                max(1., round(sqrt(x3 + (q[7] - y)**2))),
                max(1., round(sqrt(x3 + (q[11] - y)**2)))
            )
        )

    @staticmethod
    def set_left(a, q, x, _):
        """
        Set the 'corner', 'poly', and 'face_rect' attributes
        of the Box cell Faces for the Left Box Type.

        a: BoxCell
            cell in its cell table

        q: tuple
            truncated hexagon points

        x, _: numeric
            center of the hexagon
        """
        # on the left-size of the hexagon, 'y'
        y = q[1]

        a.corner = (
            (q[2], q[3], x, y, q[0], q[1], q[10], q[11]),
            (q[2], q[3], q[4], q[5], x, y, q[6], q[7]),
            (x, y, q[6], q[7], q[10], q[11], q[8], q[9])
        )
        a.poly = (
            (q[0], q[1], q[2], q[3], x, y, q[10], q[11]),
            (q[2], q[3], q[4], q[5], q[6], q[7], x, y),
            (x, y, q[6], q[7], q[8], q[9], q[10], q[11])
        )
        a.face_rect = (
            Rect(q[0], q[3], x - q[0], q[11] - q[3]),
            Rect(q[2], q[3], q[6] - q[2], q[7] - q[3]),
            Rect(q[2], q[1], q[6] - q[2], q[11] - q[1])
        )
        x1 = (q[2] - q[0])**2
        x2 = (q[2] - q[4])**2
        x3 = (q[6] - x)**2
        a.image_size = (
            (
                max(1., round(sqrt(x1 + (q[3] - q[1])**2))),
                max(1., round(sqrt(x1 + (q[1] - q[11])**2)))
            ),
            (
                max(1., round(sqrt(x2 + (q[3] - q[5])**2))),
                max(1., round(sqrt(x2 + (q[3] - y)**2)))
            ),
            (
                max(1., round(sqrt(x3 + (q[7] - y)**2))),
                max(1., round(sqrt(x3 + (q[11] - y)**2)))
            )
        )

    @staticmethod
    def set_right(a, q, x, _):
        """
        Set the 'corner', 'poly', and 'face_rect' attributes
        of the Box cell Faces for the Right Box Type.

        a: BoxCell
            cell in its cell table

        q: tuple
            truncated hexagon points

        x, _: numeric
            center of the hexagon
        """
        # on the left-size of the hexagon, 'y'
        y = q[1]

        a.corner = (
            (q[2], q[3], q[4], q[5], q[0], q[1], x, y),
            (q[4], q[5], q[6], q[7], x, y, q[8], q[9]),
            (q[0], q[1], x, y, q[10], q[11], q[8], q[9])
        )
        a.poly = (
            (q[0], q[1], q[2], q[3], q[4], q[5], x, y),
            (x, y, q[4], q[5], q[6], q[7], q[8], q[9]),
            (q[0], q[1], x, y, q[8], q[9], q[10], q[11])
        )
        a.face_rect = (
            Rect(q[0], q[3], q[4] - q[0], q[1] - q[3]),
            Rect(x, q[3], q[6] - x, q[9] - q[5]),
            Rect(q[0], q[1], q[4] - q[0], q[11] - q[1])
        )
        x1 = (q[2] - q[4])**2
        x2 = (q[4] - q[6])**2
        x3 = (q[0] - x)**2
        a.image_size = (
            (
                max(1., round(sqrt(x1 + (q[3] - q[5])**2))),
                max(1., round(sqrt(x1 + (q[1] - q[3])**2)))
            ),
            (
                max(1., round(sqrt(x2 + (q[5] - q[7])**2))),
                max(1., round(sqrt(x2 + (q[5] - y)**2)))
            ),
            (
                max(1., round(sqrt(x3 + (q[1] - y)**2))),
                max(1., round(sqrt(x3 + (q[1] - q[11])**2)))
            )
        )

    @staticmethod
    def set_top(a, q, _, y):
        """
        Set the 'corner', 'poly', and 'face_rect' attributes
        of the Box cell Faces for the Top Box Type.

        a: BoxCell
            Has attributes 'poly' and 'face_rect'.

            poly: Box Face's hexagon points
            face_rect: bounds of the Box Face
            image_size: size of an image to fit the Box Face

        q: iterable
            of points (x, y pairs)
            Box hexagon

        _, y: float
            center point of the hexagon
        """
        # at the top of the hexagon, 'x'
        x = q[2]

        # Order the points for the Face transform which is
        # topleft, top-right, bottom-left, bottom-right
        # of the image.
        a.corner = (
            (q[2], q[3], q[4], q[5], q[0], q[1], x, y),
            (q[0], q[1], x, y, q[10], q[11], q[8], q[9]),
            (x, y, q[4], q[5], q[8], q[9], q[6], q[7])
        )
        a.poly = (
            (q[0], q[1], q[2], q[3], q[4], q[5], x, y),
            (q[0], q[1], x, y, q[8], q[9], q[10], q[11]),
            (x, y, q[4], q[5], q[6], q[7], q[8], q[9])
        )
        a.face_rect = (
            Rect(q[0], q[3], q[4] - q[0], y - q[3]),
            Rect(q[0], q[1], q[2] - q[0], q[9] - q[1]),
            Rect(q[2], q[5], q[4] - q[8], q[9] - q[5])
        )
        x1 = (q[2] - q[0])**2
        x2 = (q[2] - q[0])**2
        x3 = (q[4] - x)**2
        a.image_size = (
            (
                max(1., round(sqrt(x1 + (q[3] - q[1])**2))),
                max(1., round(sqrt(x1 + (q[5] - q[3])**2)))
            ),
            (
                max(1., round(sqrt(x2 + (y - q[1])**2))),
                max(1., round(sqrt(x2 + (q[11] - q[1])**2)))
            ),
            (
                max(1., round(sqrt(x3 + (q[5] - y)**2))),
                max(1., round(sqrt(x3 + (q[9] - y)**2)))
            )
        )
