#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_for import Widget as fw
from roller_constant_key import Widget as wk
from roller_one import Base
from roller_widget_button import ColorButton
from roller_widget_row import Row


class Rainbow(Row):
    """Is an GTK HBox with two or more ColorButtons."""

    def __init__(self, **d):
        """
        Create an HBox with some ColorButtons.

        d: dict
            Has init values.
        """
        Row.__init__(self, **d)

        # Create a relay for the sub-Widgets.
        self._callback = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self.on_change

        self._has_alpha = d[wk.HAS_ALPHA] if wk.HAS_ALPHA in d else False
        d[wk.ALIGN] = 0, 0, 1, 0

        # list of ColorButtons, 'q'
        q = self.buttons = []

        for i in range(d[wk.BUTTON_COUNT]):
            q += [ColorButton(**d)]
        for i in q:
            self.hbox.pack_start(i, expand=True)

    def get_value(self):
        """
        Collect the values of the ColorButtons.

        Return: list
            of color values
        """
        q = []

        for i in self.buttons:
            q += [i.get_value()]
        return q

    def on_change(self, _):
        """
        Respond to change in one of the ColorButtons.

        _: ColorButton
            no use
        """
        self._callback(self)
        self.emit(fw.UI_CHANGE, self.group)

    def randomize(self):
        """
        Randomize the values of the ColorButtons.
        Is an Option template function.
        """
        for i in self.buttons:
            # RGB, 'q'
            q = Base.rnd_col()

            if self._has_alpha:
                # RGBA, 'q'
                q += (randint(0, 255),)
            i.set_value(q)

    def set_value(self, q):
        """
        Set the colors of the ColorButtons.
        Is a Widget template function.

        q: iterable
            Has color values.
        """
        for x, i in enumerate(q):
            self.buttons[x].set_value(i)

    def update_visibility(self, color_count):
        """
        The number of visible ColorButtons is dependent on the color count.

        color_count: int
            the number of ColorButtons to show
        """
        for x, i in enumerate(self.buttons):
            i.show() if x < color_count else i.hide()
