#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice, randint
from roller_constant_for import (
    BackdropStyle as bs,
    Border as bo,
    Bump as fb,
    Fill as fl,
    Frame as fo,
    Fringe as ng,
    Gradient as fg,
    Grid as gr,
    Image as fi,
    Justification as ju,
    Mask as ms,
    Model as mo,
    Plaque as aq,
    Resize as fz,
    Tooltip as tt,
    Shape as sh,
    Widget as fw,
    MAX_SIZE
)
from roller_constant_key import (
    BackdropStyle as by,
    Effect as ek,
    Option as ok,
    Widget as wk
)
from roller_model_image import Image
from roller_effect import ImageEffect
from roller_one import Base, Comm, Hat, Mode
from roller_one_tip import Tip
from roller_widget_button import (
    ColorButton,
    FileButton,
    FolderButton,
    OptionButton
)
from roller_widget_check_button import CheckButton, CheckRow
from roller_widget_combo import ComboBox
from roller_widget_entry import Entry
from roller_widget_label import BoxGridLabel, GridLabel, Label
from roller_widget_number_pair import CanvasPair, RectPair, RenderPair
from roller_widget_plan import GroupPlan
from roller_widget_per_cell import PerCellGroup
from roller_widget_radio import RadioColumn, RadioRow
from roller_widget_rainbow import Rainbow
from roller_widget_slider import Slider
from roller_widget_tree import OptionList, ModelList
from roller_window_brush import RWBrushChoice
from roller_window_bump_choice import RWBumpChoice
from roller_window_choice import RWChoice
from roller_window_image_choice import RWImageChoice
from roller_window_light import RWLight
from roller_window_margin import RWMargin
from roller_window_plaque_mask import RWPlaqueMask
from roller_window_resize import RWResize
from roller_window_shadow import RWShadow
from roller_window_shift import RWShift
from roller_window_stripe import RWStripe
import glob
import os
import sys

BLUR = {
    wk.RANDOM: (3., 20.),
    wk.LIMIT: (1., 100.),
    wk.PRECISION: 1,
    wk.WIDGET: Slider
}
CHECK = {wk.WIDGET: CheckButton}

# The clipboard pattern size has a maximum span of 1024.
CLIP = {
    wk.LIMIT: (6, 1024),
    wk.RANDOM: (108, 1024),
    wk.WIDGET: Slider
}
FIXED = {wk.LIMIT: (0, MAX_SIZE), wk.WIDGET: Slider}
FIXED_SIZE = {wk.LIMIT: (1, MAX_SIZE), wk.WIDGET: Slider}
GRID_COUNT = {wk.LIMIT: (1, 100), wk.WIDGET: Slider}
KEYS = (
    wk.AXIS,
    wk.BUTTON_COUNT,
    wk.CHARS,
    wk.CHOICE_WINDOW,
    wk.GET_OPTION,
    wk.HAS_ALPHA,
    wk.LABELS,
    wk.LIMIT,
    wk.PRECISION,
    wk.LIST,
    wk.LISTEN,
    wk.NAME,
    wk.SENDER,
    wk.TEXT,
    wk.TIPS,
    wk.TOOLTIP,
    wk.TIP_TYPE
)
MARGIN_X = {
    wk.AXIS: 'x',
    wk.LIMIT: (0, MAX_SIZE),
    wk.WIDGET: RenderPair
}
MARGIN_Y = {
    wk.AXIS: 'y',
    wk.LIMIT: (0, MAX_SIZE),
    wk.WIDGET: RenderPair
}
NET_LINE = {wk.LIMIT: (1, 10000), wk.WIDGET: Slider}
RENDER = {
    wk.LIMIT: (1, MAX_SIZE),
    wk.SENDER: fw.RENDER_SIZE_CHANGE,
    wk.WIDGET: Slider
}
TEXT = {wk.CHARS: 15, wk.WIDGET: Entry}


def get_brush_list():
    """
    Return: list
        of available brush
    """
    return Hat.cat.brush_list


def get_filler_width(key):
    """
    Generate a random filler-space width.

    key: string
        option key
        an effect key

    Return: int
        a random value for a filler width
    """
    a = Option.filler[key]
    return randint(a[0], a[1])


def get_frame_width(key):
    """
    Generate a random value for a frame width.

    key: string
        effect-type

    Return: int
        frame width
    """
    w, h = Option.width[key]
    return randint(w, h)


def get_gradient_list():
    """
    Return: list
        of available gradient
    """
    return Hat.cat.gradient_list


def get_pattern_list():
    """
    Return: list
        of available pattern
    """
    return Hat.cat.pattern_list


def get_image_names():
    """
    Retrieve the image name list that was
    composed during Roller's initialization.

    Return: list
        of GIMP-opened image name
    """
    return Image.image_names


def get_random_brush():
    """
    Return: string
        a randomly chosen brush
    """
    return choice(Hat.cat.brush_list)


def get_random_gradient():
    """
    Return: string
        a randomly chosen gradient
    """
    return choice(Hat.cat.gradient_list)


def get_random_pattern():
    """
    Return: string
        a randomly chosen pattern
    """
    return choice(Hat.cat.pattern_list)


def get_row_column_limited(key):
    """
    Generate a randomized integer for a row or column value.

    key: string
        option key

    Return: int
        of row or column
    """
    return randint(*Option.row_column_limit[key])


class Option:
    """Use to limit a valid range and a random range for option values."""
    # for Image Effect
    # Limit the width value, (low, high),
    # used as input for a random width amount generator.
    width = {
        ek.BORDER_LINE: (1, 15),
        ek.BRUSH_PUNCH: (1, 15),
        ek.CAMO_PLANET: (1, 100),
        ek.CERAMIC_CHIP: (1, 15),
        ek.CIRCLE_PUNCH: (1, 15),
        ek.CLEAR_FRAME: (1, 65),
        ek.COLOR_PIPE: (1, 65),
        ek.COLOR_BOARD: (1, 65),
        ek.CRUMBLE_SHELL: (1, 50),
        ek.CUTOUT_PLATE: (1, 100),
        ek.GLASS_REVEAL: (1, 100),
        ek.GRADIENT_LEVEL: (1, 100),
        ek.HOT_GLUE: (3, 10),
        ek.LINE_FASHION: (1, 15),
        ek.MAZE_MIRROR: (1, 15),
        ek.METALLIC_PROFILE: (1, 65),
        ek.PAINT_RUSH: (1, 100),
        ek.RAD_WAVE: (1, 20),
        ek.RAISED_MAZE: (1, 15),
        ek.SHAPE_BURST: (1, 100),
        ek.SQUARE_CUT: (1, 15),
        ek.SQUARE_PUNCH: (1, 15),
        ek.STAINED_GLASS: (1, 15),
        ek.STRETCH_TRAY: (1, 6),
        ek.WIRE_FENCE: (1, 15)
    }

    # Limit the filler value, (low, high),
    # Use as an input for a random filler amount generator.
    filler = {
        by.RECT_PATTERN: (100, 500),
        ek.CERAMIC_CHIP: (20, 100),
        ek.CIRCLE_PUNCH: (20, 100),
        ek.LINE_FASHION: (20, 100),
        ek.SQUARE_CUT: (20, 100),
        ek.SQUARE_PUNCH: (20, 100),
        ek.STAINED_GLASS: (20, 100),
        ek.STRETCH_TRAY: (20, 100),
        ek.WIRE_FENCE: (20, 100)
    }

    # Limit the row or column value, between low and high,
    # Use as an input for a random row and column amount generator.
    row_column_limit = {
        by.COLOR_GRID: (1, 100),
        by.CORE_DESIGN: (1, 100),
        by.DARK_FORT: (5, 10),
        by.LOST_MAZE: (4, 100),
        by.MAZE_BLEND: (4, 100),
        by.MYSTERY_GRATE: (1, 130),
        by.SPACETIME_FABRIC: (1, 25),
        by.SPIRAL_CHANNEL: (1, 4),
        ek.SQUARE_CUT: (4, 100),
        ek.MAZE_MIRROR: (1, 40),
        ek.RAD_WAVE: (1, 25),
        ek.RAISED_MAZE: (4, 100),
    }
    BACKDROP_BLUR = {
        wk.RANDOM: (0, 50),
        wk.LIMIT: (0, 500),
        wk.WIDGET: Slider
    }

    def __init__(self):
        """Use a dictionary to define a UI option."""
        self._frame_list = ["None"]
        self._frame_dict = {}
        a = wk
        self.options = {
            ok.ADDING_SHIFT_H: {
                a.TOOLTIP: Tip.ADDING_SHIFT_H,
                a.WIDGET: CheckButton
            },
            ok.ADDING_SHIFT_ROTATE: {
                a.TOOLTIP: Tip.ADDING_SHIFT_ROTATE,
                a.WIDGET: CheckButton
            },
            ok.ADDING_SHIFT_W: {
                a.TOOLTIP: Tip.ADDING_SHIFT_W,
                a.WIDGET: CheckButton
            },
            ok.ADDING_SHIFT_X: {
                a.TOOLTIP: Tip.ADDING_SHIFT_X,
                a.WIDGET: CheckButton
            },
            ok.ADDING_SHIFT_Y: {
                a.TOOLTIP: Tip.ADDING_SHIFT_Y,
                a.WIDGET: CheckButton
            },
            ok.AMPLITUDE: {
                a.LIMIT: (2, 30),
                a.RANDOM: (2, 30),
                a.TOOLTIP: Tip.JAG_AMPLITUDE,
                a.WIDGET: Slider
            },
            ok.ANGLE_JITTER: {
                a.LIMIT: (.0, 180.),
                a.PRECISION: 1,
                a.RANDOM: (.0, 180.),
                a.WIDGET: Slider
            },
            ok.ANGLE_SHIFT: {
                a.LIMIT: (0, 180),
                a.RANDOM: (0, 10),
                a.WIDGET: Slider
            },
            ok.AS_LAYERS: {a.TOOLTIP: Tip.IMAGE_LAYERS, a.WIDGET: CheckButton},
            ok.AUTOCROP: {
                a.TOOLTIP: Tip.IMAGE_AUTOCROP,
                a.WIDGET: CheckButton
            },
            ok.AZIMUTH: {
                a.LIMIT: (.0, 359.),
                a.RANDOM: (.0, 359.),
                a.PRECISION: 1,
                a.TOOLTIP: Tip.AZIMUTH,
                a.WIDGET: Slider
            },
            ok.BACKDROP_BLUR: Option.BACKDROP_BLUR,
            ok.BACKDROP_IMAGE_BLUR: Option.BACKDROP_BLUR,
            ok.BACKDROP_INFLUENCE: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TOOLTIP: Tip.BACKDROP_INFLUENCE,
                a.WIDGET: Slider
            },
            ok.BACKGROUND_STRIPE: {
                a.CHOICE_WINDOW: RWStripe,
                a.TIP_TYPE: tt.STRIPE_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.BACKDROP_STYLE: {
                a.LIST: Option.BackdropStyle.names,
                a.RANDOMIZE: True,
                a.WIDGET: OptionList
            },
            ok.BACKDROP_TYPE: {a.LIST: bs.BACKDROP_TYPE, a.WIDGET: ComboBox},
            ok.BEVEL_EDGE_WIDTH: {
                a.LIMIT: (1, 1000),
                a.RANDOM: (8, 24),
                a.WIDGET: Slider
            },
            ok.BLEND: {
                a.LIMIT: (1, 60),
                a.RANDOM: (5, 20),
                a.TOOLTIP: Tip.BLEND,
                a.WIDGET: Slider
            },
            ok.BLUR: {
                a.LIMIT: (.0, 500.),
                a.PRECISION: 1,
                a.RANDOM: (.0, 50.),
                a.WIDGET: Slider
            },
            ok.BLUR_BEHIND: {
                a.LIMIT: (0, 500),
                a.TOOLTIP: Tip.BLUR_BEHIND_TIP,
                a.WIDGET: Slider
            },
            ok.BLUR_RADIUS: {
                a.LIMIT: (-400, 400),
                a.RANDOM: (-100., 100.),
                a.WIDGET: Slider
            },
            ok.BLUR_X: BLUR,
            ok.BLUR_Y: BLUR,
            ok.BORDER_BLUR: {
                a.LIMIT: (.0, 500.),
                a.PRECISION: 1,
                a.RANDOM: (1., 3.),
                a.WIDGET: Slider
            },
            ok.BORDER_INFLUENCE: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.WIDGET: Slider
            },
            ok.BORDER_TYPE: {a.LIST: bo.TYPE, a.WIDGET: ComboBox},
            ok.BORDER_WIDTH: {a.LIMIT: (0, 10000), a.WIDGET: Slider},
            ok.BOX_CELL_SHAPE: {a.LIST: sh.BOX_SHAPE_LIST, a.WIDGET: ComboBox},
            ok.BOX_CELL_SHAPE_NORMAL: {
                a.LIST: sh.BOX_NORMAL,
                a.WIDGET: ComboBox
            },
            ok.BOX_GRID_SIZE: {a.WIDGET: BoxGridLabel},
            ok.BOX_NAME: TEXT,
            ok.BOX_PLAN: {a.WIDGET: GroupPlan},
            ok.BOX_TYPE: {a.LIST: sh.BOX_TYPE, a.WIDGET: ComboBox},
            ok.BRUSH: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_brush_list,
                a.GET_RANDOM: get_random_brush,
                a.WIDGET: OptionButton
            },
            ok.BRUSH_ANGLE: {
                a.LIMIT: (-180., 180.),
                a.PRECISION: 1,
                a.WIDGET: Slider,
            },
            ok.BRUSH_DICT: {
                a.CHOICE_WINDOW: RWBrushChoice,
                a.COLUMN_TEXT: "Brush",
                a.TIP_TYPE: tt.BRUSH_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.BRUSH_HARDNESS: {
                a.LIMIT: (.001, 1.),
                a.PRECISION: 3,
                a.WIDGET: Slider
            },
            ok.BRUSH_SIZE: {
                a.LIMIT: (10, 10000),
                a.RANDOM: (75, 125),
                a.WIDGET: Slider
            },
            ok.BRUSH_SPACING: {
                a.LIMIT: (10., 5000.),
                a.PRECISION: 1,
                a.RANDOM: (65., 135.),
                a.WIDGET: Slider
            },
            ok.BUMP: {
                a.CHOICE_WINDOW: RWBumpChoice,
                a.TIP_TYPE: tt.BUMP_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.BUMP_DEPTH: {
                a.LIMIT: (1, 100),
                a.RANDOM: (1, 4),
                a.WIDGET: Slider
            },
            ok.BUMP_TYPE: {a.LIST: fb.TYPE, a.WIDGET: ComboBox},
            ok.CAMO_TYPE: {a.LIST: mo.CAMO_TYPE, a.WIDGET: ComboBox},
            ok.CAPTION_MARGIN: {
                a.CHOICE_WINDOW: RWMargin,
                a.TIP_TYPE: tt.MARGIN_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.CAPTION_TYPE: {
                a.GET_OPTION: True,
                a.WIDGET: ComboBox
            },
            ok.CELL_COUNT: {
                a.LIMIT: (1, 100),
                a.TOOLTIP: Tip.CELL_COUNT,
                a.WIDGET: Slider
            },
            ok.CELL_GAP: {
                a.LIMIT: (2, 100),
                a.RANDOM: (3, 9),
                a.TOOLTIP: Tip.CELL_GAP,
                a.WIDGET: Slider
            },
            ok.CELL_HEIGHT: {
                a.AXIS: 'y',
                a.LIMIT: (0, MAX_SIZE),
                a.TIPS: ("",),
                a.WIDGET: RectPair
            },
            ok.CELL_NAME: TEXT,
            ok.CELL_PLAN: {a.WIDGET: GroupPlan},
            ok.CELL_SHAPE: {a.LIST: sh.SHAPE_LIST, a.WIDGET: ComboBox},
            ok.CELL_SHAPE_NORMAL: {a.LIST: sh.NORMAL_LIST, a.WIDGET: ComboBox},
            ok.CELL_SHIFT: {a.TOOLTIP: Tip.GRID_SHIFT, a.WIDGET: CheckButton},
            ok.CELL_SIZE: {
                a.LIMIT: (1, 1500),
                a.RANDOM: (1, 100),
                a.WIDGET: Slider
            },
            ok.CELL_WIDTH: {
                a.AXIS: 'x',
                a.LIMIT: (0, MAX_SIZE),
                a.TIPS: ("",),
                a.WIDGET: RectPair
            },
            ok.CIRCLE_DIAMETER: {
                a.GET_WITH_KEY: get_filler_width,

                # Is limited by GIMP's clipboard to
                # pattern function where the maximum side
                # dimension for the clipboard is 1024.
                a.LIMIT: (12, 680),

                a.WIDGET: Slider
            },
            ok.CLIP_TO_CELL: {
                a.TOOLTIP: Tip.CLIP_TO_CELL_TIP,
                a.WIDGET: CheckButton
            },
            ok.CLOSE_FILE: {
                a.COLUMN_TEXT: "Close opened images after first use.",
                a.TOOLTIP: Tip.CLOSE_FILE,
                a.WIDGET: CheckButton
            },
            ok.COLOR_1: {
                a.GET_RANDOM: Base.rnd_col,
                a.WIDGET: ColorButton
            },
            ok.COLOR_1A: {
                a.GET_RANDOM: Base.rnd_rgba,
                a.HAS_ALPHA: True,
                a.WIDGET: ColorButton
            },
            ok.COLOR_2A: {
                a.BUTTON_COUNT: 2,
                a.HAS_ALPHA: True,
                a.RANDOMIZE: True,
                a.WIDGET: Rainbow
            },
            ok.COLOR_3A: {
                a.BUTTON_COUNT: 3,
                a.HAS_ALPHA: True,
                a.RANDOMIZE: True,
                a.WIDGET: Rainbow
            },
            ok.COLOR_6: {
                a.BUTTON_COUNT: 6,
                a.RANDOMIZE: True,
                a.WIDGET: Rainbow
            },
            ok.COLOR_6A: {
                a.BUTTON_COUNT: 6,
                a.HAS_ALPHA: True,
                a.RANDOMIZE: True,
                a.WIDGET: Rainbow
            },
            ok.COLOR_COUNT_1_6: {
                a.LIMIT: (1, 6),
                a.TOOLTIP: Tip.COLOR_COUNT,
                a.WIDGET: Slider
            },
            ok.COLOR_COUNT_2_6: {
                a.RANDOM: (2, 6),
                a.LIMIT: (2, 6),
                a.TOOLTIP: Tip.COLOR_COUNT,
                a.WIDGET: Slider
            },
            ok.COLOR_GRID_TYPE: {
                a.LABELS: bs.COLOR_GRID_TYPE,
                a.RANDOM: (0, 1),
                a.WIDGET: RadioRow
            },
            ok.COLORIZE: {a.RANDOM: (0, 1), a.WIDGET: CheckButton},
            ok.COLORIZE_OPACITY: {
                a.LIMIT: (1., 100.),
                a.PRECISION: 1,
                a.RANDOM: (1., 100.),
                a.WIDGET: Slider
            },
            ok.COLUMN: {
                a.GET_WITH_KEY: get_row_column_limited,
                a.LIMIT: (1, 10000),
                a.WIDGET: Slider
            },
            ok.COLUMN_1: {
                a.GET_WITH_KEY: get_row_column_limited,
                a.LIMIT: (1, 1000),
                a.TOOLTIP: Tip.COLUMN_1,
                a.WIDGET: Slider
            },
            ok.COLUMN_2: {
                a.GET_WITH_KEY: get_row_column_limited,
                a.LIMIT: (1, 1000),
                a.TOOLTIP: Tip.COLUMN_2,
                a.WIDGET: Slider
            },
            ok.COLUMN_COUNT: GRID_COUNT,
            ok.COLUMN_MAZE: {
                a.GET_WITH_KEY: get_row_column_limited,
                a.LIMIT: (4, 10000),
                a.WIDGET: Slider
            },
            ok.COLUMN_SLICE: {
                a.LIMIT: (1, 100),
                a.WIDGET: Slider
            },
            ok.COLUMN_WIDTH: {a.LIMIT: (1, MAX_SIZE), a.WIDGET: Slider},
            ok.COMMON_BORDER: CHECK,
            ok.COMPONENT: {a.LIST: bs.COMPONENT, a.WIDGET: ComboBox},
            ok.COMPOSITION_FRAME_WIDTH: {
                a.GET_WITH_KEY: get_frame_width,
                a.LIMIT: (0, 10000),
                a.WIDGET: Slider
            },
            ok.CONTRACT: {
                a.LIMIT: (0, 10000),
                a.TOOLTIP: Tip.FRINGE_CONTRACT,
                a.WIDGET: Slider
            },
            ok.CORNER_SHIFT: {
                a.LIMIT: (0, 100),
                a.RANDOM: (0, 18),
                a.WIDGET: Slider
            },
            ok.COVER: {
                a.TEXT:
                    "If necessary, the image is resized so that it can\n"
                    "fill the cell to the greatest degree. The method may\n"
                    "enlarge the image with a locked aspect ratio. In the\n"
                    "process, a portion of the image may be clipped. The\n"
                    "image justification determines the clipped side.",
                a.WIDGET: Label
            },
            ok.CRITERION: {
                a.LIST: fl.CRITERION_LIST,
                a.WIDGET: ComboBox
            },
            ok.CROP_H: FIXED_SIZE,
            ok.CROP_W: FIXED_SIZE,
            ok.CROP_X: {
                a.LIMIT: (0, MAX_SIZE),
                a.TOOLTIP: Tip.RESIZE_CROP_VALUE,
                a.WIDGET: Slider
            },
            ok.CROP_Y: FIXED,
            ok.CURVE: {a.LIST: fo.CURVE, a.WIDGET: ComboBox},
            ok.CUSTOM_CELL_SHAPE:  {
                a.LIST: sh.CUSTOM_SHAPE_LIST,
                a.WIDGET: ComboBox
            },
            ok.DELETE_PLAN: {
                a.TOOLTIP: Tip.DELETE_PLAN,
                a.WIDGET: CheckButton
            },
            ok.DEPTH: {
                a.LIMIT: (1, 100),
                a.RANDOM: (1, 100),
                a.WIDGET: Slider
            },
            ok.DETAIL_LEVEL: {
                a.LIMIT: (1, 15),
                a.RANDOM: (1, 15),
                a.WIDGET: Slider
            },
            ok.DIAGONAL_ROTATION: {
                a.LIMIT: (-359., 359.),
                a.PRECISION: 1,
                a.RANDOM: (-359., 359.),
                a.TOOLTIP: Tip.DIAGONAL_ROTATION,
                a.WIDGET: Slider
            },
            ok.DISTRESS_SPREAD: {
                a.LIMIT: (1., 100.),
                a.PRECISION: 1,
                a.RANDOM: (8., 16.),
                a.TOOLTIP: Tip.DISTRESS_SPREAD,
                a.WIDGET: Slider
            },
            ok.DISTRESS_THRESHOLD: {
                a.LIMIT: (1., 254.),
                a.PRECISION: 1,
                a.RANDOM: (1., 254.),
                a.TOOLTIP: Tip.DISTRESS_THRESHOLD,
                a.WIDGET: Slider
            },
            ok.EDGE_MODE: {a.LIST: Mode.EDGE_MODE, a.WIDGET: ComboBox},
            ok.EDGE_TYPE: {a.LIST: bs.PaintRush.TYPE, a.WIDGET: ComboBox},
            ok.ELEVATION: {
                a.LIMIT: (.0, 180.),
                a.PRECISION: 1,
                a.RANDOM: (20.0, 40.),
                a.COLUMN_TEXT: "Light Elevation",
                a.TOOLTIP: Tip.ELEVATION,
                a.WIDGET: Slider
            },
            ok.EMBOSS: {a.RANDOM: (0, 1), a.WIDGET: CheckButton},
            ok.END_OPACITY: {
                a.LIMIT: (.0, 100.),
                a.PRECISION: 1,
                a.TOOLTIP: Tip.END_OPACITY,
                a.WIDGET: Slider
            },
            ok.END_X: {
                a.AXIS: 'x',
                a.RANDOMIZE: True,
                a.TIPS: (Tip.END_X,),
                a.WIDGET: CanvasPair
            },
            ok.END_Y: {
                a.AXIS: 'y',
                a.RANDOMIZE: True,
                a.TIPS: (Tip.END_Y,),
                a.WIDGET: CanvasPair
            },
            ok.FACE_TYPE: {
                a.LABELS:  ("Group", "Face"),
                a.TOOLTIP: Tip.FACE_TYPE,
                a.WIDGET: RadioRow,
            },
            ok.FACTOR_IMAGE_SIZE_H: {
                a.LIMIT: (.0, 2.),
                a.PRECISION: 6,
                a.WIDGET: Slider,
            },
            ok.FACTOR_IMAGE_SIZE_W: {
                a.LIMIT: (.0, 2.),
                a.PRECISION: 6,
                a.TOOLTIP: Tip.RESIZE_FACTOR_VALUE,
                a.WIDGET: Slider,
            },
            ok.FEATHER: {
                a.LIMIT: (0, 10000),
                a.RANDOM: (50, 300),
                a.TOOLTIP: Tip.FEATHER_TIP,
                a.WIDGET: Slider
            },
            ok.FILE: {a.WIDGET: FileButton},
            ok.FILLED: {
                a.TEXT:
                    "The image is resized so that it fills the cell. Its\n"
                    "aspect ratio will be that of the cell rectangle.",
                a.WIDGET: Label
            },
            ok.FILTER: {a.WIDGET: Entry},
            ok.FIT_IMAGE: CHECK,
            ok.FIXED_IMAGE_SIZE_H: FIXED,
            ok.FIXED_IMAGE_SIZE_W: {
                a.LIMIT: (0, MAX_SIZE),
                a.TOOLTIP: Tip.RESIZE_FIXED_VALUE,
                a.WIDGET: Slider
            },
            ok.FLIP: {
                a.LABELS: ("Flip Horizontal", "Flip Vertical"),
                a.WIDGET: CheckRow
            },
            ok.FLIP_VERTICAL: CHECK,
            ok.FOLDER: {a.WIDGET: FolderButton},
            ok.FOLDER_ORDER: {
                a.LABELS: fi.FOLDER_ORDER_LIST,
                a.WIDGET: RadioColumn
            },
            ok.FONT: {a.CHOICE_WINDOW: RWChoice, a.WIDGET: OptionButton},
            ok.FONT_SIZE: {a.LIMIT: (4, 1000), a.WIDGET: Slider},
            ok.FRINGE_INFLUENCE: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.WIDGET: Slider
            },
            ok.FRAME: {a.LIST: self._frame_list, a.WIDGET: ComboBox},
            ok.FRAME_STYLE: {a.LIST: fo.FRAME_STYLE, a.WIDGET: ComboBox},
            ok.FRAME_TYPE: {
                a.LABELS:  ("Rounded", "Angular"),
                a.RANDOM: (0, 1),
                a.TOOLTIP: Tip.ROUNDED,
                a.WIDGET: RadioRow
            },
            ok.FRAME_WIDTH: {
                a.GET_WITH_KEY: get_frame_width,
                a.LIMIT: (1, 10000),
                a.WIDGET: Slider
            },
            ok.FRINGE_TYPE: {
                a.LIST: ng.TYPE,
                a.WIDGET: ComboBox
            },
            ok.GAP_TYPE: {a.LIST: bs.GAP_TYPE, a.WIDGET: ComboBox},
            ok.GAP_WIDTH: {
                # Is limited by GIMP's clipboard to
                # pattern function where the maximum side
                # dimension for the clipboard is 1024.
                a.LIMIT: (3, 512),

                a.RANDOM: (12, 100),
                a.WIDGET: Slider
            },
            ok.GRADIENT: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_gradient_list,
                a.GET_RANDOM: get_random_gradient,
                a.WIDGET: OptionButton
            },
            ok.GRADIENT_ANGLE: {a.LIST: fg.GRADIENT_ANGLE, a.WIDGET: ComboBox},
            ok.GRADIENT_DIRECTION: {
                a.LABELS: bs.DIRECTION,
                a.WIDGET: RadioRow
            },
            ok.GRADIENT_MODE: {
                a.LIST: Mode.GRADIENT_MODE_LIST,
                a.WIDGET: ComboBox
            },
            ok.GRADIENT_ROW: {
                a.LABELS: ("Invert", "Reverse"),
                a.RANDOMIZE: True,
                a.TIPS: ("", Tip.REVERSE),
                a.WIDGET: CheckRow
            },
            ok.GRADIENT_TYPE: {
                a.LIST: fg.GRADIENT_TYPE_LIST,
                a.WIDGET: ComboBox
            },
            ok.GREY_SCALE: {a.RANDOM: (0, 1), a.WIDGET: CheckButton},
            ok.GRID_SIZE: {a.WIDGET: GridLabel},
            ok.GRID_TYPE: {
                a.LIST: gr.TYPE_LIST,
                a.WIDGET: ComboBox
            },
            ok.HEIGHT_CLIP: CLIP,
            ok.HEIGHT_MOD: {
                a.AXIS: 'y',
                a.LIMIT: (-MAX_SIZE, MAX_SIZE),
                a.TIPS: (Tip.HEIGHT_MOD_TIP,),
                a.WIDGET: RenderPair
            },
            ok.HORZ_COUNT: GRID_COUNT,
            ok.HORZ_SCALE: {
                a.LIMIT: (.001, 1.),
                a.PRECISION: 3,
                a.WIDGET: Slider
            },
            ok.IMAGE: {
                a.CHOICE_WINDOW: RWImageChoice,
                a.TIP_TYPE: tt.IMAGE_TIP_TYPE,
                a.WIDGET: OptionButton,
            },
            ok.IMAGE_EFFECT: {
                a.LIST: Option.Effect.names,
                a.RANDOMIZE: True,
                a.WIDGET: OptionList
            },
            ok.IMAGE_GROUP_TYPE: {
                a.LABELS:  (
                    "Make one group for the image layers.",
                    "Image layers have their own group."
                ),
                a.TOOLTIP: Tip.IMAGE_GROUP_TYPE,
                a.WIDGET: RadioRow
            },
            ok.IMAGE_INFLUENCE: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TOOLTIP: Tip.IMAGE_INFLUENCE,
                a.WIDGET: Slider
            },
            ok.IMAGE_NAME: {
                a.FUNCTION: get_image_names,
                a.WIDGET: ComboBox
            },
            ok.IMAGE_SOURCE: {
                a.LIST: fi.IMAGE_SOURCE_LIST,
                a.WIDGET: ComboBox
            },
            ok.INFLUENCE: {
                a.CHOICE_WINDOW: RWLight,
                a.TIP_TYPE: tt.INFLUENCE_TYPE,
                a.WIDGET: OptionButton
            },
            ok.INLAY_BLUR: {
                a.LIMIT: (0, 500),
                a.RANDOM: (20, 30),
                a.WIDGET: Slider
            },
            ok.INNER_FRAME_WIDTH: {
                a.LIMIT: (4, 12),
                a.RANDOM: (4, 12),
                a.WIDGET: Slider
            },
            ok.INVERT: {a.RANDOM: (0, 1), a.WIDGET: CheckButton},
            ok.INVERT_NOISE: {a.RANDOM: (0, 1), a.WIDGET: CheckButton},
            ok.INTENSITY: {
                a.LIMIT: (0, 1000),
                a.RANDOM: (80, 200),
                a.WIDGET: Slider
            },
            ok.ITERATIONS: {
                a.LIMIT: (0, 100),
                a.RANDOM: (0, 20),
                a.WIDGET: Slider
            },
            ok.JUSTIFICATION: {a.LIST: ju.TYPE, a.WIDGET: ComboBox},
            ok.KEEP_GRADIENT: {
                a.TOOLTIP: Tip.KEEP_GRADIENT,
                a.WIDGET: CheckButton
            },
            ok.LAYER_COUNT: {
                a.LIMIT: (3, 20),
                a.RANDOM: (4, 8),
                a.WIDGET: Slider
            },
            ok.LAYER_ORDER: {
                a.LABELS: fi.LAYER_ORDER_LIST,
                a.TOOLTIP: Tip.IMAGE_ORDER,
                a.WIDGET: RadioColumn
            },
            ok.LEADING_TEXT: {
                a.CHARS: 10,
                a.TOOLTIP: Tip.CAPTION_LEADING_TEXT,
                a.WIDGET: Entry,
            },
            ok.LENGTH_SHIFT: {
                a.LIMIT: (0, 1000),
                a.RANDOM: (10, 30),
                a.TOOLTIP: Tip.LENGTH_SHIFT,
                a.WIDGET: Slider
            },
            ok.LINE_WIDTH: {
                # Is limited by GIMP's clipboard to
                # pattern function where the maximum side
                # dimension for the clipboard is 1024.
                a.LIMIT: (3, 512),

                a.RANDOM: (3, 20),
                a.WIDGET: Slider
            },
            ok.LOCKED: {
                a.TEXT:
                    "The images proportions are locked and a best fit\n"
                    "is applied if necessary. The image is not enlarged.",
                a.WIDGET: Label
            },
            ok.LOOP_INDEX: {
                a.LABELS: fi.LOOP_TYPE,
                a.TIPS: (Tip.LOOP_PLUS, Tip.LOOP_MINUS),
                a.WIDGET: RadioColumn
            },
            ok.MAKE_OPAQUE: {
                a.LABELS: (
                    "No, use the original source opacity.",
                    "Yes, use an opaque source."
                ),
                a.TOOLTIP: Tip.MAKE_OPAQUE,
                a.WIDGET: RadioColumn,
            },
            ok.MARGIN_BOTTOM: MARGIN_Y,
            ok.MARGIN_LEFT: MARGIN_X,
            ok.MARGIN_RIGHT: MARGIN_X,
            ok.MARGIN_TOP: MARGIN_Y,
            ok.MASK_TYPE: {a.LIST: ms.TYPE, a.WIDGET: ComboBox},
            ok.MAZE_DIRECTION: {a.LABELS: bs.DIRECTION, a.WIDGET: RadioRow},
            ok.MAZE_TYPE: {a.LIST: bs.MAZE_TYPE, a.WIDGET: ComboBox},
            ok.MESH_SIZE: {
                a.LIMIT: (8, 1000),
                a.RANDOM: (25, 60),
                a.WIDGET: Slider
            },
            ok.MESH_TYPE: {a.LIST: bs.MESH_TYPE, a.WIDGET: ComboBox},
            ok.METAL_FRAME: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TOOLTIP: Tip.METAL_FRAME,
                a.WIDGET: Slider
            },
            ok.MODE: {
                a.GET_RANDOM: Mode.rand,
                a.LIST: Mode.names,
                a.WIDGET: ComboBox
            },
            ok.MODEL_LIST: {a.WIDGET: ModelList, a.NAME: "Model"},
            ok.NAME: {a.WIDGET: Entry},
            ok.NEATNESS: {
                a.LIMIT: (.0, 1.),
                a.PRECISION: 3,
                a.RANDOM: (.0, 1.),
                a.WIDGET: Slider
            },
            ok.NET_LINE_SPACING: NET_LINE,
            ok.NET_LINE_WIDTH: NET_LINE,
            ok.NEXT_INDEX: {
                a.LABELS: fi.NEXT_TYPE,
                a.TIPS: (
                    Tip.IMAGE_NEXT_LINEAR,
                    Tip.IMAGE_NEXT_CIRCULAR
                ),
                a.WIDGET: RadioColumn
            },
            ok.NOISE: {
                a.LIMIT: (.0, 1.),
                a.PRECISION: 3,
                a.RANDOM: (.0, .5),
                a.WIDGET: Slider
            },
            ok.NOISE_MODE: {a.LIST: bs.NOISE_MODE_LIST, a.WIDGET: ComboBox},
            ok.NOISE_OPACITY: {
                a.LIMIT: (.0, 100.),
                a.PRECISION: 1,
                a.RANDOM: (.0, 100.),
                a.TOOLTIP: Tip.NOISE_OPACITY,
                a.WIDGET: Slider
            },
            ok.NUMBER_OF_SLICES: {
                a.LIMIT: (2, 60),
                a.RANDOM: (2, 15),
                a.WIDGET: Slider
            },
            ok.NUMERIC_SEQUENCE: {
                a.LIST: Image.relative_names,
                a.WIDGET: ComboBox
            },
            ok.OBEY_MARGINS: {
                a.TOOLTIP: Tip.OBEY_MARGINS_TIP,
                a.WIDGET: CheckButton
            },
            ok.OFFSET: {
                a.LIMIT: (0, 10000),
                a.RANDOM: (0, 20),
                a.WIDGET: Slider
            },
            ok.OFFSET_X: {
                a.LIMIT: (-4096, 4096),
                a.RANDOM: (-25, 25),
                a.WIDGET: Slider
            },
            ok.OFFSET_X_SHIFT: {
                a.AXIS: 'x',
                a.LIMIT: (-MAX_SIZE, MAX_SIZE),
                a.TIPS: (Tip.OFFSET_X_SHIFT,),
                a.WIDGET: RenderPair
            },
            ok.OFFSET_Y: {
                a.LIMIT: (-4096, 4096),
                a.RANDOM: (-25, 25),
                a.WIDGET: Slider
            },
            ok.OFFSET_Y_SHIFT: {
                a.AXIS: 'y',
                a.LIMIT: (-MAX_SIZE, MAX_SIZE),
                a.TIPS: (Tip.OFFSET_Y_SHIFT,),
                a.WIDGET: RenderPair
            },
            ok.OFFSET_Z: {
                a.LIMIT: (0, 10000),
                a.TOOLTIP: Tip.OFFSET_Z,
                a.WIDGET: Slider
            },
            ok.OPACITY: {
                a.LIMIT: (.0, 100.),
                a.PRECISION: 1,
                a.RANDOM: (25., 100.),
                a.WIDGET: Slider
            },
            ok.OTHER_FRAME: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TOOLTIP: Tip.OTHER_FRAME,
                a.WIDGET: Slider
            },
            ok.PANE_HEIGHT: {
                a.LIMIT: (25, 1000),
                a.RANDOM: (100, 200),
                a.WIDGET: Slider
            },
            ok.PANE_WIDTH: {
                a.LIMIT: (25, 1000),
                a.RANDOM: (100, 200),
                a.WIDGET: Slider
            },
            ok.PATTERN: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_pattern_list,
                a.GET_RANDOM: get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PATTERN_1: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_pattern_list,
                a.GET_RANDOM: get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PATTERN_2: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_pattern_list,
                a.GET_RANDOM: get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PATTERN_3: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: get_pattern_list,
                a.GET_RANDOM: get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PATTERN_SIZE: {
                # Is limited by GIMP's clipboard to
                # pattern function where the maximum side
                # dimension for the clipboard is 1024.
                a.LIMIT: (24, 256),

                a.RANDOM: (120, 256),
                a.WIDGET: Slider
            },
            ok.PER_CELL: {a.COLUMN_TEXT: "", a.WIDGET: PerCellGroup},
            ok.PIN_CORNER: {a.LIST: gr.PIN_LIST, a.WIDGET: ComboBox},
            ok.PLAQUE_INFLUENCE: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.WIDGET: Slider
            },
            ok.PLAQUE_MASK: {
                a.CHOICE_WINDOW: RWPlaqueMask,
                a.TIP_TYPE: tt.MASK_PLAQUE_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.PLAQUE_TYPE: {
                a.LIST: aq.TYPE,
                a.WIDGET: ComboBox
            },
            ok.POSITION_X: {
                a.AXIS: 'x',
                a.LIMIT: (-MAX_SIZE, MAX_SIZE),
                a.WIDGET: RenderPair
            },
            ok.POSITION_Y: {
                a.AXIS: 'y',
                a.LIMIT: (-MAX_SIZE, MAX_SIZE),
                a.WIDGET: RenderPair
            },
            ok.POST_BLUR: {
                a.LIMIT: (0, 500),
                a.RANDOM: (0, 100),
                a.TOOLTIP: Tip.POST_BLUR,
                a.WIDGET: Slider
            },
            ok.POWER: {
                a.LIMIT: (0, 180),
                a.RANDOM: (0, 180),
                a.TOOLTIP: Tip.NOISE_POWER,
                a.WIDGET: Slider
            },
            ok.PREVIEW_MODE: {
                a.LABELS: ("Show Gradient", "Show Samples."),
                a.WIDGET: RadioRow
            },
            ok.PREVIOUS_INDEX: {
                a.LABELS: fi.PREVIOUS_TYPE,
                a.TIPS: (
                    Tip.IMAGE_PRE_LINEAR,
                    Tip.IMAGE_PRE_CIRCULAR
                ),
                a.WIDGET: RadioColumn
            },
            ok.PROFILE: {a.LIST: fo.PROFILE, a.WIDGET: ComboBox},
            ok.RANDOM: CHECK,
            ok.RANDOM_SEED: {
                a.LIMIT: (0, 100000),
                a.RANDOM: (0, 100000),
                a.TOOLTIP: Tip.RANDOM_SEED_TIP,
                a.WIDGET: Slider
            },
            ok.RENDER_HEIGHT: RENDER,
            ok.RENDER_WIDTH: RENDER,
            ok.RESIZE_METHOD: {
                a.CHOICE_WINDOW: RWResize,
                a.TIP_TYPE: tt.RESIZE_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.RESIZE_TYPE: {a.LIST: fz.RESIZE_TYPE_LIST, a.WIDGET: ComboBox},
            ok.ROTATE: {
                a.LIMIT: (-359., 359.),
                a.PRECISION: 1,
                a.RANDOM: (-359., 359.),
                a.WIDGET: Slider
            },
            ok.ROTATE_JITTER: {
                a.LIMIT: (.0, 359.),
                a.PRECISION: 1,
                a.TOOLTIP: Tip.ROTATE_JITTER_TIP,
                a.WIDGET: Slider
            },
            ok.ROW: {
                a.GET_WITH_KEY: get_row_column_limited,
                a.LIMIT: (1, 10000),
                a.WIDGET: Slider
            },
            ok.ROW_COUNT: {
                a.LIMIT: (1, 100),
                a.TOOLTIP: Tip.GRID_BY_COUNT,
                a.WIDGET: Slider
            },
            ok.ROW_HEIGHT: {
                a.LIMIT: (1, MAX_SIZE),
                a.TOOLTIP: Tip.GRID_FIXED_SIZE,
                a.WIDGET: Slider
            },
            ok.ROW_MAZE: {
                a.LIMIT: (4, 10000),
                a.GET_WITH_KEY: get_row_column_limited,
                a.WIDGET: Slider
            },
            ok.ROW_SLICE: {a.LIMIT: (1, 100), a.WIDGET: Slider},
            ok.SAMPLE_POINTS: {
                a.LIMIT: (2, 50),
                a.RANDOM: (2, 25),
                a.TOOLTIP: Tip.SAMPLE_POINTS,
                a.WIDGET: Slider
            },
            ok.SAMPLE_RADIUS: {
                a.LIMIT: (1., 100.),
                a.PRECISION: 1,
                a.RANDOM: (10., 50.),
                a.WIDGET: Slider
            },
            ok.SAMPLE_VECTOR: {a.LIST: bs.VECTOR, a.WIDGET: ComboBox},
            ok.SATURATION: {
                a.LIMIT: (.0, 10.),
                a.PRECISION: 2,
                a.RANDOM: (.0, 2.),
                a.TOOLTIP: Tip.SATURATION,
                a.WIDGET: Slider
            },
            ok.SCATTER_COUNT: {
                a.LIMIT: (1, 100),
                a.RANDOM: (2, 20),
                a.TOOLTIP: Tip.SCATTER_COUNT,
                a.WIDGET: Slider
            },
            ok.SEED_GLOBAL: {
                a.LIMIT: (0, 100000),
                a.RANDOM: (0, 100000),
                a.TOOLTIP: Tip.SEED_GLOBAL,
                a.WIDGET: Slider
            },
            ok.SHADOW_BLUR: {
                a.LIMIT: (0, 500),
                a.RANDOM: (1, 20),
                a.WIDGET: Slider
            },
            ok.SHADOW_COLOR: {a.WIDGET: ColorButton},
            ok.SHADOW_INFLUENCE: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TOOLTIP: Tip.SHADOW_INFLUENCE,
                a.WIDGET: Slider
            },
            ok.SHADOW_TYPE: {
                a.LABELS: ("None", "Shadow"),
                a.WIDGET: RadioColumn
            },
            ok.SHAPE_BURST: {a.LIST: fg.SHAPE_BURST, a.WIDGET: ComboBox},
            ok.SHIFT: {
                a.CHOICE_WINDOW: RWShift,
                a.LISTEN: (fw.RENDER_SIZE_CHANGE,),
                a.TIP_TYPE: tt.SHIFT_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.SHIFT_GEGL: {
                a.LIMIT: (0, 200),
                a.RANDOM: (20, 50),
                a.WIDGET: Slider
            },
            ok.SHIFT_DIRECTION: {
                a.LABELS: bs.SHIFT_DIRECTION,
                a.RANDOM: (0, 1),
                a.WIDGET: RadioRow
            },
            ok.SHIFT_HEIGHT: {
                a.AXIS: 'y',
                a.LIMIT: (0, MAX_SIZE),
                a.TIPS: (Tip.SHIFT_HEIGHT_TIP,),
                a.WIDGET: RenderPair
            },
            ok.SHIFT_WIDTH: {
                a.AXIS: 'x',
                a.LIMIT: (0, MAX_SIZE),
                a.TIPS: (Tip.SHIFT_WIDTH_TIP,),
                a.WIDGET: RenderPair
            },
            ok.SHIFT_X: {
                a.AXIS: 'x',
                a.LIMIT: (0, MAX_SIZE),
                a.TIPS: (Tip.SHIFT_X_TIP,),
                a.WIDGET: RenderPair
            },
            ok.SHIFT_Y: {
                a.AXIS: 'y',
                a.LIMIT: (0, MAX_SIZE),
                a.TIPS: (Tip.SHIFT_Y_TIP,),
                a.WIDGET: RenderPair
            },
            ok.SHIFT_Z: {
                a.LIMIT: (0, 1000),
                a.TOOLTIP: Tip.SHIFT_Z,
                a.WIDGET: Slider
            },
            ok.SKETCH_TEXTURE: {a.LIST: bs.NEWS_TYPE, a.WIDGET: ComboBox},
            ok.SLICE: {a.TOOLTIP: Tip.SLICE, a.WIDGET: CheckButton},
            ok.SLICE_ORDER: {
                a.LABELS: fi.SLICE_ORDER_LIST,
                a.WIDGET: RadioColumn
            },
            ok.SMOOTHNESS: {
                a.LIMIT: (3, 20),
                a.RANDOM: (5, 12),
                a.WIDGET: Slider
            },
            ok.SOFTNESS: {
                a.LIMIT: (0, 1000),
                a.RANDOM: (0, 1000),
                a.WIDGET: Slider
            },
            ok.SPIRAL_DISTANCE: {
                a.LIMIT: (.001, .5),
                a.RANDOM: (.001, .5),
                a.PRECISION: 3,
                a.TOOLTIP: Tip.SPIRAL_DISTANCE,
                a.WIDGET: Slider
            },
            ok.SPIRAL_MOD: {a.LIST: bs.SPIRAL_MOD_LIST, a.WIDGET: ComboBox},
            ok.SPREAD: {
                a.LIMIT: (0, 512),
                a.RANDOM: (0, 512),
                a.WIDGET: Slider
            },
            ok.STACK_NAME: {a.WIDGET: Entry},
            ok.START_OPACITY: {
                a.LIMIT: (.0, 100.),
                a.PRECISION: 1,
                a.TOOLTIP: Tip.START_OPACITY,
                a.WIDGET: Slider
            },
            ok.STACK_PLAN: {a.WIDGET: GroupPlan},
            ok.START_X: {
                a.AXIS: 'x',
                a.RANDOMIZE: True,
                a.TIPS: (Tip.START_X,),
                a.WIDGET: CanvasPair
            },
            ok.START_Y: {
                a.AXIS: 'y',
                a.RANDOMIZE: True,
                a.TIPS: (Tip.START_Y,),
                a.WIDGET: CanvasPair
            },
            ok.STARTING_ANGLE: {
                a.LIMIT: (-360, 360),
                a.RANDOM: (-360, 360),
                a.WIDGET: Slider
            },
            ok.START_NUMBER: {
                a.LIMIT: (-sys.maxint, sys.maxint),
                a.TOOLTIP: Tip.CAPTION_START_NUMBER,
                a.WIDGET: Slider
            },
            ok.STEPS: {
                a.LIMIT: (1, 50),
                a.RANDOM: (1, 12),
                a.TOOLTIP: Tip.STEPS,
                a.WIDGET: Slider
            },
            ok.STEPS_DROP_ZONE: {
                a.LIMIT: (2, 100),
                a.RANDOM: (2, 12),
                a.TOOLTIP: Tip.STEPS_DROP_ZONE,
                a.WIDGET: Slider
            },
            ok.STOP_LENGTH: {
                a.LIMIT: (1, 1000),
                a.RANDOM: (20, 30),
                a.TOOLTIP: Tip.STOP_LENGTH,
                a.WIDGET: Slider
            },
            ok.STRIPE_HEIGHT: {
                a.LIMIT: (.1, 3.),
                a.PRECISION: 1,
                a.TOOLTIP: Tip.STRIPE_HEIGHT,
                a.WIDGET: Slider
            },
            ok.STRIPE_TYPE: {
                a.LABELS:  ("None", "Caption Stripe"),
                a.WIDGET: RadioColumn
            },
            ok.SUPERPIXEL_SIZE: {
                a.LIMIT: (8, 256),
                a.RANDOM: (8, 256),
                a.WIDGET: Slider
            },
            ok.TABLE_NAME: {a.WIDGET: Entry},
            ok.TABLE_PLAN: {a.WIDGET: GroupPlan},
            ok.TAPE_LENGTH: {
                a.LIMIT: (5, 1000),
                a.RANDOM: (80, 140),
                a.WIDGET: Slider
            },
            ok.TAPE_WIDTH: {
                a.LIMIT: (5, 1000),
                a.RANDOM: (30, 60),
                a.WIDGET: Slider
            },
            ok.TEXT: TEXT,
            ok.TEXTURE: {a.RANDOM: (0, 1), a.WIDGET: CheckButton},
            ok.TILE_SIZE: {
                a.LIMIT: (2., 256.),
                a.RANDOM: (7., 30.),
                a.WIDGET: Slider
            },
            ok.THRESHOLD: {
                a.LIMIT: (.0, 1.),
                a.PRECISION: 3,
                a.RANDOM: (.33, 1.),
                a.TOOLTIP: Tip.THRESHOLD,
                a.WIDGET: Slider
            },
            ok.TRANSLUCENT_FRAME: {
                a.PRECISION: 1,
                a.LIMIT: (.0, 100.),
                a.TOOLTIP: Tip.TRANSLUCENT_FRAME,
                a.WIDGET: Slider
            },
            ok.TRAILING_TEXT: {
                a.CHARS: 10,
                a.TOOLTIP: Tip.CAPTION_TRAILING_TEXT,
                a.WIDGET: Entry,
            },
            ok.TRIM: {
                a.TEXT:
                    "If necessary, the image is resized so that it can fill\n"
                    "the cell to the greatest degree without enlarging or\n"
                    "stretching the image. In the process, a side of the\n"
                    "image may be trimmed. The image justification\n"
                    "determines which part of a side is removed.",
                a.WIDGET: Label
            },
            ok.TRI_SHADOW: {
                a.CHOICE_WINDOW: RWShadow,
                a.TIP_TYPE: tt.SHADOW_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            ok.UNSHARP_AMOUNT: {
                a.RANDOM: (.0, 50.),
                a.LIMIT: (.0, 300.),
                a.PRECISION: 1,
                a.WIDGET: Slider
            },
            ok.UNSHARP_RADIUS: {
                a.RANDOM: (.0, 50.),
                a.LIMIT: (.0, 1500.),
                a.PRECISION: 1,
                a.WIDGET: Slider
            },
            ok.UNSHARP_THRESHOLD: {
                a.RANDOM: (.0, .1),
                a.LIMIT: (.0, .1),
                a.PRECISION: 2,
                a.WIDGET: Slider
            },
            ok.USE_PLASMA: {
                a.RANDOM: (0, 1),
                a.TOOLTIP: Tip.USE_PLASMA,
                a.WIDGET: CheckButton
            },
            ok.VERT_COUNT: {
                a.LIMIT: (1, 100),
                a.TOOLTIP: Tip.GRID_NORMALIZED,
                a.WIDGET: Slider
            },
            ok.VERT_SCALE: {
                a.LIMIT: (.001, 1.),
                a.PRECISION: 3,
                a.WIDGET: Slider
            },
            ok.WAVE_AMPLITUDE: {
                a.LIMIT: (.0, 100.),
                a.PRECISION: 1,
                a.RANDOM: (.0, 10.),
                a.WIDGET: Slider
            },
            ok.WAVE_PER_LAYER: {
                a.LIMIT: (1, 18),
                a.RANDOM: (1, 18),
                a.WIDGET: Slider
            },
            ok.WAVE_PHASE:  {
                a.LIMIT: (-360., 360.),
                a.PRECISION: 1,
                a.RANDOM: (-360., 360.),
                a.WIDGET: Slider
            },
            ok.WAVELENGTH: {
                a.LIMIT: (.5, 50.),
                a.PRECISION: 1,
                a.RANDOM: (30., 50.),
                a.WIDGET: Slider
            },
            ok.WHIRL: {
                a.LIMIT: (-720, 720),
                a.RANDOM: (-30, 30),
                a.TOOLTIP: Tip.WHIRL,
                a.WIDGET: Slider
            },
            ok.WIDTH: {
                a.GET_WITH_KEY: get_filler_width,
                a.LIMIT: (3, 10000),
                a.WIDGET: Slider
            },
            ok.WIDTH_CLIP: CLIP,
            ok.WIDTH_MOD: {
                a.AXIS: 'x',
                a.LIMIT: (-MAX_SIZE, MAX_SIZE),
                a.TIPS: (Tip.WIDTH_MOD_TIP,),
                a.WIDGET: RenderPair
            },
            ok.WIRE_THICKNESS: {
                a.LIMIT: (3, 30),
                a.RANDOM: (4, 10),
                a.WIDGET: Slider
            }
        }

    def collect_widget_arg(self, k):
        """
        Gather together the Widget keyword arguments.

        k: string
            option key

        on_accept: function
            Use with OptionGroup.
        """
        d = {}
        e = self.options[k]

        for k in KEYS:
            if k in e:
                d[k] = e[k]

        if wk.FUNCTION in e:
            d[wk.LIST] = e[wk.FUNCTION]()
        return d

    def create_frame_list(self):
        """
        Get the frame file names and make a list for the frame list.
        """
        go = False

        try:
            # Ignore sub-directories.
            files = glob.glob(
                Hat.cat.frame_path + os.path.sep + "*.png"
            )
            go = True

        except Exception as ex:
            Comm.show_err(ex)
            Comm.show_err("Roller was unable to load frame images.")
        if go:
            for i in files:
                n = os.path.splitext(os.path.basename(i))[0]
                self._frame_dict[n] = i
                self._frame_list.append(n)

    class Effect:
        """Is a list of Image Effects for Option."""
        default = ek.KEY_LIST[:]
        names = sorted([k for k in default])

        # Remove options that are not in a Model's Image Effect list.
        for k in (ek.SHADOW_1, ek.SHADOW_2, ek.INNER_SHADOW, ek.NO_EFFECT):
            names.pop(names.index(k))

        names = [ek.NO_EFFECT] + names

    class BackdropStyle:
        """Is a list of Backdrop Styles for Option."""
        default = by.KEY_LIST[:]
        names = sorted([k for k in default])


class OptionStat:
    """Use with Option and Render."""

    @staticmethod
    def get_effect_keys(effect):
        """
        Generate a list of sub-effect keys for an effect.

        effect: string
            an Image Effect

        Return: list
            of sub-effects
            of strings
        """
        q = ImageEffect.PROPERTY[effect][ImageEffect.EFFECT_STEPS]

        if effect == ek.TRI_SHADOW:
            return q
        return (effect,) + q
