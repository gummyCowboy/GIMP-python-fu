#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Triangle as ft, Shape as sh
from roller_one import Rect
from roller_one_extract import Shape

RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP
TRIANGLE_MAX = 10000000, 11547005


class TriangleHorz:
    """
    Calculate the position and the size of cells for a triangle cell-type.
    The triangle is facing left and right. Use intersects to map points
    shared by multiple triangles. Intersects create seamless triangle joints.
    """

    def __init__(self, o):
        """
        Calculate cell points for cell shapes.

        o: One
            Has init values.
            r, c: row, column span
        """
        def _get_shape():
            """
            Do shape.

            Return: tuple
                shape
            """
            _x, _x1 = q_x[c], q_x[c + 1]
            _y, _y1, _y2 = q_y[r], q_y[r + 1], q_y[r + 2]
            _is_inverse = Shape.is_inverse_triangle(r, c)

            # Both left and right triangles use this
            # function, but the right is the inverse of the left.
            if is_right_type:
                _is_inverse = not _is_inverse

            return (_x, _y, _x1, _y1, _x, _y2) if _is_inverse \
                else (_x1, _y, _x, _y1, _x1, _y2)

        row, column = o.r, o.c
        table = o.model.table
        s = o.layer_space
        is_right_type = o.model.cell_shape in ft.RIGHT_TYPE

        # intersect points
        q_x, q_y = [], []

        x, y = o.offset

        if o.grid_type in (gr.CELL_SIZE, gr.SHAPE_COUNT):
            # cell size
            if o.grid_type == gr.CELL_SIZE:
                # Correct cell size overflow.
                w = min(s[0], o.column_width / 1.)
                h = min(s[1], o.row_height / 1.)

                # table size
                h1 = h / 2.
                h2 = h - h1
                s1 = column * w, row * h1 + h2

            else:
                # horizontal triangles
                w1 = s[0] / 1. / column
                h1 = s[1] / (.5 + row * .5)

                # two possible solutions
                # solution one
                _w, _h = h1 * RATIO, h1
                h2 = _h / 2.
                h3 = _h - h2
                s1 = column * _w, row * h2 + h3

                # solution two
                _w1, _h1 = w1, w1 * UP_RATIO
                h2 = _h1 / 2.
                h3 = _h1 - h2
                s2 = column * _w1, row * h2 + h3

                # If solution one fails, use solution two.
                if s1[0] > s[0] or s1[1] > s[1]:
                    s1 = s2
                    w, h = _w1, _h1
                else:
                    w, h = _w, _h
            x, y = Shape.calc_pin_offset(
                o.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            w = s[0] / 1. / column
            h = s[1] / (.5 + row * .5)

        max_x, max_y = x + s[0], y + s[1]
        h /= 2.

        # cell rectangle
        for c in range(column + 2):
            q_x += [int(x)]
            x += w

        for r in range(row + 2):
            q_y += [int(y)]
            y += h

        # Compose the intersect coordinates.
        for r in range(row):
            for c in range(column):
                y, y1 = q_y[r], q_y[r + 2]
                x, x1 = q_x[c], q_x[c + 1]
                position = x, y
                size = x1 - x, y1 - y

                if x + size[0] > max_x or y + size[1] > max_y:
                    size = position = 0, 0

                # Cell, 'a'
                a = table[r][c]

                # cell rectangle, 'cell'
                a.cell = Rect(position[0], position[1], size[0], size[1])

                if size[0]:
                    a.shape = a.plaque = _get_shape()
