#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import (
    Effect as ek,
    Layer as nk,
    Option as ok,
    Step as sk
)
from roller_render_gradient_light import GradientLight
from roller_one import Hat, One
from roller_option_preset_dict import PresetDict
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


def do_extra_shadow(o, z):
    """
    Do the shadow process for the image material.

    o: One
        Has variables.

    Return: layer
        with shadow
    """
    d = PresetDict.get_default(ek.SHADOW_1)
    d[ok.OFFSET_X] = d[ok.OFFSET_Y] = 0
    parent = z.parent

    # Preset dict, 'o.d'
    d.update(o.d)

    # Group key, 'o.k'
    return Shadow.do(
        One(
            cast=(z,),
            d=d,
            model_name=o.model_name,
            name=Lay.name(parent, o.k + " Shadow"),
            parent=parent
        )
    )


def do_group_shadow(o, group):
    """
    Create a drop shadow starting with a group of additional layer groups.

    o: One
        Has variables.

    z: group
        to cast shadow

    Return: list
        of layers with shadow
    """
    undo_z = []

    for group1 in group.layers:
        q = []

        for z1 in group1.layers:
            if z1.visible:
                q += [z1]

                # Shadow #1 is below the image layer, but
                # its material doesn't cast a shadow.
                if Hat.cat.get_image_layer(z1.name):
                    break
        if q:
            undo_z += [
                Shadow.do(
                    One(
                        cast=q,
                        d=o.d,
                        model_name=o.model_name,
                        parent=group1,
                        name=Lay.name(group1, o.k)
                    )
                )
            ]
    return undo_z


def do_numbered_shadow(o):
    """
    Create a drop shadow.

    o: One
        Has variables.

    Return: layer or None
        with shadow
    """
    if o.is_nested_group:
        z = do_group_shadow(o, o.image_layer)

    else:
        z = do_one_layer_shadow(o, o.shadow_layer)
    return do_gradient_light(z)


def do_gradient_light(z):
    """
    Apply Gradient Light to shadow layers.

    z: layer, list, or None
        with shadow material

    return: layer, list, or None
        with shadow material
    """
    if isinstance(z, list):
        q = []

        for i in z:
            q += [GradientLight.apply_light(i, ok.SHADOW_INFLUENCE)]
        return q
    return GradientLight.apply_light(z, ok.SHADOW_INFLUENCE)


def do_one_layer_shadow(o, q):
    """
    Create a drop shadow for one layer which
    could be an image layer or a layer group.

    o: One
        Has variables.

    q: tuple
        of layer
        to cast shadow

    Return: layer or None
        with shadow
    """
    return Shadow.do(
        One(
            cast=q,
            d=o.d,
            model_name=o.model_name,
            parent=o.parent,
            name=Lay.name(o.parent, o.k)
        )
    )


def make_shadow_unit(z, q):
    """
    Create a unified shadow layer out of multiple layers.

    z: layer
        The layer group where the unified-shadow layer is placed.

    q: iterable
        layers to copy and merge
        Form a single shadow casting unit.

    Return: layer
        a unified shadow layer
    """
    def _process():
        _z = Lay.clone(z1)
        _z.mode = fu.LAYER_MODE_NORMAL

        pdb.gimp_image_reorder_item(j, _z, group, 0)
        Lay.hide(z1)
        return _z

    j = Hat.cat.render.image
    z2 = group = None

    if len(q) > 1:
        # Put layer(s) into a group and merge the group.
        group = Lay.group(j, "Unit", parent=z)
        for z1 in q:
            if z1:
                z2 = _process()
                Lay.apply_mask(z2)

    elif pdb.gimp_item_is_group(q[0]):
        z1 = q[0]
        z1 = _process()
        z2 = Lay.merge_group(z1)
        Lay.apply_mask(z2)

    else:
        z1 = q[0]
        z2 = _process()
        Lay.apply_mask(z2)

    if group:
        z2 = Lay.merge_group(group)
    return z2


class Shadow:
    """Create a shadow layer. Use with shadow effects."""

    @staticmethod
    def do(o):
        """
        Make a shadow.

        o: One
            Has variables.

        Return: layer
            with shadow
        """
        cat = Hat.cat
        d = o.d
        parent = o.parent
        model_name = o.model_name
        j = cat.render.image
        cast = o.cast
        if cast and d[ok.INTENSITY]:
            is_inner = o.is_inner if hasattr(o, 'is_inner') else False

            # a layer of merged layers to cast a shadow together, 'unit'
            unit = make_shadow_unit(parent, cast)

            if is_inner:
                # Inner Shadow type
                x = y = 0
                blur = d[ok.INLAY_BLUR]

            else:
                blur = d[ok.SHADOW_BLUR]
                x = d[ok.OFFSET_X]
                y = d[ok.OFFSET_Y]

            is_opaque = True if ok.MAKE_OPAQUE not in d else d[ok.MAKE_OPAQUE]
            z = RenderHub.do_shadow(
                unit,
                x, y,
                blur,
                d[ok.SHADOW_COLOR],
                d[ok.INTENSITY],
                is_opaque=is_opaque,
                is_inner=is_inner
            )

            j.remove_layer(unit)

            if z:
                a = 0
                if is_inner:
                    # Caption is on top of the layer group.
                    cap = cat.get_layer((model_name, nk.CELL_CAPTION))
                    if cap:
                        a = Lay.offset(cap) + 1

                else:
                    # Put the shadow layer below the lowest shadow caster.
                    for i in cast:
                        b = Lay.offset(i) + 1
                        if b > a:
                            a = b
                pdb.gimp_image_reorder_item(j, z, parent, a)

            [Lay.show(i) for i in cast if i]
            pdb.gimp_selection_none(j)

            if hasattr(o, 'name'):
                z.name = o.name
            return z

    @staticmethod
    def do_shadows(d, z):
        """
        Draw shadows for a material given a Tri-Shadow SuperPreset.

        d: dict
            Tri-Shadow SuperPreset

        z: layer
            with material

        Return: tuple
            layer:
                the shadow layer or None

            flag:
                Is true if the shadow is an inlay.
        """
        def cast_shadow():
            """
            Create the shadow effect and merge it with the material layer.
            """
            o.d = e
            is_inner = o.is_inner = k == sk.INNER_SHADOW
            z1 = Shadow.do(o)
            if z1:
                a = 0 if is_inner else Lay.offset(z) + 1
                pdb.gimp_image_reorder_item(j, z1, z1.parent, a)

        if Shadow.get_type(d):
            j = z.image
            group = Lay.group(j, "Shadow", parent=z.parent, z=z)
            o = One(cast=(z,), model_name="", parent=group)

            for k in sk.SHADOWS:
                e = d[k]
                cast_shadow()
            return Lay.merge_group(group)
        return z

    @staticmethod
    def get_type(d):
        """
        Get the shadow type from a Tri-Shadow dictionary.

        d: dict
            Tri-Shadow SuperPreset

        Return:
            int
            True is a shadow.
        """
        if sk.SHADOW_TYPE in d:
            return d[sk.SHADOW_TYPE][ok.SHADOW_TYPE]
        return 0


class InnerShadow:
    """Create an Inner shadow for image material."""

    @staticmethod
    def do(o):
        """
        Create a drop shadow that appears over the image material.

        o: One
            Is an Object that has variables / attributes.
            'is_nested_group', boolean; Is true for nested image layer groups.
            Shadow Preset dict, 'd'
            group key, 'k'
            from the Property option group, 'model_name'
            layer group where the shadow layer will be placed, 'parent'
            'image_layer', layer or layer group; Has image material.

        Return: layer, list of one or more layers, or None
            with shadow
        """
        def cast():
            return [
                Shadow.do(
                    One(
                        cast=(z,),
                        d=o.d,
                        is_inner=True,
                        model_name=o.model_name,
                        parent=group,
                        name=Lay.name(group, o.k)
                    )
                )
            ]

        cat = Hat.cat

        if o.is_nested_group:
            # Is a list of layers for the preview undo function, 'undo_z'.
            undo_z = []

            for group in o.image_layer.layers:
                for z in group.layers:
                    if cat.get_image_layer(z.name):
                        undo_z += cast()
            z = undo_z

        else:
            # There was only one z-height for the group.
            z = o.image_layer
            group = z.parent
            z = cast()
        return do_gradient_light(z)


class Shadow1:
    """Make a Shadow that appears below image material."""

    @staticmethod
    def do(o):
        """
        Create a drop shadow.

        o: One
            Has variables.

        Return: layer or None
            with shadow
        """
        return do_numbered_shadow(o)


class Shadow2:
    """Make a Shadow that appears below image material."""

    @staticmethod
    def do(o):
        """
        Create a drop shadow.

        o: One
            Has variables.

        Return: layer or None
            with shadow
        """
        return do_numbered_shadow(o)
