#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Preset as fp
from roller_constant_key import (
    BackdropStyle as by,
    Button as bk,
    Effect as ek,
    Widget as wk
)
from roller_one import Hat
from roller_option_preset import NonPreset, Preset, SuperPreset
from roller_widget_button import Button, PreviewButton
from roller_widget_tree import ModelList
from roller_option_view import EXPOSE
from roller_widget_button_pair import ButtonPair
from roller_widget_check_button import CheckButton, CheckRow
from roller_widget_table import Table

NO_LABEL = Button, CheckButton, CheckRow, ModelList, PreviewButton
NO_SAVE = (
    wk.HAS_EFFECT_PAIR,
    wk.HAS_VIEW_PAIR,
    bk.RANDOM,
    bk.PREVIEW,
    bk.PLAN
)
PREVIEW = by.KEY_LIST + ek.KEY_LIST


class OptionGroup:
    """Use to create a group of options found in the Option class."""

    def __init__(self, **d):
        """
        Create an option group.

        d: dict
            Has init values.
        """
        # If changed, the group's Preview view is not
        # a valid representative of the Render.
        self.changed = True

        # Has Widgets that populate an option group.
        # The key is an option key. The value is a Widget.
        self.d = {}

        # Use to store the group Widget references, so nothing
        # gets lost with the GTK garbage disposal.
        self.keep = None

        # for a group of options
        self.group_key = d[wk.GROUP_KEY]

        # Use for tree traversal to determine a group's Widget keys.
        # i.e. Node, PerCell, Preset, SuperPreset
        self.group_type = d[wk.GROUP_TYPE]

        # Is a Node when the group is made of a Node.
        self.node = None

        # Distinguish a group by identifying its Node.
        self.node_key = d[wk.NODE_KEY] if wk.NODE_KEY in d else None

        # Made of the Node labels that lead to the option group.
        self.step = d[wk.STEP]

        # Is needed to change its sensitivity.
        self.plan_button = None

        # Is the Preset for the group.
        self.preset = None

        # Is needed to change its sensitivity.
        self.preview_button = None

        # Is true when the option group has not
        # been drawn by Plan and has changed.
        self.unseen = True

        # Is set by the Per Cell option group.
        self.per_cell_group = None

        # Use with Node.
        self.vbox = d[wk.CONTAINER]

        # Register the option group with the global group dict.
        Hat.cat.group_dict[self.step] = self

    @staticmethod
    def draw_group(**d):
        """
        Draw an option group.

        d: dict
            Has init values.

        Return: dict
            of Widgets in the group
        """
        # list of Widget initialization arguments, 'q'
        # Each Widget has an additional iterable
        # of options processed by the Table Widget.
        q = []

        widgets = {}
        group_key = d[wk.GROUP_KEY]
        group = d[wk.GROUP] = OptionGroup(**d)
        option = Hat.dog.option

        # Option definition dict, 'e'
        e = option.options

        has_preset = False
        group_change = Hat.dog.signal_filter.add_group

        for i in d[wk.KEYS]:
            widget = e[i][wk.WIDGET]

            # Add the Widget specific keyword args with 'd1'.
            d1 = option.collect_widget_arg(i)
            d1[wk.KEY] = i

            # label text, 'n'
            n = e[i][wk.COLUMN_TEXT] if wk.COLUMN_TEXT in e[i] else i

            d1.update(d)

            if widget in NO_LABEL:
                d1[wk.TEXT] = n
                n = ""

            n = n.split(",")[0]
            q.append([n, widget, d1])

        # ButtonPair comes before Button as both options may be in 'd'.
        if wk.HAS_VIEW_PAIR in d:
            q += (["", ButtonPair, dict(
                d,
                key=wk.HAS_VIEW_PAIR,
                text=(bk.PLAN, bk.PREVIEW)
            )],)

        elif wk.HAS_EFFECT_PAIR in d:
            q += (["", ButtonPair, dict(
                d,
                key=wk.HAS_EFFECT_PAIR,
                text=(bk.RANDOM, bk.PREVIEW)
            )],)

        elif wk.HAS_PREVIEW in d:
            q += (["", PreviewButton, d],)

        elif wk.HAS_RANDOM in d:
            q += (["", Button, dict(d, key=bk.RANDOM, text=bk.RANDOM)],)

        if wk.HAS_PRESET in d and d[wk.HAS_PRESET]:
            if d[wk.GROUP_TYPE] == Preset:
                label = group_key.split(",")[0]

            else:
                # Per Cell Preset and SuperPreset
                label = group_key.split(",")[1].strip()

            q += (
                [
                    "%s Preset:" % (label,),
                    d[wk.GROUP_TYPE],
                    dict(d, key=wk.PRESET)
                ],
            )
            has_preset = True

        if q:
            widgets = group.d = Table.create(**dict(d, q=q))
            group.keep = {k_: a for k_, a in widgets.items()}
            group.preset = widgets[wk.PRESET] if has_preset else None

            if wk.HAS_VIEW_PAIR in widgets:
                group.plan_button = widgets[wk.HAS_VIEW_PAIR].left_button

            if group_key in EXPOSE or group_key in PREVIEW:
                # Use to update Widget visibility.
                vbow = d[wk.CONTAINER]
                vbow.connect('expose-event', group_change, group)

                # Subscribe Widgets to their group's visibility function.
                for _, g in widgets.items():
                    if hasattr(g, 'change_signal'):
                        g.subscribe()

            if has_preset:
                if d[wk.GROUP_TYPE] != SuperPreset:
                    if d[wk.IS_DEFAULT]:
                        group.preset.load(fp.DEFAULT, None)
            else:
                if d[wk.IS_DEFAULT]:
                    # Initialize NonPreset group.
                    NonPreset.load(group.d, group_key)

        # Remove any Widgets from the Widget list that don't
        # have get / set values and are not saved as a Preset.
        for i in widgets.keys():
            if widgets[i].key in NO_SAVE:
                widgets.pop(i)
        return widgets
