#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

er = Fu.Erode
pdb = fu.pdb


class SquareCloud:
    """Make a cloud of bright squares."""

    @staticmethod
    def do(o):
        """
        Create a Square Cloud Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            with Square Cloud
        """
        j = Hat.cat.render.image

        # Square Cloud Preset dict, 'o.d'
        d = o.d

        if d[ok.OPACITY]:
            # Group key, 'o.k'
            base = Lay.add(j, o.k + " Base")
            group = Lay.group(j, o.k + " WIP", z=base)

            z = Lay.clone(base, n="Plasma")

            pdb.plug_in_plasma(
                j, z,
                d[ok.RANDOM_SEED],
                Fu.Plasma.MEDIUM_TURBULENCE
            )

            z1 = Lay.clone(z, n="Erode")

            for i in range(10):
                Lay.dilate(z1)
                pdb.plug_in_erode(
                    j, z,
                    er.PROPAGATE_OPAQUE,
                    er.RGB_CHANNELS,
                    er.FULL_RATE,
                    er.RGB_CHANNELS,
                    er.LOW_LIMIT_0,
                    er.UPPER_LIMIT_255
                )

            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
            pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
            Lay.color_fill(base, (127, 127, 127))

            z2 = Lay.clone(base, n="HSV Saturation")
            z2.mode = fu.LAYER_MODE_HSV_SATURATION

            pdb.gimp_image_reorder_item(j, z2, group, 0)

            z3 = Lay.clone(z, n="Overlay")
            z3.mode = fu.LAYER_MODE_OVERLAY
            z3.opacity = 75.

            pdb.gimp_image_reorder_item(j, z3, group, 0)

            z4 = Lay.clone(z3, n="Darken Only")
            z4.mode = fu.LAYER_MODE_DARKEN_ONLY
            z4.opacity = 30.
            z = Lay.merge_group(group)
            z = Lay.clone(z, n="Colorify")
            z.opacity = 50.

            pdb.plug_in_colorify(j, z, d[ok.COLOR_1])

            z = Lay.merge(z)
            return RenderHub.finish_style(o, d, z, has_mode=True)
