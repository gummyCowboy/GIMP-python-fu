#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Widget as fw
from roller_constant_key import Widget as wk
from roller_widget import Widget
import gtk
import pango


class Combo(Widget):
    """Is a base class for a ComboBox-type class."""
    # Need for OptionGroup change subscription.
    change_signal = 'changed'

    def __init__(self, **d):
        """
        Create a GTK ComboBox.

        d: dict
            Has init values.
        """
        self.option_list = []
        self.store = gtk.ListStore(str)
        g = d['sub_type'](self.store)
        self._window_update = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self.set_tooltip

        Widget.__init__(self, g, **d)

        # Limit the horizontal size of the the ComboBox.
        a = gtk.CellRendererText()
        a.props.ellipsize = pango.ELLIPSIZE_END

        g.pack_start(a)
        self.add(g)

        if d['sub_type'] == gtk.ComboBox:
            g.add_attribute(a, 'text', 0)

        else:
            g.child.set_editable(0)
        if wk.LIST in d:
            self.populate_list(d[wk.LIST])

    def get_value(self):
        """
        Get the activated item in the ComboBox. Is part of the Widget template.

        Return: string
            active option
        """
        if len(self.option_list):
            return self.option_list[self.widget.get_active()]
        else:
            return ""

    def populate_list(self, q):
        """
        Set the options for the ComboBox.

        q: iterable
            of option strings
        """
        self.store.clear()

        self.option_list = q
        for n in q:
            self.store.append([n])

    def set_tooltip(self, *_):
        """
        Call when the ComboBox changes. Add a tooltip for long strings.
        """
        if hasattr(self, 'get_text'):
            n = self.get_text()

        else:
            n = self.get_value()

        # '22' is arbitrary and from the observation of gtk on my
        # screen. The string's pixel length is difficult to obtain.
        n = " {} ".format(n)
        n = n if len(n) > 22 else ""

        self.set_tooltip_text(n)
        self._window_update(self)

    def set_value(self, n):
        """
        Set the ComboBox's display. Is part of the Widget template.

        n: string
            to display
        """
        if n in self.option_list:
            x = self.option_list.index(n)

        elif hasattr(self, 'set_text'):
            self.set_text(n)
            x = -1

        else:
            x = 0
        if x > -1:
            self.widget.set_active(x)


class ComboBox(Combo):
    """This ComboBox displays options and has a separator."""

    def __init__(self, **d):
        """
        Create a ComboBox which supports a list separator.

        d: dict
            to initialize the Widget
        """
        Combo.__init__(self, **dict(d, sub_type=gtk.ComboBox))
        self.widget.set_row_separator_func(ComboBox._set_mode_separator)

        if wk.GET_OPTION in d:
            group = self.group
            k, k1 = group.node_key, group.group_key
            d = fw.OPTION_LIST
            q = None

            if k in d:
                if k1 in d[k]:
                    q = d[k][k1]
            if q is not None:
                self.populate_list(q)
        self.widget.connect('changed', self.callback)

    @staticmethod
    def _set_mode_separator(model, itr):
        """
        Determine if the current item in the list is a
        separator. Use when populating the option list.

        model: gtk.ListStore
        itr: gtk.iter

        Return: flag
            Is true if the item is a separator.
        """
        n = model.get_value(itr, 0)
        if n:
            return fw.LIST_SEPARATOR in n
