#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Group as gk, Widget as wk, Window as wi
from roller_option_group import OptionGroup
from roller_option_preset import Preset
from roller_option_preset_dict import PresetDict
from roller_port_preview import PortPreview
from roller_window_save import RWSave
from roller_window import Window


class RWBrushChoice(Window):
    """Is a GTK Dialog for defining Brush Preset settings."""
    def __init__(self, g):
        """
        Create a Window.

        g: OptionButton
            Has a Brush Preset value.
        """
        self.safe = g
        d = {
            wk.WIN: g.win.win,
            wk.WINDOW_KEY: wi.BRUSH_CHOOSER,
            wk.WINDOW_TITLE: "Define Brush Settings"
        }

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortBrushChoice(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()


class PortBrushChoice(PortPreview):
    """Is a container for the Brush Preset Widgets."""

    def __init__(self, d, g):
        """
        Create the Port.

        d: dict
            Has init values.

        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_brush(self, g):
        """
        Draw and load the option group.

        g: GTK container
            to receive group
        """
        d = OptionGroup.draw_group(
            **{
                wk.COLOR: self.color,
                wk.CONTAINER: g,
                wk.GROUP_KEY: gk.BRUSH,
                wk.GROUP_TYPE: Preset,
                wk.HAS_PRESET: True,
                wk.IS_DEFAULT: False,
                wk.KEYS: PresetDict.get_keys(gk.BRUSH),
                wk.ON_KEY_PRESS: self.on_key_press,
                wk.ON_PREVIEW_BUTTON: self.task_preview,
                wk.ON_WIDGET_CHANGE: self.on_widget_change,
                wk.STEP: (gk.BRUSH,),
                wk.PORT: self,
                wk.SAVE_WINDOW: RWSave,
                wk.WIN: self.roller_window
            }
        )
        g = self.preset = d[wk.PRESET]
        self.group = g.group
        d = self.safe.get_value()

        g.load_preset(d)
        self._previous_brush_dict = d

    def draw_port(self, g):
        """
        Draw the Port's widgets. Is a Port template function.

        g: VBox
            container for the Widgets
        """
        self.draw_simple_dialog_port(
            g,
            (self._draw_brush, self.draw_preview_process),
            ("Define Brush", "")
        )

    def get_group_value(self):
        """
        Get the Preset value. Is a PortPreview template function.

        Return: dict
            Brush Preset
        """
        return self.preset.get_value()
