#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Color,
    Image as fi,
    Resize as fz,
    Tooltip as tt,
    Widget as fw
)
from roller_constant_key import Button as bk, Option as ok, Widget as wk
from roller_one import Comm, Hat
from roller_one_tip import Tip
from roller_widget_entry import Entry
from roller_widget_box import Box, Eventful
from roller_widget import Widget
import gtk
import os

CROP = "X: {} , Y: {}, Width: {}, Height: {}"
FILE_ONLY = \
    "The selected item is a folder, " \
    "and the entry is for an image file only."
FIXED = "Width: {}, Height: {}"
FOLDER_ONLY = \
    "The selected item is a not folder, " \
    "and the entry is for folders only. "
FACTOR = "Width x {}, Height x {}"
button_text_dict = {
    tt.BRUSH_TIP_TYPE: "Configure Brush",
    tt.BUMP_TIP_TYPE: "Configure Bump",
    tt.INFLUENCE_TYPE: "Configure Influence",
    tt.MARGIN_TIP_TYPE: "Configure Margins",
    tt.MASK_PLAQUE_TIP_TYPE: "Configure Mask",
    tt.SHADOW_TIP_TYPE: "Configure Shadow",
    tt.SHIFT_TIP_TYPE: "Configure Shift",
    tt.STRIPE_TIP_TYPE: "Configure Stripe"
}
tip_dict = {
    tt.BRUSH_TIP_TYPE: Tip.make_brush_tooltip,
    tt.BUMP_TIP_TYPE: Tip.make_bump_tooltip,
    tt.INFLUENCE_TYPE: Tip.make_influence_tooltip,
    tt.IMAGE_TIP_TYPE: Tip.make_image_tooltip,
    tt.MARGIN_TIP_TYPE: Tip.make_margin_tooltip,
    tt.MASK_PLAQUE_TIP_TYPE: Tip.mask_plaque_tooltip,
    tt.RESIZE_TIP_TYPE: Tip.make_resize_tooltip,
    tt.SHADOW_TIP_TYPE: Tip.make_shadow_tooltip,
    tt.SHIFT_TIP_TYPE: Tip.make_shift_tooltip,
    tt.STRIPE_TIP_TYPE: Tip.make_stripe_tooltip
}


class Button(Widget):
    """This is a custom GTK Button."""
    # Need for OptionGroup change subscription.
    change_signal = 'clicked'

    def __init__(self, **d):
        """
        Create a gtk.Button that is attached to an gtk.Alignment.

        d: dict
            Has keyword arguments for Widget.
        """
        # There is no basestring in Python 3.
        if isinstance(d[wk.TEXT], basestring):
            g = gtk.Button(d[wk.TEXT])

        else:
            # for arrow
            g = gtk.Button()
            g.add(d[wk.TEXT])

        self.value = None

        Widget.__init__(self, g, **d)
        self.add(g)

        # Do the connection last.
        g.connect('clicked', self.callback)

    def get_value(self):
        """
        Is part of the Widget template.

        Return: value
            from 'self.value'
        """
        return self.value

    def set_value(self, a):
        """
        Set 'self.value'. Is part of the Widget template.

        a: value
            Give to 'self.value'.
        """
        self.value = a


class ColorButton(Widget):
    """Open a color-chooser dialog on action."""
    # Need for OptionGroup change subscription.
    change_signal = 'clicked'

    def __init__(self, **d):
        """
        Create a ColorButton.

        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.ColorButton(color=gtk.gdk.Color(0, 0, 0))
        self._has_alpha = d[wk.HAS_ALPHA] if wk.HAS_ALPHA in d else False

        g.set_use_alpha(self._has_alpha)
        Widget.__init__(self, g, **d)
        self.add(g)

        # Do the connections last.
        g.connect('clicked', self.callback)
        g.connect('color_set', self.update_tooltip)

    @staticmethod
    def convert_to_rgb(color):
        """
        Convert gtk.gdk.Color to RGB.

        color: gtk.gdk.Color
            to convert

        Return: RGB
            color
        """
        if isinstance(color.red, int):
            return tuple(
                [i // 257 for i in (color.red, color.green, color.blue)]
            )

    def get_value(self):
        """
        Get the value of the ColorButton. Is part of the Widget template.

        Return: tuple
            color
            RGB
            in 0 to 255
        """
        color = self.widget.get_color()
        color = ColorButton.convert_to_rgb(color)

        if self._has_alpha:
            color = color + (self.widget.get_alpha() // 257,)
        return color

    def set_value(self, color):
        """
        Set the color of the ColorButton. Is part of the Widget template.

        color: gtk.gdk.Color
            of button
        """
        color1 = color[:]

        if self._has_alpha:
            if len(color1) < 4:
                # Fix a missing alpha value
                # which may occur with updates.
                color1 += (255,)
            color = color1[:3]

        if not isinstance(color, gtk.gdk.Color):
            if isinstance(color, tuple):
                color = tuple([i * 257 for i in color])

            # in the range of 0 to 65535, 'color'
            # 257 in GDK color is 1.0 RGBA float precision.
            color = gtk.gdk.Color(*color)

        self.widget.set_color(color)

        q = ColorButton.convert_to_rgb(color)

        if self._has_alpha:
            self.widget.set_alpha(color1[3] * 257)
            tip = Tip.COLOR_RGBA
            q += (color1[3],)

        else:
            tip = Tip.COLOR
        self.set_tooltip_text(tip.format(*q))

    def update_tooltip(self, *_):
        """
        Update the Widget's tooltip after the
        user closes the color-chooser dialog.
        """
        self.set_value(self.get_value())


class ColorfulButton(Eventful):
    """This EventBox can change color and respond to signals."""

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        super(ColorfulButton, self).__init__(None)

        self.value = None
        self._accept = d[wk.ON_ACCEPT]
        self._update_window = d[wk.ON_WIDGET_CHANGE]
        self.background_color = d[wk.COLOR]
        self.group = d[wk.GROUP] if wk.GROUP in d else None
        self.on_preview_button = d[wk.ON_PREVIEW_BUTTON] \
            if wk.ON_PREVIEW_BUTTON in d else None

        # Embed the Widget inside a VBox and an HBox.
        g = self.label = gtk.Label(d[wk.TEXT])
        g1 = self.hbox = gtk.HBox()

        self.add(g1)
        g1.add(g)

        a = gtk.gdk
        p = self.connect

        # signals to respond to
        for i in (
            a.BUTTON_PRESS_MASK,
            a.FOCUS_CHANGE_MASK,
            a.KEY_PRESS_MASK
        ):
            self.add_events(i)

        self.set_can_focus(1)
        self.set_color(self.background_color)

        # Avoid the 'button_press_event' as it fails the Widget.
        p('button_release_event', self.on_click)
        p('key_press_event', self.on_key_press)
        p('focus_in_event', self.focus_in)
        p('focus_out_event', self.focus_out)

    def set_color(self, color):
        """
        Set the button's face color.

        color: gtk.gdk.Color
            button color
        """
        self.modify_bg(gtk.STATE_NORMAL, color)

    def on_click(self, *_):
        """Pass the click event to the button owner."""
        self.grab_focus()
        self._update_window(self)

    def on_key_press(self, g, a):
        """
        Process a 'space' and 'Return' key-press.

        g: self
        a: signal
            key-press event

        Return: None or true
            Is true when key-press is processed.
        """
        n = gtk.gdk.keyval_name(a.keyval)

        if n == 'space':
            return self._update_window(g)
        elif n == 'Return':
            return self._accept()

    def focus_in(self, *_):
        """Change the color of the button to show focus."""
        self.set_color(Color.FOCUS_COLOR)

    def focus_out(self, *_):
        """Change the color of the button to normal."""
        self.set_color(self.background_color)

    def set_label(self, n):
        """
        Change the button's text.

        n: string
            for Label
        """
        self.label.set_text(n)

    def set_size(self, w=10, h=10):
        """
        Try to set the size of the button.

        w: int
            width of button

        h: int
            height of button
        """
        self.set_size_request(width=w, height=h)

    def set_text_color(self, color):
        """
        Set the color of the button's text.

        color: gtk.gdk.Color
            for the text
        """
        self.label.modify_fg(gtk.STATE_NORMAL, color)

    def show(self):
        """Display the custom button."""
        super(ColorfulButton, self).show()
        for g in (self.hbox, self.vbox, self.label):
            g.show()


class OptionButton(Button):
    """Has a Label and/or tooltip that reflect its 'self.value'."""

    MAX_SIZE = 48
    WITH_VALUE = "{}…"

    def __init__(self, **d):
        """
        Make the Button.

        d: dict
            Has variables.
        """
        self._update_window = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self.do_choice
        self.tip_type = None
        d[wk.TEXT] = "…"

        Button.__init__(self, **d)
        self.widget.set_use_underline(False)

        for k in (
            wk.CHOICE_WINDOW,
            wk.COLOR,
            wk.PREVIEW,
            wk.TIP_TYPE,
        ):
            if k in d:
                setattr(self, k, d[k])
        if wk.LISTEN in d:
            for i in d[wk.LISTEN]:
                if i == fw.RENDER_SIZE_CHANGE:
                    Hat.dog.signal_filter.connect(
                        i, self._on_render_size_change, self
                    )

    def _on_render_size_change(self, *_):
        """
        Call when the render size changes. Is a custom signal subscription.
        """
        self._update_tooltip(self.get_value())

    def _update_tooltip(self, a):
        """
        Set the OptionButton's tooltip to 'a'.

        a: value
            give to 'self.value'
        """
        if a is not None:
            # There is no basestring in Python 3.
            if isinstance(a, basestring):
                self.set_tooltip_text(" {} ".format(a))
            else:
                if self.tip_type in tip_dict:
                    self.set_tooltip_text(tip_dict[self.tip_type](a, self))

    def do_choice(self, _):
        """
        Open a ChoiceWindow. Modify the OptionButton's value.

        _: OptionButton
            activated
            to receive choice
            not used
        """
        self.choice_window(self)
        self._update_window(self)

    def set_value(self, a):
        """
        Override the super class, so that the OptionButton's Label
        and tooltip can be modified. Is part of the Widget template.

        a: string or dict
            Use to set 'self.value'.
        """
        self.value = a
        n = ""

        self._update_tooltip(a)

        if a is not None:
            # There is no basestring in Python 3.
            if isinstance(a, basestring):
                n = " {} ".format(a)
            else:
                if self.tip_type in button_text_dict:
                    n = button_text_dict[self.tip_type]

                elif self.tip_type == tt.RESIZE_TIP_TYPE:
                    n = a[ok.RESIZE_TYPE]
                    if n not in fz.TEXT_TYPE:
                        if n == fz.CROP:
                            n = CROP.format(
                                a[ok.CROP_X],
                                a[ok.CROP_Y],
                                a[ok.CROP_W],
                                a[ok.CROP_H]
                            )

                        elif n == fz.FIXED:
                            n = FIXED.format(
                                a[ok.FIXED_IMAGE_SIZE_W],
                                a[ok.FIXED_IMAGE_SIZE_H]
                            )
                        elif n == fz.FACTOR:
                            n = FACTOR.format(
                                a[ok.FACTOR_IMAGE_SIZE_W],
                                a[ok.FACTOR_IMAGE_SIZE_H]
                            )
                elif self.tip_type == tt.IMAGE_TIP_TYPE:
                    n = a[ok.IMAGE_SOURCE]
                    if n != "None":
                        if n in fi.INDICES:
                            x = fi.INDICES.index(n)
                            b = a[n]
                            n = fi.TOOLTIPS[x][b]
                        else:
                            n = a[n]

        x = min(OptionButton.MAX_SIZE, len(n))

        self.widget.set_label(
            OptionButton.WITH_VALUE.format(n[-x:].rstrip()))
        self._update_window(self)


class SwitchButton(ColorfulButton):
    """Use to process cell connection events."""

    def __init__(self, r, c, **d):
        """
        Create the SwitchButton.

        r, c: int
            cell index

        d: dict
            Has init values.
        """
        self.r = r // 2
        self.c = c // 2
        self._cell_table = d[wk.CELL_TABLE]
        self.action = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self.on_switch_action
        self.pad = d[wk.CONTAINER]
        self.gate = 0
        ColorfulButton.__init__(self, **d)

    def on_switch_action(self, _):
        """
        Reverse the switch setting. Call the connection operator.
        """
        x = self.gate = int(not self.gate)

        self.set_label(("+", "-")[x])
        self.action[x](self._cell_table[self.r][self.c])


class OSButton(Widget):
    """Is a super for FileButton and FolderButton."""
    # Need for OptionGroup change subscription.
    change_signal = 'changed'

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        box = Box()
        d[wk.CHARS] = 90
        g = self.os_entry = Entry(**d)
        d[wk.ON_WIDGET_CHANGE] = d[wk.OS_BUTTON_CLICK]
        g1 = self.os_button = Button(**d)

        Widget.__init__(self, g.widget, **d)
        box.add(g)
        box.add(g1)
        self.add(box)

    def get_value(self):
        """
        Get the value of the Entry. Is part of the Widget template.

        Return: string
            a file or folder reference
        """
        return self.os_entry.get_value()

    def set_value(self, n):
        """
        Set the value of the Entry. Is part of the Widget template.

        n: string
            a file or folder reference
        """
        return self.os_entry.set_value(n)


class FileButton(OSButton):
    """
    Has an Entry and a Button that opens a dialog for choosing an image file.
    """

    def __init__(self, **d):
        """
        Draw the Entry and Button.

        d: dict
            Has init values.

        """
        d[wk.TEXT] = "Select a File…"
        d[wk.OS_BUTTON_CLICK] = self._get_file_entry_item
        OSButton.__init__(self, **d)

    def _get_file_entry_item(self, *_):
        """Open a file chooser dialog."""
        dialog = gtk.FileChooserDialog(
            title="Choose an Image File",
            parent=self.win.win,
            action=gtk.FILE_CHOOSER_ACTION_OPEN,
            buttons=(
                "Cancel",
                gtk.RESPONSE_CANCEL,
                "Accept",
                gtk.RESPONSE_ACCEPT
            )
        )
        file_filter = gtk.FileFilter()
        n = self.os_entry.get_value()

        if not n:
            n = Hat.cat.image_path

        # reference
        # en.wikipedia.org/wiki/File_URI_scheme
        n = "file://localhost/" + os.path.dirname(n)

        dialog.set_current_folder_uri(n)
        file_filter.set_name("Images")

        for i in fi.EXTENSION:
            file_filter.add_pattern("*" + i)

        dialog.add_filter(file_filter)

        response = dialog.run()

        # Is the enum for Accept, '-3'.
        n = dialog.get_filename() if response == -3 else ""

        dialog.destroy()
        if n:
            Hat.cat.image_path = n

            if not os.path.isfile(n):
                Comm.pop_up(
                    self.win.win,
                    1,
                    FILE_ONLY.format(n),
                    "Wrong Item Type"
                )
                n = ""
            if n:
                self.os_entry.set_value(n)


class FolderButton(OSButton):
    """Has an Entry and a Button that opens a dialog to choose a folder."""

    def __init__(self, **d):
        """
        Draw an Entry and a Button.

        d: dict
            Has init values.
        """
        d[wk.TEXT] = "Select a Folder…"
        d[wk.OS_BUTTON_CLICK] = self._get_folder_entry_item
        OSButton.__init__(self, **d)

    def _get_folder_entry_item(self, *_):
        """Open a folder chooser dialog."""
        action = gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER
        dialog = gtk.FileChooserDialog(
            title="Choose an Image Folder",
            parent=self.win.win,
            action=action,
            buttons=(
                "Cancel",
                gtk.RESPONSE_CANCEL,
                "Accept",
                gtk.RESPONSE_ACCEPT
            )
        )
        n = self.os_entry.get_value()

        if not n:
            n = Hat.cat.image_path

        if os.path.isdir(n):
            # reference
            # en.wikipedia.org/wiki/File_URI_scheme
            n = "file://localhost/" + n

            # Set the initial folder.
            dialog.set_current_folder_uri(n)

        response = dialog.run()

        # Is the enum for Accept, '-3'.
        n = dialog.get_filename() if response == -3 else ""

        dialog.destroy()
        if n:
            Hat.cat.image_path = n
            if not os.path.isdir(n):
                Comm.pop_up(
                    self.win.win,
                    1,
                    FOLDER_ONLY.format(n),
                    "Wrong Item Type"
                )
                n = ""
            if n:
                self.os_entry.set_value(n)


class PreviewButton(Button):
    """Use to make a View Preview."""
    def __init__(self, **d):
        """
        Create a GTK Button that is attached to a GTK Alignment.

        d: dict
            Has button variables.
        """
        d[wk.ON_WIDGET_CHANGE] = self._on_button_action
        d[wk.TEXT] = d[wk.KEY] = bk.PREVIEW

        Button.__init__(self, **d)
        self.group.preview_button = self

    def _on_button_action(self, g):
        """
        Let the owner know that the Button has been activated.

        g: Button
            self
        """
        self.on_preview_button(self, g.group)
