#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class PatternFill:
    """Fill the backdrop with a pattern."""

    @staticmethod
    def do(o):
        """
        Create a Pattern Fill Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            with Pattern Fill
        """
        # Pattern Fill Preset dict, 'o.d'
        d = o.d

        if d[ok.OPACITY]:
            # Backdrop Image layer, 'o.z'
            # Group key, 'o.k'
            z = Lay.clone(o.z, n=o.k + " WIP")

            # fill point, 'x, y'
            x, y = RenderHub.get_render_points(d)[:2]

            RenderHub.set_fill_context(d)
            RenderHub.set_pattern(d)
            pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, x, y)

            if d[ok.INVERT]:
                pdb.gimp_drawable_invert(z, Fu.DrawableInvert.NO_LINEAR)
            return RenderHub.bump(z, d[ok.BUMP])
