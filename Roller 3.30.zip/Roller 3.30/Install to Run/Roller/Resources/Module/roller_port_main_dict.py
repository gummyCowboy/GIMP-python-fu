#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import (
    BackdropStyle as by,
    Effect as ek,
    Group as gk,
    Widget as wk
)
from roller_option_preset import (
    BEHIND_TYPE,
    NonPreset,
    PerCell,
    Preset,
    SuperPreset
)
from roller_widget_tree import Node

BOX_FACE = (
    gk.PER_CELL_PLAQUE,
    gk.PER_CELL_FRINGE,
    gk.PER_CELL_BORDER,
    gk.PER_CELL_PLACE,
    gk.PER_CELL_MASK,
    gk.PER_CELL_CAPTION
)


class MainDict:
    """
    Is extracted from PortMain. Has a dictionary
    that defines the navigation tree.
    """

    def __init__(self):
        """
        Initialize dictionaries used to make Nodes
        and OptionGroups for the navigation tree.
        """
        # for groups without a Per Cell option
        grid_type = {
            wk.HAS_PRESET: True,
            wk.HAS_VIEW_PAIR: True,
            wk.WIDGET: Preset
        }

        # for Face Group options
        # The Preview or Plan Button are not used.
        group_type = {
            wk.FORM_HAS_PREVIEW: False,
            wk.HAS_PRESET: True,
            wk.WIDGET: PerCell
        }

        # for groups with a Per Cell option
        per_cell_type = {
            wk.FORM_HAS_PREVIEW: True,
            wk.HAS_PRESET: True,
            wk.WIDGET: PerCell
        }

        # Use with Backdrop Styles and Image Effect groups.
        render_effect = {
            wk.HAS_EFFECT_PAIR: True,
            wk.HAS_PRESET: True,
            wk.WIDGET: Preset
        }

        # Use with the Tri-Shadow group in its satellite Window.
        shadow_effect = {
            wk.HAS_PRESET: True,
            wk.HAS_RANDOM: True,
            wk.WIDGET: Preset
        }

        # for option group without a Preset or a Preview Button
        simple_type = {wk.WIDGET: NonPreset}

        # for option group without a Preset, but has a Preview Button
        view_type = {wk.HAS_VIEW_PAIR: True, wk.WIDGET: NonPreset}

        # for groups with only a Preset
        super_preset = {wk.WIDGET: SuperPreset, wk.HAS_PRESET: True}

        # Use to make a navigation tree. The trunk or stem is defined by
        # the 'gk.STEPS' dict. From its items, branches form from a
        # series of connected Nodes that end in an OptionGroup.
        self.group_def = {
            by.BACKDROP_IMAGE: render_effect,
            ek.SHADOW_2: shadow_effect,
            ek.INNER_SHADOW: shadow_effect,
            ek.SHADOW_1: shadow_effect,
            gk.BACKDROP: {
                wk.LABELS: (by.BACKDROP_IMAGE, gk.BACKDROP_STYLE),
                wk.WIDGET: Node
            },
            gk.BACKDROP_STYLE: {wk.WIDGET: NonPreset, wk.HAS_RANDOM: True},
            gk.BLUR_BEHIND: {
                wk.LABELS: (gk.IMAGE_BEHIND, gk.CAPTION_BEHIND),
                wk.WIDGET: Node
            },
            gk.BOX_BORDER: {
                wk.LABELS: (
                    gk.PER_CELL_GROUP_BORDER,
                    gk.FACE_1_BORDER,
                    gk.FACE_2_BORDER,
                    gk.FACE_3_BORDER
                ),
                wk.WIDGET: Node
            },
            gk.BOX_CAPTION: {
                wk.LABELS: (
                    gk.PER_CELL_GROUP_CAPTION,
                    gk.FACE_1_CAPTION,
                    gk.FACE_2_CAPTION,
                    gk.FACE_3_CAPTION
                ),
                wk.WIDGET: Node
            },
            gk.BOX_CELL: {
                wk.LABELS: (
                    gk.TYPE_BOX,
                    gk.PER_CELL_MARGIN,
                    gk.PER_CELL_BOX_PLAQUE,
                    gk.BOX_FACE,
                    gk.PER_CELL_BOX_CAPTION
                ),
                wk.WIDGET: Node
            },
            gk.BOX_FACE: {
                wk.LABELS: (
                    gk.BOX_PLAQUE,
                    gk.BOX_FRINGE,
                    gk.BOX_BORDER,
                    gk.BOX_PLACE,
                    gk.BOX_MASK,
                    gk.BOX_CAPTION
                ),
                wk.WIDGET: Node
            },
            gk.BOX_FRINGE: {
                wk.LABELS: (
                    gk.PER_CELL_GROUP_FRINGE,
                    gk.FACE_1_FRINGE,
                    gk.FACE_2_FRINGE,
                    gk.FACE_3_FRINGE
                ),
                wk.WIDGET: Node
            },
            gk.BOX_MASK: {
                wk.LABELS: (
                    gk.PER_CELL_GROUP_MASK,
                    gk.FACE_1_MASK,
                    gk.FACE_2_MASK,
                    gk.FACE_3_MASK
                ),
                wk.WIDGET: Node
            },
            gk.BOX_MODEL: {
                wk.LABELS: (
                    gk.BOX_PROPERTY,
                    gk.CANVAS_GRID,
                    gk.BOX_CELL,
                    gk.PRESET_BOX,
                    gk.IMAGE_EFFECT,
                    gk.BLUR_BEHIND
                ),
                wk.WIDGET: Node
            },
            gk.BOX_PLACE: {
                wk.LABELS: (
                    gk.PER_CELL_GROUP_PLACE,
                    gk.FACE_1_PLACE,
                    gk.FACE_2_PLACE,
                    gk.FACE_3_PLACE
                ),
                wk.WIDGET: Node
            },
            gk.BOX_PLAQUE: {
                wk.LABELS: (
                    gk.PER_CELL_GROUP_PLAQUE,
                    gk.FACE_1_PLAQUE,
                    gk.FACE_2_PLAQUE,
                    gk.FACE_3_PLAQUE
                ),
                wk.WIDGET: Node},
            gk.BOX_PROPERTY: simple_type,
            gk.CANVAS_BORDER: grid_type,
            gk.CANVAS_CAPTION: grid_type,
            gk.CANVAS_FRINGE: grid_type,
            gk.CANVAS_GRID: {
                wk.LABELS: (
                    gk.CANVAS_MARGIN,
                    gk.CANVAS_PLAQUE,
                    gk.CANVAS_FRINGE,
                    gk.CANVAS_BORDER,
                    gk.CANVAS_CAPTION
                ),
                wk.WIDGET: Node
            },
            gk.CANVAS_MARGIN: grid_type,
            gk.CANVAS_PLAQUE: grid_type,
            gk.CAPTION_BEHIND: BEHIND_TYPE,
            gk.CELL_CAPTION: view_type,
            gk.CUSTOM_CELL_CAPTION: grid_type,
            gk.CUSTOM_CELL_BORDER: grid_type,
            gk.CUSTOM_CELL_CELL: {
                wk.LABELS: (
                    gk.TYPE_CUSTOM_CELL,
                    gk.RECTANGLE,
                    gk.CUSTOM_CELL_MARGIN,
                    gk.CUSTOM_CELL_PLAQUE,
                    gk.CUSTOM_CELL_FRINGE,
                    gk.CUSTOM_CELL_BORDER
                ),
                wk.WIDGET: Node
            },
            gk.CUSTOM_CELL_FRINGE: grid_type,
            gk.CUSTOM_CELL_IMAGE: {
                wk.LABELS: (
                    gk.CUSTOM_CELL_PLACE,
                    gk.CUSTOM_CELL_MASK,
                    gk.CUSTOM_CELL_CAPTION
                ),
                wk.WIDGET: Node
            },
            gk.CUSTOM_CELL_MASK: grid_type,
            gk.CUSTOM_CELL_PLACE: grid_type,
            gk.CUSTOM_CELL_MARGIN: grid_type,
            gk.CUSTOM_CELL_MODEL: {
                wk.LABELS: (
                    gk.CUSTOM_CELL_PROPERTY,
                    gk.CUSTOM_CELL_CELL,
                    gk.CUSTOM_CELL_IMAGE,
                    gk.PRESET_CUSTOM_CELL,
                    gk.IMAGE_EFFECT,
                    gk.BLUR_BEHIND
                ),
                wk.WIDGET: Node
            },
            gk.CUSTOM_CELL_PLAQUE: grid_type,
            gk.CUSTOM_CELL_PROPERTY: simple_type,
            gk.EFFECT: {wk.LABELS: (gk.MODEL,), wk.WIDGET: Node},
            gk.FACE_1_BORDER: per_cell_type,
            gk.FACE_2_BORDER: per_cell_type,
            gk.FACE_3_BORDER: per_cell_type,
            gk.FACE_1_CAPTION: per_cell_type,
            gk.FACE_2_CAPTION: per_cell_type,
            gk.FACE_3_CAPTION: per_cell_type,
            gk.FACE_1_FRINGE: per_cell_type,
            gk.FACE_2_FRINGE: per_cell_type,
            gk.FACE_3_FRINGE: per_cell_type,
            gk.FACE_1_MASK: per_cell_type,
            gk.FACE_2_MASK: per_cell_type,
            gk.FACE_3_MASK: per_cell_type,
            gk.FACE_1_PLACE: per_cell_type,
            gk.FACE_2_PLACE: per_cell_type,
            gk.FACE_3_PLACE: per_cell_type,
            gk.FACE_1_PLAQUE: per_cell_type,
            gk.FACE_2_PLAQUE: per_cell_type,
            gk.FACE_3_PLAQUE: per_cell_type,
            gk.GLOBAL: {wk.WIDGET: NonPreset, wk.HAS_RANDOM: True},
            gk.GRADIENT_LIGHT: render_effect,
            gk.IMAGE_BEHIND: BEHIND_TYPE,
            gk.IMAGE_EFFECT: {wk.WIDGET: NonPreset, wk.HAS_RANDOM: True},
            gk.MODEL: simple_type,
            gk.PER_CELL_BORDER: per_cell_type,
            gk.PER_CELL_BOX_CAPTION: per_cell_type,
            gk.PER_CELL_BOX_PLAQUE: per_cell_type,
            gk.PER_CELL_CAPTION: per_cell_type,
            gk.PER_CELL_FRINGE: per_cell_type,
            gk.PER_CELL_GROUP_BORDER: group_type,
            gk.PER_CELL_GROUP_CAPTION: group_type,
            gk.PER_CELL_GROUP_FRINGE: group_type,
            gk.PER_CELL_GROUP_MASK: group_type,
            gk.PER_CELL_GROUP_PLACE: group_type,
            gk.PER_CELL_GROUP_PLAQUE: group_type,
            gk.PER_CELL_TYPE: per_cell_type,
            gk.PER_CELL_PLACE: per_cell_type,
            gk.PER_CELL_MASK: per_cell_type,
            gk.PER_CELL_PLAQUE: per_cell_type,
            gk.PER_CELL_MARGIN: per_cell_type,
            gk.PRESET_BOX: super_preset,
            gk.PRESET_CUSTOM_CELL: super_preset,
            gk.PRESET_STACK: super_preset,
            gk.PRESET_TABLE: super_preset,
            gk.PRESET_STEPS: super_preset,
            gk.PRESET_TRI_SHADOW: {
                wk.WIDGET: SuperPreset,
                wk.HAS_PRESET: True
            },
            gk.RECTANGLE: grid_type,
            gk.SHADOW_TYPE: simple_type,
            gk.STACK_CELL: {
                wk.LABELS: (
                    gk.TYPE_STACK,
                    gk.RECTANGLE,
                    gk.STACK_CELL_MARGIN,
                    gk.CUSTOM_CELL_PLAQUE,
                    gk.CUSTOM_CELL_FRINGE,
                    gk.CUSTOM_CELL_BORDER
                ),
                wk.WIDGET: Node
            },
            gk.STACK_CELL_MARGIN: grid_type,
            gk.STACK_IMAGE: {
                wk.LABELS: (
                    gk.PER_CELL_PLACE,
                    gk.PER_CELL_MASK,
                    gk.CUSTOM_CELL_CAPTION
                ),
                wk.WIDGET: Node
            },
            gk.STACK_MODEL: {
                wk.LABELS: (
                    gk.STACK_PROPERTY,
                    gk.STACK_CELL,
                    gk.STACK_IMAGE,
                    gk.PRESET_STACK,
                    gk.IMAGE_EFFECT,
                    gk.BLUR_BEHIND
                ),
                wk.WIDGET: Node
            },
            gk.STACK_PROPERTY: simple_type,
            gk.STEPS: {
                wk.LABELS: (
                    gk.GLOBAL,
                    gk.BACKDROP,
                    gk.GRADIENT_LIGHT,
                    gk.EFFECT,
                    gk.PRESET_STEPS
                ),
                wk.WIDGET: Node
            },
            gk.TABLE_CELL: {
                wk.LABELS: (
                    gk.PER_CELL_TYPE,
                    gk.PER_CELL_MARGIN,
                    gk.PER_CELL_PLAQUE,
                    gk.PER_CELL_FRINGE,
                    gk.PER_CELL_BORDER
                ),
                wk.WIDGET: Node
            },
            gk.TABLE_IMAGE: {
                wk.LABELS: (
                    gk.PER_CELL_PLACE,
                    gk.PER_CELL_MASK,
                    gk.PER_CELL_CAPTION
                ),
                wk.WIDGET: Node
            },
            gk.TABLE_MODEL: {
                wk.LABELS: (
                    gk.TABLE_PROPERTY,
                    gk.CANVAS_GRID,
                    gk.TABLE_CELL,
                    gk.TABLE_IMAGE,
                    gk.PRESET_TABLE,
                    gk.IMAGE_EFFECT,
                    gk.BLUR_BEHIND
                ),
                wk.WIDGET: Node
            },
            gk.TABLE_PROPERTY: simple_type,
            gk.TRI_SHADOW: {
                wk.LABELS: (
                    gk.SHADOW_TYPE,
                    ek.SHADOW_1,
                    ek.SHADOW_2,
                    ek.INNER_SHADOW,
                    gk.PRESET_TRI_SHADOW
                ),
                wk.WIDGET: Node
            },
            gk.TYPE_BOX: grid_type,
            gk.TYPE_CUSTOM_CELL: simple_type,
            gk.TYPE_STACK: grid_type
        }
