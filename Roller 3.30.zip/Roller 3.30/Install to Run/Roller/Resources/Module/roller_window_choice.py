#!/usr/bin/env python
# -*- coding: utf-8 -*-
from datetime import datetime
from random import randint, seed
from roller_constant_for import Widget as fw
from roller_constant_key import Widget as wk, Window as wi
from roller_one import Hat
from roller_option_group import OptionGroup
from roller_option_preset import NonPreset
from roller_port_preview import PortPreview
from roller_widget_box import Box, Eventful
from roller_widget_button import Button, PreviewButton
from roller_widget_label import Label
from roller_widget_tree import ChoiceList
from roller_window import Window
import gtk


class RWChoice(Window):
    """Is a GTK Dialog with a list for the user to select an item."""

    def __init__(self, g):
        """
        Create a choice Window.

        g: OptionButton
            Has a value.
            Is responsible.
        """
        self.safe = g
        d = {}
        k = g.key
        d[wk.WIN] = g.win.win
        d[wk.WINDOW_TITLE] = "Choose a {}".format(k)
        d[wk.WINDOW_KEY] = wi.CHOOSER

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortChoice(d, g, k)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()


class PortChoice(PortPreview):
    """Is a Port for the ChoiceWindow Widgets."""

    def __init__(self, d, g, k):
        """
        Create the widgets.

        d: dict
            Has initial Widget values.

        g: OptionButton
            Has a Widget value.

        k: string
            name of choice
        """
        self._key = k
        self.group = OptionGroup(
            **{
                wk.CONTAINER: None,
                wk.GROUP_KEY: k,
                wk.GROUP_TYPE: NonPreset,
                wk.STEP: (k,)
            }
        )

        seed(datetime.now())
        PortPreview.__init__(self, d, g)

    def _draw_list_group(self, g):
        """
        Draw the list group.

        g: GTK container
            for list group
        """
        key = self._key

        # without the case-sensitive
        for i in ('radient', 'rush', 'ont', 'attern'):
            if i in key:
                break

        q = self._list = {
            'rush': Hat.cat.brush_list,
            'ont': Hat.cat.font_list,
            'radient': Hat.cat.gradient_list,
            'attern': Hat.cat.pattern_list
        }[i]
        choice = self.safe.get_value()
        self.choice_list = ChoiceList(
            **{
                wk.CONTAINER: g,
                wk.LIST: q,
                wk.CHOICE: choice,
                wk.ON_KEY_PRESS: self.on_key_press,
                wk.ON_WIDGET_CHANGE: self.on_widget_change
            }
        )
        self.treeview = self.choice_list.treeview

    def draw_process_group(self, g):
        """
        Draw a group with process Buttons.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        w1 = w // 2
        hbox = Box(box=gtk.HBox, align=(0, 0, 1, 1))
        q = (
            Button(
                align=(0, 0, 1, 0),
                on_widget_change=self._cancel,
                padding=(w, w, w, w1),
                text="Cancel"
            ),
            Button(
                align=(0, 0, 1, 0),
                on_widget_change=self.randomize,
                padding=(w, w, w1, w1),
                text="Randomize"
            ),
            PreviewButton(
                align=(0, 0, 1, 0),
                group=self.group,
                on_preview_button=self.task_preview,
                padding=(w, w, w1, w1),
            ),
            Button(
                align=(0, 0, 1, 0),
                on_widget_change=self.accept_preview,
                padding=(w, w, w1, w),
                text="Accept"
            )
        )

        for i in q:
            hbox.add(i)

        self._preview_button = q[2]

        g.add(hbox)
        self.keep(q)

    def draw_port(self, g):
        """
        Draw the Port's Widgets. Is part of the Port template.

        g: VBox
            container for the Widgets
        """
        q = self._draw_list_group, self.draw_process_group
        name = "Available {}".format(self._key), ""

        for x, p in enumerate(q):
            box = Eventful(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if name[x]:
                vbox.pack_start(
                    Label(
                        padding=(4, 4, 4, 4),
                        text=name[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()
            g.pack_start(box, expand=(True, False)[x])
        self.roller_window.win.vbox.set_size_request(350, 390)

    def get_group_value(self):
        """
        Use to get the value of the list selection.
        Is a PortPreview template function.

        Return: string
            Is the choice from the choice list.
        """
        sel = self.treeview.get_selection()

        if sel:
            model, iter_ = sel.get_selected()
            if iter_:
                return model.get_value(iter_, 0)
        return self._list[0]

    def randomize(self, _):
        """
        Randomize a choice in the list.

        _: Button
            Is responsible.
            no use
        """
        if len(self._list):
            self.choice_list.select_item(randint(0, len(self._list) - 1))
