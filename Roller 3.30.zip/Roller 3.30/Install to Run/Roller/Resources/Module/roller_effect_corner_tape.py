#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import atan2, cos, sin, radians
from random import randint, uniform
from roller_constant_for import Bump as fb, Stack as st
from roller_constant_key import Model as md, Option as ok
from roller_one_fu import Lay, Sel
from roller_one import Hat, Rect
from roller_one_extract import Step
from roller_option_preset_dict import PresetDict
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
from roller_render_shadow import do_extra_shadow
import gimpfu as fu

pdb = fu.pdb
FOUR_COORDINATES = 4

# oriented with zero at the north direction
RADIAN_135 = 2.35619
RADIAN_180 = 3.14159
RADIAN_225 = 3.92699
RADIAN_270 = 4.71239
RADIAN_315 = 5.49779
RADIAN_45 = .785398
RADIAN_90 = 1.5708


def blur_behind_tape(z, blur):
    """
    Blur behind the tape.

    z: layer
        with tape material

    blur: int
        amount of Blur Behind

    Return: layer
        with blurred tape material
    """
    if z:
        z1 = Lay.clone_background(z)
        z2 = Lay.clone_opaque(z)

        Lay.blur(z1, blur)
        pdb.gimp_drawable_curves_spline(
            z1,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            (.0, .0, 1., .92)
        )
        Sel.item(z2)
        Sel.invert_clear(z1)
        Lay.remove(z2)
        return Lay.merge(z)


def calc_bounds(j, o):
    """
    Calculate the rotated bounds of the
    work-in-progress image in its original size.

    Calculate the transform amount for the x, y vectors.
    The goal of the transform is to calculate
    the corner points of the cell-sized image.

    The function only works when the original image size ratio
    is the same as the cell image's size ratio. The Locked Resize
    Method will leave the ratio the same, but the other Resize
    Methods modify this ratio.

    j: Image
        Has size.
    """
    q = o.corners = []
    w, h = j.size

    # center
    w, h = w // 2, h // 2

    for i in range(4):
        if not i:
            x, y = -w, h

        elif i == 1:
            x, y = w, h

        elif i == 2:
            x, y = w, -h

        else:
            x, y = -w, -h

        x, y = get_point(
            0,
            0,
            atan2(x, y) + o.rotate,
            ((x**2) + (y**2))**0.5
        )
        o.corners.append((x, y))

    x_points = q[0][0], q[1][0], q[2][0], q[3][0]
    y_points = q[0][1], q[1][1], q[2][1], q[3][1]
    u = min(x_points), min(y_points)
    v = max(x_points), max(y_points)
    u = abs(u[0] - v[0]), abs(u[1] - v[1])
    o.transform = (
        o.rect.w / 1. / u[0],
        o.rect.h / 1. / u[1]
    )


def do_bottom_left(o, x, y):
    """
    Make a selection for the bottom-left corner.

    o: One
        with options

    x, y: int
        corner point
    """
    d = o.d
    angle = RADIAN_135 + get_angle_shift(d) + o.rotate
    x, y = get_rotated_corner(o, x, y, 3)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def do_bottom_right(o, x, y):
    """
    Make a selection for the bottom-right corner.

    o: One
        with options

    x, y: int
        corner point
    """
    d = o.d
    angle = RADIAN_45 + get_angle_shift(d) + o.rotate
    x, y = get_rotated_corner(o, x, y, 2)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def do_custom_cell(j, o):
    """
    Do the Image Effect for a custom cell.

    j: GIMP image
        Is render.

    o: One
        Has options.
    """
    cat = Hat.cat
    k = o.model_name

    cat.join_selection(k)
    if Sel.is_sel(j):
        o.rotate = radians(
            Step.get_place_form(
                o
            )[ok.ROTATE] + o.model.get_rotation(0, 0)
        )
        image_shadow = do_extra_shadow(o, o.image_layer)
        group = Lay.group(j, o.k, parent=o.parent)

        cat.join_selection(k)
        do_image(j, group, o)

        z = do_layer(j, group, image_shadow, o)
        return [z, image_shadow]


def do_face(j, o):
    """
    Do the Image Effect for each Face.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        with Image Effect
    """
    pdb.gimp_selection_none(j)

    for i in o.image_layer.layers:
        if i:
            Sel.item(i, option=fu.CHANNEL_OP_ADD)
    if Sel.is_sel(j):
        # Make a temp image layer for the effect to work with.
        image_layer = Lay.add_above(o.image_layer, n="Temp")

        Sel.fill(image_layer, (0, 0, 0))

        o.rotate = .0
        image_shadow = do_extra_shadow(o, image_layer)
        group = Lay.group(j, o.k, parent=o.parent)

        Sel.item(image_layer)
        do_image(j, group, o)

        z = do_layer(j, group, image_shadow, o)

        Lay.remove(image_layer)
        return [z, image_shadow]


def do_image(j, parent, o, r=0, c=0):
    """
    Add tape to an image. Select the image material prior to calling.

    j: GIMP image
        Is render.

    parent: layer
        group for different images

    o: One
        Has variables.

    r, c: int
        cell table index
        Use with the Table Model.
    """
    z = Lay.add(j, o.k, parent=parent)
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    w = x1 - x
    h = y1 - y
    o.center = x + w // 2, y + h // 2
    o.rect = Rect(x, y, w, h)
    d = o.d

    if o.rotate:
        j1 = o.model.get_image(r, c)
        calc_bounds(j1, o)

    pdb.gimp_selection_none(j)
    do_topleft(o, x, y)
    do_top_right(o, x + w, y)
    do_bottom_left(o, x, y + h)
    do_bottom_right(o, x + w, y + h)
    Sel.fill(z, d[ok.COLOR_1A])
    GradientLight.apply_light(z, ok.OTHER_FRAME)


def do_layer(j, group, image_shadow, o):
    """
    Finish processing a layer with Corner Tape.

    j: GIMP image
        Is render.

    group: layer
        with corner tape material layers

    image_shadow: layer
        with shadow

    o: One
        Has variables.

    Return: layer
        with Corner Tape material
    """
    z = Lay.merge_group(group)
    group = Lay.group(j, Lay.name(z.parent, o.k), parent=z.parent, z=z)
    z1 = Lay.clone(z)
    e = PresetDict.get_default(ok.BUMP)
    e[ok.BUMP_TYPE] = fb.NOISE
    e[ok.BUMP_DEPTH] = 1
    z1 = RenderHub.bump(z1, e)

    Lay.blur(z1, 2)
    pdb.gimp_drawable_invert(z1, 0)

    z1.mode = fu.LAYER_MODE_DIFFERENCE
    z1.opacity = 66.
    z2 = Lay.clone(z1)
    z2.mode = fu.LAYER_MODE_LCH_HUE
    z2.opacity = 24.
    z3 = Lay.clone(z2)
    z3.mode = fu.LAYER_MODE_NORMAL
    z3.opacity = 2.
    z4 = Lay.clone(z)
    z4.mode = fu.LAYER_MODE_HSL_COLOR

    # Darken the edge.
    Sel.item(z4)
    pdb.gimp_selection_shrink(j, 1.)
    Sel.invert(j)
    pdb.gimp_drawable_curves_spline(
        z4,
        fu.HISTOGRAM_VALUE,
        FOUR_COORDINATES,
        (.0, .0392, 1., .3137)
    )

    # Place on top.
    pdb.gimp_image_reorder_item(j, z4, group, 0)

    z5 = Lay.clone(z4)
    z5.mode = fu.LAYER_MODE_OVERLAY

    # rough edge, 'z6'
    z6 = Lay.clone_opaque(z)

    pdb.gimp_image_reorder_item(j, z6, None, 0)

    pdb.plug_in_shift(j, z6, 2, 0)
    pdb.plug_in_shift(j, z6, 2, 1)
    Lay.blur(z6, 2)
    pdb.gimp_drawable_invert(z1, 0)

    z = Lay.merge_group(group)

    # Apply rough edge.
    Sel.item(z6)
    Sel.invert_clear(z)
    j.remove_layer(z6)

    # Clear the shadow behind the tape.
    Sel.item(z)
    Lay.clear_sel(image_shadow)

    # Corner Tape Preset dict, 'o.d'
    z = blur_behind_tape(z, o.d[ok.BLUR_BEHIND])

    return z


def do_table(j, o):
    """
    Do the Image Effect for Table Model cells.

    j: GIMP image
        Is render.

    o: One
        Has options.

    Return: list
        of undo layers
    """
    # Do one image at a time.
    d = o.model.d
    is_merge_cell = o.model.is_merge_cell
    z1 = o.image_layer
    cat = Hat.cat
    undo_z = []
    row, column = o.r, o.c
    s = 1

    if o.is_nested_group:
        for i in z1.layers:
            # the z-height of the image layer, 'h'
            h = i.name.split(" ")[-1]
            group = None

            for r in range(row):
                for c in range(column):
                    if is_merge_cell:
                        s = d[ok.PER_CELL][r][c]

                    # Is it a dependent cell?
                    if s != (-1, -1):
                        k = o.model_name, r, c
                        if cat.get_z_height(k) == h:
                            cat.join_selection(k)
                            o.r, o.c = r, c
                            if Sel.is_sel(j):
                                o.rotate = radians(
                                    Step.get_place_form(
                                        o
                                    )[ok.ROTATE] + o.model.get_rotation(
                                        r, c
                                    )
                                )
                                if not group:
                                    group = Lay.group(
                                        j,
                                        o.k,
                                        parent=i
                                    )
                                do_image(j, group, o, r=r, c=c)
            if group:
                image_shadow = do_extra_shadow(o, i.layers[-1])
                z = do_layer(j, group, image_shadow, o)
                undo_z += [z, image_shadow]
    else:
        group = None

        for r in range(row):
            for c in range(column):
                if is_merge_cell:
                    s = d[ok.PER_CELL][r][c]

                # Is it a dependent cell?
                if s != (-1, -1):
                    o.r, o.c = r, c
                    k = o.model_name, r, c
                    cat.join_selection(k)
                    if Sel.is_sel(j):
                        o.rotate = radians(
                            Step.get_place_form(
                                o
                            )[ok.ROTATE] + o.model.get_rotation(r, c)
                        )
                        if not group:
                            group = Lay.group(
                                j,
                                o.k,
                                parent=o.parent
                            )
                        do_image(j, group, o, r=r, c=c)
        if group:
            image_shadow = do_extra_shadow(o, o.image_layer)
            z = do_layer(j, group, image_shadow, o)
            undo_z = [z, image_shadow]
    return undo_z


def do_topleft(o, x, y):
    """
    Make a selection for the topleft corner.

    o: One
        Has options.

    x, y: int
        corner point
    """
    d = o.d
    angle = RADIAN_225 + get_angle_shift(d) + o.rotate
    x, y = get_rotated_corner(o, x, y, 0)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def do_top_right(o, x, y):
    """
    Make a selection for the top-right corner.

    o: One
        with options

    x, y: int
        center point
    """
    d = o.d
    angle = RADIAN_315 + get_angle_shift(d) + o.rotate
    x, y = get_rotated_corner(o, x, y, 1)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def get_angle_shift(d):
    """
    Randomize the angle-shift amount.

    d: dict
        Corner Tape Preset dict

    Return: float
        angle shift
    """
    f = d[ok.ANGLE_SHIFT]
    return uniform(radians(-f), radians(f))


def get_corner_shift(d):
    """
    Randomize corner-shift amount.

    d: dict
        Corner Tape Preset dict

    Return: int
        corner shift
    """
    a = d[ok.CORNER_SHIFT]
    return randint(-a, a)


def get_point(x, y, angle, radius):
    """
    Return a point on a circle that corresponds to a rotation.

    x, y: int
        center point

    angle : float
        rotation angle in radians

    radius: float
        the radius of the circle in pixels

    Returns:
        x : float
        y : float
        the point on the circle
    """
    x = (sin(angle) * radius) + x
    y = (cos(angle) * -radius) + y
    return round(x), round(y)


def get_rotated_corner(o, x, y, corner_x):
    """
    o: One
        Has options.

    x, y: int
        corner point

    corner_x: int
        index to corner point

    Return: tuple
        of int
        corner point
    """
    if o.rotate:
        x1, y1 = o.corners[corner_x]
        x1 *= o.transform[0]
        y1 *= o.transform[1]
        x = x1 + o.center[0]
        y = y1 + o.center[1]

    x += get_corner_shift(o.d)
    y += get_corner_shift(o.d)
    return x, y


def get_tape_length(d):
    """
    Calculate a tape's length.

    d: dict
        Has options.

    Return: int
        tape length
    """
    return max(
        1,
        d[ok.TAPE_LENGTH] + randint(-d[ok.LENGTH_SHIFT], d[ok.LENGTH_SHIFT])
    )


def select_tape_rect(d, angle, x, y, w):
    """
    Define and select a tape rectangle.

    d: dict
        Has options.

    x, y: int
        start point

    w: int
        length of tape
    """
    w1 = d[ok.TAPE_WIDTH]
    x1, y1 = get_point(x, y, angle - RADIAN_90, w1)
    x2, y2 = get_point(x1, y1, angle - RADIAN_180, w)
    x3, y3 = get_point(x2, y2, angle - RADIAN_270, w1)
    Sel.polygon(
        Hat.cat.render.image,
        (x, y, x1, y1, x2, y2, x3, y3),
        option=fu.CHANNEL_OP_ADD
    )


class CornerTape:
    """Simulate a tape image holder."""

    @staticmethod
    def do(o):
        """
        Do a Corner Tape Image Effect. Is an Image Effect template function.

        o: One
            Has variables.

        Return: layer or list of layers
            with Corner Tape
        """
        cat = Hat.cat
        j = cat.render.image

        # Corner Tape Preset dict, 'o.d'
        d = o.d

        undo_z = []
        o.shadow_layer = []

        cat.seed(d)

        if o.model_type == md.TABLE:
            undo_z = do_table(j, o)

        elif o.model_type == md.BOX:
            undo_z = do_face(j, o)

        elif o.model_type == md.STACK:
            if o.model.image_group_type == st.EACH_HAS_GROUP:
                undo_z = do_table(j, o)
            else:
                z = o.image_layer

                Sel.item(z)
                if Sel.is_sel(j):
                    o.rotate = .0
                    group = Lay.group(j, o.k, parent=z.parent)
                    z1 = Lay.clone(z)
                    z2 = do_extra_shadow(o, z1)

                    if z2:
                        pdb.gimp_image_reorder_item(
                            j, z2,
                            z.parent,
                            Lay.offset(o.image_layer) + 1
                        )

                    Lay.remove(z1)
                    Sel.item(z)
                    do_image(j, group, o)

                    z = do_layer(j, group, z2, o)
                    undo_z = [z, z2]

        else:
            undo_z = do_custom_cell(j, o)
        return undo_z
