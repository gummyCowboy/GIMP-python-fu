#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Fringe as ng,
    Gradient as fg,
    Shape as sh,
    Triangle as ft
)
from roller_constant_key import Layer as nk, Option as ok, Step as sk
from roller_constant_fu import Fu
from roller_model_image import Image
from roller_one import Hat, One
from roller_one_extract import dispatch, Form, Render, Shape, Step
from roller_one_fu import Lay, Mage, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
pb = Fu.PaintBrush
FRINGE_MAT = (
    ng.AS_IS,
    ng.BACKDROP,
    ng.COLOR,
    ng.GRADIENT,
    ng.IMAGE,
    ng.PATTERN,
    ng.PLASMA
)


def apply_brush(z, q):
    """
    Perform a brush application.

    z: layer
        to receive brush strokes

    q: tuple
        x, y
        position of stroke
    """
    pdb.gimp_paintbrush(
        z,
        pb.NO_FADE_OUT,
        pb.STROKES_2,
        q,
        fu.PAINT_CONSTANT,
        pb.GRADIENT_LENGTH_0
    )


def apply_light(z):
    """
    Apply Gradient Light to a Fringe layer.

    z: layer or None
        with Fringe material

    Return: layer or None
        with Fringe and light applied
    """
    if z and Lay.has_pixel(z):
        z = GradientLight.apply_light(z, ok.FRINGE_INFLUENCE)
    return z


def complete(z, d):
    """
    Complete the Fringe material with Bump and mode.

    z: layer
        with Fringe

    d: dict
        Fringe Preset

    Return: layer
        with Fringe material
    """
    z = RenderHub.do_mode(z, d)
    return RenderHub.bump(z, d[ok.BUMP])


def do_as_is(_, z, o):
    """
    Make Fringe from the brush's output.

    _: GIMP image
        Is render.

    z: layer
        Has Fringe material.

    o: One
        Has cell data.

    Return: layer
        Has image.
    """
    return complete(z, o.e)


def do_backdrop(_, z, o):
    """
    Make Fringe from the Fringe layer's background.

    _: GIMP image
        Is render.
        not used

    z: layer
        Has Fringe material.

    o: One
        Has cell data.

    Return: layer
        Has image.
    """
    z1 = Lay.clone_background(z)

    transfer_sel(z, z1)
    return complete(z1, o.e)


def do_brush(j, z, o):
    """
    Paint Fringe material using a selection provided by the caller.

    j: GIMP image
        Is render.

    z: layer
        to receive paint

    o: One
        Has variables.

    Return: layer
        with paint material
    """
    d = o.e
    e = d[ok.BRUSH_DICT]
    o.colors = None
    callback = None
    foreground = pdb.gimp_context_get_foreground()

    if o.is_plan:
        pdb.gimp_context_set_foreground(o.color)

    elif o.type_ == ng.COLOR:
        o.colors = d[ok.COLOR_6]
        callback = set_foreground_color
        o.index = o.max_index = d[ok.COLOR_COUNT_1_6] - 1

    else:
        if not hasattr(o, 'color'):
            o.color = pdb.gimp_context_get_foreground()

    pdb.gimp_selection_shrink(j, d[ok.CONTRACT])

    if Sel.is_sel(j):
        RenderHub.set_brush(e)
        pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
        pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
        pdb.gimp_context_set_brush_hardness(e[ok.BRUSH_HARDNESS])
        pdb.gimp_context_set_opacity(e[ok.OPACITY])
        pdb.plug_in_sel2path(j, z)
        if j.active_vectors:
            stroke = j.active_vectors.strokes[0]

            pdb.gimp_selection_none(j)
            RenderHub.brush_stroke_on_stroke(
                z,
                e[ok.BRUSH],
                e[ok.BRUSH_SIZE],
                stroke,
                e[ok.BRUSH_SPACING],
                e[ok.ANGLE_JITTER],
                callback=(callback, o)
            )

    pdb.gimp_context_set_foreground(foreground)
    return z


def do_cell(o, k):
    """
    Process the Fringe for a cell.

    o: One
        Has variables.

    k: string or tuple
        key to the cell's Plaque selection

    Return: layer or None
        with Fringe material
    """
    cat = Hat.cat
    z = None
    is_paint = o.type_ != ng.MASK
    o.is_paint |= is_paint
    j = cat.render.image

    if is_paint:
        z = Lay.add(j, o.name, parent=o.group)
        z = do_paint(j, z, o)
        if hasattr(o, 'mask_sel'):
            o.mask_sel += [cat.get_plaque_sel(k)]

    else:
        # The Fringe Mask-type option is dependent
        # on a cell's corresponding Plaque.
        d = o.plaque_dict
        opacity = d[ok.OPACITY]
        if opacity and o.type_ != "None":
            do_mask(o, k)
    return z


def do_gradient(j, z, o):
    """
    Make a Gradient Fringe.

    j: GIMP image
        Is render.

    z: layer
        Has material to select.

    o: One
        Has cell data.

    Return: layer
        Has Fringe material.
    """
    def draw_gradient(_start_x, _end_x, _start_y, _end_y):
        """
        Draw a Gradient given a layer, a start-point and an end-point.
        """
        pdb.gimp_drawable_edit_gradient_fill(
            z1,
            fg.GRADIENT_TYPE_LIST.index(gradient_type),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            _start_x, _start_y,
            _end_x, _end_y
        )

    def finish_gradient():
        transfer_sel(z, z1)
        return complete(z1, o.e)

    Sel.item(z)

    z1 = None
    is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
    w, h = x1 - x, y1 - y
    if is_sel:
        gradient_type = o.e[ok.GRADIENT_TYPE]

        RenderHub.set_fill_context(fg.FILL_DICT)
        RenderHub.set_gradient(o.e)
        pdb.gimp_context_set_gradient_blend_color_space(
            fu.GRADIENT_BLEND_RGB_PERCEPTUAL
        )
        pdb.gimp_context_set_gradient_reverse(0)

        if gradient_type in fg.SHAPE_BURST:
            j1 = pdb.gimp_image_new(w, h, fu.RGB)
            z1 = Lay.add(j1, '')

            pdb.gimp_selection_all(j1)
            Sel.fill(z1, (127, 127, 127))
            pdb.gimp_selection_none(j1)
            draw_gradient(0, 0, 0, 0)
            Mage.copy_all(j1)
            pdb.gimp_image_delete(j1)

            z1 = Lay.paste(z)
            z1.name = o.name

            pdb.gimp_layer_set_offsets(z1, x, y)
            z1 = finish_gradient()
        else:
            z1 = Lay.add(j, o.name, parent=o.group)
            start_x, end_x, start_y, end_y = \
                RenderHub.get_gradient_points(
                    o.e[ok.GRADIENT_ANGLE],
                    x, y,
                    w, h
                )

            Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
            draw_gradient(start_x, end_x, start_y, end_y)
            z1 = finish_gradient()
    return z1 if z1 else z


def do_image(j, z, o):
    """
    Make an image Fringe.

    j: GIMP image
        Is render.

    z: layer
        Has Fringe material.

    o: One
        Has cell data.

    Return: layer or None
        Has Fringe material.
    """
    z1 = None

    Sel.item(z)

    a, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
    w, h = x1 - x, y1 - y

    if a:
        pdb.gimp_selection_none(j)

        image = o.e[ok.IMAGE]
        j1 = Image.get_image(image, o.image_index)
        if j1:
            j2 = j1.j

            Mage.copy_all(j2)

            j2 = pdb.gimp_edit_paste_as_new_image()

            Mage.shape(j2, w, h)

            z1 = Lay.paste(z)

            pdb.gimp_layer_set_offsets(z1, x, y)
            Image.close_image(j1)
            transfer_sel(z, z1)
            z1 = complete(z1, o.e)
    return z1 if z1 else z


def do_mask(o, k):
    """
    Mask the edge of a Plaque.

    o: One
        Has variables.

    k: string or tuple
        key to the Plaque selection

    plaque_name: string
        to find the Fringe layer's Plaque layer
    """
    cat = Hat.cat
    j = cat.render.image
    d = o.plaque_dict
    opacity = d[ok.OPACITY]
    plaque_type = d[ok.PLAQUE_TYPE]
    if opacity and plaque_type != "None":
        z = o.plaque_layer
        if z:
            # mask layer, 'z1'
            z1 = Lay.add(j, 'Mask', parent=o.parent)
            sel = cat.get_plaque_sel(k)

            Sel.load(j, sel)

            if Sel.is_sel(j):
                z1 = do_brush(j, z1, o)
                o.is_mask = True

                Sel.item(z1)
                Sel.invert(j)
                Sel.load(j, sel, option=fu.CHANNEL_OP_INTERSECT)

                if o.is_grid:
                    o.mask_sel += [cat.save_short_term_sel()]
                else:
                    mask = pdb.gimp_layer_create_mask(
                        z,
                        fu.ADD_MASK_SELECTION
                    )
                    pdb.gimp_layer_add_mask(z, mask)
            j.remove_layer(z1)


def call_complete(_, z, o):
    """
    Complete the one color Fringe.

    _: GIMP image
        Is render.
        not used

    z: layer
        Has Fringe material.

    o: One
        Has variables.

    Return: layer or None
        Has Fringe material.
    """
    return complete(z, o.d)


def do_paint(j, z, o):
    """
    Paint a Fringe texture on a Fringe layer.

    j: GIMP image
        Is render.

    z: layer
        for Fringe material

    o: One
        Has variables.

    Return: layer or None
        Has Fringe material.
    """
    def clip_cell():
        """Remove material outside of the cell shape."""
        if o.is_clip:
            if o.is_face:
                Sel.shape(j, o.model.get_face(o.face_x, o.r, o.c))

            else:
                b = o.model.get_cell_definition(o.e, o.r, o.c)[1]
                Sel.shape(j, b)

            Sel.invert(j)
            Lay.clear_sel(z)

    # 'Fringe Preset dict, 'o.e'
    d = o.e

    pdb.gimp_selection_none(j)
    Sel.shape(j, o.plaque)

    if Sel.is_sel(j):
        # Use with the clip option.
        sel = pdb.gimp_selection_save(j)

        z = do_brush(j, z, o)

        Sel.item(z)

        if Sel.is_sel(j):
            if o.is_plan:
                clip_cell()
            else:
                if o.type_ in FRINGE_MAT:
                    # Apply material and clear outside
                    # of the Fringe selection.
                    z = fringe_job[o.type_](j, z, o)

                    if z:
                        clip_cell()
                        if all(
                            (
                                Shadow.get_type(d[ok.TRI_SHADOW]),
                                not o.is_plan,
                                z
                            )
                        ):
                            z = Shadow.do_shadows(d[ok.TRI_SHADOW], z)
                            clip_cell()
                    if z:
                        z.name = o.name
        pdb.gimp_image_remove_channel(j, sel)
    return z


def do_pattern(j, z, o):
    """
    Make a Pattern Fringe.

    j: GIMP image
        Is render.

    z: layer
        Has paint.

    o: One
        Has cell data.

    Return: layer or None
        Has Pattern material.
    """
    z1 = None

    pdb.gimp_selection_all(j)

    a, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
    w, h = x1 - x, y1 - y
    if a:
        z1 = Lay.add(j, o.name, parent=o.group)
        s = Render.size()

        Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
        RenderHub.set_fill_context(fg.FILL_DICT)
        RenderHub.set_pattern(o.e)
        pdb.gimp_drawable_edit_bucket_fill(
            z1,
            fu.FILL_PATTERN,
            min(s[0] - 1, x + w // 2),
            min(s[1] - 1, y + h // 2)
        )
        transfer_sel(z, z1)

        # Fringe Preset dict, 'o.e'
        z1 = complete(z1, o.e)
    return z1 if z1 else z


def do_plasma(j, z, o):
    """
    Make a Plasma Fringe.

    j: GIMP image
        Is render.

    z: layer
        Has material to select.

    o: One
        Has cell data.

    Return: layer
        Has Fringe material.
    """
    z1 = Lay.add_above(z)

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z1, o.e[ok.RANDOM_SEED], 3)
    transfer_sel(z, z1)
    return complete(z1, o.e)


def get_position_info(o):
    """
    Return position info.

    o: One
        Has cell data.
    """
    return o.x, o.y, o.w, o.h


def set_foreground_color(o):
    """
    Set the foreground color for the brush to use.
    Rotate through the color option if using multiple colors.
    """
    if hasattr(o, 'colors'):
        if o.colors:
            o.index = o.index + 1 if o.index < o.max_index else 0
            o.color = o.colors[o.index]
        pdb.gimp_context_set_foreground(o.color)


def transfer_sel(z, z1):
    """
    Transfer the alpha selection from the painted
    Fringe layer to the material Fringe layer.

    z: layer
        with painted Fringe

    z1: layer
        with Fringe material
    """
    if z:
        Sel.item(z)
        Sel.invert_clear(z1)
        z.image.remove_layer(z)


class Fringe:
    """Provide Fringe functionality access."""

    @staticmethod
    def do_box(o, is_plan):
        """
        Do the Cell Face Fringe for a Box Model.

        o: One
            Has variables.

        Return: layer or None
            with Fringe material
        """
        def _act():
            """Use to lower indentation."""
            _m = True
            _arg = face_x, r, c
            _k = (o.model_name,) + _arg

            if _m:
                # Is the cell a sub-topleft cell?
                if is_merge_cell:
                    if o.model.d[ok.PER_CELL][r][c] == (-1, -1):
                        _m = False

            if _m:
                _m = Shape.is_double_cell(o.model.double_type, r, c)

            if _m:
                o.r, o.c = r, c
                _e = o.e = is_per_cell[r][c] if is_per_cell else d
                _rect = o.model.get_face_rect(*_arg)
                o.plaque = o.model.get_face(*_arg)
                o.x, o.y = _rect.position
                o.w, o.h = _rect.size
                o.type_ = _e[ok.FRINGE_TYPE]
                _m = o.type_ != "None"

            if _m:
                _m = True if _e[ok.BRUSH_DICT][ok.OPACITY] else False

            if _m:
                o.is_clip = _e[ok.CLIP_TO_CELL]

                if plaque_d[ok.PER_CELL]:
                    o.plaque_dict = plaque_d[ok.PER_CELL][r][c]

                else:
                    o.plaque_dict = plaque_d

                if not o.group:
                    o.group = Lay.group(j, o.name, parent)
                do_cell(o, _k)
            else:
                o.mask_sel += [cat.get_plaque_sel(_k)]

        cat = Hat.cat
        j = cat.render.image
        z = None

        # Fringe Preset dict, 'o.d'
        d = o.d

        parent = cat.get_layer((o.render_type, o.model_name, nk.FRINGE))
        o.name = Lay.name(parent, nk.CELL_FRINGE)
        is_merge_cell = o.model.is_merge_cell
        o.group = None
        o.is_plan = is_plan
        o.shape = o.model.cell_shape
        row, column = o.model.division
        is_per_cell = d[ok.PER_CELL]
        go = o.is_grid = o.is_face = True
        o.is_mask = o.is_paint = False
        o.mask_sel = []
        face_x = o.face_x = Step.get_face_index(o.step)
        plaque_d = Form.get_face_chunk_from_step(
            o.step,
            sk.PLAQUE,
            face_x
        )
        pdb.gimp_selection_none(j)

        if not is_per_cell and d[ok.FRINGE_TYPE] == "None":
            go = False

        if go:
            for r in range(row):
                for c in range(column):
                    _act()

        if o.group:
            if o.is_paint:
                z = Lay.merge_group(o.group)
            else:
                j.remove_layer(o.group)
                z = None

        if o.is_mask:
            pdb.gimp_selection_none(j)

            for i in o.mask_sel:
                Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
            if Sel.is_sel(j):
                z1 = o.plaque_layer
                mask = pdb.gimp_layer_create_mask(z1, fu.ADD_MASK_SELECTION)
                pdb.gimp_layer_add_mask(z1, mask)

        if not is_plan:
            z = apply_light(z)
            if z:
                z.name = Lay.name(
                    o.parent,
                    "Cell Fringe Face " + str(face_x + 1)
                )
        return z

    @staticmethod
    def do_canvas(o, is_plan):
        """
        Do Canvas Fringe.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer
            with Fringe material
        """
        # Fringe Preset dict,'o.d'
        d = o.e = o.d

        z = None
        cat = Hat.cat
        o.type_ = d[ok.FRINGE_TYPE]
        o.is_mask = o.is_face = o.is_grid = o.is_paint = False
        if o.type_ != "None":
            j = cat.render.image

            # Preserve.
            foreground = pdb.gimp_context_get_foreground()

            parent = o.group = o.parent
            o.is_plan = is_plan
            o.shape = sh.RECTANGLE
            size = Render.size()

            if d[ok.OBEY_MARGINS]:
                o.y, bottom, o.x, right = o.model.canvas_margin
                o.w = size[0] - o.x - right
                o.h = size[1] - o.y - bottom

            else:
                o.x = o.y = 0
                o.w, o.h = size

            w, h = o.x + o.w, o.y + o.h
            o.plaque = o.x, o.y, w, o.y, w, h, o.x, h
            e = o.plaque_dict = Step.get_canvas_plaque(o.step)
            o.name = Lay.name(parent, nk.CANVAS_FRINGE)
            is_paint = o.is_paint = o.type_ != ng.MASK

            if is_paint:
                o.is_clip = True if d[ok.OBEY_MARGINS] \
                    and d[ok.CLIP_TO_CELL] else False

                z = Lay.add(j, o.name, parent=parent)
                z = do_paint(j, z, o)

            else:
                # Fringe's mask dependency
                if e[ok.OPACITY] and e[ok.PLAQUE_TYPE] != "None":
                    o.parent = parent
                    do_mask(o, o.model_name)

            # Restore.
            pdb.gimp_context_set_foreground(foreground)

        if not is_plan:
            z = apply_light(z)
        return z

    @staticmethod
    def do_custom_cell(o, is_plan):
        """
        Do a Custom Cell Model's Fringe.

        o: One
            Has variables

        Return: layer or None
            with Fringe material
        """
        parent = o.parent

        # Fringe Preset dict,'o.d'
        d = o.e = o.d

        z = None
        opacity = d[ok.BRUSH_DICT][ok.OPACITY]
        o.type_ = d[ok.FRINGE_TYPE]
        o.is_mask = o.is_grid = o.is_face = o.is_paint = False

        if opacity and o.type_ != "None":
            o.name = Lay.name(parent, nk.CELL_FRINGE)
            o.shape = o.model.cell_shape
            a, o.plaque = o.model.get_cell_definition(d, 0, 0)
            o.is_clip = d[ok.CLIP_TO_CELL]
            o.is_plan = is_plan
            o.plaque_dict = Step.get_cell_plaque(o.step)
            o.w, o.h = a.size
            o.x, o.y = a.position
            o.group = o.parent
            o.r = o.c = 0
            z = do_cell(o, o.model_name)

        if not is_plan:
            z = apply_light(z)
        return z

    @staticmethod
    def do_table(o, is_plan):
        """
        Do the Cell Fringe for a Table Model.

        o: One
            Has variables.

        Return: layer or None
            with Fringe material
        """
        def _act():
            """Use to lower indentation."""
            _m = True

            if _m:
                # Is the cell a sub-topleft cell?
                if is_merge_cell:
                    if o.model.d[ok.PER_CELL][r][c] == (-1, -1):
                        _m = False

            if _m:
                _m = Shape.is_allocated_cell(o.model, r, c)

            if _m:
                o.r, o.c = r, c
                _e = o.e = is_per_cell[r][c] if is_per_cell else d

                if (
                    _e[ok.OBEY_MARGINS] and
                    Step.has_margin(Form.get_form(One(d=margin, r=r, c=c)))
                ):
                    # Update the Plaque size for the Model.
                    rect = o.model.get_pocket(r, c)
                    n = o.model.cell_shape

                    if n in ft.TRIANGLE:
                        if Shape.is_inverse_triangle(r, c):
                            n = ft.INVERTED[n]
                    o.plaque = dispatch[n](rect)

                else:
                    rect = o.model.get_merge_cell_rect(r, c)
                    o.plaque = o.model.get_plaque(r, c)

                o.x, o.y = rect.position
                o.w, o.h = rect.size
                o.type_ = _e[ok.FRINGE_TYPE]
                _m = o.type_ != "None"

            if _m:
                _m = True if _e[ok.BRUSH_DICT][ok.OPACITY] else False

            _k = o.model_name, r, c

            if _m:
                o.is_clip = _e[ok.CLIP_TO_CELL]
                o.plaque_dict = Form.get_form(
                    One(d=Step.get_cell_plaque(o.step), r=r, c=c)
                )
                if not o.group:
                    o.group = Lay.group(j, o.name, parent)
                do_cell(o, _k)
            else:
                o.mask_sel += [cat.get_plaque_sel(_k)]

        cat = Hat.cat
        j = cat.render.image
        z = None

        # Fringe Preset dict,'o.d'
        d = o.d

        parent = o.parent
        o.name = Lay.name(parent, nk.CELL_FRINGE)
        is_merge_cell = o.model.is_merge_cell
        o.group = None
        o.is_plan = is_plan
        o.shape = o.model.cell_shape
        row, column = o.model.division
        is_per_cell = d[ok.PER_CELL]
        go = o.is_grid = True
        o.is_mask = o.is_face = o.is_paint = False
        o.mask_sel = []
        margin = Step.get_cell_margin(o.step)

        pdb.gimp_selection_none(j)

        if not is_per_cell and d[ok.FRINGE_TYPE] == "None":
            go = False

        if go:
            for r in range(row):
                for c in range(column):
                    _act()

        if o.group:
            if o.is_paint:
                z = Lay.merge_group(o.group)
            else:
                j.remove_layer(o.group)
                z = None

        if o.is_mask:
            pdb.gimp_selection_none(j)

            for i in o.mask_sel:
                Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
            if Sel.is_sel(j):
                z1 = o.plaque_layer
                mask = pdb.gimp_layer_create_mask(z1, fu.ADD_MASK_SELECTION)
                pdb.gimp_layer_add_mask(z1, mask)

        if not is_plan:
            z = apply_light(z)
        return z


fringe_job = {
    ng.AS_IS: do_as_is,
    ng.BACKDROP: do_backdrop,
    ng.COLOR: call_complete,
    ng.GRADIENT: do_gradient,
    ng.IMAGE: do_image,
    ng.PATTERN: do_pattern,
    ng.PLASMA: do_plasma
}
