#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg, Plaque as aq
from roller_constant_key import Layer as nk, Model as md, Option as ok
from roller_constant_fu import Fu
from roller_one_extract import Step
from roller_effect_feather_steps import FeatherSteps
from roller_model_image import Image
from roller_model_mask import Mask, MASK_FUNCTION
from roller_one import Base, Hat, One
from roller_one_extract import Render, Shape
from roller_one_fu import Lay, Mage, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
OPACITY_100 = 255
PER_CELL_TYPE = aq.AVERAGE_COLOR, aq.GRADIENT, aq.IMAGE, aq.SHADOW


def blur_behind(z, d):
    """
    Blur behind Plaque material.

    z: layer
        with material

    d: dict
        Has the Blur Behind option.

    o: One
        Has variables.

    Return: layer
        with material
    """
    z1 = z
    z = RenderHub.blur_behind(z, d, has_mode=True)

    if not z:
        z = z1
    return z


def cast_shadow(z, d):
    """
    Do a Tri-Shadow Preset's options. Merge a
    shadow layer with a Plaque layer if needed.

    z: layer
        with material

    d: dict
        of options

    Return: layer
        with Plaque material
    """
    if Shadow.get_type(d[ok.TRI_SHADOW]):
        n = z.name
        z = Shadow.do_shadows(d[ok.TRI_SHADOW], z)
        z.name = n
    return z


def complete(j, z, d, o):
    """
    Perform the steps that complete a Plaque type.

    j: GIMP image
        Is render.

    z: layer
        Has Plaque.

    d: dict
        of Plaque Preset with its Per Cell cell table

    o: One
        Has variables.

    Return: layer
        with Plaque
    """
    z1 = z
    plaque_type = d[ok.PLAQUE_TYPE]
    is_netting = plaque_type == aq.NETTING

    if d[ok.FEATHER]:
        if is_netting:
            # Feather the outside of the netting
            # selection instead of the netting lines.
            Sel.shape(j, o.plaque, option=fu.CHANNEL_OP_INTERSECT)
            FeatherSteps.feather_sel(j, d)
            Sel.invert_clear(z, keep_sel=True)
            Sel.invert_clear(z)
        else:
            feather(z, d)

    if has_blur_behind(d):
        # Blur Behind sets the mode and opacity.
        z = blur_behind(z, d)

    else:
        z = RenderHub.do_mode(z, d)

    z = RenderHub.bump(z, d[ok.BUMP])

    if z and plaque_type != aq.SHADOW:
        z = cast_shadow(z, d)

    if z and not pdb.gimp_item_is_valid(z):
        z = z1
    return z


def do_average_color(j, z, o):
    """
    Make an Average Color Plaque. Is not a candidate for is-one-selection.
    The Average Color is calculated from the background of the Plaque layer.

    Exit with a selection to save.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress
        A new layer is inserted above 'z'.

    o: One
        Has cell data.

    opacity: float
        for Plaque layer

    Return: state of image, layer
        selection, with material
    """
    # Use the cell's background as the source
    # of the Average Color. Copy the selection.
    Sel.rect(
        j,
        o.x, o.y,
        o.w, o.h,
        option=fu.CHANNEL_OP_REPLACE
    )
    pdb.gimp_edit_copy_visible(j)
    j1 = pdb.gimp_edit_paste_as_new_image()

    z = Lay.add_above(z)

    Lay.color_fill(z, RenderHub.get_average_color(j1.layers[0]))
    pdb.gimp_image_delete(j1)
    Sel.item(z)
    Sel.shape(j, o.plaque)
    Sel.invert_clear(z, keep_sel=True)
    do_mask(j, z, o.e, o)
    return z


def do_backdrop(j, z, o):
    """
    Make a Plaque from the background.
    If called from a is-one-selection state,
    then the selection is already set.

    j: GIMP image
        Is render.

    z: layer
        Has Plaque material.

    o: One
        Has cell data.

    Return: layer
        Has image.
    """
    # Plaque Preset dict, 'o.e'
    d = o.e

    z = Lay.clone_background(z)

    if d[ok.BLUR]:
        Lay.blur(z, d[ok.BLUR])

    if not o.is_one_sel:
        Sel.shape(j, o.plaque)

    Sel.invert_clear(z, keep_sel=True)
    do_mask(j, z, d, o)
    return z


def do_cell(o, k):
    """
    The cell has a Plaque.

    o: One
        Has cell data.

    k: string or tuple
        key to the cell's Plaque selection
    """
    cat = Hat.cat
    j = cat.render.image

    # Plaque Preset dict, 'o.e'
    d = o.e

    plaque_type = d[ok.PLAQUE_TYPE]
    if plaque_type in plaque_process:
        if not o.group:
            o.group = Lay.group(
                j,
                Lay.name(o.parent, nk.CELL_PLAQUE),
                o.parent
            )
            z = Lay.add(j, "Plaque", parent=o.group)

        else:
            z = o.group.layers[0]

        if o.is_one_sel:
            Sel.shape(j, o.plaque)
            cat.save_plaque_sel(k)

        else:
            if o.is_plan:
                z = do_color(j, z, o)
            else:
                z = plaque_process[plaque_type](j, z, o)

        if not o.is_one_sel and not o.is_plan:
            z = complete(j, z, d, o)
        if not o.is_one_sel and z:
            Sel.item(z)
            cat.save_plaque_sel(k)


def do_color(j, z, o):
    """
    Make a color Plaque. If called from a is-one-selection
    state, then the selection is already set.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    o: One
        Has options.

    Return: state of image, layer
        selection, with material
    """
    if not o.is_one_sel:
        Sel.shape(j, o.plaque)

    z = Lay.add_above(z)

    Sel.fill(z, get_color(o))

    # Plaque Preset dict, 'o.e'
    do_mask(j, z, o.e, o)

    return z


def do_gradient(j, z, o):
    """
    Make a gradient Plaque. Is not
    a candidate for is-one-selection.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    o: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    def draw_gradient():
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(gradient_type),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            start_x, start_y,
            end_x, end_y
        )

    # Plaque Preset dict, 'o.e'
    d = o.e

    z = Lay.add_above(z)
    x, y, w, h = o.x, o.y, o.w, o.h
    gradient_type = d[ok.GRADIENT_TYPE]

    RenderHub.set_fill_context(fg.FILL_DICT)
    RenderHub.set_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        fu.GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(0)

    start_x, end_x, start_y, end_y =\
        RenderHub.get_gradient_points(
            d[ok.GRADIENT_ANGLE],
            x, y,
            w, h
        )

    Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
    draw_gradient()
    Sel.shape(j, o.plaque)
    Sel.invert_clear(z, keep_sel=True)
    do_mask(j, z, d, o)
    return z


def do_image(j, z, o):
    """
    Make an image Plaque. Is not a candidate for is-one-selection.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    o: One
        Has cell image.

    opacity: float
        for Plaque layer

    Return: state of image, layer or None
        selection, with material
    """
    # Plaque Preset dict, 'o.e'
    d = o.e

    j1 = Image.get_image(d[ok.IMAGE], o.image_index)

    if j1:
        j2 = j1.j

        pdb.gimp_selection_none(j)
        Mage.copy_all(j2)
        Image.close_image(j1)

        j2 = pdb.gimp_edit_paste_as_new_image()

        Mage.shape(j2, o.w, o.h)

        z = Lay.paste(z)

        pdb.gimp_layer_set_offsets(z, o.x, o.y)
        Sel.item(z)

        if d[ok.BLUR]:
            Lay.blur(z, d[ok.BLUR])

        Sel.shape(j, o.plaque)
        Sel.invert_clear(z, keep_sel=True)
        do_mask(j, z, d, o)
        return z
    else:
        # There is no plaque.
        pdb.gimp_selection_none(j)


def do_mask(j, z, d, o):
    """
    Apply a mask to a plaque. Is not a candidate for is-one-selection.

    j: GIMP image
        Is render.
    """
    e = d[ok.PLAQUE_MASK]
    plaque_type = e[ok.MASK_TYPE]

    if plaque_type in MASK_FUNCTION:
        Sel.item(z)

        is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

        if is_sel:
            w, h = x1 - x, y1 - y
            o = One(
                center_x=(x + x1) // 2, center_y=(y + y1) // 2,
                e=e,
                image_w=w, image_h=h,
                image_index=o.image_index,
                w=w * e[ok.HORZ_SCALE], h=h * e[ok.VERT_SCALE],
                x=x, y=y
            )

            MASK_FUNCTION[plaque_type](j, o)
            Mask.rotate_mask(j, e)
        if Sel.is_sel(j):
            Sel.invert_clear(z, keep_sel=True)
    else:
        pdb.gimp_selection_all(j)


def do_netting(j, z, o):
    """
    Make a netting Plaque. If called from a is-one-selection
    state, then the selection is already set.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    o: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    # Plaque Preset dict, 'o.e'
    d = o.e

    w = d[ok.NET_LINE_SPACING]
    color = d[ok.COLOR_1]
    w1 = d[ok.NET_LINE_WIDTH]
    z = Lay.add_above(z)

    if not o.is_one_sel:
        Sel.shape(j, o.plaque)

    pdb.plug_in_grid(
        j, z,
        w1,
        w,
        w,
        color,
        OPACITY_100,
        w1,
        w,
        w,
        color,
        OPACITY_100,
        0,
        0,
        0,
        (0, 0, 0),
        0
    )
    do_mask(j, z, d, o)
    return z


def do_pattern(j, z, o):
    """
    Make a pattern Plaque. If called from a is-one-selection
    state, then the selection is already set.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    o: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    # Plaque Preset dict, 'o.e'
    d = o.e

    if not o.is_one_sel:
        Sel.shape(j, o.plaque)

    RenderHub.set_fill_context(fg.FILL_DICT)
    RenderHub.set_pattern(d)

    # Try and fill the selection by keeping the
    # fill point within the visible canvas.
    x = Base.seal(o.x, 0, j.width - 1)
    y = Base.seal(o.y, 0, j.height - 1)

    z = Lay.add_above(z)

    pdb.gimp_drawable_edit_bucket_fill(
        z,
        fu.FILL_PATTERN,
        Base.seal(x, 0, j.width),
        Base.seal(y, 0, j.height)
    )

    if d[ok.BLUR]:
        Lay.blur(z, d[ok.BLUR])
    do_mask(j, z, d, o)
    return z


def do_plasma(j, z, o):
    """
    Make a plasma Plaque. If called from a is-one-selection
    state, then the selection is already set.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    o: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    # Plaque Preset dict, 'o.e'
    d = o.e

    z = Lay.add_above(z)

    if o.is_one_sel:
        # Is a work-around for a plasma bug
        # that doesn't fill a selection correctly.
        sel = Hat.cat.save_short_term_sel()

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, d[ok.RANDOM_SEED], 3)

    if d[ok.BLUR]:
        Lay.blur(z, d[ok.BLUR])

    if o.is_one_sel:
        Sel.load(j, sel)

    else:
        Sel.shape(j, o.plaque)

    Sel.invert_clear(z)
    do_mask(j, z, d, o)
    return z


def do_shadow(j, z, o):
    """
    Make a shadow Plaque. Is not a candidate for is-one-selection.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    o: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    # Plaque Preset dict, 'o.e'
    d = o.e

    z = Lay.add_above(z)

    Sel.shape(j, o.plaque)
    Sel.fill(z, (0, 0, 0))
    do_mask(j, z, d, o)

    z1 = Shadow.do(
        One(
            cast=(z,),
            d=d,
            is_inner=True,
            model_name=o.model_name,
            parent=o.group
        )
    )

    j.remove_layer(z)
    return z1


def feather(z, d):
    """
    Feather the Plaque selection.

    z: layer
        Has material.

    d: dict
        Has feather option.
    """
    if d[ok.FEATHER]:
        FeatherSteps.feather(z, d)
        Sel.item(z)


def get_color(o):
    """
    Get the color for the Plaque material.

    d: dict
        of Plaque material

    Return: tuple
        RGB
    """
    if o.is_plan:
        return o.color
    return o.e[ok.COLOR_1]


def has_blur_behind(d):
    """
    Determine if Blur Behind is in effect.

    d: dict
        of Plaque Preset dict

    Return: bool
        Is true when the Blur Behind is to be done.
    """
    return d[ok.BLUR_BEHIND] and d[ok.OPACITY]


class Plaque:
    """Provide Plaque functionality access."""

    @staticmethod
    def do_box(o, is_plan):
        """
        Do the Plaque option for the Box Model.

        o: One
            Has init values.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with Plaque material
        """
        face_x = Step.get_face_index(o.step)

        if face_x is None:
            return Plaque.do_grid(o, is_plan)

        if is_plan:
            # Create a slight difference in the Plaque
            # color so the Faces appear separate.
            o.color = tuple([i + face_x for i in o.color])

        cat = Hat.cat
        j = cat.render.image
        z = o.group = None
        row, column = o.model.division

        # Render as a single selection with the 'is_one_sel' flag.
        o.is_one_sel = o.is_layer = False

        o.is_plan = is_plan
        go = True
        d = o.d
        f, plaque_type = d[ok.OPACITY], d[ok.PLAQUE_TYPE]
        is_per_cell = d[ok.PER_CELL]
        o.parent = cat.get_layer((o.render_type, o.model_name, nk.PLAQUE))

        if (
            not is_per_cell and
            plaque_type not in PER_CELL_TYPE and
            not Shadow.get_type(d[ok.TRI_SHADOW]) and
            d[ok.PLAQUE_MASK][ok.MASK_TYPE] == "None"
        ):
            o.is_one_sel = True

        if not is_per_cell and not f:
            go = False

        if go:
            # Process a Plaque for each cell in the Model.
            for r in range(row):
                for c in range(column):
                    o.r, o.c = r, c
                    arg = face_x, r, c
                    k = (o.model_name,) + arg

                    # Plaque Preset dict, 'e'
                    e = o.e = is_per_cell[r][c] if is_per_cell else d

                    go = e[ok.OPACITY] and e[ok.PLAQUE_TYPE] != "None"
                    if go and Shape.is_double_cell(o.model.double_type, r, c):
                        rect = o.model.get_face_rect(*arg)
                        o.plaque = o.model.get_face(*arg)
                        o.x, o.y = rect.position
                        o.w, o.h = rect.size
                        do_cell(o, k)

        if o.group and o.is_one_sel:
            pdb.gimp_selection_none(j)

            q = [
                cat.get_plaque_sel((o.model_name, face_x, r, c))
                for r in range(row) for c in range(column)
            ]

            [Sel.load(j, i, option=fu.CHANNEL_OP_ADD) for i in q if i]
            if Sel.is_sel(j) and o.group:
                z = o.group.layers[0]

                if is_plan:
                    z = do_color(j, z, o)
                else:
                    z = plaque_process[plaque_type](j, z, o)
                    if not is_plan:
                        z = complete(j, z, d, o)

        if o.group:
            z = Lay.merge_group(o.group)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.PLAQUE_INFLUENCE)
            if z:
                z.name = Lay.name(
                    o.parent,
                    "Cell Plaque Face " + str(face_x + 1)
                )
        return z

    @staticmethod
    def do_canvas(o, is_plan):
        """
        Add a Plaque layer. Is one Plaque per Model.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer
            with Plaque material
        """
        # Plaque Preset dict, 'o.d'
        d = o.e = o.d

        z = None
        opacity = d[ok.OPACITY]
        plaque_type = d[ok.PLAQUE_TYPE]
        go = opacity and plaque_type != "None"

        if go:
            cat = Hat.cat
            parent = o.parent
            j = cat.render.image
            o.is_layer = True
            o.is_plan = is_plan
            o.is_one_sel = False
            size = Render.size()

            if d[ok.OBEY_MARGINS]:
                o.y, bottom, o.x, right = o.model.canvas_margin
                o.w = size[0] - o.x - right
                o.h = size[1] - o.y - bottom

            else:
                o.x = o.y = 0
                o.w, o.h = size

            w, h = o.x + o.w, o.y + o.h
            o.plaque = o.x, o.y, w, o.y, w, h, o.x, h
            o.group = Lay.group(
                j,
                Lay.name(parent, nk.CANVAS_PLAQUE),
                parent,
                len(parent.layers)
            )
            if plaque_type in plaque_process:
                z = Lay.add(j, nk.CANVAS_PLAQUE, parent=o.group)

                plaque_process[plaque_type](j, z, o)

                z = Lay.merge_group(o.group)

                if not is_plan:
                    z = complete(j, z, d, o)
                if z:
                    Sel.item(z)
                    cat.save_plaque_sel(o.model_name)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.PLAQUE_INFLUENCE)
        return z

    @staticmethod
    def do_custom_cell(o, is_plan):
        """
        Do the Plaque for a Custom Cell Model.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with Plaque material
        """
        # Plaque Preset dict, 'o.d'
        d = o.e = o.d

        z = o.group = None
        opacity = d[ok.OPACITY]
        plaque_type = d[ok.PLAQUE_TYPE]

        if opacity and plaque_type != "None":
            a, o.plaque = o.model.get_cell_definition(d, 0, 0)
            o.is_layer = True if o.model_type == md.STACK else False
            o.is_one_sel = False
            o.is_merge_cell = False
            o.is_plan = is_plan
            o.x, o.y = a.position
            o.w, o.h = a.size

            # Custom Cell's cell index
            o.r = o.c = 0

            do_cell(o, o.model_name)

        if o.group:
            z = Lay.merge_group(o.group)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.PLAQUE_INFLUENCE)
        return z

    @staticmethod
    def do_grid(o, is_plan):
        """
        Do the Plaque for Grid-type Models.

        o: One
            Has init values.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with Plaque material
        """
        cat = Hat.cat
        j = cat.render.image
        z = o.group = None
        row, column = o.model.division
        is_merge_cell = o.is_merge_cell = o.model.is_merge_cell

        # Plaque Preset dict, 'o.d'
        d = o.d

        # Cell Type Preset dict, 'grid_d'
        grid_d = o.model.d

        is_per_cell = d[ok.PER_CELL]

        # Render as a single selection with the 'is_one_sel' flag.
        o.is_one_sel = o.is_layer = False

        o.is_plan = is_plan
        go = True
        f, plaque_type = d[ok.OPACITY], d[ok.PLAQUE_TYPE]

        if not is_per_cell:
            go = f and plaque_type != "None"

        if go:
            if (
                not is_per_cell and
                plaque_type not in PER_CELL_TYPE and
                not Shadow.get_type(d[ok.TRI_SHADOW]) and
                d[ok.PLAQUE_MASK][ok.MASK_TYPE] == "None"
            ):
                o.is_one_sel = True

            # Process a Plaque for each cell in the Table Model.
            for r in range(row):
                for c in range(column):
                    o.r, o.c = r, c
                    k = o.model_name, r, c
                    e = o.e = is_per_cell[r][c] if is_per_cell else d
                    m = e[ok.OPACITY] and e[ok.PLAQUE_TYPE] != "None"

                    if m:
                        m = Shape.is_allocated_cell(o.model, r, c)

                    if m:
                        if e[ok.OBEY_MARGINS]:
                            rect = o.model.get_pocket(r, c)
                            o.plaque = o.model.get_shape(r, c)

                        else:
                            rect = o.model.get_merge_cell_rect(r, c)
                            o.plaque = o.model.get_plaque(r, c)
                        if is_merge_cell:
                            if grid_d[ok.PER_CELL][r][c] == (-1, -1):
                                m = False
                    if m:
                        o.x, o.y = rect.position
                        o.w, o.h = rect.size
                        do_cell(o, k)

        if o.group and o.is_one_sel:
            pdb.gimp_selection_none(j)

            q = [
                cat.get_plaque_sel((o.model_name, r, c))
                for r in range(row) for c in range(column)
            ]

            [Sel.load(j, i, option=fu.CHANNEL_OP_ADD) for i in q if i]
            if Sel.is_sel(j) and o.group:
                z = o.group.layers[0]

                if is_plan:
                    z = do_color(j, z, o)
                else:
                    z = plaque_process[plaque_type](j, z, o)
                    if not is_plan:
                        z = complete(j, z, d, o)

        if o.group:
            z = Lay.merge_group(o.group)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.PLAQUE_INFLUENCE)
        return z


plaque_process = {
    aq.AVERAGE_COLOR: do_average_color,
    aq.BACKDROP: do_backdrop,
    aq.COLOR: do_color,
    aq.GRADIENT: do_gradient,
    aq.IMAGE: do_image,
    aq.NETTING: do_netting,
    aq.PATTERN: do_pattern,
    aq.PLASMA: do_plasma,
    aq.SHADOW: do_shadow
}
