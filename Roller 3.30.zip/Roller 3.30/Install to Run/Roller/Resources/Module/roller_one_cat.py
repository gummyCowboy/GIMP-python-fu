#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import seed
from roller_constant_key import Option as ok
from roller_one import Comm
from roller_one_fu import Sel
from roller_render_image import RenderImage
import gimpfu as fu

pdb = fu.pdb

# Use to differentiate a mask selection from the other selections:
MASK_TYPE = 0


class Cat(object):
    """Use as a common ground for global program variables."""

    def __init__(self):
        """Initialize variables."""

        # Use to find an image layer inside its group.
        self._image_layer = {}

        # Use to find layers and image groups.
        # The key has different configurations.
        # The value is a layer.
        self._layers = {}

        # alpha channels
        self._long_term_sel = []

        # RenderImage
        self._render_image = None

        # Short-term selection
        self._short_term_sel = []

        # Use to save z-height of an image.
        self._z_height = {}

        # GIMP brush
        self.brush_list = sorted(pdb.gimp_brushes_get_list(None)[1])

        # Use to save Caption Stripe selections.
        self.caption_stripe_sel = {}

        # GIMP font
        self.font_list = sorted(pdb.gimp_fonts_get_list(None)[1])

        # Make frame file path.
        self.frame_path = ""

        # GIMP gradient
        self.gradient_list = sorted(pdb.gimp_gradients_get_list(None)[1])

        # option group
        self.group_dict = {}

        # Use with ImageGradient to delete unused gradients.
        self.image_gradients_created = []

        # Use with ImageGradient to delete unused gradients.
        self.image_gradient_used = None

        # Use to remember the image file path for a OSButton.
        self.image_path = ""

        # Is the Blur Behind image selection.
        self.image_sel = {}

        # by Image Mask for Image Effect
        self.mask_sel = {}

        # GIMP pattern
        self.pattern_list = sorted(pdb.gimp_patterns_get_list(None)[1])

        # Plaque selection
        self.plaque_sel = {}

        # Is the root folder for Preset storage.
        self.preset_folder = None

        # 'roller_path' is where Roller modules and Presets are stored.
        self.roller_path = ""

        # Window position dict
        self.window_pose = {}

        # render variables
        #
        # Set by the Global option group.
        self.seed_global = 0
        self.elevation = .0
        self.is_close_file = False
        self.azimuth = .0

        # Gradient Light Preset dict
        self.gradient_light_d = None

    def _del_vectors(self):
        """Delete the vectors (paths)."""
        j = self.render.image
        for i in j.vectors:
            pdb.gimp_image_remove_vectors(j, i)

    def _save_dict_sel(self, d, k):
        """
        Save a selection. Remove an older selection with the same identity.

        d: dict
            of selection

        n: string
            item name

        r, c: int
            cell index
        """
        sel = self._save_selection()

        if k in d:
            # Get rid of the old selection.
            channel = d[k]

            d.pop(k)
            if pdb.gimp_item_is_valid(channel):
                pdb.gimp_image_remove_channel(self.render.image, channel)
        if sel:
            d[k] = sel

    def _save_selection(self):
        """
        Save a copy of the selection to the alpha channel.

        Return: the selection or None.
        """
        j = self.render.image

        # Would save nothing (a black mask) if that was case.
        if Sel.is_sel(j):
            self._long_term_sel.append(pdb.gimp_selection_save(j))
            return self._long_term_sel[-1]

    def del_channels(self, d):
        """
        Delete channels stored in a dict.

        d: dict
            original
        """
        j = self.render.image
        for i, channel in d.items():
            if pdb.gimp_item_is_valid(channel):
                pdb.gimp_image_remove_channel(j, channel)

    def del_image_layer(self, k):
        """
        Delete an image layer reference.

        k: string
            key to to the image layer
            group name

        Return: bool
            Is true when the layer is removed.
        """
        if k in self._image_layer:
            self._image_layer.pop(k)
            return True
        return False

    def del_long_term_sel(self):
        """Remove the long term collection of selections from GIMP."""
        j = self.render.image
        q = self._long_term_sel
        self.caption_stripe_sel = {}
        self.image_sel = {}
        self.mask_sel = {}
        self.plaque_sel = {}

        for channel in q:
            if pdb.gimp_item_is_valid(channel):
                pdb.gimp_image_remove_channel(j, channel)
        self._long_term_sel = []

    def del_short_term_sel(self):
        """
        Remove the short-term collection of selections from GIMP.
        """
        j = self.render.image

        self._del_vectors()

        for channel in self._short_term_sel:
            if pdb.gimp_item_is_valid(channel):
                pdb.gimp_image_remove_channel(j, channel)
        self._short_term_sel = []

    def del_selections(self, d):
        """
        Delete the selections from a dictionary.

        d: dict
            of selections
        """
        j = self.render.image
        for k, channel in d.items():
            if pdb.gimp_item_is_valid(channel):
                pdb.gimp_image_remove_channel(j, channel)

    def get_caption_stripe_sel(self, k):
        """
        Get the Caption Stripe selection for a cell.

        k: value
            key to the selection

        Return: GIMP selection or None
            of Caption Stripe
        """
        d = self.caption_stripe_sel
        return d[k] if k in d else None

    def get_image_layer(self, k):
        """
        Get an image layer by its reference key.

        k: value

        Return: layer or None
            with image material
        """
        if k in self._image_layer:
            return self._image_layer[k]

    def get_image_sel(self, k):
        """
        Get an image selection for a cell.

        k: value

        Return: GIMP selection or None
            of a placed image
        """
        if k in self.image_sel:
            return self.image_sel[k]

    def get_layer(self, k):
        """
        Get a registered layer.

        k: value
            key to the registered layer

        Return: layer or None
            the registered layer
        """
        d = self._layers
        return d[k] if k in d else None

    def get_mask_sel(self, k):
        """
        Get the mask selection for a cell.

        k: value
            key to the mask selection

        Return: GIMP selection or None
            of the mask
        """
        k = k, MASK_TYPE
        d = self.mask_sel
        return d[k] if k in d else None

    def get_plaque_sel(self, k):
        """
        Get the Plaque selection for a cell.

        k: value
            key to the plaque selection

        Return: GIMP selection or None
            of Plaque material
        """
        d = self.plaque_sel
        return d[k] if k in d else None

    def get_z_height(self, k):
        """
        Get the z-height, the height of a layer, for a cell image.

        k: value
            key to the z-height

        Return: layer or None
            image layer
        """
        if k in self._z_height:
            return self._z_height[k]

    def is_image_sel(self, k):
        """
        Determine if an image selection exits.

        k: value
            key to the image selection

        Return: bool
            Is true if the key is in the image selection dict.
        """
        return k in self.image_sel

    def join_selection(self, k):
        """
        Intersect an image and its mask selection.

        k: value

        Return: image Selection or None
            state of image
        """
        j = self.render.image
        sel = self.get_image_sel(k)

        pdb.gimp_selection_none(j)
        if sel:
            Sel.load(j, sel)

            sel1 = self.get_mask_sel(k)
            if sel1:
                Sel.load(j, sel1, option=fu.CHANNEL_OP_INTERSECT)

    def join_selections(self, sel, k):
        """
        Intersect a selection and a mask selection.

        sel: channel or None
            to intersect with mask

        k: value
            key to a mask selection

        Return: selection, joined selection, or no selection
        """
        j = self.render.image

        pdb.gimp_selection_none(j)
        if sel:
            Sel.load(j, sel)

            sel1 = self.get_mask_sel(k)
            if sel1:
                Sel.load(j, sel1, option=fu.CHANNEL_OP_INTERSECT)

    def register_layer(self, k, z):
        """
        Store a reference to a layer.

        k: value
            key to a layer

        z: layer
            to register
        """
        self._layers[k] = z

    @property
    def render(self):
        """
        Get the RenderImage or create one.

        Return: RenderImage
            Has the Render image.
        """
        if self._render_image:
            return self._render_image
        else:
            self._render_image = RenderImage()
            return self._render_image

    @render.setter
    def render(self, *_):
        """Is an invalid access."""
        raise Cat.WriteError("render")

    def reset_dict(self):
        """Remove layer and selection registrations."""
        self._layers = {}
        self.caption_stripe_sel = {}
        self.image_sel = {}
        self.mask_sel = {}
        self.plaque_sel = {}

    def save_caption_stripe_sel(self, k):
        """
        Add a Caption Stripe selection to its dict.
        The selection is presumed to exist.

        k: value
            key for the Caption Stripe selection
        """
        self._save_dict_sel(self.caption_stripe_sel, k)

    def save_image_sel(self, z, k):
        """
        Add an image selection to the image selection dict.

        z: layer
            Has image.

        k: value
            key for the image selection
        """
        Sel.item(z)
        self._save_dict_sel(self.image_sel, k)

    def save_image_layer(self, z):
        """
        Save a reference to an image layer.

        z: layer
            image layer
        """
        self._image_layer[z.name] = z

    def save_mask_sel(self, k):
        """
        Add a Mask selection item to the Mask selection dict.
        The Mask selection is the current selection.

        k: value
            key to the Mask selection
        """
        self._save_dict_sel(self.mask_sel, (k, MASK_TYPE))

    def save_plaque_sel(self, k):
        """
        Add a Plaque selection item to the Plaque selection dict.

        k: value
            key to the Plaque selection
        """
        self._save_dict_sel(self.plaque_sel, k)

    def save_short_term_sel(self):
        """
        Save a copy of the selection to the alpha channel.
        Is a selection that is to be removed after a Plan or Preview action.

        Return: selection or None
            Is none if there is no selection.
        """
        j = self.render.image

        # Would save nothing (a black mask) if that was case.
        if Sel.is_sel(j):
            self._short_term_sel.append(pdb.gimp_selection_save(j))
            return self._short_term_sel[-1]

    def save_z_height(self, k, z_height):
        """
        Store the z-height of an image.

        k: value
            key to the image z-height

        z_height: string
            the height of the image layer
        """
        self._z_height[k] = z_height

    def seed(self, d):
        """
        Set Python's random seed. Add the Global
        Random Seed with a Preset Random Seed.

        d: dict
            with a Random Seed option
        """
        seed(d[ok.RANDOM_SEED] + self.seed_global)

    class WriteError(Exception):
        """
        Use when a function attempts to write to a read-only property.
        """
        def __init__(self, n):
            """
            There was a write error to an attribute.
            Spit out the variable name.

            n: string
                function name
            """
            self.value = "WriteError: Attempted to write to a read-only " \
                "property: Cat.{}.".format(n)
            Comm.info_msg(self.value)

        def __str__(self):
            """
            Return the string value of the error message.
            Is an Exception template function.
            """
            return repr(self.value)
