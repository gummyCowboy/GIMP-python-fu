#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice
from roller_constant_for import Color as co, Widget as fw
from roller_one import Base
from roller_one_draw import Draw
from roller_one_tip import Tip
from roller_constant_key import Model as md, Option as ok, Widget as wk
from roller_widget import Widget
from roller_widget_box import Box, Cabinet, Eventful
from roller_widget_button_pair import ButtonPair
from roller_widget_combo import ComboBox
from roller_widget_label import Label
from roller_widget_table import Table
import gtk

CHOICE_COLOR = '#C8F8FF'

# for ModelList
DELETE = "Delete"
MANAGE = 'manage'
MODEL_TYPE = "Model Type"
NEED_COUNT = 2, 2, 1
NEW = "New"
SORT = 'sort'


def create_box(g, color):
    """
    Create a Eventful box for the navigation list. Keep
    the list from destroying the container's Label.

    g: container
        container for box

    color: int
        for the Eventful background
    """
    box = Eventful(color)
    vbox = gtk.VBox()

    box.add(vbox)
    g.add(box)
    return vbox


class TreeViewList(Widget):
    """Is base class for a Roller TreeView list Widget."""

    def __init__(self, **d):
        """
        Create a TreeView list.

        d: dict
            Has init values.
        """
        self._update_window = d[wk.ON_WIDGET_CHANGE]

        # of the cell
        self.background_color = d[wk.COLOR]

        self.list_store = None
        tree = self.treeview = gtk.TreeView()
        tree.set_headers_visible = 0

        if wk.HEADER not in d:
            d[wk.HEADER] = ""

        if wk.MINIMUM_WIDTH not in d:
            d[wk.MINIMUM_WIDTH] = 1

        Widget.__init__(self, tree, **d)
        self.reset_list_store()

        # Create a column.
        col = gtk.TreeViewColumn(
            d[wk.HEADER],
            gtk.CellRendererText(),
            text=0,
            foreground=1,
            background=2
        )

        col.set_min_width(d[wk.MINIMUM_WIDTH])

        # Add the column to the TreeView.
        tree.append_column(col)

        if not d[wk.HEADER]:
            # Hide the column header with a dummy Label.
            col.set_widget(gtk.Label(""))

        # The TreeView cursor-changed signal will send a signal
        # when a row is clicked even if the row is already selected.
        tree.connect('cursor_changed', self.on_change)

        # Modify the base color or the background color of the Treeview.
        # reference
        # mail.gnome.org/archives/gtk-app-devel-list/2015-June/msg00026.html
        # kksou.com/php-gtk2/sample-codes/set-the-background-color-of-GtkTreeView.php
        if wk.STEP in d:
            if d[wk.STEP][-1] == "Model":
                # model list
                color = Cabinet.colors[len(d[wk.STEP]) + 2]
            else:
                # Node
                color = Cabinet.colors[len(d[wk.STEP]) - 1]
            tree.modify_base(
                gtk.STATE_NORMAL,
                gtk.gdk.Color(color, color, co.MAX_COLOR)
            )

    def append_item(self, n):
        """
        Add an item to the list.

        n: string
            item to add
        """
        self.list_store.append([n, '#000000', self.background_color])

    def get_sel_x(self):
        """
        Get the row index of the selected item.

        Return: int or None
            in 0 to n, where n is the length of the list minus one
        """
        x = q1 = None
        q = self.treeview.get_selection()

        if q:
            # GtkTreeIter, 'q1'
            q1 = q.get_selected_rows()[1]

        if q1:
            x = q1[0][0]
        return x

    def get_value(self):
        """
        Get the selected item in the list.

        Return: string
            from the list selection
        """
        n = None
        q = self.treeview.get_selection()

        if q:
            model, iter_ = q.get_selected()
            if iter_:
                n = model.get_value(iter_, 0)
        return n

    def on_change(self, *_):
        """Use to insert self into the change argument."""
        self._update_window(self)

    def populate_treeview(self, q):
        """
        Populate the TreeView from a list.
        The previous indexed-list is replaced.

        q: list
            of string
        """
        self.reset_list_store()

        # Append items to the list.
        for n in q:
            self.append_item(n)

    def rename_item(self, x, n):
        """
        Change the name of an item in the TreeView.

        x: int
            index to row

        n: string
            new item name
        """
        for x1, r in enumerate(self.list_store):
            if x == x1:
                self.list_store.set_value(r.iter, 0, n)

    def reset_list_store(self):
        """
        Replace the ListStore with a new one as
        old one's iterator is probably used up.
        """
        # Replace "TreeView.ListStore's" iterator.
        self.list_store = gtk.ListStore(str, str, str)
        self.treeview.set_model(self.list_store)

    def select_item(self, x):
        """
        Select a TreeView item.

        x: int
            row index in the TreeView
            in 0 to n
        """
        self.treeview.set_cursor(x)

        selection = self.treeview.get_selection()
        if selection:
            model, iter_ = selection.get_selected()
            if iter_:
                path = model.get_path(iter_)
                self.treeview.scroll_to_cell(path)

    def set_value(self, q):
        """
        Load the Treeview from a list.

        q: iterable
            of items to display in list
        """
        self.populate_treeview(q)


class ChoiceList(TreeViewList):
    """Is a Treeview composed of a list."""

    def __init__(self, **d):
        """
        Create a Treeview list. Use for when the value is a string.
        """
        d[wk.COLOR] = CHOICE_COLOR
        g1 = self.scrolled_window = gtk.ScrolledWindow()

        TreeViewList.__init__(self, **d)
        self.populate_treeview(d[wk.LIST])
        g1.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        g1.add(self.treeview)
        d[wk.CONTAINER].pack_start(g1, expand=True)

        # Select the previous choice for the user.
        x = d[wk.LIST].index(d[wk.CHOICE]) \
            if d[wk.CHOICE] in d[wk.LIST] else 0

        self.treeview.set_cursor(x)

        selection = self.treeview.get_selection()
        model, iter_ = selection.get_selected()
        if iter_:
            path = model.get_path(iter_)
            self.treeview.scroll_to_cell(path)


class OptionList(TreeViewList):
    """Is a Treeview composed of a list."""

    def __init__(self, **d):
        """
        Create a Treeview list.

        d: dict
            Has options.

            list: list
                for the Treeview list

            choice: string
                an initial choice

            on_accept: function
                callback on return key
        """
        self._choices = d[wk.LIST]
        g = gtk.ScrolledWindow()
        d[wk.COLOR] = '#D7D7FF'
        d[wk.MINIMUM_WIDTH] = 1

        TreeViewList.__init__(self, **d)
        self.populate_treeview(self._choices)

        # Initialize the iterator.
        self.select_item(0)

        vbox = gtk.VBox()
        hbox = gtk.HBox()
        label = gtk.Label("\n" * 12)

        hbox.pack_start(label, expand=1)
        hbox.pack_start(g, expand=1)
        vbox.pack_start(hbox, expand=True)
        g.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        g.add(self.treeview)
        self.add(vbox)

    @property
    def option_group(self):
        """
        Get the OptionGroup for the Treeview list. The Treeview
        list sends signals where the listener requires the OptionGroup.
        """
        return self.treeview.option_group

    @option_group.setter
    def option_group(self, a):
        """
        a: OptionGroup
            of the TreeViewList
        """
        self.treeview.option_group = a

    def randomize(self):
        """
        Make a random choice from the list.

        Return: string
            random choice
        """
        return choice(self._choices)

    def set_value(self, n):
        """
        Select an item in the list.

        n: string
            item to select
        """
        self.treeview.set_cursor(
            self._choices.index(n) if n in self._choices else 0
        )

        selection = self.treeview.get_selection()
        if selection:
            model, iter_ = selection.get_selected()
            if iter_:
                path = model.get_path(iter_)
                self.treeview.scroll_to_cell(path)


class NavigationList(TreeViewList):
    """Is a GTK TreeView with a ListStore to make a list display."""

    def __init__(self, **d):
        """
        Create a navigation list.

        g: GTK container
            to receive the TreeView
        """
        w = fw.MARGIN

        # list of VBoxes corresponding with list items, 'self._groupie'
        # Node branches connect to VBoxes found in 'self._groupie'.
        self._groupie = []

        hbox = Box(box=gtk.HBox)
        d[wk.COLOR] = co.LIST_CELL_COLOR

        TreeViewList.__init__(self, **d)
        self.add(self.treeview)

        if d[wk.ITEM_COUNT] > 14:
            g1 = gtk.ScrolledWindow()
            g1.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
            g1.add(self)

        else:
            g1 = self

        hbox.add(g1)
        hbox.set_padding(2, 2, w, w)
        d[wk.CONTAINER].add(hbox)

    def remove_item(self, x):
        """
        Remove an item from the list.

        x: int
            row number
        """
        if x < 0:
            x = len(self._groupie) + x
        for x1, r in enumerate(self.list_store):
            if x == x1:
                self._groupie.pop(x)
                self.list_store.remove(r.iter)
                break


class Node(NavigationList):
    """
    Is a navigation item list where an item descriptor is part of a step
    to an OptionGroup. Node items and Group keys are closely related
    when making step tuples. Group keys differ in that have extended
    Label strings that make their keys unique from other same-named options.
    """

    def __init__(self, **d):
        """
        Draw a navigation item list.

        d: dict
            Has init values.
        """
        # a list of strings that correspond with
        # the Node's list of item descriptors, 'q'
        q = [i.split(",")[0] for i in d[wk.LABELS]]

        self.original_length = len(q)
        g = d[wk.CONTAINER]
        g.node_ = self
        self.cabinet = d[wk.PORT].node_panel.cabinet
        g1 = self._box = d[wk.CONTAINER] = create_box(g, d[wk.COLOR])
        d[wk.ON_WIDGET_CHANGE] = self.on_list_change

        NavigationList.__init__(self, item_count=len(q), **d)

        for i in q:
            self.append_group(i, None)

        self.key = d[wk.GROUP_KEY]
        self.level = len(d[wk.STEP]) - 1

        # Use to update Widget visibility.
        g1.connect('expose-event', self._on_expose)

    def _on_expose(self, *_):
        """
        Call when the Node is exposed becoming visible.

        _: gtk.VBox, GTK Event
            container for this Node,
            not used
        """
        x = self.get_sel_x()
        x = x if x is not None else 0

        self.select_item(x)
        return True

    def append_group(self, label, vbox):
        """
        Add a group to the end of a Node's item list.

        label: string
            name of the option for the group Label

        vbox: gtk.VBox or None
            group container

        Return: gtk.VBox
            group container
            a gtk.VBox
        """
        self.append_item(label)

        if not vbox:
            vbox = gtk.VBox()
            label = label.split(",")[0]
            g = vbox.label_ = Label(
                text="{}:".format(label),
                padding=(4, 4, 4, 4),
                expand=True
            )
            vbox.pack_start(g, expand=True)

        self._groupie.append(vbox)
        return vbox

    def get_groupie(self, x):
        """
        Get the VBox reference from the Node list's selection index.

        x: int
            selection index into the Node item list

        return: VBox or None
            the VBox connected to the Node branch
        """
        return self._groupie[x]

    def get_groupie_with_label(self, n):
        """
        Get the VBox reference from the Node's item list.

        n: string or tuple
            item to match

        return: VBox or None
            the VBox, used by an option group, that branches from a Node item
        """
        if isinstance(n, str):
            n = n.split(",")[0]

        q = self.get_value()
        if n in q:
            return self._groupie[q.index(n)]

    def get_item_value(self):
        """
        Get the selected item in the list.

        Return: string
            from the list selection
        """
        n = None
        q = self.treeview.get_selection()

        if q:
            model, iter_ = q.get_selected()
            if iter_:
                n = model.get_value(iter_, 0)
        return n

    def get_value(self):
        """
        Get the items in the list.

        Return: list
            of Node items from rows
        """
        q = []
        item = self.list_store.get_iter_first()

        while item is not None:
            q.append(self.list_store.get_value(item, 0))
            item = self.list_store.iter_next(item)
        return q

    def insert_row(self, x, n, vbox):
        """
        Insert a row into the Node item list.

        x: int
            index to row

        n: string
            to insert as item
            Group key
        """
        self.list_store.set_value(
            self.list_store.insert(x),
            0,
            n.split(",")[0]
        )

        # Set the row's background color.
        for x1, i in enumerate(self.list_store):
            if x == x1:
                self.list_store[i.iter][2] = self.background_color
        self._groupie.insert(x, vbox)

    def is_valid_selection(self, x):
        """
        Determine if a value is a valid selection.

        x: int or None
            a selection index

        Return: bool
            Is true when the selection value is valid.
        """
        if x is not None:
            if len(self._groupie) and len(self._groupie) >= x:
                return True
        return False

    def on_list_change(self, g):
        """
        Respond when the user changes selection in a Node item
        list. Is a signal handler for TreeViewList-type of objects.

        g: Node
            Is responsible.
        """
        def hide_box():
            """
            Hide option groups with two columns or more into
            the navigation box from the current column.
            """
            _a = g.level + 2
            if _a < len(g.cabinet):
                for _i in range(_a, len(g.cabinet)):
                    for _j in g.cabinet[_i].get_children():
                        if isinstance(_j, gtk.VBox):
                            if _j.get_visible():
                                _j.hide()

        if not Draw.load_count:
            x = g.get_sel_x()

            # The junction is the container for
            # the Node's branched option group boxes.
            if g.is_valid_selection(x):
                # 'get_children' is created by GTK when option
                # groups are added to the 'junction'.
                if len(g.cabinet) > g.level + 1:
                    junction = g.cabinet[g.level + 1]
                    children = junction.get_children()
                    g1 = g.get_groupie(x)

                    if not hasattr(g1, 'node_'):
                        # Node, 'g1'
                        hide_box()

                    else:
                        if g1.node_.get_sel_x() is None:
                            hide_box()

                    for child in children:
                        if child != g1:
                            if child.get_visible():
                                child.hide()

                    if g1 not in children:
                        junction.add(g1)
                        g1.show_all()

                    else:
                        g1.show()

                    # Resize the Window with the group-size change.
                    self.win.resize()

                    # Tell GTK that the signal was processed.
                    return True

    def refresh_list(self, q):
        """
        Synchronize the order of a Node's branches with a list of strings.

        q: list
            of Node branch names
        """
        previous = self.get_value()
        groupie = self._groupie[:]
        for x, i in enumerate(q):
            if i != previous[x]:
                self.remove_item(x)
                self.insert_row(x, i, groupie[previous.index(i)])


class ModelList(TreeViewList):
    """
    Is a Widget group with a TreeView and TreeView item manipulation Buttons.
    """

    def __init__(self, **d):
        """
        Add an item list and associated Widgets to a group.

        d: dict
            Has init values.
        """
        w = fw.MARGIN // 2
        self._items = []
        self._list_buttons = []
        hbox = Box(box=gtk.HBox, padding=(w, w, w, w))
        self.key = d[wk.KEY]
        self._name = d[wk.NAME]
        self._on_create_model_list_item = d[wk.CREATE_LIST_ITEM]
        self._on_del_model_list_item = d[wk.DELETE_LIST_ITEM]
        self._on_move_model_list_item = d[wk.MOVE_LIST_ITEM]
        self._on_model_list_host_change = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self.on_model_list_change
        scrolled_window = gtk.ScrolledWindow()
        self._up_arrow = gtk.Arrow(gtk.ARROW_UP, gtk.SHADOW_NONE)
        self._down_arrow = gtk.Arrow(gtk.ARROW_DOWN, gtk.SHADOW_NONE)
        self._make_model_d = {
            md.BOX: self._on_create_model_list_item
        }

        # Table Widget keyword arguments, 'e'
        e = {}
        e.update(d)

        # ModelList's Table Widget arguments, 'd1'
        d1 = {}
        d1.update(d)

        # container for the Table Widget, 'vbox'
        vbox = e[wk.CONTAINER] = Box(padding=(0, 0, 0, w))

        d.update({wk.COLOR: CHOICE_COLOR, wk.MINIMUM_WIDTH: 70})
        TreeViewList.__init__(self, **d)
        self.treeview.set_tooltip_text(" Is the layer palette order. ")

        # Build a Model Table.
        e['q'] = (
            (
                "Model Type",
                ComboBox,
                dict(e, key=MODEL_TYPE, _list=md.MODEL_TYPE_LIST)
            ),
            (
                "",
                ButtonPair,
                dict(e, key=MANAGE, text=(NEW, DELETE))
            ),
            (
                "",
                ButtonPair,
                dict(e, key=SORT, text=(self._up_arrow, self._down_arrow))
            )
        )

        # dict of Widgets, 'd'
        d = Table.create(**e)

        self._model_type = d[MODEL_TYPE]
        self._list_buttons = d[SORT].buttons + (d[MANAGE].right_button,)

        for x, i in enumerate(self._list_buttons):
            i.need_count = NEED_COUNT[x]
            i.widget.set_tooltip_text(Tip.LIST_BUTTON[x])

        # Assign self variable to prevent garbage collection.
        self._new_button = d[MANAGE].left_button

        self._new_button.set_tooltip_text(Tip.NEW_MODEL)

        # Finalize.
        scrolled_window.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        scrolled_window.add(self.treeview)
        hbox.add(vbox)
        hbox.add(scrolled_window)
        self.add(hbox)
        self._verify_buttons()

        # Connect events.
        self.treeview.connect('key_press_event', self._on_key_press)
        self.treeview.get_selection().connect('changed', self._verify_buttons)

        # Do last.
        d[MODEL_TYPE].set_value(md.TABLE)

    def _make_model(self, name, model_type):
        """
        Create a new Model item. Enumerate the item
        name until a unique identifier is created.

        name: string
            identify the Model instance

        model_type: string
            Identify the Model type for Model init functionality.
        """
        # list of Model names, 'q'
        q = [i[md.NAME_INDEX] for i in self._items]

        # new Model name, 'n'
        n = name if name is not None else Base.enumerate_name(model_type, q)

        self.list_store.append([n, '#000000', self.background_color])
        self._items.append((n, model_type))
        self._verify_buttons()
        self.select_item(len(self._items) - 1)
        self._on_create_model_list_item(self, n, model_type)

    def _del_item(self, *_):
        """Delete a row in the TreeView."""
        x = self.get_sel_x()
        if x is not None:
            n = self._items[x][md.NAME_INDEX]

            self._items.pop(x)

            sel = self.widget.get_selection()

            if sel:
                # 'a, b', Model name, iter
                a, b = sel.get_selected()
                if b:
                    a.remove(b)
                    self._populate_list(self._items)
                    self._verify_buttons()
                    self._on_del_model_list_item(self, n)
            self._new_button.widget.grab_focus()

    def _move_sel_down(self, *_):
        """
        Move a selection down one line in the TreeView.
        If 'x' selection is at the bottom of the list,
        then the item rotates to the top of the list.
        """
        x = x1 = self.get_sel_x()
        a = len(self._items)
        x += 1

        if x == a:
            x = 0

        self._update_treeview(x, x1)

        # Give the move down Button focus.
        self._list_buttons[1].widget.grab_focus()

        self._on_move_model_list_item(self)

    def _move_sel_up(self, *_):
        u"""
        Move a selection up one line in the TreeView.
        If 'x' selection is at the top of the list, then
        the item rotates to the bottom of the list.
        """
        x = x1 = self.get_sel_x()
        a = len(self._items)
        x -= 1

        if x < 0:
            x = a - 1

        self._update_treeview(x, x1)

        # Give the move up Button focus.
        self._list_buttons[0].widget.grab_focus()

        self._on_move_model_list_item(self)

    def _on_key_press(self, _, a):
        """
        Use to catch a delete key-press.

        a: GTK Event
            of key-press
        """
        n = gtk.gdk.keyval_name(a.keyval)
        if len(self._items):
            if n == 'Delete':
                self._del_item()

                # Let GTK know a signal is processed.
                return True

    def _populate_list(self, q):
        """
        Populate the TreeView from a list.
        The previous indexed-list is replaced.

        q: list
            of (name, type)
        """
        self.reset_list_store()

        self._items = []
        for x, i in enumerate(q):
            self.list_store.append([i[md.NAME_INDEX], '#000000', '#00FEFF'])
            self._items.append(i)

    def _update_treeview(self, x, x1):
        """
        Update the list after a change.

        x: int
            new position

        x1: int
            old position
        """
        q = self._items[x1]

        self._items.pop(x1)
        self._items.insert(x, q)
        self._populate_list(self._items)
        self.select_item(x)

    def _verify_buttons(self, *_):
        """Verify the Buttons dependent on the list's size."""

        def disable_buttons():
            """
            Disable the dependent Buttons as there
            is no item selected in the ModelList.
            """
            for _g in self._list_buttons:
                _g.disable()

        sel = self.treeview.get_selection()

        if sel:
            # GtkTreeIter, 'iter_'
            iter_ = sel.get_selected()[1]

            if iter_:
                # The move and delete Buttons are dependent
                # on their selection state and the list size.
                x = self.get_sel_x()
                for g in self._list_buttons:
                    if (
                        iter_ and
                        len(self._items) >= g.need_count and
                        x is not None
                    ):
                        g.enable()
                    else:
                        g.disable()
            else:
                disable_buttons()
        else:
            disable_buttons()

    def get_value(self):
        """
        Get a list of strings displayed in the
        list. Is part of the Widget template.

        Return: list
            of ModelList items
            [(name, model type),]
        """
        return self._items

    def on_model_list_change(self, g):
        """
        Receive change notifications for Widgets in the ModelList.

        g: Widget
            Has changed.
        """
        k = g.key

        if k == ok.MODEL_LIST:
            self._verify_buttons()

        elif g.key == self._up_arrow:
            self._move_sel_up()

        elif g.key == self._down_arrow:
            self._move_sel_down()

        elif g.key == DELETE:
            self._del_item()

        elif g.key == NEW:
            k = self._model_type.get_value()
            self._make_model(None, k)
        elif g.key == MODEL_TYPE:
            k = g.get_value()
            if k in Tip.MODEL_TYPE:
                g.set_tooltip_text(Tip.MODEL_TYPE[k])
        self._on_model_list_host_change(g)

    def rename_item(self, x, n):
        """
        Rename an item.

        x: the current list item index
        n: name of item
        """
        super(ModelList, self).rename_item(x, n)
        self._items[x] = n, self._items[x][md.TYPE_INDEX]

    def set_value(self, q, is_preset=False):
        """
        Load the item list from the owner's
        list. Is part of the Widget template.
        """
        # Remove incompatible Model(s).
        q1 = []

        for i in q:
            n = i[md.TYPE_INDEX]
            if n in md.MODEL_TYPE_LIST:
                q1.append(i)
            q = q1

        # Before loading a ModelList Preset, clear the previous Model(s).
        if is_preset:
            while self._items:
                self.select_item(0)
                self._del_item()

        else:
            self._items = q
            self._populate_list(q)

        # Load a ModelList Preset.
        if is_preset:
            for i in q:
                self._make_model(*i)
