#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_color_grid import ColorGrid
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_option_preset import Preset
from roller_render_hub import RenderHub
import gimpfu as fu

cs = Fu.ColorSelect
de = Fu.Despeckle
ed = Fu.Edge
em = Fu.Emboss
pdb = fu.pdb
rn = Fu.RGBNoise


class DarkFort:
    """Create a dark texture that resembles a brick wall."""

    @staticmethod
    def do(o):
        """
        Do the Dark Fort Backdrop Style.
        Is a Backdrop Style template function.

        o: One
            Has variables.

        Return: layer or None
            with Dark Fort
        """
        def noise():
            """Add noise to the colored part grid."""
            # Create a selection from any black pixels.
            pdb.gimp_by_color_select(
                z,
                (0, 0, 0),
                cs.THRESHOLD_0,
                fu.CHANNEL_OP_REPLACE,
                cs.YES_ANTIALIAS,
                cs.NO_FEATHER,
                cs.FEATHER_RADIUS_0,
                cs.NO_SAMPLE_MERGED
            )

            # Clear the black grid.
            Lay.clear_sel(z)

            pdb.plug_in_rgb_noise(
                j, z,
                rn.YES_INDEPENDENT,
                rn.NO_CORRELATED,
                rn.NOISE_TENTH,
                rn.NOISE_TENTH,
                rn.NOISE_TENTH,
                rn.NOISE_ZERO
            )
            pdb.plug_in_emboss(
                j, z,
                azimuth,
                elevation,
                em.DEPTH_3,
                em.BUMP
            )
            pdb.plug_in_despeckle(
                j, z,
                de.RADIUS_4,
                de.ADAPTIVE,
                de.BLACK_7,
                de.WHITE_248
            )
            pdb.plug_in_despeckle(
                j, z,
                de.RADIUS_30,
                de.ADAPTIVE,
                de.BLACK_7,
                de.WHITE_248
            )

        cat = Hat.cat
        j = cat.render.image

        # Dark Fort Preset dict, 'd'
        d = o.d

        if d[ok.OPACITY]:
            z = Lay.add(j, "Grid")

            # Group key, 'o.k'
            group = Lay.group(j, o.k + " WIP", z=z)

            azimuth = cat.azimuth
            elevation = cat.elevation
            d[ok.COLOR_2A] = (0, 0, 0, 255), (255, 255, 255, 255)

            # Remove the Bump for ColorGrid.
            e = deepcopy(d[ok.BUMP])
            d[ok.BUMP] = Preset.get_default(ok.BUMP)
            grid = ColorGrid.draw_color_grid(z, d)

            z = Lay.clone(grid, n="Noise")

            Sel.color(z, (0, 0, 0))

            sel = cat.save_short_term_sel()

            pdb.gimp_selection_none(j)
            noise()

            z1 = Lay.clone(z, n="HSV Value")
            z1.mode = fu.LAYER_MODE_HSV_VALUE

            Lay.flip(z1, horizontal=1)
            pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            z = Lay.merge(z1)
            z1 = Lay.clone(z, n="Difference")
            z1.mode = fu.LAYER_MODE_DIFFERENCE

            pdb.plug_in_plasma(
                j, z,
                d[ok.RANDOM_SEED] + cat.seed_global,
                Fu.Plasma.LOWEST_TURBULENCE
            )
            z = Lay.clone(z, n="Unsharp Mask")

            Sel.load(j, sel)
            Lay.blur(z, 1)
            Gegl.unsharp_mask(z, 2., .5, 0.)
            pdb.gimp_selection_none(j)

            z = Lay.merge(z)

            pdb.gimp_drawable_desaturate(z, fu.DESATURATE_LUMINANCE)
            pdb.plug_in_emboss(
                j, z,
                azimuth,
                elevation,
                em.DEPTH_3,
                em.BUMP
            )

            z = Lay.merge_group(group)

            # Return the Bump for the finish.
            d[ok.BUMP] = e
            return RenderHub.finish_style(o, d, z, has_mode=True)
