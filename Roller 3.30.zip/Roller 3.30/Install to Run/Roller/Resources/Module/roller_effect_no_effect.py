#!/usr/bin/env python
# -*- coding: utf-8 -*-


class NoEffect:
    """
    Don't do anything. Use so a preview
    without an Image Effect can show images.
    """

    @staticmethod
    def do(o):
        """
        Is an Image Effect template function.

        o: One
            Has variables.
            not used
        """
        return
