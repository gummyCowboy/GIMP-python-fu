#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, uniform
from roller_constant_for import Justification as ju, Resize as fz, Stack as st
from roller_constant_fu import Fu
from roller_constant_key import (
    Layer as nk,
    Model as md,
    Option as ok,
    Step as sk
)
from roller_model_image import Image
from roller_one import Hat, One, Rect
from roller_one_extract import dispatch, Form, Render, Shape, Step
from roller_one_fu import Lay, Mage, Sel
from roller_one_tip import Tip
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
ro = Fu.Rotate


def apply_shape_mask(z, shape):
    """
    Create a shape selection and clear outside of it.

    z: layer
        with image

    shape: tuple or dict
        Has polygon shape data.
    """
    Sel.shape(z.image, shape)
    Sel.invert_clear(z)


def calc_shift_position(o, x, y):
    """
    Calculate the Shift position for an image.

    o: One
        Has variables.

    x, y: int
        topleft corner of a pocket

    Return: tuple
        (x, y, is shifted)
        int
            x, y
            Shift modified
        bool
            Is true if there was a Shift in the position.
    """
    # Shift Preset, 'o.e'
    d = o.e[ok.SHIFT]

    # position
    x1 = Render.get_factor_w(d[ok.OFFSET_X_SHIFT])
    y1 = Render.get_factor_h(d[ok.OFFSET_Y_SHIFT])
    shift_x = Render.get_factor_w(d[ok.SHIFT_X])
    shift_y = Render.get_factor_h(d[ok.SHIFT_Y])
    x1 += randint(-shift_x, shift_x)
    y1 += randint(-shift_y, shift_y)

    if o.model.add_shift_x:
        x1 = o.shift.x = x1 + o.shift.x

    if o.model.add_shift_y:
        y1 = o.shift.y = y1 + o.shift.y
    return x + x1, y + y1, bool(y1 or x1)


def calc_shift_rotation(o):
    """
    Calculate the rotation angle for an image assigned to a cell.
    Store the rotation in 'o.model.table', the Model's cell table.

    o: One
        e: dict
            Place Preset

        model: Model
            Has a 'set_rotation' method.

        r, c: int
            a cell index

    rotate: float
        Is added to the rotation angle.

    return: float
        the rotation angle
    """
    # rotation angle, 'f'
    d = o.e[ok.SHIFT]
    f = d[ok.ROTATE]
    f += uniform(-d[ok.ROTATE_JITTER], d[ok.ROTATE_JITTER])

    if o.model.add_shift_rotate:
        f = o.shift.rotate = f + o.shift.rotate

    o.model.set_rotation(o.r, o.c, f)
    return f


def calc_shift_size(o, w, h):
    """
    Calculate the Shift size for an image.

    o: One
        e: dict
            of image place

    w, h: int
        dimension of pocket

    Return: tuple
        w, h
        shift size modified
    """
    d = o.e[ok.SHIFT]

    # size
    w1 = Render.get_factor_w(d[ok.WIDTH_MOD])
    h1 = Render.get_factor_h(d[ok.HEIGHT_MOD])
    shift_w = Render.get_factor_w(d[ok.SHIFT_WIDTH])
    shift_h = Render.get_factor_h(d[ok.SHIFT_HEIGHT])
    w1 += randint(-shift_w, shift_w)
    h1 += randint(-shift_h, shift_h)

    if o.model.add_shift_w:
        w1 = o.shift.w = w1 + o.shift.w

    if o.model.add_shift_h:
        h1 = o.shift.h = h1 + o.shift.h
    return max(1, w + w1), max(1, h + h1)


def calc_z_height(d, r, is_table):
    """
    Calculate the z-height amount and store the value for a cell.

    d: dict
        of Shift Preset

    r: int
        cell row

    is_table: bool
        Is true when the Table Model class is calling.
        The OFFSET_Z option is invalid for the other Models.

    Return: int
        z-height
    """
    a = 0 if is_table else r
    a += randint(0, d[ok.SHIFT_Z])
    if is_table:
        a += d[ok.OFFSET_Z]
    return a


def get_trim_size(s, t):
    """
    Calculate the size of a trim.

    s: tuple
        (w, h)
        of int
        image size

    t: tuple
        (w, h)
        of int
        cell size

    Return: list
        size with trim
    """
    # ratios
    w_r = t[0] / 1. / s[0]
    h_r = t[1] / 1. / s[1]

    if s[0] < t[0] and s[1] < t[1]:
        # The trim is not needed.
        w, h = s

    else:
        if w_r < h_r:
            # The image height is closer to the cell size.
            f = h_r

        else:
            # The image width is closer to the cell size.
            f = w_r

        w, h = int(s[0] * f), int(s[1] * f)
        w = min(w, s[0])
        h = min(h, s[1])

    # underflow
    return [max(w, 1), max(h, 1)]


def mold_cover(o):
    """
    Resize an image using the Cover Resize Method.
    Return with the image data in the buffer.

    o: One
        Has variables.

    Return: buffer data
        of the image
    """
    j = o.j
    s = j.size
    t = j.pocket.size

    # width and height ratios
    w_r = t[0] / 1. / s[0]
    h_r = t[1] / 1. / s[1]

    if w_r < h_r:
        # The image height is closer to the cell size.
        f = h_r

    else:
        # The image width is closer to the cell size.
        f = w_r

    Mage.copy_all(j.j)

    j1 = pdb.gimp_edit_paste_as_new_image()

    Mage.shape(j1, int(s[0] * f), int(s[1] * f))

    j1 = pdb.gimp_edit_paste_as_new_image()
    s1 = select_image_trim(o.e, j, j1)

    # Copy the visible selection.
    pdb.gimp_edit_copy_visible(j1)

    pdb.gimp_image_delete(j1)

    j.mold.size = s1
    return True


def mold_crop(o):
    """
    Get image material for a Crop Resize Method.

    o: One
        Has variables.

    Return: bool
        Is true if there is material in the buffer.
        buffer data
            of the image
    """
    j = o.j
    j1 = None
    is_copy = True
    e = o.e[ok.RESIZE_METHOD]

    Sel.rect(
        j.j,
        e[ok.CROP_X], e[ok.CROP_Y],
        e[ok.CROP_W], e[ok.CROP_H],
        option=fu.CHANNEL_OP_REPLACE
    )

    if Sel.is_sel(j.j):
        # Copy the selection.
        pdb.gimp_edit_copy_visible(j.j)
        pdb.gimp_selection_none(j.j)
        j1 = pdb.gimp_edit_paste_as_new_image()

    else:
        is_copy = False

    if j1:
        if j1.width > j.pocket.w or j1.height > j.pocket.h:
            # Copy a rectangle.
            j.mold.size = select_image_trim(o.e, j, j1)

        else:
            j.mold.size = j1.width, j1.height
            pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)
    return is_copy


def mold_fill(o):
    """
    Resize using a Fill Resize Method.

    o: One
        Has variables.

    Return: buffer data, True
        of the image; The buffer is valid.
    """
    j = o.j

    if j.size != j.pocket.size:
        Mage.copy_all(j.j)

        j1 = pdb.gimp_edit_paste_as_new_image()
        w, h = j.mold.size = j.pocket.size
        Mage.shape(j1, w, h)

    else:
        j.mold.size = j.size
        Mage.copy_all(j.j)
    return True


def mold_fixed(o):
    """
    Resize an image with Fixed Resize Method.

    o: One
        Has variables.

    Return: buffered image, bool
        Is true if there is material in the buffer.
    """
    j = o.j
    is_copy = True

    Mage.copy_all(j.j)

    j1 = pdb.gimp_edit_paste_as_new_image()
    e = o.e[ok.RESIZE_METHOD]

    pdb.gimp_layer_scale(
        j1.layers[0],
        e[ok.FIXED_IMAGE_SIZE_W],
        e[ok.FIXED_IMAGE_SIZE_H],
        Fu.LayerScale.IMAGE_ORIGIN
    )
    pdb.gimp_image_resize_to_layers(j1)

    if j1:
        if j1.width > j.pocket.w or j1.height > j.pocket.h:
            # Copy a rectangle.
            j.mold.size = select_image_trim(o.e, j, j1)

        else:
            j.mold.size = j1.width, j1.height
            pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

    else:
        is_copy = False
    return is_copy


def mold_factor(o):
    """
    Resize an image by multiplying its size by a factor.

    o: One
        Has variables.

    Return: bool
        Is true if there is material in the buffer.
        buffer data
            of the image
    """
    j = o.j
    is_copy = True

    Mage.copy_all(j.j)

    j1 = pdb.gimp_edit_paste_as_new_image()
    e = o.e[ok.RESIZE_METHOD]

    pdb.gimp_layer_scale(
        j1.layers[0],
        int(j1.width * round(e[ok.FACTOR_IMAGE_SIZE_W], 6)),
        int(j1.height * round(e[ok.FACTOR_IMAGE_SIZE_H], 6)),
        Fu.LayerScale.IMAGE_ORIGIN
    )
    pdb.gimp_image_resize_to_layers(j1)

    if j1:
        if j1.width > j.pocket.w or j1.height > j.pocket.h:
            # Copy a rectangle.
            j.mold.size = select_image_trim(o.e, j, j1)

        else:
            j.mold.size = j1.width, j1.height
            pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

    else:
        is_copy = False
    return is_copy


def mold_image(o):
    """
    Mold an image to fit a cell.

    o: One
        Has variables.

    Return: image in buffer, bool
        Is true if there is material in the buffer.
    """
    def calculate_mold(_x, _y, _w, _h):
        """
        x, y: int
            topleft coordinate

        _w, _h: int
            size of the molded image
        """
        # Calculate mold.
        if n in ju.RIGHT:
            _x += j.pocket.w - _w

        if n in ju.CENTER_X:
            _x += (j.pocket.w - _w) // 2

        if n in ju.CENTER_Y:
            _y += (j.pocket.h - _h) // 2

        elif n in ju.BOTTOM:
            _y += j.pocket.h - _h
        return _x, _y, _w, _h

    pdb.gimp_selection_none(Hat.cat.render.image)

    model = o.model
    o.is_not_shaped = True
    r, c = o.r, o.c
    d = o.e
    j = o.j
    j.mold.size = j.mold.position = 0, 0

    if o.is_box:
        j.pocket = Rect(0, 0, *model.get_image_size(o.face_x, r, c))

    else:
        j.pocket = model.get_pocket(r, c)
        j.shape = model.get_shape(r, c)
        j.pocket.size = calc_shift_size(o, *j.pocket.size)

    j.cell_shape = model.cell_shape

    if MOLD[d[ok.RESIZE_METHOD][ok.RESIZE_TYPE]](o):
        n = d[ok.JUSTIFICATION]

        if not o.is_box:
            f = calc_shift_rotation(o)
            f1 = j.rotate + f
            if f1:
                s = j.pocket.size
                j1 = pdb.gimp_edit_paste_as_new_image()

                if model.is_not_rectangular:
                    o.is_not_shaped = False
                    apply_shape_mask(
                        j1.layers[0],
                        dispatch[model.cell_shape](
                            Rect(0, 0, j1.width, j1.height)
                        )
                    )

                z = Lay.rotate(j1, f1)
                t = w, h = z.width, z.height

                pdb.gimp_edit_copy_visible(j1)
                pdb.gimp_image_delete(j1)

                if (w > s[0] or h > s[1]) and not f:
                    t = w, h = Shape.calc_lock(s, t)
                    j2 = pdb.gimp_edit_paste_as_new_image()
                    Mage.shape(j2, w, h)
                j.mold.size = t

            x, y, w, h = calculate_mold(*j.pocket.position + j.mold.size)
            x, y, is_shift = calc_shift_position(o, x, y)
            j.mold.position = x, y

            model.set_mold(r, c, x, y, w, h)

            if is_shift:
                j.shape = dispatch[model.cell_shape](j.mold)
            return True
        else:
            x, y, w, h = calculate_mold(0, 0, *j.mold.size)

            model.set_mold(o.face_x, r, c, x, y, w, h)

            j.mold.position = x, y
            j.mold.size = w, h
            return True
    return False


def mold_lock(o):
    """
    Resize an image using the Locked Aspect Ratio Resize Method.

    o: One
        Has variables.

    Return: buffer data, True
        of the image; The buffer is valid.
    """
    j = o.j

    Mage.copy_all(j.j)

    if j.width > j.pocket.w or j.height > j.pocket.h:
        # down-size
        w, h = Shape.calc_lock(j.pocket.size, j.size)
        j1 = pdb.gimp_edit_paste_as_new_image()
        Mage.shape(j1, w, h)

    else:
        w, h = j.size

    j.mold.size = w, h
    return True


def mold_trim(o):
    """
    Resize an image using the Trimmed Side Resize Method.
    Finish with the image data in the buffer.

    o: One
        Has variables.

    Return: buffer data, True
        of the image; The buffer is valid.
    """
    j = o.j
    s = s1 = j.size
    t = j.pocket.size

    Mage.copy_all(j.j)

    if s[0] > t[0] or s[1] > t[1]:
        w, h = get_trim_size(s, t)
        j1 = pdb.gimp_edit_paste_as_new_image()

        Mage.shape(j1, w, h)

        j1 = pdb.gimp_edit_paste_as_new_image()
        s1 = select_image_trim(o.e, j, j1)

        # Copy the visible selection.
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

    j.mold.size = s1
    return True


def place_image(o, group, k, is_plan):
    """
    Copy and paste an image after molding it to a cell.

    model: Model
        Has cell table.

    o: One
        Has variables.

    group: layer
        group for image layer group

    k: value
        key to image selection

    is_plan: bool
        Is true when called by Plan.

    return: image layer or None
        with image
        Is None and no selection when there is no image.
    """
    j = o.j

    # Place Preset dict, 'o.e'
    d = o.e

    cat = Hat.cat
    o.is_box = o.model_type == md.BOX
    pdb.gimp_selection_none(cat.render.image)

    # The Image's GIMP image will enter the copy and paste buffer.
    if mold_image(o):
        z = Lay.paste(group.layers[0])

        if d[ok.FLIP][0]:
            Lay.flip(z, horizontal=1)

        if d[ok.FLIP][1]:
            # vertical flip
            z = Lay.flip(z)

        # The 'mold' attribute is set in the 'mold_image' function.
        pdb.gimp_layer_set_offsets(z, j.mold.x, j.mold.y)

        if o.model.is_not_rectangular and o.is_not_shaped and not o.is_box:
            apply_shape_mask(z, j.shape)

        if o.is_box:
            s = Render.size()

            # If the pasted layer is larger than the render,
            # then there is no need set the layer's size.
            if s[0] >= z.width and s[1] >= z.height:
                # Set layer 'z' size to the image size with the merge.
                # The merge probably sets some layer properties that the
                # paste layer function doesn't. IDK why but I was able
                # correct some wonky-ness in the transform perspective
                # function with this merge layer technique.
                z1 = Lay.add_above(z, "Scale")
                z = pdb.gimp_image_merge_down(z.image, z1, fu.CLIP_TO_IMAGE)
                pdb.gimp_layer_resize(z, j.pocket.w, j.pocket.h, 0, 0)
            z = Shape.transform_face(o, z)

        Sel.item(z)
        cat.save_image_sel(z, k)

        if not is_plan:
            z.opacity = d[ok.OPACITY]

        Image.close_image(j)
        return z


def select_image_trim(d, j, j1):
    """
    Use to get the cell-size scaled image material
    for a Trimmed Side resized or non-resized image.
    Create a selection rectangle for image data transfer.
    Copy the selection.

    d: dict
        Place Preset dict

    j: Image
        Has cell info.

    j1: GIMP image
        to be trimmed

    Return: tuple
        the selection size
    """
    # Need to select from one layer only.
    # extra image flag, 'm'
    m = False

    if len(j1.layers) > 1:
        Mage.copy_all(j1)

        m = True
        j1 = pdb.gimp_edit_paste_as_new_image()

    n = d[ok.JUSTIFICATION]
    s = j.pocket.size
    t = j1.width, j1.height

    if n in ju.LEFT:
        x = 0
        x1 = s[0]

    elif n in ju.RIGHT:
        x = max(t[0] - s[0], 0)
        x1 = t[0]

    else:
        # horizontal center
        x = max(t[0] // 2 - s[0] // 2, 0)
        x1 = min(t[0] // 2 + s[0] // 2 + s[0] % 2, t[0])

    if n in ju.TOP:
        y = 0
        y1 = s[1]

    elif n in ju.BOTTOM:
        y = max(t[1] - s[1], 0)
        y1 = t[1]

    else:
        # vertical center
        y = max(t[1] // 2 - s[1] // 2, 0)
        y1 = min(t[1] // 2 + s[1] // 2 + s[1] % 2, t[1])

    # Correct for underflow.
    if x == x1:
        x1 += 1

    if y == y1:
        y1 += 1

    w = max(x1 - x, 1)
    h = max(y1 - y, 1)

    Sel.rect(j1, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
    pdb.gimp_edit_copy(j1.layers[0])

    _, x, y, x1, y1 = pdb.gimp_selection_bounds(j1)

    if m:
        pdb.gimp_image_delete(j1)
    return x1 - x, y1 - y


class Place:
    """Provide image Place functionality access."""

    @staticmethod
    def blur_behind_box(o):
        """
        Blur behind a Box image(s).

        o: One
            Has variables.

        Return: layer
            with blur behind material
        """
        cat = Hat.cat
        j = cat.render.image
        row, column = o.model.division

        # Is a list of layers for the Preview's undo function, 'undo_z'.
        undo_z = []

        for face_x in range(3):
            # Blur Behind layer, 'blur_z'
            blur_z = None

            # selection list for image layer, 'sel_q'
            sel_q = []

            d = Form.get_face_chunk_from_step(o.step, sk.PLACE, face_x)
            is_per_cell = d[ok.PER_CELL]

            for r in range(row):
                for c in range(column):
                    go = Shape.is_double_cell(o.model.double_type, r, c)
                    k = o.model_name, face_x, r, c

                    if go:
                        e = is_per_cell[r][c] if is_per_cell else d
                        go = blur = e[ok.BLUR_BEHIND]

                    if go:
                        go = sel = cat.get_image_sel(k)

                    if go:
                        z = go = cat.get_layer((
                            o.render_type,
                            o.model_name,
                            face_x,
                            nk.IMAGE
                        ))
                    if go:
                        if not blur_z:
                            blur_z = Lay.clone_background(z)
                            blur_z.name = z.name + " Blur Behind"
                            undo_z += [blur_z]

                        # Join the Mask selection with the image selection.
                        cat.join_selections(sel, k)
                        if Sel.is_sel(j):
                            Lay.blur(blur_z, blur)
                            sel_q += [pdb.gimp_selection_save(j)]
            if blur_z:
                pdb.gimp_selection_none(j)

                for i in sel_q:
                    Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
                    pdb.gimp_image_remove_channel(j, i)
                Sel.invert_clear(blur_z)
        return undo_z

    @staticmethod
    def blur_behind_cell(o):
        """
        Blur behind a Custom Cell Model's image.

        o: One
            Has variables.

        Return: layer
            with Blur Behind material
        """
        z = None
        d = Step.get_place_chunk(o)

        if o.image_layer and d[ok.BLUR_BEHIND]:
            z = RenderHub.blur_behind(o.image_layer, d, is_merge=False)
            if z:
                z.name = Lay.name(z.parent, nk.IMAGE_BEHIND)
        return z

    @staticmethod
    def blur_behind_grid(o):
        """
        Blur Behind Grid-type Model cells.

        o: One
            Has variables.
        """
        def process_layer():
            def do():
                z1_ = z1

                if not z1_:
                    z1_ = Lay.clone_background(z)
                    z1_.name = Lay.name(z1_.parent, nk.IMAGE_BEHIND)

                cat.join_selection(k)
                Lay.blur(z1_, blur)
                return z1_, [cat.save_short_term_sel()]

            q = []
            z1 = None

            if is_nested_group:
                n = z.parent.name.split(" ")[-1]

            else:
                n = z.name.split(" ")[-1]

            for r in range(row):
                for c in range(column):
                    go = Shape.is_allocated_cell(o.model, r, c)

                    if go and is_merge_cell:
                        s = d[ok.PER_CELL][r][c]
                        go = s != (-1, -1)

                    if go:
                        e = is_per_cell[r][c] if is_per_cell else d
                        go = blur = e[ok.BLUR_BEHIND]

                    if go:
                        k = o.model_name, r, c
                        go = cat.is_image_sel(k)
                    if go:
                        if is_nested_group:
                            if cat.get_z_height(k) == n:
                                z1, sel = do()
                                q += sel
                        else:
                            z1, sel = do()
                            q += sel
            if z1:
                pdb.gimp_selection_none(j)

                for sel in q:
                    Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

                if q:
                    Sel.invert_clear(z1)
                return z1

        cat = Hat.cat
        j = cat.render.image
        z = o.image_layer

        # Is a list of layers for the Preview's undo function, 'undo_z'.
        undo_z = []

        if z:
            d = Step.get_place_chunk(o)
            row, column = o.model.division
            is_merge_cell = o.model.is_merge_cell
            is_per_cell = d[ok.PER_CELL] if ok.PER_CELL in d else False
            is_nested_group = Lay.with_nested_group(z)
            if is_per_cell or d[ok.BLUR_BEHIND]:
                if Lay.with_nested_group(z):
                    for i in z.layers[::-1]:
                        for z in i.layers:
                            if cat.get_image_layer(z.name):
                                undo_z += [process_layer()]
                                break
                else:
                    # The image layer is either a layer with one or more
                    # images, or a group with one or more child image layers.
                    undo_z = process_layer()
        return undo_z

    @staticmethod
    def do_box(o, is_plan):
        """
        Place Box Model images onto the Render.

        o: One
            Has place variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with image
        """
        def do_gradient():
            if not is_plan:
                return GradientLight.apply_light(z, ok.IMAGE_INFLUENCE)
            return z

        cat = Hat.cat
        j = cat.render.image
        z = group = None

        # Place Preset dict, 'o.d'
        d = o.e = o.d

        row, column = o.model.division
        is_per_cell = d[ok.PER_CELL]
        go = True
        face_x = o.face_x = Step.get_face_index(o.step)
        name = o.model_name
        parent = cat.get_layer((o.render_type, o.model_name, nk.IMAGE))

        if not is_per_cell:
            go = Tip.has_pic(d[ok.IMAGE])[0] and d[ok.OPACITY]

        if go:
            # Place images.
            for r in range(row):
                for c in range(column):
                    if Shape.is_double_cell(o.model.double_type, r, c):
                        o.r, o.c = r, c
                        arg = face_x, r, c

                        # Place Preset dict, 'e'
                        e = o.e = is_per_cell[r][c] if is_per_cell else d

                        go = Tip.has_pic(e[ok.IMAGE])[0] and e[ok.OPACITY]
                        if go:
                            j1 = o.j = Image.get_image(
                                e[ok.IMAGE],
                                o.image_index
                            )
                            if j1:
                                j1.cell_shape = o.model.cell_shape
                                n = j1.layer_name if j1.layer_name else \
                                    j1.image_name

                                o.model.set_image_name(n, *arg)

                                if not group:
                                    group = Lay.group(
                                        j,
                                        Lay.name(parent, nk.IMAGE) +
                                        " Face " + str(o.face_x + 1),
                                        parent=parent
                                    )
                                    Lay.add(j, "Base", parent=group)
                                place_image(
                                    o,
                                    group,
                                    (name,) + arg,
                                    is_plan
                                )

        if group:
            z = Lay.merge_group(group)
            z = do_gradient()

            # Register layer for Mask.
            cat.register_layer(
                (o.render_type, o.model_name, face_x, nk.IMAGE),
                z
            )
        return z

    @staticmethod
    def do_custom_cell(o, is_plan):
        """
        Place a Custom Cell image onto the Render.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with image
        """
        cat = Hat.cat
        j = cat.render.image
        z = None

        # Place Preset dict, 'o.d'
        d = o.e = o.d

        name = o.model_name

        if Tip.has_pic(d[ok.IMAGE])[0]:
            j1 = o.j = Image.get_image(d[ok.IMAGE], o.image_index)
            o.model.set_image(0, 0, j1)
            if j1:
                cat.seed(d[ok.SHIFT])

                base = Lay.add(j, "Image Base", parent=o.parent)
                j1.rotate = d[ok.ROTATE]
                o.r = o.c = 0
                z = place_image(o, o.parent, name, is_plan)

                if z:
                    n = j1.layer_name if j1.layer_name else j1.image_name

                    o.model.set_image_name(0, 0, n)
                    cat.save_z_height(name, "0")
                    z.name = Lay.name(o.parent, nk.IMAGE)
                Lay.remove(base)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.IMAGE_INFLUENCE)

        if z:
            cat.register_layer((o.render_type, o.model_name, nk.IMAGE), z)
        return z

    @staticmethod
    def do_table(o, is_plan):
        """
        Place Table Model image material onto the Render.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with image material
        """
        def do_gradient():
            if not is_plan:
                return GradientLight.apply_light(z, ok.IMAGE_INFLUENCE)
            return z

        cat = Hat.cat
        j = cat.render.image
        z = group = None

        # Place Preset dict, 'o.d'
        d = e = o.e = o.d

        row, column = o.model.division
        parent = o.parent
        name = o.model_name
        is_per_cell = d[ok.PER_CELL]
        is_merge_cell = o.model.is_merge_cell
        loft = []
        grid_d = o.model.d
        go = True

        if not is_per_cell:
            go = Tip.has_pic(e[ok.IMAGE])[0] and e[ok.OPACITY]
            cat.seed(d[ok.SHIFT])

        if go:
            # Place images.
            for r in range(row):
                for c in range(column):
                    if Shape.is_allocated_cell(o.model, r, c):
                        go = True
                        o.r, o.c = r, c

                        if is_merge_cell:
                            if grid_d[ok.PER_CELL][r][c] == (-1, -1):
                                go = False

                        if is_per_cell and go:
                            e = o.e = is_per_cell[r][c]
                            go = Tip.has_pic(e[ok.IMAGE])[0] \
                                and e[ok.OPACITY]
                            cat.seed(e[ok.SHIFT])
                        if go:
                            j1 = o.j = Image.get_image(
                                e[ok.IMAGE],
                                o.image_index
                            )
                            if j1:
                                j1.cell_shape = o.model.cell_shape
                                k = name, r, c
                                n = j1.layer_name if j1.layer_name \
                                    else j1.image_name

                                o.model.set_image_name(r, c, n)
                                o.model.set_image(r, c, j1)

                                if not group:
                                    group = Lay.group(
                                        j, Lay.name(parent, nk.IMAGE),
                                        parent=parent
                                    )

                                z_height = calc_z_height(e[ok.SHIFT], r, True)
                                j1.rotate = Form.get_image_rotate(o)
                                n1 = str(z_height)
                                n2 = Lay.name(group, n1)

                                if z_height in loft:
                                    x = loft.index(z_height)
                                    group1 = group.layers[x]

                                else:
                                    loft += [z_height]
                                    loft = sorted(loft)[::-1]
                                    x = loft.index(z_height) + 1
                                    z = Lay.add(j, n1, parent=group)
                                    group1 = Lay.group(
                                        j,
                                        n2,
                                        parent=group,
                                        offset=x,
                                        z=z
                                    )
                                if place_image(o, group1, k, is_plan):
                                    cat.save_z_height(k, n1)

        if group:
            if len(group.layers) == 1:
                z = Lay.merge_group(group)
                z = do_gradient()
            else:
                q = group.layers

                for x, z in enumerate(q):
                    z = Lay.merge_group(z)
                    z = do_gradient()

                    Lay.group(
                        j,
                        z.parent.name + " Group " + z.name.split(" ")[-1],
                        parent=group,
                        offset=x,
                        z=z
                    )
                    cat.save_image_layer(z)
                z = group

        cat.register_layer((o.render_type, o.model_name, nk.IMAGE), z)
        return z

    @staticmethod
    def do_stack(o, is_plan):
        """
        Place Stack Model images onto the Render.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer (single or group) or None
            with image
        """
        def do_gradient():
            if not is_plan:
                return GradientLight.apply_light(z, ok.IMAGE_INFLUENCE)
            return z

        cat = Hat.cat
        j = cat.render.image
        z = group = None

        # Place Preset dict, 'o.d'
        d = e = o.e = o.d

        parent = o.parent
        is_per_cell = d[ok.PER_CELL]
        loft = []
        o.c = 0
        go = True
        o.shift = One(x=0, y=0, w=0, h=0, rotate=0)

        if not is_per_cell:
            go = Tip.has_pic(e[ok.IMAGE])[0] and e[ok.OPACITY]
            cat.seed(d[ok.SHIFT])

        if go:
            # Place images.
            for r in range(o.model.cell_count):
                o.r = r

                if is_per_cell:
                    e = o.e = is_per_cell[r][0]
                    go = Tip.has_pic(e[ok.IMAGE])[0] and e[ok.OPACITY]
                    cat.seed(e[ok.SHIFT])

                if go:
                    j1 = o.j = Image.get_image(e[ok.IMAGE], o.image_index)
                    if j1:
                        n = j1.layer_name if j1.layer_name else j1.image_name

                        # image-type key, (model name, row, column)
                        k = o.model_name, r, 0

                        o.model.set_image_name(r, 0, n)
                        o.model.set_image(r, 0, j1)

                        if not group:
                            group = Lay.group(
                                j, Lay.name(parent, nk.IMAGE),
                                parent=parent
                            )

                        j1.rotate = Form.get_image_rotate(o)
                        z_height = calc_z_height(e[ok.SHIFT], r, False)
                        n1 = str(z_height)
                        n2 = Lay.name(group, n1)

                        if z_height in loft:
                            x = loft.index(z_height)
                            group1 = group.layers[x]

                        else:
                            loft += [z_height]
                            loft = sorted(loft)[::-1]
                            x = loft.index(z_height) + 1
                            z = Lay.add(j, n1, parent=group)
                            group1 = Lay.group(
                                j,
                                n2,
                                parent=group,
                                offset=x,
                                z=z
                            )
                        if place_image(o, group1, k, is_plan):
                            cat.save_z_height(k, n1)

        if group:
            if len(group.layers) == 1:
                z = Lay.merge_group(group)
                z = do_gradient()
            else:
                q = group.layers

                for x, z in enumerate(q):
                    z = Lay.merge_group(z)
                    z = do_gradient()
                    if o.model.image_group_type == st.EACH_HAS_GROUP:
                        Lay.group(
                            j,
                            z.parent.name + " Group " + z.name.split(" ")[-1],
                            parent=group,
                            offset=x,
                            z=z
                        )
                        cat.save_image_layer(z)

                # Stack's 'one' image-group-type has
                # only image layers in its layer group.
                if o.model.image_group_type == st.ONE_GROUP:
                    cat.save_image_layer(group)
                z = group

        cat.register_layer((o.render_type, o.model_name, nk.IMAGE), z)
        return z


MOLD = {
    ok.COVER: mold_cover,
    fz.CROP: mold_crop,
    ok.FILLED: mold_fill,
    fz.FIXED: mold_fixed,
    fz.FACTOR: mold_factor,
    ok.LOCKED: mold_lock,
    ok.TRIM: mold_trim
}
