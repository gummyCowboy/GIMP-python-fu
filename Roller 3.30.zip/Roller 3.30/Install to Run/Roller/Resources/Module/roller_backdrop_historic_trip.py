#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
de = Fu.Despeckle


class HistoricTrip:
    """
    Fill the Backdrop Image with a stony texture
    making lines derived from the Backdrop Image.
    """

    @staticmethod
    def do(o):
        """
        Do the Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            with Backdrop Style
        """
        def merge(_z, _n):
            """
            Merge a group and set its resulting layer mode.

            _z: layer group
                to merge

            _n: string
                version number

            return: layer
                Is the result of the merge.
            """
            _z = Lay.merge_group(_z)
            _z.mode = fu.LAYER_MODE_GRAIN_MERGE
            _z.name = "Grain Merge " + _n
            pdb.plug_in_colortoalpha(j, _z, (0, 0, 0))
            return _z

        # Historic Trip Preset dict, 'd'
        d = o.d

        # Backdrop Image layer, 'o.z'
        if d[ok.OPACITY] and Lay.has_pixel(o.z):
            cat = Hat.cat
            j = cat.render.image

            # Backdrop Image layer, 'o.z'
            # Group key, 'o.k'
            z = Lay.clone(o.z, n=o.k)
            parent = Lay.group(j, o.k + " WIP #1", z=z)

            z1 = Lay.clone(o.z, n="Original #1")
            group = Lay.group(j, o.k + " WIP #2", parent=parent, z=z1)
            z2 = Lay.clone(z1, n="Difference #1")
            z2.mode = fu.LAYER_MODE_DIFFERENCE
            color = RenderHub.get_average_color(z)

            for _ in range(d[ok.ITERATIONS]):
                Gegl.spread(
                    z2,
                    0,
                    amount_x=d[ok.SPREAD],
                    amount_y=min(6, d[ok.SPREAD])
                )

            z1 = Lay.clone(o.z, n="Original #3")
            group1 = Lay.group(j, "Sub-Group", parent=parent, z=z1)
            z2 = Lay.clone(z1, n="Difference #2")
            z2.mode = fu.LAYER_MODE_DIFFERENCE

            for _ in range(d[ok.ITERATIONS]):
                Gegl.spread(
                    z2,
                    0,
                    amount_x=min(6, d[ok.SPREAD]),
                    amount_y=d[ok.SPREAD]
                )

            Lay.color_fill(z, color)

            z1 = merge(group, "#1")
            z2 = merge(group1, "#2")

            pdb.gimp_edit_copy_visible(j)

            z = Lay.paste(z2, n="HSV Value")
            z.mode = fu.LAYER_MODE_HSV_VALUE

            Gegl.emboss(z1, cat.azimuth, 12, 1)
            Gegl.emboss(z2, cat.azimuth, 12, 1)
            Gegl.waterpixels(z, size=d[ok.SUPERPIXEL_SIZE])

            z = Lay.paste(z, n="Dissolve")
            z.mode = fu.LAYER_MODE_DISSOLVE
            z.opacity = 50.

            Gegl.blur(z, 5.)
            pdb.gimp_edit_copy_visible(j)

            z = Lay.paste(z, n="Saturation")

            Gegl.saturation(z, d[ok.SATURATION])

            z = Lay.merge_group(parent, n=o.k + " WIP")
            pdb.plug_in_despeckle(
                j, z,
                de.RADIUS_1,
                0,
                de.BLACK_MINUS_ONE,
                de.WHITE_256
            )
            return RenderHub.finish_style(o, d, z, has_mode=True)
