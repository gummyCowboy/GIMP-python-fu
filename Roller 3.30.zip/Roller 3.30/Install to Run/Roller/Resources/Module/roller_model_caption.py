#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Caption as pt, Justification as ju, Model as mo
from roller_constant_key import (
    Layer as nk,
    Model as md,
    Option as ok,
    Step as sk
)
from roller_model_text import Text
from roller_one import Base, Comm, Hat, Rect
from roller_one_fu import Lay, Sel
from roller_one_extract import Form, Render, Shape, Step
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

pdb = fu.pdb
X_IS_0 = Y_IS_0 = W_IS_0 = H_IS_0 = 0
YES_ANTIALIAS = 1


def blur_behind_box_face(o):
    """
    Blur behind Box cells and Faces for the Caption Stripe.

    o: One
        Has variables.

    Return: list
        of layers with Blur Behind material
    """
    cat = Hat.cat
    j = cat.render.image
    n = o.model_name
    row, column = o.model.division

    # one for each face
    undo_z = [None, None, None]

    for face_x in range(3):
        # blur material layer, 'z1'
        z1 = None

        # a list of Caption Stripe selection, 'q'
        q = []

        z = cat.get_layer(
            (
                o.render_type,
                o.model_name,
                face_x,
                nk.CELL_CAPTION
            )
        )
        if z:
            # Caption Preset dict with a Per Cell cell table, 'd'
            d = Form.get_face_chunk_from_step(o.step, sk.CAPTION, face_x)
            is_per_cell = d[ok.PER_CELL]
            for r in range(row):
                for c in range(column):
                    arg = face_x, r, c
                    k = (n,) + arg
                    go = Shape.is_double_cell(o.model.double_type, r, c)

                    if go:
                        # Caption Preset dict, 'e'
                        e = is_per_cell[r][c] if is_per_cell else d

                        go = blur = e[ok.BACKGROUND_STRIPE][ok.BLUR_BEHIND]
                    if go:
                        sel = cat.get_caption_stripe_sel(k)
                        if sel:
                            q += [sel]

                            if not z1:
                                z1 = Lay.clone_background(z)
                                z1.name = Lay.name(
                                    z1.parent,
                                    nk.CAPTION_BEHIND +
                                    " Face " + str(face_x + 1)
                                )

                            Sel.load(j, sel)
                            Lay.blur(z1, blur)
            if z1:
                pdb.gimp_selection_none(j)

                for i in q:
                    Sel.load(j, i, option=fu.CHANNEL_OP_ADD)

                if q:
                    Sel.invert_clear(z1)
                undo_z[face_x] = z1
    return undo_z


def blur_behind_canvas(o, z, d):
    """
    Blur behind a Canvas Caption Stripe.

    o: One
        Has variables.

    z: layer
        with Caption Stripe

    d: dict
        Caption Stripe Preset

    return: layer
        with Caption material
    """
    if d[ok.STRIPE_TYPE] and d[ok.BLUR_BEHIND]:
        z1 = RenderHub.blur_behind(z, d)
        if z1:
            z = z1
            Hat.cat.register_layer(
                (o.render_type, o.model_name, nk.CANVAS_CAPTION),
                z
            )
    return z


def get_text(o, *k):
    """
    Assemble the text as defined by the options.
    Update 'o.image_number' for the sequence type in Model.

    o: One
        Has variables.

    k: tuple
        for retrieving image name

    Return: string
        the Caption text
    """
    # Caption Preset dict, 'o.e'
    d = o.e

    text = ""
    caption_type = d[ok.CAPTION_TYPE]

    if caption_type == pt.TEXT:
        text = d[ok.TEXT]

    elif caption_type == pt.SEQUENCE_NUMBER:
        if o.is_per_cell:
            text = d[ok.TEXT]
        else:
            text = str(o.image_number)
            o.image_number += 1

    elif caption_type == pt.IMAGE_NAME:
        text = o.model.get_image_name(*k) if o.model_type in \
            md.MULTI_IMAGE else o.model.get_image_name(*k)
    if caption_type in (pt.IMAGE_NAME, pt.SEQUENCE_NUMBER):
        n = d[ok.LEADING_TEXT]
        n1 = d[ok.TRAILING_TEXT]
        if text:
            if n:
                text = n + text
            if n1:
                text += n1
    return text


def make_caption(z, o, text, name, save_sel=False):
    """
    Add text. Call once per Caption instance.

    z: layer
        to receive text

    o: One
        Has variables.

    text: string
        to display

    name: string
        layer name
        either a layer or cell-type Caption layer

    save_sel: bool
        When true, the Caption Stripe selection is saved.

    Return: layer or None
        with Caption material
    """
    go = True
    cat = Hat.cat
    j = cat.render.image

    # Caption material layer, 'z1'
    z1 = None

    # Caption Preset dict, 'o.e'
    d = o.e

    font = d[ok.FONT]

    if font not in cat.font_list:
        Comm.info_msg(mo.MISSING_ITEM.format("Caption", "font", font))
        go = False

    if go:
        color = (255, 255, 255) if o.is_plan else d[ok.COLOR_1A]
        go, z1 = Text.make_text_layer(
            j, z,
            YES_ANTIALIAS,
            X_IS_0, Y_IS_0,
            text,
            d[ok.FONT_SIZE],
            font,
            color[:3],
            W_IS_0, H_IS_0
        )

    if go:
        Sel.item(z1)
        pdb.plug_in_autocrop_layer(j, z1)

        x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]

        text_width = x1 - x
        text_height = y1 - y
        half_width = text_width // 2
        half_height = text_height // 2
        top, bottom, left, right = Form.calc_margin(
            d[ok.CAPTION_MARGIN],
            o.rect.w, o.rect.h
        )

        # cell width, height
        w = o.rect.w - left - right
        h = o.rect.h - top - bottom
        n = d[ok.JUSTIFICATION]

        # correction for the w, h dimension
        w = max(w, 1)
        h = max(h, 1)

        # cell position x, y
        s = Render.size()
        x = o.rect.x + left
        y = o.rect.y + top
        x = min(x, s[0] - 1)
        y = min(y, s[1] - 1)

        # Get 'y'.
        if n in ju.BOTTOM:
            y += h - text_height

        elif n in ju.CENTER_Y:
            # middle
            y += (h // 2) - half_height

        # Get 'x'.
        if n in ju.RIGHT:
            x += w - text_width

        elif n in ju.CENTER_X:
            # center
            x += (w // 2) - half_width

        # Correct the x, y position.
        x = Base.seal(x, o.rect.x, s[0] - 1)
        y = caption_y = Base.seal(y, o.rect.y, s[1] - 1)

        # Move the text layer.
        pdb.gimp_layer_set_offsets(z1, x, y)

        if not o.is_plan:
            z1.name = name
            z1.opacity = color[3] / 255. * 100.
            z1 = Shadow.do_shadows(d[ok.TRI_SHADOW], z1)

        # Make the Caption Stripe.
        d = d[ok.BACKGROUND_STRIPE]
        if d[ok.STRIPE_TYPE]:
            Sel.item(z1)

            center_y = caption_y + half_height
            stripe_h = int(text_height * d[ok.STRIPE_HEIGHT])
            y = center_y - stripe_h // 2
            z2 = Lay.add_below(z1, "Caption Stripe")
            color = o.color if o.is_plan else d[ok.COLOR_1A]

            Sel.rect(
                j,
                o.rect.x, y,
                o.rect.w, stripe_h,
                option=fu.CHANNEL_OP_REPLACE
            )

            if o.is_clip:
                # Modify the Stripe selection to be
                # within the bounds of a cell shape.
                Sel.shape(j, o.shape, option=fu.CHANNEL_OP_INTERSECT)

            if d[ok.BLUR_BEHIND] and not o.is_plan and save_sel:
                cat.save_caption_stripe_sel((o.model_name, o.r, o.c))

            Sel.fill(z2, color)
            z1 = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

        if o.is_clip:
            Sel.shape(j, o.shape)
            Sel.invert_clear(z1, keep_sel=True)
    return z1


class Caption:
    """Provide Caption functionality access."""

    @staticmethod
    def blur_behind_box(o):
        """
        Blur behind Box cells and Faces for the Caption Stripe.

        o: One
            Has variables.

        Return: list
            of layers with Blur Behind material
        """
        q = blur_behind_box_face(o)
        z = Caption.blur_behind_grid(o, path=(sk.CELL, sk.CAPTION))
        return q + [z]

    @staticmethod
    def blur_behind_custom_cell(o):
        """
        Blur behind a Custom Cell Model's Caption Stripe.

        o: One
            Has variables.

        Return: layer or None
            with Caption and Blur Behind
        """
        cat = Hat.cat
        z1 = None
        d = Step.get_cell_caption_form(o)[ok.BACKGROUND_STRIPE]
        blur = d[ok.BLUR_BEHIND]

        if d[ok.STRIPE_TYPE] and blur:
            j = cat.render.image
            z = cat.get_layer((
                o.render_type,
                o.model_name,
                None,
                nk.CELL_CAPTION
            ))
            if z:
                z1 = Lay.clone_background(z)
                z2 = Lay.clone_opaque(z)
                z1.name = Lay.name(z1.parent, nk.CAPTION_BEHIND)

                Sel.item(z2)
                Lay.blur(z1, blur)
                Sel.invert_clear(z1)
                j.remove_layer(z2)
        return z1

    @staticmethod
    def blur_behind_grid(o, path=(sk.IMAGE, sk.CAPTION)):
        """
        Blur behind grid-type cells for the Caption Stripe.

        o: One
            Has variables.

        path: tuple
            Is the post Model specific Node step(s).
            The Box and Table Models differ in their Node step.
            The default tuple is for the Table Model.

        Return: layer or None
            with Blur Behind
        """
        cat = Hat.cat
        j = cat.render.image
        d = Step.get_dict_from_step(o.step[:3] + path)
        is_merge_cell = o.model.is_merge_cell
        is_per_cell = d[ok.PER_CELL]
        n = o.model_name

        # size of a merged cell, 's'
        # Indicate a topleft cell with '1'.
        s = 1

        # a list of Caption Stripe selection, 'q'
        q = []

        z = cat.get_layer(
            (
                o.render_type,
                o.model_name,
                None,
                nk.CELL_CAPTION
            )
        )
        row, column = o.model.division

        # for the blur material
        z1 = None

        if z:
            for r in range(row):
                for c in range(column):
                    k = n, r, c
                    go = Shape.is_allocated_cell(o.model, r, c)

                    if go:
                        if is_merge_cell:
                            s = o.model.d[ok.PER_CELL][r][c]
                        if s == (-1, -1):
                            go = False

                    if go:
                        e = is_per_cell[r][c] if is_per_cell else d
                        go = blur = e[ok.BACKGROUND_STRIPE][ok.BLUR_BEHIND]
                    if go:
                        sel = cat.get_caption_stripe_sel(k)
                        if sel:
                            q += [sel]
                            if not z1:
                                z1 = Lay.clone_background(z)
                                z1.name = Lay.name(
                                    z1.parent,
                                    nk.CAPTION_BEHIND
                                )

                            Sel.load(j, sel)
                            Lay.blur(z1, blur)
            if z1:
                pdb.gimp_selection_none(j)

                for i in q:
                    Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
                if q:
                    Sel.invert_clear(z1)
        return z1

    @staticmethod
    def do_box(o, is_plan):
        """
        Do the Cell-based Caption for a Box Model.
        Does one Face or once for the cell.

        o: One
            Has variables.

        is_plan: bool
            Is true if Plan is calling.

        Return: layer or None
            with Caption material
        """
        face_x = o.face_x = Step.get_face_index(o.step)

        if o.face_x is None:
            return Caption.do_grid(o, is_plan)

        cat = Hat.cat
        j = cat.render.image
        row, column = o.model.division
        parent = cat.get_layer((o.render_type, o.model_name, nk.CAPTION))
        n = Lay.name(parent, nk.CELL_CAPTION + " Face " + str(o.face_x + 1))
        o.is_plan = is_plan
        z = group = None
        o.is_clip = False

        # Caption Preset dict, 'o.d'
        d = o.d

        o.image_number = d[ok.START_NUMBER]
        is_per_cell = o.is_per_cell = d[ok.PER_CELL]

        for r in range(row):
            for c in range(column):
                o.r, o.c = r, c
                arg = face_x, r, c
                go = Shape.is_double_cell(o.model.double_type, r, c)

                if go:
                    # Caption Preset dict, 'o.e'
                    o.e = is_per_cell[r][c] if is_per_cell else d

                    text = get_text(o, *arg)
                    if not text:
                        go = False

                if go:
                    go = o.e[ok.CAPTION_TYPE] != "None"
                if go:
                    if not group:
                        group = Lay.group(j, n, parent=parent)

                    a = o.rect = Rect(
                        0, 0,
                        *o.model.get_image_size(*arg)
                    )
                    z = make_caption(
                        Lay.add(j, "Caption", parent=group),
                        o,
                        text,
                        n
                    )
                    if z:
                        z1 = Lay.add_above(z, "Scale")
                        z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

                        pdb.gimp_layer_resize(z, a.w, a.h, 0, 0)

                        z = Shape.transform_face(o, z)
                        if (
                            o.e[ok.BACKGROUND_STRIPE][ok.BLUR_BEHIND] and
                            not o.is_plan
                        ):
                            z1 = Lay.clone_opaque(z)

                            Sel.item(z1)
                            cat.save_caption_stripe_sel((o.model_name,) + arg)
                            Lay.remove(z1)

        if group:
            z = Lay.merge_group(group)
        return z

    @staticmethod
    def do_custom_cell(o, is_plan):
        """
        Do a Caption for a Custom Cell Model.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with Caption material
        """
        # Caption Preset dict, 'o.d'
        # The 'get_text' function needs 'o.e'.
        o.e = o.d

        o.r = o.c = 0
        return Caption.do_singular_cell_type(
            o,
            is_plan,
            get_text(o, *(o.r, o.c)),
            o.d[ok.CAPTION_TYPE]
        )

    @staticmethod
    def do_canvas(o, is_plan):
        """
        Do a Canvas Caption.

        o: One
            Has variables.

        Return: layer or None
            with Caption material
        """
        cat = Hat.cat
        parent = o.parent

        # Caption Preset dict, 'o.d'
        d = o.e = o.d

        j = cat.render.image
        z = None
        text = d[ok.TEXT]

        if text and d[ok.CAPTION_TYPE] != "None":
            is_clip = o.is_clip = d[ok.CLIP_TO_CELL]
            o.is_plan = is_plan
            n = Lay.name(parent, nk.CANVAS_CAPTION)
            group = Lay.group(j, n, parent=parent)
            z = Lay.add(j, "Caption", parent=group)
            size = Render.size()

            if d[ok.OBEY_MARGINS]:
                y, bottom, x, right = o.model.canvas_margin
                w = size[0] - x - right
                h = size[1] - y - bottom

            else:
                x = y = 0
                w, h = size

            o.rect = Rect(x, y, w, h)

            if is_clip:
                o.shape = (
                    x, y,
                    x + w, y,
                    x + w, y + h,
                    x, y + h
                )

            make_caption(z, o, text, n)

            z = Lay.merge_group(group)
            if not is_plan:
                e = d[ok.BACKGROUND_STRIPE]
                z = blur_behind_canvas(o, z, e)
        return z

    @staticmethod
    def do_singular_cell_type(o, is_plan, text, caption_type):
        """
        Custom Cell and Stack are single
        cell Models that use this function.

        o: One
            Has variables.

        is_plan: bool
            Is true when Plan is calling.

        text: string
            caption

        caption_type: string
            Caption Type

        Return: layer or None
            with Caption material
        """
        z = group = None

        if text and caption_type != "None":
            j = Hat.cat.render.image
            n = Lay.name(o.parent, nk.CELL_CAPTION)
            o.is_clip = o.d[ok.CLIP_TO_CELL]
            o.is_plan = is_plan
            o.shape = o.model.get_shape(0, 0)
            o.rect = o.model.get_cell_rect(0, 0)
            group = Lay.group(j, n, parent=o.parent)
            z = Lay.add(j, "Caption", parent=group)
            make_caption(z, o, text, n)

        if group:
            z = Lay.merge_group(group)
        return z

    @staticmethod
    def do_stack(o, is_plan):
        """
        Do a Stack Model's Caption.

        o: One
            Has variables.

        is_plan: bool
            Is true when Plan is calling.

        Return: layer or None
            with Caption material
        """
        # Caption Preset dict, 'o.d'
        o.e = o.d

        o.r = o.c = 0
        return Caption.do_singular_cell_type(
            o,
            is_plan,
            get_text(o, o.d[ok.CAPTION_TYPE], *(o.r, o.c)),
            o.d[ok.CAPTION_TYPE]
        )

    @staticmethod
    def do_grid(o, is_plan):
        """
        Do cell Caption for the Grid-type Models.

        o: One
            Has variables.

        is_plan: bool
            Is true if Plan is calling.

        Return: layer or None
            with Caption material
        """
        cat = Hat.cat
        j = cat.render.image

        # Caption Preset dict, 'o.d'
        d = o.d

        is_merge_cell = o.model.is_merge_cell
        row, column = o.model.division
        o.image_number = d[ok.START_NUMBER]
        is_per_cell = o.is_per_cell = d[ok.PER_CELL]
        o.is_plan = is_plan
        z = group = None
        go = True

        if is_merge_cell:
            # Table Model's Type Preset dict, 'o.model.d'
            type_d = o.model.d[ok.PER_CELL]

        if not is_per_cell and o.d[ok.CAPTION_TYPE] == "None":
            go = False

        if go:
            for r in range(row):
                for c in range(column):
                    o.r, o.c = r, c
                    go = Shape.is_allocated_cell(o.model, r, c)

                    # Don't do dependent cells.
                    if go and is_merge_cell:
                        if type_d[r][c] == (-1, -1):
                            go = False

                    if go:
                        e = o.e = is_per_cell[r][c] if is_per_cell else d
                        text = get_text(o, *(r, c))
                        if not text:
                            go = False
                    if go:
                        if not group:
                            group = Lay.group(
                                j,
                                Lay.name(o.parent, nk.CELL_CAPTION),
                                parent=o.parent
                            )

                        o.rect = o.model.get_merge_cell_rect(r, c)
                        o.is_clip = e[ok.CLIP_TO_CELL]

                        if o.is_clip:
                            o.shape = o.model.get_shape(r, c)
                        make_caption(
                            Lay.add(j, "Caption", parent=group),
                            o,
                            text,
                            "Caption {} {}".format(r, c),
                            save_sel=True
                        )
        if group:
            z = Lay.merge_group(group)
        return z
