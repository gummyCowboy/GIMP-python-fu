#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat, One
from roller_one_extract import Render
from roller_one_fu import Lay, Mage, Sel
from roller_option_preset_dict import PresetDict
import gimpfu as fu

pdb = fu.pdb


class GradientLight:
    """
    Has functions used to make the GradientLight layer and apply its influence.
    """
    image = None

    @staticmethod
    def apply_light(z, k):
        """
        Apply Gradient Light influence to a layer.

        z: layer
            to receive gradient

        k: string
            an Option key from a Influence Preset

        Return: layer
            the original or its alter
        """
        def _apply():
            """
            Apply the Gradient Light to the layer.

            Return: layer
                with the Gradient Light applied
            """
            Mage.copy_all(GradientLight.image)

            # Gradient Light layer, '_z'
            _z = Lay.paste(z)
            _z1 = z

            if k == ok.METAL_FRAME:
                # Create a slight reflection for the metal frame edge.
                Sel.item(_z1)
                pdb.gimp_selection_shrink(j, 1)

                if Sel.is_sel(j):
                    sel = pdb.gimp_selection_save(j)

                    Sel.item(_z1)
                    Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

                    sel1 = pdb.gimp_selection_save(j)

                    Lay.hide(_z)
                    Lay.hide(_z1)
                    Mage.copy_all(j)

                    _z2 = Lay.paste(_z1)
                    _z2.opacity = 9.

                    # Mix in the image material.
                    Lay.blur(_z2, 12)

                    Sel.load(j, sel1)
                    Sel.invert_clear(_z2)
                    Lay.show(_z)
                    Lay.show(_z1)

                    _z1 = pdb.gimp_image_merge_down(j, _z2, fu.CLIP_TO_IMAGE)

                    pdb.gimp_image_remove_channel(j, sel)
                    pdb.gimp_image_remove_channel(j, sel1)

                # Create a metallic appearance.
                _z.mode = fu.LAYER_MODE_HARDLIGHT

            Sel.item(_z1)
            Sel.invert_clear(_z)

            _z.opacity = f
            return pdb.gimp_image_merge_down(j, _z, fu.CLIP_TO_IMAGE)

        def _do_layer():
            """
            Apply Gradient Light to a layer.

            Return: layer
                with Gradient Light applied
            """
            if GradientLight.image:
                return _apply()
            else:
                GradientLight.create_gradient_light(d)
                return _apply()

        if z:
            j = Hat.cat.render.image
            d = Hat.cat.gradient_light_d
            f = d[ok.INFLUENCE][k]
            if f:
                if pdb.gimp_item_is_group(z):
                    for z in z.layers:
                        _do_layer()
                else:
                    z = _do_layer()
        return z

    @staticmethod
    def create_gradient_light(d):
        """
        Create a Gradient Light image. The image is hidden from the user
        and is removed when Roller closes or by a GradientLight undo operation.
        Layers are created from the image using copy visible image function.

        d: dict
            Gradient Light Preset
        """
        w, h = Render.size()
        j = GradientLight.image = pdb.gimp_image_new(w, h, fu.RGB)
        e = PresetDict.get_default(by.GRADIENT_FILL)

        e.update(d)
        GradientFill.do_layer(j, One(d=e))
