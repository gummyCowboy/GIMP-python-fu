#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_render_gradient_light import GradientLight
from roller_render_shadow import do_extra_shadow
import gimpfu as fu

de = Fu.Despeckle
er = Fu.Erode
pdb = fu.pdb
EIGHT_COORDINATES = 8
H_SMOOTH_YES = V_SMOOTH_YES = 1


def do_image(j, image_layer, o):
    """
    Add a frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    cat = Hat.cat
    parent = image_layer.parent

    # shadow layer, 'z1'
    z1 = None

    # the Cutout Plate Preset dict, 'o.d'
    d = o.d

    group = Lay.group(j, Lay.name(parent, o.k), parent=parent)

    # frame layer, 'z'
    z = Lay.add(j, o.k, parent=group)

    # image_layer_1 = image_layer
    opaque = Lay.clone_opaque(image_layer, n="Opaque")

    Sel.make_layer_sel(opaque)
    Lay.remove(opaque)

    # Make a border around the outside of the selection.
    pdb.gimp_selection_border(j, d[ok.FRAME_WIDTH])

    # Create crumble selection from the frame selection.
    pdb.script_fu_distress_selection(
        j, z,
        d[ok.DISTRESS_THRESHOLD],
        d[ok.DISTRESS_SPREAD],
        4., 2.,
        H_SMOOTH_YES, V_SMOOTH_YES
    )

    go = False

    if Sel.is_sel(j):
        a = pdb.gimp_selection_save(j)

        # Add noise to the selection.
        # GEGL's Simplex-Noise failed me, so I use this.
        for i in range(12):
            Gegl.noise_rgb(
                z,
                1., 1., 1., 1.,
                d[ok.RANDOM_SEED] + cat.seed_global + i
            )

            if i % 2:
                pdb.plug_in_erode(
                    j, z,
                    er.PROPAGATE_BLACK,
                    er.RGB_CHANNELS,
                    er.FULL_RATE,
                    er.DIRECTION_MASK_7,
                    er.LOW_LIMIT_0,
                    er.UPPER_LIMIT_255
                )
            else:
                Lay.dilate(z)

        pdb.plug_in_despeckle(
            j, z,
            de.RADIUS_3,
            de.RECURSIVE_ADAPTIVE,
            de.BLACK_0,
            de.WHITE_255
        )

        z = Lay.clone(z, n="Difference")
        z.mode = fu.LAYER_MODE_DIFFERENCE
        go = True

        Sel.load(j, a)
        Sel.invert_clear(z)
        pdb.gimp_image_remove_channel(j, a)

    z = Lay.merge_group(group)

    if go:
        pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
        Gegl.saturation(z, .1)

        z = Lay.clone(z, n="Burn")

        Lay.dilate(z)

        z.mode = fu.LAYER_MODE_BURN
        z = Lay.merge(z)

        Sel.item(z)

        sel = cat.save_short_term_sel()
        z = Lay.clone_opaque(z, n="Burn")
        z = Lay.merge(z)
        z1 = do_extra_shadow(o, image_layer)

        Sel.isolate(z1, sel)
        pdb.gimp_drawable_curves_spline(
            z,
            fu.HISTOGRAM_VALUE,
            EIGHT_COORDINATES,
            (.0, .0, .345, .235, .627, .678, 1., 1.)
        )

    z = GradientLight.apply_light(z, ok.OTHER_FRAME)

    if z:
        z.name = Lay.name(z.parent, o.k)

    # Return the layers for undo.
    return [z, z1]


class CrumbleShell:
    """Is a sprinkle of noise around the edges of images."""

    @staticmethod
    def do(o):
        """
        Make the Crumble Shell Image Effect.
        Is an image-effect template function.

        o: One
            Has variables.

        o: One
            Has variables.

        Return: layer or list of layers
            with Crumble Shell
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # for Shadow #1 and Shadow #2, 'o.shadow_layer'
        o.shadow_layer = []

        # a list of layers for the preview's undo function, 'undo_z'
        undo_z = []

        if o.is_nested_group:
            for i in z.layers:
                undo_z += do_image(j, i.layers[0], o)

        else:
            undo_z = do_image(j, z, o)
        return undo_z
