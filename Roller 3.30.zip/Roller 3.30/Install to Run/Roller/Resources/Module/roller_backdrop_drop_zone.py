#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Base, Hat
from roller_one_extract import Render
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class DropZone:
    """Has shrinking rectangles colored by a gradient between two colors."""

    @staticmethod
    def do(o):
        """
        Draw the shrinking rectangles.

        o: One
            Has variables.

        Return: layer or None
            with Drop Zone material
        """
        cat = Hat.cat

        # the layer to return, 'z'
        z = None

        # Is a gradient that is created by a user option.
        grad = None

        # Drop Zone Preset dict, 'd'
        d = o.d

        j = cat.render.image

        if d[ok.OPACITY]:
            # the selection rectangle's dimension, 'w, h'
            w, h = Render.size()

            steps = d[ok.STEPS_DROP_ZONE]
            color, color1 = d[ok.COLOR_2A]
            mod_w = w / steps / 2.
            mod_h = h / steps / 2.

            if d[ok.INVERT]:
                color = RenderHub.invert_color(color)
                color1 = RenderHub.invert_color(color1)

            # RGBA of int, 'stair'
            # Is added to the start color once per iteration.
            stair = RenderHub.calc_gradient(color, color1, steps)

            # the selection rectangle's topleft coordinate, 'x, y'
            x = y = 0

            keep = d[ok.KEEP_GRADIENT]

            # There's no need to clip the previous
            # fill if the opacity is always 100%.
            is_clip = color[3] != 255 or color1[3] != 255

            if keep:
                # Make a unique gradient name.
                gradients = Hat.cat.gradient_list

                # gradient name, 'n'
                n = d[ok.NAME]

                if n in gradients:
                    n = Base.enumerate_name(n, gradients)

                # Create a gradient with evenly spaced
                # segments, one for each color.
                grad = pdb.gimp_gradient_new(n)
                pdb.gimp_gradient_segment_range_split_uniform(
                    grad,
                    0,
                    0,
                    steps
                )

            start_color = color[:]

            # Group key, 'o.k'
            # Backdrop Style layer, 'z'
            z = Lay.add(j, o.k + " WIP")

            for step in range(steps):
                # Set the 'Sel.fill' function's input to
                # the correct format (a tuple).
                # tuple of RGBA integers, 'q'
                q = tuple([int(i) for i in color])

                if keep:
                    # gradient, segment index, color, opacity
                    # The opacity value has to be rounded
                    # as it will overflow with float-sum (i.e. 100.00000007).
                    arg = grad, step, q[:3], round(q[3] / 255. * 100., 1)

                    # The start and end color is the same for a segment.
                    pdb.gimp_gradient_segment_set_left_color(*arg)
                    pdb.gimp_gradient_segment_set_right_color(*arg)

                if w >= 1 and h >= 1:
                    Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)

                    if is_clip:
                        Lay.clear_sel(z, keep_sel=True)
                    Sel.fill(z, q)

                # Define the next rectangle.
                x += mod_w
                y += mod_h
                w -= (mod_w * 2)
                h -= (mod_h * 2)

                color = ()
                for i in range(4):
                    b = stair[i] * (step + 1)
                    color += (start_color[i] + int(b),)
            z = RenderHub.finish_style(o, d, z, has_mode=True)

        # Create a gradient if the user desires.
        if grad and d[ok.KEEP_GRADIENT]:
            # Store image gradients so they can
            # be deleted before the program closes.
            Hat.cat.image_gradients_created.append(grad)

            # This gradient is kept and is
            # saved to a file when GIMP closes.
            Hat.cat.image_gradient_used = grad

        # Return the Drop Zone Backdrop Style layer for the undo function.
        return z
