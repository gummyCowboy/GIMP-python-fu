#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gtk
from roller_constant_for import Color as co
from roller_constant_key import Widget as wk
from roller_one import Base

MUST = {
    wk.ALIGN: (0, 0, 0, 0),
    wk.BOX: gtk.VBox,
    wk.PADDING: (0, 0, 0, 0)
}


class Box(gtk.Alignment):
    """This is a GTK Box widget with an GTK Alignment."""

    def __init__(self, **d):
        """
        Create a Box container for other Widgets.

        keys:
            box_type: class
                either VBox, HBox, VButtonBox, HButtonBox

            align: tuple
                of float
                top, bottom, left, right
                Alignment
                in .0 to 1.

            padding: tuple of int
                top, bottom, left, right
        """
        super(gtk.Alignment, self).__init__()

        for k in MUST:
            a = d[k] if k in d else MUST[k]
            setattr(self, k, a)

        self.box = self.box()

        self.set(*self.align)
        self.set_padding(*self.padding)
        super(gtk.Alignment, self).add(self.box)

    def add(self, g):
        """
        Add a Widget to the Box.

        g: GTK widget
            to add
        """
        self.box.add(g)

    def get_children(self):
        return self.box.get_children()

    def pack_start(self, g, **d):
        """
        Place a Widget in the Box.

        g: GTK widget
            Is packed into this container.

        d: dict
            keyword options
        """
        self.box.pack_start(g, **d)


class Cabinet(gtk.VBox):
    """
    Is a gtk.VBox with a few custom attributes.
    Use with the navigation tree where Nodes
    in the same column have the same Cabinet.
    """
    _color = Base.INIT_COLOR
    colors = []

    # Calculate a Cabinet background color gradient.
    # number of cabinets allocated, '15'
    for i in range(15):
        colors += [_color]
        _color = Base.reduce_color(_color)

    def __init__(self, column_number):
        """
        Create the VBox.

        column_number: int
            Stacked from the left-side of a pane.
            0 through 14
        """
        super(gtk.VBox, self).__init__()
        self.column_number = column_number
        self.cabinet_color = Cabinet.colors[column_number]


class Eventful(gtk.EventBox):
    """This is a custom GTK EventBox."""

    def __init__(self, color):
        """
        color: gtk color component
            None, int, tuple, or GTK color
        """
        super(gtk.EventBox, self).__init__()

        self.value = None
        if color is not None:
            if isinstance(color, int):
                q = gtk.gdk.Color(color, color, co.MAX_COLOR)

            elif isinstance(color, tuple):
                q = gtk.gdk.Color(*color)

            else:
                q = color
            self.modify_bg(gtk.STATE_NORMAL, q)

    def get_value(self):
        """
        Is part of the Widget template. Is used by PortCell to create a 'safe'.

        Return: value
            from 'self.value'
        """
        return self.value

    def set_value(self, a):
        """
        Set 'self.value'. Is part of the Widget template.
        Is used by PortCell to create a 'safe'.

        a: value
            Give to 'self.value'.
        """
        self.value = a
