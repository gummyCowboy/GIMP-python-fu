#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_option_preset_dict import PresetDict
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class AverageColor:
    """
    Determine the Backdrop Image's Average Color
    (mean average) and apply it over the Backdrop Image.
    """

    @staticmethod
    def do(o):
        """
        Do the Average Color Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            Is Average Color.
        """
        cat = Hat.cat
        j = cat.render.image

        # Average Color Preset dict, 'o.d'
        d = o.d

        if d[ok.OPACITY]:
            z = Lay.add(j, o.k + " WIP")
            e = PresetDict.get_default(by.COLOR_FILL)

            e.update(d)

            # RGB, 'q'
            q = RenderHub.get_average_color(o.z)

            if d[ok.INVERT]:
                q = RenderHub.invert_color(q)

            Lay.color_fill(z, q)
            return RenderHub.finish_style(o, d, z, has_mode=True)
