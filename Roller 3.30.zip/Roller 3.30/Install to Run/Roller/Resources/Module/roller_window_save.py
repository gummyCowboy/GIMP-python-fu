#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Widget as fw
from roller_constant_key import (
    Pickle as pc,
    Preset as pk,
    Widget as wk,
    Window as wi
)
from roller_one import OZ, Comm, Hat
from roller_port import Port
from roller_widget_box import Eventful
from roller_widget_button import Button
from roller_widget_entry import Entry
from roller_widget_label import Label
from roller_widget_splitter import Splitter
from roller_window import Window
import gtk
import os
import platform


# reference
# en.wikipedia.org/wiki/Filename#Reserved_characters_and_words
INVALID_CHAR = "/?%*:|<>" + '"' + "'" + "\\"


class RWSave(Window):
    """Is a GTK Dialog for saving a Preset."""
    preset_name = "New Preset"

    DUPLICATE_FILE = \
        "The file,\n\n{},\n\nalready exists. " \
        "Do you want to overwrite the existing file?"

    def __init__(self, d):
        """
        Create a Window.

        d: dict
            Has init values.
        """
        self._init_dict = d
        self.get_data = d[pk.GET_DATA]
        self.key = d['key']
        self.is_write = False
        n = d[wk.WINDOW_TITLE] = "Name the " + self.key + " Preset"
        d[wk.WINDOW_KEY] = wi.SAVE

        Window.__init__(self, d)

        e = {
            wk.ON_ACCEPT: self.accept,
            wk.ON_CANCEL: self.cancel,
            wk.SAVE_WINDOW: self,
            wk.WIN: self,
            wk.WINDOW_TITLE: n
        }
        self.port = PortSave(e, RWSave.preset_name, self.key)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()

    def accept(self, n):
        """
        Write the Preset, and if successful, close the Window.

        n: string
            name of the Preset

        Return: flag
            If true, the Window is done.
        """
        d = deepcopy(self.get_data())
        if RWSave.write(self.win, d, self.key, n):
            self._init_dict[pk.FILE_NAME] = RWSave.preset_name = n
            self.is_write = True
            return self.close()

    @staticmethod
    def write(win, d, key, n, overwrite=False):
        """
        Write the Preset, after checking if it already
        exists and asking permission to over-write.

        d: dict
            Preset or SuperPreset

        n: string
            second part of the file path
            the file name

        overwrite: flag
            If its false, a pop-up will confirm a file over-write.

        Return: bool
            Is true if the file was written.
        """
        # When in Windows OS, remove invalid file name characters.
        if platform.system() == "Windows":
            for i in INVALID_CHAR:
                n = n.replace(i, "")

        path = OZ.get_preset_path(
            key,
            n,
            Hat.cat.preset_folder
        )
        go = True

        if not overwrite:
            if path:
                if os.path.isfile(path):
                    n = RWSave.DUPLICATE_FILE.format(path)
                    go = Comm.pop_up(win, 0, n, "Duplicate File")

        if go:
            go = OZ.pickle_dump({pc.DATA: d, pc.FILE: path})
        return go


class PortSave(Port):
    """Use to interactively save a Preset."""

    def __init__(self, d, preset_name, preset_key):
        """
        Create the Window.

        d: dict
            Has init values.

        preset_name: string
            Use to make file path.
        """
        self._preset_name = preset_name
        self._preset_key = preset_key
        self._file_name_widget = self.save_b = None
        Port.__init__(self, d)

    def _draw_file_info_group(self, g):
        """
        The file info group shows the user the Preset file's location.

        g: GTK container
            for this group of Widgets
        """
        w = fw.MARGIN
        w1 = w // 2
        self.reduce_color()
        n = os.path.dirname(
            OZ.get_preset_path(self._preset_key, "", Hat.cat.preset_folder))

        drive, path = os.path.splitdrive(n)
        g1 = Splitter(padding=(w1, w1, w, w), has_inner_padding=True)
        g2 = Eventful(self.color)
        g3 = gtk.VBox()

        self.reduce_color()

        g4 = Eventful(self.color)
        g5 = self._file_name_box = gtk.VBox()
        g6 = self._file_name_widget = Label(text="")

        g2.add(g3)
        g4.add(g5)
        g1.both(g2, g4)
        g3.add(Label(text="Drive:"))
        g3.add(Label(text="Folder:"))
        g3.add(Label(text="File Name:"))
        g5.add(Label(text=drive))
        g5.add(Label(text=path))
        g5.add(g6)
        g1.no_pack()
        g.add(g1.container)
        self._draw_file_name(self._file_name_entry)

    def _draw_file_name(self, g):
        """
        Call whenever the Preset name entry changes. Update
        the file location group with the latest file name.

        g: GTK Entry
            file name Entry
        """
        if self._file_name_widget:
            n = OZ.get_preset_name(
                self._preset_key,
                g.get_value()
            )

            self._file_name_widget.widget.set_text(n)
            if self.save_b:
                if g.get_value().lower() in (
                            pk.DEFAULT.lower(),
                        ):
                    self.save_b.disable()
                else:
                    self.save_b.enable()

    def _draw_process_group(self, g):
        """
        Draw the Cancel and Save Buttons for the Port.

        g: GTK container
            for the Widget group
        """
        w = fw.MARGIN
        w1 = w // 2
        g1 = Splitter(padding=(w1, w1, w, w), has_inner_padding=True)
        g2 = self.save_b = Button(
            on_widget_change=self.accept,
            text="Save"
        )
        g3 = self.cancel_b = Button(
            on_widget_change=self.cancel,
            text="Cancel"
        )

        g1.both(g3, g2)
        g1.pack()
        g.add(g1.container)

    def _draw_variable_group(self, g):
        """
        Create an Entry for naming the Preset.

        g: GTK container
            for the Widget group
        """
        w = fw.MARGIN
        w1 = w // 2
        g1 = self._file_name_entry = Entry(
            on_key_press=self.on_key_press,
            on_widget_change=self._draw_file_name,
            padding=(0, w1, w, w)
        )

        g.add(Label(padding=(w1, 0, w, w), text="Preset Name:"))
        g.add(g1)
        g1.set_value(self._preset_name)
        g1.widget.select_region(0, -1)

    def draw_port(self, g):
        """
        Draw the Port's controls. Is part of the Port template.

        g: VBox
            container for the Widgets
        """
        # functions to draw an option group, 'q'
        q = (
            self._draw_variable_group,
            self._draw_file_info_group,
            self._draw_process_group
        )

        # Widget group Labels, 'q1'
        q1 = "Variables", "File Location", "Process"

        for x, p in enumerate(q):
            box = Eventful(self.color)
            g1 = gtk.VBox()

            box.add(g1)
            g.add(box)
            g1.add(Label(text=q1[x] + ":", padding=(2, 0, 4, 0)))
            p(g1)
            self.reduce_color()

    def accept(self, *_):
        """
        Proceed to write the Preset data.

        Return: true or None
            Is true if the write is successful.
        """
        return self.accept_port(self._file_name_entry.get_value())

    def cancel(self, *_):
        """
        Close the Window.

        Return: true
            The key-press is handled.
        """
        return self.cancel_port()
