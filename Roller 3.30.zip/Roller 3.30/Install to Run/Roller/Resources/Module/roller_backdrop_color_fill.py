#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class ColorFill:
    """Fill a copy of the Backdrop Image with a color."""

    @staticmethod
    def do(o):
        """
        Do the Color Fill Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            with Color Fill
        """
        # Color Fill Preset dict, 'd'
        d = o.d

        # Backdrop Image layer, 'o.z'
        z = Lay.clone(o.z, n=o.k + " WIP")

        # RGBA, 'q'
        q = d[ok.COLOR_1A]

        # Use to set the opacity context for bucket fill.
        d[ok.OPACITY] = q[3] / 255. * 100.

        if d[ok.INVERT]:
            q = RenderHub.invert_color(q)

        # fill point, 'x, y'
        x, y = RenderHub.get_render_points(d)[:2]

        # Preserve.
        foreground = pdb.gimp_context_get_foreground()

        RenderHub.set_fill_context(d)
        pdb.gimp_context_set_foreground(q)
        pdb.gimp_drawable_edit_bucket_fill(z, fu.FOREGROUND_FILL, x, y)

        # Restore.
        pdb.gimp_context_set_foreground(foreground)

        # Return the undo layer.
        return RenderHub.bump(z, d[ok.BUMP])
