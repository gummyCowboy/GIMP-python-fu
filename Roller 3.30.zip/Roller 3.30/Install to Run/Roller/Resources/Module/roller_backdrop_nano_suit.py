#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu
pdb = fu.pdb


class NanoSuit:
    """Fill the Backdrop Image with a gradient and a fabric-like texture."""

    @staticmethod
    def do(o):
        """
        Do the Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            with Nano Suit
        """
        # Nano Suit Preset dict, 'o.d'
        d = o.d

        if d[ok.OPACITY] and Lay.has_pixel(o.z):
            j = Hat.cat.render.image

            # Backdrop Image layer, 'o.z'
            # Group key, 'o.k'
            z = Lay.clone(o.z, n=o.k + " Base")

            group = Lay.group(j, o.k + " WIP", z=z)

            Lay.blur(z, 500)
            Gegl.video_degradation(z, 'dots')

            z = Lay.clone(z, n="Difference")
            z.mode = fu.LAYER_MODE_DIFFERENCE

            Gegl.engrave(z, 3)
            pdb.gimp_drawable_curves_spline(
                z,
                fu.HISTOGRAM_VALUE,
                4,
                (0, .5, 1., 1.)
            )

            z = Lay.merge_group(group)
            z.opacity = d[ok.OPACITY]

            if d[ok.INVERT]:
                pdb.gimp_drawable_invert(z, 0)
            return RenderHub.finish_style(o, d, z)
