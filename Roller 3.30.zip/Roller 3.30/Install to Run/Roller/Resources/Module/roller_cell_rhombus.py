#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_one import Rect
from roller_one_extract import Shape


class GridRhombus:
    """
    Calculate the coordinates and the size of cells.
    The cells are Rhombus shaped.
    """

    def __init__(self, o):
        """
        Calculate the cell size and a rhombus shape.

        o: One
            Has init values.
        """
        row, column = o.r, o.c
        table = o.model.table
        s = o.layer_space
        x, y = o.offset

        # intersect points
        q_x, q_y = [], []

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w, h = min(s[0], o.column_width / 1.), min(s[1], o.row_height / 1.)

            # table size
            w1, h1 = w / 2., h / 2.
            s1 = w + (column - 1) * w1, h + (row - 1) * h1
            x, y = Shape.calc_pin_offset(
                o.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        elif o.grid_type == gr.SHAPE_COUNT:
            # cell size
            w = s[0] / (.5 + column * .5)
            h = s[1] / (.5 + row * .5)
            w = min(w, h) / 1.
            w, h = w, w

            # table size
            h1 = h / 2.
            s1 = column * h1 + h1, row * h1 + h1
            x, y = Shape.calc_pin_offset(
                o.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            w = s[0] / (.5 + column * .5)
            h = s[1] / (.5 + row * .5)

        max_x, max_y = x + s[0], y + s[1]

        # intersects
        w1 = w / 2.
        h1 = h / 2.
        for c in range(column + 2):
            q_x.append(round(x))
            x += w1

        for r in range(row + 2):
            q_y.append(round(y))
            y += h1

        # Compose the points.
        for r in range(row):
            for c in range(column):
                if not o.is_table or Shape.is_allocated_cell(o.model, r, c):
                    y, y1, y2 = q_y[r], q_y[r + 1], q_y[r + 2]
                    x, x1, x2 = q_x[c], q_x[c + 1], q_x[c + 2]
                    position = x, y
                    size = x2 - x, y2 - y

                    if x + size[0] > max_x or y + size[1] > max_y:
                        size = position = 0, 0

                    # Cell, 'a'
                    a = table[r][c]

                    # Is the cell rectangle before margins, 'cell'.
                    a.cell = Rect(position[0], position[1], size[0], size[1])

                    if size[0]:
                        a.shape = a.plaque = x, y1, x1, y, x2, y1, x1, y2
