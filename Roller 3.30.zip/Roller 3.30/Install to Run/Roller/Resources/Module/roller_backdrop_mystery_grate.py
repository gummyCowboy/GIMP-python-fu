#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_color_grid import ColorGrid
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat
from roller_one import One
from roller_one_fu import Lay
from roller_option_preset import Preset
from roller_option_preset_dict import PresetDict
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


def do_1st_layer(j, d, e, d1, group):
    """
    Create a diamond-slat layer and a shadow.

    j: GIMP image
        Is render.

    d: dict
        Color Grid Preset dict

    e: dict
        Gradient Fill Preset dict

    d1: dict
        Mystery Grate Preset dict

    group: layer group
        work-in-progress
    """
    z = Lay.add(j, "1st Layer", parent=group)
    d[ok.ROW] = 1
    d[ok.COLUMN] = d1[ok.COLUMN_1]
    d[ok.COLOR_2A] = (255, 255, 255, 255), (0, 0, 0, 255)
    d[ok.MODE] = "Normal"
    d[ok.ROTATE] = 45.
    d[ok.BUMP] = Preset.get_default(ok.BUMP)
    z = ColorGrid.do(One(d=d, k="1st Layer", z=z))

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    RenderHub.do_stylish_shadow(z)
    Lay.create_mask(z)

    e[ok.START_X] = e[ok.START_Y] = 0, 0.
    e[ok.END_X] = e[ok.END_Y] = 0, 1.
    do_gradient(e, z)


def do_2nd_layer(j, d, e, d1, group):
    """
    Process the second layer.

    j: GIMP image
        Is render.

    d: dict
        Color Grid Preset dict

    e: dict
        Gradient Fill Preset dict

    d1: dict
        Mystery Grate Preset dict

    group: layer group
        work-in-progress
    """
    z = Lay.add(j, "2nd Layer", parent=group)
    d[ok.COLOR_2A] = (0, 0, 0, 255), (255, 255, 255, 255)
    d[ok.COLUMN] = d1[ok.COLUMN_2]
    z = ColorGrid.do(One(d=d, k="Grate", z=z))

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    RenderHub.do_stylish_shadow(z)
    Lay.create_mask(z)

    e[ok.END_X] = e[ok.END_Y] = 0, 0.
    e[ok.START_X] = e[ok.START_Y] = 0, 1.
    return do_gradient(e, z)


def do_3rd_layer(z):
    """
    Process the third layer.

    z: layer
        work-in-progress
    """
    z = Lay.clone(z)

    Lay.flip(z, horizontal=1)
    RenderHub.do_stylish_shadow(z)
    Lay.create_mask(z)


def do_gradient(d, z):
    """
    Draw a gradient.

    z: layer
        to receive the gradient
    """
    j = z.image
    z1 = GradientFill.do_layer(j, One(d=d))

    Lay.transfer_mask(z1, z)
    pdb.gimp_image_reorder_item(j, z1, z.parent, 0)
    return pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)


class MysteryGrate:
    """Has grate-like layers."""

    @staticmethod
    def do(o):
        """
        Create a Mystery Grate Backdrop Style.

        o: One
            Has variables.

        Return: layer
            Has Mystery Grate.
        """
        j = Hat.cat.render.image
        d = o.d
        e = PresetDict.get_default(by.GRADIENT_FILL)

        e.update(o.d)

        d1 = PresetDict.get_default(by.COLOR_GRID)
        d1[ok.ROTATE] = 45.
        z = GradientFill.do_layer(j, One(d=e))

        # Group key, 'o.k'
        z.name = o.k + " WIP"
        group = Lay.group(j, o.k, z=z)

        do_1st_layer(j, d1, e, d, group)

        z1 = do_2nd_layer(j, d1, e, d, group)

        do_3rd_layer(z1)

        e[ok.START_X] = e[ok.END_Y] = 0, 1.
        e[ok.END_X] = e[ok.START_Y] = 0, 0.
        return Lay.merge_group(group)
