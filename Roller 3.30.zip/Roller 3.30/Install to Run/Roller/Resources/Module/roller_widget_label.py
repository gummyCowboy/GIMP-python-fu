#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok, Widget as wk
from roller_model import Box, Table
from roller_one_extract import Step
from roller_one import One
from roller_one_extract import Render
from roller_widget import Widget
import gtk


def update_model_cell_table(step, model_class):
    """
    Update cell table.

    step: tuple
        of Node labels

    Return: Model instance
        Has cell table.
    """
    a = model_class(One(step=step))
    a.canvas_margin = Step.get_canvas_margin(step)
    a.update_type(One(d=Step.get_type_from_step(step)))
    a.calc_pocket(One(d=Step.get_cell_margin(step)))
    return a


class Label(Widget):
    """Is a custom GTK Label."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.Label(d[wk.TEXT])
        d[wk.ALIGN] = d[wk.ALIGN] if wk.ALIGN in d else (0, 0, 0, 0)

        Widget.__init__(self, g, **d)
        self.add(g)

    @staticmethod
    def get_value():
        """
        Is a Widget template function.

        a: undefined
            not used
        """
        return None

    def set_label_value(self, a):
        """
        Change the display value of the Label.

        a: string
            the new display value
        """
        if isinstance(a, str):
            self.widget.set_label(a)

    def set_value(self, a):
        """
        Is a Widget template function.

        a: undefined
            not used
        """
        return


class ModelGridLabel(Label):
    """Is a Label for displaying row and column counts."""

    TEMPLATE = "Row: {}, Column: {}"

    def __init__(self, **d):
        """
        Initialize the label.

        d: dict
            Has init values.
        """
        d[wk.TEXT] = GridLabel.TEMPLATE.format(0, 0)
        d[wk.ALIGN] = 0, 0, 1, 1

        Label.__init__(self, **d)

        self._model = None
        self._step = self.group.step
        self._render_size = 0, 0
        self._canvas_margin = {}

        # Grid-type Model Cell Type Preset dict, 'self._d'
        self._d = {}


class BoxGridLabel(ModelGridLabel):
    """Is a Label for displaying row and column counts."""

    def __init__(self, **d):
        """
        Initialize the Label Widget.

        d: dict
            Has init values for Widget.
        """
        ModelGridLabel.__init__(self, **d)
        self.container.connect('expose-event', self.on_grid_label_expose)

    def on_grid_label_expose(self, *_):
        """
        Respond to an expose event. Update the Label after a change.
        """
        # Grid-type Model Cell Type Preset dict, 'd'
        d = self.group.preset.get_value()

        size = Render.size()

        # Canvas Margin Preset dict, 'd1'
        d1 = Step.get_canvas_margin(self._step)

        if (
            d != self._d or
            self._render_size != size or
            self._canvas_margin != d1
        ):
            self._model = update_model_cell_table(self._step, Box)

        if self._model:
            r, c = self._model.division
            self.set_label_value(GridLabel.TEMPLATE.format(r, c))

        self._d = d
        self._canvas_margin = d1
        self._render_size = size


class GridLabel(ModelGridLabel):
    """Is a Label for displaying row and column counts."""

    def __init__(self, **d):
        """
        Initialize the Label Widget.

        d: dict
            Has init values.
        """
        ModelGridLabel.__init__(self, **d)
        self.container.connect('expose-event', self.on_grid_label_expose)

    def on_grid_label_expose(self, *_):
        """
        Respond to an expose event. Update the Label after a change.
        """
        d = self.group.preset.get_value()
        d[ok.PER_CELL] = []
        size = Render.size()
        d1 = Step.get_canvas_margin(self._step)

        if (
            d != self._d or
            self._render_size != size or
            self._canvas_margin != d1
        ):
            self._model = update_model_cell_table(self._step, Table)

        if self._model:
            r, c = self._model.division
            self.set_label_value(GridLabel.TEMPLATE.format(r, c))

        self._d = d
        self._canvas_margin = d1
        self._render_size = size
