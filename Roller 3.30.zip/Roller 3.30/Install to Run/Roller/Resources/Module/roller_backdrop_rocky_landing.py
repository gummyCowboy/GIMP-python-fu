#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
EDGE = "{} {} of {}"


def do_edge(z, mode, i, reps):
    """
    Shred the layer with the edge function and a layer mode.

    z: layer
        work-in-progress
        Is modified.

    mode: enum
        layer mode

    i: int
        repetition number

    reps: int
        number of repetitions

    Return: layer
        with modifications
    """
    j = z.image

    pdb.plug_in_edge(j, z, 1., 0, 0)

    z.mode = mode
    z = Lay.merge(z)
    return Lay.clone(z, n=EDGE.format("Edge", str(i), str(reps)))


class RockyLanding:
    """Create a rock-like Backdrop Style."""

    @staticmethod
    def do(o):
        """
        Create a Rocky Landing Backdrop Style.

        o: One
            Has variables.

        Return: layer or None
            with Rocky Landing
        """
        j = Hat.cat.render.image

        # Rocky Landing Preset dict, 'o.d'
        d = o.d

        if d[ok.OPACITY]:
            # Backdrop Image layer, 'o.z'
            # Group key, 'o.k'
            z = Lay.clone(o.z, n=o.k + " WIP")

            reps = d[ok.BLEND]
            reps1 = reps * 2 + 4
            group = Lay.group(j, o.k, z=z)

            pdb.plug_in_plasma(j, z, d[ok.RANDOM_SEED], 3)

            z1 = Lay.clone(z, n=EDGE.format(o.k, "1", reps1))

            Lay.color_fill(z, (0, 0, 0))

            z = Lay.clone(z1, n=EDGE.format(o.k, "2", reps1))
            z = do_edge(z, fu.LAYER_MODE_SUBTRACT, 3, reps1)
            z = do_edge(z, fu.LAYER_MODE_LCH_HUE, 4, reps1)
            x = 5

            for i in range(reps):
                z = do_edge(z, fu.LAYER_MODE_COLOR_ERASE, x, reps1)
                z = do_edge(z, fu.LAYER_MODE_LCH_CHROMA, x + 1, reps1)
                x += 2

            z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
            z1 = Lay.clone(z, n="Overlay")

            pdb.plug_in_emboss(j, z1, Hat.cat.azimuth, 30., 1, 1)

            z1.mode = fu.LAYER_MODE_OVERLAY

            pdb.gimp_drawable_invert(z1, 0)

            z = Lay.clone(z1, n="Despeckle")

            pdb.plug_in_despeckle(j, z1, 1, 1, 200, 255)
            pdb.gimp_layer_set_offsets(z, 0, 2)
            pdb.plug_in_sobel(j, z, 1, 0, 0)

            z.opacity = 83.
            z1.mode = fu.LAYER_MODE_NORMAL
            z1.opacity = 33.

            pdb.gimp_image_reorder_item(j, z1, group, 3)
            z = Lay.merge_group(group)
            return RenderHub.finish_style(o, d, z, has_mode=True)
