#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Model as md, Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
from roller_render_gradient_light import GradientLight
import gimpfu as fu

em = Fu.Emboss
hs = Fu.HueSaturation
pdb = fu.pdb
ELEVATION_30 = 30
SIX_COORDINATES = 6
EIGHT_COORDINATES = 8


def do_face(j, o):
    """
    Do the Image Effect for each Face.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        with the Image Effect
    """
    pdb.gimp_selection_none(j)

    for i in o.image_layer.layers:
        if i:
            Sel.item(i, option=fu.CHANNEL_OP_ADD)
    if Sel.is_sel(j):
        effect_layer = Lay.add_above(o.image_layer, n=o.k)
        do_image(o, effect_layer)
        return finish_effect_layer(j, o.image_layer, effect_layer)


def do_table(j, image_layer, effect_layer, o):
    """
    Do the Image Effect for each image placed by a Table Model.

    j: GIMP image
        Is render.

    image_layer: layer
        with layer position

    effect_layer: layer
        for frame

    o: One
        Has variables.
    """
    cat = Hat.cat
    d = o.model.d
    is_merge_cell = o.model.is_merge_cell
    n = image_layer.parent.name.split(" ")[-1]

    if not is_merge_cell:
        s = 1
    for r in range(o.r):
        for c in range(o.c):
            if is_merge_cell:
                s = d[ok.PER_CELL][r][c]

            # '(-1, -1)' is a dependent cell in a merge cell table.
            if s != (-1, -1):
                k = o.model_name, r, c

                cat.join_selection(k)
                if Sel.is_sel(j):
                    if o.is_nested_group:
                        if cat.get_z_height(k) == n:
                            do_image(o, effect_layer)
                    else:
                        do_image(o, effect_layer)


def embellish(j, z):
    """
    Add color and depth to the frame.

    j: GIMP image
        Is render.

    z: layer
        Has frame.

    Return: layer
        with new features
    """
    n = z.name
    group = Lay.group(j, n, parent=z.parent, z=z)
    z1 = Lay.clone(z)
    z1.mode = fu.LAYER_MODE_OVERLAY
    z1.opacity = 25.
    z1 = Lay.clone(z1)
    z1.mode = fu.LAYER_MODE_BURN
    z1.opacity = 50.

    pdb.plug_in_emboss(
        j, z,
        Hat.cat.azimuth,
        ELEVATION_30,
        em.DEPTH_3,
        em.EMBOSS
    )
    pdb.gimp_selection_none(j)

    z = Lay.merge_group(group)
    z.name = n

    pdb.gimp_drawable_hue_saturation(
        z,
        fu.HUE_RANGE_ALL,
        hs.HUE_OFFSET_0,
        hs.LIGHTNESS_0,
        hs.SATURATION_MINUS_50,
        hs.OVERLAP_0
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_RED,
        SIX_COORDINATES,
        (.0, .0, .549, .7568, 1., 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_GREEN,
        SIX_COORDINATES,
        (.0, .0, .5176, .4, 1., 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_BLUE,
        EIGHT_COORDINATES,
        (.0, .0, .2117, .0588, .6667, .4901, 1., 1.)
    )
    return z


def finish_effect_layer(j, image_layer, effect_layer):
    """
    Apply finishing touches to an Image Effect layer.

    j: GIMP image
        Is render.

    image_layer: layer or group
        Has image material.

    effect_layer: layer
        Has Image Effect.

    return: layer or None
        with Image Effect material and finishing touches
    """
    if effect_layer:
        Lay.clear_image_sel(image_layer, effect_layer)
        return GradientLight.apply_light(
            embellish(j, effect_layer),
            ok.METAL_FRAME
        )


def do_image(o, z):
    """
    Do the Image Effect for an image.

    o: One
        Has variables.

    z: layer
        to receive the Image Effect
    """
    j = Hat.cat.render.image

    # Ball Joint Preset dict, 'o.d'
    d = o.d

    pdb.plug_in_sel2path(j, z)
    if j.active_vectors:
        stroke = j.active_vectors.strokes[0]

        pdb.gimp_selection_none(j)
        RenderHub.brush_stroke_on_stroke(
            z,
            'dots',
            d[ok.BRUSH_SIZE],
            stroke,
            d[ok.BRUSH_SIZE] / 15.,
            .0
        )


def do_layer(j, image_layer, o):
    """
    Add a frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    if o.model_type == md.BOX:
        effect_layer = do_face(j, o)

    elif o.model_type in md.MULTI_IMAGE:
        effect_layer = Lay.add_above(image_layer, n=o.k)
        do_table(j, image_layer, effect_layer, o)

    else:
        # custom cell
        effect_layer = None
        Hat.cat.join_selection(o.model_name)
        if Sel.is_sel(j):
            effect_layer = Lay.add_above(image_layer, n=o.k)
            do_image(o, effect_layer)
    return finish_effect_layer(j, image_layer, effect_layer)


class BallJoint:
    """
    Create a metallic image frame from a brush of overlapping circles.
    """

    @staticmethod
    def do(o):
        """
        Do the Ball Joint Image Effect. Is an Image Effect template function.

        o: One
            Has variables.

        Return: layer, list or None
            with frame(s)
        """
        RenderHub.set_brush({ok.BRUSH: "dots"})
        pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
        pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
        pdb.gimp_context_set_brush_hardness(.95)
        pdb.gimp_context_set_opacity(100.)

        j = Hat.cat.render.image
        z = o.image_layer

        # a list of layer(s) for Shadow #1 and Shadow #2, 'o.shadow_layer'
        o.shadow_layer = []

        # Is a list of layers for a Preview undo function, 'undo_z'.
        undo_z = []

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [do_layer(j, i.layers[0], o)]
            o.shadow_layer = [z]

        else:
            undo_z = do_layer(j, z, o)
            if undo_z:
                o.shadow_layer = [undo_z, z]
        return undo_z
