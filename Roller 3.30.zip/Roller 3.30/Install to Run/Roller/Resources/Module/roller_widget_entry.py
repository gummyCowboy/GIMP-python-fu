#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk
from roller_widget import Widget
import gtk


class Entry(Widget):
    """This is a custom GTK Entry."""
    change_signal = 'changed'

    def __init__(self, **d):
        """
        Create a text Entry Widget.

        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.Entry()

        Widget.__init__(self, g, **d)

        if wk.CHARS in d:
            g.set_width_chars(d[wk.CHARS])

        self.add(g)

        # Do the connection last.
        g.connect('changed', self.callback)

    def get_value(self):
        """
        Get the value displayed in the Entry. Is part of the Widget template.

        Return: string
            from the gtk.Entry
        """
        return self.widget.get_text()

    def set_value(self, n):
        """
        Set the value displayed in the Entry. Is part of Widget template.

        n: string
            give to the GTK Entry
        """
        self.widget.set_text("" if n is None else n)
