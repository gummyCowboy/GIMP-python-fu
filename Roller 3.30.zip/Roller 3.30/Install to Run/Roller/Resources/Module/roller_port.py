#!/usr/bin/env python
# -*- coding: utf-8 -*-
from datetime import datetime
from random import choice, randint, seed, uniform
from roller_constant_key import Widget as wk
from roller_one import Base, Hat
from roller_one_draw import Draw
from roller_widget_box import Cabinet, Eventful
from roller_widget_button import SwitchButton
from roller_widget_label import Label
import gtk

# Are Widgets that will signal a Window's
# Accept action upon receiving the Return key.
RETURN_WIDGETS = (
    gtk.CheckButton,
    gtk.Entry,
    gtk.HScale,
    gtk.RadioButton,
    gtk.ScrolledWindow,
    gtk.SpinButton,
    gtk.ToggleButton,
    gtk.TreeView,
    SwitchButton
)


class Port(object):
    """
    Is a VBox that may be hidden from view.
    Are part of the Port template:
        draw_port: function
            Call to create Widgets for a Port.

        accept: function
            Call to Accept the options in a Port.

        cancel: function
            Call to Cancel a Port.
    """

    def __init__(self, d):
        """
        Create the VBox.

        d: dict
            Has init variables.
        """
        self._pigs = []
        self.color = Base.INIT_COLOR
        self.roller_window = d[wk.WIN]
        self.title = d[wk.WINDOW_TITLE]
        self.pane = gtk.VBox()
        self.accept_port = d[wk.ON_ACCEPT]
        self.cancel_port = d[wk.ON_CANCEL]

        self.roller_window.win.set_title(self.title)
        self.pane.connect('key_press_event', self.on_key_press)

        Draw.load_count += 1

        self.draw_port(self.pane)

        Draw.load_count -= 1

        if hasattr(self.roller_window, 'switch_box'):
            self.roller_window.switch_box.add(self.pane)
        self.roller_window.resize()

    def accept(self, *_):
        """
        Accept the choice. Use with satellite Windows.

        Return: True
            The key-press is handled.
        """
        return self.accept_port(self.get_group_value())

    def cancel(self, *_):
        """
        Cancel the Port. Use with satellite Windows.

        Return: True
            The key-press is handled.
        """
        return self.cancel_port()

    def draw_simple_dialog_port(self, g, q, q1):
        """
        Draw a Port with two stacked HBoxes.

        g: VBox
            container for the Widgets

        q: tuple
            of process to call that draw Widgets

        q1: tuple
            Has strings for VBox Labels.
        """
        for x, p in enumerate(q):
            box = Eventful(self.color)
            hbox = gtk.HBox()
            vbox = Cabinet(0)

            if x == 0 and hasattr(self, 'node_panel'):
                self.node_panel.nav_box = hbox
                self.node_panel.cabinet = [vbox]

            hbox.add(box)
            box.add(vbox)
            g.add(hbox)

            if q1[x]:
                vbox.add(Label(padding=(4, 4, 4, 4), text=q1[x] + ":"))

            p(vbox)
            self.reduce_color()

    def keep(self, q):
        """
        Put Widget reference into 'self._pigs'. Keep the GTK
        garbage collection from removing Widget connections
        from a parent Window when a child Window is opened.

        q: iterable (tuple or list)
            Widgets
        """
        [self._pigs.append(g) for g in q]

    def on_key_press(self, g, a):
        """
        Check to see if the user pressed the Esc key.
        If so, then close the Window or Port.

        g: Widget
            Is responsible.

        a: gtk.Event
            a key-press

        Return: None or true
            Is true if the key-press is handled.
        """
        if self.pane.get_visible():
            n = gtk.gdk.keyval_name(a.keyval)

            if n == 'Escape':
                return self.cancel()
            if n == 'Return':
                # Get the Widget in focus.
                if type(g) in RETURN_WIDGETS:
                    return self.accept()

    def on_widget_change(self, g):
        """
        Call when a Widget is changed. Use with satellite Ports.

        g: Widget
            Is responsible.
        """
        return

    @staticmethod
    def randomize_widgets(g):
        """
        Randomize the variables.

        g: Button
            Has an OptionGroup.
        """
        seed(datetime.now())
        d = g.group.d
        e = Hat.dog.option.options
        for k, g1 in d.items():
            if k in e:
                # option dict, 'd1'
                d1 = e[k]

                if wk.RANDOM in d1:
                    # random range, 'q'
                    q = d1[wk.RANDOM]

                    if wk.PRECISION in d1:
                        g1.set_value(uniform(*q))
                    else:
                        g1.set_value(randint(*q))

                elif wk.GET_WITH_KEY in d1:
                    g1.set_value(d1[wk.GET_WITH_KEY](g.group.group_key))

                elif wk.GET_RANDOM in d1:
                    g1.set_value(d1[wk.GET_RANDOM]())

                elif wk.LIST in d1:
                    g1.set_value(choice(d1[wk.LIST]))
                elif wk.RANDOMIZE in d1:
                    g1.randomize()

    def reduce_color(self):
        """Lower the red and green components of 'self.color'."""
        self.color = Base.reduce_color(self.color)

    def show_port(self):
        """Call when switching to the Port."""
        self.roller_window.switch_box.add(self.pane)
        self.roller_window.win.set_title(self.title)
        self.roller_window.resize()

        # Let GTK know the signal is processed.
        return True

    def switch_ports(self):
        """Call when switching to a new Port."""
        self.roller_window.switch_box.remove(self.pane)
