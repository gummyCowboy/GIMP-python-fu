#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_key import (
    Button as bk,
    Model as md,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_model import Box, Stack, Table
from roller_option_preset_core import Core
from roller_option_view import do_per_cell
from roller_one import One
from roller_one_draw import Draw
from roller_one_extract import Form, Step
from roller_one import Hat
from roller_one_tip import Tip
from roller_widget_button import Button
from roller_widget_check_button import CheckButton
from roller_port_cell import PortCell
import gtk

TRY = "{} Cell Table: Try escape, enter, space-bar to cancel, save, edit."


class PerCellGroup(gtk.Alignment):
    """
    Has a CheckButton and Button. The Button's
    value is a 2D list containing a cell table.
    """

    def __init__(self, **d):
        """
        Create Widgets for switching to the Per Cell option.

        d: dict
            Has keyword arguments for the Widgets.
        """
        super(gtk.Alignment, self).__init__()
        self.set(0, 0, 1, 1)

        hbox = gtk.HBox()

        self._value = []
        self.label = None
        self.group = d[wk.GROUP]
        self.on_preview_button = d[wk.ON_PREVIEW_BUTTON]
        self._group_key = d[wk.GROUP_KEY]
        d[wk.KEY] = ok.PER_CELL
        self.form_group = d[wk.FORM_GROUP]
        self._port = d[wk.PORT]
        self.roller_window = d[wk.WIN]
        self._update_window = d[wk.ON_WIDGET_CHANGE]

        # Use to check the cell table contents with a default form Preset.
        self.form_group_key = self.form_group.group_key

        self._preset_type_key = Core.get_preset_type(self.group.step)

        # for CheckButton
        d[wk.ON_WIDGET_CHANGE] = self._on_change
        d[wk.TOOLTIP] = Tip.PER_CELL_BEGIN
        self.key = d[wk.TEXT] = ok.PER_CELL
        d[wk.ALIGN] = 0, 0, 0, 1
        d[wk.PADDING] = 0, 0, 0, 5
        self.check_button = CheckButton(**d)

        # for Button
        d[wk.TOOLTIP] = Tip.PER_CELL_BUTTON
        d[wk.KEY] = d[wk.TEXT] = bk.OPEN
        d[wk.ALIGN] = 0, 0, 1, 0
        d[wk.PADDING] = 0, 0, 5, 0
        self.button = Button(**d)

        self.add(hbox)

        # Add Widgets.
        for i in (self.check_button, self.button):
            hbox.add(i)

    def _on_change(self, g):
        """
        Respond to a change event for one of the Widgets.

        g: Widget
            Is responsible.
        """
        def _update():
            """
            Make a cell table with updated Per Cell cell tables.

            Return: Model
                for the cell editor
            """
            if is_stack:
                _model = Stack(One(step=step))
                _model.update_type(One(d=Step.get_type_from_step(
                    step,
                    add_per_cell=False))
                )
                _model.update_cell_rect(One(d=Step.get_rectangle_dict(step)))

            else:
                if model_type == md.TABLE:
                    _model = Table(One(step=step))

                else:
                    _model = Box(One(step=step))

                _model.canvas_margin = Step.get_canvas_margin(step)
                _model.update_type(One(d=Step.get_type_from_step(step)))
                _model.calc_pocket(One(d=Step.get_cell_margin(step)))
            return _model

        if not (Draw.load_count or Draw.preset_load_count):
            a = g.get_value()
            step = self.form_group.step
            model_type = Step.get_model_type(step)
            is_stack = model_type == md.STACK

            if g == self.check_button:
                # Update its sibling form group of the change.
                self.form_group.changed = self.form_group.unseen = True

                self.on_per_cell_change(g)
                do_per_cell(self.check_button.group)

                if not a:
                    self._value = []
                else:
                    _update()

            else:
                model = _update()
                o = One(
                    is_all_cells=is_stack,
                    model=model,
                    step=step
                )

                self._port.switch_ports()

                self._original_value = deepcopy(self._value)
                o.per_cell_table = self.get_value()
                o.group_key = self.form_group.group_key
                o.preset_type_key = self._preset_type_key
                o.on_accept = self.accept_port
                o.on_cancel = self.cancel_port
                o.port = self._port
                o.win = self.roller_window
                o.window_title = TRY.format(self._preset_type_key)
                PortCell(o, self)
            self._update_window(g)

    def accept_port(self, cell_table):
        """
        Return from PortCell.

        cell_table: list
            a Per Cell cell table
        """
        self._value = cell_table
        self._port.show_port()
        self.on_per_cell_change(self.button)

    def cancel_port(self, *_):
        """Return from PortCell."""
        return self._port.show_port()

    def get_value(self):
        """
        Get the Per Cell cell table.

        Return: list
            a cell table
            2D (list(s) within a list)
        """
        if self._value:
            return deepcopy(self._value)
        return []

    def hide(self, *_):
        """
        Hide the row in the Table if the Widget is ready.
        NodePanel has set the 'self.box' to a VBox container.
        """
        if self.box:
            if self.box.get_visible():
                self.box.hide()
                self.label.box.hide()

    def on_per_cell_change(self, _):
        """
        The form group changes with the Per Cell group.

        _: Widget
            from the Per Cell group
            not used
        """
        if not (Draw.load_count or Draw.preset_load_count):
            step = self.form_group.step
            group = Hat.cat.group_dict[step]

            # 'group.changed' is set by the PortCell hooks.
            group.unseen = True

            Core.update_view_buttons(step)

            # Face Group options don't have a Preview or a Plan Button.
            if group.preview_button:
                group.preview_button.set_sensitive(1)
                group.plan_button.set_sensitive(1)

    def set_value(self, q):
        """
        Set the CheckButton checked state. Is part of the Widget template.

        q: a 2D list
            list(s) within a list
            of cell table
        """
        self.check_button.widget.set_active(len(q) > 0)
        self._value = q

    def show(self, *_):
        """
        Show the row in the Table Widget if the Widget is ready.
        NodePanel has set the 'self.box' to a VBox container.
        """
        if self.box:
            if not self.box.get_visible():
                self.box.show()
                self.label.box.show()
