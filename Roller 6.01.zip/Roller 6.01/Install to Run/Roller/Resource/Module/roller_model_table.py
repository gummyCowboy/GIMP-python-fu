#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Grid as gr, Shape as sh, Signal as si, Triangle as ft
)
from roller_constant_key import Model as md, Option as ok
from roller_model_grid import Grid
from roller_one import seal


def calc_hexagon(d, w, h, cell_w, cell_h):
    """
    Calculate the number of hexagonal-shaped cells
    that can fit into given a space and cell size.

    d: dict
        Cell/Type Preset
        not used

    w, h: numeric
        canvas size

    cell_w, cell_h: numeric
        cell size

    Return: tuple
        (row, column) of numeric
    """
    w1, h1 = cell_w * .5, cell_h * .75
    return (h - h1) / h1, (w - w1) / w1


def calc_octagon_double(d, w, h, cell_w, cell_h):
    """
    Calculate the number of octagonal-shaped cells
    that can fit into given a space and cell size.

    d: dict
        Cell/Type Preset
        not used

    w, h: numeric
        canvas size

    cell_w, cell_h: numeric
        cell size

    Return: tuple
        (row, column) of numeric
    """
    w1 = cell_w * sh.OCTAGON_RATIO
    h1 = cell_h * sh.OCTAGON_RATIO
    return (h - h1) / (cell_h - h1), (w - w1) / (cell_w - w1)


def calc_parallelogram(d, w, h, cell_w, cell_h):
    """
    Calculate the number of parallelogram-shaped cells
    that can fit into given a space and cell size.

    d: dict
        Cell/Type Preset

    w, h: numeric
        canvas size

    cell_w, cell_h: numeric
        cell size

    Return: tuple
        (row, column) of float
    """
    w1 = cell_w * d[ok.PARALLELOGRAM_SCALE]
    w2 = cell_w - w1
    w3 = w - cell_w - w2
    return h / cell_h, min(1, (w // cell_w)) + (w3 / w1)


def calc_square_mitered(d, w, h, cell_w, cell_h):
    """
    Calculate the number of diamond-shaped cells
    that can fit into given a space and cell size.

    d: dict
        Cell/Type Preset
        not used

    w, h: numeric
        canvas size

    cell_w, cell_h: numeric
        cell size

    Return: tuple
        (row, column) of numeric
    """
    w1, h1 = cell_w * .5, cell_h * .5
    return (h - h1) / h1, (w - w1) / w1


def calc_triangle_h(d, w, h, cell_w, cell_h):
    """
    Calculate the number of horizontal facing triangle-shaped
    cells that can fit into given a space and cell size.

    d: dict
        Cell/Type Preset
        not  used

    w, h: numeric
        canvas size

    cell_w, cell_h: numeric
        cell size

    Return: tuple
        (row, column) of numeric
    """
    h1 = cell_h * .5
    return (h - h1) / h1, w / cell_w


def calc_triangle_v(d, w, h, cell_w, cell_h):
    """
    Calculate the number of vertical facing triangle-shaped
    cells that can fit into given a space and cell size.

    d: dict
        Cell/Type Preset
        not used

    w, h: numeric
        canvas size

    cell_w, cell_h: numeric
        cell size

    Return: tuple
        (row, column) of numeric
    """
    w1 = cell_w * .5
    return h / cell_h, (w - w1) / w1


def calc_truncated_hexagon(d, w, h, cell_w, cell_h):
    """
    Calculate the number of truncated hexagonal-shaped
    cells that can fit into given a space and cell size.

    d: dict
        Cell/Type Preset
        not used

    w, h: numeric
        canvas size

    cell_w, cell_h: numeric
        cell size

    Return: tuple
        (row, column) of numeric
    """
    w1, h1 = cell_w * .75, cell_h * .5
    return (h - h1) / h1, (w - w1) / w1


class Table(Grid):
    """
    Has a Canvas and Cell branches. Has one or more row and column.
    """
    model_type = md.TABLE

    def __init__(self, model_name):
        """
        model_name: string
            Identify the model.
        """
        Grid.__init__(self, model_name)
        self.is_merge_cell = False

    def _fix_merge_cell(self, d):
        """
        Call if the Table Model is in the merge-cell state
        and the Cell/Type has emitted a changed Signal.

        A Table Model's merged cell's  dimension may overflow if a
        Model's grid shrinks in size. Correct the overflow
        references by reducing the merge-cell's block dimensions.

        d: dict
            Cell/Type/Per option value
        """
        row, column = self.grid

        # (row, column) zero-based cell index, 'r_c'; merge-cell size, 's'
        for r_c, s in d.items():
            r, c = r_c
            m = False

            if s[0] + r > row:
                s = row - r, s[1]
                m = True

            if s[1] + c > column:
                s = s[0], column - c
                m = True
            if m:
                d[r_c] = s

    def calc_grid(self, d):
        """
        Determine the row and column count of the cell grid.
        Call after Canvas pocket has been calculated.

        d: dict
            Cell/Type Preset
        """
        n = d[ok.GRID_TYPE]
        w, h = self.canvas_pocket.size

        if n == gr.CELL_COUNT:
            r, c = d[ok.ROW_COUNT], d[ok.COLUMN_COUNT]

        elif n == gr.SHAPE_COUNT:
            r, c = d[ok.VERT_COUNT], d[ok.HORZ_COUNT]

        else:
            # cell size
            cell_w = seal(d[ok.COLUMN_W], 1., w)
            cell_h = seal(d[ok.ROW_H], 1., h)

            n = self.cell_shape

            if n not in sh.REGULAR:
                p = ROUTE_CELL_SHAPE.get(n)

                if p:
                    r, c = p(d, w, h, cell_w, cell_h)
                    r, c = max(1, r), max(1, c)
                else:
                    # error
                    r = c = 1
            else:
                r, c = max(1, h // cell_h), max(1, w // cell_w)

        self.grid = int(r), int(c)

        self.baby.emit(si.GRID_CHANGE, self.grid)
        self.is_merge_cell = self.what_is_merge_cell(d)

    def get_cell_block(self, u, v):
        """
        Calculate merged cell block size.

        u: tuple
            (r, c) of int
            topleft cell

        v: tuple
            (r, c) of int
            bottom-right cell

        Return the topleft coordinates and the
        scale of an rectangular array of cells.
        """
        # Do repair for invalid cell dimension.
        if u == (-1, -1):
            # Repair.
            u = 1, 1

        if v == (-1, -1):
            # Repair.
            v = 1, 1

        x, y = self.goo_d[u].cell.position
        x1, y1, w, h = self.goo_d[v].cell.rect
        w = x1 - x + w
        h = y1 - y + h
        return x, y, w, h

    def init_cell_q(self, d):
        """
        Create a sorted list of valid cell index,
        'cell_q' -> [(row, column), ...].

        d: dict
            Cell/Type Preset
        """
        row, column = self.grid

        self.update_per_value(d)

        if self.cell_shape in sh.DOUBLE:
            self.cell_q = []
            is_indent = d[ok.FCI]
            for r in range(row):
                for c in range(column):
                    if is_indent:
                        if bool(
                            (r % 2 and not c % 2) or (not r % 2 and c % 2)
                        ):
                            self.cell_q += [(r, c)]
                    elif bool(
                        (r % 2 and c % 2) or (not r % 2 and not c % 2)
                    ):
                        self.cell_q += [(r, c)]

        else:
            if self.is_merge_cell:
                # Is a merge-cell that is dependent
                # on a topleft cell, '(-1, -1)'.
                e = d[ok.PER]
                self.cell_q = [
                    (r, c) for r, c in e if e[(r, c)] != (-1, -1)
                    and r < row and c < column
                ]
            else:
                self.cell_q = [
                    (r, c) for r in range(row) for c in range(column)
                ]
        self.cell_q.sort()

    def update_cell_block(self, u, v):
        """
        Update the merge-cell size for a cell block.

        u: tuple
            cell index of the topleft cell of the block

        v: tuple
            cell index of the bottom-right cell of the block
        """
        self.goo_d[u].merged.rect = self.get_cell_block(u, v)

    def update_per_value(self, d):
        """
        Synchronize a merge-cell value dict with the grid size.

        d: dict
            Cell/Type Preset
            {Option key: value}
        """
        if self.is_merge_cell:
            # Add missing cell. Remove extraneous cell.
            e = d[ok.PER]
            row, column = self.grid
            cell_q = {(r, c) for r in range(row) for c in range(column)}
            keys = e.keys()

            # Add.
            for r_c in cell_q:
                if r_c not in keys:
                    e[r_c] = 1, 1

            # Remove.
            for r_c in keys:
                if r_c not in cell_q:
                    e.pop(r_c)

    def update_type(self, arg):
        """
        Update Cell/Type dependency.

        arg: tuple
            (Cell/Type Preset, is sequence flag)
            {Option key: value}
            If the flag is True, then a chained-sequence
            is processed immediately.
        """
        def _get_cell_shape():
            """
            Get the cell shape according to the cell type.

            Return: string
                cell shape descriptor
            """
            if d[ok.GRID_TYPE] == gr.SHAPE_COUNT:
                return d[ok.ECS]
            return d[ok.CELL_SHAPE]

        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        self.cell_shape = _get_cell_shape()
        vote_d = super(Table, self).update_type(arg)

        if self.is_merge_cell:
            self._fix_merge_cell(d[ok.PER])
            vote_d = {}
            per = d[ok.PER]
            for r_c in self.cell_q:
                # Goo, 'a'
                a = self.goo_d[r_c]

                s = per[r_c]

                if s == (1, 1):
                    a.merged.rect = a.cell.rect

                elif s != (-1, -1):
                    # Is a topleft merge-cell.
                    r, c = r_c
                    x, y, w, h = a.merged.rect = self.get_cell_block(
                        r_c, (r + s[0] - 1, c + s[1] - 1)
                    )
                    a.form = a.plaque = x, y, x + w, y, x + w, y + h, x, y + h
                vote_d[r_c] = self.past.did_merged(r_c)

        self.adapt_missing_cell_step(is_sequence)
        p(si.CELL_RECT_CALC, vote_d)

    def what_is_merge_cell(self, d):
        """
        Determine if the Cell/Type is in a merge-cell state.
        A merge-cell state occurs when the
        Cell/Type Per CheckButton is checked.

        d: dict
            Cell/Type Preset

        Return: bool
            Is true if the Cell/Type option group is in merge-cell mode.
        """
        if (
            self.cell_shape == sh.RECTANGLE and
            d[ok.GRID_TYPE] == gr.CELL_COUNT and
            (self.grid[0] > 1 or self.grid[1] > 1)
        ):
            return bool(d[ok.PER])
        return False


# {shape descriptor: calculate cell grid function}
ROUTE_CELL_SHAPE = {
    ft.HORIZONTAL_TRIANGLE: calc_triangle_h,
    ft.VERTICAL_TRIANGLE: calc_triangle_v,
    ft.TRIANGLE_DOWN_SHEAR: calc_triangle_v,
    ft.TRIANGLE_LEFT_SHEAR: calc_triangle_h,
    ft.TRIANGLE_RIGHT_SHEAR: calc_triangle_h,
    ft.TRIANGLE_UP_SHEAR: calc_triangle_v,
    sh.DIAMOND: calc_square_mitered,
    sh.ELLIPSE_HORIZONTAL:  calc_hexagon,
    sh.ELLIPSE_VERTICAL: calc_truncated_hexagon,
    sh.HEXAGON_SHEAR: calc_hexagon,
    sh.HEXAGON_TRUNCATED_SHEAR: calc_truncated_hexagon,
    sh.OCTAGON_DOUBLE_SHEAR: calc_octagon_double,
    sh.PARALLELOGRAM_ALT_LEFT: calc_parallelogram,
    sh.PARALLELOGRAM_ALT_RIGHT: calc_parallelogram,
    sh.PARALLELOGRAM_LEFT: calc_parallelogram,
    sh.PARALLELOGRAM_RIGHT: calc_parallelogram
}
