#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_many_rect import Rect
from roller_model_goo import Goo
from roller_polygon import calc_pin_xy, make_coord_list


class Parallelogram:
    """A cell is a leaning parallelogram. """

    @staticmethod
    def calc(model, o):
        """
        For Model cell, calculate cell and merge
        rectangle and their inscribed form polygon.

        model: Model
        o: One
            with Cell Type reference

        Return: list
            [Plan vote, Work vote]
        """
        vote_d = {}
        did_cell = model.past.did_cell
        row, column = model.division
        goo_d = model.goo_d
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect
        scale = o.parallelogram_scale

        # [intersect, ...]
        bottom_q = []
        top_q = []
        cell_q = []

        if o.grid_type in gr.CELL_SIZE:
            # cell size
            # Correct cell size overflow.
            w = min(canvas_w, o.column_width)
            h = min(canvas_h, o.row_height)

            # grid size
            w1 = w * scale
            w2 = w - w1
            s = column * w1 + w2, row * h
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

        else:
            # Calculate the cell size for cell count.
            scale_1 = 1. - scale
            w = canvas_w / (scale_1 + column * scale)
            h = canvas_h / row
            w1 = w * scale
            w2 = w - w1

        if o.cell_shape == sh.PARALLELOGRAM_RIGHT:
            x1 = x
            x += w2

        else:
            # left parallelogram
            x1 = x + w2

        # remainder total, 'f_x, f_x1'
        f_x = f_x1 = .0

        # On remainder full, add one to the coordinate.
        for c in range(column + 2):
            x, f = divmod(x, 1.)
            f_x += f

            if f_x >= .999:
                x += 1.
                f_x -= 1.

            x1, f = divmod(x1, 1.)
            f_x1 += f

            if f_x1 >= .999:
                x1 += 1.
                f_x1 -= 1.

            top_q += [x]
            bottom_q += [x1]
            x += w1
            x1 += w1

        q_y = make_coord_list(canvas_h, row + 1, y, span=h)

        for c in range(column):
            cell_q += [min(top_q[c], bottom_q[c])]
            cell_q += [max(top_q[c + 1], bottom_q[c + 1])]

        for r_c in model.cell_q:
            r, c = r_c
            c1 = c * 2
            y, y1 = q_y[r], q_y[r + 1]
            a = goo_d[r_c] = Goo(r_c)
            x, x1 = cell_q[c1], cell_q[c1 + 1]

            # Prevent round to zero with max 1.
            a.cell = a.merged = Rect(x, y, max(1., x1 - x), max(1., y1 - y))

            x, x1 = top_q[c], top_q[c + 1]
            x3, x2 = bottom_q[c], bottom_q[c + 1]
            a.form = x, y, x1, y, x2, y1, x3, y1
            vote_d[r_c] = did_cell(r_c)
        return vote_d
