#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import (
    MAX_SIZE,
    Backdrop as bs,
    Caption as pt,
    Frame as ff,
    Fill as fl,
    Gradient as fg,
    Grid as gr,
    Justification as ju,
    Shape as sh,
    Issue as vo
)
from roller_constant_key import Option as ok, Widget as wk
from roller_def_act import (
    get_brush_list,
    get_cell_shape_list,
    get_criterion_list,
    get_justification_type,
    get_gradient_angle_list,
    get_gradient_list,
    get_gradient_type_list,
    get_grid_type_list,
    get_mesh_type_list,
    get_mode_name_list,
    get_pattern_list,
    get_pin_list,
    get_profile_list,
    get_wrap_types,
    make_bool_tip,
    make_rainbow_tip,
    make_slider_tip,
    make_text_tip
)
from roller_one_tip import Tip
from roller_port_choice import PortChoice
from roller_widget_button import RandomButton, RandomColorButton
from roller_widget_check_button import CheckButton, CheckButtonRandom
from roller_widget_combo import CaptionComboBox, ComboBox
from roller_widget_entry import Entry
from roller_widget_label import ModelTypeLabel
from roller_widget_number_pair import (
    CanvasPair, GradientPair, RectPair, RenderPair
)
from roller_widget_option_button import ListButton
from roller_widget_per import PerGroup
from roller_widget_slider import RandomSlider, Slider
from roller_widget_radio import SwitchRadio
from roller_widget_row import Rainbow

ANGLE = {
    wk.LIMIT: (-359., 359.),
    wk.PAGE_INCR: 30.,
    wk.PRECISION: 2,
    wk.RANDOM_Q: (-359., 359.),
    wk.STEP_INCR: .1,
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
ANGLE_JITTER = {
    wk.LIMIT: (.0, 180.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 180.),
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
BLUR = {
    wk.LIMIT: (.0, 500.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 50.),
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
BLOCK_W = {
    wk.AXIS: 'x',
    wk.LIMIT: (0, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.VAL: (0, .2),
    wk.WIDGET: RectPair
}
BLOCK_H = {
    wk.AXIS: 'y',
    wk.LIMIT: (0, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.VAL: (0, .2),
    wk.WIDGET: RectPair
}
BLUR_XY = {
    wk.LIMIT: (1., 100.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (3., 20.),
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
BRUSH = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortChoice,
    wk.FUNCTION: get_brush_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: "C_Normal Brush 80",
    wk.WIDGET: ListButton
}
BRUSH_SIZE = {
    wk.LIMIT: (10, 9999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (25, 125),
    wk.TIPPER: make_text_tip,
    wk.VAL: 100.,
    wk.WIDGET: RandomSlider
}
BRUSH_SPACING = {
    wk.LIMIT: (10., 5000.),
    wk.PAGE_INCR: 10,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (25., 125.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 100.,
    wk.WIDGET: RandomSlider
}
CAPTION_TYPE = {
    wk.TIPPER: make_text_tip,
    wk.VAL: pt.TEXT,
    wk.WIDGET: CaptionComboBox
}
CELL_SHAPE_CELL = {
    wk.FUNCTION: get_cell_shape_list,
    wk.ISSUE: vo.MATTER,
    wk.VAL: sh.RECTANGLE,
    wk.WIDGET: ComboBox
}
CELL_SIZE = {
    wk.LIMIT: (1, MAX_SIZE),
    wk.PAGE_INCR: 100,
    wk.TOOLTIP: Tip.GRID_FIXED_SIZE,
    wk.VAL: 250.,
    wk.WIDGET: Slider
}
CLIP = {
    wk.LIMIT: (6, 1024),
    wk.RANDOM_Q: (108, 1024),
    wk.TIPPER: make_text_tip,
    wk.VAL: 512.,
    wk.WIDGET: RandomSlider
}
CLIP_TO_CELL = {
    wk.TIPPER: make_bool_tip,
    wk.TOOLTIP: Tip.CLIP_TO_CELL,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
COLOR_1 = {
    wk.TIPPER: make_text_tip,
    wk.VAL: (0, 0, 0),
    wk.WIDGET: RandomColorButton
}
COLOR_1A = {
    wk.HAS_ALPHA: True,
    wk.TIPPER: make_text_tip,
    wk.VAL: (64, 64, 64, 255),
    wk.WIDGET: RandomColorButton
}
COLOR_2A = {
    wk.BUTTON_COUNT: 2,
    wk.HAS_ALPHA: True,
    wk.TIPPER: make_rainbow_tip,
    wk.VAL: ((64, 64, 64, 255), (187, 187, 187, 255)),
    wk.WIDGET: Rainbow
}
CONTRACT = {
    wk.LIMIT: (0, 9999),
    wk.PAGE_INCR: 50,
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.CONTRACT,
    wk.VAL: .0,
    wk.WIDGET: Slider
}
CONTRAST = {
    wk.LIMIT: (-127, 127),
    wk.RANDOM_Q: (-127, 127),
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
CRITERION = {
    wk.FUNCTION: get_criterion_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: fl.COMPOSITE,
    wk.WIDGET: ComboBox
}
CROP_XY = {
    wk.LIMIT: (0, MAX_SIZE),
    wk.PAGE_INCR: 10,
    wk.TIPPER: make_slider_tip,
    wk.VAL: .0,
    wk.WIDGET: Slider
}
DECO_TYPE = {
    wk.TIPPER: make_text_tip,
    wk.VAL: "",
    wk.WIDGET: ComboBox
}
DESATURATE = {
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButtonRandom
}
EMBOSS = {
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButtonRandom
}
FACTOR_SIZE = {
    wk.LIMIT: (.0, 2.),
    wk.PRECISION: 6,
    wk.STEP_INCR: .01,
    wk.TIPPER: make_text_tip,
    wk.VAL: 1.,
    wk.WIDGET: Slider,
}
FCI = {
    wk.TOOLTIP: Tip.FCI,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
FEATHER = {
    wk.LIMIT: (0, 1000),
    wk.PAGE_INCR: 50,
    wk.RANDOM_Q: (50, 300),
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.FEATHER,
    wk.VAL: 200.,
    wk.WIDGET: RandomSlider
}
FILL_MODE = {
    wk.FUNCTION: get_mode_name_list,
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.FILL_MODE,
    wk.VAL: "Normal",
    wk.WIDGET: ComboBox
}
FIXED_SIZE = {
    wk.LIMIT: (1, MAX_SIZE),
    wk.PAGE_INCR: 100,
    wk.TIPPER: make_text_tip,
    wk.VAL: 200.,
    wk.WIDGET: Slider
}
FLIP = {
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
FONT = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortChoice,
    wk.TIPPER: make_text_tip,
    wk.VAL: "Tahoma",
    wk.WIDGET: ListButton
}
FONT_SIZE = {
    wk.LIMIT: (4, 999),
    wk.PAGE_INCR: 10,
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.FONT_SIZE,
    wk.VAL: 24.,
    wk.WIDGET: Slider
}
FRAME_W = {
    wk.LIMIT: (1, 999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (1., 50.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 6.,
    wk.WIDGET: RandomSlider
}
GAP_W = {
    # Is limited by GIMP's clipboard to
    # pattern function where the maximum side
    # dimension for the clipboard is 1024.
    wk.LIMIT: (1, 512),

    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (12, 100),
    wk.TIPPER: make_text_tip,
    wk.VAL: 24.,
    wk.WIDGET: RandomSlider
}
GRADIENT = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortChoice,
    wk.FUNCTION: get_gradient_list,
    wk.ISSUE: vo.MATTER,
    wk.TIPPER: make_text_tip,
    wk.VAL: "Default",
    wk.WIDGET: ListButton
}
GRADIENT_ANGLE = {
    wk.FUNCTION: get_gradient_angle_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: fg.TOP_CENTER_TO_BOTTOM_CENTER,
    wk.WIDGET: ComboBox
}
GRADIENT_END_X = {
    wk.AXIS: 'x',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.END_X,),
    wk.VAL: (0, 1.),
    wk.WIDGET: GradientPair
}
GRADIENT_END_Y = {
    wk.AXIS: 'y',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.END_Y,),
    wk.VAL: (0, 1.),
    wk.WIDGET: GradientPair
}
GRADIENT_START_X = {
    wk.AXIS: 'x',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0),
    wk.WIDGET: GradientPair
}
GRADIENT_START_Y = {
    wk.AXIS: 'y',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0),
    wk.WIDGET: GradientPair
}
GRADIENT_TYPE = {
    wk.FUNCTION: get_gradient_type_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: fg.LINEAR,
    wk.WIDGET: ComboBox
}
GRID_COUNT = {
    wk.LIMIT: (1, 100),
    wk.PAGE_INCR: 2,
    wk.VAL: 1.,
    wk.WIDGET: Slider
}
GRID_SIZE = {
    wk.VAL: "",
    wk.WIDGET: ModelTypeLabel
}
GRID_TYPE = {
    wk.FUNCTION: get_grid_type_list,
    wk.VAL: gr.CELL_COUNT,
    wk.WIDGET: ComboBox
}
HARDNESS = {
    wk.LIMIT: (.001, 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.25, 1.),
    wk.STEP_INCR: .01,
    wk.TIPPER: make_text_tip,
    wk.VAL: 1.,
    wk.WIDGET: RandomSlider
}
HSL = {
    wk.LIMIT: (-100., 100.),
    wk.PAGE_INCR: 10.,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (-100., 100.),
    wk.STEP_INCR: 1.,
    wk.TIPPER: make_text_tip,
    wk.VAL: .0,
    wk.WIDGET: RandomSlider
}
INTENSITY = {
    wk.LIMIT: (0, 1000),
    wk.PAGE_INCR: 25,
    wk.RANDOM_Q: (50, 200),
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.INTENSITY,
    wk.VAL: 0.,
    wk.WIDGET: RandomSlider
}
INVERT = {
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButtonRandom
}
JUSTIFICATION = {
    wk.FUNCTION: get_justification_type,
    wk.TIPPER: make_text_tip,
    wk.VAL: ju.CENTER,
    wk.WIDGET: ComboBox
}
KEEP_GRADIENT = {
    wk.TOOLTIP: Tip.KEEP_GRADIENT,
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
LINE_W = {
    # Is limited by GIMP's clipboard to
    # pattern function where the maximum side
    # dimension for the clipboard is 1024.
    wk.LIMIT: (1, 512),

    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (1, 30),
    wk.TIPPER: make_text_tip,
    wk.VAL: 6.,
    wk.WIDGET: RandomSlider
}
MAX_POLAR_X = {
    wk.AXIS: 'x',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0),
    wk.WIDGET: RenderPair
}
MAX_POLAR_Y = {
    wk.AXIS: 'y',
    wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0),
    wk.WIDGET: RenderPair
}
MAX_POSITIVE_X = {
    wk.AXIS: 'x',
    wk.LIMIT: (0, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0),
    wk.WIDGET: RenderPair
}
MAX_POSITIVE_Y = {
    wk.AXIS: 'y',
    wk.LIMIT: (0, MAX_SIZE),
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0),
    wk.WIDGET: RenderPair
}
MESH_TYPE = {
    wk.FUNCTION: get_mesh_type_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: bs.SQUARE,
    wk.WIDGET: ComboBox
}
MASK_SCALE = {
    wk.LIMIT: (.001, 1.),
    wk.PRECISION: 3,
    wk.STEP_INCR: .01,
    wk.TIPPER: make_text_tip,
    wk.VAL: 1.,
    wk.WIDGET: Slider
}
MAZE = {
    wk.LIMIT: (4, 999),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (4, 50),
    wk.TIPPER: make_text_tip,
    wk.VAL: 10.,
    wk.WIDGET: RandomSlider
}
MESH_SIZE = {
    wk.LIMIT: (8, 1000),
    wk.RANDOM_Q: (25, 100),
    wk.TIPPER: make_text_tip,
    wk.VAL: 50.,
    wk.WIDGET: RandomSlider
}
MODE = {
    wk.FUNCTION: get_mode_name_list,
    wk.ISSUE: vo.MODE,
    wk.TIPPER: make_text_tip,
    wk.VAL: "Normal",
    wk.WIDGET: ComboBox
}
NEATNESS = {
    wk.LIMIT: (.0, 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.0, 1.),
    wk.STEP_INCR: .01,
    wk.TIPPER: make_text_tip,
    wk.VAL: 1.,
    wk.WIDGET: RandomSlider
}
NET_LINE = {
    wk.LIMIT: (1, 9999),
    wk.PAGE_INCR: 10,
    wk.TIPPER: make_text_tip,
    wk.VAL: 6.,
    wk.WIDGET: Slider
}
NOISE_AMOUNT = {
    wk.LIMIT: (1, 15),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (1, 15),
    wk.TIPPER: make_text_tip,
    wk.VAL: 2.,
    wk.WIDGET: RandomSlider
}
OBEY_MARGINS = {
    wk.TOOLTIP: Tip.OBEY_MARGINS,
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButton
}
OFFSET = {
    wk.LIMIT: (0, 9999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (0, 20),
    wk.TIPPER: make_text_tip,
    wk.VAL: 0.,
    wk.WIDGET: RandomSlider
}
OFFSET_XY = {
    wk.LIMIT: (-4096, 4096),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (-30, 30),
    wk.TIPPER: make_text_tip,
    wk.VAL: 0.,
    wk.WIDGET: RandomSlider
}
OPACITY = {
    wk.ISSUE: vo.OPACITY,
    wk.LIMIT: (.0, 100.),
    wk.PAGE_INCR: 10.,
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 100.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 100.,
    wk.WIDGET: RandomSlider
}
PATTERN = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortChoice,
    wk.FUNCTION: get_pattern_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: "Pine",
    wk.WIDGET: ListButton
}
PER = {
    wk.ISSUE: vo.PER,
    wk.VAL: {},
    wk.WIDGET: PerGroup
}
PIN = {
    wk.FUNCTION: get_pin_list,
    wk.VAL: gr.CENTER,
    wk.WIDGET: ComboBox
}
PROFILE = {
    wk.FUNCTION: get_profile_list,
    wk.TIPPER: make_text_tip,
    wk.VAL: ff.BAND,
    wk.WIDGET: ComboBox
}
R_C = {
    wk.LIMIT: (1, 999),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (1, 50),
    wk.TIPPER: make_text_tip,
    wk.VAL: 5.,
    wk.WIDGET: RandomSlider
}
RANDOM = {wk.WIDGET: RandomButton}
RANDOM_ORDER = {
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButtonRandom
}
RC_SLICE = {
    wk.LIMIT: (1, 100),
    wk.TIPPER: make_text_tip,
    wk.VAL: 1.,
    wk.WIDGET: Slider
}
REVERSE = {
    wk.TOOLTIP: Tip.REVERSE,
    wk.TIPPER: make_bool_tip,
    wk.VAL: 0,
    wk.WIDGET: CheckButtonRandom
}
SEED = {
    wk.LIMIT: (0, 99999),
    wk.RANDOM_Q: (0, 99999),
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.SEED,
    wk.VAL: 0.,
    wk.WIDGET: RandomSlider
}
SHADOW_BLUR = {
    wk.LIMIT: (.0, 500.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 40.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 15.,
    wk.WIDGET: RandomSlider
}
SPECK_NOISE = {
    wk.LIMIT: (.05, 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.05, 1.),
    wk.STEP_INCR: .01,
    wk.TIPPER: make_text_tip,
    wk.VAL: .22,
    wk.WIDGET: RandomSlider
}
START_X = {
    wk.AXIS: 'x',
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0),
    wk.WIDGET: CanvasPair
}
START_Y = {
    wk.AXIS: 'y',
    wk.TIPPER: make_slider_tip,
    wk.TIPS: (Tip.SLIDER_INT_PART,),
    wk.VAL: (0, .0),
    wk.WIDGET: CanvasPair
}
STEPS = {
    wk.LIMIT: (1, 50),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (1, 12),
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.STEPS,
    wk.VAL: 6.,
    wk.WIDGET: RandomSlider
}
SUPERPIXEL_SIZE = {
    wk.LIMIT: (8, 256),
    wk.RANDOM_Q: (8, 256),
    wk.TIPPER: make_text_tip,
    wk.VAL: 32.,
    wk.WIDGET: RandomSlider
}
SWITCH = {
    wk.COLUMN_TEXT: ok.SWITCH,
    wk.TEXT: ("Off", "On"),
    wk.VAL: 0,
    wk.WIDGET: SwitchRadio
}
TEXT = {
    wk.CHARS: 15,
    wk.TIPPER: make_text_tip,
    wk.VAL: "",
    wk.WIDGET: Entry
}
THRESHOLD = {
    wk.LIMIT: (.0, 1.),
    wk.PRECISION: 3,
    wk.RANDOM_Q: (.33, 1.),
    wk.STEP_INCR: .01,
    wk.TIPPER: make_text_tip,
    wk.TOOLTIP: Tip.THRESHOLD,
    wk.VAL: 1.,
    wk.WIDGET: RandomSlider
}
WAVE_AMPLITUDE = {
    wk.LIMIT: (.0, 100.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (.0, 11.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 4.,
    wk.WIDGET: RandomSlider
}
WAVELENGTH = {
    wk.LIMIT: (.5, 50.),
    wk.PRECISION: 1,
    wk.RANDOM_Q: (10., 50.),
    wk.TIPPER: make_text_tip,
    wk.VAL: 16.,
    wk.WIDGET: RandomSlider
}
WIDTH = {
    wk.LIMIT: (1, 9999),
    wk.PAGE_INCR: 10,
    wk.RANDOM_Q: (1, 100),
    wk.TIPPER: make_text_tip,
    wk.VAL: 30,
    wk.WIDGET: RandomSlider
}
WRAP_TYPE = {
    wk.FUNCTION: get_wrap_types,
    wk.TIPPER: make_text_tip,
    wk.VAL: ff.ROUNDED,
    wk.WIDGET: ComboBox
}
CFW = deepcopy(FRAME_W)
CFW[wk.LIMIT] = 0, 999
CFW[wk.VAL] = 0.
CROP_X = deepcopy(CROP_XY)
CROP_X[wk.TOOLTIP] = Tip.CROP_X
CROP_Y = deepcopy(CROP_XY)
GRADIENT_MODE = deepcopy(MODE)
NOISE_OPACITY = deepcopy(OPACITY)
NOISE_OPACITY[wk.VAL] = 30.
OVERLAY_MODE = deepcopy(MODE)
OVERLAY_MODE[wk.VAL] = "Overlay"
