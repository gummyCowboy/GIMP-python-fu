#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Globe, Run, The
from roller_constant_for import Frame as ff
from roller_constant_key import (
    Frame as ek, Material as ma, Option as ok, SubMaya as sm
)
from roller_frame import do_selection_material
from roller_frame_alt import FrameOverlay
from roller_def import get_default_value
from roller_fu import (
    blur_selection,
    copy_all_image,
    get_select_coord,
    load_selection,
    make_clouds,
    merge_layer,
    paste_layer,
    select_item,
    select_rect,
    shape_clipboard,
    verify_layer
)
from roller_many_image import get_image_ref
from roller_one_wip import Wip
from roller_view_hub import (
    color_layer_default,
    draw_gradient,
    get_gradient_points,
    set_fill_context_default,
    set_gimp_pattern
)
from roller_view_real import add_wip_layer, get_light
import gimpfu as fu  # type: ignore
import os

pdb = fu.pdb


def apply_clouds(maya, z, d, k):
    """
    Make clouds for a frame selection.

    maya: Maya
        not used

    z: layer
        Is frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key
        not used

    Return: layer
        with frame material
    """
    make_clouds(z, int(d[ok.SEED] + Globe.seed))
    return z


def apply_color(maya, z, d, k):
    """
    Color the frame.

    maya: Maya
        not used

    z: layer
        Is frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key
        not used

    Return: layer
        with frame material
    """
    color_layer_default(z, d[ok.RW1][ok.COLOR_1])
    return z


def apply_gradient(maya, z, d, k):
    """
    Color the frame with a gradient.

    maya: Maya
        not used

    z: layer
        Is frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key
        not used

    Return: layer
        with frame material
    """
    j = Run.j
    x, y, x1, y1 = get_select_coord(j)
    w, h = x1 - x, y1 - y
    e = get_default_value("Gradient Fill")

    e.update(d)

    e[ok.GRADIENT] = d[ok.RW2][ok.GRADIENT]
    start_x, end_x, start_y, end_y = \
        get_gradient_points(d, x - Wip.x, y - Wip.y, w, h)

    select_rect(j, x, y, w, h)
    draw_gradient(z, e, start_x, start_y, end_x, end_y)
    blur_selection(z, d[ok.BLUR])
    return z


def apply_image(maya, z, d, k):
    """
    Apply an image to the frame.

    maya: Maya
    z: layer
        Has the frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        with the frame
    """
    def _callback(_j):
        """
        Is a callback from the 'shape_clipboard' function.

        _j: GIMP image
            Is the shaped image.
        """
        blur_selection(j.layers[0], d[ok.BLUR])

    j = Run.j
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    j1 = maya.cast.get_frame_image(k)

    if j1:
        j1 = j1.j
        n = z.name

        copy_all_image(j1)
        shape_clipboard(x1 - x, y1 - y, callback=_callback)

        z1 = paste_layer(z)

        pdb.gimp_layer_set_offsets(z1, x, y)

        z = merge_layer(z1)
        z.name = n
    return z


def apply_pattern(maya, z, d, k):
    """
    Paint the frame with a pattern.

    maya: Maya
        not used

    z: layer
        Has the frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key
        not used

    Return: layer
        with material
    """
    set_fill_context_default()
    set_gimp_pattern(d[ok.RW2][ok.PATTERN])

    # x and y fill origin point, '0., 0,'
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, 0., 0.)

    blur_selection(z, d[ok.BLUR])
    return z


def apply_plasma(maya, z, d, k):
    """
    Paint the frame with plasma.

    maya: Maya
        not used

    z: layer
        Has the frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key
        not used

    Return: layer
        with material
    """
    j = Run.j

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(
        j, z,
        int(d[ok.SEED] + Globe.seed),
        1.                                 # lowest turbulence
    )
    blur_selection(z, d[ok.BLUR])
    return z


def do_matter(maya):
    """
    Make a frame.

    maya: FrameOver
    Return: layer or None
        with the frame
    """
    if maya.value_d[ok.FRAME_OVER] != "None":
        return do_selection_material(
            maya, do_sel, embellish, " Frame Over", is_clear=False
        )


def do_overlay(maya):
    """
    Make an overlay layer for the frame.

    maya: Overlay
    Return: layer or None
        with material
    """
    def _select_rect():
        _x, _y, _x1, _y1 = get_select_coord(j)
        select_rect(j, _x, _y, _x1 - _x, _y1 - _y)

    j = Run.j

    # Frame Over Preset dict, 'd'
    d = maya.value_d

    super_ = maya.cast
    n = d[ok.TYPE]
    if n in ROUTE_COLOR:
        z = add_wip_layer("Frame Over", maya.group, offset=get_light(maya))

        # Check to see if the caller is a grid, 'main_q'.
        if hasattr(super_, 'main_q') and n in ROUTE_GRID:
            for r, c in super_.main_q:
                sel = maya.model.get_image_sel((r, c))

                load_selection(j, sel)
                _select_rect()
                if not pdb.gimp_selection_is_empty(j):
                    z = ROUTE_GRID[n](maya, z, d, (r, c))
        else:
            select_item(super_.matter)
            _select_rect()
            if not pdb.gimp_selection_is_empty(j):
                z = ROUTE_COLOR[n](maya, z, d, super_.k)
        return verify_layer(z)


def do_sel(maya, z):
    """
    Make a frame for a selection.

    maya: Maya
    z: layer
        to receive the frame
    """
    j = Run.j

    # Frame Over Preset dict, 'd'
    d = maya.value_d
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    n = "{}{}{}.png".format(The.frame_path, os.path.sep, d[ok.FRAME_OVER])
    e = get_default_value(ok.IMAGE_CHOICE)
    e[ok.FILE] = n
    e[ok.TYPE] = ok.FILE

    # Get the GIMP image.
    j1 = get_image_ref(e, Run.j_d)

    if j1:
        copy_all_image(j1.j)
        shape_clipboard(x1 - x, y1 - y)

        n1 = z.name
        z = paste_layer(z, n="Frame")

        pdb.gimp_layer_set_offsets(z, x, y)

        z = merge_layer(z)
        z.name = n1
    return z


def embellish(maya, z):
    """Is a callback for 'do_selection_material'."""
    return z


class FrameOver(FrameOverlay):
    """Make an overlay for image material."""
    is_seeded = True
    kind = ek.FRAME_OVER
    material = ma.FRAME_OVER
    overlay_k = ok.OVERLAY_FO
    shade_row = ok.RW1
    wrap_k = ok.STENCIL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        FrameOverlay.__init__(
            self, any_group, super_maya, k_path, do_matter, do_overlay
        )
        overlay = self.sub_maya[sm.OVERLAY]
        k_path = overlay.k_path
        overlay.k_path = [
            k_path,
            k_path + (ok.RW1,),
            k_path + (ok.RW1, ok.IMAGE_CHOICE)
        ]

        # The k-path type changed from a tuple
        # (one dict) to a list (multi dict).
        overlay.take_vote = overlay.scan_vote


# Are FrameOver types that are applied to each cell individually.
ROUTE_GRID = {
    ff.GRADIENT: apply_gradient,
    ff.IMAGE: apply_image,
}

# Are FrameOver types that are applied tone time.
ROUTE_COLOR = {
    ff.CLOUDS: apply_clouds,
    ff.COLOR: apply_color,
    ff.GRADIENT: apply_gradient,
    ff.IMAGE: apply_image,
    ff.PATTERN: apply_pattern,
    ff.PLASMA: apply_plasma
}
