#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Deco, Run
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    attach_mask_sel,
    make_cell_face_mask,
    make_cell_facing_mask,
    make_deco_material,
    add_group_type,
    make_main_face_mask,
    make_main_facing_mask,
    make_mask_sel,
    prep_below_type,
    produce_main_facing,
    produce_per_facing,
    ready_canvas_rect,
    ready_shape,
    select_rect,
    test_image,
    transform_foam
)
from roller_fu import load_selection, select_shape, verify_layer_group
from roller_view_hub import do_mod
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def do(maya, make):
    """
    Create Plaque for a navigation branch.

    maya: Maya
    Return: layer or None
        with material
    """
    d = maya.value_d

    if not Run.x:
        # Preserve.
        type_ = d[ok.TYPE]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = {
            ny.CELL: fy.CELL_PLAQUE_COLOR,
            ny.CANVAS: fy.CANVAS_PLAQUE_COLOR,
            ny.FACE: fy.FACE_PLAQUE_COLOR,
            ny.FACING: fy.FACE_PLAQUE_COLOR
        }[maya.any_group.render_key[-2]]

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.x:
        # Restore.
        d[ok.TYPE] = type_
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Draw Canvas branch Plaque.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_canvas)


def do_cell(maya):
    """
    Draw Plaque for Cell/Per.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell)


def do_face(maya):
    """
    Draw Face/Per Plaque.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell_face)


def do_facing(maya):
    """
    Draw Facing/Per Plaque.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_cell_facing)


def do_main_cell(maya):
    """
    Draw Cell/Per Plaque.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main)


def do_main_face(maya):
    """
    Draw Face Plaque for the main option settings.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main_face)


def do_main_facing(maya):
    """
    Draw Facing Plaque for the main option settings.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main_facing)


def i_make_cell_face_mask(maya, d):
    """
    Apply the Mask option to Face/Per output.

    maya: Maya

    d: dict
        Mask Preset

    Return: mask layer or None
    """
    return make_cell_face_mask(maya, d)


def i_make_cell_facing_mask(maya, d):
    """
    Apply the Mask option to Facing/Per output.

    maya: Maya

    d: dict
        Mask Preset

    Return: mask layer or None
    """
    return make_cell_facing_mask(maya, d)


def i_make_main_face_mask(maya, d):
    """
    Apply Mask to Plaque Face main option settings.

    maya: Maya
    d: dict
        Mask Preset

    Return: mask layer or None
    """
    return make_main_face_mask(maya, d)


def i_make_main_facing_mask(maya, d):
    """
    Apply Mask to Plaque Facing main option settings.

    maya: Maya
    d: dict
        Mask Preset

    Return: mask layer or None
    """
    return make_main_facing_mask(maya, d)


def make_canvas(maya, d):
    """
    Draw Canvas Plaque material.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        with Plaque material
    """
    if test_image(maya, d):
        prep_below_type(d, maya.group)
        ready_canvas_rect(maya, d)
        return make_deco_material(maya, d, maya.group)


def make_cell_face(maya, d):
    """
    Make Plaque for Face/Per.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        with material
    """
    return produce_per_facing(maya, d, make_face)


def make_cell_facing(maya, d):
    """
    Make Plaque for Facing/Per.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        with material
    """
    return produce_per_facing(maya, d, make_facing)


def make_cell(maya, d):
    """
    Make Plaque for a cell.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        with material
    """
    if test_image(maya, d):
        prep_below_type(d, maya.group)
        ready_shape(maya, d)
        return make_deco_material(maya, d, maya.group)


def make_face(maya, d, group):
    """
    Make Plaque for Face.

    maya: Maya
    d: dict
        Plaque Preset

    group: layer group
        Is the destination of Face layer output.
    """
    is_color = False
    model = maya.model
    k = maya.k
    if test_image(maya, d):
        if d[ok.TYPE] in (dc.MEAN_COLOR, dc.COLOR):
            is_color = True

        maya.rect = model.get_facing_rect(k)

        if is_color:
            Deco.shape = model.get_facing_shape(k)

        else:
            maya.rect = model.get_facing_rect(k)
            Deco.shape = model.get_facing_form(k)

        select_shape(Run.j, Deco.shape)

        z = make_deco_material(maya, d, group)
        if z and not is_color:
            transform_foam(maya.rect, z, model.get_facing_foam(k))


def make_facing(maya, d, group):
    """
    Make Plaque for Facing.

    maya: Maya
    d: dict
        Plaque Preset

    group: layer group
        Is the destination of Facing layer output.

    Return: layer or None
        with Facing Plaque
    """
    is_color = False
    k = maya.k
    model = maya.model
    if test_image(maya, d):
        if d[ok.TYPE] in (dc.MEAN_COLOR, dc.COLOR):
            is_color = True

        maya.rect = model.get_facing_rect(k)

        if is_color:
            Deco.shape = model.get_facing_shape(k)

        else:
            maya.rect = model.get_facing_rect(k)
            Deco.shape = model.get_facing_form(k)

        if is_color:
            select_shape(Run.j, Deco.shape)

        else:
            select_rect(Run.j, *maya.rect)

        z = make_deco_material(maya, d, group)

        if z and not is_color:
            z = transform_foam(maya.rect, z, model.get_facing_foam(k))
            model.clip_facing(z, k)
        return z


def make_main(maya, d):
    """
    Create Plaque for the Cell branch main option settings.

    maya: Maya
    d: dict
        Plaque Preset

    Return: layer or None
        with material
    """
    def _do_one_material():
        _z = None

        prep_below_type(d, maya.group)

        # Create a single selection.
        # Image type is not one material, so there's no image check.
        pdb.gimp_selection_none(j)

        for _k in maya.main_q:
            maya.k = _k
            ready_shape(maya, d, option=fu.CHANNEL_OP_ADD)

        if test_image(maya, d):
            _z = make_deco_material(maya, d, maya.group)
        return _z

    def _do_many_material():
        """
        Inside a group, make a layer with its own material for each
        cell. Collapse the group and return the resulting layer.
        """
        _group = add_group_type(maya, d)

        for _k in maya.main_q:
            maya.k = _k
            if test_image(maya, d):
                ready_shape(maya, d)
                make_deco_material(maya, d, _group)
        return verify_layer_group(_group)

    j = Run.j
    n = d[ok.TYPE]

    if n not in dc.PER_TYPE:
        # All the Plaque is the same
        # material and is applied one time.
        return _do_one_material()
    else:
        # All the Plaque is the same material,
        # but applied cell-by-cell.
        return _do_many_material()


def mask_main_cell(maya, d):
    """
    Mask a Plaque layer from the main option settings.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer or None
        mask
    """
    j = Run.j
    z = maya.matter

    # selection channel, 'sel'
    sel = None

    pdb.gimp_selection_none(j)

    # Create a selection from the main cells.
    for k in maya.main_q:
        maya.k = k
        ready_shape(maya, d)

        if not pdb.gimp_selection_is_empty(j):
            make_mask_sel(maya, d)

        if sel:
            load_selection(j, sel, option=fu.CHANNEL_OP_ADD)
            pdb.gimp_image_remove_channel(j, sel)
        if not pdb.gimp_selection_is_empty(j):
            sel = pdb.gimp_selection_save(j)

    if sel:
        pdb.gimp_image_remove_channel(j, sel)
    return attach_mask_sel(z)


def make_main_face(maya, d):
    """
    Create Plaque Face for the main option settings.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer or None
        with material
    """
    return produce_main_facing(maya, d, make_face)


def make_main_facing(maya, d):
    """
    Create Plaque Facing for the main option settings.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer or None
        with material
    """
    return produce_main_facing(maya, d, make_facing)
