#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import (
    Backdrop as bs,
    Bump as fb,
    Define as de,
    Frame as ff,
    Gradient as fg,
    Image as fi,
    Mask as ms,
    Shape as sh,
    Issue as vo
)
from roller_constant_key import (
    Button as bk,
    Frame as ek,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_def_act import (
    get_backdrop_type_list,
    get_bump_type_list,
    get_camo_type_list,
    get_corner_type_list,
    get_edge_mode_list,
    get_frame_list,
    get_frame_style_list,
    get_hexagon_type_list,
    get_image_name_list,
    get_image_type_list,
    get_mask_list,
    get_noise_list,
    get_octagon_type_list,
    get_paint_rush_type_list,
    get_rectangle_type_list,
    get_resize_type_list,
    get_shaped_list,
    get_triangle_type_list,
    make_bool_tip,
    make_radio_tip,
    make_text_tip,
    scour,
    set_issue
)
from roller_def_option import (
    ANGLE,
    ANGLE_JITTER,
    BLUR,
    BLUR_XY,
    BRUSH,
    BRUSH_SIZE,
    BRUSH_SPACING,
    CFW,
    CLIP_TO_CELL,
    COLOR_1,
    COLOR_2A,
    CONTRACT,
    CONTRAST,
    CROP_X,
    CROP_Y,
    DESATURATE,
    EMBOSS,
    FACTOR_SIZE,
    FEATHER,
    FIXED_SIZE,
    FLIP,
    FONT,
    FRAME_W,
    GAP_W,
    GRADIENT,
    GRADIENT_ANGLE,
    GRADIENT_TYPE,
    HARDNESS,
    HSL,
    INTENSITY,
    INVERT,
    LINE_W,
    MASK_SCALE,
    MAX_POSITIVE_X,
    MAX_POSITIVE_Y,
    MESH_SIZE,
    MESH_TYPE,
    MODE,
    NEATNESS,
    NOISE_AMOUNT,
    OBEY_MARGINS,
    OFFSET_XY,
    OPACITY,
    OVERLAY_MODE,
    PATTERN,
    PER,
    PROFILE,
    RANDOM,
    RANDOM_ORDER,
    R_C,
    REVERSE,
    SEED,
    SHADOW_BLUR,
    SPECK_NOISE,
    STEPS,
    SWITCH,
    TEXT,
    WAVE_AMPLITUDE,
    WAVELENGTH,
    WIDTH,
    WRAP_TYPE
)
from roller_one_tip import Tip
from roller_port_generic import (
    PortAdd,
    PortAddAbove,
    PortAltAdd,
    PortAltWrap,
    PortBacking,
    PortBallJointWrap,
    PortBlurBelow,
    PortBoxyBevelOverlay,
    PortBoxyBevelWrap,
    PortBrush,
    PortBrushPD,
    PortBump,
    PortCamoPlanetOverlay,
    PortCeramicChipFiller,
    PortCirclePunchFiller,
    PortClearFrameWrap,
    PortColorBoardWrap,
    PortColorOverlay,
    PortColorPipeWrap,
    PortCrumbleShellWrap,
    PortFrameOverOverlay,
    PortGradientLevelWrap,
    PortHotGlueWrap,
    PortLineFashionFiller,
    PortLinkMirrorFiller,
    PortMargin,
    PortMod,
    PortNoise,
    PortPaintRushWrap,
    PortRadWaveFiller,
    PortRaisedMazeFiller,
    PortResize,
    PortShadowBasic,
    PortShapeBurstWrap,
    PortSquareCutFiller,
    PortSquarePunchFiller,
    PortStainedGlassFiller,
    PortStencil,
    PortStickyWobbleWrap,
    PortStretchTrayFiller,
    PortStrip,
    PortTape,
    PortWireFrameFiller,
    PortWrap
)
from roller_port_option_list import PortFrame
from roller_port_image_choice import PortImageChoice
from roller_port_mask import PortMask
from roller_port_shadow import PortShadow
from roller_widget_button import FileButton, FolderButton
from roller_widget_check_button import CheckButton, CheckButtonRandom
from roller_widget_combo import ComboBox
from roller_widget_entry import Entry
from roller_widget_label import (
    CoverLabel,
    FilledLabel,
    LockedLabel,
    NextXLabel,
    PreviousXLabel,
    TrimLabel
)
from roller_widget_option_button import OptionButton, OptionListButton
from roller_widget_slider import RandomSlider, Slider
from roller_widget_radio import RadioRandomColumn
from roller_widget_row import WidgetRow

# Bump_________________________________________________________________________
BUMP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBump,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, {
            wk.FUNCTION: get_bump_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: fb.CLOTH,
            wk.WIDGET: ComboBox
        }),
        (ok.MODE, deepcopy(OVERLAY_MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BLUR_X, deepcopy(BLUR_XY)),
        (ok.BLUR_Y, deepcopy(BLUR_XY)),
        (ok.NOISE, deepcopy(SPECK_NOISE)),
        (ok.BUMP_DEPTH, {
            wk.LIMIT: (1, 100),
            wk.RANDOM_Q: (1, 4),
            wk.TIPPER: make_text_tip,
            wk.VAL: 1.,
            wk.WIDGET: RandomSlider
        }),
        (ok.INVERT, deepcopy(INVERT))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(BUMP[wk.SUB], None, vo.MATTER, de.NO_MATTER)

a_ = BUMP[wk.SUB]
a_[ok.BLUR_X][wk.VAL] = 48.
a_[ok.BLUR_Y][wk.VAL] = 6.
BUMP[wk.SUB][ok.TYPE][wk.VAL] = fb.NOISE

BUMP[wk.SUB][ok.NOISE].update({wk.LIMIT: (.0, 1.), wk.VAL: .075})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Brush Dialog_________________________________________________________________
BRUSH_DIALOG = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBrush,
    wk.SUB: OrderedDict([
        (ok.BRUSH_SIZE, deepcopy(BRUSH_SIZE)),
        (ok.BRUSH_SPACING, deepcopy(BRUSH_SPACING)),
        (ok.BRUSH_ANGLE, {
            wk.LIMIT: (-180., 180.),
            wk.PRECISION: 1,
            wk.RANDOM_Q: (-180., 180.),
            wk.TIPPER: make_text_tip,
            wk.VAL: .0,
            wk.WIDGET: RandomSlider,
        }),
        (ok.ANGLE_JITTER, deepcopy(ANGLE_JITTER)),
        (ok.HARDNESS, deepcopy(HARDNESS)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.SEED, deepcopy(SEED)),
        (ok.BRUSH, deepcopy(BRUSH))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(BRUSH_DIALOG[wk.SUB], (), vo.MATTER, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Image Choice_________________________________________________________________
RC_SLICE = {
    wk.LIMIT: (1, 100),
    wk.TIPPER: make_text_tip,
    wk.VAL: 1.,
    wk.WIDGET: Slider
}
IMAGE_CHOICE = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortImageChoice,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, {
            wk.FUNCTION: get_image_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ok.NEXT_X,
            wk.WIDGET: ComboBox
        }),
        (ok.NUMERIC_SEQUENCE, {
            wk.LIMIT: (1, 999),
            wk.PAGE_INCR: 10,
            wk.TIPPER: make_text_tip,
            wk.VAL: 1.,
            wk.WIDGET: Slider
        }),
        (ok.IMAGE_NAME, {
            wk.FUNCTION: get_image_name_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: ComboBox
        }),
        (ok.NEXT_X, {wk.WIDGET: NextXLabel}),
        (ok.PREVIOUS_X, {wk.WIDGET: PreviousXLabel}),
        (ok.LOOP_X, {
            wk.TEXT: fi.LOOP_TYPE,
            wk.TIPPER: make_radio_tip,
            wk.TIPS: (Tip.LOOP_PLUS, Tip.LOOP_MINUS),
            wk.VAL: 0,
            wk.WIDGET: RadioRandomColumn
        }),
        (ok.FILE, {
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: FileButton
        }),
        (ok.FOLDER, {
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: FolderButton
        }),
        (ok.FILTER, {
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: Entry
        }),
        (ok.FOLDER_ORDER, {
            wk.TEXT: fi.FOLDER_ORDER_LIST,
            wk.TIPPER: make_radio_tip,
            wk.VAL: 0,
            wk.WIDGET: RadioRandomColumn
        }),
        (ok.AS_LAYERS, {
            wk.TIPPER: make_bool_tip,
            wk.TOOLTIP: Tip.IMAGE_LAYERS,
            wk.VAL: 0,
            wk.WIDGET: CheckButton
        }),
        (ok.LAYER_ORDER, {
            wk.TEXT: fi.LAYER_ORDER_LIST,
            wk.TIPPER: make_radio_tip,
            wk.TOOLTIP: Tip.IMAGE_ORDER,
            wk.VAL: 0,
            wk.WIDGET: RadioRandomColumn
        }),
        (ok.SLICE, {
            wk.TIPPER: make_bool_tip,
            wk.TOOLTIP: Tip.SLICE,
            wk.VAL: 0,
            wk.WIDGET: CheckButton
        }),
        (ok.ROW_SLICE, deepcopy(RC_SLICE)),
        (ok.COLUMN_SLICE, deepcopy(RC_SLICE)),
        (ok.SLICE_ORDER, {
            wk.TEXT: fi.SLICE_ORDER_LIST,
            wk.TIPPER: make_radio_tip,
            wk.VAL: 0,
            wk.WIDGET: RadioRandomColumn
        }),
        (ok.AUTOCROP, {
            wk.TIPPER: make_bool_tip,
            wk.TOOLTIP: Tip.AUTOCROP,
            wk.VAL: 0,
            wk.WIDGET: CheckButton
        }),
        (ok.RANDOM_ORDER, deepcopy(RANDOM_ORDER)),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(
    IMAGE_CHOICE[wk.SUB], (), vo.MATTER, de.NO_MATTER + (
        ok.NEXT_X, ok.PREVIOUS_X
    )
)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Mask_________________________________________________________________________
MASK = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortMask,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, {
            wk.FUNCTION: get_mask_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: "Circle",
            wk.WIDGET: ComboBox
        }),
        (ok.CORNER_TYPE, {
            wk.FUNCTION: get_corner_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ms.CUT_CORNER,
            wk.WIDGET: ComboBox
        }),
        (ok.HEXAGON_TYPE, {
            wk.FUNCTION: get_hexagon_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: sh.HEXAGON,
            wk.WIDGET: ComboBox
        }),
        (ok.OCTAGON_TYPE, {
            wk.FUNCTION: get_octagon_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: sh.OCTAGON,
            wk.WIDGET: ComboBox
        }),
        (ok.RECTANGLE_TYPE, {
            wk.FUNCTION: get_rectangle_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: sh.RECTANGLE,
            wk.WIDGET: ComboBox
        }),
        (ok.TRIANGLE_TYPE, {
            wk.FUNCTION: get_triangle_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ms.TRIANGLE_UP_REGULAR,
            wk.WIDGET: ComboBox
        }),
        (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
        (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
        (ok.TEXT, {
            wk.CHARS: 15,
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: Entry
        }),
        (ok.HORZ_SCALE, deepcopy(MASK_SCALE)),
        (ok.VERT_SCALE, deepcopy(MASK_SCALE)),
        (ok.PUPIL_SCALE, deepcopy(MASK_SCALE)),
        (ok.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE)),
        (ok.FEATHER, deepcopy(FEATHER)),
        (ok.STEPS, deepcopy(STEPS)),
        (ok.AMP, {
            wk.LIMIT: (2, 30),
            wk.RANDOM_Q: (2, 30),
            wk.TOOLTIP: Tip.AMP,
            wk.TIPPER: make_text_tip,
            wk.VAL: 3.,
            wk.WIDGET: RandomSlider
        }),
        (ok.SMOOTH, {
            wk.LIMIT: (3, 20),
            wk.RANDOM_Q: (5, 12),
            wk.TIPPER: make_text_tip,
            wk.VAL: 4.,
            wk.WIDGET: RandomSlider
        }),
        (ok.ANGLE, deepcopy(ANGLE)),
        (ok.CONTRACT, deepcopy(CONTRACT)),
        (ok.SEED, deepcopy(SEED)),
        (ok.CUT_OUT, {
            wk.TOOLTIP: Tip.CUT_OUT,
            wk.TIPPER: make_bool_tip,
            wk.VAL: 0,
            wk.WIDGET: CheckButton
        }),
        (ok.FONT, deepcopy(FONT)),
        (ok.RW1, {
            wk.SUB: OrderedDict([
                (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
                (ok.BRUSH_D, deepcopy(BRUSH_DIALOG))
            ]),
            wk.WIDGET: WidgetRow
        })
    ]),
    wk.WIDGET: OptionButton
}
a_ = MASK[wk.SUB]
a_[ok.FEATHER][wk.VAL] = 0.
a_[ok.PUPIL_SCALE][wk.VAL] = .33
a_[ok.PARALLELOGRAM_SCALE][wk.VAL] = .5

set_issue(MASK, None, vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Resize ______________________________________________________________________
RESIZE = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortResize,
    wk.SUB: OrderedDict([
        (ok.TYPE, {
            wk.FUNCTION: get_resize_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ok.LOCKED,
            wk.WIDGET: ComboBox
        }),
        (ok.LOCKED, {wk.WIDGET: LockedLabel}),
        (ok.TRIM, {wk.WIDGET: TrimLabel}),
        (ok.FILLED, {wk.WIDGET: FilledLabel}),
        (ok.COVER, {wk.WIDGET: CoverLabel}),
        (ok.FIXED_SIZE_W, deepcopy(FIXED_SIZE)),
        (ok.FIXED_SIZE_H, deepcopy(FIXED_SIZE)),
        (ok.FIW, deepcopy(FACTOR_SIZE)),
        (ok.FIH, deepcopy(FACTOR_SIZE)),
        (ok.CROP_X, deepcopy(CROP_X)),
        (ok.CROP_Y, deepcopy(CROP_Y)),
        (ok.CROP_W, deepcopy(FIXED_SIZE)),
        (ok.CROP_H, deepcopy(FIXED_SIZE))
    ]),
    wk.WIDGET: OptionButton
}
a_ = RESIZE[wk.SUB]
a_[ok.FIXED_SIZE_W][wk.TOOLTIP] = Tip.FIXED_SIZE_W
a_[ok.FIW][wk.TOOLTIP] = Tip.FIW

set_issue(RESIZE, None, vo.MATTER, ())

RESIZE_1 = deepcopy(RESIZE)
RESIZE_1[wk.SUB][ok.TYPE][wk.VAL] = ok.COVER
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Noise _______________________________________________________________________
NOISE_D = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortNoise,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, {
            wk.FUNCTION: get_noise_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ff.INK,
            wk.WIDGET: ComboBox
        }),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BLUR, deepcopy(BLUR)),
        (ok.NOISE_AMOUNT, deepcopy(NOISE_AMOUNT)),
        (ok.SPECK_NOISE, deepcopy(SPECK_NOISE)),
        (ok.SEED, deepcopy(SEED)),
        (ok.BUMP, deepcopy(BUMP))
    ]),
    wk.WIDGET: OptionButton
}
NOISE_D[wk.SUB][ok.BLUR].update({wk.RANDOM_Q: (.0, 15.), wk.VAL: 1.5})

set_issue(NOISE_D[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Margin_______________________________________________________________________
# Use for both Caption and for an option group.
MARGIN = OrderedDict([
    (wk.CHANGELESS, True),
    (wk.DIALOG, PortMargin),
    (wk.SUB, OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TOP, deepcopy(MAX_POSITIVE_Y)),
        (ok.BOTTOM, deepcopy(MAX_POSITIVE_Y)),
        (ok.LEFT, deepcopy(MAX_POSITIVE_X)),
        (ok.RIGHT, deepcopy(MAX_POSITIVE_X)),
        (ok.PER, deepcopy(PER))
    ])),
    (wk.WIDGET, OptionButton)
])

set_issue(MARGIN[wk.SUB], None, vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Shadow_______________________________________________________________________
SELECTED_ROW = {'node': {'selected_row': {wk.VAL: 0}}}
SWITCH_GROUP = {ok.SWITCH: deepcopy(SWITCH)}
INNER_SHADOW = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.INTENSITY, deepcopy(INTENSITY)),
    (ok.BLUR, {
        wk.LIMIT: (.0, 500.),
        wk.PRECISION: 1,
        wk.RANDOM_Q: (.0, 50.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 15.,
        wk.WIDGET: RandomSlider
    }),
    (ok.OFFSET_X, deepcopy(OFFSET_XY)),
    (ok.OFFSET_Y, deepcopy(OFFSET_XY)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (bk.RANDOM, deepcopy(RANDOM))
])
SHADOW_NUM = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.INTENSITY, deepcopy(INTENSITY)),
    (ok.BLUR, deepcopy(SHADOW_BLUR)),
    (ok.OFFSET_X, deepcopy(OFFSET_XY)),
    (ok.OFFSET_Y, deepcopy(OFFSET_XY)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (bk.RANDOM, deepcopy(RANDOM))
])
SHADOW_1 = deepcopy(SHADOW_NUM)
SHADOW_2 = deepcopy(SHADOW_NUM)

for i in (SHADOW_1, SHADOW_2, INNER_SHADOW):
    set_issue(i, (), vo.MATTER, de.NO_MATTER)

SWITCH_GROUP[ok.SWITCH][wk.ISSUE] = vo.MATTER
SHADOW = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortShadow,
    wk.SUB: OrderedDict([
        (sk.SHADOW_SWITCH, deepcopy(SWITCH_GROUP)),
        (sk.SHADOW, deepcopy(SELECTED_ROW)),
        (sk.SHADOW_1, deepcopy(SHADOW_1)),
        (sk.SHADOW_2, deepcopy(SHADOW_2)),
        (sk.INNER_SHADOW, deepcopy(INNER_SHADOW)),
    ]),
    wk.WIDGET: OptionButton
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Shadow Basic_________________________________________________________________
SHADOW_BASIC = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortShadowBasic,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.INTENSITY, deepcopy(INTENSITY)),
        (ok.BLUR, deepcopy(SHADOW_BLUR)),
        (ok.COLOR_1, deepcopy(COLOR_1))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(SHADOW_BASIC[wk.SUB], (), vo.MATTER, (ok.MODE,))
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Corner Tape__________________________________________________________________
TAPE = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortTape,
    wk.SUB: OrderedDict([
        (ok.LENGTH, {
            wk.LIMIT: (5, 1000),
            wk.PAGE_INCR: 10,
            wk.RANDOM_Q: (80, 150),
            wk.TIPPER: make_text_tip,
            wk.VAL: 150.,
            wk.WIDGET: RandomSlider
        }),
        (ok.WIDTH, {
            wk.LIMIT: (5, 999),
            wk.PAGE_INCR: 10,
            wk.RANDOM_Q: (30, 60),
            wk.TIPPER: make_text_tip,
            wk.VAL: 50.,
            wk.WIDGET: RandomSlider
        }),
        (ok.ANGLE_SHIFT, {
            wk.LIMIT: (.0, 180.),
            wk.PRECISION: 1,
            wk.RANDOM_Q: (.0, 11.),
            wk.TIPPER: make_text_tip,
            wk.VAL: 5.,
            wk.WIDGET: RandomSlider
        }),
        (ok.CORNER_SHIFT, {
            wk.LIMIT: (0, 100),
            wk.PAGE_INCR: 5,
            wk.RANDOM_Q: (0, 18),
            wk.TIPPER: make_text_tip,
            wk.VAL: 9.,
            wk.WIDGET: RandomSlider
        }),
        (ok.LENGTH_SHIFT, {
            wk.LIMIT: (0, 999),
            wk.PAGE_INCR: 10,
            wk.RANDOM_Q: (10, 40),
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.LENGTH_SHIFT,
            wk.VAL: 10.,
            wk.WIDGET: RandomSlider
        }),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(TAPE[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Mod__________________________________________________________________________
MOD = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortMod,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.BLUR, deepcopy(BLUR)),
        (ok.SATURATION, deepcopy(HSL)),
        (ok.BRIGHTNESS, deepcopy(HSL)),
        (ok.INVERT, deepcopy(INVERT)),
        (ok.FLIP_H, deepcopy(FLIP)),
        (ok.FLIP_V, deepcopy(FLIP))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(MOD[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Blur Below__________________________________________________________________
BLUR_BELOW = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBlurBelow,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.OPAQUE, {
            wk.TOOLTIP: Tip.OPAQUE,
            wk.TIPPER: make_bool_tip,
            wk.VAL: 0,
            wk.WIDGET: CheckButton
        }),
        (ok.MOD, deepcopy(MOD))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(BLUR_BELOW[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Add__________________________________________________________________________
ADD = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortAdd,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.NBR, deepcopy({
            wk.SUB: OrderedDict([
                (ok.NOISE_D, deepcopy(NOISE_D)),
                (ok.BLUR_BELOW, deepcopy(BLUR_BELOW))
            ]),
            wk.WIDGET: WidgetRow
        })),
        (ok.BRW, {
            wk.SUB: OrderedDict([
                (ok.BUMP, deepcopy(BUMP)),
                (ok.SHADOW, deepcopy(SHADOW))
            ]),
            wk.WIDGET: WidgetRow
        })
    ]),
    wk.WIDGET: OptionButton
}

set_issue(ADD[wk.SUB], None, vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Alt Add______________________________________________________________________
ADD_ALT = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortAltAdd,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.NOISE_D, deepcopy(NOISE_D)),
        (ok.BLUR_BELOW, deepcopy(BLUR_BELOW)),
        (ok.BUMP, deepcopy(BUMP))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(ADD_ALT[wk.SUB], None, vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Add Above___________________________________________________________________
ADD_ABOVE = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortAddAbove,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.NOISE_D, deepcopy(NOISE_D)),
        (ok.BUMP, deepcopy(BUMP))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(ADD_ABOVE[wk.SUB], None, vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Backing______________________________________________________________________
BACKING = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBacking,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, {
            wk.FUNCTION: get_backdrop_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: bs.COLOR,
            wk.WIDGET: ComboBox
        }),
        (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
        (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
        (ok.SEED, deepcopy(SEED)),
        (ok.FIT_IMAGE, {
            wk.VAL: 1,
            wk.TIPPER: make_bool_tip,
            wk.WIDGET: CheckButton
        }),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.PATTERN, deepcopy(PATTERN)),
        (ok.RW1, deepcopy(
            {
                wk.SUB: OrderedDict([
                    (ok.BUMP, deepcopy(BUMP)),
                    (ok.IMAGE_CHOICE, IMAGE_CHOICE),
                    (ok.GRADIENT, deepcopy(GRADIENT)),
                    (ok.MOD, deepcopy(MOD))
                ]),
                wk.WIDGET: WidgetRow
            }
        ))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(BACKING, None, vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Brush Punch Dialog___________________________________________________________
BRUSH_P_D = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBrushPD,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BRUSH_SIZE, deepcopy(BRUSH_SIZE)),
        (ok.BRUSH_SPACING, deepcopy(BRUSH_SPACING)),
        (ok.BRUSH_ANGLE, {
            wk.LIMIT: (-180., 180.),
            wk.PRECISION: 1,
            wk.RANDOM_Q: (-180., 180.),
            wk.TIPPER: make_text_tip,
            wk.VAL: .0,
            wk.WIDGET: RandomSlider,
        }),
        (ok.ANGLE_JITTER, deepcopy(ANGLE_JITTER)),
        (ok.HARDNESS, deepcopy(HARDNESS)),
        (ok.SEED, deepcopy(SEED)),
        (ok.BRW, {
            wk.SUB: OrderedDict([
                (ok.BRUSH, deepcopy(BRUSH)),
                (ok.ADD_ALT, deepcopy(ADD_ALT))
            ]),
            wk.WIDGET: WidgetRow
        }),
    ]),
    wk.WIDGET: OptionButton
}

set_issue(BRUSH_P_D[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Ceramic Chip Filler__________________________________________________________
FILLER_CC = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortCeramicChipFiller,
    wk.SUB: OrderedDict([
        (ok.MESH_TYPE, deepcopy(MESH_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.MESH_SIZE, deepcopy(MESH_SIZE)),
        (ok.SEED, deepcopy(SEED)),
        (ok.ADD_ALT, deepcopy(ADD_ALT))
    ]),
    wk.WIDGET: OptionButton
}

# Circle Punch Filler__________________________________________________________
FILLER_CP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortCirclePunchFiller,
    wk.SUB: OrderedDict([
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.CIRCLE_DIAMETER, {
            # Is limited by GIMP's clipboard to
            # pattern function where the maximum side
            # span for the clipboard is 1024.
            wk.LIMIT: (12, 680),
            wk.RANDOM_Q: (12, 100),
            wk.TIPPER: make_text_tip,
            wk.VAL: 30.,
            wk.WIDGET: RandomSlider
        }),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# Line Fashion Filler__________________________________________________________
FILLER_LF = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortLineFashionFiller,
    wk.SUB: OrderedDict([
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.GAP_W, deepcopy(GAP_W)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# Link Mirror Filler___________________________________________________________
FILLER_LM = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortLinkMirrorFiller,
    wk.SUB: OrderedDict([
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.CFW, deepcopy(CFW)),
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.SCATTER_COUNT, {
            wk.LIMIT: (1, 100),
            wk.PAGE_INCR: 5,
            wk.RANDOM_Q: (2, 20),
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.SCATTER_COUNT,
            wk.VAL: 5.,
            wk.WIDGET: RandomSlider
        }),
        (ok.SEED, deepcopy(SEED)),
    ]),
    wk.WIDGET: OptionButton
}

for i_ in (ok.ROW, ok.COLUMN):
    FILLER_LM[wk.SUB][i_][wk.LIMIT] = 3, 100
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Rad Wave Filler______________________________________________________________
FILLER_RW = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortRadWaveFiller,
    wk.SUB: OrderedDict([
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.CFW, deepcopy(CFW)),
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.WAVE_AMPLITUDE, deepcopy(WAVE_AMPLITUDE)),
        (ok.WAVELENGTH, deepcopy(WAVELENGTH)),
        (ok.WHIRL, {
            wk.LIMIT: (-720, 720),
            wk.PAGE_INCR: 10,
            wk.RANDOM_Q: (-30, 30),
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.WHIRL,
            wk.VAL: 45.,
            wk.WIDGET: RandomSlider
        })
    ]),
    wk.WIDGET: OptionButton
}

# Raised Maze Filler___________________________________________________________
FILLER_RM = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortRaisedMazeFiller,
    wk.SUB: OrderedDict([
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.CFW, deepcopy(CFW)),
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}


for i_ in (ok.ROW, ok.COLUMN):
    FILLER_RM[wk.SUB][i_][wk.LIMIT] = 4, 999
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Square Cut Filler____________________________________________________________
FILLER_SC = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortSquareCutFiller,
    wk.SUB: OrderedDict([
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

for i_ in (ok.ROW, ok.COLUMN):
    FILLER_SC[wk.SUB][i_][wk.VAL] = 15.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Square Punch Filler__________________________________________________________
FILLER_SP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortSquarePunchFiller,
    wk.SUB: OrderedDict([
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.GAP_W, deepcopy(GAP_W)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# Stained Glass Filler_________________________________________________________
FILLER_SG = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortStainedGlassFiller,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.GLASS_PANE_W, deepcopy(WIDTH)),
        (ok.ANGLE, deepcopy(ANGLE)),
        (ok.SEED, deepcopy(SEED)),
        (ok.ADD_ALT, deepcopy(ADD_ALT))
    ]),
    wk.WIDGET: OptionButton
}

a_ = FILLER_SG[wk.SUB]
a_[ok.GLASS_PANE_W][wk.RANDOM_Q] = 25, 100
a_[ok.GLASS_PANE_W][wk.VAL] = 72.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stretch Tray Filler__________________________________________________________
FILLER_ST = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortStretchTrayFiller,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.SATURATION, deepcopy(HSL)),
        (ok.ADD_ALT, deepcopy(ADD_ALT))
    ]),
    wk.WIDGET: OptionButton
}
FILLER_ST[wk.SUB][ok.SATURATION][wk.VAL] = 24.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stretch Tray Filler__________________________________________________________
FILLER_WF = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortWireFrameFiller,
    wk.SUB: OrderedDict([
        (ok.MESH_TYPE, deepcopy(MESH_TYPE)),
        (ok.MESH_SIZE, deepcopy(MESH_SIZE)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.WIRE_THICKNESS, {
            wk.LIMIT: (3, 30),
            wk.RANDOM_Q: (4, 10),
            wk.TIPPER: make_text_tip,
            wk.VAL: 3.,
            wk.WIDGET: RandomSlider
        }),
        (ok.NEATNESS, deepcopy(NEATNESS)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# Has Filler Maya.
for i_ in (
    FILLER_CC,
    FILLER_CP,
    FILLER_LF,
    FILLER_LM,
    FILLER_RM,
    FILLER_RW,
    FILLER_SC,
    FILLER_SG,
    FILLER_SP,
    FILLER_ST,
    FILLER_WF
):
    set_issue(i_, (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Overlay Boxy Bevel___________________________________________________________
OVERLAY_BB = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBoxyBevelOverlay,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.PATTERN, deepcopy(PATTERN)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}

OVERLAY_BB[wk.SUB][ok.MODE][wk.VAL] = "Overlay"

set_issue(OVERLAY_BB[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Overlay Color________________________________________________________________
OVERLAY_CF = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortColorOverlay,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(OVERLAY_MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}
a_ = OVERLAY_CF[wk.SUB]
a_[ok.COLOR_1][wk.VAL] = 231, 231, 194
a_[ok.OPACITY][wk.VAL] = 30.

set_issue(OVERLAY_CF[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Overlay Camo Planet__________________________________________________________
OVERLAY_CP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortCamoPlanetOverlay,
    wk.SUB: OrderedDict([
        (ok.CAMO_TYPE, {
            wk.FUNCTION: get_camo_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ff.COMPOSITE,
            wk.WIDGET: ComboBox
        }),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.SATURATION, deepcopy(HSL)),
        (ok.SEED, deepcopy(SEED)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}
a_ = OVERLAY_CP[wk.SUB]
a_[ok.MODE][wk.VAL] = "Hard Light"
a_[ok.SATURATION][wk.VAL] = 30.

set_issue(OVERLAY_CP[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Overlay Frame Over___________________________________________________________
OVERLAY_FO = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortFrameOverOverlay,
    wk.SUB: OrderedDict([
        (ok.TYPE, {
            wk.FUNCTION: get_frame_style_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ff.CLOUDS,
            wk.WIDGET: ComboBox
        }),
        (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
        (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BLUR, deepcopy(BLUR)),
        (ok.SEED, deepcopy(SEED)),
        (ok.RW1, {
            wk.SUB: OrderedDict([
                (ok.COLOR_1, deepcopy(COLOR_1)),
                (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE))
            ]),
            wk.WIDGET: WidgetRow
        }),
        (ok.RW2, {
            wk.SUB: OrderedDict([
                (ok.GRADIENT, deepcopy(GRADIENT)),
                (ok.PATTERN, deepcopy(PATTERN))
            ]),
            wk.WIDGET: WidgetRow
        }),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(OVERLAY_FO[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Strip________________________________________________________________________
STRIP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortStrip,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.HEIGHT, {
            wk.LIMIT: (.0, 7.),
            wk.PRECISION: 1,
            wk.RANDOM_Q: (.1, 7.),
            wk.STEP_INCR: .1,
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.STRIP_H,
            wk.VAL: 1.5,
            wk.WIDGET: RandomSlider
        }),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.ADD, deepcopy(ADD))
    ]),
    wk.WIDGET: OptionButton
}
a_ = STRIP[wk.SUB]
a_[ok.COLOR_1][wk.VAL] = 127, 127, 127

set_issue(STRIP[wk.SUB], None, vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap_________________________________________________________________________
WRAP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortWrap,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.DEPTH, deepcopy(BLUR)),
        (ok.CONTRAST, deepcopy(CONTRAST)),
        (ok.SOFTEN, deepcopy(BLUR)),
        (ok.EMBOSS, deepcopy(EMBOSS)),
        (ok.COLOR_1, deepcopy(COLOR_1))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(WRAP[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Alt_____________________________________________________________________
WRAP_ALT = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortAltWrap,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.DEPTH, deepcopy(BLUR)),
        (ok.CONTRAST, deepcopy(CONTRAST)),
        (ok.SOFTEN, deepcopy(BLUR)),
        (ok.EMBOSS, deepcopy(EMBOSS)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.ADD_ALT, deepcopy(ADD_ALT))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(WRAP_ALT[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Above___________________________________________________________________
WRAP_ABOVE = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortAltWrap,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.DEPTH, deepcopy(BLUR)),
        (ok.CONTRAST, deepcopy(CONTRAST)),
        (ok.SOFTEN, deepcopy(BLUR)),
        (ok.EMBOSS, deepcopy(EMBOSS)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(WRAP_ABOVE[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Boxy Bevel______________________________________________________________
WRAP_BB = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBoxyBevelWrap,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.BEVEL_W, {
            wk.LIMIT: (0, 999),
            wk.PAGE_INCR: 2,
            wk.RANDOM_Q: (4, 8),
            wk.TIPPER: make_text_tip,
            wk.VAL: 10.,
            wk.WIDGET: RandomSlider
        }),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(WRAP_BB[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Ball Joint______________________________________________________________
WRAP_BJ = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortBallJointWrap,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BRUSH_SIZE, deepcopy(BRUSH_SIZE))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(WRAP_BJ[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Color Board_____________________________________________________________
WRAP_CB = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortColorBoardWrap,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(WRAP_CB[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Clear Frame_____________________________________________________________
WRAP_CF = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortClearFrameWrap,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.INNER_FRAME_W, {
            wk.LIMIT: (4, 14),
            wk.RANDOM_Q: (4, 14),
            wk.TIPPER: make_text_tip,
            wk.VAL: 5.,
            wk.WIDGET: RandomSlider
        }),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}
WRAP_CF[wk.SUB][ok.WIDTH][wk.VAL] = 30.
WRAP_CF[wk.SUB][ok.OPACITY][wk.VAL] = 50.

set_issue(WRAP_CF[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Color Pipe______________________________________________________________
WRAP_CP = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortColorPipeWrap,
    wk.SUB: OrderedDict([
        (ok.PROFILE, deepcopy(PROFILE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(WRAP_CP[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Crumble Shell___________________________________________________________
WRAP_CS = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortCrumbleShellWrap,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.SPREAD, {
            wk.LIMIT: (1., 100.),
            wk.PAGE_INCR: 5.,
            wk.PRECISION: 1,
            wk.RANDOM_Q: (8., 16.),
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.SPREAD_DISTRESS,
            wk.VAL: 12.,
            wk.WIDGET: RandomSlider
        }),
        (ok.DISTRESS, {
            wk.LIMIT: (1., 254.),
            wk.PRECISION: 1,
            wk.RANDOM_Q: (1., 254.),
            wk.TIPPER: make_text_tip,
            wk.TOOLTIP: Tip.DISTRESS_THRESHOLD,
            wk.VAL: 127.,
            wk.WIDGET: RandomSlider
        }),
        (ok.SEED, deepcopy(SEED)),
    ]),
    wk.WIDGET: OptionButton
}

WRAP_CS[wk.SUB][ok.WIDTH].update({wk.RANDOM_Q: (15, 35), wk.VAL: 15.})

set_issue(WRAP_CS[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Gradient Level__________________________________________________________
WRAP_GL = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortGradientLevelWrap,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.COLOR_2A, deepcopy(COLOR_2A))
    ]),
    wk.WIDGET: OptionButton
}

WRAP_GL[wk.SUB][ok.COLOR_2A][wk.VAL] = (160, 105, 28, 255), (116, 77, 43, 255)
WRAP_GL[wk.SUB][ok.WIDTH][wk.VAL] = 30.

set_issue(WRAP_GL[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Hot Glue________________________________________________________________
WRAP_HG = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortHotGlueWrap,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.SOFTEN, deepcopy(BLUR)),
        (ok.WAVE_AMPLITUDE, deepcopy(WAVE_AMPLITUDE)),
        (ok.WAVELENGTH, deepcopy(WAVELENGTH)),
        (ok.WAVE_PHASE, {
            wk.LIMIT: (-360., 360.),
            wk.PRECISION: 1,
            wk.RANDOM_Q: (-360., 360.),
            wk.TIPPER: make_text_tip,
            wk.VAL: 1.,
            wk.WIDGET: RandomSlider
        })
    ]),
    wk.WIDGET: OptionButton
}
WRAP_HG[wk.SUB][ok.MODE][wk.VAL] = "Overlay"
WRAP_HG[wk.SUB][ok.WIDTH][wk.VAL] = 5.
WRAP_HG[wk.SUB][ok.SOFTEN].update({wk.RANDOM_Q: (1., 3.), wk.VAL: 2.})

set_issue(WRAP_HG[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Paint Rush______________________________________________________________
WRAP_PR = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortPaintRushWrap,
    wk.SUB: OrderedDict([
        (ok.EDGE_TYPE, {
            wk.FUNCTION: get_paint_rush_type_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: ff.WHITE_SOFT,
            wk.WIDGET: ComboBox
        }),
        (ok.EDGE_MODE, {
            wk.FUNCTION: get_edge_mode_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: "Lighten Only",
            wk.WIDGET: ComboBox
        }),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.POST_BLUR, deepcopy(BLUR)),
        (ok.COLORIZE_OPACITY, deepcopy(OPACITY)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.COLORIZE, {
            wk.TIPPER: make_bool_tip,
            wk.VAL: 0,
            wk.WIDGET: CheckButtonRandom
        }),
    ]),
    wk.WIDGET: OptionButton
}

WRAP_PR[wk.SUB][ok.WIDTH][wk.VAL] = 80.
WRAP_PR[wk.SUB][ok.COLOR_1][wk.VAL] = 175, 90, 10
WRAP_PR[wk.SUB][ok.COLORIZE_OPACITY][wk.VAL] = 70.
WRAP_PR[wk.SUB][ok.POST_BLUR][wk.TOOLTIP] = Tip.POST_BLUR

set_issue(WRAP_PR[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Shape Burst_____________________________________________________________
WRAP_SB = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortShapeBurstWrap,
    wk.SUB: OrderedDict([
        (ok.SHAPED_TYPE, {
            wk.FUNCTION: get_shaped_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: fg.SHAPED_DIMPLED,
            wk.WIDGET: ComboBox
        }),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.UNSHARP_AMOUNT, {
            wk.LIMIT: (.0, 300.),
            wk.PAGE_INCR: 10.,
            wk.PRECISION: 1,
            wk.RANDOM_Q: (.0, 50.),
            wk.TIPPER: make_text_tip,
            wk.VAL: 10.,
            wk.WIDGET: RandomSlider
        }),
        (ok.UNSHARP_RADIUS, {
            wk.LIMIT: (.0, 1500.),
            wk.PAGE_INCR: 10.,
            wk.PRECISION: 1,
            wk.RANDOM_Q: (.0, 50.),
            wk.TIPPER: make_text_tip,
            wk.VAL: 11.,
            wk.WIDGET: RandomSlider
        }),
        (ok.UNSHARP_THRESHOLD, {
            wk.LIMIT: (.0, .1),
            wk.PRECISION: 2,
            wk.RANDOM_Q: (.0, .1),
            wk.TIPPER: make_text_tip,
            wk.VAL: .03,
            wk.WIDGET: RandomSlider
        }),
        (ok.RW1, {
            wk.SUB: OrderedDict([
                (ok.INVERT, deepcopy(INVERT)),
                (ok.REVERSE, deepcopy(REVERSE))
            ]),
            wk.WIDGET: WidgetRow
        }),
        (ok.GRADIENT, deepcopy(GRADIENT))
    ]),
    wk.WIDGET: OptionButton
}

WRAP_SB[wk.SUB][ok.GRADIENT][wk.VAL] = "Brushed Aluminium"
WRAP_SB[wk.SUB][ok.WIDTH][wk.VAL] = 50.

set_issue(WRAP_SB[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Sticky Wobble___________________________________________________________
WRAP_SW = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortStickyWobbleWrap,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.DEPTH, deepcopy(BLUR)),
        (ok.CONTRAST, deepcopy(CONTRAST)),
        (ok.SOFTEN, deepcopy(BLUR)),
        (ok.WOBBLE_FACTOR, {
            wk.LIMIT: (.0, 1.),
            wk.PRECISION: 2,
            wk.RANDOM_Q: (.01, 1.),
            wk.TIPPER: make_text_tip,
            wk.VAL: .08,
            wk.WIDGET: RandomSlider
        }),
        (ok.SEED, deepcopy(SEED)),
        (ok.EMBOSS, deepcopy(EMBOSS)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
    ]),
    wk.WIDGET: OptionButton
}
a = WRAP_SW[wk.SUB]
a[ok.TYPE][wk.VAL] = ff.ROUNDED
a[ok.WIDTH].update({wk.RANDOM_Q: (1, 50), wk.VAL: 12.})
a[ok.DEPTH][wk.VAL] = 10.
a[ok.CONTRAST][wk.VAL] = -36
a[ok.SOFTEN][wk.VAL] = 7.

set_issue(a, (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


for i_ in (WRAP, WRAP_ABOVE, WRAP_ALT, WRAP_SW):
    a_ = i_[wk.SUB]
    a_[ok.EMBOSS][wk.VAL] = 1
    a_[ok.COLOR_1][wk.VAL] = 127, 127, 127

    a_[ok.DEPTH].update({
        wk.LIMIT: (1., 100.), wk.RANDOM_Q: (1., 25.), wk.VAL: 1.
    })
    a_[ok.SOFTEN].update({
        wk.LIMIT: (.0, 50.),
        wk.RANDOM_Q: (.0, 8.), wk.STEP_INCR: .1, wk.VAL: .0
    })

# Stencil Frame Over___________________________________________________________
STENCIL = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortStencil,
    wk.SUB: OrderedDict([
        (ok.FRAME_OVER, {
            wk.FUNCTION: get_frame_list,
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: ComboBox
        }),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}

set_issue(STENCIL[wk.SUB], (), vo.MATTER, de.NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Frame________________________________________________________________________
BORDER_LINE = OrderedDict([(ok.BRW, {
    wk.SUB: OrderedDict([
        (ok.WRAP, deepcopy(WRAP)),
        (ok.ADD_ALT, deepcopy(ADD_ALT)),
        (ok.SHADOW, deepcopy(SHADOW))
    ]),
    wk.WIDGET: WidgetRow
})])
FRAME = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortFrame,
    wk.ISSUE: vo.NULL,              # Needed by PerGroup.
    wk.VAL: {
        ok.SWITCH: SWITCH[wk.VAL],
        ek.BORDER_LINE: scour({}, BORDER_LINE, wk.VAL)
    },
    wk.WIDGET: OptionListButton
}

# Row _________________________________________________________________________
AFR = {
    wk.SUB: OrderedDict([
        (ok.ADD, ADD),
        (ok.FRAME, deepcopy(FRAME))
    ]),
    wk.WIDGET: WidgetRow
}
BRW = {
    wk.SUB: OrderedDict([
        (ok.BUMP, deepcopy(BUMP)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}

# Font / Color Row_____________________________________________________________
FCM = {
    wk.SUB: OrderedDict([
        (ok.FONT, deepcopy(FONT)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.MARGIN, deepcopy(MARGIN))
    ]),
    wk.WIDGET: WidgetRow
}
FCM[wk.SUB][ok.COLOR_1][wk.VAL] = 0, 0, 0
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

GMR = {
    wk.SUB: OrderedDict([
        (ok.GRADIENT, deepcopy(GRADIENT)),
        (ok.MOD, deepcopy(MOD))
    ]),
    wk.WIDGET: WidgetRow
}
IDR = {
    wk.SUB: OrderedDict([
        (ok.INVERT, deepcopy(INVERT)),
        (ok.DESATURATE, deepcopy(DESATURATE)),
    ]),
    wk.WIDGET: WidgetRow
}
IMR = {
    wk.SUB: OrderedDict([
        (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (ok.MASK, deepcopy(MASK)),
    ]),
    wk.WIDGET: WidgetRow
}
IRM = {
    wk.SUB: OrderedDict([
        (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (ok.RESIZE, deepcopy(RESIZE)),
        (ok.MASK, deepcopy(MASK))
    ]),
    wk.WIDGET: WidgetRow
}

# Lead / Trail Row_____________________________________________________________
LTR = {
    wk.COLUMN_TEXT: "Lead / Trail Text",
    wk.SUB: OrderedDict([
        (ok.LEAD, deepcopy(TEXT)),
        (ok.TRAIL, deepcopy(TEXT)),
    ]),
    wk.WIDGET: WidgetRow
}
LTR[wk.SUB][ok.LEAD][wk.TOOLTIP] = Tip.LEAD
LTR[wk.SUB][ok.TRAIL][wk.TOOLTIP] = Tip.TRAIL
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

OCR = {
    wk.SUB: OrderedDict([
        (ok.OBEY_MARGINS, deepcopy(OBEY_MARGINS)),
        (ok.CLIP_TO_CELL, deepcopy(CLIP_TO_CELL)),
    ]),
    wk.WIDGET: WidgetRow
}
P3R = {
    wk.SUB: OrderedDict([
        (ok.PATTERN_1, deepcopy(PATTERN)),
        (ok.PATTERN_2, deepcopy(PATTERN)),
        (ok.PATTERN_3, deepcopy(PATTERN))
    ]),
    wk.WIDGET: WidgetRow
}
MAF = {
    wk.SUB: OrderedDict([
        (ok.MOD, deepcopy(MOD)),
        (ok.ADD, deepcopy(ADD)),
        (ok.FRAME, deepcopy(FRAME))
    ]),
    wk.WIDGET: WidgetRow
}
MBR = {
    wk.SUB: OrderedDict([
        (ok.MOD, deepcopy(MOD)),
        (ok.BUMP, deepcopy(BUMP)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}
