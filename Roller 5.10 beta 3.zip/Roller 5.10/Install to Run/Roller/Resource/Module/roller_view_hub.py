#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import atan2, ceil, degrees, sqrt
from random import uniform
from roller_a_contain import Cat, Run
from roller_constant_for import (
    Fill as fl, Frame as ff, Gradient as fg, Triangle as ft
)
from roller_constant_key import Option as ok
from roller_fu import (
    add_layer,
    blur_selection,
    clone_layer,
    copy_all_image,
    create_image,
    discard_mask,
    flip_layer,
    rotate_layer,
    select_polygon,
    set_saturation
)
from roller_fu_comm import info_msg
from roller_fu_mode import get_fill_mode
from roller_many_rect import Rect
from roller_one import seal
from roller_one_wip import Wip, get_factor_h, get_factor_w
from roller_polygon import calc_circumradius, calc_hexagon
import gimpfu as fu  # type: ignore

BAND = [1., 1., .0, .0]
pdb = fu.pdb

# Are function used by deco, backdrop style, and/or frame.


def add_text_layer(group, z, x, y):
    """
    Add a text layer to a group for Plan.

    group: layer
        parent

    z: layer
        to receive text

    x, y: numeric acting as integer
        topleft position
        coordinate
    """
    pdb.gimp_image_insert_layer(z.image, z, group, 0)
    pdb.gimp_text_layer_set_color(z, (255, 255, 255))
    pdb.gimp_layer_set_offsets(z, int(x), int(y))


def adjust_mean_value(z):
    """
    Adjust a layer's material so that it's mean
    intensity is within a theoretical bounds.

    z: layer
        work-in-progress
    """
    def _histogram():
        """
        Determine the mean intensity.

        Return: float
            mean intensity
        """
        # start range, '.0'; end range, '1.'
        return pdb.gimp_drawable_histogram(z, fu.HISTOGRAM_VALUE, .0, 1.)[0]

    def _curves():
        """
        Adjust the layer's middle range using the 'ratio'
        of the theoretical mean and the actual mean.
        """
        pdb.gimp_drawable_curves_spline(
            z,
            fu.HISTOGRAM_VALUE,
            8,                                              # coordinate count
            (.0, .0, .3, .3 * ratio, .7, .7 * ratio, 1., 1.)
        )

    # Curves won't work with a selection.
    pdb.gimp_selection_none(z.image)

    mean = _histogram()

    # If the layer is only black pixels, the mean will be zero.
    if mean:
        # Consider 3 classes of intensity.
        if mean < 85.:
            # theoretical 100
            theory = (128. + mean) / 2.

        elif mean > 170.:
            # theoretical 155
            theory = (127. + mean) / 2.

        else:
            # regular
            theory = 127.5

        mean_min = theory - 16.
        mean_max = theory + 16.

        # Adjust for minimum mean.
        if mean_min > mean != theory:
            ratio = theory / mean
            for i in range(10):
                _curves()
                mean = _histogram()
                if mean >= mean_min:
                    break
        # Adjust for maximum mean.
        if mean_max < mean != theory:
            ratio = theory / mean
            for i in range(10):
                _curves()
                mean = _histogram()
                if mean <= mean_max:
                    break


def brush_stroke(
    z,
    brush,
    brush_size,
    stroke,
    spacing,
    jitter,
    callback=None,
    hardness=1.,
    angle=.0
):
    """
    Brush stroke the path.

    z: layer
        to receive brush stroke
        Has a stroke-path.

    brush: string
        GIMP brush

    brush_size: float
        size of brush

    stroke: GIMP path
        Receive brush stroke.

    spacing: numeric
        distance between the strokes

    callback: function
        a callback for each brush stroke

    hardness: float
        .0 to 1.
        Feather the brush edge.

    angle: float
        Is the brush direction in degrees.
        -180. to 180.
    """
    def _calc_angle():
        """Modify the angle with the jitter value."""
        _angle = angle + uniform(-jitter, jitter)

        while _angle > 180.:
            _angle -= 180.

        while _angle < -180.:
            _angle += 180.
        return _angle

    def _calc_stroke_angle(_p1, _p2, _f):
        """
        Calculate the angle of the brush given the
        base angle and a point with a tangent.

        _p1, _p2: points
            Form a tangent.

        _f: float
            of brush
            base angle
        """
        _x, _y = _p1
        _x1, _y1 = _p2
        return (
            (_f + degrees(atan2(_y - _y1, _x - _x1))) % 360.
        ) - 180.

    def _get_end_tangent():
        """Compute the position of the end-point for a tangent."""
        _points = stroke.points[0]

        # end point
        _x, _y = _points[-4:-2]

        # start point
        _x1, _y1 = _points[-6:-4]

        if abs(_x - _x1) < .00001 and abs(_y - _y1) < .00001:
            _x1, _y1 = stroke.get_point_at_dist(
                stroke.get_length(.001) - .5, .01
            )[0:2]
        return _x1, _y1

    def _get_origin_tangent():
        """
        Compute the origin-point position of a tangent.

        Return: tuple
            origin point
            x, y
        """
        _points = stroke.points[0]

        # origin
        _x, _y = _points[2:4]

        # tangent
        _x1, _y1 = _points[4:6]

        if abs(_x - _x1) < .001 and abs(_y - _y1) < .001:
            _x1, _y1 = stroke.get_point_at_dist(.5, .01)[0:2]
        return _x1, _y1

    def _set_hardness():
        """Set the brush hardness."""
        pdb.gimp_context_set_brush_hardness(seal(hardness, .01, 1.))

    def _stroke(_q, _f):
        """
        Make a brush stroke.

        _q: list
            of points

        _f: float
            brush angle in degrees
        """
        if callback:
            callback()

        pdb.gimp_context_set_brush_angle(_f)

        # number of stroke points, '2'; strokes, '_q'
        pdb.gimp_paintbrush_default(z, 2, _q)

    pdb.gimp_selection_none(z.image)

    length = stroke.get_length(.1)
    points, is_closed = stroke.points
    intervals = round((length / spacing))

    if intervals:
        interval_length = length / intervals

        set_gimp_brush(brush)
        pdb.gimp_context_set_brush_size(brush_size)
        _set_hardness()

        # The first and last stroke are special.
        # first point
        _stroke(
            points[2:4],
            _calc_stroke_angle(
                points[2:4], _get_origin_tangent(), _calc_angle()
            )
        )

        for step in range(1, int(intervals)):
            x1, y1 = stroke.get_point_at_dist(
                step * interval_length, .1
            )[0:2]
            x2, y2 = stroke.get_point_at_dist(
                .5 + step * interval_length, .1
            )[0:2]
            _stroke(
                (x1, y1),
                _calc_stroke_angle(
                    (x1, y1), (x2, y2), _calc_angle()
                )
            )

        # last point
        if not is_closed:
            _stroke(
                points[-4:-2],
                _calc_stroke_angle(
                    _get_end_tangent(), points[-4:-2], _calc_angle()
                )
            )


def calc_band_profile(w):
    """
    Calculate a Band profile which is made of minimum and maximum values.

    w: float
        length of profile

    Return: list
        the profile
    """
    w, a = divmod(int(w), 4)
    return BAND * w + BAND[:a]


def calc_bevel_profile(w):
    """
    Calculate a 45 degree Bevel profile.

    w: float
        width of the bevel

    Return: list
        the profile
        in .0 to 1.
    """
    # the y-axis values, 'q'
    # The y value is useful for adjusting a
    # color's lightness, value, or other property.
    q = []

    # the value to increment 'x', 'f'
    # the y mid-point, '.5'
    f = 1. if w == 1. else 2. / w
    x = f / 2.

    for i in range(int(w)):
        if x < 1.:
            q += [x]

        else:
            q += [1. - (x - 1.)]
        x += f
    return q


def calc_gradient(color, color1, steps):
    """
    Calculate the color-steps for a gradient. A color-step
    is a value that is added to one color's components in
    order for the color to become the second color.
    Each RGB color component will have its own color-step value.

    color, color1: tuple
        RGB
        int

    steps: float
        the number of steps

    Return: list
        [step value for each color component in RGB or RGBA]
    """
    # the number of color components, 'w'
    # Is three for RGB and four for RGBA.
    w = len(color)

    step = [0] * w

    # Need the color distance to calculate a color step.
    if steps > 1.:
        for x in range(w):
            step[x] = (color1[x] - color[x]) / (steps - 1.)
    return step


def calc_raise_profile(w):
    """
    Calculate a Raise profile.

    w: float
        width of profile or frame

    Return: list
        profile
        in .0 to 1.
    """
    q = []
    f = 1. / w
    x = 1. - f / 2.

    for i in range(int(w)):
        q += [x]
        x -= f
    return q


def calc_rotated_image_span(w, h):
    """
    Calculate the size of an image span where each side has equal length.

    w, h: numeric
        rectangle size

    Return: int
        size of image side
    """
    return int(ceil(calc_circumradius(w, h)) * 2.)


def calc_round_profile(w):
    """
    Calculate a Round profile using the unit circle
    formula given the width of the profile.

    w: float
        width of profile or frame

    Return: list
        of profile
        in .0 to 1.
    """
    # the y-axis values, 'q'
    # The y value is useful for adjusting a
    # color's lightness, value, or other property.
    q = []

    # the value to increment 'x', 'f'
    # the range of x from -1 to 1, '2.'
    # 'w + 5.' produces the mid-point on the y-axis, '.5'.
    f = 2. / (w + 5.) if w == 1. else 2. / w

    # 'x' is given a mid-value between the zero increment and its first.
    x = -1. + f / 2.

    for i in range(int(w)):
        q += [sqrt(1. - x**2.)]
        x += f
    return q


def calc_sink_profile(w):
    """
    Calculate a Sink profile.

    w: float
        width of profile or frame

    Return: list
        of profile
        in .0 to 1.
    """
    q = []
    f = 1. / w
    x = f / 2.

    for i in range(int(w)):
        q += [x]
        x += f
    return q


def clipboard_fill(z):
    """
    Fill a layer with a Clipboard Image pattern.

    z: layer
        Fill.
    """
    pdb.gimp_context_set_pattern("Clipboard Image")
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, .0, .0)


def clipboard_fill_arg(*q):
    """
    Fill a layer with a Clipboard Image pattern.

    q: tuple
        (layer, not used)

    Return: layer
        for calling function
    """
    z = q[0]

    pdb.gimp_context_set_pattern("Clipboard Image")
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, .0, .0)
    return z


def clipboard_fill_default(z):
    """
    Fill a layer with a Clipboard Image pattern.

    z: layer
        Fill.
    """
    set_fill_context_default()
    pdb.gimp_context_set_pattern("Clipboard Image")
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, .0, .0)


def color_layer(z, q):
    """
    Fill a layer with a color.

    z: layer
        Receive color.

    q: tuple
        RGB color
    """
    pdb.gimp_selection_all(z.image)
    color_selection(z, q)


def color_layer_default(z, q):
    """
    Fill a layer with a color.

    z: layer
        Receive color.

    q: tuple
        RGB color
    """
    pdb.gimp_selection_all(z.image)
    color_selection_default(z, q)


def color_selection(z, q):
    """
    Fill a layer's selection with a color. Is context sensitive.

    z: layer
        to apply fill

    q: tuple
        RGB or RGBA color

    opacity: float
        of the color
    """
    if len(q) != 4:
        # RGB
        opacity = 100.

    else:
        # RGBA
        opacity = round(q[3] / 255. * 100., 1)

    pdb.gimp_context_set_background(q)
    pdb.gimp_edit_bucket_fill(
        z,
        fu.BACKGROUND_FILL,
        fu.LAYER_MODE_NORMAL,
        opacity,
        1.,                     # threshold all
        0,                      # no sample merge
        .0, .0                  # x, y fill point
    )


def color_selection_default(z, q):
    """
    Fill a selection with color. Use the default context.

    z: layer
        Receive color.

    q: tuple
        RGB color
    """
    set_fill_context_default()
    color_selection(z, q)


def create_dual_gradient(n, left_color, right_color):
    """
    Create a GIMP gradient using two colors. The gradient has
    one segment and the two color occupy the ends of this segment.
    The opacity of the gradient is 100%.

    n: string
        Is the proposed name of the gradient.

    left_color: tuple
        RGB

    right_color: tuple
        RGB

    Return: string
        name of the new gradient
    """
    grad = pdb.gimp_gradient_new(n)

    Cat.gradient_list.append(grad)

    # segment index, '0'; end point opacity, '100.'
    pdb.gimp_gradient_segment_set_left_color(grad, 0, left_color, 100.)
    pdb.gimp_gradient_segment_set_right_color(grad, 0, right_color, 100.)

    return grad


def do_curves(z, q):
    """
    Execute GIMP's curve function to alter a layer's
    histogram value. Remove an existing selection.

    z: layer
        Modify with curves.

    q: iterable
        (input float, output float, ...) series
        The input and output range is from .0 to 1.0.
    """
    # Curves won't work with a selection.
    pdb.gimp_selection_none(z.image)

    pdb.gimp_drawable_curves_spline(z, fu.HISTOGRAM_VALUE, len(q), q)


def do_gradient_job(z, d):
    """
    Draw a gradient.

    z: layer
        Receive gradient.

    d: dict
        GradientFill Preset

    Return: layer
        Has gradient applied.
    """
    j = z.image
    x, y, x1, y1 = get_canvas_points(d)

    if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
        pdb.gimp_selection_all(j)
    return draw_gradient(z, d, x, y, x1, y1)


def do_mod(z, d):
    """
    Modify a layer Mod Preset settings.

    z: layer
        Modify.

    d: dict
        Mod Preset

    Return: layer
        Modified.
    """
    def _set_brightness(_f):
        """
        Alter a layer's lightness with curves.

        f: float
            -100. to 100.0
            black to white
        """
        if _f:
            if _f < .0:
                black = .0
                white = 1. + (_f / 100.)

            else:
                black = _f / 100.
                white = 1.
            do_curves(z, (.0, black, 1., white))

    if d[ok.SWITCH]:
        pdb.gimp_selection_none(z.image)

        m = Run.x

        if m and d[ok.INVERT]:
            # no linear, '0'
            pdb.gimp_drawable_invert(z, 0)

        if d[ok.FLIP_H]:
            flip_layer(z, is_h=True)

        if d[ok.FLIP_V]:
            # vertical flip
            flip_layer(z)
        if m:
            set_saturation(z, d)
            _set_brightness(d[ok.BRIGHTNESS])
            blur_selection(z, d[ok.BLUR])
    return z


def do_rotated_image(d, p):
    """
    Create an square-sized layer when rotating.
    Use a callback to process the work-in-progress layer.

    d: dict
        Has option.

    p: callback
        Call to act on the rotated layer before it is returned.

    Return: GIMP image
        with processed layer
    """
    w, h = Wip.size

    if d[ok.ANGLE]:
        # Create a new image for the rotation.
        w = h = calc_rotated_image_span(w, h)

    j = create_image(int(w), int(h))
    z = add_layer(j, "Process")
    z = p(z, d)

    if d[ok.ANGLE]:
        rotate_layer(z, d[ok.ANGLE])
    return j


def draw_gradient(z, d, x, y, x1, y1):
    """
    Paint a gradient.

    z: layer
        to receive gradient

    d: dict
        Gradient Fill Preset

    x, y: float
        start point

    x1, y1: float
        end point

    Return: layer
        with gradient material
    """
    set_fill_context_default()
    pdb.gimp_context_set_gradient_blend_color_space(
        fu.GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    set_gimp_gradient(d)
    pdb.gimp_context_set_gradient_reverse(d[ok.REVERSE])
    pdb.gimp_drawable_edit_gradient_fill(
        z,
        fg.GRADIENT_TYPE_LIST.index(d[ok.GRADIENT_TYPE]),
        d[ok.OFFSET],
        1,                                  # yes, do super-sample
        3,                                  # max depth
        .06,                                # super-sample threshold
        1,                                  # yes, dither
        x, y,
        x1, y1
    )
    return z


def get_mean_color(z):
    """
    Use GIMP's histogram function to collect the mean value
    of the red, green, and blue channels. If there's
    a selection, the selected material is sampled.

    Return: tuple
        RGB
    """
    q = ()

    # (r, g, b) where each value is .0 to 255.
    for i in (1, 2, 3):
        q += (int(pdb.gimp_drawable_histogram(z, i, .0, 1.)[0]),)
    return q


def get_canvas_points(d):
    """
    Return layer points for start and end coordinates in the WIP context.

    d: dict
        Has start and end points.
        Has fixed and factored layer point tuples.

    return:
        start and end coordinates
        x, y, x1, y1
    """
    # Add fixed and factored values.
    x = get_factor_w(d[ok.START_X])
    y = get_factor_h(d[ok.START_Y])

    # ColorFIll doesn't use end points.
    if ok.END_X in d:
        x1 = get_factor_w(d[ok.END_X])
        y1 = get_factor_h(d[ok.END_Y])

    else:
        x1 = y1 = .0
    return x, y, x1, y1


def get_gradient_factors(d):
    """
    Get the factor points for a gradient
    given a gradient angle descriptor.

    The returned factor values are multiplied by a
    scale variable to arrive at an x, y point
    that is then used to plot a gradient direction.

    d: dict
        Has a gradient angle Option key.

    Return: tuple
        of float
        start x, end x, start y, end y
        in .0 to 1.
    """
    n = d[ok.GRADIENT_ANGLE]

    if n in fg.GRADIENT_XY:
        return fg.GRADIENT_XY[n]

    # shape-burst
    return .5, .5, .5, .5


def get_gradient_points(d, x, y, w, h):
    """
    Calculate the start and end coordinates for a gradient.
    Use with a gradient angle descriptor to find the points
    on the edge of a rectangle.

    d: dict
        Has a gradient angle Option key.

    x, y: numeric
        topleft gradient space offset

    w, h: numeric
        size of the gradient's space

    Return: tuple
        of float
        start x, end x, start y, end y
        in 0. to n
    """
    start_x, end_x, start_y, end_y = get_gradient_factors(d)
    start_x = x + start_x * w
    end_x = x + end_x * w
    start_y = y + start_y * h
    end_y = y + end_y * h
    return start_x, end_x, start_y, end_y


def invert_color(q):
    """
    Calculate an inverted color.

    q: tuple
        RGB or RGBA

    Return: tuple
        RGB or RGBA
        the inverted color
    """
    if len(q) == 3:
        # RGB
        return tuple([255 - i for i in q])

    # RGBA
    return tuple([255 - i for i in q[:3]]) + (q[3],)


def make_cube_pattern(fixed_h, colors):
    """
    Make a cube tile pattern with three shades applied to the visible
    sides. In order to create the shaded sides, two of the
    sides need to be filled with a unique shade. The side
    that forms the top of the cube is made from the background
    color. The shaded sides are first selected then filled.
    Is context sensitive.

    fixed_h: float
        height of pattern

    colors: tuple
        of RGB or RGBA

    Return: clipboard buffer
        pattern
    """
    tile_w = fixed_h * ft.SCALE_DOWN

    # size of the topleft cube, 'w, h'
    w, h = tile_w / 2., fixed_h / 2.

    # a tuple of six points, 12 values, making up a hexagon,
    # connected clockwise, and starting from the topleft point, 'q'
    q = calc_hexagon(Rect(.0, .0, w, h))

    # at the left hexagon's, 'center...'
    center_x, center_y = q[2], q[9] / 2.

    # below the top hexagons, 'y1, y2'
    y1 = q[9] + q[5]
    tile_h = q[9] + center_y

    # for the right hexagon
    center_x2 = center_x + q[4]

    # Create the tile from a new image that doesn't get displayed.
    j1 = create_image(int(tile_w), int(tile_h))

    pattern_layer = add_layer(j1, "Pattern")

    # make a fill all?
    color_layer(pattern_layer, colors[0])

    # Start the right side selections.
    pdb.gimp_selection_none(j1)

    # The polygon points are connected in a clockwise rotation.
    right_poly = (
        (.0, .0, q[2], q[3], q[0], q[1]),
        (q[4], .0, q[4] + q[2], .0, q[4], q[1]),
        (center_x, center_y, q[4], q[5], q[6], q[7], q[8], q[9]),
        (center_x2, center_y, tile_w, q[5], tile_w, q[7], center_x2, q[9]),
        (.0, y1, q[2], q[9], q[2], tile_h, .0, tile_h),
        (q[4], y1, center_x2, q[9], center_x2, tile_h, q[4], tile_h)
    )

    for q1 in right_poly:
        select_polygon(j1, q1, option=fu.CHANNEL_OP_ADD)

    # Fill the right side.
    color_selection(pattern_layer, colors[1])

    # Start the left side selections.
    pdb.gimp_selection_none(j1)

    # The polygon points are connected in a clockwise rotation.
    left_poly = (
        (q[2], .0, q[4], .0, q[4], q[5]),
        (q[4] + q[2], .0, tile_w, .0, tile_w, q[5]),
        (.0, q[1], center_x, center_y, q[2], q[9], .0, q[11]),
        (q[4], q[1], center_x2, center_y, center_x2, q[9], q[4], q[11]),
        (q[2], q[9], q[4], y1, q[4], tile_h, q[2], tile_h),
        (center_x2, q[9], tile_w, y1, tile_w, tile_h, center_x2, tile_h)
    )

    for q1 in left_poly:
        select_polygon(j1, q1, option=fu.CHANNEL_OP_ADD)

    # Fill the left side.
    color_selection(pattern_layer, colors[2])

    # Set the Clipboard Image for the pattern fill op.
    copy_all_image(j1)

    # Close the tile image as the pattern is done.
    pdb.gimp_image_delete(j1)


def make_polar_mask(z, is_dark=False):
    """
    Create a dark or light mask.

    is_dark: bool
        If it's True, the group is for the dark-type masks.

    Return: layer
        with a polarized mask
    """
    z = clone_layer(z, n="Dark" if is_dark else "Lights")

    discard_mask(z)

    if is_dark:
        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)

    mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_COPY)

    pdb.gimp_layer_add_mask(z, mask)
    return z


def make_plan_text_layer(j, n, font_size):
    """
    Create a new text layer.

    j: GIMP image
        WIP

    n: string
        text to display

    font_size: float
        scale of font

    Return: layer
        with text
    """
    return pdb.gimp_text_layer_new(
        j, n, 'Sans-serif', font_size, fu.PIXELS
    )


def prep_brush():
    """Set default brush context for drawing line."""
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_context_set_brush_angle(.0)
    pdb.gimp_context_set_brush_hardness(.95)
    pdb.gimp_context_set_opacity(100.)


def prep_replace_color_default():
    """Set GIMP context for default color selection and selection fill."""
    pdb.gimp_context_set_feather(0)
    pdb.gimp_context_set_opacity(100.)
    pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
    pdb.gimp_context_set_sample_criterion(0)
    pdb.gimp_context_set_sample_threshold(1.)


def set_draw_line_brush():
    """Consistently use the same brush for drawing line."""
    set_gimp_brush("C_Normal Brush 80")


def set_fill_context(d):
    """
    Set the context for a fill-type operation.
    Call before actualizing a bucket fill operation.

    d: dict
        Has fill options.
    """
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_context_set_opacity(d[ok.FILL_OPACITY])
    pdb.gimp_context_set_paint_mode(get_fill_mode(d))
    pdb.gimp_context_set_sample_criterion(
        fl.CRITERION_LIST.index(d[ok.CRITERION])
    )
    pdb.gimp_context_set_sample_threshold(d[ok.THRESHOLD])


def set_fill_context_default():
    """Use a default fill dict to init fill context."""
    set_fill_context({
        ok.THRESHOLD: 1.,                   # Match all.
        ok.CRITERION: fl.COMPOSITE,
        ok.FILL_MODE: "Normal",
        ok.FILL_OPACITY: 100.
    })


def set_gimp_brush(n):
    """
    Set the brush for a brush-stroke operation. Make sure the brush exists.

    n: string
        GIMP brush descriptor
    """
    q = Cat.brush_list

    if n not in q:
        info_msg("A brush was not found: " + repr(n))
        n = q[0] if q else None
    if n is not None:
        pdb.gimp_context_set_brush(n)


def set_gimp_gradient(d):
    """
    Set the gradient for a gradient fill
    operation. Make sure the gradient exists.

    d: dict
        Has a gradient option.
    """
    n = d[ok.GRADIENT]
    q = Cat.gradient_list

    # Set FG and BG color.
    pdb.gimp_context_set_background(Cat.background)
    pdb.gimp_context_set_foreground(Cat.foreground)

    if n not in q:
        info_msg("A gradient was not found: " + repr(n))
        n = q[0] if q else None
    if n is not None:
        pdb.gimp_context_set_gradient(n)


def set_gimp_pattern(n):
    """
    Set the pattern for a pattern fill
    operation. Make sure the pattern exists.

    n: string
        a pattern description
    """
    q = Cat.pattern_list

    if n not in q:
        info_msg("A pattern was not found: " + repr(n))
        n = q[0] if q else None
    if n is not None:
        pdb.gimp_context_set_pattern(n)


# {profile type: function to calculate its profile}
ROUTE_PROFILE = {
    ff.BAND: calc_band_profile,
    ff.BEVEL: calc_bevel_profile,
    ff.ROUND: calc_round_profile,
    ff.RAISE: calc_raise_profile,
    ff.SINK: calc_sink_profile
}
