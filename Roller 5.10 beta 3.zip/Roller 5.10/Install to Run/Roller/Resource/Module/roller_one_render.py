#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Globe, PlanZ, Run
from roller_constant_for import Signal as si
import gimpfu as fu  # type: ignore
import gobject       # type: ignore

pdb = fu.pdb


class Render(gobject.GObject, object):
    """Use to create and change the render image."""
    __gsignals__ = si.IMAGE_D
    _display = None

    # for Signal processing
    gob = None

    def __init__(self):
        """Init for a new View image."""
        gobject.GObject.__init__(self)
        Render.gob = self

    @staticmethod
    def new_image(w, h):
        """
        Get the View's image. If it doesn't exist, then create one first.

        w, h: numeric
            new image size
        """
        # Is manipulated by Work's and Plan's 'do' function, 'is_frozen'.
        m = Run.is_frozen

        if Run.j:
            PlanZ.plan_group = None

            # The View image is the wrong size.
            Render.gob.emit(si.CLOSE_VIEW_IMAGE, Run.j)

            if m:
                # the image needs to be thawed in order to keep the balance.
                pdb.gimp_image_thaw_layers(Run.j)
            pdb.gimp_display_delete(Render._display)

        Run.j = pdb.gimp_image_new(int(w), int(h), fu.RGB)

        # Show in GIMP:
        Render._display = pdb.gimp_display_new(Run.j)

        if m:
            # Reproduce the frozen state of the previous image.
            pdb.gimp_image_freeze_layers(Run.j)

        # Turn off undo functionality to save
        # memory and to improve performance.
        pdb.gimp_image_undo_disable(Run.j)

    @staticmethod
    def provide():
        """
        Get the View's image. If it doesn't exist, then create it.

        Return: GIMP image
            Is from a View op or a new image made due to a size change.
        """
        if not Run.j:
            Render.new_image(*Globe.view_size)
        return Run.j


if not Render.gob:
    Render()

# Register the custom signals.
gobject.type_register(Render)
