#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Dog, The
from roller_constant_for import Color as co, Signal as si
from roller_constant_key import Option as ok, Step as sk, Widget as wk
from roller_model_id import ModelId
from roller_model_nexus import CLASS_MODEL
from roller_one import reduce_color
from roller_one_extract import get_model_name_list
from roller_one_helm import Helm
from roller_one_ring import Ring
from roller_one_shelf import Shelf
from roller_option_squish import hide_option
from roller_port_tree import create_steps_insert_d
from roller_view_step import (
    get_parent_node, make_panel_key, make_nav_key, get_model
)
from roller_widget_box import Eventful
from roller_widget_node import Item
import gtk  # type: ignore


def remove_empty_node():
    """Remove Node that have no item/label."""
    for i in Helm.get_all_step_q():
        # AnyGroup, 'a'
        a = Helm.get_group(i)
        if a and a.item.group_type == 'node':
            if not a.widget_d[ok.NODE].get_label_q():
                # It's useless.
                remove_node(i)


def remove_item(node, item):
    """
    Remove an item from a Node. Move its AnyGroup value from the
    step dict to the offline dict. Recursively remove empty Node.

    node: Node
        parent with Item

    item: Item
        Remove from list.
    """
    k = item.any_group.nav_k
    if node:
        node.remove_named_item(item.item)
        shelve_group(k)
        Ring.plug(si.PANEL_CHANGE, None)
        if not node.get_label_q():
            node = get_parent_node(k[:-1])
            item = node.get_named_item(k[-2])
            # Is it still around?
            if item:
                remove_item(node, item)


def remove_node(nav_k):
    """
    Remove a Node from the interface. First,
    the type of the step key is determined, then if the
    type is a Node, and it has no branches, remove the Node.

    key: tuple
        (Model name, ...)
    """
    any_group = Helm.get_group(nav_k)
    if any_group:
        if any_group.item.group_type == 'node':
            remove_item(get_parent_node(nav_k), any_group.item)


def remove_non_node(nav_k):
    """
    Remove a non-Node Widget AnyGroup from the interface. First,
    the type of the step key is determined, then if the
    type is not a Node, the item is removed.

    key: tuple
        (Model name, ...)

    Return: bool
        Is True if the the item was removed.
    """
    any_group = Helm.get_group(nav_k)

    if any_group:
        if any_group.item.group_type != 'node':
            remove_item(get_parent_node(nav_k), any_group.item)
            return True
    return False


def shelve_group(nav_k):
    """
    Move a step and its value dict from the Helm to the Shelf.
    This happens when the user has modified the navigation tree.
    """
    any_group = Helm.get_group(nav_k)

    if any_group and any_group.item.group_type == 'preset':
        Shelf.set_step(make_panel_key(nav_k), any_group.value_d)
        Helm.remove_step(nav_k)
        any_group.emit(si.DISAPPEAR, None)

    elif any_group and any_group.item.group_type in ('node', 'super_preset'):
        # Nothing to shelve.
        Helm.remove_step(nav_k)
        any_group.emit(si.DISAPPEAR, None)
    if len(nav_k) == 1 and isinstance(nav_k[0], int):
        # Remove Model.
        ModelId.delete_with_id(nav_k[0])
        Helm.remove_step(nav_k)
        any_group.item.model.die()


# Is a new style class reference for Python 2.7, 'object'.
class NodePanel(gtk.HBox, object):
    """
    Is a gtk.HBox container row with a column of VBox, 'cubby'.
    A cubby is a host for container sharing via a VBox swap operation.
    Has a navigation tree with a Node trunk,
    an item branch, and an AnyGroup leaf.
    """
    _color = co.INIT_COLOR
    colors = []

    # Calculate a background color gradient.
    # number of cubby allocated, '7'
    for i in range(7):
        colors += [_color]
        _color = reduce_color(_color)

    def __init__(self, d, on_change):
        """
        Create an HBox.

        d: dict
            Has init option for Widget.

        on_change: function
            Except for Node, is the initial on
            change function for AnyGroup init.
        """
        self.cubby_q = []
        self.first_node = None
        self._option_d = d
        self._on_change = on_change
        self.roller_win = d[wk.ROLLER_WIN]
        super(gtk.HBox, self).__init__()

    def add_cubby(self):
        """
        Add a VBox to the HBox row.

        Return: GTK VBox
            new cubby
        """
        box = Eventful(NodePanel.colors[len(self.cubby_q)])
        vbox = gtk.VBox()
        self.cubby_q += [vbox]

        box.add(vbox)
        self.add(box)

        # The default behavior of the 'add' function
        # doesn't guarantee that a box is visible.
        box.show()
        vbox.show()
        return vbox

    def add_item(self, _, arg):
        """
        Add an item to the NodePanel via a custom NodePanel signal.

        _: Node
            Sent the Signal.

        arg: tuple
            (tree dict, panel step key)
            (Insert Model dictionary, (model name,))
        """
        # Delay change vote emission.
        The.load_count += 1

        self._option_d[wk.IS_DEFAULT] = True
        tree_d, key = arg

        self.make_branch(tree_d, key, sk.STEPS, 4, 1)

        # End delay.
        The.load_count -= 1

    def create_node(self, tree_d, key, panel_key, row, column):
        """
        Create a Node AnyGroup. Is recursive with
        'self.make_branch' when growing the navigation tree.

        tree_d: dict
            Define a navigation tree.

        key: string
            Group or Node key
            Model name

        panel_key: tuple
            (item, ...)
            Where item is a Node item.

        row: int or None
            insertion index into a parent Node

        column: int
            0 to 6
            index to 'cubby'
        """
        k = key if panel_key else ()
        nav_k = make_nav_key(panel_key)
        d = tree_d[k][wk.ITEM]
        cubby = self.get_cubby(column)
        item = Item(key, get_model(nav_k), 'node')

        if not cubby.get_children():
            cubby.add(item.vbox)

        if row is not None:
            node = get_parent_node(nav_k)
            node.insert_r(row, item)

        e = {
            wk.COLUMN: column,
            wk.IS_DEFAULT: False,
            wk.ITEM: item,
            wk.RELAY: [self.on_node_change],
            wk.ROLLER_WIN: self.roller_win,
            wk.NAV_K: nav_k,
            wk.TREE_COLOR: NodePanel.colors[column]
        }
        item.any_group = Dog.loner_group(**e)
        item.node = item.any_group.widget_d[ok.NODE]

        if column == 0:
            self.first_node = item.node

        item.node.connect(si.ADD_ITEM, self.add_item)
        item.node.connect(si.UPDATE_TREE, self.update_tree)
        Ring.plug(si.PANEL_CHANGE, None)
        for row, i in enumerate(d.keys()):
            self.make_branch(d, i, panel_key, row, column + 1)

    def get_cubby(self, column):
        """
        Fetch the VBox for a column.

        column: int
            0 to 6

        Return: VBox or None
            the cubby
        """
        if column < len(self.cubby_q):
            return self.cubby_q[column]

        # Make a cubby for the next column.
        return self.add_cubby()

    def make_branch(self, tree_d, key, panel_key, row, column):
        """
        From a Node item make its branch. Is recursive with 'self.create_node'.

        tree_d: dict or None
            Define a navigation tree.

        key: string
            Group, Model, or Node key

        panel_key: tuple
            key for a Node containing the item
            (item, ...); Its Model reference is the Model's name.

        row: int
            insertion index into a Node

        column: int
            index to the NodePanel cubby
            0 to 6
        """
        panel_key += (key.split(",")[0],)
        nav_k = make_nav_key(panel_key)
        group_type = tree_d[key][wk.WIDGET]
        any_group = Helm.get_group(nav_k)

        if any_group:
            node = get_parent_node(nav_k)
            item = node.get_named_item(panel_key[-1])

            if not item:
                node.insert_r(row, any_group.item)
            if group_type == 'node':
                self.update_node(tree_d, key, panel_key, column)
        else:
            if group_type == 'node':
                self.create_node(tree_d, key, panel_key, row, column)
            else:
                item = Item(
                    key,
                    get_model(nav_k),
                    group_type,
                    has_switch=wk.HAS_SWITCH in tree_d[key]
                )
                node = get_parent_node(nav_k)

                node.insert_r(row, item)

                d = {
                    wk.COLOR: NodePanel.colors[column],
                    wk.IS_DEFAULT: True,
                    wk.ITEM: item,
                    wk.RELAY: [self._on_change],
                    wk.NAV_K: nav_k,
                    wk.TREE_COLOR: NodePanel.colors[column]
                }

                d.update(self._option_d)
                d.update(tree_d[item.key])
                d.pop(wk.WIDGET)

                if key in Dog.class_group:
                    item.any_group = Dog.class_group[key](**d)
                    Ring.plug(si.PANEL_CHANGE, None)
                else:
                    # SuperPreset
                    item.any_group = Dog.many_group(**d)
                    Ring.plug(si.PANEL_CHANGE, None)

    def on_node_change(self, g):
        """
        Respond when the selection changes in a Node item
        list. Is a signal handler for a TreeViewList.

        g: Node or TreeViewList
            Is responsible.
        """
        def _remove():
            """
            Remove option groups with two columns or more into
            the navigation box from the current column.
            """
            _column = len(self.cubby_q)
            _a = g.column + 2
            if _a < _column:
                # VBox, '_i'
                for _i in range(_a, _column):
                    # VBox, '_j'
                    for _j in self.cubby_q[_i].get_children():
                        self.cubby_q[_i].remove(_j)

        # the selected branch Item, 'item'
        item = g.get_branch(g.get_sel_row())

        # Prevent a critical error from a failed state.
        if item:
            # A cubby is a parent GTK VBox with switchable children.
            cubby = self.get_cubby(g.column + 1)

            # Switch off.
            if not item.node:
                _remove()

            # Switch off.
            for child in cubby.get_children():
                if child != item.vbox:
                    cubby.remove(child)

            # Switch on.
            if not item.vbox.parent:
                cubby.add(item.vbox)

            item.vbox.set_visible(1)
            item.vbox.show_all()

            if not item.node and item.any_group.is_squish:
                # Squish the Widgets from here for less flicker.
                hide_option(item.any_group)

            if item.node:
                self.on_node_change(item.node)

            self.roller_win.resize()
            Ring.plug(si.UI_CHANGE, g)

    def update_node(self, tree_d, key, panel_key, column):
        """
        Update the navigation tree from a Node.

        tree_d: dict
            Define a navigation tree.

        key: string
            Group, Model, or Node key

        panel_key: tuple
            (item, ...), and (Model name, item, ...)
            Where item is a Node item and Model is identified by its name.

        column: int
            0 to 6
            index to 'cubby'
        """
        d = tree_d[key][wk.ITEM]
        for row, k in enumerate(d.keys()):
            self.make_branch(d, k, panel_key, row, column + 1)

    def update_tree(self, _, arg):
        """
        Respond to a navigation tree structure update signal.
        Remove item and Node from the tree that are no longer used. Add
        new item and Node to the tree from a new panel step key list.

        _: Node
            Sent the Signal.

        arg: tuple
            ([new panel key], [(model name, model type)])
        """
        # Delay change vote emission.
        The.load_count += 1

        new_step_q, model_def = arg
        old_step_q = [make_panel_key(i) for i in Helm.get_all_step_q()]

        # Make a removed step key list by comparing the
        # old step key list with the new step key list.
        remove_q = [
            make_nav_key(i)
            for i in old_step_q
            if i not in new_step_q
        ]

        for i in remove_q[:]:
            if remove_non_node(i):
                remove_q.pop(remove_q.index(i))

        for i in remove_q:
            # If a Node item is not in the step list, then it's not used.
            if not any([i1 for i1 in new_step_q if i in i1]):
                remove_node(i)

        if new_step_q:
            name_q = get_model_name_list()

            for model_name, model_type in model_def:
                if model_name not in name_q:
                    CLASS_MODEL[model_type](model_name)

            d = create_steps_insert_d(new_step_q, model_def)
            self.update_node(d, sk.STEPS, sk.STEPS, 0)

        remove_empty_node()
        The.load_count -= 1
