#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run, The
from roller_constant_key import Group as gk, Option as ok
from roller_fu import (
    add_layer,
    clone_layer,
    invert_selection,
    make_layer_group,
    select_item,
    verify_layer,
    verify_layer_group
)
from roller_fu_mode import get_mode
from roller_view_real import clip_to_wip
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def do_stylish_shadow(
    z, blur=15., intensity=130., offset_x=.0, offset_y=.0, is_inner=False
):
    """
    Create a shadow layer.

    z: layer
        shadow caster

    blur: float
        shadow blur

    intensity: float
        shadow opacity
        .0 to 1000.

    offset_x: float
        shadow offset on x-axis (-, +)

    offset_y: float
        shadow offset on y-axis (-, +)

    is_inner: flag
        If True, the shadow is an Inner Shadow type.

    Return: layer
        the shadow layer
    """
    parent = z.parent

    if is_inner:
        d = The.preset.get_default_value(gk.INNER_SHADOW)
        p = make_shadow_inner
        arg = d, parent, z

    else:
        d = The.preset.get_default_value(gk.SHADOW_1)
        p = make_shadow
        arg = d, parent, [z]

    d[ok.BLUR] = blur
    d[ok.INTENSITY] = intensity
    d[ok.OFFSET_X] = offset_x
    d[ok.OFFSET_Y] = offset_y
    return p(*arg, name="Shadow")


def make_shadow(d, parent, cast_q, name=None):
    """
    Make a shadow.

    d: dict
        Shadow Preset
        {Option key: value}

    parent: layer group
        Has name and position.

    cast_q: tuple or list
        of layer to cast shadow

    name: string or None
        Use to name the output layer.

    Return: layer
        with shadow
    """
    intensity = d[ok.INTENSITY]
    if cast_q and intensity:
        j = Run.j
        group = make_layer_group(j, "Shadow")
        base_z = add_layer(j, 'Temp', parent=group)

        pdb.gimp_selection_none(j)

        for z in cast_q:
            select_item(z, option=fu.CHANNEL_OP_ADD)

        if not pdb.gimp_selection_is_empty(j):
            if intensity > 100.:
                layer_count = intensity // 100.
                intensity = intensity / (layer_count + 1)

            else:
                layer_count = 0

            # base layer for shadow output, 'z1'
            # Make shadow from selection.
            pdb.script_fu_drop_shadow(
                j, base_z,
                d[ok.OFFSET_X], d[ok.OFFSET_Y],
                d[ok.BLUR],
                d[ok.COLOR_1],
                intensity,
                0                       # no resizing
            )
            if layer_count:
                # Increase shadow intensity by
                # stacking duplicate shadow layers.
                z = group.layers[0]
                for i in range(int(layer_count)):
                    z = clone_layer(z)

        pdb.gimp_selection_none(j)

        z = verify_layer_group(group)

        if z:
            z.mode = get_mode(d)

            pdb.gimp_image_reorder_item(j, z, parent, 0)

            if name is not None:
                z.name = name
            clip_to_wip(z)
        return z


def make_shadow_inner(d, parent, cast_z, name=None):
    """
    Make an inner shadow.

    d: dict
        Shadow Preset
        {Option key: value}

    parent: layer group
        Has name and position.

    cast_z: layer or None
        Cast Inner Shadow with this layer.

    name: string or None
        Use to name the output layer.

    Return: layer
        with shadow
    """
    intensity = d[ok.INTENSITY]

    if cast_z and intensity:
        j = Run.j
        group = make_layer_group(j, "Shadow")
        base_z = add_layer(j, 'Temp', parent=group)

        select_item(cast_z)
        invert_selection(j)

        if not pdb.gimp_selection_is_empty(j):
            if intensity > 100.:
                layer_count = intensity // 100.
                intensity = intensity / (layer_count + 1)

            else:
                layer_count = 0

            # base layer for shadow output, 'z1'
            # Make shadow from selection.
            pdb.script_fu_drop_shadow(
                j, base_z,
                d[ok.OFFSET_X], d[ok.OFFSET_Y],
                d[ok.BLUR],
                d[ok.COLOR_1],
                intensity,
                0                       # no resizing
            )
            if layer_count:
                # Increase shadow intensity by
                # stacking duplicate shadow layers.
                z = group.layers[0]
                for i in range(int(layer_count)):
                    z = clone_layer(z)

        pdb.gimp_image_remove_layer(j, base_z)
        pdb.gimp_selection_none(j)

        z = verify_layer(pdb.gimp_image_merge_layer_group(j, group))

        if z:
            z.mode = get_mode(d)

            pdb.gimp_image_reorder_item(j, z, parent, 0)

            if name is not None:
                z.name = name
            clip_to_wip(z)
        return z


def make_inner_shadow_overlay(d, parent, cast_q, name):
    """
    Make an inner shadow.

    d: dict
        Shadow Preset
        {Option key: value}

    parent: layer group
        Has name and position.

    cast_q: list
        [cast matter, wrap matter]

    name: string
        Use to name the output layer.

    Return: layer
        shadow
    """
    intensity = d[ok.INTENSITY]

    if intensity:
        j = Run.j
        group = make_layer_group(j, "Shadow")
        base_z = add_layer(j, 'Temp', parent=group)

        # cast matter, '0'
        select_item(cast_q[0])

        # wrap matter, '1'
        select_item(cast_q[1], option=fu.CHANNEL_OP_SUBTRACT)
        invert_selection(j)

        if not pdb.gimp_selection_is_empty(j):
            if intensity > 100.:
                layer_count = intensity // 100.
                intensity = intensity / (layer_count + 1)

            else:
                layer_count = 0

            # base layer for shadow output, 'z1'
            # Make shadow from selection.
            pdb.script_fu_drop_shadow(
                j, base_z,
                d[ok.OFFSET_X], d[ok.OFFSET_Y],
                d[ok.BLUR],
                d[ok.COLOR_1],
                intensity,
                0                       # no resizing
            )
            if layer_count:
                # Increase shadow intensity by
                # stacking duplicate shadow layers.
                z = group.layers[0]
                for i in range(int(layer_count)):
                    z = clone_layer(z)

        pdb.gimp_image_remove_layer(j, base_z)
        pdb.gimp_selection_none(j)

        z = verify_layer(pdb.gimp_image_merge_layer_group(j, group))

        if z:
            z.mode = get_mode(d)

            pdb.gimp_image_reorder_item(j, z, parent, 0)

            if name is not None:
                z.name = name
            clip_to_wip(z)
        return z
