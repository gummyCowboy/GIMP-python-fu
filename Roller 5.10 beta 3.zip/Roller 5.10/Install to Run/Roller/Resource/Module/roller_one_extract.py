#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok, Step as sk
from roller_one_helm import Helm


def find_visible_preset():
    """
    Find the navigation step key of the visible Preset AnyGroup.
    A terminal group in the navigation tree is not a Node.

    Return: tuple
        (item key, ...)
    """
    def _shoot(_group, _go):
        """
        Find the step key of the visible selected AnyGroup.

        _group: AnyGroup
            Has item.

        _go: bool
            If True, then the last
        """
        _step_k = None

        if _go:
            _node = _group.item.node
            _x = _node.get_sel_row()
            _x = 0 if _x is None else _x
            _item = _node.get_branch(_x)
            _step_k = _item.any_group.nav_k

            if _item.group_type != 'node':
                _go = False
            else:
                _group1 = get_group(_step_k)
                if _group1.item.node:
                    _go, _step_k = _shoot(_group1, _go)
        return _go, _step_k

    get_group = Helm.get_group
    return _shoot(get_group(sk.STEPS), True)[1]


def get_model_list_group():
    """
    Fetch the AnyGroup of the ModelList.

    Return: AnyGroup or None
        the ModelList group
    """
    return Helm.get_group(sk.MODEL)


def get_model_name_list():
    """
    Compile a list of Model names appearing in the navigation tree.

    Return: list
        of Model name
    """
    a = Helm.get_group(sk.STEPS)
    return a.widget_d[ok.NODE].get_label_q()[4:-1]


def get_option_list_key(d):
    """
    Find the choice key in a OptionList Preset.

    d: dict
        OptionList Preset

    Return: string or None
        key to the option in the OptionList Preset
        Is None if there is a failure as in an empty dict.
    """
    k = None

    for k in d:
        if k != ok.SWITCH:
            break
    return k


def get_option_list_choice(d):
    """
    Fetch an OptionList key and the option's dictionary.

    d: dict
        Backdrop Style or Frame Preset

    Return: tuple
        (Preset key, Preset value dict)
    """
    k = get_option_list_key(d)
    return k, d[k]
