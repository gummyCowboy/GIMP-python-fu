#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice, randint, seed
from roller_a_contain import Globe, Run
from roller_a_gegl import (
    edge, median_blur, neon, noise_rgb, waterpixels
)
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok, SubMaya as sm
from roller_fu import (
    blur_selection, clone_layer, make_layer_group, merge_layer, saturate
)
from roller_maya import check_mix_basic, check_matter
from roller_maya_build import SubBuild
from roller_maya_bump import Bump
from roller_view_hub import color_layer_default
from roller_view_real import add_wip_base, mask_from_maya
import gimpfu as fu  # type: ignore

COLOR_TO_ALPHA = (
    (0, 0, 0),
    (255, 0, 0),
    (0, 255, 0),
    (0, 0, 255),
    (255, 255, 255)
)
pdb = fu.pdb


def do_ink_noise(d, z):
    """
    Make Ink Noise for a frame.

    maya: Maya
        frame variety

    d: dict
        Noise Preset

    z: layer
        WIP

    Return: layer
        Has Noise output.
    """
    # lowest turbulence, '1.'
    pdb.plug_in_plasma(Run.j, z, int(d[ok.SEED] + Globe.seed), 1.)

    z.opacity = 100.
    name = z.name

    pdb.gimp_drawable_posterize(z, 3)
    neon(z, 1., 1.)
    pdb.plug_in_colortoalpha(Run.j, z, (0, 0, 0))

    z1 = clone_layer(z)
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    blur_selection(z, 1.5)

    z = merge_layer(z1)
    z.name = name

    median_blur(z, 3, 50.)
    return z


def do_noise_matter(maya):
    """
    Create a Noise layer.

    maya: Maya
        Noise

    Return: layer
        Has Noise output.
    """
    d = maya.value_d
    group = maya.group
    z = add_wip_base("Material", group)

    pdb.gimp_selection_none(Run.j)

    z = {
        ff.INK: do_ink_noise,
        ff.RIFT: do_rift_noise,
        ff.SPECK: do_speck_noise,
        ff.WATER: do_water_noise
    }[d[ok.TYPE]](d, z)
    return z


def do_rift_noise(d, z):
    """
    Make Rift Noise for a layer.

    d: dict
        Noise Preset

    z: layer
        WIP

    Return: layer
        with noise
    """
    j = Run.j
    seed_ = int(Globe.seed + d[ok.SEED])

    seed(seed_)

    # Generate line.
    # The horizontal and vertical sizes are randomized.
    pdb.plug_in_solid_noise(
        j, z,
        0,                      # no tile-able
        1,                      # yes, turbulent
        seed_,
        int(d[ok.NOISE_AMOUNT]),
        float(randint(1, 4)),
        float(randint(1, 4))
    )

    # Harden the noise.
    # The radius is randomized.
    pdb.plug_in_unsharp_mask(
        j, z,
        choice((1., 4.)),
        54.,                    # amount
        .0                      # threshold
    )

    if d[ok.BLUR]:
        blur_selection(z, d[ok.BLUR])

    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
    return z


def do_speck_noise(d, z):
    """
    Make Speck Noise for a layer.

    d: dict
        Noise Preset
        {Option key: value}

    z: layer
        WIP

    Return: layer
        Has Noise output.
    """
    j = Run.j
    name = z.name
    z1 = clone_layer(z)
    f = (d[ok.SPECK_NOISE] + .5) / 7.

    # red, green, and blue noise, 'noise'
    pdb.plug_in_rgb_noise(
        j, z1,
        1,                  # independent
        0,                  # not correlated
        .0,
        .0,                # green
        .0,                # blue
        f
    )

    color_layer_default(z, (255, 255, 255))

    z = merge_layer(z1)

    for i in range(4):
        pdb.plug_in_erode(
            j, z,
            1,                # propagate black
            7,                # RGB channels
            1.,               # full rate
            0,                # direction mask
            0,                # lower limit
            12                # upper limit
        )
        pdb.plug_in_rgb_noise(
            j, z,
            1,                # independent
            0,                # not correlated
            f,                # red
            f,                # green
            f,                # blue
            .0
        )

    pdb.plug_in_colortoalpha(Run.j, z, (255, 255, 255))
    saturate(z, -75.)
    edge(z)
    blur_selection(z, 1.)

    # Curves won't work with a selection.
    pdb.gimp_selection_none(j)

    pdb.plug_in_despeckle(
        j, z,
        1,                      # radius
        3,                      # recursive adaptive
        0,                      # white cut-off
        255                     # black cut-off
    )
    pdb.plug_in_unsharp_mask(
        j, z,
        12.,                    # radius
        50.,                    # amount
        .0                      # threshold
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_ALPHA,
        8,                      # coordinate count
        (.0, .0, .25, .0, .62, .62, .9, 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                      # coordinate count
        (.0, .0, 1., .8)
    )

    z.name = name
    return z


def do_water_noise(d, z):
    """
    Make WaterPixel Noise for a layer.

    d: dict
        Noise Preset

    z: layer
        WIP

    Return: layer
        Has Noise output.
    """
    a = int(d[ok.SEED] + Globe.seed)

    for i in range(3):
        noise_rgb(z, 1., 1., 1., 1., a + i)

    waterpixels(z)
    pdb.gimp_brightness_contrast(z, 0, 75)
    return z


def make_group(maya):
    """
    Make a Frame/kind layer group. Is
    a sub-group of the super maya's layer group.

    maya: Maya
    Return: layer group
    """
    parent = maya.super_maya.group
    group = maya.group

    if not group:
        return make_layer_group(
            Run.j, parent.name + " Noise", parent=parent
        )
    return group


class Noise(SubBuild):
    """Process change for a Noise Preset."""
    is_seeded = True
    issue_q = 'mode', 'matter', 'opacity'
    put = (
        (make_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            origin of option

        super_maya: Maya
            The Maya's 'matter' layer alpha masks the output noise.

        k_path: tuple
            (Option key, ...)
        """
        SubBuild.__init__(
            self, any_group, super_maya, k_path, do_noise_matter
        )
        self.sub_maya[sm.BUMP] = Bump(any_group, self, k_path + (ok.BUMP,))

    def do(self, d, is_change, is_mask):
        """
        Check, modify, and produce layer output.

        d: dict
            Noise Preset
            {Option key: value}

        is_change: bool
            Is True if the cast Maya has change.

        is_mask: bool
            Is True if the super Maya has change.

        Return: bool
            Is True if the Noise changed.
        """
        self.value_d = d
        self.is_matter |= is_change
        self.go = d[ok.SWITCH]

        if self.go:
            self.is_matter |= is_change
            m = self.is_matter or is_mask

        else:
            m = False

        self.realize()

        if self.go:
            if self.matter:
                if m:
                    mask_from_maya(self.super_maya, self.matter)
                self.sub_maya[sm.BUMP].do(
                    d[ok.BUMP], self.is_matter, is_mask
                )
            else:
                self.die()

        self.reset_issue()
        return m
