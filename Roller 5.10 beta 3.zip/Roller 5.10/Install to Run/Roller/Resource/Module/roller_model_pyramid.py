#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Shape as sh, Signal as si
from roller_constant_key import Model as md, Option as ok
from roller_model_goo import Goo
from roller_model_grid import Grid
from roller_polygon import get_intersection, make_coord_list
from roller_view_preset import calc_shift_rect


def shear_polygon(q, a, b):
    """
    Calculate a transformed plaque with an existing polygon by
    modifying its coordinates with their relative positions.

    q: list
        an x, y series that define a plaque polygon

    a: Rect
        Bounds of the plaque before change.

    b: Rect
        Bounds of the plaque after change.

    Return: list
        Define an x, y series of polygon points that
        have been sheared by the change in rectangle size.
    """
    shape = []
    left, top = a.x, a.y

    # Use to calculate left offset.
    w_ratio = b.w / a.w

    # Use to calculate top offset.
    h_ratio = b.h / a.h

    for i in range(0, len(q), 2):
        x, y = q[i], q[i + 1]

        if x == left:
            # left-most
            x = b.x

        else:
            # Calculate relative 'x' ratio, 'f'
            # relative = distance from left / width of rectangle
            left_dist = x - left
            x = b.x + round(left_dist * w_ratio)

        if y == top:
            # top-most
            y = b.y

        else:
            # Calculate relative 'y' ratio.
            # relative = distance from left / width of rectangle
            top_dist = y - top
            y = b.y + round(top_dist * h_ratio)

        # adjusted point, 'x, y'.
        shape += [x, y]
    return shape


class Pyramid(Grid):
    """
    Has a Canvas and Cell branches. Has one or more row and column.
    """
    model_type = md.PYRAMID

    def __init__(self, model_name):
        """
        model_name: string
            Identify the model.
        """
        Grid.__init__(self, model_name)
        self.cell_shape = sh.PYRAMID
        self.intersect_x = self.intersect_y = self.left_x = \
            self.right_x = self.center_x = self.is_down = \
            self.column_count = None

    def calc_cell_form(self, rect, r):
        """
        Given a Rectangle, cell index, and a pyramid, determine
        and calculate a cell plaque (a polygon that fills the cell).

        rect: Rect
            Shift Rect

        r: int
            cell index

        Return: tuple
            Is a series of x, y points in canvas space that
            define a polygon in the shape of the given pyramid cell.
        """
        x, y, w, h = map(round, rect.rect)
        x1 = x + w
        y1 = y + h
        is_top = r == self.division[0] - 1
        left_x, left_x1 = self.left_x[r], self.left_x[r + 1]
        right_x, right_x1 = self.right_x[r], self.right_x[r + 1]

        # canvas point
        left, top, width, height = self.canvas_pocket.rect
        right = left + width
        bottom = top + height

        if x >= left_x1 and x1 <= right_x1:
            # four point, rectangle
            q = [x, y, x1, y, x1, y1, x, y1]

        else:
            # intersect point through with side of pyramid
            left_side = (left, bottom), (self.center_x, top)
            right_side = (right, bottom), (self.center_x, top)
            y2 = get_intersection((x, top), (x, bottom), *left_side)[1]
            y3 = get_intersection((x1, y), (x1, y1), *left_side)[1]
            y4 = get_intersection((x, y), (x, y1), *right_side)[1]
            y5 = get_intersection((x1, y), (x1, y1), *right_side)[1]

            # rounding
            y2, y3, y4, y5 = map(round, (y2, y3, y4, y5))

            if x == left_x and x1 == right_x:
                q = [x, y1, left_x1, y, right_x1, y, x1, y1]
            else:
                # Add points checking each possibility from left to right.
                q = []

                # left side intersect for x
                if left_x != x < left_x1:
                    q += [x, y2]

                # left side intersect for x1
                if x1 < left_x1:
                    q += [x1, y3, x1, y1]

                # left cut
                if x < left_x1 < x1:
                    q += [left_x1, y]

                # apex
                if is_top:
                    # no flat top
                    if x <= self.center_x <= x1:
                        q += [self.center_x, y]
                        if x1 == self.center_x:
                            q += [self.center_x, y1]

                else:
                    # flat top
                    if left_x1 <= x <= right_x1:
                        q += [x, y]

                    if left_x1 <= x1 <= right_x1:
                        q += [x1, y, x1, y1]

                # right cut
                if x < right_x1 < x1:
                    q += [right_x1, y]

                # right side intersect for x
                if x > right_x1:
                    q += [x, y4]

                # right side intersect for x1
                if x1 > right_x1:
                    q += [x1, y5, x1, y1]

                # There is always a bottom-left point.
                q += [x, y1]

        if self.is_down:
            # Invert 'y' in the plaque polygon.
            for x in range(1, len(q), 2):
                q[x] = top + bottom - q[x]
        return tuple(q)

    def calc_cell_shift(self, d, r_c):
        """
        Update the Cell Shift rectangle and plaque
        polygon for a Cell given a Shift Preset
        and a previously calculated form polygon.

        d: dict
            Shift Preset

        r_c: tuple
            cell index; of int

        Return: list
            [Plan vote, Work vote]
            Has vote on cell's Shift change since the last view run.
        """
        x, y, w, h = calc_shift_rect(d)

        # Goo, 'a'
        a = self.goo_d[r_c]
        x1, y1, w1, h1 = a.merged.rect
        a.shift.rect = x + x1, y + y1, w + w1, h + h1

        if any((x, y, w, h)):
            # Shear the plaque with a Shift rectangle mod.
            a.plaque = shear_polygon(a.form, a.merged, a.shift)

        else:
            a.plaque = a.form

        if self.is_down:
            a.shift.y = min([a.plaque[i] for i in range(1, len(a.plaque), 2)])
        return self.past.did_cell_shift(r_c)

    def calc_division(self, d):
        """
        Determine the row and column count of the cell grid.

        d: dict
            Cell Type Preset
            {Option key: value}
        """
        self.division = len(d[ok.COLUMN_COUNT_Q]), max(d[ok.COLUMN_COUNT_Q])
        self.baby.emit(si.DIVISION_CHANGE, self.division)

    def calc_pocket(self, is_margin, q, r_c):
        """
        Update the pocket rectangle and its inscribed shape polygon for a cell.

        is_margin: bool
            Is True if the cell has a margin.

        q: tuple
            (top, bottom, left, right) of numeric margin value

        r_c: tuple
            (row, column)
            zero-based cell index and key

        Return: iterable
            [Plan vote, Work vote]
            Is True if the pocket or shape changed value.
        """
        # Goo instance, 'a'
        a = self.goo_d[r_c]

        top, bottom, left, right = q
        x, y, w, h = a.shift.rect

        if is_margin:
            x += left
            y += top
            w = max(1., w - left - right)
            h = max(1., h - top - bottom)

        a.pocket.rect = x, y, w, h

        if is_margin:
            a.shape = shear_polygon(a.plaque, a.shift, a.pocket)

        else:
            a.shape = a.plaque
        return self.past.did_cell_pocket(r_c)

    def init_model_cell(self, d):
        """
        For each cell, calculate cell, merged, and plaque value.

        d: dict
            Cell Type Preset
            {Option key: value}

        Return: dict
            {(row, column): [Plan vote, Work vote]}
            A True vote equates to 'My value changed since the last view'.
        """
        vote_d = {}
        self.goo_d = {}
        row = self.division[0]

        # calc pyramid(s)
        x, y, w, h = self.canvas_pocket.rect
        last_y = y + h
        row_h = h / row
        self.center_x = round(x + (w / 2.))
        self.right_x = round(x + w)
        slope_w = (self.center_x - x) / row
        self.left_x = [x] + [round(x + (i + 1) * slope_w) for i in range(row)]
        self.right_x = [self.right_x] + [
            round(self.right_x - (i + 1) * slope_w) for i in range(row)
        ]
        q_y = self.intersect_y = []

        # Set 'y' to bottom.
        y = y + h - row_h

        # remainder total, 'f_y'
        f_y = .0

        for r in range(row + 1):
            y, f = divmod(y, 1.)
            f_y += f

            if f_y >= .999:
                y += 1.
                f_y -= 1.

            q_y.append(y)
            y -= row_h

        for r in range(row):
            y = q_y[r]
            self.intersect_x = []
            x = self.left_x[r]
            column = d[ok.COLUMN_COUNT_Q][r]
            width = self.right_x[r] - self.left_x[r]
            w = width / column
            h = last_y - y
            q_x = make_coord_list(width, column + 1, x, span=w)

            for c in range(self.column_count[r]):
                r_c = r, c
                a = self.goo_d[r_c] = Goo(r_c)
                a.cell.rect = q_x[c], y, q_x[c + 1] - q_x[c], h
                a.merged = a.cell.clone()
                vote_d[r_c] = self.past.did_cell(r_c)
                a.form = self.calc_cell_form(a.merged, r)
            last_y = y
        return vote_d

    def init_cell_q(self, d):
        """
        Create a sorted list of valid cell index,
        'cell_q' -> [(row, column), ...].

        d: dict
            Cell Type Preset
        """
        self.cell_q = [
            (r, c)
            for r in range(int(d[ok.ROW_COUNT]))
            for c in range(d[ok.COLUMN_COUNT_Q][r])
        ]
        self.cell_q.sort()

    def update_type(self, arg):
        """
        Update Cell Type dependency.

        arg: tuple
            (Cell Type Preset, is sequence flag)
            Preset -> {Option key: value}

            If the sequence flag is True, then a chained-sequence
            of cell dependency is processed immediately.
        """
        d, is_sequence = arg
        self.is_down = d[ok.DIRECTION]
        self.column_count = d[ok.COLUMN_COUNT_Q]
        p = self.baby.feed if is_sequence else self.baby.give
        vote_d = super(Pyramid, self).update_type(arg)

        self.adapt_missing_cell_step(is_sequence)
        p(si.CELL_RECT_CALC, vote_d)
