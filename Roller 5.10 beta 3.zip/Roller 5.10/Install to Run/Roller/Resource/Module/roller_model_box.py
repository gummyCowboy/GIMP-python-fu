#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Signal as si, Shape as sh
from roller_constant_key import Model as md, Option as ok
from roller_model_facing import Facing
from roller_model_goo import Map
from roller_model_grid import Grid
from roller_face_cap import CAP_BUILD, CAP_TRANSFORM
from roller_face_1 import FACE1_BUILD, FACE1_TRANSFORM
from roller_face_2 import FACE2_BUILD, FACE2_TRANSFORM
from roller_one import seal
from roller_polygon import calc_length

ROUTE_BUILD = CAP_BUILD, FACE1_BUILD, FACE2_BUILD
FACE_ORDER_D = {
    sh.BOTTOM: (1, 2, 0),
    sh.LEFT: (0, 1, 2),
    sh.RIGHT: (1, 0, 2),
    sh.TOP: (0, 1, 2)
}
V_FACE_TEXT_Q = "Cap", "Left", "Right"
H_FACE_TEXT_Q = "Cap", "Top", "Bottom"
ROUTE_TRANSFORM = CAP_TRANSFORM, FACE1_TRANSFORM, FACE2_TRANSFORM


class Box(Grid, Facing):
    """
    Has three Faces that can be arranged in four directions.

    The Faces are Cap, Left, Right. The directions are Top, Bottom, Left,
    and Right. A Face's attribute geometry is assigned according to the Box
    direction.

    Face attribute geometry
        foam
            tuple
            Is a flag-shaped ordered series of points that
            Face transform uses to create Face output.

        form
            tuple
            Is the merged rectangle defined as a GIMP polygon. There
            are four points that connect four segments making a
            rectangle. The attribute is used by deco to create
            a its input/output selection.

        merged
            Rect
            Is used to make a source rectangle for the Face transform.

        shape
            tuple
            Is the Face defined as a GIMP polygon. There are four points.
    """
    model_type = md.BOX

    def __init__(self, model_name):
        """
        model_name: string
            identity of the model
        """
        Grid.__init__(self, model_name)
        Facing.__init__(self)

        self.is_vertical = False
        self.face_q = \
            self.box_type = \
            self._grid_type = \
            self.face_order_q = \
            self._face_update_p = None

    def _update_face(self, k, q, w, h, a):
        """
        Update Cell Face attribute with cell size.

        k: tuple
            zero-based cell index; Goo key
            (row, column, face)

        q: tuple
            (x, y vertex pair, ...)
            Define a rectangle for Face transform.

        w, h: numeric
            the box (hexagon) size

        a: Rect
            cell Shift rectangle
        """
        center = map(round, a.center())
        d = self.map_d
        n = self.box_type
        x = self.face_order_q[k[-1]]
        ROUTE_BUILD[x][n](q, w, h, center, d[k])

    def calc_main_cell_pocket(self, d):
        """
        Calculate the pocket rectangle and shape polygon for
        Cell branch main. Update the dependent Box Face.

        d: dict
            Margin Preset
            {Option key: value}
        """
        super(Box, self).calc_main_cell_pocket(d)

        e = self.goo_d
        for r_c in self.cell_q:
            a = e[r_c]
            for x in range(3):
                self._face_update_p(r_c + (x,), a.shape, a.shift)

    def calc_cell_pocket(self, d, r_c):
        """
        Calculate the pocket rectangle and shape polygon for the main
        option settings Cell branch. Update the dependent Box Face.

        d: dict
            Margin Preset

        r_c: tuple
            cell index; Goo key
        """
        super(Box, self).calc_cell_pocket(d, r_c)

        # Goo, 'a'
        a = self.goo_d[r_c]

        # face count of box, '3'
        for x in range(3):
            self._face_update_p(r_c + (x,), a.shape, a.shift)

    def calc_division(self, d):
        """
        Determine the row and column count of the Model.
        Call after Canvas pocket has been calculated.

        d: dict
            Cell Type Preset
        """
        n = d[ok.GRID_TYPE]
        w, h = self.canvas_pocket.size

        if n == gr.CELL_COUNT:
            r, c = d[ok.ROW_COUNT], d[ok.COLUMN_COUNT]

        elif n == gr.SHAPE_COUNT:
            r, c = d[ok.VERT_COUNT], d[ok.HORZ_COUNT]

        else:
            # cell size
            width = seal(d[ok.COLUMN_W], 1., w)
            height = seal(d[ok.ROW_H], 1., h)
            n = d[ok.BOX_TYPE]

            if n in (sh.LEFT, sh.RIGHT):
                w1, h1 = width * .75, height * .5
                w2, h2 = w - w1, h - h1
                r, c = max(1, h2 / h1), max(1, w2 / w1)
            else:
                # vertical box
                w1, h1 = width * .5, height * .75
                w2, h2 = w - w1, h - h1
                r, c = max(1, h2 / h1), max(1, w2 / w1)

        self.division = int(r), int(c)
        self.baby.emit(si.DIVISION_CHANGE, self.division)

    def clip_facing(self, *_):
        """
        Box is Face Model type. The function is used by Facing Model type.
        """
        return

    def get_face_text(self):
        """
        Each Box/Cell/Box Type has a different order of Face.

        Return: list
            [string, ...]; length of three; one for each Box Face
            Identify Face by index.
        """
        q = (H_FACE_TEXT_Q, V_FACE_TEXT_Q)[int(self.is_vertical)]
        return [q[self.face_order_q[i]] for i in range(3)]

    def init_cell_q(self, d):
        """
        Make a list of valid cell and another with their face index.

        d: dict
            Cell Type Preset
        """
        is_indent = d[ok.FCI]
        self.face_q = []
        self.cell_q = []

        for r in range(self.division[0]):
            for c in range(self.division[1]):
                if is_indent:
                    is_cell = bool(
                        (r % 2 and not c % 2) or (not r % 2 and c % 2)
                    )

                else:
                    is_cell = bool(
                        (r % 2 and c % 2) or (not r % 2 and not c % 2)
                    )
                if is_cell:
                    self.cell_q += [(r, c)]
                    for x in range(3):
                        self.face_q += [(r, c, x)]

    def init_model_cell(self, d):
        """
        Calculate cell size and Face attribute geometry.

        d: dict
            Cell Type Preset
            {Option key: value}

        Return: list
            [Plan vote, Work vote]
            Each True vote is a vote for change.
        """
        vote_d = super(Box, self).init_model_cell(d)
        e = self.map_d = {}
        n = self.box_type

        # Init map dict.
        for k in self.face_q:
            x = self.face_order_q[k[-1]]
            e[k] = Map(d, ROUTE_TRANSFORM[x][n])
        return vote_d

    def set_default_pocket(self, is_sequence):
        """
        The Cell Margin step is not active, so a default pocket is calculated.

        is_sequence: bool
            If True, then the chained-sequence is calculated immediately.
        """
        super(Box, self).set_default_pocket(is_sequence)

        p = self._face_update_p
        for r_c in self.cell_q:
            # Face count, '3'
            for x in range(3):
                # Goo, 'a'
                a = self.goo_d[r_c]
                p(r_c + (x,), a.shape, a.shift)

    def _update_horz_face(self, k, q, a):
        """
        Update a horizontally oriented Box's Face attribute.

        k: tuple
            cell index; Goo key
            (row, column, face)

        q: tuple
            x, y float series, eight values defining four vertices
            cell shape

        a: Rect
            cell Shift rectangle
        """
        w = q[4] - q[2]
        h = round(calc_length(*q[:4]))
        self._update_face(k, q, w, h, a)

    def _update_vert_face(self, k, q, a):
        """
        Update a vertically oriented Box's Face attribute geometry.

        k: tuple
            cell index; Goo key
            (row, column, face)

        q: tuple
            x, y float series, eight values defining four vertices
            cell shape

        a: Rect
            Cell/Shift rectangle
        """
        w = round(calc_length(*q[:4]))

        # the last two positions for y-coordinate
        # in a vertical face, '7' and '5'
        h = q[7] - q[5]

        self._update_face(k, q, w, h, a)

    def update_type(self, arg):
        """
        Update Cell/Type dependency.

        arg: tuple
            (Box Cell/Type Preset, is sequence flag)
            {Option key: value}
            A sequence is processed immediately.
        """
        def _get_cell_shape():
            """
            Get the cell shape according the cell type.

            Return: string
                cell shape descriptor
            """
            if self.is_vertical:
                return sh.BOX_VERT if self.is_equilateral \
                    else sh.BOX_VERT_SHEAR
            return sh.BOX_HORZ if self.is_equilateral else sh.BOX_HORZ_SHEAR

        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        self.is_vertical = d[ok.BOX_TYPE] in (sh.TOP, sh.BOTTOM)
        self.cell_shape = _get_cell_shape()
        self.box_type = d[ok.BOX_TYPE]

        # Set the order of processing and its image assignment.
        # Is consistently ordered from topleft to bottom-right.
        self.face_order_q = FACE_ORDER_D[self.box_type]

        self._face_update_p = (
            self._update_horz_face, self._update_vert_face
        )[int(self.is_vertical)]
        vote_d = super(Box, self).update_type(arg)

        self.adapt_missing_cell_step(is_sequence)
        p(si.CELL_RECT_CALC, vote_d)
