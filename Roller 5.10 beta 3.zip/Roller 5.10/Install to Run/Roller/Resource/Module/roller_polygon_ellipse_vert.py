#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_many_rect import Rect
from roller_polygon import get_v_ellipse_rect
from roller_polygon_hexagon_truncated import HexagonTruncated


class EllipseVert:
    """
    Calculate the position and the size of cells. The cells are ellipse
    shaped and vertically aligned. Is a double-spaced cell model-type.
    """

    @staticmethod
    def calc(model, o):
        """
        Calculate cell rectangle and form polygon for a Model's cell.

        model: Model
        o: One
            Has Cell Type reference.

        Return: list
            [Plan vote, Work vote]
        """
        goo_d = model.goo_d
        vote_d = HexagonTruncated.calc(
            model, o, ellipse_space=sh.ELLIPSE_RATIO
        )

        if False if o.grid_type == gr.CELL_SIZE else True:
            # by count
            did_cell = model.past.did_cell

            for r_c in model.cell_q:
                a = goo_d[r_c]

                # The ellipse rect is smaller than the hexagon rect.
                a.cell = a.merged = Rect(*get_v_ellipse_rect(a.cell))
                a.form = a.cell.rect
                vote_d[r_c] = did_cell(r_c)

        for r_c in model.cell_q:
            a = goo_d[r_c]
            a.form = a.cell.rect
        return vote_d
