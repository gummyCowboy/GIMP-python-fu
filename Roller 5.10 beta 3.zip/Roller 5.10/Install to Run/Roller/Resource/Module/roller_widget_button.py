#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import The
from roller_constant_for import Image as fi, Signal as si
from roller_constant_key import Button as bk, Widget as wk
from roller_fu_comm import pop_up
from roller_one import (
    convert_to_rgb, random_rgb, random_rgba, seed_random
)
from roller_one_ring import Ring
from roller_one_tip import Tip
from roller_widget_entry import Entry
from roller_widget_box import Box as boxer
from roller_widget import Widget
import gobject  # type: ignore
import gtk      # type: ignore
import os

FILE_ONLY = \
    "The selected item is a folder, " \
    "and the entry is for an image file only."
FOLDER_ONLY = \
    "The selected item is not a folder, " \
    "and the entry is for folders only. "


def on_accept_action(g):
    """
    Respond to an AcceptButton click. Let
    the Window know that it is accepted.

    g: Button
        Is responsible.
    """
    g.roller_win.emit(si.ACCEPT_WINDOW, g)


def on_cancel_action(g):
    """
    Respond to a CancelButton click. Let
    the Window know that it is canceled.

    g: Button
        Is responsible.
    """
    g.roller_win.emit(si.CANCEL_WINDOW, g)


class Button(Widget, gobject.GObject):
    """This is a custom GTK Button."""
    __gsignals__ = si.BUTTON_D
    change_signal = 'clicked'
    has_table_label = False

    def __init__(self, **d):
        """
        Create a gtk.Button that is attached to an gtk.Alignment.

        d: dict
            Has keyword arguments for Widget.
        """
        self._open_state = None
        self.tooltip_text = d[wk.TOOLTIP] if wk.TOOLTIP in d else ""

        # There is no basestring in Python 3.
        if isinstance(d[wk.TEXT], basestring):
            g = self.button = gtk.Button(d[wk.TEXT])

        else:
            # arrow
            g = gtk.Button()
            g.add(d[wk.TEXT])

        # Process Button doesn't have a group.
        self._value = self.any_group = None

        # A Button is not valid if it is in a Window buried by a GTK Dialog.
        self.is_valid = True

        Widget.__init__(self, g, **d)

        # for custom signal(s)
        gobject.GObject.__init__(self)

        self.add(g)
        self.roller_win.connect(si.DIALOG_OPEN, self.on_view_dialog_open)
        self.roller_win.connect(si.DIALOG_CLOSE, self.on_view_dialog_close)

    def get_a(self):
        """Is a Port Preview requirement."""
        return

    def on_bring_dialog_button(self, *_):
        """Open a Preset dialog."""
        self.roller_win.bring_dialog(self)

    def on_view_dialog_close(self, *_):
        """
        A GTK Dialog Window closed, so the button is valid.

        _: Button
            Is responsible.
        """
        self.is_valid = True

        self.set_sensitive(1)
        self.set_tooltip_text(self.tooltip_text)
        self.emit(si.VALIDATE, None)

    def on_view_dialog_open(self, *_):
        """
        A GTK Dialog Window opened, so the Button is invalid.

        _: Button
            Is responsible.
        """
        self._open_state = self.get_sensitive()
        self.is_valid = False
        self.set_sensitive(0)
        self.set_tooltip_text("")


class ColorButton(Widget):
    """Open a color-chooser dialog on clicked action."""
    change_signal = 'color_set'
    has_table_label = True

    def __init__(self, **d):
        """
        Create a ColorButton.

        d: dict
            Has keyword arguments for Widget.
        """
        self._tooltip_n = d.get(wk.TOOLTIP)

        if not self._tooltip_n:
            self._tooltip_n = ""

        g = gtk.ColorButton(color=gtk.gdk.Color(0, 0, 0))
        self._has_alpha = d[wk.HAS_ALPHA] if wk.HAS_ALPHA in d else False
        self.greater_g = d[wk.GREATER_G] if wk.GREATER_G in d else None

        d[wk.RELAY].insert(0, self.update_tooltip)
        g.set_use_alpha(self._has_alpha)
        Widget.__init__(self, g, **d)
        self.add(g)

    def get_a(self):
        """
        Get the value of the ColorButton.

        Return: tuple
            color
            RGB
            in 0 to 255
        """
        color = convert_to_rgb(self.widget.get_color())

        if self._has_alpha:
            color = color + (self.widget.get_alpha() // 257,)
        return color

    def set_a(self, color, is_dialog=False):
        """
        Set the color of the ColorButton.

        color: gtk.gdk.Color
            of button

        is_dialog: bool
            Is True if the value is coming from a color dialog.
            When the value is not coming from a dialog,
            a vote needs to be cast.
        """
        color1 = color[:]

        if self._has_alpha:
            if len(color1) < 4:
                # Fix a missing alpha value
                # which may occur with updates.
                color1 += (255,)
            color = color1[:3]

        if not isinstance(color, gtk.gdk.Color):
            if isinstance(color, tuple):
                color = tuple([i * 257 for i in color])

            # in the range of 0 to 65535, 'color'
            # 257 in GDK color is 1.0 RGBA float precision.
            color = gtk.gdk.Color(*color)

        self.widget.set_color(color)

        q = convert_to_rgb(color)
        n = self._tooltip_n + "\n" if self._tooltip_n else ""

        if self._has_alpha:
            self.widget.set_alpha(color1[3] * 257)
            tip = Tip.COLOR_RGBA_INDENT if n else Tip.COLOR_RGBA
            q += (color1[3],)

        else:
            tip = Tip.COLOR_INTENT if n else Tip.COLOR

        tip = n + tip

        if not is_dialog and not self.greater_g:
            self.on_voter_change(self.widget)
        self.set_tooltip_text(tip.format(*q))

    def update_tooltip(self, *_):
        """
        Update the Widget's tooltip after the
        user closes the color-chooser dialog.
        Will trigger a vote.
        """
        self.set_a(self.get_a(), is_dialog=True)


class RandomColorButton(ColorButton):
    """Is able to randomize."""

    def __init__(self, **d):
        ColorButton.__init__(self, **d)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

    def randomize(self, *_):
        """Randomize the color value."""
        self.set_a(
            random_rgba() if self._has_alpha else random_rgb()
        )


class ProcessButton(Button):
    """Process a GTK Dialog signals open and close."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument. Has Button spec.
        """
        d[wk.CHANGELESS] = True
        Button.__init__(self, **d)


class ManagePresetButton(ProcessButton):
    """Use to open Preset file manager dialog."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.CHANGELESS] = True
        d[wk.TEXT] = "Manage Preset…"
        self.dialog = d[wk.DIALOG]

        d[wk.RELAY].insert(0, self.on_bring_dialog_button)
        ProcessButton.__init__(self, **d)


class NavButton(ProcessButton):
    """Process a GTK Dialog signals open and close."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument. Has ProcessButton spec.
        """
        self.on_dialog_close = d[wk.ON_DIALOG_CLOSE]
        ProcessButton.__init__(self, **d)

    def on_view_dialog_close(self, *_):
        """
        A GTK Dialog Window closed, so the button is valid.

        _: Button
            Is responsible.
        """
        self.on_dialog_close()
        self.set_tooltip_text(self.tooltip_text)


class Accept(ProcessButton):
    """Use to accept a Window."""

    def __init__(self, a, **d):
        """
        d: dict
            Has keyword argument. Has ProcessButton spec.
        """
        d[wk.TEXT] = a

        d[wk.RELAY].insert(0, on_accept_action)
        ProcessButton.__init__(self, **d)


class AcceptButton(Accept):
    """Use to accept a Window."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument. Has Accept spec.
        """
        Accept.__init__(self, bk.ACCEPT, **d)
        self.roller_win.connect(si.ACCEPT_FOCUS, self.accept_focus)

    def accept_focus(self, *_):
        """
        Take the interface focus.

        Return: True
            Let GTK know that the signal is handled.
        """
        self.widget.grab_focus()
        return True


class AcceptAllButton(Accept):
    """Use to accept a Window."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument. Has Accept spec.
        """
        Accept.__init__(self, bk.ACCEPT_ALL, **d)


class AcceptNoneButton(Accept):
    """Use to accept a Window."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument. Has Accept spec.
        """
        Accept.__init__(self, bk.ACCEPT_NONE, **d)


class CancelButton(ProcessButton):
    """Use to cancel a Window."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.TEXT] = bk.CANCEL

        d[wk.RELAY].insert(0, on_cancel_action)
        ProcessButton.__init__(self, **d)


class ViewButton(ProcessButton):
    """Respond by performing a View."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.KEY] = d[wk.TEXT]

        d[wk.RELAY].insert(0, self.on_view_action)
        ProcessButton.__init__(self, **d)
        Ring.gob.connect(si.UI_CHANGE, self.update_sensitivity)

    def on_view_action(self, *_):
        """Disable the Button when View is run."""
        self.set_sensitive(0)
        self.set_tooltip_text("")
        self.roller_win.emit(si.ACCEPT_FOCUS, self)

    def update_sensitivity(self, sender, spark):
        """
        When the user interface changes, a View Button becomes sensitive.

        sender: SignalFilter
            Sent the signal.
            not used

        spark: object
            Is responsible for initiating the signal.
        """
        if (
            self.is_valid and
            spark != self and
            spark.roller_win == self.roller_win
        ):
            if not self.get_sensitive():
                self.set_sensitive(1)
                self.set_tooltip_text(self.tooltip_text)


class DraftButton(ViewButton):
    """Run a View Draft."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.TEXT] = bk.DRAFT
        d[wk.TOOLTIP] = Tip.DRAFT_BUTTON

        d[wk.RELAY].insert(0, self.on_draft_action)
        ViewButton.__init__(self, **d)

    @staticmethod
    def on_draft_action(g):
        """
        Respond to a Button click. Call the Port's View handler.

        g: Button
            Is responsible.
        """
        # Draft index, '2'
        g.roller_win.port.task_view(g, 2)


class DialogButton(Button):
    """Create a Button for opening a dialog."""

    def __init__(self, **d):
        """
        d: dict
            Initialize Port.
        """
        d[wk.CHANGELESS] = True
        self.dialog = d[wk.DIALOG]

        d[wk.RELAY].insert(0, self.on_bring_dialog_button)
        Button.__init__(self, **d)


class MakeMaterialButton(DialogButton):
    """Open a Make Heat Material dialog."""

    def __init__(self, **d):
        """
        d: dict
            Initialize Port.
        """
        self.get_list = d[wk.GET_A]
        d[wk.TEXT] = "Make Material…"
        DialogButton.__init__(self, **d)

    def set_a(self, value):
        """
        Send a Signal with an Accept value
        received from the ChoiceList.

        value: string
            Material key
        """
        self.emit(si.MAKE_MATERIAL, value)


class NewModelButton(DialogButton):
    """Use to create a Model."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.TEXT] = "New…"
        DialogButton.__init__(self, **d)


class PeekButton(ViewButton):
    """Use to run a View Peek."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.TEXT] = bk.PEEK
        d[wk.TOOLTIP] = Tip.PEEK_BUTTON

        d[wk.RELAY].insert(0, self.on_peek_action)
        ViewButton.__init__(self, **d)

    @staticmethod
    def on_peek_action(g):
        """
        Respond to a click event. Call the Port's View handler.

        g: Button
            Is responsible.
        """
        # Peek index, '3'
        g.roller_win.port.task_view(g, 3)


class PlanButton(ViewButton):
    """Use to run a View Plan."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.TEXT] = bk.PLAN
        d[wk.TOOLTIP] = Tip.PLAN_BUTTON

        d[wk.RELAY].insert(0, self.on_plan_action)
        ViewButton.__init__(self, **d)

    @staticmethod
    def on_plan_action(g):
        """
        Respond to a PlanButton click. Call the Port's View handler.

        g: Button
            Is responsible.
        """
        # Plan index, '0'
        g.roller_win.port.task_view(g, 0)


class PreviewButton(ViewButton):
    """Use to run a View Preview."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.TEXT] = bk.PREVIEW
        d[wk.TOOLTIP] = Tip.PREVIEW_BUTTON

        d[wk.RELAY].insert(0, self.on_preview_action)
        ViewButton.__init__(self, **d)
        self.roller_win.connect(si.PREVIEW, self.on_widget_change)

    @staticmethod
    def on_preview_action(g):
        """
        Respond to a PlanButton click. Call the Port's View handler.

        g: Button
            Is responsible.
        """
        # Preview index, '1'
        g.roller_win.port.task_view(g, 1)


class RandomButton(ProcessButton):
    """Use to randomize AnyGroup option value."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.CHANGELESS] = True
        d[wk.TEXT] = bk.RANDOM

        d[wk.RELAY].insert(0, self.do_random)
        ProcessButton.__init__(self, **d)

    def do_random(self, _):
        """
        Have option randomize itself.

        _: self
        """
        seed_random()
        self.any_group.emit(si.RANDOMIZE, self)


class RemoveButton(DialogButton):
    """Open a Remove dialog."""

    def __init__(self, **d):
        """
        d: dict
            Initialize Port.
        """
        self.get_list = d[wk.GET_A]
        d[wk.TEXT] = "Remove…"
        DialogButton.__init__(self, **d)

    def set_a(self, value):
        """
        Send a Signal with an Accept value
        received from the caller.

        value: list
            [Material key, ...]
        """
        self.emit(si.REMOVE_MATERIAL, value)


class RenameButton(DialogButton):
    """Use to rename a Model."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.TEXT] = "Rename…"
        DialogButton.__init__(self, **d)


class ReviseButton(DialogButton):
    """Use to add and remove Model step."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.TEXT] = "Revise…"
        DialogButton.__init__(self, **d)


class SaveButton(ProcessButton):
    """Use to save a Preset file."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.CHANGELESS] = True
        d[wk.TEXT] = "Save Preset…"
        self.dialog = d[wk.DIALOG]

        d[wk.RELAY].insert(0, self.on_bring_dialog_button)
        ProcessButton.__init__(self, **d)


class MoveDownButton(Button):
    """Display an Arrow on the Button."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.CHANGELESS] = True
        d[wk.TEXT] = gtk.Arrow(gtk.ARROW_DOWN, gtk.SHADOW_NONE)
        Button.__init__(self, **d)


class MoveUpButton(Button):
    """Display an Arrow on the Button."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument.
        """
        d[wk.CHANGELESS] = True
        d[wk.TEXT] = gtk.Arrow(gtk.ARROW_UP, gtk.SHADOW_NONE)
        Button.__init__(self, **d)


class OSButton(Widget):
    """Factor FileButton and FolderButton."""
    change_signal = None
    has_table_label = False

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        key = d[wk.KEY]
        d[wk.CHANGELESS] = True
        box = boxer()
        d[wk.CHARS] = 90
        relay = d[wk.RELAY]
        d[wk.RELAY] = [self.on_os_entry_change]
        d[wk.KEY] = key + "_entry"
        g = self.os_entry = Entry(**d)
        d[wk.RELAY] = relay
        d[wk.KEY] = key
        self.os_button = Button(**d)

        Widget.__init__(self, g.widget, **d)
        box.add(g)
        box.add(self.os_button)
        self.add(box)

    def get_a(self):
        """
        Get the value of the Entry.

        Return: string
            a file or folder reference
        """
        return self.os_entry.get_a()

    def set_a(self, n):
        """
        Set the value of the Entry.

        n: string
            a file or folder reference
        """
        self.os_entry.set_a(n)

    def on_os_entry_change(self, *_):
        """Let listener (e.g. Preview Button) know that there was change."""
        Ring.plug(si.UI_CHANGE, self.os_entry)


class FileButton(OSButton):
    """
    Is a Button that opens a dialog for choosing an image
    file. Has an Entry partner to store the dialog choice.
    """

    def __init__(self, **d):
        """
        Draw the Entry and Button.

        d: dict
            Has init values.

        """
        d[wk.TEXT] = "Select a File…"
        d[wk.RELAY] = [self.get_file_entry_item]
        OSButton.__init__(self, **d)

    def get_file_entry_item(self, *_):
        """Open a file chooser dialog."""
        dialog = gtk.FileChooserDialog(
            title="Choose an Image File",
            parent=self.roller_win.gtk_win,
            action=gtk.FILE_CHOOSER_ACTION_OPEN,
            buttons=(
                "Cancel",
                gtk.RESPONSE_CANCEL,
                "Accept",
                gtk.RESPONSE_ACCEPT
            )
        )
        file_filter = gtk.FileFilter()
        n = self.os_entry.get_a()

        if not n:
            n = The.image_path

        # Reference
        # en.wikipedia.org/wiki/File_URI_scheme
        n = "file://localhost/" + os.path.dirname(n)

        dialog.set_current_folder_uri(n)
        file_filter.set_name("Images")

        for i in fi.EXTENSION:
            file_filter.add_pattern("*" + i)

        dialog.add_filter(file_filter)

        response = dialog.run()

        # Is the enum for Accept, '-3'.
        n = dialog.get_filename() if response == -3 else ""

        dialog.destroy()

        if n:
            The.image_path = n

            if not os.path.isfile(n):
                pop_up(
                    self.roller_win.gtk_win,        # Use dialog.
                    1,
                    FILE_ONLY.format(n),
                    "Wrong Item Type"
                )
                n = ""
            if n:
                self.os_entry.set_a(n)
        return True


class FolderButton(OSButton):
    """
    Is a Button that opens a dialog for choosing a folder.
    Has an Entry partner to store the dialog choice.
    """

    def __init__(self, **d):
        """
        Draw an Entry and a Button.

        d: dict
            Has init values.
        """
        d[wk.TEXT] = "Select a Folder…"

        d[wk.RELAY].insert(0, self._get_folder_entry_item)
        OSButton.__init__(self, **d)

    def _get_folder_entry_item(self, *_):
        """Open a folder chooser dialog."""
        action = gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER
        dialog = gtk.FileChooserDialog(
            title="Choose an Image Folder",
            parent=self.roller_win.gtk_win,
            action=action,
            buttons=(
                "Cancel",
                gtk.RESPONSE_CANCEL,
                "Accept",
                gtk.RESPONSE_ACCEPT
            )
        )
        n = self.os_entry.get_a()

        if not n:
            n = The.image_path

        if os.path.isdir(n):
            # Reference
            # en.wikipedia.org/wiki/File_URI_scheme
            n = "file://localhost/" + n

            # Set the initial folder.
            dialog.set_current_folder_uri(n)

        response = dialog.run()

        # Is the enum for Accept, '-3'.
        n = dialog.get_filename() if response == -3 else ""

        dialog.destroy()
        if n:
            The.image_path = n
            if not os.path.isdir(n):
                pop_up(
                    self.roller_win.gtk_win,        # use dialog
                    1,
                    FOLDER_ONLY.format(n),
                    "Wrong Item Type"
                )
                n = ""
            if n:
                self.os_entry.set_a(n)


class RainbowColorButton(RandomColorButton):
    """Update Rainbow Widget on change."""

    def __init__(self, **d):
        RandomColorButton.__init__(self, **d)

    def set_a(self, *q, **d):
        super(RainbowColorButton, self).set_a(*q, **d)
        self.greater_g.update_a()


# Register the custom signals.
gobject.type_register(Button)
