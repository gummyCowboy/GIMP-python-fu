#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_key import Frame as ek, Material as ma, Option as ok
from roller_frame import select_frame
from roller_frame_alt import FrameOverlay
from roller_view_hub import color_layer_default, color_selection_default
from roller_view_real import add_wip_layer, get_light
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def do_overlay(maya):
    """
    Make a color layer.

    maya: Overlay
    Return: layer
        with color
    """
    pdb.gimp_selection_none(Run.j)

    d = maya.value_d
    z = add_wip_layer("Color Board", maya.group, offset=get_light(maya))

    color_layer_default(z, d[ok.COLOR_1])
    return z


def do_matter(maya):
    """
    Make a frame.

    maya: ColorBoard
    Return: layer
        with the frame
    """
    j = Run.j
    d = maya.value_d
    z = add_wip_layer("Color Board", maya.group, offset=get_light(maya))

    select_frame(j, maya.cast.matter, d[ok.WIDTH], d[ok.TYPE])
    color_selection_default(z, (180, 180, 180))
    return z


class ColorBoard(FrameOverlay):
    kind = ek.COLOR_BOARD
    material = ma.COLOR_BOARD
    overlay_k = ok.OVERLAY_CF
    shade_row = ok.RW1
    wrap_k = ok.WRAP_CB

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            option owner

        super_maya: Maya
            deco type

        k_path: tuple
            Is the path to the Frame Button.
        """
        FrameOverlay.__init__(
            self, any_group, super_maya, k_path, do_matter, do_overlay
        )
