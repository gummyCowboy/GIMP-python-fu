#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_key import Option as ok, Widget as wk
from roller_def_dialog import (
    ADD,
    ADD_ALT,
    BLUR_BELOW,
    BRUSH_P_D,
    FILLER_CC,
    FILLER_CP,
    FILLER_LF,
    FILLER_LM,
    FILLER_RM,
    FILLER_RW,
    FILLER_SC,
    FILLER_SG,
    FILLER_SP,
    FILLER_ST,
    FILLER_WF,
    OVERLAY_CF,
    OVERLAY_CP,
    OVERLAY_BB,
    OVERLAY_FO,
    SHADOW,
    SHADOW_BASIC,
    STENCIL,
    TAPE,
    WRAP,
    WRAP_ABOVE,
    WRAP_ALT,
    WRAP_BB,
    WRAP_BJ,
    WRAP_CB,
    WRAP_CF,
    WRAP_CP,
    WRAP_CS,
    WRAP_GL,
    WRAP_HG,
    WRAP_PR,
    WRAP_SB,
    WRAP_SW
)
from roller_widget_row import WidgetRow

# Ball Joint___________________________________________________________________
BALL_JOINT = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_BJ, deepcopy(WRAP_BJ)),
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Boxy Bevel___________________________________________________________________
BOXY_BEVEL = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_BB, deepcopy(WRAP_BB)),
            (ok.OVERLAY_BB, OVERLAY_BB)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.BLUR_BELOW, deepcopy(BLUR_BELOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Brush Punch__________________________________________________________________
BRUSH_PUNCH = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_ALT, deepcopy(WRAP_ALT)),
            (ok.BRUSH_D1, deepcopy(BRUSH_P_D)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Camo Planet__________________________________________________________________
CAMO_PLANET = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_ALT, deepcopy(WRAP_ABOVE)),
            (ok.OVERLAY_CP, OVERLAY_CP)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.BLUR_BELOW, deepcopy(BLUR_BELOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])
CAMO_PLANET[ok.BRW][wk.SUB][ok.WRAP_ALT][wk.SUB][ok.WIDTH][wk.VAL] = 30.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Ceramic Chip_________________________________________________________________
CERAMIC_CHIP = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_ALT, deepcopy(WRAP_ALT)),
            (ok.FILLER_CC, FILLER_CC),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Circle Punch_________________________________________________________________
CIRCLE_PUNCH = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_CP, FILLER_CP)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Clear Frame__________________________________________________________________
CLEAR_FRAME = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_CF, deepcopy(WRAP_CF)),
            (ok.OVERLAY_CF, deepcopy(OVERLAY_CF))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.BLUR_BELOW, deepcopy(BLUR_BELOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Color Board__________________________________________________________________
COLOR_BOARD = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_CB, deepcopy(WRAP_CB)),
            (ok.OVERLAY_CF, deepcopy(OVERLAY_CF))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.BLUR_BELOW, deepcopy(BLUR_BELOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])
a = COLOR_BOARD[ok.BRW][wk.SUB][ok.OVERLAY_CF][wk.SUB]
a[ok.COLOR_1][wk.VAL] = 255, 255, 255
a[ok.OPACITY][wk.VAL] = 100.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Color Pipe___________________________________________________________________
COLOR_PIPE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_CP, deepcopy(WRAP_CP)),
            (ok.OVERLAY_CF, deepcopy(OVERLAY_CF))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.BLUR_BELOW, deepcopy(BLUR_BELOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Corner Tape__________________________________________________________________
CORNER_TAPE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.TAPE, deepcopy(TAPE)),
            (ok.OVERLAY_CF, deepcopy(OVERLAY_CF))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.BLUR_BELOW, deepcopy(BLUR_BELOW)),
            (ok.SHADOW_BASIC, deepcopy(SHADOW_BASIC))
        ]),
        wk.WIDGET: WidgetRow
    })
])
a = CORNER_TAPE[ok.BRW][wk.SUB][ok.OVERLAY_CF][wk.SUB]
a[ok.COLOR_1][wk.VAL] = 230, 220, 210
a[ok.OPACITY][wk.VAL] = 15.
a[ok.MODE][wk.VAL] = "Normal"
a = CORNER_TAPE[ok.RW1][wk.SUB][ok.SHADOW_BASIC][wk.SUB]
a[ok.INTENSITY][wk.VAL] = 75.
a[ok.BLUR][wk.VAL] = 7.
a[ok.BLUR][wk.RANDOM_Q] = 2., 10.
a = CORNER_TAPE[ok.RW1][wk.SUB][ok.BLUR_BELOW][wk.SUB]
a[ok.SWITCH][wk.VAL] = 1
a[ok.MOD][wk.SUB][
    ok.BLUR].update({wk.VAL: 3., wk.RANDOM_Q: (1., 6.)})
a[ok.MOD][wk.SUB][ok.SWITCH][wk.VAL] = 1.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Crumble Shell________________________________________________________________
CRUMBLE_SHELL = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_CS, deepcopy(WRAP_CS)),
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Frame Over___________________________________________________________________
FRAME_OVER = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.STENCIL, deepcopy(STENCIL)),
            (ok.OVERLAY_FO, OVERLAY_FO)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.BLUR_BELOW, deepcopy(BLUR_BELOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Gradient Level_______________________________________________________________
GRADIENT_LEVEL = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_GL, deepcopy(WRAP_GL)),
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Hot Glue_____________________________________________________________________
HOT_GLUE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_HG, deepcopy(WRAP_HG)),
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Line Fashion_________________________________________________________________
LINE_FASHION = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_LF, FILLER_LF)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Link Mirror__________________________________________________________________
LINK_MIRROR = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_LM, FILLER_LM)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Paint Rush___________________________________________________________________
PAINT_RUSH = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_PR, deepcopy(WRAP_PR)),
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Rad Wave_____________________________________________________________________
RAD_WAVE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_RW, FILLER_RW)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Raised Maze__________________________________________________________________
RAISED_MAZE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_RM, FILLER_RM)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Shape Burst__________________________________________________________________
SHAPE_BURST = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_SB, deepcopy(WRAP_SB)),
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Square Cut___________________________________________________________________
SQUARE_CUT = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_SC, FILLER_SC)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Square Punch_________________________________________________________________
SQUARE_PUNCH = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_SP, FILLER_SP)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Stained Glass________________________________________________________________
STAINED_GLASS = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_ALT, deepcopy(WRAP_ALT)),
            (ok.FILLER_SG, FILLER_SG),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Sticky Wobble________________________________________________________________
STICKY_WOBBLE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_SW, deepcopy(WRAP_SW)),
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Stretch Tray_________________________________________________________________
STRETCH_TRAY = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_ALT, deepcopy(WRAP_ALT)),
            (ok.FILLER_ST, FILLER_ST),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])

# Wire Fence___________________________________________________________________
WIRE_FENCE = OrderedDict([
    (ok.BRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_WF, FILLER_WF)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.ADD_ALT, deepcopy(ADD_ALT)),
            (ok.SHADOW, deepcopy(SHADOW))
        ]),
        wk.WIDGET: WidgetRow
    })
])
