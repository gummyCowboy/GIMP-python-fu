#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import MAX_SIZE, Issue as vo
from roller_constant_key import Option as ok, Widget as wk
from roller_def_act import set_issue
from roller_one_tip import Tip
from roller_widget_number_pair import RectPair

RECTANGLE = OrderedDict([
    (ok.POSITION_X, {
        wk.AXIS: 'x',
        wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
        wk.VAL: 0.,
        wk.WIDGET: RectPair
    }),
    (ok.POSITION_Y, {
        wk.AXIS: 'y',
        wk.LIMIT: (-MAX_SIZE, MAX_SIZE),
        wk.VAL: 0.,
        wk.WIDGET: RectPair
    }),
    (ok.CELL_W, {
        wk.AXIS: 'x',
        wk.LIMIT: (0, MAX_SIZE),
        wk.TIPS: (Tip.END_X,),
        wk.VAL: (.0, 1.),
        wk.WIDGET: RectPair
    }),
    (ok.CELL_H, {
        wk.AXIS: 'y',
        wk.LIMIT: (0, MAX_SIZE),
        wk.TIPS: (Tip.END_Y,),
        wk.VAL: (.0, 1.),
        wk.WIDGET: RectPair
    })
])
set_issue(RECTANGLE, (), vo.MATTER, ())
