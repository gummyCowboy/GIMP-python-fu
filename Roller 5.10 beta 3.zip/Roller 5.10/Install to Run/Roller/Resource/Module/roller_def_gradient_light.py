#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Issue as vo
from roller_constant_key import (
    Button as bk, Material as ma, Option as ok, Widget as wk
)
from roller_def_act import make_heat_tip, set_issue
from roller_def_dialog import GMR
from roller_def_option import (
    GRADIENT_END_X,
    GRADIENT_END_Y,
    GRADIENT_START_X,
    GRADIENT_START_Y,
    GRADIENT_TYPE,
    OFFSET,
    RANDOM,
    REVERSE,
    SWITCH
)
from roller_port_heat import PortHeat
from roller_widget_heat import HeatRow
from roller_widget_option_button import HeatButton
from roller_widget_row import WidgetRow

# Heat Row_____________________________________________________________________
HEAT = {
    wk.CHANGELESS: True,
    wk.DIALOG: PortHeat,
    wk.SUB: OrderedDict([
        (ma.BACKDROP, {
            wk.VAL: {ok.MODE: "Normal", ok.OPACITY: .0},
            wk.WIDGET: HeatRow
        })
    ]),
    wk.TIPPER: make_heat_tip,
    wk.VAL: OrderedDict([(ma.BACKDROP, {ok.MODE: "Normal", ok.OPACITY: .0})]),
    wk.WIDGET: HeatButton
}


GRADIENT_LIGHT = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.START_X, deepcopy(GRADIENT_START_X)),
    (ok.START_Y, deepcopy(GRADIENT_START_Y)),
    (ok.END_X, deepcopy(GRADIENT_END_X)),
    (ok.END_Y, deepcopy(GRADIENT_END_Y)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.REVERSE, deepcopy(REVERSE)),
    (ok.RW1, deepcopy(GMR)),
    (ok.RW2, {
        wk.SUB: OrderedDict([
            (ok.HEAT, deepcopy(HEAT)),
            (bk.RANDOM, deepcopy(RANDOM))
        ]),
        wk.WIDGET: WidgetRow
    })
])
set_issue(GRADIENT_LIGHT, None, vo.MATTER, (ok.HEAT,))
