#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import PlanZ, Run
from roller_constant_for import Plan as fy
from roller_constant_key import Option as ok, SubMaya as sm
from roller_fu import select_rect
from roller_maya import MAIN, ImageRoll, check_matter
from roller_maya_backing import Backing, make_backing_layer
from roller_one_wip import Wip
from roller_option_group import ManyGroup
from roller_view_hub import color_selection_default
from roller_view_option_list import BackdropStyle
from roller_view_real import make_group


def check_plan_group(maya):
    """
    Create a Plan layer group.

    maya: Plan
    Return: layer group
        for Plan
    """
    if not maya.group:
        return make_plan_backdrop_group()
    return maya.group


def do_plan_matter(maya):
    """
    Create a Plan Backdrop layer.

    maya: Plan
    Return: matter layer
        Is a simulated Backing layer.
    """
    z = make_backing_layer(maya)

    select_rect(Run.j, *Wip.get_rect())
    color_selection_default(z, fy.BACKGROUND_COLOR)
    return z


def make_plan_backdrop_group():
    """
    Make a Plan Backdrop group.

    Return: layer group
        Backdrop simulation group
    """
    return make_group("Backdrop", PlanZ.plan_group)


class Backdrop(ManyGroup):
    """
    Create Widget group and assign a Backdrop
    step processor for each View type.
    """

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)


class Chi(ImageRoll):
    """Factor Plan and Work."""
    issue_q = 'matter',
    vote_type = MAIN

    def __init__(self, any_group, view_x, q):
        """
        any_group: AnyGroup
            A Preset is displayed as a Widget group in a navigation
            tree having a step key, a value dict, and change vote.

            Is the Backdrop option group.

        view_x: int
            Plan or Work; 0 or 1

        q: iterable
            layer output function
            Is from the Maya's 'put' attribute.
        """
        ImageRoll.__init__(self, any_group, view_x, q, ())
        self.set_issue()

    def prep(self):
        """Backdrop doesn't have any image reference."""
        return


class Plan(Chi):
    """Manage the Backdrop layer output for Draft and Plan."""
    put = (check_plan_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, Plan.put)
        self.do_matter = do_plan_matter

    def dig(self):
        """
        Manage Backdrop layer for a View run.

        Return: None
            for undo
        """
        self.realize_vote()


class Work(Chi):
    """
    Manage the Backdrop layer output for Peek, Preview and the final render.
    """
    put = ()

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Has options.
        """
        Chi.__init__(self, any_group, 1, Work.put)

        cast_maya = self.sub_maya[sm.BACKING] = Backing(any_group)
        self.sub_maya[sm.BACKDROP_STYLE] = BackdropStyle(
            any_group, cast_maya, (ok.BACKDROP_STYLE,)
        )

    def dig(self):
        """
        Manage Backdrop layer for a View run.

        Return: None
            for undo
        """
        d = self.value_d
        backing = self.sub_maya[sm.BACKING]

        self.realize()

        # Is Backing Maya change boolean state, 'm'.
        m = backing.do(d[ok.BACKING])

        self.sub_maya[sm.BACKDROP_STYLE].do(
            d[ok.BACKDROP_STYLE], m, backing.matter
        )
        self.reset_issue()
