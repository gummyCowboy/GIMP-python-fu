#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Deco, Pot, Run
from roller_constant_for import Justification as ju, Resize as fz
from roller_constant_key import Option as ok
from roller_deco import (
    make_main_face_mask,
    make_main_facing_mask,
    make_cell_face_mask,
    make_cell_facing_mask,
    attach_mask_sel,
    make_mask_sel,
    ready_canvas_rect,
    ready_shape
)
from roller_fu import (
    clear_inverse_selection,
    copy_all_image,
    get_item_size,
    load_selection,
    paste_image,
    paste_layer,
    select_item,
    select_rect,
    select_shape,
    verify_layer,
    verify_layer_group
)
from roller_many_rect import Rect
from roller_one import seal
from roller_polygon import (
    calc_circumradius, get_extreme, get_bounds, rotate_points, shift_center
)
from roller_view_hub import do_mod
from roller_view_real import clip_to_view, get_light, make_matter_group
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def apply_shape_mask(z, shape):
    """
    Select a shape and clear pixel outside of it.

    z: layer
        target of the clear op

    shape: tuple
        Is a polygon shape's x, y series.
    """
    select_shape(z.image, shape)
    clear_inverse_selection(z)


def calc_lock(w, h, w1, h1):
    """
    Return the size of an image that will fit into a cell.

    w, h: float
        image size
        (width, height)

    w1, h1: float
        cell size
        (width, height)
        Conform the image size to this size.
    """
    if w and h:
        w_r = w1 / w
        h_r = h1 / h

        if w_r > h_r:
            w, h = w * h_r, h1
        else:
            w, h = w1, h * w_r

    else:
        # underflow
        return 1., 1.
    return max(w, 1.), max(h, 1.)


def calc_mold_angle(d):
    """
    If an image is rotated, calculate the rotated rectangle's
    corner points. The image is first rotated, and then the
    rotated image rectangle is fitted to the pocket rectangle.

    maya: Maya
    """
    f = d[ok.ANGLE]
    if f:
        q = shift_center(Pot.mold.foam(), *Pot.mold.center())
        q = rotate_points(
            q, Pot.pocket, calc_circumradius(*Pot.source.size), f
        )
        Pot.foam = fit_coord_in_rect(q, Pot.pocket)
        Pot.mold.rect = get_bounds(Pot.foam)


def do(maya, make):
    """
    Prepare to place image.

    maya: Maya
    make: function
        Call to make an image layer.

    Return: layer or None
        with image
    """
    d = maya.value_d

    if not Run.x:
        # Preserve.
        mode = d[ok.MODE]

        # Plan override.
        d[ok.MODE] = "Normal"

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.x:
        # Restore.
        d[ok.MODE] = mode
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Place image for the Canvas-branch option.

    maya: Maya
    Return: layer or None
        image matter
    """
    return do(maya, make_canvas)


def do_cell(maya):
    """
    Place image for Per Cell.

    maya: Maya
    Return: layer or None
        with image
    """
    return do(maya, make_per_cell)


def do_face(maya):
    """
    Place image for Per Cell Face.

    maya: Maya
    make: function
        Call to produce the layer output.

    Return: layer or None
        with material
    """
    return do(maya, make_cell_face)


def do_facing(maya):
    """
    Place image for Per Cell Face.

    maya: Maya
    make: function
        Call to produce the layer output.

    Return: layer or None
        with material
    """
    return do(maya, make_cell_facing)


def do_main_cell(maya):
    """
    Place image for the Cell-branch main option settings.

    maya: Maya
    Return: layer or None
        with material
    """
    return do(maya, make_main)


def do_main_face(maya):
    """
    Place image for the Face-branch main option settings.

    maya: Maya
    Return: layer or None
        with image material
    """
    return do(maya, make_main_face)


def do_main_facing(maya):
    """
    Place image for the Face-branch main option settings.

    maya: Maya
    Return: layer or None
        with image material
    """
    return do(maya, make_main_facing)


def fit_coord_in_rect(q, rect):
    """
    Given a rectangle polygon of points, calculate
    their position inside another rectangle.

    q: list
        x, y series
        8 total
        rectangle points

    rect: Rect
        Is the bounds for the coordinates.

    Return: list
        with coordinates
    """
    # list of coordinate, point ordered, inside pocket rectangle, 'q1'
    q1 = []

    left, top, right, bottom = get_extreme(q)
    input_w = right - left
    input_h = bottom - top
    is_fit = rect.w >= input_w and rect.h >= input_h

    if not is_fit:
        center_x, center_y = rect.center()
        lock_w, lock_h = calc_lock(input_w, input_h, *rect.size)
        lock_x = center_x - lock_w / 2.
        lock_y = center_y - lock_h / 2.

        for i in range(0, 8, 2):
            # Transform size, one coordinate per side.
            x, y = q[i], q[i + 1]

            ratio_x = (x - left) / input_w
            ratio_y = (y - top) / input_h
            x = lock_w * ratio_x + lock_x
            y = lock_h * ratio_y + lock_y
            q1 += [x, y]
        return q1
    return q


def i_make_cell_face_mask(maya, d):
    """
    Apply a mask to a Cell/Per image.

    maya: Image Per Cell Maya
    Return: mask layer or None
    """
    return make_cell_face_mask(maya, d)


def i_make_cell_facing_mask(maya, d):
    """
    Apply a mask to a Cell/Per image.

    maya: Mask
    d: dict
        Mask Preset

    Return: mask layer or None
    """
    return make_cell_facing_mask(maya, d)


def i_make_main_face_mask(maya, d):
    """
    Apply mask option to main Face/Image.

    maya: Mask
    d: dict
        Mask Preset

    Return: mask layer or None
    """
    return make_main_face_mask(maya, d)


def i_make_main_facing_mask(maya, d):
    """
    Apply mask option to main Facing/Image.

    maya: Mask
    d: dict
        Mask Preset

    Return: mask layer or None
    """
    return make_main_facing_mask(maya, d)


def justify_mold(n):
    """
    Adjust the mold position per the image justification.

    n: string
        justification type
    """
    mold = Pot.mold
    x, y = mold.position
    pocket = Pot.pocket
    w, h = mold.size

    if w != pocket.w:
        # x-vector position
        if n in ju.CENTER_X:
            x1 = pocket.w / 2. - w / 2. + pocket.x

        elif n in ju.LEFT:
            x1 = pocket.x
        else:
            # right
            x1 = pocket.x + pocket.w - w

    else:
        x1 = pocket.x

    if h != pocket.h:
        # y-vector position
        if n in ju.CENTER_Y:
            y1 = pocket.h / 2. - h / 2. + pocket.y

        elif n in ju.TOP:
            y1 = pocket.y
        else:
            # bottom
            y1 = pocket.y + pocket.h - h

    else:
        y1 = pocket.y

    mold.position = x1, y1
    if Pot.foam and (x != x1 or y != y1):
        # Adjust foam to justification.
        w1 = x1 - x
        h1 = y1 - y
        q = Pot.foam

        # adjusted foam, 'q1'
        q1 = []

        for i in range(0, len(q), 2):
            x, y = q[i], q[i + 1]
            q1 += [x + w1, y + h1]
        Pot.foam = q1


def make_canvas(maya, d):
    """
    Place a Canvas Image.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        image material
    """
    image = maya.get_image(None)
    if image:
        ready_canvas_rect(maya, d, option=None)
        Pot.pocket.rect = maya.rect
        return verify_layer(
            place_image(maya, d, maya.group, image.j, False)
        )


def make_cell(maya, d, group, is_main=False):
    """
    Place an Image in a cell.

    maya: Maya
    d: dict
        Image Preset

    group: layer
        Is the parent layer for image output.

    is_main: bool
        Is True when the caller is the main cell Maya version.

    Return: layer or None
        with image material
    """
    # Image instance, 'image'
    image = maya.get_image(maya.k)

    if image:
        ready_shape(maya, d, option=None)

        Pot.pocket = maya.model.get_pocket(maya.k)
        return verify_layer(
            place_image(maya, d, group, image.j, is_main)
        )


def make_cell_face(maya, d):
    """
    Place image for Per Cell Face.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        with material
    """
    return produce_per_facing(maya, d, make_face)


def make_cell_facing(maya, d):
    """
    Place image for Cell/Per Facing.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        with material
    """
    return produce_per_facing(maya, d, make_facing)


def make_face(maya, d, group, is_main=False):
    """
    Make Face Fringe material.

    maya: Maya
    d: dict
        Image Preset

    group: layer
        Is the destination of Face output.

    is_main: bool
        Main Maya Cell image output is placed on the same layer.
    """
    k = maya.k
    model = maya.model
    image = maya.get_image(k)

    Pot.pocket = model.get_facing_merged(k)
    maya.rect = model.get_facing_rect(k)
    Deco.shape = model.get_facing_shape(k)
    if image:
        place_image(maya, d, group, image.j, is_main)


def make_facing(maya, d, group, is_main=False):
    """
    Make Face Fringe material.

    maya: Maya
    d: dict
        Image Preset

    group: layer
        Is the destination of Face output.

    is_main: bool
        Main Maya Cell image output is placed on the same layer.
    """
    k = maya.k
    model = maya.model
    image = maya.get_image(k)
    if image:
        Pot.pocket = model.get_facing_merged(k)
        place_image(maya, d, group, image.j, is_main)


def make_per_cell(maya, d):
    """
    Is needed for its argument signature.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        image material
    """
    return verify_layer(make_cell(maya, d, maya.group))


def mask_main_cell(maya, d):
    """
    Apply mask to image on a main option layer.

    maya: Maya
    d: dict
        Mask Preset

    Return: mask layer or None
    """
    j = Run.j
    z = maya.matter
    sel = None
    model = maya.model

    pdb.gimp_selection_none(j)

    for k in maya.main_q:
        maya.k = k
        image_sel = model.get_image_sel(k)
        if image_sel:
            load_selection(j, image_sel)

            if not pdb.gimp_selection_is_empty(j):
                make_mask_sel(maya, d)

            if sel:
                load_selection(j, sel, option=fu.CHANNEL_OP_ADD)
                pdb.gimp_image_remove_channel(j, sel)
            if not pdb.gimp_selection_is_empty(j):
                sel = pdb.gimp_selection_save(j)

    if sel:
        pdb.gimp_image_remove_channel(j, sel)
    return attach_mask_sel(z)


def make_main(maya, d):
    """
    Place image for Cell branch main option settings.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        with image material
    """
    return produce_main(maya, d, make_cell)


def make_main_face(maya, d):
    """
    Place image for Face main option settings.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        with material
    """
    return produce_main(maya, d, make_face)


def make_main_facing(maya, d):
    """
    Place image for Face main option settings.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        with material
    """
    return produce_main(maya, d, make_facing)


def mold_cover(maya, d, j):
    """
    Resize an image using the Cover Resize Method.

    d: dict
        Image Preset

    j: GIMP image
        WIP

    Return: GIMP image
        WIP
    """
    b = Pot.pocket
    w, h = b.w, b.h
    w1, h1 = get_item_size(j)

    # Is small and not a Face image, 'is_small'.
    is_small = w1 <= w and h1 <= h and not maya.is_face

    trim(d, b, w1, h1, is_trim=not is_small)

    if is_small:
        x1 = b.x + b.w
        y1 = b.y + b.h

        # Transform uses foam.
        Pot.foam = (
            b.x, b.y,
            x1, b.y,
            b.x, y1,
            x1, y1
        )

        # Rotation uses rectangle.
        Pot.mold.rect = b.rect
    return j


def mold_crop(maya, d, j):
    """
    Set the mold and source rectangle for a Crop Resize Method.

    maya: Maya
    d: dict
        Image Preset

    j: GIMP image
        WIP

    Return: GIMP image
        WIP
    """
    b = Pot.pocket
    source = Pot.source
    w, h = get_item_size(j)
    e = d[ok.RW1][ok.RESIZE]

    # Limit the crop rectangle size to the image size.
    x = seal(e[ok.CROP_X], 1., w - 1.)
    y = seal(e[ok.CROP_Y], 1., h - 1.)
    source.rect = (
        x, y,
        seal(e[ok.CROP_W], 1., w - x),
        seal(e[ok.CROP_H], 1., h - y)
    )

    source.rect = trim_oversize(d[ok.JUSTIFICATION], b, source)
    Pot.mold.rect = .0, .0, source.w, source.h

    # Source pixel is copied without resizing.
    Pot.is_small = True

    return j


def mold_factor(maya, d, j):
    """
    Resize an image by multiplying its size by a factor.

    maya: Maya
    d: dict
        Image Preset

    j: GIMP image
        WIP

    Return: GIMP image
        WIP
    """
    b = Pot.pocket
    source = Pot.source
    e = d[ok.RW1][ok.RESIZE]
    w, h = e[ok.FIW], e[ok.FIH]

    # Check to see if the source image is resized.
    if w != 1. or h != 1.:
        # Create a resized source image to replace the original.
        copy_all_image(j)

        j1 = paste_image()
        if j1:
            # Remove 'temp_image' in 'place_image'.
            j = Pot.temp_image = j1

            w = j.width * w
            h = j.height * h

            pdb.gimp_item_transform_perspective(
                j.layers[0], .0, .0, w, .0, .0, h, w, h
            )
            pdb.gimp_image_resize_to_layers(j)

    source.rect = [.0, .0] + get_item_size(j)
    source.rect = trim_oversize(d[ok.JUSTIFICATION], b, source)
    Pot.mold.rect = .0, .0, source.w, source.h

    # Source pixel is copied without resizing.
    Pot.is_small = True

    return j


def mold_fill(maya, d, j):
    """
    Set the mold and source rectangle for a Fill Resize Method.

    maya: Maya
    d: dict
        Image Preset

    j: GIMP image
        WIP

    Return: GIMP image
        to be placed
    """
    b = Pot.pocket
    Pot.source.rect = [.0, .0] + get_item_size(j)
    Pot.is_small = Pot.source.w == b.w and Pot.source.h == b.h
    Pot.mold.rect = Pot.pocket.rect
    return j


def mold_fixed(maya, d, j):
    """
    Resize an image with Fixed Resize Method.

    maya: Maya
        not used

    d: dict
        Image Preset

    j: GIMP image
        WIP

    Return: GIMP image
        to be placed
    """
    b = Pot.pocket
    source = Pot.source
    e = d[ok.RW1][ok.RESIZE]
    w, h = e[ok.FIXED_SIZE_W], e[ok.FIXED_SIZE_H]

    # Check to see if a new image is needed.
    w1, h1 = get_item_size(j)

    if (w, h) != (w1, h1):
        # Create a resized source image to replace the original.
        copy_all_image(j)

        j1 = paste_image()
        if j1:
            # Remove 'temp_image' in 'place_image'.
            j = Pot.temp_image = j1

            pdb.gimp_item_transform_perspective(
                j.layers[0], .0, .0, w, .0, .0, h, w, h
            )
            pdb.gimp_image_resize_to_layers(j)

    source.rect = [.0, .0] + get_item_size(j)
    source.rect = trim_oversize(d[ok.JUSTIFICATION], b, source)
    Pot.mold.rect = .0, .0, source.w, source.h

    # Source pixel is copied without resizing.
    Pot.is_small = True

    return j


def mold_lock(maya, d, j):
    """
    Determine the size of a mold rectangle given a pocket rectangle,
    and a Locked Aspect Ratio Resize Method. Set the source
    rectangle to the image size. Determine if the source image
    is smaller than the pocket rectangle.

    maya: Maya
        not used

    d: dict
        Image Preset
        not used

    j: GIMP image
        source pixel

    Return: GIMP image
        to be placed
    """
    b = Pot.pocket
    w, h = get_item_size(j)
    Pot.source.rect = .0, .0, w, h
    Pot.is_small = Pot.source.w <= b.w and Pot.source.h <= b.h

    if not Pot.is_small:
        # down-size
        w, h = calc_lock(w, h, *b.size)

    Pot.mold.rect = .0, .0, w, h
    return j


def mold_trim(maya, d, j):
    """
    Resize an image using the Trimmed Side Resize Method.

    maya: Maya
        not used

    d: dict
        Image Preset

    j: GIMP image
        source pixel

    Return: GIMP image
        to be placed
    """
    b = Pot.pocket
    w1, h1 = get_item_size(j)
    Pot.is_small = w1 <= b.w and h1 <= b.h

    if not Pot.is_small:
        trim(d, b, w1, h1)

    else:
        Pot.mold.rect = b.x, b.y, w1, h1
        Pot.source.rect = .0, .0, w1, h1
    return j


def paste_image_layer(maya, group):
    """
    Paste the clipboard and move the new layer to the top of layer group.

    group:
        Receive image.

    Return: layer
        the newly pasted layer
    """
    # Paste on top of the Backing layer.
    z = paste_layer(Run.j.layers[-1].layers[-1], group.name + " Material")

    pdb.gimp_image_reorder_item(Run.j, z, group, get_light(maya))
    return z


def place_image(maya, d, group, j, is_main):
    """
    Copy and paste an image after molding it to a cell.
    Molding takes an input image and produces a
    transformed image that fits inside a pocket rectangle.

    maya: Maya
    d: dict
        Image Preset

    group: layer
        Is the destination of layer output.

    j: GIMP image
        WIP to place

    is_main: bool
        Is true when the Maya is the main version.

    Return: image layer or None
        with image
    """
    Pot.foam = []
    k = maya.k
    model = maya.model
    resize_type = d[ok.RW1][ok.RESIZE][ok.TYPE]
    j = ROUTE_MOLD[resize_type](maya, d, j)

    calc_mold_angle(d)

    if resize_type not in (ok.COVER, ok.FILLED):
        justify_mold(d[ok.JUSTIFICATION])

    if maya.is_face:
        if resize_type in (ok.COVER, ok.FILLED):
            Pot.foam = model.get_facing_foam(k)
        else:
            p = model.get_facing_transform(k)
            Pot.foam = p(maya)

    source_rect = Pot.source.rect

    select_rect(j, *source_rect)
    pdb.gimp_edit_copy_visible(j)

    z = paste_image_layer(maya, group)
    z = transform_source(z)
    clip_to_view(z)

    if Pot.temp_image:
        pdb.gimp_image_delete(Pot.temp_image)
        Pot.temp_image = None

    if z:
        if not maya.is_face:
            if not model.is_rectangle:
                apply_shape_mask(z, Deco.shape)
            if is_main:
                select_item(z)
                model.set_image_sel(Run.j, k)
        else:
            model.clip_facing(z, k)
    return z


def produce_per_facing(maya, d, p):
    """
    Place image for Facing/Per.

    maya: Maya
    d: dict
        Image Preset

    p: function
        Call to create cell Face/Facing.

    Return: layer or None
        with material
    """
    group = make_matter_group(maya)

    p(maya, d, group)
    return verify_layer_group(group)


def produce_main(maya, d, p):
    """
    Place image for Face/Facing main option settings.

    maya: Maya
    d: dict
        Image Preset

    p: function
        Call to make Face/Facing.

    Return: layer or None
        with material
    """
    group = make_matter_group(maya)

    for k in maya.main_q:
        maya.k = k
        p(maya, d, group, is_main=True)
    return verify_layer_group(group)


def transform_source(z):
    """
    Transform an image into its destination mold rectangle.
    Crisp antialiasing on horizontal and vertical line by rounding coordinate.

    z: layer
        with material to transform

    Return: layer
        with transformed material
    """
    q = Pot.foam

    pdb.gimp_selection_none(Run.j)

    if q:
        # Coordinate is a float.
        # point order: topleft, top-right, bottom-left, bottom-right
        z = pdb.gimp_item_transform_perspective(z, *map(round, q))

    elif Pot.is_small:
        x, y = Pot.mold.position
        pdb.gimp_layer_set_offsets(z, int(round(x)), int(round(y)))

    else:
        # transform rectangle, 'a'.
        a = Pot.mold

        # I tried 'pdb.gimp_item_transform_perspective', but it fails
        # as it interpolates outside the layer boundary producing a soft
        # edged image for a rectangular image.
        pdb.gimp_context_set_antialias(0)

        # local origin, 'True'
        # Rectangle is integer.
        pdb.gimp_layer_scale(
            z, max(1, int(round(a.w))), max(1, int(round(a.h))), True
        )
        pdb.gimp_layer_set_offsets(z, int(round(a.x)), int(round(a.y)))
    return z


def trim(d, b, w1, h1, is_trim=True):
    """
    Trim a side of an over-sized image.

    d: dict
        Image Preset

    b: Rect
        pocket

    w1, h1: numeric
        width, height of image

    is_trim: bool
        If True, then calculate the mold rectangle.
    """
    source = Pot.source
    ratio_w = b.w / w1
    ratio_h = b.h / h1

    # the mold scale factor, 'f'.
    # the pocket scale factor, 'f1'
    if ratio_w < ratio_h:
        # The image height is closer to the pocket height.
        f = ratio_h
        f1 = h1 / b.h

    else:
        # The image width is closer to the pocket width.
        f = ratio_w
        f1 = w1 / b.w

    # Oversize the pocket to get a source rectangle, 'rect'.
    rect = Rect(b.x, b.y, b.w * f1, b.h * f1)
    source.rect = .0, .0, w1, h1
    source.rect = trim_oversize(d[ok.JUSTIFICATION], rect, source)

    if is_trim:
        # The mold rectangle is derived from the image rectangle.
        Pot.mold.rect = b.x, b.y, source.w * f, source.h * f


def trim_oversize(n, pocket, source):
    """
    Use to get the pocket scale for an over-sized rectangle. The
    justification determines the side(s) where clipping is applied.

    n: string
        image justification

    w, h: numeric
        size of Trim

    Return: tuple
        x, y, w, h
        the rectangle trimmed selection of the source image
    """
    w, h = pocket.size
    x1, y1, w1, h1 = source.rect

    # x-vector
    # Check for oversized vector.
    if w < w1:
        # oversized
        w2 = w

        if n in ju.CENTER_X:
            x2 = (w1 / 2. + x1) - w / 2.

        elif n in ju.LEFT:
            x2 = x1

        else:
            # right
            x2 = x1 + w1 - w

    else:
        # no change
        x2 = x1
        w2 = w1

    # y-vector
    if h < h1:
        # oversized
        h2 = h

        if n in ju.CENTER_Y:
            y2 = (h1 / 2. + y1) - h / 2.

        elif n in ju.TOP:
            y2 = y1
        else:
            # bottom
            y2 = y1 + h1 - h

    else:
        # no change
        y2 = y1
        h2 = h1
    return x2, y2, w2, h2


ROUTE_MOLD = {
    fz.CROP: mold_crop,
    fz.FACTOR: mold_factor,
    fz.FIXED: mold_fixed,
    ok.COVER: mold_cover,
    ok.FILLED: mold_fill,
    ok.LOCKED: mold_lock,
    ok.TRIM: mold_trim
}
