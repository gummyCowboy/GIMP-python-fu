#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Globe, Run
from roller_a_gegl import edge, shift, waterpixels
from roller_constant_for import Backdrop as bs
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clone_layer,
    dilate,
    make_layer_group,
    merge_layer_group
)
from roller_maya_style import Style, make_background
from roller_view_hub import do_mod
from roller_view_real import add_sub_base_group, finish_style, insert_copy
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def make_style(maya):
    """
    Make a style layer for the Acrylic Sky Backdrop Style.

    maya: Style
    Return: layer or None
        style layer
    """
    def copier(_n):
        """
        Copy the output.

        _n: string
            layer name of copy

        Return: layer
            the copy
        """
        return insert_copy(group, parent)

    if maya.go:
        j = Run.j
        d = maya.value_d
        parent = add_sub_base_group(maya)
        group = make_layer_group(j, "WIP", parent=parent)
        z = make_background(group)
        bg_z = clone_layer(z, n="Exclusion")
        z1 = clone_layer(z, n="Difference")
        z2 = clone_layer(z1, n="Subtract")
        z.mode = z2.mode = fu.LAYER_MODE_SUBTRACT
        z1.mode = fu.LAYER_MODE_DIFFERENCE

        blur_selection(z, 60)
        blur_selection(z1, 30)
        pdb.plug_in_gimpressionist(j, z2, "Furry")

        z = copier("LCH Lightness")
        z.mode = fu.LAYER_MODE_LCH_LIGHTNESS

        waterpixels(z, size=int(d[ok.SUPERPIXEL_SIZE]))

        z = clone_layer(z, n="Edge")

        edge(z)

        z = copier("Waterpixels")

        waterpixels(z)

        z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
        z = copier("Dilate")

        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)

        dilate(z)
        dilate(z)

        bg_z.mode = fu.LAYER_MODE_EXCLUSION

        blur_selection(bg_z, 500)
        pdb.gimp_image_reorder_item(j, bg_z, group, 0)

        z = merge_layer_group(group)

        # Create a paint brush texture.
        # I put 'int' on the RadioRow output,
        # SHIFT_DIRECTION, as a float got into a Preset.
        shift(
            z,
            bs.SHIFT_DIRECTION[int(d[ok.SHIFT_DIRECTION])].lower(),
            d[ok.SHIFT],
            int(d[ok.SEED] + Globe.seed)
        )

        blur_selection(z, 1)

        z = merge_layer_group(parent)

        do_mod(z, d[ok.BRW][ok.MOD])
        return finish_style(z, "Acrylic Sky")


class AcrylicSky(Style):
    """Create Backdrop Style output."""

    def __init__(self, any_group, super_maya, k_path):
        self.init_background(any_group, super_maya, k_path, make_style)
