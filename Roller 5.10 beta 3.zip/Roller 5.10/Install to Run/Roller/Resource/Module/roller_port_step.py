#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_a_contain import The
from roller_constant_for import Signal as si, Widget as fw
from roller_constant_key import (
    Button as bk,
    ModelList as ml,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_model_id import ModelId
from roller_one_helm import Helm
from roller_one_shelf import Shelf
from roller_port_process import PortProcess
from roller_view_step import get_model_branch_key, make_panel_key
from roller_widget_model_step import ModelStep
from roller_widget_button import (
    AcceptButton, AcceptAllButton, AcceptNoneButton, CancelButton
)
from roller_widget_row import WidgetRow


class PortModelStep(PortProcess):
    """
    Is a display container for a Model step manager.

    A step key has three variations: navigation, panel, and render.
    The three variations are caused by a different Model reference.
        navigation: Model id
        panel: Model name
        render: Model type

    If the Model isn't referenced in the step key, then the
    step key is the same for all three variations.
    """
    window_key = "Model Step"

    def __init__(self, d, g):
        """
        g: Button
            Is responsible.
        """
        self._model_tree = None
        self._model_step_button = g
        PortProcess.__init__(self, d, g)

    def _draw_lists(self, box):
        """
        Draw, load, and verify the Model Step option group.

        box: GTK container
            to receive group
        """
        # Collect the Model branch step.
        # the interface step key of Model branch, 'step_q'
        step_q = Helm.get_all_step_q()

        # Reduce for readability.
        get_name = ModelId.get_name

        # Is a set of Model branch render step key, 'q'.
        q = set()

        for i in step_q:
            # Model reference index, '0'
            if i and isinstance(i[0], int):
                q.update({(get_name(i[0]),) + get_model_branch_key(i)})

        self._model_tree = ModelStep(
            self._model_step_button,
            q,
            **{
                wk.COLOR: self.color,
                wk.RELAY: [],
                wk.ROLLER_WIN: self.roller_win
            }
        )
        box.add(self._model_tree)

    def draw(self):
        """Draw Widget."""
        self.draw_column((self._draw_lists, self.draw_step_process))

    def draw_step_process(self, box):
        """
        Draw a Widget group with Cancel and Accept options.

        box: GTK Box container
            to receive group
        """
        g = WidgetRow(
            **{
                wk.PADDING: (0, 0, fw.MARGIN, fw.MARGIN),
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win,
                wk.SUB: OrderedDict([
                    (bk.CANCEL, {wk.WIDGET: CancelButton}),
                    (bk.ACCEPT_NONE, {wk.WIDGET: AcceptNoneButton}),
                    (bk.ACCEPT_ALL, {wk.WIDGET: AcceptAllButton}),
                    (bk.ACCEPT, {wk.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        box.add(g)

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return lambda: None, self.on_accept_model_step

    def on_accept_model_step(self, g):
        """
        Modify the navigation step tree with a new tree.

        g: Widget
            Is responsible or is in focus.
        """
        model_def = []
        tree_step = []
        get_group = Helm.get_group
        node = get_group(sk.STEPS).item.node
        model_list_g = get_group(sk.MODEL).widget_d[ok.MODEL_LIST]

        # ModelList definition with all Models,
        # shelved and active, 'all_def'
        all_def = model_list_g.get_model_def()

        # Ordered active Model name list, 'active_name_q'.
        active_name_q = model_list_g.get_active_model_name_q()

        # list of active and shelved Model name, 'all_def_name_q'
        all_def_name_q = [i[ml.NAME_INDEX] for i in all_def]

        if g.key != bk.ACCEPT_NONE:
            tree_step = self._model_tree.get_a(is_all=g.key == bk.ACCEPT_ALL)

        # the user chosen Model name set, 'model_name_q'
        model_name_q = {i[ml.NAME_INDEX] for i in tree_step}

        # new render step key list, 'new_step_q'
        new_step_q = tree_step[:]

        # Init the Model definition list in the existing order.
        for i in active_name_q:
            if i in model_name_q:
                x = all_def_name_q.index(i)
                model_def += [(i, all_def[x][ml.TYPE_INDEX])]
                model_name_q -= {i}

        # Newly added Model are tacked onto the end of Model definition list.
        for i in model_name_q:
            x = all_def_name_q.index(i)
            model_def += [(i, all_def[x][ml.TYPE_INDEX])]

        # Tell NodePanel to update itself.
        node.emit(si.UPDATE_TREE, (new_step_q + sk.DEFAULT_STEP, model_def))

        # Load Preset value dict from the Shelf for a former
        # shelved step. Remove a step key, from the Shelf,
        # if a step has moved to the navigation tree.

        # SuperPreset, 'e'
        # {navigation step key: value dict}
        e = {}

        for i in Helm.get_key_q():
            k = make_panel_key(i)
            d = Shelf.get_step_d(k)
            if d:
                # Add to the SuperPreset for loading.
                e[i] = d
                Shelf.remove_step(k)

        if e:
            The.preset.load_super(e)
        self.repo.any_group.changed()
