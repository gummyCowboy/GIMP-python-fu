#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_port_preview import PortPreview
from roller_widget_node import Piece


# PortGeneric__________________________________________________________________
class PortGeneric(PortPreview):
    """Is a display container for a Preset."""

    def __init__(self, d, g, k, is_random=True):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Is responsible.

        k: string
            Preset Option key
        """
        self._is_random = is_random
        self._preset_k = k
        PortPreview.__init__(self, d, g)

    def _draw(self, box):
        """
        Draw the Preset option group.

        box: GTK container
            to receive group
        """
        self.draw_group(Piece(
            self._preset_k, box, self.repo.any_group.item, has_label=False
        ))

    def draw(self):
        """Draw Widget."""
        p = self.draw_random_process_group if self._is_random \
            else self.draw_process
        self.draw_column((self._draw, p))

    def get_group_value(self):
        """
        Get the Preset value dict.

        Return: dict
            Preset
        """
        return self.preset.get_a()


class PortAdd(PortGeneric):
    window_key = "Add"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.ADD, is_random=False)


class PortAddAbove(PortGeneric):
    window_key = "Add"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.ADD_ABOVE, is_random=False)


class PortAltAdd(PortGeneric):
    window_key = "Add"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.ADD_ALT, is_random=False)


class PortBacking(PortGeneric):
    window_key = "Backing"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.BACKING)


class PortBlurBelow(PortGeneric):
    window_key = "Blur Below"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.BLUR_BELOW)


class PortBrush(PortGeneric):
    window_key = "Brush"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.BRUSH_D)


class PortBrushPD(PortGeneric):
    window_key = "Brush"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.BRUSH_D1)


class PortBump(PortGeneric):
    window_key = "Bump"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.BUMP)


class PortMargin(PortGeneric):
    window_key = "Margin"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.MARGIN)


class PortMod(PortGeneric):
    window_key = "Mod"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.MOD)


class PortNoise(PortGeneric):
    window_key = "Noise"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.NOISE_D)


class PortResize(PortGeneric):
    window_key = "Resize"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.RESIZE, is_random=False)


class PortShadowBasic(PortGeneric):
    window_key = "Shadow Basic"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.SHADOW_BASIC)


class PortStencil(PortGeneric):
    window_key = "Stencil"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.STENCIL)


class PortStrip(PortGeneric):
    window_key = "Strip"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.STRIP)


class PortTape(PortGeneric):
    window_key = "Tape"

    def __init__(self, d, g):
        PortGeneric.__init__(self, d, g, ok.TAPE)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# PortFiller___________________________________________________________________
class PortFiller(PortGeneric):
    window_key = "Filler"

    def __init__(self, d, g, k):
        PortGeneric.__init__(self, d, g, k)


class PortCeramicChipFiller(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_CC)


class PortCirclePunchFiller(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_CP)


class PortLineFashionFiller(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_LF)


class PortLinkMirrorFiller(PortFiller):

    def __init__(self, d, g):
        """d, g: PortGeneric spec"""
        PortFiller.__init__(self, d, g, ok.FILLER_LM)


class PortRadWaveFiller(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_RW)


class PortRaisedMazeFiller(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_RM)


class PortSquareCutFiller(PortFiller):
    """Is a display container for a Square Cut Filler Preset."""

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_SC)


class PortSquarePunchFiller(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_SP)


class PortStainedGlassFiller(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_SG)


class PortStretchTrayFiller(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_ST)


class PortWireFrameFiller(PortFiller):

    def __init__(self, d, g):
        PortFiller.__init__(self, d, g, ok.FILLER_WF)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# PortOverlay__________________________________________________________________
class PortOverlay(PortGeneric):
    window_key = "Overlay"

    def __init__(self, d, g, k):
        PortGeneric.__init__(self, d, g, k)


class PortBoxyBevelOverlay(PortOverlay):

    def __init__(self, d, g):
        PortOverlay.__init__(self, d, g, ok.OVERLAY_BB)


class PortCamoPlanetOverlay(PortOverlay):

    def __init__(self, d, g):
        PortOverlay.__init__(self, d, g, ok.OVERLAY_CP)


class PortColorOverlay(PortOverlay):

    def __init__(self, d, g):
        PortOverlay.__init__(self, d, g, ok.OVERLAY_CF)


class PortFrameOverOverlay(PortOverlay):

    def __init__(self, d, g):
        PortOverlay.__init__(self, d, g, ok.OVERLAY_FO)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# PortWrap_____________________________________________________________________
class PortWrap(PortGeneric):
    window_key = "Wrap"

    def __init__(self, d, g, k=ok.WRAP):
        PortGeneric.__init__(self, d, g, k)


class PortAltWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_ALT)


class PortBallJointWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_BJ)


class PortBoxyBevelWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_BB)


class PortClearFrameWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_CF)


class PortColorBoardWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_CB)


class PortColorPipeWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_CP)


class PortCrumbleShellWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_CS)


class PortGradientLevelWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_GL)


class PortHotGlueWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_HG)


class PortPaintRushWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_PR)


class PortShapeBurstWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_SB)


class PortStickyWobbleWrap(PortWrap):

    def __init__(self, d, g):
        PortWrap.__init__(self, d, g, k=ok.WRAP_SW)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
