#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import MaskGroup
from roller_fu import (
    clear_inverse_selection, clone_opaque_layer, remove_z, select_item
)
from roller_view_real import mask_sel
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Feather the cast and make a group mask.

    Return: layer
        group mask
    """
    j = v.j
    group = maya.cast.group
    z = clone_opaque_layer(maya.cast.matter)
    d = maya.value_d
    a = d[ok.FEATHER]
    f = a / d[ok.STEPS]
    b = f

    while a > b:
        select_item(z)
        pdb.gimp_selection_feather(j, b)

        b += f
        if not pdb.gimp_selection_is_empty(j):
            clear_inverse_selection(z)

    select_item(z)
    mask_sel(group)
    remove_z(z)
    return group.mask


class FeatherStep(MaskGroup):
    """Feather the edges of material."""

    def __init__(self, any_group, super_maya, k_path):
        """
        q: tuple
            MaskGroup spec

        d: dict
            MaskGroup spec
        """
        MaskGroup.__init__(self, any_group, super_maya, k_path, do_matter)
