#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Globe, Run
from roller_constant_key import Frame as ek, Material as ma, Option as ok
from roller_frame import (
    make_canvas_frame_sel, do_emboss_sel, select_frame
)
from roller_frame_alt import FrameBasic
from roller_fu import (
    dilate,
    load_selection,
    select_item,
    select_opaque,
    select_rect,
    verify_layer
)
from roller_one_wip import Wip
from roller_view_real import add_wip_layer, get_light
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def do_matter(maya):
    """
    Make the frame.

    maya: RaisedMaze
    Return: layer
        with the Frame
    """
    j = Run.j
    d = maya.value_d
    e = maya.super_maya.value_d[ok.BRW][ok.FILLER_RM]

    select_frame(j, maya.cast.matter, d[ok.WIDTH], d[ok.TYPE])

    sel = pdb.gimp_selection_save(j)

    # Canvas frame
    pdb.gimp_selection_none(j)
    make_canvas_frame_sel(e)

    sel1 = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)

    # layer for the maze, 'z'
    z = add_wip_layer("Raised Maze", None)

    pdb.gimp_context_set_foreground((0, 0, 0))
    pdb.gimp_context_set_background((255, 255, 255))
    pdb.plug_in_maze(
        j, z,
        int(max(1, Wip.w // e[ok.COLUMN])),   # passage scale
        int(max(1, Wip.h // e[ok.ROW])),      # passage scale
        1,                                      # yes, tileable
        0,                                      # depth first algorithm
        int(e[ok.SEED] + Globe.seed),
        0,                                      # multiple, not clearly defined
        0                                       # offset, not clearly defined
    )

    # amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(j, z, 1., 0, 0)

    w = max(1., e[ok.LINE_W] // 2. - 1.)

    for _ in range(int(w)):
        dilate(z)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    select_item(z)
    pdb.gimp_image_remove_layer(j, z)

    # layer for the combined frame, 'z'
    z = add_wip_layer("Material", maya.group, offset=get_light(maya))

    for i in (sel, sel1):
        load_selection(j, i, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, i)

    select_opaque(maya.cast.matter, option=fu.CHANNEL_OP_SUBTRACT)
    select_rect(Run.j, *Wip.get_rect(), option=fu.CHANNEL_OP_INTERSECT)
    return verify_layer(do_emboss_sel(z, d))


class RaisedMaze(FrameBasic):
    add_row = shade_row = ok.RW1
    filler_k = ok.FILLER_RM
    kind = ek.RAISED_MAZE
    material = ma.RAISED_MAZE
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
