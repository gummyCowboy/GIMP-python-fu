#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Shape as sh
from roller_many_rect import Rect
from roller_model_face import make_v_face

"""
The Cap Face is always a square. The Box direction
is also the Cap position. These Cap functions complete the
Cap attribute geometry according to the Cap's position.
"""


def bottom_arrange(q, w, h, center, a):
    """
    Arrange Face attribute geometry where the Cap
    is at the bottom of a Hexagon cell shape.

    q: tuple
        x, y float series, eight values defining four vertices
        cell shape

    w, h: float
        Is the size of the Face as a right rectangle.

    center: tuple
        (x, y) of float
        Is the center of the Shift rectangle.

    a: Rect
        Cell/Shift rectangle
    """
    x, y = q[10], center[1]

    # the size of the Cap square, 'w'
    w = max(w, h)
    x1 = x + w
    y1 = y + w
    a.merged = Rect(x, y, w, w)
    a.form = x, y, x1, y, x1, y1, x, y1
    a.shape = (
        x, q[11],
        q[2], y,
        q[6], q[7],
        q[8], q[9]
    )
    a.foam = (
        q[2], y,
        q[6], q[7],
        x, q[11],
        q[8], q[9],
    )


def left_arrange(q, w, h, center, a):
    """
    Arrange Face attribute geometry where the Cap
    is at the left of a HexagonTruncated cell shape.

    q: tuple
        x, y float series, eight values defining four vertices
        cell shape

    w, h: float
        Is the size of the Face as a right rectangle.

    center: tuple
        (x, y) of float
        Is the center of the Shift rectangle.

    a: Rect
        Cell/Shift rectangle
    """
    x, y = q[0], q[3]

    # the size of the Cap square, 'w'
    w = max(w, h)
    x1 = x + w
    y1 = y + w
    a.merged = Rect(x, y, w, w)
    a.form = x, y, x1, y, x1, y1, x, y1
    a.shape = (
        x, q[1],
        q[2], y,
        center[0], q[1],
        q[10], q[11]
    )
    a.foam = (
        q[2], y,
        center[0], q[1],
        x, q[1],
        q[10], q[11]
    )


def right_arrange(q, w, h, center, a):
    """
    Arrange Face attribute geometry where the Cap
    is at the right of a HexagonTruncated cell shape.

    q: tuple
        x, y float series, eight values defining four vertices
        cell shape

    w, h: float
        Is the size of the Face as a right rectangle.

    center: tuple
        (x, y) of float
        Is the center of the Shift rectangle.

    a: Rect
        Cell/Shift rectangle
    """
    x, y = center[0], q[3]

    # the size of the Cap square, 'w'
    w = max(w, h)
    x1 = x + w
    y1 = y + w
    a.merged = Rect(x, y, w, w)
    a.form = x, y, x1, y, x1, y1, x, y1
    a.shape = (
        x, q[1],
        q[4], q[5],
        q[6], q[7],
        q[8], q[9]
    )
    a.foam = (
        q[4], q[5],
        q[6], q[7],
        x, q[1],
        q[8], q[9]
    )


def top_arrange(q, w, h, center, a):
    """
    Arrange Face attribute geometry where the Cap
    is at the top of a Hexagon cell shape.

    q: tuple
        x, y float series, eight values defining four vertices
        cell shape

    w, h: float
        Is the size of the Face as a right rectangle.

    center: tuple
        (x, y) of float
        Is the center of the Shift rectangle.

    a: Rect
        Cell/Shift rectangle
    """
    x, y = q[0], q[3]

    # the size of the Cap square, 'w'
    w = max(w, h)
    x1 = x + w
    y1 = y + w
    a.merged = Rect(x, y, w, w)
    a.form = x, y, x1, y, x1, y1, x, y1
    a.shape = (
        x, q[1],
        q[2], y,
        q[4], q[5],
        q[2], center[1]
    )
    a.foam = (
        q[2], y,
        q[4], q[5],
        x, q[1],
        q[2], center[1]
    )


CAP_BUILD = {
    sh.BOTTOM: bottom_arrange,
    sh.LEFT: left_arrange,
    sh.RIGHT: right_arrange,
    sh.TOP: top_arrange
}
CAP_TRANSFORM = {
    sh.BOTTOM: make_v_face,
    sh.LEFT: make_v_face,
    sh.RIGHT: make_v_face,
    sh.TOP: make_v_face
}
