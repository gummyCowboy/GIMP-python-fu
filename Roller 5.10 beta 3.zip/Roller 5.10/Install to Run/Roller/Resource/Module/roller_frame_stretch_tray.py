#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Globe, Run
from roller_a_gegl import emboss
from roller_constant_for import Frame as ff
from roller_constant_key import (
    Frame as ek, Material as ma, Option as ok, SubMaya as sm
)
from roller_frame import (
    grow_frame, do_emboss_sel, remove_sel, sort_shadow_layer
)
from roller_frame_alt import AltFiller
from roller_fu import (
    apply_mask,
    clone_layer,
    clone_opaque_layer,
    load_selection,
    make_layer_group,
    merge_layer,
    merge_layer_group,
    remove_z,
    select_item,
    set_saturation
)
from roller_maya import (
    check_matter, check_mix_basic, make_group_shadow, make_group_wrap
)
from roller_maya_add import AltAdd
from roller_maya_build import Build, SubBuild
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_view_real import add_wip_layer, get_light
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def do_matter(maya):
    """
    Make a frame.

    maya: StretchTray
    Return: layer
        final output
    """
    for n in ('filler_sel', 'wrap_sel'):
        remove_sel(maya, n)

    maya.filler_sel = make_1st_frame_sel(maya)
    maya.wrap_sel = pdb.gimp_selection_save(Run.j)
    return add_wip_layer("Stretch Tray", maya.group)


def do_filler(maya):
    """
    Draw filler material.

    maya: AltFiller
    Return: layer
        Has ceramic chip.
    """
    j = Run.j
    d = maya.value_d

    # source layer, 'z'
    z = clone_opaque_layer(maya.cast.matter, n="Left")

    apply_mask(z)

    group = make_layer_group(
        j, "Stretch", parent=maya.group, z=z, offset=get_light(maya)
    )

    apply_mask(z)
    pdb.gimp_selection_none(j)

    for x, z in enumerate((
        z,
        clone_layer(z, n="Right"),
        clone_layer(z, n="Top"),
        clone_layer(z, n="Bottom")
    )):
        pdb.plug_in_wind(
            j, z,
            .0,                 # Threshold All
            x,                  # direction
            100,                # maximum strength
            0,                  # wind algorithm
            1,                  # leading edge
        )

        # threshold all pixel, '.0'
        pdb.plug_in_threshold_alpha(j, z, .0)

    # Make the wind output opaque.
    z = merge_layer_group(group)
    z1 = clone_opaque_layer(z)

    remove_z(z)
    pdb.gimp_drawable_curves_spline(
        z1,
        fu.HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .25, 1., .75)
    )
    set_saturation(z1, d)

    z2 = clone_layer(z1, n=z1.parent.name + " Material")
    z2.mode = fu.LAYER_MODE_HARDLIGHT
    z2.opacity = 80.

    pdb.gimp_drawable_curves_spline(
        z2,
        fu.HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .45, 1., .54)
    )

    # depth, '3'
    emboss(z2, Globe.azimuth, Globe.elevation, 3)

    return merge_layer(z2)


def make_1st_frame_sel(maya):
    """
    Make an inner and outer embossed frame.

    maya: StretchTray
    Return: GIMP selection channel and GIMP's state of selection
        Limit the filler area.
    """
    j = Run.j
    d = maya.value_d
    filler_d = maya.super_maya.value_d[ok.BRW][ok.FILLER_ST]
    cast = maya.cast.matter

    # Grow the selection for each frame part.
    select_item(cast)
    grow_frame(j, d[ok.WIDTH], d[ok.TYPE])

    # inner frame selection, 'sel'
    sel = pdb.gimp_selection_save(j)

    grow_frame(j, filler_d[ok.WIDTH], d[ok.TYPE])

    # inner and filler frame selection, 'sel1'
    sel1 = pdb.gimp_selection_save(j)

    grow_frame(j, d[ok.WIDTH], d[ok.TYPE])

    # inner, filler, and outer selection, 'sel2'
    sel2 = pdb.gimp_selection_save(j)

    load_selection(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

    # outer frame selection, 'sel3'
    sel3 = pdb.gimp_selection_save(j)

    load_selection(j, sel1)
    load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

    # Cover-up the emboss on the inner and outer frame.
    grow_frame(j, 1., ff.ANGULAR)

    filler_sel = pdb.gimp_selection_save(j)

    # Make an inner frame selection.
    load_selection(j, sel)
    select_item(cast, option=fu.CHANNEL_OP_SUBTRACT)
    load_selection(j, sel3, option=fu.CHANNEL_OP_ADD)

    for i in (sel, sel1, sel2, sel3):
        pdb.gimp_image_remove_channel(j, i)
    return filler_sel


def make_2nd_frame_sel(d, z, wrap_sel, filler_sel):
    """
    Make an inner and outer embossed frame.

    d: dict
        Wrap, Alt Preset

    z: layer
        Filler output

    wrap_sel: GIMP selection channel
        Define initial wrap.

    filler_sel: GIMP selection channel
        Limit filler area.

    Return: GIMP state of selection
    """
    j = Run.j

    load_selection(j, filler_sel)
    select_item(z, option=fu.CHANNEL_OP_INTERSECT)
    grow_frame(j, d[ok.WIDTH], d[ok.TYPE])
    select_item(z, option=fu.CHANNEL_OP_SUBTRACT)
    load_selection(j, wrap_sel, option=fu.CHANNEL_OP_ADD)


class StretchWrap(SubBuild):
    """Process change for a filler output."""
    filler_k = ok.FILLER_ST
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_wrap, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )
    wrap_k = ok.WRAP_ALT

    def __init__(self, any_group, super_maya, k_path):
        """
        super_maya: Maya
            Frame type

        k_path: tuple
            (Option key, ...)
            Are path key to its vote dict.
        """
        k_path = k_path + (ok.BRW, ok.WRAP_ALT)

        SubBuild.__init__(self, any_group, super_maya, k_path, do_matter)

        self.filler_sel = self.wrap_sel = None
        self.sub_maya[sm.ADD] = AltAdd(any_group, self, k_path + (ok.ADD_ALT,))
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.STRETCH_TRAY)

    def do(self, d, is_change, is_back):
        """
        Produce GIMP layer output. Has a filler
        layer and a Gradient Light layer.

        d: dict
            frame Preset

        is_change: bool
            Is True if the cast Maya has change.

        is_back: bool
            Is True if the background changed.

        Return: bool
            Is True if the wrap layer changed.
        """
        self.value_d = d
        m = self.is_matter = self.is_matter or is_change

        self.realize()

        if self.matter:
            self.sub_maya[sm.ADD].do(d[ok.ADD_ALT], m, m, is_back)
            self.sub_maya[sm.LIGHT].do(self.is_matter)

        else:
            self.die()

        self.reset_issue()
        return m

    def reset(self):
        """Call when the View image is removed."""
        for i in (self.filler_sel, self.wrap_sel):
            if i:
                pdb.gimp_image_remove_channel(Run.j, i)

        self.filler_sel = self.wrap_sel = None
        super(StretchWrap, self).reset()


class StretchTray(Build):
    filler_k = ok.FILLER_ST
    issue_q = ()
    kind = ek.STRETCH_TRAY
    material = ma.STRETCH_TRAY
    put = (make_group_shadow, 'group'),
    shade_row = ok.BRW
    wrap_k = ok.WRAP_ALT

    def __init__(self, any_group, super_maya, k_path):
        """
        Require the inheritor class to have a attributes 'wrap_k' and
        'filler_k'. Both are sub-row Option key to a wrap or filler dict.

        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Is the Key path of the Frame Button in its vote dict.
        """
        Build.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.WRAP] = StretchWrap(any_group, self, k_path)
        self.sub_maya[sm.FILLER] = AltFiller(
            any_group, self, k_path, do_filler, self.filler_k, ma.STRETCH_TRAY
        )
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group,
            self,
            (
                self.cast, self.sub_maya[sm.WRAP], self.sub_maya[sm.FILLER]
            ),
            k_path + (ok.BRW, ok.SHADOW)
        )

    def do(self, d, is_change):
        """
        Check, modify, and produce layer output.

        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        is_back = Run.is_back
        self.value_d = d
        m = is_change
        shadow = self.sub_maya[sm.SHADOW]
        wrap = self.sub_maya[sm.WRAP]
        wrap_d = d[ok.BRW][ok.WRAP_ALT]

        self.realize()

        m |= wrap.do(wrap_d, is_change, is_back)

        if wrap.matter:
            self.sub_maya[sm.FILLER].do(
                d[ok.BRW][self.filler_k], m, is_back, wrap.filler_sel
            )

            if m:
                make_2nd_frame_sel(
                    wrap_d,
                    self.sub_maya[sm.FILLER].matter,
                    wrap.wrap_sel,
                    wrap.filler_sel
                )
                wrap.matter = do_emboss_sel(wrap.matter, wrap_d)

            m1 = shadow.do(d[ok.BRW][ok.SHADOW], is_change, m)
            sort_shadow_layer(self, m or m1, get_light(wrap))

        else:
            self.die()
        self.reset_issue()
