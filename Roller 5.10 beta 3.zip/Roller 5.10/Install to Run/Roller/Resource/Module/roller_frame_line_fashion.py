#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Frame as ek, Material as ma, Option as ok
from roller_frame import do_embossed_frame
from roller_frame_alt import FrameBasic
from roller_fu import (
    add_layer, copy_all_image, create_image, select_rect
)
from roller_view_hub import (
    clipboard_fill, color_selection, set_fill_context_default
)
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def do_matter(maya):
    """
    Make a frame.

    maya: LineFashion
    Return: layer
        with the frame
    """
    set_fill_context_default()
    return do_embossed_frame(maya, make_pattern)


def make_pattern(z, d):
    """
    Make a Line Fashion pattern.

    z: layer
        to receive pattern

    d: dict
        Line Fashion Preset
        {Option key: value}

    Return: layer
        Has material to select.
    """
    w = d[ok.LINE_W]
    w1 = d[ok.GAP_W] + w
    j1 = create_image(int(w1), int(w1))
    z1 = add_layer(j1, "Pattern")
    y = (w1 - w) // 2.

    select_rect(j1, .0, y, w1, w)
    color_selection(z1, (0, 0, 0))

    # Set the Clipboard Image.
    copy_all_image(j1)

    pdb.gimp_image_delete(j1)
    clipboard_fill(z)
    return z


class LineFashion(FrameBasic):
    add_row = shade_row = ok.RW1
    filler_k = ok.FILLER_LF
    kind = ek.LINE_FASHION
    material = ma.LINE_FASHION
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
