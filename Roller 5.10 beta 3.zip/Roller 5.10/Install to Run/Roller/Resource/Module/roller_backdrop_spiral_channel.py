#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Cat, Run
from roller_constant_for import Backdrop as bs, Gradient as fg
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_fu import (
    add_layer,
    clone_layer,
    create_image,
    flip_layer,
    get_item_size,
    make_layer_group,
    merge_layer_group,
    paste_layer_into
)
from roller_maya_style import Style
from roller_one_wip import Wip
from roller_view_hub import create_dual_gradient, do_mod, draw_gradient
from roller_view_real import add_sub_base_group, clip_to_wip, finish_style
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def get_layer_points(d, w, h):
    """
    Return the layer points for start and end coordinates.

    d: dict
        Has start and end points.
        factor layer points
        in .0 to 1.

    w, h: float
        size of render or canvas

    return:
        start and end coordinates
        x, y, x1, y1
    """
    x = d[ok.START_X] * w
    y = d[ok.START_Y] * h

    if ok.END_X in d:
        x1 = d[ok.END_X] * w
        y1 = d[ok.END_Y] * h

    else:
        x1 = y1 = 0
    return x, y, x1, y1


def make_style(maya):
    """
    Make a style layer. The main process is to draw
    a spiral gradient at the center of an image tile.
    The output is split by a potential tile function.

    maya: SpiralChannel
    Return: layer
        the style layer
    """
    j = j1 = Run.j
    d = maya.value_d
    group = add_sub_base_group(maya)

    # A WIP layer fails.
    z = add_layer(j, "Base", parent=group)

    e = get_default_value(by.GRADIENT_FILL)

    if d[ok.GRADIENT_DIRECTION] == bs.COUNTER_CLOCKWISE:
        e[ok.GRADIENT_TYPE] = fg.SPIRAL_COUNTER_CW

    else:
        e[ok.GRADIENT_TYPE] = fg.SPIRAL_CLOCKWISE

    e[ok.BUMP] = get_default_value(ok.BUMP)
    e[ok.START_X] = e[ok.START_Y] = e[ok.END_Y] = .5
    e[ok.END_X] = .5 + d[ok.SPIRAL_DISTANCE]
    color = d[ok.COLOR_1]

    # The color inverts when using the difference mode.
    # This reverses that.
    if d[ok.SPIRAL_MOD] != "None":
        color = tuple([255 - i for i in d[ok.COLOR_1]])

    grad = e[ok.GRADIENT] = create_dual_gradient(
        "Spiral Channel", color, (255, 255, 255)
    )
    e[ok.OFFSET] = 0
    is_tile = False
    left_x, top_y, w, h = Wip.get_rect()
    row, column = map(int, (d[ok.ROW], d[ok.COLUMN]))

    if row > 1 or column > 1:
        is_tile = True
        w = w // column
        h = h // row
        j1 = create_image(int(w), int(h))
        z = add_layer(j1, "Tile")
        pdb.gimp_image_set_active_layer(j1, z)

    x, y, x1, y1 = get_layer_points(e, w, h)

    if not is_tile:
        x += left_x
        y += top_y
        x1 += left_x
        y1 += top_y

    z = draw_gradient(z, e, x, y, x1, y1)

    if d[ok.SPIRAL_MOD] != "None":
        z = clone_layer(z)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        if d[ok.SPIRAL_MOD] in (bs.HORIZONTAL_FLIP, bs.FLIP_BOTH):
            flip_layer(z, is_h=True)
        if d[ok.SPIRAL_MOD] in (bs.VERTICAL_FLIP, bs.FLIP_BOTH):
            flip_layer(z)

    if is_tile:
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

        tiles = make_layer_group(j, "Tiles", parent=group)
        x = left_x
        y = top_y

        # column tiling
        z = first = paste_layer_into(tiles)
        pdb.gimp_image_reorder_item(j, z, tiles, 0)

        for c in range(column):
            if c:
                z = clone_layer(first)
                x = (c * w) + left_x

            if c % 2:
                flip_layer(z, is_h=True)
            pdb.gimp_layer_set_offsets(z, int(x), int(y))

        z = first = merge_layer_group(tiles)

        # row tiling
        if row > 1:
            tiles = make_layer_group(j, "Tiles", parent=group, z=z)
            x = left_x

            for r in range(row - 1):
                z = clone_layer(first)

                if not r % 2:
                    flip_layer(z)

                y += h
                pdb.gimp_layer_set_offsets(z, int(x), int(y))
            z = merge_layer_group(tiles)

        w1, h1 = get_item_size(z)
        w, h = Wip.get_size()
        if (w, h) != (w1, h1):
            w = (w - z.width) / 2. + left_x
            h = (h - z.height) / 2. + top_y
            pdb.gimp_layer_set_offsets(z, int(w), int(h))

    z = merge_layer_group(group)

    # Remove the newly created gradient.
    pdb.gimp_gradient_delete(grad)
    Cat.gradient_list.pop(-1)

    clip_to_wip(z)
    do_mod(z, d[ok.BRW][ok.MOD])
    return finish_style(z, "Spiral Channel")


class SpiralChannel(Style):
    """Create Backdrop Style output."""
    is_dependent = False

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.BRW, ok.MOD)],
            make_style
        )
