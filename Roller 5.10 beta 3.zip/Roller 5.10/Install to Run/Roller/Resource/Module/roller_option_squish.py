#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import The
from roller_constant_for import (
    Backdrop as bs,
    Bump as fb,
    Caption as pt,
    Deco as dc,
    Frame as ff,
    Gradient as fg,
    Grid as gr,
    Mask as ms,
    Resize as fz,
    Shape as sh
)
from roller_constant_key import (
    BackdropStyle as by,
    Button as bk,
    Frame as ek,
    Group as gk,
    Node as ny,
    Option as ok,
    Step as sk,
    Widget as wk,
)
from roller_one_extract import get_option_list_key
from roller_widget_row import WidgetRow

ALWAYS = ok.PRESET, ok.PER, ok.SWITCH
COMMON_FORMAT = {bk.PLAN, bk.PREVIEW}
EXCLUDE_MASK = {
    (ms.EYE, ): {ok.PUPIL_SCALE},
    (ms.FRINGE,): ([(ok.RW1, (ok.BRUSH_D,)), ok.CONTRACT]),
    (ms.GRADIENT,): {ok.GRADIENT_ANGLE, ok.GRADIENT_TYPE},
    (ms.IMAGE, ms.FRINGE): {ok.RW1},
    (ms.IMAGE,): ([(ok.RW1, (ok.IMAGE_CHOICE,))]),
    (ms.PARALLELOGRAM_LEFT, ms.PARALLELOGRAM_RIGHT): {ok.PARALLELOGRAM_SCALE},
    (ms.RIP,): {ok.AMP, ok.SMOOTH, ok.SEED},
    (ms.TEXT,): (ok.TEXT, ok.FONT)
}
FOR_GRADIENT = {ok.GRADIENT, ok.GRADIENT_ANGLE, ok.GRADIENT_TYPE}
EXCLUDE_DECO = {
    (dc.CLOUDS, dc.PLASMA): {ok.SEED},
    (dc.COLOR, dc.NETTING): {ok.COLOR_1},
    (dc.GRADIENT,): FOR_GRADIENT,
    (dc.IMAGE,): ([(ok.RW1, (ok.IMAGE_CHOICE,))]),
    (dc.NETTING,): {ok.NET_LINE_W, ok.NLS},
    (dc.PATTERN,): {ok.PATTERN}
}
EXCLUDE_BORDER = {}
EXCLUDE_BORDER.update(EXCLUDE_DECO)
EXCLUDE_BORDER.update({(dc.IMAGE,): {ok.IMAGE_CHOICE}})
EXCLUDE_CAPTION = {
    (pt.TEXT,): {ok.TEXT},
    (pt.SEQUENCE,): {ok.START_NUMBER},
    (pt.SEQUENCE, pt.IMAGE_NAME): {ok.LTR}
}
EXCLUDE_FRINGE = {}
EXCLUDE_FRINGE.update(EXCLUDE_DECO)
EXCLUDE_FRINGE.update({
    (dc.IMAGE,): {ok.IMAGE_CHOICE},
    (dc.MULTI_COLOR,): {ok.COLOR_6, ok.COLOR_COUNT}
})

FOR_BOX_SHAPE_COUNT = {ok.HORZ_COUNT, ok.VERT_COUNT}
FOR_CELL_COUNT = {ok.COLUMN_COUNT, ok.ROW_COUNT}
FOR_CELL_SIZE = {ok.COLUMN_W, ok.GRID_SIZE, ok.ROW_H}
FOR_CROP = {ok.CROP_H, ok.CROP_W, ok.CROP_X, ok.CROP_Y}
FOR_FACE = ny.FACE, ny.FACING
FOR_FACTOR = {ok.FIH, ok.FIW}
FOR_FIXED = {ok.FIXED_SIZE_H, ok.FIXED_SIZE_W}
FOR_PAINT_RUSH = {ok.COLOR_1, ok.COLORIZE_OPACITY}
FOR_PARALLELOGRAM = (
    sh.PARALLELOGRAM_ALT_LEFT,
    sh.PARALLELOGRAM_ALT_RIGHT,
    sh.PARALLELOGRAM_LEFT,
    sh.PARALLELOGRAM_RIGHT
)
FOR_NOISE = {ok.BLUR, ok.NOISE_AMOUNT, ok.SPECK_NOISE}
FOR_RESIZE_LABEL = ok.COVER, ok.FILLED, ok.LOCKED, ok.TRIM
FOR_SHAPE_COUNT = {ok.ECS, ok.HORZ_COUNT, ok.VERT_COUNT}
MASK_SUB_TYPE = (
    (ms.CORNER, ok.CORNER_TYPE),
    (sh.HEXAGON, ok.HEXAGON_TYPE),
    (sh.OCTAGON, ok.OCTAGON_TYPE),
    (sh.RECTANGLE, ok.RECTANGLE_TYPE),
    (ms.TRIANGLE, ok.TRIANGLE_TYPE)
)
SHOW_SAMPLES = {
    ok.BUMP,
    ok.GRADIENT_TYPE,
    ok.MODE,
    ok.OPACITY,
    ok.ANGLE
}
SWITCH_VISIBLE = ok.PER, ok.PRESET, ok.SWITCH


def all_visible(*_):
    """
    Let the caller know that the Preset has no hidden key.

    Return: set
        Is empty.
    """
    return set()


def do_per(group):
    """
    Update the group's visibility.

    group: AnyGroup
    """
    if group and ok.PER in group.widget_d:
        g = group.widget_d[ok.PER]

        # A PerGroupEmpty has no sub-Widget.
        if hasattr(g, 'button'):
            # Open Button
            g1 = g.button

            if not g.check_button.get_a():
                g1.hide()
            else:
                g1.show()


def get_hidden_backing(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
        not used

    d: dict
        Backdrop Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        q = set()
        q1 = ()
        n = d[ok.TYPE]

        if n != bs.GRADIENT:
            q.update({ok.GRADIENT_ANGLE, ok.GRADIENT_TYPE})
            q1 = (ok.GRADIENT,)

        else:
            if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
                q.update({ok.GRADIENT_ANGLE})

        if n != bs.IMAGE:
            q.update({ok.FIT_IMAGE})
            q1 += (ok.IMAGE_CHOICE,)

        if n != bs.PATTERN:
            q.update({ok.PATTERN})

        if n not in (bs.CLOUDS, bs.PLASMA):
            q.update({ok.SEED})

        if n == bs.COLOR:
            q.update({ok.BLUR})

        else:
            q.update({ok.COLOR_1})
        q.update(([(ok.RW1, q1)]))
    return q


def get_hidden_blur_below(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        with option value

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in SWITCH_VISIBLE}

    if d[ok.SWITCH]:
        q = set()
    return q


def get_hidden_border(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        with option value

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden options, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        # hidden options, 'q'
        q = set()

        n = d[ok.TYPE]

        for i, a in EXCLUDE_BORDER.items():
            if n not in i:
                q.update(a)

        if n == dc.GRADIENT:
            # Shape type gradients radiate from
            # the center, so there is no angle.
            if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
                q.update({ok.GRADIENT_ANGLE})
        if branch_k in FOR_FACE:
            q.update({ok.OBEY_MARGINS})

    do_per(group)
    return q


def get_hidden_box(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    n = d[ok.GRID_TYPE]

    if n != gr.CELL_COUNT:
        q.update(FOR_CELL_COUNT)

    if n != gr.CELL_SIZE:
        q.update(FOR_CELL_SIZE)

    if n != gr.SHAPE_COUNT:
        q.update(FOR_BOX_SHAPE_COUNT)

    if n not in (gr.CELL_SIZE, gr.SHAPE_COUNT):
        q.update({ok.PIN})
    return q


def get_hidden_bump(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in SWITCH_VISIBLE}

    if d[ok.SWITCH]:
        q = set()
        n = d[ok.TYPE]

        if n not in fb.HAS_NOISE:
            q.update({ok.NOISE})
        if n != fb.CLOTH:
            q.update({ok.BLUR_X, ok.BLUR_Y})
    return q


def get_hidden_caption(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        n = d[ok.TYPE]

        if n == pt.TEXT and not d[ok.TEXT]:
            q -= {ok.TYPE, ok.TEXT}
        else:
            # hidden Widget key, 'q'
            q = set()

            for i, a in EXCLUDE_CAPTION.items():
                if n not in i:
                    q.update(a)

            # Face and Facing Caption don't have the Clip-to-Cell option.
            if branch_k in FOR_FACE:
                q.update({ok.OCR})

    do_per(group)
    return q


def get_hidden_cell(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    n = d[ok.CELL_SHAPE]

    if n not in FOR_PARALLELOGRAM:
        q.update({ok.PARALLELOGRAM_SCALE})
    return q


def get_hidden_frame_over_overlay(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    gpr_q = ()
    cir_q = ()
    n = d[ok.TYPE]

    if n not in (ff.CLOUDS, ff.PLASMA):
        q.update({ok.SEED})

    if n != ff.COLOR:
        cir_q += (ok.COLOR_1,)

    else:
        q.update({ok.BLUR})

    if n != ff.IMAGE:
        cir_q += (ok.IMAGE_CHOICE,)

    if n != ff.PATTERN:
        gpr_q += (ok.PATTERN,)

    if n != ff.GRADIENT:
        q.update({ok.GRADIENT_ANGLE, ok.GRADIENT_TYPE})
        gpr_q += (ok.GRADIENT,)
    else:
        if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
            q.update({ok.GRADIENT_ANGLE})

    q.update(([(ok.RW1, cir_q)]))
    q.update(([(ok.RW2, gpr_q)]))
    return q


def get_hidden_fringe(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        # hidden Widget key, 'q'
        q = set()

        n = d[ok.TYPE]

        for i, a in EXCLUDE_FRINGE.items():
            if n not in i:
                q.update(a)

        if n == dc.GRADIENT:
            # Shape-burst gradients radiate from the center.
            if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
                q.update({ok.GRADIENT_ANGLE})

        if n == dc.MULTI_COLOR:
            q.update(([(ok.COLOR_6, d[ok.COLOR_COUNT])]))
        if branch_k in FOR_FACE:
            q.update({ok.OCR})

    do_per(group)
    return q


def get_hidden_galactic_field(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        not used

    Return: set
        hidden Widget key
    """
    q = set()

    if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
        q.update(bs.POINT_KEY)
        if ok.GRADIENT_ANGLE in d:
            q.update({ok.GRADIENT_ANGLE})
    return q


def get_hidden_gradient(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
        q.update(bs.POINT_KEY)
        if ok.GRADIENT_ANGLE in d:
            q.update({ok.GRADIENT_ANGLE})
    return q


def get_hidden_gradient_light(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    if not d[ok.SWITCH]:
        # hidden Widget key, 'q'
        q = {i for i in d if i != ok.SWITCH}

    else:
        q = set()
        if d[ok.SWITCH]:
            if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
                q.update({ok.END_X, ok.END_Y, ok.START_X, ok.START_Y})
    return q


def get_hidden_image(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        if not d[ok.RW1][ok.IMAGE_CHOICE][ok.SWITCH]:
            q -= {ok.RW1}
            q.update(([(ok.RW1, (ok.MASK, ok.RESIZE))]))
        else:
            q = set()

            q.update(([(ok.RW1, ())]))
            if branch_k in FOR_FACE:
                q.update({ok.ANGLE, ok.JUSTIFICATION})

    do_per(group)
    return q


def get_hidden_image_choice(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        not used

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in (ok.SWITCH, ok.PRESET)}

    if d[ok.SWITCH]:
        n = d[ok.TYPE]
        q -= {n, ok.AUTOCROP, ok.AS_LAYERS, ok.TYPE, ok.SLICE}
        is_slice = True

        if d[ok.AS_LAYERS]:
            q -= {ok.LAYER_ORDER}

        if n == ok.FOLDER:
            q -= {ok.FILTER, ok.FOLDER_ORDER, ok.RANDOM_ORDER}
            if d[ok.RANDOM_ORDER]:
                q -= {ok.SEED}
                is_slice = False
                q.update({ok.AS_LAYERS, ok.FOLDER_ORDER, ok.SLICE})
        if is_slice and d[ok.SLICE]:
            q -= {ok.COLUMN_SLICE, ok.ROW_SLICE, ok.SLICE_ORDER}
    return q


def get_hidden_image_gradient(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    n = d[ok.SAMPLE_VECTOR]

    if n != bs.HORIZONTAL:
        q.update({ok.START_Y})

    if n != bs.VERTICAL:
        q.update({ok.START_X})

    if n != bs.DIAGONAL:
        q.update({ok.DIAGONAL_ROTATION})

    # the Show Samples option, '1'
    if d[ok.PREVIEW_MODE] == 1:
        q.update(SHOW_SAMPLES)
    return q


def get_hidden_line(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        # hidden Widget key, 'q'
        q = set()
        if branch_k in FOR_FACE:
            # Face and Facing don't have a Margin group.
            q.update({ok.OBEY_MARGINS})

    do_per(group)
    return q


def get_hidden_margin(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        with option value

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    q = {i for i in d if i not in (ok.PER, ok.SWITCH)}

    if d[ok.SWITCH]:
        q = set()

    do_per(group)
    return q


def get_hidden_mask(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Mask Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i != ok.SWITCH}

    if d[ok.SWITCH]:
        n = d[ok.TYPE]

        if n == ms.TEXT and not d[ok.TEXT]:
            q -= {ok.TYPE, ok.TEXT}
        else:
            # hidden Widget key, 'q'
            q = set()

            for i, a in EXCLUDE_MASK.items():
                if n not in i:
                    q.update(a)

            if n == ms.GRADIENT:
                # Shape type gradients radiate from the center.
                if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
                    # There's no angle.
                    q.update({ok.GRADIENT_ANGLE})

            for sub_type, mask_k in MASK_SUB_TYPE:
                if n != sub_type:
                    q.update({mask_k})

            if n == ms.FRINGE:
                q.update({ok.CUT_OUT, ok.HORZ_SCALE, ok.VERT_SCALE})
            if not d[ok.FEATHER]:
                q.update({ok.STEPS})
    return q


def get_hidden_noise(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in SWITCH_VISIBLE}

    if d[ok.SWITCH]:
        q = set()
        q.update(
            {
                ff.INK: FOR_NOISE,
                ff.RIFT: {ok.SPECK_NOISE},
                ff.SPECK: {ok.BLUR, ok.NOISE_AMOUNT},
                ff.WATER: FOR_NOISE
            }[d[ok.TYPE]]
        )
    return q


def get_hidden_paint_rush(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    # if not colorize
    if not d[ok.COLORIZE]:
        q.update(FOR_PAINT_RUSH)
    return q


def get_hidden_plaque(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        # hidden Widget key, 'q'
        q = set()

        n = d[ok.TYPE]

        for i, a in EXCLUDE_DECO.items():
            if n not in i:
                q.update(a)

        if n == dc.IMAGE:
            q.update(([(ok.RW1, ())]))

        if n == dc.GRADIENT:
            # Shape type gradients radiate from the center.
            if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
                # There's no angle.
                q.update({ok.GRADIENT_ANGLE})
        if branch_k in FOR_FACE:
            q.update({ok.OBEY_MARGINS})

    do_per(group)
    return q


def get_hidden_rect_pattern(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    return {(ok.COLOR_6A, d[ok.COLOR_COUNT])}


def get_hidden_resize(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Resize Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in (ok.PRESET, ok.TYPE)}

    n = d[ok.TYPE]

    if n in FOR_RESIZE_LABEL:
        q -= {n}

    elif n == fz.CROP:
        q -= FOR_CROP

    elif n == fz.FIXED:
        q -= FOR_FIXED

    elif n == fz.FACTOR:
        q -= FOR_FACTOR
    return q


def get_hidden_shadow(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in (ok.INTENSITY, ok.PRESET)}

    if d[ok.INTENSITY]:
        q = set()
    return q


def get_hidden_stencil(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i != ok.PRESET}

    n = d[ok.FRAME_OVER]

    if n == "None":
        q -= {ok.FRAME_OVER}

    else:
        q = set()
    return q


def get_hidden_switch(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden options, 'q'
    q = {i for i in d if i not in SWITCH_VISIBLE}

    if d[ok.SWITCH]:
        q = set()

    do_per(group)
    return q


def get_hidden_table(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    n = d[ok.GRID_TYPE]

    if n == gr.SHAPE_COUNT:
        n1 = d[ok.ECS]

    else:
        n1 = d[ok.CELL_SHAPE]

    if n != gr.CELL_COUNT:
        q.update(FOR_CELL_COUNT)

    if n != gr.CELL_SIZE:
        q.update(FOR_CELL_SIZE)

    if n != gr.SHAPE_COUNT:
        q.update(FOR_SHAPE_COUNT)

    if n not in (gr.CELL_COUNT, gr.CELL_SIZE):
        q.update({ok.CELL_SHAPE})

    if n1 not in sh.DOUBLE:
        q.update({ok.FCI})

    if n1 not in FOR_PARALLELOGRAM:
        q.update({ok.PARALLELOGRAM_SCALE})

    if n not in (gr.CELL_SIZE, gr.SHAPE_COUNT):
        q.update({ok.PIN})

    if n != gr.CELL_COUNT or d[ok.CELL_SHAPE] != sh.RECTANGLE:
        q.update({ok.PER})

    else:
        # The Per option is for merging cells and
        # is pointless if there is only one cell.
        if (
            d[ok.ROW_COUNT] == 1
            and d[ok.COLUMN_COUNT] == 1
        ):
            q.update({ok.PER})

    if ok.PER not in q:
        do_per(group)
    return q


def get_hidden_wrap(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden options, 'q'
    q = set()

    if not d[ok.EMBOSS]:
        q.update({ok.CONTRAST, ok.DEPTH, ok.SOFTEN})

    else:
        q.update({ok.COLOR_1})
    return q


def hide_option(group):
    """
    Set option visibility.

    group: AnyGroup
    """
    d = group.widget_d
    branch_k = None
    if group:
        if group.render_key and len(group.render_key) > 2:
            # index for a Model branch (Canvas, Cell, Face, Facing), '1'
            branch_k = group.render_key[1]
        set_visibility(
            d, ROUTE_SQUISH[group.item.key](
                group,
                {
                    k: a.get_a()
                    for k, a in d.items()
                    if k not in (bk.RANDOM, ok.PRESET)
                },
                branch_k
            )
        )


def make_option_tooltip(key, d, tooltip, indent):
    """
    Make a tooltip for a Preset.

    key: string
        Identify Preset.

    d: dict
        Preset

    tooltip: string
        WIP

    indent: int
        Is the count of the tab prefix.

    Return: string
        tooltip
    """
    if key in ROUTE_SQUISH:
        hidden_q = ROUTE_SQUISH[key](None, d, None).union((ok.SWITCH,))

    else:
        hidden_q = ()

    visible_q = [i for i in d if i not in hidden_q]
    default_d = The.preset.get_init_d(key)
    row_q = []

    if default_d:
        # Make a list of hidden row key.
        for i, a in default_d.items():
            # SuperPreset has a changeless option which is not a dict.
            if isinstance(a, dict):
                if default_d[i].get(wk.WIDGET) == WidgetRow:
                    row_q += [i]
    else:
        # Option list (Frame and Backdrop Style) doesn't have a default.
        k = get_option_list_key(d)

        # During development, a None key has thrown an error.
        # The None key was fixed, but check 'k' for stability.
        if k:
            tooltip = make_tooltip(k, d[k], tooltip, indent)

    if default_d:
        # Process option.
        for k, e in default_d.items():
            # Check to see if the option is visible.
            if k in visible_q and k not in row_q:
                # Check option definition for a tooltip function.
                p = e.get(wk.TIPPER) if default_d else None

                if p:
                    tooltip += '\n'
                    tooltip += e[wk.TIPPER](d, k, indent, e)
                else:
                    a = d.get(k)

                    # Some keys have no value (e.g. NEXT_INDEX, COVER, etc.).
                    if isinstance(a, dict):
                        tooltip = make_tooltip(k, a, tooltip, indent)
            else:
                # A Row has multiple option.
                if k in row_q:
                    sub_row_q = e[wk.SUB].keys()
                    hidden_row_q = []

                    # Filter out sub-row key that is hidden.
                    for i in hidden_q:
                        # index to a row key, '0'
                        if i[0] == k:
                            # (row key, (sub-row key, ...)), 'i'
                            # index to a sub-row key tuple, '1'
                            for i1 in i[1]:
                                hidden_row_q += [i1]
                    for i in sub_row_q:
                        if i not in hidden_row_q:
                            e = default_d[k][wk.SUB][i]

                            if i == ok.FRAME:
                                # This is a Frame Preset in a sub-row.
                                tooltip = make_tooltip(
                                    i, d[k][i], tooltip, indent
                                )
                            else:
                                # Sub-row options can be a sub-branch
                                # or an option end-point (leaf).
                                if e.get(wk.SUB):
                                    # Is a branch.
                                    tooltip = make_tooltip(
                                        i, d[k][i], tooltip, indent
                                    )
                                else:
                                    # A Random button doesn't have TIPPER.
                                    p = e.get(wk.TIPPER)
                                    if p:
                                        tooltip += '\n'
                                        tooltip += p(d[k], i, indent, e)
    return tooltip


def make_shadow_tooltip(key, d, tooltip, indent):
    """
    Make a tooltip for the Shadow SuperPreset.

    key: string
        Is the Shadow key.

    d: dict
        Shadow SuperPreset

    tooltip: string
        tooltip WIP

    indent: int
        Format the tooltip.

    Return: string
        the tooltip
    """
    default_d = The.preset.get_init_d(key)
    e = default_d[wk.SUB]

    for k, a in e.items():
        if k not in (sk.SHADOW, sk.SHADOW_SWITCH):
            tooltip = make_tooltip(k, d[k], tooltip, indent)
    return tooltip


def make_tooltip(key, d, tooltip, indent):
    """
    Make a tooltip for a Preset.

    key: string
        Identify Preset.

    d: dict
        Preset

    tooltip: string
        WIP

    indent: int
        Is the count of the tab prefix.

    Return: string
        tooltip
    """
    def _check_per():
        """
        The dict, 'd', is a Per type. Per doesn't have a tooltip.

        Return: string
            tooltip
        """
        return pre_tooltip

    def _check_shadow():
        """
        The dict, 'd', is a Shadow SuperPreset.

        Return: string
            tooltip
        """
        if not d[sk.SHADOW_SWITCH][ok.SWITCH]:
            return tooltip + "Off "
        else:
            return make_shadow_tooltip(key, d, tooltip, indent + 1)

    if indent:
        n = '\n' + '\t' * indent

    else:
        n = " "

    k = key.split(",")[0] if isinstance(key, basestring) else key[-1]
    pre_tooltip = tooltip
    tooltip += n + k + " "

    # a special Preset processor, 'p'
    p = {ok.PER: _check_per, ok.SHADOW: _check_shadow}.get(key)

    if p:
        # tooltip, 'a'
        a = p()
        if a:
            return a

    else:
        # Check to see if the Preset is switchable and switched off.
        a = d.get(ok.SWITCH)

        if not a and a is not None:
            return tooltip + "Off "
        if tooltip.count('\n') > 20:
            # The tooltip is too long.
            return tooltip + "On "
    return make_option_tooltip(key, d, tooltip, indent + 1)


def set_visibility(d, q):
    """
    Set Widget visibility for an option group.

    d: dict
        option group Widget

    q: set
        of Widget key of Widgets to hide
    """
    g = None
    q1 = {i for i in d.keys()} - q

    # Ensure that common Widget types are always showing.
    q1.update(COMMON_FORMAT)

    for i, g in d.items():
        g.show() if i in q1 else g.hide()

    for i in q:
        if isinstance(i, tuple):
            d[i[0]].update_visibility(i[1])
    if g:
        g.roller_win.resize()


# Each value is a Preset hidden key function.
ROUTE_SQUISH = {
    by.GALACTIC_FIELD: get_hidden_galactic_field,
    by.GRADIENT_FILL: get_hidden_gradient,
    by.IMAGE_GRADIENT: get_hidden_image_gradient,
    by.RECT_PATTERN: get_hidden_rect_pattern,
    gk.BORDER: get_hidden_border,
    gk.CAPTION: get_hidden_caption,
    gk.FRINGE: get_hidden_fringe,
    gk.GRADIENT_LIGHT: get_hidden_gradient_light,
    gk.IMAGE: get_hidden_image,
    gk.INNER_SHADOW: get_hidden_shadow,
    gk.LINE: get_hidden_line,
    gk.MARGIN: get_hidden_margin,
    gk.PLAQUE: get_hidden_plaque,
    gk.SHADOW_1: get_hidden_shadow,
    gk.SHADOW_2: get_hidden_shadow,
    gk.SHIFT: get_hidden_switch,
    gk.TYPE_BOX: get_hidden_box,
    gk.TYPE_CELL: get_hidden_cell,
    gk.TYPE_STACK: get_hidden_cell,
    gk.TYPE_TABLE: get_hidden_table,
    ok.ADD: get_hidden_switch,
    ok.ADD_ABOVE: get_hidden_switch,
    ok.ADD_ALT: get_hidden_switch,
    ok.BACKING: get_hidden_backing,
    ok.BLUR_BELOW: get_hidden_blur_below,
    ok.BUMP: get_hidden_bump,
    ok.IMAGE_CHOICE: get_hidden_image_choice,
    ok.MASK: get_hidden_mask,
    ok.MOD: get_hidden_switch,
    ok.NOISE_D: get_hidden_noise,
    ok.OVERLAY_FO: get_hidden_frame_over_overlay,
    ok.RESIZE: get_hidden_resize,
    ok.SHADOW_BASIC: get_hidden_shadow,
    ok.STENCIL: get_hidden_stencil,
    ok.STRIP: get_hidden_switch,
    ok.WRAP: get_hidden_wrap,
    ok.WRAP_ABOVE: get_hidden_wrap,
    ok.WRAP_ALT: get_hidden_wrap,
    ok.WRAP_SW: get_hidden_wrap,
    ok.WRAP_PR: get_hidden_paint_rush,
    sk.INNER_SHADOW: get_hidden_shadow,
    sk.SHADOW_1: get_hidden_shadow,
    sk.SHADOW_2: get_hidden_shadow
}
ALL_VISIBLE = (
    ok.BACKDROP_STYLE,
    ok.BRUSH_D,
    ok.BRUSH_D1,
    ok.FILLER_CC,
    ok.FILLER_CP,
    ok.FILLER_LF,
    ok.FILLER_LM,
    ok.FILLER_RM,
    ok.FILLER_RW,
    ok.FILLER_SC,
    ok.FILLER_SG,
    ok.FILLER_SP,
    ok.FILLER_ST,
    ok.HEAT,
    ok.OVERLAY_BB,
    ok.OVERLAY_CF,
    ok.OVERLAY_CP,
    ok.SHADOW,
    ok.TAPE,
    ok.WRAP_BB,
    ok.WRAP_BJ,
    ok.WRAP_CB,
    ok.WRAP_CF,
    ok.WRAP_CP,
    ok.WRAP_CS
)

ROUTE_SQUISH.update({k: all_visible for k in ALL_VISIBLE})
ROUTE_SQUISH.update(
    {k: all_visible for k in by.KEY_LIST if k not in ROUTE_SQUISH}
)
ROUTE_SQUISH.update(
    {k: all_visible for k in ek.KEY_LIST if k not in ROUTE_SQUISH}
)
