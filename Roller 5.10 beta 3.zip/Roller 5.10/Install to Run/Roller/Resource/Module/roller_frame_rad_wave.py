#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Globe, Run
from roller_a_rect_table import RectTable
from roller_constant_key import Frame as ek, Material as ma, Option as ok
from roller_frame import (
    make_canvas_frame_sel, do_emboss_sel, select_frame
)
from roller_frame_alt import FrameBasic
from roller_fu import (
    load_selection,
    select_item,
    select_opaque,
    select_rect,
    verify_layer
)
from roller_one_wip import Wip
from roller_view_hub import color_selection_default
from roller_view_real import add_wip_layer, get_light
import gimpfu as fu  # type: ignore

pdb = fu.pdb


def do_matter(maya):

    """
    Make the frame.

    maya: RadWave
    Return: layer
        with the frame
    """
    j = Run.j
    d = maya.value_d
    e = maya.super_maya.value_d[ok.BRW][ok.FILLER_RW]

    select_frame(j, maya.cast.matter, d[ok.WIDTH], d[ok.TYPE])

    sel = pdb.gimp_selection_save(j)

    # Canvas frame
    pdb.gimp_selection_none(j)
    make_canvas_frame_sel(e)

    sel1 = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)

    # layer for the wire, 'z'
    z = add_wip_layer("Rad Wave", None)

    width, height = map(float, Globe.view_size)
    w1 = e[ok.LINE_W]
    row, column = int(e[ok.ROW]), int(e[ok.COLUMN])

    if w1:
        grid = RectTable(Wip.get_rect(), row, column).table

        for r in range(1, row):
            select_rect(
                j, .0, grid[r][0].y, width, w1, option=fu.CHANNEL_OP_ADD
            )
        for c in range(1, column):
            select_rect(
                j, grid[0][c].x, .0, w1, height, option=fu.CHANNEL_OP_ADD
            )

    color_selection_default(z, (0, 0, 0))
    pdb.gimp_selection_none(j)

    # phase, '1.'; smeared wave type, '0'; no reflective, '0'
    pdb.plug_in_waves(j, z, e[ok.WAVE_AMPLITUDE], 1., e[ok.WAVELENGTH], 0, 0)

    pdb.gimp_selection_none(j)

    # mid-pinch, '.0'; radius, '2.'
    pdb.plug_in_whirl_pinch(j, z, e[ok.WHIRL], .0, 2.)

    select_item(z)
    pdb.gimp_image_remove_layer(j, z)

    # layer for the combined frame, 'z'
    z = add_wip_layer("Material", maya.group, offset=get_light(maya))

    for i in (sel, sel1):
        load_selection(j, i, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, i)

    select_opaque(maya.cast.matter, option=fu.CHANNEL_OP_SUBTRACT)
    select_rect(Run.j, *Wip.get_rect(), option=fu.CHANNEL_OP_INTERSECT)
    return verify_layer(do_emboss_sel(z, d))


class RadWave(FrameBasic):
    add_row = shade_row = ok.RW1
    filler_k = ok.FILLER_RW
    kind = ek.RAD_WAVE
    material = ma.RAD_WAVE
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
