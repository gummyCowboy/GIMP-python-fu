#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Issue as vo
from roller_constant_key import Option as ok, Plan as ak, Widget as wk
from roller_def_option import FONT_SIZE
from roller_widget_label import PropertyTypeLabel
from roller_widget_plan import PlanOption
from roller_widget_slider import FontSizeSlider

# Define the Property Preset.
PLANNER = OrderedDict([
    (ak.BORDER, 0),
    (ak.CAPTION, 0),
    (ak.CELL_SHAPE, 0),
    (ak.CORNER, 0),
    (ak.DIMENSION, 0),
    (ak.FRINGE, 0),
    (ak.GRID, 0),
    (ak.IMAGE, 0),
    (ak.LINE, 0),
    (ak.MARGIN, 0),
    (ak.NAME, 0),
    (ak.PLAQUE, 0),
    (ak.POSITION, 0),
    (ak.RATIO, 0)
])
property_d = OrderedDict([
    (ok.MODEL_TYPE, {
        wk.ISSUE: vo.NULL,
        wk.WIDGET: PropertyTypeLabel
    }),
    (ok.PLANNER, {wk.VAL: deepcopy(PLANNER), wk.WIDGET: PlanOption}),
    (ok.FONT_SIZE, deepcopy(FONT_SIZE))
])

property_d[ok.FONT_SIZE].update({
    wk.VAL: 12.,
    wk.WIDGET: FontSizeSlider
})
PROPERTY = deepcopy(property_d)
