#!/usr/bin/env python
# -*- coding: utf-8 -*-
# This module is circular with the Preset class:
from roller_constant_for import Group as og, Preset as fp, Step as fs
from roller_constant_key import Option as ok, Step as sk
from roller_one import Comm, Hat, OZ
from roller_one_extract import Path
from roller_option_preset_dict import NonPresetDict, PresetDict
from roller_widget_tree import Node
import glob
import os

PC = ok.PER_CELL


def add_to_d(d, e):
    """
    Recursively add missing dict items
    to a loaded dict using a default
    dictionary as a source.

    d: dict
        receiver

    e: dict
        of default
    """
    for i, value in e.items():
        if i not in d:
            d[i] = value
        else:
            if e and i in e:
                a, b = isinstance(d[i], dict), isinstance(value, dict)

                if a and b:
                    add_to_d(d[i], value)
                elif a or b:
                    d[i] = value


def remove_from_d(d, e):
    """
    Recursively remove invalid dict items
    from a loaded dict using a default
    dictionary as a comparison.

    d: dict
        to check

    e: dict
        of default
    """
    q = d.keys()

    # In some cases, 'e' is empty for the Tri-Shadow SuperPreset:
    if e:
        for i in q:
            # The Tri-Shadow SuperPreset loads keys with tuples:
            if not isinstance(i, tuple):
                if i not in e:
                    d.pop(i)
                else:
                    a = isinstance(d[i], dict)
                    b = isinstance(e[i], dict)

                    if a and b:
                        remove_from_d(d[i], e[i])
                    elif a or b:
                        d[i] = e[i]


def translate_step(q):
    """
    Replace a numeric id with its corresponding name.

    q: tuple
        a step key

    Return: tuple
        the translated step
    """
    q1 = []
    group_id = Hat.dog.group_id

    if len(q) > fs.MODEL_INDEX:
        if isinstance(q[fs.MODEL_INDEX], int):
            q1 += [fs.MODEL_INDEX]

    if q1:
        q2 = list(q)

        for x1 in q1:
            q2[x1] = group_id.get_name(q[x1])
        q = tuple(q2)
    return q


def update_preview_buttons(path):
    """
    Update the plan and preview buttons after change.

    path: tuple
        a render step
    """
    # Change the Preview buttons along the tree branch:
    q = Core.get_steps(sk.STEPS, with_dict=False)[1]
    d = Hat.cat.group_dict
    for i in q:
        if i == path:
            continue

        a = d[i]
        if a.preview_button:
            a.preview_button.set_sensitive(1)


class Core:
    """Are extracted static functions from SuperPreset."""

    @staticmethod
    def check_per_cell(g, q):
        """
        Check a per cell table's dictionaries with the default.

        g: Widget
            Has form group key.

        q: list
            per cell table
        """
        d = PresetDict.get_default(g.form_group_key)

        # dimension, row, 'i':
        for i in q:
            # dimension, column, 'j':
            for j in i:
                if isinstance(j, dict):
                    Core.synchronize_preset(j, d)

    @staticmethod
    def collect_preset(group_key):
        """
        Create a list of internal and external presets.

        group_key: string
            option group key

        Return: tuple
            (external preset dict, preset name list)
        """
        # 'q', list of presets:
        q = [fp.DEFAULT]

        ext_files = []
        go = False
        external_preset = {}

        try:
            search_path = OZ.get_preset_path(
                group_key,
                u"*",
                Hat.cat.preset_folder
            )

            # Ignore sub-directories:
            ext_files = glob.glob(search_path)
            go = True

        except Exception as ex:
            Comm.show_err(ex)
            Comm.show_err("Roller was unable to load presets.")

        if go:
            # Make an external preset file list:
            for n in ext_files:
                file_name = os.path.basename(n)
                split_name = file_name.split(fp.PRESET_SEPARATOR)
                combined_name = u""

                for n1 in range(1, len(split_name)):
                    combined_name = combined_name + split_name[n1]

                types = combined_name.split(u".")
                name = types[0]
                external_preset[name] = n
                q.append(name)
        return external_preset, q

    @staticmethod
    def synchronize_preset(d, e):
        """
        Recursively synchronize a loading preset with the default preset.

        d: dict
            loading preset

        e: dict
            default preset

        return: tuple
            (loading preset, default preset)
        """
        remove_from_d(d, e)
        add_to_d(d, e)

    @staticmethod
    def update_version(g, a):
        """
        Check the keys in a loaded preset
        dict with the default dict keys.

        g: Widget
            Has key.

        a: dict or Widget
            Has keys to verify.
        """
        if isinstance(a, dict):
            Core.synchronize_preset(a, PresetDict.get_default(g.key))

        else:
            if g.key == ok.PER_CELL:
                # a per cell widget has a 2D list of dictionaries, 'a':
                Core.check_per_cell(g, a)
        return a

    @staticmethod
    def get_steps(path, with_list=True, with_dict=True, last_path=None):
        """
        Make a steps dict.

        The steps are reflected by the order of the option groups.

        The steps dict has a steps list where each step is resolved
        into a step-keyed dictionary.

        steps dict
            key: 'steps', value: list of step
            1 to n of step:
                key: path, value: preset-type dict

        path: tuple
            of SuperPreset

        with_list: bool
            If it's true, a step list is built into the resulting dict.

        with_dict: bool
            If it's true, the step option groups are added with their values.

        last_path: tuple or None
            If it is a tuple, then its the stop point for the walk.

        Return: tuple
            steps dict, steps list
            The dict has option values, and the list is ordered for rendering.
        """
        def walk(a, g, k, m):
            """
            Use recursion to walk through the option groups.
            Collect option values and Node selections.

            a: OptionGroup
                Has needed info.

            g: Node
                Has branches.

            k: tuple
                path
                Is key for the group dict.

            m: bool
                If true the walk is done.

            Return: tuple
                OptionGroup, Node
                for recursion
            """
            if g and not m:
                if with_dict:
                    # Collect option values in 'e' of 'get_steps':
                    e[a.path] = {sk.SELECTED_ROW: g.get_sel_x()}

                if with_list:
                    steps.append(a.path)
                for i in g.get_value():
                    # Expand path:
                    k1 = k + (i,)

                    # Replace numeric id of a SuperPreset:
                    if k1 not in d:
                        _id = group_id.get_id(i)
                        k1 = k + (_id,)
                    if k1 in d and not m:
                        a = d[k1]

                        if a.node:
                            # Continue with a new node:
                            g = a.node
                            a, g, k1, m = walk(a, g, k1, m)
                        else:
                            # Is a terminal point of this branch:
                            if a.group_type in (Hat.per_cell, Hat.preset):
                                keys = PresetDict.get_keys(a.group_key)

                            elif a.group_type == Hat.non_preset:
                                keys = NonPresetDict.get_keys(a.group_key)

                            else:
                                keys = None

                            if with_list:
                                # Add option's step to the sequence:
                                steps.append(a.path)
                            if keys:
                                # Collect values from widgets:
                                d1 = Path.get_dict_from_path(
                                    k1,
                                    add_per_cell=False
                                )

                                if with_dict:
                                    e[k1] = d1

                                # Is there a Per Cell table?
                                if hasattr(a.vbox, og.PER_CELL_GROUP):
                                    # Get the Per Cell's cell table:
                                    k2 = Path.make_per_cell_path(k1)

                                    # OptionGroup 'b':
                                    b = d[k2]

                                    if with_dict:
                                        e[k2] = {PC: b.d[PC].get_value()}
                                    if with_list:
                                        # Add the Per Cell step:
                                        steps.append(b.path)
                    if k1 == last_path:
                        m = True
            return a, g, k, m

        cat = Hat.cat
        d = cat.group_dict
        group_id = Hat.dog.group_id
        e = {}
        steps = []
        group = d[path]
        node = group.node
        walk(group, node, path, False)
        return e, steps

    @staticmethod
    def get_render_steps(path=None):
        """
        Get the steps for a render or preview.

        path: tuple
            Is the last step needed.

        Return: list
            of filter steps
        """
        # Remove steps that are not needed for a render:
        q1 = []
        d = Hat.cat.group_dict
        q = Core.get_steps(sk.STEPS, with_dict=False, last_path=path)[1]

        # Filter out useless steps:
        for i in q:
            if d[i].group_type not in (Node, Core):
                q1 += [i]
        return q1

    @staticmethod
    def make_preview(g, group):
        """
        Create a preview render.

        g: OptionButton
            of preview
            Is responsible.
            Has path. Is a key made from the navigation tree.

        group: OptionGroup
            Has group variables.
        """
        # Get the render-filtered steps that lead to the path:
        path = group.path
        Hat.dog.viewer.do(Core.get_render_steps(path=path), is_preview=True)
        g.set_sensitive(0)
        update_preview_buttons(path)
        if hasattr(group, 'plan_button'):
            if group.plan_button:
                group.plan_button.set_sensitive(1)

    @staticmethod
    def translate_model_to_id(d, model_list):
        """
        Exchange custom cell names with ids in a SuperPreset dict.

        d: dict
            of SuperPreset

        model_list: ModelList
            Has names to translate.

        Return: dict
            of SuperPreset
            with translated cell names
        """
        if model_list:
            for i in model_list.get_value():
                d = Core.translate_to_id(d, i, Hat.dog.group_id.get_id(i))
        return d

    @staticmethod
    def translate_to_id(d, n, _id):
        """
        Translate a name to an id.

        d: dict
            of SuperPreset

        n: string
            name

        Return: dict
            with translated names
        """
        e = {}
        x = fs.MODEL_INDEX

        for step in d:
            if len(step) > x and n == step[x]:
                q = list(step)
                q[x] = _id
                q = tuple(q)
                e[q] = d[step]
            else:
                e[step] = d[step]
        return e

    @staticmethod
    def translate_to_name(d):
        """
        Replace numeric ids with their corresponding names.

        d: dict
            of steps

        Return: dict
            'd' after translation
        """
        e = {}

        for i, a in d.items():
            # Replace ids with names:
            e[translate_step(i)] = a
        return e

    @staticmethod
    def update_plan_buttons(path):
        """
        Update the plan and preview buttons after change.

        path: tuple
            a render step
        """
        # Change the Preview buttons along the tree branch:
        q = Core.get_steps(sk.STEPS, with_dict=False)[1]
        d = Hat.cat.group_dict
        for i in q:
            if i == path:
                continue

            a = d[i]
            if a.plan_button:
                a.plan_button.set_sensitive(1)

    @staticmethod
    def update_view_buttons(path):
        """
        Update the plan and preview buttons after change.

        path: tuple
            a render step
        """
        # Change the Preview buttons along the tree branch:
        q = Core.get_steps(sk.STEPS, with_dict=False)[1]
        d = Hat.cat.group_dict
        for i in q:
            if i == path:
                continue

            a = d[i]

            if a.preview_button:
                a.preview_button.set_sensitive(1)
            if a.plan_button:
                a.plan_button.set_sensitive(1)
