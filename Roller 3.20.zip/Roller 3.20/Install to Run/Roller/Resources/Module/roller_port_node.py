#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Group as og
from roller_constant_key import Option as ok, Widget as wk
from roller_one import Base
from roller_option_group import OptionGroup
from roller_option_preset import PerCell, Preset
from roller_option_preset_dict import PresetDict
from roller_widget_box import Eventful, VBow
from roller_widget_tree import Node

# Are flags used to add buttons to an option group:
BUTTON_KEY = (
    wk.HAS_EFFECT_PAIR,
    wk.HAS_GRID_PAIR,
    wk.HAS_PREVIEW,
    wk.HAS_RANDOM
)


def draw_per_cell(d, group_key):
    """
    Draw an option group for a Per Cell type group.

    Per Cell groups have an option group that applies
    to all cells in a grid, and a Per Cell option
    that applies to cells individually.

    d: dict
        Has group options.

    group_key: string
        identifier
    """
    g = d[wk.CONTAINER]
    d[wk.HAS_PRESET] = d[wk.HAS_GRID_PAIR] = True
    vbox = d[wk.CONTAINER] = VBow()

    # Get group key of option for all cells:
    k = d[wk.GROUP_KEY] = og.SOURCE_GROUP_KEY[group_key]
    d[wk.KEYS] = PresetDict.get_keys(k)
    d[wk.BOTTOM_PAD] = 0
    d[wk.GROUP_TYPE] = Preset
    g.add(vbox)

    d1 = OptionGroup.draw_group(**d)

    # per cell:
    d[wk.GROUP_KEY] = group_key
    d[wk.GROUP_TYPE] = PerCell
    d[wk.CONTAINER] = g
    d[wk.KEYS] = ok.PER_CELL,
    d[wk.TOP_PAD] = 1
    d[wk.PATH] = d[wk.PATH][:-1] + (group_key,)

    for i in (wk.BOTTOM_PAD, wk.HAS_GRID_PAIR):
        d.pop(i)

    d2 = OptionGroup.draw_group(**d)
    g1 = d2[ok.PER_CELL]

    if ok.GRID_TYPE in d1:
        d1[ok.GRID_TYPE].group.per_cell = g1

    # Connect the VBox to the PerCellGroup
    # so its cell table can be accessed:
    vbox.per_cell_group = g1


# 'object' is a new style class reference for Python 2.7:
class PortNode(object):
    """Has functions used to create Node navigation."""

    def __init__(self, d, a):
        """
        Store a reference to the dictionary used to initialize widgets.

        d: dict
            Use to initialize widgets.

        a: MainDict
            with node group definition
        """
        self.d = d
        self._main_d = a
        color = Base.INIT_COLOR
        self.column_color = []
        for i in range(9):
            self.column_color += [color]
            color = Base.reduce_color(color)

    def create_node(self, d, group_key, level, path, group_id=None):
        """
        Create a Node option group.
        Is recursive with 'self.draw_options'.
        The option group becomes visible when its
        Node item, a branch, is selected, and a signal
        is sent to the Port module's 'on_list_change' function.

        d: dict
            Has node options.

        group_key: string
            identifier

        level: int
            navigation depth

        path: tuple
            of nodes to an option group
        """
        if group_id is None:
            group_id = group_key

        labels = self._main_d.group_def[group_id][wk.LABELS]
        d[wk.LABELS] = [i.split(",")[0] for i in labels]
        d[wk.LEVEL] = level
        d[wk.COLOR] = self.column_color[level]
        d[wk.GROUP_TYPE] = Node
        k = wk.PARENT_TYPE

        if k in self._main_d.group_def[group_id]:
            d[k] = self.d[k] = self._main_d.group_def[group_id][k]

        node = Node(**d)
        node.group = d[wk.GROUP] = OptionGroup(**d)
        node.group.d = {group_id: node}
        node.group.node = node
        for x, i in enumerate(labels):
            level, path = self.draw_options(
                node.get_groupie_with_label(i),
                i,
                level + 1,
                path
            )

    def draw_options(self, g, group_key, level, path):
        """
        Draw the options.
        Is recursive with 'self.create_node'.

        g: container
            container for options

        group_key: string
            group key

        level: int
            level of navigation

        path: tuple
            Use with group keys for making paths that trace steps.
        """
        def _add_junction():
            if len(nav_box.junctions) <= level:
                junction = VBow()
                box = Eventful(self.column_color[level])

                nav_box.junctions.append(junction)
                box.add(junction)
                nav_box.add(box)

                # The default behavior of the 'add' function
                # doesn't guarantee that they are visible:
                junction.show()
                box.show()

        d = self._main_d.group_def
        nav_box = self.d[wk.NAV_BOX]
        path += group_key.split(",")[0],

        if group_key in d:
            _add_junction()
            e = {
                wk.COLOR: self.column_color[level],
                wk.CONTAINER: g,
                wk.GROUP_KEY: group_key,
                wk.PATH: path
            }
            a = e[wk.GROUP_TYPE] = d[group_key][wk.WIDGET]

            e.update(self.d)

            if a == Node:
                self.create_node(e, group_key, level, path)

            elif a == PerCell:
                draw_per_cell(e, group_key)
            else:
                for i in BUTTON_KEY:
                    if i in d[group_key]:
                        e[i] = True
                        break

                if wk.HAS_PRESET in d[group_key]:
                    e[wk.HAS_PRESET] = True

                e[wk.KEYS] = a.get_keys(group_key)
                OptionGroup.draw_group(**e)
        return level - 1, path[:-1]
