#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Model as md, Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
from roller_render_gradient_light import GradientLight
import gimpfu as fu

em = Fu.Emboss
hs = Fu.HueSaturation
pdb = fu.pdb
ELEVATION_30 = 30
SIX_COORDINATES = 6
EIGHT_COORDINATES = 8


def do_grid(j, image_layer, effect_layer, o):
    """
    Do effect for each image in the cell grid.

    j: GIMP image
        Is render.

    image_layer: layer
        with layer position

    effect_layer: layer
        for frame

    o: One
        Has variables.
    """
    cat = Hat.cat
    d = o.grid.d
    is_merge_cell = o.grid.is_merge_cell
    n = image_layer.parent.name.split(" ")[-1]

    if not is_merge_cell:
        s = 1
    for r in range(o.r):
        for c in range(o.c):
            if is_merge_cell:
                s = d[ok.PER_CELL][r][c]

            # '(-1, -1)' is a dependent cell in a merge cell table:
            if s != (-1, -1):
                k = o.model_name, r, c

                cat.join_selection(k)
                if Sel.is_sel(j):
                    if o.is_nested_group:
                        if cat.get_z_height(k) == n:
                            process_image(o, effect_layer)
                    else:
                        process_image(o, effect_layer)


def embellish(j, z):
    """
    Add color and depth to the frame.

    j: GIMP image
        Is render.

    z: layer
        Has frame.

    Return: layer
        with new features
    """
    n = z.name
    group = Lay.group(j, n, parent=z.parent, layer=z)
    z1 = Lay.clone(z)
    z1.mode = fu.LAYER_MODE_OVERLAY
    z1.opacity = 25.
    z1 = Lay.clone(z1)
    z1.mode = fu.LAYER_MODE_BURN
    z1.opacity = 50.

    pdb.plug_in_emboss(
        j, z,
        Hat.cat.azimuth,
        ELEVATION_30,
        em.DEPTH_3,
        em.EMBOSS
    )
    pdb.gimp_selection_none(j)

    z = Lay.merge_group(group)
    z.name = n

    pdb.gimp_drawable_hue_saturation(
        z,
        fu.HUE_RANGE_ALL,
        hs.HUE_OFFSET_0,
        hs.LIGHTNESS_0,
        hs.SATURATION_MINUS_50,
        hs.OVERLAP_0
    )
    pdb.gimp_curves_spline(
        z,
        fu.HISTOGRAM_RED,
        SIX_COORDINATES,
        [0, 0, 149, 193, 255, 255]
    )
    pdb.gimp_curves_spline(
        z,
        fu.HISTOGRAM_GREEN,
        SIX_COORDINATES,
        [0, 0, 132, 102, 255, 255]
    )
    pdb.gimp_curves_spline(
        z,
        fu.HISTOGRAM_BLUE,
        EIGHT_COORDINATES,
        [0, 0, 54, 15, 170, 125, 255, 255]
    )
    return z


def finish_effect_layer(j, image_layer, effect_layer):
    """
    Apply finishing touches to an effect layer.

    j: GIMP image
        Is render.

    image_layer: layer or group
        Has image material.

    effect_layer: layer
        Has effect.

    return: layer or None
        with effect material and finishing touches
    """
    if effect_layer:
        Lay.clear_image_sel(image_layer, effect_layer)
        return GradientLight.apply_light(
            embellish(j, effect_layer),
            ok.METAL_FRAME
        )


def process_image(o, z):
    """
    Do the effect for an image.

    o: One
        Has variables.

    z: layer
        to receive effect
    """
    j = Hat.cat.render.image
    d = o.d

    pdb.plug_in_sel2path(j, z)
    if j.active_vectors:
        stroke = j.active_vectors.strokes[0]

        pdb.gimp_selection_none(j)
        RenderHub.brush_stroke_on_stroke(
            z,
            'dots',
            d[ok.BRUSH_SIZE],
            stroke,
            d[ok.BRUSH_SIZE] / 15.,
            .0
        )


def process_layer(j, image_layer, o):
    """
    Add frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    if o.model in md.MULTI_IMAGE:
        effect_layer = Lay.add_above(image_layer, n=o.k)
        do_grid(j, image_layer, effect_layer, o)

    else:
        # custom cell:
        effect_layer = None
        Hat.cat.join_selection(o.model_name)
        if Sel.is_sel(j):
            effect_layer = Lay.add_above(image_layer, n=o.k)
            process_image(o, effect_layer)
    return finish_effect_layer(j, image_layer, effect_layer)


class BallJoint:
    """
    Create a metallic image frame_name from a brush with overlapping circles.
    """

    @staticmethod
    def do(o):
        """
        Do the Ball Joint image-effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer, list or None
            with frame(s)
        """
        RenderHub.set_brush({ok.BRUSH: "dots"})

        j = Hat.cat.render.image
        z = o.image_layer

        # 'undo_z' is a list of layers for the preview's undo function:
        undo_z = []
        o.shadow_layer = [z]

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], o)]

        else:
            undo_z = process_layer(j, z, o)
            if undo_z:
                o.shadow_layer = [undo_z, z]
        return undo_z
