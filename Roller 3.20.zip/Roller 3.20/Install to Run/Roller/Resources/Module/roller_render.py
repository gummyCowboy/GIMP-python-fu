#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Plan as fy, Plaque as aq
from roller_constant_key import (
    Group as gk,
    Layer as nk,
    Model as md,
    Option as ok,
    Plan as ak
)
from roller_model_table import CustomCell, Grid, Stack
from roller_model_border import Border
from roller_model_caption import Caption
from roller_model_fringe import Fringe
from roller_model_image_mask import ImageMask
from roller_model_place import Place
from roller_model_plaque import Plaque
from roller_one import Base, Hat
from roller_one_fu import Lay
import gimpfu as fu

pdb = fu.pdb
PLAN = 'plan'
PRODUCT = 'product'

# Is a dispatch switch for the image caption option group:
ASSIGN_CAPTION = {
    md.CELL: Caption.do_custom_cell,
    md.STACK: Caption.do_stack,
    md.TABLE: Caption.do_grid
}

# Is a dispatch switch for the image place option group:
ASSIGN_PLACE = {
    md.CELL: Place.do_custom_cell,
    md.STACK: Place.do_stack,
    md.TABLE: Place.do_grid
}

# Is a dispatch switch for the image mask option group:
ASSIGN_MASK = {
    md.CELL: ImageMask.do_custom_cell,
    md.STACK: ImageMask.do_stack,
    md.TABLE: ImageMask.do_layers
}


def undo_caption(q):
    """
    Undo a caption operation.

    q: tuple
        (layer, stripe dict)
    """
    z, Hat.cat.caption_stripe_sel = q
    Lay.remove(z)


class Render:
    """
    Is factored from the classes Product and Plan.

    Renders and plans are processed in steps. Steps are
    tuples where each selected Node label in the navigation
    tree is included in sequential order: (label1, label2, label3, etc.).
    """
    backdrop_image_layer = None

    def __init__(self, render_type):
        """Initialize common variables."""
        self.render_type = render_type
        self.grid = self.model = self.model_name = \
            self.plan_group = self.model_group = self.backdrop_layer = None

        self.undo = {}
        self.plan_flags = {}
        self.image_index = deepcopy(Place.IMAGE_INDEX)

        # Do not have dependency with layer margins:
        self.non_layer_d = {
            gk.GLOBAL: self._do_globals,

            # table:
            gk.CELL_BORDER: self._do_cell_border,
            gk.CELL_CAPTION: self._do_caption,
            gk.CELL_FRINGE: self._do_cell_fringe,
            gk.CELL_IMAGE_MASK: self._do_image_mask,
            gk.CELL_IMAGE_PLACE: self._do_image_place,
            gk.CELL_MARGIN: self._do_margin,
            gk.CELL_PLAQUE: self._do_cell_plaque,
            gk.TABLE_PROPERTY: self._do_table_property,

            # custom cell:
            gk.CUSTOM_CELL_BORDER: self._do_cell_border,
            gk.CUSTOM_CELL_CAPTION: self._do_caption,
            gk.CUSTOM_CELL_FRINGE: self._do_cell_fringe,
            gk.CUSTOM_CELL_IMAGE_MASK: self._do_image_mask,
            gk.CUSTOM_CELL_IMAGE_PLACE: self._do_image_place,
            gk.CUSTOM_CELL_PLAQUE: self._do_cell_plaque,
            gk.CUSTOM_CELL_MARGIN: self._do_margin,
            gk.CUSTOM_CELL_PROPERTY: self._do_custom_cell_property,
            gk.RECTANGLE: self._do_rectangle,

            # stack:
            gk.STACK_CELL_MARGIN: self._do_margin,
            gk.STACK_IMAGE_PLACE: self._do_image_place,
            gk.STACK_PILE: self._do_stack_pile,
            gk.STACK_PROPERTY: self._do_stack_property
        }

        # Have dependency with layer margins:
        self.layer_d = {
            gk.LAYER_BORDER: self._do_layer_border,
            gk.LAYER_CAPTION: self._do_layer_caption,
            gk.LAYER_FRINGE: self._do_layer_fringe,
            gk.LAYER_PLAQUE: self._do_layer_plaque
        }

    def _do_caption(self, o):
        """
        Perform a caption process for a table or custom cell.

        o: One
            Has variables.
        """
        cat = Hat.cat
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CAPTION]:
                go = False
            else:
                is_plan = True
                o.color = fy.CELL_STRIPE_COLOR
        if go:
            d = Base.copy_sel_dict(cat.caption_stripe_sel)
            cat.caption_stripe_sel = {}
            z = ASSIGN_CAPTION[o.model](o, is_plan)

            if is_plan and z:
                z.name = "Cell Caption"
                z.opacity = 66.

            self.undo[o.path] = (z, d), undo_caption
            if not is_plan:
                # for blur behind:
                cat.register_layer(
                    (self.model_name, nk.CELL_CAPTION),
                    z
                )

    def _do_cell_border(self, o):
        """
        Draw cell borders.

        o: One
            Has variables.
        """
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.BORDER]:
                go = False
            else:
                is_plan = True
                o.color = fy.CELL_BORDER_COLOR

        if go:
            if o.k == gk.CELL_BORDER:
                z = Border.do_grid(o, is_plan)

            else:
                z = Border.do_custom_cell(o, is_plan)
            if is_plan and z:
                z.name = "Cell Border"
                z.opacity = 66.
            self.undo[o.path] = z, Lay.remove

    def _do_cell_fringe(self, o):
        """
        Do cell fringe.

        o: One
            Has variables.
        """
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CELL_FRINGE]:
                go = False
            else:
                is_plan = True
                o.color = fy.CELL_FRINGE_COLOR
        if go:
            d = deepcopy(self.image_index)
            o.plaque_layer = Hat.cat.get_layer(
                (self.render_type, o.model_name, nk.CELL_PLAQUE)
            )
            if o.k == gk.CELL_FRINGE:
                z = Fringe.do_grid(o, is_plan)

            else:
                z = Fringe.do_custom_cell(o, is_plan)

            if is_plan and z:
                z.opacity = 66.
                z.name = "Cell Fringe"
            self.undo[o.path] = (
                (z, o.plaque_layer, o.is_mask, o.is_paint, d),
                self._undo_fringe
            )

    def _do_cell_plaque(self, o):
        """
        Perform a cell plaque process for a custom cell or grid.

        o: One
            Has variables.
        """
        cat = Hat.cat
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CELL_PLAQUE]:
                go = False
            else:
                is_plan = True
                o.color = fy.CELL_PLAQUE_COLOR
        if go:
            d = Base.copy_sel_dict(cat.plaque_sel)
            e = deepcopy(self.image_index)
            cat.plaque_sel = {}

            if o.k == gk.CELL_PLAQUE:
                z = Plaque.do_grid(o, is_plan)

            else:
                # custom cell and stack:
                z = Plaque.do_custom_cell(o, is_plan)

            if z and is_plan:
                z.name = "Cell Plaque"
                z.opacity = 66.

            self.undo[o.path] = (z, d, e), self._undo_cell_plaque
            Hat.cat.register_layer(
                (self.render_type, self.model_name, nk.CELL_PLAQUE),
                z
            )

    def _do_margin(self, o):
        """
        Calculate the cell margins and pocket for cells.
        A pocket is a rectangle calculated from
        the cell rectangle minus the cell's margins.

        o: One
            Has variable, 'path'.
        """
        a = self.grid.clone()

        self.grid.calc_pocket(o)
        self.undo[o.path] = (a,), self._undo_cell_margin

    def _do_custom_cell_property(self, o):
        """
        Set the custom cell's globals.

        o: One
            Has option dictionary.
        """
        cat = Hat.cat
        d = o.d
        n = Hat.dog.group_id.get_name(o.path[2])
        z = Lay.group(cat.render.image, n, offset=Hat.dog.plan.get_offset())
        q = (
            z,
            self.grid.clone() if self.grid else None,
            self.model,
            self.model_group,
            self.model_name,
            deepcopy(self.plan_flags)
        )
        self.grid = CustomCell(o)
        self.model_group = z
        self.model_name = n
        self.model = md.CELL
        self.plan_flags = d[ok.CELL_PLAN]
        self.undo[o.path] = q, self._undo_custom_cell_property

    def _do_globals(self, o):
        """
        Set the globals in cat. There is no
        compliment for this group's change.

        o: One
            Has globals dict.
        """
        d = o.d
        cat = Hat.cat
        cat.elevation = d[ok.ELEVATION]
        cat.azimuth = d[ok.AZIMUTH]
        cat.is_close_file = d[ok.CLOSE_FILE]
        cat.render.size = d[ok.RENDER_WIDTH], d[ok.RENDER_HEIGHT]
        cat.seed_global = d[ok.SEED_GLOBAL]

        # Trigger a reset if it's needed:
        cat.render.image

        if self.render_type == PLAN and not self.plan_group:
            self.plan_group = Lay.group(cat.render.image, "Plan")

    def _do_image_mask(self, o):
        """
        Perform an image mask operation for a custom cell or grid.

        o: One
            Has variables.
        """
        cat = Hat.cat
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.IMAGE_MASK]:
                go = False
            else:
                o.image_layer = cat.get_layer(
                    (
                        self.render_type,
                        self.model_name,
                        nk.IMAGE
                    )
                )
        if go:
            d = Base.copy_sel_dict(cat.mask_sel)
            e = deepcopy(self.image_index)
            cat.mask_sel = {}
            z = ASSIGN_MASK[o.model](o)
            self.undo[o.path] = (z, d, e), self._undo_image_mask

    def _do_image_place(self, o):
        """
        Perform an image place process for a custom cell and grid.

        o: One
            Has variables.
        """
        cat = Hat.cat
        go = True
        is_plan = False

        if self.render_type == PLAN:
            is_plan = True
            if not self.plan_flags[ak.IMAGE]:
                go = False
        if go:
            d = Base.copy_sel_dict(cat.image_sel)
            e = deepcopy(self.image_index)
            cat.image_sel = {}
            z = ASSIGN_PLACE[o.model](o, is_plan)

            if is_plan and z:
                z.name = "Image"
                z.opacity = 66.

            cat.register_layer(
                (self.render_type, self.model_name, nk.IMAGE),
                z
            )
            self.undo[o.path] = (z, d, e), self._undo_image_place

    def _do_layer_border(self, o):
        """
        Draw layer border.

        o: One
            Has a border dict.
        """
        go = True
        is_plan = False

        if self.render_type == PLAN:
            if not self.plan_flags[ak.BORDER]:
                go = False
            else:
                is_plan = True
                o.color = fy.LAYER_BORDER_COLOR
        if go:
            z = Border.do_layer(o, is_plan)

            if is_plan and z:
                z.opacity = 66.
                z.name = "Layer Border"
            self.undo[o.path] = z, Lay.remove

    def _do_layer_caption(self, o):
        """
        Plan a layer caption.

        o: One
            Has variables.
        """
        go = True
        is_plan = False

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CAPTION]:
                go = False
            else:
                is_plan = True
                o.color = fy.LAYER_CAPTION_COLOR
        if go:
            z = Caption.do_layer(o, is_plan)

            if is_plan and z:
                z.opacity = 66.
                z.name = "Layer Caption"
            self.undo[o.path] = z, Lay.remove

    def _do_layer_fringe(self, o):
        """
        Draw layer fringe.

        o: One
            Has layer fringe dict.
        """
        go = True
        is_plan = False

        # Update the 'rect_shape' variable which is
        # used by layer fringe when clipping the fringe:
        o.grid.update_rect_shape(o)

        if self.render_type == PLAN:
            is_plan = True
            if not self.plan_flags[ak.LAYER_FRINGE]:
                go = False
            else:
                o.color = fy.LAYER_FRINGE_COLOR
        if go:
            d = deepcopy(self.image_index)
            o.plaque_layer = Hat.cat.get_layer(
                (self.render_type, self.model_name, nk.LAYER_PLAQUE)
            )
            z = Fringe.do_layer(o, is_plan)

            if is_plan and z:
                z.opacity = 66.
                z.name = "Layer Fringe"
            self.undo[o.path] = (
                (z, o.plaque_layer, o.is_mask, o.is_paint, d),
                self._undo_fringe
            )

    def _do_layer_plaque(self, o):
        """
        Draw a layer plaque on its own layer.

        o: One
            Has layer plaque dict.
        """
        cat = Hat.cat
        d = o.d
        e = Base.copy_sel_dict(cat.plaque_sel)
        d1 = deepcopy(self.image_index)
        cat.plaque_sel = {}
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.LAYER_PLAQUE]:
                go = False
            else:
                is_plan = True
                o.color = fy.LAYER_PLAQUE_COLOR
                if d[ok.PLAQUE_TYPE] != "None":
                    d[ok.PLAQUE_TYPE] = aq.COLOR
        if go and d[ok.PLAQUE_TYPE] != "None":
            z = Plaque.do_layer(o, is_plan)

            if is_plan and z:
                z.name = "Layer Plaque"
                z.opacity = 66.

            self.undo[o.path] = (z, e, d1), self._undo_layer_plaque
            Hat.cat.register_layer(
                (self.render_type, self.model_name, nk.LAYER_PLAQUE),
                z
            )

    def _do_rectangle(self, o):
        """
        Calculate a cell rectangle.

        o: One
            Has rectangle dictionary.
        """
        a = self.grid.clone()

        self.grid.update_cell_rect(o)

        # The undo tuple needs the None to synchronize
        # with the Plan module's '_do_rectangle_plan':
        self.undo[o.path] = (None, a), self._undo_rectangle

    def _do_stack_pile(self, o):
        """
        Process the Pile option group.

        o: One
            Has Pile preset.
        """
        a = self.grid.clone()

        self.grid.update_pile(o)
        self.undo[o.path] = (a,), self._undo_grid_change

    def _do_stack_property(self, o):
        """
        Create a stack model layer group for the render.

        o: One
            Has option dict.
        """
        cat = Hat.cat
        d = o.d
        a = self.grid.clone() if self.grid else None
        n = Hat.dog.group_id.get_name(o.path[2])
        group = self.model_group
        z = self.model_group = Lay.group(
            cat.render.image,
            n,
            offset=Hat.dog.plan.get_offset()
        )
        self.grid = Stack(o)
        q = z, a, self.model, self.model_name, group, deepcopy(self.plan_flags)
        self.model = md.STACK
        self.model_name = n
        self.plan_flags = d[ok.STACK_PLAN]
        self.undo[o.path] = q, self._undo_stack_property

    def _do_table_property(self, o):
        """
        Create a table model group for the render.

        o: One
            d: dict, table property preset
            path: tuple, key to option group
        """
        cat = Hat.cat
        d = o.d
        n = Hat.dog.group_id.get_name(o.path[2])
        group = self.model_group
        z = self.model_group = Lay.group(
            cat.render.image,
            n,
            offset=Hat.dog.plan.get_offset()
        )
        a = self.grid.clone() if self.grid else None
        q = z, a, self.model, self.model_name, group, deepcopy(self.plan_flags)
        self.grid = Grid(o)
        self.model = md.TABLE
        self.model_name = n
        self.plan_flags = d[ok.TABLE_PLAN]
        self.undo[o.path] = q, self._undo_table_property

    def _undo_cell_plaque(self, q):
        """
        Undo a cell plaque operation.

        q: tuple
            (layer, plaque selection dict, image index dict)
        """
        cat = Hat.cat
        z, d, self.image_index = q

        Hat.cat.unregister_layer(
            None,
            key=(self.render_type, self.model_name, nk.CELL_PLAQUE)
        )
        Lay.remove(z)
        cat.del_channels(cat.plaque_sel)
        cat.plaque_sel = d

    def _undo_cell_margin(self, q):
        """
        Undo a cell margin operation.

        q: tuple
            Has a Table object.
        """
        self.grid = q[0]

    def _undo_custom_cell_property(self, q):
        """
        Undo a custom cell property group's change.

        q: tuple
            Has property values.
        """
        z, self.grid, self.model, self.model_group, \
            self.model_name, self.plan_flags = q
        Lay.remove(z)

    def _undo_fringe(self, q):
        """
        Undo a cell fringe operation.

        q: tuple
            (
                fringe layer,
                plaque layer,
                is mask flag,
                is paint flag,
                image index dict
            )
        """
        z, z1, is_mask, is_paint, self.image_index = q

        if is_mask:
            Lay.discard_mask(z1)
        if is_paint:
            Lay.remove(z)

    def _undo_grid_change(self, q):
        """
        Undo a stack pile option group.

        q: tuple
            (self.grid: Stack)
        """
        self.grid = q[0]

    def _undo_image_mask(self, q):
        """
        Undo an image layer mask.

        q: tuple
            undo variables
        """
        def delete(_z):
            Lay.discard_mask(_z)
            cat.del_channels(cat.mask_sel)

        cat = Hat.cat
        z, d, self.image_index = q

        if isinstance(z, tuple):
            for i in z:
                delete(i)

        else:
            delete(z)
        cat.mask_sel = d

    def _undo_image_place(self, q):
        """
        Undo image place.

        q: tuple
            (layer, image selection dict, image index dict)
        """
        cat = Hat.cat
        z, d, self.image_index = q

        cat.unregister_layer(
            None,
            key=(self.render_type, self.model_name, nk.IMAGE)
        )
        Lay.remove_layers(z)
        cat.del_channels(cat.image_sel)
        cat.image_sel = d

    def _undo_layer_plaque(self, q):
        """
        Undo a layer plaque operation.

        q: tuple
            (plaque layer, plaque sel dict)
        """
        cat = Hat.cat
        z, d, self.image_index = q

        cat.unregister_layer(
            None,
            key=(self.render_type, self.model_name, nk.LAYER_PLAQUE)
        )
        Lay.remove(z)
        cat.del_channels(cat.plaque_sel)
        cat.plaque_sel = d

    def undo_layer(self, q):
        """
        Undo a layer addition.

        q: tuple
            (layer(s), image index dict)
        """
        z, self.image_index = q
        if z is not None:
            if isinstance(z, list):
                for i in z:
                    Lay.remove(i)
            else:
                Lay.remove(z)

    def _undo_rectangle(self, q):
        """
        Undo the rectangle group.

        q: tuple
            (layer, Rect: of custom cell)
        """
        z, self.grid = q
        Lay.remove_layers(z)

    def _undo_stack_property(self, q):
        """
        Undo a stack property operation.

        q: tuple
            with table property variables
        """
        z, self.grid, self.model, self.model_name, self.model_group, \
            self.plan_flags = q
        Lay.remove(z)

    def undo_steps(self, q, steps):
        """
        Perform the undo functions of expired steps.

        q: list
            of changed steps

        steps: list
            of render steps
        """
        d = Hat.cat.group_dict
        for path in q:
            if path in self.undo:
                a, p = self.undo[path]
                p(a)

            # A reset may have removed path:
            if path in self.undo:
                self.undo.pop(path)

            # Update group status and button sensitivity:
            if path not in steps:
                b = d[path]
                if self.render_type == PRODUCT:
                    b.changed = True
                    if b.preview_button:
                        b.preview_button.set_sensitive(1)
                elif self.render_type == PLAN:
                    b.unseen = True
                    if b.plan_button:
                        b.plan_button.set_sensitive(1)

    def _undo_table_property(self, q):
        """
        Undo a table property operation.

        q: tuple
            with grid property variables
        """
        z, self.grid, self.model, self.model_name, self.model_group, \
            self.plan_flags = q
        Lay.remove(z)
