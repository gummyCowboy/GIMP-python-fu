#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as fo
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub, PROFILE
import gimpfu as fu

em = Fu.Emboss
pdb = fu.pdb
um = Fu.UnsharpMask


def process_layer(j, image_layer, o):
    """
    Add frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    cat = Hat.cat
    d = o.d
    if d[ok.OPACITY]:
        parent = image_layer.parent
        group = Lay.group(
            j,
            Lay.name(parent, o.k),
            parent=parent
        )
        z = Lay.add(j, o.k, parent=group)

        # The Stack model has a group of stacked image layers:
        if pdb.gimp_item_is_group(image_layer):
            z1 = Lay.merge_group(Lay.clone(image_layer))
            z2 = Lay.clone_opaque(z1)

            Lay.remove(z1)
            z1 = z2

        else:
            z1 = Lay.clone_opaque(image_layer)

        color = 255, 255, 255
        w = d[ok.FRAME_WIDTH]
        q = PROFILE[d[ok.PROFILE]](w, *(color,))

        Sel.make_layer_sel(z1)
        RenderHub.draw_color_profile(z, w, q, color)
        j.remove_layer(z1)

        if d[ok.CURVE] != "None":
            q = fo.CURVE_DICT[d[ok.CURVE]]
            pdb.gimp_curves_spline(z, fu.HISTOGRAM_VALUE, len(q), q)

        if d[ok.EMBOSS]:
            z = Lay.clone(z)

            pdb.plug_in_emboss(
                j, z,
                cat.azimuth,
                cat.elevation,
                w // 3,
                em.BUMP
            )
            z.opacity = 50. if w < 60. else 100.
            z.mode = fu.LAYER_MODE_MULTIPLY
            z = Lay.clone(z)
            z.mode = fu.LAYER_MODE_SCREEN

        z = Lay.merge_group(group)
        z.opacity = d[ok.OPACITY]
        return GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)


class GlassReveal:
    """Create a glass-like border."""

    @staticmethod
    def do(o):
        """
        Do the image-effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer, list, or None
            with Glass Reveal
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # 'undo_z' is a list of layers for the preview's undo function:
        undo_z = []
        o.shadow_layer = [z]

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], o)]

        else:
            undo_z = process_layer(j, z, o)
            if undo_z:
                o.shadow_layer = [undo_z, z]
        return undo_z
