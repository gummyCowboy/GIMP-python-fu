#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
mo = Fu.Mosaic


def do_job(effect_layer, _, o, sel):
    """
    Draw the ceramic chip filler.

    effect_layer: layer
        Has frame.

    _: layer
        with image, not used

    o: One
        with options

    sel: Selection
        of frame

    Return: layer or list
        with Ceramic Chip
    """
    cat = Hat.cat
    j = cat.render.image
    z = Lay.add_above(effect_layer)

    if o.is_nested_group:
        z = do_grid(j, z, o, sel)

    else:
        z = process_image(j, z, o, sel)
    return z


def process_image(j, z, o, sel):
    """
    Draw the ceramic chip.

    o: One
        with options

    Return: layer
        the ceramic chip layer
    """
    d = o.d
    cat = Hat.cat

    cat.seed(d)

    s = cat.render.size
    a = min(int(d[ok.MESH_SIZE] * 1.2), s[0], s[1])
    z = RenderHub.draw_color_rectangles(z, a, a)

    pdb.gimp_selection_all(j)
    pdb.plug_in_waves(j, z, 10, 1, 50, 0, 1)
    pdb.plug_in_mosaic(
        j, z,
        d[ok.MESH_SIZE],
        mo.TILE_HEIGHT_1,
        mo.TILE_SPACING_MIN,
        mo.TILE_NEATNESS_MIDDLE,
        mo.NO_SPLIT,
        Hat.cat.azimuth,
        mo.MIN_COLOR_VARIATION,
        mo.YES_ANTIALIAS,
        mo.YES_COLOR_AVERAGING,
        bs.MESH_TYPE.index(d[ok.MESH_TYPE]),
        mo.SMOOTH_SURFACE,
        mo.BLACK_AND_WHITE_GROUT
    )

    z = Lay.clone(z)
    z.opacity = 50.
    z.mode = fu.LAYER_MODE_LCH_COLOR

    pdb.plug_in_colorify(j, z, d[ok.COLOR])

    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    Sel.isolate(z, sel)

    z = GradientLight.apply_light(z, ok.OTHER_FRAME)
    return z


def do_grid(j, z, o, sel):
    """
    Do effect for each image in the cell grid.

    j: GIMP image
        Is render.

    z: layer
        to receive effect

    o: One
        Has options.

    Return: layer
        with ceramic material
    """
    # Do one image at a time:
    cat = Hat.cat
    d = o.grid.d
    is_merge_cell = o.grid.is_merge_cell
    s = 1

    # 'n', the image layer's z-height:
    n = z.parent.name.split(" ")[-1]

    for r in range(o.r):
        for c in range(o.c):
            if is_merge_cell:
                s = d[ok.PER_CELL][r][c]

            # Is it a dependent cell?
            if s != (-1, -1):
                k = o.model_name, r, c
                if n == cat.get_z_height(k):
                    cat.join_selection(k)
                    if Sel.is_sel(j):
                        z = process_image(j, z, o, sel)
    return z


class CeramicChip:
    """Create a frame with colorful ceramic pieces."""

    @staticmethod
    def do(o):
        """
        Do the Ceramic Chip image-effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer
            with Ceramic Chip
        """
        return BorderLine.do(o, filler=do_job)
