#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg
from roller_constant_fu import Fu
from roller_constant_key import Model as md, Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb


def do_grid(j, z, group, o):
    """
    Do the effect for each image in the cell grid.

    j: GIMP image
        Is render.

    z: layer
        to receive effect

    group: layer
        Has parent with name which has an appended z-height.

    o: One
        Has options.
    """
    def do():
        Hat.cat.join_selection(k)
        process_image(j, z, o)

    # Do one image at a time:
    cat = Hat.cat
    d = o.grid.d
    is_merge_cell = o.grid.is_merge_cell
    n = group.parent.name.split(" ")[-1]
    s = 1
    for r in range(o.r):
        for c in range(o.c):
            if is_merge_cell:
                s = d[ok.PER_CELL][r][c]

            # Is it a dependent cell?
            if s != (-1, -1):
                k = o.model_name, r, c

                if o.is_nested_group:
                    if cat.get_z_height(k) == n:
                        do()
                else:
                    do()


def process_image(j, z, o):
    """
    Do the effect for an image.

    j: GIMP image
        Is render.

    z: layer
        to receive effect

    o: One
        Has options.
    """
    if Sel.is_sel(j):
        d = o.d

        Sel.grow(j, d[ok.FRAME_WIDTH], 1)

        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(d[ok.SHAPE_BURST]),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            (x1 + x) / 2, (y1 + y) / 2,
            x, y
        )


def process_layer(j, image_layer, o):
    """
    Add a frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    d = o.d
    parent = image_layer.parent
    group = Lay.group(j, Lay.name(parent, o.k), parent=parent)
    z = Lay.add(j, o.k, parent=group)

    RenderHub.set_fill_context(fg.FILL_DICT)
    RenderHub.set_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        fu.GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(d[ok.REVERSE])

    if o.model == md.TABLE:
        do_grid(j, z, group, o)

    else:
        Sel.make_layer_sel(image_layer)
        process_image(j, z, o)

    z = Lay.merge_group(group)

    pdb.gimp_selection_none(j)

    if d[ok.INVERT]:
        pdb.gimp_drawable_invert(z, 0)

    if d[ok.UNSHARP_AMOUNT] and d[ok.UNSHARP_RADIUS]:
        Gegl.unsharp_mask(z, d[ok.UNSHARP_RADIUS], d[ok.UNSHARP_AMOUNT], .0)
        Gegl.blur(z, .5)

    Lay.clear_image_sel(image_layer, z)
    return GradientLight.apply_light(z, ok.OTHER_FRAME)


class ShapeBurst:
    """Create a border from a shape-burst type of gradient."""

    @staticmethod
    def do(o):
        """
        Do the image-effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer or None
            with frame
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # 'undo_z' is a list of layers for the preview's undo function:
        undo_z = []
        o.shadow_layer = [z]

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], o)]

        else:
            if pdb.gimp_item_is_group(z):
                z = Lay.clone(z)
                z = Lay.merge_group(z)
                undo_z = process_layer(j, z, o)

                Lay.remove(z)
                z = o.image_layer

            else:
                undo_z = process_layer(j, z, o)
            if undo_z:
                o.shadow_layer = [undo_z, z]
        return undo_z
