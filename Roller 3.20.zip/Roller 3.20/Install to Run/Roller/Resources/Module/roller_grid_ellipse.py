#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Shape as sh
from roller_one_extract import dispatch


class GridEllipse:
    """
    Calculate the position and the size of a cell.

    The cells is ellipse shaped.
    """

    def __init__(self, o):
        """
        Calculate the ellipse cell size rectangle, shape, and plaque.

        o: One
            Has init values.
            grid: object
                model type
            rect: Rect
                cell rectangle
        """
        a = o.grid.table[0][0]
        a.cell = o.rect.clone()
        a.shape = a.plaque = dispatch[sh.ELLIPSE](o.rect)
