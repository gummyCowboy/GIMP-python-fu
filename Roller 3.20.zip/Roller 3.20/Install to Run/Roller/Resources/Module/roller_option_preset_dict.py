#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import (
    BackdropStyle as bs,
    Bump as fb,
    Fill as fl,
    Frame as fo,
    Gradient as fg,
    Grid as gr,
    Image as fi,
    Justification as ju,
    Model as mo,
    Preset as fp,
    Shape as sh
)
from roller_constant_key import (
    BackdropStyle as by,
    Effect as ek,
    Group as gk,
    Option as ok,
    Plan as ak,
    Step as sk
)
from roller_widget_button import OptionButton
import gtk

# Use to initialize global render size:
screen_width, screen_height = gtk.gdk.screen_width(), gtk.gdk.screen_height()


class PresetDict(OptionButton):
    """Use to manage presets."""

    # dictionaries
    # 'A' is the first in the sort and has
    # dependency in the 'B' group and the others.
    #
    # The OrderDict objects have a widget-type sort-applied. The order
    # is ComboBox, Slider, CheckButton, OptionButton or ColorButton, RadioBox.
    # The sort creates a consistency and an interface aesthetic:
    A_SHADOW = OrderedDict([
        (ok.INTENSITY, 0),
        (ok.SHADOW_BLUR, 15),
        (ok.OFFSET_X, 0),
        (ok.OFFSET_Y, 0),
        (ok.SHADOW_COLOR, (0, 0, 0)),
        (ok.MAKE_OPAQUE, 0)
    ])
    A_INNER_SHADOW = OrderedDict([
        (ok.INTENSITY, 0),
        (ok.INLAY_BLUR, 15),
        (ok.SHADOW_COLOR, (0, 0, 0))
    ])
    A_MARGIN = OrderedDict([
        (ok.FIXED_TOP, 0),
        (ok.FIXED_BOTTOM, 0),
        (ok.FIXED_LEFT, 0),
        (ok.FIXED_RIGHT, 0),
        (ok.FACTOR_TOP, .0),
        (ok.FACTOR_BOTTOM, .0),
        (ok.FACTOR_LEFT, .0),
        (ok.FACTOR_RIGHT, .0),
        (ok.MARGIN_SIZE, "")
    ])
    A_SHIFT = OrderedDict([
        (ok.OFFSET_X, 0),
        (ok.OFFSET_Y, 0),
        (ok.OFFSET_Z, 0),
        (ok.SHIFT_X, 0),
        (ok.SHIFT_Y, 0),
        (ok.SHIFT_Z, 0),
        (ok.SHIFT_WIDTH, 0),
        (ok.SHIFT_HEIGHT, 0),
        (ok.ROTATE, .0),
        (ok.ROTATE_JITTER, .0),
        (ok.WIDTH_MOD, 0),
        (ok.HEIGHT_MOD, 0),
        (ok.RANDOM_SEED, 0)
    ])
    A_TRI_SHADOW = OrderedDict([
        (ok.SHADOW_TYPE, 0),
        (ek.SHADOW_1, A_SHADOW),
        (ek.SHADOW_2, A_SHADOW),
        (ek.INNER_SHADOW, A_INNER_SHADOW)
    ])
    # 'B' is sorted with 'A' and has
    # dependency from the others:
    B_BUMP = OrderedDict([
        (ok.BUMP_TYPE, "None"),
        (ok.BLUR_X, 48),
        (ok.BLUR_Y, 6),
        (ok.NOISE, .12),
        (ok.BUMP_DEPTH, 2),
        (ok.INVERT, 1)
    ])
    B_IMAGE = OrderedDict([
        (ok.IMAGE_SOURCE, "None"),
        (ok.NUMERIC_SEQUENCE, fi.FIRST_IMAGE),
        (ok.IMAGE_NAME, ""),
        (ok.NEXT_INDEX, 0),
        (ok.PREVIOUS_INDEX, 0),
        (ok.LOOP_INDEX, 0),
        (ok.FILE, ""),
        (ok.FOLDER, ""),
        (ok.FILTER, ""),
        (ok.FOLDER_ORDER, 0),
        (ok.AS_LAYERS, 0),
        (ok.LAYER_ORDER, 0),
        (ok.SLICE, 0),
        (ok.ROW_SLICE, 1),
        (ok.COLUMN_SLICE, 1),
        (ok.SLICE_ORDER, 0),
        (ok.AUTOCROP, 0)
    ])
    B_INFLUENCE = OrderedDict([
        (ok.BACKDROP_INFLUENCE, 8.),
        (ok.BORDER_INFLUENCE, 10.),
        (ok.PLAQUE_INFLUENCE, 10.),
        (ok.FRINGE_INFLUENCE, 10.),
        (ok.IMAGE_INFLUENCE, .0),
        (ok.METAL_FRAME, 80.),
        (ok.OTHER_FRAME, 12.),
        (ok.TRANSLUCENT_FRAME, 12.)
    ])
    B_MARGIN = OrderedDict([
        (ok.FIXED_TOP, 0),
        (ok.FIXED_BOTTOM, 0),
        (ok.FIXED_LEFT, 0),
        (ok.FIXED_RIGHT, 0),
        (ok.FACTOR_TOP, .0),
        (ok.FACTOR_BOTTOM, .0),
        (ok.FACTOR_LEFT, .0),
        (ok.FACTOR_RIGHT, .0),
        (ok.MARGIN_SIZE, "")
    ])
    B_RESIZE_METHOD = OrderedDict([
        (ok.RESIZE_TYPE, ok.LOCKED),
        (ok.LOCKED, ""),
        (ok.TRIM, ""),
        (ok.FILLED, ""),
        (ok.COVER, ""),
        (ok.FIXED_IMAGE_SIZE_W, 500),
        (ok.FIXED_IMAGE_SIZE_H, 500),
        (ok.FACTOR_IMAGE_SIZE_W, 1.),
        (ok.FACTOR_IMAGE_SIZE_H, 1.),
        (ok.CROP_X, 0),
        (ok.CROP_Y, 0),
        (ok.CROP_W, screen_width),
        (ok.CROP_H, screen_height)
    ])
    B_SHADOW_DICT = {ok.TRI_SHADOW: A_TRI_SHADOW, ok.SHADOW_TYPE: "None"}
    BACKDROP_IMAGE = OrderedDict([
        (ok.BACKDROP_IMAGE_BLUR, 0),
        (ok.FIT_IMAGE, 1),
        (ok.INVERT, 0),
        (ok.IMAGE, B_IMAGE),
        (ok.BUMP, B_BUMP)
    ])
    BACKDROP_STYLE = {ok.BACKDROP_STYLE: by.BACKDROP_IMAGE}
    BACKGROUND_STRIPE = OrderedDict([
        (ok.STRIPE_TYPE, 0),
        (ok.STRIPE_HEIGHT, 1.5),
        (ok.OPACITY, 100.),
        (ok.BLUR_BEHIND, .0),
        (ok.COLOR, (127, 127, 127))
    ])
    BORDER = OrderedDict([
        (ok.BORDER_TYPE, "None"),
        (ok.GRADIENT_TYPE, fg.GRADIENT_TYPE_LIST[0]),
        (ok.GRADIENT_ANGLE, fg.TOP_RIGHT_TO_BOTTOM_LEFT),
        (ok.MODE, "Normal"),
        (ok.BORDER_WIDTH, 0),
        (ok.OPACITY, 100.),
        (ok.BORDER_BLUR, 0),
        (ok.BLUR_BEHIND, .0),
        (ok.RANDOM_SEED, 0),
        (ok.COMMON_BORDER, 1),
        (ok.OBEY_MARGINS, 0),
        (ok.BUMP, B_BUMP),
        (ok.COLOR, (127, 127, 127)),
        (ok.GRADIENT, fp.DEFAULT),
        (ok.IMAGE, B_IMAGE),
        (ok.PATTERN, "Pine"),
        (ok.TRI_SHADOW, B_SHADOW_DICT)
    ])
    BRUSH = OrderedDict([
        (ok.BRUSH_SIZE, 100.),
        (ok.BRUSH_SPACING, 100.),
        (ok.BRUSH_ANGLE, .0),
        (ok.ANGLE_JITTER, .0),
        (ok.BRUSH_HARDNESS, 1.),
        (ok.OPACITY, 100.),
        (ok.BRUSH, "1. Pixel")
    ])
    CAPTION = OrderedDict([
        (ok.CELL_CAPTION_TYPE, "None"),
        (ok.CUSTOM_CELL_CAPTION_TYPE, "None"),
        (ok.LAYER_CAPTION_TYPE, "None"),
        (ok.JUSTIFICATION, ju.TOP_LEFT),
        (ok.TEXT, ""),
        (ok.LEADING_TEXT, ""),
        (ok.TRAILING_TEXT, ""),
        (ok.START_NUMBER, 1),
        (ok.OPACITY, 100.),
        (ok.FONT_SIZE, 24),
        (ok.OBEY_MARGINS, 1),
        (ok.CLIP_TO_CELL, 1),
        (ok.COLOR, (0, 0, 0)),
        (ok.FONT, "Tahoma"),
        (ok.CAPTION_MARGIN, A_MARGIN),
        (ok.TRI_SHADOW, B_SHADOW_DICT),
        (ok.BACKGROUND_STRIPE, BACKGROUND_STRIPE)
    ])
    CELL_PLAN = OrderedDict([
        (ak.BORDER, 1),
        (ak.CAPTION, 1),
        (ak.CELL_FRINGE, 1),
        (ak.CELL_MARGINS, 1),
        (ak.CELL_PLAQUE, 1),
        (ak.CELL_SHAPE, 1),
        (ak.COORDINATES, 0),
        (ak.CORNERS, 0),
        (ak.DIMENSIONS, 0),
        (ak.IMAGE, 1),
        (ak.IMAGE_MASK, 1),
        (ak.NAME, 0),
        (ak.RATIOS, 0),
        (ak.RECTANGLE, 1)
    ])
    FRINGE = OrderedDict([
        (ok.FRINGE_TYPE, "None"),
        (ok.GRADIENT_TYPE, fg.GRADIENT_TYPE_LIST[0]),
        (ok.GRADIENT_ANGLE, fg.TOP_RIGHT_TO_BOTTOM_LEFT),
        (ok.MODE, "Normal"),
        (ok.CONTRACT, 0),
        (ok.RANDOM_SEED, 0),
        (ok.OBEY_MARGINS, 0),
        (ok.CLIP_TO_CELL, 1),
        (ok.BRUSH_DICT, BRUSH),
        (ok.BUMP, B_BUMP),
        (ok.COLOR, (0, 0, 0)),
        (ok.COLOR_1, (87, 87, 87)),
        (ok.COLOR_2, (174, 174, 174)),
        (ok.GRADIENT, fp.DEFAULT),
        (ok.IMAGE, B_IMAGE),
        (ok.PATTERN, "Pine"),
        (ok.TRI_SHADOW, B_SHADOW_DICT)
    ])
    GLOBAL = OrderedDict([
        (ok.RENDER_WIDTH, screen_width),
        (ok.RENDER_HEIGHT, screen_height),
        (ok.AZIMUTH, 45.),
        (ok.ELEVATION, 30.),
        (ok.SEED_GLOBAL, 0),
        (ok.CLOSE_FILE, 0),
        (ok.DELETE_PLANS, 1)
    ])
    GRADIENT_LIGHT = OrderedDict([
        (ok.GRADIENT_TYPE, "Bilinear"),
        (ok.OFFSET, 0),
        (ok.ROTATE, .0),
        (ok.START_X, .0),
        (ok.START_Y, 1.),
        (ok.END_X, 1.),
        (ok.END_Y, .0),
        (ok.INVERT, 0),
        (ok.REVERSE, 0),
        (ok.INFLUENCE, B_INFLUENCE),
        (ok.GRADIENT, fp.DEFAULT),
        (ok.GRADIENT_POSITION, "")
    ])
    IMAGE_MASK = OrderedDict([
        (ok.MASK_TYPE, "None"),
        (ok.TEXT, "A"),
        (ok.HORZ_SCALE, 1.),
        (ok.VERT_SCALE, 1.),
        (ok.ROTATE, .0),
        (ok.FEATHER, 0),
        (ok.STEPS, 1),
        (ok.FONT, "Tahoma"),
        (ok.IMAGE, B_IMAGE)
    ])
    IMAGE_PLACE = OrderedDict([
        (ok.JUSTIFICATION, ju.CENTER),
        (ok.OPACITY, 100.),
        (ok.BLUR_BEHIND, .0),
        (ok.ROTATE, .0),
        (ok.FLIP_HORIZONTAL, 0),
        (ok.FLIP_VERTICAL, 0),
        (ok.IMAGE, B_IMAGE),
        (ok.RESIZE_METHOD, B_RESIZE_METHOD),
        (ok.SHIFT, A_SHIFT)
    ])
    MODEL = {ok.MODEL_LIST: []}
    PER_CELL = {ok.PER_CELL: []}
    PLAQUE = OrderedDict([
        (ok.PLAQUE_TYPE, "None"),
        (ok.GRADIENT_TYPE, fg.GRADIENT_TYPE_LIST[0]),
        (ok.GRADIENT_ANGLE, fg.GRADIENT_ANGLE[0]),
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.BLUR_BEHIND, .0),
        (ok.FEATHER, 0),
        (ok.STEPS, 1),
        (ok.BLUR, 0),
        (ok.INTENSITY, 200),
        (ok.INLAY_BLUR, 50),
        (ok.NET_LINE_SPACING, 6),
        (ok.NET_LINE_WIDTH, 2),
        (ok.RANDOM_SEED, 0),
        (ok.OBEY_MARGINS, 0),
        (ok.BUMP, B_BUMP),
        (ok.PLAQUE_MASK, IMAGE_MASK),
        (ok.TRI_SHADOW, B_SHADOW_DICT),
        (ok.COLOR, (127, 127, 127)),
        (ok.SHADOW_COLOR, (0, 0, 0)),
        (ok.GRADIENT, fp.DEFAULT),
        (ok.IMAGE, B_IMAGE),
        (ok.PATTERN, "Pine")
    ])
    STACK_PLAN = OrderedDict([
        (ak.BORDER, 1),
        (ak.CAPTION, 1),
        (ak.CELL_FRINGE, 1),
        (ak.CELL_MARGINS, 1),
        (ak.CELL_PLAQUE, 1),
        (ak.CELL_SHAPE, 1),
        (ak.COORDINATES, 0),
        (ak.CORNERS, 0),
        (ak.DIMENSIONS, 0),
        (ak.IMAGE, 1),
        (ak.IMAGE_MASK, 1),
        (ak.NAME, 0),
        (ak.RATIOS, 0),
        (ak.RECTANGLE, 1)
    ])
    TABLE_PLAN = OrderedDict([
        (ak.BORDER, 1),
        (ak.CAPTION, 1),
        (ak.CELL_FRINGE, 1),
        (ak.CELL_MARGINS, 1),
        (ak.CELL_PLAQUE, 1),
        (ak.CELL_SHAPE, 0),
        (ak.COORDINATES, 0),
        (ak.CORNERS, 0),
        (ak.DIMENSIONS, 0),
        (ak.GRID, 1),
        (ak.IMAGE, 1),
        (ak.IMAGE_MASK, 1),
        (ak.LAYER_FRINGE, 1),
        (ak.LAYER_PLAQUE, 1),
        (ak.LAYER_MARGINS, 1),
        (ak.NAME, 0),
        (ak.RATIOS, 0)
    ])
    WITH_BUMP = OrderedDict([
        (ok.BUMP_TYPE, fb.NOISE),
        (ok.BLUR_X, 48),
        (ok.BLUR_Y, 6),
        (ok.BUMP_DEPTH, 2),
        (ok.NOISE, .055)
    ])

    # Define the default structure of an option's Preset dictionary:
    _default = {
        by.AVERAGE_COLOR: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.INVERT, 0),
            (ok.BUMP, WITH_BUMP)
        ]),
        by.BACKDROP_IMAGE: BACKDROP_IMAGE,
        by.CARBON_14:  OrderedDict([
            (ok.MESH_TYPE, "Hexagon"),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.MESH_SIZE, 50),
            (ok.NEATNESS, 1.),
            (ok.RANDOM_SEED, 0),
            (ok.BUMP, WITH_BUMP)
        ]),
        by.CLAY_CHEMISTRY: OrderedDict([
            (ok.GRADIENT_TYPE, "Linear"),
            (ok.GRADIENT_ANGLE, fg.TOP_CENTER_TO_BOTTOM_CENTER),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.GRADIENT, "Default"),
            (ok.BUMP, B_BUMP)
        ]),
        by.COLOR_FILL: OrderedDict([
            (ok.CRITERION, fl.CRITERION_LIST[0]),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.THRESHOLD, 1.),
            (ok.START_X, .0),
            (ok.START_Y, .0),
            (ok.INVERT, 0),
            (ok.COLOR, (127, 127, 127)),
            (ok.BUMP, WITH_BUMP)
        ]),
        by.COLOR_GRID: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.ROW, 4),
            (ok.COLUMN, 4),
            (ok.ROTATE, .0),
            (ok.INVERT, 0),
            (ok.COLOR_1, (64, 64, 64)),
            (ok.COLOR_2, (181, 181, 181)),
            (ok.BUMP, WITH_BUMP)
        ]),
        by.CORE_DESIGN: OrderedDict([
            (ok.ROW, 12),
            (ok.COLUMN, 12),
            (ok.OFFSET, 0),
            (ok.OPACITY, 100.),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.GRADIENT, "Default"),
            (ok.COLOR, (0, 0, 0))
        ]),
        by.CRYSTAL_CAVE: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.RANDOM_SEED, 0)
        ]),
        by.CUBISM_COVER: OrderedDict([
            (ok.BACKDROP_TYPE, bs.BACKDROP_IMAGE),
            (ok.GRADIENT_TYPE, fg.SPIRAL_CLOCKWISE),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.BACKDROP_BLUR, 250),
            (ok.TILE_SIZE, 20.),
            (ok.SATURATION, 1.),
            (ok.RANDOM_SEED, 0),
            (ok.GRADIENT, "Default")
        ]),
        by.DARK_FORT: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.ROW, 8),
            (ok.COLUMN, 12),
            (ok.RANDOM_SEED, 0)
        ]),
        by.DENSITY_GRADIENT: OrderedDict([
            (ok.GRADIENT_ANGLE, fg.TOP_CENTER_TO_BOTTOM_CENTER),
            (ok.GRADIENT_MODE, "Luma Lighten Only"),
            (ok.RANDOM_SEED, 0),
            (ok.GRADIENT, "Desert Sunset")
        ]),
        by.ETCH_SKETCH: OrderedDict([
            (ok.SKETCH_TEXTURE, bs.NEWS_TYPE),
            (ok.CELL_SIZE, 9),
            (ok.OPACITY, 100.),
            (ok.EMBOSS, 0),
            (ok.INVERT, 0)
        ]),
        by.FLOOR_SAMPLE: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.NUMBER_OF_SLICES, 6),
            (ok.STARTING_ANGLE, 0),
            (ok.INTENSITY, 0),
            (ok.SHADOW_BLUR, 10),
            (ok.INVERT, 0),
            (ok.COLOR_1, (187, 187, 187)),
            (ok.COLOR_2, (64, 64, 64)),
            (ok.SHADOW_COLOR, (0, 0, 0)),
            (ok.BUMP, B_BUMP)
        ]),
        by.GALACTIC_FIELD: OrderedDict([
            (ok.GRADIENT_TYPE, "Linear"),
            (ok.GRADIENT_ANGLE, fg.TOP_CENTER_TO_BOTTOM_CENTER),
            (ok.MODE, "Subtract"),
            (ok.OPACITY, 30.),
            (ok.GRADIENT, "Galactic Field")
        ]),
        by.GLASS_GAW: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.RANDOM_SEED, 0),
            (ok.BUMP, B_BUMP)
        ]),
        by.GRADIENT_FILL: OrderedDict([
            (ok.GRADIENT_TYPE, "Linear"),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.OFFSET, 0),
            (ok.ROTATE, .0),
            (ok.START_X, .0),
            (ok.START_Y, 1.),
            (ok.END_X, 1.),
            (ok.END_Y, .0),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.GRADIENT, "Default"),
            (ok.BUMP, B_BUMP),
            (ok.GRADIENT_POSITION, "")
        ]),
        by.HISTORIC_TRIP: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.ITERATIONS, 12),
            (ok.SPREAD, 512),
            (ok.SUPERPIXEL_SIZE, 20),
            (ok.SATURATION, .3),
            (ok.BUMP, WITH_BUMP)
        ]),
        by.IMAGE_GRADIENT: OrderedDict([
            (ok.NAME, "Sampled Gradient"),
            (ok.GRADIENT_TYPE, "Linear"),
            (ok.SAMPLE_VECTOR, bs.VERTICAL),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.SAMPLE_RADIUS, 15),
            (ok.SAMPLE_POINTS, 5),
            (ok.ROTATE, .0),
            (ok.START_X, .5),
            (ok.START_Y, .5),
            (ok.DIAGONAL_ROTATION, 45.),
            (ok.KEEP_GRADIENT, 0),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.BUMP, B_BUMP),
            (ok.PREVIEW_MODE, bs.SHOW_GRADIENT)
        ]),
        by.LINE_STONE: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.RANDOM_SEED, 0)
        ]),
        by.LOST_MAZE: OrderedDict([
            (ok.GRADIENT_ANGLE, fg.GRADIENT_ANGLE[0]),
            (ok.ROW_MAZE, 10),
            (ok.COLUMN_MAZE, 10),
            (ok.OFFSET, 0),
            (ok.RANDOM_SEED, 0),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.GRADIENT, "Default")
        ]),
        by.MAZE_BLEND: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.ROW_MAZE, 4),
            (ok.COLUMN_MAZE, 100),
            (ok.RANDOM_SEED, 0)
        ]),
        by.NANO_SUIT: OrderedDict([
            (ok.OPACITY, 99.),
            (ok.INVERT, 0),
            (ok.BUMP, WITH_BUMP)
        ]),
        by.MYSTERY_GRATE: OrderedDict([
            (ok.COLUMN_1, 8),
            (ok.COLUMN_2, 80),
            (ok.OFFSET, 0),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.GRADIENT, "Default")
        ]),
        by.NOISE_RIFT: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.DETAIL_LEVEL, 1),
            (ok.SOFTNESS, 500),
            (ok.RANDOM_SEED, 0),
            (ok.USE_PLASMA, 1),
            (ok.INVERT_NOISE, 0),
            (ok.BUMP, B_BUMP)
        ]),
        by.PATTERN_FILL: OrderedDict([
            (ok.CRITERION, fl.CRITERION_LIST[0]),
            (ok.MODE, "Normal"),
            (ok.THRESHOLD, 1.),
            (ok.OPACITY, 100.),
            (ok.START_X, .0),
            (ok.START_Y, .0),
            (ok.INVERT, 0),
            (ok.PATTERN, "Paper"),
            (ok.BUMP, WITH_BUMP)
        ]),
        by.RAINBOW_VALLEY: OrderedDict([
            (ok.BACKDROP_TYPE, bs.BACKDROP_IMAGE),
            (ok.GRADIENT_TYPE, fg.SPIRAL_CLOCKWISE),
            (ok.POWER, 30),
            (ok.RANDOM_SEED, 0),
            (ok.TEXTURE, 0),
            (ok.EMBOSS, 0),
            (ok.GRADIENT, "Default")
        ]),
        by.ROCKY_LANDING:  OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.BLEND, 12),
            (ok.RANDOM_SEED, 0)
        ]),
        by.SPACETIME_FABRIC: OrderedDict([
            (ok.COMPONENT, "Green"),
            (ok.ROW, 10),
            (ok.COLUMN, 10),
            (ok.EMBOSS, 0)
        ]),
        by.SPECIMEN_SPECKLE: OrderedDict([
            (ok.GRADIENT_TYPE, "Linear"),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.OFFSET, 0),
            (ok.ROTATE, .0),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.PATTERN_1, "Crack"),
            (ok.PATTERN_2, "Leopard"),
            (ok.PATTERN_3, "Paper"),
            (ok.COLOR, (176, 82, 0)),
            (ok.GRADIENT, "Default")
        ]),
        by.SPIRAL_CHANNEL: OrderedDict([
            (ok.SPIRAL_MOD, bs.HORIZONTAL_FLIP),
            (ok.SPIRAL_DISTANCE, .1),
            (ok.OPACITY, 100.),
            (ok.ROW, 1),
            (ok.COLUMN, 1),
            (ok.COLOR, (75, 75, 75)),
            (ok.BUMP, WITH_BUMP),
            (ok.GRADIENT_DIRECTION, bs.CLOCKWISE)
        ]),
        by.SQUARE_CLOUD: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.RANDOM_SEED, 0),
            (ok.COLOR, (127, 255, 127))
        ]),
        by.TRAILING_VINE: OrderedDict([
            (ok.LAYER_COUNT, 7),
            (ok.WAVE_PER_LAYER, 5),
            (ok.RANDOM_SEED, 0),
            (ok.USE_PLASMA, 1)
        ]),
        by.WATERY_PAGE: OrderedDict([(ok.BUMP, B_BUMP)]),
        ek.BALL_JOINT: {ok.BRUSH_SIZE: 60},
        ek.BORDER_LINE: OrderedDict([
            (ok.FRAME_WIDTH, 10),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.BRUSH_PUNCH: OrderedDict([
            (ok.BRUSH_SIZE, 100),
            (ok.BRUSH_SPACING, 100.),
            (ok.ANGLE_JITTER, .0),
            (ok.FRAME_WIDTH, 6),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.BRUSH, "1. Pixel"),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.CAMO_PLANET: OrderedDict([
            (ok.CAMO_TYPE, mo.COMPOSITE),
            (ok.FRAME_WIDTH, 40),
            (ok.SATURATION, 2.),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.CERAMIC_CHIP: OrderedDict([
            (ok.MESH_TYPE, "Triangle"),
            (ok.WIDTH, 45),
            (ok.FRAME_WIDTH, 4),
            (ok.MESH_SIZE, 33),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.COLOR, (0, 255, 0)),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.CIRCLE_PUNCH: OrderedDict([
            (ok.CIRCLE_DIAMETER, 50),
            (ok.WIDTH, 45),
            (ok.FRAME_WIDTH, 4),
            (ok.ROTATE, 45.),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.CLEAR_FRAME: OrderedDict([
            (ok.FRAME_WIDTH, 45),
            (ok.INNER_FRAME_WIDTH, 5),
            (ok.OPACITY, 26.),
            (ok.COLOR, (255, 255, 255)),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.COLOR_BOARD: OrderedDict([
            (ok.FRAME_WIDTH, 1),
            (ok.OPACITY, 100.),
            (ok.COLOR, (255, 255, 255)),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.COLOR_PIPE: OrderedDict([
            (ok.PROFILE, fo.ROUND),
            (ok.NOISE_MODE, "None"),
            (ok.FRAME_WIDTH, 40),
            (ok.NOISE_OPACITY, 100.),
            (ok.RANDOM_SEED, 0),
            (ok.COLOR, (0, 127, 0))
        ]),
        ek.CORNER_TAPE: OrderedDict([
            (ok.TAPE_LENGTH, 150),
            (ok.TAPE_WIDTH, 50),
            (ok.OPACITY, 10.),
            (ok.INTENSITY, 70),
            (ok.SHADOW_BLUR, 6),
            (ok.ANGLE_SHIFT, 5),
            (ok.CORNER_SHIFT, 9),
            (ok.LENGTH_SHIFT, 10),
            (ok.BLUR_BEHIND, 8.),
            (ok.RANDOM_SEED, 0),
            (ok.COLOR, (230, 220, 210))
        ]),
        ek.CUTOUT_PLATE: OrderedDict([
            (ok.FRAME_WIDTH, 100),
            (ok.BEVEL_EDGE_WIDTH, 8),
            (ok.NOISE_OPACITY, 25.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.PATTERN, "Paper")
        ]),
        ek.FEATHER_STEPS: OrderedDict([(ok.FEATHER, 200), (ok.STEPS, 6)]),
        ek.FRAME_OVER: OrderedDict([
            (ok.FRAME, "None"),
            (ok.FRAME_STYLE, fo.PLASMA),
            (ok.MODE, "Normal"),
            (ok.GRADIENT_TYPE, fg.GRADIENT_TYPE_LIST[0]),
            (ok.GRADIENT_ANGLE, fg.GRADIENT_ANGLE[0]),
            (ok.OPACITY, 100.),
            (ok.BLUR_BEHIND, .0),
            (ok.BLUR, 20.),
            (ok.RANDOM_SEED, 0),
            (ok.BUMP, B_BUMP),
            (ok.GRADIENT, fp.DEFAULT),
            (ok.COLOR, (127, 127, 127)),
            (ok.IMAGE, B_IMAGE)
        ]),
        ek.GLASS_REVEAL: OrderedDict([
            (ok.PROFILE, fo.ROUND),
            (ok.CURVE, "None"),
            (ok.OPACITY, 47),
            (ok.FRAME_WIDTH, 50),
            (ok.EMBOSS, 0)
        ]),
        ek.GRADIENT_LEVEL: OrderedDict([
            (ok.NOISE_MODE, "None"),
            (ok.FRAME_WIDTH, 60),
            (ok.OPACITY, 100.),
            (ok.NOISE_OPACITY, 35.),
            (ok.RANDOM_SEED, 1430641197),
            (ok.COLOR_1, (177, 86, 29)),
            (ok.COLOR_2, (118, 73, 42))
        ]),
        ek.HOT_GLUE:  OrderedDict([
            (ok.FRAME_WIDTH, 3),
            (ok.BORDER_BLUR, 2.),
            (ok.BACKDROP_BLUR, 21),
            (ok.WAVE_AMPLITUDE, 4.),
            (ok.WAVELENGTH, 16.),
            (ok.WAVE_PHASE, 1.),
            (ok.INTENSITY, 80),
            (ok.SHADOW_BLUR, 3)
        ]),
        ek.INNER_SHADOW: A_INNER_SHADOW,
        ek.JAGGED_EDGE: OrderedDict([
            (ok.AMPLITUDE, 3),
            (ok.SMOOTHNESS, 4),
            (ok.RANDOM_SEED, 0)
        ]),
        ek.LINE_FASHION: OrderedDict([
            (ok.WIDTH, 45),
            (ok.LINE_WIDTH, 12),
            (ok.GAP_WIDTH, 48),
            (ok.FRAME_WIDTH, 4),
            (ok.ROTATE, 45.),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.MAZE_MIRROR: OrderedDict([
            (ok.MAZE_TYPE, bs.SCATTERED_CONNECTORS),
            (ok.GAP_TYPE, bs.RANDOM),
            (ok.ROW, 10),
            (ok.COLUMN, 10),
            (ok.CELL_GAP, 3),
            (ok.STOP_LENGTH, 25),
            (ok.SCATTER_COUNT, 4),
            (ok.FRAME_WIDTH, 12),
            (ok.COMPOSITION_FRAME_WIDTH, 12),
            (ok.LINE_WIDTH, 12),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.MAZE_DIRECTION, bs.CLOCKWISE),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.METALLIC_PROFILE: OrderedDict([
            (ok.PROFILE, fo.BAND),
            (ok.FRAME_WIDTH, 30)
        ]),
        ek.NO_EFFECT: {},
        ek.PAINT_RUSH: OrderedDict([
            (ok.EDGE_TYPE, bs.PaintRush.WHITE_SOFT),
            (ok.EDGE_MODE, "Lighten Only"),
            (ok.FRAME_WIDTH, 100),
            (ok.POST_BLUR, 0),
            (ok.COLORIZE_OPACITY, 100.),
            (ok.COLOR, (175, 90, 10)),
            (ok.EMBOSS, 0),
            (ok.COLORIZE, 0)
        ]),
        ek.RAD_WAVE: OrderedDict([
            (ok.FRAME_WIDTH, 10),
            (ok.LINE_WIDTH, 8),
            (ok.COMPOSITION_FRAME_WIDTH, 8),
            (ok.ROW, 2),
            (ok.COLUMN, 2),
            (ok.WAVE_AMPLITUDE, 10.),
            (ok.WAVELENGTH, 25.),
            (ok.WHIRL, 0),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.RAISED_MAZE: OrderedDict([
            (ok.FRAME_WIDTH, 8),
            (ok.LINE_WIDTH, 8),
            (ok.COMPOSITION_FRAME_WIDTH, 8),
            (ok.ROW_MAZE, 10),
            (ok.COLUMN_MAZE, 10),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.SHADOW_1: A_SHADOW,
        ek.SHADOW_2: A_SHADOW,
        ek.SHAPE_BURST: OrderedDict([
            (ok.SHAPE_BURST, fg.SHAPE_BURST_SPHERICAL),
            (ok.FRAME_WIDTH, 55),
            (ok.UNSHARP_AMOUNT, 10.),
            (ok.UNSHARP_RADIUS, 11.),
            (ok.UNSHARP_THRESHOLD, .03),
            (ok.REVERSE, 0),
            (ok.INVERT, 0),
            (ok.GRADIENT, "Brushed Aluminium")
        ]),
        ek.SQUARE_CUT: OrderedDict([
            (ok.WIDTH, 45),
            (ok.FRAME_WIDTH, 3),
            (ok.ROW, 20),
            (ok.COLUMN, 20),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.SQUARE_PUNCH: OrderedDict([
            (ok.WIDTH, 50),
            (ok.LINE_WIDTH, 25),
            (ok.GAP_WIDTH, 50),
            (ok.FRAME_WIDTH, 4),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.ROTATE, 45.),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.STAINED_GLASS: OrderedDict([
            (ok.WIDTH, 45),
            (ok.PANE_WIDTH, 100),
            (ok.PANE_HEIGHT, 100),
            (ok.FRAME_WIDTH, 5),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.ROTATE, 45.),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.STRETCH_TRAY: OrderedDict([
            (ok.WIDTH, 50),
            (ok.FRAME_WIDTH, 3),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1)
        ]),
        ek.WIRE_FENCE: OrderedDict([
            (ok.MESH_TYPE, "Hexagon"),
            (ok.MESH_SIZE, 30),
            (ok.WIDTH, 35),
            (ok.WIRE_THICKNESS, 3),
            (ok.NEATNESS, 1.),
            (ok.FRAME_WIDTH, 4),
            (ok.NOISE_OPACITY, 30.),
            (ok.SOFTNESS, 500),
            (ok.DETAIL_LEVEL, 2),
            (ok.RANDOM_SEED, 0),
            (ok.FRAME_TYPE, 1)
        ]),
        gk.BACKGROUND_STRIPE: BACKGROUND_STRIPE,
        gk.BRUSH: BRUSH,
        gk.CAPTION_MARGIN: A_MARGIN,
        gk.CELL_BORDER: BORDER,
        gk.CELL_CAPTION: CAPTION,
        gk.CELL_FRINGE: FRINGE,
        gk.CELL_IMAGE_MASK: IMAGE_MASK,
        gk.CELL_IMAGE_PLACE: IMAGE_PLACE,
        gk.CELL_MARGIN: B_MARGIN,
        gk.CELL_PLAQUE: PLAQUE,
        gk.CUSTOM_CELL_BORDER: BORDER,
        gk.CUSTOM_CELL_CAPTION: CAPTION,
        gk.CUSTOM_CELL_FRINGE: FRINGE,
        gk.CUSTOM_CELL_IMAGE_MASK: IMAGE_MASK,
        gk.CUSTOM_CELL_IMAGE_PLACE: IMAGE_PLACE,
        gk.CUSTOM_CELL_MARGIN: B_MARGIN,
        gk.CUSTOM_CELL_PLAQUE: PLAQUE,
        gk.EFFECT: {},
        gk.GRADIENT_LIGHT: GRADIENT_LIGHT,
        gk.GRID: OrderedDict([
            (ok.GRID_TYPE, gr.CELL_COUNT),
            (ok.CELL_SHAPE, sh.RECTANGLE),
            (ok.CELL_SHAPE_NORMAL, sh.SQUARE),
            (ok.PIN_CORNER, gr.CENTER),
            (ok.ROW_COUNT, 1),
            (ok.COLUMN_COUNT, 1),
            (ok.ROW_HEIGHT, 500),
            (ok.COLUMN_WIDTH, 500),
            (ok.VERT_COUNT, 1),
            (ok.HORZ_COUNT, 1),
            (ok.CELL_SHIFT, 0),
            (ok.GRID_SIZE, "")
        ]),
        gk.IMAGE_CHOICE: B_IMAGE,
        gk.INFLUENCE: B_INFLUENCE,
        gk.LAYER_BORDER: BORDER,
        gk.LAYER_CAPTION: CAPTION,
        gk.LAYER_FRINGE: FRINGE,
        gk.LAYER_MARGIN: A_MARGIN,
        gk.LAYER_PLAQUE: PLAQUE,
        gk.PER_CELL_BORDER: PER_CELL,
        gk.PER_CELL_CAPTION: PER_CELL,
        gk.PER_CELL_FRINGE: PER_CELL,
        gk.PER_CELL_GRID: PER_CELL,
        gk.PER_CELL_IMAGE_PLACE: PER_CELL,
        gk.PER_CELL_IMAGE_MASK: PER_CELL,
        gk.PER_CELL_PLAQUE: PER_CELL,
        gk.PER_CELL_MARGIN: PER_CELL,
        gk.PLAQUE_MASK: IMAGE_MASK,
        gk.PRESET_CUSTOM_CELL: {},
        gk.PRESET_STACK: {},
        gk.PRESET_STEPS: {},
        gk.PRESET_TABLE: {},
        gk.PRESET_TRI_SHADOW: {},
        gk.RECTANGLE: OrderedDict([
            (ok.FIXED_POSITION_X,  0),
            (ok.FIXED_POSITION_Y, 0),
            (ok.FIXED_WIDTH, 0),
            (ok.FIXED_HEIGHT, 0),
            (ok.FACTOR_POSITION_X, .0),
            (ok.FACTOR_POSITION_Y, .0),
            (ok.FACTOR_WIDTH, 1.),
            (ok.FACTOR_HEIGHT, 1.),
            (ok.RECTANGLE_SPECS, "")
        ]),
        gk.RESIZE_METHOD: B_RESIZE_METHOD,
        gk.SHIFT: A_SHIFT,
        gk.STACK_CELL_MARGIN: B_MARGIN,
        gk.STACK_IMAGE_PLACE: IMAGE_PLACE,
        gk.STACK_PILE: OrderedDict([
            (ok.CUSTOM_CELL_SHAPE, sh.RECTANGLE),
            (ok.CELL_COUNT, 6),
            (ok.ADDING_SHIFT_X, 1),
            (ok.ADDING_SHIFT_Y, 1),
            (ok.ADDING_SHIFT_W, 0),
            (ok.ADDING_SHIFT_H, 0),
            (ok.ADDING_SHIFT_ROTATE, 1),
            (ok.IMAGE_GROUP_TYPE, 0)
        ]),
        gk.STEPS: {sk.STEP_LIST: []},
        gk.TRI_SHADOW: {},
        ok.BRUSH_DICT: BRUSH,
        ok.BUMP: B_BUMP,
        ok.CELL_PLAN: CELL_PLAN,
        ok.IMAGE: B_IMAGE,
        ok.SHADOW_DICT: B_SHADOW_DICT,
        ok.TABLE_PLAN: TABLE_PLAN
    }

    @staticmethod
    def get_default(k):
        """
        Get a preset dictionary.
        Is part of a Preset template.

        k: string
            of preset

        Return: dict
            default dict
        """
        if k in PresetDict._default:
            return deepcopy(PresetDict._default[k])
        return {}

    @staticmethod
    def get_keys(k):
        """
        Get the keys belonging to a preset.
        Is part of a Preset template.

        k: string
            of preset

        Return: list
            of preset keys
            of string
        """
        if k in PresetDict._default:
            return PresetDict._default[k].keys()
        return []


class NonPresetDict:
    """
    Are dictionaries that do not have a preset,
    but still have options. Use when drawing groups.
    """
    # Define option group content.
    # Is part of a Preset template:
    _default = {
        ek.NO_EFFECT: {},
        gk.BACKDROP_STYLE: PresetDict.BACKDROP_STYLE,
        gk.CAPTION_BEHIND: {},
        gk.CLEAR_FRAME_BEHIND: {ok.BLUR_BEHIND: 16},
        gk.COLOR_BOARD_BEHIND: {ok.BLUR_BEHIND: 16},
        gk.CUSTOM_CELL_PROPERTY: OrderedDict([
            (ok.CELL_NAME, "Cell 1"),
            (ok.CUSTOM_CELL_SHAPE, sh.RECTANGLE),
            (ok.CELL_PLAN, PresetDict.CELL_PLAN)
        ]),
        gk.GLASS_REVEAL_BEHIND: {ok.BLUR_BEHIND: 16},
        gk.GRADIENT_LEVEL_BEHIND: {ok.BLUR_BEHIND: 16},
        gk.GLOBAL: PresetDict.GLOBAL,
        gk.IMAGE_BEHIND: {},
        gk.IMAGE_EFFECT: {ok.IMAGE_EFFECT: ek.NO_EFFECT},
        gk.MODEL: PresetDict.MODEL,
        gk.SHADOW_TYPE: {ok.SHADOW_TYPE: 0},
        gk.STACK_PROPERTY: OrderedDict([
            (ok.STACK_NAME, "Stack 1"),
            (ok.STACK_PLAN, PresetDict.STACK_PLAN)
        ]),
        gk.STAINED_GLASS_BEHIND: {ok.BLUR_BEHIND: 16},
        gk.TABLE_PROPERTY: OrderedDict([
            (ok.TABLE_NAME, "Table 1"),
            (ok.TABLE_PLAN, PresetDict.TABLE_PLAN)
        ]),
        ok.CELL_PLAN: PresetDict.CELL_PLAN,
        ok.STACK_PLAN: PresetDict.STACK_PLAN,
        ok.TABLE_PLAN: PresetDict.TABLE_PLAN
    }

    @staticmethod
    def get_default(k):
        """
        Get a non-preset dictionary.
        Is part of a Preset template.

        k: string
            of preset

        Return: dict
            default dict
        """
        if k in NonPresetDict._default:
            return deepcopy(NonPresetDict._default[k])
        PresetDict.get_default(k)

    @staticmethod
    def get_keys(k):
        """
        Get the keys belonging to a non-preset group.
        Is part of a Preset template.

        k: string
            of preset

        Return: list
            of preset keys
            of string
        """
        d = NonPresetDict._default
        if k in d:
            a = d[k]

            if isinstance(a, dict):
                return a
            return []
        return PresetDict.get_keys(k)

    @staticmethod
    def update_model_item_name(group_key, k, n):
        """
        Set the default name of a newly created ModelList item.
        The default model dict will then load with the latest name.

        group_key: string
            in '_default'

        k: string
            option key
            of group key dict

        n: string
            item name
        """
        NonPresetDict._default[group_key][k] = n
