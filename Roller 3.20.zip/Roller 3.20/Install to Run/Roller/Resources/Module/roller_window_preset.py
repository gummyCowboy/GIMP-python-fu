#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Widget as fw
from roller_constant_key import Widget as wk, Window as wi
from roller_port import Port
from roller_one import Comm
from roller_option_preset_core import Core
from roller_option_view import EXPOSE
from roller_widget_box import Box, Eventful
from roller_widget_button import Button
from roller_widget_label import Label
from roller_widget_tree import ChoiceList
from roller_window import Window
import gtk
import os


class RWPreset(Window):
    """Is a GTK dialog with a list for the user to select an item."""

    def __init__(self, g):
        """
        Create a preset window.

        g: OptionButton
            Has values.
            Is responsible.
        """
        self.safe = g
        d = {
            wk.WIN: g.win.win,
            wk.WINDOW_TITLE: "Manage the Preset: {}".format(g.group.group_key),
            wk.WINDOW_KEY: wi.PRESET
        }

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortPreset(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()


class PortPreset(Port):
    """Is a port for loading, saving, and deleting a preset."""

    def __init__(self, d, g):
        """
        Draw the window's port.

        d: dict
            Has init values.

        g: OptionButton
            Has option values.

        k: string
            preset key
        """
        self._button = g
        self._key = g.key
        self.group = g.group
        self.group_key = g.group.group_key
        self._external_preset = {}
        self._list = []
        self._dependent_button = []
        self._del_button = self._load_button = self._choice_list = None
        self._update_key = self.group_key
        Port.__init__(self, d)

    def _draw_list_group(self, g):
        """
        Draw the list group.

        g: GTK container
            for list group
        """
        self._external_preset, self._list = Core.collect_preset(self.group_key)
        self._choice_list = ChoiceList(
            **{
                wk.CONTAINER: g,
                wk.LIST: self._list,
                wk.CHOICE: 1,
                wk.ON_KEY_PRESS: self.on_key_press,
                wk.ON_WIDGET_CHANGE: self.on_widget_change
            }
        )
        self.on_widget_change(self._choice_list)

    def _get_selection(self):
        """
        Get the selection in the choice list.

        Return: int or None
            0 to n
        """
        if self._choice_list:
            return self._choice_list.get_sel_x()

    def delete_preset(self, _):
        """
        Delete the selected preset.

        _: Button
            the delete button
            not used
        """
        x = self._get_selection()
        if x is not None:
            n = self._list[x]
            if n in self._external_preset:
                path = self._external_preset[n]
                if Comm.pop_up(
                    self.roller_window.win,
                    0,
                    "Do you want to delete:\n{}?".format(path),
                    "Delete a File Confirmation"
                ):
                    try:
                        os.remove(path)
                        Comm.pop_up(
                            self.roller_window.win,
                            1,
                            "The file:\n" + path + "\nwas removed.",
                            "File Deleted"
                        )

                        if n in self._external_preset:
                            self._external_preset.pop(n)
                            self._list.pop(self._list.index(n))

                        self._choice_list.populate_treeview(self._list)
                        self.on_widget_change(self._choice_list)
                    except Exception as ex:
                        Comm.show_err(ex)
                        Comm.show_err("Roller was unable to delete the file.")

    def draw_process_group(self, g):
        """
        Draw a process group with cancel and accept options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        w1 = w // 2
        hbox = Box(box=gtk.HBox, align=(0, 0, 1, 1))

        cancel_button = Button(
            align=(0, 0, 1, 0),
            on_widget_change=self.cancel,
            padding=(w, w, w, w1),
            text="Cancel"
        )
        self._del_button = Button(
            align=(0, 0, 1, 0),
            on_widget_change=self.delete_preset,
            padding=(w, w, w1, w1),
            text="Delete"
        )
        self._load_button = Button(
            align=(0, 0, 1, 0),
            on_widget_change=self.load_preset,
            padding=(w, w, w1, w),
            text="Load"
        )
        q = cancel_button, self._del_button, self._load_button
        self._dependent_button = self._del_button, self._load_button

        for i in q:
            hbox.add(i)

        g.add(hbox)
        self.keep(q)

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = self._draw_list_group, self.draw_process_group
        name = "Available {}".format(self._key), ""

        for x, p in enumerate(q):
            box = Eventful(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if name[x]:
                vbox.pack_start(
                    Label(
                        padding=(4, 4, 4, 4),
                        text=name[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()
            g.pack_start(box, expand=(True, False)[x])
        self.roller_window.win.vbox.set_size_request(350, 350)

    def load_preset(self, _):
        """
        Use to get the value of the list selection.

        _: Button
            the load button
            not used

        Return: Done
            for GTK event handler
        """
        x = self._choice_list.get_sel_x()
        if x is not None:
            group = self.group
            self.roller_window.win.hide()
            group.preset.load(self._list[x], self._external_preset)

            # Update widget visibility:
            if self._update_key in EXPOSE:
                EXPOSE[self._update_key](self._button)

            # Preview and Plan outputs are outdated:
            group.changed = self.group.unseen = True

            Core.update_view_buttons(group.path)

            if group.preview_button:
                group.preview_button.set_sensitive(1)

            if group.plan_button:
                group.plan_button.set_sensitive(1)

            # Close the window:
            return self.cancel()

    def get_group_value(self):
        """
        Called by 'on_key_press' in Port.

        Load the selected preset.

        Return: Done
            for GTK
        """
        return self.load_preset(None)

    def on_widget_change(self, g):
        """
        Respond to a list choice.

        g: ChoiceList
            with presets
        """
        q = self._dependent_button
        x = self._get_selection()

        if x is not None:
            for i in q:
                i.enable()
        else:
            for i in q:
                i.disable()
