#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_backdrop_image import BackdropImage
from roller_constant_for import (
    Grid as gr,
    Plan as fy,
    Margin as fm,
    Shape as sh
)
from roller_constant_key import (
    BackdropStyle as by,
    Group as gk,
    Model as md,
    Option as ok,
    Plan as ak
)
from roller_model_border import Border
from roller_model_place import Place
from roller_one import Hat, One, Rect
from roller_one_extract import dispatch, Form, Path, Shape
from roller_one_fu import Lay, Sel
from roller_option_preset_dict import PresetDict
from roller_render import Render
import gimpfu as fu

pdb = fu.pdb
PLAN = 'plan'
READY = ": Ready"
WORK = ": Working"

# Is an option group that change and influence
# group follow as render steps go. However,
# it is not needed in the render step-through:
CHANGE_STEP = gk.BACKDROP_STYLE


def draw_cell_info(d, group, rect):
    """
    Draw the cell info per the plan options.

    d: dict
        of plan options

    group: layer
        for new layer

    rect: Rect
        cell rectangle
    """
    if d[ak.COORDINATES]:
        draw_coord(group, rect)

    if d[ak.CORNERS]:
        draw_corners(group, rect)

    if d[ak.DIMENSIONS]:
        draw_dimension(group, rect)
    if d[ak.RATIOS]:
        draw_ratio(group, rect)


def draw_coord(group, rect):
    """
    Draw image coordinates at the top-left of a cell.

    group: layer
        Is parent for new layer.

    rect: Rect
        cell rectangle
    """
    x, y = rect.position
    z = make_text(str(x) + ", " + str(y))
    draw_text(group, z, x + 3, y)


def draw_corners(group, rect):
    """
    Draw image corner coordinates.

    group: layer
        Is parent for new layer.

    rect: Rect
        cell rectangle
    """
    # top-right:
    x, y = rect.position
    w, h = rect.size
    n = str(x + w) + ", " + str(y)
    z = make_text(n)

    draw_text(group, z, x + w - z.width - 3, y)

    # bottom-left:
    n = str(x) + ", " + str(y + h)
    z = make_text(n)
    draw_text(group, z, x + 3, y + h - z.height)


def draw_custom_cell_shape(j, o):
    """
    Draw a custom cell shape.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        with shape
    """
    q = Form.combine_margin(o.d, *Hat.cat.render.size)
    q1 = dispatch[o.grid.cell_shape](o.grid.get_pocket(0, 0))

    if any(q):
        Sel.select_shape(j, q1)
        pdb.gimp_selection_shrink(j, 1)

        sel = pdb.gimp_selection_save(j)
        z = Lay.add(j, "Cell Shape", parent=o.parent)

        Sel.select_shape(j, q1)
        Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
        Sel.fill(z, fy.CELL_SHAPE_COLOR)
        pdb.gimp_image_remove_channel(j, sel)

    else:
        o.color = fy.CELL_SHAPE_COLOR
        o.d = PresetDict.get_default(gk.CELL_BORDER)
        o.d[ok.BORDER_WIDTH] = 1
        z = Border.do_custom_cell(o, True)
    return z


def draw_dimension(group, rect):
    """
    Draw an image's dimension at the bottom-right of a cell.

    group: layer
        Is parent for new layer.

    rect: Rect
        cell rectangle
    """
    x, y = rect.position
    w, h = rect.size
    n = str(w) + ", " + str(h)
    z = make_text(n)
    draw_text(group, z, x + w - z.width - 3, y + h - z.height)


def draw_name(group, n, rect, offset_y=0):
    """
    Draw an image name over a cell image.

    group: layer
        Is parent for text layer.

    n: string
        to draw

    rect: Rect
        cell rectangle

    offset_x, offset_y: int
        Use to change location of name.

    Return: layer
        with text
    """
    z = make_text(n)
    x, y = rect.position
    w, h = rect.size
    x = w // 2 + x - z.width // 2
    y = h // 2 + y + z.height // 2 + offset_y

    draw_text(group, z, x, y)
    return z


def draw_ratio(group, rect):
    """
    Draw a cell ratio at the center of a cell.

    A ratio is a cell center point divided by the render size.

    group: layer
        Is parent for new layer.

    rect: Rect
        cell rectangle
    """
    x, y = rect.position
    w, h = rect.size
    s = Hat.cat.render.size
    x1 = (w // 2 + x) / 1. / s[0]
    y1 = (h // 2 + y) / 1. / s[1]
    r_x = format(x1, '.2f')
    r_y = format(y1, '.2f')
    n = r_x[int(x1 < 1):] + ", " + r_y[int(y1 < 1):]
    z = make_text(n)
    x2 = x + w // 2 - z.width // 2
    y2 = y + h // 2 - z.height // 2
    draw_text(group, z, x2, y2)


def draw_text(group, z, x, y):
    """
    Add a text layer to the group.

    group: layer
        parent

    z: layer
        to receive text

    x, y: int
        final position
        screen coordinate
    """
    pdb.gimp_image_insert_layer(Hat.cat.render.image, z, group, 0)
    pdb.gimp_text_layer_set_color(z, (255, 255, 255))
    pdb.gimp_layer_set_offsets(z, x, y)
    z.opacity = 66.


def make_text(n):
    """
    Create a new text layer.

    n: string
        text to display

    Return: layer
        with text
    """
    return pdb.gimp_text_layer_new(
        Hat.cat.render.image,
        n,
        'Sans-serif',
        11.,
        fu.PIXELS
    )


def update_unseen_flag(steps):
    """
    The change flag is used to indicate an option group's
    render status. If it's changed, then the render needs
    to be done.

    The change flag also has a chain-inheritance. If a step
    is changed, the following steps are also changed.

    steps: list
        of paths (tuples)
        Paths are keys to option group widgets held in 'group_dict'.

    Return: list
        of changed steps
    """
    e = Hat.cat.group_dict
    q = []
    is_change = False

    # Every step after the first changed
    # group is part of a preview.
    # Change the change status as it is
    # assumed that the render will succeed.
    # Remove the CHANGE_STEP group as
    # it has served its purpose:
    for i in steps:
        a = e[i]
        if not is_change and a.unseen:
            is_change = True
        if is_change:
            a.unseen = False
            if a.group_key != CHANGE_STEP:
                q += [i]
    return q


class Plan(Render):
    """Organize Plan methods."""

    def __init__(self):
        """Initialize the plan variables."""
        Render.__init__(self, PLAN)

        self._previous_steps = []

        self.layer_d.update({gk.GRID: self._do_grid})
        self.non_layer_d.update(
            {
                by.BACKDROP_IMAGE: self._do_backdrop_style,
                gk.CELL_MARGIN: self._do_cell_margin,
                gk.LAYER_MARGIN: self._do_layer_margins
            }
        )
        self._extra_op_d = {
            gk.RECTANGLE: self._do_rectangle_plan,

            # table:
            gk.CELL_IMAGE_PLACE: self._draw_cell_image_name,
            gk.TABLE_PROPERTY: self._name_group,

            # custom cell:
            gk.CUSTOM_CELL_IMAGE_PLACE: self._draw_custom_cell_image_name,
            gk.CUSTOM_CELL_MARGIN: self._draw_custom_cell_margin,
            gk.CUSTOM_CELL_PROPERTY: self._name_group,

            # stack:
            gk.STACK_PROPERTY: self._name_group,
            gk.STACK_CELL_MARGIN: self._draw_stack_cell_margin
        }

    def _do_backdrop_style(self, o):
        """
        Create a plan group and a backdrop image layer.

        o: One
            Has globals dict.
        """
        d = deepcopy(self.image_index)
        z = self.backdrop_layer = Lay.add(
            Hat.cat.render.image,
            "Backdrop",
            parent=self.plan_group
        )

        BackdropImage.do(o, is_plan=True)
        Lay.color_fill(z, fy.BACKGROUND_COLOR)
        self.undo[o.path] = (z, d), self.undo_layer

    def _do_cell_margin(self, o):
        """
        Plan grid cell margins. Overrides Render's '_do_margin' method.

        o: One
            Has variables.
        """
        j = Hat.cat.render.image
        q = [self.grid.clone(), None]
        z = None

        self.grid.calc_pocket(o)

        if self.plan_flags[ak.CELL_MARGINS]:
            pdb.gimp_selection_none(j)

            z = Lay.add(j, "Cell Margin", parent=self.model_group)
            z.opacity = 66.
            self._draw_cell_margins(o, z)

        if self.plan_flags[ak.CELL_SHAPE]:
            z = self.draw_grid_cell_shape(j, z, o)
        if z:
            q[1] = z
            self.undo[o.path] = q, self._undo_plan_cell_margin

    def _do_grid(self, o):
        """
        Plan a cell grid.

        o: One
            Has the cell grid dictionary.
        """
        a = self.grid.clone()
        j = Hat.cat.render.image
        z = group = None
        d = self.plan_flags
        n = "Grid"
        s = 1
        is_per_cell = o.d[ok.PER_CELL]

        self.grid.update_grid(o)

        if d[ak.GRID]:
            group = Lay.group(j, n, parent=self.model_group)
            z = Lay.add(j, n, parent=group)
            self._draw_grid(z)

        if any(
            (
                d[ak.COORDINATES],
                d[ak.CORNERS],
                d[ak.DIMENSIONS],
                d[ak.RATIOS]
            )
        ):
            if not group:
                group = Lay.group(j, n, parent=self.model_group)

            row, column = self.grid.division
            for r in range(row):
                for c in range(column):
                    if is_per_cell:
                        s = o.d[ok.PER_CELL][r][c]
                    if (
                        Shape.is_allocated_cell(self.grid, r, c) and
                        s != (-1, -1)
                    ):
                        draw_cell_info(
                            d,
                            group,
                            self.grid.get_merge_cell_rect(r, c)
                        )

        if group:
            z = Lay.merge_group(group)
        self.undo[o.path] = (a, z), self._undo_grid

    def _do_layer_margins(self, o):
        """
        Calculate layer margins. Show layer margins.

        o: One
            Has layer margins dict.
        """
        cat = Hat.cat
        z = None
        a = self.grid.clone()
        self.grid.layer_margin = Form.combine_margin(o.d, *cat.render.size)

        if self.plan_flags[ak.LAYER_MARGINS]:
            z = self._draw_layer_margins(o)
        self.undo[o.path] = (a, z), self._undo_layer_margins

    def _do_rectangle_plan(self, o):
        """
        Process a custom cell rectangle step. Is called after the
        '_do_rectangle' function in the Render module.
        """
        cat = Hat.cat
        j = cat.render.image
        d = self.plan_flags
        group = None
        a = self.grid.rect
        layers = []

        if self.plan_flags[ak.RECTANGLE]:
            group = Lay.group(j, "Rectangle", parent=self.model_group)
            z = Lay.add(j, "Lines", parent=group)
            s = cat.render.size
            x, y = a.position
            w, h = a.size
            layers += [z]

            pdb.gimp_selection_none(j)
            Sel.rect(j, 0, y, s[0], 1)
            Sel.rect(j, 0, y + h, s[0], 1)
            Sel.rect(j, x, 0, 1, s[1])
            Sel.rect(j, x + w, 0, 1, s[1])
            Sel.fill(z, fy.GRID_COLOR)

        if any(
            (d[ak.COORDINATES], d[ak.CORNERS], d[ak.DIMENSIONS], d[ak.RATIOS])
        ):
            if not group:
                group = Lay.group(j, "Info", parent=self.model_group)
            draw_cell_info(d, group, a)
        if group:
            # Insert the layer, 'z', into the undo argument
            # made by the Render module's '_do_rectangle' function:
            Lay.merge_group(group)
            q, p = self.undo[o.path]
            self.undo[o.path] = (layers, q[1]), p

    def _draw_cell_image_name(self, o):
        """
        Draw the image name over a cell image.

        o: One
            Has a Place dict.
        """
        def add_group():
            return Lay.group(
                j,
                "Image Name",
                parent=self.model_group
            )

        if self.plan_flags[ak.NAME]:
            j = Hat.cat.render.image
            grid = o.grid
            row, column = grid.division
            group = None

            if o.model == md.STACK:
                offset_y = 0
                for r in range(row):
                    n = grid.get_image_name(r, 0)
                    if n:
                        if not group:
                            group = add_group()

                        z = draw_name(
                            group,
                            n,
                            self.grid.rect,
                            offset_y=offset_y
                        )
                        offset_y += z.height

            else:
                for r in range(row):
                    for c in range(column):
                        if Shape.is_allocated_cell(grid, r, c):
                            n = grid.get_image_name(r, c)
                            if n:
                                if not group:
                                    group = add_group()
                                draw_name(
                                    group,
                                    n,
                                    grid.get_merge_cell_rect(r, c)
                                )
            if group:
                z = Lay.merge_group(group)

                if o.path in self.undo:
                    q, p = self.undo[o.path]
                    z1, d, e = q
                    self.undo[o.path] = ((z, z1), d, e), p
                else:
                    self.undo[o.path] = z, Lay.remove

    def _draw_cell_margin(self, o, is_one):
        """
        Select cell margins for a cell.

        o: One
            Has model, r, c, d.

        is_one: bool
            Is true when there is only o rectangle to draw.
        """
        def select_margins():
            """
            Select a margin for a cell.

            Return: Selection
                state of image
            """
            a = q[i]

            if a:
                top, bottom, left, right = q
                width, height = rect.size

                if is_one:
                    top1, bottom1, left1, right1 = self.grid.layer_margin

                    if i < 2:
                        width = size[0] - left1 - right1
                    else:
                        height = size[1] - top1 - bottom1

                width = max(1, width - left - right)
                height = max(1, height - top - bottom)
                x, y = rect.position
                x += (left, left, 0, width + left)[i]
                y += (0, height + top, top, top)[i]
                w = (width, width, a, a)[i]
                h = (a, a, height, height)[i]
                Sel.rect(j, x, y, w, h)

        cat = Hat.cat
        e = Form.get_form(o)
        j = cat.render.image
        size = cat.render.size

        if o.model == md.TABLE:
            rect = self.grid.get_merge_cell_rect(o.r, o.c)

        else:
            rect = self.grid.rect

        q = Form.combine_margin(e, *rect.size)
        for i in range(4):
            is_draw = True

            # left, right:
            if i in (fm.LEFT, fm.RIGHT):
                if is_one and o.r > 0:
                    is_draw = False

            # top, bottom:
            else:
                if is_one and o.c > 0:
                    is_draw = False
            if is_draw:
                select_margins()

    def _draw_cell_margins(self, o, z):
        """
        Plan cell margins.

        o: One
            Has path.

        z: layer
            to draw on
        """
        def is_draw_one_margin():
            """
            There is only one margin to draw if the cells have common bounds.
            """
            return not any(
                (
                    grid_d[ok.PER_CELL],
                    is_merge_cell,
                    d[ok.PER_CELL],
                    grid_d[ok.GRID_TYPE] != gr.CELL_COUNT
                )
            )

        cat = Hat.cat
        j = cat.render.image
        row, column = self.grid.division
        grid = self.grid
        double_type = grid.double_type
        is_merge_cell = grid.is_merge_cell
        d = o.d
        grid_d = grid.d
        is_one = is_draw_one_margin() if not double_type else False

        for r in range(row):
            for c in range(column):
                go = True

                if is_merge_cell:
                    if grid_d[ok.PER_CELL][r][c] == (-1, -1):
                        go = False
                if go:
                    if double_type:
                        go = Shape.is_allocated_cell(grid, r, c)
                    if go:
                        o.r, o.c = r, c
                        self._draw_cell_margin(o, is_one)
        if Sel.is_sel(j):
            Sel.fill(z, fy.CELL_MARGIN_COLOR)

    def _draw_custom_cell_margin(self, o):
        """
        Plan cell margins.

        o: One
            Has path.

        z: layer
            to draw on
        """
        j = Hat.cat.render.image

        pdb.gimp_selection_none(j)

        if self.plan_flags[ak.CELL_MARGINS]:
            self._draw_cell_margin(o, False)
            if Sel.is_sel(j):
                z = Lay.add(j, "Cell Margins", parent=self.model_group)
                z.opacity = 66.

                Sel.fill(z, fy.CELL_MARGIN_COLOR)
                self.undo[o.path] = z, Lay.remove
        if self.plan_flags[ak.CELL_SHAPE]:
            draw_custom_cell_shape(j, o)

    def _draw_custom_cell_image_name(self, o):
        """
        Draw the image name over a cell image.

        o: One
            Has a Place dict.
        """
        if self.plan_flags[ak.NAME]:
            n = self.grid.get_image_name(0, 0)
            if n:
                z = draw_name(self.model_group, n, self.grid.rect)
                z.name = "Image Name"

                if o.path in self.undo:
                    q, p = self.undo[o.path]
                    z1, d, e = q
                    self.undo[o.path] = ((z, z1), d, e), p
                else:
                    self.undo[o.path] = z, Lay.remove

    def _draw_grid(self, z):
        """
        Draw grid lines.

        o: One
            Has grid variables.

        z: layer
            to draw on
        """
        cat = Hat.cat
        j = cat.render.image
        m = False
        grid = self.grid
        row, column = grid.division
        w, h = cat.render.size
        top, bottom, left, right = grid.layer_margin
        double_type = grid.double_type

        # Init:
        a = Rect((0, 0), (0, 0))
        y = 0

        # Grid lines divide the layer space:
        w1 = w - left - right
        x = left
        h1 = 1

        pdb.gimp_selection_none(j)

        # Draw rows:
        for r in range(0, row + 1):
            c = 0
            is_draw = True

            if double_type and r != row:
                c = not r % 2 if double_type == sh.SHIFT else r % 2
                c = min(column - 1, c)
                is_draw = Shape.is_allocated_cell(grid, r, c)
            if is_draw:
                if r == row:
                    y += a.h

                else:
                    a = grid.get_cell_rect(r, c)
                    y = a.y
                if 0 < y < h:
                    m = True
                    Sel.rect(j, x, y, w1, h1)

        w1, h1 = 1, h - top - bottom
        y = top

        # Draw columns:
        for c in range(0, column + 1):
            is_draw = True
            r = 0
            if double_type and c != column:
                r = not c % 2 if double_type == sh.SHIFT else c % 2
                r = min(row - 1, r)
                is_draw = Shape.is_allocated_cell(grid, r, c)
            if is_draw:
                if c == column:
                    x += a.w

                else:
                    a = grid.get_cell_rect(r, c)
                    x = a.x
                if 0 < x < w:
                    m = True
                    Sel.rect(j, x, y, w1, h1)
        if m:
            Sel.fill(z, fy.GRID_COLOR)

    def draw_grid_cell_shape(self, j, z, o):
        """
        Draw the cell shape.

        j: GIMP image
            Is render.

        z: layer or None
            to draw on

        o: One
            Has variables.

        Return: layer or None
            the layer that received the cell shape(s)
        """
        o.color = fy.CELL_SHAPE_COLOR
        q = Form.combine_margin(o.d, *Hat.cat.render.size)
        has_margin = True if any(q) or o.d[ok.PER_CELL] else False
        o.d = PresetDict.get_default(gk.CELL_BORDER)
        o.d[ok.BORDER_WIDTH] = 1

        if has_margin:
            row, column = o.grid.division
            for r in range(row):
                for c in range(column):
                    go = True

                    if not Shape.is_allocated_cell(o.grid, r, c):
                        go = False

                    if go and o.grid.is_merge_cell:
                        if o.grid.d[ok.PER_CELL][r][c] == (-1, -1):
                            go = False
                    if go:
                        if not z:
                            z = Lay.add(
                                j,
                                "Cell Shape",
                                parent=self.model_group
                            )

                        q = o.grid.get_shape(r, c)

                        Sel.select_shape(j, q)
                        pdb.gimp_selection_shrink(j, 1)

                        sel = pdb.gimp_selection_save(j)

                        Sel.select_shape(j, q)
                        Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
                        Sel.fill(z, o.color)
                        pdb.gimp_image_remove_channel(j, sel)

        else:
            o.color = fy.CELL_SHAPE_COLOR
            o.d = PresetDict.get_default(gk.CELL_BORDER)
            o.d[ok.BORDER_WIDTH] = 1
            o.d[ok.PER_CELL] = []
            Border.do_grid(o, True)
        return z

    def _draw_layer_margins(self, _):
        """
        Draw the layer margins.

        _: One
            not used

        Return: layer or None
            with layer margins
        """
        cat = Hat.cat
        j = cat.render.image
        z = None
        s = cat.render.size
        q = top, bottom, left, right = self.grid.layer_margin

        pdb.gimp_selection_none(j)

        if any(q):
            for x, i in enumerate(q):
                if i:
                    if x in (fm.TOP, fm.BOTTOM):
                        # top, bottom:
                        x1 = left
                        w = s[0] - left - right

                        if x == fm.TOP:
                            y = 0
                            h = top
                        else:
                            h = bottom
                            y = s[1] - h

                    else:
                        # left, right:
                        h = s[1] - top - bottom
                        y = top

                        if x == fm.LEFT:
                            x1 = 0
                            w = left
                        else:
                            w = right
                            x1 = s[0] - w
                    Sel.rect(j, x1, y, w, h)

            z = Lay.add(j, "Layer Margin", parent=self.model_group)
            z.opacity = 66.
            Sel.fill(z, fy.LAYER_MARGIN_COLOR)
        return z

    def _draw_stack_cell_margin(self, o):
        """
        Draw stack cell margins.

        o: One
            d: dict, margin dict preset
        """
        j = Hat.cat.render.image
        q = []

        pdb.gimp_selection_none(j)

        if self.plan_flags[ak.CELL_MARGINS]:
            self._draw_cell_margin(o, False)
            if Sel.is_sel(j):
                z = Lay.add(j, "Cell Margins", parent=self.model_group)
                q += [z]
                z.opacity = 66.
                Sel.fill(z, fy.CELL_MARGIN_COLOR)

        if self.plan_flags[ak.CELL_SHAPE]:
            z = draw_custom_cell_shape(j, o)
            q += [z]
        self.undo[o.path] = q, Lay.remove_layers

    def _name_group(self, _):
        """
        Rename a model folder with a 'Plan' extension.

        _: One
            not used
        """
        z = self.model_group
        z.name = self.model_name + " Plan"
        pdb.gimp_image_reorder_item(z.image, z, self.plan_group, 0)

    def _undo_plan_cell_margin(self, q):
        """
        Undo a Plan cell margin operation.

        q: tuple
            (Grid, layer)
        """
        self.grid, z = q
        Lay.remove(z)

    def _undo_grid(self, q):
        """
        Undo a grid operation.

        q: tuple
            (Grid, layer)
        """
        self.grid, z = q
        Lay.remove(z)

    def _undo_layer_margins(self, q):
        """
        Undo a layer margins operation.

        q: tuple
            (Grid, layer)
        """
        self.grid, z = q
        Lay.remove(z)

    def _update_previous_steps(self, steps):
        """
        Update previous steps for another plan.
        The previous steps are screened.
        These steps go to the undo stage.

        steps: list
            for the next render
        """
        # Set the change status:
        e = Hat.cat.group_dict
        q = []
        is_change = False

        for i in self._previous_steps[::-1]:
            a = e[i]

            if not is_change and a.unseen:
                is_change = True

            if is_change:
                if a.group_key != CHANGE_STEP:
                    q += [i]
            else:
                if i not in steps:
                    if a.group_key != CHANGE_STEP:
                        q += [i]
        self._previous_steps = q[::-1]

    def delete(self):
        """Delete the plan folder."""
        Lay.remove(self.plan_group)
        self.plan_group = None

    def delete_backdrop(self):
        """Delete the backdrop layer. This is closing procedure."""
        Lay.remove(self.backdrop_layer)

    def do(self, steps, undo):
        """
        Perform a preview.

        steps: list
            A step is based on an option group.
            Are preview or final steps.

        undo: list
            of steps to undo
        """
        cat = Hat.cat
        d = cat.group_dict
        e = self.non_layer_d
        e1 = self.layer_d
        e2 = self._extra_op_d
        is_start = True

        self.show()
        self.undo_steps(undo, steps)

        for step in steps:
            j = cat.render.image
            k = d[step].group_key
            o = One(
                d=Path.get_dict_from_path(step),
                grid=self.grid,
                image_index=self.image_index,
                k=k,
                model=self.model,
                model_name=self.model_name,
                parent=self.model_group,
                path=step,
                render_type=self.render_type
            )

            pdb.gimp_selection_none(j)

            if is_start:
                z = self.plan_group
                if z:
                    z.name = z.name.split(":")[0] + WORK
                    is_start = False

            if k in e:
                e[k](o)

            elif k in e1:
                e1[k](o)
            if k in e2:
                e2[k](o)

        z = self.plan_group
        j = cat.render.image

        if z:
            z.name = z.name.split(":")[0] + READY
            Sel.item(z)
            j.active_layer = z

        elif self.backdrop_layer:
            j.active_layer = self.backdrop_layer
            Sel.item(self.backdrop_layer)

        else:
            pdb.gimp_selection_none(j)

        pdb.gimp_displays_flush()
        cat.del_short_term_sel()

    def hide(self):
        """Hide the plan group."""
        if self.plan_group:
            Lay.hide(self.plan_group)

    def get_offset(self):
        """
        Get the offset needed for Product groups.

        Return: int
            0 or 1
        """
        return 1 if self.plan_group else 0

    def prep(self, q):
        """
        Call to do a render plan.

        q: list
            plan steps

        is_preview: bool
            unused
        """
        self._update_previous_steps(q)

        q1 = q[:]

        # Update before the render:
        q = update_unseen_flag(q)

        q2 = self._previous_steps[:]

        # Reverse the order of the list.
        # Undo is the reverse of the render:
        self._previous_steps = q1[::-1]

        # Create the image:
        self.do(q, q2)

    def reset(self):
        """Reset any variables belonging to the render."""
        self.image_index = deepcopy(Place.IMAGE_INDEX)
        self.undo = {}
        self.grid = self.model = self.plan_group = \
            self.model_group = self.model_name = self.backdrop_layer = None

    def show(self):
        """Show the plan group."""
        if self.plan_group:
            Lay.show(self.plan_group)
