#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Preset as fp
from roller_constant_key import (
    BackdropStyle as by,
    Button as bk,
    Effect as ek,
    Widget as wk
)
from roller_one import Hat
from roller_option_preset import NonPreset, Preset, SuperPreset
from roller_widget_button import Button, PreviewButton
from roller_option_view import EXPOSE, do_opacity
from roller_widget_button_pair import ButtonPair
from roller_widget_check_button import CheckButton
from roller_widget_table import Table

NO_LABEL = CheckButton, Button, PreviewButton
NO_SAVE = (
    wk.HAS_EFFECT_PAIR,
    wk.HAS_GRID_PAIR,
    bk.RANDOM,
    bk.PREVIEW,
    bk.PLAN
)
PREVIEW = by.KEY_LIST + ek.KEY_LIST


class OptionGroup:
    """Has values used to manage a PortOption group."""

    def __init__(self, **d):
        """
        Create an option group.

        d: dict
            Has init values.
        """
        # If changed, the group's preview is not
        # a valid representative of the render:
        self.changed = True

        # Has widgets that populate an option group.
        # The key is an option key. The value is a Widget:
        self.d = {}

        # Use to store the group widget references, so nothing
        # gets lost with the over-zealous GTK garbage disposal:
        self.keep = None

        # of 'Option.options':
        self.group_key = d[wk.GROUP_KEY]

        # Use for tree traversal to determine group's keys:
        self.group_type = d[wk.GROUP_TYPE]

        # Is a Node when the group is made of a Node:
        self.node = None

        # Distinguishes a factored-preset group:
        self.parent_type = d[wk.PARENT_TYPE] if wk.PARENT_TYPE in d else None

        # Use for defining steps:
        self.path = d[wk.PATH]

        # Is needed to change its sensitivity:
        self.plan_button = None

        # Is preset widget for group:
        self.preset = None

        # Is needed to change its sensitivity:
        self.preview_button = None

        # Is true when the option group has not been
        # drawn by Plan and has changed:
        self.unseen = True

        # Is the container for the group.
        # The VBox has an 'per_cell_group' attribute
        # when the box's parent has a PerCellGroup.
        # The attribute refers to a PerCellGroup and is
        # used to access its cell table:
        self.vbox = d[wk.CONTAINER]

        # Need when translating steps to options:
        Hat.cat.group_dict[self.path] = self

    @staticmethod
    def draw_group(**d):
        """
        Draw an grid option group.

        d: dict
            Has keywords.

        Return: dict
            with Widgets
            of group
        """
        def subscribe(_g, _n):
            """
            Connect a widget to a signal.

            The Preset object is unique.

            _g: Widget
                to connect

            _n: string
                signal id
            """
            if isinstance(_g, Preset):
                _g.widget.subscribe(p, _n)
            else:
                _g.subscribe(p, _n)

        q = []
        widgets = {}
        k = d[wk.GROUP_KEY]
        group = d[wk.GROUP] = OptionGroup(**d)
        option = Hat.dog.option
        e = option.options
        has_preset = False

        for i in d[wk.KEYS]:
            widget = e[i][wk.WIDGET]
            d1 = option.collect_widget_arg(i)
            d1[wk.KEY] = i
            n = e[i][wk.COLUMN_TEXT] if wk.COLUMN_TEXT in e[i] else i

            d1.update(d)

            if widget in NO_LABEL:
                d1[wk.TEXT] = n
                n = ""

            n = n.split(",")[0]
            q1 = [n, widget, d1]
            q.append(q1)

        # ButtonPair comes before Button:
        if wk.HAS_GRID_PAIR in d:
            q += (["", ButtonPair, dict(
                d,
                key=wk.HAS_GRID_PAIR,
                text=(bk.PLAN, bk.PREVIEW)
            )],)

        elif wk.HAS_EFFECT_PAIR in d:
            q += (["", ButtonPair, dict(
                d,
                key=wk.HAS_EFFECT_PAIR,
                text=(bk.RANDOM, bk.PREVIEW)
            )],)

        elif wk.HAS_PREVIEW in d:
            q += (["", PreviewButton, d],)

        elif wk.HAS_RANDOM in d:
            q += (["", Button, dict(d, key=bk.RANDOM, text=bk.RANDOM)],)

        if wk.HAS_PRESET in d and d[wk.HAS_PRESET]:
            # Steps, Effect, and Custom Cell are a SuperPreset type:
            if d[wk.GROUP_TYPE] == Preset:
                label = k.split(",")[0]

            else:
                label = k.split(",")[1].strip()

            q += (
                [
                    "%s Preset:" % (label,),
                    d[wk.GROUP_TYPE],
                    dict(d, key=wk.PRESET)
                ],
            )
            has_preset = True

        if q:
            widgets = group.d = Table.create(**dict(d, q=q))
            group.keep = {k_: a for k_, a in widgets.items()}
            g = group.preset = widgets[wk.PRESET] if has_preset else None

            if wk.HAS_GRID_PAIR in widgets:
                group.plan_button = widgets[wk.HAS_GRID_PAIR].left_button

            if k in EXPOSE or k in PREVIEW:
                # Use to update widget visibility:
                vbow = d[wk.CONTAINER]
                vbow.group = group
                vbow.win = d[wk.WIN]
                p = do_opacity if k not in EXPOSE else EXPOSE[k]

                if g:
                    g.update_view = p

                vbow.expose_handle = vbow.connect('expose-event', p, vbow)

                # Connect the widgets to the group's visibility function:
                keys = d[wk.GROUP_TYPE].get_keys(k)
                for i in keys:
                    if i in widgets:
                        if hasattr(widgets[i], 'change_signal'):
                            subscribe(widgets[i], widgets[i].change_signal)

            if has_preset:
                if d[wk.GROUP_TYPE] != SuperPreset:
                    if d[wk.IS_DEFAULT]:
                        g.load(fp.DEFAULT, None)
            else:
                if d[wk.IS_DEFAULT]:
                    # Initialize non-preset group:
                    NonPreset.load(group.d, k)

        # Remove the button widgets:
        for i in widgets.keys():
            if widgets[i].key in NO_SAVE:
                widgets.pop(i)
        return widgets
