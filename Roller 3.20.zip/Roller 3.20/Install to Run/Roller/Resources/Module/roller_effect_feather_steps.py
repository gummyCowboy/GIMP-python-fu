#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Effect as ek, Option as ok
from roller_one_fu import Lay, Mage, Sel
import gimpfu as fu

pdb = fu.pdb
FEATHER = ek.FEATHER_STEPS


def process_layer(image_layer, o):
    """
    Feather the image material on a layer.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with feather
    """
    z = Lay.clone(image_layer)

    if pdb.gimp_item_is_group(z):
        z = Lay.merge_group(z)

    z.name = Lay.name(z.parent, FEATHER)

    Lay.hide(image_layer)
    Lay.show(z)
    FeatherSteps.feather(z, o.d)
    return z


class FeatherSteps:
    """Feather the edges of image material."""

    @staticmethod
    def do(o):
        """
        Do the Feather Reduction effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer
            with Feather Steps
        """
        z = o.image_layer

        # 'undo_z' is a list of layers for the preview's undo function:
        undo_z = []
        o.shadow_layer = [z]

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [process_layer(i.layers[0], o)]

        else:
            undo_z = process_layer(z, o)
            if undo_z:
                o.shadow_layer = [undo_z, z]
        return undo_z

    @staticmethod
    def feather(z, d):
        """
        Feather image material with linear growth repeating steps.

        z: layer
            Has image material to feather.
            Could possibly have a layer mask.

        d: dict
            Has feather options.
        """
        if z:
            j = z.image
            a = d[ok.FEATHER]
            f = float(a) / d[ok.STEPS]
            b = f

            Mage.expand_image(j, a)

            while a > b:
                Sel.make_layer_sel(z)
                pdb.gimp_selection_feather(j, b)

                if Sel.is_sel(j):
                    Sel.invert_clear(z)

                else:
                    break
                b = min(b + f, a)
            Mage.contract_image(j, a)

    @staticmethod
    def feather_layer_sel(z, d):
        """
        Feather material with linear growth
        repeating steps using an existing layer.

        z: layer
            Has material to feather.

        d: dict
            Has feather options.
        """
        if z:
            j = z.image
            a = d[ok.FEATHER]
            f = float(a) / d[ok.STEPS]
            b = f

            Mage.expand_image(j, a)

            while a > b:
                Sel.item(z)
                pdb.gimp_selection_feather(j, b)

                if Sel.is_sel(j):
                    Sel.invert_clear(z)

                else:
                    break
                b = min(b + f, a)
            Mage.contract_image(j, a)

    @staticmethod
    def feather_sel(j, d):
        """
        Feather a selection with linear growth
        repeating steps using an existing selection.

        j: GIMP image
            Has selection.

        d: dict
            Has feather options.
        """
        a = d[ok.FEATHER]
        f = float(a) / d[ok.STEPS]
        b = f
        if a:
            Mage.expand_image(j, a)

            while a > b:
                pdb.gimp_selection_feather(j, b)
                b = min(b + f, a)
            Mage.contract_image(j, a)
