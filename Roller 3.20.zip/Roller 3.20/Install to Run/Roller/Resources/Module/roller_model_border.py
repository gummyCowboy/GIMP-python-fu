#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Border as bo, Gradient as fg, Shape as sh
from roller_constant_fu import Fu
from roller_constant_key import Layer as nk, Option as ok
from roller_model_image import Image
from roller_one import Hat
from roller_one_extract import dispatch, Shape
from roller_one_fu import Lay, Mage, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
ELLIPSE = (
    sh.ELLIPSE_HORIZONTAL,
    sh.ELLIPSE_VERTICAL,
    sh.CIRCLE_HORIZONTAL,
    sh.CIRCLE_VERTICAL,
    sh.ELLIPSE
)


def add_border_layer(j, o, group):
    """
    Add a border layer to the bottom of the group.

    j: GIMP image
        Is render.

    o: One
        'layer_name': string

    group: layer
        parent of layer

    Return: layer
        for border material
    """
    return Lay.add(j, n=o.layer_name, parent=group)


def do_average_color(z, o):
    """
    Fill the selection with the average color of the background.

    z: layer
        to receive material

    o: One
        not used

    Return: layer
        with border material
    """
    j = z.image
    sel = pdb.gimp_selection_save(j)
    z1 = Lay.clone_background(z)

    Lay.color_fill(z, RenderHub.get_average_color(z1))
    Lay.remove(z1)
    Sel.isolate(z, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_backdrop(z, o):
    """
    Copy the background and use to fill selection.

    z: layer
        to receive material

    o: One
        not used

    Return: layer
        with border material
    """
    Lay.clone_background(z)

    z = Lay.merge(z)

    Sel.invert_clear(z, keep_sel=True)
    return z


def do_behind(z, d):
    """
    Blur behind border material and cast a shadow.

    z: layer
        with material

    d: dict
        Has the blur behind option.

    Return: layer
        with material
    """
    if d[ok.BLUR_BEHIND]:
        z1 = RenderHub.blur_behind(z, d, has_mode=True)

    else:
        z1 = RenderHub.do_mode(z, d)

    if z1:
        z = z1
    return cast_shadow(z, d)


def do_color(z, o):
    """
    Fill with the selection with a color.

    z: layer
        to receive material

    o: One
        Has variables.
            'e': dict
                border preset

    Return: layer
        with border material
    """
    Sel.fill(z, get_color(o))
    return z


def do_gradient(z, o):
    """
    Fill with the selection with a gradient.

    z: layer
        to receive material

    o: One
        'e': dict
            border dict

    Return: layer
        with border material
    """
    def draw_gradient():
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(gradient_type),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            start_x, start_y,
            end_x, end_y
        )

    j = z.image
    d = o.e
    sel = pdb.gimp_selection_save(j)
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    w, h = x1 - x, y1 - y
    gradient_type = d[ok.GRADIENT_TYPE]

    RenderHub.set_fill_context(fg.FILL_DICT)
    RenderHub.set_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        fu.GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(0)

    start_x, end_x, start_y, end_y =\
        RenderHub.get_gradient_points(
            d[ok.GRADIENT_ANGLE],
            x, y,
            w, h
        )

    Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
    draw_gradient()
    Sel.isolate(z, sel)
    Sel.invert_clear(z, keep_sel=True)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_image(z, o):
    """
    Fill with the selection with an overlaying image.

    z: layer
        to receive material

    o: One
        'e': dict of border

    Return: layer
        with border material
    """
    j = z.image
    d = o.e
    j1 = Image.get_image(d[ok.IMAGE], o.image_index)

    if j1:
        sel = pdb.gimp_selection_save(j)
        x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
        w, h = x1 - x, y1 - y
        j2 = j1.j

        pdb.gimp_selection_none(j)
        Mage.copy_all(j2)
        Image.close_image(j1)

        j2 = pdb.gimp_edit_paste_as_new_image()

        Mage.shape(j2, w, h)

        z1 = Lay.paste(z)

        pdb.gimp_layer_set_offsets(z1, x, y)
        Sel.isolate(z1, sel)
        pdb.gimp_image_remove_channel(j, sel)
        z = Lay.merge(z1)
    return z


def do_pattern(z, o):
    """
    Fill with the selection with a pattern.

    z: layer
        to receive material

    o: One
        Has variables.
            'e': dict
                border preset

    Return: layer
        with border material
    """
    j = z.image
    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    RenderHub.set_fill_context(fg.FILL_DICT)
    RenderHub.set_pattern(o.e)

    x, y = pdb.gimp_selection_bounds(j)[1:3]

    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, x, y)
    Sel.isolate(z, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_plasma(z, o):
    """
    Fill with the selection with plasma.

    z: layer
        to receive material

    o: One
        Has variables.
            'e': dict
                border preset

    Return: layer
        with border material
    """
    j = z.image
    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, o.e[ok.RANDOM_SEED], 3)
    Sel.isolate(z, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def cast_shadow(z, d):
    """
    Merge a shadow layer with the border if needed.

    z: layer
        with material

    d: dict
        of options

    Return: layer
        with border material
    """
    if Shadow.get_type(d[ok.TRI_SHADOW]):
        n = z.name
        z = Shadow.do_shadows(d[ok.TRI_SHADOW], z)
        z.name = n
    return z


def do_common_ellipse_grid(j, o):
    """
    Draw border for a square grid
    without merged cells or per cell.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = o.d
    row, column = o.grid.division
    w = d[ok.BORDER_WIDTH]
    w1 = w // 2
    z = grid_sel = None

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(o.grid, r, c):
                Sel.select_shape(j, o.grid.get_shape(r, c))
                Sel.grow(j, w1, 1)

                sel = pdb.gimp_selection_save(j)

                pdb.gimp_selection_shrink(j, w)

                sel1 = pdb.gimp_selection_save(j) if Sel.is_sel(j) else \
                    None

                # Make border selection by subtracting
                # the inner selection from the outer:
                Sel.load(j, sel)

                if sel1:
                    Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                if grid_sel:
                    Sel.load(j, grid_sel, option=fu.CHANNEL_OP_ADD)
                    pdb.gimp_image_remove_channel(j, grid_sel)

                grid_sel = pdb.gimp_selection_save(j)

                if sel:
                    pdb.gimp_image_remove_channel(j, sel)
                if sel1:
                    pdb.gimp_image_remove_channel(j, sel1)
    if grid_sel:
        Sel.load(j, grid_sel)

        z = do_ellipse_sel(j, o)
        pdb.gimp_image_remove_channel(j, grid_sel)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_common_rect_grid(j, o):
    """
    Do a common border for a rectangular cell grid.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = o.d
    row, column = o.grid.division
    rect = o.grid.get_merge_cell_rect(0, 0)
    left, top = rect.x, rect.y
    rect = o.grid.get_merge_cell_rect(row - 1, column - 1)
    right, bottom = rect.x + rect.w, rect.y + rect.h
    x = left
    h1 = d[ok.BORDER_WIDTH]
    h2 = h1 - h1 // 2
    w1 = right - left + h1

    for r in range(row):
        rect = o.grid.get_merge_cell_rect(r, 0)
        Sel.rect(j, x - h2, rect.y - h2, w1, h1)

    Sel.rect(j, x - h2, rect.y + rect.h - h2, w1, h1)

    w1, w2 = h1, h2
    h1 = bottom - top + w1
    y = top

    for c in range(column):
        rect = o.grid.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x - w2, y - w2, w1, h1)

    Sel.rect(j, rect.x + rect.w - w2, y - w2, w1, h1)

    z = process_selection(add_border_layer(j, o, o.parent), o)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_common_polygon_grid(j, o):
    """
    Do a common border for a polygon, not rectangular, cell grid.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    # Preserve:
    foreground = pdb.gimp_context_get_foreground()

    d = o.d
    row, column = o.grid.division
    z = None
    a = set()
    color = get_color(o)
    w = d[ok.BORDER_WIDTH]
    w1 = w // 2
    w2 = w - w1

    RenderHub.set_brush_details()
    pdb.gimp_context_set_brush_size(w)
    pdb.gimp_context_set_foreground(color)
    pdb.gimp_context_set_stroke_method(fu.STROKE_LINE)
    pdb.gimp_context_set_brush_spacing(.03)

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(o.grid, r, c):
                b = o.grid.get_shape(r, c)
                for x, i in enumerate(range(len(b) - 1)):
                    if not x % 2:
                        if x < len(b) - 3:
                            if b[x] < b[x + 2]:
                                a.add((b[x], b[x + 1], b[x + 2], b[x + 3]))
                            else:
                                a.add((b[x + 2], b[x + 3], b[x], b[x + 1]))
                        else:
                            a.add((b[x], b[x + 1], b[0], b[1]))
    for x, y, x1, y1 in a:
        if x != x1 and y != y1:
            if not z:
                z = add_border_layer(j, o, o.parent)
            pdb.gimp_paintbrush(
                z,
                .0,
                4,
                (x, y, x1, y1),
                fu.PAINT_CONSTANT,
                .0
            )
        else:
            if not z:
                z = add_border_layer(j, o, o.parent)

            # Use selection to skip smudgy antialiasing:
            Sel.polygon(
                j,
                (
                    x - w1, y - w1,
                    x + w2, y + w2,
                    x1 + w2, y1 + w2,
                    x1 - w1, y1 - w1
                ),
                option=fu.CHANNEL_OP_ADD
            )
            Sel.fill(z, get_color(o))
            pdb.gimp_selection_none(j)

    if z:
        Sel.item(z)
        z = process_selection(z, o, is_fill=False)

    # Restore:
    pdb.gimp_context_set_foreground(foreground)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_common_square_grid(j, o):
    """
    Do a common border for a square cell grid.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    row, column = o.grid.division
    d = o.d
    w = d[ok.BORDER_WIDTH]
    rect = o.grid.get_merge_cell_rect(0, 0)
    w1 = rect.w * column + w
    h1 = rect.h * row + w
    w2 = w - w // 2

    for r in range(row):
        rect = o.grid.get_merge_cell_rect(r, 0)
        Sel.rect(j, rect.x - w2, rect.y - w2, w1, w)

    Sel.rect(j, rect.x - w2, rect.y + rect.h - w2, w1, w)

    for c in range(column):
        rect = o.grid.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x - w2, rect.y - w2, w, h1)

    Sel.rect(j, rect.x + rect.w - w2, rect.y - w2, w, h1)

    z = process_selection(add_border_layer(j, o, o.parent), o)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_ellipse_sel(j, o):
    """
    Increase the opacity of the ellipse.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer
        Has border material.
    """
    d = o.d
    group = make_group(j, o)
    f = d[ok.OPACITY]
    d[ok.OPACITY] = 100.
    z = add_border_layer(j, o, group)

    Sel.fill(z, get_color(o))

    d[ok.OPACITY] = f

    for i in range(3):
        Lay.clone(z)

    z = Lay.merge_group(group)

    Sel.item(z)
    return process_selection(z, o)


def do_rect_custom_cell(j, o):
    """
    Draw a rectangle border for a custom cell border.

    j: GIMP image
        Is render.

    o: One
        Has custom cell variables.
    """
    a = o.grid.rect
    x, y = a.position
    w, h = a.size
    d = o.d
    w1 = d[ok.BORDER_WIDTH]
    w2 = w1 + w1
    Sel.rect(j, x, y, w, h)
    Sel.rect(
        j,
        x + w1,
        y + w1,
        max(w - w2, 1),
        max(h - w2, 1),
        option=fu.CHANNEL_OP_SUBTRACT
    )
    z = process_selection(add_border_layer(j, o, o.group), o)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_rect_grid(j, o):
    """
    Draw border for a rectangle grid without merged cells.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = o.d
    row, column = o.grid.division
    rect = o.grid.get_merge_cell_rect(0, 0)
    left, top = rect.x, rect.y
    rect = o.grid.get_merge_cell_rect(row - 1, column - 1)
    right, bottom = rect.x + rect.w, rect.y + rect.h
    w1 = right - left
    x = left
    h1 = d[ok.BORDER_WIDTH]

    for r in range(row):
        rect = o.grid.get_merge_cell_rect(r, 0)
        Sel.rect(j, x, rect.y, w1, h1)
        Sel.rect(j, x, max(rect.y + rect.h - h1, rect.y), w1, h1)

    w1 = h1
    h1 = bottom - top
    y = top

    for c in range(column):
        rect = o.grid.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x, y, w1, h1)
        Sel.rect(j, max(rect.x + rect.w - w1, rect.x), y, w1, h1)
    z = process_selection(add_border_layer(j, o, o.parent), o)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_rect_per_cell(j, o):
    """
    Draw border for a rectangle grid with
    merged cells and / or per cell.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = o.d
    row, column = o.grid.division
    z = group = None
    is_per_cell = o.is_per_cell

    for r in range(row):
        for c in range(column):
            go = True
            w = 0

            if o.is_merge_cell:
                if o.grid.d[ok.PER_CELL][r][c] == (-1, -1):
                    go = False
            if go:
                if is_per_cell:
                    e = o.e = d[ok.PER_CELL][r][c]
                    w = e[ok.BORDER_WIDTH]
                    go = e[ok.BORDER_WIDTH] and e[ok.OPACITY] and \
                        e[ok.BORDER_TYPE] != "None"
                else:
                    e = d
                    w = d[ok.BORDER_WIDTH]
            if go and w:
                w1 = w + w
                rect = o.grid.get_merge_cell_rect(r, c)

                Sel.rect(j, rect.x, rect.y, rect.w, rect.h)
                Sel.rect(
                    j,
                    rect.x + w, rect.y + w,
                    max(rect.w - w1, 1), max(rect.h - w1, 1),
                    option=fu.CHANNEL_OP_SUBTRACT
                )
                if Sel.is_sel(j):
                    if is_per_cell:
                        if not group:
                            group = make_group(j, o)
                        z = process_selection(
                            add_border_layer(j, o, group),
                            o
                        )
                        if not o.is_plan:
                            z = do_behind(z, e)

    if not is_per_cell:
        z = process_selection(add_border_layer(j, o, o.parent), o)
        z = do_behind(z, d)
    if group:
        z = Lay.merge_group(group)
    return z


def do_shape_custom_cell(j, o, n):
    """
    Draw a non-rectangle shaped custom cell border.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    n: string
        shape descriptor

    Return: layer or None
        with border material
    """
    z = None
    a = o.grid.rect
    d = o.d

    Sel.select_shape(j, dispatch[n](a))

    if Sel.is_sel(j):
        sel = pdb.gimp_selection_save(j)

        pdb.gimp_selection_shrink(j, d[ok.BORDER_WIDTH])

        if Sel.is_sel(j):
            sel1 = pdb.gimp_selection_save(j)

        else:
            sel1 = None

        Sel.load(j, sel)
        Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

        if not Sel.is_sel(j):
            Sel.load(j, sel)

        if n in ELLIPSE:
            z = do_ellipse_sel(j, o)
        else:
            z = process_selection(add_border_layer(j, o, o.group), o)

        if not o.is_plan:
            z = do_behind(z, d)

        pdb.gimp_image_remove_channel(j, sel)
        if sel1:
            pdb.gimp_image_remove_channel(j, sel1)
    return z


def do_shape_grid(j, o, n):
    """
    Draw border for a square grid
    without merged cells or per cell.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    n: string
        shape descriptor

    Return: layer or None
        Has border material.
    """
    d = o.d
    row, column = o.grid.division
    w = d[ok.BORDER_WIDTH]
    z = grid_sel = None

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(o.grid, r, c):
                Sel.select_shape(j, o.grid.get_shape(r, c))

                sel = pdb.gimp_selection_save(j)

                pdb.gimp_selection_shrink(j, w)

                if Sel.is_sel(j):
                    sel1 = pdb.gimp_selection_save(j)

                else:
                    sel1 = None

                # Make border selection by subtracting
                # the inner selection from the outer:
                Sel.load(j, sel)
                Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                if grid_sel:
                    Sel.load(j, grid_sel, option=fu.CHANNEL_OP_ADD)
                    pdb.gimp_image_remove_channel(j, grid_sel)

                grid_sel = pdb.gimp_selection_save(j)

                pdb.gimp_image_remove_channel(j, sel)
                if sel1:
                    pdb.gimp_image_remove_channel(j, sel1)
    if grid_sel:
        Sel.load(j, grid_sel)
        pdb.gimp_image_remove_channel(j, grid_sel)

        if n in ELLIPSE:
            z = do_ellipse_sel(j, o)
        else:
            z = process_selection(
                add_border_layer(j, o, o.parent),
                o
            )

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def do_shape_per_cell(j, o):
    """
    Draw border for a square grid
    without merged cells or per cell.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = o.d
    z = group = None
    row, column = o.grid.division
    n = o.grid.cell_shape

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(o.grid, r, c):
                e = o.e = d[ok.PER_CELL][r][c]
                w = e[ok.BORDER_WIDTH]
                if w and e[ok.OPACITY] and e[ok.BACKDROP_TYPE] != "None":
                    Sel.select_shape(
                        j,
                        o.grid.get_shape(r, c)
                    )

                    if Sel.is_sel(j):
                        sel = pdb.gimp_selection_save(j)
                        pdb.gimp_selection_shrink(j, w)

                    else:
                        sel = None

                    sel1 = pdb.gimp_selection_save(j) if Sel.is_sel(j) \
                        else None

                    # Make border selection by subtracting
                    # the inner selection from the outer:
                    if sel:
                        Sel.load(j, sel)
                        Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                    if not Sel.is_sel(j):
                        Sel.load(j, sel)

                    if not group:
                        group = make_group(j, o)

                    if n in ELLIPSE:
                        z = do_ellipse_sel(j, o)
                        pdb.gimp_image_reorder_item(j, z, group, 0)
                        if not o.is_plan:
                            z = do_behind(z, e)

                    else:
                        if Sel.is_sel(j):
                            z = process_selection(
                                add_border_layer(j, o, group),
                                o
                            )
                            if not o.is_plan:
                                z = do_behind(z, e)

                    if sel:
                        pdb.gimp_image_remove_channel(j, sel)
                    if sel1:
                        pdb.gimp_image_remove_channel(j, sel1)

    if group:
        z = Lay.merge_group(group)
    return z


def do_square_grid(j, o):
    """
    Draw border for a square grid
    without merged cells or per cell.

    j: GIMP image
        Is render.

    o: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = o.d
    row, column = o.grid.division
    w = d[ok.BORDER_WIDTH]
    rect = o.grid.get_merge_cell_rect(0, 0)
    w1 = rect.w * column
    h1 = rect.h * row

    for r in range(row):
        rect = o.grid.get_merge_cell_rect(r, 0)
        Sel.rect(j, rect.x, rect.y, w1, w)
        Sel.rect(j, rect.x, max(rect.y + rect.h - w, rect.y), w1, w)

    for c in range(column):
        rect = o.grid.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x, rect.y, w, h1)
        Sel.rect(j, max(rect.x + rect.w - w, rect.x), rect.y, w, h1)

    z = process_selection(add_border_layer(j, o, o.parent), o)

    if not o.is_plan:
        z = do_behind(z, d)
    return z


def get_color(o):
    """
    Get the color for the border material.

    d: dict
        of border

    Return: tuple
        RGB
    """
    if o.is_plan:
        return o.color
    return o.d[ok.COLOR]


def make_group(j, o):
    """
    Make a group layer for cell border layers.

    j: GIMP image
        work-in-progress

    o: One
        Has layer name and parent.

    Return: layer
        of group type
    """
    return Lay.group(j, o.layer_name, parent=o.parent)


def process_selection(z, o, is_fill=True):
    """
    The selection is the border. Fill,
    blur, and emboss complete the process.

    z: layer
        for border material

    o: One
        Has variables.

    is_fill: flag
        When true, the layer selection is filled with the border color.

    Return: layer or None
        with border
    """
    j = z.image
    d = o.e

    if Sel.is_sel(j):
        if is_fill:
            if o.is_plan:
                z = do_color(z, o)
            else:
                z = BORDER_FILL[d[ok.BORDER_TYPE]](z, o)

        pdb.gimp_selection_none(j)

        if d[ok.BORDER_BLUR]:
            Lay.blur(z, d[ok.BORDER_BLUR])

        z = RenderHub.bump(z, d[ok.BUMP])
        z.opacity = d[ok.OPACITY]
        pdb.gimp_selection_none(j)
    return z


class Border:
    """Manage Border operation."""

    @staticmethod
    def do_custom_cell(o, is_plan):
        """
        Do border for free range cells.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: tuple or None
            with border
        """
        cat = Hat.cat
        z = group = None
        d = o.e = o.d
        o.is_plan = is_plan
        o.layer_name = Lay.name(o.parent, nk.CELL_BORDER)

        if (
            d[ok.BORDER_WIDTH] and
            d[ok.OPACITY] and
            d[ok.BORDER_TYPE] != "None"
        ):
            j = cat.render.image
            n = o.grid.cell_shape

            if n == sh.RECTANGLE:
                group = o.group = make_group(j, o)
                do_rect_custom_cell(j, o)
            else:
                o.group = o.parent
                z = do_shape_custom_cell(j, o, n)

            if group:
                z = Lay.merge_group(group)
            if not is_plan:
                z = GradientLight.apply_light(z, ok.BORDER_INFLUENCE)
        return z

    @staticmethod
    def do_grid(o, is_plan):
        """
        Do border for grid cells.

        j: GIMP image
            Is render.

        o: One
            Has variables.

        is_plan: bool
            Is true when the caller is the Plan class.

        Return: tuple or None
            Has border material.
        """
        cat = Hat.cat
        j = cat.render.image
        z = None
        d = o.e = o.d
        n = o.grid.cell_shape
        o.is_merge_cell = o.grid.is_merge_cell
        o.is_plan = is_plan
        is_per_cell = o.is_per_cell = d[ok.PER_CELL]
        is_one_border = not any((o.is_merge_cell, is_per_cell))
        o.layer_name = Lay.name(o.parent, nk.CELL_BORDER)
        go = True

        if not is_per_cell:
            go = d[ok.BORDER_WIDTH] and d[ok.OPACITY] and \
                d[ok.BORDER_TYPE] != "None"

        if go:
            pdb.gimp_selection_none(j)

            if n == sh.RECTANGLE:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_rect_grid(j, o)
                    else:
                        z = do_rect_grid(j, o)
                else:
                    z = do_rect_per_cell(j, o)

            elif n == sh.SQUARE:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_square_grid(j, o)
                    else:
                        z = do_square_grid(j, o)
                else:
                    z = do_rect_per_cell(j, o)

            elif n in ELLIPSE:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_ellipse_grid(j, o)
                    else:
                        z = do_shape_grid(j, o, n)
                else:
                    z = do_shape_per_cell(j, o)
            else:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_polygon_grid(j, o)
                    else:
                        z = do_shape_grid(j, o, n)
                else:
                    z = do_shape_per_cell(j, o)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.BORDER_INFLUENCE)
        return z

    @staticmethod
    def do_layer(o, is_plan):
        """
        Do a border for a Table layer.

        o: One
            Has init variables

        Return: tuple or None
            Has border material.
        """
        cat = Hat.cat
        j = cat.render.image
        d = o.e = o.d
        z = None
        w, h = cat.render.size
        o.is_plan = is_plan
        w1 = d[ok.BORDER_WIDTH]

        if w1 and d[ok.OPACITY] and d[ok.BORDER_TYPE] != "None":
            w2 = w1 * 2
            w3 = w1 // 2
            w4 = w1 - w3

            pdb.gimp_selection_none(j)

            if d[ok.OBEY_MARGINS]:
                top, bottom, left, right = o.grid.layer_margin
                width = w - left - right + w1
                height = h - top - bottom + w1
                Sel.rect(j, left - w3, top - w3, width, height)
                Sel.rect(
                    j,
                    left + w4, top + w4,
                    width - w2, height - w2,
                    option=fu.CHANNEL_OP_SUBTRACT
                )

            else:
                Sel.rect(j, 0, 0, w, h)
                Sel.rect(
                    j,
                    w1, w1,
                    w - w2, h - w2,
                    option=fu.CHANNEL_OP_SUBTRACT
                )

            o.layer_name = Lay.name(o.parent, nk.LAYER_BORDER)
            z = add_border_layer(j, o, o.parent)
            z = process_selection(z, o)
            if not is_plan:
                z = do_behind(z, d)
                z = GradientLight.apply_light(z, ok.BORDER_INFLUENCE)
        return z


BORDER_FILL = {
    bo.AVERAGE_COLOR: do_average_color,
    bo.BACKDROP: do_backdrop,
    bo.COLOR: do_color,
    bo.GRADIENT: do_gradient,
    bo.IMAGE: do_image,
    bo.PATTERN: do_pattern,
    bo.PLASMA: do_plasma
}
