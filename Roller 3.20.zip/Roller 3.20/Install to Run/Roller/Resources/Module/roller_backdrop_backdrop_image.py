#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_model_image import Image
from roller_one import Hat
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
sc = Fu.LayerScale
LOHALO = fu.INTERPOLATION_LOHALO
NOHALO = fu.INTERPOLATION_NOHALO


class BackdropImage:
    """Place an image on the backdrop layer."""

    @staticmethod
    def do(o, is_plan=False):
        """
        Do the Backdrop Image backdrop-style.

        o: One
            Has variables.

        is_plan: bool
            Is true when Plan is calling.
            Use to update image index.

        Return: layer or None
            Is backdrop.
        """
        d = o.d
        cat = Hat.cat
        j = cat.render.image
        w, h = size = cat.render.size
        z = None

        # Copy the backdrop image to the backdrop layer:
        j1 = Image.get_image(d[ok.IMAGE], o.image_index)

        if not is_plan:
            z = Lay.add(j, "", offset=Hat.dog.plan.get_offset())

        if j1 and not is_plan:
            j2 = j1.j

            if j1.size != size and d[ok.FIT_IMAGE]:
                j3 = pdb.gimp_image_new(j2.width, j2.height, fu.RGB)
                z1 = pdb.gimp_layer_new_from_visible(j2, j3, "")

                j3.add_layer(z1, 0)

                # Resize the backdrop image to fit the backdrop layer:
                a = LOHALO if w * h <= j3.width * j3.height else NOHALO

                pdb.gimp_context_set_interpolation(a)
                pdb.gimp_layer_scale(z1, w, h, sc.IMAGE_ORIGIN)
                pdb.gimp_image_resize_to_layers(j3)

                z1 = pdb.gimp_layer_new_from_visible(j3, j, "")
                pdb.gimp_image_delete(j3)

            else:
                z1 = pdb.gimp_layer_new_from_visible(j2, j, "")

            pdb.gimp_image_insert_layer(j, z1, z.parent, Lay.offset(z))

            if z1.width != w or z1.height != h:
                pdb.gimp_layer_set_offsets(
                    z1,
                    (w - z1.width) // 2, (h - z1.height) // 2
                )

            if not d[ok.FIT_IMAGE]:
                pdb.gimp_layer_resize_to_image_size(z1)

            z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
            if Lay.has_pixel(z):
                if d[ok.BACKDROP_IMAGE_BLUR]:
                    Lay.blur(z, d[ok.BACKDROP_IMAGE_BLUR])

                if d[ok.INVERT]:
                    pdb.gimp_drawable_invert(z, 0)
                z = RenderHub.bump(z, d[ok.BUMP])

        if j1:
            Image.close_image(j1)
        return z
