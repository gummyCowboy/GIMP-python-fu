#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import Comm, Hat
import gimpfu as fu

pdb = fu.pdb


class RenderImage(object):
    """
    Use to create and change the render image.
    Use to manage the layout group.
    Use to manage the backdrop layer.
    """

    def __init__(self):
        """Init for a new render image."""
        self._image = self.has_image = self._display = None
        self._size = 50, 50

    @property
    def image(self):
        """
        Get the render image. If it doesn't exist, then create one first.

        Return: GIMP image
            for render
        """
        if self._image:
            if (self._image.width, self._image.height) == self._size:
                return self._image

        if self._image:
            pdb.gimp_display_delete(self._display)
            Hat.cat.reset_dict()
            Hat.dog.plan.reset()
            Hat.dog.product.reset()

        j = self._image = pdb.gimp_image_new(
            self._size[0],
            self._size[1],
            fu.RGB
        )

        # Show in GIMP:
        self._display = pdb.gimp_display_new(j)

        # Turn off undo functionality to save
        # memory and to improve performance:
        pdb.gimp_image_undo_disable(j)

        self.has_image = True
        return j

    @image.setter
    def image(self, *_):
        """The image property is read-only."""
        raise RenderImage.WriteError('image')

    @property
    def size(self):
        """Return the size of the render."""
        return self._size

    @size.setter
    def size(self, s):
        """
        Call to set the render image size.

        If the image size has changed, the image is scaled.

        s: tuple
            of int
            width, height
            render dimensions
        """
        self._size = s

    class WriteError(Exception):
        """
        Use when a function attempts to write to a read-only property.
        """
        def __init__(self, n):
            """
            There was an write error.

            Spit out the variable name.

            n: string
                function name
            """
            self.value = "StatWriteError: Attempted to write to a read-only " \
                "property: RenderImage.{}.".format(n)
            Comm.info_msg(self.value)

        def __str__(self):
            """
            Return the string value of the error message.

            This an Exception template function.
            """
            return repr(self.value)
