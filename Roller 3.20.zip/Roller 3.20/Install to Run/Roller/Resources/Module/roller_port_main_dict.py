#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import (
    BackdropStyle as by,
    Effect as ek,
    Group as gk,
    Widget as wk
)
from roller_option_preset import (
    BEHIND_TYPE,
    NonPreset,
    PerCell,
    Preset,
    SuperPreset
)
from roller_widget_tree import Node


class MainDict:
    """Is extracted data from PortMain and PortNode."""

    def __init__(self):
        """Initialize dictionaries used to make the navigation nodes."""
        # for groups without a Per Cell option:
        grid_type = {
            wk.WIDGET: Preset,
            wk.HAS_GRID_PAIR: True,
            wk.HAS_PRESET: True
        }

        # for groups with a Per Cell option:
        per_cell_type = {wk.WIDGET: PerCell, wk.HAS_PRESET: True}

        # Use with backdrop-styles and image-effect groups:
        render_effect = {
            wk.HAS_PRESET: True,
            wk.HAS_EFFECT_PAIR: True,
            wk.WIDGET: Preset
        }

        # Use with the Tri-Shadow group in its satellite window:
        shadow_effect = {
            wk.HAS_PRESET: True,
            wk.HAS_RANDOM: True,
            wk.WIDGET: Preset
        }

        # for groups with only a Preset:
        super_preset = {wk.WIDGET: SuperPreset, wk.HAS_PRESET: True}

        # Is used to make the navigation option group by
        # forming a tree. Some references will lead to Nodes
        # while other references are terminal OptionGroups
        # with dictionaries defined in the Preset module:
        self.group_def = {
            by.BACKDROP_IMAGE: render_effect,
            ek.SHADOW_2: shadow_effect,
            ek.INNER_SHADOW: shadow_effect,
            ek.SHADOW_1: shadow_effect,
            gk.BACKDROP: {
                wk.LABELS: (by.BACKDROP_IMAGE, gk.BACKDROP_STYLE),
                wk.WIDGET: Node
            },
            gk.BACKDROP_STYLE: {wk.WIDGET: NonPreset, wk.HAS_RANDOM: True},
            gk.BLUR_BEHIND: {
                wk.LABELS: (gk.IMAGE_BEHIND, gk.CAPTION_BEHIND),
                wk.WIDGET: Node
            },
            gk.CAPTION_BEHIND: BEHIND_TYPE,
            gk.CUSTOM_CELL_CAPTION: grid_type,
            gk.CUSTOM_CELL_BORDER: grid_type,
            gk.CUSTOM_CELL_CELL: {
                wk.LABELS: (
                    gk.RECTANGLE,
                    gk.CUSTOM_CELL_MARGIN,
                    gk.CUSTOM_CELL_PLAQUE,
                    gk.CUSTOM_CELL_FRINGE,
                    gk.CUSTOM_CELL_BORDER
                ),
                wk.PARENT_TYPE: gk.CUSTOM_CELL_CELL,
                wk.WIDGET: Node
            },
            gk.CUSTOM_CELL_FRINGE: grid_type,
            gk.CUSTOM_CELL_IMAGE: {
                wk.LABELS: (
                    gk.CUSTOM_CELL_IMAGE_PLACE,
                    gk.CUSTOM_CELL_IMAGE_MASK,
                    gk.CUSTOM_CELL_CAPTION
                ),
                wk.PARENT_TYPE: gk.CUSTOM_CELL_CELL,
                wk.WIDGET: Node
            },
            gk.CUSTOM_CELL_IMAGE_MASK: grid_type,
            gk.CUSTOM_CELL_IMAGE_PLACE: grid_type,
            gk.CUSTOM_CELL_MARGIN: grid_type,
            gk.CUSTOM_CELL_MODEL: {
                wk.LABELS: (
                    gk.CUSTOM_CELL_PROPERTY,
                    gk.CUSTOM_CELL_CELL,
                    gk.CUSTOM_CELL_IMAGE,
                    gk.PRESET_CUSTOM_CELL,
                    gk.IMAGE_EFFECT,
                    gk.BLUR_BEHIND
                ),
                wk.WIDGET: Node
            },
            gk.CUSTOM_CELL_PLAQUE: grid_type,
            gk.CUSTOM_CELL_PROPERTY: {wk.WIDGET: NonPreset},
            gk.EFFECT: {
                wk.LABELS: (gk.MODEL,),
                wk.WIDGET: Node
            },
            gk.GRID_CELL: {
                wk.LABELS: (
                    gk.PER_CELL_GRID,
                    gk.PER_CELL_MARGIN,
                    gk.PER_CELL_PLAQUE,
                    gk.PER_CELL_FRINGE,
                    gk.PER_CELL_BORDER
                ),
                wk.PARENT_TYPE: gk.GRID_CELL,
                wk.WIDGET: Node
            },
            gk.GRID_IMAGE: {
                wk.LABELS: (
                    gk.PER_CELL_IMAGE_PLACE,
                    gk.PER_CELL_IMAGE_MASK,
                    gk.PER_CELL_CAPTION
                ),
                wk.PARENT_TYPE: gk.GRID_CELL,
                wk.WIDGET: Node
            },
            gk.GRID_LAYER: {
                wk.LABELS: (
                    gk.LAYER_MARGIN,
                    gk.LAYER_PLAQUE,
                    gk.LAYER_FRINGE,
                    gk.LAYER_BORDER,
                    gk.LAYER_CAPTION
                ),
                wk.PARENT_TYPE: gk.GRID_LAYER,
                wk.WIDGET: Node
            },
            gk.GLOBAL: {wk.WIDGET: NonPreset, wk.HAS_RANDOM: True},
            gk.GRADIENT_LIGHT: render_effect,
            gk.IMAGE_BEHIND: BEHIND_TYPE,
            gk.IMAGE_EFFECT: {wk.WIDGET: NonPreset, wk.HAS_RANDOM: True},
            gk.LAYER_BORDER: grid_type,
            gk.LAYER_CAPTION: grid_type,
            gk.LAYER_FRINGE: grid_type,
            gk.LAYER_MARGIN: grid_type,
            gk.LAYER_PLAQUE: grid_type,
            gk.MODEL: {wk.HAS_GRID_PAIR: True, wk.WIDGET: NonPreset},
            gk.PER_CELL_BORDER: per_cell_type,
            gk.PER_CELL_CAPTION: per_cell_type,
            gk.PER_CELL_FRINGE: per_cell_type,
            gk.PER_CELL_GRID: per_cell_type,
            gk.PER_CELL_IMAGE_PLACE: per_cell_type,
            gk.PER_CELL_IMAGE_MASK: per_cell_type,
            gk.PER_CELL_PLAQUE: per_cell_type,
            gk.PER_CELL_MARGIN: per_cell_type,
            gk.STACK_PILE: grid_type,
            gk.PRESET_CUSTOM_CELL: super_preset,
            gk.PRESET_STACK: super_preset,
            gk.PRESET_TABLE: super_preset,
            gk.PRESET_STEPS: super_preset,
            gk.PRESET_TRI_SHADOW: {
                wk.WIDGET: SuperPreset,
                wk.HAS_PRESET: True
            },
            gk.RECTANGLE: grid_type,
            gk.SHADOW_TYPE: {wk.WIDGET: NonPreset},
            gk.STACK_CELL: {
                wk.LABELS: (
                    gk.STACK_PILE,
                    gk.RECTANGLE,
                    gk.STACK_CELL_MARGIN,
                    gk.CUSTOM_CELL_PLAQUE,
                    gk.CUSTOM_CELL_FRINGE,
                    gk.CUSTOM_CELL_BORDER
                ),
                wk.PARENT_TYPE: gk.STACK_CELL,
                wk.WIDGET: Node
            },
            gk.STACK_CELL_MARGIN: grid_type,
            gk.STACK_IMAGE: {
                wk.LABELS: (
                    gk.PER_CELL_IMAGE_PLACE,
                    gk.PER_CELL_IMAGE_MASK,
                    gk.CUSTOM_CELL_CAPTION
                ),
                wk.PARENT_TYPE: gk.STACK_CELL,
                wk.WIDGET: Node
            },
            gk.STACK_MODEL: {
                wk.LABELS: (
                    gk.STACK_PROPERTY,
                    gk.STACK_CELL,
                    gk.STACK_IMAGE,
                    gk.PRESET_STACK,
                    gk.IMAGE_EFFECT,
                    gk.BLUR_BEHIND
                ),
                wk.WIDGET: Node
            },
            gk.STACK_PROPERTY: {wk.WIDGET: NonPreset},
            gk.STEPS: {
                wk.LABELS: (
                    gk.GLOBAL,
                    gk.BACKDROP,
                    gk.GRADIENT_LIGHT,
                    gk.EFFECT,
                    gk.PRESET_STEPS
                ),
                wk.WIDGET: Node
            },
            gk.TABLE_MODEL: {
                wk.LABELS: (
                    gk.TABLE_PROPERTY,
                    gk.GRID_LAYER,
                    gk.GRID_CELL,
                    gk.GRID_IMAGE,
                    gk.PRESET_TABLE,
                    gk.IMAGE_EFFECT,
                    gk.BLUR_BEHIND
                ),
                wk.WIDGET: Node
            },
            gk.TABLE_PROPERTY: {wk.WIDGET: NonPreset},
            gk.TRI_SHADOW: {
                wk.LABELS: (
                    gk.SHADOW_TYPE,
                    ek.SHADOW_1,
                    ek.SHADOW_2,
                    ek.INNER_SHADOW,
                    gk.PRESET_TRI_SHADOW
                ),
                wk.WIDGET: Node
            }
        }
