#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, uniform
from roller_constant_for import Justification as ju, Resize as fz, Stack as st
from roller_constant_fu import Fu
from roller_constant_key import Image as ik, Layer as nk, Option as ok
from roller_model_image import Image
from roller_one import Hat, One, Rect
from roller_one_extract import dispatch, Form, Path, Shape
from roller_one_fu import Lay, Mage, Sel
from roller_one_tip import Tip
from roller_render_gradient_light import GradientLight
import gimpfu as fu

pdb = fu.pdb
ro = Fu.Rotate


def apply_shape_mask(z, shape):
    """
    Create a cell-based shape selection and clear outside of it.

    z: layer
        with image

    shape: tuple or dict
        Has polygon shape data.
    """
    Sel.select_shape(z.image, shape)
    Sel.invert_clear(z)


def calc_shift_position(o, x, y):
    """
    Calculate the shift position for an image.

    o: One
        Has the shift preset in 'e'.

    x, y: int
        topleft corner of pocket

    Return: tuple
        (x, y, is shifted)
        int
            x, y
            shift modified
        bool
            Is true if there was a shift in the position.
    """
    d = o.e[ok.SHIFT]

    # position:
    x1 = d[ok.OFFSET_X]
    y1 = d[ok.OFFSET_Y]
    x1 += randint(-d[ok.SHIFT_X], d[ok.SHIFT_X])
    y1 += randint(-d[ok.SHIFT_Y], d[ok.SHIFT_Y])

    if o.grid.add_shift_x:
        x1 = o.shift.x = x1 + o.shift.x

    if o.grid.add_shift_y:
        y1 = o.shift.y = y1 + o.shift.y
    return x + x1, y + y1, bool(y1 or x1)


def calc_shift_rotation(o):
    """
    Calculate the rotation angle for an image assigned to a cell.
    Store the rotation in 'grid.table', the model's cell table.

    o: One
        e: dict
            of image place, a preset

        grid: Grid
            Has 'set_rotation' method.

        r, c: int
            cell index

    rotate: float
        Is added to the rotation angle.

    return: float
        rotation angle
    """
    # 'f', rotation angle:
    d = o.e[ok.SHIFT]
    f = d[ok.ROTATE]
    f += uniform(-d[ok.ROTATE_JITTER], d[ok.ROTATE_JITTER])

    if o.grid.add_shift_rotate:
        f = o.shift.rotate = f + o.shift.rotate

    o.grid.set_rotation(o.r, o.c, f)
    return f


def calc_shift_size(o, w, h):
    """
    Calculate the shift for an image.

    o: One
        e: dict
            of image place

    w, h: int
        dimension of pocket

    Return: tuple
        w, h
        shift size modified
    """
    d = o.e[ok.SHIFT]

    # size:
    w1 = d[ok.WIDTH_MOD]
    h1 = d[ok.HEIGHT_MOD]
    w1 += randint(-d[ok.SHIFT_WIDTH], d[ok.SHIFT_WIDTH])
    h1 += randint(-d[ok.SHIFT_HEIGHT], d[ok.SHIFT_HEIGHT])

    if o.grid.add_shift_w:
        w1 = o.shift.w = w1 + o.add_shift.w

    if o.grid.add_shift_h:
        h1 = o.shift.h = h1 + o.add_shift.h
    return max(1, w + w1), max(1, h + h1)


def calc_z_height(d, r, is_grid):
    """
    Calculate the z-height amount and store the value for a cell.

    d: dict
        of shift, a preset

    r: int
        cell row

    is_grid: bool
        Is true when the Grid class is calling.
        The OFFSET_Z option is invalid for the other models.

    Return: int
        z-height
    """
    a = 0 if is_grid else r
    a += randint(0, d[ok.SHIFT_Z])
    if is_grid:
        a += d[ok.OFFSET_Z]
    return a


def get_trim_size(s, t):
    """
    Calculate the size of a trim.

    s: tuple
        (w, h)
        of int
        image size

    t: tuple
        (w, h)
        of int
        cell size

    Return: list
        size with trim
    """
    # ratios:
    w_r = t[0] / 1. / s[0]
    h_r = t[1] / 1. / s[1]

    if s[0] < t[0] and s[1] < t[1]:
        # No trim needed:
        w, h = s

    else:
        if w_r < h_r:
            # The image height is closer to the cell size:
            f = h_r

        else:
            # The image width is closer to the cell size:
            f = w_r

        w, h = int(s[0] * f), int(s[1] * f)
        w = min(w, s[0])
        h = min(h, s[1])

    # underflow:
    return [max(w, 1), max(h, 1)]


def mold_cover(j, d):
    """
    Resize an image using the cover resize-type.

    Return with the image data in the buffer.

    j: Image
        Has cell info.

    d: dict
        of image place, form

    Return: buffer data
        of the image
    """
    s = j.size
    t = j.pocket.size

    # width and height ratios:
    w_r = t[0] / 1. / s[0]
    h_r = t[1] / 1. / s[1]

    if w_r < h_r:
        # The image height is closer to the cell size:
        f = h_r

    else:
        # The image width is closer to the cell size:
        f = w_r

    Mage.copy_all(j.j)

    j1 = pdb.gimp_edit_paste_as_new_image()

    Mage.shape(j1, int(s[0] * f), int(s[1] * f))

    j1 = pdb.gimp_edit_paste_as_new_image()
    s1 = select_image_trim(d, j, j1)

    # Copy visible selection:
    pdb.gimp_edit_copy_visible(j1)

    pdb.gimp_image_delete(j1)

    j.mold.size = s1
    return True


def mold_crop(j, d):
    """
    Get image material through a crop.

    j: Image
        Has cell info.
        Has material.
        work-in-progress

    d: dict
        of image place, form

    Return: bool
        Is true if there is material in the buffer.
        buffer data
            of the image
    """
    j1 = None
    is_copy = True
    e = d[ok.RESIZE_METHOD]

    Sel.rect(
        j.j,
        e[ok.CROP_X], e[ok.CROP_Y],
        e[ok.CROP_W], e[ok.CROP_H],
        option=fu.CHANNEL_OP_REPLACE
    )

    if Sel.is_sel(j.j):
        # Copy selection:
        pdb.gimp_edit_copy_visible(j.j)
        pdb.gimp_selection_none(j.j)
        j1 = pdb.gimp_edit_paste_as_new_image()

    else:
        is_copy = False

    if j1:
        if j1.width > j.pocket.w or j1.height > j.pocket.h:
            # Copy a rectangle:
            j.mold.size = select_image_trim(d, j, j1)

        else:
            j.mold.size = j1.width, j1.height
            pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)
    return is_copy


def mold_fill(j, _):
    """
    Resize using a fill-image resize-type.

    j: Image
        Has cell info.

    _: dict
        of image place, form
        ignore

    Return: buffer data
        of the image
    """
    if j.size != j.pocket.size:
        Mage.copy_all(j.j)

        j1 = pdb.gimp_edit_paste_as_new_image()
        w, h = j.mold.size = j.pocket.size
        Mage.shape(j1, w, h)

    else:
        j.mold.size = j.size
        Mage.copy_all(j.j)
    return True


def mold_fixed(j, d):
    """
    Resize an image with fixed-size values.

    j: Image
        Has cell info.
        Has material.
        work-in-progress

    d: dict
        of image place, form

    Return: flag
        Is true if there is material in the buffer.

        buffer data
            of the image
    """
    is_copy = True

    Mage.copy_all(j.j)

    j1 = pdb.gimp_edit_paste_as_new_image()
    e = d[ok.RESIZE_METHOD]

    pdb.gimp_layer_scale(
        j1.layers[0],
        e[ok.FIXED_IMAGE_SIZE_W],
        e[ok.FIXED_IMAGE_SIZE_H],
        Fu.LayerScale.IMAGE_ORIGIN
    )
    pdb.gimp_image_resize_to_layers(j1)

    if j1:
        if j1.width > j.pocket.w or j1.height > j.pocket.h:
            # Copy a rectangle:
            j.mold.size = select_image_trim(d, j, j1)

        else:
            j.mold.size = j1.width, j1.height
            pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

    else:
        is_copy = False
    return is_copy


def mold_factor(j, d):
    """
    Resize an image by multiplying its size by a factor.

    j: Image
        Has cell info.
        Has material.
        work-in-progress

    d: dict
        of image place, form

    Return: flag
        Is true if there is material in the buffer.
        buffer data
            of the image
    """
    is_copy = True

    Mage.copy_all(j.j)

    j1 = pdb.gimp_edit_paste_as_new_image()
    e = d[ok.RESIZE_METHOD]

    pdb.gimp_layer_scale(
        j1.layers[0],
        int(j1.width * round(e[ok.FACTOR_IMAGE_SIZE_W], 6)),
        int(j1.height * round(e[ok.FACTOR_IMAGE_SIZE_H], 6)),
        Fu.LayerScale.IMAGE_ORIGIN
    )
    pdb.gimp_image_resize_to_layers(j1)

    if j1:
        if j1.width > j.pocket.w or j1.height > j.pocket.h:
            # Copy a rectangle:
            j.mold.size = select_image_trim(d, j, j1)

        else:
            j.mold.size = j1.width, j1.height
            pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

    else:
        is_copy = False
    return is_copy


def mold_image(j, d, o):
    """
    Mold an image to fit a cell.

    j: Image
        to fit into cell

    d: dict
        of image place, form

    Return: bool
        Is true if there is material in the buffer.
    """
    pdb.gimp_selection_none(Hat.cat.render.image)

    grid = o.grid
    o.is_not_shaped = True
    r, c = o.r, o.c
    j.mold.size = j.mold.position = 0, 0
    j.pocket = grid.get_pocket(r, c)
    j.shape = grid.get_shape(r, c)
    j.plaque = grid.get_plaque(r, c)
    j.cell_shape = grid.cell_shape
    s = j.pocket.size = calc_shift_size(o, *j.pocket.size)
    n = d[ok.RESIZE_METHOD][ok.RESIZE_TYPE]
    is_copy = MOLD[n](j, d)
    f = j.rotate
    f1 = calc_shift_rotation(o)
    f2 = f + f1

    if f2 and is_copy:
        j1 = pdb.gimp_edit_paste_as_new_image()

        if o.grid.is_not_rectangular:
            o.is_not_shaped = False
            apply_shape_mask(
                j1.layers[0],
                dispatch[o.grid.cell_shape](
                    Rect((0, 0), (j1.width, j1.height))
                )
            )

        z = Lay.rotate(j1, f2)
        t = w, h = z.width, z.height

        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

        if (w > s[0] or h > s[1]) and not f1:
            t = w, h = Shape.calc_lock(s, t)
            j2 = pdb.gimp_edit_paste_as_new_image()
            Mage.shape(j2, w, h)
        j.mold.size = t

    if is_copy:
        # Calculate mold:
        x, y = j.pocket.position
        w, h = j.mold.size
        n = d[ok.JUSTIFICATION]

        if n in ju.RIGHT:
            x += j.pocket.w - w

        if n in ju.CENTER_X:
            x += (j.pocket.w - w) // 2

        if n in ju.CENTER_Y:
            y += (j.pocket.h - h) // 2

        elif n in ju.BOTTOM:
            y += j.pocket.h - h

        x, y, is_shift = calc_shift_position(o, x, y)
        j.mold.position = x, y

        grid.set_mold(r, c, (x, y), (w, h))
        if is_shift:
            j.shape = dispatch[o.grid.cell_shape](j.mold)
    return is_copy


def mold_lock(j, _):
    """
    Resize using the locked proportions resize method.

    j: Image
        Has cell info.

    _: dict
        of image place, form
        ignore

    Return: buffer data
        of the image
    """
    Mage.copy_all(j.j)

    if j.width > j.pocket.w or j.height > j.pocket.h:
        # down-size:
        w, h = Shape.calc_lock(j.pocket.size, j.size)
        j1 = pdb.gimp_edit_paste_as_new_image()
        Mage.shape(j1, w, h)

    else:
        w, h = j.size

    j.mold.size = w, h
    return True


def mold_trim(j, d):
    """
    Resize an image using the trim resize-type.

    Finish with the image data in the buffer.

    j: Image
        Has cell info.

    d: dict
        of image place, form

    Return: buffer data
        of the image
    """
    s = s1 = j.size
    t = j.pocket.size

    Mage.copy_all(j.j)

    if s[0] > t[0] or s[1] > t[1]:
        w, h = get_trim_size(s, t)
        j1 = pdb.gimp_edit_paste_as_new_image()

        Mage.shape(j1, w, h)

        j1 = pdb.gimp_edit_paste_as_new_image()
        s1 = select_image_trim(d, j, j1)

        # Copy visible selection:
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

    j.mold.size = s1
    return True


def place_image(j, d, group, o, is_plan):
    """
    Copy and paste images into a image layer group.

    grid: Grid
        Has cell table.

    j: Image
        with GIMP image reference
        Has a row and column position.
        Has a rotate attribute.

    d: dict
        of image place for cell

    group: layer
        group for image layer group

    o: One
        Has model name.

    return: the selected layer or None
        with image
        Is None and no selection when there is no image.
    """
    cat = Hat.cat
    pdb.gimp_selection_none(cat.render.image)

    # The Image's GIMP image will enter the copy and paste buffer:
    if mold_image(j, d, o):
        z = Lay.paste(group.layers[0])

        if is_plan:
            z.opacity = 100.

        else:
            z.opacity = d[ok.OPACITY]

        if d[ok.FLIP_HORIZONTAL]:
            Lay.flip(z, horizontal=1)

        if d[ok.FLIP_VERTICAL]:
            z = Lay.flip(z)

        # The 'mold' attribute is from 'mold_image':
        pdb.gimp_layer_set_offsets(z, j.mold.x, j.mold.y)

        if o.grid.is_not_rectangular and o.is_not_shaped:
            apply_shape_mask(z, j.shape)

        if not is_plan:
            z.opacity = d[ok.OPACITY]
        return z


def select_image_trim(d, j, j1):
    """
    Use to get the cell-size scaled image pixels
    for a trimmed or non-resized image.
    Create a selection rectangle for image data transfer.
    Copy the selection.

    d: dict
        of image place, form

    j: Image
        Has cell info.

    j1: GIMP image
        with trim

    Return: tuple
        the selection size
    """
    # Need to select from o layer only:
    m = False

    if len(j1.layers) > 1:
        Mage.copy_all(j1)

        m = True
        j1 = pdb.gimp_edit_paste_as_new_image()

    n = d[ok.JUSTIFICATION]
    s = j.pocket.size
    t = j1.width, j1.height

    if n in ju.LEFT:
        x = 0
        x1 = s[0]

    elif n in ju.RIGHT:
        x = max(t[0] - s[0], 0)
        x1 = t[0]

    else:
        # horizontal center:
        x = max(t[0] // 2 - s[0] // 2, 0)
        x1 = min(t[0] // 2 + s[0] // 2 + s[0] % 2, t[0])

    if n in ju.TOP:
        y = 0
        y1 = s[1]

    elif n in ju.BOTTOM:
        y = max(t[1] - s[1], 0)
        y1 = t[1]

    else:
        # vertical center:
        y = max(t[1] // 2 - s[1] // 2, 0)
        y1 = min(t[1] // 2 + s[1] // 2 + s[1] % 2, t[1])

    # Correct for underflow:
    if x == x1:
        x1 += 1

    if y == y1:
        y1 += 1

    w = max(x1 - x, 1)
    h = max(y1 - y, 1)

    Sel.rect(j1, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
    pdb.gimp_edit_copy(j1.layers[0])

    _, x, y, x1, y1 = pdb.gimp_selection_bounds(j1)

    if m:
        pdb.gimp_image_delete(j1)
    return x1 - x, y1 - y


class Place:
    """Organize functions related to image placement."""

    # Use with the Image class:
    IMAGE_INDEX = {
        # '-2' is a condition that will cause an init function to perform:
        ik.LOOP_DICT: {ik.LOOP: -2, ik.SLICE: {}},
        ik.NEXT_DICT: {ik.NEXT: 0, ik.SLICE: {}},
        ik.PREVIOUS_DICT: {ik.PREVIOUS: -2, ik.SLICE: {}},
        ik.SLICE: {}
    }

    @staticmethod
    def blur_behind_grid(o):
        """
        Blur behind grid cells.

        o: One
            Has variables.
        """
        def process_layer():
            def do():
                z1_ = z1

                if not z1_:
                    z1_ = Lay.clone_background(z)
                    z1_.name = Lay.name(z1_.parent, nk.IMAGE_BEHIND)

                cat.join_selection(k)
                Lay.blur(z1_, blur)
                return z1_, [cat.save_short_term_sel()]

            q = []
            z1 = None

            if is_nested_group:
                n = z.parent.name.split(" ")[-1]

            else:
                n = z.name.split(" ")[-1]

            for r in range(row):
                for c in range(column):
                    go = Shape.is_allocated_cell(o.grid, r, c)

                    if go and is_merge_cell:
                        s = d[ok.PER_CELL][r][c]
                        go = s != (-1, -1)

                    if go:
                        e = is_per_cell[r][c] if is_per_cell else d
                        go = blur = e[ok.BLUR_BEHIND]

                    if go:
                        k = o.model_name, r, c
                        go = cat.is_image_sel(k)
                    if go:
                        if is_nested_group:
                            if cat.get_z_height(k) == n:
                                z1, sel = do()
                                q += sel
                        else:
                            z1, sel = do()
                            q += sel
            if z1:
                pdb.gimp_selection_none(j)

                for sel in q:
                    Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

                if q:
                    Sel.invert_clear(z1)
                return z1

        cat = Hat.cat
        j = cat.render.image
        z = o.image_layer
        d = Path.get_place_chunk(o.path)
        row, column = o.grid.division
        is_merge_cell = o.grid.is_merge_cell
        is_per_cell = d[ok.PER_CELL]
        is_nested_group = Lay.with_nested_group(z)

        # 'undo_z' is a list of layers for the preview's undo function:
        undo_z = []

        if is_per_cell or d[ok.BLUR_BEHIND]:
            if Lay.with_nested_group(z):
                for i in z.layers[::-1]:
                    for z in i.layers:
                        if cat.get_image_layer(z.name):
                            undo_z += [process_layer()]
                            break
            else:
                # The image layer is either a layer with one or more
                # images, or a group with one or more child image layers:
                undo_z = process_layer()
        return undo_z

    @staticmethod
    def do_custom_cell(o, is_plan):
        """
        Place a custom cell image onto the render.

        o: One
            Has place variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with image
        """
        cat = Hat.cat
        j = cat.render.image
        z = group = None
        d = o.e = o.d
        parent = o.parent
        name = o.model_name

        if Tip.has_pic(d[ok.IMAGE])[0]:
            j1 = Image.get_image(d[ok.IMAGE], o.image_index)
            o.grid.set_image(0, 0, j1)
            if j1:
                group = Lay.group(
                    j, Lay.name(parent, nk.IMAGE),
                    parent=parent
                )

                Lay.add(j, "Image", parent=group)
                cat.seed(d[ok.SHIFT])

                j1.rotate = d[ok.ROTATE]
                o.r = o.c = 0
                z = place_image(j1, d, group, o, is_plan)

                if z:
                    n = j1.layer_name if j1.layer_name else j1.image_name
                    o.grid.set_image_name(0, 0, n)

                    cat.save_z_height(name, "0")
                    cat.save_image_sel(z, name)
                Image.close_image(j1)

        if group:
            z = Lay.merge_group(group)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.IMAGE_INFLUENCE)
        return z

    @staticmethod
    def do_grid(o, is_plan):
        """
        Place grid images onto the render.

        o: One
            Has place variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with image
        """
        def do_gradient():
            if not is_plan:
                return GradientLight.apply_light(z, ok.IMAGE_INFLUENCE)
            return z

        cat = Hat.cat
        j = cat.render.image
        z = group = None
        d = e = o.e = o.d
        row, column = o.grid.division
        parent = o.parent
        name = o.model_name
        is_per_cell = d[ok.PER_CELL]
        is_merge_cell = o.grid.is_merge_cell
        loft = []
        grid_d = o.grid.d
        go = True

        if not is_per_cell:
            go = Tip.has_pic(e[ok.IMAGE])[0] and e[ok.OPACITY]
            cat.seed(d[ok.SHIFT])

        if go:
            # Place images:
            for r in range(row):
                for c in range(column):
                    if Shape.is_allocated_cell(o.grid, r, c):
                        go = True
                        o.r, o.c = r, c

                        if is_merge_cell:
                            if grid_d[ok.PER_CELL][r][c] == (-1, -1):
                                go = False

                        if is_per_cell and go:
                            e = o.e = Form.get_form(o)
                            go = Tip.has_pic(e[ok.IMAGE])[0] \
                                and e[ok.OPACITY]
                            cat.seed(e[ok.SHIFT])
                        if go:
                            j1 = Image.get_image(e[ok.IMAGE], o.image_index)
                            if j1:
                                j1.cell_shape = o.grid.cell_shape
                                k = name, r, c
                                n = j1.layer_name if j1.layer_name \
                                    else j1.image_name

                                o.grid.set_image_name(r, c, n)
                                o.grid.set_image(r, c, j1)

                                if not group:
                                    group = Lay.group(
                                        j, Lay.name(parent, nk.IMAGE),
                                        parent=parent
                                    )

                                z_height = calc_z_height(e[ok.SHIFT], r, True)
                                j1.rotate = Form.get_image_rotate(o)
                                n1 = str(z_height)
                                n2 = Lay.name(group, n1)

                                if z_height in loft:
                                    x = loft.index(z_height)
                                    group1 = group.layers[x]

                                else:
                                    loft += [z_height]
                                    loft = sorted(loft)[::-1]
                                    x = loft.index(z_height) + 1
                                    z = Lay.add(j, n1, parent=group)
                                    group1 = Lay.group(
                                        j,
                                        n2,
                                        parent=group,
                                        offset=x,
                                        layer=z
                                    )

                                z = place_image(j1, e, group1, o, is_plan)

                                if z:
                                    Sel.item(z)
                                    cat.save_image_sel(z, k)
                                    cat.save_z_height(k, n1)
                                Image.close_image(j1)

        if group:
            if len(group.layers) == 1:
                z = Lay.merge_group(group)
                z = do_gradient()
            else:
                q = group.layers

                for x, z in enumerate(q):
                    z = Lay.merge_group(z)
                    z = do_gradient()

                    Lay.group(
                        j,
                        z.parent.name + " Group " + z.name.split(" ")[-1],
                        parent=group,
                        offset=x,
                        layer=z
                    )
                    cat.save_image_layer(z, z.name)
                z = group
        return z

    @staticmethod
    def do_stack(o, is_plan):
        """
        Place stack images onto the render.

        o: One
            Has place variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer (single or group) or None
            with image
        """
        def do_gradient():
            if not is_plan:
                return GradientLight.apply_light(z, ok.IMAGE_INFLUENCE)
            return z

        cat = Hat.cat
        j = cat.render.image
        z = group = None
        d = e = o.e = o.d
        parent = o.parent
        is_per_cell = d[ok.PER_CELL]
        loft = []
        o.c = 0
        go = True
        o.shift = One(x=0, y=0, w=0, h=0, rotate=0)

        if not is_per_cell:
            go = Tip.has_pic(e[ok.IMAGE])[0] and e[ok.OPACITY]
            cat.seed(d[ok.SHIFT])

        if go:
            # Place images:
            for r in range(o.grid.cell_count):
                o.r = r

                if is_per_cell:
                    e = o.e = Form.get_form(o)
                    go = Tip.has_pic(e[ok.IMAGE])[0] and e[ok.OPACITY]
                    cat.seed(e[ok.SHIFT])

                if go:
                    j1 = Image.get_image(e[ok.IMAGE], o.image_index)
                    if j1:
                        n = j1.layer_name if j1.layer_name else j1.image_name

                        # image-type key, (model name, row, column):
                        k = o.model_name, r, 0

                        o.grid.set_image_name(r, 0, n)
                        o.grid.set_image(r, 0, j1)

                        if not group:
                            group = Lay.group(
                                j, Lay.name(parent, nk.IMAGE),
                                parent=parent
                            )

                        j1.rotate = Form.get_image_rotate(o)
                        z_height = calc_z_height(e[ok.SHIFT], r, False)
                        n1 = str(z_height)
                        n2 = Lay.name(group, n1)

                        if z_height in loft:
                            x = loft.index(z_height)
                            group1 = group.layers[x]

                        else:
                            loft += [z_height]
                            loft = sorted(loft)[::-1]
                            x = loft.index(z_height) + 1
                            z = Lay.add(j, n1, parent=group)
                            group1 = Lay.group(
                                j,
                                n2,
                                parent=group,
                                offset=x,
                                layer=z
                            )

                        z = place_image(j1, e, group1, o, is_plan)

                        if z:
                            Sel.item(z)
                            cat.save_image_sel(z, k)
                            cat.save_z_height(k, n1)
                        Image.close_image(j1)

        if group:
            if len(group.layers) == 1:
                z = Lay.merge_group(group)
                z = do_gradient()
            else:
                q = group.layers

                for x, z in enumerate(q):
                    z = Lay.merge_group(z)
                    z = do_gradient()
                    if o.grid.image_group_type == st.EACH_HAS_GROUP:
                        Lay.group(
                            j,
                            z.parent.name + " Group " + z.name.split(" ")[-1],
                            parent=group,
                            offset=x,
                            layer=z
                        )
                        cat.save_image_layer(z, z.name)

                # Stack's 'one' image-group-type has
                # only image layers in its group:
                if o.grid.image_group_type == st.ONE_GROUP:
                    cat.save_image_layer(group, group.name)
                z = group
        return z


MOLD = {
    ok.COVER: mold_cover,
    fz.CROP: mold_crop,
    ok.FILLED: mold_fill,
    fz.FIXED: mold_fixed,
    fz.FACTOR: mold_factor,
    ok.LOCKED: mold_lock,
    ok.TRIM: mold_trim
}
