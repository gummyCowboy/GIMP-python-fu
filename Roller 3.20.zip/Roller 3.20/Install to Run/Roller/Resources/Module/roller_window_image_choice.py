#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import (
    Group as gk,
    Option as ok,
    Widget as wk,
    Window as wi
)
from roller_one_draw import Draw
from roller_one_tip import Tip
from roller_option_group import OptionGroup
from roller_option_preset import Preset
from roller_option_preset_dict import PresetDict
from roller_port_preview import PortPreview
from roller_window import Window
from roller_window_save import RWSave

DONE = 1


class RWImageChoice(Window):
    """Is a GTK dialog with multiple options for assigning an image."""
    def __init__(self, g):
        """
        Create a window.

        g: OptionButton
            Has values.
        """
        self.safe = g
        d = {
            wk.WIN: g.win.win,
            wk.WINDOW_TITLE: "Choose an Image Source",
            wk.WINDOW_KEY: wi.IMAGE_CHOOSER
        }

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortImageChoice(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()


class PortImageChoice(PortPreview):
    """Offer different methods for assigning images to cells."""

    def __init__(self, d, g):
        """
        Create the port.

        d: dict
            Has port init values.

        g: OptionButton
            Has values.
        """
        PortPreview.__init__(self, d, g)

    def _draw_image_options(self, g):
        """
        Draw the options.

        g : VBox
            container for the groups
        """
        """
        Draw the options.

        g: GTK container
            to receive group
        """
        k = gk.IMAGE_CHOICE
        d = OptionGroup.draw_group(
            **{
                wk.COLOR: self.color,
                wk.CONTAINER: g,
                wk.GROUP_KEY: k,
                wk.GROUP_TYPE: Preset,
                wk.HAS_PRESET: True,
                wk.IS_DEFAULT: False,
                wk.KEYS: PresetDict.get_keys(k),
                wk.ON_KEY_PRESS: self.on_key_press,
                wk.ON_PREVIEW_BUTTON: self.task_preview,
                wk.ON_WIDGET_CHANGE: self.on_widget_change,
                wk.PATH: (k,),
                wk.PORT: self,
                wk.SAVE_WINDOW: RWSave,
                wk.WIN: self.roller_window
            }
        )
        g = self.preset = d[wk.PRESET]
        self.group = g.group
        g.load_preset(self.safe.get_value())

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        self.draw_simple_dialog_port(
            g,
            (self._draw_image_options, self.draw_preview_process),
            ("Image Source", "")
        )

    def get_group_value(self):
        """
        Use to get the preset value.
        Call from PortPreview.

        Return: dict
            of image choice
        """
        return self.preset.get_value()

    def on_widget_change(self, g):
        """
        Respond to widget changes.

        g: Widget
            Is responsible.
        """
        if not Draw.load_count:
            # ComboBox tips don't stick after the widget has been initializedL
            d = g.group.d
            for _, g1 in d.items():
                if g1.key == ok.NUMERIC_SEQUENCE:
                    g1.widget.set_tooltip_text(Tip.IMAGE_NUMERIC)
                elif g1.key == ok.IMAGE_NAME:
                    g1.widget.set_tooltip_text(Tip.IMAGE_NAME)
        return DONE
