#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk
from roller_widget import Widget
import gtk


class CheckButton(Widget):
    """
    Is a custom GTK CheckButton.

    Is attached to its own Alignment.
    """
    change_signal = 'clicked'

    def __init__(self, **d):
        """
        Create a CheckButton and an Alignment.

        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.CheckButton(label=d[wk.TEXT])

        Widget.__init__(self, g, **d)
        self.add(g)

        # Do the connections last:
        g.connect('clicked', self.callback)
        g.connect('activate', self.callback)

    def get_value(self):
        """
        Get the value of the CheckButton.

        Is part of the Widget template.

        Return: int
            of CheckButton checked state
        """
        return int(self.widget.get_active())

    def set_value(self, a):
        """
        Set the CheckButton checked state.

        Is part of the Widget template.

        a: int
        """
        self.widget.set_active(a)
