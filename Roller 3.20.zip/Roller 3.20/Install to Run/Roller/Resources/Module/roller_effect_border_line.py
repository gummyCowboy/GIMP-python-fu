#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

em = Fu.Emboss
pdb = fu.pdb
BRIGHTNESS_ZERO = 0
CONTRAST_50 = 50
ELEVATION_30 = 30.


def add_noise_layer(z, d):
    """
    Add a bump layer.

    z: layer
        to clone from

    d: dict
        Has options.
    """
    n = z.name
    z, z1 = RenderHub.add_noise(z, d)

    if z1:
        z1.mode = fu.LAYER_MODE_HARDLIGHT
        z1.opacity = d[ok.NOISE_OPACITY]
        z = pdb.gimp_image_merge_down(z.image, z1, fu.CLIP_TO_IMAGE)
        z.name = n
    return z


def process_layers(o, filler, framer):
    """
    Do effect for each image in the image layers.

    z: layer
        to receive effect

    filler: function
        Call to fill a frame.

    framer: function
        Call to add more frame.

    o: One
        Has variables.

    Return: list
        of frames
    """
    undo_z = []

    for i in o.image_layer.layers:
        undo_z += [process_image(o, i.layers[0], filler, framer)]
    return undo_z


def process_image(o, image_layer, filler, framer):
    """
    Do the effect for an image.

    o: One
        Has variables.

    filler: function
        Call to fill a frame.

    framer: function
        Call to add more frame.

    image_layer: layer
        Has image material.
    """
    cat = Hat.cat
    d = o.d
    j = cat.render.image
    parent = image_layer.parent
    z = Lay.add(j, Lay.name(parent, o.k), parent=parent)

    Sel.make_layer_sel(image_layer)

    o.image_sel = cat.save_short_term_sel()

    Sel.grow(j, d[ok.FRAME_WIDTH], d[ok.FRAME_TYPE])

    sel = cat.save_short_term_sel()
    filler_sel = None

    if filler or (filler and framer):
        # Create filler and outer selections:
        Sel.grow(j, d[ok.WIDTH], d[ok.FRAME_TYPE])
        Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
        Sel.grow(j, 1, d[ok.FRAME_TYPE])

        # for filler:
        filler_sel = cat.save_short_term_sel()

        Sel.grow(
            j,
            max(int(d[ok.FRAME_WIDTH] / 3.5), 3),
            d[ok.FRAME_TYPE]
        )
        Sel.load(j, filler_sel, option=fu.CHANNEL_OP_SUBTRACT)
        Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

    if framer:
        # Pass the frame and filler selections:
        framer(o, image_layer, cat.save_short_term_sel(), filler_sel)

    Sel.load(j, o.image_sel, option=fu.CHANNEL_OP_SUBTRACT)
    Sel.fill(z, (127, 127, 127))
    pdb.gimp_selection_none(j)
    pdb.plug_in_emboss(
        j, z,
        cat.azimuth,
        ELEVATION_30,
        em.DEPTH_1,
        em.EMBOSS
    )
    pdb.gimp_brightness_contrast(z, BRIGHTNESS_ZERO, CONTRAST_50)
    pdb.plug_in_antialias(j, z)

    z = add_noise_layer(z, d)
    z = GradientLight.apply_light(z, ok.METAL_FRAME)

    if filler:
        # Pass the filler selection:
        z1 = filler(z, image_layer, o, filler_sel)
        if z1:
            z = pdb.gimp_image_merge_down(z.image, z1, fu.CLIP_TO_IMAGE)
    return z


class BorderLine:
    """Create a metallic-like border around images."""

    @staticmethod
    def do(o, filler=None, framer=None):
        """
        Do the Border Line image-effect.

        o: One
            Has variables.

        filler: function
            Call to fill a frame.

        framer: function
            Call to add more frame.

        Return: layer or list
            with frame
        """
        z = o.image_layer
        o.shadow_layer = [z]

        if o.is_nested_group:
            undo_z = process_layers(o, filler, framer)

        else:
            undo_z = process_image(o, z, filler, framer)
            o.shadow_layer = z, undo_z
        return undo_z
