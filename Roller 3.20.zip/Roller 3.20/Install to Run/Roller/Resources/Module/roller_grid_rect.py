#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_one import Rect
from roller_one_extract import Shape


class GridRect:
    """
    Calculate the position and the size of cells.

    The cells are rectangular shaped.
    """

    def __init__(self, o):
        """
        Calculate cell size and rectangle shape.

        o: One
            Has init values.
        """
        self.row, self.column = o.r, o.c
        self.grid = o.grid
        self.grid_type = o.grid_type
        row, column, table = o.r, o.c, self.grid.table
        x, y = o.offset
        s = o.layer_space

        # Determine if the 'cell size' is the grid type.
        # If so then calculate grid size:
        if o.grid_type == gr.CELL_SIZE:
            w, h = o.column_width, o.row_height
            s1 = w * column, h * row
            w, h = w / 1., h / 1.
            x, y = Shape.calc_pin_offset(
                o.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        elif o.grid_type == gr.SHAPE_COUNT:
            w = s[0] // column
            h = s[1] // row
            w = min(w, h)
            s1 = w * column, w * row
            w, h = w, w
            x, y = Shape.calc_pin_offset(
                o.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            w = s[0] / 1. / column
            h = s[1] / 1. / row

        # intersect points:
        q_y = []
        q_x = []

        for r in range(row + 1):
            q_y.append(int(round(y)))
            y += h

        for c in range(column + 1):
            q_x.append(int(round(x)))
            x += w
        for r in range(row):
            for c in range(column):
                y, y1 = q_y[r], q_y[r + 1]
                x, x1 = q_x[c], q_x[c + 1]
                position = x, y
                size = x1 - x, y1 - y

                # 'cell' is the cell before margins:
                a = table[r][c]
                a.cell = Rect(position, size)
                x1, y1 = x + size[0], y + size[1]
                q = x, y, x1, y, x1, y1, x, y1
                a.shape = a.plaque = q
