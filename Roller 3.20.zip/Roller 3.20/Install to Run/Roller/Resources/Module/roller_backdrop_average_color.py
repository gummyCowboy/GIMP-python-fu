#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import BackdropStyle as bsk, Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_option_preset_dict import PresetDict
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class AverageColor:
    """
    Determine a backdrop-image's average color
    and apply it over the backdrop-image.
    """

    @staticmethod
    def do(o):
        """
        Do the Average Color backdrop-style.

        o: One
            Has variables.

        Return: layer or None
            Is Average Color.
        """
        cat = Hat.cat
        j = cat.render.image
        d = o.d
        if d[ok.OPACITY]:
            z = Lay.clone(o.z)
            z = Lay.clone(z)
            e = PresetDict.get_default(bsk.COLOR_FILL)

            e.update(d)

            q = RenderHub.get_average_color(z)

            if d[ok.INVERT]:
                q = RenderHub.invert_color(q)

            Lay.color_fill(z, q)

            z = RenderHub.bump(z, d[ok.BUMP])
            z.mode, z.opacity = RenderHub.get_mode(d)
            return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
