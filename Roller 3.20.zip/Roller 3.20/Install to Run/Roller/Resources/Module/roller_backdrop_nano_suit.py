#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu
pdb = fu.pdb


class NanoSuit:
    """Fill the backdrop-image with a fine gradient texture."""

    @staticmethod
    def do(o):
        """
        Do the backdrop-style.

        o: One
            Has variables.

        Return: layer or None
            with Color Fill
        """
        d = o.d
        if d[ok.OPACITY] and Lay.has_pixel(o.z):
            j = Hat.cat.render.image
            z = Lay.clone(o.z)
            group = Lay.group(j, o.k, layer=z)

            Lay.blur(z, 500)
            Gegl.video_degradation(z, 'dots')

            z = Lay.clone(z)
            z.mode = fu.LAYER_MODE_DIFFERENCE

            Gegl.engrave(z, 3)
            pdb.gimp_curves_spline(
                z,
                fu.HISTOGRAM_VALUE,
                4,
                [0, 127, 255, 255]
            )

            z = Lay.merge_group(group)
            z.opacity = d[ok.OPACITY]

            if d[ok.INVERT]:
                pdb.gimp_drawable_invert(z, 0)
            return RenderHub.bump(z, d[ok.BUMP])
