#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Widget as fw
from roller_constant_key import Widget as wk
from roller_one import Base, Hat
import gtk

# For GTK, let it know that the function handled an event:
DONE = 1

NO_BUTTONS = None


class Window:
    """
    Create a window.

    Has common user-interface functions.
    """
    is_dialog = False

    def __init__(self, d):
        """
        Create a window.

        The new window can be a normal window with it's own event
        handler, or be a dialog. There can only be one open window
        with an event handler at a time.

        d: dict
            Has init variables.
        """
        self.is_dialog = Window.is_dialog

        # 'self.pose_key' is the window's key in the window position dict:
        self.pose_key = d[wk.WINDOW_KEY]

        if Window.is_dialog:
            g = self.win = gtk.Dialog(
                d[wk.WINDOW_TITLE],
                d[wk.WIN],
                gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
                NO_BUTTONS
            )

        else:
            g = self.win = d[wk.WIN] = gtk.Window()
            self.switch_box = gtk.VBox()

            g.add(self.switch_box)
            g.set_position(gtk.WIN_POS_CENTER)

        a = self.win.allocation

        if self.pose_key in Hat.cat.window_pose:
            # Make sure the position isn't off screen:
            w, h = Window.get_screen_res()
            self.width, self.height = a.width, a.height
            x, y = Hat.cat.window_pose[self.pose_key]
            x = Base.seal(x, 0, w - self.width)
            y = Base.seal(y, 0, h - self.height - fw.SCROLL_SPAN)
            g.move(x, y)

        else:
            w, h = Window.get_screen_res()
            self.width, self.height = a.width, a.height
            g.move(w // 2 - self.width // 2, h // 2 - self.height // 2)

        self.win.connect('delete_event', self.close)
        Window.is_dialog = True

    def cancel(self, *_):
        """
        Close the window.

        Return: true
            GTK, it is done.
        """
        return self.close()

    def accept(self, d):
        """
        Accept the options.

        Is part of the satellite Window template:
            'self.safe'

        d: dict
            of options

        Return: true
            GTK, it is done.
        """
        if hasattr(self, 'safe'):
            self.safe.set_value(d)
        return self.close()

    def close(self, *_):
        """
        Close the window.
        Exit the main loop.

        Return: true
            Tell GTK that the closing operation is handled.
        """
        g = self.win
        x, y = g.get_position()

        if min(x, y) > -1:
            Hat.cat.window_pose[self.pose_key] = x, y

        if self.is_dialog:
            g.hide()
            g.response(0)

        else:
            g.destroy()
            gtk.main_quit()

            # Set to None, so that WindowMain can determine
            # if its window is actually closed:
            self.win = None

        # Let GTK know that a key-type event has been handled:
        return DONE

    def get_remaining_dim(self, w, h):
        """
        Use to keep the window from drawing off screen.

        Return the width and height of the screen space
        to the right and bottom of the window.
        """
        w1, h1 = Window.get_screen_res()

        if self.pose_key in Hat.cat.window_pose:
            x, y = Hat.cat.window_pose[self.pose_key]

        else:
            x = w1 // 2
            y = h1 // 2

        x = Base.seal(x, x + fw.SCROLL_SPAN, w1 - 200)
        y = Base.seal(y, y + fw.SCROLL_SPAN, h1 - 200)
        return min(w, w1 - x), min(h, h1 - y)

    @staticmethod
    def get_screen_res():
        """
        Return: tuple
             width, height
             of the screen's dimension
        """
        return gtk.gdk.screen_width(), gtk.gdk.screen_height()

    def resize(self):
        """
        Resize a window, but the allocation isn't correct so the process
        only works on the second resize attempt with the old window size.
        In other words, the process is one-step behind the current state.
        """
        if self.win:
            self.win.resize(1, 1)

            w, h = Window.get_screen_res()
            g = self.win.allocation
            self.width, self.height = g.width, g.height
            x, y = q = self.win.get_position()
            x = Base.seal(x, 0, w - self.width)
            y = Base.seal(y, 0, h - self.height - fw.SCROLL_SPAN)
            if (x, y) != q:
                # GTK has an invalid state where the position is negative:
                if q[0] > -2000:
                    self.win.move(x, y)
        return DONE
