#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
import gimpfu as fu

pdb = fu.pdb


def process_layer(j, image_layer, o):
    """
    Add a frame to the image material on a layer.

    j: GIMP image
        Is render.

    image_layer: layer
        with image material

    o: One
        Has variables.

    Return: layer or None
        with frame material
    """
    cat = Hat.cat
    d = o.d
    if d[ok.OPACITY]:
        parent = image_layer.parent

        Sel.make_layer_sel(image_layer)

        sel = cat.save_short_term_sel()

        Sel.grow(j, d[ok.FRAME_WIDTH], d[ok.FRAME_TYPE])
        Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

        z = Lay.add(j, Lay.name(parent, o.k), parent=parent)

        Sel.fill(z, d[ok.COLOR])
        pdb.plug_in_antialias(j, z)

        z = GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)
        z.opacity = d[ok.OPACITY]
        return z


class ColorBoard:
    """Create a an color edge around an image(s)."""

    @staticmethod
    def do(o):
        """
        Do the Colored Board image-effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer, list, or None
            with frame
        """
        j = Hat.cat.render.image
        z = o.image_layer

        # 'undo_z' is a list of layers for the preview's undo function:
        undo_z = []
        o.shadow_layer = [z]

        if o.is_nested_group:
            for i in z.layers:
                undo_z += [process_layer(j, i.layers[0], o)]

        else:
            undo_z = process_layer(j, z, o)
            if undo_z:
                o.shadow_layer = [undo_z, z]
        return undo_z
