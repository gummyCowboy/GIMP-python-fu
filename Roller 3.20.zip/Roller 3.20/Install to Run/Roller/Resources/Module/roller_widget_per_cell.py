#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Group as og
from roller_constant_key import (
    Button as bk,
    Group as gk,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_model_table import Grid, Stack
from roller_option_preset_core import Core
from roller_option_view import do_per_cell
from roller_one import One
from roller_one_draw import Draw
from roller_one_extract import Path
from roller_one import Hat
from roller_one_tip import Tip
from roller_widget_button import Button
from roller_widget_box import Box
from roller_widget_check_button import CheckButton
from roller_port_cell import PortCell
import gtk

TRY = "{} Cell Table: Try escape, enter, space-bar to close, save, edit."


class PerCellGroup(Box):
    """
    This is a custom GTK Button.

    It's value is a list containing a cell table.
    """

    def __init__(self, **d):
        """
        Create a GTK Button that is attached to an GTK Alignment.

        Use to open per cell port.

        d: dict
            Has keyword arguments for the Widget.
        """
        Box.__init__(self, box=gtk.HBox, align=(0, 0, 1, 1))

        self._value = []
        self.group = d[wk.GROUP]
        self.on_preview_button = d[wk.ON_PREVIEW_BUTTON]
        self._group_key = d[wk.GROUP_KEY]
        d[wk.KEY] = ok.PER_CELL
        path = d[wk.PATH]
        self.form_group_key = og.SOURCE_GROUP_KEY[self._group_key]
        self._form_path_key = d[wk.GROUP_KEY].split(",")[0]
        self._form_path = path[:-1] + (self._form_path_key,)
        self.form_group = Hat.cat.group_dict[self._form_path]
        self._port = d[wk.PORT]
        self.roller_window = d[wk.WIN]
        self._update_window = d[wk.ON_WIDGET_CHANGE]

        # CheckButton:
        d[wk.ON_WIDGET_CHANGE] = self._on_change
        d[wk.TOOLTIP] = Tip.PER_CELL_BEGIN
        self.key = d[wk.TEXT] = ok.PER_CELL
        d[wk.ALIGN] = 0, 0, 0, 1
        d[wk.PADDING] = 0, 0, 0, 5
        self.check_button = CheckButton(**d)

        # Button:
        d[wk.TOOLTIP] = Tip.PER_CELL_BUTTON
        d[wk.KEY] = d[wk.TEXT] = bk.OPEN
        d[wk.ALIGN] = 0, 0, 1, 0
        d[wk.PADDING] = 0, 0, 5, 0
        self.button = Button(**d)

        # Add buttons:
        for i in (self.check_button, self.button):
            self.add(i)

    def _on_change(self, g):
        """
        Respond to a change event for one of the widgets.

        g: Widget
            Is responsible.
        """
        def update():
            """
            Update the per cell table.

            Return: Grid
                for the cell editor
            """
            d_ = Path.get_dict_from_path(sk.GLOBAL)
            cat.render.size = d_[ok.RENDER_WIDTH], d_[ok.RENDER_HEIGHT]

            if is_stack:
                model_ = Stack(One(path=path))
                model_.update_pile(One(d=Path.get_pile_from_path(path)))
                model_.update_cell_rect(One(d=Path.get_rectangle_dict(path)))

            else:
                model_ = Grid(One(path=path))
                model_.layer_margin = Path.get_layer_margin(path)
                model_.update_grid(One(d=Path.get_grid_from_path(path)))
                model_.calc_pocket(One(d=Path.get_cell_margin(path)))
            return model_

        if not (Draw.load_count or Draw.preset_load_count):
            cat = Hat.cat
            a = g.get_value()
            path = self._form_path
            is_stack = g.group.parent_type == gk.STACK_CELL

            if g == self.check_button:
                # Update its sibling form group of the change:
                self.form_group.changed = self.form_group.unseen = True

                self.on_per_cell_change(g)
                do_per_cell(self.check_button)

                if not a:
                    self._value = []
                else:
                    update()

            else:
                model = update()
                o = One(
                    is_all_cells=is_stack,
                    model=model,
                    path=path,
                    per_cell_group=self,
                    place_chunk={}
                )

                self._port.switch_ports()

                self._original_value = deepcopy(self._value)
                q = Path.make_place_path(path)

                # What is this doing?
                # d[q].vbox.per_cell_group.get_value()

                o.place_chunk = Path.get_dict_from_path(q)
                o.per_cell_table = self.get_value()
                o.group_key = self.form_group_key
                o.key = self._form_path_key
                o.on_accept = self.accept_port
                o.on_cancel = self.cancel_port
                o.port = self._port
                o.win = self.roller_window
                o.window_title = TRY.format(self._form_path_key)
                PortCell(o, self)
            self._update_window(g)

    def accept_port(self, cell_table):
        """
        Return from PortCell.

        cell_table: list
            a per cell table
        """
        self._value = cell_table
        self._port.show_port()
        self.on_per_cell_change(self.button)

    def cancel_port(self, *_):
        """Return from PortCell."""
        return self._port.show_port()

    def get_value(self):
        """
        Get the Per Cell cell table.

        Return: list
            a cell table
            2D (lists within a list)
        """
        if self._value:
            return deepcopy(self._value)
        return []

    def on_per_cell_change(self, _):
        """
        The source group changes with the per cell group.

        _: Widget
            from the per cell group
            not used
        """
        if not (Draw.load_count or Draw.preset_load_count):
            path = self._form_path
            group = Hat.cat.group_dict[path]

            # 'group.changed' is set by the PortCell hooks:
            group.unseen = True

            Core.update_view_buttons(path)
            group.preview_button.set_sensitive(1)
            group.plan_button.set_sensitive(1)

    def set_value(self, q):
        """
        Set the CheckButton checked state.

        Is part of the Widget template.

        q: a 2D list
            lists within a list
            of cell table
        """
        self.check_button.widget.set_active(len(q) > 0)
        self._value = q
