#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_rect_table import RectTable
from roller_one import Base, Hat
from roller_constant_key import Option as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class ColorGrid:
    """Create a color grid."""

    @staticmethod
    def do(o):
        """
        Do the backdrop-style.

        o: One
            Has variables.

        Return: layer or None
            with Color Grid
        """
        cat = Hat.cat
        j = cat.render.image
        d = o.d
        if d[ok.OPACITY]:
            if d[ok.ROTATE]:
                s = j.width, j.height
                w = Base.circumradius(s[0], s[1]) * 2
                r, c = d[ok.ROW], d[ok.COLUMN]
                d[ok.COLUMN] = int(c * w / 1. / s[0]) + 1
                d[ok.ROW] = int(r * w / 1. / s[1]) + 1
                j1 = pdb.gimp_image_new(w, w, fu.RGB)
                z = Lay.add(j1, o.k)

            else:
                z = Lay.add(j, o.k, parent=o.z.parent)

            z = ColorGrid.draw_color_grid(z, d)

            if d[ok.ROTATE]:
                d[ok.ROW], d[ok.COLUMN] = r, c
                Lay.rotate(j1, d[ok.ROTATE])
                pdb.gimp_edit_copy_visible(j1)
                pdb.gimp_image_delete(j1)

                z = Lay.paste(o.z)
                pdb.gimp_layer_resize_to_image_size(z)

            if d[ok.INVERT]:
                pdb.gimp_drawable_invert(z, 0)

            z.mode, z.opacity = RenderHub.get_mode(d)

            Lay.clone(o.z)

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            return RenderHub.bump(z, d[ok.BUMP])

    @staticmethod
    def draw_color_grid(z, d):
        """
        Draw a checkerboard with two colors.

        z: layer
            to receive grid

        d: dict
            Has options.

        Return: layer
            Has colored grid.
        """
        j = z.image
        s = w, h = j.width, j.height
        row, column = d[ok.ROW], d[ok.COLUMN]
        grid = RectTable(s, row, column).table

        # Draw horizontal stripes:
        Lay.color_fill(z, (255, 255, 255))

        for r in range(0, row, 2):
            Sel.rect(j, 0, grid[r][0].y, w, grid[r][0].h)

        Sel.fill(z, (0, 0, 0))
        pdb.gimp_selection_none(j)

        # Draw vertical stripes:
        z1 = Lay.add(j, "v", parent=z.parent)
        z1.mode = fu.LAYER_MODE_DIFFERENCE

        Lay.color_fill(z1, (255, 255, 255))

        a = grid[0]

        for c in range(0, column, 2):
            Sel.rect(j, a[c].x, 0, a[c].w, h)

        Sel.fill(z1, (0, 0, 0))

        z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
        z1 = Lay.clone(z)

        # Fill the black and white checkerboard:
        Sel.color(z1, (255, 255, 255))
        Sel.fill(z1, d[ok.COLOR_1])
        Sel.invert_clear(z1)
        Lay.color_fill(z, d[ok.COLOR_2])
        pdb.gimp_selection_none(j)
        return pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
