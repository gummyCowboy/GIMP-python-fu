#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Frame as fo
from roller_constant_key import (
    BackdropStyle as by,
    Effect as ek,
    Group as gk,
    Layer as nk,
    Model as md,
    Option as ok
)
from roller_model_caption import Caption
from roller_model_place import Place
from roller_one import Comm, Hat, One
from roller_one_extract import Form, Path
from roller_one_pin import Pin
from roller_one_fu import Lay, Mage, Sel
from roller_render import Render
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb

# Is a dispatch for cell caption blur behind:
ASSIGN_CAPTION = {
    md.CELL: Caption.blur_behind_custom_cell,
    md.STACK: Caption.blur_behind_custom_cell,
    md.TABLE: Caption.blur_behind_grid
}
READY = ": Ready"
WORK = ": Working"


def effect_has_room(z, k):
    """
    Determine if an effect has room. Is for effects that need at
    least one pixel of alpha-transparency to produce a result.

    z: layer
        image layer

    k: string
        effect / group key

    Return: bool
        Is true if the image-effect has working space.
    """
    j = Hat.cat.render.image

    Sel.make_layer_sel(z)
    Sel.invert(j)

    m = Sel.is_sel(j)

    if not m and k != ek.NO_EFFECT:
        Comm.info_msg("{} has no canvas space for its image-effect.".format(k))
    return m


def make_backdrop_alpha(z):
    """
    Set a layer's alpha-transparency to that of the backdrop image layer.

    z: layer
        to adjust
    """
    j = Hat.cat.render.image

    Sel.item(j.layers[-1])
    Sel.invert(j)
    if Sel.is_sel(j):
        pdb.gimp_edit_clear(z)


def undo_gradient_light(z):
    """
    Undo the gradient light layer.

    z: layer or None
        Is sitting above backdrop image / backdrop style.
    """
    Lay.remove(z)
    if GradientLight.image:
        pdb.gimp_image_delete(GradientLight.image)
        GradientLight.image = None


class Product(Render):
    """Create a render."""

    def __init__(self):
        """
        The 'do' function is the entry point for
        rendering the models, effects, and style.
        """
        self.shadow_layer = []

        Render.__init__(self, 'product')
        self.layer_d.update(
            {
                gk.GRID: self._do_grid,
                gk.LAYER_MARGIN: self._set_layer_margin
            }
        )
        self.non_layer_d.update(
            {
                gk.CAPTION_BEHIND: self._blur_behind_caption,
                gk.GRADIENT_LIGHT: self._do_gradient_light,
                gk.IMAGE_BEHIND: self._blur_behind_image,
                gk.IMAGE_EFFECT: self._do_image_effect,

                # blur behind frames:
                gk.CLEAR_FRAME_BEHIND: self._blur_behind_frame,
                gk.COLOR_BOARD_BEHIND: self._blur_behind_frame,
                gk.GLASS_REVEAL_BEHIND: self._blur_behind_frame,
                gk.GRADIENT_LEVEL_BEHIND: self._blur_behind_frame,
                gk.STAINED_GLASS_BEHIND: self._blur_behind_frame
            }
        )
        self._special_effect_d = {
            ek.FEATHER_STEPS: self._undo_feather_steps,
            ek.FRAME_OVER: self._undo_frame_over,
            ek.JAGGED_EDGE: self._undo_jagged_edge
        }
        self._main_effect = None
        self.backdrop_count = 0

    def _blur_behind_caption(self, o):
        """
        Blur behind a grid or a custom cell's caption stripe.

        o: One
            Has variables.
            Has path, d.
        """
        z = ASSIGN_CAPTION[self.model](o)
        self.undo[o.path] = z, Lay.remove

    def _blur_behind_frame(self, o):
        """
        Blur behind a translucent frame.

        o: One
            Has variables.
            Has d: an image-effect Preset
        """
        z = Hat.cat.get_layer((self.model_name, nk.FRAME))
        if z:
            blur = o.d[ok.BLUR_BEHIND]

            if isinstance(z, list):
                undo_z = []

                for i in z:
                    z1 = RenderHub.blur_behind_frame(i, blur)
                    if z1:
                        undo_z += [z1]
                        z1.name = Lay.name(i.parent, o.k.replace(",", ""))
                if undo_z:
                    self.undo[o.path] = undo_z, Lay.remove_layers
            else:
                z = RenderHub.blur_behind_frame(z, blur)
                if z:
                    z.name = Lay.name(z.parent, o.k.replace(",", ""))
                    self.undo[o.path] = z, Lay.remove

    def _blur_behind_image(self, o):
        """
        Blur behind an image.

        o: One
            Has variables.
            Has path:
                Is a tuple made with labels from nodes and an option group.
        """
        z = None

        if self.model in md.MULTI_IMAGE:
            z = Place.blur_behind_grid(o)

        else:
            # custom cell:
            d = Path.get_place_chunk(o.path)
            if o.image_layer and d[ok.BLUR_BEHIND]:
                z = RenderHub.blur_behind(o.image_layer, d, is_merge=False)
                if z:
                    z.name = Lay.name(z.parent, nk.IMAGE_BEHIND)
        if z:
            self.undo[o.path] = z, Lay.remove_layers

    def _do_backdrop(self, o, step, k, is_preview):
        """
        Do a backdrop image or backdrop style.

        o: One
            Has variables.

        step: tuple
            path of option

        k: string
            group key

        is_preview: bool
            Is true when the caller is performing a preview and not a render.
        """
        cat = Hat.cat
        o.z = self.backdrop_layer
        d = deepcopy(self.image_index)

        cat.del_long_term_sel()

        z = Pin.backdrop[k].do(o)

        if k == by.BACKDROP_IMAGE:
            self.backdrop_layer = z
            self.undo[step] = (z, d), self._undo_backdrop
            z.name = k + WORK
            self.backdrop_count = 1
        else:
            if z:
                z.name = k
                self.undo[step] = (z, d), self._undo_backdrop_style
                self.backdrop_count = 2
                offset = Hat.dog.plan.get_offset()

                if offset:
                    pdb.gimp_image_reorder_item(
                        z.image, z,
                        None,
                        offset
                    )

                # Transfer backdrop alpha-state to the backdrop-style.
                # Image gradient in sample mode is an exception:
                if not (is_preview and k == by.IMAGE_GRADIENT):
                    make_backdrop_alpha(z)

    def _do_effect(self, o, step, k):
        """
        Do an image effect.

        o: One
            Has variables.

        step: tuple
            path of option

        k: string
            group key
        """
        cat = Hat.cat
        q = self.shadow_layer[:]
        z = o.image_layer
        o.is_nested_group = Lay.with_nested_group(z)
        o.r, o.c = o.grid.division
        if z and Lay.has_pixel(z) and effect_has_room(z, k):
            o.effect_layer = None
            d1 = deepcopy(self.image_index)
            o.model = self.model
            o.shadow_layer = self.shadow_layer
            z1 = Pin.effect[k].do(o)
            self.shadow_layer = o.shadow_layer

            if k in self._special_effect_d:
                self.undo[step] = ((z1, z, q, d1), self._special_effect_d[k])
            else:
                self.undo[step] = (z1, k, q, d1), self._undo_effect
                if k in fo.BLUR_BEHIND_EFFECT:
                    cat.register_layer((self.model_name, nk.FRAME), z1)

    def _do_gradient_light(self, o):
        """
        Create a gradient light image.
        Make a backdrop gradient light layer.

        o: One
            Has variables.
        """
        cat = Hat.cat
        j = cat.render.image
        cat.gradient_light_d = o.d
        f = o.d[ok.INFLUENCE][ok.BACKDROP_INFLUENCE]
        z = None

        if f:
            GradientLight.create_gradient_light(o.d)
            Mage.copy_all(GradientLight.image)

            z = Lay.paste(self.backdrop_layer)
            z.opacity = f
            z.name = nk.GRADIENT_LIGHT

            pdb.gimp_image_reorder_item(
                j, z,
                None,
                len(j.layers) - self.backdrop_count - 1
            )
            make_backdrop_alpha(z)

        else:
            cat.gradient_light_position = self.backdrop_count
        self.undo[o.path] = z, undo_gradient_light

    def _do_grid(self, o):
        """
        Make a cell table for the grid.

        o: One
            Has variables for Grid.
        """
        a = self.grid.clone()
        d = deepcopy(self.image_index)

        self.grid.update_grid(o)
        self.undo[o.path] = (a, d), self._undo_grid

    def _do_image_effect(self, o):
        """
        Set the shadow layer for the Tri-Shadow image-effect.

        o: One
            Has variables.
        """
        if o.d[ok.IMAGE_EFFECT] == ek.TRI_SHADOW:
            q = self.shadow_layer[:]
            self.shadow_layer = [o.image_layer]
            self.undo[o.path] = q, self._undo_image_effect

    def _set_layer_margin(self, o):
        """
        Set the layer margin dict in Stat.

        o: One
            Has options dict.
        """
        cat = Hat.cat
        a = self.grid.clone()
        self.grid.layer_margin = Form.combine_margin(o.d, *cat.render.size)
        self.undo[o.path] = a, self._undo_layer_margin

    def _undo_backdrop(self, q):
        """
        Undo a backdrop image process.

        q: tuple
            Has a layer and a dict.
        """
        self.backdrop_layer = None
        z, self.image_index = q
        Lay.remove(z)

    def _undo_backdrop_style(self, q):
        """
        Undo a backdrop image process.

        q: tuple
            undo variables
        """
        self.image_gradient_used = None
        z, self.image_index = q
        Lay.remove(z)

    def _undo_effect(self, q):
        """
        Undo an image-effect.

        q: tuple
            undo variables
        """
        cat = Hat.cat
        z, k, self.shadow_layer, cat.image_index = q

        if k in fo.BLUR_BEHIND_EFFECT:
            cat.unregister_layer(None, key=(self.model_name, nk.FRAME))
        Lay.remove_layers(z)

    def _undo_feather_steps(self, q):
        """
        Undo a Feather Steps image-effect.

        q: tuple
            undo variables
        """
        z, z1, self.shadow_layer, self.image_index = q

        Lay.remove_layers(z)

        # image layer or group, 'z1':
        if z1 and pdb.gimp_item_is_group(z1):
            if pdb.gimp_item_is_group(z1.layers[0]):
                # Has shift:
                for i in z1.layers:
                    Lay.show(i.layers[0])
            else:
                # a Stack with one layer group:
                Lay.show(z1)
        else:
            Lay.show(z1)

    def _undo_frame_over(self, q):
        """
        Undo a Frame Over image-effect.

        q: tuple
            undo variables
        """
        z, z1, self.shadow_layer, self.image_index = q
        k = self.render_type, self.model_name, nk.IMAGE

        if z1 and pdb.gimp_item_is_group(z1):
            Hat.cat.register_layer(k, z1)

        Lay.remove_layers(z)

        if z1 and pdb.gimp_item_is_group(z1):
            if pdb.gimp_item_is_group(z1.layers[0]):
                for i in z1.layers:
                    # a z-shifted grid or a stack with each with group:
                    Lay.show(i.layers[0])
            else:
                Lay.show(z1)
                Hat.cat.register_layer(k, z1)
        else:
            Lay.show(z1)
            Hat.cat.register_layer(k, z1)

    def _undo_grid(self, q):
        """
        Undo a grid step.

        q: tuple
            undo variables
        """
        self.grid, self.image_index = q

    def _undo_image_effect(self, q):
        """
        Undo an image effect step.

        q: tuple
            of shadow layers
        """
        self.shadow_layer = q

    def _undo_jagged_edge(self, q):
        """
        Undo a Jagged Edge effect.

        q: tuple
            undo variables
        """
        z, z1, self.shadow_layer, self.image_index = q
        k = self.render_type, self.model_name, nk.IMAGE

        if z1 and pdb.gimp_item_is_group(z1):
            Hat.cat.register_layer(k, z1)

        if isinstance(z, list) and pdb.gimp_item_is_layer_mask(z[0]):
            pdb.gimp_layer_remove_mask(z[1], fu.MASK_DISCARD)
        else:
            Lay.remove_layers(z)

            if z1 and pdb.gimp_item_is_group(z1):
                for i in z1.layers:
                    # a z-shifted grid or a stack with each with group:
                    Lay.show(i.layers[0])
                else:
                    # a Stack with one layer group:
                    for i in z1.layers:
                        Lay.show(i)
            else:
                Lay.show(z1)
                Hat.cat.register_layer(k, z1)

    def _undo_layer_margin(self, a):
        """
        Undo a layer margin change.

        a: Table sub-class
        """
        self.grid = a

    def do(self, steps, undo, is_preview):
        """
        Perform a preview.

        steps: list
            A step is based on an option group.
            preview or final steps

        undo: list
            of steps to undo

        is_preview: bool
            ImageGradient needs this setting.
        """
        Product.is_preview = is_preview
        cat = Hat.cat
        d = cat.group_dict
        e = self.non_layer_d
        e1 = self.layer_d
        is_start = True

        Hat.dog.plan.hide()
        self.undo_steps(undo, steps)

        for step in steps:
            j = cat.render.image
            k = d[step].group_key
            o = One(
                d=Path.get_dict_from_path(step),
                grid=self.grid,
                image_index=self.image_index,
                image_layer=cat.get_layer(
                    (
                        self.render_type,
                        self.model_name,
                        nk.IMAGE
                    )
                ),
                k=k,
                model=self.model,
                model_name=self.model_name,
                parent=self.model_group,
                path=step,
                render_type=self.render_type
            )

            pdb.gimp_selection_none(j)

            if is_start and cat.render.has_image:
                z = self.backdrop_layer
                if z:
                    z.name = z.name.split(":")[0] + WORK
                    is_start = False

            if k in e:
                e[k](o)

            elif k in e1:
                e1[k](o)

            elif k in by.KEY_LIST:
                self._do_backdrop(o, step, k, is_preview)
            elif k in ek.KEY_LIST:
                self._do_effect(o, step, k)

        z = self.backdrop_layer
        j = cat.render.image

        if z:
            z.name = z.name.split(":")[0] + READY

        pdb.gimp_selection_none(j)
        pdb.gimp_displays_flush()
        cat.del_short_term_sel()

    def reset(self):
        """Reset any variables belonging to the render."""
        self.image_index = deepcopy(Place.IMAGE_INDEX)
        self.undo = {}
        self.grid = self.model = self.model_group = \
            self.model_name = self.backdrop_layer = None
