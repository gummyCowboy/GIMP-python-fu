#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import atan2, cos, sin, radians
from random import randint, uniform
from roller_constant_for import Bump as fb, Stack as st
from roller_constant_key import Effect as ek, Model as md, Option as ok
from roller_one_fu import Lay, Sel
from roller_one import Hat, One, Rect
from roller_one_extract import Path
from roller_option_preset_dict import PresetDict
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

pdb = fu.pdb
FOUR_COORDINATES = 4

# oriented with zero at north:
RADIAN_135 = 2.35619
RADIAN_180 = 3.14159
RADIAN_225 = 3.92699
RADIAN_270 = 4.71239
RADIAN_315 = 5.49779
RADIAN_45 = .785398
RADIAN_90 = 1.5708


def blur_behind_tape(z):
    """
    Blur behind the tape.

    z: layer
        with tape material

    Return: layer
        with blurred tape material
    """
    if z:
        z1 = Lay.clone_background(z)

        Lay.blur(z1, 5)
        pdb.gimp_curves_spline(
            z1,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 0, 255, 235]
        )
        Sel.item(z)
        Sel.invert_clear(z1)
        return Lay.merge(z)


def calc_bounds(j, o):
    """
    Calculate the rotated bounds of the
    work-in-progress image in its original size.

    Calculate the transform amount for the x, y vectors.
    The goal of the transform is to calculate
    the corner points of the cell-sized image.

    The function only works when the original image size ratio
    is the same as the cell image's size ratio. The Locked resize
    method will leave the ratio the same, but the other resize
    methods modify this ratio.

    j: Image
        Has size.
    """
    q = o.corners = []
    w, h = j.size

    # center:
    w, h = w // 2, h // 2

    for i in range(4):
        if not i:
            x, y = -w, h

        elif i == 1:
            x, y = w, h

        elif i == 2:
            x, y = w, -h

        else:
            x, y = -w, -h

        x, y = get_point(
            0,
            0,
            atan2(x, y) + o.rotate,
            ((x**2) + (y**2))**0.5
        )
        o.corners.append((x, y))

    x_points = q[0][0], q[1][0], q[2][0], q[3][0]
    y_points = q[0][1], q[1][1], q[2][1], q[3][1]
    u = min(x_points), min(y_points)
    v = max(x_points), max(y_points)
    u = abs(u[0] - v[0]), abs(u[1] - v[1])
    o.transform = (
        o.rect.w / 1. / u[0],
        o.rect.h / 1. / u[1]
    )


def do_bottom_left(o, x, y):
    """
    Make a selection for the bottom-left corner.

    o: One
        with options

    x, y: int
        corner point
    """
    d = o.d
    angle = RADIAN_135 + get_angle_shift(d) + o.rotate
    x, y = get_rotated_corner(o, x, y, 3)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def do_bottom_right(o, x, y):
    """
    Make a selection for the bottom-right corner.

    o: One
        with options

    x, y: int
        corner point
    """
    d = o.d
    angle = RADIAN_45 + get_angle_shift(d) + o.rotate
    x, y = get_rotated_corner(o, x, y, 2)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def do_grid(j, o):
    """
    Do the effect for grid cells.

    j: GIMP image
        Is render.

    o: One
        Has options.

    Return: list
        of undo layers
    """
    # Do o image at a time:
    d = o.grid.d
    is_merge_cell = o.grid.is_merge_cell
    z1 = o.image_layer
    cat = Hat.cat
    undo_z = []
    row, column = o.r, o.c
    s = 1

    if o.is_nested_group:
        for i in z1.layers:
            # 'h' is the z-height of the image layer:
            h = i.name.split(" ")[-1]
            group = None

            for r in range(row):
                for c in range(column):
                    if is_merge_cell:
                        s = d[ok.PER_CELL][r][c]

                    # Is it a dependent cell?
                    if s != (-1, -1):
                        k = o.model_name, r, c
                        if cat.get_z_height(k) == h:
                            cat.join_selection(k)
                            o.r, o.c = r, c
                            if Sel.is_sel(j):
                                o.rotate = radians(
                                    Path.get_place_form(
                                        o
                                    )[ok.ROTATE] + o.grid.get_rotation(
                                        r, c
                                    )
                                )
                                if not group:
                                    group = Lay.group(
                                        j,
                                        o.k,
                                        parent=i
                                    )
                                process_image(j, group, o, r=r, c=c)
            if group:
                image_shadow = do_shadow(o, i.layers[-1])
                z = process_layer(j, group, image_shadow, o)
                undo_z += [z, image_shadow]
    else:
        group = None

        for r in range(row):
            for c in range(column):
                if is_merge_cell:
                    s = d[ok.PER_CELL][r][c]

                # Is it a dependent cell?
                if s != (-1, -1):
                    o.r, o.c = r, c
                    k = o.model_name, r, c
                    cat.join_selection(k)
                    if Sel.is_sel(j):
                        o.rotate = radians(
                            Path.get_place_form(
                                o
                            )[ok.ROTATE] + o.grid.get_rotation(r, c)
                        )
                        if not group:
                            group = Lay.group(
                                j,
                                o.k,
                                parent=o.parent
                            )
                        process_image(j, group, o, r=r, c=c)
        if group:
            image_shadow = do_shadow(o, o.image_layer)
            z = process_layer(j, group, image_shadow, o)
            undo_z = [z, image_shadow]
    return undo_z


def do_shadow(o, z):
    """
    Do the shadow from the image material for the corner tape.

    o: One
        'd', the preset dict for Corner Tape
        'k', the group key string
        'model_name', the model type string

    Return: layer
        with shadow
    """
    d = PresetDict.get_default(ek.SHADOW_1)
    d[ok.OFFSET_X] = d[ok.OFFSET_Y] = 0
    parent = z.parent

    d.update(o.d)
    return Shadow.do(
        One(
            cast=(z,),
            d=d,
            model_name=o.model_name,
            name=Lay.name(parent, o.k + " Shadow"),
            parent=parent
        )
    )


def do_topleft(o, x, y):
    """
    Make a selection for the topleft corner.

    o: One
        Has options.

    x, y: int
        corner point
    """
    d = o.d
    angle = RADIAN_225 + get_angle_shift(d) + o.rotate
    x, y = get_rotated_corner(o, x, y, 0)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def do_top_right(o, x, y):
    """
    Make a selection for the top-right corner.

    o: One
        with options

    x, y: int
        center point
    """
    d = o.d
    angle = RADIAN_315 + get_angle_shift(d) + o.rotate
    x, y = get_rotated_corner(o, x, y, 1)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def get_angle_shift(d):
    """
    Make a randomized angle-shift amount.

    d: dict
        Has angle shift.

    Return: int
        angle shift
    """
    f = d[ok.ANGLE_SHIFT]
    return uniform(radians(-f), radians(f))


def get_corner_shift(d):
    """
    Make a randomized corner-shift amount.

    d: dict
        Has corner shift.

    Return: int
        corner shift
    """
    a = d[ok.CORNER_SHIFT]
    return randint(-a, a)


def get_point(x, y, angle, radius):
    """
    Returns a point on a circle that corresponds to the rotation.

    x, y: int
        center point

    angle : float
        the rotation angle
        of radians

    radius: float
        the radius of the circle

    Returns:
        x : float
        y : float
        the point on the circle
    """
    x = (sin(angle) * radius) + x
    y = (cos(angle) * -radius) + y
    return round(x), round(y)


def get_rotated_corner(o, x, y, corner_x):
    """
    o: One
        Has options.

    x, y: int
        corner point

    corner_x: int
        index to corner point

    Return: tuple
        of int
        corner point
    """
    if o.rotate:
        x1, y1 = o.corners[corner_x]
        x1 *= o.transform[0]
        y1 *= o.transform[1]
        x = x1 + o.center[0]
        y = y1 + o.center[1]

    x += get_corner_shift(o.d)
    y += get_corner_shift(o.d)
    return x, y


def get_tape_length(d):
    """
    Calculate a tape length.

    d: dict
        Has options.

    Return: int
        tape length
    """
    return max(
        1,
        d[ok.TAPE_LENGTH] + randint(-d[ok.LENGTH_SHIFT], d[ok.LENGTH_SHIFT])
    )


def process_custom_cell(j, o):
    """
    Do the effect for any free-range cells.

    j: GIMP image
        Is render.

    o: One
        Has options.
    """
    cat = Hat.cat
    k = o.model_name

    cat.join_selection(k)
    if Sel.is_sel(j):
        o.rotate = radians(
            Path.get_place_form(
                o
            )[ok.ROTATE] + o.grid.get_rotation(0, 0)
        )
        image_shadow = do_shadow(o, o.image_layer)
        group = Lay.group(j, o.k, parent=o.parent)

        cat.join_selection(k)
        process_image(j, group, o)

        z = process_layer(j, group, image_shadow, o)
        return [z, image_shadow]


def process_image(j, parent, o, r=0, c=0):
    """
    Add tape to an image. Select the image material prior to calling.

    j: GIMP image
        Is render.

    parent: layer
        group for different images

    o: One
        Has variables.

    r, c: int
        cell table index
        Use with cell table grid.
    """
    z = Lay.add(j, o.k, parent=parent)
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    w = x1 - x
    h = y1 - y
    o.center = x + w // 2, y + h // 2
    o.rect = Rect((x, y), (w, h))
    d = o.d

    if o.rotate:
        j1 = o.grid.get_image(r, c)
        calc_bounds(j1, o)

    pdb.gimp_selection_none(j)
    do_topleft(o, x, y)
    do_top_right(o, x + w, y)
    do_bottom_left(o, x, y + h)
    do_bottom_right(o, x + w, y + h)
    Sel.fill(z, d[ok.COLOR])
    GradientLight.apply_light(z, ok.OTHER_FRAME)


def select_tape_rect(d, angle, x, y, w):
    """
    Define and select a tape rectangle.

    d: dict
        Has options.

    x, y: int
        start point

    w: int
        length of tape
    """
    w1 = d[ok.TAPE_WIDTH]
    x1, y1 = get_point(x, y, angle - RADIAN_90, w1)
    x2, y2 = get_point(x1, y1, angle - RADIAN_180, w)
    x3, y3 = get_point(x2, y2, angle - RADIAN_270, w1)
    Sel.polygon(
        Hat.cat.render.image,
        (x, y, x1, y1, x2, y2, x3, y3),
        option=fu.CHANNEL_OP_ADD
    )


def process_layer(j, group, image_shadow, o):
    """
    Finish processing a layer with Corner Tape.

    j: GIMP image
        Is render.

    group: layer
        with corner tape material layers

    image_shadow: layer
        with shadow

    o: One
        Has variables.

    Return: layer
        with corner tape material
    """
    d = o.d
    z = Lay.merge_group(group)
    group = Lay.group(j, Lay.name(z.parent, o.k), parent=z.parent, layer=z)
    z1 = Lay.clone(z)
    e = PresetDict.get_default(ok.BUMP)
    e[ok.BUMP_TYPE] = fb.NOISE
    e[ok.BUMP_DEPTH] = 1
    z1 = RenderHub.bump(z1, e)

    Lay.blur(z1, 2)
    pdb.gimp_drawable_invert(z1, 0)

    z1.mode = fu.LAYER_MODE_DIFFERENCE
    z1.opacity = 66.
    z2 = Lay.clone(z1)
    z2.mode = fu.LAYER_MODE_LCH_HUE
    z2.opacity = 24.
    z3 = Lay.clone(z2)
    z3.mode = fu.LAYER_MODE_NORMAL
    z3.opacity = 2.
    z4 = Lay.clone(z)
    z4.mode = fu.LAYER_MODE_HSL_COLOR

    # Darken the edge:
    Sel.item(z4)
    pdb.gimp_selection_shrink(j, 1.)
    Sel.invert(j)
    pdb.gimp_curves_spline(
        z4,
        fu.HISTOGRAM_VALUE,
        FOUR_COORDINATES,
        [0, 10, 255, 80]
    )

    # Place on top:
    pdb.gimp_image_reorder_item(j, z4, group, 0)

    z5 = Lay.clone(z4)
    z5.mode = fu.LAYER_MODE_OVERLAY
    z6 = Lay.clone(z)

    pdb.plug_in_shift(j, z6, 2, 0)
    pdb.plug_in_shift(j, z6, 2, 1)
    Lay.blur(z6, 2)
    pdb.gimp_curves_spline(
        z6,
        fu.HISTOGRAM_VALUE,
        FOUR_COORDINATES,
        [0, 0, 255, 0]
    )

    for i in (z, z1, z2, z3, z4, z5):
        Lay.create_mask(i)

    j.remove_layer(z6)
    pdb.gimp_drawable_invert(z1, 0)

    z = Lay.merge_group(group)

    Sel.item(z)
    Lay.clear_sel(image_shadow)

    z.opacity = d[ok.OPACITY]
    z = blur_behind_tape(z)
    return z


class CornerTape:
    """Simulate a tape image holder."""

    @staticmethod
    def do(o):
        """
        Do a Corner Tape image-effect.
        Is an image-effect template function.

        o: One
            Has variables.

        Return: layer
            with Corner Tape
        """
        cat = Hat.cat
        j = cat.render.image
        d = o.d
        undo_z = []

        cat.seed(d)

        if o.model == md.TABLE:
            undo_z = do_grid(j, o)

        elif o.model == md.STACK:
            if o.grid.image_group_type == st.EACH_HAS_GROUP:
                undo_z = do_grid(j, o)
            else:
                z = o.image_layer

                Sel.item(z)
                if Sel.is_sel(j):
                    o.rotate = .0
                    group = Lay.group(j, o.k, parent=z.parent)
                    z1 = Lay.clone(z)
                    z2 = do_shadow(o, z1)

                    if z2:
                        pdb.gimp_image_reorder_item(
                            j, z2,
                            z.parent,
                            Lay.offset(o.image_layer) + 1
                        )

                    Lay.remove(z1)
                    Sel.item(z)
                    process_image(j, group, o)

                    z = process_layer(j, group, z2, o)
                    undo_z = [z, z2]

        else:
            undo_z = process_custom_cell(j, o)
        return undo_z
