#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import (
    Grid as gr,
    Group as og,
    Shape as sh,
    Triangle as ft
)
from roller_constant_key import Group as gk, Option as ok
from roller_one import Hat, Rect
from roller_one_extract import dispatch, Form, Path, Shape
from roller_grid_cell import GridCell
from roller_grid_circle import GridCircle
from roller_grid_rhombus import GridRhombus
from roller_grid_ellipse import GridEllipse
from roller_grid_ellipse_horz import EllipsisHorz
from roller_grid_ellipse_vert import EllipsisVert
from roller_grid_hexagon_regular import HexagonRegular
from roller_grid_hexagon_truncated import HexagonTruncated
from roller_grid_octagon import GridOctagon
from roller_grid_octagon_double import GridOctagonDouble
from roller_grid_rect import GridRect
from roller_grid_triangle_horz import TriangleHorz
from roller_grid_triangle_vert import TriangleVert
from roller_one import One, Base

SHAPES = {
    sh.CIRCLE_HORIZONTAL: GridCircle,
    sh.CIRCLE_VERTICAL: GridCircle,
    sh.ELLIPSE: GridEllipse,
    sh.ELLIPSE_HORIZONTAL: EllipsisHorz,
    sh.ELLIPSE_VERTICAL: EllipsisVert,
    sh.HEXAGON_REGULAR: HexagonRegular,
    sh.HEXAGON_REGULAR_SHEAR: HexagonRegular,
    sh.HEXAGON_TRUNCATED: HexagonTruncated,
    sh.HEXAGON_TRUNCATED_SHEAR: HexagonTruncated,
    sh.OCTAGON_DOUBLE_REGULAR: GridOctagonDouble,
    sh.OCTAGON_DOUBLE_SHEAR: GridOctagonDouble,
    sh.OCTAGON_SHEAR: GridOctagon,
    sh.OCTAGON_REGULAR: GridOctagon,
    sh.OCTAGON_SIDE_TO_SIDE_REGULAR: GridOctagon,
    sh.OCTAGON_SIDE_TO_SIDE_SHEAR: GridOctagon,
    sh.RECTANGLE: GridRect,
    sh.RHOMBUS: GridRhombus,
    sh.RHOMBUS_SHEAR: GridRhombus,
    sh.SQUARE: GridRect,
    ft.TRIANGLE_DOWN_SHEAR: TriangleVert,
    ft.TRIANGLE_DOWN_ISOSCELES: TriangleVert,
    ft.TRIANGLE_UP_SHEAR: TriangleVert,
    ft.TRIANGLE_UP_ISOSCELES: TriangleVert,
    ft.TRIANGLE_LEFT_SHEAR: TriangleHorz,
    ft.TRIANGLE_LEFT_ISOSCELES: TriangleHorz,
    ft.TRIANGLE_RIGHT_SHEAR: TriangleHorz,
    ft.TRIANGLE_RIGHT_ISOSCELES: TriangleHorz
}


def contract_cell_table(q, row, col):
    """
    Contract Per Cell tables to correspond with the grid dict.

    Checks Merge Cells table for group dimension overflow.

    q: 2D list
        of cell table

    row, col: int
        cell table size
        row, column span
    """
    if q:
        r = len(q)

        if r > row:
            # Remove rows:
            for _ in range(r - row):
                q.pop()
        for r in range(len(q)):
            c = len(q[r])
            if c > col:
                # Remove columns:
                for _ in range(c - col):
                    q[r].pop()


def correct_contracted_cells(q, row, col):
    """
    When cells contract, their dimensions change.
    This makes the cut-off cells independent.

    Use with the merge cell table.

    q: 2D list
        of cell table

    row, col: int
        cell table size
        row, column span
    """
    if q:
        r, c = row, col
        r1 = len(q)
        for r2 in range(r1):
            for c1 in range(len(q[r2])):
                if r2 >= r or c1 >= c:
                    q[r2][c1] = 1, 1
    return q


def correct_merge_overflow(s, row, col, r, c):
    """
    Check if the Merge Cells' table has contracted. If so then
    the top-left cells need their dimensions checked for overflow.

    s: tuple of int (w, h)
        group dimension

    row, col: int
        max location

    r, c: int
        current location
    """
    if s[0] + r > row:
        s = row - r, s[1]

    if s[1] + c > col:
        s = s[0], col - c
    return s


def expand_cell_table(q, row, col, a):
    """
    Expand a cell table based on the row and column counts.

    During an expansion, values are inserted into
    a table from the grid settings.
    These settings are placed in the 'cell' variable.

    Each Per Cell group has its own cell type.

    q: 2D list
        of cell table

    row, col: int
        cell table size
        row, column span

    a: value
        to initialize cell table

    Return: list
        of cell table
    """
    if not q:
        q = Base.make_2d_table(row, col, init=a, deep=True)

    else:
        # 'r', current row count:
        r = len(q)

        if r < row:
            e = []

            for _ in range(col):
                e.append(deepcopy(a))
            for r1 in range(row - r):
                # Add a row with a new list:
                q.append(deepcopy(e))
        for r1 in range(row):
            c = len(q[r1])
            if c < col:
                for _ in range(col - c):
                    # Add a column:
                    q[r1].append(deepcopy(a))
    return q


def fix_cell_table_size(q, r, c, a):
    """
    An existing cell table expands or contracts
    depending on the cell table size.

    q: 2D list
        a cell table
        of option values

    r, c: int
        row, column span of cell table

    a: value
        to initialize cell table

    Return: list
        of cells
        2D
        lists within a list
    """
    q = expand_cell_table(q, r, c, a)

    contract_cell_table(q, r, c)
    return q


def fix_merge_cells(q, row, col):
    """
    Correct overflow references by reducing
    merged group dimensions in the topleft cells.

    q: list
        a cell table

    row, col: int
        cell table span
    """
    if q:
        for r in range(row):
            for c in range(col):
                if r < len(q):
                    if c < len(q[r]):
                        q[r][c] = correct_merge_overflow(
                            q[r][c],
                            row, col,
                            r, c
                        )
    q = correct_contracted_cells(q, row, col)
    return q


def fix_table(q, r, c, k):
    """
    Fix the scale of the per cell tables.
    A per cell widget has a its own per cell table.

    q: tuple
        path prefix created from the model

    r, c: int
        cell index

    k: string
        a per cell option group key
    """
    d = og.PER_CELL_DEPENDENT
    path = q + d[k]
    g = Hat.cat.group_dict[path].vbox.per_cell_group
    if g.check_button.get_value():
        d1 = Path.get_dict_from_path(path)
        table = d1[ok.PER_CELL]

        if k == gk.PER_CELL_GRID:
            table = fix_cell_table_size(table, r, c, (1, 1))
            table = fix_merge_cells(table, r, c)

        else:
            d1.pop(ok.PER_CELL)
            table = fix_cell_table_size(table, r, c, d1)
        g.set_value(table)


class Model:
    """Has functions and variables common model classes."""

    def __init__(self, o):
        """
        Initialize variables. Has 'table' which cell definitions.

        o: One
            Has 'path' which has a model reference.

        A cell has attributes:
            image: Image assigned
            image_name: string, name of image assigned
            merge_cell: rectangle of merged cells; Used by Grid.
            mold: rectangle of image that was placed
            plaque: cell shape with margins
            pocket: rectangle of cell with margins
            rect: rectangle of cell
            shape: cell shape
        """
        self.d = self.rect = self.table = self.cell_shape = None
        self.layer_margin = 0, 0, 0, 0
        self.double_type = sh.NOT_DOUBLE_SPACE
        self.path = o.path if hasattr(o, 'path') else None
        self.add_shift_x = self.add_shift_y = self.add_shift_rotate = \
            self.add_shift_w = self.add_shift_h = self.is_merge_cell = \
            self.is_regular_shape = self.is_not_rectangular = False

        # Init for Rectangle label as it calls on change:
        self.division = 1, 1

        # Use with Layer/Fringe to make clip selection:
        self.rect_shape = None

    def get_normal_type(self):
        """
        Determine if the cell shape is a normal type.

        Return: bool
            Is true if the cell shape is a normal type.
        """
        return self.cell_shape in sh.NORMAL_TYPE

    def get_rotation(self, r, c):
        """
        Get the rotation angle for a given cell.
        Is calculated from the shift options in the pocket preset.

        r, c: int
            cell index

        Return: float
            rotation
        """
        return self.table[r][c].rotation

    def get_cell_position(self, r, c):
        """
        Get a cell's position.

        r, c: int
            cell index

        Return: tuple
            position of cell
            x, y
        """
        return self.table[r][c].cell.position

    def get_cell_rect(self, r, c):
        """
        Get a cell's rectangle.

        table: list
            of cells

        r, c: int
            cell index

        Return: Rect
            of cell
        """
        return self.table[r][c].cell.clone()

    def get_common_margin(self, d):
        """
        Get the cell size for margin calculations.

        d: dict
            of cell margin, chunk

        Return: tuple
            (cell margins, cell size)
        """
        w, h = self.get_cell_rect(0, 0).size
        return Form.combine_margin(d, w, h)

    def get_image(self, r, c):
        """
        Get the image assigned to a cell.

        r, c: int
            cell index

        Return: Image or None
            as assigned
        """
        a = self.table[r][c].cell
        if hasattr(a, 'image'):
            return a.image

    def get_image_name(self, r, c):
        """
        Get the image name assigned to a cell.

        r, c: int
            cell index

        Return: string or None
            an image name
        """
        a = self.table[r][c].cell
        if hasattr(a, 'image_name'):
            return a.image_name

    def get_merge_cell_rect(self, r, c):
        """
        Get a cell's size in the context of possible merged cells.

        r, c: int
            cell index

        Return: tuple
            of cell
            x, y, w, h
        """
        return self.table[r][c].merge_cell.clone()

    def get_mold(self, r, c):
        """
        Mold is a rectangle sized for image place.

        r, c: int
            cell index

        Return: Rect
            of mold
            the rectangle of the image place
        """
        return self.table[r][c].mold.clone()

    def get_plaque(self, r, c):
        """
        Get a 'plaque' value.

        d: dict
            of grid

        r, c: int
            cell index

        Return: tuple or dict
            a plaque
        """
        return self.table[r][c].plaque

    def get_pocket(self, r, c):
        """
        Get the cell pocket.

        r, c: int
            cell index

        Return: Rect
            of mold
            the rectangle of the cell with margins
        """
        return self.table[r][c].pocket.clone()

    def get_shape(self, r, c):
        """
        Get the shape tuple or dict.

        Ellipse shapes are in a dictionary. The
        other shapes are in a list or a tuple.

        r, c: int
            cell index

        Return: object
            of shape
        """
        return self.table[r][c].shape

    def get_z_height(self, r, c):
        """
        Get the z-height of a cell.

        r, c: int
            cell index
        """
        return self.table[r][c].z_height

    def set_image(self, r, c, j):
        """
        Store the image assigned to a cell.

        r, c: int
            cell index

        j: Image
            as assigned
        """
        self.table[r][c].cell.image = j

    def set_image_name(self, r, c, n):
        """
        Store the image name assigned to a cell.

        r, c: int
            cell index

        n: string
            image name
        """
        self.table[r][c].cell.image_name = n

    def set_mold(self, r, c, u, s):
        """
        Set the mold position. The 'mold' is the
        rectangle for an image place.

        u: tuple
            x, y
            screen coordinate
            topleft corner of rectangle

        s: tuple
            size of rectangle
        """
        self.table[r][c].mold = Rect(u, s)

    def set_plaque(self, r, c, a):
        """
        Update a cell plaque.

        r, c: int
            cell index

        a: value
            plaque
        """
        self.table[r][c].plaque = a

    def set_rotation(self, r, c, f):
        """
        Store angle jitter amount for an image in a cell.

        r, c: int
            cell index

        f: float
            assigned angle jitter
        """
        self.table[r][c].rotation = f

    def set_z_height(self, r, c, a):
        """
        Update a cell z-shift.

        r, c: int
            cell index

        a: int
            designated z-shift
        """
        self.table[r][c].z_height = a

    def update_rectangle(self, o):
        """
        Update the cell rectangle for Stack and Custom Cell.

        o: One
            d: dict, rectangle preset
        """
        self.rect = Form.get_custom_cell_rect(o.d)

    def update_pocket(self, r, c, x, y, w, h):
        """
        Set the pocket rectangle and, if needed, update the shape.
        The shape does not have inverted variation, unlike the grid version,
        where every triangle is an inversion of its predecessor.

        r, c: int
            cell index

        x, y: int
            the pocket's canvas coordinate
            the top-left corner of the pocket

        w, h: int
            pocket dimension
        """
        # 'a', a GridCell:
        a = self.table[r][c]

        b = a.pocket = Rect((x, y), (w, h))

        # Update the cell shape if the pocket size has changed:
        if (
            b.size != a.cell.size or
            b.position != a.cell.position
        ):
            n = self.cell_shape
            a.shape = dispatch[n](b)


class CustomCell(Model):
    """
    Use with Custom Cell model to calculate and store cell attributes.
    """

    def __init__(self, o):
        """
        Initialize the table.

        o: One
            'd': dict, custom cell preset
        """
        Model.__init__(self, o)

        self.cell_shape = o.d[ok.CUSTOM_CELL_SHAPE] if hasattr(o, 'd') \
            else None

        self.is_rectangle = self.cell_shape == sh.RECTANGLE
        self.is_regular_shape = self.get_normal_type()
        self.is_not_rectangular = not Shape.is_rectangular_shape(
            self.cell_shape
        )

        # Use with plaque and fringe and their obey margins option.
        # Provide the plaque shape for the selected option:
        self.plaque_shape = self.plaque_pocket = None

    def _calc_cell(self):
        """Calculate the cell size for the cell table."""
        a = self.table[0][0]
        a.shape = a.plaque = self.rect_shape = \
            dispatch[self.cell_shape](self.rect)
        a.cell = self.rect.clone()

    def calc_pocket(self, o):
        """
        Calculate pocket, plaque, and shape.

        o: One
            d: dict
                of margin preset and its per cell table
        """
        q = top, bottom, left, right = self.get_common_margin(o.d)
        x, y = self.rect.position
        w, h = self.rect.size

        if any(q):
            x += left
            y += top
            w = max(w - left - right, 1)
            h = max(h - top - bottom, 1)

        a = Rect((x, y), (w, h))
        self.plaque_pocket = a
        self.plaque_shape = dispatch[self.cell_shape](a)

        # The pocket size will change if the cell shape is normalized:
        if self.is_regular_shape:
            x, y, w, h = Shape.bounds(self.plaque_shape)
        self.update_pocket(0, 0, x, y, w, h)

    def clone(self):
        """
        Make a copy of this CustomCell instance.

        Return: CustomCell
            a copy of this instance
        """
        a = CustomCell(One())

        # Copy the attributes:
        Base.deep_update(a.__dict__, self.__dict__)
        return a

    def update_cell_rect(self, o):
        """
        Update the custom cell given the rectangle preset.

        o: One
            d: dict
                rectangle preset
        """
        # Rectangle preset dict, 'd':
        self.d = o.d

        self.update_rectangle(o)

        table = self.table = Base.make_2d_table(1, 1)
        self.table[0][0] = GridCell(0, 0)

        self._calc_cell()

        # The merge cell rectangle is the same as the cell rectangle:
        table[0][0].merge_cell = table[0][0].cell.clone()


class Grid(Model):
    """
    Calculate the position and the size of cells for a Table model.
    A grid cell table is the prime storage vessel for the Grid class.
    The cell table is referred to as 'self.table'. Each cell in the
    table corresponds with a cell defined by the Grid option group.
    """

    def __init__(self, o):
        """
        Initialize a cell table for a cell grid group.

        o: One
            d: dict, grid preset with its per cell table
            path: tuple, with model reference in path
        """
        Model.__init__(self, o)
        self.is_rectangle = False

    def _calc_grid_division(self):
        """
        Determine the row and column count for the grid.

        Return: tuple
            of int
            row, column
            cell index
        """
        cat = Hat.cat
        d = self.d
        n = d[ok.GRID_TYPE]
        size = cat.render.size

        if n == gr.CELL_COUNT:
            r, c = (
                min(d[ok.ROW_COUNT], size[1]),
                min(d[ok.COLUMN_COUNT], size[0])
            )

        elif n == gr.SHAPE_COUNT:
            r, c = (
                min(d[ok.VERT_COUNT], size[1]),
                min(d[ok.HORZ_COUNT], size[0])
            )

        else:
            # cell size:
            top, bottom, left, right = self.layer_margin
            w = size[0] - left - right
            h = size[1] - top - bottom
            width, height = d[ok.COLUMN_WIDTH], d[ok.ROW_HEIGHT]

            # rectangle and octagon:
            r, c = max(h // height, 1), max(w // width, 1)

            # hexagon, ellipse, rhombus, octagon-double, and triangle:
            n = self.cell_shape

            if self.is_not_rectangular and n not in sh.OCTAGONS:
                if n in sh.HORIZONTAL_ALIGNED:
                    w1, h1 = width * .5, height * .75
                    w2, h2 = w - w1, h - height * .25
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)

                elif n in sh.VERTICAL_ALIGNED:
                    w1, h1 = width * .75, height * .5
                    w2, h2 = w - width * .25, h - h1
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)

                elif n in ft.VERTICAL_TRIANGLE:
                    w1 = width * .5
                    w2 = w - w1
                    r, c = max(int(h / height), 1), max(int(w2 / w1), 1)

                elif n in ft.HORIZONTAL_TRIANGLE:
                    h1 = height * .5
                    h2 = h - h1
                    r, c = max(int(h2 / h1), 1), max(int(w / width), 1)

                elif n == sh.RHOMBUS_SHEAR:
                    w1, h1 = width * .5, height * .5
                    w2, h2 = w - w1, h - h1
                    r, c = max(int(h2 / h1), 1), max(int(w2 / w1), 1)
                elif n == sh.OCTAGON_DOUBLE_SHEAR:
                    w1 = width * sh.OCTAGON_RATIO
                    h1 = height * sh.OCTAGON_RATIO
                    w2, h2 = width - w1, height - h1
                    w3, h3 = w - w1, h - h1
                    r, c = max(int(h3 / h2), 1), max(int(w3 / w2), 1)
        return r, c

    def _calc_cell(self):
        """Calculate the cell sizes for the cell table."""
        e = self.d
        size = Hat.cat.render.size
        top, bottom, left, right = self.layer_margin
        o = One(grid=self, is_table=True, offset=(left, top))
        o.r, o.c = self.division
        o.layer_space = (
            Base.seal(size[0] - left - right, 1, size[0]),
            Base.seal(size[1] - top - bottom, 1, size[1])
        )

        # Transfer the table's preset dict to one:
        for k, a in e.items():
            k1 = k.lower().replace(" ", "_")
            setattr(o, k1, a)

        SHAPES[self.cell_shape](o)

    def _update_pocket(self, r, c, x, y, w, h):
        """
        Set the pocket rectangle and, if needed, update the shape.

        r, c: int
            cell index

        x, y: int
            the pocket's canvas coordinate
            the top-left corner of the pocket

        w, h: int
            pocket dimension
        """
        # a GridCell instance, 'a':
        a = self.table[r][c]

        b = a.pocket = Rect((x, y), (w, h))

        # Update the cell shape if the pocket size has changed:
        if (
            b.size != a.cell.size or
            b.position != a.cell.position
        ):
            n = self.cell_shape

            if n in ft.TRIANGLE:
                if Shape.is_inverse_triangle(r, c):
                    n = ft.INVERTED[n]
            a.shape = dispatch[n](b)

    def calc_pocket(self, o):
        """
        Calculate the cell pocket and update the shape.

        o: One
            d: dict, of margin preset with the per cell table
        """
        # Cell margin preset dict, 'd':
        d = o.d

        row, column = self.division
        s = Hat.cat.render.size
        q = []
        is_per_cell = True if d[ok.PER_CELL] else False

        if not is_per_cell:
            q = top, bottom, left, right = self.get_common_cell_size(d)[0]
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(self, r, c):
                    o.r, o.c = r, c
                    rect = self.get_merge_cell_rect(r, c)
                    x, y = rect.position
                    w, h = rect.size

                    if w:
                        if is_per_cell:
                            e = Form.get_form(o)
                            q = top, bottom, left, right = Form.combine_margin(
                                e,
                                w, h
                            )
                        if any(q):
                            x += left
                            y += top
                            x = Base.seal(x, 0, s[0] - 1)
                            y = Base.seal(y, 0, s[1] - 1)
                            w = max(w - left - right, 1)
                            h = max(h - top - bottom, 1)

                    # The pocket size will change if
                    # the cell shape is regular shaped:
                    if self.is_regular_shape:
                        x, y, w, h = Shape.bounds(
                            dispatch[self.cell_shape](Rect((x, y), (w, h)))
                        )
                    self._update_pocket(r, c, x, y, w, h)

    def clone(self):
        """
        Make a copy of the Grid instance.

        Return: Grid
            a copy
        """
        a = Grid(One())

        # Copy the attributes:
        Base.deep_update(a.__dict__, self.__dict__)
        return a

    @staticmethod
    def fix_tables(path, r, c):
        """
        Fix the scale of the per cell tables.
        A per cell widget has a its own per cell table.

        path: tuple
            with model

        r, c: int
            cell index
        """
        # Update the per cell tables:
        prefix = path[:3]
        for i in og.PER_CELL_DEPENDENT:
            fix_table(prefix, r, c, i)

    def get_cell_block(self, u, v):
        """
        Use when cells are merged, and the merge
        cell's dimension needs to be determined.

        u: tuple
            (r, c) of int
            topleft cell

        v: tuple
            (r, c) of int
            bottom-right cell

        Return the topleft coordinates and the scale of an array of cells.
        """
        r1, c1 = u
        x, y = self.get_cell_rect(r1, c1).position
        rect = self.get_cell_rect(v[0], v[1])
        x1, y1 = rect.position
        w, h = rect.size
        w = x1 - x + w
        h = y1 - y + h
        return x, y, w, h

    def get_common_cell_size(self, d):
        """
        Get the cell size for margin calculations.

        d: dict
            of cell margin, chunk

        Return: tuple
            (cell margins, cell size)
        """
        r = c = 0

        if self.cell_shape in sh.DOUBLE:
            if self.d[ok.CELL_SHIFT]:
                c = 1
                if self.division[1] == 1:
                    if self.division[0] == 1:
                        # There is only one cell, and it isn't allocated:
                        c = -1
                    else:
                        r, c = 1, 0

        if c > -1:
            rect = self.get_merge_cell_rect(r, c)
            w, h = rect.size
            q = Form.combine_margin(d, w, h)

        else:
            # Invalid margins:
            q = -1, -1, -1, -1
            w = h = 0
        return q, (w, h)

    def update_cell_block(self, u, v):
        """
        Update the merge cell size for a cell block.

        u: tuple
            cell index of the topleft cell of the block

        v: tuple
            cell index of the bottom-right cell of the block
        """
        x, y, w, h = self.get_cell_block(u, v)
        a = self.table[u[0]][u[1]]
        b = a.merge_cell = Rect((x, y), (w, h))
        a.shape = a.plaque = dispatch[self.cell_shape](b)

    def update_grid(self, o):
        """
        Update the grid from the grid preset.

        o: One
            d: dict, grid preset, chunk-type
        """
        def get_cell_shape():
            """
            Get the cell shape according the cell type.

            Return: string
                cell shape descriptor
            """
            if d[ok.GRID_TYPE] == gr.SHAPE_COUNT:
                return d[ok.CELL_SHAPE_NORMAL]
            return d[ok.CELL_SHAPE]

        def get_double_type():
            """
            Get the double type of the grid's cell table.

            Return: enum
                of double-type
            """
            if self.cell_shape in sh.DOUBLE:
                if self.d[ok.CELL_SHIFT]:
                    return sh.SHIFT
                else:
                    return sh.NOT_SHIFT
            return sh.NOT_DOUBLE_SPACE

        def merge_cell():
            """
            Determine if the grid is in merge cell mode.

            Return: bool
                Is true if the grid dict is in merge cell mode.
            """
            if self.is_rectangle:
                return True if ok.PER_CELL in d and d[ok.PER_CELL] else False
            return False

        # Grid preset dict, 'd':
        d = self.d = o.d

        self.cell_shape = get_cell_shape()
        self.is_rectangle = self.cell_shape == sh.RECTANGLE
        self.is_regular_shape = self.get_normal_type()
        self.is_not_rectangular = not Shape.is_rectangular_shape(
            self.cell_shape
        )

        self.is_merge_cell = merge_cell()
        self.double_type = get_double_type()
        r, c = self.division = self._calc_grid_division()
        table = self.table = Base.make_2d_table(r, c)

        Grid.fix_tables(self.path, r, c)

        # The per cell table was changed by 'fix_tables':
        self.d[ok.PER_CELL] = Path.get_grid_from_path(self.path)[ok.PER_CELL]

        for i in range(r):
            for j in range(c):
                if Shape.is_allocated_cell(self, i, j):
                    table[i][j] = GridCell(i, j)

        self._calc_cell()

        # merge cell rectangle:
        for i in range(r):
            for j in range(c):
                # cell, 'a':
                a = table[i][j]

                # If merging cells:
                if self.is_merge_cell:
                    # 's', the size of the cell in cells:
                    s = self.d[ok.PER_CELL][i][j]

                    # Sub-topleft cells are unavailable:
                    if s == (-1, -1):
                        # If the cell has a width of zero,
                        # then the cell is not an image cell:
                        x = y = w = h = 0

                    elif s == (1, 1):
                        rect = self.get_cell_rect(i, j)
                        x, y = rect.position
                        w, h = rect.size
                    else:
                        s1 = i + s[0] - 1, j + s[1] - 1
                        x, y, w, h = self.get_cell_block((i, j), s1)
                        a.plaque = dispatch[self.cell_shape](
                            Rect((x, y), (w, h))
                        )
                else:
                    if Shape.is_allocated_cell(self, i, j):
                        rect = a.cell
                        x, y = rect.position
                        w, h = rect.size
                    else:
                        # 'x' is set to flag an unallocated cell:
                        x = -1
                if x > -1:
                    a.merge_cell = Rect((x, y), (w, h))

    def update_rect_shape(self, o):
        """
        Calculate the rectangle for clipping a Fringe layer.
        Prepare a rectangle polygon, 'rect_shape', with x, y points.

        o: One
            d: dict
                of Layer/Fringe preset
        """
        x = y = 0
        s = w, h = Hat.cat.render.size

        if o.d[ok.OBEY_MARGINS]:
            x, bottom, left, right = Path.get_layer_margin(self.path)
            y = s[1] - bottom
            w = s[0] - left - right
            h = s[1] - x - bottom

        x1, y1 = x + w, y + h
        self.rect_shape = x, y, x1, y, x1, y1, x, y1


class Stack(Model):
    """Use with the stack model for its cell definitions."""

    def __init__(self, o):
        """
        Initialize variables used for rendering. Create a table
        of cells. A stack has one column and one or more rows.

        o: One
            'd': dict
                the Stack Property preset
        """
        Model.__init__(self, o)

        self.cell_count = 1
        self.cell_shape = self.image_group_type = None
        self.is_rectangle = None

        # Use with plaque and fringe and their obey margins option.
        # Provide the plaque shape for the selected option:
        self.plaque_shape = self.plaque_pocket = None

    def _calc_cell(self):
        """Calculate the cell sizes for the cell table."""
        self.rect_shape = dispatch[self.cell_shape](self.rect)
        for r in range(0, self.division[0]):
            a = self.table[r][0]
            a.cell = self.rect.clone()
            a.shape = a.plaque = self.rect_shape

    def calc_pocket(self, o):
        """
        Calculate cell rectangle, pocket, plaque, and shape.

        o: One
            d: dict, cell pocket preset
        """
        c = 0
        row = self.division[0]
        q = top, bottom, left, right = self.get_common_margin(o.d)
        x, y = self.rect.position
        w, h = self.rect.size

        if w and any(q):
            x += left
            y += top
            w = max(w - left - right, 1)
            h = max(h - top - bottom, 1)

        a = Rect((x, y), (w, h))

        self.plaque_pocket = a
        self.plaque_shape = dispatch[self.cell_shape](a)

        # The pocket size will change if the cell shape is normalized:
        if self.is_regular_shape:
            x, y, w, h = Shape.bounds(self.plaque_shape)
        for r in range(row):
            self.update_pocket(r, c, x, y, w, h)

    def clone(self):
        """
        Make a copy of this Stack instance.

        Return: Stack
            a copy
        """
        a = Stack(One())

        # Copy the attributes:
        Base.deep_update(a.__dict__, self.__dict__)
        return a

    @staticmethod
    def fix_tables(path, r, _):
        """
        Fix the scale of the per cell tables.
        A per cell widget has a its own per cell table.

        path: tuple
            with model

        r, _: int
            cell index; c = 1
        """
        q = path[:3]
        for i in (gk.PER_CELL_IMAGE_PLACE, gk.PER_CELL_IMAGE_MASK):
            path = q + og.PER_CELL_DEPENDENT[i]
            g = Hat.cat.group_dict[path].vbox.per_cell_group
            if g.check_button.get_value():
                d = Path.get_dict_from_path(path)
                table = d[ok.PER_CELL]

                d.pop(ok.PER_CELL)

                table = fix_cell_table_size(table, r, 1, d)
                g.set_value(table)

    def update_cell_rect(self, o):
        """
        Update the stack's cell rectangle.

        o: One
            d: dict, rectangle preset
        """
        self.update_rectangle(o)

        r = self.division[0]

        for i in range(r):
            self.table[i][0] = GridCell(i, 0)

        self._calc_cell()

        # The merge cell rectangle is the same as the cell rectangle:
        for i in range(r):
            self.table[i][0].merge_cell = self.table[i][0].cell.clone()

    def update_pile(self, o):
        """
        Update the Stack model's attributes from the Pile dict preset.

        o: One
            d: dict, pile preset
        """
        # Pile preset dict, 'd':
        d = self.d = o.d

        r = self.cell_count = d[ok.CELL_COUNT]
        self.cell_shape = d[ok.CUSTOM_CELL_SHAPE]
        self.is_rectangle = self.cell_shape == sh.RECTANGLE
        self.is_regular_shape = self.get_normal_type()
        self.is_not_rectangular = not Shape.is_rectangular_shape(
            self.cell_shape
        )
        self.division = r, 1
        self.image_group_type = d[ok.IMAGE_GROUP_TYPE]
        self.add_shift_x = d[ok.ADDING_SHIFT_X]
        self.add_shift_y = d[ok.ADDING_SHIFT_Y]
        self.add_shift_rotate = d[ok.ADDING_SHIFT_ROTATE]
        self.add_shift_w = d[ok.ADDING_SHIFT_W]
        self.add_shift_h = d[ok.ADDING_SHIFT_H]
        self.table = Base.make_2d_table(r, 1)
        Stack.fix_tables(self.path, r, 1)
