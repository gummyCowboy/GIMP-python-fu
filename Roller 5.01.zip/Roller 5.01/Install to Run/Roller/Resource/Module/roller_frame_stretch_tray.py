#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import MetalAltFiller
from roller_fu import (
    apply_mask,
    clone_layer,
    clone_opaque_layer,
    make_layer_group,
    merge_layer,
    merge_layer_group,
    remove_z,
    set_saturation
)
from roller_one_gegl import emboss
from roller_view_real import clip_to_wip, get_light, mask_sub_maya
import gimpfu as fu

pdb = fu.pdb


def do_filler(v, maya):
    """
    Draw filler layer.

    v: View
    maya: StretchTray
    Return: layer
        with filler material
    """
    j = v.j

    # source layer, 'z'
    z = clone_opaque_layer(maya.cause.matter, n="Left")

    if (
        z.width != v.wip.w or
        z.height != v.wip.h or
        z.offsets != v.wip.position
    ):
        clip_to_wip(v, z)

    if z.mask:
        apply_mask(z)

    group = make_layer_group(
        j, "Stretch", parent=maya.group, z=z, offset=get_light(maya)
    )

    apply_mask(z)
    pdb.gimp_selection_none(j)

    for x, z1 in enumerate((
        z,
        clone_layer(z, n="Right"),
        clone_layer(z, n="Top"),
        clone_layer(z, n="Bottom")
    )):
        pdb.plug_in_wind(
            j, z1,
            .0,                 # Threshold All
            x,                  # direction
            100,                # maximum strength
            0,                  # wind algorithm
            1,                  # leading edge
        )

        # threshold all pixel, '.0'
        pdb.plug_in_threshold_alpha(j, z1, .0)

    # Make the wind output opaque.
    z1 = merge_layer_group(group)
    z = clone_opaque_layer(z1)

    remove_z(z1)
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .25, 1., .75)
    )
    set_saturation(z, maya.value_d[ok.SATURATION])

    z1 = clone_layer(z, n="Hard Light")
    z1.mode = fu.LAYER_MODE_HARDLIGHT
    z1.opacity = 80.

    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .45, 1., .54)
    )

    # depth, '3'
    emboss(z, v.glow_ball.azimuth, v.glow_ball.elevation, 3)

    z = merge_layer(z1)
    z.name = z.parent.name + " Filler"

    mask_sub_maya(maya.super_maya.matter, z)
    return z


class StretchTray(MetalAltFiller):
    """
    Make a frame by stretching cause material horizontally and vertically.
    """

    def __init__(self, any_group, super_maya, k_path):
        MetalAltFiller.__init__(
            self, any_group, super_maya, k_path, do_filler, ok.FILLER_ST
        )
