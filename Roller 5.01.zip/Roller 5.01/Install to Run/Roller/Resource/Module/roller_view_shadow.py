#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok, Step as sk
from roller_fu import (
    add_layer,
    clone_layer,
    get_layer_offset,
    invert_selection,
    make_layer_group,
    select_item,
    verify_layer,
    verify_layer_group
)
from roller_view_real import clip_to_wip, get_light
import gimpfu as fu

pdb = fu.pdb


def do_shadow_preset(v, d, outer_cast_q, inner_cast_z, parent):
    """
    Make up to three shadow layers.

    v: View
    d: dict
        Shadow SuperPreset

    outer_cast_q: tuple
        of layers to pass to Shadow #1 and Shadow #2

    inner_cast_z: layer
        cast an inner shadow

    parent: layer group
        Where the shadow layer is placed.
    """
    make_shadow(
        v,
        d[sk.SHADOW_1],
        parent,
        outer_cast_q,
        name=parent.name + " Shadow 1"
    )
    make_shadow(
        v,
        d[sk.SHADOW_2],
        parent,
        outer_cast_q,
        name=parent.name + " Shadow 2"
    )
    make_inner_shadow(
        v,
        d[sk.INNER_SHADOW],
        inner_cast_z,
        name=parent.name + " Inner Shadow"
    )


def make_shadow(v, d, parent, cast_q, name=None, is_wrap=False):
    """
    Make a shadow.

    v: View
    d: dict
        Shadow Preset
        {Option key: value}

    parent: layer group
        Has name and position.

    cast_q: tuple or list
        of layer to cast shadow

    name: string or None
        Use to name the output layer.

    is_wrap: bool
        If True, an outer Shadow is placed at the bottom of the parent group.

    Return: layer
        with shadow
    """
    intensity = d[ok.INTENSITY]
    if cast_q and intensity:
        j = v.j
        group = make_layer_group(j, "Shadow")
        base_z = add_layer(j, 'Temp', parent=group)

        pdb.gimp_selection_none(j)

        for z in cast_q:
            select_item(z, option=fu.CHANNEL_OP_ADD)

        if not pdb.gimp_selection_is_empty(j):
            layer_count = intensity // 100.
            intensity /= (layer_count + 1.)

            # base layer for shadow output, 'z1'
            # Make shadow from selection.
            pdb.script_fu_drop_shadow(
                j, base_z,
                d[ok.OFFSET_X], d[ok.OFFSET_Y],
                d[ok.BLUR],
                d[ok.SHADOW_COLOR],
                intensity,
                0                       # no resizing
            )

            # Increase shadow intensity by
            # stacking duplicate shadow layers.
            z = group.layers[0]
            for i in range(int(layer_count)):
                z = clone_layer(z)

        pdb.gimp_selection_none(j)

        z = verify_layer_group(group)

        if z:
            if is_wrap:
                a = len(parent.layers)

            else:
                # Put the shadow layer below the lowest shadow caster.
                a = 0
                for i in cast_q:
                    b = get_layer_offset(i) + 1
                    if b > a:
                        a = b
            pdb.gimp_image_reorder_item(j, z, parent, a)

            if name is not None:
                z.name = name
            clip_to_wip(v, z)
        return z


def make_inner_shadow(v, d, cast_z, name=None):
    """
    Make an inner shadow.

    v: View
    d: dict
        Shadow Preset
        {Option key: value}

    cast_z: layer
        to cast shadow

    name: string or None
        Use to name the output layer.

    offset_z: layer
        layer with offset for the shadow layer insertion

    Return: layer
        with shadow
    """
    intensity = d[ok.INTENSITY]

    if cast_z and intensity:
        j = v.j
        group = make_layer_group(j, "Shadow")
        base_z = add_layer(j, 'Temp', parent=group)

        select_item(cast_z)
        invert_selection(j)

        if not pdb.gimp_selection_is_empty(j):
            layer_count = intensity // 100.
            intensity /= (layer_count + 1.)

            # base layer for shadow output, 'z1'
            # Make shadow from selection.
            pdb.script_fu_drop_shadow(
                j, base_z,
                d[ok.OFFSET_X], d[ok.OFFSET_Y],
                d[ok.BLUR],
                d[ok.SHADOW_COLOR],
                intensity,
                0                       # no resizing
            )

            # Increase shadow intensity by
            # stacking duplicate shadow layers.
            z = group.layers[0]
            for i in range(int(layer_count)):
                z = clone_layer(z)

        pdb.gimp_image_remove_layer(j, base_z)
        pdb.gimp_selection_none(j)

        z = verify_layer(pdb.gimp_image_merge_layer_group(j, group))

        if z:
            a = get_layer_offset(cast_z)

            pdb.gimp_image_reorder_item(j, z, cast_z.parent, a)

            if name is not None:
                z.name = name
            clip_to_wip(v, z)
        return z
