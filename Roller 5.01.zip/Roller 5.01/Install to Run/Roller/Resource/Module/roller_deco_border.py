#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    finish_backed,
    make_deco_material,
    prep_backed,
    produce_main_facing,
    produce_per_facing,
    ready_canvas_rect,
    ready_shape,
    test_image,
    transform_foam
)
from roller_fu import (
    blur_selection,
    clear_inverse_selection,
    load_selection,
    select_polygon,
    select_rect,
    shrink_selection,
    verify_layer_group
)
from roller_view_real import make_group
import gimpfu as fu

PLAN_COLOR_D = {
    ny.CELL: fy.CELL_BORDER_COLOR,
    ny.CANVAS: fy.CANVAS_BORDER_COLOR,
    ny.FACE: fy.FACE_BORDER_COLOR,
    ny.FACING: fy.FACING_BORDER_COLOR
}
pdb = fu.pdb


def do(v, maya, make):
    """
    Process the Border matter. If Plan is active,
    temporarily override Preset option with Plan setting.

    v: View
    maya: Maya
    make: function
        Call to make Border material.

    Return: layer or None
        with Border material
    """
    d = maya.value_d

    if not v.x:
        # Preserve.
        type_ = d[ok.TYPE]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = PLAN_COLOR_D[maya.any_group.render_key[-2]]

    v.deco.type_ = d[ok.TYPE]
    z = make(v, maya)

    if z and d[ok.SOFTEN]:
        pdb.gimp_selection_all(v.j)
        blur_selection(z, d[ok.SOFTEN])

    if not v.x:
        # Restore.
        d[ok.TYPE] = type_
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(v, maya):
    """
    Make Canvas Border.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_canvas)


def do_cell(v, maya):
    """
    Draw cell material.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell)


def do_face(v, maya):
    """
    Draw Face Border material for a cell.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_face)


def do_facing(v, maya):
    """
    Draw Facing Border material for a cell.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_facing)


def do_main_cell(v, maya):
    """
    Draw cell material for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main)


def do_main_face(v, maya):
    """
    Draw Face material for its main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_face)


def do_main_facing(v, maya):
    """
    Draw Facing material for its main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_facing)


def make_canvas(v, maya):
    """
    Draw Canvas Border material.

    v: View
    maya: Maya
    Return: layer or None
        with Border material
    """
    d = maya.value_d
    if test_image(v, maya):
        prep_backed(v, maya, maya.group)
        ready_canvas_rect(v, maya, option=None)

        j = v.j
        x, y, w, h = maya.rect
        border_w = d[ok.BORDER_W]
        w1 = border_w * 2.

        select_rect(j, *maya.rect)

        # Cut out an interior rectangle.
        select_rect(
            j,
            x + border_w, y + border_w,
            max(1., w - w1), max(1., h - w1),
            option=fu.CHANNEL_OP_SUBTRACT
        )

        z = make_deco_material(v, maya, maya.group)

        finish_backed(v)
        return z


def make_cell_face(v, maya):
    """
    Make Face Border material for one cell.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_per_facing(v, maya, make_face)


def make_cell_facing(v, maya):
    """
    Make Facing Border material for one cell.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_per_facing(v, maya, make_facing)


def make_cell(v, maya):
    """
    Make Border material for a cell.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    if test_image(v, maya):
        prep_backed(v, maya, maya.group)
        ready_shape(v, maya)
        select_border(v, maya.value_d)

        z = make_deco_material(v, maya, maya.group)

        finish_backed(v)
        return z


def make_face(v, maya, group):
    """
    Process Face Border for a cell.

    v: View
    maya: Maya
    group: layer
        Is the parent of Face output.
    """
    j = v.j
    model = maya.model
    k = maya.k
    go = test_image(v, maya)
    if go:
        maya.rect = model.get_facing_rect(k)
        v.deco.shape = model.get_facing_form(k)

        select_rect(j, *maya.rect)
        select_border(v, maya.value_d)

        z = make_deco_material(v, maya, group)
        if z:
            transform_foam(v, maya.rect, z, model.get_facing_foam(k))


def make_facing(v, maya, group):
    """
    Process Facing Border for a cell.

    v: View
    maya: Maya
    group: layer
        Is the parent of Face output.
    """
    j = v.j
    model = maya.model
    k = maya.k
    is_color = False
    go = test_image(v, maya)

    if go:
        if v.deco.type_ in (dc.AVERAGE_COLOR, dc.COLOR):
            is_color = True

        maya.rect = model.get_facing_rect(k)
        shape = model.get_facing_shape(k)

        if is_color:
            v.deco.shape = shape
            select_polygon(j, v.deco.shape)
            select_border(v, maya.value_d)

        else:
            v.deco.shape = model.get_facing_form(k)
            select_rect(j, *maya.rect)

        z = make_deco_material(v, maya, group)
        if z and not is_color:
            z = transform_foam(v, maya.rect, z, model.get_facing_foam(k))

            model.clip_facing(z, k)
            select_polygon(j, shape)
            select_border(v, maya.value_d)
            clear_inverse_selection(z)


def make_main(v, maya):
    """
    Make Border material for the main option settings.
    Multiple Cell Border is combined into one layer.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    def _do_average_color():
        """
        The output is on one layer.

        Return: layer or None
            with material
        """
        _parent = maya.group
        _group = make_group(v, "Material", _parent, offset=len(_parent.layers))

        prep_backed(v, maya, _group)

        for _k in maya.main_q:
            maya.k = _k

            ready_shape(v, maya)
            select_border(v, maya.value_d)
            make_deco_material(v, maya, _group)

        finish_backed(v)
        return verify_layer_group(_group)

    def _do_many_material():
        """
        The cells have the same Border type, but
        the material is applied cell-by-cell.
        """
        _parent = maya.group
        _group = make_group(v, "Material", _parent, offset=len(_parent.layers))

        for _k in maya.main_q:
            maya.k = _k
            if test_image(v, maya):
                ready_shape(v, maya)
                select_border(v, maya.value_d)
                make_deco_material(v, maya, _group)
        return verify_layer_group(_group)

    def _do_one_material():
        """
        The cells have the same Border material,
        so there selection is combined.
        """
        _sel = None
        _d = maya.value_d

        prep_backed(v, maya, maya.group)
        pdb.gimp_selection_none(j)

        for _k in maya.main_q:
            maya.k = _k

            ready_shape(v, maya)
            select_border(v, _d)

            if _sel:
                load_selection(j, _sel, option=fu.CHANNEL_OP_ADD)
                pdb.gimp_image_remove_channel(j, _sel)
            _sel = pdb.gimp_selection_save(j)

        if _sel:
            pdb.gimp_image_remove_channel(j, _sel)

        _z = make_deco_material(v, maya, maya.group)

        finish_backed(v)
        return _z

    j = v.j

    if v.deco.type_ == dc.AVERAGE_COLOR:
        return _do_average_color()

    elif v.deco.type_ not in dc.PER_TYPE:
        # All the Border is the same
        # material and is applied one time.
        return _do_one_material()
    else:
        # All the Border is the same material
        # and is applied cell-by-cell.
        return _do_many_material()


def make_main_face(v, maya):
    """
    Each Face in the grid uses the main option settings.
    The output is a single layer.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_main_facing(v, maya, make_face)


def make_main_facing(v, maya):
    """
    Each Face in the grid uses the main option settings.
    The output is a single layer.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_main_facing(v, maya, make_facing)


def select_border(v, d):
    """
    Make a Border selection for a cell. Requires a selection at start.

    v: View
    d: dict
        Border Preset

    Return: state of selection
    """
    j = v.j
    sel = pdb.gimp_selection_save(j)

    shrink_selection(j, d[ok.BORDER_W])
    if not pdb.gimp_selection_is_empty(j):
        # inner polygon cut-out selection, 'inner_cut'
        inner_cut = pdb.gimp_selection_save(j)

        load_selection(j, sel)
        load_selection(j, inner_cut, option=fu.CHANNEL_OP_SUBTRACT)
        pdb.gimp_image_remove_channel(j, sel)
        pdb.gimp_image_remove_channel(j, inner_cut)
