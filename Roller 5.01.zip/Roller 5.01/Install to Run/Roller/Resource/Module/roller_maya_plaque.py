#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy, Signal as si
from roller_constant_key import Node as ny, Option as ok, Plan as ak
from roller_deco import make_deco_mask
from roller_deco_plaque import (
    do_canvas,
    do_main_cell,
    do_main_face,
    do_main_facing,
    do_cell,
    do_face,
    do_facing,
    i_make_main_face_mask,
    i_make_main_facing_mask,
    i_make_cell_face_mask,
    i_make_cell_facing_mask,
    mask_main_cell
)
from roller_maya import (
    MAIN,
    PER,
    CanvasRoute,
    CellRoute,
    FaceRoute,
    Plasma,
    assign_deco_image,
    assign_frame_image,
    assign_mask_image,
    check_matter,
    check_mix_basic,
    take_type_vote
)
from roller_maya_blur_behind import BlurBehind
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_maya_mask import Mask
from roller_option_group import DecoGroup
from roller_view_option_list import Frame
from roller_view_real import LIGHT, make_canvas_group, make_cast_group
from roller_view_step import get_planner


def assign_canvas_image(v, maya):
    """
    Assign image and mask image for the Canvas branch.

    v: View
    d: dict
        Plaque Preset
        {Option key: value}
    """
    d = maya.value_d
    j = assign_deco_image(v, d)
    j1 = assign_mask_image(v, d[ok.MRW][ok.MASK])

    if j != maya.get_image(None) or j1 != maya.get_mask_image(None):
        maya.is_matter = True

    maya.set_image(None, j)
    maya.set_mask_image(None, j1)


def assign_image(v, maya, p, q):
    """
    Assign image and mask image for Cell and Facing Maya.

    v: View
    maya: Maya
    p: function
        Call to assign image.

    q: list
        [(r, c) or (r, c, x)]
    """
    d = maya.value_d
    d_q = d, d[ok.MRW][ok.MASK]
    per = d[ok.PER]
    per_d = maya.per_d
    for k in q:
        if k in per:
            e = per[k]
            e1 = e[ok.MRW][ok.MASK]
            this_maya = per_d[k]

        else:
            e, e1 = d_q
            this_maya = maya

        image, mask, frame = p(v, e, e1)

        # Determine if an image reference changed.
        if image != this_maya.get_image(k):
            this_maya.is_matter = True

        if mask != this_maya.get_mask_image(k):
            this_maya.sub_maya[ok.MASK].is_matter = True

        if frame != this_maya.get_frame_image(k):
            this_maya.sub_maya[ok.FRAME].is_matter = True

        # Store image reference.
        this_maya.set_image(k, image)
        this_maya.set_mask_image(k, mask)
        this_maya.set_frame_image(k, frame)


def assign_per_image(v, maya, q):
    """
    Assign image for the Cell branch.

    v: View
    maya: Maya
    """
    def _assign(_v, _d, _e):
        """
        _v: View
        _d: dict
            Plaque Preset
            {Option key: value}

        _e: dict
            Mask Preset
            {Option key: value}

        Return: tuple
            (Image, Mask Image)
            either could be None
        """
        return (
            assign_deco_image(_v, _d),
            assign_mask_image(_v, _e) if _d[ok.SWITCH] else None,
            assign_frame_image(_v, _d[ok.FRW][ok.FRAME], False)
            if _d[ok.SWITCH] else None
        )
    assign_image(v, maya, _assign, q)


class Plaque(DecoGroup):
    """Assign Plan and Work delegates for View run processing."""

    def __init__(self, **d):
        DecoGroup.__init__(self, **d)

        node_k = self.nav_k[-2]
        self.plan = {
            ny.CANVAS: PlanCanvas,
            ny.CELL: PlanCell,
            ny.FACE: PlanFace,
            ny.FACING: PlanFacing
        }[node_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas,
            ny.CELL: WorkCell,
            ny.FACE: WorkFace,
            ny.FACING: WorkFacing
        }[node_k](self)
        baby = self.item.model.baby
        if node_k in (ny.FACE, ny.FACING):
            # Face has no Margin to receive update from Shift. Thus
            # Plaque receive update directly from Shift instead of Margin.
            self.handle_d[
                baby.connect(si.CELL_SHIFT_CALC, self.on_cell_calc)
            ] = baby


class Chi(Plasma):
    """Factor Plan and Work layer output."""

    def __init__(self, any_group, view_x, q, make_mask, get_mask_d):
        """
        view_x: int
            0 or 1; Plan or Work

        mask_mask: function
            Call to make mask.

        q: iterable
            of function for producing View output

        get_mask_d: function
            Call to retrieve the Mask Preset.
        """
        Plasma.__init__(
            self, any_group, view_x, q, k_path=[(), (ok.IMAGE_CHOICE,)]
        )

        self.sub_maya[ok.MASK] = Mask(
            any_group, self, view_x, make_mask, get_mask_d, (ok.MRW, ok.MASK)
        )
        self.set_issue()


class Plan(Chi):
    """Manage Plan Plaque output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, make_mask, get_mask_d):
        """
        any_group: AnyGroup
        make_mask: function
            Call to make a Mask for the matter layer.

        get_mask_d: function
            Call to retrieve the Mask Preset.
        """
        Chi.__init__(self, any_group, 0, self.put, make_mask, get_mask_d)

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.PLAQUE)
        self.handle_d[
            planner.connect(fy.SIGNAL_D[ak.PLAQUE], self.on_plan_option_change)
        ] = planner

    def bore(self, v):
        """
        Manage layer output for a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned
        self.is_matter |= self.is_switched

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)
            self.sub_maya[ok.MASK].do(v, d[ok.MRW][ok.MASK])

    def on_plan_option_change(self, _, arg):
        """
        Respond to change from Planner's Plaque option.

        arg: tuple
            (bool, bool)
            (
                Is True if the Plaque option is checked in Planner.,
                Is True if the Plaque option in Planner changed.
            )
        """
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage Plaque for Peek, Preview and final output."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, make_mask, get_mask_d):
        """
        any_group: AnyGroup
            owner

        make_mask: function
            Call to make Mask output.

        get_mask_d: function
            Call to retrieve the Mask Preset.
        """
        Chi.__init__(self, any_group, 1, self.put, make_mask, get_mask_d)

        self.sub_maya[ok.FRAME] = Frame(any_group, self, (ok.FRW, ok.FRAME))
        self.sub_maya[ok.BUMP] = Bump(any_group, self, (ok.MRW, ok.BUMP))
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(any_group, self, (), ok.FRW)
        self.sub_maya[LIGHT] = Light(any_group, self, ok.PLAQUE)
        self.handle_d[
            self.any_group.connect(si.BACK_CHANGE, self.on_back_change)
        ] = self.any_group

    def bore(self, v):
        """
        Produce layer output during a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH]
        is_back = v.is_back

        if self.go:
            self.is_matter |= take_type_vote(v, d)

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)
            is_change = self.is_matter or self.sub_maya[ok.MASK].is_matter

            self.sub_maya[ok.MASK].do(v, d[ok.MRW][ok.MASK])
            self.sub_maya[ok.BUMP].do(v, d[ok.MRW][ok.BUMP], is_change)

            if not self.is_face:
                is_back |= self.sub_maya[ok.FRAME].do(
                    v, d[ok.FRW][ok.FRAME], is_change
                )

            self.sub_maya[ok.BLUR_BEHIND].do(
                v, d[ok.FRW][ok.BLUR_BEHIND], is_back, is_change
            )
            self.sub_maya[LIGHT].do(v, is_change)
            v.is_back = is_back


class Main:
    """Is for main option settings found in the MainWindow."""
    vote_type = MAIN

    def __init__(self):
        return

    def get_mask_d(self):
        return self.any_group.value_d[ok.MRW][ok.MASK]


class WorkMain(Main, Work):
    """Is factored from Main and Work."""

    def __init__(self, *arg):
        """
        arg: tuple
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *arg + (self.get_mask_d,))


# Canvas_______________________________________________________________________
class Cloth:
    """Is factored from Plan and Work Canvas."""

    def __init__(self):
        self.do_matter = do_canvas

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_canvas_image(v, self)


class PlanCanvas(Cloth, Main, Plan, CanvasRoute):
    """Manage Plan Plaque output for the Canvas branch."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Cloth.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, make_deco_mask, self.get_mask_d)
        CanvasRoute.__init__(self)


class WorkCanvas(Cloth, WorkMain, CanvasRoute):
    """Manage Work Plaque output for the Canvas branch."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's option group
        """
        Cloth.__init__(self)
        WorkMain.__init__(self, any_group, make_deco_mask)
        CanvasRoute.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:
    """Is factored from Plan and Work Cell."""
    is_face = False

    def __init__(self):
        self.do_matter = do_main_cell

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_per_image(v, self, self.model.cell_q)


class PlanCell(Main, Plan, CellRoute, Cellular):
    """Manage Plan Plaque output for the Cell-branch."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Main.__init__(self)
        Plan.__init__(self, any_group, mask_main_cell, self.get_mask_d)
        CellRoute.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, CellRoute, Cellular):
    """Manage Work Plaque output for the Cell-branch."""
    issue_q = 'matter', 'mode', 'opacity', 'per', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        WorkMain.__init__(self, any_group, mask_main_cell)
        CellRoute.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per__________________________________________________________________________
class Per:
    """Is factored from Plan and Work Per Cell."""
    vote_type = PER

    def __init__(self, do_matter, k):
        self.do_matter = do_matter
        self.k = k

    def get_mask_d(self):
        d = self.per_group.get_cell_value(self.k)
        if d:
            return d[ok.MRW][ok.MASK]


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Plan Plaque output for a Per Cell Preset."""
    is_face = False
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group, make_deco_mask, self.get_mask_d)
        Per.__init__(self, do_cell, k)


class WorkCellPer(Work, Per):
    """Manage Work Plaque output for a Cell/Per Preset."""
    is_face = False
    issue_q = 'matter', 'mode', 'opacity', 'shade'

    def __init__(self, any_group, k):
        """
        Create a Maya for Per Cell.

        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group, make_deco_mask, self.get_mask_d)
        Per.__init__(self, do_cell, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    """Is factored from Plan and Work Face."""
    is_face = True

    def __init__(self):
        self.do_matter = do_main_face

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_per_image(v, self, self.model.face_q)


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage Plan Plaque output for the Face branch."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, i_make_main_face_mask, self.get_mask_d)
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, FaceRoute):
    """Manage Work Plaque output for the Face branch."""
    issue_q = 'matter', 'mode', 'opacity', 'per', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Face.__init__(self)
        WorkMain.__init__(self, any_group, i_make_main_face_mask)
        FaceRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per_____________________________________________________________________
class FacePer(Per):
    """Is factored from Plan and Work Face/Per."""
    is_face = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacePer(Plan, FacePer):
    """Manage Plan Plaque output for a Face/Per Preset."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c, x);
            of int; Goo key
        """
        Plan.__init__(self, any_group, i_make_cell_face_mask, self.get_mask_d)
        FacePer.__init__(self, do_face, k)


class WorkFacePer(Work, FacePer):
    """Manage Work Plaque output for a Face/Per Preset."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int; Goo key
        """
        Work.__init__(self, any_group, i_make_cell_face_mask, self.get_mask_d)
        FacePer.__init__(self, do_face, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing_______________________________________________________________________
class Facing:
    """Is factored from Plan and Work Facing."""
    is_face = False

    def __init__(self):
        self.do_matter = do_main_facing

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_per_image(v, self, self.model.face_q)


class PlanFacing(Facing, Main, Plan, FaceRoute):
    """Manage Plan Plaque output for the Facing branch."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Facing.__init__(self)
        Main.__init__(self)
        Plan.__init__(
            self, any_group, i_make_main_facing_mask, self.get_mask_d
        )
        FaceRoute.__init__(self, PlanFacingPer)


class WorkFacing(Facing, WorkMain, FaceRoute):
    """Manage Work Plaque output for the Facing branch."""
    issue_q = 'matter', 'mode', 'opacity', 'per', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Facing.__init__(self)
        WorkMain.__init__(self, any_group, i_make_main_facing_mask)
        FaceRoute.__init__(self, WorkFacingPer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing Per Cell______________________________________________________________
class FacingPer(Per):
    """Is factored from Plan and Work Facing/Per."""
    is_face = False

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacingPer(Plan, FacingPer):
    """Manage Plan Plaque output for a Facing/Per Preset."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group, i_make_cell_facing_mask, self.get_mask_d)
        FacingPer.__init__(self, do_facing, k)


class WorkFacingPer(Work, FacingPer):
    """Manage Work Plaque output for a Facing/Per Preset."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'

    def __init__(self, any_group, k):
        """
        k: tuple
            Goo key
        """
        Work.__init__(self, any_group, i_make_cell_facing_mask, self.get_mask_d)
        FacingPer.__init__(self, do_facing, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
