#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr
from roller_model_goo import Goo
from roller_one_rect import Rect
from roller_polygon import calc_pin_xy


class GridRect:
    """
    Calculate the position and the size of
    cell. Each cell is rectangular shaped.
    """

    @staticmethod
    def calc(model, o):
        """
        Calculate a Model's cell rectangle, merge rectangle, and form polygon.

        model: Model
        o: One
            with Cell Type reference

        Return: dict
            {(row, column0): [Plan vote, Work vote]}
        """
        vote_d = {}
        did_cell = model.past.did_cell
        row, column = model.division
        goo_d = model.goo_d
        x, y, canvas_w, canvas_h = model.canvas_pocket.rect

        if o.grid_type == gr.CELL_SIZE:
            # Correct cell size overflow.
            w = min(canvas_w, o.column_width)
            h = min(canvas_h, o.row_height)
            s = w * column, h * row
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

        elif o.grid_type == gr.SHAPE_COUNT:
            w = canvas_w / column
            h = canvas_h / row
            w = min(w, h)
            s = w * column, w * row
            w, h = w, w
            x, y = calc_pin_xy(o.pin, x, y, canvas_w, canvas_h, *s)

        else:
            w = canvas_w / column
            h = canvas_h / row

        # intersect points
        q_y = []
        q_x = []

        # remainder total, 'f_x, f_y'
        f_x = f_y = .0

        # Add one to coordinate when the remainder is close to one.
        for r in range(row + 1):
            y, f = divmod(y, 1.)
            f_y += f

            if f_y >= .999:
                y += 1.
                f_y -= 1.

            q_y.append(y)
            y += h

        for c in range(column + 1):
            x, f = divmod(x, 1.)
            f_x += f

            if f_x >= .999:
                x += 1.
                f_x -= 1.

            q_x.append(x)
            x += w

        for r in range(row):
            for c in range(column):
                r_c = r, c
                y, y1 = q_y[r], q_y[r + 1]
                x, x1 = q_x[c], q_x[c + 1]
                a = goo_d[r_c] = Goo(r_c)

                # Prevent round to zero with max 1.
                b = a.cell = Rect(x, y, max(1., x1 - x), max(1., y1 - y))

                a.merged = b.clone()
                a.form = x, y, x1, y, x1, y1, x, y1
                vote_d[r_c] = did_cell(r_c)
        return vote_d
