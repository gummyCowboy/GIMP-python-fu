#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Model as md, Option as ok
from roller_model_cell_branch import CellBranch
from roller_model_goo import Goo
from roller_one_the import get_factor_h, get_factor_w
from roller_polygon import CELL_SHAPE_D, SHEAR_D


class Stack(CellBranch):
    """
    Has multiple grid row and one column. Additional
    row cell position have an offset option.
    """
    model_type = md.STACK

    def __init__(self, model_name):
        """
        model_name: string
            Identify the model.
        """
        CellBranch.__init__(self, model_name)

    def calc_division(self, d):
        """
        Calculate the Stack's grid size in row and column span for 'division'.

        d: dict
            Cell Type Preset
        """
        self.division = int(d[ok.CELL_COUNT]), 1
        self.baby.emit(si.DIVISION_CHANGE, self.division)

    def init_cell_q(self, _):
        """
        Create a sorted list of valid cell index,
        'cell_q' -> [(row, column), ...].

        _: dict
            Cell Type Preset
            {Option key: value}
        """
        self.cell_q = [(r, 0) for r in range(self.division[0])]

    def init_model_cell(self, d):
        """
        Calculate the cell rectangle, the merged
        rectangle, and their inscribed plaque polygon.

        d: dict
            Cell Type Preset
            {Option key: value}

        Return: list
            [Plan vote, Work vote]
            Each True vote is a vote for change.
        """
        self.goo_d = {}
        vote_d = {}
        add_x = add_y = 0
        inc_x = get_factor_w(d[ok.ADD_OFFSET_X])
        inc_y = get_factor_h(d[ok.ADD_OFFSET_Y])
        x, y, w, h = self.rectangle

        for r_c in self.cell_q:
            a = self.goo_d[r_c] = Goo(r_c)
            a.cell.rect = a.merged.rect = x + add_x, y + add_y, w, h
            p = CELL_SHAPE_D.get(self.cell_shape)
            a.form = p(a.cell) if p else SHEAR_D[self.cell_shape](
                a.cell, d[ok.PARALLELOGRAM_SCALE]
            )
            vote_d[r_c] = self.past.did_cell(r_c)
            add_x += inc_x
            add_y += inc_y
        return vote_d
