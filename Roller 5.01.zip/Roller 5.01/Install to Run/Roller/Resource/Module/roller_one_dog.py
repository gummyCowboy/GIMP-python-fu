#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_option_group import LonerGroup, ManyGroup, NoneGroup
from roller_option_maya import GROUP_NEXUS


class Dog(object):
    """
    Initialize a class during program start as part of
    a circular import reference solution.
    Reference class instance variables from 'The.dog'.
    """

    def __init__(self):
        """Initialize global access variables."""
        self.loner_group = LonerGroup
        self.many_group = ManyGroup
        self.none_group = NoneGroup

        # Class init dispatch
        self.group_nexus = GROUP_NEXUS
