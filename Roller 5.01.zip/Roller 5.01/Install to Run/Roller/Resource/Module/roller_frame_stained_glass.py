#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Filler, Noise, do_filler_frame, make_frame_group
from roller_frame_build import Build
from roller_fu import (
    blur_selection,
    clone_layer,
    color_fill_selection,
    get_item_size,
    merge_layer,
    select_rect,
    set_saturation
)
from roller_maya import check_matter, check_mix_wrap
from roller_maya_blur_behind import BlurBehind
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_one import random_rgb
from roller_one_gegl import edge
from roller_view_preset import combine_seed
from roller_view_real import FILLER, LIGHT, do_rotated_layer, get_light
import gimpfu as fu

pdb = fu.pdb


def do_filler(v, maya):
    """
    Make Stained Glass material.

    v: View
    maya: StainedGlass
    Return: layer
        with filler material
    """
    d = maya.value_d
    group = maya.group

    combine_seed(v, d)

    z = do_rotated_layer(v, d, draw_color, group, get_light(maya))
    z = clone_layer(z)

    edge(z)

    z = clone_layer(z)
    z.mode = fu.LAYER_MODE_DIVIDE
    z = merge_layer(z)

    # Remove the color.
    set_saturation(z, -100.)

    blur_selection(z, 6.)
    blur_selection(z, 3.)
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                              # coordinate count
        (.0, .0, .7, 1.)
    )

    # Convert the layer to be a black edge on white material.
    # no linear, '0'
    pdb.gimp_drawable_invert(z, 0)

    z.mode = fu.LAYER_MODE_LUMA_DARKEN_ONLY
    z = merge_layer(z)

    set_saturation(z, 30.)

    z.name = z.parent.name + " Stained Glass"
    return z


def draw_color(z, d):
    """
    Create color rectangles from two layers of color stripes.

    z: layer
        layer to draw on

    d: dict
        Stained Glass Preset
        {Option key: value}

    Return: layer
        Has color grid.
    """
    # vertical panes
    j = z.image
    x = y = x1 = y1 = .0
    w1, h1 = get_item_size(j)
    z.mode, z.opacity = fu.LAYER_MODE_NORMAL, 100.
    w = d[ok.GLASS_PANE_W]

    while x < w1:
        x1 = min(x1 + w, w1)

        select_rect(j, x, .0, x1 - x, h1)
        color_fill_selection(z, random_rgb())
        x = x1

    z = clone_layer(z, n="Difference")
    z.mode = fu.LAYER_MODE_DIFFERENCE

    # horizontal panes
    while y < h1:
        y1 = min(y1 + w, h1)

        select_rect(j, .0, y, w1, y1 - y)
        color_fill_selection(z, random_rgb())
        y = y1
    return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)


class StainedGlass(Build):
    """Is a frame with colorful transparent glass."""
    filler_k = ok.FILLER_SG
    is_seeded = is_embossed = True
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)

        """
        self.filler_sel = None

        Build.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.WRW, ok.WRAP)],
            do_filler_frame
        )

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.SRW, ok.NOISE_D)
        )
        self.sub_maya[FILLER] = Filler(
            any_group,
            self,
            k_path + (ok.WRW, ok.FILLER_SG),
            do_filler,
            is_lucid=True
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group,
            self,
            k_path + (ok.SRW, ok.SHADOW),
            (self.cause, self, self.sub_maya[FILLER])
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(
            any_group, self.sub_maya[FILLER], k_path, ok.SRW
        )

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        filler = self.sub_maya[FILLER]
        self.is_matter |= is_change

        self.realize(v)
        filler.do(v, d[ok.WRW][ok.FILLER_SG], is_change, self.is_matter)
        self.sub_maya[ok.NOISE_D].do(
            v, d[ok.SRW][ok.NOISE_D], is_change, self.is_matter
        )

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], self.is_matter, is_change
        )

        self.sub_maya[ok.BLUR_BEHIND].do(
            v, d[ok.SRW][ok.BLUR_BEHIND], m or is_back, self.is_matter
        )
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m

    def reset(self):
        """Call when the View image is removed."""
        self.filler_sel = None
        super(StainedGlass, self).reset()
