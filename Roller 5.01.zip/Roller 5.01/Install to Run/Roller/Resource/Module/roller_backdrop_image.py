#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    create_image,
    get_layer_offset,
    layer_has_pixel,
    merge_layer
)
from roller_view_real import add_wip_layer, isolate_wip_rect, make_group
import gimpfu as fu
pdb = fu.pdb


def add_image(v, maya):
    """
    Make a Backdrop Image layer.

    v: View
    maya: Maya
    Return: layer or None
        the Backdrop Image layer
    """
    d = maya.value_d
    j = v.j
    w, h = map(int, v.wip.size)
    z = make_image_layer(v, maya)
    j1 = maya.get_image(None)

    if j1:
        # GIMP image, 'j2'
        j2 = j1.j

        if j1.size != (w, h) and d[ok.FIT_IMAGE]:
            j3 = create_image(w, h)
            z1 = pdb.gimp_layer_new_from_visible(j2, j3, "")

            j3.add_layer(z1, 0)

            # Use image origin, '1'.
            pdb.gimp_layer_scale(z1, w, h, 1)

            pdb.gimp_image_resize_to_layers(j3)

            z1 = pdb.gimp_layer_new_from_visible(j3, j, "")
            pdb.gimp_image_delete(j3)

        else:
            z1 = pdb.gimp_layer_new_from_visible(j2, j, "")

        pdb.gimp_image_insert_layer(j, z1, z.parent, get_layer_offset(z))

        if z1.width != j.width or z1.height != j.height:
            pdb.gimp_layer_set_offsets(
                z1,
                (j.width - z1.width) // 2, (j.height - z1.height) // 2
            )

        z = merge_layer(z1)
        z.name = "Backdrop Image"
        if layer_has_pixel(z):
            if d[ok.BLUR]:
                blur_selection(z, d[ok.BLUR])

            if d[ok.INVERT]:
                # no linear, '0'
                pdb.gimp_drawable_invert(z, 0)
            if not d[ok.FIT_IMAGE]:
                isolate_wip_rect(v, z)
    return z


def make_image_layer(v, maya):
    """
    Create a Backdrop Image layer.

    v: View
    maya: Maya
    Return: layer
        Is new.
    """
    return add_wip_layer(v, "Image", maya.group, offset=len(maya.group.layers))


def make_plan_group(v):
    """
    Make a Plan Backdrop group.

    v: View
    Return: layer group
        Backdrop simulation group
    """
    return make_group(v, "Backdrop", v.plan.plan_group)


def make_work_group(v):
    """
    Make a Backdrop layer group for Work.

    v: View
    Return: layer group
        for the Backdrop Image and the Backdrop Style
    """
    return make_group(v, "Backdrop", None, offset=len(v.j.layers))
