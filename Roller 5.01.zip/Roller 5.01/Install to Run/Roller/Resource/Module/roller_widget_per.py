#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Signal as si, Issue as vo
from roller_constant_key import Button as bk, Option as ok, Widget as wk
from roller_one_the import The
from roller_one_extract import get_option_list_choice
from roller_one_tip import Tip
from roller_port_per import (
    PortPerCell, PortPerFace, PortPerFacing, PortPerMerge
)
from roller_widget import set_widget_attr
from roller_widget_button import ProcessButton
from roller_widget_check_button import CheckButton
from roller_widget_voter import accept_vote
import gobject
import gtk


def compare_both_value(g):
    """
    Compare both the Plan and View values.

    g: PerGroup
        with value table
    """
    # Do Work and Plan, '2'.
    for x in range(2):
        g.compare_value_table(x)


def compare_preset_table(g, new_d, x):
    """
    Compare the Preset value table with a Preview table.

    g: PerGroup
    new_d: dict
        Is the incoming value from the Per Cell Group.

    x: int
        index to Plan or Work; 0 or 1
    """
    old_d = g.view_value[x]
    is_change = new_d != old_d

    # (row, column) or (row, column, face), 'k'; Preset value dict, 'd'
    for k, d in new_d.items():
        vote_d = {}
        reap_vote(
            vote_d,
            g.default_ballot_d,
            old_d[k] if k in old_d else None,
            d
        )
        g.emit(si.PER_CHANGE, (k, vote_d, x))
    return is_change


def compare_type_table(g, new_d, x):
    """
    Compare the Table Cell Type value with its view value.

    g: PerGroup
        with value table

    new_d: dict
        incoming Table's Cell-Type Per-Cell value

    x: int
        index to Plan or Work
    """
    old_d = g.view_value[x]
    is_change = old_d != new_d

    for r_c, a in new_d.items():
        if a != old_d[r_c] if r_c in old_d else None:
            m = True

        else:
            m = False
        g.emit(si.PER_CHANGE, (r_c, m, x))
    return is_change


def reap_vote(vote_d, ballot_d, old_d, new_d):
    """
    Compare two Preset values. Have each option cast a vote in a
    vote dict. The option's vote is True if the option has changed.

    vote_d: dict
        Use to collect vote string-type.

    ballot_d: dict
        {Option key: votes}

    old_d: dict
        old value

    new_d: dict
        new value

    Return: dict
        with vote
    """
    if old_d:
        for i, a in ballot_d.items():
            if i == ok.FRAME:
                if i not in vote_d:
                    vote_d[i] = {}

                k = get_option_list_choice(new_d[i])[0]
                k1 = get_option_list_choice(old_d[i])[0]
                sub_ballot_d = The.preset.get_vote_d(k)

                # A Frame OptionList has no vote in
                # the ballot dict, so it is checked here.
                if new_d[i][ok.SWITCH] != old_d[i][ok.SWITCH]:
                    reap_ballot(vote_d[i], sub_ballot_d, new_d[i][k])

                elif k == k1:
                    reap_vote(
                        vote_d[i], sub_ballot_d, old_d[i][k], new_d[i][k]
                    )
                else:
                    reap_ballot(vote_d[i], sub_ballot_d, new_d[i][k])

            elif isinstance(a, dict):
                if i not in vote_d:
                    vote_d[i] = {}
                reap_vote(vote_d[i], a, old_d[i], new_d[i])
            elif old_d[i] != new_d[i]:
                accept_vote(vote_d, i, a, True)
    else:
        reap_ballot(vote_d, ballot_d, new_d)


def reap_ballot(vote_d, ballot_d, new_d):
    """
    Collect change vote with a default ballot dict.

    vote_d: dict
        Use to collect vote.

    ballot_d: dict
        Is the default vote for a Preset.
    """
    for i, a in ballot_d.items():
        if i == ok.FRAME:
            k = get_option_list_choice(new_d[i])[0]
            sub_ballot_d = The.preset.get_vote_d(k)

            if i not in vote_d:
                vote_d[i] = {}
            reap_ballot(vote_d[i], sub_ballot_d, new_d[i][k])

        elif isinstance(a, dict):
            if i not in vote_d:
                vote_d[i] = {}
            reap_ballot(vote_d[i], a, new_d[i])
        else:
            accept_vote(vote_d, i, a, True)


def update_button_visual(g):
    """
    Update the Open Button's visibility.

    g: Per Cell Group
        Has button.
    """
    if g.check_button.get_a():
        g.button.show()
    else:
        g.button.hide()


class PerGroup(gtk.Alignment, gobject.GObject, object):
    """Has a Per CheckButton and an Open Button."""
    __gsignals__ = si.PER_D
    change_signal = None
    has_table_label = False

    def __init__(self, **d):
        """
        d: dict
            Has keyword argument for Widget.
        """
        super(gtk.Alignment, self).__init__()
        gobject.GObject.__init__(self)

        # the GTK Alignment setting
        self.set(0, 0, 1, 1)

        self.handle_d = {}
        self._cancel_value = {}

        # Updated after a View, a copy of the value table.
        # Is ordered as [Plan, Work].
        self.view_value = [{}, {}]

        # {per key: Preset dict}
        self._value = {}

        set_widget_attr(self, d)

    def hide(self, *_):
        """
        Hide the row in the Table container if the Widget is ready.
        Table sets the 'self.box' to a VBox container.
        """
        # There's a timing issue 'box' during init.
        if hasattr(self, 'box') and self.box:
            self.box.hide()
            self.label_box.hide()

    def show(self, *_):
        """
        Show the row in the Table Widget if the Widget is ready.
        The Table Widget class has set the 'self.box' to a VBox container.
        """
        # There's a timing issue 'box' during init.
        if hasattr(self, 'box') and self.box:
            self.box.show()
            self.label_box.show()


class WithWidget(PerGroup):
    """Create PerGroup Widget."""

    def __init__(self, **d):
        PerGroup.__init__(self, **d)

        # Is true when PortPerTable is open.
        self.edit_mode = False

        self._hbox = gtk.HBox()
        relay = d[wk.RELAY][:]
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

        # CheckButton
        # The CheckButton and Button don't cast vote.
        d.pop(wk.ISSUE)
        d[wk.RELAY].insert(0, self.on_per_switch)
        d[wk.CHANGELESS] = True
        d[wk.TOOLTIP] = Tip.PER_CHECK_BUTTON
        d[wk.ALIGN] = 0, 0, 0, 1
        self.check_button = CheckButton(**d)

        # Button
        d[wk.TOOLTIP] = Tip.PER_BUTTON
        d[wk.KEY] = d[wk.TEXT] = bk.OPEN
        d[wk.ALIGN] = 0, 0, 1, 0
        d[wk.RELAY] = relay

        relay.insert(0, self.on_open_button_action)

        self.button = self.widget = ProcessButton(**d)

        self.add(self._hbox)

        for i in (self.check_button, self.button):
            self._hbox.add(i)
            same_size.add_widget(i.widget)

    def get_a(self):
        """
        Get the Preset table.

        Return: list
            Preset table
            2D (list(s) within a list)
            May be an empty list.
        """
        return self._value

    def intersect_vote(self, vote_d):
        """
        Receive a vote dict and send a change signal.

        vote_d: dict
            {cell index-type key: [Plan vote, Work vote]}
        """
        group_vote_q = set()
        q = self._value.keys()

        # Plan and Work vote list, 'a'
        for k, a in vote_d.items():
            if k in q:
                # Plan and Work, '2'
                for x in range(2):
                    d = {ok.IS_CHAIN: a[x]}

                    self.emit(
                        si.PER_CHANGE,
                        (k, {vo.MATTER: d, vo.MODE: d, vo.OPACITY: d}, x)
                    )
                    group_vote_q.update((x,))
        for x in group_vote_q:
            self.any_group.cast_vote(x, ok.PER, vo.PER, True)

    def on_accept_cell_edit(self, d):
        """
        Return from PortPer. Exit edit mode.

        d: dict
            the new value for the PerGroup
        """
        self.set_a(d)
        self.edit_mode = False

    def on_cancel_cell_edit(self):
        """
        Return from PortPer. Exit from edit
        mode. Restore the 'cancel_value'.
        """
        self.set_a(self._cancel_value)
        self.edit_mode = False

    def on_open_button_action(self, g):
        """
        Respond to an Open Button action.

        g: Button
            Is responsible.
        """
        # Use to restore change on cancel.
        self._cancel_value = deepcopy(self._value)

        # Is True when the cell editor is open.
        self.edit_mode = True

        self.roller_win.bring_dialog(
            self,
            d={
                wk.ON_ACCEPT: self.on_accept_cell_edit,
                wk.ON_CANCEL: self.on_cancel_cell_edit,
            }
        )

    def on_per_switch(self, g):
        """
        Respond to a change event for the Per Cell CheckButton.

        g: CheckButton
            Is responsible.
        """
        if not g.get_a():
            self.set_a({})

        # Plan and Work indices, '2'
        for x in range(2):
            self.any_group.cast_vote(
                x, ok.PER, vo.PER, self._value != self.view_value[x]
            )
        update_button_visual(self)

    def set_a(self, d, x=None):
        """
        Set the PerGroup value.

        d: dict
            {(row, column): Preset value dict}
            The row and column cell index range from 0
            to the span of the Model's table.

        x: int or None
            Is used by Cell Table to indicate the View origin
            where zero is Plan and one is Work.
        """
        d = self._value = d if isinstance(d, dict) else {}

        if x is not None:
            self.compare_value_table(self, x)

        else:
            compare_both_value(self)

        self.check_button.widget.set_active(bool(d))
        self.any_group.update_option_a(self.key, d)

    def set_view_value(self, x, a):
        self.view_value[x] = deepcopy(a)


class Cellular(WithWidget):
    """Is factored from Cell and Face PerGroup."""

    def __init__(self, **d):
        WithWidget.__init__(self, **d)

        self.default_ballot_d = The.preset.get_vote_d(
            self.any_group.item.key
        )

    def check_for_lost(self, q):
        lost_q = []
        is_change = False

        for k in self._value.keys():
            if k not in q:
                lost_q.append(k)
                self._value.pop(k)
            else:
                # The Per Maya changed.
                is_change = True

        if is_change:
            # Set the View value to trigger change.
            self.view_value = [{}, {}]
            compare_both_value(self)
        if lost_q:
            self.emit(si.DISAPPEAR, lost_q)

    def compare_value_table(self, x):
        """
        Compare a value table with a view value.
        Route Table Cell Type differently.

        x: int
            index to Plan or Work attribute
        """
        d = self.get_a()
        is_change = compare_preset_table(self, d, x)

        # Per Widget changed
        self.any_group.cast_vote(x, ok.PER, vo.PER, is_change)

        self.any_group.cast_vote(
            x, ok.IS_MAIN, vo.MATTER, d.keys() != self.view_value[x].keys()
        )

    def get_cell_value(self, k):
        """
        Fetch the value from the Preset table.

        k: tuple
            (r, c) or (r, c, x)
            zero-based cell index (r, c) and face index (x)
        """
        if k in self._value:
            return self._value[k]

    def on_cell_rect_calc(self, _, arg):
        """
        Check the cell key for a Model grid.

        _: Baby
            Sent the Signal.

        arg: dict
            Has vote.
        """
        self.check_for_lost(self.any_group.item.model.cell_q)

    def set_a(self, d, x=None):
        """
        Set the PerGroup value.

        d: dict
            {(row, column): Preset value dict}
            The row and column cell index range from 0
            to the span of the Model's table.

        x: int or None
            Is used by Cell Table to indicate the View origin
            where zero is Plan and one is Work.
        """
        lost_q = []
        last_value = deepcopy(self._value)

        super(Cellular, self).set_a(d)

        for k in last_value:
            if k not in self._value:
                lost_q.append(k)
        if lost_q:
            self.emit(si.DISAPPEAR, lost_q)


class PerGroupCell(Cellular):
    """Manage Cell-branch PerGroup."""

    def __init__(self, **d):
        self.dialog = PortPerCell
        Cellular.__init__(self, **d)


class PerGroupEmpty(PerGroup):
    """Is basically a dummy PerGroup."""

    def __init__(self, **d):
        PerGroup.__init__(self, **d)

        # never changes
        self.any_group.value_d[ok.PER] = {}

    def get_a(self):
        """
        Get the Preset table.

        Return: list
            empty
        """
        return {}

    def intersect_vote(self, vote_d):
        return

    def set_a(self, *_, **q):
        """Set the PerGroup value."""
        return

    def set_view_value(self, x, a):
        self.view_value[x] = {}


class PerGroupFace(Cellular):
    """
    Manage Face branch PerGroup. It's value dict key is
    (row, column, face), where each tuple item is a zero-based index.
    """

    def __init__(self, **d):
        self.dialog = PortPerFace
        Cellular.__init__(self, **d)

    def intersect_vote(self, vote_d):
        """
        Receive a vote dict and send a change signal.

        vote_d: dict
            {cell index-type key: [Plan vote, Work vote]}
        """
        group_vote_q = set()
        q = self._value.keys()

        # zero-based (row, column) index, 'k'
        # Plan and Work vote list, 'a'
        for k, a in vote_d.items():
            # Each Face in the cell has change.
            for face_x in range(3):
                k1 = k + (face_x,)
                if k1 in q:
                    # Plan and Work, '2'
                    for x in range(2):
                        d = {ok.IS_CHAIN: a[x]}

                        self.emit(
                            si.PER_CHANGE,
                            (k1, {vo.MATTER: d, vo.MODE: d, vo.OPACITY: d}, x)
                        )
                        group_vote_q.update((x,))
        for x in group_vote_q:
            self.any_group.cast_vote(x, ok.PER, vo.PER, True)

    def on_cell_rect_calc(self, _, arg):
        """
        Check the cell key for a Model grid.

        _: Baby
            Sent the Signal.

        arg: dict
            Has issue vote.
        """
        self.check_for_lost(self.any_group.item.model.face_q)

    def set_a(self, d, x=None):
        """
        Set the PerGroup value.

        d: dict
            {(row, column): Preset value dict}
            The row and column cell index range from 0
            to the span of the Model's table.

        x: int or None
            Is used by Cell Table to indicate the View origin
            where zero is Plan and one is Work.
        """
        super(PerGroupFace, self).set_a(d, x=x)

        # Repair.
        for i in self._value.keys():
            if len(i) == 2:
                self._value.pop(i)


class PerGroupFacing(PerGroupFace):
    """
    Manage Face-branch PerGroup. It's value dict key is
    (row, column, 0), where each tuple item is a zero-based index.
    The zero in the key is deviant from the Cell branch because
    some Model dict are shared by both the Cell and Facing branches.
    """

    def __init__(self, **d):
        Cellular.__init__(self, **d)
        self.dialog = PortPerFacing

    def intersect_vote(self, vote_d):
        """
        Receive a vote dict and send a change signal.

        vote_d: dict
            {cell index-type key: [Plan vote, Work vote]}
        """
        group_vote_q = set()
        q = self._value.keys()

        # zero-based (row, column) index, 'k'
        # Plan and Work vote list, 'a'
        for k, a in vote_d.items():
            # Add Facing index.
            k = k + (0,)
            if k in q:
                # Plan and Work, '2'
                for x in range(2):
                    d = {ok.IS_CHAIN: a[x]}

                    self.emit(
                        si.PER_CHANGE,
                        (k, {vo.MATTER: d, vo.MODE: d, vo.OPACITY: d}, x)
                    )
                    group_vote_q.update((x,))
        for x in group_vote_q:
            self.any_group.cast_vote(x, ok.PER, vo.PER, True)


class PerGroupMerge(WithWidget):
    """Is used by Table/Cell/Type for its PerGroup."""

    def __init__(self, **d):
        self.dialog = PortPerMerge
        WithWidget.__init__(self, **d)

    def compare_value_table(self, x):
        """
        Compare a value table with a Preview table.
        Route Table Cell Type differently.

        x: int
            index to Plan or Work attribute
        """
        d = self.get_a()
        is_change = compare_type_table(self, d, x)

        # Per Widget changed
        self.any_group.cast_vote(x, ok.PER, vo.PER, is_change)

        self.any_group.cast_vote(
            x, ok.IS_MAIN, vo.MATTER, d.keys() != self.view_value[x].keys()
        )

    def on_accept_cell_edit(self, d):
        """
        Return from PortPer. Exit from edit mode.

        d: dict
            the new value for the PerGroup
        """
        super(PerGroupMerge, self).on_accept_cell_edit(d)

        # When the Table Cell Type change,
        # the pocket and merge rect need update.
        self.any_group.item.model.baby.give(
            si.CELL_RECT_CHANGE, (self.any_group.value_d, False)
        )

    def on_cancel_cell_edit(self):
        """
        Return from PortPer. Exit from edit
        mode. Restore the 'cancel_value' table.
        """
        super(PerGroupMerge, self).on_cancel_cell_edit()

        # Merge cell may have been altered.
        self.any_group.item.model.baby.give(
            si.CELL_RECT_CHANGE, (self.any_group.value_d, False)
        )

    def on_per_switch(self, g):
        """
        Respond to a change event for the Per Cell CheckButton.

        g: CheckButton
            Is responsible.
        """
        if g.get_a() and not The.load_count:
            for r_c in self.any_group.item.model.cell_q:
                self._value[r_c] = 1, 1
        super(PerGroupMerge, self).on_per_switch(g)


# Register the custom signals.
gobject.type_register(PerGroup)
