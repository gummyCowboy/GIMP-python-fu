#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from random import choice
from roller_constant_for import Signal as si
from roller_constant_key import (
    Item as ie, Option as ok, Step as sk, Widget as wk
)
from roller_one_extract import get_option_list_choice
from roller_one_the import The
from roller_option_squish import make_tooltip
from roller_widget_button import ProcessButton
from roller_widget_voter import accept_vote
import gtk


def gather_vote(vote_d, ballot_d, old_d, new_d):
    """
    Compare two Preset dict. When an item differs,
    record a True vote for the option's issue that is
    found in a ballot dict.

    vote_d: dict
        Use to collect issue vote.

    ballot_d: dict
        Is structured symmetrically with the Preset dict.

    old_d: dict or None
        old value

    new_d: dict
        new value

    Return: dict
        with vote
    """
    if old_d:
        for i, a in ballot_d.items():
            if isinstance(a, dict):
                if i not in vote_d:
                    vote_d[i] = {}
                gather_vote(vote_d[i], ballot_d[i], old_d[i], new_d[i])
            elif old_d[i] != new_d[i]:
                accept_vote(vote_d, i, a, True)
    else:
        gather_ballot_vote(vote_d, ballot_d)


def gather_option_list_vote(vote_d, old_d, new_d):
    """
    Collect vote for an OptionListButton.

    vote_d: dict
        {issue: {Option key: bool}}
        Receive vote to be used by Maya.

    old_d: dict or None
        the previous value

    new_d: dict or None
        the incoming value
    """
    if not new_d:
        # Init phase.
        return

    else:
        new_switch = new_d[ok.SWITCH]
    if new_switch:
        new_option_k, sub_new_d = get_option_list_choice(new_d)
        ballot_d = The.preset.get_vote_d(new_option_k)

        if not old_d:
            sub_old_d = old_option_k = None
            old_switch = 0

        else:
            old_option_k, sub_old_d = get_option_list_choice(old_d)
            old_switch = old_d[ok.SWITCH]
            if new_option_k != old_option_k:
                sub_old_d = None

        is_switch = old_switch != new_switch

        if is_switch:
            gather_ballot_vote(vote_d, ballot_d)

        elif old_option_k != new_option_k:
            gather_ballot_vote(vote_d, ballot_d)
        else:
            gather_vote(vote_d, ballot_d, sub_old_d, sub_new_d)


def gather_ballot_vote(vote_d, ballot_d):
    """
    Collect vote from the default ballot dict.

    vote_d: dict
        Use to collect vote.

    ballot_d: dict
        Is the default vote for a Preset.
    """
    for i, a in ballot_d.items():
        if isinstance(a, dict):
            if i not in vote_d:
                vote_d[i] = {}
            gather_ballot_vote(vote_d[i], a)
        else:
            accept_vote(vote_d, i, a, True)


class ValueButton(ProcessButton):
    """Has an attached value."""
    has_table_label = False

    def __init__(self, **d):
        """
        d: dict
            Has init variables.
        """
        self.tip_type = None
        self.tooltip_text = ""
        d[wk.TEXT] = d[wk.KEY].split(",")[0] + "…"

        if wk.ROW_KEY not in d:
            d[wk.ROW_KEY] = None

        d[wk.RELAY].insert(0, self.on_option_button_action)
        ProcessButton.__init__(self, **d)
        self.widget.set_use_underline(False)

    def _update_tooltip(self, a):
        """
        Set the ValueButton's tooltip.

        a: value
            Use to make tooltip.
        """
        if a is not None:
            self.tooltip_text = make_tooltip(self.key, a, "", 0, 0)
            self.set_tooltip_text(self.tooltip_text)

    def get_a(self):
        """Fetch the value."""
        return deepcopy(self._value)

    def on_option_button_action(self, _):
        """
        Respond to a Button click. Open a Window.

        _: ValueButton
            activated

        Return: True
            Tell GTK that the signal is processed.
        """
        if self.dialog:
            self.roller_win.bring_dialog(self)
        return True


class Switchable:
    """Has a popup menu with a Throw Switch menu item."""

    def __init__(self, button):
        """
        button: GTK Button
            Give Throw Switch menu.
        """
        # Add popup menu.
        # Reference
        # 'stackoverflow.com/questions/6616270/'
        # 'right-click-menu-context-menu-using-pygtk'
        self.menu = gtk.Menu()
        self.menu_item = gtk.MenuItem("Throw Switch")

        self.menu_item.connect('activate', self.on_throw_switch)
        self.menu.append(self.menu_item)
        self.menu_item.show()
        self.menu.show()
        button.connect('button_release_event', self.on_switchable_clicked)

    def on_switchable_clicked(self, button, event):
        """
        React to a mouse button click on the button. If the
        button is right-clicked, create a popup menu.

        button: self
        event: gtk.gdk.Event
        Return: None
            Tell GTK to continue processing the event.
        """
        def _popup():
            # GTK right-mouse button enum, '3'
            if event.button == 3:
                self.menu.popup(None, None, None, event.button, event.time)

        d = self.get_a()
        a = d.get(ok.SWITCH)

        if a is not None:
            _popup()

        else:
            a = d.get(sk.SHADOW_SWITCH)
            if a is not None:
                _popup()


    def on_throw_switch(self, *arg):
        """
        Respond to a throw switch request from the right-click popup menu.

        arg: tuple
            (sender, signal)

        Return: None
            Tell GTK to continue processing the event.
        """
        def _flip():
            The.power.add(self.any_group, si.GROUP_CHANGE, None)
            The.power.plug(si.UI_CHANGE, self)

        d = self.get_a()
        a = d.get(ok.SWITCH)

        if a is not None:
            d[ok.SWITCH] = not a

            self.set_a(d)
            _flip()

        else:
            a = d[sk.SHADOW_SWITCH][ok.SWITCH]
            d[sk.SHADOW_SWITCH][ok.SWITCH] = not a

            self.set_a(d)
            _flip()


class OptionButton(ValueButton, Switchable):
    """
    Open a Preset editor dialog. Handle Preset value change.
    Has a Preset tooltip and a Preset value.
    """

    def __init__(self, **d):
        """
        d: dict
            Has variables.
        """
        ValueButton.__init__(self, **d)
        Switchable.__init__(self, self.button)
        self._default_ballot_d = The.preset.get_vote_d(self.key)

    def set_a(self, a, x=None):
        """
        Override the base class, so that the ValueButton's Label
        and tooltip can be modified. Compare value for change.

        a: dict
            incoming Button value

        x: int
            0, 1, or None
            Plan, Work, both index
        """
        # A Dialog Button is not main.
        if self.roller_win.is_main:
            vote_q = [{}, {}]

            for x1 in (0, 1) if x is None else (x,):
                gather_vote(
                    vote_q[x1],
                    self._default_ballot_d,
                    self.view_value[x1],
                    a
                )
            self.any_group.update_sub_g(self.key, self.row_key, a, vote_q)

        self._value = a

        self._update_tooltip(a)
        if self.key == ok.IMAGE_CHOICE:
            The.power.add(self.any_group, si.GROUP_CHANGE, None)


class InfluenceButton(ValueButton):
    """Use to customize the 'set_a' function of ValueButton."""

    def __init__(self, **d):
        self._make_tooltip = d[wk.TIPPER]
        ValueButton.__init__(self, **d)

    def set_a(self, a, x=None):
        """
        a: string
            Is the Button's value.

        x: int or None
            Is an index for Plan, Work, or both.
        """
        self._value = a
        if self.roller_win.is_main:
            self.tooltip_text = self._make_tooltip(a)
            self.set_tooltip_text(self.tooltip_text)
            self.any_group.set_sub_widget_a(self.key, self.row_key, a)

            # Work index, '1'
            if x in (1, None):
                The.power.plug(si.LIGHT_CHANGE, None)
            self.any_group.changed(1)


class OptionListButton(ValueButton, Switchable):
    """Use with the Style and Frame option. Compares the OptionList choice."""

    def __init__(self, **d):
        ValueButton.__init__(self, **d)
        Switchable.__init__(self, self.button)

    def set_a(self, a, x=None):
        """
        a: dict
            Is the Button's value.

        x: int
            0, 1, or None
            Plan, Work, both index
        """
        if self.roller_win.is_main:
            vote_q = [{}, {}]

            for x1 in (0, 1) if x is None else (x,):
                if a and not a[ok.SWITCH]:
                    pass

                else:
                    gather_option_list_vote(
                        vote_q[x1], self.view_value[x1], a
                    )

            self.any_group.update_sub_g(
                self.key, self.row_key, a, vote_q
            )

        self._value = a
        self._update_tooltip(a)


class StringButton(ValueButton):
    """Has a string value."""

    def __init__(self, **d):
        ValueButton.__init__(self, **d)

    def set_a(self, a, x=None):
        """
        Override the super class, so that the ValueButton's Label
        and tooltip can be modified. Compare value for change.

        a: string
            Is the Button's value.

        x: int
            0, 1, or None
            Plan, Work, both index
        """
        def _sub_vote():
            _vote_q = [{}, {}]

            for _x in range(2):
                accept_vote(
                    _vote_q[_x], self.key, self.issue, a != self.view_value[_x]
                )
            self.any_group.update_sub_g(self.key, self.row_key, a, _vote_q)

        if self.roller_win.is_main:
            if self.row_key:
                _sub_vote()
            else:
                for x1 in (0, 1) if x is None else (x,):
                    self.any_group.cast_vote(
                        x1, self.key, self.issue, a != self.view_value[x1]
                    )
                self.any_group.update_option_a(self.key, a)

        self.tooltip_text = " {} ".format(a)

        self.set_tooltip_text(self.tooltip_text)
        self._value = a


class ListButton(StringButton):
    """
    Has a function to get a list of choices. Is coupled with RWChoice Window.
    """

    def __init__(self, **d):
        StringButton.__init__(self, **d)
        self.handle_d[
            self.any_group.connect(si.RANDOMIZE, self.randomize)
        ] = self.any_group

    def get_list(self):
        """
        Fetch a list that is the source of the Button's value.

        Return: list
            of string
        """
        key = self.key

        if 'pattern' in key.lower():
            key = ok.PATTERN

        return {
            ok.BRUSH: The.cat.brush_list,
            ok.FONT: The.cat.font_list,
            ok.GRADIENT: The.cat.gradient_list,
            ok.PATTERN: The.cat.pattern_list
        }[key]

    def randomize(self, *_):
        """Randomize the value of the Button."""
        self.set_a(choice(self.get_list()))
