#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_rect_table import RectTable
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_fu import (
    add_layer_above,
    blur_selection,
    color_fill_selection,
    color_fill_layer,
    desaturate,
    get_item_size,
    get_layer_offsets,
    merge_layer_group,
    remove_z,
    select_color,
    select_rect,
    set_layer_mode
)
from roller_fu_mode import translate_mode
from roller_maya_style import Style, make_background
from roller_view_hub import invert_color
from roller_view_real import (
    add_wip_layer, do_rotated_layer, finish_style, make_layer_group
)
import gimpfu as fu

pdb = fu.pdb


def do_color_grid(v, d, group):
    """
    Draw a Color Grid.

    v: View
    d: dict
        Color Grid Preset

    group: layer
        Is destination for output.

    Return: layer
        with Color Grid material
    """
    return do_rotated_layer(v, d, draw_color_grid, group, 0)


def draw_color_grid(z, d):
    """
    Draw a black and white checkerboard.

    z: layer
        to be replaced by the grid layer

    d: dict
        Color Grid Preset
        {Option key: value}

    Return: layer
        Has the checkerboard pattern.
    """
    j = z.image
    x, y = get_layer_offsets(z)
    w, h = get_item_size(z)
    row, column = int(d[ok.ROW]), int(d[ok.COLUMN])
    grid = RectTable((x, y, w, h), row, column).table
    z1 = add_layer_above(z, n="V")

    # Prep layers for selections.
    color_fill_layer(z, (255, 255, 255))
    color_fill_layer(z1, (255, 255, 255))

    pdb.gimp_selection_none(j)

    # Draw horizontal stripes.
    for r in range(0, row, 2):
        select_rect(
            j, .0, grid[r][0].y, w, grid[r][0].h, option=fu.CHANNEL_OP_ADD
        )

    color_fill_selection(z, (0, 0, 0))
    pdb.gimp_selection_none(j)

    # Draw vertical stripes.
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    # row, 'a'
    a = grid[0]

    for c in range(0, column, 2):
        select_rect(j, a[c].x, .0, a[c].w, h, option=fu.CHANNEL_OP_ADD)

    color_fill_selection(z1, (0, 0, 0))
    return pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)


def make_style(v, maya):
    """
    Do the Backdrop Style.

    v: View
        Has scope variable.

    maya: Style
    Return: layer
        with Color Grid
    """
    j = v.j
    d = maya.value_d
    group = make_layer_group(j, "WIP", parent=maya.group)
    back_z = make_background(v, d, group)

    # black and white checkerboard layer, 'z'
    z = do_color_grid(v, d, maya.group)

    # Get the checkerboard layer out of the
    # way of the background copy function.
    pdb.gimp_image_reorder_item(j, z, None, 0)

    # Begin making two color grid layers each with its own layer mode.
    # layer to receive color grid material, 'z1'
    z1 = add_wip_layer(v, "Color 1", group)

    # Select by color and fill.
    select_color(z, (255, 255, 255))

    q = d[ok.COLOR_2A][0]

    if d[ok.IDR][ok.INVERT]:
        q = invert_color(q)

    set_layer_mode(z1, translate_mode(d[ok.COLOR_1_MODE]))
    color_fill_selection(z1, q)

    a = d[ok.BLUR_BEHIND_COLOR_1]

    if a:
        blur_selection(back_z, a)

    # layer to receive color grid material, 'z1'
    z2 = add_wip_layer(v, "Color 2", group)

    select_color(z, (0, 0, 0))

    q = d[ok.COLOR_2A][1]

    if d[ok.IDR][ok.INVERT]:
        q = invert_color(q)

    set_layer_mode(z2, translate_mode(d[ok.COLOR_2_MODE]))
    color_fill_selection(z2, q)

    a = d[ok.BLUR_BEHIND_COLOR_2]

    if a:
        blur_selection(back_z, a)

    remove_z(z)

    z = merge_layer_group(group)

    if d[ok.IDR][ok.DESATURATE]:
        desaturate(z)
    return finish_style(z, "Color Grid")


class ColorGrid(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BRW][ok.BACKGROUND][ok.TYPE] == bs.BACKDROP_IMAGE
        super(ColorGrid, self).do(v, d, is_change)
