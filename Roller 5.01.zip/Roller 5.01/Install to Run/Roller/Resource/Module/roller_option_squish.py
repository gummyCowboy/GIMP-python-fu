#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    BackdropStyle as bs,
    Bump as fb,
    Caption as pt,
    Deco as dc,
    Frame as ff,
    Gradient as fg,
    Grid as gr,
    Mask as ms,
    Resize as fz,
    Shape as sh
)
from roller_constant_key import (
    BackdropStyle as by,
    Button as bk,
    Frame as ek,
    Group as gk,
    Node as ny,
    Option as ok,
    Step as sk,
    Widget as wk,
)
from roller_one_extract import get_option_list_key
from roller_one_the import The

ALWAYS = ok.PRESET, ok.PER, ok.SWITCH
COMMON_FORMAT = {bk.PLAN, bk.PREVIEW}
FOR_BOX_SHAPE_COUNT = {ok.HORZ_COUNT, ok.VERT_COUNT}
FOR_CELL_COUNT = {ok.COLUMN_COUNT, ok.ROW_COUNT}
FOR_CELL_SIZE = {ok.COLUMN_W, ok.GRID_SIZE, ok.ROW_H}
FOR_CROP = {ok.CROP_H, ok.CROP_W, ok.CROP_X, ok.CROP_Y}
FOR_FACE = ny.FACE, ny.FACING
FOR_FACTOR = {ok.FIH, ok.FIW}
FOR_FIXED = {ok.FIXED_SIZE_H, ok.FIXED_SIZE_W}
FOR_GRADIENT = {ok.GRADIENT, ok.GRADIENT_ANGLE, ok.GRADIENT_TYPE}
FOR_PAINT_RUSH = {ok.COLOR_1, ok.COLORIZE_OPACITY}
FOR_DECO_BLUR = dc.BACKDROP, dc.PATTERN, dc.PLASMA, dc.IMAGE
FOR_MASK_D = {
    ms.EYE: ok.PUPIL_SCALE,
    ms.FRINGE: ok.CONTRACT,
    ms.TEXT: (ok.TEXT, ok.FONT),
}
FOR_PARALLELOGRAM = (
    sh.PARALLELOGRAM_ALT_LEFT,
    sh.PARALLELOGRAM_ALT_RIGHT,
    sh.PARALLELOGRAM_LEFT,
    sh.PARALLELOGRAM_RIGHT
)
FOR_METAL_NOISE = {ok.BLUR, ok.NOISE_AMOUNT, ok.SPECK_NOISE}
FOR_RESIZE_LABEL = ok.COVER, ok.FILLED, ok.LOCKED, ok.TRIM
FOR_SHAPE_COUNT = {ok.ECS, ok.HORZ_COUNT, ok.VERT_COUNT}
MASK_SUB_TYPE = (
    (ms.CORNER, ok.CORNER_TYPE),
    (sh.HEXAGON, ok.HEXAGON_TYPE),
    (sh.OCTAGON, ok.OCTAGON_TYPE),
    (sh.RECTANGLE, ok.RECTANGLE_TYPE),
    (ms.TRIANGLE, ok.TRIANGLE_TYPE)
)
PLAQUE_COLOR = dc.COLOR, dc.NETTING
SHOW_SAMPLES = {
    ok.BUMP,
    ok.GRADIENT_TYPE,
    ok.IRR,
    ok.MODE,
    ok.OPACITY,
    ok.ANGLE
}
SWITCH_VISIBLE = ok.PER, ok.PRESET, ok.SWITCH


def all_visible(*_):
    """
    Let the caller know that the Preset has no hidden key.

    Return: set
        Is empty.
    """
    return set()


def do_per(group):
    """
    Update the group's visibility.

    group: AnyGroup
    """
    if group and ok.PER in group.widget_d:
        g = group.widget_d[ok.PER]

        # A PerGroupEmpty has no sub-Widget.
        if hasattr(g, 'button'):
            # Open Button
            g1 = g.button

            if not g.check_button.get_a():
                g1.hide()
            else:
                g1.show()


def get_hidden_background(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Backdrop Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    n = d[ok.TYPE]

    if n != bs.GRADIENT:
        q.update({ok.GRADIENT_ANGLE, ok.GRADIENT_TYPE})
        q.update(([(ok.GRR, (ok.GRADIENT,))]))

    else:
        q.update(([(ok.GRR, ())]))
        if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
            q.update({ok.GRADIENT_ANGLE})

    if n not in (bs.CLOUDS, bs.PLASMA):
        q.update({ok.SEED})
    return q


def get_hidden_blur_behind(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        with option value

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in SWITCH_VISIBLE}

    if d[ok.SWITCH]:
        q = set()
    return q


def get_hidden_border(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        with option value

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden options, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        # hidden options, 'q'
        q = set()

        n = d[ok.TYPE]

        if n != dc.GRADIENT:
            q.update(FOR_GRADIENT)

        else:
            # Shape type gradients radiate from
            # the center, so there is no angle.
            if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
                q.update({ok.GRADIENT_ANGLE})

        if n not in (dc.COLOR, dc.NETTING):
            q.update({ok.COLOR_1})

        if n != dc.IMAGE:
            q.update({ok.IMAGE_CHOICE})

        if n != dc.PATTERN:
            q.update({ok.PATTERN})

        if n not in (dc.CLOUDS, dc.PLASMA):
            q.update({ok.SEED})

        if n != dc.NETTING:
            q.update({ok.NET_LINE_W, ok.NLS})

        if n not in dc.INVERT_ABLE:
            q.update({ok.IDR})

        if n not in FOR_DECO_BLUR:
            q.update({ok.BLUR})
        if branch_k in FOR_FACE:
            q.update({ok.OBEY_MARGINS})
            if branch_k == ny.FACE:
                q.update(([(ok.BRW, (ok.FRAME,))]))

    do_per(group)
    return q


def get_hidden_box(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    n = d[ok.GRID_TYPE]

    if n != gr.CELL_COUNT:
        q.update(FOR_CELL_COUNT)

    if n != gr.CELL_SIZE:
        q.update(FOR_CELL_SIZE)

    if n != gr.SHAPE_COUNT:
        q.update(FOR_BOX_SHAPE_COUNT)

    if n not in (gr.CELL_SIZE, gr.SHAPE_COUNT):
        q.update({ok.PIN})
    return q


def get_hidden_bump(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in SWITCH_VISIBLE}

    if d[ok.SWITCH]:
        q = set()
        n = d[ok.TYPE]

        if n not in fb.HAS_NOISE:
            q.update({ok.NOISE})

        if n != fb.CLOTH:
            q.update({ok.BLUR_X, ok.BLUR_Y})
        if n not in fb.HAS_INVERT:
            q.update({ok.INVERT})
    return q


def get_hidden_caption(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        n = d[ok.TYPE]

        if n == pt.TEXT and not d[ok.TEXT]:
            q -= {ok.TYPE, ok.TEXT}
        else:
            # hidden Widget key, 'q'
            q = set()

            if n != pt.TEXT:
                q.update({ok.TEXT})

            if n != pt.SEQUENCE:
                q.update({ok.START_NUMBER})

            if n not in (pt.SEQUENCE, pt.IMAGE_NAME):
                q.update({ok.LTR})

            # Face and Facing Caption don't have the Clip-to-Cell option.
            if branch_k in FOR_FACE:
                q.update({ok.OCR})

    do_per(group)
    return q


def get_hidden_cell(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    n = d[ok.CELL_SHAPE]

    if n not in FOR_PARALLELOGRAM:
        q.update({ok.PARALLELOGRAM_SCALE})
    return q


def get_hidden_frame_over_overlay(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    gpr_q = ()
    cir_q = ()
    n = d[ok.TYPE]

    if n not in (ff.CLOUDS, ff.PLASMA):
        q.update({ok.SEED})

    if n != ff.COLOR:
        cir_q += (ok.COLOR_1,)

    else:
        q.update({ok.BLUR})

    if n != ff.IMAGE:
        cir_q += (ok.IMAGE_CHOICE,)

    if n != ff.PATTERN:
        gpr_q += (ok.PATTERN,)

    if n != ff.GRADIENT:
        q.update({ok.GRADIENT_ANGLE, ok.GRADIENT_TYPE})
        gpr_q += (ok.GRADIENT,)
    else:
        if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
            q.update({ok.GRADIENT_ANGLE})

    q.update(([(ok.GPR, gpr_q)]))
    q.update(([(ok.CIR, cir_q)]))
    return q


def get_hidden_fringe(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        # hidden Widget key, 'q'
        q = set()

        clip_q = ()
        n = d[ok.TYPE]

        if n != dc.GRADIENT:
            q.update(FOR_GRADIENT)

        else:
            # Shape-burst gradients radiate from the center.
            if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
                q.update({ok.GRADIENT_ANGLE})

        if n not in (dc.CLOUDS, dc.PLASMA):
            q.update({ok.SEED})

        if n != dc.IMAGE:
            q.update({ok.IMAGE_CHOICE})

        if n != dc.MULTI_COLOR:
            q.update({ok.COLOR_6, ok.COLOR_COUNT})

        else:
            q.update(([(ok.COLOR_6, d[ok.COLOR_COUNT])]))

        if n != dc.PATTERN:
            q.update({ok.PATTERN})

        if n != dc.NETTING:
            q.update({ok.NET_LINE_W, ok.NLS})

        if n not in (dc.COLOR, dc.NETTING):
            q.update({ok.COLOR_1})

        if n not in FOR_DECO_BLUR:
            q.update({ok.BLUR})

        if n not in dc.INVERT_ABLE:
            q.update({ok.IDR})

        if branch_k in FOR_FACE:
            q.update({ok.OCR})
            if branch_k == ny.FACE:
                q.update(([(ok.FRW, (ok.FRAME,))]))
        q.update(([(ok.OCR, clip_q)]))

    do_per(group)
    return q


def get_hidden_galactic_field(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        not used

    Return: set
        hidden Widget key
    """
    q = set()

    if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
        q.update(bs.POINT_KEY)
        if ok.GRADIENT_ANGLE in d:
            q.update({ok.GRADIENT_ANGLE})
    return q


def get_hidden_gradient(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
        q.update(bs.POINT_KEY)
        if ok.GRADIENT_ANGLE in d:
            q.update({ok.GRADIENT_ANGLE})
    return q


def get_hidden_gradient_light(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    if not d[ok.SWITCH]:
        # hidden Widget key, 'q'
        q = {i for i in d if i != ok.SWITCH}

    else:
        q = set()
        if d[ok.SWITCH]:
            if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
                q.update({ok.END_X, ok.END_Y, ok.START_X, ok.START_Y})
    return q


def get_hidden_image(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        if not d[ok.IRRW][ok.IMAGE_CHOICE][ok.SWITCH]:
            q -= {ok.IRRW}
            q.update(([(ok.IRRW, (ok.RESIZE,))]))
        else:
            q = set()

            q.update(([(ok.IRRW, ())]))

            if branch_k in FOR_FACE:
                q.update({ok.ANGLE})

            if branch_k == ny.FACE:
                q.update(([(ok.MRW, (ok.FRAME,))]))
            else:
                q.update(([(ok.MRW, ())]))

    do_per(group)
    return q


def get_hidden_image_choice(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        not used

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in (ok.SWITCH, ok.PRESET)}

    if d[ok.SWITCH]:
        n = d[ok.IMAGE_SOURCE]
        q -= {n, ok.AUTOCROP, ok.AS_LAYERS, ok.IMAGE_SOURCE, ok.SLICE}
        is_slice = True

        if d[ok.AS_LAYERS]:
            q -= {ok.LAYER_ORDER}

        if n == ok.FOLDER:
            q -= {ok.FILTER, ok.FOLDER_ORDER, ok.RANDOM_ORDER}
            if d[ok.RANDOM_ORDER]:
                q -= {ok.SEED}
                is_slice = False
                q.update({ok.AS_LAYERS, ok.FOLDER_ORDER, ok.SLICE})
        if is_slice and d[ok.SLICE]:
            q -= {ok.COLUMN_SLICE, ok.ROW_SLICE, ok.SLICE_ORDER}
    return q


def get_hidden_image_gradient(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    n = d[ok.SAMPLE_VECTOR]

    if n != bs.HORIZONTAL:
        q.update({ok.START_Y})

    if n != bs.VERTICAL:
        q.update({ok.START_X})

    if n != bs.DIAGONAL:
        q.update({ok.DIAGONAL_ROTATION})

    # the Show Samples option, '1'
    if d[ok.PREVIEW_MODE] == 1:
        q.update(SHOW_SAMPLES)
    return q


def get_hidden_margin(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        with option value

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    q = {i for i in d if i not in (ok.PER, ok.SWITCH)}

    if d[ok.SWITCH]:
        q = set()

    do_per(group)
    return q


def get_hidden_mask(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i != ok.SWITCH}

    if d[ok.SWITCH]:
        n = d[ok.MASK_TYPE]

        if n == ms.TEXT and not d[ok.TEXT]:
            q -= {ok.MASK_TYPE, ok.TEXT}
        else:
            # hidden Widget key, 'q'
            q = set()

            for k, a in FOR_MASK_D.items():
                if n != k:
                    if isinstance(a, tuple):
                        q.update(a)
                    else:
                        q.update({a})

            if n not in (ms.PARALLELOGRAM_LEFT, ms.PARALLELOGRAM_RIGHT):
                q.update({ok.PARALLELOGRAM_SCALE})

            if n not in (ms.IMAGE, ms.FRINGE):
                q.update({ok.IBR})

            elif n != ms.IMAGE:
                q.update(([(ok.IBR, (ok.IMAGE_CHOICE,))]))

            elif n != ms.FRINGE:
                q.update(([(ok.IBR, (ok.BRUSH_D,))]))

            for sub_type, mask_k in MASK_SUB_TYPE:
                if n != sub_type:
                    q.update({mask_k})

            if n == ms.FRINGE:
                q.update({ok.CUT_OUT, ok.HORZ_SCALE, ok.VERT_SCALE})
            if not d[ok.FEATHER]:
                q.update({ok.STEPS})
    return q


def get_hidden_nail_polish(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()
    n = d[ok.TYPE]

    if n == ff.BACKDROP:
        q.update({ok.IMAGE_CHOICE, ok.PATTERN})

    elif n != ff.IMAGE:
        q.update({ok.IMAGE_CHOICE})

    elif n != ff.PATTERN:
        q.update({ok.PATTERN})
    return q


def get_hidden_noise(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in SWITCH_VISIBLE}

    if d[ok.SWITCH]:
        q = set()
        q.update(
            {
                ff.INK: FOR_METAL_NOISE,
                ff.RIFT: {ok.SPECK_NOISE},
                ff.SPECK: {ok.BLUR, ok.NOISE_AMOUNT},
                ff.WATER: FOR_METAL_NOISE
            }[d[ok.TYPE]]
        )
    return q


def get_hidden_paint_rush(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    # if not colorize
    if not d[ok.CRW][ok.COLORIZE]:
        q.update(FOR_PAINT_RUSH)
    return q


def get_hidden_plaque_key(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        # hidden Widget key, 'q'
        q = set()

        n = d[ok.TYPE]

        if n != dc.IMAGE:
            q.update({ok.IMAGE_CHOICE})

        if n != dc.NETTING:
            q.update({ok.NET_LINE_W, ok.NLS})

        if n not in PLAQUE_COLOR:
            q.update({ok.COLOR_1})

        if n != dc.PATTERN:
            q.update({ok.PATTERN})

        if n not in dc.INVERT_ABLE:
            q.update({ok.IDR})

        if n != dc.GRADIENT:
            q.update(FOR_GRADIENT)

        else:
            # Shape type gradients radiate from the center.
            if d[ok.GRADIENT_TYPE] in fg.SHAPED_TYPE:
                # There's no angle.
                q.update({ok.GRADIENT_ANGLE})

        if n not in (dc.CLOUDS, dc.PLASMA):
            q.update({ok.SEED})

        if n not in FOR_DECO_BLUR:
            q.update({ok.BLUR})
        if branch_k in FOR_FACE:
            q.update({ok.OBEY_MARGINS})
            if branch_k == ny.FACE:
                q.update(([(ok.FRW, (ok.FRAME,))]))

    do_per(group)
    return q


def get_hidden_rect_pattern(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    return {(ok.COLOR_6A, d[ok.COLOR_COUNT])}


def get_hidden_resize(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Resize Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in (ok.PRESET, ok.TYPE)}

    n = d[ok.TYPE]

    if n in FOR_RESIZE_LABEL:
        q -= {n}

    elif n == fz.CROP:
        q -= FOR_CROP

    elif n == fz.FIXED:
        q -= FOR_FIXED

    elif n == fz.FACTOR:
        q -= FOR_FACTOR
    return q


def get_hidden_shadow(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i not in (ok.INTENSITY, ok.PRESET)}

    if d[ok.INTENSITY]:
        q = set()
    return q


def get_hidden_stencil(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = {i for i in d if i != ok.PRESET}

    n = d[ok.FRAME_OVER]

    if n == "None":
        q -= {ok.FRAME_OVER}

    else:
        q = set()
    return q


def get_hidden_switch(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden options, 'q'
    q = {i for i in d if i not in SWITCH_VISIBLE}

    if d[ok.SWITCH]:
        q = set()

    do_per(group)
    return q


def get_hidden_table(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden Widget key, 'q'
    q = set()

    n = d[ok.GRID_TYPE]

    if n == gr.SHAPE_COUNT:
        n1 = d[ok.ECS]

    else:
        n1 = d[ok.CELL_SHAPE]

    if n != gr.CELL_COUNT:
        q.update(FOR_CELL_COUNT)

    if n != gr.CELL_SIZE:
        q.update(FOR_CELL_SIZE)

    if n != gr.SHAPE_COUNT:
        q.update(FOR_SHAPE_COUNT)

    if n not in (gr.CELL_COUNT, gr.CELL_SIZE):
        q.update({ok.CELL_SHAPE})

    if n1 not in sh.DOUBLE:
        q.update({ok.FCI})

    if n1 not in FOR_PARALLELOGRAM:
        q.update({ok.PARALLELOGRAM_SCALE})

    if n not in (gr.CELL_SIZE, gr.SHAPE_COUNT):
        q.update({ok.PIN})

    if n != gr.CELL_COUNT or d[ok.CELL_SHAPE] != sh.RECTANGLE:
        q.update({ok.PER})

    else:
        # The Per option is for merging cells and
        # is pointless if there is only one cell.
        if (
            d[ok.ROW_COUNT] == 1
            and d[ok.COLUMN_COUNT] == 1
        ):
            q.update({ok.PER})

    if ok.PER not in q:
        do_per(group)
    return q


def get_hidden_wrap(group, d, branch_k):
    """
    Make a hidden Widget key set.

    group: AnyGroup
    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden options, 'q'
    q = set()

    if not d[ok.EMBOSS]:
        q.update({ok.CONTRAST, ok.DEPTH, ok.SOFTEN})

    else:
        q.update({ok.COLOR_1})
    return q


def hide_option(group):
    """
    Set option visibility.

    group: AnyGroup
    """
    d = group.widget_d
    branch_k = None
    if group:
        if group.render_key and len(group.render_key) > 2:
            # index for a Model branch (Canvas, Cell, Face, Facing), '1'
            branch_k = group.render_key[1]
        set_visibility(
            d, HIDDEN_KEY[group.item.key](
                group,
                {
                    k: a.get_a()
                    for k, a in d.items()
                    if k not in (bk.RANDOM, ok.PRESET)
                },
                branch_k
            )
        )


def make_tooltip(key, d, tooltip, indent, tip_count):
    """
    Make a tooltip for a Preset.

    key: string
        Identify Preset.

    d: dict
        Preset

    tooltip: string
        WIP

    indent: int
        Is the count of the tab prefix.

    tip_count: int
        Is the number of lines, or rows, in the tooltip.

    Return: string
        tooltip
    """
    n = '\t' * indent if indent else " "

    if tip_count:
        n = '\n' + n

    k = key.split(",")[0] if isinstance(key, basestring) else key[-1]
    tooltip += n + k + " "

    indent += 1
    tip_count += 1

    if not isinstance(d, dict):
        # Is an error, possibly caused by a version mismatch.
        return tooltip

    if (
        (ok.SWITCH in d and not d[ok.SWITCH]) or
        (sk.SHADOW_SWITCH in d and not d[sk.SHADOW_SWITCH][ok.SWITCH])
    ):
        n = '\t' * indent if indent else " "
        return tooltip + '\n' + n + "Off "

    default_d = The.preset.get_init_d(key)

    if not default_d:
        key = get_option_list_key(d)
        d = d[key]
        default_d = The.preset.get_init_d(key)
        tooltip += '\n' + '\t' * indent + key + " "
        indent += 1
        tip_count += 1
        if key == ek.SHADOWY:
            # Is a special case for the Shadow SuperPreset.
            if not d[ok.SHADOW][sk.SHADOW_SWITCH][ok.SWITCH]:
                n = '\t' * indent if indent else " "
                return tooltip + '\n' + n + "Off "
            for i in (sk.SHADOW, sk.SHADOW_SWITCH):
                default_d[ok.SHADOW][wk.SUB].pop(i)

    if default_d and wk.SUB in default_d:
        default_d = default_d[wk.SUB]

    # Need to get visible Widget. Hidden Widget is irrelevant.
    if key in HIDDEN_KEY:
        hidden_q = HIDDEN_KEY[key](None, d, None).union((ok.SWITCH,))
        visible_q = [i for i in d if i not in hidden_q]
        hidden_d = {i[0]: i[1] for i in hidden_q if isinstance(i, tuple)}
        for i in default_d:
            if i in visible_q:
                if wk.TIPPER in default_d[i]:
                    tooltip += '\n'
                    tooltip += default_d[i][wk.TIPPER](
                        d, i, indent, default_d[i]
                    )
                    tip_count += 1
                else:
                    if wk.SUB in default_d[i]:
                        # row
                        is_hide = i in hidden_d
                        e = default_d[i][wk.SUB]
                        for i1 in e:
                            is_show = not is_hide or i1 not in hidden_d[i]
                            if is_show and i1 in d[i]:
                                a = d[i][i1]
                                if isinstance(a, dict):
                                    tooltip = make_tooltip(
                                        i1,
                                        a,
                                        tooltip,
                                        indent,
                                        tip_count
                                    )
                                else:
                                    if wk.TIPPER in e[i1]:
                                        tooltip += '\n'
                                        tooltip += e[i1][wk.TIPPER](
                                            d[i], i1, indent, e[i1]
                                        )
                    else:

                        if isinstance(d[i], dict) and i in HIDDEN_KEY:
                            tooltip = make_tooltip(
                                i, d[i], tooltip, indent, tip_count
                            )
    return tooltip


def set_visibility(d, q):
    """
    Set Widget visibility for an option group.

    d: dict
        option group Widget

    q: set
        of Widget key of Widgets to hide
    """
    g = None
    q1 = {i for i in d.keys()} - q

    # Ensure that common Widget types are always showing.
    q1.update(COMMON_FORMAT)

    for i, g in d.items():
        g.show() if i in q1 else g.hide()

    for i in q:
        if isinstance(i, tuple):
            d[i[0]].update_visibility(i[1])
    if g:
        g.roller_win.resize()


# Each value is a Preset hidden key function.
HIDDEN_KEY = {
    by.GALACTIC_FIELD: get_hidden_galactic_field,
    by.GRADIENT_FILL: get_hidden_gradient,
    by.IMAGE_GRADIENT: get_hidden_image_gradient,
    by.RECT_PATTERN: get_hidden_rect_pattern,
    ek.PAINT_RUSH: get_hidden_paint_rush,
    gk.BORDER: get_hidden_border,
    gk.CAPTION: get_hidden_caption,
    gk.FRINGE: get_hidden_fringe,
    gk.GRADIENT_LIGHT: get_hidden_gradient_light,
    gk.IMAGE: get_hidden_image,
    gk.INNER_SHADOW: get_hidden_shadow,
    gk.MARGIN: get_hidden_margin,
    gk.PLAQUE: get_hidden_plaque_key,
    gk.SHADOW_1: get_hidden_shadow,
    gk.SHADOW_2: get_hidden_shadow,
    gk.SHIFT: get_hidden_switch,
    gk.TYPE_BOX: get_hidden_box,
    gk.TYPE_CELL: get_hidden_cell,
    gk.TYPE_STACK: get_hidden_cell,
    gk.TYPE_TABLE: get_hidden_table,
    ok.BACKGROUND: get_hidden_background,
    ok.BLUR_BEHIND: get_hidden_blur_behind,
    ok.BUMP: get_hidden_bump,
    ok.IMAGE_CHOICE: get_hidden_image_choice,
    ok.MASK: get_hidden_mask,
    ok.NOISE_D: get_hidden_noise,
    ok.OVERLAY_FO: get_hidden_frame_over_overlay,
    ok.OVERLAY_NP: get_hidden_nail_polish,
    ok.RESIZE: get_hidden_resize,
    ok.SHADOW_BASIC: get_hidden_shadow,
    ok.STENCIL: get_hidden_stencil,
    ok.STRIPE: get_hidden_switch,
    ok.WRAP: get_hidden_wrap,
    sk.INNER_SHADOW: get_hidden_shadow,
    sk.SHADOW_1: get_hidden_shadow,
    sk.SHADOW_2: get_hidden_shadow
}
ALL_VISIBLE = (
    ok.BACKDROP_STYLE,
    ok.BRUSH_D,
    ok.FILLER_CC,
    ok.FILLER_CP,
    ok.FILLER_LF,
    ok.FILLER_LM,
    ok.FILLER_RM,
    ok.FILLER_RW,
    ok.FILLER_SC,
    ok.FILLER_SG,
    ok.FILLER_SP,
    ok.FILLER_ST,
    ok.INFLUENCE,
    ok.OVERLAY_CF,
    ok.OVERLAY_CP,
    ok.OVERLAY_CU,
    ok.SHADOW,
    ok.TAPE,
    ok.WRAP_CB,
    ok.WRAP_CF,
    ok.WRAP_CP,
    ok.WRAP_CS,
    ok.WRAP_CU,
    ok.WRAP_NP
)

HIDDEN_KEY.update({k: all_visible for k in ALL_VISIBLE})
HIDDEN_KEY.update({k: all_visible for k in by.KEY_LIST if k not in HIDDEN_KEY})
HIDDEN_KEY.update({k: all_visible for k in ek.KEY_LIST if k not in HIDDEN_KEY})
