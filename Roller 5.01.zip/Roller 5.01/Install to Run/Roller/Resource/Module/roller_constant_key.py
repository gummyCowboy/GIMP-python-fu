#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Keyword class modules have two letter import variables
# that are unique in the context of the program.
# As a rule, two letter variables are either import classes,
# enumerated single letter typed variable names, or
# single letter typed variable names with an underscore.
_BORDER = "Border"
_BOX = "Box"
_BUMP = "Bump"
_CANVAS = "Canvas"
_CAPTION = "Caption"
_CELL = "Cell"
_CELL_SHAPE = "Cell Shape"
_COLOR_PIPE = "Color Pipe"
_CORNER_TAPE = "Corner Tape"
_FACE = "Face"
_FACING = "Facing"
_FRINGE = "Fringe"
_IMAGE = "Image"
_INNER_SHADOW = "Inner Shadow"
_JAGGED_EDGE = "Jagged Edge"
_MARGIN = "Margin"
_MASK = "Mask"
_PLAN = "Plan"
_PLAQUE = "Plaque"
_PRESET = "Preset"
_PROPERTY = "Property"
_RANDOM = "Random"
_RECTANGLE = "Rectangle"
_RESIZE = "Resize"
_SHADOW = "Shadow"
_SHADOW_1 = "Shadow #1"
_SHADOW_2 = "Shadow #2"
_SHIFT = "Shift"
_STEPS = "Steps"
_SWITCH = "Switch"
_TYPE = "Type"
LIST_SEPARATOR = "@"


class BackdropStyle:
    """Are group key that identify a Backdrop Style. Import as 'by'."""
    ACRYLIC_SKY = "Acrylic Sky"
    AVERAGE_COLOR = "Average Color"
    BACK_GAME = "Back Game"
    CLAY_CHEMISTRY = "Clay Chemistry"
    COLOR_FILL = "Color Fill"
    COLOR_GRID = "Color Grid"
    CRYSTAL_CAVE = "Crystal Cave"
    CORE_DESIGN = "Core Design"
    CUBE_PATTERN = "Cube Pattern"
    CUBISM_COVER = "Cubism Cover"
    DENSITY_GRADIENT = "Density Gradient"
    DROP_ZONE = "Drop Zone"
    ETCH_SKETCH = "Etch Sketch"
    FLOOR_SAMPLE = "Floor Sample"
    GALACTIC_FIELD = "Galactic Field"
    GLASS_GAW = "Glass Gaw"
    GRADIENT_FILL = "Gradient Fill"
    HISTORIC_TRIP = "Historic Trip"
    IMAGE_GRADIENT = "Image Gradient"
    LINE_STONE = "Line Stone"
    LOST_MAZE = "Lost Maze"
    MAZE_BLEND = "Maze Blend"
    MYSTERY_GRATE = "Mystery Grate"
    NANO_SUIT = "Nano Suit"
    NOISE_RIFT = "Noise Rift"
    PAPER_WASTE = "Paper Waste"
    PATTERN_FILL = "Pattern Fill"
    RAINBOW_VALLEY = "Rainbow Valley"
    RECT_PATTERN = "Rectangle Pattern"
    ROCKY_LANDING = "Rocky Landing"
    SOFT_TOUCH = "Soft Touch"
    SPECIMEN_SPECKLE = "Specimen Speckle"
    SPIRAL_CHANNEL = "Spiral Channel"
    SQUARE_CLOUD = "Square Cloud"
    STONE_AGE = "Stone Age"
    TRAILING_VINE = "Trailing Vine"
    ROOF_TOP = "Roof Top"
    KEY_LIST = (
        ACRYLIC_SKY,
        AVERAGE_COLOR,
        BACK_GAME,
        CLAY_CHEMISTRY,
        COLOR_FILL,
        COLOR_GRID,
        CORE_DESIGN,
        CRYSTAL_CAVE,
        CUBE_PATTERN,
        CUBISM_COVER,
        DENSITY_GRADIENT,
        DROP_ZONE,
        ETCH_SKETCH,
        FLOOR_SAMPLE,
        GALACTIC_FIELD,
        GLASS_GAW,
        GRADIENT_FILL,
        HISTORIC_TRIP,
        IMAGE_GRADIENT,
        LINE_STONE,
        LOST_MAZE,
        MAZE_BLEND,
        MYSTERY_GRATE,
        NANO_SUIT,
        NOISE_RIFT,
        PAPER_WASTE,
        PATTERN_FILL,
        RAINBOW_VALLEY,
        RECT_PATTERN,
        ROCKY_LANDING,
        ROOF_TOP,
        SOFT_TOUCH,
        SPECIMEN_SPECKLE,
        SPIRAL_CHANNEL,
        SQUARE_CLOUD,
        STONE_AGE,
        TRAILING_VINE
    )


class Button:
    """Has keys used by a Button Widget. Import as 'bk'."""
    ACCEPT = "Accept"
    ACCEPT_ALL = "Accept All"
    ACCEPT_NONE = "Accept None"
    ADD_COLUMN = 'Add Column'
    DEL_MODEL = 'del model'
    CANCEL = "Cancel"
    DRAFT = "Draft"
    MANAGE_PRESET = 'manage preset'
    MINUS = 'minus'
    MOVE_DOWN = 'move down'
    MOVE_UP = 'move up'
    OPEN = "Open…"
    PEEK = "Peek"
    PLAN = _PLAN
    NEW_MODEL = 'new model'
    PREVIEW = "Preview"
    RANDOM = _RANDOM
    RENAME = 'rename'
    REVISE = 'revise'
    SHELVE = "Shelve"
    SUBTRACT_COLUMN = 'Subtract Column'
    SAVE_PRESET = 'save preset'
    SELECT_ALL = 'select all'
    SELECT_NONE = 'select none'


class Frame:
    """Are a Preset option key that identify Frame output. Import as 'ek'."""
    BALL_JOINT = "Ball Joint"
    BORDER_LINE = "Border Line"
    BRUSH_PUNCH = "Brush Punch"
    CAMO_PLANET = "Camo Planet"
    CERAMIC_CHIP = "Ceramic Chip"
    CIRCLE_PUNCH = "Circle Punch"
    CLEAR_FRAME = "Clear Frame"
    COLOR_BOARD = "Color Board"
    COLOR_PIPE = _COLOR_PIPE
    CORNER_TAPE = _CORNER_TAPE
    CRUMBLE_SHELL = "Crumble Shell"
    CUTOUT_PLATE = "Cutout Plate"
    FEATHER_STEP = "Feather Step"
    FRAME_OVER = "Frame Over"
    GRADIENT_LEVEL = "Gradient Level"
    HOT_GLUE = "Hot Glue"
    JAGGED_EDGE = _JAGGED_EDGE
    LINE_FASHION = "Line Fashion"
    LINK_MIRROR = "Link Mirror"
    NAIL_POLISH = "Nail Polish"
    PAINT_RUSH = "Paint Rush"
    RAD_WAVE = "Rad Wave"
    RAISED_MAZE = "Raised Maze"
    SHAPE_BURST = "Shape Burst"
    SQUARE_CUT = "Square Cut"
    SQUARE_PUNCH = "Square Punch"
    STAINED_GLASS = "Stained Glass"
    STRETCH_TRAY = "Stretch Tray"
    SHADOWY = "Shadowy"
    STICKY_WOBBLE = "Sticky Wobble"
    WIRE_FENCE = "Wire Fence"
    KEY_LIST = (
        BALL_JOINT,
        BORDER_LINE,
        BRUSH_PUNCH,
        CAMO_PLANET,
        CERAMIC_CHIP,
        CIRCLE_PUNCH,
        CLEAR_FRAME,
        COLOR_BOARD,
        COLOR_PIPE,
        CORNER_TAPE,
        CRUMBLE_SHELL,
        CUTOUT_PLATE,
        FEATHER_STEP,
        FRAME_OVER,
        GRADIENT_LEVEL,
        HOT_GLUE,
        JAGGED_EDGE,
        LINE_FASHION,
        LINK_MIRROR,
        NAIL_POLISH,
        PAINT_RUSH,
        RAD_WAVE,
        RAISED_MAZE,
        SHADOWY,
        SHAPE_BURST,
        SQUARE_CUT,
        SQUARE_PUNCH,
        STAINED_GLASS,
        STICKY_WOBBLE,
        STRETCH_TRAY,
        WIRE_FENCE
    )
    DECO_KEY_LIST = list(KEY_LIST)[:]
    for i in (
        BALL_JOINT,
        CORNER_TAPE,
        CUTOUT_PLATE,
        FRAME_OVER,
        NAIL_POLISH,
        SHAPE_BURST
    ):
        DECO_KEY_LIST.pop(DECO_KEY_LIST.index(i))


class Group:
    """
    Is a key for an AnyGroup. A comma splits a string to make a
    suitable label as in the case of a Node item. Import as 'gk'.
    """
    BACKDROP = "Backdrop"
    DECO = "Deco"
    GLOBAL = "Global"
    GRADIENT_LIGHT = "Gradient Light"
    MODEL = "Model"
    PROPERTY = _PROPERTY
    SWITCH = _SWITCH

    # Shadow
    INNER_SHADOW = _INNER_SHADOW
    SHADOW_1 = _SHADOW_1
    SHADOW_2 = _SHADOW_2
    SHADOW_PRESET = _PRESET + ", " + _SHADOW

    # shared by Model
    BORDER = _BORDER
    CAPTION = _CAPTION
    FRINGE = _FRINGE
    IMAGE = _IMAGE
    MARGIN = _MARGIN
    PLAQUE = _PLAQUE
    RECTANGLE = _RECTANGLE
    SHIFT = _SHIFT
    TYPE = _TYPE

    # Box
    TYPE_BOX = "Type, Box"

    # Cell Model
    TYPE_CELL = "Type, Cell"

    # Pyramid
    TYPE_PYRAMID = "Type, Pyramid"

    # Stack
    TYPE_STACK = "Type, Stack"

    # Sidewalk
    TYPE_SIDEWALK = "Type, Sidewalk"

    # Table
    TYPE_TABLE = "Type, Table"

    # SuperPreset
    PRESET_BOX = "Preset, Box"
    PRESET_CELL = "Preset, Cell"
    PRESET_PYRAMID = "Preset, Pyramid"
    PRESET_SIDEWALK = "Preset, Sidewalk"
    PRESET_STACK = "Preset, Stack"
    PRESET_STEPS = "Preset, Steps"
    PRESET_TABLE = "Preset, Table"
    PRESET_SHADOW = "Preset, Shadow"
    SUPER_MODEL = (
        PRESET_BOX,
        PRESET_CELL,
        PRESET_PYRAMID,
        PRESET_SIDEWALK,
        PRESET_STACK,
        PRESET_TABLE
    )

    # Window
    CELL_EDITOR = 'cell editor'
    DEFINE_MODEL = "Define Model"
    MODEL_NAME = "Model Name"
    MODEL_TREE = "Model Tree"

    PRESET = _PRESET
    IMAGE_SOURCE_USER = _BORDER, FRINGE, IMAGE, PLAQUE, BACKDROP
    STEPS_DEFAULT = [GLOBAL, GRADIENT_LIGHT, BACKDROP, MODEL, PRESET_STEPS]


gk = Group


class Image:
    """Are image related. Import as 'ik'."""
    LOOP = 'loop'
    LOOP_DICT = 'loop_dict'
    NEXT = 'next'
    NEXT_DICT = 'next_dict'
    PREVIOUS = 'previous'
    PREVIOUS_DICT = 'previous_dict'
    SLICE = 'slice'


class Item:
    """Are used in a Node list. Import as 'ie'."""
    BORDER = _BORDER
    CANVAS = _CANVAS
    CAPTION = _CAPTION
    CELL = _CELL
    FACE = _FACE
    FACING = _FACING
    FRINGE = _FRINGE
    IMAGE = _IMAGE
    MARGIN = _MARGIN
    PLAQUE = _PLAQUE
    PRESET = _PRESET
    PROPERTY = _PROPERTY
    RECTANGLE = _RECTANGLE
    SHIFT = _SHIFT
    TYPE = _TYPE


class Model:
    """Has keys used by a Model. Import as 'md'."""
    BOX = _BOX
    CELL = _CELL
    PYRAMID = "Pyramid"
    SIDEWALK = "Sidewalk"
    STACK = "Stack"
    TABLE = "Table"

    # The model has only one cell.
    ONE_CELL = CELL, STACK

    # Model type
    MODEL_TYPE_LIST = BOX, CELL, PYRAMID, SIDEWALK, STACK, TABLE
    MODEL_TYPE_DICT = {
        gk.TYPE_BOX:  BOX,
        gk.TYPE_CELL: CELL,
        gk.TYPE_PYRAMID: PYRAMID,
        gk.TYPE_STACK: STACK,
        gk.TYPE_SIDEWALK: SIDEWALK,
        gk.TYPE_TABLE: TABLE
    }

    # Model branch format used in PortDefineModel.
    CHECKBUTTON_KEY = "{},{}"


md = Model


class ModelList:
    """
    Are key used by the ModelList value dict. Import as 'ml'.
    """
    MODEL_DEF = 'model_def'
    SHELVED = 'shelved'
    ACTIVE = 'active'

    # indices for the ModelList's 'self._items'
    NAME_INDEX, TYPE_INDEX = 0, 1


class Node:
    """Are used to identify a Node. Import as 'ny'."""
    CANVAS = _CANVAS
    CELL = _CELL
    FACE = _FACE
    FACING = _FACING

    # SuperPreset
    SHADOW = _SHADOW
    STEPS = _STEPS


ny = Node


class Option:
    """
    Each is a key for a Widget option or a vote cast.

    A descriptor with a comma makes the key unique, and a typical
    label will only display the string before the comma.

    An underline in a key value is the signature of a cast key. A cast
    key is not a Widget key but is used for casting an AnyGroup vote.

    Import as 'ok'.
    """
    ADD_OFFSET_X = "Add Offset X"
    ADD_OFFSET_Y = "Add Offset Y"
    AMPLITUDE = "Amplitude"
    ANGLE = "Angle"
    ANGLE_JITTER = "Angle Jitter"
    ANGLE_SHIFT = "Angle Shift"
    AS_LAYERS = "Decompose As Layers"
    AUTOCROP = "Auto-Crop"
    AZIMUTH = "Light Azimuth"
    BACKDROP = "Backdrop"
    BACKDROP_STYLE = "Backdrop Style"
    BACKGROUND = "Background"
    BEVEL_W = "Bevel Width"
    BLEND = "Blend"
    BLOCK_H = "Block Height"
    BLOCK_W = "Block Width"
    BLUR = "Blur"
    BLUR_BEHIND = "Blur Behind"
    BLUR_BEHIND_COLOR_1 = "Blur Behind Color #1"
    BLUR_BEHIND_COLOR_2 = "Blur Behind Color #2"
    BLUR_X = "Blur X"
    BLUR_Y = "Blur Y"
    BORDER = _BORDER
    BORDER_W = "Border Width"
    BOTTOM = "Bottom"
    BOX_TYPE = "Box Type"
    BRUSH = "Brush"
    BRUSH_ANGLE = "Brush Angle"
    BRUSH_D = "Brush, Group"
    BRUSH_HARDNESS = "Brush Hardness"
    BRUSH_SIZE = "Brush Size"
    BRUSH_SPACING = "Brush Spacing"
    BRW = 'BRW'                                 # Bump type row
    BUMP = _BUMP
    BUMP_DEPTH = "Bump Depth"
    CAMO_TYPE = "Camo Type"
    CELL_COUNT = "Cell Count"
    CELL_H = "Cell Height"
    CELL_SHAPE = _CELL_SHAPE
    CELL_SIZE = "Cell Size"
    CELL_W = "Cell Width"
    CFW = "Canvas Frame Width"
    CIR = 'CIR'                                 # Color 1, Image Choice, row
    CIRCLE_DIAMETER = "Circle Diameter"
    CLIP_TO_CELL = "Clip to Cell"

    # Color options have a naming scheme.
    # "Color", number of colors, with alpha 'A'
    COLOR_1 = "Color, 1"
    COLOR_1A = "Color, 1A"
    COLOR_2A = "Color, 2A"
    COLOR_3 = "Color, 3"
    COLOR_3A = "Color, 3A"
    COLOR_6 = "Color, 6"
    COLOR_6A = "Color, 6A"

    COLOR_1_MODE = "Color #1 Mode"
    COLOR_2_MODE = "Color #2 Mode"
    COLOR_COUNT = "Color Count"
    COLOR_GRID_TYPE = "Color Grid Type"
    COLORIZE = "Colorize"
    COLORIZE_OPACITY = "Colorize Opacity"
    COLUMN = "Column"
    COLUMN_1 = "Column #1"
    COLUMN_2 = "Column #2"
    COLUMN_COUNT = "Column Count"               # int/float
    COLUMN_COUNT_Q = "Column Count"             # list
    COLUMN_SLICE = "Column Slice Count"
    COLUMN_W = "Column Width"
    COMPONENT = "Color Component"
    CONTRACT = "Contract"
    CONTRAST = "Contrast"
    CORNER_TYPE = "Corner Type"
    CORNER_SHIFT = "Corner Shift"
    COVER = "Cover"
    CRITERION = "Criterion"
    CROP_H = "Crop Height"
    CROP_W = "Crop Width"
    CROP_X = "Crop Offset X"
    CROP_Y = "Crop Offset Y"
    CRW = 'CRW'                                 # CheckButton row
    CURVE = "Curve"
    CUT_OUT = "Cut-Out"
    DELETE_PLAN = "Delete Plan output on exit."
    DEPTH = "Depth"
    DESATURATE = "Desaturate"
    DIAGONAL_ROTATION = "Diagonal Rotation"
    DIRECTION = "Direction"
    DISTRESS = "Distress"
    ECS = "Equilateral Cell Shape"
    EDGE_MODE = "Edge Mode"
    EDGE_TYPE = "Edge Type"
    ELEVATION = "Elevation"
    EMBOSS = "Emboss"
    END_X = "End X"
    END_Y = "End Y"
    FIW = "Factor of Image Width"
    FCI = "First Cell Indented"
    FCR = 'FCR'                                 # Font, Color 1, row
    FEATHER = "Feather"
    FIH = "Factor of Image Height"
    FILE = "File"
    FILL_MODE = "Fill Paint Mode"
    FILL_OPACITY = "Fill Opacity"
    FILLED = "Filled Cell"
    FILLER_CC = "Filler, Ceramic Chip"
    FILLER_CP = "Filler, Circle Punch"
    FILLER_LF = "Filler, Line Fashion"
    FILLER_LM = "Filler, Link Mirror"
    FILLER_RM = "Filler, Raised Maze"
    FILLER_RW = "Filler, Rad Wave"
    FILLER_SC = "Filler, Square Cut"
    FILLER_SG = "Filler, Stained Glass"
    FILLER_SP = "Filler, Square Punch"
    FILLER_ST = "Filler, Stretch Tray"
    FILLER_WF = "Filler, Wire Fence"
    FILTER = "Filter"
    FIT_IMAGE = "Fit image to render"
    FIXED_SIZE_H = "Fixed Size Height"
    FIXED_SIZE_W = "Fixed Size Width"
    FLIP_R = 'flip r'
    FLIP_H = "Flip Horizontal"
    FLIP_V = "Flip Vertical"
    FOLDER = "Folder"
    FOLDER_ORDER = "Folder Order"
    FONT = "Font"
    FONT_SIZE = "Font Size"
    FRAME = "Frame"
    FRAME_OVER = "Frame Over"
    FRINGE = _FRINGE
    FRW = 'FRW'                                 # Frame type row
    GAP_W = "Gap Width"
    GLASS_PANE_W = "Glass Pane Width"
    GPR = 'GPR'                                 # Gradient, Pattern, Image Choice
    GRADIENT = "Gradient"
    GRADIENT_ANGLE = "Gradient Angle"
    GRADIENT_DIRECTION = "Gradient Direction"
    GRADIENT_MODE = "Gradient Mode"
    GRADIENT_OPACITY = "Gradient Opacity"
    GRADIENT_TYPE = "Gradient Type"
    GREY_SCALE = "Grey Scale"
    GRID_SIZE = "Grid Size"
    GRID_TYPE = "Grid Type"
    GRR = 'GRR'                                 # Gradient, Random, row
    HEIGHT = "Height"
    HEIGHT_MOD = "Height Mod"
    HEXAGON_TYPE = "Hexagon Type"
    HORZ_COUNT = "Horizontal Count"
    HORZ_SCALE = "Horizontal Scale"
    IBR = 'IBR'                                 # Image Choice, Brush, row
    IDF = 'IDF'                                 # Invert, Desaturate, Flip V
    IDK = 'IDK'                                 # Invert, Desaturate, Keep Gradient
    IDR = 'IDR'                                 # Invert, Desaturate, row
    IDT = 'IDT'                                 # Invert, Saturate, Texture
    IFR = 'IFR'                                 # Flip V, Random, row
    IFRW = 'IFRW'                               # Invert, Flip V, row
    IMAGE = _IMAGE
    IMAGE_CHOICE = "Image, Choice"
    IMAGE_NAME = "Image Name"
    IMAGE_SOURCE = "Image Source"
    INFLUENCE = "Influence"
    IGR = 'IGR'                                 # Influence, Gradient, Random
    INNER_FRAME_W = "Inner Frame Width"
    INTENSITY = "Intensity"
    INVERT = "Invert"
    INWARD = "Inward"
    IRR = 'IRR'                                 # Invert, Saturate, Reverse
    IRRW = 'IRRW'                               # Image Choice, Resize, row
    IS_BACK = 'is_back'
    IS_CHAIN = 'is_chain'
    IS_EMBOSS = 'is_emboss'
    IS_MAIN = 'is_main'
    IS_NEW = 'is_new'
    IS_PLANNED = 'is_planned'
    IS_ROTATE = 'is_rotate'
    IS_SEED = 'is_seed'
    ITERATIONS = "Iterations"
    JITTER_H = "Jitter Height"
    JITTER_W = "Jitter Width"
    JITTER_X = "Jitter X"
    JITTER_Y = "Jitter Y"
    JUSTIFICATION = "Justification"
    KEEP_GRADIENT = "Keep the Gradient"
    LAYER_COUNT = "Layer Count"
    LAYER_ORDER = "Layer Order"
    LEAD = 'lead'
    LEFT = "Left"
    LENGTH = "Length"
    LENGTH_SHIFT = "Length Shift"
    LIGHTNESS = "Lightness"
    LINE_W = "Line Width"
    LOCKED = "Locked Aspect Ratio"
    LOOP_X = "Loop Index"
    LTR = 'LTR'                                 # Lead, Trail, row
    MARGIN = "Margin"
    MASK = _MASK
    MBF = 'MBF'                                 # Mask, Bump, Frame
    MASK_TYPE = "Mask Type"
    MESH_SIZE = "Mesh Size"
    MESH_TYPE = "Mesh Type"
    METAL = "Metal"
    MODE = "Mode"
    MODEL_LIST = "Model List"
    MODEL_TYPE = 'model type'
    MRW = 'MRW'                                 # Mask type row
    MSS = 'MSS'                                 # Margin, Shadow, Stripe
    NAME = "Name"
    NBR = 'NBR'                                 # Noise, Blur Behind, row
    NEATNESS = "Neatness"
    NET_LINE_W = "Net Line Width"
    NEXT_X = "Next Index"
    NLS = "Net Line Spacing"
    NODE = 'node'
    NOISE = "Noise"
    NOISE_AMOUNT = "Noise Amount"
    NOISE_D = "Noise, Group"
    NOISE_OPACITY = "Noise Opacity"
    NUMERIC_SEQUENCE = "Numeric Sequence"
    OBEY_MARGINS = "Obey Margins"
    OCR = 'OCR'                                 # Obey Margin, Clip to Cell, row
    OCTAGON_TYPE = "Octagon Type"
    OFFSET = "Offset"
    OFFSET_X = "Offset X"
    OFFSET_Y = "Offset Y"
    OPACITY = "Opacity"
    OPAQUE = "Opaque"
    OTHER = "Other"
    OVERLAY_CF = "Overlay, Color"
    OVERLAY_CP = "Overlay, Camo Planet"
    OVERLAY_CU = "Overlay, Cutout Plate"
    OVERLAY_FO = "Overlay, Frame Over"
    OVERLAY_NP = "Overlay, Nail Polish"
    PATTERN = "Pattern"
    PATTERN_1 = "Pattern #1"
    PATTERN_2 = "Pattern #2"
    PATTERN_3 = "Pattern #3"
    P3R = 'P3R'                                 # Pattern, Pattern, Pattern
    PARALLELOGRAM_SCALE = "Parallelogram Scale"
    PATTERN_SIZE = "Pattern Size"
    PER = "Per"
    PIN = "Pin"
    PLANNER = "Planner"
    PLAQUE = _PLAQUE
    PNR = 'PNR'                                 # Pattern, Noise, row
    POSITION_X = "Position X"
    POSITION_Y = "Position Y"
    POST_BLUR = "Post Blur"
    POWER = "Noise Power"
    PRESET = _PRESET
    PREVIEW_MODE = "Preview Mode"
    PREVIOUS_X = "Previous Index"
    PROFILE = "Profile"
    PUPIL_SCALE = "Pupil Scale"
    RANDOM_ORDER = "Random Order"
    RECTANGLE_TYPE = "Rectangle Type"
    RENAME_MODEL = "Rename Model"
    RENDER_H = "Render Height"
    RENDER_W = "Render Width"
    RESIZE = _RESIZE
    REVERSE = "Reverse"
    RIGHT = "Right"
    RKR = 'RKR'                                 # Reverse, Keep Gradient, row
    ROW = "Row"
    ROW_COUNT = "Row Count"
    ROW_H = "Row Height"
    ROW_SLICE = "Row Slice Count"
    SAMPLE_COUNT = "Sample Count"
    SAMPLE_RADIUS = "Sample Radius"
    SAMPLE_VECTOR = "Sample Vector"
    SATURATION = "Saturation"
    SCATTER_COUNT = "Scatter Count"
    SEED = "Random Seed"
    SHADOW = "Shadow"
    SHADOW_COLOR = "Shadow Color"
    SHADOW_BASIC = "Shadow, Basic"
    SHAPE = "Shape"
    SHAPED_TYPE = "Shaped Type"
    SHIFT_DIRECTION = "Shift Direction"
    SHIFT = "Shift"
    SKETCH_TEXTURE = "Sketch Texture"
    SLICE = "Slice"
    SLICE_COUNT = "Slice Count"
    SLICE_ORDER = "Slice Order"
    SMOOTHNESS = "Smoothness"
    SOFTEN = "Soften"
    SPECK_NOISE = "Speck Noise"
    SPIRAL_DISTANCE = "Spiral Distance"
    SPIRAL_MOD = "Spiral Mod"
    SPREAD = "Spread"
    SQUARE_DIMENSION = "Square Dimension"
    SRW = 'SRW'                                 # Shadow type row
    START_NUMBER = "Start Number"
    START_X = "Start X"
    START_Y = "Start Y"
    START_ANGLE = "Start Angle"
    STENCIL = "Stencil"
    STEPS = _STEPS
    STRIPE = "Stripe"
    SUPERPIXEL_SIZE = "Superpixel Size"
    SWITCH = _SWITCH
    TAPE = "Tape"
    TEXT = "Text"
    TEXTURE = "Texture"
    TILE_SIZE = "Tile Size"
    THRESHOLD = "Threshold"
    TOP = "Top"
    TRAIL = 'trail'
    TRANSLUCENT = "Translucent"
    TRIANGLE_TYPE = "Triangle Type"
    TRIM = "Trimmed Side"
    TYPE = "Type"
    UNSHARP_AMOUNT = "Unsharp Amount"
    UNSHARP_RADIUS = "Unsharp Radius"
    UNSHARP_THRESHOLD = "Unsharp Threshold"
    VERT_COUNT = "Vertical Count"
    VERT_SCALE = "Vertical Scale"
    WAVE_AMPLITUDE = "Wave Amplitude"
    WAVE_PER_LAYER = "Waves Per Layer"
    WAVE_PHASE = "Wave Phase"
    WAVELENGTH = "Wavelength"
    WHIRL = "Whirl"
    WIDTH = "Width"
    WIDTH_MOD = "Width Mod"
    WIP = "Work in Progress"
    WIRE_THICKNESS = "Wire Thickness"
    WOBBLE_FACTOR = "Wobble Factor"
    WRW = 'WRW'                                 # Wrap type row
    WRAP = "Wrap"
    WRAP_CF = "Wrap, Clear Frame"
    WRAP_CB = "Wrap, Color Board"
    WRAP_CP = "Wrap, Color Pipe"
    WRAP_CS = "Wrap, Crumble Shell"
    WRAP_CU = "Wrap, Cutout Plate"
    WRAP_NP = "Wrap, Nail Polish"


class Plan:
    """Are keys used by Plan activity. Import as 'ak'."""
    BORDER = _BORDER
    CAPTION = _CAPTION
    CELL_SHAPE = _CELL_SHAPE
    CORNER = "Corner"
    DIMENSION = "Dimension"
    FRINGE = _FRINGE
    GRID = "Grid"
    IMAGE = _IMAGE
    MARGIN = _MARGIN
    NAME = "Name"
    PLAQUE = _PLAQUE
    POSITION = "Position"
    RATIO = "Ratio"
    KEY = (
        BORDER,
        CAPTION,
        CELL_SHAPE,
        CORNER,
        DIMENSION,
        FRINGE,
        GRID,
        IMAGE,
        MARGIN,
        NAME,
        PLAQUE,
        POSITION,
        RATIO
    )


class Preset:
    """Has keys used to initialize a Preset. Import as 'pk'."""
    DEFAULT = "Default"
    DELETE = "Delete"
    SAVE = "Save"


class Render:
    """Are keys used by a Render. Import as 'rd'."""
    PLAN = 'plan'
    WORK = 'work'


class Step:
    """Has keys used by option groups. Import as 'sk'."""
    STEPS = ()
    SELECTED_ROW = 'selected_row'
    BACKDROP = gk.BACKDROP,
    GLOBAL = gk.GLOBAL,
    GRADIENT_LIGHT = gk.GRADIENT_LIGHT,
    MODEL = gk.MODEL,
    PRESET_STEPS = gk.PRESET,
    DEFAULT_STEP = [
        STEPS,
        GLOBAL,
        GRADIENT_LIGHT,
        BACKDROP,
        MODEL,
        PRESET_STEPS
    ]

    # Group key to Step key
    GROUP_2_STEP_D = {
        gk.BACKDROP: BACKDROP,
        gk.GLOBAL: GLOBAL,
        gk.GRADIENT_LIGHT: GRADIENT_LIGHT,
        gk.MODEL: MODEL
    }

    # Shadow
    SHADOW_SWITCH = ny.SHADOW, gk.SWITCH
    SHADOW = _SHADOW,
    SHADOW_PRESET = ny.SHADOW, gk.PRESET
    SHADOW_1 = ny.SHADOW, gk.SHADOW_1
    SHADOW_2 = ny.SHADOW, gk.SHADOW_2
    INNER_SHADOW = ny.SHADOW, gk.INNER_SHADOW

    # Model____________________________________________________________________
    # Box
    BOX_CANVAS = md.BOX, _CANVAS
    BOX_CELL = md.BOX, _CELL
    BOX_FACE = md.BOX, _FACE

    # Cell
    CELL_CELL = md.CELL, _CELL

    # Pyramid
    PYRAMID_CANVAS = md.PYRAMID, _CANVAS
    PYRAMID_CELL = md.PYRAMID, _CELL

    # Sidewalk
    SIDEWALK_CANVAS = md.SIDEWALK, _CANVAS
    SIDEWALK_CELL = md.SIDEWALK, _CELL
    SIDEWALK_FACING = md.SIDEWALK, _FACING

    # Stack
    STACK_CELL = md.STACK, _CELL

    # Table
    TABLE_CANVAS = md.TABLE, _CANVAS
    TABLE_CELL = md.TABLE, _CELL

    # Identify AnyGroup with a visible Per Cell option.
    PER_GROUP = (
        BOX_CELL,
        BOX_FACE,
        PYRAMID_CELL,
        SIDEWALK_CELL,
        SIDEWALK_FACING,
        STACK_CELL,
        TABLE_CELL
    )

    MARGIN_DEPENDENT = _BORDER, _CAPTION, _FRINGE, _IMAGE, _PLAQUE
    MERGE_DEPENDENT = MARGIN_DEPENDENT + (_MARGIN,)

    # Cell branch
    CELL_MARGIN = _CELL, _MARGIN
    CELL_SHIFT = _CELL, _SHIFT
    CELL_TYPE = _CELL, _TYPE


class Widget:
    """
    Has key used to initialize a Widget. A key descriptor
    may become a Widget attribute, hence the underline. Import as 'wk'.
    """
    # tuple of float
    # in .0 to 1.
    # a factor of the space to assign
    # for top, bottom, left, right
    ALIGN = 'align'

    # AnyGroup
    # Use to connect widgets with other widget in their group.
    ANY_GROUP = 'any_group'

    # string
    # Identify the render scale axis as either 'x' or 'y'
    # for RenderPair
    AXIS = 'axis'

    # of gtk.Box classes
    BOX = 'box'

    # int
    # Use with the Rainbow Widget or the Radio Widget.
    # Is the number of ColorButtons in the Rainbow Widget.
    # Is the number of Radio Buttons in the Radio group.
    BUTTON_COUNT = 'button_count'

    # a 2D list from Cell Table to its SwitchButton
    CELL_TABLE = 'cell_table'

    # None value
    # Is a flag to identify an option as not having change.
    # Use to screen out an option's change checker.
    CHANGELESS = 'changeless'

    # Use with Entry's string length allocation.
    CHARS = 'chars'

    # string
    # Use with the Choice Window.
    CHOICE = 'choice'

    # int
    # for Event boxes
    COLOR = 'color'

    # int
    # a Node's cubby index
    COLUMN = 'column'

    # string
    # for a Widget Table
    # Is a label string for the left-side of a Table.
    COLUMN_TEXT = 'column_text'

    # GTK container
    CONTAINER = 'container'

    # class
    # type of Window
    DIALOG = 'dialog'

    # Call to get a value for a Widget range.
    FUNCTION = 'function'

    # function
    # Call to get the value of a widget.
    GET_A = 'get_a'

    # Is Widget with the proper get_a and set_a function.
    GREATER_G = 'greater_g'

    # GTK Window or Dialog
    GTK_WIN = 'gtk_win'

    # boolean
    # for ColorButton
    # When its true, the ColorButton has an alpha value.
    HAS_ALPHA = 'has_alpha'

    # boolean
    # When True, an AnyGroup has a Randomize button.
    HAS_RANDOM = 'has_random'

    # boolean
    # When True, an AnyGroup has a Preset button.
    HAS_PRESET = 'has_preset'

    # boolean
    # Use to change Item behavior when a Label
    # is not needed for a switchable Preset.
    HAS_SWITCH = 'has_switch'

    # string
    # Is an optional header for a TreeViewList.
    HEADER = 'header'

    # undefined
    # If present in a Widget init argument dict, then
    # AnyGroup will load the group's default dict.
    IS_DEFAULT = 'is_default'

    # bool
    # Identify a Face. Used by PortPer and PortCellEditor.
    IS_FACE = 'is_face'

    # undefined
    # Pass to AnyGroup to have it skip widget creation.
    IS_NONE = 'is_none'

    # string
    # Identify layer dependency type.
    ISSUE = 'issue'

    # Item
    # Pass to Node to populate its list.
    ITEM = 'item'

    # string
    # option group
    KEY = 'key'

    # iterable
    # Use with Row.
    KEYS = 'keys'

    # int
    # Use when creating a RadioButton.
    LABEL_X = 'label_x'

    # tuple
    # low, high
    # limit self value range of a Slider
    LIMIT = 'limit'

    # int
    # Set the minimum width of a TreeViewList column.
    MINIMUM_W = 'minimum_w'

    # function
    # a callback for an Accept Button
    ON_ACCEPT = 'on_accept'

    # function
    # a callback for a Cancel Button
    ON_CANCEL = 'on_cancel'

    # function
    # Is a callback for a ProcessButton override.
    ON_DIALOG_CLOSE = 'on_dialog_close'

    # tuple
    # Alignment padding
    PADDING = 'padding'

    # numeric value
    # Use with Slider to initialize the GTK Adjustment.
    PAGE_INCR = 'page_incr'

    # int
    # number of digits after the decimal point
    # Is zero for an integer.
    PRECISION = 'precision'

    # RadioButton
    # Is used to define the lead
    # RadioButton for a group of RadioButtons.
    RADIO_GROUP = 'radio_group'

    # tuple
    # Define a random-function limitation.
    RANDOM_Q = 'random_q'

    # tuple
    # (row, column) cell index
    R_C = 'r_c'

    # list of function
    # Is in the order change callback.
    RELAY = 'relay'

    # tuple
    # Use to configure option view.
    RENDER_KEY = 'render_key'

    # Window class instance
    ROLLER_WIN = 'roller_win'

    # string
    # Is a key for an sub-dict in a Preset.
    ROW_KEY = 'row_key'

    # undefined
    # Pass to a TreeViewList to have it make a scrolled window.
    SCROLL = 'scroll'

    # function
    # Call to set the value of a widget.
    SET_A = 'set_a'

    # custom Widget Signal
    # Use to pass a custom signal to a Widget.
    SIGNAL = 'signal'

    # numeric value
    # Use with Slider to initialize the GTK SpinButton.
    STEP_INCR = 'step_incr'

    # tuple
    # Use to id an AnyGroup.
    # (node item) or (model id, node item, ...)
    NAV_K = 'nav_k'

    # Widget definition group
    SUB = 'sub'

    # string
    # for CheckButton, Label
    TEXT = 'text'

    # function
    # Use to make a tooltip.
    TIPPER = 'tipper'

    # tuple
    # Use to set multiple tooltips.
    TIPS = 'tips'

    # string
    # for a tooltip
    TOOLTIP = 'tooltip'

    # color
    # Use to set the background color of a TreeView.
    TREE_COLOR = 'tree_color'

    # value
    # Use with the AnyGroup definition dict.
    VAL = 'val'

    # Set a Widget class.
    WIDGET = 'widget'

    # string
    # Use to pass a Window's key for storage in the Window position dict.
    WINDOW_KEY = 'window_key'

    # Use when initializing a Widget-type
    # to set a Widget attribute.
    ATTRIBUTE = (
        ALIGN,
        ANY_GROUP,
        COLUMN,
        DIALOG,
        FUNCTION,
        KEY,
        RANDOM_Q,
        ROLLER_WIN,
        ROW_KEY,
        NAV_K,
        TEXT
    )
