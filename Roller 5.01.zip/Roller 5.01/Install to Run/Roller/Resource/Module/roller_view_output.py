#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Output:
    """Factor Work and Plan."""

    def __init__(self):
        self.plan_group = self.backdrop_layer = None
