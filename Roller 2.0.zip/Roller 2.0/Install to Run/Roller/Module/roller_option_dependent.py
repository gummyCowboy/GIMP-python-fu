#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_caster import Effect_
from roller_one_constant import (
    BackdropStyleKey as bsk,
    ForBackdropStyle as fbs,
    ForGradient,
    OptionKey as ok
)

ek = Effect_.Key
BACKDROP_IMAGE_DEPENDENT = ok.BACKDROP_BLUR, ok.FIT_IMAGE, ok.INVERT
MAZES = fbs.FILLED, fbs.COMPOSITION_FRAME, fbs.SCATTERED_MAZES


class OptionDependent:
    """
    Manage dependent image-effect and backdrop-style option widgets.
    """

    def __init__(self, win, stat):
        """
        Initialize variables.

        win: RollerWindow
            responsible owner

        stat: Stat
            globals
        """
        self.win = win
        self.stat = stat

    @staticmethod
    def _init_backdrop_image(option_group):
        """
        Add connections for widget dependencies.

        option_group: OptionGroup
            Has widget list.
        """
        dependent = []

        d = option_group.widget_dict
        button = d[ok.BACKDROP_IMAGE]

        for i in BACKDROP_IMAGE_DEPENDENT:
            g = d[i]
            dependent.append(g)
        button.attach_dependent(dependent)

    def _init_gradient(self, option_group):
        """
        Add connections for widget dependencies.

        option_group: OptionGroup
            Has widget list.
        """
        dependent_widget = []
        d = option_group.widget_dict
        combobox = d[ok.GRADIENT_TYPE]
        combobox.dependent_widget = dependent_widget

        for k in fbs.POINT_KEY:
            if k in d:
                dependent_widget.append(d[k])
        combobox.attach_dependent([self.on_gradient_type_change])

    def _init_jagged_edge(self, option_group):
        """
        Update sub-navigation list for the latest Jagged Edge shadow.

        option_group: OptionGroup
            Has widget list.
        """
        d = option_group.widget_dict
        shadow = d[ok.SHADOW]
        make_opaque = d[ok.MAKE_OPAQUE]
        shadow_blur = d[ok.SHADOW_BLUR]
        intensity = d[ok.INTENSITY]
        shadow_color = d[ok.SHADOW_COLOR]
        shadow.dependent_widget = [
            make_opaque,
            shadow_blur,
            intensity,
            shadow_color
        ]
        shadow.attach_dependent([self.on_shadow_changed])

    def _init_maze_mirror(self, option_group):
        """
        Use to set-up widget dependencies.

        option_group: OptionGroup
            Has widget group info.
        """
        d = option_group.widget_dict
        cell_gap = d[ok.CELL_GAP]
        gap_type = d[ok.GAP_TYPE]
        stop_length = d[ok.STOP_LENGTH]
        scatter_count = d[ok.SCATTER_COUNT]
        maze_type = d[ok.MAZE_TYPE]

        for i in d:
            d[i].widgets = stop_length, cell_gap, scatter_count, gap_type
        for i in (maze_type, gap_type):
            i.attach_dependent([self.on_maze_widget_change])

    def init_widget_state(self, branch, opt_key, option_group):
        """
        Use to set-up widget dependencies.

        branch: Branch
            Has navigation lists.

        opt_key: string
            either effect or style
        """
        self._branch = branch
        d = {
            bsk.BACKDROP_IMAGE: self._init_backdrop_image,
            bsk.BACKDROP_STYLE: self._branch.init_option_list,
            bsk.GRADIENT_FILL: self._init_gradient,
            bsk.SPECIMEN_SPECKLE: self._init_gradient,
            ek.FRAME_GRADIENT: self._init_gradient,
            ek.MAZE_MIRROR: self._init_maze_mirror,
            ek.JAGGED_EDGE: self._init_jagged_edge,
            ek.IMAGE_EFFECT: self._branch.init_option_list
        }
        if opt_key in d:
            d[opt_key](option_group)

    def on_gradient_type_change(self, g):
        """
        Update sub-gradient widget visibility.

        g: RollerComboBox
            Has changed.
        """
        if g.get_value() in ForGradient.SHAPE_BURST:
            for i in g.dependent_widget:
                i.hide()

        else:
            for i in g.dependent_widget:
                i.show()
        self.win.resize()

    def on_maze_widget_change(self, g):
        """
        Update widgets based their dependency to a given widget.

        widget: Widget
            of Maze Mirror
        """
        value = g.get_value()
        k = g.key
        stop_length, cell_gap, scatter_count, gap_type = g.widgets

        if k == ok.MAZE_TYPE:
            if value in MAZES:
                # mazes:
                stop_length.show()

            else:
                stop_length.hide()

            if value in (fbs.FILLED, fbs.COMPOSITION_FRAME):
                for i in (cell_gap, scatter_count, gap_type):
                    i.hide()

            else:
                for i in (cell_gap, scatter_count, gap_type):
                    i.show()

        if k == ok.GAP_TYPE:
            if value == fbs.RANDOM:
                cell_gap.hide()

            else:
                cell_gap.show()
        self.win.resize()

    def on_shadow_changed(self, g):
        """
        Update sub-navigation list with the latest
        selection from the Jagged Edge shadow widget.

        g: Widget
            Jagged Edge ComboBox with shadow options
        """
        option = g.get_value()
        make_opaque, shadow_blur, intensity, shadow_color = g.dependent_widget
        q = shadow_blur, intensity, shadow_color

        if option in (ek.INLAY_SHADOW, ok.NONE):
            make_opaque.hide()

        elif option == ek.DROP_SHADOW:
            make_opaque.show()

        if option in (ek.INLAY_SHADOW, ek.DROP_SHADOW):
            for i in q:
                i.show()

        else:
            # no shadow:
            for i in q:
                i.hide()
        self.win.resize()
