#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_caster import LayerKey
from roller_format_form import Form
from roller_one_base import Comm
from roller_one_constant import (
    CellKey,
    ForLayout,
    FormatKey as fk,
    FreeCellKey as fck,
    OptionKey as ok,
    PlaceKey,
    PropertyKey as pk,
    SessionKey as sk
)
from roller_one_fu import Lay, Sel
import gimp
import gimpfu as fu
import os

pdb = fu.pdb


class RollerImage:
    """Use to manage an open image."""

    # number of valid images:
    image_count = 0

    # An open image already inside GIMP
    # is assigned a RollerImage.
    # The key is an image name from image names.
    # The value is a RollerImage:
    roller_image = {}

    # valid image names:
    image_names = []

    # numeric ordered:
    relative_names = []

    # Has images opened from a file reference.
    # The key is the file path; the value is a RollerImage:
    opened_images = {}

    # Each folder that is in process has an item in "folder_pile".
    # The key is: string; a folder path.
    # The value is: tuple; (a file index, a file list).
    # The file index is: int; an index to the
    # next file to process in the file list.
    #
    # The file list is: list; of file
    # path strings found in the folder.
    folder_pile = {}

    def __init__(self, j, n):
        """
        Create a RollerImage object from
        a corresponding open image.

        j: GIMP image
            Could be None for dummy-usage.

        n: string
            image name
            Could be empty for dummy-usage.
        """
        if j:
            pdb.gimp_selection_none(j)

        self.j = j
        self.image_name = n

        # flag; Is true when a file is to be
        # closed after its first use:
        self.free = 0

        s = (j.width, j.height) if j else (0, 0)
        self.size = self.width, self.height = s

        # 'cell' is the cell rectangle without the margins:
        self.cell = Rect((0, 0), (0, 0))

        # 'pocket' is the cell rectangle with the margins included:
        self.pocket = Rect((0, 0), (0, 0))

        # 'mold' is the image rectangle for the image place.
        # Its value is computed by layout 'mold' functions:
        self.mold = Rect((0, 0), (0, 0))

    @staticmethod
    def close_image(j):
        """
        Close an opened file.

        j: RollerImage
            opened but soon to be closed
        """
        pdb.gimp_image_delete(j.j)
        RollerImage.opened_images.pop(j.path)

    @staticmethod
    def do_blur_behind(stat, session):
        """
        Create a blur-behind layer if one doesn't exist.

        Use an opaque selection of an image
        to blur the area on the blur behind layer.
        """
        def create_blur_layer():
            """
            Create the Blur Behind layer.

            Return:
                z: layer
                    the blur behind layer
            """
            pdb.gimp_image_crop(j, session['w'], session['h'], 0, 0)
            pdb.gimp_edit_copy_visible(j)

            z = Lay.paste(j, image_layer)
            z.name = n

            Lay.order(j, z, parent, offset=Lay.offset(image_layer))
            return z

        j = stat.render.image
        format_list = session[sk.FORMAT_LIST]

        for x in range(len(format_list) - 1, -1, -1):
            d = format_list[x]
            name = d[fk.Layer.NAME]
            blur_behind_layer = None
            parent = stat.render.format_group(x, name)
            image_layer = stat.render.get_image_layer(
                Lay.get_format_name_from_group(parent)
            )
            n = Lay.get_layer_name(
                LayerKey.IMAGE_BLUR_BEHIND,
                parent=parent
            )
            if image_layer:
                pdb.gimp_selection_none(j)
                Lay.hide_format_stack(stat, x)
                Lay.hide_layers_above(parent, image_layer)

                double_space = Form.is_double_space(d)
                row, col = stat.layout.get_division(x)

                for r in range(row):
                    for c in range(col):
                        blur = 1

                        if double_space:
                            blur = Form.is_double_space_cell(
                                r,
                                c,
                                double_space
                            )

                        if blur:
                            blur = Form.get_blur_behind(d, r, c)
                        if blur:
                            if not blur_behind_layer:
                                blur_behind_layer = create_blur_layer()

                            sel = stat.get_image_sel(name, r, c)
                            if sel:
                                Sel.load(j, sel)
                                Lay.blur(j, blur_behind_layer, blur)

                r = ForLayout.FREE_CELL

                for cell in reversed(d[fk.Layer.CELL_LIST]):
                    j1 = RollerImage.get_image(
                        session,
                        cell[PlaceKey.IMAGE_PLACE][PlaceKey.IMAGE]
                    )
                    if j1:
                        blur = cell[pk.IMAGE_PROPERTY][pk.BLUR_BEHIND]
                        if blur:
                            if not blur_behind_layer:
                                blur_behind_layer = create_blur_layer()

                            sel = stat.get_image_sel(
                                cell[fck.CELL][CellKey.NAME],
                                r,
                                r
                            )
                            if sel:
                                Sel.load(j, sel)
                                Lay.blur(j, blur_behind_layer, blur)

                Lay.show_layer_on_top(parent, image_layer)
                Lay.show_format_groups(stat)

                # Clear outside of the blur-behind selection:
                pdb.gimp_selection_none(j)

                for r in range(row):
                    for c in range(col):
                        if Form.get_blur_behind(d, r, c):
                            sel = stat.get_image_sel(name, r, c)
                            if sel:
                                Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

                r = ForLayout.FREE_CELL

                for cell in d[fk.Layer.CELL_LIST]:
                    j1 = RollerImage.get_image(
                        session,
                        cell[PlaceKey.IMAGE_PLACE][PlaceKey.IMAGE],
                    )
                    if j1:
                        blur = cell[pk.IMAGE_PROPERTY][pk.BLUR_BEHIND]
                        if blur:
                            sel = stat.get_image_sel(
                                cell[fck.CELL][CellKey.NAME],
                                r,
                                r
                            )
                            Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
                if Sel.is_sel(j):
                    Sel.clear_outside_of_selection(j, blur_behind_layer)

    @staticmethod
    def _get_file_from_path(n, session):
        """
        Get a RollerImage for a file path.

        Will open a file.

        n: string
            file path

        Return: RollerImage or None
            corresponding with an opened image
        """
        j = None

        # If the image is already opened, then don't re-open:
        if n in RollerImage.opened_images:
            j = RollerImage.opened_images[n]

        else:
            try:
                j1 = pdb.gimp_file_load(n, n)
                j = RollerImage(j1, j1.name)
                RollerImage.opened_images[n] = j
                j.free = session[sk.CLOSE_FILE]
                j.path = n

            except Exception as ex:
                Comm.info_msg(
                    "Roller tried to"
                    " load an image file:\n'{}'\n"
                    "and an error occurred.".format(n)
                )
                Comm.info_msg("The error was:\n" + repr(ex))
                Comm.info_msg(
                    "Roller will use a 'None' reference for the image."
                )
        return j

    @staticmethod
    def _get_image_from_name(n, *_):
        """
        Get a RollerImage corresponding
        with an opened image name.

        n: string
            image name

        Return: RollerImage or None
            corresponding to an opened image
        """
        d = RollerImage.roller_image
        j = RollerImage.roller_image[n] if n in d else None
        return j

    @staticmethod
    def get_image(session, n):
        """
        Get a RollerImage object.

        session: dict
            of session

        n: string
            name of image

        Return: RollerImage or None
            corresponding with an opened image
        """
        if n:
            _file = n if os.path.isfile(n) else "☂not☂a☂file☂"

            for x, q in enumerate((
                RollerImage.relative_names,
                RollerImage.image_names,
                [_file]
            )):
                if n in q:
                    break

            else:
                x += 1

            return (
                RollerImage._get_relative_name_image,
                RollerImage._get_image_from_name,
                RollerImage._get_file_from_path,
                lambda *args: None
            )[x](n, session)

    @staticmethod
    def _get_relative_name_image(n, *_):
        """
        Get a RollerImage corresponding with a numeric index.

        n: string
            relative position

        Return: RollerImage or None
            an opened image
        """
        j = None
        q = RollerImage.relative_names
        d = RollerImage.roller_image

        if n != ok.NONE and n in q:
            x = q.index(n)
            n1 = RollerImage.image_names[x]
            j = d[n1]
        return j

    @staticmethod
    def init_file_list():
        """Reset any file list indices back to zero."""
        d = RollerImage.folder_pile
        for i in d:
            q = d[i]
            d[i] = q[0], 0

    @staticmethod
    def make_image_list():
        """Collect related data for images."""
        # post-fix image number tuple:
        q = pdb.gimp_image_list()[1][::-1]

        # GIMP has an image list:
        q1 = reversed(gimp.image_list())
        d = RollerImage.roller_image
        q2 = RollerImage.image_names = []

        for x, j in enumerate(q1):
            n = j.name + "-" + str(q[x])
            d[n] = RollerImage(j, n)
            q2.append(n)

        # Use 'q2' to map the image numeric sequence to a name:
        RollerImage.image_count = len(q2)

        for i in range(len(q2)):
            go = 1
            while go:
                go = q2.count(q2[i]) - 1
                if go:
                    x = q2.index(q2[i])
                    q2[x] += " (" + str(go) + ")"

        if not q2:
            q2.append(ok.NONE)

        # numeric sequenced:
        if RollerImage.image_count:
            for i in range(len(q)):
                n = str(i + 1)
                a1 = i + 1

                if i == 0 or (a1 > 20 and a1 % 10 == 1):
                    c = n + "st"

                elif i == 1 or (a1 > 20 and a1 % 10 == 2):
                    c = n + "nd"

                elif i == 2 or (a1 > 20 and a1 % 10 == 3):
                    c = n + "rd"

                else:
                    c = n + "th"
                RollerImage.relative_names.append(c + " Image")

        else:
            RollerImage.relative_names.append(ok.NONE)


class Rect(object):
    """Define a rectangle."""

    def __init__(self, position, size):
        """
        Create useful fields.

        position: tuple
            x, y
            of rectangle

        size: tuple
            width, height
            of rectangle
        """
        self.x = position[0]
        self.y = position[1]
        self.width = size[0]
        self.height = size[1]

    @property
    def clone(self):
        """Make a copy of the rectangle and return the copy."""
        return Rect((self.x, self.y), (self.width, self.height))

    @property
    def position(self):
        """Return the rectangle position."""
        return self.x, self.y

    @position.setter
    def position(self, value):
        """Set the rectangle position."""
        self.x, self.y = value

    @property
    def size(self):
        """Return the rectangle size."""
        return self.width, self.height

    @size.setter
    def size(self, value):
        """Set the rectangle size."""
        self.width, self.height = value
