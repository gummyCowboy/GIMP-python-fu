#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_style_gradient_fill import GradientFill
from roller_one import One
from roller_one_constant import ForGradient, ForLayer, OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class LostMaze:
    """Use a maze to create regions, a border, and grid lines."""

    def __init__(self, one):
        """
        Create a Lost Maze backdrop-style.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        self.session = one.session
        d = one.d
        self.option_key = one.k
        j = stat.render.image
        self.group = Lay.group(j, one.k, parent=one.z.parent)
        z = maze_layer = Lay.add(j, one.k, parent=self.group)
        w = one.session['w'] // d[ok.COLUMN]
        h = one.session['h'] // d[ok.ROW]

        pdb.gimp_context_set_foreground((0, 0, 0))
        pdb.gimp_context_set_background((255, 255, 255))
        pdb.plug_in_maze(j, z, w, h, 1, 0, d[ok.RANDOM_SEED], 0, 0)

        z = Lay.clone(j, z)

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        alpha_layer = Lay.clone(j, z)
        alpha_layer.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.gimp_selection_none(j)
        pdb.plug_in_edge(j, maze_layer, 1., 0, 0)

        # Expand the border:
        for _ in range(2):
            Lay.dilate(j, maze_layer)

        pdb.plug_in_colortoalpha(j, maze_layer, (0, 0, 0))

        # horizontal lines:
        h1 = min(max(6, h // 5), one.session['h'])

        RenderHub.do_grid(
            stat,
            z,
            (h1, h1 + 1, 0, (0, 0, 0), 255),
            is_vertical=0
        )
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        z = Lay.merge(j, z)
        e = self.e = deepcopy(ForGradient.LINEAR_DICT)

        e.update(d)

        e[ok.START_X] = e[ok.START_Y] = 1.
        e[ok.END_X] = e[ok.END_Y] = 0.

        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        Sel.item(j, z)

        sel = self.stat.save_selection()

        pdb.gimp_selection_none(j)
        pdb.gimp_image_set_active_layer(j, z)
        self._do_gradient()

        z = pdb.gimp_image_get_active_drawable(j)

        Sel.isolate(j, z, sel)
        RenderHub.do_stylish_shadow(
            stat,
            z,
            blur=8.,
            intensity=140.,
            offset_x=3,
            offset_y=3
        )
        pdb.gimp_selection_none(j)

        # vertical lines:
        z = Lay.add(
            j,
            one.k,
            parent=self.group,
            offset=len(self.group.layers) + 1
        )

        Lay.color_fill(z, (255, 255, 255))
        pdb.gimp_selection_all(j)

        v1 = min(max(12, w // 12), one.session['w'])

        RenderHub.do_grid(stat, z, (v1, v1 + 1, 0, (0, 0, 0), 255))
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
        RenderHub.do_stylish_shadow(
            stat,
            z,
            blur=10,
            intensity=200.,
            d=ForLayer.MAKE_OPAQUE_DICT,
            is_inlay=1
        )
        RenderHub.do_stylish_shadow(stat, z, blur=10, intensity=200.)

        # background:
        e[ok.END_X] = e[ok.START_X] = e[ok.START_Y] = .5
        e[ok.END_Y] = 0.
        e[ok.GRADIENT_TYPE] = "Bilinear"
        z = Lay.add(
            j,
            one.k,
            parent=self.group,
            offset=len(self.group.layers) + 1
        )
        z.opacity = 50.

        pdb.gimp_image_set_active_layer(j, z)
        self._do_gradient()
        Lay.order(j, alpha_layer, self.group, offset=4)
        Lay.blur(j, alpha_layer, 500)
        Lay.blur(j, one.z, 500)

        # grain effect:
        z = Lay.clone(j, alpha_layer)

        Lay.order(j, z, self.group, offset=6)

        z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
        z.opacity = 100.
        pdb.gimp_drawable_invert(z, 0)

    def _do_gradient(self):
        """
        Draw a gradient.

        Use 'self.e' to pass gradient options.
        """
        GradientFill(
            One(
                d=self.e,
                k=self.option_key,
                session=self.session,
                stat=self.stat,
                z=self.stat.render.image.active_layer
            )
        )
