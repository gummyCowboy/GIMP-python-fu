#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_caster import Effect_
from roller_one_constant import (
    BackdropStyleKey as bsk,
    BranchKey as bk,
    OptionKey as ok,
    UIKey
)
from roller_port import Port
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_tree import NavigationList
from roller_option_stat import OptionStat
import gtk


class Branch:
    """Has two navigation lists which form a path to option groups."""

    # Is the length of the backdrop-style sub-steps when a
    # backdrop-style is chosen other than Backdrop Image:
    WITH_BACKDROP_STYLE = 3

    # Is the slot in the sub-steps navigation
    # list for the backdrop-style option:
    BACKDROP_STYLE_INDEX = 2

    # Is the slot in the sub-steps navigation
    # list for the image-effect option:
    IMAGE_EFFECT_INDEX = 1

    def __init__(self, d, g):
        """
        Draw navigation groups.

        d: dict
            Has init values.

        g: GTK HBox
            container for the three Branch groups
        """
        self._window = d[UIKey.WINDOW]
        self.stat = d[UIKey.STAT]
        self._on_key_press = d[UIKey.ON_KEY_PRESS]
        self._make_option_group = d[bk.MAKE_OPTION_GROUP]
        self._offshoot_item = d[bk.OFFSHOOT_ITEM]
        self._trunk_item = d[bk.TRUNK_ITEM]
        k = bk.CHANGE_OFFSHOOT_ITEM
        self._change_offshoot_item = d[k] if k in d else None
        labels = d[bk.LABEL]
        vbox = self._create_box(g, labels[0])

        self._draw_trunk_group(vbox)
        self._window.reduce_color()

        vbox = self._create_box(g, labels[1])

        self._draw_offshoot_group(vbox)
        self._window.reduce_color()

        vbox = self._create_box(g, "")
        self._window.option_group_color = self._window.color
        save_color = self._window.color

        self._draw_option_groups(vbox)
        self._window.color = save_color

    def change_substep(self, g):
        """
        Modify the sub-step of a navigation list
        with an option list selection.

        g: Widget
           ComboBox
           not in use
        """
        Port.loading += 1
        g1 = g.option_group.navigation_list
        opt_key = g.get_value()
        opt_type = g.option_group.opt_type
        is_effect = False

        # Remove previous option:
        if opt_key in Effect_.MAIN:
            # for effect:
            a = len(g1.list_store)
            if a > 1:
                while len(g1.list_store) > 1:
                    g1.remove_item(len(g1.list_store) - 1)
                    g1.group_box.pop(len(g1.group_box) - 1)
            is_effect = True

        else:
            # for backdrop-style:
            if len(g1.list_store) == Branch.WITH_BACKDROP_STYLE:
                g1.remove_item(2)
                g1.group_box.pop(2)

        if is_effect:
            x = Branch.IMAGE_EFFECT_INDEX
            options = OptionStat.get_effect_keys(opt_key)
            for i in options:
                g1.add_item(i)

        else:
            x = Branch.BACKDROP_STYLE_INDEX
            options = []
            if opt_key != bsk.BACKDROP_IMAGE:
                g1.add_item(opt_key)
                options = [opt_key]

        for option in options:
            self._change_offshoot_item(
                g1,
                x,
                option,
                opt_type
            )
            x += 1

        Port.loading -= 1
        self._window.roller_window.resize()

    def _create_box(self, g, label):
        """
        Create a box for the navigation list.

        g: GTK HBox
            container for box

        label: string
            for boxes' label
        """
        box = RollerEventBox(self._window.color)
        vbox = gtk.VBox()

        box.add(vbox)
        g.add(box)
        if label:
            vbox.add(RollerLabel(padding=(2, 0, 4, 0), text=label + ":"))
        return vbox

    def _do_treeview_selection(self, widget, index, has_sel):
        """
        Get and apply the TreeView selection to the sub-step's group box.

        Is recursive.

        widget: GTK widget
            Has children.

        index: int
            index to the sub-steps group
            with selection

        has_sel: flag
            Use to return state of the sub-steps navigation list.
            Is true when there is a row selected.
        """
        q = widget.get_children()
        for g in q:
            if isinstance(g, gtk.TreeView):
                q1 = g.get_selection().get_selected_rows()[1]
                if q1:
                    x = q1[0][0]
                    self._window.on_list_change(self.offshoot[index], x)
                    break
            has_sel = self._do_treeview_selection(g, index, has_sel)
        return has_sel

    def _draw_option_groups(self, g):
        """
        Draw the option groups.

        g: GTK container
            to receive group
        """
        for x, g1 in enumerate(self.offshoot):
            g1.switch_group_box = g
            for i in g1.list_store:
                vbox = gtk.VBox()

                self.offshoot[x].group_box.append(vbox)
                self._make_option_group(
                    vbox,
                    g1,
                    self.trunk.list_store[x][0],
                    i[0]
                )

    def _draw_offshoot_group(self, g):
        """
        Draw the sub-steps group.

        Steps are either for the backdrop and an image-effect.

        g: GTK container
            to receive group
        """
        g1 = self.trunk
        g1.switch_group_box = g
        self.offshoot = []

        for x in range(len(g1.list_store)):
            vbox = gtk.VBox()
            g2 = NavigationList(
                vbox,
                self._window.on_list_change,
                100,
                self._on_key_press
            )

            g2.set_value(self._offshoot_item[x])
            self.offshoot.append(g2)
            g1.group_box.append(vbox)

    def _draw_trunk_group(self, g):
        """
        Draw the steps group.

        Steps are either for the backdrop and an image-effect.

        g: GTK container
            to receive group
        """
        n = self._trunk_item
        g1 = self.trunk = NavigationList(
            g,
            self._window.on_list_change,
            75,
            self._on_key_press,
            item_count=len(n)
        )

        g1.set_value(n)

        # When a row is selected, it emits a signal:
        g1.widget.get_selection().connect('changed', self.on_trunk_selection)

    def init_option_list(self, option_group):
        """
        Add connections for widget dependencies.

        option_group: OptionGroup
            Has widget list.
        """
        d = option_group.widget_dict
        for i in d:
            if d[i].key in (ok.BACKDROP_STYLE, ok.IMAGE_EFFECT):
                d[i].attach_dependent([self.change_substep])

    def on_trunk_selection(self, *_):
        """
        Update the visibility of the target widget box.

        The target widget box is out-of-sync when the trunk selection
        changes, so update the offshoot widget display.
        """
        g = self.trunk
        x = g.get_sel_x()
        if x is not None:
            has_sel = self._do_treeview_selection(g.group_box[x], x, 0)

            # Hide the group boxes when there is no selection:
            if not has_sel:
                for x1 in range(len(g.list_store)):
                    if x1 != x:
                        g = self.offshoot[x1]
                        for box in g.group_box:
                            box.hide()
