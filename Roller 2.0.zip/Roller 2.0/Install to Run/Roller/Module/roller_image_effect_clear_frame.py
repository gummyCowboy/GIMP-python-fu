#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_caster import LayerKey
from roller_one_constant import ForLayer, OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class ClearFrame:
    """Create a translucent border around an image(s)."""

    def __init__(self, one):
        """
        Do the Clear Frame image-effect.

        one: One
            Has variables.
        """
        stat = one.stat
        j = stat.render.image
        frame = [0, 0]
        n = one.k
        d = one.d
        parent = one.parent
        q = ClearFrame._edge_color(d[ok.COLOR])
        z = Lay.group(j, n, parent=parent)
        select_layer = Lay.selectable(
            j,
            stat.render.get_image_layer(
                Lay.get_format_name_from_group(parent)
            ),
            ForLayer.MAKE_OPAQUE_DICT
        )

        # Creates two layers:
        for x in range(2):
            Sel.item(j, select_layer)
            Sel.grow(
                j,
                (d[ok.FRAME_WIDTH] + 5, 5)[x],
                d[ok.FRAME_TYPE]
            )

            z1 = Lay.add(j, n, parent=z)

            Sel.fill(z1, d[ok.COLOR])
            Sel.item(j, select_layer)
            Lay.clear_sel(j, z1)
            frame[x] = ClearFrame._do_edge(j, z, z1, q)

        pdb.gimp_image_remove_layer(j, select_layer)

        # Create frame selection to remove shadow bleed:
        Sel.item(j, frame[0])
        Sel.item(j, frame[1], option=fu.CHANNEL_OP_ADD)

        sel = stat.save_selection()

        # Add shadow and merge:
        z1 = RenderHub.do_shadow(stat, frame[1], 0, 0, 5, (0, 0, 0), 100)

        Lay.order(j, z1, z)

        z1.mode = fu.LAYER_MODE_NORMAL
        frame[0].opacity = 55.
        frame[1].mode = fu.LAYER_MODE_OVERLAY
        z = Lay.merge_group(
            j,
            z,
            n=Lay.get_layer_name(LayerKey.TRANSPARENCY, parent=parent)
        )
        z.opacity = 33.

        Sel.load(j, sel)
        Sel.clear_outside_of_selection(j, z)

    @staticmethod
    def _do_edge(j, z, z1, q):
        """
        Use to create an overlay edge effect
        where the light source is directly above
        the subject.

        j: GIMP image
            work-in-progress

        z: layer
            group layer

        z1: layer
            The layer that is on top.

        q: tuple
            background color (RGB)
            The background color needs to differ from the subject.
            It is used to turn transparent pixels into opaque pixels.

        Return: layer
            the layer with the edge
        """
        edge = Lay.clone(j, z1)
        bg = Lay.new(j, "bg")

        Lay.color_fill(bg, q)
        Lay.place(j, bg, parent=z, offset=1)

        edge = Lay.merge(j, edge)

        pdb.plug_in_edge(
            j,
            edge,
            1.,
            0,
            0
        )
        Sel.item(j, z1)
        Sel.clear_outside_of_selection(j, edge)

        edge.mode = fu.LAYER_MODE_OVERLAY
        return Lay.merge(j, edge)

    @staticmethod
    def _edge_color(q):
        """
        Return an edge color for a color.

        q: tuple
            (red, green, blue)
            of int
            color
        """
        q1 = [0, 0, 0]

        for x, a in enumerate(q):
            q1[x] = 0 if a > 127 else 255
        return tuple(q1)
