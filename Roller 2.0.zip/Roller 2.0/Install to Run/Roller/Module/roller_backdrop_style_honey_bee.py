#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import ForBackdropStyle, ForLayer, OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
mo = Pdb.Mosaic


class HoneyBee:
    """Create a backdrop-style with layers of mosaic tiles."""

    def __init__(self, one):
        """
        Do the Honey Bee backdrop-style.

        one: One
            Has variables.
        """
        d = one.d
        j = one.stat.render.image
        Lay.blur(j, one.z, 500)
        self.group = Lay.group(j, one.k, parent=one.z.parent)
        self.layer = plasma_layer = Lay.clone(j, one.z)

        pdb.plug_in_plasma(j, self.layer, d[ok.RANDOM_SEED], 3)

        # Create alternate textures for light and dark:
        z = self._create_polar_mask(j, is_dark=False)

        Lay.color_fill(z, (255, 255, 127))
        pdb.script_fu_clothify(j, z, 0, 0, 90, 70, 1)

        z = self._create_polar_mask(j, is_dark=True)

        Lay.color_fill(z, (127, 255, 255))
        pdb.plug_in_engrave(j, z, 6, 1)

        z = Lay.clone(j, self.layer)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        Lay.order(j, z, self.group, offset=0)
        pdb.gimp_drawable_invert(z, 0)

        z = Lay.merge_group(j, self.group)

        # Create additional textures for the previous texture:
        self.group = Lay.group(j, one.k, parent=one.z.parent)

        Lay.order(j, z, self.group)

        z = Lay.clone(j, z)

        pdb.plug_in_emboss(j, z, 45, 30, 1, 1)

        z = first = self.layer = Lay.merge_group(j, self.group)
        keep_layer = Lay.clone(j, z)

        Lay.blur(j, keep_layer, d[ok.MESH_SIZE])

        keep_layer.opacity = 50.
        keep_layer.mode = fu.LAYER_MODE_BURN
        self.group = Lay.group(j, one.k, parent=one.z.parent)

        Lay.order(j, z, self.group)

        z = self._create_polar_mask(j, is_dark=False)
        z.mode = fu.LAYER_MODE_OVERLAY

        z = self._create_polar_mask(j, is_dark=True)
        z.mode = fu.LAYER_MODE_BURN

        HoneyBee._do_mosaic(d, j, z)

        z1 = Lay.clone(j, first)
        z1.mode = fu.LAYER_MODE_BURN

        Lay.order(j, z1, self.group, 0)
        pdb.gimp_edit_copy_visible(j)

        z = Lay.paste(j, z1)

        Lay.blur(j, z1, d[ok.MESH_SIZE])

        z1.mode = fu.LAYER_MODE_EXCLUSION

        HoneyBee._do_mosaic(d, j, z)

        z = Lay.clone(j, z)

        pdb.gimp_drawable_invert(z, 0)

        z = Lay.merge_group(j, self.group)

        # Make the mosaic translucent:
        pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

        self.group = Lay.group(j, one.k, parent=one.z.parent)

        Lay.order(j, z, self.group)
        Lay.clone(j, z)
        Lay.blur(j, plasma_layer, 400)
        pdb.gimp_drawable_desaturate(plasma_layer, fu.DESATURATE_LUMINANCE)
        plasma_layer.mode = fu.LAYER_MODE_HSV_VALUE

        # Use shadow to add depth:
        z1 = Lay.merge_group(j, self.group)
        z = RenderHub.do_shadow(
            one.stat,
            z1,
            0,
            0,
            20,
            (0, 0, 0),
            600,
            d=ForLayer.MAKE_OPAQUE_DICT
        )

        z.mode = fu.LAYER_MODE_SPLIT

        pdb.gimp_edit_copy_visible(j)
        pdb.gimp_image_remove_layer(j, z)

        z = Lay.paste(j, z1)
        z.mode = fu.LAYER_MODE_GRAIN_EXTRACT

    def _clone_layer(self, j, z):
        """
        Duplicate a layer.

        j: GIMP image
            with layer

        z: layer
            to duplicate

        Return: layer
            the duplicate
        """
        pdb.gimp_selection_all(j)

        z1 = pdb.gimp_layer_copy(z, 1)

        # Insert the layer above the active layer:
        pdb.gimp_image_set_active_layer(j, z)
        pdb.gimp_image_insert_layer(j, z1, self.group, 0)

        # Perceptual space creates smoother masks:
        pdb.gimp_layer_set_composite_space(
            z,
            fu.LAYER_COLOR_SPACE_RGB_PERCEPTUAL
        )

        # The mask is not needed from the copy:
        if z1.mask:
            z1.remove_mask(fu.MASK_DISCARD)

        pdb.gimp_selection_none(j)
        return z1

    def _create_polar_mask(self, j, is_dark=False):
        """
        Create a base mask, either light or dark.

        j: GIMP image
            work-in-progress

        is_dark: flag
            If it's true, the group is for the dark-type masks.

        Return: layer
            with a polar-type selection
        """
        n = "Dark" if is_dark else "Lights"
        z = self._clone_layer(j, self.layer)

        pdb.gimp_drawable_desaturate(z, fu.DESATURATE_LUMINANCE)

        if is_dark:
            pdb.gimp_drawable_invert(z, 0)

        channel = pdb.gimp_channel_new_from_component(
            j,
            fu.CHANNEL_RED,
            n,
        )

        pdb.gimp_image_insert_channel(j, channel, None, 0)

        # Select the channel to get grayscale pixels where
        # black equates to transparent and white to opaque.
        pdb.gimp_image_select_item(j, fu.CHANNEL_OP_REPLACE, channel)
        mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)

        pdb.gimp_image_remove_layer(j, z)
        pdb.gimp_image_remove_channel(j, channel)

        z = self._clone_layer(j, self.layer)
        z.name = n

        pdb.gimp_layer_add_mask(z, mask)
        return z

    @staticmethod
    def _do_mosaic(d, j, z):
        """
        Create a mosaic pattern.

        j: GIMP image
            work-in-progress

        z: layer
            to receive mosaic
        """
        pdb.plug_in_mosaic(
            j,
            z,
            d[ok.MESH_SIZE],
            mo.TILE_HEIGHT_4,
            mo.TILE_SPACING_1,
            d[ok.NEATNESS],
            mo.NO_SPLIT,
            mo.LIGHT_ANGLE_45,
            mo.MIN_COLOR_VARIATION,
            mo.YES_ANTIALIAS,
            mo.YES_COLOR_AVERAGING,
            ForBackdropStyle.MESH_TYPE.index(d[ok.MESH_TYPE]),
            mo.SMOOTH_SURFACE,
            mo.BLACK_AND_WHITE_GROUT
        )
