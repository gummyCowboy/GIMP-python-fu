#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_caster import LayerKey
from roller_render_shadow import Shadow


class ImageShadow:
    """
    Creates a shadow layer for an image.

    Use with shadow effects.
    """

    def __init__(self, one):
        """
        Make a shadow.

        one: One
            Has variables.
        """
        one.e['caster_key'] = (LayerKey.IMAGE,)
        Shadow(one)
