#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_border_line import BorderLine
from roller_image_effect_caster import Effect_
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

ek = Effect_.Key
pdb = fu.pdb


class CirclePunch(BorderLine):
    """Add round holes to a frame that fits around a BorderLine frame."""

    def __init__(self, one):
        """
        Do the Circle Punch image-effect.

        one: One
            Has variables.
        """
        BorderLine.__init__(
            self,
            one,
            framer=self.make_line_sel,
            filler=lambda *args: None
        )

    def draw_circles(self, j, z, d):
        """
        Draw circles on the rotated layer.

        j: GIMP image
            target image

        z: layer
            target layer

        d: dict
            Has options.
        """
        w, h = j.width, j.height
        diameter = d[ok.CIRCLE_DIAMETER]
        w1 = int(diameter * 1.5)
        x1 = triangle_height = int(w1 * .8660254)
        y = 0

        while y < h:
            Sel.ellipse(j, 0, y, diameter, diameter)
            y += w1

        y = w1 // 2

        while y < h:
            pdb.gimp_ellipse_select(
                j,
                x1,
                y,
                diameter,
                diameter,
                fu.CHANNEL_OP_ADD,
                True,
                True,
                1.
            )
            y += w1

        Sel.fill(z, (0, 0, 0))

        _, x, y, x1, _ = pdb.gimp_selection_bounds(j)
        a = x1 - x
        last_iter = 0

        while 1:
            pdb.gimp_edit_copy(z)

            a *= 2
            z = Lay.paste(j, z)
            x = x1 + triangle_height - diameter

            pdb.gimp_layer_set_offsets(z, x, 0)

            if a > w:
                last_iter += 1

            z = Lay.merge(j, z)

            Sel.item(j, z)

            _, x, y, x1, _ = pdb.gimp_selection_bounds(j)
            if last_iter == 2:
                break
        return z

    def make_line_sel(self, d):
        """
        Modify the current selection with selected circles.

        Add the circle selection to the border selection
        within the bounds of the filler selection.

        d: dict
            Has options.

        Return: state of selection
        """
        j = self.stat.render.image
        border_sel = self.stat.save_selection()
        z = z1 = Lay.add(j, self.option_key, self.parent)
        z = RenderHub.do_rotated_layer(self.stat, z, d, self.draw_circles)

        Sel.item(j, z)

        sel = self.stat.save_selection()

        Sel.load(j, self.fill_sel)
        Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
        Sel.grow(j, 1, 1)
        pdb.gimp_selection_feather(j, 1)
        pdb.gimp_image_remove_layer(j, z)
        pdb.gimp_image_remove_layer(j, z1)
        Sel.load(j, border_sel, option=fu.CHANNEL_OP_ADD)
