#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_cell_table import CellTable
from roller_format_form import Form
from roller_format_widget import FormatWidget
from roller_group_per_cell import GroupPerCell
from roller_one_constant import (
    BranchKey,
    CaptionKey,
    CellKey,
    ForColor,
    ForFormat as ff,
    FormatKey as fk,
    ForWidget as fw,
    FreeCellKey as fck,
    FringeKey,
    PlaqueKey,
    PortCellKey,
    PortKey,
    PresetKey,
    Signal,
    UIKey,
    WidgetKey
)
from roller_one_preset import Preset
from roller_port import Port
from roller_port_cell import PortCell
from roller_port_free_cell import PortFreeCell
from roller_widget_branch import Branch
from roller_widget_button import OptionButton
from roller_widget_check_button import RollerCheckButton
from roller_widget_entry import RollerEntry
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_table import RollerTable
from roller_widget_zlist import ZList
from roller_window_grid import RWGrid
import gtk

COLUMN_0, COLUMN_1 = 0, 1

# For gtk, let it know that the function handled an event:
DONE = 1

PAD = 0, 0, fw.MARGIN, fw.MARGIN
TOTAL_ROW_2 = 2


class PortFormat(Port):
    """Create a layer-centric format."""
    CATEGORY = "Layer", "Grid"
    OPTION_DICT = {}
    SUB_CATEGORY = (
        (
            "Layer",
            "Layer Margins",
            "Layer Plaque",
            "Layer Fringe",
            "Layer Caption",
            "Free-Range Cell"
        ),
        (
            "Cell Grid",
            "Cell Margins",
            "Image Place",
            "Image Property",
            "Image Mask",
            "Cell Plaque",
            "Cell Fringe",
            "Cell Caption"
        )
    )
    TITLE = "Format Editor: {}"

    def __init__(self, d):
        """
        Start it up.

        d: dict
            Has init values.
        """
        layer_group = (
            self._draw_layer_group,
            self._draw_layer_margin,
            self._draw_layer_plaque_group,
            self._draw_layer_fringe_group,
            self._draw_layer_caption_group,
            self._draw_free_range_cell_group
        )
        cell_group = (
            self._draw_grid_group,
            self._draw_cell_margin,
            self._draw_place_group,
            self._draw_property_group,
            self._draw_mask_group,
            self._draw_cell_plaque_group,
            self._draw_cell_fringe_group,
            self._draw_cell_caption_group
        )
        draw_option = layer_group, cell_group
        e = PortFormat.OPTION_DICT
        d[UIKey.PORT_KEY] = PortKey.FORMAT
        self._get_session_dict = d[UIKey.GET_SESSION_DICT]
        self._format_x = d[UIKey.FORMAT_INDEX]
        self._pc_button = []

        for x, n in enumerate(PortFormat.CATEGORY):
            for x1, n1 in enumerate(PortFormat.SUB_CATEGORY[x]):
                if n not in e:
                    e[n] = {}
                e[n][n1] = draw_option[x][x1]

        Port.__init__(self, d)
        self._show_port()

    def _draw_cell_caption_group(self, g):
        """
        Draw the cell caption group.

        g: GTK container
            to receive group
        """
        q = FormatWidget.draw_caption_group(
            bottom_pad=fw.MARGIN // 2,
            sub_type=CaptionKey.CELL_CAPTION,
            color=self.color,
            container=g,
            fraction_of="Cell",
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self._caption_preset = q[-1]
        g = GroupPerCell(
            button_action=self.open_cell_port,
            checkbutton_action=self.on_widget_change,
            container=g,
            get_format_info=self.get_format_info,
            key=fk.Cell.Caption.PER_CELL,
            port=self,
            stat=self.stat,
            text="Cell Caption…",
            widgets=q,
            win=self.roller_window
        )
        self._pc_button += [g.check_button]
        self.controls += [q[-1], g.check_button]
        self.keep([g.button])

    def _draw_cell_fringe_group(self, g):
        """
        Draw the cell fringe group.

        g: GTK container
            for widget group
        """
        q = FormatWidget.draw_fringe_group(
            bottom_pad=fw.MARGIN,
            sub_type=FringeKey.CELL_FRINGE,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            color=self.color,
            win=self.roller_window
        )
        self._fringe_preset = q[-1]
        g = GroupPerCell(
            button_action=self.open_cell_port,
            checkbutton_action=self.on_widget_change,
            container=g,
            get_format_info=self.get_format_info,
            key=fk.Cell.Fringe.PER_CELL,
            port=self,
            stat=self.stat,
            text="Cell Fringe…",
            widgets=q,
            win=self.roller_window
        )
        self._pc_button += [g.check_button]
        self.controls += [q[-1], g.check_button]
        self.keep([g.button])

    def _draw_cell_margin(self, g):
        """
        Draw the cell margins group.

        g: GTK container
            for widgets in group
        """
        q = FormatWidget.draw_margin_group(
            bottom_pad=fw.MARGIN // 2,
            sub_type=fk.Cell,
            color=self.color,
            container=g,
            fraction_of="Cell",
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self._margins_preset = q[-1]
        g = GroupPerCell(
            button_action=self.open_cell_port,
            checkbutton_action=self.on_widget_change,
            container=g,
            get_format_info=self.get_format_info,
            key=fk.Cell.Margin.PER_CELL,
            port=self,
            stat=self.stat,
            text="Cell Margins…",
            widgets=q,
            win=self.roller_window
        )
        self._pc_button += [g.check_button]
        self.controls = self.controls + q + [g.check_button]
        self.keep([g.button])

    def _draw_cell_plaque_group(self, g):
        """
        Draw the cell plaque group.

        g: GTK container
            for widget group
        """
        q = FormatWidget.draw_plaque_group(
            bottom_pad=fw.MARGIN // 2,
            sub_type=PlaqueKey.CELL_PLAQUE,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self._plaque_preset = q[-1]
        g = GroupPerCell(
            button_action=self.open_cell_port,
            checkbutton_action=self.on_widget_change,
            container=g,
            get_format_info=self.get_format_info,
            key=fk.Cell.Plaque.PER_CELL,
            port=self,
            stat=self.stat,
            text="Cell Plaque…",
            widgets=q,
            win=self.roller_window
        )
        self._pc_button += [g.check_button]
        self.controls += [q[-1], g.check_button]
        self.keep([g.button])

    def _draw_free_range_cell_group(self, g):
        """
        Draw a free-range cell list group.

        g: GTK container
            for widget group
        """
        w = fw.MARGIN
        alignment = gtk.Alignment(0, 0, 0, 0)
        table = gtk.Table(TOTAL_ROW_2, COLUMN_1)
        color = self.color

        for i in range(TOTAL_ROW_2):
            color = RollerTable.get_darker_color(color, TOTAL_ROW_2)
            color1 = color, color, ForColor.MAX_COLOR
            box = RollerEventBox(color1)

            if not i:
                g1 = self._free_cell_list = ZList(
                    container=box,
                    create_z_list_item=self.create_z_list_item,
                    edit_z_list_item=self.edit_z_list_item,
                    get_item_name=self.get_cell_list_name,
                    key=fk.Layer.CELL_LIST,
                    item_name="Cell",
                    on_widget_change=self.on_widget_change,
                    set_item_name=self.set_cell_list_name
                )

            else:
                g1 = RollerCheckButton(
                    key=fk.Layer.PLACE_FREE_CELL_ABOVE,
                    on_widget_change=self.on_widget_change,
                    text=fk.Layer.PLACE_FREE_CELL_ABOVE,
                )
                box.add(g1)

            table.attach(box, COLUMN_0, COLUMN_1, i, i + 1)
            self.controls += [g1]

        table.set_row_spacings(1)
        alignment.set_padding(w, w, w, w)
        alignment.add(table)
        g.add(alignment)

    def _draw_grid_group(self, g):
        """
        Draw the grid group.

        g: GTK container
            to receive group
        """
        d = dict(
            choice_window=RWGrid,
            color=self.color,
            get_format_info=self.get_format_info,
            get_session_dict=self.get_updated_session_dict,
            key=fk.Cell.Grid.CELL_GRID,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            tip_type=ff.CELL_GRID_TIP_TYPE,
            win=self.roller_window
        )
        q = (
            [
                "Cell Grid Table:",
                OptionButton,
                d
            ],
        )
        q = RollerTable.populate_table(
            **dict(d, container=g, q=q, bottom_pad=fw.MARGIN // 2)
        )

        # for verify widgets:
        q[0].verify = self.verify_merge_widget

        g = self._merge_pc_group = GroupPerCell(
            button_action=self.open_cell_port,
            checkbutton_action=self.on_widget_change,
            container=g,
            get_format_info=self.get_format_info,
            key=fk.Cell.Grid.PER_CELL,
            port=self,
            stat=self.stat,
            text="Merge Cells…",
            widgets=q,
            win=self.roller_window
        )
        self._pc_button += [g.check_button]
        self.controls = self.controls + q + [g.check_button]
        self.keep([g.button])

    def _draw_layer_caption_group(self, g):
        """
        Draw the layer caption group.

        g: VBox
            to receive group
        """
        q = FormatWidget.draw_caption_group(
            bottom_pad=fw.MARGIN,
            sub_type=CaptionKey.LAYER_CAPTION,
            color=self.color,
            container=g,
            fraction_of="Cell",
            get_size=self.get_layer_space_size,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self.controls += [q[-1]]

        # Update widgets when its sub-navigation list-item is selected:
        g = q[ff.Caption.Layer.Index.TYPE]
        g.connect_event((self, Signal.VISIBILITY_CHANGE))
        g.dependent = [g.verify]

    def _draw_layer_fringe_group(self, g):
        """
        Draw the layer fringe group.

        g: GTK container
        """
        q = FormatWidget.draw_fringe_group(
            bottom_pad=fw.MARGIN,
            sub_type=FringeKey.LAYER_FRINGE,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self.controls += [q[-1]]

        # Update widgets when its sub-navigation list-item is selected:
        g = q[ff.Fringe.Index.TYPE]
        g.connect_event((self, Signal.VISIBILITY_CHANGE))
        g.dependent = [g.verify]

    def _draw_layer_group(self, g):
        """
        Draw a format layer-centric group.

        g: GTK container
            for widget group
        """
        d = dict(
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change
        )
        q = (
            [
                "Format Name:",
                RollerEntry,
                dict(d, key=fk.Layer.NAME)
            ],
            [
                "Layout Preference: ",
                RollerCheckButton,
                dict(
                    d,
                    key=fk.Layer.SHOW_IN_LAYOUT,
                    text=fk.Layer.SHOW_IN_LAYOUT,
                )
            ]
        )
        q = RollerTable.populate_table(
            bottom_pad=fw.MARGIN // 2,
            color=self.color,
            container=g,
            q=q
        )
        self.controls += q
        self._format_name_entry = q[-2]

    def _draw_layer_margin(self, g):
        """
        Draw a layer margin group.

        g: GTK container
            for widget group
        """
        q = FormatWidget.draw_margin_group(
            sub_type=fk.Layer,
            color=self.color,
            container=g,
            fraction_of="Layer",
            get_size=self.get_render_size,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self.controls += q
        self._layer_margin_button = q[0]

    def _draw_layer_plaque_group(self, g):
        """
        Draw a layer plaque group.

        g: GTK container
            container for the group
        """
        q = FormatWidget.draw_plaque_group(
            bottom_pad=fw.MARGIN,
            sub_type=PlaqueKey.LAYER_PLAQUE,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self.controls += [q[-1]]

        # Update widgets when its sub-navigation list-item is selected:
        g = q[ff.Plaque.Index.TYPE]
        g.connect_event((self, Signal.VISIBILITY_CHANGE))
        g.dependent = [g.verify]

    def _draw_mask_group(self, g):
        """
        Draw the image mask group.

        g: GTK container
            container for the image mask group
        """
        q = FormatWidget.draw_mask_group(
            bottom_pad=fw.MARGIN // 2,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self._image_mask_preset = q[-1]
        g = GroupPerCell(
            button_action=self.open_cell_port,
            checkbutton_action=self.on_widget_change,
            container=g,
            get_format_info=self.get_format_info,
            key=fk.Cell.Image.Mask.PER_CELL,
            port=self,
            stat=self.stat,
            text="Image Mask…",
            widgets=q,
            win=self.roller_window
        )
        self._pc_button += [g.check_button]
        self.controls += [q[-1], g.check_button]
        self.keep([g.button])

    def _draw_navigation_group(self, g):
        """
        Draw the category navigation group.

        Display a multiple widget groups, one at a time,
        using a TreeView list.

        g: GTK container
            to receive group of widgets
        """
        d = {
            BranchKey.LABEL: ("Category", "Sub-Category"),
            BranchKey.MAKE_OPTION_GROUP: self.make_option_group,
            BranchKey.OFFSHOOT_ITEM: PortFormat.SUB_CATEGORY,
            BranchKey.TRUNK_ITEM: PortFormat.CATEGORY,
            UIKey.ON_KEY_PRESS: self.on_key_press,
            UIKey.WINDOW: self,
            UIKey.STAT: self.stat
        }
        self.branch = Branch(d, g)

    def _draw_place_group(self, g):
        """
        Draw the image place group.

        g: GTK container
            to receive group
        """
        q = FormatWidget.draw_place_group(
            bottom_pad=fw.MARGIN // 2,
            color=self.color,
            container=g,
            get_format_info=self.get_format_info,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self._place_preset = q[-1]
        g = GroupPerCell(
            button_action=self.open_cell_port,
            checkbutton_action=self.on_widget_change,
            container=g,
            get_format_info=self.get_format_info,
            key=fk.Cell.Image.Place.PER_CELL,
            port=self,
            stat=self.stat,
            text="Image Place…",
            widgets=q,
            win=self.roller_window
        )
        self._pc_button += [g.check_button]
        self.controls += [q[-1], g.check_button]
        self.keep([g.button])

    def _draw_preset_group(self, g):
        """
        Draw the Preset ComboBox and Buttons.

        g: GTK container
            for widget group
        """
        self.preset = Preset(
            container=g,
            key=fk.FORMAT,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_preset_change,
            stat=self.stat,
            widget_list=self.controls,
            win=self.roller_window
        )

    def _draw_property_group(self, g):
        """
        Draw the property group.

        g: GTK container
            for group widgets
        """
        q = FormatWidget.draw_property_group(
            bottom_pad=fw.MARGIN // 2,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self._image_property_preset = q[-1]
        g = GroupPerCell(
            button_action=self.open_cell_port,
            checkbutton_action=self.on_widget_change,
            container=g,
            get_format_info=self.get_format_info,
            key=fk.Cell.Image.Property.PER_CELL,
            port=self,
            stat=self.stat,
            text="Property…",
            widgets=q,
            win=self.roller_window
        )
        self._pc_button += [g.check_button]
        self.controls += [q[-1], g.check_button]
        self.keep([g.button])

    def _reshow_port(self, n):
        """
        Call when returning to the format port.

        n: string
            format name
        """
        self.roller_window.switch_box.add(self.pane)
        self._show_port()
        self.roller_window.win.set_title(PortFormat.TITLE.format(n))

    def _show_port(self):
        """
        Call when switching to this port.

        Select a navigation list items in order
        to collapse the port's option groups.
        """
        self.pane.show_all()

        x = self.branch.trunk.get_sel_x()

        if x is not None:
            self.branch.offshoot[x].treeview.emit('cursor_changed')

        else:
            self.branch.trunk.select_item(0)
            self.branch.offshoot[0].select_item(0)

        self.branch.trunk.treeview.emit('cursor_changed')
        self.roller_window.win.present()

    def create_z_list_item(self, n):
        """
        Create a new format.

        Call from the ZList when the
        user activates the New Cell Button.

        Is part of the ZList template.

        n: string
            name of the cell

        Return: dict
            of free-range cell
        """
        d = Preset.get_default(fck.FREE_RANGE_CELL)
        d[fck.CELL][CellKey.NAME] = n
        return d

    def do_accept(self, *_):
        """
        Accept the PortFormat content.

        Return: true
            The key-press is handled.
        """
        d = self.get_format_info()[0]

        # Exit:
        self.switch_ports()
        return self.do_accept_callback(d)

    def do_accept_free_cell(self, d):
        """
        Update a free-range cell with changes made in PortFreeCell.

        Return: true
            The key-press is handled.
        """
        x = self._free_cell_index
        Port.loading += 1

        self._free_cell_list.update_zlist(d, x)
        self.preset.preset_is_undefined()

        Port.loading -= 1

        self._reshow_port(self._format_name_entry.get_value())
        return DONE

    def do_cancel(self, *_):
        """
        Cancel the format edit.

        Return: true
            The key-press is handled.
        """
        self.switch_ports()
        return self.do_cancel_callback()

    def do_cancel_free_cell(self, *_):
        """
        Call from the free-cell port.

        Return: true
            The key-press is handled.
        """
        self._reshow_port(self._format_name_entry.get_value())
        return DONE

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = (
            self._draw_navigation_group,
            self._draw_preset_group,
            self.draw_process_layout_group
        )
        group_name = "", "Format Preset", "Process"

        for x, p in enumerate(q):
            if x in (0, 1):
                g1 = hbox = gtk.HBox()
                g.add(hbox)

            if x in (1, 2):
                box = RollerEventBox(self.color)
                g1 = gtk.VBox()

                box.add(g1)
                hbox.add(box)

            if group_name[x]:
                g1.add(
                    RollerLabel(
                        padding=(2, 0, 4, 0),
                        text=group_name[x] + ":"
                    )
                )
            p(g1)
            self.reduce_color()

        for i in self.branch.offshoot:
            self.return_widgets.append(i.widget)
        self.return_widgets.append(self.branch.trunk.widget)

    def edit_z_list_item(self, d, x):
        """
        Switch focus to the free cell port for the selected cell.

        Is part of the ZList template.

        x: int
            the row selected in the cell list
            (0 .. n)
        """
        self._free_cell_index = x
        n = d[fck.CELL][CellKey.NAME]
        e = {UIKey.CELL_INDEX: x, UIKey.FORMAT_INDEX: self._format_x}

        self.switch_ports()

        # Get the port if it has already been created:
        if PortKey.FREE_CELL in Port.port_dict:
            a = Port.port_dict[PortKey.FREE_CELL]
            a.reopen_port(n, e)

        else:
            e.update(
                {
                    UIKey.GET_FORMAT_INFO: self.get_format_info,
                    UIKey.GET_SESSION_DICT: self.get_updated_session_dict,
                    UIKey.ON_ACCEPT: self.do_accept_free_cell,
                    UIKey.ON_CANCEL: self.do_cancel_free_cell,
                    UIKey.WINDOW: self.roller_window,
                    UIKey.WINDOW_TITLE: PortFreeCell.TITLE.format(n),
                    UIKey.PARENT_PORT: self,
                    UIKey.STAT: self.stat
                }
            )
            a = PortFreeCell(e)
        a.preset.load_preset(d[PresetKey.PRESET], d)

    def get_cell_list_name(self, d):
        """
        Use with Z-List.

        d: dict
            of free cell

        Return: string
            cell list name
        """
        return d[fck.CELL][CellKey.NAME]

    def get_format_info(self, cell=None):
        """
        Use with dialogs, free-range port, and cell port.

        cell: dict
            of free cell

        Return: tuple
            dict, int
            of format, index to format in format list
        """
        d = self.preset.get_value(has_preset=True)

        if cell:
            d[fk.Layer.CELL_LIST][self._free_cell_index] = cell
        return d, self._format_x

    def get_layer_space_size(self):
        """
        Use with layer caption's margins.

        Layer-space is the render size less layer margins.

        Return: tuple
            width, height
            of layer space
        """
        w, h = self.stat.render.size
        q = self._layer_margin_button.get_value()
        q = Form.combine_margin(q, w, h)
        return (
            w - q[ff.Margin.Index.LEFT] - q[ff.Margin.Index.RIGHT],
            h - q[ff.Margin.Index.TOP] - q[ff.Margin.Index.BOTTOM]
        )

    def get_render_size(self):
        """
        Use with layer margins' PortMargin.

        Return: tuple
            width, height
            size of render
            of int
        """
        return self.stat.render.size

    def get_updated_session_dict(self):
        """
        Collect session info.

        Return: dict
            of session
        """
        d = self.get_format_info()[0]
        return self._get_session_dict(form=d)

    def make_option_group(self, g, nav_list, opt_type, opt_key):
        """
        Draw the format groups.
        Hide the groups that aren't selected.

        g: gtk container
            group box

        nav_list: NavigationList
            not in use

        opt_type: string
            a format name

        opt_key: string
            an image-effect key
        """
        g.add(
            RollerLabel(
                padding=(2, 0, 4, fw.MARGIN),
                text=opt_key + " Options:"
            )
        )

        p = PortFormat.OPTION_DICT[opt_type][opt_key]
        p(g)

    def on_cell_port_close(self):
        """Call when closing a cell port."""
        self._reshow_port(self._format_name_entry.get_value())

    def on_preset_change(self, _):
        """
        The preset changed. Update widget visibility.
        """
        self._show_port()

    def on_widget_change(self, g):
        """
        Call when a widget changes.

        g: Widget
            Is responsible.
        """
        if not Port.loading:
            if hasattr(g, 'verify'):
                g.verify(g)

            if not isinstance(g, Preset):
                if hasattr(g, 'preset'):
                    g.preset.preset_is_undefined()

            if g.key == fk.Layer.NAME:
                self.roller_window.win.set_title(
                    PortFormat.TITLE.format(g.get_value())
                )

            elif g.key == fk.Cell.Grid.CELL_GRID:
                d = self.preset.get_value()

                # Adjust the cell tables to the grid size:
                CellTable.adjust_cell_tables(d, self.stat)

                # Update the check buttons with the adjusted cell tables:
                Port.loading += 1

                for i in self._pc_button:
                    i.set_value(d[i.key])

                Port.loading -= 1
            self.preset.preset_is_undefined()

    def open_cell_port(self, g, k, q):
        """
        Open a Per Cell port.

        g: RollerCheckButton
            per cell check button

        k: string
            for format dict

        q: 2D list
            cell table
        """
        self.switch_ports()

        # Open a cell-table-type port:
        PortCell(
            {
                PortCellKey.PER_CELL_BUTTON: g,
                PortCellKey.CELL_TABLE: q,
                UIKey.ON_ACCEPT: self.on_cell_port_close,
                UIKey.ON_CANCEL: self.on_cell_port_close,
                WidgetKey.KEY: k,
                UIKey.GET_FORMAT_INFO: self.get_format_info,
                UIKey.GET_SESSION_DICT: self.get_updated_session_dict,
                UIKey.WINDOW: self.roller_window,
                UIKey.PARENT_PORT: self,
                UIKey.STAT: self.stat
            }
        )

    def reopen_port(self, n, x):
        """
        Call when opening the format port for the second time.

        form: dict
            Has format.

        d: dict
            Has init values.

        n: string
            format name
        """
        self._format_x = x

        # Update in the case of new format:
        for i in self._pc_button:
            i.connect_expose()
        self._reshow_port(n)

    def set_cell_list_name(self, d, n):
        """
        Use with Z-List.

        d: dict
            of free cell

        n: string
            free-range cell name
        """
        d[fck.CELL][CellKey.NAME] = n

    def show_layout(self, *_):
        """Show a layout sketch-up."""
        self.stat.layout.show(self.get_updated_session_dict())

    def verify_merge_widget(self, g):
        """
        Call to verify grid widgets.
        Currently, this would be the per cell group.

        g: Widget
            from grid group
        """
        value = g.get_value()
        if value:
            if value[fk.Cell.Grid.SHAPE] != ff.Cell.Shape.RECTANGLE:
                self._merge_pc_group.hide()

            else:
                self._merge_pc_group.show()
