#!/usr/bin/env python
# -*- coding: utf-8 -*-


class One(object):
    """Use to pass around data."""

    def __init__(self, **d):
        """
        Add some attributes to the object.

        d: dict
            Has 'keyword, value' pairs that form attributes.
        """
        for k in d:
            setattr(self, k, d[k])
