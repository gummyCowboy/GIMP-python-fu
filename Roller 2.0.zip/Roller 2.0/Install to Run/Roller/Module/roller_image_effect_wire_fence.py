#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_border_line import BorderLine
from roller_image_effect_caster import Effect_
from roller_one_constant import ForBackdropStyle, OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay, Sel
import gimpfu as fu

ek = Effect_.Key
mosaic = Pdb.Mosaic
pdb = fu.pdb


class WireFence(BorderLine):
    """Add a wire framework to the BorderLine effect."""

    def __init__(self, one):
        """
        Do the Wire Fence image-effect.

        one: One
            Has variables.
        """
        BorderLine.__init__(
            self,
            one,
            framer=self.do_job,
            filler=lambda *args: None
        )

    def do_job(self, d):
        """
        Draw the wire framework.

        The framework will later mesh with BorderLine.

        d: dict
            Has options.

        Add the selection to the current selection.

        Return: selection state
            of render
        """
        j = self.stat.render.image
        border_sel = self.stat.save_selection()
        z = Lay.add(j, self.option_key, parent=self.parent)

        pdb.gimp_selection_none(j)

        # Set the layer size to the image size with 'color_fill':
        Lay.color_fill(z, (255, 255, 255))
        pdb.gimp_selection_all(j)
        pdb.plug_in_mosaic(
            j,
            z,
            d[ok.MESH_SIZE],
            mosaic.TILE_HEIGHT_1,
            d[ok.WIRE_THICKNESS],
            d[ok.NEATNESS],
            mosaic.NO_SPLIT,
            d[ok.LIGHT_ANGLE],
            mosaic.MIN_COLOR_VARIATION,
            mosaic.YES_ANTIALIAS,
            mosaic.YES_COLOR_AVERAGING,
            ForBackdropStyle.MESH_TYPE.index(d[ok.MESH_TYPE]),
            mosaic.SMOOTH_SURFACE,
            mosaic.BLACK_AND_WHITE_GROUT
        )
        Sel.isolate(j, z, self.fill_sel)

        # Erase white pixels:
        pdb.plug_in_colortoalpha(j, z, (255, 255, 255))

        Sel.item(j, z)
        pdb.gimp_selection_feather(j, 1)
        Sel.load(j, border_sel, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_image_remove_layer(j, z)
