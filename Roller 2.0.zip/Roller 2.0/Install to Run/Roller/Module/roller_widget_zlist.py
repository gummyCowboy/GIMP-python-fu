#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_image_effect_caster import LayerId
from roller_one_base import Base
from roller_one_constant import ForWidget as fw, SessionKey as sk
from roller_widget_box import RollerBox
from roller_widget_button import RollerButton
from roller_widget_tree import TreeViewList
import gtk

# For GTK, let it know that the function handled an event:
DONE = 1

ITEM_UPDATE = 'on_delete_item', 'on_rename_item'


class ZList(TreeViewList):
    """
    Is a widget group with a TreeView and TreeView manipulation Buttons.
    """
    RESPOND_KEY = 'Return', 'Delete', 'space'

    def __init__(self, **d):
        """
        Add an item list and associated buttons to a group.

        d: dict
            Has init values.
        """
        w = fw.MARGIN
        w1 = w // 2
        self.buttons = []
        self.items = []
        self._zlist = []
        box = RollerBox(gtk.HBox, padding=(w1, w, w, w))
        name = self._item_name = d['item_name']
        self.create_z_list_item = d['create_z_list_item']
        self.edit_z_list_item = d['edit_z_list_item']
        self._get_item_name = d['get_item_name']
        self._set_item_name = d['set_item_name']
        self._on_zlist_change = d['on_widget_change']

        for i in ITEM_UPDATE:
            setattr(self, i, None)
            if i in d:
                setattr(self, i, d[i])

        TreeViewList.__init__(
            self,
            self.verify_buttons,
            '#00FEFF',
            "",
            100,
            **d
        )

        self.treeview.set_tooltip_text("Is in z-order.")

        vbox = RollerBox(
            gtk.VButtonBox,
            align=(0, 0, 1, 1),
            padding=(0, 0, w1, 0)
        )
        q = zip(
            (
                "New {}…".format(name),
                "Edit {}…".format(name),
                "Delete {}".format(name)),
            (
                self._create_item,
                self._edit_item,
                self._del_item
            ),
            (0, 1, 1)
        )

        for n, p, a in q:
            g = CoOpButton(n, p, a)
            vbox.add(g)
            self.buttons.append(g)

        hbox = gtk.HBox()
        scrolled_window = gtk.ScrolledWindow()
        up_arrow = gtk.Arrow(gtk.ARROW_UP, gtk.SHADOW_NONE)
        down_arrow = gtk.Arrow(gtk.ARROW_DOWN, gtk.SHADOW_NONE)

        move_up_button = self._move_up_button = CoOpButton(
            up_arrow,
            self.move_sel_up,
            2
        )
        move_down_button = self._move_down_button = CoOpButton(
            down_arrow,
            self.move_sel_down,
            2
        )

        hbox.add(move_up_button)
        hbox.add(move_down_button)
        vbox.add(hbox)
        [self.buttons.append(i) for i in (move_up_button, move_down_button)]
        scrolled_window.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        scrolled_window.add(self.treeview)
        box.add(scrolled_window)
        box.add(vbox)
        d['container'].add(box)
        self.verify_buttons()

        # Connect events:
        self.treeview.connect('key_press_event', self._on_key_press)
        self.treeview.get_selection().connect('changed', self.verify_buttons)

    def _create_item(self, *_):
        """
        Create a new item.

        Enumerate the item name until
        a unique identifier is created.
        """
        names = [
            self._get_item_name(i).lower() for x1, i in enumerate(self._zlist)
        ]
        n = Base.enumerate_name(self._item_name, names)
        q = self.items

        self.list_store.append([n, '#000000', self._background_color])
        q.append((n, len(q)))
        self.verify_buttons()
        self.select_item(len(q) - 1)
        self._zlist.append(self.create_z_list_item(n))
        self._edit_item()

    def _del_item(self, *_):
        """Delete a row in the TreeView."""
        x = self.get_sel_x()
        n = self.items[x][0]

        self.items.pop(x)
        self._zlist.pop(x)

        # model, iter:
        a, b = self.widget.get_selection().get_selected()

        a.remove(b)
        self._populate_list(self.items)
        self.verify_buttons()
        if self.on_delete_item:
            self.on_delete_item(n)
        self._on_zlist_change(self)

    def _edit_item(self, *_):
        """Call the creator, the user wants to edit."""
        x = self.get_sel_x()
        d = deepcopy(self._zlist[x])
        self.edit_z_list_item(d, x)

    def _on_key_press(self, _, a):
        """
        Use to catch the delete and return keys.

        a: key-press event
        """
        n = gtk.gdk.keyval_name(a.keyval)

        if len(self.items):
            if n in ZList.RESPOND_KEY:
                x = ZList.RESPOND_KEY.index(n)

                (self._edit_item, self._del_item, self.verify_buttons)[x]()
                return DONE

    def _populate_list(self, q):
        """
        Populate the TreeView from a list.
        The previous indexed-list is replaced.

        q: list of tuples (name, index)
        """
        # Replace "TreeView.ListStore's" iterator.
        self.list_store = gtk.ListStore(str, str, str)
        self.treeview.set_model(self.list_store)

        self.items = []
        for x, b in enumerate(q):
            self.list_store.append([b[0], '#000000', '#00FEFF'])
            self.items.append((b[0], x))

    def get_value(self):
        """
        Get a list of strings displayed in the list.

        Is part of the Widget template.

        Return: list
            of z-list items
        """
        return deepcopy(self._zlist)

    def move_sel_down(self, *_):
        """
        Move a selection down one line in the TreeView.

        If 'x' selection is at the bottom of the list,
        then the item rotates to the top of the list.
        """
        x = x1 = self.get_sel_x()
        a = len(self.items)
        x += 1

        if x == a:
            x = 0

        self.update_treeview(x, x1)
        self._move_down_button.widget.grab_focus()
        self._on_zlist_change(self)

    def move_sel_up(self, *_):
        u"""
        Move a selection up one line in the TreeView.

        If 'x' selection is at the top of the list, then
        the item rotates to the bottom of the list.
        """
        x = x1 = self.get_sel_x()
        a = len(self.items)
        x -= 1

        if x < 0:
            x = a - 1

        self.update_treeview(x, x1)
        self._move_up_button.widget.grab_focus()
        self._on_zlist_change(self)

    def rename(self, x, n):
        """
        Rename an item.

        x: the current list entry index
        n: name of item
        """
        self.items[x] = n, self.items[x][1]
        self._populate_list(self.items)

    def set_indices(self):
        u"""
        Update the 'self.items' indices.

        Call after the dictionary's item list is re-ordered.
        """
        self.items = [(i, x) for x, i in enumerate(self.items)]

    def set_value(self, q):
        """
        Load the item list from the owner's list.

        Is part of the Widget template.
        """
        self._zlist = q
        self.items = [self._get_item_name(i) for i in self._zlist]

        self.set_indices()
        self._populate_list(self.items)

    def update_treeview(self, x, x1):
        """
        Update the list after a change.

        x: int
            new position

        x1: int
            old position
        """
        q = self.items[x1]
        d = self._zlist[x1]

        self.items.pop(x1)
        self.items.insert(x, q)
        self._populate_list(self.items)
        self.select_item(x)
        self._zlist.pop(x1)
        self._zlist.insert(x, d)

    def update_zlist(self, d, x):
        """
        Update the list.

        Call when user accepts a z-list edit.

        d: dict
            of z-list

        x: int
            index to item in list
        """
        q = self._zlist
        old_name = self._get_item_name(q[x])
        q[x] = d
        n = self._get_item_name(d).strip()

        # Ensure layer keys don't conflict with item name:
        for k in LayerId.KEY:
            n = n.replace(LayerId.KEY[k], "")

        if sk.BACKDROP == n:
            n = "Background"

        names = [
            self._get_item_name(i).lower() for x1, i in enumerate(q) if x1 != x
        ]

        if n.lower() in names:
            n = Base.enumerate_name(n, names)

        self._set_item_name(d, n)

        if n != old_name:
            self.rename(x, n)
            if self.on_rename_item:
                self.on_rename_item(old_name, n)

    def verify_buttons(self, *_):
        """Verify Buttons dependent on the list quantity."""
        _, b = self.treeview.get_selection().get_selected()

        # The move and delete Buttons are dependent
        # on their selection state and the list size:
        x = self.get_sel_x()
        for g in self.buttons[1:]:
            if b and len(self.items) >= g.need and x is not None:
                g.enable()

            else:
                g.disable()


class CoOpButton(RollerButton):
    """
    Has a variable, 'self.need'.
    'self.need' is the number of items in a list
    needed for the Button to be valid.
    """

    def __init__(self, text, callback, need, **d):
        """
        text: string
            Button Label
            or gtk.Arrow

        callback: function
            Call on action.

        need: int
            the number of items needed for this Button to be valid
        """
        self.need = need
        RollerButton.__init__(self, text=text, on_widget_change=callback, **d)
