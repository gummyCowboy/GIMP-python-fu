#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_border_line import BorderLine
from roller_image_effect_caster import Effect_
from roller_format_form import Form
from roller_render_hub import RenderHub
from roller_one_constant import (
    FormatKey as fk,
    OptionKey as ok,
    SessionKey as sk
)
from roller_one_fu import Lay, Sel
import gimpfu as fu

ek = Effect_.Key
pdb = fu.pdb


class BrushPunch(BorderLine):
    """Create a unique image frames using brush stroke selections."""

    def __init__(self, one):
        """
        Do the Brush Punch image-effect.

        one: One
            Has variables.
        """
        self.d = one.d
        BorderLine.__init__(self, one, framer=self.do_job)

    def do_job(self, d):
        """
        Draw the brush frame by making a selection from the brush.

        session: dict
            with format list

        d: dict
            with options

        Return: state of image
            the selection for the frame
        """
        stat = self.stat
        j = stat.render.image
        name = Lay.get_format_name_from_group(self.parent)
        form = None
        start_sel = stat.save_selection()
        w = d[ok.FRAME_WIDTH] + 3

        # Get the format dict:
        for x, i in enumerate(self.session[sk.FORMAT_LIST]):
            if i[fk.Layer.NAME] == name:
                form = i
                break

        z = Lay.add(j, 'path', self.parent)
        merged = Form.is_merge_cells(form)
        row, col = stat.layout.get_division(x)

        # Do one image at a time:
        for r in range(row):
            for c in range(col):
                if merged:
                    s = d[fk.Cell.Grid.PER_CELL][r][c]

                else:
                    # not a dependent cell:
                    s = 1

                # Is it a dependent cell?
                if s != (-1, -1):
                    image_sel = stat.get_image_sel(name, r, c)
                    if image_sel:
                        Sel.load(j, image_sel)
                        Sel.grow(j, w, d[ok.FRAME_TYPE])
                        pdb.plug_in_sel2path(j, z)

                        stroke = j.active_vectors.strokes[0]

                        pdb.gimp_selection_none(j)
                        RenderHub.brush_stroke_on_stroke(
                            z,
                            self.d[ok.BRUSH],
                            self.d[ok.BRUSH_SIZE],
                            stroke,
                            d[ok.BRUSH_SPACING]
                        )

        # Select the usable new material:
        Sel.load(j, start_sel, option=fu.CHANNEL_OP_SUBTRACT)

        for r in range(row):
            for c in range(col):
                image_sel = stat.get_image_sel(name, r, c)
                if image_sel:
                    Sel.load(j, image_sel, option=fu.CHANNEL_OP_SUBTRACT)

        Sel.load(j, start_sel, option=fu.CHANNEL_OP_ADD)
        Sel.item(j, z, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_image_remove_layer(j, z)
