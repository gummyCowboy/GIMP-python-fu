#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb


class ColoredBoard:
    """Create a an colored edge around an image(s)."""

    def __init__(self, one):
        """
        Do the Colored Board image-effect.

        one: One
            Has variables.
        """
        stat = one.stat
        parent = one.parent
        d = one.d
        j = stat.render.image
        z = Lay.selectable(
            j,
            stat.render.get_image_layer(
                Lay.get_format_name_from_group(parent)
            ),
            d
        )

        Sel.item(j, z)
        Sel.grow(j, d[ok.FRAME_WIDTH], d[ok.FRAME_TYPE])
        Sel.item(j, z, option=fu.CHANNEL_OP_SUBTRACT)

        n = Lay.get_layer_name(one.k, parent=parent)
        z1 = Lay.add(j, n, parent=parent, offset=1)

        Sel.fill(z1, d[ok.COLOR])
        pdb.gimp_image_remove_layer(j, z)
        pdb.plug_in_antialias(j, z1)
