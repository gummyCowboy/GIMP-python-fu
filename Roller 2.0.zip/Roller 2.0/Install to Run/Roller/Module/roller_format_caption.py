#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import RollerImage
from roller_format_text import Text
from roller_image_effect_caster import Effect_, LayerId, LayerKey
from roller_one import One
from roller_one_constant import (
    CaptionKey as ck,
    FormatKey as fk,
    ForFormat as ff,
    ForLayout,
    FreeCellKey as fck,
    OptionKey as ok,
    PlaceKey
)
from roller_one_base import Comm
from roller_one_fu import Lay, Sel
from roller_render_shadow import Shadow
import gimpfu as fu
import os

ek = Effect_.Key
pdb = fu.pdb
YES_ANTIALIAS = 1
X_IS_0 = Y_IS_0 = W_IS_0 = H_IS_0 = 0


class Caption:
    """Create a text overlay on a cell."""

    def __init__(
        self,
        session,
        d,
        format_x,
        stat,
        parent=None,
        is_layout=False
    ):
        """
        Create a cell captions for a format.

        session: dict
            of session

        d: dict
            of format

        stat: Stat
            globals

        format_x: int
            index
            corresponding with the session's format list

        parent: layer
            layer group for caption layer

        is_layout: flag
            If it is true, the layout opacity is used.
        """
        self.session = session
        self.stat = stat
        self._form = d
        self._format_x = format_x
        self._is_layout = is_layout
        self._group = self.layer = None
        self._is_per_cell = 1 if d[fk.Cell.Caption.PER_CELL] else 0
        self._image_number = d[ck.CELL_CAPTION][ck.START_NUMBER]
        self._caption_layer_name = Lay.get_layer_name(
            LayerKey.CELL_CAPTION,
            parent=parent
        )

        if not parent:
            parent = stat.render.format_group(format_x, d[fk.Layer.NAME])

        self._parent = parent

        if d[fk.Layer.CELL_LIST]:
            if not d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                self._do_free_cell()

        self._do_cells()
        self._do_layer()
        if d[fk.Layer.CELL_LIST]:
            if d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                self._do_free_cell()

    def _do(self, z, cell, text, caption_index, name):
        """
        Add text.

        z: layer
            to receive text

        cell: One
            Has cell data.

        text: string
            to display

        caption_index: class
            caption type
            either cell, free cell, or layer index

        name: string
            layer name
            either a layer or cell-type caption layer
        """
        go = 1
        j = self.stat.render.image
        q = cell.data
        font = q[caption_index.FONT]
        z1 = None

        if font not in self.stat.font_list:
            Comm.info_msg(ff.MISSING_ITEM.format("Caption", "font", font))
            go = 0

        if go:
            if self._is_layout:
                color = 255, 255, 255

            else:
                color = q[caption_index.COLOR]

            go, z = Text.make_text_layer(
                j,
                z,
                YES_ANTIALIAS,
                X_IS_0,
                Y_IS_0,
                text,
                q[caption_index.FONT_SIZE],
                font,
                color,
                W_IS_0,
                H_IS_0
            )
        if go:
            Sel.item(j, z)

            a = ff.Caption
            _, x1, y1, x2, y2 = pdb.gimp_selection_bounds(j)
            sel_width = x2 - x1
            sel_height = y2 - y1

            # cell size without margins:
            x, y, w, h = cell.x, cell.y, cell.w, cell.h

            top, bottom, left, right = Form.combine_margin(
                q[caption_index.MARGIN],
                w,
                h
            )
            width, height = w, h
            center_x = x + left - right + w // 2
            center_y = y + top - bottom + h // 2
            left_x, top_y = x, y
            right_x = x + w
            bottom_y = y + h
            w -= left - right
            w = max(1, w)
            w = min(w, sel_width)
            h -= top - bottom
            h = max(1, h)
            h = min(h, sel_height)
            n = q[caption_index.JUSTIFICATION]

            if n == a.TOP_LEFT:
                x += left
                y += top

            elif n == a.TOP_CENTER:
                x = center_x - w // 2
                y += top

            elif n == a.TOP_RIGHT:
                x = right_x - w - right
                y += top

            elif n == a.MIDDLE_LEFT:
                x += left
                y = center_y - h // 2

            elif n == a.CENTERED:
                x = center_x - w // 2
                y = center_y - h // 2

            elif n == a.MIDDLE_RIGHT:
                x = right_x - w - right
                y = center_y - h // 2

            elif n == a.BOTTOM_LEFT:
                x += left
                y = bottom_y - h - bottom

            elif n == a.BOTTOM_CENTER:
                x = center_x - w // 2
                y = bottom_y - h - bottom

            elif n == a.BOTTOM_RIGHT:
                x = right_x - w - right
                y = bottom_y - h - bottom

            # Limit x and y to margins.
            # Check for invalid state:
            if left_x + left > x > right_x - right:
                x = center_x

            else:
                x = left_x + left if x < left_x + left else x
                x = right_x - right if x > right_x - right else x

            # Check for invalid state:
            if top_y + top > y > bottom_y - bottom:
                y = center_y

            else:
                y = top_y + top if y < top_y + top else y
                y = bottom_y - bottom if y > bottom_y - bottom else y

            pdb.gimp_layer_set_offsets(z, x, y)

            if not self._is_layout:
                self._do_shadow(z, q, caption_index, name)
                z1 = j.active_layer
            if q[caption_index.CLIP_TO_CELL]:
                # Trim material out of cell bounds:
                Sel.rect(
                    j,
                    left_x,
                    top_y,
                    width,
                    height,
                    option=fu.CHANNEL_OP_REPLACE
                )
                Sel.clear_outside_of_selection(j, z, keep_sel=1)
                if z1:
                    Sel.clear_outside_of_selection(j, z1)

    def _do_cells(self):
        """Do the cell captions."""
        d = self._form
        stat = self.stat
        _x = self._format_x
        parent = self._parent
        merged = Form.is_merge_cells(d)
        j = stat.render.image
        row, column = stat.layout.get_division(_x)
        double_space = Form.is_double_space(d)
        n = self._caption_layer_name

        for r in range(row):
            for c in range(column):
                has_caption = 1

                # Don't do dependent merged cells:
                if merged:
                    if d[fk.Cell.Grid.PER_CELL][r][c] == (-1, -1):
                        has_caption = 0

                if has_caption and double_space:
                    has_caption = Form.is_double_space_cell(r, c, double_space)

                if has_caption:
                    q = Form.get_cell_caption(d, r, c)
                    text = self._get_text(
                        q,
                        r,
                        c,
                        ff.Caption.Cell.Index
                    )
                    if not text:
                        has_caption = 0
                if has_caption:
                    if not self._group:
                        self._group = Lay.group(j, "Caption Group")

                    if not self.layer:
                        self.layer = Lay.add(j, n, parent=self._group)

                    rect = self.stat.layout.get_merge_cell_rect(
                        _x,
                        r,
                        c
                    )
                    cell = One(
                        x=rect.x,
                        y=rect.y,
                        w=rect.width,
                        h=rect.height,
                        data=q
                    )
                    self._do(
                        self.layer,
                        cell,
                        text,
                        ff.Caption.Cell.Index,
                        LayerKey.CELL_CAPTION
                    )
        if self._group:
            z = Lay.merge_group(j, self._group, n=n)
            self._group = None

            Lay.order(j, z, parent)
            if self._is_layout:
                z.opacity = 66.

    def _do_free_cell(self):
        """Do captions for free-range cells."""
        stat = self.stat
        j = stat.render.image
        n = Lay.get_layer_name(
            LayerKey.FREE_CELL_CAPTION,
            parent=self._parent
        )
        r = ForLayout.FREE_CELL
        self.layer = None

        for cell in reversed(self._form[fk.Layer.CELL_LIST]):
            q = Form.get_cell_caption(cell, r, r)
            j1 = RollerImage.get_image(
                self.session,
                cell[PlaceKey.IMAGE_PLACE][PlaceKey.IMAGE]
            )
            text = self._get_text(q, r, r, ff.Caption.FreeCell.Index, j=j1)
            if text:
                if j1:
                    Form.prep_free_cell_image(j1, cell, stat.render.size)
                    w, h = j1.pocket.size
                    x, y = j1.pocket.position

                else:
                    x, y, w, h = Form.get_free_cell_rect(
                        cell[fck.CELL],
                        stat.render.size
                    )

                if not self._group:
                    self._group = Lay.group(j, "Caption Group")

                if not self.layer:
                    self.layer = Lay.add(j, n, parent=self._group)

                one = One(data=q, w=w, h=h, x=x, y=y)
                self._do(
                    self.layer,
                    one,
                    text,
                    ff.Caption.FreeCell.Index,
                    LayerKey.FREE_CELL_CAPTION
                )
        if self._group:
            z = Lay.merge_group(j, self._group, n=n)
            self._group = None

            Lay.order(j, z, self._parent)
            if self._is_layout:
                z.opacity = 66.

    def _do_layer(self):
        """Do a layer (per format) caption."""
        stat = self.stat
        d = self._form
        q = Form.get_caption_by_key(d[ck.LAYER_CAPTION], ck.LAYER_CAPTION)
        text = self._get_text(q, None, None, ff.Caption.Layer.Index)
        if text:
            j = stat.render.image
            self._group = Lay.group(j, "Caption Group")
            n = Lay.get_layer_name(
                LayerKey.LAYER_CAPTION,
                parent=self._parent
            )
            self.layer = Lay.add(j, n, parent=self._group)
            cell = One(data=q)
            size = self.session['size']

            if d[ck.LAYER_CAPTION][ck.OBEY_MARGINS]:
                cell.y, bottom, cell.x, right = Form.get_layer_margin(
                    d,
                    size
                )
                cell.w = size[0] - cell.x - right
                cell.h = size[1] - cell.y - bottom

            else:
                cell.x = cell.y = 0
                cell.w, cell.h = size

            self._do(
                self.layer,
                cell,
                text,
                ff.Caption.Layer.Index,
                LayerKey.LAYER_CAPTION
            )

            z = Lay.merge_group(j, self._group, n=n)
            self._group = None

            Lay.order(j, z, self._parent)
            if self._is_layout:
                z.opacity = 66.

    def _do_shadow(self, z, q, caption_index, name):
        """
        Draw a shadow for the text.

        z: layer
            with caption

        q: tuple
            caption data
            for cell

        caption_index: class
            caption type
            either of cell, free cell, or layer
            with index sub-class

        name: string
            layer name for cell type
        """
        stat = self.stat
        j = stat.render.image
        shadow = q[caption_index.SHADOW][ff.Shadow.Index.CHOICE]
        if shadow != ok.NONE and not self._is_layout:
            unicode_key = LayerId.KEY[name]
            z.name = "{} {}".format(unicode_key, name)
            e = {'caster_key': (name,)}
            d = Form.get_shadow_dict(q[caption_index.SHADOW])
            is_inlay = False

            if shadow == ff.Shadow.INLAY_SHADOW:
                is_inlay = e['is_inlay'] = True

            if d:
                Shadow(
                    One(
                        d=d,
                        e=e,
                        k='shadow',
                        stat=stat,
                        parent=z.parent
                    )
                )

                z1 = j.active_layer
                q = (z, z1) if is_inlay else (z1, z)
                for i in q:
                    Lay.order(j, i, self._group)

            # Rename the layer so that additional captions will
            # not find the layer during a shadow-layer search:
            z.name = "processed"

    def _get_text(self, q, r, c, caption_index, j=None):
        """
        Create the text as defined by the format
        cell data for the caption option group.

        q: tuple
            Is caption cell data.

        r, c: int
            cell index

        caption_index: class
            either cell, free cell, or layer index

        j: RollerImage
            Use with free-range cell to get the image name.

        Return: string
            the caption
        """
        a = ff.Caption
        _type = q[caption_index.TYPE]
        text = ""

        if _type == a.TEXT:
            text = q[caption_index.TEXT]

        elif _type == a.SEQUENCE_NUMBER:
            if self._is_per_cell:
                text = str(q[caption_index.START_NUMBER])

            else:
                text = str(self._image_number)
                self._image_number += 1

        elif _type == a.IMAGE_NAME:
            text = self.stat.layout.get_image_name_from_cell(
                self._format_x,
                r,
                c,
                j=j
            )
            try:
                if text and os.path.isfile(text):
                    q1 = os.path.split(text)
                    text = os.path.splitext(q1[1])[0]

            except TypeError:
                pass

        if _type in (a.IMAGE_NAME, a.SEQUENCE_NUMBER):
            n = q[caption_index.LEADING_TEXT]
            n1 = q[caption_index.TRAILING_TEXT]
            if text:
                if n:
                    text = n + text
                if n1:
                    text += n1
        return text
