#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_grid import Grid
from roller_image_effect_border_line import BorderLine
from roller_image_effect_caster import Effect_
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay, Sel
import gimpfu as fu

ek = Effect_.Key
pdb = fu.pdb


class RadWave(BorderLine):
    """Add a wire framework to BorderLine using waves."""

    def __init__(self, one):
        """
        Do the Rad Wave image-effect.

        one: One
            Has variables.
        """
        BorderLine.__init__(self, one, framer=self.select_wave)

    def select_wave(self, d):
        """
        Draw the wire framework.

        The framework will later mesh with BorderLine.

        d: dict
            Has options.

        Return: state of selection
        """
        j = self.stat.render.image
        border_sel = self.stat.save_selection()
        z = Lay.add(j, self.option_key, parent=self.parent)

        if d[ok.LINE_WIDTH]:
            pdb.gimp_context_set_brush_size(d[ok.LINE_WIDTH])

        pdb.gimp_selection_none(j)
        pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
        pdb.gimp_context_set_opacity(100.)
        pdb.gimp_context_set_foreground((0, 0, 0))
        pdb.gimp_context_set_brush_aspect_ratio(0.)
        pdb.gimp_context_set_brush_angle(0)
        pdb.gimp_context_set_brush_spacing(0.1)
        pdb.gimp_context_set_dynamics('Dynamics Off')
        pdb.gimp_context_set_brush_default_hardness()
        pdb.gimp_context_set_paint_method("gimp-paintbrush")

        # Set the layer size to the image size with 'color_fill':
        Lay.color_fill(z, (0, 0, 0))

        # composition border:
        if d[ok.COMPOSITION_FRAME_WIDTH]:
            pdb.gimp_selection_all(j)
            pdb.gimp_selection_shrink(j, d[ok.COMPOSITION_FRAME_WIDTH])
            Sel.invert(j)
            sel = self.stat.save_selection()

        else:
            sel = None

        pdb.gimp_selection_all(j)
        Lay.clear_sel(j, z)

        # row and column line:
        if d[ok.LINE_WIDTH]:
            grid = Grid(self.session['size'], d[ok.ROW], d[ok.COLUMN]).table
            for r in range(1, d[ok.ROW]):
                y = grid[r][0].y
                q = [0, y, self.session['w'], y]
                pdb.gimp_paintbrush_default(z, len(q), q)

            for c in range(1, d[ok.COLUMN]):
                x = grid[0][c].x
                q = [x, 0, x, self.session['h']]
                pdb.gimp_paintbrush_default(z, len(q), q)

        pdb.plug_in_waves(
            j,
            z,
            d[ok.WAVE_AMPLITUDE],
            1,
            d[ok.WAVELENGTH],
            0,
            1
        )

        pdb.plug_in_whirl_pinch(j, z, d[ok.WHIRL], 0, 2.)
        pdb.gimp_selection_none(j)

        if sel:
            Sel.load(j, sel)

        Sel.item(j, z, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_selection_feather(j, 1)
        Sel.load(j, border_sel, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_image_remove_layer(j, z)
