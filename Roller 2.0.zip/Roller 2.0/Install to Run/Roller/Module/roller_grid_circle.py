#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import Rect
from roller_grid import Grid
from roller_one_constant import ForFormat as ff

RATIO = ff.Cell.Shape.TRIANGLE_DOWN_SCALE_RATIO
RATIO_ALT = 1 - RATIO
SHAPE = ff.Cell.Shape


class GridCircle:
    """
    Calculate the position and the size of cells.

    The cells are ellipse shaped.

    Use a double-spaced grid-type.
    """

    def __init__(self, grid):
        """
        Calculate an ellipse cell-sized rectangle and an ellipse shape.

        grid: One
            Has init values.
        """
        self.grid = grid
        row, column = grid.r, grid.c
        table = grid.table
        shape = grid.cell_shape
        s = grid.layer_space
        x, y = grid.offset
        double_space = grid.double_space

        if shape == SHAPE.CIRCLE_HORIZONTAL:
            # cell size:
            w1 = s[0] / (.5 + column * .5)
            h1 = s[1] / (RATIO_ALT + row * RATIO)
            w = min(w1, h1)
            w, h = w, w

            # table size:
            w1 = w / 2.
            h1 = h * RATIO
            h2 = h * RATIO_ALT
            s1 = int(column * w1 + w1), int(row * h1 + h2)
            x, y = Grid.calc_pin_offset(grid.pin, s, s1[0], s1[1], x, y)

            # intersect:
            w1 = w / 2
            h1 = h * RATIO

        else:
            # circle, vertically aligned
            # cell size:
            w1 = s[0] / (RATIO_ALT + column * RATIO)
            h1 = s[1] / (.5 + row * .5)
            w = min(w1, h1)
            w, h = w, w

            # table size:
            w1 = w * RATIO
            w2 = w * RATIO_ALT
            h1 = h / 2.
            s1 = int(column * w1 + w2), int(row * h1 + h1)
            x, y = Grid.calc_pin_offset(grid.pin, s, s1[0], s1[1], x, y)

            # intersect:
            w1 = w * RATIO
            h1 = h / 2

        w, h = int(w), int(h)
        offset = x, y
        x_intersect = self.x_intersect = []
        y_intersect = self.y_intersect = []

        for c in range(column):
            x_intersect.append(int(round(x)))
            x += w1

        for r in range(row):
            y_intersect.append(int(round(y)))
            y += h1

        # Compose points:
        for r in range(row):
            for c in range(column):
                if Form.is_double_space_cell(r, c, double_space):
                    y = y_intersect[r]
                    x = x_intersect[c]
                    position = x, y

                    if (
                        x + w > s[0] + offset[0] or
                        y + h > s[1] + offset[1]
                    ):
                        position = size = 0, 0

                    else:
                        size = w, h

                    # 'cell' is the cell before margins:
                    table[r][c].cell = Rect(position, size)
                    if size[0]:
                        table[r][c].plaque = {
                            'x': x,
                            'y': y,
                            'w': size[0],
                            'h': size[1]
                        }
                        # If there are no margins, then do shape:
                        if grid.with_shape:
                            table[r][c].shape = table[r][c].plaque

    def calc_shape_per_cell(self, *_):
        """
        Calculate the shape of the ellipse from
        the pocket size on a per cell basis.

        Is part of the GridDeck template.
        """
        # The pocket rectangle has the shape points:
        self.calc_shape_with_pocket()

    def calc_shape_with_pocket(self):
        """
        Calculate the shape of the ellipse from
        the pocket size using intersects.

        Is part of the GridDeck template.
        """
        q = self.grid.table
        for r in range(self.grid.r):
            for c in range(self.grid.c):
                if Form.is_double_space_cell(r, c, self.grid.double_space):
                    rect = q[r][c].pocket
                    q[r][c].shape = {
                        'x': rect.x,
                        'y': rect.y,
                        'w': rect.width,
                        'h': rect.height
                    }
