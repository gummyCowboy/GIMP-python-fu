#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice, uniform, randint
from roller_image_effect_caster import Effect_
from roller_option_limit import Option
from roller_one_constant import OptionLimitKey as olk, SessionKey as sk

ek = Effect_.Key


class OptionStat:
    """Has static functions used by PortOption and Render."""

    @staticmethod
    def get_effect_keys(effect):
        """
        Generate a list of sub-effect keys for an effect.

        effect: string
            an image-effect

        Return: list
            of sub-effects
            of strings
        """
        return [effect] + Effect_.PROPERTY[effect][Effect_.EFFECT_STEPS]

    @staticmethod
    def get_step_class(option_type):
        """
        Determine the step type in class-form for a step key.

        option_type: string
            either BACKDROP, Frame Gradient, or a format name

        Return: class
            step type
        """
        if option_type == sk.BACKDROP:
            return Option.BackdropStyle
        return Option.Effect

    @staticmethod
    def rand(d, option_key, e):
        """
        Randomize option values.

        Is part of the PortOption template.

        d: dict
            option group

        option_key: string
            either an effect or a style

        e: dict
            Is option limit 'pure'.
        """
        for k in d:
            if k in e:
                if olk.LIMIT in e[k]:
                    a = e[k][olk.LIMIT]
                    if olk.PRECISION in e[k]:
                        d[k] = uniform(a[0], a[1])

                    else:
                        d[k] = randint(a[0], a[1])

                elif olk.LIMIT_SELF in e[k]:
                    d[k] = e[k][olk.LIMIT_SELF](option_key)

                elif olk.LIMIT_FUNCTION in e[k]:
                    d[k] = e[k][olk.LIMIT_FUNCTION]()

                elif olk.LIST in e[k]:
                    d[k] = choice(e[k][olk.LIST])

    @staticmethod
    def step_is_backdrop_style(option_type):
        """
        Determine if the step key is a backdrop-style.

        option_type: string
            either BACKDROP or an format name

        Return: flag
            If it's true, then the step is a backdrop-style.
        """
        return 1 if option_type == sk.BACKDROP else 0
