#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_image import Rect
from roller_one_base import Base
from roller_one_constant import ForFormat as ff


class Grid:
    """
    Calculate the coordinates and the size of cells.

    Use a Rect object to store the position and size of a cell.

    Has one attribute, 'table', for cell access.
    """

    def __init__(self, s, row, column):
        """
        Calculate cell size.

        s: (w, h) of int
            size of the grid

        row, column: int
            row and column scale of the grid
        """
        w = s[0] / 1. / column
        h = s[1] / 1. / row
        x = y = 0.
        y_intersect = []
        x_intersect = []
        table = self.table = Base.create_2d_table(row, column)

        for r in range(row + 1):
            y_intersect.append(int(round(y)))
            y += h

        for c in range(column + 1):
            x_intersect.append(int(round(x)))
            x += w
        for r in range(row):
            for c in range(column):
                y, y1 = y_intersect[r], y_intersect[r + 1]
                x, x1 = x_intersect[c], x_intersect[c + 1]
                table[r][c] = Rect((x, y), (x1 - x, y1 - y))

    @staticmethod
    def calc_pin_offset(pin, s, w, h, x, y):
        """
        Calculate pin offset given the layer space.

        pin: string
            pin type

        s: tuple
            size
            w, h
            layer space

        w, h: int
            size of table

        x, y: int
            offset
        """
        if pin in ff.Grid.Pin.PINS_WITH_X_OFFSET:
            x1 = s[0] - w

            if pin == ff.Grid.Pin.CENTER:
                x1 //= 2
            x += x1

        if pin in ff.Grid.Pin.PINS_WITH_Y_OFFSET:
            y1 = s[1] - h

            if pin == ff.Grid.Pin.CENTER:
                y1 //= 2
            y += y1
        return x, y

    @staticmethod
    def get_point(q):
        """
        Returns a valid coordinate from a pair of coordinates.

        If the intersect coordinate is -1, then it is invalid.

        q: tuple
            intersect, pocket
            coordinates
        """
        return q[1] if q[0] == -1 else q[0]
