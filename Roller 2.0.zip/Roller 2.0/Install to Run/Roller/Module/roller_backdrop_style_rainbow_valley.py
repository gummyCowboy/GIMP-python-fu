#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class RainbowValley:
    """Fill the backdrop with a colorful abstract."""

    def __init__(self, one):
        """
        Create the Rainbow Valley backdrop-style.

        one: One
            Has variables.
        """
        e = deepcopy(one.d)
        j = one.stat.render.image
        z = Lay.clone(j, one.z)
        self.group = Lay.group(j, one.k, parent=one.z.parent)

        pdb.plug_in_plasma(j, z, e[ok.RANDOM_SEED], 3)
        Lay.order(j, z, self.group)

        for i in range(10):
            z = Lay.clone(j, z)
            z.name = "Layer #{} of 10".format(i + 1)
            z.mode = fu.LAYER_MODE_DIFFERENCE
            pdb.plug_in_despeckle(j, z, i, 0, 0, 255)

            if i % 2:
                z = Lay.clone(j, z)
                z.mode = fu.LAYER_MODE_LIGHTEN_ONLY
                RenderHub.noise(one.stat, z, e)
                e[ok.RANDOM_SEED] += 1
                pdb.plug_in_despeckle(j, z, i, 0, 0, 255)
                z = Lay.merge(j, z)

            do_engrave = 0

            if e[ok.TEXTURE]:
                if i < 7 or i == 9:
                    do_engrave = 1

            elif i < 7:
                do_engrave = 1

            if do_engrave:
                z = Lay.clone(j, z)

                pdb.plug_in_engrave(j, z, max(i, 2), 1)

                z.mode = fu.LAYER_MODE_BURN
                z = Lay.merge(j, z)
                pdb.plug_in_wind(
                    j,
                    z,
                    Pdb.Wind.THRESHOLD_0,
                    Pdb.Wind.FROM_TOP,
                    Pdb.Wind.STRENGTH_50,
                    Pdb.Wind.BLAST,
                    Pdb.Wind.LEADING_EDGE
                )

        z = Lay.merge_group(j, self.group)
        if e[ok.EMBOSS]:
            z = Lay.clone(j, z)
            pdb.plug_in_emboss(j, z, 45, 30., 1, 1)
            z.mode = fu.LAYER_MODE_OVERLAY
