#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Script type: Python-fu
Script Title: Roller
Tested on GIMP version: 2.10.20; Windows 10, 64 bit; GTK 2.28.7

What is Does:
    Create image compositions like wallpaper.

Where The Script Installs:
  The script is accessed through
  the main image window and the Filters / Render menus.

  Place the script in GIMP's Python-Fu folder. You can discover where this
  folder is by opening the Preference dialog (Edit / Preferences). In
  this dialog, find Folders / Plug-ins (scroll down). On the right-panel
  are two paths. The first path listed is the Python-Fu folder.

Get the latest version: github.com/gummycowboy
"""

from copy import deepcopy
from os.path import expanduser
from random import choice
from random import randint as rnd
import cPickle
import gimp
import gimpfu as fu
import glob
import gobject
import gtk
import math
import os
import pango
import platform
import pygtk
import sys

pygtk.require("2.0")

program_title = "Roller 1.04"

# Debug:
# Creates a file and / or appends error messages and piped print statements.
# import time
# sys.stderr = open("D:\\roller_1_error.txt", 'a')
# print >> sys.stderr, "\nRoller 1,", time.ctime()

# constants:
ABLE = gtk.STATE_NORMAL
ACCEPT = 'accept'
ACT = 'activate'

# alignment key:
ALIGN = 'align'
Align = gtk.Alignment

# center horizontal alignment:
ALL_X = 0, 0, 1, 0
ALL_Y = 0, 0, 0, 1

# Automate Button key:
AUTO = 'auto'
BD = "Backdrop"

# Backdrop Image key:
BD_IMAGE = 'bd_image'

# Backdrop Style key:
BD_STYLE = 'bd_style'
BDI = BD + " Image"
BLK = 0, 0, 0
BOT = "Bottom"
C = 'c'

# preview layer margin:
C1 = 200, 200, 206

# preview cell margin:
C2 = 150, 156, 150

# preview image rectangle:
C3 = 106, 100, 100

# preview background:
C4 = 25, 25, 25

# preview cell lines:
C5 = 225, 225, 225
CE = 'Center'
CELL_KEY = 'cell_key'
CELL_MARG = 'Cell Margins'
CHG = 'changed'
CLK = 'clicked'
CM_BOT = 'cm_bot'

# Cell Margin's cell table key:
CM_CELL = 'cm_cell'
CM_LEF = 'cm_lef'

# Cell Margins Per Cell Checkbutton key:
CM_PER = 'cm_per'
CM_RIG = 'cm_rig'
CM_TOP = 'cm_top'
COD = "Colored Diamonds"
COL = 'col'
COG = "Color Grid"
COORD = "Coordinates"
CORN = "Corners"
CORRUPT = \
    "The session file is corrupted,\n" \
    "so the default settings will be used.\n" \
    "Please visit\nwww.github.com/gummycowboy\n" \
    "for a newer version of " + program_title + "."

# global dictionary:
D = {}

# file folder key:
DIR = 'dir'

# Draw widgets function key:
DRAW = 'draw'
DEF = "Default"
DIM = "Dimensions"
DISPLAY = 'display'
DUPE = "The file,\n\n{},\n\nalready exists. Do you want to overwrite?"

# 3D Effect key:
EFFECT = 'effect'
EFFECTS = 'effects'
EXIT = ": Use Escape or Enter"

# Format key:
FORMAT = 'format'
FF = "Flood Fill"
FH = "Flip Horizontal"
FIL = "Fill Cell"
FIRST = "1st Image"
FLIP_H = 'flip_h'
FLIP_V = 'flip_v'
FORMAT_GRP = 'format_grp'
FV = "Flip Vertical"
GRID = "Grid"
H = 'h'
HBox = gtk.HBox

# Resolution Height Entry key:
HG = 'hg'
HORZ = 'horz'

# Image ComboBox key:
IMAGE = 'image'
IMG_GRP = 'img_grp'
INT_X = 0
K = 'Color'
KEY = 'key'

# Layers Dict:
L = {}
LAB_H = 'lab_h'
LAB_I = "w: ", "h: ", "x: ", "y: "
LAB_W = 'lab_w'
LAB_X = 'lab_x'
LAB_Y = 'lab_y'
LAY_MARG = 'Layer Margins'
LM_BOT = 'lay_bot'
LM_LEF = 'lay_lef'
LM_RIG = 'lay_rig'
LM_TOP = 'lay_top'
LAYER = 'layer'
LAYERS = 'layers'
LCK = "Locked"
LFT = "Left"
LIST_KEY = 'Return', 'Delete', 'space'
LOAD_ERR = "Roller was unable to load presets."
MARGIN = 18
MAX_COL = 65535

# Merge Cells table key:
ME_CELL = 'me_cell'
MERG_PER = 'merge'
MID = "Middle"
N = 'Name'

# Format Name Entry key:
NAME = 'name'
NON = "None"
NORMAL = fu.LAYER_MODE_NORMAL
NP = "No Picture"
NXT = "Next"
OP = 'Opacity'

# options key:
OPT = 'opt'

# padding keyword:
PAD = 'pad'
PAD5 = [5, 5, 5, 5]
PARENT = 'parent'
PC = "Per Cell"
pdb = fu.pdb
PE = "Process"
PF = "Pattern Fill"

# Image Placement table key:
PL_CELL = 'pl_cell'

# Placement Per Cell Checkbutton key:
PLACE_PER = 'place_per'

# window-id key for the WINDOW dictionary:
POSE = 'pose'

# Properties cell table key:
PR_CELL = 'pr_cell'
PRESET = 'preset'
PREVIEW = 'preview'
PREVIEW_BG = "Preview Background"

# Preview Options key:
PREVIEW_OPT = 'preview_opt'

# Placement Per Cell Checkbutton key:
PROP_PER = 'prop_per'
R = 'r'
RANGE = 'range'
RAT = "Ratios"
RENDER = 'render'
REPLACE = fu.CHANNEL_OP_REPLACE

# Resize key:
RESIZE = 'resize'
RGT = "Right"

# Rotate Entry key:
ROT = 'rot'
ROW = 'row'

# Scrollbar width, height:
SCROLL = 22
SELF_BG = 'self_bg'

# Session dict key:
SESS = 'session'
SIZE = 'size'
STYLES = 'styles'
TEXT = 'text'

# window title key:
TITLE = 'title'
TOP = "Top"
TOPL = MARGIN / 2, 0, MARGIN, MARGIN
TR = "Transparency"
TRM = "Trim"
UND = "- undefined -"
USE = "Last Used"

# cell table size:
V = 'v'
VBox = gtk.VBox

# Session version key:
VERSION = 'version'
VERT = 'vert'
W = 'w'

# Set Wallpaper CheckButton key:
WH = 255, 255, 255

# Resolution Width Entry key:
WI = 'wi'

# Window positions dictionary key:
WINDOW = 'window'
X = 'x'
Y = 'y'

# left justify alignment:
ZERO = 0, 0, 0, 0

# Related keys:
CELL_K = ME_CELL, PL_CELL, CM_CELL, PR_CELL
CELL_SB_K = CM_TOP, CM_BOT, CM_LEF, CM_RIG
LAB_K = LAB_W, LAB_H, LAB_X, LAB_Y
LAY_SB_K = LM_TOP, LM_BOT, LM_LEF, LM_RIG
PER_CELL_K = PLACE_PER, CM_PER, PROP_PER
PLACE_K = RESIZE, HORZ, VERT, IMAGE
PROP_K = FLIP_H, FLIP_V, ROT, OP

# cell tuple indices:
RESIZE_X, IMAGE_X, HORZ_X, VERT_X = range(4)
FLIP_H_X, FLIP_V_X, ROTATE_X, OP_X = range(4)
TOP_X, BOT_X, LEF_X, RIG_X = range(4)

# colors:
BG_BUTTON = gtk.gdk.Color(52000, 52000, MAX_COL)
BG_BUTTON_FOCUS = gtk.gdk.Color(50000, 50000, MAX_COL)
BG_CELL = gtk.gdk.Color(56000, 56000, MAX_COL)
BG_HEAD = 44000, 44000, MAX_COL
BG_GROUP = gtk.gdk.Color(54000, 54000, MAX_COL)

# options:
VRT = [TOP, MID, BOT]
HRZ = [LFT, CE, RGT]
RSZ = [FIL, LCK, NON, TRM]

# UICell-type overlay index:
PL_X, PR_X = 1, 3

# label text:
MARGINS = TOP, BOT, LFT, RGT

"""
variables:
    a : sequence
    b : sequence
    c : sequence, column
    d : dict
    e : dict
    f : float
    g : widget, window
    h : height
    i : iteration
    j : Img, gtk.image, iteration
    k : key
    m : flag
    n : string
    p : process
    q : iterable
    r : row
    s : size
    t : size
    u : point
    v : point
    w : width
    x : coordinate, index
    y : coordinate
    z : layer
"""


def clear(z):
    """
    Clears a layer or a selection.

    z: drawable
    """
    pdb.gimp_edit_clear(z)


def create_2d_table(r, c, a=0):
    """
    Returns a 2D list.

    r, c: size of the table (integers)
    a: initial cell value
    """
    b = [a] * r

    for i in range(r):
        b[i] = [a] * c
    return b


def draw_color_grid(j, z, m=0):
    """
    Draws a checkerboard with two colors.

    OddRC may look ugly if the resulting rectangles are too small.

    m: flag: If it is true the row and column counts are doubled.

    Returns the merged layer.
    """
    info_msg("draw color grid")
    w, h = j.width, j.height
    s = w, h
    r, c = rnd(1, w / 12), rnd(1, h / 12)
    odd = OddRC(s, r, c)

    # Draw horizontal stripes:
    Lay.color_fill(z, WH)

    D[W] = w
    D[X] = 0

    for r1 in range(0, r, 2):
        _, D[Y], _, D[H] = odd.calc(r1, 0)
        Sel.rect(j)

    Sel.fill(z, BLK)
    Sel.none(j)

    # Draw vertical stripes:
    z1 = Lay.add(j, "V")
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    Lay.color_fill(z1, WH)

    D[H] = h
    D[Y] = 0

    for c1 in range(0, c, 2):
        D[X], _, D[W], _ = odd.calc(0, c1)
        Sel.rect(j)

    Sel.fill(z1, BLK)
    z = Lay.merge(j, z1)

    # Fill the b/w checkerboard:
    Sel.color(j, z, WH)
    Sel.fill(z, rnd_col())
    Sel.color(j, z, BLK)
    Sel.fill(z, rnd_col())
    Sel.none(j)
    return z


def float_to_layer(j, z):
    """
    Converts a floating selection to a layer.

    j: GIMP image
    z: floating selection

    Returns the layer.
    """
    pdb.gimp_floating_sel_to_layer(z)
    return pdb.gimp_image_get_active_layer(j)


def info_msg(msg):
    """ Used to output messages to the error console. """
    a = pdb.gimp_message_get_handler()

    pdb.gimp_message_set_handler(fu.ERROR_CONSOLE)
    fu.gimp.message(msg)
    pdb.gimp_message_set_handler(a)


def check_session(d):
    """
    Verifies the contents of a session file.

    d: Session dict

    Returns the validity of the Session file where positive value is corrupt.
    """
    m_int = WI, HG
    m_str = PRESET, BD_STYLE, BD_IMAGE
    f_int = (OP, ROW, COL, ROT) + LAY_SB_K
    f_bool = FLIP_H, FLIP_V, MERG_PER, PROP_PER, PLACE_PER, CM_PER
    f_str = EFFECT, IMAGE, NAME, PRESET, RESIZE
    per_cell = (MERG_PER,) + PER_CELL_K

    try:
        # main:
        for k in m_int:
            if not isinstance(d[k], int):
                return 1

        for k in m_str:
            if not isinstance(d[k], basestring):
                return 2

        for k in (PREVIEW_OPT, WINDOW):
            if not isinstance(d[k], dict):
                return 4

        if not isinstance(d[FORMAT], list):
            return 5

        # format:
        for f in d[FORMAT]:
            for k in f_int:
                if not isinstance(f[k], int):
                    return 6

            for k in f_bool:
                if f[k] not in (0, 1):
                    return 7

            for k in f_str:
                if not isinstance(f[k], basestring):
                    return 8

            # cell tables:
            for x, k in enumerate((ME_CELL, PL_CELL, CM_CELL, PR_CELL)):
                if f[k]:
                    if f[per_cell[x]]:
                        if len(f[k]) != f[ROW]:
                            return 9
                        for col in f[k]:
                            if col:
                                if len(col) != f[COL]:
                                    return 10

    except Exception as ex:
        show_err(ex)
        return 11
    return 0


def kopy(j):
    """
    Copies an image.

    j: GIMP image
    """
    pdb.gimp_edit_copy_visible(j)


def pickle_dump(d):
    """
    Writes a file using "cPickle".

    d: dict

    Returns a flag, which is set to true if the operation succeeded.
    """
    a = 0

    try:
        with open(d['file'], "wb") as output_file:
            cPickle.dump(d['data'], output_file)
        a = 1

    except Exception as ex:
        show_err(ex)
        show_err("Roller is unable to save\n" + d['file'])
    return a


def pickle_load(d):
    """
    Reads a "cPickle" type file.

    d: dict

    Returns "e" as the data read by
    "cPickle" or None if the operation failed.
    """
    e = None

    try:
        with open(d['file'], "rb") as input_file:
            e = cPickle.load(input_file)

    except Exception as ex:
        if d['show']:
            show_err(ex)
            show_err("Roller is unable to load\n" + d['file'])
    return e


def pixelize(j, z, w, h):
    pdb.plug_in_pixelize2(j, z, w, h)


def rnd_col():
    """ Returns a tuple of integers containing random colors (r, g, b). """
    return rnd(0, 255), rnd(0, 255), rnd(0, 255)


def seal(a, b, c):
    """
    Limits a value to be between two numbers.

    a: value to limit
    b: minimum value
    c: maximum value
    """
    return max(min(c, a), b)


def show_err(a):
    """
    Posts an error message to GIMP's Error Console.

    a: Exception or string
    """
    if not isinstance(a, basestring):
        a = repr(a)
    info_msg(a)


class OddRC:
    """
    Calculates x and y coordinates of rows and columns.

    Applies width and column division remainders
    to width and height calculations for full image
    evenly distributed row and column plotting.

    OddRC is a row and column plotting convention used with "pixl8".

    Floating point arithmetic won't work with "pixl8", so OddRC is used.
    """
    def __init__(self, s, r, c):
        """
        s: size of the grid
        r, c: row and column scales of the grid
        """
        self.r, self.c = r, c

        # Calculate cell size.
        # Converting to float prevents int underflow:
        self.w = int(max(s[0] / 1.0 / c, 1))
        self.h = int(max(s[1] / 1.0 / r, 1))

        # Calculate remainders:
        self.rx = s[0] % c
        self.ry = s[1] % r

    def add(self, u, v):
        """
        Used when cells are merged, and the merge
        cell's dimension needs to be determined.

        Returns the top-left coordinates and the scale of an array of cells.

        u: top-left cell, (r, c)
        v: bottom-right cell, (r, c)
        """
        w = h = 0

        for r in range(v[0] - u[0] + 1):
            _, _, _, f = self.calc(u[0] + r, u[1])
            h += f

        for c in range(v[1] - u[1] + 1):
            _, _, f, _ = self.calc(u[0], u[1] + c)
            w += f

        x, y, _, _ = self.calc(u[0], u[1])
        return x, y, w, h

    def calc(self, r, c):
        """
        Returns x, y, w, h for the cell at r, c.

        x, y: top-left point
        r, c: row, column (int)
        """
        x, y = c * self.w, r * self.h
        w, h = self.w, self.h

        if c < self.rx:
            x += c
            if w:
                w += 1

        else:
            x += self.rx

        if r < self.ry:
            y += r
            if h:
                h += 1

        else:
            y += self.ry
        return x, y, w, h


class Wig:
    """ This is the base widget for the custom widgets. """

    def __init__(self, p, **d):
        """
        p: callback function
        d: dict
        """
        self.feed = p
        self.wig = d['g']
        self.key = d['k'] if 'k' in d else None

    def callback(self, *a):
        """
        The widget changed.

        a: unused
        """
        self.feed(self)

    def enable(self, *a):
        """
        Makes the widget operational.

        a: unused
        """
        self.wig.set_sensitive(1)

    def disable(self, *a):
        """
        Makes the widget inoperable.

        a: unused
        """
        self.wig.set_sensitive(0)


class FormatList(Wig):
    """
    This is widget group with TreeView and TreeView manipulation Buttons.
    """

    def __init__(self, g, p, p1, p2):
        """
        Adds the format list and Buttons to a group.

        g: container
        d: dict
        p: on new function
        p1: on edit function
        p2: on change function
        """
        w = MARGIN
        self.buttons = []
        self.items = []
        self.do_new_format = p
        self.do_edit_format = p1
        g1 = RBox(1)

        # Format Stack TreeView:
        self.store = gtk.ListStore(str)

        g3 = gtk.TreeView(model=self.store)
        g3.set_headers_visible = 0

        Wig.__init__(self, p2, k=FORMAT, g=g3)

        # Create column:
        col = gtk.TreeViewColumn(
            "Format Stack:", gtk.CellRendererText(), text=0)

        col.set_min_width(120)
        col.set_sizing(gtk.TREE_VIEW_COLUMN_AUTOSIZE)

        # Add column to TreeView:
        g3.append_column(col)

        # When a row is selected, it emits a signal:
        g3.get_selection().connect(CHG, self.selected)
        g3.connect('key_press_event', self.on_key_press)
        g1.g.set_padding(w / 2, w, w, w)

        g4 = RBox(2, align=ALL_Y, pad=(0, 0, MARGIN / 2, 0))
        d = {}
        a = zip(
            ("New Format", "Edit Format", "Del Format", "Move Up", "Move Down"),
            (
                self.create_format,
                self.edit_format,
                self.del_format,
                self.move_sel_up,
                self.move_sel_down),
            (0, 1, 1, 2, 2))

        for n, p, b in a:
            g6 = CoOpButton(n, p, b)
            g4.add(g6.g)
            self.buttons.append(g6)

        g7 = gtk.ScrolledWindow()

        g7.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        g7.add_with_viewport(g3)
        g1.add(g7)
        g1.add(g4.g)
        g.add(g1.g)
        self.verify_buttons()

    def create_format(self, *a):
        """
        Called when the user activated the New Format Button.

        a: unused
        """
        q = self.items
        n = "Format"
        a = len(q) + 1
        go = 1

        while(go):
            go = 0
            n1 = n + " " + str(a)
            for i in q:
                if i[0] == n1:
                    a += 1
                    go = 1
                    break

        self.store.append([n1])
        q.append((n1, len(q)))
        self.verify_buttons()
        self.select_item(len(q) - 1)
        self.do_new_format(n1)

    def del_format(self, *a):
        """
        Deletes a row in the TreeView.

        a: unused
        """
        self.items.pop(self.get_sel_x())

        a, b = self.wig.get_selection().get_selected()

        a.remove(b)
        self.feed()

    def edit_format(self, *a):
        """
        Called because the user clicked the Edit Button.

        a: unused
        """
        self.do_edit_format()

    def get_sel_x(self):
        """ Returns the index of the selected item. """
        return self.wig.get_selection().get_selected_rows()[1][0][0]

    def get_sel_text(self):
        """ Returns the selected format name. """
        return self.items[self.get_sel_x()][0]

    def get_val(self):
        """ Returns a list of strings displayed in the list. """
        return self.items

    def load(self, q):
        """
        Populates the TreeView from a list.
        The previous index is replaced.

        q: list of tuples (name, index)
        """
        self.store.clear()
        self.items = []
        for x, b in enumerate(q):
            self.store.append([b[0]])
            self.items.append((b[0], x))

    def move_sel_down(self, *a):
        """
        Called when the user activates the Move Down Button.

        Moves selections down one line in the TreeView.

        If x selection is at the bottom of the list,
        then the item rotates to the top of the list.

        a: unused
        """
        x = x1 = self.get_sel_x()
        a = len(self.items)
        x += 1

        if x == a:
            x = 0
        self.shuffled(x, x1)

    def move_sel_up(self, *a):
        """
        Called when the user activated the Move Up Button.

        Moves selections up one line in the TreeView.

        If "x" selection is at the top of the list, then
        the item rotates to the bottom of the list.

        a: unused
        """
        x = x1 = self.get_sel_x()
        a = len(self.items)
        x -= 1

        if x < 0:
            x = a - 1
        self.shuffled(x, x1)

    def on_key_press(self, g, a):
        """
        Used to catch delete and return key.

        g: TreeView
        a: key-press event
        """
        n = gtk.gdk.keyval_name(a.keyval)
        if len(self.items):
            if n in LIST_KEY:
                x = LIST_KEY.index(n)
                (self.edit_format, self.del_format, self.selected)[x]()
                return 1

    def rename(self, x, n):
        """
        Renames a format.

        x: the current list entry index
        n: name of format
        """
        self.items[x] = n, self.items[x][1]
        self.load(self.items)

    def selected(self, *a):
        """
        Called when a selection event occurs.

        a: unused
        """
        self.verify_buttons()

    def select_item(self, x):
        """
        Selects, sort of, a TreeView item.

        x: index in the TreeView
        """
        self.wig.set_cursor(x)

    def set_indices(self):
        """
        Updates the "self.items" indices.

        This is called after the Session
        dictionary's format list is re-ordered.
        """
        for i in range(len(self.items)):
            self.items[i] = self.items[i][0], i

    def set_val(self, q):
        """
        Loads the format list from a session dictionary's list of formats.

        q: list of formats from the session dict.
        """
        b = []
        for d in q:
            b.append((d[NAME], 0))
        self.load(b)

    def shuffled(self, x, x1):
        """
        Selects a TreeView item by index.

        Re-orders the list.

        x: new position (int)
        x1: old position
        """
        q = self.items[x1]

        self.items.pop(x1)
        self.items.insert(x, q)
        self.feed()
        self.load(self.items)
        self.select_item(x)

    def verify_buttons(self):
        """ Validates Buttons that are dependent on the list quantity. """
        a, b = self.wig.get_selection().get_selected()

        if b:
            cell_val = a[b][0]

        # The move and delete Buttons are dependent
        # on their selection state and the list size:
        for g in self.buttons[1:]:
            if b and len(self.items) >= g.need:
                g.enable()

            else:
                g.disable()


class RBox:
    """ This is a GTK Box widget with an Alignment. """

    def __init__(self, x, align=ZERO, pad=None):
        """
        x: index to box where 0 is a VBox, 1 is a HBox, 2 is a VButtonBox
        align: Alignment tuple (f, f, f, f)
        pad: padding tuple (TBLR)
        """
        g = self.g = Align(*align)
        g1 = self.box = (VBox, HBox, gtk.VButtonBox)[x]()

        if pad:
            g.set_padding(*pad)
        g.add(g1)

    def add(self, g):
        """ g: widget """
        self.box.add(g)


class RButton(Wig):
    """ This is a custom GTK Button. """

    def __init__(self, n, p, padx=0, align=ALL_X):
        """
        n: Button label
        p: callback function
        padx: index to padding
        """
        w = MARGIN
        g = self.g = Align(*align)
        g1 = gtk.Button(n)

        Wig.__init__(self, p, g=g1)
        g1.connect(CLK, self.callback)
        g.add(g1)
        if not isinstance(padx, int):
            g.set_padding(*padx)

        elif padx:
            x = padx - 1
            g.set_padding((
                w / 2, w / 4, w / 4)[x],
                (0, 0, w / 2)[x],
                w,
                w)


class RCheckButton(Wig):
    """ This is a custom GTK CheckButton. """

    def __init__(self, p, n, k=None, pad=0):
        """
        n: label text
        p: callback function
        k: widget key
        pad: flag: true results in padding
        """
        w = MARGIN
        g = self.g = Align(*ZERO)
        g1 = gtk.CheckButton(label=n)

        g.add(g1)
        g1.connect(CLK, self.callback)
        g1.connect(ACT, self.callback)

        if pad:
            g.set_padding(w / 2, w / 2, w, w)
        Wig.__init__(self, p, k=k, g=g1)

    def get_val(self):
        """ Returns the value of the CheckButton. """
        return int(self.wig.get_active())

    def set_val(self, a):
        """
        Sets the CheckButton checked state.

        a: int
        """
        self.wig.set_active(a)


class RCombo(Wig):
    """ Used by RComboBox and RComboBoxE. """

    def __init__(self, p, sub, **d):
        """
        p: callback function
        sub: sub-class
        d: dict
        """
        w = MARGIN
        self.opt = []
        self.length = 0
        g = self.g = Align(*ALL_X)

        self.store = gtk.ListStore(str)
        g1 = d['g'] = sub(self.store)

        Wig.__init__(self, p, **d)

        a = gtk.CellRendererText()
        a.props.ellipsize = pango.ELLIPSIZE_END

        g1.pack_start(a)
        g.add(g1)

        if sub == gtk.ComboBox:
            g1.add_attribute(a, 'text', 0)

        else:
            g1.child.set_editable(0)

        if 'padx' in d:
            g.set_padding(0, (0, w / 2)[int(d['padx'] == 2)], w, w)
        if 'opt' in d:
            self.load(d['opt'])

    def get_val(self):
        """ Returns the string displayed in the ComboBox. """
        return self.opt[self.wig.get_active()]

    def load(self, q):
        """
        Sets the options the ComboBox.

        q: iter of option strings
        """
        self.store.clear()

        self.opt = q

        for n in q:
            self.store.append([n])
        self.length = len(q)

    def set_val(self, n):
        """
        Sets the ComboBox display.

        n: string to display
        """
        if n in self.opt:
            x = self.opt.index(n)

        else:
            x = 0
        self.wig.set_active(x)


class RComboBox(RCombo):
    """ This ComboBox displays options. """

    def __init__(self, p, **d):
        """
        p: callback function
        d: dict
        """
        RCombo.__init__(self, p, gtk.ComboBox, **d)
        self.wig.connect(CHG, self.callback)


class RComboBoxE(RCombo):
    """ This ComboBox displays options and text using an Entry. """

    def __init__(self, p, **d):
        """
        p: callback function
        d: dict
        """
        RCombo.__init__(self, p, gtk.ComboBoxEntry, **d)
        self.wig.child.connect(CHG, self.callback)

    def get_text(self):
        """
        Returns the value displayed in the Entry.

        n: text
        """
        return self.wig.child.get_text()

    def set_text(self, n):
        """
        Sets the text in the Entry.

        n: text
        """
        self.wig.child.set_text(n)


class REntry(Wig):
    """ This is a custom GTK Entry. """

    def __init__(self, p, k, padx=0):
        """
        p: callback function
        k: widget's key
        padx: index to padding
        """
        w = MARGIN
        g = self.g = Align(*ALL_X)
        g1 = gtk.Entry(100)

        g.add(g1)
        g1.connect(CHG, self.callback)

        if padx:
            g.set_padding(0, (0, w / 2)[padx - 1], w, w)
        Wig.__init__(self, p, k=k, g=g1)

    def get_val(self):
        """ Returns the value displayed in the Entry. """
        return self.wig.get_text()

    def set_val(self, n):
        """
        Sets the value displayed in the the Entry.

        n: string to place in the Entry
        """
        self.wig.set_text(n)


class REventBox(gtk.EventBox):
    """ This is a custom GTK EventBox. """

    def __init__(self, a):
        """
        a: gtk color component
            None, int, tuple, or GTK color
        """
        super(gtk.EventBox, self).__init__()
        if a is not None:
            if isinstance(a, int):
                q = gtk.gdk.Color(a, a, MAX_COL)

            elif isinstance(a, tuple):
                q = gtk.gdk.Color(*a)

            else:
                q = a
            self.modify_bg(ABLE, q)


class RLabel:
    """ This is a custom GTK Label. """

    def __init__(self, n, pad=ZERO, align=ZERO):
        """
        n: label text
        a: padding tuple (top, bottom, left, right)
        """
        g = self.lab = gtk.Label(n)
        g1 = self.g = Align(*align)
        g1.set_padding(*pad)
        g1.add(g)

    def destroy(self):
        """ Destroys the internal widgets. """
        self.lab.destroy()
        self.g.destroy()


class RSpinButton(Wig):
    """ This is a custom GTK SpinButton. """

    def __init__(self, p, q, k=None, q1=(1, 1), padx=0):
        """
        p: callback function
        q: range tuple
        k: widget key
        q1: increments tuple
        padx: index to padding (0..1)
        """
        w = MARGIN
        g = self.g = Align(*ALL_X)
        g1 = gtk.SpinButton(adjustment=None, climb_rate=2, digits=0)

        Wig.__init__(self, p, k=k, g=g1)

        # Tell the SpinButton to respond to click events:
        for i in (
                gtk.gdk.BUTTON_RELEASE_MASK,
                gtk.gdk.BUTTON_PRESS_MASK):
            g1.add_events(i)

        g.add(g1)
        g1.set_range(*q)
        g1.set_increments(*q1)
        g1.connect('button_press_event', self.focus)
        g1.connect('value_changed', self.callback)
        g1.connect('key_release_event', self.key_handler)
        if padx:
            x = padx - 1
            g.set_padding(0, (0, w / 2)[x], w, w)

    def focus(self, *a):
        """
        Improves focus handling.

        Corrects an invalid numeric.

        a: unused
        """
        self.wig.grab_focus()
        self.set_val(self.get_val())

    def get_val(self):
        """ Returns the value of the SpinButton. """
        n = self.wig.get_text()
        return int(n) if n.isdigit() else int(self.wig.get_value())

    def key_handler(self, g, a):
        """
        Keeps arrow and page key events from signaling twice.

        g: SpinButton
        a: key release event
        """
        VALID_SB = ['Up', 'Down', 'Page_Up', 'Page_Down']
        n = gtk.gdk.keyval_name(a.keyval)

        if n in VALID_SB:
            return
        self.callback()

    def set_val(self, a):
        """
        Sets the SpinButton display value.

        a: int
        """
        self.wig.set_value(a / 1.)


class CoOpButton(RButton):
    """
    This Button has an extra variable, "self.need".
    "self.need" is the number of items in a list
    needed for the Button to be valid.
    """

    def __init__(self, n, p, a):
        """
        n: label
        p: callback function
        a: the number of items needed for this Button to be valid
        """
        self.need = a
        RButton.__init__(self, n, p)


class ColoredButton(gtk.EventBox):
    """ This Button changes color. """

    def __init__(self, n, p):
        """
        n: button text
        p: callback function
        """
        super(ColoredButton, self).__init__()

        self.feed = p

        # Embed widget inside VBox and HBox:
        g = self.label = gtk.Label(n)
        g1 = self.hbox = HBox()

        self.add(g1)
        g1.add(g)

        # events to react to:
        a = gtk.gdk
        p = self.connect

        for i in (
                a.BUTTON_RELEASE_MASK,
                a.BUTTON_PRESS_MASK,
                a.ENTER_NOTIFY_MASK,
                a.LEAVE_NOTIFY_MASK,
                a.FOCUS_CHANGE_MASK,
                a.KEY_PRESS_MASK,
                a.KEY_RELEASE_MASK):
            self.add_events(i)

        self.set_can_focus(1)
        p('button_press_event', self.on_click)
        p('key_press_event', self.on_key_press) # key release?
        p('focus_in_event', self.focus_in)
        p('focus_out_event', self.focus_out)

    def focus_in(self, *a):
        """
        Called when the EventBox receives focus.

        a: unused
        """
        self.set_color(BG_BUTTON_FOCUS)

    def focus_out(self, *a):
        """
        Called when the EventBox loses focus.

        a: unused
        """
        self.set_color(BG_BUTTON)

    def on_click(self, g, a=None):
        """
        Pass the click event to the button owner.

        g: self
        a: gtk.Event
        """
        self.feed(g)
        self.grab_focus()

    def on_key_press(self, g, a):
        """
        Called when because the user pressed a key.

        g: self
        a: key-press event
        """
        if gtk.gdk.keyval_name(a.keyval) == 'space':
            self.feed(g)
            return 1

    def set_color(self, color, state=ABLE):
        """
        Sets the button-face color.

        color: gtk.gdk.Color
        state: normal or disabled
        """
        self.modify_bg(state, color)

    def set_label(self, n):
        """
        Change button's text.

        n: string
        """
        self.label.set_text(n)

    def set_size(self, w=10, h=10):
        """
        Try to set the size of the button.

        w: width of widget, int
        h: height of widget, int
        """
        self.set_size_request(width=w, height=h)

    def set_text_color(self, color, state=ABLE):
        """
        Sets the color of the button's text.

        color: gtk.gdk.Color
        state: normal or disabled
        """
        self.label.modify_fg(state, color)

    def show(self):
        """ Draws the custom button. """
        super(ColoredButton, self).show()
        for g in (self.hbox, self.vbox, self.label):
            g.show()


class SwitchButton(ColoredButton):
    """ Used to process CG cell connection events. """

    def __init__(self, n, p, r, c, g):
        """
        n: text on button
        p: callback functions
        r: row
        c: column
        g: gtk Box-type, widget's container which is padded
        """
        self.r = r / 2
        self.c = c / 2
        self.action = p
        p = self.switch
        self.pad = g
        self.switch = 0
        ColoredButton.__init__(self, n, p)

    def switch(self, g):
        """
        Reverses the switch setting.

        Calls the connection operator.

        g: self
        """
        x = self.switch = int(not self.switch)

        self.set_label(("+", "-")[x])
        self.action[x](CG.grid[self.r][self.c])


class GPerCell(RCheckButton):
    """ Manages a group of widgets that work cells on a per cell basis. """

    def __init__(self, p, p1, n, k, g, x):
        """
        p: callback function
        p1: open window function
        n: Button label
        k: CheckButton's key
        g: container
        x: "win_x" index
        """
        self.key = k
        self.cb_feed = p
        self.x = x
        self.cell_key = CELL_K[x]
        p = self.relay
        g1 = Splitter(padx=3)

        RCheckButton.__init__(self, p, PC, k=k)

        self.button_feed = p1
        p1 = self.relay_button
        g2 = self.g1 = RButton(n, p1)

        g1.left.add(self.g)
        g1.right.add(g2.g)
        g1.pack()
        g.add(g1.g)

    def relay(self, g):
        """
        Intercepts signals from the CheckButton.

        g: CheckButton widget
        """
        self.validate_button()
        self.cb_feed(g)

    def relay_button(self, g):
        """
        Intercepts changed signal from the Button.

        g: Button
        """
        self.button_feed(self.x)

    def set_val(self, a):
        """
        Sets the value of the CheckButton.

        a: int
        """
        RCheckButton.set_val(self, a)
        self.validate_button()

    def validate_button(self):
        """
        The cell window Button is valid only if the CheckButton is checked.
        """
        self.g1.enable() if self.get_val() else self.g1.disable()


class GPreset(RComboBoxE):
    """ Manages a preset group of widgets. """

    def __init__(self, g, p, data_p, saver, parent, preset):
        """
        g: container
        p: callback function
        d: dict that gets saved
        saver: class type called when saving a preset
        parent: owner window
        """
        w = MARGIN
        self.get_data = data_p
        self.saver = saver
        self.parent = parent
        self.preset = preset
        self.presets = []
        self.key = PRESET
        self.relay = p
        p = self.on_change

        self.collect_presets()
        RComboBoxE.__init__(self, p, k=PRESET, opt=self.opt, padx=2)

        g1 = self.wig
        g2 = Splitter(padx=3)
        g3 = self.save_b = RButton("Save", self.save)
        g4 = self.del_b = RButton("Delete", self.delete)

        g.add(RLabel("Session Preset:", TOPL).g)
        g2.both(g3.g, g4.g)
        g2.pack()
        g.add(self.g)
        g.add(g2.g)

    def collect_presets(self):
        """ Creates a list, "self.opt", of internal and external Presets. """
        q = self.presets = []
        self.opt = []       # menu options
        ext_files = []
        d = dict(parent=self.parent, show=0)
        go = 0
        b = self.preset

        try:
            search_path = os.path.join(D[DIR], b.pattern)

            # Ignore sub-directories:
            ext_files = glob.glob(search_path)
            go = 1

        except Exception as ex:
            show_err(ex)
            show_err(LOAD_ERR)

        if go:
            # Loads internal presets into a list:
            for i in b.internal_presets:
                q.append(i)

            # Makes an external preset file list:
            for n in ext_files:
                file_name = os.path.basename(n)
                split_name = file_name.split(u"_")
                combined_name = u""

                for n1 in range(1, len(split_name)):
                    combined_name = combined_name + split_name[n1]

                types = combined_name.split(u".")
                name = types[0]
                d['file'] = n

                try:
                    # Check version:
                    c = pickle_load(d)
                    if c:
                        if c[VERSION] == b.version:
                            q.append([Preset.ext, name, n])

                except Exception as ex:
                    show_err(ex)
            for i in q:
                self.opt.append(i[Preset.name_x])

    def delete(self, *a):
        """
        Called when the user activated the Delete Button.

        a: unused
        """
        n = self.get_val()

        # Get the file's full file name so that it can be deleted:
        for n1 in self.presets:
            if n1[Preset.name_x].lower() == n.lower():
                n2 = n1[Preset.file_x]
                g = gtk.MessageDialog(
                    parent=self.parent,
                    flags=gtk.DIALOG_MODAL,
                    type=gtk.MESSAGE_QUESTION,
                    buttons=gtk.BUTTONS_YES_NO,
                    message_format="Do you want to delete:\n"+ n2 + "?")

                g.set_title("Delete File Confirmation")

                a = g.run()

                g.destroy()
                if int(a == gtk.RESPONSE_YES):
                    try:
                        os.remove(n2)

                        g = gtk.MessageDialog(
                            parent=self.parent,
                            flags=gtk.DIALOG_MODAL,
                            type=gtk.MESSAGE_INFO,
                            buttons=gtk.BUTTONS_CLOSE,
                            message_format="The file:\n" + n2 + "\nwas removed.")

                        g.set_title("File Deleted")

                        a = g.run()

                        g.destroy()
                        self.refresh(UND)

                    except Exception as ex:
                        show_err(ex)
                        show_err("Roller was unable to delete the file.")

    def on_change(self, g):
        """
        When the ComboBoxE is activated, the delete Button needs to be validated.

        g: ComboBoxE
        """
        n = self.get_text()

        if n not in (DEF, UND, USE):
            UISave.preset_name = self.get_val()

        if n != UND:
            d = self.preset.get_preset(n, self.presets)

            self.verify_del_button()
            self.relay(g, d)

    def refresh(self, n):
        """
        The state of the preset menu has changed.

        n: the name to display on the menu
        """
        UI.loading += 1

        self.collect_presets()
        self.load(self.opt)

        p = self.set_val if n in self.opt else self.set_text

        p(n)

        if n not in (DEF, UND, USE):
            UISave.preset_name = n
        UI.loading -= 1

    def save(self, *a):
        """
        Called when the user activated the Save Button.

        a: unused
        """
        self.parent.iconify()

        if self.saver(dict(
                get_data=self.get_data,
                parent=self.parent,
                preset=self.preset)).reply:
            self.refresh(UISave.preset_name)
        self.parent.present()

    def verify_del_button(self):
        """ The delete Button is valid for an external preset. """
        a = self.del_b
        p = a.enable if self.get_val() not in (UND, DEF, USE) else a.disable
        p()


class PlusMenu(RComboBoxE):
    """
    This menu remembers menu selection states and shares this
    info with the user by displaying a "+" by the drop-down option.
    """

    def __init__(self, p, key, opt):
        """
        p: callback function
        key: widget's key
        """
        self.plus_feed = p
        self.d = {}
        q = self.origin_opt = sorted(opt)

        for n in q:
            self.d[n] = 0
        RComboBoxE.__init__(self, self.update, k=key, opt=q, padx=2)

    def get_val(self):
        """
        Returns a dictionary with its keys set from menu
        items and values indicating their selection.
        """
        return self.d

    def set_val(self, d):
        """
        Sets the menu options to the keys in "d".

        The menu always shows the same text.

        d: dict
        """
        q = self.origin_opt
        self.temp_opt = q[:]

        if d:
            for x, n in enumerate(q):
                if n in d:
                    if d[n]:
                        self.temp_opt[x] = "+ " + n
                        self.d[n] = 1

        self.load(self.temp_opt)
        self.set_text("Preview Options")

    def update(self, g):
        """
        Updates a menu option by inverting its selection state.

        Updates "self.d" for "get".

        g: ComboBox
        """
        x = g.wig.get_active()
        if x > -1:
            n = self.origin_opt[x]
            if n:
                if n[0] == "+":
                    n = n[2:]

                if self.d[n]:
                    self.d[n] = 0

                else:
                    self.d[n] = 1

                self.plus_feed(self)
                self.set_val(self.d)

            # Updates completed:
            return 1


class Splitter:
    """ Creates two equal sized vertical boxes on the x-axis. """

    def __init__(self, padx=0):
        """
        padx: index to padding (1..3)
        """
        w = MARGIN
        self.g = self.box = HBox()

        if padx:
            g = self.g = Align(*ALL_X)

            g.add(self.box)
            g.set_padding(w / 2, (0, w / 2)[int(padx == 3)], w, w)

        g1 = RBox(0, align=ALL_X)
        g2 = RBox(0, align=ALL_X)
        self.left, self.right = g1.box, g2.box
        g3 = self.left_a = g1.g
        g4 = self.right_a = g2.g
        if padx > 1:
            g3.set_padding(0, 0, 0, w / 2)
            g4.set_padding(0, 0, w / 2, 0)

    def both(self, g, g1):
        """
        Adds two widgets to the Splitter.

        g: left widget
        g1: right widget
        """
        self.left.add(g)
        self.right.add(g1)

    def no_pack(self):
        """ Adds the two Alignment objects to the box. """
        self.box.add(self.left_a)
        self.box.add(self.right_a)

    def pack(self):
        """
        Makes the the two VBoxes the same size.
        Adds the same-sized VBoxes to the HBox.

        This function is called after all of
        the widgets have been added to the Splitter.
        """
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

        # Transform size:
        for g in (self.left_a, self.right_a):
            same_size.add_widget(g)

        g = reversed(same_size.get_widgets())
        [self.box.add(g1) for g1 in g]


class Lay:
    """ These are functions used to manage image layers. """

    @staticmethod
    def add(j, n, a=0):
        """
        Adds a layer to an image.

        j: image
        n: name of layer
        a: layer offset (0 is top)

        Returns the new layer.
        """
        z = Lay.new(j, n)

        j.add_layer(z, a)
        return z

    @staticmethod
    def add_to_group(j, z, n):
        """
        Creates a layer and adds it to a group.

        j: image
        z: group layer
        n: name of new layer
        """
        z1 = Lay.new(j, n)

        Lay.place(j, z1, z)
        return z1

    @staticmethod
    def bury(j, z):
        """
        Removes a layer.

        j: GIMP image
        z: layer
        """
        pdb.gimp_image_remove_layer(j, z)

    @staticmethod
    def color_fill(z, q):
        """
        Fills a layer with a color.

        z: layer
        q: color
        """
        pdb.gimp_context_set_foreground(q)
        z.fill(fu.FOREGROUND_FILL)

    @staticmethod
    def dupe(j, z):
        """
        Duplicates a layer.

        z: layer

        Returns the duplicated layer.
        """
        z1 = pdb.gimp_item_get_parent(z)
        z2 = pdb.gimp_layer_copy(z, 0)
        Lay.place(j, z2, z1=z1, a=0)
        return z2

    @staticmethod
    def group(j, n, a=0):
        """
        Creates a group layer.

        j: image
        n: name of group
        a: layer offset

        Returns the group layer.
        """
        z = pdb.gimp_layer_group_new(j)
        j.add_layer(z, a)
        z.name = n
        return z

    @staticmethod
    def merge(j, z):
        """
        Merges layer down. The target must be visible.

        j: GIMP image
        z: layer

        Returns the merged layer.
        """
        return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    @staticmethod
    def move(z, x, y):
        """
        Moves a layer to a set of coordinates.

        z: layer
        x: coordinate
        y: coordinate
        """
        pdb.gimp_layer_set_offsets(z, x, y)

    @staticmethod
    def order(j, z, z1, a=0):
        """
        Moves a layer into a different position.

        j: GIMP image
        z: layer
        z1: parent
        a: layer offset
        """
        pdb.gimp_image_reorder_item(j, z, z1, a)

    @staticmethod
    def paste(j, z):
        """
        Pastes the content of the buffer.

        j: GIMP image
        z: paste to layer
        """
        a = pdb.gimp_edit_paste(z, 0)
        return float_to_layer(j, a)

    @staticmethod
    def place(j, z, z1=None, a=0):
        """
        Inserts a layer into an image.

        j: image
        z: layer to insert
        z1: group
        a: offset (0 is top, negative above, positive is below)
        """
        pdb.gimp_image_insert_layer(j, z, z1, a)

    @staticmethod
    def new(j, n):
        """
        Creates a layer.

        j: GIMP image to receive layer
        n: layer name

        Returns the layer.
        """
        return pdb.gimp_layer_new(
            j,
            j.width,
            j.height,
            fu.RGBA_IMAGE,
            n,
            100,
            NORMAL)

    @staticmethod
    def rotate(j, a):
        """
        Rotates the bottom layer.

        j: GIMP image
        a: rotation amount in degrees

        Returns the transformed layer.
        """
        pdb.gimp_context_set_transform_direction(fu.TRANSFORM_FORWARD)
        pdb.gimp_context_set_transform_resize(fu.TRANSFORM_RESIZE_ADJUST)
        z = pdb.gimp_item_transform_rotate(
            j.layers[0], math.radians(a), True, 0, 0)

        pdb.gimp_image_resize_to_layers(j)
        return z


class Layout:
    """ Manages image and preview placement. """
    pix = 0

    @staticmethod
    def get_cell_margin(r, c, d):
        """
        Returns the image margins for a cell at r, c.

        d: format dict
        """
        if not d[CM_PER]:
            return d[CM_TOP], d[CM_BOT], d[CM_LEF], d[CM_RIG]

        else:
            return d[CM_CELL][r][c]

    @staticmethod
    def get_flip_h(j, d):
        """
        Returns the flip horizontal flag of an image being placed.

        j: Img
        d: format dict
        """
        if d[PROP_PER]:
            return d[PR_CELL][j.r][j.c][FLIP_H_X]

        else:
            return d[FLIP_H]

    @staticmethod
    def get_flip_v(j, d):
        """
        Returns the flip vertical flag of an image being placed.

        j: Img
        d: format dict
        """
        if d[PROP_PER]:
            return d[PR_CELL][j.r][j.c][FLIP_V_X]

        else:
            return d[FLIP_V]

    @staticmethod
    def get_horz_just(r, c, d):
        """
        Returns the horizontal justification for the cell at r, c.

        d: format dict
        """
        if d[PLACE_PER]:
            return d[PL_CELL][r][c][HORZ_X]

        else:
            return d[HORZ]

    @staticmethod
    def get_image(r, c, d):
        """
        Returns an Img object for the cell at r, c.

        d: format dict
        """
        if not d[PLACE_PER]:
            n = d[IMAGE]

        else:
            n = d[PL_CELL][r][c][IMAGE_X]
        return Img.get_image(n)

    @staticmethod
    def sel_img_trim(d, j, j1):
        """
        Used to get the cell-size scaled image pixels
        for a trimmed or non-resized image.

        Creates a selection rectangle for the image transfer.

        Copies the selection.

        d: Format dict
        j: Img
        j1: GIMP image

        Returns the selection size.
        """
        # Need to select from one layer only:
        j2 = 0

        if len(j1.layers) > 1:
            kopy()
            j2 = j1
            j1 = Img.paste()

        r, c = j.r, j.c
        n = Layout.get_horz_just(r, c, d)
        s = j.cell_size
        t = j1.width, j1.height

        if n == LFT:
            x = 0
            x1 = s[0]

        elif n == CE:
            x = max(t[0] / 2 - s[0] / 2, 0)
            x1 = min(t[0] / 2 + s[0] / 2 + s[0] % 2, t[0])

        else:
            x = max(t[0] - s[0], 0)
            x1 = t[0]

        n1 = Layout.get_vert_just(r, c, d)

        if n1 == TOP:
            y = 0
            y1 = s[1]

        elif n1 == MID:
            y = max(t[1] / 2 - s[1] / 2, 0)
            y1 = min(t[1] / 2 + s[1] / 2 + s[1] % 2, t[1])

        else:
            y = max(t[1] - s[1], 0)
            y1 = t[1]

        # Correct for underflow:
        if x == x1:
            x1 += 1

        if y == y1:
            y1 += 1

        w = max(x1 - x, 1)
        h = max(y1 - y, 1)

        pdb.gimp_image_select_rectangle(
            j1,
            REPLACE,
            x,
            y,
            w,
            h)

        Sel.kopy(j1.layers[0])
        _, x, y, x1, y1 = pdb.gimp_selection_bounds(j1)

        if j2:
            Img.bury(j2)
        return x1 - x, y1 - y

    @staticmethod
    def get_placement(r, c, d):
        """
        Returns the image placement for a cell at r, c.

        d: format dict
        """
        if not d[PLACE_PER]:
            return d[RESIZE], d[IMAGE], d[HORZ], d[VERT]

        else:
            return d[PL_CELL][r][c]

    @staticmethod
    def get_prop_opacity(r, c, d):
        """
        Returns the opacity property of a cell at r, c.

        d: format dict
        """
        if d[PROP_PER]:
            return d[PR_CELL][r][c][OP_X]

        else:
            return d[OP]

    @staticmethod
    def get_resize_type(r, c, d):
        """
        Returns the resize type for the cell at r, c.

        d: format dict
        """
        if d[PLACE_PER]:
            return d[PL_CELL][r][c][0]

        else:
            return d[RESIZE]

    @staticmethod
    def get_rotate(r, c, d):
        """
        Returns the resize type for the cell at r, c.

        d: format dict
        """
        if d[PROP_PER]:
            return d[PR_CELL][r][c][ROTATE_X]

        else:
            return d[ROT]

    @staticmethod
    def get_vert_just(r, c, d):
        """
        Returns the vertical justification for the cell at r, c.

        d: format dict
        """
        if d[PLACE_PER]:
            return d[PL_CELL][r][c][VERT_X]

        else:
            return d[VERT]

    @staticmethod
    def is_draw_one_margin(d):
        """
        Returns true when drawing one margin per row or column.

        d: format dict
        """
        return not any((
            d[PLACE_PER],
            d[CM_PER],
            d[MERG_PER],
            d[PROP_PER]))

    @staticmethod
    def new_render():
        """
        Creates a new image for the Preview and render.

        Returns the new image.
        """
        j = L[RENDER] = Img.new(D[WI], D[HG])

        # Turn off undo functionality:
        pdb.gimp_image_undo_group_start(j)
        return j

    @staticmethod
    def place_img(j, d, cell):
        """
        Copies and pastes images on or above the image layer.

        j: Img
        d: format dict
        cell: Cell
        """
        # The Img will enter the copy and paste buffer:
        Img.mold(j, d, cell)

        j1 = L[RENDER]

        if not Layout.pix:
            a = 1 if Preview.has_formats else 0
            L[IMG_GRP] = Lay.group(j1, d[NAME] + ": Image", a=a)

        z = Lay.paste(j1, j1.layers[-1])
        z.opacity = Layout.get_prop_opacity(j.r, j.c, d) / 1.

        if Layout.get_flip_h(j, d):
            z = pdb.gimp_item_transform_flip_simple(
                z, fu.ORIENTATION_HORIZONTAL, True, 0)

        if Layout.get_flip_v(j, d):
            z = pdb.gimp_item_transform_flip_simple(
                z, fu.ORIENTATION_VERTICAL, True, 0)

        Lay.order(j1, z, L[IMG_GRP])
        Lay.move(z, j.x, j.y)
        Layout.pix += 1


class Sel:
    """ Organizes selection functions. """

    @staticmethod
    def all(j):
        """
        Selects all of the image.

        j:  GIMP image
        """
        pdb.gimp_selection_all(j)

    @staticmethod
    def color(j, z, q):
        """
        Creates a selection based on color.

        j: GIMP image
        z: layer
        q: color
        """
        pdb.gimp_image_select_color(j, REPLACE, z, q)

    @staticmethod
    def fill(z, q):
        """
        Fills a selection on a layer.

        z: layer to apply fill
        q: color
        """
        pdb.gimp_context_set_background(q)
        pdb.gimp_edit_bucket_fill(
            z,
            fu.BACKGROUND_FILL,
            NORMAL,
            100,
            0, False, 0, 0)
    @staticmethod
    def kopy(z):
        """
        Copies a selection.

        z: layer for selection
        """
        pdb.gimp_edit_copy(z)

    @staticmethod
    def none(j):
        """
        Removes the selection.

        j: GIMP image
        """
        pdb.gimp_selection_none(j)

    @staticmethod
    def rect(j):
        """
        Draws a selection rectangle.

        j: GIMP image
        """
        pdb.gimp_image_select_rectangle(
            j,
            fu.CHANNEL_OP_ADD,
            D[X],
            D[Y],
            seal(D[W], 1, j.width),
            seal(D[H], 1, j.height))


class EFDS:
    """ This creates a drop shadow effect on an image layer. """

    name = "Drop Shadow"

    def __init__(self, m=0):
        # Use a selection so the shadow doesn't appear below the image:
        j, z = L[RENDER], L[IMAGE]

        pdb.gimp_image_select_item(j, REPLACE, z)

        if m:
            pdb.gimp_selection_invert(j)

        pdb.script_fu_drop_shadow(
            j,
            z,
            .05,   # offset x
            .05,   # offset y
            (40, 30)[m],    # blur radius
            BLK,
            (66, 100)[m],   # opacity
            0)     # resize image

        z1 = pdb.gimp_item_get_parent(z)
        z = z1.layers[0]

        # Double the shadow effect:
        if not m:
            z = Lay.dupe(j, z)
            z = Lay.merge(j, z)

        z.mode = fu.LAYER_MODE_MULTIPLY
        if m:
            z.name = EFII.name

        else:
            Lay.order(j, z, z1, a=1)


class EFII:
    """ This creates a sunken image effect on an image layer. """

    name = "Inlay Image"

    def __init__(self):
        EFDS(m=1)


class BSAC:
    """ Uses pixelize to create an approximate average color. """
    name = "Average Color"

    def __init__(self):
        D[X] = D[Y] = 0
        j = L[RENDER]
        w, h = D[W], D[H] = j.width, j.height

        kopy(j)

        j1 = Img.paste()

        Img.resize(j1, w * 2, h * 2)

        z = j1.layers[0]

        Lay.move(z, 0, 0)
        pixelize(j1, z, w, h)
        Sel.rect(j1)
        Sel.kopy(z)
        Img.bury(j1)

        z = Lay.paste(j, L[BD])
        L[BD] = Lay.merge(j, z)


class BSBD:
    """ Backdrop image """
    name = BDI

    def __init__(self):
        return


class BSCD():
    """ Creates a diamond grid. """
    name = COD

    def __init__(self):
        w = max(D[WI] * 2, D[HG] * 2)
        s = w, w
        j = Img.new(s[0], s[1])
        z = Lay.add(j, "Diamond")
        z = draw_color_grid(j, z)

        Lay.rotate(j, 45)
        kopy(j)
        Img.bury(j)

        j = L[RENDER]
        z = Lay.paste(j, L[BD])
        L[BD] = Lay.merge(j, z)


class BSCG:
    """ Creates a randomly colored grid. """

    name = COG

    def __init__(self):
         # OddRC may look ugly if the resulting rectangles are too small:
        L[BD] = draw_color_grid(L[RENDER], L[BD])


class BSFF:
    """ Fills the backdrop with a random color. """
    name = FF

    def __init__(self):
        Lay.color_fill(L[BD], rnd_col())


class BSPF:
    """ Fills the backdrop with a pattern. """
    name = PF

    def __init__(self):
        _, q = pdb.gimp_patterns_get_list(None)

        pdb.gimp_context_set_pattern(choice(q))
        Sel.all(L[RENDER])
        pdb.gimp_edit_bucket_fill(
            L[BD],
            fu.BUCKET_FILL_PATTERN,
            NORMAL,
            100.,
            0, False, 0, 0)


class BSTR:
    """ Transparency does nothing. """
    name = TR

    def __init__(self):
        return


class EFS:
    """
    Contains the collection of 3D Effects.

    It is used by the 3D Effects menu.
    """
    obj = (EFDS, EFII)

    def __init__(self):
        """ Creates a list of names from the 3D Effects collection. """
        self.names = [i.name for i in EFS.obj]


class BDS:
    """
    Contains the collection of Backdrop Styles.

    It is used by the Backdrop Styles menu.
    """
    obj = (BSAC, BSBD, BSCD, BSCG, BSFF, BSPF, BSTR)

    def __init__(self):
        """ Creates a list of names for Backdrop Styles. """
        self.names = [i.name for i in self.obj]


class Preview():
    """ Manages render preview. """

    # flags:
    has_formats = has_background = 0

    # Preview canvas size:
    size = 0, 0

    def __init__(self):
        return

    def add_text(self, x, y, z):
        """
        Adds a text layer to the format group.

        Moves the layer to its final position.

        x, y: final position
        z: text layer
        """
        Lay.place(L[RENDER], z, self.format_grp)
        pdb.gimp_text_layer_set_color(z, WH)
        Lay.move(z, x, y)
        z.opacity = 66.

    def draw_cell_margins(self, d):
        """
        Draws cell margins.

        d: format dict
        """
        just_one = Layout.is_draw_one_margin(d)
        row, col = d[ROW], d[COL]
        cell = self.cell
        m = 0
        for r in range(row):
            for c in range(col):
                margin = Layout.get_cell_margin(r, c, d)
                for x in range(4):
                    draw = 1

                    # left, right:
                    if x in (LEF_X, RIG_X):
                        if just_one and r > 0:
                            draw = 0

                    # top, bottom:
                    else:
                        if just_one and c > 0:
                            draw = 0
                    if draw:
                        v = margin[x]
                        if v:
                            # Unavailable cells have zero dimensions:
                            if cell.get_w(r, c):
                                m = 1
                                D[X], D[Y] = cell.get_pos(r, c)
                                D[X] += (
                                    0,
                                    0,
                                    -margin[LEF_X],
                                    cell.get_w(r, c))[x]

                                D[Y] += (
                                    -margin[TOP_X],
                                    cell.get_h(r, c),
                                    0,
                                    0)[x]

                                D[W] = (
                                    cell.get_margin_w(r, c, d),
                                    cell.get_margin_w(r, c, d),
                                    v,
                                    v)[x]

                                D[H] = (
                                    v,
                                    v,
                                    cell.get_margin_h(r, c, d),
                                    cell.get_margin_h(r, c, d))[x]
                                Sel.rect(L[RENDER])
        if m:
            self.fill(C2)

    def draw_coord(self, j):
        """
        Draws image coordinates at the top-left of an image rectangle.

        j: Img
        """
        n = str(j.x) + ", " + str(j.y)
        z = pdb.gimp_text_layer_new(L[RENDER], n, 'Sans-serif', 11., fu.PIXELS)
        self.add_text(j.x + 3, j.y, z)

    def draw_corners(self, j):
        """
        Draw image corner coordinates.

        j: Img
        """
        # top-right:
        x = j.x + j.new_size[0]
        n = str(x) + ", " + str(j.y)
        z = pdb.gimp_text_layer_new(L[RENDER], n, 'Sans-serif', 11., fu.PIXELS)

        self.add_text(x - z.width - 3, j.y, z)

        # bottom-left:
        y = j.y + j.new_size[1]
        n = str(j.x) + ", " + str(y)
        z = pdb.gimp_text_layer_new(L[RENDER], n, 'Sans-serif', 11., fu.PIXELS)
        self.add_text(j.x + 3, y - z.height, z)

    def draw_dim(self, j):
        """
        Draws an image's dimension at the bottom-right of an image rectangle.

        j: image
        """
        w, h = j.new_size[0], j.new_size[1]
        n = str(w) + ", " + str(h)
        z = pdb.gimp_text_layer_new(L[RENDER], n, 'Sans-serif', 11., fu.PIXELS)
        self.add_text(j.x + w - z.width - 3, j.y + h - z.height, z)

    def draw_format(self, d):
        """
        Draws a format.

        d: format dict
        """
        self.cell = Cell(d)
        e = D[SESS][PREVIEW_OPT]
        q = ((
                CELL_MARG, self.draw_cell_margins), (
                LAY_MARG, self.draw_layer_margins), (
                GRID, self.draw_grid
            ))

        self.draw_image_types(d)
        for i in q:
            if e[i[0]]:
                i[1](d)

    def draw_grid(self, d):
        """
        Draws grid lines.

        d: format dict
        """
        m = 0
        row, col = d[ROW], d[COL]
        w, h = D[WI], D[HG]
        top, left = d[LM_TOP], d[LM_LEF]

        # Grid lines divide the layer space:
        D[W] = w - left - d[LM_RIG]
        D[X] = left
        D[H] = 0

        # Draw rows:
        if row > 1:
            for r in range(1, row):
                D[Y] = self.cell.get_row_y(r)
                D[Y] += top
                if D[Y] > 0 and D[Y] < h:
                    m = 1
                    Sel.rect(L[RENDER])

        D[W], D[H] = 0, h - top - d[LM_BOT]
        D[Y] = top

        # Draw columns:
        if col > 1:
            for c in range(1, col):
                D[X] = self.cell.get_col_x(c)
                D[X] += left
                if D[X] > 0 and D[X] < w:
                    m = 1
                    Sel.rect(L[RENDER])
        if m:
            self.fill(C5)

    def draw_image_types(self, d):
        """
        Draws a rectangle that represents an image.

        d: format dict
        """
        row, col = d[ROW], d[COL]
        cell = self.cell
        m = 0
        e = D[SESS][PREVIEW_OPT]
        q = ((
                COORD, self.draw_coord), (
                CORN, self.draw_corners), (
                DIM, self.draw_dim), (
                N, self.draw_name), (
                RAT, self.draw_ratio
            ))

        for r in range(row):
            for c in range(col):
                if cell.has_image(r, c, d):
                    m = 1
                    j = Layout.get_image(r, c, d)
                    j.r, j.c = r, c
                    j.rot = Layout.get_rotate(r, c, d)

                    if j.rot:
                        if m:
                            Sel.fill(D[LAYER], C3)
                            Sel.none(L[RENDER])
                            m = 0

                    if j.rot:
                        z = Lay.add_to_group(L[RENDER], self.format_grp, j.n)

                    Img.mold_rect(j, d, cell)

                    if j.rot:
                        self.rotate(j, z, cell, d)
                    for i in q:
                        if e[i[0]]:
                            i[1](j)
        if m:
            self.fill(C3)

    def draw_layer_margins(self, d):
        """
        Draws layer margins.

        d: format dict
        """
        m = 0
        for x, k in enumerate(LAY_SB_K):
            if d[k]:
                m = 1
                if x in (TOP_X, BOT_X):
                    # top, bottom:
                    D[X] = d[LM_LEF]
                    D[W] = D[WI] - d[LM_LEF] - d[LM_RIG]
                    D[H] = d[k]

                    if x == TOP_X:
                        D[Y] = 0

                    else:
                        D[Y] = D[HG] - d[k]

                else:
                    # left, right:
                    D[W] = d[k]
                    D[H] = D[HG] - d[LM_TOP] - d[LM_BOT]
                    D[Y] = d[LM_TOP]

                    if x == LEF_X:
                        D[X] = 0

                    else:
                        D[X] = D[WI] - d[k]
                Sel.rect(L[RENDER])
        if m:
            self.fill(C1)

    def draw_name(self, j):
        """
        Draws a document title at the center of an image rectangle.

        j: Img
        """
        z = pdb.gimp_text_layer_new(L[RENDER], j.n, 'Sans-serif', 11., fu.PIXELS)
        x = j.new_size[0] / 2 + j.x - z.width / 2
        y = j.new_size[1] / 2 + j.y + z.height / 2
        self.add_text(x, y, z)

    def draw_ratio(self, j):
        """
        Draws an image ratio at the center of an image rectangle.

        A ratio is an image center point divided by the render size.

        j: Img
        """
        x = j.new_size[0] / 2 + j.x
        y = j.new_size[1] / 2 + j.y
        x1 = x / 1. / D[WI]
        y1 = y / 1. / D[HG]
        r_x = format(x1, '.2f')
        r_y = format(y1, '.2f')
        n = r_x[int(x1 < 1):] + ", " + r_y[int(y1 < 1):]
        z = pdb.gimp_text_layer_new(
            L[RENDER], n, 'Sans-serif', 11., fu.PIXELS)

        x2 = x - z.width / 2
        y2 = y - z.height / 2
        self.add_text(x2, y2, z)

    def fill(self, q):
        """
        Fills the selection with a color on the current format layer.

        q: color (RGB tuple)
        """
        Sel.fill(D[LAYER], q)
        Sel.none(L[RENDER])

    def rotate(self, j, z, cell, d):
        """
        Rotates an image rectangle.

        j: Img
        z: rotation layer
        cell: Cell
        d: format dict
        """
        # Create a new image with the selection:
        j1 = L[RENDER]

        Sel.fill(z, C3)
        Sel.kopy(z)
        clear(z)
        Sel.none(j1)

        s = cell.get_cell_size(j.r, j.c)
        j2 = Img.paste()
        z1 = Lay.rotate(j2, j.rot)

        j.new_size = z1.width, z1.height

        if j.new_size[0] > s[0] or j.new_size[1] > s[1]:
            # The image won't fit into the cell so get the size that will:
            w, h = j.new_size = Img.calc_lock(s, j.new_size)
            z1 = pdb.gimp_item_transform_scale(z1, 0, 0, w, h)

        z2 = Sel.kopy(z1)

        Img.bury(j2)

        z3 = pdb.gimp_edit_paste(z, 0)
        z4 = float_to_layer(j1, z3)
        z4.name = "Rotated " + j.n

        Lay.bury(j1, z)
        cell.calc_rect_pos(d, j)
        Lay.move(z4, j.x, j.y)
        z4.opacity = 66.

        # for additional preview options:
        D[X], D[Y] = j.x, j.y

    def show(self):
        """ Draws the preview. """
        a = Preview
        Images.next_x = 0
        s = D[SIZE] = D[WI], D[HG] = D[SESS][WI], D[SESS][HG]

        if a.has_background:
            if a.size != s:
                # Delete old preview:
                pdb.gimp_image_undo_group_end(L[RENDER])
                pdb.gimp_display_delete(D[DISPLAY])
                a.has_background = a.has_formats = 0

        if not a.has_background:
            # Create a new preview:
            j = Layout.new_render()
            z = L[PREVIEW_BG] = Lay.add(j, PREVIEW_BG)
            D[DISPLAY] = pdb.gimp_display_new(j)
            a.has_background = 1
            a.size = D[WI], D[HG]
            Lay.color_fill(z, C4)

        j = L[RENDER]
        q = D[SESS][FORMAT]
        start = len(q) - 1

        if a.has_formats:
            # Delete group:
            Lay.bury(j, L[PREVIEW])

        if start > -1:
            # new group:
            z = L[PREVIEW] = Lay.group(j, "Preview")

        # Draw format previews:
        for x in range(start, -1, -1):
            a.has_formats = 1
            d = q[x]
            n = d[NAME]
            z1 = self.format_grp = Lay.group(j, "Preview Group: " + n)

            Lay.order(j, z1, z)

            z1 = D[LAYER] = Lay.add_to_group(j, z1, "Preview: " + n)
            z1.opacity = 66.
            self.draw_format(d)

        pdb.gimp_image_set_active_layer(j, z)
        pdb.gimp_displays_flush()


class Cell:
    """ Calculates cell-related dimensions. """
    def __init__(self, d):
        """
        Creates a new cell table, "tb", to store the cell sizes.

        Calculates cell sizes.

        Corrects cell size underflow.

        d : format dict
        """
        r, c = d[ROW], d[COL]
        self.r, self.c = r, c

        # cell table with cell keys: X, Y, W, H:
        self.tb = create_2d_table(r, c)

        # Calculate layer size:
        w = D[WI] - d[LM_LEF] - d[LM_RIG]
        h = D[HG] - d[LM_TOP] - d[LM_BOT]

        # "s" is the size of a cell before image margins are subtracted
        # and after layer margins are subtracted from the layer size:
        s = seal(w, 1, D[WI]), seal(h, 1, D[HG])
        self.odd = OddRC(s, self.r, self.c)

        # Cells reduce their size with cell margins:
        for r in range(self.r):
            for c in range(self.c):
                self.calc_cell(r, c, d)

    def calc_block(self, start, end, d):
        """ Recalculates the cell sizes for a block of cells. """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self.calc_cell(r, c, d)

    def calc_cell(self, r, c, d):
        """
        Adds a dict entry to "self.tb" for the cell at r, c.

        d: format dict
        """
        # Check if merging cells:
        if d[MERG_PER]:
            s = d[ME_CELL][r][c]

            # Sub-top-left cells are unavailable:
            if s == (-1, -1):
                x = y = w = h = 0

            else:
                k1 = (r + s[0] - 1, c + s[1] - 1)
                x, y, w, h = self.odd.add((r, c), k1)

        else:
            x, y, w, h = self.odd.calc(r, c)

        if w:
            a = Layout.get_cell_margin(r, c, d)
            x += a[LEF_X] + d[LM_LEF]
            y += a[TOP_X] + d[LM_TOP]

            # Correct for margin overflow errors:
            x = seal(x, 0, D[WI] - 1)
            y = seal(y, 0, D[HG] - 1)
            w = w - a[LEF_X] - a[RIG_X]
            h = h - a[TOP_X] - a[BOT_X]

            # Set "w", "h" to the minimum value if size under-flowed:
            w = max(w, 1)
            h = max(h, 1)
        self.tb[r][c] = dict(x=x, y=y, w=w, h=h)

    def calc_rect_pos(self, d, j):
        """
        For an image or rectangle, calculates its (x, y) position in a cell.

        d: format dict
        j: Img
        """
        r, c = j.r, j.c
        x, y = self.get_pos(r, c)
        w, h = j.new_size[0], j.new_size[1]

        n = Layout.get_horz_just(r, c, d)
        n1 = Layout.get_vert_just(r, c, d)

        if n == CE:
            self.get_w(r, c)
            x += (self.get_w(r, c) - w) / 2

        elif n == RGT:
            x += self.get_w(r, c) - w

        if n1 == MID:
            y += (self.get_h(r, c) - h) / 2

        elif n1 == BOT:
            y += self.get_h(r, c) - h
        j.x, j.y = x, y

    def get_cell_info(self, r, c):
        """ Returns a cell's dimension and position for a cell at r, c. """
        return (
            self.tb[r][c][W], self.tb[r][c][H],
            self.tb[r][c][X], self.tb[r][c][Y])

    def get_cell_size(self, r, c):
        """ Returns a cell's width and height for a cell at r, c. """
        return self.tb[r][c][W], self.tb[r][c][H]

    def get_col_x(self, c):
        """ Returns the coordinate x for column, "c". """
        x, _, _, _ = self.odd.calc(0, c)
        return x

    def get_row_y(self, r):
        """ Returns the coordinate y for row, "r". """
        _, y, _, _ = self.odd.calc(r, 0)
        return y

    def get_h(self, r, c):
        """ Returns the cell height for a cell at r, c. """
        return self.tb[r][c][H]

    def get_margin_h(self, r, c, d):
        """
        Returns the height of an image margin for the cell at r, c.

        d: format dict
        """
        if Layout.is_draw_one_margin(d):
            a = Layout.get_cell_margin(r, c, d)
            return D[HG] - d[LM_TOP] - d[LM_BOT] - a[TOP_X] - a[BOT_X]

        else:
            return self.get_h(r, c)

    def get_margin_w(self, r, c, d):
        """
        Returns the width of an image margin at r, c.

        d: format dict.
        """
        if Layout.is_draw_one_margin(d):
            a = Layout.get_cell_margin(r, c, d)
            return D[WI] - d[LM_LEF] - d[LM_RIG] - a[LEF_X] - a[RIG_X]

        else:
            return self.get_w(r, c)

    def get_pos(self, r, c):
        """ Returns the cell coordinate (x, y) for a cell at r, c. """
        return self.tb[r][c][X], self.tb[r][c][Y]

    def get_w(self, r, c):
        """ Returns the cell width for a cell at r, c. """
        return self.tb[r][c][W]

    def has_image(self, r, c, d):
        """
        Returns true if a cell has an available image at r, c.

        d: format dict
        """
        if self.get_w(r, c):
            a = Layout.get_placement(r, c, d)
            n = a[IMAGE_X]

            if n == NON or not Layout.get_prop_opacity(r, c, d):
                return 0

            if n == NXT:
                if Images.image_count > Images.next_x:
                    return 1

                else:
                    return 0
            if n in Images.format_img_list:
                return 1
        return 0


class CG:
    """ Manages cell grouping and serves UICell. """

    # "overlay" is a flag. When it is true,
    # merge cell controls are not displayed:
    overlay = 0

    # "collective" is a table of cell dictionaries:
    collective = None

    # "sizer" is a Cell.
    # It's used when displaying cell sizes in a Merge Cells window:
    sizer = None

    # "format" is a format dict:
    format = None

    @staticmethod
    def calc_bottom_right(d):
        """
        Return the row and column for the
        bottom-right cell of a merged cell group.

        d: top-left cell dict
        """
        return d[R] + d[V][0] - 1, d[C] + d[V][1] - 1

    @staticmethod
    def connect_left(d):
        """
        This routine is called when the user has clicked
        on a horizontal connector in the cell graph.

        d: cell dict
        """
        origin = CG.get_topleft(d=d)
        top = CG.get_topleft(u=(d[R], d[C] - 1))

        CG.merge_groups(top, origin)

    @staticmethod
    def connect_up(d):
        """
        Called when the user has clicked on
        a vertical connector in the cell graph.

        d: cell dict
        """
        origin = CG.get_topleft(d=d)
        top = CG.get_topleft(u=(d[R] - 1, d[C]))

        CG.merge_groups(top, origin)

    @staticmethod
    def draw(d):
        """
        Draws a cell and its connectors.

        d: cell dict
        """
        g = CG.get_topleft(d=d)
        start, end = CG.get_start_end_of_top(g)
        CG.set_cell_looks(d, start, end)

    @staticmethod
    def generate_group(slices):
        """
        Slices organize themselves into one or two groups.

        A slice is a cell group with a piece of itself
        removed by a "connect_up" or "connect_left" process
        and the resulting merge group.

        slices: a dict of dictionaries where each defines a group of cells
        """
        for k in slices:
            """
            Sort the two possible groups
            into a larger and smaller group (short).
            The larger group will have the greater cell count.
            The smaller group will be the cells not in the larger group.
            If there's only one group,
            the smaller group won't get initialized.

            Starts by finding the longer and shorter row.
            """
            u = slices[k][V]
            long_row_width = long_row_height = 0
            long_col_width = long_col_height = 0
            short_col_width = short_row_height = 0
            short_row_width = short_col_height = 0
            start_long_row = [0, 0]
            start_short_row = [0, 0]
            start_long_col = [0, 0]
            start_short_col = [0, 0]

            for r in range(k[0], k[0] + u[0]):
                row_width = 0
                first_col = -1

                for c in range(k[1], k[1] + u[1]):
                    if CG.is_vector(k, r, c):
                        row_width += 1
                        if first_col < 0:
                            first_col = c

                    elif row_width:
                        break

                if row_width > long_row_width:
                    if long_row_width > 0:
                        # Second group inherits from the first group:
                        short_row_width = long_row_width
                        short_row_height = long_row_height
                        start_short_row = start_long_row

                    # Initialize first group:
                    long_row_width = row_width
                    long_row_height = 1
                    start_long_row = r, first_col

                elif row_width:
                    # The vector is long or short:
                    if row_width == long_row_width:
                        long_row_height += 1

                    else:
                        if short_row_height:
                            # Add another row:
                            short_row_height += 1

                        else:
                            # Initialize second group:
                            short_row_width = row_width
                            start_short_row = r, first_col
                            short_row_height = 1

            # Start finding the long and short column:
            for c in range(k[1], k[1] + u[1]):
                col_height = 0
                first_row = -1

                for r in range(k[0], k[0] + u[0]):
                    if CG.is_vector(k, r, c):
                        col_height += 1
                        if first_row < 0:
                            first_row = r

                    elif col_height:
                        break

                if col_height > long_col_height:
                    if long_col_height > 0:
                        # Second group inherits from the first group:
                        short_col_width = long_col_width
                        short_col_height = long_col_height
                        start_short_col = start_long_col

                    # Initialize first group:
                    long_col_height = col_height
                    long_col_width = 1
                    start_long_col = first_row, c

                elif col_height:
                    # The vector is long or short:
                    if col_height == long_col_height:
                        long_col_width += 1

                    else:
                        if short_col_height:
                            short_col_width += 1

                        else:
                            # Initialize second group:
                            short_col_width = 1
                            short_col_height = col_height
                            start_short_col = first_row, c

            row_cells = long_row_width * long_row_height
            col_cells = long_col_height * long_col_width
            v = 0

            if row_cells >= col_cells:
                u = long_row_height, long_row_width
                d = CG.grid[start_long_row[0]][start_long_row[1]]

                # Process second group if it was initialized:
                if short_row_width > 0:
                    v = short_row_height, short_row_width
                    d1 = CG.grid[
                        start_short_row[0]][start_short_row[1]]

            else:
                u = long_col_height, long_col_width
                d = CG.grid[start_long_col[0]][start_long_col[1]]

                # Process second group if it was initialized:
                if short_col_height > 0:
                    v = short_col_height, short_col_width
                    d1 = CG.grid[
                        start_short_col[0]][start_short_col[1]]

            CG.set_group(d, u)

            # Set the second group if it there was one:
            if v:
                CG.set_group(d1, v)

    @staticmethod
    def get_d(r, c):
        """ Returns the dictionary for the cell at r, c. """
        return CG.grid[r][c]

    @staticmethod
    def get_start_end_of_top(d):
        """
        Return the row and column for the current
        cell and its bottom-right cell.

        d: cell dict
        """
        s = d[R], d[C]
        t = s[0] + d[V][0] - 1, s[1] + d[V][1] - 1
        return s, t

    @staticmethod
    def get_topleft(d=None, u=None):
        """
        Top-left is the cell located at the top-left of a group.

        Sub-top-left cells refer to the top-left
        cell through a "topleft" key.

        d: cell dict
        u: (r, c)
        """
        if u:
            d = CG.grid[u[0]][u[1]]

        if d[V][0] < 0:
            v = d['topleft']

        else:
            v = d[R], d[C]
        return CG.grid[v[0]][v[1]]

    @staticmethod
    def is_group(d):
        """
        Returns true if a cell is part of a group.

        d: cell dict
        """
        return CG.is_topleft(d) or d[V] == (-1, -1)

    @staticmethod
    def is_outside(d, r, c, s):
        """
        Returns true if the cell has cells that
        exist outside the bounds of a rectangle.

        d: cell dict
        r, c, s: bounds
        """
        if d[R] < r or d[C] < c or d[R] \
                + d[V][0] > r + s[0] or d[C] \
                + d[V][1] > c + s[1]:
            return 1

    @staticmethod
    def is_topleft(d):
        """
        Returns true if the cell is a top-left cell.

        d: cell dict
        """
        return d[V][0] > 1 or d[V][1] > 1

    @staticmethod
    def is_vector(u, r, c):
        """
        Returns true if the cell (r, c) is still
        referencing a top-left cell at "u".

        u:  (r, c)
        """
        d = CG.grid[r][c]

        # Independent cells are not part of a vector:
        if CG.is_group(d):
            a = CG.get_topleft(d)

            # Cell must refer to its old top:
            if a[R] == u[0] and a[C] == u[1]:
                return 1

    @staticmethod
    def merge_groups(top, origin):
        """
        Merge two groups into a new group.

        top: top-left cell
        origin: top-left cell
        """
        # Get bottom-rights:
        o_b_r = CG.calc_bottom_right(origin)
        t_b_r = CG.calc_bottom_right(top)

        # Merge group settings:
        m_pos = min(top[R], origin[R]), min(top[C], origin[C])
        m_b_r = tuple(max(o, m) for o, m in zip(o_b_r, t_b_r))
        diff = tuple(n - m for n, m in zip(m_b_r, m_pos))
        v = diff[0] + 1, diff[1] + 1

        # Get top-left cell of the merged group:
        m = CG.get_d(m_pos[0], m_pos[1])

        """
        Create a dictionary of potential slices.

        Slices are groups that are part of a merged group rectangle,
        but are exclusive of top and origin groups.

        Slices also have cells outside the bounds of the merged group.
        """
        slice = {}

        for r in range(m_pos[0], m_pos[0] + v[0]):
            for c in range(m_pos[1], m_pos[1] + v[1]):
                d = CG.grid[r][c]
                if CG.is_group(d):
                    t = CG.get_topleft(d)
                    if t[R] != top[R] or t[C] != top[C]:
                        if t[R] != origin[R] or t[C] != origin[C]:
                            if CG.is_outside(t, m[R], m[C], v):
                                key = t[R], t[C]
                                if KEY not in slice:
                                    slice[key] = dict(v=t[V])

        CG.set_group(m, v)
        CG.generate_group(slice)

    @staticmethod
    def set_block_looks(start, end):
        """
        Sets the appearance of a block of cells.

        start: (r, c) for the top-left cell
        end: (r, c) for the bottom-right cell
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                CG.set_cell_looks(CG.get_d(r, c), start, end)

    @staticmethod
    def set_cell_looks(d, start, end):
        """
        Sets a cell's appearance.

        d: cell dict
        start: (r, c) for the top-left cell
        end: (r, c) for the bottom-right cell
        """
        if d[V] == (1, 1):
            CG.set_single_looks(d)

        else:
            # The cell is a member of a group:
            not_start_r = d[R] != start[0]
            not_start_c = d[C] != start[1]
            k = 'left_b'
            k1 = 'top_b'

            # cell neighbor flags:
            top = d[R] > start[0]
            bottom = d[R] < end[0]
            left = d[C] > start[1]
            right = d[C] < end[1]

            # TBLR:
            w = PAD5[:]

            for x, i in enumerate((top, bottom, left, right)):
                if i:
                    w[x] = 0

            d[PAD].set_padding(*w)
            CG.set_group_looks(d)
            if not CG.overlay:
                # button updates:
                if k in d:
                    if left:
                        w = [5, 5, 0, 0]
                        for x, i in enumerate((top, bottom)):
                            if i:
                                w[x] = 0
                        d[k].pad.g.set_padding(*w)
                        d[k].set_label("-")
                        d[k].switch = 1

                    else:
                        d[k].set_label("+")
                        d[k].switch = 0
                        d[k].pad.g.set_padding(5, 5, 0, 0)

                if k1 in d:
                    if top:
                        w = [0, 0, 5, 5]
                        for x, i in enumerate((left, right)):
                            if i:
                                w[x + 2] = 0

                        d[k1].pad.g.set_padding(*w)
                        d[k1].set_label("-")
                        d[k1].switch = 1

                    else:
                        d[k1].set_label("+")
                        d[k1].switch = 0
                        d[k1].pad.g.set_padding(0, 0, 5, 5)
        CG.update_cell_label(d)

    @staticmethod
    def set_group(top, s):
        """
        Sets a group's sub-cell's attributes and the group's appearance.

        top: a new group dict
        s: group's new dimensions
        """
        top[V] = s
        start, end = CG.get_start_end_of_top(top)

        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                if r != top[R] or c != top[C]:
                    CG.set_subtop(top, CG.grid[r][c])
        CG.update_block(start, end)

    @staticmethod
    def set_group_looks(d):
        """
        Changes the appearance of a cell's frame to appear merged.

        d: cell dict
        """
        d['event_box'].modify_bg(ABLE, BG_GROUP)

    @staticmethod
    def set_single_looks(d):
        """
        Changes the appearance of a cell's frame to appear independent.

        d: cell dict
        """
        d[PAD].set_padding(*(5,) * 4)
        d['event_box'].modify_bg(ABLE, BG_CELL)

    @staticmethod
    def set_subtop(d, e):
        """
        Used when a cell is merged into a group.

        Modifies the cell's dictionary to identify the cell as sub-top.

        d: the top-left cell's dict
        e: the sub-top cell's dict
        """
        e['topleft'] = d[R], d[C]
        e[V] = -1, -1

    @staticmethod
    def split_horz(d):
        """
        The user has clicked a horizontal black connector.

        This routine divides the group containing
        this connector of two columns.

        d: cell dict
        """
        c = d[C]
        top = CG.get_topleft(d=d)
        w = c - top[C]
        w1 = top[V][1] - w
        e = CG.get_d(top[R], top[C] + w)
        CG.set_group(e, (top[V][0], w1))
        CG.set_group(top, (top[V][0], w))

    @staticmethod
    def split_vert(d):
        """
        The user has clicked a vertical black connector.

        This routine divides the group
        containing this connector of two rows.

        d: cell dict
        """
        r = d[R]
        top = CG.get_topleft(d=d)
        h = r - top[R]
        h1 = top[V][0] - h
        e = CG.get_d(top[R] + h, top[C])

        # Create a new groups from the split:
        CG.set_group(e, (h1, top[V][1]))
        CG.set_group(top, (h, top[V][1]))

    @staticmethod
    def update_block(start, end):
        """
        Updates format data, cell size table,
        and the cell appearance for a block of cells.

        start: the top-left cell in the block
        end: the bottom-right cell in the block
        """
        CG.update_format(start, end)
        CG.sizer.calc_block(start, end, CG.format_c.format)
        CG.set_block_looks(start, end)

    @staticmethod
    def update_cell_label(d):
        """
        Called whenever a cell is drawn.

        Updates the cell dimension labels.

        d: cell dict
        """
        if not CG.overlay:
            a = UICell

            if CG.is_topleft(d) or d[V] == (1, 1):
                b = CG.sizer.get_cell_info(d[R], d[C])

                if LAB_W in d:
                    for x, k in enumerate(LAB_K):
                        d[k].lab.set_text(LAB_I[x] + str(b[x]))

                else:
                    for x, k in enumerate(LAB_K):
                        g = d[k] = RLabel(LAB_I[x] + str(b[x]))

                        d['box'].add(d[k].g)

                        # Need to show both:
                        g.g.show()
                        g.lab.show()

            else:
                if LAB_W in d:
                    # Delete the Labels:
                    for k in LAB_K:
                        b = d[k]

                        d['box'].remove(b.g)
                        d.pop(k)
                        b.destroy()

    @staticmethod
    def update_format(start, end):
        """
        Updates the format data for a block of cells.

        start: the top-left cell in the block
        end: the bottom-right cell in the block.
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                CG.format_c.format[ME_CELL][r][c] = CG.grid[r][c][V]


class Preset:
    """
    Presets are used to store session and format values.

    External presets are created by the user and given a name.
    """
    # indices:
    ext = 1      # external preset type
    src_x = 0    # external or internal source index
    name_x = 1   # Name of the Preset index
    file_x = 2   # External data: file name index
    data_x = 2   # Internal preset data index

    def __init__(self, d):
        """ d: dict """
        self.default_preset = deepcopy(d[DEF])
        self.internal_presets = d['internal']
        self.parent = d[PARENT]
        self.pattern = d['pattern']
        self.version = d[VERSION]

    def get_preset(self, n, presets):
        """
        Returns a preset from internal and external sources.

        n: name of preset
        presets: preset list
        """
        d = deepcopy(self.default_preset)

        for q in presets:
            if n == q[Preset.name_x]:
                if q[Preset.src_x] == Preset.ext:
                    e = pickle_load({'file': q[Preset.file_x]})

                    if e:
                        d = e
                    break

                else:
                    # Load internal data:
                    d = q[Preset.data_x]
                break
        return d


class PRForm(Preset):
    """
    This is the Preset used in the Form group.

    Its Preset is the Session data.
    """
    pattern = u"Form_*.pkl"

    def __init__(self, d):
        """ d: dict """
        e = d[DEF] = deepcopy(Session.default)
        d['internal'] = [[INT_X, DEF, e]]
        d['pattern'] = PRForm.pattern
        d[VERSION] = Session.version
        Preset.__init__(self, d)


class PRFormat(Preset):
    """
    This is the Preset used in the Format window.

    Stores values from the UIFormat window and from its Per Cell windows.
    """
    def __init__(self, d):
        """ d: dict """
        q = d[DEF] = [INT_X, DEF, deepcopy(Format.default)]
        d['internal'] = [q]
        d['pattern'] = u"Format5_*.pkl"
        d[VERSION] = Format.version
        Preset.__init__(self, d)


class Images:
    """ Used to manage the open images. """
    # number of valid images:
    image_count = 0

    # next image index:
    next_x = 0

    # open images:
    images = []

    # valid image names:
    image_names = []
    format_img_list = []
    relative_names = []

    @staticmethod
    def get_img():
        """ Collect related data for images. """
        # post-fix image number tuple:
        q = pdb.gimp_image_list()[1][::-1]

        # gimp.Image list:
        q1 = reversed(gimp.image_list())

        for x, j in enumerate(q1):
            n = j.name + "-" + str(q[x])
            Images.images.append(Img(j, n))

        q = Images.image_names = Images.make_image_name_list()
        Images.image_count = len(q)

        for i in range(len(q)):
            go = 1
            while go:
                go = q.count(q[i]) - 1
                if go:
                    x = q.index(q[i])
                    q[x] = Images.images[x].n = q[x] + " (" + str(go) + ")"

        # Make list for format:
        q = Images.format_img_list = Images.image_names[:]
        b = Images.relative_names

        for i in range(len(q)):
            n = str(i + 1)
            a1 = i + 1

            if i == 0 or (a1 > 20 and a1 % 10 == 1):
                c = n + "st"

            elif i == 1 or (a1 > 20 and a1 % 10 == 2):
                c = n + "nd"

            elif i == 2 or (a1 > 20 and a1 % 10 == 3):
                c = n + "rd"

            else:
                c = n + "th"
            b.append(c + " Image")
        q += b

        q.insert(0, NXT)
        q.insert(1, NON)

    @staticmethod
    def get_next():
        """ Returns the next Img or none. """
        j = None
        a = Images

        if a.next_x < a.image_count:
            j = a.images[a.next_x]
            a.next_x += 1
        return j

    @staticmethod
    def make_image_name_list():
        """ Returns a list of valid image names. """
        return [i.n for i in Images.images]


class Img:
    """ Used to manage an open image. """

    def __init__(self, j, n):
        """ j: image """
        Sel.none(j)
        self.j = j
        self.n = n
        self.size = j.width, j.height

    @staticmethod
    def bury(j):
        """
        Deletes an image that doesn't have a display.

        j: GIMP image
        """
        pdb.gimp_image_delete(j)

    @staticmethod
    def calc_lock(s, t):
        """
        Returns the size of an image that will fit into a smaller cell.

        s: cell size
        t: image size
        """
        w_r = float(t[0]) / s[0]
        h_r = float(t[1]) / s[1]

        if w_r > h_r:
            w, h = s[0], int(t[1] * (s[0] / float(t[0])))

        else:
            w, h = int(t[0] * (s[1] / float(t[1]))), s[1]

        # underflow:
        return w + int(int(w) == 0), h + int(int(h) == 0)

    @staticmethod
    def get_image(n):
        """
        Returns an Img object.

        n: name of image
        """
        a = Images

        if n == NXT:
            j = a.get_next()

        elif n in a.image_names:
            x = a.image_names.index(n)
            j = a.images[x]

        else:
            x = a.relative_names.index(n)
            j = a.images[x]
        return j

    @staticmethod
    def get_trim_size(s, t):
        """
        Returns the size of the trim.

        s: image size
        t: cell size
        """
        w_r = t[0] / 1. / s[0]
        h_r = t[1] / 1. / s[1]

        if s[0] < t[0] and s[1] < t[1]:
            # No trim needed:
            w, h = s

        else:
            if w_r < h_r:
                # The image height is closer to the cell size:
                w, h = int(s[0] * h_r), t[1]

            else:
                # The image width is closer to the cell size:
                w, h = t[0], int(s[1] * w_r)

        # underflow:
        return [w + int(int(w) == 0), h + int(int(h) == 0)]

    @staticmethod
    def mold(j, d, cell):
        """
        Molds an image to fit a cell.

        d: format dict
        cell: Cell
        """
        j1 = L[RENDER]

        Sel.none(j1)

        s = j.cell_size = cell.get_cell_size(j.r, j.c)

        # Resize index for fill, locked, none, trim:
        x = RSZ.index(Layout.get_resize_type(j.r, j.c, d))

        (Img.mold_fill, Img.mold_lock, Img.mold_none, Img.mold_trim)[x](j, d)

        if j.rot:
            j2 = Img.paste()
            z = Lay.rotate(j2, j.rot)
            t = w, h = z.width, z.height

            kopy(j2)
            Img.bury(j2)

            if w > s[0] or h > s[1]:
                t = w, h = Img.calc_lock(s, t)
                j3 = Img.paste()
                Img.resize(j3, w, h)
                kopy(j3)
                Img.bury(j3)
            j.new_size = t
        cell.calc_rect_pos(d, j)

    @staticmethod
    def mold_fill(j, d):
        """
        Resizes a fill image resize-type.

        Returns with the image data in the buffer.

        d: format dict
        """
        if j.size != j.cell_size:
            kopy(j.j)
            j1 = Img.paste()
            j.new_size = w, h = j.cell_size
            Img.resize(j1, w, h)
            kopy(j1)
            Img.bury(j1)

        else:
            j.new_size = j.size
            kopy(j.j)

    @staticmethod
    def mold_lock(j, d):
        """
        Resizes a locked image resize-type.

        Returns with the image data in the buffer.

        d: format dict
        """
        kopy(j.j)
        if j.size[0] > j.cell_size[0] or j.size[1] > j.cell_size[1]:
            # down-size:
            w, h = Img.calc_lock(j.cell_size, j.size)
            j1 = Img.paste()

            Img.resize(j1, w, h)
            kopy(j1)
            Img.bury(j1)

        else:
            w, h = j.size
        j.new_size = w, h

    @staticmethod
    def mold_none(j, d):
        """
        Resizes an None image resize-type.

        Returns with the image data in the buffer.

        d: format dict
        """
        if j.size[0] > j.cell_size[0] or j.size[1] > j.cell_size[1]:
            # Copy a rectangle:
            j.new_size = Layout.sel_img_trim(d, j, j.j)

        else:
            j.new_size = j.size
            kopy(j.j)

    @staticmethod
    def mold_rect(j, d, cell):
        """
        Draws an image rectangle for preview
        that corresponds with the format.

        d: format dict
        cell: Cell
        """
        s = j.size
        t = j.cell_size = cell.get_cell_size(j.r, j.c)

        typ = Layout.get_resize_type(j.r, j.c, d)

        # [FIL, LCK, NON, TRM]
        if typ == FIL:
            s1 = t

        elif typ == LCK:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = Img.calc_lock(t, s)

            else:
                s1 = s

        elif typ == NON:
            s1 = list(s)

            if s[0] > t[0]:
                s1[0] = t[0]
            if s[1] > t[1]:
                s1[1] = t[1]

        else:
            if s[0] > t[0] or s[1] > t[1]:
                s1 = Img.get_trim_size(s, t)
                if s1[1] > t[1]:
                    s1[1] = t[1]

                else:
                    s1[0] = t[0]

            else:
                s1 = s

        D[N] = j.n
        D[W], D[H] = j.new_size = s1

        cell.calc_rect_pos(d, j)

        D[X], D[Y] = j.x, j.y
        Sel.rect(L[RENDER])

    @staticmethod
    def mold_trim(j, d):
        """
        Resizes a None image resize-type.

        Returns with the image data in the buffer.

        d: format dict
        """
        s = s1 = j.size
        t = j.cell_size

        kopy(j.j)

        if s[0] > t[0] or s[1] > t[1]:
            w, h = Img.get_trim_size(s, t)
            j1 = Img.paste()
            Img.resize(j1, w, h)

            s1 = Layout.sel_img_trim(d, j, j1)

            # Copy selection:
            kopy(j1)
            Img.bury(j1)
        j.new_size = s1

    @staticmethod
    def new(w, h):
        """
        Creates a new image based on the global scales.

        w, h: size of the new image

        Returns the new image.
        """
        return pdb.gimp_image_new(w, h, fu.RGB)

    @staticmethod
    def paste():
        """
        Pastes the buffer as a new image.

        Returns the new image.
        """
        return pdb.gimp_edit_paste_as_new_image()

    @staticmethod
    def resize(j, w, h):
        """
        Resizes a layer.

        z: image with one layer
        w: width
        h: height
        """
        pdb.gimp_item_transform_scale(j.layers[0], 0, 0, w, h)
        pdb.gimp_image_resize_to_layers(j)


class Format:
    """ Manages UIFormat session data. """
    version = 1

    # Read only:
    default = {
        NAME: "Format",
        EFFECT: NON,
        RESIZE: LCK,
        HORZ: CE,
        VERT: MID,
        IMAGE: NXT,
        ROT: 0,
        OP: 100,
        FLIP_H: 0,
        FLIP_V: 0,
        MERG_PER: 1,
        PROP_PER: 0,
        PLACE_PER: 0,
        CM_PER: 0,
        ROW: 1,
        COL: 1,
        LM_TOP: 0,
        LM_LEF: 0,
        LM_RIG: 0,
        LM_BOT: 0,
        CM_TOP: 0,
        CM_LEF: 0,
        CM_RIG: 0,
        CM_BOT: 0,
        PRESET: DEF,
        ME_CELL: None,
        PL_CELL: None,
        CM_CELL: None,
        PR_CELL: None,
        VERSION: version}

    def __init__(self, format):
        self.format = deepcopy(format)


class Session:
    """ Stores session control values. """
    # file version:
    version = 1

    # Read only:
    default = {
        VERSION: version,
        FORMAT: [],
        PRESET: DEF,
        PREVIEW_OPT: {
            LAY_MARG: 0,
            CELL_MARG: 0,
            COORD: 0,
            DIM: 0,
            CORN: 0,
            GRID: 0,
            N: 0,
            RAT: 0},

        BD_STYLE: TR,
        BD_IMAGE: FIRST,
        WI: 1920,
        HG: 1080,
        WINDOW: {}}

    @staticmethod
    def load(d):
        """
        Loads a Session file.
        Checks to see if its valid.

        d: dict

        Returns the Session data or (0 or -1) for failure.
        """
        e = pickle_load(d)
        if e:
            if e[VERSION] == Session.version:
                a = check_session(e)
                if a:
                    e = 0
                    n = CORRUPT + "\nError number: " + str(a)
                    show_err(n)

            else:
                e = 0
        return e


class UI:
    """
    Creates windows.

    Holds common user-interface functions.
    """
    loading = 0

    def __init__(self, d):
        """ d: dict """
        self.title = d[TITLE]
        self.accept = d[ACCEPT]
        self.color = MAX_COL

        # "self.poser" is the window name key in the WINDOW dict:
        self.pose = d[POSE]

        if not UIMain.win:
            is_dialog = 0
            g = self.win = UIMain.win = gtk.Window()
            g.set_title(d[TITLE])
            w, h = UI.get_screen_res()
            Session.default[WI] = w
            Session.default[HG] = h
            if SESS in D:
                if D[SESS][PRESET] == DEF:
                    D[SESS][WI] = w
                    D[SESS][HG] = h

        else:
            self.reply = 0
            is_dialog = 1
            g = self.win = gtk.Dialog(
                d[TITLE],
                UIMain.win,
                gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
                None)

        UI.loading += 1

        d[DRAW]()

        UI.loading -= 1

        g.set_position(gtk.WIN_POS_CENTER)
        g.show_all()

        if self.pose in D[SESS][WINDOW]:
            # Make sure the position isn't off screen:
            w, h = UI.get_screen_res()
            w1, h1 = self.win.allocation.width, self.win.allocation.height
            x, y = D[SESS][WINDOW][self.pose]
            x = seal(x, 0, w - w1)
            y = seal(y, 0, h - h1)
            g.move(x, y)

        else:
            g.set_position(gtk.WIN_POS_CENTER)

        g.connect('delete_event', self.close)
        g.connect('key_press_event', self.on_key_press)
        if is_dialog:
            self.win.run()
            self.win.destroy()

    def close(self, *a):
        """
        Closes the window.
        Exits the main loop.

        a: unused

        Returns true to let GTK know that the closing operation is handled.
        """
        g = self.win
        D[SESS][WINDOW][self.pose] = g.get_position()

        if g == UIMain.win:
            g.destroy()
            gtk.main_quit()

        else:
            self.win.response(0)
        return 1

    def do_return(self):
        """ Call by "on_key_press" when the user hits the return key. """
        return self.accept()

    def get_preset_name(self, n, pr):
        """
        Replaces an asterisk with a preset name.

        Preset file names are formed from a constant string containing an
        asterisk, and an additional part, a user-defined Preset name.

        n: preset pattern string
        pr: preset name
        """
        return n.replace(u"*", pr)

    @staticmethod
    def get_screen_res():
        """ Returns the (width, height) of the screen's dimension. """
        return gtk.gdk.screen_width(), gtk.gdk.screen_height()

    def load_controls(self, d):
        """
        Loads the controls from a preset.

        d: preset
        """
        return self.update_controls(d)

    def on_key_press(self, g, a):
        """
        Checks to see if the user pressed the Esc key.
        If so, then close the window.

        g: window
        a: key-press event
        """
        n = gtk.gdk.keyval_name(a.keyval)
        if n == 'Escape':
            return self.close()

        elif n == 'Return':
            g = self.win.get_focus()
            if type(g) in (RETURN_WIDGETS):
                return self.do_return()

    def preset_is_undefined(self):
        """ Sets the preset ComboBox display to undefined. """
        if not UI.loading:
            self.preset_m.set_text(UND)

    def subtract_from_color(self):
        """ Subtracts from from the window's red and green color channels. """
        self.color -= 2200

    def update_controls(self, d):
        """
        Loads a window's controls.

        d: dict that stores control values

        Returns the dict.
        """
        UI.loading += 1

        for g in self.controls:
            g.set_val(d[g.key])

        UI.loading -= 1
        return d

    def verify_opacity_depend(self, g, cb=None):
        """
        Validates property group widgets based on the opacity value.

        g: opacity Entry
        cb: Per Cell Checkbutton
        """
        q = g.rot, g.flip_h, g.flip_v

        if not cb:
            do = 1

        else:
            do = not cb.get_val()
        if do:
            if g.get_val():
                for i in q:
                    i.enable()

            else:
                for i in q:
                    i.disable()

    def verify_place_menus(self, g):
        """
        Resize/Fill Cell and Image/None options cause
        some of the other menu options to be invalid.

        g: Placement ComboBox
        """
        if g.resz.get_val() == FIL or g.img.get_val() == NON:
            g.vert.disable()
            g.horz.disable()

        else:
            g.vert.enable()
            g.horz.enable()

        if g.img.get_val() == NON:
            g.resz.disable()

        else:
            g.resz.enable()


class UISwitch(UI):
    """ Switches window focus for dialog interaction. """

    def __init__(self, d):
        g = d['parent']

        g.hide()
        UI.__init__(self, d)
        g.show()


class UICell(UI):
    """ Draws the Per Cell windows. """

    # GTK will sometimes draw scroll-bars after size changes:
    xtra = 4

    def __init__(self, d):
        """ d: dict """
        x = CG.overlay = self.win_x = d['win_x']
        self.merged = d['merge_pc']
        self.format_c = d['format_c']
        d[ACCEPT] = self.do_job
        d[DRAW] = self.draw_win
        d[POSE] = ('cell_merge',  'cell_place', 'cell_margin', 'cell_prop')[x]
        d[TITLE] = (
            "Merge Cells",
            "Image Placement",
            CELL_MARG,
            "Image Properties")[x] + EXIT

        self.init_merge_cells(d)

        # cell window format copy:
        CG.format_c = Format(self.format_c.format)
        CG.sizer = Cell(CG.format_c.format)
        UI.__init__(self, d)

    def do_job(self):
        """ Called because the user pressed the Enter key. """
        self.format_c.format = CG.format_c.format
        return self.close()

    def draw_cell(self, g, d):
        """
        Called by UICell for each cell.

        Initializes the cell's dictionary.

        Draws connectors and cell sizes.

        g: container
        d: dict
        """
        a = UICell
        e = CG.grid[d[R]][d[C]]

        CG.draw(e)
        if self.win_x:
            if e[V] != (-1, -1):
                (
                    self.draw_place_cell,
                    self.draw_margin_cell,
                    self.draw_prop_cell)[self.win_x - 1](d)

    def draw_margin_cell(self, d):
        """
        Called by UICell for each cell.

        Draws margin Labels and SpinButtons.

        d: dict
        """
        # needs index
        if self.isnt_no_pic(d):
            e = self.format_c.format[CM_CELL][d[R]][d[C]]
            g = CG.grid[d[R]][d[C]]['box']
            for x, n in enumerate(MARGINS):
                g1 = Splitter()
                w = D[HG] - 1 if x < 2 else D[WI] - 1
                g2 = RSpinButton(
                    self.on_widget_change, (0, w), k=CELL_SB_K[x])

                g2.cell_key = CM_CELL
                g2.r, g2.c = d[R], d[C]
                g2.index = x

                g1.both(RLabel(n + ":").g, g2.g)
                g2.set_val(e[x] / 1.)
                g1.pack()
                g.add(g1.g)

    def draw_place_cell(self, d):
        """
        Called by UICell for each cell.

        Draws the ComboBoxes for Image Placement.

        d: dict
        """
        if self.isnt_no_pic(d):
            p = self.on_widget_change
            g = [0] * 4

            for x in range(4):
                a = (RSZ, Images.format_img_list, HRZ, VRT)[x]
                g1 = g[x] = RComboBox(p, opt=a)
                g1.index = x
                g1.cell_key = PL_CELL
                g1.r, g1.c = d[R], d[C]
                CG.grid[d[R]][d[C]]['box'].add(g1.g)

            e = self.format_c.format[PL_CELL][d[R]][d[C]]

            for x in range(4):
                g[x].resz, g[x].img, g[x].horz, g[x].vert = g[0], g[1], g[2], g[3]
                g[x].set_val(e[x])
            if g1.resz.get_val() == FIL or g1.img.get_val() == NON:
                self.verify_place_menus(g[0])

    def draw_prop_cell(self, d):
        """
        Called by UICell for each cell.

        Draws the widgets for the Property cell.

        d: dictionary
        """
        if self.isnt_no_pic(d):
            g = CG.grid[d[R]][d[C]]['box']
            p = self.on_widget_change
            q = zip(
                (RCheckButton, RCheckButton, RSpinButton, RSpinButton),
                ((p, FH), (p, FV), (p, (0, 359)), (p, (0, 100))),
                (FLIP_H_X, FLIP_V_X, ROTATE_X, OP_X))

            g4 = []
            for x, q1 in enumerate(q):
                g1, c, x1 = q1
                g2 = g1(*c)
                g2.index = x1
                g2.r, g2.c = d[R], d[C]
                g2.cell_key = PR_CELL

                # opacity dependents:
                if x != 3:
                    g4.append(g2)

                else:
                    g2.flip_h, g2.flip_v, g2.rot = g4

                if x < 2:
                    # CheckButton:
                    g.add(g2.g)

                else:
                    g3 = Splitter()
                    g3.both(RLabel(("Rotate:", "Opacity:")[x - 2]).g, g2.g)
                    g3.pack()
                    g.add(g3.g)

            g4.append(g2)

            e = self.format_c.format[PR_CELL][d[R]][d[C]]

            for i in range(4):
                g4[i].set_val(e[i])
            if not e[i]:
                self.verify_opacity_depend(g2)

    def draw_win(self):
        """
        Draws the background framework used by the three Per Cell windows.

        Calls the Per Cell window owner to draw
        its overlay on top of the background.
        """
        # Cell content is the top Frame:
        d = self.format_c.format
        row, col = d[ROW] * 2, d[COL] * 2
        vbox = self.win.vbox
        table = gtk.Table(row, col)
        scroll = gtk.ScrolledWindow()
        is_1st_cell = 1

        scroll.add_with_viewport(table)
        vbox.add(scroll)
        scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        self.buttons = create_2d_table(d[ROW], d[COL])
        for r in range(row):
            for c in range(col):
                r1, c1 = r / 2 + 1, c / 2 + 1
                r2, c2 = r / 2 - 1, c / 2 - 1

                if r == 0:
                    if not self.win_x or (self.win_x and c % 2):
                        # column header:
                        g = REventBox(BG_HEAD)
                        g1 = gtk.Frame()

                        if c % 2:
                            g2 = col_label = RLabel(str(c1), align=ALL_X).g
                            g1.add(g2)

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif c == 0:
                    if not self.win_x or (self.win_x and r % 2):
                        # row header:
                        g = REventBox(BG_HEAD)
                        g1 = gtk.Frame()

                        if r % 2:
                            g2 = row_label = RLabel(
                                str(r1), pad=(0, 0, 4, 4), align=ALL_Y).g
                            g1.add(g2)

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif (r % 2 and c % 2):
                    # Create cell:
                    r3, c3 = d[R], d[C] = r / 2, c / 2
                    e = CG.grid[r3][c3]

                    # Add buttons to the cell's dictionary:
                    if r > 1:
                        e['top_b'] = self.buttons[r2][c3]

                    if c > 1:
                        e['left_b'] = self.buttons[r3][c2]

                    g = RBox(0, align=(0, 0, 1, 1))
                    e[PAD] = g.g
                    g1 = e['event_box'] = REventBox(None)
                    g2 = RBox(0, pad=PAD5)
                    g3 = CG.grid[r3][c3]['box'] = g2.box

                    g.add(g1)
                    g1.add(g2.g)
                    table.attach(g.g, c, c + 1, r, r + 1)
                    self.draw_cell(g3, d)

                    if is_1st_cell:
                        """
                        "show_all" causes the "vbox" allocation to be
                        calculated which will fail ScrolledWindow's dependency.
                        So calculating scroll region-size manually.
                        """
                        self.win.show_all()

                        is_1st_cell = 0
                        w = max(g3.allocation.width, g3.allocation.height)
                        w1, h = w * d[COL], w * d[ROW]
                        w2 = row_label.allocation.width
                        h1 = col_label.allocation.height
                        button_w = 0 if self.win_x else 15 * (d[COL] - 1)
                        button_h = 0 if self.win_x else 15 * (d[ROW] - 1)
                        pad_w = 20 * d[COL]
                        pad_h = 20 * d[ROW]
                        xtra_w, xtra_h = row, col

                        # totaling:
                        w1 += w2 + pad_w + button_w + xtra_w + SCROLL + UICell.xtra
                        h += h1 + pad_h + button_h + xtra_h + SCROLL + UICell.xtra
                        w3, h2 = self.get_remaining_dim()
                        w1, h = min(w3, w1), min(h2, h)
                        self.win.vbox.set_size_request(w1, h)
                    g3.set_size_request(w, w)

                elif not (not r % 2 and not c % 2):
                    if not self.win_x:
                        # connector button:
                        if r % 2:
                            # left button:
                            p = CG.split_horz, CG.connect_left
                            r3, c3 = r, c + 1
                            r4, c4 = r / 2, c / 2 - 1
                            q = (5, 5, 0, 0)

                        else:
                            # upper button:
                            p = CG.split_vert, CG.connect_up
                            r3, c3 = r + 1, c
                            r4, c4 = r / 2 - 1, c / 2
                            q = (0, 0, 5, 5)

                        g = RBox(1, align=(0, 0, 1, 1), pad=q)
                        g1 = self.buttons[r4][c4] = SwitchButton(
                            "+", p, r3, c3, g)

                        g1.set_size(15, 15)
                        g1.set_color(BG_BUTTON)
                        g.add(g1)
                        table.attach(g.g, c, c + 1, r, r + 1)

                else:
                    if not self.win_x:
                        # nothing reactive:
                        g = REventBox(BG_BUTTON)
                        g1 = HBox()
                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

    def get_remaining_dim(self):
        """
        Used to keep the dynamically sized Per
        Cell windows from drawing off screen.

        Returns the width and height of the screen space
        to the right and bottom of the window.
        """
        w, h = UI.get_screen_res()

        if self.pose in D[SESS][WINDOW]:
            x, y = D[SESS][WINDOW][self.pose]

        else:
            x = w / 2
            y = h / 2

        x = seal(x, x + SCROLL, w - 200)
        y = seal(y, y + SCROLL, h - 200)
        return w - x, h - y

    def init_merge_cells(self, d):
        """
        Sets the first phase of the initial data needed to draw cells.

        d: unused
        """
        d = self.format_c.format
        row, col = d[ROW], d[COL]
        CG.grid = create_2d_table(row, col)

        # Load cell dimensions:
        for r in range(row):
            for c in range(col):
                if self.merged:
                    s = d[ME_CELL][r][c]

                else:
                    s = 1, 1
                CG.grid[r][c] = dict(v=s, r=r, c=c)

        # Initialize top-left references:
        for r in range(row):
            for c in range(col):
                e = CG.grid[r][c]
                if CG.is_topleft(e):
                    t = e

                    # Initialize sub-topleft cells:
                    for r1 in range(r, r + t[V][0]):
                        for c1 in range(c, c + t[V][1]):
                            if r1 != r or c1 != c:
                                e = CG.grid[r1][c1]
                                e['topleft'] = t[R], t[C]

    def isnt_no_pic(self, d):
        """
        Returns a flag which is true when the image placement is not an image.

        d: dict
        """
        e = CG.format_c.format
        m = 1

        if self.win_x != PL_X:
            if not e[PL_CELL]:
                m = e[IMAGE] != NON

            else:
                m = e[PL_CELL][d[R]][d[C]][IMAGE_X] != NON

        # zero opacity:
        if m:
            if self.win_x != PR_X:
                if not e[PR_CELL]:
                    m = e[OP] != 0

                else:
                    m = e[PR_CELL][d[R]][d[C]][OP_X] != 0

        if not m:
            n = NP + "............" if not d[R] and not d[C] else NP
            CG.grid[d[R]][d[C]]['box'].add(RLabel(n).g)
        return m

    def on_widget_change(self, g):
        """
        Called when a widget changed display value.

        g: widget
        """
        if not self.loading:
            x = g.index
            k = g.cell_key
            q = list(CG.format_c.format[k][g.r][g.c])
            q[x] = g.get_val()
            CG.format_c.format[k][g.r][g.c] = tuple(q)

            if k == PL_CELL:
                if x in (RESIZE_X, IMAGE_X):
                    self.verify_place_menus(g)

            elif k == PR_CELL:
                if x == OP_X:
                    self.verify_opacity_depend(g)


class UISave(UI):
    """ This window gets a preset name then saves the preset. """
    preset_name = "New Preset"

    def __init__(self, d):
        """ d: dict """
        self.get_data = d['get_data']
        self.preset = d['preset']
        d[ACCEPT] = self.save
        d[TITLE] = "Name the " + d[TITLE] + " Preset"
        d[DRAW] = self.draw_win
        UI.__init__(self, d)

    def draw_file_info_grp(self, g):
        """
        The file info group shows the user the preset file's location.

        g: container
        """
        self.subtract_from_color()

        drive, path = os.path.splitdrive(D[DIR])
        g1 = Splitter(padx=3)
        g2 = REventBox(self.color)
        g3 = VBox()

        self.subtract_from_color()

        g4 = REventBox(self.color)
        g5 = self.file_name_box = VBox()
        g6 = self.filename_label = RLabel("")

        g2.add(g3)
        g4.add(g5)
        g1.both(g2, g4)
        g3.add(RLabel("Drive:").g)
        g3.add(RLabel("Folder:").g)
        g3.add(RLabel("File Name:").g)
        g5.add(RLabel(drive).g)
        g5.add(RLabel(path).g)
        g5.add(g6.g)
        g1.no_pack()
        g.add(g1.g)
        self.draw_file_name(self.file_name_e)

    def draw_file_name(self, g):
        """
        Called whenever the preset name Entry changes.

        Updates the File Location group with the latest file name.

        g: file name Entry
        """
        if self.filename_label:
            n = self.get_preset_name(
                self.preset.pattern,
                g.get_val())
            self.filename_label.lab.set_text(n)

    def draw_process_grp(self, g):
        """
        Draws the Cancel and Save Buttons for the window.

        g: container
        """
        g1 = Splitter(padx=3)
        g2 = RButton("Save", self.save).g

        g1.both(RButton("Cancel", self.close).g, g2)
        g1.pack()
        g.add(g1.g)

    def draw_var_grp(self, g):
        """
        Creates an Entry for naming the preset.

        g: container
        """
        g1 = self.file_name_e = REntry(self.draw_file_name, None, padx=2)

        g.add(RLabel("Preset Name:", TOPL).g)
        g.add(g1.g)
        g1.set_val(UISave.preset_name)
        g1.wig.select_region(0, -1)

    def draw_win(self):
        """ Draws the window's controls. """
        self.subtract_from_color()

        g = self.win.vbox
        self.filename_label = None
        q = (
            self.draw_var_grp,
            self.draw_file_info_grp,
            self.draw_process_grp)

        c = "Variables", "File Location", PE

        for x, p in enumerate(q):
            box = REventBox(self.color)
            g1 = VBox()

            box.add(g1)
            g.add(box)
            g1.add(RLabel(c[x] + ":", (2, 0, 4, 0)).g)
            p(g1)
            self.subtract_from_color()

    def save(self, *a):
        """
        Called because the user activated the Save Button.

        Attempts to write the preset and if successful
        updates the preset menu and closes the window.

        a: unused
        """
        d = deepcopy(self.get_data())
        n = d[PRESET] = self.file_name_e.get_val()
        if self.write(d):
            UISave.preset_name = n
            self.reply = 1
            return self.close()

    def write(self, d):
        """
        Writes the preset, after checking if it already
        exists and asking permission to over-write.

        d: dict that gets saved

        Returns a result flag where true is successful.
        """
        path = os.path.join(
            D[DIR],
            self.get_preset_name(
                self.preset.pattern,
                self.file_name_e.get_val()))

        m = 1
        n = DUPE.format(path)

        if os.path.isfile(path):
            g = gtk.MessageDialog(
                parent=self.win,
                flags=gtk.DIALOG_MODAL,
                type=gtk.MESSAGE_QUESTION,
                buttons=gtk.BUTTONS_YES_NO,
                message_format=n)

            g.set_title("Duplicate File")

            a = g.run()

            g.destroy()
            m = int(a == gtk.RESPONSE_YES)

        if m:
            m = pickle_dump(dict(data=d, file=path))
        return m


class UISaveForm(UISave):
    """ Creates a dialog for naming and saving the session preset. """
    def __init__(self, d):
        """ d: dict """
        d[TITLE] = "Form"
        d[POSE] = 'save_form'
        UISave.__init__(self, d)


class UISaveFormat(UISave):
    """ Creates a dialog for naming and saving the format preset. """
    def __init__(self, d):
        """ d: dict """
        d[TITLE] = "Format"
        d[POSE] = 'save_format'
        UISave.__init__(self, d)


class UIFormat(UISwitch):
    """
    This is a window with format controls and accesses UICell windows.
    """
    MARG_Y = 30

    def __init__(self, d):
        """ d: dict """
        x = self.format_x = d['format_x']
        self.format = deepcopy(D[SESS][FORMAT][x])
        d[ACCEPT] = self.do_job
        d[TITLE] = "Format"
        d[DRAW] = self.draw_win
        d[POSE] = 'format'
        self.feed = d['feed']
        UISwitch.__init__(self, d)

    def adjust_cell_tables(self):
        """
        Cell tables expand or contract depending on the rows and columns.
        """
        self.expand_cell_tables()
        self.contract_cell_tables()

    def contract_cell_tables(self):
        """
        Contracts Per Cell tables to correspond with the Format window.

        Checks Merge Cells table for group dimension overflow.
        """
        row = self.format[ROW]
        col = self.format[COL]

        for k in (CELL_K):
            if self.format[k]:
                r = len(self.format[k])

                if r > row:
                    # Remove rows:
                    for _ in range(r - row):
                        self.format[k].pop()
                for r in range(len(self.format[k])):
                    c = len(self.format[k][r])
                    if c > col:
                        # Remove columns:
                        for _ in range(c - col):
                            self.format[k][r].pop()
        self.fix_merge_cells()

    def correct_merge_overflow(self, s, row, col, r, c):
        """
        Checks if the Merge Cells' table has contracted. If so then
        the top-left cells need their dimensions checked for overflow.

        row, col: max location.
        r, c: current location
        s: group dimension
        """
        if s[0] + r > row:
            s = row - r, s[1]

        if s[1] + c > col:
            s = s[0], col - c
        return s

    def correct_contracted_cells(self):
        """
        When cells contract, their dimensions change.
        This makes the cut-off cells independent.
        """
        if self.format[MERG_PER]:
            r = self.format[ROW]
            r1 = len(self.format[ME_CELL])
            c = self.format[COL]
            for r2 in range(r1):
                for c1 in range(len(self.format[ME_CELL][r2])):
                    if r2 >= r or c1 >= c:
                        self.format[ME_CELL][r2][c1] = 1, 1

    def do_no(self, *a):
        """
        Called when the user cancels the Format window.

        a: unused
        """
        self.feed(None)
        return self.close()

    def do_job(self, *a):
        """
        Called when the user accepts the UIFormat window.

        a: unused
        """
        d = D[SESS]

        for g in self.controls:
            self.format[g.key] = g.get_val()

        self.adjust_cell_tables()
        d[FORMAT][self.format_x] = self.format
        self.feed(self.format_x)
        return self.close()

    def draw_cell_margin_grp(self, g):
        """
        Draws the Cell Margins group.

        g: container
        """
        self.cell_margin_sb = list(self.draw_marg_grp(g, CELL_SB_K))
        g = self.margin_pc_grp = GPerCell(
            self.on_widget_change,
            self.open_cell_win,
            "Cell Margins...",
            CM_PER,
            g,
            2)
        g.wig.connect(CLK, self.set_margin_depend)

    def draw_grid_grp(self, g):
        """
        Draws the grid group.

        g: container
        """
        a = 1, 100
        p = self.on_widget_change
        g1 = Splitter(padx=2)
        g2 = RLabel("Row:").g
        g3 = self.row_sb = RSpinButton(p, a, k=ROW)
        g4 = RLabel("Column:").g
        g5 = self.col_sb = RSpinButton(p, a, k=COL)

        g1.both(g2, g4)
        g1.both(g3.g, g5.g)
        g1.pack()
        g.add(g1.g)
        self.merge_pc_grp = GPerCell(
            p,
            self.open_cell_win,
            "Merge Cells...",
            MERG_PER,
            g,
            0)

    def draw_layer_grp(self, g):
        """
        Draws a format layer group.

        g: container
        """
        w = MARGIN
        p = self.on_widget_change
        g1 = self.format_name_e = REntry(p, NAME, padx=1)
        g2 = self.effect_m = RComboBox(
            p, k=EFFECT, opt=[NON] + D[EFFECTS].names, padx=2)

        g.add(RLabel("Format Name:", TOPL).g)
        g.add(g1.g)
        g.add(RLabel("3D Effect:", TOPL).g)
        g.add(g2.g)

    def draw_layer_marg_grp(self, g):
        """
        Draws the layer margins.

        g: container
        """
        self.layer_margin_sb = list(self.draw_marg_grp(g, LAY_SB_K))

    def draw_marg_grp(self, g, k):
        """
        Draws the margin SpinButtons.

        g: container
        k: group key

        Returns the top, bottom, left, right SpinButton widgets.
        """
        a = 0, 100000
        p = self.on_widget_change
        g1 = [0] * 5

        for x in range(5):
            b = 2 if x == 0 else 0
            g1[x] = Splitter(padx=b)

        g2 = RLabel("Top:").g
        g3 = RSpinButton(p, a, k=k[TOP_X])
        g4 = RLabel("Bottom: ").g
        g5 = RSpinButton(p, a, k=k[BOT_X])
        g6 = RLabel("Left:").g
        g7 = RSpinButton(p, a, k=k[LEF_X])
        g8 = RLabel("Right:").g
        g9 = RSpinButton(p, a, k=k[RIG_X])

        for g10 in reversed(g1):
            g10.pack()

        g1[0].both(g1[1].g, g1[2].g)
        g1[0].both(g1[3].g, g1[4].g)
        g1[1].both(g2, g3.g)
        g1[2].both(g6, g7.g)
        g1[3].both(g4, g5.g)
        g1[4].both(g8, g9.g)
        g.add(g1[0].g)
        return g3, g5, g7, g9

    def draw_place_grp(self, g):
        """
        Draws the Placement ComboBoxes.

        g: container
        """
        q = MARGIN / 4, 0, 0, 0
        p = self.on_widget_change
        g1 = Splitter(padx=2)
        g2 = [0] * 4
        g2[0] = self.resize_m = RComboBox(p, k=RESIZE, opt=RSZ)
        g2[1] = self.image_m = RComboBox(p, k=IMAGE, opt=Images.format_img_list[:])
        g2[2] = self.horz_m = RComboBox(p, k=HORZ, opt=HRZ)
        g2[3] = self.vert_m = RComboBox(p, k=VERT, opt=VRT)

        # Connect dependents:
        for x in range(4):
            g2[x].resz, g2[x].img, g2[x].horz, g2[x].vert = g2[0], g2[1], g2[2], g2[3]

        g1.both(RLabel("Resize:", q).g, RLabel("Image:", q).g)
        g1.both(g2[0].g, g2[1].g)
        g1.both(RLabel("Horizontal:", q).g, RLabel("Vertical:", q).g)
        g1.both(g2[2].g, g2[3].g)
        g1.pack()
        g.add(g1.g)

        g = self.place_pc_grp = GPerCell(
            p,
            self.open_cell_win,
            "Placement...",
            PLACE_PER,
            g,
            1)
        g.wig.connect(CLK, self.set_place_depend)

    def draw_preset_grp(self, g):
        """
        Draws the Preset ComboBox and Buttons.

        g: container
        """
        self.preset_m = GPreset(
            g,
            self.on_preset_change,
            self.return_format,
            UISaveFormat,
            self.win,
            self.preset)

    def draw_process_grp(self, g):
        """
        Draws the Show Preview, Cancel, and Accept Buttons.

        g: container
        """
        # Save a self reference to buttons as GTK
        # will remove the event connections otherwise:
        g1 = self.accept_b = RButton("Accept", self.do_job, padx=3)
        g2 = self.show_b = RButton("Show Preview", self.show_preview, padx=2)
        g3 = self.cancel_b = RButton("Cancel", self.do_no, padx=1)

        g.add(g3.g)
        g.add(g2.g)
        g.add(g1.g)

    def draw_prop_grp(self, g):
        """
        Draws the property group.

        g: container
        """
        p = self.on_widget_change
        g1 = [0] * 3

        for x in range(3):
            a = 2 if x == 0 else 0
            g1[x] = Splitter(padx=a)

        g2 = self.flip_h_cb = RCheckButton(p, FH, FLIP_H)
        g3 = self.flip_v_cb = RCheckButton(p, FV, FLIP_V)
        g4 = self.rotate_sb = RSpinButton(p, (0, 359), k=ROT)
        g5 = self.opacity_sb = RSpinButton(p, (0, 100), k=OP)
        g5.flip_h, g5.flip_v, g5.rot = g2, g3, g4

        g1[0].left.add(g2.g)
        g1[0].left.add(g3.g)
        g1[1].both(RLabel("Rotate:").g, g4.g)
        g1[2].both(RLabel("Opaque:").g, g5.g)

        for g6 in reversed(g1):
            g6.pack()

        g.add(g1[0].g)
        g1[0].right.add(g1[1].g)
        g1[0].right.add(g1[2].g)

        g = self.prop_pc_grp = GPerCell(
            p,
            self.open_cell_win,
            "Property...",
            PROP_PER,
            g,
            3)
        g.wig.connect(CLK, self.set_prop_depend)

    def draw_win(self):
        """ Draws the window's widgets. """
        self.subtract_from_color()

        self.preset = PRFormat(dict(parent=self.win))
        g = self.win.vbox
        q = (
            self.draw_layer_grp,
            self.draw_grid_grp,
            self.draw_place_grp,
            self.draw_prop_grp,
            self.draw_layer_marg_grp,
            self.draw_cell_margin_grp,
            self.draw_preset_grp,
            self.draw_process_grp)

        c = (
            "Format Layer",
            "Layer Cell Grid",
            "Image Placement",
            "Image Property",
            LAY_MARG,
            CELL_MARG,
            "Format Options",
            PE)

        for i, p in enumerate(q):
            if not i % 2:
                same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

            box = REventBox(self.color)
            g1 = VBox()

            g1.add(RLabel(c[i] + ":", (2, 0, 4, 0)).g)
            box.add(g1)
            p(g1)
            same_size.add_widget(box)
            self.subtract_from_color()

            # Keep the widgets in memory:
            wig = same_size.get_widgets()

            if i % 2:
                # Add row of same size widgets:
                g2 = HBox()

                [g2.add(g3) for g3 in reversed(wig)]
                g.add(g2)

        self.pc_group = (
                self.merge_pc_grp,
                self.place_pc_grp,
                self.margin_pc_grp,
                self.prop_pc_grp)

        q = self.controls = [
            self.format_name_e,
            self.effect_m,
            self.resize_m,
            self.horz_m,
            self.vert_m,
            self.image_m,
            self.rotate_sb,
            self.opacity_sb,
            self.flip_h_cb,
            self.flip_v_cb,
            self.prop_pc_grp,
            self.place_pc_grp,
            self.merge_pc_grp,
            self.margin_pc_grp,
            self.row_sb,
            self.col_sb,
            self.preset_m]

        q += [g for g in self.layer_margin_sb]
        q += [g for g in self.cell_margin_sb]

        self.update_controls(self.format)
        self.verify_opacity_depend(self.opacity_sb, self.prop_pc_grp)
        self.verify_place_menus(self.resize_m)
        self.verify_per_cell_buttons()

    def expand_cell_table(self, p):
        """
        Expands a cell table based on the row and column counts.

        During an expansion, values are inserted into
        a table from the Format window settings.
        These settings are placed in a "cell" variable.

        Each Per Cell group has its own cell configuration.

        p: a process that returns a cell value
            and the cell table index for the format
        """
        d = self.format
        cell, x = p()
        row, col = d[ROW], d[COL]

        if not d[x]:
            d[x] = create_2d_table(row, col, a=cell)

        else:
            r = len(d[x])

            if r < row:
                e = []

                for _ in range(col):
                    e.append(cell)
                for r1 in range(row - r):
                    # Add a row with a new list:
                    d[x].append(deepcopy(e))
            for r1 in range(row):
                c = len(d[x][r1])
                if c < col:
                    for _ in range(col - c):
                        # Add a column:
                        d[x][r1].append(cell)

    def expand_cell_tables(self):
        """
        The Per Cell tables need updating because the number
        of rows and/or columns may have increased value.
        """
        for x, p in enumerate([
                self.init_merge_table,
                self.init_place_table,
                self.init_margin_table,
                self.init_prop_table]):
            if self.pc_group[x].get_val():
                self.expand_cell_table(p)

    def fix_merge_cells(self):
        """
        Correct overflow references by reducing
        merged group dimensions in top-left cells.
        """
        d = self.format
        row = d[ROW]
        col = d[COL]

        if d[MERG_PER]:
            for r in range(row):
                for c in range(col):
                    if r < len(d[ME_CELL]):
                        if c < len(d[ME_CELL][r]):
                            d[ME_CELL][r][c] = self.correct_merge_overflow(
                                d[ME_CELL][r][c], row, col, r, c)
        self.correct_contracted_cells()

    def init_margin_table(self):
        """
        This routine is called by "expand_cell_table".

        Returns the image margins cell table init value and the cell table key.
        """
        q = []

        for k in CELL_SB_K:
            q.append(self.format[k])
        return tuple(q), CM_CELL

    def init_merge_table(self):
        """
        This routine is called by "expand_cell_table".

        Returns the merge cell table init value and the cell table key.
        """
        return (1, 1), ME_CELL

    def init_place_table(self):
        """
        This routine is called by "expand_cell_table".

        Returns the image placement cell table
        init value and the cell table key.
        """
        d = self.format
        return (
            d[RESIZE],
            d[IMAGE],
            d[HORZ],
            d[VERT]), PL_CELL

    def init_prop_table(self):
        """
        This routine is called by "expand_cell_table".

        Returns the property table init value and the cell table key.
        """
        q = []

        for k in PROP_K:
            q.append(self.format[k])
        return tuple(q), PR_CELL

    def on_preset_change(self, g, d):
        """
        Called when the user makes a selection in the preset ComboBox.

        Loads the preset.

        g: GPreset
        d: preset dict
        """
        if not UI.loading:
            if self.preset_m.get_text() != UND:
                self.format = self.load_controls(d)
                self.verify_per_cell_buttons()

    def on_widget_change(self, g):
        """
        A widget changed.

        g: widget
        """
        if not UI.loading:
            self.format[g.key] = g.get_val()

            if g.key in PLACE_K:
                self.verify_place_menus(g)

            elif g.key in PER_CELL_K or g.key == MERG_PER:
                # Reset cell data:
                self.format[g.cell_key] = None
                self.verify_per_cell_buttons()

            elif g.key == OP:
                self.verify_opacity_depend(g)
            self.preset_is_undefined()

    def open_cell_win(self, x):
        """
        Opens a Per Cell window.

        x: window index used by UICell
        """
        # Update layout calculations:
        self.adjust_cell_tables()

        a = Format(self.format)

        self.win.iconify()
        UICell(
            dict(
                format_c=a,
                merge_pc=self.merge_pc_grp.get_val(),
                win_x=x,
                parent=self.win)).reply
        if a.format != self.format:
            self.format = deepcopy(a.format)
        self.win.present()

    def return_format(self):
        """ Used by GPreset when saving presets. """
        return self.format

    def set_margin_depend(self, *a):
        """
        Sets margin dependents.

        a: unused
        """
        for g in self.cell_margin_sb:
            g.disable() if self.margin_pc_grp.get_val() else g.enable()

    def set_place_depend(self, *a):
        """
        Sets placement dependents.

        a: unused
        """
        for g in (self.resize_m, self.horz_m, self.vert_m, self.image_m):
            g.disable() if self.place_pc_grp.get_val() else g.enable()

    def set_prop_depend(self, *a):
        """
        Sets image dependents.

        a: unused
        """
        for g in (
                self.rotate_sb, self.opacity_sb,
                self.flip_h_cb, self.flip_v_cb):
            g.disable() if self.prop_pc_grp.get_val() else g.enable()

    def show_preview(self, *a):
        """
        Called when the user activated the Show Preview Button.

        a: unused
        """
        self.adjust_cell_tables()

        # Update D:
        q = D[SESS][FORMAT]
        d = deepcopy(q[self.format_x])
        q[self.format_x] = self.format

        D[PREVIEW].show()

        # Restore D:
        q[self.format_x] = d

    def verify_per_cell_buttons(self):
        """ Validates Per Cell dependency. """
        for p in (
                self.set_place_depend,
                self.set_margin_depend,
                self.set_prop_depend):
            p()


class UIMain(UI):
    """ This is the script's main window. """
    win = None

    def __init__(self):
        """ This is where the main gtk event loop takes place. """
        if self.verify_ext_dir():
            self.load_last_session()
            info_msg("started")
            Images.get_img()

            D[EFFECTS] = EFS()
            D[PREVIEW] = Preview()
            d = {
                ACCEPT: self.do_job,
                DRAW: self.draw_win,
                POSE: 'main',
                TITLE: program_title}

            UI.__init__(self, d)
            gtk.main()

    def cancel(self, g):
        """
        Called when the user activates the Cancel Button.

        g: unused
        """
        self.close()

    def create_format(self, n):
        """
        Creates a new format.

        n: name of the format
        """
        d = deepcopy(Format.default)
        d[NAME] = self.format_list.get_sel_text()
        D[SESS][FORMAT].append(d)
        self.edit_format()

    def do_job(self, *a):
        """
        Called when the user activates the Render Button.

        a: unused
        """
        self.set_global_scales()

        for g in self.controls:
            if g.key != FORMAT:
                D[SESS][g.key] = g.get_val()

        self.close()

        if D[SESS] != self.last_session:
            D[SESS][PRESET] = USE
            pickle_dump(dict(data=D[SESS], file=self.last_used_file))
        self.render()

    def draw_backdrop_grp(self, g):
        """
        Draws the format group.

        g: container
        """
        # Backdrop Style:
        w = MARGIN
        p = self.on_widget_change
        q = self.backdrop_images = Images.format_img_list[:]

        q.pop(q.index(NXT))

        a = D[STYLES] = BDS()
        q1 = self.styles = a.names
        g1 = self.bd_style_m = RComboBox(p, k=BD_STYLE, opt=q1, padx=1)
        g2 = self.bd_image_m = RComboBoxE(p, k=BD_IMAGE, opt=q, padx=2)

        g.add(RLabel("Backdrop Style:", TOPL).g)
        g.add(g1.g)
        g.add(RLabel("Backdrop Image", TOPL).g)
        g.add(g2.g)

    def draw_format_grp(self, g):
        """
        Draws the format group.

        g: container
        """
        self.format_list = FormatList(
            g,
            self.create_format,
            self.edit_format,
            self.on_format_list_changed)

    def draw_preset_grp(self, g):
        """
        Draws the preset group.

        g: container
        d: dict
        """
        self.preset_m = GPreset(
            g,
            self.on_preset_change,
            self.return_session,
            UISaveForm,
            self.win,
            self.preset)

    def draw_preview_grp(self, g):
        """
        Draws the preview group.

        g: container
        d: dict
        """
        g1 = self.show_b = RButton("Show Preview", self.show_preview, padx=1)
        g2 = self.preview_m = PlusMenu(
            self.on_widget_change,
            PREVIEW_OPT,
            deepcopy(Session.default[PREVIEW_OPT]))

        g.add(g1.g)
        g.add(RLabel("Preview Options:", TOPL).g)
        g.add(g2.g)

    def draw_process_grp(self, g):
        """
        Draws the process group.

        g: container
        d: dict
        """
        g1 = self.cancel_b = RButton("Cancel", self.cancel, padx=1)
        g2 = self.render_b = RButton("Render", self.accept, padx=2)

        g.add(g1.g)
        g.add(g2.g)

    def draw_res_grp(self, g):
        """
        Draws the resolution group.

        g: container
        d: dict
        """
        q = 25, 100000
        w = MARGIN
        p = self.on_widget_change
        g1 = self.width_sb = RSpinButton(p, q, q1=(10, 100), k=WI, padx=1)
        g2 = self.height_sb = RSpinButton(p, q, q1=(10, 100), k=HG, padx=2)

        g.add(RLabel("Width:", (0, 0, w, 0)).g)
        g.add(g1.g)
        g.add(RLabel("Height:", (w / 2, 0, w, 0)).g)
        g.add(g2.g)

    def draw_win(self):
        """ Draws the window's widgets. """
        self.subtract_from_color()

        self.preset = PRForm(dict(parent=self.win))
        g = VBox()
        q = (
            self.draw_format_grp,
            self.draw_preset_grp,
            self.draw_backdrop_grp,
            self.draw_preview_grp,
            self.draw_res_grp,
            self.draw_process_grp)

        q1 = "Format", "Preset", "Backdrop", "Preview", "Resolution", "Process"

        for i, p in enumerate(q):
            if not i % 2:
                same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

            box = REventBox(self.color)
            g1 = VBox()

            g1.add(RLabel(q1[i] + ":", (2, 0, 4, 0)).g)
            box.add(g1)
            p(g1)
            same_size.add_widget(box)
            self.subtract_from_color()

            # For some reason I have to get widgets in order to keep them:
            wig = same_size.get_widgets()

            if i % 2:
                # Add row of same size widgets:
                g2 = HBox()

                [g2.add(g3) for g3 in reversed(wig)]
                g.add(g2)

        self.win.add(g)
        self.controls = (
            self.format_list,
            self.preview_m,
            self.bd_style_m,
            self.bd_image_m,
            self.preset_m,
            self.width_sb,
            self.height_sb)

        self.update_controls(D[SESS])
        self.verify_bd_img_m()

    def edit_format(self):
        """
        Switches to the format editor window for the selected format.

        a: unused
        """
        self.format_x = self.format_list.items[self.format_list.get_sel_x()][1]

        self.set_global_scales()
        UIFormat(dict(
            feed=self.get_uiformat,
            format_x=self.format_x,
            parent=self.win))

    def get_uiformat(self, x):
        """
        Called when the user accepted the format window.

        x:  format index
        """
        if x is not None:
            n = D[SESS][FORMAT][x][NAME]
            self.format_list.rename(x, n)
        self.format_list.select_item(self.format_x)
        self.preset_is_undefined()

    def img_needed(self, n):
        """
        Some backdrop styles don't require an image.

        n: backdrop style name
        """
        return n not in (COD, COG, FF, PF, TR)

    def load_last_session(self):
        """ Loads the last Session file or the default settings. """
        n = self.last_used_file = os.path.join(
            D[DIR], self.get_preset_name(PRForm.pattern, USE))

        d = Session.load(dict(file=n, show=0))

        if d > 0:
            D[SESS] = deepcopy(d)
            b = self.last_session = deepcopy(d)
            b[PRESET] = D[USE] = D[SESS][PRESET] = USE

        else:
            self.last_session = None
            D[SESS] = deepcopy(Session.default)
            D[SESS][PREVIEW_OPT] = {}

    def on_format_list_changed(self, *g):
        """
        Called when the format list changes.

        g: unused
        """
        if not UI.loading:
            # Re-order the list:
            q = self.format_list.get_val()
            q1 = []

            for q2 in q:
                # new format list order:
                q1.append(D[SESS][FORMAT][q2[1]])

            D[SESS][FORMAT] = q1

            self.format_list.set_indices()
            self.preset_is_undefined()

    def on_preset_change(self, g, d):
        """
        Called because the preset menu changed display value.

        g: GPreset
        d: preset dict
        """
        if not UI.loading:
            if self.preset_m.get_text() != UND:
                D[SESS] = self.load_controls(d)
                self.verify_bd_img_m()

    def on_widget_change(self, g):
        """
        A widget changed.

        g: widget
        """
        if not UI.loading:
            D[SESS][g.key] = g.get_val()

            self.preset_is_undefined()
            if g.key == BD_STYLE:
                self.verify_bd_img_m()

    def render(self):
        """ Renders the form. """
        m = 0

        if Preview.has_background:
            j = L[RENDER]

            Lay.bury(j, L[PREVIEW_BG])

            if Preview.has_formats:
                pdb.gimp_item_set_visible(L[PREVIEW], 0)

            if D[SIZE] != (j.width, j.height):
                m = 1
                pdb.gimp_image_scale_full(
                    j, D[WI], D[HG], fu.INTERPOLATION_CUBIC)

            z = L[BD] = Lay.new(j, BD)
            Lay.place(j, z, a=1)

        else:
            j = Layout.new_render()
            L[BD] = Lay.add(j, BD)
            D[DISPLAY] = pdb.gimp_display_new(j)

        self.render_backdrop()
        self.render_format()
        Sel.none(j)
        pdb.gimp_image_set_active_layer(j, L[BD])
        if m:
            Lay.bury(j, L[PREVIEW])

    def render_backdrop(self):
        """
        Creates the backdrop layer.

        Returns a style name.
        """
        d = D[SESS]
        style = d[BD_STYLE]

        if self.img_needed(style):
            # Copy the backdrop image to the backdrop layer:
            n = d[BD_IMAGE]

            if n == NON:
                # Fill with white:
                Lay.color_fill(L[BD], WH)

            else:
                j = Img.get_image(n)
                j1 = j.j

                Sel.none(j1)
                kopy(j1)

                if j.size != D[SIZE]:
                    # Resize backdrop image to fit backdrop layer:
                    j = Img.paste()

                    Img.resize(j, D[WI], D[HG])
                    kopy(j)
                    Img.bury(j)

                z = Lay.paste(L[RENDER], L[BD])
                L[BD] = Lay.merge(L[RENDER], z)

        L[BD].name = style
        D[STYLES].obj[self.styles.index(style)]()

    def render_effect(self, d):
        """
        Creates a 3D effect for the images.

        d: format dict
        """
        D[FORMAT] = d
        D[N] = effect = d[EFFECT]
        if effect != NON:
            p = D[EFFECTS].obj[D[EFFECTS].names.index(effect)]
            p()

    def render_format(self):
        """ Renders from the bottom of the Format list. """
        j1 = L[RENDER]
        format_list = D[SESS][FORMAT]
        start = len(format_list) - 1
        Images.next_x = 0

        for x in range(start, -1, -1):
            Layout.pix = 0
            d = format_list[x]
            cell = Cell(d)
            r, c = d[ROW], d[COL]
            row, col = d[ROW], d[COL]
            cell = Cell(d)

            #  Place images:
            for r in range(row):
                for c in range(col):
                    if cell.has_image(r, c, d):
                        j = Layout.get_image(r, c, d)
                        j.r, j.c = r, c
                        j.rot = Layout.get_rotate(r, c, d)
                        Layout.place_img(j, d, cell)
            if Layout.pix:
                z = L[IMAGE] = pdb.gimp_image_merge_layer_group(j1, L[IMG_GRP])
                a = 1 if Preview.has_formats else 0
                L[FORMAT_GRP] = Lay.group(j1, d[NAME], a=a)

                Lay.order(j1, z, L[FORMAT_GRP])
                self.render_effect(d)

    def return_session(self):
        """ Used to get session data for saving. """
        return D[SESS]

    def set_global_scales(self):
        """ Sets the global scale variables. """
        D[SIZE] = D[WI], D[HG] = self.width_sb.get_val(), self.height_sb.get_val()

    def show_preview(self, *a):
        """
        Called when the user activated the Show Preview Button.

        a: unused
        """
        D[PREVIEW].show()

    def verify_bd_img_m(self):
        """
        The Backdrop Images menu is invalid if the
        Backdrop Style does not need an image.
        """
        a = self.bd_image_m
        if self.img_needed(self.bd_style_m.get_val()):
            a.enable()

            n = self.bd_image_m.get_val()
            if n not in self.backdrop_images or n != D[SESS][BD_IMAGE]:
                n = FIRST if FIRST in self.backdrop_images else NON
                D[SESS][BD_IMAGE] = n
                self.bd_image_m.set_val(n)

        else:
            a.disable()

    def verify_ext_dir(self):
        """
        The external directory is where preset and session files are stored.

        The script uses the user's home
        directory to create a storage folder.

        Returns a result flag. It is set to true if the directory is verified.
        """
        m = n1 = 0
        n = platform.system()

        if n == "Linux":
            n1 = u"/home/user/.GIMP/Roller/profiles/"

        elif n == "Darwin":
            n1 = u"/Library/Application Support/GIMP/Roller"

        elif n == "Windows":
            n1 = u"AppData\\Local\\GIMP\\Roller"

        if n1:
            try:
                n = D[DIR] = os.path.join(expanduser("~"), n1)

                if not os.path.isdir(n):
                    os.makedirs(n)
                m = 1

            except Exception as ex:
                show_err(ex)

        else:
            show_err("The operating system isn't supported by Roller.")
        return m


def start():
    """
    Called by GIMP when the user selects the
    Roller menu item in the render menu.
    """
    # Save the interface context:
    pdb.gimp_context_push()
    UIMain()

    # Return undo functionality:
    if RENDER in L:
        pdb.gimp_image_undo_group_end(L[RENDER])

    # Restore the interface context:
    pdb.gimp_context_pop()


fu.register(
    # name
    # becomes dialog title as python-fu + name
    # Space character is not allowed.
    # "name" is case-sensitive:
    "Roller",

    # tool-tip and window-tip text:
    "Renders image compositions.",

    # help (describe how-to, exceptions and dependencies).
    # This info will display in the plug-in browser:
    "Creates a new image and does not require an open image.",

    # The author is displayed in the plug-in browser:
    "Charles Bartley",

    # The copyright is displayed in the plug-in browser:
    "Charles Bartley",

    # The date is displayed in the plug-in browser:
    "2020",

    # menu item descriptor:
    "Roller...",

    # image types
    # An empty string equates to no image:
    "",

    # dialog parameters:
    [],

    # results:
    [],

    # dialog function handler
    # The second item is the menu's location:
    start, menu="<Image>/Filters/Render")


RETURN_WIDGETS = (
    gtk.CheckButton,
    gtk.Entry,
    gtk.ScrolledWindow,
    gtk.SpinButton,
    gtk.ToggleButton,
    SwitchButton)
fu.main()
