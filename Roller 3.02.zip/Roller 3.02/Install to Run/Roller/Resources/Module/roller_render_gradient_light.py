#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_style_gradient_fill import GradientFill
from roller_constant_key import (
    BackdropStyle as by,
    Layer as nk,
    Option as ok
)
from roller_one import Hat, One
from roller_one_fu import Lay, Sel
from roller_option_preset import Preset
import gimpfu as fu

pdb = fu.pdb


class GradientLight:

    @staticmethod
    def apply_light(z, k):
        """
        Add gradient light to a layer.

        z: layer
            to receive effect

        k: string
            option key
            of Influence

        Return: layer
            the original or its alter
        """
        def apply_it():
            """
            Apply the gradient light to the layer.

            Return: layer
                with the gradient light
            """
            z2 = Lay.clone(z1)
            z2.opacity = 100.

            if k == ok.METAL_FRAME:
                z2.mode = fu.LAYER_MODE_HARDLIGHT

            pdb.gimp_image_reorder_item(j, z2, z.parent, 0)
            Sel.item(z)
            Sel.invert_clear(z2)

            opacity = z.opacity
            z2.opacity = f
            z2 = pdb.gimp_image_merge_down(j, z2, fu.CLIP_TO_IMAGE)
            z2.opacity = opacity
            return z2

        if z:
            cat = Hat.cat
            j = cat.render.image
            d = cat.gradient_light_d
            f = d[ok.INFLUENCE][k]
            k1 = nk.GRADIENT_LIGHT
            if f:
                z1 = cat.get_layer(k1)

                if z1:
                    z = apply_it()
                else:
                    e = Preset.get_default(by.GRADIENT_FILL)

                    e.update(d)

                    z1 = GradientFill.do_layer(One(d=e))
                    z1.opacity = .0
                    z1.name = nk.GRADIENT_LIGHT

                    cat.register_layer(k1, z1)
                    pdb.gimp_image_reorder_item(
                        j, z1,
                        None,
                        len(j.layers) - 1 - cat.gradient_light_position
                    )
                    z = apply_it()
        return z
