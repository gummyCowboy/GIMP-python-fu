#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Mage, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
X_IS_1 = Y_IS_1 = 1


def draw_lines(z, d):
    """
    Draw squares on the rotated layer.

    Create a pattern (a black square).
    Use the clipboard to hold the pattern.
    Fill the target layer with the pattern.

    z: layer
        target layer

    d: dict
        Has options.

    Return: layer
        work-in-progress
        Has material to select.
    """
    w = d[ok.LINE_WIDTH]
    w1 = d[ok.GAP_WIDTH] + w
    j1 = pdb.gimp_image_new(w1, w1, fu.RGB)
    z1 = Lay.add(j1, "Pattern")
    y = (w1 - w) // 2

    Sel.rect(j1, 0, y, w1, w, option=fu.CHANNEL_OP_REPLACE)
    Sel.fill(z1, (0, 0, 0))

    # Set the Clipboard Image:
    Mage.copy_all(j1)

    pdb.gimp_image_delete(j1)
    RenderHub.set_fill_context(fg.FILL_DICT)
    pdb.gimp_context_set_pattern("Clipboard Image")
    pdb.gimp_drawable_edit_bucket_fill(
        z,
        fu.FILL_PATTERN,
        X_IS_1, Y_IS_1
    )
    return z


def make_sel(one, frame_sel, filler_sel):
    """
    Modify the current selection with the selected lines.

    Add the line selection to the border selection
    within the bounds of the filler selection.

    one: One
        Has options.

    frame_sel:
        Is the frame around the image material.

    filler_sel:
        Is the space for the filler material.

    Return: state of selection
    """
    cat = Hat.cat
    j = cat.render.image
    z = Lay.add(j, "Lines", parent=one.parent)
    z1 = RenderHub.do_rotated_layer(z, one.d, draw_lines)

    Sel.isolate(z1, filler_sel)
    Sel.item(z1)
    pdb.gimp_selection_feather(j, 1.)
    Sel.grow(j, 1, 1)
    pdb.gimp_image_remove_layer(j, z1)
    Sel.load(j, frame_sel, option=fu.CHANNEL_OP_ADD)


class LineFashion:
    """Add a framework to BorderLine."""

    @staticmethod
    def do(one):
        """
        Do the Line Fashion image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Line Fashion
        """
        return BorderLine.do(one, framer=make_sel, filler=lambda *q, **k: None)
