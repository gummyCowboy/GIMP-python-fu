#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_style_backdrop_image import BackdropImage
from roller_constant_for import (
    Grid as gr,
    Plan as fy,
    Margin as fm,
    Shape as sh
)
from roller_constant_key import (
    BackdropStyle as by,
    Group as gk,
    Option as ok,
    Plan as ak
)
from roller_grid import Grid
from roller_model_place import Place
from roller_one import Hat, One, Rect
from roller_one_extract import Form, Path, Shape
from roller_one_fu import Lay, Sel
from roller_render import Render
import gimpfu as fu

pdb = fu.pdb
PLAN = 'plan'
READY = ": Ready"
WORK = ": Working"

# Are option groups that change and influence follower groups.
# However, they are not needed in the render step-through:
CHANGE_STEP = gk.BACKDROP_STYLE


def draw_cell_info(d, group, rect):
    """
    Draw the cell info per the plan options.

    d: dict
        of plan options

    group: layer
        for new layer

    rect: Rect
        cell rectangle
    """
    if d[ak.COORDINATES]:
        draw_coord(group, rect)
    if d[ak.CORNERS]:
        draw_corners(group, rect)
    if d[ak.DIMENSIONS]:
        draw_dimension(group, rect)
    if d[ak.RATIOS]:
        draw_ratio(group, rect)


def draw_coord(group, rect):
    """
    Draw image coordinates at the top-left of a cell.

    group: layer
        Is parent for new layer.

    rect: Rect
        cell rectangle
    """
    x, y = rect.position
    z = make_text(str(x) + ", " + str(y))
    draw_text(group, z, x + 3, y)


def draw_corners(group, rect):
    """
    Draw image corner coordinates.

    group: layer
        Is parent for new layer.

    rect: Rect
        cell rectangle
    """
    # top-right:
    x, y = rect.position
    w, h = rect.size
    n = str(x + w) + ", " + str(y)
    z = make_text(n)

    draw_text(group, z, x + w - z.width - 3, y)

    # bottom-left:
    n = str(x) + ", " + str(y + h)
    z = make_text(n)
    draw_text(group, z, x + 3, y + h - z.height)


def draw_dimension(group, rect):
    """
    Draw an image's dimension at the bottom-right of a cell.

    group: layer
        Is parent for new layer.

    rect: Rect
        cell rectangle
    """
    x, y = rect.position
    w, h = rect.size
    n = str(w) + ", " + str(h)
    z = make_text(n)
    draw_text(group, z, x + w - z.width - 3, y + h - z.height)


def draw_name(group, n, rect):
    """
    Draw an image name over a cell image.

    group: layer
        Is parent for text layer.

    n: string
        to draw

    rect: Rect
        cell rectangle

    Return: layer
        with text
    """
    z = make_text(n)
    x, y = rect.position
    w, h = rect.size
    x = w // 2 + x - z.width // 2
    y = h // 2 + y + z.height // 2
    draw_text(group, z, x, y)
    return z


def draw_ratio(group, rect):
    """
    Draw a cell ratio at the center of a cell.

    A ratio is a cell center point divided by the render size.

    group: layer
        Is parent for new layer.

    rect: Rect
        cell rectangle
    """
    x, y = rect.position
    w, h = rect.size
    s = Hat.cat.render.size
    x1 = (w // 2 + x) / 1. / s[0]
    y1 = (h // 2 + y) / 1. / s[1]
    r_x = format(x1, '.2f')
    r_y = format(y1, '.2f')
    n = r_x[int(x1 < 1):] + ", " + r_y[int(y1 < 1):]
    z = make_text(n)
    x2 = x + w // 2 - z.width // 2
    y2 = y + h // 2 - z.height // 2
    draw_text(group, z, x2, y2)


def draw_text(group, z, x, y):
    """
    Add a text layer to the group.

    group: layer
        parent

    z: layer
        to receive text

    x, y: int
        final position
        screen coordinate
    """
    pdb.gimp_image_insert_layer(Hat.cat.render.image, z, group, 0)
    pdb.gimp_text_layer_set_color(z, (255, 255, 255))
    pdb.gimp_layer_set_offsets(z, x, y)
    z.opacity = 66.


def make_text(n):
    """
    Create a new text layer.

    n: string
        text to display

    Return: layer
        with text
    """
    return pdb.gimp_text_layer_new(
        Hat.cat.render.image,
        n,
        'Sans-serif',
        11.,
        fu.PIXELS
    )


def update_unseen_flag(steps):
    """
    The change flag is used to indicate an option group's
    render status. If it's changed, then the render needs
    to be done.

    The change flag also has a chain-inheritance. If a step
    is changed, the following steps are also changed.

    steps: list
        of paths (tuples)
        Paths are keys to option group widgets held in 'group_dict'.

    Return: list
        of changed steps
    """
    e = Hat.cat.group_dict
    q = []
    is_change = False

    # Every step after the first changed
    # group is part of a preview.
    # Change the change status as it is
    # assumed that the render will succeed.
    # Remove the CHANGE_STEP group as
    # it has served its purpose:
    for i in steps:
        a = e[i]
        if not is_change and a.unseen:
            is_change = True
        if is_change:
            a.unseen = False
            if a.group_key != CHANGE_STEP:
                q += [i]
    return q


class Plan(Render):
    """Organize Plan methods."""

    def __init__(self):
        """Initialize the plan variables."""
        Render.__init__(self, PLAN)

        self._previous_steps = []

        self.layer_d.update({gk.GRID: self._do_grid})
        self.non_layer_d.update(
            {
                by.BACKDROP_IMAGE: self._do_backdrop_style,
                gk.CELL_MARGIN: self._do_cell_margin,
                gk.LAYER_MARGIN: self._do_layer_margins
            }
        )
        self._extra_op_d = {
            gk.CELL_IMAGE_PLACE: self._draw_cell_image_name,
            gk.CUSTOM_CELL_IMAGE_PLACE: self._draw_custom_cell_image_name,
            gk.CUSTOM_CELL_MARGIN: self._do_custom_cell_margins,
            gk.CUSTOM_CELL_PROPERTY: self._rename_group,
            gk.TABLE_PROPERTY: self._rename_group,
            gk.RECTANGLE: self._do_rectangle
        }

    def _do_backdrop_style(self, one):
        """
        Create a plan group and a backdrop image layer.

        one: One
            Has globals dict.
        """
        d = deepcopy(self.image_index)
        z = self.backdrop_layer = Lay.add(
            Hat.cat.render.image,
            "Backdrop",
            parent=self.plan_group
        )

        BackdropImage.do(one, is_plan=True)
        Lay.color_fill(z, fy.BACKGROUND_COLOR)
        self.undo[one.path] = (z, d), self.undo_layer

    def _do_cell_margin(self, one):
        """
        Plan grid cell margins.

        one: One
            Has variables.
        """
        one.grid.calc_pockets(one.d)
        if self.plan_flags[ak.CELL_MARGINS]:
            z = Lay.add(
                Hat.cat.render.image,
                "Cell Margin",
                parent=self.model_group
            )
            z.opacity = 66.

            self._draw_cell_margins(one, z)
            self.undo[one.path] = z, Lay.remove

    def _do_custom_cell_margins(self, one):
        """
        Plan cell margins.

        one: One
            Has path.

        z: layer
            to draw on
        """
        if self.plan_flags[ak.CELL_MARGINS]:
            r = fy.CUSTOM_CELL
            j = Hat.cat.render.image

            self._draw_cell_margin(one.d, r, r, False)
            if Sel.is_sel(j):
                z = Lay.add(j, "Cell Margins", parent=self.model_group)
                z.opacity = 66.

                Sel.fill(z, fy.CELL_MARGIN_COLOR)
                self.undo[one.path] = z, Lay.remove

    def _do_grid(self, one):
        """
        Plan a cell grid.

        one: One
            Has the cell grid dictionary.
        """
        a = self.grid
        j = Hat.cat.render.image
        grid = self.grid = Grid(one)
        z = group = None
        d = self.plan_flags
        n = "Grid"
        s = 1
        is_per_cell = one.d[ok.PER_CELL]

        if d[ak.GRID]:
            group = Lay.group(j, n, parent=self.model_group)
            z = Lay.add(j, n, parent=group)
            self._draw_grid(z)

        if any(
            (
                d[ak.COORDINATES],
                d[ak.CORNERS],
                d[ak.DIMENSIONS],
                d[ak.RATIOS]
            )
        ):
            if not group:
                group = Lay.group(j, n, parent=self.model_group)
            row, column = grid.division
            for r in range(row):
                for c in range(column):
                    if is_per_cell:
                        s = one.d[ok.PER_CELL][r][c]
                    if (
                        Shape.is_allocated_cell(grid, r, c) and
                        s != (-1, -1)
                    ):
                        draw_cell_info(
                            d,
                            group,
                            grid.get_merge_cell_rect(r, c)
                        )

        if group:
            z = Lay.merge_group(group)
        self.undo[one.path] = (a, z), self._undo_grid

    def _do_layer_margins(self, one):
        """
        Calculate layer margins. Show layer margins.

        one: One
            Has layer margins dict.
        """
        cat = Hat.cat
        z = None
        q = self.layer_margin[:]
        self.layer_margin = Form.combine_margin(one.d, *cat.render.size)

        if self.plan_flags[ak.LAYER_MARGINS]:
            z = self._draw_layer_margins(one)
        self.undo[one.path] = (q, z), self._undo_layer_margins

    def _do_rectangle(self, one):
        """
        Process a custom cell rectangle step.
        """
        cat = Hat.cat
        j = cat.render.image
        d = self.plan_flags
        group = None
        a = self.cell.rect

        if self.plan_flags[ak.RECTANGLE]:
            group = Lay.group(j, "Rectangle", parent=self.model_group)
            z = Lay.add(j, "Lines", parent=group)
            s = cat.render.size
            x, y = a.position
            w, h = a.size

            pdb.gimp_selection_none(j)
            Sel.rect(j, 0, y, s[0], 1)
            Sel.rect(j, 0, y + h, s[0], 1)
            Sel.rect(j, x, 0, 1, s[1])
            Sel.rect(j, x + w, 0, 1, s[1])
            Sel.fill(z, fy.GRID_COLOR)

        if any(
            (d[ak.COORDINATES], d[ak.CORNERS], d[ak.DIMENSIONS], d[ak.RATIOS])
        ):
            if not group:
                group = Lay.group(j, "Rectangle", parent=self.model_group)
            draw_cell_info(d, group, a)
        if group:
            z = Lay.merge_group(group)
            q, p = self.undo[one.path]
            self.undo[one.path] = (z, q[1]), p

    def _draw_cell_margin(self, d, r, c, is_one):
        """
        Select cell margins for a cell.

        d: dict
            of cell margin chunk or form

        r, c: int
            cell index
        """
        def select_margins():
            """
            Select a margin for a cell.

            Return: Selection
                state of image
            """
            a = q[i]

            if a:
                top, bottom, left, right = q
                width, height = rect.size

                if is_one:
                    top1, bottom1, left1, right1 = self.layer_margin

                    if i < 2:
                        width = size[0] - left1 - right1
                    else:
                        height = size[1] - top1 - bottom1

                width = max(1, width - left - right)
                height = max(1, height - top - bottom)
                x, y = rect.position
                x += (left, left, 0, width + left)[i]
                y += (0, height + top, top, top)[i]
                w = (width, width, a, a)[i]
                h = (a, a, height, height)[i]
                Sel.rect(j, x, y, w, h)

        cat = Hat.cat
        e = Form.get_form(d, r, c)
        j = cat.render.image
        size = cat.render.size

        if r != fy.CUSTOM_CELL:
            rect = self.grid.get_merge_cell_rect(r, c)

        else:
            rect = self.cell.rect

        q = Form.combine_margin(e, *rect.size)
        for i in range(4):
            is_draw = True

            # left, right:
            if i in (fm.LEFT, fm.RIGHT):
                if is_one and r > 0:
                    is_draw = False

            # top, bottom:
            else:
                if is_one and c > 0:
                    is_draw = False
            if is_draw:
                select_margins()

    def _draw_cell_margins(self, one, z):
        """
        Plan cell margins.

        one: One
            Has path.

        z: layer
            to draw on
        """
        def is_draw_one_margin():
            """
            There is only one margin to draw if the cells have common bounds.
            """
            return not any(
                (
                    grid_d[ok.PER_CELL],
                    is_merge_cell,
                    d[ok.PER_CELL],
                    grid_d[ok.GRID_TYPE] != gr.CELL_COUNT
                )
            )

        cat = Hat.cat
        j = cat.render.image
        row, column = self.grid.division
        grid = self.grid
        double_type = self.grid.double_type
        is_merge_cell = self.grid.is_merge_cell
        d = one.d
        grid_d = grid.grid_d
        is_one = is_draw_one_margin() if not double_type else False

        for r in range(row):
            for c in range(column):
                go = True

                if is_merge_cell:
                    if grid_d[ok.PER_CELL][r][c] == (-1, -1):
                        go = False
                if go:
                    if double_type:
                        go = Shape.is_allocated_cell(grid, r, c)
                    if go:
                        self._draw_cell_margin(d, r, c, is_one)
        if Sel.is_sel(j):
            Sel.fill(z, fy.CELL_MARGIN_COLOR)

    def _draw_grid(self, z):
        """
        Draw grid lines.

        one: One
            Has grid variables.

        z: layer
            to draw on
        """
        cat = Hat.cat
        j = cat.render.image
        m = False
        grid = self.grid
        row, column = grid.division
        w, h = cat.render.size
        top, bottom, left, right = self.layer_margin
        double_type = grid.double_type

        # Init:
        a = Rect((0, 0), (0, 0))
        y = 0

        # Grid lines divide the layer space:
        w1 = w - left - right
        x = left
        h1 = 1

        pdb.gimp_selection_none(j)

        # Draw rows:
        for r in range(0, row + 1):
            c = 0
            is_draw = True

            if double_type and r != row:
                c = not r % 2 if double_type == sh.SHIFT else r % 2
                c = min(column - 1, c)
                is_draw = Shape.is_allocated_cell(grid, r, c)
            if is_draw:
                if r == row:
                    y += a.h

                else:
                    a = grid.get_cell_rect(r, c)
                    y = a.y
                if 0 < y < h:
                    m = True
                    Sel.rect(j, x, y, w1, h1)

        w1, h1 = 1, h - top - bottom
        y = top

        # Draw columns:
        for c in range(0, column + 1):
            is_draw = True
            r = 0
            if double_type and c != column:
                r = not c % 2 if double_type == sh.SHIFT else c % 2
                r = min(row - 1, r)
                is_draw = Shape.is_allocated_cell(grid, r, c)
            if is_draw:
                if c == column:
                    x += a.w

                else:
                    a = grid.get_cell_rect(r, c)
                    x = a.x
                if 0 < x < w:
                    m = True
                    Sel.rect(j, x, y, w1, h1)
        if m:
            Sel.fill(z, fy.GRID_COLOR)

    def _draw_cell_image_name(self, one):
        """
        Draw the image name over a cell image.

        one: One
            Has a Place dict.
        """
        if self.plan_flags[ak.NAME]:
            j = Hat.cat.render.image
            grid = one.grid
            row, column = grid.division
            group = None
            for r in range(row):
                for c in range(column):
                    if Shape.is_allocated_cell(grid, r, c):
                        n = grid.get_image_name(r, c)
                        if n:
                            if not group:
                                group = Lay.group(
                                    j,
                                    "Image Name",
                                    parent=self.model_group
                                )
                            draw_name(
                                group,
                                n,
                                grid.get_merge_cell_rect(r, c)
                            )
            if group:
                z = Lay.merge_group(group)

                if one.path in self.undo:
                    q, p = self.undo[one.path]
                    z1, d, e = q
                    self.undo[one.path] = ((z, z1), d, e), p
                else:
                    self.undo[one.path] = z, Lay.remove

    def _draw_custom_cell_image_name(self, one):
        """
        Draw the image name over a cell image.

        one: One
            Has a Place dict.
        """
        if self.plan_flags[ak.NAME]:
            n = self.cell.image_name
            if n:
                z = draw_name(self.model_group, n, self.cell.rect)
                z.name = "Image Name"

                if one.path in self.undo:
                    q, p = self.undo[one.path]
                    z1, d, e = q
                    self.undo[one.path] = ((z, z1), d, e), p
                else:
                    self.undo[one.path] = z, Lay.remove

    def _draw_layer_margins(self, _):
        """
        Draw the layer margins.

        _: One
            not used

        Return: layer or None
            with layer margins
        """
        cat = Hat.cat
        j = cat.render.image
        z = None
        s = cat.render.size
        q = top, bottom, left, right = self.layer_margin

        pdb.gimp_selection_none(j)

        if any(q):
            for x, i in enumerate(q):
                if i:
                    if x in (fm.TOP, fm.BOTTOM):
                        # top, bottom:
                        x1 = left
                        w = s[0] - left - right

                        if x == fm.TOP:
                            y = 0
                            h = top
                        else:
                            h = bottom
                            y = s[1] - h

                    else:
                        # left, right:
                        h = s[1] - top - bottom
                        y = top

                        if x == fm.LEFT:
                            x1 = 0
                            w = left
                        else:
                            w = right
                            x1 = s[0] - w
                    Sel.rect(j, x1, y, w, h)

            z = Lay.add(j, "Layer Margin", parent=self.model_group)
            z.opacity = 66.
            Sel.fill(z, fy.LAYER_MARGIN_COLOR)
        return z

    def _rename_group(self, _):
        """
        Rename a model folder with a 'Plan' extension.

        _: One
            not used
        """
        z = self.model_group
        z.name = self.model_name + " Plan"
        pdb.gimp_image_reorder_item(z.image, z, self.plan_group, 0)

    def _undo_grid(self, a):
        """
        Undo a grid operation.
        """
        self.grid, z = a
        Lay.remove(z)

    def _undo_layer_margins(self, q):
        """
        Undo a layer margins operation.

        q: tuple
            (layer margin list, layer of layer margin)
        """
        self.layer_margin, z = q
        Lay.remove(z)

    def _update_previous_steps(self, steps):
        """
        Update previous steps for another plan.
        The previous steps are screened.
        These steps go to the undo stage.

        steps: list
            for the next render
        """
        # Set the change status:
        e = Hat.cat.group_dict
        q = []
        is_change = False

        for i in self._previous_steps[::-1]:
            a = e[i]

            if not is_change and a.unseen:
                is_change = True

            if is_change:
                if a.group_key != CHANGE_STEP:
                    q += [i]
            else:
                if i not in steps:
                    if a.group_key != CHANGE_STEP:
                        q += [i]
        self._previous_steps = q[::-1]

    def delete(self):
        """Delete the plan folder."""
        Lay.remove(self.plan_group)
        self.plan_group = None

    def delete_backdrop(self):
        """Delete the backdrop layer. This is closing procedure."""
        Lay.remove(self.backdrop_layer)

    def do(self, steps, undo):
        """
        Perform a preview.

        steps: list
            A step is based on an option group.
            Are preview or final steps.

        undo: list
            of steps to undo
        """
        cat = Hat.cat
        d = cat.group_dict
        e = self.non_layer_d
        e1 = self.layer_d
        e2 = self._extra_op_d
        is_start = True

        self.show()
        self.undo_steps(undo, steps)

        for step in steps:
            j = cat.render.image
            k = d[step].group_key
            one = One(
                cell=self.cell,
                d=Path.get_dict_from_path(step),
                grid=self.grid,
                image_index=self.image_index,
                k=k,
                model_name=self.model_name,
                parent=self.model_group,
                path=step,
                render_type=self.render_type
            )

            pdb.gimp_selection_none(j)

            if is_start:
                z = self.plan_group
                if z:
                    z.name = z.name.split(":")[0] + WORK
                    is_start = False

            if k in e:
                e[k](one)

            elif k in e1:
                one.layer_margin = self.layer_margin
                e1[k](one)
            if k in e2:
                e2[k](one)

        z = self.plan_group
        j = cat.render.image

        if z:
            z.name = z.name.split(":")[0] + READY
            Sel.item(z)
            j.active_layer = z

        elif self.backdrop_layer:
            j.active_layer = self.backdrop_layer
            Sel.item(self.backdrop_layer)

        else:
            pdb.gimp_selection_none(j)

        pdb.gimp_displays_flush()
        cat.del_short_term_sel()

    def hide(self):
        """Hide the plan group."""
        if self.plan_group:
            Lay.hide(self.plan_group)

    def get_offset(self):
        """
        Get the offset needed for Product groups.

        Return: int
            0 or 1
        """
        return 1 if self.plan_group else 0

    def prep(self, q):
        """
        Call to do a render plan.

        q: list
            plan steps

        is_preview: bool
            unused
        """
        self._update_previous_steps(q)

        q1 = q[:]

        # Update before the render:
        q = update_unseen_flag(q)

        q2 = self._previous_steps[:]

        # Reverse the order of the list.
        # Undo is the reverse of the render:
        self._previous_steps = q1[::-1]

        # Create the image:
        self.do(q, q2)

    def reset(self):
        """Reset any variables belonging to the render."""
        self.plan_group = self.model_group = self.model_name = None
        self.cell = self.grid = self.backdrop_layer = None
        self.layer_margin = []
        self.image_index = deepcopy(Place.IMAGE_INDEX)
        self.context = ""
        self.undo = {}

    def show(self):
        """Show the plan group."""
        if self.plan_group:
            Lay.show(self.plan_group)
