#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class ColorFill:
    """Fill the backdrop with a color."""

    @staticmethod
    def do(one):
        """
        Do the Color Fill backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with Color Fill
        """
        d = one.d
        if d[ok.OPACITY]:
            z = Lay.clone(one.z)
            q = d[ok.COLOR]
            a = RenderHub.invert_color(q) if d[ok.INVERT] else q
            s = Hat.cat.render.size
            x, y = RenderHub.get_layer_points(d, s[0], s[1])[:2]

            # Preserve:
            foreground = pdb.gimp_context_get_foreground()

            RenderHub.set_fill_context(d)
            pdb.gimp_context_set_foreground(a)
            pdb.gimp_drawable_edit_bucket_fill(z, fu.FOREGROUND_FILL, x, y)

            # Restore:
            pdb.gimp_context_set_foreground(foreground)
            return RenderHub.bump(z, d[ok.BUMP])
