#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_style_color_grid import ColorGrid
from roller_backdrop_style_gradient_fill import GradientFill
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat
from roller_one import One
from roller_one_fu import Lay
from roller_option_preset import Preset
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


def do_1st_layer(d, e, d1, group):
    """Create a diamond-slat layer and a shadow."""
    cat = Hat.cat
    j = cat.render.image
    z = Lay.add(j, "1st Layer", parent=group)
    d[ok.ROW] = 1
    d[ok.COLUMN] = d1[ok.COLUMN_1]
    d[ok.COLOR_1] = (255, 255, 255)
    d[ok.COLOR_2] = (0, 0, 0)
    d[ok.MODE] = "Normal"
    d[ok.OPACITY] = 100
    d[ok.ROTATE] = 45
    z = ColorGrid.do(One(d=d, k="1st Layer", z=z))

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    RenderHub.do_stylish_shadow(z)
    Lay.create_mask(z)

    e[ok.START_X] = e[ok.START_Y] = 0.
    e[ok.END_X] = e[ok.END_Y] = 1.
    do_gradient(e, z)


def do_2nd_layer(d, e, d1, group):
    """Process the second layer."""
    j = Hat.cat.render.image
    z = Lay.add(j, "2nd Layer", parent=group)
    d[ok.COLOR_1] = 0, 0, 0
    d[ok.COLOR_2] = 255, 255, 255
    d[ok.COLUMN] = d1[ok.COLUMN_2]
    z = ColorGrid.do(One(d=d, k="Grate", z=z))

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    RenderHub.do_stylish_shadow(z)
    Lay.create_mask(z)

    e[ok.END_X] = e[ok.END_Y] = 0.
    e[ok.START_X] = e[ok.START_Y] = 1.
    return do_gradient(e, z)


def do_3rd_layer(z):
    """
    Process the third layer.

    z: layer
        work-in-progress
    """
    z = Lay.clone(z)

    Lay.flip(z, horizontal=1)
    RenderHub.do_stylish_shadow(z)
    Lay.create_mask(z)


def do_gradient(d, z):
    """
    Draw a gradient.

    z: layer
        to receive the gradient
    """
    j = Hat.cat.render.image
    z1 = GradientFill.do_layer(One(d=d))

    Lay.transfer_mask(z1, z)
    pdb.gimp_image_reorder_item(j, z1, z.parent, 0)
    return pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)


class MysteryGrate:
    """Has grate-like layers."""

    @staticmethod
    def do(one):
        """
        Create a Mystery Grate backdrop-style.

        one: One
            Has variables.

        Return: layer
            Has Mystery Grate
        """
        j = Hat.cat.render.image
        e = Preset.get_default(by.GRADIENT_FILL)

        e.update(one.d)

        d1 = one.d
        d2 = Preset.get_default(by.COLOR_GRID)
        d2[ok.ROTATE] = 45.
        group = Lay.group(j, one.k)
        z = GradientFill.do_layer(One(d=e))

        pdb.gimp_image_reorder_item(j, z, group, 0)
        do_1st_layer(d2, e, d1, group)

        z1 = do_2nd_layer(d2, e, d1, group)

        do_3rd_layer(z1)

        e[ok.START_X] = e[ok.END_Y] = 1.
        e[ok.END_X] = e[ok.START_Y] = 0.
        return Lay.merge_group(group)
