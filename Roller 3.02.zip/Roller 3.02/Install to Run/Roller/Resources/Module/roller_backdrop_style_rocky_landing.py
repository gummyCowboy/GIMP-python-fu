#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


def do_edge(z, mode):
    """
    Shred the layer with the edge function and a layer mode.

    z: layer
        work-in-progress
        Is modified.

    mode: enum
        layer mode

    Return: layer
        with modifications
    """
    j = z.image

    pdb.plug_in_edge(j, z, 1., 0, 0)

    z.mode = mode
    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
    return Lay.clone(z)


class RockyLanding:
    """Create a rock-like backdrop-style."""

    @staticmethod
    def do(one):
        """
        Create a Rocky Landing backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with Rocky Landing
        """
        j = Hat.cat.render.image
        d = one.d
        if d[ok.OPACITY]:
            z = Lay.clone(one.z)
            group = Lay.group(j, one.k)

            pdb.gimp_image_reorder_item(j, z, group, 0)
            pdb.plug_in_plasma(j, z, d[ok.RANDOM_SEED], 3)

            z1 = Lay.clone(z)

            Lay.color_fill(z, (0, 0, 0))

            z = Lay.clone(z1)
            z = do_edge(z, fu.LAYER_MODE_SUBTRACT)
            z = do_edge(z, fu.LAYER_MODE_LCH_HUE)

            for _ in range(d[ok.BLEND]):
                z = do_edge(z, fu.LAYER_MODE_COLOR_ERASE)
                z = do_edge(z, fu.LAYER_MODE_LCH_CHROMA)

            z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
            z1 = Lay.clone(z)

            pdb.plug_in_emboss(j, z1, Hat.cat.light_angle, 30., 1, 1)

            z1.mode = fu.LAYER_MODE_OVERLAY

            pdb.gimp_drawable_invert(z1, 0)

            z = Lay.clone(z1)

            pdb.plug_in_despeckle(j, z1, 1, 1, 200, 255)
            pdb.gimp_layer_set_offsets(z, 0, 2)
            pdb.plug_in_sobel(j, z, 1, 0, 0)

            z.opacity = 83.
            z1.mode = fu.LAYER_MODE_NORMAL
            z1.opacity = 33.

            pdb.gimp_image_reorder_item(j, z1, group, 3)
            z = Lay.merge_group(group)
            z.mode, z.opacity = RenderHub.get_mode(d)

            Lay.clone(one.z)
            return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
