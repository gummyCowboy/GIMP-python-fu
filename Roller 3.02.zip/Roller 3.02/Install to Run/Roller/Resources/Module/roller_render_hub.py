#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from random import choice, randint, uniform
from roller_constant_for import (
    Bump as fb,
    Fill as fl,
    Frame as fo,
    Gradient as fg
)
from roller_constant_key import Effect as ek, Option as ok
from roller_constant_fu import Fu
from roller_one import Base, Comm, Hat, Mode
from roller_one_fu import Lay, Sel
import colorsys
import gimpfu as fu
import math

em = Fu.Emboss
pdb = fu.pdb
rn = Fu.RGBNoise
sn = Fu.SolidNoise
um = Fu.UnsharpMask

CENTER_X_0 = CENTER_Y_0 = 0
ONE_PIXEL = 1.
SAME_XY = ZERO_ANGLE = 0.
SHADOW_LAYER = ek.SHADOW_2, ek.SHADOW_1
YES_AUTO_CENTER = 1


class RenderHub:
    """
    Use with image-effect and backdrop-style options.

    Many thanks to Ofnuts for some of the source code which can be found at:
    sourceforge.net/projects/gimp-tools/s
    """

    @staticmethod
    def add_noise(z, d):
        """
        Create noise.

        z: layer
            to receive noise

        d: dict
            Has options.
        """
        go = True
        j = z.image

        if ok.NOISE_OPACITY in d:
            if not d[ok.NOISE_OPACITY]:
                go = False
        if go:
            # Generate source of lines.
            # The horizontal and vertical sizes are randomized:
            pdb.plug_in_solid_noise(
                j, z,
                sn.NO_TILEABLE,
                sn.YES_TURBULENT,
                d[ok.RANDOM_SEED],
                d[ok.DETAIL_LEVEL],
                float(randint(1, 3)),
                float(randint(1, 3)),
            )

            # Harden the noise.
            # The radius is randomized:
            pdb.plug_in_unsharp_mask(
                j, z,
                choice((1., 3.)),
                um.AMOUNT_54,
                um.THRESHOLD_0
            )

            # Remove the white noise:
            Sel.item(z)
            Sel.invert_clear(z)
            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
            # Feather softens the noise:
            if d[ok.SOFTNESS]:
                Sel.item(z)
                pdb.gimp_selection_feather(j, d[ok.SOFTNESS])
                Sel.invert(j)
                Lay.clear_sel(z)
                Lay.blur(z, d[ok.SOFTNESS] / 100.)

    @staticmethod
    def adjust_mean_value(z):
        """
        Adjust a layer's material so that it's mean
        intensity is within a theoretical bounds.

        z: layer
            work-in-progress
        """
        def histogram():
            """
            Determine the mean intensity.

            Return: float
                the mean intensity
            """
            return pdb.gimp_drawable_histogram(
                z,
                fu.HISTOGRAM_VALUE,
                .0,
                1.
            )[0]

        def curves():
            """
            Adjust the layer's middle range using the 'ratio'
            of the theoretical mean and the actual mean.
            """
            pdb.gimp_drawable_curves_spline(
                z,
                fu.HISTOGRAM_VALUE,
                8,
                (.0, .0, .3, .3 * ratio, .7, .7 * ratio, 1., 1.)
            )

        mean = histogram()

        # If the layer is only black pixels, the mean will be zero:
        if mean:
            # Consider 3 classes of intensity:
            if mean < 85:
                # theoretical 100:
                theory = (128 + mean) / 2

            elif mean > 170:
                # theoretical 155:
                theory = (127 + mean) / 2

            else:
                # regular:
                theory = 127.5

            mean_min = theory - 16
            mean_max = theory + 16

            # Adjust for minimum mean:
            if mean_min > mean != theory:
                ratio = theory / mean
                for i in range(10):
                    curves()
                    mean = histogram()
                    if mean >= mean_min:
                        break
            # Adjust for maximum mean:
            if mean_max < mean != theory:
                ratio = theory / mean
                for i in range(10):
                    curves()
                    mean = histogram()
                    if mean <= mean_max:
                        break

    @staticmethod
    def blur_behind(z, d, is_merge=True, has_mode=False):
        """
        Blur behind a layer and merge the blur with the layer.

        z: layer
            with material

        d: dict
            Has the blur behind option.

        is_merge: bool
            When true, the blur behind material
            is merged with the original material.

        has_mode: bool
            When true, the material layer's mode
            is set from the options dict.

        Return: layer or None
            image layer with or without blur behind
        """
        z1 = None
        blur = d[ok.BLUR_BEHIND]

        if z and blur:
            cat = Hat.cat
            j = cat.render.image
            z1 = Lay.clone_background(z)
            z2 = Lay.clone_opaque(z, True)

            Sel.make_layer_sel(z2)

            if Sel.is_sel(j):
                Lay.blur(z1, blur)
                Sel.invert_clear(z1)
                if is_merge:
                    if has_mode:
                        z.mode = Mode.get_(d)
                    z1 = Lay.merge(z)

            else:
                pdb.gimp_image_remove_layer(j, z1)
            pdb.gimp_image_remove_layer(j, z2)
        return z1

    @staticmethod
    def blur_behind_frame(z, blur):
        """
        Blur behind a translucent frame.

        z: layer
            to blur behind

        blur: int
            blur behind amount

        Return: layer or None
            with blur behind material
        """
        j = Hat.cat.render.image
        if z and blur:
            z1 = Lay.clone_background(z)

            # If there's only transparency, then the blur-behind is pointless:
            if Lay.has_pixel(z1):
                z2 = Lay.clone_opaque(z, True)

                Lay.blur(z1, blur)
                Sel.item(z2)
                Sel.invert_clear(z1)
                pdb.gimp_image_remove_layer(j, z2)

            else:
                pdb.gimp_image_remove_layer(j, z1)
                z1 = None
            return z1

    @staticmethod
    def brush_stroke(z, q, f, p):
        """
        Make a brush stroke.

        z: layer
            to receive brush stroke

        q: list
            of points

        f: float
            of brush

        p: function or None
            a callback for each stroke
        """
        if p and p[0]:
            p[0](p[1])

        pdb.gimp_context_set_brush_angle(f)
        pdb.gimp_paintbrush_default(z, 2, q)

    @staticmethod
    def brush_stroke_on_stroke(
        z,
        brush,
        brush_size,
        stroke,
        spacing,
        callback=None,
        hardness=1.,
        angle=0.,
        angle_flux=0.,
        opacity_flux=0.
    ):
        """
        Brush stroke the path.

        z: layer
            to receive brush stroke
            Has a stroke-path.

        brush: string
            GIMP brush

        brush_size: float
            size of brush

        stroke: GIMP path
            to receive brush

        spacing: numeric
            distance between the strokes

        callback: tuple
            function, object
            a callback for each brush stroke and its argument
        """
        def set_hardness():
            pdb.gimp_context_set_brush_force(
                Base.seal(
                    hardness + uniform(-opacity_flux, opacity_flux) / 100.,
                    .01,
                    1.
                )
            )

        length = stroke.get_length(.1)
        points, closed = stroke.points
        intervals = round((length / spacing))
        if intervals:
            interval_length = length / intervals

            pdb.gimp_context_set_brush_hardness(1.)
            pdb.gimp_context_set_brush(brush)
            pdb.gimp_context_set_brush_size(brush_size)
            pdb.gimp_context_set_brush_aspect_ratio(0.)
            pdb.gimp_context_set_dynamics("Pencil Generic")
            pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
            pdb.gimp_context_set_antialias(1)
            set_hardness()

            # first point:
            RenderHub.brush_stroke(
                z,
                points[2:4],
                RenderHub.calc_stroke_angle(
                    points[2:4],
                    RenderHub.get_origin_tangent(stroke),
                    angle
                ),
                callback
            )

            # special case for first and last:
            for step in range(1, int(intervals)):
                x1, y1 = stroke.get_point_at_dist(
                    step * interval_length,
                    .1
                )[0:2]
                x2, y2 = stroke.get_point_at_dist(
                    .5 + step * interval_length,
                    .1
                )[0:2]

                set_hardness()
                RenderHub.brush_stroke(
                    z,
                    (x1, y1),
                    RenderHub.calc_stroke_angle(
                        (x1, y1),
                        (x2, y2),
                        angle + uniform(-angle_flux, angle_flux)
                    ),
                    callback
                )
            # last point:
            if not closed:
                set_hardness()
                RenderHub.brush_stroke(
                    z,
                    points[-4:-2],
                    RenderHub.calc_stroke_angle(
                        RenderHub.get_end_tangent(stroke),
                        points[-4:-2],
                        angle + uniform(-angle_flux, angle_flux)
                    ),
                    callback
                )

    @staticmethod
    def bump(z, d, keep_sel=False):
        """
        Add bump to a layer.

        z: layer
            work-in-progress

        d: dict
            of bump

        keep_sel: flag
            Has save selection function.
            When set, the selection is restored.

        Return: layer or None
            Return merged layer if merge.
        """
        if d[ok.BUMP_TYPE] in fb.HAS_BUMP:
            j = z.image
            cat = Hat.cat

            if keep_sel:
                sel = cat.save_short_term_sel()

            z = Lay.clone(z)
            z.opacity = 100.

            z.mode = fu.LAYER_MODE_OVERLAY
            f = d[ok.NOISE]

            if d[ok.BUMP_TYPE] == fb.NOISE:
                if f:
                    # Set red, green, blue noise with 'f':
                    pdb.plug_in_rgb_noise(
                        j, z,
                        rn.YES_INDEPENDENT,
                        rn.NO_CORRELATED,
                        f,
                        f,
                        f,
                        rn.NOISE_ZERO
                    )
            else:
                pdb.script_fu_clothify(
                    j, z,
                    d[ok.BLUR_X],
                    d[ok.BLUR_Y],
                    cat.light_angle,
                    max(min(cat.elevation, 90.), 1.),
                    min(d[ok.BUMP_DEPTH], 50.)
                )

            pdb.plug_in_emboss(
                j, z,
                cat.light_angle,
                cat.elevation,
                d[ok.BUMP_DEPTH],
                em.EMBOSS
            )

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            if keep_sel:
                Sel.load(j, sel)
        return z

    @staticmethod
    def calc_bevel_profile(w, *_):
        """
        Calculate a 45 degree beveled profile.

        w: int
            width of the bevel

        Return: list
            the profile
            in .0 to 1.
        """
        # 'q' is for the y-axis values.
        # The y value can be later be used to adjust a
        # color's lightness, value, or other property:
        q = []

        # f is the value to increment x.
        # '2.' is the range of x from -1 to 1.
        # '.5' is the y mid-point:
        f = 1. if w == 1 else 2. / w
        x = f / 2.

        for i in range(w):
            if x < 1.:
                q += [x]

            else:
                q += [1. - (x - 1.)]
            x += f
        return q

    @staticmethod
    def calc_gradient(color, color1, steps):
        """
        Return the color-steps for a gradient.

        A color-step is a value that is added to one color's
        components in order for the color to become the second color.
        Each color component will have its own color-step.

        color, color1: tuple
            RGB
            of int

        steps: int
            the number of steps
        """
        delta = [0, 0, 0]
        step = [0, 0, 0]

        # Need the color distance to calculate a color step:
        if steps > 1:
            for x in range(3):
                delta[x] = abs(color[x] - color1[x]) / 1. / (steps - 1)
            # The color step can be positive or negative:
            for x in range(3):
                if color[x] > color1[x]:
                    step[x] = -delta[x]
                elif color[x] < color1[x]:
                    step[x] = delta[x]
        return step

    @staticmethod
    def calc_raise_profile(w, *_):
        """
        Calculate a raise profile.

        w: int
            width of profile or frame

        Return: list
            of profile
            in .0 to 1.
        """
        q = []
        f = 1. / w
        x = 1. - f / 2.

        for i in range(w):
            q += [x]
            x -= f
        return q

    @staticmethod
    def calc_round_profile(w, *_):
        """
        Calculate a rounded profile using
        the unit circle formula and given
        the width of the profile.

        w: int
            width of profile or frame

        Return: list
            of profile
            in .0 to 1.
        """
        # 'q' is for the y-axis values.
        # The y value can be later be used to adjust a
        # color's lightness, value, or other property:
        q = []

        # f is the value to increment x.
        # '2.' is the range of x from -1 to 1.
        # 'w + 5.' produces the mid-point on the y-axis, '.5':
        f = 2. / (w + 5.) if w == 1 else 2. / w

        # 'x' is given a mid-value between the zero increment and the first:
        x = -1. + f / 2.

        for i in range(w):
            q += [math.sqrt(1. - x**2)]
            x += f
        return q

    @staticmethod
    def calc_sink_profile(w, *_):
        """
        Calculate a rise profile.

        w: int
            width of profile or frame

        Return: list
            of profile
            in .0 to 1.
        """
        q = []
        f = 1. / w
        x = f / 2.

        for i in range(w):
            q += [x]
            x += f
        return q

    @staticmethod
    def calc_stroke_angle(p1, p2, f):
        """
        Calculate the angle of the brush given the
        base angle and a point with a tangent.

        p1, p2: points
            Form a tangent.

        f: float
            of brush
            base angle
        """
        x, y = p1
        x1, y1 = p2
        return ((f + math.degrees(math.atan2(y - y1, x - x1))) % 360.) - 180.

    @staticmethod
    def contract_image(j):
        """
        Reverse the image expansion provided by 'expand_image'.

        j: GIMP image
            work-in-progress
        """
        pdb.gimp_image_resize(j, j.width - 200, j.height - 200, -100, -100)

    @staticmethod
    def do_cartoony(z, z1, color):
        """
        Create a cartoony color frame for gradient frames.

        z: layer
            Has frame.

        z1: layer
            Has noise.

        color: tuple
            RGB
            to colorize noise

        Return: layer
            with effect
        """
        j = z.image
        group = Lay.group(j, z.name, parent=z.parent)

        pdb.gimp_image_reorder_item(j, z, group, 0)
        pdb.gimp_image_reorder_item(j, z1, group, 0)

        opacity = z1.opacity
        z = Lay.clone(z)
        z.mode = fu.LAYER_MODE_HSV_VALUE

        pdb.gimp_image_reorder_item(j, z, group, 0)

        z1 = Lay.clone(z1)
        z1.mode = fu.LAYER_MODE_LCH_COLOR
        z1.opacity = opacity

        pdb.plug_in_colorify(j, z1, color)
        return Lay.merge_group(group)

    @staticmethod
    def do_rotated_layer(z, d, p):
        """
        Create an enlarged layer before rotating.

        Use a callback to process the rotated layer.

        z: layer
            Is the layer that gets rotated and processed.

        d: dict
            Has options.

        p: callback
            Call to act on the rotated layer before it is returned.

        Return: layer
            the rotated layer
        """
        cat = Hat.cat
        d = deepcopy(d)
        z1 = z
        j = cat.render.image
        w, h = cat.render.size

        if d[ok.ROTATE]:
            # Create a new image for the rotation:
            f = Base.circumradius(w, h) * 2
            j = pdb.gimp_image_new(f, f, fu.RGB)
            z = Lay.add(j, "Rotate")

        z = p(z, d)

        if d[ok.ROTATE]:
            pdb.gimp_selection_all(j)
            pdb.gimp_item_transform_rotate(
                z,
                math.radians(d[ok.ROTATE]),
                YES_AUTO_CENTER,
                CENTER_X_0,
                CENTER_Y_0,
            )

            # Copy and paste the rotated gradient:
            Sel.rect(
                j,
                j.width // 2 - w // 2, j.height // 2 - h // 2,
                w, h,
                option=fu.CHANNEL_OP_REPLACE
            )

            pdb.gimp_edit_copy_visible(j)
            pdb.gimp_image_delete(j)

            j = cat.render.image
            z = Lay.paste(z1)
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

        pdb.gimp_layer_resize_to_image_size(z)
        return z

    @staticmethod
    def do_shadow(
        z,
        x, y,
        blur,
        color,
        intensity,
        is_opaque=True,
        is_inner=False
    ):
        """
        Draw a drop shadow.

        Create a number of layers, group them, merge them,
        and then cast a shadow from the merged layer.

        If the shadow is an inlay shadow,
        create a layer to cast a shadow over the image.

        z: layer
            layer that casts shadow

        x: float
            offset x

        y: float
            offset y

        blur: float
            shadow blur

        color: tuple
            of int
            (R, G, B)
            shadow color

        intensity: int
            intensity

        is_opaque: flag
            When true, the shadow source is made opaque.

        is_inner: flag
            if true, the selection is inverted.

        Return: layer
            the new shadow layer
        """
        j = Hat.cat.render.image
        if intensity:
            group = Lay.group(j, "Shadow")

            # 'opaque' is a layer with an optional 100% opaqueness:
            opaque = Lay.clone_opaque(z, is_opaque) if is_opaque else \
                Lay.clone(z)

            pdb.gimp_image_reorder_item(j, opaque, group, 0)

            if is_inner:
                RenderHub.expand_image(j)

                z1 = Lay.add(j, "Inlay", parent=group)

                Lay.color_fill(z1, (255, 255, 255))
                Sel.item(opaque)
                Lay.clear_sel(z1)
                pdb.gimp_image_remove_layer(j, opaque)
                opaque = z1

            Sel.item(opaque)

            if not Sel.is_sel(j):
                intensity = 0

            if intensity:
                layer_count = int(intensity / 100.) + 1
                intensity /= layer_count

                pdb.script_fu_drop_shadow(
                    j, opaque,
                    x, y,
                    blur,
                    color,
                    intensity,
                    Fu.DropShadow.NO_RESIZING
                )

                # Increase shadow intensity by
                # stacking duplicate shadow layers:
                z = group.layers[0]
                for i in range(int(layer_count) - 1):
                    z = Lay.clone(z)

            if is_inner:
                Sel.item(opaque)

            pdb.gimp_image_remove_layer(j, opaque)

            z = Lay.merge_group(group)

            if is_inner:
                Lay.clear_sel(z)
                RenderHub.contract_image(j)

            pdb.gimp_layer_resize_to_image_size(z)
            return z

    @staticmethod
    def do_stylish_shadow(
        z,
        blur=15.,
        intensity=130.,
        offset_x=0,
        offset_y=0,
        is_opaque=True,
        is_inner=False
    ):
        """
        z: layer
            to cast shadow

        blur: float
            shadow blur

        intensity: float
            shadow opacity

        offset_x: int
            shadow offset on x-axis (-, +)

        offset_y: int
            shadow offset on y-axis (-, +)

        is_opaque: flag
            If true, the shadow source is made opaque.

        is_inner: flag
            If true, the shadow is an inlay type.

        Return: layer
            the shadow layer
        """
        parent = z.parent
        j = Hat.cat.render.image
        x = Lay.offset(z)
        z = RenderHub.do_shadow(
            z,
            offset_x, offset_y,
            blur,
            (0, 0, 0),
            intensity,
            is_opaque=is_opaque,
            is_inner=is_inner
        )
        z.mode = fu.LAYER_MODE_NORMAL

        if is_inner:
            x -= 1

        pdb.gimp_image_reorder_item(j, z, parent, x + 1)
        return z

    @staticmethod
    def draw_color_profile(z, w, q, q1):
        """
        Draw a color-gradient frame using a profile.

        z: layer
            for blur material

        w: int
            width of border

        q: list
            of profile
            in .0 to 1.

        q1: tuple
            RGB
            of int
        """
        j = z.image

        if len(q) == 1:
            a = Hat.cat.save_short_term_sel()

            Sel.grow(j, w, 1)
            Sel.fill(z, q1)
            Sel.load(j, a)
            Lay.clear_sel(z)
        else:
            # HSV:
            q1 = RenderHub.rgb_to_hsv(q1)

            # selections:
            a = b = None

            for i in range(w):
                if a:
                    # Do now to save memory for large frames:
                    pdb.gimp_image_remove_channel(j, a)

                a = b = pdb.gimp_selection_save(j)
                if b:
                    Sel.grow(j, 1, 0)
                    Sel.load(j, b, option=fu.CHANNEL_OP_SUBTRACT)
                    Sel.fill(z, RenderHub.hsv_to_rgb((q1[0], q1[1], q[i])))
                    Sel.load(j, b, option=fu.CHANNEL_OP_ADD)
            if b:
                pdb.gimp_image_remove_channel(j, b)

    @staticmethod
    def draw_color_rectangles(z, w, h):
        """
        Draws two layer of colors stripes in order to create color rectangles.

        z: layer
            layer to draw on

        w: int
            width of rectangle

        h: int
            height of rectangle

        Return: layer
            Has color grid.
        """
        # vertical panes:
        j = z.image
        x = y = x1 = y1 = 0
        w1, h1 = j.width, j.height
        z.mode, z.opacity = fu.LAYER_MODE_NORMAL, 100.

        while x < w1:
            x1 = min(x1 + w, w1)

            Sel.rect(j, x, 0, x1 - x, h1, option=fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, Base.rnd_col())
            x = x1

        z = Lay.clone(z)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        # horizontal panes:
        while y < h1:
            y1 = min(y1 + h, h1)

            Sel.rect(j, 0, y, w1, y1 - y, option=fu.CHANNEL_OP_REPLACE)
            Sel.fill(z, Base.rnd_col())
            y = y1
        return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    @staticmethod
    def expand_image(j):
        """
        Enlarge the render by 200 pixels on both x and y vectors.

        Provides extra pixel space for feathering and inlay shadow.

        j: GIMP image
            work-in-progress
        """
        pdb.gimp_image_resize(j, j.width + 200, j.height + 200, 100, 100)

    @staticmethod
    def get_end_tangent(stroke):
        """
        Compute the position of the end-point for a tangent.

        stroke: path
            work-in-progress
        """
        points = stroke.points[0]

        # end point:
        x, y = points[-4:-2]

        # start point:
        x1, y1 = points[-6:-4]

        if abs(x - x1) < .0001 and abs(y - y1) < .0001:
            x1, y1 = stroke.get_point_at_dist(
                stroke.get_length(.001) - .5,
                .01
            )[0:2]
        return x1, y1

    @staticmethod
    def get_gradient_points(n, x, y, w, h):
        """
        Get the screen coordinates for a gradient.

        n: string
            gradient angle
            side to side

        x, y: numeric
            topleft coordinate

        w, h: numeric
            size of the gradient's space

        Return: tuple
            of float
            start x, end x, start y, end y
            in 0. to n
        """
        start_x, end_x, start_y, end_y = RenderHub.get_gradient_factors(n)
        start_x = x + start_x * w
        end_x = x + end_x * w
        start_y = y + start_y * h
        end_y = y + end_y * h
        return start_x, end_x, start_y, end_y

    @staticmethod
    def get_gradient_factors(n):
        """
        Get the factor points for a
        gradient given a gradient angle descriptor.

        n: string
            gradient angle
            side to side

        Return: tuple
            of float
            start x, end x, start y, end y
            in .0 to 1.
        """
        if n == fg.CENTER:
            start_x = .5
            end_x = .5
            start_y = .5
            end_y = .0

        elif n in fg.LEFT_X:
            start_x = .0
            end_x = 1.

        elif n in fg.CENTER_X:
            end_x = start_x = .5

        else:
            start_x = 1.
            end_x = .0

        if n == fg.CENTER:
            # Is already calculated from above:
            pass

        elif n in fg.TOP_Y:
            start_y = .0
            end_y = 1.

        elif n in fg.CENTER_Y:
            end_y = start_y = 1.

        else:
            start_y = 1.
            end_y = .0
        return start_x, end_x, start_y, end_y

    @staticmethod
    def get_layer_points(d, w, h):
        """
        Return the layer points for start and end coordinates.

        d: dict
            Has start and end points.
            factor layer points
            in .0 to 1.

        w, h: int
            size of render or canvas

        return:
            start and end coordinates
            x, y, x1, y1
        """
        x1 = y1 = -1
        x = int(round(d[ok.START_X], 6) * w)
        y = int(round(d[ok.START_Y], 6) * h)

        if ok.END_X in d:
            x1 = min(int(round(d[ok.END_X], 6) * w), w - 1)
            y1 = min(int(round(d[ok.END_Y], 6) * h), h - 1)
        return x, y, x1, y1

    @staticmethod
    def get_mode(d):
        """
        Return the mode and opacity in an option dict.

        d: dict
            Has options.
        """
        return Mode.get_(d), d[ok.OPACITY] / 1.

    @staticmethod
    def get_origin_tangent(stroke):
        """
        Compute the origin-point position of a tangent.

        stroke: path
            work-in-progress

        Return: tuple
            origin point
            x, y
        """
        points = stroke.points[0]

        # origin:
        x, y = points[2:4]

        # tangent:
        x1, y1 = points[4:6]

        if abs(x - x1) < .001 and abs(y - y1) < .001:
            x1, y1 = stroke.get_point_at_dist(.5, .01)[0:2]
        return x1, y1

    @staticmethod
    def get_point_on_rectangle(s, angle):
        """
        Calculate an x, y coordinate for a point intersecting
        a ray, originating from the center of a rectangle,
        and ending at its defining lines.

        s: tuple or list
            size
            width, height
            of int

        angle: float
            degrees
            angle from center of the rectangle

        Return: point
            x, y
            of float or int
            the point on the rectangle
        """
        w, h = s
        angle = math.radians(angle)
        sine = math.sin(angle)
        cosine = math.cos(angle)

        # distance to the top or the bottom edge (from the center):
        dy = h / 2 if sine > 0 else h / -2

        # distance to the left or the right edge (from the center):
        dx = w / 2 if cosine > 0 else w / -2

        # (distance to the vertical line) < (distance to the horizontal line):
        if abs(dx * sine) < abs(dy * cosine):
            # Calculate distance to the vertical line:
            dy = (dx * sine) / cosine

        # (distance to the top or the bottom edge)
        # < (distance to the left or the right edge):
        else:
            dx = (dy * cosine) / sine
        return max(0., round(dx + w / 2., 0)), max(0., round(dy + h / 2., 0))

    @staticmethod
    def hsv_to_rgb(q):
        """
        Convert HSV to RGB.

        q: iterable
            HSV
            in .0 to 1.

        return: tuple
            RGB
            in 0. to 255.
        """
        return tuple([int(round(i1 * 255)) for i1 in colorsys.hsv_to_rgb(*q)])

    @staticmethod
    def invert_color(q):
        """
        Generate an inverted color.

        q: tuple
            RGB

        Return: tuple
            RGB
            inverted color
        """
        return tuple([255 - i for i in q])

    @staticmethod
    def rgb_to_hsv(q):
        """
        Convert RGB to HSV.

        q: iterable
            of int
            RGB

        Return: tuple
            HSV
                float in .0 to 1.
                float in .0 to 1.
                float in 0. to 255.
        """
        return colorsys.rgb_to_hsv(*[(i / 255.) for i in q])

    @staticmethod
    def set_brush_details():
        """Set up the brush for drawing lines."""
        pdb.gimp_context_set_paint_mode(fu.LAYER_MODE_NORMAL)
        pdb.gimp_context_set_opacity(100.)

        try:
            pdb.gimp_context_set_brush("1. Pixel")

        except Exception:
            Comm.info_msg("Roller is unable to use the '1. Pixel' brush.")

        pdb.gimp_context_set_brush_size(ONE_PIXEL)
        pdb.gimp_context_set_brush_aspect_ratio(SAME_XY)
        pdb.gimp_context_set_brush_angle(ZERO_ANGLE)
        pdb.gimp_context_set_dynamics('Pencil Generic')
        pdb.gimp_context_set_brush_force(1.)
        pdb.gimp_context_set_stroke_method(fu.STROKE_PAINT_METHOD)
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_brush_hardness(.95)

    @staticmethod
    def set_fill_context(d):
        """
        Set the context for the current fill-type operation.

        Call before a bucket fill operation.

        d: dict
            Has options.
        """
        pdb.gimp_context_set_sample_threshold(d[ok.THRESHOLD])
        pdb.gimp_context_set_opacity(d[ok.OPACITY])
        pdb.gimp_context_set_paint_mode(Mode.get_(d))
        pdb.gimp_context_set_sample_criterion(
            fl.CRITERION_LIST.index(d[ok.CRITERION])
        )


PROFILE = {
    fo.BEVEL: RenderHub.calc_bevel_profile,
    fo.FLAT: lambda w, q: [q],
    fo.ROUND: RenderHub.calc_round_profile,
    fo.RAISE: RenderHub.calc_raise_profile,
    fo.SINK: RenderHub.calc_sink_profile
}
