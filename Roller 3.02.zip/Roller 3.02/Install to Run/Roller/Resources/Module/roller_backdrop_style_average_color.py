#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class AverageColor:
    """Use pixelize to create an approximate average color."""

    @staticmethod
    def do(one):
        """
        Do the Average Color backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            Is Average Color.
        """
        cat = Hat.cat
        j = cat.render.image
        d = one.d
        if Lay.has_pixel(one.z) and d[ok.OPACITY]:
            z = Lay.clone(one.z)
            z = Lay.clone(z)

            pdb.plug_in_pixelize2(j, z, *cat.render.size)

            if one.d[ok.INVERT]:
                pdb.gimp_drawable_invert(z, 0)

            z = RenderHub.bump(z, d[ok.BUMP])
            z.mode, z.opacity = RenderHub.get_mode(d)
            return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
