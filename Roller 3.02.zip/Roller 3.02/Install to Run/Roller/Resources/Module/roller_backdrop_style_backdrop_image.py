#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_model_image import Image
from roller_one import Hat
from roller_one_fu import Lay, Mage
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class BackdropImage:
    """Place an image on the backdrop layer."""

    @staticmethod
    def do(one, is_plan=False):
        """
        Do the Backdrop Image backdrop-style.

        one: One
            Has variables.

        is_plan: bool
            Is true when Plan is calling.
            Use to update image index.

        Return: layer
            Is backdrop.
        """
        d = one.d
        cat = Hat.cat
        j = cat.render.image
        w, h = size = cat.render.size
        z = None

        # Copy the backdrop image to the backdrop layer:
        j1 = Image.get_image(d[ok.IMAGE], one.image_index)

        if not is_plan:
            z = Lay.add(j, "", offset=cat.plan.get_offset())

        if j1 and not is_plan:
            j2 = j1.j

            Mage.copy_all(j2)

            if j1.size != size:
                if d[ok.FIT_IMAGE]:
                    # Resize the backdrop image to fit the backdrop layer:
                    Mage.shape(
                        pdb.gimp_edit_paste_as_new_image(),
                        w, h
                    )

            z1 = Lay.paste(z)

            if not d[ok.FIT_IMAGE]:
                pdb.gimp_layer_resize_to_image_size(z1)

            z = pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)

            if Lay.has_pixel(z):
                if d[ok.BACKDROP_IMAGE_BLUR]:
                    Lay.blur(z, d[ok.BACKDROP_IMAGE_BLUR])

                if d[ok.INVERT]:
                    pdb.gimp_drawable_invert(z, 0)
                z = RenderHub.bump(z, d[ok.BUMP])
            Image.close_image(j1)
        return z
