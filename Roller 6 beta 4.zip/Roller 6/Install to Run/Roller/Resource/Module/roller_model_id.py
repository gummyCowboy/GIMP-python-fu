#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import Id


class ModelId:
    """Use to lessen the impact of Model name change."""
    # {model id: model name}
    # {int: string}
    _model_id_d = {}

    @staticmethod
    def delete_with_id(id_):
        """
        Remove a Model id using a Model id key.

        id_: int
            Model id key
        """
        if id_ in ModelId._model_id_d:
            ModelId._model_id_d.pop(id_)

    @staticmethod
    def delete_with_name(n):
        """
        Remove a Model id using a Model name value.

        n: string
            Model name value (unique)
        """
        for k, a in ModelId._model_id_d.items():
            if a['name'] == n:
                ModelId._model_id_d.pop(k)
                break

    @staticmethod
    def get_id(n):
        """
        Get the Model id from a Model name.

        n: string
            item name

        Return: int or None
            id for the Model
        """
        for i, a in ModelId._model_id_d.items():
            if a['name'] == n:
                return i

    @staticmethod
    def get_model(a):
        """
        Fetch the Model given its identifier.

        a: value
            int or string
            If the value is an int, then the value is used as a Model id key.
            Otherwise, the value is a Model name and a search is done.

        Return: Model or None
        """
        d = ModelId._model_id_d

        if isinstance(a, int):
            if a in d:
                return d[a]['model']
        else:
            for i, b in d.items():
                if b['name'] == a:
                    return b['model']

    @staticmethod
    def get_name(a):
        """
        Get the name from an Model id.

        a: int
            Model id

        Return: string or None
            Model name
            Is None if the id is not found.
        """
        if a in ModelId._model_id_d:
            return ModelId._model_id_d[a]['name']

    @staticmethod
    def make_id(n, model):
        """
        Assign an id to an item name.

        n: string
            Model name

        model: Model
            Add to ModelId.

        Return: int
            Model id
        """
        a = Id.make()
        ModelId._model_id_d[a] = {'name': n, 'model': model}
        return a

    @staticmethod
    def rename(old_name, new_name):
        """
        Rename a Model.

        old_name: string
            previous Model name

        new_name: string
            new Model name
        """
        d = ModelId._model_id_d
        for k in d:
            if d[k]['name'] == old_name:
                d[k]['name'] = new_name
                break
