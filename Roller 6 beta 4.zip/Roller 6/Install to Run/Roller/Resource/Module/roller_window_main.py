#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb  # type: ignore
from roller_a_contain import Gradient, Path, Run, The
from roller_a_oz import ensure_dir, make_preset_path, pickle_dump, pickle_load
from roller_constant_key import Widget as wk
from roller_fu import (
    collect_group,
    collect_non_group,
    load_selection,
    remove_z,
    validate_item
)
from roller_fu_comm import show_err
from roller_image_pic import Pic, image_undo_end, image_undo_start
from roller_one_ring import Ring
from roller_one_wip import Wip
from roller_port_main import PortMain
from roller_window import Window
import gobject       # type: ignore
import gtk           # type: ignore

CRITICAL = "Roller closed itself due to a critical error: "
TITLE = "Roller 6"


def collapse_tree(j):
    """
    Move grouped layers to the Layers trunk.

    j: GIMP image
        Is render.
    """
    # a top-down ordered list of drawable in the Render, z_q.
    z_q = []

    collect_non_group(j, z_q)
    for z in reversed(z_q):
        if not z.visible:
            pdb.gimp_image_remove_layer(j, z)

        elif not z.opacity:
            pdb.gimp_image_remove_layer(j, z)
        else:
            if z.parent and len(z.parent.layers) == 1:
                # Fix a Pass-through layer problem
                # when there is only one layer in the group.
                # Reference
                # 'www.gimp-forum.net/Thread-Why-is-the-Pass-through'
                # '-layer-mode-changing-this-image'
                mode, name = z.mode, z.name
                z = pdb.gimp_image_merge_layer_group(j, z.parent)
                z.mode, z.name = mode, name
            pdb.gimp_image_reorder_item(j, z, None, 0)


def remove_group(j):
    """
    Remove any group layers without any children.

    j: GIMP image
        Is render.
    """
    # list of group layers from the top-down, 'group_q'
    group_q = []

    collect_group(j, group_q)

    # Remove empty groups from the bottom-up.
    [remove_z(z) for z in reversed(group_q)]


def resize_layers(z):
    """
    Resize the layers to the image size.

    z: GIMP image or layer
        Has sub-layers.
    """
    # list of group layers from the top-down, 'group_q'
    # Remove invisible layer.
    for i in z.layers:
        pdb.gimp_layer_resize_to_image_size(i)
        if pdb.gimp_item_is_group(i):
            resize_layers(i)


def verify_preset_folder():
    """
    Roller requires a Preset folder to store Preset.

    Return: bool
        It is True if the directory is verified.
    """
    go = False

    try:
        go = ensure_dir(Path.preset)[-1]

    except Exception as ex:
        show_err(ex)
        show_err("The operating system isn't compatible with Roller.")
    return go


class WindowMain(Window):
    """Is Roller's main window."""

    def __init__(self):
        """Has the GTK event loop."""
        if verify_preset_folder():
            self._last_pose_d = {}

            # Preserve the selection and active layer of open images.
            sel_q = []
            active_layer_q = []

            self._load_window_pose()
            image_undo_start()

            for j in Pic.tab_q:
                if pdb.gimp_image_is_valid(j):
                    active_layer_q.append((j, j.active_layer))
                    sel_q.append((
                        j,
                        pdb.gimp_selection_save(j)
                        if not pdb.gimp_selection_is_empty(j) else None
                    ))
                    pdb.gimp_selection_none(j)

            Window.__init__(self, {wk.WINDOW_KEY: TITLE}, is_dialog=False)

            self.port = PortMain({wk.ROLLER_WIN: self})

            self.set_hook(self.port.get_hook())
            self.add(self.port)

            # Display the main window now that it
            # has been initialized by PortMain.
            self.gtk_win.show_all()

            try:
                # Insert a signal processing function
                # into the main signal processing ring.
                #
                # Reference
                # library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
                gobject.idle_add(Ring.send)

                # Start the main signal processing ring.
                gtk.main()

            except Exception as ex:
                if self.gtk_win is not None:
                    self.close()
                    show_err(CRITICAL + repr(ex))
                raise

            view_j = Run.j

            for j in Pic.opened_q:
                if pdb.gimp_image_is_valid(j):
                    pdb.gimp_image_delete(j)

            # Close the GradientLight image.
            if Gradient.image:
                pdb.gimp_image_delete(Gradient.image)

            # Restore the selection for open images.
            for i in sel_q:
                j, sel = i[0], i[1]

                if sel is not None:
                    if (
                        pdb.gimp_item_is_valid(sel) and
                        pdb.gimp_image_is_valid(j)
                    ):
                        load_selection(j, sel)
                        pdb.gimp_image_remove_channel(j, sel)
                else:
                    if pdb.gimp_image_is_valid(j):
                        # Remove a Roller generated selection.
                        pdb.gimp_selection_none(j)

            # Restore the active layer for open images.
            for j, z in active_layer_q:
                if pdb.gimp_image_is_valid(j) and validate_item(z):
                    j.active_layer = z

            if view_j and not self.canceled:
                collapse_tree(view_j)
                remove_group(view_j)
                pdb.gimp_image_resize(
                    view_j, *map(int, (Wip.get_size() + (-Wip.x, -Wip.y)))
                )
                resize_layers(view_j)

            if self.canceled and The.grad:
                pdb.gimp_gradient_delete(The.grad)
                The.grad = None

            if not self.canceled and view_j:
                # Set the bottom layer as the active layer.
                if len(view_j.layers):
                    view_j.active_layer = view_j.layers[-1]

                # Remove channels.
                [view_j.remove_channel(i) for i in view_j.channels]

            # Save Window position.
            if Window.pose_d != self._last_pose_d:
                pickle_dump(Window.pose_d, self._pose_file)
            image_undo_end()

    def _load_window_pose(self):
        """Load the Window position dictionary if it exists."""
        n = self._pose_file = make_preset_path(u"Window Position", "")
        d = pickle_load(n, is_shown=False)
        if d:
            Window.pose_d = deepcopy(d)
            self._last_pose_d = deepcopy(d)
