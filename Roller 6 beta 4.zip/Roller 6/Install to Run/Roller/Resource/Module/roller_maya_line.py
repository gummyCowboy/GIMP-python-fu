#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_for import Issue as vo, Plan as fy, Signal as si
from roller_constant_key import (
    Material as ma, Node as ny, Option as ok, Plan as ak, SubMaya as sm
)
from roller_deco import finish_backed
from roller_deco_line import (
    do_canvas, do_cell_per, do_cell_main, do_facial_per, do_facial_main
)
from roller_maya import CanvasRoute, CellRoute, FaceRoute, Runner
from roller_maya_layer import check_matter, check_mix_basic
from roller_maya_light import Light
from roller_maya_add import Add
from roller_option_group import DecoGroup
from roller_view_option_list import Frame
from roller_view_real import make_canvas_group, make_cast_group
from roller_view_step import get_planner


class Line(DecoGroup):
    """Assign Plan and Work delegates for view run processing."""
    frame_row_k = ok.BRW

    def __init__(self, **d):
        DecoGroup.__init__(self, **d)

        self.plan = {
            ny.CANVAS: PlanCanvas,
            ny.CELL: PlanCell,
            ny.FACE: PlanFace,
            ny.FACING: PlanFace
        }[self.branch_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas,
            ny.CELL: WorkCell,
            ny.FACE: WorkFace,
            ny.FACING: WorkFace
        }[self.branch_k](self)
        if self.branch_k in (ny.FACE, ny.FACING):
            # Face has no Margin to receive update from Shift, so
            # Line receive update directly from Shift instead of Margin.
            self.latch(
                self.item.model.baby, (si.CELL_SHIFT_CALC, self.on_cell_calc)
            )


class Chi(Runner):
    """Factor Plan and Work."""

    def __init__(self, any_group, view_x, put):
        Runner.__init__(
            self,
            any_group,
            view_x,
            put,
            [
                (),
                (ok.RW1,),                  # Color Button
                (ok.RW1, ok.BRUSH),          # Brush Button
                (ok.BRW, ok.MOD)
            ]
        )
        self.set_issue()


class Plan(Chi):
    """Manage Plan Line output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        """
        any_group: AnyGroup
        """
        Chi.__init__(self, any_group, 0, self.put)

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.LINE)
        self.latch(planner, (fy.SIGNAL_D[ak.LINE], self.on_plan_option_change))

    def bore(self):
        """Manage layer output during a view run."""
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned
        self.is_matter |= self.is_switched
        self.realize()

    def on_plan_option_change(self, _, arg):
        """
        Respond to change from Planner's Line option.

        arg: tuple
            (bool, bool)
            (
                Is True if the Line option is checked in Planner.,
                Is True if the Line option in Planner changed.
            )
        """
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage Line for Peek, Preview and final output."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Line
        """
        Chi.__init__(self, any_group, 1, self.put)

        self.sub_maya[sm.ADD] = Add(any_group, self, (ok.BRW, ok.ADD))
        self.sub_maya[sm.FRAME] = Frame(any_group, self, (ok.BRW, ok.FRAME))
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.LINE)

    def bore(self):
        """Produce layer output during a view run."""
        d = self.value_d
        self.go = d[ok.SWITCH]
        is_back = Run.is_back

        self.realize()
        if self.go:
            if self.matter:
                self.sub_maya[sm.ADD].do(
                    d[ok.BRW][ok.ADD],
                    self.is_matter,
                    self.is_matter,
                    is_back,
                    self.group
                )
                finish_backed()
                self.sub_maya[sm.FRAME].do(d[ok.BRW][ok.FRAME], self.is_matter)
                self.sub_maya[sm.LIGHT].do(self.is_matter)
            else:
                self.die()


class Main:
    """Identify the Maya as main."""
    vote_type = vo.MAIN

    def __init__(self):
        return


class WorkMain(Main, Work):
    """Factor Main and Work."""

    def __init__(self, *arg):
        """
        arg: tuple
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *arg)


# Canvas_______________________________________________________________________
class Cloth:
    """Factor Plan and Work Canvas."""

    def __init__(self):
        self.do_matter = do_canvas


class PlanCanvas(Cloth, Main, Plan, CanvasRoute):
    """Manage Plan Canvas/Line output."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Cloth.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group)
        CanvasRoute.__init__(self)


class WorkCanvas(Cloth, WorkMain, CanvasRoute):
    """Manage Work Canvas/Line output."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's option group
        """
        Cloth.__init__(self)
        WorkMain.__init__(self, any_group)
        CanvasRoute.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:
    """Is factored from Plan and Work Cell."""
    is_face = False

    def __init__(self):
        self.do_matter = do_cell_main


class PlanCell(Main, Plan, CellRoute, Cellular):
    """Manage Plan Cell/Line output for main."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Main.__init__(self)
        Plan.__init__(self, any_group)
        CellRoute.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, CellRoute, Cellular):
    """Manage Work Cell/Line output for main."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        WorkMain.__init__(self, any_group)
        CellRoute.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per__________________________________________________________________________
class Per:
    """Factor Plan and Work Cell/Line Per."""
    vote_type = vo.PER

    def __init__(self, do_matter, k):
        self.do_matter = do_matter
        self.k = k


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Plan Cell/Line Per output."""
    is_face = False
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group)
        Per.__init__(self, do_cell_per, k)


class WorkCellPer(Work, Per):
    """Manage Work Cell/Line/Per output."""
    is_face = False
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group)
        Per.__init__(self, do_cell_per, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    """Factor Plan and Work Face."""
    is_face = True

    def __init__(self):
        self.do_matter = do_facial_main


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage Plan Face/Line output for main."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group)
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, FaceRoute):
    """Manage Work Face/Line output for main."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Face.__init__(self)
        WorkMain.__init__(self, any_group)
        FaceRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per_____________________________________________________________________
class FacePer(Per):
    """Factor Plan and Work Face/Line/Per."""
    is_face = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacePer(Plan, FacePer):
    """Manage Plan Face/Line output for Per."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c, x);
            of int; Goo key
        """
        Plan.__init__(self, any_group)
        FacePer.__init__(self, do_facial_per, k)


class WorkFacePer(Work, FacePer):
    """Manage Work Face/Line output for Per."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int; Goo key
        """
        Work.__init__(self, any_group)
        FacePer.__init__(self, do_facial_per, k)
