#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import ForLayer, ForFill, OptionKey
from roller_interactive import Interactive
from roller_fu import Lay
from roller_mode import Mode
import gimpfu as fu


class BackdropStyle(Interactive):
    """
    Is an intermediary for backdrop styles and Interactive.

    Has common style functions.
    """

    def __init__(self, d, stat, layer_key=ForLayer.BACKDROP, active=None):
        """
        Rename the backdrop layer and pass the rod to Interactive.

        Interactive will delegate the job.

        d: sub-session dict
        stat: Stat
        layer_key: layer key
        active: layer
            the active layer
        """
        if layer_key == ForLayer.BACKDROP:
            Lay.get_backdrop_layer(stat.render).name = Lay.get_layer_name(
                self.name, stat)
        Interactive.__init__(self, d, stat, layer_key, active=active)

    @staticmethod
    def invert_color(q):
        """
        Return an inverted color.

        q: RGB
        """
        return tuple([255 - i for i in q])

    def set_fill_context(self, d):
        """
        Set the context for current fill-type operation.

        Called before a bucket fill operation.

        d: sub-session dict
        """
        pdb.gimp_context_set_sample_threshold(d[OptionKey.THRESHOLD])
        pdb.gimp_context_set_opacity(d[OptionKey.OPACITY])
        pdb.gimp_context_set_paint_mode(Mode.get_x(d[OptionKey.MODE]))
        pdb.gimp_context_set_sample_criterion(
            ForFill.CRITERIA_LIST.index(d[OptionKey.CRITERIA]))

    def shadow(self, z, blur=15., op=130.):
        """
        z: layer
        blur: shadow blur
        op: shadow opacity

        Return the shadow.
        """
        x = Lay.offset(z, self.group)
        z = self.do_shadow(z, 0, 0, blur, (0, 0, 0), op, "")
        z.mode = fu.LAYER_MODE_NORMAL

        Lay.order(self.stat.render, z, self.group, a=x + 1)
        return z
