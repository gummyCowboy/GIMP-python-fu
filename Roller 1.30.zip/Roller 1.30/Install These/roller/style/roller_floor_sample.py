#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import OptionKey, SessionKey
from roller_backdrop_style import BackdropStyle
from roller_fu import Lay, Sel
import colorsys
import gimpfu as fu
import math


class FloorSample(BackdropStyle):
    """Has wedges colored by a gradient between two colors."""
    name = SessionKey.FLOOR_SAMPLE

    def __init__(self, d, stat):
        """
        Start creating a Floor Sample.

        Interactive will delegate the job with a template.

        d: sub-session dict
        stat: Stat
        """
        BackdropStyle.__init__(self, d, stat)

    def do(self, d):
        """
        Draw the samples wedges.

        Is part of Interactive class template.

        d: sub-session dict
        """
        ok = OptionKey
        j = self.stat.render
        q = color, color1 = d[ok.COLOR_1], d[ok.COLOR_2]

        if d[ok.INVERT]:
            color = BackdropStyle.invert_color(color)
            color1 = BackdropStyle.invert_color(color1)

        lum = colorsys.rgb_to_hls(*color)[1]
        lum1 = colorsys.rgb_to_hls(*color1)[1]
        spins = int(360. / d[ok.ANGLE]) + int(360 % d[ok.ANGLE] > 0)
        step = [0] * 3
        steps = [0] * 3
        w, h = self.stat.width, self.stat.height
        cx, cy = w / 2., h / 2.
        a = 0
        self.group = Lay.group(j, self.name)

        if lum > lum1:
            color, color1 = color1, color

        for x in range(3):
            step[x] = abs(color[x] - color1[x]) / 1. / (spins - 1)

        for x in range(3):
            if color[x] > color1[x]:
                steps[x] = -step[x]

            elif color[x] < color1[x]:
                steps[x] = step[x]

        x, y = self.get_point_on_rectangle(0)
        start_color = color

        for spin in range(spins):
            a += d[ok.ANGLE]
            x1, y1 = self.get_point_on_rectangle(a)
            q = cx, cy, x, y

            if x == w and x1 != w:
                q += w, h

            elif y == h and y1 != h:
                q += 0, h

            elif x == 0 and x1 != 0:
                q += 0, 0

            elif y == 0 and y1 != 0:
                q += w, 0

            if y == 0 or y1 == 0:
                if y == h or y1 == h:
                    if a > 270:
                        q += w, h

                    else:
                        q += 0, 0

            if 0 in (x, x1):
                if w in (x, x1):
                    if a > 270:
                        q += w, 0

                    else:
                        q += 0, h

            q += x1, y1

            pdb.gimp_free_select(j, len(q), q, fu.CHANNEL_OP_REPLACE, 1, 0, 0)

            x, y = x1, y1
            z = Lay.add(j, self.name, z=self.group)

            Sel.fill(z, color)
            pdb.script_fu_clothify(j, z, 0, 0, 90, 70, 1)
            self.shadow(z, blur=50., op=100.)

            q1 = [0] * 3

            for i in range(3):
                b = steps[i] * (spin + 1)
                q1[i] = start_color[i] + int(b)
            color = tuple(q1)

        z = Lay.eat(j, self.group)

        Lay.clip(z)
        self.give_render_mask(z)
        self.active.layer = Lay.merge(j, z)

    def get_point_on_rectangle(self, angle):
        """
        Return an x, y coordinate.

        angle: radians, angle from center of the rectangle
        """
        w, h = self.stat.width, self.stat.height
        angle = math.radians(angle)
        sine = math.sin(angle)
        cosine = math.cos(angle)

        # distance to the top or the bottom edge (from the center):
        dy = h / 2 if sine > 0 else h / -2

        # distance to the left or the right edge (from the center):
        dx = w / 2 if cosine > 0 else w / -2

        # (distance to the vertical line) < (distance to the horizontal line):
        if (abs(dx * sine) < abs(dy * cosine)):
            # Calculate distance to the vertical line:
            dy = (dx * sine) / cosine

        # (distance to the top or the bottom edge)
        # < (distance to the left or the right edge):
        else:
            dx = (dy * cosine) / sine
        return round(dx + w / 2., 0), round(dy + h / 2., 0)
