#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_constant import ForGradient, OptionKey, SessionKey
from roller_backdrop_style import BackdropStyle
from roller_fu import Lay
from roller_gradient_fill import GradientFill


class ImageGradient(BackdropStyle):
    """Create a gradient from an image."""
    name = SessionKey.IMAGE_GRADIENT

    def __init__(self, d, stat):
        """d: sub-session dict"""
        self.grad = None

        BackdropStyle.__init__(self, d, stat)
        if self.stat.cancel and self.grad:
            pdb.gimp_gradient_delete(self.grad)

    def _do_bottomleft(self, d):
        """
        Sample colors and returns gradient start and end points.

        d: sub-session dict
        """
        a = d[OptionKey.SAMPLE_POINTS]
        w = self.stat.width / (a + 1)
        h = self.stat.height / (a + 1)
        x, y = w, self.stat.height - 1 - h

        for i in range(a):
            self.color[i] = self._pick_color(d, x, y)
            x = min(x + w, self.stat.width - 1)
            y = max(y - h, 0)
        return 0, self.stat.height - 1, self.stat.width - 1, 0

    def _do_horizontal(self, d):
        """
        Sample colors and returns gradient start and end points.

        d: sub-session dict
        """
        stat = self.stat
        a = d[OptionKey.SAMPLE_POINTS]
        w = stat.width / (a + 1)
        x, y = w, stat.height / 2

        for i in range(a):
            self.color[i] = self._pick_color(d, x, y)
            x = min(x + w, stat.width - 1)
        return 0, stat.height / 2, stat.width - 1, stat.height / 2

    def _do_topleft(self, d):
        """
        Sample colors and returns gradient start and end points.

        d: sub-session dict
        """
        a = d[OptionKey.SAMPLE_POINTS]
        w = self.stat.width / (a + 1)
        h = self.stat.height / (a + 1)
        x, y = w, h

        for i in range(a):
            self.color[i] = self._pick_color(d, x, y)
            x = min(x + w, self.stat.width - 1)
            y = min(y + h, self.stat.height - 1)
        return 0, 0, self.stat.width - 1, self.stat.height - 1

    def _do_vertical(self, d):
        """
        Sample colors and returns gradient start and end points.

        d: sub-session dict
        """
        stat = self.stat
        a = d[OptionKey.SAMPLE_POINTS]
        h = stat.height / (a + 1)
        x, y = stat.width / 2, h

        for i in range(a):
            self.color[i] = self._pick_color(d, x, y)
            y = min(y + h, stat.height - 1)
        return stat.width / 2, 0, stat.width / 2, stat.height - 1

    def _pick_color(self, d, x, y):
        """
        Pick a color from the canvas.

        d: sub-session dict
        x, y: int coordinates

        Return the color (RGBA).
        """
        return pdb.gimp_image_pick_color(
                self.stat.render,
                self.active.layer,
                x, y, 0, 1,
                d[OptionKey.SAMPLE_RADIUS]
            )

    def do(self, d):
        """
        Create an image gradient.

        Is part of an Interactive class template.

        d: sub-session dict
        """
        ok = OptionKey
        j = self.stat.render
        n = SessionKey.IMAGE_GRADIENT
        if self.grad:
            pdb.gimp_gradient_delete(self.grad)

        a = d[ok.SAMPLE_POINTS]
        e = deepcopy(d)
        e[ok.OFFSET] = 0
        self.color = [0] * a
        x = ForGradient.VECTOR.index(d[ok.SAMPLE_VECTOR])
        grad = self.grad = e[ok.GRADIENT] = pdb.gimp_gradient_new(d[ok.NAME])
        q = (
                self._do_vertical,
                self._do_horizontal,
                self._do_topleft,
                self._do_bottomleft
            )

        if a > 2:
            pdb.gimp_gradient_segment_range_split_uniform(grad, 0, 0, a - 1)

        e[ok.START_X], e[ok.START_Y], e[ok.END_X], e[ok.END_Y] = q[x](e)

        for x in range(a - 1):
            pdb.gimp_gradient_segment_set_left_color(
                self.grad, x, self.color[x], 100.)
            pdb.gimp_gradient_segment_set_right_color(
                self.grad, x, self.color[x + 1], 100.)

        Lay.clone(j, self.active.layer)
        GradientFill(e, self.stat, name=n, layer_key=n, auto=1)

        z = Lay.get_active(j)

        self.give_render_mask(z)

        self.active.layer = Lay.merge(j, z)

        if not d[ok.KEEP_GRADIENT] or self.stat.auto in (2, 3):
            pdb.gimp_gradient_delete(grad)
            self.grad = None
