#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForBackdropStyle
from roller_fu import Lay


class Transparency:
    """Transparency does nothing."""
    name = ForBackdropStyle.TRANSPARENCY

    def __init__(self, _, stat):
        """Renames the backdrop layer."""
        Lay.get_backdrop_layer(stat.render).name = \
            Lay.get_layer_name(self.name, stat)
