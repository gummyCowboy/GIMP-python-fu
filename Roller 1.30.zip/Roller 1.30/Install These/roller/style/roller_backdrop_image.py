#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForFormat, ForWidget, OptionKey, SessionKey
from roller_fu import Lay, Sel
from roller_layout import Images, Img
from roller_backdrop_style import BackdropStyle
import gimpfu as fu


class BackdropImage(BackdropStyle):
    """Backdrop image"""
    name = SessionKey.BACKDROP_IMAGE

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        q = Images.format_img_list[:]

        if d[SessionKey.BACKDROP_IMAGE] not in q:
            d[SessionKey.BACKDROP_IMAGE] = \
                ForWidget.FIRST if ForWidget.FIRST in q else ForFormat.NONE
        BackdropStyle.__init__(self, d, stat)

    def do(self, d):
        """
        Places an existing image as a backdrop.

        Is part of an Interactive class template.

        d: sub-session dict
        """
        ok = OptionKey
        j, z = self.stat.render, self.active.layer

        if d[SessionKey.BACKDROP_IMAGE] == ForFormat.NONE:
            # Fill with white:
            Lay.color_fill(z, (255,) * 3)

        else:
            # Copy the backdrop image to the backdrop layer:
            j1 = Img.get_image(d[SessionKey.BACKDROP_IMAGE])
            j2 = j1.j

            Sel.none(j2)
            Lay.kopy(j2)

            if j1.size != self.stat.size:
                if d[ok.FIT_IMAGE]:
                    # Resize backdrop image to fit backdrop layer:
                    j1 = Img.paste()
                    Img.shape(j1, self.stat.width, self.stat.height)

            z1 = self.active.layer = Lay.paste(j, z)

            if not d[ok.FIT_IMAGE]:
                Lay.clip(z1)
            z = self.active.layer = Lay.merge(j, z1)
        Lay.invert(z, d[ok.INVERT])

        if d[ok.BLUR]:
            Lay.blur(j, z, d[ok.BLUR])

        if z.mask:
            z.remove_mask(fu.MASK_DISCARD)
        Lay.masked(z)
