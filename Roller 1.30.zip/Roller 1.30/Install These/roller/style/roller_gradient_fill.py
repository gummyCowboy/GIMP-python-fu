#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import ForGradient, ForLayer, OptionKey, SessionKey
from roller_fu import Lay, Sel
from roller_backdrop_style import BackdropStyle


class GradientFill(BackdropStyle):
    """Fill the backdrop with a gradient."""
    name = SessionKey.GRADIENT_FILL

    def __init__(
                self,
                d,
                stat,
                name=SessionKey.GRADIENT_FILL,
                layer_key=ForLayer.BACKDROP,
                sel=None,
                auto=0
            ):
        """
        d: sub-session dict
        stat: Stat
        name: effect name
        layer_key: layer that is processed
        sel: selection
        auto: flag: If it's true, the gradient is drawn as is.
        """
        if auto:
            a = stat.auto
            stat.auto = 3

        self.name = name
        self.sel = sel
        active = None if name == SessionKey.GRADIENT_FILL else \
            Lay.get_active(stat.render)

        BackdropStyle.__init__(
            self, d, stat, layer_key=layer_key, active=active)
        if auto:
            stat.auto = a

    def do(self, d):
        """
        Fill the active layer with a gradient.

        Is part of an Interactive class template.

        d: sub-session dict
        """
        z = self.do_rotated_layer(d, self.do_job, self.active.layer)

        if self.name == SessionKey.GRADIENT_FILL:
            self.give_render_mask(z)

        z.mode, z.opacity = self.get_grad_mode(d)
        z.name = Lay.get_layer_name(self.name, self.stat)
        self.active.layer = Lay.merge(self.stat.render, z)
        if self.sel:
            Sel.isolate(self.stat.render, self.active.layer, self.sel)

    def do_job(self, j, z, d):
        """
        Draw a gradient.

        j: GIMP image
        z: layer
        d: sub-session dict

        Return the layer.
        """
        ok = OptionKey

        # Shape-burst methods require an opaque layer to work properly:
        if d[ok.GRADIENT_TYPE] in ForGradient.SHAPE_BURST:
            Sel.all(j)
            Sel.fill(z, (127, 127, 127))
            Sel.none(j)

        pdb.gimp_context_set_gradient(d[ok.GRADIENT])
        pdb.gimp_context_set_gradient_reverse(d[ok.REVERSE])
        pdb.gimp_drawable_edit_gradient_fill(
                z,
                ForGradient.GRADIENT_TYPE.index(d[ok.GRADIENT_TYPE]),
                d[ok.OFFSET],
                1,
                1,
                0.,
                1,
                d[ok.START_X],
                d[ok.START_Y],
                d[ok.END_X],
                d[ok.END_Y]
            )

        Lay.invert(z, d[ok.INVERT])
        return z
