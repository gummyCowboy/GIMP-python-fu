#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_base import OZ
from roller_constant import (
        ForBackdropStyle,
        ForFill,
        ForFormat,
        ForWidget,
        FormatKey,
        LayoutKey,
        OptionKey,
        SessionKey
    )

import gtk


class Format:
    """Manage UIFormat session data."""
    fk = FormatKey

    # Read only:
    default = {
            fk.NAME: "Format",
            fk.EFFECT: ForFormat.NONE,
            fk.RESIZE: ForFormat.LOCKED,
            fk.HORIZONTAL: ForFormat.CENTER,
            fk.VERTICAL: ForFormat.MIDDLE,
            fk.IMAGE: ForFormat.NEXT,
            fk.ROTATE: 0,
            fk.OPACITY: 100,
            fk.BLUR_BEHIND: 0,
            fk.FLIP_HORIZONTAL: 0,
            fk.FLIP_VERTICAL: 0,
            fk.MERGE_PER_CELL: 0,
            fk.PROPERTY_PER_CELL: 0,
            fk.PLACEMENT_PER_CELL: 0,
            fk.MARGIN_PER_CELL: 0,
            fk.ROW: 1,
            fk.COLUMN: 1,
            fk.LAYER_MARGIN_TOP: 0,
            fk.LAYER_MARGIN_LEFT: 0,
            fk.LAYER_MARGIN_RIGHT: 0,
            fk.LAYER_MARGIN_BOTTOM: 0,
            fk.CELL_MARGIN_TOP: 0,
            fk.CELL_MARGIN_LEFT: 0,
            fk.CELL_MARGIN_RIGHT: 0,
            fk.CELL_MARGIN_BOTTOM: 0,
            fk.PRESET: "Default",
            fk.CELL_TABLE_MERGE: None,
            fk.CELL_TABLE_PLACEMENT: None,
            fk.CELL_TABLE_MARGIN: None,
            fk.CELL_TABLE_PROPERTY: None
        }

    def __init__(self, d):
        self.format = deepcopy(d)


class Session:
    """
    Store session control values.

    After a successful render, a Last_Used session file is
    written if the current session dictionary has changed.
    """
    w, h = gtk.gdk.screen_width(), gtk.gdk.screen_height()
    sk, ok, a = SessionKey, OptionKey, LayoutKey

    # read-only:
    default = {
        sk.AVERAGE_COLOR: OrderedDict([
                (ok.MODE, "Normal"),
                (ok.OPACITY, 100.),
                (ok.INVERT, 0)
            ]),

        sk.AUTOMATE: 0,
        sk.BACKDROP_IMAGE: OrderedDict([
                (ok.BACKDROP_IMAGE, ForWidget.FIRST),
                (ok.BLUR, 0),
                (ok.FIT_IMAGE, 1),
                (ok.INVERT, 0)
            ]),

        sk.BACKDROP_STYLE: ForBackdropStyle.TRANSPARENCY,
        sk.BORDER_GRADIENT: OrderedDict([
                (ok.GRADIENT, "Default"),
                (ok.GRADIENT_TYPE, "Bilinear"),
                (ok.OPACITY, 100),
                (ok.ROTATE, 0),
                (ok.INVERT, 0),
                (ok.REVERSE, 0),
                (ok.OFFSET, 0),
                (ok.START_X, 0),
                (ok.START_Y, 0),
                (ok.END_X, w - 1),
                (ok.END_Y, h - 1)
            ]),

        sk.BORDER_LINE: OrderedDict([
                (ok.BORDER_WIDTH, 10),
                (ok.LIGHT_ANGLE, 45.),
                (ok.BORDER_TYPE, 1),
                (ok.INHERIT_OPACITY, 0),
                (ok.NOISE_SEED, 0),
                (ok.POWER, 30)
            ]),

        sk.CLEAR_FRAME: OrderedDict([
                (ok.BORDER_WIDTH, 45),
                (ok.BORDER_TYPE, 1),
                (ok.COLOR_1, (255, 255, 255))
            ]),

        sk.COLOR_FILL: OrderedDict([
                (ok.THRESHOLD, 1.),
                (ok.CRITERIA, ForFill.CRITERIA_LIST[0]),
                (ok.COLOR_1, (127, 127, 127)),
                (ok.MODE, "Normal"),
                (ok.OPACITY, 100),
                (ok.INVERT, 0),
                (ok.START_X, 0),
                (ok.START_Y, 0)
            ]),

        sk.COLORED_BOARD: OrderedDict([
                (ok.BORDER_WIDTH, 1),
                (ok.BORDER_TYPE, 1),
                (ok.COLOR_1, (255, 255, 255)),
                (ok.INHERIT_OPACITY, 0)
            ]),

        sk.COLORED_GRID: OrderedDict([
                (ok.ROW, 4),
                (ok.COLUMN, 4),
                (ok.COLOR_1, (0,) * 3),
                (ok.COLOR_2, (255, 255, 255)),
                (ok.MODE, "Normal"),
                (ok.OPACITY, 100),
                (ok.ROTATE, 0),
                (ok.INVERT, 0)
            ]),

        sk.CORE_DESIGN: OrderedDict([
                (ok.GRADIENT, "Default"),
                (ok.ROW, 12),
                (ok.COLUMN, 12),
                (ok.INVERT, 0)
            ]),

        sk.DROP_SHADOW: OrderedDict([
                (ok.BLUR, 30),
                (ok.INTENSITY, 120),
                (ok.OFFSET_X, 0),
                (ok.OFFSET_Y, 0),
                (ok.SHADOW_COLOR, (0, 0, 0)),
                (ok.INHERIT_OPACITY, 1)
            ]),

        sk.FILL_LIGHT_SHADOW: OrderedDict([
                (ok.BLUR, 30),
                (ok.INTENSITY, 120),
                (ok.OFFSET_X, 0),
                (ok.OFFSET_Y, 0),
                (ok.SHADOW_COLOR, (0, 0, 0)),
                (ok.INHERIT_OPACITY, 0)
            ]),

        sk.FLOOR_SAMPLE: OrderedDict([
                (ok.ANGLE, 60),
                (ok.COLOR_1, (255, 255, 255)),
                (ok.COLOR_2, (0, 0, 0)),
                (ok.INVERT, 0)
            ]),

        sk.FORMAT_LIST: [],
        sk.IMAGE_EDGE_SHADOW: OrderedDict([
                (ok.BLUR, 20),
                (ok.INTENSITY, 120),
                (ok.SHADOW_COLOR, (0, 0, 0))
            ]),

        sk.GRADIENT_FILL: OrderedDict([
                (ok.GRADIENT, "Default"),
                (ok.GRADIENT_TYPE, "Linear"),
                (ok.ROTATE, 0),
                (ok.MODE, "Normal"),
                (ok.OPACITY, 100),
                (ok.INVERT, 0),
                (ok.REVERSE, 0),
                (ok.OFFSET, 0),
                (ok.START_X, 0),
                (ok.START_Y, 0),
                (ok.END_X, w - 1),
                (ok.END_Y, h - 1)
            ]),

        sk.HEIGHT: h,
        sk.IMAGE_GRADIENT: OrderedDict([
                (ok.NAME, "Sampled Gradient"),
                (ok.SAMPLE_RADIUS, 1),
                (ok.SAMPLE_POINTS, 2),
                (ok.SAMPLE_VECTOR, "Mid-Vertical"),
                (ok.KEEP_GRADIENT, 0),
                (ok.GRADIENT_TYPE, "Linear"),
                (ok.ROTATE, 0),
                (ok.MODE, "Normal"),
                (ok.OPACITY, 100),
                (ok.INVERT, 0),
                (ok.REVERSE, 0)
            ]),

        sk.INLAY_SHADOW: OrderedDict([
                (ok.BLUR, 30),
                (ok.INTENSITY, 100),
                (ok.SHADOW_COLOR, (0, 0, 0))
            ]),

        sk.KEY_LIGHT_SHADOW: OrderedDict([
                (ok.BLUR, 30),
                (ok.INTENSITY, 120),
                (ok.OFFSET_X, 0),
                (ok.OFFSET_Y, 0),
                (ok.SHADOW_COLOR, (0, 0, 0)),
                (ok.INHERIT_OPACITY, 0)
            ]),

        sk.LAYOUT_OPTION: {
                a.LAYER_MARGINS: 0,
                a.CELL_MARGINS: 0,
                a.COORDINATES: 0,
                a.DIMENSIONS: 0,
                a.CORNERS: 0,
                a.GRID: 0,
                a.NAME: 0,
                a.RATIOS: 0
            },

        sk.MYSTERY_GRATE: OrderedDict([
                (ok.GRADIENT, "Default"),
                (ok.COLUMN_1, 8),
                (ok.COLUMN_2, 80),
                (ok.INVERT, 0)
            ]),

        sk.PATTERN_FILL: OrderedDict([
                (ok.PATTERN, None),
                (ok.CRITERIA, ForFill.CRITERIA_LIST[0]),
                (ok.THRESHOLD, 1.),
                (ok.MODE, "Normal"),
                (ok.OPACITY, 100),
                (ok.INVERT, 0),
                (ok.START_X, 0),
                (ok.START_Y, 0)
            ]),

        sk.PRESET: "Default",
        sk.ROUNDED_EDGE: OrderedDict([
                (ok.BLUR, 15),
                (ok.ROUND_UP, 0),
            ]),

        sk.STAINED_GLASS: OrderedDict([
                (ok.GLASS_WIDTH, 45),
                (ok.PANE_WIDTH, 50),
                (ok.PANE_HEIGHT, 50),
                (ok.ROTATE, 45),
                (ok.BORDER_WIDTH, 10),
                (ok.LIGHT_ANGLE, 45.),
                (ok.BORDER_TYPE, 1),
                (ok.INHERIT_OPACITY, 0),
                (ok.NOISE_SEED, 0),
                (ok.POWER, 30)
            ]),
        sk.WIDTH: w}

    @staticmethod
    def load_file(d):
        """
        Load a Session file.
        Check to see if its valid.

        d: pickle dict

        Return the Session data or (0 or -1) for failure.
        """
        e = OZ.pickle_load(d)

        if e:
            d1 = deepcopy(Session.default)
            d1[SessionKey.WINDOW] = {}

            OZ.pass_version(e, d1)
            for d1 in e[SessionKey.FORMAT_LIST]:
                OZ.pass_version(d1, Format.default, is_format=1)

        else:
            e = 0
        return e
