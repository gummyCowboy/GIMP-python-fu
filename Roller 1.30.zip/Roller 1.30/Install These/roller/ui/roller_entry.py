#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_wig import Wig
import gtk


class REntry(Wig):
    """This is a custom GTK Entry."""

    def __init__(self, p, k, pad_x=0):
        """
        p: callback function
        k: widget's key
        pad_x: index to padding
        """
        w = ForWidget.MARGIN
        g = self.g = gtk.Alignment(0, 0, 1, 0)
        g1 = gtk.Entry(100)

        Wig.__init__(self, p, key=k, widget=g1)
        g.add(g1)
        g1.connect('changed', self.callback)
        if pad_x:
            g.set_padding(0, (0, w / 2)[pad_x - 1], w, w)

    def get_value(self):
        """
        Return the value displayed in the Entry.

        Is part of a UI widget template.
        """
        return self.wig.get_text()

    def set_value(self, n):
        """
        Set the value displayed in the the Entry.

        Is part of a UI widget template.

        n: string to place in the Entry
        """
        self.wig.set_text(n)
