#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget, OptionKey, SessionKey
from roller_rbox import RBox
from roller_button import RButton
from roller_wig import Wig
import gtk


class GroupFormatList(Wig):
    """
    This is widget group with TreeView and TreeView manipulation Buttons.

    Use the GroupFormatList class template to
    hook feedback from the GroupFormatList:
        on_format_list_change: function
            Called when the format list changes

        create_format: function
            Called when the New Format button is activated.

        edit_format: function
            Called when the Edit Format button is activated.

        delete_format: function
            Called when the Delete Format button is activated.
    """
    RESPOND_KEY = 'Return', 'Delete', 'space'

    def __init__(self, g, creator):
        """
        Adds the format list and Buttons to a group.

        g: container
        d: widget dict
        creator: class instance
            the one that created the format list
        """
        w = ForWidget.MARGIN
        self.creator = creator
        self.buttons = []
        self.items = []
        g1 = RBox(1)

        # Format Stack TreeView:
        self.store = gtk.ListStore(str)

        g3 = gtk.TreeView(model=self.store)
        g3.set_headers_visible = 0

        Wig.__init__(
                self,
                creator.on_format_list_change,
                key=SessionKey.FORMAT_LIST,
                widget=g3
            )

        # Create column:
        col = gtk.TreeViewColumn(
            "Format Stack:", gtk.CellRendererText(), text=0)

        col.set_min_width(120)
        col.set_sizing(gtk.TREE_VIEW_COLUMN_AUTOSIZE)

        # Add column to TreeView:
        g3.append_column(col)

        # When a row is selected, it emits a signal:
        g3.get_selection().connect('changed', self.selected)
        g3.connect('key_press_event', self.on_key_press)
        g1.g.set_padding(w / 2, w, w, w)

        g4 = RBox(2, align=(0, 0, 0, 1), pad=(0, 0, ForWidget.MARGIN / 2, 0))
        a = zip(
            (
                "New Format",
                "Edit Format",
                "Del Format"),
            (
                self._create_format,
                self._edit_format,
                self._del_format
            ),
            (0, 1, 1))

        for n, p, b in a:
            g5 = GroupFormatList.CoOpButton(n, p, b)
            g4.add(g5.g)
            self.buttons.append(g5)

        hbox = gtk.HBox()
        g6 = GroupFormatList.CoOpButton("↑", self.move_sel_up, 2)
        g7 = GroupFormatList.CoOpButton("↓", self.move_sel_down, 2)
        g8 = gtk.ScrolledWindow()

        hbox.add(g6.g)
        hbox.add(g7.g)
        g4.add(hbox)
        [self.buttons.append(i) for i in (g6, g7)]
        g8.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        g8.add_with_viewport(g3)
        g1.add(g8)
        g1.add(g4.g)
        g.add(g1.g)
        self.verify_buttons()

    def _create_format(self, *_):
        """
        Called when the user activated the New Format Button.

        Enumerates the ‟Format” name until
        a unique identifier is created.
        """
        q = self.items
        n = "Format"
        a = len(q) + 1
        go = 1

        while go:
            go = 0
            n1 = n + " " + str(a)
            for i in q:
                if i[0] == n1:
                    a += 1
                    go = 1
                    break

        self.store.append([n1])
        q.append((n1, len(q)))
        self.verify_buttons()
        self.select_item(len(q) - 1)
        self.creator.create_format(n1)

    def _del_format(self, *_):
        """Delete a row in the TreeView."""
        x = self.get_sel_x()

        self.items.pop(x)

        # model, iter:
        a, b = self.wig.get_selection().get_selected()

        a.remove(b)
        self.creator.delete_format(x)

    def _edit_format(self, *_):
        """Called because the user clicked the Edit Button."""
        self.creator.edit_format()

    def get_sel_x(self):
        """Return the row index of the selected item."""
        return self.wig.get_selection().get_selected_rows()[1][0][0]

    def get_sel_text(self):
        """Return the selected format name."""
        return self.items[self.get_sel_x()][0]

    def get_value(self):
        """
        Return a list of strings displayed in the list.

        Is part of a UI widget template.
        """
        return self.items

    def populate_treeview(self, q):
        """
        Populate the TreeView from a list.
        The previous indexed-list is replaced.

        q: list of tuples (name, index)
        """
        self.store.clear()
        self.items = []
        for x, b in enumerate(q):
            self.store.append([b[0]])
            self.items.append((b[0], x))

    def move_sel_down(self, *_):
        u"""
        Called when the user activates the Move Down Button.

        Move selections down one line in the TreeView.

        If ‟x” selection is at the bottom of the list,
        then the item rotates to the top of the list.
        """
        x = x1 = self.get_sel_x()
        a = len(self.items)
        x += 1

        if x == a:
            x = 0
        self.update_treeview(x, x1)

    def move_sel_up(self, *_):
        u"""
        Called when the user activated the Move Up Button.

        Move selections up one line in the TreeView.

        If ‟x” selection is at the top of the list, then
        the item rotates to the bottom of the list.
        """
        x = x1 = self.get_sel_x()
        a = len(self.items)
        x -= 1

        if x < 0:
            x = a - 1
        self.update_treeview(x, x1)

    def on_key_press(self, _, a):
        """
        Used to catch the delete and return keys.

        a: key-press event
        """
        n = gtk.gdk.keyval_name(a.keyval)
        if len(self.items):
            if n in GroupFormatList.RESPOND_KEY:
                x = GroupFormatList.RESPOND_KEY.index(n)

                (self._edit_format, self._del_format, self.selected)[x]()
                return 1

    def rename(self, x, n):
        """
        Rename a format.

        x: the current list entry index
        n: name of format
        """
        self.items[x] = n, self.items[x][1]
        self.populate_treeview(self.items)

    def selected(self, *_):
        """Called when a selection event occurs."""
        self.verify_buttons()

    def select_item(self, x):
        """
        Select, sort of, a TreeView item.

        x: row index in the TreeView
        """
        self.wig.set_cursor(x)

    def set_indices(self):
        u"""
        Update the ‟self.items” indices.

        This is called after the Session
        dictionary's format list is re-ordered.
        """
        for i in range(len(self.items)):
            self.items[i] = self.items[i][0], i

    def set_value(self, q):
        """
        Load the format list from a session dictionary's list of formats.

        Is part of a UI widget template.

        q: list of formats from the session dict
        """
        b = []
        for d in q:
            b.append((d[OptionKey.NAME], 0))
        self.populate_treeview(b)

    def update_treeview(self, x, x1):
        """
        Update the list after a change.

        x: new position (int)
        x1: old position
        """
        q = self.items[x1]

        self.items.pop(x1)
        self.items.insert(x, q)
        self.creator.on_format_list_change()
        self.populate_treeview(self.items)
        self.select_item(x)

    def verify_buttons(self):
        """Verify Buttons that are dependent on the list quantity."""
        _, b = self.wig.get_selection().get_selected()

        # The move and delete Buttons are dependent
        # on their selection state and the list size:
        for g in self.buttons[1:]:
            if b and len(self.items) >= g.need:
                g.enable()

            else:
                g.disable()

    class CoOpButton(RButton):
        """
        Has a variable, ‟self.need”.
        ‟self.need” is the number of items in a list
        needed for the Button to be valid.
        """

        def __init__(self, n, p, a):
            """
            n: label
            p: callback function
            a: the number of items needed for this Button to be valid
            """
            self.need = a
            RButton.__init__(self, n, p)
