#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_constant import (
        ForBackdropStyle,
        ForCell,
        ForFill,
        ForGradient,
        ForPreset,
        ForWidget,
        OptionKey,
        PresetKey,
        SessionKey,
        UIKey,
        WindowKey
    )

from roller_base import OZ
from roller_ui import UI
from roller_group_preset import GroupPreset
from roller_layout import Images
from roller_session import Session
from roller_mode import Mode
from roller_preset_sub_session import PresetSubSession
from roller_button import RButton
from roller_check_button import RCheckButton
from roller_color_button import RColorButton
from roller_combobox import RComboBox
from roller_combobox_entry import RComboBoxEntry
from roller_eventbox import REventBox
from roller_entry import REntry
from roller_fu import Sel
from roller_label import RLabel
from roller_radio import RRadio
from roller_radio_button import RRadioButton
from roller_spin_button import RSpinButton
from roller_splitter import Splitter
import gtk


class UIOption(UI):
    """
    This is a dynamic-widget dialog for style and effect options.

    Use an UIOption class template to communicate with the creator class.
    The UIOption template has the following properties:
        prep: function
            Called when the user accepted the options.

        preview: function
            Called when the user wants a preview of the options.

        preview_changed: function
            Called so the creator class can keep or delete a
            previous preview.

        rand: function
            Called so the creator can return a dictionary with
            randomized widget values.
    """

    def __init__(self, a, d, stat):
        """
        a: calling class instance
            part of the UIOption class template

        d: sub-session dict
        stat: Stat
        """
        self.stat = stat
        self.stat.cancel = 1
        self._session_key = a.name
        self._creator = a
        self.d = d
        self.wigs = [k for k in Session.default[a.name]]
        self.bd_image_m = None
        d = {
                UIKey.ON_RETURN: self.do_job,
                UIKey.WINDOW_POSITION: WindowKey.OPTION,
                UIKey.WINDOW_TITLE: a.name + " Options"
            }

        UI.__init__(self, d)
        Sel.none(stat.render)
        pdb.gimp_displays_flush()

        if self._gradient_type_widget:
            self._update_widget_visibility(self._gradient_type_widget)
        gtk.main()

    def _add_box(self, g):
        """
        Create a box that is split and has a colored background.

        g: container

        Returns: REventBox.
        """
        box = REventBox(self.color)
        g1 = Splitter(pad_x=3)

        g.add(box)
        box.add(g1.g)
        return g1, box

    def _compliment_key_light(self):
        """Return a complimentary preset of the key-light shadow."""
        d = deepcopy(self.stat.session[SessionKey.KEY_LIGHT_SHADOW])
        d[OptionKey.OFFSET_X] *= -1
        d[OptionKey.OFFSET_Y] *= -1
        d[OptionKey.INTENSITY] /= 2
        return d

    def _get_data(self):
        """Return a dict of the control values."""
        d = {}

        for g in self.controls:
            d[g.key] = g.get_value()
        return d

    def _draw_preview(self, g):
        """
        Draw a preview.

        Calls the creator class to perform the preview operation.

        g: RButton
        """
        self.win.iconify()
        g.disable()

        d = self._get_data()

        self._creator.preview(d)
        g.enable()
        pdb.gimp_displays_flush()
        self.win.present()

    def _draw_widgets(self, g, q):
        """
        Create the widgets.

        g: Vbox
        q: list of widgets
        """
        ok = OptionKey
        sb, cb, rb = RSpinButton, RComboBoxEntry, RRadioButton
        p = self.on_widget_change
        w, h = self.stat.height, self.stat.width
        cell_w = ForCell.MIN_CELL_SPAN
        self._point_box = []
        self._gradient_type_widget = None

        for n in self.wigs:
            g1, event_box = self._add_box(g)
            a = self.d[n]

            if n in (
                        ok.INVERT,
                        ok.KEEP_GRADIENT,
                        ok.FIT_IMAGE
                    ):
                g2 = RLabel("")

            else:
                g2 = RLabel(n + ":\t\t")

            if n == ok.ANGLE:
                g3 = sb(p, (6, 90), key=n)

            elif n == ok.BACKDROP_IMAGE:
                q1 = self.backdrop_images = Images.format_img_list[1:]
                g3 = self.bd_image_m = RComboBox(p, key=n, opt=q1)

            elif n == ok.BORDER_TYPE:
                g_ = rb(p, "Rounded", n, None)
                g3 = rb(p, "Angular", n, g_.wig)
                rr = RRadio((g_, g3), n)
                g1.right.add(g_.g)

            elif n == ok.BORDER_WIDTH:
                g3 = sb(p, (0, self.stat.radius), key=n)

            elif n == ok.BLUR:
                g3 = sb(p, (0, 1024), key=n)

            elif n in (
                    ok.COLOR_1,
                    ok.COLOR_2,
                    ok.SHADOW_COLOR
                ):
                g3 = RColorButton(p, a, n)

            elif n == ok.CRITERIA:
                g3 = cb(p, key=n, opt=ForFill.CRITERIA_LIST)

            elif n == ok.GLASS_WIDTH:
                g3 = sb(p, (0, self.stat.radius), key=n)

            elif n == ok.GRADIENT:
                q1 = sorted(pdb.gimp_gradients_get_list(None)[1])
                g3 = cb(p, key=n, opt=q1)

            elif n == ok.GRADIENT_TYPE:
                g3 = self._gradient_type_widget = cb(
                    p, key=n, opt=ForGradient.GRADIENT_TYPE)

            elif n == ok.INHERIT_OPACITY:
                g_ = rb(p, "Same as image", n, None)
                g3 = rb(p, "Make opaque", n, g_.wig)
                rr = RRadio((g_, g3), n)
                g1.right.add(g_.g)

            elif n in (
                    ok.FIT_IMAGE,
                    ok.INVERT,
                    ok.KEEP_GRADIENT,
                    ok.REVERSE,
                    ok.ROUND_UP
                ):
                g3 = RCheckButton(n, p, n)

            elif n == ok.LIGHT_ANGLE:
                g3 = sb(p, (0, 359), key=n)

            elif n in ForBackdropStyle.POINT_KEY:
                b = h - 1 if n in (
                        ok.START_X,
                        ok.END_X
                    ) else w - 1
                g3 = sb(p, (0, b), key=n)
                self._point_box.append(event_box)

            elif n == ok.INTENSITY:
                g3 = sb(p, (0, 1000), key=n)

            elif n == ok.MODE:
                g3 = RComboBox(p, key=n, opt=Mode.names())

            elif n == ok.NAME:
                g3 = REntry(p, n)

            elif n == ok.NOISE_SEED:
                g3 = sb(p, (1, 100000), key=n)

            elif n == ok.OFFSET:
                g3 = sb(p, (0, self.stat.radius), key=n)

            elif n in (ok.OFFSET_X, ok.OFFSET_Y):
                b = ((h, w)[(
                    ok.OFFSET_X, ok.OFFSET_Y).index(n)])

                b = min(b, 4096)
                g3 = sb(p, (-b, b), key=n)

            elif n == ok.OPACITY:
                g3 = sb(p, (0, 100), key=n)

            elif n in (ok.PANE_HEIGHT, ok.PANE_WIDTH):
                g3 = sb(p, (5, self.stat.radius), key=n)

            elif n == ok.PATTERN:
                q1 = pdb.gimp_patterns_get_list(None)[1]
                g3 = cb(p, key=n, opt=q1)

            elif n == ok.POWER:
                g3 = sb(p, (0, 180), key=n)

            elif n == ok.SAMPLE_POINTS:
                g3 = sb(p, (2, 24), key=n)

            elif n == ok.SAMPLE_RADIUS:
                g3 = sb(p, (1, 12), key=n)

            elif n == ok.ROTATE:
                g3 = sb(p, (-359, 359), key=n)

            elif n in (ok.ROW, ok.COLUMN, ok.COLUMN_1, ok.COLUMN_2):
                b = w / cell_w if n == ok.ROW else h / cell_w
                g3 = sb(p, (1, b), key=n)

            elif n == ok.THRESHOLD:
                g3 = sb(p, (0, 1), key=n, is_float=1, q1=(.01, .1))

            elif n == ok.SAMPLE_VECTOR:
                g3 = cb(p, key=n, opt=ForGradient.VECTOR)

            g1.both(g2.g, g3.g)
            g3.set_value(a)

            if isinstance(g3, rb):
                g3 = rr

            self.controls.append(g3)
            q.append(g1)
            self.reduce_color()

    def _randomize_widgets(self, _):
        """Randomize the variables."""
        d = self._creator.rand(self._get_data())

        self._creator.preview_changed()
        self.update_controls(d)
        self.preset_is_undefined()
        self._update_widget_visibility(self._gradient_type_widget)

    def _update_widget_visibility(self, g):
        """
        The end points are not necessary for a shape-burst gradient type.

        g: widget
        """
        if g:
            if g.key == OptionKey.GRADIENT_TYPE:
                if g.get_value() in ForGradient.SHAPE_BURST:
                    [i.hide() for i in self._point_box]

                else:
                    [i.show() for i in self._point_box]

    def cancel(self, *_):
        """The user canceled the window."""
        self.close()

    def do_job(self, *_):
        """Called when the user activates the Accept Button."""
        d = self._get_data()

        self._creator.prep(d)
        self.close()
        self.stat.cancel = 0

    def draw_window(self):
        """
        Draw the windows widgets.

        Is part of the UI window template.
        """
        self.controls = []
        q = []
        internal = None
        g = gtk.VBox()
        k = self._session_key

        if k == SessionKey.FILL_LIGHT_SHADOW:
            n1 = ForPreset.KEY_LIGHT_COMPLIMENT
            self.d = self._compliment_key_light()
            internal = [[n1, self.d]]

        else:
            n1 = ForWidget.LAST_USED if self.stat.session[k] != \
                Session.default[k] else PresetKey.DEFAULT

        if k == SessionKey.COLORED_GRID:
            d = deepcopy(self.d)
            d[OptionKey.ROTATE] = 45
            internal = [[ForPreset.COLORED_DIAMONDS, d]]

        self._draw_widgets(g, q)

        # preview and randomize:
        g1, _ = self._add_box(g)
        g2 = RButton("Preview", self._draw_preview)
        g3 = RButton("Randomize", self._randomize_widgets)

        self.keep((g2, g3))
        q.append(g1)
        g1.both(g2.g, g3.g)
        self.reduce_color()

        # default and presets:
        d = {
                PresetKey.FOLDER: self.stat.preset_folder,
                PresetKey.NAME: k,
                PresetKey.PARENT: self.win
            }

        if internal:
            d[PresetKey.INTERNAL] = internal

        self.preset = PresetSubSession(d, self.stat)
        g1, _ = self._add_box(g)
        g2 = self.preset_menu = GroupPreset(
            None,
            self.on_preset_change,
            k,
            self._get_data,
            self.win,
            self.preset)

        q.append(g1)
        g2.box.both(g2.save_b.g, g2.del_b.g)
        g2.box.pack()
        g1.left.add(g2.label.g)
        g1.both(g2.g, g2.box.g)
        self.reduce_color()
        g2.set_value(n1)
        g2.verify_del_button()

        # cancel and accept:
        g1, _ = self._add_box(g)
        g2 = RButton("Cancel", self.cancel)
        g3 = RButton("Accept", self.accept)

        self.keep((g2, g3))
        q.append(g1)
        g1.both(g2.g, g3.g)
        [g4.pack() for g4 in q]
        self.win.add(g)

    def on_preset_change(self, _, d):
        """
        Called when the user makes a selection in the preset ComboBox.

        Loads the preset.

        d: preset dict
        """
        g = self.preset_menu
        if g.get_text() != ForWidget.UNDEFINED:
            OZ.pass_version(d, Session.default[self._session_key])
            self.update_controls(d)
            self._creator.preview_changed()
            self._update_widget_visibility(self._gradient_type_widget)

    def on_widget_change(self, g):
        """
        Called when a widget changes.

        g: widget
        """
        if not UI.loading:
            self._creator.preview_changed()
            self.preset_is_undefined()
            self._update_widget_visibility(g)
