#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_wig import Wig
import gtk


class RButton(Wig):
    """This is a custom GTK Button."""

    def __init__(self, n, p, pad_x=0, align=(0, 0, 1, 0)):
        """
        n: Button label
        p: callback function
        pad_x: index to padding
        """
        w = ForWidget.MARGIN
        w1, w2 = w / 2, w / 4
        g = self.g = gtk.Alignment(*align)
        g1 = gtk.Button(n)

        Wig.__init__(self, p, widget=g1)
        g1.connect('clicked', self.callback)
        g.add(g1)

        if not isinstance(pad_x, int):
            g.set_padding(*pad_x)

        elif pad_x:
            x = pad_x - 1
            g.set_padding((
                    w1, w2, w2, w1)[x],
                    (0, 0, w, w1)[x],
                    w,
                    w
                )
