#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script type: Python-fu
Script Title: Roller
Tested on GIMP version: 2.10.22; Windows 10, 64 bit; GTK 2.28.7

What is Does:
    Creates image compositions like wallpaper.

Where The Script Installs:
    See the how-to file.

Get the latest version: github.com/gummycowboy
"""
from copy import deepcopy
from gimpfu import pdb
from roller_base import Comm, OZ
from roller_constant import (
        ForBackdropStyle,
        ForCell,
        ForFormat,
        ForLayer,
        ForWidget,
        FormatKey,
        LayerKey,
        PickleKey,
        PresetKey,
        SessionKey,
        UIFormatKey,
        UIKey,
        WindowKey
    )

from roller_button import RButton
from roller_combobox import RComboBox
from roller_backdrop_image import BackdropImage
from roller_backdrop_style_nexus import BackdropStyleNexus
from roller_check_menu import CheckMenu
from roller_effect_nexus import EffectNexus
from roller_eventbox import REventBox
from roller_format_list import GroupFormatList
from roller_fu import Lay, Sel
from roller_group_preset import GroupPreset
from roller_label import RLabel
from roller_layout import Layout, Images, Cell
from roller_preset_session import PresetSession
from roller_radio import RRadio
from roller_radio_button import RRadioButton
from roller_session import Format, Session
from roller_spin_button import RSpinButton
from roller_splitter import Splitter
from roller_ui import UI
from roller_ui_format import UIFormat
import gimpfu as fu
import gtk
import os
import platform
import pygtk
pygtk.require("2.0")

program_title = "Roller 1.30"


class UIMain(UI):
    """This is the script's main window."""

    def __init__(self, stat):
        """
        This is where the main GTK event loop takes place.

        stat: Stat
        """
        self.stat = stat
        if self._verify_preset_folder():
            self._load_last_session()
            self._layout = Layout(stat)
            Images.get_img()

            self.backdrop_images = Images.format_img_list[:]
            d = {
                UIKey.ON_RETURN: self.do_job,
                UIKey.WINDOW_POSITION: WindowKey.MAIN,
                UIKey.WINDOW_TITLE: program_title}

            UI.__init__(self, d)
            gtk.main()

    def _draw_backdrop_group(self, g):
        """
        Draw the format group.

        g: container
        """
        p = self.on_widget_change
        g1 = self.bd_style_m = RComboBox(
                p,
                key=SessionKey.BACKDROP_STYLE,
                opt=BackdropStyleNexus.names,
                pad_x=1
            )
        g.add(g1.g)

    def _draw_format_group(self, g):
        """
        Draw the format group.

        g: container
        """
        self.format_list = GroupFormatList(g, self)

    def _draw_layout_group(self, g):
        """
        Draw the layout group.

        g: container
        d: dict
        """
        g1 = self.show_b = RButton("Show Layout", self._show_layout, pad_x=4)
        g2 = self.layout_m = CheckMenu(
            self.on_widget_change,
            "Layout Options",
            SessionKey.LAYOUT_OPTION,
            deepcopy(Session.default[SessionKey.LAYOUT_OPTION]))

        g.add(g1.g)
        g.add(g2.g)

    def _draw_preset_group(self, g):
        """
        Draw the preset group.

        g: container
        d: dict
        """
        self.preset_menu = GroupPreset(
            g,
            self.on_preset_change,
            "Session",
            self.return_session,
            self.win,
            self.preset)

    def _draw_process_group(self, g):
        """
        Draw the process group.

        g: container
        d: dict
        """
        p = self.on_widget_change
        g1 = self.cancel_b = RButton("Cancel", self.close, pad_x=1)
        g2 = self.render_b = RButton("Render", self.accept, pad_x=2)
        g3 = Splitter(pad_x=1)
        g4 = RRadioButton(p, "Manual", SessionKey.AUTOMATE, None)
        g5 = RRadioButton(p, "Auto: Last Used", SessionKey.AUTOMATE, g4.wig)
        g6 = RRadioButton(p, "Auto: Randomized", SessionKey.AUTOMATE, g4.wig)
        self.auto_r = RRadio((g4, g5, g6), SessionKey.AUTOMATE)

        g3.both(g4.g, g5.g)
        g3.left.add(g6.g)
        g3.pack()
        g.add(g1.g)
        g.add(g2.g)
        g.add(g3.g)

    def _draw_resolution_group(self, g):
        """
        Draw the resolution group.

        g: container
        d: dict
        """
        q = ForCell.MIN_CELL_SPAN, 100000
        w = ForWidget.MARGIN
        p = self.on_widget_change
        g1 = self.width_sb = RSpinButton(
            p, q, q1=(10, 100), key=SessionKey.WIDTH, pad_x=1)

        g2 = self.height_sb = RSpinButton(
            p, q, q1=(10, 100), key=SessionKey.HEIGHT, pad_x=2)

        g.add(RLabel("Width:", (0, 0, w, 0)).g)
        g.add(g1.g)
        g.add(RLabel("Height:", (w / 2, 0, w, 0)).g)
        g.add(g2.g)

    def _load_last_session(self):
        """Load the last Session file or the default settings."""
        n = self.last_used_file = OZ.get_preset_path(
            "Session", ForWidget.LAST_USED, self.stat.preset_folder)

        d = Session.load_file({
                PickleKey.FILE: n,
                PickleKey.SHOW_ERROR: 0
            })

        if d > 0:
            self.stat.session = deepcopy(d)
            e = self.last_session = deepcopy(d)
            e[PresetKey.PRESET] = self.stat.session[PresetKey.PRESET] = \
                ForWidget.LAST_USED
            UI.win.update(self.stat.session[SessionKey.WINDOW])

        else:
            self.last_session = None
            self.stat.session = deepcopy(Session.default)
            self.stat.session[SessionKey.LAYOUT_OPTION] = {}

    def _merge_shadow(self, k):
        """
        Copy the drop shadow and merges it with another layer.

        This is used by translucent layers that blur behind and
        need the to adjust their backgrounds to correspond with the shadows.

        k: layer key
        """
        sk = SessionKey
        j = self.stat.render
        format_layer = Lay.get_active_format_layer(self.stat)
        z = Lay.search(format_layer, k, is_err=0)

        if z:
            if Lay.pixels(z):
                z1 = Lay.selectable(j, z, ForLayer.INHERIT_DICT)

                Sel.item(j, z1)

                sel = Sel.save(j)

                Lay.bury(j, z1)
                for k1 in (
                            sk.DROP_SHADOW,
                            sk.FILL_LIGHT_SHADOW,
                            sk.KEY_LIGHT_SHADOW
                        ):
                    z1 = Lay.search(format_layer, k1, is_err=0)
                    if z1:
                        Sel.kopy(z1)

                        z1 = Lay.paste(j, z)

                        Sel.load(j, sel)

                        z = Lay.merge(j, z1)
                        Sel.kleer(j, z)

    def on_format_list_change(self, *_):
        """
        Called when the format list changes.

        Is part of the GroupFormatList class template.
        """
        if not UI.loading:
            # Re-order the list:
            q = self.format_list.get_value()
            q1 = []

            for q2 in q:
                # new format list order:
                q1.append(self.stat.session[SessionKey.FORMAT_LIST][q2[1]])

            self.stat.session[SessionKey.FORMAT_LIST] = q1

            self.format_list.set_indices()
            self.preset_is_undefined()

    def _render(self):
        """Render the form."""
        m = 0
        s = self.stat.size
        self.stat.auto = self.stat.session[SessionKey.AUTOMATE]

        if self._layout.layout_background:
            self._layout.remove_background()

            if self.stat.has_layout:
                pdb.gimp_item_set_visible(self._layout.layout_group, 0)

            # The layout is invalid if the render size changed:
            if s != (self.stat.render.width, self.stat.render.height):
                m = 1
                pdb.gimp_image_scale_full(
                        self.stat.render,
                        self.stat.width,
                        self.stat.height,
                        fu.INTERPOLATION_LINEAR
                    )

            z = Lay.new(self.stat.render, ForLayer.BACKDROP)
            Lay.place(self.stat.render, z, a=1)

        else:
            self._layout.do_new_render()
            Lay.add(self.stat.render, ForLayer.BACKDROP)
            pdb.gimp_display_new(self.stat.render)

        self._render_backdrop()

        if not self.stat.cancel:
            self._render_format()

        if not self.stat.cancel:
            Sel.none(self.stat.render)
            Lay.activate(
                self.stat.render, Lay.get_backdrop_layer(self.stat.render))

            if m:
                self._layout.remove_layout_group()
            Lay.tidy(self.stat.render)

    def _render_backdrop(self):
        """
        Create the backdrop layer.

        Return a style name.
        """
        sk = SessionKey
        bsn = BackdropStyleNexus
        stat = self.stat
        style = stat.session[sk.BACKDROP_STYLE]

        # Transparency isn't in the session dict:
        e = stat.session[style] if style in stat.session else {}

        if style != ForBackdropStyle.TRANSPARENCY:
            BackdropImage(stat.session[sk.BACKDROP_IMAGE], stat)

        if style != sk.BACKDROP_IMAGE and not stat.cancel:
            bsn.obj[bsn.names.index(style)](e, stat)

        z = Lay.get_backdrop_layer(stat.render)

        if z.mask:
            z.remove_mask(fu.MASK_APPLY)

        if stat.cancel:
            z.name = "Canceled " + z.name

    def _render_effect(self, d):
        """
        Create a 3D effect for the images.

        d: format dict
        """
        effect = d[FormatKey.EFFECT]

        if effect != ForFormat.NONE:
            p = EffectNexus.obj[EffectNexus.names.index(effect)]
            p(self.stat.session[effect], self.stat)
        if self.stat.cancel:
            z = Lay.get_active_format_layer(self.stat)
            z.name = z.name + "Canceled"

    def _render_format(self):
        """
        Render each format in the session's format list.

        Place images and add 3D effects by rendering
        from the bottom of the Format list to the top.
        """
        stat, render = self.stat, self.stat.render
        format_list = stat.session[SessionKey.FORMAT_LIST]
        start = len(format_list) - 1
        Images.next_x = 0

        for x in range(start, -1, -1):
            if not stat.cancel:
                stat.format_count += 1
                self._layout.pix = 0
                d = format_list[x]
                row, col = d[FormatKey.ROW], d[FormatKey.COLUMN]
                cell = Cell(d, stat)

                #  Place images:
                for r in range(row):
                    for c in range(col):
                        if cell.has_image(r, c, d):
                            j = Layout.get_image_reference(r, c, d)
                            j.r, j.c = r, c
                            j.rot = Layout.get_rotate(r, c, d)
                            self._layout.place_image(j, d, cell)
                if self._layout.pix:
                    z = Lay.eat(render, self._layout.image_group)
                    z.name = Lay.get_layer_name(LayerKey.IMAGE, stat)
                    a = 1 if stat.has_layout else 0
                    z1 = Lay.group(
                            render,
                            Lay.get_layer_name(d[FormatKey.NAME], stat),
                            a=a
                        )

                    Lay.order(render, z, z1)

                    z2 = self._layout.blur_behind_layer
                    if z2:
                        # Make blur behind opaque and arrange the layer:
                        z3 = Lay.selectable(render, z, ForLayer.INHERIT_DICT)

                        Sel.item(render, z3)
                        Sel.kleer(render, z2)
                        Lay.bury(render, z3)
                        Lay.order(render, z2, z1, a=1)
                        z2.name = Lay.get_layer_name(
                            LayerKey.BLUR_BEHIND, stat)

                    self._render_effect(d)
                    if not stat.cancel:
                        if z2:
                            self._merge_shadow(FormatKey.BLUR_BEHIND)
                        self._merge_shadow(LayerKey.BLURRED_BACKGROUND)

    def _set_render_size(self):
        """
        Update the session dictionary with the current resolution values.

        Ensure that format and layout have the current state.
        """
        self.stat.session[SessionKey.WIDTH] = self.width_sb.get_value()
        self.stat.session[SessionKey.HEIGHT] = self.height_sb.get_value()

    def _show_layout(self, *_):
        """Called when the user activated the Show Layout Button."""
        self._layout.show()

    def _verify_preset_folder(self):
        """
        The external directory is where preset and session files are stored.

        The script uses the user's home
        directory to create a storage folder.

        Return a result flag. It is set to true if the directory is verified.
        """
        go = n1 = 0
        n = platform.system()

        if n == "Linux":
            n1 = u"/home/user/.GIMP/Roller/profiles/"

        elif n == "Darwin":
            n1 = u"/Library/Application Support/GIMP/Roller"

        elif n == "Windows":
            n1 = u"AppData\\Local\\GIMP\\Roller"

        if n1:
            try:
                n = self.stat.preset_folder = os.path.join(
                    os.path.expanduser("~"), n1)
                _, go = OZ.ensure_dir(n)

            except Exception as ex:
                Comm.show_err(ex)

        else:
            Comm.show_err("The operating system isn't supported by Roller.")
        return go

    def create_format(self, n):
        """
        Create a new format.

        Call from the GroupFormatList when the
        user activated the New Format Button.

        Is part of the GroupFormatList class template.

        n: name of the format.
        """
        d = deepcopy(Format.default)
        d[FormatKey.NAME] = n

        self.stat.session[SessionKey.FORMAT_LIST].append(d)
        self.edit_format()

    def delete_format(self, x):
        """
        Delete a format from the format list.

        Is part of the GroupFormatList class template.

        x: int
            index in format list
        """
        self.stat.session[SessionKey.FORMAT_LIST].pop(x)

    def do_job(self, *_):
        """Called when the user activates the Render Button."""
        self.stat.cancel = 0

        self._set_render_size()

        for g in self.controls:
            if g.key != SessionKey.FORMAT_LIST:
                self.stat.session[g.key] = g.get_value()

        self.close()
        self._render()

        self.stat.session[SessionKey.WINDOW] = deepcopy(UI.win)
        if self.stat.session != self.last_session and not self.stat.cancel:
            self.stat.session[PresetKey.PRESET] = ForWidget.LAST_USED
            OZ.pickle_dump({
                    PickleKey.DATA: self.stat.session,
                    PickleKey.FILE: self.last_used_file
                })

    def draw_window(self):
        """
        Draw the window's widgets.

        Is part of the UI window template.
        """
        self.preset = PresetSession({
                PresetKey.FOLDER: self.stat.preset_folder,
                UIKey.PARENT: self.win
            })

        g = gtk.VBox()
        q = (
            self._draw_format_group,
            self._draw_preset_group,
            self._draw_backdrop_group,
            self._draw_layout_group,
            self._draw_resolution_group,
            self._draw_process_group)

        q1 = (
                "Format",
                "Preset",
                "Backdrop Style",
                "Layout",
                "Resolution",
                "Process"
            )

        for i, p in enumerate(q):
            if not i % 2:
                same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

            box = REventBox(self.color)
            g1 = gtk.VBox()

            g1.add(RLabel(q1[i] + ":", (2, 0, 4, 0)).g)
            box.add(g1)
            p(g1)
            same_size.add_widget(box)
            self.reduce_color()

            # For some reason I have to get widgets in order to keep them:
            wig = same_size.get_widgets()
            if i % 2:
                # Add row of same size widgets:
                g2 = gtk.HBox()

                [g2.add(g3) for g3 in reversed(wig)]
                g.add(g2)

        self.win.add(g)
        self.controls = (
            self.format_list,
            self.layout_m,
            self.bd_style_m,
            self.preset_menu,
            self.width_sb,
            self.height_sb,
            self.auto_r)
        self.update_controls(self.stat.session)

    def edit_format(self):
        """
        Switch to the format editor window for the selected format.

        Is part of the GroupFormatList class template.

        a: unused
        """
        self._format_index = self.format_list.items[
            self.format_list.get_sel_x()][1]

        self._set_render_size()
        UIFormat(
            {
                UIKey.FEEDBACK: self.get_uiformat,
                UIFormatKey.FORMAT_INDEX: self._format_index,
                UIKey.LAYOUT: self._layout,
                UIKey.PARENT: self.win,
                UIKey.STAT: self.stat
            })

    def get_uiformat(self, x):
        """
        Called when the user accepted the format window.

        x:  format index
        """
        if x is not None:
            n = self.stat.session[SessionKey.FORMAT_LIST][x][FormatKey.NAME]

            # Ensure layer keys don't conflict with user layer names:
            for n1 in ForLayer.UNICODE_KEY:
                n = n.replace(n1, "")

            self.stat.session[SessionKey.FORMAT_LIST][x][
                    FormatKey.NAME] = n = n.strip()
            self.format_list.rename(x, n)

        self.format_list.select_item(self._format_index)
        self.preset_is_undefined()

    def on_preset_change(self, _, d):
        """
        Called because the preset menu changed display value.

        d: preset dict
        """
        if self.preset_menu.get_text() != ForWidget.UNDEFINED:
            e = deepcopy(Session.default)

            # SessionKey.WINDOW isn't checked by ‟pass_version”:
            e[SessionKey.WINDOW] = {}

            OZ.pass_version(d, e)

            for e in d[SessionKey.FORMAT_LIST]:
                OZ.pass_version(e, Format.default, is_format=1)

            self.stat.session = self.load_controls(d)
            UI.win.update(self.stat.session[SessionKey.WINDOW])

    def on_widget_change(self, g):
        """
        A widget changed.

        g: widget
        """
        if not UI.loading:
            if isinstance(g, RRadioButton):
                g = self.auto_r

            self.stat.session[g.key] = g.get_value()

            self.preset_is_undefined()

    def return_session(self):
        """Used to get session data for saving."""
        self.stat.session[SessionKey.WINDOW] = deepcopy(UI.win)
        return self.stat.session
