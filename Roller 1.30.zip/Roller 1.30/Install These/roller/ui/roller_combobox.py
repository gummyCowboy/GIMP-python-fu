#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForWidget
from roller_combo import RCombo
import gtk


class RComboBox(RCombo):
    """This ComboBox displays options and has a separator."""

    def __init__(self, p, **d):
        """
        p: callback function
        d: dict
        """
        RCombo.__init__(self, p, gtk.ComboBox, **d)
        self.wig.connect('changed', self.callback)
        self.wig.set_row_separator_func(self.set_mode_separator)

    def set_mode_separator(self, model, itr):
        """
        Returns true if the current item being
        populated in the list is a separator.

        model: gtk.ListStore
        itr: gtk.iter
        """
        n = model.get_value(itr, 0)
        return ForWidget.LIST_SEPARATOR in n
