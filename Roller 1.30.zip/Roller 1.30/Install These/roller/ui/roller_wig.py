#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import WidgetKey
import gtk


class Wig:
    """This is the base widget for the custom widgets."""

    def __init__(self, p, **d):
        """
        Has widget factored functions and attributes.

        Sub-widgets need to init Wig before connecting events.

        p: callback function
        d: widget dict
        """
        self._callback = p
        self.wig = d[WidgetKey.WIDGET]
        self.key = d[WidgetKey.KEY] if WidgetKey.KEY in d else None

        # attached label widget:
        self.label = d[WidgetKey.LABEL] if WidgetKey.LABEL in d else None

    def callback(self, *_):
        """
        The widget changed or was activated.

        Call the widget's feedback function.
        """
        self._callback(self)

    def enable(self, *_):
        """
        Make the widget operational.

        If the widget has an attached label,
        then it is also enabled.
        """
        self.wig.set_sensitive(1)
        if self.label:
            self.label.set_sensitive(1)

    def disable(self, *_):
        """
        Make the widget inoperable.

        If the widget has an attached label,
        then it is also disabled.
        """
        self.wig.set_sensitive(0)
        if self.label:
            self.label.set_sensitive(0)
