#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import LayerKey, OptionKey, SessionKey
from roller_drop_shadow import DropShadow
from roller_effect import Effect
from roller_fu import Lay, Sel
import gimpfu as fu


class ColoredBoard(Effect):
    """Create a an colored edge around an image(s)."""
    name = SessionKey.COLORED_BOARD

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        Effect.__init__(self, d, stat)
        if not stat.cancel and self.has_room:
            DropShadow({}, stat, q=(SessionKey.COLORED_BOARD, LayerKey.IMAGE))

    def do(self, d):
        """
        Draws the colored board.

        Is part of an Interactive class template.

        d: sub-session dict
        """
        ok = OptionKey
        j = self.stat.render
        z = Lay.selectable(j, Lay.get_active_image(self.stat), d)

        Sel.item(j, z)
        Sel.grow(j, d[ok.BORDER_WIDTH], d[ok.BORDER_TYPE])
        Sel.item(j, z, op=fu.CHANNEL_OP_SUBTRACT)

        n = Lay.get_layer_name(self.name, self.stat)
        z1 = Lay.add(j, n, z=self.active.format, a=1)

        Sel.fill(z1, d[ok.COLOR_1])
        Lay.bury(j, z)
        Lay.anti(j, z1)
