#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_constant import ForBackdropStyle, OptionKey, SessionKey
from roller_border_line import BorderLine
from roller_fu import Lay, Sel
import gimpfu as fu


class WireFence(BorderLine):
    """Add a wire framework to BorderLine with waves."""
    name = SessionKey.WIRE_FENCE
    width_low, width_high = 3, 15
    filler_width_low, filler_width_high = 20, 60

    def __init__(self, d, stat):
        """
        d: sub-session dict
        stat: Stat
        """
        BorderLine.__init__(
                self,
                d,
                stat,
                name=SessionKey.WIRE_FENCE,
                framer=self.select_wire,
                filler=lambda *args: None
            )

    def select_wire(self, d):
        """
        Draw the wire framework.

        The framework will later mesh with BorderLine.

        Is part of the RenderHub class template.

        d: sub-session dict

        Add the selection to current selection.
        """
        j = self.stat.render
        ok = OptionKey
        border_sel = Sel.save(j)
        z = Lay.add(j, self.name, z=self.group)

        Sel.none(j)

        # Set the layer size to the image size with ‟color_fill”:
        Lay.color_fill(z, (255, 255, 255))
        Sel.all(j)
        pdb.plug_in_mosaic(
                j,
                z,
                d[ok.MESH_SIZE],
                1,
                d[ok.WIRE_THICKNESS],
                d[ok.NEATNESS],
                0,
                d[ok.LIGHT_ANGLE],
                .0,
                1,
                1,
                ForBackdropStyle.MESH_TYPE.index(d[ok.MESH_TYPE]),
                0,
                0
            )

        Sel.isolate(j, z, self.fill_sel)

        # Erase the white:
        pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
        Sel.item(j, z)
        Sel.feather(j, 1)
        Sel.load(j, border_sel, opt=fu.CHANNEL_OP_ADD)
        Lay.bury(j, z)
