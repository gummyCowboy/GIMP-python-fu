#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_border_line import BorderLine
from roller_constant import OptionKey, SessionKey
from roller_fu import Lay, Sel
import gimpfu as fu


class CirclePunch(BorderLine):
    """Add a round holes to a frame that fits around a BorderLine frame."""
    name = SessionKey.CIRCLE_PUNCH
    width_low, width_high = 3, 15
    filler_width_low, filler_width_high = 20, 60

    def __init__(self, d, stat):
        """
        d: dict
            sub-session dict

        stat: Stat
            global variables
        """
        BorderLine.__init__(
                self,
                d,
                stat,
                name=SessionKey.CIRCLE_PUNCH,
                framer=self.make_line_sel,
                filler=lambda *args: None
            )

    def draw_circles(self, j, z, d):
        """
        Draw circles on the rotated layer.

        j: GIMP image
            target image

        z: layer
            target layer

        d: dict
            sub-session dict
        """
        ok = OptionKey
        x = y = 0
        w, h = j.width, j.height
        diameter = d[ok.CIRCLE_DIAMETER]
        w1 = int(diameter * 1.12)
        x1 = triangle_hieight = int(w1 * .8660254)
        y = 0
        x = diameter / 2

        while y < h:
            pdb.gimp_ellipse_select(
                    j,
                    0,
                    y,
                    diameter,
                    diameter,
                    fu.CHANNEL_OP_ADD,
                    True,
                    False,
                    0.
                )
            y += w1

        y = w1 / 2

        while y < h:
            pdb.gimp_ellipse_select(
                    j,
                    x1,
                    y,
                    diameter,
                    diameter,
                    fu.CHANNEL_OP_ADD,
                    True,
                    True,
                    1.
                )
            y += w1

        Sel.fill(z, (0, 0, 0))

        _, x, y, x1, _ = pdb.gimp_selection_bounds(j)
        a = x1 - x
        last_iter = 0

        while 1:
            Sel.kopy(z)

            a *= 2
            z = Lay.paste(j, z)
            x = x1 + triangle_hieight - diameter

            Lay.move(z, x, 0)

            if a > w:
                last_iter += 1

            z = Lay.merge(j, z)

            Sel.item(j, z)

            _, x, y, x1, _ = pdb.gimp_selection_bounds(j)
            if last_iter == 2:
                break
        return z

    def make_line_sel(self, d):
        """
        Modify the current selection with selected circles.

        Add the circle selection to the border selection
        within the bounds of the filler selection.

        d: dict
            sub-session dict
        """
        j = self.stat.render
        border_sel = Sel.save(j)
        z = z1 = Lay.add(j, self.id, self.group)
        z = self.do_rotated_layer(z, d, self.draw_circles)

        Sel.item(j, z)
        sel = Sel.save(j)

        Sel.load(j, self.fill_sel)
        Sel.load(j, sel, opt=fu.CHANNEL_OP_SUBTRACT)
        Sel.grow(j, 1, 1)
        Sel.feather(j, 1)
        Lay.bury(j, z)
        Lay.bury(j, z1)
        Sel.load(j, border_sel, opt=fu.CHANNEL_OP_ADD)
