#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant import ForLayer
from roller_fu import Lay


class Active(object):
    """
    This new-style class stores layer
    references and serves preview production.

    Preview operations work by duplicating a wip layer
    which is either a format group layer or a single layer.
    """
    FORMAT = 'format'
    LAYER = 'layer'

    # Is either the format group or the layer:
    WIP = 'wip'

    def __init__(self, stat, layer_key, clone=None):
        """
        stat: Stat
        layer_key: layer key
        clone: the active WIP layer
        """
        self.d = {
                Active.FORMAT: None,
                Active.LAYER: None,
                Active.WIP: None
            }

        if layer_key == ForLayer.BACKDROP:
            # backdrop layer:
            z = clone if clone else Lay.get_backdrop_layer(stat.render)
            self.d[Active.LAYER] = self.d[Active.WIP] = z

        elif layer_key == ForLayer.FORMAT:
            # format layer:
            z = clone if clone else Lay.get_active_format_layer(stat)
            self.d[Active.FORMAT] = self.d[Active.WIP] = z

        else:
            # sub-format layers:
            z = self.d[Active.FORMAT] = Lay.get_active_format_layer(stat)
            z = clone if clone else Lay.search(z, layer_key, is_err=False)
            self.d[Active.LAYER] = self.d[Active.WIP] = z

    @property
    def format(self):
        """Return the active format group layer."""
        return self.d[Active.FORMAT]

    @format.setter
    def format(self, z):
        """
        Set the active format group layer.

        z: layer
        """
        self.d[Active.FORMAT] = self.d[Active.WIP] = z

    def hide(self):
        """Hide the active clone-able layer."""
        if self.d[Active.WIP]:
            Lay.hide(self.d[Active.WIP])

    @property
    def layer(self):
        """Return the active layer which could be an original or a clone."""
        return self.d[Active.LAYER]

    @layer.setter
    def layer(self, z):
        """
        Set the active layer and WIP layer.

        z: layer
        """
        self.d[Active.LAYER] = self.d[Active.WIP] = z

    def show(self):
        """Show the active item."""
        if self.d[Active.WIP]:
            Lay.show(self.d[Active.WIP])

    @property
    def wip(self):
        """Return the wip layer."""
        return self.d[Active.WIP]
