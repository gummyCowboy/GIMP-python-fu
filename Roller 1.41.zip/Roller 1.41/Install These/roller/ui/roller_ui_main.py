#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_base import Comm, OZ
from roller_constant import (
        ForBackdropStyle,
        ForCell,
        ForFormat,
        ForLayer,
        ForWidget,
        FormatKey,
        LayerKey,
        PickleKey,
        PresetKey,
        SessionKey,
        UIKey,
        WindowKey
    )

from roller_button import RollerButton
from roller_combobox import RollerComboBox
from roller_backdrop_image import BackdropImage
from roller_backdrop_style_nexus import BackdropStyleNexus
from roller_effect_nexus import EffectNexus
from roller_eventbox import REventBox
from roller_format_list import GroupFormatList
from roller_fu import Lay, Sel
from roller_group_layout_option import GroupLayoutOption
from roller_group_preset import GroupPreset
from roller_label import RollerLabel
from roller_layout import Layout, RollerImage
from roller_navigation_list import NavigationList
from roller_preset_session import PresetSession
from roller_radio import RRadio
from roller_radio_button import RollerRadioButton
from roller_session import Format, Session
from roller_spin_button import RollerSpinButton
from roller_splitter import Splitter
from roller_ui import UI
from roller_ui_format import UIFormat
import gimpfu as fu
import gtk
import os
import platform
import pygtk
pygtk.require("2.0")

program_title = "Roller 1.41"


class UIMain(UI):
    """This is the script's main window."""

    GROUP_LABEL = (
            "Format",
            "Backdrop Style",
            "Resolution",
            "Layout Option",
        )

    def __init__(self, stat):
        """
        This is where the main GTK event loop takes place.

        stat: Stat
            global variables
        """
        self.stat = stat
        self.is_invalid_layout = True
        if self._verify_preset_folder():
            self._load_last_session()
            self._load_window_pose()
            self._layout = Layout(stat)
            RollerImage.collect_images()

            self.group_box = []
            self.switch_group_box = self.group_visibility = None
            self.backdrop_images = RollerImage.image_list[:]
            d = {
                    UIKey.ON_RETURN: self.do_job,
                    UIKey.STAT: stat,
                    UIKey.WINDOW_KEY: WindowKey.MAIN,
                    UIKey.WINDOW_TITLE: program_title
                }

            UI.__init__(self, d)
            gtk.main()

    def _draw_backdrop_group(self, g):
        """
        Draw the format group.

        g: GTK container
        """
        w = ForWidget.MARGIN
        p = self.on_widget_change
        g1 = self.bd_style_m = RollerComboBox(
                p,
                key=SessionKey.BACKDROP_STYLE,
                opt=BackdropStyleNexus.names,
                padding=(0, w / 2, w, w)
            )
        g.add(g1.alignment)

    def _draw_format_group(self, g):
        """
        Draw the format group.

        g: GTK container
        """
        self.format_list = GroupFormatList(g, self)

    def _draw_layout_group(self, g):
        """
        Draw the layout group.

        g: GTK container
        """
        self.group_layout_option = GroupLayoutOption(
                self.on_layout_option_change,
                SessionKey.LAYOUT_OPTION,
                g,
                self.stat
            )

    def _draw_multiple_groups(self, g):
        """
        Draw the format groups.
        Hide the groups that aren't selected.

        g: gtk container
            group box
        """
        q = (
                self._draw_format_group,
                self._draw_backdrop_group,
                self._draw_resolution_group,
                self._draw_layout_group,
            )

        self.group_visibility = [0] * (len(q) + 1)
        self.switch_group_box = g
        for x, p in enumerate(q):
            g = gtk.VBox()
            self.group_box.append(g)
            g.add(RollerLabel(
                UIMain.GROUP_LABEL[x] + ":",
                padding=(2, 0, 4, 0)).alignment)
            p(g)

    def _draw_navigation_group(self, g):
        """
        Draw the navigation list.

        g: GTK container
            container for the list
        """
        g1 = NavigationList(g, self)
        g1.set_value(UIMain.GROUP_LABEL)

    def _draw_preset_group(self, g):
        """
        Draw the preset group.

        g: GTK container
        """
        self.preset_menu = GroupPreset(
                g,
                self.on_preset_change,
                "Session",
                self.return_session,
                self.win,
                self.preset,
                self.stat
            )

    def _draw_process_group(self, g):
        """
        Draw the process group.

        g: GTK container
        """
        w = ForWidget.MARGIN
        w1 = w / 2
        p = self.on_widget_change
        q = []
        q.append(RollerButton(
                "Cancel",
                self.close,
                padding=(w1, 0, w, w)
            ))

        q.append(RollerButton(
                "Show Layout",
                self._show_layout,
                padding=(0, 0, w, w)
            ))

        q.append(RollerButton(
                "Render",
                self.accept,
                padding=(0, 0, w, w)
            ))

        self.cancel_b = self.show_b = self.render_b = q
        g2 = Splitter(padding=(w1, w, w, w))
        g3 = RollerRadioButton(p, "Manual", SessionKey.AUTOMATE, None)
        g4 = RollerRadioButton(
                p,
                "Auto: Last Used",
                SessionKey.AUTOMATE,
                g3.wig
            )

        g5 = RollerRadioButton(
                p,
                "Auto: Randomized",
                SessionKey.AUTOMATE,
                g3.wig
            )

        self.auto_r = RRadio((g3, g4, g5), SessionKey.AUTOMATE)

        g2.both(g3.alignment, g4.alignment)
        g2.left.add(g5.alignment)
        g2.pack()

        for i in q:
            g.pack_start(i.alignment, expand=False)
        g.pack_start(g2.container, expand=False)

    def _draw_resolution_group(self, g):
        """
        Draw the resolution group.

        g: GTK container
        """
        limit = ForCell.MIN_CELL_SPAN, 100000
        w = ForWidget.MARGIN
        p = self.on_widget_change
        q = []
        q.append(RollerLabel("Width:", padding=(0, 0, w, 0)))
        q.append(RollerSpinButton(
                p,
                limit,
                step=(10, 100),
                key=SessionKey.WIDTH,
                padding=(0, 0, w, w)
            ))

        q.append(RollerLabel("Height:", padding=(w / 2, 0, w, 0)))
        q.append(RollerSpinButton(
                p,
                limit,
                step=(10, 100),
                key=SessionKey.HEIGHT,
                padding=(0, w, w, w)
            ))

        self.width_sb, self.height_sb = q[1], q[3]
        for i in q:
            g.pack_start(i.alignment, expand=False)

    def _load_last_session(self):
        """Load the last Session file or the default settings."""
        pk = PickleKey
        stat = self.stat
        n = self.last_used_file = OZ.get_preset_path(
            u"Session", ForWidget.LAST_USED, stat.preset_folder)

        d = Session.load_file({
                pk.FILE: n,
                pk.SHOW_ERROR: 0
            })

        if d > 0:
            stat.session = deepcopy(d)
            e = self.last_session = deepcopy(d)
            e[PresetKey.PRESET] = stat.session[PresetKey.PRESET] = \
                ForWidget.LAST_USED

        else:
            self.last_session = None
            stat.session = deepcopy(Session.default)
            stat.session[SessionKey.LAYOUT_OPTION] = {}

    def _load_window_pose(self):
        """Load the window position dictionary if it exists."""
        pk = PickleKey
        stat = self.stat
        n = self.window_pose_file = OZ.get_preset_path(
            u"Window Position", "", stat.preset_folder)

        d = OZ.pickle_load({
                pk.FILE: n,
                pk.SHOW_ERROR: 0
            })

        if d > 0:
            stat.window_pose = deepcopy(d)
            self.last_window_pose = deepcopy(d)

        else:
            self.last_window_pose = {}

    def _merge_shadow(self, k):
        """
        Copy the drop shadow and merges it with another layer.

        This is used by translucent layers that blur behind and
        need the to adjust their backgrounds to correspond with the shadows.

        k: string
            layer key
        """
        sk = SessionKey
        j = self.stat.render
        format_layer = Lay.get_active_format_layer(self.stat)
        z = Lay.search(format_layer, k, is_err=0)

        if z:
            if Lay.has_pixel(j, z):
                z1 = Lay.selectable(j, z, ForLayer.INHERIT_DICT)

                Sel.item(j, z1)

                sel = Sel.save(j)

                Lay.bury(j, z1)
                for k1 in (
                            sk.DROP_SHADOW,
                            sk.FILL_LIGHT_SHADOW,
                            sk.KEY_LIGHT_SHADOW
                        ):
                    z1 = Lay.search(format_layer, k1, is_err=0)
                    if z1:
                        Sel.kopy(z1)

                        z1 = Lay.paste(j, z)

                        Sel.load(j, sel)

                        z = Lay.merge(j, z1)
                        Sel.kleer(j, z)

    def _render(self):
        """
        Render the form.

        First, render the backdrop.
        Second, step through the formats starting from the
        bottom of the format stack. Lastly, delete the layout
        if it is invalid and select the backdrop layer.
        """
        stat = self.stat
        stat.auto = stat.session[SessionKey.AUTOMATE]

        if self._layout.layout_background:
            self._layout.remove_background()

            if stat.has_layout:
                pdb.gimp_item_set_visible(self._layout.layout_group, 0)

            # The layout is invalid if the render size changed:
            if stat.size != self._layout.layout_size:
                self.is_invalid_layout = True
                pdb.gimp_image_scale_full(
                        stat.render,
                        stat.width,
                        stat.height,
                        fu.INTERPOLATION_LINEAR
                    )

            z = Lay.new(stat.render, ForLayer.BACKDROP)
            Lay.place(stat.render, z, a=1)

        else:
            self._layout.do_new_render()
            Lay.add(stat.render, ForLayer.BACKDROP)
            pdb.gimp_display_new(stat.render)

        self._render_backdrop()

        if not stat.cancel:
            self._render_format()

        if not stat.cancel:
            Sel.none(stat.render)
            Lay.activate(
                stat.render, Lay.get_backdrop_layer(stat.render))

            if self.is_invalid_layout and stat.has_layout:
                self._layout.remove_layout_group()
            Lay.tidy(stat.render)

    def _render_backdrop(self):
        """
        Create the backdrop layer.

        Return a style name.
        """
        sk = SessionKey
        bsn = BackdropStyleNexus
        stat = self.stat
        style = stat.session[sk.BACKDROP_STYLE]

        # Transparency isn't in the session dict:
        e = stat.session[style] if style in stat.session else {}

        if style != ForBackdropStyle.TRANSPARENCY:
            BackdropImage(stat.session[sk.BACKDROP_IMAGE], stat)

        if style != sk.BACKDROP_IMAGE and not stat.cancel:
            bsn.obj[bsn.names.index(style)](e, stat)

        z = Lay.get_backdrop_layer(stat.render)

        if z.mask:
            z.remove_mask(fu.MASK_APPLY)
        if stat.cancel:
            z.name = "Canceled " + z.name

    def _render_effect(self, d):
        """
        Create a 3D effect for the images.

        d: dict
            format dict
        """
        effect = d[FormatKey.EFFECT]

        if effect != ForFormat.NONE:
            p = EffectNexus.obj[EffectNexus.names.index(effect)]
            p(self.stat.session[effect], self.stat)
        if self.stat.cancel:
            z = Lay.get_active_format_layer(self.stat)
            z.name = z.name + " Canceled"

    def _render_format(self):
        """
        Render each format in the session's format list.

        Place images and add 3D effects by rendering
        from the bottom of the Format list to the top.
        """
        nk = LayerKey
        stat, render = self.stat, self.stat.render
        format_list = stat.session[SessionKey.FORMAT_LIST]
        start = len(format_list) - 1
        RollerImage.next_x = 0

        for x in range(start, -1, -1):
            if not stat.cancel:
                stat.format_count += 1
                self._layout.init_format_references()
                d = format_list[x]
                row, col = d[FormatKey.ROW], d[FormatKey.COLUMN]
                self._layout.calc_cell_table(d)

                #  Place images:
                for r in range(row):
                    for c in range(col):
                        if self._layout.cell_has_image(r, c, d):
                            j = Layout.get_image_reference(r, c, d)
                            j.r, j.c = r, c
                            j.rot = Layout.get_rotate(r, c, d)
                            self._layout.place_image(j, d)
                if self._layout.pix:
                    z = Lay.eat(render, self._layout.image_group)
                    z.name = Lay.get_layer_name(nk.IMAGE, stat)
                    a = 1 if stat.has_layout else 0
                    z1 = Lay.group(
                            render,
                            Lay.get_layer_name(d[FormatKey.NAME], stat),
                            a=a
                        )

                    Lay.order(render, z, z1)

                    z2 = self._layout.blur_behind_layer

                    if z2:
                        # Make blur behind opaque and arrange the layer:
                        z3 = Lay.selectable(render, z, ForLayer.INHERIT_DICT)

                        Sel.item(render, z3)
                        Sel.kleer(render, z2)
                        Lay.bury(render, z3)
                        Lay.order(render, z2, z1, a=1)
                        z2.name = Lay.get_layer_name(
                            nk.BLUR_BEHIND, stat)

                    self._render_effect(d)
                    if not stat.cancel:
                        if z2:
                            self._merge_shadow(FormatKey.BLUR_BEHIND)
                        self._merge_shadow(nk.BLURRED_BACKGROUND)
                        z3 = Lay.search(
                            render, nk.BACKDROP_LIGHT, is_err=0)
                        if z3:
                            z = Lay.get_active_format_layer(stat)
                            Sel.item(render, z)
                            Lay.klear(render, z3)

    def _set_render_size(self):
        """
        Update the session dictionary with the current resolution values.

        Format and layout states use 'self.stat' to stay current.
        """
        self.stat.session[SessionKey.WIDTH] = self.width_sb.get_value()
        self.stat.session[SessionKey.HEIGHT] = self.height_sb.get_value()

    def _show_layout(self, *_):
        """Show a layout sketch-up."""
        self._layout.show()
        self.is_invalid_layout = False

    def _verify_preset_folder(self):
        """
        The external directory is where preset and session files are stored.

        The script uses the user's home
        directory to create a storage folder.

        Return a result flag. It is set to true if the directory is verified.
        """
        go = n1 = 0
        n = platform.system()

        if n == "Linux":
            n1 = u"/home/user/.GIMP/Roller/profiles/"

        elif n == "Darwin":
            n1 = u"/Library/Application Support/GIMP/Roller"

        elif n == "Windows":
            n1 = u"AppData\\Local\\GIMP\\Roller"

        if n1:
            try:
                n = self.stat.preset_folder = os.path.join(
                    os.path.expanduser("~"), n1)
                _, go = OZ.ensure_dir(n)

            except Exception as ex:
                Comm.show_err(ex)

        else:
            Comm.show_err("The operating system isn't supported by Roller.")
        return go

    def create_format(self, n):
        """
        Create a new format.

        Call from the GroupFormatList when the
        user activated the New Format Button.

        Is part of the GroupFormatList class template.

        n: string
            name of the format
        """
        d = deepcopy(Format.default)
        d[FormatKey.NAME] = n
        self.is_invalid_layout = True

        self.stat.session[SessionKey.FORMAT_LIST].append(d)
        self.edit_format()

    def delete_format(self, x):
        """
        Delete a format from the format list.

        Is part of the GroupFormatList class template.

        x: int
            index to format in format list
        """
        self.stat.session[SessionKey.FORMAT_LIST].pop(x)

    def do_job(self, *_):
        """Begin a render."""
        pk = PickleKey
        stat = self.stat
        stat.cancel = 0

        self._set_render_size()

        for g in self.controls:
            if g.key != SessionKey.FORMAT_LIST:
                stat.session[g.key] = g.get_value()

        self.close()
        self._render()

        if not stat.cancel:
            if stat.session != self.last_session:
                stat.session[PresetKey.PRESET] = ForWidget.LAST_USED
                OZ.pickle_dump({
                        pk.DATA: stat.session,
                        pk.FILE: self.last_used_file
                    })

            if stat.window_pose != self.last_window_pose:
                OZ.pickle_dump({
                        pk.DATA: stat.window_pose,
                        pk.FILE: self.window_pose_file
                    })

    def draw_window(self):
        """
        Draw the window's widgets.

        Is part of the UI window template.
        """
        self.preset = PresetSession({
                PresetKey.FOLDER: self.stat.preset_folder,
                UIKey.PARENT: self.win
            })

        g = gtk.VBox()
        q = (
                self._draw_navigation_group,
                self._draw_multiple_groups,
                self._draw_preset_group,
                self._draw_process_group
            )

        q1 = (
                "Navigation",
                "",
                "Session Preset",
                "Process"
            )

        for i, p in enumerate(q):
            if not i % 2:
                same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

            box = REventBox(self.color)
            g1 = gtk.VBox()

            if q1[i]:
                g1.add(
                    RollerLabel(q1[i] + ":", padding=(2, 0, 4, 0)).alignment)

            box.add(g1)
            p(g1)
            same_size.add_widget(box)
            self.reduce_color()

            # For some reason I have to get widgets in order to keep them:
            wig = same_size.get_widgets()
            if i % 2:
                # Add row of same size widgets:
                g2 = gtk.HBox()

                [g2.add(g3) for g3 in reversed(wig)]
                g.add(g2)

        self.win.add(g)

        self.controls = (
            self.format_list,
            self.group_layout_option,
            self.bd_style_m,
            self.preset_menu,
            self.width_sb,
            self.height_sb,
            self.auto_r)
        self.update_controls(self.stat.session)

    def edit_format(self):
        """
        Switch to the format editor window for the selected format.

        Is part of the GroupFormatList class template.
        """
        x = self.format_list.items[self.format_list.get_sel_x()][1]
        d = self.stat.session[SessionKey.FORMAT_LIST][x]
        e = deepcopy(d)

        self._set_render_size()
        UIFormat(
            {
                UIKey.FORMAT_DICT: e,
                UIKey.FORMAT_INDEX: x,
                UIKey.LAYOUT: self._layout,
                UIKey.PARENT: self.win,
                UIKey.STAT: self.stat
            })

        if d != e:
            d = e
            n = d[FormatKey.NAME]

            # Ensure layer keys don't conflict with user layer names:
            for n1 in ForLayer.UNICODE_KEY:
                n = n.replace(n1, "")

            n = d[FormatKey.NAME] = n.strip()
            self.format_list.rename(x, n)
            self.preset_is_undefined()
            self.is_invalid_layout = True
        self.format_list.select_item(x)

    def on_format_list_change(self, *_):
        """
        Update the format list with any changes.

        Is part of the GroupFormatList class template.
        """
        if not UI.loading:
            # Re-order the list:
            q = self.format_list.get_value()
            q1 = []

            for q2 in q:
                # new format list order:
                q1.append(self.stat.session[SessionKey.FORMAT_LIST][q2[1]])

            self.stat.session[SessionKey.FORMAT_LIST] = q1

            self.format_list.set_indices()
            self.preset_is_undefined()

    def on_layout_option_change(self, g):
        """
        Update the session dict to reflect a layout option change.

        g: widget
            the CheckButton that changed
        """
        if not UI.loading:
            self.stat.session[SessionKey.LAYOUT_OPTION][g.key] = g.get_value()

    def on_preset_change(self, _, d):
        """
        Process a loaded session file.

        Update the window widgets to show the newly loaded session dictionary.
        Fix the dictionary in the case of invalid or missing entries.

        d: dict
            preset dict
        """
        if self.preset_menu.get_text() != ForWidget.UNDEFINED:
            e = deepcopy(Session.default)

            OZ.pass_version(d, e)

            for e in d[SessionKey.FORMAT_LIST]:
                OZ.pass_version(e, Format.default, is_format=1)
            self.stat.session = self.load_controls(d)

    def on_widget_change(self, g):
        """
        A widget changed.

        Keep the session dictionary up-to-date with the window state.

        g: widget
            the widget that changed
        """
        if not UI.loading:
            if isinstance(g, RollerRadioButton):
                g = self.auto_r

            self.stat.session[g.key] = g.get_value()

            self.preset_is_undefined()

    def return_session(self):
        """Use to get session data for saving."""
        return self.stat.session
