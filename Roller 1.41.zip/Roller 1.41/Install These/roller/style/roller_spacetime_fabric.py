#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb
from roller_backdrop_style import BackdropStyle
from roller_constant import OptionKey, SessionKey
from roller_fu import Lay, Sel
from roller_colored_grid import ColoredGrid
import gimpfu as fu


class SpacetimeFabric(BackdropStyle):
    """Use wind to shred lines and make a fabric texture."""
    name = SessionKey.SPACETIME_FABRIC
    row = column = 1

    def __init__(self, d, stat):
        """d: sub-session dict"""
        BackdropStyle.__init__(self, d, stat)

    def do(self, d):
        """
        Make the backdrop style.

        Use a grid to establish line break-outs.

        Separate color components to create dimension and unity.

        Use wind to shred the lines and provide texture.

        Is part of a RenderHub class template.

        d: dict
            sub-session dict
        """
        ok = OptionKey
        j = self.stat.render
        z = Lay.clone(j, self.active.layer)

        d[ok.COLOR_1] = 255, 255, 255
        d[ok.COLOR_2] = 0, 0, 0
        d[ok.MODE] = "Normal"
        d[ok.OPACITY] = 100
        d[ok.ROTATE] = 0
        d[ok.THRESHOLD] = 1.
        d[ok.INVERT] = 0

        ColoredGrid(
                d,
                self.stat,
                name=self.name,
                layer_key=self.name,
                no_save=1
            )

        z = Lay.get_active(j)

        pdb.plug_in_edge(j, z, 10, 1, 4)

        w, h = self.stat.width / d[ok.COLUMN], self.stat.height / d[ok.ROW]
        w = min(w, h)
        w = max(1, w / 4)

        for _ in range(w):
            pdb.plug_in_dilate(
                    j,
                    z,
                    6,
                    0,
                    1.,
                    0,
                    0,
                    255
                )

        pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
        Sel.item(j, z)

        white_sel = Sel.save(j)

        Sel.none(j)
        Lay.bury(j, z)

        # Create three layers, one for each color:
        group = Lay.group(j, self.name)
        z = red = Lay.clone(j, self.active.layer)
        z.name = "Red"

        Lay.order(j, z, group)

        z = green = Lay.clone(j, z)
        z.name = "Green"
        z = blue = Lay.clone(j, z)
        z.name = "Blue"
        n = d[ok.COMPONENT]

        pdb.plug_in_colortoalpha(j, red, (0, 255, 255))
        pdb.plug_in_colortoalpha(j, green, (255, 0, 255))
        pdb.plug_in_colortoalpha(j, blue, (255, 255, 0))

        if n == "Red":
            z = red
            q = green, blue

        elif n == "Green":
            z = green
            q = red, blue

        else:
            z = blue
            q = red, green

        Sel.load(j, white_sel)
        Lay.klear(j, z, no_sel=0)
        Sel.none(j)

        w1 = max(2, w / 2)

        # Shred the edges of the top layer:
        for i in range(10):
            for i1 in range(4):
                z.name = n + str(i) + str(i1)
                pdb.plug_in_wind(j, z, 0, i1, w1, 1, 1)
                Lay.blur(j, z, 1.)

        Lay.order(j, z, group, a=0)

        # Add texture to bottom layers:
        for z in q:
            n = z.name
            for i in range(3):
                for i1 in range(4):
                    pdb.plug_in_wind(j, z, 0, i1, (50, 25, 12)[i], 1, 1)
                    Lay.blur(j, z, 1.5)
                    z.name = n + str(i) + str(i1)

            z = Lay.clone(j, z)

            pdb.plug_in_engrave(j, z, i + 2, 1)

            z.mode = fu.LAYER_MODE_BURN
            z = Lay.merge(j, z)

        z = Lay.eat(j, group)

        if d[ok.EMBOSS]:
            z = Lay.clone(j, z)
            pdb.plug_in_emboss(j, z, 45, 30., 1, 1)
            z.mode = fu.LAYER_MODE_OVERLAY
            z = Lay.merge(j, z)
        self.finish_style(z)
