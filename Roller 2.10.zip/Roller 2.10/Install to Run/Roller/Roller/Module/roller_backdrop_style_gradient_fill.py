#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import ForGradient as fg, OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb


class GradientFill:
    """Fill the backdrop with a gradient."""

    def __init__(self, one, make_opaque=False):
        """
        Do the Gradient Fill backdrop-style.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        j = stat.render.image
        self.session = one.session
        self.make_opaque = make_opaque
        z = RenderHub.do_rotated_layer(stat, one.z, one.d, self.do_job)
        z.mode, z.opacity = RenderHub.get_mode(one.d)
        z = Lay.merge(j, z)
        RenderHub.bump(j, z, one.d[ok.BUMP], merge=1)

    def do_job(self, j, z, d):
        """
        Draw a gradient.

        j: GIMP image
            with layer

        z: layer
            to receive gradient

        d: dict
            Has options.

        Return: layer
            with gradient
        """
        # Shape-burst methods require an opaque layer to work properly:
        s = self.session['size']
        x, y, x1, y1 = RenderHub.get_layer_points(d, s[0], s[1])

        if (
            d[ok.GRADIENT_TYPE] in fg.SHAPE_BURST
            or self.make_opaque
        ):
            pdb.gimp_selection_all(j)
            Sel.fill(z, (127, 127, 127))
            pdb.gimp_selection_none(j)
        return GradientFill.do_gradient(j, z, d, x, y, x1, y1)

    @staticmethod
    def do_gradient(j, z, d, x, y, x1, y1):
        """
        j: GIMP image
            with layer

        z: layer
            to receive gradient

        d: dict
            Has options.

        x, y: int
            start point

        x1, y1: int
            end point
        """
        RenderHub.set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_gradient_blend_color_space(
            fu.GRADIENT_BLEND_RGB_PERCEPTUAL
        )
        pdb.gimp_context_set_gradient(d[ok.GRADIENT])
        pdb.gimp_context_set_gradient_reverse(d[ok.REVERSE])
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(d[ok.GRADIENT_TYPE]),
            d[ok.OFFSET],
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            x,
            y,
            x1,
            y1
        )

        if d[ok.INVERT]:
            pdb.gimp_drawable_invert(z, 0)
        return z
