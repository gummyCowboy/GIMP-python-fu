#!/usr/bin/env python
# -*- coding: utf-8 -*-
KEY = 'key'


class LayerKey:
    """Has keys used to identify layers."""
    BACKDROP_LIGHT = "Backdrop Light"
    BLURRED_BACKGROUND = "Blurred Background"
    BUMP = "Bump"
    CELL_CAPTION = "Cell Caption"
    CELL_FRINGE = "Cell Fringe"
    CELL_PLAQUE = "Cell Plaque"
    CELL_PLAQUE_BLUR_BEHIND = "Cell Plaque Blur Behind"
    CORNER_TAPE = "Corner Tape"
    EDGE = "Edge"
    FILLER = "Filler"
    FORMAT = u"🌲 "
    FRAME = "Frame"
    FREE_CELL_CAPTION = "Free-Range Cell Caption"
    FREE_CELL_FRINGE = "Free-Range Cell Fringe"
    FREE_CELL_PLAQUE = "Free-Range Cell Plaque"
    FREE_CELL_PLAQUE_BLUR_BEHIND = "Free Cell Plaque Blur Behind"
    GRADIENT_PIPE = "Gradient Pipe"
    IMAGE = "Image"
    IMAGE_BLUR_BEHIND = "Image Blur Behind"
    LAYER_CAPTION = "Layer Caption"
    LAYER_FRINGE = "Layer Fringe"
    LAYER_PLAQUE = "Layer Plaque"
    LAYER_PLAQUE_BLUR_BEHIND = "Layer Plaque Blur Behind"
    METAL = "Metal"
    REFLECTION = "Reflection"
    SHADOW = "Shadow"
    STAIN = "Stain"
    TRANSPARENCY = "Transparency"


class ImageEffect:
    """Has objects used by image-effects."""
    APPLY = "Apply"

    class Key:
        """Has keys that identify an image-effect. Are option types."""
        BALL_JOINT = "Ball Joint"
        BORDER_LINE = "Border Line"
        BRUSH_PUNCH = "Brush Punch"
        CERAMIC_CHIP = "Ceramic Chip"
        CIRCLE_PUNCH = "Circle Punch"
        CLEAR_FRAME = "Clear Frame"
        COLORED_BOARD = "Colored Board"
        CORNER_TAPE = "Corner Tape"
        COSMETIC_PIPE = "Cosmetic Pipe"
        CUTOUT_PLATE = "Cutout Plate"
        DROP_SHADOW = "Drop Shadow"
        FEATHER_REDUCTION = "Feather Reduction"
        FILL_LIGHT_SHADOW = "Fill Light Shadow"
        FRAME_GRADIENT = "Frame Gradient"
        GRADIENT_LEVEL = "Gradient Level"
        GRADIENT_PIPE = "Gradient Pipe"
        IMAGE_EDGE_SHADOW = "Image Edge Shadow"
        IMAGE_SHADOW = "Image Shadow"
        INLAY_SHADOW = "Inlay Shadow"
        JAGGED_EDGE = "Jagged Edge"
        KEY_LIGHT_SHADOW = "Key Light Shadow"
        LINE_FASHION = "Line Fashion"
        MAZE_MIRROR = "Maze Mirror"
        NO_EFFECT = "No Effect"
        RAD_WAVE = "Rad Wave"
        RAISED_MAZE = "Raised Maze"
        ROUNDED_EDGE = "Rounded Edge"
        SHADOW = "Shadow"
        SQUARE_PUNCH = "Square Punch"
        STAINED_GLASS = "Stained Glass"
        IMAGE_EFFECT = "Image Effect"
        WIRE_FENCE = "Wire Fence"
        KEY_LIST = [
            BALL_JOINT,
            BORDER_LINE,
            BRUSH_PUNCH,
            CERAMIC_CHIP,
            CIRCLE_PUNCH,
            CLEAR_FRAME,
            COLORED_BOARD,
            CORNER_TAPE,
            COSMETIC_PIPE,
            CUTOUT_PLATE,
            DROP_SHADOW,
            FEATHER_REDUCTION,
            FILL_LIGHT_SHADOW,
            FRAME_GRADIENT,
            GRADIENT_LEVEL,
            GRADIENT_PIPE,
            IMAGE_EDGE_SHADOW,
            IMAGE_SHADOW,
            INLAY_SHADOW,
            JAGGED_EDGE,
            KEY_LIGHT_SHADOW,
            LINE_FASHION,
            MAZE_MIRROR,
            NO_EFFECT,
            RAD_WAVE,
            RAISED_MAZE,
            ROUNDED_EDGE,
            SHADOW,
            SQUARE_PUNCH,
            STAINED_GLASS,
            IMAGE_EFFECT,
            WIRE_FENCE
        ]

    # Identify effects that need to set the 'caster_key'
    # item in the shadow-effect dictionary when doing a render:
    CASTER_EFFECT = (
        Key.DROP_SHADOW,
        Key.FILL_LIGHT_SHADOW,
        Key.IMAGE_EDGE_SHADOW,
        Key.IMAGE_SHADOW,
        Key.INLAY_SHADOW,
        Key.KEY_LIGHT_SHADOW,
        Key.ROUNDED_EDGE
    )

    # Has layer id/key(s) that shadow-effects
    # need to make a unified-shadow-unit.
    # Each effect's shadow needs an entry:
    CAST = 'cast'

    EFFECT_STEPS = 'effect_steps'

    # Use for effects that make a copy of the image layer:
    IS_HIDE = 'is_hide'

    # Use with preview function to remove previous preview layers.
    # The key is an image effect key. The value is a tuple of
    # layer identifiers. Layers are identified with a layer key
    # and an entry in the LAYER_DICT:
    LAYERS = 'layers'

    nk = LayerKey
    K, K1, K2, K3, K4 = (
        Key.FRAME_GRADIENT,
        Key.KEY_LIGHT_SHADOW,
        Key.FILL_LIGHT_SHADOW,
        Key.IMAGE_EDGE_SHADOW,
        Key.DROP_SHADOW
    )
    PROPERTY = {
        Key.BALL_JOINT: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS:  (Key.BALL_JOINT, nk.FRAME),
        },
        Key.BORDER_LINE: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.BUMP, nk.FRAME, nk.STAIN),
        },
        Key.BRUSH_PUNCH: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.BUMP, nk.FRAME, nk.STAIN),
        },
        Key.CERAMIC_CHIP: {
            CAST: (nk.FILLER, nk.FRAME, nk.IMAGE),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.BUMP, nk.FRAME, nk.STAIN, nk.FILLER),
        },
        Key.CIRCLE_PUNCH: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.BUMP, nk.FRAME, nk.STAIN),
        },
        Key.CLEAR_FRAME: {
            CAST: (nk.IMAGE, nk.TRANSPARENCY),
            EFFECT_STEPS: [K4, K3],
            IS_HIDE: 0,
            LAYERS: (nk.BLURRED_BACKGROUND, nk.TRANSPARENCY),
        },
        Key.COLORED_BOARD: {
            CAST: (nk.IMAGE, Key.COLORED_BOARD),
            EFFECT_STEPS: [K4],
            IS_HIDE: 0,
            LAYERS:  (Key.COLORED_BOARD,),
        },
        Key.CORNER_TAPE: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS:  (Key.CORNER_TAPE, Key.DROP_SHADOW),
        },
        Key.COSMETIC_PIPE: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.FRAME,),
        },
        Key.CUTOUT_PLATE: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K4, K3],
            IS_HIDE: 0,
            LAYERS: (nk.FRAME,),
        },
        Key.DROP_SHADOW: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.DROP_SHADOW,),
        },
        Key.FEATHER_REDUCTION: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 1,
            LAYERS: (Key.FEATHER_REDUCTION,),
        },
        Key.FILL_LIGHT_SHADOW: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.FILL_LIGHT_SHADOW,),
        },
        Key.FRAME_GRADIENT: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (nk.BACKDROP_LIGHT, nk.EDGE, nk.METAL, nk.REFLECTION),
        },
        Key.GRADIENT_LEVEL: {
            CAST: (nk.IMAGE, Key.GRADIENT_LEVEL),
            EFFECT_STEPS: [K4, K3],
            IS_HIDE: 0,
            LAYERS: (Key.GRADIENT_LEVEL,),
        },
        Key.GRADIENT_PIPE: {
            CAST: (nk.IMAGE, Key.GRADIENT_PIPE),
            EFFECT_STEPS: [K4, K3],
            IS_HIDE: 0,
            LAYERS: (Key.GRADIENT_PIPE,),
        },
        Key.IMAGE_EDGE_SHADOW: {
            CAST: [],
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.IMAGE_EDGE_SHADOW,),
        },
        Key.IMAGE_SHADOW: {
            CAST: (nk.IMAGE,),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.IMAGE_SHADOW,),
        },
        Key.INLAY_SHADOW: {
            CAST: (nk.IMAGE,),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.INLAY_SHADOW,),
        },
        Key.JAGGED_EDGE: {
            CAST: (nk.IMAGE,),
            EFFECT_STEPS: [],
            IS_HIDE: 1,
            LAYERS: (Key.JAGGED_EDGE, nk.SHADOW),
        },
        Key.KEY_LIGHT_SHADOW: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (Key.KEY_LIGHT_SHADOW,),
        },
        Key.LINE_FASHION: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.BUMP, nk.FRAME, nk.STAIN),
        },
        Key.MAZE_MIRROR: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.BUMP, nk.FRAME, nk.STAIN),
        },
        Key.NO_EFFECT: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (),
        },
        Key.RAD_WAVE: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.BUMP, nk.FRAME, nk.STAIN),
        },
        Key.RAISED_MAZE: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.BUMP, nk.FRAME, nk.STAIN),
        },
        Key.ROUNDED_EDGE: {
            CAST: (nk.IMAGE,),
            EFFECT_STEPS: [K4],
            IS_HIDE: 0,
            LAYERS: (Key.ROUNDED_EDGE,),
        },
        Key.SHADOW: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (),
        },
        Key.SQUARE_PUNCH: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.BUMP, nk.FRAME, nk.STAIN),
        },
        Key.STAINED_GLASS: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (
                nk.BLURRED_BACKGROUND,
                nk.BUMP,
                nk.FILLER,
                nk.FRAME,
                nk.STAIN
            ),
        },
        Key.IMAGE_EFFECT: {
            CAST: (),
            EFFECT_STEPS: [],
            IS_HIDE: 0,
            LAYERS: (),
        },
        Key.WIRE_FENCE: {
            CAST: (nk.IMAGE, nk.FRAME),
            EFFECT_STEPS: [K, K1, K2, K3],
            IS_HIDE: 0,
            LAYERS: (nk.BUMP, nk.FRAME, nk.STAIN)
        }
    }

    # effect categories:
    MAIN = (
        Key.BALL_JOINT,
        Key.BORDER_LINE,
        Key.BRUSH_PUNCH,
        Key.CERAMIC_CHIP,
        Key.CIRCLE_PUNCH,
        Key.CLEAR_FRAME,
        Key.COLORED_BOARD,
        Key.CORNER_TAPE,
        Key.COSMETIC_PIPE,
        Key.CUTOUT_PLATE,
        Key.FEATHER_REDUCTION,
        Key.GRADIENT_LEVEL,
        Key.GRADIENT_PIPE,
        Key.IMAGE_SHADOW,
        Key.INLAY_SHADOW,
        Key.JAGGED_EDGE,
        Key.LINE_FASHION,
        Key.MAZE_MIRROR,
        Key.NO_EFFECT,
        Key.RAD_WAVE,
        Key.RAISED_MAZE,
        Key.ROUNDED_EDGE,
        Key.SQUARE_PUNCH,
        Key.STAINED_GLASS,
        Key.WIRE_FENCE
    )

    # Use with effect options in PortOption:
    SHADOW_CHOICE = (
        "None",
        Key.DROP_SHADOW,
        Key.INLAY_SHADOW
    )

    # These image effects duplicate the image layer as part of their
    # function. The duplicate image layer is to be deleted after a render:
    IMAGE_DUPLICATOR = Key.JAGGED_EDGE, Key.FEATHER_REDUCTION


class LayerId:
    """
    Pair layer-key names with a unicode-key symbol.

    Use for fast layer searches.
    """
    KEY = {
        ImageEffect.Key.CERAMIC_CHIP: u"❖",
        ImageEffect.Key.COLORED_BOARD: u"☺",
        ImageEffect.Key.CORNER_TAPE: u"`",
        ImageEffect.Key.DROP_SHADOW: u"☁",
        ImageEffect.Key.FEATHER_REDUCTION: u"☘",
        ImageEffect.Key.FILL_LIGHT_SHADOW: u"⚫",
        ImageEffect.Key.GRADIENT_LEVEL: u"❄",
        ImageEffect.Key.GRADIENT_PIPE: u"☉",
        ImageEffect.Key.IMAGE_EDGE_SHADOW: u"☾",
        ImageEffect.Key.IMAGE_SHADOW: u"✪",
        ImageEffect.Key.INLAY_SHADOW: u"★",
        ImageEffect.Key.JAGGED_EDGE: u"❀",
        ImageEffect.Key.KEY_LIGHT_SHADOW: u"⚪",
        ImageEffect.Key.ROUNDED_EDGE: u"♟",
        LayerKey.BACKDROP_LIGHT: u"☂",
        LayerKey.BLURRED_BACKGROUND: u"✾",
        LayerKey.BUMP: u"¤",
        LayerKey.CELL_CAPTION: u"©",
        LayerKey.CELL_FRINGE: u"◊",
        LayerKey.CELL_PLAQUE: u"☢",
        LayerKey.CELL_PLAQUE_BLUR_BEHIND: u"✺",
        LayerKey.EDGE: u"☠",
        LayerKey.FILLER: u"✤",
        LayerKey.FRAME: u"￭",
        LayerKey.FREE_CELL_CAPTION: u"♔",
        LayerKey.FREE_CELL_FRINGE: u"✸",
        LayerKey.FREE_CELL_PLAQUE: u"º",
        LayerKey.FREE_CELL_PLAQUE_BLUR_BEHIND: u"✯",
        LayerKey.IMAGE: u"❑",
        LayerKey.IMAGE_BLUR_BEHIND: u"□",
        LayerKey.LAYER_CAPTION: u"®",
        LayerKey.LAYER_FRINGE: u"✬",
        LayerKey.LAYER_PLAQUE: u"♦",
        LayerKey.LAYER_PLAQUE_BLUR_BEHIND: u"∞",
        LayerKey.METAL: u"❤",
        LayerKey.REFLECTION: u"⚔",
        LayerKey.SHADOW: u"♠",
        LayerKey.STAIN: u"☀",
        LayerKey.TRANSPARENCY: u"❍"
    }
