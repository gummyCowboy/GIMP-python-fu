#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_one_constant import (
    ForWidget,
    LayoutKey as nk,
    SessionKey as sk,
    WidgetKey as wk
)
from roller_one_preset import Preset
from roller_one_tip import Tip
from roller_widget import Widget
from roller_widget_box import RollerBox
from roller_widget_check_button import RollerCheckButton
import gtk

TOOLTIP = {
    nk.CELL_FRINGE: Tip.LAYOUT_FRINGE,
    nk.CELL_MARGINS: Tip.LAYOUT_MARGINS,
    nk.COORDINATES: Tip.LAYOUT_COORDINATES,
    nk.CORNERS: Tip.LAYOUT_CORNERS,
    nk.DIMENSIONS: Tip.LAYOUT_DIMENSIONS,
    nk.GRID: Tip.LAYOUT_GRID,
    nk.RATIOS: Tip.LAYOUT_RATIOS
}


class GroupLayoutOption(Widget):
    """Has a CheckButtons for selecting layout-preview options."""

    def __init__(self, **d):
        """
        Create a group of layout option CheckButtons.

        d: dict
            Has init values.
        """
        d[wk.KEY] = sk.LAYOUT_OPTION
        w = ForWidget.MARGIN
        w1 = w // 2
        self._box = RollerBox(gtk.HBox, padding=(w, w1, 0, 0))
        buttons = []
        self.layout_option_dict = {}

        Widget.__init__(self, self._box, **d)

        vbox_list = RollerBox(gtk.VBox), RollerBox(gtk.VBox)

        for k in Preset.default[sk.SESSION][sk.LAYOUT_OPTION]:
            buttons.append(
                RollerCheckButton(padding=(0, 0, w, w), text=k, **d)
            )
            self.layout_option_dict[k] = buttons[-1]
            if k in TOOLTIP:
                buttons[-1].set_tooltip_text(TOOLTIP[k])

        self._box.add(vbox_list[0])
        self._box.add(vbox_list[1])

        vbox = vbox_list[0]
        midpoint = len(buttons) // 2 + len(buttons) % 2

        for x, button in enumerate(buttons):
            if x == midpoint:
                vbox = vbox_list[1]
            vbox.add(button)
        self.container.add(self._box)

    def get_value(self):
        """
        Return a layout option dictionary so
        the settings can be saved and restored.
        """
        d = OrderedDict()

        for k in self.layout_option_dict:
            d[k] = self.layout_option_dict[k].get_value()
        return d

    def set_value(self, d):
        """
        Set the value of the CheckButton and is part of the Widget template.

        Verify the cell window opener button.

        d: dict
            layout option dict
        """
        [self.layout_option_dict[k].set_value(d[k]) for k in d]
