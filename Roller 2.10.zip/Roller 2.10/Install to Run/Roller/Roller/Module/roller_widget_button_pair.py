#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import ForWidget as fw
from roller_widget_box import RollerBox
from roller_widget_button import RollerButton
import gtk


class ButtonPair(gtk.Alignment):
    """Is an GTK HBox with two RollerButtons."""

    def __init__(self, **d):
        """
        Create an HBox with some buttons.

        d: dict
            Has init values.
        """
        super(gtk.Alignment, self).__init__()

        w1 = w2 = fw.MARGIN // 2
        self.key = None
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        hbox = RollerBox(gtk.HBox, align=(0, 0, 1, 0))
        q = d['text']
        q1 = d['button_action']
        self._update_window = d['on_widget_change']
        d['on_widget_change'] = self.on_button_action
        d['key'] = d['text'] = q[0]
        d['padding'] = w1, 0, 0, w1
        d['align'] = 0, 0, 1, 0

        if q1[0]:
            g = self.left_button = RollerButton(**d)
            self.left_button.button_action = q1[0]

        else:
            g = None
            w2 = 0

        d['key'] = d['text'] = q[1]
        d['padding'] = w1, 0, w2, 0
        g1 = self.right_button = RollerButton(**d)
        self.right_button.button_action = q1[1]

        for i in (g, g1):
            if i:
                hbox.pack_start(i, expand=1)
                if g:
                    same_size.add_widget(i.widget)
        self.add(hbox)

    def on_button_action(self, g):
        """
        Respond to user-click on one of the buttons.

        g: RollerButton
            Is responsible.
        """
        g.button_action(g)
        self._update_window(g)
