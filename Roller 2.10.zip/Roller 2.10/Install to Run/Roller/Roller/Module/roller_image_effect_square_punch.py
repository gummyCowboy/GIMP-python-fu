#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect_border_line import BorderLine
from roller_image_effect import ImageEffect
from roller_one_constant import OptionKey as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb


class SquarePunch(BorderLine):
    """Add square holes to a frame that fits around a BorderLine frame."""

    def __init__(self, one):
        """
        Do the Square Punch image-effect.

        one: One
            Has variables.
        """
        BorderLine.__init__(
            self,
            one,
            framer=self.make_line_sel,
            filler=lambda *args: None
        )

    def draw_lines(self, j, z, d):
        """
        Draw vertical and horizontal lines.

        j: GIMP image
            target image

        z: layer
            target layer

        d: dict
            Has options.
        """
        x = y = 0
        w, h = j.width, j.height
        z.mode, z.opacity = fu.LAYER_MODE_NORMAL, 100.
        w1, w2 = d[ok.LINE_WIDTH], d[ok.GAP_WIDTH]

        while x < w:
            Sel.rect(j, x, 0, w1, h, option=fu.CHANNEL_OP_ADD)
            x += w1 + w2
            x = min(x, w)

        while y < h:
            Sel.rect(j, 0, y, w, w1, option=fu.CHANNEL_OP_ADD)
            y += w1 + w2
            y = min(y, h)

        Sel.fill(z, (0, 0, 0))
        return z

    def make_line_sel(self, d):
        """
        Modify the current selection with the selected grid lines.

        Add the grid selection to the border selection
        within the bounds of the filler selection.

        d: dict
            Has options.

        Return: state of selection
            of render
        """
        j = self.stat.render.image
        sel = self.stat.save_render_sel()
        z = z1 = Lay.add(j, ek.CIRCLE_PUNCH, self.parent)
        z = RenderHub.do_rotated_layer(self.stat, z, d, self.draw_lines)

        Sel.isolate(j, z, self.fill_sel)
        Sel.item(j, z)
        Sel.grow(j, 1, 1)
        pdb.gimp_selection_feather(j, 1)
        pdb.gimp_image_remove_layer(j, z)
        pdb.gimp_image_remove_layer(j, z1)
        Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
