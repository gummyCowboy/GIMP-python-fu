#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import ImageEffect, LayerKey as nk
from roller_one import One
from roller_one_constant import OptionKey as ok, ShadowKey as sh
from roller_one_fu import Lay, Sel
from roller_one_preset import Preset
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import colorsys
import gimpfu as fu
import math

ek = ImageEffect.Key
LEFT, TOP, RIGHT, BOTTOM = range(4)


class FloorSample:
    """Has wedges colored by a gradient between two colors."""

    def __init__(self, one):
        """
        Draw the samples wedges.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        self.session = one.session
        d = one.d
        j = stat.render.image
        parent = one.z.parent
        n = nk.EDGE
        color, color1 = d[ok.COLOR_1], d[ok.COLOR_2]
        s = self.session['size']

        if d[ok.INVERT]:
            color = RenderHub.invert_color(color)
            color1 = RenderHub.invert_color(color1)

        lum = colorsys.rgb_to_hls(*color)[1]
        lum1 = colorsys.rgb_to_hls(*color1)[1]
        angle = 360. / d[ok.NUMBER_OF_SLICES]
        steps = d[ok.NUMBER_OF_SLICES]
        w, h = one.session['size']
        cx, cy = w // 2., h // 2.
        a = d[ok.STARTING_ANGLE]
        group = Lay.group(j, one.k, parent=parent)

        if lum > lum1:
            color, color1 = color1, color

        step = RenderHub.calc_gradient(color, color1, steps)
        x, y = RenderHub.get_point_on_rectangle(s, a)
        start_color = color
        e = Preset.get_default(ek.DROP_SHADOW)
        e[sh.SHADOW_COLOR] = d[ok.SHADOW_COLOR]
        e[sh.INTENSITY] = d[ok.INTENSITY]
        e[sh.SHADOW_BLUR] = d[ok.SHADOW_BLUR]
        name = Lay.get_layer_name(n, parent=parent)
        shadow = One(
            d=e,
            e={'caster_key': (n,)},
            k=n,
            stat=stat,
            parent=group
        )

        for spin in range(steps):
            a += angle
            a = a if a < 360 else a - 360
            a = a if a > 0 else a + 360
            x1, y1 = [int(i) for i in RenderHub.get_point_on_rectangle(s, a)]
            q = cx, cy, x, y
            end = start = None

            # Get the corner points in the arc.
            # The variables 'start' and 'end' are
            # the sides of the image-rectangle
            # that the arc begins and ends.
            #
            # start-point:
            for i in range(1):
                if x == w and y != h:
                    start = RIGHT
                    break

                if y == h:
                    if x != 0:
                        start = BOTTOM
                        break

                if x == 0:
                    if y != 0:
                        start = LEFT
                        break
                start = TOP

            # end-point:
            for i in range(1):
                if x1 == w:
                    if y1 != h:
                        end = RIGHT
                        break

                if y1 == h:
                    if x != 0:
                        end = BOTTOM
                        break

                if x1 == 0:
                    if y1 != 0:
                        end = LEFT
                        break
                end = TOP

            _x = start + 1

            # Add corner points along the span of the arc:
            if start != end:
                for i in range(4):
                    if _x > BOTTOM:
                        _x = 0

                    q += ((0, h), (0, 0), (w, 0), (w, h))[_x]

                    if _x == end:
                        break
                    _x += 1

            q += x1, y1

            Sel.polygon(j, q, option=fu.CHANNEL_OP_REPLACE)

            x, y = x1, y1
            z = Lay.add(j, name, parent=group)

            Sel.fill(z, color)

            if d[ok.INTENSITY] and d[ok.SHADOW_BLUR]:
                if spin > 0:
                    Shadow(shadow)
                    Lay.order(j, j.active_layer, group, offset=1)

            q1 = [0] * 3

            for i in range(3):
                b = step[i] * (spin + 1)
                q1[i] = start_color[i] + int(b)
            color = tuple(q1)

        z = Lay.merge_group(j, group)
        RenderHub.bump(j, z, d[ok.BUMP], merge=1)

    @staticmethod
    def get_point_on_rectangle(s, f):
        """
        Calculate an x, y coordinate for a point intersecting
        a ray, originating from the center of a rectangle,
        and ending at its defining lines.

        s: tuple or list
            size
            width, height
            of int

        f: float
            in degrees
            angle from center of the rectangle

        Return: tuple
            x, y
            of float or int
            the point on the rectangle
        """
        w, h = s
        f = math.radians(f)
        sine = math.sin(f)
        cosine = math.cos(f)

        # distance to the top or the bottom edge (from the center):
        dy = h / 2 if sine > 0 else h / -2

        # distance to the left or the right edge (from the center):
        dx = w / 2 if cosine > 0 else w / -2

        # (distance to the vertical line) < (distance to the horizontal line):
        if abs(dx * sine) < abs(dy * cosine):
            # Calculate distance to the vertical line:
            dy = (dx * sine) / cosine

        # (distance to the top or the bottom edge)
        # < (distance to the left or the right edge):
        else:
            dx = (dy * cosine) / sine
        return max(0., round(dx + w / 2., 0)), max(0., round(dy + h / 2., 0))
