#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
import gimpfu as fu
import gtk

# Often times keys will change with version changes by enumeration.

BACKDROP = "Backdrop"
BUMP = "Bump"
COLOR = "Color"
CRITERION = "Criteria"
DROP_SHADOW = "Drop Shadow"
END_X = "End X"
END_Y = "End Y"
FEATHER = "Feather"
FILL_LIGHT_SHADOW = "Fill Light Shadow"
GRADIENT_TYPE = "Gradient Type"
HAS_NO_BUMP = 0
INLAY_BLUR = "Inlay Shadow Blur"
INLAY_SHADOW = "Inlay Shadow"
INTENSITY = "Shadow Intensity"
INVERT = "Invert"
KEY_LIGHT_SHADOW = "Key Light Shadow"
LIST_SEPARATOR = "★"
MAKE_OPAQUE = "Make Opaque?"
MODE = "Paint Mode"
NONE = "None"
OFFSET = "Offset"
OFFSET_X = "Offset X"
OFFSET_Y = "Offset Y"
OPACITY = "Opacity"
REVERSE = "Reverse"
ROTATE = "Rotate"
SHADOW_BLUR = "Shadow Blur"
SHADOW_COLOR = "Shadow Color"
SHADOW_PAIR = "Shadow Pair"
START_X = "Start X"
START_Y = "Start Y"
STEPS = "Feather Steps"
THRESHOLD = "Threshold"
TRI_SHADOW = "Tri-Shadow"
TRIANGLE_DOWN = "Triangle, Facing Down"
TRIANGLE_LEFT = "Triangle, Facing Left"
TRIANGLE_RIGHT = "Triangle, Facing Right"
TRIANGLE_UP = "Triangle, Facing Up"


class BackdropStyleKey:
    """
    Has keys that identify a backdrop-style in the session-option (Opt) dict.
    """
    AVERAGE_COLOR = "Average Color"
    BACKDROP_IMAGE = "Backdrop Image"
    BACKDROP_STYLE = "Backdrop Style"
    COLOR_FILL = "Color Fill"
    COLORED_GRID = "Colored Grid"
    CRYSTAL_CAVE = "Crystal Cave"
    CORE_DESIGN = "Core Design"
    DARK_FORT = "Dark Fort"
    ETCH_SKETCH = "Etch Sketch"
    FLOOR_SAMPLE = "Floor Sample"
    LIGHT_SHAFT = "Light Shaft"
    GLASS_GAW = "Glass Gaw"
    GRADIENT_FILL = "Gradient Fill"
    GRID_WORK = "Grid Work"
    HONEY_BEE = "Honey Bee"
    IMAGE_GRADIENT = "Image Gradient"
    LOST_MAZE = "Lost Maze"
    MYSTERY_GRATE = "Mystery Grate"
    NOISE_RIFT = "Noise Rift"
    PATTERN_FILL = "Pattern Fill"
    RAINBOW_VALLEY = "Rainbow Valley"
    ROCKY_LANDING = "Rocky Landing"
    MAZE_BLEND = "Maze Blend"
    SPACETIME_FABRIC = "Spacetime Fabric"
    SPECIMEN_SPECKLE = "Specimen Speckle"
    SPIRAL_CHANNEL = "Spiral Channel"
    SQUARE_CLOUD = "Square Cloud"
    TRAILING_VINE = "Trailing Vine"
    KEY_LIST = (
        AVERAGE_COLOR,
        BACKDROP_IMAGE,
        BACKDROP_STYLE,
        COLOR_FILL,
        COLORED_GRID,
        CRYSTAL_CAVE,
        CORE_DESIGN,
        DARK_FORT,
        ETCH_SKETCH,
        FLOOR_SAMPLE,
        LIGHT_SHAFT,
        GLASS_GAW,
        GRADIENT_FILL,
        GRID_WORK,
        HONEY_BEE,
        IMAGE_GRADIENT,
        LOST_MAZE,
        MAZE_BLEND,
        MYSTERY_GRATE,
        NOISE_RIFT,
        PATTERN_FILL,
        RAINBOW_VALLEY,
        ROCKY_LANDING,
        SPACETIME_FABRIC,
        SPECIMEN_SPECKLE,
        SPIRAL_CHANNEL,
        SQUARE_CLOUD,
        TRAILING_VINE
    )


class BranchKey:
    """Has keys used to make a Branch."""
    CHANGE_OFFSHOOT_ITEM = 'change_offshoot_item'
    LABEL = 'label'
    MAKE_OPTION_GROUP = 'make_option_group'
    OFFSHOOT_ITEM = 'offshoot_item'
    TRUNK_ITEM = 'trunk_item'


class BrushKey:
    BRUSH = "Brush"
    ANGLE = "Angle"
    SIZE = "Size"
    HARDNESS = "Hardness"
    OPACITY = OPACITY
    SPACING = "Spacing"


class BumpKey:
    class Cloth:
        BLUR_X = "Blur X"
        BLUR_Y = "Blur Y"

    class Emboss:
        BUMP_DEPTH = "Bump Depth"
        BUMP_ELEVATION = "Bump Elevation"

    class Noise:
        NOISE = "Noise"


class CaptionKey:
    """Use with the caption presets."""
    SHADOW = 'shadow_1'
    CELL_CAPTION = "Cell Caption"
    CLIP_TO_CELL = 'clip_to_cell'
    COLOR = 'color'
    FONT = 'font'
    FREE_CELL_CAPTION = "Free-Range Cell Caption"
    JUSTIFICATION = 'justification'
    LAYER_CAPTION = "Layer Caption"
    LEADING_TEXT = 'leading_text'
    MARGIN = 'margin'
    OBEY_MARGINS = 'obey_margins'
    OPACITY = 'opacity'
    SIZE = 'size'
    START_NUMBER = 'start_number'
    STRIPE = 'stripe'
    TEXT = 'text'
    TRAILING_TEXT = 'trailing_text'
    TYPE = 'type'


class CellKey:
    """Has keys used by Free-Range Cell's Cell option group."""
    NAME = 'name'
    SHAPE = 'cell_shape'
    FIXED_HEIGHT = 'fixed_height'
    FIXED_POSITION_X = 'fixed_x'
    FIXED_POSITION_Y = 'fixed_y'
    FIXED_WIDTH = 'fixed_width'
    FRACTION_HEIGHT = 'fraction_height'
    FRACTION_POSITION_X = 'fraction_x'
    FRACTION_POSITION_Y = 'fraction_y'
    FRACTION_WIDTH = 'fraction_width'


class ForBackdropStyle:
    """Has values used by backdrop styles."""
    CARTOONY = "Cartoony"
    CLOCKWISE, COUNTER_CLOCKWISE = 0, 1
    COMPONENT = "Red", "Green", "Blue"
    COMPOSITION_FRAME = "Frame"
    DIAGONAL = "Diagonal"
    DIRECTION = "Clockwise", "Counter-Clockwise"
    FILLED = "Filled"
    FLIP_BOTH = "Flip Both Axis"
    HORIZONTAL = "Horizontal"
    HORIZONTAL_FLIP = "Horizontal Flip"
    MESH_TYPE = "Square", "Hexagon", "Octagon", "Triangle"
    NEWS_TYPE = "Dot", "Line", "Diamond", "Euclidian Dot", "PS-Diamond"
    NOISE_LAYER_MODE = (
        None,
        fu.LAYER_MODE_MULTIPLY,
        fu.LAYER_MODE_HARD_MIX,
        fu.LAYER_MODE_GRAIN_EXTRACT,
        fu.LAYER_MODE_HSL_COLOR
    )
    POINT_KEY = START_X, START_Y, END_X, END_Y
    PRISMATIC = "Prismatic"
    RANDOM = "Random"
    SCATTERED_CONNECTORS = "Scattered Connectors"
    SCATTERED_MAZES = "Scattered Mazes"
    SHOW_GRADIENT, SHOW_SAMPLE = 0, 1
    SYRUPY = "Syrupy"
    VERTICAL = "Vertical"
    VERTICAL_FLIP = "Vertical Flip"

    # dependent:
    GAP_TYPE = RANDOM, "Evenly Distributed"
    MAZE_TYPE = (
        SCATTERED_CONNECTORS,
        SCATTERED_MAZES,
        COMPOSITION_FRAME,
        FILLED
    )
    NOISE_MODE_LIST = NONE, "Dark", CARTOONY, SYRUPY, PRISMATIC
    SPIRAL_MOD_LIST = NONE, HORIZONTAL_FLIP, VERTICAL_FLIP, FLIP_BOTH
    VECTOR = VERTICAL, HORIZONTAL, DIAGONAL


class ForColor:
    """Has values used by color processing."""
    MAX_COLOR = 65535

    # colored button:
    ACTIVE_COLOR = gtk.gdk.Color(55000, 55000, 0)
    CELL_COLOR = gtk.gdk.Color(55000, 55000, MAX_COLOR)
    CONNECTOR_COLOR = gtk.gdk.Color(52000, 52000, MAX_COLOR)
    CONNECTED_COLOR = gtk.gdk.Color(MAX_COLOR, 0, 0)
    FOCUS_COLOR = gtk.gdk.Color(50000, 44000, MAX_COLOR)

    COLOR_TOOLTIP = " Red:\t{} \n Green:\t{} \n Blue:\t{} "
    HEADER_COLOR = 44000, 44000, MAX_COLOR
    LIST_CELL_COLOR = gtk.gdk.Color(54500, 60500, 54500)
    WHITE = gtk.gdk.Color(MAX_COLOR, MAX_COLOR, MAX_COLOR)
    MISSING_FILE = gtk.gdk.Color(MAX_COLOR, MAX_COLOR, MAX_COLOR // 2)


class ForFill:
    """
    Has values used by a fill process.

    Color Fill and Pattern Fill use criteria.
    """
    CRITERION_LIST = (
        "Composite",
        "Red",
        "Green",
        "Blue",
        "Hue",
        "Saturation",
        "Value",
        "Alpha",
        "LCH-Lightness",
        "LCH-Chroma",
        "LCH Hue"
    )


class ForFormat:
    """Has values used by format."""
    MISSING_ITEM = "Roller {} can't find a {}, {}."

    # tooltip types:
    BRUSH_TIP_TYPE = 'brush'
    BUMP_TIP_TYPE = 'bump'
    CELL_GRID_TIP_TYPE = 'cell_grid'
    IMAGE_TIP_TYPE = 'image'
    MARGIN_TIP_TYPE = 'margin'
    SHADOW_TIP_TYPE = 'shadow'
    STRIPE_TIP_TYPE = 'stripe'

    # option button:
    SELECT_FONT = "Choose a Font"

    # fringe layout enum:
    IS_BOTH_FRINGE, IS_CELL_FRINGE, IS_LAYER_FRINGE = 1, 2, 3

    class Caption:
        TOP_LEFT = "Top-Left"
        TOP_CENTER = "Top-Center"
        TOP_RIGHT = "Top-Right"
        MIDDLE_LEFT = "Middle-Left"
        CENTERED = "Centered"
        MIDDLE_RIGHT = "Middle-Right"
        BOTTOM_LEFT = "Bottom-Left"
        BOTTOM_CENTER = "Bottom-Center"
        BOTTOM_RIGHT = "Bottom-Right"
        JUSTIFICATION_LIST = (
            TOP_LEFT,
            TOP_CENTER,
            TOP_RIGHT,
            MIDDLE_LEFT,
            CENTERED,
            MIDDLE_RIGHT,
            BOTTOM_LEFT,
            BOTTOM_CENTER,
            BOTTOM_RIGHT
        )
        IMAGE_NAME = "Image Name"
        SEQUENCE_NUMBER = "Sequence Number"
        TEXT = "Text"
        CELL_TYPE_LIST = (
            NONE,
            LIST_SEPARATOR,
            TEXT,
            SEQUENCE_NUMBER,
            IMAGE_NAME
        )
        FREE_CELL_TYPE_LIST = NONE, IMAGE_NAME, TEXT
        LAYER_TYPE_LIST = NONE, TEXT
        NO_SEQUENCE_LIST = NONE, LIST_SEPARATOR, TEXT, IMAGE_NAME

    class Cell:
        # flag and enum; A zero enum is excluded as not double-spaced.
        # Use to type a double-spaced grid:
        NOT_SHIFT, SHIFT = 1, 2

        class Shape:
            CIRCLE_HORIZONTAL = "Circle, Aligned Horizontally"
            CIRCLE_VERTICAL = "Circle, Aligned Vertically"
            DIAMOND = "Diamond"
            ELLIPSE = "Ellipse"
            ELLIPSE_HORIZONTAL = "Ellipsis, Aligned Horizontally"
            ELLIPSE_VERTICAL = "Ellipsis, Aligned Vertically"
            ELLIPSE_LIST = ELLIPSE_HORIZONTAL, ELLIPSE_VERTICAL
            HEXAGON_HORIZONTAL = "Hexagon, Aligned Horizontally"
            HEXAGON_VERTICAL = "Hexagon, Aligned Vertically"
            HEXAGON = HEXAGON_HORIZONTAL, HEXAGON_VERTICAL
            RECTANGLE = "Rectangle"
            RHOMBUS = "Rhombus"
            SQUARE = "Square"
            DOUBLE = ELLIPSE_LIST + HEXAGON + (DIAMOND, RHOMBUS) + \
                (CIRCLE_VERTICAL, CIRCLE_HORIZONTAL)

            NORMAL_LIST = (
                SQUARE,
                CIRCLE_HORIZONTAL,
                CIRCLE_VERTICAL,
                HEXAGON_HORIZONTAL,
                HEXAGON_VERTICAL,
                RHOMBUS,
                TRIANGLE_DOWN,
                TRIANGLE_LEFT,
                TRIANGLE_RIGHT,
                TRIANGLE_UP
            )
            SHAPE_LIST = (
                RECTANGLE,
                DIAMOND,
                ELLIPSE_HORIZONTAL,
                ELLIPSE_VERTICAL,
                HEXAGON_HORIZONTAL,
                HEXAGON_VERTICAL,
                TRIANGLE_DOWN,
                TRIANGLE_LEFT,
                TRIANGLE_RIGHT,
                TRIANGLE_UP
            )
            HORIZONTAL_ALIGNED = ELLIPSE_HORIZONTAL, HEXAGON_HORIZONTAL
            VERTICAL_ALIGNED = ELLIPSE_VERTICAL, HEXAGON_VERTICAL

            # width/height ratios of an equilateral triangle:
            TRIANGLE_SCALE_RATIO_DOWN = .8660254
            TRIANGLE_SCALE_RATIO_UP = 1.1547005

    class Fringe:
        GRADIENT = "Gradient"
        IMAGE = "Image"
        MASK = "Mask"
        ONE_COLOR = "One Color"
        PATTERN = "Pattern"
        TWO_COLOR = "Two Color"
        TYPE = (
            NONE,
            LIST_SEPARATOR,
            GRADIENT,
            IMAGE,
            MASK,
            ONE_COLOR,
            PATTERN,
            TWO_COLOR
        )

    class Grid:
        CELL_COUNT = "Cell Count"
        CELL_SIZE = "Cell Size"
        SHAPE_COUNT = "Shape Count"
        TYPE_LIST = CELL_COUNT, CELL_SIZE, SHAPE_COUNT

        class Index:
            CELL_COUNT, CELL_SIZE, SHAPE_COUNT = 0, 1, 2

        class Pin:
            TOP_LEFT = "Top-Left"
            TOP_RIGHT = "Top-Right"
            BOTTOM_LEFT = "Bottom-Left"
            BOTTOM_RIGHT = "Bottom-Right"
            CENTER = "Center"
            PIN_LIST = CENTER, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT

            # A fixed-sized table has a pin-point:
            PINS_WITH_X_OFFSET = CENTER, TOP_RIGHT, BOTTOM_RIGHT
            PINS_WITH_Y_OFFSET = CENTER, BOTTOM_LEFT, BOTTOM_RIGHT

    class Image:
        COLOR = COLOR
        FIRST_IMAGE = "1st Image"
        FLUCTUATE_DECREMENT = "Fluctuate-Decrement"
        FLUCTUATE_INCREMENT = "Fluctuate-Increment"
        FOLDER_ORDER_LIST = "Ascending (A to Z)", "Descending (Z to A)"
        LAYER_ORDER_LIST = "Bottom-Up", "Top-Down"
        NEXT_CIRCULAR = "Next-Circular"
        NEXT_LINEAR = "Next-Linear"
        PATTERN = "Pattern"
        PREVIOUS_CIRCULAR = "Previous-Circular"
        PREVIOUS_LINEAR = "Previous-Linear"
        LAYER_TYPE = "Layer"

        # index-ordered:
        NEXT_TYPE = NEXT_LINEAR, NEXT_CIRCULAR
        PREVIOUS_TYPE = PREVIOUS_LINEAR, PREVIOUS_CIRCULAR
        FLUCTUATE_TYPE = FLUCTUATE_INCREMENT, FLUCTUATE_DECREMENT

        # Use with file selector:
        EXTENSION = (
            ".xcf",
            ".jpg", ".jpeg", ".jpe", ".jif", ".jfif", ".jfi",
            ".png",
            ".gif", ".webp",
            ".tiff", ".tif",
            ".psd",
            ".raw", ".arw", ".cr2", ".nrw", ".k25",
            ".bmp", ".dib",
            ".jp2", ".j2k", ".jpx", ".jpm", ".mj2",
            ".ico",
            ".svg",
            ".pdf"
        )

        class Type:
            FILE = 'file'
            FLUCTUATE = 'fluctuate'
            FOLDER = 'folder'
            IMAGE_NAME = 'image_name'
            NEXT = 'next'
            NONE = NONE
            NUMERIC_SEQUENCE = 'numeric_sequence'
            PREVIOUS = 'previous'

            AS_LAYERS_LIST = NUMERIC_SEQUENCE, IMAGE_NAME, FILE

            HAS_FORMAT = (
                NEXT,
                PREVIOUS,
                FLUCTUATE,
                NUMERIC_SEQUENCE,
                IMAGE_NAME,
                FILE,
                FOLDER,
                NONE
            )
            NO_FORMAT = NUMERIC_SEQUENCE, IMAGE_NAME, FILE, NONE

    class Margin:
        # four fixed-value, four fraction-of:
        MARGINS = 0, 0, 0, 0, 0., 0., 0., 0.

        class Index:
            TOP, BOTTOM, LEFT, RIGHT = range(4)

    class Mask:
        CHARACTER = "Character"
        CIRCLE = "Circle"
        CUT_CORNERS = "Cut Corners"
        DIAMOND = "Diamond"
        IMAGE = "Image"
        OVAL = "Oval"
        RECTANGLE = "Rectangle"
        RHOMBUS = "Rhombus"
        ROUNDED_CORNERS = "Rounded Corners"
        SQUARE = "Square"
        TYPE = [
            NONE,
            LIST_SEPARATOR,
            CHARACTER,
            CIRCLE,
            CUT_CORNERS,
            DIAMOND,
            IMAGE,
            OVAL,
            RECTANGLE,
            RHOMBUS,
            ROUNDED_CORNERS,
            SQUARE,
            TRIANGLE_DOWN,
            TRIANGLE_LEFT,
            TRIANGLE_RIGHT,
            TRIANGLE_UP
        ]

    class Place:
        LOCKED = "Locked"
        FILL_CELL = "Fill Cell"
        TRIM = "Trim"
        NUMERIC = "Numeric"
        NUMERIC_INDEX = 3
        TYPE = LOCKED, TRIM, FILL_CELL, NUMERIC
        FIXED_VALUE_INDEX, FRACTION_VALUE_INDEX, CROP_VALUE_INDEX = 3, 4, 5
        RESIZE_NUMERIC_INDEX = \
            FIXED_VALUE_INDEX, \
            FRACTION_VALUE_INDEX, \
            CROP_VALUE_INDEX

        # justification:
        BOTTOM = "Bottom"
        CENTER = "Center"
        LEFT = "Left"
        MIDDLE = "Middle"
        RIGHT = "Right"
        TOP = "Top"
        HORIZONTAL_OPTION = [LEFT, CENTER, RIGHT]
        VERTICAL_OPTION_LIST = [TOP, MIDDLE, BOTTOM]

    class Plaque:
        AVERAGE_COLOR = "Average Color"
        COLOR = COLOR
        GRADIENT = "Gradient"
        GRADIENT_TYPE = GRADIENT_TYPE
        GRADIENT_ANGLE = "Gradient Angle"
        IMAGE = "Image"
        PATTERN = "Pattern"
        TYPE = (
            NONE,
            LIST_SEPARATOR,
            AVERAGE_COLOR,
            COLOR,
            GRADIENT,
            IMAGE,
            PATTERN
        )

    class Shadow:
        # Use to convert a radio box choice to text:
        LOWER_SHADOWS = DROP_SHADOW, KEY_LIGHT_SHADOW, FILL_LIGHT_SHADOW
        SHADOW_OPTION = (
            DROP_SHADOW,
            INLAY_SHADOW,
            SHADOW_PAIR,
            TRI_SHADOW,
            NONE
        )


class ForGradient:
    """Has values used by gradients."""
    BOTTOM_CENTER_TO_TOP_CENTER = "Bottom-center to Top-center"
    BOTTOM_LEFT_TO_TOP_RIGHT = "Bottom-left to Top-right"
    BOTTOM_RIGHT_TO_TOP_LEFT = "Bottom-right to Top-left"
    MIDDLE_LEFT_TO_MIDDLE_RIGHT = "Middle-left to Middle-right"
    MIDDLE_RIGHT_TO_MIDDLE_LEFT = "Middle-right to Middle-left"
    RADIAL = "Radial"
    SPIRAL_CLOCKWISE = "Spiral-Clockwise"
    SPIRAL_COUNTER_CW = "Spiral-Counter-Clockwise"
    SQUARE = "Square"
    TOP_CENTER_TO_BOTTOM_CENTER = "Top-center to Bottom-center"
    TOP_LEFT_TO_BOTTOM_RIGHT = "Top-left to Bottom-right"
    TOP_RIGHT_TO_BOTTOM_LEFT = "Top-right to Bottom-left"
    FILL_DICT = {
        THRESHOLD: 1.,
        CRITERION: "Composite",
        MODE: "Normal",
        OPACITY: 100.
    }
    GRADIENT_ANGLE = (
        TOP_LEFT_TO_BOTTOM_RIGHT,
        TOP_CENTER_TO_BOTTOM_CENTER,
        TOP_RIGHT_TO_BOTTOM_LEFT,
        BOTTOM_LEFT_TO_TOP_RIGHT,
        BOTTOM_CENTER_TO_TOP_CENTER,
        BOTTOM_RIGHT_TO_TOP_LEFT,
        MIDDLE_LEFT_TO_MIDDLE_RIGHT,
        MIDDLE_RIGHT_TO_MIDDLE_LEFT
    )
    CENTER_X = (
        TOP_CENTER_TO_BOTTOM_CENTER,
        BOTTOM_CENTER_TO_TOP_CENTER
    )
    MIDDLE_Y = (
        MIDDLE_LEFT_TO_MIDDLE_RIGHT,
        MIDDLE_RIGHT_TO_MIDDLE_LEFT
    )
    GRADIENT_TYPE_LIST = (
        "Linear",
        "Bilinear",
        RADIAL,
        SQUARE,
        "Conical Symmetric",
        "Conical ASymmetric",
        "Shape-burst-Angular",
        "Shape-burst-Spherical",
        "Shape-burst-Dimpled",
        SPIRAL_CLOCKWISE,
        SPIRAL_COUNTER_CW
    )
    LEFT_X = (
        BOTTOM_LEFT_TO_TOP_RIGHT,
        MIDDLE_LEFT_TO_MIDDLE_RIGHT,
        TOP_LEFT_TO_BOTTOM_RIGHT
    )
    LINEAR_DICT = OrderedDict([
        (BUMP, {BUMP: HAS_NO_BUMP}),
        (GRADIENT_TYPE, "Linear"),
        (INVERT, 0),
        (MODE, "Normal"),
        (OFFSET, 0),
        (OPACITY, 100.),
        (REVERSE, 0),
        (ROTATE, 0.)
    ])
    SHAPE_BURST = (
        "Shape-burst-Angular",
        "Shape-burst-Spherical",
        "Shape-burst-Dimpled"
    )
    TOP_Y = (
        TOP_CENTER_TO_BOTTOM_CENTER,
        TOP_LEFT_TO_BOTTOM_RIGHT,
        TOP_RIGHT_TO_BOTTOM_LEFT
    )


class ForLayer:
    """Has values used by GIMP layers."""
    LAYER_BULLET = "• "
    BACKDROP = "Backdrop"
    FORMAT = "Format"
    BACKDROP_LIGHT_OPACITY = 6.

    # Opaque is on:
    MAKE_OPAQUE_DICT = {MAKE_OPAQUE: 1}


class ForLayout:
    """Has values used by Layout."""
    GRID_COLOR = 225, 220, 220
    BACKGROUND_COLOR = 0, 0, 0
    LAYER_MARGIN_COLOR = 40, 40, 40
    CELL_MARGIN_COLOR = 55, 50, 50
    PLAQUE_COLOR = 70, 70, 75
    FRINGE_COLOR = 90, 95, 90
    IMAGE_COLOR = 105, 105, 110
    STRIPE_COLOR = 115, 115, 115

    # Negative row and column numbers are invalid, but part
    # of a selection id and are used as an item identifier:
    FREE_CELL = -1
    LAYER = -2


class FormatKey:
    """Has keys used by the Format dictionary."""
    FORMAT = "Format"

    class Cell:
        MARGIN = "Cell Margin"

        class Caption:
            PER_CELL = 'pc_caption'

        class Fringe:
            PER_CELL = 'pc_fringe'

        class Grid:
            """
            The cell grid dict values are converted
            to attributes by the 'grid_deck' module.
            """
            CELL_GRID = "Cell Grid"
            COLUMN = 'column_count'
            COLUMN_WIDTH = 'column_width'
            HORIZONTAL = 'horizontal_count'
            PER_CELL = "Per Cell: Cell Merge"
            PIN = 'pin'
            ROW = 'row_count'
            ROW_HEIGHT = 'row_height'
            SHAPE = 'cell_shape'
            SHIFT = 'shift'
            TYPE = 'grid_type'
            VERTICAL = 'vertical_count'

        class Image:
            class Mask:
                PER_CELL = 'pc_image_mask'

            class Place:
                PER_CELL = 'pc_place'

            class Property:
                PER_CELL = 'pc_image_property'

        class Margin:
            PER_CELL = "Per Cell: Cell Margins"

        class Plaque:
            PER_CELL = 'pc_plaque'

    class Layer:
        CELL_LIST = 'layer_cell_list'
        MARGIN = "Layer Margin"
        NAME = 'name'
        PLACE_FREE_CELL_ABOVE = \
            "Place free-range cells above grid cells in the z-order."


class ForBump:
    """Has values used by the bump preset."""
    NONE, NOISE, CLOTH = HAS_NO_BUMP, 1, 2
    HAS_BUMP = NOISE, CLOTH


class ForPreset:
    """Has values used by a preset."""
    PRESET_SEPARATOR = "﹎"


class ForRender:
    """Has values used by the render process."""
    BACKDROP_INDEX = 2
    MAX_SIZE = 100000


class ForStep:
    """Has values used by the step tuple."""
    # Define key position indices for 'steps'.
    # Steps are composed of a tuple with two strings.
    # option type, option key
    # option type key: Is either a BACKDROP or a format name.
    # It's typically referred to as an 'opt_type'.
    # option key: Is of an effect or a style.
    # Use to access a dictionary of options.
    OPTION_TYPE_INDEX, OPTION_KEY_INDEX = 0, 1
    BACKDROP_IMAGE_STEP = BACKDROP, BackdropStyleKey.BACKDROP_IMAGE


class ForTriangle:
    """Has values used to describe triangles."""
    TRIANGLE_DOWN = "Triangle, Facing Down"
    TRIANGLE_LEFT = "Triangle, Facing Left"
    TRIANGLE_RIGHT = "Triangle, Facing Right"
    TRIANGLE_UP = "Triangle, Facing Up"
    TRIANGLE = TRIANGLE_DOWN, TRIANGLE_LEFT, TRIANGLE_RIGHT, TRIANGLE_UP
    INVERTED = TRIANGLE_UP, TRIANGLE_RIGHT, TRIANGLE_LEFT, TRIANGLE_DOWN
    HORIZONTAL_TRIANGLE = TRIANGLE_LEFT, TRIANGLE_RIGHT
    VERTICAL_TRIANGLE = TRIANGLE_DOWN, TRIANGLE_UP


class ForWidget:
    """Has values used by widgets."""
    FILE = "Add file reference…"
    FROM_LAST_SESSION = "From Last Session"
    FROM_THIS_SESSION = "From This Session"
    IMAGE_SYMBOL = "❑"
    INT_INDEX, FLOAT_INDEX = 0, 1
    LAST_USED = "Last Used"
    LIST_SEPARATOR = LIST_SEPARATOR
    MARGIN = 12
    NO_IMAGE = "…"
    SCROLL_SPAN = 22
    UNDEFINED = "〰 undefined 〰"


class FreeCellKey:
    """Has keys used by the free cell dictionary."""
    CELL = "Cell"
    FREE_RANGE_CELL = "Free-Range Cell"

    class Cell:
        MARGIN = "Cell Margin"


class FringeKey:
    """Use with the fringe presets."""
    BRUSH = 'brush_1'
    BUMP = 'bump'
    CELL_FRINGE = "Cell Fringe"
    CLIP_TO_CELL = 'clip_to_cell'
    COLOR = 'color'
    COLOR_1 = 'color_1'
    COLOR_2 = 'color_2'
    CONTRACT = 'contract'
    GRADIENT = 'gradient'
    GRADIENT_ANGLE = 'gradient_angle'
    GRADIENT_TYPE = GRADIENT_TYPE
    IMAGE = 'image_1'
    LAYER_FRINGE = "Layer Fringe"
    OBEY_MARGINS = 'obey_margins'
    PATTERN = 'pattern'
    SHADOW = 'shadow_1'
    TYPE = 'type'


class ImageKey:
    """Use with the image button dictionary."""
    AS_LAYERS = 'as_layers'
    AUTOCROP = 'autocrop'
    FILTER = 'filter'
    FOLDER_ORDER = 'folder_order'
    HAS_FORMAT = 'has_format'
    IMAGE_REF = 'image_ref'
    LAYER_ORDER = 'layer_order'
    TYPE = 'type'


class LayoutKey:
    """Has keys used by the session layout option."""
    CELL_CAPTION = "Cell Caption"
    CELL_FRINGE = "Cell Fringe"
    CELL_PLAQUE = "Cell Plaque"
    CELL_MARGINS = "Cell Margins"
    COORDINATES = "Coordinates"
    CORNERS = "Corners"
    DIMENSIONS = "Dimensions"
    LAYER_FRINGE = "Layer Fringe"
    LAYER_PLAQUE = "Layer Plaque"
    LAYER_MARGINS = "Layer Margins"
    GRID = "Grid"
    IMAGE_MASK = "Image Mask"
    NAME = "Name"
    RATIOS = "Ratios"


class MarginKey:
    """Use with the margins preset."""
    MARGINS = "Margins"
    FIXED_TOP = 'fixed_top'
    FIXED_BOTTOM = 'fixed_bottom'
    FIXED_LEFT = 'fixed_left'
    FIXED_RIGHT = 'fixed_right'
    FRACTION_TOP = 'fraction_top'
    FRACTION_BOTTOM = 'fraction_bottom'
    FRACTION_LEFT = 'fraction_left'
    FRACTION_RIGHT = 'fraction_right'
    ORDER_LIST = (
        FIXED_TOP,
        FIXED_BOTTOM,
        FIXED_LEFT,
        FIXED_RIGHT,
        FRACTION_TOP,
        FRACTION_BOTTOM,
        FRACTION_LEFT,
        FRACTION_RIGHT
    )


class MaskKey:
    """Has keys for image mask group options."""
    CHAR = 'char'
    FEATHER = FEATHER
    FONT = 'font'
    HORZ_SCALE = 'horizontal_scale'
    IMAGE = 'image_1'
    IMAGE_MASK = "Image Mask"
    STEPS = STEPS
    TYPE = 'type'
    VERT_SCALE = 'vertical_scale'


class OptionKey:
    """Has keys displayed in PortOption."""
    AMPLITUDE = "Amplitude"
    ANGLE_SHIFT = "Angle Shift"
    BACKDROP_BLUR = "Backdrop Image Blur"
    BACKDROP_IMAGE = 'backdrop image'
    BACKDROP_STYLE = "Backdrop Style"
    BEVEL_EDGE_WIDTH = "Bevel Edge Width"
    BLEND = "Blend"
    BLUR = "Blur"
    BRUSH = "Brush"
    BRUSH_SIZE = "Brush Size"
    BRUSH_SPACING = "Brush Spacing"
    BUMP = BUMP
    FRAME_WIDTH = "Frame Width"
    FRAME_TYPE = "Frame Type"
    CELL_GAP = "Cell Gap"
    CELL_SIZE = "Cell Size"
    CIRCLE_DIAMETER = "Circle Diameter"
    COLOR = COLOR
    COLOR_1 = "Color #1"
    COLOR_2 = "Color #2"
    COLOR_3 = "Color #3"
    COLOR_4 = "Color #4"
    COLUMN = "Column"
    COLUMN_1 = "Column #1"
    COLUMN_2 = "Column #2"
    COLUMN_MAZE = "Column for Maze"
    COMPONENT = "Color Component"
    COMPOSITION_FRAME_WIDTH = "Composition Frame Width"
    CORNER_SHIFT = "Corner Shift"
    CRITERION = CRITERION
    DETAIL_LEVEL = "Noise Amount"
    DIAGONAL_ROTATION = "Diagonal Rotation"
    EMBOSS = "Emboss"
    END_X = END_X
    END_Y = END_Y
    FEATHER = "Feather"
    FIT_IMAGE = "Fit image to render"
    GAP_TYPE = "Gap Type"
    GAP_WIDTH = "Gap Width"
    GRADIENT = "Gradient"
    GRADIENT_DIRECTION = "Gradient Direction"
    GRADIENT_TYPE = GRADIENT_TYPE
    MAKE_OPAQUE = MAKE_OPAQUE
    INLAY_BLUR = INLAY_BLUR
    INTENSITY = INTENSITY
    INVERT = INVERT
    INVERT_NOISE = "Invert Noise"
    KEEP_GRADIENT = "Keep the Gradient"
    LAYER_COUNT = "Layer Count"
    LIGHT_ANGLE = "Light Angle"
    LINE_WIDTH = "Line Width"
    MAZE_DIRECTION = "Maze Rotation Direction"
    MAZE_TYPE = "Maze Type"
    MESH_SIZE = "Mesh Size"
    MESH_TYPE = "Mesh Type"
    MODE = MODE
    NAME = "Name"
    NEATNESS = "Neatness"
    SKETCH_TEXTURE = "Sketch Texture"
    NOISE_MODE = "Noise Mode"
    NOISE_OPACITY = "Noise Opacity"
    NONE = NONE
    NUMBER_OF_SLICES = "Number of Slices"
    OFFSET = OFFSET
    OFFSET_X = OFFSET_X
    OFFSET_Y = OFFSET_Y
    PANE_HEIGHT = "Pane Height"
    PANE_WIDTH = "Pane Width"
    PATTERN = "Pattern"
    PATTERN_1 = "Pattern #1"
    PATTERN_2 = "Pattern #2"
    PATTERN_3 = "Pattern #3"
    RANDOM_SEED = "Random Seed"
    OPACITY = OPACITY
    PIPE_TYPE = "Pipe Type"
    POWER = "Noise Power"
    PREVIEW_MODE = "Preview Mode"
    RENDER_HEIGHT = "Render Height"
    RENDER_WIDTH = "Render Width"
    REVERSE = REVERSE
    ROTATE = ROTATE
    ROUND_UP = "Round Up"
    ROUNDED_EDGE_BLUR = "Rounded Edge Blur"
    ROW = "Row"
    ROW_MAZE = "Row for Maze"
    SAMPLE_POINTS = "Sample Points"
    SAMPLE_RADIUS = "Sample Radius"
    SAMPLE_VECTOR = "Sample Vector"
    SCALE = "Scale"
    SCATTER_COUNT = "Scatter Count"
    SHADOW = "Shadow"
    SHADOW_BLUR = SHADOW_BLUR
    SHADOW_COLOR = SHADOW_COLOR
    SMOOTHNESS = "Smoothness"
    SOFTNESS = "Noise Softness"
    SPIRAL_DISTANCE = "Spiral Distance"
    SPIRAL_MOD = "Spiral Mod"
    START_X = "Start X"
    START_Y = "Start Y"
    STARTING_ANGLE = "Starting Angle"
    STEPS = STEPS
    STOP_LENGTH = "Stop Length"
    TAPE_LENGTH = "Tape Length"
    TAPE_WIDTH = "Tape Width"
    TEXTURE = "Texture"
    IMAGE_EFFECT = "Image Effect"
    THRESHOLD = THRESHOLD
    USE_PLASMA = "Use Plasma"
    WAVE_AMPLITUDE = "Wave Amplitude"
    WAVE_PER_LAYER = "Waves Per Layer"
    WAVELENGTH = "Wavelength"
    WHIRL = "Whirl"
    WIDTH = "Width"
    WIRE_THICKNESS = "Wire Thickness"


class OptionLimitKey:
    """Has keys used to access the OptionLimit 'pure' dictionary."""
    CHOICE_WINDOW = 'choice_window'
    DICT = '_dict'
    FUNCTION = 'function'
    FUNCTION_RANGE = 'function_range'

    # for option group table:
    LABEL = 'label'

    # Use with RadioBox:
    LABELS = 'labels'

    # randomize keyword LIMIT:
    LIMIT = 'limit'

    # Call a function in OptionLimit:
    LIMIT_FUNCTION = 'limit_function'

    # Call a function in the caller class. Is a template:
    LIMIT_SELF = 'limit_self'

    # LIST is used by the randomize and initialize functions:
    LIST = 'list'

    # Use to set only one tooltip. Modify
    # the button's 'set_value' function:
    ONLY_TOOLTIP = 'only_tooltip'

    # A precision of zero is an integer:
    PRECISION = 'precision'

    # min and max numeric limitation:
    RANGE = 'range'
    RANGE_FUNCTION = 'range_function'
    RANGE_SELF = 'range_self'

    TIP_TYPE = 'tip_type'
    TOOLTIP = 'tooltip'

    # Set a widget class:
    WIDGET = 'widget'

    WIDGET_SIGNAL = 'widget_signal'
    WINDOW_SIGNAL = 'window_signal'


class PickleKey:
    """Has keys used with Pickle."""
    DATA = 'data'
    FILE = 'file'
    SHOW_ERROR = 'show_error'


class PlaceKey:
    """Use keys with image place group options."""
    HORIZONTAL = 'horizontal'
    IMAGE_DICT = 'image_dict'
    RESIZE = 'resize'
    VERTICAL = 'vertical'

    # preset dict key:
    IMAGE_PLACE = "Image Place"


class PlaqueKey:
    """Use with the plaque presets."""
    BUMP = 'bump'
    BLUR_BEHIND = 'blur_behind'
    CELL_PLAQUE = "Cell Plaque"
    COLOR = 'color'
    FEATHER = FEATHER
    GRADIENT = 'gradient'
    GRADIENT_ANGLE = 'gradient_angle'
    GRADIENT_TYPE = GRADIENT_TYPE
    IMAGE = 'image_1'
    LAYER_PLAQUE = "Layer Plaque"
    OBEY_MARGINS = 'obey_margins'
    OPACITY = 'opacity'
    PATTERN = 'pattern'
    STEPS = STEPS
    TYPE = 'type'


class PortCellKey:
    """Has keys used to initialize PortCell."""
    CELL_TABLE = 'cell_table'
    PER_CELL_BUTTON = 'per_cell_button'
    SET_TOOLTIP = 'set_tooltip'
    TABLE_SIZE = 'table_size'


class PortKey:
    """Has keys used to identify ports."""
    CELL = 'cell'
    CELL_MOD = 'cell_mod'
    FORMAT = 'format'
    FREE_CELL = 'free_cell'
    MAIN = 'main'
    OPTION = 'option'
    NOT_USED = 'not_used'


class PresetKey:
    """Has keys used to initialize a Preset."""
    DEFAULT = "Default"
    FILE_NAME = 'file_name'
    GET_DATA = 'get_data'
    INTERNAL = 'internal'
    PRESET = 'preset'
    WINDOW = 'window'


class PropertyKey:
    """Use keys with property group options."""
    BLUR_BEHIND = 'blur_behind'
    FLIP_HORIZONTAL = 'flip_horizontal'
    FLIP_VERTICAL = 'flip_vertical'
    IMAGE_PROPERTY = "Image Property"
    OPACITY = 'opacity'
    ROTATE = 'rotate'


class SessionKey:
    """Has keys used by the Session dictionary."""
    BACKDROP = BACKDROP
    CLOSE_FILE = 'close_file'
    FORMAT_LIST = 'format_list'
    FORMAT_NAME_LIST = 'format_name_list'
    LAYOUT_OPTION = 'layout_option'
    SESSION = "Session"
    SESSION_OPT = 'session_opt'


class ShadowKey:
    """Has keys used in the shadow dictionaries."""
    DROP_SHADOW = DROP_SHADOW
    FILL_LIGHT_SHADOW = FILL_LIGHT_SHADOW
    INLAY_BLUR = INLAY_BLUR
    INLAY_SHADOW = INLAY_SHADOW
    INTENSITY = INTENSITY
    KEY_LIGHT_SHADOW = KEY_LIGHT_SHADOW
    MAKE_OPAQUE = MAKE_OPAQUE
    OFFSET_X = OFFSET_X
    OFFSET_Y = OFFSET_Y
    SHADOW_BLUR = SHADOW_BLUR
    SHADOW_COLOR = SHADOW_COLOR
    SHADOW_DICT = "Shadow"
    SHADOW_PAIR = SHADOW_PAIR
    TRI_SHADOW = TRI_SHADOW
    TYPE = 'type'


class Signal:
    """
    Has signal names.

    Use with format and layer management.
    """
    VALUE_CHANGED = 'value_changed'
    VISIBILITY_CHANGE = 'visibility-change'


class StripeKey:
    """Has keys used by the caption stripe preset."""
    BLUR_BEHIND = 'blur_behind'
    COLOR = 'color'
    HEIGHT = 'height'
    OPACITY = 'opacity'
    TYPE = 'type'


class UIKey:
    """Has keys used to initialize a window or a port."""
    CELL_INDEX = 'cell_index'
    FORMAT_DICT = 'format_dict'
    FORMAT_INDEX = 'format_index'
    GET_FORMAT_INFO = 'get_format_info'
    GET_SESSION_DICT = 'get_session_dict'
    ON_ACCEPT = 'on_accept'
    ON_CANCEL = 'on_cancel'
    ON_KEY_PRESS = 'on_key_press'
    OPT_BUTTON = 'opt_button'
    PARENT_PORT = 'parent_port'
    PORT = 'port'
    PORT_KEY = 'port'
    STAT = 'stat'
    WINDOW = 'window'
    WINDOW_KEY = 'window_key'
    WINDOW_TITLE = 'window_title'


class WidgetKey:
    """Has keys used to initialize widgets."""
    # tuple of float
    # (0 .. 1)
    # fraction of space to assign
    # for top, bottom, left, right:
    ALIGN = 'align'

    # int
    # padding for the bottom of a table:
    BOTTOM_PAD = 'bottom_pad'

    # class
    # type of choice window:
    CHOICE_WINDOW = 'choice_window'

    # Widget
    # container for group:
    CONTAINER = 'container'

    # int
    # for event boxes:
    COLOR = 'color'

    # list
    # of strings for combobox:
    COMBO_LIST = 'combo_list'

    # Use to connect widget with event:
    EVENT = 'event'

    # string
    # either cell or layer:
    FRACTION_OF = 'fraction_of'

    # function
    # Use with margins to return size of margin space:
    GET_SIZE = 'get_size'

    # string
    # Use to initialize a preset combobox:
    INIT_VALUE = 'init_value'

    # string
    # option group:
    KEY = 'key'

    # RollerLabel
    # sensitivity synchronized with another widget:
    LABEL = 'label'

    # tuple
    # low, high
    # limit self value range of slider
    LIMIT = 'limit'

    # function
    # callback on key press:
    ON_KEY_PRESS = 'on_key_press'

    # function
    # callback on change:
    ON_WIDGET_CHANGE = 'on_widget_change'

    # tuple
    # Alignment padding:
    PADDING = 'padding'

    # int
    # number of digits after the decimal point
    # Is zero for an integer:
    PRECISION = 'precision'

    # function
    # Is a callback to show preview for a chooser window:
    PREVIEW = 'preview'

    # Stat
    # globals:
    STAT = 'stat'

    # identifier
    # Use to differentiate multiple types
    # that have the same super type:
    SUB_TYPE = 'sub_type'

    # string
    # for checkbutton:
    TEXT = 'text'

    TIP_TYPE = 'tip_type'

    # string
    # for tooltip:
    TOOLTIP = 'tooltip'

    # list
    # of preset widgets:
    WIDGET_LIST = 'widget_list'

    # GTK window or RollerWindow:
    WIN = 'win'


class WindowKey:
    """
    Has keys used in the window position dictionary.

    Use key with a window type.
    """
    BUMP_CHOOSER = 'bump_chooser'
    BRUSH_CHOOSER = 'brush_chooser'
    CELL_MOD = 'cell_mod'
    CHOOSER = 'chooser'
    IMAGE_CHOOSER = 'image_chooser'
    MAIN = 'main'
    MARGIN_CHOOSER = 'margin_chooser'
    RESIZE_CHOOSER = 'resize_chooser'
    SAVE = 'save'
    SHADOW_CHOOSER = 'shadow_chooser'
    STRIPE = 'stripe'


class ForCell:
    """Has values used by cells."""

    # Use to verify cell tables when loading a session preset:
    # 'key' is a reference to the preset key for the cell table:
    CELL_TABLE_DICT = {
        FormatKey.Cell.Caption.PER_CELL: {
            'key': CaptionKey.CELL_CAPTION,
            'name': "Cell Caption",
            'window_key': 'cell_caption'
        },
        FormatKey.Cell.Fringe.PER_CELL: {
            'key': FringeKey.CELL_FRINGE,
            'name': "Cell Fringe",
            'window_key': 'cell_fringe'
        },
        FormatKey.Cell.Grid.PER_CELL: {
            'key': None,
            'name': "Merge Cells",
            'window_key': 'cell_merge'
        },
        FormatKey.Cell.Image.Mask.PER_CELL: {
            'key': MaskKey.IMAGE_MASK,
            'name': "Image Mask",
            'window_key': 'image_mask'
        },
        FormatKey.Cell.Image.Place.PER_CELL: {
            'key': PlaceKey.IMAGE_PLACE,
            'name': "Image Place",
            'window_key': 'cell_place'
        },
        FormatKey.Cell.Image.Property.PER_CELL: {
            'key': PropertyKey.IMAGE_PROPERTY,
            'name': "Image Property",
            'window_key': 'cell_prop'
        },
        FormatKey.Cell.Margin.PER_CELL: {
            'key': FormatKey.Cell.MARGIN,
            'name': "Cell Margin",
            'window_key': 'cell_margin'
        },
        FormatKey.Cell.Plaque.PER_CELL: {
            'key': PlaqueKey.CELL_PLAQUE,
            'name': "Cell Plaque",
            'window_key': 'cell_plaque'
        }
    }
    MIN_CELL_SPAN = 4
