#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_one_constant import ForColor, ForWidget as fw, WidgetKey as wk
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
import gtk

LABEL_INDEX, WIDGET_INDEX, ARGS_INDEX, KEY_ARGS_INDEX = range(4)
PAD = fw.MARGIN


class RollerTable(gtk.Alignment):
    """Organize GTK table methods."""

    @staticmethod
    def create(**d):
        """
        Put widgets in a two column GTK table.

        Each widget must have a key if it is
        to be returned in the widget dict.

        d: dict
            Has keyword arguments.

        Return: dict
            of widget
        """
        q = RollerTable.enlist(**d)
        d = OrderedDict([])
        for i in q:
            if hasattr(i, 'key'):
                d[i.key] = i
        return d

    @staticmethod
    def enlist(**d):
        """
        Put widgets in a two column GTK table.

        d: dict
            Has keyword arguments.

        Return: list
            of widget
        """
        w = fw.MARGIN
        bottom_pad = d[wk.BOTTOM_PAD] if wk.BOTTOM_PAD in d else w
        color = d[wk.COLOR]
        q = d['q']
        q1 = []
        alignment = gtk.Alignment(0, 0, 1, 0)

        alignment.set_padding(w, bottom_pad, w, w)

        table = gtk.Table(len(q), 2)
        option_count = len(q)

        table.set_row_spacings(1)

        for x, i in enumerate(q):
            if not x:
                # Expand the right-column with an invisible label widget:
                table.attach(gtk.Label("\t" * 8), 1, 2, x, x + 1)

            g1 = i[WIDGET_INDEX](**i[ARGS_INDEX])

            color = RollerTable.get_darker_color(color, option_count)
            color1 = color, color, ForColor.MAX_COLOR
            label = RollerLabel(text=i[LABEL_INDEX])
            label.box = box = RollerEventBox(color1)
            g1.box = box1 = RollerEventBox(color1)
            g1.label = label

            q1.append(g1)
            label.set_padding(0, 0, w, w // 2)
            g1.set_padding(0, 0, w // 2, w)
            box.add(label)
            box1.add(g1)
            table.attach(box, 0, 1, x, x + 1)
            table.attach(box1, 1, 2, x, x + 1)

        alignment.add(table)
        d[wk.CONTAINER].pack_start(alignment, expand=True)
        return q1

    @staticmethod
    def get_darker_color(color, step_count):
        """
        Calculate a darker blue color with a step count.

        color: int
            to decrease
            Is the red and green component.

        step_count: int
            Use to compute amount to reduce.

        Return: int
            for a darker color
        """
        return color - 14000 // (step_count + 1)

    @staticmethod
    def do_wide(**d):
        """
        Put widgets in a three column GTK table.

        d: dict
            Has keyword arguments.

        Return: list
            of widget
        """
        w = fw.MARGIN
        bottom_pad = d[wk.BOTTOM_PAD] if wk.BOTTOM_PAD in d else w
        color = d[wk.COLOR]
        q = d['q']
        q1 = []
        alignment = gtk.Alignment(0, 0, 1, 0)

        alignment.set_padding(w, bottom_pad, w, w)

        table = gtk.Table(len(q), 3)
        option_count = len(q)

        table.set_row_spacings(1)

        for x, i in enumerate(q):
            if not x:
                # Expand the right-column with an invisible label widget:
                table.attach(gtk.Label("\t" * 8), 2, 3, x, x + 1)

            if len(i) == 4:
                g1 = i[WIDGET_INDEX](*i[ARGS_INDEX], **i[KEY_ARGS_INDEX])

            else:
                g1 = i[WIDGET_INDEX](**i[ARGS_INDEX])

            color = RollerTable.get_darker_color(color, option_count)
            color1 = color, color, ForColor.MAX_COLOR
            label = label1 = None

            if i[LABEL_INDEX][0]:
                label = RollerLabel(text=i[LABEL_INDEX][0])

            if i[LABEL_INDEX][1]:
                label1 = RollerLabel(text=i[LABEL_INDEX][1])

            box = RollerEventBox(color1)
            box1 = RollerEventBox(color1)
            box2 = RollerEventBox(color1)

            q1.append(g1)

            for g2 in (label, label1):
                if g2:
                    g2.set_padding(0, 0, w, w // 2)

            g1.set_padding(0, 0, w // 2, w)

            if label:
                box.add(label)

            if label1:
                box1.add(label1)

            box2.add(g1)
            table.attach(box, 0, 1, x, x + 1)
            table.attach(box1, 1, 2, x, x + 1)
            table.attach(box2, 2, 3, x, x + 1)

        alignment.add(table)
        d[wk.CONTAINER].pack_start(alignment, expand=True)
        return q1
