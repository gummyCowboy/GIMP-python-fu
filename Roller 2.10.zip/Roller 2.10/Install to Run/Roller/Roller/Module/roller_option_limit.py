#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice, randint
from roller_image_effect import ImageEffect
from roller_one_base import Base
from roller_one_constant import (
    BackdropStyleKey as bsk,
    BumpKey,
    ForBackdropStyle as fbs,
    ForFill,
    ForFormat as ff,
    ForGradient,
    ForRender,
    ForWidget,
    OptionKey as ok,
    OptionLimitKey as olk,
    Signal,
    SessionKey as sk
)
from roller_one_mode import Mode
from roller_one_tip import Tip
from roller_widget_button import OptionButton, RollerColorButton
from roller_widget_check_button import RollerCheckButton
from roller_widget_combo import RollerComboBox
from roller_widget_entry import RollerEntry
from roller_widget_radio import RadioBox
from roller_widget_slider import RollerSlider
from roller_window_bump_choice import RWBumpChoice
from roller_window_choice import RWChoice
from roller_window_image_choice import RWImageChoice

ek = ImageEffect.Key
BLUR = {
    olk.LIMIT: (3., 20.),
    olk.RANGE: (1., 60.),
    olk.PRECISION: 1,
    olk.WIDGET: RollerSlider
}


class OptionLimit:
    """Use to limit a valid range and a random range for option values."""
    # for effect, limit width: (low, high):
    width = {
        ek.BORDER_LINE: (1, 12),
        ek.BRUSH_PUNCH: (1, 12),
        ek.CERAMIC_CHIP: (1, 12),
        ek.CIRCLE_PUNCH: (1, 12),
        ek.CLEAR_FRAME: (1, 65),
        ek.COLORED_BOARD: (1, 20),
        ek.COSMETIC_PIPE: (1, 65),
        ek.CUTOUT_PLATE: (1, 200),
        ek.GRADIENT_LEVEL: (1, 200),
        ek.GRADIENT_PIPE: (1, 65),
        ek.LINE_FASHION: (1, 15),
        ek.MAZE_MIRROR: (1, 15),
        ek.RAD_WAVE: (1, 20),
        ek.RAISED_MAZE: (1, 12),
        ek.SQUARE_PUNCH: (1, 15),
        ek.STAINED_GLASS: (1, 12),
        ek.WIRE_FENCE: (1, 12)
    }

    # for effect, limit filler: (low, high):
    filler = {
        ek.CERAMIC_CHIP: (25, 55),
        ek.CIRCLE_PUNCH: (20, 200),
        ek.LINE_FASHION: (20, 200),
        ek.SQUARE_PUNCH: (20, 200),
        ek.STAINED_GLASS: (60, 120),
        ek.WIRE_FENCE: (20, 200)
    }

    # Is a minimum, maximum value for a limit-random function.
    # If the option in 'pure' is a row or column option, and
    # has a 'LIMIT_SELF: self.get_row_limited key' value-pair,
    # then the option group (either an image-effect or backdrop-style)
    # will need an entry in this dictionary:
    row_column_limit = {
        bsk.COLORED_GRID: (1, 100),
        bsk.CORE_DESIGN: (1, 100),
        bsk.DARK_FORT: (5, 10),
        bsk.GRID_WORK: (1, 25),
        bsk.LOST_MAZE: (4, 100),
        bsk.MAZE_BLEND: (4, 100),
        ek.MAZE_MIRROR: (1, 40),
        bsk.MYSTERY_GRATE: (1, 130),
        ek.RAD_WAVE: (1, 25),
        ek.RAISED_MAZE: (4, 100),
        bsk.SPACETIME_FABRIC: (1, 25),
        bsk.SPIRAL_CHANNEL: (1, 4)
    }

    def __init__(self, stat):
        """
        Option variables use 'pure' to
        define their user-interface widgets.

        The key is an OptionKey. The value is a
        dictionary with OptionLimitKey items.

        With each option dictionary define:
        the RANGE an option widget will allow;
        the LIMIT an option widget will randomize;
        the WIDGET's class-type in the interface.

        stat: Stat
            globals
        """
        self.stat = stat
        a = olk

        self.pure = {
            ok.AMPLITUDE: {
                a.LIMIT: (2, 10),
                a.RANGE: (2, 10),
                a.TOOLTIP: Tip.JAG_AMPLITUDE,
                a.WIDGET: RollerSlider
            },
            ok.ANGLE_SHIFT: {
                a.LIMIT: (0, 10),
                a.RANGE: (0, 30),
                a.WIDGET: RollerSlider
            },
            ok.BACKDROP_BLUR: {
                a.LIMIT: (0, 500),
                a.RANGE: (0, 500),
                a.WIDGET: RollerSlider
            },
            ok.BACKDROP_IMAGE: {
                a.CHOICE_WINDOW: RWImageChoice,
                a.LABEL: "Backdrop Image",
                a.TIP_TYPE: ff.IMAGE_TIP_TYPE,
                a.WIDGET: OptionButton,
            },
            ok.BACKDROP_STYLE: {
                a.LIMIT_FUNCTION: self.get_random_backdrop_style,
                a.LIST: Option.BackdropStyle.names,
                a.WIDGET: RollerComboBox
            },
            ok.BEVEL_EDGE_WIDTH: {
                a.LIMIT: (8, 24),
                a.RANGE: (1, 1000),
                a.WIDGET: RollerSlider
            },
            ok.BLEND: {
                a.LIMIT: (5, 20),
                a.RANGE: (1, 60),
                a.TOOLTIP: Tip.BLEND,
                a.WIDGET: RollerSlider
            },
            BumpKey.Cloth.BLUR_X: BLUR,
            BumpKey.Cloth.BLUR_Y: BLUR,
            ok.BRUSH: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: self.get_brush_list,
                a.LIMIT_FUNCTION: self.get_random_brush,
                a.WIDGET: OptionButton
            },
            ok.BRUSH_SIZE: {
                a.LIMIT: (75, 125),
                a.RANGE: (30, 10000),
                a.WIDGET: RollerSlider
            },
            ok.BRUSH_SPACING: {
                a.LIMIT: (65, 135),
                a.PRECISION: 1,
                a.RANGE: (20, 5000),
                a.WIDGET: RollerSlider
            },
            ok.BUMP: {
                a.CHOICE_WINDOW: RWBumpChoice,
                a.TIP_TYPE: ff.BUMP_TIP_TYPE,
                a.WIDGET: OptionButton
            },
            BumpKey.Emboss.BUMP_DEPTH: {
                a.LIMIT: (1, 4),
                a.RANGE: (1, 100),
                a.WIDGET: RollerSlider
            },
            BumpKey.Emboss.BUMP_ELEVATION: {
                a.LIMIT: (20., 30.),
                a.PRECISION: 1,
                a.RANGE: (0., 180.),
                a.WIDGET: RollerSlider
            },
            ok.CELL_GAP: {
                a.LIMIT: (3, 12),
                a.RANGE: (2, 100),
                a.TOOLTIP: Tip.CELL_GAP,
                a.WIDGET: RollerSlider
            },
            ok.CELL_SIZE: {
                a.LIMIT: (1, 100),
                a.RANGE: (1, 1500),
                a.WIDGET: RollerSlider
            },
            ok.CIRCLE_DIAMETER: {
                a.LIMIT_SELF: self.get_filler_width,
                a.RANGE: (20, 10000),
                a.WIDGET: RollerSlider
            },
            ok.COLOR: {
                a.LIMIT_FUNCTION: Base.rnd_col,
                a.WIDGET: RollerColorButton
            },
            ok.COLOR_1: {
                a.LIMIT_FUNCTION: Base.rnd_col,
                a.WIDGET: RollerColorButton
            },
            ok.COLOR_2: {
                a.LIMIT_FUNCTION: Base.rnd_col,
                a.WIDGET: RollerColorButton
            },
            ok.COLUMN: {
                a.LIMIT_SELF: self.get_column_limited,
                a.RANGE: (1, 10000),
                a.WIDGET: RollerSlider
            },
            ok.COLUMN_1: {
                a.LIMIT_SELF: self.get_column_limited,
                a.RANGE: (1, 1000),
                a.TOOLTIP: Tip.COLUMN_1,
                a.WIDGET: RollerSlider
            },
            ok.COLUMN_2: {
                a.LIMIT_SELF: self.get_column_limited,
                a.RANGE: (1, 1000),
                a.TOOLTIP: Tip.COLUMN_2,
                a.WIDGET: RollerSlider
            },
            ok.COLUMN_MAZE: {
                a.LIMIT_SELF: self.get_column_limited,
                a.RANGE: (4, 10000),
                a.WIDGET: RollerSlider
            },
            ok.COMPONENT: {
                a.LIST: fbs.COMPONENT,
                a.WIDGET: RollerComboBox
            },
            ok.COMPOSITION_FRAME_WIDTH: {
                a.LIMIT_SELF: self.get_frame_width,
                a.RANGE: (0, 10000),
                a.WIDGET: RollerSlider
            },
            ok.CORNER_SHIFT: {
                a.LIMIT: (0, 18),
                a.RANGE: (0, 100),
                a.WIDGET: RollerSlider
            },
            ok.CRITERION: {
                # List is also used by random:
                a.LIST: ForFill.CRITERION_LIST,
                a.WIDGET: RollerComboBox
            },
            ok.DETAIL_LEVEL: {
                a.LIMIT: (1, 15),
                a.RANGE: (1, 15),
                a.WIDGET: RollerSlider
            },
            ok.DIAGONAL_ROTATION: {
                a.LIMIT: (-359., 359.),
                a.PRECISION: 1,
                a.RANGE: (-359., 359.),
                a.TOOLTIP: Tip.DIAGONAL_ROTATION,
                a.WIDGET: RollerSlider
            },
            ok.EMBOSS: {
                a.LIMIT: (0, 1),
                a.WIDGET: RollerCheckButton
            },
            ok.END_X: {
                a.LIMIT: (.0, 1.),
                a.PRECISION: 6,
                a.RANGE: (.0, 1.),
                a.TOOLTIP: Tip.END_COORDINATE,
                a.WIDGET: RollerSlider
            },
            ok.END_Y: {
                a.LIMIT: (.0, 1.),
                a.RANGE: (.0, 1.),
                a.PRECISION: 6,
                a.WIDGET: RollerSlider
            },
            ok.FEATHER: {
                a.LIMIT: (50, 300),
                a.RANGE: (0, 10000),
                a.TOOLTIP: Tip.FEATHER,
                a.WIDGET: RollerSlider
            },
            ok.FIT_IMAGE: {
                a.WIDGET: RollerCheckButton
            },
            ok.FRAME_TYPE: {
                a.LABELS:  ("Rounded", "Angular"),
                a.LIMIT: (0, 1),
                a.TOOLTIP: Tip.ROUNDED,
                a.WIDGET: RadioBox
            },
            ok.FRAME_WIDTH: {
                a.LIMIT_SELF: self.get_frame_width,
                a.RANGE: (1, 10000),
                a.WIDGET: RollerSlider
            },
            ok.GAP_TYPE: {
                a.LIST: fbs.GAP_TYPE,
                a.TOOLTIP: Tip.MAZE_GAP_TYPE,
                a.WIDGET: RollerComboBox,
                a.WINDOW_SIGNAL: Signal.VISIBILITY_CHANGE
            },
            ok.GAP_WIDTH: {
                a.LIMIT_SELF: self.get_frame_width,
                a.RANGE: (3, 256),
                a.WIDGET: RollerSlider
            },
            ok.GRADIENT: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: self.get_gradient_list,
                a.LIMIT_FUNCTION: self.get_random_gradient,
                a.WIDGET: OptionButton
            },
            ok.GRADIENT_DIRECTION: {
                a.LABELS: fbs.DIRECTION,
                a.WIDGET: RadioBox
            },
            ok.GRADIENT_TYPE: {
                a.LIST: ForGradient.GRADIENT_TYPE_LIST,
                a.WIDGET: RollerComboBox,
                a.WINDOW_SIGNAL: Signal.VISIBILITY_CHANGE
            },
            ok.IMAGE_EFFECT: {
                a.LIMIT_FUNCTION: self.get_random_image_effect,
                a.LIST: Option.Effect.names,
                a.WIDGET: RollerComboBox
            },
            ok.INLAY_BLUR: {
                a.LIMIT: (20, 30),
                a.RANGE: (0, 500),
                a.WIDGET: RollerSlider
            },
            ok.INVERT: {
                a.LIMIT: (0, 1),
                a.WIDGET: RollerCheckButton
            },
            ok.INVERT_NOISE: {
                a.LIMIT: (0, 1),
                a.WIDGET: RollerCheckButton
            },
            ok.INTENSITY: {
                a.LIMIT: (80, 200),
                a.RANGE: (0, 1000),
                a.WIDGET: RollerSlider,
                a.WINDOW_SIGNAL: Signal.VISIBILITY_CHANGE
            },
            ok.KEEP_GRADIENT: {
                a.TOOLTIP: Tip.KEEP_GRADIENT,
                a.WIDGET: RollerCheckButton
            },
            ok.LAYER_COUNT: {
                a.LIMIT: (4, 8),
                a.RANGE: (3, 15),
                a.WIDGET: RollerSlider
            },
            ok.LIGHT_ANGLE: {
                a.LIMIT: (0., 359.),
                a.PRECISION: 1,
                a.RANGE: (0., 359.),
                a.WIDGET: RollerSlider
            },
            ok.LINE_WIDTH: {
                a.RANGE: (3, 10000),
                a.LIMIT_SELF: self.get_frame_width,
                a.WIDGET: RollerSlider
            },
            ok.MAKE_OPAQUE: {
                a.LABELS: (
                    "No, use the original source opacity.",
                    "Yes, use an opaque source."
                ),
                a.TOOLTIP: Tip.MAKE_OPAQUE,
                a.WIDGET: RadioBox,
            },
            ok.MAZE_DIRECTION: {
                a.LABELS: fbs.DIRECTION,
                a.WIDGET: RadioBox
            },
            ok.MAZE_TYPE: {
                a.LIST: fbs.MAZE_TYPE,
                a.WIDGET: RollerComboBox,
                a.WINDOW_SIGNAL: Signal.VISIBILITY_CHANGE
            },
            ok.MESH_SIZE: {
                a.LIMIT: (25, 60),
                a.RANGE: (3, 1000),
                a.WIDGET: RollerSlider
            },
            ok.MESH_TYPE: {
                a.LIST: fbs.MESH_TYPE,
                a.WIDGET: RollerComboBox
            },
            ok.MODE: {
                a.LIMIT_FUNCTION: Mode.rand,
                a.LIST: Mode.names,
                a.WIDGET: RollerComboBox
            },
            ok.NAME: {a.WIDGET: RollerEntry},
            ok.NEATNESS: {
                a.LIMIT: (.0, 1.),
                a.PRECISION: 3,
                a.RANGE: (.0, 1.),
                a.WIDGET: RollerSlider
            },
            BumpKey.Noise.NOISE: {
                a.LIMIT: (.0, .5),
                a.PRECISION: 3,
                a.RANGE: (.0, 1.),
                a.WIDGET: RollerSlider
            },
            ok.NOISE_MODE: {
                a.LIST: fbs.NOISE_MODE_LIST,
                a.WIDGET: RollerComboBox,
                a.WINDOW_SIGNAL: Signal.VISIBILITY_CHANGE
            },
            ok.NOISE_OPACITY: {
                a.LIMIT: (0., 100.),
                a.PRECISION: 1,
                a.RANGE: (0., 100.),
                a.WIDGET: RollerSlider,
                a.WINDOW_SIGNAL: Signal.VISIBILITY_CHANGE
            },
            ok.NUMBER_OF_SLICES: {
                a.LIMIT: (2, 15),
                a.RANGE: (2, 60),
                a.WIDGET: RollerSlider
            },
            ok.OFFSET: {
                a.LIMIT_FUNCTION: self.get_gradient_offset_limited,
                a.RANGE: (0, 10000),
                a.WIDGET: RollerSlider
            },
            ok.OFFSET_X: {
                a.LIMIT_FUNCTION: self.get_shadow_offset_limited,
                a.RANGE: (-10000, 10000),
                a.WIDGET: RollerSlider
            },
            ok.OFFSET_Y: {
                a.LIMIT_FUNCTION: self.get_shadow_offset_limited,
                a.RANGE: (-10000, 10000),
                a.WIDGET: RollerSlider
            },
            ok.OPACITY: {
                a.LIMIT: (25., 100.),
                a.PRECISION: 1,
                a.RANGE: (0., 100.),
                a.WIDGET: RollerSlider
            },
            ok.PANE_HEIGHT: {
                a.LIMIT_FUNCTION: self.get_pane_limit,
                a.RANGE: (25, 1000),
                a.WIDGET: RollerSlider
            },
            ok.PANE_WIDTH: {
                a.LIMIT_FUNCTION: self.get_pane_limit,
                a.RANGE: (25, 1000),
                a.WIDGET: RollerSlider
            },
            ok.PATTERN: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: self.get_pattern_list,
                a.LIMIT_FUNCTION: self.get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PATTERN_1: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: self.get_pattern_list,
                a.LIMIT_FUNCTION: self.get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PATTERN_2: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: self.get_pattern_list,
                a.LIMIT_FUNCTION: self.get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PATTERN_3: {
                a.CHOICE_WINDOW: RWChoice,
                a.FUNCTION: self.get_pattern_list,
                a.LIMIT_FUNCTION: self.get_random_pattern,
                a.WIDGET: OptionButton
            },
            ok.PIPE_TYPE: {
                a.LABELS:  ("Beveled", "Rounded"),
                a.LIMIT: (0, 1),
                a.WIDGET: RadioBox
            },
            ok.POWER: {
                a.LIMIT: (0, 180),
                a.RANGE: (0, 180),
                a.TOOLTIP: Tip.NOISE_POWER,
                a.WIDGET: RollerSlider
            },
            ok.PREVIEW_MODE: {
                a.LABELS: (
                    "Show Gradient",
                    "Show Samples."
                ),
                a.WIDGET: RadioBox,
            },
            ok.RANDOM_SEED: {
                a.LIMIT: (0, 2147483640),
                a.RANGE: (0, 2147483640),
                a.TOOLTIP: Tip.RANDOM_SEED,
                a.WIDGET: RollerSlider
            },
            ok.RENDER_HEIGHT: {
                a.RANGE: (1, ForRender.MAX_SIZE),
                a.WIDGET: RollerSlider,
                a.WIDGET_SIGNAL: Signal.VALUE_CHANGED
            },
            ok.RENDER_WIDTH: {
                a.RANGE: (1, ForRender.MAX_SIZE),
                a.WIDGET: RollerSlider,
                a.WIDGET_SIGNAL: Signal.VALUE_CHANGED
            },
            ok.REVERSE: {
                a.LIMIT: (0, 1),
                a.TOOLTIP: Tip.REVERSE,
                a.WIDGET: RollerCheckButton
            },
            ok.ROTATE: {
                a.LIMIT: (-359., 359.),
                a.PRECISION: 1,
                a.RANGE: (-359., 359.),
                a.WIDGET: RollerSlider
            },
            ok.ROUND_UP: {
                a.LIMIT: (0, 1),
                a.WIDGET: RollerCheckButton
            },
            ok.ROUNDED_EDGE_BLUR: {
                a.LIMIT: (15, 30),
                a.RANGE: (0, 500),
                a.WIDGET: RollerSlider
            },
            ok.ROW: {
                a.LIMIT_SELF: self.get_row_limited,
                a.RANGE: (1, 10000),
                a.WIDGET: RollerSlider
            },
            ok.ROW_MAZE: {
                a.LIMIT_SELF: self.get_row_limited,
                a.RANGE: (4, 10000),
                a.WIDGET: RollerSlider
            },
            ok.SAMPLE_POINTS: {
                a.LIMIT: (2, 25),
                a.RANGE: (2, 50),
                a.TOOLTIP: Tip.SAMPLE_POINTS,
                a.WIDGET: RollerSlider
            },
            ok.SAMPLE_RADIUS: {
                a.LIMIT: (10, 50),
                a.RANGE: (1, 100),
                a.WIDGET: RollerSlider
            },
            ok.SAMPLE_VECTOR: {
                a.LIST: fbs.VECTOR,
                a.TOOLTIP: Tip.SAMPLE_VECTOR,
                a.WIDGET: RollerComboBox,
                a.WINDOW_SIGNAL: Signal.VISIBILITY_CHANGE
            },
            ok.SCALE: {
                a.LIMIT: (4, 20),
                a.RANGE: (4, 20),
                a.TOOLTIP: Tip.SCALE,
                a.WIDGET: RollerSlider
            },
            ok.SCATTER_COUNT: {
                a.LIMIT: (2, 20),
                a.RANGE: (1, 100),
                a.TOOLTIP: Tip.SCATTER_COUNT,
                a.WIDGET: RollerSlider
            },
            ok.SHADOW: {
                a.LIST: ImageEffect.SHADOW_CHOICE,
                a.WIDGET: RollerComboBox,
                a.WINDOW_SIGNAL: Signal.VISIBILITY_CHANGE
            },
            ok.SHADOW_BLUR: {
                a.LIMIT: (15, 40),
                a.RANGE: (0, 500),
                a.WIDGET: RollerSlider
            },
            ok.SHADOW_COLOR: {a.WIDGET: RollerColorButton},
            ok.SKETCH_TEXTURE: {
                a.LIST: fbs.NEWS_TYPE,
                a.WIDGET: RollerComboBox
            },
            ok.SMOOTHNESS: {
                a.LIMIT: (5, 12),
                a.RANGE: (3, 20),
                a.WIDGET: RollerSlider
            },
            ok.SOFTNESS: {
                a.LIMIT: (0, 1000),
                a.RANGE: (0, 1000),
                a.WIDGET: RollerSlider
            },
            ok.SPIRAL_DISTANCE: {
                a.LIMIT: (.001, .5),
                a.RANGE: (.001, .5),
                a.PRECISION: 3,
                a.TOOLTIP: Tip.SPIRAL_DISTANCE,
                a.WIDGET: RollerSlider
            },
            ok.SPIRAL_MOD: {
                a.LIST: fbs.SPIRAL_MOD_LIST,
                a.WIDGET: RollerComboBox,
                a.WINDOW_SIGNAL: Signal.VISIBILITY_CHANGE
            },
            ok.START_X: {
                a.LIMIT: (.0, 1.),
                a.PRECISION: 6,
                a.RANGE: (.0, 1.),
                a.TOOLTIP: Tip.START_X,
                a.WIDGET: RollerSlider
            },
            ok.START_Y: {
                a.LIMIT: (.0, 1.),
                a.RANGE: (.0, 1.),
                a.PRECISION: 6,
                a.WIDGET: RollerSlider
            },
            ok.STARTING_ANGLE: {
                a.LIMIT: (-360, 360),
                a.RANGE: (-360, 360),
                a.WIDGET: RollerSlider
            },
            ok.STEPS: {
                a.LIMIT: (1, 20),
                a.RANGE: (1, 20),
                a.TOOLTIP: Tip.STEPS,
                a.WIDGET: RollerSlider
            },
            ok.STOP_LENGTH: {
                a.LIMIT: (20, 30),
                a.RANGE: (1, 100),
                a.TOOLTIP: Tip.STOP_LENGTH,
                a.WIDGET: RollerSlider
            },
            ok.TAPE_LENGTH: {
                a.LIMIT: (80, 140),
                a.RANGE: (5, 1000),
                a.WIDGET: RollerSlider
            },
            ok.TAPE_WIDTH: {
                a.LIMIT: (30, 60),
                a.RANGE: (5, 1000),
                a.WIDGET: RollerSlider
            },
            ok.TEXTURE: {
                a.LIMIT: (0, 1),
                a.WIDGET: RollerCheckButton
            },
            ok.THRESHOLD: {
                a.LIMIT: (.33, 1.),
                a.PRECISION: 3,
                a.RANGE: (.0, 1.),
                a.TOOLTIP: Tip.THRESHOLD,
                a.WIDGET: RollerSlider,
            },
            ok.USE_PLASMA: {
                a.LIMIT: (0, 1),
                a.TOOLTIP: Tip.USE_PLASMA,
                a.WIDGET: RollerCheckButton
            },
            ok.WAVE_AMPLITUDE: {
                a.LIMIT: (0, 10),
                a.RANGE: (0, 100),
                a.WIDGET: RollerSlider
            },
            ok.WAVE_PER_LAYER: {
                a.LIMIT: (1, 15),
                a.RANGE: (3, 6),
                a.WIDGET: RollerSlider
            },
            ok.WAVELENGTH: {
                a.LIMIT: (30., 50.),
                a.PRECISION: 1,
                a.RANGE: (.01, 50.),
                a.WIDGET: RollerSlider
            },
            ok.WHIRL: {
                a.LIMIT: (-30, 30),
                a.RANGE: (-720, 720),
                a.TOOLTIP: Tip.WHIRL,
                a.WIDGET: RollerSlider
            },
            ok.WIDTH: {
                a.LIMIT_SELF: self.get_filler_width,
                a.RANGE: (3, 10000),
                a.WIDGET: RollerSlider
            },
            ok.WIRE_THICKNESS: {
                a.LIMIT: (4, 10),
                a.RANGE: (3, 30),
                a.WIDGET: RollerSlider
            }
        }

    def collect_widget_arg(self, k, opt_key, port):
        """
        Gather together the widget keyword arguments.

        k: string
            option key

        opt_key: string
            of group

        port: Port
            Use with event settings.
        """
        a = olk
        d = {}
        e = self.pure[k]
        widget = e[a.WIDGET]

        if widget == RollerSlider:
            d['limit'] = self.get_range(k, opt_key)
            d['precision'] = e[a.PRECISION] if a.PRECISION in e else 0

        elif widget == RollerComboBox:
            d['combo_list'] = e[a.LIST]

        elif widget == OptionButton:
            d['choice_window'] = e[a.CHOICE_WINDOW]
            if a.TIP_TYPE in e:
                d['tip_type'] = e[a.TIP_TYPE]

        elif widget == RadioBox:
            d['labels'] = e[a.LABELS]

        for i in (a.TOOLTIP, a.ONLY_TOOLTIP):
            if i in e:
                d[i] = e[i]

        if a.WINDOW_SIGNAL in e:
            d['event'] = port, e[a.WINDOW_SIGNAL]
        return d

    def get_brush_list(self):
        """
        Return: list
            of available gradients
        """
        return self.stat.brush_list

    def get_column(self):
        """
        Return: int
            a randomized column value
        """
        return self.random_rc()[1]

    def get_column_limited(self, key):
        """
        Generate a random, limited, column value.

        key: string
            option key

        Return: int
            a self-limited randomized column value
        """
        return randint(*OptionLimit.row_column_limit[key])

    def get_filler_width(self, key):
        """
        Generate a random filler-space width.

        key: string
            option key
            an effect key

        Return: int
            a random value for a filler width
        """
        a = OptionLimit.filler[key]
        return randint(a[0], a[1])

    def get_frame_width(self, key):
        """
        Generate a random value for a frame width.

        key: string
            effect-type

        Return: int
            frame width
        """
        w, h = OptionLimit.width[key]
        return randint(w, h)

    def get_gradient_list(self):
        """
        Return: list
            of available gradients
        """
        return self.stat.gradient_list

    def get_gradient_offset_limited(self):
        """
        Generate a random gradient offset.

        Return: tuple
            offset for gradient
            x, y
        """
        return randint(0, 100)

    def get_pane_limit(self):
        """
        Generate a random glass pane width.

        Return: int
            a randomized glass pane width
        """
        return randint(25, 120)

    def get_pattern_list(self):
        """
        Return: list
            of available patterns
        """
        return self.stat.pattern_list

    def get_random_backdrop_style(self):
        """
        Return: string
            a randomly chosen backdrop-style
        """
        return choice(Option.BackdropStyle.names)

    def get_random_brush(self):
        """
        Return: string
            a randomly chosen brush
        """
        return choice(self.stat.brush_list)

    def get_random_gradient(self):
        """
        Return: string
            a randomly chosen gradient
        """
        return choice(self.stat.gradient_list)

    def get_random_image_effect(self):
        """
        Return: string
            a randomly chosen image-effect
        """
        n = ForWidget.LIST_SEPARATOR

        while n == ForWidget.LIST_SEPARATOR:
            n = choice(Option.Effect.names)
        return n

    def get_random_pattern(self):
        """
        Return: string
            a randomly chosen pattern
        """
        return choice(self.stat.pattern_list)

    def get_range(self, k, opt_key):
        """
        Determine the range of an option.

        k: string
            option key

        opt_key: string
            group key

        Return: tuple
            range
            of numeric
        """
        d = self.pure[k]

        if olk.RANGE in d:
            return d[olk.RANGE]

        elif olk.RANGE_SELF in d:
            return d[olk.RANGE_SELF](opt_key)

        elif olk.RANGE_FUNCTION in d:
            return d[olk.RANGE_FUNCTION]()

    def get_row_limited(self, key):
        """
        Generate a randomized integer for a self-limited row value.

        key: string
            option key

        Return: int
            of row
        """
        return randint(*OptionLimit.row_column_limit[key])

    def get_shadow_offset_limited(self):
        """
        Generate a random shadow offset.

        Return: int
            shadow offset
        """
        return randint(0, 25) * choice((-1, 1))

    def pass_bounds(self, d, option_key):
        """
        Check for under and over flow states and missing values.

        Options are using the last-used session settings.
        Hence, they may be out-of-sync with current GIMP
        installation or have a scale problem.

        d: dict
            option dict

        option_key: string
            for option limit dict
        """
        a = olk
        e = self.pure

        for k in d:
            if k in e:
                if a.RANGE in e[k]:
                    q = e[k][a.RANGE]
                    d[k] = Base.seal(d[k], q[0], q[1])

                elif a.RANGE_FUNCTION in e[k]:
                    q = e[k][a.RANGE_FUNCTION]()
                    if isinstance(q[0], basestring):
                        if d[k] not in q:
                            d[k] = q[0]

                    elif isinstance(q[0], tuple):
                        d[k] = Base.seal(d[k], q[0], q[1])

                elif a.FUNCTION in e[k]:
                    q = e[k][a.FUNCTION]()
                    if d[k] not in q:
                        d[k] = q[0]

                elif a.RANGE_SELF in e[k]:
                    q = e[k][a.RANGE_SELF](option_key)
                    d[k] = Base.seal(d[k], q[0], q[1])

                elif a.LIST in e[k]:
                    q = e[k][a.LIST]
                    if d[k] not in q:
                        d[k] = q[0]

    def random_rc(self):
        """
        Generate randomized row and column counts.

        Return: tuple
            row, column
        """
        w = h = w1 = h1 = 12
        w2, h2 = min(w1, 24), min(h1, 24)
        w3, h3 = min(w2, 36), min(h2, 36)
        return randint(1, randint(h1, randint(h2, randint(h3, h)))), randint(
            1, randint(w1, randint(w2, randint(w3, w))))


class Option:
    """Has names for image-effect and backdrop-style."""

    class Effect:
        """Is a list of image-effects for PortOption."""
        default = ImageEffect.Key.KEY_LIST[:]
        names = sorted([k for k in default])

        # Remove options that are not a main effect:
        for k in (
            ek.DROP_SHADOW,
            ek.FRAME_GRADIENT,
            ek.KEY_LIGHT_SHADOW,
            ek.FILL_LIGHT_SHADOW,
            ek.IMAGE_EDGE_SHADOW,
            ek.NO_EFFECT,
            ek.IMAGE_EFFECT,
            ek.SHADOW
        ):
            names.pop(names.index(k))
        names = [ek.NO_EFFECT, ForWidget.LIST_SEPARATOR] + names

    class BackdropStyle:
        """Is a list of backdrop-styles for PortOption."""
        default = bsk.KEY_LIST[:]
        names = sorted([k for k in default])
        names.pop(names.index(bsk.BACKDROP_STYLE))


class OptionStat:
    """Has static functions used by PortOption and Render."""

    @staticmethod
    def get_effect_keys(effect):
        """
        Generate a list of sub-effect keys for an effect.

        effect: string
            an image-effect

        Return: list
            of sub-effects
            of strings
        """
        return [effect] + \
            ImageEffect.PROPERTY[effect][ImageEffect.EFFECT_STEPS]

    @staticmethod
    def get_step_class(option_type):
        """
        Determine the step type in class-form for a step key.

        option_type: string
            either BACKDROP, Frame Gradient, or a format name

        Return: class
            step type
        """
        if option_type == sk.BACKDROP:
            return Option.BackdropStyle
        return Option.Effect

    @staticmethod
    def step_is_backdrop_style(option_type):
        """
        Determine if the step key is a backdrop-style.

        option_type: string
            either BACKDROP or an format name

        Return: flag
            If it's true, then the step is a backdrop-style.
        """
        return 1 if option_type == sk.BACKDROP else 0
