#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from random import randint, seed
from roller_image_effect import ImageEffect, LayerKey
from roller_one import One
from roller_one_constant import ForLayer, OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_render_shadow import Shadow
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb


class JaggedEdge:
    """Create a jagged edge around image material."""

    def __init__(self, one):
        """
        Do the Jagged Edge image-effect.

        one: One
            Has variables.
        """
        stat = one.stat
        d = one.d
        parent = one.parent
        j = stat.render.image
        z = stat.render.get_image_layer(
            Lay.get_format_name_from_group(parent)
        )
        jagged_edge_layer = Lay.clone(j, z)

        Lay.show(jagged_edge_layer)

        jagged_edge_layer.name = Lay.get_layer_name(
            ek.JAGGED_EDGE,
            parent=parent
        )
        z = Lay.selectable(j, jagged_edge_layer, ForLayer.MAKE_OPAQUE_DICT)

        seed(d[ok.RANDOM_SEED])
        Sel.item(j, z)
        pdb.gimp_selection_shrink(j, max(d[ok.AMPLITUDE] + 1, 6))
        Sel.clear_outside_of_selection(j, z)

        for _ in range(3):
            amp = randint(1, d[ok.AMPLITUDE])
            for i in (fu.ORIENTATION_VERTICAL, fu.ORIENTATION_HORIZONTAL):
                pdb.plug_in_shift(j, z, amp, i)

        pdb.plug_in_oilify(j, z, d[ok.SMOOTHNESS], Fu.Oilify.RGB_MODE)
        Sel.item(j, z)
        pdb.gimp_image_remove_layer(j, z)
        Sel.clear_outside_of_selection(j, jagged_edge_layer)

        if d[ok.SHADOW] != ok.NONE:
            has_inlay = False
            e = deepcopy(d)
            e[ok.OFFSET_X] = e[ok.OFFSET_Y] = 0

            if d[ok.SHADOW] == ek.INLAY_SHADOW:
                has_inlay = True
                e.pop(ok.MAKE_OPAQUE)
                e[ok.INLAY_BLUR] = d[ok.SHADOW_BLUR]
            Shadow(
                One(
                    d=e,
                    e={
                        'caster_key': (ek.JAGGED_EDGE,),
                        'is_inlay': has_inlay
                    },
                    k=LayerKey.SHADOW,
                    parent=parent,
                    stat=stat
                )
            )
