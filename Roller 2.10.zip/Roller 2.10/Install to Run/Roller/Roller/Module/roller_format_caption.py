#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_image import RollerImage
from roller_format_text import Text
from roller_image_effect import ImageEffect, LayerKey as nk
from roller_one import One
from roller_one_constant import (
    CaptionKey as ck,
    FormatKey as fk,
    ForFormat as ff,
    ForLayout as fy,
    FreeCellKey as fck,
    ImageKey as ik,
    PlaceKey as pl,
    StripeKey as st,
)
from roller_one_base import Comm
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu
import os

ek = ImageEffect.Key
pdb = fu.pdb
REPLACE = fu.CHANNEL_OP_REPLACE
YES_ANTIALIAS = 1
X_IS_0 = Y_IS_0 = W_IS_0 = H_IS_0 = 0

# margins:
BOTTOM = (
    ff.Caption.BOTTOM_CENTER,
    ff.Caption.BOTTOM_LEFT,
    ff.Caption.BOTTOM_RIGHT
)
LEFT = ff.Caption.BOTTOM_LEFT, ff.Caption.MIDDLE_LEFT, ff.Caption.TOP_LEFT
RIGHT = ff.Caption.BOTTOM_RIGHT, ff.Caption.MIDDLE_RIGHT, ff.Caption.TOP_RIGHT
TOP = ff.Caption.TOP_CENTER, ff.Caption.TOP_LEFT, ff.Caption.TOP_RIGHT


class Caption:
    """Create a text overlay on a cell."""

    def __init__(
        self,
        session,
        d,
        format_x,
        stat,
        parent=None,
        is_layout=False
    ):
        """
        Create a cell captions for a format.

        session: dict
            of session

        d: dict
            of format

        stat: Stat
            globals

        format_x: int
            index
            corresponding with the session's format list

        parent: layer
            layer group for caption layer

        is_layout: flag
            If it is true, the layout opacity is used.
        """
        self.session = session
        self.stat = stat
        self._form = d
        self._format_x = format_x
        self._is_layout = is_layout
        self._group = self.layer = None
        self._is_per_cell = 1 if d[fk.Cell.Caption.PER_CELL] else 0
        self._image_number = d[ck.CELL_CAPTION][ck.START_NUMBER]

        if not parent:
            parent = stat.render.format_group(format_x, d[fk.Layer.NAME])

        self._parent = parent

        self._do_cells()
        self._do_layer()
        if d[fk.Layer.CELL_LIST]:
            self._do_free_cell()

    def _do(self, z, cell, text, layer_key, name):
        """
        Add text. Call once per cell.

        z: layer
            to receive text

        cell: One
            Has cell data.

        text: string
            to display

        layer_key: string
            Use to find layer.

        name: string
            layer name
            either a layer or cell-type caption layer
        """
        go = 1
        j = self.stat.render.image
        d = cell.d
        font = d[ck.FONT]

        if font not in self.stat.font_list:
            Comm.info_msg(ff.MISSING_ITEM.format("Caption", "font", font))
            go = 0

        if go:
            if self._is_layout:
                color = 255, 255, 255

            else:
                color = d[ck.COLOR]

            go, z = Text.make_text_layer(
                j,
                z,
                YES_ANTIALIAS,
                X_IS_0,
                Y_IS_0,
                text,
                d[ck.SIZE],
                font,
                color,
                W_IS_0,
                H_IS_0
            )
        if go:
            Sel.item(j, z)

            _, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
            text_width = x1 - x
            text_height = y1 - y
            half_width = text_width // 2
            half_height = text_height // 2
            top, bottom, left, right = Form.combine_margin(
                d[ck.MARGIN],
                cell.w,
                cell.h
            )

            # Calculate a margin box:
            left = cell.x + left
            right = cell.x + cell.w - right
            top = cell.y + top
            bottom = cell.y + cell.h - bottom

            # The minimum size of the margin rectangle is 1 x 1 pixels:
            if right <= left:
                left = (left + right) // 2
                right = left + 1

            if bottom < top:
                top = (top + bottom) // 2
                bottom = top + 1

            w = right - left
            h = bottom - top
            n = d[ck.JUSTIFICATION]

            # Get 'y':
            if n in TOP:
                y = top

            elif n in BOTTOM:
                y = bottom - text_height

            else:
                # middle:
                y = top + (h // 2) - half_height

            # Get 'x':
            if n in LEFT:
                x = left

            elif n in RIGHT:
                x = right - text_width

            else:
                # center:
                x = left + (w // 2) - half_width

            x = min(x, cell.x + cell.w - text_width)
            y = min(y, cell.y + cell.h - text_height)
            x = max(x, cell.x)
            y = max(y, cell.y)

            pdb.gimp_layer_set_offsets(z, x, y)

            if not self._is_layout:
                z.name = name
                z.opacity = d[ck.OPACITY]
                z = Shadow.do_shadows(j, z, d[ck.SHADOW], self.stat, layer_key)

            z = self._make_stripe(
                j,
                z,
                d[ck.STRIPE],
                cell,
                name,
                d[ck.CLIP_TO_CELL]
            )
            if d[ck.CLIP_TO_CELL]:
                # Trim material out of the cell bounds:
                Sel.rect(j, cell.x, cell.y, cell.w, cell.h, option=REPLACE)
                Sel.clear_outside_of_selection(j, z, keep_sel=1)

    def _do_cells(self):
        """Do the cell captions."""
        d = self._form
        stat = self.stat
        _x = self._format_x
        parent = self._parent
        merged = Form.is_merge_cells(d)
        j = stat.render.image
        row, column = stat.layout.get_division(_x)
        double_space = Form.is_double_space(d)
        n = Lay.get_layer_name(
            nk.CELL_CAPTION,
            parent=parent
        )

        for r in range(row):
            for c in range(column):
                has_caption = 1

                # Don't do dependent merged cells:
                if merged:
                    if d[fk.Cell.Grid.PER_CELL][r][c] == (-1, -1):
                        has_caption = 0

                if has_caption and double_space:
                    has_caption = Form.is_double_space_cell(r, c, double_space)

                if has_caption:
                    e = Form.get_cell_caption(d, r, c)
                    text = self._get_text(
                        d[pl.IMAGE_PLACE][pl.IMAGE_DICT],
                        e,
                        r,
                        c
                    )
                    if not text:
                        has_caption = 0
                if has_caption:
                    if not self._group:
                        self._group = Lay.group(j, "Caption Group")

                    if not self.layer:
                        self.layer = Lay.add(j, n, parent=self._group)

                    rect = self.stat.layout.get_merge_cell_rect(
                        _x,
                        r,
                        c
                    )
                    cell = One(
                        x=rect.x,
                        y=rect.y,
                        w=rect.width,
                        h=rect.height,
                        d=e
                    )
                    self._do(self.layer, cell, text, nk.CELL_CAPTION, n)
        if self._group:
            z = Lay.merge_group(j, self._group, n=n)
            self._group = None

            Lay.order(j, z, parent)
            if self._is_layout:
                z.opacity = 66.

    def _do_free_cell(self):
        """Do captions for free-range cells."""
        stat = self.stat
        j = stat.render.image
        d = self._form
        parent = self._parent
        n = Lay.get_layer_name(
            nk.FREE_CELL_CAPTION,
            parent=parent
        )
        r = fy.FREE_CELL
        self.layer = None

        for cell in reversed(d[fk.Layer.CELL_LIST]):
            e = Form.get_cell_caption(cell, r, r)
            j1 = RollerImage.get_image(
                self.session,
                cell[pl.IMAGE_PLACE][pl.IMAGE_DICT]
            )
            text = self._get_text(
                cell[pl.IMAGE_PLACE][pl.IMAGE_DICT],
                e,
                r,
                r,
                j=j1
            )
            if text:
                if j1:
                    Form.prep_free_cell_image(j1, cell, stat.render.size)
                    w, h = j1.pocket.size
                    x, y = j1.pocket.position

                else:
                    x, y, w, h = Form.get_free_cell_rect(
                        cell[fck.CELL],
                        stat.render.size
                    )

                if not self._group:
                    self._group = Lay.group(j, "Caption Group")

                if not self.layer:
                    self.layer = Lay.add(j, n, parent=self._group)

                one = One(d=e, w=w, h=h, x=x, y=y)
                self._do(self.layer, one, text, nk.FREE_CELL_CAPTION, n)
        if self._group:
            z = Lay.merge_group(j, self._group, n=n)
            self._group = None

            # The free-range cell caption goes below the layer caption:
            if Lay.search(parent, nk.LAYER_CAPTION, is_err=0):
                offset = 1

            else:
                offset = 0

            if not d[fk.Layer.PLACE_FREE_CELL_ABOVE]:
                if Lay.search(parent, nk.CELL_CAPTION, is_err=0):
                    offset += 1

            Lay.order(j, z, parent, offset=offset)
            if self._is_layout:
                z.opacity = 66.

    def _do_layer(self):
        """Do a layer (per format) caption."""
        stat = self.stat
        d = self._form
        e = d[ck.LAYER_CAPTION]
        text = self._get_text(None, e, None, None)
        if text:
            j = stat.render.image
            self._group = Lay.group(j, "Caption Group")
            n = Lay.get_layer_name(
                nk.LAYER_CAPTION,
                parent=self._parent
            )
            self.layer = Lay.add(j, n, parent=self._group)
            cell = One(d=e)
            size = self.session['size']

            if d[ck.LAYER_CAPTION][ck.OBEY_MARGINS]:
                cell.y, bottom, cell.x, right = Form.get_layer_margin(
                    d,
                    size
                )
                cell.w = size[0] - cell.x - right
                cell.h = size[1] - cell.y - bottom

            else:
                cell.x = cell.y = 0
                cell.w, cell.h = size

            self._do(self.layer, cell, text, nk.LAYER_CAPTION, n)

            z = Lay.merge_group(j, self._group, n=n)
            self._group = None

            Lay.order(j, z, self._parent)
            if self._is_layout:
                z.opacity = 66.

    def _get_text(self, d, e, r, c, j=None):
        """
        Create the text as defined by the format
        cell data for the caption option group.

        d: dict
            of image choice

        e: dict
            Is caption cell data.

        r, c: int
            cell index

        j: RollerImage
            Use with free-range cell to get the image name.

        Return: string
            the caption
        """
        _type = e[ck.TYPE]
        text = ""

        if _type == ff.Caption.TEXT:
            text = e[ck.TEXT]

        elif _type == ff.Caption.SEQUENCE_NUMBER:
            if self._is_per_cell:
                text = str(e[ck.START_NUMBER])

            else:
                text = str(self._image_number)
                self._image_number += 1

        elif _type == ff.Caption.IMAGE_NAME:
            text = self.stat.layout.get_image_name_from_cell(
                self._format_x,
                r,
                c,
                j=j
            )
            if (
                d[ik.AS_LAYERS] and
                d[ik.TYPE] in ff.Image.Type.AS_LAYERS_LIST
            ):
                text = self.stat.layout.get_layer_name(
                    self._format_x,
                    r,
                    c,
                    j=j
                )
            elif (
                text and
                d[ik.TYPE] in (ff.Image.Type.FILE, ff.Image.Type.FOLDER)
            ):
                text = os.path.split(text)[1]

        if _type in (ff.Caption.IMAGE_NAME, ff.Caption.SEQUENCE_NUMBER):
            n = e[ck.LEADING_TEXT]
            n1 = e[ck.TRAILING_TEXT]
            if text:
                if n:
                    text = n + text
                if n1:
                    text += n1
        return text

    def _make_stripe(self, j, z, d, cell, name, is_clip):
        """
        Determine if a caption stripe is required.

        Create the caption background stripe.

        j: GIMP image
            work-in-progress

        z: layer
            Has caption.

        d: dict
            of stripe

        name: string
            type of stripe
            Use to define stripe width.

        is_clip: flag
            Is true when the caption material is clipped to the cell bounds.

        Return: layer
            Has caption and possibly stripe.
        """
        if d[st.TYPE] and d[st.OPACITY]:
            Sel.item(j, z)

            n = z.name
            is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)
            if is_sel:
                h = y1 - y
                center_y = y + h // 2
                h1 = int(h * d[st.HEIGHT])
                stripe_y = center_y - h1 // 2
                stripe_x = cell.x
                group = Lay.group(
                    j,
                    n,
                    parent=z.parent,
                    offset=pdb.gimp_image_get_item_position(j, z) + 1
                )
                z1 = Lay.add(j, n, parent=group)

                Lay.order(j, z, group)
                Sel.rect(
                    j,
                    stripe_x,
                    stripe_y,
                    cell.w,
                    h1,
                    option=REPLACE
                )
                Sel.fill(
                    z1,
                    fy.STRIPE_COLOR if self._is_layout else d[st.COLOR]
                )

                z1.opacity = 66. if self._is_layout else d[st.OPACITY]
                z = Lay.merge_group(j, group, n=n)
                if (
                    d[st.BLUR_BEHIND] and
                    not self._is_layout and
                    d[st.OPACITY] < 100.
                ):
                    self.stat.save_caption_stripe(
                        self._format_x,
                        One(
                            blur=d[st.BLUR_BEHIND],
                            cell=cell,
                            is_clip=is_clip,
                            name=name,
                            x=stripe_x,
                            y=stripe_y,
                            w=cell.w,
                            h=h1
                        )
                    )
        return z

    @staticmethod
    def blur_behind(j, stat, parent, format_x):
        """
        Blur behind any caption stripes that require the service.

        j: GIMP image
            Has render.

        stat: Stat
            globals

        parent: layer
            format group

        format_x: int
            format index in format list
        """
        def add_layer():
            """Add a blur behind layer."""
            pdb.gimp_selection_none(j)
            RenderHub.copy_for_blur(j, z, parent, stat, format_x)

            a = pdb.gimp_image_get_item_position(j, z) + 1
            z1 = Lay.paste(j, parent.layers[0])
            z1.name = Lay.get_layer_name(n + " Blur Behind", parent=parent)

            Lay.order(j, z1, parent, offset=a)
            return z1

        cell_layer = format_layer = free_cell_layer = None
        cell_sel = []
        free_sel = []
        layer_sel = []
        stripe_list = stat.get_stripe_list(format_x)

        # list of blur behind stripes:
        for i in stripe_list:
            # caption layer name:
            k = i.name

            # caption type:
            n = k.split(':')[-1].strip()

            # caption layer:
            z = pdb.gimp_image_get_layer_by_name(j, k)

            if n == nk.CELL_CAPTION:
                if not cell_layer:
                    cell_layer = add_layer()
                z2 = cell_layer
                q = cell_sel

            elif n == nk.FREE_CELL_CAPTION:
                if not free_cell_layer:
                    free_cell_layer = add_layer()
                z2 = free_cell_layer
                q = free_sel

            else:
                z2 = format_layer = add_layer()
                q = layer_sel

            Sel.rect(j, i.x, i.y, i.w, i.h, option=REPLACE)

            if Sel.is_sel(j):
                Lay.blur(j, z2, i.blur)
                if i.is_clip:
                    Sel.rect(
                        j,
                        i.cell.x,
                        i.cell.y,
                        i.cell.w,
                        i.cell.h,
                        option=fu.CHANNEL_OP_INTERSECT
                    )

            sel = stat.save_render_sel()
            if sel:
                q.append(sel)

        for x, i in enumerate((cell_sel, free_sel, layer_sel)):
            z = (cell_layer, free_cell_layer, format_layer)[x]
            if z:
                pdb.gimp_selection_none(j)

                for sel in i:
                    Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
                Sel.clear_outside_of_selection(j, z)
