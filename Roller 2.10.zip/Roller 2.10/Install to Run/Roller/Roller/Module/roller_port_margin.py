#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_one_constant import (
    ForWidget as fw,
    MarginKey,
    UIKey
)
from roller_one_preset import Preset
from roller_one_tip import Tip
from roller_port import Port
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable
import gtk

MARGIN_LABEL = "Top: {}, Bottom: {}, Left: {}, Right: {}"
MARGIN_NAME = "Top", "Bottom", "Left", "Right"
TYPES = "Fixed-Value-Size", "Fraction-of-the-{}-Size"


class PortMargin(Port):
    """Is a port with fixed and fraction-of margin widgets."""

    def __init__(self, d, g):
        """
        Start it up.

        d: dict
            Has init values.

        g: OptionButton
            Has option values.
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self.color = g.color
        self._option_data = g.get_value()
        self._button = g
        self._get_size = g.get_size if hasattr(g, 'get_size') else None
        self.margin_label = None
        Port.__init__(self, d)

    def _draw_margins(self, g):
        """
        Draw widgets in a table.

        g: VBox
            container for widgets

        q: iterable
            of strings
            keys to widgets
        """
        margin_name = MARGIN_NAME * 2
        default = Preset.get_default(MarginKey.MARGINS)
        q = []
        d = dict(
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        widget = RollerSlider

        for x, k in enumerate(default):
            if x % 4:
                label = ""

            else:
                label = TYPES[x // 4].format(self._button.fraction_of)

            label1 = margin_name[x]
            e = {
                'key': k,
                'limit': ((0, 100000), (0., 1.))[x // 4],
                'precision': (0, 6)[x // 4]
            }

            e.update(d)

            q1 = [(label, label1), widget, e]
            q.append(q1)

        if self._get_size:
            e = {
                'align': (0, 0, .9, 0),
                'text': MARGIN_LABEL.format(0, 0, 0, 0)
            }
            e.update(d)
            q.append([("", ""), RollerLabel, e])

        q.append(
            [
                ("", "Margins Preset"),
                Preset,
                dict(
                    d,
                    key=MarginKey.MARGINS,
                    on_widget_change=self.on_widget_change,
                    stat=self.stat,
                    win=self.roller_window
                )
            ]
        )

        q = RollerTable.do_wide(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )

        self.controls = q[:8]
        self.margin_label = q[-2]
        self.preset = q[-1]
        self.preset.widget_list = self.controls

        # Make a dummy preset dictionary:
        d = default

        for x, i in enumerate(self.controls):
            d[q[x].key] = self._option_data[x]

        self.preset.load_preset(fw.UNDEFINED, d)
        self.controls[0].set_tooltip_text(Tip.MARGIN)
        self._update_margin_label()

    def _update_margin_label(self):
        """Update the margin label with the latest settings."""
        if self._get_size:
            q = []

            for i in self.controls:
                q.append(i.get_value())

            top, bottom, left, right = Form.combine_margin(
                q,
                *self._get_size()
            )

            self.margin_label.widget.set_text(
                MARGIN_LABEL.format(top, bottom, left, right)
            )
            self.margin_label.show()

    def do_accept(self, *_):
        """
        Accept the margins.

        Return: true
            The key-press is handled.
        """
        q = []

        for i in self.controls:
            q.append(i.get_value())
        return self.do_accept_callback(tuple(q))

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for widgets
        """
        q = self._draw_margins, self.draw_process_group
        group_name = "Set {}s".format(self._button.key), ""

        self.reduce_color()
        self.reduce_color()
        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if group_name[x]:
                vbox.pack_start(
                    RollerLabel(
                        text=group_name[x] + ":",
                        padding=(2, 0, 4, fw.MARGIN)
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()
            g.pack_start(box, expand=False)

    def on_widget_change(self, g):
        """
        Call when a widget is changed.

        g: Widget
            Has changed.
        """
        if not Port.loading:
            self._update_margin_label()
            if g.key != MarginKey.MARGINS:
                self.preset.preset_is_undefined()
