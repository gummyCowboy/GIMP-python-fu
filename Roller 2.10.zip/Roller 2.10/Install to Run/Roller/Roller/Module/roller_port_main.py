#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_group_layout_option import GroupLayoutOption
from roller_one_constant import (
    BackdropStyleKey as bsk,
    ForWidget as fw,
    FormatKey as fk,
    OptionKey as ok,
    PresetKey,
    SessionKey as sk,
    PortKey,
    UIKey
)
from roller_one_preset import Preset
from roller_one_tip import Tip
from roller_port import Port
from roller_port_format import PortFormat
from roller_port_option import PortOption
from roller_widget_box import RollerBox
from roller_widget_button import RollerButton
from roller_widget_check_button import RollerCheckButton
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_opt_button import OptButton
from roller_widget_table import RollerTable
from roller_widget_tree import NavigationList
from roller_widget_zlist import ZList
import gtk

BACKDROP = sk.BACKDROP
BI = bsk.BACKDROP_IMAGE

# For GTK, let it know that the function handled an event:
DONE = 1

IE = ok.IMAGE_EFFECT


class PortMain(Port):
    """Is created for the main window."""
    GROUP_LABEL = "Format", "Render Option", "Layout Option"
    TITLE = "Roller 2.10"

    def __init__(self, d):
        """
        Draw widgets.

        d: dict
            Has init variables.
        """
        self._format_x = None
        self.stat = d[UIKey.STAT]
        d[UIKey.PORT_KEY] = PortKey.MAIN
        d[UIKey.WINDOW_TITLE] = PortMain.TITLE
        Port.__init__(self, d)

    def _draw_format_group(self, g):
        """
        Draw the format group.

        g: GTK container
            to receive group
        """
        g = self._format_list = ZList(
            container=g,
            create_z_list_item=self.create_z_list_item,
            edit_z_list_item=self.edit_z_list_item,
            get_item_name=self.get_format_name,
            key=sk.FORMAT_LIST,
            item_name="Format",
            on_widget_change=self.on_widget_change,
            on_delete_item=self.on_format_delete,
            on_rename_item=self.on_format_rename,
            set_item_name=self.set_format_name
        )
        self.controls += [g]

    def _draw_layout_group(self, g):
        """
        Draw the layout group.

        g: GTK container
            to receive group
        """
        g = GroupLayoutOption(
            container=g,
            on_widget_change=self.on_widget_change,
            stat=self.stat
        )
        self.controls += [g]

    def _draw_option_groups(self, g):
        """
        Draw the option groups.

        g: GTK VBox
            container for widgets
        """
        g1 = self._navigation_list
        g1.switch_group_box = g
        q = (
            self._draw_format_group,
            self._draw_render_option_group,
            self._draw_layout_group,
        )
        for x, p in enumerate(q):
            vbox = gtk.VBox()

            g1.group_box.append(vbox)
            vbox.add(
                RollerLabel(
                    padding=(2, 0, 4, 0),
                    text=PortMain.GROUP_LABEL[x] + ":"
                )
            )
            p(vbox)

    def _draw_navigation_group(self, g):
        """
        Draw the navigation list.

        g: GTK container
            container for the list
        """
        self._navigation_list = NavigationList(
            g,
            self.on_list_change,
            130,
            self.on_key_press
        )
        self._navigation_list.set_value(PortMain.GROUP_LABEL)

    def _draw_preset_group(self, g):
        """
        Draw the preset group.

        g: GTK container
            for the widgets
        """
        self.preset = Preset(
            container=g,
            key=sk.SESSION,
            on_key_press=self.on_key_press,
            stat=self.stat,
            widget_list=self.controls,
            win=self.roller_window
        )

    def _draw_process_group(self, g):
        """
        Draw the process group.

        g: GTK VBox
            container for widgets
        """
        w = fw.MARGIN
        w1 = w // 2
        hbox = RollerBox(gtk.HBox, align=(0, 0, 1, 1))
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        q = [
            RollerButton(
                on_widget_change=self.do_cancel,
                padding=(w1, w1, w, w1),
                text="Cancel"
            ),
            RollerButton(
                on_widget_change=self.show_layout,
                padding=(w1, w1, w1, w),
                text="Show Layout",
                tooltip=Tip.MAIN_LAYOUT
            ),
            RollerButton(
                on_widget_change=self.do_accept,
                padding=(0, w, w, w),
                text="Render",
                tooltip=Tip.MAIN_RENDER
            )
        ]

        for i in q[:-1]:
            hbox.pack_start(i, expand=True)
            same_size.add_widget(i.widget)

        self.keep(q)
        g.pack_start(hbox, expand=True)
        g.pack_start(q[-1], expand=False)

    def _draw_render_option_group(self, g):
        """
        Draw the render option group.

        g: GTK VBox
            container for the group of widgets
        """
        q = (
            [
                "Options:",
                OptButton,
                dict(
                    button_action=self._edit_option,
                    get_session_dict=self.get_session_dict,
                    key=sk.SESSION_OPT,
                    on_widget_change=self.on_widget_change,
                    stat=self.stat,
                    text="Effect and Style Options…",
                    tooltip=Tip.MAIN_OPTIONS
                ),
            ],
            [
                "File Handler:",
                RollerCheckButton,
                dict(
                    key=sk.CLOSE_FILE,
                    on_widget_change=self.on_widget_change,
                    text="Close opened images after first use.",
                    tooltip=Tip.MAIN_CLOSE_FILE
                )
            ]
        )
        d = RollerTable.create(
            bottom_pad=fw.MARGIN // 2,
            color=self.color,
            container=g,
            q=q
        )
        self.controls += [d[i] for i in d]
        self._option_button = d[sk.SESSION_OPT]

    def _edit_option(self, g):
        """
        Open PortOption.

        g: OptButton
            Is responsible.
        """
        self._update_render_size()
        self.switch_ports()
        PortOption(
            {
                UIKey.GET_SESSION_DICT: self.get_session_dict,
                UIKey.OPT_BUTTON: g,
                UIKey.ON_ACCEPT: self.do_accept_option,
                UIKey.ON_CANCEL: self.do_cancel_option,
                UIKey.WINDOW: self.roller_window,
                UIKey.PARENT_PORT: self,
                UIKey.PORT_KEY: PortKey.OPTION,
                UIKey.STAT: self.stat
            }
        )

    def _select_nav_list(self):
        """Select an item in the navigation list."""
        if self._navigation_list.get_sel_x() is None:
            self._navigation_list.select_item(0)

        self.on_list_change(
            self._navigation_list,
            self._navigation_list.get_sel_x()
        )

    def _show_port(self):
        """
        Call when switching to this port.

        Select a navigation list items in
        order to collapse the option groups.
        """
        self.roller_window.switch_box.add(self.pane)
        self.pane.show_all()
        self._select_nav_list()
        self.roller_window.win.set_title(PortMain.TITLE)
        self.roller_window.win.present()

        x = self._format_x
        if x is not None:
            self._format_list.select_item(x)

    def _update_render_size(self):
        """Update the render size for globals."""
        d = self._option_button.get_value()[BACKDROP][BI]
        self.stat.render.size = d[ok.RENDER_WIDTH], d[ok.RENDER_HEIGHT]

    def create_z_list_item(self, n):
        """
        Create a new format.

        Call from the ZList when the
        user activates the New Format Button.

        Is part of the ZList template.

        n: string
            name of the format

        Return: dict
            new format
        """
        d = Preset.get_default(fk.FORMAT)
        d[fk.Layer.NAME] = n

        self.on_widget_change(self._format_list)
        return d

    def do_accept(self, *_):
        """
        Begin a render.

        Return: true
            The key-press is handled.
        """
        d = self.get_session_dict()
        return self.do_accept_callback(
            d,
            self._option_button.get_render_steps(d)
        )

    def do_accept_format(self, d):
        """
        Update a format with changes made in PortFormat.

        d: dict
            of format

        Return: true
            The key-press is handled.
        """
        x = self._format_x
        Port.loading += 1

        self._format_list.update_zlist(d, x)
        self.stat.render.del_formats(del_bg=False)

        Port.loading -= 1

        self.preset.preset_is_undefined()
        self._show_port()
        return DONE

    def do_accept_option(self, d):
        """
        Call when accepting options.

        Return: true
            The key-press is handled.
        """
        self._option_button.set_value(d)
        self.preset.preset_is_undefined()
        self._show_port()
        return DONE

    def do_cancel(self, *_):
        """
        Close the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def do_cancel_format(self):
        """Call when canceling a format edit."""
        self._show_port()
        return DONE

    def do_cancel_option(self):
        """
        Call when canceling PortOption.

        Return: true
            The key-press is handled.
        """
        self._update_render_size()

        self._show_port()
        return DONE

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            to receive port
        """
        boxes = []
        q = (
            self._draw_navigation_group,
            self._draw_option_groups,
            self._draw_preset_group,
            self._draw_process_group
        )
        q1 = (
            "Category",
            "",
            "Session Preset",
            "Process"
        )

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            g1 = gtk.VBox()

            if q1[x]:
                g1.add(RollerLabel(padding=(2, 0, 4, 0), text=q1[x] + ":"))

            boxes.append(box)
            p(g1)
            self.reduce_color()

            if x % 2:
                # Add row of same size widgets:
                hbox = gtk.HBox()

                hbox.add(boxes[-2])
                hbox.add(boxes[-1])
                g.add(hbox)
            box.add(g1)
        self.return_widgets.append(self._navigation_list.treeview)

    def edit_z_list_item(self, d, x):
        """
        Switch focus to the format editor port for the selected format.

        Is part of the ZList template.

        d: dict
            of format

        x: int
            the row selected in the format list
            (0 .. n)
        """
        self._format_x = x
        n = d[fk.Layer.NAME]

        self._update_render_size()
        self.switch_ports()

        # Get Port if it has already been created:
        if PortKey.FORMAT in Port.port_dict:
            a = Port.port_dict[PortKey.FORMAT]
            a.reopen_port(n, x)

        else:
            a = PortFormat(
                {
                    UIKey.FORMAT_INDEX: x,
                    UIKey.GET_SESSION_DICT: self.get_session_dict,
                    UIKey.ON_ACCEPT: self.do_accept_format,
                    UIKey.ON_CANCEL: self.do_cancel_format,
                    UIKey.WINDOW: self.roller_window,
                    UIKey.WINDOW_TITLE: PortFormat.TITLE.format(n),
                    UIKey.PARENT_PORT: self,
                    UIKey.STAT: self.stat
                }
            )

        a.preset.load_preset(d[PresetKey.PRESET], d)

    def get_format_name(self, d):
        """
        Use with Z-List.

        d: dict
            of format

        Return: string
            format name
        """
        return d[fk.Layer.NAME]

    def get_session_dict(self, form=None, option=None):
        """
        Collect the session info.

        Return: dict
            of the session preset
        """
        d = self.preset.get_value(has_preset=True)

        # Update on callback:
        if form:
            d[sk.FORMAT_LIST][self._format_x] = form

        if option:
            d[sk.SESSION_OPT] = option

        e = d[sk.SESSION_OPT][BACKDROP][BI]
        d['size'] = d['w'], d['h'] = self.stat.render.size = \
            e[ok.RENDER_WIDTH], e[ok.RENDER_HEIGHT]
        return d

    def on_widget_change(self, g):
        """
        A widget changed.

        Keep the session dictionary up-to-date with the widgets.

        g: Widget
            the widget that changed
        """
        if not Port.loading:
            self.preset.preset_is_undefined()

    def set_format_name(self, d, n):
        """
        Use with Z-List.

        d: dict
            of format

        n: string
            format name
        """
        d[fk.Layer.NAME] = n

    def show_layout(self, *_):
        """Show a layout sketch-up."""
        self.stat.layout.show(self.get_session_dict())

    def on_format_delete(self, n):
        """
        Update session opt after format is deleted.

        n: string
            name of format
        """
        d = self._option_button.get_value()
        e = self.stat.option_group_dict
        q = [i for i in e]

        # opt button:
        if n in d:
            d.pop(n)

        self._option_button.set_value(d)
        self.stat.render.del_formats(del_bg=False)

        # option group dict:
        for opt_type, opt_key in q:
            if opt_type == n:
                e.pop((opt_type, opt_key))

    def on_format_rename(self, n, n1):
        """
        A format name changed. Update the format name references.

        n: string
            former name of format

        n1: string
            new name of format
        """
        d = self._option_button.get_value()
        e = self.stat.option_group_dict
        q = [i for i in e]

        # opt button:
        if n in d:
            d[n1] = deepcopy(d[n])
            d.pop(n)

        self._option_button.set_value(d)

        # option group dict:
        for opt_type, opt_key in q:
            if opt_type == n:
                k = opt_type, opt_key
                e[(n1, opt_key)] = deepcopy(k)
                e.pop(k)
