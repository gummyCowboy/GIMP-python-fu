#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok, Step as sk
from roller_fu import set_layer_mode
from roller_maya import check_layer
from roller_maya_build import SubBuild
from roller_fu_mode import get_mode
from roller_view_shadow import make_shadow, make_shadow_inner
from roller_view_real import INNER, SHADOW1, SHADOW2
import gimpfu as fu

pdb = fu.pdb


def check_inner_shadow(v, maya):
    """
    Produce Inner Shadow material.

    v: View
    maya: Maya
    Return: tuple
        of shadow layer
    """
    if maya.is_inner_shadow:
        return check_layer(v, maya, 'inner_shadow', do_inner_shadow)
    return maya.inner_shadow


def check_mix_inner_shadow(v, maya):
    """
    Determine the matter layer's mode or opacity change.

    v: View
    maya: Maya
    """
    check_mix_shadows(v, maya, 'inner_shadow')


def check_mix_shadows(v, maya, n):
    """
    Determine Shadow layer mode change.

    v: View
    maya: Maya
    n: string
        Shadow's layer descriptor
    """
    z = getattr(maya, n)
    if z:
        if maya.is_mode:
            m = set_layer_mode(z, get_mode(maya.value_d))
            maya.is_back += m
            v.is_back += m


def check_mix_shadow_1(v, maya):
    """
    Determine the matter layer's mode or opacity change.

    v: View
    maya: Maya
    """
    check_mix_shadows(v, maya, 'shadow_1')


def check_mix_shadow_2(v, maya):
    """
    Determine the matter layer's mode or opacity change.

    v: View
    maya: Maya
    """
    check_mix_shadows(v, maya, 'shadow_2')


def check_shadow_1(v, maya):
    """
    Produce Shadow 1 material.

    v: View
    maya: Maya
    Return: tuple
        of shadow layer
    """
    if maya.is_shadow_1:
        return check_layer(v, maya, 'shadow_1', do_shadow_1)
    return maya.shadow_1


def check_shadow_2(v, maya):
    """
    Produce Shadow 2 material.

    v: View
    maya: Maya
    Return: tuple
        of shadow layer
    """
    if maya.is_shadow_2:
        return check_layer(v, maya, 'shadow_2', do_shadow_2)
    return maya.shadow_2


def do_shadow_1(v, maya):
    """
    Create a Shadow 1 layer.

    v: View
    maya: Shadow
    Return: layer or None
        with shadow
    """
    return do_shadow_num(v, maya, "1")


def do_shadow_2(v, maya):
    """
    Create a Shadow 2 layer.

    v: View
    maya: Shadow
    Return: layer or None
        with shadow
    """
    return do_shadow_num(v, maya, "2")


def do_shadow_num(v, maya, n):
    """
    Create a numbered Shadow layer. The shadow is
    an external shadow and not an internal one.

    v: View
    maya: Shadow
    n: string
        Shadow number
        1 or 2

    Return: layer or None
        with shadow
    """
    # list of layer to cast shadow, 'q'
    q = []

    for i in maya.maya_q:
        q += [getattr(i, 'matter')]

    z = q[0].parent.parent if maya.is_wrap else q[0].parent
    return make_shadow(
        v,
        maya.value_d,
        z,
        q,
        is_wrap=maya.is_wrap,
        name=z.name + " Shadow " + n
    )


def do_inner_shadow(v, maya):
    """
    Create an Inner Shadow layer.

    v: View
    maya: Shadow
    cast: layer
        to cast shadow

    Return: layer or None
        with shadow
    """
    z = maya.maya_q[0].matter
    return make_shadow_inner(
        v, maya.value_d, z, name=z.name + " Inner Shadow"
    )


class ShadowBack(SubBuild):
    """Has an 'is_back' attribute for Shadow1 and Shadow2."""

    def __init__(self, *q):
        SubBuild.__init__(self, *q)

        # Is used to by the mix check function to record background change.
        self.is_back = False


class Shadow1(ShadowBack):
    """
    Manage Shadow 1 layer output. Shadow 1 can process multiple caster layer,
    and in the layer dock, its shadow output is below any caster layer.
    """
    issue_q = 'mode', 'shadow_1'
    put = (check_shadow_1, 'shadow_1'), (check_mix_shadow_1, None)

    def __init__(self, any_group, super_maya, maya_q, k_path, is_wrap):
        """
        any_group: AnyGroup
            origin of option

        super_maya: Maya
            Is the super Shadow.

        maya_q: iterable
            of Maya, ...

            The Shadow-caller, a Maya, is expected to have a
            matter layer and a 'is_matter' attribute. The
            entire iterable is treated as a unified group where
            each of matter layer is merged into a single caster layer.

        is_wrap: bool
            If True, then an the Shadow 1 layer is placed
            at the bottom of the wrapping parent layer group.
        """
        self.maya_q = maya_q
        self.is_wrap = is_wrap
        ShadowBack.__init__(
            self, any_group, super_maya, k_path + (sk.SHADOW_1,), None
        )

    def do(self, v, d, is_outer):
        """
        Manage layer output during a View run.

        v: View
        d: dict
            Shadow Preset
            {Option key: Widget value}

        is_outer: bool
            Is True if the shadow caster group has change.

        Return: bool
            Is True if there is background change.
        """
        self.value_d = d[sk.SHADOW_1]
        self.is_shadow_1 |= self.super_maya.is_shadow or is_outer

        self.realize(v)

        is_back = self.is_shadow_1 or self.is_back

        self.reset_issue()

        self.is_back = False
        return is_back


class Shadow2(ShadowBack):
    """
    Produces in the same way as Shadow 1, but has different key attribute.
    """
    issue_q = 'mode', 'shadow_2'
    put = (check_shadow_2, 'shadow_2'), (check_mix_shadow_2, None)

    def __init__(self, any_group, super_maya, maya_q, k_path, is_wrap):
        """
        any_group: AnyGroup
            Is where this option originates.

        super_maya: Maya
            Is the super Shadow.

        maya_q: iterable
            of Maya, ...

            The Shadow-caller, a Maya, is expected to have a
            matter layer and a 'is_matter' attribute. The
            entire iterable is treated as a unified group where
            each of matter layer is merged into a single caster layer.

        is_wrap: bool
            If True, then the Shadow 2 layer is placed
            at the bottom of the wrapping parent group.
        """
        self.maya_q = maya_q
        self.is_wrap = is_wrap
        ShadowBack.__init__(
            self, any_group, super_maya, k_path + (sk.SHADOW_2,), None
        )

    def do(self, v, d, is_outer):
        """
        Manage layer output during a View run.

        v: View
        d: dict
            Shadow Preset

        is_outer: bool
            Is True if the shadow caster group has change.

        Return: bool
            Is True if the background changed.
        """
        self.value_d = d[sk.SHADOW_2]
        self.is_shadow_2 |= self.super_maya.is_shadow or is_outer

        self.realize(v)

        is_back = self.is_shadow_2 or self.is_back

        self.reset_issue()

        self.is_back = False
        return is_back


class Inner(SubBuild):
    """
    Manage Inner Shadow layer output. Inner Shadow processes one caster layer,
    and in the layer dock, its shadow output lies above the caster layer.
    """
    issue_q = 'mode', 'inner_shadow'
    put = (check_inner_shadow, 'inner_shadow'), (check_mix_inner_shadow, None)

    def __init__(self, any_group, super_maya, maya_q, k_path):
        """
        any_group: AnyGroup
            Is where this option originates.

        super_maya: Maya
            Is the super Shadow.

        maya_q: iterable
            of Maya, ...

            The Shadow-caller, a Maya, is expected to have a
            matter layer and a 'is_matter' attribute. The first
            Maya's matter layer is the Inner Shadow caster layer.

        k_path: tuple
            Is a key path to the Shadow option in the vote dict.
        """
        # Use to flag Inner Shadow's change
        # state after calling the 'do' function, 'had_change'.
        self.had_change = False

        # Isn't used but is here to be compatible
        # with Shadow1 and Shadow2's mix check.
        self.is_back = False

        self.maya_q = maya_q
        SubBuild.__init__(
            self, any_group, super_maya, k_path + (sk.INNER_SHADOW,), None
        )

    def do(self, v, d, is_inner):
        """
        Manage layer output during a View run.

        v: View
        d: dict
            Shadow Preset

        is_inner: bool
            Is True if the shadow caster has change.

        Return: bool
            Is True if there is matter change.
        """
        self.value_d = d[sk.INNER_SHADOW]
        self.is_inner_shadow |= self.super_maya.is_shadow or is_inner
        self.had_change = self.is_inner_shadow
        self.realize_vote(v)


class Shadow(SubBuild):
    """Manage layer output for a Shadow Preset Button."""
    issue_q = 'shadow',
    put = ()

    def __init__(
        self,
        any_group,
        super_maya,
        k_path,
        maya_q,
        is_wrap=True,
        has_inner=True
    ):
        """
        super_maya: Maya
            Has a Shadow option.

        k_path: tuple
            Is a key path to the Shadow option in the vote dict.

        maya_q: iterable
            of Maya, ...

            A Shadow-caller, a Maya, is expected to have
            a matter layer and a 'is_matter' attribute.

        is_wrap: bool
            If True, then Shadow 1 and Shadow 2 layer output
            is placed at the bottom of the wrapping parent group.

        has_inner: bool
            If False, then bypass the inner shadow option.
        """
        self.maya_q = maya_q
        self.has_inner = has_inner

        SubBuild.__init__(
            self, any_group, super_maya, k_path + (sk.SHADOW_SWITCH,), None
        )

        self.sub_maya[SHADOW1] = Shadow1(
            any_group, self, maya_q, k_path, is_wrap
        )
        self.sub_maya[SHADOW2] = Shadow2(
            any_group, self, maya_q, k_path, is_wrap
        )
        self.sub_maya[INNER] = Inner(any_group, self, maya_q, k_path)

    def do(self, v, d, is_inner, is_outer):
        """
        Manage layer output during a View run.

        v: View
        d: dict
            Shadow Preset

        is_inner: bool
            Is True if the shadow caster has change.

        is_outer: bool
            Is True if the shadow caster group has change.

        Return: bool
            If True, then the background has changed.
        """
        self.value_d = d
        self.go = d[sk.SHADOW_SWITCH][ok.SWITCH]
        is_back = False

        if self.go:
            is_back |= self.sub_maya[SHADOW1].do(v, d, is_outer)
            is_back |= self.sub_maya[SHADOW2].do(v, d, is_outer)
            if self.has_inner:
                self.sub_maya[INNER].do(v, d, is_inner)

        else:
            if self.has_inner:
                is_back = any((
                    self.sub_maya[SHADOW1].shadow_1,
                    self.sub_maya[SHADOW2].shadow_2,
                    self.sub_maya[INNER].inner_shadow,
                ))

            else:
                is_back = any((
                    self.sub_maya[SHADOW1].shadow_1,
                    self.sub_maya[SHADOW2].shadow_2
                ))

            # Future developer, why call this here?
            self.die(v)

        self.reset_issue()
        return is_back

    def get_any_vote(self):
        """
        Determine the status of Shadow vote.

        Return: bool
            Is True if there is change.
        """
        return any((
            self.is_shadow,
            self.sub_maya[SHADOW1].is_shadow_1,
            self.sub_maya[SHADOW2].is_shadow_2,
            self.sub_maya[INNER].is_inner_shadow
        ))

    def reset_all_issue(self):
        """Call to reset issue when the 'do' function isn't used."""
        self.reset_issue()
        self.sub_maya[SHADOW1].reset_issue()
        self.sub_maya[SHADOW2].reset_issue()
        self.sub_maya[INNER].reset_issue()
