#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_fu import (
    add_layer,
    blur_selection,
    clear_selection,
    clear_inverse_selection,
    clone_layer,
    clone_opaque_layer,
    get_layer_position,
    load_selection,
    make_layer_group,
    merge_layer_group,
    select_item,
    set_layer_mode
)
from roller_fu_mode import get_mode
from roller_maya import check_matter, check_mix_basic
from roller_maya_build import Build
from roller_maya_shadow import Shadow
from roller_one_gegl import emboss
from roller_view_hub import color_layer_default, do_curves
from roller_view_real import INNER, clone_background
import gimpfu as fu

MIXED_EDGE = ff.WHITE_MIXED, ff.GREY_MIXED
MODE_1 = (
    fu.LAYER_MODE_DIVIDE,
    fu.LAYER_MODE_DIVIDE,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT
)
MODE_2 = (
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_GRAIN_EXTRACT,
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_SUBTRACT,
    fu.LAYER_MODE_SUBTRACT
)
MODE_3 = (
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_LINEAR_LIGHT,
    fu.LAYER_MODE_NORMAL
)
MODE_4 = (
    fu.LAYER_MODE_MULTIPLY,
    fu.LAYER_MODE_DIFFERENCE,
    fu.LAYER_MODE_DIFFERENCE,
    fu.LAYER_MODE_MULTIPLY,
    fu.LAYER_MODE_DIFFERENCE,
    fu.LAYER_MODE_DIFFERENCE
)
pdb = fu.pdb


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: PaintRush
    Return: layer
        with color
    """
    def _clear_selection():
        """
        Clear the center selection and the area outside of the image material.
        """
        load_selection(j, sel1)
        clear_inverse_selection(z)
        load_selection(j, sel)
        clear_selection(z)

    j = v.j
    cast = maya.cast.matter
    parent = cast.parent
    d = maya.value_d
    group = make_layer_group(
        j,
        "Paint Rush WIP",
        parent=parent,
        offset=get_layer_position(cast)
    )
    x = ff.PAINT_RUSH_TYPE.index(d[ok.EDGE_TYPE])
    group.mode = fu.LAYER_MODE_LIGHTEN_ONLY
    z = first_z = clone_opaque_layer(cast)
    z.mode = MODE_1[x]

    select_item(z)
    clear_inverse_selection(z)
    pdb.gimp_image_reorder_item(j, z, group, 0)

    # amount, '2.'; wrap, '1'; Sobel, '0'
    pdb.plug_in_edge(j, z, 2., 1, 0)

    z = dark_z = clone_layer(z, n="Dark")
    z.mode = MODE_2[x]

    pdb.gimp_image_lower_item_to_bottom(j, z)

    z = light_z = clone_layer(z, n="Light")
    z.mode = MODE_3[x]
    w = d[ok.WIDTH]

    while w:
        w1 = min(w, 500.)
        w -= w1
        blur_selection(z, w1)

    if d[ok.EDGE_TYPE] in MIXED_EDGE:
        w = d[ok.WIDTH] // 2.
        while w:
            w1 = min(w, 500.)
            w -= w1
            blur_selection(z, w1)

    pdb.gimp_image_lower_item_to_bottom(j, z)

    # Protect the center with a grey layer.
    z = clone_layer(dark_z, n="Burn")
    z.mode = fu.LAYER_MODE_BURN

    pdb.gimp_image_reorder_item(j, z, group, 2)
    do_curves(z, (.0, .5, 1., .5))
    select_item(z)
    pdb.gimp_selection_shrink(j, int(d[ok.WIDTH]))

    sel = pdb.gimp_selection_save(j)

    clear_inverse_selection(z)
    select_item(first_z)

    sel1 = pdb.gimp_selection_save(j)
    z = clone_layer(light_z, n="Accent")
    z.mode = MODE_4[x]

    pdb.gimp_image_lower_item_to_bottom(j, z)

    z = add_layer(j, "Grey", parent=group, offset=len(group.layers))

    color_layer_default(z, (127, 127, 127))

    n = d[ok.EDGE_MODE]
    z = z1 = merge_layer_group(group)

    set_layer_mode(z, get_mode({ok.MODE: n}))
    _clear_selection()

    if n == "Burn":
        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)

    else:
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

    if d[ok.POST_BLUR]:
        blur_z = clone_background(v, z, n="Post Blur", is_hide=False)

        pdb.gimp_image_remove_layer(j, z)

        z = blur_z

        blur_selection(z, d[ok.POST_BLUR])
        _clear_selection()

    if d[ok.CRW][ok.EMBOSS]:
        emboss_z = clone_background(v, z, is_hide=False, on_top=True)
        z = clone_layer(emboss_z, n="Overlay")
        z.mode = fu.LAYER_MODE_OVERLAY

        emboss(z, v.glow_ball.azimuth, v.glow_ball.elevation, 3)
        load_selection(j, sel)

        for i in (z, z1, emboss_z):
            if pdb.gimp_item_is_valid(i):
                clear_selection(i, keep_sel=True)

        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

        load_selection(j, sel1)
        clear_inverse_selection(z)

    if d[ok.CRW][ok.COLORIZE]:
        z = clone_background(
            v, z, n="Colorify", is_hide=False, on_top=True
        )
        z.opacity = d[ok.COLORIZE_OPACITY]

        pdb.plug_in_colorify(j, z, d[ok.COLOR_1])

        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        _clear_selection()

    pdb.gimp_image_remove_channel(j, sel)
    pdb.gimp_image_remove_channel(j, sel1)

    z.name = parent.name + " Paint Rush"
    return z


class PaintRush(Build):
    """Create a frame over the subject material by altering it."""
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        Build.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.CRW,)],
            do_matter
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cast, self)
        )

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)

        is_back = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], is_change, self.is_matter
        )

        z = self.sub_maya[ok.SHADOW].sub_maya[INNER].inner_shadow

        if z:
            a = get_layer_position(self.matter)
            pdb.gimp_image_reorder_item(v.j, z, z.parent, a)

        self.reset_issue()
        return is_back
