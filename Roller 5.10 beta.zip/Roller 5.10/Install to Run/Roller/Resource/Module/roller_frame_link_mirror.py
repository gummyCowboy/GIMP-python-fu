#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice, randint
from roller_constant_key import Option as ok
from roller_frame import MetalCanvas, make_canvas_frame_sel, do_metal_sel
from roller_fu import (
    add_layer,
    clone_layer,
    flip_layer,
    load_selection,
    make_layer_group,
    merge_layer_group,
    remove_z,
    select_opaque,
    select_item,
    select_rect
)
from roller_one import make_2d_table
from roller_one_rect_table import RectTable
from roller_view_hub import color_selection_default
from roller_view_preset import combine_seed
from roller_view_real import isolate_wip_rect
import gimpfu as fu

# connection vector type (line type enum).
# A graph boundary is a virtual connection.
NONE, REAL, VIRTUAL = 0, 1, 2

# screen-oriented start-point direction index
RIGHT_X, DOWN_X, LEFT_X, UP_X,  = range(4)

# Determine the direction index of an end-point.
# Up and down switch. Left and right switch.
OPPOSITE_DIR_X = 2, 3, 0, 1
pdb = fu.pdb


def do_filler(v, maya):
    """
    Make the frame.

    v: View
    maya: Frame
    Return: layer
        with the Frame
    """
    j = v.j
    d = maya.value_d[ok.WRW][ok.FILLER_LM]
    e = maya.value_d[ok.WRW][ok.WRAP]
    super_group = maya.super_maya.group
    group = make_layer_group(
        j,
        super_group.name + " Filler",
        parent=super_group,
        offset=len(super_group.layers)
    )

    # Canvas frame
    pdb.gimp_selection_none(j)
    make_canvas_frame_sel(v, d)

    sel = pdb.gimp_selection_save(j)

    combine_seed(v, d)

    # link layer
    z = add_layer(j, group.name + " Link", parent=group)
    graph = LineGraph(v.wip.rect, int(d[ok.ROW]), int(d[ok.COLUMN]))

    graph.add_real(d[ok.SCATTER_COUNT])
    graph.connect_line()
    graph.draw_connection(j, float(d[ok.LINE_W]))
    draw_corner(v)
    load_selection(j, sel, option=fu.CHANNEL_OP_ADD)
    pdb.gimp_image_remove_channel(j, sel)
    select_opaque(maya.cast.matter, option=fu.CHANNEL_OP_SUBTRACT)
    do_metal_sel(v, z, e)
    return merge_layer_group(group)


def draw_corner(v):
    """
    Flip the topleft-quarter selection into the other canvas corners.

    v: View
    maya: LinkMirror
    Return: state of selection
    """
    j = v.j
    z = add_layer(j, "Corner")

    color_selection_default(z, (0, 0, 0))
    isolate_wip_rect(v, z)

    z = clone_layer(z)

    flip_layer(z, is_h=True)

    z = pdb.gimp_image_merge_down(z.image, z, fu.CLIP_TO_IMAGE)
    z = clone_layer(z)

    flip_layer(z)

    z = pdb.gimp_image_merge_down(z.image, z, fu.CLIP_TO_IMAGE)

    select_item(z)
    remove_z(z)


def get_end_point_index(r, c, dir_x):
    """
    Determine the cell index of a cell connection
    which depends on one of four directions
    indicated by direction index.

    dir_x: int
        0 to 3
        direction index

    Return: tuple
        (row, column)
        cell index of the connected cell
    """
    # point direction tuple, (left, down, right, up)
    return r + (0, 1, 0, -1)[dir_x], c + (1, 0, -1, 0)[dir_x]


def what_is_real_state(a):
    """
    Determine if a point is REAL and connected.

    a: list
        [direction index]
        [right, down, left, up]
    """
    is_real = False
    count = 0

    # direction index, 'b'
    for b in a:
        if b == REAL:
            is_real = True
            count += 1
        elif b == VIRTUAL:
            count += 1
    return is_real, count


class LineGraph:
    """ Create randomized Connectors for Maze Mirror. """
    # ordered vector direction, (x, y)

    def __init__(self, rect, row, column):
        """
        rect: tuple
            (x, y, w, h) of float
            space for graph

        row: int
            row count

        column: int
            column count
        """
        a, b = divmod(row, 2)
        graph_row = a + b + 1
        a, b = divmod(column, 2)
        graph_column = a + b + 1

        # endian index with a connector, 'last'
        last_r = graph_row - 1
        last_c = self.last_c = graph_column - 1

        self._rc_q = [(r, c) for r in range(last_r) for c in range(last_c)]
        self._grid = RectTable(rect, row, column).table
        q = self.graph = make_2d_table(graph_row, graph_column)

        # Initialize the line matrix to a disconnected state.
        for r in range(graph_row):
            for c in range(graph_column):
                self.graph[r][c] = [0] * 4

        # connection type for edges, 'a'
        a = VIRTUAL

        # The graph boundaries are connected by virtual connections.
        for c in range(graph_column):
            q[0][c][UP_X] = q[0][c][LEFT_X] = q[0][c][RIGHT_X] = \
                q[last_r][c][DOWN_X] = q[last_r][c][LEFT_X] = \
                q[last_r][c][RIGHT_X] = a

        for r in range(graph_row):
            q[r][0][LEFT_X] = q[r][0][UP_X] = q[r][0][DOWN_X] = \
                q[r][last_c][RIGHT_X] = q[r][last_c][UP_X] = \
                q[r][last_c][DOWN_X] = a

    def add_real(self, add_count):
        """
        Add REAL points to the line graph.

        add_count: float
            requested number of points to add to the graph
        """
        graph = self.graph
        q = [(r, c, dir_x) for dir_x in range(4) for r, c in self._rc_q]
        while len(q) and add_count:
            r, c, dir_x = choice(q)
            a = graph[r][c]
            if a[dir_x] == NONE:
                add_count -= 1.

                # start point
                a[dir_x] = REAL

                # end-point
                r1, c1 = get_end_point_index(r, c, dir_x)
                dir_x1 = OPPOSITE_DIR_X[dir_x]
                b = graph[r1][c1]

                if b[dir_x1] == NONE:
                    b[dir_x1] = REAL
                if (r1, c1, dir_x1) in q:
                    q.pop(q.index((r1, c1, dir_x1)))
            q.pop(q.index((r, c, dir_x)))

    def connect_line(self):
        """
        Scan through the 'self.graph' table for disconnected points.

        When all disconnected points are connected, the scan stops.
        Connections end at the graph boundaries or with self-contained loops.

        A line segment has end points. Each point has up to four directions
        that lines can connect. There are two connection vector types.
        Once a line segment has two connections that are
        real and/or virtual, then the point is connected.
        """
        graph = self.graph
        real_q = []

        # Create a list of (row, column) of disconnected REAL point.
        for r, c in self._rc_q:
            # Determine if the point at (r, c) is connected
            # and real. If the connect count is less than
            # two, then the point is disconnected.
            is_real, count = what_is_real_state(graph[r][c])
            if is_real and count < 2:
                real_q += [(r, c)]

        while real_q:
            r, c = choice(real_q)

            # Find a disconnected direction.
            while 1:
                dir_x = randint(0, 3)
                if graph[r][c][dir_x] == NONE:
                    # Found it.
                    break

            # Add a line from this point.
            r1, c1 = get_end_point_index(r, c, dir_x)
            dir_x1 = OPPOSITE_DIR_X[dir_x]
            graph[r][c][dir_x] = graph[r1][c1][dir_x1] = REAL

            real_q.pop(real_q.index((r, c)))
            is_real, count = what_is_real_state(graph[r1][c1])
            if is_real and count < 2:
                real_q += [(r1, c1)]

    def draw_connection(self, j, line_w):
        """
        Select REAL type connection in the graph.

        j: GIMP image
            work-in-progress

        line_w: int
            Define selection size.
            For vertical, it is the width of the selection rectangle.
            For horizontal, it is the height of the selection rectangle.

        Return: state of selection
        """
        q = self.graph
        q1 = self._grid

        pdb.gimp_selection_none(j)
        for r, c in self._rc_q:
            a = q[r][c]

            # direction index, 'dir_x'
            for dir_x in range(2):
                if a[dir_x] == REAL:
                    r1, c1 = get_end_point_index(r, c, dir_x)
                    dir_x1 = OPPOSITE_DIR_X[dir_x]
                    if q[r1][c1][dir_x1] in (REAL, VIRTUAL):
                        x, y = q1[r][c].position
                        x1, y1 = q1[r1][c1].position
                        w, h = abs(x - x1), abs(y - y1)

                        if not w:
                            w = line_w

                        else:
                            if c1 != self.last_c:
                                w += line_w
                            h = line_w
                        select_rect(j, x, y, w, h, option=fu.CHANNEL_OP_ADD)


class LinkMirror(MetalCanvas):
    """
    Is a metallic-like wrap with a random
    canvas spread connectors linked together.
    """

    def __init__(self, any_group, super_maya, k_path):
        MetalCanvas.__init__(
            self,
            any_group,
            super_maya,
            k_path,
            do_filler,
            (ok.WRW, ok.FILLER_LM)
        )
