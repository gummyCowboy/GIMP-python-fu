#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Backdrop as bs, Issue as vo
from roller_constant_key import (
    BackdropStyle as by, Group as gk, Option as ok, Step as sk
)
from roller_one_extract import get_model_list_group, get_option_list_choice
from roller_fu import hide_layer, show_layer, validate_layer
from roller_one_the import The
import gimpfu as fu

pdb = fu.pdb


def hide_plan(v):
    """Hide the Plan group."""
    z = v.plan.plan_group
    if validate_layer(z):
        hide_layer(z)
        pdb.gimp_displays_flush()


def show_work(v):
    """Show the Work group."""
    j = v.j
    if j and j.layers:
        z = j.layers[-1]
        if z and z is not v.plan.plan_group and validate_layer(z):
            if not z.visible:
                show_layer(z)

                model_group = get_model_list_group()
                q = model_group.work.get_model_folder_list()

                for i in q:
                    show_layer(i)
                pdb.gimp_displays_flush()


class Work:
    """Render layer per option group."""

    def __init__(self):
        self.is_frozen = False

    def do(self, v, step_q):
        """
        Perform a peek, preview or finish the render.

        v: View
        step_q: list
            [Step key, ...]
        """
        def _refresh():
            # Remove selection because the marching ants are slow to draw.
            # Flushing the display will fail if ignored for too long.
            pdb.gimp_selection_none(v.j)
            pdb.gimp_displays_flush()

        self.is_frozen = False
        is_ice = The.helm.get_group(sk.GLOBAL).widget_d[ok.HIDE_LAYER].get_a()

        show_work(v)
        hide_plan(v)

        # [(navigation step key: AnyGroup)], 'step_q'
        for k, any_group in step_q:
            if is_ice:
                # Freeze GIMP's Layers dock and hide layers.
                if v.j:
                    pdb.gimp_image_freeze_layers(v.j)
                    is_ice = False
                    self.is_frozen = True

            any_group.do(v)

            # Image Gradient with a Show Sample status needs to be redone.
            if any_group.item.key == gk.BACKDROP and v.is_preview:
                style, style_d = get_option_list_choice(
                    any_group.value_d[ok.BACKDROP_STYLE]
                )
                if (
                    style == by.IMAGE_GRADIENT and
                    style_d[ok.PREVIEW_MODE] == bs.SHOW_SAMPLE
                ):
                    any_group.cast_vote(1, ok.SAMPLE_COUNT, vo.MATTER, True)

            _refresh()
            if any_group.item.key in gk.IMAGE_USER:
                v.pre_j_d[k] = deepcopy(v.j_d)

        if v.j:
            z = v.j.layers[-1]

            if validate_layer(z):
                v.j.active_layer = z
            if self.is_frozen:
                pdb.gimp_image_thaw_layers(v.j)
                self.is_frozen = False
        _refresh()
