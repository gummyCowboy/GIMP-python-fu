#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Issue as vo
from roller_constant_key import Option as ok
from roller_def_share import (
    GRADIENT_END_X,
    GRADIENT_END_Y,
    GRADIENT_START_X,
    GRADIENT_START_Y,
    GRADIENT_TYPE,
    IGR,
    IRR,
    OFFSET,
    SWITCH,
    set_issue
)

GRADIENT_LIGHT = OrderedDict([
    (ok.SWITCH, deepcopy(SWITCH)),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.START_X, deepcopy(GRADIENT_START_X)),
    (ok.START_Y, deepcopy(GRADIENT_START_Y)),
    (ok.END_X, deepcopy(GRADIENT_END_X)),
    (ok.END_Y, deepcopy(GRADIENT_END_Y)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.IRR, deepcopy(IRR)),
    (ok.IGR, IGR)
])
set_issue(GRADIENT_LIGHT, None, vo.MATTER, (ok.INFLUENCE,))
