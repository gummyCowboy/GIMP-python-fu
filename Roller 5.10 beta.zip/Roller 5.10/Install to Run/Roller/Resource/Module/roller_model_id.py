#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
import sys


class ModelId:
    """Use to lessen the impact of Model name change."""
    # Remember the Model id after an assignment and reduce
    # the possibility of a duplicate id in play.
    used_id = []

    def __init__(self):
        """Initialize the model id database."""
        # {model id: model name}
        # {int: string}
        self._model_id_d = {}

    def delete_with_id(self, id_):
        """
        Remove a Model id using the Model id.

        id_: int
            Model id key
        """
        if id_ in self._model_id_d:
            self._model_id_d.pop(id_)

    def delete_with_name(self, n):
        """
        Remove a Model id using the Model name.

        n: string
            Model name value (unique)
        """
        q = [i for i in self._model_id_d]
        for i in q:
            if self._model_id_d[i]['name'] == n:
                self._model_id_d.pop(i)
                break

    def get_id(self, n):
        """
        Get the Model id from a Model name.

        n: string
            item name

        Return: int
            id for the Model
            Is None if the item is not found.
        """
        for i, a in self._model_id_d.items():
            if a['name'] == n:
                return i

    def get_model(self, a):
        """
        Fetch the Model given its identifier.

        a: value
            int or string
            If the value is an int, then the value is used as a Model id key.
            Otherwise, the value is seen as a Model name, and searched for.

        Return: Model or None
        """
        d = self._model_id_d

        if isinstance(a, int):
            if a in d:
                return d[a]['model']
        else:
            for i, b in d.items():
                if b['name'] == a:
                    return b['model']

    def get_name(self, a):
        """
        Get the name from an Model id.

        a: int
            Model id

        Return: string or None
            Model name
            Is None if the id is not found.
        """
        if a in self._model_id_d:
            return self._model_id_d[a]['name']

    def make_id(self, n, model):
        """
        Assign an id to an item name.

        n: string
            Model name

        model: Model
            to add

        Return: int
            Model id
        """
        while 1:
            a = randint(-sys.maxint, sys.maxint)
            if a not in ModelId.used_id:
                self._model_id_d[a] = {'name': n, 'model': model}
                ModelId.used_id += [a]
                break
        return a

    def rename(self, old_name, new_name):
        """
        Rename a Model.

        old_name: string
            previous Model name

        new_name: string
            new Model name
        """
        d = self._model_id_d
        for k in d:
            if d[k]['name'] == old_name:
                d[k]['name'] = new_name
                break
