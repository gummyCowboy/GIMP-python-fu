#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_fu import (
    blur_selection,
    clone_layer,
    invert_and_desaturate,
    make_layer_group,
    merge_layer,
    merge_layer_group
)
from roller_fu_mode import get_gradient_mode
from roller_maya_style import Style
from roller_one_gegl import emboss
from roller_view_preset import combine_seed
from roller_view_real import (
    add_sub_base_group,
    add_wip_layer,
    do_gradient_for_layer,
    finish_style,
    insert_copy_above
)
from roller_view_hub import get_gradient_factors
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: Style
    Return: layer
        with Density Gradient
    """
    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya)
    z = add_wip_layer(v, "Plasma", maya.group)
    group = make_layer_group(j, "WIP", parent=parent, z=z)

    combine_seed(v, d)
    pdb.gimp_selection_none(j)

    # lowest turbulence, '1.'
    pdb.plug_in_plasma(j, z, int(d[ok.SEED] + v.glow_ball.seed), 1.)

    z = add_wip_layer(v, "Difference", group)
    z.mode = fu.LAYER_MODE_DIFFERENCE

    # medium turbulence, '3.5'
    pdb.plug_in_plasma(j, z, randint(0, 100000), 3.5)

    z = z1 = add_wip_layer(v, "Difference 2", group)
    z.mode = fu.LAYER_MODE_DIFFERENCE

    # highest turbulence, '7.'
    pdb.plug_in_plasma(j, z, randint(0, 100000), 7.)

    z = insert_copy_above(v, z, group.layers[0])
    z.mode = fu.LAYER_MODE_GRAIN_EXTRACT

    for i in ((255, 0, 0), (0, 255, 0), (255, 0, 255)):
        pdb.plug_in_colortoalpha(j, z, i)

    pdb.plug_in_unsharp_mask(
        j, z1,
        3.,                     # radius
        100.,                   # amount
        .0                      # threshold
    )
    z2 = clone_layer(z1, n="Blur")

    blur_selection(z1, 3)

    z1.mode = fu.LAYER_MODE_NORMAL
    z2.mode = fu.LAYER_MODE_DIFFERENCE
    z = clone_layer(z1, n="HSV Saturation")
    z.mode = fu.LAYER_MODE_HSV_SATURATION

    pdb.gimp_image_reorder_item(j, z, group, 0)

    z = clone_layer(z, n="Difference #3")
    z.mode = fu.LAYER_MODE_DIFFERENCE
    z = insert_copy_above(v, z, group.layers[0])
    z.mode = fu.LAYER_MODE_EXCLUSION

    emboss(z, v.glow_ball.azimuth, 30, 2)

    z1 = clone_layer(z, n="Exclusion #2")
    z1.mode = fu.LAYER_MODE_EXCLUSION
    e = get_default_value(by.GRADIENT_FILL)

    e.update(d)

    merge_layer_group(group)

    e[ok.GRADIENT] = d[ok.BRW][ok.GRADIENT]
    e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
        get_gradient_factors(d)
    z = do_gradient_for_layer(v, e, parent, 0)
    z.mode = get_gradient_mode(d)

    merge_layer(z)

    z = merge_layer_group(parent)

    invert_and_desaturate(d[ok.IDR], z)
    return finish_style(z, "Density Gradient")


class DensityGradient(Style):
    """Create Backdrop Style output."""
    is_dependent = False
    is_seeded = True

    def __init__(self, any_group, super_maya, k_path):
        k_path = [k_path, k_path + (ok.BRW,), k_path + (ok.IDR,)]
        Style.__init__(self, any_group, super_maya, k_path, make_style)
