#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import (
    Backdrop as bs,
    Gradient as fg,
    Issue as vo,
    Shape as sh,
    Triangle as ft
)
from roller_constant_key import Option as ok, Widget as wk
from roller_def_share import (
    BLOCK_H,
    BLOCK_W,
    BLUR,
    BRW,
    BSRR,
    CLIP,
    COLOR_1,
    COLOR_2A,
    CRITERION,
    ANGLE,
    FILL_MODE,
    GRADIENT_ANGLE,
    GBR,
    GRADIENT_MODE,
    GRADIENT_END_X,
    GRADIENT_END_Y,
    GRADIENT_START_X,
    GRADIENT_START_Y,
    GRADIENT_TYPE,
    IDF,
    IDK,
    IDR,
    IDT,
    IFR,
    IFRW,
    INVERT,
    IRR,
    MODE,
    NOISE_AMOUNT,
    OFFSET,
    OPACITY,
    P3R,
    PBR,
    R_C,
    RKR,
    HSL,
    SEED,
    START_X,
    START_Y,
    SUPERPIXEL_SIZE,
    THRESHOLD,
    make_radio_tip,
    make_rainbow_count_tip,
    make_rainbow_tip,
    make_text_tip,
    set_issue
)
from roller_one_tip import Tip
from roller_widget_button import RandomColorButton
from roller_widget_combo import ComboBox
from roller_widget_entry import Entry
from roller_widget_slider import RandomSlider
from roller_widget_radio import RadioRow
from roller_widget_row import Rainbow


def get_component_list():
    return bs.COMPONENT


def get_news_type_list():
    return bs.NEWS_TYPE


def get_shape_list():
    return (
        sh.RECTANGLE,
        sh.CIRCLE,
        sh.ELLIPSE,
        sh.HEXAGON,
        sh.HEXAGON_TRUNCATED,
        sh.OCTAGON,
        sh.OCTAGON_ON_ITS_SIDE,
        sh.SQUARE,
        sh.SQUARE_MITERED,
        ft.TRIANGLE_DOWN_REGULAR,
        ft.TRIANGLE_LEFT_REGULAR,
        ft.TRIANGLE_RIGHT_REGULAR,
        ft.TRIANGLE_UP_REGULAR
    )


def get_spiral_mod_list():
    return bs.SPIRAL_MOD_LIST


def get_vector_list():
    return bs.VECTOR


MAZE = {
    wk.LIMIT: (4, 999),
    wk.PAGE_INCR: 2,
    wk.RANDOM_Q: (4, 50),
    wk.TIPPER: make_text_tip,
    wk.VAL: 10.,
    wk.WIDGET: RandomSlider
}

# Acrylic Sky__________________________________________________________________
ACRYLIC_SKY = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SHIFT, {
        wk.LIMIT: (0, 200),
        wk.RANDOM_Q: (0, 200),
        wk.TIPPER: make_text_tip,
        wk.VAL: 200.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SUPERPIXEL_SIZE, deepcopy(SUPERPIXEL_SIZE)),
    (ok.SEED, deepcopy(SEED)),
    (ok.IDR, deepcopy(IDR)),
    (ok.SHIFT_DIRECTION, {
        wk.TEXT: bs.SHIFT_DIRECTION,
        wk.RANDOM_Q: (0, 1),
        wk.TIPPER: make_radio_tip,
        wk.VAL: 1,
        wk.WIDGET: RadioRow
    }),
    (ok.BRW, deepcopy(BRW))
])

# Back Game____________________________________________________________________
BACK_GAME = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.COLOR_1_MODE, deepcopy(MODE)),
    (ok.COLOR_2_MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.BLUR_BEHIND_COLOR_1, deepcopy(BLUR)),
    (ok.BLUR_BEHIND_COLOR_2, deepcopy(BLUR)),
    (ok.IDR, deepcopy(IDR)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BRW, deepcopy(BRW))
])

BACK_GAME[ok.COLOR_1_MODE][wk.ISSUE] = vo.MATTER
BACK_GAME[ok.COLOR_2_MODE][wk.ISSUE] = vo.MATTER

# Clay Chemistry_______________________________________________________________
CLAY_CHEMISTRY = OrderedDict([
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (ok.IDR, deepcopy(IDR)),
    (ok.BRW, deepcopy(GBR))
])

# Color Fill___________________________________________________________________
COLOR_FILL = OrderedDict([
    (ok.CRITERION, deepcopy(CRITERION)),
    (ok.FILL_MODE, deepcopy(FILL_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.THRESHOLD, deepcopy(THRESHOLD)),
    (ok.START_X, deepcopy(START_X)),
    (ok.START_Y, deepcopy(START_Y)),
    (ok.IDR, deepcopy(IDR)),
    (ok.COLOR_1A, {
        wk.HAS_ALPHA: True,
        wk.TIPPER: make_text_tip,
        wk.VAL: (127, 127, 127, 255),
        wk.WIDGET: RandomColorButton
    }),
    (ok.BRW, deepcopy(BRW))
])

# Color Grid___________________________________________________________________
COLOR_GRID = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.COLOR_1_MODE, deepcopy(MODE)),
    (ok.COLOR_2_MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.BLUR_BEHIND_COLOR_1, deepcopy(BLUR)),
    (ok.BLUR_BEHIND_COLOR_2, deepcopy(BLUR)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.IDR, deepcopy(IDR)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BRW, deepcopy(BRW))
])

COLOR_GRID[ok.COLOR_1_MODE][wk.ISSUE] = vo.MATTER
COLOR_GRID[ok.COLOR_2_MODE][wk.ISSUE] = vo.MATTER
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Core Design__________________________________________________________________
CORE_DESIGN = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.IRR, deepcopy(IRR)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.BRW, deepcopy(GBR))
])

# Crystal Cave_________________________________________________________________
CRYSTAL_CAVE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.IDR, deepcopy(IDR)),
    (ok.BRW, deepcopy(BRW))
])


# Cube Pattern_________________________________________________________________
CUBE_PATTERN = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.HEIGHT, deepcopy(CLIP)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.IDF, deepcopy(IDF)),
    (ok.COLOR_3A, {
        wk.BUTTON_COUNT: 3,
        wk.HAS_ALPHA: True,
        wk.TIPPER: make_rainbow_tip,
        wk.VAL: (
            (24, 104, 174, 255),
            (217, 165, 179, 255),
            (198, 215, 235, 255)
        ),
        wk.WIDGET: Rainbow
    }),
    (ok.BRW, deepcopy(BRW))
])

# Cubism Cover_________________________________________________________________
CUBISM_COVER = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.TILE_SIZE, {
        wk.LIMIT: (2., 256.),
        wk.RANDOM_Q: (7, 45),
        wk.TIPPER: make_text_tip,
        wk.VAL: 20.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SATURATION, deepcopy(HSL)),
    (ok.IDR, deepcopy(IDR)),
    (ok.BRW, deepcopy(BRW))
])

# Dark Fort____________________________________________________________________
DARK_FORT = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.SEED, deepcopy(SEED)),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.BRW, deepcopy(BRW))
])

for i in (ok.ROW, ok.COLUMN):
    DARK_FORT[i][wk.RANDOM_Q] = 4, 16

# Density Gradient__________________________________________________________
DENSITY_GRADIENT = OrderedDict([
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.GRADIENT_MODE, deepcopy(GRADIENT_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.IDR, deepcopy(IDR)),
    (ok.BRW, deepcopy(GBR))
])
DENSITY_GRADIENT[ok.GRADIENT_ANGLE][wk.VAL] = fg.TOP_CENTER_TO_BOTTOM_CENTER
DENSITY_GRADIENT[ok.GRADIENT_MODE][wk.VAL] = "Luma Lighten Only"
DENSITY_GRADIENT[ok.BRW][wk.SUB][ok.GRADIENT][wk.VAL] = "Desert Sunset"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Drop Zone____________________________________________________________________
DROP_ZONE = OrderedDict([
    (ok.NAME, {
        wk.TIPPER: make_text_tip,
        wk.VAL: "Drop Zone",
        wk.WIDGET: Entry
    }),
    (ok.SHAPE, {
        wk.FUNCTION: get_shape_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: sh.RECTANGLE,
        wk.WIDGET: ComboBox
    }),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.STEPS, {
        wk.LIMIT: (2, 100),
        wk.RANDOM_Q: (2, 12),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.STEPS_DROP_ZONE,
        wk.VAL: 12.,
        wk.WIDGET: RandomSlider
    }),
    (ok.IDK, deepcopy(IDK)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BRW, deepcopy(BRW))
])
DROP_ZONE[ok.COLOR_2A][wk.VAL] = (255, 255, 255, 255), (0, 0, 0, 255)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Etch Sketch__________________________________________________________________
ETCH_SKETCH = OrderedDict([
    (ok.SKETCH_TEXTURE, {
        wk.FUNCTION: get_news_type_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: bs.DOT,
        wk.WIDGET: ComboBox
    }),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.CELL_SIZE, {
        wk.LIMIT: (1, 1500),
        wk.PAGE_INCR: 10,
        wk.RANDOM_Q: (1, 100),
        wk.TIPPER: make_text_tip,
        wk.VAL: 9.,
        wk.WIDGET: RandomSlider
    }),
    (ok.IDR, deepcopy(IDR)),
    (ok.BRW, deepcopy(BRW))
])

# Fading Maze__________________________________________________________________
FADING_MAZE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.WIDTH, deepcopy(CLIP)),
    (ok.SEED, deepcopy(SEED)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BRW, deepcopy(BRW))
])

for i in (ok.ROW, ok.COLUMN):
    FADING_MAZE[i][wk.RANDOM_Q] = 4, 199
    FADING_MAZE[i][wk.LIMIT] = 4, 999
    FADING_MAZE[i][wk.VAL] = (70., 7.)[i == ok.COLUMN]

# Floor Sample_________________________________________________________________
FLOOR_SAMPLE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SLICE_COUNT, {
        wk.LIMIT: (2, 60),
        wk.RANDOM_Q: (2, 15),
        wk.TIPPER: make_text_tip,
        wk.VAL: 6.,
        wk.WIDGET: RandomSlider
    }),
    (ok.START_ANGLE, {
        wk.LIMIT: (-360, 360),
        wk.RANDOM_Q: (-360, 360),
        wk.TIPPER: make_text_tip,
        wk.VAL: .0,
        wk.WIDGET: RandomSlider
    }),
    (ok.IDR, deepcopy(IDR)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BRW, deepcopy(BSRR))
])

# Galactic Field_______________________________________________________________
GALACTIC_FIELD = OrderedDict([
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.GRADIENT_MODE, deepcopy(GRADIENT_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (ok.IDR, deepcopy(IDR)),
    (ok.BRW, deepcopy(GBR))
])
GALACTIC_FIELD[ok.GRADIENT_ANGLE][wk.VAL] = fg.TOP_CENTER_TO_BOTTOM_CENTER
GALACTIC_FIELD[ok.GRADIENT_MODE][wk.VAL] = "Subtract"
GALACTIC_FIELD[ok.BRW][wk.SUB][ok.GRADIENT][wk.VAL] = "Galactic Field"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Glass Gaw____________________________________________________________________
GLASS_GAW = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.IDR, deepcopy(IDR)),
    (ok.BRW, deepcopy(BRW))
])

# Gradient Fill________________________________________________________________
GRADIENT_FILL = OrderedDict([
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.START_X, deepcopy(GRADIENT_START_X)),
    (ok.START_Y, deepcopy(GRADIENT_START_Y)),
    (ok.END_X, deepcopy(GRADIENT_END_X)),
    (ok.END_Y, deepcopy(GRADIENT_END_Y)),
    (ok.IRR, deepcopy(IRR)),
    (ok.BRW, deepcopy(GBR))
])

# Historic Trip________________________________________________________________
HISTORIC_TRIP = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ITERATIONS, {
        wk.LIMIT: (0, 100),
        wk.PAGE_INCR: 2,
        wk.RANDOM_Q: (0, 20),
        wk.TIPPER: make_text_tip,
        wk.VAL: 12.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SPREAD, {
        wk.LIMIT: (0, 512),
        wk.RANDOM_Q: (0, 512),
        wk.TIPPER: make_text_tip,
        wk.VAL: 512.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SUPERPIXEL_SIZE, deepcopy(SUPERPIXEL_SIZE)),
    (ok.SATURATION, deepcopy(HSL)),
    (ok.IDR, deepcopy(IDR)),
    (ok.BRW, deepcopy(BRW))
])

# Image Gradient_______________________________________________________________
IMAGE_GRADIENT = OrderedDict([
    (ok.NAME, {
        wk.TIPPER: make_text_tip,
        wk.VAL: "Sampled Gradient",
        wk.WIDGET: Entry
    }),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.SAMPLE_VECTOR, {
        wk.FUNCTION: get_vector_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: bs.VERTICAL,
        wk.WIDGET: ComboBox
    }),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SAMPLE_RADIUS, {
        wk.LIMIT: (1., 100.),
        wk.PRECISION: 1,
        wk.RANDOM_Q: (10., 50.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 15.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SAMPLE_COUNT, {
        wk.LIMIT: (2, 50),
        wk.RANDOM_Q: (2, 12),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.SAMPLE_COUNT,
        wk.VAL: 5.,
        wk.WIDGET: RandomSlider
    }),
    (ok.DIAGONAL_ROTATION, {
        wk.LIMIT: (-359., 359.),
        wk.PRECISION: 1,
        wk.RANDOM_Q: (-359., 359.),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.DIAGONAL_ROTATION,
        wk.VAL: 45.,
        wk.WIDGET: RandomSlider
    }),
    (ok.START_X, deepcopy(START_X)),
    (ok.START_Y, deepcopy(START_Y)),
    (ok.RKR, RKR),
    (ok.IDR, IDR),
    (ok.PREVIEW_MODE, {
        wk.TEXT: ("Show Gradient", "Show Samples."),
        wk.TIPPER: make_radio_tip,
        wk.VAL: bs.SHOW_GRADIENT,
        wk.WIDGET: RadioRow
    }),
    (ok.BRW, deepcopy(BRW))
])
IMAGE_GRADIENT[ok.START_X][wk.VAL] = IMAGE_GRADIENT[ok.START_Y][wk.VAL] = 0, .5
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Line Stone___________________________________________________________________
LINE_STONE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.IDR, IDR),
    (ok.BRW, deepcopy(BRW))
])

# Lost Maze____________________________________________________________________
LOST_MAZE = OrderedDict([
    (ok.GRADIENT_ANGLE, GRADIENT_ANGLE),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(MAZE)),
    (ok.COLUMN, deepcopy(MAZE)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.SEED, deepcopy(SEED)),
    (ok.IRR, deepcopy(IRR)),
    (ok.BRW, deepcopy(GBR))
])

# Maze Blend___________________________________________________________________
MAZE_BLEND = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(MAZE)),
    (ok.COLUMN, deepcopy(MAZE)),
    (ok.SEED, deepcopy(SEED)),
    (ok.IDR, IDR),
    (ok.BRW, deepcopy(BRW))
])
MAZE_BLEND[ok.ROW][wk.VAL] = 4.
MAZE_BLEND[ok.COLUMN][wk.VAL] = 100.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Mystery Grate________________________________________________________________
MYSTERY_GRATE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.COLUMN_1, deepcopy(R_C)),
    (ok.COLUMN_2, deepcopy(R_C)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.IRR, deepcopy(IRR)),
    (ok.BRW, deepcopy(GBR))
])
MYSTERY_GRATE[ok.COLUMN_1][wk.VAL] = 16.
MYSTERY_GRATE[ok.COLUMN_2][wk.VAL] = 160.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Nano Suit____________________________________________________________________
NANO_SUIT = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.IDR, IDR),
    (ok.BRW, deepcopy(BRW))
])

# Noise Rift___________________________________________________________________
NOISE_RIFT = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.NOISE_AMOUNT, deepcopy(NOISE_AMOUNT)),
    (ok.BLUR, deepcopy(BLUR)),
    (ok.SEED, deepcopy(SEED)),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.BRW, deepcopy(BRW))
])
NOISE_RIFT[ok.NOISE_AMOUNT][wk.VAL] = 1.
NOISE_RIFT[ok.BLUR][wk.VAL] = 20.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Paper Waste__________________________________________________________________
PAPER_WASTE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BLOCK_W, deepcopy(BLOCK_W)),
    (ok.BLOCK_H, deepcopy(BLOCK_H)),
    (ok.IDR, IDR),
    (ok.BRW, deepcopy(BRW))
])

# Pattern Fill_________________________________________________________________
PATTERN_FILL = OrderedDict([
    (ok.CRITERION, deepcopy(CRITERION)),
    (ok.FILL_MODE, deepcopy(FILL_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.FILL_OPACITY, deepcopy(OPACITY)),
    (ok.THRESHOLD, deepcopy(THRESHOLD)),
    (ok.START_X, deepcopy(START_X)),
    (ok.START_Y, deepcopy(START_Y)),
    (ok.IDR, IDR),
    (ok.BRW, deepcopy(PBR))
])

# Rainbow Valley_______________________________________________________________
RAINBOW_VALLEY = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.POWER, {
        wk.LIMIT: (0, 180),
        wk.RANDOM_Q: (0, 180),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.POWER,
        wk.VAL: 30.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SEED, deepcopy(SEED)),
    (ok.IDT, IDT),
    (ok.BRW, deepcopy(BRW))
])

# Rectangle Pattern____________________________________________________________
RECT_PATTERN = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.WIDTH, deepcopy(CLIP)),
    (ok.HEIGHT, deepcopy(CLIP)),
    (ok.COLOR_COUNT, {
        wk.LIMIT: (2, 6),
        wk.PAGE_INCR: 1,
        wk.RANDOM_Q: (2, 6),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.COLOR_COUNT,
        wk.VAL: 2.,
        wk.WIDGET: RandomSlider
    }),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.SEED, deepcopy(SEED)),
    (ok.IFR, deepcopy(IFR)),
    (ok.IDR, IDR),
    (ok.COLOR_GRID_TYPE, {
        wk.TEXT: bs.COLOR_GRID_TYPE,
        wk.RANDOM_Q: (0, 1),
        wk.TIPPER: make_radio_tip,
        wk.VAL: 0,
        wk.WIDGET: RadioRow
    }),
    (ok.COLOR_6A, {
        wk.BUTTON_COUNT: 6,
        wk.HAS_ALPHA: True,
        wk.TIPPER: make_rainbow_count_tip,
        wk.VAL: (
            (51, 51, 51, 255),
            (204, 204, 204, 255),
            (0, 0, 0, 255),
            (255, 255, 255, 255),
            (102, 102, 102, 255),
            (153, 153, 153, 255)
        ),
        wk.WIDGET: Rainbow
    }),
    (ok.BRW, deepcopy(BRW))
])

# Rocky Landing________________________________________________________________
ROCKY_LANDING = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BLEND, {
        wk.LIMIT: (1, 60),
        wk.PAGE_INCR: 2,
        wk.RANDOM_Q: (5, 20),
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.BLEND,
        wk.VAL: 12.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SEED, deepcopy(SEED)),
    (ok.IDR, IDR),
    (ok.BRW, deepcopy(BRW))
])

# Soft Touch___________________________________________________________________
SOFT_TOUCH = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.INVERT, deepcopy(INVERT)),
    (ok.BRW, deepcopy(BRW))
])

# Specimen Speckle_____________________________________________________________
SPECIMEN_SPECKLE = OrderedDict([
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.IRR, deepcopy(IRR)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.P3R, deepcopy(P3R)),
    (ok.BRW, deepcopy(GBR))
])
SPECIMEN_SPECKLE[ok.COLOR_1][wk.VAL] = 176, 82, 0
a = SPECIMEN_SPECKLE[ok.P3R][wk.SUB]
a[ok.PATTERN_1][wk.VAL] = "Crack"
a[ok.PATTERN_2][wk.VAL] = "Leopard"
a[ok.PATTERN_3][wk.VAL] = "Paper"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Spiral Channel_______________________________________________________________
SPIRAL_CHANNEL = OrderedDict([
    (ok.SPIRAL_MOD, {
        wk.FUNCTION: get_spiral_mod_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: "None",
        wk.WIDGET: ComboBox
    }),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SPIRAL_DISTANCE, {
        wk.LIMIT: (.001, .5),
        wk.RANDOM_Q: (.001, .5),
        wk.PRECISION: 3,
        wk.TIPPER: make_text_tip,
        wk.TOOLTIP: Tip.SPIRAL_DISTANCE,
        wk.VAL: .1,
        wk.WIDGET: RandomSlider
    }),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.IDR, deepcopy(IDR)),
    (ok.GRADIENT_DIRECTION, {
        wk.TEXT: bs.DIRECTION,
        wk.TIPPER: make_text_tip,
        wk.VAL: bs.CLOCKWISE,
        wk.WIDGET: RadioRow
    }),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.BRW, deepcopy(BRW))
])
SPIRAL_CHANNEL[ok.COLOR_1][wk.VAL] = 75, 75, 75
SPIRAL_CHANNEL[ok.ROW][wk.VAL] = 1.
SPIRAL_CHANNEL[ok.COLUMN][wk.VAL] = 1.
SPIRAL_CHANNEL[ok.SPIRAL_MOD][wk.VAL] = bs.HORIZONTAL_FLIP

d = {wk.RANDOM_Q: (1, 10), wk.PAGE_INCR: 2, wk.LIMIT: (1, 100)}

SPIRAL_CHANNEL[ok.ROW].update(d)
SPIRAL_CHANNEL[ok.COLUMN].update(d)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Square Cloud_________________________________________________________________
SQUARE_CLOUD = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.IDR, deepcopy(IDR)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.BRW, deepcopy(BRW))
])

# Stone age____________________________________________________________________
STONE_AGE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.PATTERN_SIZE, {
        # Is limited by GIMP's clipboard to
        # pattern function where the maximum side
        # dimension for the clipboard is 1024.
        wk.LIMIT: (24, 256),
        wk.RANDOM_Q: (120, 256),
        wk.TIPPER: make_text_tip,
        wk.VAL: 120.,
        wk.WIDGET: RandomSlider
    }),
    (ok.IFRW, deepcopy(IFRW)),
    (ok.BRW, deepcopy(BRW))
])

# Trailing Vine________________________________________________________________
TRAILING_VINE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.LAYER_COUNT, {
        wk.LIMIT: (3, 20),
        wk.RANDOM_Q: (4, 8),
        wk.TIPPER: make_text_tip,
        wk.VAL: 7.,
        wk.WIDGET: RandomSlider
    }),
    (ok.WAVE_PER_LAYER, {
        wk.LIMIT: (1, 18),
        wk.RANDOM_Q: (1, 18),
        wk.TIPPER: make_text_tip,
        wk.VAL: 5.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SEED, deepcopy(SEED)),
    (ok.IDR, deepcopy(IDR)),
    (ok.BRW, deepcopy(BRW))
])

# Roof Top_____________________________________________________________________
ROOF_TOP = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.SEED, deepcopy(SEED)),
    (ok.COLOR_3, {
        wk.BUTTON_COUNT: 3,
        wk.TIPPER: make_rainbow_tip,
        wk.VAL: (
            (160, 160, 160),
            (110, 110, 110),
            (70, 70, 70)
        ),
        wk.WIDGET: Rainbow
    }),
    (ok.BRW, deepcopy(BRW))
])

for i in (ok.ROW, ok.COLUMN):
    ROOF_TOP[i][wk.RANDOM_Q] = 4, 12

for i in (
    ACRYLIC_SKY,
    BACK_GAME,
    CLAY_CHEMISTRY,
    COLOR_FILL,
    COLOR_GRID,
    CORE_DESIGN,
    CRYSTAL_CAVE,
    CUBE_PATTERN,
    CUBISM_COVER,
    DARK_FORT,
    DENSITY_GRADIENT,
    DROP_ZONE,
    ETCH_SKETCH,
    FADING_MAZE,
    FLOOR_SAMPLE,
    GALACTIC_FIELD,
    GLASS_GAW,
    GRADIENT_FILL,
    HISTORIC_TRIP,
    IMAGE_GRADIENT,
    LINE_STONE,
    LOST_MAZE,
    MAZE_BLEND,
    MYSTERY_GRATE,
    NANO_SUIT,
    NOISE_RIFT,
    PAPER_WASTE,
    PATTERN_FILL,
    RAINBOW_VALLEY,
    RECT_PATTERN,
    ROCKY_LANDING,
    ROOF_TOP,
    SOFT_TOUCH,
    SPECIMEN_SPECKLE,
    SPIRAL_CHANNEL,
    SQUARE_CLOUD,
    STONE_AGE,
    TRAILING_VINE
):
    set_issue(
        i, None, vo.MATTER, (ok.OPACITY, ok.MODE, ok.BUMP, ok.SHADOW)
    )
