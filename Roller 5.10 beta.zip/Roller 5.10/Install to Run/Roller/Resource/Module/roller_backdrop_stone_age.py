#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clear_inverse_selection,
    clone_layer,
    make_layer_group,
    merge_layer,
    merge_layer_group,
    remove_z,
    select_item
)
from roller_maya_style import Style, make_background
from roller_one_gegl import spread
from roller_view_hub import (
    clipboard_fill,
    color_selection,
    do_curves,
    get_average_color,
    make_cube_pattern,
    set_fill_context_default
)
from roller_view_real import add_sub_base_group, add_wip_below, finish_style
import gimpfu as fu

pdb = fu.pdb

# Made of x, y pairs that range from .0 to 1..
CURVES = (
    # one
    (
        .0, .0,
        .4, .1,
        .8, .8,
        1., 1.
    ),

    # two
    (
        .0, .0,
        .2, .0,
        .5, 1.,
        .75, 1.,
        1., .0
    ),

    # three
    (
        .0, .0,
        .25, 1.,
        .5, 1.,
        .8, .0,
        1., .0
    ),

    # four
    (
        .0, 1.,
        .25, 1.,
        .55, .0,
        1., .0
    )
)


def draw_layer(v, j, z, d, layer_num):
    """
    There are four layers, each having a different pattern and
    value range. Each pattern is a cube, but differs by scale.
    The value range is determined by the CURVES settings.

    j: GIMP image
        Is render.

    z: layer
        Backing copy

    d: dict
        Stone Age Preset

    layer_num: int
        distinguish range and type
    """
    # receiving layer, 'z1'
    z1 = clone_layer(z, n="Curves")

    # layer with the average color value, 'z2'
    z2 = clone_layer(z, n="Color")

    do_curves(z1, CURVES[layer_num])

    # Erase the black.
    pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

    # layer to receive symbol and average color, 'z'
    z = clone_layer(z, n="{} of 4".format(str(layer_num + 1)))
    z.mode = fu.LAYER_MODE_MULTIPLY

    make_cube_pattern(
        d[ok.PATTERN_SIZE] * (layer_num + 1),
        ((255, 255, 255), (187, 187, 187), (127, 127, 127)),
        d[ok.IFRW][ok.FLIP_V]
    )
    clipboard_fill(z)
    select_item(z1)
    clear_inverse_selection(z)
    select_item(z1)
    clear_inverse_selection(z2)

    # Get the average color to fill the layer.
    avg_color = get_average_color(z2)

    # Fill existing pixels with the average
    # color using their material selection.
    color_z = add_wip_below(v, z)

    select_item(z)
    color_selection(color_z, avg_color)
    merge_layer(z)
    remove_z(z1)
    remove_z(z2)


def make_style(v, maya):
    """
    Make a style layer.

    v: View
    maya: StoneAge
    Return: layer or None
        with the style material
    """
    # Is dependent.
    if maya.go:
        j = v.j
        d = maya.value_d
        parent = add_sub_base_group(v, maya)
        group = make_layer_group(j, "WIP", parent=parent)
        z = make_background(v, group)

        set_fill_context_default()

        for i in range(4):
            draw_layer(v, j, z, d, i)

        pdb.gimp_selection_none(j)
        blur_selection(z, 500.)

        z = merge_layer_group(group)
        z = clone_layer(z)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        do_curves(z, (.0, .0, .0431, .3411, 1., 1.))

        arg = (15, 10) if j.width > j.height else (10, 15)

        spread(z, *arg)

        z = merge_layer_group(parent)

        if d[ok.IFRW][ok.INVERT]:
            # no linear, '0'
            pdb.gimp_drawable_invert(z, 0)
        return finish_style(z, "Stone Age")


class StoneAge(Style):
    """Create Backdrop Style output."""

    def __init__(self, any_group, super_maya, k_path):
        self.is_seeded = self.is_dependent = True
        k_path = [
            k_path,
            k_path + (ok.BRW,),
            k_path + (ok.BRW, ok.BACKING),
            k_path + (ok.BRW, ok.BACKING, ok.IGA),
            k_path + (ok.BRW, ok.BACKING, ok.IGA, ok.IMAGE_CHOICE),
            k_path + (ok.IFRW,)
        ]
        Style.__init__(self, any_group, super_maya, k_path, make_style)
