#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import ready_canvas_rect, ready_shape
from roller_fu import (
    blur_selection,
    select_item,
    select_shape,
    verify_layer,
)
from roller_view_hub import set_draw_line_brush
from roller_view_real import add_base_layer
import gimpfu as fu

pdb = fu.pdb
gimp = fu.gimp


def add_line_layer(v, maya):
    """
    Add a layer named after "Line" to the base of the Maya's group.

    v: View
    maya: Maya
    Return: layer
        newly added
    """
    return add_base_layer(v, maya.group, "Line")


def do(v, maya, make):
    """
    Create Line for a navigation branch.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    d = maya.value_d

    if not v.x:
        # Preserve.
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = {
            ny.CANVAS: fy.CANVAS_LINE_COLOR,
            ny.CELL: fy.CELL_LINE_COLOR,
            ny.FACE: fy.FACE_LINE_COLOR
        }[maya.any_group.render_key[-2]]

    z = make(v, maya)

    if not v.x:
        # Restore.
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_face(v, maya):
    """
    Draw Face/Per Line.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_face)


def do_canvas(v, maya):
    """
    Draw Canvas branch Line.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_canvas)


def do_blur(z, d):
    """
    Blur a Line layer.

    z: layer
        Receive blur.

    d: dict
        Line Preset
    """
    a = d[ok.BLUR]
    if a:
        select_item(z)
        blur_selection(z, a)


def do_cell(v, maya):
    """
    Draw Line for Cell/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell)


def do_main_cell(v, maya):
    """
    Draw Cell/Per Line.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main)


def do_main_face(v, maya):
    """
    Draw Face/Per Line.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_face)


def make_canvas(v, maya):
    """
    Draw Canvas Line material.

    v: View
    maya: Maya
    Return: layer or None
        with Line material
    """
    j = v.j
    d = maya.value_d
    z = add_line_layer(v, maya)

    ready_canvas_rect(v, maya)

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)
        do_blur(z, d)
    return verify_layer(z)


def make_cell(v, maya):
    """
    Make Line for a Per cell.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    j = v.j
    d = maya.value_d
    z = add_line_layer(v, maya)

    ready_shape(v, maya)

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)
        do_blur(z, d)
    return verify_layer(z)


def make_cell_face(v, maya):
    """
    Make Line for Face/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    j = v.j
    d = maya.value_d
    z = add_line_layer(v, maya)

    select_shape(j, maya.model.get_facing_shape(maya.k))

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)
        do_blur(z, d)
    return verify_layer(z)


def make_main(v, maya):
    """
    Create Line for the Cell branch main option settings.

    v: View
    maya: Maya
    Return: layer or None
        Line output
    """
    j = v.j
    d = maya.value_d
    z = add_line_layer(v, maya)

    prep_line(d)

    # cell key, 'k'
    for k in maya.main_q:
        maya.k = k
        ready_shape(v, maya)
        if not pdb.gimp_selection_is_empty(j):
            pdb.gimp_drawable_edit_stroke_selection(z)

    do_blur(z, d)
    return verify_layer(z)


def make_main_face(v, maya):
    """
    Make Line for Face/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    j = v.j
    d = maya.value_d
    z = add_line_layer(v, maya)

    prep_line(d)

    for k in maya.main_q:
        select_shape(j, maya.model.get_facing_shape(k))
        if not pdb.gimp_selection_is_empty(j):
            pdb.gimp_drawable_edit_stroke_selection(z)

    do_blur(z, d)
    return verify_layer(z)


def prep_line(d):
    """
    Prepare to draw line.

    d: dict
        Line Preset
    """
    set_draw_line_brush()
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_context_set_brush_angle(.0)
    pdb.gimp_context_set_brush_hardness(d[ok.HARDNESS])
    pdb.gimp_context_set_brush_size(d[ok.LINE_W])
    pdb.gimp_context_set_foreground(d[ok.COLOR_1])
    pdb.gimp_context_set_opacity(100.)
