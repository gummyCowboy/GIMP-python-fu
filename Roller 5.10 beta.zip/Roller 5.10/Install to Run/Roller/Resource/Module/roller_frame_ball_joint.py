#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import do_selection_material
from roller_fu import (
    clone_layer,
    get_layer_position,
    load_selection,
    make_layer_group,
    merge_layer_group,
    select_item,
    set_saturation,
    verify_layer
)
from roller_maya import check_matter, check_mix_basic, make_group_frame
from roller_maya_build import Build
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_view_real import LIGHT
from roller_view_hub import do_curves, prep_brush, set_gimp_brush
import gimpfu as fu

pdb = fu.pdb
MAIN = 'main'


def do_sel(v, maya, z):
    """
    Make a frame from a selection.

    v: View
    maya: Maya
    z: layer
        to receive the frame

    Return: layer
        with the frame material
    """
    j = v.j
    super_ = maya.cast

    # Stroke one selection at a time for the best chance of success.
    if super_.vote_type == MAIN:
        for r, c in super_.main_q:
            sel = maya.model.get_image_sel((r, c))
            load_selection(j, sel)
            if not pdb.gimp_selection_is_empty(j):
                pdb.gimp_drawable_edit_stroke_selection(z)
    else:
        select_item(super_.matter)
        if not pdb.gimp_selection_is_empty(j):
            pdb.gimp_drawable_edit_stroke_selection(z)
    return verify_layer(z)


def do_matter(v, maya):
    """
    Add a frame to the image material on a layer.

    v: View
    maya: Maya
    Return: layer
        with the frame material
    """
    init_brush(maya.value_d)
    return do_selection_material(v, maya, do_sel, embellish, "Ball Joint")


def embellish(v, maya, z):
    """
    Add color and depth to frame material.

    v: View
    maya: Maya
        not used

    z: layer
        Has frame.

    Return: layer
        with the frame material
    """
    n = z.name
    j = v.j
    group = make_layer_group(
        j, n, parent=z.parent, offset=get_layer_position(z), z=z
    )
    z1 = clone_layer(z)
    z1.mode = fu.LAYER_MODE_OVERLAY
    z1.opacity = 25.
    z1 = clone_layer(z1)
    z1.mode = fu.LAYER_MODE_BURN
    z1.opacity = 25.

    pdb.plug_in_emboss(
        j, z,
        v.glow_ball.azimuth,
        v.glow_ball.elevation,
        3,                              # depth
        1                               # emboss
    )
    do_curves(z, (.0, .2, 8., .6, 1., 1.))

    z1 = clone_layer(z)
    z2 = clone_layer(z1)
    z3 = clone_layer(z2)
    z1.mode = fu.LAYER_MODE_VIVID_LIGHT
    z1.opacity = 80.
    z2.mode = fu.LAYER_MODE_SCREEN
    z3.mode = fu.LAYER_MODE_ADDITION
    z = merge_layer_group(group)

    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_RED,
        6,                              # coordinate count
        (.0, .0, .5, .8, 1., 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_GREEN,
        6,                              # coordinate count
        (.0, .0, .5, .3, 1., 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_BLUE,
        8,                              # coordinate count
        (.0, .0, .2, .06, .7, .5, 1., 1.)
    )
    set_saturation(z, -33.)

    z.name = n
    return z


def init_brush(d):
    """Initialize the brush before stroking the frame."""
    prep_brush()
    set_gimp_brush("dots")
    pdb.gimp_context_set_brush_size(d[ok.BRUSH_SIZE])


class BallJoint(Build):
    """Is a metallic frame made with of an overlapping circle brush."""
    INFLUENCE = ok.METAL
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_frame, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.

        do_matter: function
            Call to make the frame layer.
        """
        Build.__init__(self, any_group, super_maya, k_path, do_matter)
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cast, self)
        )
        if self.INFLUENCE:
            self.sub_maya[LIGHT] = Light(any_group, self, self.INFLUENCE)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], is_change, self.is_matter
        )

        if self.INFLUENCE:
            self.sub_maya[LIGHT].do(v, self.is_matter)

        self.reset_issue()
        return m
