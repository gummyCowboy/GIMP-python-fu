#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_key import (
    BackdropStyle as by,
    Frame as ek,
    Group as gk,
    ModelList as ml,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_def_backdrop_style import (
    ACRYLIC_SKY,
    BACK_GAME,
    CLAY_CHEMISTRY,
    COLOR_FILL,
    COLOR_GRID,
    CORE_DESIGN,
    CRYSTAL_CAVE,
    CUBE_PATTERN,
    CUBISM_COVER,
    DARK_FORT,
    DENSITY_GRADIENT,
    DROP_ZONE,
    ETCH_SKETCH,
    FADING_MAZE,
    FLOOR_SAMPLE,
    GALACTIC_FIELD,
    GLASS_GAW,
    GRADIENT_FILL,
    HISTORIC_TRIP,
    IMAGE_GRADIENT,
    LINE_STONE,
    LOST_MAZE,
    MAZE_BLEND,
    MYSTERY_GRATE,
    NANO_SUIT,
    NOISE_RIFT,
    PAPER_WASTE,
    PATTERN_FILL,
    RAINBOW_VALLEY,
    RECT_PATTERN,
    ROCKY_LANDING,
    SOFT_TOUCH,
    SPECIMEN_SPECKLE,
    SPIRAL_CHANNEL,
    SQUARE_CLOUD,
    STONE_AGE,
    TRAILING_VINE,
    ROOF_TOP
)
from roller_def_backdrop import BACKDROP
from roller_def_cell_type import (
    TYPE_BOX, TYPE_CELL, TYPE_PYRAMID, TYPE_SIDEWALK, TYPE_STACK, TYPE_TABLE
)
from roller_def_frame import (
    BALL_JOINT,
    BRUSH_PUNCH,
    CAMO_PLANET,
    CERAMIC_CHIP,
    CIRCLE_PUNCH,
    CLEAR_FRAME,
    COLOR_BOARD,
    COLOR_PIPE,
    CORNER_TAPE,
    CRUMBLE_SHELL,
    BOXY_BEVEL,
    FEATHER_STEP,
    FRAME_OVER,
    GRADIENT_LEVEL,
    HOT_GLUE,
    JAGGED_EDGE,
    LINE_FASHION,
    LINK_MIRROR,
    NAIL_POLISH,
    PAINT_RUSH,
    RAD_WAVE,
    RAISED_MAZE,
    SHAPE_BURST,
    SQUARE_CUT,
    SQUARE_PUNCH,
    STAINED_GLASS,
    STICKY_WOBBLE,
    STRETCH_TRAY,
    SHADOWY,
    WIRE_FENCE
)
from roller_def_global import GLOBAL
from roller_def_gradient_light import GRADIENT_LIGHT
from roller_def_property import PLANNER, PROPERTY
from roller_def_rectangle import RECTANGLE
from roller_def_share import (
    AVERAGE_COLOR,
    BACKING,
    BLUR_BEHIND,
    BORDER_LINE,
    BRUSH_DIALOG,
    BUMP,
    FILLER_CC,
    FILLER_CP,
    FILLER_LF,
    FILLER_LM,
    FILLER_RM,
    FILLER_RW,
    FILLER_SC,
    FILLER_SP,
    FILLER_SG,
    FILLER_ST,
    FILLER_WF,
    IMAGE_CHOICE,
    INFLUENCE,
    INNER_SHADOW,
    MARGIN,
    MASK,
    NOISE_D,
    OVERLAY_CF,
    OVERLAY_CP,
    OVERLAY_BB,
    OVERLAY_FO,
    OVERLAY_NP,
    RESIZE,
    SHADOW_1,
    SHADOW_2,
    STRIPE,
    SWITCH_GROUP,
    SHADOW,
    SHADOW_BASIC,
    STENCIL,
    TAPE,
    WRAP,
    WRAP_CB,
    WRAP_CF,
    WRAP_CP,
    WRAP_CS,
    WRAP_BB,
    WRAP_NP
)
from roller_def_model import (
    BORDER,
    CAPTION,
    FRINGE,
    IMAGE,
    LINE,
    PLAQUE,
    SHIFT
)
from roller_one_extract import scour
from roller_widget_entry import Entry
from roller_widget_model_list import ModelList

BACKDROP_DEF = {
    by.AVERAGE_COLOR: AVERAGE_COLOR,
    by.ACRYLIC_SKY: ACRYLIC_SKY,
    by.BACK_GAME: BACK_GAME,
    by.CLAY_CHEMISTRY: CLAY_CHEMISTRY,
    by.COLOR_FILL: COLOR_FILL,
    by.COLOR_GRID: COLOR_GRID,
    by.CORE_DESIGN: CORE_DESIGN,
    by.CRYSTAL_CAVE: CRYSTAL_CAVE,
    by.CUBE_PATTERN: CUBE_PATTERN,
    by.CUBISM_COVER: CUBISM_COVER,
    by.DARK_FORT: DARK_FORT,
    by.DROP_ZONE: DROP_ZONE,
    by.DENSITY_GRADIENT: DENSITY_GRADIENT,
    by.ETCH_SKETCH: ETCH_SKETCH,
    by.FADING_MAZE: FADING_MAZE,
    by.FLOOR_SAMPLE: FLOOR_SAMPLE,
    by.GALACTIC_FIELD: GALACTIC_FIELD,
    by.GLASS_GAW: GLASS_GAW,
    by.GRADIENT_FILL: GRADIENT_FILL,
    by.HISTORIC_TRIP: HISTORIC_TRIP,
    by.IMAGE_GRADIENT: IMAGE_GRADIENT,
    by.LINE_STONE: LINE_STONE,
    by.LOST_MAZE: LOST_MAZE,
    by.MAZE_BLEND: MAZE_BLEND,
    by.MYSTERY_GRATE: MYSTERY_GRATE,
    by.NANO_SUIT: NANO_SUIT,
    by.NOISE_RIFT: NOISE_RIFT,
    by.PAPER_WASTE: PAPER_WASTE,
    by.PATTERN_FILL: PATTERN_FILL,
    by.RAINBOW_VALLEY: RAINBOW_VALLEY,
    by.RECT_PATTERN: RECT_PATTERN,
    by.ROCKY_LANDING: ROCKY_LANDING,
    by.SOFT_TOUCH: SOFT_TOUCH,
    by.SPECIMEN_SPECKLE: SPECIMEN_SPECKLE,
    by.SPIRAL_CHANNEL: SPIRAL_CHANNEL,
    by.SQUARE_CLOUD: SQUARE_CLOUD,
    by.STONE_AGE: STONE_AGE,
    by.TRAILING_VINE: TRAILING_VINE,
    by.ROOF_TOP: ROOF_TOP
}
DEFINE_MODEL = {}
FRAME_DEF = {
    ek.BALL_JOINT: BALL_JOINT,
    ek.BORDER_LINE: BORDER_LINE,
    ek.BRUSH_PUNCH: BRUSH_PUNCH,
    ek.CAMO_PLANET: CAMO_PLANET,
    ek.CERAMIC_CHIP: CERAMIC_CHIP,
    ek.CIRCLE_PUNCH: CIRCLE_PUNCH,
    ek.CLEAR_FRAME: CLEAR_FRAME,
    ek.COLOR_BOARD: COLOR_BOARD,
    ek.COLOR_PIPE: COLOR_PIPE,
    ek.CORNER_TAPE: CORNER_TAPE,
    ek.CRUMBLE_SHELL: CRUMBLE_SHELL,
    ek.BOXY_BEVEL: BOXY_BEVEL,
    ek.FEATHER_STEP: FEATHER_STEP,
    ek.FRAME_OVER: FRAME_OVER,
    ek.GRADIENT_LEVEL: GRADIENT_LEVEL,
    ek.HOT_GLUE: HOT_GLUE,
    ek.JAGGED_EDGE: JAGGED_EDGE,
    ek.LINE_FASHION: LINE_FASHION,
    ek.LINK_MIRROR: LINK_MIRROR,
    ek.NAIL_POLISH: NAIL_POLISH,
    ek.PAINT_RUSH: PAINT_RUSH,
    ek.RAD_WAVE: RAD_WAVE,
    ek.RAISED_MAZE: RAISED_MAZE,
    ek.SHAPE_BURST: SHAPE_BURST,
    ek.SQUARE_CUT: SQUARE_CUT,
    ek.SQUARE_PUNCH: SQUARE_PUNCH,
    ek.STAINED_GLASS: STAINED_GLASS,
    ek.STICKY_WOBBLE: STICKY_WOBBLE,
    ek.STRETCH_TRAY: STRETCH_TRAY,
    ek.SHADOWY: SHADOWY,
    ek.WIRE_FENCE: WIRE_FENCE
}

# Model________________________________________________________________________
MODEL_LIST = {
    wk.SUB: {
        ml.MODEL_DEF: {wk.VAL: []},
        ml.SHELVED: {wk.VAL: {}},
        ml.ACTIVE: {wk.VAL: {}},
    },
    wk.WIDGET: ModelList
}
MODEL = {ok.MODEL_LIST: MODEL_LIST}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

MODEL_DEF = {
    gk.BORDER: BORDER,
    gk.CAPTION: CAPTION,
    gk.FRINGE: FRINGE,
    gk.IMAGE: IMAGE,
    gk.LINE: LINE,
    gk.PLAQUE: PLAQUE,
    gk.PROPERTY: PROPERTY,
    gk.RECTANGLE: RECTANGLE,
    gk.SHIFT: SHIFT,
    gk.TYPE_BOX: TYPE_BOX,
    gk.TYPE_CELL: TYPE_CELL,
    gk.TYPE_PYRAMID: TYPE_PYRAMID,
    gk.TYPE_SIDEWALK: TYPE_SIDEWALK,
    gk.TYPE_STACK: TYPE_STACK,
    gk.TYPE_TABLE: TYPE_TABLE,
    ok.PLANNER: PLANNER,
    ok.SHADOW: SHADOW
}
MODEL_NAME = {
    ok.RENAME_MODEL: {
        wk.CHANGELESS: True,
        wk.VAL: "",
        wk.WIDGET: Entry
    }
}

# These group keys have a 'wk.SUB' item and
# a dialog option in their definition.
SUB_GROUP_DEF = {
    gk.SHADOW_PRESET: SHADOW,
    ok.BACKING: BACKING,
    ok.BLUR_BEHIND: BLUR_BEHIND,
    ok.BRUSH_D: BRUSH_DIALOG,
    ok.BUMP: BUMP,
    ok.FILLER_CC: FILLER_CC,
    ok.FILLER_CP: FILLER_CP,
    ok.FILLER_LF: FILLER_LF,
    ok.FILLER_LM: FILLER_LM,
    ok.FILLER_RM: FILLER_RM,
    ok.FILLER_RW: FILLER_RW,
    ok.FILLER_SC: FILLER_SC,
    ok.FILLER_SG: FILLER_SG,
    ok.FILLER_ST: FILLER_ST,
    ok.FILLER_WF: FILLER_WF,
    ok.FILLER_SP: FILLER_SP,
    ok.IMAGE_CHOICE: IMAGE_CHOICE,
    ok.INFLUENCE: INFLUENCE,
    ok.MARGIN: MARGIN,
    ok.MASK: MASK,
    ok.NOISE_D: NOISE_D,
    ok.OVERLAY_CF: OVERLAY_CF,
    ok.OVERLAY_CP: OVERLAY_CP,
    ok.OVERLAY_CU: OVERLAY_BB,
    ok.OVERLAY_FO: OVERLAY_FO,
    ok.OVERLAY_NP: OVERLAY_NP,
    ok.RESIZE: RESIZE,
    ok.SHADOW_BASIC: SHADOW_BASIC,
    ok.STENCIL: STENCIL,
    ok.STRIPE: STRIPE,
    ok.TAPE: TAPE,
    ok.WRAP: WRAP,
    ok.WRAP_CB: WRAP_CB,
    ok.WRAP_CF: WRAP_CF,
    ok.WRAP_CP: WRAP_CP,
    ok.WRAP_CS: WRAP_CS,
    ok.WRAP_CU: WRAP_BB,
    ok.WRAP_NP: WRAP_NP
}

SHADOW_DEF = {
    ok.SWITCH: SWITCH_GROUP,
    gk.SHADOW_1: SHADOW_1,
    gk.SHADOW_2: SHADOW_2,
    gk.INNER_SHADOW: INNER_SHADOW,
    sk.INNER_SHADOW: INNER_SHADOW,
    sk.SHADOW_1: SHADOW_1,
    sk.SHADOW_2: SHADOW_2
}
GROUP_DEF = {
    gk.BACKDROP: BACKDROP,
    gk.DEFINE_MODEL: DEFINE_MODEL,
    gk.GRADIENT_LIGHT: GRADIENT_LIGHT,
    gk.GLOBAL: GLOBAL,
    gk.MODEL: MODEL,
    gk.MODEL_NAME: MODEL_NAME,
    ok.MODEL_LIST: MODEL_LIST
}

for i in (
    BACKDROP_DEF, FRAME_DEF, MODEL_DEF, SHADOW_DEF
):
    GROUP_DEF.update(i)

# vote dict____________________________________________________________________
vote_d = {}

for i in GROUP_DEF:
    vote_d[i] = scour({}, GROUP_DEF[i], wk.ISSUE)

for i in SUB_GROUP_DEF:
    vote_d[i] = scour({}, SUB_GROUP_DEF[i], wk.ISSUE)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


def get_vote_d(k):
    """
    Fetch the prefab vote dict for a Preset.

    k: string
        Option key

    Return: dict
        Is the default vote dict for the Preset.
    """
    global vote_d

    if k in vote_d:
        return vote_d[k]


def get_default_value(k):
    """
    Fetch a Widget group's option value.

    k: string
        Group key

    Return: dict or None
        {option key: value}
        Use to load a default Preset.
    """
    if k in GROUP_DEF:
        return scour({}, GROUP_DEF[k], wk.VAL)
    if k in SUB_GROUP_DEF:
        return scour({}, SUB_GROUP_DEF[k][wk.SUB], wk.VAL)


def get_group_keys(k):
    """
    Fetch a Widget group's option key list.
    Typically Widget groups are organized as a Preset or a Row.

    k: string
        Group key

    Return: list or None
        [option key]
    """
    if k in GROUP_DEF:
        return GROUP_DEF[k].keys()
    if k in SUB_GROUP_DEF:
        return SUB_GROUP_DEF[k][wk.SUB].keys()


def get_init(k):
    """
    Fetch Widget init argument for a Widget group.

    k: string
        Group key

    Return: tuple
        (dict, list)
        ({option key: Widget init dict}, [option key])
    """
    if k in GROUP_DEF:
        d = deepcopy(GROUP_DEF[k])
        return d, GROUP_DEF[k].keys()

    if k in SUB_GROUP_DEF:
        d = deepcopy(SUB_GROUP_DEF[k])
        return d[wk.SUB], d[wk.SUB].keys()
    return None, None
