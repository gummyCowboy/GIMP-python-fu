#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_fu import (
    add_layer, create_image, invert_and_desaturate, paste_layer, rotate_image
)
from roller_maya_style import Style
from roller_view_hub import (
    calc_rotated_image_span,
    clipboard_fill,
    make_cube_pattern,
    set_fill_context_default
)
from roller_view_real import add_wip_layer, clip_to_wip, finish_style
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: Style
    Return: layer
        with Cube Pattern
    """
    j = v.j
    d = maya.value_d
    key = maya.any_group.item.key

    set_fill_context_default()
    make_cube_pattern(
        d[ok.HEIGHT], d[ok.COLOR_3A], d[ok.IDF][ok.FLIP_V]
    )

    if d[ok.ANGLE]:
        w = calc_rotated_image_span(j.width, j.height)
        j1 = create_image(w, w)
        z = add_layer(j1, key)

        clipboard_fill(z)
        rotate_image(j1, d[ok.ANGLE])
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

        z = paste_layer(maya.group, n=key)

        pdb.gimp_image_reorder_item(j, z, maya.group, 0)
        pdb.gimp_layer_resize_to_image_size(z)
        clip_to_wip(v, z)

    else:
        # pattern layer, 'z'
        z = add_wip_layer(v, key, maya.group)
        clipboard_fill(z)

    invert_and_desaturate(d[ok.IDF], z)
    return finish_style(z, "Cube Pattern")


class CubePattern(Style):
    """Create Backdrop Style output."""
    is_dependent = False

    def __init__(self, any_group, super_maya, k_path):
        k_path = [k_path, k_path + (ok.IDF,)]
        Style.__init__(self, any_group, super_maya, k_path, make_style)
