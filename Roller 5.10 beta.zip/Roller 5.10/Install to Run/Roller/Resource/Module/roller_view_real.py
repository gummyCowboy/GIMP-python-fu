#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_key import Group as gk, Item as ie, Option as ok
from roller_fu import (
    add_layer,
    clear_inverse_selection,
    copy_all_image,
    create_image,
    discard_mask,
    get_background,
    get_layer_position,
    make_layer_group,
    paste_layer,
    remove_layers,
    remove_z,
    rotate_layer,
    select_item,
    select_rect,
    set_layer_mode
)
from roller_view_hub import calc_rotated_image_span, do_gradient_job
from roller_view_step import get_model_branch
import gimpfu as fu
import math

# {group key: sortable position ordinal}
LEAF_D = OrderedDict([
    (gk.CAPTION, 0),
    (gk.LINE, 1),
    (gk.IMAGE, 2),
    (gk.BORDER, 3),
    (gk.FRINGE, 4),
    (gk.PLAQUE, 5),
    (gk.MARGIN, 6),
    (gk.TYPE, 7)
])

# {Node/branch item key: sortable position ordinal}
BRANCH_D = OrderedDict([
    (ie.FACING, 0),
    (ie.FACE, 1),
    (ie.CELL, 2),
    (ie.CANVAS, 3),
])

# sub-Maya  key
FILLER = 'filler'
INNER = 'inner'
LIGHT = 'light'
OVERLAY = 'overlay'
SHADOW = 'shadow'
SHADOW1 = 'shadow1'
SHADOW2 = 'shadow2'
pdb = fu.pdb


def add_base_layer(v, group, n="Base"):
    """
    Add a layer at the bottom of a layer group.

    v: View
    group: layer group
        parent of new layer

    n: string
        appendix for layer name

    Return: layer
        newly added
    """
    return add_layer(
        v.j, group.name + " " + n, offset=len(group.layers), parent=group
    )


def add_matter_group(v, maya, group):
    """
    Add a material layer group to a layer group.

    v: View
    group: layer group
        parent of new layer

    n: string
        appendix for layer name

    Return: layer
        newly added
    """
    return make_layer_group(
        v.j,
        group.name + " Material",
        offset=len(group.layers) - get_blur_behind(maya),
        parent=group
    )


def add_matter_layer(v, maya, group):
    """
    Add a material layer to a layer group.

    v: View
    group: layer group
        parent of new layer

    n: string
        appendix for layer name

    Return: layer
        newly added
    """
    return add_layer(
        v.j,
        group.name + " Material",
        offset=len(group.layers) - get_blur_behind(maya),
        parent=group
    )


def add_sub_base_group(v, maya):
    """
    Add a group layer to the bottom of a Maya layer group.

    v: View
    maya: Maya
    Return: layer group
        newly added
    """
    return make_layer_group(
        v.j,
        maya.any_group.item.key + " WIP",
        parent=maya.group,
        offset=len(maya.group.layers)
    )


def add_top_layer(v, maya, n):
    """
    Add a layer at the top of its group, but below a Gradient Light layer.

    v: View
    maya: Maya
    n: string
        layer name appendix

    Return: layer
        newly added
    """
    return add_layer(
        v.j,
        maya.group.name + " " + n,
        parent=maya.group,
        offset=get_light(maya)
    )


def add_wip_base(v, n, group):
    """
    Insert a new empty WIP layer at the bottom of a layer group.

    v: View
    n: string
        layer name appendix

    Return: layer
        newly added
    """
    return add_wip_layer(v, n, group, offset=len(group.layers))


def add_wip_below(v, z, n=""):
    """
    Insert a new empty WIP layer below an existing layer.

    z: layer
        target of insertion

    n: string or None
        When true, the layer is named.

    Return: layer
        newly added
    """
    return add_wip_layer(
        v, n, z.parent, offset=get_layer_position(z) + 1
    )


def add_wip_layer(v, n, group, offset=0):
    """
    Make a WIP layer. Is not for the layer dock
    trunk, but is for a layer dock branch.

    v: View
    n: string
        layer name appendix

    group: layer group
        If set to None, then the Maya's group layer is used as the parent.

    offset: int
        position the layer

    Return: layer
        as requested
    """
    x, y, w, h = map(int, v.wip.rect)
    z = pdb.gimp_layer_new(
        v.j,
        w, h,
        fu.RGBA_IMAGE,
        group.name + " " + n,
        100.,                       # opacity
        fu.LAYER_MODE_NORMAL
    )

    pdb.gimp_layer_set_offsets(z, x, y)
    pdb.gimp_image_insert_layer(v.j, z, group, offset)
    return z


def clip_to_view(z):
    """
    Transform a layer to the view size which is also the image size.
    The layer content is clipped to the image bounds.

    z: layer
        Is resized to the view size.
    """
    j = z.image
    pdb.gimp_layer_resize(z, j.width, j.height, *z.offsets)


def clip_to_wip(v, z):
    """
    Transform a view sized layer to WIP sized layer.
    Crop the content to the WIP layer bounds.
    """
    isolate_wip_rect(v, z)

    x, y = z.offsets
    q = map(int, (v.wip.w, v.wip.h, x - v.wip.x, y - v.wip.y))
    pdb.gimp_layer_resize(z, *q)


def clone_background(v, z, n="BG Copy", is_hide=True, on_top=False):
    """
    Make a copy of the visible background material
    below a layer. Insert the copy below the layer.

    v: View
    z: layer
        Has background to copy.

    n: string
        layer name of clone

    is_hide: bool
        If true, the top layer, 'z', is not visible.

    on_top: bool
        If True, the the clone layer is inserted above layer 'z'.

    Return: layer
        the copy of the background
    """
    j = z.image
    z1 = get_background(z, n, is_hide=is_hide)
    x = 0 if on_top else 1

    # Insert the layer below layer 'z'.
    pdb.gimp_image_insert_layer(j, z1, z.parent, get_layer_position(z) + x)

    clip_to_wip(v, z1)
    return z1


def create_branch(v, maya):
    """
    Create a layer group for a Model branch or leaf.

    v: View
    maya: Maya
        Needs a layer group in the correct position.

    Return: layer group
        newly created
    """
    def _position(_d):
        # [item key, ...]
        _q = []

        for _z in parent.layers:
            _n = _z.name
            _q.append(_n.split(" ")[-1])

        # [position ordinal, ...]
        _q1 = []

        for k in _q:
            _q1.append(_d.get(k))

        _ordinal = _d.get(item_k)
        _q1.append(_ordinal)
        _q1 = sorted(_q1)

        # Is the offset from the top of parent, '_x'.
        _x = _q1.index(_ordinal)

        pdb.gimp_image_reorder_item(j, group, parent, _x)

    j = v.j
    step_k = get_model_branch(maya.nav_k)

    # Model layer group for Plan or Work, 'parent'
    parent = maya.model.group_q[v.x]

    # If there isn't a Model group, then the caller is out-of-sync.
    if parent:
        # index to item in step key, 'x'
        for x, item_k in enumerate(step_k):
            # Find the sub-step's layer group.
            group = None
            n = parent.name + " " + item_k

            for i in parent.layers:
                if i.name == n:
                    group = i
                    break

            if not group:
                group = make_layer_group(j, parent.name + " " + item_k)

                # Create a layer group.
                if x:
                    _position(LEAF_D)
                else:
                    _position(BRANCH_D)
            parent = group
    return parent


def do_gradient_for_layer(v, d, group, offset):
    """
    Do Gradient Fill on a layer.

    d: dict
        GradientFill Preset

    group: layer group
        destination of layer

    offset: int
        in destination layer group

    Return: layer
        with gradient material
    """
    d[ok.ANGLE] = .0
    return do_rotated_layer(v, d, do_gradient_job, group, offset)


def do_rotated_layer(v, d, p, group, offset):
    """
    Create an enlarged layer before rotating.
    Use a callback to process the rotated layer.

    v: View
    d: dict
        Has options.

    p: callback
        Call to act on the rotated layer before it is finished.

    group: layer
        output destination group

    offset: int
        output position in destination group

    Return: layer
        the rotated layer
    """
    j = group.image
    w, h = map(int, v.wip.size)
    f = d[ok.ANGLE]

    if f:
        # Create a new image for the rotation.
        a = calc_rotated_image_span(w, h)
        j1 = create_image(a, a)
        z = add_layer(j1, "Rotate")

    else:
        j1 = create_image(w, h)
        z = add_layer(j1, "Rotate")

    z = p(z, d)

    if f:
        rotate_layer(z, f)

    copy_all_image(j1)

    if not group.layers:
        # Need something to paste on top of.
        base = add_layer(j, "Base", parent=group)
        z = paste_layer(group.layers[offset])
        remove_z(base)

    else:
        z = paste_layer(group.layers[offset])

    if f:
        pdb.gimp_layer_resize_to_image_size(z)
        clip_to_wip(v, z)

    pdb.gimp_image_delete(j1)
    return z


def finish_style(z, n):
    """
    Finish a Backdrop Style by giving the style layer a name.

    z: layer
        Backdrop Style output

    n: string
        Backdrop Style key

    Return: layer or None
        with material
    """
    if z and z.name != n:
        z.name = n
    return z


def get_blur_behind(maya):
    """
    Determine the offset for a possible Blur Behind layer.

    maya: Maya
    Return: int
        0 or 1
        Is the integer conversion of the boolean result
        of the layer in question's existence.
    """
    if ok.BLUR_BEHIND in maya.sub_maya:
        return int(bool(maya.sub_maya[ok.BLUR_BEHIND].matter))
    return 0


def get_light(maya):
    """
    Determine the offset for a possible Gradient Light layer.

    maya: Maya
    Return: int
        0 or 1
        Is the integer conversion of the boolean result
        of the layer in question's existence.
    """
    if LIGHT in maya.sub_maya:
        return int(bool(maya.sub_maya[LIGHT].matter))
    return 0


def get_noise(maya):
    """
    Determine the offset for a possible Noise layer.

    maya: Maya
    Return: int
        0, 1, or 2
        Is the integer conversion of the boolean result
        of the layer in question's existence added to
        the integer conversion of the boolean result
        of the layer in question's bump layer existence.
    """
    d = maya.sub_maya[ok.NOISE_D]
    return int(bool(d.matter)) + int(bool(d.sub_maya[ok.BUMP].matter))


def get_overlay(maya):
    """
    Determine the offset for a possible Color layer.

    maya: Maya
    Return: int
        0 or 1
        Is the layer offset for inserting a layer
        into a parent group with an Overlay layer.
    """
    return int(bool(maya.sub_maya[OVERLAY].matter))


def insert_copy(v, group, z, is_hide=False):
    """
    Insert a background copy layer into a layer group.

    group: layer
        Is the destination.

    z: layer
        Has position to copy from.

    is_hide: bool
        If True, then the positional layer is
        hidden before making the background copy.

    Return: layer
        that was inserted
    """
    j = z.image
    z1 = get_background(z, "Background Copy", is_hide=is_hide)

    pdb.gimp_image_insert_layer(j, z1, group, 0)
    clip_to_wip(v, z1)
    return z1


def get_point_on_edge(v, angle):
    """
    Calculate an x, y coordinate for a point intersecting
    a ray, originating from the center of a rectangle,
    and ending at a rectangle boundary.

    v: View
    angle: float
        radians
        angle from center of the rectangle

    Return: point
        x, y of float
        the point on the rectangle
    """
    x, y, w, h = v.wip.rect
    sine = math.sin(angle)
    cosine = math.cos(angle)
    h1 = h / 2.
    w1 = w / 2.

    # distance to the top or the bottom edge (from the center), 'h2'
    h2 = h1 if sine > .0 else -h1

    # distance to the left or the right edge (from the center), 'w2'
    w2 = w1 if cosine > .0 else -w1

    # (distance to the vertical line) < (distance to the horizontal line)
    if abs(w2 * sine) < abs(h2 * cosine):
        # Calculate distance to the vertical line:
        h2 = (w2 * sine) / cosine

    # (distance to the top or the bottom edge)
    # < (distance to the left or the right edge)
    else:
        w2 = (h2 * cosine) / sine
    return round(w2 + w1 + x), round(h2 + h1 + y)


def insert_copy_above(v, z, z1):
    """
    Insert a background copy layer above another layer.

    z: layer
        Insert the copy above this layer.

    z1: layer
        Has position to copy from.

    Return: layer
        that was inserted
    """
    j = z.image
    z2 = get_background(z1, "Background Copy", is_hide=False)

    pdb.gimp_image_insert_layer(j, z2, z.parent, get_layer_position(z))
    clip_to_wip(v, z2)
    return z2


def isolate_wip_rect(v, z, keep_sel=False):
    """
    Clear out material not in the WIP rectangle.

    v: View
    z: layer
        with material to clear

    keep_sel: flag
        If true, the selection remains.
    """
    if v.wip.x:
        select_rect(v.j, *v.wip.rect)
        clear_inverse_selection(z, keep_sel=keep_sel)


def make_cast_group(v, maya):
    """
    Make a group layer for a step or a cell sub-step.

    v: View
    maya: Maya
    """
    if not maya.group:
        group = create_branch(v, maya)
        maya.group = make_group(v, "Cast", group, offset=get_light(maya))
    return maya.group


def make_canvas_group(v, maya):
    """
    Make a group layer for a Canvas-branch step.

    v: View
    maya: Maya
    """
    if not maya.group:
        maya.group = create_branch(v, maya)
    return maya.group


def make_group(v, n, parent, offset=0):
    """
    Make a group layer. Is not for the layer dock
    trunk, but is for a layer dock branch.

    v: View
    n: string
        layer name

    parent: layer group or GIMP image
    offset: int
        position the group

    Return: group layer
        as requested
    """
    if parent:
        n = parent.name + " " + n
    return make_layer_group(v.j, n, parent=parent, offset=offset)


def make_plan_group(v, _):
    """
    Make a Plan layer group if there isn't one.

    v: View
    _: maya
        not used

    Return: layer group
        for Plan
    """
    if not v.plan.plan_group:
        v.plan.plan_group = make_layer_group(v.j, "Plan")
    return v.plan.plan_group


def mask_sub_maya(source_z, sub_z):
    """
    Make a mask for a sub-Maya matter layer.

    source_z: layer
        Is the layer with alpha material to make the mask from.

    sub_z: layer or None
        Is the layer to receive the mask.

    Return: layer
        the mask
    """
    if sub_z and source_z:
        mode = None

        # Opacity doesn't change the selection.
        if source_z.mode != fu.LAYER_MODE_NORMAL:
            mode = source_z.mode
            set_layer_mode(source_z, fu.LAYER_MODE_NORMAL)

        select_item(source_z)
        mask_sel(sub_z)
        if mode is not None:
            source_z.mode = mode


def mask_from_many_layer(source_q, sub_z):
    """
    Make a mask for a sub-Maya matter layer.

    source_q: tuple
        (layer, ...)
        Each layer's alpha selection is added to the mask.

    sub_z: layer or None
        Is the layer to receive the mask.

    Return: layer
        the mask
    """
    if sub_z and source_q:
        mode = None

        pdb.gimp_selection_none(sub_z.image)
        for z in source_q:
            # Opacity doesn't change the selection.
            if z.mode != fu.LAYER_MODE_NORMAL:
                mode = z.mode
                set_layer_mode(z, fu.LAYER_MODE_NORMAL)

            select_item(z, option=fu.CHANNEL_OP_ADD)
            if mode is not None:
                z.mode = mode
                mode = None
        mask_sel(sub_z)


def mask_sel(z):
    """
    Make a mask for a layer from a selection.
    Call with a selection already in place.

    z: layer
        to receive mask
    """
    if z:
        discard_mask(z)
        if not pdb.gimp_selection_is_empty(z.image):
            z.add_mask(pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION))
        else:
            # There is no source for the mask, so mask everything.
            z.add_mask(pdb.gimp_layer_create_mask(z, fu.ADD_MASK_BLACK))


def remove_maya_z(maya, n):
    """
    Remove a layer given its attribute descriptor. Set its reference to None.

    maya: Maya
        Has the attribute that references a layer(s).

    n: string
        layer attribute descriptor
    """
    remove_layers(getattr(maya, n))
    setattr(maya, n, None)
