#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame import grow_frame
from roller_fu import (
    add_layer, clear_selection, load_selection, select_item
)
from roller_maya import check_matter, check_mix_basic, make_group_frame
from roller_maya_blur_behind import BlurBehind
from roller_maya_build import Build
from roller_maya_light import Light
from roller_maya_noise import Noise
from roller_maya_shadow import Shadow
from roller_view_hub import (
    calc_gradient, color_selection, set_fill_context_default
)
from roller_view_real import LIGHT, get_light, get_noise
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: GradientLevel
    Return: layer
        with the frame
    """
    j = v.j
    d = maya.value_d
    start_color, end_color = d[ok.COLOR_2A]
    steps = d[ok.WIDTH]
    cast = maya.cast.matter
    z = add_layer(
        j,
        maya.group.name + " Gradient Level",
        parent=maya.group,
        offset=get_light(maya) + get_noise(maya)
    )

    # Begin gradient construction.
    step = calc_gradient(start_color, end_color, steps)
    q = list(start_color)
    sel = None

    set_fill_context_default()
    select_item(cast)

    for i in range(int(steps)):
        if not pdb.gimp_selection_is_empty(j):
            sel = pdb.gimp_selection_save(j)

            grow_frame(j, 1., ff.ANGULAR)
            load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
            color_selection(z, tuple(q))
            load_selection(j, sel, option=fu.CHANNEL_OP_ADD)
            for x in range(4):
                q[x] = start_color[x] + int(step[x] * (i + 1))
        pdb.gimp_image_remove_channel(j, sel)

    select_item(cast)
    clear_selection(z)
    return z


class GradientLevel(Build):
    """Is frame made from a dual color gradient."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_group_frame, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        Build.__init__(self, any_group, super_maya, k_path, do_matter)

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.NBR, ok.NOISE_D)
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cast, self)
        )
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(
            any_group, self, k_path, ok.NBR
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.TRANSLUCENT)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Gradient Level Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[ok.NOISE_D].do(
            v, d[ok.NBR][ok.NOISE_D], is_change, self.is_matter
        )

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], is_change, self.is_matter
        )

        self.sub_maya[ok.BLUR_BEHIND].do(
            v, d[ok.NBR][ok.BLUR_BEHIND], m or is_back, self.is_matter
        )
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m
