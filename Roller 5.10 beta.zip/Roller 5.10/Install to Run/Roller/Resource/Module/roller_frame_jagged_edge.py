#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_key import Option as ok
from roller_fu import (
    apply_mask,
    blur_selection,
    clear_inverse_selection,
    clone_opaque_layer,
    remove_z,
    select_item
)
from roller_maya import check_matter
from roller_maya_build import Build
from roller_maya_shadow import Shadow
from roller_view_preset import combine_seed
from roller_view_real import INNER, SHADOW1, SHADOW2, mask_sel
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Make a Jagged Edge mask for its layer group.

    Return: layer
        the mask applied to the layer group
    """
    j = v.j
    d = maya.value_d
    z = clone_opaque_layer(maya.cast.matter, n="Ripping")
    group = maya.cast.group
    amp = int(d[ok.AMPLITUDE])

    apply_mask(z)
    combine_seed(v, d)
    select_item(z)
    pdb.gimp_selection_shrink(j, max(6, amp + 1))
    clear_inverse_selection(z)

    for x in range(4):
        a = randint(0, 1)

        pdb.plug_in_shift(j, z, randint(1, amp), a)
        pdb.plug_in_shift(j, z, randint(1, amp), int(not a))

    # RGB mode, '0'
    pdb.plug_in_oilify(j, z, int(d[ok.SMOOTHNESS]), 0)

    # threshold all, '.0'
    pdb.plug_in_threshold_alpha(j, z, .0)

    blur_selection(z, 1.)
    mask_sel(group)
    remove_z(z)
    return group.mask


class JaggedEdge(Build):
    """Create a Jagged Edge around cast pixel."""
    is_seeded = True
    issue_q = 'matter',
    put = (check_matter, 'matter'),

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        Build.__init__(self, any_group, super_maya, k_path, do_matter)
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self,)
        )

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame type Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If it is True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)

        # Switch the matter layer for Shadow's methodology.
        matter = self.matter
        group = self.matter = self.cast.group

        a = self.sub_maya[ok.SHADOW]
        m = a.do(
            v, d[ok.SRW][ok.SHADOW],
            self.is_matter,
            self.is_matter + is_change
        )
        parent = group.parent
        z = a.sub_maya[SHADOW1].shadow_1

        if z:
            pdb.gimp_image_reorder_item(v.j, z, parent, len(parent.layers))
            z.name = parent.name + " Shadow 1"

        z = a.sub_maya[SHADOW2].shadow_2

        if z:
            pdb.gimp_image_reorder_item(v.j, z, parent, len(parent.layers))
            z.name = parent.name + " Shadow 2"

        z = a.sub_maya[INNER].inner_shadow

        if z:
            pdb.gimp_image_reorder_item(v.j, z, group, 0)
            z.name = group.name + " Inner Shadow"

        self.matter = matter
        self.reset_issue()
        return m
