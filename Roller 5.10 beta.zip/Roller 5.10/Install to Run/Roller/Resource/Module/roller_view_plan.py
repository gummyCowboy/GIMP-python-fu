#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Signal as si
from roller_constant_key import Group as gk, Option as ok, Step as sk
from roller_fu import (
    hide_layer, remove_z, show_layer, validate_layer
)
from roller_one_extract import get_model_list_group
from roller_one_the import The
import gimpfu as fu

pdb = fu.pdb


class Plan:
    """Sketch layer output from the user option settings."""

    def __init__(self):
        self.plan_group = None
        self.is_frozen = False
        The.cat.render.connect(si.CLOSE_VIEW_IMAGE, self.on_close_view_image)

    def delete(self):
        """Delete the Plan folder."""
        remove_z(self.plan_group)
        self.plan_group = None

    def do(self, v, step_q):
        """
        Perform a Plan View.

        v: View
        step_q: list
            [Step key, ...]
        """
        def _refresh():
            # Remove selection because the marching ants are slow to draw.
            # Flushing the display will fail if ignored for too long.
            pdb.gimp_selection_none(v.j)
            pdb.gimp_displays_flush()

        self.is_frozen = False
        is_ice = The.helm.get_group(sk.GLOBAL).widget_d[ok.HIDE_LAYER].get_a()

        self.show_plan()
        self.hide_work(v)

        # [(navigation step key, AnyGroup)], 'step_q'
        for k, any_group in step_q:
            if is_ice:
                # Freeze GIMP's Layers dock and hide layers.
                if v.j:
                    pdb.gimp_image_freeze_layers(v.j)
                    is_ice = False
                    self.is_frozen = True

            any_group.do(v)
            _refresh()
            if any_group.item.key in gk.IMAGE_USER:
                v.pre_j_d[k] = deepcopy(v.j_d)

        if v.j:
            if validate_layer(self.plan_group):
                v.j.active_layer = self.plan_group
            if self.is_frozen:
                pdb.gimp_image_thaw_layers(v.j)
                self.is_frozen = False
        _refresh()

    def get_offset(self):
        """
        Get the offset needed for Product groups.

        Return: int
            0 or 1
        """
        return 1 if validate_layer(self.plan_group) else 0

    def hide_work(self, v):
        """
        Hide the Work group.

        v: View
            Has attribute 'j', the visible rendered GIMP image.
        """
        j = v.j
        if j and j.layers:
            z = j.layers[-1]
            if z and z.name != "Plan":
                hide_layer(z)

                model_group = get_model_list_group()
                q = model_group.work.get_model_folder_list()

                for i in q:
                    hide_layer(i)
                pdb.gimp_displays_flush()

    def on_close_view_image(self, sender, signal):
        """
        Reset the Plan group reference as it was deleted.

        sender: ViewImage
        signal: not used
        """
        self.plan_group = None

    def show_plan(self):
        """Show the Plan group."""
        if validate_layer(self.plan_group):
            show_layer(self.plan_group)
            pdb.gimp_displays_flush()
