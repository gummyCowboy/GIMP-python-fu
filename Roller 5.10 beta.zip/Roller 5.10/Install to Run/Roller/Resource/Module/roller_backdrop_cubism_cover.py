#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_fu import (
    clone_layer,
    invert_and_desaturate,
    merge_layer,
    merge_layer_group,
    set_saturation
)
from roller_maya_style import Style, make_background
from roller_one_gegl import cubism, edge
from roller_view_real import add_sub_base_group, finish_style
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: Style
    Return: layer or None
        with Cubism Cover
    """
    # Is dependent.
    if maya.go:
        j = v.j
        d = maya.value_d
        parent = add_sub_base_group(v, maya)
        z = make_background(v, parent)

        cubism(
            z,
            size=d[ok.TILE_SIZE],
            amount=5.,
            seed=int(v.glow_ball.seed)
        )

        z1 = clone_layer(z, n="Soft light")
        z1.mode = z.mode = fu.LAYER_MODE_SOFTLIGHT

        edge(z1)
        pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

        z = merge_layer(z1)

        set_saturation(z, d[ok.SATURATION])
        invert_and_desaturate(d[ok.IDR], z)
        return finish_style(merge_layer_group(parent), "Cubism Cover")


class CubismCover(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
