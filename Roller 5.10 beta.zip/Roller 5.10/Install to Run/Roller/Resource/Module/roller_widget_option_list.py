#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from random import randint
from roller_constant_for import Color as co, Signal as si, Widget as fw
from roller_constant_key import (
    BackdropStyle as by, Frame as ek, Option as ok, Widget as wk
)
from roller_one import reduce_color, seed_random
from roller_one_extract import get_option_list_key
from roller_one_the import The
from roller_one_tip import Tip
from roller_widget import set_widget_attr
from roller_widget_box import Eventful
from roller_widget_button import ProcessButton
from roller_widget_combo import ComboBox
from roller_widget_label import Label
from roller_widget_node import Dust, Piece
from roller_widget_radio import RadioRow
from roller_widget_tree import TreeViewList
import gtk


def get_frame_canvas_scale():
    return [
        ek.LINK_MIRROR,
        ek.RAD_WAVE,
        ek.RAISED_MAZE
    ]


def get_frame_cell():
    return [
        ek.BOXY_BEVEL,
        ek.CORNER_TAPE,
        ek.FRAME_OVER,
        ek.NAIL_POLISH,
        ek.SHAPE_BURST
    ]


def get_frame_filler():
    return [
        ek.CERAMIC_CHIP,
        ek.STAINED_GLASS,
        ek.STRETCH_TRAY
    ]


def get_frame_mask():
    return [
        ek.FEATHER_STEP,
        ek.JAGGED_EDGE
    ]


def get_frame_metal():
    return [
        ek.BALL_JOINT,
        ek.BORDER_LINE,
        ek.BRUSH_PUNCH,
        ek.CAMO_PLANET,
        ek.CIRCLE_PUNCH,
        ek.LINE_FASHION,
        ek.SQUARE_CUT,
        ek.SQUARE_PUNCH,
        ek.STICKY_WOBBLE,
        ek.WIRE_FENCE
    ]


def get_frame_other():
    return [
        ek.CRUMBLE_SHELL,
        ek.PAINT_RUSH,
        ek.SHADOWY,
    ]


def get_frame_translucent():
    return [
        ek.CLEAR_FRAME,
        ek.COLOR_BOARD,
        ek.COLOR_PIPE,
        ek.GRADIENT_LEVEL,
        ek.HOT_GLUE,
    ]


def get_style_abstract():
    return [
        by.CUBISM_COVER,
        by.ETCH_SKETCH,
        by.GLASS_GAW,
        by.RAINBOW_VALLEY,
        by.SQUARE_CLOUD,
        by.TRAILING_VINE
    ]


def get_style_basic():
    return [
        by.AVERAGE_COLOR,
        by.COLOR_FILL,
        by.GRADIENT_FILL,
        by.IMAGE_GRADIENT,
        by.PATTERN_FILL
    ]


def get_style_design():
    return [
        by.CORE_DESIGN,
        by.DROP_ZONE,
        by.FLOOR_SAMPLE,
        by.LOST_MAZE,
        by.MAZE_BLEND,
        by.MYSTERY_GRATE,
        by.ROOF_TOP
    ]


def get_style_pattern():
    return [
        by.BACK_GAME,
        by.COLOR_GRID,
        by.CUBE_PATTERN,
        by.RECT_PATTERN,
        by.SPIRAL_CHANNEL
    ]


def get_style_texture():
    return [
        by.ACRYLIC_SKY,
        by.CLAY_CHEMISTRY,
        by.CRYSTAL_CAVE,
        by.DARK_FORT,
        by.DENSITY_GRADIENT,
        by.FADING_MAZE,
        by.GALACTIC_FIELD,
        by.HISTORIC_TRIP,
        by.LINE_STONE,
        by.NANO_SUIT,
        by.NOISE_RIFT,
        by.PAPER_WASTE,
        by.ROCKY_LANDING,
        by.SOFT_TOUCH,
        by.SPECIMEN_SPECKLE,
        by.STONE_AGE
    ]


BACKDROP_STYLE_CATEGORY = OrderedDict([
    ("All", None),
    ("Abstract", get_style_abstract),
    ("Basic", get_style_basic),
    ("Design", get_style_design),
    ("Pattern", get_style_pattern),
    ("Texture", get_style_texture)
])
FRAME_CATEGORY = OrderedDict([
    ("All", None),
    ("Canvas Scale", get_frame_canvas_scale),
    ("Cell-by-Cell", get_frame_cell),
    ("Filler", get_frame_filler),
    ("Mask", get_frame_mask),
    ("Metal", get_frame_metal),
    ("Other", get_frame_other),
    ("Translucent", get_frame_translucent)
])


def get_treeview_item(treeview):
    """
    Return the item selected in a TreeViewList.

    treeview: TreeView
        with list

    Return: string or None
        item
    """
    n = None

    # GTK TreeSelection, 'a'
    a = treeview.get_selection()

    if a:
        model, iter_ = a.get_selected()
        if iter_:
            n = model.get_value(iter_, 0)
    return n


class OptionList(Eventful):
    """Is a Treeview composed of a list."""
    category_selection_d = {}
    has_table_label = False
    option_group_d = {}

    def __init__(self, **d):
        """
        d: dict
            Has option.
        """
        set_widget_attr(self, d)

        self._preset = \
            self._label_h = \
            self._option_panel = \
            self._preset_group = \
            self._category_list = \
            self._option_list_d = \
            self._category_combo = None
        self.key = 'option list'
        self._option_type_k = d[wk.ITEM].item
        self.relay = d[wk.RELAY]
        self._list_color = d[wk.TREE_COLOR] = reduce_color(d[wk.COLOR])
        self._panel_color = reduce_color(self._list_color)
        self.option_color = reduce_color(self._panel_color)
        self._container = self.any_group.item.vbox
        self._panel = gtk.HBox()
        The.load_count += 1

        self._init_category_list(d)
        Eventful.__init__(self, self._list_color)
        self._draw_switch(self._container, **d)
        self._draw_list(self._panel, **d)
        self._make_panel(self._panel)
        self._container.pack_start(self._panel, expand=True)
        self.roller_win.connect(si.DIALOG_DRAWN, self.on_option_list_switch)
        The.load_count -= 1

    def _draw_switch(self, vbox, **d):
        """
        Add a Switch option to the top of the base VBox.

        vbox: GTK VBox
            parent of the Switch Widget

        d: dict
            Has init value.
        """
        hbox = gtk.HBox()

        hbox.add(Label(**{wk.TEXT: self._option_type_k + ": "}))

        relay = self.relay[:]

        relay.insert(0, self.on_option_list_switch)

        self._switch = RadioRow(
            **{
                wk.ANY_GROUP: The.dog.none_group(**{wk.ITEM: Dust()}),
                wk.CHANGELESS: True,
                wk.KEY: "SWITCH",
                wk.RELAY: relay,
                wk.ROLLER_WIN: self.roller_win,
                wk.TEXT: ("Off", "On")
            }
        )

        hbox.add(self._switch)
        vbox.pack_start(hbox, expand=False)

    def _draw_list(self, container, **d):
        """
        Draw a choice list for serving a selectable Preset.

        d: dict
            Has option.
        """
        w = fw.MARGIN
        d[wk.SCROLL] = 1
        d[wk.COLOR] = co.LIST_CELL_COLOR
        d[wk.MINIMUM_W] = 1
        d[wk.RELAY] = self.relay[:]

        d[wk.RELAY].insert(0, self.on_option_list_act)

        d[wk.ALIGN] = 0, 0, 1, 1
        self._tree = TreeViewList(**d)
        d[wk.KEY] = d[wk.TEXT] = "Random"
        d[wk.RELAY] = self.relay[:]

        d[wk.RELAY].insert(0, self.randomize)

        button = ProcessButton(**d)
        vbox = gtk.VBox()
        hbox = gtk.HBox()
        self._label_h = gtk.Label("\n")

        self._tree.set_padding(0, w, w, w)
        self.add(vbox)
        hbox.pack_start(self._label_h, expand=True)
        hbox.pack_start(self._tree, expand=True)
        vbox.pack_start(
            Label(
                **{wk.TEXT: "{} Category:  ".format(self._option_type_k)}
            ), expand=False
        )

        e = {}

        e.update(d)

        e[wk.FUNCTION] = self._get_category
        e[wk.RELAY] = self.relay[:]

        e[wk.RELAY].insert(0, self.on_category_change)

        self._category_combo = ComboBox(**e)

        vbox.pack_start(self._category_combo, expand=True)
        vbox.pack_start(hbox, expand=True)
        vbox.pack_start(button, expand=True)
        container.pack_start(self, expand=True)
        self._tree.populate_item_q(d[wk.FUNCTION]())
        self._tree.select_item(0)
        self._category_combo.set_a("All")

    def _get_category(self):
        return self._category_list

    def _init_category_list(self, d):
        """
        Set the option list dict required to access a sub-category preset list.

        d: dict
            Has a 'wk.FUNCTION' key, value pair.
            Get the complete list of options for the TreeViewList.
        """
        e = self._option_list_d = {
            ok.BACKDROP_STYLE: BACKDROP_STYLE_CATEGORY,
            ok.FRAME: FRAME_CATEGORY
        }[self._option_type_k]
        e["All"] = d[wk.FUNCTION]
        self._category_list = e.keys()

    def _make_panel(self, container):
        """
        Make a GTK HBox panel for the list choice.

        container: GTK HBox
            Is the parent for the option panel.
        """
        self._option_panel = gtk.HBox()
        box = Eventful(self._panel_color)

        box.add(self._option_panel)
        container.pack_start(box, expand=True)

    def _on_list_choice(self, value=None):
        """
        Respond to list change. For each choice,
        create an AnyGroup. Change Widget visibility.

        value: dict
            If a value, then load the chosen AnyGroup with this Preset.
        """
        if self._option_panel:
            dog = The.dog
            group_d = OptionList.option_group_d

            # Save old value.
            if self._preset:
                self._preset_group.value_d = self._preset.get_a()

            OptionList.category_selection_d[self._category_combo.get_a()] = \
                preset_k = value.keys()[0] if value \
                else get_treeview_item(self._tree.treeview)

            if not value and preset_k in group_d:
                value_d = group_d[preset_k].value_d

            else:
                if value:
                    value_d = value[preset_k]
                else:
                    value_d = The.preset.get_default_value(preset_k)

            self.disconnect()

            d = {
                wk.COLOR: self.option_color,
                wk.HAS_PRESET: True,
                wk.IS_DEFAULT: False,
                wk.ITEM: Piece(
                    preset_k, self._option_panel, self.any_group.item
                ),
                wk.RELAY: self.relay[:],
                wk.ROLLER_WIN: self.roller_win
            }
            any_group = self._preset_group = dog.many_group(**d)
            group_d[preset_k] = any_group
            a = len(any_group.widget_d)

            self._label_h.set_label("\n" * (a + 2 + (a // 2)))
            self._option_panel.show_all()
            self.roller_win.emit(si.DIALOG_DRAWN, self)

            self._preset = any_group.widget_d[ok.PRESET]

            self._preset.set_a(value_d)
            self._tree.treeview.set_tooltip_text(
                Tip.OPTION_LIST[preset_k] if preset_k in Tip.OPTION_LIST
                else ""
            )

            # for the Preview and Plan Button sensitivity
            self.relay[-1](self)
            self.roller_win.resize()

    def disconnect(self, *_):
        """
        Remove the VBox child from the option panel so
        that the VBox can be reused by another option.
        """
        for child in self._option_panel.get_children():
            # Remove the previous VBox from
            # the panel, but don't delete it.
            #
            # Reference
            # 'stackoverflow.com/questions/5614840/pygtk-remove-a
            # -widget-from-a-container-and-reuse-it-later'
            self._option_panel.remove(child)

    def get_a(self):
        """
        Retrieve the value of the list and Preset.

        Return: dict
            {Preset key: Preset}
        """
        d = {ok.SWITCH: self._switch.get_a()}
        preset_k = get_treeview_item(self._tree.treeview)

        # Make a copy because the AnyGroup Widget
        # is shared and not unique to a single Preset.
        d.update({preset_k: deepcopy(self._preset.get_a())})
        return d

    def on_category_change(self, g):
        """
        Respond to change in the category ComboBox.

        g: ComboBox
            category list
            Is responsible.
        """
        if not The.load_count:
            # Set the option list and select the previous selection.
            x = 0
            k = g.get_a()
            q = self._option_list_d[k]()

            self._tree.set_a(q)

            n = OptionList.category_selection_d.get(k)

            if n is not None:
                q = self._tree.item_q
                if n in q:
                    x = q.index(n)
            self._tree.select_item(x)
        return True

    def on_option_list_act(self, *_):
        """
        Receive TreeViewList change signal.

        Return: True
            The signal is processed.
        """
        self._on_list_choice()
        return True

    def on_option_list_switch(self, *_):
        """
        Respond to a Switch click.

        Return: True
            Let GTK know the signal is processed.
        """
        if self._switch.get_a():
            if not self._panel.parent:
                self._container.add(self._panel)

        else:
            if self._panel.parent:
                self._container.remove(self._panel)

        self._container.show_all()
        self.roller_win.resize()
        return True

    def randomize(self, *_):
        """Select a random choice from the list."""
        seed_random()
        self._tree.select_item(randint(0, len(self._tree.item_q) - 1))

    def set_a(self, d):
        """
        Select an item in the list. Load its Preset.

        d: dict
            Backdrop Style or Frame Preset
        """
        k = get_option_list_key(d)
        q = self._tree.item_q
        if q:
            x = q.index(k) if k in q else 0
            self._tree.treeview.set_cursor(x)

            # GTK TreeSelection, 'selection'
            selection = self._tree.treeview.get_selection()

            if selection:
                model, iter_ = selection.get_selected()
                if iter_:
                    path = model.get_path(iter_)
                    self._tree.treeview.scroll_to_cell(path)

            self._on_list_choice(value={k: d[k]})
            self._switch.set_a(d[ok.SWITCH])
