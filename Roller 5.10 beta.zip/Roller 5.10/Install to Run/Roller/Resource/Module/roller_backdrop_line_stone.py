#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clone_layer,
    dilate,
    invert_and_desaturate,
    make_layer_group,
    merge_layer_group
)
from roller_maya_style import Style, make_background
from roller_one_gegl import color_to_grey, edge, emboss, unsharp_mask
from roller_view_hub import do_curves
from roller_view_preset import combine_seed
from roller_view_real import (
    add_sub_base_group, finish_style, insert_copy_above
)
import gimpfu as fu

STEP = "Line Stone Step {} of 5"
pdb = fu.pdb


def do_step_one(j, z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = clone_layer(z)
    group = make_layer_group(j, STEP.format(1), parent=parent, z=z)
    z = clone_layer(z, n="HSV Value")
    z.mode = fu.LAYER_MODE_HSV_VALUE

    edge(z)

    # no linear, '0'
    pdb.gimp_drawable_invert(z, 0)

    z = clone_layer(z, n="LCH Lightness")
    z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
    z.opacity = 25.
    z = clone_layer(z, n="Hard Mix")
    z.mode = fu.LAYER_MODE_HARD_MIX
    z.opacity = 20.
    return merge_layer_group(group)


def do_step_two(j, z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = clone_layer(z, n="Erode")
    group = make_layer_group(j, STEP.format(2), parent=parent, z=z)

    dilate(z)
    pdb.plug_in_erode(
        j, z,
        1,                  # propagate black
        7,                  # RGB channels
        1.,                 # full rate
        0,                  # direction mask
        0,                  # lower limit
        255                 # upper limit
    )
    return merge_layer_group(group)


def do_step_three(j, z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = clone_layer(z)
    group = make_layer_group(j, STEP.format(3), parent=parent, z=z)

    blur_selection(z, 8)
    pdb.plug_in_despeckle(
        j, z,
        4,
        3,                  # recursive adaptive
        248,                # white cut-off
        7                   # black cut-off
    )
    dilate(z)

    z = clone_layer(z, n="HSV Value")
    z.mode = fu.LAYER_MODE_HSV_VALUE

    dilate(z)
    return merge_layer_group(group)


def do_step_four(v, j, z, parent):
    """
    Process in multiple phases.

    v: View
    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    parent: layer
        container group

    Return: layer
        work-in-progress
    """
    z = clone_layer(z, n="Clouds")
    group = make_layer_group(j, STEP.format(4), parent=parent, z=z)

    # The foggify output is on a layer with zero offset.
    pdb.python_fu_foggify(j, z, "Clouds 2", (127, 127, 127), 3., 100.)
    z1 = j.active_layer
    x, y, w, h = map(int, v.wip.rect)
    pdb.gimp_layer_set_offsets(z1, x, y)
    pdb.gimp_layer_resize(z1, w, h, 0, 0)           # offset x, y: '0'
    return merge_layer_group(group)


def do_step_five(j, z, bg_z, parent):
    """
    Process in multiple phases.

    j: GIMP image
        work-in-progress

    z: layer
        work-in-progress

    bg_z: layer
        background clone

    parent: layer
        container group
    """
    group = make_layer_group(j, "WIP", parent=parent, z=z)
    z = z1 = clone_layer(z, n="Overlay #1")
    z.mode = fu.LAYER_MODE_OVERLAY
    z.opacity = 100.

    pdb.plug_in_hsv_noise(
        j, z,
        1,                  # minimum holdness (1 through 8)
        5,                  # hue-distance angle (0 through 180)
        5,                  # saturation-distance (0 through 255)
        5                   # value-distance (0 through 255)
    )
    emboss(z, 45., 15., 3)
    do_curves(z, (.0, .3921, 1., .6078))

    z = bg_z
    z.mode = fu.LAYER_MODE_OVERLAY
    z.opacity = 100.

    pdb.gimp_image_reorder_item(j, z, group, 1)

    # four coordinates, '4'
    pdb.gimp_drawable_curves_spline(z, fu.HISTOGRAM_VALUE, 4, (.0, 1., 1., .5))

    z = clone_layer(z, n="Difference")
    z.mode = fu.LAYER_MODE_DIFFERENCE
    z.opacity = 50.
    z = clone_layer(z, n="Exclusion")
    z.mode = fu.LAYER_MODE_EXCLUSION
    z.opacity = 25.

    color_to_grey(z)

    z1.opacity = 50.
    z = merge_layer_group(group)
    unsharp_mask(z, 5., 1.5, .3)


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: LineStone
    Return: layer
        with the style material
    """
    # Is dependent.
    if maya.go:
        j = v.j
        d = maya.value_d

        combine_seed(v, d)

        parent = add_sub_base_group(v, maya)
        z = make_background(v, parent)
        bg_z = clone_layer(z, "Overlay")
        group = make_layer_group(j, "WIP", parent=parent, z=z)
        z = z1 = do_step_one(j, z, group)
        z = do_step_two(j, z, group)
        z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
        z2 = insert_copy_above(v, z, parent.layers[0])
        z.mode = fu.LAYER_MODE_NORMAL
        z = z2
        z.mode = fu.LAYER_MODE_HARD_MIX
        z = insert_copy_above(v, z, parent.layers[0])
        z.mode = fu.LAYER_MODE_HSV_VALUE

        j.remove_layer(z1)
        j.remove_layer(z2)

        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        z = do_step_three(j, z, group)
        z = do_step_four(v, j, z, group)
        z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
        z = merge_layer_group(group)

        do_step_five(j, z, bg_z, parent)

        z = merge_layer_group(parent)

        invert_and_desaturate(d[ok.IDR], z)
        return finish_style(z, "Line Stone")


class LineStone(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
