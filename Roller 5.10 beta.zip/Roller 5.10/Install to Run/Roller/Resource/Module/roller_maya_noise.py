#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice, randint, seed
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection, clone_layer, merge_layer, set_saturation
)
from roller_maya import check_mix_noise, check_noise
from roller_maya_build import SubBuild
from roller_maya_bump import Bump
from roller_one_gegl import (
    edge, median_blur, neon, noise_rgb, waterpixels
)
from roller_view_hub import color_layer_default
from roller_view_real import (
    add_wip_layer, get_light, mask_from_many_layer, mask_sub_maya
)
import gimpfu as fu

COLOR_TO_ALPHA = (
    (0, 0, 0),
    (255, 0, 0),
    (0, 255, 0),
    (0, 0, 255),
    (255, 255, 255)
)
pdb = fu.pdb


def do_ink_noise(v, d, z):
    """
    Make Ink Noise for a frame.

    v: View
    maya: Maya
        frame variety

    d: dict
        Metal Noise Preset

    z: layer
        WIP

    Return: layer
        Has Noise output.
    """
    # lowest turbulence, '1.'
    pdb.plug_in_plasma(v.j, z, int(d[ok.SEED] + v.glow_ball.seed), 1.)

    z.opacity = 100.
    name = z.name

    pdb.gimp_drawable_posterize(z, 3)
    neon(z, 1., 1.)
    pdb.plug_in_colortoalpha(v.j, z, (0, 0, 0))

    z1 = clone_layer(z)
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    blur_selection(z, 1.5)

    z = merge_layer(z1)
    z.name = name

    median_blur(z, 3, 50.)
    return z


def do_noise_matter(v, maya):
    """
    Create a Noise layer.

    v: View
    maya: Maya
        Noise

    Return: layer
        Has Noise output.
    """
    d = maya.value_d
    group = maya.super_maya.group
    z = add_wip_layer(v, "Noise", group, offset=get_light(maya.super_maya))

    pdb.gimp_selection_none(v.j)

    z = {
        ff.INK: do_ink_noise,
        ff.RIFT: do_rift_noise,
        ff.SPECK: do_speck_noise,
        ff.WATER: do_water_noise
    }[d[ok.TYPE]](v, d, z)
    return z


def do_rift_noise(v, d, z):
    """
    Make Rift Noise for a layer.

    v: View
    d: dict
        Metal Noise Preset

    z: layer
        WIP

    Return: layer
        with noise
    """
    j = v.j
    seed_ = int(v.glow_ball.seed + d[ok.SEED])

    seed(seed_)

    # Generate line.
    # The horizontal and vertical sizes are randomized.
    pdb.plug_in_solid_noise(
        j, z,
        0,                      # no tile-able
        1,                      # yes, turbulent
        seed_,
        int(d[ok.NOISE_AMOUNT]),
        float(randint(1, 4)),
        float(randint(1, 4))
    )

    # Harden the noise.
    # The radius is randomized.
    pdb.plug_in_unsharp_mask(
        j, z,
        choice((1., 4.)),
        54.,                    # amount
        .0                      # threshold
    )

    if d[ok.BLUR]:
        blur_selection(z, d[ok.BLUR])

    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
    return z


def do_speck_noise(v, d, z):
    """
    Make Speck Noise for a layer.

    v: View
    d: dict
        Metal Noise Preset
        {Option key: value}

    z: layer
        WIP

    Return: layer
        Has Noise output.
    """
    j = v.j
    name = z.name
    z1 = clone_layer(z)
    f = (d[ok.SPECK_NOISE] + .5) / 7.

    # red, green, and blue noise, 'noise'
    pdb.plug_in_rgb_noise(
        j, z1,
        1,                  # independent
        0,                  # not correlated
        .0,
        .0,                # green
        .0,                # blue
        f
    )

    color_layer_default(z, (255, 255, 255))

    z = merge_layer(z1)

    for i in range(4):
        pdb.plug_in_erode(
            j, z,
            1,                # propagate black
            7,                # RGB channels
            1.,               # full rate
            0,                # direction mask
            0,                # lower limit
            12                # upper limit
        )
        pdb.plug_in_rgb_noise(
            j, z,
            1,                # independent
            0,                # not correlated
            f,                # red
            f,                # green
            f,                # blue
            .0
        )

    pdb.plug_in_colortoalpha(v.j, z, (255, 255, 255))
    set_saturation(z, -75.)
    edge(z)
    blur_selection(z, 1.)

    # Curves won't work with a selection.
    pdb.gimp_selection_none(j)

    pdb.plug_in_despeckle(
        j, z,
        1,                      # radius
        3,                      # recursive adaptive
        0,                      # white cut-off
        255                     # black cut-off
    )
    pdb.plug_in_unsharp_mask(
        j, z,
        12.,                    # radius
        50.,                    # amount
        .0                      # threshold
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_ALPHA,
        8,                      # coordinate count
        (.0, .0, .25, .0, .62, .62, .9, 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                      # coordinate count
        (.0, .0, 1., .8)
    )

    z.name = name
    return z


def do_water_noise(v, d, z):
    """
    Make WaterPixel Noise for a layer.

    v: View
    d: dict
        Metal Noise Preset

    z: layer
        WIP

    Return: layer
        Has Noise output.
    """
    a = int(d[ok.SEED] + v.glow_ball.seed)

    for i in range(3):
        noise_rgb(z, 1., 1., 1., 1., a + i)

    waterpixels(z)
    pdb.gimp_brightness_contrast(z, 0, 75)
    return z


class Chaos(SubBuild):
    """Process change for a Noise Preset."""
    is_seeded = True
    issue_q = 'noise', 'mode', 'opacity'
    put = (check_noise, 'matter'), (check_mix_noise, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        super_maya: Maya
            Has the Noise option.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, do_noise_matter)
        self.sub_maya[ok.BUMP] = Bump(any_group, self, k_path + (ok.BUMP,))

    def do(self, v, d, is_change, is_mask):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Noise Preset
            {Option key: value}

        is_change: bool
            Is True if the cast Maya has change.

        is_mask: bool
            Is True if the super Maya has change.
        """
        self.value_d = d
        self.is_noise |= is_change
        self.go = d[ok.SWITCH] and bool(self.super_maya.matter)

        self.realize(v)
        self.sub_maya[ok.BUMP].do(v, d[ok.BUMP], self.is_noise)

        if self.go and (self.is_noise or is_change or is_mask):
            self.mask_layer()
        self.reset_issue()

    def mask_bump_layer(self):
        """Mask the Bump layer if it exists."""
        z = self.sub_maya[ok.BUMP].matter
        if z:
            mask_sub_maya(self.matter, z)


class Noise(Chaos):
    """Process change for a Noise Preset."""

    def __init__(self, *q):
        """
        super_maya: Maya
            Has the Noise option.
        """
        Chaos.__init__(self, *q)

    def mask_layer(self):
        mask_sub_maya(self.super_maya.matter, self.matter)
        self.mask_bump_layer()


class Noisy(Chaos):
    """Process change for a Noise Preset having multiple mask source."""

    def __init__(self, any_group, super_maya, k_path, mask_maya):
        """
        super_maya: Maya
            Has the Noise option.

        mask_maya: iterable
            [Maya, ...]
            Each Maya's 'matter' layer is used as part of the total Noise mask.
        """
        self.mask_maya = mask_maya
        Chaos.__init__(self, any_group, super_maya, k_path)

    def mask_layer(self):
        mask_from_many_layer(
            [i.matter for i in self.mask_maya], self.matter
        )
        self.mask_bump_layer()
