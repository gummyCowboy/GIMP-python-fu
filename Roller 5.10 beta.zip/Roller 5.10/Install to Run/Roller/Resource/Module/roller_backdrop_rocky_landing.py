#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_fu import (
    clone_layer,
    invert_and_desaturate,
    merge_layer,
    merge_layer_group
)
from roller_maya_style import Style
from roller_view_hub import color_layer_default
from roller_view_real import (
    add_sub_base_group, add_wip_layer, clip_to_wip, finish_style
)
import gimpfu as fu

EDGE = "{} of {}"
pdb = fu.pdb


def do_edge(z, mode, i, reps):
    """
    Shred the layer with the edge function and a layer mode.

    z: layer
        work-in-progress
        Is modified.

    mode: enum
        layer mode

    i: int
        repetition number

    reps: int
        number of repetitions

    Return: layer
        with modifications
    """
    j = z.image

    # amount, '1.'; no wrap, '0'; SOBEL, '0'
    pdb.plug_in_edge(j, z, 1., 0, 0)

    z.mode = mode
    z = merge_layer(z)
    return clone_layer(z, n=EDGE.format(str(i), str(reps)))


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: RockyLanding
    Return: layer
        with the style material
    """
    j = v.j
    d = maya.value_d
    group = add_sub_base_group(v, maya)
    z = add_wip_layer(v, "Rocky Landing WIP", group)
    reps = int(d[ok.BLEND])
    reps1 = reps * 2 + 4

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, int(d[ok.SEED] + v.glow_ball.seed), 3.)

    z1 = clone_layer(z, n=EDGE.format("1", reps1))

    color_layer_default(z, (0, 0, 0))

    z = clone_layer(z1, n=EDGE.format("2", reps1))
    z = do_edge(z, fu.LAYER_MODE_SUBTRACT, 3, reps1)
    z = do_edge(z, fu.LAYER_MODE_LCH_HUE, 4, reps1)
    x = 5

    for i in range(reps):
        z = do_edge(z, fu.LAYER_MODE_COLOR_ERASE, x, reps1)
        z = do_edge(z, fu.LAYER_MODE_LCH_CHROMA, x + 1, reps1)
        x += 2

    z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
    z1 = clone_layer(z, n="Overlay")

    # elevation, '30.'; depth, '1'; bump map, '1'
    pdb.plug_in_emboss(j, z1, v.glow_ball.azimuth, 30., 1, 1)

    z1.mode = fu.LAYER_MODE_OVERLAY

    # no linear, '0'
    pdb.gimp_drawable_invert(z1, 0)

    z = clone_layer(z1, n="Despeckle")

    pdb.plug_in_despeckle(j, z1, 1, 1, 200, 255)
    pdb.gimp_layer_set_offsets(z, int(v.wip.x), int(v.wip.y) + 2)
    pdb.plug_in_sobel(j, z, 1, 0, 0)

    z.opacity = 83.
    z1.mode = fu.LAYER_MODE_NORMAL
    z1.opacity = 33.

    pdb.gimp_image_reorder_item(j, z1, group, 3)

    z = merge_layer_group(group)

    clip_to_wip(v, z)
    invert_and_desaturate(d[ok.IDR], z)
    return finish_style(z, "Rocky Landing")


class RockyLanding(Style):
    """Create Backdrop Style output."""
    is_dependent = False
    is_seeded = True

    def __init__(self, any_group, super_maya, k_path):
        k_path = [k_path, k_path + (ok.IDR,)]
        Style.__init__(self, any_group, super_maya, k_path, make_style)
