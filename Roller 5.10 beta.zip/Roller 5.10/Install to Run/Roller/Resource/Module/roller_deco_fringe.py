#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    add_group_type,
    finish_backed,
    make_deco_material,
    paint,
    prep_backed,
    produce_per_facing,
    produce_main_facing,
    ready_canvas_rect,
    ready_shape,
    test_image,
    transform_foam
)
from roller_fu import (
    add_layer_above,
    clear_inverse_selection,
    remove_z,
    select_item,
    select_polygon,
    select_rect,
    select_shape,
    verify_layer_group
)
from roller_view_real import add_base_layer
import gimpfu as fu

pdb = fu.pdb


def do(v, maya, make):
    """
    Make Fringe material. If Plan is active, it
    makes temporary adjustment to the option settings.

    v: View
    maya: Maya
    make: function
        Call to create Fringe layer.

    Return: layer or None
        matter
    """
    d = maya.value_d

    if not v.x:
        # Preserve.
        type_ = d[ok.TYPE]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = {
            ny.CELL: fy.CELL_FRINGE_COLOR,
            ny.CANVAS: fy.CANVAS_FRINGE_COLOR,
            ny.FACE: fy.FACE_FRINGE_COLOR,
            ny.FACING: fy.FACE_FRINGE_COLOR
        }[maya.any_group.render_key[-2]]

    v.deco.type_ = d[ok.TYPE]
    z = make(v, maya)

    if not v.x:
        # Restore.
        d[ok.TYPE] = type_
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(v, maya):
    """
    Make Fringe for the Canvas branch.

    v: View
    maya: Maya
    Return: layer or None
        with Canvas Fringe material
    """
    return do(v, maya, make_canvas)


def do_cell(v, maya):
    """
    Make Fringe for Cell/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell)


def do_face(v, maya):
    """
    Draw Face/Per Fringe.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_face)


def do_facing(v, maya):
    """
    Draw Facing/Per Fringe.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_facing)


def do_main_cell(v, maya):
    """
    Make Cell branch Fringe for main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main)


def do_main_face(v, maya):
    """
    Draw Fringe Face for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_face)


def do_main_facing(v, maya):
    """
    Draw Fringe Face for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_facing)


def make_canvas(v, maya):
    """
    Draw Canvas Fringe material.

    v: View
    maya: Maya
    Return: layer or None
        with Fringe material
    """
    if test_image(v, maya):
        prep_backed(v, maya, maya.group)
        ready_canvas_rect(v, maya)

        z = paint_fringe(v, maya, maya.group)

        finish_backed(v)
        return z


def make_cell(v, maya):
    """
    Make Fringe for Cell/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    if test_image(v, maya):
        prep_backed(v, maya, maya.group)
        ready_shape(v, maya)

        z = paint_fringe(v, maya, maya.group)

        finish_backed(v)
        return z


def make_cell_face(v, maya):
    """
    Make Fringe for Face/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_per_facing(v, maya, make_face)


def make_cell_facing(v, maya):
    """
    Make Fringe for Facing/Per.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_per_facing(v, maya, make_facing)


def make_face(v, maya, group):
    """
    Create Face material.

    v: View
    maya: Maya
    group: layer
        Is the destination parent layer of Face output.
    """
    k = maya.k
    model = maya.model
    go = test_image(v, maya)
    if go:
        maya.rect = model.get_facing_rect(k)
        v.deco.shape = model.get_facing_form(k)
        z = paint_fringe(v, maya, group)
        if z:
            transform_foam(v, maya.rect, z, model.get_facing_foam(k))


def make_facing(v, maya, group):
    """
    Create cell Facing material.

    v: View
    maya: Maya
    group: layer or None
        Is the destination parent layer of Facing output.
    """
    j = v.j
    k = maya.k
    model = maya.model
    go = test_image(v, maya)
    if go:
        maya.rect = model.get_facing_rect(k)

        if v.deco.type_ in (dc.AVERAGE_COLOR, dc.COLOR):
            is_color = True
            v.deco.shape = model.get_facing_shape(k)
            select_polygon(j, v.deco.shape)

        else:
            v.deco.shape = model.get_facing_form(k)
            is_color = False
            select_rect(v.j, *maya.rect)

        # The As Is Fringe Type doesn't create a layer.
        z = make_deco_material(v, maya, group)

        if z and not is_color:
            z = transform_foam(v, maya.rect, z, model.get_facing_foam(k))

        z1 = add_base_layer(v, group, n=v.deco.type_)

        select_shape(j, model.get_facing_shape(k))

        paint(v, z1, maya.value_d)
        model.clip_facing(z1, k)
        select_item(z1)
        if z:
            clear_inverse_selection(z)
            remove_z(z1)


def make_main_face(v, maya):
    """
    Create Fringe material for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_main_facing(v, maya, make_face)


def make_main_facing(v, maya):
    """
    Create Fringe material for the main Facing option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return produce_main_facing(v, maya, make_facing)


def make_main(v, maya):
    """
    Create Cell branch Fringe for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    def _do_average_color():
        _j = v.j
        _d = maya.value_d

        prep_backed(v, maya, group)

        for _k in maya.main_q:
            maya.k = _k
            _z = add_layer_above(v.deco.bg_z, "{}, {}".format(*_k))

            ready_shape(v, maya)
            paint(v, _z, _d)
            select_item(_z)
            pdb.gimp_image_remove_layer(_j, _z)
            make_deco_material(v, maya, group)

        finish_backed(v)
        return verify_layer_group(group)

    def _do_many_material():
        """
        The cells have the same Fringe material, but
        the material has to be applied cell-by-cell.
        """
        for _k in maya.main_q:
            maya.k = _k
            if test_image(v, maya):
                ready_shape(v, maya)
                paint_fringe(v, maya, group)
        return verify_layer_group(group)

    def _do_one_material():
        """
        The cells have the same Fringe material,
        so the output is combined on one layer.
        """
        for _k in maya.main_q:
            _z = add_base_layer(v, group)
            maya.k = _k

            ready_shape(v, maya)
            paint(v, _z, maya.value_d)

        _z = verify_layer_group(group)
        prep_backed(v, maya, parent)

        if _z:
            select_item(_z)
            _z = paint_fringe(v, maya, parent, z=_z)

        finish_backed(v)
        return _z

    parent = maya.group
    group = add_group_type(v, maya)

    if v.deco.type_ == dc.AVERAGE_COLOR:
        return _do_average_color()

    elif v.deco.type_ not in dc.PER_TYPE:
        # All the Fringe is the same
        # material and is applied one time.
        return _do_one_material()
    else:
        return _do_many_material()


def paint_fringe(v, maya, group, z=None):
    """
    Paint Fringe and apply material.

    v: View
    maya: Maya
    group: layer
        Is the destination parent of Fringe output.

    z: layer
        The layer has Fringe material.

    Return: layer or None
        with Fringe material
    """
    j = v.j
    d = maya.value_d

    if not z:
        z = add_base_layer(v, group, n=v.deco.type_)

        select_shape(j, v.deco.shape)
        paint(v, z, d)

    if v.deco.type_ not in (dc.AS_IS, dc.MULTI_COLOR):
        n = z.name

        select_item(z)
        pdb.gimp_image_remove_layer(v.j, z)

        z = make_deco_material(v, maya, group)
        if z:
            z.name = n
    return z
