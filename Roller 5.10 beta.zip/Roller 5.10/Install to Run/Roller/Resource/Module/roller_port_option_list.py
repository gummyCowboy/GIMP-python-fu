#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import (
    BackdropStyle as bs,
    Frame as ek,
    Group as gk,
    Item as ie,
    Option as ok,
    Widget as wk
)
from roller_one_the import The
from roller_port_preview import PortPreview
from roller_widget_option_list import OptionList
from roller_widget_node import Piece


def get_frame_key_list():
    return ek.KEY_LIST


def get_deco_frame_key_list():
    return ek.DECO_KEY_LIST


def get_style_key_list():
    return bs.KEY_LIST


class PortOptionList(PortPreview):
    """Factor Backdrop Style and Frame Port."""

    def __init__(self, d, g, k):
        """
        d: dict
            Has init values.

        g: OptionButton
            Has option values.

        k: string
            Preset key
        """
        self._preset_key = k
        PortPreview.__init__(self, d, g)

    def _draw_option_list(self, box):
        """
        Draw the OptionList Widget group.

        box: GTK container
            to receive group
        """
        d = {
            wk.COLOR: self.color,
            wk.ITEM: Piece(
                self._preset_key,
                box, self.safe.any_group.item,
                has_label=False
            ),
            wk.RELAY: [self.on_port_change],
            wk.ROLLER_WIN: self.roller_win
        }
        d[wk.ANY_GROUP] = The.dog.none_group(**d)

        if self._preset_key == ok.FRAME:
            if self.safe.any_group.render_key[-2] in (ie.FACE, ie.FACING):
                d.update({wk.FUNCTION: get_deco_frame_key_list})

            elif self.safe.any_group.item.key == gk.IMAGE:
                d.update({wk.FUNCTION: get_frame_key_list})
            else:
                d.update({wk.FUNCTION: get_deco_frame_key_list})

        else:
            d.update({wk.FUNCTION: get_style_key_list})

        self._option_list = OptionList(**d)
        self.color = self._option_list.option_color
        self._option_list.set_a(self.safe.get_a())

    def draw(self):
        """
        Draw Widget.

        g: VBox
            container for Widget
        """
        self.is_dirt = True
        self.draw_column((self._draw_option_list, self.draw_process))

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return self.on_cancel_style_port, self.on_accept_style_port

    def get_group_value(self):
        """
        Use to get the OptionList value.

        Return: value
        """
        return self._option_list.get_a()

    def on_accept_style_port(self, *_):
        """Disconnect the option panel before closing."""
        self._option_list.disconnect()
        return self.on_accept_port_preview()

    def on_cancel_style_port(self):
        """Disconnect the option panel before closing."""
        self._option_list.disconnect()
        return self.on_cancel_port_preview()


class PortStyle(PortOptionList):
    """Is a display container for Backdrop Style."""
    window_key = "Backdrop Style"

    def __init__(self, d, g):
        """
        d: dict
            Has init values.

        g: OptionButton
            Has option values.
        """
        PortOptionList.__init__(self, d, g, ok.BACKDROP_STYLE)


class PortFrame(PortOptionList):
    """Is a display container with Frame options."""
    window_key = "Frame"

    def __init__(self, d, g):
        """
        d: dict
            Has init values.

        g: OptionButton
            Is responsible.
        """
        PortOptionList.__init__(self, d, g, ok.FRAME)
