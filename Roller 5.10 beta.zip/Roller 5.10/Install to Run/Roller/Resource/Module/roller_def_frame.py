#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Frame as ff, Gradient as fg, Issue as vo
from roller_constant_key import Option as ok, Widget as wk
from roller_def_share import (
    BBS,
    BLUR,
    BRUSH_SIZE,
    BSR,
    BSR1,
    BSR2,
    CER,
    COLOR_1,
    COLOR_2A,
    FEATHER,
    FILLER_CC,
    FILLER_CP,
    FILLER_LF,
    FILLER_LM,
    FILLER_RM,
    FILLER_RW,
    FILLER_SC,
    FILLER_SG,
    FILLER_SP,
    FILLER_ST,
    FILLER_WF,
    FRAME_W,
    GSR,
    IRR,
    MODE,
    NBR,
    NBS,
    NSR,
    OPACITY,
    OVERLAY_CF,
    OVERLAY_CP,
    OVERLAY_BB,
    OVERLAY_FO,
    OVERLAY_NP,
    SEED,
    SHADOW,
    SHADOW_BASIC,
    SRR,
    STENCIL,
    STEPS,
    TAPE,
    WAVE_AMPLITUDE,
    WAVELENGTH,
    WBR,
    WNR,
    WRAP,
    WRAP_CB,
    WRAP_CF,
    WRAP_CP,
    WRAP_CS,
    WRAP_BB,
    WRAP_NP,
    make_text_tip,
    set_issue
)
from roller_fu_mode import Mode
from roller_one_tip import Tip
from roller_widget_combo import ComboBox
from roller_widget_row import WidgetRow
from roller_widget_slider import RandomSlider

NO_MATTER = (
    ok.BLUR_BEHIND,
    ok.BUMP,
    ok.MODE,
    ok.NOISE_D,
    ok.OPACITY,
    ok.SHADOW,
    ok.SHADOW_BASIC
)


def get_edge_mode_list():
    return Mode.EDGE_MODE


def get_paint_rush_type_list():
    return ff.PAINT_RUSH_TYPE


def get_shaped_list():
    return fg.SHAPED_TYPE


brush_size = deepcopy(BRUSH_SIZE)

# Ball Joint___________________________________________________________________
BALL_JOINT = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BRUSH_SIZE, brush_size),
    (ok.SRW, deepcopy(SRR))
])

set_issue(BALL_JOINT, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Brush Punch__________________________________________________________________
BRUSH_PUNCH = OrderedDict([
    (ok.WRW, deepcopy(WBR)),
    (ok.SRW, deepcopy(NSR))
])

set_issue(BRUSH_PUNCH[ok.WRW][wk.SUB][ok.BRUSH_D], (), vo.FILLER, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Camo Planet__________________________________________________________________
CAMO_PLANET = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.OVERLAY_CP, OVERLAY_CP),
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])
CAMO_PLANET[ok.WRW][wk.SUB][ok.WRAP][wk.SUB][ok.WIDTH][wk.VAL] = 30.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Ceramic Chip_________________________________________________________________
CERAMIC_CHIP = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_CC, FILLER_CC)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])

# Circle Punch_________________________________________________________________
CIRCLE_PUNCH = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_CP, FILLER_CP)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])

# Clear Frame__________________________________________________________________
CLEAR_FRAME = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_CF, deepcopy(WRAP_CF)),
            (ok.OVERLAY_CF, deepcopy(OVERLAY_CF)),
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(BSR))
])

# Color Board__________________________________________________________________
COLOR_BOARD = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_CB, deepcopy(WRAP_CB)),
            (ok.OVERLAY_CF, deepcopy(OVERLAY_CF)),
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(BSR))
])
a = COLOR_BOARD[ok.WRW][wk.SUB][ok.OVERLAY_CF][wk.SUB]
a[ok.COLOR_1][wk.VAL] = 255, 255, 255
a[ok.OPACITY][wk.VAL] = 100.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Color Pipe___________________________________________________________________
COLOR_PIPE = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_CP, deepcopy(WRAP_CP)),
            (ok.OVERLAY_CF, deepcopy(OVERLAY_CF)),
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NBS))
])

# Corner Tape__________________________________________________________________
CORNER_TAPE = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.TAPE, deepcopy(TAPE)),
            (ok.OVERLAY_CF, deepcopy(OVERLAY_CF)),
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(BSR1))
])
a = CORNER_TAPE[ok.WRW][wk.SUB][ok.OVERLAY_CF][wk.SUB]
a[ok.COLOR_1][wk.VAL] = 230, 220, 210
a[ok.OPACITY][wk.VAL] = 15.
a[ok.MODE][wk.VAL] = "Normal"
a = CORNER_TAPE[ok.SRW][wk.SUB][ok.SHADOW_BASIC][wk.SUB]
a[ok.INTENSITY][wk.VAL] = 75.
a[ok.BLUR][wk.VAL] = 7.
a[ok.BLUR][wk.RANDOM_Q] = 2., 10.

CORNER_TAPE[ok.SRW][wk.SUB][ok.BLUR_BEHIND][wk.SUB][ok.SWITCH][wk.VAL] = 1
CORNER_TAPE[ok.SRW][wk.SUB][ok.BLUR_BEHIND][wk.SUB][ok.BLUR].update(
    {wk.VAL: 3., wk.RANDOM_Q: (1., 6.)}
)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Crumble Shell________________________________________________________________
CRUMBLE_SHELL = OrderedDict([
    (ok.WRAP_CS, deepcopy(WRAP_CS)),
    (ok.SHADOW_BASIC, deepcopy(SHADOW_BASIC))
])

a = CRUMBLE_SHELL[ok.SHADOW_BASIC][wk.SUB]
a[ok.BLUR][wk.VAL] = 10.
a[ok.INTENSITY][wk.VAL] = 100.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Boxy Bevel___________________________________________________________________
BOXY_BEVEL = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_CU, deepcopy(WRAP_BB)),
            (ok.OVERLAY_CU, OVERLAY_BB),
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])

# Frame Over___________________________________________________________________
FEATHER_STEP = OrderedDict([
    (ok.FEATHER, deepcopy(FEATHER)),
    (ok.STEPS, deepcopy(STEPS))
])

set_issue(FEATHER_STEP, (), vo.MATTER, ())
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Frame Over___________________________________________________________________
FRAME_OVER = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.STENCIL, deepcopy(STENCIL)),
            (ok.OVERLAY_FO, OVERLAY_FO),
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(BBS))
])

# Gradient Level_____________________________________________________________
GRADIENT_LEVEL = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.WIDTH, deepcopy(FRAME_W)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.NBR, deepcopy(NBR)),
    (ok.SRW, deepcopy(SRR))
])
GRADIENT_LEVEL[ok.COLOR_2A][wk.VAL] = (160, 105, 28, 255), (116, 77, 43, 255)
GRADIENT_LEVEL[ok.WIDTH][wk.VAL] = 30.

set_issue(GRADIENT_LEVEL, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Hot Glue_____________________________________________________________________
HOT_GLUE = OrderedDict([
    (ok.WIDTH, deepcopy(FRAME_W)),
    (ok.SOFTEN, deepcopy(BLUR)),
    (ok.WAVE_AMPLITUDE, deepcopy(WAVE_AMPLITUDE)),
    (ok.WAVELENGTH, deepcopy(WAVELENGTH)),
    (ok.WAVE_PHASE, {
        wk.LIMIT: (-360., 360.),
        wk.PRECISION: 1,
        wk.RANDOM_Q: (-360., 360.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 1.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SRW, deepcopy(BSR2))
])
HOT_GLUE[ok.WIDTH][wk.VAL] = 5.
HOT_GLUE[ok.SOFTEN].update(
    {wk.RANDOM_Q: (1., 3.), wk.VAL: 2.}
)
HOT_GLUE[ok.SRW][wk.SUB][ok.BLUR_BEHIND][wk.SUB][ok.SWITCH][wk.VAL] = 1
HOT_GLUE[ok.SRW][wk.SUB][ok.BLUR_BEHIND][wk.SUB][ok.BLUR][wk.VAL] = 10.

a = HOT_GLUE[ok.SRW][wk.SUB][ok.SHADOW_BASIC][wk.SUB]
a[ok.INTENSITY][wk.VAL] = 80.
a[ok.BLUR].update({wk.RANDOM_Q: (1., 6.), wk.VAL: 4.})
set_issue(HOT_GLUE, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Jagged Edge__________________________________________________________________
JAGGED_EDGE = OrderedDict([
    (ok.AMPLITUDE, {
        wk.LIMIT: (2, 30),
        wk.RANDOM_Q: (2, 30),
        wk.TOOLTIP: Tip.AMPLITUDE,
        wk.TIPPER: make_text_tip,
        wk.VAL: 3.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SMOOTHNESS, {
        wk.LIMIT: (3, 20),
        wk.RANDOM_Q: (5, 12),
        wk.TIPPER: make_text_tip,
        wk.VAL: 4.,
        wk.WIDGET: RandomSlider
    }),
    (ok.SEED, deepcopy(SEED)),
    (ok.SRW, deepcopy(SRR))
])

set_issue(JAGGED_EDGE, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Line Fashion_________________________________________________________________
LINE_FASHION = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_LF, FILLER_LF)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])

# Link Mirror__________________________________________________________________
LINK_MIRROR = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_LM, FILLER_LM)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])

# Nail Polish__________________________________________________________________
NAIL_POLISH = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP_NP, deepcopy(WRAP_NP)),
            (ok.OVERLAY_NP, OVERLAY_NP)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(BSR))
])
a = NAIL_POLISH[ok.SRW][wk.SUB][ok.BLUR_BEHIND][wk.SUB]
a[ok.SWITCH][wk.VAL] = 1
a[ok.BLUR][wk.VAL] = 12.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Paint Rush___________________________________________________________________
PAINT_RUSH = OrderedDict([
    (ok.EDGE_TYPE, {
        wk.FUNCTION: get_paint_rush_type_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: ff.WHITE_SOFT,
        wk.WIDGET: ComboBox
    }),
    (ok.EDGE_MODE, {
        wk.FUNCTION: get_edge_mode_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: "Lighten Only",
        wk.WIDGET: ComboBox
    }),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.WIDTH, deepcopy(FRAME_W)),
    (ok.POST_BLUR, deepcopy(BLUR)),
    (ok.COLORIZE_OPACITY, deepcopy(OPACITY)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.CRW, deepcopy(CER)),
    (ok.SRW, deepcopy(SRR))
])
PAINT_RUSH[ok.WIDTH][wk.VAL] = 80.
PAINT_RUSH[ok.COLOR_1][wk.VAL] = 175, 90, 10
PAINT_RUSH[ok.COLORIZE_OPACITY][wk.VAL] = 70.
PAINT_RUSH[ok.POST_BLUR][wk.TOOLTIP] = Tip.POST_BLUR

set_issue(PAINT_RUSH, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Rad Wave_____________________________________________________________________
RAD_WAVE = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_RW, FILLER_RW)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])

# Raised Maze__________________________________________________________________
RAISED_MAZE = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_RM, FILLER_RM)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])

SHADOWY = {ok.SHADOW: deepcopy(SHADOW)}

# Shape Burst__________________________________________________________________
SHAPE_BURST = OrderedDict([
    (ok.SHAPED_TYPE, {
        wk.FUNCTION: get_shaped_list,
        wk.TIPPER: make_text_tip,
        wk.VAL: fg.SHAPED_DIMPLED,
        wk.WIDGET: ComboBox
    }),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.WIDTH, deepcopy(FRAME_W)),
    (ok.UNSHARP_AMOUNT, {
        wk.LIMIT: (.0, 300.),
        wk.PAGE_INCR: 10.,
        wk.PRECISION: 1,
        wk.RANDOM_Q: (.0, 50.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 10.,
        wk.WIDGET: RandomSlider
    }),
    (ok.UNSHARP_RADIUS, {
        wk.LIMIT: (.0, 1500.),
        wk.PAGE_INCR: 10.,
        wk.PRECISION: 1,
        wk.RANDOM_Q: (.0, 50.),
        wk.TIPPER: make_text_tip,
        wk.VAL: 11.,
        wk.WIDGET: RandomSlider
    }),
    (ok.UNSHARP_THRESHOLD, {
        wk.LIMIT: (.0, .1),
        wk.PRECISION: 2,
        wk.RANDOM_Q: (.0, .1),
        wk.TIPPER: make_text_tip,
        wk.VAL: .03,
        wk.WIDGET: RandomSlider
    }),
    (ok.IRR, deepcopy(IRR)),
    (ok.SRW, deepcopy(GSR))
])
SHAPE_BURST[ok.SRW][wk.SUB][ok.GRADIENT][wk.VAL] = "Brushed Aluminium"
SHAPE_BURST[ok.WIDTH][wk.VAL] = 50.

set_issue(SHAPE_BURST, (), vo.MATTER, NO_MATTER)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Square Cut___________________________________________________________________
SQUARE_CUT = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_SC, FILLER_SC)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])

# Square Punch_________________________________________________________________
SQUARE_PUNCH = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_SP, FILLER_SP)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])

# Stained Glass________________________________________________________________
STAINED_GLASS = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_SG, FILLER_SG)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NBS))
])

# Sticky Wobble________________________________________________________________
STICKY_WOBBLE = OrderedDict([
    (ok.WOBBLE_FACTOR, {
        wk.LIMIT: (.0, 1.),
        wk.PRECISION: 2,
        wk.RANDOM_Q: (.01, 1.),
        wk.TIPPER: make_text_tip,
        wk.VAL: .08,
        wk.WIDGET: RandomSlider
    }),
    (ok.SEED, deepcopy(SEED)),
    (ok.WRW, deepcopy(WNR)),
    (ok.SRW, deepcopy(SRR))
])

a = STICKY_WOBBLE[ok.WRW][wk.SUB][ok.WRAP][wk.SUB]
a[ok.TYPE][wk.VAL] = ff.ROUNDED
a[ok.WIDTH].update({wk.RANDOM_Q: (1, 50), wk.VAL: 12.})
a[ok.DEPTH][wk.VAL] = 10.
a[ok.CONTRAST][wk.VAL] = -36
a[ok.SOFTEN][wk.VAL] = 7.

set_issue(STICKY_WOBBLE, (), vo.MATTER, (ok.WRW, ok.SRW))
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stretch Tray_________________________________________________________________
STRETCH_TRAY = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_ST, FILLER_ST)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])
STRETCH_TRAY[ok.WRW][wk.SUB][ok.WRAP][wk.SUB][ok.TYPE][wk.VAL] = ff.ROUNDED
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wire Fence___________________________________________________________________
WIRE_FENCE = OrderedDict([
    (ok.WRW, {
        wk.SUB: OrderedDict([
            (ok.WRAP, deepcopy(WRAP)),
            (ok.FILLER_WF, FILLER_WF)
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.SRW, deepcopy(NSR))
])
