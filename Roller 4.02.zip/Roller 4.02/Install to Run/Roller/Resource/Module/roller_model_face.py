#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Shape as sh
from roller_model_goo import Mesh
from roller_one import Base, Rect


def get_intersection(p, p1, p2, p3):
    """
    Given two lines that are known to intersect,
    find their intersecting point.

    Reference
    'stackoverflow.com/questions/563198/how-do-you
    -detect-where-two-line-segments-intersect'

    p0, p1: tuple
        (x, y) of float
        line

    p2, p3: tuple
        (x, y) of float
        line

    Return: list
        [float x, float y]
        intersect point
    """
    s_x = p1[0] - p[0]
    s_y = p1[1] - p[1]
    s1_x = p3[0] - p2[0]
    s1_y = p3[1] - p2[1]
    s2_x = p[0] - p2[0]
    s2_y = p[1] - p2[1]

    # scalar, 't'
    t = (s1_x * s2_y - s1_y * s2_x) / (s_x * s1_y - s1_x * s_y)
    return [p[0] + (t * s_x), p[1] + (t * s_y)]


def make_h_face(v, maya):
    """
    Calculate the foam needed for a finished mold.
    The intersection of two lines make a foam corner.
    First create four lines, then intersect them.

    v: View

    Return: tuple
        foam
        (x, y) float series; flag ordered
    """
    q = maya.model.get_face_foam(*maya.r_c_x)
    foam_w = q[2] - q[0]
    foam_h = q[5] - q[1]
    merged = maya.model.get_face_merged(*maya.r_c_x)
    mold = v.pot.mold

    # rectangle offset percentage
    x_f = (mold.x - merged.x) / merged.w
    x1_f = x_f + mold.w / merged.w
    y_f = (mold.y - merged.y) / merged.h
    y1_f = y_f + mold.h / merged.h

    # six coordinate of four lines
    x = x_f * foam_w + q[0]
    x1 = x1_f * foam_w + q[0]
    y = y_f * foam_h + q[1]
    y1 = y1_f * foam_h + q[1]
    y2 = y_f * foam_h + q[3]
    y3 = y1_f * foam_h + q[3]

    # four line that intersect
    line = (x, q[1]), (x, q[5])
    line_1 = (x1, q[1]), (x1, q[5])
    line_2 = (q[0], y), (q[2], y2)
    line_3 = (q[0], y1), (q[2], y3)

    # foam for mold, 'q1'
    q1 = []
    q1 += get_intersection(*line + line_2)
    q1 += get_intersection(*line_1 + line_2)
    q1 += get_intersection(*line + line_3)
    q1 += get_intersection(*line_1 + line_3)
    return q1


def make_v_face(v, maya):
    """
    Calculate the foam needed for a finished mold.
    The intersection of two lines make a foam corner.
    First create four lines, then intersect them.

    v: View
    maya: Maya
    Return: tuple
        foam
        (x, y) float series; flag ordered
    """
    q = maya.model.get_face_foam(*maya.r_c_x)
    foam_w = q[2] - q[0]
    foam_h = q[5] - q[1]
    merged = maya.model.get_face_merged(*maya.r_c_x)
    mold = v.pot.mold

    # rectangle height offset percentage, '*_f'
    y_f = (mold.y - merged.y) / merged.h
    y1_f = y_f + mold.h / merged.h

    # y-factor
    y = y_f * foam_h + q[1]
    y1 = y1_f * foam_h + q[1]
    y2 = y_f * foam_h + q[3]
    y3 = y1_f * foam_h + q[3]

    # x-slope
    slope = (q[1] - q[5]) / (q[0] - q[4])

    x = (y - q[1]) / slope + q[0]
    x1 = (y1 - q[1]) / slope + q[0]
    x2 = (y2 - q[1]) / slope + q[2] + foam_w
    x3 = (y3 - q[1]) / slope + q[2] + foam_w

    # line from NW to SE
    line = (x, y), (x2, y2)
    line_1 = (x1, y1), (x3, y3)

    # rectangle width offset percentage, '*_f'
    x_f = (mold.x - merged.x) / merged.w
    x1_f = x_f + mold.w / merged.w

    # x-factor
    x4 = x_f * foam_w + q[0]
    x5 = x1_f * foam_w + q[0]
    x6 = x_f * foam_w + q[4]
    x7 = x1_f * foam_w + q[4]

    # y-slope
    slope = (q[1] - q[3]) / (q[0] - q[2])
    y4 = slope * (x4 - q[0]) + q[1]
    y5 = slope * (x5 - q[0]) + q[1]
    y6 = slope * (x6 - q[4]) + q[5]
    y7 = slope * (x7 - q[4]) + q[5]

    # line from NE to SW
    line_2 = (x4, y4), (x6, y6)
    line_3 = (x5, y5), (x7, y7)

    # foam derived from mold rectangle, 'q1'
    q1 = []
    q1 += get_intersection(*line + line_2)
    q1 += get_intersection(*line + line_3)
    q1 += get_intersection(*line_1 + line_2)
    q1 += get_intersection(*line_1 + line_3)
    return q1


class BoxFace:
    """Is a super-class for a numbered Face model."""

    def __init__(self, box):
        """
        box: Box
            Is the Model containing the Face.

        update_foam: function
            Call to calculate a Face shape for a pocket size.
        """
        self.box = box
        self.table = None

    def update_type(self):
        """Create a Mesh table to contain Face attribute."""
        self.table = Base.make_2d_table(*self.box.division)
        for r, c in self.box.cell_q:
            self.table[r][c] = Mesh((r, c))


class BoxFace1(BoxFace):
    """Is a reflection of its opposing Face, BoxFace2."""

    def __init__(self, box):
        """
        box: Box
            Is the Model containing the Face.
        """
        BoxFace.__init__(self, box)

    @staticmethod
    def _assemble_bottom_foam(q, center):
        # parallelogram for transform
        return (
            center[0], q[1],
            q[6], q[7],
            q[10], q[11],
            q[8], q[9]
        )

    @staticmethod
    def _assemble_bottom_rect(q, w, h):
        return Rect(q[10], q[1], w, h)

    @staticmethod
    def _assemble_bottom_shape(q, w, h):
        x = q[2] + w
        y = q[1] + h
        return (
            q[2], q[1],
            x, q[1],
            x, y,
            q[2], y,
        )

    @staticmethod
    def _assemble_left_foam(q, center):
        # parallelogram for transform
        return (
            q[0], q[1],
            q[8], center[1],
            q[10], q[11],
            q[8], q[9]
        )

    @staticmethod
    def _assemble_left_rect(q, w, h):
        return Rect(q[0], q[1], w, h)

    @staticmethod
    def _assemble_left_shape(q, w, h):
        x = q[0] + w
        y = q[1] + h
        return (
            q[0], q[1],
            x, q[1],
            x, y,
            q[0], y,
        )

    @staticmethod
    def _assemble_right_foam(q, center):
        # parallelogram for transform
        return (
            q[2], q[3],
            q[4], q[5],
            center[0], center[1],
            q[6], q[7]
        )

    @staticmethod
    def _assemble_right_rect(q, w, h):
        return Rect(q[2], q[3], w, h)

    @staticmethod
    def _assemble_right_shape(q, w, h):
        x = q[2] + w
        y = q[3] + h
        return (
            q[2], q[3],
            x, q[3],
            x, y,
            q[2], y,
        )

    @staticmethod
    def _assemble_top_foam(q, center):
        # parallelogram for transform
        return (
            q[2], q[3],
            q[4], q[5],
            q[0], q[1],
            center[0], center[1]
        )

    @staticmethod
    def _assemble_top_rect(q, w, h):
        return Rect(q[0], q[3], w, h)

    @staticmethod
    def _assemble_top_shape(q, w, h):
        x = q[0] + w
        y = q[3] + h
        return (
            q[0], q[3],
            x, q[3],
            x, y,
            q[0], y,
        )

    def build_bottom(self, q, w, h, center, a):
        """
        Assemble the points of a vertical box Face 1 for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        center: tuple
            (x, y)
            Is the center point of the Box Cell.

        w, h: float
            size of the Face rectangle
        """
        a.merged = a.pocket = self._assemble_bottom_rect(q, w, h)
        a.shape = a.plaque = self._assemble_bottom_shape(q, w, h)
        a.foam = self._assemble_bottom_foam(q, center)
        a.transform = make_v_face

    def build_left(self, q, w, h, center, a):
        """
        Assemble the points of a vertical box Face 1 for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        center: tuple
            (x, y)
            Is the center point of the Box Cell.

        w, h: float
            size of the Face rectangle
        """
        a.merged = a.pocket = self._assemble_left_rect(q, w, h)
        a.shape = a.plaque = self._assemble_left_shape(q, w, h)
        a.foam = self._assemble_left_foam(q, center)
        a.transform = make_h_face

    def build_right(self, q, w, h, center, a):
        """
        Assemble the points of a vertical box Face 2 for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        center: tuple
            (x, y)
            Is the center point of the Box Cell.

        w, h: float
            size of the Face rectangle
        """
        a.merged = a.pocket = self._assemble_right_rect(q, w, h)
        a.shape = a.plaque = self._assemble_right_shape(q, w, h)
        a.foam = self._assemble_right_foam(q, center)
        a.transform = make_h_face

    def build_top(self, q, w, h, center, a):
        """
        Assemble the points of a vertical box Face 1 for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        center: tuple
            (x, y)
            Is the center point of the Box Cell.

        w, h: float
            size of the Face rectangle
        """
        a.merged = a.pocket = self._assemble_top_rect(q, w, h)
        a.shape = a.plaque = self._assemble_top_shape(q, w, h)
        a.foam = self._assemble_top_foam(q, center)
        a.transform = make_v_face

    def update_face(self, *arg):
        """
        Calculate the shape using the pocket rectangle.

        Return: tuple
            of Face shape
        """
        return {
            sh.BOTTOM: self.build_right,
            sh.LEFT: self.build_bottom,
            sh.RIGHT: self.build_top,
            sh.TOP: self.build_left
        }[self.box.box_type](*arg)


class BoxFace2(BoxFace):
    """Is a reflection of its opposing Face, BoxFace1."""

    def __init__(self, box):
        """
        box: Box
            Is the Model containing the Face.
        """
        BoxFace.__init__(self, box)

    @staticmethod
    def _assemble_bottom_foam(q, center):
        return (
            q[0], q[1],
            center[0], q[1],
            q[10], q[11],
            q[8], q[9]
        )

    @staticmethod
    def _assemble_bottom_rect(q, w, h):
        return Rect(q[0], q[1], w, h)

    @staticmethod
    def _assemble_bottom_shape(q, w, h):
        # rectangle polygon
        x = q[0] + w
        y = q[1] + h
        return (
            q[0], q[1],
            x, q[1],
            x, y,
            q[0], y
        )

    @staticmethod
    def _assemble_left_foam(q, center):
        return (
            q[0], q[1],
            q[2], q[3],
            q[10], q[11],
            center[0], center[1]
        )

    @staticmethod
    def _assemble_left_rect(q, w, h):
        return Rect(q[0], q[3], w, h)

    @staticmethod
    def _assemble_left_shape(q, w, h):
        # rectangle polygon
        x = q[0] + w
        y = q[3] + h
        return (
            q[0], q[3],
            x, q[3],
            x, y,
            q[0], y
        )

    @staticmethod
    def _assemble_right_foam(q, center):
        return (
            q[2], center[1],
            q[4], q[5],
            q[2], q[9],
            q[6], q[7]
        )

    @staticmethod
    def _assemble_right_rect(q, w, h, center):
        return Rect(center[0], q[1], w, h)

    @staticmethod
    def _assemble_right_shape(q, w, h):
        # rectangle polygon
        x = q[2] + w
        y = q[5] + h
        return (
            q[2], q[5],
            x, q[5],
            x, y,
            q[2], y
        )

    @staticmethod
    def _assemble_top_foam(q, center):
        return (
            q[2], q[3],
            q[4], q[5],
            center[0], center[1],
            q[6], q[7]
        )

    @staticmethod
    def _assemble_top_rect(q, w, h):
        return Rect(q[2], q[3], w, h)

    @staticmethod
    def _assemble_top_shape(q, w, h):
        # rectangle polygon
        x = q[2] + w
        y = q[3] + h
        return (
            q[2], q[3],
            x, q[3],
            x, y,
            q[2], y
        )

    def build_bottom(self, q, w, h, center, a):
        """
        Assemble the points of a vertical Box Face 2 for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        center: tuple
            (x, y)
            Is the center point of the Box Cell.

        w, h: float
            size of the Face rectangle
        """
        a.merged = a.pocket = self._assemble_bottom_rect(q, w, h)
        a.shape = a.plaque = self._assemble_bottom_shape(q, w, h)
        a.foam = self._assemble_bottom_foam(q, center)
        a.transform = make_v_face

    def build_left(self, q, w, h, center, a):
        """
        Assemble the points of a vertical Box Face 1 for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        center: tuple
            (x, y)
            Is the center point of the Box Cell.

        w, h: float
            size of the Face rectangle
        """
        a.merged = a.pocket = self._assemble_left_rect(q, w, h)
        a.shape = a.plaque = self._assemble_left_shape(q, w, h)
        a.foam = self._assemble_left_foam(q, center)
        a.transform = make_h_face

    def build_right(self, q, w, h, center, a):
        """
        Assemble the points of a vertical box Face 2 for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        center: tuple
            (x, y)
            Is the center point of the Box Cell.

        w, h: float
            size of the Face rectangle
        """
        a.merged = a.pocket = self._assemble_right_rect(q, w, h, center)
        a.shape = a.plaque = self._assemble_right_shape(q, w, h)
        a.foam = self._assemble_right_foam(q, center)
        a.transform = make_h_face

    def build_top(self, q, w, h, center, a):
        """
        Assemble the points of a vertical box Face 2 for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        center: tuple
            (x, y)
            Is the center point of the Box Cell.

        w, h: float
            size of the Face rectangle
        """
        a.merged = a.pocket = self._assemble_top_rect(q, w, h)
        a.shape = a.plaque = self._assemble_top_shape(q, w, h)
        a.foam = self._assemble_top_foam(q, center)
        a.transform = make_v_face

    def update_face(self, *arg):
        """
        Calculate the shape using the pocket rectangle.

        a: Rect
            Cell pocket
            Has a rectangle and center attribute.

        w, h: float
            size of rectangle

        Return: tuple
            of Face shape
        """
        return {
            sh.BOTTOM: self.build_left,
            sh.LEFT: self.build_top,
            sh.RIGHT: self.build_bottom,
            sh.TOP: self.build_right
        }[self.box.box_type](*arg)


class Cap(BoxFace):
    """Is not a reflection of its opposing Face."""

    def __init__(self, box):
        """
        Initialize the model.

        box: Box
            Is the Model containing the Face.
        """
        BoxFace.__init__(self, box)

    @staticmethod
    def _assemble_bottom_foam(q, center):
        return (
            center[0], center[1],
            q[6], q[7],
            q[10], q[11],
            q[8], q[9],
        )

    @staticmethod
    def _assemble_bottom_rect(q, w, center):
        return Rect(q[10], center[1], w, w)

    @staticmethod
    def _assemble_bottom_shape(q, w, center):
        x = q[10] + w
        y = center[1] + w
        return (
            q[10], center[1],
            x, center[1],
            x, y,
            q[10], y
        )

    @staticmethod
    def _assemble_left_foam(q, center):
        return (
            q[2], q[3],
            center[0], q[1],
            q[0], q[1],
            q[10], q[11]
        )

    @staticmethod
    def _assemble_left_rect(q, w):
        return Rect(q[0], q[3], w, w)

    @staticmethod
    def _assemble_left_shape(q, w):
        x = q[0] + w
        y = q[3] + w
        return (
            q[0], q[3],
            x, q[3],
            x, y,
            q[0], y
        )

    @staticmethod
    def _assemble_right_foam(q, center):
        return (
            q[4], q[5],
            q[6], q[7],
            center[0], q[1],
            q[8], q[9]
        )

    @staticmethod
    def _assemble_right_rect(q, w, center):
        return Rect(center[0], q[3], w, w)

    @staticmethod
    def _assemble_right_shape(q, w, center):
        x = center[0] + w
        y = q[3] + w
        return (
            center[0], q[3],
            x, q[3],
            x, y,
            center[0], y
        )

    @staticmethod
    def _assemble_top_foam(q, center):
        return (
            q[2], q[3],
            q[4], q[5],
            q[0], q[1],
            center[0], center[1]
        )

    @staticmethod
    def _assemble_top_rect(q, w):
        return Rect(q[0], q[3], w, w)

    @staticmethod
    def _assemble_top_shape(q, w):
        x = q[0] + w
        y = q[3] + w
        return (
            q[0], q[3],
            x, q[3],
            x, y,
            q[0], y
        )

    def build_bottom(self, q, w, h, center, a):
        """
        Assemble the points of a vertical Box Cap for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        w, h: float
            the scale of the Box hexagon

        center: tuple
            (x, y) of float
            Is the center point of the Box Cell.

        a: Rect
            cell rectangle
        """
        a.merged = a.pocket = self._assemble_bottom_rect(q, w, center)
        a.shape = a.plaque = self._assemble_bottom_shape(q, w, center)
        a.foam = self._assemble_bottom_foam(q, center)
        a.transform = make_v_face

    def build_left(self, q, w, h, center, a):
        """
        Assemble the points of a vertical Box Cap for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        w, h: float
            the scale of the Box hexagon

        center: tuple
            (x, y) of float
            Is the center point of the Box Cell.

        a: Rect
            cell rectangle
        """
        a.merged = a.pocket = self._assemble_left_rect(q, h)
        a.shape = a.plaque = self._assemble_left_shape(q, h)
        a.foam = self._assemble_left_foam(q, center)
        a.transform = make_v_face

    def build_right(self, q, w, h, center, a):
        """
        Assemble the points of a vertical Box Cap for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        w, h: float
            the scale of the Box hexagon

        center: tuple
            (x, y) of float
            Is the center point of the Box Cell.

        a: Rect
            cell rectangle
        """
        a.merged = a.pocket = self._assemble_right_rect(q, h, center)
        a.shape = a.plaque = self._assemble_right_shape(q, h, center)
        a.foam = self._assemble_right_foam(q, center)
        a.transform = make_v_face

    def build_top(self, q, w, h, center, a):
        """
        Assemble the points of a vertical Box Cap for a Mesh instance.

        q: iterable
            of x, y coordinate
            Is the shape of the Top Box.

        w, h: float
            the scale of the Box hexagon

        center: tuple
            (x, y) of float
            Is the center point of the Box Cell.

        a: Rect
            cell rectangle
        """
        a.merged = a.pocket = self._assemble_top_rect(q, w)
        a.shape = a.plaque = self._assemble_top_shape(q, w)
        a.foam = self._assemble_top_foam(q, center)
        a.transform = make_v_face

    def update_face(self, *arg):
        """Calculate the shape using its pocket rectangle."""
        {
            sh.BOTTOM: self.build_bottom,
            sh.LEFT: self.build_left,
            sh.RIGHT: self.build_right,
            sh.TOP: self.build_top
        }[self.box.box_type](*arg)
