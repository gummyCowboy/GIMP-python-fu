#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_fu import Lay
from roller_view_real import (
    add_sub_base_group, add_wip_layer, finish_style, insert_copy_above
)
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Create a Crystal Cave Backdrop Style.

    v: View
        Has scope variable.

    maya: Style
    Return: layer or None
        with Crystal Cave
    """
    def _flip():
        """Flip a layer both horizontally and vertically."""
        Lay.flip(z2)
        Lay.flip(z2, horizontal=1)

    def _make_group():
        """
        Make a layer group.

        Return:
            group: layer
                new
        """
        return Lay.group(j, "WIP", parent=parent, z=z)

    j = v.j
    a = v.glow_ball
    parent = add_sub_base_group(v, maya)
    random_seed = maya.value_d[ok.SEED] + a.seed
    z = add_wip_layer(v, maya, "Plasma")
    group = _make_group()

    # medium turbulence, '3.5'
    pdb.plug_in_plasma(j, z, random_seed, 3.5)

    z1 = Lay.clone(z, n="Erase")

    pdb.plug_in_emboss(
        j, z,
        a.azimuth,
        a.elevation,
        2,                  # depth
        1                   # emboss type
    )

    z2 = Lay.clone(z, n="Linear Light")

    Lay.clone(z2, n="Linear Light #2")
    pdb.plug_in_emboss(
        j, z1,
        a.azimuth,
        a.elevation,
        100,                # maximum depth
        1                   # emboss type
    )

    z1.mode = fu.LAYER_MODE_COLOR_ERASE

    pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
    pdb.gimp_image_reorder_item(j, z2, z2.parent, 0)

    z2.mode = fu.LAYER_MODE_LINEAR_LIGHT
    z = Lay.merge_group(group)
    z.name = "Group #1"
    group = _make_group()
    z1 = Lay.clone(z, n="Exclusion")
    z1.mode = fu.LAYER_MODE_EXCLUSION

    pdb.plug_in_despeckle(
        j, z,
        16,                     # radius
        3,                      # recursive adaptive
        64,                     # white cut-off
        191                     # black cut-off
    )

    pdb.plug_in_unsharp_mask(
        j, z,
        12.,                    # radius
        54.,                    # amount
        .0                      # threshold
    )

    for _ in range(3):
        pdb.plug_in_wind(
            j, z,
            10,                 # threshold
            0,                  # from left
            30,                 # strength
            0,                  # wind
            1                   # leading edge
        )

    z = Lay.merge_group(group)
    z.name = "Group #2"
    group = _make_group()
    z1 = Lay.clone(z, n="Plasma")
    z2 = Lay.clone(z1, n="Dodge")

    pdb.plug_in_plasma(
        j, z1,
        random_seed,
        1.                      # lowest turbulence
    )

    z1.mode = fu.LAYER_MODE_HSV_VALUE
    z1.opacity = 10.

    pdb.plug_in_erode(
        j, z,
        1,                      # propagate black
        7,                      # RGB channels
        1.,                     # full rate
        0,                      # direction mask
        0,                      # lower limit
        255                     # upper limit
    )
    _flip()

    z2.mode = fu.LAYER_MODE_DODGE
    z3 = insert_copy_above(v, z2, group.layers[0])
    z3.mode = fu.LAYER_MODE_DIFFERENCE
    z2.mode = fu.LAYER_MODE_HSV_VALUE
    z2.opacity = 50.

    _flip()

    z1.mode = fu.LAYER_MODE_BURN
    z1.opacity = 100.

    pdb.gimp_drawable_hue_saturation(
        z1,
        fu.HUE_RANGE_ALL,
        0,                              # hue offset
        0,                              # lightness
        -95,                            # saturation
        0                               # overlap
    )
    z4 = insert_copy_above(v, z3, group.layers[0])
    z4.mode = fu.LAYER_MODE_HSV_VALUE

    pdb.gimp_image_remove_layer(j, z1)

    z5 = Lay.clone(z4, n="Exclusion")
    z5.mode = fu.LAYER_MODE_EXCLUSION
    z5.opacity = 50.
    z = Lay.merge_group(group)
    z.name = "Group #3"
    _make_group()
    z1 = Lay.clone(z, n="Hard Light")

    # no linear, '0'
    pdb.gimp_drawable_invert(z1, 0)

    pdb.plug_in_gauss_rle2(
        j, z1,
        3,                          # blur horizontal
        36                          # blur vertical
    )

    z1.mode = fu.LAYER_MODE_HARDLIGHT
    z1.opacity = 75.
    z = Lay.clone(z1)
    z.mode = fu.LAYER_MODE_HARDLIGHT
    z.opacity = 65.
    return finish_style(Lay.merge_group(parent), "Crystal Cave")


class CrystalCave(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = False
    is_seeded = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
