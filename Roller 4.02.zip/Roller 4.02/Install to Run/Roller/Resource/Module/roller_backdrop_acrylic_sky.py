#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_view_real import add_sub_base_group, finish_style, insert_copy
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a style layer.

    v: View
        Has scope variable.

    maya: Style
    Return: layer or None
        style layer
    """
    def copier(_n):
        """
        Copy the output.

        _n: string
            layer name of copy

        Return: layer
            the copy
        """
        return insert_copy(v, group, parent)

    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya)
    z = insert_copy(v, parent, parent)
    group = Lay.group(j, "WIP", parent=parent, z=z)
    bg_z = Lay.clone(z, n="Exclusion")
    z1 = Lay.clone(z, n="Difference")
    z2 = Lay.clone(z1, n="Subtract")
    z.mode = z2.mode = fu.LAYER_MODE_SUBTRACT
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    Lay.blur(z, 60)
    Lay.blur(z1, 30)
    pdb.plug_in_gimpressionist(j, z2, "Furry")

    z = copier("LCH Lightness")
    z.mode = fu.LAYER_MODE_LCH_LIGHTNESS

    Gegl.waterpixels(z, size=d[ok.SUPERPIXEL_SIZE])

    z = Lay.clone(z, n="Edge")

    Gegl.edge(z)

    z = copier("Waterpixels")

    Gegl.waterpixels(z)

    z.mode = fu.LAYER_MODE_LCH_LIGHTNESS
    z = copier("Dilate")

    pdb.gimp_drawable_invert(z, 0)
    Lay.dilate(z)
    Lay.dilate(z)

    bg_z.mode = fu.LAYER_MODE_EXCLUSION

    Lay.blur(bg_z, 500)
    pdb.gimp_image_reorder_item(j, bg_z, group, 0)

    z = Lay.merge_group(group)

    # Create a paint brush texture.
    Gegl.shift(
        z,
        bs.SHIFT_DIRECTION[d[ok.SHIFT_DIRECTION]].lower(),
        d[ok.SHIFT_GEGL],
        d[ok.SEED] + v.glow_ball.seed
    )
    Lay.blur(z, 1)
    return finish_style(Lay.merge_group(parent), "Acrylic Style")


class AcrylicSky(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_seeded = is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
