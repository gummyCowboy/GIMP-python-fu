#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok, Step as sk
from roller_frame_build import Build
from roller_maya import MAIN, check_cake, check_matter
from roller_maya_bump import Bump
from roller_maya_shadow import Shadow
from roller_maya_style import check_style_group
from roller_one_fu import Lay, Sel
from roller_view_hub import calc_gradient, invert_color
from roller_view_real import (
    add_sub_base_group,
    add_wip_layer,
    clip_to_wip,
    finish_style,
    get_point_on_edge
)
from roller_view_shadow import do_shadow_preset
import gimpfu as fu

LEFT, TOP, RIGHT, BOTTOM = range(4)
pdb = fu.pdb


def make_style(v, maya):
    """
    Draw a fan of wedges colored by one color transiting to another.

    v: View
    maya: Style
    Return: layer or None
        with Floor Sample material
    """
    j = v.j
    d = maya.value_d
    shadow_d = d[ok.BSR][ok.SHADOW]
    has_shadow = shadow_d[sk.SHADOW_SWITCH][ok.SWITCH]
    color, color1 = d[ok.COLOR_2A]

    if d[ok.INVERT]:
        color = invert_color(color)
        color1 = invert_color(color1)

    angle = 360. / d[ok.SLICE_COUNT]
    steps = d[ok.SLICE_COUNT]
    left_x, top_y, w, h = v.wip.rect
    cx, cy = v.j.width // 2., v.j.height // 2.
    a = d[ok.START_ANGLE]
    group = add_sub_base_group(v, maya)
    step = calc_gradient(color, color1, steps)
    x, y = get_point_on_edge(v, a)
    start_color = color
    right_x = w + left_x
    bottom_y = h + top_y

    for spin in range(steps):
        a += angle
        a = a if a < 360 else a - 360
        a = a if a > 0 else a + 360
        x1, y1 = [
            int(i) for i in get_point_on_edge(v, a)
        ]
        q = cx, cy, x, y
        end = start = None

        # Get the corner points in the arc.
        # The variables 'start' and 'end' are
        # the sides of the image-rectangle
        # that the arc begins and ends.
        #
        # start-point
        for i in range(1):
            if x == right_x and y != bottom_y:
                start = RIGHT
                break

            if y == bottom_y:
                if x != left_x:
                    start = BOTTOM
                    break

            if x == left_x:
                if y != top_y:
                    start = LEFT
                    break
            start = TOP

        # end-point
        for i in range(1):
            if x1 == right_x:
                if y1 != bottom_y:
                    end = RIGHT
                    break

            if y1 == bottom_y:
                if x != left_x:
                    end = BOTTOM
                    break

            if x1 == left_x:
                if y1 != top_y:
                    end = LEFT
                    break
            end = TOP

        _x = start + 1

        # Add corner points along the span of the arc.
        if start != end:
            for i in range(4):
                if _x > BOTTOM:
                    _x = 0

                q += (
                    (left_x, bottom_y),
                    (left_x, top_y),
                    (right_x, top_y),
                    (right_x, bottom_y)
                )[_x]

                if _x == end:
                    break
                _x += 1

        q += x1, y1

        Sel.polygon(j, q)

        x, y = x1, y1
        z = add_wip_layer(v, maya, "Edge", group=group)

        Sel.fill(z, color)

        if has_shadow:
            do_shadow_preset(j, shadow_d, (z,), (z,), group)

        color = ()
        for i in range(4):
            b = step[i] * (spin + 1)
            color += (start_color[i] + int(b),)

    z = Lay.merge_group(group)

    clip_to_wip(v, z)
    return finish_style(z, "Floor Sample")


class FloorSample(Build):
    """Create Backdrop Style output."""
    is_dependent = False
    issue_q = 'cake', 'matter'
    put = (
        (check_style_group, 'group'),
        (check_matter, 'matter'),
        (check_cake, None)
    )
    vote_type = MAIN

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            Has the Backdrop Style Button.

        super_maya: Backdrop Maya
        k_path: tuple
            Is the key path to the Backdrop Style
            Button in the AnyGroup's vote dict.
        """
        self.do_matter = make_style

        Build.__init__(self, any_group, super_maya, k_path)

        self.sub_maya[ok.BUMP] = Bump(
            any_group, self, k_path + (ok.BSR, ok.BUMP)
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, [self], k_path + (ok.BSR, ok.SHADOW)
        )

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
            Floor Sample is independent of the Backdrop Image.
        """
        self.value_d = d
        self.is_matter |= self.sub_maya[ok.SHADOW].get_any_vote()

        self.realize(v)

        self.sub_maya[ok.BUMP].do(
            v, self.value_d[ok.BSR][ok.BUMP], self.is_matter
        )
        self.sub_maya[ok.SHADOW].reset_all_issue()
        self.reset_issue()
