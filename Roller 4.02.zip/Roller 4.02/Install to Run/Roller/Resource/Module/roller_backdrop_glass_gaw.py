#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, uniform
from roller_backdrop_color_grid import do_color_grid
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_maya_style import Style
from roller_one import Base
from roller_one_extract import combine_seed
from roller_one_fu import Lay
from roller_view_real import add_sub_base_group, finish_style, insert_copy
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a style layer.

    v: View
    maya: GlassGaw
    Return: layer or None
        the Glass Gaw layer
    """
    def _do_grid(_merge):
        """
        Mix random grid overlays with waves.

        _merge: bool
            If it's true, the color grid layer
            is merged with the layer below.
        """
        def do_waves():
            """Do waves on a layer."""
            pdb.plug_in_waves(
                j, _z,
                randint(1, 12),
                1.,                 # phase
                uniform(24., 50.),
                1,                  # sheared
                1                   # Use reflection.
            )

        e[ok.ROW] = randint(2, 6)
        e[ok.COLUMN] = randint(2, 6)
        e[ok.COLOR_2A] = (
            Base.random_rgb() + (255,), Base.random_rgb() + (255,)
        )
        _z = do_color_grid(v, e, group)
        _z.mode = fu.LAYER_MODE_DIFFERENCE

        do_waves()

        if _merge:
            _z = pdb.gimp_image_merge_down(j, _z, fu.CLIP_TO_IMAGE)
            do_waves()
        return _z

    def _make_group(_n):
        return Lay.group(j, key + _n, parent=parent, z=z)

    j = v.j
    e = get_default_value(by.COLOR_GRID)
    key = maya.any_group.item.key
    parent = add_sub_base_group(v, maya)
    z = insert_copy(v, parent, parent)
    group = _make_group(" Group 1 WIP")

    combine_seed(v, maya.value_d)

    for i in range(4):
        z1 = _do_grid(i != 0)
        z = Lay.clone(z1, n="Grid " + str(i + 1))

    # edge amount, '1.'
    # no wrap, '0'
    # Sobel, '0'
    pdb.plug_in_edge(j, z, 1., 0, 0)

    z2 = Lay.clone(z1, n="Difference")

    Lay.blur(z2, 20)

    z2.mode = fu.LAYER_MODE_DIFFERENCE
    z3 = Lay.clone(z2, n="Difference 2")
    z3.mode = fu.LAYER_MODE_DIFFERENCE
    z4 = Lay.clone(z3, n="Grain Extract")
    z4.mode = fu.LAYER_MODE_GRAIN_EXTRACT
    z.mode = fu.LAYER_MODE_DARKEN_ONLY

    pdb.gimp_drawable_invert(z, 0)
    Lay.blur(z, 4)
    pdb.plug_in_unsharp_mask(
        j, z1,
        3.,                     # radius
        .16,                    # amount
        .0                      # threshold
    )

    group1 = _make_group(" Group 2 WIP")

    for i in (z1, z3, z2, z4, z):
        pdb.gimp_image_reorder_item(j, i, group1, 0)

    z5 = Lay.clone(z, n="Erode")

    for _ in range(2):
        pdb.plug_in_erode(
            j, z5,
            1,              # propagate black
            7,              # RGB channels
            1.,             # full rate
            7,              # direction mask
            0,              # lower limit
            128             # upper limit
        )

    Lay.blur(z5, 90)
    j.remove_layer(group)

    z5.mode = fu.LAYER_MODE_MULTIPLY
    return finish_style(Lay.merge_group(parent), "Glass Gaw")


class GlassGaw(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = False
    is_seeded = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
