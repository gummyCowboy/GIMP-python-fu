#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Option as ok
from roller_maya import MAIN, Maya
from roller_one_extract import get_parent_node
from roller_one_fu import Lay
from roller_one_the import The
from roller_option_group import ManyGroup
import gimpfu as fu

pdb = fu.pdb


def rename(z, prefix, n, x):
    """
    Recursively rename sub-Model layer.

    n: string
        name prefix

    z: group layer or GIMP image
    x: int
        offset of layer name to replace
    """
    for z1 in z.layers:
        z1.name = prefix + n + z1.name[x:]
        if hasattr(z1, 'layers'):
            rename(z1, prefix, n, x)


class Model(ManyGroup):
    """The Model step manages Model group."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        parent_node = get_parent_node(self.step_key)
        self.plan = Plan(self, parent_node)
        self.work = Work(self, parent_node)


class Chi(Maya):
    """Use with Plan and Work."""
    issue_q = 'matter',
    vote_type = MAIN

    def __init__(self, any_group, view_x, parent_node, prefix):
        """
        parent_node: Node
            Node has model name item and branch.

        prefix: string
            for Model layer group name
        """
        # Connect Model id with Model layer group, 'model_id_d'.
        # key, value -> {Model id: {'group': layer, 'name': Model name}}
        self.model_d = {}

        self._parent_node = parent_node
        self._prefix = prefix

        Maya.__init__(self, any_group, view_x, ())
        self.set_issue()
        The.cat.render.connect(si.CLOSE_VIEW_IMAGE, self.on_close_view_image)
        for i in (
            (si.MODEL_CREATED, self.on_model_created),
            (si.MODEL_MOVE, self.on_model_move),
            (si.MODEL_RENAME, self.on_model_rename)
        ):
            The.power.connect(*i)

    def check(self, v, plan_offset, group):
        """
        Process Plan and Work Model change.
        Manage Model layer group life-cycle.

        v: VIew
        prefix: string
            layer group name prefix

        plan_offset: int
            layer offset for layer group insertion

        group: layer group
        """
        is_move = False

        for i, d in self.model_d.items():
            name_q = self._parent_node.get_label_q()[1:]
            if not d['group']:
                n = d['name']
                if n in name_q:
                    n = self._prefix + n
                    d['group'] = Lay.group(
                        v.j, n, offset=plan_offset, parent=group
                    )
                    is_move = True

        if is_move:
            self.on_model_move()
        self.reset_issue()

    def do(self, v):
        """
        Is a View entry point. Determine and process change.

        v: View
        """
        if self.is_matter:
            if self.view_x:
                # Work
                offset = v.plan.get_offset()
                group = None

            else:
                # Plan
                offset = 0
                group = v.plan.plan_group
            self.check(v, offset, group)

    def get_group(self, id_):
        """
        Get a Model's layer group from its Model id.

        id_: int
            Model id as used in a navigation step

        x: int
            0 or 1; Plan or Work index

        Return: layer group or None
            a Model group
        """
        d = self.model_d
        if id_ in d:
            return d[id_]['group']

    def on_model_created(self, _, model):
        """
        Record a Model that has been created.

        _: Power
            Sent the Signal.

        arg: Model
            newly created
        """
        a = The.model_id
        i = model.model_id
        self.model_d[i] = {'group': None, 'name': a.get_name(i)}
        self.is_matter = True
        model.baby.connect(si.MODEL_DIE, self.on_model_die)

    def on_model_die(self, _, model):
        """
        A Model is gone. Remove any traces of it.

        model: Model
        """
        i = model.model_id

        Lay.remove(self.model_d[i]['group'])
        self.model_d.pop(i)

    def move_model(self, plan_offset):
        """
        Sync the order of Model folder with the navigation tree.
        The Model folder order is an inverted navigation tree order.

        plan_offset: int
            Is 0 or 1.
            Is one if the Plan layer group has been created.
        """
        # Reverse the order of the list, '[::-1]'.
        name_q = self._parent_node.get_label_q()[1:][::-1]

        for i, d in self.model_d.items():
            n = d['name']
            if n in name_q:
                group = d['group']
                if group:
                    a = Lay.offset(group)
                    b = name_q.index(n) + plan_offset
                    if a != b:
                        pdb.gimp_image_reorder_item(
                            The.view.j, group, group.parent, b
                        )
        pdb.gimp_displays_flush()

    def on_close_view_image(self, _, arg):
        """
        If the render image closes, any Model groups disappear.

        _: ViewImage
            Sent the Signal

        arg: GIMP image
            that was closed
        """
        for i, d in self.model_d.items():
            d['group'] = False

    def on_model_rename(self, _, arg):
        """
        Rename a Model's layers.

        _: Power
            Sent the Signal.

        arg: tuple
            (old name, new name)
        """
        def _rename(_z, _n, _x):
            """
            Recursively rename sub-Model layer.

            _z: group layer or GIMP image
            _n: string
                name prefix

            _x: int
                offset of layer name to replace
            """
            for _z1 in _z.layers:
                _z1.name = self._prefix + _n + _z1.name[_x:]
                if hasattr(_z1, 'layers'):
                    _rename(_z1, _n, _x)

        old_name, new_name = arg

        # Rename the layer output.
        for i, d in self.model_d.items():
            if d['name'] == old_name:
                z = d['group']

                if z:
                    # old layer name cut-off index, 'x'
                    x = len(old_name) + len(self._prefix)
                    z.name = self._prefix + new_name + z.name[x:]
                    _rename(z, new_name, x)

                d['name'] = new_name
                break

    def reset(self):
        """Reset on View image change."""
        self.model_d = {}
        super(Chi, self).reset()


class Plan(Chi):
    """Use with Plan."""

    def __init__(self, any_group, parent_node):
        """
        parent_node: Node
            Node has model name item and branch.
        """
        Chi.__init__(self, any_group, 0, parent_node, "Plan ")

    def on_model_move(self, *_):
        self.move_model(0)


class Work(Chi):
    """Use with Work."""

    def __init__(self, any_group, parent_node):
        """
        any_group: AnyGroup
            Use to acquire the ModelList Widget.

        parent_node: Node
            Node has model name item and branch.
        """
        self._model_list = any_group.widget_d[ok.MODEL_LIST]
        Chi.__init__(self, any_group, 1, parent_node, "")

    def get_model_folder_list(self):
        """
        Collect a list of layer group used by a Model for output.

        Return: list
            of Model owned layer group
        """
        return [a['group'] for i, a in self.model_d.items() if a['group']]

    def on_model_move(self, *_):
        self.move_model(The.view.plan.get_offset())
