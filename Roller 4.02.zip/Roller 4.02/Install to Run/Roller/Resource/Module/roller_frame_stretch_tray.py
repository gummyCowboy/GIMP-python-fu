#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Frame as ek
from roller_frame import FILLER, MetalFiller
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_view_real import clip_to_wip, get_light
import gimpfu as fu

pdb = fu.pdb


def do_filler(v, maya):
    """
    Draw filler material.

    v: View
    maya: StretchTray
    Return: layer
        with filler material
    """
    j = v.j

    # source layer, 'z'
    z = Lay.clone_opaque(maya.cause.matter, n="Left")

    if (
        z.width != v.wip.w or
        z.height != v.wip.h or
        z.offsets != v.wip.position
    ):
        clip_to_wip(v, z)

    if z.mask:
        Lay.apply_mask(z)

    group = Lay.group(
        j, "Stretch", parent=maya.group, z=z, offset=get_light(maya)
    )

    Lay.apply_mask(z)
    pdb.gimp_selection_none(j)

    for x, z1 in enumerate((
        z,
        Lay.clone(z, n="Right"),
        Lay.clone(z, n="Top"),
        Lay.clone(z, n="Bottom")
    )):
        # Gegl.wind(*q)
        pdb.plug_in_wind(
            j, z1,
            .0,                 # Threshold All
            x,                  # direction
            100,                # maximum strength
            0,                  # wind algorithm
            1,                  # leading edge
        )

        # Threshold all pixel, '.0'
        pdb.plug_in_threshold_alpha(j, z1, .0)

    # Make the wind output opaque.
    z1 = Lay.merge_group(group)
    z = Lay.clone_opaque(z1)

    Lay.remove(z1)
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .25, 1., .75)
    )
    Gegl.saturation(z, 10.)

    z1 = Lay.clone(z, n="Hard Light")
    z1.mode = fu.LAYER_MODE_HARDLIGHT
    z1.opacity = 80.

    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .45, 1., .54)
    )

    # depth, '3'; emboss, '1'
    pdb.plug_in_emboss(j, z, v.glow_ball.azimuth, v.glow_ball.elevation, 3, 1)

    z = Lay.merge(z1)
    z.name = z.parent.name + " Filler"
    return z


class StretchTray(MetalFiller):
    """
    Make a frame by stretching cause material horizontally and vertically.
    """
    FRAME_K = ek.STRETCH_TRAY

    def __init__(self, *q, **d):
        """
        q: tuple
            MetalFiller spec

        d: dict
            MetalFiller spec
        """
        MetalFiller.__init__(self, *q + (do_filler,), **d)

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            Ceramic Chip Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then the background was changed by Shadow.
        """
        # Stretch Tray Filler has no vote, so check for change.
        if is_change or not self.sub_maya[FILLER].matter:
            self.sub_maya[FILLER].is_filler = True
        return super(StretchTray, self).do(v, d, is_change)
