#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy
from roller_one_extract import calc_margin
from roller_one_fu import Sel
from roller_view_real import add_wip_base
import gimpfu as fu

pdb = fu.pdb


def make_main_material(v, maya):
    """
    Draw Cell-branch margin for the main option settings.

    Return: layer or None
        with the Margin material
    """
    j = v.j

    pdb.gimp_selection_none(j)

    for r, c in maya.super_maya.main_cell_q:
        maya.r_c = r, c
        select_cell_material(v, maya, option=fu.CHANNEL_OP_ADD)
    if Sel.is_sel(j):
        z = add_wip_base(v, maya, "Margin", maya.super_maya.group)
        z.opacity = 66.

        Sel.fill(z, fy.CELL_MARGIN_COLOR)
        return z


def make_canvas_material(v, maya):
    """
    Draw Canvas Margin for Plan.

    v: View
    maya: CanvasMargin
    Return: layer or None
        Is None if the margin is not planned.
    """
    model = maya.model
    j = v.j
    left_x, top_y, w, h = model.canvas_rect
    right_x = left_x + w
    bottom_y = top_y + h

    pdb.gimp_selection_none(j)

    q = top, bottom, left, right = model.canvas_margin

    for x, i in enumerate(q):
        if i:
            if x in (0, 1):
                # top, bottom
                x1 = left + left_x
                w1 = w - left - right

                if x == 0:
                    y = top_y
                    h1 = top
                else:
                    h1 = bottom
                    y = bottom_y - h1

            else:
                # left, right
                h1 = h - top - bottom
                y = top + top_y

                if x == 2:
                    x1 = left_x
                    w1 = left
                else:
                    w1 = right
                    x1 = right_x - w1
            Sel.rect(j, x1, y, w1, h1, option=fu.CHANNEL_OP_ADD)
    if Sel.is_sel(j):
        z = add_wip_base(v, maya, "Margin", maya.super_maya.group)
        z.opacity = 66.

        Sel.fill(z, fy.CANVAS_MARGIN_COLOR)
        return z


def make_cell_material(v, maya):
    """
    Select Cell-branch Margin for a cell.

    v: View
    maya: Maya
    """
    def select_margins():
        """
        Select a margin for a cell.

        Return: Selection
            state of image
        """
        if a:
            _width = max(1, w - left - right)
            _height = max(1, h - top - bottom)
            _x = x + (left, left, 0, _width + left)[i]
            _y = y + (0, _height + top, top, top)[i]
            _w = (_width, _width, a, a)[i]
            _h = (a, a, _height, _height)[i]
            Sel.rect(j, _x, _y, _w, _h, option=fu.CHANNEL_OP_ADD)

    j = v.j
    super_ = maya.super_maya

    goo = maya.model.goo_d[super_.r_c]
    x, y, w, h = goo.shift.rect
    x1, y1, w1, h1 = goo.pocket.rect
    left = x1 - x
    right = (x + w) - (x1 + w1)
    top = y1 - y
    bottom = (y + h) - (y1 + h1)

    pdb.gimp_selection_none(j)

    for i in range(4):
        a = (top, bottom, left, right)[i]
        select_margins()
    if Sel.is_sel(j):
        z = add_wip_base(v, maya, "Margin", super_.group)
        z.opacity = 66.

        Sel.fill(z, fy.CELL_MARGIN_COLOR)
        return z


def select_cell_material(v, maya, option=fu.CHANNEL_OP_REPLACE):
    """
    Select cell Margin.

    v: View
    maya: Maya
    option: gimpfu enum
        Specify selection option, add, replace, subtract, or intersect.

    Return: state of selection
    """
    j = v.j
    x, y, w, h = maya.model.get_shift_rect(maya.r_c)
    q = top, bottom, left, right = calc_margin(v, maya.value_d)
    for i in range(4):
        a = q[i]
        if a:
            width = max(1, w - left - right)
            height = max(1, h - top - bottom)
            x1 = x + (left, left, 0, width + left)[i]
            y1 = y + (0, height + top, top, top)[i]
            w1 = (width, width, a, a)[i]
            h1 = (a, a, height, height)[i]
            Sel.rect(j, x1, y1, w1, h1, option=option)
