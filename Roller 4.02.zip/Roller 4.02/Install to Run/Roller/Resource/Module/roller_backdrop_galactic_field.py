#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_maya_style import Style
from roller_one import Mode
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_view_real import (
    add_sub_base_group,
    do_gradient_for_layer,
    finish_style,
    insert_copy,
    insert_copy_above
)
from roller_view_hub import get_gradient_factors
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Draw the shrinking rectangles.

    v: View
    maya: GalacticField
    Return: layer
        with Galactic Field material
    """
    def _make_group():
        return Lay.group(v.j, "WIP", parent=parent, z=z)

    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya)
    key = maya.any_group.item.key
    z = insert_copy(v, parent, parent)
    group = _make_group()
    n = "Dotify"
    z1 = Lay.clone(z, n=n)
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    pdb.plug_in_gimpressionist(j, z1, n)

    z2 = insert_copy_above(v, z1, group.layers[0])
    z2.mode = fu.LAYER_MODE_HARD_MIX

    Gegl.emboss(z2, v.glow_ball.azimuth, 12, 3)

    n = "Embroidery"
    z3 = Lay.clone(z, n=n)
    z3.mode = fu.LAYER_MODE_COLOR_ERASE

    pdb.plug_in_gimpressionist(j, z3, n)

    z4 = insert_copy_above(v, z, group.layers[0])

    Lay.hide(z3)
    Lay.blur(z, 500)

    z5 = insert_copy_above(v, z4, group.layers[0])
    z5.mode = fu.LAYER_MODE_SOFTLIGHT

    Lay.hide(z1)
    Lay.hide(z2)

    z = Lay.merge_group(group, n="Group 1")
    group = _make_group()
    z1 = Lay.clone(z, n="Difference")
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    Gegl.unsharp_mask(z1, 3., .5, .0)

    z = insert_copy_above(v, z1, group.layers[0])
    z.mode = fu.LAYER_MODE_SOFTLIGHT

    Lay.hide(z1)

    z = Lay.merge_group(group, n="Group 2")
    group = _make_group()
    z = Lay.clone(z, n="Grain Extract")
    z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
    z.opacity = 50.

    Gegl.waterpixels(z)
    Lay.blur(z, 3)

    z = Lay.clone(z, n="Difference")
    z.mode = fu.LAYER_MODE_DIFFERENCE
    z.opacity = 100.
    z = Lay.merge_group(group, n=key + " WIP")
    e = get_default_value(by.GRADIENT_FILL)
    e[ok.GRADIENT] = d[ok.GBR][ok.GRADIENT]
    e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
        get_gradient_factors(d[ok.GRADIENT_ANGLE])

    e.update(d)

    z = do_gradient_for_layer(v, e, parent, 0)
    z.mode = Mode.get_gradient_mode(d)
    z.opacity = d[ok.GRADIENT_OPACITY]

    Lay.merge(z)

    z = Lay.merge_group(parent)
    return finish_style(z, "Galactic Field")


class GalacticField(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.GBR
    is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        k_path = d['k_path']
        d['k_path'] = [k_path, k_path + (ok.GBR,)]
        Style.__init__(self, *q + (make_style,), **d)
