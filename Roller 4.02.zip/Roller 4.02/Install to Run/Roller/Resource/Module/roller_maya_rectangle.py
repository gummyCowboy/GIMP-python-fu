#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_maya import MAIN, Maya
from roller_one_the import The
from roller_option_group import ManyGroup


class Rectangle(ManyGroup):
    """Use with Cell Rectangle to update its Model."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)
        self.work = Chi(self, 1)
        self.plan = Chi(self, 0)
        self.handle_d[
            self.booth.connect(si.VOTE_CHANGE, self.update_model)
        ] = self.booth
        self.handle_d[self.connect(si.SEQUENCE, self.on_sequence)] = self
        self.handle_d[
            The.power.connect(si.RESIZE, self.on_sequence)
        ] = The.power

    def do(self, v):
        """
        Override the AnyGroup function so that Past's View Signal can be sent.

        v: View
        """
        super(Rectangle, self).do(v)
        self.item.model.past.emit(si.RECTANGLE_VIEW, v.x)

    def on_sequence(self, _, arg):
        """
        Update the Model immediately.

        _: AnyGroup
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
        """
        self.item.model.baby.feed(si.RECTANGLE_CHANGE, (self.value_d, True))

    def update_model(self, *_):
        """Update the Model as time permits."""
        self.item.model.baby.give(si.RECTANGLE_CHANGE, (self.value_d, False))


class Chi(Maya):
    """Is for the Model's Cell Type."""
    issue_q = 'matter',
    vote_type = MAIN

    def __init__(self, any_group, view_x):
        Maya.__init__(self, any_group, view_x, ())
        self.set_issue()

    def do(self, v):
        """
        v: VIew
        """
        self.reset_issue()
