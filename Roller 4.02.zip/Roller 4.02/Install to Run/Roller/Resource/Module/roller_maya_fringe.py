#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy, Signal as si
from roller_constant_key import Node as ny, Option as ok, Plan as ak
from roller_deco_fringe import (
    do_main_cell, do_main_face, do_canvas, do_cell, do_face
)
from roller_maya import (
    MAIN,
    PER,
    Canvas,
    Cell,
    CellRoute,
    Plasma,
    assign_deco_face_image,
    check_cake,
    check_matter,
    take_type_vote
)
from roller_maya_blur_behind import BlurBehind
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_one_extract import get_planner
from roller_option_group import DecoGroup
from roller_view_option_list import Frame
from roller_view_real import LIGHT, make_canvas_group, make_cast_group


class Fringe(DecoGroup):
    """Assign Fringe Maya to an option group."""

    def __init__(self, **d):
        """
        d: dict
            Has init value.
        """
        DecoGroup.__init__(self, **d)

        node_k = self.step_key[-2]
        self.plan = {
            ny.CANVAS: PlanCanvas, ny.CELL: PlanCell, ny.FACE: PlanFace
        }[node_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas, ny.CELL: WorkCell, ny.FACE: WorkFace
        }[node_k](self)
        baby = self.item.model.baby
        if node_k == ny.FACE:
            self.handle_d[
                baby.connect(si.CELL_SHIFT_CALC, self.on_cell_calc)
            ] = baby


class Chi(Plasma):
    """Is factored from Plan and Work."""

    def __init__(self, any_group, view_x, q):
        """
        view_x: int
            0 or 1; Plan or Work index

        q: iterable
            of function for producing View output
        """
        Plasma.__init__(
            self,
            any_group,
            view_x,
            q,
            k_path=[(), (ok.OCR,), (ok.IMAGE_CHOICE,), (ok.BBF, ok.BRUSH_D,)]
        )
        self.set_issue()


class Plan(Chi):
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, self.put)

        planner = get_planner(any_group.step_key)
        self.is_planned = planner.get_option_a(ak.FRINGE)
        self.handle_d[
            planner.connect(fy.SIGNAL_D[ak.FRINGE], self.on_plan_option_change)
        ] = planner

    def bore(self, v):
        """
        Process layer output.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned

        if self.go:
            self.is_matter |= self.is_switched
        self.realize(v)

    def on_plan_option_change(self, _, arg):
        """
        Respond to change.
        """
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Has layer attribute update function. Plan has no need."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_cake, None)
    )

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1, self.put)
        self.sub_maya[ok.FRAME] = Frame(any_group, self, (ok.BBF, ok.FRAME))
        self.sub_maya[ok.BUMP] = Bump(any_group, self, (ok.BBF, ok.BUMP))
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(any_group, self, ())
        self.sub_maya[LIGHT] = Light(any_group, self, ok.FRINGE)
        self.handle_d[
            self.any_group.connect(si.BACK_CHANGE, self.on_back_change)
        ] = self.any_group

    def bore(self, v):
        """
        Process layer output.

        v: View
        """
        d = self.value_d
        self.go = self.value_d[ok.SWITCH]
        is_back = v.is_back

        if self.go:
            self.is_matter |= take_type_vote(v, d)

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)

            self.sub_maya[ok.BUMP].do(v, d[ok.BBF][ok.BUMP], self.is_matter)

            if not self.is_face:
                is_back |= self.sub_maya[ok.FRAME].do(
                    v, d[ok.BBF][ok.FRAME], self.is_matter
                )

            self.sub_maya[ok.BLUR_BEHIND].do(v, d, is_back, self.is_matter)
            self.sub_maya[LIGHT].do(v, self.is_matter)


class Main:
    vote_type = MAIN

    def __init__(self):
        return


class WorkMain(Main, Work):
    """Is for the main option settings."""

    def __init__(self, *arg):
        """
        arg: tuple
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *arg)


# Canvas_______________________________________________________________________
class Cloth:

    def __init__(self):
        self.do_matter = do_canvas


class PlanCanvas(Plan, Canvas, Main, Cloth):
    """Simulate Canvas output."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Plan.__init__(self, any_group)
        Canvas.__init__(self)
        Main.__init__(self)
        Cloth.__init__(self)


class WorkCanvas(WorkMain, Canvas, Cloth):
    """Process Canvas layer output for Work."""
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_cake, None)
    )

    def __init__(self, any_group):
        """Check and act on Vote flag change."""
        WorkMain.__init__(self, any_group)
        Canvas.__init__(self)
        Cloth.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:
    is_face = False

    def __init__(self):
        self.r_c = None
        self.do_matter = do_main_cell


class PlanCell(Plan, Cell, Main, Cellular):
    """Determine change of a Plan's Cell."""
    issue_q = 'matter', 'per_cell', 'switched'

    def __init__(self, any_group):
        Plan.__init__(self, any_group)
        Main.__init__(self)
        Cell.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, Cell, Cellular):
    """Determine change of a Work's Cell."""
    issue_q = 'cake', 'matter', 'per_cell', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            owner
        """
        WorkMain.__init__(self, any_group)
        Cell.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per Cell_____________________________________________________________________
class PerCell:
    vote_type = PER

    def __init__(self, do_matter, r_c):
        self.do_matter = do_matter
        self.r_c = r_c


class PlanCellPer(PerCell, Plan):
    """Manage Per Cell layer output."""
    is_face = False
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, r_c):
        """
        Create a Maya for Per Cell.

        r_c: tuple
            (r, c); cell index; of int
        """
        PerCell.__init__(self, do_cell, r_c)
        Plan.__init__(self, any_group)


class WorkCellPer(PerCell, Work):
    """Manage Per Cell layer output."""
    is_face = False
    issue_q = 'cake', 'matter', 'shade'

    def __init__(self, any_group, r_c):
        """
        Create a Maya for Per Cell.

        r_c: tuple
            (r, c); cell index; of int
        """
        PerCell.__init__(self, do_cell, r_c)
        Work.__init__(self, any_group)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    is_face = True

    def __init__(self):
        self.r_c = self.r_c_x = None
        self.do_matter = do_main_face

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_deco_face_image(v, self)


class PlanFace(Face, Main, Plan, CellRoute):
    """Manage Face layer output."""
    issue_q = 'matter', 'per_cell', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group)
        CellRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, Cell):
    """Manage Face layer output for the main option settings."""
    issue_q = 'cake', 'matter', 'per_cell', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            with Face options
        """
        Face.__init__(self)
        WorkMain.__init__(self, any_group)
        CellRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per Cell________________________________________________________________
class FacePer(PerCell):
    is_face = True

    def __init__(self, *q):
        PerCell.__init__(self, *q)


class PlanFacePer(FacePer, Plan):
    """Manage Per Cell Face layer output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, r_c):
        """
        r_c: tuple
            (r, c); cell index; of int
        """
        FacePer.__init__(self, do_face, r_c)
        Plan.__init__(self, any_group)


class WorkFacePer(FacePer, Work):
    """Manage Per Cell Face layer output."""
    issue_q = 'cake', 'matter', 'shade'

    def __init__(self, any_group, r_c):
        """
        r_c: tuple
            (r, c); cell index; of int
        """
        FacePer.__init__(self, do_face, r_c)
        Work.__init__(self, any_group)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
