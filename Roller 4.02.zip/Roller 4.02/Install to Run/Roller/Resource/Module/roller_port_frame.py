#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_port_option_list import PortOptionList


class PortFrame(PortOptionList):
    """Is a display container with Frame options."""
    window_key = "Frame"

    def __init__(self, d, g):
        """
        d: dict
            Has init values.

        g: OptionButton
            Is responsible.
        """
        PortOptionList.__init__(self, d, g, ok.FRAME)
