#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import Widget as fw
from roller_constant_key import Button as bk, Option as ok, Widget as wk
from roller_one_the import The
from roller_port_preview import PortPreview
from roller_widget_button import (
    AcceptButton,
    CancelButton,
    PlanButton,
    PreviewButton,
    RandomButton
)
from roller_widget_node import Piece
from roller_widget_influence import InfluenceTable
from roller_widget_row import WidgetRow


class PortInfluence(PortPreview):
    """Is a display container for Gradient Light Influence."""
    window_key = "Influence"

    def __init__(self, d, g):
        """
        d: dict
            Has init values.

        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_influence(self, box):
        """
        Draw the Influence option group.

        box: VBox
            container for the Widgets
        """
        d = {
            wk.COLOR: self.color,
            wk.ITEM: Piece(ok.INFLUENCE, box, self.safe.any_group.item),
            wk.RELAY: [self.on_port_change],
            wk.ROLLER_WIN: self.roller_win
        }
        self.any_group = d[wk.ANY_GROUP] = The.dog.none_group(**d)

        self._influence_table = InfluenceTable(**d)
        self._influence_table.set_a(self.safe.get_a())

    def draw(self):
        """
        Draw Widget.

        vbox: VBox
            container for the Widgets
        """
        self.draw_column((self._draw_influence, self.draw_influence_process))

    def draw_influence_process(self, vbox):
        """
        Draw a group with process Buttons.

        vbox: GTK container
            to receive group
        """
        g = WidgetRow(
            **{
                wk.ANY_GROUP: self.any_group,
                wk.PADDING: (0, 0, fw.MARGIN, fw.MARGIN),
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win,
                wk.SUB: OrderedDict([
                    (bk.CANCEL, {wk.WIDGET: CancelButton}),
                    (bk.RANDOM, {wk.WIDGET: RandomButton}),
                    (bk.PLAN, {wk.WIDGET: PlanButton}),
                    (bk.PREVIEW, {wk.WIDGET: PreviewButton}),
                    (bk.ACCEPT, {wk.WIDGET: AcceptButton})
                ])
            }
        )

        self.keep(g)
        vbox.add(g)

    def get_group_value(self):
        """
        Get the Influence Table value.

        Return: dict
            Gradient Light Influence Preset
        """
        return self._influence_table.get_a()
