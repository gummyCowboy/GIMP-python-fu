#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Deco, Run
from roller_constant_for import Signal as si
from roller_constant_key import Option as ok
from roller_fu import (
    clone_layer, select_item, select_opaque, select_rect
)
from roller_maya import on_global
from roller_maya_build import SubBuild
from roller_maya_layer import check_matter, check_mix_basic
from roller_one_wip import Wip
from roller_view_hub import do_mod
from roller_view_real import clip_to_wip, clone_background, mask_from_maya


def do_below_matter(maya):
    """
    Do the Below output for the super Maya's matter layer.

    maya: Below
    Return: layer or None
        Below 'matter'
    """
    j = Run.j
    group = maya.super_maya.group
    d = maya.value_d

    # When there is no Below layer, 'z'.
    z = None

    if group:
        # Below 'matter' layer, 'z'
        if Deco.bg_z:
            z = clone_layer(Deco.bg_z)

        else:
            z = clone_background(group)

        z.name = group.name + " Below"

        select_rect(j, *Wip.get_rect())
        do_mod(z, d[ok.MOD])
        clip_to_wip(z)
    return z


class Below(SubBuild):
    """Manage Below layer output."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (check_matter, 'matter'), (check_mix_basic, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            It's 'matter' layer alpha becomes the output mask.
        """
        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.MOD,)] if isinstance(k_path, tuple) else
            k_path + [k_path[0] + (ok.MOD,)],
            do_below_matter
        )
        self.latch(any_group, (si.BACK_CHANGE, self.on_back_change))

    def do(self, d, is_back, is_mask):
        """
        Manage layer output during a view run.

        d: dict or None
            Below Preset

        is_back: bool or None
            Is True when the background has change.

        is_mask: bool
            If True, then the Below is masked from its above layer.

        Return: bool
            Is True if Below changed.
        """
        self.value_d = d
        self.go = d[ok.SWITCH] and bool(self.super_maya.matter)

        if self.go:
            m = self.is_matter = self.is_matter or is_back or is_mask

        else:
            m = bool(self.matter)

        self.realize()

        if self.matter and m:
            mask_from_maya(
                self.super_maya,
                self.matter,
                select_opaque if d[ok.OPAQUE] else select_item
            )

        self.reset_issue()
        return m

    def on_back_change(self, _, x):
        """
        The background changed.

        _: AnyGroup
            Sent the Signal.

        x: int
            Plan or Work index
        """
        if x == self.view_x:
            arg = [None, None]
            arg[x] = True
            on_global(self, arg, ok.IS_BACK)
