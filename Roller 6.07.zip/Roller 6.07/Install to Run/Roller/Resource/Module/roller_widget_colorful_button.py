#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color as co, Signal as si
from roller_constant_key import Option as ok, Widget as wk
from roller_widget_box import Eventful
import gobject  # type: ignore
import gtk      # type: ignore


class ColorfulButton(Eventful, gobject.GObject):
    """Is a rectangle area that can change color and respond to signals."""
    # Are signals that can be emitted by this class.
    __gsignals__ = si.PER_BUTTON_D

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        super(ColorfulButton, self).__init__(None)

        # for custom signal(s)
        gobject.GObject.__init__(self)

        self.background_color = d[wk.COLOR]
        self.any_group = d[wk.ANY_GROUP]
        self.key = d[wk.KEY] if wk.KEY in d else None
        self.update_creator = d[wk.RELAY]
        self.roller_win = d[wk.ROLLER_WIN]

        # Embed the Widget inside a VBox and an HBox.
        g = self.label = gtk.Label(d[wk.TEXT])
        g1 = self.hbox = gtk.HBox()

        self.add(g1)
        g1.add(g)

        a = gtk.gdk
        p = self.connect

        # signals to respond to
        for i in (a.BUTTON_PRESS_MASK, a.FOCUS_CHANGE_MASK, a.KEY_PRESS_MASK):
            self.add_events(i)

        self.set_can_focus(1)
        self.set_color(self.background_color)

        # Avoid the 'button_press_event' as it fails the Widget.
        p('button_release_event', self.on_click)
        p('key_press_event', self.on_key_press)
        p('focus_in_event', self.focus_in)
        p('focus_out_event', self.focus_out)

    def set_color(self, color):
        """
        Set the button's face color.

        color: gtk.gdk.Color
            button color
        """
        self.modify_bg(gtk.STATE_NORMAL, color)

    def on_click(self, *_):
        """Pass the click event to the button owner."""
        self.grab_focus()
        self.update_creator(self)
        return True

    def on_key_press(self, g, a):
        """
        Process 'space' and 'Return' keypress.

        g: self
        a: signal
            keypress event

        Return: None or True
            Is true when keypress is processed.
        """
        n = gtk.gdk.keyval_name(a.keyval)

        if n == 'space':
            self.update_creator(g)
            return True
        elif n == 'Return':
            g.roller_win.emit(si.ACCEPT_WINDOW, g)
            return True

    def focus_in(self, *_):
        """Change the color of the button to show focus."""
        self.set_color(co.FOCUS_COLOR)
        return True

    def focus_out(self, *_):
        """Change the color of the button to normal."""
        self.set_color(self.background_color)
        return True

    def set_label(self, n):
        """
        Change the button's text.

        n: string
            for Label
        """
        self.label.set_text(n)

    def set_size(self, w=10, h=10):
        """
        Try to set the size of the button.

        w: int
            width of button

        h: int
            height of button
        """
        self.set_size_request(width=w, height=h)

    def set_text_color(self, color):
        """
        Set the color of the button's text.

        color: gtk.gdk.Color
            for the text
        """
        self.label.modify_fg(gtk.STATE_NORMAL, color)

    def show(self):
        """Display the custom button."""
        super(ColorfulButton, self).show()
        for g in (self.hbox, self.vbox, self.label):
            g.show()


class PerCellButton(Eventful, gobject.GObject):
    """
    Is a rectangular area that can change color, respond
    to signal, and display a throw switch menu.
    """
    # Are signals that can be emitted by this class.
    __gsignals__ = si.PER_BUTTON_D

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        super(PerCellButton, self).__init__(None)

        # Enable custom signal.
        gobject.GObject.__init__(self)

        self.background_color = d[wk.COLOR]
        self.any_group = d[wk.ANY_GROUP]
        self.key = d[wk.KEY] if wk.KEY in d else None
        self.update_creator = d[wk.RELAY]
        self.roller_win = d[wk.ROLLER_WIN]
        self.get_owner_a = d[wk.GET_A]
        self.throw_switch = d[wk.SET_A]

        # Embed the Widget inside a VBox and an HBox.
        g = self.label = gtk.Label(d[wk.TEXT])
        g1 = self.hbox = gtk.HBox()

        self.add(g1)
        g1.add(g)

        a = gtk.gdk
        p = self.connect

        # Respond to signal.
        for i in (a.BUTTON_PRESS_MASK, a.FOCUS_CHANGE_MASK, a.KEY_PRESS_MASK):
            self.add_events(i)

        self.set_can_focus(1)
        self.set_color(self.background_color)

        # Avoid the 'button_press_event' as it fails the Widget.
        p('button_release_event', self.on_colorful_button_click)
        p('key_press_event', self.on_key_press)
        p('focus_in_event', self.focus_in)
        p('focus_out_event', self.focus_out)

        self.menu = gtk.Menu()
        self.menu_item = gtk.MenuItem("Throw Switch")

        self.menu_item.connect('activate', self.on_throw_switch)
        self.menu.append(self.menu_item)
        self.menu_item.show()
        self.menu.show()

    def on_switchable_clicked(self, button, event):
        """
        React to a mouse button click on the button. If the
        button is right-clicked, create a popup menu.

        button: self
            not used

        event: gtk.gdk.Event
        """
        d = self.get_owner_a(self.key)
        a = d.get(ok.SWITCH) if d else None
        if a is not None:
            # gtk right-mouse button enum, '3'
            if event.button == 3:
                self.menu.popup(None, None, None, event.button, event.time)

    def on_throw_switch(self, *arg):
        """
        Respond to a throw switch request from the right-click popup menu.

        arg: tuple
            (sender, signal)
            not  used
        """
        d = self.get_owner_a(self.key)
        a = d.get(ok.SWITCH) if d else None
        if a is not None:
            d[ok.SWITCH] = not a
            self.throw_switch(d, self.key)

    def set_color(self, color):
        """
        Set the button's face color.

        color: gtk.gdk.Color
            button color
        """
        self.modify_bg(gtk.STATE_NORMAL, color)

    def on_colorful_button_click(self, button, event):
        """Pass the click event to the button owner."""
        if event.button == 3:
            self.on_switchable_clicked(button, event)
        else:
            self.grab_focus()
            self.update_creator(self)

    def on_key_press(self, g, a):
        """
        Process 'space' and 'Return' keypress.

        g: self
        a: signal
            keypress event

        Return: None or True
            Is true when keypress is processed.
        """
        n = gtk.gdk.keyval_name(a.keyval)

        if n == 'space':
            self.update_creator(g)
        elif n == 'Return':
            g.roller_win.emit(si.ACCEPT_WINDOW, g)

    def focus_in(self, *_):
        """Change the color of the button to show focus."""
        self.set_color(co.FOCUS_COLOR)
        return True

    def focus_out(self, *_):
        """Change the color of the button to normal."""
        self.set_color(self.background_color)
        return True

    def set_label(self, n):
        """
        Change the button's text.

        n: string
            for Label
        """
        self.label.set_text(n)

    def set_size(self, w=10, h=10):
        """
        Try to set the size of the button.

        w: int
            width of button

        h: int
            height of button
        """
        self.set_size_request(width=w, height=h)

    def set_text_color(self, color):
        """
        Set the color of the button's text.

        color: gtk.gdk.Color
            for the text
        """
        self.label.modify_fg(gtk.STATE_NORMAL, color)

    def show(self):
        """Display the custom button."""
        super(PerCellButton, self).show()
        for g in (self.hbox, self.vbox, self.label):
            g.show()


class SwitchButton(ColorfulButton):
    """Process cell connection events."""

    def __init__(self, r, c, **d):
        """
        Create the SwitchButton.

        r, c: int
            cell index

        d: dict
            Has init values.
        """
        self.gate = 0
        self.r = r // 2
        self.c = c // 2
        self._cell_table = d[wk.CELL_TABLE]
        self.pad = d[wk.CONTAINER]
        self.on_gate_action = d[wk.RELAY]
        d[wk.RELAY] = self.on_switch_action
        ColorfulButton.__init__(self, **d)

    def on_switch_action(self, _):
        """
        Reverse the switch setting. Call the connection operator.

        Return: True
            Tell GTK that the signal is handled.
        """
        x = self.gate = int(not self.gate)

        self.set_label(("+", "-")[x])
        self.on_gate_action[x](self._cell_table[self.r][self.c])
        return True


# Register the custom signals.
gobject.type_register(ColorfulButton)
