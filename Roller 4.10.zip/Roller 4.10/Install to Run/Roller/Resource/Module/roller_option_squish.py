#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    BackdropStyle as bs,
    Bump as fb,
    Caption as pt,
    Deco as dc,
    Frame as ff,
    Gradient as fg,
    Grid as gr,
    Mask as ms,
    Resize as fz,
    Shape as sh
)
from roller_constant_key import (
    BackdropStyle as by,
    Button as bk,
    Frame as ek,
    Group as gk,
    Node as ny,
    Option as ok,
    Step as sk,
    Widget as wk,
)
from roller_one_extract import get_option_list_key
from roller_one_the import The
import gimpfu as fu

ALWAYS = ok.PRESET, ok.PER_CELL, ok.SWITCH
COMMON_FORMAT = {bk.PLAN, bk.PREVIEW}
FOR_BOX_SHAPE_COUNT = {ok.HORZ_COUNT, ok.VERT_COUNT}
FOR_CELL_COUNT = {ok.COLUMN_COUNT, ok.ROW_COUNT}
FOR_CELL_SIZE = {ok.COLUMN_W, ok.GRID_SIZE, ok.ROW_H}
FOR_CROP = {ok.CROP_H, ok.CROP_W, ok.CROP_X, ok.CROP_Y}
FOR_BACKDROP = {ok.GRADIENT_ANGLE, ok.GRADIENT_TYPE}
FOR_FIXED = {ok.FIXED_SIZE_H, ok.FIXED_SIZE_W}
FOR_FACTOR = {ok.FIH, ok.FIW}
FOR_GRADIENT = {ok.GRADIENT, ok.GRADIENT_ANGLE, ok.GRADIENT_TYPE}
FOR_PAINT_RUSH = {ok.COLOR_1, ok.COLORIZE_OPACITY}
FOR_DECO_BLUR = dc.BACKDROP, dc.PATTERN, dc.PLASMA, dc.IMAGE
FOR_MASK_D = {
    ms.EYE: ok.PUPIL_SCALE,
    ms.FRINGE: ok.CONTRACT,
    ms.TEXT: (ok.TEXT, ok.FONT),
}
FOR_PARALLELOGRAM = (
    sh.PARALLELOGRAM_ALT_LEFT,
    sh.PARALLELOGRAM_ALT_RIGHT,
    sh.PARALLELOGRAM_LEFT,
    sh.PARALLELOGRAM_RIGHT
)
FOR_METAL_NOISE = {ok.BLUR, ok.NOISE_AMOUNT, ok.SPECK_NOISE}
FOR_RESIZE_LABEL = ok.COVER, ok.FILLED, ok.LOCKED, ok.TRIM
FOR_SHAPE_COUNT = {ok.ECS, ok.HORZ_COUNT, ok.VERT_COUNT}
PLAQUE_COLOR = dc.COLOR, dc.NETTING
SHOW_SAMPLES = {
    ok.BUMP,
    ok.GRADIENT_TYPE,
    ok.IRR,
    ok.MODE,
    ok.OPACITY,
    ok.ANGLE
}
SWITCH_VISIBLE = ok.PER_CELL, ok.PRESET, ok.SWITCH
pdb = fu.pdb


def all_visible(*_):
    """
    Let the caller know that the Preset has no hidden key.

    Return: set
        Is empty.
    """
    return set()


def do_per_cell(group, q):
    """
    Update the group's visibility.

    group: AnyGroup
        Has options.
    """
    if group and ok.PER_CELL in group.widget_d:
        if group.render_key not in sk.PER_CELL_GROUP:
            q.update({ok.PER_CELL})
        else:
            g = group.widget_d[ok.PER_CELL].button

            if not group.widget_d[ok.PER_CELL].check_button.get_a():
                g.hide()
            else:
                g.show()


def get_hidden_nail_polish(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = set()
    n = d[ok.FRAME_TYPE]

    if n == ff.BACKDROP:
        q.update(([(ok.IPB, (ok.IMAGE_CHOICE, ok.PATTERN))]))

    elif n != ff.IMAGE:
        q.update(([(ok.IPB, (ok.IMAGE_CHOICE,))]))

    elif n != ff.PATTERN:
        q.update(([(ok.IPB, (ok.PATTERN,))]))
    return q


def get_hidden_background(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = set()

    n = d[ok.BACKDROP_TYPE]

    if n != bs.GRADIENT:
        q.update(FOR_BACKDROP)
        q.update(([(ok.GRR, (ok.GRADIENT,))]))

    else:
        q.update(([(ok.GRR, ())]))

    if n != bs.PLASMA:
        q.update({ok.SEED})
    return q


def get_hidden_border(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        with option value

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden options, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        # hidden options, 'q'
        q = set()

        n = d[ok.TYPE_DECO]

        if n != dc.GRADIENT:
            q.update(FOR_GRADIENT)

        else:
            # Shape-burst-type gradients radiate from
            # the center, so there is no angle.
            if (
                d[ok.GRADIENT_TYPE]
                in fg.SHAPE_BURST
            ):
                q.update({ok.GRADIENT_ANGLE})

        if n not in (dc.COLOR, dc.NETTING):
            q.update({ok.COLOR_1})

        if n != dc.IMAGE:
            q.update({ok.IMAGE_CHOICE})

        if n != dc.PATTERN:
            q.update({ok.PATTERN})

        if n != dc.PLASMA:
            q.update({ok.SEED})

        if n != dc.NETTING:
            q.update({ok.NET_LINE_W, ok.NLS})

        if n not in FOR_DECO_BLUR:
            q.update({ok.BLUR})
        if branch_k == ny.FACE:
            q.update({ok.OBEY_MARGINS})
            q.update(([(ok.BFR, (ok.FRAME,))]))

    do_per_cell(group, q)
    return q


def get_hidden_box(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = set()

    n = d[ok.GRID_TYPE]

    if n != gr.CELL_COUNT:
        q.update(FOR_CELL_COUNT)

    if n != gr.CELL_SIZE:
        q.update(FOR_CELL_SIZE)

    if n != gr.SHAPE_COUNT:
        q.update(FOR_BOX_SHAPE_COUNT)

    if n not in (gr.CELL_SIZE, gr.SHAPE_COUNT):
        q.update({ok.PIN_CORNER})
    return q


def get_hidden_bump(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = {i for i in d if i not in SWITCH_VISIBLE}

    if d[ok.SWITCH]:
        q = set()
        n = d[ok.BUMP_TYPE]

        if n not in fb.HAS_NOISE:
            q.update({ok.NOISE})

        if n != fb.CLOTH:
            q.update({ok.BLUR_X, ok.BLUR_Y})
        if n not in fb.HAS_INVERT:
            q.update({ok.INVERT})
    return q


def get_hidden_caption(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        n = d[ok.TYPE_DECO]

        if n == pt.TEXT and not d[ok.TEXT]:
            q -= {ok.TYPE_DECO, ok.TEXT}
        else:
            # Widget key of Widget to hide, 'q'
            q = set()

            if n != pt.TEXT:
                q.update({ok.TEXT})

            if n != pt.SEQUENCE_NUMBER:
                q.update({ok.START_NUMBER})

            if n not in (pt.SEQUENCE_NUMBER, pt.IMAGE_NAME):
                q.update({ok.LTR})

            # For the Box Model, Face Caption doesn't have
            # the Clip-to-Cell option, but the Cell Caption
            # option group have the Clip-to-Cell option.
            if branch_k == ny.FACE:
                q.update({ok.OCR})

    do_per_cell(group, q)
    return q


def get_hidden_cell(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {option key: widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = set()

    n = d[ok.CELL_SHAPE]

    if n not in FOR_PARALLELOGRAM:
        q.update({ok.PARALLELOGRAM_SCALE})
    return q


def get_hidden_ceramic_chip(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = set()

    if d[ok.GREY_SCALE]:
        q.update({ok.COLOR_1})
    return q


def get_hidden_frame_over(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = {i for i in d if i not in (ok.PRESET, ok.SRR)}

    n = d[ok.FRAME_OVER]

    if n == "None":
        q -= {ok.FRAME_OVER}

    else:
        q = set()
        q1 = gradient_q = ()
        color_q = ()
        n = d[ok.FRAME_STYLE]

        if n != ff.PLASMA:
            q.update({ok.SEED})

        if n != ff.COLOR:
            color_q += (ok.COLOR_1,)

        else:
            q.update({ok.BLUR})

        if n != ff.IMAGE:
            color_q += (ok.IMAGE_CHOICE,)

        if n == ff.AS_IS:
            q.update({ok.FSM})

        if n != ff.GRADIENT:
            q.update({
                ok.GRADIENT_ANGLE,
                ok.GRADIENT_TYPE
            })
            gradient_q = (ok.GRADIENT,)
        else:
            if d[ok.GRADIENT_TYPE] in fg.SHAPE_BURST:
                q.update({ok.GRADIENT_ANGLE})

        q.update(([(ok.GBRW, gradient_q)]))
        q.update(([(ok.CIR, color_q)]))
        q.update(([(ok.SRR, q1)]))
    return q


def get_hidden_fringe(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        # Widget key of Widget to hide, 'q'
        q = set()

        clip_q = ()
        n = d[ok.TYPE_DECO]

        if n != dc.GRADIENT:
            q.update(FOR_GRADIENT)

        else:
            # Shape-burst gradients radiate from the center.
            if d[ok.GRADIENT_TYPE] in fg.SHAPE_BURST:
                q.update({ok.GRADIENT_ANGLE})

        if n != dc.PLASMA:
            q.update({ok.SEED})

        if n != dc.IMAGE:
            q.update({ok.IMAGE_CHOICE})

        if n != dc.MULTI_COLOR:
            q.update({ok.COLOR_6, ok.COLOR_COUNT})

        else:
            q.update(([(ok.COLOR_6, d[ok.COLOR_COUNT])]))

        if n != dc.PATTERN:
            q.update({ok.PATTERN})

        if n != dc.NETTING:
            q.update({ok.NET_LINE_W, ok.NLS})

        if n not in (dc.COLOR, dc.NETTING):
            q.update({ok.COLOR_1})

        if n not in FOR_DECO_BLUR:
            q.update({ok.BLUR})

        if branch_k == ny.FACE:
            q.update({ok.OCR})
            q.update(([(ok.BBF, (ok.FRAME,))]))
        q.update(([(ok.OCR, clip_q)]))

    do_per_cell(group, q)
    return q


def get_hidden_galactic_field(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        not used

    Return: set
        hidden Widget key
    """
    q = set()

    if d[ok.GRADIENT_TYPE] in fg.SHAPE_BURST:
        q.update(bs.POINT_KEY)
        if ok.GRADIENT_ANGLE in d:
            q.update({ok.GRADIENT_ANGLE})
    return q


def get_hidden_gradient(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = set()

    if d[ok.GRADIENT_TYPE] in fg.SHAPE_BURST:
        q.update(bs.POINT_KEY)
        if ok.GRADIENT_ANGLE in d:
            q.update({ok.GRADIENT_ANGLE})
    return q


def get_hidden_gradient_light(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    if not d[ok.SWITCH]:
        # Widget key of Widget to hide, 'q'
        q = {i for i in d if i != ok.SWITCH}

    else:
        q = set()
        if not d[ok.SWITCH]:
            if d[ok.GRADIENT_TYPE] in fg.SHAPE_BURST:
                q.update({ok.END_X, ok.END_Y, ok.START_X, ok.START_Y})
    return q


def get_hidden_image(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        if not d[ok.IRRW][ok.IMAGE_CHOICE][ok.SWITCH]:
            q -= {ok.IRRW}
            q.update(([(ok.IRRW, (ok.RESIZE,))]))
        else:
            q = set()

            q.update(([(ok.IRRW, ())]))

            if branch_k == ny.FACE:
                q.update({ok.ROTATION})
                q.update(([(ok.MRR, (ok.FRAME,))]))
            else:
                q.update(([(ok.MRR, ())]))

    do_per_cell(group, q)
    return q


def get_hidden_image_choice(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        not used

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = {i for i in d if i not in (ok.SWITCH, ok.PRESET)}

    if d[ok.SWITCH]:
        n = d[ok.IMAGE_SOURCE]
        q -= {n, ok.AUTOCROP, ok.AS_LAYERS, ok.IMAGE_SOURCE, ok.SLICE}
        is_slice = True

        if d[ok.AS_LAYERS]:
            q -= {ok.LAYER_ORDER}

        if n == ok.FOLDER:
            q -= {ok.FILTER, ok.FOLDER_ORDER, ok.RANDOM_ORDER}
            if d[ok.RANDOM_ORDER]:
                q -= {ok.SEED}
                is_slice = False
                q.update({ok.AS_LAYERS, ok.FOLDER_ORDER, ok.SLICE})
        if is_slice and d[ok.SLICE]:
            q -= {ok.COLUMN_SLICE, ok.ROW_SLICE, ok.SLICE_ORDER}
    return q


def get_hidden_image_gradient(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = set()

    n = d[ok.SAMPLE_VECTOR]

    if n != bs.HORIZONTAL:
        q.update({ok.START_Y})

    if n != bs.VERTICAL:
        q.update({ok.START_X})

    if n != bs.DIAGONAL:
        q.update({ok.DIAGONAL_ROTATION})

    # the Show Samples option, '1'
    if d[ok.PREVIEW_MODE] == 1:
        q.update(SHOW_SAMPLES)
    return q


def get_hidden_margin(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        with option value

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    q = {i for i in d if i not in (ok.PER_CELL, ok.SWITCH)}

    if d[ok.SWITCH]:
        q = set()

    do_per_cell(group, q)
    return q


def get_hidden_mask(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = {i for i in d if i != ok.SWITCH}

    if d[ok.SWITCH]:
        n = d[ok.MASK_TYPE]

        if n == ms.TEXT and not d[ok.TEXT]:
            q -= {ok.MASK_TYPE, ok.TEXT}
        else:
            # Widget key of Widget to hide, 'q'
            q = set()

            for k, a in FOR_MASK_D.items():
                if n != k:
                    if isinstance(a, tuple):
                        q.update(a)
                    else:
                        q.update({a})

            if n not in (ms.PARALLELOGRAM_LEFT, ms.PARALLELOGRAM_RIGHT):
                q.update({ok.PARALLELOGRAM_SCALE})

            if n not in (ms.IMAGE, ms.FRINGE):
                q.update({ok.IBR})

            elif n != ms.IMAGE:
                q.update(([(ok.IBR, (ok.IMAGE_CHOICE,))]))

            elif n != ms.FRINGE:
                q.update(([(ok.IBR, (ok.BRUSH_D,))]))

            if n == ms.FRINGE:
                q.update({ok.CUT_OUT, ok.HORZ_SCALE, ok.VERT_SCALE})
            if not d[ok.FEATHER]:
                q.update({ok.STEPS})
    return q


def get_hidden_noise(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = {i for i in d if i not in SWITCH_VISIBLE}

    if d[ok.SWITCH]:
        q = set()
        q.update(
            {
                ff.INK: FOR_METAL_NOISE,
                ff.RIFT: {ok.SPECK_NOISE},
                ff.SPECK: {ok.BLUR, ok.NOISE_AMOUNT},
                ff.WATER: FOR_METAL_NOISE
            }[d[ok.NOISE_TYPE]]
        )
    return q


def get_hidden_paint_rush(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = set()

    # if not colorize
    if not d[ok.CER][ok.COLORIZE]:
        q.update(FOR_PAINT_RUSH)
    return q


def get_hidden_plaque_key(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    q = {i for i in d if i not in ALWAYS}

    if d[ok.SWITCH]:
        # Widget key of Widget to hide, 'q'
        q = set()

        n = d[ok.TYPE_DECO]

        if n != dc.IMAGE:
            q.update({ok.IMAGE_CHOICE})

        if n != dc.NETTING:
            q.update({ok.NET_LINE_W, ok.NLS})

        if n not in PLAQUE_COLOR:
            q.update({ok.COLOR_1})

        if n != dc.PATTERN:
            q.update({ok.PATTERN})

        if n != dc.GRADIENT:
            q.update(FOR_GRADIENT)

        else:
            # Shape-burst-type of gradients radiate from the center.
            if d[ok.GRADIENT_TYPE] in fg.SHAPE_BURST:
                q.update({ok.GRADIENT_ANGLE})

        if n != dc.PLASMA:
            q.update({ok.SEED})

        if n not in FOR_DECO_BLUR:
            q.update({ok.BLUR})
        if branch_k == ny.FACE:
            q.update({ok.OBEY_MARGINS})
            q.update(([(ok.MBF, (ok.FRAME,))]))

    do_per_cell(group, q)
    return q


def get_hidden_rect_pattern(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    return {(ok.COLOR_6A, d[ok.COLOR_COUNT])}


def get_hidden_resize(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = {i for i in d if i not in (ok.PRESET, ok.RESIZE_TYPE)}

    n = d[ok.RESIZE_TYPE]

    if n in FOR_RESIZE_LABEL:
        q -= {n}

    elif n == fz.CROP:
        q -= FOR_CROP

    elif n == fz.FIXED:
        q -= FOR_FIXED

    elif n == fz.FACTOR:
        q -= FOR_FACTOR
    return q


def get_hidden_shadow(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = {i for i in d if i not in (ok.INTENSITY, ok.PRESET)}

    if d[ok.INTENSITY]:
        q = set()
    return q


def get_hidden_switch(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # hidden options, 'q'
    q = {i for i in d if i not in SWITCH_VISIBLE}

    if d[ok.SWITCH]:
        q = set()

    do_per_cell(group, q)
    return q


def get_hidden_table(group, d, branch_k):
    """
    Get the key hidden Widget given the options.

    group: AnyGroup
        Has node-key, step-key.

    d: dict
        Preset
        {Option key: Widget value}

    branch_k: string
        Identify branch.

    Return: set
        hidden Widget key
    """
    # Widget key of Widget to hide, 'q'
    q = set()

    n = d[ok.GRID_TYPE]

    if n == gr.SHAPE_COUNT:
        n1 = d[ok.ECS]

    else:
        n1 = d[ok.CELL_SHAPE]

    if n != gr.CELL_COUNT:
        q.update(FOR_CELL_COUNT)

    if n != gr.CELL_SIZE:
        q.update(FOR_CELL_SIZE)

    if n != gr.SHAPE_COUNT:
        q.update(FOR_SHAPE_COUNT)

    if n not in (gr.CELL_COUNT, gr.CELL_SIZE):
        q.update({ok.CELL_SHAPE})

    if n1 not in sh.DOUBLE:
        q.update({ok.FCI})

    if n1 not in FOR_PARALLELOGRAM:
        q.update({ok.PARALLELOGRAM_SCALE})

    if n not in (gr.CELL_SIZE, gr.SHAPE_COUNT):
        q.update({ok.PIN_CORNER})

    if n != gr.CELL_COUNT or d[ok.CELL_SHAPE] != sh.RECTANGLE:
        q.update({ok.PER_CELL})

    else:
        # The Per Cell option is for merging cells
        # is pointless if there is only one cell.
        if (
            d[ok.ROW_COUNT] == 1
            and d[ok.COLUMN_COUNT] == 1
        ):
            q.update({ok.PER_CELL})

    if ok.PER_CELL not in q:
        if group:
            e = group.widget_d
            open_button = e[ok.PER_CELL].button

            if not e[ok.PER_CELL].check_button.get_a():
                open_button.hide()
            else:
                open_button.show()
    return q


def hide_option(group):
    """
    Set option visibility.

    group: AnyGroup
        Has options.
    """
    d = {}
    e = group.widget_d
    branch_k = None
    if group:
        if group.render_key and len(group.render_key) > 2:
            branch_k = group.render_key[2]

        # Convert Widget dict to a Preset value dict.
        for k in e:
            if k != ok.PRESET:
                d[k] = e[k].get_a()

        set_visibility(e, HIDDEN_KEY[group.item.key](group, d, branch_k))


def make_tooltip(key, d, tooltip, indent, tip_count):
    """
    Make a tooltip for a Preset.

    key: string
        Identify Preset.

    d: dict
        Preset

    tooltip: string
        WIP

    indent: int
        Is the count of the tab prefix.

    tip_count: int
        Is the number of lines, or rows, in the tooltip.

    Return: string
        tooltip
    """
    n = '\t' * indent if indent else " "

    if tip_count:
        n = '\n' + n

    k = key.split(",")[0] if isinstance(key, basestring) else key[-1]
    tooltip += n + k + " "

    indent += 1
    tip_count += 1

    if (
        (ok.SWITCH in d and not d[ok.SWITCH]) or
        (sk.SHADOW_SWITCH in d and not d[sk.SHADOW_SWITCH][ok.SWITCH])
    ):
        n = '\t' * indent if indent else " "
        return tooltip + '\n' + n + "Off "

    default_d = The.preset.get_init_d(key)

    if not default_d:
        key = get_option_list_key(d)
        d = d[key]
        default_d = The.preset.get_init_d(key)
        tooltip += '\n' + '\t' * indent + key + " "
        indent += 1
        tip_count += 1

    if default_d and wk.SUB in default_d:
        default_d = default_d[wk.SUB]

    # Need to get visible Widget. Hidden Widget is irrelevant.
    if key in HIDDEN_KEY:
        hidden_q = HIDDEN_KEY[key](None, d, None).union((ok.SWITCH,))
        visible_q = [i for i in d if i not in hidden_q]
        hidden_d = {i[0]: i[1] for i in hidden_q if isinstance(i, tuple)}

        for i in default_d:
            if i in visible_q:
                if wk.TIPPER in default_d[i]:
                    tooltip += '\n'
                    tooltip += default_d[i][wk.TIPPER](
                        d, i, indent, default_d[i]
                    )
                    tip_count += 1
                else:
                    if wk.SUB in default_d[i]:
                        # row
                        is_hide = i in hidden_d
                        e = default_d[i][wk.SUB]
                        for i1 in e:
                            is_show = not is_hide or i1 not in hidden_d[i]
                            if is_show and i1 in d[i]:
                                a = d[i][i1]
                                if isinstance(a, dict):
                                    tooltip = make_tooltip(
                                        i1,
                                        a,
                                        tooltip,
                                        indent,
                                        tip_count
                                    )
                                else:
                                    if wk.TIPPER in e[i1]:
                                        tooltip += '\n'
                                        tooltip += e[i1][wk.TIPPER](
                                            d[i], i1, indent, e[i1]
                                        )
                    else:
                        if isinstance(d[i], dict) and i in HIDDEN_KEY:
                            tooltip = make_tooltip(
                                i,
                                d[i],
                                tooltip,
                                indent,
                                tip_count
                            )
    return tooltip


def set_visibility(d, q):
    """
    Set Widget visibility for an option group.

    d: dict
        option group Widget

    q: set
        of Widget key of Widgets to hide
    """
    g = None
    q1 = {i for i in d.keys()} - q

    # Ensure that common Widget types are always showing.
    q1.update(COMMON_FORMAT)

    for i, g in d.items():
        g.show() if i in q1 else g.hide()

    for i in q:
        if isinstance(i, tuple):
            d[i[0]].update_visibility(i[1])
    if g:
        g.roller_win.resize()


# Are Preset hidden key function.
HIDDEN_KEY = {
    by.GALACTIC_FIELD: get_hidden_galactic_field,
    by.GRADIENT_FILL: get_hidden_gradient,
    by.IMAGE_GRADIENT: get_hidden_image_gradient,
    by.RECT_PATTERN: get_hidden_rect_pattern,
    ek.CERAMIC_CHIP: get_hidden_ceramic_chip,
    ek.FRAME_OVER: get_hidden_frame_over,
    ek.NAIL_POLISH: get_hidden_nail_polish,
    ek.PAINT_RUSH: get_hidden_paint_rush,
    gk.BORDER: get_hidden_border,
    gk.CAPTION: get_hidden_caption,
    gk.FRINGE: get_hidden_fringe,
    gk.GRADIENT_LIGHT: get_hidden_gradient_light,
    gk.IMAGE: get_hidden_image,
    gk.INNER_SHADOW: get_hidden_shadow,
    gk.MARGIN: get_hidden_margin,
    gk.PLAQUE: get_hidden_plaque_key,
    gk.SHADOW_1: get_hidden_shadow,
    gk.SHADOW_2: get_hidden_shadow,
    gk.SHIFT: get_hidden_switch,
    gk.TYPE_BOX: get_hidden_box,
    gk.TYPE_CELL: get_hidden_cell,
    gk.TYPE_STACK: get_hidden_cell,
    gk.TYPE_TABLE: get_hidden_table,
    ok.BACKDROP_STYLE: all_visible,
    ok.BACKGROUND: get_hidden_background,
    ok.BRUSH_D: all_visible,
    ok.BUMP: get_hidden_bump,
    ok.FRAME_METAL: all_visible,
    ok.IMAGE_CHOICE: get_hidden_image_choice,
    ok.INFLUENCE: all_visible,
    ok.MASK: get_hidden_mask,
    ok.NOISE_D: get_hidden_noise,
    ok.RESIZE: get_hidden_resize,
    ok.STRIPE: get_hidden_switch,
    ok.SHADOW: all_visible,
    sk.INNER_SHADOW: get_hidden_shadow,
    sk.SHADOW_1: get_hidden_shadow,
    sk.SHADOW_2: get_hidden_shadow
}

HIDDEN_KEY.update({k: all_visible for k in by.KEY_LIST if k not in HIDDEN_KEY})
HIDDEN_KEY.update({k: all_visible for k in ek.KEY_LIST if k not in HIDDEN_KEY})
