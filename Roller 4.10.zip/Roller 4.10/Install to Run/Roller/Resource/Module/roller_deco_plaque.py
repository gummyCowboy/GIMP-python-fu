#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    finish_backed,
    make_main_face_mask,
    make_cell_face_mask,
    make_deco_material,
    make_sel_mask,
    prep_backed,
    ready_canvas_rect,
    ready_shape,
    test_image,
    transform_foam
)
from roller_fu import load_selection, verify_layer_group, select_shape
from roller_view_real import make_group
import gimpfu as fu

PLAN_COLOR_D = {
    ny.CELL: fy.CELL_PLAQUE_COLOR,
    ny.CANVAS: fy.CANVAS_PLAQUE_COLOR,
    ny.FACE: fy.FACE_PLAQUE_COLOR
}
pdb = fu.pdb


def do(v, maya, make):
    """
    Create Plaque for a navigation branch.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    d = maya.value_d

    if not v.x:
        # Preserve.
        type_deco = d[ok.TYPE_DECO]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE_DECO] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = PLAN_COLOR_D[maya.any_group.render_key[-2]]

    v.deco.type_ = d[ok.TYPE_DECO]
    z = make(v, maya)

    if not v.x:
        # Restore.
        d[ok.TYPE_DECO] = type_deco
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_main_cell(v, maya):
    """
    Draw Per Cell Plaque.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_material)


def do_main_face(v, maya):
    """
    Draw Face Plaque for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_face_material)


def do_canvas(v, maya):
    """
    Draw Canvas-branch Plaque.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_canvas_material)


def do_cell(v, maya):
    """
    Draw Plaque for Per Cell.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_material)


def do_face(v, maya):
    """
    Draw Per Cell Face Plaque.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_face_material)


def i_make_cell_face_mask(v, maya):
    """
    Apply the Mask option to a Per cell Face.

    v: View
    maya: Maya
    Return: mask layer or None
    """
    return make_cell_face_mask(
        v, maya, maya.value_d[ok.MBF][ok.MASK]
    )


def i_make_main_face_mask(v, maya):
    """
    Apply Mask to Plaque Face main option settings.

    v: View
    maya: Maya
    Return: mask layer or None
    """
    return make_main_face_mask(
        v, maya, maya.value_d[ok.MBF][ok.MASK]
    )


def make_canvas_material(v, maya):
    """
    Draw Canvas Plaque material.

    v: View
    maya: Maya
    Return: layer or None
        with Plaque material
    """
    if test_image(v, maya):
        prep_backed(v, maya, maya.group)
        ready_canvas_rect(v, maya)

        z = make_deco_material(v, maya, maya.group)

        finish_backed(v)
        return z


def make_cell_face_material(v, maya):
    """
    Make Plaque for Per Cell Face.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    parent = maya.group
    group = make_group(v, "Material", parent, offset=len(parent.layers))

    prep_backed(v, maya, group)
    make_face_material(v, maya, group)
    finish_backed(v)
    return verify_layer_group(group)


def make_cell_material(v, maya):
    """
    Make Plaque for a cell.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    if test_image(v, maya):
        prep_backed(v, maya, maya.group)
        ready_shape(v, maya)

        z = make_deco_material(v, maya, maya.group)

        finish_backed(v)
        return z


def make_face_material(v, maya, group):
    """
    Make Plaque for Face.

    v: View
    maya: Maya
    group: layer group
        Is the destination of Face layer output.
    """
    is_color = False
    r, c = maya.r_c
    model = maya.model

    if v.deco.type_ == dc.IMAGE:
        face_image_q = maya.get_image((r, c))

    elif v.deco.type_ in (dc.AVERAGE_COLOR, dc.COLOR):
        is_color = True

    # three faces, '3'
    for face_x in range(3):
        arg = r, c, face_x
        go = True

        if v.deco.type_ == dc.IMAGE:
            go = v.deco.image = face_image_q[face_x]
        if go:
            maya.rect = model.get_face_rect(*arg)
            foam = model.get_face_foam(*arg)

            if is_color:
                v.deco.shape = model.get_face_form(*arg)

            else:
                x, y, w, h = maya.rect = model.get_face_rect(*arg)
                x1, y1 = x + w, y + h
                v.deco.shape = x, y, x1, y, x1, y1, x, y1

            select_shape(v.j, v.deco.shape)

            z = make_deco_material(v, maya, group)
            if z and not is_color:
                transform_foam(v, maya.rect, z, foam)


def make_main_face_material(v, maya):
    """
    Create Plaque Face for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    parent = maya.group
    group = make_group(v, "Material", parent, offset=len(parent.layers))

    prep_backed(v, maya, group)

    for r, c in maya.main_cell_q:
        maya.r_c = r, c
        make_face_material(v, maya, group)

    finish_backed(v)
    return verify_layer_group(group)


def make_main_material(v, maya):
    """
    Create Plaque for the Cell-branch main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    def _do_average_color():
        _parent = maya.group
        _group = make_group(v, "Material", _parent, offset=len(_parent.layers))

        prep_backed(v, maya, _group)

        for _r, _c in maya.main_cell_q:
            maya.r_c = _r, _c

            ready_shape(v, maya)
            make_deco_material(v, maya, _group)

        finish_backed(v)
        return verify_layer_group(_group)

    def _do_one_material():
        _z = None

        prep_backed(v, maya, maya.group)

        # Create a single selection.
        # Image type is not one material, so there's no image check.
        pdb.gimp_selection_none(j)

        for _r, _c in maya.main_cell_q:
            maya.r_c = _r, _c
            ready_shape(v, maya, option=fu.CHANNEL_OP_ADD)

        if test_image(v, maya):
            _z = make_deco_material(v, maya, maya.group)

        finish_backed(v)
        return _z

    def _do_many_material():
        """
        Inside a group, make a layer with its own material for each
        cell. Collapse the group and return the resulting layer.
        """
        _parent = maya.group
        _group = make_group(v, "Material", _parent, offset=len(_parent.layers))

        for _r, _c in maya.main_cell_q:
            maya.r_c = _r, _c
            if test_image(v, maya):
                ready_shape(v, maya)
                make_deco_material(v, maya, _group)
        return verify_layer_group(_group)

    j = v.j

    if v.deco.type_ == dc.AVERAGE_COLOR:
        return _do_average_color()

    elif v.deco.type_ not in dc.PER_CELL_TYPE:
        # All the Plaque is the same
        # material and is applied one time.
        return _do_one_material()
    else:
        # All the Plaque is the same material,
        # but applied cell-by-cell.
        return _do_many_material()


def mask_main_cell(v, maya):
    """
    Mask a Plaque layer from the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        mask
    """
    j = v.j
    z = maya.matter
    d = maya.value_d
    sel = mask = None
    mask_d = d[ok.MBF][ok.MASK]

    pdb.gimp_selection_none(j)

    for r_c in maya.main_cell_q:
        maya.r_c = r_c
        ready_shape(v, maya)

        if not pdb.gimp_selection_is_empty(j):
            make_sel_mask(v, maya, mask_d)

        if sel:
            load_selection(j, sel, option=fu.CHANNEL_OP_ADD)
            pdb.gimp_image_remove_channel(j, sel)
        sel = pdb.gimp_selection_save(j)

    if sel:
        load_selection(j, sel)
        pdb.gimp_image_remove_channel(j, sel)
    if not pdb.gimp_selection_is_empty(j):
        mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)
        pdb.gimp_layer_add_mask(z, mask)
    return mask
