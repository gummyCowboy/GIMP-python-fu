#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clear_inverse_selection,
    clone_layer,
    color_fill_selection,
    make_layer_group,
    merge_layer,
    merge_layer_group,
    remove_z,
    select_item
)
from roller_maya_style import Style, make_background
from roller_one_gegl import spread
from roller_view_hub import (
    fill_with_clipboard, get_average_color, make_cube_pattern
)
from roller_view_real import add_sub_base_group, add_wip_below, finish_style
import gimpfu as fu

pdb = fu.pdb

# Made of x, y pairs that range from .0 to 1..
CURVES = (
    # one
    (
        .0, .0,
        .4, .1,
        .8, .8,
        1., 1.
    ),

    # two
    (
        .0, .0,
        .2, .0,
        .5, 1.,
        .75, 1.,
        1., .0
    ),

    # three
    (
        .0, .0,
        .25, 1.,
        .5, 1.,
        .8, .0,
        1., .0
    ),

    # four
    (
        .0, 1.,
        .25, 1.,
        .55, .0,
        1., .0
    )
)


def draw_layer(v, j, z, d, layer_num):
    """
    There are four layers, each having a different pattern and
    value range. Each pattern is a cube, but differs by scale.
    The value range is determined by the CURVES settings.

    j: GIMP image
        Is render.

    z: layer
        Backdrop Image copy

    d: dict
        Stone Age Preset

    layer_num: int
        distinguish range and type
    """
    # receiving layer, 'z1'
    z1 = clone_layer(z, n="Curves")

    # layer with the average color value, 'z2'
    z2 = clone_layer(z, n="Color")

    pdb.gimp_drawable_curves_spline(
        z1,
        fu.HISTOGRAM_VALUE,
        len(CURVES[layer_num]),
        CURVES[layer_num]
    )

    # Erase the black.
    pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

    # layer to receive symbol and average color, 'z'
    z = clone_layer(z, n="{} of 4".format(str(layer_num + 1)))
    z.mode = fu.LAYER_MODE_MULTIPLY

    make_cube_pattern(
        d[ok.PATTERN_SIZE] * (layer_num + 1),
        ((255, 255, 255), (187, 187, 187), (127, 127, 127)),
        d[ok.FLIP_V]
    )
    fill_with_clipboard(z)
    select_item(z1)
    clear_inverse_selection(z)
    select_item(z1)
    clear_inverse_selection(z2)

    # Get the average color to fill the layer.
    avg_color = get_average_color(z2)

    # Fill existing pixels with the average
    # color using their material selection.
    color_layer = add_wip_below(v, z)

    select_item(z)
    color_fill_selection(color_layer, avg_color)
    merge_layer(z)
    remove_z(z1)
    remove_z(z2)


def make_style(v, maya):
    """
    Make a style layer.

    v: View
    maya: StoneAge
    Return: layer or None
        with the style material
    """
    j = v.j
    d = maya.value_d
    z = make_background(v, maya, d)
    parent = add_sub_base_group(v, maya, z=z)
    group = make_layer_group(j, "WIP", parent=parent, z=z)

    for i in range(4):
        draw_layer(v, j, z, d, i)

    pdb.gimp_selection_none(j)
    blur_selection(z, 500)

    z = merge_layer_group(group)
    z = clone_layer(z)
    z.mode = fu.LAYER_MODE_DIFFERENCE

    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        6,
        (.0, .0, .0431, .3411, 1., 1.)
    )

    arg = (15, 10) if j.width > j.height else (10, 15)

    spread(z, *arg)
    return finish_style(merge_layer_group(parent), "Stone Age")


class StoneAge(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BBR

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        self.init_background(make_style, *q, **d)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BBR][ok.BACKGROUND][ok.BACKDROP_TYPE] == bs.BACKDROP_IMAGE
        super(StoneAge, self).do(v, d, is_change)
