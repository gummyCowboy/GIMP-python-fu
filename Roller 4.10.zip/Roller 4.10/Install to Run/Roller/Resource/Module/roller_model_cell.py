#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Model as md, Option as ok
from roller_model_cell_branch import CellBranch
from roller_model_goo import Goo
from roller_polygon import CELL_SHAPE_D, SHEAR_D
import gimpfu as fu

pdb = fu.pdb


class Cell(CellBranch):
    """Is a single cell Model."""
    model_type = md.CELL

    def __init__(self, model_name):
        """
        model_name: string
            Identify the model.
        """
        CellBranch.__init__(self, model_name)
        self.division = 1, 1
        self.cell_q = [(0, 0)]
        self.goo_d = {(0, 0): Goo((0, 0))}

    def calc_division(self, *_):
        """Cell's division doesn't change."""
        return

    def init_cell_q(self, d):
        """
        Cell's list of cell index doesn't change.

        d: dict
            Cell Type dict
        """
        return

    def init_model_cell(self, d):
        """
        Set the cell, merged, and plaque value.

        d: dict
            Cell Type Preset
            {Option key: value}

        Return: dict
            {cell key: [Plan vote, Work vote]}
            Each vote is a vote for change.
        """
        a = self.goo_d[(0, 0)] = Goo((0, 0))
        a.cell.rect = a.merged.rect = self.rectangle
        p = CELL_SHAPE_D.get(self.cell_shape)
        a.form = p(a.cell) if p else \
            SHEAR_D[self.cell_shape](a.cell, d[ok.PARALLELOGRAM_SCALE])
        return {(0, 0): self.past.did_rectangle(self.rectangle)}
