#!/usr/bin/env python
# -*- coding: utf-8 -*-
from bisect import bisect
from roller_constant_for import Shape as sh, Signal as si, Triangle as ft
from roller_constant_key import (
    Group as gk, Item as ie, Option as ok, Step as sk
)
from roller_model_goo import Goo
from roller_polygon import CELL_SHAPE_D, SHEAR_D, what_is_inverse_triangle
from roller_fu import make_layer_group, validate_layer
from roller_one_the import The
from roller_polygon_circle import GridCircle
from roller_polygon_rhombus import GridRhombus
from roller_polygon_ellipse_horz import EllipseHorz
from roller_polygon_ellipse_vert import EllipseVert
from roller_polygon_hexagon import Hexagon
from roller_polygon_hexagon_truncated import HexagonTruncated
from roller_polygon_octagon import GridOctagon
from roller_polygon_octagon_double import GridOctagonDouble
from roller_polygon_parallelogram import Parallelogram
from roller_polygon_parallelogram_alt import ParallelogramAlt
from roller_polygon_rect import GridRect
from roller_polygon_triangle_horz import TriangleHorz
from roller_polygon_triangle_vert import TriangleVert
from roller_view_preset import calc_margin, calc_shift_rect
from roller_view_step import find_cell_margin, get_cell_shift, get_model_branch
import gimpfu as fu
import gobject

# Is ordered by a chain of responsibility.
# Is for Model having only a Cell branch.
CELL_CHAIN = (
    si.RECTANGLE_CHANGE,
    si.RECTANGLE_CALC,
    si.CELL_RECT_CHANGE,
    si.CELL_RECT_CALC,
    si.CELL_SHIFT_CHANGE,
    si.CELL_SHIFT_CALC,
    si.CELL_MARGIN_CHANGE,
    si.CELL_MARGIN_CALC,
    si.MODEL_DIE
)

# Is the 'z-order' of the options in the layer palette, top-to-bottom.
ORDER = gk.CAPTION, gk.IMAGE, gk.BORDER, gk.FRINGE, gk.PLAQUE

# The keys are Node item, except for 'first', which
# would be equivalent to the Model id in a navigation step key.
LAYER_D = {
    'first': (ie.FACE, ie.CELL, ie.CANVAS),
    ie.CANVAS: ORDER,
    ie.CELL: ORDER,
    ie.FACE: ORDER
}


# Convert a shape descriptor to a cell rectangle and plaque calculator.
SHAPE = {
    sh.BOX_HORZ: HexagonTruncated,
    sh.BOX_HORZ_SHEAR: HexagonTruncated,
    sh.BOX_VERT: Hexagon,
    sh.BOX_VERT_SHEAR: Hexagon,
    sh.CIRCLE_HORIZONTAL: GridCircle,
    sh.CIRCLE_VERTICAL: GridCircle,
    sh.ELLIPSE_HORIZONTAL: EllipseHorz,
    sh.ELLIPSE_VERTICAL: EllipseVert,
    sh.HEXAGON: Hexagon,
    sh.HEXAGON_SHEAR: Hexagon,
    sh.HEXAGON_TRUNCATED: HexagonTruncated,
    sh.HEXAGON_TRUNCATED_SHEAR: HexagonTruncated,
    sh.OCTAGON_DOUBLE: GridOctagonDouble,
    sh.OCTAGON_DOUBLE_SHEAR: GridOctagonDouble,
    sh.OCTAGON_SHEAR: GridOctagon,
    sh.OCTAGON: GridOctagon,
    sh.OCTAGON_SIDE_TO_SIDE: GridOctagon,
    sh.OCTAGON_SIDE_TO_SIDE_SHEAR: GridOctagon,
    sh.PARALLELOGRAM_ALT_LEFT: ParallelogramAlt,
    sh.PARALLELOGRAM_ALT_RIGHT: ParallelogramAlt,
    sh.PARALLELOGRAM_LEFT: Parallelogram,
    sh.PARALLELOGRAM_RIGHT: Parallelogram,
    sh.RECTANGLE: GridRect,
    sh.RHOMBUS: GridRhombus,
    sh.RHOMBUS_SHEAR: GridRhombus,
    sh.SQUARE: GridRect,
    ft.TRIANGLE_DOWN_SHEAR: TriangleVert,
    ft.TRIANGLE_DOWN_ISOSCELES: TriangleVert,
    ft.TRIANGLE_UP_SHEAR: TriangleVert,
    ft.TRIANGLE_UP_ISOSCELES: TriangleVert,
    ft.TRIANGLE_LEFT_SHEAR: TriangleHorz,
    ft.TRIANGLE_LEFT_ISOSCELES: TriangleHorz,
    ft.TRIANGLE_RIGHT_SHEAR: TriangleHorz,
    ft.TRIANGLE_RIGHT_ISOSCELES: TriangleHorz
}

pdb = fu.pdb


class Past(gobject.GObject, object):
    """Remember the state of Model variables from the last View run."""

    # Are signals that can be emitted by this class.
    __gsignals__ = si.PAST_D

    def __init__(self, model):
        """
        model: Model
        """
        self._goo_q = [{}, {}]
        self._division = [(0, 0), (0, 0)]

        gobject.GObject.__init__(self)

        self._model = model
        for i in (
            (si.CELL_MARGIN_VIEW, self.on_cell_margin_view),
            (si.CELL_RECT_VIEW, self.on_cell_rect_view),
            (si.CELL_SHIFT_VIEW, self.on_cell_shift_view)
        ):
            self.connect(*i)

    def _did_division(self):
        """
        Did the Model's row and column count change?

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        return [self._division[x] != self._model.division for x in range(2)]

    def did_cell(self, r_c):
        """
        Did Cell rectangle change?

        r_c: tuple
            (row, column)
            cell index
            key to cell

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_division()
        a = self._goo_q
        b = self._model.goo_d[r_c].cell.rect
        b1 = self._model.goo_d[r_c].plaque

        # Plan and Work, '2'
        for x in range(2):
            if not vote_q[x]:
                if r_c in a[x]:
                    # Goo, 'a1'
                    a1 = a[x][r_c]
                    vote_q[x] = a1.cell.rect != b or a1.plaque != b1
                else:
                    vote_q[x] = True
        return vote_q

    def did_cell_pocket(self, r_c):
        """
        Did Cell pocket change?

        r_c: tuple
            cell index

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_division()
        a = self._goo_q

        # Goo, 'b, a1'
        b = self._model.goo_d[r_c]

        for x in range(2):
            if not vote_q[x]:
                if r_c in a[x]:
                    # Goo, 'a1'
                    a1 = a[x][r_c]
                    vote_q[x] = a1.shape != b.shape
                else:
                    vote_q[x] = True
        return vote_q

    def did_cell_shift(self, r_c):
        """
        Did Cell Shift change?

        r_c: tuple
            cell index

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_division()

        a = self._goo_q
        b = self._model.goo_d[r_c]

        for x in range(2):
            if not vote_q[x]:
                if r_c in a[x]:
                    # Goo, 'a1'
                    a1 = a[x][r_c]
                    vote_q[x] = (
                        a1.plaque != b.plaque or a1.shift.rect != b.shift.rect
                    )
                else:
                    vote_q[x] = True
        return vote_q

    def did_merged(self, r_c):
        """
        Did Cell merged change?

        r_c: tuple
            zero-based cell index and key
            (row, column)

        Return: list
            [Plan vote, Work vote]
            [bool, bool] where True is changed
        """
        vote_q = self._did_division()

        a = self._goo_q
        b = self._model.goo_d[r_c]

        for x in range(2):
            if not vote_q[x]:
                if r_c in a[x]:
                    vote_q[x] = a[x][r_c].merged.rect != b.merged.rect
                else:
                    vote_q[x] = True
        return vote_q

    def on_cell_margin_view(self, _, x):
        """
        Respond to a Cell Margin view by recording its state.

        _: Past
            Sent the Signal.

        x: int
            Plan or Work index
            0 or 1
        """
        d = self._goo_q[x]

        # (row, column), Goo; 'r_c, a'
        for r_c, a in self._model.goo_d.items():
            d[r_c].pocket = a.pocket.clone()
            d[r_c].shape = a.shape

    def on_cell_rect_view(self, _, x):
        """
        Respond to a Cell Type view by recording its variables.

        _: Past
            Sent the Signal.

        x: int
            Plan or Work index
            0 or 1
        """
        self._division[x] = self._model.division
        d = self._goo_q[x] = {}

        # (row, column), Goo; 'r_c, a'
        for r_c, a in self._model.goo_d.items():
            d[r_c] = Goo(r_c)
            d[r_c].cell = a.cell.clone()
            d[r_c].merged = a.merged.clone()

    def on_cell_shift_view(self, _, x):
        """
        Respond to a Cell Shift view by recording its variables.

        _: Past
            Sent the Signal.

        x: int
            Plan or Work index
            0 or 1
        """
        d = self._goo_q[x]

        # (row, column), Goo; 'r_c, a'
        for r_c, a in self._model.goo_d.items():
            d[r_c].shift = a.shift.clone()


class CellPast(Past):
    """
    Record a Cell-branched Model's View run state for change determination.
    """
    def __init__(self, model):
        self._rectangle = [None, None]

        Past.__init__(self, model)
        self.connect(si.RECTANGLE_VIEW, self.on_rectangle_view),

    def did_rectangle(self, rectangle):
        """
        Did the Cell Rectangle change?

        pocket: Rect
            Compare with the viewed value.

        Return: list
            [Plan vote, Work vote]
            where a True vote is change
        """
        q = []

        for i in range(2):
            if self._rectangle[i]:
                q.append(rectangle != self._rectangle[i])
            else:
                q.append(True)
        return q

    def on_rectangle_view(self, _, x):
        """
        Respond to a Rectangle view by recording its state.

        _: Past
            Sent the Signal.

        x: int
            Plan or Work index
            0 or 1
        """
        self._rectangle[x] = self._model.rectangle


class Baby(gobject.GObject, object):
    """
    Accept Model type signal.
    Call from Power when the interface is idle
    and after a Preset has finished loading.
    Send Signal ordered by a chain of responsibility.
    """
    # Reference
    #   github.com/sebp/PyGObject-Tutorial/blob/master/source/objects.txt
    #   library.isr.ist.utl.pt/docs/pygtk2reference/gobject-functions.html
    #   zetcode.com/gui/pygtk/signals/
    #   stackoverflow.com/questions/66730/how-do-i-create-a-new-signal-in-pygtk

    # Are signals that can be emitted by this class.
    __gsignals__ = si.MODEL_D

    def __init__(self, chain):
        # for custom signal(s)
        gobject.GObject.__init__(self)

        self._chain = chain

        # A Signal process is dependent on the chain of responsibility
        # being processed in an orderly manner.
        # {Signal: value}
        self._diaper = {}
        The.power.carry(self)

    def feed(self, signal, arg):
        """
        Emit a Signal after removing it from the diaper.

        signal: Signal
        arg: value
        """
        if signal in self._diaper:
            self._diaper.pop(signal)
        self.emit(signal, arg)

    def give(self, k, arg):
        """
        Add a Model signal for later emission.

        k: string
            Signal type

        arg: value
        """
        self._diaper[k] = k, arg

    def press(self):
        """Clear Signal from the diaper."""
        for i in self._diaper.keys():
            if i not in self._chain:
                self._diaper.pop(i)
        while self._diaper:
            self.rock()

    def rock(self):
        """Send out a signal found in diaper."""
        q = self._diaper.keys()
        if q:
            for i in self._chain:
                if i in q:
                    signal, arg = self._diaper[i]
                    self._diaper.pop(i)
                    self.emit(signal, arg)
                    break
        return True


class Model(object):
    """Has function and variable common to sub-Model class."""

    def __init__(self, model_name, past, chain):
        """
        model_name: string
            Is a key that identifies the Model in ModelId.

        past: object
            Has function to record a snap-shot of a View run.

        chain: tuple
            of Signal ordered by a chain of responsibility
        """
        self._image_sel_d = {}
        self._caption_sel_d = {}
        self._handle_d = {}
        self.cell_q = []
        self.goo_d = {}

        # for Model group management
        # Is ordered as [Plan, Work].
        self._group_d = [{}, {}]

        self.cell_shape = self.cell_type_d = None
        self.is_alt = \
            self.is_triangle = \
            self.is_rectangle = \
            self.is_merge_cell = \
            self.is_equilateral = False

        self.division = 0, 0
        self.model_id = The.model_id.make_id(model_name, self)
        self.step_key = sk.EXTRA + (self.model_id,)
        self.past = past(self)
        self.baby = Baby(chain)

        for i, p in (
            (si.CELL_MARGIN_CHANGE, self.on_cell_margin_change),
            (si.CELL_RECT_CHANGE, self.on_cell_rect_change),
            (si.CELL_SHIFT_CHANGE, self.on_cell_shift_change),
            (si.MODEL_DIE, self.die)
        ):
            self._handle_d[self.baby.connect(i, p)] = self.baby

        The.power.emit(si.MODEL_CREATED, self)
        The.cat.render.connect(si.CLOSE_VIEW_IMAGE, self.on_close_view_image)

    def adapt_cell_shape(self, r_c):
        """
        A triangle Cell shape is inverted with every other cell.
        An alt-parallelogram shape is inverted with every odd row.

        r_c: tuple
            (row, column)
            zero-based cell index

        Return: string
            cell shape
        """
        n = self.cell_shape

        if self.is_triangle:
            if what_is_inverse_triangle(*r_c):
                return ft.INVERTED[n]
            return n

        elif self.is_alt:
            # On every odd row, switch parallelogram.
            if r_c[0] % 2:
                return sh.ALT_PARALLELOGRAM[n]
        return n

    def adapt_missing_cell_step(self, is_sequence):
        """
        Check Cell Shift and Cell Margin to see
        if its step is missing. If so, then set
        the default value for the property.

        is_sequence: bool
            If True, then the chain of responsibility
            sequence is calculated immediately.
        """
        d = get_cell_shift(self.step_key)

        if not d:
            self.set_default_shift(d, is_sequence)
            if not find_cell_margin(self.step_key):
                self.set_default_pocket(is_sequence)

    def calc_cell_pocket(self, v, d, r_c):
        """
        Calculate the pocket rectangle and shape polygon for Per Cell.

        v: View
        d: dict
            Margin Preset
            {Option key: value}

        r_c: tuple
            cell key
            (row, column)

        Return: list
            [Plan vote, Work vote]
            A True vote is vote for change.
        """
        q = calc_margin(v, d)
        is_margin = any(q)
        return self.process_pocket(is_margin, q, r_c)

    def calc_cell_shift(self, v, d, r_c):
        """
        Update the Cell Shift rectangle and plaque
        polygon for a Cell given a Shift Preset
        and a previously calculated form polygon.

        v: View
        d: dict
            Shift Preset

        r_c: tuple
            cell index; of int

        Return: list
            [Plan vote, Work vote]
            Has vote on cell's Shift change since the last View run.
        """
        x, y, w, h = calc_shift_rect(v, d)

        # Goo, 'a'
        a = self.goo_d[r_c]
        x1, y1, w1, h1 = a.merged.rect
        a.shift.rect = x + x1, y + y1, w + w1, h + h1

        if any((x, y, w, h)):
            n = self.adapt_cell_shape(r_c)
            p = CELL_SHAPE_D.get(n)
            a.plaque = p(a.shift) if p else SHEAR_D[n](
                    a.shift, self.cell_type_d[ok.PARALLELOGRAM_SCALE]
                )

        else:
            a.plaque = a.form
        return self.past.did_cell_shift(r_c)

    def calc_main_cell_pocket(self, v, arg):
        """
        Calculate the pocket rectangle and shape polygon for main Cell.

        v: View
        arg: tuple
            (Cell Margin Preset, is sequence flag)
            ({Option key: value}, bool)
        """
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        q = calc_margin(v, d)
        is_margin = any(q)
        per_cell = d[ok.PER_CELL]
        vote_d = {}

        for r_c in self.cell_q:
            if r_c in per_cell:
                vote_d[r_c] = self.calc_cell_pocket(v, per_cell[r_c], r_c)
            else:
                vote_d[r_c] = self.process_pocket(is_margin, q, r_c)
        p(si.CELL_MARGIN_CALC, vote_d)

    def calc_main_cell_shift(self, v, arg):
        """
        Update the Cell Shift rectangle for main Cell given a Shift Preset.

        v: View
        arg: tuple
            (Shift Preset, is sequence flag)
        """
        vote_d = {}
        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        per_cell = d[ok.PER_CELL]

        for r_c in self.cell_q:
            if r_c in per_cell:
                vote_d[r_c] = self.calc_cell_shift(v, per_cell[r_c], r_c)
            else:
                vote_d[r_c] = self.calc_cell_shift(v, d, r_c)

        p(si.CELL_SHIFT_CALC, vote_d)
        if not find_cell_margin(self.step_key):
            self.set_default_pocket(is_sequence)

    def create_branch(self, v, maya):
        """
        Make a path of group layer for a Model step. From the Cell step key,
        Use Node item to determine the layer's position in a relational list.

        v: View
        maya: Maya
            Has a step key.
        """
        def _get_offset(_key):
            """
            Determine the offset of a new layer group.

            _key: string
                of 'constant_key.Group'
            """
            _offset = 0

            # key prefix
            _k = k[:-1]

            if _key in LAYER_D:
                # the order of options by branch key, '_q'
                _q = LAYER_D[_key]
                if leaf in _q:
                    for _i in _q:
                        # the key for a group in the group dict', '_k1'
                        _k1 = _k + (_i,)

                        if _k1 in d:
                            _offset += 1
                        elif _i == leaf:
                            break

            else:
                # Use bisect to find the insertion point for a
                # layer name given a list of existing layer name.
                # bisect reference
                # 'stackoverflow.com/questions/11290767/how-to-find-an-index-at-
                # which-a-new-item-can-be-inserted-into-sorted-list-and-ke'
                # and
                # docs.python.org/2/library/bisect.html
                _q = [_i.name for _i in reversed(parent.layers)]
                _offset = bisect(_q, parent.name + " " + leaf)
                _offset = len(parent.layers) - _offset
            return _offset

        def _groupie():
            """
            Make a layer group.

            Return: layer group
                parent
            """
            _key = 'first' if not x else k[:x][-1]
            _a = _get_offset(_key)
            _z = d[k] = make_layer_group(
                v.j, parent.name + " " + leaf, offset=_a, parent=parent
            )
            return _z

        d = self._group_d[v.x]
        sub_step = get_model_branch(maya.step_key)

        # AnyGroup, 'a'
        a = The.helm.get_group(sk.MODEL)

        # Model layer group for Work or Plan, 'parent'
        parent = (a.plan, a.work)[v.x].get_group(self.model_id)

        for x in range(len(sub_step)):
            k = sub_step[:x + 1]
            leaf = k[-1]

            if k not in d:
                parent = _groupie()
            else:
                if not validate_layer(d[k]):
                    # The dict is out-of-sync with the View. Correct
                    # the problem by removing invalid groups.
                    for i in d.keys():
                        if not validate_layer(d[i]):
                            # goodbye group
                            d.pop(i)
                    parent = _groupie()
                else:
                    parent = d[k]
        return parent

    def die(self, _, arg):
        """
        Is part of deleting a Model. Remove some connections.

        _: Baby
            Sent the Signal.

        arg: None
        """
        for i, a in self._handle_d.items():
            a.disconnect(i)
        The.power.drop(self.baby)

    def get_caption_y(self, k):
        """
        Get a Caption Text selection.

        k: value
            key

        Return: GIMP selection or None
            for Caption Text
        """
        return self._caption_sel_d.get(k)

    def get_image_sel(self, k):
        """
        Get an image selection.

        k: value
            key to the image selection

        Return: GIMP selection reference or None
        """
        return self._image_sel_d.get(k)

    def get_main_list(self, d):
        """
        Produce a list of the main option settings' cell index.

        d: dict
            A Preset that has a Per Cell option.

        Return: list
            list of (r, c) sorted in reverse order
            [(row, column)]
        """
        per_cell = d[ok.PER_CELL]

        if per_cell:
            return [
                r_c for r_c in reversed(self.cell_q) if r_c not in per_cell
            ]
        return self.cell_q

    def get_merge_rect(self, r, c):
        """
        Get the cell rectangle from a cell's merged value.

        r, c: int
            (row, column)
            zero-based cell index

        Return: tuple
            the rectangle of the cell post merged
            x, y, w, h
        """
        return self.goo_d[(r, c)].merged.rect

    def get_equilateral_type(self):
        """
        Determine if the cell shape has equal side length.

        Return: bool
            Is true if the cell shape is equilateral.
        """
        return self.cell_shape in sh.EQUILATERAL_TYPE

    def get_plaque(self, r_c):
        """
        Get a cell's plaque value.

        r_c: tuple
            (row, column)
            zero-based cell index

        Return: tuple
            for drawing a Plaque polygon
        """
        return self.goo_d[r_c].plaque

    def get_pocket(self, r_c):
        """
        Get the cell pocket.

        r_c: tuple
            Goo key
            (row, column)
            zero-based cell index

        Return: Rect
            pocket
            the rectangle of the cell within margin
        """
        return self.goo_d[r_c].pocket.clone()

    def get_shape(self, r_c):
        """
        Get a Cell's shape tuple.

        r_c: tuple
            Goo key
            (row, column)
            zero-based cell index

        Return: object
            of shape
        """
        return self.goo_d[r_c].shape

    def get_shift_rect(self, r_c):
        """
        Get the Cell Shift rectangle.

        r_c: tuple
            Goo key
            (row, column)
            zero-based cell index

        Return: tuple
            (x, y, w, h)
            the rectangle of the shifted cell
        """
        return self.goo_d[r_c].shift.rect

    def on_cell_margin_change(self, _, arg):
        """
        Respond to change in the main Cell Margin AnyGroup.

        _: Baby
            Sent the signal.

        arg: tuple
            (Shift Preset, is sequence flag)
        """
        self.calc_main_cell_pocket(The.view, arg)

    def on_cell_rect_change(self, _, arg):
        """
        Respond to change in the Cell Type AnyGroup.

        _: Baby
            Sent the signal.

        arg: tuple
            (Cell Type Preset, is sequence flag)
            {Option key: value}
        """
        self.update_type(arg)

    def on_cell_shift_change(self, _, arg):
        """
        Respond to change in the main Cell Shift AnyGroup.

        _: Baby
            Sent the signal.

        arg: dict
            Shift Preset value
        """
        self.calc_main_cell_shift(The.view, arg)

    def on_close_view_image(self, _, arg):
        """
        If the View image closes, then Model layer groups disappear.

        _: ViewImage
            Sent the Signal

        arg: GIMP image
            that was closed
        """
        # There's no more layer groups.
        self._group_d = [{}, {}]

    def process_pocket(self, is_margin, q, r_c):
        """
        Update the pocket rectangle and shape polygon for a cell.

        is_margin: bool
            Is True if the cell has a margin.

        q: tuple
            (top, bottom, left, right) of numeric
            margin value

        r_c: tuple
            Goo key
            (row, column)
            zero-based cell index

        Return: iterable
            [Plan vote, Work vote]
            A vote is True if the pocket or shape changed value.
        """
        # Goo instance, 'a'
        a = self.goo_d[r_c]

        top, bottom, left, right = q
        n = self.adapt_cell_shape(r_c)
        x, y, w, h = a.shift.rect

        if is_margin:
            x += left
            y += top
            w = max(1, w - left - right)
            h = max(1, h - top - bottom)

        a.pocket.rect = x, y, w, h

        if is_margin:
            p = CELL_SHAPE_D.get(n)
            a.shape = p(a.pocket) if p else SHEAR_D[n](
                    a.pocket, self.cell_type_d[ok.PARALLELOGRAM_SCALE]
                )

        else:
            a.shape = a.plaque
        return self.past.did_cell_pocket(r_c)

    def reset_group_d(self):
        """Reset the layer group dict when the View image is replaced."""
        self._group_d = [{}, {}]

    def set_caption_y(self, k, q):
        """
        Save a Caption Text's properties.

        k: value
            key to the Caption selection

        q: tuple
            (position y, height of Caption text)
        """
        self._caption_sel_d[k] = q

    def set_default_pocket(self, is_sequence):
        """
        Set the Cell pocket to the Cell Shift rectangle.
        Calc the Cell shape using Cell Shift rectangle.

        is_sequence: bool
            If True, then the chained-sequence is calculated immediately.
        """
        vote_d = {}
        p = self.baby.feed if is_sequence else self.baby.give

        for r_c in self.cell_q:
            vote_d[r_c] = self.process_pocket(False, (0, 0, 0, 0), r_c)
        p(si.CELL_MARGIN_CALC, vote_d)

    def set_default_shift(self, d, is_sequence):
        """
        Set the Cell Shift to the Cell merged rectangle.
        Calc the Cell plaque using the same rectangle.

        d: dict
            Cell Shift Preset
            {Option key: value}

        is_sequence: bool
            If True, then the sequence is calculated immediately.
        """
        vote_d = {}
        v = The.view
        p = self.baby.feed if is_sequence else self.baby.give

        for r_c in self.cell_q:
            vote_d[r_c] = self.calc_cell_shift(v, d, r_c)
        p(si.CELL_SHIFT_CALC, vote_d)

    def set_image_sel(self, j, k):
        """
        Memorize an image selection.

        j: GIMP image
            Has selection.

        k: value
            key to the image selection
        """
        self._image_sel_d[k] = pdb.gimp_selection_save(j)

    def update_group(self, v, group, old_k, new_k):
        """
        Update the group key for a layer group that changed its name.

        v: View
        old_k: tuple
            key for the group before it changed

        new_k: string
            the key of the group now
        """
        d = self._group_d[v.x]
        d[new_k] = group
        d.pop(old_k)

    def update_type(self, arg):
        """
        Update common Model variable for Cell Type.

        arg: tuple
            (Cell Type Preset, is sequence flag)
            {Option key: value}

        Return: list
            [Plan vote, Work vote]
            where a True vote is change
        """
        d = self.cell_type_d = arg[0]
        self.is_equilateral = self.get_equilateral_type()
        self.is_rectangle = self.cell_shape == sh.RECTANGLE
        self.is_alt = self.cell_shape in sh.ALT_PARALLELOGRAM
        self.is_triangle = self.cell_shape in ft.TRIANGLE

        self.calc_division(d)
        self.init_cell_q(d)
        return self.init_model_cell(d)


# Register the custom signals.
gobject.type_register(Baby)
