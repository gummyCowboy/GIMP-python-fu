#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Deco as dc, Fill as fl, Gradient as fg, Mask as ms
)
from roller_constant_key import Group as gk, Option as ok
from roller_deco_mask import MASK_FUNCTION, feather_mask, rotate_mask
from roller_def import get_default_value
from roller_fu import (
    add_layer,
    blur_selection,
    clear_selection,
    clear_inverse_selection,
    clone_layer,
    color_fill_selection,
    copy_all_image,
    invert_selection,
    load_selection,
    make_layer_group,
    merge_layer_group,
    paste_layer,
    remove_z,
    select_item,
    select_rect,
    select_shape,
    shape_image,
    verify_layer
)
from roller_one_rect import Rect
from roller_view_contain import One
from roller_view_hub import (
    brush_stroke,
    get_average_color,
    get_gradient_points,
    set_fill_context,
    set_gimp_gradient,
    set_gimp_pattern
)
from roller_view_preset import combine_seed
from roller_view_real import clip_to_wip, insert_copy
import gimpfu as fu

pdb = fu.pdb


def do_average_color(v, maya, z):
    """
    Make an Average Color layer. The Average
    Color is calculated from a selection.

    v: View
    maya: Maya
        not used

    z: layer
        WIP

    Return: layer
        Has the average color.
    """
    color = get_average_color(v.deco.bg_z)

    color_fill_selection(z, color)
    return z


def do_backdrop(v, maya, z):
    """
    Make material from the background.

    v: View
    maya: Maya
    z: layer
        Has material.

    Return: layer
        Has backdrop clone.
    """
    j = v.j
    d = maya.value_d
    sel = pdb.gimp_selection_save(j)
    z1 = clone_layer(v.deco.bg_z)

    remove_z(z)
    load_selection(j, sel)

    if d[ok.BLUR]:
        blur_selection(z1, d[ok.BLUR])

    z1.name = z1.parent.name + " Material"

    clear_inverse_selection(z1)
    pdb.gimp_image_remove_channel(j, sel)
    return z1


def do_brush(v, z, d):
    """
    Paint Fringe material using a selection provided by the caller.

    v: View
    z: layer
        to receive paint

    d: dict
        Fringe Preset
        {Option key: value}
    """
    def _set_foreground_color():
        """
        Set the foreground color for the brush to use.
        Rotate through the multiple color option.
        """
        if is_multi_color:
            v.deco.color_x = v.deco.color_x + 1 \
                if v.deco.color_x < max_x else 0
            pdb.gimp_context_set_foreground(
                color_q[v.deco.color_x]
            )

    j = v.j
    e = d[ok.BBF][ok.BRUSH_D]
    callback = None
    foreground = pdb.gimp_context_get_foreground()

    combine_seed(v, e)

    if v.deco.type_ == dc.MULTI_COLOR:
        v.deco.color_x = 0
        is_multi_color = True
        color_q = d[ok.COLOR_6]
        max_x = d[ok.COLOR_COUNT] - 1
        callback = _set_foreground_color

    pdb.gimp_context_set_antialias(1)
    pdb.gimp_selection_shrink(j, d[ok.CONTRACT])

    if not pdb.gimp_selection_is_empty(j):
        pdb.gimp_context_set_opacity(e[ok.OPACITY])
        pdb.plug_in_sel2path(j, z)

        if j.active_vectors:
            for stroke in j.active_vectors.strokes:
                brush_stroke(
                    z,
                    e[ok.BRUSH],
                    e[ok.BRUSH_SIZE],
                    stroke,
                    e[ok.BRUSH_SPACING],
                    e[ok.ANGLE_JITTER],
                    callback=callback,
                    hardness=e[ok.BRUSH_HARDNESS],
                    angle=e[ok.BRUSH_ANGLE]
                )

            # Remove, from the image, the path created by 'plug_in_sel2path'.
            pdb.gimp_image_remove_vectors(j, j.active_vectors)
    pdb.gimp_context_set_foreground(foreground)


def do_color(v, maya, z):
    """
    Fill a selection with a color.

    v: View
    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with the color material
    """
    color = maya.value_d[ok.COLOR_1]

    color_fill_selection(z, color)
    return z


def do_gradient(v, maya, z):
    """
    Fill a selection with a gradient.

    v: View
    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with the gradient material
    """
    def _draw():
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(d[ok.GRADIENT_TYPE]),
            0,                 # gradient offset
            1,                 # Super sample is true.
            2,                 # super sample max depth
            .0,                # super sample threshold all
            1,                 # Dither is true.
            start_x, start_y,
            end_x, end_y
        )

    j = v.j
    d = maya.value_d
    sel = pdb.gimp_selection_save(j)

    # Begin rectangle calculation.
    # The gradient draws in a rectangle space which
    # is made by the greater bounds of the intersection
    # of the canvas rectangle and the current selection.
    x, y, w, h = maya.rect
    x1, y1, x2, y2 = pdb.gimp_selection_bounds(j)[1:]
    x = min(max(0, x), x1)
    y = min(max(0, y), y1)
    w = max(w, x2 - x1)
    h = max(h, y2 - y1)
    # End rectangle calculation.

    set_fill_context(fl.FILL_DICT)
    set_gimp_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        fu.GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(0)

    start_x, end_x, start_y, end_y =\
        get_gradient_points(d[ok.GRADIENT_ANGLE], x, y, w, h)

    select_rect(j, x, y, w, h)
    _draw()
    load_selection(j, sel)
    clear_inverse_selection(z)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_image(v, maya, z):
    """
    Fill a selection with an image.

    v: View
    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with the image material
    """
    j = v.j
    d = maya.value_d
    j1 = v.deco.image
    sel = pdb.gimp_selection_save(j)
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    w, h = x1 - x, y1 - y

    if j1:
        j2 = j1.j

        pdb.gimp_selection_none(j)
        copy_all_image(j2)

        j2 = pdb.gimp_edit_paste_as_new_image()

        shape_image(j2, w, h)

        z1 = paste_layer(z)

        pdb.gimp_layer_set_offsets(z1, x, y)

        # Resize the pasted layer.
        z = pdb.gimp_image_merge_down(z.image, z1, fu.CLIP_TO_IMAGE)

        if sel:
            load_selection(j, sel)
            clear_inverse_selection(z)
        if d[ok.BLUR]:
            select_item(z)
            if not pdb.gimp_selection_is_empty(j):
                blur_selection(z, d[ok.BLUR])

    else:
        remove_z(z)
        z = None

    if sel:
        pdb.gimp_image_remove_channel(j, sel)
    return z


def do_netting(v, maya, z):
    """
    Fill a selection with netting material.

    v: View
    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with the netting material
    """
    j = v.j
    d = maya.value_d
    w = d[ok.NLS]
    color = d[ok.COLOR_1]
    w1 = d[ok.NET_LINE_W]

    pdb.plug_in_grid(
        j, z,
        w1, w, w,
        color,
        100.,           # opacity
        w1, w, w,
        color,
        100.,           # opacity
        0, 0, 0,
        (0, 0, 0),
        0
    )
    return z


def do_pattern(v, maya, z):
    """
    Fill a selection with a pattern.

    v: View
    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with pattern
    """
    d = maya.value_d

    set_fill_context(fl.FILL_DICT)
    set_gimp_pattern(d[ok.PATTERN])
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, 0, 0)

    if d[ok.BLUR]:
        blur_selection(z, d[ok.BLUR])
    return z


def do_plasma(v, maya, z):
    """
    Fill a selection with plasma.

    v: View
    maya: Maya
    z: layer
        work-in-progress

    Return: layer
        with plasma material
    """
    j = v.j
    d = maya.value_d
    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, d[ok.SEED], 3)

    if d[ok.BLUR]:
        blur_selection(z, d[ok.BLUR])

    load_selection(j, sel)
    pdb.gimp_image_remove_channel(j, sel)
    clear_inverse_selection(z)
    return z


def finish_backed(v):
    """
    If the background was used in deco production,
    then remove the prepped background copy layer.

    v: View
    """
    if v.deco.bg_z:
        pdb.gimp_image_remove_layer(v.j, v.deco.bg_z)


def get_clip_to_cell(d):
    """
    Fetch the CLIP_TO_CELL option's value.

    d: dict
        deco Preset

    Return: int
        0 or 1
    """
    a = d.get(ok.CLIP_TO_CELL)

    if a is not None:
        return a
    return d[ok.OCR][ok.CLIP_TO_CELL]


def get_obey_margins(d):
    """
    Fetch the OBEY_MARGINS option's value. If not
    present, return True as the default deco behavior.

    d: dict
        deco Preset

    Return: int
        0 or 1
        same as bool
    """
    a = d.get(ok.OBEY_MARGINS)

    if a is not None:
        return a

    a = d.get(ok.OCR)

    if a is not None:
        return a[ok.OBEY_MARGINS]
    return 1


def make_main_face_mask(v, maya, mask_d):
    """
    Apply a Box Face mask for main.

    v: View
    maya: Maya
    mask_d: dict
        Mask Preset
        {Option key: value}

    Return: layer
        the mask
    """
    z = maya.matter
    mask = None
    j = v.j
    model = maya.model
    group = make_layer_group(
        j,
        "Mask Group",
        parent=z.parent,
        offset=len(z.parent.layers)
    )
    for r, c in maya.main_cell_q:
        # Box Face count, '3'
        for face_x in range(3):
            z1 = add_layer(j, "Mask", parent=group)
            arg = maya.r_c_x = r, c, face_x
            maya.rect = model.get_face_rect(*arg)
            w, h = maya.rect[2:]

            select_rect(j, 0, 0, w, h)
            make_sel_mask(v, maya, mask_d)
            color_fill_selection(z1, (255, 255, 255))
            transform_foam(
                v, (0, 0, w, h), z1, model.get_face_foam(*arg)
            )

    z1 = merge_layer_group(group)

    select_item(z1)

    if not pdb.gimp_selection_is_empty(j):
        mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)
        pdb.gimp_layer_add_mask(z, mask)

    remove_z(z1)
    return mask


def make_cell_face_mask(v, maya, mask_d):
    """
    Apply a Box Face mask for a cell.

    v: View
    maya: Maya
    mask_d: dict
        Mask Preset
    """
    z = maya.matter
    mask = None
    j = v.j
    model = maya.model
    group = make_layer_group(
        j,
        "Mask Group",
        parent=z.parent,
        offset=len(z.parent.layers)
    )
    r, c = maya.r_c

    # Box Face count, '3'
    for face_x in range(3):
        z1 = add_layer(j, "Mask", parent=group)
        arg = r, c, face_x
        maya.rect = model.get_face_rect(*arg)
        w, h = maya.rect[2:]

        select_rect(j, 0, 0, w, h)
        make_sel_mask(v, maya, mask_d)
        color_fill_selection(z1, (255, 255, 255))
        transform_foam(v, (0, 0, w, h), z1, model.get_face_foam(*arg))

    z1 = merge_layer_group(group)

    select_item(z1)

    if not pdb.gimp_selection_is_empty(j):
        mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)
        pdb.gimp_layer_add_mask(z, mask)

    remove_z(z1)
    return mask


def make_deco_mask(v, maya):
    """
    Mask a Plaque or an Image cell.

    v: View
    maya: Maya
    """
    z = maya.matter
    d = maya.value_d
    mask = None
    mask_d = d[maya.MASK_ROW_K][ok.MASK]
    j = v.j

    select_item(z)
    make_sel_mask(v, maya, mask_d)
    if not pdb.gimp_selection_is_empty(j):
        mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)
        pdb.gimp_layer_add_mask(z, mask)
    return mask


def make_deco_material(v, maya, group):
    """
    Produce deco layer. Set 'v.deco.type_' before calling.

    v: View
    maya: Maya
    group: layer
        Is the parent group of the deco output.

    Return: layer or None
        with material
    """
    if v.deco.type_ in ROUTE:
        if not pdb.gimp_selection_is_empty(v.j):
            return verify_layer(
                ROUTE[v.deco.type_](
                    v,
                    maya,
                    add_layer(
                        v.j,
                        group.name + " Material",
                        parent=group,
                        offset=len(group.layers)
                    )
                )
            )


def make_sel_mask(v, maya, d):
    """
    Apply a mask to a selection.

    v: View
    maya: Maya
    d: dict
        Mask Preset

    Return: state of selection
        The selection is to be a mask.
    """
    j = v.j
    mask_type = d[ok.MASK_TYPE]
    p = MASK_FUNCTION.get(mask_type)
    is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

    if is_sel:
        if p:
            e = maya.value_d[maya.MASK_ROW_K][ok.MASK]
            w, h = x1 - x, y1 - y
            w1, h1 = w * d[ok.HORZ_SCALE], h * d[ok.VERT_SCALE]
            p(
                j,
                One(
                    d=e,
                    maya=maya,
                    scale=Rect(x + (w - w1) // 2, y + (h - h1) // 2, w1, h1),
                    sel=Rect(x, y, w, h),
                )
            )
            if e[ok.CUT_OUT]:
                sel = pdb.gimp_selection_save(j)

                select_rect(j, x, y, w, h)
                load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
                pdb.gimp_image_remove_channel(j, sel)

        elif mask_type == ms.FRINGE:
            sel = pdb.gimp_selection_save(j)
            e = get_default_value(gk.FRINGE)
            e[ok.CONTRACT] = d[ok.CONTRACT]
            e[ok.BBF][ok.BRUSH_D] = d[ok.IBR][ok.BRUSH_D]
            z = add_layer(j, "Paint")

            paint(v, z, e)
            load_selection(j, sel)
            select_item(z, option=fu.CHANNEL_OP_SUBTRACT)
            pdb.gimp_image_remove_channel(j, sel)
            pdb.gimp_image_remove_layer(j, z)

        feather_mask(j, d)
        rotate_mask(j, d)
    else:
        pdb.gimp_selection_none(j)


def paint(v, z, d):
    """
    Create Fringe brush stroke.

    v: View
    z: layer
        for Fringe material

    d: dict
        Fringe Preset
    """
    j = v.j

    if not pdb.gimp_selection_is_empty(j):
        do_brush(v, z, d)
    if get_clip_to_cell(d):
        select_item(z)
        if not pdb.gimp_selection_is_empty(j):
            select_shape(j, v.deco.shape)
            invert_selection(j)
            clear_selection(z)


def prep_backed(v, maya, z):
    """
    If the deco type depends on the visible background,
    then create a copy of the background. Both main or
    Per Cell deco, expect the background copy to be set
    when their output functions are called.

    The blur behind layer is hidden because it is
    part of the background.

    v: View
    maya: Maya
        deco variety

    z: layer
        parent group to place copy
    """
    if v.deco.type_ in dc.BACKED:
        v.deco.bg_z = insert_copy(v, z, z.parent, is_hide=True)
    else:
        v.deco.bg_z = None


def ready_canvas_rect(v, maya, option=fu.CHANNEL_OP_REPLACE):
    """
    Prepare a Deco Canvas-type's rectangle and shape.

    v: View
    maya: Maya
    option: gimpfu enum or None
        If not None, the canvas' rectangle is selected.
    """
    if get_obey_margins(maya.value_d):
        x, y, w, h = maya.model.canvas_pocket.rect

    else:
        x, y, w, h = maya.model.canvas_rect

    maya.rect = x, y, w, h
    x1, y1 = x + w, y + h
    v.deco.shape = x, y, x1, y, x1, y1, x, y1
    if option:
        select_shape(v.j, v.deco.shape, option=option)


def ready_shape(v, maya, option=fu.CHANNEL_OP_REPLACE):
    """
    Set 'v.deco.shape' and 'maya.rect'. Select
    the shape when 'option' is set.

    v: View
    maya: Maya
    option: gimpfu enum or None
        If not None, then the canvas' rectangle is selected.
    """
    a = maya.model
    r_c = maya.r_c

    # An Image Preset doesn't have the OBEY_MARGINS option.
    if get_obey_margins(maya.value_d):
        # the pocket shape
        maya.rect = a.get_pocket(r_c).rect
        v.deco.shape = a.get_shape(r_c)

    else:
        maya.rect = a.get_shift_rect(r_c)
        v.deco.shape = a.get_plaque(r_c)
    if option is not None:
        select_shape(v.j, v.deco.shape, option=option)


def test_image(v, maya):
    """
    If the Deco Type is an image, determine if an
    image has been assigned. Assign 'v.deco.image'.

    v: View
    maya: Maya
    Return: bool
        Is not None if a valid image is assigned
    """
    go = True

    if v.deco.type_ == dc.IMAGE:
        go = v.deco.image = maya.get_image(maya.r_c)
    return go


def transform_foam(v, rect, z, q):
    """
    Shape rectangular material into a polygon.

    v: View
    rect: tuple
        (x, y, w, h)
        input material to transform

    z: layer
        disposable input material

    q: tuple
        x, y float series
        (topleft, top-right, bottom-left, bottom-right)

    Return: layer
        with the transformed material
    """
    select_rect(v.j, *rect)

    # Transform the selected material into a floating selection layer.
    z1 = pdb.gimp_item_transform_perspective(z, *q)

    pdb.gimp_floating_sel_to_layer(z1)
    remove_z(z)
    clip_to_wip(v, z1)
    return z1


# Use to make a Deco-type material.
ROUTE = {
    dc.AVERAGE_COLOR: do_average_color,
    dc.BACKDROP: do_backdrop,
    dc.COLOR: do_color,
    dc.GRADIENT: do_gradient,
    dc.IMAGE: do_image,
    dc.NETTING: do_netting,
    dc.PATTERN: do_pattern,
    dc.PLASMA: do_plasma
}
