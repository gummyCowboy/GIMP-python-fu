#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Shape as sh
from roller_model_face import BoxFace, make_v_face
from roller_one_rect import Rect


def bottom_arrange(q, w, h, center, a):
    a.merged = Rect(q[10], center[1], w, w)
    a.form = (
        q[10], q[11],
        q[2], center[1],
        q[6], q[7],
        q[8], q[9]
    )
    a.foam = (
        q[2], center[1],
        q[6], q[7],
        q[10], q[11],
        q[8], q[9],
    )


def left_arrange(q, w, h, center, a):
    a.merged = Rect(q[0], q[3], w, w)
    a.form = (
        q[0], q[1],
        q[2], q[3],
        center[0], q[1],
        q[10], q[11]
    )
    a.foam = (
        q[2], q[3],
        center[0], q[1],
        q[0], q[1],
        q[10], q[11]
    )


def right_arrange(q, w, h, center, a):
    a.merged = Rect(center[0], q[3], w, w)
    a.form = (
        center[0], q[1],
        q[4], q[5],
        q[6], q[7],
        q[8], q[9]
    )
    a.foam = (
        q[4], q[5],
        q[6], q[7],
        center[0], q[1],
        q[8], q[9]
    )


def top_arrange(q, w, h, center, a):
    a.merged = Rect(q[0], q[3], w, w)
    a.form = (
            q[0], q[1],
            q[2], q[3],
            q[4], q[5],
            q[2], center[1]
        )
    a.foam = (
            q[2], q[3],
            q[4], q[5],
            q[0], q[1],
            q[2], center[1]
        )


class Cap(BoxFace):
    """
    Differs from the other two faces in that it is
    not a reflection of its opposing Face.
    """

    def __init__(self, box):
        """
        box: Box
            Is the Model containing the Face.
        """
        BoxFace.__init__(self, box)

    def build_bottom(self, *q):
        bottom_arrange(*q)
        q[-1].transform = make_v_face

    def build_left(self, *q):
        left_arrange(*q)
        q[-1].transform = make_v_face

    def build_right(self, *q):
        """
        Assemble the points of a vertical Box Cap for a Mesh instance.
        """
        right_arrange(*q)
        q[-1].transform = make_v_face

    def build_top(self, *q):
        top_arrange(*q)
        q[-1].transform = make_v_face

    def update_face(self, *arg):
        """
        Calculate the shape using its pocket rectangle.

        arg: tuple
            (Face foam, Face rectangle, center point of Cell, Mesh)
        """
        {
            sh.BOTTOM: self.build_bottom,
            sh.LEFT: self.build_left,
            sh.RIGHT: self.build_right,
            sh.TOP: self.build_top
        }[self.box.box_type](*arg)
