#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame import Frame, draw_color_profile
from roller_fu import select_opaque
from roller_view_hub import PROFILE, make_polar_mask
from roller_view_real import add_top_layer
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: MetallicProfile
    Return: layer
        with the frame
    """
    j = v.j
    d = maya.value_d
    z = add_top_layer(v, maya, "Metallic Profile")
    color = 255, 255, 255
    w = d[ok.FRAME_W]
    q = PROFILE[d[ok.PROFILE]](w, *(color,))

    select_opaque(maya.cause.matter)
    draw_color_profile(z, w, q, color)
    pdb.plug_in_emboss(
        j, z,
        v.glow_ball.azimuth,
        v.glow_ball.elevation,
        2,                  # depth
        0                   # bump
    )

    z = make_polar_mask(z, is_dark=True)
    z.mode = fu.LAYER_MODE_VIVID_LIGHT
    z.opacity = 50. if d[ok.PROFILE] == ff.BAND else .10
    return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)


class MetallicProfile(Frame):
    """Create a metallic frame from a profile."""
    INFLUENCE = ok.METAL
    is_embossed = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Frame spec

        d: dict
            Frame spec
        """
        Frame.__init__(self, *q + (do_matter,), **d)
