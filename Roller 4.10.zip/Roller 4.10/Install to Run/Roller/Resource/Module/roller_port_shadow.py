#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import (
    Node as ny,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_one_the import The
from roller_port_preview import PortPreview
from roller_port_tree import SHADOW_TREE
from roller_view_step import get_branch_value_d
from roller_widget_node_panel import NodePanel


class PortShadow(PortPreview):
    """Is a display container for the Shadow SuperPreset."""
    window_key = "Shadow"

    def __init__(self, d, g):
        """
        d: dict
            Has init values.

        g: OptionButton
            Has option values.
        """
        self.is_dirt = None
        self._node_panel = NodePanel(
            {wk.ROLLER_WIN: d[wk.ROLLER_WIN]},
            self.on_port_change
        )
        PortPreview.__init__(self, d, g)

    def _draw_navigation(self, box):
        """
        Make a navigation tree.

        box: GTK container
            to receive group
        """
        box.add(self._node_panel)

        # tree dict, Node key, render key, row, column
        self._node_panel.create_node(
            SHADOW_TREE, ny.SHADOW, sk.SHADOW, None, 0
        )

        g = The.helm.get_group(sk.SHADOW_PRESET).widget_d[ok.PRESET]
        d = self.safe.get_a()
        g.set_a(d)

    def draw(self):
        """
        Draw Widget.

        g: VBox
            container for the Widgets
        """
        # Tell the Window to clean-up after the Port with 'is_dirt'.
        self.is_dirt = True

        self.draw_row((self._draw_navigation, self.draw_process))

    @staticmethod
    def get_group_value():
        """
        Use to get the Shadow SuperPreset value.

        Return: dict
            Shadow SuperPreset
        """
        return get_branch_value_d(sk.SHADOW)
