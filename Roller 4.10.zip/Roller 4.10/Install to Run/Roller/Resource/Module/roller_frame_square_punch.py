#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Metal, do_soft_metal_material
from roller_fu import (
    add_layer,
    color_fill_selection,
    color_fill_layer,
    copy_all_image,
    select_rect
)
from roller_view_hub import fill_with_clipboard
import gimpfu as fu

pdb = fu.pdb


def make_pattern(z, d):
    """
    Draw a rectangle on a rotated layer. Create a pattern
    (a black square). Use the clipboard to hold the
    pattern. Fill the provided layer with the pattern.

    z: layer
        to receive pattern

    d: dict
        Square Punch Preset
        {Option key: value}

    Return: layer
        with the pattern
    """
    side = d[ok.GAP_W]
    w = side + d[ok.LINE_W]
    j1 = pdb.gimp_image_new(w, w, fu.RGB)
    z1 = add_layer(j1, "Pattern")

    color_fill_layer(z1, (255, 255, 255))

    # A rectangle at the center of 'z1' will become a hole in the pattern.
    x = (w - side) // 2
    y = (w - side) // 2

    select_rect(j1, x, y, w, w)
    color_fill_selection(z1, (0, 0, 0))

    # Set the Clipboard Image.
    copy_all_image(j1)

    pdb.gimp_image_delete(j1)
    fill_with_clipboard(z)
    pdb.plug_in_colortoalpha(z.image, z, (0, 0, 0))
    return z


def do_matter(v, maya):
    """
    Make a border around material.

    v: View
    maya: SquarePunch
    Return: layer
        with the frame
    """
    return do_soft_metal_material(v, maya, make_pattern, "Square Punch")


class SquarePunch(Metal):
    """Is a metallic frame with rectangular holes."""

    def __init__(self, *q, **d):
        """
        q: tuple
            Metal spec

        d: dict
            Metal spec
        """
        Metal.__init__(self, *q + (do_matter,), **d)
