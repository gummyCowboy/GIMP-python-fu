#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_for import Widget as fw
from roller_constant_key import Option as ok
import gimpfu as fu


class Mode:
    _q = [
        ("Normal", fu.LAYER_MODE_NORMAL),
        ("Dissolve", fu.LAYER_MODE_DISSOLVE),
        ("Color Erase", fu.LAYER_MODE_COLOR_ERASE),
        ("Erase", fu.LAYER_MODE_ERASE),
        ("Merge", fu.LAYER_MODE_MERGE),
        ("Split", fu.LAYER_MODE_SPLIT),
        (fw.LIST_SEPARATOR, None),
        ("Lighten Only", fu.LAYER_MODE_LIGHTEN_ONLY),
        ("Luma Lighten Only", fu.LAYER_MODE_LUMA_LIGHTEN_ONLY),
        ("Screen", fu.LAYER_MODE_SCREEN),
        ("Dodge", fu.LAYER_MODE_DODGE),
        ("Addition", fu.LAYER_MODE_ADDITION),
        (fw.LIST_SEPARATOR * 2, None),
        ("Darken Only", fu.LAYER_MODE_DARKEN_ONLY),
        ("Luma Darken Only", fu.LAYER_MODE_LUMA_DARKEN_ONLY),
        ("Multiply", fu.LAYER_MODE_MULTIPLY),
        ("Burn", fu.LAYER_MODE_BURN),
        ("Linear Burn", fu.LAYER_MODE_LINEAR_BURN),
        (fw.LIST_SEPARATOR * 3, None),
        ("Overlay", fu.LAYER_MODE_OVERLAY),
        ("Soft Light", fu.LAYER_MODE_SOFTLIGHT),
        ("Hard Light", fu.LAYER_MODE_HARDLIGHT),
        ("Vivid Light", fu.LAYER_MODE_VIVID_LIGHT),
        ("Pin Light", fu.LAYER_MODE_PIN_LIGHT),
        ("Linear Light", fu.LAYER_MODE_LINEAR_LIGHT),
        ("Hard Mix", fu.LAYER_MODE_HARD_MIX),
        (fw.LIST_SEPARATOR * 4, None),
        ("Difference", fu.LAYER_MODE_DIFFERENCE),
        ("Exclusion", fu.LAYER_MODE_EXCLUSION),
        ("Subtract", fu.LAYER_MODE_SUBTRACT),
        ("Grain Extract", fu.LAYER_MODE_GRAIN_EXTRACT),
        ("Grain Merge", fu.LAYER_MODE_GRAIN_MERGE),
        ("Divide", fu.LAYER_MODE_DIVIDE),
        (fw.LIST_SEPARATOR * 5, None),
        ("HSV Hue", fu.LAYER_MODE_HSV_HUE),
        ("HSV Saturation", fu.LAYER_MODE_HSV_SATURATION),
        ("HSL Color", fu.LAYER_MODE_HSL_COLOR),
        ("HSV Value", fu.LAYER_MODE_HSV_VALUE),
        (fw.LIST_SEPARATOR * 6, None),
        ("LCH Hue", fu.LAYER_MODE_LCH_HUE),
        ("LCH Chroma", fu.LAYER_MODE_LCH_CHROMA),
        ("LCH Color", fu.LAYER_MODE_LCH_COLOR),
        ("LCH Lightness", fu.LAYER_MODE_LCH_LIGHTNESS),
        ("Luminance", fu.LAYER_MODE_LUMINANCE)
    ]

    # Use with PaintRush.
    EDGE_MODE = (
        "Normal",
        "Lighten Only",
        "Screen",
        "Overlay",
        "Soft Light",
        "Hard Light",
        "Difference",
        "Subtract",
        "Grain Extract",
        "Grain Merge",
        "Divide",
        "HSV Value",
        "HSV Saturation",
        "HSL Color",
        "LCH Lightness",
        "Luminance"
    )
    INFLUENCE_MODE = (
        "Normal",
        "Overlay",
        "Hard Light",
        "Soft Light",
        "Vivid Light",
        "Pin Light",
        "Linear Light",
        "Hard Mix",
        fw.LIST_SEPARATOR,
        "Dissolve",
        "Color Erase",
        "Erase",
        "Merge",
        "Split",
        fw.LIST_SEPARATOR,
        "Lighten Only",
        "Luma Lighten Only",
        "Screen",
        "Dodge",
        "Addition",
        fw.LIST_SEPARATOR,
        "Darken Only",
        "Luma Darken Only",
        "Multiply",
        "Burn",
        "Linear Burn",
        fw.LIST_SEPARATOR,
        "Difference",
        "Exclusion",
        "Subtract",
        "Divide",
        "Grain Extract",
        "Grain Merge",
        fw.LIST_SEPARATOR,
        "HSV Hue",
        "HSV Saturation",
        "HSV Value",
        "HSL Color",
        fw.LIST_SEPARATOR,
        "LCH Lightness",
        "LCH Chroma",
        "LCH Hue",
        "LCH Color",
        "Luminance"
    )
    _d = OrderedDict(_q)
    names = _d.keys()


def get_fill_mode(d):
    """
    Get the enum mode from a English translation. Use with ColorFill.

    d: dict
        Has a MODE option.

    Return: enum
        of layer mode
    """
    return Mode._d[d[ok.FILL_MODE]]


def get_gradient_mode(d):
    """
    Get the enum mode from a English translation. Use with gradient.

    d: dict
        Has a MODE option.

    Return: enum
        of layer mode
    """
    return Mode._d[d[ok.GRADIENT_MODE]]


def get_influence_mode():
    """
    Fetch the Influence Paint Mode list.

    Return: tuple
        of string; Paint Mode type
    """
    return Mode.INFLUENCE_MODE


def get_mode(d, k=ok.MODE):
    """
    Get the enum mode from a English translation.

    d: dict
        Has a MODE option.

    k: string
        mode key

    Return: enum
        of layer mode
    """
    return Mode._d[d[k]]


def translate_mode(n):
    """
    Translate an English Paint Mode descriptor into GIMP layer mode enum.

    n: string
        paint mode descriptor

    Return: enum
        of layer mode
    """
    return Mode._d[n]
