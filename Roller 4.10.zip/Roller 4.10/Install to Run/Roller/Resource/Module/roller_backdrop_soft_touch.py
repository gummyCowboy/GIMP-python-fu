#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection, clone_layer, make_layer_group, merge_layer_group
)
from roller_maya_style import Style, make_background
from roller_view_real import add_sub_base_group, finish_style
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a style layer.

    v: View
    maya: SoftTouch
    Return: layer or None
        Has style material.
    """
    j = v.j
    z = make_background(v, maya, maya.value_d)
    parent = add_sub_base_group(v, maya, z=z)
    group = make_layer_group(j, "WIP", parent=parent, z=z)
    z1 = clone_layer(z)

    blur_selection(z, 500)

    z1.name = "HSV Hue"
    z1.mode = fu.LAYER_MODE_HSV_HUE

    pdb.plug_in_gimpressionist(j, z1, "Painted_Rock")

    if maya.value_d[ok.INVERT]:
        pdb.gimp_drawable_invert(merge_layer_group(group), 0)
    return finish_style(merge_layer_group(parent), "Soft Touch")


class SoftTouch(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BBR

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        self.init_background(make_style, *q, **d)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BBR][ok.BACKGROUND][ok.BACKDROP_TYPE] == bs.BACKDROP_IMAGE
        super(SoftTouch, self).do(v, d, is_change)
