#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clear_inverse_selection,
    clone_layer,
    color_fill_layer,
    dilate,
    invert_selection,
    load_selection,
    make_layer_group,
    merge_layer_group,
    select_color,
    select_item
)
from roller_maya_style import Style
from roller_view_hub import get_average_color
from roller_view_real import (
    add_sub_base_group, add_wip_layer, finish_style, insert_copy
)
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: MazeBlend
    Return: layer
        with backdrop style material
    """
    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya)
    bg_z = insert_copy(v, parent, parent)
    z = add_wip_layer(v, maya, "Lost Maze Base", group=parent)
    group = make_layer_group(j, "WIP", parent=parent, z=z)

    # Preserve.
    q = pdb.gimp_context_get_foreground()
    q1 = pdb.gimp_context_get_background()

    color_fill_layer(z, (127, 127, 127))
    pdb.gimp_image_reorder_item(j, bg_z, group, 0)
    select_item(bg_z)

    color = get_average_color(bg_z)

    color_fill_layer(bg_z, color)

    z = pdb.gimp_image_merge_down(j, bg_z, fu.CLIP_TO_IMAGE)
    z1 = clone_layer(z, n="Multiply")
    z1.mode = fu.LAYER_MODE_MULTIPLY
    z1.opacity = 25.
    w = max(1, v.wip.w // d[ok.COLUMN])
    h = max(1, v.wip.h // d[ok.ROW])
    w1 = int((w + h) / 1.5)

    pdb.gimp_context_set_background((0, 0, 0))
    pdb.gimp_context_set_foreground((255, 255, 255))
    select_item(z1)
    pdb.plug_in_maze(j, z1, w, h, 1, 0, d[ok.SEED], 0, 0)
    select_color(z1, (255, 255, 255))

    sel = pdb.gimp_selection_save(j)
    z2 = clone_layer(z1, n="Overlay")
    z2.mode = fu.LAYER_MODE_OVERLAY

    # edge amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(j, z1, 1., 0, 0)

    for _ in range(4):
        dilate(z1)

    pdb.gimp_drawable_invert(z2, 0)
    color_fill_layer(z2, (127, 127, 127))
    load_selection(j, sel)
    clear_inverse_selection(z2)
    pdb.plug_in_emboss(
        j,
        z2,
        v.glow_ball.azimuth,
        v.glow_ball.elevation,
        3,                  # depth
        1                   # emboss type
    )
    pdb.gimp_drawable_invert(z1, 0)
    blur_selection(z1, w1)
    load_selection(j, sel)
    invert_selection(j)
    clear_inverse_selection(z1)
    merge_layer_group(group)

    # Restore.
    pdb.gimp_context_set_foreground(q)
    pdb.gimp_context_set_background(q1)

    pdb.gimp_image_remove_channel(j, sel)
    return finish_style(merge_layer_group(parent), "Maze Blend")


class MazeBlend(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
