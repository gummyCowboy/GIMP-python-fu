#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Maya import and export business
from roller_constant_key import Group as gk
from roller_maya_border import Border
from roller_maya_caption import Caption
from roller_maya_fringe import Fringe
from roller_maya_global import Global
from roller_maya_image import Image
from roller_maya_gradient_light import Light
from roller_maya_model import Model
from roller_maya_margin import Margin
from roller_maya_plaque import Plaque
from roller_maya_property import Property
from roller_maya_rectangle import Rectangle
from roller_maya_shift import Shift
from roller_maya_backdrop import Backdrop
from roller_maya_type import Type

# {Group key: Group Maya processor}
GROUP_NEXUS = {
    gk.BACKDROP: Backdrop,
    gk.BORDER: Border,
    gk.CAPTION: Caption,
    gk.FRINGE: Fringe,
    gk.GLOBAL: Global,
    gk.IMAGE: Image,
    gk.GRADIENT_LIGHT: Light,
    gk.MARGIN: Margin,
    gk.MODEL: Model,
    gk.PLAQUE: Plaque,
    gk.PROPERTY: Property,
    gk.RECTANGLE: Rectangle,
    gk.SHIFT: Shift,
    gk.TYPE_BOX: Type,
    gk.TYPE_CELL: Type,
    gk.TYPE_PYRAMID: Type,
    gk.TYPE_STACK: Type,
    gk.TYPE_TABLE: Type
}
