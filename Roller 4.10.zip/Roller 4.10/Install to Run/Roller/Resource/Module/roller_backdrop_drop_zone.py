#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_fu import clear_selection, color_fill_selection, select_rect
from roller_one import enumerate_name
from roller_one_the import The
from roller_view_real import add_wip_base, finish_style
from roller_view_hub import calc_gradient, invert_color
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Draw the shrinking rectangles.

    v: View
    maya: Style
    Return: layer or None
        with Drop Zone material
    """
    d = maya.value_d

    # Is a gradient that is created by the user, 'grad'.
    grad = None

    x, y, w, h = v.wip.rect
    steps = d[ok.STEPS_DROP_ZONE]
    color, color1 = d[ok.COLOR_2A]
    mod_w = w / steps / 2.
    mod_h = h / steps / 2.

    if d[ok.IKR][ok.INVERT]:
        color = invert_color(color)
        color1 = invert_color(color1)

    # RGBA of int, 'stair'
    # Is added to the start color once per iteration.
    stair = calc_gradient(color, color1, steps)

    is_keep = d[ok.IKR][ok.KEEP_GRADIENT]

    # There's no need to clip the previous
    # fill if the opacity is always 100%.
    is_clip = color[3] != 255 or color1[3] != 255

    if is_keep:
        # Make a unique gradient name.
        gradients = The.cat.gradient_list

        # gradient name, 'n'
        n = d[ok.NAME]

        if not n:
            n = "Drop Zone"

        if n in gradients:
            n = enumerate_name(n, gradients)

        # Create a gradient with evenly spaced
        # segments, one for each color.
        grad = pdb.gimp_gradient_new(n)
        pdb.gimp_gradient_segment_range_split_uniform(
            grad,
            0,
            0,
            steps
        )

    start_color = color[:]
    z = add_wip_base(v, maya, "Drop Zone WIP", maya.group)

    for step in range(steps):
        # Set the 'color_fill_selection' function's input to
        # the correct format (a tuple).
        # tuple of RGBA ordered integer, 'q'
        q = tuple([int(i) for i in color])

        if is_keep:
            # arg, (gradient, segment index, color, opacity)
            # The opacity value has to be rounded
            # as it will overflow with float-sum (e.g. 100.00000007).
            arg = grad, step, q[:3], round(q[3] / 255. * 100., 1)

            # The start and end color is the same for a segment.
            pdb.gimp_gradient_segment_set_left_color(*arg)
            pdb.gimp_gradient_segment_set_right_color(*arg)

        if w >= 1 and h >= 1:
            select_rect(v.j, x, y, w, h)

            if is_clip:
                clear_selection(z, keep_sel=True)
            color_fill_selection(z, q)

        # Define the next rectangle.
        x += mod_w
        y += mod_h
        w -= (mod_w * 2)
        h -= (mod_h * 2)

        color = ()
        for i in range(4):
            b = stair[i] * (step + 1)
            color += (start_color[i] + int(b),)

    # Create a gradient if the user desires.
    if grad and is_keep:
        # Store image gradients so they can
        # be deleted before the program closes.
        The.image_gradient_created.append(grad)

        # This gradient is kept and is
        # saved to a file when GIMP closes.
        The.image_gradient_used = grad

    return finish_style(z, "Drop Zone")


class DropZone(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = False

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        k_path = d['k_path']
        d['k_path'] = [k_path, k_path + (ok.IKR,)]
        Style.__init__(self, *q + (make_style,), **d)
