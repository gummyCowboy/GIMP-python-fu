#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as ff
from roller_constant_key import Option as ok
from roller_frame import Noise, grow_frame
from roller_frame_build import Build
from roller_fu import (
    add_layer,
    clear_selection,
    color_fill_selection,
    load_selection,
    select_item
)
from roller_maya import check_matter, make_frame_group, check_frame_cake
from roller_maya_blur_behind import BlurBehind
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_view_hub import calc_gradient
from roller_view_real import LIGHT, get_light
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: GradientLevel
    Return: layer
        with the frame
    """
    j = v.j
    d = maya.value_d
    start_color, end_color = d[ok.COLOR_2A]
    steps = d[ok.FRAME_W]
    cause = maya.cause.matter
    z = add_layer(
        j,
        maya.group.name + " Material",
        parent=maya.group,
        offset=get_light(maya)
    )

    # Begin gradient construction.
    step = calc_gradient(start_color, end_color, steps)
    q = list(start_color)
    sel = None
    select_item(cause)

    for i in range(steps):
        if not pdb.gimp_selection_is_empty(j):
            sel = pdb.gimp_selection_save(j)

            grow_frame(j, 1, ff.ANGULAR)
            load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
            color_fill_selection(z, tuple(q))
            load_selection(j, sel, option=fu.CHANNEL_OP_ADD)
            for x in range(4):
                q[x] = start_color[x] + int(step[x] * (i + 1))
        pdb.gimp_image_remove_channel(j, sel)

    select_item(cause)
    clear_selection(z)
    return z


class GradientLevel(Build):
    """Is frame made from a dual color gradient."""
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        self.do_matter = do_matter

        Build.__init__(self, any_group, super_maya, k_path)

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.NSR, ok.NOISE_D)
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (self.cause, self), k_path + (ok.NSR, ok.SHADOW)
        )
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(any_group, self, k_path)
        self.sub_maya[LIGHT] = Light(any_group, self, ok.TRANSLUCENT)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Gradient Level Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[ok.NOISE_D].do(v, d[ok.NSR][ok.NOISE_D], self.is_matter)

        m = self.sub_maya[ok.SHADOW].do(
            v,
            d[ok.NSR][ok.SHADOW],
            self.is_matter + self.is_cake,
            is_change + self.cause.is_cake
        )

        self.sub_maya[ok.BLUR_BEHIND].do(v, d, m or is_back, self.is_matter)
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m
