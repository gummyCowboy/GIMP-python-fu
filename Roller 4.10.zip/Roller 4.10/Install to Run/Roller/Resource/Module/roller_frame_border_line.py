#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Metal, select_border, soften_metal_sel
from roller_fu import add_layer


def do_matter(v, maya):
    """
    Make a frame around material.

    v: View
    maya: Maya
    Return: layer
        with the frame
    """
    j = v.j
    d = maya.value_d[ok.FNR][ok.FRAME_METAL]
    group = maya.group
    cause = maya.cause.matter

    # layer for the emboss, 'z'
    z = add_layer(
        j,
        group.name + " Border Line",
        parent=group,
        offset=len(group.layers)
    )

    select_border(j, cause, d[ok.FRAME_W], d[ok.FRAME_TYPE])
    return soften_metal_sel(v, z, d)


class BorderLine(Metal):
    """Create a metallic-like frame."""

    def __init__(self, *q, **d):
        """
        q: tuple
            Metal spec
        """
        Metal.__init__(self, *q + (do_matter,), **d)
