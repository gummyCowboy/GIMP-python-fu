#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Fill as fl, Frame as ff
from roller_constant_key import Option as ok
from roller_frame import do_selection_material
from roller_frame_build import Build
from roller_fu_mode import translate_mode
from roller_maya import check_frame_cake, check_matter, make_frame_group
from roller_maya_blur_behind import BlurBehind
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_fu import (
    clone_layer,
    color_fill_selection,
    copy_all_image,
    get_layer_offset,
    isolate_selection,
    merge_layer,
    paste_layer,
    remove_z,
    select_item,
    select_rect,
    set_layer_attr,
    shape_image
)
from roller_one_gegl import edge
from roller_view_hub import set_gimp_pattern, set_fill_context
from roller_view_real import LIGHT, insert_copy
import gimpfu as fu

pdb = fu.pdb


def apply_backdrop(v, maya, z):
    """
    Copy the background. Clip material around the existing selection.

    v: View
    maya: Maya
    Return: layer
        with backdrop
    """
    j = v.j
    sel = pdb.gimp_selection_save(j)
    z1 = clone_layer(maya.bg_z)

    pdb.gimp_image_reorder_item(j, z1, maya.group, get_layer_offset(z))
    j.remove_layer(z)
    isolate_selection(z1, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z1


def apply_image(v, maya, z):
    """
    Apply an image to the frame.

    v: View
    maya: Maya
    z: layer
        Has the frame.

    Return: layer
        with the frame
    """
    j = v.j
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    j1 = maya.cause.get_frame_image(maya.r_c)

    if j1:
        j1 = j1.j

        copy_all_image(j1)

        j1 = pdb.gimp_edit_paste_as_new_image()

        shape_image(j1, x1 - x, y1 - y)

        z = paste_layer(z)

        pdb.gimp_layer_set_offsets(z, x, y)
        z = merge_layer(z)
    return z


def apply_pattern(v, maya, z):
    """
    Fill the existing selection with a pattern.

    v: View
    maya: Maya
    Return: layer
        with pattern
    """
    d = maya.value_d

    # fill point, 'x, y'
    x, y = pdb.gimp_selection_bounds(v.j)[1:3]

    set_fill_context(fl.FILL_DICT)
    set_gimp_pattern(d[ok.IPB][ok.PATTERN])
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, x, y)
    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: FrameOver
    Return: layer or None
        with the frame
    """
    if maya.value_d[ok.FRAME_TYPE] == ff.BACKDROP:
        maya.bg_z = insert_copy(v, maya.group.parent, maya.group, is_hide=True)

    z = do_selection_material(v, maya, do_sel, embellish, "")

    remove_z(maya.bg_z)
    return z


def do_sel(v, maya, z):
    """
    Make a frame from a selection.

    v: View
    maya: Maya
    z: layer
        to receive the frame
    """
    j = v.j
    is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

    if is_sel:
        d = maya.value_d
        a = d[ok.FRAME_W]
        x -= a
        y -= a
        w = x1 + a - x
        h = y1 + a - y
        maya.rect_q += [(x, y, w, h)]

        select_rect(j, x, y, w, h)
        z = FILL_D[d[ok.FRAME_TYPE]](v, maya, z)
    return z


def embellish(v, maya, z):
    """
    Is a callback from 'do_selection_material'.

    v: View
    maya: NailPolish
    z: layer
        to embellish

    Return: layer
        with embellishment
    """
    j = v.j
    d = maya.value_d
    z1 = clone_layer(z)
    z1.opacity = d[ok.FSO]

    pdb.gimp_selection_none(j)

    for rect in maya.rect_q:
        select_rect(j, *rect, option=fu.CHANNEL_OP_ADD)

    select_item(maya.cause.matter, option=fu.CHANNEL_OP_SUBTRACT)
    color_fill_selection(z, d[ok.COLOR_1])
    pdb.gimp_selection_none(j)
    edge(z1)
    pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
    set_layer_attr(z1, translate_mode(d[ok.FSM]), d[ok.FSO])

    z = merge_layer(z1)
    z.name = z.parent.name + " Material"
    return z


class NailPolish(Build):
    """Make an overlay for material."""
    is_seeded = True
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, k_path=()):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        # Remember background to improve main
        # cell frame processing speed, 'bg_z'.
        # Store frame rectangle from formation to embellishment, 'rect_q'.
        self.bg_z = self.rect_q = None

        self.do_matter = do_matter

        Build.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.IPB,),
                k_path + (ok.IPB, ok.PATTERN),
                k_path + (ok.IPB, ok.IMAGE_CHOICE)
            ]
        )

        self.sub_maya[ok.BUMP] = Bump(
            any_group, self, k_path + (ok.IPB, ok.BUMP)
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (self.cause, self), k_path + (ok.SRR, ok.SHADOW)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.OTHER)
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(any_group, self, k_path)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame Over Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.rect_q = []

        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[ok.BUMP].do(v, d[ok.IPB][ok.BUMP], self.is_matter)

        m = self.sub_maya[ok.SHADOW].do(
            v,
            d[ok.SRR][ok.SHADOW],
            self.is_matter + self.is_cake,
            is_change + self.cause.is_cake
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.sub_maya[ok.BLUR_BEHIND].do(v, d, m or is_back, self.is_matter)
        self.reset_issue()
        return m


FILL_D = {
    ff.BACKDROP: apply_backdrop,
    ff.IMAGE: apply_image,
    ff.PATTERN: apply_pattern
}
