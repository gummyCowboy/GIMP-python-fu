#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Signal as si
from roller_constant_key import Option as ok, Step as sk
from roller_frame_build import SubBuild
from roller_fu_mode import translate_mode
from roller_maya import NO_VOTE, check_matter
from roller_fu import set_layer_attr
from roller_one_the import The
from roller_view_gradient_light import GradientLight
from roller_view_real import mask_sub_maya


def do_matter(v, maya):
    """
    Make a Gradient Light layer at the top of a super Maya group.

    v: View
    maya: Light
    Return: layer
        with Gradient Light
    """
    return GradientLight.insert_z(maya.super_maya.group)


class Light(SubBuild):
    """Manage Gradient Light layer output."""
    issue_q = 'cake', 'matter'
    put = (check_matter, 'matter'),

    def __init__(self, any_group, super_maya, influence):
        """
        any_group: AnyGroup
            with a Gradient Light Influence

        super_maya: Maya
            Has control over the Light output.

        influence: string
            Influence type
        """
        self.influence = influence
        self.do_matter = do_matter
        self._view_mode = self.view_value = self._view_opacity = None

        SubBuild.__init__(self, any_group, super_maya, k_path=NO_VOTE)
        self.handle_d[
            The.power.connect(si.LIGHT_CHANGE, self.on_light_change)
        ] = The.power
        self.value_d = The.helm.get_group(sk.GRADIENT_LIGHT).value_d

    def do(self, v, is_change):
        """
        Manage layer output during a View run.

        v: View
        is_change: bool
            Is True when the super Maya has either matter or mask change.
        """
        d = self.value_d
        self.go = self.super_maya.go and d[ok.SWITCH]
        e = d[ok.IGR][ok.INFLUENCE][self.influence]
        mode, opacity = e[ok.MODE], e[ok.OPACITY]

        if self.go:
            if not self.matter:
                if opacity == .0:
                    self.is_cake = self.is_matter = False
                else:
                    # Matter is valid because the layer had been suppressed.
                    self.is_matter = True

            self.realize(v)

            if self.is_cake or self.is_matter:
                set_layer_attr(self.matter, translate_mode(mode), opacity)
                v.is_back = True
            if self.is_matter or is_change:
                mask_sub_maya(self.super_maya.matter, self.matter)

        else:
            self.die(v)

        self.reset_issue()

        self.view_value = deepcopy(self.value_d)
        self._view_mode = mode
        self._view_opacity = opacity

    def on_light_change(self, *_):
        """Respond to Gradient Light change."""
        mode = opacity = None
        d = self.value_d

        if ok.IGR in d and ok.INFLUENCE in d[ok.IGR]:
            e = d[ok.IGR][ok.INFLUENCE][self.influence]
            mode, opacity = e[ok.MODE], e[ok.OPACITY]

        e = self.view_value

        if e:
            self.is_cake = self.is_matter = False

            for k in d:
                if k != ok.IGR:
                    if d[k] != e[k]:
                        self.is_matter = True
                        break
                else:
                    if (
                        ok.GRADIENT in d[k] and
                        d[k][ok.GRADIENT] != e[k][ok.GRADIENT]
                    ):
                        self.is_matter = True
                        break
            if opacity != self._view_opacity or mode != self._view_mode:
                self.is_cake = True
        else:
            self.is_cake = self.is_matter = True

    def reset(self):
        """
        Is called when the View image closes as during an image resize event.
        """
        self.view_value = None
        self.is_cake = self.is_matter = True
