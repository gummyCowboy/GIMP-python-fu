#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_view_image import ViewImage
import gimpfu as fu

pdb = fu.pdb

# Use to differentiate a mask selection from the other selections:
MASK_TYPE = 0


class Cat(object):
    """Hold the center. Has program scope variable."""

    def __init__(self):
        """Initialize variables."""

        # RenderImage
        self._view_image = None

        # GIMP brush
        self.brush_list = sorted(pdb.gimp_brushes_get_list(None)[1])

        # GIMP font
        self.font_list = sorted(pdb.gimp_fonts_get_list(None)[1])

        # GIMP gradient
        self.gradient_list = sorted(pdb.gimp_gradients_get_list(None)[1])

        # GIMP pattern
        self.pattern_list = sorted(pdb.gimp_patterns_get_list(None)[1])

    @property
    def render(self):
        """
        Get the ViewImage or create one.

        Return: ViewImage
            Has the View image.
        """
        if self._view_image:
            return self._view_image
        else:
            self._view_image = ViewImage()
            return self._view_image

    @render.setter
    def render(self, *_):
        """Is an invalid access."""
        raise AttributeError("Unable to write to variable 'render'.")
