#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_fu import clone_layer, merge_layer
from roller_maya_style import Style, make_background
from roller_one_gegl import cubism, edge, saturation
from roller_view_real import finish_style
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: Style
    Return: layer or None
        with Cubism Cover
    """
    j = v.j
    d = maya.value_d
    z = make_background(v, maya, d)

    cubism(
        z,
        size=d[ok.TILE_SIZE],
        amount=5.,
        seed=d[ok.BBR][ok.BACKGROUND][ok.SEED] + v.glow_ball.seed
    )

    z1 = clone_layer(z, n="Soft light")
    z1.mode = z.mode = fu.LAYER_MODE_SOFTLIGHT

    edge(z1)
    pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))

    z = merge_layer(z1)

    saturation(z, d[ok.SATURATION])
    return finish_style(z, "Cubism Cover")


class CubismCover(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BBR

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        self.init_background(make_style, *q, **d)

    def do(self, v, d, is_change):
        """
        Produce output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BBR][ok.BACKGROUND][ok.BACKDROP_TYPE] == bs.BACKDROP_IMAGE
        super(CubismCover, self).do(v, d, is_change)
