#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_color_grid import do_color_grid
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clear_selection,
    clone_layer,
    flip_layer,
    load_selection,
    merge_layer,
    merge_layer_group,
    select_color
)
from roller_maya_style import Style
from roller_one_gegl import unsharp_mask
from roller_view_real import add_sub_base_group, add_wip_layer, finish_style
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a Dark Fort Backdrop Style layer.

    v: View
    maya: Style
    Return: layer or None
        with Dark Fort
    """
    def _noise():
        """Add noise to the colored part grid."""
        # Create a selection from black pixel.
        pdb.gimp_by_color_select(
            z,
            (0, 0, 0),
            0,                      # threshold
            fu.CHANNEL_OP_REPLACE,
            1,                      # yes, antialias
            0,                      # no feather
            .0,                     # feather radius
            0                       # no sample merged
        )

        # Clear the black grid.
        clear_selection(z)

        pdb.plug_in_rgb_noise(
            j, z,
            1,                      # yes, independent
            0,                      # no correlated
            .1,                     # R noise
            .1,                     # G noise
            .1,                     # B noise
            .0                      # A noise
        )
        pdb.plug_in_emboss(
            j, z,
            azimuth,
            elevation,
            3,                      # depth
            0                       # bump
        )
        pdb.plug_in_despeckle(
            j, z,
            4,                      # radius
            1,                      # adaptive
            7,                      # black cut-off
            248                     # white cut-off
        )
        pdb.plug_in_despeckle(
            j, z,
            30,                     # radius
            1,                      # adaptive
            7,                      # black cut-off
            248                     # white cut-off
        )

    j = v.j
    d = maya.value_d
    z = add_wip_layer(v, maya, "Grid")
    group = add_sub_base_group(v, maya, z=z)
    a = v.glow_ball
    azimuth = a.azimuth
    elevation = a.elevation
    e = deepcopy(d)
    e[ok.COLOR_2A] = (0, 0, 0, 255), (255, 255, 255, 255)
    e[ok.ANGLE] = .0
    grid = do_color_grid(v, e, group)
    z = clone_layer(grid, n="Noise")

    select_color(z, (0, 0, 0))

    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    _noise()

    z1 = clone_layer(z, n="HSV Value")
    z1.mode = fu.LAYER_MODE_HSV_VALUE

    flip_layer(z1, horizontal=1)
    pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    z = merge_layer(z1)
    z1 = clone_layer(z, n="Difference")
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    # lowest turbulence, '1.'
    pdb.plug_in_plasma(j, z, d[ok.SEED] + a.seed, 1.)

    z = clone_layer(z, n="Unsharp Mask")

    load_selection(j, sel)
    blur_selection(z, 1)
    unsharp_mask(z, 2., .5, 0.)
    pdb.gimp_selection_none(j)

    z = merge_layer(z)

    pdb.gimp_drawable_desaturate(z, fu.DESATURATE_LUMINANCE)
    pdb.plug_in_emboss(
        j, z,
        azimuth,
        elevation,
        3,                  # depth
        0                   # bump
    )
    pdb.gimp_image_remove_channel(j, sel)

    z = merge_layer_group(group)
    return finish_style(z, "Dark Fort")


class DarkFort(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = False
    is_seeded = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
