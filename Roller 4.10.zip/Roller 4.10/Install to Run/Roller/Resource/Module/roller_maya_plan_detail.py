#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Group as gk, Option as ok, Plan as ak
from roller_deco_border import select_border
from roller_def import get_default_value
from roller_maya import NO_VOTE, Maya, check_matter
from roller_fu import (
    color_fill_selection, load_selection, select_shape, verify_layer_group
)
from roller_view_hub import add_text_layer, make_plan_text_layer
from roller_view_real import add_wip_layer, make_group
from roller_view_step import get_property_group, get_planner
import gimpfu as fu

pdb = fu.pdb


def draw_coordinate(v, maya, group, r_c):
    """
    Draw the cell pocket coordinate in the topleft corner of a cell.

    v: View
    maya: Maya
    group: layer
        Is the destination for the output layer.

    r_c: tuple
        zero-based cell index
        (row, column)
    """
    model = maya.model
    x, y = model.get_pocket(r_c).position
    x1 = x - v.wip.x
    y1 = y - v.wip.y
    x1, y1 = map(int, map(round, (x1, y1)))
    add_text_layer(
        group,
        make_plan_text_layer(v.j, "{}, {}".format(x1, y1), maya.font_size),
        x + 3, y
    )


def draw_corner(v, maya, group, r_c):
    """
    Draw the cell pocket corners in the bottom-left
    and top-right corners of the cell.

    v: View
    maya: Maya
    group: layer
        Is the destination for the output layer.

    r_c: tuple
        zero-based cell index
        (row, column)
    """
    # The pocket position is in View space.
    x, y, w, h = maya.model.get_pocket(r_c).rect
    x1 = x - v.wip.x
    y1 = y - v.wip.y
    x2 = x1 + w
    y2 = y1 + h
    x1, x2, y1, y2 = map(int, map(round, (x1, x2, y1, y2)))

    # top-right
    z = make_plan_text_layer(v.j, "{}, {}".format(x2, y1), maya.font_size)

    add_text_layer(group, z, x + w - z.width - 3, y)

    # bottom-left
    z = make_plan_text_layer(v.j, "{}, {}".format(x1, y2), maya.font_size)
    add_text_layer(group, z, x + 3, y + h - z.height)


def draw_dimension(v, maya, group, r_c):
    a = maya.model.get_pocket(r_c)
    z = make_plan_text_layer(
        v.j, str(int(a.w)) + ", " + str(int(a.h)), maya.font_size
    )
    add_text_layer(
        group, z, a.x + a.w - z.width - 3, a.y + a.h - z.height
    )


def draw_main(v, maya, n, p):
    """
    Process layer output for the main option settings.

    v: View
    maya: Maya
    n: string
        layer name

    p: function
        Call to make layer output.

    Return: layer or None
    """
    group = make_group(v, n, maya.super_maya.group)

    for r_c in maya.super_maya.main_cell_q:
        p(v, maya, group, r_c)
    return verify_layer_group(group)


def draw_main_position(v, maya):
    """
    Draw cell position at the topleft of a main cell.

    v: View
    maya: Maya
    Return: layer or None
    """
    return draw_main(v, maya, "Coordinate", draw_coordinate)


def draw_main_corner(v, maya):
    """
    Draw cell corner coordinates.

    v: View
    maya: Maya
    Return: layer or None
    """
    return draw_main(v, maya, "Corner", draw_corner)


def draw_main_dimension(v, maya):
    """
    Draw a cell's dimension at the bottom-right corner of a cell.

    v: View
    maya: Maya
    Return: layer or None
    """
    return draw_main(v, maya, "Dimension", draw_dimension)


def draw_main_ratio(v, maya):
    """
    Draw a cell ratio at the center of a cell. A ratio
    is a cell center point divided by the render size.

    v: View
    maya: Maya
    """
    return draw_main(v, maya, "Ratio", draw_ratio)


def draw_main_shape(v, maya):
    """
    Draw a cell shape for the main option settings.

    v: View
    maya: Maya
    """
    group = make_group(v, "Cell Shape", maya.super_maya.group)

    for r_c in maya.super_maya.main_cell_q:
        draw_shape(v, maya, r_c)

    fill_shape(v, maya, group)
    return verify_layer_group(group)


def draw_ratio(v, maya, group, r_c):
    """
    Draw a cell's position ratio in the WIP rectangle context.

    v: View
    maya: Maya
    group: layer
        Is the destination for the output layer.

    r_c: tuple
        zero-based cell index; Goo key
        (row, column)
    """
    model = maya.model
    j = v.j

    # View space pocket rectangle
    x, y, w, h = model.get_pocket(r_c).rect

    # WIP relative position
    x1 = x - v.wip.x
    y1 = y - v.wip.y

    # ratio
    f_x = (w / 2. + x1) / v.wip.w
    f_y = (h / 2. + y1) / v.wip.h

    # format
    r_x = format(f_x, '.2f')
    r_y = format(f_y, '.2f')

    z = make_plan_text_layer(
        j,
        r_x[int(f_x < 1):] + ", " + r_y[int(f_y < 1):],
        maya.font_size
    )
    add_text_layer(
        group, z, x + w / 2 - z.width / 2, y + h / 2 - z.height / 2
    )


def draw_per_cell(v, maya, n, p):
    """
    Process layer output for Per Cell settings.

    v: View
    maya: Maya
    n: string
        layer name

    p: function
        Call to make layer output.

    Return: layer or None
    """
    group = make_group(v, n, maya.super_maya.group)
    p(v, maya, group, maya.super_maya.r_c)
    return verify_layer_group(group)


def draw_per_cell_position(v, maya):
    """
    Draw the cell position at the topleft of a Per Cell.

    v: View
    maya: Maya
    Return: layer or None
    """
    return draw_per_cell(v, maya, "Coordinate", draw_coordinate)


def draw_per_cell_corner(v, maya):
    """
    Draw cell corner coordinates.

    v: View
    maya: Maya
    Return: layer or None
    """
    return draw_per_cell(v, maya, "Corner", draw_corner)


def draw_per_cell_dimension(v, maya):
    """
    Draw cell corner coordinates.

    v: View
    maya: Maya
    Return: layer or None
    """
    return draw_per_cell(v, maya, "Dimension", draw_dimension)


def draw_per_cell_ratio(v, maya):
    """
    Draw cell corner coordinates.

    v: View
    maya: Maya
    Return: layer or None
    """
    return draw_per_cell(v, maya, "Ratio", draw_ratio)


def draw_per_cell_shape(v, maya):
    """
    Draw cell corner coordinates.

    v: View
    maya: Maya
    Return: layer or None
    """
    group = make_group(v, "Cell Shape", maya.super_maya.group)

    draw_shape(v, maya, maya.super_maya.r_c)
    fill_shape(v, maya, group)
    return verify_layer_group(group)


def draw_shape(v, maya, r_c):
    """
    Draw a Cell Model's cell shape.

    v: View
    maya: Maya
    """
    model = maya.model
    j = v.j
    sel = pdb.gimp_selection_save(j) \
        if not pdb.gimp_selection_is_empty(j) else None
    d = get_default_value(gk.BORDER)
    maya.r_c = r_c
    d[ok.BORDER_W] = 2
    d[ok.TYPE_DECO] = dc.COLOR
    v.deco.shape = model.get_plaque(r_c)

    select_shape(j, v.deco.shape)
    select_border(v, d)
    if sel:
        load_selection(j, sel, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, sel)


def fill_shape(v, maya, group):
    """
    Fill a selection with a color.

    v: View
    maya: Maya
    group: layer
        parent for filled selection layer
    """
    if not pdb.gimp_selection_is_empty(v.j):
        z = add_wip_layer(v, maya, "Cell", group=group)
        z.opacity = 66.
        color_fill_selection(z, fy.SHAPE_COLOR)


class Detail(Maya):
    """"Manage Plan output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, super_maya, do_matter, key):
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter
        self.font_size = 11.

        Maya.__init__(
            self, any_group, 0, ((check_matter, 'matter'),), k_path=NO_VOTE
        )
        self.set_issue()

        get_property_group(
            any_group.step_key
        ).widget_d[ok.FONT_SIZE].relay += [self.on_font_size_change]
        planner = get_planner(any_group.step_key)
        self.is_planned = planner.get_option_a(key)
        self.handle_d[
            planner.connect(fy.SIGNAL_D[key], self.on_plan_option_change)
        ] = planner

    def do(self, v):
        """
        Manage layer output for a View run.

        v: View
        """
        self.go = self.is_planned
        self.is_matter |= self.is_switched or self.super_maya.is_matter

        self.realize(v)
        self.reset_issue()

    def on_plan_option_change(self, _, arg):
        """
        Receive a Signal when the Plan option
        is activated. Update the 'go' dependency
        with 'self.is_planned'.

        _: PlanOption
            Sent the signal.

        arg: tuple
            (the value of the Margin CheckButton, its change state)
        """
        self.is_planned, self.is_switched = arg

    def on_font_size_change(self, g):
        """
        Respond to change in the Font Size Widget value.

        g: Widget
            Font Size
        """
        a = self.font_size
        self.font_size = g.get_a()
        self.is_matter = a != self.font_size


class PlanMargin(Maya):
    """Manage Margin dependent layer output for Plan."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, super_maya, do_matter):
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter

        Maya.__init__(
            self, any_group, 0, ((check_matter, 'matter'),), k_path=NO_VOTE
        )
        self.set_issue()

        planner = get_planner(any_group.step_key)
        self.is_planned = planner.get_option_a(ak.MARGIN)
        self.handle_d[
            planner.connect(fy.SIGNAL_D[ak.MARGIN], self.on_plan_option_change)
        ] = planner

    def do(self, v):
        """
        Manage layer output for a View run.

        v: View
        """
        self.go = self.is_planned and self.super_maya.value_d[ok.SWITCH]
        self.is_matter = self.is_switched or self.super_maya.is_matter

        self.realize(v)
        self.reset_issue()

    def on_plan_option_change(self, _, arg):
        """
        Receive a Signal when the Planner Margin option is modified.

        _: PlanOption
            Sent the signal.

        arg: tuple
            (the value of the Margin CheckButton, its change state)
        """
        self.is_planned, self.is_switched = arg


class PlanShape(Maya):
    """Manage Cell/Shape layer output for Plan."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, super_maya, do_matter):
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter

        Maya.__init__(
            self, any_group, 0, ((check_matter, 'matter'),), k_path=NO_VOTE
        )
        self.set_issue()

        planner = get_planner(any_group.step_key)
        self.is_planned = planner.get_option_a(ak.CELL_SHAPE)
        self.handle_d[
            planner.connect(
                fy.SIGNAL_D[ak.CELL_SHAPE], self.on_plan_option_change
            )
        ] = planner

    def do(self, v):
        """
        Manage a Plan Cell-branch shape layer for a View run.

        v: View
        """
        self.go = self.is_planned
        self.is_matter = self.is_switched or self.super_maya.is_matter

        self.realize(v)
        self.reset_issue()

    def on_plan_option_change(self, _, arg):
        """
        Receive a Signal when the Plan option is activated.
        Update the 'go' dependency with 'self.is_planned'.

        _: PlanOption
            Sent the signal.

        arg: tuple
            (the value of the Margin CheckButton, its change state)
        """
        self.is_planned, self.is_switched = arg
