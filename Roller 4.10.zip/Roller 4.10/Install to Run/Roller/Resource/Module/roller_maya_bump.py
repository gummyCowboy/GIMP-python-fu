#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Bump as fb
from roller_constant_key import Option as ok
from roller_frame_build import SubBuild
from roller_maya import check_cake, check_matter
from roller_fu import clone_layer, clone_opaque_layer
from roller_one_gegl import engrave, video_degradation
from roller_view_real import clip_to_wip, mask_sub_maya
import gimpfu as fu

pdb = fu.pdb
NOISE_WIP = "Noise WIP"


def do_bump_matter(v, maya):
    """
    Make a Bump layer.

    Return: layer or None
        with Bump material
    """
    def _clone():
        _z = clone_opaque_layer(z, n="Bump")
        clip_to_wip(v, _z)
        return _z

    z = maya.super_maya.matter
    d = maya.value_d
    z1 = None

    if z:
        j = z.image
        noise = d[ok.NOISE]
        n = d[ok.BUMP_TYPE]
        elevation = v.glow_ball.elevation
        azimuth = v.glow_ball.azimuth

        if n == fb.NANO:
            z1 = _clone()

            video_degradation(z1, 'dots')

            z2 = clone_layer(z1, n="Nano Bump WIP #2")
            z2.mode = fu.LAYER_MODE_DIFFERENCE

            engrave(z2, 3)
            pdb.gimp_drawable_curves_spline(
                z2,
                fu.HISTOGRAM_VALUE,
                4,
                (.0, .5, 1., 1.)
            )
            z1 = pdb.gimp_image_merge_down(j, z2, fu.CLIP_TO_IMAGE)

        if n in fb.HAS_NOISE:
            if noise:
                if not z1:
                    z1 = _clone()

                # red, green, and blue noise, 'noise'
                pdb.plug_in_rgb_noise(
                    j, z1,
                    1,                  # independent
                    0,                  # not correlated
                    noise,
                    noise,
                    noise,
                    .0                  # zero noise
                )

        elif n == fb.CROSSHATCH:
            if not z1:
                z1 = _clone()
            pdb.plug_in_gimpressionist(j, z1, "Crosshatch")

        else:
            if not z1:
                z1 = _clone()
            pdb.script_fu_clothify(
                j, z1,
                d[ok.BLUR_X], d[ok.BLUR_Y],
                azimuth,
                max(min(elevation, 90.), 1.),
                min(d[ok.BUMP_DEPTH], 50.)
            )

        if n in fb.HAS_INVERT:
            if d[ok.INVERT]:
                pdb.gimp_drawable_invert(z1, 0)

        if not z1:
            z1 = _clone()

        # emboss, '1'
        pdb.plug_in_emboss(j, z1, azimuth, elevation, d[ok.BUMP_DEPTH], 1)

        z1.name = z.name + " Bump"
    return z1


class Bump(SubBuild):
    """Manage Bump layer output for a Bump Preset."""
    is_embossed = True
    issue_q = 'cake', 'matter'
    put = (check_matter, 'matter'), (check_cake, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            enclosing Maya

        k_path: tuple or list
            (Option key, ...)
        """
        self.do_matter = do_bump_matter
        SubBuild.__init__(self, any_group, super_maya, k_path)

    def do(self, v, d, is_change):
        """
        Manage layer output during a View run.

        v: View
        d: dict or None
            Bump Preset
            Maybe None if 'go' is False.

        is_change: bool
            Is True if the source layer for the Bump material has changed.
        """
        self.value_d = d
        self.go = d[ok.SWITCH]

        if self.go:
            self.is_matter |= is_change

        self.realize(v)

        if self.go and self.is_matter:
            mask_sub_maya(self.super_maya.matter, self.matter)
        self.reset_issue()
