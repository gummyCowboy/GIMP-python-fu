#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Frame as ff, Widget as fw
from roller_constant_key import (
    Group as gk, Node as ny, Option as ok, Step as sk
)
from roller_one_extract import get_option_list_key
from roller_one_the import The
from roller_port_process import PortProcess
from roller_port_tree import MAIN_TREE
from roller_widget_node_panel import NodePanel
from roller_port_save import save_file
import gimpfu as fu

pdb = fu.pdb


def do_render():
    """
    Complete the render with a final view run.

    Return: dict
        {navigation step key: value dict}
        from View
    """
    cat = The.cat
    d, e = The.view.do_render()

    if cat.render.has_image:
        j = cat.render.image()
        if j.layers:
            z = j.layers[-1].layers[-1]
            z.name = "Backdrop Image Finish"
            z1 = The.view.plan.plan_group

            if z1:
                z1.name = z1.name.split(":")[0]

            j.active_layer = z
            pdb.gimp_selection_none(j)
    return d, e


def find_option(d, k, q):
    """
    Fetch an option from a dict where the option location varies.

    d: dict
        with option

    k: string
        key of option to find

    q: iter
        (option key,)
        Has sub-key, k.

    Return: dict or None
        option
    """
    a = d.get(k)

    if a:
        return a
    for i in q:
        a = d.get(i)
        if a:
            return a[k]


class PortMain(PortProcess):
    """Is a display container for the main Window."""

    def __init__(self, d):
        """Make a navigation tree."""

        # When equal to None, identify MainPort, 'self.safe'.
        self._node_panel = NodePanel(d, self.on_port_change)

        PortProcess.__init__(self, d, None)

        The.load_count += 1

        self.draw()
        self._load_steps()
        The.load_count -= 1

    def _load_steps(self):
        """Load the steps from the previous session."""
        # Use the Steps SuperPreset to load the last used file.
        g = The.helm.get_group(sk.PRESET_STEPS).widget_d[ok.PRESET]
        self._last_session = deepcopy(g.load_file(
            fw.LAST_USED, g.any_group.item.key
        ))

    def _write_last_used(self, d, e):
        """
        Write Last Used Preset for the session.

        d: OrderedDict
            Is the Steps SuperPreset.
            {step key: group value dict}

        e: OrderedDict
            Is a navigation tree value dict.
            {step key: group value dict}
        """
        def _get_frame(_d):
            """
            Find the Frame dict in a Preset.
            The Preset may not have the option.

            _d: dict
                Preset

            Return: dict or None
                Frame Preset
            """
            if ok.SWITCH in _d and _d[ok.SWITCH]:
                _e = find_option(_d, ok.FRAME, ff.FRAME_ROW)
                if _e and _e[ok.SWITCH]:
                    return _e

        def _write(_d, _group_key):
            """
            _d: dict
                data to write

            _group_key: string
                Identify Preset storage folder.
            """
            return save_file(
                None,
                _d,
                _group_key,
                fw.LAST_USED,
                overwrite=True
            )

        # Break on error flag, 'go'.
        go = True

        if e != self._last_session:
            go = _write(d, gk.PRESET_STEPS)

        if go:
            # Has group key of Preset group type.
            # Use to filter out duplicate group key
            # in the navigation tree dict, 'e'.
            # {group key: group value dict}
            last_d = {}

            get_group = The.helm.get_group
            for step_key, value in e.items():
                any_group = get_group(step_key)
                if any_group:
                    if any_group.item.group_type == 'preset':
                        # Presets are identified by their group key.
                        # Replace a previous value if it exists.
                        last_d[step_key[-1]] = value

                        # Save Frame Preset.
                        frame = _get_frame(value)
                        if frame:
                            k = get_option_list_key(frame)
                            last_d[k] = frame[k]

            # Write a Last Used Preset for each item in the collected Preset.
            for item_key, value in last_d.items():
                if go:
                    # Presets are distinguished by their key.
                    go = _write(value, item_key)

        # Save the Backdrop Style
        style = d[sk.BACKDROP][ok.BACKDROP_STYLE]
        if style[ok.SWITCH]:
            k = get_option_list_key(style)
            _write(style[k], k)

    def accept_main_port(self, *_):
        """
        Begin a render.

        Return: true
            The keypress is handled.
        """
        if The.helm.get_group(sk.GLOBAL).widget_d[ok.DELETE_PLAN].get_a():
            The.view.plan.delete()

        else:
            The.view.plan.delete_backdrop()

        The.power.press()
        self._write_last_used(*do_render())
        return True

    @staticmethod
    def cancel_main_port(*_):
        """
        Close the Window.

        Return: true
            The keypress is handled.
        """
        # ImageGradient may have produced a gradient.
        The.image_gradient_used = None

    def draw(self):
        """Draw the Port's Widgets."""
        self.draw_row((self.draw_navigation, self.draw_process))

    def draw_navigation(self, g):
        """
        Draw a navigation tree.

        g: GTK container
            to receive a group of Widgets
        """
        g.add(self._node_panel)
        self._node_panel.create_node(MAIN_TREE, ny.STEPS, sk.STEPS, None, 0)

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return self.cancel_main_port, self.accept_main_port
