#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import Option as ok
from roller_fu import clone_layer, merge_layer_group
from roller_maya_style import Style, make_background
from roller_one_the import get_factor_w, get_factor_h
from roller_one_gegl import cubism, median_blur, neon, pixelize
from roller_view_real import add_sub_base_group, finish_style
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: PaperWaste
    Return: layer
        with the style material
    """
    d = maya.value_d
    z = make_background(v, maya, d)
    parent = add_sub_base_group(v, maya, z)
    w = max(1, get_factor_w(d[ok.BLOCK_W]))
    h = max(1, get_factor_h(d[ok.BLOCK_H]))
    z1 = clone_layer(z, n="Curvy")

    # background color, 'z'
    pixelize(z, v.wip.w, v.wip.h)

    # shredded curvy edge with alpha holes, 'z1'
    pixelize(z1, w, h)
    median_blur(z1, int((w + h) / 4), 50.)
    cubism(z1, 9., 3.)
    cubism(z1, 6., 3.)
    cubism(z1, 3., 3.)

    # bumpy paper stack, 'z2'
    z2 = clone_layer(z1, n="Bumpy")

    neon(z2, 5., .0)

    z2.mode = fu.LAYER_MODE_GRAIN_EXTRACT
    z2.opacity = 50.
    return finish_style(merge_layer_group(parent), "Paper Waste")


class PaperWaste(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BBR

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        self.init_background(make_style, *q, **d)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.
        """
        self.is_dependent = \
            d[ok.BBR][ok.BACKGROUND][ok.BACKDROP_TYPE] == bs.BACKDROP_IMAGE
        super(PaperWaste, self).do(v, d, is_change)
