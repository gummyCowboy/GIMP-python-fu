#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok, Step as sk, Widget as wk
from roller_one_the import The
import gimpfu as fu

pdb = fu.pdb


def find_visible_preset():
    """
    Find the navigation step key of the visible Preset AnyGroup.
    A terminal group in the navigation tree is not a Node.

    Return: tuple
        (item key, ...)
    """
    def _shoot(_group, _go):
        """
        Find the step key of the visible selected AnyGroup.

        _group: AnyGroup
            Has item.

        _go: bool
            If True, then the last
        """
        _step_k = None

        if _go:
            _node = _group.item.node
            _x = _node.get_sel_x()
            _x = 0 if _x is None else _x
            _item = _node.get_branch(_x)
            _step_k = _item.any_group.step_key

            if _item.group_type != 'node':
                _go = False
            else:
                _group1 = get_group(_step_k)
                if _group1.item.node:
                    _go, _step_k = _shoot(_group1, _go)
        return _go, _step_k

    get_group = The.helm.get_group
    return _shoot(get_group(sk.STEPS), True)[1]


def get_model_list_group():
    """
    Fetch the AnyGroup of the ModelList.

    Return: AnyGroup or None
        the ModelList group
    """
    return The.helm.get_group(sk.MODEL)


def get_model_name_list():
    """
    Compile a list of Model names appearing in the navigation tree.

    Return: list
        of Model name
    """
    a = The.helm.get_group(sk.EXTRA)
    return a.widget_d[ok.NODE].get_label_q()[1:]


def get_node_row(d):
    """
    Make a list of selected Node row from a SuperPreset.
    Remove Node reference from the SuperPreset.

    d: dict
        SuperPreset type

    Return: list
        [(AnyGroup with Node, row index)]
    """
    q = []
    get_group = The.helm.get_group

    # value dict, 'e'
    for step_key in d.keys():
        any_group = get_group(step_key)
        if any_group:
            e = d[step_key]

            if e:
                for k, a in e.items():
                    # A loaded Node has a selected
                    # row item in its value dict.
                    if k == 'node':
                        d.pop(step_key)
                        if a and any_group.item.node:
                            # (Node, row index)
                            q += [(any_group.item.node, a[sk.SELECTED_ROW])]
            else:
                # The default Node value is None.
                d.pop(step_key)
    return q


def get_option_list_key(d):
    """
    Find the choice key in a OptionList Preset.

    d: dict
        OptionList Preset

    Return: string or None
        key to the option in the OptionList Preset
        Is None if there is a failure as in an empty dict.
    """
    k = None

    for k in d:
        if k != ok.SWITCH:
            break
    return k


def get_option_list_choice(d):
    """
    Fetch an OptionList key and the option's dictionary.

    d: dict
        Backdrop Style or Frame Preset

    Return: tuple
        (Preset key, Preset value dict)
    """
    k = get_option_list_key(d)
    return k, d[k]


def scour(d, e, seek):
    """
    Recursively peruse a group definition dict collecting Widget init value.

    d: dict
        Reflect group tree structure.
        {option key: option value or dict of option value}

    e: dict
        Is an option group definition.

    seek: string
        Is the option key to collect in the data definition tree.

    Return: dict
        with option value
    """
    for i, a in e.items():
        if isinstance(a, dict):
            if seek in a:
                d[i] = a[seek]
            else:
                if i == wk.SUB:
                    # The SUB key is not part of the value dict.
                    b = d
                else:
                    b = d[i] = {}

                scour(b, a, seek)
                if not b and i in d:
                    d.pop(i)
    return d
