#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok, Step as sk
from roller_fu import (
    clone_layer,
    get_layer_offset,
    make_layer_group,
    merge_layer_group,
    set_layer_mode,
    verify_layer
)
from roller_view_hub import do_shade
import gimpfu as fu

pdb = fu.pdb


def do_shadow_preset(j, d, outer_cast, inner_cast, parent):
    """
    Make up to three shadow layers.

    d: dict
        Shadow SuperPreset

    outer_cast: tuple
        of layers to pass to Shadow #1 and Shadow #2

    inner_cast: tuple
        of layers to pass to InnerShadow.

    parent: layer group
        Where the shadow layer is placed.

    Return: list
        of layer with shadow material
    """
    make_shadow(
        j,
        d[sk.SHADOW_1],
        parent,
        outer_cast,
        name=parent.name + " Shadow 1"
    )
    make_shadow(
        j,
        d[sk.SHADOW_2],
        parent,
        outer_cast,
        name=parent.name + " Shadow 2"
    )
    make_shadow(
        j,
        d[sk.INNER_SHADOW],
        parent,
        inner_cast,
        name=parent.name + " Inner Shadow",
        is_inner=True
    )


def make_shadow(j, d, parent, cast, is_inner=False, name=None, is_wrap=False):
    """
    Make a shadow.

    j: GIMP image
        WIP

    d: dict
        Shadow Preset
        {Option key: value}

    parent: layer group
        Has name and position.

    cast: tuple or list
        of layer to cast shadow

    is_inner: bool
        If true, the shadow-type is an Inner Shadow.

    name: string or None
        Use to name the output layer.

    is_wrap: bool
        If True, an outer Shadow is placed at the bottom of the parent group.

    Return: layer
        with shadow
    """
    def _make_shadow_unit():
        """
        Create a unified shadow layer out of multiple layers.

        Return: layer
            a unified shadow layer
        """
        def _process(_z_):
            _z1_ = clone_layer(_z_, no_mask=False)
            _z1_.opacity = _z_.opacity
            pdb.gimp_image_reorder_item(j, _z1_, _group, 0)

        _group = make_layer_group(j, "Unit", parent=parent)

        [_process(_z)for _z in cast if _z]
        return merge_layer_group(_group)

    if cast and d[ok.INTENSITY]:
        # a layer of merged layers to cast a shadow together, 'unit_z'
        unit_z = _make_shadow_unit()

        if is_inner:
            # Inner Shadow type
            x = y = 0
            blur = d[ok.INNER_BLUR]

        else:
            blur = d[ok.SHADOW_BLUR]
            x = d[ok.OFFSET_X]
            y = d[ok.OFFSET_Y]

        z = do_shade(
            unit_z,
            x, y,
            blur,
            d[ok.SHADOW_COLOR],
            d[ok.INTENSITY],
            is_inner=is_inner
        )

        pdb.gimp_image_remove_layer(j, unit_z)

        z = verify_layer(z)

        if z:
            if is_inner:
                a = get_layer_offset(cast[0])

            elif is_wrap:
                a = len(parent.layers)

            else:
                # Put the shadow layer below the lowest shadow caster.
                a = 0
                for i in cast:
                    b = get_layer_offset(i) + 1
                    if b > a:
                        a = b
            pdb.gimp_image_reorder_item(j, z, parent, a)

        pdb.gimp_selection_none(j)

        if z:
            if name is not None:
                z.name = name
            pdb.gimp_layer_resize_to_image_size(z)
        return z


def make_shadow1(j, d, parent, cast, is_inner=False, name=None, offset=0):
    """
    Make a shadow.

    j: GIMP image
        WIP

    d: dict
        Shadow Preset

    parent: layer group
        Has name and position.

    cast: tuple or list
        of layer to cast shadow

    is_inner: bool
        If true, the shadow-type is an Inner Shadow.

    name: string or None
        Use to name the output layer.

    offset: int
        for inner shadow.
        Is for its layer position.

    Return: layer
        with shadow
    """
    def _make_shadow_unit():
        """
        Create a unified shadow layer out of multiple layers.

        Return: layer
            a unified shadow layer
        """
        def _process(_z_):
            _z_ = clone_layer(_z_)

            set_layer_mode(_z_, fu.LAYER_MODE_NORMAL)
            pdb.gimp_image_reorder_item(j, _z_, _group, 0)

        _group = make_layer_group(j, "Unit", parent=parent)

        [_process(_z)for _z in cast if _z]
        return merge_layer_group(_group)

    if cast and d[ok.INTENSITY]:
        # a layer of merged layers to cast a shadow together, 'unit_z'
        unit_z = _make_shadow_unit()

        if is_inner:
            # Inner Shadow type
            x = y = 0
            blur = d[ok.INNER_BLUR]

        else:
            blur = d[ok.SHADOW_BLUR]
            x = d[ok.OFFSET_X]
            y = d[ok.OFFSET_Y]

        z = do_shade(
            unit_z,
            x, y,
            blur,
            d[ok.SHADOW_COLOR],
            d[ok.INTENSITY],
            is_inner=is_inner
        )

        pdb.gimp_image_remove_layer(j, unit_z)

        if z:
            if offset or is_inner:
                a = offset

            else:
                a = 0

                # Put the shadow layer below the lowest shadow caster.
                for i in cast:
                    b = get_layer_offset(i) + 1
                    if b > a:
                        a = b
            pdb.gimp_image_reorder_item(j, z, parent, a)

        pdb.gimp_selection_none(j)

        if z:
            if name is not None:
                z.name = name
            pdb.gimp_layer_resize_to_image_size(z)
        return z
