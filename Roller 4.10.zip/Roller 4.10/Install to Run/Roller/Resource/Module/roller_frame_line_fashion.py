#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Metal, do_soft_metal_material
from roller_fu import (
    add_layer, color_fill_selection, copy_all_image, select_rect
)
from roller_view_hub import fill_with_clipboard
import gimpfu as fu

pdb = fu.pdb


def make_pattern(z, d):
    """
    Make a Line Fashion pattern.

    z: layer
        to receive pattern

    d: dict
        Line Fashion Preset
        {Option key: value}

    Return: layer
        Has material to select.
    """
    w = d[ok.LINE_W]
    w1 = d[ok.GAP_W] + w
    j1 = pdb.gimp_image_new(w1, w1, fu.RGB)
    z1 = add_layer(j1, "Pattern")
    y = (w1 - w) // 2

    select_rect(j1, 0, y, w1, w)
    color_fill_selection(z1, (0, 0, 0))

    # Set the Clipboard Image.
    copy_all_image(j1)

    pdb.gimp_image_delete(j1)
    fill_with_clipboard(z)
    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: LineFashion
    Return: layer
        with the frame
    """
    return do_soft_metal_material(v, maya, make_pattern, "Line Fashion")


class LineFashion(Metal):
    """Is a metallic frame with striped plating."""

    def __init__(self, *q, **d):
        """
        q: tuple
            Metal spec
        """
        Metal.__init__(self, *q + (do_matter,), **d)
