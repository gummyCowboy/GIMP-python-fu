#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from roller_constant_key import (
    Group as gk, Item as ie, Option as ok, Step as sk, Widget as wk
)
from roller_one_the import The


def collect_step(d, render_key, step_q):
    """
    Recursively add navigation step key found in
    a hierarchical step dict to a list.

    d: dict
        with step key structure

    step_key: tuple
        (item, ...)

    step_q: list
        step key collection
    """
    k = render_key[-1]
    step_q += [render_key]
    if wk.ITEM in d[k]:
        for k1 in d[k][wk.ITEM]:
            collect_step(
                d[k][wk.ITEM],
                render_key + (k1,),
                step_q
            )


def extract_value_d(step_key, d):
    """
    Get the Widget value dict for an AnyGroup.

    step_key: tuple
        sequenced navigation Node

    d: dict
        Has an AnyGroup value for the step key.

    Return: dict
        {Option key: Widget value}
    """
    any_group = d[step_key] if step_key in d else None
    if any_group:
        return any_group.get_value_d()


def find_canvas_margin(step_key):
    """
    For a Model, determine if a Canvas Margin step is online.

    step_key: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(step_key, (ie.CANVAS, ie.MARGIN)))


def find_canvas_shift(step_key):
    """
    For a Model, determine if a Canvas Shift step is online.

    step_key: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(step_key, (ie.CANVAS, ie.SHIFT)))


def find_cell_margin(step_key):
    """
    For a Model, determine if a Cell Margin step is online.

    step_key: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(step_key, sk.CELL_MARGIN))


def find_cell_shift(step_key):
    """
    For a Model, determine if a Cell Shift step is online.

    step_key: tuple
        Has a Model id reference.

    Return: bool
        Is True if the step is in navigation tree.
    """
    return The.helm.finds(make_model_key(step_key, sk.CELL_SHIFT))


def get_branch_value_d(step_key):
    """
    Get a SuperPreset value dict.

    step_key: tuple
        SuperPreset key in step dict

    Return: dict
        {step key: value}
    """
    d = {}
    helm = The.helm
    get_group = helm.get_group
    q = helm.get_branch_step_q(step_key)

    for i in q:
        a = get_group(i)
        if a.item.group_type in ('node', 'preset'):
            d[i] = a.get_value_d()
    return d


def get_cell_shift(step_key):
    """
    Get a Cell Shift Preset value dict.

    step_key: tuple
        Has a Model reference.

    Return: dict
        Shift Preset
    """
    any_group = The.helm.get_group(make_model_key(step_key, sk.CELL_SHIFT))
    if any_group:
        return any_group.get_value_d()


def get_planner(step_key):
    """
    Get a Model's Cell / Rectangle Preset value dictionary.

    step_key: tuple
        Is a navigation step key with a Model id reference.
    """
    return get_property_group(step_key).widget_d[ok.PLANNER]


def get_model(step_key):
    """
    Return the Model instance for a step key. If the step key
    is not part of a Model branch, then return None.

    step_key: tuple
        step key
        Has a Model id in position one.

    Return: Model instance or None
    """
    if len(step_key) > 1:
        return The.model_id.get_model(step_key[1])


def get_model_branch(step_key):
    """
    Clip the branch from a step key.

    step_key: tuple
        navigation step key

    Return: tuple
        any -> (Node key,), (Group key,), (Node key, Group key)
    """
    return step_key[2:]


def get_parent_node(step_key):
    """
    Get the Node of a branched AnyGroup.
    The Node may not be in the interface step dict.

    step_key: tuple
        of the branch group

    Return: Node or None
        for the branch group
    """
    k = step_key[:-1]
    any_group = The.helm.get_group(k)
    if any_group:
        return any_group.item.node


def get_property_group(step_key):
    return The.helm.get_group(make_model_key(step_key, (ie.PROPERTY,)))


def get_step_d(step_q):
    """
    Get the navigation step key dict of a navigation step key list.

    step_q: list
        [step key]

    Return: dict
        {step key: value dict}
    """
    # steps in the View, {step key: option value dict}, 'step_d'
    step_d = OrderedDict()
    get_group = The.helm.get_group

    for i in step_q:
        # AnyGroup, 'a'
        a = get_group(i)

        # Is a terminal point of this branch.
        if a.item.group_type in ('node', 'preset'):
            step_d[i] = a.get_value_d()
    return step_d


def make_model_key(k, q):
    """
    Given a Model branch key, append a key to it.

    k: tuple
        Is a Model branch.

    q: tuple
        any -> (Node key,), (Group key,), (Node key, Group key)
    """
    # A Model branch is made of two items, '2'.
    return k[:2] + q


def make_panel_key(step_key, model_name=None):
    """
    Make a panel-usable key from a step key.
    Swap the Model id with a Model name.

    step_key: tuple
        for AnyGroup

    model_id: string or None
        Use to prefetch the Model name.

    Return: tuple
        NodePanel usable key
    """
    a = len(step_key)

    if a < 2:
        # no Model
        return step_key

    if model_name is None:
        model_name = The.model_id.get_name(step_key[1])

    if model_name:
        return step_key[:1] + (model_name,) + step_key[2:]

    # no model
    return step_key


def make_render_key(step_key, model_type):
    """
    Make a render key from a step key. This is done
    by swapping the Model id for a Model type.

    render_key: tuple
        for AnyGroup

    model_type: string
        Model type key
    """
    a = len(step_key)

    if a <= 1:
        # no Model
        return step_key

    elif a == 2 and step_key[1] == gk.MODEL:
        # no Model
        return step_key
    return step_key[:1] + (model_type,) + step_key[2:]


def make_step_key(key):
    """
    Make a navigation step key from a render key. This
    is done by swapping the Model type with a Model id.

    key: tuple
        for AnyGroup
        panel key

    Return: tuple
        step_key
    """
    a = len(key)

    if a <= 1:
        # no Model
        return key

    elif a == 2 and key[-1] == gk.MODEL:
        # no Model
        return key

    model_id = The.model_id.get_id(key[1])

    if model_id:
        return key[:1] + (model_id,) + key[2:]

    # no model
    return key


def translate_to_id(d):
    """
    For a SuperPreset, translate a Model name to a Model id.

    d: dict
        of SuperPreset

    n: string
        Model name

    identity: int
        Is unique to a Model.

    Return: dict
        with step having translated name to identity
    """
    e = {}

    for k in d:
        e[make_step_key(k)] = d[k]
    return e


def translate_to_name(d):
    """
    For a SuperPreset, replace numeric Model id
    with its corresponding Model name.

    d: dict
        of steps

    Return: dict
        with translation
    """
    e = {}

    for i, a in d.items():
        e[make_panel_key(i)] = a
    return e
