#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice, randint
from roller_constant_for import Frame as ff, Model as mo
from roller_constant_key import Group as gk, Option as ok
from roller_frame_build import Build, SubBuild
from roller_def import get_default_value
from roller_fu import (
    blur_selection,
    clear_selection,
    clear_inverse_selection,
    clone_layer,
    color_fill_selection,
    color_fill_layer,
    load_selection,
    merge_layer,
    remove_z,
    select_item,
    select_opaque,
    select_rect,
    verify_layer
)
from roller_maya import (
    check_cake,
    check_color,
    check_filler,
    check_frame_cake,
    check_color_style,
    check_filler_cake,
    check_matter,
    check_metal_frame_cake,
    check_shadow,
    make_filler_group,
    make_frame_group
)
from roller_maya_blur_behind import BlurBehind
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_one import hsv_to_rgb, rgb_to_hsv
from roller_one_gegl import (
    edge, median_blur, neon, noise_rgb, saturation, waterpixels
)
from roller_view_preset import combine_seed
from roller_view_real import (
    COLOR,
    FILLER,
    LIGHT,
    add_base_layer,
    add_wip_layer,
    do_rotated_layer,
    get_light,
    mask_sel,
    mask_sub_maya
)
from roller_view_shadow import make_shadow
import gimpfu as fu

COLOR_TO_ALPHA = (
    (0, 0, 0),
    (255, 0, 0),
    (0, 255, 0),
    (0, 0, 255),
    (255, 255, 255)
)
pdb = fu.pdb


def do_filler_frame(v, maya):
    """
    Make an inner and outer metallic frame.

    v: View
    maya: Frame
    Return: layer
        with the frame
    """
    d = maya.value_d
    e = d[ok.FNR][ok.FRAME_METAL]
    j = v.j
    group = maya.group
    cause = maya.cause.matter

    # layer for the emboss, 'z'
    z = add_wip_layer(v, maya, maya.FRAME_K, group, offset=get_light(maya))

    # Grow the selection for each frame part.
    select_item(cause)
    grow_frame(j, e[ok.FRAME_W], e[ok.FRAME_TYPE])

    # inner frame selection, 'sel'
    sel = pdb.gimp_selection_save(j)

    grow_frame(j, d[ok.WIDTH], e[ok.FRAME_TYPE])

    # inner and filler frame selection, 'sel1'
    sel1 = pdb.gimp_selection_save(j)

    grow_frame(j, e[ok.FRAME_W], e[ok.FRAME_TYPE])

    # inner, filler, and outer selection, 'sel2'
    sel2 = pdb.gimp_selection_save(j)

    load_selection(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

    # outer frame selection, 'sel3'
    sel3 = pdb.gimp_selection_save(j)

    load_selection(j, sel1)
    load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

    # Cover the emboss on the inner and outer frame.
    grow_frame(j, 1, ff.ANGULAR)

    # filler selection
    if maya.filler_sel:
        pdb.gimp_image_remove_channel(v.j, maya.filler_sel)

    maya.filler_sel = pdb.gimp_selection_save(j)

    # Make inner frame selection.
    load_selection(j, sel)
    select_item(cause, option=fu.CHANNEL_OP_SUBTRACT)
    load_selection(j, sel3, option=fu.CHANNEL_OP_ADD)

    soften_metal_sel(v, z, e)

    for i in (sel, sel1, sel2, sel3):
        pdb.gimp_image_remove_channel(j, i)
    return z


def do_ink_noise(v, d, z):
    """
    Make Ink Noise for a frame.

    v: View
    maya: Maya
        frame variety

    d: dict
        Metal Noise Preset

    z: layer
        WIP

    Return: layer
        with noise
    """
    pdb.plug_in_plasma(
        v.j, z,
        d[ok.SEED] + v.glow_ball.seed,
        1.                      # lowest turbulence
    )
    z.opacity = 100.
    name = z.name

    pdb.gimp_drawable_posterize(z, 3)
    neon(z, 1., 1.)
    pdb.plug_in_colortoalpha(v.j, z, (0, 0, 0))

    z1 = clone_layer(z)
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    blur_selection(z, 1.5)

    z = merge_layer(z1)
    z.name = name

    median_blur(z, 3, 50.)
    return z


def do_noise_matter(v, maya):
    """
    Create a metal noise layer.

    v: View
    maya: Maya
    Return: layer
        with noise
    """
    d = maya.value_d
    group = maya.super_maya.group
    z = add_wip_layer(
        v,
        maya,
        "Noise",
        group=group,
        offset=get_light(maya.super_maya)
    )

    pdb.gimp_selection_none(v.j)

    z = {
        ff.INK: do_ink_noise,
        ff.RIFT: do_rift_noise,
        ff.SPECK: do_speck_noise,
        ff.WATER: do_water_noise
    }[d[ok.NOISE_TYPE]](v, d, z)
    return z


def do_rift_noise(v, d, z):
    """
    Make Rift Noise for a frame.

    v: View
    d: dict
        Metal Noise Preset

    z: layer
        WIP

    Return: layer
        with noise
    """
    j = v.j

    combine_seed(v, d)

    # Generate line.
    # The horizontal and vertical sizes are randomized.
    pdb.plug_in_solid_noise(
        j, z,
        0,                      # no tile-able
        1,                      # yes, turbulent
        d[ok.SEED] + v.glow_ball.seed,
        d[ok.NOISE_AMOUNT],
        float(randint(1, 4)),
        float(randint(1, 4)),
    )

    # Harden the noise.
    # The radius is randomized.
    pdb.plug_in_unsharp_mask(
        j, z,
        choice((1., 4.)),
        54.,                    # amount
        .0                      # threshold
    )

    if d[ok.BLUR]:
        blur_selection(z, d[ok.BLUR])

    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
    return z


def do_selection_material(v, maya, do_sel, embellish, n, is_clear=True):
    """
    Process the material for a frame.

    v: View
    maya: Maya

    do_sel: function
        Call to process selection.

    embellish: function
        Call to process the material layer.

    n: string
        group key
        layer name appendix

    is_clear: bool
        If True, then a cause layer alpha
        selection is removed from the output layer.

    Return: layer or None
        with material
    """
    j = v.j
    model = maya.model
    super_ = maya.cause
    cause = super_.matter
    z = add_base_layer(v, maya.group, n=n)

    if super_.cell_type == mo.MAIN:
        cause = super_.matter
        for r, c in super_.main_cell_q:
            maya.r_c = r, c
            sel = model.get_image_sel((r, c))

            load_selection(j, sel)

            if cause.mask:
                pdb.gimp_image_select_item(
                    j, fu.CHANNEL_OP_INTERSECT, cause.mask
                )
            if not pdb.gimp_selection_is_empty(j):
                z = do_sel(v, maya, z)

    else:
        maya.r_c = super_.r_c

        select_item(cause)
        if not pdb.gimp_selection_is_empty(j):
            z = do_sel(v, maya, z)

    if is_clear:
        select_item(cause)
        clear_selection(z)

    z = verify_layer(z)

    if z:
        z = embellish(v, maya, z)
    return z


def do_shadow(v, maya):
    """
    Do the shadow process for the cause material.

    v: View
    maya: Maya
        Frame type

    Return: layer or None
        with shadow
    """
    d = get_default_value(gk.SHADOW_1)
    frame = maya.super_maya
    cause = frame.cause
    group = cause.group.parent

    d.update(maya.value_d)

    z = make_shadow(
        v.j,
        d,
        group,
        (cause.matter,),
        name=group.name + " Shadow",
        is_wrap=True
    )

    select_opaque(frame.matter)

    if z:
        clear_selection(z)
    return z


def do_soft_metal_material(v, maya, make_pattern, n):
    """
    Make a metallic frame.

    v: View
    maya: Frame
    n: string
        group key
        Use to name layer.

    Return: layer or None
        with the Frame
    """
    def _draw(_z):
        """
        Return a layer with pattern.

        _z: layer
            Maya matter layer
        """
        return do_rotated_layer(
            v, d, make_pattern, maya.group, len(maya.group.layers) - 1
        )

    d = maya.value_d
    j = v.j
    cause = maya.cause.matter

    # Add a pattern layer to the bottom of the Maya's group layer, 'z'.
    z = add_wip_layer(
        v, maya, n, maya.group, offset=len(maya.group.layers)
    )
    make_pattern_frame(j, cause, d, _draw)
    return soften_metal_sel(v, z, d[ok.FNR][ok.FRAME_METAL])


def do_speck_noise(v, d, z):
    """
    Make Speck Noise for a frame.

    v: View
    d: dict
        Metal Noise Preset
        {Option key: value}

    z: layer
        WIP

    Return: layer
        with noise
    """
    j = v.j
    name = z.name

    combine_seed(v, d)

    z1 = clone_layer(z)
    f = (d[ok.SPECK_NOISE] + .5) / 7.

    # red, green, and blue noise, 'noise'
    pdb.plug_in_rgb_noise(
        j, z1,
        1,                  # independent
        0,                  # not correlated
        .0,
        .0,                # green
        .0,                # blue
        f
    )

    color_fill_layer(z, (255, 255, 255))

    z = merge_layer(z1)

    for i in range(4):
        pdb.plug_in_erode(
            j, z,
            1,                # propagate black
            7,                # RGB channels
            1.,               # full rate
            0,                # direction mask
            0,                # lower limit
            12                # upper limit
        )
        pdb.plug_in_rgb_noise(
            j, z,
            1,                # independent
            0,                # not correlated
            f,                # red
            f,                # green
            f,                # blue
            .0
        )

    pdb.plug_in_colortoalpha(v.j, z, (255, 255, 255))
    saturation(z, .25)
    edge(z)
    blur_selection(z, 1.)
    pdb.plug_in_despeckle(
        j, z,
        1,                      # radius
        3,                      # recursive adaptive
        0,                      # white cut-off
        255                     # black cut-off
    )
    pdb.plug_in_unsharp_mask(
        j, z,
        12.,                    # radius
        50.,                    # amount
        .0                      # threshold
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_ALPHA,
        8,
        (.0, .0, .25, .0, .62, .62, .9, 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,
        (.0, .0, 1., .8)
    )

    z.name = name
    return z


def do_water_noise(v, d, z):
    """
    Make WaterPixel Noise for a frame.

    v: View
    d: dict
        Metal Noise Preset

    z: layer
        WIP

    Return: layer
        with noise
    """
    a = d[ok.SEED] + v.glow_ball.seed

    for i in range(3):
        noise_rgb(z, 1., 1., 1., 1., a + i)

    waterpixels(z)
    pdb.gimp_brightness_contrast(z, 0, 75)

    for i in COLOR_TO_ALPHA:
        pdb.plug_in_colortoalpha(v.j, z, i)
    return z


def draw_color_profile(z, w, q, q1):
    """
    Draw a color-type gradient frame using a profile.

    z: layer
        for blur material

    w: int
        width of border

    q: list
        of profile
        in .0 to 1.

    q1: tuple
        RGB
        of int
    """
    j = z.image

    if len(q) == 1:
        a = pdb.gimp_selection_save(j)

        grow_frame(j, w, ff.ANGULAR)
        color_fill_selection(z, q1)
        load_selection(j, a)
        clear_selection(z)
    else:
        # HSV
        q1 = rgb_to_hsv(q1)

        # selections
        a = b = None

        for i in range(w):
            if a:
                # Do now to save memory for large frames.
                pdb.gimp_image_remove_channel(j, a)

            a = b = pdb.gimp_selection_save(j)
            if b:
                grow_frame(j, 1, ff.ANGULAR)
                load_selection(j, b, option=fu.CHANNEL_OP_SUBTRACT)
                color_fill_selection(z, hsv_to_rgb((q1[0], q1[1], q[i])))
                load_selection(j, b, option=fu.CHANNEL_OP_ADD)
        if b:
            pdb.gimp_image_remove_channel(j, b)


def grow_frame(j, w, n):
    """
    Expand a frame selection depending on the Frame Type.

    j: GIMP image
        with selection

    w: int
        expansion amount

    n: string
        Frame Type
    """
    def _angular():
        pdb.gimp_context_set_antialias(0)
        for _ in range(w):
            pdb.gimp_selection_grow(j, 1)

    def _rectangle():
        _is_sel, _x, _y, _x1, _y1 = pdb.gimp_selection_bounds(j)
        if _is_sel:
            _x -= w
            _y -= w
            _w = _x1 + w - _x
            _h = _y1 + w - _y
            select_rect(j, _x, _y, _w, _h)

    def _rounded():
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_selection_grow(j, w)

    {ff.ANGULAR: _angular, ff.RECTANGLE: _rectangle, ff.ROUNDED: _rounded}[n]()


def make_canvas_frame_sel(v, d):
    """
    Make a selection border around the Canvas.

    v: View
    d: dict
        a frame Preset

    Return: GIMP selection or None
        of Canvas border
    """
    if d[ok.CFW]:
        j = v.j

        select_rect(v.j, *v.wip.rect)
        pdb.gimp_selection_shrink(j, d[ok.CFW])

        sel = pdb.gimp_selection_save(j)

        select_rect(v.j, *v.wip.rect)
        load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
        pdb.gimp_image_remove_channel(j, sel)
        return pdb.gimp_selection_save(j)


def make_pattern_frame(j, z, d, p):
    """
    Make a selection for frame material.

    j: GIMP image
        from View

    z: layer
        Maya matter

    d: dict
        Frame Preset

    p: function
        Call to make pattern.

    Return: state of selection
    """
    e = d[ok.FNR][ok.FRAME_METAL]

    select_item(z)
    grow_frame(j, e[ok.FRAME_W], e[ok.FRAME_TYPE])

    sel = pdb.gimp_selection_save(j)

    grow_frame(j, d[ok.WIDTH], e[ok.FRAME_TYPE])

    sel1 = pdb.gimp_selection_save(j)

    grow_frame(j, e[ok.FRAME_W], e[ok.FRAME_TYPE])

    sel2 = pdb.gimp_selection_save(j)

    load_selection(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

    # outer selection, 'sel3'
    sel3 = pdb.gimp_selection_save(j)

    z1 = p(z)

    load_selection(j, sel1)
    load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
    select_item(z1, option=fu.CHANNEL_OP_INTERSECT)
    remove_z(z1)

    # filler selection, 'sel4'
    sel4 = pdb.gimp_selection_save(j)

    # Make inner frame selection.
    load_selection(j, sel)
    select_item(z, option=fu.CHANNEL_OP_SUBTRACT)

    # Combine selections.
    load_selection(j, sel3, option=fu.CHANNEL_OP_ADD)
    load_selection(j, sel4, option=fu.CHANNEL_OP_ADD)
    for i in (sel, sel1, sel2, sel3, sel4):
        pdb.gimp_image_remove_channel(j, i)


def mask_filler_layer(j, filler, sel):
    """
    Mask a filler group from a selection created by a frame.

    j: GIMP image
        View output

    filler: Filler
        Has filler and group layer.

    sel: GIMP selection
        to apply to layer
    """
    if sel:
        load_selection(j, sel)
        mask_sel(filler.matter)


def select_border(j, z, w, n):
    """
    Make a border selection.

    j: GIMP image
        with selection

    z: layer
        Is the material that the border surround.

    w: int
        expansion amount

    n: string
        Frame Type
    """
    def _angular():
        pdb.gimp_context_set_antialias(0)
        for _ in range(w):
            pdb.gimp_selection_grow(j, 1)

    def _rectangle():
        _is_sel, _x, _y, _x1, _y1 = pdb.gimp_selection_bounds(j)
        if _is_sel:
            _x -= w
            _y -= w
            _w = _x1 + w - _x
            _h = _y1 + w - _y
            select_rect(j, _x, _y, _w, _h)

    def _rounded():
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_selection_grow(j, w)

    f = z.opacity
    z.opacity = 100.

    select_item(z)
    {ff.ANGULAR: _angular, ff.RECTANGLE: _rectangle, ff.ROUNDED: _rounded}[n]()
    select_item(z, option=fu.CHANNEL_OP_SUBTRACT)
    z.opacity = f


def soften_metal_sel(v, z, d):
    """
    Fill the selection with grey color and emboss it.

    v: View

    z: layer
        to fill
        WIP

    d: dict
        Metal Frame Preset

    Return: layer
        with material
    """
    j = v.j
    sel = pdb.gimp_selection_save(j)

    color_fill_selection(z, (127, 127, 127))
    pdb.gimp_selection_none(j)
    blur_selection(z, d[ok.DEPTH] - 1)
    pdb.plug_in_emboss(
        j, z,
        v.glow_ball.azimuth,
        v.glow_ball.elevation,
        d[ok.DEPTH],            # depth
        1                       # emboss
    )

    # brightness, '0'
    if d[ok.CONTRAST]:
        pdb.gimp_brightness_contrast(z, 0, d[ok.CONTRAST])

    blur_selection(z, d[ok.SOFTEN])
    load_selection(j, sel)
    clear_inverse_selection(z)
    pdb.gimp_image_remove_channel(j, sel)
    return z


class Color(SubBuild):
    """Process change for a color layer."""
    issue_q = 'cake', 'color'
    put = (check_color, 'matter'), (check_color_style, None)

    def __init__(self, any_group, super_maya, do_color, k_path):
        """
        v: View
        super_maya: Maya
            Is the enclosing Maya.

        do_color: function
            Call to make a color layer.
        """
        self.do_matter = do_color
        SubBuild.__init__(self, any_group, super_maya, k_path)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            If it is True, then a mask is drawn on the Color layer.
        """
        self.value_d = d
        self.go = bool(self.super_maya.matter)

        self.realize(v)

        if self.go and (self.is_color or is_change):
            mask_sub_maya(self.super_maya.matter, self.matter)
        self.reset_issue()


class Filler(SubBuild):
    """Process change for a filler output."""
    issue_q = 'cake', 'filler', 'shade'
    put = (
        (make_filler_group, 'group'),
        (check_filler, 'matter'),
        (check_filler_cake, None)
    )

    def __init__(
        self, any_group, super_maya, do_filler, k_path, is_lucid=False
    ):
        """
        super_maya: Maya
            Frame type

        do_filler: function
            Call to make a filler layer.

        is_lucid: bool
            If True, then Blur Behind is incorporated.
        """
        # Isn't an issue, 'matter', but is referenced by Shadow.
        self.is_matter = False

        self.do_matter = do_filler

        SubBuild.__init__(self, any_group, super_maya, k_path)
        self.sub_maya[LIGHT] = Light(
            any_group, self, [ok.OTHER, ok.TRANSLUCENT][is_lucid]
        )

    def do(self, v, d, is_change):
        """
        Produce GIMP layer output. Has a filler
        layer and a Gradient Light layer.

        v: View
        d: dict
            frame Preset
        """
        self.value_d = d
        self.is_filler |= is_change

        # for shadow output
        self.is_matter = self.is_filler

        self.realize(v)

        if self.is_matter:
            mask_filler_layer(v.j, self, self.super_maya.filler_sel)

        self.sub_maya[LIGHT].do(v, self.is_filler)
        self.reset_issue()


class Frame(Build):
    """Its layers are material and shadow Maya."""
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, do_matter, k_path=()):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        do_matter: function
            Call to make the frame layer.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        self.do_matter = do_matter

        Build.__init__(self, any_group, super_maya, k_path)
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (self.cause, self), k_path + (ok.SRR, ok.SHADOW)
        )
        if self.INFLUENCE:
            self.sub_maya[LIGHT] = Light(any_group, self, self.INFLUENCE)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)
        m = self.sub_maya[ok.SHADOW].do(
            v,
            d[ok.SRR][ok.SHADOW],
            self.is_matter + self.is_cake,
            is_change + self.cause.is_cake
        )

        if self.INFLUENCE:
            self.sub_maya[LIGHT].do(v, self.is_matter)

        self.reset_issue()
        return m


class Lucid(Build):
    """Is a translucent frame."""
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, do_matter, do_color, k_path=()):
        """
        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        do_matter: function
            Call to make the matter layer.

        do_color: function
            Call to make the color layer.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        self.do_matter = do_matter

        Build.__init__(self, any_group, super_maya, k_path)

        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (self.cause, self), k_path + (ok.SRR, ok.SHADOW)
        )
        self.sub_maya[COLOR] = Color(any_group, self, do_color, k_path)
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(any_group, self, k_path)
        self.sub_maya[LIGHT] = Light(any_group, self, ok.TRANSLUCENT)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame-type Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)

        m = self.sub_maya[ok.SHADOW].do(
            v,
            d[ok.SRR][ok.SHADOW],
            self.is_matter + self.is_cake,
            is_change + self.cause.is_cake
        )

        self.sub_maya[COLOR].do(v, d, self.is_matter)
        self.sub_maya[ok.BLUR_BEHIND].do(v, d, m or is_back, self.is_matter)
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m


class MaskGroup(Build):
    """Create a group having a mask and parenting the cast layer."""
    issue_q = 'matter',
    put = (check_matter, 'matter'),

    def __init__(self, any_group, super_maya, do_matter, k_path=()):
        """
        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        do_matter: function
            Call to make a material layer.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        self.do_matter = do_matter
        Build.__init__(self, any_group, super_maya, k_path)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame type Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: False
            The background did not change.
        """
        self.value_d = d
        self.is_matter |= is_change
        self.realize_vote(v)
        return False


class Metal(Build):
    """Is a metallic-like frame."""
    is_embossed = True
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_metal_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, do_matter, k_path=()):
        """
        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        do_matter: function
            Call to make the matter layer.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        self.do_matter = do_matter

        Build.__init__(
            self,
            any_group,
            super_maya,
            k_path=[k_path, k_path + (ok.FNR, ok.FRAME_METAL,)]
        )

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.FNR, ok.NOISE_D)
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (self.cause, self), k_path + (ok.SRR, ok.SHADOW)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[ok.NOISE_D].do(v, d[ok.FNR][ok.NOISE_D], self.is_matter)

        m = self.sub_maya[ok.SHADOW].do(
            v,
            d[ok.SRR][ok.SHADOW],
            self.is_matter + self.is_cake,
            is_change + self.cause.is_cake
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m


class MetalFiller(Build):
    """Create a metal frame with a filler insert."""
    is_embossed = True
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_metal_frame_cake, None)
    )

    def __init__(self, any_group, super_maya, do_filler, k_path=()):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        do_filler: function
            Call to make filler material

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        self.filler_sel = None
        self.do_matter = do_filler_frame

        Build.__init__(
            self,
            any_group,
            super_maya,
            k_path=[k_path, k_path + (ok.FNR, ok.FRAME_METAL)]
        )

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.FNR, ok.NOISE_D)
        )
        self.sub_maya[FILLER] = Filler(any_group, self, do_filler, k_path)
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group,
            self,
            (self.cause, self, self.sub_maya[FILLER]),
            k_path + (ok.SRR, ok.SHADOW)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[FILLER].do(v, d, self.is_matter)
        self.sub_maya[ok.NOISE_D].do(v, d[ok.FNR][ok.NOISE_D], self.is_matter)

        m = self.sub_maya[ok.SHADOW].do(
            v,
            d[ok.SRR][ok.SHADOW],
            self.is_matter + self.is_cake,
            is_change + self.cause.is_cake
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m

    def reset(self):
        """Call when the View image is removed."""
        self.filler_sel = None
        super(MetalFiller, self).reset()


class Noise(SubBuild):
    """Process change for a Noise Metal Preset."""
    issue_q = 'cake', 'matter'
    is_seeded = True
    put = (check_matter, 'matter'), (check_cake, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        super_maya: Maya
            Has the Noise option.
        """
        self.do_matter = do_noise_matter
        SubBuild.__init__(self, any_group, super_maya, k_path)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Noise Preset
            {Option key: value}
        """
        self.value_d = d
        self.go = d[ok.SWITCH] and bool(self.super_maya.matter)

        self.realize(v)

        if self.go and (self.is_matter or is_change):
            mask_sub_maya(self.super_maya.matter, self.matter)
        self.reset_issue()


class Shadow1(SubBuild):
    """Process change for a shadow layer."""
    issue_q = 'shadow',
    put = (check_shadow, 'shadow'),

    def __init__(self, any_group, super_maya, k_path):
        """
        v: View
        super_maya: Maya
            Is the enclosing Maya.
        """
        self.do_shadow = do_shadow
        SubBuild.__init__(self, any_group, super_maya, k_path)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame-type Preset
        """
        self.value_d = d
        self.is_shadow &= bool(d[ok.INTENSITY])
        self.is_shadow |= is_change
        self.realize_vote(v)
