#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Frame as ek
from roller_frame import FILLER, MetalFiller
from roller_fu import (
    apply_mask,
    clone_layer,
    clone_opaque_layer,
    make_layer_group,
    merge_layer,
    merge_layer_group,
    remove_z
)
from roller_one_gegl import saturation
from roller_view_real import clip_to_wip, get_light
import gimpfu as fu

pdb = fu.pdb


def do_filler(v, maya):
    """
    Draw filler material.

    v: View
    maya: StretchTray
    Return: layer
        with filler material
    """
    j = v.j

    # source layer, 'z'
    z = clone_opaque_layer(maya.cause.matter, n="Left")

    if (
        z.width != v.wip.w or
        z.height != v.wip.h or
        z.offsets != v.wip.position
    ):
        clip_to_wip(v, z)

    if z.mask:
        apply_mask(z)

    group = make_layer_group(
        j, "Stretch", parent=maya.group, z=z, offset=get_light(maya)
    )

    apply_mask(z)
    pdb.gimp_selection_none(j)

    for x, z1 in enumerate((
        z,
        clone_layer(z, n="Right"),
        clone_layer(z, n="Top"),
        clone_layer(z, n="Bottom")
    )):
        pdb.plug_in_wind(
            j, z1,
            .0,                 # Threshold All
            x,                  # direction
            100,                # maximum strength
            0,                  # wind algorithm
            1,                  # leading edge
        )

        # Threshold all pixel, '.0'
        pdb.plug_in_threshold_alpha(j, z1, .0)

    # Make the wind output opaque.
    z1 = merge_layer_group(group)
    z = clone_opaque_layer(z1)

    remove_z(z1)
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .25, 1., .75)
    )
    saturation(z, 10.)

    z1 = clone_layer(z, n="Hard Light")
    z1.mode = fu.LAYER_MODE_HARDLIGHT
    z1.opacity = 80.

    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                          # coordinate count
        (.0, .45, 1., .54)
    )

    # depth, '3'; emboss, '1'
    pdb.plug_in_emboss(j, z, v.glow_ball.azimuth, v.glow_ball.elevation, 3, 1)

    z = merge_layer(z1)
    z.name = z.parent.name + " Filler"
    return z


class StretchTray(MetalFiller):
    """
    Make a frame by stretching cause material horizontally and vertically.
    """
    FRAME_K = ek.STRETCH_TRAY

    def __init__(self, *q, **d):
        """
        q: tuple
            MetalFiller spec

        d: dict
            MetalFiller spec
        """
        MetalFiller.__init__(self, *q + (do_filler,), **d)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Ceramic Chip Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then the background was changed by Shadow.
        """
        # Stretch Tray Filler has no vote, so check for change.
        if is_change or not self.sub_maya[FILLER].matter:
            self.sub_maya[FILLER].is_filler = True
        return super(StretchTray, self).do(v, d, is_change)
