#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_fu import (
    blur_selection,
    clone_layer,
    color_fill_layer,
    dilate,
    isolate_selection,
    merge_layer_group,
    select_item
)
from roller_maya_style import Style
from roller_view_real import (
    add_sub_base_group,
    add_wip_layer,
    clip_to_wip,
    do_gradient_for_layer,
    finish_style
)
from roller_view_hub import do_stylish_shadow, get_gradient_factors
import gimpfu as fu

pdb = fu.pdb


def do_grid(z, q, is_vertical=True):
    """
    Draw grid lines. The grid lines are either
    horizontal or vertical, but not both.

    z: layer
        work-in-progress

    q: tuple
        argument for vertical or horizontal line

    is_vertical: bool
        If it's true, the argument is for vertical line.
    """
    args = z.image, z
    q1 = 0, 0, 0, (0, 0, 0), 0

    if is_vertical:
        args += q1 + q + q1

    else:
        args += q + q1 * 2
    pdb.plug_in_grid(*args)


def make_style(v, maya):
    """
    Make a Backdrop Style layer.

    v: View
    maya: LostMaze
    Return: layer
        with the style material
    """
    j = v.j
    d = maya.value_d
    group = add_sub_base_group(v, maya)
    z = maze_layer = add_wip_layer(v, maya, "Base", group=group)
    w = max(1, v.wip.w // d[ok.COLUMN])
    h = max(1, v.wip.h // d[ok.ROW])

    # Preserve.
    foreground = pdb.gimp_context_get_foreground()
    background = pdb.gimp_context_get_background()

    pdb.gimp_context_set_foreground((0, 0, 0))
    pdb.gimp_context_set_background((255, 255, 255))
    select_item(z)
    pdb.plug_in_maze(j, z, w, h, 1, 0, d[ok.SEED], 0, 0)

    z = clone_layer(z, n="Alpha")

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

    alpha_layer = clone_layer(z, n="Difference")
    alpha_layer.mode = fu.LAYER_MODE_DIFFERENCE

    pdb.gimp_selection_none(j)
    pdb.plug_in_edge(j, maze_layer, 1., 0, 0)

    # Expand the border.
    for _ in range(2):
        dilate(maze_layer)

    pdb.plug_in_colortoalpha(j, maze_layer, (0, 0, 0))

    # horizontal line
    h1 = min(max(6, h // 5), v.wip.h)

    do_grid(
        z,
        (h1, h1 + 1, 0, (0, 0, 0), 255),
        is_vertical=False
    )
    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
    e = get_default_value(by.GRADIENT_FILL)

    e.update(d)

    e[ok.GRADIENT] = d[ok.GBR][ok.GRADIENT]
    e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
        get_gradient_factors(d[ok.GRADIENT_ANGLE])

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    select_item(z)

    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.gimp_image_set_active_layer(j, z)

    z = do_gradient_for_layer(v, e, group, 0)

    if e[ok.START_X] < e[ok.END_X]:
        x = 3

    elif e[ok.START_X] > e[ok.END_X]:
        x = -3

    else:
        x = 0

    if e[ok.START_Y] < e[ok.END_Y]:
        y = 3

    elif e[ok.START_Y] > e[ok.END_Y]:
        y = -3

    else:
        y = 0

    isolate_selection(z, sel)
    do_stylish_shadow(z, blur=9., intensity=150., offset_x=x, offset_y=y)
    pdb.gimp_selection_none(j)

    # vertical line
    z = add_wip_layer(
        v, maya, "Vertical Line", group=group, offset=len(group.layers) + 1
    )

    color_fill_layer(z, (255, 255, 255))
    pdb.gimp_selection_all(j)

    v1 = min(max(12, w // 12), v.wip.h)

    do_grid(z, (v1, v1 + 1, 0, (0, 0, 0), 255))
    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    do_stylish_shadow(z, blur=10, intensity=200., is_inner=True)
    do_stylish_shadow(z, blur=10, intensity=200.)

    # background
    z = do_gradient_for_layer(v, e, group, 0)

    pdb.gimp_image_lower_item_to_bottom(j, z)
    pdb.gimp_image_reorder_item(j, alpha_layer, group, 4)
    blur_selection(alpha_layer, 500)

    # grain
    z = clone_layer(alpha_layer, n="Grain Extract")

    pdb.gimp_image_reorder_item(j, z, group, 6)

    z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
    z.opacity = 100.

    pdb.gimp_drawable_invert(z, 0)

    z = merge_layer_group(group)

    # Restore.
    pdb.gimp_context_set_foreground(foreground)
    pdb.gimp_context_set_background(background)

    pdb.gimp_image_remove_channel(j, sel)
    clip_to_wip(v, z)
    return finish_style(z, "Lost Maze")


class LostMaze(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.GBR
    is_dependent = False

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        k_path = d['k_path']
        d['k_path'] = [k_path, k_path + (ok.GBR,), k_path + (ok.IRR,)]
        Style.__init__(self, *q + (make_style,), **d)
