#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_style_average_color import AverageColor
from roller_backdrop_style_backdrop_image import BackdropImage
from roller_backdrop_style_color_fill import ColorFill
from roller_backdrop_style_colored_grid import ColoredGrid
from roller_backdrop_style_core_design import CoreDesign
from roller_backdrop_style_crystal_cave import CrystalCave
from roller_backdrop_style_dark_fort import DarkFort
from roller_backdrop_style_etch_sketch import EtchSketch
from roller_backdrop_style_floor_sample import FloorSample
from roller_backdrop_style_grid_work import GridWork
from roller_backdrop_style_glass_gaw import GlassGaw
from roller_backdrop_style_gradient_fill import GradientFill
from roller_backdrop_style_honey_bee import HoneyBee
from roller_backdrop_style_image_gradient import ImageGradient
from roller_backdrop_style_light_shaft import LightShaft
from roller_backdrop_style_lost_maze import LostMaze
from roller_backdrop_style_maze_blend import MazeBlend
from roller_backdrop_style_mystery_grate import MysteryGrate
from roller_backdrop_style_noise_rift import NoiseRift
from roller_backdrop_style_pattern_fill import PatternFill
from roller_backdrop_style_rainbow_valley import RainbowValley
from roller_backdrop_style_density_gradient import DensityGradient
from roller_backdrop_style_rocky_landing import RockyLanding
from roller_backdrop_style_spacetime_fabric import SpacetimeFabric
from roller_backdrop_style_specimen_speckle import SpecimenSpeckle
from roller_backdrop_style_spiral_channel import SpiralChannel
from roller_backdrop_style_square_cloud import SquareCloud
from roller_backdrop_style_trailing_vine import TrailingVine
from roller_image_effect import ImageEffect
from roller_image_effect_ball_joint import BallJoint
from roller_image_effect_border_line import BorderLine
from roller_image_effect_brush_punch import BrushPunch
from roller_image_effect_ceramic_chip import CeramicChip
from roller_image_effect_circle_punch import CirclePunch
from roller_image_effect_clear_frame import ClearFrame
from roller_image_effect_colored_board import ColoredBoard
from roller_image_effect_corner_tape import CornerTape
from roller_image_effect_cosmetic_pipe import CosmeticPipe
from roller_image_effect_cutout_plate import CutoutPlate
from roller_image_effect_feather_reduction import FeatherReduction
from roller_image_effect_frame_gradient import FrameGradient
from roller_image_effect_gradient_level import GradientLevel
from roller_image_effect_gradient_pipe import GradientPipe
from roller_image_effect_image_shadow import ImageShadow
from roller_image_effect_jagged_edge import JaggedEdge
from roller_image_effect_line_fashion import LineFashion
from roller_image_effect_maze_mirror import MazeMirror
from roller_image_effect_no_effect import NoEffect
from roller_image_effect_paint_rush import PaintRush
from roller_image_effect_rad_wave import RadWave
from roller_image_effect_raised_maze import RaisedMaze
from roller_image_effect_rounded_edge import RoundedEdge
from roller_image_effect_square_punch import SquarePunch
from roller_image_effect_stained_glass import StainedGlass
from roller_image_effect_wire_fence import WireFence
from roller_one_constant import BackdropStyleKey as bsk
from roller_render_shadow import Shadow

ek = ImageEffect.Key


class Pin:
    """
    Connect image-effect and backdrop-style classes with their key.
    Use with render or its preview.
    """
    # backdrop-style:
    backdrop = {
        bsk.AVERAGE_COLOR: AverageColor,
        bsk.BACKDROP_IMAGE: BackdropImage,
        bsk.COLOR_FILL: ColorFill,
        bsk.COLORED_GRID: ColoredGrid,
        bsk.CRYSTAL_CAVE: CrystalCave,
        bsk.CORE_DESIGN: CoreDesign,
        bsk.DARK_FORT: DarkFort,
        bsk.DENSITY_GRADIENT: DensityGradient,
        bsk.ETCH_SKETCH: EtchSketch,
        bsk.FLOOR_SAMPLE: FloorSample,
        bsk.GRID_WORK: GridWork,
        bsk.GLASS_GAW: GlassGaw,
        bsk.GRADIENT_FILL: GradientFill,
        bsk.HONEY_BEE: HoneyBee,
        bsk.IMAGE_GRADIENT: ImageGradient,
        bsk.LIGHT_SHAFT: LightShaft,
        bsk.LOST_MAZE: LostMaze,
        bsk.MAZE_BLEND: MazeBlend,
        bsk.MYSTERY_GRATE: MysteryGrate,
        bsk.NOISE_RIFT: NoiseRift,
        bsk.PATTERN_FILL: PatternFill,
        bsk.RAINBOW_VALLEY: RainbowValley,
        bsk.ROCKY_LANDING: RockyLanding,
        bsk.SPACETIME_FABRIC: SpacetimeFabric,
        bsk.SPECIMEN_SPECKLE: SpecimenSpeckle,
        bsk.SPIRAL_CHANNEL: SpiralChannel,
        bsk.SQUARE_CLOUD: SquareCloud,
        bsk.TRAILING_VINE: TrailingVine
    }

    # image-effect:
    effect = {
        ek.BALL_JOINT: BallJoint,
        ek.BORDER_LINE: BorderLine,
        ek.BRUSH_PUNCH: BrushPunch,
        ek.CERAMIC_CHIP: CeramicChip,
        ek.CIRCLE_PUNCH: CirclePunch,
        ek.CLEAR_FRAME: ClearFrame,
        ek.COLORED_BOARD: ColoredBoard,
        ek.CORNER_TAPE: CornerTape,
        ek.COSMETIC_PIPE: CosmeticPipe,
        ek.CUTOUT_PLATE: CutoutPlate,
        ek.DROP_SHADOW: Shadow,
        ek.FEATHER_REDUCTION: FeatherReduction,
        ek.FILL_LIGHT_SHADOW: Shadow,
        ek.FRAME_GRADIENT: FrameGradient,
        ek.GRADIENT_LEVEL: GradientLevel,
        ek.GRADIENT_PIPE: GradientPipe,
        ek.IMAGE_EDGE_SHADOW: Shadow,
        ek.IMAGE_SHADOW: ImageShadow,
        ek.INLAY_SHADOW: Shadow,
        ek.JAGGED_EDGE: JaggedEdge,
        ek.KEY_LIGHT_SHADOW: Shadow,
        ek.LINE_FASHION: LineFashion,
        ek.MAZE_MIRROR: MazeMirror,
        ek.NO_EFFECT: NoEffect,
        ek.RAD_WAVE: RadWave,
        ek.RAISED_MAZE: RaisedMaze,
        ek.PAINT_RUSH: PaintRush,
        ek.ROUNDED_EDGE: RoundedEdge,
        ek.SHADOW_PAIR: None,
        ek.SQUARE_PUNCH: SquarePunch,
        ek.STAINED_GLASS: StainedGlass,
        ek.WIRE_FENCE: WireFence
    }
