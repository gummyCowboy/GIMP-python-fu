#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, seed, uniform
from roller_format_form import Form
from roller_format_image import Rect, RollerImage
from roller_image_effect import ImageEffect, LayerKey
from roller_one_constant import (
    BumpKey,
    CellKey as ck,
    ForBump as fb,
    ForLayout,
    FormatKey as fk,
    FreeCellKey as fck,
    OptionKey as ok,
    PlaceKey as pl,
    PropertyKey as pr,
    SessionKey as sk
)
from roller_one_fu import Lay, Sel
from roller_one import One
from roller_one_preset import Preset
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu
import math

pdb = fu.pdb
ek = ImageEffect.Key
FOUR_COORDINATES = 4
FREE = ForLayout.FREE_CELL

# oriented with zero at north:
RADIAN_135 = 2.35619
RADIAN_180 = 3.14159
RADIAN_225 = 3.92699
RADIAN_270 = 4.71239
RADIAN_315 = 5.49779
RADIAN_45 = .785398
RADIAN_90 = 1.5708


class CornerTape:
    """Simulate a tape image holder."""

    def __init__(self, one):
        """
        Do a Corner Tape image-effect.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        j = self.render = stat.render.image
        parent = self.parent = one.parent
        d = one.d
        self.session = one.session
        self.format_name = Lay.get_format_name_from_group(parent)
        self.row = self.col = self.format_x = 0
        self.length = d[ok.TAPE_LENGTH]
        self.width = d[ok.TAPE_WIDTH]
        self.corner_shift = d[ok.CORNER_SHIFT]
        self.angle_shift = d[ok.ANGLE_SHIFT]
        e = Preset.get_default(ek.DROP_SHADOW)

        for i in (ok.SHADOW_BLUR, ok.INTENSITY):
            e[i] = d[i]

        seed(d[ok.RANDOM_SEED])
        Shadow(
            One(
                d=e,
                e={'caster_key': (LayerKey.IMAGE,)},
                k=ek.DROP_SHADOW,
                parent=parent,
                stat=stat
            )
        )

        # Get the format dict:
        for x, i in enumerate(one.session[sk.FORMAT_LIST]):
            if i[fk.Layer.NAME] == self.format_name:
                self.form = i
                self.row, self.col = stat.layout.get_division(x)
                self.format_x = x
                break

        n = Lay.get_layer_name(one.k, parent)
        group = Lay.group(j, n, parent=parent)
        z = Lay.add(j, n, parent=group)
        self.merged = Form.is_merge_cells(self.form)

        self._process_grid(j, z, d)
        self._process_free_range(j, z, d)

        z1 = Lay.clone(j, z)
        e = Preset.get_default(ok.BUMP)
        e[ok.BUMP] = fb.NOISE
        e[BumpKey.Emboss.BUMP_DEPTH] = 1
        e[ok.LIGHT_ANGLE] = 225.

        RenderHub.bump(j, z1, e)
        Lay.blur(j, z1, 2)
        pdb.gimp_drawable_invert(z1, 0)

        z1.mode = fu.LAYER_MODE_DIFFERENCE
        z1.opacity = 66.
        z2 = Lay.clone(j, z1)
        z2.mode = fu.LAYER_MODE_LCH_HUE
        z2.opacity = 24.
        z3 = Lay.clone(j, z2)
        z3.mode = fu.LAYER_MODE_NORMAL
        z3.opacity = 2.
        z4 = Lay.clone(j, z)
        z4.mode = fu.LAYER_MODE_HSL_COLOR

        # Darken the edge:
        Sel.item(j, z4)
        pdb.gimp_selection_shrink(j, 1.)
        Sel.invert(j)
        pdb.gimp_curves_spline(
            z4,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 10, 255, 80]
        )

        # Place on top:
        Lay.order(j, z4, group)

        z5 = Lay.clone(j, z4)
        z5.mode = fu.LAYER_MODE_OVERLAY
        z6 = Lay.clone(j, z)

        pdb.plug_in_shift(j, z6, 2, 0)
        pdb.plug_in_shift(j, z6, 2, 1)
        Lay.blur(j, z6, 2)
        pdb.gimp_curves_spline(
            z6,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 0, 255, 0]
        )

        for i in (z, z1, z2, z3, z4, z5):
            Lay.give_mask(i, z6)

        pdb.gimp_image_remove_layer(j, z6)
        pdb.gimp_drawable_invert(z1, 0)
        z = Lay.merge_group(j, group, n)
        z.opacity = d[ok.OPACITY]

    def _calc_bounds(self, j):
        """
        Calculate the rotated bounds of the
        work-in-progress image in its original size.

        Calculate the transform amount for the x, y vectors.
        The goal of the transform is to calculate
        the corner points of the cell-sized image.

        j: RollerImage
            Has size.
        """
        self.corners = []
        w, h = j.size

        # center:
        w, h = w // 2, h // 2

        for i in range(4):
            if not i:
                x, y = -w, h

            elif i == 1:
                x, y = w, h

            elif i == 2:
                x, y = w, -h

            else:
                x, y = -w, -h

            x, y = CornerTape.get_point(
                0,
                0,
                math.atan2(x, y) + self.rotate,
                ((x**2) + (y**2))**0.5
            )
            self.corners.append((x, y))

        q = self.corners
        x_points = q[0][0], q[1][0], q[2][0], q[3][0]
        y_points = q[0][1], q[1][1], q[2][1], q[3][1]
        u = min(x_points), min(y_points)
        v = max(x_points), max(y_points)
        u = abs(u[0] - v[0]), abs(u[1] - v[1])
        self.transform = (
            self.rect.width / 1. / u,
            self.rect.height / 1. / u[1]
        )

    def _do_bottom_left(self, x, y):
        """
        Make a selection for the bottom-left corner.

        x, y: int
            corner point
        """
        angle = RADIAN_135 + self._get_angle_shift() + self.rotate
        x, y = self._get_rotated_corner(x, y, 3)
        x1, y1 = CornerTape.get_point(x, y, angle, self.length // 2)
        self._select_tape_rect(angle, x1, y1)

    def _do_bottom_right(self, x, y):
        """
        Make a selection for the bottom-right corner.

        x, y: int
            corner point
        """
        angle = RADIAN_45 + self._get_angle_shift() + self.rotate
        x, y = self._get_rotated_corner(x, y, 2)
        x1, y1 = CornerTape.get_point(x, y, angle, self.length // 2)
        self._select_tape_rect(angle, x1, y1)

    def _do_topleft(self, x, y):
        """
        Make a selection for the topleft corner.

        x, y: int
            corner point
        """
        angle = RADIAN_225 + self._get_angle_shift() + self.rotate
        x, y = self._get_rotated_corner(x, y, 0)
        x1, y1 = CornerTape.get_point(x, y, angle, self.length // 2)
        self._select_tape_rect(angle, x1, y1)

    def _do_top_right(self, x, y):
        """
        Make a selection for the top-right corner.

        x, y: int
            center point
        """
        angle = RADIAN_315 + self._get_angle_shift() + self.rotate
        x, y = self._get_rotated_corner(x, y, 1)
        x1, y1 = CornerTape.get_point(x, y, angle, self.length // 2)
        self._select_tape_rect(angle, x1, y1)

    def _get_angle_shift(self):
        """
        Make a randomized angle-shift amount.

        Return: int
            angle shift
        """
        return uniform(
            math.radians(-self.angle_shift),
            math.radians(self.angle_shift)
        )

    def _get_corner_shift(self):
        """
        Make a randomized corner-shift amount.

        Return: int
            corner shift
        """
        return randint(-self.corner_shift, self.corner_shift)

    def _get_rotated_corner(self, x, y, corner_x):
        """
        x: int
            index to corner point

        Return: tuple
            of int
            corner point
        """
        if self.rotate:
            x1, y1 = self.corners[corner_x]
            x1 *= self.transform[0]
            y1 *= self.transform[1]
            x = x1 + self.center[0]
            y = y1 + self.center[1]

        x += self._get_corner_shift()
        y += self._get_corner_shift()
        return x, y

    def _process_free_range(self, j, z, d):
        """
        Do the effect for any free-range cells.

        j: GIMP image
            work-in-progress
            Is render.

        z: layer
            to receive effect

        d: dict
            Has options.
        """
        for e in reversed(self.form[fk.Layer.CELL_LIST]):
            sel = self.stat.get_image_sel(e[fck.CELL][ck.NAME], FREE, FREE)
            if sel:
                j1 = RollerImage.get_image(
                    self.session,
                    e[pl.IMAGE_PLACE][pl.IMAGE_DICT]
                )
                self.rotate = math.radians(
                    Form.get_image_property(e, FREE, FREE)[pr.ROTATE]
                )
                self._process_image(j, j1, d, z, FREE, FREE, sel)

    def _process_grid(self, j, z, d):
        """
        Do the effect for grid cells.

        j: GIMP image
            work-in-progress
            Is render.

        z: layer
            to receive effect

        d: dict
            Has options.
        """
        # Do one image at a time:
        for r in range(self.row):
            for c in range(self.col):
                if self.merged:
                    s = self.form[fk.Cell.Grid.PER_CELL][r][c]

                else:
                    # not a dependent cell:
                    s = 1

                # Is it a dependent cell?
                if s != (-1, -1):
                    sel = self.stat.get_image_sel(self.format_name, r, c)
                    if sel:
                        self.rotate = math.radians(
                            Form.get_image_property(
                                self.form,
                                r,
                                c
                            )[pr.ROTATE]
                        )
                        self._process_image(j, None, d, z, r, c, sel)

    def _process_image(self, j, j1, d, z, r, c, sel):
        """
        j1: RollerImage or None
            for free-range cell

        r, c: int
            row, column

        sel: Selection
            from image
        """
        Sel.load(j, sel)
        x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
        w = x1 - x
        h = y1 - y
        self.center = x + w // 2, y + h // 2
        self.rect = Rect((x, y), (w, h))

        if self.rotate:
            name = self.stat.layout.get_image_name_from_cell(
                self.format_x,
                r,
                c,
                j1
            )
            if not j1:
                j1 = RollerImage.get_image(self.session, name)
            self._calc_bounds(j1)

        pdb.gimp_selection_none(j)
        self._do_topleft(x, y)
        self._do_top_right(x + w, y)
        self._do_bottom_left(x, y + h)
        self._do_bottom_right(x + w, y + h)
        Sel.fill(z, d[ok.COLOR])

    def _select_tape_rect(self, angle, x, y):
        """
        Define and select a tape rectangle.

        x, y: int
            start point
        """
        x1, y1 = CornerTape.get_point(x, y, angle - RADIAN_90, self.width)
        x2, y2 = CornerTape.get_point(x1, y1, angle - RADIAN_180, self.length)
        x3, y3 = CornerTape.get_point(x2, y2, angle - RADIAN_270, self.width)
        Sel.polygon(self.render, (x, y, x1, y1, x2, y2, x3, y3))

    @staticmethod
    def blur_behind_tape(j, parent, stat, format_x):
        """
        Blur behind the tape.

        j: GIMP image
            work-in-progress

        parent: layer
            format group

        stat: Stat
            globals

        format_x: int
            index to format in format list
        """
        z = Lay.search(parent, LayerKey.CORNER_TAPE, is_err=0)
        if z:
            RenderHub.copy_for_blur(j, z, parent, stat, format_x)

            n = z.name
            x = pdb.gimp_image_get_item_position(j, z) + 1
            z1 = Lay.paste(j, z.parent.layers[x])

            Lay.blur(j, z1, 5)
            pdb.gimp_curves_spline(
                z1,
                fu.HISTOGRAM_VALUE,
                FOUR_COORDINATES,
                [0, 0, 255, 235]
            )
            Sel.item(j, z)
            Sel.clear_outside_of_selection(j, z1)

            z = Lay.merge(j, z)
            z.name = n

    @staticmethod
    def get_point(x, y, angle, radius):
        """
        Returns a point the circle that corresponds to the rotation.

        x, y: int
            center point

        angle : float
            the rotation angle
            of radians

        radius: float
            the radius of the circle

        Returns:
            x : float
            y : float
            the point on the circle
        """
        x = (math.sin(angle) * radius) + x
        y = (math.cos(angle) * -radius) + y
        return round(x), round(y)
