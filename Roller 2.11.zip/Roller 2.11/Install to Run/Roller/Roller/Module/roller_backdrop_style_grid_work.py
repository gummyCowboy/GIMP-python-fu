#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_style_colored_grid import ColoredGrid
from roller_one_constant import ForBump as fb, OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay
from roller_one_gegl import Gegl
import gimpfu as fu

cs = Fu.ColorSelect
em = Fu.Emboss
pdb = fu.pdb
rn = Fu.RGBNoise


class GridWork:
    """
    Create a multi-textured grid and overlay
    it with a blurred background image.
    """

    def __init__(self, one):
        """
        Do the Grid Work backdrop-style.

        one: One
            Has variables.
        """
        d = one.d
        j = one.stat.render.image
        group = Lay.group(j, one.k, parent=one.z.parent)
        z1 = Lay.clone(j, one.z)

        Lay.order(j, z1, group)
        Gegl.blur(z1, 500)

        z2 = Lay.clone(j, z1)
        z2.mode = fu.LAYER_MODE_OVERLAY
        z = Lay.add(j, one.k, parent=group)
        d[ok.COLOR_1] = 0, 0, 0
        d[ok.COLOR_2] = 255, 255, 255
        d[ok.BUMP] = {ok.BUMP: fb.NONE}
        z = ColoredGrid.draw_color_grid(j, z, d)
        angle = d[ok.LIGHT_ANGLE] + 180

        if angle > 360:
            angle -= 360

        # Create a selection from the black pixels:
        pdb.gimp_by_color_select(
            z,
            (0, 0, 0),
            cs.THRESHOLD_0,
            fu.CHANNEL_OP_REPLACE,
            cs.YES_ANTIALIAS,
            cs.NO_FEATHER,
            cs.FEATHER_RADIUS_0,
            cs.NO_SAMPLE_MERGED
        )

        # Clear the black grid:
        Lay.clear_sel(j, z)

        pdb.plug_in_rgb_noise(
            j,
            z,
            rn.YES_INDEPENDENT,
            rn.NO_CORRELATED,
            rn.NOISE_TENTH,
            rn.NOISE_TENTH,
            rn.NOISE_TENTH,
            rn.NOISE_ZERO
        )
        pdb.plug_in_emboss(
            j,
            z,
            d[ok.LIGHT_ANGLE],
            em.ELEVATION_20,
            em.DEPTH_3,
            em.EMBOSS
        )
        pdb.plug_in_rgb_noise(
            j,
            z1,
            rn.YES_INDEPENDENT,
            rn.NO_CORRELATED,
            rn.NOISE_TENTH,
            rn.NOISE_TENTH,
            rn.NOISE_TENTH,
            rn.NOISE_ZERO
        )
        pdb.plug_in_emboss(
            j,
            z1,
            angle,
            em.ELEVATION_19,
            em.DEPTH_4,
            em.EMBOSS
        )
        Lay.order(j, z2, group, offset=0)
