#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_image_effect import LayerKey as nk
import gimpfu as fu

ed = Fu.Edge
pdb = fu.pdb
FOUR_COORDINATES = 4


class PaintRush:
    """Create a white frame around image material that has splattered paint."""

    def __init__(self, one):
        """
        Do the image-effect.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        parent = one.parent
        d = one.d
        j = stat.render.image
        image_layer = stat.render.get_image_layer(
            Lay.get_format_name_from_group(parent)
        )
        group = Lay.group(
            j,
            one.k,
            parent=parent,
            offset=Lay.offset(j, image_layer)
        )
        group.mode = fu.LAYER_MODE_LIGHTEN_ONLY
        z = Lay.clone(j, image_layer)
        z.mode = fu.LAYER_MODE_DIVIDE

        Lay.order(j, z, group)
        pdb.plug_in_edge(j, z, ed.AMOUNT_2, ed.WRAP, ed.SOBEL)

        z = z1 = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_SUBTRACT

        Lay.order(j, z, group, offset=len(group.layers))

        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_LINEAR_LIGHT

        Gegl.blur(z, d[ok.EDGE_BLUR])
        Lay.order(j, z, group, offset=len(group.layers))

        # Protect the center with a grey layer:
        z = Lay.clone(j, z1)
        z.mode = fu.LAYER_MODE_BURN

        Lay.order(j, z, group, offset=2)
        pdb.gimp_curves_spline(
            z,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 127, 255, 127]
        )
        Sel.item(j, z)
        pdb.gimp_selection_shrink(j, d[ok.EDGE_BLUR] * 1.5)
        Sel.clear_outside_of_selection(j, z)

        z = Lay.clone(j, z1)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        Lay.order(j, z, group, offset=len(group.layers))
        Gegl.blur(z, d[ok.EDGE_BLUR] / 2)

        z = Lay.add(j, one.k, parent=group, offset=len(group.layers))

        Lay.color_fill(z, (127, 127, 127))

        z = Lay.merge_group(
            j,
            group,
            n=Lay.get_layer_name(nk.FRAME, parent=parent)
        )

        Sel.item(j, image_layer)
        Sel.clear_outside_of_selection(j, z)
