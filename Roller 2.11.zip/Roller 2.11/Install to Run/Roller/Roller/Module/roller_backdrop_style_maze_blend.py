#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay, Sel
import gimpfu as fu

cs = Fu.ColorSelect
ed = Fu.Edge
em = Fu.Emboss
pdb = fu.pdb
STRENGTH_100 = 100
THRESHOLD_POINT_5 = 127


class MazeBlend:
    """
    Use a maze graph to produce softly blended backdrop.
    """

    def __init__(self, one):
        """
        Do the Maze Blend backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        if Lay.has_pixel(j, one.z):
            d = one.d
            group = Lay.group(j, one.k, parent=one.z.parent)
            z = Lay.clone(j, one.z)

            # Preserve:
            q = pdb.gimp_context_get_foreground()
            q1 = pdb.gimp_context_get_background()

            Lay.order(j, z, group)
            pdb.plug_in_pixelize2(j, z, one.session['w'], one.session['h'])

            z1 = Lay.clone(j, z)
            z1.mode = fu.LAYER_MODE_MULTIPLY
            z1.opacity = 25.
            w = one.session['w'] // d[ok.COLUMN_MAZE]
            h = one.session['h'] // d[ok.ROW_MAZE]
            w1 = (w + h) // 2

            pdb.gimp_selection_none(j)
            pdb.gimp_context_set_background((0, 0, 0))
            pdb.gimp_context_set_foreground((255, 255, 255))
            pdb.plug_in_maze(j, z1, w, h, 1, 0, d[ok.RANDOM_SEED], 0, 0)
            MazeBlend.select_white_mat(z1)

            sel = one.stat.save_render_sel()
            z2 = Lay.clone(j, z1)
            z2.mode = fu.LAYER_MODE_OVERLAY

            pdb.plug_in_edge(j, z1, ed.AMOUNT_1, ed.NO_WRAP, ed.SOBEL)

            for _ in range(4):
                Lay.dilate(j, z1)

            pdb.gimp_drawable_invert(z2, 0)
            Lay.color_fill(z2, (127, 127, 127))
            Sel.load(j, sel)
            Sel.clear_outside_of_selection(j, z2)
            MazeBlend.do_emboss(j, z2, d)
            pdb.gimp_drawable_invert(z1, 0)
            Lay.blur(j, z1, w1)
            Sel.load(j, sel)
            Sel.invert(j)
            Sel.clear_outside_of_selection(j, z1)

            # Restore:
            pdb.gimp_context_set_foreground(q)
            pdb.gimp_context_set_background(q1)

    @staticmethod
    def do_emboss(j, z, d):
        """
        Emboss a layer.

        j: GIMP image
            work-in-progress

        z: layer
            to emboss

        d: dict
            Has options.
        """
        pdb.plug_in_emboss(
            j,
            z,
            d[ok.LIGHT_ANGLE],
            em.ELEVATION_20,
            em.DEPTH_3,
            em.EMBOSS
        )

    @staticmethod
    def select_white_mat(z):
        """
        Select the white material on a layer.

        z: layer
            with material to make selection

        Return: state of selection
        """
        # Create a selection from the white lines:
        pdb.gimp_by_color_select(
            z,
            (255, 255, 255),
            THRESHOLD_POINT_5,
            fu.CHANNEL_OP_REPLACE,
            cs.YES_ANTIALIAS,
            cs.NO_FEATHER,
            cs.FEATHER_RADIUS_0,
            cs.NO_SAMPLE_MERGED
        )
