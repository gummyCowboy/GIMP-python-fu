#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from math import sqrt
from random import choice, randint, uniform
from roller_one_constant import (
    BrushKey as br,
    BumpKey,
    ForBump,
    ForFormat as ff,
    FormatKey as fk,
    ForPreset,
    ImageKey as ik,
    OptionKey as ok,
    OptionLimitKey as olk,
    PickleKey as pk,
    ShadowKey as sh,
    StripeKey as st
)
from roller_one_tip import Tip
import cPickle
import gimpfu as fu
import gtk
import os

pdb = fu.pdb


class Base:
    """Has functions used my multiple classes."""

    @staticmethod
    def create_2d_table(r, c, init=0, deep=0):
        """
        Return a 2D list.

        r, c: int
            size of the table

        init: value
            to init table with

        deep: flag
            When it is true, the init value is deep-copied.
        """
        b = [init] * r

        for i in range(r):
            if deep:
                b[i] = [0] * c
                for j in range(c):
                    b[i][j] = deepcopy(init)

            else:
                b[i] = [init] * c
        return b

    @staticmethod
    def enumerate_name(n, q):
        """
        Enumerate a name given a list of names.

        Ensure the name is unique as in a key.

        n: string
            name

        q: list
            list of names
            of string

        Return: string
            the enumerated name
        """
        while n[-1].isdigit():
            n = n[:-1]

        n = n.strip()
        a = len(q) + 1
        go = 1

        while go:
            go = 0
            n1 = n + " " + str(a)
            if n1.lower() in q:
                a += 1
                go = 1
        return n1

    @staticmethod
    def make_brush_tooltip(d):
        """
        Create a tooltip for a brush option button.

        d: dict
            with brush settings

        Return: string
            tooltip
        """
        return Tip.BASE_BRUSH.format(
            d[br.BRUSH],
            d[br.SIZE],
            d[br.SPACING],
            d[br.OPACITY],
            round(d[br.HARDNESS], 3),
            d[br.ANGLE]
        )

    @staticmethod
    def make_bump_tooltip(d):
        """
        Create a tooltip for a bump option button.

        d: dict
            with bump settings

        Return: string
            tooltip
        """
        if d[ok.BUMP] == ForBump.NOISE:
            return Tip.BASE_NOISE_BUMP.format(
                d[BumpKey.Emboss.BUMP_DEPTH],
                round(d[BumpKey.Emboss.BUMP_ELEVATION], 1),
                round(d[BumpKey.Noise.NOISE], 2),
                round(d[ok.LIGHT_ANGLE], 1)
            )

        elif d[ok.BUMP] == ForBump.CLOTH:
            return Tip.BASE_CLOTH_BUMP.format(
                d[BumpKey.Emboss.BUMP_DEPTH],
                round(d[BumpKey.Emboss.BUMP_ELEVATION], 1),
                round(d[BumpKey.Cloth.BLUR_X], 1),
                round(d[BumpKey.Cloth.BLUR_Y], 1),
                round(d[ok.LIGHT_ANGLE], 1)
            )

        else:
            return " No Bump "

    @staticmethod
    def make_cell_grid_tooltip(d):
        """
        Create a tooltip for a merged cell grid.

        d: dict
            with row and column settings

        Return: string
            tooltip
        """
        a = fk.Cell.Grid
        if d[a.TYPE] == ff.Grid.Index.CELL_COUNT:
            if d[a.SHAPE] in ff.Cell.Shape.DOUBLE:
                return Tip.BASE_BY_COUNT_SHIFT.format(
                    d[a.ROW],
                    d[a.COLUMN],
                    d[a.SHAPE],
                    bool(d[a.SHIFT])
                )
            return Tip.BASE_BY_COUNT.format(d[a.ROW], d[a.COLUMN], d[a.SHAPE])

        elif d[a.TYPE] == ff.Grid.Index.CELL_SIZE:
            if d[a.SHAPE] in ff.Cell.Shape.DOUBLE:
                return Tip.BASE_FIXED_SIZE_SHIFT.format(
                    d[a.ROW_HEIGHT],
                    d[a.COLUMN_WIDTH],
                    d[a.PIN],
                    d[a.SHAPE],
                    bool(d[a.SHIFT])
                )
            return Tip.BASE_FIXED_SIZE.format(
                d[a.ROW_HEIGHT],
                d[a.COLUMN_WIDTH],
                d[a.PIN],
                d[a.SHAPE]
            )

        else:
            if d[a.SHAPE] in ff.Cell.Shape.DOUBLE:
                return Tip.BASE_SHAPE_COUNT_SHIFT.format(
                    d[a.VERTICAL],
                    d[a.HORIZONTAL],
                    d[a.PIN],
                    d[a.SHAPE],
                    bool(d[a.SHIFT])
                )

            else:
                return Tip.BASE_SHAPE_COUNT.format(
                    d[a.VERTICAL],
                    d[a.HORIZONTAL],
                    d[a.PIN],
                    d[a.SHAPE]
                )

    @staticmethod
    def make_image_tooltip(d):
        """
        Create a tooltip for a image choice option button.

        d: dict
            of image choice

        Return: string
            tooltip
        """
        n = d[ik.IMAGE_REF]

        if d[ik.TYPE] == ff.Image.Type.FOLDER:
            if d[ik.FILTER]:
                return Tip.BASE_FOLDER_AND_FILTER.format(
                    n,
                    d[ik.FILTER],
                    ff.Image.FOLDER_ORDER_LIST[d[ik.FOLDER_ORDER]]
                )

            else:
                return Tip.BASE_FOLDER.format(
                    n,
                    ff.Image.FOLDER_ORDER_LIST[d[ik.FOLDER_ORDER]]
                )

        if (
            d[ik.HAS_FORMAT] and
            d[ik.AS_LAYERS] and
            d[ik.TYPE] in ff.Image.Type.AS_LAYERS_LIST
        ):
            return Tip.BASE_IMAGE_LAYERS.format(
                n,
                bool(d[ik.AS_LAYERS]),
                bool(d[ik.AUTOCROP]),
                ff.Image.LAYER_ORDER_LIST[d[ik.LAYER_ORDER]]
            )
        return n

    @staticmethod
    def make_margin_tooltip(q, fraction_of_type):
        """
        Return a tooltip for a margin tuple.

        The tuple is composed of four fixed-value
        and four fraction-of values.

        q: tuple
            of margins

        Return: string
            tooltip
        """
        a = ff.Margin.Index
        return Tip.BASE_MARGIN.format(
            q[a.TOP],
            q[a.BOTTOM],
            q[a.LEFT],
            q[a.RIGHT],
            fraction_of_type,
            q[a.TOP + 4],
            q[a.BOTTOM + 4],
            q[a.LEFT + 4],
            q[a.RIGHT + 4],
        )

    @staticmethod
    def make_shadow_tooltip(d):
        """
        Create a tooltip for a shadow tuple.

        d: dict
            of shadow

        Return: string
            tooltip
        """
        def get_shadow_tip(e):
            if n == ok.NONE:
                return Tip.BASE_NO_SHADOW

            elif n in ff.Shadow.LOWER_SHADOWS:
                e = e[n]
                return Tip.BASE_DROP_SHADOW.format(
                    n,
                    e[sh.SHADOW_BLUR],
                    e[sh.INTENSITY],
                    e[sh.OFFSET_X],
                    e[sh.OFFSET_Y],
                    e[sh.SHADOW_COLOR][0],
                    e[sh.SHADOW_COLOR][1],
                    e[sh.SHADOW_COLOR][2],
                    bool(e[sh.MAKE_OPAQUE])
                )

            elif n == sh.INLAY_SHADOW:
                e = e[sh.INLAY_SHADOW]
                return Tip.BASE_INLAY_SHADOW.format(
                    n,
                    e[sh.INLAY_BLUR],
                    e[sh.INTENSITY],
                    e[sh.SHADOW_COLOR][0],
                    e[sh.SHADOW_COLOR][1],
                    e[sh.SHADOW_COLOR][2]
                )
            return ""

        n = d[sh.TYPE]
        tip = ""

        if n in (sh.DROP_SHADOW, sh.INLAY_SHADOW, ok.NONE):
            tip = get_shadow_tip(d)

        else:
            n1 = n
            for n in d[n1]:
                n2 = "" if not tip else "\n"
                tip += n2 + get_shadow_tip(d[n1])
        return tip

    @staticmethod
    def make_stripe_tooltip(d):
        """
        Create a tooltip for a image choice option button.

        d: dict
            of image choice

        Return: string
            tooltip
        """
        if d[st.TYPE] == 1:
            return Tip.BASE_STRIPE.format(
                d[st.OPACITY],
                d[st.HEIGHT],
                d[st.BLUR_BEHIND],
                d[st.COLOR][0],
                d[st.COLOR][1],
                d[st.COLOR][2]
            )

        else:
            return " No Stripe "

    @staticmethod
    def circumradius(w, h):
        """
        Calculate the half-diagonal of a rectangle.

        Return: int
        """
        return int(sqrt(w**2 + h**2) // 2)

    @staticmethod
    def random_option(d, opt_key, e):
        """
        Randomize option values.

        Is part of the PortOption template.

        d: dict
            option group

        opt_key: string
            either an effect or a style

        e: dict
            Is option limit 'pure'.
        """
        for k in d:
            if k in e:
                if olk.LIMIT in e[k]:
                    a = e[k][olk.LIMIT]
                    if olk.PRECISION in e[k]:
                        d[k] = uniform(a[0], a[1])

                    else:
                        d[k] = randint(a[0], a[1])

                elif olk.LIMIT_SELF in e[k]:
                    d[k] = e[k][olk.LIMIT_SELF](opt_key)

                elif olk.LIMIT_FUNCTION in e[k]:
                    d[k] = e[k][olk.LIMIT_FUNCTION]()

                elif olk.LIST in e[k]:
                    d[k] = choice(e[k][olk.LIST])

    @staticmethod
    def rnd_col():
        """Return a tuple of integers containing random colors (r, g, b)."""
        return randint(0, 255), randint(0, 255), randint(0, 255)

    @staticmethod
    def seal(a, b, c):
        """
        Limit a numeric value to be between two numbers.

        a: value
            to limit

        b: value
            minimum amount

        c: value
            maximum amount
        """
        return max(min(c, a), b)


class OZ:
    """
    Has functions that work with the
    operating system or with files.
    """

    @staticmethod
    def ensure_dir(n):
        """
        Ensure a directory exists.

        n: string
            path

        Return two flags.
            err: int
                error flag

            go: int
                If it is true, then the operation was successful.
        """
        go = err = 0

        if n and not os.path.isdir(os.path.dirname(n)):
            try:
                os.makedirs(os.path.dirname(n))

            except Exception as ex:
                err = 1
                Comm.show_err(ex)
                Comm.show_err("Roller is unable to store files at\n" + n)

        else:
            go = 1
        return err, go

    @staticmethod
    def get_preset_name(n, n1):
        """
        Construct a preset file name.

        n: string
            preset name

        n1: string
            file specific id

        Return: string
            preset name
        """
        return n + ForPreset.PRESET_SEPARATOR + n1 + ".pkl"

    @staticmethod
    def get_preset_path(n, n1, _dir):
        """
        Construct a path to a preset.

        n: string
            preset name or key

        n1: string
            file id

        _dir: string
            preset root directory

        Return: string
            preset path
        """
        n2 = os.path.join(_dir, n)
        n3 = os.path.join(n2, OZ.get_preset_name(n, n1))
        return n3

    @staticmethod
    def pickle_dump(d):
        """
        Write a file using 'cPickle'.

        d: dict
            of Pickle

        Return:
            m: flag
                Is set to true if the operation succeeded.
        """
        m = 0
        n = d[pk.FILE]
        err, _ = OZ.ensure_dir(n)

        if not err:
            try:
                with open(n, "wb") as output_file:
                    cPickle.dump(d[pk.DATA], output_file)
                m = 1

            except Exception as ex:
                Comm.show_err(ex)
                Comm.show_err("Roller is unable to save\n" + n)
        return m

    @staticmethod
    def pickle_load(d):
        """
        Read a 'cPickle' type file.

        d: dict
            of Pickle

        Return: dict or None
            the data read in
        """
        e = None
        n = d[pk.FILE]
        err, go = OZ.ensure_dir(n)

        if go and not err:
            try:
                with open(n, "rb") as input_file:
                    e = cPickle.load(input_file)
                    if not isinstance(e, dict):
                        # failure:
                        e = {}

            except Exception as ex:
                if pk.SHOW_ERROR in d:
                    if d[pk.SHOW_ERROR]:
                        Comm.show_err(ex)
                        Comm.show_err("Roller is unable to load\n" + n)
        return e


class Comm:
    """Has functions that are used to communicate."""

    @staticmethod
    def info_msg(n):
        """
        Use to output messages to the error console.

        n: message
        """
        a = pdb.gimp_message_get_handler()
        n = n if isinstance(n, str) else str(n)

        pdb.gimp_message_set_handler(fu.ERROR_CONSOLE)
        fu.gimp.message(n)
        pdb.gimp_message_set_handler(a)

    @staticmethod
    def pop_up(window, x, n, title):
        """
        Display a message dialog.

        window: window
            GTK window
            parent

        x: int
            message type index
            (question, info)
            0, 1

        n: string
            message

        title: string
            window title

        Return: flag
            It is true if the user responded with yes.
        """
        g = gtk.MessageDialog(
            parent=window,
            flags=gtk.DIALOG_MODAL,
            type=(gtk.MESSAGE_QUESTION, gtk.MESSAGE_INFO)[x],
            buttons=(gtk.BUTTONS_YES_NO, gtk.BUTTONS_CLOSE)[x],
            message_format=n
        )

        g.set_title(title)

        a = g.run()

        g.destroy()
        return int(a == gtk.RESPONSE_YES)

    @staticmethod
    def show_err(a):
        """
        Post an error message to GIMP's error console.

        a: Exception or string
            to show
        """
        # Python 3 does not have basestring:
        if not isinstance(a, basestring):
            a = repr(a)
        Comm.info_msg(a)
