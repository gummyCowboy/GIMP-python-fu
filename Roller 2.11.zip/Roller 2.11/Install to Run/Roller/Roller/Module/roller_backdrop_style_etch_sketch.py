#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import ForBackdropStyle as fbs, OptionKey as ok
from roller_one_constant_fu import Fu
from roller_one_fu import Lay
from roller_one_gegl import Gegl
import gimpfu as fu

pdb = fu.pdb

em = Fu.Emboss
np = Fu.NewsPrint
FOUR_COORDINATES = 4


class EtchSketch:
    """Use edge and newsprint to create a broken line style."""

    def __init__(self, one):
        """
        Create a Etch Sketch backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        z = Lay.clone(j, one.z)
        if Lay.has_pixel(j, z):
            d = one.d
            self.opt_key = one.k
            self.angle = d[ok.LIGHT_ANGLE]
            self.cell_size = d[ok.CELL_SIZE]
            self.emboss = d[ok.EMBOSS]
            self.invert = d[ok.INVERT]
            self.opacity = d[ok.OPACITY]
            self.sketch_type = fbs.NEWS_TYPE.index(d[ok.SKETCH_TEXTURE])
            parent = one.z.parent

            pdb.plug_in_edge(
                j,
                z,
                Fu.Edge.AMOUNT_1,
                Fu.Edge.NO_WRAP,
                Fu.Edge.SOBEL
            )

            z = self._do_step_1(j, z, parent)
            z = self._do_step_2(j, z, Lay.clone(j, one.z), parent)
            self._do_step_3(j, z, parent)

    def _do_step_1(self, j, z, parent):
        """
        Increase the strength of the line.

        j: GIMP image
            work-in-progress

        z: layer
            Has line.

        parent: group layer
            contains the style
        """
        group = Lay.group(j, self.opt_key, parent=parent)

        Lay.order(j, z, group)

        z1 = Lay.clone(j, z)
        z1.mode = fu.LAYER_MODE_OVERLAY

        pdb.gimp_drawable_invert(z, 0)
        return Lay.merge_group(j, group)

    def _do_step_2(self, j, z, z1, parent):
        """
        Apply news print to line.

        j: GIMP image
            work-in-progress

        z: layer
            Has line.

        z1: layer
            copy of the original layer

        parent: group layer
            contain the style
        """
        while self.angle < 0:
            self.angle += 360

        group = Lay.group(j, self.opt_key, parent=parent)

        Lay.order(j, z1, group)
        Lay.order(j, z, group)

        z.mode = fu.LAYER_MODE_DARKEN_ONLY

        pdb.plug_in_newsprint(
            j,
            z,
            self.cell_size,
            np.RGB,
            np.BLACK_100,
            self.angle,
            self.sketch_type,
            self.angle,
            self.sketch_type,
            self.angle,
            self.sketch_type,
            self.angle,
            self.sketch_type,
            np.SAMPLE_2
        )

        q = 0, 0, 0

        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_sample_merged(0)
        pdb.gimp_context_set_sample_criterion(0)
        pdb.gimp_context_set_sample_threshold(.25)
        pdb.gimp_context_set_sample_transparent(1)
        pdb.gimp_image_select_color(j, fu.CHANNEL_OP_REPLACE, z1, q)
        Lay.clear_sel(j, z)
        Gegl.blur(z1, 500)
        pdb.gimp_curves_spline(
            z1,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 100, 255, 155]
        )

        z.opacity = self.opacity
        return Lay.merge_group(j, group)

    def _do_step_3(self, j, z, parent):
        """
        Do invert and / or emboss.

        j: GIMP image
            work-in-progress

        z: layer
            Has line.

        parent: group layer
            contain the style
        """
        group = Lay.group(j, self.opt_key, parent=parent)

        Lay.order(j, z, group)

        if self.invert:
            pdb.gimp_drawable_invert(z, 0)

        if self.emboss:
            z1 = Lay.clone(j, z)
            pdb.plug_in_emboss(
                j,
                z1,
                self.angle,
                em.ELEVATION_30,
                em.DEPTH_1,
                em.EMBOSS
            )
            z1.mode = fu.LAYER_MODE_HARDLIGHT
        return Lay.merge_group(j, group)
