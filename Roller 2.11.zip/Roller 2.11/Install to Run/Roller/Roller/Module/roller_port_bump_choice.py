#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_base import Base
from roller_one_constant import (
    BumpKey,
    ForBump as fb,
    ForWidget as fw,
    OptionKey as ok,
    OptionLimitKey as olk,
    UIKey
)
from roller_one_preset import Preset
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_button_pair import ButtonPair
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_radio import RollerRadioList
from roller_widget_table import RollerTable
import gtk

LABEL = "No Bump", "Noise Bump", "Cloth Bump"


class PortBumpChoice(Port):
    """Provide widgets for defining a bump layer."""

    def __init__(self, d, g):
        """
        Create the port.

        g: OptionButton
            Has values.
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self._d = g.get_value()
        self._button = g
        self._do_preview = g.preview if g.preview else None
        self.stat = g.stat
        self._is_valid_preview = False
        Port.__init__(self, d)

    def _draw_noise_group(self, g):
        """
        Draw the noise bump options.

        g: GTK container
            to receive group
        """
        default = BumpKey.Noise.NOISE,
        pure = self.stat.option_limit.pure
        q = []
        d = dict(
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
        )

        for k in default:
            widget = pure[k][olk.WIDGET]
            e = self.stat.option_limit.collect_widget_arg(k, ok.BUMP, self)
            e['key'] = k

            e.update(d)

            q1 = [k, widget, e]
            q.append(q1)

        d = RollerTable.create(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        self.controls += [d[i] for i in d]

    def _draw_choices(self, g):
        """
        Draw the choices group.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        box = RollerBox(
            gtk.VBox,
            align=(1, 1, 1, 1),
            padding=(w // 2, w, 0, 0)
        )

        g.add(box)

        g = self._radio_list = RollerRadioList(
            container=box,
            key=ok.BUMP,
            labels=LABEL,
            on_widget_change=self._on_list_change,
            padding=(1, 0, w, w)
        )
        self.controls += [g]

    def _draw_cloth_group(self, g):
        """
        Draw the cloth bump options.

        g: GTK container
            to receive group
        """
        default = BumpKey.Cloth.BLUR_X, BumpKey.Cloth.BLUR_Y
        pure = self.stat.option_limit.pure
        q = []
        d = dict(
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
        )

        for k in default:
            widget = pure[k][olk.WIDGET]
            e = self.stat.option_limit.collect_widget_arg(k, ok.BUMP, self)
            e['key'] = k

            e.update(d)

            q1 = [k, widget, e]
            q.append(q1)

        d = RollerTable.create(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        self.controls += [d[i] for i in d]

    def _draw_emboss_options(self, g):
        """
        Draw the emboss options group.

        g: VBox
            container for the widgets
        """
        self.reduce_color()

        self._emboss_box = gtk.VBox()
        box = RollerEventBox(self.color)

        box.add(self._emboss_box)
        g.add(box)
        self._emboss_box.add(
            RollerLabel(
                padding=(2, 0, 4, fw.MARGIN),
                text="Emboss Options:"
            )
        )

        # The 'default' dict has ordered keys:
        default = (
            BumpKey.Emboss.BUMP_DEPTH,
            BumpKey.Emboss.BUMP_ELEVATION,
            ok.LIGHT_ANGLE
        )

        pure = self.stat.option_limit.pure
        q = []
        d = dict(
            color=self.color,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
        )

        for k in default:
            widget = pure[k][olk.WIDGET]
            e = self.stat.option_limit.collect_widget_arg(k, ok.BUMP, self)
            e['key'] = k

            e.update(d)

            q1 = [k, widget, e]
            q.append(q1)

        p = self._preview if self._do_preview else None
        q += [
            [
                "",
                ButtonPair,
                dict(
                    d,
                    button_action=(
                        p,
                        self._randomize
                    ),
                    on_widget_change=lambda *a: None,
                    text=("Preview", "Randomize")
                )
            ]
        ]
        d = RollerTable.create(
            container=self._emboss_box,
            q=q,
            color=self.color
        )
        self.controls += [d[i] for i in d]

    def _draw_options(self, g):
        """
        Create option groups that sync with the radio-list.

        g: VBox
            container for the groups
        """
        # for switch group box
        # Is affected by 'self.on_list_change':
        vbox = gtk.VBox()

        g.pack_start(vbox, expand=1)

        g1 = self._radio_list
        g1.switch_group_box = vbox
        group = (
            self._draw_none_group,
            self._draw_noise_group,
            self._draw_cloth_group
        )
        self.none_index = len(group) - 1

        for x, p in enumerate(group):
            vbox = gtk.VBox()

            g1.group_box.append(vbox)
            vbox.add(
                RollerLabel(
                    padding=(2, 0, 4, fw.MARGIN),
                    text=LABEL[x] + " Options:"
                )
            )
            p(vbox)

        # for emboss options
        # Is unaffected by 'self.on_list_change':
        vbox = gtk.VBox()

        self._draw_emboss_options(vbox)
        g.pack_end(vbox, expand=True)

    def _draw_none_group(self, g):
        """
        Draw the none options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text="No bump will be applied\n"
            "when this option is used."
        )
        g.pack_start(g1, expand=True)

    def _draw_preset_group(self, g):
        """
        Draw a preset group for the cell grid.

        g: VBox
            container for widgets
        """
        self.preset = Preset(
            container=g,
            key=ok.BUMP,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_preset_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _on_list_change(self, *q):
        """
        Use to set the preset to undefined.

        q: iterable
            of arguments
        """
        self.on_list_change(*q)
        self._update_emboss_box()
        self.on_widget_change(self._radio_list)

    def _preview(self, g):
        """
        Do a preview.

        g: RollerButton
            Is responsible.
            not used
        """
        self._button.set_value(self.preset.get_value())

        if hasattr(self._button, 'option_group'):
            self._button.option_group.changed = 1

        self._is_valid_preview = True
        self._do_preview(self._button)
        self._button.set_value(self._d)

    def _randomize(self, g):
        """
        Randomize option values.

        g: RollerButton
            Is responsible.
            not used
        """
        Port.loading += 1
        k = ok.BUMP
        d = self.preset.get_value()

        Base.random_option(d, k, self.stat.option_limit.pure)
        self.preset.set_value(d)

        Port.loading -= 1
        self.preset.preset_is_undefined()

    def _update_emboss_box(self, *_):
        """Update the visibility of the table option group."""
        if self._radio_list.get_value() == fb.NONE:
            self._emboss_box.hide()
            self.roller_window.resize()

        else:
            self._emboss_box.show()

    def do_accept(self, *_):
        """
        Accept the choice.

        Return: true
            The key-press is handled.
        """
        if self._is_valid_preview:
            if hasattr(self._button, 'option_group'):
                self._button.option_group.changed = 0

        else:
            if hasattr(self._button, 'option_group'):
                self._button.option_group.changed = 1
        return self.do_accept_callback(self.preset.get_value())

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = (
            self._draw_choices,
            self._draw_options,
            self._draw_preset_group,
            self.draw_process_group
        )
        group_name = "Choose Bump", "", "Bump Preset", "Process"

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if group_name[x]:
                vbox.pack_start(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=group_name[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()

            if x in (0, 2):
                hbox = gtk.HBox()
                g.pack_start(hbox, expand=True)
            hbox.pack_start(box, expand=True)

        self.preset.widget_list = self.controls

        self._emboss_box.connect('expose-event', self._update_emboss_box)
        self.preset.load_preset(fw.UNDEFINED, self._d)

        a = Port.loading
        Port.loading = 0

        self.on_list_change(self._radio_list, self._radio_list.get_value())
        Port.loading = a

    def on_preset_change(self, g):
        """
        Call when a preset is loaded.

        g: RollerComboBox
            Is responsible.
            not used
        """
        self.on_list_change(self._radio_list, self._radio_list.get_value())

    def on_widget_change(self, g):
        """
        Call when a widget is changed.

        g: Widget
            Is responsible.
        """
        if not Port.loading:
            self.preset.preset_is_undefined()
            self._is_valid_preview = False
