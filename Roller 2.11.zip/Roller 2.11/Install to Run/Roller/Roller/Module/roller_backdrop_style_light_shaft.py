#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_style_gradient_fill import GradientFill
from roller_one import One
from roller_one_constant import OptionKey as ok, BackdropStyleKey as bsk
from roller_one_constant_fu import Fu
from roller_one_fu import Lay
from roller_one_preset import Preset
import gimpfu as fu

mo = Fu.Mosaic
pdb = fu.pdb
MOSAIC = (
    mo.TILE_HEIGHT_1,
    mo.TILE_SPACING_MIN,
    mo.TILE_NEATNESS_MIDDLE,
    mo.NO_SPLIT,
    mo.LIGHT_ANGLE_0,
    mo.MIN_COLOR_VARIATION,
    mo.YES_ANTIALIAS,
    mo.YES_COLOR_AVERAGING,
    mo.TRIANGLE_TYPE,
    mo.SMOOTH_SURFACE,
    mo.BLACK_AND_WHITE_GROUT
)


class LightShaft:
    """Create a dark stone-like texture with bumpy highlights."""

    def __init__(self, one):
        """
        Create a Light Shaft backdrop-style.

        one: One
            Has variables.
        """
        self.stat = one.stat
        j = one.stat.render.image
        if Lay.has_pixel(j, one.z):
            self.option_key = one.k
            self.session = one.session
            group = Lay.group(j, one.k, one.z.parent)
            z = Lay.clone(j, one.z)

            Lay.order(j, z, group)
            pdb.gimp_selection_all(j)

            for i in range(10):
                z.name = "{} Layer #{} of 10".format(one.k, i + 1)

                if not i % 3:
                    pdb.plug_in_mosaic(
                        j,
                        z,
                        (i + 1) * one.d[ok.SCALE],
                        *MOSAIC
                    )

                elif not i % 2:
                    Lay.flip(z, horizontal=1)

                else:
                    Lay.flip(z)

                z = Lay.clone(j, z)
                z.mode = fu.LAYER_MODE_DIFFERENCE

            z = Lay.merge_group(j, group)
            group = Lay.group(j, one.k, parent=one.z.parent)
            z1 = Lay.clone(j, z)
            z1.mode = fu.LAYER_MODE_EXCLUSION

            Lay.order(j, z1, group)
            pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
            pdb.plug_in_emboss(j, z1, 135, 30., 1, 1)

            z1 = Lay.clone(j, z1)
            z1.mode = fu.LAYER_MODE_GRAIN_MERGE
            z1 = Lay.clone(j, z1)
            z1.mode = fu.LAYER_MODE_GRAIN_EXTRACT
            e = Preset.get_default(bsk.GRADIENT_FILL)
            e[ok.GRADIENT] = "Default"
            e[ok.GRADIENT_TYPE] = "Bilinear"
            e[ok.MODE] = "Normal"
            e[ok.OPACITY] = 50.
            e[ok.INVERT] = e[ok.REVERSE] = 1
            e[ok.START_X] = e[ok.START_Y] = .5
            e[ok.END_X] = e[ok.END_Y] = 0.
            e[ok.OFFSET] = 0
            e[ok.ROTATE] = one.d[ok.ROTATE]

            self._do_gradient(z, e)

            z = j.active_layer

            Lay.order(j, z, group, offset=len(group.layers))

            z2 = Lay.clone(j, z)

            Lay.order(j, z2, group, offset=0)
            pdb.gimp_drawable_invert(z2, Fu.DrawableInvert.NO_LINEAR)

            z2.mode = fu.LAYER_MODE_LINEAR_BURN
            z = Lay.merge_group(j, group)
            z = Lay.clone(j, z)
            z.mode = fu.LAYER_MODE_COLOR_ERASE
            z.opacity = 50.

            pdb.plug_in_erode(j, z, 1, 7, 1, 0, 0, 255)
            pdb.gimp_drawable_invert(z, Fu.DrawableInvert.NO_LINEAR)

    def _do_gradient(self, z, e):
        """
        Draw a gradient on a layer.

        Preserve the alpha.

        z: layer
            to receive the gradient

        e: dict
            Has gradient options.
        """
        j = self.stat.render.image

        Lay.clone(j, z)
        GradientFill(
            One(
                d=e,
                k=self.option_key,
                session=self.session,
                stat=self.stat,
                z=j.active_layer
            )
        )

        z1 = j.active_layer

        Lay.give_mask(z1, z)
        return Lay.merge(j, z1)
