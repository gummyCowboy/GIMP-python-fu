#!/usr/bin/env python
# -*- coding: utf-8 -*-
from ctypes import c_char_p, c_void_p, CDLL, POINTER, Structure, util
from gimpfu import pdb
import sys

EMBOSS = "emboss azimuth=%d elevation=%d depth=%d"
G_BLUR = "gaussian-blur std-dev-x=%f std-dev-y=%f"


class Gegl:
    """
    Use as a common ground for essential program variables.

    Has minimal dependencies so it won't create a circular import problem.
    """
    # DLL:
    gimp_library = None

    @staticmethod
    def blur(z, f):
        """
        Do the GEGL gaussian blur.

        z: layer
            work-in-progress

        f: float
            standard deviation for x and y
        """
        f = min(float(f), 1500.)
        Gegl.do_gegl(z, G_BLUR % (f, f))

    @staticmethod
    def emboss(z, azimuth, elevation, depth):
        """
        Do the GEGL emboss.

        z: layer
            work-in-progress

        azimuth: int
            for emboss

        elevation: int
            higher is lighter

        depth: int
            for emboss
        """
        Gegl.do_gegl(z, EMBOSS % (azimuth, elevation, depth))

    @staticmethod
    def do_gegl(z, n):
        """
        Perform a GEGL function.

        z: drawable
            work-in-progress

        n: string
            of GEGL graph
        """
        class GeglBuffer(Structure):
            pass

        # drawable id:
        _id = z.ID

        go = 0
        gegl = Gegl.load_library('libgegl-0.4')
        gimp = Gegl.gimp_library

        if gegl:
            go = gegl.gegl_init(None, None)
        if go:
            gimp.gimp_drawable_get_shadow_buffer.restype = POINTER(GeglBuffer)
            gimp.gimp_drawable_get_buffer.restype = POINTER(GeglBuffer)

            is_sel, x, y, w, h = pdb.gimp_drawable_mask_intersect(z)
            args = [b"string", c_char_p(n), c_void_p()]

            if is_sel:
                source = gimp.gimp_drawable_get_buffer(_id)
                target = gimp.gimp_drawable_get_shadow_buffer(_id)
                if gegl.gegl_render_op(source, target, "gegl:gegl", *args):
                    gegl.gegl_buffer_flush(target)
                    gimp.gimp_drawable_merge_shadow(_id, PushUndo=True)
                    gimp.gimp_drawable_update(_id, x, y, w, h)
                    gimp.gimp_displays_flush()

    @staticmethod
    def load_library(library_name):
        """
        Load library for GEGL command function.
        The library name differs with the operating system.

        library_name: string
            OS dependent library name

        Return: library or None
            as referenced by 'library_name'
        """
        n = sys.platform

        if n == "linux" or n == "linux2":
            library_name = library_name + '.so.0'

        elif n == "win32":
            # Search for the library name from
            # the PATH environment variable:
            library_name = util.find_library(library_name + "-0")

        else:
            library_name = ""
        if library_name:
            # Load the dynamic link library:
            return CDLL(library_name)
